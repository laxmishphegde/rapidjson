/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINLIB02_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H
#define CTYPE_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"      
#include "tls.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "scpt.h"
#include "scptyl.h"
#include "conv.h"       /* REF4249 - SSO - 000926 */
#include "finai.h"
#include "scelib.h"
#include "scelib.h"     /* REF9082 - TEB - 030619 */

TIMER_ST        SV_KeywordMeanCap;
TIMER_ST        SV_KeywordSelectPtfSynthMeanCap;
TIMER_ST        SV_KeywordSelectPtfSynthReturn;
TIMER_ST        SV_KeywordReturnOptimiGet;
TIMER_ST        SV_KeywordReturnOptimiSet;
TIMER_ST        SV_KeywordPeriodReturnOptimiSet;
TIMER_ST        SV_KeywordReturnCalc;
TIMER_ST        SV_KeywordReturnAnnual;
TIMER_ST        SV_KeywordCalcMeanCapReturn;
TIMER_ST        SV_KeywordPeriodPtfReturn;
TIMER_ST        SV_KeywordCalcMeanCapIRR;
int             getMWRSucceedCounter;
int             getMWRFailedCounter;
int             setMWRCounter;

/*  -------------------------------------------------------------------------------------------- **
**  RETURN FUNCTIONS 
**  -----------------
**  FIN_BenchReturn() 		    Calculate the return of any object (value varies over time)
**  FIN_RetDiff() 		        Difference between 2 portfolio synthethic data
**  FIN_Return() 		        Compute rate of return depending on received arguments
**  FIN_CalcCapPL() 		    Compute asked capital P&L
**  FIN_CalcMeanInvestedCap() 	Compute mean invested capital for received period 
**  FIN_CalcUnrealPL() 		    Compute profit and loss for received position
**  FIN_CmpPtfSynth() 		    Sort ptf synthetic data by portfolio and validity date
**  FIN_CmpReturnPtfSynth() 	Sort ptf synthetic data order by portfolio and validity date
**  FIN_CmpInstrCompo()     Sort instr compo ordered by begin date descending
**  FIN_FilterPtfSynth() 	    Keep valid synth data depending on risk flag, period and dimension.
**  FIN_InstrBenchReturn() 	    Calculate the return of received instrument 
**  FIN_InternalRateReturn() 	Calculate the internal rate of return          
**  FIN_PeriodPtfReturn() 	    Compute average capital on period (mean invested cap) and return 
**  FIN_SelectPtfSynth() 	    Select ptf synthetic data depending on received flags and date
**  FIN_UnrealPL() 		        Compute profit and loss for received position
**  FIN_UpdFlowPeriodArray() 	Fill flowArray and periodArray depending on ptf synthetic data
**  FIN_PeriodIncEvt() 		    Compute period income event value
**
**  -------------------------------------------------------------------------------------------- **
**  BOOK VALUE FUNCTIONS     
**  ------------------------
**  FIN_ComputeBookValue()      Compute target book value
**  FIN_BookValueByValRule()    Look for valid valuation rule element and compute target book value
**
**  -------------------------------------------------------------------------------------------- */

/************************************************************************
**      Structure definitions
*************************************************************************/
typedef struct FIN_WEIGHT FIN_WEIGHT_ST, *FIN_WEIGHT_STP;

struct FIN_WEIGHT {
        OBJECT_ENUM     objectEnum;
        ID_T            objectId;
        DBA_DYNFLD_STP  objectPtr;
        FLAG_T          objectAllocFlg;
        DBA_DYNFLD_STP  objectHistPtr;
        FLAG_T          objectHistAllocFlg;
        FIN_WEIGHT_STP  parentWeightPtr;
        int             childNbr;
        DBA_DYNFLD_STP  *eltTab;
        FLAG_T          eltTabAllocFlg;
		
		/* REF9071 - RAK - 030819 */
		/* change FIN_WEIGHT_STP childWeightTab in FIN_WEIGHT_STP* to allow correct storage in parentWeightPtr */
		/* because we can't stored pointer on an element of a array which is REALLOCATED (pointer could change) */
        FIN_WEIGHT_STP  *childWeightTab;

        NUMBER_T        weightValue;
        NUMBER_T        periodReturn;	
};

typedef struct {
        FIN_WEIGHT_STP  firstWeight;
        FLAG_T          initialWeightFlg;
        DATETIME_T      beginDate;
        DATETIME_T      endDate;
} FIN_WEIGHTHEAD_ST, *FIN_WEIGHTHEAD_STP;


/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE	FIN_PeriodPtfReturn(DBA_DYNFLD_STP*, int, int, FLAG_T, FLAG_T,
    FLAG_T, FLAG_T, FLAG_T, FLAG_T,
    DBA_DYNFLD_STP,
    DBA_DYNFLD_STP,
    DBA_DYNFLD_STP,
    DBA_DYNFLD_STP, double*, double*,
    DBA_HIER_HEAD_STP),
    FIN_InternalRateReturn(DATETIME_T, DATETIME_T, FLAG_T, FLAG_T,
        FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, /* REF11269 - LJE - 051220 */
        DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int,
        DBA_DYNFLD_STP, DBA_DYNFLD_STP, double*, double*, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
    FIN_IRate(AMOUNT_T, double*, double*, int, double*),	/* REF10663 - TEB - 041115 */
    FIN_PeriodIncEvt(DBA_DYNFLD_STP, DBA_DYNFLD_STP,
        ID_T, ID_T, FIN_EXCHARG_STP, /* PMSTA-10527 - RAK - 101021 */
        DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, NUMBER_T,  /* REF4180 - LJE - 020704 */
        double*, FLAG_T, std::set<DATE_T> &, DBA_HIER_HEAD_STP),   /* PMSTA-47762 - JBC - 220131 */

    FIN_PeriodIncEvtInstrFlow(DBA_DYNFLD_STP,
        ID_T, ID_T, FIN_EXCHARG_STP, /* PMSTA-10527 - RAK - 101021 */
        DATETIME_T, DATETIME_T,
        NUMBER_T, double*, FLAG_T, std::set<DATE_T> &, DBA_HIER_HEAD_STP),  /* PMSTA-47762 - JBC - 220131 */

    FIN_SelectPtfSynth(DATETIME_T, DATETIME_T, FLAG_T, ID_T, ID_T, ID_T, ID_T, ID_T,
        DBA_DYNFLD_STP, /* REF4263 - CSY - 000128 */
        DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
        FLAG_T*, /* REF4263 - CSY - 000211 */
        int*, DBA_DYNFLD_STP**),
    FIN_CalcMeanInvestedCap(DBA_DYNFLD_STP*, int, int, FLAG_T,
        FLAG_T, FLAG_T, FLAG_T,
        FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP, /* REF11269 - LJE - 051220 */
		DBA_DYNFLD_STP,double*, double*, double*, double*,
        DATETIME_T,         /* REF7395 - CSY - 020430 */
        DATETIME_T,         /* REF7395 - CSY - 020430 */
        DBA_HIER_HEAD_STP), /* REF4253 - RAK - 000106 */
    FIN_CalcMeanInvestedCapWithNIP(DBA_DYNFLD_STP*, int, int, FLAG_T,
                                   FLAG_T, FLAG_T, FLAG_T,
                                   FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, /* REF11269 - LJE - 051220 */
                                   double*, double*, double*, double*,
                                   DATETIME_T,         /* REF7395 - CSY - 020430 */
                                   DATETIME_T, DBA_HIER_HEAD_STP),        /* REF7395 - CSY - 020430 */
    FIN_CalcMeanInvestedCapNew(DBA_DYNFLD_STP*, int, int, FLAG_T,
					           FLAG_T, FLAG_T, FLAG_T, 
                               FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP,
                               double*, double*, double*, double*, 
                               DATETIME_T,         
                               DATETIME_T,         
                               DBA_HIER_HEAD_STP); /* PMSTA07059 - LJE - 080917 */

STATIC int FIN_CmpPtfSynth(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
           FIN_CmpInstrCompo(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), /* REF5358 - CSY - 001115 */
           FIN_CmpStratHistByDescBegDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), /* REF5358 - CSY - 001123 */
           FIN_CmpDateTime(DATETIME_T*, DATETIME_T*); /* REF5358 - CSY - 001115 */

        
int     FIN_CmpReturnPtfSynth(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),

        FIN_FilterPtfSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),	/* REF385 */
        FIN_FilterStrat(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),    /* REF6025 - CSY - 010606 */
        FIN_FilterStrat2(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),    /* REF7422 - CSY - 020605 */
        FIN_FilterGlobalPtfSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7634 - LJE - 020619 */
        
       

STATIC void FIN_UpdFlowPeriodArray(DATETIME_T, DATETIME_T, double, FLAG_T, FLAG_T, FLAG_T, FLAG_T, 
				   FLAG_T, FLAG_T, 
                   FLAG_T, FLAG_T,  /* REF11269 - LJE - 051220 */
                   DBA_DYNFLD_STP, 
                   DBA_DYNFLD_STP, /* REF7395 - CSY - 020808 */
                   double, double*, double*, int*);

STATIC void FIN_CalcInvestAndWithdr(DBA_DYNFLD_STP, 
                                    DBA_DYNFLD_STP, /* REF7395 - CSY - 020808 */
                                    FLAG_T, FLAG_T, FLAG_T,
			   		                FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, int, double, FLAG_T*, /* REF11269 - LJE - 051220 */
                                    AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*,
                                    DATETIME_T, DATETIME_T);    /* REF7395 - CSY - 020430 */
STATIC void FIN_CalcInvestAndWithdrNew(DBA_DYNFLD_STP, 
                                    DBA_DYNFLD_STP,
                                    FLAG_T, FLAG_T,
			   		                FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T*,
                                    AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*, AMOUNT_T*,
                                    DATETIME_T, DATETIME_T);   /* PMSTA07059 - LJE - 080917 */
STATIC void FIN_CalcFinalNumDays(DBA_DYNFLD_STP, DBA_DYNFLD_STP, INVESTTIMINGRULE_ENUM, 
                                 FLAG_T, FLAG_T*, double*,DBA_HIER_HEAD_STP);

STATIC RET_CODE FIN_CalcInitNumDaysAndInterm(DBA_DYNFLD_STP*, DBA_DYNFLD_STP, int, INVESTTIMINGRULE_ENUM,
                                             FLAG_T, FLAG_T, DBA_DYNFLD_STP*, FLAG_T*, double*, /* REF7634 - LJE - 020618 */
                                             int**, int*, int*, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_CalcPtfDailyFlg(DBA_DYNFLD_STP, int, DBA_HIER_HEAD_STP, FLAG_T*);

/* PMSTA-11143 - RAK - 101220 */
STATIC double FIN_InstrBenchReturnPeriod(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T,
			                           ID_T, RETURNTP_ENUM, RETURNNAT_ENUM,
			                           NUMBER_T, NUMBER_T, FLAG_T, 
	                                   ID_T, ID_T, /* REF5358 - CSY - 001218 */
									   FIN_RETURNPARAM_STP, /* PMSTA08895 - LJE - 091102 */
	                                   DBA_HIER_HEAD_STP, FLAG_T);
/* REF5358 - CSY - 001114 */
STATIC RET_CODE FIN_CompositeBenchReturn(FIN_WEIGHT_STP, OBJECT_ENUM, DATETIME_T, DATETIME_T,
		                           FIN_RETURNPARAM_STP, IDXTIMERULE_ENUM, ID_T, CONTRIBRULE_ENUM,
                                   ID_T, ID_T,
                                   FIN_BENCHRETPARAM_STP, /* REF6025 - CSY - 010614 */
                                   FLAG_T,  /* REF6025 - CSY - 010611 */
                                   FLAG_T,  /* REF7422 - CSY - 020605 */
                                   FLAG_T*, /* REF6025 - CSY - 010619 */
								   DBA_DYNFLD_STP,
                                   DBA_HIER_HEAD_STP);


/* REF5358 - CSY - 010117 */
STATIC RET_CODE FIN_ComputeWeight(ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, OBJECT_ENUM,
		                           DATETIME_T, FIN_RETURNPARAM_STP, IDXTIMERULE_ENUM,
                                   ID_T, CONTRIBRULE_ENUM, ID_T, ID_T, DBA_HIER_HEAD_STP,
                                   FIN_WEIGHT_STP, 
                                   DBA_DYNFLD_STP*, int, FLAG_T,  /* SUPPORT-6697 - LJE - 160609 */
                                   FLAG_T,
                                   FLAG_T,  /* REF7422 - CSY - 020605  */
                                   ID_T**,  /* REF6025 - CSY - 010607 */
                                   int*,    /* REF6025 - CSY - 010607 */
                                   DBA_DYNFLD_STP); /* REF6025 - CSY - 010606 */

/* DVP186 */
STATIC AMOUNT_T FIN_CalcCapPL(DBA_DYNFLD_STP, DBA_DYNFLD_STP, PORTPLCOMPRULE_ENUM, 
		                      CURRPLCOMPRULE_ENUM, PLTP_ENUM, ID_T);

STATIC RET_CODE FIN_InitWeightHeader(FIN_WEIGHTHEAD_STP, 
                                     OBJECT_ENUM, ID_T, 
                                     DBA_DYNFLD_STP, FLAG_T, DBA_DYNFLD_STP, FLAG_T, 
                                     DATETIME_T, DATETIME_T);
STATIC RET_CODE FIN_FreeWeightTab(FIN_WEIGHTHEAD_STP);
STATIC RET_CODE FIN_FreeWeight(FIN_WEIGHT_STP*);
STATIC RET_CODE FIN_AddChildWeight(FIN_WEIGHT_STP, OBJECT_ENUM,
                                   ID_T, DBA_DYNFLD_STP, FLAG_T, DBA_DYNFLD_STP, FLAG_T, 
                                   DBA_DYNFLD_STP, FLAG_T); 
STATIC RET_CODE FIN_ComputeInitWeight(FIN_WEIGHTHEAD_STP,
                                      FIN_RETURNPARAM_STP,
                                      IDXTIMERULE_ENUM,
                               ID_T,
                               CONTRIBRULE_ENUM,
                               ID_T,
                               ID_T,
                               FIN_BENCHRETPARAM_STP,   /* REF6025 - CSY - 010606 */
                               FLAG_T,  /* REF6025 - CSY - 010706 */
                               DATETIME_T,  /* REF6025 - CSY - 010706 */
                               FLAG_T,  /* REF7422 - CSY - 020605 */
							   DBA_DYNFLD_STP,			/* REF10274 - RAK - 040506 */
                               DBA_HIER_HEAD_STP);      /* REF5358 - CSY - 010119 */
STATIC RET_CODE FIN_ComputeNewInitWeight(FIN_WEIGHT_STP,    /* REF5358 - CSY - 010119 */
                                         FLAG_T);          /* REF6025 - CSY - 010606 */ 
                                            

 
STATIC RET_CODE FIN_SearchWeight(FIN_WEIGHT_STP, ID_T, FLAG_T*, double*);    /* REF6025 - CSY - 010530 */



/* REF5662 - DDV - 010209 */
STATIC int FIN_FilterNotAccExtPos(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7264 - LJE - 020131 */
STATIC int FIN_FilterNotAccNoRiskExtPos(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);	/* PMSTA-8736 - RAK - 100205 */

STATIC int FIN_FilterStratWithMktSgtOfElt(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

STATIC int FIN_FilterStratByIdAndRefStratId(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);	/* REF10274 - RAK - 040512 */


/* REF10822 - RAK - 041215 */
STATIC RET_CODE FIN_ComputeWeightGetStratAndStratHist(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T, FLAG_T, DATETIME_T, DBA_DYNFLD_STP*, FLAG_T*, DBA_DYNFLD_STP*, FLAG_T*);
/* PMSTA-11143 - RAK - 101220 */
STATIC RET_CODE FIN_InstrBenchReturnIncome(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, ID_T, RETURNTP_ENUM, NUMBER_T, ID_T, DBA_HIER_HEAD_STP,
										   NUMBER_T*, FLAG_T, std::set<DATE_T> &); /* PMSTA-47762 - JBC - 220131 */
													 
/************************************************************************
**      Functions 
*************************************************************************/

/************************************************************************
**
**  Function    :  FIN_InitWeightHeader()
**
**  Description :  Initialyse the header structure used to store weights, 
**                 with informations of first strategy or instrument.
**                 
**  Arguments   :  weightHead         header of structure used to store weights
**                 objectEnum         objectEnum of object (Instr or Strat)
**                 objectId           id of object
**                 objectPtr          pointer on object
**                 objectAllocFlg     flag to indicate if pointer of object must be free
**                 objectHistPtr      pointer of current histry of object (used only for strategy)
**                 objectHistAllocFlg flag to indicate if pointer of object history must be free
**                 beginDate          begin date of treated period
**                 endDate            end date of treated period
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010116 - DDV
**  Modif.      :  
**
*************************************************************************/
STATIC RET_CODE FIN_InitWeightHeader(FIN_WEIGHTHEAD_STP weightHead, 
                                     OBJECT_ENUM        objectEnum,
                                     ID_T               objectId,
                                     DBA_DYNFLD_STP     objectPtr,
                                     FLAG_T             objectAllocFlg,
                                     DBA_DYNFLD_STP     objectHistPtr,
                                     FLAG_T             objectHistAllocFlg,
                                     DATETIME_T         beginDate, 
                                     DATETIME_T         endDate)
{
    FIN_WEIGHT_STP weight=NULL;

    if (weightHead->firstWeight != (FIN_WEIGHT_STP) NULL)
        FIN_FreeWeightTab(weightHead);

    weight = weightHead->firstWeight = (FIN_WEIGHT_STP) CALLOC (1, sizeof(FIN_WEIGHT_ST));
    if (weightHead->firstWeight == (FIN_WEIGHT_STP) NULL)
    {
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
    }

    weightHead->initialWeightFlg=FALSE;
    weightHead->beginDate.date=beginDate.date;
    weightHead->beginDate.time=beginDate.time;
    weightHead->endDate.date=endDate.date;
    weightHead->endDate.time=endDate.time;

    weight->objectEnum = objectEnum;
    weight->objectId = objectId;
    weight->objectPtr = objectPtr;
    weight->objectAllocFlg = objectAllocFlg;
    weight->objectHistPtr = objectHistPtr;
    weight->objectHistAllocFlg = objectHistAllocFlg;
    weight->parentWeightPtr = (FIN_WEIGHT_STP) NULL;
    weight->childNbr = 0;
	
	/* REF9071 - RAK - 030819 */
	/* change FIN_WEIGHT_STP childWeightTab in FIN_WEIGHT_STP* to allow good storage in parentWeightPtr */
    weight->childWeightTab = (FIN_WEIGHT_STP *) NULL;
    
	weight->eltTab=NULL;
    weight->eltTabAllocFlg = FALSE;
    weight->periodReturn = 0;
    weight->weightValue=1;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_FreeWeightTab()
**
**  Description :  Free all structure used to store weights.
**                 
**  Arguments   :  weightHead     header of structure used to store weights
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010116 - DDV
**  Modif.      :  
**
*************************************************************************/
STATIC RET_CODE FIN_FreeWeightTab(FIN_WEIGHTHEAD_STP weightHead)
{
    if (weightHead->firstWeight != (FIN_WEIGHT_STP) NULL)
    {
        FIN_FreeWeight(&(weightHead->firstWeight));
		/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
		/* so free of each weight is added in function FIN_FreeWeight() and firstWeight is already freed */
        /* FREE(weightHead->firstWeight); */
    }

    weightHead->initialWeightFlg=FALSE;
    weightHead->beginDate.date=0;
    weightHead->beginDate.time=0;
    weightHead->endDate.date=0;
    weightHead->endDate.time=0;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_FreeWeight()
**
**  Description :  Free a structure used to store one weight and all his children.
**                 
**  Arguments   :  weight     pointer of weight to free
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010116 - DDV
**  Modif.      :  
**
*************************************************************************/
STATIC RET_CODE FIN_FreeWeight(FIN_WEIGHT_STP *weightPtr)
{
    int i=0, j=0;
    FIN_WEIGHT_STP weight = *weightPtr; /* REF9303 - LJE - 030911 */

    /* Free all children */
    if (weight->childWeightTab != (FIN_WEIGHT_STP *) NULL)
    {
        for (i=0; i<weight->childNbr; i++)
			/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
            /* FIN_FreeWeight(&(weight->childWeightTab[i])); */
			FIN_FreeWeight(&(weight->childWeightTab[i]));	

        FREE(weight->childWeightTab);
    }
	
    /* REF8844 - LJE - 030415 */
    if (weight->objectEnum == Instr)
    {

        if (weight->objectAllocFlg == TRUE)
            FREE_DYNST(weight->objectPtr, A_Instr);

        if (weight->eltTabAllocFlg == TRUE)
        {
            for (j=0; j<weight->childNbr; j++)
                FREE_DYNST(weight->eltTab[j], A_InstrCompo);
        }
        FREE(weight->eltTab); /* REF8712 - LJE - 031017 */
        
    }
    else if (weight->objectEnum == Strat)
    {

        if (weight->objectAllocFlg == TRUE)
            FREE_DYNST(weight->objectPtr, A_Strat);
        if (weight->objectHistAllocFlg == TRUE)
            FREE_DYNST(weight->objectHistPtr, A_StratHist);
        if (weight->eltTabAllocFlg == TRUE)
        {
            for (j=0; j<weight->childNbr; j++)
                FREE_DYNST(weight->eltTab[j], A_StratElt);
        }
        FREE(weight->eltTab); /* REF8712 - LJE - 031017 */
        
    }

	/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* and each element is allocated */
	FREE((*weightPtr));

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_AddChildWeight()
**
**  Description :  Add a new child weight.
**                 
**  Arguments   :  currentWeight
**                 objectEnum         objectEnum of object (Instr or Strat)
**                 objectId           id of object
**                 objectPtr          pointer on object
**                 objectAllocFlg     flag to indicate if pointer of object must be free
**                 objectHistPtr      pointer of current history of object (used only for strategy)
**                 objectHistAllocFlg flag to indicate if pointer of object history must be free
**                 eltPtr             pointer on element associated to new child (A_StratElt for Strat and A_InstrCompo for Instr)
**                 eltAllocFlg        flag to indicate if elements must be free
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010116 - DDV
**  Modif.      :  REF6025 - CSY - 010719: DerivedStrat 
**
*************************************************************************/
STATIC RET_CODE FIN_AddChildWeight(FIN_WEIGHT_STP     currentWeight,
                                   OBJECT_ENUM        objectEnum,
                                   ID_T               objectId,
                                   DBA_DYNFLD_STP     objectPtr,
                                   FLAG_T             objectAllocFlg,
                                   DBA_DYNFLD_STP     objectHistPtr,
                                   FLAG_T             objectHistAllocFlg,
                                   DBA_DYNFLD_STP     eltPtr,
                                   FLAG_T             eltAllocFlg)
{
    int            allocSz=8;
    FIN_WEIGHT_STP childWeight=NULL;
    FIN_WEIGHT_STP parentWeight = currentWeight->parentWeightPtr;
    FLAG_T         loopFlg = FALSE;
		
    /* check that object is not parent or grandparents to avoid loop */
    parentWeight = currentWeight;
    while (parentWeight != NULL && loopFlg != TRUE)
    {
        if (objectEnum == parentWeight->objectEnum &&
            objectId == parentWeight->objectId)
            loopFlg = TRUE;
        parentWeight = parentWeight->parentWeightPtr;
    }

    if (loopFlg == TRUE)
    {
        /* REF8844 - LJE - 030415 */
        if (objectEnum == Instr)
        {

            MSG_SendMesg(RET_FIN_ERR_CHECKPARENTS, 1, FILEINFO, GET_CODE(objectPtr, A_Instr_Cd));  
            
        }
        else if (objectEnum == Strat)
        {

            MSG_SendMesg(RET_FIN_ERR_CHECKPARENTS, 1, FILEINFO, GET_CODE(objectPtr, A_Strat_Cd));
            
        }
        else if (objectEnum == DerivedStrat)
        {

            MSG_SendMesg(RET_FIN_ERR_CHECKPARENTS, 1, FILEINFO, " derived strategy");   /* there is no field for code in A_DerivedStrat */
            
        }

        return(RET_FIN_ERR_CHECKPARENTS);
    }

	
    if (currentWeight->childNbr % allocSz == 0)
    {
		/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
        /* currentWeight->childWeightTab = (FIN_WEIGHT_ST *) REALLOC(currentWeight->childWeightTab, (currentWeight->childNbr+allocSz) * sizeof(FIN_WEIGHT_ST));
        if (currentWeight->childWeightTab == (FIN_WEIGHT_ST *) NULL)
        {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
        }
		*/
		currentWeight->childWeightTab = (FIN_WEIGHT_STP *) REALLOC(currentWeight->childWeightTab, (currentWeight->childNbr+allocSz) * sizeof(FIN_WEIGHT_STP));
        if (currentWeight->childWeightTab == (FIN_WEIGHT_STP *) NULL)
        {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
        }

        currentWeight->eltTab = (DBA_DYNFLD_STP *) REALLOC(currentWeight->eltTab, (currentWeight->childNbr+allocSz) * sizeof(DBA_DYNFLD_STP));
        if (currentWeight->eltTab == (DBA_DYNFLD_STP *) NULL)
        {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
        }
    }

    currentWeight->eltTab[currentWeight->childNbr] = eltPtr;
    currentWeight->eltTabAllocFlg=eltAllocFlg;

	/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
	/* childWeight = &(currentWeight->childWeightTab[currentWeight->childNbr]); */

	/* so we have to allacate each FIN_WEIGHT_ST */
	if ((currentWeight->childWeightTab[currentWeight->childNbr] = (FIN_WEIGHT_STP) CALLOC(1, sizeof(FIN_WEIGHT_ST))) == (FIN_WEIGHT_STP) NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}
	childWeight = currentWeight->childWeightTab[currentWeight->childNbr];
    
    currentWeight->childNbr++;

    childWeight->objectEnum = objectEnum;
    childWeight->objectId = objectId;
    childWeight->objectPtr = objectPtr;
    childWeight->objectAllocFlg = objectAllocFlg;
    childWeight->objectHistPtr = objectHistPtr;
    childWeight->objectHistAllocFlg = objectHistAllocFlg;
    childWeight->parentWeightPtr = currentWeight;
    childWeight->childNbr = 0;
	/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
    childWeight->childWeightTab = (FIN_WEIGHT_STP *) NULL;

    childWeight->eltTab=NULL;
    childWeight->eltTabAllocFlg = FALSE;
    childWeight->periodReturn = 0;

    /* REF8844 - LJE - 030415 */
    if (currentWeight->objectEnum == Instr)
    {

        childWeight->weightValue = GET_NUMBER(eltPtr, A_InstrCompo_Quantity)/100;
        
    }
    else if (currentWeight->objectEnum == Strat)
    {

        childWeight->weightValue = GET_NUMBER(eltPtr, A_StratElt_Value)/100;
        
    }
    else if (currentWeight->objectEnum == DerivedStrat)
    {

        childWeight->weightValue = GET_NUMBER(eltPtr, A_DerivedStratElt_Weight)/100;
        
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_SearchWeight()
**
**  Description :  search a weight value in a weight structure
**                 
**  Arguments   :  weight      weight inside which we search the element
**                 objectEnum         objectEnum of currentWeight (Instr or Strat)
**                 elementId          id of the element that we are looking for
**                 adjWeight          weight of the element
**                 
**
**  Return      :  
**
**  Creation    :  REF6025 - 010530 - CSY
**  Modif.      :  
**
*************************************************************************/
STATIC RET_CODE FIN_SearchWeight(FIN_WEIGHT_STP     weight,
                                   ID_T             elemtId,
                                   FLAG_T*          foundFlg,
                                   double*          adjWeight)
{
    int i = 0;
    RET_CODE ret = RET_SUCCEED;

    if (weight->parentWeightPtr != NULL) 
    {
        if ((weight->objectEnum == Instr &&
            weight->parentWeightPtr->objectEnum == Instr &&
            weight->objectId ==  elemtId)
                ||
                (weight->objectEnum == Instr &&
            weight->parentWeightPtr->objectEnum == Strat &&
            weight->objectId ==  elemtId)   /* is elemtId an instr id ? */
                ||
                (weight->objectEnum == Strat &&
                weight->parentWeightPtr->objectEnum == Strat &&
                weight->objectPtr != NULL &&
                (elemtId == GET_ID(weight->objectPtr, A_Strat_Id)))
                )
        {
        
            *foundFlg = TRUE;
            *adjWeight = weight->weightValue;
            return(RET_SUCCEED);
        }

        if (weight->objectEnum == Instr &&
            weight->parentWeightPtr->objectEnum == Strat && weight->objectId !=  elemtId)
        {
            /*  is elemtId a market segment id ? */
            int j = 0;
            while (j < weight->parentWeightPtr->childNbr)
            {
				/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
				/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                if (elemtId == (GET_ID(weight->parentWeightPtr->eltTab[j], A_StratElt_MktSegtId))
                    &&
                    weight->objectId == weight->parentWeightPtr->childWeightTab[j]->objectId)
                {
                    *foundFlg = TRUE;
                    *adjWeight = weight->weightValue;
                    return(RET_SUCCEED);
                }
                j++;
            }
        }
        
    }

    if (weight->childNbr > 0)
    {
		/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
        if (weight->childWeightTab != (FIN_WEIGHT_STP*) NULL)
        {       
            for (i=0; i<weight->childNbr; i++)
            {
                if ((ret = FIN_SearchWeight(weight->childWeightTab[i], elemtId, foundFlg, adjWeight)) 
                    != RET_SUCCEED)
                {
                    return (ret);
                }

                if ((*foundFlg) == TRUE)
                    break;
            }
        }
    }
    
    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_InitReturnParam()
**
**  Description :  put the received arguments in a structure. Avoids too much parameters
**                 in functions using these arguments, by passing only a pointer to a structure.
**                 
**  Arguments   :  currId		      currency id
**                 returnTpEn	      
**                 returnNatEn, 
**	               capGainTax
**		           incGainTax
**		           taxAccrInterFlg
**				   rebalRule
**                 contribObjectId
**                 contribRule
**                 priceValRuleId
**                 exchValRuleId
**
**  Return      :  RET_CODE
**  Creation    :  REF6025 - CSY - 010613
**  Modif.      :  
**
*************************************************************************/
RET_CODE    FIN_InitReturnParam(ID_T                    currId, 
                                        RETURNTP_ENUM           returnTpEn, 
                                        RETURNNAT_ENUM          returnNatEn, 
                                        NUMBER_T                capGainTax, 
                                        NUMBER_T                incGainTax, 
                                        FLAG_T                  taxAccrInterFlg,
                                        PORTPLCOMPRULE_ENUM     PlCompRuleEn,
                                        FIN_RETURNPARAM_STP     returnParam
                                        )
{
    RET_CODE ret = RET_SUCCEED;
    returnParam->capGainTax = capGainTax;
    returnParam->currId = currId;
    returnParam->incGainTax = incGainTax;
    returnParam->returnNatEn = (RETURNNAT_ENUM)returnNatEn;
    returnParam->returnTpEn = (RETURNTP_ENUM)returnTpEn;
    returnParam->taxAccrInterFlg = taxAccrInterFlg;
    returnParam->PlCompRuleEn = PlCompRuleEn;
    return (ret);
}



/************************************************************************
**
**  Function    :  FIN_UnrealPL()
**
**  Description :  Computes profit and loss for received position.
**                 
**  Arguments   :  pos		      position
**                 PLNatEn	      P&L nature (total, capital, currency)
**                 grossPLFlg	  gross or net P&L
**		           portPLCompRule indicates how to post the currency gains on the capital gains
**		           currPLCompRule indicates whether the capital gain is computed in the 
**				                  instrument currency or the position currency
**
**  Return      :  desired amount expressed in the "reference currency" of the position
**
**  Creation    :  DVP186 - RAK - 960828 
**  Modif.      :  BUG138 - RAK - 960826 
**                 
**
*************************************************************************/
double FIN_UnrealPL(DBA_DYNFLD_STP      pos,
		            PLNAT_ENUM          PLNatEn,
		            char	  	        grossPLFlg,
		            PORTPLCOMPRULE_ENUM *portPLCompRulePtr,
		            CURRPLCOMPRULE_ENUM *currPLCompRulePtr)
{
	FIN_PL_ST           PLSt;
	DBA_DYNFLD_STP      valo=NULLDYNST;
	PORTPLCOMPRULE_ENUM portPLCompRule=PortPlCompRule_Dflt;     /* REF7264 - RAK - 020307 */ 
	CURRPLCOMPRULE_ENUM currPLCompRule=CurrPlCompRule_Instr;    /* REF7264 - RAK - 020307 */  
    RET_CODE            ret;

	/* BUG138 - No P&L on balance positions */
	if (IS_NULLFLD(pos, ExtPos_BalPosTpId) == FALSE)
		return(0.0);

	valo = NULLDYNST;
	if (GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext) == NULL ||
            (valo = *(GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext))) == NULLDYNST)
	{
	    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_UnrealPL", ExtPos_PosVal_Ext);
		return(0.0);
	}

    /* Portfolio P&L computation rule */
	if (portPLCompRulePtr == NULL)
        GEN_GetApplInfo(ApplPortPlCompRule, &portPLCompRule);
	else
	    portPLCompRule = *portPLCompRulePtr;

    /* Currency P&L computation rule */
	if (currPLCompRulePtr == NULL)
    {
        /* Currency P&L computation rule */     /* REF4347 - 001124 - DED */
        if ((ret=GEN_GetCurrPlCompRule(GET_ID(pos, ExtPos_PtfId),
                                       NULLDYNST,
                                       GET_ID(pos, ExtPos_PtfPosSetId),
                                       NULLDYNST,
                                       (PTR)NULL,
                                       UNUSED,
                                       UNUSED,
                                       LogicIdRule_NoValue,
                                       &currPLCompRule)) != RET_SUCCEED)
        {
            return(0.0);
        }
    }
	else
    {
	    currPLCompRule = *currPLCompRulePtr;
    }

	FIN_CalcUnrealPL(pos, valo, portPLCompRule, currPLCompRule, GET_ID(pos, ExtPos_RefCurrId), PLNatEn, &PLSt);

	switch (PLNatEn)
	{
	case PL_Total :
	    if (grossPLFlg == TRUE)
			return(PLSt.grossTot);	/* return gross total */
		else
			return(PLSt.netTot);	/* return net total */
		break;

	case PL_Capital :
	    if (grossPLFlg == TRUE)
			return(PLSt.grossCap);	/* return gross capital */
		else
			return(PLSt.netCap);	/* return net capital */
		break;

	case PL_Currency :
	    if (grossPLFlg == TRUE)
			return(PLSt.grossCurr);	/* return gross currency */
		else
			return(PLSt.netCurr);	/* return net currency */
		break;
	}
	return(0.0);
}

/************************************************************************
**
**  Function    :  FIN_CalcUnrealPL()
**
**  Description :  Computes profit and loss for received position.
**                 
**  Arguments   :  pos		      position
**                 valo           position valorisation
**		           portPLCompRule indicates how to post the currency gains on the capital gains
**		           currPLCompRule indicates whether the capital gain is computed in the 
**				                  instrument currency or the position currency
**                 currId         reference currency
**                 PLNatEn	      P&L nature (total, capital, currency)
**                 PLStp	      P&L structure pointer
**
**  Return      :  none, PLStp is filled
**
**  Creation    :  DVP186 - RAK - 960828 
**
**  Modif.      :  REF806 - RAK - 971029 
**                 PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
void FIN_CalcUnrealPL(DBA_DYNFLD_STP      pos,
		              DBA_DYNFLD_STP      valo,
		              PORTPLCOMPRULE_ENUM portPLCompRule, 
		              CURRPLCOMPRULE_ENUM currPLCompRule, 
		              ID_T                currId,
		              PLNAT_ENUM          PLNatEn,
		              FIN_PL_STP	      PLStp)
{
	AMOUNT_T		PL;
	DBA_DYNFLD_STP	instrPtr=NULLDYNST, underlyInstrPtr=NULLDYNST;
	ID_T			underlyInstrId;
	INSTRNAT_ENUM	instrNat, underlayInstrNat;
	FLAG_T			allocInstrFlg=FALSE, allocUnderFlg=FALSE, noCapPLFlg=FALSE;			/* PMSTA01710 - RAK - 070411 */

	PLStp->netTot = CAST_AMOUNT(GET_AMOUNT(valo, PosVal_RefNetAmt) -
	                            GET_AMOUNT(pos, ExtPos_RefNetAmt), currId); 

	PLStp->grossTot = CAST_AMOUNT(GET_AMOUNT(valo, PosVal_RefNetAmt) -
			                      GET_AMOUNT(pos, ExtPos_RefGrossAmt), currId);

	if (PLNatEn == PL_Total)
		return;

	/* -------------------------------- */
	/*** NET CAPITAL AND CURRENCY P&L ***/
	/* -------------------------------- */

	/*	PRS-FPL-PMSTA09546-110808 sometime we could have negative id for instrument, so DBA_GetInstrById not work for everz cases	*/
	if (IS_NULLFLD(pos, ExtPos_A_Instr_Ext) == FALSE)
	{
		instrPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext));
	}
	else
	{
		/* PMSTA01710 - RAK - 070411 - No capital P&L for forward and for currency options */
		if (DBA_GetInstrById(GET_ID(pos, ExtPos_InstrId), FALSE, &allocInstrFlg, 
							 &instrPtr, NULL, UNUSED, UNUSED) != RET_SUCCEED)
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(pos, ExtPos_InstrId));
			return;
		}
	}

   	instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);

	if (instrNat == InstrNat_Option)
	{		 
		if ((underlyInstrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId)) != ZERO_ID) /* PMSTA-17133 - 051113 - PMO */
		{
			if (DBA_GetInstrById(underlyInstrId, FALSE, &allocUnderFlg, 
                          &underlyInstrPtr, NULL, UNUSED, UNUSED) != RET_SUCCEED)
			{
				MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(pos, ExtPos_InstrId));
				if (allocInstrFlg == TRUE)
				{ FREE_DYNST(instrPtr, A_Instr); }
				return;
			}
			underlayInstrNat = (INSTRNAT_ENUM)GET_ENUM(underlyInstrPtr, A_Instr_NatEn);
			if ( underlayInstrNat == InstrNat_CashAcct && underlyInstrId != GET_ID(instrPtr, A_Instr_RefCurrId))
			{
				noCapPLFlg = TRUE; 
			}

		
		}
	}
	else if (/* GET_FLAG(pos, ExtPos_MainFlg) == TRUE && WEALTH-551 - DDV - 230614 - No Cap PL for all Fwd pos, no only main ones */
	         (GET_ENUM(pos, ExtPos_RefNatEn) == PosRefNat_FwdOpen || 
	          GET_ENUM(pos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
	{
		noCapPLFlg = TRUE; 
	}

	if (allocInstrFlg == TRUE)
	{ FREE_DYNST(instrPtr, A_Instr); }

	if (allocUnderFlg == TRUE)
	{ FREE_DYNST(underlyInstrPtr, A_Instr); }

	if (noCapPLFlg == TRUE)
	{
		PL = 0.0;
	}
	else
	{
		/* Unrealised net capital P&L */
		PL = FIN_CalcCapPL(pos, valo, portPLCompRule, currPLCompRule, PL_NetCap, currId);
		
	}

	PLStp->netCap = PL;

	/* Unrealised net currency P&L */
	PLStp->netCurr = CAST_AMOUNT(PLStp->netTot - PL, currId); 

	/* ---------------------------------- */
	/*** GROSS CAPITAL AND CURRENCY P&L ***/
	/* ---------------------------------- */

	if (noCapPLFlg == TRUE)
	{
		PL = 0.0;
	}
	else
	{
		/* Unrealised gross capital P&L */
		PL = FIN_CalcCapPL(pos, valo, portPLCompRule, currPLCompRule, PL_GrossCap, currId);
	}
	PLStp->grossCap = PL;

	/* Unrealised gross currency P&L */
	PLStp->grossCurr = CAST_AMOUNT(PLStp->grossTot - PL, currId);	    
 
	return;
}

/************************************************************************
**
**  Function    :  FIN_CalcCapPL()
**
**  Description :  Compute asked capital P&L
**                 
**  Arguments   :  portPLCompRule indicates how to post the currency gains on 
**                                the capital gains
**		   currPLCompRule indicates whether the capital gain is computed in the 
**				  instrument currency or the position currency
**		   PLTp 	  P&L type (net or gross)
**                 currId         P&L reference currency
**
**  Return      :  calculated P&L
**
**  Creation    :  DVP186 - RAK - 960828 
**  Modif       :  BUG117 - RAK - 960902 
**
*************************************************************************/
STATIC AMOUNT_T FIN_CalcCapPL(DBA_DYNFLD_STP      pos,
		                      DBA_DYNFLD_STP      valo,
		                      PORTPLCOMPRULE_ENUM portPLCompRule, 
		                      CURRPLCOMPRULE_ENUM currPLCompRule, 
		                      PLTP_ENUM           PLTp,
		                      ID_T                currId)
{
	AMOUNT_T PL=0.0;

	switch (currPLCompRule)
	{
	/* profit computed according to instrument currency */
	case CurrPlCompRule_Instr :

	    switch (portPLCompRule)
	    {
	    case PortPlCompRule_Init :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_InstrNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_InstrCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) * 
			              GET_AMOUNT(pos, ExtPos_RefNetAmt) / 
			              GET_AMOUNT(pos, ExtPos_InstrNetAmt)) -
			              GET_AMOUNT(pos, ExtPos_RefNetAmt);
		        }
		        else
		        {
		    	    PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) *
			              GET_EXCHANGE(pos, ExtPos_InstrExchRate)) -
		                  GET_AMOUNT(pos, ExtPos_RefNetAmt);
		        }
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_InstrNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_InstrCurrId)) != 0)
		        {
		    	    PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) *
			              GET_AMOUNT(pos, ExtPos_RefNetAmt) /
			              GET_AMOUNT(pos, ExtPos_InstrNetAmt)) -
			              GET_AMOUNT(pos, ExtPos_RefGrossAmt);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) *
			              GET_EXCHANGE(pos, ExtPos_InstrExchRate)) -
		                  GET_AMOUNT(pos, ExtPos_RefGrossAmt);
		        }
		    }
		    break;

	    case PortPlCompRule_Final :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
		        PL = GET_AMOUNT(valo, PosVal_RefNetAmt) -
		             (GET_AMOUNT(pos, ExtPos_InstrNetAmt) * 
		             GET_EXCHANGE(valo, PosVal_InstrExchRate));
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
		        PL = GET_AMOUNT(valo, PosVal_RefNetAmt) -
		             (GET_AMOUNT(pos, ExtPos_InstrGrossAmt) *
		             GET_EXCHANGE(valo, PosVal_InstrExchRate));
		    }
		    break;

	    /* BUG117 - ExtPos_InstrExchRate -> PosVal_InstrExchRate */
	    case PortPlCompRule_Mean :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_InstrNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_InstrCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) -
			             GET_AMOUNT(pos, ExtPos_InstrNetAmt)) *
			             (((GET_AMOUNT(pos, ExtPos_RefNetAmt) /
			             GET_AMOUNT(pos, ExtPos_InstrNetAmt)) +
			             GET_EXCHANGE(valo, PosVal_InstrExchRate)) / 2);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) -
		                 GET_AMOUNT(pos, ExtPos_InstrNetAmt)) *
			             ((GET_EXCHANGE(pos, ExtPos_InstrExchRate) +
			             GET_EXCHANGE(valo, PosVal_InstrExchRate)) / 2);
		        }
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_InstrNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_InstrCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) -
			             GET_AMOUNT(pos, ExtPos_InstrGrossAmt)) *
			             (((GET_AMOUNT(pos, ExtPos_RefNetAmt) /
			             GET_AMOUNT(pos, ExtPos_InstrNetAmt)) +
			             GET_EXCHANGE(valo, PosVal_InstrExchRate)) / 2);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_InstrNetAmt) -
			             GET_AMOUNT(pos, ExtPos_InstrGrossAmt)) *
			             ((GET_EXCHANGE(pos, ExtPos_InstrExchRate) +
			             GET_EXCHANGE(valo, PosVal_InstrExchRate)) / 2);
		        }
		    }
	    	break;
	    }
	    break;

	/* profit computed according to position currency */
	case CurrPlCompRule_Pos :

	    switch (portPLCompRule)
	    {
	    case PortPlCompRule_Init :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_PosNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_PosCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) * 
			             GET_AMOUNT(pos, ExtPos_RefNetAmt) / 
			             GET_AMOUNT(pos, ExtPos_PosNetAmt)) -
		                 GET_AMOUNT(pos, ExtPos_RefNetAmt);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) *
			             GET_EXCHANGE(pos, ExtPos_PosExchRate)) -
		                 GET_AMOUNT(pos, ExtPos_RefNetAmt);
		        }
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_PosNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_PosCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) * 
			             GET_AMOUNT(pos, ExtPos_RefGrossAmt) /
			             GET_AMOUNT(pos, ExtPos_PosGrossAmt)) -
		                 GET_AMOUNT(pos, ExtPos_RefGrossAmt);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) *
			             GET_EXCHANGE(pos, ExtPos_PosExchRate)) -
		                 GET_AMOUNT(pos, ExtPos_RefGrossAmt);
		        }
		    }
		    break;

	    case PortPlCompRule_Final :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
		        PL = GET_AMOUNT(valo, PosVal_RefNetAmt) -
		             (GET_AMOUNT(pos, ExtPos_PosNetAmt) * 
		             GET_EXCHANGE(valo, PosVal_PosExchRate));
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
		        PL = GET_AMOUNT(valo, PosVal_RefNetAmt) -
		             (GET_AMOUNT(pos, ExtPos_PosGrossAmt) *
			         GET_EXCHANGE(valo, PosVal_PosExchRate));
		    }
		    break;

	    /* BUG117 - ExtPos_PosExchRate -> PosVal_PosExchRate */
	    case PortPlCompRule_Mean :
		    if (PLTp == PL_NetCap)
		    {
		        /*** Unrealised net capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_PosNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_PosCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) -
		                 GET_AMOUNT(pos, ExtPos_PosNetAmt)) *
			             (((GET_AMOUNT(pos, ExtPos_RefNetAmt) /
			             GET_AMOUNT(pos, ExtPos_PosNetAmt)) +
			        GET_EXCHANGE(valo, PosVal_PosExchRate)) / 2);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) -
		                 GET_AMOUNT(pos, ExtPos_PosNetAmt)) *
			             ((GET_EXCHANGE(pos, ExtPos_PosExchRate) +
			             GET_EXCHANGE(valo, PosVal_PosExchRate)) / 2);
		        }
		    }
		    else
		    {
		        /*** Unrealised gross capital P&L ***/
	    	    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_PosNetAmt), 0.0,
		                       GET_ID(pos, ExtPos_PosCurrId)) != 0)
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) -
		                 GET_AMOUNT(pos, ExtPos_PosGrossAmt)) *
			             (((GET_AMOUNT(pos, ExtPos_RefNetAmt) /
			             GET_AMOUNT(pos, ExtPos_PosNetAmt)) +
			             GET_EXCHANGE(valo, PosVal_PosExchRate)) / 2);
		        }
		        else
		        {
		            PL = (GET_AMOUNT(valo, PosVal_PosNetAmt) -
		                  GET_AMOUNT(pos, ExtPos_PosGrossAmt)) *
			             ((GET_EXCHANGE(pos, ExtPos_PosExchRate) +
			               GET_EXCHANGE(valo, PosVal_PosExchRate)) / 2);
		        }
		    }
		    break;
	    }
	    break;
	}

	PL = CAST_AMOUNT(PL, currId);
	return(PL);
}

/************************************************************************
**
**  Function    :  FIN_SelectPtfSynth()
**
**  Description :  Select portfolio synthetic data depending on received 
**                 flags and date. Fill portfolio synthetic data array.
**                 
**  Arguments   :  fromDate        date from which the computation is done
**                 tillDate        date until which the computation is done
**                 riskFlg         indicates whether risk amounts are used for
**                                 the computation.
**                 ptfId           current portfolio identifier
**                 mktSgtId        current market segment identifier
**                 posHierHeadPtr  pointer on hierarchy header
**                 ptfSynthNbrPtr  pointer on portfolio synthetic data number
**                 ptfSynthPtr     pointer on portfolio synthetic data array
**
**  Return      :  RET_SUCCEED or error code, 
**                 ptfSynthNbrPtr and extrPtfSynthPtr are filled
**
**  Creation    :  DVP004 - RAK - 960305 
**
**  Modif       :  DVP165 - RAK - 960730 
**  Modif       :  DVP232 - RAK - 961120
**  Modif       :  REF385 - GRD - 970925
**  Modif       :  REF1458 - RAK - 980318
**  Modif       :  REF4263 - CSY - 000128: manage synthetic datas generated 
**                                         by SEL_SYNTH keyword
**                 REF4263 - CSY - 000210: refilter selected synthetics on dates.
**                 REF5313 - CSY - 001017 : add index on ptfId
**
*************************************************************************/
STATIC RET_CODE FIN_SelectPtfSynth(DATETIME_T         fromDate,
			                        DATETIME_T        tillDate,
			                        FLAG_T            riskFlg,
				                    ID_T              ptfId,
				                    ID_T              gridId,	/* DVP232 - RAK - 961120 */
				                    ID_T              mktSgtId,	/* DVP232 - RAK - 961112 */
				                    ID_T              instrId, 	/* DVP165 - RAK - 960730 */
                                    ID_T              pspId,    /* REF9264 - LJE - 031021 */
                                    DBA_DYNFLD_STP    selSynthPtr, /* REF4263 - CSY - 000128 */
			                        DBA_HIER_HEAD_STP synthHierHead, 
				                    DBA_DYNFLD_STP    crtRecPtr,
                                    /* REF3621 - RAK - 990715 */
                                    FLAG_T *           freeFlg, /* REF4263 - CSY - 000211 */
		                            int               *ptfSynthNbrPtr, 
			                        DBA_DYNFLD_STP    **ptfSynthPtr) 
{
	RET_CODE		ret= RET_SUCCEED;
	DBA_DYNFLD_STP	argPtr=NULLDYNST;
	int			    indexFld;
	DBA_DYNFLD_ST 	idDynSt;
    DBA_DYNFLD_STP  domainPtr=NULLDYNST;
    int             i, tmpNbr;    /* REF4263 - CSY - 000210 */
    DBA_DYNFLD_STP  *tmpArray;
    *freeFlg = TRUE;  /* REF4263 - CSY - 000210 */

	*ptfSynthNbrPtr = 0;
    *ptfSynthPtr = NULL;
    

	/*** VERIFY INPUT ARGUMENTS ***/
	if (fromDate.date == BAD_DATE)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_SelectPtfSynth", "from date");
	    return(RET_GEN_ERR_INVARG);
	}

	if (tillDate.date == BAD_DATE)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_SelectPtfSynth", "till date");
	    return(RET_GEN_ERR_INVARG);
	}

	/* BUG037 - RAK - 960614 */
	if (tillDate.date < fromDate.date)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			 "FIN_SelectPtfSynth", "till date before from date");
	    return(RET_GEN_ERR_INVARG);
	}
	

    /* REF4263 - CSY - 000128 */
    if (selSynthPtr != NULLDYNST)		/* A v�rifier ... */
    {
        if (IS_NULLFLD(selSynthPtr, A_Array_Ptr) == FALSE) /* PMSTA14453 - DDV - 120705 - Array definition not clean */
        {
            /* we are in a SEL_SYNTH context */
            
            /* 
            REF4263 - CSY - 000210: need to refilter array of synthetics
            to keep only the relevant ones  (based on return/mean cap dates arguments) */
            
            tmpArray = (DBA_DYNFLD_STP *)GET_ARRAY_PTR(selSynthPtr, A_Array_Ptr); /* REF7264 - LJE - 020131 */ /* PMSTA14453 - DDV - 120705 - Array definition not clean */
            tmpNbr = GET_ARRAY_ELTNBR(selSynthPtr, A_Array_Ptr); /* PMSTA14453 - DDV - 120705 - Array definition not clean */
            for (i=0; i< tmpNbr; i++)
            {
                if (DATETIME_CMP(GET_DATETIME(
                        (tmpArray)[i],A_PtfSynth_InitialDate), fromDate) >= 0 &&
                    DATETIME_CMP(GET_DATETIME(
                        (tmpArray)[i],A_PtfSynth_FinalDate), tillDate) <= 0)
                {
                    if (*ptfSynthPtr == NULL)
                        (*ptfSynthPtr) = &(tmpArray[i]);
                    (*ptfSynthNbrPtr)++;
                }
            }
            *freeFlg = FALSE;
	        return(RET_SUCCEED);
        }
        else
        {
            (*ptfSynthPtr) = NULLDYNSTPTR;
            (*ptfSynthNbrPtr) = 0;
             MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			              "FIN_SelectPtfSynth", "no synthetic data created by SEL_SYNTH()");
	        return(RET_GEN_ERR_INVARG);
        }
    }
    else

        /*
	     * REF385, Calls to hierarchy is now optimized.
	     *         Should improve the return function.
	     */
    {
        if ((argPtr = ALLOC_DYNST(MeanCapReturn_Arg)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    /* REF4159 - memory size - RAK - 991124 */
	    /* if ((ptfRetPtr = ALLOC_DYNST(Array)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    FREE_DYNST(argPtr, MeanCapReturn_Arg);
		    return(RET_MEM_ERR_ALLOC);
	    } */

        SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate,         fromDate);
        SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate,         tillDate);
        SET_FLAG(argPtr,     MeanCapReturn_Arg_RiskFlg,          riskFlg);
        SET_ID(argPtr,       MeanCapReturn_Arg_PtfId,            ptfId);
        SET_ID(argPtr,       MeanCapReturn_Arg_GridId,           gridId);
        SET_ID(argPtr,       MeanCapReturn_Arg_MktSgtId,         mktSgtId);
        SET_ID(argPtr,       MeanCapReturn_Arg_InstrId,          instrId);
        SET_ID(argPtr,       MeanCapReturn_Arg_PSPId,            pspId); /* REF9264 - LJE - 031021 */

	    /* REF4159 - memory size - RAK - 991124 */
	    /* if (DBA_GetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, argPtr, Array, 
			      ptfRetPtr, (DBA_DYNFLD_STP *) NULL, Opti_Local) == RET_SUCCEED)
	    {
		    FREE_DYNST(argPtr, MeanCapReturn_Arg);
		    *ptfSynthNbrPtr = GET_ARRAY_ELTNBR(ptfRetPtr, Array_Ptr);
		    *ptfSynthPtr = GET_ARRAY_PTR(ptfRetPtr, Array_Ptr);
		    if (*ptfSynthNbrPtr == 0)	
			    ret = RET_FIN_ERR_INVDATA;
		    else
			    ret = RET_SUCCEED;
		    return(ret);
	    } */

	    /* Data is not yet optimized. */

	    /* Verify if asked record is current record, if period is bigger call Extract */
	    if ((GET_BIT((MASK_T)GET_TINYINT(crtRecPtr, A_PtfSynth_Level), SynthLevel_Primary) == TRUE || /* REF7634 - LJE - 020613 */
			 GET_TINYINT(crtRecPtr, A_PtfSynth_Level) == 0) &&  /* REF7634 - LJE - 020621 */
			DATETIME_CMP(GET_DATETIME(crtRecPtr, A_PtfSynth_InitialDate), fromDate) == 0 && 
	        DATETIME_CMP(GET_DATETIME(crtRecPtr, A_PtfSynth_FinalDate),   tillDate) == 0)
	    {
	        *ptfSynthNbrPtr = 1;
	        if (((*ptfSynthPtr) = (DBA_DYNFLD_STP *)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR) /* REF7264 - LJE - 020131 */
	        {
		        *ptfSynthNbrPtr = 0;
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        (*ptfSynthPtr)[0] = crtRecPtr;
	    }
	    else
	    {
	        /*** EXTRACT PORTFOLIO SYNTHETIC DATA ***/
	        /* REF3621 - Use index depending on detail level         */
	        /* - if instrId is received, use A_PtfSynth_InstrId,     */
	        /* - if mktSgttId is received, use A_PtfSynth_MktSegtId. */
	        indexFld = -1;
            memset(&idDynSt, 0, sizeof(DBA_DYNFLD_ST));

            if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(synthHierHead))) != NULLDYNST) 
		    {
			    if ((PTFRETDETLVL_ENUM) GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument)
			    {
				    indexFld = A_PtfSynth_InstrId;
                    if (instrId != 0)   /* No global data */
                    { SET_ID((&idDynSt), 0, instrId); }
			    }
			    else if ((PTFRETDETLVL_ENUM)GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
                         GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE)
			    {
				    indexFld = A_PtfSynth_MktSegtId;
                    if (mktSgtId != 0)  /* No global data */
                    { SET_ID((&idDynSt), 0, mktSgtId); }
			    }
		    }

            /* If domain isn't availabe but instrument or market segment is received, use index */
            if (indexFld == -1) 
            {
	            if (instrId != 0)
	            {
		            indexFld = A_PtfSynth_InstrId;
		            SET_ID((&idDynSt), 0, instrId);
	            }
	            else if (mktSgtId != 0)
	            {
		            indexFld = A_PtfSynth_MktSegtId;
		            SET_ID((&idDynSt), 0, mktSgtId);
	            }
                else /* REF5313 - CSY - 001017: index on PtfId */ /* REF11193 - LJE - 050512 : on MktSegt */
                {
                	/*
                    indexFld = A_PtfSynth_PtfId;
		            SET_ID((&idDynSt), 0, ptfId);
		            */
                    
		            indexFld = A_PtfSynth_MktSegtId;
		            SET_ID((&idDynSt), 0, mktSgtId);
                }
            }

	        if (indexFld != -1)
	        {
		        if ((ret = DBA_ExtractHierEltRecByIndexKey(synthHierHead, A_PtfSynth, 
                                                           indexFld, idDynSt, FALSE, 
						                                   FIN_FilterPtfSynth, argPtr,
						                                   FIN_CmpReturnPtfSynth, FALSE,
			                                               ptfSynthNbrPtr, ptfSynthPtr)) != RET_SUCCEED) 
		        {
		            FREE_DYNST(argPtr,    MeanCapReturn_Arg);
		            /* REF4159 - FREE_DYNST(ptfRetPtr, Array); */
		            return(ret);
		        }
	        }
	        else
	        {
		        /* REF385 - Extract valid portfolio synthetic data (use MeanCapReturn_Arg for filter) */
		        if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth, FALSE,
					                                         FIN_FilterPtfSynth, argPtr, 
						                                     FIN_CmpReturnPtfSynth,
					                                         ptfSynthNbrPtr, ptfSynthPtr)) != RET_SUCCEED)
		        {
		            FREE_DYNST(argPtr,    MeanCapReturn_Arg);
		            /* REF4159 - FREE_DYNST(ptfRetPtr, Array); */
		            return(ret);
		        }
	        }
	    }

	    if (*ptfSynthNbrPtr == 0)
	    {
		    ret = RET_FIN_ERR_INVDATA;
	        MSG_SendMesg(ret, 2, FILEINFO, "FIN_SelectPtfSynth", "period");
		    FREE(*ptfSynthPtr);
	    }

	    /* Prepare the data to be optimized. */

	    /* REF4159 - memory size - RAK - 991124 */
	    /* SET_ARRAY(ptfRetPtr, Array_Ptr, *ptfSynthPtr, (short) *ptfSynthNbrPtr, sizeof(DBA_DYNFLD_STP)); */
	    /* REF1458 - keep extract return code */
	    /* REF4159 - memory size - RAK - 991124 */
	    /* DBA_SetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, argPtr, Array, ptfRetPtr, Opti_Local); */

	    FREE_DYNST(argPtr, MeanCapReturn_Arg);
        return(ret);
    }	
}

/************************************************************************
**
**  Function    :  FIN_Return()
**
**  Description :  Computes rate of return depending on received arguments. 
**                 
**  Arguments   :  fromDate       date from which the computation is done
**                                It should correspond to a date in the synth.
**                                struct. If it doesn't, use the next record
**                 tillDate       date until which the computation is done
**                                It should correspond to a date in the synth.
**                                struct. If it doesn't, use the previous record
**                 returnMethod   TWR : time weighted rate of return            
**                                MWR : money weighted rate of return           
**                                IRR : internal rate of return 
**                 taxCredFlg     indicates whether tax credits are to be 
**                                included as withdrawals from the system
**                 grossEffectFlg indicates whether the investment and 
**                                withdrawal amounts are Gross or Net amounts
**		   grossFeesFlg   indicates whether portfolio fees are to be
**                                included as withdrawals from the portfolio
**		   grossTaxFlg    indicates whether portfolio taxes are to be
**                                included as withdrawals from the portfolio
**                 riskFlg        indicates whether risk amounts are used for
**                                the computation.
**                 annualiseRuleEn annualise return (not used)
**                 ptfId          current portfolio identifier
**                 hierHeadPtr    pointer on hierarchy header
**                 ptfRetPtr      allocated A_PtfReturn dynamic structure pointer
**                 useNIPMethodFlg use NIP informnation to compute mean cap
**
**  Return      :  RET_SUCCEED or error code
**                 ptfRetPtr is filled with computed rate of return 
**
**  Creation    :  DVP004 - RAK - 960305 (replace FIN_PtfReturn)
**
**  Modif       :  BUG048 - RAK - 960705
**                 DVP165 - RAK - 960730
**                 DVP232 - RAK - 961120
**                 REF385 - RAK - 971001
**                 REF713 - RAK - 971027
**                 REF4222 - CSY - 991217 new parameters excludeIncFlg, selSynthPtr
**                 REF4222 - CSY - 991230 add excludeIncFlg in optimisation
**                 REF4263 - CSY - 000211 new argument freeFlg for FIN_SelectPtfSynth
**                 REF7395 - CSY - 020430: adjustment
**                 REF7634 - LJE - 020618: add param alwaysIntialDtFlg
**              
*************************************************************************/
RET_CODE FIN_Return(DATETIME_T         fromDate, 
		            DATETIME_T         tillDate,
	                RETURNMET_ENUM     returnMethod,
		            FLAG_T             taxCredFlg,
		            FLAG_T             grossEffectFlg,
		            FLAG_T             grossFeesFlg, 	/* DVP165 - RAK - 960823 */
		            FLAG_T             grossTaxFlg, 	/* DVP165 - RAK - 960823 */
		            FLAG_T             riskFlg,
		            ANNUALISERULE_ENUM annualiseRuleEn, 
                    FLAG_T             excludeIncFlg,   /* REF4222 - CSY - 991217 */
					FLAG_T             alwaysInitialDtFlg, /* REF7634 - LJE - 020618 */
					FLAG_T             retContribFlg,      /* REF7634 - LJE - 020619 */
                    FLAG_T             excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
                    FLAG_T             excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
                    DBA_DYNFLD_STP     selSynthPtr,     /* REF4222 - CSY - 991217 */
                    DBA_DYNFLD_STP     gblSynthArray,   
		            ID_T               ptfId,
		            ID_T               gridId, 		    /* DVP232 - RAK - 961120 */
		            ID_T               mktSgtId,	    /* DVP232 - RAK - 961112 */
		            ID_T               instrId, 	    /* DVP165 - RAK - 960730 */
		            PTR                hierHeadPtr,
		            DBA_DYNFLD_STP     crtRecPtr,		/* REF3621 - RAK - 990715 */
		            DBA_DYNFLD_STP     ptfRetPtr)
{
	DBA_HIER_HEAD_STP   posHierHead=(DBA_HIER_HEAD_STP)hierHeadPtr; /* REF7264 - LJE - 020131 */
	DBA_DYNFLD_STP      *crtPtfSynth=(DBA_DYNFLD_STP*)NULL, periodPtfReturn=NULLDYNST, 
			            argPtr=NULLDYNST, optiArgPtr=NULLDYNST;  /* REF7634 - LJE - 021008 */
	NUMBER_T            amt, totalRet, totalRetGbl; /* BUG048 - RAK - 960705 */ /* REF7634 - LJE - 020626 */
	double		        diffDays=0.0, tmpInitD=0.0, initD=0.0, finalD=0.0, gblInitD=0.0, gblFinalD=0.0;
	int                 ptfSynthNbr=0, period, fld; 
	RET_CODE            ret=RET_SUCCEED;
    FLAG_T              freeFlg=FALSE; /* REF4263 - CSY - 000211 */
	/* REF7634 - LJE - 020620 */
	DBA_DYNFLD_STP      *ptfGblSynthPtr=(DBA_DYNFLD_STP*)NULL;
	int                 ptfGblSynthNbr=0;
	DBA_DYNFLD_STP      periodGblPtfReturn=NULLDYNST;
	int                 nbrPeriod=0, periodDet=0;
    ID_T                pspId=0; /* REF9264 - LJE - 031021 */
	DBA_DYNFLD_STP* glbPtfSynthTab = (DBA_DYNFLD_STP*)NULL;
	int				glbPtfSynthNbr = 0;
	MemoryPool      mp;

	/* REF7634 - LJE - 020621 : Put here */
	/* --------------------- */
	/* DVP232 - RAK - 961118 */
	/* In local only, because of 0 for ptf, instr or mktSgt */
	if ((optiArgPtr = ALLOC_DYNST(MeanCapReturn_Arg)) == NULLDYNST)
    {
        DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* REF8712 - LJE - 031021 */
    if (crtRecPtr != NULL)
    {
        pspId = GET_ID(crtRecPtr, A_PtfSynth_PSPId);
    }

    /* Force return risk flag to 0 (in doc : Not yet implemented) */ /* REF9725 - LJE - 041223 */
    riskFlg = 0;

	SET_DATETIME(optiArgPtr, MeanCapReturn_Arg_FromDate,         fromDate);
	SET_DATETIME(optiArgPtr, MeanCapReturn_Arg_TillDate,         tillDate);
	SET_ID(optiArgPtr,       MeanCapReturn_Arg_PtfId,            ptfId);
	SET_ID(optiArgPtr,       MeanCapReturn_Arg_MktSgtId,         mktSgtId);
	SET_ID(optiArgPtr,       MeanCapReturn_Arg_InstrId,          instrId);
    SET_ID(optiArgPtr,       MeanCapReturn_Arg_PSPId,            pspId);    /* REF9264 - LJE - 031021 */
	SET_ENUM(optiArgPtr,     MeanCapReturn_Arg_MethodEn,         (ENUM_T) returnMethod);
	SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_TaxCredFlg,       taxCredFlg);
	SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_GrossEffectFlg,   grossEffectFlg);
	SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_GrossFeesFlg,     grossFeesFlg);
	SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_GrossTaxFlg,      grossTaxFlg);
	SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_RiskFlg,          riskFlg);
	SET_ENUM(optiArgPtr,     MeanCapReturn_Arg_AnnualRuleEn,     (ENUM_T) annualiseRuleEn);
	/* REF7634 - LJE - 020619 */
    SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_AlwaysInitialDtFlg, alwaysInitialDtFlg);
    SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_RetContribFlg,    retContribFlg);
	SET_ID(optiArgPtr,       MeanCapReturn_Arg_GridId,           gridId);
    /* REF4222 - CSY - 991230 */
    SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_ExcludeIncFlg,    excludeIncFlg); 
	/* REF7634 - LJE - 020619 */
	SET_TINYINT(optiArgPtr, MeanCapReturn_Arg_Level, GET_TINYINT(crtRecPtr, A_PtfSynth_Level));
    /* REF11269 - LJE - 051220 */
    SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_ExcludePosFeesFlg,   excludePosFeesFlg); 
    SET_FLAG(optiArgPtr,     MeanCapReturn_Arg_ExcludePosTaxFlg,    excludePosTaxFlg); 

    /* REF4263 - CSY - 000131: can't use optimisation if SEL_SYNTH */
    if (selSynthPtr == NULLDYNST && (instrId == 0 || mktSgtId == 0)) /* REF11193 - LJE - 050512 */
    {
        DATE_StartTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL); 

	    if (DBA_GetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, optiArgPtr, A_PtfReturn, 
			      ptfRetPtr, (DBA_DYNFLD_STP *) NULL, Opti_Local) == RET_SUCCEED)
	    {
		    FREE_DYNST(optiArgPtr, MeanCapReturn_Arg);
            getMWRSucceedCounter++;
            DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
		    return(RET_SUCCEED);
	    }
        getMWRFailedCounter++;
        DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
    }

   	if ((argPtr = ALLOC_DYNST(MeanCapReturn_Arg)) == NULLDYNST)
    {
        DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    COPY_DYNST(argPtr, optiArgPtr, MeanCapReturn_Arg);
                                  
	/* --------------------- */

	if (returnMethod!=ReturnMet_ARC || 
        retContribFlg==FALSE ||  /* REF7634 - LJE - 020701 */
        (IS_NULLFLD(crtRecPtr, A_PtfSynth_InstrId ) == TRUE &&
		 IS_NULLFLD(crtRecPtr, A_PtfSynth_MktSegtId ) == TRUE))
	{
		/* --------------------- */
		/* DVP165 - RAK - 960730 */
		/* if ((ret = FIN_SelectPtfSynth(fromDate, tillDate, riskFlg, ptfId,
				   posHierHead, &ptfSynthNbr, &crtPtfSynth)) != RET_SUCCEED) */
		DATE_StartTimer(&SV_KeywordSelectPtfSynthMeanCap, TIMER_MASK_ALL);
		if ((ret = FIN_SelectPtfSynth(fromDate, tillDate, riskFlg,
						  ptfId, gridId, mktSgtId, 
						  instrId, pspId, /* REF9264 - LJE - 031021 */
						  selSynthPtr, /* REF4263 - CSY - 000128 */
						  posHierHead, crtRecPtr, &freeFlg,
						  &ptfSynthNbr, &crtPtfSynth)) != RET_SUCCEED || ptfSynthNbr == 0)
		/* --------------------- */
		{
            if (freeFlg == TRUE)
            {
                FREE(crtPtfSynth);
            }
			FREE_DYNST(argPtr, MeanCapReturn_Arg);
            FREE_DYNST(optiArgPtr, MeanCapReturn_Arg); /* REF7634 - LJE - 021008 */
			DATE_StopTimer(&SV_KeywordSelectPtfSynthMeanCap, TIMER_MASK_ALL);
			return(ret);
		}
		DATE_StopTimer(&SV_KeywordSelectPtfSynthMeanCap, TIMER_MASK_ALL);
	}

	/* PMSTA-55377 - Deepthi - 240117 - Extracting the global port synthetic records and adding it to array */
	if (gblSynthArray == NULLDYNSTPTR ||
		IS_NULLFLD(gblSynthArray, A_Array_Ptr) == TRUE ||
		GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr) == 0)
	{
		for (int idx = 0; idx < ptfSynthNbr; idx++)
		{
			if (GET_EXTENSION_PTR(crtPtfSynth[idx], A_PtfSynth_GblPtfSynth_Ext) != NULL)
			{
				glbPtfSynthTab = GET_EXTENSION_PTR(crtPtfSynth[idx], A_PtfSynth_GblPtfSynth_Ext);
				glbPtfSynthNbr = GET_EXTENSION_NBR(crtPtfSynth[idx], A_PtfSynth_GblPtfSynth_Ext);
			}
		}

		if (glbPtfSynthNbr > 0)
		{
			SET_ARRAY(gblSynthArray, A_Array_Ptr, glbPtfSynthTab, glbPtfSynthNbr, sizeof(DBA_DYNFLD_STP));
		}
	}

    DATE_StartTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
	if (ret == RET_SUCCEED)
	{
	    SET_DATETIME(ptfRetPtr, A_PtfReturn_FromDate,       fromDate);
	    SET_DATETIME(ptfRetPtr, A_PtfReturn_TillDate,       tillDate);
	    SET_ENUM(ptfRetPtr,     A_PtfReturn_ReturnMetEn,         returnMethod);
	    SET_FLAG(ptfRetPtr,     A_PtfReturn_TaxCreditFlg,     taxCredFlg);
	    SET_FLAG(ptfRetPtr,     A_PtfReturn_GrossEffectFlg, grossEffectFlg);

		switch(returnMethod)
		{
			/* The computation of TWRR is done by computing periodic MWRRs */
			/* and chaining them, as shown in the following formula :      */
			/* TWRR = (1 + R1) * (1 + R2) * (1 + R3) * ... * (1 + Ri)      */
		case ReturnMet_TWR :
			if ((periodPtfReturn = ALLOC_DYNST(A_PtfReturn)) == NULLDYNST)
			{
				FREE_DYNST(optiArgPtr, MeanCapReturn_Arg);
				FREE_DYNST(argPtr, MeanCapReturn_Arg); /* REF7634 - LJE - 021008 */
				if (freeFlg == TRUE)
				{
					FREE(crtPtfSynth);
				}
				DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			/* Chain periods computed return */
			for (period=0; period<ptfSynthNbr; period++)
			{
				FIN_PeriodPtfReturn(crtPtfSynth, period, period+1, taxCredFlg,
					grossEffectFlg, grossFeesFlg, grossTaxFlg,
					excludeIncFlg, retContribFlg, selSynthPtr, gblSynthArray, /* WEALTH-4788 - DDV - 240126 - Performance TWR with exclude Income is wrong */
					argPtr, /* REF5314 - CSY - 001018 */
					periodPtfReturn,
					&tmpInitD, &finalD,
					posHierHead);

				if (period == 0)
				{
					/* REF4253 - RAK - 000106 - Get first initial num days for annualisation */
					initD = tmpInitD;

					/* Update return fields */
					for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
					{
						/* BUG048 - RAK - 960705 */
						amt = 1 + GET_NUMBER(periodPtfReturn, fld);
						SET_NUMBER(ptfRetPtr, fld, amt);
					}

					/*WEALTH-2193 - Senthil - 231005*/
					for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
					{
						amt = 1 + GET_NUMBER(periodPtfReturn, fld);
						SET_NUMBER(ptfRetPtr, fld, amt);
					}

					/* REF11269 - LJE - 051230 */
					SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, (1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees)));
					SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax,  (1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax)));

				}
				else
				{
					/* Update return fields */
					for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
					{
						/* BUG048 - RAK - 960705 */
						amt = GET_NUMBER(ptfRetPtr, fld) *
							(1 + GET_NUMBER(periodPtfReturn, fld));
						SET_NUMBER(ptfRetPtr, fld, amt);
					}

					/*WEALTH-2193 - Senthil - 231005*/
					for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
					{
						amt = GET_NUMBER(ptfRetPtr, fld) *
							(1 + GET_NUMBER(periodPtfReturn, fld));
						SET_NUMBER(ptfRetPtr, fld, amt);
					}

					/* REF11269 - LJE - 051230 */
					SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, GET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees) *
						(1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees)));
					SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax,  GET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax ) *
						(1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax)));
				}
			}

			for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
			{
				/* Update return fields */
				/* BUG048 - RAK - 960705 */
				amt = GET_NUMBER(ptfRetPtr, fld) - 1;
				SET_NUMBER(ptfRetPtr, fld, amt);
			}

			/*WEALTH-2539 - Senthil - 231012*/
			for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
			{
				amt = GET_NUMBER(ptfRetPtr, fld) - 1;
				SET_NUMBER(ptfRetPtr, fld, amt);
			}

			/* REF11269 - LJE - 051230 */
			SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, (GET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees) - 1));
			SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax,  (GET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax)  - 1));


			FREE_DYNST(periodPtfReturn, A_PtfReturn);
			break;

			/* Calculate the mean invested capital over the period. */
			/* Total return = (final mkt val - initial mkt val - flows) / mean invested capital */
			/* Counters     = (final counter - initial counter) / mean invested capital */
		case ReturnMet_MWR :
			FIN_PeriodPtfReturn(crtPtfSynth, 0, ptfSynthNbr, taxCredFlg, grossEffectFlg,
				grossFeesFlg, grossTaxFlg,
				excludeIncFlg, retContribFlg,
				selSynthPtr, gblSynthArray,
				argPtr, /* REF5314 - CSY - 001015 */
				ptfRetPtr, &initD, &finalD, /* REF4253 - RAK - 000106 */
				posHierHead);
			break;

			/* Calculate the internal rate of return */
		case ReturnMet_IRR :
			FIN_InternalRateReturn(fromDate, tillDate, taxCredFlg, grossEffectFlg,
				grossFeesFlg, grossTaxFlg,
				excludeIncFlg, alwaysInitialDtFlg,
				excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
				retContribFlg,
				selSynthPtr,
				crtPtfSynth,
				ptfSynthNbr,
				gblSynthArray,
				ptfRetPtr, &initD, &finalD,
				posHierHead, argPtr);
			break;

			/* REF7634 - LJE - 020620 New method of "chaining" return contributions and th return effect */
		case ReturnMet_ARC :
		{
			/* 'RC(ARC)ms,1->n' = 'RC(ARC)ms,1->n-1' + (1 + 'R(TWR)g,1->n-1') * 'RCms,n' */
			/* RC => Return Contrib or Return Effect                                     */
			/* ms => market segment (current portfolio synthetic)                        */

			if ((periodPtfReturn    = ALLOC_DYNST(A_PtfReturn)) == NULLDYNST ||
				(periodGblPtfReturn = ALLOC_DYNST(A_PtfReturn)) == NULLDYNST )
			{

				FREE_DYNST(periodPtfReturn, A_PtfReturn);
				FREE_DYNST(periodGblPtfReturn, A_PtfReturn);
				FREE_DYNST(argPtr, MeanCapReturn_Arg);
				FREE_DYNST(optiArgPtr, MeanCapReturn_Arg); /* REF7634 - LJE - 021008 */
				if (freeFlg == TRUE)
				{
					FREE(crtPtfSynth);
				}
				DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			totalRet    = 0.0;
			totalRetGbl = 0.0;


			if (retContribFlg==TRUE)
			{
				{
					DBA_DYNFLD_STP ptfSynthTest;

					/* REF9055.4002 - LJE - 030507 */
					if ((ptfSynthTest = ALLOC_DYNST(A_PtfSynth)) == NULLDYNST)
					{
						FREE_DYNST(periodPtfReturn, A_PtfReturn);
						FREE_DYNST(periodGblPtfReturn, A_PtfReturn);
						return(ret);
					}

					DBA_SetDfltEntityFld(PtfSynth,  A_PtfSynth, ptfSynthTest);

					/* The reference loop is on global ptfSynth for treated the empty line
					 * detail ptf synth
					 */

					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_PtfId,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_PtfId);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_GridId,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_GridId);
					SET_NULL_ID(ptfSynthTest, A_PtfSynth_MktSegtId);
					SET_NULL_ID(ptfSynthTest, A_PtfSynth_InstrId);
					/* REF9264 - LJE - 031021 */
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_PSPId,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_PSPId);

					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_Level,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_Level);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_InitialDate,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_FromDate);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_FinalDate,
						argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_TillDate);
					/* PMSTA-55377 - Deepthi - 240117 - If Global Port Synthetic array is populated,
   call the filter function with the records from the array, else use hierarchy */
					DBA_DYNFLD_STP* ptfGblSynthTab = (DBA_DYNFLD_STP*)NULL;

					if (gblSynthArray != NULLDYNSTPTR &&
						IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
						(GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr)) > 0)
					{
						ptfGblSynthTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
						int nbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr);
						if ((ptfGblSynthPtr = (DBA_DYNFLD_STP*)mp.calloc(FILEINFO, nbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
						{
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
						for (int idx = 0; idx < nbr; ++idx)
						{
							if (FIN_FilterGlobalPtfSynth(ptfGblSynthTab[idx], A_PtfSynth, ptfSynthTest))
							{
								ptfGblSynthPtr[ptfGblSynthNbr] = ptfGblSynthTab[idx];
								ptfGblSynthNbr++;
							}
						}
					}
					else
					{
						/* REF10276 - LJE - 040512 */
						if ((ret = DBA_ExtractHierEltRecByIndexKey(posHierHead,
							A_PtfSynth,
							A_PtfSynth_MktSegtId,
							ptfSynthTest[A_PtfSynth_MktSegtId],
							FALSE,
							FIN_FilterGlobalPtfSynth,
							ptfSynthTest,
							FIN_CmpReturnPtfSynth,
							FALSE,
							&ptfGblSynthNbr,
							&ptfGblSynthPtr)) != RET_SUCCEED ||
							ptfGblSynthNbr == 0)
						{
							FREE_DYNST(ptfSynthTest, A_PtfSynth);  /* REF9055.4002 - LJE - 030507 */
							FREE_DYNST(periodPtfReturn, A_PtfReturn);
							FREE_DYNST(periodGblPtfReturn, A_PtfReturn);
							return(ret);
						}
						mp.ownerPtr(ptfGblSynthPtr);

						freeFlg = TRUE;
					}

					FREE_DYNST(ptfSynthTest, A_PtfSynth);  /* REF9055.4002 - LJE - 030507 */

					nbrPeriod = ptfGblSynthNbr;
				}
			}
			else
			{
				nbrPeriod = ptfSynthNbr;
			}

			/* PMSTA-53154 - DDV  - 230823 - Fix missing return in perf_calc_result for contrib method */
			int firstGblSynthIdx = 0;

			if (ptfGblSynthPtr != nullptr)
			{
				if (selSynthPtr != NULLDYNST && IS_NULLFLD(selSynthPtr, A_Array_Ptr) == FALSE)
				{
					DBA_DYNFLD_STP* tmpTab = (DBA_DYNFLD_STP*)NULL;
					int                  tmpNbr = 0;

					tmpTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(selSynthPtr, A_Array_Ptr);
					tmpNbr = GET_ARRAY_ELTNBR(selSynthPtr, A_Array_Ptr);

					if (tmpNbr > 0)
					{

					}

					while (firstGblSynthIdx < nbrPeriod &&
						GET_DATE(ptfGblSynthPtr[firstGblSynthIdx], A_PtfSynth_InitialDate) < GET_DATE(tmpTab[0], A_PtfSynth_InitialDate))
					{
						firstGblSynthIdx++;
					}

					if (firstGblSynthIdx == nbrPeriod)
					{
						firstGblSynthIdx = 0;
					}
				}
			}

			/* Chain periods computed return */
			for (period= firstGblSynthIdx; period<nbrPeriod; period++)
			{
				SET_ID(argPtr,       MeanCapReturn_Arg_MktSgtId,         mktSgtId);
				SET_ID(argPtr,       MeanCapReturn_Arg_InstrId,          instrId);
				SET_ID(argPtr,       MeanCapReturn_Arg_PSPId,            pspId); /* REF9264 - LJE - 031021 */
				SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn,         (ENUM_T) returnMethod);

				if (retContribFlg==TRUE &&
					(IS_NULLFLD(crtRecPtr, A_PtfSynth_InstrId ) == FALSE ||
						IS_NULLFLD(crtRecPtr, A_PtfSynth_MktSegtId ) == FALSE ))
				{
					/* PMSTA-53154 - DDV  - 230823 - Fix missing return in perf_calc_result for contrib method */
					if (period < firstGblSynthIdx)
						continue;

					/* Extract current ptf synth detail */
					if (freeFlg == TRUE)
					{
						FREE(crtPtfSynth);
					}

					freeFlg = TRUE;
					crtPtfSynth = NULLDYNSTPTR;
					ptfSynthNbr = 0;

					SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate,
						GET_DATETIME(ptfGblSynthPtr[period], A_PtfSynth_InitialDate));
					SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate,
						GET_DATETIME(ptfGblSynthPtr[period], A_PtfSynth_FinalDate));

					if (selSynthPtr != NULLDYNST && IS_NULLFLD(selSynthPtr, A_Array_Ptr) == FALSE)
					{
						DBA_DYNFLD_STP      *tmpTab = (DBA_DYNFLD_STP*)NULL;
						int                  tmpNbr = 0;

						tmpTab = (DBA_DYNFLD_STP *)GET_ARRAY_PTR(selSynthPtr, A_Array_Ptr);
						tmpNbr = GET_ARRAY_ELTNBR(selSynthPtr, A_Array_Ptr);

						crtPtfSynth = (DBA_DYNFLD_STP *)CALLOC(tmpNbr, sizeof(DBA_DYNFLD_STP));
						for (int i = 0; i < tmpNbr; ++i)
						{
							if (FIN_FilterPtfSynth(tmpTab[i], A_PtfSynth, argPtr) == TRUE)
							{
								crtPtfSynth[ptfSynthNbr++] = tmpTab[i];
							}
						}
					}

					if (ptfSynthNbr == 0)
					{
						/* REF11193 - LJE - 050512 : Use instrument index */
						if (instrId != 0)
						{
							DBA_ExtractHierEltRecByIndexKey(posHierHead,
								A_PtfSynth,
								A_PtfSynth_InstrId,
								argPtr[MeanCapReturn_Arg_InstrId],
								FALSE,
								FIN_FilterPtfSynth,
								argPtr,
								FIN_CmpReturnPtfSynth,
								FALSE,
								&ptfSynthNbr,
								&crtPtfSynth);
						}
						else
						{
							DBA_ExtractHierEltRecByIndexKey(posHierHead,
								A_PtfSynth,
								A_PtfSynth_MktSegtId,
								argPtr[MeanCapReturn_Arg_MktSgtId],
								FALSE,
								FIN_FilterPtfSynth,
								argPtr,
								FIN_CmpReturnPtfSynth,
								FALSE,
								&ptfSynthNbr,
								&crtPtfSynth);
						}
					}

					SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate,         fromDate);
					SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate,         tillDate);

					if (ptfSynthNbr == 1) /* REF7634 - LJE - 021014 */
					{
						periodDet=0;
						/* Get current returns */
						FIN_PeriodPtfReturn(crtPtfSynth,
							periodDet,
							periodDet+1,
							taxCredFlg,
							grossEffectFlg,
							grossFeesFlg,
							grossTaxFlg,
							excludeIncFlg,
							retContribFlg,
							selSynthPtr,
							gblSynthArray,
							argPtr,
							periodPtfReturn,
							&tmpInitD,
							&finalD,
							posHierHead);


						if (period == firstGblSynthIdx && periodDet == 0)
						{
							/* Get first initial num days for annualisation */
							initD = tmpInitD;

							/* Total return */
							totalRet = GET_NUMBER(periodPtfReturn, A_PtfReturn_TotalReturn);

							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								amt = GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/*WEALTH-2539 - Senthil - 231012*/
							for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
							{
								amt = GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}
							/* REF11269 - LJE - 051230 */
							amt = GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, amt);
							amt = GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, amt);
						}
						else
						{
							/* Total return */
							totalRet = (1 + totalRet) *
								(1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_TotalReturn)) -1;


							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								amt = GET_NUMBER(ptfRetPtr, fld) +
									(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/*WEALTH-2539 - Senthil - 231012*/
							for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
							{
								amt = GET_NUMBER(ptfRetPtr, fld) +
									(1 + totalRetGbl) * GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/* REF11269 - LJE - 051230 */
							amt = GET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees) +
								(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, amt);

							amt = GET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax) +
								(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, amt);
						}
					}
					else
					{
						if (period == firstGblSynthIdx)
						{
							/* Total return */
							totalRet = 0.0;

							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								SET_NUMBER(ptfRetPtr, fld, 0.0);
							}

							/* REF11269 - LJE - 051230 */
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, 0.0);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, 0.0);
						}
					}

					/* Return global TWR */
					SET_NULL_ID(argPtr, MeanCapReturn_Arg_MktSgtId );
					SET_NULL_ID(argPtr, MeanCapReturn_Arg_InstrId  );
					SET_ID(argPtr,       MeanCapReturn_Arg_PSPId,            pspId); /* REF9264 - LJE - 031021 */
					SET_ENUM   (argPtr, MeanCapReturn_Arg_MethodEn, (ENUM_T)ReturnMet_TWR);

					/* Get global return */
					FIN_PeriodPtfReturn(ptfGblSynthPtr,
						period,
						period+1,
						taxCredFlg,
						grossEffectFlg,
						grossFeesFlg,
						grossTaxFlg,
						excludeIncFlg,
						retContribFlg,
						selSynthPtr,
						gblSynthArray,
						argPtr,
						periodGblPtfReturn,
						&gblInitD,
						&gblFinalD,
						posHierHead);

					if (period == firstGblSynthIdx)
					{
						/* Get first initial num days for annualisation */
						initD = gblInitD;

						/* Update return fields */
						totalRetGbl = GET_NUMBER(periodGblPtfReturn, A_PtfReturn_TotalReturn);
					}
					else
					{
						/* Update return fields */
						totalRetGbl = (1 + totalRetGbl) *
							(1 + GET_NUMBER(periodGblPtfReturn, A_PtfReturn_TotalReturn)) - 1;
					}
				}
				else
				{
					if (ptfSynthNbr > 0)
					{
						/* Get current returns */
						FIN_PeriodPtfReturn(crtPtfSynth,
							period - firstGblSynthIdx,
							period - firstGblSynthIdx + 1,
							taxCredFlg,
							grossEffectFlg,
							grossFeesFlg,
							grossTaxFlg,
							excludeIncFlg,
							retContribFlg,
							selSynthPtr,
							gblSynthArray,
							argPtr,
							periodPtfReturn,
							&tmpInitD,
							&finalD,
							posHierHead);

						if (period == firstGblSynthIdx)
						{
							/* Get first initial num days for annualisation */
							initD = tmpInitD;

							/* Total return */
							totalRet = GET_NUMBER(periodPtfReturn, A_PtfReturn_TotalReturn);

							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								amt = GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/*WEALTH-2539 - Senthil - 231012*/
							for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
							{
								amt = GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/* REF11269 - LJE - 051230 */
							amt = GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, amt);
							amt = GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, amt);
						}
						else
						{
							/* Total return */
							totalRet = (1 + totalRet) *
								(1 + GET_NUMBER(periodPtfReturn, A_PtfReturn_TotalReturn)) -1;


							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								amt = GET_NUMBER(ptfRetPtr, fld) +
									(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/*WEALTH-2539 - Senthil - 231012*/
							for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
							{
								amt = GET_NUMBER(ptfRetPtr, fld) +
									(1 + totalRetGbl) * GET_NUMBER(periodPtfReturn, fld);
								SET_NUMBER(ptfRetPtr, fld, amt);
							}

							/* REF11269 - LJE - 051230 */
							amt = GET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees) +
								(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, A_PtfReturn_PosFees);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, amt);
							amt = GET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax) +
								(1+totalRetGbl)*GET_NUMBER(periodPtfReturn, A_PtfReturn_PosTax);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, amt);

						}

					}
					else
					{
						if (period == firstGblSynthIdx)
						{
							/* Total return */
							totalRet = 0.0;

							/* Update return fields */
							for (fld = A_PtfReturn_RealCapProfit; fld < A_PtfReturn_MeanCap; fld++)
							{
								SET_NUMBER(ptfRetPtr, fld, 0.0);
							}

							/* REF11269 - LJE - 051230 */
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, 0.0);
							SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, 0.0);
						}

					}

					totalRetGbl = totalRet;

				}
			}

			if (retContribFlg==FALSE ||
				(IS_NULLFLD(crtRecPtr, A_PtfSynth_InstrId ) == TRUE &&
					IS_NULLFLD(crtRecPtr, A_PtfSynth_MktSegtId ) == TRUE ) )
			{
				/* if the method is ARC and the ptf synth is global or
				 * market segment without ret contrib flag, the method is TWR
				 */
				SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, totalRet);
			}


			FREE_DYNST(periodPtfReturn, A_PtfReturn);
			FREE_DYNST(periodGblPtfReturn, A_PtfReturn);
			}
			break;

		/* WEALTH-3330 - DDV - 240708 */
	    /* The computation of MWR with NIP is done by computing MC by invested period(MC1, MC1, MC3 . . .) * /
		/* MC = MC1 * NbDays1 + MC2 * NbDays2 + MC3 * NbDays3 + ... / (NbDays1 + NbDays2 + NbDays3 + ... )  */
		/* MWR = (PL1 + PL2 + PL3 + ...) / MC                                                               */
		case ReturnMet_MWRWithNIP:
			{
				if ((periodPtfReturn = mp.allocDynst(FILEINFO, A_PtfReturn)) == NULLDYNST)
				{
					FREE_DYNST(optiArgPtr, MeanCapReturn_Arg);
					FREE_DYNST(argPtr, MeanCapReturn_Arg); /* REF7634 - LJE - 021008 */
					if (freeFlg == TRUE)
					{
						FREE(crtPtfSynth);
					}
					DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				DBA_DYNFLD_STP *ptfGblSynthTab = (DBA_DYNFLD_STP*)NULL;

				if (retContribFlg == TRUE)
				{
					DBA_DYNFLD_STP ptfSynthTest;

					if ((ptfSynthTest = mp.allocDynst(FILEINFO, A_PtfSynth)) == NULLDYNST)
					{
						FREE_DYNST(periodPtfReturn, A_PtfReturn);
						FREE_DYNST(periodGblPtfReturn, A_PtfReturn);
						DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
						return(ret);
					}

					DBA_SetDfltEntityFld(PtfSynth, A_PtfSynth, ptfSynthTest);

					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_PtfId, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_PtfId);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_GridId, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_GridId);
					SET_NULL_ID(ptfSynthTest, A_PtfSynth_MktSegtId);
					SET_NULL_ID(ptfSynthTest, A_PtfSynth_InstrId);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_PSPId, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_PSPId);

					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_Level, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_Level);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_InitialDate, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_FromDate);
					COPY_DYNFLD(ptfSynthTest, A_PtfSynth, A_PtfSynth_FinalDate, argPtr, MeanCapReturn_Arg, MeanCapReturn_Arg_TillDate);

					if (gblSynthArray != NULLDYNSTPTR &&
						IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
						(GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr)) > 0)
					{
						ptfGblSynthTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
						int nbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr);
						if ((ptfGblSynthPtr = (DBA_DYNFLD_STP*) mp.calloc(FILEINFO, nbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
						{
							DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

						for (int idx = 0; idx < nbr; ++idx)
						{
							if (FIN_FilterGlobalPtfSynth(ptfGblSynthTab[idx], A_PtfSynth, ptfSynthTest))
							{
								ptfGblSynthPtr[ptfGblSynthNbr] = ptfGblSynthTab[idx];
								ptfGblSynthNbr++;
							}
						}
					}
					else
					{
						/* REF10276 - LJE - 040512 */
						if ((ret = DBA_ExtractHierEltRecByIndexKey(posHierHead,
																   A_PtfSynth,
																   A_PtfSynth_MktSegtId,
																   ptfSynthTest[A_PtfSynth_MktSegtId],
																   FALSE,
																   FIN_FilterGlobalPtfSynth,
																   ptfSynthTest,
																   FIN_CmpReturnPtfSynth,
																   FALSE,
																   &ptfGblSynthNbr,
																   &ptfGblSynthPtr)) != RET_SUCCEED ||
																   ptfGblSynthNbr == 0)
						{
							return(ret);
						}
						mp.ownerPtr(ptfGblSynthPtr);
					}

				}
				else
				{
					ptfGblSynthNbr = ptfSynthNbr;
					ptfGblSynthPtr = crtPtfSynth;
				}

				int           idxGbl = 0, firstIdxGbl = 0, nbOfZeroDaysMeanCap = 0;
				NUMBER_T      nbDays = 0, sumNbDays = 0, sumNbDaysGbl = 0, zeroDaysMeanCap = 0.0;
				AMOUNT_T      sumPL = 0.0;
				FIELD_IDX_T   fldIdx = 0;

				do
				{
					/* skip all NIP PTfSynth */
					while (idxGbl < ptfGblSynthNbr &&
						static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthPtr[idxGbl], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
					{
						++idxGbl;
					}

					if (idxGbl < ptfGblSynthNbr)
					{
						firstIdxGbl = idxGbl;
						while (idxGbl < ptfGblSynthNbr &&
							static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthPtr[idxGbl], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::EndOfInvestedPeriod &&
							static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthPtr[idxGbl], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::IsOneInvestedPeriod)
						{
							++idxGbl;
						}

						if (idxGbl == ptfGblSynthNbr)
						{
							--idxGbl;
						}

						int    firstIdx = 0, idx = 0;
						if (ptfGblSynthPtr == crtPtfSynth)
						{
							firstIdx = firstIdxGbl;
							idx = idxGbl;
						}
						else
						{
							while (firstIdxGbl < ptfSynthNbr &&
								   DATETIME_CMP(GET_DATETIME(crtPtfSynth[firstIdx], A_PtfSynth_InitialDate),
									            GET_DATETIME(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_InitialDate)) < 0)
							{
								++firstIdx;
							}

							idx = ptfSynthNbr - 1;
							while (idx >= 0 &&
								   DATETIME_CMP(GET_DATETIME(crtPtfSynth[idx], A_PtfSynth_FinalDate),
									            GET_DATETIME(ptfGblSynthPtr[idxGbl], A_PtfSynth_FinalDate)) > 0)
							{
								--idx;
							}
						}

						FIN_PeriodPtfReturn(crtPtfSynth, firstIdx, idx+1, taxCredFlg,
							grossEffectFlg, grossFeesFlg, grossTaxFlg,
							excludeIncFlg, retContribFlg, selSynthPtr, gblSynthArray, /* WEALTH-4788 - DDV - 240126 - Performance TWR with exclude Income is wrong */
							argPtr, /* REF5314 - CSY - 001018 */
							periodPtfReturn,
							&tmpInitD, &finalD,
							posHierHead);

						nbDays = static_cast <NUMBER_T> (DATE_Diff(GET_DATE(crtPtfSynth[firstIdx], A_PtfSynth_InitialDate), GET_DATE(crtPtfSynth[idx], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));

						if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(crtPtfSynth[firstIdx], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod)
						{
							nbDays -= GET_NUMBER(crtPtfSynth[firstIdx], A_PtfSynth_InitialNotInvestedDays);
						}
						else
						{
							nbDays -= static_cast <NUMBER_T> (DATE_Diff(GET_DATE(crtPtfSynth[firstIdx], A_PtfSynth_InitialDate), GET_DATE(crtPtfSynth[firstIdx], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));
						}

						if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(crtPtfSynth[idx], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod)
						{
							nbDays -= GET_NUMBER(crtPtfSynth[idx], A_PtfSynth_FinalNotInvestedDays);
						}
						else if (firstIdx != idx)
						{
							nbDays -= static_cast <NUMBER_T> (DATE_Diff(GET_DATE(crtPtfSynth[idx], A_PtfSynth_InitialDate), GET_DATE(crtPtfSynth[idx], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));
						}

						sumNbDays += nbDays;

						AMOUNT_T pl = GET_AMOUNT(crtPtfSynth[idx], A_PtfSynth_FinalMktVal) - GET_AMOUNT(crtPtfSynth[firstIdx], A_PtfSynth_InitialMktVal) - GET_NUMBER(periodPtfReturn, A_PtfReturn_Flows);
						sumPL += pl;

						NUMBER_T wMeanCap = 0.0;
						/* WEALTH-10662 - DDV - 240822 - If number of days is zero, sum meancap of zero days and count number of meancap */
						if (nbDays == 0 && retContribFlg == FALSE)
						{
							zeroDaysMeanCap += GET_NUMBER(periodPtfReturn, A_PtfReturn_MeanCap);
							nbOfZeroDaysMeanCap++;
						}
						else
						{
							wMeanCap = GET_NUMBER(periodPtfReturn, A_PtfReturn_MeanCap) * nbDays;
						}

						SET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap, GET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap) + wMeanCap);

						NUMBER_T meanCap = 0.0;

						if (retContribFlg == TRUE)
						{
							nbDays = static_cast <NUMBER_T> (DATE_Diff(GET_DATE(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_InitialDate), GET_DATE(ptfGblSynthPtr[idxGbl], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));

							if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod)
							{
								nbDays -= GET_NUMBER(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_InitialNotInvestedDays);
							}
							else
							{
								nbDays -= static_cast <NUMBER_T> (DATE_Diff(GET_DATE(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_InitialDate), GET_DATE(ptfGblSynthPtr[firstIdxGbl], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));
							}

							if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthPtr[idxGbl], A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod)
							{
								nbDays -= GET_NUMBER(ptfGblSynthPtr[idxGbl], A_PtfSynth_FinalNotInvestedDays);
							}
							else if (firstIdx != idx)
							{
								nbDays -= static_cast <NUMBER_T> (DATE_Diff(GET_DATE(ptfGblSynthPtr[idxGbl], A_PtfSynth_InitialDate), GET_DATE(ptfGblSynthPtr[idxGbl], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID));
							}

							sumNbDaysGbl += nbDays;

							wMeanCap = GET_NUMBER(periodPtfReturn, A_PtfReturn_MeanCapGlobal) * nbDays;

							SET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCapGlobal, GET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCapGlobal) + wMeanCap);

							meanCap = GET_NUMBER(periodPtfReturn, A_PtfReturn_MeanCapGlobal);
						}
						else
						{
							meanCap = GET_NUMBER(periodPtfReturn, A_PtfReturn_MeanCap);
						}


						for (fldIdx = A_PtfReturn_CapitalEffect; fldIdx <= A_PtfReturn_UnrealIncEffect; ++fldIdx)
						{
							SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) + GET_NUMBER(periodPtfReturn, fldIdx) * meanCap);
						}

						fldIdx = A_PtfReturn_RealEffect;
						SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) + GET_NUMBER(periodPtfReturn, fldIdx) * meanCap);

						fldIdx = A_PtfReturn_UnrealEffect;
						SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) + GET_NUMBER(periodPtfReturn, fldIdx) * meanCap);

						fldIdx = A_PtfReturn_Flows;
						SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) + GET_NUMBER(periodPtfReturn, fldIdx));
					}

					++idxGbl;

				} while (idxGbl < ptfGblSynthNbr);

				NUMBER_T meanCap = 0.0;

				if (sumNbDays != 0.0)
				{
					meanCap = GET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap) / sumNbDays;
				}
				else
				{
					/* WEALTH-10662 - DDV - 240730 - If numbers of days is zero, keep meancap as it is */
					if (retContribFlg == TRUE)
					{
						meanCap = GET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap);
					}
					else if (nbOfZeroDaysMeanCap > 0) /* WEALTH-7579 - DDV - 240822 - For not contrib method compute meancap using zeor days information */
					{
						meanCap = zeroDaysMeanCap / nbOfZeroDaysMeanCap;
					}
				}

				SET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap, meanCap);

				if (retContribFlg == TRUE)
				{
					meanCap = 0.0;

					if (sumNbDaysGbl != 0.0)
					{
						meanCap = GET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCapGlobal) / sumNbDaysGbl;
					}

					if (meanCap != 0.0)
					{
						SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, sumPL / meanCap);
					}
					else
					{
						SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, 0.0);
					}
				}
				else
				{
					if (meanCap != 0.0)
					{
						SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, sumPL / meanCap);
					}
					else
					{
						SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, 0.0);
					}
				}

				if (meanCap != 0.0)
				{
					for (fldIdx = A_PtfReturn_CapitalEffect; fldIdx <= A_PtfReturn_UnrealIncEffect; ++fldIdx)
					{
						SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) / meanCap);
					}

					fldIdx = A_PtfReturn_RealEffect;
					SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) / meanCap);

					fldIdx = A_PtfReturn_UnrealEffect;
					SET_NUMBER(ptfRetPtr, fldIdx, GET_NUMBER(ptfRetPtr, fldIdx) / meanCap);
				}
				else
				{
					for (fldIdx = A_PtfReturn_CapitalEffect; fldIdx <= A_PtfReturn_UnrealIncEffect; ++fldIdx)
					{
						SET_NUMBER(ptfRetPtr, fldIdx, 0.0);
					}

					fldIdx = A_PtfReturn_RealEffect;
					SET_NUMBER(ptfRetPtr, fldIdx, 0.0);

					fldIdx = A_PtfReturn_UnrealEffect;
					SET_NUMBER(ptfRetPtr, fldIdx, 0.0);
				}

			}
			break;
		}
	}

    if (freeFlg == TRUE)
        FREE(crtPtfSynth); 	/* REF385 */

    DATE_StopTimer(&SV_KeywordReturnCalc, TIMER_MASK_ALL);

	/*** ------------------------------------------------- ***/
	/* REF713 - RAK - 971028                                 */
	/* Formula : A = [(1+R)�(365/N)] - 1                     */
	/* A = annualised return                                 */
	/* R = return                                            */
	/* N = number of days between the from and the till date */
	/*** ------------------------------------------------- ***/
    DATE_StartTimer(&SV_KeywordReturnAnnual, TIMER_MASK_ALL);
	/* REF1913 - rule AnnualiseOver1Year and period > year -> annualise too */
	if (annualiseRuleEn == AnnualiseOver1Year)
		/* REF4253 - Use computed initial and final num days */
        /* diffDays = DATE_Diff(fromDate.date, tillDate.date, 
				    Day, AccrRule_Actual_365); */
        diffDays = finalD - initD;

	if (annualiseRuleEn == Annualise || 
	    (annualiseRuleEn == AnnualiseOver1Year && CMP_NUMBER(diffDays, 365.0) >= 0))
	{
		int	field;
		/* long	diffDays=0; REF4253 - RAK - 000106 */
		double  days=0.0, annual;

		/* REF4253 - Use computed initial and final num days */
        /* DATE_DaysBetween(fromDate.date, tillDate.date, 
				 AccrRule_Actual_Actual, &diffDays);
        */
        diffDays = finalD - initD;

		if (diffDays > 0.0)
		{
		    days = 365.0/diffDays;

            for (field = A_PtfReturn_RealCapProfit; field < A_PtfReturn_InitNumDays; field++) /* PMSTA-27247 - LJE - 170627 */
		    {
			    annual = 1.0 + GET_NUMBER(ptfRetPtr, field);
			    if (CMP_NUMBER(annual, 0.0) >= 0)
			    {
			        annual = pow(annual, days);
			        annual -= 1.0;
			        SET_NUMBER(ptfRetPtr, field, annual);
			    }
			    else
			    {
			        SET_NUMBER(ptfRetPtr, field, 0.0);
			    }
		    }
		}
	}
    DATE_StopTimer(&SV_KeywordReturnAnnual, TIMER_MASK_ALL);

    /* REF4263 - CSY - 000131: can't use optimisation if SEL_SYNTH */
    if (selSynthPtr == NULLDYNST && 
        /* REF5314 - CSY - 001018: for MWR, DBA_SetMemory is done in FIN_PeriodPtfReturn */
		(RETURNMET_ENUM)GET_ENUM(optiArgPtr, MeanCapReturn_Arg_MethodEn) != ReturnMet_MWR &&
        (instrId == 0 || mktSgtId == 0))  /* REF11193 - LJE - 050512 */
    {
	    /* DVP232 - RAK - 961118 */
	    /* In local only, because of 0 for ptf, instr or mktSgt */
        DATE_StartTimer(&SV_KeywordReturnOptimiSet, TIMER_MASK_ALL);
	    ret = DBA_SetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, optiArgPtr,
			                A_PtfReturn, ptfRetPtr, Opti_Local);

        setMWRCounter++; 
        DATE_StopTimer(&SV_KeywordReturnOptimiSet, TIMER_MASK_ALL);
    }

    FREE_DYNST(argPtr, MeanCapReturn_Arg);
    FREE_DYNST(optiArgPtr, MeanCapReturn_Arg); /* REF7634 - LJE - 021008 */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_PeriodPtfReturn()
**
**  Description :   Compute average capital on period and return
**                  counter at v1 - counter at v0 / average capital
**
**  Arguments   :   ptfSynthPtr    pointer on portfolio synthetic data records
**                  fromIdx        index on record with initial date equal to the from date
**                  recNbr         number of record to read until final date is equal to till date
**                                 It can be only one record.
**                  taxCredFlg     indicates whether tax credits are to be 
**                                 included as withdrawals from the system
**                  grossEffectFlg indicates whether the investment and 
**                                 withdrawal amounts are Gross or Net amounts
**		            grossFeesFlg   indicates whether portfolio fees are to be
**                                 included as withdrawals from the portfolio
**		            grossTaxFlg    indicates whether portfolio taxes are to be
**                                 included as withdrawals from the portfolio
**                  excludeIncFlg  indicates whether dividends are to be included or not 
**                                 in performance attribution
**                  selSynthPtr    array of synthetics
**                  ptfReturn      A_PtfReturn structure to be filled
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP004 - RAK - 960306 
**                  BUG037 - RAK - 960613
**                  BUG046 - RAK - 960628
**                  BUG048 - RAK - 960705
**                  DVP165 - RAK - 960918
**                  REF3064 - RAK - 981124
**                  REF4222 - CSY - 991217 new parameters excludeIncFlg, selSynthPtr
**                  REF5314 - CSY - 001018: put MWR in optimisation.
**                  REF5314 - CSY - 001206: add get of the MWR (opti) at the beginning
**                  REF7634 - LJE - 020618: add param alwaysInitialDtFlg
**
*************************************************************************/
STATIC RET_CODE	FIN_PeriodPtfReturn(DBA_DYNFLD_STP    *ptfSynthPtr, 
				                    int               fromIdx,
				                    int               recNbr,
				                    FLAG_T            taxCredFlg,
				                    FLAG_T            grossEffectFlg,
				                    FLAG_T            grossFeesFlg,	    /* DVP165 - RAK - 960823 */
				                    FLAG_T            grossTaxFlg,      /* DVP165 - RAK - 960823 */
                                    FLAG_T            excludeIncFlg,    /* REF4222 - CSY - 991217 */
	                                FLAG_T            retContribFlg,    /* WEALTH-2417 - DDV - 231004 */
                                    DBA_DYNFLD_STP    selSynthPtr,      /* REF4222 - CSY - 991217 */
                                    DBA_DYNFLD_STP    gblSynthArray,
                                    DBA_DYNFLD_STP    argPtr,           /* REF5314 - CSY - 001018 */
				                    DBA_DYNFLD_STP    ptfRetPtr, 
                                    double            *initD,           /* REF4253 - RAK - 000106 */
                                    double            *finalD,          /* REF4253 - RAK - 000106 */
                                    DBA_HIER_HEAD_STP hierHead)
{
	AMOUNT_T amt, ptfFees, taxCred, ptfTax, effect, recAccr, paidAccr, uRecAccr, uPaidAccr,
	         realCapP, realCapL, realCurrP, realCurrL, recInc, paidInc, uRealCapP, 
		     uRealCapL, uRealCurrP, uRealCurrL, posFees, posTax;
	ID_T     currId;
	double   meanCap, flows; 
	int      i, fld;
	RET_CODE ret;
    RETURNMET_ENUM returnMethod; /* REF5314 - CSY - 001018 */
	DATETIME_T	fromDate, tillDate; /* REF5314 - RAK - 001106 */
	
	FLOWTIMINGRULE_ENUM flowTimingRule; /* PMSTA07059 - LJE - 080917 */

    memset(&fromDate, 0, sizeof(DATETIME_T));
    memset(&tillDate, 0, sizeof(DATETIME_T));
    fromDate = GET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate);
	tillDate = GET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate);
    
	GEN_GetApplInfo(ApplRetFlowTimingRule, &flowTimingRule);
    
    /* REF5314 - CSY - 001206: can't use optimisation if SEL_SYNTH */
    if (selSynthPtr == NULLDYNST && 
        (IS_NULLFLD(argPtr, MeanCapReturn_Arg_InstrId) == TRUE ||
         IS_NULLFLD(argPtr, MeanCapReturn_Arg_MktSgtId) == TRUE)) /* REF11193 - LJE - 050512 */
    {
        DATE_StartTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL); 
        
		/* save initial values (if TWR) */
		returnMethod = (RETURNMET_ENUM)GET_ENUM(argPtr, MeanCapReturn_Arg_MethodEn); /* REF7264 - LJE - 020131 */

        /* set criterias to get the needed MWR */
        SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn,       (ENUM_T) ReturnMet_MWR);
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate,       
                        GET_DATETIME(ptfSynthPtr[fromIdx], A_PtfSynth_InitialDate));
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate,       
                        GET_DATETIME(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalDate));

	    if (DBA_GetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, argPtr, A_PtfReturn, 
			      ptfRetPtr, (DBA_DYNFLD_STP *) NULL, Opti_Local) == RET_SUCCEED)
	    {
		    /* reset initial values (if TWR) */
            SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn,       (ENUM_T) returnMethod);
            SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate, fromDate);
	        SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate, tillDate);

            /* Set the initial and final num days from the optimization structure */
            *initD  = GET_NUMBER(ptfRetPtr, A_PtfReturn_InitNumDays);  /* PMSTA-11731 - LJE - 110420 */
            *finalD = GET_NUMBER(ptfRetPtr, A_PtfReturn_FinalNumDays); /* PMSTA-11731 - LJE - 110420 */

            getMWRSucceedCounter++;
            DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
		    return(RET_SUCCEED);
	    }

        /* reset initial values (if TWR) */
        SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn,       (ENUM_T) returnMethod);
        SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate, fromDate);
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate, tillDate);
        getMWRFailedCounter++;
        DATE_StopTimer(&SV_KeywordReturnOptimiGet, TIMER_MASK_ALL);
    }
    

	/* BUG046 - RAK - 960628 */
	currId = GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId);

	/* ----------------------------- */
	/* COMPUTE MEAN INVESTED CAPITAL */
	/* ----------------------------- */
	DATE_StartTimer(&SV_KeywordCalcMeanCapReturn, TIMER_MASK_ALL);

    DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr();

    /* PMSTA-47578 - DDV - 220318 - New function to compute mean cap when NIP information are availabe */
    if (domainPtr != NULLDYNST && 
        GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
    {
	    ret = FIN_CalcMeanInvestedCapWithNIP(ptfSynthPtr, fromIdx, recNbr, taxCredFlg, 
								             grossEffectFlg, grossFeesFlg, grossTaxFlg, 
								             excludeIncFlg, 
								             GET_FLAG(argPtr, MeanCapReturn_Arg_AlwaysInitialDtFlg), /* REF7634 - LJE - 020618 */
                                             GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosFeesFlg),  /* REF11269 - LJE - 051220 */
                                             GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosTaxFlg),   /* REF11269 - LJE - 051220 */
			                                 retContribFlg,
								             selSynthPtr, /* REF4222 - CSY - 991221 */
											 gblSynthArray,
								             &flows, &meanCap, initD, finalD, 
								             fromDate, tillDate, hierHead);   /* REF7395 - CSY - 020430 */
    }
    else
    {
		if (flowTimingRule == FlowTimingRule_UseRetInvestTimingRule)
		{
			ret = FIN_CalcMeanInvestedCap(ptfSynthPtr, fromIdx, recNbr, taxCredFlg,
										  grossEffectFlg, grossFeesFlg, grossTaxFlg,
										  excludeIncFlg,
										  GET_FLAG(argPtr, MeanCapReturn_Arg_AlwaysInitialDtFlg), /* REF7634 - LJE - 020618 */
										  GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosFeesFlg),  /* REF11269 - LJE - 051220 */
										  GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosTaxFlg),   /* REF11269 - LJE - 051220 */
										  selSynthPtr, /* REF4222 - CSY - 991221 */
										  gblSynthArray,
										  &flows, &meanCap, initD, finalD,
										  fromDate, tillDate,   /* REF7395 - CSY - 020430 */
										  hierHead);
		}
		else
		{
			ret = FIN_CalcMeanInvestedCapNew(ptfSynthPtr, fromIdx, recNbr, taxCredFlg,
				                             grossEffectFlg, grossFeesFlg, grossTaxFlg,
				                             excludeIncFlg,
				                             GET_FLAG(argPtr, MeanCapReturn_Arg_AlwaysInitialDtFlg),
				                             GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosFeesFlg),
				                             GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosTaxFlg),
				                             selSynthPtr,
				                             &flows, &meanCap, initD, finalD,
				                             fromDate, tillDate,
				                             hierHead);
		}
    }

	DATE_StopTimer(&SV_KeywordCalcMeanCapReturn, TIMER_MASK_ALL);

    /* REF5315 - CSY - 001018 set the field A_PtfReturn_MeanCap */  /* REF5314 - RAK - 010109 */
    SET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCap, meanCap);

    /* REF7634 - LJE - 020618 : set the field A_PtfReturn_Flows */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_Flows, (NUMBER_T)flows);

	/* If mean invested capital is equal to 0, the return is 0. */
	/* BUG046 - RAK - 960628 */
    DATE_StartTimer(&SV_KeywordPeriodPtfReturn, TIMER_MASK_ALL);
	if (ret != RET_SUCCEED) /* REF3064 */ /* REF7634 - LJE - 020703 */
	{
		for (fld=A_PtfReturn_RealCapProfit; fld<A_PtfReturn_MeanCap; fld++)
		{ 	
			/* BUG048 - RAK - 960705 */
			SET_NUMBER(ptfRetPtr, fld, 0.0); 
		}

        /* REF11269 - LJE - 051230 */
        SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, 0.0);
        SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, 0.0);

        DATE_StopTimer(&SV_KeywordPeriodPtfReturn, TIMER_MASK_ALL);
		return(RET_SUCCEED);
	}

	/* If mean invested capital is negative, the returns should be multiplied by -1 */
	/* BUG046 - RAK - 960628 */
	/* if (meanCap < 0.0) */
    /* REF9072 - LJE - 030502 : Remove absolute value 
	    if (CMP_AMOUNT(meanCap, 0.0, currId) == -1)
		    meanCap *= -1;
     */

	/* REF7634 - LJE - 020619 : For calculate the return contribution, the mean cap is the global mean cap */

	 /* PMSTA-55377 - Deepthi - 240117 - Use the global port synthetic array records if available in Filter function, else use hierarchy */
	if (GET_FLAG(argPtr, MeanCapReturn_Arg_RetContribFlg) == TRUE && 
		(IS_NULLFLD(ptfSynthPtr[fromIdx], A_PtfSynth_InstrId ) == FALSE ||
		 IS_NULLFLD(ptfSynthPtr[fromIdx], A_PtfSynth_MktSegtId ) == FALSE ) )
	{
		DBA_DYNFLD_STP *ptfGblSynthTab=(DBA_DYNFLD_STP*)NULL;
		int             ptfGblSynthNbr=0;
        DBA_DYNFLD_STP  ptfGblSynthRec = NULLDYNST;
        DBA_DYNFLD_STP  aGblPtfReturn = NULLDYNST;
		DBA_DYNFLD_ST   nullValueSt;
		FLAG_T			gblArrayUsed = FALSE;

        if ((aGblPtfReturn = ALLOC_DYNST(A_PtfReturn)) == NULLDYNST)
        {
            return(RET_MEM_ERR_ALLOC);
        }

		memset(&nullValueSt, 0, sizeof(DBA_DYNFLD_ST)); /* PMSTA-02403 - LJE - 070514 */



        if (gblSynthArray != NULLDYNSTPTR &&
            IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
            GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr) > 0)
        {
            ptfGblSynthTab = (DBA_DYNFLD_STP *)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
            int nbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr);
            for (int j = 0; j < nbr; ++j)
            {
                if (FIN_FilterGlobalPtfSynth(ptfGblSynthTab[j], A_PtfSynth, ptfSynthPtr[fromIdx]))
                {
                    ptfGblSynthRec = ptfGblSynthTab[j];
                    ptfGblSynthNbr++;
                }
            }
			if (ptfGblSynthTab != NULL)
			{
				gblArrayUsed = TRUE;
			}
        }
        else
        {
            /* REF10276 - LJE - 040512 */
			if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, 
												       A_PtfSynth, 
												       A_PtfSynth_MktSegtId,
												       nullValueSt,
												       FALSE,
					                                   FIN_FilterGlobalPtfSynth, 
												       ptfSynthPtr[fromIdx], 
						                               FIN_CmpReturnPtfSynth,
												       FALSE,
					                                   &ptfGblSynthNbr, 
												       &ptfGblSynthTab)) != RET_SUCCEED ||
                                                       ptfGblSynthNbr <= 0 )
            {
                FREE_DYNST(aGblPtfReturn, A_PtfReturn);
                FREE(ptfGblSynthTab);
                return(ret);
            }

            ptfGblSynthRec = ptfGblSynthTab[0];
            FREE(ptfGblSynthTab);
        }

        if (ptfGblSynthNbr != 1)
        {
            FREE_DYNST(aGblPtfReturn, A_PtfReturn);
            return(ret);
        }

        if ((ret=FIN_Return(GET_DATETIME(ptfSynthPtr[fromIdx], A_PtfSynth_InitialDate), 
							GET_DATETIME(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalDate), 
							ReturnMet_MWR,
							taxCredFlg, 
							grossEffectFlg, 
							grossFeesFlg,
							grossTaxFlg, 
							GET_FLAG(argPtr, MeanCapReturn_Arg_RiskFlg), 
							(ANNUALISERULE_ENUM)GET_ENUM(argPtr, MeanCapReturn_Arg_AnnualRuleEn),
							excludeIncFlg,
							GET_FLAG(argPtr, MeanCapReturn_Arg_AlwaysInitialDtFlg),
							GET_FLAG(argPtr, MeanCapReturn_Arg_RetContribFlg),
                            GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosFeesFlg), /* REF11269 - LJE - 051220 */
                            GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosTaxFlg),  /* REF11269 - LJE - 051220 */
							gblSynthArray,
							gblSynthArray, /* WEALTH-2637 - DDV - 231017 - It must be given to avoid message in log file */
							GET_ID(ptfGblSynthRec, A_PtfSynth_PtfId),
							GET_ID(ptfGblSynthRec, A_PtfSynth_GridId),
							GET_ID(ptfGblSynthRec, A_PtfSynth_MktSegtId),
							GET_ID(ptfGblSynthRec, A_PtfSynth_InstrId),
							hierHead, 
							ptfGblSynthRec,
							aGblPtfReturn)) != RET_SUCCEED )
		{
			FREE_DYNST(aGblPtfReturn, A_PtfReturn); 
		    return(ret);
		}

		meanCap = GET_NUMBER(aGblPtfReturn, A_PtfReturn_MeanCap);
		FREE_DYNST(aGblPtfReturn, A_PtfReturn);
	}

	SET_NUMBER(ptfRetPtr, A_PtfReturn_MeanCapGlobal, meanCap);
	/* Save the initial and final num days into the optimization structure */
    SET_NUMBER(ptfRetPtr, A_PtfReturn_InitNumDays, *initD);  /* PMSTA-11731 - LJE - 110420 */
    SET_NUMBER(ptfRetPtr, A_PtfReturn_FinalNumDays, *finalD); /* PMSTA-11731 - LJE - 110420 */

    /* REF7634 - LJE - 020703 */
	if (CMP_AMOUNT(meanCap, 0.0, currId) == 0 || ret != RET_SUCCEED)
	{
		for (fld=A_PtfReturn_RealCapProfit; fld<A_PtfReturn_MeanCap; fld++)
		{ 	
			SET_NUMBER(ptfRetPtr, fld, 0.0); 
		}

        /* REF11269 - LJE - 051230 */
        SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, 0.0);
        SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax, 0.0);

		/* WEALTH-3330 - DDV - 240711 */
		for (fld = A_PtfReturn_RealEffect; fld <= A_PtfReturn_UnrealEffect; fld++)
		{
			SET_NUMBER(ptfRetPtr, fld, 0.0); 
		}

        DATE_StopTimer(&SV_KeywordPeriodPtfReturn, TIMER_MASK_ALL);
		return(RET_SUCCEED);
	}


	/* ------------ */
	/* TOTAL RETURN */
	/* ------------ */
	amt = (GET_AMOUNT(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalMktVal) -
	       GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal) - flows) / meanCap; /* REF7634 - LJE - 020619 */

	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, amt); /* PMSTA-54389 - DDV - 231106 - Keep the max precision for return (remove CAST_NUMBER) */

	/* ------------------------------------------------------ */
	/* COUNTER FOR FEES, TAX, TAX CREDIT AND ACCRUED INTEREST */
    /* ------------------------------------------------------ */
	ptfFees = taxCred = ptfTax = recAccr = paidAccr = uRecAccr = uPaidAccr = posFees = posTax = 0.0;
	for (i=fromIdx; i<recNbr; i++)
	{ 	
	    /* PORTFOLIO FEES AND TAX, TAX CREDIT */
	    taxCred += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_TaxCred); 
	    ptfFees += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_PtfFees); 
	    ptfTax  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_PtfTax); 

        /* REF11269 - LJE - 051222 */
        /* POSITION FEES AND TAX, TAX CREDIT */
		posFees += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_PosFees); 
		posTax  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_PosTax); 

        /* RECEIVED AND PAID ACCRUED INTEREST */
	    recAccr  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_RecAccrInter);
	    paidAccr += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_PaidAccrInter);

	    /* UNREALISED RECEIVED AND PAID ACCRUED INTEREST */
	    uRecAccr  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_UnrealRecAccrInter);
	    uPaidAccr += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_UnrealPaidAccrInter);
	}

	/* ------------------------------------------------ */
	/* PORTFOLIO FEES AND TAX, TAX CREDIT               */
	/* (+ EFFECT with tax credit depend on taxCredFlg)  */
	/* ------------------------------------------------ */
	/* DVP165 */
	effect = 0;
	if (grossTaxFlg == FALSE) 	effect += ptfTax;
	if (grossFeesFlg == FALSE) 	effect += ptfFees;  /* REF7499 - CSY - 020423 
                                                    use grossFeesFlg instead of grossEffectFlg */
	if (taxCredFlg == FALSE) 	effect += taxCred;

	/* WEALTH-6254 - DDV - 240402 */
	if (GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosFeesFlg) == TRUE)
	{
			effect -= posFees;
	}

	/* WEALTH-6254 - DDV - 240402 */
	if (GET_FLAG(argPtr, MeanCapReturn_Arg_ExcludePosTaxFlg) == TRUE)
	{
			effect -= posTax;
	}

	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_TaxCredit, (taxCred / meanCap));    /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PortfFees, (ptfFees / meanCap));    /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PortfTax,  (ptfTax / meanCap));     /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PosFees, (posFees / meanCap));      /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PosTax,  (posTax / meanCap));       /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_FeesTaxEffect, (effect / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* -------------------------------------------------------------------- */
	/* RECEIVED AND PAID ACCRUED INTEREST (effect with gross or net income) */
	/* -------------------------------------------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RecAccrInterest, (recAccr / meanCap));   /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PaidAccrInterest, (paidAccr / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* -------------------------------------------------------------------- */
	/* UNREALISED RECEIVED AND PAID ACCRUED INTEREST (+ UNREALISED INCOME EFFECT) */
	/* -------------------------------------------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealRecAccrInterest, (uRecAccr / meanCap));	      /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealPaidAccrInterest, (uPaidAccr / meanCap));     /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealIncEffect, ((uRecAccr+uPaidAccr) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* ----------------------------------------------------------------------------------- */
	/* COUNTER FOR REALISED AND UNREALISED CURRENCY AND CAPITAL PROFIT AND LOSS AND INCOME */
    /* ----------------------------------------------------------------------------------- */
	realCapP = realCapL = realCurrP = realCurrL = recInc = paidInc = 0.0;
	uRealCapP = uRealCapL = uRealCurrP = uRealCurrL = 0.0;
	/* grossEffectFlg indicates whether the invest and withdrawal amts are gross or net amts */
	if (grossEffectFlg == TRUE)
	{
	    for (i=fromIdx; i<recNbr; i++)
	    { 	
	    	/* REALISED CAPITAL PROFIT AND LOSS */
	    	realCapP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossRealCapP);
	    	realCapL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossRealCapL);

	    	/* REALISED CURRENCY PROFIT AND LOSS */
		    realCurrP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossRealCurrP); /* WEALTH-7062 - DDV - 240910 - Fix Wrong Currency Effect */
		    realCurrL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossRealCurrL); /* WEALTH-7062 - DDV - 240910 - Fix Wrong Currency Effect */

	    	/* RECEIVED AND PAID INCOME */
			if (excludeIncFlg == FALSE) /* WEALTH-6254 - DDV - 240402 - If incomes are excluded don't sum them */

			{
				recInc  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossRecInc);
				paidInc += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossPaidInc);
			}

	    	/* UNREALISED CAPITAL PROFIT AND LOSS */
		    uRealCapP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossUnrealCapP);
		    uRealCapL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossUnrealCapL);

	    	/* UNREALISED CURRENCY PROFIT AND LOSS */
		    uRealCurrP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossUnrealCurrP);
		    uRealCurrL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_GrossUnrealCurrL);
	    }
	}
	else
	{
	    for (i=fromIdx; i<recNbr; i++)
	    { 	
	    	/* REALISED CAPITAL PROFIT AND LOSS */
		    realCapP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetRealCapP);
		    realCapL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetRealCapL);

	    	/* REALISED CURRENCY PROFIT AND LOSS */
		    realCurrP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetRealCurrP);
		    realCurrL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetRealCurrL);

	    	/* RECEIVED AND PAID INCOME */
			if (excludeIncFlg == FALSE) /* WEALTH-6254 - DDV - 240402 - If incomes are excluded don't sum them */
			{
				recInc  += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetRecInc);
				paidInc += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetPaidInc);
			}

	    	/* UNREALISED CAPITAL PROFIT AND LOSS */
		    uRealCapP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetUnrealCapP);
		    uRealCapL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetUnrealCapL);

	    	/* UNREALISED CURRENCY PROFIT AND LOSS */
		    uRealCurrP += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetUnrealCurrP);
		    uRealCurrL += GET_AMOUNT(ptfSynthPtr[i], A_PtfSynth_NetUnrealCurrL);
	    }
	}

	/* ---------------------------------- */
	/* CAPITAL PROFIT AND LOSS (+ EFFECT) */
	/* ---------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCapProfit, (realCapP / meanCap));            /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCapLoss, (realCapL / meanCap));              /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCapEffect, ((realCapP+realCapL) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* ----------------------------------- */
	/* CURRENCY PROFIT AND LOSS (+ EFFECT) */
	/* ----------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCurrProfit, (realCurrP / meanCap));             /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCurrLoss, (realCurrL / meanCap));               /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealCurrEffect, ((realCurrP+realCurrL) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* ----------------- */
	/* INCOME (+ EFFECT) */
	/* ----------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RecIncome, (recInc / meanCap));                                     /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_PaidIncome, (paidInc / meanCap));                                   /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealIncEffect, ((recInc + paidInc + recAccr + paidAccr) / meanCap)) /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	/* DVP232 */
	/*SET_NUMBER(ptfRetPtr, A_PtfReturn_IncomeEffect, ((recInc+paidInc+recAccr+paidAccr) / meanCap));*/

	/* --------------------------------------------- */
	/* UNREALISED CAPITAL PROFIT AND LOSS (+ EFFECT) */
	/* --------------------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCapProfit, (uRealCapP / meanCap));              /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCapLoss, (uRealCapL / meanCap));                /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCapEffect, ((uRealCapP+uRealCapL) / meanCap));  /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* ---------------------------------------------- */
	/* UNREALISED CURRENCY PROFIT AND LOSS (+ EFFECT) */
	/* ---------------------------------------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCurrProfit, (uRealCurrP / meanCap));               /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCurrLoss, (uRealCurrL / meanCap));                 /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealCurrEffect, ((uRealCurrP+uRealCurrL) / meanCap));  /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */
	
	/* -------------- */
	/* CAPITAL EFFECT */
	/* -------------- */
	/* BUG048 - RAK - 960705 */
    /* BUG037 - RAK - 960613 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_CapitalEffect, 
			   ((uRealCapP+uRealCapL+realCapP+realCapL) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* --------------- */
	/* CURRENCY EFFECT */
	/* --------------- */
	/* BUG048 - RAK - 960705 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_CurrentEffect, 
			   ((uRealCurrP+uRealCurrL+realCurrP+realCurrL) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* ------------- */
	/* INCOME EFFECT */
	/* ------------- */
	/* BUG048 - RAK - 960705 */
	/* DVP232 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_IncomeEffect, 
			   ((uRecAccr+uPaidAccr+recInc+paidInc+recAccr+paidAccr) / meanCap));  /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* --------------------------------------------- */
	/* REALISED EFFECT */
	/* --------------------------------------------- */
	/* PMSTA-51631  - SENTHIL KUMAR - 21122022 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_RealEffect, ((realCapP + realCapL + realCurrP + realCurrL + recInc + paidInc + recAccr + paidAccr + effect) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

	/* --------------------------------------------- */
	/* UNREALISED EFFECT */
	/* --------------------------------------------- */
	/* PMSTA-51631  - SENTHIL KUMAR - 21122022 */
	SET_NUMBER(ptfRetPtr, A_PtfReturn_UnrealEffect, ((uRealCapP + uRealCapL + uRealCurrP + uRealCurrL + uRecAccr + uPaidAccr) / meanCap)); /* PMSTA-54389 - DDV - 231106 - Keep the max precision (remove CAST_NUMBER) */

    DATE_StopTimer(&SV_KeywordPeriodPtfReturn, TIMER_MASK_ALL);

    /* REF5314 - CSY - 001018 */
    if (selSynthPtr == NULLDYNST && 
        (IS_NULLFLD(argPtr, MeanCapReturn_Arg_InstrId) == TRUE ||
         IS_NULLFLD(argPtr, MeanCapReturn_Arg_MktSgtId) == TRUE)) /* REF11193 - LJE - 050512 */
    {
        DATE_StartTimer(&SV_KeywordPeriodReturnOptimiSet, TIMER_MASK_ALL);
        /* save return method (if TWR) */
        returnMethod = (RETURNMET_ENUM)GET_ENUM(argPtr, MeanCapReturn_Arg_MethodEn); /* REF7264 - LJE - 020131 */

	    /* REF5314 - RAK - 001106 - Change from and till date too */
	    fromDate = GET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate);
	    tillDate = GET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate);

        /* put the MWR in cache memory */
        SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn,       (ENUM_T) ReturnMet_MWR);
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate,  
 	        GET_DATETIME(ptfSynthPtr[fromIdx], A_PtfSynth_InitialDate));
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate,  
	        GET_DATETIME(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalDate));

        ret = DBA_SetMemory(OptiFct, UNUSED, MeanCapReturn_Arg, argPtr,
			                    A_PtfReturn, ptfRetPtr, Opti_Local);
        /* reset returnMethod (it may be TWR) */
        SET_ENUM(argPtr,     MeanCapReturn_Arg_MethodEn, (ENUM_T) returnMethod);
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_FromDate, fromDate);
	    SET_DATETIME(argPtr, MeanCapReturn_Arg_TillDate, tillDate);
        setMWRCounter++;
        DATE_StopTimer(&SV_KeywordPeriodReturnOptimiSet, TIMER_MASK_ALL);
    }

    
    return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    : FIN_InternalRateReturn()
**
**  Description : Calculate the internal rate of return          
**                This is the discount rate that equals the start-of-period    
**                value to the sum of the discounted cash flows, including the 
**                end-of-period value. It is referred to as the (BAI) Bank    
**                Administration Institute method AIMR                       
**
**  Arguments   : fromDate       from date
**                tillDate       till date
**                taxCredFlg     indicates whether tax credits are to be 
**                               included as withdrawals from the system
**                grossEffectFlg indicates whether the investment and 
**                               withdrawal amounts are Gross or Net amounts
**		          grossFeesFlg   indicates whether portfolio fees are to be
**                               included as withdrawals from the portfolio
**		          grossTaxFlg    indicates whether portfolio taxes are to be
**                               included as withdrawals from the portfolio
**                crtPtfSynth    pointer on portfolio synthetic data list     
**                ptfSynthNbr    portfolio synthetic data number
**                ptfReturn      A_PtfReturn structure to be filled
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : DVP004 - RAK _ 960308 
**
**  Modif       : BUG037 - RAK - 960614
**                BUG048 - RAK - 960705
**                DVP165 - RAK - 960823
**                REF7395 - CSY - 020808: prevSynthPtr (for adjustment)
**                REF9082 - TEB - 030619: Suppress Tech call for Irate
**				  REF10663 - TEB - 041115
**
*************************************************************************/
STATIC RET_CODE	FIN_InternalRateReturn(DATETIME_T        fromDate,
				                       DATETIME_T        tillDate,
		    		                   FLAG_T            taxCredFlg,
		                               FLAG_T            grossEffectFlg,
		    		                   FLAG_T            grossFeesFlg,	 /* DVP165 - RAK - 960823 */
		                               FLAG_T            grossTaxFlg,	 /* DVP165 - RAK - 960823 */
                                       FLAG_T            excludeIncFlg,  /* REF4254 - RAK - 000105 */
									   FLAG_T            alwaysInitialDtFlg, /* REF7634 - LJE - 020619 */
                                       FLAG_T            excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
                                       FLAG_T            excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
	                                   FLAG_T            retContribFlg,      /* WEALTH-2417 - DDV - 231004 */
                                       DBA_DYNFLD_STP    selSynthPtr,
                                       DBA_DYNFLD_STP    *crtPtfSynth, 
                                       int               ptfSynthNbr,
                                       DBA_DYNFLD_STP    gblSynthArray,
				                       DBA_DYNFLD_STP    ptfRetPtr,
                                       double            *initD,
                                       double            *finalD,
                                       DBA_HIER_HEAD_STP hierHead,
                                       DBA_DYNFLD_STP    argPtr)
{
    DBA_DYNFLD_STP          prevSynthPtr=NULLDYNST; /* REF7395 - CSY - 020808 */
	double                  iRate=0.0, *flowArray, *periodArray, diffDays;
	double                  meanCap=0.0, meanCapFlows=0.0;
    int                     flowNbr, i;
	FLAG_T                  finalFlg;
    /* INVESTTIMINGRULE_ENUM       timingRule;  REF4254 - RAK - 000317 */
	RET_CODE                ret=RET_SUCCEED;
    AMOUNT_T                iniMktVal;          /* REF9082 - TEB - 030619 */

    /* REF4254 - RAK - 000106 */
    /* GEN_GetApplInfo(ApplRetInvestTimingRule, &timingRule);

    if ((ret = FIN_CalcPtfDailyFlg(crtPtfSynth[0], ptfSynthNbr,
                                   hierHead, &dailyFlg)) != RET_SUCCEED)
        return(ret); 
    */

    /* Compute final num days according to timingRule and final market value */
    /* FIN_CalcFinalNumDays(crtPtfSynth[0],          
                         crtPtfSynth[ptfSynthNbr-1],   
                         timingRule,
                         &modifFinalD,
                         finalD); 
    */

    /* Compute initial num days */
    /* if ((ret = FIN_CalcInitNumDaysAndInterm(&(crtPtfSynth[0]), ptfSynthNbr,
                                            timingRule, dailyFlg,
                                            &begRec, &modifInitD, initD,
                                            NULL, NULL, NULL)) != RET_SUCCEED)
    {
        return(ret);
    }
    */

    /* PMSTA-47578 - DDV - 220510 - New function to compute mean cap when NIP information are availabe */
    DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr();

    /* PMSTA-47578 - DDV - 220318 - New function to compute mean cap when NIP information are availabe */
    if (domainPtr != NULLDYNST &&
        GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
    {
        ret = FIN_CalcMeanInvestedCapWithNIP(crtPtfSynth, 0, ptfSynthNbr, taxCredFlg,
                                             grossEffectFlg, grossFeesFlg, grossTaxFlg,
                                             excludeIncFlg,
                                             alwaysInitialDtFlg,
                                             excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
			                                 retContribFlg,
                                             selSynthPtr,  /* REF7634 - LJE - 020618 */
											 gblSynthArray,
                                             &meanCapFlows, &meanCap, initD, finalD,
                                             fromDate, tillDate, hierHead);   /* REF7395 - CSY - 020430 */
    }
    else
    {
        ret = FIN_CalcMeanInvestedCap(crtPtfSynth, 0, ptfSynthNbr, taxCredFlg,
            grossEffectFlg, grossFeesFlg, grossTaxFlg,
            excludeIncFlg,
            alwaysInitialDtFlg,
            excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
            selSynthPtr,  /* REF7634 - LJE - 020618 */
			gblSynthArray,	/* PMSTA-55377 - Deepthi - 240117 */
            &meanCapFlows, &meanCap, initD, finalD,
            fromDate, tillDate,   /* REF7395 - CSY - 020430 */
            hierHead);
    }

    /* REF4254 - RAK - 000106 */
	/* DATE_DaysBetween(fromDate.date, tillDate.date, AccrRule_Actual_Actual, &diffDays); */
    diffDays = (*finalD) - (*initD);
	if (diffDays == 0.0)
	{
        /* y'en a trop et c'est pas grave
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_InternalRateReturn", 
			 "0 days between from and till date");
        */
	    return(RET_GEN_ERR_INVARG);
	}

	if (ptfSynthNbr == 1) 
		flowNbr = 2;
	else
		flowNbr = ptfSynthNbr+1;

	if ((flowArray = (double *)CALLOC(flowNbr, sizeof(double))) == NULL)  /* REF7264 - LJE - 020131 */
	{
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	} 

	if ((periodArray = (double *)CALLOC(flowNbr, sizeof(double))) == NULL) /* REF7264 - LJE - 020131 */
	{
	    FREE(flowArray);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	} 

    /* REF9082 - TEB - 030619 */

	/* First record is initial period, use initial market value */
    iniMktVal = GET_AMOUNT(crtPtfSynth[0], A_PtfSynth_InitialMktVal); /* REF9082 - TEB - 030619 */

	if (ptfSynthNbr == 1) 
	{
	    flowNbr = 0;    /* flowNbr is incremented in FIN_UpdFlowPeriodArray() */

	    /* Unique flow */
	    finalFlg = FALSE;
	    FIN_UpdFlowPeriodArray(fromDate, tillDate, diffDays, grossEffectFlg, 
				               taxCredFlg, grossFeesFlg, grossTaxFlg, excludeIncFlg, 
                               finalFlg,
                               excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
                               crtPtfSynth[0], 
                               prevSynthPtr,    /* REF7395 - CSY - 020808: used for adjustment */
                               *initD, 
                               flowArray, periodArray, &flowNbr);

	    /* Final market value */
	    finalFlg = TRUE;
	    FIN_UpdFlowPeriodArray(fromDate, tillDate, diffDays, grossEffectFlg, 
				               taxCredFlg, grossFeesFlg, grossTaxFlg, excludeIncFlg, 
                               finalFlg, 
                               excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
                               crtPtfSynth[0], 
                               prevSynthPtr,    /* REF7395 - CSY - 020808: used for adjustment */
                               *initD, 
                               flowArray, periodArray, &flowNbr);
	}
	else
	{
	    /* Read investment and withdrawal counters */
	    for (flowNbr=0, i=0, finalFlg=FALSE; i<ptfSynthNbr; i++)
	    {
            if(i > 0)    /* REF7395 - CSY - 020808: used for adjustment */
            {
                prevSynthPtr = crtPtfSynth[i-1];
            }

		    /* Flows */
	        FIN_UpdFlowPeriodArray(fromDate, tillDate, diffDays, grossEffectFlg, 
				                   taxCredFlg, grossFeesFlg, grossTaxFlg, excludeIncFlg, finalFlg, 
                                   excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
				                   crtPtfSynth[i], 
                                   prevSynthPtr,    /* REF7395 - CSY - 020808: used for adjustment */
                                   *initD, 
                                   flowArray, periodArray, &flowNbr);

	        /* Final market value */
	        if (i == (ptfSynthNbr-1))
		    {
		        finalFlg = TRUE;
	            FIN_UpdFlowPeriodArray(fromDate, tillDate, diffDays, grossEffectFlg,
					                   taxCredFlg, grossFeesFlg, grossTaxFlg, excludeIncFlg, 
                                       finalFlg, 
                                       excludePosFeesFlg, excludePosTaxFlg, /* REF11269 - LJE - 051220 */
                                       crtPtfSynth[i], 
                                       prevSynthPtr,    /* REF7395 - CSY - 020808: used for adjustment */
                                       *initD, 
                                       flowArray, periodArray, &flowNbr);
		    }
	    }
	}

    /* REF4254 - RAK - 000307 */
	/* new periodArray table organisation   */
	/* OLD		NEW			                */
	/* 0.1		0.1 (same)		            */
	/* 0.3		0.2 (0.3 - 0.1)		        */
	/* 0.5		0.2 (0.5 - 0.3)		        */
	/* 0.7		0.2 (0.7 - 0.5)		        */
	/* 1.0		0.3 (1.0 - 0.7)		        */
	if (flowNbr != 0)
	{
		for (i=flowNbr-1; i>0; i--)
			periodArray[i] = periodArray[i] - periodArray[i-1];
	}

    /* si npv = 0 et premier flux � 1.0 -> n-1 period � 0 */
    /* REF4254 - RAK - 000413 */
    if (flowNbr >=2 &&
        CMP_NUMBER(iniMktVal, 0.0) == 0 && /* REF9082 - TEB - 030619 */
        CMP_NUMBER(periodArray[0], 1.0) == 0)
    {
        periodArray[0] = 0.0;
        periodArray[flowNbr-1] = 1.0;
    }

    /* REF4254 - RAK - 000411 */
    /* Suppress last flow if it occurs on last date */
    if (flowNbr-2 >= 0 &&
        CMP_NUMBER(periodArray[flowNbr-1], 0.0) == 0)    
    {
        flowArray[flowNbr-2] = flowArray[flowNbr-2] + flowArray[flowNbr-1];
        flowNbr = flowNbr-1;
    }

	if (flowNbr != 0)	/* BUG181 - can't occurs */
	{
        iRate = 0.0;                               /* REF9082 - TEB - 030619 */

		/* REF10663 - TEB - 041115 */
		ret = FIN_IRate(iniMktVal,
						periodArray,
						flowArray,
						flowNbr,
						&iRate);

	    if (ret == RET_SUCCEED)
        {
            /* REF4254 - RAK - 000317 */
            /* If mean invested capital is negative, the returns should be multiplied by -1 */
            /* REF9072 - LJE - 030502 : Remove absolute value 
                if (CMP_AMOUNT(meanCap, 0.0, GET_ID(crtPtfSynth[0], A_PtfSynth_CurrId)) == -1)
                    iRate *= -1.0;
             */

		    SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, iRate);	/* BUG048 - RAK - 960705 */
        }
    }
	else
	{
	    SET_NUMBER(ptfRetPtr, A_PtfReturn_TotalReturn, 0.0);
	    ret = RET_GEN_ERR_INVARG;
	    MSG_SendMesg(ret, 1, FILEINFO, "FIN_InternalRateReturn", "no flow");
	}

	FREE(flowArray);    /* SET_ARRAY = memory allocation and copy */
	FREE(periodArray);

	return(ret);
}

/************************************************************************
**
**  Function    : FIN_IRate()
**
**  Description : Compute the internal rate of return
**
**  Arguments   : iniMktVal		initiale market value
**                periodArray   pointer on period array
**                flowArray     pointer on flows array
**                flowNbr       flows number
**                iRate			pointer on returned internal rate
**
**  Return      : RET_SUCCEED or error code 
**
**  Creation  	: REF10663 - TEB - 041115
**
**  Modification: 
**
*************************************************************************/
STATIC RET_CODE FIN_IRate(AMOUNT_T  iniMktVal,
						  double	*periodArray,
						  double	*flowArray,
						  int		flowNbr,
						  double	*iRate) 
{
	RET_CODE			ret=RET_SUCCEED;
	IRRCOMPRULE_ENUM	irrCompRule;
	double				U, W, Y, Z, A, B, C, D;

	/* Init */
	*iRate = 0.0;

	GEN_GetApplInfo(ApplIrrCompRule, &irrCompRule);

	/* If we have more than 3 flows,
	 * we have to use an iterativ resolution
	 * otherwise we can use simple methode
	 */
	if (flowNbr > 2)
	{
		if (RET_SUCCEED!=SCE_CallIrr_OamsCompute(irrCompRule,
												iniMktVal,
												flowArray,
												periodArray,
												flowNbr,
												iRate))
		{
			ret = RET_GEN_ERR_INVARG;
		}
	}
	else if (flowNbr < 1)
	{
		ret = RET_GEN_ERR_INVARG;
	}
	else
	{
		/* Use different formulas in function of the irr rule,
		 * this formulas come from CGU and her XLS file,
		 * please refer to the Notes
		 */
		switch (irrCompRule)
		{
			case IrrCompRule_Compound:
				if (flowNbr == 2)
				{
					if (RET_SUCCEED!=SCE_CallIrr_OamsCompute(irrCompRule,
															iniMktVal,
															flowArray,
															periodArray,
															flowNbr,
															iRate))
					{
						ret = RET_GEN_ERR_INVARG;
					}

/* Following block was a solution by approximation 
 * But now I have implemented the Iterativ solution, we are more precise
 * and do no nead anymore following.
 * But I let the code, may be one day we need it... :-p
 */
#if 0
*					if (ret == RET_SUCCEED  &&
*						iniMktVal      == 0 &&
*						flowArray[1]   != 0)
*					{
*						/* Init */
*						Y = flowArray[0];
*						Z = flowArray[1];
*						X = periodArray[1];
*
*						/* Avoid zero division */
*						if (X == 0 || Y == 0)
*						{
*							ret = RET_GEN_ERR_INVARG;
*						}
*						else
*						{
*							/* Formula is */
*							*iRate = pow((0-(Z/Y)),(1/X)) -1;
*						}
*					}
*					else if (ret == RET_SUCCEED &&
*						iniMktVal      != 0 &&
*						flowArray[1]   == 0 &&
*						flowArray[0]   != 0 )
*					{
*						/* Init */
*						U = iniMktVal;
*						W = periodArray[0];
*						Y = flowArray[0];
*
*						/* Avoid zero division */
*						if (W == 0)
*						{
*							ret = RET_GEN_ERR_INVARG;
*						}
*						else
*						{
*							/* Formula is */
*							*iRate = pow((Y/U),(1/W)) -1;
*						}
*					}
*					/* Avoid zero division */
*					else if (ret == RET_SUCCEED &&
*						(iniMktVal      == 0 ||
*						 periodArray[0] == 0 ||
*						 periodArray[1] == 0 ||
*						 flowArray[0]   == 0 ))
*					{
*						ret = RET_GEN_ERR_INVARG;
*					}
*					else
*					{
*						/* Init */
*						U = iniMktVal;
*						W = periodArray[0];
*						X = periodArray[1];
*						Y = flowArray[0];
*						Z = flowArray[1];
*
*						/* Avoid zero division */
*						if ((U-X*Y) == 0)
*						{
*							ret = RET_GEN_ERR_INVARG;
*						}
*						else
*						{
*							/* Formula is */
*							A = X*W*Y;
*							B = X*Y-U;
*							C = Z+Y-U;
*
*							D = B*B +4*A*C;
*
*							P = (Z-U+Y)/(U-X*Y);
*							Q = (B+sqrt(D))/(2*A);
*
*							*iRate = (P+Q)/2;
*						}
*					}
#endif
				}
				else
				{ /* flowNbr == 1 */
					if (ret == RET_SUCCEED &&
						iniMktVal != 0)
					{
						/* Formula is */
						*iRate = (flowArray[0]/iniMktVal)-1;
					}
					else
					{
						ret = RET_GEN_ERR_INVARG;
					}
				}

				break;

			case IrrCompRule_CompoundSimple:
				if (flowNbr == 2)
				{
					if (ret == RET_SUCCEED  &&
						iniMktVal      == 0 &&
						flowArray[1]   != 0)
					{
						/* Init */
						W = periodArray[0];
						Y = flowArray[0];
						Z = flowArray[1];

						/* Avoid zero division */
						if ( (D = (0-Y-Z*W)) == 0)
						{
							ret = RET_GEN_ERR_INVARG;
						}
						else
						{
							/* Formula is */
							*iRate = (Z+Y)/D;
						}
					}
					/* Avoid zero division */
					else if (ret == RET_SUCCEED &&
							 (iniMktVal      == 0 ||
							  periodArray[0] == 0))
					{
						ret = RET_GEN_ERR_INVARG;
					}
					else
					{
						/* Init */
						U = iniMktVal;
						W = periodArray[0];
						Y = flowArray[0];
						Z = flowArray[1];

						/* Formula is */
						A = U*W;
						B = U - Y + W*(U-Z);
						C = U-Z-Y;

						D = B*B -4*A*C;

						*iRate = (sqrt(D)-B)/(2*A);
					}
				}
				else
				{ /* flowNbr == 1 */
					if (ret == RET_SUCCEED &&
						iniMktVal != 0)
					{
						/* Formula is */
						*iRate = (flowArray[0]/iniMktVal)-1;
					}
					else
					{
						ret = RET_GEN_ERR_INVARG;
					}
				}
				break;

			default :
				ret = RET_GEN_ERR_INVARG;
				break;
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    : FIN_UpdFlowPeriodArray()
**
**  Description : Fill flowArray and periodArray depending on received 
**                flag and portfolio synthetic data.
**
**  Arguments   : taxCredFlg     indicates whether tax credits are to be 
**                               included as withdrawals from the system
**                grossEffectFlg indicates whether the investment and 
**                               withdrawal amounts are Gross or Net amounts
**		  grossFeesFlg   indicates whether portfolio fees are to be
**                               included as withdrawals from the portfolio
**		  grossTaxFlg    indicates whether portfolio taxes are to be
**                               included as withdrawals from the portfolio
**                crtPtfSynth    pointer on current portfolio synthetic data
**                prevSynthPtr   pointer on previous portfolio synthetic data (for adjustment)
**                flowArray      pointer on flow array
**                periodArray    pointer on period array
**                flowNbr        pointer on flow number
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : BUG037 - RAK - 960614
**  
**  Modif       : BUG046 - RAK - 960628
**                DVP165 - RAK - 960823
**                BUG181 - RAK - 961016
**                REF7395 - CSY - 020808: add argument prevSynthPtr for adjustment
**
*************************************************************************/
STATIC void FIN_UpdFlowPeriodArray( DATETIME_T      fromDate,
				                    DATETIME_T      tillDate,
				                    double          diffDays,
				                    FLAG_T          grossEffectFlg, 
				                    FLAG_T          taxCredFlg, 
				                    FLAG_T          grossFeesFlg,   /* DVP165 - RAK - 960823 */
				                    FLAG_T          grossTaxFlg, 	/* DVP165 - RAK - 960823 */
                                    FLAG_T          excludeIncFlg,  /* REF4254 - RAK - 000105 */
				                    FLAG_T          finalFlg,
                                    FLAG_T          excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
                                    FLAG_T          excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
				                    DBA_DYNFLD_STP  crtPtfSynth, 
                                    DBA_DYNFLD_STP  prevSynthPtr,   /* REF7395 - CSY - 020808 */
                                    double          initialDays,    /* REF4254 - RAK - 000106 */
				                    double          *flowArray, 
				                    double          *periodArray, 
				                    int             *flowNbr)
{
	AMOUNT_T flow, fInvest, fWithdr, fWinvest, fWwithdr;

	/* Flows is the periodic value of the sum of all the investment counters  */
	/* less the sum of all the withdrawal counters. "Tax credit flag" is used */
	/* to determine if tax credits are included in the withdrawal. "Gross     */
	/* effect flag" is used to determine if gross or net amounts are used.    */
	/* The last occurence is the "till date" value of the portfolio.          */

	/* BUG037 : FALSE */
	/* Periods indicate the timing of the flows and is computed in years  */
	/* The last occurence is the number of days between the till and from */
	/* dates divided by 365.25                                            */

	if (finalFlg == TRUE)
	{
	    /* BUG046 - RAK - 960628 */
	    /* if (GET_AMOUNT(crtPtfSynth, A_PtfSynth_FinalMktVal) != 0.0) */
	    /* BUG181 */
	    /* if (CMP_AMOUNT(GET_AMOUNT(crtPtfSynth, A_PtfSynth_FinalMktVal), 0.0, 
			    GET_ID(crtPtfSynth, A_PtfSynth_CurrId)) != 0) */
	    flowArray[(*flowNbr)]   = GET_AMOUNT(crtPtfSynth, A_PtfSynth_FinalMktVal);
	    periodArray[(*flowNbr)] = 1.0;
	    ++(*flowNbr);
	}
	else
	{
	    /* REF4254 - Use initial days according to all received synthetics */
        /* initialDays = GET_INT(crtPtfSynth, A_PtfSynth_InitialNumDays); */

	    fInvest=fWithdr=fWinvest=fWwithdr=0.0;

        /* REF4254 - RAK - 000105 - So they are always computed by same way */
        FIN_CalcInvestAndWithdr(crtPtfSynth, 
                                prevSynthPtr,   /* REF7395 - CSY - 020808 */
                                taxCredFlg, grossEffectFlg, grossFeesFlg,
			   		            grossTaxFlg, excludeIncFlg, 
                                FALSE, excludePosFeesFlg, excludePosTaxFlg,  /* REF11269 - LJE - 051220 */
                                0, 0.0,      /* not used (for intermediate) */
                                NULL, &fInvest,  &fWithdr,  
                                &fWinvest, &fWwithdr, 
                                (AMOUNT_T*)NULL, (AMOUNT_T*)NULL,
                                (AMOUNT_T*)NULL,
                                fromDate, tillDate);    /* REF7395 - CSY - 020430 */                            

	    /* BUG181 - withdrawal is negative */
	    flow = (-1.0 * fInvest) + (-1.0 * fWithdr);

	    if (CMP_AMOUNT(flow, 0.0, GET_ID(crtPtfSynth, A_PtfSynth_CurrId)) != 0)
	    {
		    flowArray[(*flowNbr)] = flow;

		    /* BUG037 - RAK - 960618 */	/* BUG181 */
		    periodArray[(*flowNbr)] = 
		      (((fWinvest + fWwithdr) / (fInvest + fWithdr)) - initialDays) / diffDays;
            periodArray[(*flowNbr)] = CAST_NUMBER(periodArray[(*flowNbr)]);
		    ++(*flowNbr);
	    }
	}
}

/************************************************************************
**
**  Function    :  FIN_CalcMeanInvestedCap()
**
**  Description :  Computes mean invested capital for received period 
**                 (from and till record)
**                 
**  Arguments   :  ptfSynthPtr    pointer on portfolio synthetic data records
**                 fromIdx        index on record with initial date equal to the from date
**                 recNbr         number of record to read until final date is equal to till date
**                                It can be only one record.
**                 taxCredFlg     indicates whether tax credits are to be 
**                                included as withdrawals from the system
**                 grossEffectFlg indicates whether the investment and 
**                                withdrawal amounts are Gross or Net amounts
**		           grossFeesFlg   indicates whether portfolio fees are to be
**                                included as withdrawals from the portfolio
**		           grossTaxFlg    indicates whether portfolio taxes are to be
**                                included as withdrawals from the portfolio
**                 flowsPtr       pointer on flow sum to update
**                 meanCapPtr     pointer on mean invested capital to update
**
**  Return      :  RET_SUCCEED or error code
**                 meanCapPtr is updated with computed mean invested capital
**
**  Creation    :  DVP004 - RAK - 960306 
** 
**  Modif       :  BUG037 - RAK - 960613
**                 BUG096 - RAK - 960812
**                 DVP165 - RAK - 960823
**                 BUG174 - RAK - 961010
**                 DVP232 - RAK - 961105
**                 BUG378 - RAK - 970527 - suppress PaidAccrInt, RecAccrInt
**                 BUG499 - RAK - 970910 - first flow for instrument, grid, global level
**                 REF1008 - RAK - 980113  
**                 REF2448 - RAK - 980703  
**                 REF2552 - RAK - 980721  
**                 REF2552 - bis - RAK - 981020  
**                 REF3064 - RAK - 981124
**                 REF3086 - RAK - 990118
**                 REF4222 - CSY - 991217 add arguments excludeIncFlg and selSynthPtr
**                 REF5703 - RAK - 010221 Verify if flow is only composed by incomes
**                 REF7395 - CSY - 020430: new arguments fromDate, tillDate
**
*************************************************************************/
STATIC RET_CODE FIN_CalcMeanInvestedCap(DBA_DYNFLD_STP *ptfSynthPtr,
					                    int             fromIdx,
				    	                int             recNbr,
					                    FLAG_T          taxCredFlg,
					                    FLAG_T          grossEffectFlg,
			   		                    FLAG_T          grossFeesFlg,	    /* DVP165 - RAK - 960823 */
			   		                    FLAG_T          grossTaxFlg,	    /* DVP165 - RAK - 960823 */
                                        FLAG_T          excludeIncFlg,      /* REF4222 - CSY - 991217 */
										FLAG_T          alwaysInitialDtFlg, /* REF7634 - LJE - 020618 */
                                        FLAG_T          excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
                                        FLAG_T          excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
                                        DBA_DYNFLD_STP  selSynthPtr,        /* REF4222 - CSY - 991217 */
										DBA_DYNFLD_STP  gblSynthArray,		/* PMSTA-55377 - Deepthi - 240117 */
					                    double          *flowsPtr,
					                    double          *meanCapPtr,
                                        double          *initD,             /* REF4253 - RAK - 000106 */
                                        double          *finalD,            /* REF4253 - RAK - 000106 */
                                        DATETIME_T        fromDate,         /* REF7395 - CSY - 020430 */
                                        DATETIME_T        tillDate,         /* REF7395 - CSY - 020430 */
                                        DBA_HIER_HEAD_STP hierHead)
{
    AMOUNT_T        weightFlows, invest, withdr, wInvest, wWithdr, iInvest, iWithdr, adjust;
    INVESTTIMINGRULE_ENUM 	investTimingRule;
	int	 		    fD, intermDNbr = 0, * intermDPtr = (int*)NULL, nbrZeroD = 0, findIntermD = -1;
    double   		timingRuleD, intermD=0.0;
	DBA_DYNFLD_STP 	finalRec=NULLDYNST, begRec=NULLDYNST;
	int      		i, j;
	FLAG_T			modifFinalD=TRUE, modifInitD=TRUE, dailyFlg=FALSE, 	/* REF3064 */
                    onlyIncFlg=TRUE; /* REF5703 - RAK - 010221 */
    DBA_DYNFLD_STP  prevSynthPtr = NULLDYNST; /* REF7395 - CSY - 020808: previous synthetic */
    RET_CODE        ret=RET_SUCCEED;
    FLAG_T          getOnlyInvestFlg = FALSE; /* PMSTA00816 - RAK - 070402 */
	MemoryPool      mp;

    /* REF4253 - RAK - 000106 */
    *initD  = 0.0;
    *finalD = 0.0;

    GEN_GetApplInfo(ApplRetInvestTimingRule, &investTimingRule);

	/* REF3086 - Get portfolio frequency ... */
    if ((ret = FIN_CalcPtfDailyFlg(ptfSynthPtr[fromIdx], recNbr, 
                                   hierHead, &dailyFlg)) != RET_SUCCEED)
        return(ret);

	/* ------------------------------------------------------------------------------------- */
	/* Mean invested capital is MVal0 + (((days1 * flows) - weighted flows) / (days1-days0)) */
	/* MVal0 = initial market value at the beginning of the period                           */
	/* days1 = number of days from system date till the period end date                      */
	/* days0 = number of days from system date till the period start date                    */
	/* flows = (sum of investment at end date - sum of investment at start date) -           */
	/*         (sum of withdrawal at end date - sum of withdrawal at start date)             */
	/* weighted flows = (sum of weighted investment at end date -                            */
	/*                   sum of weighted investment at start date) -                         */
	/*                  (sum of weighted withdrawal at end date -                            */
	/*                   sum of weighted  withdrawal at start date)                          */
	/* ------------------------------------------------------------------------------------- */

    /* REF4253 - RAK - 000106 - Create functions FIN_CalcFinalNumDays() */
    /*                         and FIN_CalcInitNumDaysAndInterm()      */
	fD = GET_INT(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalNumDays);
    finalRec = ptfSynthPtr[recNbr-1];

    /* Compute final num days according to investTimingRule and final market value */
    FIN_CalcFinalNumDays(ptfSynthPtr[fromIdx],      /* initial record */
                         finalRec,                  /* final record */
                         investTimingRule, 
						 alwaysInitialDtFlg,
                         &modifFinalD,
                         finalD,
                         hierHead);

    if ((ret = FIN_CalcInitNumDaysAndInterm(&(ptfSynthPtr[fromIdx]), gblSynthArray, recNbr-fromIdx,
                                            investTimingRule, dailyFlg, alwaysInitialDtFlg,
                                            &begRec, &modifInitD, initD,
                                            &intermDPtr, &intermDNbr, &nbrZeroD, hierHead)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* REF7658 - LJE - 020628 : Problem with meancap when the initial market value = 0 */
	if (TLS_Cmp(*finalD, *initD, SV_DefaultMaxPrecision) == 0 &&
		alwaysInitialDtFlg == FALSE &&
		modifInitD == TRUE && 
	    (CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal), 0.0, 
			                      GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0 ||
		 CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_FinalMktVal), 0.0, 
		                          GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0))
	{	
			switch(investTimingRule)
			{
			case InvestTimingRule_Mid :
				break;

			case InvestTimingRule_End :
				(*finalD)++; /* Correct the finalD for correctly compute the mean_cap */
				break;

			case InvestTimingRule_Beginning :
				break;
			}
	}

	/* REF3064 - if ((finalD - initD) == 0) */
	if ((*finalD) < (*initD)) /* REF11526 - LJE - 060119 */
	{
		*meanCapPtr = 0.0;
		*flowsPtr   = 0.0;
	        /* MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "FIN_CalcMeanInvestedCap", "days"); */
		
		/* REF4159 - memory leak - RAK - 991124 */
		if (intermDPtr != NULL)
		{ FREE(intermDPtr); }
		
		return(RET_FIN_ERR_INVDATA);
	}

	/* REF3086 - Compute number of days modification according to TimingRule */
	if (investTimingRule == InvestTimingRule_Beginning)
		timingRuleD = -1.0;
	else if (investTimingRule == InvestTimingRule_Mid)
		timingRuleD = -0.5;
	else 	/* InvestTimingRule_End  */
		timingRuleD = 0.0;

	/* DVP165 */
    invest = withdr = wInvest = wWithdr = iInvest = iWithdr = adjust = 0.0;
	for (j=0, i=fromIdx; i<recNbr; i++)
	{
	    /* intermediate date is                                          */
	    /* - finalD if all empty synthetics are before current synthetic */
	    /* - next empty synthetic date + timing rule elsewhere           */
	    if (dailyFlg == TRUE)
	    {
		    if (intermDNbr > 0)
		    {
			    findIntermD=-1;
			
			    for (j=0; j<intermDNbr && findIntermD == -1; j++)
				    if (GET_INT(ptfSynthPtr[i], A_PtfSynth_FinalNumDays) <= intermDPtr[j])
					    findIntermD = intermDPtr[j];

			    if (findIntermD != -1)
			    {
				    intermD = (double) findIntermD + timingRuleD;
			    }
			    else
				    intermD = (*finalD);
		    }
		    else
			    intermD = (*finalD);
	    }

        if(i > 0)   /* REF7395 - CSY - 020808 */
        {
            prevSynthPtr = ptfSynthPtr[i-1];
        }
        FIN_CalcInvestAndWithdr(ptfSynthPtr[i], 
                                prevSynthPtr,   /* REF7395 - CSY - 020808 */
                                taxCredFlg, grossEffectFlg, grossFeesFlg, grossTaxFlg,
                                excludeIncFlg, dailyFlg, excludePosFeesFlg, excludePosTaxFlg, nbrZeroD, intermD, /* REF11269 - LJE - 051220 */
                                &onlyIncFlg, &invest,  &withdr,  &wInvest, &wWithdr, 
                                &iInvest, &iWithdr, &adjust,
                                fromDate, tillDate);    /* REF7395 - CSY - 020430 */
	}

	/* -------------------------------- */
	/* BEGIN BUG037 -      RAK - 960613 */
	/* *flowsPtr = invest - withdr;     */
	/* weightFlows = wInvest - wWithdr; */
	*flowsPtr   = invest + withdr;
	weightFlows = wInvest + wWithdr;
	/* END BUG037          RAK - 960613 */
	/* -------------------------------- */

	/* PMSTA00816 - RAK - 070402 : If all flows are in one day, the mean capital is the sum of invest 
     *                              only if global level don't start by zero market value
     */
    if (TLS_Cmp(*finalD, *initD, 1.01) == 0 &&
        CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal), 0.0, 
                    GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0)
    {
        DBA_DYNFLD_STP * ptfGblSynthTab = NULL;
        int             ptfGblSynthNbr = 0;
		DBA_DYNFLD_STP  gblPtfSynthPtr = ptfSynthPtr[fromIdx];
		DBA_DYNFLD_ST   gblMktSegtId;

        memset(&gblMktSegtId, 0, sizeof(DBA_DYNFLD_ST)); /* PMSTA-02403 - LJE - 070514 */

		if (FIN_FilterGlobalPtfSynth(gblPtfSynthPtr, A_PtfSynth, ptfSynthPtr[fromIdx]) == FALSE)
		{
			gblPtfSynthPtr = NULLDYNST;

			/* PMSTA-55377 - Deepthi - 240117 - Use global port synthetic records from array (if available) in the Filter function,
										else use the hierachy records */
			if (gblSynthArray != NULLDYNSTPTR &&
				IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
				(GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr)) > 0)
			{
				ptfGblSynthTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
				ptfGblSynthNbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr);

				for (int idx = 0; idx < ptfGblSynthNbr && gblPtfSynthPtr == NULLDYNST; ++idx)
				{
					if (FIN_FilterGlobalPtfSynth(ptfGblSynthTab[idx], A_PtfSynth, ptfSynthPtr[fromIdx]))
					{
						gblPtfSynthPtr = ptfGblSynthTab[idx];
					}
				}
			}

			if (gblPtfSynthPtr == NULLDYNST)
			{
				if (DBA_ExtractHierEltRecByIndexKey(hierHead,
                                                    A_PtfSynth,
                                                    A_PtfSynth_MktSegtId,
                                                    gblMktSegtId, /* PMSTA-02403 - LJE - 070514 */
                                                    FALSE,
                                                    FIN_FilterGlobalPtfSynth,
                                                    ptfSynthPtr[fromIdx],
                                                    FIN_CmpReturnPtfSynth,
                                                    FALSE,
                                                    &ptfGblSynthNbr,
                                                    &ptfGblSynthTab) == RET_SUCCEED &&
				    ptfGblSynthNbr > 0)
				{
					mp.ownerPtr(ptfGblSynthTab);
					gblPtfSynthPtr = ptfGblSynthTab[0];
				}
				else
				{
					gblPtfSynthPtr = ptfSynthPtr[fromIdx];
				}
			}
	    }

        if (CMP_AMOUNT(invest, 0.0, GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) != 0 && /* PMSTA0???? - LJE - 080206 */
			CMP_AMOUNT(GET_AMOUNT(gblPtfSynthPtr, A_PtfSynth_InitialMktVal), 0.0, 
            GET_ID(gblPtfSynthPtr, A_PtfSynth_CurrId)) != 0) {
            getOnlyInvestFlg = TRUE;
        }

		/* PMSTA-9027 - RAK - 100906 - report PMSTA08647 - If final date is 0, we are in futur case */
		else if (CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_FinalMktVal), 0.0, 
						    GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0)
		{
			getOnlyInvestFlg = TRUE;
		}
    }

    /* REF5703 - RAK - 010221 */
    /* In case of flow is only composed by incomes, return (and meanCap) should be 0% */
    if (onlyIncFlg == TRUE && 
        CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal), 0.0, 
                   GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0 &&
        CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[recNbr-1], A_PtfSynth_FinalMktVal), 0.0,
                   GET_ID(ptfSynthPtr[recNbr-1], A_PtfSynth_CurrId)) == 0)
    {
        *meanCapPtr = 0.0;
    }
    else if (getOnlyInvestFlg) /* PMSTA00816 - RAK - 070402 */ /* If all flows are in one day, the mean capital is the sum of invest */ /* PMSTA-00634 - LJE - 061101 */
    {
        /* PMSTA-20363 - LJE - 150617 - Manage the risk origin case */
        if (CMP_NUMBER(adjust, 0.0) != 0 && CMP_NUMBER(invest, adjust) == 0)
        {
            *meanCapPtr = withdr;
        }
        else
        {
            *meanCapPtr = invest;
		}

		/* PMSTA-23520 - LJE - 160718 */
		if (investTimingRule == InvestTimingRule_Mid && alwaysInitialDtFlg == TRUE)
		{
			*meanCapPtr *= 0.5;
        }
    }
	else if (modifFinalD == FALSE) /* BUG096 - RAK - 960812 */ /* REF3064 - Mean capital is initial market value or investment */
    {
		*meanCapPtr = GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal);
    }
	else if (modifInitD == FALSE)
    {
		*meanCapPtr = invest + withdr;
    }
	else
	{
		/* if nbrZeroD > 0, intermDPtr[0] is set ... */
		if (dailyFlg == TRUE && nbrZeroD > 0)
        {
			*meanCapPtr = ((GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal) * 
					      ((intermDPtr[0] + timingRuleD) - (*initD))) +
				           (iInvest+iWithdr) - weightFlows) / ((*finalD) - (*initD) - nbrZeroD);
        }
		else
        {
	        *meanCapPtr = GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal) +
	                      ((((*finalD) * *flowsPtr) - weightFlows) / ((*finalD) - (*initD)));
        }
	}

	/* WEALTH-4573 - DDV - 240306 - remove rounding */
	/* *meanCapPtr = CAST_AMOUNT((*meanCapPtr), GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)); */

	if (intermDPtr != NULL)
	{ FREE(intermDPtr); }
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_FilterPrimaryGlobalSynthByPSP()
**
**  Description :   Keep only primary global PtfSynth for current psp
**
**
**  Arguments   :   input:
**                  hierHead            hierarchy header pointer
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   
**
*************************************************************************/
STATIC int DBA_FilterPrimaryGlobalSynthByPSP(DBA_DYNFLD_STP  dynSt,
											 DBA_DYNST_ENUM  dynStTp,
											 DBA_DYNFLD_STP  ptfSynthPtr)
{
	if (CMP_DYNFLD(dynSt, ptfSynthPtr, A_PtfSynth_PSPId, A_PtfSynth_PSPId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, ptfSynthPtr, A_PtfSynth_PtfId, A_PtfSynth_PtfId, IdType) == 0 && 
        (RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(dynSt, A_PtfSynth_GridLinkNatEn) != ReturnGridLnk_ParStorPtfSynth && /* no ParStorPtfSynth */
		GET_BIT(GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Primary) == TRUE &&
		IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == TRUE &&
		IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) == TRUE)
	{
		return(TRUE);
	}

	return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_CmpSynthDate
**
**  Description :   Synthetics sorted by date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   
**
*************************************************************************/
int DBA_CmpSynthDate(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
	int ret;

	if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_InitialDate, A_PtfSynth_InitialDate, DatetimeType)) != 0)
		return ret;

	if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_FinalDate, A_PtfSynth_FinalDate, DatetimeType)) != 0)
		return ret;

	return CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_Id, A_PtfSynth_Id, IdType);
}

/************************************************************************
**
**  Function    :  FIN_CalcMeanInvestedCapWithNIP()
**
**  Description :  Computes mean invested capital for received period
**                 (from and till record) when NIP period has been detected.
**
**  Arguments   :  ptfSynthPtr    pointer on portfolio synthetic data records
**                 fromIdx        index on record with initial date equal to the from date
**                 recNbr         number of record to read until final date is equal to till date
**                                It can be only one record.
**                 taxCredFlg     indicates whether tax credits are to be
**                                included as withdrawals from the system
**                 grossEffectFlg indicates whether the investment and
**                                withdrawal amounts are Gross or Net amounts
**		           grossFeesFlg   indicates whether portfolio fees are to be
**                                included as withdrawals from the portfolio
**		           grossTaxFlg    indicates whether portfolio taxes are to be
**                                included as withdrawals from the portfolio
**                 flowsPtr       pointer on flow sum to update
**                 meanCapPtr     pointer on mean invested capital to update
**
**  Return      :  RET_SUCCEED or error code
**                 meanCapPtr is updated with computed mean invested capital
**
**  Creation    :  PMSTA-47578 - DDV - 220307
**
**  Modif       :  
**                 
**
*************************************************************************/
STATIC RET_CODE FIN_CalcMeanInvestedCapWithNIP(DBA_DYNFLD_STP   *ptfSynthPtr,
	                                           int               fromIdx,
	                                           int               recNbr,
	                                           FLAG_T            taxCredFlg,
	                                           FLAG_T            grossEffectFlg,
	                                           FLAG_T            grossFeesFlg,	   /* DVP165 - RAK - 960823 */
	                                           FLAG_T            grossTaxFlg,	       /* DVP165 - RAK - 960823 */
	                                           FLAG_T            excludeIncFlg,      /* REF4222 - CSY - 991217 */
	                                           FLAG_T            alwaysInitialDtFlg, /* REF7634 - LJE - 020618 */
	                                           FLAG_T            excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
	                                           FLAG_T            excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
	                                           FLAG_T            retContribFlg,      /* WEALTH-2417 - DDV - 231004 */
	                                           DBA_DYNFLD_STP    selSynthPtr,        /* REF4222 - CSY - 991217 */
	                                           DBA_DYNFLD_STP    gblSynthArray,
	                                           double           *flowsPtr,
	                                           double           *meanCapPtr,
	                                           double           *initD,             /* REF4253 - RAK - 000106 */
	                                           double           *finalD,            /* REF4253 - RAK - 000106 */
	                                           DATETIME_T        fromDate,         /* REF7395 - CSY - 020430 */
	                                           DATETIME_T        tillDate,
	                                           DBA_HIER_HEAD_STP hierHead)         /* REF7395 - CSY - 020430 */
{
	AMOUNT_T        weightFlows, invest, withdr, wInvest, wWithdr, iInvest, iWithdr, adjust;
	double		    periodNbOfDays = 0;
	DBA_DYNFLD_STP 	firstRec = ptfSynthPtr[fromIdx];
	DBA_DYNFLD_STP 	lastRec = ptfSynthPtr[recNbr - 1];
	int      		i;
	FLAG_T			onlyIncFlg = TRUE;
	DBA_DYNFLD_STP  prevSynthPtr = NULLDYNST;
	MemoryPool		mp;

	/* ------------------------------------------------------------------------------------- */
	/* Mean invested capital is MVal0 + (((days1 * flows) - weighted flows) / (days1-days0)) */
	/* MVal0 = initial market value at the beginning of the period                           */
	/* days1 = number of days from system date till the period end date                      */
	/* days0 = number of days from system date till the period start date                    */
	/* flows = (sum of investment at end date - sum of investment at start date) -           */
	/*         (sum of withdrawal at end date - sum of withdrawal at start date)             */
	/* weighted flows = (sum of weighted investment at end date -                            */
	/*                   sum of weighted investment at start date) -                         */
	/*                  (sum of weighted withdrawal at end date -                            */
	/*                   sum of weighted  withdrawal at start date)                          */
	/* ------------------------------------------------------------------------------------- */

	bool     bIntradayNIP = false;
	invest = withdr = wInvest = wWithdr = iInvest = iWithdr = adjust = 0.0;

	for (i = fromIdx; i < recNbr; i++)
	{
		if (i > 0)
		{
			prevSynthPtr = ptfSynthPtr[i - 1];
		}

		FIN_CalcInvestAndWithdr(ptfSynthPtr[i],
			prevSynthPtr,   /* REF7395 - CSY - 020808 */
			taxCredFlg, grossEffectFlg, grossFeesFlg, grossTaxFlg,
			excludeIncFlg, FALSE, excludePosFeesFlg, excludePosTaxFlg, 0, 0,
			&onlyIncFlg, &invest, &withdr, &wInvest, &wWithdr,
			&iInvest, &iWithdr, &adjust,
			fromDate, tillDate);    /* REF7395 - CSY - 020430 */

		/* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
		if (GET_FLAG(ptfSynthPtr[i], A_PtfSynth_IntradayNIPFlg) == TRUE)
		{
			bIntradayNIP = true;
		}
	}

	*flowsPtr = invest + withdr;
	weightFlows = wInvest + wWithdr;

	DATE_T      refDate;
	long        numDate;
	GEN_GetApplInfo(ApplSynthRefDate, &refDate);
	if (refDate == BAD_DATE)
	{
		refDate = DATE_Put(PTFSYNTH_REFDATE_YEAR, PTFSYNTH_REFDATE_MON, PTFSYNTH_REFDATE_DAY);
	}

	DATE_DaysBetween(refDate, GET_DATETIME(firstRec, A_PtfSynth_InitialDate).date, AccrRule_Actual_Actual, &numDate, 0);
	*initD = (double)numDate;

	DATE_DaysBetween(refDate, GET_DATETIME(lastRec, A_PtfSynth_FinalDate).date, AccrRule_Actual_Actual, &numDate, 0);
	*finalD = (double)numDate;

	/* PMSTA-52459 - DDV - 230703 - Use bMeanInvestCap instead of alwaysInitialDtFlg, to avoid confusion.
									Be careful, in ext_ret_analysis MIC is stored into mean_capital_m field and MC is stored into mean_invest_cap_m */
	bool       bMeanInvestCap = (alwaysInitialDtFlg == FALSE);

	/* PMSTA-52459 - DDV - 230425 - For global line and contrib method, MC = MIC => force computation of MIC */
	if ((IS_NULLFLD(firstRec, A_PtfSynth_MktSegtId) == TRUE &&
		 IS_NULLFLD(firstRec, A_PtfSynth_InstrId) == TRUE))
	{
		bMeanInvestCap = true;
	}

	/* WEALTH-2417 - DDV - 231004 - use local SynthTab to use global Synth for contrib methods and given Tab for others methods */
	DBA_DYNFLD_STP*   localSynthTab = ptfSynthPtr;
	int               localSynthNbr = recNbr;
	int               localFromIdx = fromIdx;

	/* PMSTA-52895 - DDV - 230824 - If global line id begin of invested period (or one invested period), then MC = MIC => force computation of MIC */
	if (bMeanInvestCap == false || retContribFlg == TRUE)
	{
		DBA_DYNFLD_STP* ptfGblSynthTab =NULLDYNSTPTR;
		int             ptfGblSynthNbr = 0;

		if (gblSynthArray != NULLDYNSTPTR &&
			IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
			(ptfGblSynthNbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr)) > 0)
		{
		    ptfGblSynthTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
		}
		else
		{
			DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE, DBA_FilterPrimaryGlobalSynthByPSP,
				                              firstRec, DBA_CmpSynthDate, &ptfGblSynthNbr, &ptfGblSynthTab);

			mp.ownerPtr(ptfGblSynthTab);
		}

		i = 0;
		int             firstIdx = NO_VALUE;
		while (i < ptfGblSynthNbr && CMP_DYNFLD(ptfGblSynthTab[i], firstRec, A_PtfSynth_InitialDate, A_PtfSynth_InitialDate, DatetimeType) < 0)
		{
			i++;
		}

		if (i < ptfGblSynthNbr &&
			CMP_DYNFLD(ptfGblSynthTab[i], firstRec, A_PtfSynth_InitialDate, A_PtfSynth_InitialDate, DatetimeType) == 0)
		{
			firstIdx = i;
		}

		if (firstIdx != NO_VALUE)
		{
			/* WEALTH-3197 - DDV - 2404225 - Skip NIP PtfSynth to find first invested PtfSynth */
			int gblFirstInvested = firstIdx;
			while (gblFirstInvested < ptfGblSynthNbr && static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
			{
				gblFirstInvested++;
			}

			int objFirstInvested = fromIdx;
			while (objFirstInvested < recNbr && static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
			{
				objFirstInvested++;
			}

			/* WEALTH-2475 - DDV - 231016 - When it is first Ptf investment MC=MIC even for contrib method */
			if (gblFirstInvested < ptfGblSynthNbr && objFirstInvested < recNbr &&
			    (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod ||
				 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod) &&
				(static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod ||   /* PMSTA-54537 - DDV - 230913 - Check that first PtfSynth is also begining of new invested period */
				 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objFirstInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod) &&
				CMP_DYNFLD(ptfGblSynthTab[gblFirstInvested], ptfSynthPtr[objFirstInvested], A_PtfSynth_InitialDate, A_PtfSynth_InitialDate, DateType) == 0 &&
				CMP_DYNFLD(ptfGblSynthTab[gblFirstInvested], ptfSynthPtr[objFirstInvested], A_PtfSynth_InitialNotInvestedDays, A_PtfSynth_InitialNotInvestedDays, NumberType) == 0)
			{
				bMeanInvestCap = true;
			}

			/* WEALTH-3197 - DDV - 2404225 - Ignore NIP PtfSynth at the end to find last invested PtfSynth */
			int gblLastInvested = ptfGblSynthNbr-1;
			while (gblLastInvested > 0 && static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
			{
				gblLastInvested--;
			}

			int objLastInvested = recNbr-1;
			while (objLastInvested > 0 && static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
			{
				objLastInvested--;
			}

			/* WEALTH-6642 - DDV - 240404 - When it is last Ptf investment MC=MIC even for contrib method */
			if (gblLastInvested >= 0 && objLastInvested >= 0 &&
				(static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod ||
				 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfGblSynthTab[gblLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod) &&
				(static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod ||
				 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[objLastInvested], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod) &&
				CMP_DYNFLD(ptfGblSynthTab[gblLastInvested], ptfSynthPtr[objLastInvested], A_PtfSynth_FinalDate, A_PtfSynth_FinalDate, DateType) == 0 &&                       /* WEALTH-3197 - DDV - 240604 - Fix regression on WEALTH-6642 */
				CMP_DYNFLD(ptfGblSynthTab[gblLastInvested], ptfSynthPtr[objLastInvested], A_PtfSynth_FinalNotInvestedDays, A_PtfSynth_FinalNotInvestedDays, NumberType) == 0) /* WEALTH-3197 - DDV - 240604 - Fix regression on WEALTH-6642 */
			{
				bMeanInvestCap = true;
			}

			if (retContribFlg == TRUE)
			{
				/* WEALTH-2417 - DDV - 231004 - use global Synth for contrib methods */
				localSynthTab = ptfGblSynthTab;
				localSynthNbr = ptfGblSynthNbr;
				localFromIdx = firstIdx;
			}
		}
	}

	/* PMSTA-52459 - DDV - 230425 - For Mean Invested Capital, adjust period's number of days */
    if (bMeanInvestCap || retContribFlg == TRUE)
    {
        /* Adjust initD when beginning of period is not invested */
        int 	idx = localFromIdx;

        while (idx < localSynthNbr &&
            static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
        {
            (*initD) += DATE_Diff(GET_DATE(localSynthTab[idx], A_PtfSynth_InitialDate), GET_DATE(localSynthTab[idx], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID);
            ++idx;
        }

        if (idx < localSynthNbr && (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod ||
            static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod))
        {
            (*initD) += GET_NUMBER(localSynthTab[idx], A_PtfSynth_InitialNotInvestedDays);
        }

        /* Adjust finalD when end of period is not invested */
        idx = (localSynthNbr - 1);
		while (idx >= localFromIdx && CMP_DYNFLD(localSynthTab[idx], lastRec, A_PtfSynth_FinalDate, A_PtfSynth_FinalDate, DatetimeType) > 0)
		{
			--idx;
		}

        while (idx >= localFromIdx &&
            static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
        {
            (*finalD) -= DATE_Diff(GET_DATE(localSynthTab[idx], A_PtfSynth_InitialDate), GET_DATE(localSynthTab[idx], A_PtfSynth_FinalDate), Day, AccrRule_SceActAct, ZERO_ID);
            --idx;
		}

		if (idx >= localFromIdx && (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod ||
            static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(localSynthTab[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod))
        {
            (*finalD) -= GET_NUMBER(localSynthTab[idx], A_PtfSynth_FinalNotInvestedDays);
        }

		/* WEALTH-3077 - DDV - 231031 - change firstRec and lastRec to be in phase with new dates. */
		idx = fromIdx;
		while (idx < recNbr &&
			   static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
		{
			++idx;
		}

		if (idx < recNbr)
		{
			firstRec = ptfSynthPtr[idx];
		}

		idx = (recNbr - 1);
		while (idx >= fromIdx &&
			  static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(ptfSynthPtr[idx], A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod)
		{
			--idx;
		}

		if (idx >= fromIdx)
		{
			lastRec = ptfSynthPtr[idx];
		}
	}

    periodNbOfDays = (*finalD) - (*initD);

    if (periodNbOfDays < 0)
    {
        *meanCapPtr = 0.0;
    }
	/* WEALTH-2891 - DDV - 231026 - Treate correctly last not invested period */
	/* WEALTH-3055 - DDV - 231030 - Use exception only when number of days in period is zero */
	else if (bMeanInvestCap && periodNbOfDays == 0 &&
             (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod ||
              static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod || 
		      static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(lastRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod))
    {
		/* WEALTH-2954 - DDV - 240115 - if last ptfSynth is one invested period, meanCap is equal to purchase + investment */
		/* WEALTH-6156 - DDV - 240507 - Manage when they are 2 PtfSynth (BeginOfInvestedPeriod and EndOfInvestedPeriod), it is also one invest period */
		if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod ||
			(static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod &&
			 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(lastRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod)
		   )
		{
			if (grossEffectFlg == TRUE)
			{
				*meanCapPtr = GET_AMOUNT(firstRec, A_PtfSynth_GrossPurchases) + GET_AMOUNT(firstRec, A_PtfSynth_GrossInvest);
			}
			else
			{
				*meanCapPtr = GET_AMOUNT(firstRec, A_PtfSynth_NetPurchases) + GET_AMOUNT(firstRec, A_PtfSynth_NetInvest);
			}
		}
		/* if first date of period is not invested, meanCap is equal to flows */
		else if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod)
		{
			*meanCapPtr = *flowsPtr;
		}
		/* WEALTH-2954 - DDV - 240115 - if last ptfSynth is one invested period, meanCap is equal to purchase + investment */
		/* if last ptfSynth is end of investment, meanCap is equal to InitalMktVal */
        else if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(lastRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod)
        {
            *meanCapPtr = GET_AMOUNT(firstRec, A_PtfSynth_InitialMktVal);
        }
    }
	else if (bMeanInvestCap && periodNbOfDays == 1 && bIntradayNIP) /* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
	{
		AMOUNT_T       investPurchasesSum = 0.0;

		if (grossEffectFlg == TRUE)
		{
			investPurchasesSum = GET_AMOUNT(firstRec, A_PtfSynth_GrossInvest) + GET_AMOUNT(firstRec, A_PtfSynth_GrossPurchases);
		}
		else
		{
			investPurchasesSum = GET_AMOUNT(firstRec, A_PtfSynth_NetInvest) + GET_AMOUNT(firstRec, A_PtfSynth_NetPurchases);
		}

		if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(firstRec, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod)
		{
		    *meanCapPtr = investPurchasesSum/2;
		}
		else
		{
			*meanCapPtr = (GET_AMOUNT(firstRec, A_PtfSynth_InitialMktVal) + investPurchasesSum) / 2; /* WELATH-6156 - DDV - 241003 - Fix formula */
		}
	}
	else if ((onlyIncFlg == TRUE &&
             CMP_AMOUNT(GET_AMOUNT(firstRec, A_PtfSynth_InitialMktVal), 0.0, GET_ID(firstRec, A_PtfSynth_CurrId)) == 0 &&
             CMP_AMOUNT(GET_AMOUNT(lastRec, A_PtfSynth_FinalMktVal), 0.0, GET_ID(lastRec, A_PtfSynth_CurrId)) == 0)
		    || periodNbOfDays == 0)  /* PMSTA-55480 - JBC - 20240205 */
    {
        *meanCapPtr = 0.0;
    }
	else
    {
        *meanCapPtr = GET_AMOUNT(firstRec, A_PtfSynth_InitialMktVal) +
                      ((((*finalD) * *flowsPtr) - weightFlows) / ((*finalD) - (*initD)));
    }

	/* WEALTH-4573 - DDV - 240306 - remove rounding */
    /* *meanCapPtr = CAST_AMOUNT((*meanCapPtr), GET_ID(firstRec, A_PtfSynth_CurrId));*/

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_CalcMeanInvestedCapNew()
**
**  Description :  Computes mean invested capital for received period
**                 (from and till record)
**
**  Arguments   :  ptfSynthPtr    pointer on portfolio synthetic data records
**                 fromIdx        index on record with initial date equal to the from date
**                 recNbr         number of record to read until final date is equal to till date
**                                It can be only one record.
**                 taxCredFlg     indicates whether tax credits are to be
**                                included as withdrawals from the system
**                 grossEffectFlg indicates whether the investment and
**                                withdrawal amounts are Gross or Net amounts
**		           grossFeesFlg   indicates whether portfolio fees are to be
**                                included as withdrawals from the portfolio
**		           grossTaxFlg    indicates whether portfolio taxes are to be
**                                included as withdrawals from the portfolio
**                 flowsPtr       pointer on flow sum to update
**                 meanCapPtr     pointer on mean invested capital to update
**
**  Return      :  RET_SUCCEED or error code
**                 meanCapPtr is updated with computed mean invested capital
**
**  Creation    :  PMSTA07059 - LJE - 080917
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CalcMeanInvestedCapNew(DBA_DYNFLD_STP* ptfSynthPtr,
	                                       int               fromIdx,
	                                       int               recNbr,
	                                       FLAG_T            taxCredFlg,
	                                       FLAG_T            grossEffectFlg,
	                                       FLAG_T            grossFeesFlg,
	                                       FLAG_T            grossTaxFlg,
	                                       FLAG_T            excludeIncFlg,
	                                       FLAG_T            alwaysInitialDtFlg,
	                                       FLAG_T            excludePosFeesFlg,
	                                       FLAG_T            excludePosTaxFlg,
	                                       DBA_DYNFLD_STP    selSynthPtr,
	                                       double* flowsPtr,
	                                       double* meanCapPtr,
	                                       double* initD,
	                                       double* finalD,
	                                       DATETIME_T        fromDate,
	                                       DATETIME_T        tillDate,
	                                       DBA_HIER_HEAD_STP hierHead)
{
	AMOUNT_T        weightFlows, invest, withdr, wInvest, wWithdr, iInvest, iWithdr;
	DBA_DYNFLD_STP 	finalRec = NULLDYNST, begRec = NULLDYNST;
	int      		i, j;
	FLAG_T			onlyIncFlg = TRUE;
	DBA_DYNFLD_STP  prevSynthPtr = NULLDYNST;

	*initD = 0.0;
	*finalD = 0.0;

	/* ------------------------------------------------------------------------------------- */
	/* Mean invested capital is MVal0 + (((days1 * flows) - weighted flows) / (days1-days0)) */
	/* MVal0 = initial market value at the beginning of the period                           */
	/* days1 = number of days from system date till the period end date                      */
	/* days0 = number of days from system date till the period start date                    */
	/* flows = (sum of investment at end date - sum of investment at start date) -           */
	/*         (sum of withdrawal at end date - sum of withdrawal at start date)             */
	/* weighted flows = (sum of weighted investment at end date -                            */
	/*                   sum of weighted investment at start date) -                         */
	/*                  (sum of weighted withdrawal at end date -                            */
	/*                   sum of weighted  withdrawal at start date)                          */
	/* ------------------------------------------------------------------------------------- */

	finalRec = ptfSynthPtr[recNbr - 1];
	begRec = ptfSynthPtr[fromIdx];

	if (alwaysInitialDtFlg == TRUE)
	{
		DATE_T		refDate;
		long        numDate;

		GEN_GetApplInfo(ApplSynthRefDate, &refDate);
		if (refDate == BAD_DATE)
			refDate = DATE_Put(PTFSYNTH_REFDATE_YEAR,
				PTFSYNTH_REFDATE_MON,
				PTFSYNTH_REFDATE_DAY);

		DATE_DaysBetween(refDate, GET_DATETIME(begRec, A_PtfSynth_InitialDate).date, AccrRule_Actual_Actual, &numDate, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
		*initD = (double)numDate;
		DATE_DaysBetween(refDate, GET_DATETIME(finalRec, A_PtfSynth_FinalDate).date, AccrRule_Actual_Actual, &numDate, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
		*finalD = (double)numDate;
	}
	else
	{
		if (GET_INT(begRec, A_PtfSynth_FirstFlowNumDays) >
			GET_INT(begRec, A_PtfSynth_InitialNumDays) &&
			CMP_AMOUNT(GET_AMOUNT(begRec, A_PtfSynth_InitialMktVal), 0.0,
				GET_ID(begRec, A_PtfSynth_CurrId)) == 0)
		{
			*initD = GET_INT(begRec, A_PtfSynth_FirstFlowNumDays);
		}
		else
		{
			*initD = GET_INT(begRec, A_PtfSynth_InitialNumDays);
		}

		if (IS_NULLFLD(finalRec, A_PtfSynth_LastFlowNumDays) == FALSE &&
			GET_INT(finalRec, A_PtfSynth_LastFlowNumDays) <
			GET_INT(finalRec, A_PtfSynth_FinalNumDays) &&
			CMP_AMOUNT(GET_AMOUNT(finalRec, A_PtfSynth_FinalMktVal), 0.0,
				GET_ID(finalRec, A_PtfSynth_CurrId)) == 0)
		{
			*finalD = GET_INT(finalRec, A_PtfSynth_LastFlowNumDays);
		}
		else
		{
			*finalD = GET_INT(finalRec, A_PtfSynth_FinalNumDays);
		}

	}

	if ((*finalD) < (*initD))
	{
		*meanCapPtr = 0.0;
		*flowsPtr = 0.0;
		return(RET_FIN_ERR_INVDATA);
	}

	invest = withdr = wInvest = wWithdr = iInvest = iWithdr = 0.0;
	for (j = 0, i = fromIdx; i < recNbr; i++)
	{
		if (i > 0)
		{
			prevSynthPtr = ptfSynthPtr[i - 1];
		}
		FIN_CalcInvestAndWithdrNew(ptfSynthPtr[i],
			                       prevSynthPtr,
			                       taxCredFlg, grossEffectFlg, grossFeesFlg, grossTaxFlg,
			                       excludeIncFlg, excludePosFeesFlg, excludePosTaxFlg,
			                       &onlyIncFlg, &invest, &withdr, &wInvest, &wWithdr,
			                       &iInvest, &iWithdr,
			                       fromDate, tillDate);
	}

	*flowsPtr = invest + withdr;
	weightFlows = wInvest + wWithdr;

	/* In case of flow is only composed by incomes, return (and meanCap) should be 0% */
	if (onlyIncFlg == TRUE &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal), 0.0,
			GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthPtr[recNbr - 1], A_PtfSynth_FinalMktVal), 0.0,
			GET_ID(ptfSynthPtr[recNbr - 1], A_PtfSynth_CurrId)) == 0)
	{
		*meanCapPtr = 0.0;
	}
	else
	{
		*meanCapPtr = GET_AMOUNT(ptfSynthPtr[fromIdx], A_PtfSynth_InitialMktVal) +
			((((*finalD) * *flowsPtr) - weightFlows) / ((*finalD) - (*initD)));

		/* PMSTA07393 - LJE - 081203 : Move here */ /* WEALTH-4573 - DDV - 240306 - remove rounding */
		/* *meanCapPtr = CAST_AMOUNT((*meanCapPtr), GET_ID(ptfSynthPtr[fromIdx], A_PtfSynth_CurrId)); */
	}



	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_CalcInvestAndWithdr()
**
**  Description :  Computes invested and withdrawal amounts (+ weighted and intermediate)
**
**  Arguments   :   ptfSynthPtr     pointer on current portfolio synthetic
**                  prevSynthPtr    pointer on previous synthetic (used for adjustment only)
**                  taxCredFlg      indicates whether tax credits are to be
**                                  included as withdrawals from the system
**                  grossEffectFlg  indicates whether the investment and
**                                  withdrawal amounts are Gross or Net amounts
**		            grossFeesFlg    indicates whether portfolio fees are to be
**                                  included as withdrawals from the portfolio
**		            grossTaxFlg     indicates whether portfolio taxes are to be
**                                  included as withdrawals from the portfolio
**
**  Return      :  nothing
**                 amounts are updated
**
**  Creation    :  PMSTA07059 - LJE - 080917
**  Modif.      :
**
*************************************************************************/
STATIC void FIN_CalcInvestAndWithdrNew(DBA_DYNFLD_STP  ptfSynthPtr,
	                                   DBA_DYNFLD_STP  prevSynthPtr,
	                                   FLAG_T          taxCredFlg,
	                                   FLAG_T          grossEffectFlg,
	                                   FLAG_T          grossFeesFlg,
	                                   FLAG_T          grossTaxFlg,
	                                   FLAG_T          excludeIncFlg,
	                                   FLAG_T          excludePosFeesFlg,
	                                   FLAG_T          excludePosTaxFlg,
	                                   FLAG_T* onlyIncFlg,
	                                   AMOUNT_T* invest,
	                                   AMOUNT_T* withdr,
	                                   AMOUNT_T* wInvest,
	                                   AMOUNT_T* wWithdr,
	                                   AMOUNT_T* iInvest,
	                                   AMOUNT_T* iWithdr,
	                                   DATETIME_T      fromDate,
	                                   DATETIME_T      tillDate)
{
	AMOUNT_T    testInvest = 0.0, testWithdr = 0.0;
	FLAG_T      useAdjustFlg = FALSE;
	MASK_T      riskCashLegRuleMask;

	GEN_GetApplInfo(ApplRiskCashLegRuleMask, &riskCashLegRuleMask);

	if (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_NetAdj) == FALSE)
	{
		if (prevSynthPtr != NULLDYNST)
		{
			if (DATETIME_CMP(GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate),
				GET_DATETIME(prevSynthPtr, A_PtfSynth_FinalDate)) == 0)
			{
				useAdjustFlg = TRUE;
			}
		}
	}

	/* grossEffectFlg indicates whether the investment */
	/* and withdrawal amounts are Gross or Net amounts */
	if (grossEffectFlg == TRUE)
	{
		/* Verify if flow is only composed by incomes */
		if (onlyIncFlg != NULL)
		{
			testInvest = *invest;
			testWithdr = *withdr;
		}

		(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPurchases);
		(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossSales); /* fees and taxes */


		(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossInvest);
		(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossWithdr);

		/* adjust */
		if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
			(useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_GrossAdj) == FALSE &&
				DATETIME_CMP(fromDate,
					GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
		{
			if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj) > 0)
				(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj);
			else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj) < 0)
				(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj);
		}

		/* Verify if flow is only composed by incomes */
		if (onlyIncFlg != NULL)
		{
			if (CMP_AMOUNT(testInvest, (*invest), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0 ||
				CMP_AMOUNT(testWithdr, (*withdr), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0)
				*onlyIncFlg = FALSE;
		}


		(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossPurchases);
		(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossSales);

		(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossInvest);
		(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossWithdr);

		/* ajust */
		if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
			(useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) == FALSE &&
				DATETIME_CMP(fromDate,
					GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
		{
			if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) > 0)
				(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj);
			else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) < 0)
				(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj);
		}

		if (excludeIncFlg == FALSE)
		{
			(*invest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossRecInc) * -1);
			(*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPaidInc) * -1);
			(*wInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossRecInc) * -1);
			(*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossPaidInc) * -1);
		}

		/* excludePosFeesFlg indicates whether position fees are to be exclude as withdrawals */
		if (excludePosFeesFlg == TRUE)
		{
			(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosFees);
			(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPosFees);
		}

		/* excludePosTaxFlg indicates whether position taxes are to be exclude as withdrawals */
		if (excludePosTaxFlg == TRUE)
		{
			(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosTax);
			(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPosTax);
		}

	}
	else
	{
		/* Verify if flow is only composed by incomes */
		if (onlyIncFlg != NULL)
		{
			testInvest = *invest;
			testWithdr = *withdr;
		}


		(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPurchases);
		(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetSales); /* fees and taxes */

		(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetInvest);
		(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetWithdr);

		/* adjust */
		if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
			(useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_NetAdj) == FALSE &&
				DATETIME_CMP(fromDate,
					GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
		{
			if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj) > 0)
				(*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj);
			else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj) < 0)
				(*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj);
		}

		/* Verify if flow is only composed by incomes */
		if (onlyIncFlg != NULL)
		{
			if (CMP_AMOUNT(testInvest, (*invest), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0 ||
				CMP_AMOUNT(testWithdr, (*withdr), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0)
				*onlyIncFlg = FALSE;
		}

		(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetPurchases);
		(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetSales);

		(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetInvest);
		(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetWithdr);

		/* adjust */
		if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
			(useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_WeightNetAdj) == FALSE &&
				DATETIME_CMP(fromDate,
					GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
		{
			if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj) > 0)
				(*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj);
			else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj) < 0)
				(*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj);
		}

		if (excludeIncFlg == FALSE)
		{
			(*invest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetRecInc) * -1);
			(*wInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetRecInc) * -1);
			(*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPaidInc) * -1);
			(*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetPaidInc) * -1);
		}

	}

	/* taxCredFlg indicates whether tax credits are to be included as withdrawals */
	/* if they are not withdrawals, annul sales counter effect */
	if (taxCredFlg == FALSE)
	{
		(*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_TaxCred) * -1);
		(*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightTaxCred) * -1);
	}

	/* grossFeesFlg indicates whether portfolio fees are to be included as withdrawals */
	/* if they are not withdrawals, annul sales counter effect */
	if (grossFeesFlg == FALSE)
	{
		(*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfFees) * -1);
		(*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfFees) * -1);
	}

	/* grossTaxFlg indicates whether portfolio taxes are to be included as withdrawals */
	/* if they are not withdrawals, annul sales counter effect */
	if (grossTaxFlg == FALSE)
	{
		(*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfTax) * -1);
		(*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfTax) * -1);
	}
}

/************************************************************************
**
**  Function    :  FIN_CalcInvestAndWithdr()
**
**  Description :  Computes invested and withdrawal amounts (+ weighted and intermediate)
**                 
**  Arguments   :   ptfSynthPtr     pointer on current portfolio synthetic
**                  prevSynthPtr    pointer on previous synthetic (used for adjustment only)
**                  taxCredFlg      indicates whether tax credits are to be 
**                                  included as withdrawals from the system
**                  grossEffectFlg  indicates whether the investment and 
**                                  withdrawal amounts are Gross or Net amounts
**		            grossFeesFlg    indicates whether portfolio fees are to be
**                                  included as withdrawals from the portfolio
**		            grossTaxFlg     indicates whether portfolio taxes are to be
**                                  included as withdrawals from the portfolio
**
**  Return      :  nothing
**                 amounts are updated 
**
**  Creation    :  REF4254 - RAK - 000105 
**  Modif.      :  REF5703 - RAK - 010221
**  Modif.      :  REF5904 - RAK - 010403
**  Modif.      :  REF7395 - CSY - 020430: adjustment
**  Modif.      :  REF7395 - CSY - 020808: add argument prevSynthPtr for adjustment
**
*************************************************************************/
STATIC void FIN_CalcInvestAndWithdr(DBA_DYNFLD_STP  ptfSynthPtr,
                                    DBA_DYNFLD_STP  prevSynthPtr,   /* REF7395 - CSY - 020808 */
                                    FLAG_T          taxCredFlg,
                                    FLAG_T          grossEffectFlg,
			   		                FLAG_T          grossFeesFlg,
			   		                FLAG_T          grossTaxFlg,
                                    FLAG_T          excludeIncFlg, 
                                    FLAG_T          dailyFlg,
                                    FLAG_T          excludePosFeesFlg,  /* REF11269 - LJE - 051220 */
                                    FLAG_T          excludePosTaxFlg,   /* REF11269 - LJE - 051220 */
                                    int             nbrZeroD,
                                    double          intermD,
                                    FLAG_T          *onlyIncFlg,    /* REF5703 - RAK- 010221 */
                                    AMOUNT_T        *invest, 
                                    AMOUNT_T        *withdr, 
                                    AMOUNT_T        *wInvest, 
                                    AMOUNT_T        *wWithdr,
                                    AMOUNT_T        *iInvest, 
                                    AMOUNT_T        *iWithdr,
                                    AMOUNT_T        *adjust,
                                    DATETIME_T      fromDate,   /* REF7395 - CSY - 020430 */
                                    DATETIME_T      tillDate)   /* REF7395 - CSY - 020430 */
{
    AMOUNT_T    testInvest = 0.0, testWithdr = 0.0;
    FLAG_T      useAdjustFlg = FALSE;
    MASK_T      riskCashLegRuleMask;

    GEN_GetApplInfo(ApplRiskCashLegRuleMask, &riskCashLegRuleMask);

    /* REF7395 - CSY - 020808 */
    if (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_NetAdj) == FALSE)
    {
        if (prevSynthPtr != NULLDYNST)
        {
            if (DATETIME_CMP(GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate),
                GET_DATETIME(prevSynthPtr, A_PtfSynth_FinalDate)) == 0)
            {
                useAdjustFlg = TRUE;
            }
        }
    }

    /* grossEffectFlg indicates whether the investment */
    /* and withdrawal amounts are Gross or Net amounts */
    if (grossEffectFlg == TRUE)
    {
        /* REF5703 - RAK - 010221 - Verify if flow is only composed by incomes */
        if (onlyIncFlg != NULL)
        {
            testInvest = *invest;
            testWithdr = *withdr;
        }

        (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPurchases);
        (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossSales); /* fees and taxes */


        (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossInvest);
        (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossWithdr);

        /* REF7395 - CSY - 020430: adjust */
        if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
            (useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_GrossAdj) == FALSE &&
            DATETIME_CMP(fromDate,
            GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
        {
            if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj) > 0)
                (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj);
            else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj) < 0)
                (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj);

            if (adjust != NULL)
            {
                (*adjust) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossAdj);
            }
        }

        /* REF5703 - RAK - 010221 - Verify if flow is only composed by incomes */
        if (onlyIncFlg != NULL)
        {
            if (CMP_AMOUNT(testInvest, (*invest), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0 ||
                CMP_AMOUNT(testWithdr, (*withdr), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0)
                *onlyIncFlg = FALSE;
        }


        (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossPurchases);
        (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossSales);

        (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossInvest);
        (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossWithdr);

        /* REF7395 - CSY - 020430: ajust */
        if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
            (useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) == FALSE &&
            DATETIME_CMP(fromDate,
            GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
        {
            if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) > 0)
                (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj);
            else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj) < 0)
                (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossAdj);
        }

        /* REF4222 - CSY - 991220 */
        if (excludeIncFlg == FALSE)
        {
            (*invest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossRecInc) * -1);
            (*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPaidInc) * -1);
            (*wInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossRecInc) * -1);
            (*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightGrossPaidInc) * -1);
        }

        /* REF3086 */
        if (dailyFlg == TRUE && nbrZeroD > 0 &&
            iInvest != (AMOUNT_T*)NULL && (iWithdr) != (AMOUNT_T*)NULL)
        {
            (*iInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossInvest) * intermD);
            (*iInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPurchases) * intermD);

            (*iWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossWithdr) * intermD);
            (*iWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossSales) * intermD); /* fees and taxes */

            /* REF4222 - CSY - 991221 */
            if (excludeIncFlg == FALSE)
            {
                (*iInvest) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossRecInc) * -1) * intermD);
                (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_GrossPaidInc) * -1) * intermD);
            }
        }

        /* REF11269 - LJE - 051220 */
        /* excludePosFeesFlg indicates whether position fees are to be exclude as withdrawals */
        if (excludePosFeesFlg == TRUE)
        {
            (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosFees);
            (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPosFees);

            if (dailyFlg == TRUE && nbrZeroD > 0)
            {
                (*iWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosFees) * intermD;
            }
        }

        /* REF11269 - LJE - 051220 */
        /* excludePosTaxFlg indicates whether position taxes are to be exclude as withdrawals */
        if (excludePosTaxFlg == TRUE)
        {
            (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosTax);
            (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPosTax);

            if (dailyFlg == TRUE && nbrZeroD > 0)
            {
                (*iWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PosTax) * intermD;
            }
        }

    }
    else
    {
        /* REF5703 - RAK - 010221 - Verify if flow is only composed by incomes */
        if (onlyIncFlg != NULL)
        {
            testInvest = *invest;
            testWithdr = *withdr;
        }


        (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPurchases);
        (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetSales); /* fees and taxes */

        (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetInvest);
        (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetWithdr);

        /* REF7395 - CSY - 020430: adjust */
        if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
            (useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_NetAdj) == FALSE &&
            DATETIME_CMP(fromDate,
            GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
        {
            if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj) > 0)
                (*invest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj);
            else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj) < 0)
                (*withdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj);

            if (adjust != NULL)
            {
                (*adjust) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetAdj);
            }
        }

        /* REF5703 - RAK - 010221 - Verify if flow is only composed by incomes */
        if (onlyIncFlg != NULL)
        {
            if (CMP_AMOUNT(testInvest, (*invest), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0 ||
                CMP_AMOUNT(testWithdr, (*withdr), GET_ID(ptfSynthPtr, A_PtfSynth_CurrId)) != 0)
                *onlyIncFlg = FALSE;
        }

        (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetPurchases);
        (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetSales);

        (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetInvest);
        (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetWithdr);
        /* REF7395 - CSY - 020430: adjust */
        if (riskCashLegRuleMask > 0 || /* PMSTA-18393 - LJE - 140723 */
            (useAdjustFlg == TRUE && (IS_NULLFLD(ptfSynthPtr, A_PtfSynth_WeightNetAdj) == FALSE &&
            DATETIME_CMP(fromDate,
            GET_DATETIME(ptfSynthPtr, A_PtfSynth_InitialDate)) < 0)))
        {
            if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj) > 0)
                (*wInvest) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj);
            else if (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj) < 0)
                (*wWithdr) += GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetAdj);
        }


        /* REF4222 - CSY - 991221 */
        if (excludeIncFlg == FALSE)
        {
            (*invest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetRecInc) * -1);
            (*wInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetRecInc) * -1);
            (*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPaidInc) * -1);
            (*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightNetPaidInc) * -1);
        }

        /* REF3086 */
        if (dailyFlg == TRUE && nbrZeroD > 0 &&
            iInvest != (AMOUNT_T*)NULL && (iWithdr) != (AMOUNT_T*)NULL)
        {
            (*iInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetInvest) * intermD);
            (*iInvest) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPurchases) * intermD);

            (*iWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetWithdr) * intermD);
            (*iWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetSales) * intermD); /* fees and taxes */

            /* REF4222 - CSY - 991221 */
            if (excludeIncFlg == FALSE)
            {
                (*iInvest) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetRecInc) * -1) * intermD);
                (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_NetPaidInc) * -1) * intermD);
            }
        }
    }

    /* DVP165 */
    /* taxCredFlg indicates whether tax credits are to be included as withdrawals */
    /* if they are not withdrawals, annul sales counter effect */
    if (taxCredFlg == FALSE)
    {
        (*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_TaxCred) * -1);
        (*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightTaxCred) * -1);

        /* REF3086 */
        if (dailyFlg == TRUE && nbrZeroD > 0)
        {
            /* REF5904 - RAK - 010403 */
            /* (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightTaxCred) * -1) * intermD); */
            (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_TaxCred) * -1) * intermD);
        }
    }

    /* grossFeesFlg indicates whether portfolio fees are to be included as withdrawals */
    /* if they are not withdrawals, annul sales counter effect */
    if (grossFeesFlg == FALSE)
    {
        (*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfFees) * -1);
        (*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfFees) * -1);

        /* REF3086 */
        if (dailyFlg == TRUE && nbrZeroD > 0)
        {
            /* REF5904 - RAK - 010403 */
            /* (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfFees) * -1) * intermD); */
            (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfFees) * -1) * intermD);
        }
    }

    /* grossTaxFlg indicates whether portfolio taxes are to be included as withdrawals */
    /* if they are not withdrawals, annul sales counter effect */
    if (grossTaxFlg == FALSE)
    {
        (*withdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfTax) * -1);
        (*wWithdr) += (GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfTax) * -1);

        /* REF3086 */
        if (dailyFlg == TRUE && nbrZeroD > 0)
        {
            /* REF5904 - RAK - 010403 */
            /* (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_WeightPtfTax) * -1) * intermD); */
            (*iWithdr) += ((GET_AMOUNT(ptfSynthPtr, A_PtfSynth_PtfTax) * -1) * intermD);
        }
    }
}

/************************************************************************
**
**  Function    :  FIN_CalcPtfDailyFlg()
**
**  Description :  Computes portfolio daily flag.
**                 
**  Arguments   :  firstPtfSynthPtr     pointer on first portfolio synthetic
**                 recNbr               record number
**                 hierHead             hierarchy header pointer
**                 dailyFlg             filled to TRUE if portfolio is daily and more than 1 record
**
**  Return      :  RET_SUCCEED or error code
**                 dailyFlg is updated 
**
**  Creation    :  REF4254 - RAK - 000106 
**
*************************************************************************/
STATIC RET_CODE FIN_CalcPtfDailyFlg(DBA_DYNFLD_STP    firstPtfSynthPtr, 
                                    int               recNbr, 
                                    DBA_HIER_HEAD_STP hierHead, 
                                    FLAG_T            *dailyFlg)
{
    FLAG_T          allocFlg=FALSE;
    DBA_DYNFLD_STP  ptfPtr=NULLDYNST;

	*dailyFlg = FALSE;
	
    if (recNbr > 1 && 
	    (IS_NULLFLD(firstPtfSynthPtr, A_PtfSynth_InstrId) == FALSE ||
	     IS_NULLFLD(firstPtfSynthPtr, A_PtfSynth_MktSegtId) == FALSE))
	{
		/* REF3644 - In case of merge, no portfolio id in synthetic ... */
		if (GET_ID(firstPtfSynthPtr, A_PtfSynth_PtfId) != 0)
		{
 	       /* REF3913 - DDV - 991014 */
	        if (DBA_GetPtfById(GET_ID(firstPtfSynthPtr, A_PtfSynth_PtfId), FALSE, &allocFlg,
	                           &ptfPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
				return(RET_DBA_ERR_NODATA);
			}
			
			if (GET_SMALLINT(ptfPtr, A_Ptf_RetFreq) == 1 &&
				(FREQUNIT_ENUM) GET_ENUM(ptfPtr, A_Ptf_RetFreqUnitEn) == FreqUnit_Day)
				*dailyFlg = TRUE;
		}

        if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
	}

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_CalcFinalNumDays()
**
**  Description :  Computes final num days.
**                 
**  Arguments   :   initPtfSynthPtr     pointer on first portfolio synthetic
**                  finalPtfSynthPtr    pointer on final portfolio synthetic
**
**  Return      :  nothing
**                 finalD and modifFinalD are updated 
**
**  Creation    :  REF4254 - RAK - 000106 
**
*************************************************************************/
STATIC void FIN_CalcFinalNumDays(DBA_DYNFLD_STP         initPtfSynthPtr,
                                 DBA_DYNFLD_STP         finalPtfSynthPtr, 
                                 INVESTTIMINGRULE_ENUM  timingRule, 
								 FLAG_T                 alwaysInitialDtFlg, /* REF7634 - LJE - 020618 */
                                 FLAG_T                 *modifFinalD,
                                 double                 *finalD,
                                 DBA_HIER_HEAD_STP      hierHead) /* PMSTA-16727 - LJE - 130723 */
{
    *modifFinalD=TRUE;

    /* PMSTA-16727 - LJE - 130719 */
	/* REF3064 - Don't modify finalD (so meanCap will be computed ...) */
	if (finalPtfSynthPtr != NULLDYNST &&
		CMP_AMOUNT(GET_AMOUNT(finalPtfSynthPtr, A_PtfSynth_FinalMktVal), 0.0,
				   GET_ID(finalPtfSynthPtr, A_PtfSynth_CurrId)) == 0 &&
		GET_INT(finalPtfSynthPtr, A_PtfSynth_FinalNumDays) -
		GET_INT(initPtfSynthPtr, A_PtfSynth_InitialNumDays) == 1 &&
		timingRule == InvestTimingRule_Beginning)
    {
   		(*modifFinalD) = FALSE;

        /* PMSTA-16727 - LJE - 130722 */
        if (alwaysInitialDtFlg == TRUE)
        {
            DBA_DYNFLD_STP *ptfGblSynthPtr = NULL;
            int             ptfGblSynthNbr = 0;
            DBA_DYNFLD_STP gblPtfSynthPtr  = finalPtfSynthPtr;
            DBA_DYNFLD_ST   gblMktSegtId;

            memset(&gblMktSegtId, 0, sizeof(DBA_DYNFLD_ST));

            if (FIN_FilterGlobalPtfSynth(gblPtfSynthPtr, A_PtfSynth, gblPtfSynthPtr) == FALSE &&
                DBA_ExtractHierEltRecByIndexKey(hierHead,
										        A_PtfSynth,
										        A_PtfSynth_MktSegtId,
										        gblMktSegtId,
										        FALSE,
										        FIN_FilterGlobalPtfSynth,
										        finalPtfSynthPtr,
										        FIN_CmpReturnPtfSynth,
										        FALSE,
										        &ptfGblSynthNbr, 
										        &ptfGblSynthPtr) == RET_SUCCEED &&
		        ptfGblSynthNbr > 0)
	        {
                gblPtfSynthPtr  = ptfGblSynthPtr[0];
	        }

            if (CMP_AMOUNT(GET_AMOUNT(gblPtfSynthPtr, A_PtfSynth_FinalMktVal), 0.0, 
                           GET_ID(gblPtfSynthPtr, A_PtfSynth_CurrId)) != 0)
            {
           		(*modifFinalD) = TRUE;
            }

            if (ptfGblSynthNbr > 0)
            {
                FREE(ptfGblSynthPtr);
            }
        }
    }

	/* REF7634 - LJE - 020628 */
	if (alwaysInitialDtFlg == TRUE)
	{
        DATE_T    refDate;
        long        numDate;
        GEN_GetApplInfo(ApplSynthRefDate, &refDate);
        if (refDate == BAD_DATE)
              refDate = DATE_Put(PTFSYNTH_REFDATE_YEAR,
                    PTFSYNTH_REFDATE_MON,
                    PTFSYNTH_REFDATE_DAY);
        DATE_DaysBetween(refDate, GET_DATETIME(finalPtfSynthPtr, A_PtfSynth_FinalDate).date, AccrRule_Actual_Actual, &numDate, 0); /* PMSTA-22396  - SRIDHARA ? 160430 */
        *finalD = (double)numDate;

	}
	else
	{
		*finalD = (double) (GET_INT(finalPtfSynthPtr, A_PtfSynth_FinalNumDays));

        /* REF11526 - LJE - 060118 */
   		if (finalPtfSynthPtr != NULLDYNST &&
			CMP_AMOUNT(GET_AMOUNT(finalPtfSynthPtr, A_PtfSynth_FinalMktVal), 0.0,
					   GET_ID(finalPtfSynthPtr, A_PtfSynth_CurrId)) == 0 &&
            CMP_NUMBER(GET_NUMBER(finalPtfSynthPtr, A_PtfSynth_Qty), 0.0) == 0 &&
            IS_NULLFLD(finalPtfSynthPtr, A_PtfSynth_LastFlowNumDays) == FALSE &&  /* PMSTA05731 - LJE - 080326 */
			GET_INT(finalPtfSynthPtr, A_PtfSynth_FinalNumDays) >
			GET_INT(initPtfSynthPtr, A_PtfSynth_LastFlowNumDays))
        {
            *finalD = (double) (GET_INT(finalPtfSynthPtr, A_PtfSynth_LastFlowNumDays));
        }

		/* REF2552 - bis - Verify final market value. */
		if ((*modifFinalD) == TRUE && finalPtfSynthPtr != NULLDYNST &&
			CMP_AMOUNT(GET_AMOUNT(finalPtfSynthPtr, A_PtfSynth_FinalMktVal), 0.0,
					   GET_ID(finalPtfSynthPtr, A_PtfSynth_CurrId)) == 0)
		{
			switch(timingRule)
			{
			case InvestTimingRule_Beginning :       /* Correct to begin of day */
                *finalD = (*finalD) - 1.0;
 				break;

			case InvestTimingRule_Mid :       	    /* Correct to middle of day */
				*finalD = (*finalD) - 0.5;
				break;

			case InvestTimingRule_End :		        /* Is at end of day */
			default :
				break;
			}
		}
	}
}

/************************************************************************
**
**  Function    :  FIN_CalcInitNumDaysAndInterm()
**
**  Description :  Computes final num days.
**                 
**  Arguments   :   initPtfSynthPtr     pointer on first portfolio synthetic
**                  finalPtfSynthPtr    pointer on final portfolio synthetic
**
**  Return      :  RET_SUCCEED or error code
**                 initD, modifInitD, intermDPtr, intermDNbr, nbrZeroD are updated 
**
**  Creation    :  REF4254 - RAK - 000106 
**  Modification   REF5387 - CSY - 001121
**
*************************************************************************/
STATIC RET_CODE FIN_CalcInitNumDaysAndInterm(DBA_DYNFLD_STP         *ptfSynthTab,
											DBA_DYNFLD_STP			gblSynthArray, /* PMSTA-55377 - Deepthi - 240117 */
                                             int                    recNbr, 
                                             INVESTTIMINGRULE_ENUM  timingRule, 
                                             FLAG_T                 dailyFlg,
											 FLAG_T                 alwaysInitialDtFlg, /* REF7634 - LJE - 020618 */
                                             DBA_DYNFLD_STP         *begRec,
                                             FLAG_T                 *modifInitD,
                                             double                 *initD,
                                             int                    **intermDPtr,
                                             int                    *intermDNbr,
                                             int                    *nbrZeroD,
                                             DBA_HIER_HEAD_STP      hierHead) /* PMSTA-16727 - LJE - 130723 */
{
    FLAG_T          updNbrZeroDFlg = FALSE;
    int             i;
    INT_T           fD = GET_INT(ptfSynthTab[recNbr-1], A_PtfSynth_FinalNumDays);
    DBA_DYNFLD_STP  finalRec = ptfSynthTab[recNbr-1];
	MemoryPool      mp;
    
    *begRec     = NULLDYNST;
    if (intermDNbr != NULL) *intermDNbr = 0;
	
    /* REF3086 - Initial date is first non-zero position */
	if (dailyFlg == FALSE)
	{
		*begRec = ptfSynthTab[0];
	}
	else
	{
        if (intermDPtr != NULL)
        {
		    if (((*intermDPtr)=(int*) CALLOC(recNbr, sizeof(int)))== NULL)
		    {
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }
        }

		for (i=0; i<recNbr; i++)
		{
			if ((*begRec) == NULLDYNST)
			{
			    if (CMP_AMOUNT(GET_AMOUNT(ptfSynthTab[i], A_PtfSynth_FinalMktVal), 0.0,
				               GET_ID(ptfSynthTab[i], A_PtfSynth_CurrId)) != 0)
					(*begRec) = ptfSynthTab[i];
			}
			else
			{
				/* Search intermediate empty synthetic */
				if (CMP_AMOUNT(GET_AMOUNT(ptfSynthTab[i], A_PtfSynth_FinalMktVal), 0.0,
					           GET_ID(ptfSynthTab[i], A_PtfSynth_CurrId)) == 0 &&
				    CMP_AMOUNT(GET_AMOUNT(ptfSynthTab[i], A_PtfSynth_InitialMktVal), 0.0,
					           GET_ID(ptfSynthTab[i], A_PtfSynth_CurrId)) != 0 &&
				    GET_INT(ptfSynthTab[i], A_PtfSynth_FinalNumDays) != fD)
				{
                    if (intermDPtr != NULL)
                    {
					    (*intermDPtr)[(*intermDNbr)++] = GET_INT(ptfSynthTab[i], A_PtfSynth_FinalNumDays);
                    }
                    updNbrZeroDFlg = TRUE;						
				}

				if (nbrZeroD != NULL &&
                    updNbrZeroDFlg == TRUE &&
				    CMP_AMOUNT(GET_AMOUNT(ptfSynthTab[i], A_PtfSynth_FinalMktVal), 0.0,
					           GET_ID(ptfSynthTab[i], A_PtfSynth_CurrId)) == 0 &&
		                        GET_INT(ptfSynthTab[i], A_PtfSynth_FinalNumDays) != fD) /* REF5387 */
					++(*nbrZeroD);
				else
					updNbrZeroDFlg = FALSE;
			}
		}

		if ((*begRec) == NULLDYNST)
			(*begRec) = ptfSynthTab[0];
	}

	/* REF3086 - ptfSynthPtr[fromIdx] replaced by begRec */
	/* REF3064 - Don't modify initD (so meanCap will be computed ...) */
	(*modifInitD) = TRUE;

    /* PMSTA-16727 - LJE - 130719 */
	if (CMP_AMOUNT(GET_AMOUNT((*begRec), A_PtfSynth_InitialMktVal), 0.0,
		GET_ID((*begRec), A_PtfSynth_CurrId)) == 0 &&
		GET_INT(finalRec, A_PtfSynth_FinalNumDays) -
		GET_INT((*begRec), A_PtfSynth_InitialNumDays) == 1 &&
		timingRule == InvestTimingRule_End)
	{
		(*modifInitD) = FALSE;

		/* PMSTA-16727 - LJE - 130722 */
		if (alwaysInitialDtFlg == TRUE)
		{
			DBA_DYNFLD_STP* ptfGblSynthTab = NULL;
			int             ptfGblSynthNbr = 0;
			DBA_DYNFLD_STP  gblPtfSynthPtr = (*begRec);
			DBA_DYNFLD_ST   gblMktSegtId;

			memset(&gblMktSegtId, 0, sizeof(DBA_DYNFLD_ST));


			if (FIN_FilterGlobalPtfSynth((*begRec), A_PtfSynth, (*begRec)) == FALSE)
			{
				gblPtfSynthPtr = NULLDYNST;

				/* PMSTA-55377 - Deepthi - 240117 */
				if (gblSynthArray != NULLDYNSTPTR &&
					IS_NULLFLD(gblSynthArray, A_Array_Ptr) == FALSE &&
					(GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr)) > 0)
				{
					ptfGblSynthTab = (DBA_DYNFLD_STP*)GET_ARRAY_PTR(gblSynthArray, A_Array_Ptr);
					ptfGblSynthNbr = GET_ARRAY_ELTNBR(gblSynthArray, A_Array_Ptr);
					gblPtfSynthPtr = NULLDYNST;

					for (int idx = 0; idx < ptfGblSynthNbr && gblPtfSynthPtr == NULLDYNST; ++idx)
					{
						if (FIN_FilterGlobalPtfSynth(ptfGblSynthTab[idx], A_PtfSynth, (*begRec)))
						{
							gblPtfSynthPtr = ptfGblSynthTab[idx];
						}
					}
				}

				if (gblPtfSynthPtr == NULLDYNST)
				{
					if (DBA_ExtractHierEltRecByIndexKey(hierHead,
                                                        A_PtfSynth,
                                                        A_PtfSynth_MktSegtId,
                                                        gblMktSegtId,
                                                        FALSE,
                                                        FIN_FilterGlobalPtfSynth,
                                                        (*begRec),
                                                        FIN_CmpReturnPtfSynth,
                                                        FALSE,
                                                        &ptfGblSynthNbr,
                                                        &ptfGblSynthTab) == RET_SUCCEED &&
					    ptfGblSynthNbr > 0)
					{
						mp.ownerPtr(ptfGblSynthTab);
						gblPtfSynthPtr = ptfGblSynthTab[0];
					}
					else
					{
						gblPtfSynthPtr = (*begRec);
					}
				}

				if (CMP_AMOUNT(GET_AMOUNT(gblPtfSynthPtr, A_PtfSynth_InitialMktVal), 0.0,
					GET_ID(gblPtfSynthPtr, A_PtfSynth_CurrId)) != 0)
				{
					(*modifInitD) = TRUE;
				}
			}
		}
	}

	if (alwaysInitialDtFlg == FALSE) /* REF7634 - LJE - 020619 */
	{
		/* REF3086 - ptfSynthPtr[fromIdx] replaced by begRec */
		/* BUG499 - first flow nbr of days if it is after initial nbr of days (first period) */
		/* REF2552 - Verify initial market value. */
		/* If more than one period, use "first flow" num days */
		if ((*modifInitD) == TRUE && 
			 GET_INT((*begRec), A_PtfSynth_FirstFlowNumDays) >=  
				GET_INT((*begRec), A_PtfSynth_InitialNumDays) &&
			CMP_AMOUNT(GET_AMOUNT((*begRec), A_PtfSynth_InitialMktVal), 0.0,
					   GET_ID((*begRec), A_PtfSynth_CurrId)) == 0)
		{	
			*initD = (double) (GET_INT((*begRec), A_PtfSynth_FirstFlowNumDays)); 

			switch(timingRule)
			{
			case InvestTimingRule_Mid :		/* REF2448 - Correct to middle of day */
				*initD = (*initD) + 0.5;
				break;

			case InvestTimingRule_End :		/* REF2448 - Correct to end of day */
				*initD = (*initD) + 1.0;
				break;

			case InvestTimingRule_Beginning :	/* REF2448 - FirstFlowNumDays is -1 (beginning of day) */
				*initD = (*initD);
				break;
			}

		}
		else
		{	
			*initD  = (double) (GET_INT((*begRec), A_PtfSynth_InitialNumDays));  
		}
	}
	else
	{	
		*initD  = (double) (GET_INT((*begRec), A_PtfSynth_InitialNumDays));  
	}


    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :  FIN_RetDiff()
**
**  Description :  Difference between 2 portfolio synthethic data
**                 
**  Arguments   :  fromDate      from date for return computation
**                                can be NULL and replaced by period number 
**                                from the till date
**                 periodNbr     period nbr from the till date, give from date
**                 field         position on field to compute
**                 ptfId         current portfolio identifier
**                 hierHeadPtr   pointer on hierarchy header
**                 hierEltPos    hierarchy element position (A_PtfSynth)
**
**  Return      :  difference
**
*************************************************************************/
double FIN_RetDiff_2del(DATETIME_T     fromDate, 
		   NUMBER_T       periodNbr,
		   int            field,
		   ID_T           ptfId,
		   PTR            hierHeadPtr,
		   DBA_DYNST_ENUM hierEltPos)
{
	DBA_HIER_HEAD_STP posHierHead=(DBA_HIER_HEAD_STP)hierHeadPtr; /* REF7264 - LJE - 020131 */
	DBA_DYNFLD_STP    *extrPtfSynth=(DBA_DYNFLD_STP*)NULL; 
	int               ptfSynthNbr, i, fromRec, tillRec, 
			  begin;
	RET_CODE          ret;
	double            diff=0.0;

	if (fromDate.date == BAD_DATE)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1,FILEINFO, "FIN_RetDiff", "from date");
	    return(diff);
	}

	if (field < A_PtfSynth_NetRealCapP || field > GET_FIX_NBR(A_PtfSynth)) /* REF8844 - LJE - 030403 */
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1,FILEINFO, "FIN_RetDiff", "field");
	    return(diff);
	}

	/* Extract portfolio synthetic data in received hierarchy */
	if ((ret = DBA_ExtractHierEltRec(posHierHead, hierEltPos, FALSE, NULLFCT, FIN_CmpPtfSynth,
					 &ptfSynthNbr, &extrPtfSynth)) != RET_SUCCEED)
	{
	    MSG_SendMesg(ret, 0, FILEINFO);
	    return(diff);
	}

	/* Go on asked portfolio data */
	for (begin=-1, i=0; i<ptfSynthNbr && begin == -1; i++)
	{
		if (GET_ID(extrPtfSynth[i], A_PtfSynth_PtfId) == ptfId)
			begin = i;
	}

	if (begin == -1)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_PtfReturn", "portfolio");
		return(RET_GEN_ERR_INVARG);
	}

	/**** DETERMINE FROM DATE DATA IN SYNTHETIC RECORDS ****/
	for (fromRec=-1, i=begin; 
	     i<ptfSynthNbr && GET_ID(extrPtfSynth[i],A_PtfSynth_PtfId)==ptfId && fromRec == -1; i++)
	{
	    /* Use corresponding date in synthetic struct or next record */
	    if (DATETIME_CMP(GET_DATETIME(extrPtfSynth[i], A_PtfSynth_FinalDate), fromDate) >= 0)
		fromRec = i;                 /* and stop */
	}

	/* Verify validity of the from date record */
	if (fromRec != -1)
	{
		/* Period can be a positive or negative value */
		tillRec = fromRec + (int)periodNbr;

		/* Verify validity of the till date record */
		if (tillRec >= 0 && tillRec < ptfSynthNbr &&
		    GET_ID(extrPtfSynth[tillRec], A_PtfSynth_PtfId) == ptfId)
		{
		    diff = GET_AMOUNT(extrPtfSynth[fromRec], field) -
	       	           GET_AMOUNT(extrPtfSynth[tillRec], field);
		}
	}

	FREE(extrPtfSynth);
	return(diff);
}


/************************************************************************
**
**  Function    :  FIN_GetCrystalDates()
**
**  Description :  Compute the crystal dates table according parameters
**                 
**  Arguments   :  
**
**  Return      :  
**
*************************************************************************/
STATIC RET_CODE FIN_GetCrystalDates(DATETIME_T     **crystalDatesPtr,
                                    int             *crystalNbrPtr,
                                    DATETIME_T      *valDatePtr,
                                    DATETIME_T      *shRebalDatePtr,
                                    FLAG_T          *rebalFlgPtr,           /* REF6025 - CSY - 010706: indicates wether we have defined a periodic rebalancing */
                                    TINYINT_T        freq,
                                    FREQUNIT_ENUM    freqUnit,
                                    IDXTIMERULE_ENUM rebalRule,
                                    DATETIME_T       rebalDate,
                                    DATETIME_T       begDate,
                                    DATETIME_T       endDate)
{
    RET_CODE    ret=RET_SUCCEED;
    int         i=0, firstCrystIdx=0;
    

    /* create the crystal dates (in function of freq, rebal_rule and instr_compo) */
    if (freq > 0 && freqUnit != FreqUnit_None && 
        !(rebalDate.date == 0 && rebalDate.time == 0))
    {
        /* create the crystal dates  between rebalDate and endDate */
        ret = DATE_CrystalDates(rebalDate, endDate, freq, freqUnit, FALSE,
			                    crystalDatesPtr, crystalNbrPtr, NULL, NULL, SameDayIn, nullptr, nullptr);

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)  
	    {
		    return(ret);
	    }

        if (DATETIME_CMP(begDate, rebalDate) < 0)
        {
            /* realloc crystalDates to put begDate inside */
            (*crystalDatesPtr) = (DATETIME_T*) REALLOC((*crystalDatesPtr),
						                              ((*crystalNbrPtr)+1)*sizeof(DATETIME_T));

		    if ((*crystalDatesPtr) == nullptr)
		    { 
			    MSG_RETURN(RET_MEM_ERR_ALLOC); 
		    }

            (*crystalNbrPtr)++;

            /* shift the array */
            for (i=(*crystalNbrPtr)-1; i > 0; i--)
            {
                (*crystalDatesPtr)[i] = (*crystalDatesPtr)[i-1];
            }
            /* add begDate in the array of crystal dates */
            (*crystalDatesPtr)[0] = begDate;
        }
        else
        {
            /* advance in crystal dates array till begDate */
            while(i < (*crystalNbrPtr) && 
                    DATETIME_CMP((*crystalDatesPtr)[i], begDate) <= 0)
            {  
                firstCrystIdx = i;
                i++;
            }

            if (firstCrystIdx > 0)
            {
                /* shift crystalDate  and realloc */
                for (i= 0; i<(*crystalNbrPtr)-firstCrystIdx; i++)
                {
                    (*crystalDatesPtr)[i] = (*crystalDatesPtr)[i+firstCrystIdx];
                }

                /* realloc (remove dates before begDate) */
                (*crystalDatesPtr) = (DATETIME_T*) REALLOC((*crystalDatesPtr),
						                  ((*crystalNbrPtr)-firstCrystIdx)*sizeof(DATETIME_T));
                if ((*crystalDatesPtr) == nullptr)
		        { 
			        MSG_RETURN(RET_MEM_ERR_ALLOC); 
		        }

                (*crystalNbrPtr) = (*crystalNbrPtr)-firstCrystIdx;
            }

            /* crystalDate[0] must alway be equal to begDate */
            if (DATETIME_CMP((*crystalDatesPtr)[0], begDate) < 0)
            {
                (*shRebalDatePtr) = (*crystalDatesPtr)[0];  /* REF6025 - CSY - 020422 */

                /* REF6025 - CSY - 020419: setting rebalFlg */
                if(rebalRule == IdxTimeRule_None || 
                        rebalRule == IdxTimeRule_InitialWeight ||
                        rebalRule == IdxTimeRule_InitialWeightIrregular)
                {
                    (*rebalFlgPtr) = TRUE;
                }

                if (rebalRule == IdxTimeRule_None || 
                        rebalRule == IdxTimeRule_InitialWeight)
                    /* if no irregular, weights at begDate must be weights valid
                    at valDate (<begDate) */
                {
                    (*valDatePtr) = (*crystalDatesPtr)[0];
                    
                }
                (*crystalDatesPtr)[0] = begDate;
            }
            else
            {
                /* no initial weights computation if the begDate equals a rebalancing date */
                if (rebalRule == IdxTimeRule_InitialWeight || 
                        rebalRule == IdxTimeRule_InitialWeightIrregular)
                    rebalRule = (IDXTIMERULE_ENUM)(rebalRule - 1);    /* no initial weights: 3 becomes 2, 1 becomes 0 */ /* REF7264 - LJE - 020131 */
            }
        }
    }
    else    
    {
        /* crystalDates is made of only two dates: begDate and endDate */
        (*crystalNbrPtr) = 2;
        (*crystalDatesPtr) = (DATETIME_T*) CALLOC((*crystalNbrPtr), sizeof(DATETIME_T)); 

	    if ((*crystalDatesPtr) == nullptr)
	    {
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        (*crystalDatesPtr)[0] = begDate;
        (*crystalDatesPtr)[1] = endDate;
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrCompositeBenchReturn()
**
**  Description :   Calculate the return of received composite instrument 
**                 
**  Arguments   :   instrPtr instrument structure pointer
**                  endDate  end date
**                  begDate  begin date
**                  currId   currency identifier
**                  returnTpEn return type
**                  returnNatEn return nature
**                  capGainTax  - tax rate applied to any capital GAIN 
**                  incGainTax  - tax rate applied to any income EARNED 
**                  taxAccrInterFlg indicates wheter  the income tax rate 
**                                  applies to any accrued interest (dflt YES)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-16215 - LJE - 130422 : Extract as function
**  Modification:   
**  
**
********************************************************************************/
RET_CODE FIN_InstrCompositeBenchReturn(DBA_HIER_HEAD_STP       hierHead,
                                      ID_T                    instrId,
                                      DBA_DYNFLD_STP          instrStp,
                                      FIN_BENCHRETPARAM_STP   benchRetParamStp,
                                      FIN_RETURNPARAM_STP     returnParamStp,
                                      TINYINT_T               freq,
                                      FREQUNIT_ENUM           freqUnit,
                                      ID_T                    contribObjectId,
                                      CONTRIBRULE_ENUM        contribRule,
                                      ID_T                    priceValRuleId,
                                      ID_T                    exchValRuleId,
                                      FLAG_T                  checkStratFlg,
                                      FLAG_T                  anaBenchFlg,
                                      ID_T                  **stratIdTabPtr,
                                      int                    *stratIdNbrPtr,
				                      DBA_DYNFLD_STP		  ESLPtr,		
                                      IDXTIMERULE_ENUM        rebalRule,
                                      DATETIME_T              rebalDate,
			                          DATETIME_T              begDate,
			                          DATETIME_T              endDate,
                                      double                 *benchRetPtr,
                                      double                 *adjWeight,
                                      FLAG_T                 *foundFlg)
{
    RET_CODE        ret=RET_SUCCEED;
    DBA_DYNFLD_STP  getArg;  /* PMSTA-25331 - TEB - 20171018 */
    double          benchRet=1.0;
    double          periodRet;
    int             selInstrCompoNbr=0;
    DBA_DYNFLD_STP *selInstrCompoTab = NULL;
    int             crystalNbr = 0;
    DATETIME_T     *crystalDates =nullptr;
    int             i, k;
    DATETIME_T      valDate = begDate;
    DATETIME_T      firstDate= begDate, secondDate= begDate, 
                    shRebalDate=rebalDate;    /* REF6025 - CSY - 020422: shifted rebalDate */
    FLAG_T          rebalFlg=FALSE;
    FLAG_T          foundContribFlg = FALSE;

    FIN_WEIGHTHEAD_ST  weightHead;

    memset(&weightHead, '\0', sizeof(FIN_WEIGHTHEAD_ST));

    *benchRetPtr = 0.0;

    if ((ret = FIN_GetCrystalDates(&crystalDates,
                                    &crystalNbr,
                                    &valDate,
                                    &shRebalDate,
                                    &rebalFlg,
                                    freq,
                                    freqUnit,
                                    rebalRule,
                                    rebalDate,
                                    begDate,
                                    endDate)) != RET_SUCCEED)
    {
        return (ret);
    }

    /* input structure for select */
	if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)  /* PMSTA-25331 - TEB - 20171018 */
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");  /* PMSTA-25331 - TEB - 20171018 */
        return(RET_MEM_ERR_ALLOC);
    }

    /* set input structure for select  */
	SET_ID(getArg, Get_Arg_ObjId, instrId); /* id of the benchmark */  /* PMSTA-25331 - TEB - 20171018 */ /* PMSTA-36724 - Smitha - 190729 */
	SET_DATETIME(getArg, Get_Arg_Date, valDate);  /* PMSTA-25331 - TEB - 20171018 */
	SET_DATETIME(getArg, Get_Arg_ShortDate, endDate);  /* PMSTA-25331 - TEB - 20171018 */

    if (benchRetParamStp->adjWeightFlg == FALSE)
    {
        benchRetParamStp->date1 = valDate;
        benchRetParamStp->date2 = endDate;
    }

    /* select all the valid instr_compos between domain begDate and endDate dates */
	if ((ret = DBA_Select2(InstrCompo, UNUSED, Get_Arg, getArg,   /* PMSTA-25331 - TEB - 20171018 */
	                       A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
	                       &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
    {
        FREE(selInstrCompoTab); 
        return(ret);
    }

	FREE_DYNST(getArg, Get_Arg);  /* PMSTA-25331 - TEB - 20171018 */


    if ((rebalRule == IdxTimeRule_Irregular || 
        rebalRule == IdxTimeRule_InitialWeightIrregular) && selInstrCompoNbr > 0)
    {
        if ((ret = FIN_MergeIrregDates(begDate, &crystalDates, &crystalNbr, (TLS_CMPFCT *)FIN_CmpInstrCompoByAscBegDate,  /* REF7264 - LJE - 020131 */
			A_InstrCompo_BeginDate, selInstrCompoTab, selInstrCompoNbr)) != RET_SUCCEED)
        {
            DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);
            return(ret);
        }
    }

    /* now, crystal dates array is set */
    
    /* sort  by desc. begin date */
    TLS_Sort((char*) selInstrCompoTab, selInstrCompoNbr, sizeof(DBA_DYNFLD_STP), 
                 (TLS_CMPFCT *)FIN_CmpInstrCompo, (PTR**)NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

    /* loop on the crystal dates */
    for(i= 0; i < crystalNbr-1 ; i++)
    {
        periodRet = 0.0;
        firstDate = crystalDates[i];
        secondDate = crystalDates[i+1];

        if (i>0)
            valDate = firstDate;

        k = 0;
        /* for each period, find the valid instr compo (=> valid weights) */  
        /*instr compo are sorted by desc. valid. date) */
        while (k < selInstrCompoNbr &&
                            DATETIME_CMP(GET_DATETIME(
                            selInstrCompoTab[k], 
							A_InstrCompo_BeginDate), valDate) > 0)
                        k++;
        
        if (k < selInstrCompoNbr &&
                            DATETIME_CMP(GET_DATETIME(
                            selInstrCompoTab[k], 
							A_InstrCompo_BeginDate), valDate) <= 0)
        {
            if ((ret = FIN_InitWeightHeader(&weightHead, 
                      Instr,
                      instrId,
                      instrStp,   /* ptr on instrument */
                      FALSE,
                      NULL,
                      FALSE,
                      firstDate, 
                      secondDate)) != RET_SUCCEED)
            {
				DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
				FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                return (ret);
            }

            if ((ret = FIN_ComputeWeight(instrId,
										 instrStp,
										 NULL,
										 Instr,
									     firstDate,
										 returnParamStp,
										 rebalRule, 
										 contribObjectId,
										 contribRule, 
										 priceValRuleId, 
										 exchValRuleId,
										 hierHead,
										 weightHead.firstWeight,
										 &(selInstrCompoTab[k]),
										 (selInstrCompoNbr - k),
                                         FALSE, /* SUPPORT-6697 - LJE - 160609 */
										 checkStratFlg,   /* REF6025 - CSY - 010606 */
										 anaBenchFlg,    /* REF7422 - CSY - 020605 */
										 stratIdTabPtr,  /* REF6025 - CSY - 010607 */
										 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
										 ESLPtr /* REF10274 - RAK - 040506 */)) != RET_SUCCEED)
            {
				DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
				FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                return (ret);
            }

            if (i == 0 && (rebalRule == IdxTimeRule_InitialWeight ||
                                rebalRule == IdxTimeRule_InitialWeightIrregular))
            {
                /* irregulars must be taken into account for sub-strategies in
                check strategy ==> force rebalRule to get the irregulars */
                if (checkStratFlg == TRUE)  /* REF6025 - CSY - 010611 */
                    rebalRule = IdxTimeRule_InitialWeightIrregular;

                /* REF6025 - CSY - 020422 */
                if(rebalFlg == TRUE)
                {
                    valDate = shRebalDate;
                }

                /* compute the period return between crystalDates i and i+1 */
                if ((ret = FIN_ComputeInitWeight(&weightHead, 
											     returnParamStp,
												 rebalRule,
												 contribObjectId, 
												 contribRule, 
												 priceValRuleId,
												 exchValRuleId,
												 benchRetParamStp,  /* REF6025 - CSY - 010614 */
												 rebalFlg,   /* REF6025 - CSY - 010706 */
												 valDate,    /* REF6025 - CSY - 010706 */
												 anaBenchFlg,    /* REF7422 - CSY - 020605 */
												 ESLPtr,			/* REF10274 - RAK - 040506 */
												 hierHead)) != RET_SUCCEED)
                {
					DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
					FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
					return(ret);
                }

                /* REF6025 - CSY - 010614 */
                if (benchRetParamStp->adjWeightFlg== TRUE)
                {
                    if (checkStratFlg == FALSE)
                    {
                        /* search the asked element (criteria on contribObjectId and set adjWeight) */
                        if ((ret = FIN_SearchWeight(weightHead.firstWeight,
													contribObjectId,
													foundFlg,
													adjWeight)) != RET_SUCCEED)
                        {
							DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
							FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                            return(ret);
                        }
                    }
                
                    /* free weights  before exiting */
                    ret=FIN_FreeWeightTab(&weightHead);

					/* REF9071 - RAK - 030805 - nimportkwak
                    if (checkStratFlg == FALSE)
                        DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); */

                    FREE(crystalDates);

                    /* now  adjWeight is setted: we can exit */
					DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
					return (RET_SUCCEED);
                }
            }
        
            foundContribFlg = FALSE;
            /* compute the period return between crystalDates i and i+1 */
            if ((ret = FIN_CompositeBenchReturn(weightHead.firstWeight,
												Instr, 
												secondDate,
												firstDate,
												returnParamStp,
												rebalRule, 
												contribObjectId, 
												contribRule, 
												priceValRuleId,
												exchValRuleId,
												benchRetParamStp, /* REF6025 - CSY - 010614 */
												FALSE,         /* REF6025 - CSY - 010611 */
												anaBenchFlg, /* REF7422 - CSY - 020605 */
												&foundContribFlg,
												ESLPtr,		/* REF10274 - RAK - 040506 */
												hierHead)) != RET_SUCCEED)
            {
				DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
				FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                return(ret);
            }

            /* chain the period returns */
            benchRet = benchRet * (1 + (weightHead.firstWeight)->periodReturn);

            /* free weights for the current period */
            if ((ret = FIN_FreeWeightTab(&weightHead)) != RET_SUCCEED)
            {
				DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);	/* REF10304 - RAK - 041215 */
				FREE(crystalDates);													/* REF7475 - LJE - 020701 */
                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                return(ret);
            }
        } 
        else
        {
            /* no valid instr_compo found at val date: send message in log */
            DATE_FORMAT_ST	dateFormat;
            char tab[50];
            
            dateFormat.ordre = Dmy;
            strcpy(dateFormat.yearSep,  "/");
            strcpy(dateFormat.monthSep, "/");
            strcpy(dateFormat.daySep,   "/");
            dateFormat.yearFormat = 1;
            dateFormat.monthFormat = 0;
            
            DATE_FormatToStr(tab, valDate.date, &dateFormat);
            MSG_SendMesg(RET_FIN_ERR_ELTNOTFOUND, 1, FILEINFO, 
                GET_CODE(instrStp, A_Instr_Cd), tab);
        }
    }

    DBA_FreeDynStTab(selInstrCompoTab, selInstrCompoNbr, A_InstrCompo);
    FREE(crystalDates);
    
    *benchRetPtr = benchRet - 1;

    return ret;
}

/************************************************************************
**
**  Function    :  FIN_BenchReturn()
**
**  Description :  Calculate the return of any object (value varies over time)
**                 
**  Arguments   :  objectId    object identfier
**                 objectEn    object enum (Instr, Ptf, ...)
**                 endDate     date until wich the return is computed
**                 begDate     date from wich the returm must be computed 
**                             OR
**                 linePos     indicates that the start_date is n nbr of lines 
**                             before the end_date in ptf synthetic data
**                 currId      currency in which any return is computed 
**			       (instrument reference currency by dflt)
**                 returnTpEn  return type 
**			       - total return, this is the return including all
**				  factors (capital, income, currency)
**			       - capital return, this is the return due to ap-
**				 preciation in the instrument reference currency
**                             - income return, this is the return due to any
**				 income being received (or paid) in this instr.
**                 returnNatEn return nature
**                             - local return, computes the above return in the
**                               instrument currency
**			       - currency return, computes the above return in
**                               the input currency	       
**                             - currency effect return, indicates the return
**                               due to the difference between the aforemen-
**                               tioned local currency return and the currency 
**                               return
**                 capGainTax  - tax rate applied to any capital GAIN 
**                 incGainTax  - tax rate applied to any income EARNED 
**                 taxAccrInterFlg indicates wheter  the income tax rate 
**                                 applies to any accrued interest (dflt YES)
**                 capCurrPlRuleEn indicates how the currency profit or loss
**                                 on the capital/income profit and loss is 
**                                 attributed
**                                 - system appl_param
**                                 - final
**                                 - mixed
**                                 - initial
**
**  Return      :  return
**                 0 if initial value is 0
**                 0 if no income event (when asked)
** Modif:          REF5358 - CSY - 001113: management of  composite benchmarks
**                 REF6025 - CSY - 010530: price adjusted weights 
**                 REF7422 - CSY - 020605  anaBenchFlg TRUE if use A_StratElt_AnaBenchObjId
**                 REF7422 - CSY - 020627: benchStorageFlg
**
*************************************************************************/
RET_CODE FIN_BenchReturn(ID_T                objectId,
					     DBA_DYNFLD_STP      inObjPtr,
		                 OBJECT_ENUM         objectEn,
	                     DATETIME_T          endDate,
						 DATETIME_T          begDate,
                         FIN_RETURNPARAM_STP returnParamStp,
                         IDXTIMERULE_ENUM    rebalRule,
                         TINYINT_T           freq,
                         FREQUNIT_ENUM       freqUnit,
                         DATETIME_T          rebalDate,
                         ID_T                contribObjectId,
                         CONTRIBRULE_ENUM    contribRule,
                         ID_T                priceValRuleId,
                         ID_T                exchValRuleId,
                         FLAG_T              checkStratFlg,		/* REF6025 - CSY - 010530 */ 
                         FLAG_T              adjWeightFlg,		/* REF6025 - CSY - 010530 */ 
                         FLAG_T              benchStorageFlg,	/* REF7422 - CSY - 020405 */
                         FLAG_T              anaBenchFlg,		/* REF7422 - CSY - 020605 */
                         double              *adjWeight,		/* REF6025 - CSY - 010530 */
                         FLAG_T              *foundFlg,			/* REF6025 - CSY - 010530 */ 
                         double              *benchRet,
                         ID_T                **stratIdTabPtr,	/* REF6025 - CSY - 010607 */
                         int                 *stratIdNbrPtr,	/* REF6025 - CSY - 010607 */
						 DBA_DYNFLD_STP		 ESLPtr,			/* REF10274 - RAK - 040506 */
                         DBA_HIER_HEAD_STP   hierHead)
{
    double periodRet =0.0; /* REF5358 - CSY - 001115 */
     /* REF5358 - CSY - 001115 */
    int             DSENbr=0;
    int             selStratHistNbr=0;
    int j=0;
    RET_CODE        ret=RET_SUCCEED;
    DATETIME_T  firstDate= begDate, secondDate= begDate, 
                shRebalDate=rebalDate;    /* REF6025 - CSY - 020422: shifted rebalDate */
    int i=0;
	char   allocOk;
	int    idFld;
	DBA_DYNST_ENUM allDynSt, getDynSt;
	DBA_DYNFLD_STP objPtr=NULLDYNST, getPtr=NULLDYNST,
        domainArg=NULLDYNST,    /* REF5358 - CSY - 001115 */
        *selStratHistTab = (DBA_DYNFLD_STP*)NULL, *DSETab = (DBA_DYNFLD_STP*)NULL;

    ID_T        valStratHistId=0, currId = returnParamStp->currId;
    FLAG_T      foundContribFlg    = FALSE;
                
    FIN_WEIGHTHEAD_ST  weightHead;
    FIN_BENCHRETPARAM_ST    benchRetParamSt;

	FLAG_T	selStratHistAllocFlg=FALSE;
    
    DATETIME_T     *crystalDates =nullptr;
    DATETIME_T      valDate = begDate;
    int             crystalNbr = 0;
    FLAG_T          rebalFlg = FALSE;

    
    memset(&weightHead, '\0', sizeof(FIN_WEIGHTHEAD_ST));
    memset(&benchRetParamSt, '\0', sizeof(FIN_BENCHRETPARAM_ST));
    benchRetParamSt.checkStratFlg = checkStratFlg;
    benchRetParamSt.adjWeightFlg = adjWeightFlg;
    

    *benchRet=1.0;
    *adjWeight = 0.0;
    
    

    /* REF8844 - LJE - 030415 */
	if (objectEn == Instr)
    {

		allDynSt = A_Instr;
		getDynSt = S_Instr;
		idFld    = S_Instr_Id;
		
    }
	/* REF5358 - CSY - 001113 */
    else if (objectEn == Strat)
    {

        allDynSt = A_Strat;
		getDynSt = S_Strat;
		idFld    = S_Strat_Id;
		
    }
    else if (objectEn == DerivedStrat)
    {
        /* REF6082 - CSY - 010919 */
        allDynSt = A_DerivedStrat; 
		getDynSt = S_DerivedStrat;
		idFld    = S_DerivedStrat_Id;
		
    }
    else 
    {
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_BenchReturn", "object");
		return(RET_GEN_ERR_INVARG);
	}

	if (inObjPtr == NULLDYNST)
	{
	    if ((objPtr = ALLOC_DYNST(allDynSt)) == NULLDYNST)
	    {
	   	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    if ((getPtr = ALLOC_DYNST(getDynSt)) == NULLDYNST)
	    {
		    FREE_DYNST(objPtr, allDynSt);
	   	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    SET_ID(getPtr, idFld, objectId);

	    if (DBA_Get2(objectEn, UNUSED, getDynSt, getPtr, 
		         allDynSt, &objPtr, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	    {
		    FREE_DYNST(objPtr, allDynSt);
		    FREE_DYNST(getPtr, getDynSt);
		    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_BenchReturn", "identifier");
		    return(RET_GEN_ERR_INVARG);
	    }

	    FREE_DYNST(getPtr, getDynSt);
	    allocOk = TRUE;
	}
	else
	{
		objPtr  = inObjPtr;
		allocOk = FALSE;
	}

    /* REF8844 - LJE - 030415 */
	if (objectEn == Instr)
    {
        /* input currency not given, use instrument currency */
        if (currId == -1)
	        currId = GET_ID(objPtr, A_Instr_RefCurrId);

        if ((GET_ENUM(objPtr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue)&&
            (GET_ENUM(objPtr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
        {     
			/* Compute main return value */
            FIN_InstrCompositeBenchReturn(hierHead,
                              GET_ID(objPtr, A_Instr_Id),
												 objPtr,
                                          &benchRetParamSt,
												 returnParamStp,
                                          freq,
                                          freqUnit,
												 contribObjectId,
												 contribRule, 
												 priceValRuleId, 
												 exchValRuleId,
                                          checkStratFlg,
                                          anaBenchFlg,
                                          stratIdTabPtr,
                                          stratIdNbrPtr,
			                              ESLPtr,		
														 rebalRule,
                                          rebalDate,
		                                  begDate,
		                                  endDate,
                                          benchRet,
                                          adjWeight,
                                          foundFlg);
                } 
                else
                {
	        *benchRet = FIN_InstrBenchReturn(objPtr,
											 endDate,
											 begDate,
											 currId,
											 returnParamStp->returnTpEn, 
					                         returnParamStp->returnNatEn,
											 returnParamStp->capGainTax,
											 returnParamStp->incGainTax, 
                                             returnParamStp->taxAccrInterFlg, 
                                             priceValRuleId,
											 exchValRuleId, /* REF5358 - CSY - 001219 */
											 returnParamStp, /* PMSTA08895 - LJE - 091102 */
                                             hierHead);
        }
    }
    /* REF5358 - CSY - 001113 */
    else if (objectEn == Strat)
    {
        /* PMSTA-16215 - LJE - 130422 - Use function instead of direct code */
        FIN_GetCrystalDates(&crystalDates,
                            &crystalNbr,
                            &valDate,
                            &shRebalDate,
                            &rebalFlg,
                            freq,
                            freqUnit,
                            rebalRule,
                            rebalDate,
                            begDate,
                            endDate);

        if (checkStratFlg == TRUE 
            || benchStorageFlg == TRUE) /* REF7422 - CSY - 020627 */
        {

            /* get the valid strategy history for the given strategy */
            selStratHistTab = GET_EXTENSION_PTR(objPtr, A_Strat_A_StratHist_Ext);
            selStratHistNbr = GET_EXTENSION_NBR(objPtr, A_Strat_A_StratHist_Ext);
			/* REF9071 - RAK - 030805 - nimportkwak */
			selStratHistAllocFlg = FALSE;

			/* REF9125 - RAK - 031113 - ce bout de code a un sens ici �galement ! */
			/* je pense que le 020627 on y a pas fait attention ...*/
			if (adjWeightFlg == FALSE)
            {
                benchRetParamSt.date1 = valDate;
                benchRetParamSt.date2 = endDate;
            }
        }
        else
        {
            /* select strategy histories valid between begGate and endDate */
            /* input structure for select */
            if ((domainArg = ALLOC_DYNST(A_Domain)) == NULLDYNST)
            {
				FREE(crystalDates); /* REF7475 - LJE - 020701 */
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Domain");
				if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                return(RET_MEM_ERR_ALLOC);
            }

            SET_ID(domainArg, A_Domain_StratObjId, objectId); 
            SET_DATETIME(domainArg, A_Domain_InterpFromDate, valDate);  /* CSY - 010202: valDate instead of begDate */  
            SET_DATETIME(domainArg, A_Domain_InterpTillDate, endDate);

            if (adjWeightFlg == FALSE)
            {
                benchRetParamSt.date1 = valDate;
                benchRetParamSt.date2 = endDate;
            }
        
            /* select all the strategy historys between domain from and till dates */
		    if ((ret = DBA_Select2(StratHist, UNUSED, A_Domain, domainArg,
			              A_StratHist, &selStratHistTab, UNUSED, UNUSED, 
			              &selStratHistNbr, UNUSED, UNUSED))!=RET_SUCCEED)
            {
				FREE(crystalDates); /* REF7475 - LJE - 020701 */
                FREE_DYNST(domainArg, A_Domain);
                FREE(selStratHistTab);
				if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                return(RET_SUCCEED);
            }
            FREE_DYNST(domainArg, A_Domain);    /* purify */

			/* REF9071 - RAK - 030805 - nimportkwak */
			selStratHistAllocFlg = TRUE;

            /* create irregular dates based on strategy histories */
            if ((rebalRule == IdxTimeRule_Irregular || 
                    rebalRule == IdxTimeRule_InitialWeightIrregular) && selStratHistNbr > 0)
            {
                if ((ret = FIN_MergeIrregDates(begDate, &crystalDates, &crystalNbr, (TLS_CMPFCT *)FIN_CmpStratHistByAscBegDate,  /* REF7264 - LJE - 020131 */
                                        A_StratHist_BegDate, selStratHistTab, selStratHistNbr))!=RET_SUCCEED)
                {
					DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); /* REF9071 - RAK - 030805 - memory leak */
					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
					return(RET_SUCCEED);
                }
            }
        }

        if (selStratHistNbr == 0 || selStratHistTab == NULL)
		{
			FREE(crystalDates); /* REF7475 - LJE - 020701 */
			/* REF10541 - RAK - 040812 - new message and new return */
			/* return(RET_GEN_INFO_NODATA); */
		
			MSG_SendMesg(RET_FIN_ERR_DYNWEIGHT, 2, FILEINFO, 
						                        GET_CODE(objPtr, A_Strat_Cd));            
			if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
            FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
			return(RET_FIN_ERR_DYNWEIGHT);
		}
        
        /* sort the strategy histories by desc. begin date */
        TLS_Sort((char*) selStratHistTab, selStratHistNbr, sizeof(DBA_DYNFLD_STP), 
	                 (TLS_CMPFCT *)FIN_CmpStratHistByDescBegDate, (PTR**)NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */
          
        /* loop on the periods */
        for(i= 0; i < crystalNbr-1; i++)
        {
            periodRet = 0.0;
            firstDate = crystalDates[i];
            secondDate = crystalDates[i+1];
            if (i > 0)
                valDate = firstDate;
			/* REF10801 - RAK - 041130 */
			/* regression of the good correction REF10690 */
			/* in that case we want to use the first one */
			else if (checkStratFlg == TRUE)	/* REF10801 - RAK - 041215 - Do it only for check strategy */
			{
				/* if valDate is before the first (and the only one history in case of check strat), */
				/* set valDate to this history date */
				if (selStratHistNbr > 0 && 
					DATETIME_CMP(valDate, GET_DATETIME(selStratHistTab[selStratHistNbr-1], A_StratHist_BegDate)) < 0)
				{
					valDate = GET_DATETIME(selStratHistTab[selStratHistNbr-1], A_StratHist_BegDate);
				}
			}

            j=0;
            while ( /*
                    (j < selStratHistNbr && DATETIME_CMP(GET_DATETIME(
                                selStratHistTab[j], A_StratHist_BegDate), 
                                valDate) == 0)
								&& */ 
                                /* REF9075 MCA compute also when the date begin and history are egual */
                                /* REF10690 - LJE - 041014 : Remove */
				  (j < selStratHistNbr && DATETIME_CMP(GET_DATETIME(
                                selStratHistTab[j], A_StratHist_BegDate), 
                                valDate) > 0))
            {
                j++;
            }

            if (j < selStratHistNbr)
            {
                valStratHistId = GET_ID(selStratHistTab[j], A_StratHist_Id);

                
                if ((ret = FIN_InitWeightHeader(&weightHead, 
										        Strat,
							                    valStratHistId,
										        objPtr,   /* ptr on strategy */
												FALSE,
												selStratHistTab[j],
												FALSE,
												firstDate, 
												secondDate)) != RET_SUCCEED)
                {
					/* REF9071 - RAK - 030805 - memory leak */
					if (selStratHistAllocFlg == TRUE)
					{
						DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); 
					}
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                    return (ret);
                }

                if ((ret = FIN_ComputeWeight(valStratHistId,
											 objPtr,
											 selStratHistTab[j],
											 Strat,
											 firstDate,
											 returnParamStp,
											 rebalRule,
											 contribObjectId,
											 contribRule,
											 priceValRuleId,
											 exchValRuleId,
											 hierHead,
											 weightHead.firstWeight,
											 NULL,
											 0,
                                             TRUE, /* SUPPORT-6697 - LJE - 160609 */
											 checkStratFlg,				/* REF6025 - CSY - 010606 */
										     anaBenchFlg,				/* REF7422 - CSY - 020605 */
											 stratIdTabPtr,				/* REF6025 - CSY - 010607 */
											 stratIdNbrPtr,				/* REF6025 - CSY - 010607 */
											 ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                {
					/* REF9071 - RAK - 030805 - memory leak */
					if (selStratHistAllocFlg == TRUE)
					{
						DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); 
					}
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                    return (ret);
                }

                if (i == 0 && (rebalRule == IdxTimeRule_InitialWeight ||
                                        rebalRule == IdxTimeRule_InitialWeightIrregular))
                {
                    /* irregulars must be taken into account for sub-strategies in
                    check strategy ==> force rebalRule to get the irregulars */
                    if (checkStratFlg == TRUE)  /* REF6025 - CSY - 010611 */
                        rebalRule = IdxTimeRule_InitialWeightIrregular;

                    /* REF6025 - CSY - 020717 */
                    if(rebalFlg == TRUE)
                    {
                        valDate = shRebalDate;
                    }

                    /* compute the initial weights: performance may modify them */
                    if ((ret = FIN_ComputeInitWeight(&weightHead, 
												     returnParamStp,
													 rebalRule, contribObjectId, 
													 contribRule, 
													 priceValRuleId,
													 exchValRuleId,
													 &benchRetParamSt,  /* REF6025 - CSY - 010614 */
													 rebalFlg,   /* REF6025 - CSY - 010706 */
													 valDate,    /* REF6025 - CSY - 010706 */
													 anaBenchFlg,    /* REF7422 - CSY - 020605 */
													 ESLPtr,			/* REF10274 - RAK - 040506 */
													 hierHead)) != RET_SUCCEED)
                    {
						/* REF9071 - RAK - 030805 - memory leak */
						if (selStratHistAllocFlg == TRUE)
						{
							DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); 
						}
						FREE(crystalDates); /* REF7475 - LJE - 020701 */
						if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                        FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                        return(ret);
                    }

                    /* REF6025 - CSY - 010530 */
                    if (adjWeightFlg == TRUE)
                    {
                        if (checkStratFlg == FALSE)
                        {
                            /* search the asked element (criteria on contribObjectId and set adjWeight) */
                            if ((ret = FIN_SearchWeight(weightHead.firstWeight,
														contribObjectId,
														foundFlg,
														adjWeight)) != RET_SUCCEED)
                            {
								/* REF9071 - RAK - 030805 - memory leak */
								if (selStratHistAllocFlg == TRUE)
								{
									DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); 
								}
								FREE(crystalDates); /* REF7475 - LJE - 020701 */
								if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                                return(ret);
                            }
                        }

                        /* in bench storage: do not exit immediately when 
                        adjusted weights are comptuted: compute also the return on the period  */
                        if(benchStorageFlg == FALSE)    /* REF7422 - CSY - 020405 */
                        {
                            /* free weights  before exiting */
                            ret = FIN_FreeWeightTab(&weightHead);

							/* REF9071 - RAK - 030805 - nimportkwak */
                            /* if (checkStratFlg == FALSE)  */
							if (selStratHistAllocFlg == TRUE)
                                DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);

                            FREE(crystalDates);
	                        if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)};

                            /* now  adjWeight is setted: we can exit */
                            return (ret);
                        }
                    }
                }
                
                foundContribFlg = FALSE;
                /* compute the period return between crystalDates i and i+1 */
                if ((ret = FIN_CompositeBenchReturn(weightHead.firstWeight,
													objectEn, 
													secondDate,
													firstDate,
													returnParamStp,
													rebalRule,
													contribObjectId, 
													contribRule, 
													priceValRuleId,
													exchValRuleId,
													&benchRetParamSt, /* REF6025 - CSY - 010608 */
													FALSE,         /* REF6025 - CSY - 010611 */
													anaBenchFlg, /* REF7422 - CSY - 020605 */
													&foundContribFlg,
													ESLPtr,		/* REF10274 - RAK - 040506 */
													hierHead)) != RET_SUCCEED)
                {
					/* REF9071 - RAK - 030805 - memory leak */
					if (selStratHistAllocFlg == TRUE)
						DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                    return(ret);
                }

                /* chain the period returns */
                 *benchRet = *benchRet * (1 + (weightHead.firstWeight)->periodReturn);

                /* free weights for the current period */
                if ((ret = FIN_FreeWeightTab(&weightHead)) != RET_SUCCEED)
                {
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
					/* REF9071 - RAK - 030805 - memory leak */
					if (selStratHistAllocFlg == TRUE)
						DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);
					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    return(ret);
                }
            }
            else
            {
                /* no valid strategy history found at val date: send message in log */
                DATE_FORMAT_ST	dateFormat;
	            char tab[50];
	            
	            dateFormat.ordre = Dmy;
	            strcpy(dateFormat.yearSep,  "/");
	            strcpy(dateFormat.monthSep, "/");
	            strcpy(dateFormat.daySep,   "/");
	            dateFormat.yearFormat = 1;
	            dateFormat.monthFormat = 0;
	            
	            DATE_FormatToStr(tab, valDate.date, &dateFormat);
                MSG_SendMesg(RET_FIN_ERR_ELTNOTFOUND, 1, FILEINFO, 
                    GET_CODE(objPtr, A_Strat_Cd), tab);
            }

        }

		/* REF9071 - RAK - 030805 - nimportkwak */
        /* if(benchStorageFlg == FALSE) */   /* REF7422 - MCA -  020702 */                    
		if (selStratHistAllocFlg == TRUE)
		{
			DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist); /* purify */
		}

        *benchRet = *benchRet - 1;

        FREE(crystalDates);
    }
    else if (objectEn == DerivedStrat)
    {
        /* REF6082 - CSY - 010919 */
        if (checkStratFlg == TRUE)
        {
            /* PMSTA-16215 - LJE - 130422 - Use function instead of direct code */
            FIN_GetCrystalDates(&crystalDates,
                                &crystalNbr,
                                &valDate,
                                &shRebalDate,
                                &rebalFlg,
                                freq,
                                freqUnit,
                                rebalRule,
                                rebalDate,
                                begDate,
                                endDate);

            /* get the derived  strategy elements for the given derived strategy */
            DSETab = GET_EXTENSION_PTR(objPtr, A_DerivedStrat_A_DerivedStratElt_Ext);
            DSENbr = GET_EXTENSION_NBR(objPtr, A_DerivedStrat_A_DerivedStratElt_Ext);
            
            if ((ret = FIN_InitWeightHeader(&weightHead, 
                          Strat,
                          GET_ID(objPtr, A_DerivedStrat_Id),
                          objPtr,   /* ptr on strategy */
                          FALSE,
                          objPtr,   /* derived strategy contains A_DerivedStrat_BegD */
                          FALSE,
                          firstDate, 
                          secondDate)) != RET_SUCCEED)
            {
				if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                return (ret);
            }

            if ((ret = FIN_ComputeWeight(GET_ID(objPtr, A_DerivedStrat_Id), 
                                         objPtr,
										 objPtr,
										 DerivedStrat,
										 firstDate,
										 returnParamStp,
										 rebalRule,
										 contribObjectId,
                                         contribRule,
										 priceValRuleId,
										 exchValRuleId,
                                         hierHead,
										 weightHead.firstWeight,
										 NULL,
										 0,
                                         TRUE, /* SUPPORT-6697 - LJE - 160609 */
                                         checkStratFlg, /* REF6025 - CSY - 010606 */
                                         anaBenchFlg,    /* REF7422 - CSY - 020605 */
                                         stratIdTabPtr,  /* REF6025 - CSY - 010607 */
                                         stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
                                         ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
            {
				if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                return (ret);
            }

            if (rebalRule == IdxTimeRule_InitialWeight ||
                                    rebalRule == IdxTimeRule_InitialWeightIrregular)
            {
                /* irregulars must be taken into account for sub-strategies in
                check strategy ==> force rebalRule to get the irregulars */
                if (checkStratFlg == TRUE)  /* REF6025 - CSY - 010611 */
                    rebalRule = IdxTimeRule_InitialWeightIrregular;

                /* compute the initial weights: performance may modify them */
                if ((ret = FIN_ComputeInitWeight(&weightHead, 
												 returnParamStp,
												 rebalRule,
												 contribObjectId, 
												 contribRule, 
												 priceValRuleId,
												 exchValRuleId,
												 &benchRetParamSt,  /* REF6025 - CSY - 010614 */
												 rebalFlg,   /* REF6025 - CSY - 010706 */
												 valDate,    /* REF6025 - CSY - 010706 */
												 anaBenchFlg,    /* REF7422 - CSY - 020605 */
												 ESLPtr,			/* REF10274 - RAK - 040506 */
												 hierHead)) != RET_SUCCEED)
                {
  					if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)}; /* PMSTA14453 - DDV - 120712 - Purify */
                    FIN_FreeWeightTab(&weightHead); /* PMSTA14453 - DDV - 120712 - Purify */
                    return(ret);
                }

                /* REF6025 - CSY - 010530 */
                if (adjWeightFlg == TRUE)
                {
                    /* free weights  before exiting */
                    ret = FIN_FreeWeightTab(&weightHead);

	                if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)};

                    /* now  adjWeight is setted: we can exit */
                    return (ret);
                }
            }
        }
    }

	if (allocOk == TRUE) {FREE_DYNST(objPtr, allDynSt)};
	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_MergeIrregDates()
**
**  Description :   Calculate the return of received instrument 
**                 
**  Arguments   :   begDate: begin date
**                  crystalDates:   crystallisation dates to be completed with irregular dates
**                  crystalNbr                       
**                  cmpFct:     comparison function (for sort)
**                  fldIdx:     index of dynStEnum (A_InstrCompo_BeginDate or A_StratHist_BegDate)
**                  eltTab:     array of elements
**                  eltNbr:     number of elements
**                  
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation:   REF5358 - CSY - 001123
**  Modif       REF6025 - CSY - 010608: exit if no irregular data   
**
*************************************************************************/
RET_CODE FIN_MergeIrregDates(DATETIME_T      begDate,
                                    DATETIME_T      **crystalDates,
                                    int             *crystalNbr,
                                    TLS_CMPFCT     *cmpFct,
                                    int             fldIdx,
                                    DBA_DYNFLD_STP  *eltTab,
                                    int             eltNbr)
{
    /* compute the array of irregular dates */
    RET_CODE    ret = RET_SUCCEED;       
    int allocSz = eltNbr+1, i=0, j=0, irregNbr=0, oldCrystalNbr=0;
    DATETIME_T     *irregDates =nullptr;

    if (eltNbr == 0)    /* REF6025 - CSY - 010608: no irregular data ==> nothing to merge */
        return (RET_SUCCEED); 

    irregDates = (DATETIME_T*) CALLOC(allocSz, sizeof(DATETIME_T)); 

    if (irregDates == nullptr)
    {
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* sort by ascending begin date */
    TLS_Sort((char*) eltTab, eltNbr, sizeof(DBA_DYNFLD_STP), 
	                 cmpFct/*FIN_CmpInstrCompoByAscBegDate*/, (PTR**)NULL, SortRtnTp_None);

    
    i=0,j=0;
    irregDates[0] = GET_DATETIME(eltTab[0], fldIdx);
    irregNbr++;
    /* loop in array sorted by ascending begin date */
    for (i=0; i < eltNbr; i++)
    {
        /* new irregular date when fldIdx(A_InstrCompo_BeginDate or A_StratHist_BegDate) changes */
        if (DATETIME_CMP(GET_DATETIME(eltTab[i], 
                fldIdx), irregDates[irregNbr-1]) > 0)    /* fldIdx: A_InstrCompo_BeginDate or A_StratHist_BegDate */
        {   
            irregDates[irregNbr] = GET_DATETIME(eltTab[i], fldIdx);   /* fldIdx: A_InstrCompo_BeginDate or A_StratHist_BegDate */
            irregNbr++;  
        }
    }

    /* at this step, irreg dates is naturally already sorted by ascending date
    (no TLS_Sort on irreg dates is required here) */
    allocSz = irregNbr;
    irregDates = (DATETIME_T*) REALLOC(irregDates,
						      allocSz*sizeof(DATETIME_T));
    if (irregDates == nullptr)
    { 
	    MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    /* realloc crystalDates because it will receive irregDates */
    allocSz += (*crystalNbr);
    *crystalDates = (DATETIME_T*) REALLOC(*crystalDates,
						      allocSz*sizeof(DATETIME_T));
    if (*crystalDates == nullptr)
    { 
		FREE(irregDates); /* REF7475 - LJE - 020701 */
	    MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    j=0;
    oldCrystalNbr = (*crystalNbr);
    /* merge the two arrays: crystalDates and irregular dates */
    for(i= 1; i < oldCrystalNbr; i++)
    {
        while (j<irregNbr && (DATETIME_CMP(
                        irregDates[j], (*crystalDates)[i]) <0))
        {
            if (DATETIME_CMP(irregDates[j], (*crystalDates)[i-1]) >0)
            {
                /* irreg dates are put at the end of the crystalDates array:
                the crystalDates array will be sorted after */
                (*crystalDates)[*crystalNbr] = irregDates[j];
                (*crystalNbr)++;
            }
            j++; 
        }
    }

    FREE(irregDates); /* purify */

    /* realloc the array to free the unuesed memory */
    allocSz = *crystalNbr;
    (*crystalDates) = (DATETIME_T*) REALLOC((*crystalDates),
					      allocSz*sizeof(DATETIME_T));
    if ((*crystalDates) == nullptr)
    { 
	    MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    /* sort the array by ascending date */
    TLS_Sort((char*) (*crystalDates), allocSz, sizeof(DATETIME_T), 
	         (TLS_CMPFCT *)FIN_CmpDateTime, (PTR**)NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */
    /*
    TLS_Sort((char*) (*newCrystDates), (*newCrystDatesNbr), sizeof(DATETIME_T), 
	                 FIN_CrystDatesCmp, (PTR**)NULL, SortRtnTp_None);*/

                

    return(ret);


}


/*********************************************************************************************
**
**  Function    :  FIN_ComputeInitWeight()
**
**  Description :  Compute all new initial weight for all weight stored in weightHead structure
**                 
**  Arguments   :  weightHead         header of structure used to store weights
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010119 - DDV
**  Modif.      :  REF6025 - CSY - 010606: add argument checkStratFlg
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeInitWeight(FIN_WEIGHTHEAD_STP	weightHead,
								      FIN_RETURNPARAM_STP   returnParamStp, 
							          IDXTIMERULE_ENUM		rebalRule,
							          ID_T					contribObjectId,
							          CONTRIBRULE_ENUM		contribRule,
							          ID_T					priceValRuleId,
							          ID_T					exchValRuleId,
							          FIN_BENCHRETPARAM_STP	benchRetParamStp,  /* REF6025 - CSY - 010614 */
							          FLAG_T				rebalFlg,
							          DATETIME_T			rebalDate,  /* shifted by freq */
							          FLAG_T				anaBenchFlg,    /* REF7422 - CSY - 020605 */
									  DBA_DYNFLD_STP		ESLPtr,			/* REF10274 - RAK - 040506 */
							          DBA_HIER_HEAD_STP		hierHead)
{
    FLAG_T  foundContribFlg = FALSE;
    DATETIME_T     histDate;
    histDate.date = 0;
    histDate.time = 0;
    
    

    /* REF8844 - LJE - 030415 */
    if (weightHead->firstWeight->objectEnum == Instr)
    {
        if (weightHead->firstWeight->childNbr >0)
			histDate = GET_DATETIME(weightHead->firstWeight->eltTab[0], A_InstrCompo_BeginDate);
        
    }
    else if (weightHead->firstWeight->objectEnum == Strat)
    {

        histDate = GET_DATETIME(weightHead->firstWeight->objectHistPtr, A_StratHist_BegDate);
        
    }

    

    if (rebalFlg == TRUE && (rebalRule == (IDXTIMERULE_ENUM)IdxTimeRule_InitialWeight ||
        (rebalRule == (IDXTIMERULE_ENUM)IdxTimeRule_InitialWeightIrregular && 
        DATETIME_CMP(histDate, rebalDate) < 0)))
    {
        histDate = rebalDate;
    }


    if (histDate.date == (weightHead->beginDate).date)
        return (RET_SUCCEED);

    FIN_CompositeBenchReturn(weightHead->firstWeight,
					         weightHead->firstWeight->objectEnum, 
							 weightHead->beginDate,
							 histDate,
							 returnParamStp, 
							 rebalRule,
							 0,  /* pass 0 for contribObjectId argument for initial weights pre-return */
							 contribRule,
							 priceValRuleId,
							 exchValRuleId, 
							 benchRetParamStp, /* REF6025 - CSY - 010608 */
							 FALSE,         /* REF6025 - CSY - 010611 */
							 anaBenchFlg, /* REF7422 - CSY - 020605 */
							 &foundContribFlg,   /* foundContribFlg */
							 ESLPtr,		/* REF10274 - RAK - 040506 */
							 hierHead);

    weightHead->initialWeightFlg=TRUE;

    FIN_ComputeNewInitWeight(weightHead->firstWeight, benchRetParamStp->checkStratFlg);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  FIN_ComputeInitWeight()
**
**  Description :  Compute all new initial weight a weight and all children
**                 
**  Arguments   :  weight         weight structure to update
**
**  Return      :  
**
**  Creation    :  REFBENCH - 010119 - DDV
**  Modif.      :  REF6025 - CSY - 010606: add argument checkStratFlg
**                 REF6025 - CSY - 010701: set A_StratElt_OldValue
**                 REF6082 - CSY - 010919 manage DerivedStrat
**                 
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeNewInitWeight(FIN_WEIGHT_STP weight, FLAG_T  checkStratFlg)
{
    int i=0;
    NUMBER_T childWeight, childReturn, denomValue=0.0, sumWeight=0.0; /* PMSTA-10683 - LJE - 101018 */

	/* PMSTA-8970 - RAK - 110524 - 1� Compute the delta and the denom value */ /* PMSTA-100683 - LJE - 101018 */
    for (i=0; i<weight->childNbr; i++)
    {
		FIN_ComputeNewInitWeight(weight->childWeightTab[i], checkStratFlg);

		childWeight = weight->childWeightTab[i]->weightValue;
		childReturn = weight->childWeightTab[i]->periodReturn;

		sumWeight += childWeight;
		denomValue += childWeight * (childReturn + 1);
	}

	denomValue += 1. - sumWeight; /* PMSTA-10683 - LJE - 101018 */	

	if (CMP_NUMBER(denomValue, 0.0) != 0)
	{
    	/* PMSTA-8970 - RAK - 110524 - 2� Compute weights */
		for (i=0; i<weight->childNbr; i++)
		{
			childWeight = weight->childWeightTab[i]->weightValue;
			childReturn = weight->childWeightTab[i]->periodReturn;

			weight->childWeightTab[i]->weightValue = childWeight * (childReturn + 1) / 
														 denomValue; /* PMSTA-10683 - LJE - 101018 */
		}

		/* PMSTA-8970 - RAK - 110524 - 4� Update the weights in StratElt */
		if (checkStratFlg == TRUE)
		{
			for (i=0; i<weight->childNbr; i++)
			{
				if ((weight->childWeightTab[i])->objectEnum == Strat ||
					/* element of a strategy given by A_StratElt_BenchObjId and 
					 A_StratElt_BenchEntDictId == instrDictId */
						((weight->childWeightTab[i])->objectEnum == Instr && 
						(weight->childWeightTab[i])->parentWeightPtr != NULL && 
						((weight->childWeightTab[i])->parentWeightPtr)->objectEnum == Strat)
				   ) 
				{
					/* keep in memory the old value */
					SET_NUMBER(weight->eltTab[i], A_StratElt_OldValue,
						GET_NUMBER(weight->eltTab[i], A_StratElt_Value));

					/* in FIN_AddChildWeight: eltTab elements correspond to childWeightTab elements */
					SET_NUMBER(weight->eltTab[i], A_StratElt_Value, 
							100*weight->childWeightTab[i]->weightValue);
				}
			}
		}
	}
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_InstrBenchReturn()
**
**  Description :   Calculate the return of received instrument 
**                 
**  Arguments   :   instrPtr instrument structure pointer
**                  endDate  end date
**                  begDate  begin date
**                  currId   currency identifier
**                  returnTpEn return type
**                  returnNatEn return nature
**                  capGainTax  - tax rate applied to any capital GAIN 
**                  incGainTax  - tax rate applied to any income EARNED 
**                  taxAccrInterFlg indicates wheter  the income tax rate 
**                                  applies to any accrued interest (dflt YES)
**
**  Return      :   RET_SUCCEED or error code
**
********************************************************************************/
double FIN_InstrBenchReturn(DBA_DYNFLD_STP	 instrPtr,
						    DATETIME_T        endDate,
						    DATETIME_T        begDate,
						    ID_T              currId,
						    RETURNTP_ENUM     returnTpEn,
						    RETURNNAT_ENUM    returnNatEn,
						    NUMBER_T          capGainTax,
						    NUMBER_T          incGainTax,
						    FLAG_T            taxAccrInterFlg, 
						    ID_T              priceValRuleId, /* REF5358 - CSY - 001219 */
						    ID_T              exchValRuleId,  /* REF5358 - CSY - 001219 */
					        FIN_RETURNPARAM_STP returnParamStp,       /* PMSTA08895 - LJE - 091102 */		
						    DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE	ret=RET_SUCCEED;
	ID_T		wrkCurrId=currId;
	DATETIME_T	tmpDate;
	double		benchRet=0.0;
	NUMBER_T	incVal=0.0, returnPeriod=0.0;

	/* Compute return in instrument currency */
	switch (returnNatEn)
	{
	/* Compute return in instrument currency */
	case ReturnNat_Local :    
		wrkCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);
		break;

	/* Compute return in input currency */
	case ReturnNat_Curr :    
		wrkCurrId = currId;   
		break;
	}

	tmpDate.date = DATE_Move(begDate.date, 1, Day);
	tmpDate.time = 0;

	/* daily */
	if (tmpDate.date == endDate.date)
	{
		return(FIN_InstrBenchReturnPeriod(instrPtr, endDate, begDate, currId, returnTpEn,
										  returnNatEn, capGainTax, incGainTax, taxAccrInterFlg, 
										  priceValRuleId, exchValRuleId,  
										  returnParamStp, hierHead, FALSE));
	}
	else
	{
		std::set<DATE_T> incDateSet;  //  PMSTA-47762 - JBC - 220131 this is an unsigned it so it is sorted automatically
		ret = FIN_InstrBenchReturnIncome(instrPtr, endDate, tmpDate, wrkCurrId, returnTpEn, incGainTax, exchValRuleId, hierHead, &incVal, TRUE, incDateSet);
		
		/* chain geometrically income period(s) */
		if (ret == RET_SUCCEED && incDateSet.empty() == false)
		{
			/* add begin and end date */
			/* what about beg or end date is coupon date !?! */

		    incDateSet.insert(begDate.date); /* PMSTA-47762 - JBC - 220131 */
            incDateSet.insert(endDate.date);
            std::vector<DATETIME_T> incDateTimeList;
            for(auto it=incDateSet.begin();it != incDateSet.end();++it)
            {   
                DATETIME_T tmpDateTime;
                tmpDateTime.date = *it;
                tmpDateTime.time = 0;
                incDateTimeList.push_back(tmpDateTime);
            }
			/* chain geometrically  */
			benchRet = 1;
			for (size_t i=0; i<incDateTimeList.size()-1; i++)
			{

				returnPeriod = FIN_InstrBenchReturnPeriod(instrPtr, /* end */ incDateTimeList[i+1], /* beg */incDateTimeList[i], 
															currId, returnTpEn, returnNatEn, 
															capGainTax, incGainTax, taxAccrInterFlg, 
															priceValRuleId, exchValRuleId,  
															returnParamStp, hierHead, FALSE);

				benchRet *= (1.0 + returnPeriod);
			}

			benchRet = benchRet - 1.0;

			return(benchRet);
		}
		else	/* no income during period */
		{
			return(FIN_InstrBenchReturnPeriod(instrPtr, endDate, begDate, currId, returnTpEn,
									  returnNatEn, capGainTax, incGainTax, taxAccrInterFlg, 
									  priceValRuleId, exchValRuleId,  
									  returnParamStp, hierHead, TRUE));
		}
	}
}

STATIC RET_CODE FIN_InstrBenchReturnIncome(DBA_DYNFLD_STP    instrPtr, 
										   DATETIME_T        endDate, 
										   DATETIME_T        begDate, 
										   ID_T		         wrkCurrId, 
										   RETURNTP_ENUM     returnTpEn,
										   NUMBER_T	         incGainTax, 
										   ID_T				 exchValRuleId,
										   DBA_HIER_HEAD_STP hierHead,
										   NUMBER_T			 *incVal,
										   FLAG_T			 incDateFlg,
										  std::set<DATE_T> & incDateSet) /* PMSTA-47762 - JBC - 220131 */
{
	DBA_DYNFLD_STP	 *incTab=(DBA_DYNFLD_STP*)NULL, unitInterPtr=NULL; 
	int              i, incNbr;
	FIN_EXCHARG_ST   exchArgSt;					/* REFXZ */
	FLAG_T			 periodFlg, accrRuleFlg=FALSE, updateAccrRuleFlg;	/* PMSTA-9942 - RAK - 110103 */
	ACCRRULE_ENUM	 accrRule= AccrRule_None;
   
	if ((unitInterPtr = ALLOC_DYNST(UnitInter)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}
 
	/* PMSTA-9942 - RAK - 110103 - We have to update the Actual/Actual too in income computation */
	/* (as in AI computation) elsewhere we have incoherent computed income and a bug (wrong income, wrong return) */
	FIN_SetSceActActRule(instrPtr, &updateAccrRuleFlg);	

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	RET_CODE		ret=RET_SUCCEED;
	INSTRNAT_ENUM	instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);

	if (returnTpEn == ReturnTp_Total || returnTpEn == ReturnTp_Income)
	{
		if (instrNat == InstrNat_Bond      || instrNat == InstrNat_CashAcct ||
			instrNat == InstrNat_MoneyMkt  || instrNat == InstrNat_Discount ||
			instrNat == InstrNat_CumOption || instrNat == InstrNat_ConvertBond ||
			instrNat == InstrNat_Other)
		{
			periodFlg = TRUE;
			FIN_GetInstrAccrRule(begDate.date, instrPtr, hierHead, &accrRule);	            
			accrRuleFlg = SCE_CheckAccrRule(accrRule);
		}
		else
        {
			periodFlg = FALSE;
        }
		/* PMSTA-10527 - RAK- I think we have to correct the PeriocIncEvtInstrFlow */
		/* (why use Quote and not AmtUnit) and the InstrFlow (journal,event gen) */
		/* (partially paid bond aren't correctly treated and call on each case the FIN_PeriodIncEvtInstrFlow */
		/* but for an hot-fix it is a lot of risk :) */

		/* If new accrual rule, call instr flow functions (which uses simcorp libraries) */ /* REF9085 - YST - 030618 */
		if (accrRuleFlg == TRUE)
		{
			FIN_PeriodIncEvtInstrFlow(instrPtr, wrkCurrId, exchValRuleId, &exchArgSt, /* PMSTA-10527 - RAK - 101021 */
									  begDate, endDate, incGainTax, incVal, incDateFlg, incDateSet, hierHead);
		}
		else if ((DBA_SelectIncEvt(instrPtr, begDate, endDate, endDate, /* PMSTA-12867 - LJE - 111005 - use endDate instead begDate for the validity date */
									&incTab, &incNbr)) == RET_SUCCEED)
		{
			/* PMSTA-11143 - RAK - 101220 - So will compute an AI between 2 coupons */
			for (i=0; i<incNbr; i++)
			{
				if (IS_NULLFLD(incTab[i], A_IncEvt_LastPayDate) == TRUE ||
					GET_DATE(incTab[i], A_IncEvt_LastPayDate) == MAGIC_END_DATE)
				{
					if (i+1 < incNbr)
					{
						SET_DATE(incTab[i], A_IncEvt_LastPayDate, GET_DATE(incTab[i+1], A_IncEvt_BeginDate));
					}
					else
					{
						/* PMSTA-10738 - RAK - 101102 */
						SET_DATE(incTab[i], A_IncEvt_LastPayDate, GET_DATE(instrPtr, A_Instr_EndDate));
					}
				}
			} 

           
            if (periodFlg == FALSE)	/* Not Bonds & Cie */
			{
				FIN_PeriodIncEvtInstrFlow(instrPtr, 
										  wrkCurrId, exchValRuleId, &exchArgSt, /* PMSTA-10527 - RAK - 101021 */ 
										  begDate, endDate, incGainTax, incVal, incDateFlg, incDateSet, hierHead);
			}
            else
            {
                for (i=0; i<incNbr; i++)	
                {
			   
					FIN_PeriodIncEvt(incTab[i], instrPtr, 
									 wrkCurrId, exchValRuleId, &exchArgSt, /* PMSTA-10527 - RAK - 101021 */ 
									 unitInterPtr, begDate, endDate, incGainTax, incVal, incDateFlg, incDateSet, hierHead);
			    }
            }

			DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
		}
		else
		{
			*incVal = 0.0;
		}
	}

	FREE_DYNST(unitInterPtr, UnitInter);
	FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);	/* PMSTA-9942 - RAK - 110103 */
	return(ret);
}
	   
/************************************************************************
**
**  Function    :   FIN_InstrBenchReturnPeriod()
**
**  Description :   Calculate the return of received instrument 
**                 
**  Arguments   :   instrPtr instrument structure pointer
**                  endDate  end date
**                  begDate  begin date
**                  currId   currency identifier
**                  returnTpEn return type
**                  returnNatEn return nature
**                  capGainTax  - tax rate applied to any capital GAIN 
**                  incGainTax  - tax rate applied to any income EARNED 
**                  taxAccrInterFlg indicates wheter  the income tax rate 
**                                  applies to any accrued interest (dflt YES)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP125 - RAK - 960620
**  Modif       :   REF1149 - RAK - 980113
**  Modif.	    :   REF2580 - SSO - 980727
**  Modif.	    :   REF5358 - CSY - 001219: new arguments priceValRuleId, exchValRuleId
**                  REF10256 - TEB - 040615
**
*************************************************************************/
STATIC double FIN_InstrBenchReturnPeriod(DBA_DYNFLD_STP    instrPtr,
                            DATETIME_T        endDate,
		                    DATETIME_T        begDate,
		                    ID_T              currId,
		                    RETURNTP_ENUM     returnTpEn,
		                    RETURNNAT_ENUM    returnNatEn,
		                    NUMBER_T          capGainTax,
		                    NUMBER_T          incGainTax,
		                    FLAG_T            taxAccrInterFlg, 
                            ID_T              priceValRuleId, /* REF5358 - CSY - 001219 */
                            ID_T              exchValRuleId,  /* REF5358 - CSY - 001219 */
							FIN_RETURNPARAM_STP returnParamStp,       /* PMSTA08895 - LJE - 091102 */
                            DBA_HIER_HEAD_STP hierHead,
							FLAG_T			  noIncomeFlg)
{
	DBA_DYNFLD_STP   pricePtr=NULL, unitInterPtr=NULL,
			         *chronoTab=NULL,
                     instrPriceArg; /* PMSTA-10049 - LJE - 101006 */
    FUSDATERULE_ENUM fusDateRule; 
	EXCHANGE_T       exch;
	PRICE_T          begPrice, endPrice;
	NUMBER_T         correctFact, accrInterBeg=0.0, 
			 accrInterEnd=0.0, begInc=0.0;  /* PMSTA-12867 - LJE - 111003 */
	ID_T             wrkCurrId=0, instrId;
	FLAG_T           fullCoupFlg;
	int              chronoNbr;
	char             calcAccrInterFlg;
	double           benchRet=0.0, refCurrBenchRet=0.0, 
		             localCurrBenchRet=0.0, incVal=0.0, capVal=0.0;
	FIN_EXCHARG_ST   exchArgSt;			/* REFXZ */
    DATE_T			 fusionSwitchDate;			/* REF10256 - TEB - 040615 */
	FLAG_T           adjPriceFlg=TRUE; /* PMSTA-10070 - LJE - 100929 */
    SMALLINT_T       adjPriceTypeRank;
    GEN_GetApplInfo(ApplAdjustedPriceTypeRank, &adjPriceTypeRank);

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	/* Compute return in instrument currency */
	switch (returnNatEn)
	{
	/* Compute return in instrument currency */
	case ReturnNat_Local :    
		wrkCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);
		break;

	/* Compute return in input currency */
	case ReturnNat_Curr :    
		if (currId == (ID_T)0)	/* PMSTA-17867 - CHU - 140403 */
		{
			/* If no currency provided, choose instrument currency
			   in order to get a valid exchange rate
			*/
			wrkCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);
		}
		else
		{
			wrkCurrId = currId;   
		}
		break;
	}

	if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(benchRet);
	}

    /* PMSTA-10049 - LJE - 101006 - Use instrPriceArg to define the adjusted type rank */
    if ((instrPriceArg = ALLOC_DYNST(InstrPrice_Arg)) == NULLDYNST)
    {
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(benchRet);
    }

    /* set instr price argument structure with value of appl_param */
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_InstrId);
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_CurrId);
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_TpId);
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_ThirdId);
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_TermTpId);
    SET_NULL_ID(instrPriceArg, InstrPrice_Arg_MktThirdId);
    SET_SMALLINT(instrPriceArg, InstrPrice_Arg_AdjTypeRank, 0);
    SET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg, FALSE);
    SET_FLAG(instrPriceArg, InstrPrice_Arg_TpMandatFlg, FALSE);
    SET_FLAG(instrPriceArg, InstrPrice_Arg_ThirdMandatFlg, FALSE);
    SET_FLAG(instrPriceArg, InstrPrice_Arg_MktMandatFlg, FALSE);
    SET_FLAG(instrPriceArg, InstrPrice_Arg_TermMandatFlg, FALSE);

	/*** Begin price ***/
	if (FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr, begDate, 
			   instrPriceArg,  /* PMSTA-10049 - LJE - 101006 */
               priceValRuleId, /* REF5358 - CSY - 001219 */
               NULL, NULLDYNST, 
			   NULLDYNST, hierHead, pricePtr, FALSE) == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	{
		/* PMSTA08895 - LJE - 091102 */
		if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Rate)
		{
			int  fullPeriodNbr=360;
			long periodNbr=1;

			if (returnParamStp != NULL &&
				returnParamStp->pspBenchDateStp != NULL &&
				returnParamStp->pspBenchDateStp->freqUnit == FreqUnit_Day)
			{
				fullPeriodNbr = 365;
			}
			else
			{
				DATE_DaysBetween(begDate.date, endDate.date, AccrRule_30_360_FebAdj, &periodNbr, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
			}


			benchRet = (pow(1+GET_PRICE(pricePtr, A_InstrPrice_Price), periodNbr/(double)fullPeriodNbr) - 1);

			FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
			FREE_DYNST(pricePtr, A_InstrPrice);
			return (benchRet);
		}

	    /* Change price in working currency */
	    if (GET_ID(pricePtr, A_InstrPrice_CurrId) != wrkCurrId
            && wrkCurrId != 0) /* REF5358 - CSY - 010212: add test id != 0 to avoid message in log */
	    {
		    FIN_GetExchRate(begDate, GET_ID(pricePtr, A_InstrPrice_CurrId),
		                    wrkCurrId, 
                            exchValRuleId,  /* REF5358 - CSY - 001219 */
                            NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
	    }
	    else
		    exch = 1.0;

	    begPrice = GET_PRICE(pricePtr, A_InstrPrice_Price) * exch;

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
		    instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
		    instrId = GET_ID(instrPtr, A_Instr_Id);

        /* PMSTA-10049 - LJE - 100929 - Get the type of the price */
        if (IS_NULLFLD(pricePtr, A_InstrPrice_TpId) == FALSE)
        {
            if (adjPriceTypeRank != NO_VALUE)
            {
                DBA_DYNFLD_STP   sTypeStp, aTypeStp;
	            if ((sTypeStp = ALLOC_DYNST(S_Tp)) == NULLDYNST)
				{
				    FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
					FREE_DYNST(pricePtr, A_InstrPrice);
		            return(benchRet);
				}

                SET_ID(sTypeStp, S_Tp_Id, GET_ID(pricePtr, A_InstrPrice_TpId));

	            if ((aTypeStp = ALLOC_DYNST(A_Tp)) == NULLDYNST)
	            {
		            FREE_DYNST(sTypeStp, S_Tp);
					FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
					FREE_DYNST(pricePtr, A_InstrPrice);
		            return(benchRet);
	            }

	            if (DBA_Get2(Tp, UNUSED, S_Tp, sTypeStp, A_Tp, &aTypeStp, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	            {
	                FREE_DYNST(sTypeStp, S_Tp);
	                FREE_DYNST(aTypeStp, A_Tp);
					FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
					FREE_DYNST(pricePtr, A_InstrPrice);
	                return(benchRet);
	            }

                if (GET_SMALLINT(aTypeStp, A_Tp_Rank) == adjPriceTypeRank)
                {
                    adjPriceFlg = FALSE;
                }

                FREE_DYNST(sTypeStp, S_Tp);
                FREE_DYNST(aTypeStp, A_Tp);
            }
        }

        if (adjPriceFlg == TRUE)
        {
            DATETIME_T tmpBegDate; 
		    /* PMSTA08120 - LJE - 090408 : Add one day to avoid the price conversion factor at the beginning */
		    tmpBegDate.date = DATE_Move(begDate.date, 1, Day);
		    tmpBegDate.time = 0;

	        if ((DBA_SelectInstrChrono(instrId, tmpBegDate, endDate, ChronoNat_PriceConvFactor, (ID_T)0, /* REF10598 - LJE - 041011 */
				                       hierHead, &chronoTab, &chronoNbr)) == RET_SUCCEED) /* PMSTA-10748 - LJE - 110210 */

	        {
		        correctFact = 1.0;
		        for (int i=0; i<chronoNbr; i++)
		        {
				    /* 
				    ** TGU-REF11704-060414-Use GET_LONGAMOUNT since data type for field 
				    ** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT. 
				    */
		            correctFact *= GET_LONGAMOUNT(chronoTab[i],A_InstrChrono_Val);
		        }

				DBA_FreeDynStTab(chronoTab, chronoNbr, A_InstrChrono);		

			    /* REF11306 - RAK - 050714 - Avoid a divided by 0 */
			    if (CMP_NUMBER(correctFact, 0.0) != 0)
			{
				    begPrice /= correctFact;
			    }
			}
        }
	}
	else
	    begPrice = 0.0;

	/* REF11306 - RAK - 050714 - Better to do test with CMP_NUMBER than begPrice == 0.0 !!! */
	if (CMP_NUMBER(begPrice, 0.0) == 0)
	{
		FREE_DYNST(pricePtr, A_InstrPrice);
	    FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
		return(benchRet);
	}

	/* Compute return in input or instrument currency */
	if (returnNatEn == ReturnNat_Local || returnNatEn == ReturnNat_Curr)
	{
	    /* Capital or total return */
	    if (returnTpEn == ReturnTp_Total || returnTpEn == ReturnTp_Capital)
	    {
		    /*** End price ***/
		    if (FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr, endDate, 
				   instrPriceArg,  /* PMSTA-10049 - LJE - 101006 */
                   priceValRuleId,  /* REF5358 - CSY - 001219 */
                   NULL, NULLDYNST, 
				   NULLDYNST, hierHead, pricePtr, FALSE) == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
		    {
		        /* Change price in working currency */
		        if (GET_ID(pricePtr, A_InstrPrice_CurrId) !=  wrkCurrId)
	 	        {
		    	    FIN_GetExchRate(endDate, GET_ID(pricePtr, A_InstrPrice_CurrId), wrkCurrId, 
			            exchValRuleId,  /* REF5358 - CSY - 001219 */  
                        NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
		        }
		        else
		            exch = 1.0;

 		        endPrice = GET_PRICE(pricePtr, A_InstrPrice_Price) * exch;
		    }
		    else
		        endPrice = 0.0;

		    if ((endPrice-begPrice) > 0.0)
	     	    capVal = (endPrice-begPrice) * (1-capGainTax/100.0);
		    else
		        capVal = (endPrice-begPrice);
	    }
	    else 
		    capVal = 0.0;

		/* REF10256 - TEB - 040615 - Begin */
		/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
			fusionSwitchDate == MAGIC_END_DATE )
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);		/* REF1149 */
		}
		else
		{
			if (DATE_Cmp(begDate.date, fusionSwitchDate) < 0)
			{
				GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
			}
			else
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
		}
		/* REF10256 - TEB - 040615 - End */

		/* PMSTA-11143 - RAK - 101220 */
		/* Move AI computation after income to be abble to test */
		/* the income event and not compute AI on income date */
		/* Use new subfunction for income computation */
		incVal = 0.0;
        std::set<DATE_T> incDateSet; // PMSTA-47762 - JBC - 220131 this is yyyymmdd as string it so it is sorted automatically

		if (noIncomeFlg == FALSE)	/* is FALSE if we already know that there isn't income (monthly without income)  */
		{
			INVESTTIMINGRULE_ENUM       retInvesttimingRuleEn = InvestTimingRule_Beginning;
			GEN_GetApplInfo(ApplRetInvestTimingRule,  &retInvesttimingRuleEn);

			/* PMSTA-12867 - LJE - 111003 - Add on day to retrieve income event.*/
			DATETIME_T tmpDate;
			tmpDate.date = DATE_Move(begDate.date, 1, Day);
			tmpDate.time = 0;
            
			FIN_InstrBenchReturnIncome(instrPtr, endDate, tmpDate, wrkCurrId, returnTpEn, incGainTax, exchValRuleId, hierHead, &incVal,
									   TRUE, incDateSet);	

			/* PMSTA12867 - LJE - 111003 - According the ret invest timing rule, 
									       use the income to compute the return (reduce the begin price) */
			if (retInvesttimingRuleEn == InvestTimingRule_Beginning)
			{
				begInc = incVal;
			}

			/* if (income == begDate) -> no income  */
			/* but keep incDate to avoid AI computation on that date */
			/* NB I think this code is due to a wrong computation on ""*�%+&" instrument with "%*?? income definition */
			/* perhaps better to correct the wrong instrument or the wrong AI/income computation but no time */
			/* PMSTA09843 - LJE - 111003 - definitely useless
			for (i=0; i<incDateNbr; i++)
				if (DATETIME_CMP(begDate, incDateTab[i]) == 0)
					incVal = 0.0;
		     */
		}

		/* PMSTA-10527 - RAK - 101021 */
		/* Compute AI as fullCoupFlg to avoid AI computation the day of coupon payment (begin or end date AI) */
		/* GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg); */
		fullCoupFlg = FALSE;

		if (fusDateRule == FusDateRule_None)	
			calcAccrInterFlg = FALSE;
		else
			calcAccrInterFlg = TRUE;

		if ((unitInterPtr = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			FREE_DYNST(pricePtr, A_InstrPrice);
		    FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			return(benchRet);
		}

		/*** accrued interest at begin date */
		accrInterBeg = 0.0;

		/* PMSTA11143 - RAK - 101220 - verify income dates */
		/* NB I think this code is due to a wrong computation on ""*�%+&" instrument with "%*?? income definition */
		/* perhaps better to correct the wrong instrument or the wrong AI/income computation but no time */	
		bool payedInc = incDateSet.count(begDate.date) > 0;

		if (payedInc == false)
		{
			/* DVP125 - RAK - 960620 */
			/* REF7265 - YST - 020320 - add two new arguments */
			if (FIN_UnitAccrInter(begDate, GET_ID(instrPtr, A_Instr_Id), instrPtr, 
					  fusDateRule, fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, begDate,
					  AccrRule_None, /* REF11218 - TEB - 050627 */
					  NULLDYNST, unitInterPtr, hierHead, FALSE, NULL) == RET_SUCCEED) /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/
			{
				if (GET_ID(unitInterPtr, UnitInter_CurrId) != wrkCurrId)
	 			{
		    		FIN_GetExchRate(begDate, GET_ID(unitInterPtr, UnitInter_CurrId), wrkCurrId, 
						exchValRuleId, /* REF5358 - CSY - 001219 */
						NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
				}
				else
					exch = 1.0;

 				accrInterBeg = GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter) * exch;
			}
		}

		/*** accrued interest at end date */
		accrInterEnd = 0.0;
		
		/* PMSTA11143 - RAK - 101220 - verify income dates */
		/* NB I think this code is due to a wrong computation on ""*�%+&" instrument with "%*?? income definition */
		/* perhaps better to correct the wrong instrument or the wrong AI/income computation but no time */		
		payedInc = incDateSet.count(endDate.date) > 0;
	    
		if (payedInc == false && returnTpEn == ReturnTp_Total || returnTpEn == ReturnTp_Capital)
	    {
			/* REF10256 - TEB - 040615 - Begin*/
			/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
			if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
				fusionSwitchDate == MAGIC_END_DATE )
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);		/* REF1149 */
			}
			else
			{
				if (DATE_Cmp(endDate.date, fusionSwitchDate) < 0)
				{
					GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
				}
				else
				{
					GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
				}
			}

			/*
			 * Also redetermine calcAccrInterFlg, because fusDateRule may 
			 * have changed between begin and end date
			 */
			if (fusDateRule == FusDateRule_None)	
				calcAccrInterFlg = FALSE;
			else
				calcAccrInterFlg = TRUE;
			/* REF10256 - TEB - 040615 - End */

			/* DVP125 - RAK - 960620 */
			/* REF7265 - YST - 020320 - add two new arguments */
			if (FIN_UnitAccrInter(endDate, GET_ID(instrPtr, A_Instr_Id), instrPtr, 
						  fusDateRule, fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, endDate,
						  AccrRule_None, /* REF11218 - TEB - 050627 */
						  NULLDYNST, unitInterPtr, hierHead, FALSE, NULL) == RET_SUCCEED) /* PMSTA08308 - 090609 - PMO / PMSTA5389-CHU-080131*/
			{
				if (GET_ID(unitInterPtr, UnitInter_CurrId) != wrkCurrId)
	 			{
		    		FIN_GetExchRate(endDate, GET_ID(unitInterPtr, UnitInter_CurrId), wrkCurrId, 
						exchValRuleId,  /* REF5358 - CSY - 001219 */
						NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
				}
				else
					exch = 1.0;

 				accrInterEnd = GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter) * exch;
			}

		}

		/* PMSTA11143 - RAK - 101220 */
		/* printf("\n\nbegin date : %s ", DATE_DateConv(begDate.date));
		printf("end date : %s ", DATE_DateConv(endDate.date));
		printf("\nbegprice : %2.8f : endprice : %2.8f" begPrice, endPrice); 
		printf("\nbegAi    : %2.8f : endAi    : %2.8f : income : %2.8f", accrInterBeg, accrInterEnd, incVal);
		*/

		/* REF4180 - LJE - 020704 : Modify computing */
	    switch (returnTpEn)
	    {
	    /* Return including all factors (capital, income, currency) */
	    case ReturnTp_Total:
			if (accrInterEnd - accrInterBeg > 0.0)
				incVal += ((accrInterEnd - accrInterBeg) * (1-incGainTax/100));
			else
				incVal += (accrInterEnd - accrInterBeg);
		break;

	    /* Return due to appreciation in working currency */
	    case ReturnTp_Capital:
			if (accrInterEnd - accrInterBeg > 0.0)
				incVal = ((accrInterEnd - accrInterBeg) * (1-incGainTax/100));
			else
				incVal = (accrInterEnd - accrInterBeg);
		break;

	    /* Return due to any income being received */
	    case ReturnTp_Income:
			capVal = 0.0;
		break;
	    }

		benchRet = (capVal + incVal) / (fabs(begPrice-begInc+accrInterBeg)); /* REF4180 - LJE - 020701 */
		/* PMSTA11143 - RAK - 101209 */
		/* printf("\nbenchRet : %2.8f ", benchRet); */

        FREE_DYNST(unitInterPtr, UnitInter); /* REF11269 - LJE - 051221 : Memory leek */
	}
	/* Difference between local return and currency return */
	else
	{
	    if (currId != GET_ID(instrPtr, A_Instr_RefCurrId))
	    {
		    /* Compute return in input currency */
		    refCurrBenchRet = FIN_InstrBenchReturnPeriod(instrPtr, endDate, begDate, currId, 
				                               returnTpEn, ReturnNat_Curr, 
						                       capGainTax, incGainTax, taxAccrInterFlg, 
                                               priceValRuleId, exchValRuleId, /* REF5358 - CSY - 001219 */
											   returnParamStp,  /* PMSTA08895 - LJE - 091102 */
                                               hierHead, noIncomeFlg);

		    /* Compute return in instrument currency */
		    localCurrBenchRet = FIN_InstrBenchReturnPeriod(instrPtr, endDate, begDate, currId, 
					                             returnTpEn, ReturnNat_Local, 
							                     capGainTax, incGainTax, taxAccrInterFlg, 
                                                 priceValRuleId, exchValRuleId, /* REF5358 - CSY - 001219 */
												 returnParamStp,  /* PMSTA08895 - LJE - 091102 */
                                                 hierHead, noIncomeFlg);

		    benchRet = refCurrBenchRet - localCurrBenchRet;
	    }
	    else
		    benchRet = 0.0;    /* No difference */
	}

    FREE_DYNST(instrPriceArg, InstrPrice_Arg); /* PMSTA-10049 - LJE - 101006 */
	FREE_DYNST(pricePtr, A_InstrPrice);
	return(benchRet);
}

/************************************************************************
**
**  Function    :   FIN_CompositeBenchReturn()
**
**  Description :   Calculate the return of received composite benchmark
**                  between two dates, using weight infos
**                  (benchmark can be modelled in T'A 
**                      - either as an instrument (with instr_compo) 
**                      - either as a strategy (asset allocation or model portfolio)
**                 
**  Arguments   :   objId: either an instrument id, 
**                         either a strategy history id
**                  
**                  objectEn:       object enum corresponding to objId (Instr or Strat)
**                  endDate:        return is computed between begDate and endDate       
**                  begDate
**                  currId:         currencyId
**                  returnTpEn
**                  returnNatEn
**                  capGainTax
**                  incGainTax
**                  taxAccrInterFlg indicates wheter  the income tax rate 
**                                  applies to any accrued interest (dflt YES)
**                  rebalRule:      rebalancing rule (argument of keyword BENCH_RETURN)
**                  contribObjectId:    id of a component of a benchmark whose contribution 
**                                      is to be computed
**                  contribRule:        contribution rule
**                  priceValRuleId:     price valuation rule id
**                  exchValRuleId:      exchange valuation rule id
**                  hierHead:           pointer on hierarchy
**
**  Return      :   RET_SUCCEED (value of the computed return is in currentWeight->periodReturn)
**
**  Creation.	:   REF5358 - CSY - 010118
**  Modif:          REF6025 - CSY - 010601 splitting period with irregulars in sub-strat
**                  REF7422 - CSY - 020605 benchAnaFlg
**
*************************************************************************/
STATIC RET_CODE FIN_CompositeBenchReturn(FIN_WEIGHT_STP		    currentWeight,   /* description (id, childs, weights...) of the benchmark we want to compute the return */
                                         OBJECT_ENUM			objectEn,
		                                 DATETIME_T			    endDate,
		                                 DATETIME_T				begDate,
                                         FIN_RETURNPARAM_STP	returnParamStp,
                                         IDXTIMERULE_ENUM		rebalRule,
                                         ID_T					contribObjectId,
                                         CONTRIBRULE_ENUM	    contribRule,
                                         ID_T				    priceValRuleId,
                                         ID_T					exchValRuleId,
                                         FIN_BENCHRETPARAM_STP  benchRetParamStp,
                                         FLAG_T				    stopLoop, /* REF6025 - CSY - 010611 */
                                         FLAG_T					anaBenchFlg,
                                         FLAG_T				    *foundContribFlg,
										 DBA_DYNFLD_STP			ESLPtr,		/* REF10274 - RAK - 040506 */
                                         DBA_HIER_HEAD_STP		hierHead)
{
    FIN_WEIGHTHEAD_ST  weightHead;  /* REF6025 - CSY - 010601 */
    RET_CODE    ret = RET_SUCCEED;
    FLAG_T  sumFlg = FALSE;
    FLAG_T  fcFlg = FALSE;  /* REF6025 - CSY - 010619 : fc = found contribution */
    int i = 0, j=0;
    ID_T    compoId = 0;
    ID_T    currId = returnParamStp->currId; /* REF6025 - CSY - 010614 */
    
    currentWeight->periodReturn = 0.0;

    if (currentWeight->childNbr == 0)
    {
        /* REF6025 - CSY - 010716: compute FIN_InstrBenchReturn only for instr, never for strat */
        if (currentWeight->objectEnum != Instr)
            return (ret);

		/* REF10822 - RAK - 041215 - Now instrument could be NULL */
		if (currentWeight->objectPtr == NULLDYNST)
		{
			currentWeight->periodReturn = 0;
		}
		else
		{
			/* input currency not given, use instrument currency */
			if (currId == -1)
		        currId = GET_ID(currentWeight->objectPtr, A_Instr_RefCurrId);

			currentWeight->periodReturn = FIN_InstrBenchReturn(currentWeight->objectPtr,
												           endDate,
														   begDate,
														   currId,
														   returnParamStp->returnTpEn,
														   returnParamStp->returnNatEn,
														   returnParamStp->capGainTax,
														   returnParamStp->incGainTax,
														   returnParamStp->taxAccrInterFlg, 
														   priceValRuleId, /* REF5358 - CSY - 001219 */
														   exchValRuleId,  /* REF5358 - CSY - 001219 */
														   returnParamStp,  /* PMSTA08895 - LJE - 091102 */
														   hierHead);
		}
    } 
    else
    {
        /* REF6025 - CSY - 010625: if rebal_rule asks for irregulars, it must be managed
        for sub-strategies (a sub-strategy has a parent and children) */
        if ((rebalRule == IdxTimeRule_Irregular || 
            rebalRule == IdxTimeRule_InitialWeightIrregular) 
                        && /* splitting irregular only for sub-strat */
            (currentWeight->parentWeightPtr !=  (FIN_WEIGHT_STP) NULL)
                        && stopLoop == FALSE)
        {
            DATETIME_T     *crystalDates= nullptr;
            DBA_DYNFLD_STP  domainArg = NULLDYNST;
            DBA_DYNFLD_STP     objectHistPtr = NULLDYNST;
            DBA_DYNFLD_STP  *selInstrCompoTab = (DBA_DYNFLD_STP*)NULL,    /* REF5358 - CSY - 001115 */
            *selStratHistTab = NULLDYNSTPTR, *eltTab = NULLDYNSTPTR;
            double subBenchRet = 1.0;
            int crystalNbr = 2, k=0;
            int             selInstrCompoNbr = 0, eltNbr = 0;
            int             selStratHistNbr = 0;
            FLAG_T          foundFlg = FALSE;
            ID_T    objectId = 0;

            stopLoop = TRUE;    /* REF6025 - CSY - 010611: avoid infinite recursivity */

            crystalDates = (DATETIME_T*) CALLOC(crystalNbr, sizeof(DATETIME_T)); 

	        if (crystalDates == nullptr)
	        {
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

            crystalDates[0] = begDate;
            crystalDates[1] = endDate;
            
            memset(&weightHead, '\0', sizeof(FIN_WEIGHTHEAD_ST));

            /* select the sub-strategy elements valid between begDate and endDate */
            
            /* input structure for select */
            if ((domainArg = ALLOC_DYNST(A_Domain)) == NULLDYNST)
            {
				FREE(crystalDates); /* REF7475 - LJE - 020701 */
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Domain");
                return(RET_MEM_ERR_ALLOC);
            }

            if (benchRetParamStp->adjWeightFlg == FALSE)
            {
                /* for a call through script BENCH_RETURN, select elements of sub-benchmark over all the 
                BENCH_RETURN period: date1-date2 */
                SET_DATETIME(domainArg, A_Domain_InterpFromDate, benchRetParamStp->date1);  
                SET_DATETIME(domainArg, A_Domain_InterpTillDate, benchRetParamStp->date2);
            }
            else
            {
                SET_DATETIME(domainArg, A_Domain_InterpFromDate, begDate);  
                SET_DATETIME(domainArg, A_Domain_InterpTillDate, endDate);
            }

            if (currentWeight->objectEnum == Instr)
            {
				DBA_DYNFLD_STP  getArg = NULLDYNST;
				if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)  /* PMSTA-25331 - TEB - 20171018 */
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");  /* PMSTA-25331 - TEB - 20171018 */
					FREE(crystalDates);
					FREE_DYNST(domainArg, A_Domain);
					return(RET_MEM_ERR_ALLOC);
				}

				/* set input structure for select  */ /* PMSTA-25331 - TEB - 20171018 */
				SET_DATE(getArg, Get_Arg_Date,      GET_DATE(domainArg, A_Domain_InterpFromDate) );
				SET_DATE(getArg, Get_Arg_ShortDate, GET_DATE(domainArg, A_Domain_InterpTillDate));

                /* set input structure for select  */
				SET_ID(getArg, Get_Arg_ObjId, currentWeight->objectId); /* id of the benchmark */ /* PMSTA-25331 - TEB - 20171018 */

                /* select all the valid instr_compos between domain begDate and endDate dates */
				if ((ret = DBA_Select2(InstrCompo, UNUSED, Get_Arg, getArg,
			                  A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
			                  &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
                {
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
                    FREE(selInstrCompoTab); 
                    FREE_DYNST(domainArg, A_Domain);
					FREE_DYNST(getArg, Get_Arg);
                    return(RET_SUCCEED);
                }

				FREE_DYNST(getArg, Get_Arg);

                /* build the crystalDates between begDate and endDate, with irregulars instr_compo */
                if ((ret = FIN_MergeIrregDates(begDate, &crystalDates, &crystalNbr, (TLS_CMPFCT *)FIN_CmpInstrCompoByAscBegDate,  /* REF7264 - LJE - 020131 */
					A_InstrCompo_BeginDate, selInstrCompoTab, selInstrCompoNbr)) != RET_SUCCEED)
                {
                   FREE(selInstrCompoTab); 
                   FREE_DYNST(domainArg, A_Domain);
                   return(RET_SUCCEED);
                }

                /* sort the instr_compo by desc. begin date */
                TLS_Sort((char*) selInstrCompoTab, selInstrCompoNbr, sizeof(DBA_DYNFLD_STP), 
	                         (TLS_CMPFCT *)FIN_CmpInstrCompo, (PTR**)NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */
            }
            else if (currentWeight->objectEnum == Strat)
            {
                /*SET_ID(domainArg, A_Domain_StratObjId, currentWeight->objectId); */
                SET_ID(domainArg, A_Domain_StratObjId, 
                    GET_ID(currentWeight->objectPtr, A_Strat_Id));
        
                /* select all the strategy historys between domain from and till dates */
		        if ((ret = DBA_Select2(StratHist, UNUSED, A_Domain, domainArg,
			                  A_StratHist, &selStratHistTab, UNUSED, UNUSED, 
			                  &selStratHistNbr, UNUSED, UNUSED))!=RET_SUCCEED)
                {
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
                    FREE_DYNST(domainArg, A_Domain);
                    DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);/*FREE(selStratHistTab);*//* REF8712 - YST - 030807 */
                    return(RET_SUCCEED);
                }

                /* build the crystalDates between begDate and endDate, with irregulars strategy histories */           
                if ((ret = FIN_MergeIrregDates(begDate, &crystalDates, &crystalNbr, (TLS_CMPFCT *)FIN_CmpStratHistByAscBegDate, 
                                        A_StratHist_BegDate, selStratHistTab, selStratHistNbr))!=RET_SUCCEED)
                {
					FREE(crystalDates); /* REF7475 - LJE - 020701 */
                    DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);/*FREE(selStratHistTab); *//* REF8712 - YST - 030807 */
                    FREE_DYNST(domainArg, A_Domain);
                    return(RET_SUCCEED);
                }

                /* sort the strategy histories by desc. begin date */
                TLS_Sort((char*) selStratHistTab, selStratHistNbr, sizeof(DBA_DYNFLD_STP), 
	                         (TLS_CMPFCT *)FIN_CmpStratHistByDescBegDate, (PTR**)NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */
            }
            FREE_DYNST(domainArg, A_Domain);    
            
            /* now, crystal dates array is set and sorted */
            crystalDates = (DATETIME_T*) REALLOC(crystalDates,
						              (crystalNbr+1)*sizeof(DATETIME_T));

            /* loop on the crystalDates */
            for (k=0; k< crystalNbr-1; k++)
            {
                

                if (k == 0)
                {
                    *foundContribFlg = FALSE;
                    if ((ret = FIN_CompositeBenchReturn(currentWeight, 
												        objectEn,
														crystalDates[k+1],
														crystalDates[k],
														returnParamStp,
														rebalRule,
														contribObjectId,
														contribRule,
														priceValRuleId,
														exchValRuleId,
														benchRetParamStp, /* REF6025 - CSY - 010614 */
														stopLoop,      /* REF6025 - CSY - 010611 */
														anaBenchFlg, /* REF7422 - CSY - 020605 */
														foundContribFlg,
														ESLPtr,		/* REF10274 - RAK - 040506 */
														hierHead)) != RET_SUCCEED)
                    {
						FREE(crystalDates); /* REF7475 - LJE - 020701 */
						DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);/* REF8712 - YST - 030807 */
                        return(ret);
                    }

                    /* chain the return for each period */
                    subBenchRet = subBenchRet * (1 + (currentWeight->periodReturn));
                }
                else
                {
                    foundFlg = FALSE;
                    /* at each period, find valid instr_compos or valid strategy histories */
                    /* REF8844 - LJE - 030415 */
                    if (currentWeight->objectEnum == Instr)
                    {

                        /* instr_compo are sorted by desc. date */
                        while(j < selInstrCompoNbr &&
                            DATETIME_CMP(GET_DATETIME(
							selInstrCompoTab[j], A_InstrCompo_BeginDate), crystalDates[k]) > 0)
                            j++;

                        if (j < selInstrCompoNbr && DATETIME_CMP(GET_DATETIME(
							selInstrCompoTab[j], A_InstrCompo_BeginDate), crystalDates[k]) <= 0)
                        {
                            foundFlg = TRUE;
                            objectId = currentWeight->objectId;
                            eltNbr = selInstrCompoNbr - j;
                            eltTab = &(selInstrCompoTab[j]);
                        }
                        
                    }
                    else if (currentWeight->objectEnum == Strat)
                    {

                        j = 0;
                        while(j < selStratHistNbr && DATETIME_CMP(GET_DATETIME(
                            selStratHistTab[j], A_StratHist_BegDate), crystalDates[k]) > 0)
                            j++;
                    

                        if (j < selStratHistNbr)
                        {
                            foundFlg = TRUE;
                            objectHistPtr = selStratHistTab[j];
                            objectId = GET_ID(selStratHistTab[j], A_StratHist_Id);
                            eltNbr = 0;
                            eltTab = NULLDYNSTPTR;
                        }

                        
                    }

                    if (foundFlg == TRUE)
                    {
                        if ((ret = FIN_InitWeightHeader(&weightHead, 
                                          currentWeight->objectEnum,
                                          objectId,
                                          currentWeight->objectPtr,   /* ptr on instrument or strategy */
                                          FALSE,
                                          objectHistPtr,
                                          FALSE,
                                          crystalDates[k], 
                                          crystalDates[k+1])) != RET_SUCCEED)
                        {
							FREE(crystalDates); /* REF7475 - LJE - 020701 */
                            return (ret);
                        }

                        if ((ret = FIN_ComputeWeight(objectId,
													(weightHead.firstWeight)->objectPtr, 
													(weightHead.firstWeight)->objectHistPtr,
													(weightHead.firstWeight)->objectEnum,
													crystalDates[k], 
													returnParamStp,
													rebalRule,
													contribObjectId,
													contribRule,
													priceValRuleId,
													exchValRuleId,
													hierHead,
													weightHead.firstWeight,
													eltTab,
													eltNbr,
                                                    FALSE, /* SUPPORT-6697 - LJE - 160609 */
													FALSE,  /* REF6025 - CSY - 010606 checkStratFlg */
													anaBenchFlg,    /* REF7422 - CSY - 020605 */
													NULL,  /* REF6025 - CSY - 010607 stratIdTabPtr */
													NULL,  /* REF6025 - CSY - 010607 stratIdNbrPtr */
													ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                        {
							FREE(crystalDates); /* REF7475 - LJE - 020701 */
                            return (ret);
                        }

                        *foundContribFlg = FALSE;
                        if ((ret = FIN_CompositeBenchReturn(weightHead.firstWeight, 
														    currentWeight->objectEnum,
															crystalDates[k+1],
															crystalDates[k],
															returnParamStp,
															rebalRule,
															contribObjectId,
															contribRule,
															priceValRuleId,
															exchValRuleId,
															benchRetParamStp, /* REF6025 - CSY - 010614 */
															stopLoop,      /* REF6025 - CSY - 010611 */
															anaBenchFlg, /* REF7422 - CSY - 020605 */
															foundContribFlg,
															ESLPtr,		/* REF10274 - RAK - 040506 */
															hierHead)) != RET_SUCCEED)
                        {
							FREE(crystalDates); /* REF7475 - LJE - 020701 */
                            return(ret);
                        } 
                    
                        /* chain the return for each period */
                        subBenchRet = subBenchRet * (1 + (weightHead.firstWeight)->periodReturn);
                    
                        /* free weight of the sub-strategy for the current period */
                        if ((ret = FIN_FreeWeightTab(&weightHead)) != RET_SUCCEED)
                        {
							FREE(crystalDates); /* REF7475 - LJE - 020701 */
                            return (ret);
                        }
                    }
                }    
            }

            FREE(crystalDates);     /* REF6025 - CSY - 010720: purify */
            if (currentWeight->objectEnum == Strat)
                DBA_FreeDynStTab(selStratHistTab, selStratHistNbr, A_StratHist);/*FREE(selStratHistTab);*/  /* REF8712 - YST - 030807 */
            

            /* set periodReturn */
            currentWeight->periodReturn = subBenchRet -1;

        }
        else    /* REF6025 - CSY - 010611 */
        {
            if (contribObjectId != 0  && 
                currentWeight->parentWeightPtr != NULL)
            {
                for (j=0; j < currentWeight->parentWeightPtr->childNbr; j++)
                {
					/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
					/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                    if (currentWeight->parentWeightPtr->objectEnum == Strat &&
                        currentWeight->objectId == currentWeight->parentWeightPtr->childWeightTab[j]->objectId)
                    {
                        if (contribObjectId == GET_ID(currentWeight->parentWeightPtr->eltTab[j], A_StratElt_MktSegtId))
                            sumFlg = TRUE;
                    }
                }
            }

            currentWeight->periodReturn = 0.0;
            for (i = 0; i < currentWeight->childNbr; i++)
            {
                fcFlg = FALSE;
				/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
				/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                if ((ret = FIN_CompositeBenchReturn((currentWeight->childWeightTab[i]), 
													(currentWeight->childWeightTab[i])->objectEnum,
													  endDate,
													  begDate,
													  returnParamStp,
													  rebalRule,
													  contribObjectId,
													  contribRule,
													  priceValRuleId,
													  exchValRuleId, 
													  benchRetParamStp, /* REF6025 - CSY - 010614 */
													  FALSE,         /* REF6025 - CSY - 010611 */
													  anaBenchFlg, /* REF7422 - CSY - 020605 */
													  &fcFlg,
													  ESLPtr,		/* REF10274 - RAK - 040506 */
													  hierHead)) != RET_SUCCEED)
                {
                    return(ret);
                }
            
                if (contribObjectId != 0)
                {
                    if (objectEn == Instr)
                    {
						/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
						/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                        compoId = (currentWeight->childWeightTab[i])->objectId;
                    }
                    else if (objectEn == Strat)
                    {
                            if (GET_ENUM(currentWeight->objectPtr, A_Strat_NatEn) == (STRATNAT_ENUM)StratNat_ModelPtf &&
                                IS_NULLFLD(currentWeight->eltTab[i], A_StratElt_MktSegtId))
                                compoId = GET_ID(currentWeight->eltTab[i], A_StratElt_InstrId);
                            else /* StratNat_Alloc or StratNat_ModelPtf with A_StratElt_MktSegtId not null */
                                compoId = GET_ID(currentWeight->eltTab[i], A_StratElt_MktSegtId);
                    }
                }

                if (contribObjectId == compoId || 
                    (currentWeight->objectEnum == Instr && contribObjectId == currentWeight->objectId) /* we must be able to compute the contrib of an index benchmark */
                            || sumFlg == TRUE 
                            || 
                     (fcFlg == TRUE)   /* REF6025 - CSY - 010619: to tell 
                     to the parent that the contrib has been found...l'avenir nous dira si �a marche */
                            ||
					/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
					/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                     ((currentWeight->childWeightTab[i])->childNbr > 0)  /* if we want to compute the contrib of a benchmark */
                            ||
                     ((currentWeight->objectEnum == Strat && contribObjectId == GET_ID(currentWeight->objectPtr, A_Strat_Id)) 
                     || (currentWeight->objectEnum == Instr && contribObjectId == GET_ID(currentWeight->objectPtr, A_Instr_Id)))
                     ) 

                {   /* return of currentWeight on the period begDate-endDate = 
                    sum of the contributions (wi*Ri) of each child on the period */

					/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
					/* so childWeightTab[]. is transformed in childWeightTab[]-> */
                    currentWeight->periodReturn += ((currentWeight->childWeightTab[i])->periodReturn)*
                                    ((currentWeight->childWeightTab[i])->weightValue);

                    
                    /* REF7422 - CSY - 020405 set the contrib value in A_StratElt_Return:
                    check the objectEnum (don't do it for A_InstrCompo field !) */
                    if(currentWeight->objectEnum == Strat)/* REF7422 CSY 020726 */ 
                    {
                        if (returnParamStp->returnCurrEffectFlg)  /* REF9227 - LJE - 030919 */
                        {
						    SET_NUMBER(currentWeight->eltTab[i], A_StratElt_ReturnCurr, 
							    ((currentWeight->childWeightTab[i])->periodReturn)*
                                ((currentWeight->childWeightTab[i])->weightValue));

						    SET_NUMBER(currentWeight->eltTab[i], A_StratElt_AbsoluteReturnCurr, 
						               (currentWeight->childWeightTab[i])->periodReturn);

                        }
                        else
                        {
						    /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
						    /* so childWeightTab[]. is transformed in childWeightTab[]-> */
						    SET_NUMBER(currentWeight->eltTab[i], A_StratElt_Return, 
							    ((currentWeight->childWeightTab[i])->periodReturn)*
                                ((currentWeight->childWeightTab[i])->weightValue));

						    SET_NUMBER(currentWeight->eltTab[i], A_StratElt_AbsoluteReturn, 
						               (currentWeight->childWeightTab[i])->periodReturn);/* REF8555 MCA 020108 */
                        }
                    }
                    *foundContribFlg = TRUE;
                }
            }
        }   /* REF6025 - CSY - 010611 */
    }
    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_SetStratEltReturn()
**
**  Description :   compute the return of a strategy between two dates, with
**                  initial weights, according to the rebalancing rule
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_InstrCompo
**                  ptr2   pointer on dynamic structure type A_InstrCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF7422 - CSY - 020405
**  Modification:   REF7422 - YST - 020809
**
*************************************************************************/
RET_CODE    FIN_SetStratEltReturn(DBA_HIER_HEAD_STP hierHead, 
                                  DBA_DYNFLD_STP    domainPtr,
                                  DBA_DYNFLD_STP    stratPtr, 
								  DBA_DYNFLD_STP    ESLPtr, 
                                  DATETIME_T        date1, 
                                  DATETIME_T        date2, 
								  DATETIME_T        rebalDate,
                                  IDXTIMERULE_ENUM  rebalRule,
								  FLAG_T            anaBenchFlg,
                                  FLAG_T            currEffectRetFlg,
								  BENCH_OBJ_DATE_STP pspBenchDateStp, /* PMSTA08895 - LJE - 091102 */
								  double			*rtnValue)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP 	    *stratEltTab=NULLDYNSTPTR;
    FIN_RETURNPARAM_ST  returnParam;                
    RETURNTP_ENUM       returnTp=ReturnTp_Total;
	RETURNNAT_ENUM      returnNat=ReturnNat_Curr;   
	PORTPLCOMPRULE_ENUM PLCompRule=PortPlCompRule_Dflt;
    OBJECT_ENUM         objectEnum=ApplParam;
    FLAG_T              foundAdjWFlg = FALSE;
    ID_T*               stratIdTab = NULL;
    int                 stratIdNbr = 0, j=0, stratEltNbr=0, k=0;
    double              returnValue =0.0,adjWeight = 0.0;
    ID_T                currId = GET_ID(domainPtr, A_Domain_CurrId);/* use domain currency */
    int                 returnFieldIdx;
	SCPT_CLASSIFSTACK_STP   classifStack=(SCPT_CLASSIFSTACK_STP)NULL;

    returnFieldIdx = (currEffectRetFlg?A_StratElt_AbsoluteReturnCurr:A_StratElt_AbsoluteReturn); /* REF9227 - LJE - 030919 */

    /* REF9227 - LJE - 030919 */
    if (currEffectRetFlg)
    {
        returnNat=ReturnNat_CurrEffect;
    }

    memset(&returnParam, '\0', sizeof(FIN_RETURNPARAM_ST));
          
	/* < REF11457 - CHU - 051019 */
	if (IS_NULLFLD(domainPtr, A_Domain_CurrId) == FALSE)
	{
		currId = GET_ID(domainPtr, A_Domain_CurrId);/* use domain currency */
	}
	else if (IS_NULLFLD(stratPtr, A_Strat_CurrId) == FALSE)
	{
		currId = GET_ID(stratPtr, A_Strat_CurrId); /* use strategy currency */
	}
	/* > REF11457 - CHU - 051019 */
          
    if ((ret = FIN_InitReturnParam(currId, (RETURNTP_ENUM)returnTp, (RETURNNAT_ENUM)returnNat, 
        0.0 /* capTaxRate */ , 0.0 /* incTaxRate */, FALSE /* incTaxFlg */, PLCompRule, &returnParam)) != RET_SUCCEED)
    {
        return(RET_SUCCEED);
    }

    returnParam.returnCurrEffectFlg = currEffectRetFlg; /* REF9227 - LJE - 030919 */
 	returnParam.pspBenchDateStp = pspBenchDateStp;      /* PMSTA08895 - LJE - 091102 */

    /* compute price adjusted weights (set of A_StratElt_Value with adjusted weights
    is done in FIN_ComputeNewInitWeight) */
    if ((ret = FIN_BenchReturn(GET_ID(stratPtr, A_Strat_Id), 
						       stratPtr,
	                           Strat,
	                           date2, 
                               date1,
	                           &returnParam,
                               rebalRule,
                               10,      
                               FreqUnit_Year,  
                               rebalDate,
                               0,   /* contribObjectId */ 
                               ContribRule_None,
                               GET_ID(stratPtr, A_Strat_QuoteValRuleId) /* priceValRuleId */,  /* PMSTA-10070 - LJE - 101004 */
                               0 /* exchValRuleId */, 
                               TRUE,   /* checkStratFlg */
                               (FLAG_T)(currEffectRetFlg?FALSE:GET_FLAG(domainPtr, A_Domain_DynWeightFlg)), /* adjWeightFlg */
                               TRUE,     /* benchStorageFlg */
                               anaBenchFlg,    /* REF7422 - MCA - 020718:  */
                               &adjWeight,
                               &foundAdjWFlg,
                               &returnValue,
                               &stratIdTab,  /* REF6025 - CSY - 010607 */
                               &stratIdNbr,  /* REF6025 - CSY - 010607 */
							   ESLPtr,		 /* REF10274 - RAK - 040506 */
                               hierHead)) != RET_SUCCEED)
    {
        FREE(stratIdTab);
        return (ret);
    } 

	*rtnValue = returnValue;

    /* for strategies with list of grids, do the repercussion process from index market segments
    to parent market segments and children market segments */
    if (IS_NULLFLD(stratPtr, A_Strat_DimGridDictId) == FALSE &&
		(STRATNAT_ENUM)GET_ENUM(stratPtr, A_Strat_NatEn) != StratNat_Index) /* PMSTA07963 - LJE - 090602 */
    {
        DBA_GetObjectEnum(GET_DICT(stratPtr, A_Strat_DimGridDictId), &objectEnum);
        if (objectEnum == List
                        || 
            (objectEnum == Grid && IS_NULLFLD(stratPtr, A_Strat_GridObjId) == FALSE
            )    /* REF6025 - CSY - 020307 */
                        
            )
        {
			/* REF9658 - CHU - 040206 */
			/* get the valid strategy histories from all treated strategies */
			/* initial code replaced by this function to be used in
			 * 2 functions : FIN_AdjustWeights() and FIN_SetStratEltReturn()
			 */
			if ((ret = FIN_GetStratEltFromStratIdTab(hierHead, stratPtr,	/* REF10274 - RAK - 040512 */
									stratIdNbr, stratIdTab,
									&stratEltNbr, &stratEltTab)) != RET_SUCCEED)
			{
				FREE(stratEltTab);
				FREE(stratIdTab);
				return(ret);
			}		/*REF9881 MCA 040324 market segment not initialized and return=0 for MP*/
					/* REF9658 - CHU - 040209 : IT SEEMS MKTSEGT IS NOT INITIALIZED !! */
					/* IS THIS REALLY NORMAL ?? Mais que fait la police ? */
					/* En attendant, vaut mieux setter l'Id du Mkt Segment... */
					for (k=0; k < stratEltNbr; k++)
					{
						if ((IS_NULLFLD(ESLPtr, ExtStratLnk_GridId) == FALSE) &&
							(IS_NULLFLD(stratEltTab[k], A_StratElt_MktSegtId) == TRUE) &&
							(IS_NULLFLD(stratEltTab[k], A_StratElt_InstrId) == FALSE))
						{
							ID_T mktSegtId = FIN_SearchInstrInGrid(hierHead,
											   GET_ID(ESLPtr, ExtStratLnk_GridId), 
											   GET_ID(stratEltTab[k], A_StratElt_InstrId),
											   NULLDYNST, 0, TRUE, classifStack,
											   NULL, FALSE, 0, TRUE, /* PMSTA08737 - LJE - 091223 */ 
											   NULL,
											   UNUSED, UNUSED);
							if (mktSegtId > 0)
							{
								SET_ID(stratEltTab[k], A_StratElt_MktSegtId, mktSegtId); 
							}
						}
					}

            /* REF7422 - YST - 021112 - reinitialisation is done before calling this function, in FIN_BenchLoadStratHistAndUpdateHier */
            /*for (j=0; j < stratEltNbr; j++)
            {		
				if(* reinitialization of the total , because the value rest into  *
				   (IS_NULLFLD(stratEltTab[j], A_StratElt_BenchObjId)==TRUE && anaBenchFlg==FALSE) 
							||
			       (IS_NULLFLD(stratEltTab[j], A_StratElt_AnaBenchObjId)==TRUE && anaBenchFlg==TRUE))
				{
					SET_NULL_NUMBER(stratEltTab[j],A_StratElt_Return);
				}

			}*/
            if (currEffectRetFlg == FALSE) /* REF9227 - LJE - 030919 */
            {
                /* test each strategy element if it is an index */
                for (j=0; j < stratEltNbr; j++)
                {		
                    /* if the value has changed, it means that it is an index because only index 
                    are changed by FIN_BenchReturn */
                    if (
                        IS_NULLFLD(stratEltTab[j], A_StratElt_OldValue) == FALSE 
                                                &&
						(TLS_Cmp(GET_NUMBER(stratEltTab[j], A_StratElt_Value),  /* REF7475 - LJE - 020619 */
                                 GET_NUMBER(stratEltTab[j], A_StratElt_OldValue), 0.0) != 0)
					    )
                    {
                        /* repercussion up from modified index to parent grid market segments */
                        if ((ret = FIN_RepercuteUp(hierHead, 
											       stratEltTab[j],
									               GET_NUMBER(stratEltTab[j], A_StratElt_OldValue),
												   0.0, /* Not used */
												   0.0, /* Not used */
                                                   stratPtr,
												   FALSE,
												   FALSE,
												   REPERCUTION_MODE_NORMAL)) != RET_SUCCEED)
                        {
                            FREE(stratEltTab);  
                            FREE(stratIdTab);
                            return(ret);
                        }
                  
                       /* do NOT do a repercussion down  */
                    }
			    }	
            }

            for (j=0; j < stratEltNbr; j++) /*REF8555 MCA 030110*/
            {		

				if(/* repercussion only for the instr. that have a benchMark */
				   (IS_NULLFLD(stratEltTab[j], A_StratElt_BenchObjId)==FALSE && anaBenchFlg==FALSE) 							
						||
			       (IS_NULLFLD(stratEltTab[j], A_StratElt_AnaBenchObjId)==FALSE && anaBenchFlg==TRUE))
				{
					if ((ret = FIN_RepercuteUp(hierHead,
												stratEltTab[j],
												0.0, /* Not Used */
												GET_NUMBER(stratEltTab[j], returnFieldIdx),  /* REF9227 - LJE - 030919 */
												0.0, /* Not used */
												stratPtr,
												currEffectRetFlg,
												FALSE,
												REPERCUTION_MODE_BENCH)) != RET_SUCCEED)
					{
					  FREE(stratEltTab); 
					  FREE(stratIdTab);
					  return(ret);
					}

				}
 

				/* REF9075 - RAK - 030604 */
				else if(IS_NULLFLD(stratEltTab[j], A_StratElt_InstrId) == FALSE)
				{
					if ((ret = FIN_RepercuteUp(hierHead,
												stratEltTab[j],
												0.0, /* Not Used */
												GET_NUMBER(stratEltTab[j], returnFieldIdx),  /* REF9227 - LJE - 030919 */
												0.0, /* Not used */
												stratPtr,
												currEffectRetFlg,
												FALSE,
												REPERCUTION_MODE_BENCH)) != RET_SUCCEED)
					{
					  FREE(stratEltTab); 
					  FREE(stratIdTab);
					  return(ret);
					}

				}

            }

            FREE(stratEltTab);  /* REF6025 - CSY - 010723: purify */
        }
    }
        
    FREE(stratIdTab);
    
    return (ret);
}

/************************************************************************
**
**  Function    : FIN_RepercuteUp()
**
**  Description : repercute the modification of index strategy elements to 
**                the strategy elements of parent grid market segments.
**                ("Up" means repercussion in the direction children to parents)
**
**  Arguments   : hierHead    hierarchy pointer
**                idxStratElt strategy element already adjusted (index), from which we do the repercussion.  
**
**  Return      : RET_SUCCEED : everybody is ok
**                error code:   something's wrong
** 
**  Creation    : DVP6025 - CSY - 010628 
**  Modification  REF6025 - CSY - 020308: add argument stratPtr to manage model portfolios based on grid
**  Modification  REF7422 - CSY - 020405: repercute also the contribution (return) of the index
**                REF6025 - CSY - 020517 model portfolio on grid list
**                REF6025 - CSY - 020524 repercussion on total global
**                REF7420 - CSY - 020918 get grid by id (grid of nature market structure is not in hierarcy)
**                REF7422 - MCA - 020728: adapt function for Bench
**                REF9658 - CHU - 040209 : Merge FIN_RepercuteUp(), FIN_RepercuteBenchUp() and FIN_RepercuteUpDSE()
** 
*************************************************************************/
RET_CODE FIN_RepercuteUp(DBA_HIER_HEAD_STP	hierHead, 
                         DBA_DYNFLD_STP		idxStratElt, 
                         double				oldValue,
						 double				idxContrib,
						 double				derivDiff,
                         DBA_DYNFLD_STP		stratPtr,
						 FLAG_T				currEffectRetFlg,
						 FLAG_T				derivFlg,
						 int				repercutionMode)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP  aGridSt			= NULLDYNST,
                    sMktSegtSt		= NULLDYNST, 
                    mktStructPtr	= NULLDYNST,
					derStratPtr		= NULLDYNST,
					idxDerStratPtr	= NULLDYNST,
                    admArgIn		= NULLDYNST;

    DBA_DYNFLD_STP	*stratEltTab1	= NULLDYNSTPTR,
					*stratEltTab2	= NULLDYNSTPTR,
					*sMktSgtTab		= NULLDYNSTPTR;

    int				stratEltNbr1	= 0,
					stratEltNbr2	= 0,
					sMktSgtNbr		= 0,
					i=0, j=0, k=0;

    double			diff = 0.0,
					newEltValue = 0.0,
					oldEltValue;
    FLAG_T          aGridStAllocFlg=FALSE;  /* REF7420 - CSY - 020918 */

    int             returnFieldIdx = (currEffectRetFlg?A_StratElt_AbsoluteReturnCurr:A_StratElt_AbsoluteReturn); /* REF9227 - LJE - 030919 */
	NUMBER_T		valueBench = 0.0;

	/* < REF9658 - CHU - 040211 : conditionnal expression simplification */
	FLAG_T			aGrid_isNatMktStruct     = FALSE,
					aGrid_isNatM3S           = FALSE,
					aGrid_Has_ParMktSegt     = FALSE,
					sMktSegt_Has_ParMktSegt  = FALSE,
					aStrat_Has_ParMktSegt    = FALSE,
					mktStruct_Has_ParMktSegt = FALSE,

					is1DGrid    = FALSE,
					is2DGrid    = FALSE,
					isGlobalTot = FALSE,
					isRowTot    = FALSE,
					isColTot    = FALSE;

	/* REF9658 - CHU - 040211 > */

	/* < REF9658 - CHU - 040209 : Repercution Fct Merge */
	FIELD_IDX_T		stratEltNatEnFld,
					stratEltWeightFld,
					stratEltOldWeightFld,
					stratEltContribFld,
					stratEltOldContribFld,
					stratEltStratIdFld,
					stratEltMktSegtIdFld,
					stratEltInstrIdFld;	/* REF10257 - RAK - 040608 */

    DBA_DYNST_ENUM  dynStEn;
	HIER_FLTFCT		*filterFct		= NULLFCT;

	switch(repercutionMode)
	{
	case REPERCUTION_MODE_DERIVATION :
				stratEltNatEnFld     = A_DerivedStratElt_NatEn;
				stratEltWeightFld    = A_DerivedStratElt_Weight;
				stratEltOldWeightFld = A_DerivedStratElt_OldWeight;
				stratEltContribFld   = A_DerivedStratElt_ContribValue;
				stratEltOldContribFld= A_DerivedStratElt_OldContribValue;
				stratEltStratIdFld   = A_DerivedStratElt_DerivedStratId;
				stratEltMktSegtIdFld = A_DerivedStratElt_MktSgtId;
				stratEltInstrIdFld	 = A_DerivedStratElt_InstrId;	/* REF10257 - RAK - 040608 */
                dynStEn              = A_DerivedStratElt;
				filterFct            = FIN_FilterDerivedStratElt;
				break;

	case REPERCUTION_MODE_NORMAL   :
	case REPERCUTION_MODE_BENCH    :
	default :
				stratEltNatEnFld     = A_StratElt_NatEn;
				stratEltWeightFld    = A_StratElt_Value;
				stratEltOldWeightFld = A_StratElt_OldValue;
				stratEltContribFld   = A_StratElt_ContribValue;
				stratEltOldContribFld= 0; /* should never be used in these modes ! */
				stratEltStratIdFld   = A_StratElt_StratHistId;
				stratEltMktSegtIdFld = A_StratElt_MktSegtId;
				stratEltInstrIdFld	 = A_StratElt_InstrId;	/* REF10257 - RAK - 040608 */
                dynStEn              = A_StratElt;
				filterFct            = FIN_FilterStratElt;
				break;
	}
	/* REF9658 - CHU - 040209 > */

	if (repercutionMode == REPERCUTION_MODE_DERIVATION)
	{
		diff = derivDiff;
		idxDerStratPtr = DBA_SearchHierRecById(hierHead,
										  A_DerivedStrat, A_DerivedStrat_Id,
										  GET_ID(idxStratElt, stratEltStratIdFld));
	}
	else
	{
		diff = GET_NUMBER(idxStratElt, stratEltWeightFld) - oldValue;
	}

    /* get from hierarchy the market segment of the strategy element */
    if ((ret = DBA_GetRecPtrFromHierById(hierHead, GET_ID(idxStratElt, stratEltMktSegtIdFld),
										S_MktSegt, &sMktSegtSt)) != RET_SUCCEED)
    {
        sMktSegtSt = NULLDYNST;
        return(ret);
    }
	if (sMktSegtSt == NULLDYNST)
		return(ret);

    /* REF7420 - CSY - 020918: grid with nature market structure subset is not loaded in hierarchy.
    get grid by id: from hier or by a DBA_Get2 */
	/* REF7420 - RAK - 021031 - New fct DBA_GetGridById() If not found in hier -> add grid in hier ... */
	if ((ret = DBA_GetGridById(GET_ID(sMktSegtSt, S_MktSegt_GridId), TRUE,	/* addInHier */
						       &aGridStAllocFlg, &aGridSt, hierHead,
						       UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		return(FALSE);
	}
	if (aGridSt == NULLDYNST)
		return(ret);

    if(GET_ENUM(aGridSt, A_Grid_NatEn) == (GRIDNATURE_ENUM)GridNat_MktStruct)
    {
        /* get from hierarchy the market structure of the market segment index */
        if ((ret = DBA_GetRecPtrFromHierById(hierHead, GET_ID(sMktSegtSt, S_MktSegt_MktStructId),
											A_MktStruct, &mktStructPtr)) != RET_SUCCEED)
        {
            mktStructPtr = NULLDYNST;
            return(ret);
        }
		if (mktStructPtr == NULLDYNST)
			return(ret);
    }

    /* REF7420 - CSY - 020918: make links between ref_grid and market structure */
	if (aGridStAllocFlg == FALSE)	/* REF7420 - RAK - 021031 - not allocated -> in hier */
	{
		if ((ret = DBA_SetHierLnkUsed(hierHead, A_Grid, A_Grid_S_MktSegt_Ext)) != RET_SUCCEED)
			return(ret);

		if ((ret = DBA_MakeSpecRecLinks(hierHead, A_Grid, A_Grid_S_MktSegt_Ext)) != RET_SUCCEED)
			return(ret);

		if ((ret = DBA_SetHierLnkUsed(hierHead, ExtStratLnk, ExtStratLnk_A_Grid_Ext)) != RET_SUCCEED)
			return(ret);

		if ((ret = DBA_MakeSpecRecLinks(hierHead,  ExtStratLnk, ExtStratLnk_A_Grid_Ext)) != RET_SUCCEED)
			return(ret);
	}

	/* Init some global conditional variables */
	if (aGridSt != NULLDYNST)
	{
		aGrid_isNatMktStruct = (FLAG_T)(GET_ENUM(aGridSt, A_Grid_NatEn) == (GRIDNATURE_ENUM)GridNat_MktStruct);
		aGrid_isNatM3S       = (FLAG_T)(GET_ENUM(aGridSt, A_Grid_NatEn) == (GRIDNATURE_ENUM)GridNat_MktSSubSet);
		aGrid_Has_ParMktSegt = (FLAG_T)(IS_NULLFLD(aGridSt, A_Grid_ParMktSegtId) == FALSE);
		is1DGrid             = (FLAG_T)(IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == TRUE);
		is2DGrid             = (FLAG_T)(IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE);
	}

	if (sMktSegtSt != NULLDYNST)
		sMktSegt_Has_ParMktSegt = (FLAG_T)(IS_NULLFLD(sMktSegtSt, S_MktSegt_ParMktSegtId) == FALSE);

	if (stratPtr != NULLDYNST)
		aStrat_Has_ParMktSegt = (FLAG_T)(IS_NULLFLD(stratPtr, A_Strat_MktSegmentId) == FALSE);

	if (mktStructPtr != NULLDYNST)
		mktStruct_Has_ParMktSegt = (FLAG_T)(IS_NULLFLD(mktStructPtr, A_MktStruct_ParMktSegtId) == FALSE);

    /* extract the market segments of the grid */
    if (GET_EXTENSION_PTR(aGridSt, A_Grid_S_MktSegt_Ext) != NULL &&
	    (sMktSgtTab = GET_EXTENSION_PTR(aGridSt, A_Grid_S_MktSegt_Ext)) != NULLDYNSTPTR)
    {
        sMktSgtNbr = GET_EXTENSION_NBR(aGridSt, A_Grid_S_MktSegt_Ext);

        /* loop on the market segments:
		 * extract the strategy elements which A_StratElt_MktSegtId equals S_MktSegt_Id,
		 * and that are totalisers, and not index
		 */
        for (j=0; j < sMktSgtNbr; j++)
        {	/* init some conditional variables */
			isGlobalTot = (FLAG_T)(IS_NULLFLD(sMktSgtTab[j], S_MktSegt_AbcissaListId)  == TRUE &&
								   IS_NULLFLD(sMktSgtTab[j], S_MktSegt_OrdinateListId) == TRUE);

			isRowTot = (FLAG_T)(IS_NULLFLD(sMktSgtTab[j], S_MktSegt_AbcissaListId)  == TRUE &&
								IS_NULLFLD(sMktSgtTab[j], S_MktSegt_OrdinateListId) == FALSE);

			isColTot = (FLAG_T)(IS_NULLFLD(sMktSgtTab[j], S_MktSegt_AbcissaListId)  == FALSE &&
								IS_NULLFLD(sMktSgtTab[j], S_MktSegt_OrdinateListId) == TRUE);

            /* repercute first to totalisers, then to parent market segment */
            if ((is1DGrid == TRUE && isGlobalTot == TRUE)
						||
                ((is2DGrid == TRUE || aGrid_isNatMktStruct== TRUE) && isRowTot == TRUE &&
				 GET_ID(sMktSgtTab[j], S_MktSegt_OrdinateListId) == GET_ID(sMktSegtSt, S_MktSegt_OrdinateListId))
                        ||
                ((is2DGrid == TRUE || aGrid_isNatMktStruct == TRUE) && isColTot == TRUE &&
                 GET_ID(sMktSgtTab[j], S_MktSegt_AbcissaListId) == GET_ID(sMktSegtSt, S_MktSegt_AbcissaListId))
                        || /* REF6025 - CSY - 020524 */
                ((is2DGrid == TRUE || aGrid_isNatMktStruct == TRUE) && isGlobalTot == TRUE)
                        ||
				 /* REF9075 - RAK - 030604 - Get the market segment of instrument for model portfolio */
				 /* PMSTA06124 - RAK - 080401 - Use stratEltInstrIdFld */
				(IS_NULLFLD(idxStratElt, stratEltInstrIdFld) == FALSE && 
				 GET_ID(sMktSgtTab[j], S_MktSegt_Id) == GET_ID(idxStratElt, stratEltMktSegtIdFld))
               )
            {
				/* REF10257 - RAK - 040608 - use new stratEltInstrIdFld which take care of A_StratElt or A_DerivedStratElt structure is received */
				/*                         - modify test and add verification on MktSgt and Instr Id in two part (mktStruct and not mktStruct) */
				if(
				   ((aGrid_isNatMktStruct == FALSE && aGrid_isNatM3S == FALSE) 
				                             &&
				   ((GET_ID(sMktSgtTab[j], S_MktSegt_Id) != GET_ID(sMktSegtSt, S_MktSegt_Id)) ||
				    (GET_ID(sMktSgtTab[j], S_MktSegt_Id) == GET_ID(sMktSegtSt, S_MktSegt_Id) &&
					 IS_NULLFLD(idxStratElt, stratEltInstrIdFld) == FALSE)))
							                 || 
				   /* REF7420 - CSY - 020829: market structure but bypass market segment with same id */
                   (aGrid_isNatMktStruct == TRUE &&
                    IS_NULLFLD(sMktSegtSt, S_MktSegt_MktStructId) == FALSE &&
				    GET_ID(sMktSegtSt, S_MktSegt_MktStructId) == GET_ID(sMktSgtTab[j], S_MktSegt_MktStructId) 
					                           &&
				    ((GET_ID(sMktSgtTab[j], S_MktSegt_Id) != GET_ID(sMktSegtSt, S_MktSegt_Id)) ||
				     (GET_ID(sMktSgtTab[j], S_MktSegt_Id) == GET_ID(sMktSegtSt, S_MktSegt_Id) &&
					  IS_NULLFLD(idxStratElt, stratEltInstrIdFld) == FALSE)))
				  )
                {
                    if (admArgIn == NULLDYNST)
                    {
                        if ((admArgIn = ALLOC_DYNST(Adm_Arg)) == NULLDYNST) 
                        {
		                    return(RET_SUCCEED);
	                    }
                    }

                    /* set filter criterias */
					/* same strategy history as the index element */
                    SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(idxStratElt, stratEltStratIdFld));
                    SET_ID(admArgIn, Adm_Arg_CodifId,GET_ID(sMktSgtTab[j], S_MktSegt_Id));  /* market segment id */

					/* REF10274 - RAK - 040512 - Add RefStratId (I continue the beautiful choose of fields */
					if (stratPtr != NULLDYNST)
					{ SET_ID(admArgIn, Adm_Arg_InstrCodifId, GET_ID(stratPtr, A_Strat_RefStratId)); }

					if (repercutionMode == REPERCUTION_MODE_DERIVATION)
					{	/*
						if derivFlg == FALSE : context of repercussion of an adjusted weight (index)
						********************
					 		extract the derived strategy elements which:
							- field  A_[Derived]StratElt_MktSgtId equals the id of the market segment sMktSgtTab[j] 
							- strategy_history_id or derived_strategy_id == strategy_history_id or derived_strategy_id of idxStratElt
							- are not index :
									- A_[Derived]StratElt_BenchObjectId == NULL
									- A_[Derived]StratElt_NatEn == StratEltNat_Weight
							so, keep initial filter fct : FIN_FilterDerivedStratElt()

						if derivFlg == TRUE : repercussion of a derived weight
						*******************
							extract the derived strategy elements which:
							- field A_[Derived]StratElt_MktSgtId == the market segment id of sMktSgtTab[j] 
							- derived strategy id == derived strategy id of idxStratElt
						*/
						if(derivFlg == TRUE)
							filterFct = FIN_FilterDerivedStratElt3;
					}

					if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, dynStEn, FALSE,
									filterFct, admArgIn, NULLFCT, &stratEltNbr1, &stratEltTab1)) != RET_SUCCEED)
					{
						FREE_DYNST(admArgIn, Adm_Arg);
						return(ret);
					}

                    /* repercute on totalisers */
                    for (k=0; k < stratEltNbr1; k++)
                    {
						switch(repercutionMode)
						{
						case REPERCUTION_MODE_DERIVATION :
							if(derivFlg == TRUE)
							{
								if(IS_NULLFLD(stratEltTab1[k], stratEltWeightFld) == TRUE)
								{	/* initialisation */
									SET_NUMBER(stratEltTab1[k], stratEltWeightFld,
										GET_NUMBER(stratEltTab1[k], stratEltOldWeightFld));
								}
								if(IS_NULLFLD(stratEltTab1[k], stratEltContribFld) == TRUE)
								{	/* initialisation */
									SET_NUMBER(stratEltTab1[k], stratEltContribFld,
										GET_NUMBER(stratEltTab1[k], stratEltOldContribFld));
								}
							}
							/* NO BREAK PLEASE ! */

						case REPERCUTION_MODE_NORMAL :                    
							/* add the difference between old value and value of the index [derived] strategy element */
							if(derivFlg == FALSE) /* Normal mode */
							{
								SET_NUMBER(stratEltTab1[k], stratEltWeightFld,
									diff + GET_NUMBER(stratEltTab1[k], stratEltWeightFld));
							}
							else   /* context of derivation computing: the weights are computed after from contributions */
							{
								SET_NUMBER(stratEltTab1[k], stratEltContribFld,
									diff +  GET_NUMBER(stratEltTab1[k], stratEltContribFld));
							}
							break;

						case REPERCUTION_MODE_BENCH :
							/* REF7422 - CSY - 020405: add the return contribution of the index strategy element */
							if (CMP_NUMBER(GET_NUMBER(stratEltTab1[k], stratEltWeightFld), 0.0) != 0) /*REF8555 MCA 030115 DIVISION BY 0*/
							{
								if((STRATELTNAT_ENUM)GET_ENUM(idxStratElt, stratEltNatEnFld) == (STRATELTNAT_ENUM)StratEltNat_ModelPtf)
								{
									valueBench = (idxContrib *100) * GET_NUMBER(idxStratElt, stratEltWeightFld) /*REF9881 MCA 030220 factor 100*/
												/ GET_NUMBER(stratEltTab1[k], stratEltWeightFld)
												+ GET_NUMBER(stratEltTab1[k], returnFieldIdx);
								}
								else
								{
									valueBench = idxContrib  * GET_NUMBER(idxStratElt, stratEltWeightFld) 
												/ GET_NUMBER(stratEltTab1[k], stratEltWeightFld)
												+ GET_NUMBER(stratEltTab1[k], returnFieldIdx);
								}

								SET_NUMBER(stratEltTab1[k], returnFieldIdx, valueBench); /*REF8555 MCA 030110*/
							}
							break;

						default :
							break;
						}
                    } /*end for*/
                    FREE(stratEltTab1);
                }
            }
        }
    }

	/* the grid may have a parent market segment */
    if (((aGrid_isNatMktStruct == FALSE) && (aGrid_isNatM3S == FALSE) && (aGrid_Has_ParMktSegt == TRUE))
				||
		/* REF7420 - CSY - 020829: for grid of nature market structure, parent market segment is given by market structure */
        ((aGrid_isNatMktStruct == TRUE) && (mktStruct_Has_ParMktSegt == TRUE))
				||
		(sMktSegt_Has_ParMktSegt == TRUE) /* REF9123 - CHU - 040218 */
				||
		(aStrat_Has_ParMktSegt == TRUE) /* REF9123 - CHU - 040218 */
	   )
    {
        /* allocate a structure for filter criterias */
        if (admArgIn == NULLDYNST)
        {
	        if ((admArgIn = ALLOC_DYNST(Adm_Arg)) == NULLDYNST) 
            {
		        return(RET_SUCCEED);
	        }
        }
        /* Set filter criterias : */
		/* same strategy history as the index element */
        SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(idxStratElt, stratEltStratIdFld));

		/* REF7420 - CSY - 020829: market structure grid:    */
		/* parent market segment id taken from market struct */
        if((aGrid_isNatMktStruct == TRUE) && (mktStruct_Has_ParMktSegt == TRUE))
        {
            SET_ID(admArgIn, Adm_Arg_CodifId, GET_ID(mktStructPtr, A_MktStruct_ParMktSegtId));
        }
        else
			if (aGrid_Has_ParMktSegt == TRUE) /* standard grid : parent market segment id taken from grid*/
			{
				SET_ID(admArgIn, Adm_Arg_CodifId, GET_ID(aGridSt, A_Grid_ParMktSegtId));
			}
			else
			{
				if (sMktSegt_Has_ParMktSegt == TRUE) /* REF9123 - CHU - 040218 */
				{
					SET_ID(admArgIn, Adm_Arg_CodifId, GET_ID(sMktSegtSt, S_MktSegt_ParMktSegtId));
				}
				else
				{
					if (aStrat_Has_ParMktSegt) /* REF9123 - CHU - 040218 */
					{
						SET_ID(admArgIn, Adm_Arg_CodifId, GET_ID(stratPtr, A_Strat_MktSegmentId));
					}
					else
					{
						FREE_DYNST(admArgIn, Adm_Arg);
						return(RET_SUCCEED);
					}
				}
			}

		/* Select Filtering function for next extract in hierarchy */
		if (repercutionMode == REPERCUTION_MODE_DERIVATION)
		{
			if(derivFlg == TRUE) /* repercussion of derived weight  */
			{	/* Extract from hierarchy the derivedstrategy elements which
				 * A_DerivedStratElt_MktSgtId equals A_Grid_ParMktSegtId
				 */
				if((STRATELTNAT_ENUM)GET_ENUM(idxStratElt, stratEltNatEnFld) == (STRATELTNAT_ENUM)StratEltNat_ModelPtf ||
				   (STRATELTNAT_ENUM)GET_ENUM(idxStratElt, stratEltNatEnFld) == (STRATELTNAT_ENUM)StratEltNat_Model)
				{	/* model portfolio: filter DSE in the same derived strat */
					filterFct = FIN_FilterDerivedStratElt3;
				}
				else /* asset alloc: may have parent market segment in an differnt derived strategy */
				{
					filterFct = FIN_FilterDerivedStratElt4;
				}
			}
		}

        /* extract from hierarchy the strategy elements which A_StratElt_MktSegtId equals A_Grid_ParMktSegtId */
        if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, dynStEn, FALSE,
            filterFct, admArgIn, NULLFCT, &stratEltNbr2, &stratEltTab2)) != RET_SUCCEED)
        {
            FREE_DYNST(admArgIn, Adm_Arg);
            return(ret);
        }

        /* repercute the modified index weight on the parent market segment strategy elements */
        for (i=0; i < stratEltNbr2; i++)
        {
			/* REF9658 - CHU - 040310 : Avoid endless recurse if same MPtf is present in several strategies */
			if (CMP_ID(GET_ID(stratEltTab2[i], A_StratElt_Id),GET_ID(idxStratElt, A_StratElt_Id))==0)
			{
				continue;
			}

			switch(repercutionMode)
			{
			case REPERCUTION_MODE_NORMAL :
					newEltValue = GET_NUMBER(stratEltTab2[i], stratEltWeightFld); /* here, the value is in fact old! */
					newEltValue += diff;   /* now, the value is new */
					/* save the old value of the element */
					oldEltValue = GET_NUMBER(stratEltTab2[i], stratEltWeightFld);
					/* add the difference between old value and value of the index strategy element */
					SET_NUMBER(stratEltTab2[i], stratEltWeightFld, newEltValue); /* now repercussion (on the strat elt) is done */

					/* continue the repercution upper and upper */
					if ((ret = FIN_RepercuteUp(hierHead, stratEltTab2[i], oldEltValue, 0.0, 0.0,
												stratPtr, FALSE, FALSE, repercutionMode)) != RET_SUCCEED)
					{
						FREE_DYNST(admArgIn, Adm_Arg);
						return (ret);
					}
					break;

			case REPERCUTION_MODE_BENCH :
					if (CMP_NUMBER(GET_NUMBER(stratEltTab2[i], stratEltWeightFld), 0.0) == 0)/* REF8555 MCA 030115 DIVISION BY 0 */
					{
						/* continue the repercussion upper and upper */
						if ((ret = FIN_RepercuteUp(hierHead, stratEltTab2[i], 0.0, 0.0, 0.0,
									stratPtr, currEffectRetFlg, FALSE, repercutionMode)) != RET_SUCCEED)
						/* change the value contrib to value absolute incremental.REF8555 MCA 030113 */
						{
							FREE_DYNST(admArgIn, Adm_Arg);
							return (ret);
						}
					}
					else
					{
						/* add the return contribution of the index strategy element */
						if((STRATELTNAT_ENUM)GET_ENUM(idxStratElt, stratEltNatEnFld) == (STRATELTNAT_ENUM)StratEltNat_ModelPtf)
						{
							valueBench = (idxContrib *100) * GET_NUMBER(idxStratElt, stratEltWeightFld)/*REF9881 MCA 030220 factor 100*/
										/ GET_NUMBER(stratEltTab2[i], stratEltWeightFld)
										+ GET_NUMBER(stratEltTab2[i], returnFieldIdx);
							SET_NUMBER(stratEltTab2[i], returnFieldIdx, valueBench); /* REF8555 MCA 030110 */

							valueBench = (idxContrib *100) * GET_NUMBER(idxStratElt, stratEltWeightFld)/*REF9881 MCA 030220 factor 100*/
										/ GET_NUMBER(stratEltTab2[i], stratEltWeightFld);
						}
						else
						{
							valueBench = idxContrib * GET_NUMBER(idxStratElt, stratEltWeightFld)
										/ GET_NUMBER(stratEltTab2[i], stratEltWeightFld)
										+ GET_NUMBER(stratEltTab2[i], returnFieldIdx);
							SET_NUMBER(stratEltTab2[i], returnFieldIdx, valueBench); /* REF8555 MCA 030110 */

							valueBench = idxContrib * GET_NUMBER(idxStratElt, stratEltWeightFld)
										/ GET_NUMBER(stratEltTab2[i], stratEltWeightFld);
						}


						/* continue the repercussion upper and upper */
						if ((ret = FIN_RepercuteUp(hierHead, stratEltTab2[i], 0.0, valueBench, 0.0,
									stratPtr, currEffectRetFlg, FALSE, repercutionMode)) != RET_SUCCEED)
						/* change the value contrib to value absolute incremental.REF8555 MCA 030113 */
						{
							FREE_DYNST(admArgIn, Adm_Arg);
							return (ret);
						}
					}
					break;

			case REPERCUTION_MODE_DERIVATION :
					/* REF8396 - CSY - 021111: check that derived strategy of DSE are of the same portfolio_id */
					derStratPtr = NULLDYNST;
					derStratPtr = DBA_SearchHierRecById(hierHead, A_DerivedStrat, A_DerivedStrat_Id,
														  GET_ID(stratEltTab2[i], stratEltStratIdFld));

					if(idxDerStratPtr != NULLDYNST && derStratPtr != NULLDYNST)
					{
						if(GET_ID(idxDerStratPtr, A_DerivedStrat_PtfId) != GET_ID(derStratPtr, A_DerivedStrat_PtfId))
						{
							continue;
						}
					}

					if(derivFlg == FALSE)
					{
						newEltValue = GET_NUMBER(stratEltTab2[i], stratEltWeightFld);   
						newEltValue += diff;   
						SET_NUMBER(stratEltTab2[i], stratEltWeightFld, newEltValue);
					}
					else
					{
						if(IS_NULLFLD(stratEltTab2[i], stratEltContribFld) == FALSE)
						{
							newEltValue = GET_NUMBER(stratEltTab2[i], stratEltContribFld);
						}
						else
						{
							newEltValue = GET_NUMBER(stratEltTab2[i], stratEltOldContribFld);
						}
						SET_NUMBER(stratEltTab2[i], stratEltContribFld, diff + newEltValue);
					}
					/* now repercussion (on the derived strat elt) is done */
            
					/* continue the repercussion upper and upper */
					if ((ret = FIN_RepercuteUp(hierHead, stratEltTab2[i], 0.0, 0.0, diff,
												NULLDYNST, FALSE, TRUE, repercutionMode)) != RET_SUCCEED)
					{
						FREE_DYNST(admArgIn, Adm_Arg);
						return (ret);
					}
					break;

			default :
					break;
			}
        }
        FREE(stratEltTab2);  /* REF6025 - CSY - 010723 - purify */
    }
    if (admArgIn != NULLDYNST)
        FREE_DYNST(admArgIn, Adm_Arg);  /* REF6025 - CSY - 010723 - purify */
    return (ret);
}

/************************************************************************
**
**  Function    : FIN_RepercuteDown()
**
**  Description : repercute the modification of index strategy elements to 
**                the strategy elements of sub-grid market segments.
**                ("Down" means repercussion in the direction parents to children)
**
**  Arguments   : hierHead    hierarchy pointer
**                idxStratElt strategy element already adjusted (index), from which
**                                 we do the repercussion. 
**                factor: repercussion factor (factor = X'/X)
**
**  Return      : RET_SUCCEED : everybody is ok
**                error code:   something's wrong
** 
**  Creation    : DVP6025 - CSY - 010628 
**  Modif       : REF9658 - CHU - 040209 Merge both functions FIN_RepercuteDown() and FIN_RepercuteDownDSE()
** 
*************************************************************************/
RET_CODE FIN_RepercuteDown(DBA_HIER_HEAD_STP	hierHead,
						   DBA_DYNFLD_STP		idxStratElt,
						   double				factor,
						   int					repercutionMode)
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP  *gridTab      = NULLDYNSTPTR,
                    *sMktSgtTab   = NULLDYNSTPTR,
                    *stratEltTab1 = NULLDYNSTPTR,
					*stratEltTab2 = NULLDYNSTPTR;

    DBA_DYNFLD_STP  aGridSt     = NULLDYNST,
                    sMktSegtSt  = NULLDYNST,
                    admArgIn    = NULLDYNST;

    int				gridNbr      = 0,
					stratEltNbr1 = 0,
					stratEltNbr2 = 0,
					sMktSgtNbr   = 0,
					i=0, j=0, k=0;

	/* < REF9658 - CHU - 040209 : Repercution Fct Merge */
	FIELD_IDX_T		stratEltWeightFld, stratEltOldWeightFld, stratEltStratIdFld, stratEltMktSegtIdFld;
    DBA_DYNST_ENUM  dynStEn;
	HIER_FLTFCT		*filterFct		= NULLFCT;

	FLAG_T			ignore_MSorM3S = TRUE;

	switch(repercutionMode)
	{
	case REPERCUTION_MODE_DERIVATION :
				stratEltWeightFld    = A_DerivedStratElt_Weight;
				stratEltOldWeightFld = A_DerivedStratElt_OldWeight;
				stratEltStratIdFld   = A_DerivedStratElt_DerivedStratId;
				stratEltMktSegtIdFld = A_DerivedStratElt_MktSgtId;
                dynStEn              = A_DerivedStratElt;
				filterFct            = FIN_FilterDerivedStratElt;
				break;

	case REPERCUTION_MODE_NORMAL   :
	case REPERCUTION_MODE_BENCH    :
	default :
				stratEltWeightFld    = A_StratElt_Value;
				stratEltOldWeightFld = A_StratElt_OldValue;
				stratEltStratIdFld   = A_StratElt_StratHistId;
				stratEltMktSegtIdFld = A_StratElt_MktSegtId;
                dynStEn              = A_StratElt;
				filterFct            = FIN_FilterStratElt;
				break;
	}
	/* REF9658 - CHU - 040209 > */

    /* allocate a structure for filter criterias */
	if ((admArgIn = ALLOC_DYNST(Adm_Arg)) == NULLDYNST) 
    {
		return(RET_SUCCEED);
	}

    /**************************************************************************/
    /*                                                                        */
    /*                if index is on totaliser: REPERCUSSION LATERAL          */ 
    /*                                                                        */
    /**************************************************************************/
    if (IS_NULLFLD(idxStratElt, stratEltOldWeightFld) == FALSE &&
        TLS_Cmp(GET_NUMBER(idxStratElt, stratEltOldWeightFld), GET_NUMBER(idxStratElt, stratEltWeightFld), 0.0) != 0) /* REF7475 - LJE - 020619 */
    {
        /* get from hierarchy the market segment of the strategy element */
        if ((ret = DBA_GetRecPtrFromHierById(hierHead, GET_ID(idxStratElt, stratEltMktSegtIdFld),
											S_MktSegt, &sMktSegtSt)) != RET_SUCCEED)
        {
            sMktSegtSt = NULLDYNST;
            return(ret);
        }

        if (sMktSegtSt != NULL) /* PMSTA-29623 - CHU - 171214 : avoid crash when accessing to the grid_id - next, find out why this mktsegt if missing from the hierarchy... */
        {
	        /* get from hierarchy the grid where the market segment belongs to */
	        if ((ret = DBA_GetRecPtrFromHierById(hierHead, GET_ID(sMktSegtSt, S_MktSegt_GridId),
												A_Grid, &aGridSt)) != RET_SUCCEED)
	        {
	            aGridSt = NULLDYNST;
	            return(ret);
	        }
	
			if (aGridSt != NULLDYNST)
			{
				ignore_MSorM3S = (FLAG_T)((GET_ENUM(aGridSt, A_Grid_NatEn) != (GRIDNATURE_ENUM)GridNat_MktStruct) && 
								(GET_ENUM(aGridSt, A_Grid_NatEn) != (GRIDNATURE_ENUM)GridNat_MktSSubSet));
			}
	
	        /* is the market segment a totaliser ? */
	        if (aGridSt != NULLDYNST && /* REF7420 - CSY - 020918 */
	            ignore_MSorM3S &&
	            (
	            (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == TRUE  &&   /* 1D grid */
	            IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == TRUE &&   /* totaliser of a 1D grid */
	            IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == TRUE)
	                                    ||
	            (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE  &&  /* 2D grid */
	             IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == TRUE &&  /* totaliser row of a 2D grid */
	             IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == FALSE)
	                                    ||
	            (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE  &&  /* 2D grid */
	             IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == FALSE && /* totaliser column of a 2D grid */
	             IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == TRUE)
	             )
	            )
	        {
	            /* extract the market segments of the grid */
	            if (GET_EXTENSION_PTR(aGridSt, A_Grid_S_MktSegt_Ext) != NULL &&
		            (sMktSgtTab = GET_EXTENSION_PTR(aGridSt, A_Grid_S_MktSegt_Ext)) != NULLDYNSTPTR)
	            {
	                sMktSgtNbr = GET_EXTENSION_NBR(aGridSt, A_Grid_S_MktSegt_Ext);
	        
	                /* loop on the market segments:
					 * extract the strategy elements which A_StratElt_MktSegtId equals S_MktSegt_Id,
					 * and that are not totalisers, and not index
					 */
	                for (j=0; j < sMktSgtNbr; j++)
	                {
	                    /* repercute first to elements totalised, then down */
	                    if (
	                        (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == TRUE  && /* 1D grid */
	                        IS_NULLFLD(sMktSgtTab[j], S_MktSegt_AbcissaListId) == FALSE  /* element sMktSgtTab[j] is not totaliser: we must repercute from totaliser */
	                        )
	                                                ||
	                        (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE  && /* 2D grid */
	                         IS_NULLFLD(sMktSgtTab[j], S_MktSegt_AbcissaListId) == FALSE &&    /* element sMktSgtTab[j] is not totaliser: we must repercute from totaliser   */
	                         IS_NULLFLD(sMktSgtTab[j], S_MktSegt_OrdinateListId) == FALSE &&
	                            (GET_ID(sMktSgtTab[j], S_MktSegt_OrdinateListId) == 
	                            GET_ID(sMktSegtSt, S_MktSegt_OrdinateListId) ||
	                            GET_ID(sMktSgtTab[j], S_MktSegt_AbcissaListId) == 
	                            GET_ID(sMktSegtSt, S_MktSegt_AbcissaListId))
	                            )   
	                        )
	        
	                    {
	                        /* set filter criterias */
							/* same strategy history as the index element */
	                        SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(idxStratElt, stratEltStratIdFld));
							/* market segment id */
	                        SET_ID(admArgIn, Adm_Arg_CodifId, GET_ID(sMktSgtTab[j], S_MktSegt_Id));
	
	                        /* extract the strategy elements which:
	                        - field A_StratElt_MktSegtId equals the id of the 
	                            market segment sMktSgtTab[j] 
	                        - strategy history id equals as strategy history id of idxStratElt
	                        - are not index :
	                                - A_StratElt_BenchObjectId == NULL
	                                - A_StratElt_NatEn == StratEltNat_Weight (if asset alloc) or 15 (if model)  */
	                        if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, dynStEn, FALSE,
	                                        filterFct, admArgIn, NULLFCT, &stratEltNbr1, &stratEltTab1)) != RET_SUCCEED)
	                        {
	                            FREE_DYNST(admArgIn, Adm_Arg);
	                            return(ret);
	                        }
	
	                        for (k=0; k < stratEltNbr1; k++)
	                        {
	                            SET_NUMBER(stratEltTab1[k], stratEltWeightFld,
									(GET_NUMBER(stratEltTab1[k], stratEltWeightFld)) * factor);
	
	                            if ((ret = FIN_RepercuteDown(hierHead, stratEltTab1[k], factor, repercutionMode)) != RET_SUCCEED)
	                            {
	                                FREE(stratEltTab1);
	                                FREE_DYNST(admArgIn, Adm_Arg);
	                                return(ret);
	                            }
	                        }
	                        FREE(stratEltTab1); /* REF6025 - CSY - 010723: purify */
	                    }
	                }
	            }
	        }
	    }
    }

    /**************************************************************************/
    /*                                                                        */
    /*                REPERCUSSION DOWN                                       */ 
    /*                                                                        */
    /**************************************************************************/

    /* set criteria on index market segment id */
    SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(idxStratElt, stratEltMktSegtIdFld));

    /* extract the grid which parent market segment is the market segment of the index strategy element */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_Grid, FALSE,
            FIN_FilterGridByParMktSegtId, admArgIn, NULLFCT, &gridNbr, &gridTab)) != RET_SUCCEED)
    {
        FREE_DYNST(admArgIn, Adm_Arg);
        return(ret);
    }

    for (i=0; i < gridNbr; i++)
    {
        SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(gridTab[i], A_Grid_Id));

        /* extract the market segments of the grid */
        if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_MktSegt, FALSE,
            FIN_FilterMktSegtByGridId, admArgIn, NULLFCT, &sMktSgtNbr, &sMktSgtTab)) != RET_SUCCEED)
        {
            FREE_DYNST(admArgIn, Adm_Arg);
            return(ret);
        }

        for (j=0; j < sMktSgtNbr; j++)
        {
            /* set filter extraction criterias */
			/* same strategy history as the index element */
            SET_ID(admArgIn, Adm_Arg_UserId, GET_ID(idxStratElt, stratEltStratIdFld));   
            SET_ID(admArgIn, Adm_Arg_CodifId,GET_ID(sMktSgtTab[j], S_MktSegt_Id));   

            /* extract the strategy elements which:
                - field A_StratElt_MktSegtId equals the id of the market segment sMktSgtTab[j] 
                - are not index :
                        - A_StratElt_BenchObjectId == NULL
                        - A_StratElt_NatEn == StratEltNat_Weight (if alloc) or 15 (if model)*/
            if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, dynStEn, FALSE,
                            filterFct, admArgIn, NULLFCT, &stratEltNbr2, &stratEltTab2)) != RET_SUCCEED)
            {
                FREE_DYNST(admArgIn, Adm_Arg);
                return(ret);
            }

            /* repercute on the strategy elements */
            for (k = 0; k < stratEltNbr2; k++)
            {
                /* set the value to the stratEltWeightFld: x' = X'/X (where X: index weight original value)*/
                SET_NUMBER(stratEltTab2[k], stratEltWeightFld,
                    (GET_NUMBER(stratEltTab2[k], stratEltWeightFld)) * factor);

                /* repercute deeper and deeper... aouch...*/
                if ((ret = FIN_RepercuteDown(hierHead, stratEltTab2[k], factor, repercutionMode)) != RET_SUCCEED)
                {
                    FREE_DYNST(admArgIn, Adm_Arg);
                    return (ret);
                }
            }
            FREE(stratEltTab2);     /* REF6025 - CSY - 010723: purify */
        }
        FREE(sMktSgtTab);   /* REF6025 - CSY - 010723: purify */
    }
    FREE(gridTab);
    FREE_DYNST(admArgIn, Adm_Arg);
    return (ret);
}

/*************************************************************************************************
*
*  Function          : FIN_FilterGridByParMktSegtId()  
*                      
*
*
*  Description       : filter function used to find  A_Grid which A_Grid_ParMktSegtId is equal
*                      to the id given in the filter structure admArgIn.
*                      
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6025 - CSY - 010628
*  Last modification : REF6082 - CSY - 010912: change STATIC to EXTERN
*
**************************************************************************************************/
EXTERN int FIN_FilterGridByParMktSegtId(DBA_DYNFLD_STP dynSt, 
		                 		        DBA_DYNST_ENUM dynStTp, 
		                 		        DBA_DYNFLD_STP admArgIn)
{
    if (GET_ID(dynSt, A_Grid_ParMktSegtId) == GET_ID(admArgIn, Adm_Arg_UserId))
        return (TRUE);
    return (FALSE);

}

/*************************************************************************************************
*
*  Function          : FIN_FilterMktSegtByGridId()  
*                      
*
*
*  Description       : filter function used to find  S_MktSegt which S_MktSegt_GridId is equal
*                      to the id given in the filter structure admArgIn.
*                      
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6025 - CSY - 010628
*  Last modification :
*
**************************************************************************************************/
int FIN_FilterMktSegtByGridId(DBA_DYNFLD_STP dynSt,
							  DBA_DYNST_ENUM dynStTp, 
							  DBA_DYNFLD_STP admArgIn)
{
    if (GET_ID(dynSt, S_MktSegt_GridId) == GET_ID(admArgIn, Adm_Arg_UserId))
        return (TRUE);
    return (FALSE);

}

/*************************************************************************************************
*
*  Function          : FIN_FilterStratElt()  
*                      
*
*
*  Description       : filter function used to find  A_StratElt by market segment id, strategy history id,
*                      and other criterias meaning the A_StratElt is not an index.
*                      
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6025 - CSY - 010628
*  Last modification : REF6025 - CSY - 020528: remove criteria value != 100
*
**************************************************************************************************/
int FIN_FilterStratElt (DBA_DYNFLD_STP dynSt, 
		                 		        DBA_DYNST_ENUM dynStTp, 
		                 		        DBA_DYNFLD_STP admArgIn)
{
    if ( GET_ID(dynSt, A_StratElt_StratHistId) ==  GET_ID(admArgIn,   Adm_Arg_UserId)  /* strategy history id */
                                    &&
		 GET_ID(dynSt, A_StratElt_MktSegtId) == GET_ID(admArgIn,   Adm_Arg_CodifId) /* market segment id */
                                &&
		 /* REF10274 - RAK - 040512 - RefStratId */
		 GET_ID(dynSt, A_StratElt_RefStratId) == GET_ID(admArgIn, Adm_Arg_InstrCodifId)		/* RefStratId */
                                    &&
         /* filter elements that are not an index: value != 100, no bench_object_id, 
         nature == weight (1) (for asset alloc) or model (15) (for model portfolio) */
         (IS_NULLFLD(dynSt, A_StratElt_BenchObjId) == TRUE) &&
         /* (GET_NUMBER(dynSt, A_StratElt_Value) != 100.0)  &&  */
         ((STRATELTNAT_ENUM)GET_ENUM(dynSt, A_StratElt_NatEn) == (STRATELTNAT_ENUM)StratEltNat_Weight 
                                        ||
         (STRATELTNAT_ENUM)GET_ENUM(dynSt, A_StratElt_NatEn) == (STRATELTNAT_ENUM)StratEltNat_Model)
         )
		return(TRUE);
	else   
    	return(FALSE);
    
}

/************************************************************************
**
**  Function    :   FIN_FilterStratEltByStratHistId()
**
**  Description :   filter strategy elements by A_StratElt_StratHistId == 
**                  the given id (contained in A_StratHist_Id)
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF6025 - CSY - 010627
**
*************************************************************************/
int FIN_FilterStratEltByStratHistId(DBA_DYNFLD_STP dynSt, 
		       DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    
    if (GET_ID(dynSt, A_StratElt_StratHistId) == GET_ID(paramSt, A_StratHist_Id) &&	/* REF10274 - RAK - 040512 */
		GET_ID(dynSt, A_StratElt_RefStratId)  == GET_ID(paramSt, A_StratHist_RefStratId) )
	    return(TRUE);
    else 
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterStratByIdAndRefStratId()
**
**  Description :   filter strategy  by A_Strat_Id and A_Strat_RefStratId
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF10274 - RAK - 040512 
**
*************************************************************************/
STATIC int FIN_FilterStratByIdAndRefStratId(DBA_DYNFLD_STP dynSt, 
											DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    if (GET_ID(dynSt, A_Strat_Id)         == GET_ID(paramSt, Get_Arg_Id) &&	
		GET_ID(dynSt, A_Strat_RefStratId) == GET_ID(paramSt, Get_Arg_RefCurrId)) /* In fact RefStratId */
	    return(TRUE);
    else 
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpInstrCompo()
**
**  Description :   A_InstrCompo sorted  by desc. beg.date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_InstrCompo
**                  ptr2   pointer on dynamic structure type A_InstrCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF5358 - CSY - 001115
**
*************************************************************************/
STATIC int FIN_CmpInstrCompo(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
           
	return(DATETIME_CMP(GET_DATETIME((*ptr2), A_InstrCompo_BeginDate),
		GET_DATETIME((*ptr1), A_InstrCompo_BeginDate)));
    
}

/************************************************************************
**
**  Function    :   FIN_CmpDateTime()
**
**  Description :   sort an array of dates by ascending date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_InstrCompo
**                  ptr2   pointer on dynamic structure type A_InstrCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF5358 - CSY - 001120
**
*************************************************************************/
STATIC int FIN_CmpDateTime(DATETIME_T* date1, DATETIME_T* date2)
{
    return(DATETIME_CMP((*date1), (*date2)));
}

/************************************************************************
**
**  Function    :   FIN_CmpInstrCompoByAscBegDate()
**
**  Description :   A_InstrCompo sorted by asc. beg.date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_InstrCompo
**                  ptr2   pointer on dynamic structure type A_InstrCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF5358 - CSY - 001115
**	Modif		:	PMSTA01435 - RAK - 070327 - external 
**
*************************************************************************/
int FIN_CmpInstrCompoByAscBegDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* PMSTA02303 - RAK - 070509 - Add sort on end date */
	if (DATETIME_CMP(GET_DATETIME((*ptr1), A_InstrCompo_BeginDate),
		GET_DATETIME((*ptr2), A_InstrCompo_BeginDate)) == 0)
	{
        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_InstrCompo_EndDate), 
		                        GET_DATETIME((*ptr2), A_InstrCompo_EndDate)));
	}
	else
	{
		return(DATETIME_CMP(GET_DATETIME((*ptr1), A_InstrCompo_BeginDate),
			GET_DATETIME((*ptr2), A_InstrCompo_BeginDate)));
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpStratHistByAscBegDate()
**
**  Description :   A_StratHist sorted by asc. beg.date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_StratHist
**                  ptr2   pointer on dynamic structure type A_StratHist
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF5358 - CSY - 001123
**
*************************************************************************/
int FIN_CmpStratHistByAscBegDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_StratHist_BegDate), 
		                        GET_DATETIME((*ptr2), A_StratHist_BegDate)));

}


/************************************************************************
**
**  Function    :   FIN_CmpStratHistByDescBegDate()
**
**  Description :   A_StratHist sorted by desc. beg.date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_StratHist
**                  ptr2   pointer on dynamic structure type A_StratHist
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF5358 - CSY - 001123
**
*************************************************************************/
STATIC int FIN_CmpStratHistByDescBegDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

        return(DATETIME_CMP(GET_DATETIME((*ptr2), A_StratHist_BegDate), 
		                        GET_DATETIME((*ptr1), A_StratHist_BegDate)));

}



/************************************************************************
**
**  Function    :   FIN_ComputeWeight()
**
**  Description :   Compute the valid weights of a benchmark for a given period
**                 
**  Arguments   :   
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   REF1079 - CSY - 010117
**              REF6025 - CSY - 010606  
**              REF6025 - CSY - 010718: derived strategies management  
**              REF7422 - CSY - 020605: anaBenchFlg       
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeWeight(ID_T				   objId,
                                  DBA_DYNFLD_STP	   parentPtr, 
                                  DBA_DYNFLD_STP	   stratHistPtr, 
                                  OBJECT_ENUM          objectEn,
		                          DATETIME_T		   begDate,
                                  FIN_RETURNPARAM_STP  returnParamStp,
                                  IDXTIMERULE_ENUM	   rebalRule, 
                                  ID_T                 contribObjectId,
                                  CONTRIBRULE_ENUM     contribRule,
                                  ID_T                 priceValRuleId,
                                  ID_T                 exchValRuleId,
                                  DBA_HIER_HEAD_STP    hierHead,
                                  FIN_WEIGHT_STP       currentWeight,
                                  DBA_DYNFLD_STP       *instrCompoTabParam,
                                  int                  instrCompoNbrParam,
                                  FLAG_T               allocInstrCompoEltFlg, /* SUPPORT-6697 - LJE - 160609 */
                                  FLAG_T               checkStratFlg,  /* REF6025 - CSY - 010606 */
                                  FLAG_T               anaBenchFlg,    /* REF7422 - CSY - 020605 */
                                  ID_T**               stratIdTabPtr,  /* REF6025 - CSY - 010607 */
                                  int*                 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
                                  DBA_DYNFLD_STP	   ESLPtr)		   /* REF10274 - RAK - 040506 */
{
    int				selInstrCompoNbr = 0, i=0, j=0, stratEltNbr=0, maxWeightNbr = 0,
					stratNbr = 0;   /* REF6025 - CSY - 010606: for extract from hier when checkStratFlg */
    double			maxWeight = 0.0;
    FLAG_T			stratAllocFlg = TRUE, stratHistAllocFlg = TRUE, stratEltAllocFlg = TRUE, allocInstrCompoFlg = TRUE; /* REF6025 - CSY - 010606 */
	DBA_DYNFLD_STP  *selInstrCompoTab = NULLDYNSTPTR, *stratEltTab = NULLDYNSTPTR,
        			*stratHistTab=NULLDYNSTPTR, *stratTab; /* REF6025 - CSY - 010606: for extract from hier when checkStratFlg */
    RET_CODE		ret=RET_SUCCEED;
    DBA_DYNFLD_STP	sInstr=NULLDYNST, aStratHistOut   = NULLDYNST, /* for sub strat */
					getArg = NULLDYNST,
					aInstr=NULLDYNST, aStrat=NULLDYNST, selArg=NULLDYNST, 
					compoInstr = NULLDYNST,
					aStratOut=NULLDYNST, getStratPtr=NULLDYNST,
					sMktSegt=NULLDYNST, aMktSegt=NULLDYNST;

    DICT_T			stratDictId, instrDictId;
    ID_T			compoInstrId=0, instrId=0, stratHistId=0;
    ID_T			benchId = 0;    /* REF7422 - CSY - 020605: may be a benchObjectId or a anaBenchOjectId */
    DBA_DYNFLD_STP  *instrCompoTab=NULLDYNSTPTR;
    int             instrCompoNbr=0;
	FLAG_T addChild = FALSE;
	int k = 0;
	
    DBA_GetDictId(Strat, &stratDictId);
    DBA_GetDictId(Instr, &instrDictId);

    if (objectEn == Instr)
    {
        /* get instrument with id = objId */
        if ((sInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        
        if (instrCompoTabParam == NULLDYNSTPTR)
        {
            /* alloc input structure for select */
            if ((selArg = ALLOC_DYNST(S_InstrCompo)) == NULLDYNST)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_InstrCompo");
                return(RET_MEM_ERR_ALLOC);
            }

            /* set input structure for select  */
            SET_ID(selArg, S_InstrCompo_ParentInstrId, objId); /* id of the benchmark */
            SET_DATETIME(selArg, S_InstrCompo_BeginDate, begDate);

            /* select all the valid instr_compos of the benchmark valid at begDate */
		    if ((ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, selArg,
			              A_InstrCompo, &instrCompoTab, UNUSED, UNUSED, 
			              &instrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
            {
                   FREE(instrCompoTab); 
                   FREE_DYNST(selArg, S_InstrCompo);
                   return(RET_SUCCEED);
            }
            FREE_DYNST(selArg, S_InstrCompo);
        }
        else
        {
            instrCompoTab = instrCompoTabParam;
            instrCompoNbr = instrCompoNbrParam;
            allocInstrCompoFlg = FALSE;
        }

        j = 0;
        while (j < instrCompoNbr && 
			DATETIME_CMP(GET_DATETIME(instrCompoTab[0], A_InstrCompo_BeginDate),
			GET_DATETIME(instrCompoTab[j], A_InstrCompo_BeginDate)) == 0)
        {
            compoInstrId = GET_ID(instrCompoTab[j], A_InstrCompo_InstrId);
            SET_ID(sInstr, S_Instr_Id, compoInstrId);
            
            if ((aInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
            {
                FREE_DYNST(sInstr, S_Instr);
                if (allocInstrCompoFlg == TRUE)
                            FREE(instrCompoTab);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr,
                               &aInstr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
			    MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "Instr",
                          compoInstrId);
                FREE_DYNST(sInstr, S_Instr);
                FREE_DYNST(aInstr, A_Instr);
                if (allocInstrCompoFlg == TRUE)
                            FREE(instrCompoTab);
                return(RET_DBA_ERR_NODATA);
            }

            /* add the(simple)  child  */ 
            if ((ret = FIN_AddChildWeight(currentWeight, Instr,
                            compoInstrId, aInstr,
                            TRUE,
                            NULL,
                            FALSE,
                            instrCompoTab[j],
                            allocInstrCompoEltFlg
                            )) != RET_SUCCEED)
            {
                FREE_DYNST(sInstr, S_Instr);
                FREE_DYNST(aInstr, A_Instr);
                if (allocInstrCompoFlg == TRUE)
                        FREE(instrCompoTab);
                return (ret);
            }

            if ((GET_ENUM(aInstr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue) &&
            (GET_ENUM(aInstr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
            {

                if ((ret = FIN_ComputeWeight(compoInstrId,
											 compoInstr,
											 NULLDYNST,
											 objectEn,
											 begDate,
											 returnParamStp, 
										     rebalRule,
											 contribObjectId, 
											 contribRule, 
											 priceValRuleId,
											 exchValRuleId,
											 hierHead, 
											 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
											 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
											 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
											 NULLDYNSTPTR,
											 0,
                                             TRUE, /* SUPPORT-6697 - LJE - 160609 */
											 checkStratFlg,   /* REF6025 - CSY - 010606 */
											 anaBenchFlg,    /* REF7422 - CSY - 020605 */
											 stratIdTabPtr,  /* REF6025 - CSY - 010607 */
											 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
											 ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                {
                    FREE_DYNST(sInstr, S_Instr);
                    if (allocInstrCompoFlg == TRUE)
                        FREE(instrCompoTab);
                    return (ret);
                }
            }
            
            j++;
        }
        if (allocInstrCompoFlg == TRUE)
             FREE(instrCompoTab);
		
        FREE_DYNST(sInstr, S_Instr);
        
    }
	/* REF10822 - RAK - 041216 - strat could be NULL */
    else if (objectEn == Strat && parentPtr != NULLDYNST)
    {
        aStrat = parentPtr; /* it must be a strategy ! */
		
		if (checkStratFlg == TRUE)
		{
			/* check if strategy has already been treated: if treated, don't treat it again */
			FLAG_T  foundIdFlg = FALSE;
			int     allocSz = 10;
			for (j=0; j< *stratIdNbrPtr; j++)
			{
				if ((*stratIdTabPtr)[j] == GET_ID(parentPtr, A_Strat_Id))
				{
					foundIdFlg = TRUE;
					break;
				}
			}

			if (foundIdFlg == FALSE)
			{           
				if (*stratIdNbrPtr == 0)
				{
					*stratIdTabPtr = (ID_T *)CALLOC(allocSz, sizeof(ID_T)); /* REF7264 - LJE - 020131 */
				}
				else if ((*stratIdNbrPtr)%allocSz == 0)
				{
					/* REF8949.410 - CSY - 040203 */
					allocSz =  (*stratIdNbrPtr) + allocSz;
					if ((*stratIdTabPtr = (ID_T*) REALLOC(*stratIdTabPtr, 
						(allocSz*sizeof(ID_T)))) == (ID_T*)NULL)
					{
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}
				}

				/* add the strategy id in the array */
				(*stratIdTabPtr)[*stratIdNbrPtr] = GET_ID(parentPtr, A_Strat_Id);
				(*stratIdNbrPtr)++;
			}      
		}

		/* if called via check strategy, links are done */
		if (stratHistPtr != NULL && (stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext)) != NULL)
		{
			stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
			if (stratEltNbr > 0)
				stratEltAllocFlg = FALSE;
		}
		else
		{
			/* alloc input structure for select */
			if ((selArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
				return(0);
			}
        
			SET_ID(selArg, Adm_Arg_Id, objId);  /* objId: id of a strategy history */

			/* select the strategy elements of the given strategy history id */
			if ((ret = DBA_Select2(StratElt, UNUSED, Adm_Arg, selArg, A_StratElt, &stratEltTab, 
								UNUSED, UNUSED, &stratEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
			{
				FREE_DYNST(selArg, Adm_Arg);
				return(ret);
			}
			FREE_DYNST(selArg, Adm_Arg);
		}

		if (stratEltNbr == 0 || stratEltTab == NULL)
			/*return(benchRet);*/  
			return (RET_GEN_INFO_NODATA); /* ? */ 

		/* compute maxWeight for asset allocation only */
		if (GET_ENUM(aStrat, A_Strat_NatEn) == (STRATNAT_ENUM)StratNat_Alloc)
		{
			int loopNbr = 0;
			while (loopNbr < 2)
			/*  first loop: compute maxWeight 
				second loop: compute maxWeightNbr */
			{
				for (i=0; i < stratEltNbr; i++)
				{
					if (GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                                                 (STRATELTNAT_ENUM)StratEltNat_Weight)
					{
						continue;
					}
					if (loopNbr == 0 &&
                        (maxWeight <  GET_NUMBER(stratEltTab[i], A_StratElt_Value)))
					{
						maxWeight = GET_NUMBER(stratEltTab[i], A_StratElt_Value);
                    }
                    else if (loopNbr == 1 && 
                            (TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_StratElt_Value), 0.0) == 0)) /* REF7475 - LJE - 020619 */
                    {
                        maxWeightNbr++;
                    }
                }
                loopNbr++;
            }
        }
		        
        /* loop on the elements to add the childs */
        for (i=0; i < stratEltNbr; i++)
        {
			addChild = FALSE;
            if (GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_Weight &&
                        GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_ModelPtf &&
                        GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_ModelPtfConstWeight)
            {
                if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                    FREE_DYNST(stratEltTab[i], A_StratElt);
                continue;
            }

			/* REF11559 - CHU - 051124 : check validity of Strategy element */
			if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
				IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
				CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
			{
				/* PMSTA06646 - LJE - 080613 */
                if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                    FREE_DYNST(stratEltTab[i], A_StratElt);
				continue;
			}

			/* REF8286 - CSY - 030501: save the original value */
			SET_NUMBER(stratEltTab[i], A_StratElt_DBValue, GET_NUMBER(stratEltTab[i], A_StratElt_Value));
            
            if (GET_ENUM(aStrat, A_Strat_NatEn) == (STRATNAT_ENUM)StratNat_Alloc)
            {
				/* REF10274 - RAK - 040505 - If dimension is strategy and object identifier isn't specified, use sub-strategy (if exist) */
				if (GET_ENUM(stratEltTab[i], A_StratElt_NatEn) == (STRATELTNAT_ENUM)StratEltNat_Weight)
				{
					if (ESLPtr != NULLDYNST && IS_NULLFLD(ESLPtr, ExtStratLnk_RefStratId) == FALSE &&
						(anaBenchFlg == FALSE && 
					     GET_DICT(stratEltTab[i], A_StratElt_BenchEntDictId) == stratDictId &&
					     IS_NULLFLD(stratEltTab[i], A_StratElt_BenchObjId)) ||
						(anaBenchFlg == TRUE && 
					     GET_DICT(stratEltTab[i], A_StratElt_AnaBenchEntDictId) == stratDictId &&
					     IS_NULLFLD(stratEltTab[i], A_StratElt_AnaBenchObjId)))
					{
						DBA_DYNFLD_STP	paramStp=NULLDYNST, *ESLTab=NULLDYNSTPTR;
						int				ESLNbr=0;

						if ((paramStp = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
						{
							return(RET_MEM_ERR_ALLOC);
						}

						SET_ID(paramStp, Get_Arg_Id, GET_ID(stratEltTab[i], A_StratElt_MktSegtId));
						SET_ID(paramStp, Get_Arg_RefCurrId, GET_ID(ESLPtr, ExtStratLnk_RefStratId));

						if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
			                                                ExtStratLnk, 
			                                                FALSE,
                                                            FIN_FilterStratWithMktSgtOfElt,
                                                            paramStp,
                                                            NULL,
                                                            &ESLNbr,
                                                            &ESLTab)) != RET_SUCCEED)
						{
							FREE_DYNST(paramStp, Get_Arg);
                            return(ret);
                        }

						if (ESLNbr > 0)	/* REF10274 - Could be several if more than one ptf is linked to the same ref strategy */
						{
							if (anaBenchFlg == FALSE)
							{ SET_ID(stratEltTab[i], A_StratElt_BenchObjId, GET_ID(ESLTab[0], ExtStratLnk_StratId));}
							else
							{ SET_ID(stratEltTab[i], A_StratElt_AnaBenchObjId, GET_ID(ESLTab[0], ExtStratLnk_StratId));}
						}
						else if(checkStratFlg == TRUE)			/*WEALTH-4625*/
						{							
							continue;
						}

						FREE_DYNST(paramStp, Get_Arg);
						FREE(ESLTab);
					}
				}

                /* asset allocation */
                if (GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_Weight || 
                            /* REF7422 - CSY - 020605 : manage anaBenchFlg */
							/* REF10822 - RAK - 041215 */
							/* suppress test on ObjId and EntDictId        */
							/* to add all children in childWeightTab       */
							/* so ponderation will be done on all children */
                            /* ((anaBenchFlg == FALSE && IS_NULLFLD(stratEltTab[i], A_StratElt_BenchObjId)) ||
                                (anaBenchFlg == TRUE && IS_NULLFLD(stratEltTab[i], A_StratElt_AnaBenchObjId))) 
                                    || 
							   ((anaBenchFlg == FALSE && IS_NULLFLD(stratEltTab[i], A_StratElt_BenchEntDictId)) || 
							    (anaBenchFlg == TRUE && IS_NULLFLD(stratEltTab[i], A_StratElt_AnaBenchEntDictId)))
                                    || 
							*/
                    (maxWeightNbr == 1 && TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_StratElt_Value), 0.0) == 0) /* REF7475 - LJE - 020619 */
                                    )
                {
                    if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                        FREE_DYNST(stratEltTab[i], A_StratElt);
                    continue;
                }

                if (maxWeightNbr > 1 && TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_StratElt_Value), 0.0) == 0) /* REF7475 - LJE - 020619 */
                {
                    if ((sMktSegt = ALLOC_DYNST(S_MktSegt)) == NULLDYNST)
		            {
			            return(RET_SUCCEED);
		            }

                    if ((aMktSegt = ALLOC_DYNST(A_MktSegt)) == NULLDYNST)
		            {
                        FREE_DYNST(sMktSegt,    S_MktSegt);
			            return(RET_SUCCEED);
		            }

                    SET_ID(sMktSegt, S_MktSegt_Id, GET_ID(stratEltTab[i], A_StratElt_MktSegtId));

                    /* get the market segment which id equals the value of the field
                    A_StratElt_MktSegtId of the strategy element */
                    if (DBA_Get2(MktSegt, UNUSED, S_MktSegt, sMktSegt, A_MktSegt, &aMktSegt,
					             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
			        {
				        FREE_DYNST(sMktSegt,    S_MktSegt);
				        FREE_DYNST(aMktSegt, A_MktSegt);
				        return(RET_SUCCEED);
			        }

                    /* eliminate strategy elements associated to a grid */
                    if (IS_NULLFLD(aMktSegt, A_MktSegt_AbcissaListId) && 
                        IS_NULLFLD(aMktSegt, A_MktSegt_OrdinateListId))
                    {
                        if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                            FREE_DYNST(stratEltTab[i], A_StratElt);
                        FREE_DYNST(sMktSegt,    S_MktSegt);
				        FREE_DYNST(aMktSegt, A_MktSegt);
                        continue;
                    }
                    FREE_DYNST(sMktSegt,    S_MktSegt);
				    FREE_DYNST(aMktSegt, A_MktSegt);
                }
                
               if ((GET_DICT(stratEltTab[i], A_StratElt_BenchEntDictId) == stratDictId && anaBenchFlg == FALSE) ||
                    (GET_DICT(stratEltTab[i], A_StratElt_AnaBenchEntDictId) == stratDictId && anaBenchFlg == TRUE))   
                {
					/* REF10822 - RAK - 041215 - Get strategy history only if stratId is specified */
					if ((anaBenchFlg == TRUE && IS_NULLFLD(stratEltTab[i], A_StratElt_AnaBenchObjId) == FALSE) ||
						(anaBenchFlg == FALSE && IS_NULLFLD(stratEltTab[i], A_StratElt_BenchObjId) == FALSE))
					{
						/* REF10822 - RAK - 041215 - Create a sub-function to simplify code */
						if ((ret = FIN_ComputeWeightGetStratAndStratHist(hierHead, stratEltTab[i], 
																		 checkStratFlg, anaBenchFlg, begDate, 
																		 &aStratOut, &stratAllocFlg,
																		 &aStratHistOut, &stratHistAllocFlg)) != RET_SUCCEED)
						{
							FREE(stratHistTab);
							return(ret);
						}

						/* PMSTA07963 - LJE - 090608 */
						if (aStratHistOut != NULL)
						{
						  stratHistId = GET_ID(aStratHistOut, A_StratHist_Id);
					    }
					    else
					    {
						   stratHistId = 0;
						   aStratOut = NULLDYNST;
						   aStratHistOut = NULLDYNST;
						   stratHistAllocFlg = FALSE;
						   stratAllocFlg = FALSE;
					    }
					}
					else
					{
						stratHistId = 0;
						aStratOut = NULLDYNST;
						aStratHistOut = NULLDYNST;
						stratHistAllocFlg = FALSE;
						stratAllocFlg = FALSE;
					}
                    
					/* add the child  */ 
					if ((ret = FIN_AddChildWeight(currentWeight, Strat, 
                                                  stratHistId,
												  aStratOut,
												  stratAllocFlg,  /* REF6025 - CSY - 010607: we don't free if aStratOut comes from hierarchy */
												  aStratHistOut,
												  stratHistAllocFlg,  /* REF6025 - CSY - 010607: we don't free if aStratHistOut comes from hierarchy */
												  stratEltTab[i],
												  stratEltAllocFlg    /* REF6025 - CSY - 010607: we don't free if stratEltTab[i] comes from hierarchy */
												  )) != RET_SUCCEED)
                    {
                        FREE_DYNST(aStratOut, A_Strat);
                        FREE_DYNST(aStratHistOut, A_StratHist);
                        return (ret);
                    }

                    /* the child is a benchmark composite */
                    if ((ret = FIN_ComputeWeight(stratHistId, 
                                                 aStratOut,
												 aStratHistOut,
												 Strat,
												 begDate, 
                                                 returnParamStp, 
                                                 rebalRule,
                                                 contribObjectId, 
                                                 contribRule, 
                                                 priceValRuleId,
                                                 exchValRuleId,
                                                 hierHead,
												 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
                                                 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
												 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
                                                 NULL,
                                                 0,
                                                 TRUE, /* SUPPORT-6697 - LJE - 160609 */
                                                 checkStratFlg,   /* REF6025 - CSY - 010606 */
                                                 anaBenchFlg,    /* REF7422 - CSY - 020605 */
                                                 stratIdTabPtr,  /* REF6025 - CSY - 010607 */
                                                 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
                                                 ESLPtr)) != RET_SUCCEED &&
						ret != RET_GEN_INFO_NODATA)	/* PMSTA07963 - LJE - 090604 */
					{
                        return (ret);
                    }    
                }
                else 
				{
					/*if ((GET_DICT(stratEltTab[i], A_StratElt_BenchEntDictId) == instrDictId && anaBenchFlg == FALSE) ||
                         (GET_DICT(stratEltTab[i], A_StratElt_AnaBenchEntDictId) == instrDictId && anaBenchFlg == TRUE))
                   {*/
                    /* instrument (market segt) of asset allocation
                    get instrument from A_StratElt_BenchObjId */

					/* REF10822 - RAK - 041215 - Only if instrument is specified */
					  /*if ((anaBenchFlg == TRUE && IS_NULLFLD(stratEltTab[i], A_StratElt_AnaBenchObjId) == FALSE) ||*/
					  if((IS_NULLFLD(stratEltTab[i], A_StratElt_BenchObjId) == FALSE) &&
						  (GET_DICT(stratEltTab[i], A_StratElt_BenchEntDictId) == instrDictId))
					  {
					    
						if ((sInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
							MSG_RETURN(RET_MEM_ERR_ALLOC);

						if ((aInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
						{
							FREE_DYNST(sInstr, S_Instr);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

						if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
						{SET_ID(sInstr, S_Instr_Id, 
							GET_ID(stratEltTab[i], A_StratElt_AnaBenchObjId));}  
						else
						{SET_ID(sInstr, S_Instr_Id, 
							GET_ID(stratEltTab[i], A_StratElt_BenchObjId));}  

						if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr,
										    &aInstr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
						{
							MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "Instr", GET_ID(sInstr, S_Instr_Id));	/* PMSTA19028 - DDB - 141031 */
							FREE_DYNST(sInstr, S_Instr);
							FREE_DYNST(aInstr, A_Instr);
							return(RET_DBA_ERR_NODATA);
						}
						FREE_DYNST(sInstr, S_Instr);

						instrId = GET_ID(aInstr, A_Instr_Id);
						addChild = TRUE;
					}
					else
					{
						instrId = 0;
						aInstr = NULLDYNST;
						/*check if Bench with the same DepthLevel present in the STrategy. if yes, add the STratElt*/
						if(IS_NULLFLD(stratEltTab[i], A_StratElt_ParStratEltId) == FALSE)
						{
						  for(k=0; k<stratEltNbr; k++)
						    if((GET_TINYINT(stratEltTab[i], A_StratElt_DepthLevel)== 
							    GET_TINYINT(stratEltTab[k],A_StratElt_DepthLevel)) &&
                                (IS_NULLFLD(stratEltTab[k], A_StratElt_BenchObjId) == FALSE) &&
							    (GET_DICT(stratEltTab[k], A_StratElt_BenchEntDictId) == instrDictId))
						    {
						      addChild = TRUE;
						      break;
						    }
						}
					}
					                        
                    /* add the child  */ 
                    if(addChild == TRUE)
					{
					    if((ret = FIN_AddChildWeight(currentWeight, Instr, /* ou Strat?? */
												  instrId, aInstr,
												  TRUE,
												  NULL,
												  FALSE,
												  stratEltTab[i],
												  stratEltAllocFlg    /* REF6025 - CSY - 010607 */
												  )) != RET_SUCCEED)
                      {
                        FREE_DYNST(aInstr, A_Instr);
                        return (ret);
                      }
					}
                    
					/* REF10822 - RAK - 041215 */
					if (aInstr != NULLDYNST)
					{
						if ((GET_ENUM(aInstr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue)&&
							(GET_ENUM(aInstr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
						{
							/* the child is a benchmark composite */

							/* alloc input structure for select */
							if ((selArg = ALLOC_DYNST(S_InstrCompo)) == NULLDYNST)
							{
								MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_InstrCompo");
								return(RET_MEM_ERR_ALLOC);
							}

							/* set input structure for select  */
							if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
							{SET_ID(selArg, S_InstrCompo_ParentInstrId, 
								GET_ID(stratEltTab[i], A_StratElt_AnaBenchObjId));} /* id of the benchmark */
							else
							{SET_ID(selArg, S_InstrCompo_ParentInstrId, 
								GET_ID(stratEltTab[i], A_StratElt_BenchObjId));} /* id of the benchmark */
							SET_DATETIME(selArg, S_InstrCompo_BeginDate, begDate);

							/* select all the valid instr_compos of the benchmark valid at begDate */
							if ((ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, selArg,
			                          A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
			                          &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
							{
                               FREE(selInstrCompoTab); 
                               FREE_DYNST(selArg, S_InstrCompo);
                               return(RET_SUCCEED);
							}
							FREE_DYNST(selArg, S_InstrCompo);

							/* REF7422 - CSY - 020605 */
							if(anaBenchFlg == TRUE)
							{
								benchId = GET_ID(stratEltTab[i], A_StratElt_AnaBenchObjId);
							}
							else
							{
								benchId = GET_ID(stratEltTab[i], A_StratElt_BenchObjId);
							}

							if ((ret = FIN_ComputeWeight(benchId, 
													 aInstr,
													 NULLDYNST,
													 Instr,
													 begDate, 
													 returnParamStp,
													 rebalRule,
													 contribObjectId, 
													 contribRule, 
													 priceValRuleId,
													 exchValRuleId,
													 hierHead,
													 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
													 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
													 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
													 selInstrCompoTab,
													 selInstrCompoNbr,
                                                     TRUE, /* SUPPORT-6697 - LJE - 160609 */
													 checkStratFlg,   /* REF6025 - CSY - 010606 */
													 anaBenchFlg,    /* REF7422 - CSY - 020605 */
													 stratIdTabPtr,  /* REF6025 - CSY - 010607 */
													 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
													 ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
							{
								FREE(selInstrCompoTab); 
								FREE_DYNST(selArg, S_InstrCompo);
								return (ret);
							}
							FREE(selInstrCompoTab);
						}
                    }

                    if (addChild == FALSE)
                    {
					/* PMSTA06646 - LJE - 080613 */
                        if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
						FREE_DYNST(stratEltTab[i], A_StratElt);

                    }
                }
            }
            else if ((STRATNAT_ENUM)GET_ENUM(aStrat, A_Strat_NatEn) == StratNat_ModelPtf ||
				     (STRATNAT_ENUM)GET_ENUM(aStrat, A_Strat_NatEn) == StratNat_Index)	/* PMSTA01435 - RAK - 070410 */
            {
                /* model portfolio */
                if (IS_NULLFLD(stratEltTab[i], A_StratElt_InstrId) || 
                            GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_ModelPtf &&
                            GET_ENUM(stratEltTab[i], A_StratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_ModelPtfConstWeight)
                {
                    if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                        FREE_DYNST(stratEltTab[i], A_StratElt);
                    continue;
                }

                /* get instrument from  A_StratElt_InstrId */
                if ((sInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
                    MSG_RETURN(RET_MEM_ERR_ALLOC);

		        if ((aInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
                {
                    FREE_DYNST(sInstr, S_Instr);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

		        SET_ID(sInstr, S_Instr_Id, 
                    GET_ID(stratEltTab[i], A_StratElt_InstrId));  

                if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr,
                                   &aInstr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
			        MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "Instr",
                              objId);
                    FREE_DYNST(sInstr, S_Instr);
                    FREE_DYNST(aInstr, A_Instr);
                    return(RET_DBA_ERR_NODATA);
                }
                FREE_DYNST(sInstr, S_Instr);

                /* benchmark composite */
                
                /* add the (composite) child  */ 
                if ((ret = FIN_AddChildWeight(currentWeight,
                    Instr, 
                    GET_ID(aInstr, A_Instr_Id),
                    aInstr,
                    TRUE,
                    NULL,
                    TRUE,
                    stratEltTab[i], 
                    stratEltAllocFlg    /* REF6025 - CSY - 010607: if FALSE, don't free stratEltTab[i] because it comes from hierarchy */
                    )) != RET_SUCCEED)
                {
                    FREE_DYNST(aInstr, A_Instr);
                    return (ret);
                }

                if ((GET_ENUM(aInstr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue)&&
                        (GET_ENUM(aInstr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
                {
                    /* alloc input structure for select */
                    if ((selArg = ALLOC_DYNST(S_InstrCompo)) == NULLDYNST)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_InstrCompo");
                        return(RET_MEM_ERR_ALLOC);
                    }

                    /* set input structure for select  */
                    SET_ID(selArg, S_InstrCompo_ParentInstrId, 
                        GET_ID(stratEltTab[i], A_StratElt_InstrId)); /* id of the benchmark */
                    SET_DATETIME(selArg, S_InstrCompo_BeginDate, begDate);

                    /* select all the valid instr_compos of the benchmark valid at begDate */
		            if ((ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, selArg,
			                      A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
			                      &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
                    {
                           FREE(selInstrCompoTab); 
                           FREE_DYNST(selArg, S_InstrCompo);
                           return(RET_SUCCEED);
                    }
                    FREE_DYNST(selArg, S_InstrCompo);

                    if ((ret = FIN_ComputeWeight(GET_ID(stratEltTab[i], A_StratElt_InstrId), 
												 aInstr,
												 NULLDYNST,
												 Instr,
												 begDate, 
												 returnParamStp, 
												 rebalRule,
												 contribObjectId, 
												 contribRule, 
												 priceValRuleId,
												 exchValRuleId,
												 hierHead,
												 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
												 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
												 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
												 selInstrCompoTab,
												 selInstrCompoNbr,
                                                 TRUE, /* SUPPORT-6697 - LJE - 160609 */
												 checkStratFlg,   /* REF6025 - CSY - 010606 */
												 anaBenchFlg,    /* REF7422 - CSY - 020605 */
		                                         stratIdTabPtr,  /* REF6025 - CSY - 010607 */
												 stratIdNbrPtr,  /* REF6025 - CSY - 010607 */
	                                             ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                    {
                        FREE(selInstrCompoTab); 
                        FREE_DYNST(selArg, S_InstrCompo);
                        return (ret);
                    }
                    FREE(selInstrCompoTab); 
                }
            }
			else
			{
				/* PMSTA06646 - LJE - 080613 */
				if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
					FREE_DYNST(stratEltTab[i], A_StratElt);
			}

        }

        /* REF6025 - CSY - 010723: purify memory leak: because we may have allocated too much in FIN_AddChildWeight */
		/* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
        currentWeight->childWeightTab = (FIN_WEIGHT_STP *) REALLOC(currentWeight->childWeightTab, (currentWeight->childNbr) * sizeof(FIN_WEIGHT_STP));
        
		currentWeight->eltTab = (DBA_DYNFLD_STP *) REALLOC(currentWeight->eltTab, (currentWeight->childNbr) * sizeof(DBA_DYNFLD_STP));

        if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
            FREE(stratEltTab);

    }
    /* REF6025 - CSY - 010718 */
    else if (objectEn == DerivedStrat)
    {
        aStrat = parentPtr; /* derived strategy ! */

        if (checkStratFlg == TRUE)
        {
            /* check if strategy has already been treated: if treated, don't treat it again */
            FLAG_T  foundIdFlg = FALSE;
            int     allocSz = 10;
            for (j=0; j< *stratIdNbrPtr; j++)
            {
                if ((*stratIdTabPtr)[j] == GET_ID(parentPtr, A_DerivedStrat_Id))
                {
                    foundIdFlg = TRUE;
                    break;
                }
            }

            if (foundIdFlg == FALSE)
            {           
                if (*stratIdNbrPtr == 0)
                {
                    *stratIdTabPtr = (ID_T *)CALLOC(allocSz, sizeof(ID_T)); /* REF7264 - LJE - 020131 */
                }
                else if ((*stratIdNbrPtr)%allocSz == 0)
                {
                    allocSz += allocSz;
                    if ((*stratIdTabPtr = (ID_T*) REALLOC(*stratIdTabPtr, 
                        (allocSz*sizeof(ID_T)))) == (ID_T*)NULL)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                }
                /* add the strategy id in the array */
                (*stratIdTabPtr)[*stratIdNbrPtr] = GET_ID(parentPtr, A_DerivedStrat_Id);
                (*stratIdNbrPtr)++;
            }      
        }

        
        /* alloc input structure for select */
        if ((selArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(0);
        }
    
	    SET_ID(selArg, Adm_Arg_Id, objId);  /* objId: id of a derived strategy */

        /* select the derived strategy elements of the given derived strategy id */
	    if ((ret = DBA_Select2(DerivedStratElt, UNUSED, Adm_Arg, selArg, A_DerivedStratElt, &stratEltTab, 
			           UNUSED, UNUSED, &stratEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	    {
		    FREE_DYNST(selArg, Adm_Arg);
		    return(ret);
	    }
	    FREE_DYNST(selArg, Adm_Arg);
        

	    if (stratEltNbr == 0 || stratEltTab == NULL)
            return (RET_GEN_INFO_NODATA); /* ? */ 

        /* compute maxWeight for asset allocation only */
        if (GET_ENUM(aStrat, A_DerivedStrat_NatEn) == (DERIVEDSTRATNAT_ENUM)DerivedStratNat_AssetAlloc)
        {
            int loopNbr = 0;
            while (loopNbr < 2)
            /*  first loop: compute maxWeight 
                second loop: compute maxWeightNbr */
            {
                for (i=0; i < stratEltNbr; i++)
                {
                    
                    if (GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                                (STRATELTNAT_ENUM)StratEltNat_Weight)
                    {
                        continue;
                    }
                    if (loopNbr == 0 &&
                            (maxWeight <  GET_NUMBER(stratEltTab[i], A_DerivedStratElt_Weight)))
                    {
                        maxWeight = GET_NUMBER(stratEltTab[i], A_DerivedStratElt_Weight);
                    }
                    else if (loopNbr == 1 && 
                            (TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_DerivedStratElt_Weight), 0.0) == 0)) /* REF7475 - LJE - 020619 */
                    {
                        maxWeightNbr++;
                    }
                }
                loopNbr++;
            }
        }

        /* loop on the elements to add the childs */
        for (i=0; i < stratEltNbr; i++)
        {
            if (GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_Weight &&
                        GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_ModelPtf &&
                        GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                        (STRATELTNAT_ENUM)StratEltNat_ModelPtfConstWeight)
            {
                if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                    FREE_DYNST(stratEltTab[i], A_DerivedStratElt);
                continue;
            }

            
            if (GET_ENUM(aStrat, A_DerivedStrat_NatEn) == DerivedStratNat_AssetAlloc)
            {
                /* asset allocation */
                if (GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_Weight || 
                            (IS_NULLFLD(stratEltTab[i], A_DerivedStratElt_BenchObjId)) 
                                    || 
                    (IS_NULLFLD(stratEltTab[i], A_DerivedStratElt_BenchEntDictId))
                                    ||
                    (maxWeightNbr == 1 && TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_DerivedStratElt_Weight), 0.0) == 0) /* REF7475 - LJE - 020619 */
                                    )
                {
                    if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                        FREE_DYNST(stratEltTab[i], A_DerivedStratElt);
                    continue;
                }

                if (maxWeightNbr > 1 && TLS_Cmp(maxWeight, GET_NUMBER(stratEltTab[i], A_DerivedStratElt_Weight), 0.0) == 0) /* REF7475 - LJE - 020619 */
                {
                    if ((sMktSegt = ALLOC_DYNST(S_MktSegt)) == NULLDYNST)
		            {
			            return(RET_SUCCEED);
		            }

                    if ((aMktSegt = ALLOC_DYNST(A_MktSegt)) == NULLDYNST)
		            {
                        FREE_DYNST(sMktSegt,    S_MktSegt);
			            return(RET_SUCCEED);
		            }

                    SET_ID(sMktSegt, S_MktSegt_Id, GET_ID(stratEltTab[i], A_DerivedStratElt_MktSgtId));

                    /* get the market segment which id equals the value of the field
                    A_StratElt_MktSegtId of the strategy element */
                    if (DBA_Get2(MktSegt, UNUSED,
					    S_MktSegt, sMktSegt, A_MktSegt, &aMktSegt,
					    UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
			        {
				        FREE_DYNST(sMktSegt,    S_MktSegt);
				        FREE_DYNST(aMktSegt, A_MktSegt);
				        return(RET_SUCCEED);
			        }

                    /* eliminate strategy elements associated to a grid */
                    if (IS_NULLFLD(aMktSegt, A_MktSegt_AbcissaListId) && 
                        IS_NULLFLD(aMktSegt, A_MktSegt_OrdinateListId))
                    {
                        if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                            FREE_DYNST(stratEltTab[i], A_DerivedStratElt);
                        FREE_DYNST(sMktSegt,    S_MktSegt);
				        FREE_DYNST(aMktSegt, A_MktSegt);
                        continue;
                    }
                    FREE_DYNST(sMktSegt,    S_MktSegt);
				    FREE_DYNST(aMktSegt, A_MktSegt);
                }
                
                if (GET_DICT(stratEltTab[i], A_DerivedStratElt_BenchEntDictId) == stratDictId)   
                {
                    
                    if (hierHead != NULL && checkStratFlg == TRUE)
                    {
                        /* extract from hierarchy the strategy which id == bench_object_id */
                        stratNbr = 0;
                        if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
                        {
                            if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
			                                                A_Strat, 
			                                                FALSE,
                                                            FIN_FilterStrat2,   /* filter on A_StratElt_AnaBenchObjId */
                                                            stratEltTab[i],
                                                            NULL,
                                                            &stratNbr,
                                                            &stratTab)) != RET_SUCCEED)
                            {
                                FREE(stratHistTab);
                                return(ret);
                            }
                        }
                        else
                        {
                            if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
			                                                A_Strat, 
			                                                FALSE,
                                                            FIN_FilterStrat,    /* filter on A_StratElt_BenchObjId */
                                                            stratEltTab[i],
                                                            NULL,
                                                            &stratNbr,
                                                            &stratTab)) != RET_SUCCEED)
                            {
                                FREE(stratHistTab);
                                return(ret);
                            }
                        }

                        /* then use extension ptr (A_Strat_A_StratHist_Ext) to get the strategy history */
                        if (stratTab != NULL && stratNbr > 0) 
                        {
                            aStratOut = stratTab[0];
                            if (aStratOut != NULLDYNST)
                            {
                                stratAllocFlg = FALSE;
                                if (GET_EXTENSION_PTR(aStratOut, A_Strat_A_StratHist_Ext) != NULL)
                                {
                                    aStratHistOut = *(GET_EXTENSION_PTR(aStratOut, A_Strat_A_StratHist_Ext));
                                    if (aStratHistOut != NULLDYNST)
                                        stratHistAllocFlg = FALSE;
                                }
                            }
                        }
                    }
                    
                    if (stratHistAllocFlg == TRUE)
                    {
                        /* sub-strategy of asset allocation */
                        if ((getArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
		                {
			                return(RET_SUCCEED);
		                }

                        /* we want the strategy history which strategy_id 
                        is the strategy element bench_object_id, valid at begDate */
                        if ((aStratHistOut = ALLOC_DYNST(A_StratHist)) == NULLDYNST)
	                    {
                            FREE_DYNST(getArg, Adm_Arg);
	   	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		                    return(RET_MEM_ERR_ALLOC);
	                    }

                        SET_ID(getArg, Adm_Arg_Id, 
                            GET_ID(stratEltTab[i], A_DerivedStratElt_BenchObjId));
                        SET_DATETIME(getArg, Adm_Arg_Date, begDate);

                        /* get the strategy history of the (sub) strategy at begDate */
                        if (DBA_Get2(StratHist, DBA_ROLE_GET_LAST_STRAT_HIST,
					        Adm_Arg, getArg, A_StratHist, &aStratHistOut,
					        UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
			            {
				            FREE_DYNST(getArg,    Adm_Arg);
				            FREE_DYNST(aStratHistOut, A_StratHist);
				            return(RET_SUCCEED);
			            }
    		            FREE_DYNST(getArg,    Adm_Arg);
                    }

                    if (stratAllocFlg == TRUE)
                    {

                        /* get the strategy which id is the strategy element bench_object_id */
                        if ((aStratOut = ALLOC_DYNST(A_Strat)) == NULLDYNST)
	                    {
	   	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		                    return(RET_MEM_ERR_ALLOC);
	                    }

	                    if ((getStratPtr = ALLOC_DYNST(S_Strat)) == NULLDYNST)
	                    {
		                    FREE_DYNST(aStratOut, A_Strat);
	   	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		                    return(RET_MEM_ERR_ALLOC);
	                    }

	                    SET_ID(getStratPtr, S_Strat_Id, 
                            GET_ID(stratEltTab[i], A_DerivedStratElt_BenchObjId));

	                    if (DBA_Get2(Strat, UNUSED, S_Strat, getStratPtr, 
		                         A_Strat, &aStratOut, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	                    {
		                    FREE_DYNST(aStratOut, A_Strat);
		                    FREE_DYNST(getStratPtr, S_Strat);
		                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ComputeWeight", "identifier");
		                    return(RET_MEM_ERR_ALLOC);
	                    }
	                    FREE_DYNST(getStratPtr, S_Strat);

                    }                                        
                    
                    /* add the child  */ 
                    if ((ret = FIN_AddChildWeight(currentWeight, Strat, 
                                        GET_ID(aStratHistOut, A_StratHist_Id),
                                        aStratOut,
                                        stratAllocFlg,  
                                        aStratHistOut,
                                        stratHistAllocFlg,  
                                        stratEltTab[i],
                                        stratEltAllocFlg    
                                        )) != RET_SUCCEED)
                    {
                        FREE_DYNST(aStratOut, A_Strat);
                        FREE_DYNST(aStratHistOut, A_StratHist);
                        return (ret);
                    }

                    /* the child is a benchmark composite */
                    if ((ret = FIN_ComputeWeight(GET_ID(aStratHistOut, A_StratHist_Id), 
                                                 aStratOut,
												 aStratHistOut,
												 Strat,
												 begDate, 
                                                 returnParamStp, 
                                                 rebalRule,
                                                 contribObjectId, 
                                                 contribRule, 
                                                 priceValRuleId,
                                                 exchValRuleId,
                                                 hierHead,
												 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
												 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
                                                 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
                                                 NULL,
                                                 0,
                                                 TRUE, /* SUPPORT-6697 - LJE - 160609 */
                                                 checkStratFlg,  
                                                 anaBenchFlg,    /* REF7422 - CSY - 020605 */
                                                 stratIdTabPtr,  
                                                 stratIdNbrPtr,
                                                 ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                    { 
                        return (ret);
                    }    
                }
                else if (GET_DICT(stratEltTab[i], A_DerivedStratElt_BenchEntDictId) == instrDictId)
                {
                    /* instrument (market segt) of asset allocation
                    get instrument from A_StratElt_BenchObjId */
                    if ((sInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
                        MSG_RETURN(RET_MEM_ERR_ALLOC);

		            if ((aInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
                    {
                        FREE_DYNST(sInstr, S_Instr);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    
		            SET_ID(sInstr, S_Instr_Id, 
                        GET_ID(stratEltTab[i], A_DerivedStratElt_BenchObjId));  
                    

                    if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr,
                                       &aInstr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                    {
			            MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "Instr",
                                  objId);
                        FREE_DYNST(sInstr, S_Instr);
                        FREE_DYNST(aInstr, A_Instr);
                        return(RET_DBA_ERR_NODATA);
                    }
                    FREE_DYNST(sInstr, S_Instr);    
                    
                    /* add the child  */ 
                    if ((ret = FIN_AddChildWeight(currentWeight, Instr, 
                                    GET_ID(aInstr, A_Instr_Id),
                                    aInstr,
                                    TRUE,
                                    NULL,
                                    FALSE,
                                    stratEltTab[i],
                                    stratEltAllocFlg   
                                    )) != RET_SUCCEED)
                    {
                        FREE_DYNST(aInstr, A_Instr);
                        return (ret);
                    }

                    
                    if ((GET_ENUM(aInstr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue)&&
                        (GET_ENUM(aInstr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
                    {
                        /* the child is a benchmark composite */

                        /* alloc input structure for select */
                        if ((selArg = ALLOC_DYNST(S_InstrCompo)) == NULLDYNST)
                        {
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_InstrCompo");
                            return(RET_MEM_ERR_ALLOC);
                        }

                        /* set input structure for select  */
                        SET_ID(selArg, S_InstrCompo_ParentInstrId, 
                            GET_ID(stratEltTab[i], A_DerivedStratElt_BenchObjId)); 
                        SET_DATETIME(selArg, S_InstrCompo_BeginDate, begDate);

                        /* select all the valid instr_compos of the benchmark valid at begDate */
		                if ((ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, selArg,
			                          A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
			                          &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
                        {
                               FREE(selInstrCompoTab); 
                               FREE_DYNST(selArg, S_InstrCompo);
                               return(RET_SUCCEED);
                        }
                        FREE_DYNST(selArg, S_InstrCompo);

                        if ((ret = FIN_ComputeWeight(GET_ID(stratEltTab[i], A_DerivedStratElt_BenchObjId), 
													 aInstr, NULLDYNST, 
													 Instr, begDate, 
													 returnParamStp, rebalRule, contribObjectId, 
	                                                 contribRule, 
													 priceValRuleId,
													 exchValRuleId,
													 hierHead,
													 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
													 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
													 currentWeight->childWeightTab[(currentWeight->childNbr)-1],
													 selInstrCompoTab,
													 selInstrCompoNbr,
                                                     TRUE, /* SUPPORT-6697 - LJE - 160609 */
													 checkStratFlg,  
													 anaBenchFlg,    /* REF7422 - CSY - 020605 */
													 stratIdTabPtr,  
													 stratIdNbrPtr, 
													 ESLPtr)) != RET_SUCCEED)
                        {
                            FREE(selInstrCompoTab); 
                            FREE_DYNST(selArg, S_InstrCompo);
                            return (ret);
                        }
                        FREE(selInstrCompoTab);
                    }
                }
            }
            else if (GET_ENUM(aStrat, A_DerivedStrat_NatEn) == DerivedStratNat_ModelPtf)
            {
                /* model portfolio */
                if (IS_NULLFLD(stratEltTab[i], A_DerivedStratElt_InstrId) || 
                            GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_ModelPtf &&
                            GET_ENUM(stratEltTab[i], A_DerivedStratElt_NatEn) != 
                            (STRATELTNAT_ENUM)StratEltNat_ModelPtfConstWeight)
                {
                    if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
                        FREE_DYNST(stratEltTab[i], A_DerivedStratElt);
                    continue;
                }

                /* get instrument from  A_StratElt_InstrId */
                if ((sInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
                    MSG_RETURN(RET_MEM_ERR_ALLOC);

		        if ((aInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
                {
                    FREE_DYNST(sInstr, S_Instr);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

		        SET_ID(sInstr, S_Instr_Id, 
                    GET_ID(stratEltTab[i], A_DerivedStratElt_InstrId));  

                if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr,
                                   &aInstr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
			        MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "Instr",
                              objId);
                    FREE_DYNST(sInstr, S_Instr);
                    FREE_DYNST(aInstr, A_Instr);
                    return(RET_DBA_ERR_NODATA);
                }
                FREE_DYNST(sInstr, S_Instr);

                /* benchmark composite */
                
                /* add the (composite) child  */ 
                if ((ret = FIN_AddChildWeight(currentWeight,
                    Instr, 
                    GET_ID(aInstr, A_Instr_Id),
                    aInstr,
                    TRUE,
                    NULL,
                    TRUE,
                    stratEltTab[i], 
                    stratEltAllocFlg    
                    )) != RET_SUCCEED)
                {
                    FREE_DYNST(aInstr, A_Instr);
                    return (ret);
                }

                if ((GET_ENUM(aInstr, A_Instr_IdxCalcRuleEn) == (ENUM_T)IdxCalcRule_PctValue)&&
                        (GET_ENUM(aInstr, A_Instr_ValRuleEn) == (ENUM_T)ValRule_Composite))
                {
                    /* alloc input structure for select */
                    if ((selArg = ALLOC_DYNST(S_InstrCompo)) == NULLDYNST)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_InstrCompo");
                        return(RET_MEM_ERR_ALLOC);
                    }

                    /* set input structure for select  */
                    SET_ID(selArg, S_InstrCompo_ParentInstrId, 
                        GET_ID(stratEltTab[i], A_DerivedStratElt_InstrId)); 
                    SET_DATETIME(selArg, S_InstrCompo_BeginDate, begDate);

                    /* select all the valid instr_compos of the benchmark valid at begDate */
		            if ((ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, selArg,
			                      A_InstrCompo, &selInstrCompoTab, UNUSED, UNUSED, 
			                      &selInstrCompoNbr, UNUSED, UNUSED))!=RET_SUCCEED)
                    {
                           FREE(selInstrCompoTab); 
                           FREE_DYNST(selArg, S_InstrCompo);
                           return(RET_SUCCEED);
                    }
                    FREE_DYNST(selArg, S_InstrCompo);

                    if ((ret = FIN_ComputeWeight(GET_ID(stratEltTab[i], A_DerivedStratElt_InstrId), 
												 aInstr,
												 NULLDYNST,
												 Instr,
												 begDate, 
												 returnParamStp, 
												 rebalRule,
												 contribObjectId, 
												 contribRule, 
												 priceValRuleId,
												 exchValRuleId,
												 hierHead,
												 /* REF9071 - RAK - 030819 - childWeightTab is now a FIN_WEIGHT_STP* */
												 /* &(currentWeight->childWeightTab[(currentWeight->childNbr)-1]) */
	                                             currentWeight->childWeightTab[(currentWeight->childNbr)-1],
												 selInstrCompoTab,
												 selInstrCompoNbr,
                                                 TRUE, /* SUPPORT-6697 - LJE - 160609 */
												 checkStratFlg,  
												 anaBenchFlg,    /* REF7422 - CSY - 020605 */
												 stratIdTabPtr,  
												 stratIdNbrPtr,  
												 ESLPtr)) != RET_SUCCEED)	/* REF10274 - RAK - 040506 */
                    {
                        FREE(selInstrCompoTab); 
                        FREE_DYNST(selArg, S_InstrCompo);
                        return (ret);
                    }
                    FREE(selInstrCompoTab); 
                }
            }
        }
        if (checkStratFlg == FALSE || stratEltAllocFlg == TRUE)
            FREE(stratEltTab);
    }

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_ComputeWeightGetStratAndStratHist()
**
**  Description :   Compute the valid weights of a benchmark for a given period
**                 
**  Arguments   :   
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	REF10822 - RAK - 041215       
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeWeightGetStratAndStratHist(DBA_HIER_HEAD_STP	hierHead, 
													  DBA_DYNFLD_STP	stratEltPtr, 
													  FLAG_T			checkStratFlg,
													  FLAG_T			anaBenchFlg,
													  DATETIME_T		begDate,
													  DBA_DYNFLD_STP	*aStratOutPtr,
													  FLAG_T			*stratAllocFlg,
													  DBA_DYNFLD_STP	*aStratHistOutPtr,
													  FLAG_T			*stratHistAllocFlg) 
{
	int				stratNbr=0;
	DBA_DYNFLD_STP	*stratTab=NULLDYNSTPTR, getArg=NULLDYNST;
	RET_CODE		ret=RET_SUCCEED;

	*stratHistAllocFlg = TRUE;
	*stratAllocFlg = TRUE;

	if (hierHead != NULL && checkStratFlg == TRUE)
	{
		/* extract from hierarchy the strategy which id == bench_object_id */
		if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
		{
			ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
			                                        A_Strat, 
			                                        FALSE,
                                                    FIN_FilterStrat2,/* filter on A_StratElt_AnaBenchObjId */
                                                    stratEltPtr,
                                                    NULL,
                                                    &stratNbr,
                                                    &stratTab);	
		}
		else
		{
             ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
			                                         A_Strat, 
			                                         FALSE,
                                                     FIN_FilterStrat,    /* filter on A_StratElt_BenchObjId */
                                                     stratEltPtr,
                                                     NULL,
                                                     &stratNbr,
                                                     &stratTab);
		}

		if (ret != RET_SUCCEED)
		{
			return(ret);
		}

        /* then use extension ptr (A_Strat_A_StratHist_Ext) to get the strategy history */
        if (stratTab != NULL && stratNbr > 0) 
        {
			*aStratOutPtr = stratTab[0];
            if ((*aStratOutPtr) != NULLDYNST)
            {
				*stratAllocFlg = FALSE;
                if (GET_EXTENSION_PTR((*aStratOutPtr), A_Strat_A_StratHist_Ext) != NULL)
                {
					*aStratHistOutPtr = *(GET_EXTENSION_PTR((*aStratOutPtr), A_Strat_A_StratHist_Ext));
                    if ((*aStratHistOutPtr) != NULLDYNST)
						*stratHistAllocFlg = FALSE;
				}
			}
		}

        FREE(stratTab); /* REF6025 - CSY - 010720: purify */
	}

	/* not found in hierarchy (or not searched) */
	if ((*stratHistAllocFlg) == TRUE)
    {
		/* sub-strategy of asset allocation */
        if ((getArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
		{
			return(RET_SUCCEED);
		}

        /* we want the strategy history which strategy_id 
           is the strategy element bench_object_id, valid at begDate */
        if (((*aStratHistOutPtr) = ALLOC_DYNST(A_StratHist)) == NULLDYNST)
	    {
			FREE_DYNST(getArg, Adm_Arg);
	   	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

        if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
        {
			SET_ID(getArg, Adm_Arg_Id, GET_ID(stratEltPtr, A_StratElt_AnaBenchObjId));
		}
        else
        {
			SET_ID(getArg, Adm_Arg_Id, GET_ID(stratEltPtr, A_StratElt_BenchObjId));
		}

        SET_DATETIME(getArg, Adm_Arg_Date, begDate);

        /* get the strategy history of the (sub) strategy at begDate */
        if (DBA_Get2(StratHist, DBA_ROLE_GET_LAST_STRAT_HIST,
					 Adm_Arg, getArg, A_StratHist, aStratHistOutPtr,
					 UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		{
			FREE_DYNST(getArg, Adm_Arg);
			FREE_DYNST((*aStratHistOutPtr), A_StratHist);
			return(RET_SUCCEED);
		}

    	FREE_DYNST(getArg, Adm_Arg);
	}

    if ((*stratAllocFlg) == TRUE)
    {
		/* get the strategy which id is the strategy element bench_object_id */
		if (((*aStratOutPtr) = ALLOC_DYNST(A_Strat)) == NULLDYNST)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
		}

	    if ((getArg = ALLOC_DYNST(S_Strat)) == NULLDYNST)
	    {
			FREE_DYNST((*aStratOutPtr), A_Strat);
	   	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

        if(anaBenchFlg == TRUE) /* REF7422 - CSY - 020605 */
        {
			SET_ID(getArg, S_Strat_Id, GET_ID(stratEltPtr, A_StratElt_AnaBenchObjId));
		}
        else
        {
			SET_ID(getArg, S_Strat_Id, GET_ID(stratEltPtr, A_StratElt_BenchObjId));
		}

	    if (DBA_Get2(Strat, UNUSED, S_Strat, getArg, 
		             A_Strat, aStratOutPtr, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	    {
			FREE_DYNST((*aStratOutPtr), A_Strat);
		    FREE_DYNST(getArg, S_Strat);
		    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ComputeWeight", "identifier");
		    return(RET_MEM_ERR_ALLOC);
	    }

	    FREE_DYNST(getArg, S_Strat);
	}  
	
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterStratWithMktSgtOfElt()
**
**  Description :   filter strategy with parent market segment = to element market segment
**                 
**  Rem			:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**					paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REFX - RAK - 040505
**
*************************************************************************/
STATIC int FIN_FilterStratWithMktSgtOfElt(DBA_DYNFLD_STP dynSt, 
										  DBA_DYNST_ENUM dynStTp, 
										  DBA_DYNFLD_STP paramSt)
{
    if (GET_ID(dynSt, ExtStratLnk_MktSegId) == GET_ID(paramSt, Get_Arg_Id) &&			/* A_StratElt_MktSegtId */ 
		GET_ID(dynSt, ExtStratLnk_RefStratId) == GET_ID(paramSt, Get_Arg_RefCurrId))	/* ExtStratLnk_RefStratId */
	    return(TRUE);
    else 
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterStrat()
**
**  Description :   filter strategy by strategy_id == the given id (contained
**                  in A_StratElt_BenchObjId)
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		    paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF6025 - CSY - 010606
**
*************************************************************************/
int FIN_FilterStrat(DBA_DYNFLD_STP dynSt, 
		       DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    
    if (GET_ID(dynSt, A_Strat_Id) == GET_ID(paramSt, A_StratElt_BenchObjId)) 
	    return(TRUE);
    else 
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterStrat2()
**
**  Description :   filter strategy by strategy_id == the given id (contained
**                  in A_StratElt_AnaBenchObjId)
**                  analog to FIN_FilterStrat, but use A_StratElt_AnaBenchObjId
**                  instead of A_StratElt_BenchObjId
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		    paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF7422 - CSY - 020605
**
*************************************************************************/
int FIN_FilterStrat2(DBA_DYNFLD_STP dynSt, 
		       DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    
    if (GET_ID(dynSt, A_Strat_Id) == GET_ID(paramSt, A_StratElt_AnaBenchObjId)) 
	    return(TRUE);
    else 
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_PeriodIncEvt()
**
**  Description :   Compute period income event value
**                 
**  Arguments   :   inc      income event
**                  begDate  begin date
**                  endDate  end date
**                  incValPtr total value from income
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   REF1079 - RAK - 971219
**
*************************************************************************/
STATIC RET_CODE FIN_PeriodIncEvt(DBA_DYNFLD_STP   inc, 
                                 DBA_DYNFLD_STP   instrPtr,
								 ID_T			  wrkCurrId,
								 ID_T			  exchValRuleId,
								 FIN_EXCHARG_STP  exchArgStp,
                                 DBA_DYNFLD_STP   unitInterPtr,
				 				 DATETIME_T       fromDate, 
				 			     DATETIME_T       tillDate, 
				                 NUMBER_T         incGainTax,
				                 double           *incValPtr,
								 FLAG_T			  incDateFlg,
								 std::set<DATE_T> & incDateSet,               /* PMSTA-47762 - JBC - 220131 */
                                 DBA_HIER_HEAD_STP hierHead)
{
	DATETIME_T      begDate, endDate, firstCoupDate;
	double          freq;
	char            lastPay;
	EXCHANGE_T		exch=1-0;
	NUMBER_T		rate=0.0, unpaidPrct=0.0;
	double			incVal;

	/* Income event must be in report period */
	if (GET_DATE(inc, A_IncEvt_LastPayDate) < fromDate.date)
		return(RET_SUCCEED);

	FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(inc, A_IncEvt_PayFreqUnitEn), /* REF7264 - CSY - 020130 */
			          GET_TINYINT(inc, A_IncEvt_PayFreq), FreqUnit_Month, &freq);

	begDate.date  = GET_DATE(inc, A_IncEvt_BeginDate);
	endDate.date  = GET_DATE(inc, A_IncEvt_BeginDate);
	firstCoupDate = GET_DATETIME(inc, A_IncEvt_FirstCoupDate);

	if (endDate.date == BAD_DATE)
	{
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_PeriodIncEvt", GET_CODE(instrPtr, A_Instr_Cd), "end date");
		return(RET_FIN_ERR_INVDATA);
	}

	/* Advance in repetitiv event until begin date */
	lastPay = 0;
	if ((int) freq == 0)	/* PMSTA-11143 - RAK - 101220 - exception in case of ne frequency */
	{
		/* First coupon date can be 0 */
		if (firstCoupDate.date > begDate.date)
			endDate.date = firstCoupDate.date;
		else 
		{
			endDate.date = GET_DATE(inc, A_IncEvt_LastPayDate);
		}
	}
	else
	{
		/* PMSTA01815-CHU-070723 : include fromDate in this condition */
		/* while (endDate.date < fromDate.date && lastPay < 2) */
		while (endDate.date < fromDate.date && lastPay < 2) /* PMSTA-15473 - LJE - 121123 - rechange <= by < */
		{
			begDate = endDate;

		/* First coupon date can be 0 */
			if (firstCoupDate.date > begDate.date)
				endDate.date = firstCoupDate.date;
			else 
			{
			    if (freq == 0)  /* No repetitive event */
				endDate.date = GET_DATE(inc, A_IncEvt_LastPayDate);
			    else
				endDate.date = DATE_Move(begDate.date, (int)freq, Month);
			}
	
			/* Force last payment date */
			if (IS_NULLFLD(inc, A_IncEvt_LastPayDate) == FALSE &&
			    GET_DATE(inc, A_IncEvt_LastPayDate) < endDate.date)
			{
				endDate.date = GET_DATE(inc, A_IncEvt_LastPayDate);
				++lastPay;
			}
		}
	}

	/* For each period in current income event */
	/* (one in case of no repetitive event)    */
	if (IS_NULLFLD(inc, A_IncEvt_LastPayDate) == TRUE)
	{
		SET_DATE(inc, A_IncEvt_LastPayDate, tillDate.date);
	}

	lastPay = 0;
	while (endDate.date <= GET_DATE(inc, A_IncEvt_LastPayDate) &&
	       endDate.date <= tillDate.date && lastPay < 2)
	{
	    if ((FIN_PeriodUnitAccrInter(instrPtr, begDate.date, endDate.date, 	/* REF1079 */
					                 (PERCENT_T *)NULL, inc, AccrRule_None,	 /* REF11218 - TEB - 050627 */
					                 unitInterPtr, hierHead, NULL)) != RET_SUCCEED)
	    {
		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			                 "FIN_PeriodIncEvt", GET_CODE(instrPtr, A_Instr_Cd), "interest");
		        return(RET_FIN_ERR_INVDATA);
	    } 

	
		/* PMSTA-10527 - RAK - 101021 */
		if (GET_ID(unitInterPtr, UnitInter_CurrId) != wrkCurrId)
		{
		
			FIN_GetExchRate(endDate, GET_ID(unitInterPtr, UnitInter_CurrId), wrkCurrId, 
					        exchValRuleId, 
                            NULLDYNST, NULLDYNST, exchArgStp, &exch);
		}
		else
			exch = 1.0;

		/* PMSTA-10527 - RAK - 101021 - treat PartiallyPaidBonds */
		rate = GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter);

		if ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_PartiallyPaidBonds)
		{
			
			if (FIN_GetChronoNatUnpPrct(instrPtr, &unpaidPrct, endDate, hierHead) == RET_SUCCEED)
			{
				rate = rate * (100 - unpaidPrct) / 100; 
			}
		}

		/* REF4180 - LJE - 020701 : Remove factor 100 and add income gain taxe effect */
	    incVal = ((rate * (1-incGainTax/100)) * exch);
	    *incValPtr += incVal;
		
		/* PMSTA-11143 - RAK - 101220 - update array with each income date */
		if (incDateFlg == TRUE)
		{
            incDateSet.insert(endDate.date);
		}

	    /* Go on next period */
	    begDate = endDate;

	    if (firstCoupDate.date > begDate.date)
		    endDate.date = firstCoupDate.date;
	    else 
	    {
		    if (freq == 0)     /* No repetitive event, stop */
		        endDate.date = DATE_Move(endDate.date, 1, Day); 
		    else
		        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
	    }

	    /* If next payment is last payment, create income */
	    /* on last payment date and stop after.           */
	    if (IS_NULLFLD(inc, A_IncEvt_LastPayDate) == FALSE &&
		    GET_DATE(inc, A_IncEvt_LastPayDate) <= endDate.date)
	    {
		    endDate.date = GET_DATE(inc, A_IncEvt_LastPayDate);
		    ++lastPay; /* If 2, stop */
	    }
	}
	return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   FIN_PeriodIncEvtInstrFlow()
**
**  Description :   Compute period income event value by calling 
**                  FIN_GenerateInstrFlows() function. 
**                  Currently this function is called when new accrual rule
**                  is used.
**                 
**  Arguments   :   instrPtr    pointer on instrument
**                  fromDate    from date
**                  tillDate    till date
**                  incGainTax  income gain tax 
**                  incValPtr   total value from income
**                  hierHead    pointer on hierarchy
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9085 - YST - 030630
**
**  Modif.      :   REF11218 - TEB - 050627
**
*************************************************************************/
STATIC RET_CODE FIN_PeriodIncEvtInstrFlow(DBA_DYNFLD_STP    instrPtr,
										  ID_T				wrkCurrId,
										  ID_T				exchValRuleId,
										  FIN_EXCHARG_STP	exchArgStp,
										  DATETIME_T        fromDate, 
										  DATETIME_T        tillDate, 
									      NUMBER_T          incGainTax,
										  double            *incValPtr,
										  FLAG_T			incDateFlg,		/* PMSTA-11143 - RAK - 101220 */
										  std::set<DATE_T> & incDateSet,    /* PMSTA-47762 - JBC - 220131 */
									      DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  *flowTab = NULL;
    ENUMMASK_T          mask = 0;
    int             i = 0, flowNbr = 0;
	EXCHANGE_T		exch;
	double			incVal;
    *incValPtr = 0.0;
    
    SET_BIT64(mask, FlowSubNat_Any, TRUE);

	/* PMSTA-9942 - RAK - 100525 - Keep only flow on the till date */
    /* PMSTA-11287 - RAK - 110310 - remove PMSTA-9942 correction but use PMSTA-11143 correction */								   
    retCd = FIN_GenerateInstrFlows(/* PMSTA-11287 tillDate, tillDate, tillDate, */
								   fromDate, tillDate, tillDate, /* PMSTA-12867 - LJE - 111005 - Use tillDate as valditiy date */
								   FALSE,	/* PMSTA-9032 - RAK - 091216 */
								   GET_ID(instrPtr, A_Instr_Id), instrPtr, 
								   mask, EvtGen_Automatic, EvtDateRule_Term, TRUE, 
								   GenInstrFlow_InstrFlow, (ACCRRULE_ENUM) AccrRule_None, /* REF11218 - TEB - 050627 */
								   &flowTab, &flowNbr, hierHead);

    if (retCd == RET_SUCCEED || retCd == RET_FIN_ERR_SCE_ZEROFLOW)
    {
        retCd = RET_SUCCEED;

        for (i=0; i<flowNbr; i++)
        {
			if ((FLOWNAT_ENUM)GET_ENUM(flowTab[i], Flow_NatEn) == FlowNat_Inc)
			{
				/* PMSTA-10527 - RAK - 101021 */
				if (GET_ID(flowTab[i], Flow_AmtCurrId) != wrkCurrId)
				{
					FIN_GetExchRate(GET_DATETIME(flowTab[i], Flow_EndPayDate),
						            GET_ID(flowTab[i], Flow_AmtCurrId), wrkCurrId, 
									exchValRuleId,
									NULLDYNST, NULLDYNST, exchArgStp, &exch);
				}
				else
					exch = 1.0;

				/* PMSTA-11143 - RAK - 101220 - use tmp variable */
				/* PMSTA-9942 - RAK - 110103 - Error with the report : use AmtUnit and no more Quote */
				incVal = ((GET_PRICE(flowTab[i], Flow_AmtUnit) * (1.0-incGainTax/100.0)) * exch);

				*incValPtr += incVal;

				/* PMSTA-11143 - RAK - 101220 - update array with each income and date*/
				if (incDateFlg == TRUE)
				{
                    DATETIME_T flowEndDate = GET_DATETIME(flowTab[i], Flow_EndPayDate);
                    incDateSet.insert(flowEndDate.date);
				}
			}
        }
    }

	/* PMSTA-15913 - DDV - 130207 - Purify */
	if (flowNbr > 0)
		DBA_FreeDynStTab(flowTab, flowNbr, Flow);

    return(retCd);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynth()
**
**  Description :   Keep valid synthetic data depending on risk flag, period and dimension.
**                  (period is delimited by from and till date, dimension is 
**		     defined by portfolio, grid, market segment, instrument.)
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		    paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF385 - RAK - 971001
**
*************************************************************************/
int FIN_FilterPtfSynth(DBA_DYNFLD_STP dynSt, 
		       DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    /* REF7634 - LJE - 020613 : Dont get the no-primary ptf synth */
	if(	IS_NULLFLD(dynSt, A_PtfSynth_Level) == FALSE &&
		GET_TINYINT(dynSt, A_PtfSynth_Level) != 0 && 
		GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Primary) == FALSE)
	{
		return(FALSE);
	}

    /* PMSTA-9378 - RAK - 100422 - keep all created synthetics */
	/* if (GET_FLAG(paramSt, MeanCapReturn_Arg_RiskFlg) == TRUE)
    {								/-* Eliminate no risk records *-/
        if (GET_ENUM(dynSt, A_PtfSynth_RiskNatEn) == ExtPosRisk_NoRisk)
		return(FALSE);			
    }
    else
    {								/-* Eliminate risk records *-/
        if (GET_ENUM(dynSt, A_PtfSynth_RiskNatEn) != ExtPosRisk_NoRisk)
		return(FALSE);
    } */

    /* Search valid synthetic data depending on period (delimited by from and till date) */
    /* and portfolio, grid, market segment, instrument.                                  */
    /* grid, market segment, instrument are NULL (0) in case of global return            */
    /* instrument is NULL (0) in case of grid or global return                           */
    if (GET_ID(dynSt, A_PtfSynth_PtfId)     == GET_ID(paramSt, MeanCapReturn_Arg_PtfId)    &&
        GET_ID(dynSt, A_PtfSynth_GridId)    == GET_ID(paramSt, MeanCapReturn_Arg_GridId)   && 
        GET_ID(dynSt, A_PtfSynth_MktSegtId) == GET_ID(paramSt, MeanCapReturn_Arg_MktSgtId) &&
        GET_ID(dynSt, A_PtfSynth_InstrId)   == GET_ID(paramSt, MeanCapReturn_Arg_InstrId)  &&
        GET_ID(dynSt, A_PtfSynth_PSPId)     == GET_ID(paramSt, MeanCapReturn_Arg_PSPId)    && /* REF9264 - LJE - 031021 */
	    DATETIME_CMP(GET_DATETIME(dynSt, A_PtfSynth_InitialDate), 
		             GET_DATETIME(paramSt, MeanCapReturn_Arg_FromDate)) >=0 &&
	    DATETIME_CMP(GET_DATETIME(dynSt, A_PtfSynth_FinalDate), 
		             GET_DATETIME(paramSt, MeanCapReturn_Arg_TillDate)) <=0)
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}
}

/************************************************************************
**
**  Function    :   FIN_FilterGlobalPtfSynth()
**
**  Description :   Keep gblobal valid synthetic data depending on risk flag, 
**                  period and dimension.
**                  (period is delimited by from and till date, dimension is 
**		            defined by portfolio, grid, market segment, instrument.)
**                 
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF7634 - LJE - 020619
**
*************************************************************************/
int FIN_FilterGlobalPtfSynth(DBA_DYNFLD_STP dynSt, 
							 DBA_DYNST_ENUM dynStTp,
							 DBA_DYNFLD_STP paramSt)
{
    /* REF7634 - LJE - 021014 : Dont get the no-primary ptf synth */
	if(	IS_NULLFLD(dynSt, A_PtfSynth_Level) == FALSE &&
		GET_TINYINT(dynSt, A_PtfSynth_Level) != 0 && 
		GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Primary) == FALSE)
	{
		return(FALSE);
	}

    /* REF9264 - LJE - 031021 : Test perf_storage_param_id too */
    if (CMP_DYNFLD(dynSt, paramSt, A_PtfSynth_PSPId, A_PtfSynth_PSPId, IdType) != 0)
    {
        return (FALSE);
    }

    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(paramSt, A_PtfSynth_PtfId)  &&
        (IS_NULLFLD(dynSt, A_PtfSynth_GridId)   == TRUE ||
		 GET_ID(dynSt, A_PtfSynth_GridId)    == GET_ID(paramSt, A_PtfSynth_GridId)) &&
		IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_InstrId)   == TRUE &&
	    DATETIME_CMP(GET_DATETIME(dynSt, A_PtfSynth_InitialDate), 
		             GET_DATETIME(paramSt, A_PtfSynth_InitialDate)) >= 0 &&
	    DATETIME_CMP(GET_DATETIME(dynSt, A_PtfSynth_FinalDate), 
		             GET_DATETIME(paramSt, A_PtfSynth_FinalDate)) <= 0)
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}
}


/************************************************************************
**
**  Function    :   FIN_CmpReturnPtfSynth()
**
**  Description :   Ptf synthetic data order by portfolio and validity date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Modif       :   DVP165 - RAK - 960730
**  Modif       :   DVP232 - RAK - 961112
**
*************************************************************************/
int FIN_CmpReturnPtfSynth(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* DVP232 - MktSegtId and GridId are set to 0 if no grid is used */
	    /* Grid */
	    if (GET_ID((*ptr1), A_PtfSynth_GridId) == GET_ID((*ptr2), A_PtfSynth_GridId))
	    {
	        /* Market segment */
	        if (GET_ID((*ptr1), A_PtfSynth_MktSegtId) == GET_ID((*ptr2), A_PtfSynth_MktSegtId))
	        {
	    	    /* DVP165 For non-detailled data, A_PtfSynth_InstrId is set to 0 */
		        /* Instrument */
	    	    if (GET_ID((*ptr1), A_PtfSynth_InstrId) == GET_ID((*ptr2), A_PtfSynth_InstrId))
	    	    {
		            /* Validity date */
		            return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_FinalDate),
		                                GET_DATETIME((*ptr2), A_PtfSynth_FinalDate)));
	    	    }
	    	    else
	    	    {
	    	        /* Instrument identifier aren't same */
	    	        return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_InstrId),
			               GET_ID((*ptr2), A_PtfSynth_InstrId))); /* DLA - REF9089 - 030508 */
	    	    }
	        }
	        else
	        {
	  	        /* Market segment identifier aren't same */
		        return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_MktSegtId),
			           GET_ID((*ptr2), A_PtfSynth_MktSegtId))); /* DLA - REF9089 - 030508 */
	        }
	    }
	    else
	    {
		    /* Grid identifier aren't same */
		    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_GridId) , GET_ID((*ptr2), A_PtfSynth_GridId))); /* DLA - REF9089 - 030508 */
	    }
	}
	else
	{
	    /* Portfolio identifier aren't same */
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynth()
**
**  Description :   Ptf synthetic data order by portfolio and validity date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Modif       :   DVP165 - RAK - 960823
**  Modif       :   DVP172 - RAK - 961008
**
*************************************************************************/
STATIC int FIN_CmpPtfSynth(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Validity date */
	    return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_FinalDate),
		                GET_DATETIME((*ptr2), A_PtfSynth_FinalDate)));
	}
	else
	{
	    /* Portfolio identifier aren't same */
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_ComputeBookValue()
**
**  Description :   Compute book value for position using evaluation rule enum 
**                  and maximum constraint.
**
**  Arguments   :   extPosPtr      allocated pointer on position
**                  lastBVPtrInput allocated pointer on position of last book value
**                  evalRuleEn     Evaluation rule to use
**                  maxConstrEn    Maximum constraint enum
**                  refDateTime    reference date and time
**                  opExch         operation exchange rate
**                  instrExch      instrument exchange rate
**                  sysExch        system exchange rate
**                  hiearHead      pointer on hierarchy
**                  bookValuePtr   allocated book value structure pointer
**
**  Return      :   RET_SUCCEED or error code, 
**
**  Modif       :   DVP395 - XDI - 970416
**		            DVP395 - DED - 970714 : Portfolio record is not obligatory
**		            REF2580 - SSO - 980727
**                  REF2462 - DED - 980729 : change extPosPtr by lastBVPtrInput
**		            REF3118 - SSO - 981214
**                  REF9082 - TEB - 030619
**                  REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF9303 - 030915 - PMO : Implementation of Unicode
**                  REF10461 - TEB - 040804
**                  REF11163 - TEB - 050616
**
*************************************************************************/
EXTERN RET_CODE FIN_ComputeBookValue(DBA_DYNFLD_STP    extPosPtr, 
		                             DBA_DYNFLD_STP    lastBVPtrInput, 
		                             EVALRULE_ENUM     evalRuleEn,
		                             EVALRULE_ENUM     maxConstrEn,
		                             DATETIME_T        refDateTime, 
                                     EXCHANGE_T        opExchInput,
                                     EXCHANGE_T        instrExchInput,
                                     EXCHANGE_T        sysExchInput,
		                             DBA_HIER_HEAD_STP hierHead,
		                             DBA_DYNFLD_STP    bookValuePtr)
{
	DBA_DYNFLD_STP ptfPtr=NULLDYNST;
	DBA_DYNFLD_STP instrPtr=NULLDYNST;
	DBA_DYNFLD_STP sPtfPosSet=NULLDYNST, ptfPosSetPtr=NULLDYNST;
	DBA_DYNFLD_STP instrPricePtr=NULLDYNST, lastBVPtr = NULLDYNST;
	DBA_DYNFLD_STP domainPtr=NULLDYNST, iorEvt=NULLDYNST;
	DBA_DYNFLD_STP ytmPtr=NULLDYNST,        
                   advArgStp   = NULLDYNST;                     /* REF9082 - TEB - 030619 */
    SCE_ADVA_ARG_ST *advaArgStp=(SCE_ADVA_ARG_ST*)NULL;         /* REF9082 - TEB - 030626 */
	FLAG_T         useNetVal=FALSE, useMktVal=FALSE, useBookVal=FALSE,
	               useFaceVal=FALSE, useStrAmorVal=FALSE, useEffAmorVal=FALSE,
            	       bvFind = FALSE, allocPtfPosSet=FALSE, allocPtf=FALSE, allocInstr=FALSE;
	NUMBER_T       tmpVal=0.0,lastBVInstrAmt=0.0,
                       minBVPtf=0.0, minBVOp=0.0, minBVInstr=0.0, minBVSys=0.0, ytm=0.0;
	PRICE_T	       price=0.0, quote=0.0, faceVal=0.0;
	EXCHANGE_T     tmpExch = 0.0;
	ID_T           ptfCurrId=0, sysCurrId=0, quoteValRuleId=0, exchValRuleId=0;
	ID_T           opCurrId=0, instrCurrId=0;
	EXCHANGE_T     opExch=0.0, instrExch=0.0, sysExch=0.0;
	long           nbOfDays=0, daysTotal=0;
	DATE_T         endDate=0;
	DATETIME_T     bigDateTime;
	RET_CODE       ret;
	FIN_EXCHARG_ST exchArgSt;			/* REFXZ */
	FLAG_T 	       applBookGrossAmountFlag;			/* REF4219 - 000228 - DED */	
    INSTRNAT_ENUM  instrNatInstr = InstrNat_None;   /* REF9082 - TEB - 030619 */
    SUBNAT_ENUM    instrSubNatEn = SubNat_None;     /* REF9082 - TEB - 030630 */
	ID_T		   calendarId = 0; 	/* PMSTA-22396  - SRIDHARA � 160430 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */
	GEN_GetApplInfo(ApplBookGrossAmountFlag, &applBookGrossAmountFlag);		/* REF4219 - 000228 - DED */

	if (bookValuePtr == NULLDYNST || extPosPtr == NULLDYNST)
		return(RET_GEN_ERR_INVARG);

	/* look which value must be compute for evalrule */
	switch(evalRuleEn)
	{
    case EvalRule_LowestCostOrMarket:
		useNetVal=TRUE;
		useMktVal=TRUE;
		break;
    case EvalRule_LowestEver:
		useNetVal=TRUE;
		useMktVal=TRUE;
		useBookVal=TRUE;
		break;
    case EvalRule_MktValue:
		useMktVal=TRUE;
		break;
    case EvalRule_AcquCost:
		useNetVal=TRUE;
		break;
    case EvalRule_ParValue:
		useFaceVal=TRUE;
		break;
    case EvalRule_StraightLineAmortCost:
	        useStrAmorVal=TRUE;
		break;
    case EvalRule_EffYieldAmortCost:
	        useEffAmorVal=TRUE;
		break;
    default:
		break;
	}

	/* look which value must be compute for maximum constraint */
	switch(maxConstrEn)
	{
    case MaxConstr_MaxParVal:
		useFaceVal=TRUE;
		break;
    case MaxConstr_MaxStraightLineAmortCost:
	        useStrAmorVal=TRUE;
		break;
    case MaxConstr_MaxEffYieldAmortCost:
	        useEffAmorVal=TRUE;
		break;
    default:
		break;
	}

	if (useNetVal == FALSE && useMktVal == FALSE && useBookVal == FALSE &&
	    useFaceVal == FALSE && useStrAmorVal == FALSE && useEffAmorVal == FALSE)
		useBookVal = TRUE;


    /* extract portfolio, portfolio position set and instrument pointer */
    /* from position or load it from database */
    if (GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Ptf_Ext) != NULL)
	{
        ptfPtr = *(GET_EXTENSION_PTR(extPosPtr,ExtPos_A_Ptf_Ext));
	}
    else if (IS_NULLFLD(extPosPtr, ExtPos_PtfId) == FALSE)			/* 970714 - DED */
    {
        /* REF4332 - RAK - 000210 */
        if ((ret = DBA_GetPtfById(GET_ID(extPosPtr, ExtPos_PtfId),
                                  FALSE, &allocPtf, &ptfPtr, hierHead,
                                  UNUSED, UNUSED)) != RET_SUCCEED)
        {
            return(ret);
        }
	}

	if (GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Instr_Ext) != NULL)
		instrPtr = *(GET_EXTENSION_PTR(extPosPtr,ExtPos_A_Instr_Ext));
	else
	{
        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(GET_ID(extPosPtr, ExtPos_InstrId), FALSE, &allocInstr, 
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
            return(RET_DBA_ERR_NODATA);
        }
	}

	if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == FALSE &&
	    GET_ID(extPosPtr, ExtPos_PtfPosSetId) != 0)
	{
		if ((sPtfPosSet = ALLOC_DYNST(S_PtfPosSet)) == NULLDYNST)
		{
			if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((ptfPosSetPtr = ALLOC_DYNST(A_PtfPosSet)) == NULLDYNST)
		{
			if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
			FREE_DYNST(sPtfPosSet, S_PtfPosSet);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		COPY_DYNFLD(sPtfPosSet, S_PtfPosSet, S_PtfPosSet_Id,
		            extPosPtr, ExtPos, ExtPos_PtfPosSetId);

		if (DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, sPtfPosSet, 
		             A_PtfPosSet, &ptfPosSetPtr,
		             UNUSED, UNUSED, UNUSED) != TRUE)
		{
			if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
			FREE_DYNST(sPtfPosSet, S_PtfPosSet);
			FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
			return(RET_DBA_ERR_NODATA);
		}
			
		FREE_DYNST(sPtfPosSet, S_PtfPosSet);
		allocPtfPosSet = TRUE;
	}

	if ((ptfPosSetPtr != NULLDYNST && ptfPtr == NULLDYNST)||
            instrPtr == NULLDYNST)
	{
		if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
		if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
		return(RET_GEN_ERR_INVARG);
	}

	/* if Domain containt valuation rule for quote or exchange, use it */
    if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead))) != NULLDYNST)/* REF2580 - SSO - 980727 */
    {
	    ptfCurrId = GET_ID(domainPtr, A_Domain_CurrId);				/* 970714 - DED */
        if (IS_NULLFLD(domainPtr, A_Domain_QuoteValRuleId) == FALSE)
            quoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId);
        if (IS_NULLFLD(domainPtr, A_Domain_ExchValRuleId) == FALSE)
            exchValRuleId = GET_ID(domainPtr, A_Domain_ExchValRuleId);
	}

	/* search Ptf currency. First look in portfolio position set */
	if (ptfPosSetPtr != NULLDYNST)
	{
		ptfCurrId = GET_ID(ptfPosSetPtr, A_PtfPosSet_CurrId);
		if (quoteValRuleId == 0)
			quoteValRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_QuoteValRuleId);
		if (exchValRuleId == 0)
			exchValRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_ExchValRuleId);
	}
	else if (ptfPtr != NULLDYNST)							/* 970714 - DED */
	{
		ptfCurrId = GET_ID(ptfPtr, A_Ptf_CurrId);
		if (quoteValRuleId == 0)
			quoteValRuleId = GET_ID(ptfPtr, A_Ptf_QuoteValRuleId);
		if (exchValRuleId == 0)
			exchValRuleId = GET_ID(ptfPtr, A_Ptf_ExchValRuleId);
	}

	opCurrId    = GET_ID(extPosPtr, ExtPos_PosCurrId);      /* REF2313 - DDV - 980618 */
	instrCurrId = GET_ID(extPosPtr, ExtPos_InstrCurrId);    /* REF2313 - DDV - 980618 */

	/* REF3118 - SSO - 981214 : get the syscurrid from ptf before from appl param */
	sysCurrId = 0;
	if (ptfPtr != NULLDYNST)
	{
	    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
	    {
		    sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
	    }
	}/* nb: if ptfPtr is NULL, ExtPos_PtfId is NULL (see above) */
	
	if (sysCurrId == 0)
	{
	    GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);
	}
	bvFind = FALSE;

	/* check position pointer with last book value if needed */
	if (useStrAmorVal == TRUE || useEffAmorVal || useBookVal == TRUE)
	{
        if (lastBVPtrInput == NULLDYNST)
		{
			if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
			if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
			return(RET_GEN_ERR_INVARG);
		}
		else
			lastBVPtr = lastBVPtrInput;
	}
	else	/* DVP453 - 970610 - DED */
	{
		lastBVPtr = lastBVPtrInput;
	}

	/* Get exchange rate if not in parametre */
	if (instrExchInput == 0.0)
	{
		FIN_GetExchRate(refDateTime, GET_ID(instrPtr, A_Instr_RefCurrId),
			            ptfCurrId, exchValRuleId,NULLDYNST, extPosPtr, &exchArgSt, &instrExch);	/* PMSTA01649 - TGU - 070405 */
	}
	else
		instrExch = instrExchInput;

	if (opExchInput == 0.0)
	{
		if (GET_ID(extPosPtr, ExtPos_PosCurrId) == GET_ID(instrPtr, A_Instr_RefCurrId))
			opExch = instrExch;
		else
			FIN_GetExchRate(refDateTime, GET_ID(extPosPtr, ExtPos_PosCurrId),
				            ptfCurrId, exchValRuleId, NULLDYNST, 
				            extPosPtr, &exchArgSt, &opExch);	/* PMSTA01649 - TGU - 070405 */
	}
	else
		opExch = opExchInput;

	if (sysExchInput == 0.0)
	{
		if (sysCurrId == GET_ID(instrPtr, A_Instr_RefCurrId))
			sysExch = instrExch;
		else if (sysCurrId == GET_ID(extPosPtr, ExtPos_PosCurrId))
			sysExch = opExch;
		else
			FIN_GetExchRate(refDateTime, sysCurrId, ptfCurrId, exchValRuleId,NULLDYNST,
			                extPosPtr, &exchArgSt, &sysExch);	/* PMSTA01649 - TGU - 070405 */
	}
	else
		sysExch = sysExchInput;

	/* first compute all value using exchange rate et refDateTime */
	/* MktVal, FaceVal, StrAmorVal and EffAmorVal */
	if (useMktVal == TRUE || useFaceVal == TRUE || 
	    useStrAmorVal == TRUE || useEffAmorVal == TRUE)
	{
		if (useMktVal == TRUE)
		{
			if ((instrPricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
			{
				if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
				if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
				if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr,
                                 refDateTime, NULLDYNST, quoteValRuleId, 
					             NULL, NULLDYNST, extPosPtr, hierHead, instrPricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */

            /* REF4249 - SSO - 000926 missing ret code test */
            if (ret == RET_FIN_INFO_NOPRICE)
            {
                char dateFmt[30], buf[30];
			    
                FREE_DYNST(instrPricePtr, A_InstrPrice);
	            if (allocInstr == TRUE)     {FREE_DYNST(instrPtr, A_Instr);}
	            if (allocPtf == TRUE)       {FREE_DYNST(ptfPtr, A_Ptf);}
	            if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}

                CONV_GetDfltDateFmt(DatetimeType, dateFmt, NULL);
                CONV_DataToStr(buf, sizeof(buf), DatetimeType, dateFmt, GET_DATETIME64(refDateTime), FALSE, TextConversion_None);  /* REF9303 - 030915 - PMO */
                strcat((char*)&buf, ": no price");

			    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_ComputeBookValue", 
				    GET_CODE(instrPtr, A_Instr_Cd), &buf);

                return(RET_FIN_ERR_INVDATA);
            }

			price = GET_PRICE(instrPricePtr, A_InstrPrice_Price);

			/* if not same currency, change price currency */
			if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
			{
				if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) == GET_ID(extPosPtr, ExtPos_PosCurrId))
					tmpExch = opExch / instrExch;
				else if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) == sysCurrId)
					tmpExch = sysExch / instrExch;
				else if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) == ptfCurrId)
					tmpExch = 1 / instrExch;
				else
					FIN_GetExchRate(refDateTime, GET_ID(instrPricePtr, A_InstrPrice_CurrId),
					                GET_ID(instrPtr, A_Instr_RefCurrId), 
							        exchValRuleId, NULLDYNST, extPosPtr, &exchArgSt, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
				price *= tmpExch;
			}

            /* DVP453 - 970610 - DED
			tmpVal = price * GET_NUMBER(extPosPtr, ExtPos_Qty) * GET_NUMBER(instrPtr, A_Instr_ContractSize);
            */
            /* Contract size used in load - XDI
			tmpVal = price * GET_NUMBER(lastBVPtr, ExtPos_Qty) * GET_NUMBER(instrPtr, A_Instr_ContractSize);
            */
			tmpVal = price * GET_NUMBER(lastBVPtr, ExtPos_Qty);

			/* REF11163 - TEB - 050616 */
			if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
				  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
				 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
			{
				tmpVal *= GET_PRICE(instrPtr, A_Instr_FaceValue);
			}

			if (bvFind == FALSE || tmpVal < minBVInstr)
			{
				minBVInstr = tmpVal;
				bvFind = TRUE;
			}

			FREE_DYNST(instrPricePtr, A_InstrPrice);
		}

		if (useFaceVal == TRUE)
		{
			if (instrExch != 0.0)
			{
                /* DVP453 - 970610 - DED
				faceVal = GET_NUMBER(extPosPtr, ExtPos_Qty) * opExch / instrExch; */
				/* faceVal = GET_NUMBER(lastBVPtr, ExtPos_Qty) * opExch / instrExch; REF2313 - DDV - 980618 */
				exchArgSt.srcAmt=GET_NUMBER(lastBVPtr, ExtPos_Qty);             /* REF2462 - DED - 980729 */

				/* REF11163 - TEB - 050616 */
				if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
					  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
					 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
				{
					exchArgSt.srcAmt *= GET_PRICE(instrPtr, A_Instr_FaceValue);
				}

				tmpExch=opExch/instrExch;
				FIN_ExchAmt(refDateTime, opCurrId, instrCurrId, exchValRuleId, NULLDYNST, 
                            extPosPtr, &exchArgSt, &tmpExch, &faceVal, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
			}
			else
				faceVal = 0.0;

			if (bvFind == FALSE || faceVal < minBVInstr)
			{
				minBVInstr = faceVal;
				bvFind = TRUE;
			}
		}

		if (useStrAmorVal == TRUE)
		{
			if (instrExch != 0.0)
			{
                /* DVP453 - 970610 - DED
				faceVal = GET_NUMBER(extPosPtr, ExtPos_Qty) * opExch / instrExch;
                */
				/* faceVal = GET_NUMBER(lastBVPtr, ExtPos_Qty) * opExch / instrExch; REF2313 - DDV - 980618 */
				exchArgSt.srcAmt=GET_NUMBER(lastBVPtr, ExtPos_Qty);             /* REF2462 - DED - 980729 */
				tmpExch=opExch/instrExch;
				FIN_ExchAmt(refDateTime, opCurrId, instrCurrId, exchValRuleId, NULLDYNST, 
                                 extPosPtr, &exchArgSt, &tmpExch, &faceVal, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
			}
			else
				faceVal = 0.0;

			/* REF11163 - TEB - 050616 */
			if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
				  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
				 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
			{
				faceVal *= GET_PRICE(instrPtr, A_Instr_FaceValue);
			}

			/* DDV - REF1732 - 980421 */
            if (IS_NULLFLD(instrPtr, A_Instr_RedempPrice) == FALSE)
				faceVal *= GET_PRICE(instrPtr, A_Instr_RedempPrice);

			lastBVInstrAmt = GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt);

			/* PMSTA-22396  - SRIDHARA � 160430 */
			DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			DATE_DaysBetween(GET_DATE(lastBVPtr, ExtPos_BegDate), refDateTime.date,
			                 (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
							 &nbOfDays, calendarId);

			/* if end date not define in instrument, take it in finalr RedmEvt */
			if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE)
			{
				if ((iorEvt = ALLOC_DYNST(A_IssueEvt)) == NULLDYNST)
                {
					if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

				bigDateTime.date = DATE_Put(2999, 12, 31);
				bigDateTime.time = 0;  

				if ((ret = DBA_GetFinalIOREvt(instrPtr, refDateTime, bigDateTime,
                                              refDateTime, iorEvt)) != RET_SUCCEED)
				{
					if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                	FREE_DYNST(iorEvt, A_IssueEvt);
		    		MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				endDate = GET_DATE(iorEvt, A_IssueEvt_EndDate);
                FREE_DYNST(iorEvt, A_IssueEvt);
			}
			else
				endDate = GET_DATE(instrPtr, A_Instr_EndDate);

			DATE_DaysBetween(GET_DATE(lastBVPtr, ExtPos_BegDate), 
			                 endDate, 
                             (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
							 &daysTotal, calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */

			if (daysTotal != 0.0)
				tmpVal = lastBVInstrAmt - ((lastBVInstrAmt - faceVal) * 
	                     ((NUMBER_T) nbOfDays / (NUMBER_T) daysTotal));
			else
				tmpVal = lastBVInstrAmt;

			if (bvFind == FALSE || tmpVal < minBVInstr)
			{
				minBVInstr = tmpVal;
				bvFind = TRUE;
			}
		}

		if (useEffAmorVal == TRUE)
		{
            /* DVP453 - 970610 - DED
			if (GET_NUMBER(extPosPtr, ExtPos_Qty) != 0.0)
            */
			if (GET_ID(extPosPtr, ExtPos_PosCurrId) ==
			    GET_ID(instrPtr, A_Instr_RefCurrId))
				faceVal = GET_NUMBER(lastBVPtr, ExtPos_Qty);
			if (instrExch != 0.0)
			{
				/* faceVal = CAST_AMOUNT(GET_NUMBER(lastBVPtr, ExtPos_Qty) * 
				             opExch / instrExch, GET_ID(instrPtr, A_Instr_RefCurrId)); REF2313 - DDV - 980618 */
				exchArgSt.srcAmt=GET_NUMBER(lastBVPtr, ExtPos_Qty);

				/* REF11163 - TEB - 050616 */
				if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
					  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
					 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
				{
					exchArgSt.srcAmt *= GET_PRICE(instrPtr, A_Instr_FaceValue);
				}

				tmpExch=opExch/instrExch;
				FIN_ExchAmt(refDateTime, opCurrId, instrCurrId, exchValRuleId, NULLDYNST, 
                            extPosPtr, &exchArgSt, &tmpExch, &faceVal, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
			}
			else
				faceVal = 0.0;

			if (TLS_Cmp(GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt), faceVal, 0.0) == 0) /* REF7475 - LJE - 020619 */
			{
				tmpVal = faceVal;
			}
			else if (GET_NUMBER(lastBVPtr, ExtPos_Qty) != 0.0)
			{
                /* REF9082 - TEB - 030619 -Begin */
                /* Replace Tech with Simcorp */

                /* Get nature of the instrument */
                instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);  

	            /* compute these instruments */
	            if ((InstrNat_Bond          != instrNatInstr) &&
	                (InstrNat_MoneyMkt      != instrNatInstr) &&
	                (InstrNat_Discount      != instrNatInstr) &&
	                (InstrNat_Swap          != instrNatInstr) &&
	                (InstrNat_ForexSwaps    != instrNatInstr) &&
                    (InstrNat_ConvertBond   != instrNatInstr) &&
                    (InstrNat_FlowInstr     != instrNatInstr)
	               )
	            {
	                ytm = 0.0;	                
	            }
                else
                {
	                /* Create input structure. */
	                if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
                    {
					    if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					    if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					    if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
		    		    MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    /* Set the instrument id */
				    COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_InstrId,
                                instrPtr, A_Instr, A_Instr_Id);

                    /* Set the reference date */
					/* REF10529 - TEB - 040826 */
					/* Default value is current date */
					if (IS_NULLFLD(lastBVPtr, ExtPos_BegDate)==FALSE)
					{
						COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RefDate,
	 		    					lastBVPtr, ExtPos, ExtPos_BegDate);
					}
					else
					{
						SET_DATE(advArgStp, AdvA_Arg_RefDate, DATE_CurrentDate());
					}

                    COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );    

                    /* REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice */
                    /* Set the redemption quote */
					/* REF10461 - TEB - 040804 */
					/* Compute Redemption Price in SCE functions, because of iorevent priority */
/*

                    if (IS_NULLFLD(instrPtr, A_Instr_RedempQuote)== TRUE)
                    {
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "No redemption quote for YTM computation ! Instrument :",
                                     GET_CODE(instrPtr, A_Instr_Cd));
		                FREE_DYNST(advArgStp, AdvA_Arg);
					    if (allocInstr     == TRUE) {FREE_DYNST(instrPtr,     A_Instr);}
					    if (allocPtf       == TRUE) {FREE_DYNST(ptfPtr,       A_Ptf);}
					    if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                        return(RET_FIN_ERR_INVDATA);
                    }
                    else
                    {
                        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RedemptionPrice, instrPtr, A_Instr, A_Instr_RedempQuote );
                    }
*/

                    /* Set the price */
					/* REF10836 - TEB - 041016 - Check if price valid */
					if (IS_NULLFLD(lastBVPtr, ExtPos_BookInstrNetAmt) == TRUE ||
						GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt) == 0.0)
					{
						MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
									 "FIN_ComputeBookValue", GET_CODE(instrPtr, A_Instr_Cd), "ExtPos_BookInstrNetAmt");
		                FREE_DYNST(advArgStp, AdvA_Arg);
					    if (allocInstr     == TRUE) {FREE_DYNST(instrPtr,     A_Instr);}
					    if (allocPtf       == TRUE) {FREE_DYNST(ptfPtr,       A_Ptf);}
					    if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
						return(RET_FIN_ERR_INVDATA);
					}

					/* REF11163 - TEB - 050616 */
					if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
						  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
						 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) &&
						 /* REF11336 - TEB - 050815 - Avoid zero division */
						 IS_NULLFLD(instrPtr, A_Instr_FaceValue) == FALSE  && GET_PRICE(instrPtr, A_Instr_FaceValue) != 0.0)
					{
						tmpVal = GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt) /
		         				 (GET_NUMBER(lastBVPtr, ExtPos_Qty)*GET_PRICE(instrPtr, A_Instr_FaceValue));
					}
					else
					{
						tmpVal = GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt) /
		         				 GET_NUMBER(lastBVPtr, ExtPos_Qty);
					}

					/* REF11163 - TEB - 050616 */
					/* Only apply factor 100 if instrument is quote/100 */
					if ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Quote100)
					{
						tmpVal *= 100.0;
					}

                    SET_PRICE(advArgStp, AdvA_Arg_CurrentPrice, (NUMBER_T)tmpVal);

                    /* Allocate the output structure */
	                if ((ytmPtr = ALLOC_DYNST(A_Ytm)) == NULLDYNST)
	                {
		                FREE_DYNST(advArgStp, AdvA_Arg);
					    if (allocInstr     == TRUE) {FREE_DYNST(instrPtr,     A_Instr);}
					    if (allocPtf       == TRUE) {FREE_DYNST(ptfPtr,       A_Ptf);}
					    if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
		                MSG_RETURN(RET_MEM_ERR_ALLOC);
	                }

                    /* set the type of the output structure */
	                SET_INT(advArgStp, AdvA_Arg_SceOutEn, A_Ytm); /* REF9764 - LJE - 040113 */

	                /* set the keyword nature */
	                SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_YTM);

                    /* Compute ytm */
	                if ((ret=SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
				                                    NULL , hierHead, ytmPtr)) != RET_SUCCEED)
	                {
					    if (allocInstr     == TRUE) {FREE_DYNST(instrPtr,     A_Instr);}
					    if (allocPtf       == TRUE) {FREE_DYNST(ptfPtr,       A_Ptf);}
					    if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                        FREE_DYNST(advArgStp, AdvA_Arg);
					    FREE_DYNST(ytmPtr, A_Ytm);
					    return(ret);
				    }

				    ytm = GET_NUMBER(ytmPtr, A_Ytm_Ytm);

                    FREE_DYNST(advArgStp, AdvA_Arg);
				    FREE_DYNST(ytmPtr, A_Ytm);
                }

                /* REF9082 - TEB - 030619 - End*/

                /* REF9082 - TEB - 030626 - Begin*/
                if ((advaArgStp = (SCE_ADVA_ARG_ST*)CALLOC(1, sizeof(SCE_ADVA_ARG_ST))) == NULL)
                {
					if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
    
                /* ------------------------------------- */
                /* set structure of all structure needed */
                /* ------------------------------------- */
                advaArgStp->extPosStp	    = NULLDYNST;
                advaArgStp->instrStp	    = instrPtr;
                advaArgStp->hierHead	    = hierHead;
                advaArgStp->underInstr	    = NULLDYNST; 
                advaArgStp->underUnderInstr = NULLDYNST;
                advaArgStp->incomeStp       = NULLDYNST;
                advaArgStp->under           = FALSE;
                advaArgStp->underUnder      = FALSE;

	            /* Create input structure. */
	            if ((advaArgStp->argStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
                {
					if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
                    FREE(advaArgStp);
		            MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                /* Set the instrument id */
                SET_ID(advaArgStp->argStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

                /* Set the reference date */
                SET_DATE(advaArgStp->argStp, AdvA_Arg_RefDate, refDateTime.date);
                COPY_DYNFLD(advaArgStp->argStp, AdvA_Arg, AdvA_Arg_Date, advaArgStp->argStp, AdvA_Arg, AdvA_Arg_RefDate );    

                /* Set the Yield */
                SET_NUMBER(advaArgStp->argStp, AdvA_Arg_Ytm, (NUMBER_T)(ytm));

                /* Allocate the output structure */
	            if ((advaArgStp->outStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	            {
		            FREE_DYNST(advaArgStp->argStp, AdvA_Arg);
                    FREE(advaArgStp);
					if (allocInstr == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
					if (allocPtf == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
					if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}
		            MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                SET_INT(advaArgStp->argStp, AdvA_Arg_SceOutEn, A_AdvA);

                /* Compute price */
                instrSubNatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);
                if ((instrNatInstr == InstrNat_Bond || instrNatInstr == InstrNat_MoneyMkt) && instrSubNatEn == SubNat_FRN)
                {
                    advaArgStp->currSceFct = Sce_FctName_FRN_YTM2Price;
                    ret =  SCE_CallFRN_YTM2Price(advaArgStp);
                }
                else
                {
                    advaArgStp->currSceFct = Sce_FctName_Bond_YTM2Price;
                    ret =  SCE_CallBond_YTM2Price(advaArgStp);
                }

                if (IS_NULLFLD(advaArgStp->outStp, A_AdvA_Price)==FALSE)
                    tmpVal= GET_PRICE(advaArgStp->outStp, A_AdvA_Price);

	            FREE_DYNST(advaArgStp->outStp,   A_AdvA);
                FREE_DYNST(advaArgStp->argStp, AdvA_Arg);
                FREE(advaArgStp);

				/* REF11163 - TEB - 050616 */
				if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
					  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
					 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
				{
					tmpVal *= GET_NUMBER(lastBVPtr, ExtPos_Qty)*GET_PRICE(instrPtr, A_Instr_FaceValue);
				}
				else
				{
					tmpVal *= GET_NUMBER(lastBVPtr, ExtPos_Qty);
				}

				/* REF11163 - TEB - 050616 */
				/* Only apply factor 100 if instrument is quote/100 */
				if ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Quote100 ||
					(PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_QuoteInUnit )/* REF11163 - TEB - 050622 */
				{
					tmpVal /= 100.0;
				}

                /* REF9082 - TEB - 030626 - Begin */
	    	}
			else
                tmpVal = 0.0;

			if (bvFind == FALSE || tmpVal < minBVInstr)
			{
				minBVInstr = tmpVal;
				bvFind = TRUE;
			}
		}

		/* minBVPtf = minBVInstr * instrExch; REF2313 - DDV - 980618 */
		exchArgSt.srcAmt=minBVInstr;
		tmpExch=instrExch;
		FIN_ExchAmt(refDateTime, instrCurrId, ptfCurrId, exchValRuleId, NULLDYNST, 
                    extPosPtr, &exchArgSt, &tmpExch, &minBVPtf, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
		
		exchArgSt.srcAmt=minBVPtf;
		if (opExch != 0.0)
		{
			tmpExch=1/opExch;
			FIN_ExchAmt(refDateTime, ptfCurrId, opCurrId, exchValRuleId, NULLDYNST, 
                        extPosPtr, &exchArgSt, &tmpExch, &minBVOp, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
			/*minBVOp = minBVPtf / opExch; REF2313 - DDV - 980618 */
		}
		else
			minBVOp = 0.0;
		
		if (sysExch != 0.0)
		{
			tmpExch=1/sysExch;
			FIN_ExchAmt(refDateTime, ptfCurrId, sysCurrId, exchValRuleId, NULLDYNST, 
                        extPosPtr, &exchArgSt, &tmpExch, &minBVSys, (EXCHANGE_T *) NULL);	/* PMSTA01649 - TGU - 070405 */
			/*minBVSys = minBVPtf / sysExch; REF2313 - DDV - 980618 */
		}
		else
			minBVSys = 0.0;
	}

	/* compare result of first part (compute result) with stored result */
	/* in extendend position */
	
	if (useNetVal == TRUE)
	{
		if (bvFind == FALSE)
		{
			if (applBookGrossAmountFlag == TRUE)				/* REF4219 - 000228 - DED */
			{	
			    minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_InstrGrossAmt);
			    minBVPtf   = GET_NUMBER(lastBVPtr, ExtPos_RefGrossAmt);
			    minBVOp    = GET_NUMBER(lastBVPtr, ExtPos_PosGrossAmt);
			    minBVSys   = GET_NUMBER(lastBVPtr, ExtPos_SysGrossAmt);
			}
			else
			{	
			    minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_InstrNetAmt);
			    minBVPtf   = GET_NUMBER(lastBVPtr, ExtPos_RefNetAmt);
			    minBVOp    = GET_NUMBER(lastBVPtr, ExtPos_PosNetAmt);
			    minBVSys   = GET_NUMBER(lastBVPtr, ExtPos_SysNetAmt);
			}
			bvFind = TRUE;
		}
		else
		{
			if (applBookGrossAmountFlag == TRUE)                            /* REF4219 - 000228 - DED */
                        {
			    if (GET_NUMBER(lastBVPtr, ExtPos_InstrGrossAmt) < minBVInstr)
				    minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_InstrGrossAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_RefGrossAmt) < minBVPtf)
				    minBVPtf = GET_NUMBER(lastBVPtr, ExtPos_RefGrossAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_PosGrossAmt) < minBVOp)
				    minBVOp = GET_NUMBER(lastBVPtr, ExtPos_PosGrossAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_SysGrossAmt) < minBVSys)
				    minBVSys = GET_NUMBER(lastBVPtr, ExtPos_SysGrossAmt);
			}
			else
                        {
			    if (GET_NUMBER(lastBVPtr, ExtPos_InstrNetAmt) < minBVInstr)
				    minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_InstrNetAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_RefNetAmt) < minBVPtf)
				    minBVPtf = GET_NUMBER(lastBVPtr, ExtPos_RefNetAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_PosNetAmt) < minBVOp)
				    minBVOp = GET_NUMBER(lastBVPtr, ExtPos_PosNetAmt);

			    if (GET_NUMBER(lastBVPtr, ExtPos_SysNetAmt) < minBVSys)
				    minBVSys = GET_NUMBER(lastBVPtr, ExtPos_SysNetAmt);
			}
		}
	}

	if (useBookVal == TRUE)
	{
		if (bvFind == FALSE)
		{
			minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt);
			minBVPtf = GET_NUMBER(lastBVPtr, ExtPos_BookRefNetAmt);
			minBVOp = GET_NUMBER(lastBVPtr, ExtPos_BookPosNetAmt);
			minBVSys = GET_NUMBER(lastBVPtr, ExtPos_BookSysNetAmt);
			bvFind = TRUE;
		}
		else
		{
			if (GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt) < minBVInstr)
				minBVInstr = GET_NUMBER(lastBVPtr, ExtPos_BookInstrNetAmt);

		        if (GET_NUMBER(lastBVPtr, ExtPos_BookRefNetAmt) < minBVPtf)
				minBVPtf = GET_NUMBER(lastBVPtr, ExtPos_BookRefNetAmt);
    
			if (GET_NUMBER(lastBVPtr, ExtPos_BookPosNetAmt) < minBVOp)
				minBVOp = GET_NUMBER(lastBVPtr, ExtPos_BookPosNetAmt);
    
			if (GET_NUMBER(lastBVPtr, ExtPos_BookSysNetAmt) < minBVSys)
				minBVSys = GET_NUMBER(lastBVPtr, ExtPos_BookSysNetAmt);
		}
	}

	/* set result in book value structure and cast amounts */
	SET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt, 
               CAST_AMOUNT(minBVPtf, ptfCurrId));	
	SET_NUMBER(bookValuePtr, A_BookValue_OpNetAmt, 
               CAST_AMOUNT(minBVOp, GET_ID(extPosPtr, ExtPos_PosCurrId)));	
	SET_NUMBER(bookValuePtr, A_BookValue_InstrNetAmt, 
               CAST_AMOUNT(minBVInstr,GET_ID(instrPtr, A_Instr_RefCurrId)));	
	SET_NUMBER(bookValuePtr, A_BookValue_SysNetAmt, 
               CAST_AMOUNT(minBVSys, sysCurrId));	

	SET_EXCHANGE(bookValuePtr, A_BookValue_InstrExchRate, instrExch);
	SET_EXCHANGE(bookValuePtr, A_BookValue_OpExchRate,    opExch);
	SET_EXCHANGE(bookValuePtr, A_BookValue_SysExchRate,   sysExch);

	if (GET_NUMBER(lastBVPtr, ExtPos_Qty) != 0.0)
	{
		/* REF11336 - TEB - 050815 */
		if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
			  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
			 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) &&
			 IS_NULLFLD(instrPtr, A_Instr_FaceValue) == FALSE  && GET_PRICE(instrPtr, A_Instr_FaceValue) != 0.0)
		{
			price = minBVOp/(GET_NUMBER(lastBVPtr, ExtPos_Qty)*GET_PRICE(instrPtr, A_Instr_FaceValue));
		}
		else
		{
			price = minBVOp/GET_NUMBER(lastBVPtr, ExtPos_Qty);
		}
	}
    else
        price = 0.0;

    price = CAST_AMOUNT(price, GET_ID(extPosPtr, ExtPos_PosCurrId));	

	FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
                     GET_ID(instrPtr, A_Instr_Id), instrPtr,
                     refDateTime, NULL, price, &quote, hierHead);

	SET_PRICE(bookValuePtr, A_BookValue_Price,       price);
	SET_PRICE(bookValuePtr, A_BookValue_Quote,       quote);
	SET_ENUM(bookValuePtr,   A_BookValue_EvalRuleEn,  evalRuleEn);
	SET_ENUM(bookValuePtr,   A_BookValue_MaxConstrEn, maxConstrEn);

	if (allocInstr == TRUE)     {FREE_DYNST(instrPtr, A_Instr);}
	if (allocPtf == TRUE)       {FREE_DYNST(ptfPtr, A_Ptf);}
	if (allocPtfPosSet == TRUE) {FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_GetBookValueEltByValRuleHist()
**
**  Description :   return valuation rule element for book value
**                  corresponding with valuation rule history and record.
**
**  Arguments   :   extPosPtr       allocated pointer on position
**                  valRuleHistPtr  allocated pointer on valuation rule history
**                  hiearHead       allocated pointer on hierarchy
**                  valRuleElt      allocated valuation rule element structure pointer
**
**  Return      :   RET_SUCCEED or error code, 
**
**  Modif       :   DVP395 - XDI - 970617
**  Modif       :   REF1272 - RAK - 980216
**
*************************************************************************/
EXTERN RET_CODE FIN_GetBookValueEltByValRuleHist(DBA_DYNFLD_STP    extPosPtr, 
       			                         DBA_DYNFLD_STP    valRuleHistPtr,
		                                 DBA_HIER_HEAD_STP hierHead,
		                                 DBA_DYNFLD_STP    valRuleEltPtr,
                                         DATETIME_STP      refDateTime)
{
	DBA_DYNFLD_STP instrPtr=NULLDYNST;
	DBA_DYNFLD_STP classifResult=NULLDYNST;
	DBA_DYNFLD_STP admArgPtr=NULLDYNST;
	DBA_DYNFLD_STP *valRuleEltTab=NULLDYNSTPTR;
	ID_T	       listId=0, instrId;
	int	           valRuleEltNbr = 0;
	int	           i;
	FLAG_T         allocInstrOk=FALSE;
	OBJECT_ENUM    entity;
	RET_CODE	ret; /* REF3955 - SSO - 000112 added test */

	if (extPosPtr == NULLDYNST || valRuleHistPtr == NULLDYNST)
		return(RET_GEN_ERR_INVARG);

	/**** LOAD INSTRUMENT ****/
	if (GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Instr_Ext) != NULL)
		instrPtr = *(GET_EXTENSION_PTR(extPosPtr,ExtPos_A_Instr_Ext));
	else
	{
        /* REF3913 - 990820 - DDV */
        if (DBA_GetInstrById(GET_ID(extPosPtr, ExtPos_InstrId), FALSE, &allocInstrOk, 
                             &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
        {
            return(RET_DBA_ERR_NODATA);
        }
	}

	DBA_GetObjectEnum(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId), &entity);

	/* if not classification for extpos entity or instrument entity, return */
	/*if (entity != EPos && entity != Instr) classif only on instrument - 970617 - XDI */
	if (entity != Instr)
	{
		if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		return(RET_GEN_ERR_INVARG);
	}

	/* if classification for instrument entity and no instrument found, return */
	if (entity == Instr && instrPtr == NULLDYNST) 
	{
		if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		return(RET_GEN_ERR_INVARG);
	}

	/* Select all valuation rule element */
	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
	{
		if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(valRuleHistPtr, A_ValRuleHist_Id));

    if ((DBA_Select2(ValRuleElt, UNUSED, Adm_Arg, admArgPtr,
                     A_ValRuleElt, &valRuleEltTab, UNUSED, UNUSED,
                     &valRuleEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleElt));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
		             entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
		if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		FREE_DYNST(admArgPtr, Adm_Arg);
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(admArgPtr, Adm_Arg);

	if ((classifResult = ALLOC_DYNST(A_ClassifCompo)) == NULLDYNST)
	{
		if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		return(RET_GEN_ERR_INVARG);
	}

	/* Classify the entity define in valRuleHistory */
	if (entity == Instr)
	{
		/* REF1272 - RAK - 980216 */
		if (GET_ID(instrPtr, A_Instr_Id) < 0)
			instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		else
			instrId = GET_ID(instrPtr, A_Instr_Id);
		/* REF3955 - SSO - 000112 added test */
		if ((ret = FIN_Classify(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId), instrId, /* PMSTA-10070 - LJE - 101004 */
		             GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId), 
       		         instrPtr, classifResult, NULL, hierHead, 
                     refDateTime, NULLDYNST, FALSE, TRUE, UNUSED, UNUSED)) != RET_SUCCEED)
		{
		    FREE_DYNST(classifResult, A_ClassifCompo);
		    if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		    return(ret);
		}
	}
     /* else if (entity == EPos) classif only on instrument - 970617 - XDI 
		FIN_Classify(EPos, GET_ID(extPosPtr, ExtPos_Id),
		             GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       		             extPosPtr, classifResult, NULL, hierHead);               */

	listId = GET_ID(classifResult, A_ClassifCompo_ListId);
	
    FREE_DYNST(classifResult, A_ClassifCompo);
	if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}

	/* search the first element in list corresponding to list_id */
    for (i=0; i<valRuleEltNbr && GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) < listId; i++);

	if (i == valRuleEltNbr)
	{
        DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
	    return(RET_FIN_INFO_NOPRICE);
	}

    COPY_DYNST(valRuleEltPtr, valRuleEltTab[i], A_ValRuleElt);
    
    DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_BookValueByValRule()
**
**  Description :   Compute book value for extended position and valuation rule
**
**  Arguments   :   extPosPtr       allocated pointer on position
**                  lastBVPtr       allocated pointer on position of last book value
**                  valRuleId       Valuation rule to use
**                  inputvalRulePtr pointer on valuation rule (optional)
**                  refDateTime     reference date and time
**                  opExch          operation exchange rate
**                  instrExch       instrument exchange rate
**                  sysExch         system exchange rate
**                  hiearHead       pointer on hierarchy
**                  bookValuePtr    allocated book value structure pointer
**
**  Return      :   RET_SUCCEED or error code, 
**
**  Modif       :   DVP395 - XDI - 970418
**
*************************************************************************/
EXTERN RET_CODE FIN_BookValueByValRule(DBA_DYNFLD_STP    extPosPtr, 
                                       DBA_DYNFLD_STP    lastBVPtr, 
       			                       ID_T              valRuleId,
       	       		                   DBA_DYNFLD_STP    inputValRulePtr,
       	       	                       DATETIME_T        refDateTime, 
                                       NUMBER_T          opExch,
                                       NUMBER_T          instrExch,
                                       NUMBER_T          sysExch,
		                               DBA_HIER_HEAD_STP hierHead,
		                               DBA_DYNFLD_STP    bookValuePtr)
{
	DBA_DYNFLD_STP getValRule=NULLDYNST, valRulePtr=NULLDYNST;
	DBA_DYNFLD_STP valRuleHistPtr=NULLDYNST;
	DBA_DYNFLD_STP admArgPtr=NULLDYNST;
	DBA_DYNFLD_STP valRuleEltPtr=NULLDYNST;
	char           allocValRuleOk=FALSE;
	RET_CODE       ret;

	if (extPosPtr == NULLDYNST || valRuleId <= 0)
		return(RET_GEN_ERR_INVARG);

	/**** LOAD Valuation Rule ****/
	/* If valuation rule structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputValRulePtr != NULLDYNST)
	{
		valRulePtr = inputValRulePtr;
		allocValRuleOk = FALSE;
	}
	else
	{
		if ((getValRule = ALLOC_DYNST(S_ValRule)) == NULLDYNST)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		if ((valRulePtr = ALLOC_DYNST(A_ValRule)) == NULLDYNST)
		{
			FREE_DYNST(getValRule, S_ValRule);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(getValRule, S_ValRule_Id, valRuleId);
		if (DBA_Get2(ValRule, UNUSED, S_ValRule, getValRule, A_ValRule, &valRulePtr,
		             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		{
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRule));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
			             entSqlName, GET_ID(getValRule, S_ValRule_Id));
			FREE_DYNST(getValRule, S_ValRule);
			FREE_DYNST(valRulePtr, A_ValRule);
			return(RET_DBA_ERR_NODATA);
		}

		FREE_DYNST(getValRule, S_ValRule);
		allocValRuleOk = TRUE;
	}

	/*if the given rule nature is not book value, exit */
	if (GET_ENUM(valRulePtr, A_ValRule_NatEn) != ValRuleNat_BookValue)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		return(RET_GEN_ERR_INVARG);
	}

	/* Get valuation History record corresponding with rule and date */
	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((valRuleHistPtr = ALLOC_DYNST(A_ValRuleHist)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(admArgPtr, Adm_Arg);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(admArgPtr, Adm_Arg_Id, valRuleId);
	SET_DATETIME(admArgPtr, Adm_Arg_Date, refDateTime);

	if (DBA_Get2(ValRuleHist, DBA_GET_LAST, Adm_Arg, admArgPtr, A_ValRuleHist, &valRuleHistPtr, /* DDV - 180918 - Add role to avoid confusion with BK */
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleHist));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
		             entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(admArgPtr, Adm_Arg);
		FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(admArgPtr, Adm_Arg);

	/* Select all valuation rule element */
	if ((valRuleEltPtr = ALLOC_DYNST(A_ValRuleElt)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	        FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    ret = FIN_GetBookValueEltByValRuleHist(extPosPtr, valRuleHistPtr, hierHead, valRuleEltPtr, &refDateTime);

	if (ret != RET_SUCCEED)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
		FREE_DYNST(valRuleEltPtr, A_ValRuleElt);
		MSG_RETURN(ret);
	}

	ret = FIN_ComputeBookValue(extPosPtr, lastBVPtr, 
                               (EVALRULE_ENUM)GET_ENUM(valRuleEltPtr, A_ValRuleElt_EvalRuleEn),  /* REF7264 - CSY - 020130 */
                               (EVALRULE_ENUM)GET_ENUM(valRuleEltPtr, A_ValRuleElt_MaxConstraintEn),  /* REF7264 - LJE - 020131 */
                               refDateTime, opExch, instrExch, sysExch, 
                               hierHead, bookValuePtr);

	if (ret != RET_SUCCEED)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
		FREE_DYNST(valRuleEltPtr, A_ValRuleElt);
		MSG_RETURN(ret);
	}

	SET_ID(bookValuePtr, A_BookValue_ValRuleId, valRuleId);
	COPY_DYNFLD(bookValuePtr, A_BookValue, A_BookValue_ValRuleHistId,
	            valRuleHistPtr, A_ValRuleHist, A_ValRuleHist_Id);
	COPY_DYNFLD(bookValuePtr, A_BookValue, A_BookValue_ValRuleEltId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

	FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
	FREE_DYNST(valRuleEltPtr, A_ValRuleElt);
	if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CalcBookUnrealPL()
**
**  Description :   Compute unrealised Book Value for position
**
**  Arguments   :   extPosPtr       allocated pointer on position
**                  posValPtr       posVal pointer          
**                  hiearHead       pointer on hierarchy
**                  bookValuePtr    allocated book value structure pointer
**
**  Return      :   RET_SUCCEED or error code, 
**
**  Modif       :   DVP439 - XDI - 970505
**
*************************************************************************/
EXTERN RET_CODE FIN_CalcBookUnrealPL(DBA_DYNFLD_STP    extPosPtr, 
                                     DBA_DYNFLD_STP    posValPtr, 
                                     DBA_HIER_HEAD_STP hierHead,
		                             DBA_DYNFLD_STP    bookValuePtr)
{
	DBA_DYNFLD_STP          dynFldInput = NULLDYNST, ptfPosSetPtr = NULLDYNST, ptfPtr = NULLDYNST;
	RET_CODE                ret = RET_SUCCEED;
	ID_T                    valRuleId = 0;
	BOOKVALADJMETHOD_ENUM   bookValueAdjMethod;
	NUMBER_T                ptfAmt=0.0, instrAmt=0.0, opAmt=0.0, sysAmt=0.0;

	if (extPosPtr == NULLDYNST || posValPtr == NULLDYNST)
		return(RET_GEN_ERR_INVARG);

	/* get valuation rule to use */
	if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSet_Ext) == FALSE &&
	    GET_EXTENSION_PTR(extPosPtr, ExtPos_PtfPosSet_Ext) != NULL &&
	    (ptfPosSetPtr = *(GET_EXTENSION_PTR(extPosPtr, ExtPos_PtfPosSet_Ext))) != NULLDYNST)
		valRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_BookValRuleId);

	/* REF1987 - DDV - 980428 */
    if (valRuleId == 0 && IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == FALSE &&
        GET_ID(extPosPtr, ExtPos_PtfPosSetId) > 0)
    {
            /* get portfolio position set */
	        if ((ptfPosSetPtr = ALLOC_DYNST(A_PtfPosSet)) == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_PtfPosSet");
	            return(RET_MEM_ERR_ALLOC);
	        }

	        if ((dynFldInput = ALLOC_DYNST(S_PtfPosSet)) == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_PtfPosSet");
	            FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
	            return(RET_MEM_ERR_ALLOC);
	        }

	        /* Fill input structure field */
	        SET_ID(dynFldInput, S_PtfPosSet_Id, GET_ID(extPosPtr, ExtPos_PtfPosSetId));

	        /* Load portfolio position set */
	        if ((ret = DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, dynFldInput, A_PtfPosSet, &ptfPosSetPtr,
	                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	        {
	            FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
	       	    FREE_DYNST(dynFldInput, S_PtfPosSet);
        	}
            else
	        {
	       	    FREE_DYNST(dynFldInput, S_PtfPosSet);
                if (IS_NULLFLD(ptfPosSetPtr, A_PtfPosSet_BookValRuleId) == FALSE)
		    	valRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_BookValRuleId);
	            FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
        	}
        }

	if (valRuleId == 0 && IS_NULLFLD(extPosPtr, ExtPos_A_Ptf_Ext) == FALSE &&
	    GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Ptf_Ext))) != NULLDYNST)
		valRuleId = GET_ID(ptfPtr, A_Ptf_BookValRuleId); /* BUG493 - XDI - 970903 */

	if (valRuleId == 0)
		return(RET_GEN_ERR_INVARG);

	/* get target book value */
	if ((ret = FIN_BookValueByValRule(extPosPtr, 
                                      extPosPtr, /* last book value stored in position */
       			                      valRuleId, 
       			                      NULLDYNST,
       		                          GET_DATETIME(posValPtr, PosVal_Date), 
                                      0, 0, 0,
		                              hierHead,
		                              bookValuePtr)) != RET_SUCCEED)
	{
		return(ret);
	}

	ptfAmt   = GET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt);
	opAmt    = GET_NUMBER(bookValuePtr, A_BookValue_OpNetAmt);
	instrAmt = GET_NUMBER(bookValuePtr, A_BookValue_InstrNetAmt);
	sysAmt   = GET_NUMBER(bookValuePtr, A_BookValue_SysNetAmt);

/* REF1987 - DDD - 980515 */
#if 0
	SET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt, /*BookAdjOp_BookPtfNetAmt, DDV - 980429 */
               GET_NUMBER(posValPtr, PosVal_RefNetAmt) - ptfAmt);
#endif 
	SET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt, /*BookAdjOp_BookPtfNetAmt, DDV - 980429 */
               CAST_NUMBER(ptfAmt - GET_NUMBER(extPosPtr, ExtPos_BookRefNetAmt))); /* REF3288 - SSO - 990205 */

	/* Compute adjustment amount */
	/* use appl_param.BOOK_VALUE_ADJUST_METHOD to define how to compute */
	/* amount for each currency */
	GEN_GetApplInfo(ApplBookValAdjMethod, &bookValueAdjMethod);

	switch(bookValueAdjMethod)
	{
	case BookValAdjMethod_AllCurrency:
		SET_NUMBER(bookValuePtr, A_BookValue_OpNetAmt, /*BookAdjOp_BookOpNetAmt, DDV - 980429 */
                           CAST_NUMBER(opAmt - GET_NUMBER(extPosPtr, ExtPos_BookPosNetAmt))); /* REF3288 - SSO - 990205 */

		SET_NUMBER(bookValuePtr, A_BookValue_InstrNetAmt, /*BookAdjOp_BookInstrNetAmt, DDV - 980429 */
                           CAST_NUMBER(instrAmt - GET_NUMBER(extPosPtr, ExtPos_BookInstrNetAmt))); /* REF3288 - SSO - 990205 */

		SET_NUMBER(bookValuePtr, A_BookValue_SysNetAmt, /*BookAdjOp_BookSysNetAmt, DDV - 980429 */
                           CAST_NUMBER(sysAmt - GET_NUMBER(extPosPtr, ExtPos_BookSysNetAmt))); /* REF3288 - SSO - 990205 */
/* REF1987 - DDD - 980515 */
#if 0
		SET_NUMBER(bookValuePtr, A_BookValue_OpNetAmt, /*BookAdjOp_BookOpNetAmt, DDV - 980429 */
                           opAmt - GET_NUMBER(posValPtr, PosVal_PosNetAmt));

		SET_NUMBER(bookValuePtr, A_BookValue_InstrNetAmt, /*BookAdjOp_BookInstrNetAmt, DDV - 980429 */
                           instrAmt - GET_NUMBER(posValPtr, PosVal_InstrNetAmt));

		SET_NUMBER(bookValuePtr, A_BookValue_SysNetAmt, /*BookAdjOp_BookSysNetAmt, DDV - 980429 */
                           sysAmt - (ptfAmt / GET_EXCHANGE(extPosPtr, ExtPos_SysExchRate)));
#endif 
		break;

	case BookValAdjMethod_PtfCurrency:
		SET_NUMBER(bookValuePtr, A_BookValue_OpNetAmt, /*BookAdjOp_BookOpNetAmt,DDV - 980429 */
                   CAST_NUMBER(	GET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt) / /* REF3288 - SSO - 990205 */
					            GET_EXCHANGE(extPosPtr, ExtPos_PosExchRate)));

		SET_NUMBER(bookValuePtr, A_BookValue_InstrNetAmt, /*BookAdjOp_BookInstrNetAmt,DDV - 980429 */
                   CAST_NUMBER(	GET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt) / /* REF3288 - SSO - 990205 */
                           		GET_EXCHANGE(extPosPtr, ExtPos_InstrExchRate)));

		SET_NUMBER(bookValuePtr, A_BookValue_SysNetAmt, /*BookAdjOp_BookSysNetAmt, DDV - 980429 */
                   CAST_NUMBER(	GET_NUMBER(bookValuePtr, A_BookValue_PtfNetAmt) /  /* REF3288 - SSO - 990205 */
                           		GET_EXCHANGE(extPosPtr, ExtPos_SysExchRate)));
		break;
	}	

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CumulPtfSynth()
**
**  Description :   Cumul amounts from two synthetics
**                 
**  Arguments   :   cumulSynth	cumulated synthetics
**		    addSynth   	synthetics to add
**
**  Creation    :   DVP232 - RAK - 961115
**  Modif    	:   DVP261 - RAK - 961211
**  Modif    	:   BUG499 - RAK - 970908
**  Modif    	:   REF1008 - RAK - 980113
**  Modif    	:   REF4263 - CSY - 000127 transfer the function from file finsrv05.c
**                                         to file finlib02.c
**
*************************************************************************/
void FIN_CumulPtfSynth(DBA_DYNFLD_STP cumulSynth,
                       DBA_DYNFLD_STP addSynth,
                       char           mergePtfFlg)
{
    /* PMSTA-19044 - LJE - 141110 - Fund Splitting management */
    if (GET_ENUM(addSynth, A_PtfSynth_FundSplitNatEn) != FundSplitNat_Splitted)
    {

        AMOUNT_T amt;
        int	 field;

        /* PMSTA-52459 - DDV - 230414 - compute not invested days for initial_d */
        if (GET_INT(cumulSynth, A_PtfSynth_InitialNumDays) == GET_INT(addSynth, A_PtfSynth_InitialNumDays))
        {
            if (CMP_NUMBER(GET_NUMBER(cumulSynth, A_PtfSynth_InitialNotInvestedDays), GET_NUMBER(addSynth, A_PtfSynth_InitialNotInvestedDays)) != 0)
            {
				if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod ||
					(GET_NUMBER(cumulSynth, A_PtfSynth_InitialNotInvestedDays) > GET_NUMBER(addSynth, A_PtfSynth_InitialNotInvestedDays) &&
					 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod))
				{
					SET_NUMBER(cumulSynth, A_PtfSynth_InitialNotInvestedDays, GET_NUMBER(addSynth, A_PtfSynth_InitialNotInvestedDays));
				}
            }
        }
		/* WEALTH-2586 - DDV - 231012 - Take care of nipPeriod. If cumul is nip, used add not invested days. And check that add is not nip */
        else if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod &&
			     (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod ||
			      GET_INT(cumulSynth, A_PtfSynth_InitialNumDays) > GET_INT(addSynth, A_PtfSynth_InitialNumDays)))
        {
            SET_NUMBER(cumulSynth, A_PtfSynth_InitialNotInvestedDays, GET_NUMBER(addSynth, A_PtfSynth_InitialNotInvestedDays));
        }

        /* PMSTA-52459 - DDV - 230414 - compute not invested days for final_d */
        if (GET_INT(cumulSynth, A_PtfSynth_FinalNumDays) == GET_INT(addSynth, A_PtfSynth_FinalNumDays))
        {
            if (CMP_NUMBER(GET_NUMBER(cumulSynth, A_PtfSynth_FinalNotInvestedDays), GET_NUMBER(addSynth, A_PtfSynth_FinalNotInvestedDays)))
            {
				if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod ||
					(GET_NUMBER(cumulSynth, A_PtfSynth_FinalNotInvestedDays) > GET_NUMBER(addSynth, A_PtfSynth_FinalNotInvestedDays) &&
					 static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod))
				{
					SET_NUMBER(cumulSynth, A_PtfSynth_FinalNotInvestedDays, GET_NUMBER(addSynth, A_PtfSynth_FinalNotInvestedDays));
				}
            }
        }
		/* WEALTH-2586 - DDV - 231012 - Take care of nipPeriod. If cumul is nip, used add not invested days. And check that add is not nip */
		else if (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) != PerfCalcResultPeriodNatEn::NIPPeriod &&
			     (static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::NIPPeriod ||
			      GET_INT(cumulSynth, A_PtfSynth_FinalNumDays) > GET_INT(addSynth, A_PtfSynth_FinalNumDays)))
        {
            SET_NUMBER(cumulSynth, A_PtfSynth_FinalNotInvestedDays, GET_NUMBER(addSynth, A_PtfSynth_FinalNotInvestedDays));
        }

		/* PMSTA-52459 - DDV - 230414 - Compute period_nature_e for resulting PtfSynth */
		if ((static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod &&
			static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod) ||
			(static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::EndOfInvestedPeriod &&
				static_cast <PerfCalcResultPeriodNatEn> GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn) == PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod))
		{
			SET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn, PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
		}
		else if (GET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn) < GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn))
		{
			SET_ENUM(cumulSynth, A_PtfSynth_PeriodNatEn, GET_ENUM(addSynth, A_PtfSynth_PeriodNatEn));
		}

		/* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
		if (GET_FLAG(cumulSynth, A_PtfSynth_IntradayNIPFlg) == TRUE && 
			GET_FLAG(addSynth, A_PtfSynth_IntradayNIPFlg) == FALSE)
		{
			SET_FLAG(cumulSynth, A_PtfSynth_IntradayNIPFlg, FALSE);
		}

		/* ---------------------------------------------------------- */
        /* BUG499 - When cumulate synthetic to global or grid level,  */
        /* remember first flow of the portfolio or the market segment */
        if (GET_INT(addSynth, A_PtfSynth_FirstFlowNumDays) < GET_INT(cumulSynth, A_PtfSynth_FirstFlowNumDays) &&
            /* PMSTA-18200 - LJE - 140606 - Don't use the empty ptfSynth */
            GET_INT(addSynth, A_PtfSynth_FinalNumDays) >= GET_INT(cumulSynth, A_PtfSynth_InitialNumDays))
        {
            SET_INT(cumulSynth, A_PtfSynth_FirstFlowNumDays, GET_INT(addSynth, A_PtfSynth_FirstFlowNumDays));
        }

        /* PMSTA02541 - LJE - 070530 : Set the last last flow num days */
        if (GET_INT(addSynth, A_PtfSynth_LastFlowNumDays) >
            GET_INT(cumulSynth, A_PtfSynth_LastFlowNumDays))
        {
            SET_INT(cumulSynth, A_PtfSynth_LastFlowNumDays, GET_INT(addSynth, A_PtfSynth_LastFlowNumDays));
        }

        if (mergePtfFlg == TRUE)
        {
            if (DATETIME_CMP(GET_DATETIME(addSynth, A_PtfSynth_InitialDate),
                GET_DATETIME(cumulSynth, A_PtfSynth_InitialDate)) < 0)
            {
                SET_DATETIME(cumulSynth, A_PtfSynth_InitialDate,
                             GET_DATETIME(addSynth, A_PtfSynth_InitialDate));
            }

            if (GET_INT(addSynth, A_PtfSynth_InitialNumDays) < GET_INT(cumulSynth, A_PtfSynth_InitialNumDays))
            {
                SET_INT(cumulSynth, A_PtfSynth_InitialNumDays, GET_INT(addSynth, A_PtfSynth_InitialNumDays));
            }
        }
        /* ---------------------------------------------------------- */

		/* WEALTH-3119 - DDV - 231123 - Only when both PtfSynth are NIP cumul is NIP */
		if (GET_BIT(GET_TINYINT(addSynth, A_PtfSynth_Level), SynthLevel_InstrNIP) == FALSE)
		{
			SET_BIT(GET_TINYINT(cumulSynth, A_PtfSynth_Level), SynthLevel_InstrNIP, FALSE);
		}

        /* ----------------------------------------------------------- */
        /* REF1008  - When cumulate synthetic to global or grid level, */
        /* remember last flow of the portfolio or the market segment   */
        if (GET_INT(addSynth, A_PtfSynth_FinalNumDays) >
            GET_INT(cumulSynth, A_PtfSynth_FinalNumDays))
        {
            SET_INT(cumulSynth, A_PtfSynth_FinalNumDays,
                    GET_INT(addSynth, A_PtfSynth_FinalNumDays));
        }
        /* ----------------------------------------------------------- */

        for (field = A_PtfSynth_NetRealCapP;
             field <= A_PtfSynth_WeightGrossAdj; field++)
        {
            amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
            SET_AMOUNT(cumulSynth, field, amt);
        }

        for (field = A_PtfSynth_NetPurchases;
             field <= A_PtfSynth_FinUnrealPaidAI; field++)
        {
            amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
            SET_AMOUNT(cumulSynth, field, amt);
        }

        /* REF11269 - LJE - 060518 : Cumul pos fees and tax */ /* REF11269 - LJE - 060609 */
        field = A_PtfSynth_PosFees;
        amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
        SET_AMOUNT(cumulSynth, field, amt);

        field = A_PtfSynth_PosTax;
        amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
        SET_AMOUNT(cumulSynth, field, amt);

        field = A_PtfSynth_WeightPosFees;
        amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
        SET_AMOUNT(cumulSynth, field, amt);

		field = A_PtfSynth_WeightPosTax;
		amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
		SET_AMOUNT(cumulSynth, field, amt);

		/* WEALTH-8023 - DDV - 240701 - Cumul mktSeg/port in/out ajust counters */
		field = A_PtfSynth_MktSegInAdj;
        amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
        SET_AMOUNT(cumulSynth, field, amt);

		field = A_PtfSynth_MktSegOutAdj;
		amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
		SET_AMOUNT(cumulSynth, field, amt);

		field = A_PtfSynth_PtfInAdj;
		amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
		SET_AMOUNT(cumulSynth, field, amt);

		field = A_PtfSynth_PtfOutAdj;
		amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
		SET_AMOUNT(cumulSynth, field, amt);

        SET_NULL_NUMBER(cumulSynth, A_PtfSynth_Qty); /* REF9743 - LJE - 040301 */
        SET_NULL_NUMBER(cumulSynth, A_PtfSynth_Dura); /* PMSTA08736 - LJE - 100623 */
    }
}

/************************************************************************
**
**  Function    :   FIN_CumulPtfSynthCurrField()
**
**  Description :   Cumul  amounts from two synthetics in 8 currency fields.
**                  (A_PtfSynth_NetUnrealCurrP, etc...)
**                  
**                 
**  Arguments   :   cumulSynth	cumulated synthetics
**		            addSynth   	synthetics to add
**                  resetFlg:   if TRUE, set counter value to 0.0
**
**  Creation    :   REF6912 - CSY - 010810
**  
**
*************************************************************************/
void  FIN_CumulPtfSynthCurrField(DBA_DYNFLD_STP cumulSynth, 
			      DBA_DYNFLD_STP addSynth, FLAG_T   resetFlg)
{
	AMOUNT_T amt;
    int field;
    for (field=A_PtfSynth_NetRealCurrP;
	     field<=A_PtfSynth_NetUnrealCurrL; field++)
	{
        if (field != A_PtfSynth_NetRealCurrP && field != A_PtfSynth_NetRealCurrL
            && field != A_PtfSynth_NetUnrealCurrP && field != A_PtfSynth_NetUnrealCurrL
            && field != A_PtfSynth_GrossRealCurrP && field != A_PtfSynth_GrossRealCurrL
            && field != A_PtfSynth_GrossUnrealCurrP && field != A_PtfSynth_GrossUnrealCurrL)
            continue;

        if (resetFlg == TRUE)
        {
            SET_AMOUNT(cumulSynth, field, 0.0);
        }
        else
        {
	        amt = GET_AMOUNT(cumulSynth, field) + GET_AMOUNT(addSynth, field);
	        SET_AMOUNT(cumulSynth, field, amt);
        }
	}
}

/************************************************************************
**
**  Function    :   FIN_DelNoAcctNoRiskExtPosFromHier()
**
**  Description :   Filter All Extpos with value 0 in field ExtPos_AcctFlg
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-8736 - RAK - 100205
**  Modif	    : 
**
*************************************************************************/
RET_CODE FIN_DelNoAcctNoRiskExtPosFromHier(DBA_HIER_HEAD_STP hierHead)
{
    return(DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtPos, FIN_FilterNotAccNoRiskExtPos, NULLDYNST, NULL));
}

/************************************************************************
**
**  Function    :   FIN_FilterAllNotAccExtPos()
**
**  Description :   Filter All Extpos with value 0 in field ExtPos_AcctFlg
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-10800 - RAK - 101116
**  Modif	    :   PMSTA-12673 - PRS - 110830
**
*************************************************************************/
STATIC int FIN_FilterAllNotAccExtPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) 
{
	/* standard fut cash leg in portfolio */
    if (GET_FLAG(dynSt, ExtPos_AcctFlg) == FALSE && IS_NULLFLD(dynSt, ExtPos_FundSplitNatEn) == TRUE)
        return(TRUE);
	/* PMSTA12673-PRS-300811: cash account was being displayed when fund with futures in mutual portfolio was split. */
	/*                        Fix checks for FundSplitNat_None enum and filters/discards it (by returning TRUE).     */
	/*                        We are on a split but we won�t keep them because it is a fut cash leg.                 */
	else if (GET_FLAG(dynSt, ExtPos_AcctFlg) == FALSE && IS_NULLFLD(dynSt, ExtPos_FundSplitNatEn) == FALSE
		           && GET_ENUM(dynSt, ExtPos_FundSplitNatEn) == FundSplitNat_None)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_DelNoAcctExtPosFromHier()
**
**  Description :   Filter All Extpos with value 0 in field ExtPos_AcctFlg
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-10800 - RAK - 101116
**  Modif	    : 
**
*************************************************************************/
RET_CODE FIN_DelNoAcctExtPosFromHier(DBA_HIER_HEAD_STP hierHead)
{
    return(DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtPos, FIN_FilterAllNotAccExtPos, NULLDYNST, NULL));
}

/************************************************************************
**
**  Function    :   FIN_FilterNotAccENoRiskxtPos()
**
**  Description :   Filter All Extpos with value 0 in field ExtPos_AcctFlg
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-8736 - RAK - 100205
**  Modif	    : 
**
*************************************************************************/
STATIC int FIN_FilterNotAccNoRiskExtPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	if (GET_FLAG(dynSt, ExtPos_AcctFlg) == FALSE && IS_NULLFLD(dynSt, ExtPos_FundSplitNatEn) == TRUE &&
		GET_ENUM(dynSt, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk) 
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfDate()
**
**  Description :   Synthetics sorted by portfolio id, date
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   DVP261 - RAK - 961121
**
*************************************************************************/
int FIN_CmpPtfSynthPtfDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Date */
	    return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate), 
		                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_GetStratEltFromStratIdTab()
**
**  Description :   get the valid strategy histories from all treated strategies
**                 
**  Arguments   :   hierHead	hierarchy header pointer
**                  stratNbr	number of strat id's in stratTab
**                  stratTab	strat id array
**                  stratEltNbr	number of stratElt in stratEltTab
**                  stratEltTab	pointer on dynamic structure array pointer to allocate and fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation  	:   DVP9658 - CHU - 040206
**
*************************************************************************/
RET_CODE FIN_GetStratEltFromStratIdTab(DBA_HIER_HEAD_STP	hierHead,
									   DBA_DYNFLD_STP		refStratPtr,	/* REF10274 - RAK - 040512 */
									   int					stratIdNbr,
									   ID_T					*stratIdTab,
									   int					*stratEltNbr,
									   DBA_DYNFLD_STP		**stratEltTab)
{
	int				i, j;
	int				tmpStratEltNbr=0, crtStratNbr=0;

	DBA_DYNFLD_STP	*tmpStratEltTab=NULLDYNSTPTR, *crtStratTab=NULLDYNSTPTR;

	DBA_DYNFLD_STP	stratPtr		= NULLDYNST;
	DBA_DYNFLD_STP	stratHistPtr	= NULLDYNST;
	DBA_DYNFLD_STP  paramStp		= NULLDYNST;

	FLAG_T			freeTmpStratEltFlg=FALSE;

	RET_CODE		ret				= RET_SUCCEED;
	HIER_CMPFCT		*compFct		= NULLFCT;

	/* reset number of records to zero */
	*stratEltNbr = 0;

	if ((paramStp = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	/* loop on every strategy processed in FIN_BenchReturn() */
	for (i=0; i < stratIdNbr; i++)
	{
		/* Get Strategy record */
		/* REF10274 - RAK - 040512 - Use refStratId (we have to use an extract) */
		/* if((stratPtr = DBA_SearchHierRecById(hierHead, A_Strat,
						  A_Strat_Id, stratIdTab[i])) == NULLDYNST)
		{
			continue;
		} */

		crtStratNbr = 0;
		SET_ID(paramStp, Get_Arg_Id, stratIdTab[i]);
		SET_ID(paramStp, Get_Arg_RefCurrId, GET_ID(refStratPtr, A_Strat_RefStratId));
			
		if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
												A_Strat, 
												FALSE,
												FIN_FilterStratByIdAndRefStratId,
												paramStp,
												NULLFCT,
												&crtStratNbr,
												&crtStratTab)) != RET_SUCCEED || crtStratNbr != 1)
		{
			continue;
		}

		stratPtr = crtStratTab[0];
		FREE(crtStratTab);		

		/* set comparison function pointer */
		if(GET_ENUM(stratPtr, A_Strat_NatEn) == (STRATNAT_ENUM)StratNat_ModelPtf)
		{
			/* if one of these strategies is a MP, records must be sorted */
			compFct = FIN_CmpSEByMktSegt;
		}

		/* get strategy history of current strategy */
		if (IS_NULLFLD(stratPtr, A_Strat_A_StratHist_Ext) == FALSE &&		/* REF11821 - CHU - 060629 */
			GET_EXTENSION_PTR(stratPtr, A_Strat_A_StratHist_Ext) != NULL &&	/* REF11821 - CHU - 060629 */
			(stratHistPtr = *(GET_EXTENSION_PTR(stratPtr, A_Strat_A_StratHist_Ext))) != NULLDYNST)
		{
			/* REF10274 - RAK - 040512 */
			/* Use extension which is built according to RefStratId (if exist) */
			/* and add test on RefStratId in filter fct */  
			freeTmpStratEltFlg = FALSE;
			tmpStratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
            tmpStratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

			if (tmpStratEltNbr == 0)
			{
			/* extract the strategy elements of the strategy history */
			if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
												A_StratElt, 
												FALSE,
												FIN_FilterStratEltByStratHistId,
												stratHistPtr,
												NULLFCT,
												&tmpStratEltNbr,
												&tmpStratEltTab)) != RET_SUCCEED)
			{
				FREE(tmpStratEltTab);
				return(ret);
			}

				freeTmpStratEltFlg = TRUE;
			}

			/* (re-)allocate space to store output records */
			if (i == 0)
				(*stratEltTab) = (DBA_DYNFLD_STP *)CALLOC(tmpStratEltNbr, sizeof(DBA_DYNFLD_STP *));
			else
				(*stratEltTab) = (DBA_DYNFLD_STP *)REALLOC((*stratEltTab),
													((*stratEltNbr)+tmpStratEltNbr) * sizeof(DBA_DYNFLD_STP));

			/* store output records */
			for (j=0; j < tmpStratEltNbr; j++)
				(*stratEltTab)[(*stratEltNbr) + j] = tmpStratEltTab[j];

			/* initialize total number of records */
			*stratEltNbr += tmpStratEltNbr;

			/* initialize pointer and number for next loop, if any */
			if (freeTmpStratEltFlg == TRUE) {FREE(tmpStratEltTab)};	/* REF10274 - RAK - 040512 - test on flag */
			tmpStratEltNbr = 0;
		}
	}

	FREE_DYNST(paramStp, Get_Arg);		/* REF10274 - RAK - 040512 */

	/* sort records if necessary, but do we have to sort all records ? */
	/* initially, only records coming from a model portfolio were sorted... */
	if (compFct != NULLFCT)
	{
		TLS_Sort((char*) (*stratEltTab), (*stratEltNbr), sizeof(DBA_DYNFLD_STP), 
				(TLS_CMPFCT *)compFct, (PTR**)NULL, SortRtnTp_None);
	}
	return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpSEByMktSegt()
**
**  Description :   strategy element table is sort by asc. market segment id,
**                  instr_id not null put first.
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_DerivedStratElt
**                  ptr2   pointer on dynamic structure type A_DerivedStratElt
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation	:   REF6025 - CSY - 020521
**
*************************************************************************/
int FIN_CmpSEByMktSegt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    
    if (GET_ID((*ptr1), A_StratElt_MktSegtId) == GET_ID((*ptr2), A_StratElt_MktSegtId))
    {
        if(IS_NULLFLD((*ptr1), A_StratElt_InstrId) == TRUE && 
            IS_NULLFLD((*ptr2), A_StratElt_InstrId) == FALSE)
        {
            return(1);  /* instr_id null: put at the end */
        }
        else 
        {
            return(-1);
        }
    }
    return(CMP_ID(GET_ID((*ptr1), A_StratElt_MktSegtId) , GET_ID((*ptr2), A_StratElt_MktSegtId))); /* DLA - REF9089 - 030509 */
}

/*************************************************************************************************
*
*  Function          : FIN_FilterDerivedStratElt()  
*
*  Description       : filter function used to find  A_DerivedStratElt by market segment id, derived strategy  id,
*                      and other criterias meaning the A_DerivedStratElt is not an index.
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6025 - CSY - 010628
*  Last modification :
*
**************************************************************************************************/
int FIN_FilterDerivedStratElt(DBA_DYNFLD_STP dynSt,
							  DBA_DYNST_ENUM dynStTp,
							  DBA_DYNFLD_STP admArgIn)
{
    if ( GET_ID(dynSt, A_DerivedStratElt_DerivedStratId) ==  GET_ID(admArgIn,   Adm_Arg_UserId)  /* derived strategy  id */
                                &&
		 GET_ID(dynSt, A_DerivedStratElt_MktSgtId) == GET_ID(admArgIn,   Adm_Arg_CodifId) /* market segment id */
                                &&
         /* filter elements that are not an index: value != 100, no bench_object_id, nature == weight */
         (IS_NULLFLD(dynSt, A_DerivedStratElt_BenchObjId) == TRUE) &&
         (CMP_NUMBER(GET_NUMBER(dynSt, A_DerivedStratElt_Weight), 100.0) != 0) &&
         ((STRATELTNAT_ENUM)GET_ENUM(dynSt, A_DerivedStratElt_NatEn) == (STRATELTNAT_ENUM)StratEltNat_Weight)
         )
		return(TRUE);
	else   
    	return(FALSE);
}

/*************************************************************************************************
*
*  Function          : FIN_FilterDerivedStratElt3()  
*
*  Description       : filter function used to find  A_DerivedStratElt by market segment id
*                      and derived strategy id
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6082 - CSY - 020122
*  Last modification :
*
**************************************************************************************************/
int FIN_FilterDerivedStratElt3(DBA_DYNFLD_STP dynSt,
							   DBA_DYNST_ENUM dynStTp,
							   DBA_DYNFLD_STP admArgIn)
{
    if (GET_ID(dynSt, A_DerivedStratElt_DerivedStratId) ==  GET_ID(admArgIn,   Adm_Arg_UserId) /* derived strategy  id */
                                &&    
		 GET_ID(dynSt, A_DerivedStratElt_MktSgtId) == GET_ID(admArgIn,   Adm_Arg_CodifId) /* market segment id */

         
         )
		return(TRUE);
	else   
    	return(FALSE);
}

/*************************************************************************************************
*
*  Function          : FIN_FilterDerivedStratElt4()  
*
*  Description       : filter function used to find  A_DerivedStratElt by market segment id
*
*  Arguments         : dynSt :      
*                      dynStTp:     
*                      admArgIn:    :
*
*  Return            : TRUE/FALSE
*
*  Creation date     : REF6082 - CSY - 020325
*  Last modification :
*
**************************************************************************************************/
int FIN_FilterDerivedStratElt4(DBA_DYNFLD_STP dynSt,
							   DBA_DYNST_ENUM dynStTp,
							   DBA_DYNFLD_STP admArgIn)
{
    if (GET_ID(dynSt, A_DerivedStratElt_MktSgtId) == GET_ID(admArgIn,   Adm_Arg_CodifId)) /* market segment id */        
		return(TRUE);
	else   
    	return(FALSE);
}

/************************************************************************
*   Function             : FIN_IsEmptyPtfSynth()
*
*   Description          : Determines whether the data is emptyase
*
*   Arguments            : ptfSynthStp to test
* 			               
*                         
*   Return               : TRUE if the ptf synth 
*
*   Creation             : PMSTA-18200 - LJE - 140605
*   Modif                :
*  
*************************************************************************/
FLAG_T FIN_IsEmptyPtfSynth(DBA_DYNFLD_STP ptfSynthStp)
{
	if (CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_FinalMktVal), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
	    CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_InitialMktVal), 0.0, 
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
        CMP_NUMBER(GET_NUMBER(ptfSynthStp, A_PtfSynth_Qty), 0.0) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetSales), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
	    CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossSales), 0.0, 
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetPurchases), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
	    CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossPurchases), 0.0, 
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetInvest), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossInvest), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetWithdr), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossWithdr), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_TaxCred), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetAdj), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossAdj), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetRecInc), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossRecInc), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetPaidInc), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_GrossPaidInc), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_PtfFees), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_PtfTax), 0.0,
			       GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetCostVal), 0.0,		/* PMSTA-51654 - SIRI - 10312023 -Added few more null checks for the data consideration */
				   GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetRealCapP), 0.0,
				   GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetRealCapL), 0.0,
				   GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetRealCurrP), 0.0,
				   GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0 &&
		CMP_AMOUNT(GET_AMOUNT(ptfSynthStp, A_PtfSynth_NetRealCurrL), 0.0,
				   GET_ID(ptfSynthStp, A_PtfSynth_CurrId)) == 0)
    {
        return TRUE;
    }

    return FALSE;
}                       
/************************************************************************
**
**  Function    :  FIN_RealisedlPL()
**
**  Description :  Computes profit and loss for received position.
**
**  Arguments   :  pos            position
**                 PLNatEn        P&L nature (total, capital, currency)
**                 grossPLFlg     gross or net P&L
**                 portPLCompRule indicates how to post the currency gains on the capital gains
**                 currPLCompRule indicates whether the capital gain is computed in the
**                                instrument currency or the position currency
**
**  Return      :  desired amount expressed in the "reference currency" of the position
**
**  Creation    :  KD-19323 - AIS 220704
**
**
*************************************************************************/
double FIN_RealisedPL(DBA_DYNFLD_STP      pos,
                      PLNAT_ENUM          PLNatEn,
                      FLAG_T              grossPLFlg,
                      RealisedPLCalcRuleEn calcRuleEn,
                      DBA_DYNFLD_STP domain,
                      DBA_HIER_HEAD_STP hierHead,
                      DATETIME_ST cutOverD)
{
 
    DBA_DYNFLD_STP  getArg = NULLDYNST,
                    outAmount = NULLDYNST,
                    instrPtr = NULLDYNST, 
                    ptfPtr = NULLDYNST,
                    underlyInstrPtr = NULLDYNST;
    ID_T            underlyInstrId = ZERO_ID;
    INSTRNAT_ENUM   instrNat, underlayInstrNat;
    FLAG_T          noCapPLFlg = FALSE;
    MemoryPool      mp;
    DbiConnectionHelper dbiConnHelper;
    RET_CODE            ret = RET_SUCCEED;

    /* BUG138 - No P&L on balance positions */
    if (IS_NULLFLD(pos, ExtPos_BalPosTpId) == FALSE)
        return(0.0);

    if (IS_NULLFLD(pos, ExtPos_A_Instr_Ext) == FALSE)
    {
        instrPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext));
    }
    else
    {
		FLAG_T allocInstrFlg = FALSE;
        ret = DBA_GetInstrById(GET_ID(pos, ExtPos_InstrId), FALSE, &allocInstrFlg,
            &instrPtr, NULL, UNUSED, UNUSED);

		if(allocInstrFlg == TRUE)
		{
		    mp.ownerDynStp(instrPtr);
		}

        if(ret != RET_SUCCEED)
        {			
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(pos, ExtPos_InstrId));
            return (0.0);
        }
    }

    instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);

    if (instrNat == InstrNat_Option)
    {
        if ((underlyInstrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId)) != ZERO_ID)
        {
			FLAG_T allocUnderFlg = FALSE;
            ret = DBA_GetInstrById(underlyInstrId, FALSE, &allocUnderFlg,
                &underlyInstrPtr, NULL, UNUSED, UNUSED);

			if(allocUnderFlg == TRUE)
			{
			    mp.ownerDynStp(underlyInstrPtr);
			}

            if(ret != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(pos, ExtPos_InstrId));
                return (0.0);
            }
            underlayInstrNat = (INSTRNAT_ENUM)GET_ENUM(underlyInstrPtr, A_Instr_NatEn);
            if (underlayInstrNat == InstrNat_CashAcct && underlyInstrId != GET_ID(instrPtr, A_Instr_RefCurrId))
            {
                noCapPLFlg = TRUE;
            }
        }
    }
    else if (GET_FLAG(pos, ExtPos_MainFlg) == TRUE &&
        ((POSREFNAT_ENUM)GET_ENUM(pos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
          (POSREFNAT_ENUM)GET_ENUM(pos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
    {
        noCapPLFlg = TRUE;
    }

    if (noCapPLFlg == TRUE)
    {
        return(0.0);
    }

    getArg = mp.allocDynst(FILEINFO, Get_Arg);
    outAmount = mp.allocDynst(FILEINFO, Out_Amount);

    SET_ID(getArg, Get_Arg_PtfId, GET_ID(pos, ExtPos_PtfId));
    SET_ID(getArg, Get_Arg_InstrId, GET_ID(pos, ExtPos_InstrId));
    SET_DATETIME(getArg, Get_Arg_DateTime, GET_DATETIME(domain, A_Domain_InterpTillDate));
    SET_ENUM(getArg, Get_Arg_Enum1, calcRuleEn);
    SET_FLAG(getArg, Get_Arg_Flag, grossPLFlg);
    SET_ENUM(getArg, Get_Arg_Enum2, PLNatEn);
    
    if(cutOverD.date != 0)
        SET_DATETIME(getArg, Get_Arg_DateTime2, cutOverD);

    if (GET_ID(getArg, Get_Arg_PtfId) <= ZERO_ID || 
		GET_ID(getArg, Get_Arg_InstrId) <= ZERO_ID ||
		IS_NULLFLD(getArg, Get_Arg_DateTime) ||
		(ret = dbiConnHelper.dbaGet(BalPos, UNUSED, getArg, &outAmount)) != RET_SUCCEED)
    {
        return(0.0);
    }

    if (IS_NULLFLD(pos, ExtPos_A_Ptf_Ext) == FALSE)
    {
        ptfPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Ptf_Ext));
    }
    else
    {
		FLAG_T allocPtfPtrFlg = FALSE;
        ret = DBA_GetPtfById(GET_ID(pos, ExtPos_PtfId), FALSE, &allocPtfPtrFlg,
            &ptfPtr, hierHead, UNUSED, UNUSED);

		if(allocPtfPtrFlg == TRUE)
		{
		    mp.ownerDynStp(ptfPtr);
		}

        if(ret != RET_SUCCEED)
        {
            return(0.0);
        }
    }
    if (ptfPtr != NULLDYNST && GET_ID(ptfPtr, A_Ptf_CurrId) != GET_ID(domain, A_Domain_CurrId)
        && GET_AMOUNT(outAmount, Out_Amount_Amount) != 0.0)
    {
        FIN_EXCHARG_ST exchArgSt;
        memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
        AMOUNT_T	   newCalcAmount = (AMOUNT_T)0;
        exchArgSt.srcAmt = GET_AMOUNT(outAmount, Out_Amount_Amount);

        if (FIN_ExchAmt(GET_DATETIME(domain, A_Domain_InterpTillDate), GET_ID(ptfPtr, A_Ptf_CurrId),
            GET_ID(domain, A_Domain_CurrId), (ID_T)0, NULLDYNST, NULLDYNST,
            &exchArgSt, (EXCHANGE_T*)NULL, &newCalcAmount, (EXCHANGE_T*)NULL) == RET_SUCCEED)
        {
            SET_LONGAMOUNT(outAmount, Out_Amount_Amount, newCalcAmount);
        }
    }

    return(CAST_AMOUNT(GET_AMOUNT(outAmount, Out_Amount_Amount), GET_ID(domain, A_Domain_CurrId)));
}

/************************************************************************
**
**  Function    :   FIN_FilterDomainPerfCompPeriod()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
STATIC int FIN_FilterDomainPerfCompPeriod(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
	return(static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt, S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::Domain);
}

/************************************************************************
**
**  Function    :   FIN_CmpPerfCompuPeriodByPtfDate()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
STATIC int FIN_CmpPerfCompuPeriodByPtfDate(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
	int cmp;

	if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_PtfId, S_PerfComputationPeriod_PtfId, IdType)) != 0)
	{
		return(cmp);
	}

	return(CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_BeginDate, S_PerfComputationPeriod_BeginDate, DateType));
}

/************************************************************************
**
**  Function    :   FIN_CmpPerfCompuPeriodByParentPtfDate()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
STATIC int FIN_CmpPerfCompuPeriodByParentPtfDate(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
	int cmp;

	if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_ParentPortId, S_PerfComputationPeriod_ParentPortId, IdType)) != 0)
	{
		return(cmp);
	}

	return(CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_BeginDate, S_PerfComputationPeriod_BeginDate, DateType));
}

/************************************************************************
**
**  Function    :   FIN_CmpPerfCompuPeriodByHierPtfDate()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
STATIC int FIN_CmpPerfCompuPeriodByHierPtfDate(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
	int cmp;

	if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_HierPortId, S_PerfComputationPeriod_HierPortId, IdType)) != 0)
	{
		return(cmp);
	}

	return(CMP_DYNFLD((*ptr1), (*ptr2), S_PerfComputationPeriod_BeginDate, S_PerfComputationPeriod_BeginDate, DateType));
}

/************************************************************************
**
**  Function    :   FIN_FindParentPortfolioByDt()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
RET_CODE FIN_FindParentPortfolioByDt(DBA_DYNFLD_STP      domainPtr,
	                                 ID_T                ptfId,
	                                 DBA_DYNFLD_STP      ptfStpParam,
	                                 DATE_T              histDate,
	                                 DBA_HIER_HEAD_STP   hierHead,
	                                 ID_T& parentPtfId,
	                                 DATE_T& validTillDate)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	parentPtfId = 0;
	validTillDate = 0;

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);

		if (allocFlg == TRUE)
		{
			mp.ownerDynStp(ptfStp);
		}
	}

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* parentPCPTab = NULLDYNSTPTR;
		int             parentPCPNbr = 0;

		if (((parentPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((parentPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) > 0))
		{
			for (int i = 0; i < parentPCPNbr; ++i)
			{
				if (GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_EndDate) >= histDate)
				{
					parentPtfId = GET_ID(parentPCPTab[i], S_PerfComputationPeriod_ParentPortId);
					validTillDate = GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_EndDate);
					break;
				}
			}
			return(RET_SUCCEED);
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate) <= histDate)
			{
				++i;
			}

			if (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_BeginDate) <= histDate)
			{
				parentPtfId = GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId);
				validTillDate = GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate);
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			parentPtfId = GET_ID(ptfStp, A_Ptf_ParentPortId);
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FindHierPortfolioByDt()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification :
**
*************************************************************************/
RET_CODE FIN_FindHierPortfolioByDt(DBA_DYNFLD_STP      domainPtr,
	                               ID_T                ptfId,
	                               DBA_DYNFLD_STP      ptfStpParam,
	                               DATE_T              histDate,
	                               DBA_HIER_HEAD_STP   hierHead,
	                               ID_T& hierPtfId,
	                               DATE_T& validTillDate)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	hierPtfId = 0;
	validTillDate = 0;

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);

		if (allocFlg == TRUE)
		{
			mp.ownerDynStp(ptfStp);
		}
	}

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* parentPCPTab = NULLDYNSTPTR;
		int             parentPCPNbr = 0;

		if (((parentPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((parentPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) > 0))
		{
			for (int i = 0; i < parentPCPNbr; ++i)
			{
				if (GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_EndDate) >= histDate)
				{
					hierPtfId = GET_ID(parentPCPTab[i], S_PerfComputationPeriod_HierPortId);
					validTillDate = GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_EndDate);
					break;
				}
			}
			return(RET_SUCCEED);
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate) <= histDate)
			{
				++i;
			}

			if (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_BeginDate) <= histDate)
			{
				hierPtfId = GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId);
				validTillDate = GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate);
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			hierPtfId = GET_ID(ptfStp, A_Ptf_HierPortId);
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FindChildrenPortfolioByDt()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
RET_CODE FIN_FindChildrenPortfolioByDt(DBA_DYNFLD_STP      domainPtr,
	                                   ID_T                ptfId,
	                                   DBA_DYNFLD_STP      ptfStpParam,
	                                   DATE_T              histDate,
	                                   DBA_HIER_HEAD_STP   hierHead,
	                                   DBA_DYNFLD_STP** childrenTab,
	                                   int* childrenNbr)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	*childrenTab = NULLDYNSTPTR;
	*childrenNbr = 0;

	if (histDate == 0)
	{
		return(ret);
	}

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);

		if (allocFlg == TRUE)
		{
			mp.ownerDynStp(ptfStp);
		}
	}

	DBA_DYNFLD_STP  childPtf = NULLDYNST;

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* childrenPCPTab = NULLDYNSTPTR;
		int             childrenPCPNbr = 0;

		if (ptfStp != NULLDYNST &&
			((childrenPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ChildrenHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((childrenPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ChildrenHistoPCP_Ext)) > 0))
		{
			*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(childrenPCPNbr, sizeof(DBA_DYNFLD_STP)));

			for (int i = 0; i < childrenPCPNbr; ++i)
			{
				if (GET_DATE(childrenPCPTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(childrenPCPTab[i], S_PerfComputationPeriod_EndDate) >= histDate)
				{
					if (GET_EXTENSION_PTR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
						GET_EXTENSION_NBR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
						(childPtf = *GET_EXTENSION_PTR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
					{
						*childrenTab[(*childrenNbr)++] = childPtf;
					}
				}
			}
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByParentPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(perfCompPeriodNbr, sizeof(DBA_DYNFLD_STP)));

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId) == ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId) == ptfId)
			{
				if (GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate) >= histDate &&
					GET_EXTENSION_PTR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
					GET_EXTENSION_NBR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
					(childPtf = *GET_EXTENSION_PTR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
				{
					*childrenTab[(*childrenNbr)++] = childPtf;
				}
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			DBA_DYNFLD_STP* childrenPtfTab = NULLDYNSTPTR;
			int             childrenPtfNbr = 0;

			if ((((childrenPtfTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ChildrenPtf_Ext)) != NULLDYNSTPTR) &&
				(childrenPtfNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ChildrenPtf_Ext)) > 0) ||
				(((childrenPtfTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_HierChildrenPtf_Ext)) != NULLDYNSTPTR) &&
					(childrenPtfNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_HierChildrenPtf_Ext)) > 0))
			{

				if ((*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(childrenPtfNbr, sizeof(DBA_DYNFLD_STP)))) != NULLDYNSTPTR)
				{
					for (int i = 0; i < childrenPtfNbr; ++i)
					{
						if (GET_EXTENSION_PTR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
							GET_EXTENSION_NBR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
							(childPtf = *GET_EXTENSION_PTR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
						{
							*childrenTab[(*childrenNbr)++] = childPtf;
						}
					}
				}
			}
		}
	}

	if (*childrenNbr == 0 && *childrenTab != NULLDYNSTPTR)
	{
		FREE(*childrenTab);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FindHierChildrenPortfolioByDt()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
RET_CODE FIN_FindHierChildrenPortfolioByDt(DBA_DYNFLD_STP      domainPtr,
	                                       ID_T                ptfId,
	                                       DBA_DYNFLD_STP      ptfStpParam,
	                                       DATE_T              histDate,
	                                       DBA_HIER_HEAD_STP   hierHead,
	                                       DBA_DYNFLD_STP** childrenTab,
	                                       int* childrenNbr)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	*childrenTab = NULLDYNSTPTR;
	*childrenNbr = 0;

	if (histDate == 0)
	{
		return(ret);
	}

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);

		if (allocFlg == TRUE)
		{
			mp.ownerDynStp(ptfStp);
		}
	}

	DBA_DYNFLD_STP  childPtf = NULLDYNST;

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* childrenPCPTab = NULLDYNSTPTR;
		int             childrenPCPNbr = 0;

		if (ptfStp != NULLDYNST &&
			((childrenPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_AllHierChildrenHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((childrenPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_AllHierChildrenHistoPCP_Ext)) > 0))
		{
			*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(childrenPCPNbr, sizeof(DBA_DYNFLD_STP)));

			for (int i = 0; i < childrenPCPNbr; ++i)
			{
				if (GET_DATE(childrenPCPTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(childrenPCPTab[i], S_PerfComputationPeriod_EndDate) >= histDate)
				{
					if (GET_EXTENSION_PTR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
						GET_EXTENSION_NBR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
						(childPtf = *GET_EXTENSION_PTR(childrenPCPTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
					{
						*childrenTab[(*childrenNbr)++] = childPtf;
					}
				}
			}
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByHierPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(perfCompPeriodNbr, sizeof(DBA_DYNFLD_STP)));

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId) == ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId) == ptfId)
			{
				if (GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate) >= histDate &&
					GET_EXTENSION_PTR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
					GET_EXTENSION_NBR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
					(childPtf = *GET_EXTENSION_PTR(perfCompPeriodTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
				{
					*childrenTab[(*childrenNbr)++] = childPtf;
				}
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			DBA_DYNFLD_STP* childrenPtfTab = NULLDYNSTPTR;
			int             childrenPtfNbr = 0;

			if ((((childrenPtfTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ChildrenPtf_Ext)) != NULLDYNSTPTR) &&
				(childrenPtfNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ChildrenPtf_Ext)) > 0) ||
				(((childrenPtfTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_HierChildrenPtf_Ext)) != NULLDYNSTPTR) &&
					(childrenPtfNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_HierChildrenPtf_Ext)) > 0))
			{

				if ((*childrenTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(childrenPtfNbr, sizeof(DBA_DYNFLD_STP)))) != NULLDYNSTPTR)
				{
					for (int i = 0; i < childrenPtfNbr; ++i)
					{
						if (GET_EXTENSION_PTR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext) != NULLDYNSTPTR &&
							GET_EXTENSION_NBR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext) > 0 &&
							(childPtf = *GET_EXTENSION_PTR(childrenPtfTab[i], S_PerfComputationPeriod_Ptf_Ext)) != NULLDYNST)
						{
							*childrenTab[(*childrenNbr)++] = childPtf;
						}
					}
				}
			}
		}
	}

	if (*childrenNbr == 0 && *childrenTab != NULLDYNSTPTR)
	{
		FREE(*childrenTab);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_IsHeadPortfolio()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
bool FIN_IsHeadPortfolioByDt(DBA_DYNFLD_STP      domainPtr,
	                         ID_T                ptfId,
	                         DBA_DYNFLD_STP      ptfStpParam,
	                         DATE_T              histDate,
	                         DBA_HIER_HEAD_STP   hierHead)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	if (histDate == 0)
	{
		return(ret);
	}

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);
	}

	if (allocFlg == TRUE)
	{
		mp.ownerDynStp(ptfStp);
	}

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* parentPCPTab = NULLDYNSTPTR;
		int             parentPCPNbr = 0;

		if (ptfStp != NULLDYNST &&
			((parentPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((parentPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) > 0))
		{
			for (int i = 0; i < parentPCPNbr; ++i)
			{
				if (GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_BeginDate) <= histDate &&
					GET_DATE(parentPCPTab[i], S_PerfComputationPeriod_EndDate) >= histDate)
				{
					return(false);
				}
			}
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_EndDate) <= histDate)
			{
				++i;
			}

			if (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_PtfId) == ptfId &&
				GET_DATE(perfCompPeriodTab[i], S_PerfComputationPeriod_BeginDate) <= histDate)
			{
				return(false);
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			if (GET_ID(ptfStp, A_Ptf_ParentPortId) != 0 ||
				GET_ID(ptfStp, A_Ptf_HierPortId) != 0)
			{
				return(false);
			}
		}
	}

	return(true);
}

/************************************************************************
**
**  Function    :   FIN_FindHierParentPortfolio()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-16752 - DDV - 241120
**
**  Modification:
**
*************************************************************************/
RET_CODE FIN_FindHierParentPortfolio(DBA_DYNFLD_STP      domainPtr,
	                                 ID_T                ptfId,
	                                 DBA_DYNFLD_STP      ptfStpParam,
	                                 DBA_HIER_HEAD_STP   hierHead,
	                                 DBA_DYNFLD_STP**    hierParentPtfTab,
	                                 int*                hierParentPtfNbr)
{
	RET_CODE        ret = RET_SUCCEED;
	MemoryPool      mp;

	DBA_DYNFLD_STP  ptfStp = ptfStpParam;
	FLAG_T          allocFlg = FALSE;

	*hierParentPtfTab = NULLDYNSTPTR;
	*hierParentPtfNbr = 0;

	if (ptfStp == NULLDYNST)
	{
		DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfStp, NULL, UNUSED, UNUSED);

		if (allocFlg == TRUE)
		{
			mp.ownerDynStp(ptfStp);
		}
	}

	std::set < DBA_DYNFLD_STP> hierParentPtfSet;

	if (GET_ENUM(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
	{
		DBA_DYNFLD_STP* parentPCPTab = NULLDYNSTPTR;
		int             parentPCPNbr = 0;

		if (ptfStp != NULLDYNST &&
			((parentPCPTab = GET_EXTENSION_PTR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) != NULLDYNSTPTR) &&
			((parentPCPNbr = GET_EXTENSION_NBR(ptfStp, A_Ptf_ParentHistoPCP_Ext)) > 0))
		{
			for (int i = 0; i < parentPCPNbr; ++i)
			{
				if (GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) != NULLDYNSTPTR &&
					*GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) != NULLDYNST &&
					GET_EXTENSION_NBR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) > 0)
				{
					hierParentPtfSet.insert(*GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext));
				}
			}
		}
		else
		{
			DBA_DYNFLD_STP* perfCompPeriodTab = nullptr;
			int             perfCompPeriodNbr = 0;

			DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterDomainPerfCompPeriod, FIN_CmpPerfCompuPeriodByHierPtfDate, &perfCompPeriodNbr, &perfCompPeriodTab);
			mp.ownerPtr(perfCompPeriodTab);

			int i = 0;
			while (i < perfCompPeriodNbr && GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId) < ptfId)
			{
				++i;
			}

			while (i < perfCompPeriodNbr &&
				GET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId) == ptfId)
			{
				if (GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) != NULLDYNSTPTR &&
					*GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) != NULLDYNST &&
					GET_EXTENSION_NBR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext) > 0)
				{
					hierParentPtfSet.insert(*GET_EXTENSION_PTR(parentPCPTab[i], S_PerfComputationPeriod_HierPtf_Ext));
				}
			}
		}
	}
	else
	{
		if (ptfStp != NULLDYNST)
		{
			if (GET_EXTENSION_PTR(ptfStp, A_Ptf_HierPtf_Ext) != NULLDYNSTPTR &&
				*GET_EXTENSION_PTR(ptfStp, A_Ptf_HierPtf_Ext) != NULLDYNST &&
				GET_EXTENSION_NBR(ptfStp, A_Ptf_HierPtf_Ext) > 0)
			{
				hierParentPtfSet.insert(*GET_EXTENSION_PTR(ptfStp, A_Ptf_HierPtf_Ext));
			}
		}
	}

	if (hierParentPtfSet.size() > 0)
	{ 
		if ((*hierParentPtfTab = static_cast <DBA_DYNFLD_STP*> (CALLOC(hierParentPtfSet.size(), sizeof(DBA_DYNFLD_STP)))) != NULLDYNSTPTR)
		{
			for (auto& it : hierParentPtfSet)
			{
				*hierParentPtfTab[(*hierParentPtfNbr)++] = it;
			}
		}
	}

	return(ret);
}

/************************************************************************
**      END  finlib02.c                                          UNICIBLE
*************************************************************************/

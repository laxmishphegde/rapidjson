/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB06_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "fin.h"

#include "dbiconnection.h"     /* PMSTA-23226 - LJE - 160517 */
#include "dbisqlexecbyblock.h" /* PMSTA-23226 - LJE - 160517 */

EXTERN RET_CODE FIN_GetExcludedMarketSegments(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, std::vector<ID_T> &);  /* PMSTA - 39969 - sanand - 05052020 */
/************************************************************************
**
**		FIN_StratCreateESEHeader		Create total line.
**		FIN_StratHeaderGetWeight		Get current weight (reading parent if necessary).
**		FIN_StratGetParMktSgtInfo		Get parent market segment information and update ExtStratElt.
**		FIN_StratCreateESEAlloc			Create extended strategy elements for allocation.
**		FIN_StratSetValueAndMargin		Update field, margin field, contrib field and margin contrib field.
**		FIN_StratUpdESEAlloc			Update allocation extended strategy element fields according to loaded strategy elements.
**
*************************************************************************/

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/


STATIC RET_CODE FIN_StratUpdESEAlloc(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int);
STATIC RET_CODE	FIN_StratSetValueAndMargin(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, int);
STATIC RET_CODE FIN_StratHeaderGetWeight(DBA_DYNFLD_STP, ID_T, NUMBER_T*);
STATIC RET_CODE FIN_StratGetParMktSgtInfo(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int, int*);

STATIC int FIN_FilterMktSegtFromMktStruct(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7420 - RAK - 020703 */

/*************************************************************************************
*   Function             : FIN_StratCreateESEHeader()
*
*   Description          : Create total line.
*
*   Arguments            : stratHierPtr   : strategy hierarchy header
*			   ESLPtr          : extended strategy link pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 23.06.99 - REF3729
*
**************************************************************************************/
RET_CODE FIN_StratCreateESEHeader(DBA_HIER_HEAD_STP      stratHierPtr,
                                 int                    ESEFldNbr,
                                 DBA_DYNFLD_STP         ESLPtr,
                                 int                    selOptions,
                                 int*                   connectNo)
{
    RET_CODE	    ret             = RET_SUCCEED;
    DBA_DYNFLD_STP  ESEPtr          = NULLDYNST;
    DBA_DYNFLD_STP  parStratESLPtr  = NULLDYNST;
    DBA_DYNFLD_STP  stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP *stratEltTab     = NULLDYNSTPTR;
    int		        i;
    int             stratEltNbr     =0;
    NUMBER_T	    weight=0.0;

    if (ESEFldNbr > 0)
    {
	    ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	    if (ESEPtr == NULLDYNST)
	    {
	        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
	        return(RET_MEM_ERR_ALLOC);
	    }
    }
    else
    {
	    ESEPtr = ALLOC_DYNST(ExtStratElt);
	    if (ESEPtr == NULLDYNST)
	    {
	        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
	        return(RET_MEM_ERR_ALLOC);
	    }
    }

    /* ----------------------------------------------------------- */
    /* strategy without parent strategy and parent market segment, */
    /* create an "empty" total line                                */
    /* ----------------------------------------------------------- */
    if (IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratId) == TRUE &&
        IS_NULLFLD(ESLPtr, ExtStratLnk_MktSegId) == TRUE)
    {
	    SET_ID(ESEPtr, ExtStratElt_StratId, GET_ID(ESLPtr, ExtStratLnk_StratId));

	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, 100.0);
		SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, 100.0); /* PMSTA15213-CHU-121107 */
	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight,        100.0);
        /* REF4047 - 000125 - SKE */
        SET_ENUM(ESEPtr, ExtStratElt_StratNatEn, GET_ENUM(ESLPtr, ExtStratLnk_StratNatEn));
    }
    /* ----------------------------------------------------------------- */
    /* Strategy with parent market segment, but without parent strategy, */
    /* create an "market segment" total line                             */
    /* ----------------------------------------------------------------- */
    else if (IS_NULLFLD(ESLPtr, ExtStratLnk_MktSegId) == FALSE &&
             IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratId) == TRUE)
    {
	    SET_ID(ESEPtr, ExtStratElt_StratId,   GET_ID(ESLPtr, ExtStratLnk_StratId));
        /* REF4047 - 000125 - SKE */
        SET_ENUM(ESEPtr, ExtStratElt_StratNatEn, (STRATNAT_ENUM)StratNat_Alloc);

	    /* Get parent market segment information */
	    SET_ID(ESEPtr, ExtStratElt_MktSegtId, GET_ID(ESLPtr, ExtStratLnk_MktSegId));
	    if ((ret = FIN_StratGetParMktSgtInfo(stratHierPtr, ESEPtr, selOptions, connectNo)) != RET_SUCCEED)
	    {
	        if (ESEFldNbr > 0)
	        {
                FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
            }
	        else
	        {
                FREE_DYNST(ESEPtr, ExtStratElt);
            }
	        return(ret);
	    }

	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, 100.0);
		SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, 100.0); /* PMSTA15213-CHU-121107 */
	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight,        100.0);
    }
    /* -------------------------------------------------------- */
    /* Strategy with parent market segment and parent strategy, */
    /* create a "parent" total line                             */
    /* -------------------------------------------------------- */
    else if (IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratId) == FALSE &&
             IS_NULLFLD(ESLPtr, ExtStratLnk_MktSegId) == FALSE)
    {
        /* REF4047 - 000125 - SKE */
        SET_ENUM(ESEPtr, ExtStratElt_StratNatEn, (STRATNAT_ENUM)StratNat_Alloc);

	    /* Get parent market segment information */
	    SET_ID(ESEPtr, ExtStratElt_MktSegtId, GET_ID(ESLPtr, ExtStratLnk_MktSegId));
	    if ((ret = FIN_StratGetParMktSgtInfo(stratHierPtr, ESEPtr, selOptions, connectNo)) != RET_SUCCEED)
	    {
	        if (ESEFldNbr > 0)
	        {
                FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
            }
	        else
	        {
                FREE_DYNST(ESEPtr, ExtStratElt);
            }
	        return(ret);
	    }

	    /* Use parent ESL info */
	    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_ParStrat_ExtStratLnk_Ext) ==NULL ||
	        (parStratESLPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_ParStrat_ExtStratLnk_Ext))) == NULLDYNST)
	    {
	        if (ESEFldNbr > 0)
	        {
                FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
            }
	        else
	        {
                FREE_DYNST(ESEPtr, ExtStratElt);
            }
	        ret = RET_GEN_ERR_INVARG;
	        MSG_SendMesg(ret, 3, FILEINFO, "FIN_StratCreateESEHeader", "No parent strategy link");
	        return(ret);
	    }
	    SET_ID(ESEPtr, ExtStratElt_StratId,      GET_ID(parStratESLPtr, ExtStratLnk_StratId));
	    SET_ID(ESEPtr, ExtStratElt_ParStratId,   GET_ID(parStratESLPtr, ExtStratLnk_ParStratId));
	    SET_ID(ESEPtr, ExtStratElt_ParMktSegtId, GET_ID(parStratESLPtr, ExtStratLnk_MktSegId));

	    if (GET_EXTENSION_PTR(parStratESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL)
	    {
	        SET_ID(ESEPtr, ExtStratElt_StratHistId, GET_ID((*(GET_EXTENSION_PTR(parStratESLPtr, ExtStratLnk_A_StratHist_Ext))), A_StratHist_Id));
	    }

	    weight = 100.0;
	    FIN_StratHeaderGetWeight(parStratESLPtr, GET_ID(ESLPtr, ExtStratLnk_MktSegId), &weight);

	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, weight);
		SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, weight); /* PMSTA15213-CHU-121107 */
	    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight,        100.0);

	    /* Other objectiv value (beta, ...) */
	    if (GET_EXTENSION_PTR(parStratESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	       (stratHistPtr = *(GET_EXTENSION_PTR(parStratESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
	    {
	        stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
	        stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

	        for (i=0; i<stratEltNbr; i++)
	        {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(parStratESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

		        if (GET_ID(ESEPtr, ExtStratElt_StratHistId) == GET_ID(stratHistPtr, A_StratHist_Id) &&
		            GET_ID(ESEPtr, ExtStratElt_MktSegtId) == GET_ID(stratEltTab[i], A_StratElt_MktSegtId))
		        {
		            switch ((STRATELTNAT_ENUM) GET_ENUM(stratEltTab[i], A_StratElt_NatEn))
		            {
		                case StratEltNat_MinWeight :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_MinWeight);
			                break;

		                case StratEltNat_MaxWeight :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_MaxWeight);
			                break;

		                case StratEltNat_Duration :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjDura);
			                break;

		                case StratEltNat_ContrDura :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjDuraContrib);
			                break;

		                case StratEltNat_Beta :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjBeta);
			                break;

		                case StratEltNat_ContrBeta :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjBetaContrib);
			                break;

		                case StratEltNat_CurrRtn :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjCrtYield);
			                break;

		                case StratEltNat_ContrCurrRtn :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjCrtYieldContrib);
			                break;

		                case StratEltNat_MinRatingRk :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_MinRatingRank);
			                break;

		                case StratEltNat_TrackError :
			                ret = FIN_StratSetValueAndMargin(parStratESLPtr,
                                                             ESEPtr,
                                                             stratEltTab[i],
						                                     ExtStratElt_ObjTrackErr);
			                break;
		            }
                    if (ret != RET_SUCCEED)
                    {
	                    if (ESEFldNbr > 0)
	                    {
                            FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
                        }
	                    else
	                    {
                            FREE_DYNST(ESEPtr, ExtStratElt);
                        }
	                    return(ret);
                    }
		        }
	        }
	    }
    }

    SET_TINYINT(ESEPtr, ExtStratElt_Level,         0);
    SET_TINYINT(ESEPtr, ExtStratElt_StratLevel,    0);
    SET_ENUM(ESEPtr,    ExtStratElt_NatEn,         (ENUM_T) ExtStratEltNat_StratHead);
	SET_ID(ESEPtr,      ExtStratElt_ExtStratLnkId, GET_ID(ESLPtr, ExtStratLnk_Id));

    /* ADD RECORD, update links */
    if (ESEFldNbr > 0)
    {
	    ret = DBA_AddHierRecordSupplFld(stratHierPtr,
			                            ESEPtr,
                                        ExtStratElt,
                                        FALSE,
				                        ESEFldNbr,
                                        HierAddRec_TestMandatLnk);
    }
    else
    {
	    ret = DBA_AddHierRecord(stratHierPtr,
			                    ESEPtr,
                                ExtStratElt,
                                FALSE,
			                    HierAddRec_TestMandatLnk);
    }

    if (ret != RET_SUCCEED)
    {
	    if (ESEFldNbr > 0)
	    {
            FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
        }
	    else
	    {
            FREE_DYNST(ESEPtr, ExtStratElt);
        }
	    return(ret);
    }

    return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratHeaderGetWeight()
*
*   Description          : Get current weight (reading parent if necessary).
*
*   Arguments            : parESLPtr   : parent strategy pointer
*			   crtMktSgtId : current market segment identifier
*			   weightPtr   : weight value pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : RAK - 07.07.99 - REF3729
*
**************************************************************************************/
STATIC RET_CODE FIN_StratHeaderGetWeight(DBA_DYNFLD_STP parESLPtr, ID_T crtMktSgtId, NUMBER_T *weightPtr)
{
    DBA_DYNFLD_STP  stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP  parStratESLPtr  = NULLDYNST;
    DBA_DYNFLD_STP *stratEltTab     = NULLDYNSTPTR;
    int		        i;
    int             stratEltNbr;
    FLAG_T          stop;

    if (GET_EXTENSION_PTR(parESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	    (stratHistPtr = *(GET_EXTENSION_PTR(parESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
	    stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
	    stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

	    for (i=0, stop=FALSE; i<stratEltNbr && stop==FALSE; i++)
	    {
			/* REF11559 - CHU - 051124 : check validity of Strategy element */
			if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
				IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
				CMP_ID(GET_ID(parESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
			{
				continue;
			}

	        if (GET_ENUM(stratEltTab[i], A_StratElt_NatEn) == StratEltNat_Weight)
	        {
		        if (GET_ID(stratEltTab[i], A_StratElt_MktSegtId) == crtMktSgtId)
		        {
		            (*weightPtr) = (*weightPtr) * GET_NUMBER(stratEltTab[i], A_StratElt_Value) / 100.0;
		            stop = TRUE;
		        }
	        }
	    }
    }

    /* Use parent ESL info */
    if (GET_EXTENSION_PTR(parESLPtr, ExtStratLnk_ParStrat_ExtStratLnk_Ext) != NULL &&
	    (parStratESLPtr = *(GET_EXTENSION_PTR(parESLPtr, ExtStratLnk_ParStrat_ExtStratLnk_Ext))) != NULLDYNST)
    {
	    return(FIN_StratHeaderGetWeight(parStratESLPtr, GET_ID(parESLPtr, ExtStratLnk_MktSegId), weightPtr));
    }

    return(RET_SUCCEED);
}


/*************************************************************************************
*   Function             : FIN_StratGetParMktSgtInfo()
*
*   Description          : Get parent market segment information and update ExtStratElt.
*
*   Arguments            : stratHierPtr : strategy hierarchy header
*                          ESEPtr       : extended strategy element pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 25.06.99 - REF3729
*   Modif. Date          : REF4047 - 991216 - SKE : Use hierarchy
**************************************************************************************/
STATIC RET_CODE FIN_StratGetParMktSgtInfo(DBA_HIER_HEAD_STP     stratHierPtr,
                                          DBA_DYNFLD_STP        ESEPtr,
                                          int                   selOptions,
                                          int*                  connectNo)

{
    RET_CODE	    ret         = RET_SUCCEED;
    DBA_DYNFLD_STP  ask         = NULLDYNST;
    DBA_DYNFLD_STP  sMktSgtPtr  = NULLDYNST;
    DBA_DYNFLD_STP  outputPtr   = NULLDYNST;

    /* Retrieve short market_segment record */
    /* REF4047 - 991207 - SKE : let's find in hierarchy */
    /* otherwise in database                            */
    sMktSgtPtr = DBA_SearchHierRecById(stratHierPtr,
                                       S_MktSegt,
                                       S_MktSegt_Id,
                                       GET_ID(ESEPtr, ExtStratElt_MktSegtId));

    if (sMktSgtPtr == NULLDYNST)
    {
        if ((ask = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(RET_MEM_ERR_ALLOC);
        }
        if ((outputPtr = ALLOC_DYNST(S_MktSegt)) == NULLDYNST)
        {
	        FREE_DYNST(ask, Adm_Arg);
	        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_MktSegt");
	        return(RET_MEM_ERR_ALLOC);
        }

        SET_ID(ask, Adm_Arg_Id, GET_ID(ESEPtr, ExtStratElt_MktSegtId));

        if ((ret = DBA_Get2(MktSegt,
                            UNUSED,
                            Adm_Arg,
                            ask,
                            S_MktSegt,
                            &outputPtr,
		                    UNUSED,
                            UNUSED,
                            UNUSED)) != RET_SUCCEED)
        {
            FREE_DYNST(ask, Adm_Arg);
            FREE_DYNST(outputPtr, S_MktSegt);
            return(ret);
        }
        FREE_DYNST(ask, Adm_Arg);
        sMktSgtPtr = outputPtr;
    }

    SET_ID(ESEPtr, ExtStratElt_GridId,       GET_ID(sMktSgtPtr, S_MktSegt_GridId));
    SET_ID(ESEPtr, ExtStratElt_AbsListId,    GET_ID(sMktSgtPtr, S_MktSegt_AbcissaListId));
    SET_ID(ESEPtr, ExtStratElt_OrdListId,    GET_ID(sMktSgtPtr, S_MktSegt_OrdinateListId));
    SET_ID(ESEPtr, ExtStratElt_AbsClassifId, GET_ID(sMktSgtPtr, S_MktSegt_AbcissaClassifId));
    SET_ID(ESEPtr, ExtStratElt_OrdClassifId, GET_ID(sMktSgtPtr, S_MktSegt_OrdinateClassifId));

    /* Only Free the dynst allocated by DBA_Get2 */
    if (outputPtr != NULLDYNST) FREE_DYNST(outputPtr, S_MktSegt);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_FilterNoESEHeader()
**
**  Description : Filter the ESE that are not header of a strategy
**                return TRUE  -> record must be extract
**                       FALSE -> record musn't be extract
**
**  Arguments   : dynSt         element pointer
**                dynStTp       element description enum  not used !!!!
**                parMktStruct  parent mktStruct not used !!!!
**
**  Return      : TRUE or FALSE
**
**  Creation    : REF8451 - CHU - 021219
**
*************************************************************************/
int FIN_FilterNoESEHeader(DBA_DYNFLD_STP   sMSPtr,
				              DBA_DYNST_ENUM   dynStTp,
				              DBA_DYNFLD_STP   ESLPtr)
{
    if ((CMP_DYNFLD(sMSPtr, ESLPtr, ExtStratElt_MktSegtId, ExtStratLnk_MktSegId, IdType) == 0) &&
		(GET_TINYINT(sMSPtr, ExtStratElt_StratLevel) == 0)) /* REF9264 - LJE - 030829 */
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
*
*   Function        :   FIN_FilterStratEltOnStratHist()
*
*   Description     :   Filter Strategy Elements for a stratHistory
*
*   Arguments       :   dynSt      : a pointer on strategy element
*                       dynStTp    : enum value for strategy element
*                      stratHistPtr: StrategyHistory reference
*
*   Return          :   TRUE or FALSE
*
*   Creation date   :   PMSTA - 39969 - sanand - 05052020
*************************************************************************/
int FIN_FilterStratEltOnStratHist(DBA_DYNFLD_STP dynSt,
                                  DBA_DYNST_ENUM dynStTp,
                                  DBA_DYNFLD_STP stratHistPtr)
{
    if( CMP_DYNFLD(dynSt, stratHistPtr, A_StratElt_StratHistId, A_StratHist_Id, IdType) == 0 )
        return(TRUE);
    else
        return(FALSE);
}
/*************************************************************************************
*   Function             : FIN_StratCreateESEAlloc()
*
*   Description          : Create extended strategy elements for allocation.
*
*   Arguments            : stratHierPtr : strategy hierarchy header
*                          ESLPtr       : extended strategy link pointer
*                          eseNatEn     : element nature
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 23.06.99 - REF3729
*
**************************************************************************************/
RET_CODE FIN_StratCreateESEAlloc(DBA_HIER_HEAD_STP      stratHierPtr,
                                 int                    ESEFldNbr,
                                 DBA_DYNFLD_STP         ESLPtr,
                                 FLAG_T                 editAllocConstrFlg) /* REF7216 - RAK - 020207 */
{
    RET_CODE	        ret             = RET_SUCCEED;
    DBA_DYNFLD_STP     *sMSTab          = NULLDYNSTPTR;
    DBA_DYNFLD_STP      ESEPtr          = NULLDYNST;
    DBA_DYNFLD_STP     *ESETab          = NULLDYNSTPTR;
    DBA_DYNFLD_STP      parESEPtr       = NULLDYNST;
    DBA_DYNFLD_STP      newParESEPtr    = NULLDYNST;
    DBA_DYNFLD_STP      gridPtr         = NULLDYNST;
	DBA_DYNFLD_STP      *headESEPtr     = NULLDYNSTPTR;
    DBA_DYNFLD_STP      stratHistPtr    = NULLDYNST;    /* PMSTA - 39969 - sanand - 02062020 - Market segment exclusion */
    STRATNAT_ENUM       stratNatEn;
    EXTSTRATELTNAT_ENUM eseNatEn;
    int                 sMSNbr          = 0;
    int                 ESENbr          = 0;
	int                 headESENbr      = 0;
    int		            i;
    int                 sMSNbrFinal     = 0;            /*PMSTA -40823  - lalby - excludemarketsegments*/

    if (IS_NULLFLD(ESLPtr, ExtStratLnk_GridId) == TRUE)
    {
		ret = RET_FIN_ERR_INVDATA;
		MSG_SendMesg(ret, 2, FILEINFO, "FIN_StratCreateESEAlloc", "no grid");
		return(ret);
    }
    /* Extract all short market segment linked to our grid */
    /* REF4047 - 991216 - SKE : let's find in hierarchy */
    /* otherwise in database                            */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
                                                 S_MktSegt,
                                                 FALSE,
                                                 FIN_StratFilterSMS,
                                                 ESLPtr,
                                                 FIN_CmpMSRank,
				                                 &sMSNbr,
                                                 &sMSTab)) != RET_SUCCEED)
    {
		return(ret);
    }

    /* REF7420 - RAK - 020703 */
    /* Not found, verify if gris is a MktSSubSet, and in */
    /* that case select MktSegt of associated mktStruct  */
    if (ret == RET_SUCCEED && sMSNbr == 0)
    {
        if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Grid_Ext) != NULL &&
	        (gridPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Grid_Ext))) != NULLDYNST)
	    {
            if ((GRIDNATURE_ENUM) GET_ENUM(gridPtr, A_Grid_NatEn) == GridNat_MktSSubSet)
            {
                if ((ret = FIN_StratMktSegtFromGridMktSSubSet(stratHierPtr, gridPtr,
                                                              &sMSTab, &sMSNbr)) != RET_SUCCEED)
                {
                    return(ret);
                }
            }
        }
    }

	/* REF8451 - CHU - 021219 : Get Header ESE, if any */
	/* REF8777 - CHU - 030205 : filter header on ESLPtr mkt segt Id */
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
                                                 ExtStratElt,
                                                 FALSE,
                                                 FIN_FilterNoESEHeader,
                                                 ESLPtr,
                                                 NULLFCT,
				                                 &headESENbr,
                                                 &headESEPtr)) != RET_SUCCEED)
	{
		return(ret);
	}

    sMSNbrFinal = sMSNbr; /*PMSTA -40823  - lalby - excludemarketsegments*/

    /* PMSTA - 39969 - sanand - 02062020 */
    std::vector<ID_T> excludedMarketSegments;
    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL)
    {
        stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext));
        if (stratHistPtr)
        {
            ret = FIN_GetExcludedMarketSegments(stratHierPtr,stratHistPtr,excludedMarketSegments);
            if(ret != RET_SUCCEED)
            {
                MSG_SendMesg(ret, 2, FILEINFO, "Not able to extract the excluded market segments");
            }
            /* The Excluded Market Segment related Strat Element
               also needs to be added to the StratHier -> A_StratElt_Ext
               as the objective weight, margin values are picked from the StratElement
               and then populated into the ESE created
            */
            int              stratEltNumber = 0;
            DBA_DYNFLD_STP     *stratEltTab = NULLDYNSTPTR;
	        if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
                                                         A_StratElt,
                                                         FALSE,
                                                         FIN_FilterStratEltOnStratHist,
                                                         stratHistPtr,
                                                         NULLFCT,
                                                         &stratEltNumber,
                                                         &stratEltTab)) != RET_SUCCEED)
	        {
		        return(ret);
	        }
            auto iter = excludedMarketSegments.begin();
            while (iter != excludedMarketSegments.end())
            {
                /*
                1) From the MarketSegmentId and the Strategy History, get the Required StratElement
                2) Add the StratElement to the StrategyHistory -> A_StratElt_Ext  Tab
                */
                ID_T mktSegtId = *iter;
                for (int stratEltIdx = 0; stratEltIdx < stratEltNumber; stratEltIdx++)
                {
                    if (CMP_ID(GET_ID(stratEltTab[stratEltIdx], A_StratElt_MktSegtId), mktSegtId) == 0)
                    {
                        /* Excluded Market segment found!   Needs to be added to the StratEltList */
                        if ((ret = DBA_HierUpdExt(A_StratHist_A_StratElt_Ext, stratHistPtr, stratEltTab[stratEltIdx], A_StratElt))
                            != RET_SUCCEED)
                        {
                            MSG_SendMesg(ret, 2, FILEINFO, "Unable to add the Excluded Strat element to the StratHist Extension");
                            return ret;
                        }
                        else
                        {
                            if (editAllocConstrFlg == TRUE)  /*PMSTA -40823  - lalby - excludemarketsegments*/
                            {
                                sMSNbrFinal--;
                            }
                            break;
                        }
                    }
                }
                ++iter;
            }
            FREE(stratEltTab);
        }
    }

    /* For each market segment, create an element ... */
    if (ret == RET_SUCCEED && sMSNbrFinal > 0) /*PMSTA -40823  - lalby - excludemarketsegments*/
    {
		if ((ESETab = (DBA_DYNFLD_STP *)CALLOC(sMSNbrFinal, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR) /* REF7264 - LJE - 020130 */ /*PMSTA -40823*/
	    {
            FREE(headESEPtr); /* REF8712 - LJE - 031017 */
	        FREE(sMSTab);
	        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, sMSNbrFinal);
	        return(RET_MEM_ERR_ALLOC);
	    }

 	    for (i=0; i<sMSNbr; i++)
	    {
			/* REF8451 - CHU - 021219 */
			/* If a head ESE already exists with the same mkt segt id,
			 * do not create another ESE for this mkt segt */

            if ((headESENbr > 0) &&
                (GET_ID(headESEPtr[0], ExtStratElt_MktSegtId) == GET_ID(sMSTab[i], S_MktSegt_Id)))
                continue;

            /*PMSTA -40823  - lalby - excludemarketsegments for constraints allocation*/
            if (editAllocConstrFlg == TRUE)
            {
                auto it = std::find_if(excludedMarketSegments.begin(), excludedMarketSegments.end(),
                                [=](auto xsegid) {
                            return ((GET_ID(sMSTab[i], S_MktSegt_Id) == xsegid) || 
                               ( (IS_NULLFLD(sMSTab[i], A_MktStruct_ParMktSegtId) == FALSE)? (GET_ID(sMSTab[i], S_MktSegt_ParMktSegtId) == xsegid):0));
                            });

                if (it != excludedMarketSegments.end() )
                {
                    if ((IS_NULLFLD(sMSTab[i], A_MktStruct_ParMktSegtId) == FALSE) && *it == GET_ID(sMSTab[i], S_MktSegt_ParMktSegtId))
                    {
                        excludedMarketSegments.push_back(GET_ID(sMSTab[i], S_MktSegt_Id));
                    }
                     continue;
                }
             }
            /*PMSTA -40823  - lalby - excludemarketsegments for constraints allocation*/

			if (ESEFldNbr > 0)
	        {
		        ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);

		        if (ESEPtr == NULLDYNST)
		        {
                    FREE(headESEPtr); /* REF8712 - LJE - 031017 */
		            FREE(sMSTab);
		            FREE(ESETab);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
		            return(RET_MEM_ERR_ALLOC);
		        }
	        }
	        else
	        {
		        ESEPtr = ALLOC_DYNST(ExtStratElt);
                DBA_SetDfltEntityFld(EStratElt, ExtStratElt, ESEPtr); /* PMSTA-30291 - DDV - 180320 */

		        if (ESEPtr == NULLDYNST)
		        {
                    FREE(headESEPtr); /* REF8712 - LJE - 031017 */
		            FREE(sMSTab);
		            FREE(ESETab);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
		            return(RET_MEM_ERR_ALLOC);
		        }
	        }

	        SET_ID(ESEPtr, ExtStratElt_MktSegtId,    GET_ID(sMSTab[i], S_MktSegt_Id));
	        SET_ID(ESEPtr, ExtStratElt_AbsClassifId, GET_ID(sMSTab[i], S_MktSegt_AbcissaClassifId));
	        SET_ID(ESEPtr, ExtStratElt_OrdClassifId, GET_ID(sMSTab[i], S_MktSegt_OrdinateClassifId));
	        SET_ID(ESEPtr, ExtStratElt_AbsListId,    GET_ID(sMSTab[i], S_MktSegt_AbcissaListId));
	        SET_ID(ESEPtr, ExtStratElt_OrdListId,    GET_ID(sMSTab[i], S_MktSegt_OrdinateListId));

            /* REF7420 - RAK - 020612 - Update new field */
            if (IS_NULLFLD(sMSTab[i], S_MktSegt_MktStructLevel) == FALSE)
			{
                SET_TINYINT(ESEPtr, ExtStratElt_MktStructLevel,
                    GET_TINYINT(sMSTab[i], S_MktSegt_MktStructLevel));
            }

            if (IS_NULLFLD(sMSTab[i], S_MktSegt_MktStructId) == FALSE)
            {
                DBA_DYNFLD_STP  mktStructPtr=NULLDYNST;

                /* get parent market segment of the market structure */
                if (DBA_GetRecPtrFromHierById(stratHierPtr,
                                      GET_ID(sMSTab[i], S_MktSegt_MktStructId),
                                      A_MktStruct,
                                      &mktStructPtr) == RET_SUCCEED &&
                                      mktStructPtr != NULLDYNST)
                {
                    if (IS_NULLFLD(mktStructPtr, A_MktStruct_ParMktSegtId) == FALSE)
                    {
                        SET_ID(ESEPtr, ExtStratElt_ParMktSegtId,
                            GET_ID(mktStructPtr, A_MktStruct_ParMktSegtId));
                    }
                }
            }

	        /* RANK */
	        if (IS_NULLFLD(sMSTab[i], S_MktSegt_OrdinateListRank) == FALSE)
	        {
		        SET_SMALLINT(ESEPtr, ExtStratElt_Rank, GET_SMALLINT(sMSTab[i], S_MktSegt_OrdinateListRank));
	        }
	        else if (IS_NULLFLD(sMSTab[i], S_MktSegt_AbcissaListRank) == FALSE)
	        {
		        SET_SMALLINT(ESEPtr, ExtStratElt_Rank, GET_SMALLINT(sMSTab[i], S_MktSegt_AbcissaListRank));
	        }

	        /* LEVEL */
	        if (IS_NULLFLD(sMSTab[i], S_MktSegt_AbcissaListId) == TRUE)
	        {
		        if (IS_NULLFLD(sMSTab[i], S_MktSegt_OrdinateListId) == TRUE)
		        {
                    SET_TINYINT(ESEPtr, ExtStratElt_Level, 1);
                }
		        else
		        {
                    SET_TINYINT(ESEPtr, ExtStratElt_Level, 2);
                }
	        }
	        else
	        {
		        if (IS_NULLFLD(sMSTab[i], S_MktSegt_OrdinateListId) == TRUE)
		        {
                    SET_TINYINT(ESEPtr, ExtStratElt_Level, 2);
                }
		        else
		        {
                    SET_TINYINT(ESEPtr, ExtStratElt_Level, 3);
                }
	        }

            stratNatEn = (STRATNAT_ENUM)GET_ENUM(ESLPtr, ExtStratLnk_StratNatEn); /* REF7264 - LJE - 020130 */
            if (stratNatEn == StratNat_Alloc)
            {
                eseNatEn = ExtStratEltNat_Alloc;
            }
            else /* StratNat_ModelPtf or StratNat_RecomList or StratNat_Index (PMSTA01435) */
            {
                eseNatEn = ExtStratEltNat_BreakCriteria;
            }

	        /* INIT COMMON FIELDS AND ADD EXTENDED STRATEGY ELEMENT IN HIERARCHY */
	        if ((ret = FIN_StratAddESEInHier(stratHierPtr,
                                             ESEPtr,
                                             ESEFldNbr,
                                             ESLPtr,
                                             eseNatEn)) != RET_SUCCEED)
	        {
                FREE(headESEPtr); /* REF8712 - LJE - 031017 */
		        DBA_FreeDynStTab(sMSTab, sMSNbr, S_MktSegt);
		        FREE(ESETab);
		        return(ret);
	        }

	        /* Prepare link ExtStratElt_DispPar_ExtStratElt_Ext */
            /*
                REF4047 - 991217 - SKE : In case of a Grid List,
                display all the ESE with Level == 2 at the same
                strategy level of their parent ESE. Except if the
                parent of the parent ESE is either the header (level 0)
                or belongs to another strategy.
            */
            SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId, GET_ID(ESEPtr, ExtStratElt_ParExtStratEltId));
            if ((GET_TINYINT(ESEPtr, ExtStratElt_StratLevel) > 1 ||
                 GET_TINYINT(ESEPtr, ExtStratElt_MktStructLevel) > 1) &&
                GET_TINYINT(ESEPtr, ExtStratElt_Level)      == 2        &&
                IS_NULLFLD(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) == FALSE)
            {
				parESEPtr = NULLDYNST;
				/* bug - RAK - 020807 - test GET_EXTENSION != NULL was missing */
                if (GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL &&
					(parESEPtr = *(GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST)
                {
                    if (IS_NULLFLD(parESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) == FALSE)
                    {
                        newParESEPtr = NULLDYNST;
						/* bug - RAK - 020807 - test GET_EXTENSION != NULL was missing */
                        if (GET_EXTENSION_PTR(parESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL &&
							(newParESEPtr = *(GET_EXTENSION_PTR(parESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST)
                        {
                            /* REF7216 - RAK - 020207 - For EditAllocConstr don't verify strategy */
                            /* if (GET_TINYINT(newParESEPtr, ExtStratElt_Level) != 0 &&
                                GET_ID(newParESEPtr, ExtStratElt_StratId) == GET_ID (ESEPtr, ExtStratElt_StratId))
                            */
                            if (GET_TINYINT(newParESEPtr, ExtStratElt_Level) != 0)
                            {
                                if (editAllocConstrFlg == TRUE)
                                {
                                    SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId,
                                        GET_ID(newParESEPtr, ExtStratElt_Id));
                                }
                                else if (GET_ID(newParESEPtr, ExtStratElt_StratId) == GET_ID(ESEPtr, ExtStratElt_StratId))
                                {
                                    SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId,
                                        GET_ID(newParESEPtr, ExtStratElt_Id));
                                }
                            }
                        }
                    }
                }
            }
            /**/

	        /* Keep created ESE in array */
	        ESETab[ESENbr] = ESEPtr;
	        ++ESENbr;
	    }

	    FREE(sMSTab);

	    /* Update allocation values ... */
		/* REF7216 - RAK - 021010 -  not necessary for EditAllocConstr */
		if (editAllocConstrFlg == FALSE)
		{
			ret = FIN_StratUpdESEAlloc(stratHierPtr, ESLPtr, ESETab, ESENbr);
			if (ret != RET_SUCCEED)
			{
                FREE(headESEPtr); /* REF8712 - LJE - 031017 */
				FREE(ESETab);
				return(ret);
			}
		}
    }
    FREE(headESEPtr); /* REF8712 - LJE - 031017 */
    FREE(ESETab);
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SearchParentMktSegt()
**
**  Description :
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**  Created		    REF7758 - LJE - 020925
**
*************************************************************************/
STATIC int FIN_SearchParentMktSegt(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testSt)
{
    if (CMP_DYNFLD(dynSt, testSt, S_MktSegt_GridId, S_MktSegt_GridId, IdType) != 0)
    {
        return (FALSE);
    }

    if (IS_NULLFLD(testSt, S_MktSegt_MktStructId) == FALSE &&
        CMP_DYNFLD(dynSt, testSt, S_MktSegt_MktStructId, S_MktSegt_MktStructId, IdType) != 0)
    {
        return (FALSE);
    }

    if (IS_NULLFLD(testSt, S_MktSegt_AbcissaListId)  == FALSE &&
        IS_NULLFLD(testSt, S_MktSegt_OrdinateListId) == FALSE)
    {
        if (CMP_DYNFLD(dynSt, testSt, S_MktSegt_AbcissaListId, S_MktSegt_AbcissaListId, IdType) == 0 &&
            IS_NULLFLD(dynSt, S_MktSegt_OrdinateListId) == TRUE)
            return (TRUE);
        else
            return (FALSE);
    }
    else if (IS_NULLFLD(testSt, S_MktSegt_AbcissaListId)  == FALSE ||
             IS_NULLFLD(testSt, S_MktSegt_OrdinateListId) == FALSE )
    {
        if (IS_NULLFLD(dynSt, S_MktSegt_AbcissaListId)  == TRUE &&
            IS_NULLFLD(dynSt, S_MktSegt_OrdinateListId) == TRUE)
            return (TRUE);
        else
            return (FALSE);
    }
    else
    {
        return (FALSE);
    }

}

/************************************************************************
**
**  Function    :   FIN_GetParMktSegtWithoutInstr()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7758 - LJE - 021031
**  Modification
**
*************************************************************************/
STATIC RET_CODE FIN_GetParMktSegtWithoutInstr(DBA_DYNFLD_STP    domainPtr,
                                              DBA_HIER_HEAD_STP hierHead,
                                              DBA_DYNFLD_STP    mktSegtPtr,
                                              DBA_DYNFLD_STP    parMktSegtIdPtr,
                                              FLAG_T            allMktStructFlg,
										      FLAG_T            nullOnHeadFlg)
{
    RET_CODE       ret=RET_SUCCEED;
    DBA_DYNFLD_STP *findMktSegtTab=NULL, mktStructPtr;
    int            findMktSegtNbr=0;
    DBA_DYNFLD_ST  grandParMktSegtId;

    memset(&grandParMktSegtId, 0, sizeof(DBA_DYNFLD_ST));

    if (parMktSegtIdPtr != NULL)
    {
        SET_NULL_ID(parMktSegtIdPtr, 0);

        if (mktSegtPtr != NULL)
        {
            if (IS_NULLFLD(mktSegtPtr, S_MktSegt_AbcissaListId)  == FALSE &&
                (allMktStructFlg == TRUE ||
                 IS_NULLFLD(mktSegtPtr, S_MktSegt_OrdinateListId) == FALSE))
            {
                /* The parent market segment is the same where ordinate list id is null */
                /* Search the new market segment */
  	            if ((ret = DBA_HierEltRecExtract(hierHead,
                                                 S_MktSegt,
                                                 FALSE,
                                                 FIN_SearchParentMktSegt,
                                                 mktSegtPtr,
                                                 NULL,
                                                 FALSE,
                                                 FALSE,
                                                 &findMktSegtNbr,
                                                 &findMktSegtTab)) != RET_SUCCEED)
	            {
		            return(ret);
	            }

                if (findMktSegtNbr == 1)
                {
                    SET_ID(parMktSegtIdPtr, 0, GET_ID(findMktSegtTab[0], S_MktSegt_Id));

                    /* REF9743 - LJE - 040305 */
                    if (nullOnHeadFlg   == TRUE &&
						allMktStructFlg == TRUE &&
                        IS_NULLFLD(findMktSegtTab[0], S_MktSegt_AbcissaListId)  == TRUE &&
                        IS_NULLFLD(findMktSegtTab[0], S_MktSegt_OrdinateListId) == TRUE)
                    {
                        FIN_GetParMktSegtWithoutInstr(domainPtr, hierHead, findMktSegtTab[0], &grandParMktSegtId, FALSE, TRUE);

                        if (IS_NULLFLD((&grandParMktSegtId), 0))
                        {
                            SET_NULL_ID(parMktSegtIdPtr, 0);
                        }
                    }
                }

                FREE(findMktSegtTab);

            }
            else if (IS_NULLFLD(mktSegtPtr, S_MktSegt_MktStructId) == FALSE)
            {
                /* Get market structure */
                mktStructPtr = DBA_SearchHierRecById(hierHead,
												     A_MktStruct,
												     A_MktStruct_Id,
												     GET_ID(mktSegtPtr, S_MktSegt_MktStructId));

                if (mktStructPtr != NULL)
                {
                    SET_ID(parMktSegtIdPtr, 0, GET_ID(mktStructPtr, A_MktStruct_ParMktSegtId));
                }
            }
        }
    }
    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_GetParentMktSegt()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7758 - LJE - 021031
**  Modification
**
*************************************************************************/
RET_CODE FIN_GetParentMktSegt(DBA_DYNFLD_STP    domainPtr,
                              DBA_HIER_HEAD_STP hierHead,
                              DBA_DYNFLD_STP    recordStp,
                              FIELD_IDX_T       instrIdIdx,
                              FIELD_IDX_T       mktSegtIdIdx,
                              DBA_DYNFLD_STP   *mktSegtPtr,
                              DBA_DYNFLD_STP    parMktSegtIdPtr,
                              FLAG_T            allMktStructFlg,
							  FLAG_T            nullOnHeadFlg)
{
    RET_CODE ret = RET_SUCCEED;

    if (instrIdIdx < 0 ||
		IS_NULLFLD(recordStp, instrIdIdx) == TRUE)
    {
        /* Get the market segment in hier */
        *mktSegtPtr = DBA_SearchHierRecById(hierHead,
                                            S_MktSegt,
                                            S_MktSegt_Id,
                                            GET_ID(recordStp, mktSegtIdIdx));

        ret = FIN_GetParMktSegtWithoutInstr(domainPtr,
                                            hierHead,
                                            *mktSegtPtr,
                                            parMktSegtIdPtr,
                                            allMktStructFlg,
									        nullOnHeadFlg);
    }
    else /* REF9344 - LJE - 031014 */
    {
        SET_ID(parMktSegtIdPtr, 0, GET_ID(recordStp, mktSegtIdIdx));
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterCurrentMktStruct()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA-13109 - LJE - 120326
**
*************************************************************************/
STATIC int FIN_FilterCurrentMktStruct(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP currGridStp)
{
	if (CMP_DYNFLD(dynSt, currGridStp, A_MktSegt_GridId, A_Grid_Id, IdType) == 0 ||
		CMP_DYNFLD(dynSt, currGridStp, A_MktSegt_GridId, A_Grid_GlobalGridId, IdType) == 0)
		return(TRUE);

    return(FALSE);
}

/************************************************************************
*   Function             : DBA_CreateMarketSegmentFromShort()
*
*   Description          : This function convert all market segments (short)
*                          in the hierarchy to the all structure.
*                          The standard format treatement work only with "all"
*                          structures.
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Last Modification    : PMSTA08736 - LJE - 100216
*************************************************************************/
RET_CODE DBA_CreateMarketSegmentFromShort(DBA_DYNFLD_STP    domainPtr,
 										  DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE         ret=RET_SUCCEED;
	int              eltNbr, i, j, gridNbr;
	DBA_DYNFLD_STP  *eltTab=NULL, *gridTab;
	DBA_DYNFLD_STP   mktSegtPtr, admArg;

    if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

   	if ((ret = DBA_ExtractHierEltRec(hierHead, A_Grid, FALSE, NULLFCT, NULL, &gridNbr, &gridTab)) != RET_SUCCEED)
	{
		return (ret);
	}

    for (i=0; i<gridNbr; i++)
    {
		/* OCS-40237 - LJE - 120326 - Check if the market structure is not already on the hierarchy */
        if (DBA_HierEltRecExtract(hierHead,
								  A_MktSegt,
                                  FALSE,
                                  FIN_FilterCurrentMktStruct,
                                  gridTab[i],
                                  NULL,
                                  FALSE,
                                  FALSE,
                                  &eltNbr,
                                  &eltTab) == RET_SUCCEED &&
				eltNbr > 0)
	    {
				FREE(eltTab);
				eltNbr = 0;
				continue;
	    }

        /* Don't load market structure subset if the global is load */
        if (GET_ENUM(gridTab[i], A_Grid_NatEn) == GridNat_MktSSubSet)
        {
            for (j=0; j<gridNbr; j++)
            {
                if (GET_ID(gridTab[i], A_Grid_GlobalGridId) == GET_ID(gridTab[j], A_Grid_Id))
                    break;
            }

            if (j<gridNbr)
                continue;
        }

        /* Extract all grid market segments and sort them */
        SET_ID(admArg, Adm_Arg_Id, GET_ID(gridTab[i], A_Grid_Id));

        ret = DBA_Select2(MktSegt, UNUSED, Adm_Arg, admArg,
			              A_MktSegt, &eltTab, UNUSED, UNUSED,
			              &eltNbr, UNUSED, UNUSED);

        if (ret == RET_SUCCEED && eltNbr > 0)
        {
   	        for (j=0; j<eltNbr; j++)
	        {
                FIN_GetParentMktSegt(domainPtr,
                                     hierHead,
                                     eltTab[j],
                                     Null_Dynfld,
                                     A_MktSegt_Id,
                                     &mktSegtPtr,
                                     (&(eltTab[j][A_MktSegt_ParMktSegtId])),
                                     TRUE,
							         FALSE);
	        }

            DBA_AddHierRecordList(hierHead,
			                      eltTab,
			                      eltNbr,
			                      A_MktSegt,
						          TRUE);

        }

		FREE(eltTab);
		eltNbr = 0;

    }

    FREE_DYNST(admArg, Adm_Arg);
    FREE(gridTab);
	gridNbr = 0;

    if ((ret = DBA_SetHierLnkUsed(hierHead, A_MktSegt,
                                  A_MktSegt_ParMktSegt_Ext)) != RET_SUCCEED)
    	return(ret);
    if ((ret = DBA_SetHierLnkUsed(hierHead, A_MktSegt,
                                  A_MktSegt_ChildrenMktSegt_Ext)) != RET_SUCCEED)
    	return(ret);

	if ((ret = DBA_MakeAllRecLinks(hierHead, A_MktSegt)) != RET_SUCCEED)
	{
		return(ret);
	}

    /* PMSTA-11309 - LJE - 110128 - Check parent market segment, mainly for market structure subset */
   	if ((ret = DBA_ExtractHierEltRec(hierHead, A_MktSegt, FALSE, NULLFCT, NULL, &eltNbr, &eltTab)) != RET_SUCCEED)
	{
		return (ret);
	}

    for (j=0; j<eltNbr; j++)
    {
        if (IS_NULLFLD(eltTab[j], A_MktSegt_ParMktSegtId) == FALSE &&
            GET_EXTENSION_NBR(eltTab[j], A_MktSegt_ParMktSegt_Ext) == 0)
        {
            SET_NULL_ID(eltTab[j], A_MktSegt_ParMktSegtId);
        }
    }

	FREE(eltTab);
	eltNbr = 0;

	return (ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadGridMktStruct()
**
**  Description :   Laod all data for grid and market structure
**
**
**  Arguments   :
**
**
**  Return      :
**
**
**
**  Creation D. : REF9340 - DDV - 030724
**  Last modif. : PMSTA01727 - RAK - 070312 - Suppress oldPSP arguments (oldPspTab, oldPspNbr)
**
*************************************************************************/
EXTERN RET_CODE DBA_LoadGridMktStruct(DBA_DYNFLD_STP     domainPtr,
									  DBA_HIER_HEAD_STP  hierHead,
									  ID_T              *gridIdTab,
                                      int                gridIdNbr)
{
    int            i, j;
   	char           buffer[255];
    DICT_T         gridDictId;
    RET_CODE       ret=RET_SUCCEED;
	const DBA_DYNST_ENUM *outputStLst[] = {&A_Grid,
                                           &A_MktSSubSet,
                                           &A_MktStruct,
                                           &S_MktSegt,
										   &A_PerfEffectLink,
										   &A_PerfEffectDef};

	int                 outputBlkNb = 6;
	DBA_DYNFLD_STP      *data[6] = {NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
	int                 rows[6] = {0,0,0,0,0,0};

	DBA_DYNFLD_STP		testGridPtr=NULLDYNST;
    DBA_GetDictId(Grid, &gridDictId);

    DbiSqlExecByBlock sqlBlock; /* PMSTA-23226 - LJE - 160517 */

    /* if grids id all ready not found in oldPSPTab, insert it into #vector_id */
    for (i=0; i < gridIdNbr; i++)
    {
        /* REF9770 - LJE - 031215 : bug fix */
		/* PMSTA01727 - RAK - 070312 - Don't use oldPSP anymore, check in hierarchy ! */
        /* for (j=0; j < oldPspNbr && GET_ID(oldPspTab[j], A_PerfStorageParam_GridId) < gridIdTab[i];j++); */
		testGridPtr = DBA_SearchHierRecById(hierHead,
		                                    A_Grid, A_Grid_Id,
											gridIdTab[i]);


        /* grid id not found, add it into vector_id */
		/* PMSTA01727 - RAK - 070312 - Don't use oldPSP anymore, check in hierarchy ! */
        /* if (j == oldPspNbr || GET_ID(oldPspTab[j], A_PerfStorageParam_GridId) != gridIdTab[i]) */
		if (testGridPtr == NULLDYNST)
        {
            sprintf(buffer,
					"insert into #vector_id (id, entity_dict_id) values (%" szFormatId",%" szFormatId") ",  /* DLA - PMSTA08801 - 100211 */ /* PMSTA-21007 - CHU - 150810 */
                    gridIdTab[i], gridDictId);

            sqlBlock.addSql(buffer);
        }
    }

    if (sqlBlock.getSize() != 0) /* PMSTA07656 - LJE - 081216 */
	{
		/* REF9340 - DDV - 030725 - get a new connection, create #vector_id table and fill it */
        DbiConnectionHelper  dbiConnHelper;

        if (dbiConnHelper.isValidAndInit() == false)
        {
            MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
            return(RET_DBA_ERR_CONNOTFOUND);
        }

        if ((ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), TCT_VECTOR_ID)) != RET_SUCCEED)
        {
            return ret;
        }

        sqlBlock.execSqlExecByBloc(dbiConnHelper.getConnection());

		/* multiselect to load all data */
		if ((ret = DBA_MultiSelect2(Grid, UNUSED,  NullDynSt,
					    			NULL, outputStLst, data,
		               	    		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, rows,
                                    dbiConnHelper, UNUSED)) != RET_SUCCEED)
		{
            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), TCT_VECTOR_ID) != RET_SUCCEED)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_TruncateTempTables failed");
            }
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect for Grid failed");
            return(ret);
		}


        if ((ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), TCT_VECTOR_ID)) != RET_SUCCEED)
		{
   			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_TruncateTempTables failed");
			return ret;
		}

		/* insert all data into hierarchy */
		for (i=0; i<outputBlkNb; i++)
		{
			if (*(outputStLst[i]) != NullDynSt)
			{
				/* OCS-40237 - LJE - 120326 - Check if the perf effect def is not already in the hierarchy */
				if (*(outputStLst[i]) == A_PerfEffectDef)
    			{
					for (j=0; j<rows[i]; j++)
					{
						if (DBA_SearchHierRecById(hierHead,
												 A_PerfEffectDef,
												 A_PerfEffectDef_Id,
												 GET_ID(data[i][j], A_PerfEffectDef_Id)) == NULL)
						{
							ret = DBA_AddHierRecord(hierHead,
   													data[i][j],
													*(outputStLst[i]),
													TRUE,
													HierAddRec_NoLnk);

						}
					}
				}
				else if (rows[i] > 0)  /* REF8712 - DDV - 031013 */
				{
					ret = DBA_AddHierRecordList(hierHead, data[i], rows[i], *(outputStLst[i]), TRUE);
				}
                FREE(data[i]);
			}
			else
			{
				DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i]));
			}
		}
	}

	DBA_CreateMarketSegmentFromShort(domainPtr, hierHead); /* PMSTA08736 - LJE - 100223 */

	if ((ret = DBA_SetHierLnkUsed(hierHead,
								  A_PerfEffectDef,
								  A_PerfEffectDef_A_PerfEffectLink_Ext)) != RET_SUCCEED)
		return(ret);

	if ((ret = DBA_MakeAllRecLinks(hierHead, A_PerfEffectDef)) != RET_SUCCEED)
		return(ret);

	if ((ret = DBA_SetHierLnkUsed(hierHead,
								  A_PerfEffectLink,
								  A_PerfEffectLink_A_MktSgt_Ext)) != RET_SUCCEED)
		return(ret);
	if ((ret = DBA_SetHierLnkUsed(hierHead,
								  A_PerfEffectLink,
								  A_PerfEffectLink_A_PerfEffectDef_Ext)) != RET_SUCCEED)
		return(ret);

	if ((ret = DBA_MakeAllRecLinks(hierHead, A_PerfEffectLink)) != RET_SUCCEED)
		return(ret);

    if ((ret = DBA_SetHierLnkUsed(hierHead,
                                  A_MktStruct,
                                  A_MktStruct_S_MktSegt_Ext)) != RET_SUCCEED)
    {
        return(ret);
    }

	if ((ret = DBA_MakeAllRecLinks(hierHead, A_MktStruct)) != RET_SUCCEED)
		return(ret);


    if ((ret = DBA_SetHierLnkUsed(hierHead,
                                  A_Grid,
                                  A_Grid_S_MktSegt_Ext)) != RET_SUCCEED)
    {
        return(ret);
    }

	if ((ret = DBA_MakeAllRecLinks(hierHead, A_Grid)) != RET_SUCCEED)
		return(ret);

	return(ret);
}

/*************************************************************************************
*   Function             : FIN_CreateESEfromGrid()
*
*   Description          : Create extended strategy elements for market segments of a given Grid.
*                          New function using FIN_StratCreateESEAlloc() for RPC select_grid_market_segments
*
*   Arguments            : gridPtr      : grid pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA-20843 - CHU - 150723
*
**************************************************************************************/
RET_CODE FIN_CreateESEfromGrid(DBA_HIER_HEAD_STP	stratHierPtr,
							   DBA_DYNFLD_STP		gridPtr)
{
	RET_CODE ret = RET_SUCCEED;

	DBA_DYNFLD_STP	ESLPtr = NULL;
	DBA_DYNFLD_STP	OrigDomainPtr = NULLDYNST;
	ID_T			gridId = (ID_T)NULL;

	if (IS_NULLFLD(gridPtr, S_Grid_Id) == TRUE)
	{
		return(ret);;
	}
	gridId = GET_ID(gridPtr, S_Grid_Id);

	if ((ESLPtr = ALLOC_DYNST(ExtStratLnk)) == NULL)
	{
		ret = RET_MEM_ERR_ALLOC;
		MSG_SendMesg(ret, 2, FILEINFO, "ExtStratLnk");
		return(ret);
	}

	SET_ID(ESLPtr, ExtStratLnk_GridId, gridId);
    ret = DBA_AddHierRecord(stratHierPtr,
			                ESLPtr,
                            ExtStratLnk,
                            FALSE,
			                HierAddRec_TestMandatLnk);

	OrigDomainPtr = DBA_GetDomainPtr(-1);
   	if ((ret = DBA_LoadGridMktStruct(OrigDomainPtr, stratHierPtr, &gridId, 1)) != RET_SUCCEED)
    {
        return(ret);
    }

	/* Treat MktStruct (update level, ...) */
	if ((ret = FIN_TreatMktStruct(stratHierPtr, NULLDYNST)) != RET_SUCCEED)
	{
		return(ret);
	}

    /* Set link to "Used" between ExtStratLnk and ExtStratElt */
    DBA_SetHierLnkUsed(stratHierPtr, ExtStratLnk, ExtStratLnk_ExtStratElt_Ext);

    /* Set link to "Used" between ExtStratElt and ExtStratElt (link parent) */
    DBA_SetHierLnkUsed(stratHierPtr, ExtStratElt, ExtStratElt_LnkPar_ExtStratElt_Ext);

    /* Set link to "Used" between ExtStratElt and ExtStratElt (ordinate parent) */
    DBA_SetHierLnkUsed(stratHierPtr, ExtStratElt, ExtStratElt_OrdPar_ExtStratElt_Ext);

	ret = FIN_StratCreateESEAlloc(stratHierPtr,
								  0,
								  ESLPtr,
								  TRUE); /* Like Edit Allocation Constraints */

	return(ret);
}

/************************************************************************
*   Function             : FIN_SelectGridMktSgtCompute()
*
*   Description          : select market segments from a given grid
*
*   Arguments            :
*
*   Return               : CS_SUCCEED
*
**  Created				 :   PMSTA-20843 - CHU - 150724
*
*************************************************************************/
RET_CODE FIN_SelectGridMktSgtCompute(DBA_DYNFLD_STP domainPtr, PTR argHierHead)
{
	RET_CODE			ret = RET_SUCCEED;
	DBA_HIER_HEAD_STP	hierStp = (DBA_HIER_HEAD_STP)argHierHead;
	DBA_DYNFLD_STP		sGrid = NULL;

	if (IS_NULLFLD(domainPtr, A_Domain_GridId) == TRUE)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_SelectGridMktSgtCompute", "Grid identifier mandatory when running select_grid_market_segments function");
        return RET_GEN_ERR_INVARG;
	}

	if ((sGrid = ALLOC_DYNST(S_Grid)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Grid");
		return(RET_MEM_ERR_ALLOC);
	}
	SET_ID(sGrid, S_Grid_Id, GET_ID(domainPtr, A_Domain_GridId));

	if ((ret = FIN_CreateESEfromGrid(hierStp, sGrid)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "Exit FIN_SelectGridMktSgtCompute with errors. Check log file of Financial server.");
		FREE(sGrid);
        DBA_FreeHier(hierStp);
        return(ret);
	}
	FREE(sGrid);
	return (ret);
}


/*************************************************************************************
*   Function             : FIN_StratSetValueAndMargin()
*
*   Description          : Update field, margin field, contrib field and margin contrib field.
*
*   Arguments            : ESLPtr   : extended strategy link pointer
*			   ESEPtr   : extended strategy element pointer
*			   stratPtr : strategy element pointer
*			   weightFld : weight field (which will decide other fields)
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF3621 - RAK - 990715
*   Modification         : REF7422 - YST - 021113
*
**************************************************************************************/
STATIC RET_CODE FIN_StratSetValueAndMargin(DBA_DYNFLD_STP ESLPtr,
				                           DBA_DYNFLD_STP ESEPtr,
				                           DBA_DYNFLD_STP stratPtr,
				                           int            weightFld)
{
    RET_CODE        ret                 = RET_SUCCEED;
    int             marginWeightFld     = -1;
    int		        contribFld          = -1;
    int             marginContribFld    = -1;
    int             calcContribFld      = ExtStratElt_ObjWeightContrib;
    NUMBER_T	    contrib				= 0.0/*, benchRtn = 0.0*/;
    DBA_DYNFLD_STP  parESEPtr           = NULLDYNST;
    
	/* PMSTA-40213-badhri-23072020 */
	int             lowerMarginWeightFld  = -1;
	int             lowerMarginContribFld = -1;
	int             upperMarginWeightFld = -1;
	int             upperMarginContribFld = -1;

    /* INIT FIELDS ACCORDING TO RECEIVED PARAMETERS */

    /* REF8844 - LJE - 030410 : switch -> if */
    if (weightFld==ExtStratElt_ObjWeight)
    {
	    marginWeightFld  = ExtStratElt_ObjWeightMarg;
	    contribFld       = ExtStratElt_ObjWeightContrib;
	    marginContribFld = ExtStratElt_ObjWeightContribMarg;

		/* PMSTA-40213-badhri-23072020 */
		lowerMarginWeightFld = ExtStratElt_ObjLowerMarg;
		lowerMarginContribFld = ExtStratElt_ObjLowerContribMarg;
		upperMarginWeightFld = ExtStratElt_ObjUpperMarg;
		upperMarginContribFld = ExtStratElt_ObjUpperContribMarg;

        /*  REF4047 - 000126 - SKE */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_BenchEntDictId,
				    stratPtr, A_StratElt, A_StratElt_BenchEntDictId);
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_BenchObjId,
				    stratPtr, A_StratElt,  A_StratElt_BenchObjId);

		/* Ana Bench Obj Id */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_AnaBenchObjId,
				    stratPtr, A_StratElt, A_StratElt_AnaBenchObjId);
		/* Ana Bench Ent Dict Id */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_AnaBenchEntDictId,
				    stratPtr, A_StratElt, A_StratElt_AnaBenchEntDictId);

		SET_NUMBER(stratPtr,A_StratElt_AbsoluteReturn,(GET_NUMBER(stratPtr,A_StratElt_AbsoluteReturn)*100));/* REF7422 MCA 020725 */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_BenchRtn,
					stratPtr, A_StratElt, A_StratElt_AbsoluteReturn); /* REF8555 MCA 020108 */

        /* REF9227 - LJE - 030919 */
		SET_NUMBER(stratPtr,A_StratElt_AbsoluteReturnCurr,(GET_NUMBER(stratPtr,A_StratElt_AbsoluteReturnCurr)*100));
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_BenchRtnCurr,
					stratPtr, A_StratElt, A_StratElt_AbsoluteReturnCurr);
        /**/

		/* REF11457 - RAK - 050928 - Get dynamic weight */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_DynObjWeight,
					stratPtr, A_StratElt, A_StratElt_DynValue);

		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_OldObjWeight,
					stratPtr, A_StratElt, A_StratElt_DBValue);

		/* PMSTA07121 - RAK - 081029 */
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CriticalnessEn,
					stratPtr, A_StratElt, A_StratElt_CriticalnessEn);
    }
    else if (weightFld==ExtStratElt_MinWeight)
    {
        contribFld = ExtStratElt_MinWeightContrib;
    }
    else if (weightFld==ExtStratElt_MaxWeight)
    {
        contribFld = ExtStratElt_MaxWeightContrib;
    }
    else if (weightFld==ExtStratElt_ObjDura)
    {
        marginWeightFld = ExtStratElt_ObjDuraMarg;
    }
    else if (weightFld==ExtStratElt_ObjDuraContrib)
    {
        marginWeightFld = ExtStratElt_ObjDuraContribMarg;
    }
    else if (weightFld==ExtStratElt_ObjBeta)
    {
        marginWeightFld = ExtStratElt_ObjBetaMarg;
    }
    else if (weightFld==ExtStratElt_ObjBetaContrib)
    {
        marginWeightFld = ExtStratElt_ObjBetaContribMarg;
    }
    else if (weightFld==ExtStratElt_ObjCrtYield)
    {
        marginWeightFld = ExtStratElt_ObjCrtYieldMarg;
    }
    else if (weightFld==ExtStratElt_ObjCrtYieldContrib)
    {
        marginWeightFld = ExtStratElt_ObjCrtYieldContribMarg;
    }
    else if (weightFld==ExtStratElt_ObjTrackErr)
    {
        marginWeightFld = ExtStratElt_ObjTrackErrMarg;
    }
    /* No other fields for ExtStratElt_MinRatingRank */

    /* SET VALUE IN FIELDS */
    if (weightFld == ExtStratElt_MinRatingRank)	/* PMSTA08782 - RAK - 091013 - cast necessary */
	{
		SET_SMALLINT(ESEPtr, weightFld, (SMALLINT_T) GET_NUMBER(stratPtr, A_StratElt_Value));
	}
	else
	{
		COPY_DYNFLD(ESEPtr, ExtStratElt, weightFld,
			        stratPtr, A_StratElt,  A_StratElt_Value);
	}

    if (marginWeightFld != -1)
    {
	    if (IS_NULLFLD(stratPtr, A_StratElt_FluctMargin) == FALSE)
	    {
	        SET_NUMBER(ESEPtr, marginWeightFld, GET_NUMBER(stratPtr, A_StratElt_FluctMargin));
	    }
		else if (TRUE == IS_NULLFLD(stratPtr, A_StratElt_LowerMarg) && TRUE == IS_NULLFLD(stratPtr, A_StratElt_UpperMarg))
		{
			if (IS_NULLFLD(ESLPtr, ExtStratLnk_Marg) == FALSE &&
				GET_TINYINT(ESEPtr, ExtStratElt_Level) != 1)
			{
				SET_NUMBER(ESEPtr, marginWeightFld, GET_NUMBER(ESLPtr, ExtStratLnk_Marg));
			}
		}
    }

	/* PMSTA-40213-badhri-23072020 : cascade the lower and upper margin from strat level */
	if(lowerMarginWeightFld != -1)
	{
		if (IS_NULLFLD(stratPtr, A_StratElt_LowerMarg) == FALSE)
		{
			SET_NUMBER(ESEPtr, lowerMarginWeightFld, GET_NUMBER(stratPtr, A_StratElt_LowerMarg));
		}
		else if(TRUE == IS_NULLFLD(stratPtr, A_StratElt_UpperMarg)	&& 
			    TRUE == IS_NULLFLD(stratPtr, A_StratElt_FluctMargin))
		{
			if (IS_NULLFLD(ESLPtr, ExtStratLnk_LowerMarg) == FALSE &&
				GET_TINYINT(ESEPtr, ExtStratElt_Level) != 1)
			{
				SET_NUMBER(ESEPtr, lowerMarginWeightFld, GET_NUMBER(ESLPtr, ExtStratLnk_LowerMarg));
			}
		}
    }
	if (upperMarginWeightFld != -1)
	{
		if (IS_NULLFLD(stratPtr, A_StratElt_UpperMarg) == FALSE)
		{
			SET_NUMBER(ESEPtr, upperMarginWeightFld, GET_NUMBER(stratPtr, A_StratElt_UpperMarg));
		}
		else if(TRUE == IS_NULLFLD(stratPtr, A_StratElt_LowerMarg)	&& 
			    TRUE == IS_NULLFLD(stratPtr, A_StratElt_FluctMargin))
		{
			if (IS_NULLFLD(ESLPtr, ExtStratLnk_UpperMarg) == FALSE &&
				GET_TINYINT(ESEPtr, ExtStratElt_Level) != 1)
			{
				SET_NUMBER(ESEPtr, upperMarginWeightFld, GET_NUMBER(ESLPtr, ExtStratLnk_UpperMarg));
			}
		}
	}

    if (contribFld != -1)
    {
	    /* Update weight contrib using parent information ... */
	    if (IS_NULLFLD(ESEPtr, weightFld) == FALSE &&
	        /* IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE) */ /* REF4047 - 000202 - SKE */
            IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratMktSgtId) == TRUE)
	    {
	        SET_NUMBER(ESEPtr, contribFld, GET_NUMBER(ESEPtr, weightFld));
			if (contribFld == ExtStratElt_ObjWeightContrib) /* PMSTA15213-CHU-121107  */
			{
				SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESEPtr, contribFld));
			}

	        if (marginContribFld != -1)
	        {
		        COPY_DYNFLD(ESEPtr, ExtStratElt, marginContribFld, ESEPtr, ExtStratElt, marginWeightFld);
	        }

			if (lowerMarginContribFld != -1)
			{
				if (IS_NULLFLD(ESEPtr, lowerMarginWeightFld) == FALSE)
					COPY_DYNFLD(ESEPtr, ExtStratElt, lowerMarginContribFld, ESEPtr, ExtStratElt, lowerMarginWeightFld);
			}

			if (upperMarginContribFld != -1)
			{
				if (IS_NULLFLD(ESEPtr, upperMarginWeightFld) == FALSE)
					COPY_DYNFLD(ESEPtr, ExtStratElt, upperMarginContribFld, ESEPtr, ExtStratElt, upperMarginWeightFld);
			}
	    }
	    else
	    {
	        if ((parESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	        {
		        if (IS_NULLFLD(parESEPtr, calcContribFld) == FALSE)
		        {
		            if (IS_NULLFLD(ESEPtr, weightFld) == FALSE)
		            {
			            contrib = GET_NUMBER(ESEPtr, weightFld) *
                                  GET_NUMBER(parESEPtr, calcContribFld) / 100.0;
			            SET_NUMBER(ESEPtr, contribFld, CAST_NUMBER(contrib));
						if (contribFld == ExtStratElt_ObjWeightContrib) /* PMSTA15213-CHU-121107  */
						{
							SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESEPtr, contribFld));
						}
		            }


                    /* REF7422 - YST - 021113 */
					/* REF9075 - RAK - 030730 */
					/* In fact already done in FIN_BenchReturn() */
					/*
                    benchRtn = GET_NUMBER(ESEPtr, ExtStratElt_BenchRtn) * GET_NUMBER(parESEPtr, calcContribFld) / 100.0;
                    SET_NUMBER(ESEPtr, ExtStratElt_BenchRtn, CAST_NUMBER(benchRtn));
					*/

		            if (marginContribFld != -1)
		            {
			            if (IS_NULLFLD(ESEPtr, marginWeightFld) == FALSE)
			            {

							switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))/* <SKE - 010208 - REF5599 */
							{
								case ExtStratEltForecast_Absolute:
	 			                     contrib = GET_NUMBER(ESEPtr, marginWeightFld) *
                                     GET_NUMBER(parESEPtr, calcContribFld) / 100.0;
			                         SET_NUMBER(ESEPtr, marginContribFld, CAST_NUMBER(contrib));
								     break;
								case ExtStratEltForecast_Relative:
 	                                 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
            					     break;
	 			            	case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
								     SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg,
                                     GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
	 			            		 break;
							}

      			        }
		            }

					/* PMSTA-40213-badhri-23072020 : */
					if (lowerMarginContribFld != -1)
					{
						if (IS_NULLFLD(ESEPtr, lowerMarginWeightFld) == FALSE)
						{
							switch (GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))
							{
							case ExtStratEltForecast_Absolute:
								contrib = GET_NUMBER(ESEPtr, lowerMarginWeightFld) *
									GET_NUMBER(parESEPtr, calcContribFld) / 100.0;
								SET_NUMBER(ESEPtr, lowerMarginContribFld, CAST_NUMBER(contrib));
								break;
							case ExtStratEltForecast_Relative:
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg));
								break;
							case ExtStratEltForecast_AbsoluteContrib:
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg,
									GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg));
								break;
							}

						}
					}

					if (upperMarginContribFld != -1)
					{
						if (IS_NULLFLD(ESEPtr, upperMarginWeightFld) == FALSE)
						{
							switch (GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))
							{
							case ExtStratEltForecast_Absolute:
								contrib = GET_NUMBER(ESEPtr, upperMarginWeightFld) *
									GET_NUMBER(parESEPtr, calcContribFld) / 100.0;
								SET_NUMBER(ESEPtr, upperMarginContribFld, CAST_NUMBER(contrib));
								break;
							case ExtStratEltForecast_Relative:
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg));
								break;
							case ExtStratEltForecast_AbsoluteContrib:
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg,
									GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg));
								break;
							}

						}
					}
		        }
	        }
	    }
    }
    return(ret);
}

/*************************************************************************************
*   Function             :	FIN_StratUpdESEAlloc()
*
*   Description          :	Update allocation extended strategy element fields
*							according to loaded strategy elements.
*
*   Arguments            :	ESLPtr   : extended strategy link pointer
*							ESEPtr   : extended strategy element pointer
*							stratPtr : strategy element pointer
*							weightFld : weight field (which will decide other fields)
*
*   Return               :	RET_SUCCEED or error code
*
*   Creation Date        :	REF3621 - RAK - 990715
*
**************************************************************************************/
STATIC RET_CODE FIN_StratUpdESEAlloc(DBA_HIER_HEAD_STP  stratHierPtr,
                                     DBA_DYNFLD_STP     ESLPtr,
                                     DBA_DYNFLD_STP    *ESETab,
                                     int                ESENbr)
{
    RET_CODE	    ret             = RET_SUCCEED;
    DBA_DYNFLD_STP  stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP  parESEPtr       = NULLDYNST;
    DBA_DYNFLD_STP *stratEltTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP  aStratPtr       = NULLDYNST;
    FLAG_T          foundFlg        = FALSE;
    NUMBER_T	    contrib         = 0.0;
    NUMBER_T	    weight          = 0.0;
    int		        stratEltNbr     = 0;
    int		        i;
    int		        j;


	if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext) != NULL) /* PMSTA06840-CHU-080716 ... sinon BOUM */
	{
		aStratPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext)); /*REF9075  030520 MCA -- need for the nature of strategy*/
	}

    /* Read strategy elements */
    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	    (stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
	    /* For each strategy element */
	    stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
	    stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

	    /* Search created extended strategy element with same market segment ... */
        for (i=0 ; i<stratEltNbr ; i++)
	    {
            /*  REF4047 - 000106 - SKE : exclude all Strategy Element
                defining an instrument                                  */
            if ((IS_NULLFLD(stratEltTab[i], A_StratElt_InstrId) == FALSE) &&
				aStratPtr != NULL &&			/* PMSTA06840-CHU-080716 ... sinon BOUM */
				(GET_ENUM(aStratPtr, A_Strat_NatEn) == (STRATNAT_ENUM)StratNat_ModelPtf))/*REF9075  030520 MCA */
            {
               continue;
            }

			/* REF11559 - CHU - 051124 : check validity of Strategy element */
			if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
				IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
				CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
			{
				continue;
			}

	        for (j=0, foundFlg = FALSE ; j < ESENbr && foundFlg == FALSE ; j++)
	        {
		        if (GET_ID(ESETab[j], ExtStratElt_StratHistId) ==
	                GET_ID(stratHistPtr, A_StratHist_Id)
				&&
		            GET_ID(ESETab[j], ExtStratElt_MktSegtId) ==
                   GET_ID(stratEltTab[i], A_StratElt_MktSegtId))
		        {
                    foundFlg = TRUE;

					/* REF10352 - RAK - 040608 - Return is computed on SE with nature Weight - move in case below */
					/* COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtn,
						stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturn); */ /*REF9075  030520 MCA*/

					/* COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtnCurr,
						stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturnCurr); */ /* REF9227 - LJE - 030919 */

                    /* REF4047 - 000105 - SKE */
                    SET_ID(stratEltTab[i], A_StratElt_ExtStratElt_Id, GET_ID(ESETab[j], ExtStratElt_Id));

                    /* PMSTA14459-JPP-120626 */
					COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_StratEltId,
				        stratEltTab[i], A_StratElt,  A_StratElt_Id);

                    /* FIH-REF6989-010911 */
					COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_Priority,
				        stratEltTab[i], A_StratElt,  A_StratElt_Priority);

		            COPY_DYNFLD(ESETab[j],      ExtStratElt, ExtStratElt_HedgeCurrId,
				        stratEltTab[i], A_StratElt,  A_StratElt_HedgeCurrId);

                    /* PMSTA-39969 - sanand - 02062020 */
                    COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ExcludedFlg,
                        stratEltTab[i], A_StratElt, A_StratElt_ExcludedFlg);

                    /* PMSTA-40203 - sanand - 17062020 */
                    COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_NoTargetWeightEn,
                        stratEltTab[i], A_StratElt, A_StratElt_NoTargetWeightEn);

					/* PMSTA-43175-Badhri-21122020 */
					COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_QuasiCashEn,
						stratEltTab[i], A_StratElt, A_StratElt_QuasiCashEn);

					/* Update fields according to strategy element nature */
		            switch ((STRATELTNAT_ENUM) GET_ENUM(stratEltTab[i], A_StratElt_NatEn))
		            {
		                case StratEltNat_Weight :

							/* REF10352 - RAK - 040608 - Return is computed on Weight SE */
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtn,
										stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturn);

							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtnCurr,
										stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturnCurr);

			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjWeight);
			                break;

		                case StratEltNat_MinWeight :
							ret = FIN_StratSetValueAndMargin(ESLPtr,
									                         ESETab[j],
										                     stratEltTab[i],
											                 ExtStratElt_MinWeight);
			                break;

		                case StratEltNat_MaxWeight :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_MaxWeight);
			                break;

		                case StratEltNat_Duration :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjDura);
			                break;

		                case StratEltNat_ContrDura :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjDuraContrib);
			                break;

		                case StratEltNat_Beta :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjBeta);
			                break;

		                case StratEltNat_ContrBeta :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjBetaContrib);
			                break;

		                case StratEltNat_CurrRtn :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjCrtYield);
			                break;

		                case StratEltNat_ContrCurrRtn :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjCrtYieldContrib);
			                break;

		                case StratEltNat_MinRatingRk :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_MinRatingRank);
			                break;

		                case StratEltNat_TrackError :
			                ret = FIN_StratSetValueAndMargin(ESLPtr,
                                                             ESETab[j],
                                                             stratEltTab[i],
				                                             ExtStratElt_ObjTrackErr);
			                break;
                        case StratEltNat_ModelPtf: /* REF5358 - 030528 - MCA */
							/*COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtn,
									    stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturn);*/ /*REF9075  030520 MCA*/
							break;

		                case StratEltNat_Model: /* Stored element for sum */
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjWeight, stratEltTab[i], A_StratElt, A_StratElt_Value);
                            /* REF4047 - 000126 - SKE */
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjWeightMarg, stratEltTab[i], A_StratElt, A_StratElt_FluctMargin);
                            /*<REF4864 000606 SKE */
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchEntDictId, stratEltTab[i], A_StratElt, A_StratElt_BenchEntDictId);
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchObjId, stratEltTab[i], A_StratElt, A_StratElt_BenchObjId);
							/* Ana Bench Obj Id */
					        COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_AnaBenchObjId,  stratEltTab[i], A_StratElt, A_StratElt_AnaBenchObjId);
							/* Ana Bench Ent Dict Id */
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_AnaBenchEntDictId, stratEltTab[i], A_StratElt, A_StratElt_AnaBenchEntDictId);
							/* Instruments for a strategy of nature ModelPtf*/
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtn,
									    stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturn); /*REF9075  030520 MCA*/
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_BenchRtnCurr,
									    stratEltTab[i], A_StratElt,  A_StratElt_AbsoluteReturnCurr); /* REF9227 - LJE - 030919 */

							/* PMSTA07121 - RAK - 081029 */
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_CriticalnessEn,
										stratEltTab[i], A_StratElt, A_StratElt_CriticalnessEn);

                            /* REF4864 000606 SKE> */
                            /* REF4047 - 000126 - SKE : Update weight contrib/margin */
	                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeight) == FALSE &&
                                IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratMktSgtId) == TRUE)
                            {
                                SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeight));
								SET_NUMBER(ESETab[j], ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib)); /* PMSTA15213-CHU-121107  */
                                if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightMarg) == FALSE)
                                {
                                    SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg));
                                }
                            }
                            else
                            {
	                            if ((parESEPtr = FIN_StratGetParESEPtr(ESETab[j])) != NULLDYNST)
	                            {
                                    if (IS_NULLFLD(parESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
                                    {
                                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeight) == FALSE)
                                        {
		                                    contrib = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeight) *
                                                      GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
		                                    SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib, CAST_NUMBER(contrib));
											SET_NUMBER(ESETab[j], ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib)); /* PMSTA15213-CHU-121107  */
                                        }
                                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightMarg) == FALSE)
                                        {

											/* <SKE - 010208 - REF5599 */
										switch(GET_ENUM(ESETab[j], ExtStratElt_ForecastFlg))
										{
											case ExtStratEltForecast_Absolute:
												 contrib = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg) *
														   GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
												 SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg, CAST_NUMBER(contrib));
												 break;
											case ExtStratEltForecast_Relative:
												 SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg));
            									 break;
	 			            				case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
												 SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg,
												 GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg));
	 			            					 break;

										}
                                        }
                                    }
                                }
                            }
			                break;
                        case StratEltNat_ModelConstWeight: /* REF4047 - 000203 - SKE */
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjWeightContrib, stratEltTab[i], A_StratElt, A_StratElt_Value);
							COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_OrigObjWeightContrib, ESETab[j], ExtStratElt, ExtStratElt_ObjWeightContrib); /* PMSTA15213-CHU-121107  */
                            COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjWeightContribMarg, stratEltTab[i], A_StratElt, A_StratElt_FluctMargin);

	                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightContrib) == FALSE &&
                                IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratMktSgtId) == TRUE)
                            {
                                SET_NUMBER(ESETab[j], ExtStratElt_ObjWeight, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib));
                                if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightContribMarg) == FALSE)
                                {
                                    SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib));
                                }
                            }
                            else
                            {
	                            if ((parESEPtr = FIN_StratGetParESEPtr(ESETab[j])) != NULLDYNST)
	                            {
                                    if (IS_NULLFLD(parESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                                        GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib != 0.0))
                                    {
                                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightContrib) == FALSE)
                                        {
		                                    weight = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContrib) * 100.0 /
                                                     GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                                    SET_NUMBER(ESETab[j], ExtStratElt_ObjWeight, CAST_NUMBER(weight));
                                        }

                                        if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjWeightContribMarg) == FALSE)
                                        {
											/* <SKE - 010208 - REF5599 */
										switch(GET_ENUM(ESETab[j], ExtStratElt_ForecastFlg))
										{
											case ExtStratEltForecast_Absolute:
						                        weight = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg) * 100.0 /
                                                         GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                                        SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg, CAST_NUMBER(weight));
                        						 break;
											case ExtStratEltForecast_Relative:
				                                 SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg, GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg));
                                     									 break;
	 			            				case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
						                         weight = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeightContribMarg) * 100.0 /
                                                         GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                                         SET_NUMBER(ESETab[j], ExtStratElt_ObjWeightMarg, CAST_NUMBER(weight));
                                   				 break;
                                            }
                                        }
                                    }
                                }
                            }
                            break;

		            }
                    if (ret != RET_SUCCEED)
                        return(ret);
		        }
	        }
	    }
    }

    /* <SKE 000913 REF5192 : Update absolute/relative ratios */
    if (static_cast<StratSubNatEn> (GET_ENUM(ESLPtr, ExtStratLnk_SubNatEn)) == StratSubNatEn::LoadRatio) /* PMSTA-51103-Deepthi-20221202 */
    {
        stratEltTab = NULLDYNSTPTR;
        stratEltNbr = 0;

        if (IS_NULLFLD(ESLPtr, ExtStratLnk_A_Strat_Ext) == FALSE     &&
            GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext) != NULL  &&
            (aStratPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext))) != NULLDYNST)
        {
	        /* Find the r�f�rence A_StratElt */
            ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
											        A_StratElt,
											        FALSE,
											        FIN_StratFilterRefStratEltByStratId,
											        aStratPtr,
											        NULLFCT,
											        &stratEltNbr,
											        &stratEltTab);
            if (ret != RET_SUCCEED)
            {
                return(ret);
            }
        }

        for (j=0 ; j<ESENbr ; j++)
	    {
            NUMBER_T absRatio = (NUMBER_T)0;
            NUMBER_T relRatio = (NUMBER_T)0;

            for (i=0, foundFlg=FALSE ; i<stratEltNbr && foundFlg == FALSE ; i++)
            {
		        if (GET_ID(ESETab[j], ExtStratElt_StratId) == GET_ID(ESLPtr, ExtStratLnk_StratId) &&
		            GET_ID(ESETab[j], ExtStratElt_MktSegtId) == GET_ID(stratEltTab[i], A_StratElt_MktSegtId))
		        {
                    foundFlg = TRUE;
                    COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjConstrVal, stratEltTab[i], A_StratElt, A_StratElt_Value);
                    COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_ObjConstrMarg, stratEltTab[i], A_StratElt, A_StratElt_FluctMargin);
                }
            }
            absRatio = GET_NUMBER(ESETab[j], ExtStratElt_ObjWeight) - GET_NUMBER(ESETab[j], ExtStratElt_ObjConstrVal);
            SET_NUMBER(ESETab[j], ExtStratElt_ActualWeight, CAST_NUMBER(absRatio));
            if (IS_NULLFLD(ESETab[j], ExtStratElt_ObjConstrVal) == FALSE &&
                GET_NUMBER(ESETab[j], ExtStratElt_ObjConstrVal) != (NUMBER_T)0)
            {
                relRatio = 100.0 * absRatio / GET_NUMBER(ESETab[j], ExtStratElt_ObjConstrVal);
                SET_NUMBER(ESETab[j], ExtStratElt_ActualWeightContrib, CAST_NUMBER(relRatio));
            }
        }
        FREE(stratEltTab);
    }
    /* SKE 000913 REF5192> */

    return(ret);
}

/*************************************************************************************
*   Function             : FIN_StratMktSegtFromGridMktSSubSet()
*
*   Description          : Get market segment for grid "mktSSubSet"
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF7420 - RAK - 020703
*
**************************************************************************************/
RET_CODE FIN_StratMktSegtFromGridMktSSubSet(DBA_HIER_HEAD_STP stratHierHead,
                                            DBA_DYNFLD_STP    gridPtr,
                                            DBA_DYNFLD_STP    **sMSTab,
                                            int               *sMSNbr)
{
    RET_CODE        ret=RET_SUCCEED;
    DBA_DYNFLD_STP  *subSetTab=NULLDYNSTPTR, *tmpMSTab=NULLDYNSTPTR;
    int             subSetNbr=0, subSetIdx=0, tmpMSNbr=0, tmpMSIdx=0;

    /* select mktSSubSet with RefGridId = current grid */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierHead,
											A_MktSSubSet,
											FALSE,
											FIN_FilterMktSSubSetFromGrid,
											gridPtr,
											NULLFCT,
											&subSetNbr,
											&subSetTab)) == RET_SUCCEED)
    {
        /* select mktSegt with MktStructId = current MktSSubset mktStructId */
        for (subSetIdx=0; subSetIdx<subSetNbr; subSetIdx++)
        {
            tmpMSNbr=0;
            tmpMSTab=NULLDYNSTPTR;
            if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierHead,
											S_MktSegt,
											FALSE,
											FIN_FilterMktSegtFromMktStruct,
											subSetTab[subSetIdx],
											NULLFCT,
											&tmpMSNbr,
											&tmpMSTab)) == RET_SUCCEED)
            {
                if (tmpMSNbr > 0)
                {
                    if (((*sMSTab) = (DBA_DYNFLD_STP*) REALLOC((*sMSTab),
                                  ((*sMSNbr)+tmpMSNbr)*sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                    {
                        for (tmpMSIdx=0; tmpMSIdx<tmpMSNbr; tmpMSIdx++)
                        { (*sMSTab)[(*sMSNbr)+tmpMSIdx] = tmpMSTab[tmpMSIdx]; }
                        (*sMSNbr) += tmpMSNbr;
                    }
                    else
                    {
                        ret = RET_MEM_ERR_ALLOC;
                    }
                }
            }
            FREE(tmpMSTab);
        }
        FREE(subSetTab);

        if (ret == RET_SUCCEED && (*sMSNbr) > 0)
        {
            TLS_Sort((char *) (*sMSTab),
                     (*sMSNbr), sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpMSRank, /* REF7264 - LJE - 020201 */
                     (PTR **)NULL, SortRtnTp_None);
        }
    }

    return(ret);
}

/************************************************************************
*
*   Function      :   FIN_FilterMktSSubSetFromGrid()
*
*   Description   :   Return mktSSubSet according to received grid
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   REF7420 - RAK - 020703
*
*************************************************************************/
int FIN_FilterMktSSubSetFromGrid(DBA_DYNFLD_STP dynSt,
                                 DBA_DYNST_ENUM dynStTp,
                                 DBA_DYNFLD_STP gridPtr)
{
    if (GET_ID(dynSt, A_MktSSubSet_RefGridId) == GET_ID(gridPtr, A_Grid_Id))
        return(TRUE);
    return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterNonCalcNoFIN_FilterMktSegtFromMktStructnAllocExtStratElt()
*
*   Description   :   Return MktSegt according to received MktSSubSet (mktStructId)
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   REF7420 - RAK - 020703
*
*************************************************************************/
STATIC int FIN_FilterMktSegtFromMktStruct(DBA_DYNFLD_STP dynSt,
                                          DBA_DYNST_ENUM dynStTp,
                                          DBA_DYNFLD_STP mktSSubSetPtr)
{
    if (GET_ID(dynSt, S_MktSegt_MktStructId) == GET_ID(mktSSubSetPtr, A_MktSSubSet_MktStructId))
        return(TRUE);
    return(FALSE);
}

/************************************************************************
**      END  finlib06.c
*************************************************************************/

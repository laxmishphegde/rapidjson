/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINSRV_H
#define FINSRV_H

/************************************************************************
**      Constant & Macro definitions 
*************************************************************************/

/************************************************************************
**      Structure definitions & typedef
*************************************************************************/
#define FUNDSPLIT_MAXLEVEL   3
#define RISKDECOMPO_MAXLEVEL 4

typedef enum {
	Risk_Cash,
	Risk_Father,
	Risk_Son,
	Risk_LastSon 
} RISK_ANALYSIS_ENUM;

/* DVP190 - DVP191 */
typedef enum {
	Risk_ValoPrice_Dflt,		/* FIN_PosPrice() call */
	Risk_ValoPrice_LastSon,		/* price is computed by difference */
	Risk_ValoPrice_Calc,		/* already calculated, use received pricePtr */
	Risk_ValoPrice_ParPrice, 	/* parent price */
	Risk_ValoPrice_UnderlyOpt, 	/* options */
	Risk_ValoPrice_Underly, 	/* future on cash accounts */
	Risk_ValoPrice_Exchange,	/* forward on cash accounts */
	Risk_ValoPrice_Cheapest 	/* future on cheapest to deliver instrument */
} RISK_VALOPRICE_ENUM;

typedef enum {
	RiskFutFwd_None,
	RiskFutFwd_FutFwd,
	RiskFutFwd_Underly 
} RISK_FUTFWD_ENUM; 

/* PMSTA08736 - LJE - 100125 */
typedef enum
{
    RecInfoBench_PortBenchStorage,
    RecInfoBench_StdPerf,
    RecInfoBench_LastLeaf,
	RecInfoBench_LastLeafWithoutInstr,
	RecInfoBench_CurrentData,
	RecInfoBench_DynWeight,
	RecInfoBench_FactorSet,
	RecInfoBench_AllBenchComputed,
	RecInfoBench_ReturnSet,
	RecInfoBench_BenchRebal,
    RecInfoBench_NewHistoOrRebal,
	RecInfoBench_BenchLevel,
	RecInfoBench_KeepSegt,
	RecInfoBench_Deleted,
	RecInfoBench_NewPeriod,
    RecInfoBench_DynWeightLastLeaf,
    RecInfoBench_NoInstrOnChild,
    RecInfoBench_LastLeafOnChild,
    RecInfoBench_BenchOnChild
} BENCH_RECINFO_MASK;



typedef struct {			/* DVP189 */
	STNSPECTREATMENT_ENUM STNEn;		/* PMSTA-34140 - RAK - Structured notes specifications */
	IDXCALCRULE_ENUM idxCalcRuleEn;
	DBA_DYNFLD_STP	 pricePtr;
	NUMBER_T         qty;
	PRICE_T          price;
	ID_T             priceCurrId;
} RISK_QTY_ST, *RISK_QTY_STP;

typedef struct {			/* DVP440 */
	ID_T		  currId;
	ID_T		  underlyId;
	DATETIME_T        begDate;
	DATETIME_T        endDate;
	ACCRRULE_ENUM	  accrRuleEn;
	NUMBER_T          rate;
	CODE_T		  code;
	NAME_T		  name;
	VALRULE_ENUM	  valRuleEn;	/* REF53.1 */
} FIN_MONEYMKTINFO_ST, *FIN_MONEYMKTINFO_STP;

typedef enum {
	FinFundRisk_None,
	FinFundRisk_FundCompo,
	FinFundRisk_FundRisk
} FIN_FUNDRISK_ENUM;


typedef struct {
	DATETIME_T        fromDateTime;
	ID_T              refCurrId;
	char              fusDatePtfFlg;
	FUSDATERULE_ENUM  domFusDateRule;
	OPTDELTARULE_ENUM optDeltaRule;
	FIN_FUNDRISK_ENUM fundRiskEn;
	char              riskDecompoLevel;
} FIN_DOMAIN_ARG_ST, *FIN_DOMAIN_ARG_STP;


/* DVP232 - Return by market segment */
typedef struct {	
	ID_T	instrId;
	ID_T	gridId;
	ID_T	mktSgtId;
} RETURN_GRIDINSTR_ST, *RETURN_GRIDINSTR_STP;

typedef struct {
	RETURN_GRIDINSTR_STP        gridInstrTab;
	ID_T                        *gridTab;
	int		                    gridInstrNbr;
	int		                    gridNbr;	
    RETURN_GRID_LNK_NAT_ENUM    gridLinkNatEn;  /* REF7395 - YST - 021003 */
	DATETIME_T                  classifDate;    /* WEALTH-8023 - DDV - 240628 */
} RETURN_GRID_INFO_ST, *RETURN_GRID_INFO_STP;

/* DVP165 - DVP232 - Periodic information for each portfolio */
typedef struct {
	ID_T	   ptfId;
	DATETIME_T lastDate;
	ID_T       *lastPerInstr;
	ID_T       *crtPerInstr;
	int        allocSz;
	int        lastNbr;
	int        crtNbr;
} RETURN_PTFPER_INFO_ST, *RETURN_PTFPER_INFO_STP;

typedef struct {
	RETURN_PTFPER_INFO_STP ptfPerInfoTab;	
	int		       allocPtfNbr;
	int		       ptfNbr;
	int		       ptfIdx;
	DATE_T     	       refDate;
	DATETIME_T 	       lastCrystDate;
	int        	       perNbr;
	PERSISTNAT_ENUM	       persistEn;	/* DVP479 */
} RETURN_PER_INFO_ST, *RETURN_PER_INFO_STP;

typedef enum {
	compaFreq_Ok,		/* Nothing to do */
	compaFreq_Group,	/* Group initial frequency to final frequency */
	compaFreq_Impossible 	/* Impossible */
} COMPA_FREQ_ENUM;

typedef struct {
	DATETIME_T             domFromDate;     /* REF2728 - 980917 */
	REVERSAL_METHODE_ENUM  reversalMethode; /* REF4198 - 991208 - DED */
    FLAG_T                 initBpFlg;             /* REF11269 - LJE - 060518 */
    BPTNAT_ENUM            posBpNatByRankTab[10]; /* REF11269 - LJE - 051220 */
	BPTNAT_ENUM			   balPosNat;			  /* PMSTA05513 - RAK - 080229 */
} RETURN_ARG_ST, *RETURN_ARG_STP;



/* DVP232 */
#define FREE_GRIDINFO(g) { FREE((g).gridInstrTab); (g).gridInstrNbr=0; FREE((g).gridTab); (g).gridNbr=0; }
#define FREE_GRIDINFOINSTR(g) { if ((g).gridInstrTab != (RETURN_GRIDINSTR_STP)NULL)\
				{FREE((g).gridInstrTab);} (g).gridInstrNbr=0; }
#define FREE_PERINFO(p)  { FREE(p.ptfPerInfoTab); p.allocPtfNbr=0; }


#include "finsrv01.h"
#include "finsrv02.h"
#include "finsrv05.h"
#include "finsrv10.h"
#include "finsrv11.h"
#include "finsrvous.h"  /* PMSTA-26250 - DDV - 170322 */
#include "finrisk.h"
#include "srvperf1.h"   /* REF7423 - RAK - 020314 */
#include "srvperf2.h"   /* REF7423 - RAK - 020314 */
#include "srvperf3.h"   /* REF7421 - YST - 020726 */
#include "srvperf4.h"  /*PMSTA-48195*/


#endif         /*  #ifndef FINSRV_H */
/************************************************************************
*       END           finsrv.h                                   UNICIBLE	
*************************************************************************/

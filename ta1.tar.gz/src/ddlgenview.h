/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENVIEW_H
#define DDLGENVIEW_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenview.cpp
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DDLGENVIEW_CPP
#define	EXTERN
#else
#define EXTERN extern
#endif

#include      "ddlgen.h"

class DdlGenView :public DdlGen {

public:
    // Constructors
    DdlGenView(OBJECT_ENUM           objectEn,
               DDL_VIEW_ENUM         viewEn,
               DdlGenContext        &paramDdlGenContext,
               DdlGenEntity         *paramDdlGenEntityPtr,
               DdlGenFile           *paramFileHelper,
               TARGET_TABLE_ENUM     paramTargetTableEn);

    // Destructor
    virtual ~DdlGenView();

    // Methods
    virtual RET_CODE          build();
    virtual RET_CODE          printHeader();
    virtual RET_CODE          drop();
    virtual RET_CODE          grant();

    RET_CODE                  setViewEn(DDL_VIEW_ENUM viewEn);
    std::string               getVewSep();   /* PMSTA-26250 - LJE - 170327 */

    void                      setDefaultFromViewEn();

    /* PMSTA-nuodb - LJE - 190503 */
    static std::string        getBaseSqlName(DICT_ENTITY_STP dictEntityStp);
    static std::string        getVewSep(DDL_GEN_MODE_ENUM ddlGenMode);
    static std::string        getName(DICT_ENTITY_STP dictEntityStp, DDL_VIEW_ENUM viewEn, DDL_GEN_MODE_ENUM ddlGenMode);
    static std::string        getViewExtension(DDL_VIEW_ENUM viewEn);

protected:

    RET_CODE create();

	RET_CODE setUser(std::string user_name = std::string()); /* PMSTA-14785 - LJE - 120827 */

    RET_CODE      setName();
    RET_CODE      setGroupToGrant();
    RET_CODE      setAccessToGrant();

    RET_CODE      printFooter();

private:
    DDL_VIEW_ENUM   m_viewEn;

};


#endif	                               /* ifndef DDLGENVIEW_H */
/************************************************************************
**      END       ddlgenview.h                                   Odyssey
*************************************************************************/

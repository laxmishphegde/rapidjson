/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBIBCP
#include <string.h>
#include "unidef.h"
#include "dbibcp.h"
#include "sybbcp.h"
#include "orabcp.h"
#include "syslib.h"
#include "dba.h"
#include "dbiconnection.h"
/************************************************************************
**      Include files
*************************************************************************/

/************************************************************************
**      Local functions
**
**
*************************************************************************/

/*************************************************************************
*
*   Function             : DBI_BcpFree
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Created              :
*
*   Last modif.          : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*                          PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
*
*************************************************************************/
void DBI_BcpFree(DBI_BLKDEF_STP & _blkdef)                                                  /* PMSTA-23981 - 070716 - PMO */
{
	// based on connection type call the accurate sublayer bcp free
	switch (_blkdef->dbiConnPtr->m_connectToRDBMS)
    {
	    case Sybase:
            {
                SYB_BLKDEF_STP sybBlkdef = static_cast<SYB_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-23981 - 070716 - PMO */
		        SYB_BcpFree(sybBlkdef);
            }
		    break;

	    case Oracle:
            {
                ORA_BLKDEF_STP oraBlkdef = static_cast<ORA_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-25190 - 061116 - PMO */
		        ORA_BcpFree(oraBlkdef);
            }
		    break;
	}

    delete _blkdef;                                                                         /* PMSTA-23981 - 070716 - PMO */
    _blkdef = nullptr;                                                                      /* PMSTA-23981 - 070716 - PMO */
}


/*************************************************************************
*
*   Function             : DBI_BcpInInit
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Created              :
*
*   Last modif.          : PMSTA-21017 - 251015 - PMO : General small fix
*                          PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
RET_CODE DBI_BcpInInit(DbiConnection&   dbiConn,
                       char            *tableName,
                       SYSNAME_T       *columnName,
                       DATATYPE_ENUM   *fieldType,
                       int              colNb,
                       int              firstCol,
                       int              count,
                       void           **blkdef)
{
	/*
	** Check parameters
	*/
	if (colNb <= 0 || colNb > 100000 || count <= 0 || count > 100000)
	{
		return(RET_DBA_ERR_SETPARAM);
	}

	/*
	** Allocate a DBI_BLKDEF_ST structure
	*/
	DBI_BLKDEF_STP _blkdef = nullptr;

    try
    {
        _blkdef = new DBI_BLKDEF_ST();
    }
    catch(std::bad_alloc)
    {
		return RET_MEM_ERR_ALLOC;
    }

	/*
	** save bulk copy parameters
	*/
	*blkdef               = (void*)_blkdef;
	_blkdef->dbiConnPtr   = &dbiConn;
	_blkdef->colNb        = colNb;
	_blkdef->firstCol     = firstCol;
	_blkdef->count        = count;
	_blkdef->curRow       = 0;

    nstrncpy(_blkdef->tableName, sizeof(_blkdef->tableName), tableName, GET_MAXDATALEN(LongSysnameType)); /* PMSTA-33077 - DLA - 181003 */
    *((char*)_blkdef->tableName + GET_MAXCHARLEN(LongSysnameType)) = '\0';                                /* PMSTA-33077 - DLA - 181003 */

	if ((_blkdef->fieldType = (DATATYPE_ENUM*)CALLOC(_blkdef->colNb, sizeof(DATATYPE_ENUM))) == NULL)
	{
		return(RET_MEM_ERR_ALLOC);
	}
	memcpy(_blkdef->fieldType, fieldType, colNb * sizeof(DATATYPE_ENUM));

    if ((_blkdef->colName = (SYSNAME_T*)CALLOC(_blkdef->colNb, sizeof(SYSNAME_T))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }
    memcpy(_blkdef->colName, columnName, colNb * sizeof(SYSNAME_T));

	void *      childBlkDef = NULL;
	RET_CODE    res         = RET_SUCCEED;

	switch (dbiConn.m_connectToRDBMS)
    {
	case Sybase:
		res = SYB_BcpInInit(_blkdef, &childBlkDef);
		break;
	case Oracle:
		res = ORA_BcpInInit(_blkdef, &childBlkDef);
		break;
	}

	return res;
}


/*************************************************************************
*
*   Function             : DBI_BcpInsert
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Created              :
*
*   Last modif.          : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*                          PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
*
*************************************************************************/
RET_CODE DBI_BcpInsert(DBA_DYNFLD_STP  record,
                       DBI_BLKDEF_STP  _blkdef,                             /* PMSTA-23981 - 070716 - PMO */
                       int *           outRowNb,
                       const char *    objectName)
{
    RET_CODE res = RET_SUCCEED;                                             /* PMSTA-23981 - 070716 - PMO */

    if (_blkdef == NULL || _blkdef->internal == NULL) /* PMSTA-42866 - ARUN - 25012021*/
    {
        return(RET_DBA_ERR_INSERT_FAILED);
    }

    switch (_blkdef->dbiConnPtr->m_connectToRDBMS)
    {
        case Sybase:
        {
            SYB_BLKDEF_STP sybBlkdef = static_cast<SYB_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-25190 - 061116 - PMO */
            res = SYB_BcpInsert(record, sybBlkdef, outRowNb, objectName);
        }
        break;

        case Oracle:
        {
            ORA_BLKDEF_STP oraBlkdef = static_cast<ORA_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-25190 - 061116 - PMO */
            res = ORA_BcpInsert(record, oraBlkdef, outRowNb);
            if (res == RET_DBA_ERR_INSERT_FAILED) /* PMSTA-42866 - ARUN - 25012021 - ensure pointer is NULL after being freed */
            {
                _blkdef->internal = NULL;
            }
        }
        break;
    }

    return res;
}


/*************************************************************************
*
*   Function             : DBI_BcpEnd
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Created              :
*
*   Last modif.          : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*                          PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
*
*************************************************************************/
RET_CODE DBI_BcpEnd(DBI_BLKDEF_STP  _blkdef,                                                /* PMSTA-23981 - 070716 - PMO */
                    int *           outRowNb,
                    const char *    objectName)
{
    RET_CODE        res = RET_SUCCEED;                                                   /* PMSTA-23981 - 070716 - PMO */

    if (_blkdef == NULL || _blkdef->internal == NULL) /* PMSTA-42866 - ARUN - 25012021*/
    {
        return(RET_DBA_ERR_INSERT_FAILED);
    }
    switch (_blkdef->dbiConnPtr->m_connectToRDBMS)
    {
        case Sybase:
        {
            SYB_BLKDEF_STP sybBlkdef = static_cast<SYB_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-23981 - 070716 - PMO */
            res = SYB_BcpEnd(sybBlkdef, outRowNb, objectName);
            _blkdef->internal = NULL; /* PMSTA-50997 - JBC - 221104 */
        }
        break;

        case Oracle:
        {
            ORA_BLKDEF_STP oraBlkdef = static_cast<ORA_BLKDEF_STP>(_blkdef->internal);  /* PMSTA-25190 - 061116 - PMO */
            res = ORA_BcpEnd(oraBlkdef, outRowNb);
            _blkdef->internal = NULL; /* PMSTA-50997 - JBC - 221104 */ /* PMSTA-42866 - ARUN - 25012021 */
        }
        break;
    }

    return res;
}

/*************************************************************************
*
*   Function             : DBI_GetBcpBlockSize
*
*   Description          : This function returns the size of elt buffer
*
*   Arguments            : pointer on SYB_BLKDEF_ST struct
*
*   Return               : int
*
*   Created              : REF10281 - CHU - 040507
*
*   Last modif.          : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
int DBI_GetBcpBlockSize(DBI_BLKDEF_STP blkdef) /* PMSTA-23981 - 070716 - PMO */
{
	return blkdef->count;                      /* PMSTA-23981 - 070716 - PMO */
}

/************************************************************************
**      END          dbibcp.c
*************************************************************************/


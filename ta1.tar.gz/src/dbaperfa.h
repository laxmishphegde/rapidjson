/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBAPERFA_H
#define DBAPERFA_H

/************************************************************************
**      External Structure definitions
*************************************************************************/

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/***********************************************************************
**      BEGIN External definitions attached to : dbaperfa.c
*************************************************************************/

extern RET_CODE DBA_InitObjectLnkForInstrStratPtf(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, RETURNINPARENTPTFRULE_ENUM); /* PMSTA-10775 - LJE - 101105 */
extern RET_CODE DBA_InitObjectLnkForListPtf(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, RETURNINPARENTPTFRULE_ENUM); /*PMSTA-53952 - Lalby - 14112023 */
extern RET_CODE DBA_UpdateObjectLnkForRiskFree(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
extern RET_CODE DBA_LoadInstrPtfStrat(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, DbiConnection &, int); /* PMSTA12427-CHU-110725 */
extern RET_CODE DBA_LoadInstrPtfStratCurrThird(DBA_HIER_HEAD_STP  *, DBA_DYNFLD_STP, DbiConnectionHelper&, int);
extern RET_CODE DBA_FillVectorIdAndLoadData(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnection&);
extern RET_CODE DBA_UpdateObjectLnkForBench(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
extern RET_CODE DBA_SelStratHistoCompo(ID_T, DATE_T, DATE_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *); /* REF9187 - LJE - 030616 */
extern RET_CODE DBA_GenerateSPFromExtRA(DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP **, int *);

extern RET_CODE DBA_SelectStratLnkByPtf(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, EXPANDSTRAT_ENUM, DBA_DYNFLD_STP **, int*); /* REF9187 - LJE - 030630 */

extern RET_CODE DBA_FilterBestStratLnk(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP **, int *, int);   /* PMSTA-50467 - JBC - 221112 */

/* PMSTA07331 - LJE - 081030 */
extern FREQUNIT_ENUM FIN_GetDomainFreqEnForPAA(DBA_DYNFLD_STP, OBJECT_ENUM);
extern FREQUNIT_ENUM FIN_GetMinDomainFreqEnForPAA(DBA_DYNFLD_STP);

extern RET_CODE DBA_UseCompPeriodsForStratLnk(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T, DATETIME_T *, DATETIME_T *, CODE_T *, DatePeriodVec &); /*PMSTA-27728-NRAO-190211*/ /* PMSTA-50467 - JBC 221222 */
extern RET_CODE DBA_MergePerfCompPeriods(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP * ptfTab, int); /* PMSTA-50467 - JBC 221222 */

#endif	 /* ifndef DBAPERFA_H */

/************************************************************************
**      END        dbaperfa.h                                    UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AAABPI_C

/************************************************************************
**      Includes
*************************************************************************/

#include "os.h"
#include "syslib.h"
#include <iostream>

#ifdef NTWIN
#pragma warning(push)
#pragma warning(disable:4127)
#endif

#include "QCoreApplication"
#include "submitbpi.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

using namespace std;

/************************************************************************
**      Static Data Definitions
*************************************************************************/
static int  SV_ServerMode = FALSE;
static int  SV_ServerInitFlg = TRUE;

/************************************************************************
**      Global Data Definitions
*************************************************************************/
int  EV_GuiActivatedFlg = 0;
int  EV_TestNewScpt = 1;
int  EV_OptiMemFlg = FALSE;
int *EV_ServerMode = &SV_ServerMode;
int *EV_ServerInitFlg = &SV_ServerInitFlg;
QCoreApplication *app;
CODE_T      EV_DbTimeZoneCd = "";


/************************************************************************
** **   Function             : initCallback()
** **
** **   Description          : No special initialization at this level for the GUI
** **
** **   Arguments            : None
** **
** **   Functions call       : None
** **
** **   Return               : None
** **
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
        , GEN_ThreadDataCtxGenericAllocate
        , GEN_ThreadDataCtxGenericInit
        , GEN_ThreadDataCtxGenericPrepareApplicationData
        , GEN_ThreadDataCtxGenericCleaningApplicationData
        , GEN_ThreadDataCtxGenericDestroy);
}


/*************************************************************************
** **
** **   Function     : convertToString()
** **
** **   Description  : Converts the argv parameters list to 
** **                   vector of strings.
** **
** **   Arguments    : argNbr ( Number of parameters in argv )
** **                  argv ( all the parameters )
** **
** **   Return       : argvNew ( all the parameters converted to
** **                             vector of strings )
** **
** **********************************************************************/
void convertToString(int *argNbr, char **argv, std::vector<std::string> & argvNew)
{
    int n = 0;
    
    for (int i = 0; i < *argNbr; i++)
    {
            argvNew.push_back(argv[i]);
            n++;
    }
}


/************************************************************************
** **
** **  Function    :   main()
** **
** **  Description :   Application entry point and exception intercepting
** **
** **  Arguments   :   argc  parameters number
** **                  argv  parameters list (first is application)
** **
** **  Return      :   0 if ok
** **                  >0 if error
** **
*************************************************************************/
int main(int argc, char *argv[])
{
    SubmitBpiExitVal ret = SubmitBpiExitVal::BPI_SUCCESS;
    int argc1 = 1;
    app = new QCoreApplication(argc1, argv);
    AaaMetaDict::load();

#ifndef _DEBUG
    try
    {
#endif
        initCallback();

        if (true == SYS_CreateMainThreadDataStorage())
        {
            char *hideArgsFlg = NULL, *startupParam = NULL;
            SubmitBpi  sBpi;

            if ((hideArgsFlg = SYS_GetEnv("HIDE_ARGS")) != NULL &&
                strcmp(hideArgsFlg, "1") == 0 &&
                (startupParam = SYS_GetEnv("AAA_STARTUP_PARAMS")) != NULL)
            {
                int argNbr = 0;
                char **argTab = NULL;
                MemoryPool mp;

                if (GEN_TreatStartupParams(startupParam, argv, &argNbr, &argTab, mp) == FALSE)
                    return (ret == SubmitBpiExitVal::BPI_SUCCESS) ? 0 : 1;

                std::vector<std::string> argNew;
                convertToString(&argNbr, argTab, argNew);
                ret = sBpi.mainSubmitBpi(argNew);
            }
            else
            {
                std::vector<std::string> argNew;
                convertToString(&argc, argv, argNew);
                ret = sBpi.mainSubmitBpi(argNew);
            }

            SYS_FreeMainThreadDataStorage((ret == SubmitBpiExitVal::BPI_SUCCESS) ? 0 : 1);
        }
        else
        {
            ret = SubmitBpiExitVal::BPI_FAIL;
        }
#ifndef _DEBUG
    }
    catch (...)
    {
        if (SYS_IsStateLoggingAllowed())
        {
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
        else
        {
            exceptionHandler(FILEINFO, MSG_SendStderr);
        }
    }
#endif

    delete app;
    return ( ret == SubmitBpiExitVal::BPI_SUCCESS ) ? 0 : 1;
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType()
{
    return(AAAProgramType::Bpi);
}

/************************************************************************
**      END  aaabpi.cpp
*************************************************************************/


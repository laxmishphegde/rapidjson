/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DbiConnection_H_
#define DbiConnection_H_

#include "aaalogger.h" // forward class declaration not possible for nested class (AAALogger::Level)!
#include "unidef.h"
#include "aaaconnection.h"
#include "gen.h"
#include "dba.h"
#include "date.h"
#include "dbi.h"
#include "dbisqlexecbyblock.h"
#include <chrono>


extern bool    EV_CheckTransState;
extern int     EV_MaxNumberArgument;

class RequestHelper;
class DdlGenContext;
class DdlGenFromFile;
class DdlGenDbaAccess;
class DbaCallGuard;
class DdlGenMsg;


typedef struct SCPT_DFLTVAL *SCPT_DFLTVAL_STP;
typedef struct SCPT_ARG     *SCPT_ARG_STP;

class DbaMsgStackMemberClass
{
public:
    DbaMsgStackMemberClass()
        : msgOrigin(NullHandler)
        , rdbmsMsgNb(0)
        , applMsgNb(0)
        , retCode(RET_SUCCEED)
        , severity(0)
        , severityStr(std::string())
        , state(0)
        , stateStr(std::string())
        , isAlreadyWritedInLog(false)
        , isTrfToMsgStruct(false)
        , line(-1)
        , recordPos(0)
    {
    }

    virtual ~DbaMsgStackMemberClass()
    {
    }

    DbaMsgStackMemberClass(const DbaMsgStackMemberClass &ref)
        : DbaMsgStackMemberClass()
    {
        *this = ref;
    }

    DbaMsgStackMemberClass & operator=(const DbaMsgStackMemberClass &toCopy)
    {
        this->msgOrigin            = toCopy.msgOrigin;
        this->rdbmsMsgNb           = toCopy.rdbmsMsgNb;
        this->applMsgNb            = toCopy.applMsgNb;
        this->retCode              = toCopy.retCode;
        this->severity             = toCopy.severity;
        this->severityStr          = toCopy.severityStr;
        this->state                = toCopy.state;
        this->stateStr             = toCopy.stateStr;
        this->isAlreadyWritedInLog = toCopy.isAlreadyWritedInLog;
        this->isTrfToMsgStruct     = toCopy.isTrfToMsgStruct;
        this->procedure            = toCopy.procedure;
        this->serverName           = toCopy.serverName;
        this->msgString            = toCopy.msgString;
        this->line                 = toCopy.line;
        this->recordPos            = toCopy.recordPos;

        return *this;
    }

    void clear()
    {
        this->msgOrigin            = NullHandler;
        this->rdbmsMsgNb           = 0;
        this->applMsgNb            = 0;
        this->retCode              = RET_SUCCEED;
        this->severity             = 0;
        this->severityStr.clear();
        this->state                = 0;
        this->stateStr.clear();
        this->isAlreadyWritedInLog = false;
        this->isTrfToMsgStruct     = false;
        this->procedure.clear();
        this->serverName.clear();
        this->msgString.clear();
        this->line                 = -1;
        this->recordPos            = 0;
    }

    DBA_MSG_ORIGIN_ENUM      msgOrigin;
    int                      rdbmsMsgNb;
    int                      applMsgNb;
    RET_CODE                 retCode;

    int                      severity;
    std::string              severityStr;
    int                      state;
    std::string              stateStr;
    bool                     isAlreadyWritedInLog;
    bool                     isTrfToMsgStruct;

    std::string              procedure;
    std::string              serverName;
    std::string              msgString;
    int                      line;
    int                      recordPos;
};

class DbaMsgStackClass
{
public:
    DbaMsgStackClass()
        : lastMsgNb(0)
    {
    }

    virtual ~DbaMsgStackClass()
    {
    }

    DbaMsgStackClass(const DbaMsgStackClass &ref)
        : DbaMsgStackClass()
    {
        *this = ref;
    }
    
    DbaMsgStackClass & operator=(const DbaMsgStackClass &toCopy)
    {
        this->lastMsgNb     = toCopy.lastMsgNb;
        this->msgStackMbTab = toCopy.msgStackMbTab;

        return *this;
    }

    void clear()
    {
        this->lastMsgNb = 0;
        this->msgStackMbTab.clear();
    }

    int size()
    {
        return static_cast<int>(this->msgStackMbTab.size());
    }

    bool empty()
    {
        return this->msgStackMbTab.empty();
    }

    DbaMsgStackMemberClass &getNewMember()
    {
        this->msgStackMbTab.resize(this->msgStackMbTab.size() + 1);

        return this->msgStackMbTab.back();
    }

    DbaMsgStackMemberClass &getLastMember()
    {
        return this->msgStackMbTab.back();
    }

    void popLastMember()
    {
        return this->msgStackMbTab.pop_back();
    }

    DbaMsgStackMemberClass &getMember(int idx)
    {
        if (idx < this->size())
        {
            return this->msgStackMbTab[idx];
        }
        return getLastMember();
    }

    int                                  lastMsgNb;

protected:

    std::vector<DbaMsgStackMemberClass>  msgStackMbTab;
};

class DbiColInfo
{
public:
    DbiColInfo(FIELD_IDX_T   columnPos,
               std::string   columnName,
               DATATYPE_ENUM dataType,
               bool          isDb)
        : m_columnPos(columnPos)
        , m_columnName(columnName)
        , m_dataType(dataType)
        , m_isDb(isDb)
    {
    }

    DbiColInfo(const DbiColInfo &ref)
        : DbiColInfo(ref.m_columnPos, ref.m_columnName, ref.m_dataType, ref.m_isDb)
    {
    }

    DbiColInfo & operator=(const DbiColInfo &ref)
    {
        this->m_columnPos  = ref.m_columnPos;
        this->m_columnName = ref.m_columnName;
        this->m_dataType   = ref.m_dataType;
        this->m_isDb       = ref.m_isDb;

        return *this;
    }

    FIELD_IDX_T       m_columnPos;
    std::string       m_columnName;
    DATATYPE_ENUM     m_dataType;
    bool              m_isDb;
};

#include "dbibinddatadef.h"

class DbiInOutData : public AAAObject
{
public:
    DbiInOutData(DATATYPE_ENUM dataType, bool bInpout = false, bool bOutput = true, const std::string &sqlName = std::string(), bool = true);
    DbiInOutData(DBA_DYNFLD_STP dynFldStp, bool bInpout = false, bool bOutput = true, const std::string &sqlName = std::string());
    ~DbiInOutData();

    DbiInOutData(const DbiInOutData &) = delete;
    DbiInOutData & operator=(const DbiInOutData &) = delete;

    void               setOutputDynFldStp(DBA_DYNFLD_STP outputDynFldStp);
    void               initNullValue();
    DBA_DYNFLD_STP     getDynFldStp();
    DBA_DYNFLDDATA_UN *getDataPtr();
    size_t             getAllocSize();
    size_t             getDataSize();

    void               setCharPtr(const char *);
    const char        *getCharPtr();
    void               setUCharPtr(const UChar *);
    const UChar       *getUCharPtr();

    bool               isNull();
    void               updOutputData();
    void               clear();

    void               setPtrToFree(void *);

    DATATYPE_ENUM      m_dataType;
    DBI_SMALLINT       m_nullInd;
    DBI_INT            m_dataLength;
    void              *m_valuePtr;
    DBA_DYNFLD_STP     m_outputDynFldStp;

    std::string        m_sqlName;
    bool               m_bInput;
    bool               m_bOutput;
    bool               m_bOutputOnly;
    DATATYPE_ENUM      m_paramDataType;

    FIELD_IDX_T        m_fieldIdx;
    FIELD_IDX_T        m_colPos;
    FIELD_IDX_T        m_outputFieldIdx;

    bool               m_sqlTraceHide;
    DBI_INT64          m_strLenInd;     /* PMSTA-40978 - Smitha - Indicator for sql Server corresponding to SQLLEN */

protected:
    size_t             m_size;
    size_t             m_allocSize;

    DBA_DYNFLD_ST      m_dynFldSt;

private:

    void              *m_ptrToFree;
};

class DbiBatchOutput
{
public:
    DbiBatchOutput()
        : rowNum(0)
        , id(0)
        , rowVersion(0)
    { }

    DbiBatchOutput(const DbiBatchOutput &ref)
        : DbiBatchOutput()
    {
        *this = ref;
    }

    virtual ~DbiBatchOutput()
    {
    }

    DbiBatchOutput& operator= (const DbiBatchOutput &toCopy)
    {
        this->rowNum     = toCopy.rowNum;
        this->id         = toCopy.id;
        this->rowVersion = toCopy.rowVersion;

        return *this;
    }

    bool operator== (const DbiBatchOutput &toCmp)
    {
        return this->rowNum == toCmp.rowNum;
    }

    bool operator< (const DbiBatchOutput &a) const
    {
        return rowNum < a.rowNum;
    }

    INT_T           rowNum;
    ID_T            id;
    TIMESTAMP_T     rowVersion;
};

class DbiInputParam
{
public:

    DbiInputParam(std::string sqlname, DATATYPE_ENUM dataTypeEn)
        : m_sqlname(sqlname)
        , m_dataTypeEn(dataTypeEn)
    {
    }

    DbiInputParam(const DbiInputParam& ref)
        : DbiInputParam(ref.m_sqlname, ref.m_dataTypeEn)
    {
    }

    virtual ~DbiInputParam()
    {
    }

    DbiInputParam& operator= (const DbiInputParam& toCopy)
    {
        this->m_sqlname    = toCopy.m_sqlname;
        this->m_dataTypeEn = toCopy.m_dataTypeEn;

        return *this;
    }

    std::string   m_sqlname;
    DATATYPE_ENUM m_dataTypeEn;
};

/* DLA - PMSTA-29886 - 180126 */
enum class AAATransactionEnum
{
    NotTransactionnal,
    Transactionnal
};

class DBI_MsgError
{
public:
    DBI_MsgError();
    virtual ~DBI_MsgError();
    DBI_MsgError &       operator=(const DBI_MsgError &) = delete;

    static bool          isTechMsg(RET_CODE);
};

class DbiSqlTrace
{
public:
    DbiSqlTrace();

    ~DbiSqlTrace() {};

    DbiSqlTrace(const DbiSqlTrace&) = delete;
    DbiSqlTrace &       operator=(const DbiSqlTrace &) = delete;


    enum class Mode
    {
        Undefined,
        Rpc,
        Lang,
        FmtElt,
        Connection
    };

    void                clear();
    void                sendSqlTrace() { sendSqlTrace("", NO_VALUE, nullptr, 1); };
    void                sendSqlTrace(std::string dbName, int connectNo, DbaMsgStackClass* msgStack, size_t requestLevel);

    std::string         m_command;
    std::string         m_procedure;
    std::stringstream   m_request;
    RET_CODE            m_retCode;
    AAALogger::Level    m_logLevel;
    std::string         m_fmtEltInfo;
    int                 m_fmtRowNbr;
    DbiSqlTrace::Mode   m_mode;
    std::string         m_function;

    TIMER_ST            m_timer;
    INT64_T             m_startTime_ms;
};

class DbiSqlRequest
{
public:

    DbiSqlRequest(KindOfRequest kindOfRequest)
        : m_kindOfRequest(kindOfRequest)
        , m_currentAction(DBA_ACTION_ENUM::Custom)
        , m_currProcedure(nullptr)
        , m_isInit(false)
        , m_bFromRequestHelper(false)
        , m_currResultSet(0)
    {
    }

    DbiSqlRequest(const DbiSqlRequest &ref)
        : DbiSqlRequest(ref.m_kindOfRequest)
    {
        *this = ref;
    }
    virtual ~DbiSqlRequest()
    {
    }

    DbiSqlRequest&       operator=(const DbiSqlRequest &toCopy)
    {
        this->m_kindOfRequest            = toCopy.m_kindOfRequest;
        this->m_currentAction            = toCopy.m_currentAction;
        this->m_currProcedure            = toCopy.m_currProcedure;
        this->m_isInit                   = toCopy.m_isInit;
        this->m_bFromRequestHelper       = toCopy.m_bFromRequestHelper;
        this->m_requestStr               = toCopy.m_requestStr;
        this->m_requestParamMap          = toCopy.m_requestParamMap;
        this->m_colInfoVector            = toCopy.m_colInfoVector;
        this->m_requestOutputVector      = toCopy.m_requestOutputVector;
        this->m_requestBindDataVector    = toCopy.m_requestBindDataVector;
        this->m_currResultSet            = toCopy.m_currResultSet;
        this->m_batchOutputSet           = toCopy.m_batchOutputSet;

        return *this;
    }

    KindOfRequest                           m_kindOfRequest;
    DBA_ACTION_ENUM                         m_currentAction;
    DBA_PROC_STP                            m_currProcedure;
    bool                                    m_isInit;
    bool                                    m_bFromRequestHelper;

    std::string                             m_requestStr;
    std::map<FIELD_IDX_T, DbiInOutData*>    m_requestParamMap;
    std::vector<DbiColInfo>                 m_colInfoVector;
    std::vector<std::vector<DbiInOutData*>> m_requestOutputVector;
    size_t                                  m_currResultSet;
    std::vector<DbiBindData>                m_requestBindDataVector;

    std::set<DbiBatchOutput>                m_batchOutputSet;

    DbiSqlTrace                             m_sqlTrace;
};

class DbiOutboxManager: public AAAObject
{
public:
    DbiOutboxManager(DbiConnection &);
    virtual ~DbiOutboxManager();

    void     addRecord(DBA_DYNFLD_STP, DBA_ACTION_ENUM, OutboxEventModeEn);
    void     addRecord(DBA_DYNFLD_STP, DBA_PROC_STP);
    RET_CODE flush(bool);
    void     clean();
    int      getTotalInsertedNbr();
    void     resetTotalInsertedNbr();

protected:
    void     getBkInfo(std::string&, std::string&, DBA_DYNFLD_STP);

    DbiConnection&                                                                 m_dbiConn;
    std::map<OBJECT_ENUM, std::map<DBA_ACTION_ENUM, std::vector<DBA_DYNFLD_STP>>>  m_recordActionMap;
    int                                                                            m_totalInsertedNbr;

    MemoryPool                                                                     m_mp;
};

class DbiConnection : public  AAAConnection
{
    friend RequestHelper;

public:

    DbiConnection(const AAAConnectionSpecification& spec, const int& id);
    virtual ~DbiConnection();

    DbiConnection & operator= (const DbiConnection&) = delete;    /* PMSTA-24510 - 220816 - PMO */
    DbiConnection             (const DbiConnection&) = delete;    /* PMSTA-24510 - 220816 - PMO */

    enum class BatchMode
    {
        RowByRow,
        ExecuteOnce,
        TryAndRetryRowByRow,
        TryBCP
    };

    void clean();

    void         filterMsgInfos(RET_CODE * = nullptr, FLAG_T * = nullptr);
    void         sendAllMsg();
    void         sendAllMsgFromMA();
    void         dispAllMsgText();
    bool         emptyMsg();
    void         clearMsg();
    void         sendMsg(const char *, const int, const std::string &);
    void         setExternalMsgManagement(bool);
    bool         isExternalMsgManagement();
    bool         isAutoCommit();

    void         initRequest(DBA_ACTION_ENUM, bool);
    void         startRequest();

    virtual bool connect();
    virtual bool disconnect();

    virtual bool reconnect();
    virtual void release();

    virtual bool reopenOnThreadChange();

    virtual PTR  getConnectionPtr() = 0;
    virtual PTR  getCommandPtr() = 0;

    virtual RET_CODE createStatement(const std::string &, DBA_ACTION_ENUM action) = 0;

    void                     setOptimDataAlloc();
    void                     setBatchBlockSize(int);
    RET_CODE                 addBatch();
    RET_CODE                 executeBatch();

    void                     setDelimiter(std::string);
    std::string              getDelimiter();

    virtual RET_CODE         doAddBatch() = 0;
    virtual RET_CODE         doExecuteBatch() = 0;

    virtual int              getColumnCount() = 0;
    virtual RET_CODE         getColumnName(int, std::string &) = 0;
    virtual RET_CODE         getColumnType(int, CTYPE_ENUM &) = 0;
    virtual int              getPrecision(int) = 0;
    virtual int              getScale(int) = 0;
    virtual int              getColumnMaxLength(int) = 0;
    virtual int              getColumnDisplaySize(int) = 0;

    virtual bool             isBcpAllowed() = 0;

    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, ID_T valueId);
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, ENUM_T valueEn);
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, INT_T  valueInt);
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName);

    virtual void clearPassword() = 0;

    void incTransaction();
    void decTransaction(const FLAG_T status);
    bool isInTransaction();
    bool isAutoTransaction();

    static DBA_CONNECT_INFO_STP getConnectionInfo(const int& id);
    static DbiConnection*       getConnection(const int& id);

    RET_CODE                    endConnection(bool);

    DBA_RDBMS_ENUM getDbaRDBMS();

    DBA_CONNECT_INFO_STP getConnStructPtr(){ return &this->connectSt; }

    RET_CODE setApplSession(DBA_DYNFLD_STP applSessionStp);
    RET_CODE setAppContext(const std::string &propertyName, ID_T propertyValueId);
    RET_CODE setLanguageDictId(DICT_T propertyValueId);

    RET_CODE readObjectData(DBA_DYNST_ENUM, DBA_DYNFLD_STP, int *, DBA_DYNFLD_STP **);

    RET_CODE bindRequestOutput();

    void     setModifStat(int modifStat);

    DbiSqlTrace &getSqlTrace();
    void         sendSqlTrace();

    virtual void setDateTimeFormat(DATE_STYLE_ENUM) = 0;

    virtual void        manageError() = 0;

    virtual std::string getDefaultCharset() = 0;
    virtual std::string getConnectionCharset() = 0;
    virtual std::string getDatabaseName() /*PMSTA-55617 - 2024-04-05 - Suparna*/
    {
        return std::string();
    }

    virtual bool        isUtf16Allowed() = 0;

    void                    setCurrCharsetEn(CURRENTCHARSETCODE_ENUM);
    CURRENTCHARSETCODE_ENUM getCurrCharsetEn();

    void                    setDbCommCharsetEn(CURRENTCHARSETCODE_ENUM);
    CURRENTCHARSETCODE_ENUM getDbCommCharsetEn();

    virtual RET_CODE doStartRequest();

            RET_CODE beginTransaction(bool = false);
    virtual RET_CODE doBeginTransaction() = 0;

            RET_CODE endTransaction(const FLAG_T);
    virtual RET_CODE doEndTransaction(const FLAG_T) = 0;

    virtual RET_CODE getNextResultSet() = 0;

            RET_CODE sendCommand(const std::string &request = std::string(), DBA_DYNST_ENUM outputSt = NullDynSt);
    virtual RET_CODE doSendCommand(DBA_DYNST_ENUM outputSt) = 0;

    virtual RET_CODE sendRequest(DBI_INT *) = 0;

            RET_CODE releaseCommand();
    virtual RET_CODE doReleaseCommand() = 0;

    virtual bool     isDbTransactionRequired() = 0;
    virtual bool     isDdlGenOnTran() = 0;
    virtual RET_CODE prepareReceivedData() = 0;
    virtual RET_CODE bindRecvDynSt(DBA_DYNST_ENUM , DBA_DYNFLD_STP);
    virtual RET_CODE bindRecvDynFld(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData, INT_T  fldIdx, INT_T colIndex, short *nullFlgPtr);
    virtual RET_CODE bindRecvDynSqlEntity(OBJECT_ENUM , DBA_DYNST_ENUM , DBA_DYNFLD_STP );
    virtual RET_CODE colBind(int, DATATYPE_ENUM, const std::string &, DBI_PTR, size_t, DBI_INT *, DBI_SMALLINT *, bool dynFldFlag, unsigned char * nullIndicatorDynFld, DbiInOutData *) = 0;
    virtual RET_CODE fetch() = 0;
    virtual RET_CODE copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM) = 0;
    virtual RET_CODE processAllResults(DBI_INT       *status,
                                       OBJECT_ENUM    object    = NullEntityCst,
                                       DBA_DYNST_ENUM dynSt     = NullDynSt,
                                       DBA_DYNFLD_STP record    = NULLDYNST,
                                       DBA_PROC_STP   procedure = NULL) = 0;

    virtual RET_CODE sqlExecSt(const char *sqlBuff, DBI_INT* status = nullptr, bool bKeepCommand = false);

    bool isStatementInProgress();

    virtual RET_CODE cancelDbRequest(int, int) = 0;

    virtual bool             isReadOnly();
    void                     setReadOnly(bool);
    void                     setReadOnly(DBA_PROC_STP procStp);     /* PMSTA-29027 - LJE - 190111 */
    void                     resetReadOnly();

    virtual RET_CODE disableIdentity(std::string, std::string)
    {
        this->m_insertIdentityOn = true;
        return RET_SUCCEED;
    }
    virtual RET_CODE enableIdentity(std::string, std::string)
    {
        this->m_insertIdentityOn = false;
        return RET_SUCCEED;
    }

    /* Command RDBMS depends part */
    virtual std::string                      endOfCmd();


    virtual void                             enableOutput() = 0;
    virtual void                             disableOutput() = 0;
    virtual RET_CODE                         getLastCmdRetCode() = 0;
    virtual RET_CODE                         getCmdRetCode(int) = 0;

    virtual bool                             isSamePasswordMsg() = 0;
    virtual bool                             isWarningMsgToHide(const DbaErrmsgInfosClass &) = 0;

    bool                                     isTechMsg();
    bool                                     isDbAccessByRequestHelper();

    virtual RET_CODE                         convertToRetCode(int)=0;
    unsigned                                 getTimeOutMiliSec();                /* PMSTA-25090 - 191016 - PMO */
    void                                     setTimeOutMiliSec(const unsigned);  /* PMSTA-25090 - 191016 - PMO */

    bool                                     isMultiAccessLangRequest();         /* PMSTA-30586 - DLA - 180404 */
    void                                     setMultiAccessLangRequest(const bool);    /* PMSTA-30586 - DLA - 180404 */

    void                                     setFetchSize(int);
    int                                      getFetchSize();

    bool                                     isBatchMode();
    BatchMode                                getBatchMode();
    void                                     setBatchMode(BatchMode &);

    DdlGenFromFile                          *getScriptDdlGenPtr();

    DBA_ACTION_ENUM                          getCurrentAction();
    void                                     setCurrentAction(DBA_ACTION_ENUM);
    DBA_PROC_STP                             getCurrProcedure();
    void                                     setCurrProcedure(DBA_PROC_STP);

    virtual void                             setDefaultReadOnly(DBA_PROC_STP, RequestHelper*)
    {
        return;
    }

    void                                     setGUIBehavior(bool);
    bool                                     isGUIBehavior();

    SubscriptionModuleEn                     getSubscriptionModuleEn();

    void                                     setDdlGenDbaAccessPtr(DdlGenDbaAccess *);
    DdlGenDbaAccess                         *getDdlGenDbaAccessPtr();
    void                                     setConnectionStatus(bool status);

    DBA_RDBMS_ENUM                           m_connectToRDBMS;

    DBI_INT                                  m_lastResultType;
    RET_CODE                                 m_lastResultRetCode;
    signed char                              m_transactCpt;

    bool                                     m_bSettingsForDdl;        /* PMSTA-18593 - LJE - 150518 */
    DICT_T                                   m_parentDictEntity;       /* PMSTA-46681 - LJE - 211227 */

    DbaMsgStackClass                         m_msgStack;
    DbaErrmsgHeaderClass                     m_msgStructHeaderSt;

    short *                                  m_bindNullFlags;
    DBI_INT *                                m_bindFieldLength;
    DBI_SMALLINT *                           m_bindFlags;
    DBA_DYNST_ENUM                           m_bindDynStEn;
    unsigned int                             m_bindColNbr;
    DBA_DYNFLD_STP                           m_bindDynStp;

    bool                                     m_insertIdentityOn;
    bool                                     m_oneRecordExpected;
    bool                                     m_bOnBatchOutput;

    std::vector<DBA_WORK_ON_CLOSE_CONNECTION_ST> m_workOnCloseConnectionVector;

    std::map<FIELD_IDX_T, DbiInOutData*>    &getRequestParamMap();
    std::vector<DbiColInfo>                 &getColInfoVector();
    DbiSqlRequest                           &getSqlRequest();
    std::string                             m_sqlTraceHideEnd;

    std::string                              m_errorConstraint;         /* PMSTA-48744 - LJE - 220413 */
    virtual void                             initMessageBehavior();
    void                                     addMessage(const std::string &);
    virtual void                             getPrintAndClearMessages(std::ostream &);
    virtual void                             closeMessageBehavior();
    std::string                              m_dbNameOption;

    virtual DATATYPE_ENUM                    getDatatypeFromDesc(CTYPE_ENUM cType, int& dataSize, int precision, int scale);

    std::string                              getNextAction();

    DbiOutboxManager                        &getOutboxManager();

protected:

    std::vector<std::string>                &getActionVector();

    std::vector<std::string>                &getMessageVector();

    virtual bool                             doConnect() = 0;
    virtual bool                             doDisconnect() = 0;

    virtual bool                             useDb(const std::string&);

    std::string                             &getRequest();
    std::string                              getRequestToSend();
    void                                     clearColInfoVector();
    virtual bool                             convParamFromPos(std::string&, std::string::size_type&, int, const std::string&) = 0;
    void                                     clearRequestParamMap();
    std::vector<DbiInOutData*>              &getRequestOutputVector();
    void                                     clearRequestOutputVector();
    std::vector<DbiBindData>                &getRequestBindDataVector();
    void                                     clearRequestBindDataVector();

    virtual void                             pushSqlRequest(KindOfRequest);
    virtual void                             popSqlRequest(KindOfRequest = KindOfRequest::Default);

    int                                      m_resultSetPos;

    DdlGenContext                           *m_ddlGenContextPtr;
    DdlGenFromFile                          *m_scriptDdlGenPtr;

    CURRENTCHARSETCODE_ENUM                  m_currCharSetEn;
    CURRENTCHARSETCODE_ENUM                  m_dbCommCharSetEn;

    int                                      m_activitiesSinceLastCommit;

    int                                      m_fetchSize;

    bool                                     m_bOptimDataAlloc;
    int                                      m_batchBlockSize;
    int                                      m_batchSize;
    std::string                              m_batchTableSqlName;
    BatchMode                                m_batchMode;

    DdlGenDbaAccess                         *m_ddlGenDbaAccessPtr;
    DbiOutboxManager                        *m_outboxManagerPtr;

    std::vector<std::string>                 m_messageVector;

    std::set<std::pair<std::string, std::string>> m_disableIdentitySet;

    std::vector<std::string>                 m_actionVector;
    unsigned                                 m_TimeOutMiliSec;       /* The timeout in millisecond PMSTA-25090 - 191016 - PMO */
    DBA_CONNECT_INFO_ST                      connectSt;

    std::vector<DbiSqlRequest>               m_sqlRequestVector;

    bool                                     m_isMultiAccessLangRequest;
    bool                                     m_bCurrentRequestOutputBinded;
    bool                                     m_bExternalMsgManagement;

    bool                                     m_isGUIBehavior;

    bool                                     m_beginTransToDo;
    bool                                     m_isAutoTransaction;
    bool                                     m_transactionInProgress;
    bool                                     m_isDBConnectRetryRequired;

    std::string                              m_delimiter;

private:
    bool              m_bReadOnly;
    bool              m_bDefaultReadOnly;           /* PMSTA-29027 - LJE - 190111 */

};

class DbiConnectionHelper
{
    friend DbaCallGuard;

public:
    DbiConnectionHelper(AAATransactionEnum useTran = AAATransactionEnum::NotTransactionnal, const DBA_SERVER_TYPE_ENUM server = DBA_SERVER_TYPE_ENUM::SqlServer, const AAAConnectionRole role = ROLE_USER);     /* DLA - PMSTA-29886 - 180126 */
    DbiConnectionHelper(const DBA_SERVER_TYPE_ENUM &);
    DbiConnectionHelper(DbiConnection* dbiConn, bool releaseConnectionOnDeleteObject = false);
    DbiConnectionHelper(const std::string & serverName, const AAAConnectionKind & = AAAConnectionKind::StandardConnection);                         /* PMSTA-26427 - 240217 - PMO */
    DbiConnectionHelper(int *connectNoPtr);                                                                                                         /* PMSTA-nuodb - LJE - 190607 */

    virtual ~DbiConnectionHelper();

    DbiConnectionHelper(const DbiConnectionHelper&) = delete;
    DbiConnectionHelper & operator= (const DbiConnectionHelper&) = delete;

    DbiConnection*       getConnection();
    void                 setOnError(bool isInError = false);
    void                 reopen();                                       /* PMSTA-22990 - 080416 - PMO */
    bool                 reopenHttpOnThreadChange();                     /* PMSTA-24510 - 220816 - PMO */
    bool                 reopenHttpOnThreadChangeForOnlineBatch();       /* DLA - PMSTA-29743 - 180214 */
    void                 setConnectionKind(const AAAConnectionKind &);   /* PMSTA-26427 - 240217 - PMO */
    bool                 isValidAndInit();
    bool                 isConnected();
    bool                 isInTransaction();                              /* PMSTA-22990 - 080416 - PMO */
    RET_CODE             beginTransaction();                             /* PMSTA-22990 - 080416 - PMO */
    RET_CODE             endTransaction(const FLAG_T commitFlag);        /* PMSTA-23385 - LJE - 160630 */
    RET_CODE             commit();
    RET_CODE             rollback();
    void                 updateServerPoolCfg(const std::string&);        /* PMSTA-39659 - ankita - 05082020 */
    bool                 setCurrBusinessEntity(const std::string &);

    void                 sendAllMsg();
    void                 sendAllMsgFromMA();
    bool                 emptyMsg();
    void                 clearMsg();
    DbaErrmsgInfosClass *getNewErrMsgInfoStp(const char *file, int line);
    void                 setExternalMsgManagement(bool);
    bool                 isExternalMsgManagement();

    int &                       getId();                            /* PMSTA-22990 - 080416 - PMO */
    AAAConnectionDescription   &getDescription();                   /* PMSTA-25644 - 141216 - PMO */
    void                        reloadDescription();                /* PMSTA-25644 - 141216 - PMO */

    void            setSilentMode(bool bSilentMode);                /* PMSTA-24563 - LJE - 160907 */
    bool            getSilentMode();                                /* PMSTA-45390 - JBC - 210607 */

    bool             isDbaAccess(DBA_ACTION_ENUM);
    DdlGenDbaAccess *getDdlGenDbaAccessPtr(DBA_ACTION_ENUM);

    RET_CODE        dbaInsert(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNFLD_STP inputData);

    RET_CODE        dbaUpdate(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNFLD_STP inputData);

    RET_CODE        dbaDelete(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNFLD_STP inputData);

    RET_CODE        dbaInsUpd(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNFLD_STP inputData);

    RET_CODE        dbaSelect(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNFLD_STP inputData,
                              DBA_DYNST_ENUM outputDynStEnum,
                              DBA_DYNFLD_STP **outputData,
                              int            *resultRows);

    RET_CODE        dbaMultiSelect(OBJECT_ENUM          object,
                                   int                  role,
                                   DBA_DYNFLD_STP       inputData,
                                   const DBA_DYNST_ENUM **outputStLstPtr,
                                   DBA_DYNFLD_STP       **outputDataLst,
                                   int                  *resultRows);

    /* PMSTA-nuodb - LJE - 190807 */
    RET_CODE        dbaMultiSelect(OBJECT_ENUM          object,
                                   int                  role,
                                   DBA_DYNFLD_STP       inputData,
                                   DBA_DYNFLD_STP       **outputDataLst,
                                   int                  *resultRows);

    RET_CODE        dbaGet(OBJECT_ENUM       object,
                           int            role,
                           DBA_DYNFLD_STP  inputData,
                           DBA_DYNFLD_STP  *outputData,
                           DBA_PROC_STP   procedure = nullptr);  /* PMSTA-34344 - TEB - 190319 */

    RET_CODE        dbaNotif(OBJECT_ENUM     object,
                             int            role,
                             DBA_DYNFLD_STP  inputData);

    void            setNotifRetry (const int  retry);
    void            setNotifReopen(const bool reopen);

    RET_CODE        dbaCheck(OBJECT_ENUM     object,
                             int            role,
                             DBA_DYNFLD_STP  inputData);

    RET_CODE        dbaInsertByBlock(OBJECT_ENUM          object,
                                     int                  role,
                                     DBA_DYNFLD_STP       *inputDataTab,
                                     int                  inputRecNbr,
                                     int                  maxRecInBuf);

    RET_CODE        dbaCopy(OBJECT_ENUM       object,
                            int            role,
                            DBA_DYNFLD_STP  inputData);

    void                    setCurrProcedure(DBA_PROC_STP);
    DBA_PROC_STP            getCurrProcedure();

    DBA_ERRMSG_HEADER_STP   dbaGetMsgStructHeader();
    int                     dbaGetOptions();
    void                    dbaSetOptions(int options);
    int                     dbaGetSelectMaxRows();
    void                    dbaSetSelectMaxRows(int maRows);
    bool                    dbaCreateTempTables(const int tmpTablesMask);   /* PMSTA-26258 - 080217 - PMO */
    RET_CODE                execSqlExecByBloc(DbiSqlExecByBlock & sqlExec); /* PMSTA-26258 - 080217 - PMO */
    RET_CODE                dbaSqlExec(const std::string & sqlCmd);         /* PMSTA-29159 - 111217 - PMO */

    ID_T                    getConnectedBusinessEntityId();                 /* PMSTA-26108 - LJE - 171121 */
    bool                    isConnBusEntityEqualTo(const std::string & );         /* PMSTA-39974 - JBC - 290420 */
    bool                    isConnBusEntityIdEqualTo(const ID_T);         /* PMSTA-39974 - JBC - 290420 */

    virtual RET_CODE        httpReceiveFile(const std::string & outputFileName, const std::string & rpcName, const std::string & request);   /* PMSTA-32235 - 160519 - PMO */
    bool                    isHttp();
    bool                    isBlockMode();
    void                    setGUIBehavior();
    bool                    isGUIBehavior();

    void                    setFromDbaAccess();
    void                    resetFromDbaAccess();

protected:

    void                        setDbiConnection();                 /* PMSTA-19735 - 020415 - PMO */
    void                        endConnection();

    DbiConnection *             m_dbiConn;
    bool                        m_usetran;          /* DLA - PMSTA-29886 - 180126 */
    bool                        m_uselocaltran;     /* PMSTA-24563 - LJE - 160908 */
    bool                        m_releaseConnection;
    int                         m_options;
    int                         m_maxRows;
    int                         m_connNotFound;
    AAAConnectionDescription    m_desc;
    AAAConnectionKind           m_connectionKind;   /* Dispatcher keep one global connection for each fusion server / PMSTA-26427 - 240217 - PMO */
    bool                        m_bSilentMode;
    bool                        m_notifyReopen;     /* In case of notify error, Close and reopen the connection / PMSTA-25644 - 141216 - PMO */
    int                         m_notifyRetry;      /* # of retry in case of notify error                       / PMSTA-25644 - 141216 - PMO */
    bool                        m_previousExternalMsgManagement;
    bool                        m_isGUIBehavior;

    DBA_PROC_STP                m_currProcedureStp;

    bool                        m_fromDbaAccess;
};

class RequestHelper : public AAAObject
{
public:
    RequestHelper(DbiConnection *, bool = false);
    RequestHelper(DbiConnectionHelper &);
    RequestHelper(RequestHelper*, const std::vector< DBA_DYNFLD_STP>&);

    RequestHelper(const RequestHelper&) = delete;

    virtual ~RequestHelper();

    enum class TransactionMode
    {
        AllOrNothing,
        MostAsPossible,
        External
    };

    class CopyInfo
    {
    public:
        CopyInfo(DBA_DYNFLD_STP targetDynStp,
                 FIELD_IDX_T    targetFldIdx,
                 DBA_DYNFLD_STP srcDynStp,
                 FIELD_IDX_T    srcFldIdx
        )
            : m_targetDynStp(targetDynStp)
            , m_targetFldIdx(targetFldIdx)
            , m_srcDynStp(srcDynStp)
            , m_srcFldIdx(srcFldIdx)
        {
        };

        CopyInfo(const CopyInfo& ref)
            : m_targetDynStp(ref.m_targetDynStp)
            , m_targetFldIdx(ref.m_targetFldIdx)
            , m_srcDynStp(ref.m_srcDynStp)
            , m_srcFldIdx(ref.m_srcFldIdx)
        {
        };

        CopyInfo& operator=(const CopyInfo&) = delete;

        DBA_DYNFLD_STP m_srcDynStp;
        FIELD_IDX_T    m_srcFldIdx;
        DBA_DYNFLD_STP m_targetDynStp;
        FIELD_IDX_T    m_targetFldIdx;
    };

    void            init();
    void            setReadOnly(bool bReadOnly);
    void            setDdlGen();
    void            setFetchSize(int);
    bool            startProcedureCall(DBA_PROC_STP procedureStp, DBA_DYNFLD_STP inputDataStp);
    void            finishRequest();
    void            setCommand(const std::string &sqlCmd);

    bool            isConnection(DbiConnection *);
    DbiConnection&  getDbiConn();

    RET_CODE        sendAndGetCommand();
    RET_CODE        sendCommandForFetch();
    RET_CODE        fetch();
    RET_CODE        getNextResultSet();

    bool            startProcedureCallForBatch(DBA_PROC_STP procedureStp);
    bool            startProcedureCallForBatch(DBA_ACTION_ENUM action,
                                               OBJECT_ENUM     object,
                                               int             role,
                                               DBA_DYNFLD_STP  inputData);
    bool            addProcedureCallForBatchMulti(DBA_ACTION_ENUM action,
                                                  OBJECT_ENUM     object,
                                                  int             role,
                                                  DBA_DYNFLD_STP  inputData,
                                                  size_t          batchRank = MAX_SHORT);
    virtual void    setCopyIdForBatchMulti(size_t, DBA_DYNFLD_STP, FIELD_IDX_T, DBA_DYNFLD_STP, FIELD_IDX_T);
    virtual void    setCopyIdForBatchMulti(ID_T *, DBA_DYNFLD_STP, FIELD_IDX_T, size_t = MAX_SHORT);

    void                      setBatchMode(DbiConnection::BatchMode);
    DbiConnection::BatchMode  getBatchMode();
    void                      setTransactionMode(TransactionMode);
    TransactionMode           getTransactionMode(void);

    RET_CODE        prepareStatementForBatch();
    void            resetBatchBlockSize();
    void            setBatchBlockSize(unsigned int);
    unsigned int    getBatchBlockSize();

    static unsigned int    getDefBatchBlockSize(DBA_RDBMS_ENUM);

    unsigned int    getBatchSize();
    void            setBatchInfo(const std::string &, const std::string &, OBJECT_ENUM);
    void            setBatchASync();
    void            setParallel(unsigned);
    unsigned        getParallel();
    RET_CODE        getNewRecordForBatch(DBA_DYNST_ENUM, DBA_DYNFLD_STP &);
    DBA_DYNFLD_STP  getNewRecordForBatch(DBA_DYNST_ENUM);
    RET_CODE        setNewRecordForBatch(DBA_DYNFLD_STP);
    void            removeLastRecordForBatch();
    void            setTargetTable(TARGET_TABLE_ENUM targetTableEn);
    RET_CODE        flushBatch(bool bForceFlush, DdlGenMsg* = nullptr);
    RET_CODE        realFlushBatch(bool, bool = false);
    RET_CODE        executeBatch(DdlGenMsg* = nullptr);
    RET_CODE        executeBatchMulti(bool bRowByRow = false);
    void            setApplyDVBatchMulti()
    {
        this->m_bApplyDV = true;
    }
    void            setApplyICBatchMulti()
    {
        this->m_bApplyIC = true;
    }
    void            setFlushStatBatchMulti()
    {
        this->m_bFlushStat = true;
    }
    RET_CODE        computeDV(DBA_DYNFLD_STP);
    RET_CODE        computeIC(DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP> &);

    void            updateOutputValue();

    int             getColumnCount();
    RET_CODE        getColumnName(int, std::string &);
    RET_CODE        getColumnType(int, CTYPE_ENUM &);
    int             getPrecision(int);
    int             getScale(int);
    int             getColumnMaxLength(int);
    int             getColumnDisplaySize(int);

    void            setExternalMsgManagement(bool);
    bool            isExternalMsgManagement();
    void            printMsg();
    void            clearMsg();                         /* PMSTA-53403 - LJE - 230622 */

    void            addNewResultSet();

    DbiInOutData   *addNewParam(DATATYPE_ENUM dataType);                   /* NULL parameter */
    DbiInOutData   *addNewParam(const DBA_DYNFLD_STP dynFldStp, bool);           /* DynFldSt parameter */

    DbiInOutData   *addNewParamString(const std::string &newParamStr, DATATYPE_ENUM dataType);     /* std::string */
    DbiInOutData   *addNewParamCharPtr(const char *newParamStr, DATATYPE_ENUM dataType);           /* CharPtrCType */
    DbiInOutData   *addNewParamCharPtr(const std::string &newParamStr, DATATYPE_ENUM dataType);    /* CharPtrCType */
    DbiInOutData   *addNewParamUCharPtr(const UChar *newParamStr, DATATYPE_ENUM dataType);         /* UniCharPtrCType */
    DbiInOutData   *addNewParamUChar(UCHAR_T newParamUc);                                          /* UCharCType */
    DbiInOutData   *addNewParamInt(INT_T newParamInt);                                             /* IntCType */
    DbiInOutData   *addNewParamShort(SMALLINT_T newParamShort);                                    /* ShortCType */
    DbiInOutData   *addNewParamUShort(YEAR_T newParamUShort);                                      /* UShortCType */
    DbiInOutData   *addNewParamLongLong(INT64_T newParamId);                                       /* LongLongCType */
    DbiInOutData   *addNewParamId(ID_T newParamId, DATATYPE_ENUM dataType = IdType);               /* LongLongCType for id */
    DbiInOutData   *addNewParamDouble(NUMBER_T newParamDbl, DATATYPE_ENUM dataType);               /* DoubleCType */
    DbiInOutData   *addNewParamDatetime(const DATETIME_T &newParamDateTime);                       /* DateTimeStCType */
    DbiInOutData   *addNewParamDatetime(const DATETIME64_ST &newParamDateTime);                    /* DateTimeStCType */
    DbiInOutData   *addNewParamUInt(TIME_T newParamUInt);                                          /* UIntCType */
    DbiInOutData   *addNewParamTimeStamp(TIMESTAMP_T);                                             /* TimeStampCType */
    DbiInOutData   *addNewParamBinary(UINT64_T);                                                   /* BinaryCType */
    DbiInOutData   *addNewParamDynStp(DBA_DYNFLD_STP);                                             /* ExtensionCType */

    DbiInOutData   *addNewOutputData(DATATYPE_ENUM dataType, const char * = nullptr);

    void            getBindVariablePtr(DBA_DYNFLDDATA_UN*  &dynFldDataValue);

    bool           isNullValue(int colNum);
    const char    *getCharPtrValue(int colNum);
    const UChar   *getUCharPtrValue(int colNum);
    INT64_T        getLongLongValue(int colNum);
    double         getDoubleValue(int colNum);
    int            getIntValue(int colNum);
    unsigned int   getUIntValue(int colNum);
    short          getShortValue(int colNum);
    unsigned short getUShortValue(int colNum);
    unsigned char  getUCharValue(int colNum);
    BINARY_T       getBinaryValue(int colNum);
    DATETIME_ST    getDateTimeValue(int colNum);
    DATE_ST        getDateValue(int colNum);

    void          setDefDynSt(DBA_ENTITY_NAT_ENUM, const std::string &, const std::string &, const std::vector<DbiColInfo> &);
    void          setDynFldStpParam(DBA_DYNFLD_STP dynFldStp, TARGET_TABLE_ENUM targetTableEn, bool bOnlyPhisical = false);
    void          setOneDynFldParam(DBA_DYNFLD_STP dynFldStp, 
                                    FIELD_IDX_T fieldIdx, 
                                    FIELD_IDX_T colPos,
                                    DATATYPE_ENUM dataTypeEn, 
                                    bool bInputParam,
                                    bool bOutputParam, 
                                    bool bOutputOnlyParam,
                                    const char *sqlName,
                                    FIELD_IDX_T *indexedFieldIdxPtr,
                                    bool setDefaultFld);
    void          setDynStOutputData(DBA_DYNST_ENUM dynStEn, TARGET_TABLE_ENUM targetTableEn = TargetTable_Undefined, bool bOnlyPhisical = false);
    RET_CODE      readAllRecord(int *rowsNbr, DBA_DYNFLD_STP **outputData);
    RET_CODE      readOneRecord(DBA_DYNFLD_STP dynFldStp);
    RET_CODE      readData(DBA_DYNFLD_STP dynFldStp);

    void          optimDataAlloc();
    void          useNativeQueryForBatch();
    void          useProcQueryForBatch();

    bool          isSubscription(DBA_PROC_STP, DBA_DYNFLD_STP);
    RET_CODE      manageSubscription(DBA_DYNFLD_STP);

    DdlGenFromFile *getScriptDdlGenPtr();

    void            setDbNameOption(const std::string&);

    template<typename T> void getBindVariablePtr(T* &valuePtr)
    {
        valuePtr = static_cast<T*>(this->m_dbiConn->getRequestOutputVector().back()->m_valuePtr);
    }

    template<typename T> void getBindVariablePtr(T* &valuePtr, DBI_SMALLINT *&nullFld)
    {
        valuePtr = static_cast<T*>(this->m_dbiConn->getRequestOutputVector().back()->m_valuePtr);
        nullFld = &this->m_dbiConn->getRequestOutputVector().back()->m_nullInd;
    }

    void useDb(const std::string &dbSqlName);

    void setLastRetCode(RET_CODE retCode)
    {
        this->m_lastRetCode = retCode;
    }

    class ASyncBatchInfo: public ThreadArg
    {
    public:

        ASyncBatchInfo(RequestHelper*, bool);
        virtual ~ASyncBatchInfo();

        RequestHelper *m_requestHelperPtr;
        bool           m_bForceFlush;
        RET_CODE       m_retCode;
    };

    class ParallelBatchInfo: public ThreadArg
    {
    public:

        ParallelBatchInfo(RequestHelper*, bool, const std::vector<DBA_DYNFLD_STP>&, DdlGenMsg*);
        virtual ~ParallelBatchInfo();

        MemoryPool                    m_mp;
        RequestHelper*                m_requestHelperPtr;
        DdlGenMsg*                    m_ddlGenMsgPtr;
        std::vector< DBA_DYNFLD_STP>  m_recordsForBatch;
        bool                          m_bForceFlush;
        RET_CODE                      m_retCode;
        std::chrono::duration<double> m_writeDuration;
    };


    int                          getLastStatus();
    int                          getLastResultType();
    RET_CODE                     getLastResultRetCode();
    RET_CODE                     getLastRetCode();
    DBA_ERRMSG_HEADER_ST        &getMsgStructHeader();

    void                         trfRecordForBatch(RequestHelper&);
    void                         getParallelRecords(RequestHelper*);
    void                         printErrorOnFile(const std::string &, int, DdlGenMsg&);

    bool                         m_useAlternativeDataServer;

    /* PMSTA-46508 - LJE - 211012 - Error management */
    std::vector<std::string>     m_onErrorRequests;
    std::vector<std::string>     m_errorConstraints;

protected:
    DbiConnection*               m_dbiConn;

private:
    RequestHelper();

    void                         free();
    void                         clearOutputData();
    void                         clearParamData();
    DbiInOutData                *getNewParam(DATATYPE_ENUM dataType, DbiInOutData *dynFldStp = nullptr);
    void                         addNewParam(DbiInOutData *newParamStp);
    void                         clearRecordForBatch(bool);
    void                         getRealRequest(std::string &);

    bool                         m_bKeepConnectProps;
    DbiConnectionHelper          m_localConnectionHelper;

    MemoryPool                   m_requestMp;
    MemoryPool                   m_globalMp;

    std::vector< DBA_DYNFLD_STP> m_recordsForBatch;
    std::vector< DBA_DYNFLD_STP> m_recordsForBatchInQueue;
    unsigned int                 m_batchPos;
    unsigned int                 m_batchBlock;
    bool                         m_bApplyDV;
    bool                         m_bApplyIC;
    bool                         m_bFlushStat;


    DBA_DYNFLD_STP              *m_outSubscriptionTab;
    int                          m_outSubscriptionNbr;
    DBA_DYNFLD_STP               m_oldRecordStp;

    class DefValHandler
    {
    public:
        DefValHandler()
            : dfltValStPtr(nullptr)
            , flags(nullptr)
            , m_bInit(false)
        {
        }

        virtual ~DefValHandler();

        SCPT_DFLTVAL_STP  dfltValStPtr;
        FLAG_T           *flags;

        bool              m_bInit;
        MemoryPool        m_mp;
    };

    class ICHandler
    {
    public:
        ICHandler()
            : icStPtr(nullptr)
            , m_bInit(false)
        {
        }

        virtual ~ICHandler();

        SCPT_ARG_STP      icStPtr;

        bool              m_bInit;
        MemoryPool        m_mp;
    };

    std::map<OBJECT_ENUM, DefValHandler>  m_scptDfltValMap;
    std::map<OBJECT_ENUM, ICHandler>      m_scptICMap;

    std::map<size_t, std::map<DBA_PROC_STP, std::vector<DBA_DYNFLD_STP>>> m_batchRecordMultiMap;
    std::map<size_t, std::vector<RequestHelper::CopyInfo>>                m_batchToCopyMap;
    std::map<size_t, std::map<DBA_DYNFLD_STP, ID_T*>>                     m_batchToCopyIdMap;

    DBI_INT                      m_lastStatus;
    RET_CODE                     m_lastRetCode;
    bool                         m_bSendDone;
    bool                         m_bFetchStarted;
    bool                         m_bFetchDone;
    bool                         m_bMsgPrinted;

    bool                         m_bReadOnly;
    bool                         m_bDdlGen;

    int                          m_fetchSize;

    DBA_PROC_STP                 m_procedureStp;
    TARGET_TABLE_ENUM            m_targetTableEn;
    bool                         m_bInsertMain;
    bool                         m_bInsertUd;

    DBA_ENTITY_NAT_ENUM          m_entityNatEn;
    std::string                  m_targetDbName;
    std::string                  m_tableSqlName;
    std::vector<DbiColInfo>      m_colInfoVector;

    DBA_DYNST_ENUM               m_paramDynStEn;
    DBA_DYNFLD_STP               m_paramDataStp;
    int                          m_paramPos;

    DBA_DYNST_ENUM               m_outputDynStEn;
    DBA_DYNFLD_STP               m_defOutDataStp;

    std::string                  m_previousDbSqlName;
    DBA_ACTION_ENUM              m_previousAction;
    bool                         m_previousExternalMsgManagement;
    DbaErrmsgHeaderClass         m_previousMsgStructHeaderSt;
    std::string                  m_previousDbNameOption;

    bool                         m_managemInsertIdentity;

    OBJECT_ENUM                  m_batchObjEn;

    DbiConnection::BatchMode     m_batchMode;
    TransactionMode              m_transactionMode;
    bool                         m_bOverFlow;
    bool                         m_bBatchASync;
    unsigned                     m_parallel;
    unsigned                     m_threadNb;
    ThreadPool                  *m_batchThreadPoolPtr;
    RET_CODE                     m_batchRetCode;

    bool                         m_bOptimDataAlloc;
    bool                         m_bUseNativeQuery;
    bool                         m_bSubRequestHelper;


    /* PMSTA-46508 - LJE - 211029 */
    CURRENTCHARSETCODE_ENUM      m_currCharSet;
    UChar                       *m_currUChar;
    char                        *m_currChar;
    int                          m_currUCharSize;

    std::vector<DBA_DYNFLD_STP>                            m_availableRecordsVector;
    std::map<int,std::vector<DbiInOutData*>>               m_availableDbiInOutDataMap;

    std::vector<std::vector<DbiInOutData*>>                m_parallelDbiInOutDataVector;

    std::vector<DbiInOutData*>                             m_allDbiInOutDataVector;

    Lock                                                   m_lock;

    std::vector<std::string>                               m_onReleaseCommands;
};

class DbaCallGuard
{
public:
    DbaCallGuard(DbiConnectionHelper &);
    virtual ~DbaCallGuard();

private:
    DbiConnectionHelper &m_dbiConnectionHelper;

    bool           m_fromDbaAccess;
};

/* PMSTA-46681 - LJE - 230911 */
class DbaTransactionGuard
{
public:
    DbaTransactionGuard(DbiConnection&, RET_CODE &);
    virtual ~DbaTransactionGuard();

    RET_CODE beginTransaction();
    void     setModifStat(int);

private:
    DbiConnection &m_dbiConnection;
    RET_CODE      &m_retCode;

    bool           m_isInTransaction;
    int            m_modifStat;
};



#endif

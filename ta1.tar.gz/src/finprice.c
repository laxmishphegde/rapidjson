/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINPRICE_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scpt.h"
#include "scptyl.h"
#include "scelib.h"

#include <algorithm>
#include <numeric>
#include <map>
using namespace std;

/************************************************************************
**      External entry points
**
**
**  FIN_ForwardPrice() 		    Compute forward price.
**  FIN_InstrOrUnderlyLife()    Compute instrument life (period between settl. and maturity date).
**  FIN_InstrPrice() 		    Compute instrument price.
**  FIN_PosPrice() 		        Compute position price at received reference date depending.
**  FIN_PriceToQuote() 		    Determine quote depending on price, instr. info and received rule.
**  FIN_QuoteToPrice() 		    Determine price depending on quote, instr. info and received rule.
**  FIN_RatePrice() 		    Search price at reference date for rate in received currency.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**  FIN_DefaultInstrPrice() 	Search the best price using definiton from appl_param.
**  FIN_DiscountedInstrPrice() 	Compute a discounted instrument price.
**  FIN_ForexSwapPrice() 	    Compute forex swap price.
**  FIN_InstrComposite()	    Compute instrument value with its component values.
**  FIN_InstrLending() 		    Compute instrument price.
**  FIN_InstrRefInstrPrice() 	Evaluate a instrument depending on a reference instrument.
**  FIN_InstrTheoPrice() 	    Evaluate instrument via theoritical price.
**  FIN_IsInstrPriceValid()	    Check if instrument price is valid for a valuation rule
**  FIN_SelectInstrPrice() 	    Select all instr price for a instrument.
**  FIN_GetPtfInstrPrice()      Get all portfolio instr price for a fund share instrument
**  FIN_SetInstrPrice() 	    Set all value in structure instr price using val_rule.
*************************************************************************/


#ifndef min	     /* REF3722 - SSO - 000301 */
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#endif


/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE	FIN_DiscountedInstrPrice(	DBA_DYNFLD_STP,
											DBA_DYNFLD_STP,
											DATETIME_T,
											DBA_DYNFLD_STP,
											DBA_HIER_HEAD_STP),

				/* FIN_ForexSwapTheoPrice(			DBA_DYNFLD_STP,
											DATETIME_T,
											DBA_DYNFLD_STP,
											DBA_DYNFLD_STP,
											DBA_HIER_HEAD_STP), */

				FIN_InstrComposite(			DBA_DYNFLD_STP,
											DATETIME_T,
											DBA_DYNFLD_STP,
											DBA_HIER_HEAD_STP,
											DBA_DYNFLD_STP),

				FIN_InstrLending(			DATETIME_T,
											ID_T, DBA_DYNFLD_STP,
											ENUM_T,
											DBA_DYNFLD_STP,
											DBA_HIER_HEAD_STP,
											DBA_DYNFLD_STP),

				FIN_InstrRefInstrPrice(		DBA_DYNFLD_STP,
											DBA_DYNFLD_STP,
											DATETIME_T,
											DBA_DYNFLD_STP,
DBA_HIER_HEAD_STP),

FIN_InstrTheoPrice(DBA_DYNFLD_STP,
DATETIME_T,
FIN_PRICEARG_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_HIER_HEAD_STP),

FIN_IsInstrPriceValid(DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
FLAG_T), /* PMSTA-10049 - LJE - 101007 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

FIN_SelectInstrPrice(ID_T,
DATETIME_T,
FLAG_T, /* PMSTA06487 - RAK - 080529 */
DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP**,
int*,
FLAG_T*),

FIN_SetInstrPrice(DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DATETIME_T,
DBA_DYNFLD_STP,
VALRULE_ENUM,
FIN_PRICEARG_STP,
DBA_DYNFLD_STP,
DBA_HIER_HEAD_STP),

FIN_GetPtfInstrPrice(ID_T,
ID_T,
DATETIME_T,
DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP*,
int*,
FLAG_T*),         /* PMSTA-32157 - SILPA - 180905*/

FIN_InstrTheoricPrice(DBA_HIER_HEAD_STP,
DATETIME_T,
DBA_DYNFLD_STP,
ID_T,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP),

FIN_InitInstrPrice(DATETIME_T,
ID_T,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP),

FIN_InstrTheoricPriceLeg(SCPT_ARG_STP,
DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
OBJECT_ENUM,
DBA_DYNFLD_STP),

FIN_InstrTheoricPriceSwap(DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
INSTRNAT_ENUM,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP),

FIN_InstrTheoricPriceOthers(DBA_HIER_HEAD_STP,
DATETIME_T, /* REF10531 - TEB - 040806 */
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP),

FIN_InstrTheoricBuildScript(DBA_DYNFLD_STP,
SCPT_ARG_STP *,
OBJECT_ENUM *),

FIN_ComputeQuote(DBA_HIER_HEAD_STP,
DATETIME_T,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP),

/* REF4478 - CHU - 000323 */
FIN_InstrLinearPrice(DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DATETIME_T),
FIN_InstrPriceClassify(OBJECT_ENUM,
DBA_DYNFLD_STP,
ID_T,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_HIER_HEAD_STP,
ID_T*,
DATETIME_T,
DBA_DYNFLD_STP),

FIN_PosPriceAllocOrder(DATETIME_T,
DBA_DYNFLD_STP,
DBA_DYNFLD_STP,
DBA_HIER_HEAD_STP,
DBA_DYNFLD_STP);

STATIC int  FIN_FilterAllocOrder(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
FIN_CmpESEInstrId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
FIN_FilterPtfInstrQuoteDate(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),    /* PMSTA-54407- Savitha - 30082023*/
FIN_CmpPtfInstrQuoteDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);   /* PMSTA-32157 - SILPA - 180905*/


/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    :   FIN_DefaultInstrPrice()
**
**  Description :   Search the best price using definiton from appl_param
**
**  Arguments   :   instrPtr      instrument price structure pointer
**                  refDatetime   Valuation date
**                  inputInstrPriceArg argument used ehwn calling from INSTR_PRICE()
**                  extPosPtr	  extended position structure pointer
**                  hierHead      hierarchy (ExtPos hierarchy only)
**                  pricePtr	  iinstrument price structure pointer
**
**  Return      :   instrument price stored in pricePtr argument
**
**  Modif       :   DVP344 - XDI - 970217
**  Modif       :   DVP440 - RAK - 970428
**  Modif		:   PMSTA-32157 - SILPA - 180905
**
*************************************************************************/
RET_CODE FIN_DefaultInstrPrice(DBA_DYNFLD_STP    instrPtr,
	DATETIME_T        refDateTime,
	FLAG_T			selOnlyExdValPricePeriodFlg, /* PMSTA06487 - RAK - 080529 */
	DBA_DYNFLD_STP    inputInstrPriceArg,
	FIN_PRICEARG_STP  priceArgStp,
	DBA_DYNFLD_STP    extPosPtr,
	DBA_HIER_HEAD_STP hierHead,
	DBA_DYNFLD_STP    pricePtr,
	FLAG_T            excludeAdjustedPriceFlg)	/* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
{
	DBA_DYNFLD_STP  *instrPriceTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP  *instrPriceTabCpy = NULLDYNSTPTR;
	DBA_DYNFLD_STP  *instrPriceTabCpySave = NULLDYNSTPTR;
	DBA_DYNFLD_STP  instrPriceArg = inputInstrPriceArg;
	DBA_DYNFLD_STP  valRuleElt = NULLDYNST;
	DBA_DYNFLD_STP  sTpPtr = NULLDYNST;
	DBA_DYNFLD_STP  aTpPtr = NULLDYNST;
	DBA_DYNFLD_STP instrPricePtr = NULLDYNST, ptfInstrPricePtr = NULLDYNST;  /* PMSTA-32157 - SILPA - 180905*/
	int	            instrPriceNbr = 0, i = 0, attribute = 0, priority = 0, rankMin = 9999;
	SMALLINT_T     *rankTab = nullptr;
	FLAG_T	        allocPriceOk = TRUE, allocArgOk = FALSE;
	FLAG_T	        datePriorityFlg = TRUE, nextPriority = TRUE, keepRankZero = FALSE;
	int	            nbOk = 0, nbOkSave = 0, firstPrice = 0;
	ID_T	        instrId = (ID_T)0, ptfId = ZERO_ID;  /* PMSTA-32157 - SILPA - 180905*/
	NAME_T	        priceSelOrder;
	RET_CODE        ret = RET_SUCCEED;
	FLAG_T			rankZeroExtendedValPriceFlg = FALSE;
	FLAG_T          keepAdjPrice = FALSE;    /* PMSTA-10049 - LJE - 101007 */
    FIELD_IDX_T     busEntityFldIdx = INVALID_FLD; /* PMSTA-32141 CMILOS 200718 */
    ID_T            busEntityId = ZERO_ID;
	OPSTAT_ENUM		accountingStatus;   /* PMSTA-32158 - SILPA - 180924*/

	/* PMSTA-32158 - SILPA - 180924 */
	/* Get acounting default status define in appl_param */
	GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

	if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Quote)
	{
		ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, NULLDYNST,
			(VALRULE_ENUM)GET_ENUM(instrPtr, A_Instr_ValRuleEn), priceArgStp,  /* REF7264 - LJE - 020131 */
			pricePtr, hierHead);
		return(ret);
	}

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
		instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
		instrId = GET_ID(instrPtr, A_Instr_Id);

	/* PMSTA-32157 - SILPA - 180905 */
	/* Extract the portfolio id from script definition or extended pos*/
	if ((instrPriceArg != NULLDYNST) && (GET_ID(instrPriceArg, InstrPrice_Arg_PtfId) > ZERO_ID))
		ptfId = GET_ID(instrPriceArg, InstrPrice_Arg_PtfId);
	else
	{
		if (extPosPtr != NULLDYNST)
			ptfId = GET_ID(extPosPtr, ExtPos_PtfId);
	}

	/* Signature Portfolio */
	/* PMSTA-33746 - RAK - 181122 - Suppress test on instr nature and sub-nature (could be used for others instruments */
	if ((ptfId != ZERO_ID) &&
		PriceCalcRule_PortfolioSpecificPrice == static_cast<PRICECALCRULE_ENUM>GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
	{
		ret = FIN_GetPtfInstrPrice(instrId, ptfId, refDateTime,
			hierHead, &ptfInstrPricePtr,
			&instrPriceNbr, &allocPriceOk);

        if ((instrPricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if ((ret != RET_SUCCEED) || (instrPriceNbr == 0))
        {
            /* PMSTA-33467- SILPA - 181107 */
            if (extPosPtr != NULLDYNST)
            {
                SET_ID(instrPricePtr, A_InstrPrice_InstrId, GET_ID(extPosPtr, ExtPos_InstrId));
                SET_ID(instrPricePtr, A_InstrPrice_CurrId, GET_ID(extPosPtr, ExtPos_InstrCurrId));
                SET_DATETIME(instrPricePtr, A_InstrPrice_QuoteDate, GET_DATETIME(extPosPtr, ExtPos_OpDate));
				/* PMSTA-50022 - Savitha - 11082022 - No Records*/
				if (0 == CMP_PRICE(ZERO_PRICE, GET_PRICE(extPosPtr, ExtOp_Price)))
				{
					SET_PRICE(instrPricePtr, A_InstrPrice_Price, 1);
					SET_PRICE(instrPricePtr, A_InstrPrice_Quote, 1);
				}
				else
				{
					SET_PRICE(instrPricePtr, A_InstrPrice_Price, GET_PRICE(extPosPtr, ExtPos_Price));
					SET_PRICE(instrPricePtr, A_InstrPrice_Quote, GET_PRICE(extPosPtr, ExtPos_Quote));
				}
                SET_ENUM(instrPricePtr, A_InstrPrice_PriceCalcRuleEn, GET_ENUM(extPosPtr, ExtPos_PriceCalcRuleEn));

                ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, instrPricePtr,
                    ValRule_Quote, priceArgStp, pricePtr, hierHead);

                FREE_DYNST(instrPricePtr, A_InstrPrice);
                return ret;
            }
            else
            {
                FREE_DYNST(instrPricePtr, A_InstrPrice);
                return(RET_FIN_INFO_NOPRICE);
            }
        }
		else
			nbOk = instrPriceNbr;

		/* Having one record*/
		if (nbOk == 1)
		{
			SET_ID(instrPricePtr, A_InstrPrice_InstrId, GET_ID(ptfInstrPricePtr, A_PortfolioInstrPrice_InstrId));
			SET_ID(instrPricePtr, A_InstrPrice_CurrId, GET_ID(ptfInstrPricePtr, A_PortfolioInstrPrice_CurrId));
			SET_DATETIME(instrPricePtr, A_InstrPrice_QuoteDate, GET_DATETIME(ptfInstrPricePtr, A_PortfolioInstrPrice_QuoteDate));

			/* PMSTA - 32158 - SILPA - 180905 */  /* Start*/
			if (extPosPtr != NULLDYNST)
			{
                /*PMSTA-33639 - SILPA - 181511*/
                if (GET_ID(extPosPtr, ExtPos_PtfId) != GET_ID(instrPtr, A_Instr_PositionPtfId) ||
                    DATETIME_CMP(GET_DATETIME(instrPtr, A_Instr_RefDateTime), refDateTime) != 0) /* PMSTA-54407 - Savitha - 30082023*/
                {
                    SET_FLAG(instrPtr, A_Instr_PtfInstrPriceQtyFlg, FALSE);
                }

                /*PMSTA-33467 -SILPA -180511*/
                if (GET_FLAG(instrPtr, A_Instr_PtfInstrPriceQtyFlg) == FALSE)
                {
                    SET_FLAG(instrPtr, A_Instr_PtfInstrPriceQtyFlg, TRUE);
                    SET_NUMBER(instrPtr, A_Instr_PtfInstrPriceQty, GET_NUMBER(ptfInstrPricePtr, A_PortfolioInstrPrice_Quantity));
                    SET_ID(instrPtr, A_Instr_PositionPtfId, GET_ID(ptfInstrPricePtr, A_PortfolioInstrPrice_PtfId));
					SET_DATETIME(instrPtr, A_Instr_RefDateTime, refDateTime);/* PMSTA-54407 - Savitha - 30082023*/
                }

                if (CMP_NUMBER(GET_NUMBER(extPosPtr, ExtPos_Qty),ZERO_NUMBER) < 0)
                {
                    SET_PRICE(instrPricePtr, A_InstrPrice_Price, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Price));
                    SET_PRICE(instrPricePtr, A_InstrPrice_Quote, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Quote));
                }
                else if (GET_ENUM(extPosPtr, ExtPos_StatEn) < accountingStatus)
                {
                    SET_PRICE(instrPricePtr, A_InstrPrice_Price, 1);
                    SET_PRICE(instrPricePtr, A_InstrPrice_Quote, 1);
                }
				/* PMSTA-50022 - Savitha - 11082022 - Removed comparision of price creation date and operation date */
                else if (CMP_NUMBER(GET_NUMBER(extPosPtr, ExtPos_Qty),GET_NUMBER(instrPtr, A_Instr_PtfInstrPriceQty)) <=0 )
                {
                    SET_NUMBER(instrPtr, A_Instr_PtfInstrPriceQty,
                        (GET_NUMBER(instrPtr, A_Instr_PtfInstrPriceQty) - GET_NUMBER(extPosPtr, ExtPos_Qty)));
                    SET_PRICE(instrPricePtr, A_InstrPrice_Price, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Price));
                    SET_PRICE(instrPricePtr, A_InstrPrice_Quote, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Quote));
                }
                /* WEALTH-10057- Deepthi - 20240628 - Incorrect AUM as market price not considered where there are 2 OTC positions
                */
                else if (DATETIME_CMP(GET_DATETIME(extPosPtr, ExtPos_OpDate), GET_DATETIME(ptfInstrPricePtr, A_PortfolioInstrPrice_QuoteDate)) <= 0)
                {
                    SET_PRICE(instrPricePtr, A_InstrPrice_Price, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Price));
                    SET_PRICE(instrPricePtr, A_InstrPrice_Quote, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Quote));
                }
                else
                {
                    SET_PRICE(instrPricePtr, A_InstrPrice_Price, 1);
                    SET_PRICE(instrPricePtr, A_InstrPrice_Quote, 1);
                }
			}
			else
			{
				SET_PRICE(instrPricePtr, A_InstrPrice_Price, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Price));
				SET_PRICE(instrPricePtr, A_InstrPrice_Quote, GET_PRICE(ptfInstrPricePtr, A_PortfolioInstrPrice_Quote));
			}
			/* PMSTA - 32158 - SILPA - 180905 */    /* End */

			SET_ENUM(instrPricePtr, A_InstrPrice_PriceCalcRuleEn, GET_ENUM(ptfInstrPricePtr, A_PortfolioInstrPrice_PriceCalcRuleEn));

			ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, instrPricePtr,
				ValRule_Quote, priceArgStp, pricePtr, hierHead);

        }

        FREE_DYNST(instrPricePtr, A_InstrPrice);
        return ret;
	}
	else
	{
		/* extract all instrprice for a instrument */
		/* PMSTA06487 - RAK - 080529 - Extract only price included in EXTENDED_VAL_PERIOD */
		FIN_SelectInstrPrice(instrId, refDateTime,
			selOnlyExdValPricePeriodFlg,	/* PMSTA06487 - RAK - 080529 */
			hierHead,
			&instrPriceTab, &instrPriceNbr, &allocPriceOk);

		if (instrPriceNbr == 0)
		{
			/*ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, NULLDYNST,
									ValRule_Quote0, priceArgStp,
									pricePtr, hierHead);*/ /* Return NULL not Quote0 */
			return(RET_FIN_INFO_NOPRICE);
		}

		/* PMSTA06487 - RAK - 080529 */
		GEN_GetApplInfo(ApplRankZeroExtendedValPriceFlag, &rankZeroExtendedValPriceFlg);

		if ((instrPriceTabCpy = (DBA_DYNFLD_STP *)CALLOC(instrPriceNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
		{
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		memcpy(instrPriceTabCpy, instrPriceTab, instrPriceNbr * sizeof(DBA_DYNFLD_STP));
		nbOk = instrPriceNbr;
		
		/* if no InstrPrice given as parameter use default */
		if (inputInstrPriceArg == NULLDYNST)
		{
			/* PMSTA-10049 - LJE - 101006 - Use instrPriceArg to define the adjusted type rank */
			SMALLINT_T       adjPriceTypeRank;
			GEN_GetApplInfo(ApplAdjustedPriceTypeRank, &adjPriceTypeRank);

			if ((instrPriceArg = ALLOC_DYNST(InstrPrice_Arg)) == NULLDYNST)
			{
				if (allocPriceOk == TRUE)
				{
					DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
				}
				else
				{
					FREE(instrPriceTab);
				}
				FREE(instrPriceTabCpy);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			allocArgOk = TRUE;

			/* set instr price argument structure with value of appl_param */
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_InstrId);
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_CurrId);
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_TpId);
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_ThirdId);
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_TermTpId);
			SET_NULL_ID(instrPriceArg, InstrPrice_Arg_MktThirdId);
			SET_SMALLINT(instrPriceArg, InstrPrice_Arg_AdjTypeRank, adjPriceTypeRank); /* PMSTA-10049 - LJE - 101006 */
			/*SET_DATETIME(instrPriceArg, InstrPrice_Arg_QuoteDate, 0);*/
			SET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg, FALSE);
			SET_FLAG(instrPriceArg, InstrPrice_Arg_TpMandatFlg, FALSE);
			SET_FLAG(instrPriceArg, InstrPrice_Arg_ThirdMandatFlg, FALSE);
			SET_FLAG(instrPriceArg, InstrPrice_Arg_MktMandatFlg, FALSE);
			SET_FLAG(instrPriceArg, InstrPrice_Arg_TermMandatFlg, FALSE);
		}

		/* search rank for all instr price and stock it into array */
		if ((sTpPtr = ALLOC_DYNST(S_Tp)) == NULLDYNST)
		{
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((aTpPtr = ALLOC_DYNST(A_Tp)) == NULLDYNST)
		{
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			FREE_DYNST(sTpPtr, S_Tp);
			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((rankTab = (SMALLINT_T *)CALLOC(instrPriceNbr, sizeof(SMALLINT_T))) == NULL)
		{
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			FREE_DYNST(sTpPtr, S_Tp);
			FREE_DYNST(aTpPtr, A_Tp);
			return(RET_DBA_ERR_NODATA);
		}

		if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_TpId) == FALSE &&
			GET_ID(instrPriceArg, InstrPrice_Arg_TpId) != 0)
		{
			SET_ID(sTpPtr, S_Tp_Id, GET_ID(instrPriceArg, InstrPrice_Arg_TpId));

			if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr,
				UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
			{
				SYSNAME_T entSqlName;
				strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
				MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
					entSqlName, GET_ID(sTpPtr, S_Tp_Id));
				if (allocPriceOk == TRUE)
				{
					DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
				}
				else
				{
					FREE(instrPriceTab);
				}
				FREE(instrPriceTabCpy);
				FREE(rankTab);
				if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
				FREE_DYNST(sTpPtr, S_Tp);
				FREE_DYNST(aTpPtr, A_Tp);
				return(RET_DBA_ERR_NODATA);
			}

			if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE && GET_SMALLINT(aTpPtr, A_Tp_Rank) == 0)
				keepRankZero = TRUE;

			/* PMSTA-10049 - LJE - 101007 */
			if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_AdjTypeRank) == FALSE &&
				GET_SMALLINT(instrPriceArg, InstrPrice_Arg_AdjTypeRank) == GET_SMALLINT(aTpPtr, A_Tp_Rank))
				keepAdjPrice = TRUE;
		}

		/* REF1170 - XDI - 980205 - supress all price with different and not NULL TermTpId */
		for (i = 0; i < instrPriceNbr; i++)
		{
			if (inputInstrPriceArg == NULLDYNST)
			{
				if (IS_NULLFLD(instrPriceTabCpy[i], A_InstrPrice_TermTpId) == FALSE &&
					(extPosPtr == NULLDYNST ||
					CMP_DYNFLD(instrPriceTabCpy[i], extPosPtr,
					A_InstrPrice_TermTpId, ExtPos_TermTpId, IdType) != 0))
				{
					nbOk--;
					instrPriceTabCpy[i] = NULLDYNST;
				}
			}
			else
			{
				if (GET_FLAG(instrPriceArg, InstrPrice_Arg_TermMandatFlg) == TRUE)
				{
					if (CMP_DYNFLD(instrPriceTabCpy[i], inputInstrPriceArg,
						A_InstrPrice_TermTpId, InstrPrice_Arg_TermTpId, IdType) != 0)

					{
						nbOk--;
						instrPriceTabCpy[i] = NULLDYNST;
					}
				}
				else
				{
					if (IS_NULLFLD(instrPriceTabCpy[i], A_InstrPrice_TermTpId) == FALSE &&
						CMP_DYNFLD(instrPriceTabCpy[i], inputInstrPriceArg,
						A_InstrPrice_TermTpId, InstrPrice_Arg_TermTpId, IdType) != 0)

					{
						nbOk--;
						instrPriceTabCpy[i] = NULLDYNST;
					}
				}
			}
		}

		{
			map<ID_T, SMALLINT_T> instrTypeRankMap; /* PMSTA-14XXX - LJE - 120918 */

			/* PMSTA-24913 - LJE - 161011 - Optimisation ... */
			ID_T lastTypeId = 0;
			SMALLINT_T lastRankN = 0;

			for (i = 0; i < instrPriceNbr; i++)
			{
				if (instrPriceTabCpy[i] != NULLDYNST)
				{
					if (IS_NULLFLD(instrPriceTabCpy[i], A_InstrPrice_TpId) == FALSE)
					{
						if (lastTypeId != GET_ID(instrPriceTabCpy[i], A_InstrPrice_TpId))
						{
							lastTypeId = GET_ID(instrPriceTabCpy[i], A_InstrPrice_TpId);

							if (instrTypeRankMap.find(lastTypeId) == instrTypeRankMap.end())
							{
								SET_ID(sTpPtr, S_Tp_Id, lastTypeId);

								if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr,
									UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
								{
									SYSNAME_T entSqlName;
									strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
									MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
										entSqlName, GET_ID(sTpPtr, S_Tp_Id));
									if (allocPriceOk == TRUE)
									{
										DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
									}
									else
									{
										FREE(instrPriceTab);
									}
									FREE(instrPriceTabCpy);
									FREE(rankTab);
									if (allocArgOk == TRUE)
									{
										FREE_DYNST(instrPriceArg, InstrPrice_Arg);
									}
									FREE_DYNST(sTpPtr, S_Tp);
									FREE_DYNST(aTpPtr, A_Tp);
									return(RET_DBA_ERR_NODATA);
								}

								if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE)
									instrTypeRankMap[lastTypeId] = GET_SMALLINT(aTpPtr, A_Tp_Rank);
								else
									instrTypeRankMap[lastTypeId] = 999;
							}

							rankTab[i] = instrTypeRankMap[lastTypeId];
							lastRankN = rankTab[i];

						}
						else
						{
							rankTab[i] = lastRankN;
						}

						/* for default analysis remove instr price with rank = 0 */
						if ((rankTab[i] == 0 && keepRankZero == FALSE) ||
							/* PMSTA-10049 - LJE - 101007 */
							(keepAdjPrice == FALSE &&
							IS_NULLFLD(instrPriceArg, InstrPrice_Arg_AdjTypeRank) == FALSE &&
							GET_SMALLINT(instrPriceArg, InstrPrice_Arg_AdjTypeRank) == rankTab[i]))
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
						else if (rankTab[i] < rankMin)
							rankMin = rankTab[i];
					}
					else
					{
						rankTab[i] = 999;
						if (rankTab[i] < rankMin)
							rankMin = rankTab[i];
					}
				}
			}
		}
		FREE_DYNST(sTpPtr, S_Tp);
		FREE_DYNST(aTpPtr, A_Tp);

		/* PMSTA06487 - RAK - 080529 */
		if (rankZeroExtendedValPriceFlg == TRUE &&	/* system parameter */
			selOnlyExdValPricePeriodFlg == FALSE &&	/* to avoid loop */
			keepRankZero == FALSE && instrPriceNbr > 0 && nbOk == 0)	/* no price (suppressed by rank=0) */
		{
			/* select prices in extended validity period */
			ret = FIN_DefaultInstrPrice(instrPtr,
				refDateTime,
				TRUE, /* PMSTA06487 - RAK - 080529 */
				instrPriceArg,
				priceArgStp,
				extPosPtr,
				hierHead,
				pricePtr,
				excludeAdjustedPriceFlg); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			FREE(rankTab);
			return(ret);
		}

		if ((valRuleElt = ALLOC_DYNST(A_ValRuleElt)) == NULLDYNST)
		{
			if (allocArgOk == TRUE)
            {
                FREE_DYNST(instrPriceArg, InstrPrice_Arg);
            }

			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			FREE(rankTab);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* Check whether the multi entity feature was configured; suppress instrument prices when BE mandatory flag is TRUE */ /* PMSTA-32141 CMILOS 200718 */
		if (GEN_IsMultiEntity())
		{
			/* set the owner_business_entity_id field index */
			DICT_ENTITY_STP instrPrice = DBA_GetDictEntitySt(InstrPrice);
			if (instrPrice != nullptr && instrPrice->ownerBusinessEntAttrStp != nullptr)
	            busEntityFldIdx = instrPrice->ownerBusinessEntAttrStp->progN;
		}

		/* if one or many mandatory field, supress all instrprice which doesn't match */
		if (GET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg) == TRUE ||
			GET_FLAG(instrPriceArg, InstrPrice_Arg_TpMandatFlg) == TRUE ||
			GET_FLAG(instrPriceArg, InstrPrice_Arg_ThirdMandatFlg) == TRUE ||
		    GET_FLAG(instrPriceArg, InstrPrice_Arg_MktMandatFlg) == TRUE ||
        	GET_FLAG(instrPriceArg, InstrPrice_Arg_BusEntityMandatFlg) == TRUE)
		{

			if (GET_FLAG(instrPriceArg, InstrPrice_Arg_TpMandatFlg) == TRUE)
				COPY_DYNFLD(valRuleElt, A_ValRuleElt, A_ValRuleElt_TypeId,
				instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_TpId);

			if (GET_FLAG(instrPriceArg, InstrPrice_Arg_MktMandatFlg) == TRUE)
			{
				COPY_DYNFLD(valRuleElt, A_ValRuleElt, A_ValRuleElt_MktThirdId,
					instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_MktThirdId);
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceMktRuleEn, PriceMktRule_Instrument);
			}
			else
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceMktRuleEn, PriceMktRule_Any);

			if (GET_FLAG(instrPriceArg, InstrPrice_Arg_ThirdMandatFlg) == TRUE)
			{
				COPY_DYNFLD(valRuleElt, A_ValRuleElt, A_ValRuleElt_ProviderThirdId,
					instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_ThirdId);
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceProviderRuleEn, PriceProvRule_Instrument);
			}
			else
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceProviderRuleEn, PriceProvRule_Any);

			if (GET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg) == TRUE)
			{
				COPY_DYNFLD(valRuleElt, A_ValRuleElt, A_ValRuleElt_CurrId,
					instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_CurrId);
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceCurrRuleEn, PriceCurrRule_Instrument);
			}
			else
				SET_ENUM(valRuleElt, A_ValRuleElt_PriceCurrRuleEn, PriceCurrRule_Any);

            if (GET_FLAG(instrPriceArg, InstrPrice_Arg_BusEntityMandatFlg) == TRUE)
            {
                COPY_DYNFLD(valRuleElt, A_ValRuleElt, A_ValRuleElt_BusEntityRuleEn,
                            instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_BusEntityRule);
            }
            else
                SET_ENUM(valRuleElt, A_ValRuleElt_BusEntityRuleEn, BusEntityRule_Any);

			for (i = 0; i < instrPriceNbr; i++)
			{
				if (instrPriceTabCpy[i] != NULLDYNST)
				{
					if (FIN_IsInstrPriceValid(instrPriceTabCpy[i], valRuleElt,
						instrPtr, extPosPtr, instrPriceArg, excludeAdjustedPriceFlg) == FALSE) /* PMSTA-10049 - LJE - 101007 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
					{
						nbOk--;
						instrPriceTabCpy[i] = NULLDYNST;
					}
				}
			}
		}

		/* read PRICE_DATE_PRIORITY_FLAG parametre */
		GEN_GetApplInfo(ApplPriceDatePriorityFlag, &datePriorityFlg);

		/* keep only more recent price if date priority is TRUE */
		if (datePriorityFlg == TRUE && nbOk > 1)
		{
			firstPrice = -1;
			for (i = 0; i<instrPriceNbr && nbOk > 1; i++)
			{
				if (firstPrice == -1 && instrPriceTabCpy[i] != NULLDYNST)
				{
					firstPrice = i;
				}
				else if (instrPriceTabCpy[i] != NULLDYNST &&
					CMP_DYNFLD(instrPriceTabCpy[firstPrice], instrPriceTabCpy[i],
					A_InstrPrice_QuoteDate, A_InstrPrice_QuoteDate, DatetimeType) != 0)
				{
					nbOk--;
					instrPriceTabCpy[i] = NULLDYNST;
				}
			}
		}

		if (nbOk == 0)
		{
			/* no price found, return 0 */
			/*ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, NULLDYNST,
									ValRule_Quote0, priceArgStp,
									pricePtr, hierHead);*/ /* return NULL not Quote0 */
			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			FREE_DYNST(valRuleElt, A_ValRuleElt);
			FREE(rankTab);
			return(RET_FIN_INFO_NOPRICE);
		}

		/* only one price, return it */
		if (nbOk == 1)
		{
			for (i = 0; i < instrPriceNbr; i++)
			{
				if (instrPriceTabCpy[i] != NULLDYNST)
				{
					ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, instrPriceTabCpy[i],
						ValRule_Quote, priceArgStp, pricePtr, hierHead);
					if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
					if (allocPriceOk == TRUE)
					{
						DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
					}
					else
					{
						FREE(instrPriceTab);
					}
					FREE(instrPriceTabCpy);
					FREE_DYNST(valRuleElt, A_ValRuleElt);
					FREE(rankTab);
					return(ret);
				}
			}
		}

		/* search the best one */
		if ((instrPriceTabCpySave = (DBA_DYNFLD_STP *)CALLOC(instrPriceNbr,
			sizeof(DBA_DYNFLD_STP))) == NULL)
		{
			if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
			if (allocPriceOk == TRUE)
			{
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
			}
			else
			{
				FREE(instrPriceTab);
			}
			FREE(instrPriceTabCpy);
			FREE_DYNST(valRuleElt, A_ValRuleElt);
			FREE(rankTab);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		memcpy(instrPriceTabCpySave, instrPriceTabCpy, instrPriceNbr * sizeof(DBA_DYNFLD_STP));
		nbOkSave = nbOk;

		GEN_GetApplInfo(ApplPriceSelOrder, priceSelOrder);/* strcpy(priceSelOrder, "CMTP");*/

		/* use offset to have disctinct attribute number for different structure */
		/* InstPrice_Arg structure, no offset */
		/* A_Instr structure offset = 100 */
		/* ExtPos structure, offset = 200 */
		/* REF1170 - XDI - 980205 - 'for' end condition changed to be dynamic */
		for (priority = 0;  priceSelOrder[priority] != ' ' &&
			priceSelOrder[priority] != END_OF_STRING && nbOk > 1; priority++)
		{
			nextPriority = FALSE;
			switch (priceSelOrder[priority])
			{
			case 'C':
			case 'c':
				/* Priority is Currency */
				if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_CurrId) == FALSE)
					attribute = InstrPrice_Arg_CurrId;
				else
					attribute = ExtPos_PosCurrId + 200;
				break;

			case 'M':
			case 'm':
				/* Priority is Market */
				if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_MktThirdId) == FALSE)
					attribute = InstrPrice_Arg_MktThirdId;
				else
					attribute = A_Instr_MktThirdId + 100;
				break;

			case 'T':
			case 't':
				/* Priority is Type */
				attribute = InstrPrice_Arg_TpId;
				break;

			case 'P':
			case 'p':
				/* Priority is Provider */
				if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_ThirdId) == FALSE)
					attribute = InstrPrice_Arg_ThirdId;
				else
					attribute = A_Instr_ProviderThirdId + 100;
				break;

			case 'F': /* REF1170 - XDI - 980205 */
			case 'f':
				/* Priority is Term Type */
				if (inputInstrPriceArg == NULLDYNST)
					attribute = ExtPos_TermTpId + 200;
				else
					attribute = InstrPrice_Arg_TermTpId;
				break;

			case 'B':  /* Priority is Business Entity */ /* PMSTA-32141 CMILOS 200718 */
			case 'b':

				/* Check whether the multi entity feature was configured */
				if (GEN_IsMultiEntity())
				{
	                switch(GET_ENUM(instrPriceArg, InstrPrice_Arg_BusEntityRule))
	                {
	                    case BusEntityRule_ConnectedBE:
	                        attribute = InstrPrice_Arg_BusEntityRule;
	                        busEntityId = SYS_GetThreadCurrBusinessEntityId();
	                        break;

	                    case BusEntityRule_Master:
	                        attribute = InstrPrice_Arg_BusEntityRule;
	                        busEntityId = EV_MasterBusinessEntityId;
	                        break;

	                    case  BusEntityRule_Any:
	                    default:
	                        nextPriority = TRUE; /* do nothing */
	                        break;
	                }
				}
				else
					nextPriority = TRUE; /* do nothing when ME is not configured */
				break;

			default:
				nextPriority = TRUE;
				break;
			}

			while (nextPriority == FALSE)
			{
				/* REF8844 - LJE - 030410 : switch -> if */
				if (attribute == InstrPrice_Arg_CurrId)
				{
					if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_CurrId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPriceArg,
							A_InstrPrice_CurrId, InstrPrice_Arg_CurrId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					attribute = ExtPos_PosCurrId + 200;
				}
				else if (attribute == InstrPrice_Arg_TpId)
				{
					if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_TpId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
                            CMP_DYNFLD(instrPriceTabCpy[i], instrPriceArg,
                                       A_InstrPrice_TpId, InstrPrice_Arg_TpId, IdType) != 0) /* PMSTA-32140 - DDV - 181015 - Very very old bug found during business entity testing */
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					attribute = A_Instr_TypeId + 100;
				}
				else if (attribute == InstrPrice_Arg_ThirdId)
				{
					if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_ThirdId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPriceArg,
							A_InstrPrice_ThirdId, InstrPrice_Arg_ThirdId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					attribute = A_Instr_ProviderThirdId + 100;
				}
				else if (attribute == InstrPrice_Arg_MktThirdId)
				{
					if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_MktThirdId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPriceArg,
							A_InstrPrice_MktThirdId, InstrPrice_Arg_MktThirdId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					attribute = A_Instr_MktThirdId + 100;
				}
				else if (attribute == InstrPrice_Arg_TermTpId)
				{/* REF1170 - XDI - 980205 */
					if (IS_NULLFLD(instrPriceArg, InstrPrice_Arg_TermTpId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPriceArg,
							A_InstrPrice_TermTpId, InstrPrice_Arg_TermTpId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					nextPriority = TRUE;
				}
                else if (attribute == InstrPrice_Arg_BusEntityRule) /* PMSTA-32141 CMILOS 200718 */
				{
                    if (busEntityFldIdx != INVALID_FLD)
					{
						for (i = 0; i < instrPriceNbr && nbOk > 0; i++)
						{
							if (instrPriceTabCpy[i] != NULLDYNST &&
                                CMP_ID(GET_ID(instrPriceTabCpy[i], busEntityFldIdx), busEntityId) != 0)
							{
								nbOk--;
								instrPriceTabCpy[i] = NULLDYNST;
							}
						}
					}
					nextPriority = TRUE;
				}
				else if (attribute == A_Instr_TypeId + 100)
				{/* Just use this attribute to seach the lowest rank */
					/* don't compare with instrument type */
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							rankTab[i] > rankMin)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					if (nbOk > 0)
						nextPriority = TRUE;
					else
						rankMin++;
				}
				else if (attribute == A_Instr_MktThirdId + 100)
				{
					if (IS_NULLFLD(instrPtr, A_Instr_MktThirdId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPtr,
							A_InstrPrice_MktThirdId, A_Instr_MktThirdId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					nextPriority = TRUE;
				}
				else if (attribute == A_Instr_ProviderThirdId + 100)
				{
					if (IS_NULLFLD(instrPtr, A_Instr_ProviderThirdId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPtr,
							A_InstrPrice_ThirdId, A_Instr_ProviderThirdId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					nextPriority = TRUE;
				}
				else if (attribute == A_Instr_RefCurrId + 100)
				{
					if (IS_NULLFLD(instrPtr, A_Instr_RefCurrId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], instrPtr,
							A_InstrPrice_CurrId, A_Instr_RefCurrId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					nextPriority = TRUE;
				}
				else if (attribute == ExtPos_PosCurrId + 200)
				{
					if (extPosPtr != NULLDYNST &&
						IS_NULLFLD(extPosPtr, ExtPos_PosCurrId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], extPosPtr,
							A_InstrPrice_CurrId, ExtPos_PosCurrId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					attribute = A_Instr_RefCurrId + 100;
				}
				else if (attribute == ExtPos_TermTpId + 200)
				{/* REF1170 - XDI - 980205 */
					if (extPosPtr != NULLDYNST &&
						IS_NULLFLD(extPosPtr, ExtPos_TermTpId) == FALSE)
					for (i = 0; i<instrPriceNbr && nbOk > 0; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST &&
							CMP_DYNFLD(instrPriceTabCpy[i], extPosPtr,
							A_InstrPrice_TermTpId, ExtPos_TermTpId, IdType) != 0)
						{
							nbOk--;
							instrPriceTabCpy[i] = NULLDYNST;
						}
					}
					nextPriority = TRUE;
				}

				if (nbOk == 1)
				{
					for (i = 0; i < instrPriceNbr; i++)
					{
						if (instrPriceTabCpy[i] != NULLDYNST)
						{
							ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime,
								instrPriceTabCpy[i], ValRule_Quote, NULL,
								pricePtr, hierHead);
							if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
							if (allocPriceOk == TRUE)
							{
								DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
							}
							else
							{
								FREE(instrPriceTab);
							}
							FREE(instrPriceTabCpy);
							FREE(instrPriceTabCpySave);
							FREE_DYNST(valRuleElt, A_ValRuleElt);
							FREE(rankTab);
							return(ret);
						}
					}
				}
				else if (nbOk == 0)
				{
					nbOk = nbOkSave;
					memcpy(instrPriceTabCpy, instrPriceTabCpySave, instrPriceNbr * sizeof(DBA_DYNFLD_STP));
				}
				else if (nbOk != nbOkSave)
				{
					nbOkSave = nbOk;
					memcpy(instrPriceTabCpySave, instrPriceTabCpy, instrPriceNbr * sizeof(DBA_DYNFLD_STP));
				}
			}
		}

		for (i = 0; i < instrPriceNbr; i++)
		{
			if (instrPriceTabCpy[i] != NULLDYNST)
			{
				ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, instrPriceTabCpy[i],
					ValRule_Quote, priceArgStp, pricePtr, hierHead);
				if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
				if (allocPriceOk == TRUE)
				{
					DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
				}
				else
				{
					FREE(instrPriceTab);
				}
				FREE(instrPriceTabCpy);
				FREE(instrPriceTabCpySave);
				FREE_DYNST(valRuleElt, A_ValRuleElt);
				FREE(rankTab);
				return(ret);
			}
		}

		/*ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, NULLDYNST,
								ValRule_Quote0, priceArgStp,
								pricePtr, hierHead);*//* returnNULL not Quote0 */
		if (allocArgOk == TRUE) { FREE_DYNST(instrPriceArg, InstrPrice_Arg); }
		if (allocPriceOk == TRUE)
		{
			DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
		}
		else
		{
			FREE(instrPriceTab);
		}
		FREE(instrPriceTabCpy);
		FREE(instrPriceTabCpySave);
		FREE_DYNST(valRuleElt, A_ValRuleElt);
		FREE(rankTab);

		return(RET_FIN_INFO_NOPRICE);
	}
}

/************************************************************************
**
**  Function    :   FIN_DiscountedInstrPrice()
**
**  Description :   Compute a discounted instrument price.
**
**  Arguments   :   posPtr       position structure pointer
**                  instrPtr     instrument structure pointer
**                  refDateTime  reference date
**                  pricePtr     pointer on price structure to update
**
**  Return      :   RET_SUCCEED or error code, pricePtr is updated
**
**  Modif.	    :   REF1079 - RAK - 971219
**
*************************************************************************/
STATIC RET_CODE FIN_DiscountedInstrPrice(DBA_DYNFLD_STP     posPtr,
			                             DBA_DYNFLD_STP     instrPtr,
			                             DATETIME_T         refDateTime,
			                             DBA_DYNFLD_STP     pricePtr,
			                             DBA_HIER_HEAD_STP  hierHead)
{
	DATETIME_T     expirDate, tillDate;
	DBA_DYNFLD_STP accrInter=NULLDYNST;
	PRICE_T        price = 0.0;
	PERCENT_T      rate;
	RET_CODE       ret = RET_SUCCEED;

	if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr,
			            refDateTime, NULLDYNST, 0, NULL, NULLDYNST,
			            posPtr, hierHead, pricePtr, FALSE);		/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

	if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
	{
	    if (IS_NULLFLD(posPtr, ExtPos_Rate) == FALSE &&
	    	GET_PERCENT(posPtr, ExtPos_Rate) != 0.0)
	    {
	    	expirDate = GET_DATETIME(posPtr,   ExtPos_ExpirDate);
	    	tillDate  = GET_DATETIME(pricePtr, A_InstrPrice_QuoteDate);

		    rate = GET_PERCENT(posPtr, ExtPos_Rate);

		    if ((ret = FIN_PeriodUnitAccrInter(instrPtr, expirDate.date, tillDate.date,
			                                   &rate, NULLDYNST, 	/* REF1079 */
											   AccrRule_None,	 /* REF11218 - TEB - 050627 */
						                       accrInter, hierHead, NULL)) == RET_SUCCEED)
		    {
			    price = GET_PRICE(pricePtr, A_InstrPrice_Price);

			    /* Add unitary accrued interest */
			    price -= GET_NUMBER(accrInter, UnitInter_UnitAccrInter);
			    price = CAST_PRICE(price);
			    SET_PRICE(pricePtr, A_InstrPrice_Price, price);
			    /* ?? quote and other fields */
			    FREE_DYNST(accrInter, UnitInter);
			    return(RET_SUCCEED);
		    }
		    else
		    {
			    FREE_DYNST(accrInter, UnitInter);
			    return(ret);
		    }
	    }
	    else
	    {
		    FREE_DYNST(accrInter, UnitInter);
	    	return(RET_SUCCEED);
	    }
	}
	else
	{
		FREE_DYNST(accrInter, UnitInter);
		return(ret);
	}
}

/************************************************************************
**
**  Function    :   FIN_ForexSwapTheoPrice()
**
**  Description :   Compute forex swap price.
**
**  Arguments   :   instrPtr    instrument structure pointer
**                  refDateTime reference date
**                  posPrice    position price
**                  pricePtr    pointer on price structure, will be updated
**
**  Return      :   RET_SUCCEED or error code
**
**  Create      :   DVP510 - XDI - 970624
**  Modif.      :   REF053 - RAK - 980422
**  Modif.      :   REF053 - RAK - 980422
**
*************************************************************************/
#if 0
STATIC RET_CODE FIN_ForexSwapTheoPrice(DBA_DYNFLD_STP    instrPtr,
			                           DATETIME_T        refDateTime,
		                               DBA_DYNFLD_STP    posPtr,
			                           DBA_DYNFLD_STP    pricePtr,
		                               DBA_HIER_HEAD_STP hierHead)
{
	long		totalLife=0, currentLife=0;
	PRICE_T         price=0.0, costPrice = 0.0;
	PRICE_T         quote=0.0;
	ID_T			calendarId  = 0; 	/* PMSTA-22396  - SRIDHARA – 160430 */


    /* REF4609 - RAK - 000502 - Set price to 0 */
	if (posPtr == NULLDYNST)
	{
		SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(instrPtr, A_Instr_Id));
		SET_ID(pricePtr, A_InstrPrice_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,    refDateTime);
		SET_FLAG(pricePtr,     A_InstrPrice_DailyDfltFlg, FALSE);
		SET_PRICE(pricePtr,   A_InstrPrice_Quote,        0.0);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,        0.0);
		SET_FLAG(pricePtr,     A_InstrPrice_UnicityFlg,   FALSE);
		SET_NUMBER(pricePtr,   A_InstrPrice_ActuRate,     0.0);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

        MSG_RETURN(RET_GEN_ERR_INVARG);
	}

	costPrice = GET_PRICE(posPtr, ExtPos_Price);

    /* PMSTA-22396  - SRIDHARA – 160430 */
    DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	DATE_DaysBetween(GET_DATE(instrPtr, A_Instr_BeginDate),
	                 GET_DATE(instrPtr, A_Instr_EndDate),
                     GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),
					 &totalLife, calendarId);

	DATE_DaysBetween(refDateTime.date,
			         GET_DATE(instrPtr, A_Instr_EndDate),	/* REF053 */
	                 GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),
        &currentLife, calendarId);   /* PMSTA-22396 - SRIDHARA – 160502 */

	price = (costPrice*(NUMBER_T)currentLife)/((NUMBER_T)totalLife);

	FIN_PriceToQuote(GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn),
                     GET_ID(instrPtr, A_Instr_Id), instrPtr,
			         refDateTime, NULL, price, &quote, hierHead);

	/* REF1986 */
	if (GET_ID(instrPtr, A_Instr_RefCurrId) == GET_ID(posPtr, ExtPos_PosCurrId) &&
	    CMP_PRICE(GET_PRICE(posPtr, ExtPos_SpotQuote), 0.0) != 0)
		price /= (GET_PRICE(posPtr, ExtPos_SpotQuote));

	SET_PRICE(pricePtr,   A_InstrPrice_Price,        CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
	SET_PRICE(pricePtr,   A_InstrPrice_Quote,        CAST_PRICE(quote)); /* REF3288 - SSO - 990205 */

	SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(instrPtr, A_Instr_Id));
	SET_ID(pricePtr, A_InstrPrice_CurrId,  GET_ID(posPtr, ExtPos_PosCurrId));

	SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
	SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
	SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
	SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,    refDateTime);
	SET_FLAG(pricePtr,     A_InstrPrice_DailyDfltFlg, FALSE);
	SET_FLAG(pricePtr,     A_InstrPrice_UnicityFlg,   FALSE);
	SET_NUMBER(pricePtr,   A_InstrPrice_ActuRate,     0.0);
	SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn, GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

	return(RET_SUCCEED);
}
#endif

/************************************************************************
**
**  Function    :   FIN_ForwardPrice()
**
**  Description :   Compute forward price.
**
**  Arguments   :   instrPtr    instrument structure pointer
**                  refDateTime reference date
**                  pricePtr    pointer on price structure, will be updated
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   REF495 - RAK - 980518
**  Modif.	    :   REF2580 - SSO - 980727
**  Modif.	    :   REF3030 - RAK - 981118
**  Modif.	    :   REF3082 - RAK - 981130
**  Modif.      :   REF5641 - RAK - 010320
**              :   PMSTA02258 - BSA - 070605
**
*************************************************************************/
RET_CODE FIN_ForwardTheoPrice(  DBA_DYNFLD_STP      instrPtr,
			                    DATETIME_T          refDateTime,
			                    FIN_PRICEARG_STP    ,
			                    DBA_DYNFLD_STP      posPtr,
			                    DBA_DYNFLD_STP      pricePtr,
			                    DBA_HIER_HEAD_STP   hierHead)
{
	DBA_DYNFLD_STP   underlyPrice=NULLDYNST, underlyPtr=NULLDYNST;
	PRICE_T          price = 0.0, posPrice = 0.0, spotPrice = 0.0;
	NUMBER_T	 actuRate = 0.0, life = 0.0;
	DATE_T           tillDate;
	DATE_T           valDate, expiDate;
	DATE_PERIOD_ST   period;
	ACCRRULE_ENUM    rule = AccrRule_None;
	RET_CODE         ret = RET_SUCCEED;
	double           freq = 0, margin = 0;
	long             valExpi = 0, refExpi = 0;
	FIN_EXCHARG_ST   exchArgSt;
    FLAG_T           allocUnderlyFlg;
    NUMBER_T         valTempo;
    ID_T			 calendarId = 0;   	/* PMSTA-22396  - SRIDHARA – 160430 */


	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	/* DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	/*** GET UNDERLYING INSTRUMENT ***/
	/* Set price to 0 */
	if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId) == TRUE || posPtr == NULLDYNST)
	{
		SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(instrPtr, A_Instr_Id));
		SET_ID(pricePtr, A_InstrPrice_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,    refDateTime);
		SET_FLAG(pricePtr,     A_InstrPrice_DailyDfltFlg, FALSE);
		SET_PRICE(pricePtr,   A_InstrPrice_Quote,        0.0);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,        0.0);
		SET_FLAG(pricePtr,     A_InstrPrice_UnicityFlg,   FALSE);
		SET_NUMBER(pricePtr,   A_InstrPrice_ActuRate,     0.0);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

        if (posPtr == NULLDYNST)
        {
            /* BSA - PMSTA02258 - 070605 */

            MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_ForwardPrice",GET_CODE(instrPtr, A_Instr_Cd), "Position is missing");
            return (RET_GEN_ERR_INVARG);
        }
        else
		    return(RET_SUCCEED);
	}

    posPrice  = GET_PRICE(posPtr, ExtPos_Price);
	spotPrice = GET_PRICE(posPtr, ExtPos_SpotPrice);

	/* ------------------------ */
	/* Compute underlying price */
	/* ------------------------ */
    /* REF3913 - 990820 - DDV */
    if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId), FALSE, &allocUnderlyFlg,
                                &underlyPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
    {
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			     entSqlName,GET_ID(instrPtr, A_Instr_UnderlyInstrId));
		return(RET_DBA_ERR_NODATA);  /* retour DBA_Get ?? */
	}

	if ((underlyPrice = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
	{
        if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_UnderlyInstrId),
		                underlyPtr, refDateTime, NULLDYNST, 0, NULL, NULLDYNST,
                        NULLDYNST, hierHead, underlyPrice, FALSE);		/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
        if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
		FREE_DYNST(underlyPrice, A_InstrPrice);
		return(ret);
	}

	/* Apply exchange between underly and instrument currency */
	ret = FIN_GetExchRate(refDateTime, GET_ID(underlyPrice, A_InstrPrice_CurrId),
			              GET_ID(instrPtr, A_Instr_RefCurrId),
			              0,NULLDYNST, posPtr, &exchArgSt, &price);	/* PMSTA01649 - TGU - 070405 */

	if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
	{
		/* Multiply exchange rate by price */
        valTempo = GET_PRICE(underlyPrice, A_InstrPrice_Price);
        price = price * valTempo;

		/* Store new price */
		price = CAST_PRICE(price);
		SET_PRICE(underlyPrice, A_InstrPrice_Price,        price);
		SET_PRICE(pricePtr,     A_InstrPrice_FwdSpotPrice, price);
	}
	else
	{
        if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
		FREE_DYNST(underlyPrice, A_InstrPrice);
		return(ret);
	}

   /* After forward end date, margin is 0 */
   if (refDateTime.date >= GET_DATE(instrPtr, A_Instr_EndDate))
   {
	    margin = 0.0;
   }
   else
   {
	    /* REF1048 - RAK - 971205 */
	    rule     = (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);   /* REF7264 - CSY - 020130 */
        valDate  = GET_DATE(instrPtr, A_Instr_BeginDate);
	    expiDate = GET_DATE(instrPtr, A_Instr_EndDate);

        /* REF5641 - RAK - 010320 */
        /* Add the settle_day_n (from instrument entity) to the operation date */
        /* Only when Valuation Domain from date is between operation date      */
        /* (=> Begin date) and operation date (=> Begin date) + settle_day_n   */
        if (IS_NULLFLD(instrPtr, A_Instr_SettleDay) == FALSE)
        {
            DATETIME_T  valDateTime;
            DATETIME_T  valSettlDate;
            int         addDays=(int) GET_PERIOD(instrPtr, A_Instr_SettleDay);

            valDateTime.date = GET_DATE(instrPtr, A_Instr_BeginDate);
            valDateTime.time = 0;

            valSettlDate.date = 0;
            valSettlDate.time = 0;

            if (SCE_CldrAddBusinessDays(instrPtr, 0, &addDays,
                                        valDateTime, &valSettlDate) == RET_SUCCEED)
            {
                    valDate = valSettlDate.date;
            }
        }

        /* PMSTA-22396  - SRIDHARA – 160430 */
        DBA_GetCalendarFromInstr(instrPtr, &calendarId);
		DATE_DaysBetween(refDateTime.date, expiDate, rule, &refExpi, calendarId);
		DATE_DaysBetween(valDate, expiDate, rule, &valExpi, calendarId);

	    if (valExpi != 0)
	    {
		    margin = (posPrice - spotPrice) * (refExpi / (double) valExpi);
	    }
	    else
	    {
            if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
	   	    FREE_DYNST(underlyPrice, A_InstrPrice);
   		    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_ForwardPrice",
			            GET_CODE(instrPtr, A_Instr_Cd), "expiration");
		    return(RET_FIN_ERR_INVDATA);
	    }
	}

	price = GET_PRICE(underlyPrice, A_InstrPrice_Price) + margin;

	price = CAST_PRICE(price);
	SET_PRICE(pricePtr,   A_InstrPrice_Quote,     price);
	SET_PRICE(pricePtr,   A_InstrPrice_Price,     price);
	SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
	SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);

	/* ----------- */
	/* Actual rate */
	/* ----------- */
    if (GET_FLAG(instrPtr, A_Instr_PhysicalFlg) == FALSE)
	{
	    /* Underlying is a rate (on x month) */
	    if (GET_ENUM(underlyPtr, A_Instr_NatEn) == InstrNat_Rate)
	    {
			FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(underlyPtr, A_Instr_RateFreqUnitEn), /* REF7264 - CSY - 020130 */
		                      GET_SMALLINT(underlyPtr, A_Instr_RateFreq),  /* PMSTA-45526 - VSW - 080721 */
	                          FreqUnit_Month, &freq);

			expiDate = GET_DATE(instrPtr, A_Instr_EndDate);
			tillDate = DATE_Move(expiDate, (int) freq, Month);

			rule = (ACCRRULE_ENUM)GET_ENUM(underlyPtr, A_Instr_AccrualRuleEn); /* REF7264 - CSY - 020130 */
            /* PMSTA-22396  - SRIDHARA – 160430 */
            DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			DATE_AccrPeriod(expiDate, tillDate, rule, (PERIOD_T)freq, &period, calendarId);
			if (period.denom != 0)
				life = period.num / (double) period.denom;
			else
				life = period.num / 360.0;
	    }
		else
			life = 1.0;

		actuRate = (GET_PRICE(underlyPrice, A_InstrPrice_Price) * life / 100);
	}
	else
		actuRate = 0.0;

	SET_NUMBER(pricePtr, A_InstrPrice_ActuRate, CAST_NUMBER(actuRate)); /* REF3288 - SSO - 990205 */

    if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
	FREE_DYNST(underlyPrice, A_InstrPrice);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrComposite()
**
**  Description :   Compute instrument value with its component values.
**
**  Arguments   :   parInstrPtr  pointer on parent instrument structure
**                  refDateTime  reference date
**                  pricePtr     pointer on price
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	    :   BUG106 - RAK - 960826
**                  BUG410 - GRD - 970630
**                  BUG423 - GRD - 970708
**  		        REF1149 - RAK - 980113
**  		        REF1485 - RAK - 980326
**		        :   REF2580 - SSO - 980727
**		        :   REF3542 - AKO - 990420 : purify -> free memory no more used
**              :   REF7782 - YST - 020904
**                  REF10256 - TEB - 040615
**
*************************************************************************/
STATIC RET_CODE FIN_InstrComposite(DBA_DYNFLD_STP       parInstrPtr,
		                           DATETIME_T           refDateTime,
		                           DBA_DYNFLD_STP       pricePtr,
			                       DBA_HIER_HEAD_STP    hierHead,
		                           DBA_DYNFLD_STP       extPosPtr)

{
	DBA_DYNFLD_STP   *instrCompoTab=(DBA_DYNFLD_STP*)NULL, getInstr=NULLDYNST,
			         instrPtr=NULLDYNST, accrInter=NULLDYNST, fixedInstrPtr=NULLDYNST;
	NUMBER_T         unitInter = 0.0;
	PRICE_T	 	 price = 0.0, totPrice = 0.0, quote = 0.0, floatLegPrice=0.0;
	SUBNAT_ENUM	 subNatEn = SubNat_None; /* REF7264 - LJE - 020131 */
	EXCHANGE_T       exch;
	int              instrCompoNbr = 0, i = 0, j = 0;
	RET_CODE         ret = RET_SUCCEED;
	FLAG_T           fullCoupFlg = FALSE, noAiFlg=FALSE;
	char             hierFlg=TRUE;
	ID_T             parInstrId = (ID_T)0, instrCurrId = (ID_T)0;
	ENUM_T           priceCalc = 0;
	FUSDATERULE_ENUM fusDateRule = FusDateRule_None;
	FIN_EXCHARG_ST   exchArgSt;			/* REFXZ */
	DATE_T			 fusionSwitchDate;  /* REF10256 - TEB - 040615 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */
	/* DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	instrCurrId = GET_ID(parInstrPtr,   A_Instr_RefCurrId);
	priceCalc   = GET_ENUM(parInstrPtr, A_Instr_PriceCalcRuleEn);

	if ((getInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/*	REF3542 - AKO/SSO - 990420
	if ((instrPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
	{
		FREE_DYNST(getInstr, S_Instr);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	*/

	if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
	{
		FREE_DYNST(getInstr, S_Instr);
		/* FREE_DYNST(instrPtr, A_Instr); */ /* REF3542 */
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

#if 0
	/*	DEV1055 - RAK - 991130
		Obsolete */
	if (GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_ForexSwaps)
    {
        /*** FOREX SWAP ***/ /* DVP510 - XDI - 970623 */
        ret = FIN_GenForexInstrCompo(parInstrPtr, hierHead, &instrCompoTab, &instrCompoNbr);
    }
	else if (GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_Swap &&
            ((SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
             (SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFixStdSwap ||
             (SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FltFltStdSwap ||
		     (SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix)) /* REF7782 - YST - 020904 */
    {
        /*** SWAP ***/ /* DVP510 - XDI - 970623 */
        ret = FIN_GenSwapInstrCompo(parInstrPtr, hierHead, &instrCompoTab, &instrCompoNbr);
    }
    else
    {
		if (GET_ID(parInstrPtr, A_Instr_Id) < 0)	/* BUG423 - GRD - 970708 */
			parInstrId = GET_ID(parInstrPtr, A_Instr_ParentInstrId);
		else
			parInstrId = GET_ID(parInstrPtr, A_Instr_Id);

            /*** COMPOSITE INSTRUMENT ***/
	    ret = DBA_SelectInstrCompo(parInstrId, refDateTime, &instrCompoTab, &instrCompoNbr);
    }
#endif

	if (GET_ID(parInstrPtr, A_Instr_Id) < 0)	/* BUG423 - GRD - 970708 */
		parInstrId = GET_ID(parInstrPtr, A_Instr_ParentInstrId);
	else
		parInstrId = GET_ID(parInstrPtr, A_Instr_Id);

    /*** COMPOSITE INSTRUMENT ***/
	ret = DBA_SelectInstrCompo(parInstrId, refDateTime, &instrCompoTab, &instrCompoNbr);

	if (ret != TRUE)
	{
		FREE_DYNST(getInstr, S_Instr);
		FREE_DYNST(accrInter, UnitInter);
   		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
			         "FIN_InstrComposite", GET_CODE(parInstrPtr,A_Instr_Cd), "composition");
		return(RET_FIN_ERR_INVDATA);
	} /* ?? */

	totPrice = 0.0;
	for (i=0; i<instrCompoNbr; i++)
	{
		/* if (DBA_Get2(Instr, UNUSED, S_Instr, getInstr, A_Instr, &instrPtr,
		             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		 */
        if (FIN_GetHierInstr(hierHead,
                             GET_ID(instrCompoTab[i], A_InstrCompo_InstrId),
                             &hierFlg,
                             &instrPtr) != RET_SUCCEED)
		{
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(getInstr, S_Instr_Id));
			FREE_DYNST(getInstr, S_Instr);
			if (FALSE==hierFlg) {FREE_DYNST(instrPtr, A_Instr);} /* REF3542 - AKO/SSO - 990420 */
			FREE_DYNST(accrInter, UnitInter);
			for(j=0; j<instrCompoNbr; j++)
				FREE_DYNST(instrCompoTab[j], A_InstrCompo);
			FREE(instrCompoTab);
			if (fixedInstrPtr != NULLDYNST) {FREE_DYNST(fixedInstrPtr, A_Instr);}
			return(RET_DBA_ERR_NODATA);
		}

		/* Use final pricePtr, but only price field will be keep and */
		/* it will be update after all component instr. are be read. */
		SET_NULL_DYNST(pricePtr, A_InstrPrice);	/* RAK - 980420 - set price to NULL */
		ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr,
				             refDateTime, NULLDYNST, 0, NULL, NULLDYNST,
				             extPosPtr, hierHead, pricePtr, FALSE);	/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

		if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
		{
			/* Composant instrument price must be convert in   */
			/* parent instr currency (if necessary and useful) */
			if ((ret == RET_SUCCEED) &&
			    (GET_ID(pricePtr, A_InstrPrice_CurrId) != instrCurrId))
			{
	   	        FIN_GetExchRate(refDateTime, GET_ID(pricePtr, A_InstrPrice_CurrId),
					            instrCurrId, 0,NULLDYNST, extPosPtr, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
			    price = GET_PRICE(pricePtr, A_InstrPrice_Price) * exch;
			}
			else
			{
			    price = GET_PRICE(pricePtr, A_InstrPrice_Price);
			}

			/* Add unitary accrued interest */
			GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

			/* REF10256 - TEB - 040615 - Begin */
			/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
			if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
				fusionSwitchDate == MAGIC_END_DATE )
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
			else
			{
				if (DATE_Cmp(refDateTime.date, fusionSwitchDate) < 0)
				{
					GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
				}
				else
				{
					GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
				}
			}
			/* REF10256 - TEB - 040615 - End */

            /* REF6171 - RAK - 010725 - Don't add accrued interest in net value (price) */
            noAiFlg = FALSE;
            if ((GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_Swap)  &&
                (GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_None))
                noAiFlg = TRUE;

            if (noAiFlg == FALSE)
            {
			    /* DVP125 - RAK - 960620 */
                /* REF7265 - YST - 020320 - add two new arguments */
			    ret = FIN_UnitAccrInter(refDateTime, GET_ID(instrPtr, A_Instr_Id),
						            instrPtr, fusDateRule, fullCoupFlg,
						            TRUE, AccrInterMethod_Default, refDateTime,
									AccrRule_None, /* REF11218 - TEB - 050627 */
									NULLDYNST, accrInter, hierHead, FALSE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

			    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && ret != RET_GEN_INFO_NOACTION)
			    {
			        if (GET_NUMBER(accrInter, UnitInter_UnitAccrInter) != 0.0 &&
				        GET_ID(accrInter, UnitInter_CurrId) != instrCurrId)
			        {
	   	    	   	    FIN_GetExchRate(refDateTime, GET_ID(accrInter, UnitInter_CurrId),
						            instrCurrId, 0,NULLDYNST, extPosPtr, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */

				        unitInter = GET_NUMBER(accrInter, UnitInter_UnitAccrInter) * exch;
			        }
			        else
			        {
				        unitInter = GET_NUMBER(accrInter, UnitInter_UnitAccrInter);
			        }

			        price += unitInter;
			    }
            }

			/* BUG106 - RAK - 960826 */
			if (GET_NUMBER(parInstrPtr,  A_Instr_ContractSize) != 0.0)
			{	price /= GET_NUMBER(parInstrPtr,  A_Instr_ContractSize); }

			totPrice += (price * GET_NUMBER(instrCompoTab[i], A_InstrCompo_Quantity));

			/* REF1485 - Keep floating leg price to send to DF2Rate and compute quote */
			subNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

			if (GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_Swap &&
                ((SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
                 (SUBNAT_ENUM)GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix)) /* REF7782 - YST - 020904 */
			{
			    if (subNatEn == SubNat_RecSwapFloatLeg ||
			        subNatEn == SubNat_PaidSwapFloatLeg)
			    {
				    floatLegPrice = price;
			    }
			    else if (subNatEn == SubNat_RecSwapFixedLeg ||
				         subNatEn == SubNat_PaidSwapFixedLeg)
			    {
				    /* le cas fixed/fixed n est pas code  pour l instant : eviter perte memoire */
				    if (fixedInstrPtr != NULLDYNST) /* REF3542 - AKO/RAK - 990420 */
				    {
					    FREE_DYNST(fixedInstrPtr, A_Instr);
				    }

				    if ((fixedInstrPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
				    {
				        FREE_DYNST(getInstr, S_Instr);
				        if (hierFlg == FALSE)
					    FREE_DYNST(instrPtr, A_Instr);
				        FREE_DYNST(accrInter, UnitInter);
				        for(j=0; j<instrCompoNbr; j++)
					    FREE_DYNST(instrCompoTab[j], A_InstrCompo);
				        FREE(instrCompoTab);
				        MSG_RETURN(RET_MEM_ERR_ALLOC);
				    }

				    COPY_DYNST(fixedInstrPtr, instrPtr, A_Instr);
			    }
			}
		}
		else
		{
			FREE_DYNST(getInstr, S_Instr);
			if (hierFlg == FALSE)
			{
				FREE_DYNST(instrPtr, A_Instr);
			}
			FREE_DYNST(accrInter, UnitInter);
			for(j=0; j<instrCompoNbr; j++)
			{
				FREE_DYNST(instrCompoTab[j], A_InstrCompo);
			}
			FREE(instrCompoTab);
			if (fixedInstrPtr != NULLDYNST)
			{
				FREE_DYNST(fixedInstrPtr, A_Instr);
			}
			/*MSG_RETURN(ret)*/;  /* REF5170 - AKO - 001030 */
            return(ret);
		}

		/* REF3542 - AKO/SSO - 990420 : purify */
		if (hierFlg == FALSE) {FREE_DYNST(instrPtr, A_Instr)};
	}

	FREE_DYNST(getInstr, S_Instr);
	FREE_DYNST(accrInter, UnitInter);

	SET_ID(pricePtr,       A_InstrPrice_CurrId,  instrCurrId);
	SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
	SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
	SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);
	SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
	SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn, priceCalc);

	totPrice = CAST_PRICE(totPrice);
	SET_PRICE(pricePtr,   A_InstrPrice_Price, totPrice);

	/* REF1485 - Don't use FIN_PriceToQuote() to update quote but use SwapFix_DF2Rate */
	if (fixedInstrPtr != NULLDYNST &&
	    (INSTRNAT_ENUM) GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_Swap &&
        ((SUBNAT_ENUM) GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
         (SUBNAT_ENUM) GET_ENUM(parInstrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix)) /* REF7782 - YST - 020904 */
	{
		ret = SCE_DF2Rate(GET_ID(fixedInstrPtr, A_Instr_Id), fixedInstrPtr,
				  hierHead, refDateTime, NULL, &floatLegPrice, &quote);
	}
	else
	{ 	/* BUG106 - RAK - 960826 */
		FIN_PriceToQuote((PRICECALCRULE_ENUM)priceCalc, /* REF7264 - CSY - 020130 */
            GET_ID(parInstrPtr, A_Instr_Id), parInstrPtr,
			             refDateTime, NULL, totPrice, &quote, hierHead);
	}

	SET_PRICE(pricePtr, A_InstrPrice_Quote, quote);

	if (fixedInstrPtr != NULLDYNST) {FREE_DYNST(fixedInstrPtr, A_Instr);}
	for(j=0; j<instrCompoNbr; j++)
		FREE_DYNST(instrCompoTab[j], A_InstrCompo);
	FREE(instrCompoTab);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_InstrLending()
**
**  Description :   Compute instrument price.
**
**  Arguments   :   refDateTime      reference date
**                  valRuleId        id of used valuation rule
**                  valRuleEltPtr    allocated val rule element structure pointer
**                  valRuleCoefNaten nature of coeff to return into instr price
**                  extPosPtr        allocated extended position structure pointer
**                  hierHear         hierarchy
**                  pricePtr         allocated price structure pointer to fill
**
**  Return      :   RET_SUCCEED, RET_FIN_INFO_NOPRICE or error code,
**                  pricePtr will be fill up
**
**  Modif       :   DVP395 - XDI - 970325
**  Modif       :   REF2580 - SSO - 980727
**
*************************************************************************/
STATIC RET_CODE FIN_InstrLending(DATETIME_T        refDateTime,
			                     ID_T              valRuleId,
			                     DBA_DYNFLD_STP    valRuleEltPtr,
			                     ENUM_T	           valRuleCoefNatEn,
			                     DBA_DYNFLD_STP    extPosPtr,
			                     DBA_HIER_HEAD_STP hierHead,
		                         DBA_DYNFLD_STP    pricePtr)
{
	DICT_ATTRIB_STP  attribStp      = (DICT_ATTRIB_STP)  NULL;
	DBA_DYNFLD_STP   aScriptDef=NULLDYNST, *scriptDefTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP   sValRuleCoeff=NULLDYNST, aValRuleCoeff=NULLDYNST;
	DBA_DYNFLD_ST    result;
	int 		     scriptDefNbr = 0, i = 0;
    char             *scptBuf;
    SCPT_ARG_STP     genContext = (SCPT_ARG_STP)NULL;
	RET_CODE         ret=RET_SUCCEED;

    memset(&result, 0, sizeof(DBA_DYNFLD_ST));

	/* get val rule coeff */
	if ((sValRuleCoeff = ALLOC_DYNST(S_ValRuleCoeff)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((aValRuleCoeff = ALLOC_DYNST(A_ValRuleCoeff)) == NULLDYNST)
	{
		FREE_DYNST(sValRuleCoeff, S_ValRuleCoeff);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNFLD(sValRuleCoeff, S_ValRuleCoeff, S_ValRuleCoeff_ValRuleElemId,
	            valRuleEltPtr, A_ValRuleElt,   A_ValRuleElt_Id);
	SET_ENUM(sValRuleCoeff, S_ValRuleCoeff_NatEn, valRuleCoefNatEn);

	if (DBA_Get2(ValRuleCoeff, UNUSED, S_ValRuleCoeff, sValRuleCoeff, A_ValRuleCoeff,
                     &aValRuleCoeff, UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
	{
		COPY_DYNFLD(pricePtr,      A_InstrPrice,   A_InstrPrice_ValRuleCoef,
                    aValRuleCoeff, A_ValRuleCoeff, A_ValRuleCoeff_Value);
		SET_ENUM(pricePtr, A_InstrPrice_CoefNatEn, valRuleCoefNatEn);
	}
	else
	{
		SET_NULL_NUMBER(pricePtr, A_InstrPrice_ValRuleCoef);
		SET_NULL_ENUM(pricePtr, A_InstrPrice_CoefNatEn);
	}

	FREE_DYNST(sValRuleCoeff, S_ValRuleCoeff);
	FREE_DYNST(aValRuleCoeff, A_ValRuleCoeff);

	COPY_DYNFLD(pricePtr,      A_InstrPrice, A_InstrPrice_InstrId,
		        extPosPtr,     ExtPos,       ExtPos_InstrId);
	COPY_DYNFLD(pricePtr,      A_InstrPrice, A_InstrPrice_CurrId,
		        extPosPtr,     ExtPos,       ExtPos_InstrCurrId);

    SET_NULL_ID(pricePtr,      A_InstrPrice_TpId);
	SET_NULL_ID(pricePtr,      A_InstrPrice_ThirdId);
	SET_NULL_ID(pricePtr,      A_InstrPrice_TermTpId);
	SET_NULL_ID(pricePtr,      A_InstrPrice_MktThirdId);
	SET_DATETIME(pricePtr,     A_InstrPrice_QuoteDate, refDateTime);
	SET_FLAG(pricePtr,         A_InstrPrice_DailyDfltFlg, FALSE);
	SET_PRICE(pricePtr,       A_InstrPrice_Quote, 0.0);
	SET_PRICE(pricePtr,       A_InstrPrice_Price, 0.0);
	SET_NULL_ENUM(pricePtr,    A_InstrPrice_PriceCalcRuleEn);
	SET_FLAG(pricePtr,         A_InstrPrice_UnicityFlg, FALSE);
	SET_ID(pricePtr,           A_InstrPrice_ValRuleId, valRuleId);

    COPY_DYNFLD(pricePtr,      A_InstrPrice, A_InstrPrice_ValRuleEltId,
		        valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

    SET_NULL_NUMBER(pricePtr,  A_InstrPrice_ActuRate);
	SET_NULL_PRICE(pricePtr,  A_InstrPrice_FwdSpotPrice);

	if ((aScriptDef = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	attribStp = DBA_GetAttributeBySqlName(ValRuleElt, "script_definition");

	SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, attribStp->attrDictId);

    COPY_DYNFLD(aScriptDef,    A_ScriptDef,  A_ScriptDef_ObjId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

    SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

    if ((DBA_Select2(ScriptDef, UNUSED, A_ScriptDef, aScriptDef,
                     A_ScriptDef, &scriptDefTab, UNUSED, UNUSED,
                     &scriptDefNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ScriptDef));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(aScriptDef, A_ScriptDef_ObjId));
		FREE_DYNST(aScriptDef, A_ScriptDef);
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(aScriptDef, A_ScriptDef);

	if ((scptBuf = (char *) CALLOC(1, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181011 */
		MSG_RETURN(RET_MEM_ERR_ALLOC);

    scptBuf[0] = END_OF_STRING;
    for (i=0; i<scriptDefNbr; i++)
        strcat(scptBuf, GET_STRING(scriptDefTab[i], A_ScriptDef_Def));

    DBA_FreeDynStTab(scriptDefTab, scriptDefNbr, A_ScriptDef);

	if (scptBuf[0] != END_OF_STRING)
	{
		 /* generate evaluation tree */
        if ((ret = SCPT_GenerateScptTree(scptBuf,
                                         EPos,
                                         InternalSMode,
                                         PriceType, /* PMSTA-52091 - DDV - 230302 */
                                         &genContext)) == RET_SUCCEED)
        {
	        COPY_DYNFLD(extPosPtr,     ExtPos,       ExtPos_LendingValRuleEltId,
	                    valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

            ret = SCPT_ExecScptTree(genContext,
	                                DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)), /* REF2580 - SSO - 980727 */
                                    hierHead,
                                    extPosPtr,
                                    PriceType, /* PMSTA-52091 - DDV - 230302 */
                                    &result,
									NULLDYNST); /* PMSTA14443 - DDV - 120709 */
        }

		SCPT_FreeScptTree(genContext);

		if (ret == RET_SUCCEED)
		{
			SET_PRICE(pricePtr, A_InstrPrice_Quote, GET_NUMBER((&result), 0));
			SET_PRICE(pricePtr, A_InstrPrice_Price, GET_NUMBER((&result), 0));
		}
	}
	FREE(scptBuf);

	if (ret != RET_SUCCEED)
		ret = RET_FIN_INFO_NOPRICE;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrOrUnderlyLife()
**
**  Description :   Instrument life is the period between the settlement
**		            date and the maturity date expressed in days/year
**		            using the accrual day rule defines at the instrument level
**
**  Arguments   :   instrPtr   instrument pointer
**                  settleDate settlement date
**                  lifeStp    pointer on life output structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP440 - RAK - 970425
**  Modif       :   DVP561 - RAK - 970826 - Return FIN_LIFE_STP structure
**  Modif       :   REF3477 - RAK - 990325 - Read new FIN_LIFE_STP structure argument accrRule.
**
*************************************************************************/
RET_CODE FIN_InstrOrUnderlyLife(char                underlyFlg,
			                    DBA_DYNFLD_STP      instrPtr,
			                    DATETIME_T          settleDate,
			                    FIN_LIFE_STP        lifeStp,
		                        DBA_HIER_HEAD_STP   hierHead)
{
	double         	freq = 0;
	DATE_PERIOD_ST 	period;
	DBA_DYNFLD_STP	underlyPtr = NULLDYNST;
	ACCRRULE_ENUM 	rule = AccrRule_None;
	RET_CODE	    ret  = RET_SUCCEED;
    FLAG_T          allocUnderlyFlg;
    ID_T	        calendarId = 0;  	/* PMSTA-22396  - SRIDHARA – 160430 */

	if (underlyFlg == FALSE)
	{
	    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_RateFreqUnitEn), /* REF7264 - CSY - 020130 */
		                  GET_SMALLINT(instrPtr, A_Instr_RateFreq), FreqUnit_Month, &freq); /* PMSTA-45526 - VSW - 080721 */

	    lifeStp->begDate  = settleDate.date;
	    lifeStp->endDate  = GET_DATE(instrPtr, A_Instr_EndDate);
	    lifeStp->subNatEn = SubNat_None;
	    rule              = (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);  /* REF7264 - CSY - 020130 */

	    ret = RET_SUCCEED;
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId) == TRUE)
	    {
		    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
			             "FIN_InstrOrUnderlyLife", GET_CODE(instrPtr, A_Instr_Cd), "underly");
		    return(RET_FIN_ERR_INVDATA);
	    }

        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId), FALSE, &allocUnderlyFlg,
                                    &underlyPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
		    SYSNAME_T entSqlName;
		    strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
		    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(instrPtr, A_Instr_UnderlyInstrId));
		    return(RET_DBA_ERR_NODATA);
	    }

	    if ((INSTRNAT_ENUM) GET_ENUM(underlyPtr, A_Instr_NatEn) == InstrNat_Rate &&
		    IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE)
	    {
	        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(underlyPtr, A_Instr_RateFreqUnitEn), /* REF7264 - CSY - 010230 */
		                      GET_SMALLINT(underlyPtr, A_Instr_RateFreq), FreqUnit_Month,/* PMSTA-45526 - VSW - 080721 */
                              &freq);

	        lifeStp->begDate  = GET_DATE(instrPtr, A_Instr_EndDate);
	        lifeStp->endDate  = DATE_Move(lifeStp->begDate, (int) freq, Month);
	        lifeStp->subNatEn = (SUBNAT_ENUM) GET_ENUM(underlyPtr, A_Instr_SubNatEn);

		    /* REF3477 - Use received accrual rule */
		    if (lifeStp->accrRuleEn != AccrRule_None)
		    { rule = lifeStp->accrRuleEn; }
		    else
		    { rule = (ACCRRULE_ENUM)GET_ENUM(underlyPtr, A_Instr_AccrualRuleEn); } /* REF7264 - CSY - 010230 */

		    ret = RET_SUCCEED;
	    }
	    else
	    {
	    	lifeStp->subNatEn = SubNat_None;
		    lifeStp->life     = 1.0;
		    ret = RET_GEN_INFO_NOACTION;
	    }

        if (allocUnderlyFlg == TRUE) {FREE_DYNST(underlyPtr, A_Instr);}
	}

	if (ret == RET_SUCCEED)
	{
        /* PMSTA-22396  - SRIDHARA – 160430 */
        DBA_GetCalendarFromInstr(instrPtr, &calendarId);
		DATE_AccrPeriod(lifeStp->begDate, lifeStp->endDate, rule, (PERIOD_T)freq, &period, calendarId);

	    if (period.denom != 0)
	        lifeStp->life = period.num / (double) period.denom;
	    else
	        lifeStp->life = period.num / 360.0;
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_GetAdAMInfoForInstr()
**
**  Description :   Init some variables used by AdAM fonctionality
**
**  Arguments   :   instrPtr   instrument pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF1055 - RAK - 000315
**  Modif.	:   REF5306 - RAK - 010208 - old FIN_InstrPriceInitAdAM()
**
*************************************************************************/
void FIN_GetAdAMInfoForInstr(DBA_DYNFLD_STP instrPtr,
                            ID_T           *defaultValuationRuleId,
                            FLAG_T         *isAALicenseFlag,
                            FLAG_T         *isTheoriticalInstrument)
{
    ADAM_LICENCEE_ENUM  isAALicenseEn=AdamLicencee_No;
    INSTRNAT_ENUM       instrNatEn;

    /*
		DEV1055 - CSA - 14101999
		Get the Identifier of the default valuation rule
	*/
	GEN_GetApplInfo(ApplAADefValueRuleId, defaultValuationRuleId);

    /*
        DEV1055 - CSA - 21121999
        Get for the Advanced Analytics License flag
    */
    GEN_GetApplInfo(ApplAALicense, &isAALicenseEn);
    instrNatEn = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);  /* REF7264 - 020130 - CSY */

    if ((instrNatEn == InstrNat_Bond ||
         instrNatEn == InstrNat_Discount ||
         instrNatEn == InstrNat_MoneyMkt ||
         instrNatEn == InstrNat_Swap ||
         instrNatEn == InstrNat_ForexSwaps ||
         instrNatEn == InstrNat_FlowInstr) &&
        isAALicenseEn >= AdamLicencee_Level1)
    {
        *isAALicenseFlag = TRUE;
    }
    else if ((instrNatEn == InstrNat_Future ||
              /* instrNatEn == InstrNat_Forward || */    /*  REF5586 - AKO-RAK - 010207 */
              instrNatEn == InstrNat_FRA) &&
             isAALicenseEn >= AdamLicencee_Level2)
    {
        *isAALicenseFlag = TRUE;
    }
    else if ((instrNatEn == InstrNat_Option ||
              instrNatEn == InstrNat_ExoticOptions || instrNatEn == InstrNat_ConvertBond) &&
             isAALicenseEn >= AdamLicencee_Level3)
    {
        *isAALicenseFlag = TRUE;
    }
    else if (instrNatEn == InstrNat_Forward)        /* REF5586 - AKO-RAK - 010207 */
    {
        /* REF5586 - RAK - 010221 - If FORWARD_VAL_RULE is Point -> use Adam for Forward */
        FORWARD_VAL_ENUM    fwdValRuleEn;
        GEN_GetApplInfo(ApplForwardValRule, &fwdValRuleEn);
        if (fwdValRuleEn == Forward_Point)
            *isAALicenseFlag = TRUE;
        else
            *isAALicenseFlag = FALSE;
    }
    else
    {
        *isAALicenseFlag = FALSE;
    }

	/* Is the instrument theoritical */
	*isTheoriticalInstrument = FALSE;
	if(GET_ENUM(instrPtr, A_Instr_ValRuleEn)==ValRule_Theo)
		*isTheoriticalInstrument = TRUE;
}


/************************************************************************
**
**  Function    :   FIN_InstrUnderlyingCategory()
**
**  Description :   Compute instrument price from underlying instruments
**
**  Arguments   :   instrPtr                Instrument used has reference
**                  refDateTime             Reference date and time
**                  priceArgStp             Price arguments
**                  extPosPtr               Pointer on position (same rule need it)
**                  hiearHead               Pointer on hierarchy
**                  pricePtr                Price structure to fill
**
**  Return      :   None
**
**  Creation    :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_InstrUnderlyingCategory(const DBA_DYNFLD_STP                   instrPtr,
                                     const DATETIME_T &                     refDateTime,
                                     FIN_PRICEARG_STP                       priceArgStp,
                                     DBA_DYNFLD_STP                         extPosPtr,
                                     DBA_HIER_HEAD_STP                      hierHead,
                                     DBA_DYNFLD_STP                         pricePtr,
                                     ID_T &                                 worstInstrId,
                                     const INSTR_UNDERLYING_CATEGORY_ENUM & instrUnderlyCatEn
                                    )
{
    MemoryPool  mp;

    worstInstrId = ZERO_ID;

    /*
     * Set input structure for select
     */
    DBA_DYNFLD_STP *    selInstrCompoTab = nullptr;
    int                 selInstrCompoNbr = 0;

	/* PMSTA-32502 -RAK - 180925 - Use same function as risk treatment and all Structured notes treatment */
	RET_CODE ret = FIN_SelectUnderlyingCompo(hierHead, refDateTime, instrPtr, &selInstrCompoTab, &selInstrCompoNbr); /* PMSTA-32502 - RAK - 180924 */

    if (RET_SUCCEED == ret && selInstrCompoNbr > 0)
    {
        mp.owner(selInstrCompoTab, selInstrCompoNbr);

        DBA_DYNFLD_STP compoPricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

        /*
         * Grab data for the computation of the field
         */
        std::vector<NUMBER_T>   weightedPrices;
        std::vector<ID_T>       weightedPricesInstrId;

        for (int idx = 0 ; idx < selInstrCompoNbr && RET_SUCCEED == ret; idx++)
        {
            DBA_DYNFLD_STP      curentInstrCompo                    = selInstrCompoTab[idx];
            const PERCENT_T     currentInstrCompoWeight             = GET_PERCENT(curentInstrCompo, A_InstrCompo_BasketWeightP) * 0.01;
            const PRICE_T      currentInstrCompoBasketFixingPrice  = GET_PRICE (curentInstrCompo, A_InstrCompo_BasketFixingPrice);
            FLAG_T              allocInstrOk                        = FALSE;
            DBA_DYNFLD_STP      curentInstr                         = nullptr;

            ret = DBA_GetInstrById(GET_ID(curentInstrCompo, A_InstrCompo_InstrId) , FALSE, &allocInstrOk, &curentInstr, hierHead, UNUSED, nullptr);

            if (RET_SUCCEED == ret)
            {
                ret = FIN_DefaultInstrPrice(curentInstr, refDateTime, FALSE, nullptr, priceArgStp, extPosPtr, hierHead, compoPricePtr, FALSE);

                if (RET_SUCCEED == ret)
                {
                    weightedPrices.push_back(currentInstrCompoWeight * FIN_DIV(GET_PRICE(compoPricePtr, A_InstrPrice_Price), currentInstrCompoBasketFixingPrice));
                    weightedPricesInstrId.push_back(GET_ID(compoPricePtr, A_Instr_Id));
                }
                else
                {
                    weightedPrices.push_back(currentInstrCompoWeight * currentInstrCompoBasketFixingPrice);
                    weightedPricesInstrId.push_back(GET_ID(curentInstrCompo, A_Instr_Id));
                }

                if (TRUE == allocInstrOk)
                {
                    FREE_DYNST(curentInstr, A_Instr);
                }
            }
        }


        /*
         * Computation of the field
         */
        if (RET_SUCCEED == ret && false == weightedPrices.empty())
        {
            const PRICE_T initialFixingPrice = GET_PRICE(instrPtr, A_Instr_UnderlyFixingPrice);

            switch(instrUnderlyCatEn)
            {
                case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                    {
                        const NUMBER_T sumWeightedPrices = std::accumulate(weightedPrices.begin(), weightedPrices.end(), ZERO_NUMBER);

                        SET_PRICE(pricePtr, A_InstrPrice_Price, initialFixingPrice * sumWeightedPrices);
                    }
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                    {
                        const size_t worstIdx = std::distance(weightedPrices.begin(), std::min_element(weightedPrices.begin(), weightedPrices.end()));

                        SET_PRICE(pricePtr, A_InstrPrice_Price, initialFixingPrice * weightedPrices[worstIdx]);
                        worstInstrId = weightedPricesInstrId[worstIdx];
                    }
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                    break;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_InstrPrice()
**
**  Description :   Compute instrument price.
**
**  Arguments   :   instrId                 instrument identifier (for alloc if necessary)
**                  instrPtr	            allocated instrument structure pointer
**                  refDateTime             reference date and time
**                  instrPriceArg           arguments or NULL and defaults values will be used
**		            valRuleId               id of rule to use for quoting instrument
**                  valRulePtr              allocated valrule structure pointer
**                  extPos                  allocated pointer on position (same rule need it)
**                  hiearHead               pointer on hierarchy
**                  pricePtr	            allocated price structure pointer to fill
**                  excludeAdjustedPriceFlg Indicate is adjusted price must be removed even if valRuleElt or PriceArg select it.
**                                          It is used to avoid using adjusted prices during thoeritical computation  (DURA, MDURA, YTM . . .).
**
**  Return      :   RET_SUCCEED, RET_FIN_INFO_NOPRICE or error code,
**                  pricePtr will be fill up
**
**  Modif       :   BUG045 - RAK - 960628
**  Modif       :   BUG195 - RAK - 961107
**  Modif       :   DVP294 - RAK - 961204
**  Modif       :   DVP344 - XDI - 970213
**  Modif       :   DVP395 - XDI - 970325
**  Modif       :   DVP440 - RAK - 970425
**  Modif.	    :   REF1108 - RAK - 980112
**  Modif       :   REF2580 - SSO - 980727
**	Modif		:	PMSTA06487 - RAK - 080529
**                  PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
*************************************************************************/
RET_CODE FIN_InstrPrice(ID_T              instrId, 
						DBA_DYNFLD_STP    inputInstrPtr, 
						DATETIME_T        refDateTime, 
						DBA_DYNFLD_STP    instrPriceArgParam,
						ID_T	          valRuleId,
						FIN_PRICEARG_STP  priceArgStp,
						DBA_DYNFLD_STP    inputValRulePtr,
						DBA_DYNFLD_STP    extPosPtr,
						DBA_HIER_HEAD_STP hierHead,
						DBA_DYNFLD_STP    pricePtr,
						FLAG_T            excludeAdjustedPriceFlg) /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
{
    DBA_DYNFLD_STP  instrPtr=NULLDYNST;
    DBA_DYNFLD_STP  valRulePtr=NULLDYNST;
    DBA_DYNFLD_STP  valRuleHistPtr=NULLDYNST;
    DBA_DYNFLD_STP  domainPtr=NULLDYNST;
    DBA_DYNFLD_STP  *valRuleEltTab=NULLDYNSTPTR, *instrPriceTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  instrPriceArg = instrPriceArgParam;
	ID_T            listId=0;
    int             valRuleEltNbr = 0, instrPriceNbr = 0;
    int             firstRuleElt = 0, lastRuleElt = 0;
    int             valRuleUsed = 0;
    RET_CODE        ret = RET_SUCCEED;
    MemoryPool      mp;

    /* DVP440 - current date use in SelectInstrPrice() */

    /**** LOAD INSTRUMENT ****/
    /* If instrument structure was load upper, his pointer is given */
    /* in parameters list. So function use it and don't free it.    */
    if (inputInstrPtr != NULLDYNST)
    {
        instrPtr = inputInstrPtr;
    }
    else
    {
        FLAG_T allocInstrOk = FALSE;

        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocInstrOk,
                                    &instrPtr, hierHead, UNUSED, nullptr)) != RET_SUCCEED)
        {
            if (instrId > 0)        /*  FIH-REF5013-010207  */
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, DBA_GetDictEntitySqlName(Instr), instrId);
            }
            return(RET_DBA_ERR_NODATA);
        }
        if (TRUE == allocInstrOk)
        {
            mp.owner(instrPtr);
        }
    }

	/* PMSTA-51476 - DDV - 221216 - For instrument having SubNat_FXFwd_TwoLegsAgainsPtfCurr as sub nature,
	                                return price with the currency of underlying instrument */
	if (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
	{
		if (instrPriceArg == NULL || 
			IS_NULLFLD(instrPriceArg, InstrPrice_Arg_CurrId) == TRUE ||
			GET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg) == FALSE)
		{
			FLAG_T          allocOk = FALSE;
			DBA_DYNFLD_STP  underlyInstrPtr = NULLDYNST;

			DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId), TRUE, &allocOk, &underlyInstrPtr, hierHead, UNUSED, UNUSED);

			if (underlyInstrPtr != NULLDYNST)
			{
				if (instrPriceArg == NULL)
				{
					instrPriceArg = mp.allocDynst(FILEINFO, InstrPrice_Arg);
				}

				if (priceArgStp != NULL)
				{
					COPY_DYNFLD(instrPriceArg, InstrPrice_Arg, InstrPrice_Arg_CurrId, underlyInstrPtr, A_Instr, A_Instr_RefCurrId);
					SET_FLAG(instrPriceArg, InstrPrice_Arg_CurrMandatFlg, TRUE);
				}
			}
		}
	}

    /* REF1055 - RAK - 000315 */
    ID_T    defaultValuationRuleId = ZERO_ID;   /* DEV1055 - CSA - 14101999 */
    FLAG_T  isTheoriticalInstrument = FALSE;    /* DEV1055 - CSA - 18101999 */
    FLAG_T  isAALicenseFlg          = FALSE;    /* DEV1055 - CSA - 21121999 */
    FIN_GetAdAMInfoForInstr(instrPtr,
                            &defaultValuationRuleId,
                            &isAALicenseFlg,
                            &isTheoriticalInstrument);

	/* BUG195 */
	if (GET_ID(instrPtr, A_Instr_Id) < 0)
	    instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    instrId = GET_ID(instrPtr, A_Instr_Id);

	/* DVP440 - RAK - 970428 */
	if (extPosPtr   != nullptr &&
	    priceArgStp != nullptr && priceArgStp->costQuote == 0.0)
		priceArgStp->costQuote = GET_PRICE(extPosPtr, ExtPos_Quote);

	/* if no valuation rule look for it in Domain (only if no instrprice argument define), PPS, Portfolio */
	if (valRuleId == 0 &&
        instrPriceArg == NULLDYNST &&
	    ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead))) != NULLDYNST)) /* REF2580 - SSO - 980727 */
	{
		if ((ret = FIN_GetValRuleIdInDomPPSPtf(domainPtr,
							                   extPosPtr,
							                   hierHead,
							                   &valRuleId)) != RET_SUCCEED)
		{
		    return(ret);
		}
	}

	/*	DEV1055 - CSA - 11101999
		If no valuation rule AND if the instrument is a theorical instrument,
		then get the default AA_DEF_VAL_RULE and continue with
		this valuation rule identifier !
	*/
	if (valRuleId<=0)
	{
		/* Test if it's a theorical instrument AND if there is the AA License   */
		if ((isTheoriticalInstrument==TRUE) &&  (isAALicenseFlg==TRUE)  )
        {
			valRuleId	=	defaultValuationRuleId;
            if (valRuleId == 0)
            {
                /* REF5563 - YST - 020819 - message changed */
		        MSG_SendMesg(RET_GEN_ERR_INVARG, 4, FILEINFO, "FIN_InstrPrice()",
                            "The default valuation rule is missing.");
            }
        }
	}

    /* if no valRule in parameter use default define with appl_param */
    if (valRuleId <= 0)
    {
        ret = FIN_DefaultInstrPrice(instrPtr,
                                    refDateTime,
                                    FALSE, /* PMSTA06487 - RAK - 080529 */
                                    instrPriceArg,
                                    priceArgStp,
                                    extPosPtr,
                                    hierHead,
                                    pricePtr,
                                    excludeAdjustedPriceFlg);	/* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

        return ret;
    }

    {/**** LOAD Valuation Rule and valuation rule history ****/
        /* If valuation rule structure was load upper, his pointer is given */
        /* in parameters list. So function use it and don't free it.    */
        FLAG_T allocValRuleOk = FALSE;

        if ((ret = FIN_LoadValRuleAndHist(valRuleId,
                                            refDateTime,
                                            inputValRulePtr,
                                            &allocValRuleOk,
                                            &valRulePtr,
                                            &valRuleHistPtr)) != RET_SUCCEED)
        {
            return(ret);
        }

        mp.owner(valRuleHistPtr);

        if (TRUE == allocValRuleOk)
        {
            mp.owner(valRulePtr);
        }
    }

    OBJECT_ENUM entity = NullEntity;
    DBA_GetObjectEnum(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId), &entity);

	/* if not classification for extpos entity and nature ValRuleNat_InstrLending */
	/* or no extpos in parametre, return no price found */
	/*if (GET_ENUM(valRulePtr, A_ValRule_NatEn) == ValRuleNat_InstrLending &&
            (entity != EPos || extPosPtr == NULLDYNST))
	{
	    if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
            FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            return(RET_FIN_INFO_NOPRICE);
	}*/

	/* if classification for extpos entity and no extpos in parametre */
	/* return instr price using default definiton from appl_param */
	if (entity == EPos && extPosPtr == NULLDYNST)
	{
		ret = FIN_DefaultInstrPrice(instrPtr,
		                            refDateTime,
									FALSE, /* PMSTA06487 - RAK - 080529 */
		                            instrPriceArg,
					                priceArgStp,
		                            extPosPtr,
		                            hierHead,
		                            pricePtr,
									excludeAdjustedPriceFlg);	/* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

		return(ret);
	}

    /* Select all valuation rule element */
    if ((ret = FIN_LoadValRuleElt(valRuleHistPtr,
                                  &valRuleEltNbr,
                                  &valRuleEltTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    mp.owner(valRuleEltTab, valRuleEltNbr);

	/* Classify the entity define in valRuleHistory */
	/* (listId is filled, could be 0 if no classification is found) */
	if ((ret = FIN_InstrPriceClassify(entity,
					                  instrPtr,
					                  instrId,
					                  extPosPtr,
					                  valRuleHistPtr,
					                  hierHead,
					                  &listId,
                                      refDateTime,
                                      domainPtr)) != RET_SUCCEED)
	{
		return(ret);
	}

    FLAG_T  found          = FALSE;
    FLAG_T  datePriority   = GET_FLAG(valRulePtr, A_ValRule_DatePriorityFlg);
    FLAG_T  notQuote       = FALSE;
    int     bestPrice      = -1;
    int     bestValRuleElt = -1;

    /* search the first element in list corresponding to list_id */
    int i = 0;
    while (i < valRuleEltNbr && GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) < listId)
        i++;

    /* The instrument isn't in the list */  /* REF5711 - RAK - 010313 - verify listId */
	if (i == valRuleEltNbr || GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) != listId)
	{
		/*
			DEV1055 - CSA 18101999
			If the instrument is theoritical AND
			if the valuation rule is not equal to
			the default valuation rule, then
			RECALL FIN_InstrPrice with AA_DEF_VAL_RULE
			identifier.
		*/
		if	((valRuleId!=defaultValuationRuleId) &&
             (isTheoriticalInstrument==TRUE) && (isAALicenseFlg==TRUE)  )
		{
			ret	=	FIN_InstrPrice(	instrId,
									inputInstrPtr,
									refDateTime,
									instrPriceArg,
									defaultValuationRuleId,	/*	Force the default valuation rule identifier	*/
									priceArgStp,
									inputValRulePtr,
									extPosPtr,
									hierHead,
									pricePtr,
									excludeAdjustedPriceFlg); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
			return(ret);
		}
		else
		{
			/* REF969 - XDI - 971512 */
			ret = FIN_DefaultInstrPrice(instrPtr,
										refDateTime,
										FALSE, /* PMSTA06487 - RAK - 080529 */
										instrPriceArg,
							            priceArgStp,
										extPosPtr,
										hierHead,
										pricePtr,
										excludeAdjustedPriceFlg); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
			return(ret);
		}
	}
	else
	{
		/*
			DEV1055 - CSA - 18101999
			If valuation rule element nature is theoretical AND
			if the valuation rule is not equal to the
			default valuation rule identifier, then
			RECALL FIN_InstrPrice with the
			AA_DEF_VAL_RULE identifier
		*/
		if ((valRuleId!=defaultValuationRuleId)	&&	(GET_ENUM(valRuleEltTab[i],A_ValRuleElt_EvalRuleEn)==EvalRule_ValuedWithTheoPrice)	 &&  (isAALicenseFlg==TRUE) )
		{
			ret	=	FIN_InstrPrice(	instrId,
									inputInstrPtr,
									refDateTime,
									instrPriceArg,
									defaultValuationRuleId,	/*	Force the default valuation rule identifier	*/
									priceArgStp,
									inputValRulePtr,
									extPosPtr,
									hierHead,
									pricePtr,
									excludeAdjustedPriceFlg); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
			return(ret);
		}
	}

	/*
		DEV1055 - CSA 18101999
		If valuation rule nature is theoretical AND
		if a valuation rule element corresponding
		to choosen list in classification is found,
		then call FIN_InstrTheoricPrice
	*/
    if	((i != valRuleEltNbr) &&
         (GET_ENUM(valRulePtr, A_ValRule_NatEn) == ValRuleNat_Theoritical) &&
         (isAALicenseFlg==TRUE))
	{
		ret	=	FIN_InstrTheoricPrice(	hierHead,
										refDateTime,
										extPosPtr,
										valRuleId,
										valRuleEltTab[i],
										instrPtr,
										pricePtr);
		return(ret);
	}


    /* REF4756 - RAK - 000523 */
    /* Eval rule of valuation rule element is "None" */
    /* and instrument is theoric and licensee is valid */
    /* RECALL FIN_InstrPrice with AA_DEF_VAL_RULE */
    if	((i != valRuleEltNbr) &&
         (GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == EvalRule_None) &&
         (isTheoriticalInstrument == TRUE)  &&
         (isAALicenseFlg==TRUE) &&
         (valRuleId!=defaultValuationRuleId))
    {
        ret	=	FIN_InstrPrice(	instrId,
								inputInstrPtr,
								refDateTime,
								instrPriceArg,
								defaultValuationRuleId,	/*	Force the default valuation rule identifier	*/
								priceArgStp,
								inputValRulePtr,
								extPosPtr,
								hierHead,
								pricePtr,
								excludeAdjustedPriceFlg); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
		return(ret);
    }

	/* if valuation rule nature is instrument lending call specific procedure */
	if (GET_ENUM(valRulePtr, A_ValRule_NatEn) == ValRuleNat_InstrLending)
	{
	    /* REF2994 - RAK - 981109 - verify instrPriceArg */
        ret = FIN_InstrLending(refDateTime, valRuleId, valRuleEltTab[i],
                               (instrPriceArg == nullptr ? static_cast<ENUM_T>(0): GET_ENUM(instrPriceArg, InstrPrice_Arg_ValRuleCoefNatEn)),
                               extPosPtr, hierHead, pricePtr);
        return(ret);
	}

	/* search the last element in list corresponding to list_id */
	firstRuleElt = i;
	while (i < valRuleEltNbr && GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) == listId)
	    i++;

	lastRuleElt = i;

    /* extract all instrprice for a instrument, only if first rule is Quote */
    if (GET_ENUM(valRuleEltTab[firstRuleElt], A_ValRuleElt_EvalRuleEn) == ValRule_Quote ||
        (GET_ENUM(valRuleEltTab[firstRuleElt], A_ValRuleElt_EvalRuleEn) == ValRule_None &&
         GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Quote))
    {
        FLAG_T allocPriceOk = FALSE;

        FIN_SelectInstrPrice(instrId, refDateTime, FALSE, /* PMSTA06487 - RAK - 080529 */
                             hierHead,
                             &instrPriceTab, &instrPriceNbr, &allocPriceOk);

        if (TRUE == allocPriceOk)
        { // Free all instruments array
            mp.owner(instrPriceTab, instrPriceNbr);
        }
        else
        {   // Free the array
            mp.owner(static_cast<void*>(instrPriceTab));
        }
    }

    int limite = instrPriceNbr;

    /* for each rule, check if one instr price is valid */
    for (i=firstRuleElt; i<lastRuleElt && found == FALSE &&
                         GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) == listId; i++)
    {
        if (GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == ValRule_Quote ||
            (GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == ValRule_None &&
             GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Quote))
        {
            /* check each instr price */
            for (int j=0; j<limite && found == FALSE; j++)
            {
                if (FIN_IsInstrPriceValid(instrPriceTab[j],
                                          valRuleEltTab[i],
                                          instrPtr,
                                          extPosPtr,
                                          instrPriceArg,
										  excludeAdjustedPriceFlg) == TRUE) /* PMSTA-10049 - LJE - 101007 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
                {
			        /* if date priority if false, return the first one else */
			        /* continue to search a other can be valid and more recent */
                    if (datePriority == FALSE)
                    {
                        bestValRuleElt = i;
                        bestPrice = j;
                        found = TRUE;
                    }
                    else
                    {
			            /* if the first element is valid stop searching, */
			            /* there is no price more recent */
                        if (j == 0)
                        {
                            /* REF1915 - DDV - 980430 */
                            /* REF5573 - SSO - 010110 fixed comparison */
				            if (bestPrice != -1 &&
                                DATETIME_CMP(GET_DATETIME(instrPriceTab[j], A_InstrPrice_QuoteDate),
                                             GET_DATETIME(instrPriceTab[bestPrice], A_InstrPrice_QuoteDate)) > 0)
                            {
                                bestValRuleElt = i;
                                bestPrice = j;
                            }
				            else if (bestPrice == -1)
                            {
                                bestValRuleElt = i;
                                bestPrice = j;
                            }
                            found = TRUE;
                        }
                        else
                        {
                            /* REF1915 - DDV - 980430 */
                            /* REF5573 - SSO - 010110 fixed comparison */
				            if (bestPrice != -1 &&
                                DATETIME_CMP(GET_DATETIME(instrPriceTab[j], A_InstrPrice_QuoteDate),
                                             GET_DATETIME(instrPriceTab[bestPrice], A_InstrPrice_QuoteDate)) > 0)
                            {
                                bestValRuleElt = i;
                                bestPrice = j;
                                limite = j;
                            }
				            else if (bestPrice == -1)
                            {
                                bestValRuleElt = i;
                                bestPrice = j;
                                limite = j;
                            }
                        }
                    }
                }
            }
        }
        else
        {
			/* REF4478 - CHU - 000321 */
			if (GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == EvalRule_Linear)
			{
				if (FIN_InstrLinearPrice(hierHead,domainPtr,instrPtr,extPosPtr,
										 valRuleEltTab[i],pricePtr,refDateTime)==RET_SUCCEED)
				{
					bestValRuleElt = i;
					bestPrice = -1;
					notQuote = TRUE;
					found = TRUE;
				}
			}
			else
			{
				bestValRuleElt = i;
				notQuote = TRUE;
				found = TRUE;
			}
        }
    }

	/* if nothing is found return RET_FIN_INFO_NOPRICE */
    if (found == FALSE && bestPrice == -1)
	{
        /*valRuleUsed = ValRule_Quote0;*/ /* Error no price found => return NULL not Quote0 */
	    return(RET_FIN_INFO_NOPRICE);
	}
	else if (notQuote == TRUE && bestPrice == -1)
    {
	    if (GET_ENUM(valRuleEltTab[i-1], A_ValRuleElt_EvalRuleEn) == ValRule_None)
            valRuleUsed = GET_ENUM(instrPtr, A_Instr_ValRuleEn);
        else
            valRuleUsed = GET_ENUM(valRuleEltTab[i-1], A_ValRuleElt_EvalRuleEn);
    }
	else
        valRuleUsed = ValRule_Quote;

	if (valRuleUsed != EvalRule_Linear)
	{
		if (bestPrice == -1 || instrPriceTab == NULLDYNSTPTR)
			ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, NULLDYNST,
            static_cast<VALRULE_ENUM> (valRuleUsed), /* REF7264 - CSY - 020130 */
            NULL, pricePtr, hierHead);
		else
			ret = FIN_SetInstrPrice(instrPtr, extPosPtr, refDateTime, instrPriceTab[bestPrice],
				                    static_cast<VALRULE_ENUM> (valRuleUsed), /* REF7264 - CSY - 020130 */
                                    NULL, pricePtr, hierHead);
	}

	COPY_DYNFLD(pricePtr, A_InstrPrice, A_InstrPrice_ValRuleId, valRulePtr, A_ValRule, A_ValRule_Id);

	if (bestValRuleElt != -1)
	    COPY_DYNFLD(pricePtr, A_InstrPrice, A_InstrPrice_ValRuleEltId,
                        valRuleEltTab[bestValRuleElt], A_ValRuleElt, A_ValRuleElt_Id);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetValRuleIdInDomPPSPtf()
**
**  Description :   Get valuation rule identifier in domain, pps or portfolio.
**		            Could return 0.
**
**  Arguments   :   domainPtr	    pointer on domain
**		            extPosPtr	    pointer on extended position (could be NULLDYNST)
**		            hierHead	    hierarchy header pointer
**		            valRuleId	    pointer on valuation rule identifier
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF1055 - RAK - 991231
**
*************************************************************************/
EXTERN RET_CODE	FIN_GetValRuleIdInDomPPSPtf(DBA_DYNFLD_STP	 domainPtr,
					                       DBA_DYNFLD_STP	 extPosPtr,
					                       DBA_HIER_HEAD_STP hierHead,
					                       ID_T		         *valRuleId)
{
    RET_CODE	    ret=RET_SUCCEED;
    DBA_DYNFLD_STP  sPtfPosSet=NULLDYNST, ptfPosSetPtr=NULLDYNST;
    DBA_DYNFLD_STP  ptfPtr=NULLDYNST;
    FLAG_T	        allocFlg=FALSE;

    *valRuleId = 0; /* REF9759 - DDV - 040202 - initialisation */

    /* Get domain valuation rule */
    if (IS_NULLFLD(domainPtr, A_Domain_QuoteValRuleId) == FALSE)
	    *valRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId);

    /* if no valuatrion rule in domain look for it in PPS */
    if (*valRuleId <= 0 && extPosPtr != NULLDYNST)
    {
	    if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == FALSE &&
	        GET_ID(extPosPtr, ExtPos_PtfPosSetId) != 0)
	    {
		    if ((sPtfPosSet = ALLOC_DYNST(S_PtfPosSet)) == NULLDYNST)
		    {
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    if ((ptfPosSetPtr = ALLOC_DYNST(A_PtfPosSet)) == NULLDYNST)
		    {
		        FREE_DYNST(sPtfPosSet, S_PtfPosSet);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    COPY_DYNFLD(sPtfPosSet, S_PtfPosSet, S_PtfPosSet_Id,
		                extPosPtr, ExtPos, ExtPos_PtfPosSetId);

		    if (DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, sPtfPosSet,
		                 A_PtfPosSet, &ptfPosSetPtr,
		                 UNUSED, UNUSED, UNUSED) != TRUE)
		    {
			    FREE_DYNST(sPtfPosSet, S_PtfPosSet);
			    FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
			    return(RET_DBA_ERR_NODATA);
		    }

		    *valRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_QuoteValRuleId);

		    FREE_DYNST(sPtfPosSet, S_PtfPosSet);
		    FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
	    }
	}

    /* if no valuatrion rule in domain look for it in Portfolio */
    if (*valRuleId <= 0 && extPosPtr != NULLDYNST)
    {
	    if (GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Ptf_Ext) != NULL)
	    {
		ptfPtr = *(GET_EXTENSION_PTR(extPosPtr,ExtPos_A_Ptf_Ext));
		*valRuleId = GET_ID(ptfPtr, A_Ptf_QuoteValRuleId);
	    }
	    else if (GET_ID(extPosPtr,ExtPos_PtfId) > 0)
	    {
		if (DBA_GetPtfById(GET_ID(extPosPtr, ExtPos_PtfId), FALSE, &allocFlg,
	                           &ptfPtr, hierHead, UNUSED,UNUSED) != RET_SUCCEED)
		{
			return(RET_DBA_ERR_NODATA);
		}

		*valRuleId = GET_ID(ptfPtr, A_Ptf_QuoteValRuleId);

		if (allocFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
	    }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_LoadValRuleAndHist()
**
**  Description :   Load valuation rule (if necessary) and valuation rule history
**		            according to received valRuleId and date.
**
**  Arguments   :   valRuleId	    valuation rule identifier
**                  refDateTime	    reference date
**                  inputValRulePtr inputed valuation rule structure pointer
**		            allocValRuleOk  will be set to TRUE if valuation rule struct is allocated
**		            valRulePtr	    pointer on valuation rule struct. pointer
**		            valRUleHIstPtr  pointer on valuation rule history struct. pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF1055 - RAK - 991231
**
*************************************************************************/
EXTERN RET_CODE	FIN_LoadValRuleAndHist(	ID_T		    valRuleId,
				                        DATETIME_T	    refDateTime,
					                    DBA_DYNFLD_STP	inputValRulePtr,
					                    FLAG_T		    *allocValRuleOk,
					                    DBA_DYNFLD_STP	*valRulePtr,
					                    DBA_DYNFLD_STP	*valRuleHistPtr)
{
    DBA_DYNFLD_STP  getValRule=NULLDYNST;
    DBA_DYNFLD_STP  admArgPtr=NULLDYNST;
    RET_CODE	    ret=RET_SUCCEED;

    *allocValRuleOk	= FALSE;
    *valRulePtr		= NULLDYNST;
    *valRuleHistPtr	= NULLDYNST;

    if (inputValRulePtr != NULLDYNST)
    {
	    *valRulePtr = inputValRulePtr;
    }
    else
    {
	    if ((getValRule = ALLOC_DYNST(S_ValRule)) == NULLDYNST)
	        MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (((*valRulePtr) = ALLOC_DYNST(A_ValRule)) == NULLDYNST)
	    {
	        FREE_DYNST(getValRule, S_ValRule);
	        MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_ID(getValRule, S_ValRule_Id, valRuleId);
	    if (DBA_Get2(ValRule, UNUSED, S_ValRule, getValRule, A_ValRule, valRulePtr,
		         UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	    {
	        SYSNAME_T entSqlName;
	        strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRule));
	        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			     entSqlName, GET_ID(getValRule, S_ValRule_Id));
	        FREE_DYNST(getValRule, S_ValRule);
	        FREE_DYNST((*valRulePtr), A_ValRule);
	        return(RET_DBA_ERR_NODATA);
	    }

	    FREE_DYNST(getValRule, S_ValRule);
	    *allocValRuleOk = TRUE;
    }

    /* Get valuation History record corresponding qith rule and date */
    if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
	    if ((*allocValRuleOk) == TRUE) {FREE_DYNST((*valRulePtr), A_ValRule);}
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (((*valRuleHistPtr) = ALLOC_DYNST(A_ValRuleHist)) == NULLDYNST)
    {
	    if ((*allocValRuleOk) == TRUE) {FREE_DYNST((*valRulePtr), A_ValRule);}
	    FREE_DYNST(admArgPtr, Adm_Arg);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_ID(admArgPtr,	    Adm_Arg_Id,	    valRuleId);
    SET_DATETIME(admArgPtr, Adm_Arg_Date,   refDateTime);

    if (DBA_Get2(ValRuleHist, DBA_GET_LAST, Adm_Arg, admArgPtr, A_ValRuleHist, valRuleHistPtr, /* DDV - 180918 - Add role to avoid confusion with BK */
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
    {
	    SYSNAME_T entSqlName;
	    strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleHist));
	    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		         entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
	    if ((*allocValRuleOk) == TRUE) {FREE_DYNST((*valRulePtr), A_ValRule);}
	    FREE_DYNST(admArgPtr, Adm_Arg);
	    FREE_DYNST((*valRuleHistPtr), A_ValRuleHist);
	    return(RET_DBA_ERR_NODATA);
    }
    FREE_DYNST(admArgPtr, Adm_Arg);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_LoadValRuleElt()
**
**  Description :   Load valuation rule elements
**		            according to received valuation rule history.
**
**  Arguments   :   valRUleHistPtr  pointer on valuation rule history struct. pointer
**		            valRuleELtNbr   pointer on valuation rule elements number
**		            valRuleEltTab   pointer on valuation rule elements table
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF1055 - RAK - 991231
**
*************************************************************************/
EXTERN	RET_CODE    FIN_LoadValRuleElt( DBA_DYNFLD_STP  valRuleHistPtr,
				                        int	            *valRuleEltNbr,
				                        DBA_DYNFLD_STP  **valRuleEltTab)
{
    DBA_DYNFLD_STP  admArgPtr=NULLDYNST;
    RET_CODE	    ret=RET_SUCCEED;

    *valRuleEltNbr = 0;
    *valRuleEltTab = NULLDYNSTPTR;

    if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(valRuleHistPtr, A_ValRuleHist_Id));

    if ((DBA_Select2(ValRuleElt, UNUSED, Adm_Arg, admArgPtr,
                     A_ValRuleElt, valRuleEltTab, UNUSED, UNUSED,
                     valRuleEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
    {
	    SYSNAME_T entSqlName;
	    strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleElt));
	    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		            entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
	    FREE_DYNST(admArgPtr, Adm_Arg);
	    return(RET_DBA_ERR_NODATA);
    }

    FREE_DYNST(admArgPtr, Adm_Arg);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrPriceClassify()
**
**  Description :   Classify instrument according to received parameters.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF1055 - RAK - 991231
**
*************************************************************************/
STATIC RET_CODE	FIN_InstrPriceClassify(OBJECT_ENUM          entity,
				                       DBA_DYNFLD_STP       instrPtr,
				                       ID_T                 instrId,
				                       DBA_DYNFLD_STP       extPosPtr,
				                       DBA_DYNFLD_STP       valRuleHistPtr,
				                       DBA_HIER_HEAD_STP    hierHead,
				                       ID_T                *listId,
                                       DATETIME_T           refDateTime,
				                       DBA_DYNFLD_STP       domainPtr)
{
    DBA_DYNFLD_STP  classifResult=NULLDYNST;
    RET_CODE	    ret=RET_SUCCEED;

    if ((classifResult = ALLOC_DYNST(A_ClassifCompo)) == NULLDYNST)
    {
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Classify the entity define in valRuleHistory */
    if (entity == Instr)
    {
	/*	DEV1055 - CSA - 13101999
		If recieved instrument is a swap or a forex swap leg,
		we need to classify it like  swaps or a forex swaps instruments.
		So, we call FIN_Classify() with parent instrument instead.
	*/

	/*	Local variables definition	*/
	LEGNAT_ENUM	instrNat;
	ID_T		instrParId;

    DICT_T      instrDictId; /* PMSTA-10070 - LJE - 101004 */
    DBA_GetDictId(Instr, &instrDictId); /* PMSTA-10070 - LJE - 101004 */

	/*	Get the nature of the instrument	*/
	instrNat	=	FIN_InstrGetNatureLeg(instrPtr,hierHead);

	/*	Call FIN_Classify with the goods parameters	*/
	switch(instrNat)
	{
	case	LegNat_Swap:
	case	LegNat_ForexSwap:
		instrParId	=	GET_ID(instrPtr,A_Instr_ParentInstrId);
		FIN_Classify(instrDictId, /* PMSTA-10070 - LJE - 101004 */
                     instrParId,
                     GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       			     NULL,
                     classifResult,
                     NULL,
                     hierHead,
                     &refDateTime,
                     domainPtr,
                     FALSE,
                     TRUE,
                     UNUSED,
                     UNUSED);
		break;

	default:
		/* REF1108 - Use received instrId instead of A_Instr_Id */
		FIN_Classify(instrDictId, /* PMSTA-10070 - LJE - 101004 */
                     instrId,
                     GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       			     instrPtr,
                     classifResult,
                     NULL,
                     hierHead,
                     &refDateTime,
                     domainPtr,
                     FALSE,
                     TRUE,
                     UNUSED,
                     UNUSED); /* no optimisation */
		break;
	}
    }
    else if (entity == EPos)
    {
        DICT_T  ePosDictId;
        DBA_GetDictId(EPos, &ePosDictId); /* PMSTA-10070 - LJE - 101004 */

	    FIN_Classify(ePosDictId, GET_ID(extPosPtr, ExtPos_Id), /* PMSTA-10070 - LJE - 101004 */
		             GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       		         extPosPtr,
                     classifResult,
                     NULL,
                     hierHead,
                     &refDateTime,
                     domainPtr,
                     FALSE,
                     TRUE,
                     UNUSED,
                     UNUSED); /* no optimisation */
    }

    /* If no classif is found, listId will be 0 */
    *listId = GET_ID(classifResult, A_ClassifCompo_ListId);
    FREE_DYNST(classifResult, A_ClassifCompo);
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrRefInstrPrice()
**
**  Description :   Evaluate a instrument depending on a reference instrument.
**
**  Arguments   :   instrPtr    instrument pointer
**                  refDateTime reference date
**                  pricePtr    price pointer, will be updated
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   REF1108 - RAK - 980105
**  Modif.	    :   REF3388 - RAK - 990303
**
*************************************************************************/
STATIC RET_CODE FIN_InstrRefInstrPrice( DBA_DYNFLD_STP      instrPtr,
		                                DBA_DYNFLD_STP      extPosPtr,
			                            DATETIME_T          refDateTime,
			                            DBA_DYNFLD_STP      pricePtr,
			                            DBA_HIER_HEAD_STP   hierHead)
{
	DBA_DYNFLD_STP refPricePtr=NULLDYNST, instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
	PRICE_T        price = 0.0, quote = 0.0;
	ID_T           instrId = (ID_T)0;
	RET_CODE       ret = RET_SUCCEED;

	if ((refPricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* REF1108 - If reference instrument don't exist, return RET_GEN_ERR_INVARG */
	if (IS_NULLFLD(instrPtr, A_Instr_RefInstrId) == TRUE)
		ret = RET_GEN_ERR_INVARG;
	else
		/* Compute reference instrument price */
		ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_RefInstrId), NULLDYNST,
		                     refDateTime, NULLDYNST, 0, NULL, NULLDYNST,
                             extPosPtr, hierHead, refPricePtr, FALSE);		/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

	if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
	{
		/* REF3388 - Use Quote instead of Price */
		quote = GET_PRICE(refPricePtr, A_InstrPrice_Quote);

		/* Add margin */
		if (refDateTime.date <= GET_DATE(instrPtr, A_Instr_LastMargDate))
		{
			quote += GET_NUMBER(instrPtr, A_Instr_LastMargin);
		}
		else
		{
			if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
				MSG_RETURN(RET_MEM_ERR_ALLOC);

	        if (GET_ID(instrPtr, A_Instr_Id) < 0)
			    instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	        else
			    instrId = GET_ID(instrPtr, A_Instr_Id);

			/* ------------------------------------------------- */
			/* DVP051 : new get on InstrChrono data (RAK 960509) */
			/* ret = DBA_GetInstrChrono(instrId, refDateTime,
				  ChronoNat_Marg, TimeDim_Last, TRUE, instrChrono); */
			if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
			{
				FREE_DYNST(instrChrono, A_InstrChrono);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
			SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
			SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_Marg);
			SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

			ret = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);

			FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
			/* DVP051 : END (RAK 960509) */
			/* ------------------------- */

			if (ret == RET_SUCCEED)
			{
				/*
				** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
				** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT.
				*/
			   quote += GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
			}
			/*
			else
			{
				FREE_DYNST(refPricePtr, A_InstrPrice);
				return(ret);
			}
			*/
			FREE_DYNST(instrChrono, A_InstrChrono);
		}

		/* REF3388 - Update Quote instead of Price */
		quote = CAST_PRICE(quote);
		SET_PRICE(pricePtr, A_InstrPrice_Quote, quote);

		/* REF3388 - Call FIN_QuoteToPrice with instrument price calculation rule */
		/* FIN_PriceToQuote(PriceCalcRule_None, GET_ID(instrPtr, A_Instr_Id), instrPtr,
				 refDateTime, NULL, price, &quote, hierHead);
		SET_PRICE(pricePtr, A_InstrPrice_Quote, quote); */

		FIN_QuoteToPrice((PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn),
				         GET_ID(instrPtr, A_Instr_Id), instrPtr,
				         refDateTime, NULL, quote, &price, hierHead);

        SET_PRICE(pricePtr,    A_InstrPrice_Price,             price);
		SET_ID(pricePtr,        A_InstrPrice_InstrId,           GET_ID(instrPtr, A_Instr_Id));
		SET_ID(pricePtr,        A_InstrPrice_CurrId,            GET_ID(refPricePtr, A_InstrPrice_CurrId));
		SET_ID(pricePtr,        A_InstrPrice_TpId,              GET_ID(refPricePtr, A_InstrPrice_TpId));
		SET_ID(pricePtr,        A_InstrPrice_ThirdId,           GET_ID(refPricePtr, A_InstrPrice_ThirdId));
		SET_ID(pricePtr,        A_InstrPrice_TermTpId,          GET_ID(refPricePtr, A_InstrPrice_TermTpId));
		SET_DATETIME(pricePtr,  A_InstrPrice_QuoteDate,         refDateTime);
		SET_FLAG(pricePtr,      A_InstrPrice_DailyDfltFlg,      GET_FLAG(refPricePtr, A_InstrPrice_DailyDfltFlg));
		SET_ENUM(pricePtr,      A_InstrPrice_PriceCalcRuleEn,   GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
		SET_FLAG(pricePtr,      A_InstrPrice_UnicityFlg,        GET_FLAG(refPricePtr, A_InstrPrice_UnicityFlg));
		SET_NUMBER(pricePtr,    A_InstrPrice_ActuRate,          GET_NUMBER(refPricePtr, A_InstrPrice_ActuRate));

		FREE_DYNST(refPricePtr, A_InstrPrice);
		return(RET_SUCCEED);
	}
	else
	{
		FREE_DYNST(refPricePtr, A_InstrPrice);
		return(ret);
	}
}

/************************************************************************
**
**  Function    :   FIN_InstrTheoPrice()
**
**  Description :   Evaluate instrument via theoritical price.
**
**  Arguments   :   instrPtr    instrument structure pointer
**                  refDateTime reference date
**                  pricePtr    pointer on price structure to fill
**
**  Return      :   RET_SUCCEED or error code, pricePtr is updated
**
**  Modif	:   BUG286 - RAK - 961213
**  Modif	:   DVP440 - RAK - 970428
**  Modif	:   DVP561 - RAK - 970826
**  Modif	:   REF881 - RAK - 971106
**  Modif	:   REF1048 - RAK - 971205
**  Modif	:   REF1100 - RAK - 971230 - suppressed 16/03/98 (RAK/IRM)
**  Modif	:   REF53.1 - RAK - 980408
**  Modif	:   REF2852 - RAK - 990111
**              REF9082 - TEB - 030619
**
*************************************************************************/

STATIC RET_CODE FIN_InstrTheoPrice(DBA_DYNFLD_STP    instrPtr,
				                   DATETIME_T        refDateTime,
			  	                   FIN_PRICEARG_STP  priceArgStp,
				                   DBA_DYNFLD_STP    pricePtr,
				                   DBA_DYNFLD_STP    posPtr,
                                   DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE	    ret = RET_SUCCEED;
    DBA_DYNFLD_STP  advArgStp   = NULLDYNST,        /* REF9082 - TEB - 030619 */
                    advAStp	    = NULLDYNST;        /* REF9082 - TEB - 030619 */
	double          pricingModel;                   /* REF9082 - TEB - 030619 */
	PRICE_T	    price=0.0, quote=0.0;	/* REF881 */

	switch ((INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn))
	{
	case InstrNat_Option :
        /* REF9082 - TEB - 030619 - Begin */
        /* Replacement of Tech call with Simcorp call */
        if (instrPtr == NULLDYNST)
		    return(RET_GEN_INFO_NODATA);

	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
		    return(RET_SUCCEED);

        /* Set the instrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the pricing model */
	    if (IS_NULLFLD(instrPtr, A_Instr_DefModelEn) == TRUE  ||
		    GET_ENUM(instrPtr, A_Instr_DefModelEn)   == OptModel_None)
	    {
		    GEN_GetApplInfo(ApplOptPricingModel, &pricingModel);
		    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, pricingModel);
	    }
	    else
	    {
		    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, GET_ENUM(instrPtr, A_Instr_DefModelEn));
	    }

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, refDateTime.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

	    if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    return(RET_SUCCEED);
	    }

	    /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_OPT_PRICE);

	    /* Execute the price computation */
        if (SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
				                   NULL, hierHead, advAStp) != RET_SUCCEED)
        {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    FREE_DYNST(advAStp,   A_AdvA);
		    return(RET_SUCCEED);
	    }

        if (IS_NULLFLD(advAStp, A_AdvA_Price)==FALSE)
            price = GET_PRICE(advAStp, A_AdvA_Price);

        FREE_DYNST(advArgStp, AdvA_Arg);
	    FREE_DYNST(advAStp,   A_AdvA);
        /* REF9082 - TEB - 030619 - End */

		if (ret == RET_SUCCEED)
		{
		    SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(instrPtr, A_Instr_Id));
		    SET_ID(pricePtr, A_InstrPrice_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

		    SET_ENUM(pricePtr, A_InstrPrice_PriceCalcRuleEn,
			    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

		    SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		    SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		    SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		    SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,    refDateTime);
		    SET_FLAG(pricePtr,     A_InstrPrice_DailyDfltFlg, FALSE);
		    SET_FLAG(pricePtr,     A_InstrPrice_UnicityFlg,   FALSE);

		    FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(pricePtr, A_InstrPrice_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
				             GET_ID(instrPtr, A_Instr_Id), instrPtr, refDateTime,
				             NULL, price, &quote, hierHead);

		    SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
		    SET_PRICE(pricePtr, A_InstrPrice_Quote, CAST_PRICE(quote)); /* REF3288 - SSO - 990205 */
		}
		else
		{
		    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			    MSG_SendMesg(ret, 0, FILEINFO);
		}
		break;

	/* Treat in function FIN_PosPrice() on account of position */
	/* informations are necessary (price and spot price)       */
	case InstrNat_Forward :
		ret = FIN_ForwardTheoPrice( instrPtr,
                                    refDateTime,
                                    priceArgStp,
                                    posPtr,
                                    pricePtr,
                                    hierHead);
		break;

    /* REF4597 - RAK - 000509 */
    /* Don't compute price for theoric forex_swap if we don't have AdAM licencee */
    /* case InstrNat_ForexSwaps  : */				/* DVP510 - XDI - 970624 */
    /*     ret = FIN_ForexSwapTheoPrice(instrPtr,
                                      refDateTime,
                                      posPtr,
                                      pricePtr,
                                      hierHead);
         break;
    */

	default :
        /* REF4597 - RAK - 000501 */
        SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(instrPtr, A_Instr_Id));
		SET_ID(pricePtr, A_InstrPrice_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

		SET_ENUM(pricePtr, A_InstrPrice_PriceCalcRuleEn,
			GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,    refDateTime);
		SET_FLAG(pricePtr,     A_InstrPrice_DailyDfltFlg, FALSE);
		SET_FLAG(pricePtr,     A_InstrPrice_UnicityFlg,   FALSE);

		SET_PRICE(pricePtr, A_InstrPrice_Price, 0.0);
		SET_PRICE(pricePtr, A_InstrPrice_Quote, 0.0);
		ret = RET_SUCCEED;
        break;
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_IsInstrPriceValid()
**
**  Description :   Check if instrument price is valid for a valuation rule
**
**  Arguments   :   instrPricePtr instrument price structure pointer
**                  vatRuleEltPtr valuation rule element structure pointer
**                  instrPtr	  instrument structure pointer
**                  extPosPtr	  extended position structure pointer
**
**  Return      :   TRUE if the instrument price is valid and FALSE if not
**
**  Modif       :   DVP344 - XDI - 970213
**
*************************************************************************/
STATIC RET_CODE FIN_IsInstrPriceValid( DBA_DYNFLD_STP instrPricePtr,
		                               DBA_DYNFLD_STP valRuleEltPtr,
		                               DBA_DYNFLD_STP instrPtr,
		                               DBA_DYNFLD_STP extPosPtr,
                                       DBA_DYNFLD_STP instrPriceArg,
									   FLAG_T         excludeAdjustedPriceFlg) /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
{
	DBA_DYNFLD_STP sTpPtr=NULLDYNST, aTpPtr=NULLDYNST;
	SMALLINT_T       adjPriceTypeRank=0;
	SMALLINT_T       priceTypeRank=0;

	GEN_GetApplInfo(ApplAdjustedPriceTypeRank, &adjPriceTypeRank);

	/* If needed, load tp to know its rank. */
	if (GET_ID(instrPricePtr, A_InstrPrice_TpId) != 0 &&
        ((excludeAdjustedPriceFlg == TRUE && adjPriceTypeRank != 0) || IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_TypeId) == TRUE))
	{
        if ((sTpPtr = ALLOC_DYNST(S_Tp)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((aTpPtr = ALLOC_DYNST(A_Tp)) == NULLDYNST)
        {
            FREE_DYNST(sTpPtr, S_Tp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(sTpPtr, S_Tp_Id, GET_ID(instrPricePtr, A_InstrPrice_TpId)); /* PMSTA-10049 - LJE - 101007 */

        if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(sTpPtr, S_Tp_Id));
            FREE_DYNST(sTpPtr, S_Tp);
            FREE_DYNST(aTpPtr, A_Tp);
            return(RET_DBA_ERR_NODATA);
        }
        FREE_DYNST(sTpPtr, S_Tp);

        if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE)
			priceTypeRank = GET_SMALLINT(aTpPtr, A_Tp_Rank);

        FREE_DYNST(aTpPtr, A_Tp);
	}

    /* PMSTA14876 - DDV - 120911 - Return FALSE for adjusted price when they must be excluded */
	if (GET_ID(instrPricePtr, A_InstrPrice_TpId) != 0 &&
        excludeAdjustedPriceFlg == TRUE && adjPriceTypeRank != 0 &&
		adjPriceTypeRank == priceTypeRank)
	{
		return(FALSE);
	}

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_TypeId) == TRUE)
	{
        if (GET_ID(instrPricePtr, A_InstrPrice_TpId) != 0) /* PMSTA-10049 - LJE - 101007 */
        {

            if (priceTypeRank == 0 ||
                /* PMSTA-10049 - LJE - 101007 */
                (instrPriceArg != NULL &&
                 IS_NULLFLD(instrPriceArg, InstrPrice_Arg_AdjTypeRank) == FALSE &&
                 priceTypeRank == GET_SMALLINT(instrPriceArg, InstrPrice_Arg_AdjTypeRank)))
            {
                return(FALSE);
            }
	    }
	}
	else if (GET_ID(instrPricePtr, A_InstrPrice_TpId) !=
	         GET_ID(valRuleEltPtr, A_ValRuleElt_TypeId))
		return(FALSE);

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_MktThirdId) == TRUE)
	{
		switch(GET_ENUM(valRuleEltPtr, A_ValRuleElt_PriceMktRuleEn))
		{
	    case PriceMktRule_Instrument:
			if (GET_ID(instrPricePtr, A_InstrPrice_MktThirdId) !=
                GET_ID(instrPtr, A_Instr_MktThirdId))
				return(FALSE);
			break;
		}
	}
	else if (GET_ID(instrPricePtr, A_InstrPrice_MktThirdId) !=
             GET_ID(valRuleEltPtr, A_ValRuleElt_MktThirdId))
        return(FALSE);

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_ProviderThirdId) == TRUE)
	{
		switch(GET_ENUM(valRuleEltPtr, A_ValRuleElt_PriceProviderRuleEn))
		{
		case PriceProvRule_Instrument:
			if (GET_ID(instrPricePtr, A_InstrPrice_ThirdId) !=
                GET_ID(instrPtr, A_Instr_ProviderThirdId))
				return(FALSE);
			break;
		}
	}
	else if (GET_ID(instrPricePtr, A_InstrPrice_ThirdId) !=
             GET_ID(valRuleEltPtr, A_ValRuleElt_ProviderThirdId))
			return(FALSE);

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_CurrId) == TRUE)
	{
		switch(GET_ENUM(valRuleEltPtr, A_ValRuleElt_PriceCurrRuleEn))
		{
		case PriceCurrRule_Position:
			if (extPosPtr != NULLDYNST &&
	            GET_ID(instrPricePtr, A_InstrPrice_CurrId) !=
                GET_ID(extPosPtr, ExtPos_PosCurrId))
				return(FALSE);
			break;
		case PriceCurrRule_Instrument:
		    if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) !=
                GET_ID(instrPtr, A_Instr_RefCurrId))
			    return(FALSE);
		    break;
		}
	}
	else if (GET_ID(instrPricePtr, A_InstrPrice_CurrId) !=
             GET_ID(valRuleEltPtr, A_ValRuleElt_CurrId))
			return(FALSE);

    /* Check optional argument "business entity rule" */
    if (GEN_IsMultiEntity())
    {
        FIELD_IDX_T     busEntityFldIdx = INVALID_FLD;

        /* set the owner_business_entity_id field index */
        DICT_ENTITY_STP instrPrice = DBA_GetDictEntitySt(InstrPrice);
        if (instrPrice != nullptr && instrPrice->ownerBusinessEntAttrStp != nullptr &&
            (busEntityFldIdx = instrPrice->ownerBusinessEntAttrStp->progN) != INVALID_FLD)
        {
            ID_T busEntitiyId = ZERO_ID;

	        switch(GET_ENUM(valRuleEltPtr, A_ValRuleElt_BusEntityRuleEn))
	        {
		        case BusEntityRule_ConnectedBE:
                    busEntitiyId = SYS_GetThreadCurrBusinessEntityId();
			        break;
		        case BusEntityRule_Master:
                    busEntitiyId = EV_MasterBusinessEntityId;
		            break;
	        }

            if (busEntitiyId != ZERO_ID &&
                GET_ID(instrPricePtr, busEntityFldIdx) != busEntitiyId)
            {
			    return(FALSE);
            }
        }
    }

	return(TRUE);
}

/************************************************************************
**
**  Function    :   FIN_PosPrice()
**
**  Description :   Compute position price at receive reference date depending
**                  on quotation retrieval method and instrument data.
**
**  Arguments   :   posPtr        position structure pointer
**                  inputInstrPtr pointer on instrument or NULLDYNST
**                  refDateTime   reference date (and time)
**                  prPtr         price structure pointer
**
**  Return      :   RET_SUCCED, RET_FIN_INFO_NOPRICE or error code
**
**  Modif	    :   REF3030 - RAK - 981118
**					REF7925 - TEB - 060712
**
*************************************************************************/
RET_CODE FIN_PosPrice(DBA_DYNFLD_STP    posPtr,
                      DBA_DYNFLD_STP    inputInstrPtr,
		              DATETIME_T        refDateTime,
		              FIN_PRICEARG_STP  priceArgStp,
		              DBA_DYNFLD_STP    prPtr,
                      DBA_DYNFLD_STP    domainPtr,
		              DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP   instrPtr=NULLDYNST, genInstr=NULLDYNST;
    RET_CODE         ret = RET_SUCCEED;
    FLAG_T           allocInstrOk;
    ID_T             instrId;

	/* REF3030
	FIN_PRICEARG_ST	 priceArgSt;
	memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST)); */

    /* Get position instrument */
	if (inputInstrPtr == NULLDYNST)
    {
		if (GET_ID(posPtr, ExtPos_InstrId) > 0)
		{
            instrId = GET_ID(posPtr, ExtPos_InstrId);
		}
		else
		{
		    /* DVP172 */
		    genInstr = NULLDYNST;
		    if (GET_EXTENSION_PTR(posPtr, ExtPos_A_Instr_Ext) == NULL ||
			(genInstr = *(GET_EXTENSION_PTR(posPtr, ExtPos_A_Instr_Ext))) == NULLDYNST)
		    {
			    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_PosPrice", ExtPos_A_Instr_Ext);
			    return(RET_DBA_ERR_HIER);
		    }

            instrId=GET_ID(genInstr, A_Instr_ParentInstrId);
		}

        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocInstrOk,
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, instrId);
			return(RET_DBA_ERR_NODATA);
        }   /* ?? */
    }
    else
    {
		instrPtr = inputInstrPtr;
        allocInstrOk = FALSE;
    }

	/* DVP440 - RAK - 970428 */
	if (posPtr != NULLDYNST)
	{ priceArgStp->costQuote = GET_PRICE(posPtr, ExtPos_Quote); }

    /* REF3348 - RAK - 000214 */
    /* In case of allocate order, search in ExtStratElt */
    /* if a current price isn't specified.              */
    ret = FIN_PosPriceAllocOrder(refDateTime, instrPtr, domainPtr, hierHead, prPtr);

    if (ret != RET_FIN_INFO_NOPRICE)
    {
        if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        return(ret);
    }

    /* REF1055 - RAK - 000214 - Theoretical price is generate in FIN_InstrPrice() */
    if (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Discounted)
    {
        ret = FIN_DiscountedInstrPrice(posPtr, instrPtr, refDateTime, prPtr, hierHead);

        if (allocInstrOk == TRUE)
            FREE_DYNST(instrPtr, A_Instr);
        return(ret);
    }

	/* In case of position price, quoted instruments are evaluate   */
	/* different that usual case, so treat it here, else call usual */
	/* function FIN_InstrPrice()                                    */
	if ((VALRULE_ENUM) GET_ENUM(instrPtr,A_Instr_ValRuleEn)==ValRule_Quote)
	{
		ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr,
				             refDateTime, NULLDYNST, 0, priceArgStp, NULLDYNST,  /* REF3030 */
				             posPtr, hierHead, prPtr, FALSE);		/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

		if (ret != RET_SUCCEED)
		{
			/* If no price found set price to 0 */
			SET_ID(prPtr, A_InstrPrice_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId));

			SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, refDateTime);

			SET_ENUM(prPtr, A_InstrPrice_PriceCalcRuleEn,
			    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

			SET_NULL_ID(prPtr, A_InstrPrice_TpId);
			SET_NULL_ID(prPtr, A_InstrPrice_ThirdId);
			SET_NULL_ID(prPtr, A_InstrPrice_TermTpId);

			/* REF7925 - TEB - 060712 - If no price, don't set to 0 */
			/*
			SET_PRICE(prPtr, A_InstrPrice_Quote, 0.0);
			SET_PRICE(prPtr, A_InstrPrice_Price, 0.0);
			*/
			SET_NULL_FLD(prPtr, A_InstrPrice_Quote);
			SET_NULL_FLD(prPtr, A_InstrPrice_Price);

			ret = RET_FIN_INFO_NOPRICE;
		}
	}
	else
	{
		/* Instrument is already loaded */
		ret = FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), instrPtr,
				             refDateTime, NULLDYNST, 0, priceArgStp, NULLDYNST,  /* REF3030 */
				             posPtr, hierHead, prPtr, FALSE);			/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
	}

    if (allocInstrOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_PosPriceAllocOrder()
**
**  Description :   In case of allocate order, search in ExtStratElt
**                  if a current price isn't specified.
**
**  Arguments   :   refDateTime     reference date (and time)
**                  instrPtr        instrument structure pointer
**                  domainPtr       domain structure pointer (or NULL)
**                  hierHead        hierarchy header pointer
**                  prPtr           price structure pointer
**
**  Return      :   RET_SUCCED, RET_FIN_INFO_NOPRICE or error code
**
**  Creation	:   REF3348 - RAK - 000214
**
*************************************************************************/
STATIC RET_CODE FIN_PosPriceAllocOrder(DATETIME_T        refDateTime,
                                       DBA_DYNFLD_STP    instrPtr,
                                       DBA_DYNFLD_STP    domainPtr,
                                       DBA_HIER_HEAD_STP hierHead,
                                       DBA_DYNFLD_STP    prPtr)
{
    DBA_DYNFLD_ST   ptfIdDynSt;
    int             i, ESENbr=0;
    ID_T            instrId;
    DBA_DYNFLD_STP  *ESETab=NULLDYNSTPTR;
    RET_CODE        ret=RET_SUCCEED;

    if (domainPtr == NULLDYNST && hierHead != NULL)
        domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

    if (domainPtr != NULLDYNST &&
        GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo &&
        GET_ENUM(domainPtr, A_Domain_OrderAllocNatEn) != DomOrderAllocNat_None)
    {
        /* No portfolio identifier for order alloc details */
        memset((&ptfIdDynSt), 0, sizeof(DBA_DYNFLD_ST));

        if (GET_ID(instrPtr, A_Instr_Id) < 0)
        { instrId = GET_ID(instrPtr, A_Instr_ParentInstrId); }
        else
        { instrId = GET_ID(instrPtr, A_Instr_Id); }

	    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, ExtStratElt,
                                                   ExtStratElt_PtfId, ptfIdDynSt, FALSE,
			                                       FIN_FilterAllocOrder, NULLDYNST,
			                                       FIN_CmpESEInstrId, FALSE,
					 	                           &ESENbr, &ESETab)) != RET_SUCCEED)
        {
            /* and compute price */
            return(RET_FIN_INFO_NOPRICE);
        }

        for (i=0; i<ESENbr && GET_ID(ESETab[i], ExtStratElt_InstrId) <= instrId; i++)
        {
            /* price found for instrument */
            if (GET_ID(ESETab[i], ExtStratElt_InstrId) == instrId &&
                IS_NULLFLD(ESETab[i], ExtStratElt_CrtPrice) == FALSE &&
                IS_NULLFLD(ESETab[i], ExtStratElt_CrtQuoteCurrId) == FALSE)
            {
			    SET_ID(prPtr, A_InstrPrice_CurrId,
                    GET_ID(ESETab[i], ExtStratElt_CrtQuoteCurrId));

                SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, refDateTime);

                SET_ENUM(prPtr, A_InstrPrice_PriceCalcRuleEn,
			        GET_ENUM(ESETab[i], ExtStratElt_CrtPriceCalcRuleEn));

                SET_NULL_ID(prPtr, A_InstrPrice_TpId);
			    SET_NULL_ID(prPtr, A_InstrPrice_ThirdId);
			    SET_NULL_ID(prPtr, A_InstrPrice_TermTpId);

			    SET_PRICE(prPtr, A_InstrPrice_Quote,
                    GET_PRICE(ESETab[i], ExtStratElt_CrtQuote));

                SET_PRICE(prPtr, A_InstrPrice_Price,
                    GET_PRICE(ESETab[i], ExtStratElt_CrtPrice));

                FREE(ESETab);
                return(RET_SUCCEED);
            }
        }

        FREE(ESETab);
    }

    /* and compute price */
    return(RET_FIN_INFO_NOPRICE);
}

STATIC int FIN_FilterAllocOrder(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM, DBA_DYNFLD_STP) /* REF7264 - LJE - 020131 */
{
    if (GET_ENUM(dynSt, ExtStratElt_NatEn) == ExtStratEltNat_AllocOrder)
        return(TRUE);
    else
        return(FALSE);
}

STATIC int FIN_CmpESEInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), ExtStratElt_InstrId),
           GET_ID((*ptr2), ExtStratElt_InstrId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_PriceToQuote()
**
**  Description :   Determine quote depending on price and instrument info
**                  and received rule.
**
**  Arguments   :   priceCalcRule   rule to use, by default (value is None)
**                                               use instrument rule
**                  instrId         instrument identifier
**                  inputInstrPtr   instrument pointer or NULLDYNST
**                  date            price date
**                  price           price
**                  *quote          pointer on quote
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP125 - RAK - 960620
**  Modif       :   BUG147 - RAK - 960930
**  Modif       :   BUG169 - RAK - 961008
**  Modif       :   BUG207 - RAK - 961121
**  Modif       :   BUG257 - RAK - 970117
**  Modif       :   DVP431 - RAK - 970414
**  Modif       :   DVP440 - RAK - 970425
**  Modif       :   BUG364 - RAK - 970505
**  Modif       :   BUG438 - RAK - 970707
**  Modif       :   DVP561 - RAK - 970826
**  Modif       :   REF1149 - RAK - 980113
**  Modif       :   REF3477 - RAK - 990322
**                  REF9082 - TEB - 030619 : Replace Tech with Simcorp
**                  REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF10256 - TEB - 040615
**                  REF10461 - TEB - 040804
**                  REF11163 - TEB - 050616
**                  REF11163 - TEB - 050713
**                  PMSTA-14109 - 160512 - PMO : Price calculation error and fusion engine error messages (Data overflow detected while Inserting extended_pos...) when working with instrument chronos #28 (Unpaid %) equal to100
**					PMSTA-32157 - SILPA - 180905 : Signature Portfolio
**
*************************************************************************/
RET_CODE FIN_PriceToQuote(	PRICECALCRULE_ENUM priceCalcRule,
							ID_T               instrId,
							DBA_DYNFLD_STP     inputInstrPtr,
							DATETIME_T         priceDate,
							FIN_PRICEARG_STP   priceArgStp,
							PRICE_T            price,
							PRICE_T            *quote,
							DBA_HIER_HEAD_STP  hierHead)
{
	DBA_DYNFLD_STP  instrPtr=NULLDYNST,
                    advArgStp   = NULLDYNST;    /* REF9082 - TEB - 030619 */
	FLAG_T          allocOk;
	RET_CODE        ret;
	CODE_T	        instrCd;
	ACTUARULE_ENUM  actuaRule;
	ACCRRULE_ENUM   accrRule = AccrRule_None;   /* REF3410 - SSO - 990315 */
	int		        signifDigits;               /* REF3722 - SSO - 000301 */
	NUMBER_T	    n1, n2;
	DATE_T			fusionSwitchDate;  /* REF10256 - TEB - 040615 */
    ID_T	        calendarId = 0;    	/* PMSTA-22396  - SRIDHARA – 160430 */

	if (priceCalcRule != PriceCalcRule_InFineYield && CMP_NUMBER(price, 0.0) == 0) 			/* PMSTA-33034 - RAK - 180924 - Not for InFineYield (price = 1.0) */
	{
		*quote = 0.0;
		return(RET_SUCCEED);
	}

	/* Load instrument if necessary */
	allocOk = FALSE;

	if (inputInstrPtr != NULLDYNST)
		instrPtr = inputInstrPtr;

	if (instrPtr == NULLDYNST &&
	    (priceCalcRule == PriceCalcRule_PartiallyPaidStocks ||
	     priceCalcRule == PriceCalcRule_PartiallyPaidBonds ||	 /* BUG257 - RAK */
	     priceCalcRule == PriceCalcRule_StocksQuotedInPrct ||
	     priceCalcRule == PriceCalcRule_BondsQuotedInUnit ||
	     priceCalcRule == PriceCalcRule_Discounted ||
	     priceCalcRule == PriceCalcRule_InFineYield ||		 /* DVP431 - RAK */
	     priceCalcRule == PriceCalcRule_QuotedWithAI  ||
	     priceCalcRule == PriceCalcRule_QuotedInUnitWithAI ||
	     priceCalcRule == PriceCalcRule_LiborFRA ||
	     priceCalcRule == PriceCalcRule_WithAddOnRate ||		 /* BUG364 - RAK */
	     priceCalcRule == PriceCalcRule_EuroFutureContract ||	 /* DVP440 - RAK */
	     priceCalcRule == PriceCalcRule_PartiallyPaidBondsInUnit ||  /* DVP193 - XDI */
	     priceCalcRule == PriceCalcRule_PartiallyPaidStocksInPrct || /* DVP193 - XDI */
	     priceCalcRule == PriceCalcRule_ActuarialYield ||		 /* BUG257 - RAK */
		 priceCalcRule == PriceCalcRule_OldAustralianFuture      || /* PMSTA15393-JPP-130107*/
		 priceCalcRule == PriceCalcRule_FlexibleAustralianFuture || /* PMSTA15393-JPP-121218*/
			priceCalcRule == PriceCalcRule_QuoteInUnit ||				/* REF11163 - TEB - 050616 */
			priceCalcRule == PriceCalcRule_NPV ||						/* PMSTA-35405 - RAK - 190621 - one year later last report */
			priceCalcRule == PriceCalcRule_ChileanBond))				/* PMSTA-35405 - RAK - 190621 - one year later last report */

	{
		/* REF10633 - RAK - 041104 - DBA_GetInstrById() will search negativ instruments in hier */
		/* if (instrId <= 0)
		{
   			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			             "FIN_PriceToQuote", "instrument identifier");
			return(RET_GEN_ERR_INVARG);
		} */

        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk,
                                    &instrPtr, hierHead,
                                    UNUSED, UNUSED)) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
				         entSqlName, instrId);
			return(RET_DBA_ERR_NODATA);
		}
	}

	/* Instrument structure isn't obligatory in memory (depend on rule) */
	if (instrPtr != NULLDYNST)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
		    instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
		    instrId = GET_ID(instrPtr, A_Instr_Id);
	}

	switch (priceCalcRule)
	{
	/* Dflt : Price = Quote */
	case PriceCalcRule_None :
	   	*quote = price;
		ret = RET_SUCCEED;
		break;

	/* Price = Quote */
	case PriceCalcRule_Quote :
	   	*quote = price;
		ret = RET_SUCCEED;
		break;

	/* Price = Quote / 100 */
	case PriceCalcRule_Quote100 :
	   	*quote = price * 100.0;
		ret = RET_SUCCEED;
		break;

	/* Quote = Nom * (Quote * unpPrct / 100) */
	case PriceCalcRule_PartiallyPaidBondsInUnit: /* DVP193 */
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Quote = Price / ((100 - unpPrct) * Nom) */
	case PriceCalcRule_PartiallyPaidStocksInPrct: /* DVP193 */
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Price = Quote - (Nom * unpPrct / 100)  */
	case PriceCalcRule_PartiallyPaidStocks :
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Price = (Quote - unpPrct) / 100 */
	case PriceCalcRule_PartiallyPaidBonds :
	{
		DBA_DYNFLD_STP instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
		NUMBER_T       unpaidPrct;

		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* ------------------------------------------------- */
		/* DVP051 : new get on InstrChrono data (RAK 960509) */
		/* if (DBA_GetInstrChrono(instrId, priceDate, ChronoNat_UnpPrct, */
		/*      TimeDim_Last, FALSE, instrChrono) != RET_SUCCEED)        */
		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     priceDate);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_UnpPrct);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		if (FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead) != RET_SUCCEED)
		{
			unpaidPrct = 0.0;
			/* In log file, missing chrono is signaled */
		}
		else
		{
			/* REF11704 - TGU - 060419 - Change datatype */
			unpaidPrct = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		/* DVP051 : END (RAK 960509) */
		/* ------------------------- */

		switch (priceCalcRule)
		{
		case PriceCalcRule_PartiallyPaidBonds:
            /* REF6188 - rak - 010727 */
			/* *quote = 100.0 * price + unpaidPrct; */
            /* PMSTA-14109 - 160512 - PMO */
            if (0 == CMP_NUMBER(unpaidPrct, 100.0))
            {
                *quote = ZERO_NUMBER;
            }
            else
            {
                *quote = (price / ((100.0 - unpaidPrct) / 100.0))* 100.0;
            }
		    break;
		case PriceCalcRule_PartiallyPaidStocks :
			/* PMSTA16076 - DDV - 130315 - When define use face value to compute paid amount, else use quote */
			if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == FALSE &&
				GET_PRICE(instrPtr, A_Instr_FaceValue) != 0.0)
			{
				*quote = price + (GET_PRICE(instrPtr, A_Instr_FaceValue) *
					     unpaidPrct / 100.0);
			}
			else
			{
				*quote = price / (1 - unpaidPrct / 100.0);
			}
		    break;
		case PriceCalcRule_PartiallyPaidBondsInUnit: /* DVP193 */
		    if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		    	GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
			    *quote = price;
		    else
			    *quote = GET_PRICE(instrPtr,A_Instr_FaceValue) *
				         (price +  unpaidPrct / 100);
		    break;
		case PriceCalcRule_PartiallyPaidStocksInPrct: /* DVP193 */
		    if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE)
			    *quote = price;
		    else
			    *quote = price / ((100 - unpaidPrct) *
	 			         GET_PRICE(instrPtr,A_Instr_FaceValue));
		    break;
		}
		ret = RET_SUCCEED;
		break;
	}

	/* Price = Quote / Nom */
	case PriceCalcRule_StocksQuotedInPrct :
		if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		    GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
		{
			*quote = price;
		}
		else
		{
			*quote = 100 * price / GET_PRICE(instrPtr, A_Instr_FaceValue);
		}
		ret = RET_SUCCEED;
		break;

	/* Price = Quote * Nom / 100 */
	case PriceCalcRule_BondsQuotedInUnit :
	{
		/* BEGIN BUG026 - PriceCalcRule_BondsQuotedInUnit - rak 960426 */
		/* *quote = price * GET_PRICE(instrPtr, A_Instr_FaceValue) / 100.0; */
		*quote = price * GET_PRICE(instrPtr, A_Instr_FaceValue);
		/* END BUG026 - rak 960426 */
		ret = RET_SUCCEED;
		break;
	}

	/* actuarial yield function */
	case PriceCalcRule_ActuarialYield :
	case PriceCalcRule_NPV:			/* PMSTA-35405 - RAK - 190621 - one year later last report */
	case PriceCalcRule_ChileanBond:	/* PMSTA-35405 - RAK - 190621 - one year later last report */
	{
        /* REF9082 - TEB - 030619 - Begin */
        /* Replace Tech with Simcorp */
        DBA_DYNFLD_STP ytmPtr=NULLDYNST;

	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the instrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, priceDate.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

        /* Set the current price */
        SET_PRICE(advArgStp, AdvA_Arg_CurrentPrice, (PRICE_T)(price * 100.0));

        /* Set the redemption quote */
        /* REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice */
		/* REF10461 - TEB - 040804 */
		/* Compute Redemption Price in SCE functions, because of iorevent priority */
/*
        if (IS_NULLFLD(instrPtr, A_Instr_RedempQuote)== TRUE)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "No redemption quote for YTM computation ! Instrument :",
                         GET_CODE(instrPtr, A_Instr_Cd));
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
            return(RET_FIN_ERR_INVDATA);
        }
        else
        {
            COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RedemptionPrice, instrPtr, A_Instr, A_Instr_RedempQuote );
        }
*/

        /* Allocate the output structure */
	    if ((ytmPtr = ALLOC_DYNST(A_Ytm)) == NULLDYNST)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        /* set the type of the output structure */
	    SET_INT(advArgStp, AdvA_Arg_SceOutEn, A_Ytm); /* REF9764 - LJE - 040113 */

	    /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_YTM);

        /* Compute ytm */
	    if (SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
				                   NULL , hierHead, ytmPtr) != RET_SUCCEED)
	    {
		    *quote = price;
	    }
        else
        {
		    *quote = GET_NUMBER(ytmPtr, A_Ytm_Ytm);
            *quote *= 100;
		}

	    FREE_DYNST(ytmPtr,   A_Ytm);	/* RAK10270 - RAK - 040511 - use correct DBA_DYNST_ENUM */
	    FREE_DYNST(advArgStp, AdvA_Arg);

        /* REF9082 - TEB - 030619 - End */
		ret = RET_SUCCEED;
		break;
	}

	/* Price = redemption price * (1- (quote/100) * life) */
	case PriceCalcRule_Discounted :
	{
		FIN_LIFE_ST lifeSt;		/* DVP561 */
		memset(&lifeSt, 0, sizeof(FIN_LIFE_ST));

		/* BUG207 - Suppress test instrument nature = rate */
		if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
            GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) ||	/* BUG208 */
		    priceDate.date >= GET_DATE(instrPtr, A_Instr_EndDate))
		{
		    *quote =  0.0;
		}
		else
		{
		    FIN_InstrOrUnderlyLife(FALSE, instrPtr, priceDate, &lifeSt, hierHead);	/* DVP440 */

		    if (lifeSt.life != 0.0)
		    {
		   	    /* *quote = (100 * (price - 1)) / lifeSt.life;  REF3173 - DDV - 990108 - Formula error */
			    /* *quote = (100 * (1 - price)) / lifeSt.life; REF3722 - SSO - 000301 : less than 14 significant digits ! */
			    signifDigits = min(14, 9 + TLS_GetPos1stDigit(price));
			    n1 = AAA_TIME_SD(100, AAA_MINUS_SD(1, price, 14, signifDigits), 14, signifDigits);
			    *quote = AAA_DIV_SD(n1, lifeSt.life, 14, signifDigits);
		    }
		    else
		   	    *quote = 0.0;
		}

		ret = RET_SUCCEED;
		break;
	}

	/* DVP431 - Quote = (1/Price - 1) * 100 / life */
	case PriceCalcRule_InFineYield :
	{
		FIN_LIFE_ST lifeSt;		/* DVP561 */
		memset(&lifeSt, 0, sizeof(FIN_LIFE_ST));

		/* BUG207 - Suppress test instrument nature = rate */
		if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
            GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) ||	/* BUG208 */
		    priceDate.date >= GET_DATE(instrPtr, A_Instr_EndDate))
		{
		    *quote =  0.0;
		}
		else
		{
		    FIN_InstrOrUnderlyLife(FALSE, instrPtr, priceDate, &lifeSt, hierHead);	/* DVP440 */

		    if (lifeSt.life != 0.0 && CMP_PRICE(price, 0.0) != 0)
		    {
		   	     /* *quote = ((1.0/price) - 1.0) * (100 / lifeSt.life);   REF3722 - SSO - 000301 : less than 14 significant digits ! */
			     signifDigits = min(14, 9 + TLS_GetPos1stDigit(price));
			     n1 = AAA_MINUS_SD(AAA_DIV_SD(1.0, price, 14, signifDigits) ,1.0 , 14, signifDigits);
			     n2 = AAA_DIV_SD(100, lifeSt.life, 14, signifDigits);
			     *quote = AAA_TIME_SD(n1 , n2, 14, signifDigits);
		    }
		    else
		   	    *quote = 1.0;			/* PMSTA-33034 - RAK - 180924 - 1 instead of 0 */
		}

		ret = RET_SUCCEED;
		break;
	}

	/* add-on rate function */ 					/* BUG364 - RAK - 970505 */
	case PriceCalcRule_WithAddOnRate :
	{
		NUMBER_T	dm;
		NUMBER_T	sm;
		DATE_PERIOD_ST 	period;
		double          freq;

	    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_RateFreqUnitEn), /* REF7264 - CSY - 020130 */
		                  GET_SMALLINT(instrPtr, A_Instr_RateFreq), FreqUnit_Month, &freq); /* PMSTA-45526 - VSW - 080721 */

		if ((ret = FIN_GetInstrAccrRule(priceDate.date, instrPtr, hierHead, /* REF3410 - SSO - 990315 */
				                        &accrRule)) != RET_SUCCEED)
		{
		    if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		    return(ret);
		}

        /* PMSTA-22396  - SRIDHARA – 160430 */
        DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	    DATE_AccrPeriod(GET_DATE(instrPtr, A_Instr_BeginDate),
				        GET_DATE(instrPtr, A_Instr_EndDate),
				        accrRule,     /* REF3410 - SSO - 990315 */
				        (PERIOD_T) freq, &period, calendarId);

	    if (period.denom != 0)
	        dm = period.num / (double) period.denom;
	    else
	        dm = period.num / 360.0;

		DATE_AccrPeriod(priceDate.date,
                        GET_DATE(instrPtr, A_Instr_EndDate),
				        accrRule,     /* REF3410 - SSO - 990315 */
            (PERIOD_T)freq, &period, calendarId);   /* PMSTA-22396 - SRIDHARA – 160502 */

	    if (period.denom != 0)
	        sm = period.num / (double) period.denom;
		else
	        sm = period.num / 360.0;

		/* Formula */
		if (sm != 0.0)
		    *quote = ((1.0 + (GET_PERCENT(instrPtr, A_Instr_InterestRateP)/100.0) * dm) /
			         price * sm) - 1.0;
		else
		    *quote = 0.0;

		ret = RET_SUCCEED;
		break;
	}

	/* Price = Quote / 100 - unitary interest */
	case PriceCalcRule_QuotedWithAI :
		/* Get accrued interest like QuotedInUnitWithAI case */

	/* Price = Quote - unitary interest * nom */
	case PriceCalcRule_QuotedInUnitWithAI :
	{
		DBA_DYNFLD_STP   accrInter;
		char             calcAccrInterFlg;
		FLAG_T           fullCoupFlg;
		FUSDATERULE_ENUM fusDateRule;

		if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

		/* REF10256 - TEB - 040615 - Begin */
		/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
			fusionSwitchDate == MAGIC_END_DATE )
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
		}
		else
		{
			if (DATE_Cmp(priceDate.date, fusionSwitchDate) < 0)
			{
				GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
			}
			else
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
		}
		/* REF10256 - TEB - 040615 - End */

		if (fusDateRule == FusDateRule_None)
			calcAccrInterFlg = FALSE;
		else
			calcAccrInterFlg = TRUE;

		/* DVP125 - RAK - 960620 */
        /* REF7265 - YST - 020320 - add two new arguments */
		ret = FIN_UnitAccrInter(priceDate, instrId, instrPtr, fusDateRule,
					            fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, priceDate,
								AccrRule_None, /* REF11218 - TEB - 050627 */
								NULLDYNST, accrInter, hierHead, TRUE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

		if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
			ret = RET_SUCCEED;

		if (priceCalcRule == PriceCalcRule_QuotedInUnitWithAI)
		{
		   if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		       GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
		   {
			    *quote = price;
		   }
		   else
		   {
			    /* BUG169 */
			    *quote = (price + GET_NUMBER(accrInter, UnitInter_UnitAccrInter)) *
			             GET_PRICE(instrPtr, A_Instr_FaceValue);
		   }
		}
		else
		{
			*quote = (price + GET_NUMBER(accrInter, UnitInter_UnitAccrInter)) * 100.0;
		}
        FREE_DYNST(accrInter, UnitInter);
		break;
	}

	/* basis point to another instrument */
	case PriceCalcRule_TCN :
		*quote = price;
		ret = RET_SUCCEED;
		break;

	/* annualised rate / 100 */
	case PriceCalcRule_AnnualRate:
		*quote = price;
		ret = RET_SUCCEED;
		break;

	/* ?? */
	case PriceCalcRule_QuoteLife :
		*quote = price;
		ret = RET_SUCCEED;
		break;

	case PriceCalcRule_EuroFutureContract :		/* DVP440 - RAK - 970425 */
	{
		FIN_LIFE_ST uLifeSt;		/* DVP561 */
		memset(&uLifeSt, 0, sizeof(FIN_LIFE_ST));

		*quote = price;

		if (priceArgStp != (FIN_PRICEARG_STP)NULL && priceArgStp->costQuote != 0.0)
		{
		    /*** ----------- ***/
		    /* UNDERLYING LIFE */
		    /*** ----------- ***/
		    /* REF3477 - force 30/360 for euro future contract */
		    uLifeSt.accrRuleEn = AccrRule_30E_360;
		    FIN_InstrOrUnderlyLife(TRUE, instrPtr, priceDate, &uLifeSt, hierHead);	/* DVP440 */

		    /*** ---- ***/
		    /* FORMULA */
		    /*** --- ***/
		    /* REF3477 - RAK - 990322 */
		    /* the old formula, compte quote by difference, but ... */
		    /* if (uLifeSt.life != 0.0)
		    	*quote = (100.0 * (price - 1.0) / uLifeSt.life) + priceArgStp->costQuote;
		    */
		    if (uLifeSt.life != 0.0)
		    	*quote = (((100.0 * price) - 100.0) / uLifeSt.life) + 100.0;
		}
		ret = RET_SUCCEED;
		break;
	}

	case PriceCalcRule_LiborFRA :			/* DVP440 - RAK - 970425 */
	{
		NUMBER_T 	actuRate = 0.0;
		FIN_LIFE_ST	uLifeSt, fLifeSt;		/* DVP561 */
		memset(&uLifeSt, 0, sizeof(FIN_LIFE_ST));
		memset(&fLifeSt, 0, sizeof(FIN_LIFE_ST));

		*quote = price;

		if (priceArgStp != (FIN_PRICEARG_STP)NULL && priceArgStp->costQuote != 0.0)
		{
		    /*** ----------- ***/
		    /* UNDERLYING LIFE */
		    /*** ----------- ***/
		    FIN_InstrOrUnderlyLife(TRUE, instrPtr, priceDate, &uLifeSt, hierHead);	/* DVP440 */

		    /*** ----------- ***/
		    /* INSTRUMENT LIFE */
		    /*** ----------- ***/
		    FIN_InstrOrUnderlyLife(FALSE, instrPtr, priceDate, &fLifeSt, hierHead);	/* DVP440 */

		    /*** ------------------------- ***/
		    /* INSTRUMENT ACTUALISATION RATE */
		    /*** ------------------------- ***/
		    GEN_GetApplInfo(ApplActuaRule, &actuaRule);
		    switch (actuaRule)
		    {
		    case ActuaRule_None :
			    actuRate = 0.0;
			    break;

		    case ActuaRule_YieldCurve :
			    /* tech ?? */
			    actuRate = 0.11;
			    break;
		    }

		    /*** ---- ***/
		    /* FORMULA */
		    /*** --- ***/
		    if (actuaRule == ActuaRule_UnderlyRate)
		    {
			    double a, b, c, val, s1, s2, d1, d2;

			    if ((price - 1.0) != 0.0)
			    {
			        a = uLifeSt.life * fLifeSt.life;
			        b = uLifeSt.life + fLifeSt.life - (uLifeSt.life / price - 1.0);
			        c = 1 + (priceArgStp->costQuote * uLifeSt.life / 100 * (price -1.0));

			        if (a != 0.0)
			        {
			            val = pow(b,2) - 4*a*c;
			            if (val >= 0.0)
			            {
				            val = sqrt(val);
			                s1 = (-1 * b) + val / 2*a;
			                s2 = (-1 * b) - val / 2*a;

			                if (s1 >= 0.0 && s2 >= 0.0)
			                {
				                d1 = fabs(priceArgStp->costQuote - s1);
				                d2 = fabs(priceArgStp->costQuote - s2);

				                if (d1 > d2)
					                *quote = s2;
				                else
					                *quote = s1;
				            }
				            else
				            {
				                if (s1 >= 0.0)
					                *quote = s1;
				                else
					                *quote = s2;
				            }
			            }
			        }
			    }
		    }
		    else
		    {
		        *quote = 100.0 *
			             ((((1.0 + (actuRate * fLifeSt.life / 100.0)) * price) +
				            (priceArgStp->costQuote * uLifeSt.life / 100.0)) /
			                (uLifeSt.life * (1.0 - (1.0 + (actuRate * fLifeSt.life / 100.0))) * price));
		    }
		}

		ret = RET_SUCCEED;
		break;
	}

	/* ------------------------------- */
	/* BEGIN DVP124 -     RAK - 960606 */
	/* quote = 100 - yield to maturity */
	case PriceCalcRule_OldAustralianFuture :
	case PriceCalcRule_FlexibleAustralianFuture: /* PMSTA15205 - DDV - 121113 - New priceCalcRule */
	{
		double         ytm;

		/* Australian bond is a 10 years , 12 % notional bond */
        /* REF9082 - TEB - 030618 */
        SCE_CallAustralianBond_YTM2Yield(price,&ytm, priceCalcRule, instrPtr); /* PMSTA16032-JPP-130304 */

		*quote = 100.0 - ytm ;

		ret = RET_SUCCEED;
		break;
	}
	/* END DVP124 - RAK - 960606 */
	/* ------------------------- */

	/* quote = price / priceCalculationFactor */
	case PriceCalcRule_PriceCalculationFactor: /* DVP193 - XDI */
	{
		DBA_DYNFLD_STP instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
		NUMBER_T       factor;

		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     priceDate);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_PriceCalculationFactor);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		if (FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead) != RET_SUCCEED)
		{
			factor = 1.0;
			/* In log file, missing chrono is signaled */
		}
		else
		{
			/* REF11704 - TGU - 060419 - Change datatype */
			factor = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		if (factor != 0)
			*quote = price / factor;
		else
			*quote = 0.0;

		ret = RET_SUCCEED;
		break;
	}

	/* DVP510 - XDI - 970624 */
	/* Price = Quote * 10000 */
	case PriceCalcRule_BasisPoints :
	   	*quote = price * 10000.0;
		ret = RET_SUCCEED;
		break;

	/* REF11163 - TEB - 050616 */
	/* Bonds quoted in units */
	case PriceCalcRule_QuoteInUnit:
	{
		/* REF11163 - TEB - 050713 */
		/* Take in account the accrued interest... because client wasnt happy :'( */
		DBA_DYNFLD_STP   accrInter;
		char             calcAccrInterFlg;
		FLAG_T           fullCoupFlg;
		FUSDATERULE_ENUM fusDateRule;

		if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

		/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
			fusionSwitchDate == MAGIC_END_DATE )
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
		}
		else
		{
			if (DATE_Cmp(priceDate.date, fusionSwitchDate) < 0)
			{
				GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
			}
			else
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
		}

		if (fusDateRule == FusDateRule_None)
			calcAccrInterFlg = FALSE;
		else
			calcAccrInterFlg = TRUE;

		ret = FIN_UnitAccrInter(priceDate, instrId, instrPtr, fusDateRule,
					            fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, priceDate,
								AccrRule_None,
								NULLDYNST, accrInter, hierHead, TRUE, NULL); /* PMSTA08308 - 090609 - PMO */

		if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
			ret = RET_SUCCEED;

		if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		    GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
			*quote = price +
					 GET_NUMBER(accrInter, UnitInter_UnitAccrInter); /* REF11163 - TEB - 050713 */
		else
			*quote = GET_PRICE(instrPtr,A_Instr_FaceValue) *
			         (price + GET_NUMBER(accrInter, UnitInter_UnitAccrInter)); /* REF11163 - TEB - 050713 */

		ret = RET_SUCCEED;
		FREE_DYNST(accrInter, UnitInter);
		break;
	}

	/* PMSTA-32157 - SILPA - 180905 */
	case PriceCalcRule_PortfolioSpecificPrice:
		*quote = price;
		ret = RET_SUCCEED;
		break;

	default :
		*quote = price;

		/* BUG257 */
		if (instrPtr == NULLDYNST) instrCd[0] = END_OF_STRING;
		else strcpy(instrCd, GET_CODE(instrPtr, A_Instr_Cd));
		ret = RET_FIN_ERR_INVDATA;
   		MSG_SendMesg(ret, 1, FILEINFO, "FIN_PriceToQuote", instrCd, "priceCalcRule");
		break;

	} /* end switch */

	/* REF2158 - DDV - 980514 */
	*quote = CAST_PRICE(*quote);

	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_QuoteToPrice()
**
**  Description :   Determine price depending on quote and instrument info
**                  and received rule.
**
**  Arguments   :   priceCalcRule   rule to use, by default (value is None)
**                                               use instrument rule
**                  instrId         instrument identifier
**                  inputInstrPtr   instrument pointer or NULLDYNST
**                  date            price date
**                  quote           quote
**                  *price          pointer on price
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP125 - RAK - 960620
**  Modif       :   BUG147 - RAK - 960930
**  Modif       :   BUG169 - RAK - 961008
**  Modif       :   BUG207 - RAK - 961121
**  Modif       :   BUG257 - RAK - 970117
**  Modif       :   DVP431 - RAK - 970414
**  Modif       :   DVP440 - RAK - 970425
**  Modif       :   BUG438 - RAK - 970707
**  Modif       :   DVP561 - RAK - 970826
**  Modif       :   REF1149 - RAK - 980113
**  Modif       :   REF053 - RAK - 980415
**                  REF9082 - TEB - 030618 : Replace Tech with Simcorp
**                  REF10256 - TEB - 040615
**                  REF11163 - TEB - 050616
**                  REF11163 - TEB - 050713
**                  PMSTA-14109 - 160512 - PMO : Price calculation error and fusion engine error messages (Data overflow detected while Inserting extended_pos...) when working with instrument chronos #28 (Unpaid %) equal to100
*************************************************************************/
RET_CODE FIN_QuoteToPrice(PRICECALCRULE_ENUM priceCalcRule,
                          ID_T               instrId,
                          DBA_DYNFLD_STP     inputInstrPtr,
			              DATETIME_T         priceDate,
			              FIN_PRICEARG_STP   priceArgStp,
			              PRICE_T            quote,
			              PRICE_T            *price,
                          DBA_HIER_HEAD_STP  hierHead)
{
	DBA_DYNFLD_STP instrPtr    = NULLDYNST;
    SCE_ADVA_ARG_ST *advaArgStp=(SCE_ADVA_ARG_ST*)NULL; /* REF9082 - TEB - 030626 */
    FLAG_T         allocOk;
	RET_CODE       ret;
	CODE_T	       instrCd;
	ACCRRULE_ENUM  accrRule = AccrRule_None;    /* REF3410 - SSO - 990315 */
    INSTRNAT_ENUM  instrNatEn = InstrNat_None;  /* REF9082 - TEB - 030630 */
    SUBNAT_ENUM    instrSubNatEn = SubNat_None; /* REF9082 - TEB - 030630 */
	DATE_T		   fusionSwitchDate;            /* REF10256 - TEB - 040615 */
    ID_T		   calendarId = 0;              /* PMSTA-22396  - SRIDHARA – 160430 */


	if (priceCalcRule != PriceCalcRule_InFineYield && CMP_PRICE(quote, 0.0) == 0) 			/* PMSTA-33034 - RAK - 180924 - Not for InFineYield price = 1.0 */
	{
		*price = 0.0;
		return(RET_SUCCEED);
	}

	/* Load instrument if necessary */
	allocOk = FALSE;

	if (inputInstrPtr != NULLDYNST)
		instrPtr = inputInstrPtr;

	if (instrPtr == NULLDYNST &&
	    (priceCalcRule == PriceCalcRule_PartiallyPaidStocks ||
	     priceCalcRule == PriceCalcRule_PartiallyPaidBonds ||	/* BUG257 - RAK - Why not */
	     priceCalcRule == PriceCalcRule_StocksQuotedInPrct ||
	     priceCalcRule == PriceCalcRule_BondsQuotedInUnit ||
	     priceCalcRule == PriceCalcRule_Discounted ||
	     priceCalcRule == PriceCalcRule_InFineYield ||		/* DVP431 - RAK - 970414 */
	     priceCalcRule == PriceCalcRule_QuotedWithAI  ||
	     priceCalcRule == PriceCalcRule_QuotedInUnitWithAI ||
	     priceCalcRule == PriceCalcRule_LiborFRA ||
	     priceCalcRule == PriceCalcRule_WithAddOnRate ||		 /* BUG364 - RAK */
	     priceCalcRule == PriceCalcRule_EuroFutureContract ||	 /* DVP440 - RAK */
	     priceCalcRule == PriceCalcRule_PartiallyPaidBondsInUnit ||  /* DVP193 - XDI */
	     priceCalcRule == PriceCalcRule_PartiallyPaidStocksInPrct || /* DVP193 - XDI */
	     priceCalcRule == PriceCalcRule_OldAustralianFuture ||		 /* BUG257 - RAK */
		 priceCalcRule == PriceCalcRule_FlexibleAustralianFuture || /* PMSTA15205 - DDV - 121113 - New priceCalcRule */
	     priceCalcRule == PriceCalcRule_ActuarialYield ||		 /* BUG257 - RAK */
		 priceCalcRule == PriceCalcRule_QuoteInUnit ||			 /* REF11163 - TEB - 050616 */
			priceCalcRule == PriceCalcRule_NPV ||				 /* PMSTA-35405 - RAK - 190621 - one year later last report */
			priceCalcRule == PriceCalcRule_ChileanBond))
	{
        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk,
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, instrId);
			return(RET_DBA_ERR_NODATA);
		}

		/* REF11163 - TEB - 050616 */
		if (instrPtr == NULLDYNST)
		{
   			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			             "FIN_PriceToQuote", "instrument not found");
			return(RET_GEN_ERR_INVARG);
		}
	}

	/* Instrument structure isn't obligatory in memory (depend on rule) */
	if (instrPtr != NULLDYNST)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
		    instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
		    instrId = GET_ID(instrPtr, A_Instr_Id);
	}

	switch (priceCalcRule)
	{
	/* Dflt : Price = Quote */
	case PriceCalcRule_None :
	   	*price = quote;
		ret = RET_SUCCEED;
		break;

	/* Price = Quote */
	case PriceCalcRule_Quote :
	   	*price = quote;
		ret = RET_SUCCEED;
		break;

	/* Price = Quote / 100 */
	case PriceCalcRule_Quote100 :
	   	*price = quote / 100.0;
		ret = RET_SUCCEED;
		break;

	/* Price = (Quote - (Nom * unpPrct / 100)) / Nom  */
	case PriceCalcRule_PartiallyPaidBondsInUnit : /* DVP193 */
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Price = (100 - unpPrct) * Nom * Quote  */
	case PriceCalcRule_PartiallyPaidStocksInPrct : /* DVP193 */
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Price = Quote - (Nom * unpPrct / 100)  */
	case PriceCalcRule_PartiallyPaidStocks :
		/* Get unpaid percentage like PartiallyPaidBonds case */

	/* Price = (Quote - unpPrct) / 100 */
	case PriceCalcRule_PartiallyPaidBonds :
	{
		DBA_DYNFLD_STP instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
		NUMBER_T       unpaidPrct;

		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* ------------------------------------------------- */
		/* DVP051 : new get on InstrChrono data (RAK 960509) */
		/* if (DBA_GetInstrChrono(instrId, priceDate, ChronoNat_UnpPrct, */
		/*      TimeDim_Last, FALSE, instrChrono) != RET_SUCCEED)        */
		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     priceDate);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_UnpPrct);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		if (FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead) != RET_SUCCEED)
		{
			unpaidPrct = 0.0;
			/* In log file, missing chrono is signaled */
		}
		else
		{
			/* REF11704 - TGU - 060419 - Change datatype */
			unpaidPrct = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		/* DVP051 : END (RAK 960509) */
		/* ------------------------- */

		switch (priceCalcRule)
		{
		case PriceCalcRule_PartiallyPaidBonds:
           /* REF6188 - RAK - 010727 */
			/* *price = (quote - unpaidPrct) / 100.0; */
            /* PMSTA-14109 - 160512 - PMO */
            if (0 == CMP_NUMBER(unpaidPrct, 100.0))
            {
                *price = ZERO_NUMBER;
            }
            else
            {
                *price = (quote/100.0) * (100.0 - unpaidPrct) / 100.0;
            }
			break;

		case PriceCalcRule_PartiallyPaidStocks :
			/* PMSTA16076 - DDV - 130315 - When define use face value to compute paid amount, else use quote */
			if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == FALSE &&
				GET_PRICE(instrPtr, A_Instr_FaceValue) != 0.0)
			{
			    *price = quote - (GET_PRICE(instrPtr, A_Instr_FaceValue) * unpaidPrct / 100.0);
			}
			else
			{
				*price = quote - (quote * unpaidPrct / 100.0);
			}
			break;

		case PriceCalcRule_PartiallyPaidBondsInUnit: /* DVP193 */
			if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		    	GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
				*price = quote;
			else
				*price = (quote - GET_PRICE(instrPtr,A_Instr_FaceValue) *
					     unpaidPrct / 100) /
                         GET_PRICE(instrPtr,A_Instr_FaceValue);
			break;

		case PriceCalcRule_PartiallyPaidStocksInPrct: /* DVP193 */
			if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE)
				*price = (100 - unpaidPrct) * quote;
			else
				*price = (100 - unpaidPrct) * quote *
	 			         GET_PRICE(instrPtr,A_Instr_FaceValue);
			break;
		}
		ret = RET_SUCCEED;
		break;
	}

	/* Price = Nom * Quote / 100 */
	case PriceCalcRule_StocksQuotedInPrct :
		*price = GET_PRICE(instrPtr, A_Instr_FaceValue) * quote / 100;
		ret = RET_SUCCEED;
		break;

	/* Price = Quote / Nom * 100 */
	case PriceCalcRule_BondsQuotedInUnit :
		if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		    GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
		{
			*price = quote;
		}
		else
		{
			/* BEGIN BUG026 - PriceCalcRule_BondsQuotedInUnit - rak 960426 */
			/* *price = (quote/GET_PRICE(instrPtr,A_Instr_FaceValue)) * 100.0; */
			*price = quote / GET_PRICE(instrPtr,A_Instr_FaceValue);
			/* END BUG026 - rak 960426 */
		}
		ret = RET_SUCCEED;
		break;

	/* actuarial yield function */
	case PriceCalcRule_ActuarialYield :
	case PriceCalcRule_NPV:						/* PMSTA-35405 - RAK - 190621 - one year later last report */
	case PriceCalcRule_ChileanBond:				/* PMSTA-35405 - RAK - 190621 - one year later last report */
	{
		/* BUG147 */
        /* REF9082 - TEB - 030626 - Begin */
        if ((advaArgStp = (SCE_ADVA_ARG_ST*)CALLOC(1, sizeof(SCE_ADVA_ARG_ST))) == NULL)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* ------------------------------------- */
        /* set structure of all structure needed */
        /* ------------------------------------- */
        advaArgStp->extPosStp	    = NULLDYNST;
        advaArgStp->instrStp	    = instrPtr;
        advaArgStp->hierHead	    = hierHead;
        advaArgStp->underInstr	    = NULLDYNST;
        advaArgStp->underUnderInstr = NULLDYNST;
        advaArgStp->incomeStp       = NULLDYNST;
        advaArgStp->under           = FALSE;
        advaArgStp->underUnder      = FALSE;

	    /* Create input structure. */
	    if ((advaArgStp->argStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
            FREE(advaArgStp);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the instrument id */
        SET_ID(advaArgStp->argStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the reference date */
        SET_DATE(advaArgStp->argStp, AdvA_Arg_RefDate, priceDate.date);
        COPY_DYNFLD(advaArgStp->argStp, AdvA_Arg, AdvA_Arg_Date, advaArgStp->argStp, AdvA_Arg, AdvA_Arg_RefDate );

        /* Set the Yield */
        SET_NUMBER(advaArgStp->argStp, AdvA_Arg_Ytm, (NUMBER_T)(quote));

        /* Allocate the output structure */
	    if ((advaArgStp->outStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	    {
		    FREE_DYNST(advaArgStp->argStp, AdvA_Arg);
            FREE(advaArgStp);
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        SET_INT(advaArgStp->argStp, AdvA_Arg_SceOutEn, A_AdvA);

        /* Compute price */
		/* PMSTA-35405 - RAK - 190621 - one year later last report */
		if (priceCalcRule == PriceCalcRule_NPV ||
			priceCalcRule == PriceCalcRule_ChileanBond)
		{
			advaArgStp->currSceFct = Sce_FctName_Bond_df2Price;
            /*Set the instr's price rule to the one user provides in the instr price window , so that when user changes the rule between NPV and TERA
            in the instr price window , the price gets computed accordingly*/
            SET_ENUM(advaArgStp->instrStp, A_Instr_PriceCalcRuleEn, (PRICECALCRULE_ENUM)priceCalcRule); /*PMSTA-40263-ARUN-15102020*/
			ret = SCE_CallBond_DF2Price(advaArgStp);
		}
		else
		{
			/* Compute price */
			instrNatEn = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);
			instrSubNatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);
			if ((instrNatEn == InstrNat_Bond || instrNatEn == InstrNat_MoneyMkt) && instrSubNatEn == SubNat_FRN)
			{
				advaArgStp->currSceFct = Sce_FctName_FRN_YTM2Price;
				ret = SCE_CallFRN_YTM2Price(advaArgStp);
			}
			else
			{
				advaArgStp->currSceFct = Sce_FctName_Bond_YTM2Price;
				ret = SCE_CallBond_YTM2Price(advaArgStp);
			}
		}

		if (IS_NULLFLD(advaArgStp->outStp, A_AdvA_Price) == FALSE)
		{
			*price = GET_PRICE(advaArgStp->outStp, A_AdvA_Price);
		}

	    FREE_DYNST(advaArgStp->outStp,   A_AdvA);
        FREE_DYNST(advaArgStp->argStp, AdvA_Arg);
        FREE(advaArgStp);

		(*price)/=100.0;

        /* REF9082 - TEB - 030626 - Begin */
		ret = RET_SUCCEED;
		break;
	}

	/* Price = Redemption price * (1 - (quote/100) * life) */
	case PriceCalcRule_Discounted :
	{
		FIN_LIFE_ST   lifeSt;			/* DVP561 */
		memset(&lifeSt, 0, sizeof(FIN_LIFE_ST));

		/* BUG207 - Suppress test instrument nature = rate */
		if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
                     GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) ||	/* BUG208 */
		    priceDate.date >= GET_DATE(instrPtr, A_Instr_EndDate))
		{
		    *price = 1.0;
		}
		else
		{
		    FIN_InstrOrUnderlyLife(FALSE, instrPtr, priceDate, &lifeSt, hierHead);	/* DVP440 */

		    *price = 1 - ((quote / 100) * lifeSt.life);
		}

		ret = RET_SUCCEED;
		break;
	}

	/* DVP431 - Price =  1 / (1 + (quote * life / 100) */
	case PriceCalcRule_InFineYield :
	{
		FIN_LIFE_ST   lifeSt;			/* DVP561 */
		memset(&lifeSt, 0, sizeof(FIN_LIFE_ST));

		/* BUG207 - Suppress test instrument nature = rate */
		if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
             GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) ||	/* BUG208 */
		    priceDate.date >= GET_DATE(instrPtr, A_Instr_EndDate))
		{
		    *price = 1.0;
		}
		else
		{
		    FIN_InstrOrUnderlyLife(FALSE, instrPtr, priceDate, &lifeSt, hierHead);	/* DVP440 */

		    if (CMP_NUMBER((quote * lifeSt.life), -100.0) != 0)
		    	*price = 1.0 / (1.0 + ((quote * lifeSt.life) / 100.0));
		    else
				*price = 1.0;			/* PMSTA-33034 - RAK - 180924 - 1 instead of 0 */
		}

		ret = RET_SUCCEED;
		break;
	}

	/* add-on rate function */					/* BUG364 - RAK - 970505 */
	case PriceCalcRule_WithAddOnRate :
	{
		NUMBER_T	dm;
		NUMBER_T	sm;
		DATE_PERIOD_ST 	period;
		double         	freq;

	    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_RateFreqUnitEn), /* REF7264 - CSY - 020130 */
		                  GET_SMALLINT(instrPtr, A_Instr_RateFreq), FreqUnit_Month, &freq); /* PMSTA-45526 - VSW - 080721 */

		if ((ret = FIN_GetInstrAccrRule(priceDate.date, instrPtr, hierHead, /* REF3410 - SSO - 990315 */
				                        &accrRule)) != RET_SUCCEED)
		{
		    if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		    return(ret);
		}

        /* PMSTA-22396  - SRIDHARA – 160430 */
        DBA_GetCalendarFromInstr(instrPtr, &calendarId);
		DATE_AccrPeriod(GET_DATE(instrPtr, A_Instr_BeginDate),
				        GET_DATE(instrPtr, A_Instr_EndDate),
				        accrRule, /* REF3410 - SSO - 990315 */
				        (PERIOD_T) freq, &period, calendarId);

	    if (period.denom != 0)
	        dm = period.num / (double) period.denom;
	    else
	        dm = period.num / 360.0;

	    DATE_AccrPeriod(priceDate.date, GET_DATE(instrPtr, A_Instr_EndDate),
			accrRule, /* REF3410 - SSO - 990315 */
			(PERIOD_T) freq, &period, calendarId);   /* PMSTA-22396 - SRIDHARA - 160502 */

	    if (period.denom != 0)
	        sm = period.num / (double) period.denom;
		else
	        sm = period.num / 360.0;

		/* Formula */
		if (((quote/100.0) * sm) != 1.0)
		    *price = (1.0 + ((GET_PERCENT(instrPtr, A_Instr_InterestRateP)/100.0) * dm)) /
			         (1.0 + ((quote/100.0) * sm));
		else
		    *price = 0.0;

		ret = RET_SUCCEED;
		break;
	}

	/* Price = Quote / 100 - unitary interest */
	case PriceCalcRule_QuotedWithAI :
		/* Get accrued interest like QuotedInUnitWithAI case */

	/* Price = Quote - unitary interest * nom */
	case PriceCalcRule_QuotedInUnitWithAI :
	{
		DBA_DYNFLD_STP   accrInter;
		char             calcAccrInterFlg;
		FLAG_T           fullCoupFlg;
		FUSDATERULE_ENUM fusDateRule;

		if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

		/* REF10256 - TEB - 040615 - Begin */
		/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
			fusionSwitchDate == MAGIC_END_DATE )
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
		}
		else
		{
			if (DATE_Cmp(priceDate.date, fusionSwitchDate) < 0)
			{
				GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
			}
			else
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
		}
		/* REF10256 - TEB - 040615 - End */

		if (fusDateRule == FusDateRule_None)
			calcAccrInterFlg = FALSE;
		else
			calcAccrInterFlg = TRUE;

		/* DVP125 - RAK - 960620 */
        /* REF7265 - YST - 020320 - add two new arguments */
		ret = FIN_UnitAccrInter(priceDate, instrId, instrPtr,  fusDateRule, fullCoupFlg, calcAccrInterFlg,
                                AccrInterMethod_Default, priceDate,
								AccrRule_None, /* REF11218 - TEB - 050627 */
								NULLDYNST, accrInter, hierHead, TRUE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

		if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
			ret = RET_SUCCEED;

		if (priceCalcRule == PriceCalcRule_QuotedInUnitWithAI)
		{
		   if (IS_NULLFLD(instrPtr,A_Instr_FaceValue) == TRUE ||
		       GET_PRICE(instrPtr,A_Instr_FaceValue) == 0.0)
		   {
			    *price = quote;
		   }
		   else
		   {
			    /* BUG169 */
			    *price = (quote / GET_PRICE(instrPtr, A_Instr_FaceValue)) -
				         GET_NUMBER(accrInter, UnitInter_UnitAccrInter);
		   }
		}
		else
		{
			*price = quote / 100.0 - GET_NUMBER(accrInter, UnitInter_UnitAccrInter);
		}
    	FREE_DYNST(accrInter, UnitInter); /* Memory leak - DDV - 071109 */
		break;
	}

	/* basis point to another instrument */
	case PriceCalcRule_TCN :
		/* ?? */
		*price = quote;
		ret = RET_SUCCEED;
		break;

	/* annualised rate / 100 */
	case PriceCalcRule_AnnualRate :
		/* TECH_?? */
		*price = quote;
		ret = RET_SUCCEED;
		break;

	/* ?? */
	case PriceCalcRule_QuoteLife :
		*price = quote;
		ret = RET_SUCCEED;
		break;

	case PriceCalcRule_EuroFutureContract :			/* DVP440 - RAK - 970425 */
	{
		FIN_LIFE_ST   uLifeSt;			/* DVP561 */
		memset(&uLifeSt, 0, sizeof(FIN_LIFE_ST));

		*price = quote;

		if (priceArgStp != (FIN_PRICEARG_STP)NULL && priceArgStp->costQuote != 0.0)
		{
		    /*** ----------- ***/
		    /* UNDERLYING LIFE */
		    /*** ----------- ***/
		    /* REF3477 - force 30/360 for euro future contract */
		    uLifeSt.accrRuleEn = AccrRule_30E_360;
		    FIN_InstrOrUnderlyLife(TRUE, instrPtr, priceDate, &uLifeSt, hierHead);

		    /*** ---- ***/
		    /* FORMULA */
		    /*** --- ***/
		    /* REF3477 - RAK - 990322 */
		    /* the old formula, compte quote by difference, but ... */
		    /* if (uLifeSt.life != 0.0)
		    	*price = 1.0 + ((quote - priceArgStp->costQuote) / 100.0 * uLifeSt.life);
		    */
		    *price = ((100.0 - ((100.0 -quote)) * uLifeSt.life)) / 100.0;
		}

		ret = RET_SUCCEED;
		break;
	}

	case PriceCalcRule_LiborFRA :				/* DVP440 - RAK - 970425 */
	{
		SCE_NPV_ST	sceNpvSt;
		DATETIME_T	nullDate;
		memset(&nullDate, 0, sizeof(DATETIME_T));

		*price = quote;

		/* REF053 - Call SCECON function */
		if (priceArgStp != (FIN_PRICEARG_STP)NULL &&
		    CMP_PRICE(priceArgStp->costQuote, 0.0) != 0 &&
                    DATETIME_CMP(priceArgStp->expirDate, nullDate) != 0)
		{
		     SET_PRICE(instrPtr,   A_Instr_RedempQuote, priceArgStp->costQuote);
		     /* REF3730 - RAK - 990604 */
		     /* SET_DATETIME(instrPtr, A_Instr_EndDate,     priceArgStp->expirDate); */
		     SET_DATE(instrPtr, A_Instr_EndDate, priceArgStp->expirDate.date);

		     ret = SCE_DF2NPV(GET_ID(instrPtr, A_Instr_Id), instrPtr, NULLDYNST,
				              hierHead, priceDate, NULL, &sceNpvSt);

		     if (ret == RET_SUCCEED)
			*price = sceNpvSt.price;
		}
		else
			ret = RET_GEN_ERR_INVARG;
		break;
	}

	/* --------------------------------- */
	/* BEGIN DVP124 -       RAK - 960606 */
	/* quote = 100 - yield to maturity   */
	/* price depend on yield to maturity */
	case PriceCalcRule_OldAustralianFuture :
	case PriceCalcRule_FlexibleAustralianFuture: /* PMSTA15205 - DDV - 121113 - New priceCalcRule */
	{
		/* Australian bond is a 10 years, 12 % notional bond */	/* BUG147 */
        /* REF9082 - TEB - 030618 */
        SCE_CallAustralianBond_YTM2Price(quote, price, priceCalcRule, instrPtr);  /* PMSTA15205 - DDV - 121113 - New parameters for Australian Future (flxible) */ /* PMSTA16032-JPP-130304 */
		(*price)/=100.0;

		ret = RET_SUCCEED;
		break;
	}
	/* END DVP124 - RAK - 960606 */
	/* ------------------------- */

	/* price = quote * priceCalculationFactor */
	case PriceCalcRule_PriceCalculationFactor: /* DVP193 - XDI */
	{
		DBA_DYNFLD_STP instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
		NUMBER_T       factor;

		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     priceDate);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_PriceCalculationFactor);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		if (FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead) != RET_SUCCEED)
		{
			factor = 1.0;
			/* In log file, missing chrono is signaled */
		}
		else
		{
			/* REF11704 - TGU - 060419 - Change datatype */
			factor = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		*price = quote * factor;

		ret = RET_SUCCEED;
		break;
	}

	/* DVP510 - XDI - 970624 */
	/* Price = Quote / 10000 */
	case PriceCalcRule_BasisPoints :
	   	*price = quote / 10000.0;
		ret = RET_SUCCEED;
		break;

	/* REF11163 - TEB - 050616 */
	/* Bonds quoted in units */
	case PriceCalcRule_QuoteInUnit:
	{
		/* REF11163 - TEB - 050713 */
		/* Take in account the accrued interest... because client wasnt happy :'( */
		DBA_DYNFLD_STP   accrInter;
		char             calcAccrInterFlg;
		FLAG_T           fullCoupFlg;
		FUSDATERULE_ENUM fusDateRule;

		if ((accrInter = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

		/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
			fusionSwitchDate == MAGIC_END_DATE )
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
		}
		else
		{
			if (DATE_Cmp(priceDate.date, fusionSwitchDate) < 0)
			{
				GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
			}
			else
			{
				GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
			}
		}

		if (fusDateRule == FusDateRule_None)
			calcAccrInterFlg = FALSE;
		else
			calcAccrInterFlg = TRUE;

		/* REF11842 - RAK - 060810 */
		if (GET_FLAG(instrPtr, A_Instr_AccruedIntFlg) == /*FALSE*/TRUE) /* PMSTA05385-CHU-080128 */
		{
			ret = FIN_UnitAccrInter(priceDate, instrId, instrPtr,  fusDateRule, fullCoupFlg, calcAccrInterFlg,
                                AccrInterMethod_Default, priceDate,
								AccrRule_None,
								NULLDYNST, accrInter, hierHead, TRUE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

			if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
				ret = RET_SUCCEED;
		}


		if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == TRUE ||
		    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0.0)
			*price = quote -
					 GET_NUMBER(accrInter, UnitInter_UnitAccrInter); /* REF11163 - TEB - 050713 */
		else
			*price = (quote / GET_PRICE(instrPtr,A_Instr_FaceValue)) -
				     GET_NUMBER(accrInter, UnitInter_UnitAccrInter); /* REF11163 - TEB - 050713 */

		ret = RET_SUCCEED;
		FREE_DYNST(accrInter, UnitInter);
		break;
	}

	/* PMSTA-32157 - SILPA - 180905 */
	case PriceCalcRule_PortfolioSpecificPrice:
		*price = quote;
		ret = RET_SUCCEED;
		break;


	default :
		*price = quote;

		/* BUG257 */
		if (instrPtr == NULLDYNST) instrCd[0] = END_OF_STRING;
		else strcpy(instrCd, GET_CODE(instrPtr, A_Instr_Cd));
		ret = RET_FIN_ERR_INVDATA;
		MSG_SendMesg(ret, 1, FILEINFO, "FIN_QuoteToPrice", instrCd, "priceCalcRule");
		break;

	}  /* end switch */

	/* REF2158 - DDV - 980514 */
	*price = CAST_PRICE(*price);

	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_RatePrice()
**
**  Description :   Search price information at received reference date
**                  for rate in received currency.
**
**  Arguments   :   refCurrId    reference currency for the rate
**                  refDateTime  reference date
**                  prPtr        pointer on price structure, will be filled
**
**  Return      :   RET_SUCCEED, or error code
**
**  Modif.      :   REF5248 - RAK - 001005
**
*************************************************************************/
RET_CODE FIN_RatePrice(ID_T              refCurrId,
		               DATETIME_T        refDateTime,
		               DBA_DYNFLD_STP    prPtr,
                       DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP getArg=NULLDYNST, ratePtr=NULLDYNST;
	RET_CODE       ret;

	if (prPtr == NULLDYNST)
	{
	   	MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_RatePrice", "price pointer");
		return(RET_GEN_ERR_INVARG);
	}

	if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((ratePtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
	{
		FREE_DYNST(getArg, Get_Arg);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(getArg,   Get_Arg_RefCurrId, refCurrId);
	SET_ENUM(getArg, Get_Arg_NatEn,     (ENUM_T) InstrNat_Rate);

	if (DBA_Get2(Instr, UNUSED, Get_Arg, getArg, A_Instr, &ratePtr,
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/* REFRAK - 990304 - New message "plus joli" */
		char 		    *msgTxt=NULL, msgOK=FALSE;
		DBA_DYNFLD_STP	currPtr=NULLDYNST;
        FLAG_T          freeFlag=FALSE;

        /* REF5248 - RAK - 001005 */
        /* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */
		/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
        if (DBA_GetCurrById(GET_ID(getArg, Get_Arg_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
        {
		    if ((msgTxt = (char *) CALLOC(128, sizeof(char))) != (char*)NULL)
			{
				sprintf(msgTxt, "default rate missing for currency %s",
                        GET_CODE(currPtr, A_Curr_Cd));
	   		    MSG_SendMesg(RET_GEN_ERR_INVARG, 4, FILEINFO,
				             "FIN_RatePrice", msgTxt);
				FREE(msgTxt);
			    msgOK = TRUE;
            }
		}

		if (msgOK == FALSE)
		{
	   		MSG_SendMesg(RET_GEN_ERR_INVARG, 4, FILEINFO,
				         "FIN_RatePrice", "missing default rate");
		}

        if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
		FREE_DYNST(ratePtr, A_Instr);
		FREE_DYNST(getArg, Get_Arg);
		return(RET_GEN_ERR_INVARG);
	}

	ret = FIN_InstrPrice(GET_ID(ratePtr, A_Instr_Id), ratePtr, refDateTime, NULLDYNST,
                         0, NULL, NULLDYNST, NULLDYNST, hierHead, prPtr, FALSE);	/* DVP440 */ /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

	FREE_DYNST(getArg, Get_Arg);
	FREE_DYNST(ratePtr, A_Instr);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SelectInstrPrice()
**
**  Description :   Select all instr price for a instrument
**
**  Arguments   :   instrId       instrument Id
**                  refDatetime   Valuation date
**                  hierHead      hierarchy (ExtPos hierarchy only)
**                  priceTab	  array of instrument price
**                  priceNbr	  number of element in array
**                  allocPrice    define if array has been allocated
**
**  Return      :   instrument price array
**
**  Modif       :   DVP344 - XDI - 970218
**  Modif       :   DVP440 - RAK - 970501
**		            REF3219 - SSO - 990125
**		            REF3985 - SSO - 990927
**		            REF4295 - SSO - 000329
**					PMSTA06487 - RAK - 080529
**
*************************************************************************/
STATIC RET_CODE FIN_SelectInstrPrice( ID_T              instrId,
		                              DATETIME_T        refDateTime,
									  FLAG_T			selOnlyExdValPricePeriodFlg, /* PMSTA06487 - RAK - 080529 */
		                              DBA_HIER_HEAD_STP hierHead,
		                              DBA_DYNFLD_STP    **priceTab,
		                              int               *priceNbr,
		                              FLAG_T            *allocPrice)
{
	DBA_DYNFLD_STP  	selArgPtr=NULLDYNST;
	RET_CODE        	ret=RET_SUCCEED;
	FLAG_T			    selectFromDb = FALSE, stopSearchFlg = FALSE;
				        /* olderPriceExistFlg = FALSE; */
	int			        i, j, valNbr = 0, extValNbr = 0, validity,
                        allPriceNbr=0, firstPrice = 0;
	DBA_DYNFLD_STP    	*allPriceTab;
    DBA_DYNFLD_STP      domainPtr;
	DBA_DYNFLD_ST     	instrIdDynSt;
	DATE_T	       		currentDate;
	DATETIME_T		    valDateTime, extValDateTime;

	/* REF3985 - SSO - 990927 : flags to indicate that (ext) val period is in hier but with hole */
	FLAG_T			    holeInHierValPerFlg = FALSE,
                        holeInHierExtValPerFlg = FALSE,
				        selectExtPeriodOnly = FALSE;            /* REF3985 - SSO - 990927 : to optimize selects */
	DATETIME_T		    begPerDate, endPerDate,			        /* period covered by price */
				        begCovPerHierDate, endCovPerHierDate;	/* period covered by hier */

	memset(&begCovPerHierDate, 0, sizeof(DATETIME_T));
	memset(&endCovPerHierDate, 0, sizeof(DATETIME_T));

	DATE_START_TIMER(6, TIMER_MASK_XDI);
	/* DVP440 - RAK - 970501 */
	/* if refDateTime is future, seach today's price */
	currentDate = DATE_CurrentDate();
	if (refDateTime.date > currentDate)
		refDateTime.date = currentDate;

	valDateTime.date    = 0;
	valDateTime.time    = 0;
	extValDateTime.date = 0;
	extValDateTime.time = 0;

	*allocPrice = FALSE;

	/* Compute begin date for validity and extvalidity */
	GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
	valDateTime.date = DATE_Move(refDateTime.date, (-1) * validity, Day);

    GEN_GetApplInfo(ApplExtPricePeriodValidity, &validity);
	extValDateTime.date = DATE_Move(refDateTime.date, (-1) * validity, Day);

    memset(&instrIdDynSt, 0 ,sizeof(instrIdDynSt));
	SET_ID((&instrIdDynSt), 0, instrId);

	/* PMSTA06487 - RAK - 080520 - New case -> select only extended period */
	if (selOnlyExdValPricePeriodFlg == TRUE)
	{
		selectFromDb = TRUE;
		selectExtPeriodOnly = TRUE;
	}
	else
	{
		if (hierHead == (DBA_HIER_HEAD_STP) NULL)
		{
			selectFromDb = TRUE;
		}
		else if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead,
			 		                                A_InstrPrice,
							                        A_InstrPrice_InstrId,
	                                                instrIdDynSt,
			 		                                FALSE, /* copyRecFlag */
			 		                                NULLFCT, NULLDYNST, NULLFCT, FALSE,
			 		                                &allPriceNbr,
			 		                                &allPriceTab)) != RET_SUCCEED)
		{
			selectFromDb = TRUE;
		}
		else if (allPriceNbr == 0)
		{
			FREE(allPriceTab); /* REF666 - XDI - 971017 */
			selectFromDb = TRUE;

            /* WEALTH-10009 - Deepthi - 20240701 */
            domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

            if (domainPtr != NULLDYNST && (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo))
            {
                selOnlyExdValPricePeriodFlg = TRUE;
                selectExtPeriodOnly = TRUE;
            }
		}
		else
		{
			i = 0;
			while (i<allPriceNbr &&
		       GET_ID(allPriceTab[i], A_InstrPrice_InstrId) != instrId)
				i++;

			/* INIT NB: there's a trouble if the val period is ZERO! */
			begCovPerHierDate.date = refDateTime.date;
			endCovPerHierDate.date = refDateTime.date;

			/* search first valid price for the instrument */
			while (i < allPriceNbr &&
               GET_ID(allPriceTab[i], A_InstrPrice_InstrId) == instrId &&
		       DATETIME_CMP(GET_DATETIME(allPriceTab[i], A_InstrPrice_QuoteDate),
		                    refDateTime) > 0)
			{
				/* PMSTA-30132 - DDV - 180319 - Check cover period also on more recent prices */
				begPerDate = GET_DATETIME(allPriceTab[i], A_InstrPrice_BegCoveredPerDate);
				endPerDate = GET_DATETIME(allPriceTab[i], A_InstrPrice_EndCoveredPerDate);

				/* coverage updating */
				if ((DATETIME_CMP(begCovPerHierDate, begPerDate) >= 0 && DATETIME_CMP(begCovPerHierDate, endPerDate) <= 0)
		        || (DATETIME_CMP(endCovPerHierDate, begPerDate) >= 0 && DATETIME_CMP(endCovPerHierDate, endPerDate) <= 0) )
				{
    				if (DATETIME_CMP(begCovPerHierDate, begPerDate) > 0)
    					begCovPerHierDate = begPerDate;

    				if (DATETIME_CMP(endCovPerHierDate, endPerDate) < 0)
    					endCovPerHierDate = endPerDate;
				}

				i++;
			}
			firstPrice = i;

			/* Analyse existing price :
			if one or more price in valid_period => return it.
			if no price in valid_period and one or more in ext_valid_period => return it.
			if one price older as ext_valid_period return a empty array
			else select in database */

			/* REF3985 - SSO - 990927 : rewrote to avoid bugs due to holes in hierarchy (regarding loading dates) */

			/* IMPORTANT: Hole detection currently doesn't sort end loading dates (A_InstrPrice_EndCoveredPerDate)
		    this is ok while only 2 load periods max. can occur. For example:
					quote
                1st price:    |---¦-----------|

            |-------------¦-| 2nd price


                |---¦------------|	3rd price

			-> in this case, an hole will be detected altough there isn't one...

			This can't happen while load pos are loading prices on one or 2 periods (but not 3),
				and prices aren't added in hierarchy after load (with non-null special price fields)

			*/

			while (i<allPriceNbr &&
		       stopSearchFlg == FALSE &&
		       /* olderPriceExistFlg == FALSE &&  SSO:  do not stop loop to compute ext period coverage */
		       holeInHierValPerFlg == FALSE &&	/* REF3985 - SSO - 990927 */
		       holeInHierExtValPerFlg == FALSE
                   /*GET_ID(allPriceTab[i], A_InstrPrice_InstrId) == instrId*/)
			{
				/* skip prices if no loading info avaible (filled in DBA_LoadPos) */
				if (IS_NULLFLD(allPriceTab[i], A_InstrPrice_BegCoveredPerDate) == TRUE
					|| IS_NULLFLD(allPriceTab[i], A_InstrPrice_EndCoveredPerDate) == TRUE)
				{
					i++;
					continue;
				}

				begPerDate = GET_DATETIME(allPriceTab[i], A_InstrPrice_BegCoveredPerDate);
				endPerDate = GET_DATETIME(allPriceTab[i], A_InstrPrice_EndCoveredPerDate);

				/* coverage updating */
				if ((DATETIME_CMP(begCovPerHierDate, begPerDate) >= 0 && DATETIME_CMP(begCovPerHierDate, endPerDate) <= 0)
		        || (DATETIME_CMP(endCovPerHierDate, begPerDate) >= 0 && DATETIME_CMP(endCovPerHierDate, endPerDate) <= 0) )
				{
    				if (DATETIME_CMP(begCovPerHierDate, begPerDate) > 0)
    					begCovPerHierDate = begPerDate;

    				if (DATETIME_CMP(endCovPerHierDate, endPerDate) < 0)
    					endCovPerHierDate = endPerDate;
				}

				/* price selecting */
				if (DATETIME_CMP(GET_DATETIME(allPriceTab[i], A_InstrPrice_QuoteDate),
			                 valDateTime) >= 0)
				{
					/* hole detection */
					if (DATETIME_CMP(begCovPerHierDate, endPerDate) > 0 || DATETIME_CMP(endCovPerHierDate, begPerDate) < 0)
					{
						holeInHierValPerFlg = TRUE; /* stop loop */
						continue;
					}
					valNbr++;
				}
				else
				{
					/* validity testing */
					if (DATETIME_CMP(GET_DATETIME(allPriceTab[i], A_InstrPrice_QuoteDate),
				                 extValDateTime) >= 0)
					{
						/* hole detection  */
						if (DATETIME_CMP(begCovPerHierDate, endPerDate) > 0 || DATETIME_CMP(endCovPerHierDate, begPerDate) < 0)
						{
							holeInHierExtValPerFlg = TRUE; /* stop loop */
							continue;
						}

						extValNbr++;

						if (valNbr > 0)	/* extended is found and already for not-extended... */
							stopSearchFlg = TRUE;
					}
				}
				i++;
			}

			/* if hole or insufficent coverage, we must select from db. */
			if (holeInHierValPerFlg == TRUE
				|| (DATETIME_CMP(endCovPerHierDate, refDateTime) < 0)
				|| (DATETIME_CMP(begCovPerHierDate, valDateTime) > 0) )
			{
				selectFromDb = TRUE;
				*priceNbr = 0;
			}
			else
			{
				if (valNbr > 0)
				{
					/* val period is necessarly covered (see above tests) */
					*priceNbr = valNbr;
				}
				else
				{
					/* is ext val period covered ? */
					if (holeInHierExtValPerFlg == TRUE
						|| DATETIME_CMP(begCovPerHierDate, extValDateTime) > 0)
					{
						selectFromDb = TRUE;
						selectExtPeriodOnly = TRUE;
						*priceNbr = 0;
					}
					else
					{
						*priceNbr = extValNbr; /* NB: it can be equal to ZERO */
					}
				}
			}

			if (selectFromDb == FALSE)
			{
				if (*priceNbr > 0)
				{
					/* alloc tab to return, copy pointeur from priceTabTmp */

					if ((*priceTab=(DBA_DYNFLD_STP *) CALLOC(*priceNbr, sizeof(DBA_DYNFLD_STP)))== NULL)
					{
						FREE(allPriceTab);
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}

					/* REF4295 - SSO - 000329 bug: NULL records in priceTab !!! rewrote this loop */
					i = 0; j = 0;  /* REF3985 - SSO - 991012 : skip dates which must be ignored  */
					while (j<*priceNbr)
					{
						if (IS_NULLFLD(allPriceTab[firstPrice+i], A_InstrPrice_BegCoveredPerDate) == FALSE
							&& IS_NULLFLD(allPriceTab[firstPrice+i], A_InstrPrice_EndCoveredPerDate) == FALSE)
						{
							(*priceTab)[j]=allPriceTab[firstPrice+i];
							j++;
						}
						i++;
					}
				}
				else
				{
					/* *priceNbr is ZERO */
					*priceTab = NULLDYNSTPTR;
				}
			}

			FREE(allPriceTab);
		}
	}

	/* Load from database */
	if (selectFromDb == TRUE)
	{
	    /* Get valuation History record corresponding with rule and date */
	    if ((selArgPtr = ALLOC_DYNST(Sel_Arg)) == NULLDYNST)
		    MSG_RETURN(RET_MEM_ERR_ALLOC);

	    SET_ID(selArgPtr,       Sel_Arg_Id1,         instrId);
	    SET_FLAG(selArgPtr,     Sel_Arg_DistinctFlg, TRUE);
	    SET_DATETIME(selArgPtr, Sel_Arg_TillDate,    refDateTime);

	    /* REF3985 - SSO - 990927 : optimize db call (if the hole is only in ext period skip this call) */
	    if (selectExtPeriodOnly == FALSE)
	    {
		    SET_DATETIME(selArgPtr, Sel_Arg_FromDate, valDateTime);

		    if ((DBA_Select2(InstrPrice, UNUSED, Sel_Arg, selArgPtr,
				             A_InstrPrice, priceTab, UNUSED, UNUSED,
				             priceNbr, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        SYSNAME_T entSqlName;
		        strcpy(entSqlName, DBA_GetDictEntitySqlName(InstrPrice));
		        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			        entSqlName, GET_ID(selArgPtr, Sel_Arg_Id1));	/* ROI - 000706 - REF4979 */
		        FREE_DYNST(selArgPtr, Sel_Arg);
		        return(RET_DBA_ERR_NODATA);
		    }
	    }

	    /* REF944 - XDI - 971125 */
        if (*priceNbr == 0)
	    {
		    /* Compute begin date for extended validity period */
		    SET_DATETIME(selArgPtr, Sel_Arg_FromDate, extValDateTime);

            if ((DBA_Select2(InstrPrice, UNUSED, Sel_Arg, selArgPtr,
                             A_InstrPrice, priceTab, UNUSED, UNUSED,
                             priceNbr, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        SYSNAME_T entSqlName;
		        strcpy(entSqlName, DBA_GetDictEntitySqlName(InstrPrice));
		        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             	     entSqlName, GET_ID(selArgPtr, Sel_Arg_Id1));		/* ROI - 000706 - REF4979 */
		        FREE_DYNST(selArgPtr, Sel_Arg);
		        return(RET_DBA_ERR_NODATA);
		    }

            /* PMSTA-30132 - DDV - 180319 - Specifiy that these prices results from additionnal load, to allow optimisation in FIN_InstrPriceByFreq function */
            for (i=0; i < *priceNbr; i++)
                SET_FLAG((*priceTab)[i], A_InstrPrice_ExtendedLoadFlg, TRUE);
	    }

	    FREE_DYNST(selArgPtr, Sel_Arg);
	    *allocPrice = TRUE;
	}

	DATE_STOP_TIMER(6, TIMER_MASK_XDI);
	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_GetPtfInstrPrice()
**
**  Description :   Get portfolio instr price for a instrument
**
**  Arguments   :   instrId       instrument Id
**					ptfId		  portfolio Id
**                  refDatetime   Valuation date
**                  hierHead      hierarchy (ExtPos hierarchy only)
**                  aPortfolioInstrPricePtr	  portfolio instrument price
**                  priceNbr	  number of element in array
**                  allocPrice    define if price has been allocated
**
**  Return      :   portfolio instrument price
**
**  Modif       :   PMSTA-32157 - SILPA - 180905
**
*************************************************************************/

STATIC RET_CODE FIN_GetPtfInstrPrice(ID_T instrId,
									 ID_T ptfId,
									 DATETIME_T refDateTime,
									 DBA_HIER_HEAD_STP hierHead,
									 DBA_DYNFLD_STP *aPortfolioInstrPricePtr,
									 int *priceNbr,
									 FLAG_T *allocPrice)
{
	DBA_DYNFLD_STP  	shPortfolioInstrPricePtr = NULLDYNST, admArgPtr = NULLDYNST;
	RET_CODE        	ret = RET_SUCCEED;
	FLAG_T			    selectFromDb = FALSE;
	int					allPriceNbr = ZERO_ID, i = ZERO_ID;
	DBA_DYNFLD_STP    	*allPriceTab = NULLDYNSTPTR;
	DATE_T	       		currentDate;
	DBA_DYNFLD_ST     	instrIdDynSt;
	DbiConnectionHelper dbiConnHelper;
	MemoryPool			mp;

	memset(&instrIdDynSt, 0, sizeof(instrIdDynSt));
	SET_ID((&instrIdDynSt), 0, instrId);

	/* if refDateTime is future, seach today's price */
	currentDate = DATE_CurrentDate();
	if (refDateTime.date > currentDate)
		refDateTime.date = currentDate;

	*allocPrice = FALSE;
	*priceNbr = 0;

	admArgPtr = mp.allocDynst(FILEINFO,Adm_Arg);

	SET_ID(admArgPtr, Adm_Arg_Id, ptfId)
	SET_ID(admArgPtr, Adm_Arg_UserId, instrId);
	SET_DATETIME(admArgPtr, Adm_Arg_Date, refDateTime);

	if (hierHead == (DBA_HIER_HEAD_STP)NULL)
	{
		selectFromDb = TRUE;
	}
	else if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead,
		A_PortfolioInstrPrice,
		A_PortfolioInstrPrice_InstrId,
		instrIdDynSt,
		FALSE,
		FIN_FilterPtfInstrQuoteDate,
		admArgPtr,
		FIN_CmpPtfInstrQuoteDate,
		FALSE,
		&allPriceNbr,
		&allPriceTab)) != RET_SUCCEED)
	{
		selectFromDb = TRUE;
	}
	else if (allPriceNbr == 0)
	{
		selectFromDb = TRUE;
	}

	if(RET_SUCCEED == ret)
		mp.ownerPtr(allPriceTab);

	/* Search price for an instrument based on the portfolio and quote date */
	if (selectFromDb == FALSE && allPriceNbr > 0 && *allPriceTab != NULLDYNSTPTR)
	{
		for (i = 0; i < allPriceNbr; i++)
		{
			if (DATETIME_CMP(GET_DATETIME(allPriceTab[i], A_PortfolioInstrPrice_QuoteDate), refDateTime) > 0)
			{
				break;
			}
		}

		if (i == 0)
			selectFromDb = TRUE;
        else
        {
            *aPortfolioInstrPricePtr = allPriceTab[i - 1];
            (*priceNbr)++;  /* PMSTA-32764  - SILPA - 181010 */
        }

	}

	/* Load from database */
	if (selectFromDb == TRUE)
	{

		shPortfolioInstrPricePtr = mp.allocDynst(FILEINFO, S_PortfolioInstrPrice);

		*aPortfolioInstrPricePtr = mp.allocDynst(FILEINFO, A_PortfolioInstrPrice);

		*allocPrice = TRUE;

		/* Fill the short portfolio instrument structure for the input */
		SET_ID(shPortfolioInstrPricePtr, S_PortfolioInstrPrice_PtfId, ptfId);
		SET_ID(shPortfolioInstrPricePtr, S_PortfolioInstrPrice_InstrId, instrId);
		SET_DATETIME(shPortfolioInstrPricePtr, S_PortfolioInstrPrice_QuoteDate, refDateTime);

		ret = dbiConnHelper.dbaGet(PortfolioInstrPrice, DBA_ROLE_GET_PTF_INSTR_PRICE, shPortfolioInstrPricePtr, aPortfolioInstrPricePtr);

		if (ret == RET_SUCCEED)
		{
			(*priceNbr)++;
			if ((ret = DBA_AddHierRecord(hierHead, *aPortfolioInstrPricePtr, A_PortfolioInstrPrice, TRUE, HierAddRec_ForceInsert)) != RET_SUCCEED)
			{
				return (ret);
			}
			mp.removeDynStp(*aPortfolioInstrPricePtr);
		}
		else
		{
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(PortfolioInstrPrice));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(shPortfolioInstrPricePtr, S_PortfolioInstrPrice_InstrId));
			*allocPrice = FALSE;
			return(RET_DBA_ERR_NODATA);
		}
	}

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_SetInstrPrice()
**
**  Description :   Set all value in structure instr price using val_rule
**
**  Arguments   :   instrPtr      instrument structure pointer
**                  refDatetime   Valuation date
**                  bestPricePtr  best price found structure pointer
**		            valRule       val rule to use (VALRULE_ENUM)
**                  pricePtr	  structure to set
**
**  Return      :   instrument price array
**
**  Modif.      :   DVP344 - XDI - 970220
**  Modif.      :   DVP440 - RAK - 970424
**  Modif.      :   DVP458 - RAK - 970505
**  Modif.      :   REF1048 - RAK - 971205
**  Modif.      :   REF11163 - TEB - 050616
**
*************************************************************************/
STATIC RET_CODE FIN_SetInstrPrice(DBA_DYNFLD_STP      instrPtr,
		                            DBA_DYNFLD_STP    extPosPtr,
	                                DATETIME_T        refDateTime,
	                                DBA_DYNFLD_STP    bestPricePtr,
	                                VALRULE_ENUM      valRule,
			                        FIN_PRICEARG_STP  priceArgStp,
	                                DBA_DYNFLD_STP    pricePtr,
			                        DBA_HIER_HEAD_STP hierHead)
{
	PRICE_T            dfltPrice=1.0, price;
	PRICECALCRULE_ENUM  priceCalc;
	RET_CODE            ret;
	FLAG_T              priceCalcFlag = TRUE;  /* PMSTA-43592 - VSW - 310321 */

	/* DVP510 - XDI - 970626 */
	/*	DEV1055 - CSA - 991104
		Obsolete
	if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Swap &&
            GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Theo)
		valRule = ValRule_Composite;
	*/

	switch(valRule)
	{
	case ValRule_Quote :
		if (bestPricePtr != NULLDYNST)
		{
		    COPY_DYNST(pricePtr, bestPricePtr, A_InstrPrice);
		    ret = RET_SUCCEED;

		    /* REF1208 - Use price calculation rule from instrPrice        */
		    /*         - add nature PriceCalcRule_TCN                      */
		    /*         - test date for LiborFRA and EuroFutureContract too */
		    priceCalc = (PRICECALCRULE_ENUM)
				        GET_ENUM(pricePtr, A_InstrPrice_PriceCalcRuleEn);
			DBA_DYNFLD_STP	mainDomain = NULL;
			/* PMSTA-43592 - VSW - 310321 - Code developed to ensure that the System does not recalculate the Price from the Quote */
			/*   for the price calc rule of PriceCalcRule_QuotedWithAI and provided there is no Clean Price for the Valuation date  */
			mainDomain = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

			if (mainDomain != NULLDYNST)	/* PMSTA-43592 - VSW - 310321 */
			{
				if ((DATETIME_CMP(GET_DATETIME(mainDomain, A_Domain_CalcRefDate),
					GET_DATETIME(pricePtr, A_InstrPrice_QuoteDate)) == 1) &&
					priceCalc == PriceCalcRule_QuotedWithAI)
				{
					priceCalcFlag = FALSE;
				}
			}
		    if ((priceCalc == PriceCalcRule_ActuarialYield ||	/* DVP458 */
				 priceCalc == PriceCalcRule_ChileanBond ||	/* PMSTA-35405 - RAK - 190621 - one year later last report */
				 priceCalc == PriceCalcRule_NPV ||			/* PMSTA-35405 - RAK - 190621 - one year later last report */
			     priceCalc == PriceCalcRule_Discounted ||
			     priceCalc == PriceCalcRule_WithAddOnRate ||
			     priceCalc == PriceCalcRule_QuotedWithAI ||
			     priceCalc == PriceCalcRule_QuotedInUnitWithAI ||
			     priceCalc == PriceCalcRule_AnnualRate ||
			     priceCalc == PriceCalcRule_QuoteLife ||
			     priceCalc == PriceCalcRule_OldAustralianFuture ||
				 priceCalc == PriceCalcRule_FlexibleAustralianFuture || /* PMSTA15205 - DDV - 121113 - New priceCalcRule */
			     priceCalc == PriceCalcRule_InFineYield ||
			     priceCalc == PriceCalcRule_LiborFRA ||
			     priceCalc == PriceCalcRule_EuroFutureContract ||
			     priceCalc == PriceCalcRule_TCN ||
				 priceCalc == PriceCalcRule_QuoteInUnit /* REF11163 - TEB - 050616 */ ||
				 priceCalc == PriceCalcRule_None /* PMSTA06680-CHU-090420 */) &&
			     DATETIME_CMP(refDateTime,
				              GET_DATETIME(pricePtr, A_InstrPrice_QuoteDate)) != 0)
		    {
		        if ((ret = FIN_QuoteToPrice((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
                                            GET_ID(instrPtr, A_Instr_Id), instrPtr,
						                    refDateTime, priceArgStp,
					                        GET_PRICE(pricePtr, A_InstrPrice_Quote),
						                    &price, hierHead)) == RET_SUCCEED)
			    {
					if (priceCalcFlag == TRUE)	/* PMSTA-43592 - VSW - 310321 */
					{
						SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(price));
					}
				} /* REF3288 - SSO - 990205 */
		    }
		}
		else
		    ret = RET_FIN_INFO_NOPRICE;

		break;

	/* not quoted, default 0 or 1, ValRule_Quote0 and */
	/* ValRule_Quote1 treated together, just default  */
	/* value is different (no break)                  */
	case ValRule_Quote0 :
		dfltPrice = 0.0;
        /* fallthrough */
	/* not quoted, default 1 */
	case ValRule_Quote1 :
		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,     dfltPrice);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

		if (dfltPrice == 0.0)
		{
		    SET_PRICE(pricePtr, A_InstrPrice_Quote, dfltPrice);
		}
		else
		{
		    PRICE_T quote;
		    /* REF3836 - SSO - 990830 PriceCalcRule_None -> GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) */
		    FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - 020130 - CSY */
                GET_ID(instrPtr, A_Instr_Id), instrPtr,
				             refDateTime, NULL, dfltPrice, &quote, hierHead);	/* BUG195 */
		    SET_PRICE(pricePtr, A_InstrPrice_Quote, quote);
		}
		ret = RET_SUCCEED;
		break;

	/* calculated via its component */
	case ValRule_Composite :
        /* REF5358 - RAK - 010130 */
        if (GET_ENUM(instrPtr, A_Instr_IdxCalcRuleEn) == IdxCalcRule_PctValue)
            ret = RET_SUCCEED;
        else
		    ret = FIN_InstrComposite(instrPtr, refDateTime, pricePtr, hierHead, extPosPtr);
		break;

	/* evaluated via theoritical price */
	case ValRule_Theo :
		ret = FIN_InstrTheoPrice(instrPtr, refDateTime, priceArgStp, pricePtr, extPosPtr, hierHead);
		break;

	/* Debt valuation ?? */
	case ValRule_Debt :
		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,     1.0);
		SET_PRICE(pricePtr,   A_InstrPrice_Quote,     1.0);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
		ret = RET_SUCCEED;
		break;

	/* TCNs valuation */
	case ValRule_RefInstr :
		ret = FIN_InstrRefInstrPrice(instrPtr, extPosPtr, refDateTime, pricePtr, hierHead);
		break;

	/* Script ?? */
	case ValRule_Script :
	case ValRule_SimpleScript : /* REF2338 - DDV - 981028 */
		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,     1.0);
		SET_PRICE(pricePtr,   A_InstrPrice_Quote,     1.0);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
		ret = RET_SUCCEED;
		break;

	/* Instrument takes the price of its parent instrument */
	/* (in case of risk valuation), otherwise 1            */
	case ValRule_ParInstr :
		SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
		SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
		SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);
		SET_PRICE(pricePtr,   A_InstrPrice_Price,     1.0);
		SET_PRICE(pricePtr,   A_InstrPrice_Quote,     1.0);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn,
		    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
		ret = RET_SUCCEED;
		break;

	default :
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
			     "FIN_InstrPrice", GET_CODE(instrPtr, A_Instr_Cd), "valuation rule");
		ret = RET_FIN_ERR_INVDATA;
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrTheoricPrice()
**
**  Description :   This function compute instrument price according
**					to script associated to selected valuation rule
**					element. There is nevertheless a flat on instruments
**					of type Swap and Forex Swap.
**
**  Arguments   :   hierHead		Current hierarchiy header pointer
**					refDate			Reference date
**					extPos			Current record to ExtPos dynamic structure
**					valRule_Id		Valuation rule identifier
**					valRuleElt		Valuation rule element
**					instrPtr		Current instrument pointer
**					instrPrice		Dynamic structure A_InstrPrice to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 20101999
**
*************************************************************************/
STATIC RET_CODE FIN_InstrTheoricPrice(	DBA_HIER_HEAD_STP	hierHead,
										DATETIME_T			refDate,
										DBA_DYNFLD_STP		extPos,
										ID_T				valRule_Id,
										DBA_DYNFLD_STP		valRuleElt,
										DBA_DYNFLD_STP		instrPtr,
										DBA_DYNFLD_STP		instrPrice)
{
	/*	Declaration of variables	*/
	INSTRNAT_ENUM	instrNature;
	RET_CODE	ret;

	/*	Initialization of A_InstrPrice	*/
	FIN_InitInstrPrice(	refDate,
						valRule_Id,
						valRuleElt,
						instrPtr,
						instrPrice);

	/*	Get the nature of the instrument	*/
	instrNature	= (INSTRNAT_ENUM)GET_ENUM(instrPtr,A_Instr_NatEn); /* REF7264 - CSY - 020130 */

	/*
		If the type of the instrument is Swap or Forex Swap,
		then call FIN_InstrTheoricPriceSwap,
		else call FIN_InstrTheoricPriceOthers
	*/
	switch(instrNature)
	{
	case	InstrNat_Swap:
	case	InstrNat_ForexSwaps:
		ret	=	FIN_InstrTheoricPriceSwap(	hierHead,
											extPos,
											valRuleElt,
											instrNature,
											instrPtr,
											&instrPrice[A_InstrPrice_Price]);
		break;

	default:	/*	Others instruments	*/

        /* REF5711 - RAK - 01313 */
        /* No price for future without underlying (elsewhere Fatal error) */
        ret = RET_SUCCEED;
        if (GET_ENUM(instrPtr, A_Instr_NatEn) ==  InstrNat_Future)
        {
            DBA_DYNFLD_STP  termEvtStp=NULLDYNST;
            if ((termEvtStp = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	        {
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        ret = DBA_GetTermEvt(instrPtr, refDate.date, termEvtStp);

	        FREE_DYNST(termEvtStp, A_TermEvt);

            if (ret != RET_SUCCEED)
            {
                ret = RET_DBA_ERR_NODATA;
                MSG_SendMesg(ret, 3, FILEINFO, "FIN_InstrTheoricPrice",
                             GET_CODE(instrPtr, A_Instr_Cd), "underlying instrument");
            }
        }

        if (ret == RET_SUCCEED)
        {
		    ret	= FIN_InstrTheoricPriceOthers(hierHead,
											  refDate, /* REF10531 - TEB - 040806 */
											  extPos,
											  valRuleElt,
                                              instrPtr,
											  &instrPrice[A_InstrPrice_Price]);
        }
		break;
	}

	/*	Computation of the quote if a price was calculated	*/
	if	(ret == RET_SUCCEED)
		/*SET_PRICE(instrPrice,A_InstrPrice_Quote,GET_PRICE(instrPrice,A_InstrPrice_Price));*/
		ret	=	FIN_ComputeQuote(	hierHead,
									refDate,
									instrPtr,
									instrPrice);

	/*	Return value	*/
	return(ret);
}	/*	End function FIN_InstrTheoricPrice	*/


/************************************************************************
**
**  Function    :   FIN_InitInstrPrice()
**
**  Description :   This function initialize many fields of A_InstrPrice
**
**	Arguments	:	refDate			Reference date
**					valRule_Id		Valuation rule identifier
**					valRuleElt		Valuation rule element
**					instrPtr		Current instrument pointer
**					instrPrice		Dynamic structure A_InstrPrice to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 21101999
**
*************************************************************************/
STATIC RET_CODE FIN_InitInstrPrice(	DATETIME_T			refDate,
									ID_T				valRule_Id,
									DBA_DYNFLD_STP		valRuleElt,
									DBA_DYNFLD_STP		instrPtr,
									DBA_DYNFLD_STP		instrPrice)
{
	/*	Declaration of variables	*/
	ID_T	instrId;
	ID_T	currId;
	ID_T	valRuleEltId;

	/*	Get instrument, currency and Element of valuation rule identifiers from A_Instr	*/
	instrId	        =	GET_ID(instrPtr,A_Instr_Id);
	currId	        =	GET_ID(instrPtr,A_Instr_RefCurrId);
	valRuleEltId	=	GET_ID(valRuleElt,A_ValRuleElt_Id);

	/*	Set values into A_InstrPrice	*/
	SET_ID(			instrPrice,	A_InstrPrice_InstrId,		instrId);
	SET_ID(			instrPrice,	A_InstrPrice_CurrId,		currId);
	SET_DATETIME(	instrPrice,	A_InstrPrice_QuoteDate,		refDate);
	SET_FLAG(		instrPrice,	A_InstrPrice_DailyDfltFlg,	FALSE);
	SET_PRICE(		instrPrice,	A_InstrPrice_Quote,			0);
	SET_PRICE(		instrPrice,	A_InstrPrice_Price,			0);
	SET_FLAG(		instrPrice,	A_InstrPrice_UnicityFlg,	FALSE);
	SET_ID(			instrPrice,	A_InstrPrice_ValRuleId,		valRule_Id);
	SET_ID(			instrPrice,	A_InstrPrice_ValRuleEltId,	valRuleEltId);

	/*	Return value	*/
	return(RET_SUCCEED);
}	/*	End function FIN_InitInstrPrice	*/


/************************************************************************
**
**  Function    :   FIN_InstrTheoricBuildScript()
**
**  Description :   This function build the scipt string and generate the tree
**
**	Arguments	:	*generalContext	Pointer to the tree stored structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 25101999
**
*************************************************************************/
STATIC RET_CODE FIN_InstrTheoricBuildScript(DBA_DYNFLD_STP valRuleEltPtr, SCPT_ARG_STP *generalContext, OBJECT_ENUM *objEn)
{
	/*	Declaration of variables	*/
	DICT_ATTRIB_STP	attribStp = (DICT_ATTRIB_STP)  NULL;
	DBA_DYNFLD_STP  aScriptDef=NULLDYNST;
	DBA_DYNFLD_STP	*scriptDefTab=NULLDYNSTPTR;
	SYSNAME_T		entSqlName;
	char			*scptBuf;
	int				scriptDefNbr;
	DICT_T			objId; /* DLA - REF9089 - 030512 */
	int				i;
	RET_CODE		ret;

	/*	Memory allocation for the string of the script	*/
	if ((scptBuf = (char *) CALLOC(1, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181011 */
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/*	Memory allocation for the dynamic structure of the script	*/
	if ((aScriptDef = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
    {
        FREE(scptBuf);  /* PMSTA-14109 - 160512 - PMO */
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	/*	Initialize the dict attribute id for the script definition	*/
	attribStp = DBA_GetAttributeBySqlName(ValRuleElt, "script_definition");
	SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, attribStp->attrDictId);

	/*	Initialize the valuation rule element id	*/
	COPY_DYNFLD(aScriptDef,    A_ScriptDef,  A_ScriptDef_ObjId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

	/*	Initalize the nature field	*/
	SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

	/*	Do the database request	*/
    ret	=	DBA_Select2(	ScriptDef,
							UNUSED,
							A_ScriptDef,
							aScriptDef,
							A_ScriptDef,
							&scriptDefTab,
							UNUSED,
							UNUSED,
							&scriptDefNbr,
							UNUSED,
							UNUSED);

	/*	The database request was successfull	*/
	if	(ret == RET_SUCCEED)
	{
		/*
			Loop on all items from the recordset
			and concatenate the string value
		*/
		scptBuf[0] = END_OF_STRING;
		for (i=0; i<scriptDefNbr; i++)
		    strcat(scptBuf, GET_STRING(scriptDefTab[i], A_ScriptDef_Def));

		/*	Get the object enum of the format element	*/
		objId	=	GET_DICT(valRuleEltPtr,A_ValRuleElt_ScriptEntityDictId); /* DLA - REF9089 - 030512 */
		DBA_GetObjectEnum(objId,objEn);

		/*	Build the script tree	*/
		if (scptBuf[0] != END_OF_STRING)
		{
			ret	= SCPT_GenerateScptTree(	scptBuf,
											*(objEn),
											InternalSMode,
											PriceType, /* PMSTA-52091 - DDV - 230302 */
											generalContext);
		}
	}
	else	/*	The database request wasn't successfull	*/
	{
		/*	Send a message to explain the error	*/
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ScriptDef));
		MSG_SendMesg(	RET_DBA_ERR_NODATA, 1,FILEINFO, entSqlName, GET_ID(aScriptDef, A_ScriptDef_ObjId));
	}

	/*	We make household	*/
	FREE_DYNST(aScriptDef, A_ScriptDef);
	FREE(scptBuf);
    DBA_FreeDynStTab(scriptDefTab, scriptDefNbr, A_ScriptDef);

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_InstrTheoricBuildScript	*/


/************************************************************************
**
**  Function    :   FIN_InstrTheoricPriceOthers()
**
**  Description :   This function compute the price of a normal instrument
**
**	Arguments	:	hierHead		Pointer to the hierarchy
**					refDate			Reference date
**					extPos			Current extended position
**					fld				Field to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 25101999
**                  REF10531 - TEB - 040806
**
*************************************************************************/
STATIC RET_CODE FIN_InstrTheoricPriceOthers(	DBA_HIER_HEAD_STP	hierHead,
												DATETIME_T			refDate, /* REF10531 - TEB - 040806 */
												DBA_DYNFLD_STP		extPos,
												DBA_DYNFLD_STP		valRuleElt,
                                                DBA_DYNFLD_STP      instrPtr,
												DBA_DYNFLD_STP		fld)
{
	/*	Declaration of variables	*/
	SCPT_ARG_STP	generalContext = (SCPT_ARG_STP)NULL;
	DBA_DYNFLD_STP	theDomain=NULL;
	OBJECT_ENUM		objEn;
	RET_CODE		ret;
	DATETIME_T      tmpFromDate;

	/* Initialisation */
	tmpFromDate.date = 0;	/* REF10531 - TEB - 041209 */
	tmpFromDate.time = 0;	/* REF10531 - TEB - 041209 */

	/*	Build the tree of the script	*/
	ret	=	FIN_InstrTheoricBuildScript(valRuleElt, &generalContext, &objEn);

	/*	Get the domain pointer	*/
	theDomain = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

	/* REF10531 - TEB - 040806 */
	if (theDomain != NULLDYNST)	/* REF10531 - TEB - 041209 */
	{
		tmpFromDate = GET_DATETIME(theDomain, A_Domain_InterpFromDate);
		SET_DATETIME(theDomain, A_Domain_InterpFromDate, refDate);
	}


    /*	Exécution du script	*/
    if	(ret==RET_SUCCEED)
    {
        switch  (GET_OBJECT_CST(objEn))
        {
        case    InstrCst :
		    ret	=	SCPT_ExecScptTree(	generalContext,
									    theDomain,
									    hierHead,
									    instrPtr,
									    PriceType, /* PMSTA-52091 - DDV - 230302 */
									    fld,
										extPos); /* PMSTA14443 - DDV - 120709 */
            break;

        case    EPosCst :
		    ret	=	SCPT_ExecScptTree(	generalContext,
									    theDomain,
									    hierHead,
									    extPos,
									    PriceType, /* PMSTA-52091 - DDV - 230302 */
									    fld, 
										NULLDYNST); /* PMSTA14443 - DDV - 120709 */
            break;

    	default:
		    /*
			    The program never will go here,
			    but it is anticipated for a future
			    passage of the LINT utility ;-)
                So, we write an error message into
                the log file, and exit with an error
                code.
		    */
			if (theDomain != NULLDYNST)	/* REF10531 - TEB - 041209 */
				SET_DATETIME(theDomain, A_Domain_InterpFromDate, tmpFromDate); /* REF10531 - TEB - 040806 */
            ret =   RET_SCPT_ERR_SYNTAX;
            MSG_SendStrToLog("Error in valuation: The script has to be based solely on the extpos or the instruments.");
		    break;
        }
    }

	if (theDomain != NULLDYNST)	/* REF10531 - TEB - 041209 */
		SET_DATETIME(theDomain, A_Domain_InterpFromDate, tmpFromDate); /* REF10531 - TEB - 040806 */

	/*	Free the script structure	*/
	if	(ret==RET_SUCCEED)
		ret	=	SCPT_FreeScptTree(generalContext);

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_InstrTheoricPriceOthers	*/


/************************************************************************
**
**  Function    :   FIN_InstrTheoricPriceSwap()
**
**  Description :   This function compute the price of
**					a swap & Forex swap intruments
**
**	Arguments	:	hierHead		Pointer to the hierarchy
**					extPos			Current extended position
**					instrNature		1 for Swap OR 2 for Forex swap
**					instrPtr		Instrument pointer
**					fld				Field to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 25101999
**
**  Modifs      :   DEV1055 - CSA - 06012000
**                  REF4367 - CSA - 16052000
**                  REF8712 - TEB - 030619
**
*************************************************************************/
STATIC RET_CODE FIN_InstrTheoricPriceSwap(	DBA_HIER_HEAD_STP	hierHead,
						                    DBA_DYNFLD_STP		extPos,
						                    DBA_DYNFLD_STP		valRuleElt,
						                    INSTRNAT_ENUM		instrNature,
						                    DBA_DYNFLD_STP		instrPtr,
						                    DBA_DYNFLD_STP		fld)
{
	/*	Declaration of variables	*/
	SCPT_ARG_STP	generalContext = (SCPT_ARG_STP)NULL;
	DBA_DYNFLD_STP	leg1Ptr=NULLDYNST;
	DBA_DYNFLD_STP	leg2Ptr=NULLDYNST;
	DBA_DYNFLD_ST	fld1;
	DBA_DYNFLD_ST	fld2;
	NUMBER_T	    numLeg1=0.0;
	NUMBER_T	    numLeg2=0.0;
	NUMBER_T            numLeg=0.0;
	OBJECT_ENUM	    objEn = NullEntity;
	FLAG_T		    freeLegFlg=FALSE, freeScptFlg=FALSE; /* REF8712 - TEB - 030619 */
	RET_CODE	    ret = RET_GEN_INFO_NOACTION;

	/*	Memory allocation	*/
	memset(&fld1, 0, sizeof(DBA_DYNFLD_ST));
	memset(&fld2, 0, sizeof(DBA_DYNFLD_ST));

	/*	Split the instrument	*/
	switch	(instrNature)
	{
	case	InstrNat_Swap:
	    {
		/* ret	=	FIN_GenSplitSwap(hierHead, instrPtr,
						 &leg1Ptr, &leg2Ptr, &freeLegFlg); */
		ret	=	FIN_SplitInstrument(instrPtr, hierHead, extPos,
						            &leg1Ptr, &leg2Ptr, &freeLegFlg,
						            (NUMBER_T*)NULL);
		break;
	    }

	case	InstrNat_ForexSwaps:
	    {
		/* ret	=	FIN_GenSplitForexSwap(hierHead,instrPtr,
						    &leg1Ptr, &leg2Ptr, &freeLegFlg); */
		ret	=	FIN_SplitInstrument(instrPtr, hierHead, extPos,
						            &leg1Ptr, &leg2Ptr, &freeLegFlg,
						            (NUMBER_T*)NULL);
		break;
	    }
	default:
		/*
			The program never will go here,
			but it is anticipated for a future
			passage of the LINT utility ;-)
		*/
		break;
	}

	/*	Build the tree of the script	*/
    /*  REF4367 - CSA - 16052000    */
    if  (ret==RET_SUCCEED)
    {
	    ret	=	FIN_InstrTheoricBuildScript(valRuleElt, &generalContext, &objEn);
        /* REF8712 - TEB - 030619 */
        if (ret == RET_SUCCEED)
            freeScptFlg=TRUE;
    }


	/*	Script execution for the 1st leg	*/
	if	(ret==RET_SUCCEED)
	{
		ret	=	FIN_InstrTheoricPriceLeg(generalContext,
							            hierHead,
							            extPos,
							            instrPtr,
							            leg1Ptr,
							            objEn,
							            &fld1);
	}

	/*	Script execution for the 2nd leg	*/
	if	(ret==RET_SUCCEED)
	{
		ret	=	FIN_InstrTheoricPriceLeg(generalContext,
							            hierHead,
							            extPos,
							            instrPtr,
							            leg2Ptr,
							            objEn,
							            &fld2);
	}

	if	(ret==RET_SUCCEED)
	{
		/*	Compute the sum	and store it into the field	*/

		ret    =   FIN_ComputeQtyForInstrCompo(instrPtr,
                                               hierHead,
                                               extPos,
                                               leg1Ptr,
                                               FIN_InstrCategory(instrPtr, hierHead),
                                               0.0, NULL,
                                               1, &numLeg1);

		if (ret == RET_SUCCEED)
		{
		    ret    =   FIN_ComputeQtyForInstrCompo(instrPtr,
						                            hierHead,
						                            extPos,
						                            leg2Ptr,
                                                    FIN_InstrCategory(instrPtr, hierHead),
                                                    0.0, NULL,
                                                    2, &numLeg2);
		}

		if (ret == RET_SUCCEED)
		{
		    /*  Compute the sum  */
            numLeg1 *= (GET_NUMBER((&fld1),0));
		    numLeg2 *= (GET_NUMBER((&fld2),0));
            numLeg = numLeg1 + numLeg2;
		    SET_NUMBER(fld, 0, numLeg);

            /*
                DEV1055 - CSA - 06012000
                Store the results into the A_Instr_LastPrice
            */
            /*SET_PRICE(instrPtr, A_Instr_LastPrice, numLeg);*/
            SET_PRICE(leg1Ptr,A_Instr_LastPrice,CAST_PRICE(numLeg1));
            SET_PRICE(leg2Ptr,A_Instr_LastPrice,CAST_PRICE(numLeg2));
		}

		/*	Free the script structure	*/
		/* ret	=	SCPT_FreeScptTree(generalContext); */ /* REF8712 - TEB - 030619 */
	}

    /* REF8712 - TEB - 030619 */
    if (freeScptFlg == TRUE)
    {
		/*	Free the script structure	*/
		ret	=	SCPT_FreeScptTree(generalContext);
    }

	if (freeLegFlg == TRUE)
	{
	    FREE_DYNST(leg1Ptr, A_Instr);
	    FREE_DYNST(leg2Ptr, A_Instr);
	}

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_InstrTheoricPriceSwap	*/


/************************************************************************
**
**  Function    :   FIN_InstrTheoricPriceLeg()
**
**  Description :   This function compute the price of a leg
**
**	Arguments	:	hierHead		Pointer to the hierarchy
**					extPos			Current extended position
**					legPtr			Leg pointer
**					fld				Field to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 25101999
**
*************************************************************************/
STATIC RET_CODE FIN_InstrTheoricPriceLeg(SCPT_ARG_STP		generalContext,
					                    DBA_HIER_HEAD_STP	hierHead,
					                    DBA_DYNFLD_STP		extPos,
					                    DBA_DYNFLD_STP		instrPtr,
					                    DBA_DYNFLD_STP		legPtr,
					                    OBJECT_ENUM		    objEn,
					                    DBA_DYNFLD_STP		fld)
{
	/*	Declaration of variables	*/
	RET_CODE		ret;
	DBA_DYNFLD_STP	ptr;
	DBA_DYNFLD_STP	theDomain=NULL;

	/*	Get the domain pointer	*/
	theDomain = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

	/*	Store the current link	*/
	if ((extPos!=NULLDYNST)	&&
	    (GET_EXTENSION_PTR(extPos,ExtPos_A_Instr_Ext)!=NULL))
	{
		ptr	=	*(GET_EXTENSION_PTR(extPos,ExtPos_A_Instr_Ext));

		/*	Force link	*/
		ret = DBA_ForceLink(hierHead, ExtPos, ExtPos_A_Instr_Ext,
				            extPos, legPtr);

		/*	Execute the script	*/
		if	(ret==RET_SUCCEED)
		{
		    switch  (GET_OBJECT_CST(objEn))
		    {
		    case    InstrCst :
		        ret	=	SCPT_ExecScptTree(generalContext,
							              theDomain,
							              hierHead,
							              legPtr,
							              PriceType, /* PMSTA-52091 - DDV - 230302 */
							              fld,
										  extPos); /* PMSTA14443 - DDV - 120709 */
			    break;

		    case    EPosCst :
		        ret	=	SCPT_ExecScptTree(generalContext,
							              theDomain,
							              hierHead,
							              extPos,
							              PriceType, /* PMSTA-52091 - DDV - 230302 */
							              fld,
										  NULLDYNST); /* PMSTA14443 - DDV - 120709 */
			    break;

    		default:
		        /* The program never will go here,
			      but it is anticipated for a future
			      passage of the LINT utility ;-)
			      So, we write an error message into
			      the log file, and exit with an error
			      code. */
			    ret =   RET_SCPT_ERR_SYNTAX;
			    MSG_SendStrToLog("Error in valuation: The script has to be based solely on the extpos or the instruements.");
		        break;
		    }
		}

		/*	Restore the original link	*/
		DBA_ForceLink(hierHead, ExtPos,ExtPos_A_Instr_Ext, extPos, ptr);

		/*	If necessary, convert price in parent currency */
		/*	(computed leg price is always in leg currency) */
		if (ret == RET_SUCCEED && GET_ID(instrPtr, A_Instr_RefCurrId) !=
            GET_ID(legPtr, A_Instr_RefCurrId))
		{
			DATETIME_T  refDateTime;
			EXCHANGE_T  exch;
			PRICE_T     price;
			FIN_EXCHARG_ST  exchArgSt;

			memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

			refDateTime.date = GET_DATE(extPos, ExtPos_ExtPosDate);
			refDateTime.time = 0;

			if ((ret = FIN_GetExchRate(refDateTime,
					                    GET_ID(legPtr, A_Instr_RefCurrId),
					                    GET_ID(instrPtr, A_Instr_RefCurrId),
					                    0, NULLDYNST, extPos, &exchArgSt, &exch)) == RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
			{
			   price = GET_NUMBER(fld,0);
			   price *= exch;
			   SET_PRICE(fld,0,price);
			}
		}
	}
	else
	{
		/*	There is no link from the extended position to the instrument	*/
		ret	=	RET_FIN_INFO_NOPRICE;
	}

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_InstrTheoricPriceLeg	*/


/************************************************************************
**
**  Function    :   FIN_ComputeQuote()
**
**  Description :   This function calculates the quote of an instrument
**					from its price with a few parameters.
**
**	Arguments	:	hierHead		Pointer to the hierarchy
**					refDate			Reference date
**					instrPtr		Pointer to the dynamic structure of the instrument
**					pricePtr		Pointer to the dynamic structure of the price
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	DEV1055 - CSA - 12111999
**
**  Modifs      :   DEV1055 - CSA - 06012000
**                  REF7782 - YST - 020904
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeQuote(	DBA_HIER_HEAD_STP	hierHead,
									DATETIME_T			refDate,
									DBA_DYNFLD_STP		instrPtr,
									DBA_DYNFLD_STP		pricePtr)
{
	/*	Declaration of variables	*/
	PRICE_T			thePrice;
	PRICE_T			theQuote;
	ID_T				instrId;
	ENUM_T				thePriceCalcRule;
	RET_CODE			ret;
    ENUM_T              instrNat;           /*  DEV1055 - CSA - 06012000  */
    ENUM_T              instrSubNat;        /*  DEV1055 - CSA - 06012000  */
    DBA_DYNFLD_STP      instrLeg1=NULLDYNST;/*  DEV1055 - CSA - 06012000  */
    DBA_DYNFLD_STP      instrLeg2=NULLDYNST;/*  DEV1055 - CSA - 06012000  */
    ID_T                calendarId;
    DBA_DYNFLD_STP      advArgStp   = NULLDYNST;
    DBA_DYNFLD_STP      advAStp     = NULLDYNST;
    DBA_DYNFLD_STP      domainPtr = NULLDYNST;

	/*	Get the price	*/
	thePrice	=	GET_PRICE(pricePtr,A_InstrPrice_Price);

	/*	Get the actual quote	*/
	theQuote	=	GET_PRICE(pricePtr,A_InstrPrice_Quote);

	/*	Get the identifier of the instrument	*/
	instrId	=	GET_ID(pricePtr,A_InstrPrice_InstrId);

	/*	Get the price calculation rule enumeration value from the instrument	*/
	thePriceCalcRule	=	GET_ENUM(instrPtr,A_Instr_PriceCalcRuleEn);

	/*
        DEV1055 - CSA 06012000
        Get the nature and the sub nature of the instrument
    */
    instrNat    = GET_ENUM(instrPtr, A_Instr_NatEn);
    instrSubNat = GET_ENUM(instrPtr, A_Instr_SubNatEn);

    /*
        DEV1055 - CSA 06012000
        Compute the quote
    */
    if  ((hierHead!=NULL) && (instrNat==InstrNat_Swap) &&
        (instrSubNat==SubNat_FixFloatStdSwap || instrSubNat==SubNat_FixFltSwapHedgFix)) /* REF7782 - YST - 020904 */
    {
        /*
            DEV1055 - CSA - 06012000
            Retrieve the 2 instruments legs pointers
        */
        ret = FIN_SearchInstrLegInHier( instrPtr,
                                        hierHead,
                                        &instrLeg1,
                                        &instrLeg2);

        /*
            DEV1055 - CSA - 06012000
            Set order legs
        */
        /*if  (ret==RET_SUCCEED)
            ret = FIN_SetOrderLegs( instrPtr,
                                    hierHead,
                                    &instrLeg1,
                                    &instrLeg2);*/

        /*
            DEV1055 - CSA - 06012000
            Compute the quote
        */
        if  (ret==RET_SUCCEED)
        {
            instrSubNat = GET_ENUM(instrLeg1, A_Instr_SubNatEn);
            if  ((instrSubNat==SubNat_PaidSwapFloatLeg)  ||
                 (instrSubNat==SubNat_RecSwapFloatLeg))
            {
                /*
                    Leg1 = Float
                    Leg2 = Fix
                */
                instrId  = GET_ID(instrLeg2,A_Instr_Id);
                thePrice = GET_PRICE(instrLeg1, A_Instr_LastPrice);
                ret =   SCE_DF2Rate(    instrId,
                                        instrLeg2,
                                        hierHead,
                                        refDate,
                                        NULL,
                                        &thePrice,
                                        &theQuote);
            }
            else
            {
                /*
                    Leg1 = Fix
                    Leg2 = Float
                */
                instrId  = GET_ID(instrLeg1,A_Instr_Id);
                thePrice = GET_PRICE(instrLeg2, A_Instr_LastPrice);
                ret =   SCE_DF2Rate(    instrId,
                                        instrLeg1,
                                        hierHead,
                                        refDate,
                                        NULL,
                                        &thePrice,
                                        &theQuote);
            }
        }
    }
    else if (instrNat==InstrNat_FRA)
    {
        /**************************************
        ***  Memory allocation for the leg  ***
        **************************************/
        advArgStp   =   ALLOC_DYNST(AdvA_Arg);
        advAStp     =   ALLOC_DYNST(A_AdvA);

        /*  Test for success    */
	    if  (advArgStp == NULLDYNST)
		    MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if  (advAStp == NULLDYNST)
	    {
	        FREE(advArgStp);
	        MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        /****************************
        ***  Build the arguments  ***
        ****************************/

        /* Get the calendar identifier */
        ret =   DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	    if ((ret != RET_SUCCEED)    ||  (calendarId <= 0)   )
	        GEN_GetApplInfo(ApplSysCalendarId, &calendarId);

        /* CalendarId from reference currency. */
	    SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
        SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 011219 */

        /* instrument Id */
	    SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

	    /* Margin */
	    SET_FLAG(advArgStp, AdvA_Arg_Margin, (FLAG_T)FALSE);

	    /* domestic */
	    SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);

	    /* ref date */
	    domainPtr = (DBA_DYNFLD_STP) DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

	    if (domainPtr != NULLDYNST)
	    {
		    DATETIME_T  refDateTmp;
		    refDateTmp = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
		    SET_DATE(advArgStp, AdvA_Arg_Date, refDateTmp.date);
	    }
        else
        {
		    SET_DATE(advArgStp, AdvA_Arg_Date, refDate.date); /* PMSTA-24282 - DDV - 160811 */
        }

	    /* spread */
	    SET_NUMBER(advArgStp, AdvA_Arg_Spread, (NUMBER_T)0);

	    /* shock */
	    SET_NUMBER(advArgStp, AdvA_Arg_Shock, (NUMBER_T)0);

	    /* CTD */
	    SET_FLAG(advArgStp, AdvA_Arg_MarketCTD, (FLAG_T)TRUE);

	    /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DF_Fut);


        /**************************
        ***  Compute the price  ***
        **************************/
        ret =   SCE_ComputeCurrKeyWord( advArgStp,
                                        instrPtr,
                                        NULLDYNST,
                                        hierHead,
                                        advAStp);


        /**********************
        ***  Get the price  ***
        **********************/
	    if (ret == RET_SUCCEED)
	    {
            /*  Get the identifier to the instrument    */
            theQuote = GET_PRICE(advAStp, A_AdvA_Price);

        }

        FREE_DYNST(advArgStp, AdvA_Arg);    /* PURIFY - RAK - 000406 */
        FREE_DYNST(advAStp,   A_AdvA);
    }
    else
    {
	    ret	=	FIN_PriceToQuote(	(PRICECALCRULE_ENUM)thePriceCalcRule,   /* REF7264 - CSY - 020130 */
								    instrId,
								    instrPtr,
								    refDate,
								    NULL,
								    thePrice,
								    &theQuote,
								    hierHead);
    }

	/*	Set the quote	*/
	SET_PRICE(pricePtr,A_InstrPrice_Quote,theQuote);

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_ComputeQuote	*/


/************************************************************************
**
**  Function    :   FIN_InstrLinearPrice()
**
**  Description :   This function compute the linear price of an instrument
**
**	Arguments	:	hierHead		Pointer to the hierarchy
**					domainPtr		Pointer to the domain
**					extPos			Current extended position
**					vrelemPtr		Valuation Rule Element pointer
**					fld				Field to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	REF4478 - CHU - 000322
**
*************************************************************************/
STATIC RET_CODE FIN_InstrLinearPrice(DBA_HIER_HEAD_STP	hierHead,
									 DBA_DYNFLD_STP		domainPtr,
									 DBA_DYNFLD_STP		instrPtr,
									 DBA_DYNFLD_STP		extPosPtr,
									 DBA_DYNFLD_STP		valRuleEltPtr,
									 DBA_DYNFLD_STP		pricePtr,
									 DATETIME_T			refDateTime)
{
	/*	Declaration of variables	*/
	RET_CODE		ret;
	DBA_DYNFLD_STP	vrelemScptDef = NULLDYNST;
	DBA_DYNFLD_ST	fld;
	OBJECT_ENUM		entity;
	char            *vrelemScptDefStr = NULL;
	DICT_ATTRIB_STP attribStp = (DICT_ATTRIB_STP)NULL;
	SCPT_ARG_STP	genContextPtr = (SCPT_ARG_STP)NULL;
	PRICE_T		linPrice=0.0, linQuote=0.0;

	memset(&fld, 0, sizeof(DBA_DYNFLD_ST));

	/* Initialize Script Definition */
	if ((vrelemScptDef = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	attribStp = DBA_GetAttributeBySqlName(ValRuleElt, "script_definition");

	SET_DICT(vrelemScptDef, A_ScriptDef_AttrDictId, attribStp->attrDictId);
	SET_ENUM(vrelemScptDef, A_ScriptDef_NatEn,      ScriptDef_ObjDefVal);

    COPY_DYNFLD(vrelemScptDef, A_ScriptDef,  A_ScriptDef_ObjId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);


	/* Get the entity from the Script_Entity_Dict_Id */
	DBA_GetObjectEnum(GET_DICT(valRuleEltPtr, A_ValRuleElt_ScriptEntityDictId), &entity);

    DbiConnectionHelper dbiConnHelper;
    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

	/*	Return no Price if Script definition is missing	*/
	if ((ret = DBA_GetScptDef(vrelemScptDef, *dbiConnHelper.getConnection()))!=RET_SUCCEED)
		ret	= RET_FIN_INFO_NOPRICE;
	else
	{
		vrelemScptDefStr = GET_NOTE(vrelemScptDef, A_ScriptDef_Def);
		if (vrelemScptDefStr == NULL || vrelemScptDefStr[0] == END_OF_STRING)
			ret	= RET_FIN_INFO_NOPRICE;
		else
		{
			if ((ret = SCPT_GenerateScptTree(vrelemScptDefStr, entity, InternalSMode,
				                             PriceType, &genContextPtr)) != RET_SUCCEED) /* PMSTA-52091 - DDV - 230302 */
			{
				MSG_RETURN(RET_SCPT_ERR_SYNTAX);
			}

			if (entity == Instr)
				ret = SCPT_ExecScptTree(genContextPtr, domainPtr, hierHead,
										instrPtr, PriceType, &fld, extPosPtr); /* PMSTA14443 - DDV - 120709 */ /* PMSTA-52091 - DDV - 230302 */
			else if ((entity == EPos) && (extPosPtr != NULLDYNST))
					ret = SCPT_ExecScptTree(genContextPtr, domainPtr, hierHead,
											extPosPtr, PriceType, &fld, NULLDYNST); /* PMSTA14443 - DDV - 120709 */ /* PMSTA-52091 - DDV - 230302 */
				 else
					ret	= RET_FIN_INFO_NOPRICE;

			FREE_DYNST(vrelemScptDef, A_ScriptDef);
			SCPT_FreeScptTree(genContextPtr);

			/* if result not null fill instrPrice Ptr */
			if (IS_NULLFLD((&fld), 0) == TRUE)
				ret	= RET_FIN_INFO_NOPRICE;
			else
			{
				SET_NULL_ID(pricePtr,  A_InstrPrice_TpId);
				SET_NULL_ID(pricePtr,  A_InstrPrice_ThirdId);
				SET_NULL_ID(pricePtr,  A_InstrPrice_TermTpId);
				SET_ID(pricePtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
				SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate, refDateTime);

				linPrice = (GET_NUMBER((&fld),0));
				SET_PRICE(pricePtr,   A_InstrPrice_Price, linPrice);

				/* PMSTA-23790 - DDV - 160628 - Convert price to quote using instrument's PriceCalcRule */
				if (FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn),
					                 GET_ID(instrPtr, A_Instr_Id),
								     instrPtr,
								     refDateTime,
								     NULL,
								     linPrice,
			                         &linQuote,
                                     hierHead) == RET_SUCCEED &&
								     linQuote != 0.0)
				{
					SET_PRICE(pricePtr,   A_InstrPrice_Quote, linQuote);
				}
				else
				{
					SET_PRICE(pricePtr,   A_InstrPrice_Quote, linPrice);
				}

				SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn, GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
				ret = RET_SUCCEED;
			}
		}
	}

	/*	Return value	*/
	return(ret);

}	/*	End function FIN_InstrLinearPrice	*/


/************************************************************************
**
**  Function    : FIN_FilterPtfInstrQuoteDate()
**
**  Description : Filter price by ptfId and instrId
**                return TRUE  -> record must be extract
**                       FALSE -> record musn't be extract
**
**  Arguments   : dynSt    element pointer
**				: dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation    :  PMSTA-54407 - Savitha - 30082023
**
*************************************************************************/
STATIC int FIN_FilterPtfInstrQuoteDate(DBA_DYNFLD_STP dynSt,
							  DBA_DYNST_ENUM dynStTp,
	                          DBA_DYNFLD_STP admArgPtr)
{
	if (CMP_ID(GET_ID(dynSt, A_PortfolioInstrPrice_PtfId), GET_ID(admArgPtr, Adm_Arg_Id)) == 0 &&  /* Adm_Arg_Id: ptf id */
	    CMP_ID(GET_ID(dynSt, A_PortfolioInstrPrice_InstrId), GET_ID(admArgPtr, Adm_Arg_UserId)) == 0 &&  /* Adm_Arg_Id: Instr id */
	    DATETIME_CMP(GET_DATETIME(dynSt, A_PortfolioInstrPrice_QuoteDate) ,GET_DATETIME(admArgPtr, Adm_Arg_Date)) == 0) /* Adm_Arg_Date: Quote Date */
		return(TRUE);

	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfInstrQuoteDate()
**
**  Description :   PortfolioInstrPrice table is sort by quotedate
**
**  Arguments   :   ptr1   pointer on dynamic structure type PortfolioInstrPrice
**                  ptr2   pointer on dynamic structure type PortfolioInstrPrice
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA-32157 - SILPA - 180905
**
*************************************************************************/
STATIC int FIN_CmpPtfInstrQuoteDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio & Instr id check */
	if (GET_ID((*ptr1), A_PortfolioInstrPrice_InstrId) == GET_ID((*ptr2), A_PortfolioInstrPrice_InstrId) &&
		GET_ID((*ptr1), A_PortfolioInstrPrice_PtfId) == GET_ID((*ptr2), A_PortfolioInstrPrice_PtfId))
	{
		/* Validity date */
		return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PortfolioInstrPrice_QuoteDate),
			GET_DATETIME((*ptr2), A_PortfolioInstrPrice_QuoteDate)));
	}
	else
	{
		return FALSE;
	}
}


/************************************************************************
**      END  finprice.c                                       OAMS
*************************************************************************/


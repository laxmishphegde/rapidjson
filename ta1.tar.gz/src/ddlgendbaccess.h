/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENDBACCESS_H
#define DDLGENDBACCESS_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/
typedef struct ITFC_CONTEXT *ITFC_CONTEXT_STP;

/************************************************************************
**      External definitions attached to : ddlgendbaccess.cpp
*************************************************************************/
class DdlGenRequestHelper: public RequestHelper
{
public:
    DdlGenRequestHelper(DbiConnection *dbiConn, DdlGenContext &ddlGenContext);
    DdlGenRequestHelper(DbiConnectionHelper &dbiConnHelper, DdlGenContext &ddlGenContext);
    virtual ~DdlGenRequestHelper();

    RET_CODE       dbaCall(DBA_ACTION_ENUM  action,
                           OBJECT_ENUM      object,
                           int              role,
                           DBA_DYNFLD_STP  &inputDataStp,
                           size_t           batchRank = MAX_SHORT,
                           DBA_DYNFLD_STP   parentDataStp = nullptr);

    RET_CODE       dbaGet(OBJECT_ENUM     object,
                          int             role,
                          DBA_DYNFLD_STP  inputData,
                          DBA_DYNFLD_STP &outputData);

    RET_CODE       insUpdRecord(DBA_DYNFLD_STP &, DBA_ACTION_ENUM &, DBA_DYNFLD_STP = nullptr, bool = false);

    virtual void    setCopyIdForBatchMulti(size_t, DBA_DYNFLD_STP, FIELD_IDX_T, DBA_DYNFLD_STP, FIELD_IDX_T);
    virtual void    setCopyIdForBatchMulti(ID_T*, DBA_DYNFLD_STP, FIELD_IDX_T, size_t = MAX_SHORT);
    void            copyBatchToCopyMap(std::map<size_t, std::vector<RequestHelper::CopyInfo>>&, 
                                       std::map<size_t, std::map<DBA_DYNFLD_STP, ID_T*>>&,
                                       std::set<size_t>&);

    void           sendAllMsg();

    DBA_DYNFLD_STP allocDynSt(const char *, const int, const DBA_DYNST_ENUM &);
    DBA_DYNFLD_STP duplicateDynStp(const char *, const int, const DBA_DYNFLD_STP);
    void           ownerDynStp(const DBA_DYNFLD_STP);
    void           freeDynStp(DBA_DYNFLD_STP &);

protected:

    DdlGenContext                                                &m_ddlGenContext;
};
typedef std::unique_ptr<DdlGenRequestHelper> DdlGenRequestHelperPtr;

class DdlGenEntity: public AAAObject
{
    friend class DdlGenDbaAccess;

public:
    // Constructors
    DdlGenEntity(std::string sqlName, DdlGenContext &ddlGenContext);
    DdlGenEntity(const DdlGenEntity&) = delete;
    // Destructor
    virtual ~DdlGenEntity();

    DdlGenEntity&     operator=(const DdlGenEntity&) = delete;

    void              setTargetSqlName(const std::string & targetSqlName)
    {
        this->m_targetSqlName = targetSqlName;
    };

    RET_CODE          setXdEntityFromDict(DICT_ENTITY_STP srcDictEntityStp);

    bool              check();

    RET_CODE          insUpdXdIndex(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP &xdIndexStp, DBA_DYNFLD_STP xdEntityStp);
    RET_CODE          insXdIndexAttrib(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP currXdAttribStp, DBA_DYNFLD_STP xdIndexStp, DBA_DYNFLD_STP xdIndexAttribStp);

    void              sortAttributes();

    void              addXdAttribInTab(DBA_DYNFLD_STP newXdAttrib);

    DBA_DYNFLD_STP    getXdEntityStp();

    int               getXdAttribNbr();
    DBA_DYNFLD_STP    getXdAttrib(int xdAttribPos);
    DBA_DYNFLD_STP   *getSortedXdAttribTab(TLS_CMPFCT *icmp);
    DBA_DYNFLD_STP    getXdAttribStp(DICT_ATTRIB_STP dictAttribStp);
    DBA_DYNFLD_STP    getXdAttribBySqlName(const std::string &sqlName);
    DBA_DYNFLD_STP    getDbXdAttribBySqlName(const std::string &sqlName);
    DBA_DYNFLD_STP    getXdAttribById(ID_T xdAttribId);

    DBA_DYNFLD_STP    getSysXdAttribStp(TARGET_TABLE_ENUM targetTableEn, const std::string &attribSqlName);
    void              getSysMandatoryAttribSqlNameSet(std::map<std::string, DBA_DYNFLD_STP> &mandatorySet, TARGET_TABLE_ENUM targetTableEn);

    DBA_DYNFLD_STP    getSysXdEntityStp(std::string &);

    DBA_DYNFLD_STP   &getADictEntityStp();

    RET_CODE          loadExdEntityInfo(bool bForceLoad);
    RET_CODE          loadExdIndexInfo(bool bForceLoad = false);
    void              setExdIndexInfo(std::map<ID_T, DBA_DYNFLD_STP> &, std::map<ID_T, std::vector<DBA_DYNFLD_STP>> &);

    TARGET_TABLE_ENUM getTargetTableEnum(DBA_DYNFLD_STP paramXdAttribStp);

    RET_CODE          loadExdEntityFromSysInfo(std::string &realSqlName, bool bForceLoad = false);
    RET_CODE          loadExdIndexFromSysInfo(bool bForceLoad = false);

    ID_T              getXdEntityId(OBJECT_ENUM paramObjectEn);

    DBA_DYNFLD_STP    fixTemplateAttributeId(DBA_DYNFLD_STP xdObjectStp, FIELD_IDX_T lnkAttribIdx); /* PMSTA-29879 - LJE - 180207 */

    std::vector<DBA_DYNFLD_STP>            &getXdIndexVector();
    std::vector<DBA_DYNFLD_STP>            &getSysXdIndexVector();

    void                                    addXdIndex(DBA_DYNFLD_STP);

    std::vector<DBA_DYNFLD_STP>            &getXdIndexAttribVector(DBA_DYNFLD_STP xdIndexStp);
    std::map<SMALLINT_T, DBA_DYNFLD_STP>   &getXdIndexAttribByRankMap(DBA_DYNFLD_STP xdIndexStp);
    std::map<SMALLINT_T, DBA_DYNFLD_STP>   &getSysXdIndexAttribByRankMap(DBA_DYNFLD_STP xdIndexStp);

    std::map<std::string, DBA_DYNFLD_STP>  &getDbXdAttribMap();

    std::map<ENUM_T, DBA_DYNFLD_STP>       *getXdPermValByAttribMap(ID_T);
    std::map<ENUM_T, DBA_DYNFLD_STP>       *getXdPermValByAttribMap(DBA_DYNFLD_STP);
    DBA_DYNFLD_STP                          getXdPermValById(ID_T);

    std::string                             getPkSqlName(TARGET_TABLE_ENUM targetTableEn);
    RET_CODE                                removeDeletedAttributes();

    DICT_ENTITY_STP   getDictEntityStp();

    void              addXdEntityFeature(DdlGenRequestHelper&, XdEntityFeatureFeatureEn, GEN_RULE_ENUM, FEATURE_AUTH_ENUM, bool);

    FEATURE_AUTH_ENUM getFeatureAuth(XdEntityFeatureFeatureEn featureEn);
    void              clearXdEntityFeatures();

    bool              isChangedPartition(std::string &realSqlName);

    DBA_DYNFLD_STP   *getXdPartitionTab();
    int               getXdPartitionNbr();
    RET_CODE          addXdPartition(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP newXdPartition, DdlGenEntity *tplDdlGenEntityPtr);
    DBA_DYNFLD_STP    getXdPartitionBySqlName(DBA_DYNFLD_STP newXdPartition);
    DBA_DYNFLD_STP    getXdPartitionById(ID_T partitionId);
    void              sortPartitions(bool bSysPartition = false);
    bool              isMesiPartitioned();                                                  /* PMSTA-34418 - LJE - 190201 */

    void              clearXdPartition();
    void              clearXdPartitionIndex();

    DBA_DYNFLD_STP   *getXdPartitionIndexTab();
    int               getXdPartitionIndexNbr();
    void              addXdPartitionIndexInTab(DBA_DYNFLD_STP newXdPartitionIndex);
    void              sortPartitionIndexes();

    DICT_T            getNextAttributeDictId(DBA_DYNFLD_STP xdAttribStp);

    void              freeNoSysRecords();

    void              setStatistics(TARGET_TABLE_ENUM, DdlGenContext *);

    void              setDdlGenActionInfo(const DdlGenAction& ddlGenAction);

    std::map<XdEntityFeatureFeatureEn, DBA_DYNFLD_STP>                       xdEntityFeatureMap;

    bool                                                                     bMultiEntityOnPrecomp;
    bool                                                                     bMultiEntityOnCustom;

    std::map<TARGET_TABLE_ENUM, std::map<std::string, DBA_DYNFLD_STP>>       newXdAttribMapMap;
    std::set<DBA_DYNFLD_STP>                                                 xdAttribToPhysicalDeleteSet;

    std::vector<DBA_DYNFLD_STP>                                              m_extFmtEltVector;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                              m_extFmtEltDenomMap;

    std::string                                                              m_dbFct;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                              m_xdAttribCustoMap;    /* PMSTA-43367 - LJE - 210421 */

    class Statistics
    {
    public:
        Statistics()
            : m_targetTotRows(-1)
            , m_sourceTotRows(-1)
            , m_transfertSize(0)
            , m_statisticInfo(std::string())
        {
        }

        Statistics(const Statistics&) = delete;
        Statistics& operator=(const Statistics&) = delete;

    ID_T                                                                     m_targetTotRows;
    ID_T                                                                     m_sourceTotRows;
    ID_T                                                                     m_transfertSize;
    std::string                                                              m_statisticInfo;
    };

    std::map<TARGET_TABLE_ENUM, Statistics>                                  m_statisticsMap;


    std::map<DICT_T, std::map<XdLabelNatEn, DBA_DYNFLD_STP>>                 m_xdEntityLabelMap;    /* DictLanguage */
    std::map<ID_T, std::map<DICT_T, std::map<XdLabelNatEn, DBA_DYNFLD_STP>>> m_xdAttribLabelMap;    /* XdAttribId / DictLanguage */
    std::map<ID_T, std::map<DICT_T, std::map<XdLabelNatEn, DBA_DYNFLD_STP>>> m_xdPermValLabelMap;   /* XdPermValId / DictLanguage */

protected:

    DBA_DYNFLD_STP                                                           m_xdEntityStp;
    std::vector<DBA_DYNFLD_STP>                                              m_xdAttribVector;

private:
    std::string                                                              m_sqlName;
    std::string                                                              m_pkSqlName;
    std::string                                                              m_udPkSqlName;
    std::string                                                              m_xPkSqlName;

    std::string                                                              m_targetSqlName;

    bool                                                                     bIsLoaded;
    bool                                                                     bIsExtLoaded;
    std::string                                                              sysLoadedSqlName;

    bool                                                                     bIsIdxLoaded;
    std::set<std::string>                                                    m_sysIdxLoadedDbNameSet;

    DBA_DYNFLD_STP                                                           shXdEntityStp;

    DBA_DYNFLD_STP                                                           sysXdEntityStp;
    std::map<TARGET_TABLE_ENUM, std::map<std::string, DBA_DYNFLD_STP>>       sysXdAttribMapMap;

    DBA_DYNFLD_STP                                                          *xdPartitionTab;
    int                                                                      xdPartitionNbr;

    std::vector<DBA_DYNFLD_STP>                                              m_xdPartitionVector;

    DBA_DYNFLD_STP                                                          *sysXdPartitionTab;
    int                                                                      sysXdPartitionNbr;

    DBA_DYNFLD_STP                                                           shDictEntityStp;
    DBA_DYNFLD_STP                                                           aDictEntityStp;

    std::vector<DBA_DYNFLD_STP>                                              m_xdIndexVector;
    std::map<DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP>>                    m_xdIndexAttribMapVector;
    std::map<DBA_DYNFLD_STP, std::map<SMALLINT_T, DBA_DYNFLD_STP>>           m_xdIndexAttribByRankMapMap;

    std::map<DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP>>                    m_xdPartitionIndexMapVector;
    DBA_DYNFLD_STP                                                          *xdPartitionIndexTab;
    int                                                                      xdPartitionIndexNbr;

    std::vector<DBA_DYNFLD_STP>                                              m_sysXdIndexVector;
    std::map<DBA_DYNFLD_STP, std::map<SMALLINT_T, DBA_DYNFLD_STP>>           m_sysXdIndexAttribByRankMapMap;

    std::vector<DBA_DYNFLD_STP>                                              m_sysXdIdxPartitionVector;

    std::map<ID_T, std::map<ENUM_T, DBA_DYNFLD_STP>>                         m_xdAttrPermValMap;
    std::map<ID_T, DBA_DYNFLD_STP>                                           m_xdPermValMap;

    DICT_ENTITY_STP                                                          m_dictEntityStp;
    DICT_ENTITY_STP                                                          m_refDictEntityTab;
    DICT_ENTITY_ST                                                           m_invalidDictEntitySt;

    DdlGenContext                                                            m_ddlGenContext;
    DdlGenDbi                                                                m_ddlGenDbi;

    /* PMSTA-26108 - LJE - 170904 */
    MemoryPool                                                               m_mp;
    std::map<std::string, DBA_DYNFLD_STP>                                    m_dbXdAttribMap;

    DICT_T                                                                   m_attDictId;
    DICT_T                                                                   m_UDFAttDictId;
    DICT_T                                                                   m_extAttDictId;
    DICT_T                                                                   m_maxAttDictId;
    DICT_T                                                                   m_maxUDFAttDictId;
    DICT_T                                                                   m_maxExtAttDictId;
};

class DdlGenImportFile: public AAAObject
{
public:
    enum class KindOfData
    {
        None,
        MetaDictionary,
        PckMetaDictionary,
        CustoMetaDictionary,
        OptionMetaDictionary,
        InfraData,
        CustoInfraData,
        ScriptDef
    };

    // Constructors
    DdlGenImportFile(const std::string &, 
                     const std::string &, 
                     const std::string &, 
                     const std::string &,
                     DdlGenImportFile::KindOfData);

    DdlGenImportFile(const DdlGenImportFile &ref)
    {
        *this = ref;
    }

    DdlGenImportFile &operator=(const DdlGenImportFile &ref)
    {
        this->m_kindOfData   = ref.m_kindOfData;
        this->m_rootPath     = ref.m_rootPath;
        this->m_path         = ref.m_path;
        this->m_fileName     = ref.m_fileName;
        this->m_fileExt      = ref.m_fileExt;
        this->m_logPath      = ref.m_logPath;
        this->m_logName      = ref.m_logName;
        this->m_fullPath     = ref.m_fullPath;
        this->m_fullName     = ref.m_fullName;

        return *this;
    }

    // Destructor
    virtual ~DdlGenImportFile();

    const std::string &getFullName() const
    {
        return this->m_fullName;
    }

    const std::string &getFileName() const
    {
        return this->m_fileName;
    }

    const std::string &getFullPath() const
    {
        return this->m_fullPath;
    }

    const std::string &getPath() const
    {
        return this->m_path;
    }

    const std::string &getRootPath() const
    {
        return this->m_rootPath;
    }

    KindOfData      m_kindOfData;
    std::string     m_logPath;
    std::string     m_logName;

protected:

    std::string     m_fileName;
    std::string     m_fileExt;

    std::string     m_rootPath;
    std::string     m_path;

    std::string     m_fullPath;
    std::string     m_fullName;
};

/* PMSTA-45413 - LJE - 210610 */
class DdlGenDbaAccess: public AAAObject
{
    class Action;

public:
    // Constructors
    DdlGenDbaAccess(DdlGenContext &ddlGenContext);
    DdlGenDbaAccess(const DdlGenDbaAccess&) = delete;

    // Destructor
    virtual ~DdlGenDbaAccess();

    DdlGenContext                   &getDdlGenContext();

    RET_CODE                         loadMetaDict();
    RET_CODE                         loadExtended();
    RET_CODE                         load(DBA_DYNFLD_STP, bool = false);
    RET_CODE                         loadXdLabels(DBA_DYNFLD_STP, bool = false);
    void                             loadLabels();
    void                             processLabels();
    RET_CODE                         importData(const DdlGenImportFile &, ITFC_CONTEXT_STP = nullptr);
    RET_CODE                         importAllMetaDict();
    RET_CODE                         importAllData();
    void                             resetAllMetaDict();
    void                             cleanUpMetaDict();
    void                             cleanUpDictLabels();
    void                             cleanUpOneEntity(DBA_DYNFLD_STP);
    void                             loadHelpDoc();

    void                             copyXdEntityDictBuildRule();
    void                             copyXdEntityByName(DBA_DYNFLD_STP, XdEntityDictBuildRuleEn);
    void                             copyXdAttrib(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DICT_BUILD_RULE_ENUM, DBA_DYNFLD_STP &, std::map<ID_T, DBA_DYNFLD_STP> &);
    void                             applyCusto();

    void                             manageXdEntityFeature(DBA_DYNFLD_STP, size_t);

    void                             setXdAction(DBA_DYNFLD_STP, XD_ACTION_ENUM);
    void                             getXdActionStatusFieldPos(DBA_DYNFLD_STP, FIELD_IDX_T&, FIELD_IDX_T&);
    void                             manageDenormAttributes(DBA_DYNFLD_STP);
    bool                             isLoaded(DBA_DYNFLD_STP);
    bool                             isLoaded(OBJECT_ENUM);
    void                             loadManagement(OBJECT_ENUM);
    bool                             isLoaded(DDL_OBJ_ENUM);
    void                             getData(DdlGenEntity &, bool);
    void                             fillExtFromMemory(DdlGenEntity &);
    void                             getExtendedData(DdlGenEntity &);
    void                             getLabels(DdlGenEntity &);
    std::map <OBJECT_ENUM, std::map<ID_T, DBA_DYNFLD_STP>>& getHelpDoc()
    {
        return this->m_xdHelpDocMap;
    }

    DdlObjDef                       *getDdlObjDef(DdlObjDefKey &);
    void                             addDdlObjDefByKey(DdlObjDefKey &);
    void                             addDdlObjDef(DdlObjDef &);
    void                             eraseDdlObjDef(DdlObjDefKey &);

    DBA_DYNFLD_STP                   getRecordByCode(OBJECT_ENUM, const std::string &);
    DBA_DYNFLD_STP                   getRecordById(OBJECT_ENUM, ID_T, bool);

    DBA_DYNFLD_STP                   getXdEntityBySqlName(const std::string &);
    DBA_DYNFLD_STP                   getXdEntityById(ID_T);

    DBA_DYNFLD_STP                   getDictEntityBySqlName(const std::string &);
    DBA_DYNFLD_STP                   getDictEntityById(DICT_T);

    std::string                      getKey(DBA_DYNFLD_STP, bool = false);
    DBA_DYNFLD_STP                   getRecord(OBJECT_ENUM, DBA_DYNFLD_STP, bool = true, bool = true);
    DBA_DYNFLD_STP                   insUpdRecord(DBA_DYNFLD_STP, ID_T &, int, bool);
    void                             updRecordStatus(DBA_DYNFLD_STP);
    void                             linkRecords(DBA_DYNFLD_STP, bool);
    void                             linkOneRecord(DBA_DYNFLD_STP, FIELD_IDX_T, DBA_DYNFLD_STP);
    void                             replaceLinkRecord(DBA_DYNFLD_STP, FIELD_IDX_T, DBA_DYNFLD_STP, FIELD_IDX_T);
    bool                             checkRecord(DBA_DYNFLD_STP, bool);
    void                             selRecords(OBJECT_ENUM, int, DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP> &);
    void                             selRecords(OBJECT_ENUM, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP* &, int &, MemoryPool &);
    void                             selRecordsByParent(OBJECT_ENUM, ID_T, bool, std::vector<DBA_DYNFLD_STP> &, OBJECT_ENUM = NullEntity);
    void                             selScriptDef(OBJECT_ENUM, int, DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP>&);
    bool                             selScriptDefByAttribNat(DICT_T, SCRIPTDEFNAT_ENUM, DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP> &);
    void                             cleanUpScriptDef();

    void                             addAutoRecord(DBA_DYNFLD_STP, DBA_DYNFLD_STP);

    DBA_DYNFLD_STP                   getDatabaseStp(DICT_T);

    bool                             isStatusOnIns(DBA_DYNFLD_STP);
    bool                             isModified(DBA_DYNFLD_STP, bool &, std::vector<DdlGenDbaAccess::Action> &);
    bool                             isModifiedObject(OBJECT_ENUM);

    bool                             isSimulation();

    std::map<ID_T, DBA_DYNFLD_STP>         &getIdByObjEnMap(OBJECT_ENUM);
    std::map<std::string, DBA_DYNFLD_STP>  &getCodeByObjEnMap(OBJECT_ENUM);


    RET_CODE                         insUpdDelRecord(DBA_ACTION_ENUM  action,
                                                     OBJECT_ENUM      object,
                                                     int              role,
                                                     DBA_DYNFLD_STP& inputDataStp,
                                                     bool             bToCopy,
                                                     size_t           batchRank = MAX_SHORT,
                                                     DBA_DYNFLD_STP   parentDataStp = nullptr);

    RET_CODE                         insUpdDelFullRecord(DBA_ACTION_ENUM  action,
                                                         DBA_DYNFLD_STP   inputDataStp);

    RET_CODE                         dbaGet(OBJECT_ENUM, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP&, bool = false);

    bool                             manageCustoData(DBA_DYNFLD_STP, int);

    std::map<ID_T, DBA_DYNFLD_STP>   &selAllRecords(OBJECT_ENUM, bool, bool);

    RET_CODE       flushData();
    void           fillRecordsId(bool);
    void           cleanUpRecordAction();
    bool           isDataModelChanged();
    bool           checkSecurity();
    void           clear();

    bool            addProcedureCallForBatchMulti(DBA_ACTION_ENUM action,
                                                  OBJECT_ENUM     object,
                                                  int             role,
                                                  DBA_DYNFLD_STP  inputData,
                                                  size_t          batchRank = MAX_SHORT);

    DBA_DYNFLD_STP allocDynSt(const char *, const int, const DBA_DYNST_ENUM &);
    DBA_DYNFLD_STP duplicateDynStp(const char *, const int, const DBA_DYNFLD_STP);
    void           ownerDynStp(const DBA_DYNFLD_STP);
    void           freeDynStp(DBA_DYNFLD_STP &);


    bool           isMetaDictLoaded()
    {
        return this->m_isMetaDictLoaded;
    }

    bool           isExtendedLoaded()
    {
        return this->m_isExtendedLoaded;
    }

    RET_CODE       load(const std::string&, DbiConnectionHelper&);
    RET_CODE       loadByParent(DICT_ENTITY_STP, ID_T, OBJECT_ENUM, DbiConnectionHelper &);
    RET_CODE       loadById(OBJECT_ENUM, ID_T, DbiConnectionHelper &);
    RET_CODE       loadByCode(OBJECT_ENUM, const std::string &, DbiConnectionHelper &);
    DBA_DYNFLD_STP insRecord(DBA_DYNFLD_STP, ID_T&, bool = false, bool = false, bool = false);

    void           insToLoadRecord(DBA_DYNFLD_STP);
    void           clearProvidedRecord();
    void           setProvidedRecord(DBA_DYNFLD_STP);
    bool           isProvidedRecord(DBA_DYNFLD_STP);
    bool           isDbRecord(DBA_DYNFLD_STP);

    void           setPackageCompositionStp(DBA_DYNFLD_STP);
    void           setPackageCompositionLink(DBA_DYNFLD_STP);
    DBA_DYNFLD_STP getPackageCompositionStp(DBA_DYNFLD_STP);

    std::map<size_t, std::vector<RequestHelper::CopyInfo>>  m_batchToCopyMap;
    std::map<size_t, std::map<DBA_DYNFLD_STP, ID_T*>>       m_batchToCopyIdMap;

protected:

    void           insRecordById(std::map<ID_T, DBA_DYNFLD_STP> &, DBA_DYNFLD_STP, FIELD_IDX_T, bool);
    void           insRecordDepends(DBA_DYNFLD_STP, bool);
    void           eraseRecordDepends(DBA_DYNFLD_STP);
    void           addToAllDbRecords(DBA_DYNFLD_STP);

    ID_T           getIdFromKey(const std::string &, OBJECT_ENUM, OBJECT_ENUM);
    std::string    getKeyFromId(ID_T, DICT_T);
    std::string    getKeyFromRecord(DBA_DYNFLD_STP);

    std::map<OBJECT_ENUM, std::set<std::string>>            m_providedKeyMap;
    std::map<DBA_DYNFLD_STP, std::set<DBA_DYNFLD_STP>>      m_autoRecordMap;

private:
    friend class DdlGenDbaAccessGuard;

    bool                                                                      m_isMetaDictLoaded;
    bool                                                                      m_isExtendedLoaded;
    std::set<std::string>                                                     m_isLoadedXdEntitySet;
    std::set<OBJECT_ENUM>                                                     m_isLoadedObjectSet;
    std::set<OBJECT_ENUM>                                                     m_isLoadAvoidedObjectSet;
    std::set<OBJECT_ENUM>                                                     m_existsObjectSet;
    std::set<DDL_OBJ_ENUM>                                                    m_allDdlObjLoadedSet;


    DdlGenContext                                                            &m_ddlGenContext;

    std::map<OBJECT_ENUM, std::map<ID_T, DBA_DYNFLD_STP>>                     m_mapIdByObjEnMap;
    std::map<OBJECT_ENUM, std::set<ID_T>>                                     m_isLoadedByIdMap;
    std::map<OBJECT_ENUM, std::map<ID_T, DBA_DYNFLD_STP>>                     m_validIdByObjEnMap;

    std::map<OBJECT_ENUM, std::map<std::string, DBA_DYNFLD_STP>>              m_mapCodeByObjEnMap;
    std::map<OBJECT_ENUM, std::set<std::string>>                              m_isLoadedByCodeMap;

    std::map<OBJECT_ENUM, std::map<OBJECT_ENUM, std::map<ID_T, std::map<ID_T, std::vector<DBA_DYNFLD_STP>>>>> m_mapIdByParentMap;
    std::map<OBJECT_ENUM, std::map<OBJECT_ENUM, std::set<ID_T>>>                                              m_isLoadedByParentMap;

    std::map<OBJECT_ENUM, std::map<ID_T, ID_T>>                               m_mapConvIdByObjEnMap;

    std::map<DBA_DYNFLD_STP, XD_ACTION_ENUM>                                  m_allRecordsMap;
    std::map<DBA_DYNFLD_STP, DBA_DYNFLD_STP>                                  m_allDbRecordsMap;        /* Current record / Database record */

    std::map<DDL_OBJ_ENUM, std::map<DdlObjDefKey, DdlObjDef>>                 m_allDdlObjDefMap;

    /* xd_entity */
    /* Managed by m_mapIdByObjEndMap and m_mapSqlNameByObjEndMap */

    /* xd_attribute */
    std::map<ID_T, std::map<std::string, DBA_DYNFLD_STP>>                     m_xdEntityAttribBySqlNameMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdAttributesByEntityMap;

    /* xd_entity_feature */
    std::map<ID_T, std::map<XdEntityFeatureFeatureEn, DBA_DYNFLD_STP>>        m_xdEntityFeaturesByEntityMap;

    /* xd_perm_value */
    std::map<ID_T, std::map<ENUM_T, DBA_DYNFLD_STP>>                          m_xdPemValuesByXdAttribNatMap;
    std::map<ID_T, std::map<std::string, DBA_DYNFLD_STP>>                     m_xdPemValuesByXdAttribNameMap;

    /* xd_partition */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdPartitionByEntityMap;

    /* xd_attribute_custo */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdAttribCustoByEntityMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdAttribCustoByAttribMap;

    /* xd_index */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdIndexByEntityMap;
    std::map<ID_T, std::map<std::string, DBA_DYNFLD_STP>>                     m_xdEntityIndexByEntityMap;

    /* xd_index_attrib */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdIndexAttribByIndexMap;
    std::map<ID_T, std::map<ID_T, DBA_DYNFLD_STP>>                            m_xdIndexAttribByBkMap;

    /* xd_partition_index */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdPartitonIndexByIndexMap;

    /* xd_attribute_comment */
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>>                               m_xdAttribCommentByEntityMap;

    /* dict_entity */
    /* Managed by m_mapIdByObjEndMap and m_mapSqlNameByObjEndMap */

    /* dict_attribute */
    std::map<DICT_T, DBA_DYNFLD_STP>                                          m_dictAttributesMap;
    std::map<DICT_T, std::map<std::string, DBA_DYNFLD_STP>>                   m_dictEntityAttribBySqlNameMap;

    /* dict_criteria */
    std::map<DICT_T, std::map<ENUM_T, std::map<std::string, DBA_DYNFLD_STP>>> m_dictEntityCriteriaBySqlNameMap;
    std::map < ENUM_T, std::map<std::string, DBA_DYNFLD_STP>>                 m_dictCriteriaByKeyMap;

    /* dict_perm_value */
    std::map<DICT_T, std::map<ENUM_T, DBA_DYNFLD_STP>>                        m_dictPemValuesByAttribMap;

    /* dict_sproc */
    std::map<std::string, std::map<std::string, DBA_DYNFLD_STP>>              m_dictSprocBySqlNameMap;

    /* dict_sproc_param */
    std::map<DICT_T, std::map<std::string, DBA_DYNFLD_STP>>                   m_dictSprocParamByProcMap;

    /* dict_sproc_returns */
    std::map<DICT_T, std::map<SMALLINT_T, DBA_DYNFLD_STP>>                    m_dictSprocReturnsByProcMap;

    /* dict_entity_constraints */
    std::map<DICT_T, std::map<std::string, DBA_DYNFLD_STP>>                   m_dictEntityConstrByEntityMap;

    /* dict_entity_depends */
    std::map<std::string, DBA_DYNFLD_STP>                                     m_dictEntityDependsByKeyMap;
    std::map<DICT_T, std::vector<DBA_DYNFLD_STP>>                             m_dictEntityDependsByDepEntityMap;

    /* xd_label */
    std::map<DICT_T, std::map<ID_T, std::map<DICT_T, std::map<XdLabelNatEn, DBA_DYNFLD_STP>>>>         m_xdLabelMap;   /* EntityDictId, ObjId, LangDictId, NatEn*/
    std::map<DICT_T, std::map<std::string, std::map<DICT_T, std::map<XdLabelNatEn, DBA_DYNFLD_STP>>>>  m_xdLabelByKeyMap;

    /* dict_label */
    std::map<DICT_T, std::map<ID_T, std::map<DICT_T, DBA_DYNFLD_STP>>>                                 m_dictLabelMap;  /* A_DictLabel_EntDictId, A_DictLabel_ObjDictId, A_DictLabel_LangDictId */

    /* xd_help_doc */
    std::map<OBJECT_ENUM, std::map<ID_T,  DBA_DYNFLD_STP>>         m_xdHelpDocMap;

    /* xd_attribute_comnent */
    std::map<std::string, DBA_DYNFLD_STP>                                m_xdAttributeComnentByKeyMap;

    /* dict_attribute_comnent */
    std::map<std::string, DBA_DYNFLD_STP>                                m_dictAttributeComnentByKeyMap;

    /* dict_language */
    std::map<std::string, DBA_DYNFLD_STP>                                m_dictLanguageBySqlNameMap;

    /* object by key */
    std::map<OBJECT_ENUM, std::map<std::string, DBA_DYNFLD_STP>>         m_objectByKeyMapMap;

    /* Script definition case */
    std::map<DICT_T, std::map<SCRIPTDEFNAT_ENUM, std::map<SMALLINT_T, DBA_DYNFLD_STP>>>                m_scriptDefMap;

    /* Update data management */
    class Action
    {
    public:
        Action(DBA_ACTION_ENUM action,
               OBJECT_ENUM     object,
               int             role)
            : m_action(action)
            , m_object(object)
            , m_role(role)
            , m_bIsModified(false)
            , m_bExists(false)
            , m_bToDo(true)
            , m_bTreated(false)
        {
        };

        Action(const Action& ref)
        {
            *this = ref;
        }

        Action& operator=(const Action& ref)
        {
            this->m_action     = ref.m_action;
            this->m_object     = ref.m_object;
            this->m_role       = ref.m_role;
            this->m_bIsModified = ref.m_bIsModified;
            this->m_bExists    = ref.m_bExists;
            this->m_bToDo      = ref.m_bToDo;
            this->m_bTreated   = ref.m_bTreated;

            return *this;
        }

        bool operator==(const Action &ref)
        {
            return(this->m_action == ref.m_action &&
                   this->m_object == ref.m_object &&
                   this->m_role   == ref.m_role);
        }

        bool operator<(const Action &ref) const
        {
            if (this->m_action < ref.m_action)
            {
                return true;
            }
            if (this->m_action > ref.m_action)
            {
                return false;
            }
            if (this->m_object < ref.m_object)
            {
                return true;
            }
            if (this->m_object > ref.m_object)
            {
                return false;
            }
            if (this->m_role < ref.m_role)
            {
                return true;
            }
            if (this->m_role > ref.m_role)
            {
                return false;
            }

            return false;
        }

        DBA_ACTION_ENUM m_action;
        OBJECT_ENUM     m_object;
        int             m_role;

        bool            m_bExists;
        bool            m_bIsModified;

        bool            m_bToDo;
        bool            m_bTreated;
    };

    int                                                                 m_newId;
    std::map<DBA_DYNFLD_STP, std::vector<DdlGenDbaAccess::Action>>      m_recordActionVector;
    std::map<DBA_DYNFLD_STP, std::map<FIELD_IDX_T, DBA_DYNFLD_STP>>     m_recordLinks;
    std::map<ID_T, DBA_DYNFLD_STP>                                      m_recordNewId;
    std::map<ID_T, std::pair<OBJECT_ENUM, ID_T>>                        m_newIdLinks;

    std::set<OBJECT_ENUM>                                               m_objModifStatSet;
    std::set<OBJECT_ENUM>                                               m_modifiedSet;

    DdlGenImportFile::KindOfData                                        m_kindOfImportFile;

    std::map<DBA_DYNST_ENUM, std::set<DBA_DYNFLD_STP>>                  m_toLoadRecordMap;
    std::map<DBA_DYNST_ENUM, std::set<DBA_DYNFLD_STP>>                  m_toLoadFinalRecordMap;

    DBA_DYNFLD_STP                                                      m_packageCompositionStp;
    std::map<DBA_DYNFLD_STP, DBA_DYNFLD_STP>                            m_packageCompositionMap;

    /* Technical part */
    MemoryPool                                                          m_mp;
    Lock                                                                m_lock;
};

#endif	                               /* ifndef DDLGENDBACCESS_H */
/************************************************************************
**      END       ddlgendbaccess.h                                   Odyssey
*************************************************************************/

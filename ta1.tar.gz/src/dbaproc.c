/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAPROC_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H

#include "unidef.h"     /* Mandatory */

#ifndef DBA_H
#include "dba.h"
#endif

#include "date.h"
#include "ope.h"

#ifdef NT
#include <process.h>	/* Necessary for getpid */
#endif

#define MAX_PROCS 25 /* REF11269 - LJE - 051221 */

void DBA_VerifProcDef(DBA_SERVER_TYPE_ENUM  serverType, int mode)
{
    int	i, j, argNb, cpt;
    FILE *dump = fopen("/usr/tmp/dbaproc_list.out", "w");

    for (i = 0; i <= LASTENTITYOBJECT; i++) /* REF9789 - LJE - 031229 */ /* PMSTA07431 - DDV - 081120 - replace "<" with "<=" */
    {
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(i);

        if (objProcLstStp != nullptr)
        {
            for (j = 0; objProcLstStp[j].action != NullAction; j++)
            {
                if (objProcLstStp[j].server != serverType)
                    continue;

                if (objProcLstStp[j].procParamDefPtr != NULL)
                    for (argNb = 0, cpt = 1;
                         objProcLstStp[j].procParamDefPtr[argNb].paramName[0] != '\0';
                         argNb++)
                {
                    if (mode == 1)
                    {
                        fprintf(dump, "%-30s %d %-30s %d\n",
                                objProcLstStp[j].procName, cpt,
                                objProcLstStp[j].procParamDefPtr[argNb].paramName,
                                GET_FLD_TYPE(*(objProcLstStp[j].inputDynStPtr),                     /* REF8844 - LJE - 030415 */
                                             *(objProcLstStp[j].procParamDefPtr[argNb].fldNbrPtr))); /* REF8844 - LJE - 030410 */

                        cpt++;
                    }
                }
                else
                {
                    if (mode == 1)
                        fprintf(dump, "%-30s \n", objProcLstStp[j].procName);
                    argNb = -1;
                }
            }
        }
    }
    fclose(dump);
}

/************************************************************************
*
*   Function           : DBA_EvalOptiTab()
*
*   Description        : Evaluate memory used by optimised table.
*
*   Arguments          : nothing
*
*   Return             : TRUE if success, FALSE elsewhere
*
*  Creation Date       : DVP212 - RAK - 960923
*
*  Last modif.         : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
void DBA_EvalOptiTab()
{
	int            i, j, k, argNb, strTheoSz, arrayTheoSz, multiArrayTheoSz,
		       fldNbr, len, outArgNb;
	unsigned int  inRecSz, outRecSz, recSz, totLoc, totGlob;                                                                                                            /* PMSTA-16124 - 250413 - PMO */
	DBA_DYNST_ENUM inputDynSt;
	DBA_DYNST_ENUM outputDynSt;
	DBA_OPTI_STP   optiPtr;
	FILE           *dumpMem=fopen("/usr/tmp/evalOpti.out", "w");

	totLoc=totGlob=0;

	for (i=0; i<=LASTENTITYOBJECT ; i++) /* REF9789 - LJE - 031229 */ /* PMSTA07431 - DDV - 081120 - replace "<" with "<=" */
	{
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(i);

        if (objProcLstStp != nullptr)
        {
		    for (j=0; objProcLstStp[j].action != NullAction ; j++)
		    {
    	        if (objProcLstStp[j].optiIdx == NullOpti)
		            continue;

		        inputDynSt  = *(objProcLstStp[j].inputDynStPtr);  /* REF8844 - LJE - 030415 */
		        outputDynSt = *(objProcLstStp[j].outputDynStPtr); /* REF8844 - LJE - 030415 */
                optiPtr = (DBA_OPTI_STP) EV_OptiPtr+(objProcLstStp[j].optiIdx);
                LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, true, FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

                /* Get input argument number and theoric size for strings and arrays */
		        strTheoSz = arrayTheoSz = multiArrayTheoSz = argNb = 0;

    	        if (objProcLstStp[j].procParamDefPtr != NULL)
		        {
    	            for (argNb=0;
                         objProcLstStp[j].procParamDefPtr[argNb].paramName[0] != '\0';
		 	             argNb++)
			        {
			            fldNbr = *(objProcLstStp[j].procParamDefPtr[argNb].fldNbrPtr);
			            if (IS_STRINGFLD(inputDynSt, fldNbr) == TRUE)
			            {
				        len = GET_FLD_MAXLEN(inputDynSt,fldNbr);
				        strTheoSz += (len/2);
			            }
                        else
			            if (IS_USTRINGFLD(inputDynSt, fldNbr) == TRUE)
			            {
				        len = GET_FLD_MAXLEN(inputDynSt,fldNbr);
				        strTheoSz += len;
			            }

			            if (IS_ARRAYFLD(inputDynSt, fldNbr) == TRUE)
			            {
				        arrayTheoSz += 10*8;  /* ex : tableau de 20 doubles */
			            }

			            if (IS_MULTIARRAYFLD(inputDynSt, fldNbr) == TRUE)
			            {
				        multiArrayTheoSz += 10;
			            }
			        }
	            }

		        inRecSz = argNb * 16;
		        inRecSz += strTheoSz;
		        inRecSz += arrayTheoSz;
		        inRecSz += (multiArrayTheoSz * 16);

		        /* Get output argument number and theoric size for strings and arrays */
		        strTheoSz = arrayTheoSz = multiArrayTheoSz = 0;
		        outArgNb = GET_FLD_NBR(outputDynSt);

		        for(k=0; k<outArgNb; k++)
		        {
			        if (IS_STRINGFLD(outputDynSt, k) == TRUE)
			        {
			            len = GET_FLD_MAXLEN(outputDynSt,k);
			            strTheoSz += (len/2);
			        }
                    else
			        if (IS_USTRINGFLD(outputDynSt, k) == TRUE)
			        {
			            len = GET_FLD_MAXLEN(outputDynSt,k);
			            strTheoSz += len;
			        }

			        if (IS_ARRAYFLD(outputDynSt, k) == TRUE)
			        {
			            arrayTheoSz += 10*8; /* ex : tableau de 20 doubles */
			        }

			        if (IS_MULTIARRAYFLD(outputDynSt, k) == TRUE)
			        {
			            multiArrayTheoSz += 10;
			        }
	            }

	            outRecSz = outArgNb * 16;
	            outRecSz += strTheoSz;
	            outRecSz += arrayTheoSz;
	            outRecSz += (multiArrayTheoSz * 16);

	            recSz = inRecSz + outRecSz + 16;

	            fprintf(dumpMem, "\n\n\n PROCEDURE %s (input %d, output %d) :",
                        objProcLstStp[j].procName, inputDynSt, outputDynSt);
	            fprintf(dumpMem, "\n record size : input %d\t output %d", inRecSz, outRecSz);
	            fprintf(dumpMem, "\n local maximum record size : %d\t (number %d)",
		               (recSz * optiPtr->locMaxAllocNbr), optiPtr->locMaxAllocNbr);
	            fprintf(dumpMem, "\n global maximum record size : %d\t (number %d)",
		               (recSz * optiPtr->maxAllocNbr), optiPtr->maxAllocNbr);

	            totLoc += (recSz * optiPtr->locMaxAllocNbr);
	            totGlob += (recSz * optiPtr->maxAllocNbr);
	        }
        }
	}

	fprintf(dumpMem, "\n\n Total local : %d\t Total global : %d\n\n ", totLoc, totGlob);
	fclose(dumpMem);

	return;
}

/************************************************************************
*
*   Function           : DBA_EvalOptiTab2()
*
*   Description        : Evaluate memory used by optimised table.
*
*   Arguments          : detailed if 0 only bloc size if 1 bloc size and all record size
*                        procName stored procedure to check
*
*   Return             : nothing
*
*  Creation Date       : DDV - 980409
*
*  Last modif.         : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
void DBA_OptiStat(int detailed, char *procName, char *fileName)
{
	DBA_OPTI_STP		 optiPtr;
	FILE			 *dumpMem;
	unsigned int		totLocal = 0, totGlobal = 0;                                                                                                                    /* PMSTA-16124 - 250413 - PMO */
	LONGINT_T			procSize=0;
	FLAG_T                   useProcNameFlg = FALSE;
        static FLAG_T            inUse = FALSE;
	char                     strTime[128];

	DATE_GetStrTime(strTime);

	if (fileName == NULL || strcmp(fileName, "") == 0)
		return;

	while (inUse == TRUE)
		SYS_MilliSleep(1000);

	inUse = TRUE;

	if (procName != NULL && strcmp(procName, "") != 0)
		useProcNameFlg = TRUE;

	dumpMem = fopen (fileName, "a");

	fprintf(dumpMem, "\n* * * * * BEGIN * * * * * %s \n", strTime);

	for (OBJECT_ENUM i = 0; i <= LASTOBJECT; i++) /* DLA - REF9552 - 031015 <= � la place de < */
	{
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(i);

        if (objProcLstStp != nullptr)
		{
			for (int j = 0; objProcLstStp[j].action != NullAction; j++)
			{
					/* No optimization. */
				if (objProcLstStp[j].optiIdx == NullOpti)
					continue;

		    	/*inputDynSt = objProcLstStp[j].inputDynSt;*/
		    	/*outputDynSt = objProcLstStp[j].outputDynSt;*/
		    	optiPtr = (DBA_OPTI_STP) EV_OptiPtr+(objProcLstStp[j].optiIdx);
                LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, true, FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

                /* if optimisation used in Global and never call, then continue */
				if (optiPtr->procPtr == NULL && optiPtr->maxAllocNbr > 0)
					continue;

				if (useProcNameFlg == TRUE && strcmp(procName, (objProcLstStp[j]).procName) != 0)
					continue;

				switch (objProcLstStp[j].server)
				{
				    case SqlServer:
				    case FinServer:
                    case DispatchServer: /* PMSTA-24563 - LJE - 160908 */
					fprintf(dumpMem, "\n\n PROCEDURE %s (input %d, output %d) :",
                            objProcLstStp[j].procName,
					        *(objProcLstStp[j].inputDynStPtr),
					        *(objProcLstStp[j].outputDynStPtr));
                                        break;

				    case InternalProc:
					fprintf(dumpMem, "\n\n Internal Procedure (input %d, output %d) :",
					        *(objProcLstStp[j].inputDynStPtr),
					        *(objProcLstStp[j].outputDynStPtr));
                                        break;
				}

				DBA_OptiGetUsedSizeByProc(&(objProcLstStp[j]), Opti_Local, detailed, &procSize, dumpMem);
				totLocal += (int)procSize;

				DBA_OptiGetUsedSizeByProc(&(objProcLstStp[j]), Opti_Global, detailed, &procSize, dumpMem);
				totGlobal += (int)procSize;

			}
		}
	}

	totLocal /= 1024;
	totGlobal /= 1024;

	if (useProcNameFlg == FALSE)
		fprintf(dumpMem, "\n\n Total local : %d kb.\t Total global : %d kb.\n", totLocal, totGlobal);

	fprintf(dumpMem, "\n\n* * * * *  END  * * * * * %s \n", strTime);

	fclose(dumpMem);

	inUse = FALSE;

	return;
}

/************************************************************************
*   Function             : DBA_GetStoredProcs()
*
*   Description          : Retrieve a procedure from the procedure list
*
*   Arguments            : action     : the action to execute (Get, Select,...)
*                          object     : the request corresponding object
*                          role       : the role of the request
*                          inputSt    : the input dynamic struct. format
*                          inputData  : the pointer on the input dynamic struct.
*                          outputSt   : the output dynamic struct. format
*                          pExplain   : Optional. Used to provide explanation why we have a procedure not found
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : A pointer on the chosen procedure if found
*                          or NULL if no procedure corresponds to the profile
*
*   Last Modification    : 22.12.95 - PEC - Added new handling of procedure priorities.
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
DBA_PROC_STP DBA_GetStoredProcs(DBA_ACTION_ENUM action,
                                OBJECT_ENUM     object,
                                int             role,
                                DBA_DYNST_ENUM  inputSt,
                                DBA_DYNFLD_STP  inputData,
                                DBA_DYNST_ENUM  outputSt,
                                bool            bTryToAvoidInteralProc,
                                std::string *   pExplain)
{
    if (object == NullEntityCst)    /* DLA - PMSTA-27196 - 170505 */
    {
        return(NULL);
    }

    DBA_PROC_STP objProcs = AaaMetaDict::getObjProcLstStp(object);

    if (objProcs == NULL)
    {
        return(NULL);
    }

    MemoryPool mp;
    DBA_PROC_ST **interestProcs = (DBA_PROC_STP *)mp.calloc(FILEINFO, MAX_PROCS, sizeof(DBA_PROC_STP));

    /* Test memory allocation */
    if (interestProcs == NULL)
    {
        return(NULL);
    }

    if (nullptr != pExplain)
    { // For error logging
        if (NullDynSt != inputSt)
        {
            *pExplain += "Input Data for the selection:\n";
            std::string inputDispData;
            DBA_DispDynStToString(inputData, inputDispData, 4);
            *pExplain += inputDispData;
        }
        *pExplain += "Procedure Selection:\n";
    }

    /* Search for a procedure corresponding to the request parameters in the Object procedure list. */
    int idx = 0;
    int procNum = 0;
    while (objProcs[idx].action != NullAction)
    {
        if (objProcs[idx].action == action)
            if (*(objProcs[idx].inputDynStPtr) == inputSt) /* REF8844 - LJE - 030416 */
                if (*(objProcs[idx].outputDynStPtr) == outputSt) /* REF8844 - LJE - 030416 */
                    if (objProcs[idx].subObj == role)
                    {
                        interestProcs[procNum] = &(objProcs[idx]);
                        ++procNum;

                        if (nullptr != pExplain)
                        { // For error logging
                            *pExplain += "    Selecting:";

                            if (objProcs[idx].server == InternalProc)
                            {
                                *pExplain += "C function";
                            }
                            else
                            {
                                *pExplain += objProcs[idx].procName;
                            }

                            *pExplain += "\n";
                        }
                    }
        ++idx;
    }

    /* If procedure was found */
    if (procNum > 0)
    {
        /* Check that all necessary arguments for the request are given */
        int                 paramIndex = 0;
        bool                paramFound = true;
        int                 foundedProc = 0;
        int                 priority;
        DBA_PROCPARAM_STP   procParam = NULL;

        for (idx = 0; idx < procNum; idx++)
        {
            priority = 100;
            for (int i = 0; i<procNum; i++)
            {
                if (interestProcs[i] != NULL && interestProcs[i]->priority < priority)
                {
                    procParam = interestProcs[i]->procParamDefPtr;
                    foundedProc = i;
                    priority = interestProcs[i]->priority;
                }
            }

            if (procParam != UNUSED)
            {
                if (nullptr != pExplain)
                { // For error logging
                    *pExplain += "    Checking parameters of ";

                    if ( interestProcs[foundedProc]->server == InternalProc)
                    {
                        *pExplain += "C function";
                    }
                    else
                    {
                        *pExplain += interestProcs[foundedProc]->procName;
                    }

                    *pExplain += ":\n";
                }

                paramFound = true;
                paramIndex = 0;
                while (paramFound &&
                       procParam[paramIndex].paramName != NULL &&
                       procParam[paramIndex].paramName[0] != END_OF_STRING)
                {
                    if ((IS_NULLFLD(inputData, *(procParam[paramIndex].fldNbrPtr)) == TRUE)
                        && (procParam[paramIndex].mandatFlg == TRUE))
                    {
                        paramFound = false;
                        interestProcs[foundedProc] = NULL;
                    }

                    if (nullptr != pExplain)
                    { // For error logging
                        *pExplain += "        ";
                        *pExplain += procParam[paramIndex].paramName;

                        if (true == paramFound)
                        {
                            *pExplain += ":ok\n";
                        }
                        else
                        {
                            *pExplain += ":ko\n";
                        }
                    }

                    ++paramIndex;
                }
            }
            else if (idx == procNum - 1) /* PMSTA-13109 - LJE - 111223 */
            {
                paramFound = true;
            }

            if (paramFound == true)
            {
                DBA_PROC_STP choosenProc = interestProcs[foundedProc];

                if (bTryToAvoidInteralProc &&
                    choosenProc->server == InternalProc)
                {
                    DBA_PROC_STP procedureStp = nullptr;

                    if (role == UNUSED)
                    {
                        procedureStp = DBA_GetStoredProcs(action,
                                                          object,
                                                          DBA_ROLE_DB_ACCESS,
                                                          GET_DYNSTENUM(inputData),
                                                          inputData,
                                                          NullDynSt,
                                                          false,
                                                          pExplain);
                    }
                    else if (role == DBA_ROLE_UDT || role == DBA_ROLE_STATUS)
                    {
                        procedureStp = DBA_GetStoredProcs(action,
                                                          object,
                                                          DBA_ROLE_DB_STATUS,
                                                          GET_DYNSTENUM(inputData),
                                                          inputData,
                                                          NullDynSt,
                                                          false,
                                                          pExplain);
                    }
                    else if (role == DBA_ROLE_IMPORT_USR_MD)
                    {
                        procedureStp = DBA_GetStoredProcs(action,
                                                          object,
                                                          DBA_ROLE_DB_ACCESS_USR,
                                                          GET_DYNSTENUM(inputData),
                                                          inputData,
                                                          NullDynSt,
                                                          false,
                                                          pExplain);
                    }
                    else
                    {
                        procedureStp = DBA_GetStoredProcs(action,
                                                          object,
                                                          role + DBA_ROLE_DB_ACCESS_FACTOR,
                                                          GET_DYNSTENUM(inputData),
                                                          inputData,
                                                          NullDynSt,
                                                          false,
                                                          pExplain);

                    }

                    if (procedureStp != nullptr)
                    {
                        choosenProc = procedureStp;
                    }
                }

                return(choosenProc);
            }
        }
    }

    return(NULL);
}


/************************************************************************
*   Function             : DBA_IsInOutStoredProc()
*
*   Description          : Returns true if the stored proc has a parameter IN OUT
*                          (example : upd_ext_order)
*
*   Arguments            : procedure    SQL procedure
*
*   Return               : bool
*
*   Creation Date        : PMSTA-24434 - TEB - 160923
*
*   Last modif.          :
*************************************************************************/
bool DBA_IsInOutStoredProc(DBA_PROC_STP procedure)
{
    if (procedure->procParamDefPtr != nullptr && (procedure->action == Update || procedure->action == Insert))  /* PMSTA-28698 - LJE - 180524 */
    {
        int paramIdx = 0;
        while (procedure->procParamDefPtr[paramIdx].fldNbrPtr != UNUSED)
        {
            if (procedure->procParamDefPtr[paramIdx].procParamTypeEn != ProcParamType_Output &&
                procedure->procParamDefPtr[paramIdx].procParamTypeEn != ProcParamType_Output_Indexed)
            {
                return false;
            }
            paramIdx++;
        }

        return true;

    }
    return false;
}


/************************************************************************
*   Function             : DBA_CreateSQLCall()
*
*   Description          : Generate the SQL command into sqlCmd.
*                          Designed for error message related to the fusion
*                          Known limitation:
*                          a) Output parameter are not numbered. Ex @pos_object_id6 -> @pos_object_id
*                          b) Double value are not trailled with 0. Ex "1.00" or "1.000000000" -> "1."
*                          c) No generation of the following SQL statement declare @pos_object_id6 id_t
*                          Example of SQL commands generated:
*                          a) del_ext_order_by_id @id=50502704,@time_stamp=0x0000000029b901ad
*                          b) del_position_by_open_oper_id @id=50502681
*                          c) ins_operation_by_id 50502681,"AAAPmo1466000001",1,64, NULL, NULL, NULL, NULL,50004411, NULL, NULL, NULL,597, NULL, NULL,2, NULL, NULL, NULL,2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,64,"07/20/2012 11:50:03",4,0,"07/18/2012 10:06:53",1.000000000, NULL, NULL,1.000000000, NULL, NULL,"01/01/2012 00:00:00","01/01/2012 00:00:00", NULL, NULL,"01/01/2012 00:00:00", NULL,0,90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,0,0, NULL, NULL,0,0,0,0,0, NULL, NULL,0,0, NULL,0, NULL, NULL,0, NULL, NULL, NULL,0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,0, NULL, NULL, NULL, NULL,0, NULL, NULL, NULL,0x0000000029b901ad
*                          d) ins_exd_position_by_id @pos_object_id output,50004411, NULL,597, NULL, NULL,2,2,2, NULL,50502681, NULL, NULL, NULL, NULL,4,0,"AAAPmo1466000001", NULL, NULL, NULL,0, NULL,0,0, NULL,0, NULL,0, NULL, NULL,90,1,0,2,0,0,0,0,1,0,"01/01/2012 00:00:00","12/31/9999 00:00:00","01/01/2012 00:00:00","01/01/2012 00:00:00","01/01/2012 00:00:00", NULL, NULL, NULL, NULL,"cc",1.000000000,1.000000000,1.000000000, NULL, NULL, NULL,100000.00000000,100.000000000, NULL, NULL,1,100.000000000, NULL, NULL, NULL, NULL,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00, NULL, NULL, NULL, NULL,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,100.000000000, NULL,50004411
*
*   Arguments            : sqlCmd       Add the SQL command to this string
*                          dataStr      Working buffer used for formatting a field
*                          dataStrSize  Allocation size of dataStr
*                          accessPtr    Some fields used
*                          procedure    SQL procedure
*
*   Return               : None
*
*   Creation Date        : PMSTA-14660 - 160712 - PMO : NQA: Critical fusion error during database updates : message "FIN_UpdateDataBase: Position mismatch detected code" in server log file
*
*   Last modif.          :
*************************************************************************/
void DBA_CreateSQLCall(std::string & sqlCmd, char * dataStr, const int dataStrSize, const DBA_ACCESS_STP accessPtr, DBA_PROC_STP procedure)
{
    if (NULL != procedure)
    {
        DBA_PROCPARAM_STP   procParam = NULL;     /* SQL parameter of some procs                          */
        int                 dataLength = 0;        /* Length of formatted data                             */
        bool                firstField = true;     /* Argument separator. First time we add " " and ","    */

        /*
        * Set the SQL procedure name or Internal proc for C function
        */
        if (SqlServer == procedure->server)
        {
            sqlCmd += procedure->procName;
        }
        else
        {
            sqlCmd += "Internal Proc";
        }

        /*
        * Processing of some parameters (adm_arg for del, output param for insert)
        * Typical processing:
        * a) del_ext_order_by_id @id=50502704,@time_stamp=0x0000000029b901ad
        * b) ins_exd_position_by_id @pos_object_id output
        */
        if (NULL != procedure->procParamDefPtr)
        {
            procParam = procedure->procParamDefPtr;

            for (int paramIdx = 0; procParam[paramIdx].paramName != NULL && procParam[paramIdx].paramName[0] != 0; paramIdx++)
            {
                sqlCmd += true == firstField ? " " : ",";

                if (RET_SRV_LIB_ERR_DB_OVERFLOW != DBI_FldToDbDataStr(dataStr,
                    dataStrSize,
                    accessPtr->data,
                    *(procParam[paramIdx].fldNbrPtr),
                    GET_FLD_TYPE(accessPtr->entity, *(procParam[paramIdx].fldNbrPtr)),
                    &dataLength, false))
                {
                    sqlCmd += procParam[paramIdx].paramName;

                    if (ProcParamType_Output != procParam[paramIdx].procParamTypeEn)
                    {
                        sqlCmd += "=";
                        sqlCmd += dataStr;
                    }
                    else
                    {
                        sqlCmd += " output";
                    }

                }
                else
                {
                    sqlCmd += "ERR_DB_OVERFLOW";
                }

                firstField = false;
            }
        }

        /*
        * Processing of all parameters (skip output param for insert)
        * Typical processing (see the previous processing for b):
        * a) ins_operation_by_id 50502681,"AAAPmo1466000001",1,64, NULL, NULL, NULL, NULL,50004411, NULL, NULL, NULL,597, NULL, NULL,2, NULL, NULL, NULL,2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,64,"07/20/2012 11:50:03",4,0,"07/18/2012 10:06:53",1.000000000, NULL, NULL,1.000000000, NULL, NULL,"01/01/2012 00:00:00","01/01/2012 00:00:00", NULL, NULL,"01/01/2012 00:00:00", NULL,0,90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,0,0, NULL, NULL,0,0,0,0,0, NULL, NULL,0,0, NULL,0, NULL, NULL,0, NULL, NULL, NULL,0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,0, NULL, NULL, NULL, NULL,0, NULL, NULL, NULL,0x0000000029b901ad
        * b) ,50004411, NULL,597, NULL, NULL,2,2,2, NULL,50502681, NULL, NULL, NULL, NULL,4,0,"AAAPmo1466000001", NULL, NULL, NULL,0, NULL,0,0, NULL,0, NULL,0, NULL, NULL,90,1,0,2,0,0,0,0,1,0,"01/01/2012 00:00:00","12/31/9999 00:00:00","01/01/2012 00:00:00","01/01/2012 00:00:00","01/01/2012 00:00:00", NULL, NULL, NULL, NULL,"cc",1.000000000,1.000000000,1.000000000, NULL, NULL, NULL,100000.00000000,100.000000000, NULL, NULL,1,100.000000000, NULL, NULL, NULL, NULL,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00,10000000.00, NULL, NULL, NULL, NULL,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,-0.00,100.000000000, NULL,50004411
        */
        switch (accessPtr->action)
        {
            case Insert:
            case InsUpd:
            case Update:
            {
                const int nbDbFld = DBA_GetFirstCustFld(accessPtr->object); /* PMSTA-18593 - LJE - 151022 */

                for (int fldIdx = 0; fldIdx < nbDbFld; fldIdx++)
                {
                    /* Database fields only */
                    if (TRUE == IS_DBFLD(accessPtr->entity, fldIdx) && DictAttribClass::isPhysicalCalcEn(DBA_GetDictAttribCalcEn(accessPtr->object, fldIdx)) == TRUE) /* PMSTA-18593 - LJE - 150625 */
                    {
                        /*
                        * Output field processing
                        */
                        bool skipOutputField = false;

                        if (NULL != procParam)
                        {
                            for (int paramIdx = 0; procParam[paramIdx].paramName != NULL && procParam[paramIdx].paramName[0] != 0; paramIdx++)
                            {
                                if (fldIdx == *(procParam[paramIdx].fldNbrPtr))
                                {
                                    skipOutputField = true;
                                    break;
                                }
                            }
                        }

                        /*
                        * Field processing
                        */
                        if (false == skipOutputField)
                        {
                            sqlCmd += true == firstField ? " " : ",";
                            if (RET_SRV_LIB_ERR_DB_OVERFLOW != DBI_FldToDbDataStr(dataStr,
                                dataStrSize,
                                accessPtr->data,
                                fldIdx,
                                GET_FLD_TYPE(accessPtr->entity, fldIdx),
                                &dataLength, false))
                            {
                                sqlCmd += dataStr;
                            }
                            else
                            {
                                sqlCmd += "ERR_DB_OVERFLOW";
                            }

                            firstField = false;
                        }
                    }
                }
            }
            break;

            default:
                break;
        }
    }
    else
    { /* Strange error... */
        sqlCmd += "No Procedure";
    }
}

/************************************************************************
*   Function             : DBA_GetStoredProcsBySqlName()
*
*   Description          : Retrieve a procedures from the procedure list by sql name
*
*   Arguments            :
*
*   Return               :
*
*   Creation             : PMSTA-29956 - LJE - 180125
*   Last Modification    :
*
*************************************************************************/
void DBA_GetStoredProcsBySqlName(OBJECT_ENUM object, const std::string &sqlName, std::vector<DBA_PROC_STP> &storedProcVector)
{
    DBA_PROC_STP objProcs = AaaMetaDict::getObjProcLstStp(object);

    storedProcVector.clear();

    if (objProcs == nullptr)
    {
        DBA_InitProcLstPtr(object);
        objProcs = AaaMetaDict::getObjProcLstStp(object);
    }

    if (objProcs)
    {
        int idx = 0;
        while (objProcs[idx].action != NullAction)
        {
            if (objProcs[idx].server == SqlServer &&
                objProcs[idx].procName &&
                (sqlName.empty() == true || strcasecmp(sqlName.c_str(), objProcs[idx].procName) == 0))
            {
                storedProcVector.push_back(&objProcs[idx]);
            }
            idx++;
        }

        if (storedProcVector.empty() && object != FinAnalysis)
        {
            DBA_GetStoredProcsBySqlName(FinAnalysis, sqlName, storedProcVector);
        }
    }
}

/************************************************************************
**      END          dbaproc.c                                   UNICIBLE
*************************************************************************/

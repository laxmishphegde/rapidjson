/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DFTTESTFUSION_H
#define DFTTESTFUSION_H

#include <assert.h>
#include <sstream>

#include "zlib.h"

#ifndef GEN_H
#include "gen.h"
#endif

#ifndef DBA_H
#include "dba.h"
#endif


#include <fstream>
#include <stdexcept>

typedef class FusionContext  FIN_FUS_CONTEXT_ST;
typedef class FusionContext *FIN_FUS_CONTEXT_STP;
class PosLog;

const int QUICKCHECKFILEVERSION   = 7015;             /* PMSTA-23996 - 080716 - PMO */

enum ENUMDFTAPPL { DFT_APPLNULL
                 , DFT_APPLENUM
                 , DFT_APPLID
                 , DFT_APPLFLAG
                 , DFT_APPLDATE
                 , DFT_APPLINT      /* PMSTA08746 - 061009 - PMO */
                 };

struct STRUCT_SYSPARAMETERS
{
    GEN_APPLINFO_ENUM   applParameter;  /* Enumeration value of the system parameter                        */
    const char *        pszName;        /* Name of the system parameter                                     */
    long                lValue;         /* Argument type used when setting the parameter. No string for yet */
    bool                bDefined;       /* True if loaded from the xml file       PMSTA-9175 - 050110 - PMO */
    enum ENUMDFTAPPL    iType;          /* For futur implementation                                         */
};
typedef struct STRUCT_SYSPARAMETERS SYSPARAMETERS_ST, * SYSPARAMETERS_STP;

static SYSPARAMETERS_ST SV_tabSysParameters[] = { { ApplPortFusRule,                "ApplPortFusRule",              0,              false, DFT_APPLENUM}
                                                , { ApplPortPlCompRule,             "ApplPortPlCompRule",           0,              false, DFT_APPLENUM}
                                                , { ApplPosLogicalIdRule,           "ApplPosLogicalIdRule",         0,              false, DFT_APPLENUM}
                                                , { ApplFusDateRule,                "ApplFusDateRule",              0,              false, DFT_APPLENUM}    /* PMSTA-8062 - 190509 - PMO */
                                                , { ApplCapPBpTypeId,               "ApplCapPBpTypeId",             0,              false, DFT_APPLID}
                                                , { ApplCapLBpTypeId,               "ApplCapLBpTypeId",             0,              false, DFT_APPLID}
                                                , { ApplCurPBpTypeId,               "ApplCurPBpTypeId",             0,              false, DFT_APPLID}
                                                , { ApplCurLBpTypeId,               "ApplCurLBpTypeId",             0,              false, DFT_APPLID}
                                                , { ApplAccountingStatus,           "ApplAccountingStatus",         0,              false, DFT_APPLENUM}
                                                , { ApplPeriodUnitEnum,             "ApplPeriodUnitEnum",           0,              false, DFT_APPLENUM}
                                                , { ApplFwdCloseFlag,               "ApplFwdCloseFlag",             0,              false, DFT_APPLFLAG}
                                                , { ApplFutCloseFlag,               "ApplFutCloseFlag",             0,              false, DFT_APPLFLAG}
                                                , { ApplTermCloseFlag,              "ApplTermCloseFlag",            0,              false, DFT_APPLFLAG}
                                                , { ApplMatchSourceCdFlag,          "ApplMatchSourceCdFlag",        0,              false, DFT_APPLFLAG}
                                                , { ApplDefBookProfitBpTpId,        "ApplDefBookProfitBpTpId",      0,              false, DFT_APPLID}
                                                , { ApplDefBookLossBpTpId,          "ApplDefBookLossBpTpId",        0,              false, DFT_APPLID}
                                                , { ApplBookValAdjMethod,           "ApplBookValAdjMethod",         0,              false, DFT_APPLENUM}
                                                , { ApplUseBookValueFlag,           "ApplUseBookValueFlag",         0,              false, DFT_APPLFLAG}
                                                , { ApplBookAdjLossBpTpId,          "ApplBookAdjLossBpTpId",        0,              false, DFT_APPLID}
                                                , { ApplBookAdjProfitBpTpId,        "ApplBookAdjProfitBpTpId",      0,              false, DFT_APPLID}
                                                , { ApplFusRuleSortRule,            "ApplFusRuleSortRule",          0,              false, DFT_APPLENUM}
                                                , { ApplFusionCashValueDateFlg,     "ApplFusionCashValueDateFlg",   0,              false, DFT_APPLFLAG}
                                                , { ApplAdjustInheritPosDateEnum,   "ApplAdjustInheritPosDateEnum", 0,              false, DFT_APPLENUM}
                                                , { ApplReversalMethode,            "ApplReversalMethode",          0,              false, DFT_APPLENUM}
                                                , { ApplEuroCurrId,                 "ApplEuroCurrId",               0,              false, DFT_APPLID}
                                                , { ApplEuroExchConvDate,           "ApplEuroExchConvDate",         0,              false, DFT_APPLDATE}
                                                , { ApplBookGrossAmountFlag,        "ApplBookGrossAmountFlag",      0,              false, DFT_APPLFLAG}
                                                , { ApplMargInheritPosDateEn,       "ApplMargInheritPosDateEn",     0,              false, DFT_APPLENUM}
                                                , { ApplFusMmktAmendValueDateFlag,  "ApplFusMmktAmendValueDateFlag",0,              false, DFT_APPLFLAG}
                                                , { ApplZeroPosLogFilter,           "ApplZeroPosLogFilter",         0,              false, DFT_APPLENUM}
                                                , { ApplFusionSwitchDate,           "ApplFusionSwitchDate",         0,              false, DFT_APPLENUM}
                                                , { ApplFusionSwitchRule,           "ApplFusionSwitchRule",         0,              false, DFT_APPLDATE}
                                                , { ApplFusBondCloseValueDate,      "ApplFusBondCloseValueDate",    0,              false, DFT_APPLFLAG}
                                                , { ApplAccAccrInterDateRule,       "ApplAccAccrInterDateRule",     0,              false, DFT_APPLENUM}
                                                , { FullCouponFlag,                 "FullCouponFlag",               0,              false, DFT_APPLFLAG}
                                                , { ApplAccrInterestResetFlag,      "ApplAccrInterestResetFlag",    0,              false, DFT_APPLFLAG}
                                                , { ApplClosedPosBegDate,           "ApplClosedPosBegDate",         0,              false, DFT_APPLFLAG}
                                                , { ApplFutMergeInvestBpTypeId,     "ApplFutMergeInvestBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFutMergeWithdrBpTypeId,     "ApplFutMergeWithdrBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFutCloseInvestBpTypeId,     "ApplFutCloseInvestBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFutCloseWithdrBpTypeId,     "ApplFutCloseWithdrBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFwdMergeInvestBpTypeId,     "ApplFwdMergeInvestBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFwdMergeWithdrBpTypeId,     "ApplFwdMergeWithdrBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFwdCloseInvestBpTypeId,     "ApplFwdCloseInvestBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplFwdCloseWithdrBpTypeId,     "ApplFwdCloseWithdrBpTypeId",   0,              false, DFT_APPLID}
                                                , { ApplCashAdjNeutralizingEnum,    "ApplCashAdjNeutralizingEnum",  0,              false, DFT_APPLENUM}    /* PMSTA-6921 - 311008 - PMO */
                                                , { ApplCashPtfFwdAccountEnum,      "ApplCashPtfFwdAccountEnum",    0,              false, DFT_APPLENUM}    /* PMSTA-6924 - 280109 - PMO */
                                                , { ApplCashAdjFlag,                "ApplCashAdjFlag",              0,              false, DFT_APPLFLAG}    /* PMSTA08471 - 280709 - PMO */
                                                , { ApplCurrPlCompRule,             "ApplCurrPlCompRule",           1,              false, DFT_APPLENUM}    /* PMSTA08746 - 061009 - PMO */
                                                , { ApplNbFusionByBatch,            "ApplNbFusionByBatch",          1,              false, DFT_APPLINT}     /* PMSTA08746 - 061009 - PMO */
                                                , { ApplFutPlAcct2MarginCall,       "ApplFutPlAcct2MarginCall",     MAGIC_END_DATE, true,  DFT_APPLINT}     /* PMSTA08746 - 061009 - PMO / PMSTA-9072 - 050510 - PMO */
                                                , { ApplFusionFutSplitCurrPl,       "ApplFusionFutSplitCurrPl",     0,              false, DFT_APPLINT}     /* PMSTA08746 - 061009 - PMO */
                                                , { ApplCloseOldZeroPos,            "ApplCloseOldZeroPos",          15,             false, DFT_APPLINT}     /* PMSTA-9688 - 210410 - PMO */
                                                , { ApplExecutionStatus,            "ApplExecutionStatus",          -1,             false, DFT_APPLINT}     /* PMSTA-14010 - 130412 - PMO */
                                                , { ApplCashFlowOpenRefNat,         "ApplCashFlowOpenRefNat",       0,              false, DFT_APPLDATE}    /* PMSTA-21633 - 031115 - PMO */
                                                , { ApplTaxLotAccountingEn,         "ApplTaxLotAccountingEn",       0,              false, DFT_APPLENUM}    /* PMSTA-28340 - 270917 - PMO */    
                                                , { ApplTrsfCapPBpTpId,             "ApplTrsfCapPBpTpId",           0,              false, DFT_APPLID}      /* WEALTH-6236 - JBC -20240417 */
                                                , { ApplTrsfCapLBpTpId,             "ApplTrsfCapLBpTpId",           0,              false, DFT_APPLID}      /* WEALTH-6236 - JBC -20240417 */
                                                , { ApplTrsfCurPBpTpId,             "ApplTrsfCurPBpTpId",           0,              false, DFT_APPLID}      /* WEALTH-6236 - JBC -20240417 */
                                                , { ApplTrsfCurLBpTpId,             "ApplTrsfCurLBpTpId",           0,              false, DFT_APPLID}      /* WEALTH-6236 - JBC -20240417 */
                                                };

enum ENUMSTEPDATA { SD_NONE
                  , SD_POSITION
                  , SD_INSTRUMENT 
                  , SD_EXTOP
                  , SD_FUSARG
                  , SD_PORTFOLIO
                  , SD_FUSIONLOOP
                  , SD_POSFUSION
                  , SD_BALPOSFUSION
                  , SD_ADJEXCHANGEWITHFEES      /* PMSTA-9324 - 281210 - PMO */
                  , SD_TAXLOTINITIAL
                  , SD_TAXLOT
                  };


/* Contain all information related to a step */
struct STRUCT_FUSIONSTEP
{
    int                 M_iPrimaryStep;     /* Primary step in the xml file                                 */
    int                 M_iSecondaryStep;   /* Secondary step in the xml file   / PMSTA-8062 - 190509 - PMO */
    void *              M_pData;            /* Pointer on related data                                      */
    enum ENUMSTEPDATA   M_enumStepData;     /* Type of data                                                 */

    void set(const int iPrimaryStep, const int iSecondaryStep, const enum ENUMSTEPDATA enumStepData, void * pData)
    {
        M_iPrimaryStep      = iPrimaryStep;
        M_iSecondaryStep    = iSecondaryStep;
        M_enumStepData      = enumStepData;
        M_pData             = pData;
    }

};
typedef struct STRUCT_FUSIONSTEP FUSIONSTEP_ST, * FUSIONSTEP_STP;


enum ENUMSTEPPROCESSING { SP_INIT
                        , SP_LOAD
                        , SP_PROC
                        , SP_SAVE
                        };

/* How to handle a difference */
struct STRUCT_FUSIONDIFF
{
    FILE *                  hLogFile;               /* Handler of the log file                                                                          */
    int                     iReferenceStep;         /* Reference step to display                                                                        */
    unsigned                uStatCmpEventOk;        /* Statistics about how many events has been successfully compared                                  */
    unsigned                uStatCmpEventFail;      /* Statistics about how many events has been unsuccessfully compared                                */
    bool                    bDispField;             /* If we display the field                                                                          */
    bool                    bWriteLogField;         /* If we write the field in the log file                                                            */
    bool                    bContinueOnDiff;        /* If we continue to compare on difference                                                          */
    bool                    bCompareUD;             /* If we compare ud fields. Must be implemented                                                     */
    bool                    bCompareID;             /* If we compare ud field                                                                           */
    bool                    bCompareZeroEqualNULL;  /* If 0 must be considered equal to NULL                                / PMSTA-6921 - 311008 - PMO */
    bool                    bDebugOnDiff;           /* If we stop in the debugger on difference                                                         */
    bool                    bLoadDataFromFile;      /* If data are loaded from the xml trace file                                                       */
    bool                    bCheckLoad;             /* If we check while loading                                                                        */
    bool                    bCompareFusState;       /* If we compare fus state field                                        / PMSTA-8062 - 190509 - PMO */
    bool                    bRemoveUseLessFile;     /* Useless files are removed                                            / PMSTA08746 - 061009 - PMO */
    bool                    bAccruedInterest;       /* Set accrued interest when they are not computed from the reference file
                                                       Useful when it is not the same database                             / PMSTA-10139 - 041010 - PMO */
    enum ENUMSTEPPROCESSING eStepProcessing;        /* Current processing step                                                                          */

    STRUCT_FUSIONDIFF()
    {
        hLogFile                = NULL;
        iReferenceStep          = 0;
        uStatCmpEventOk         = 0;
        uStatCmpEventFail       = 0;
        bDispField              = true;
        bWriteLogField          = true;
        bContinueOnDiff         = true;
        bCompareUD              = false;
        bCompareID              = false;
        bCompareZeroEqualNULL   = true;
        bDebugOnDiff            = true;
        bLoadDataFromFile       = true;
        bCheckLoad              = false;
        bCompareFusState        = false;
        bRemoveUseLessFile      = false;
        bAccruedInterest        = false;
        eStepProcessing         = SP_INIT;
    }
};
typedef struct STRUCT_FUSIONDIFF FUSIONDIFF_ST, * FUSIONDIFF_STP;


/* To store information related to the function fusion loop */
struct STRUCT_FUSIONLOOP
{
    char szDate[11];    /* Date format JJ/MM/AAAA */
};
typedef struct STRUCT_FUSIONLOOP FUSIONLOOP_ST, * FUSIONLOOP_STP;


/* To store information related to the function pos fusion */
struct STRUCT_POSFUSION
{
    DBA_DYNFLD_STP pos1;
    DBA_DYNFLD_STP pos2;
    DBA_DYNFLD_STP resPos;
    DBA_DYNFLD_STP capProfitLossPos;
    DBA_DYNFLD_STP exchGainLossPos;
    int            fusionCptr;          /* PMSTA-9072 - 050510 - PMO */

    STRUCT_POSFUSION()
    {
        pos1                = NULL;
        pos2                = NULL;
        resPos              = NULL;
        capProfitLossPos    = NULL;
        exchGainLossPos     = NULL;
        fusionCptr          = 0;
    }

};
typedef struct STRUCT_POSFUSION POSFUSION_ST, * POSFUSION_STP;




/* To store the old and new ID / PMSTA-9072 - 050510 - PMO */
struct STRUCT_REMAPID
{
    ID_T idOld;
    ID_T idNew;

    STRUCT_REMAPID()
    {
        idOld  = 0;
        idNew  = 0;
    }

};
typedef struct STRUCT_REMAPID REMAPID_ST, * REMAPID_STP;




/* Contain all data loaded and parsed from the xml fusion trace */
struct STRUCT_DATAFILEFUSION
{
    DBA_DYNFLD_STP *    tabFusArg;                      /* Array with all FusArg            */
    int                 nbEntriesFusArg;                /* # of entries in tabFusArg        */
    DBA_DYNFLD_STP *    tabPtf;                         /* Array with all Ptf               */
    int                 nbEntriesPtf;                   /* # of entries in tabPtf           */
    DBA_DYNFLD_STP *    tabPosition;                    /* Array with all Positions         */
    int                 nbEntriesPosition;              /* # of entries in tabPosition      */
    DBA_DYNFLD_STP *    tabInstrument;                  /* Array with all Instruments       */
    int                 nbEntriesInstrument;            /* # of entries in tabInstrument    */
    DBA_DYNFLD_STP *    tabBalPos;                      /* Array with all Balance position  */
    int                 nbEntriesBalPos;                /* # of entries in tabBalPos        */
    DBA_DYNFLD_STP *    tabPosDetail;                   /* Array with all Position Details  */
    int                 nbEntriesPosDetail;             /* # of entries in tabPosDetail     */
    DBA_DYNFLD_STP *    tabBalPosDetail;                /* Array with all Bal pos detail    */
    int                 nbEntriesBalPosDetail;          /* # of entries in tabBalPosDetail  */
    DBA_DYNFLD_STP *    tabTaxLotInitial;               /* Array with all Tax Lot Init      */
    int                 nbEntriesTaxLotInitial;         /* # of entries in tabTaxLotInitial */
    DBA_DYNFLD_STP *    tabTaxLot;                      /* Array with all Tax Lots          */
    int                 nbEntriesTaxLot;                /* # of entries in tabTaxLot        */    
    DBA_DYNFLD_STP *    tabExtOp1;                      /* Array with all Extended position */
    int                 nbEntriesExtOp1;                /* # of entries in tabExtOp1        */
    DBA_DYNFLD_STP *    tabExtOp2;                      /* Array with all Extended position */
    int                 nbEntriesExtOp2;                /* # of entries in tabExtOp2        */
    DBA_DYNFLD_STP *    tabFusArg2;                     /* Array with all FusArg2           */
    int                 nbEntriesFusArg2;               /* # of entries in tabFusArg2       */
    FUSIONSTEP_STP      tabFusionStep;                  /* Array with all fusion step       */
    int                 nbEntriesFusionStep;            /* # of entries in tabFusionStep    */
    DBA_DYNFLD_STP *    tabUpdateDataBase;              /* Array with all UpdateDataBase                                        / PMSTA-9134  - 160310 - PMO */
    int                 nbEntriesUpdateDataBase;        /* # of entries in tabUpdateDataBase                                    / PMSTA-9134  - 160310 - PMO */
    DBA_DYNFLD_STP *    tabOperation1;                  /* Array with all operation issued from the ext_order                   / PMSTA-15298 - 040213 - PMO */
    int                 nbEntriesOperation1;            /* # of entries in tabOperation1                                        / PMSTA-15298 - 040213 - PMO */
    DBA_DYNFLD_STP *    tabOperation2;                  /* Array with all operation issued from the ext_order                   / PMSTA-15298 - 040213 - PMO */
    int                 nbEntriesOperation2;            /* # of entries in tabOperation1                                        / PMSTA-15298 - 040213 - PMO */
    DBA_DYNFLD_STP *    tabConversionPosition1;         /* Array with all operation issued from the ext_order                   / PMSTA-15298 - 040213 - PMO */
    int                 nbEntriesConversionPosition1;   /* # of entries in tabOperation1                                        / PMSTA-15298 - 040213 - PMO */
    DBA_DYNFLD_STP *    tabConversionPosition2;         /* Array with all operation issued from the ext_order                   / PMSTA-15298 - 040213 - PMO */
    int                 nbEntriesConversionPosition2;   /* # of entries in tabOperation1                                        / PMSTA-15298 - 040213 - PMO */
    REMAPID_STP         tabRemapBalPosType;             /* Array with all ID to remap                                           / PMSTA-9072  - 050510 - PMO */
    int                 nbEntriesRemapBalPosType;       /* # of entries in tabUpdateDataBase                                    / PMSTA-9072  - 050510 - PMO */
    FUSIONDIFF_ST       tagDiff;                        /* How to handle a difference       */
    SYSPARAMETERS_ST    tabSysParameters[56];           /* Array with system parameters                                         / PMSTA-9688  - 210410 - PMO */
    size_t              nbEntriesSysParameters;         /* # of entries in tabSysParameters */
    int                 nbFusionLoad;                   /* Current fusion load                                                  / PMSTA-14047 - 260412 - PMO */
    unsigned            uFnFusionLoop;                  /* Current value of SD_FUSIONLOOP   */
    unsigned            uFnPosFusion;                   /* Current value of SD_POSFUSION    */
    unsigned            uFnBalPosFusion;                /* Current value of SD_BALPOSFUSION */
    unsigned            uFnAdjExchangeWithFees;         /* Current value of SD_ADJEXCHANGEWITHFEES                              / PMSTA-9324  - 281210 - PMO */
    char *              pszRemapBalPosTypeFile;         /* File name of the remapping balance position type                     / PMSTA-9072  - 050510 - PMO */
    FusionContext *     ctx;                            /* Fusion context. for SQL hooks                                        / PMSTA-9072  - 050510 - PMO */
    const char *        pszFileName;                    /* Fusion trace file name                                               / PMSTA-9072  - 050510 - PMO */
    gzFile              hgzFile;                        /* Handle of the fusion trace                                           / PMSTA-14047 - 260412 - PMO */
    char                szCurrentTag[256];              /* Handling of double database load                                     / PMSTA-15298 - 040213 - PMO */
    int                 maxFusionLoad;                  /* # of load                                                            / PMSTA-15298 - 040213 - PMO */
    bool                bSameFilename;                  /* Fusion trace output file name have the same name than the input      / PMSTA-9072  - 050510 - PMO */
    bool                console;                        /* If the console mode is enabled                                                                    */
    bool                validation;                     /* Validation mode                                                      / PMSTA-27843 - 200717 - PMO */

    STRUCT_DATAFILEFUSION()
    {
        tabFusArg                       = NULL;
        nbEntriesFusArg                 = 0;
        tabPtf                          = NULL;
        nbEntriesPtf                    = 0;
        tabPosition                     = NULL;
        nbEntriesPosition               = 0;
        tabInstrument                   = NULL;
        nbEntriesInstrument             = 0;
        tabBalPos                       = NULL;
        nbEntriesBalPos                 = 0;
        tabPosDetail                    = NULL;
        nbEntriesPosDetail              = 0;
        tabBalPosDetail                 = NULL;
        nbEntriesBalPosDetail           = 0;
        tabTaxLotInitial                = NULL;
        nbEntriesTaxLotInitial          = 0;
        tabTaxLot                       = NULL;
        nbEntriesTaxLot                 = 0;
        tabExtOp1                       = NULL;
        nbEntriesExtOp1                 = 0;
        tabExtOp2                       = NULL;
        nbEntriesExtOp2                 = 0;
        tabFusArg2                      = NULL;
        nbEntriesFusArg2                = 0;
        tabFusionStep                   = NULL;
        nbEntriesFusionStep             = 0;
        tabUpdateDataBase               = NULL;
        nbEntriesUpdateDataBase         = 0;
        tabOperation1                   = NULL;
        nbEntriesOperation1             = 0;
        tabOperation2                   = NULL;
        nbEntriesOperation2             = 0;
        tabConversionPosition1          = NULL;
        nbEntriesConversionPosition1    = 0;
        tabConversionPosition2          = NULL;
        nbEntriesConversionPosition2    = 0;
        tabRemapBalPosType              = NULL;
        nbEntriesRemapBalPosType        = 0;
        nbEntriesSysParameters          = sizeof(tabSysParameters) / sizeof(tabSysParameters[0]);
        nbFusionLoad                    = 0;
        clearFunctionCallCounters();
        pszRemapBalPosTypeFile          = NULL;
        ctx                             = NULL;
        pszFileName                     = NULL;
        hgzFile                         = NULL;
        szCurrentTag[0]                 = 0;
        maxFusionLoad                   = 0;
        bSameFilename                   = false;
        console                         = false;
        validation                      = false;

        assert(sizeof(SV_tabSysParameters)==sizeof(tabSysParameters));

        /* Copy all parameters */
        for(unsigned idx = 0; idx < sizeof(SV_tabSysParameters) / sizeof(SV_tabSysParameters[0]); idx++)
        {
            tabSysParameters[idx] = SV_tabSysParameters[idx];
        }
    }



    /* After the load from the xml file, counters must be reset for comparing with a normal execution / PMSTA-8062 - 190509 - PMO */
    void clearFunctionCallCounters()
    {
        uFnFusionLoop           = 0;
        uFnPosFusion            = 0;
        uFnBalPosFusion         = 0;
        uFnAdjExchangeWithFees  = 0;
    }

    /* Remove positions and balance positions PMSTA-27843 - 200717 - PMO */
    void clearPositionBalancePosition()
    {
        DBA_FreeDynStTab(tabPosition, nbEntriesPosition, ExtPos);
        DBA_FreeDynStTab(tabBalPos,   nbEntriesBalPos,   ExtPos);
        DBA_FreeDynStTab(tabPosDetail, nbEntriesPosDetail, ExtPos);
        DBA_FreeDynStTab(tabBalPosDetail, nbEntriesBalPosDetail, ExtPos);
        DBA_FreeDynStTab(tabTaxLotInitial, nbEntriesTaxLotInitial, A_TaxLotInitial);
        DBA_FreeDynStTab(tabTaxLot, nbEntriesTaxLot, A_TaxLot);

        tabPosition                     = nullptr;
        nbEntriesPosition               = 0;
        tabBalPos                       = nullptr;
        nbEntriesBalPos                 = 0;
        tabPosDetail                    = nullptr;
        nbEntriesPosDetail              = 0;
        tabBalPosDetail                 = nullptr;
        nbEntriesBalPosDetail           = 0;
        tabTaxLotInitial                = nullptr;
        nbEntriesTaxLotInitial          = 0;
        tabTaxLot                       = nullptr;
        nbEntriesTaxLot                 = 0;
    }

    void addEntry(DBA_DYNFLD_STP * &,  int &, DBA_DYNFLD_STP);
    void addEntry(REMAPID_STP &      , int &, REMAPID_STP);     /* PMSTA-9072 - 050510 - PMO */

    void addFusArg(DBA_DYNFLD_STP pFusArg)
    {
        addEntry(tabFusArg, nbEntriesFusArg, pFusArg);
    }

    void addPtf(DBA_DYNFLD_STP pPtf)
    {
        addEntry(tabPtf, nbEntriesPtf, pPtf);
    }

    void addPosition(DBA_DYNFLD_STP pPosition)
    {
        addEntry(tabPosition, nbEntriesPosition, pPosition);
    }

    void addPosDetail(DBA_DYNFLD_STP pPosDetail)
    {
        addEntry(tabPosDetail, nbEntriesPosDetail, pPosDetail);
    }

    void addConversionPosition(DBA_DYNFLD_STP pPosition)
    {
        if (1 == maxFusionLoad)
        {
            addEntry(tabConversionPosition1, nbEntriesConversionPosition1, pPosition);
        }
        else
        {
            addEntry(tabConversionPosition2, nbEntriesConversionPosition2, pPosition);
        }
    }

    void addInstrument(DBA_DYNFLD_STP pInstrument)
    {
        addEntry(tabInstrument, nbEntriesInstrument, pInstrument);
    }

    void addBalPos(DBA_DYNFLD_STP pBalPos)
    {
        addEntry(tabBalPos, nbEntriesBalPos, pBalPos);
    }

    void addBalPosDetail(DBA_DYNFLD_STP pBalPosDetail)
    {
        addEntry(tabBalPosDetail, nbEntriesBalPosDetail, pBalPosDetail);
    }

    void addTaxLotInitial(DBA_DYNFLD_STP pTaxLotInitial)
    {
        addEntry(tabTaxLotInitial, nbEntriesTaxLotInitial, pTaxLotInitial);
    }

    void addTaxLot(DBA_DYNFLD_STP pTaxLot)
    {
        addEntry(tabTaxLot, nbEntriesTaxLot, pTaxLot);
    }
    
    void addExtOp(DBA_DYNFLD_STP pExtOp)
    {
        if (nullptr != pExtOp)
        {
            if (1 == maxFusionLoad)
            {
                addEntry(tabExtOp1, nbEntriesExtOp1, pExtOp);
            }
            else
            {
                addEntry(tabExtOp2, nbEntriesExtOp2, pExtOp);
            }
        }
    }

    void addFusArg2(DBA_DYNFLD_STP pFusArg)
    {
        addEntry(tabFusArg2, nbEntriesFusArg2, pFusArg);
    }

    void addExtOpConversionOperation(DBA_DYNFLD_STP pOperation)
    {
        if (1 == maxFusionLoad)
        {
            addEntry(tabOperation1, nbEntriesOperation1, pOperation);
        }
        else
        {
            addEntry(tabOperation2, nbEntriesOperation2, pOperation);
        }
    }

    void addUpdateDataBase(DBA_DYNFLD_STP pPos)
    {
        addEntry(tabUpdateDataBase, nbEntriesUpdateDataBase, pPos);
    }

    /* PMSTA-9072 - 050510 - PMO */
    void addRemapBalPosType(REMAPID_STP pRemapID)
    {
        addEntry(tabRemapBalPosType, nbEntriesRemapBalPosType, pRemapID);
    }

    void setSetSystemParameter(const char * pszAppl, const long lValue)
    {
        bool bFound = false;

        for(unsigned idx = 0; idx < nbEntriesSysParameters; idx++)
        {
            /* Check if we have found the system parameter */
            if (0 == strcmp(tabSysParameters[idx].pszName, pszAppl))
            { /* Yes */
                /* Set the value and leave */
                tabSysParameters[idx].lValue   = lValue;
                tabSysParameters[idx].bDefined = true;  /* PMSTA-9175 - 050110 - PMO */
                bFound = true;
                break;
            }
        }

        if (false == bFound)
        {
            throw std::invalid_argument(pszAppl);
        }
    }

    bool applyAllSystemParameter()
    {
        bool bRet = true; /* Function return value */

        for(unsigned idx = 0; idx < nbEntriesSysParameters; idx++)
        {
            /* PMSTA-9175 - 050110 - PMO */
            if (true == tabSysParameters[idx].bDefined)
            {
                if (TRUE != GEN_SetApplInfo(tabSysParameters[idx].applParameter, &tabSysParameters[idx].lValue))
                { /* Error */
                    bRet = false;
                    break;
                }
            }
        }

        return bRet;
    }

    void openLogFile()
    {
        char szPath[512];
        (void)snprintf(szPath, sizeof(szPath), "%s/%s", SYS_GetEnv("AAAMSG"), "diff_fusion.txt");
        tagDiff.hLogFile = fopen(szPath,"a+b");
    }

    void closeLogFile()
    {
        if (NULL != tagDiff.hLogFile)
        {
            fclose(tagDiff.hLogFile);
        }
    }

    /* This enable unit testing validation mode PMSTA-27843 - 200717 - PMO */
    void setValidationMode()
    {
        validation = true;
    }

    bool isValidationMode()
    {
        return validation;
    }

    void addFusionStep(FUSIONSTEP_STP);
    void sort(int (*)(const void *, const void *));
    void check(const int, const ENUMSTEPDATA, void *);
    void checkBalance(const DATETIME_T);
    void getTagPosFusion(const int, POSFUSION_STP *);
    void free();
    void freeFusionLoadData();
    void checkOpenedPositions(FIN_FUS_CONTEXT_STP);
};

typedef struct STRUCT_DATAFILEFUSION DATAFILEFUSION_ST, *DATAFILEFUSION_STP;


class DftFusionReport 
{
    public:
        DftFusionReport(std::ostringstream & outputBuff, std::string & testName) : m_output   (outputBuff)
                                                                                 , m_testName (testName)
                                                                                 , m_testOk   (true)
                                                                                 , m_first    (true)
        {
        }

        DftFusionReport            (const DftFusionReport &) = delete;
        DftFusionReport & operator=(const DftFusionReport &) = delete;

        std::ostringstream &    m_output;
        std::string &           m_testName;
        bool                    m_testOk;
        bool                    m_first;
};

/* PMSTA-28355 - 291017 - PMO 
 * Allow to add an open html tag with the constructor if the condition is meet
 * And close the tag with the destructor
 */
class DftFusionConditionalTag
{
    public:
        DftFusionConditionalTag(std::string & data, const std::string & tag, bool condition = true) : m_data     (data)
                                                                                                    , m_tag      (tag)
                                                                                                    , m_condition(condition)
        {
            if (true == m_condition)
            {
                m_data += "<";
                m_data += m_tag;
                m_data += ">";
            }
        }

        ~DftFusionConditionalTag()
        {
            if (true == m_condition)
            {
                m_data += "</";
                m_data += m_tag;
                m_data += ">";
            }
        }

        DftFusionConditionalTag            (const DftFusionConditionalTag &) = delete;
        DftFusionConditionalTag & operator=(const DftFusionConditionalTag &) = delete;

    private:
        std::string &   m_data;
        std::string     m_tag;
        bool            m_condition;
};


/* PMSTA-27631 - 270617 - PMO 
 *
 * Management of keywords written in the header of the file.
 *
 * At startup, all flags are defined to false.
 * For each position a call to updateKeywords must be done.
 * 
 * The function updateKeywords will analyze the position.
 * For example, if it is an "Margin Call" position,
 * The flag Adjustment will be defined as well the flag AdjustmentMarginCall
 *
 * When all position are treated. the call to getKeywordsLine will return a line will all keywords encountered
 */
class DftFusionQuickCheckHeaderKeywords
{
    public:
        DftFusionQuickCheckHeaderKeywords();

        DftFusionQuickCheckHeaderKeywords            (const DftFusionQuickCheckHeaderKeywords &) = delete;
        DftFusionQuickCheckHeaderKeywords & operator=(const DftFusionQuickCheckHeaderKeywords &) = delete;

        void        updateKeywords (const PosLog &);
        bool        checkKeywords  (const std::string &, const std::string &);
        std::string getKeywordsLine();
        std::string getMissingExpectedKeywords();

        bool hasTaxLot()
        {
            return m_TaxLot;
        }

    private:
        std::set<std::string>   m_setKnownKeywords;         // All known keywords
        std::string             m_MissingExpectedKeywords;
        bool                    m_AdjustmentGrossAmt;
        bool                    m_AdjustmentPL;
        bool                    m_AdjustmentManualBookAdj;
        bool                    m_AdjustmentAutomaticBookAdj;
        bool                    m_AdjustmentMarketPrice;
        bool                    m_AdjustmentAcqCostBookValue;
        bool                    m_AdjustmentBookAdjFunction;
        bool                    m_AdjustmentMarginCall;
        bool                    m_AdjustmentPtfTransfLocked;
        bool                    m_AdjustmentProportional;
        bool                    m_AdjustmentExchange;
        bool                    m_AdjustmentCostPrice;
        bool                    m_AdjustmentExchangeWithFees;
        bool                    m_AdjustmentPartiallyPaid;
        bool                    m_OpNat[OpNat_OpNatNbr];
        bool                    m_OpFuture;
        bool                    m_OpForex;
        bool                    m_OpForward;
        bool                    m_TaxLot;                               /* PMSTA-28340 - 270917 - PMO */
};


/* PMSTA-28355 - 291017 - PMO 
 * Contains common properties for doing checks
 */
class DftFusionQuickCheckCtx
{
    public:
        DftFusionQuickCheckCtx(FIN_FUS_CONTEXT_STP ctx) : m_ctx              (ctx)
                                                        , m_compute          (false)
                                                        , m_computeHtmlOutput(false)
        {
        }

        FIN_FUS_CONTEXT_STP getCtx()
        {
            return m_ctx;
        }

        bool isCompute() const
        {
            return m_compute;
        }

        bool isComputeHtmlOutput() const
        {
            return m_computeHtmlOutput;
        }

        void enableComputeHtmlOutput()
        {
            m_compute           = true;
            m_computeHtmlOutput = true;
        }

    private:
        FIN_FUS_CONTEXT_STP     m_ctx;                 /* Fusion context                                                              */
        bool                    m_compute;             /* Do only the computation. This mode allow to save data into the fusion trace */
        bool                    m_computeHtmlOutput;   /* Do only the computation. This mode allow to save data into the fusion trace */
};


/* PMSTA-23318 - 120516 - PMO 
 * On the fly checks of fusion results. This part cover TaxLot & TaxLotInitial entities
 */
class DftFusionQuickCheckBasic
{
    public:
        DftFusionQuickCheckBasic(DftFusionQuickCheckCtx & checkCtx) : m_refCheckCtx(checkCtx)
        {
        }

        ~DftFusionQuickCheckBasic()
        {
        }

        DftFusionQuickCheckBasic            (const DftFusionQuickCheckBasic &) = delete;
        DftFusionQuickCheckBasic & operator=(const DftFusionQuickCheckBasic &) = delete;

        void                addBalancePosAmount           (std::vector<FIELD_IDX_T> &, std::vector<FIELD_IDX_T> &, const size_t, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, const bool &, const bool &);
        void                addFormatedExtPosRecord       (std::vector<FIELD_IDX_T> &, std::vector<FIELD_IDX_T> &, DBA_DYNFLD_STP, DBA_DYNFLD_STP, const DBA_DYNFLD_STP, std::string &, std::string &, FIELD_IDX_T, const size_t, const bool &);
        void                addFormatedTaxLotRecord       (PosLog &, DBA_DYNFLD_STP, std::string &, std::string &, std::string &, FIELD_IDX_T, const size_t);
        void                addFormatedTaxLotInitialRecord(PosLog &, DBA_DYNFLD_STP, std::string &, std::string &, std::string &, FIELD_IDX_T, const size_t);
        std::string         formatAmount                  (const AMOUNT_T &);
        FIN_FUS_CONTEXT_STP getCtx                        ();
        void                getInstrBpName                (const PosLog &, std::string &);
        void                getInstrTaxLotName            (const PosLog &, std::string &);
        DBA_DYNFLD_STP      getTaxLot                     (const PosLog &);
        DBA_DYNFLD_STP      getTaxLotInitial              (const PosLog &);

        // Check for the computation mode. This mode allow to save data into the fusion trace
        bool isCompute() const
        {
            return m_refCheckCtx.isCompute();
        }

        // Check html output mode. This mode allow to save data into the fusion trace
        bool isComputeHtmlOutput() const
        {
            return m_refCheckCtx.isComputeHtmlOutput();
        }

        // Enable html output mode. This mode allow to save data into the fusion trace
        void enableComputeHtmlOutput ()
        {
            m_refCheckCtx.enableComputeHtmlOutput();
        }

        std::string         parseAndCompare               (const std::string &, const std::string &, std::vector<FIELD_IDX_T> &, std::vector<FIELD_IDX_T> &, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, const bool &, const bool &, bool &);
        void                writeDataLines                (std::fstream &);
        void                buildHtmlHeaderArray          (std::string &, const std::vector<FIELD_IDX_T> &, const DBA_DYNFLD_STP);
        void                addHtmlTagAndValue            (std::string &, const std::string &, const std::string &);

    protected:
        void _addFormatedRecord(std::vector<FIELD_IDX_T> &, std::vector<FIELD_IDX_T> &, DBA_DYNFLD_STP, DBA_DYNFLD_STP, const DBA_DYNFLD_STP, std::string &, std::string &, std::string &, FIELD_IDX_T, const size_t, const bool &);

        std::string                      m_instrName;           /* Current instrument name                                  */
        std::string                      m_dataLines;           /* Lines of data to be written                              */
        DftFusionQuickCheckCtx &         m_refCheckCtx;         /* All common properties for doing checks                   */
};


/* PMSTA-23318 - 120516 - PMO 
 * On the fly checks of fusion results. This part cover TaxLot entity
 */
class DftFusionQuickCheckTaxLot : public DftFusionQuickCheckBasic
{
    public:
        DftFusionQuickCheckTaxLot(DftFusionQuickCheckCtx &);
        ~DftFusionQuickCheckTaxLot();

        DftFusionQuickCheckTaxLot            (const DftFusionQuickCheckTaxLot &) = delete;
        DftFusionQuickCheckTaxLot & operator=(const DftFusionQuickCheckTaxLot &) = delete;

        void        fill        (const ID_T &, std::string &);
        std::string compareAll  (std::fstream &, const std::string &, const PosLog &, bool &);

    private :
        std::vector<FIELD_IDX_T> fields;
};


/* PMSTA-23318 - 120516 - PMO 
 * On the fly checks of fusion results. This part cover TaxLotInitial entity
 */
class DftFusionQuickCheckTaxLotInitial : public DftFusionQuickCheckBasic
{
    public:
        DftFusionQuickCheckTaxLotInitial(DftFusionQuickCheckCtx &);
        ~DftFusionQuickCheckTaxLotInitial();

        DftFusionQuickCheckTaxLotInitial            (const DftFusionQuickCheckTaxLotInitial &) = delete;
        DftFusionQuickCheckTaxLotInitial & operator=(const DftFusionQuickCheckTaxLotInitial &) = delete;

        void        fill        (const ID_T &, std::string &);
        std::string compareAll  (std::fstream &, const std::string &, const PosLog &, bool &);

    private :
        std::vector<FIELD_IDX_T> fields;
};


/* PMSTA-23318 - 120516 - PMO 
 * On the fly checks of fusion results
 */
class DftFusionQuickCheck : public DftFusionQuickCheckBasic
{
    public:
        DftFusionQuickCheck(FIN_FUS_CONTEXT_STP);
        ~DftFusionQuickCheck();

        void quickCheck();
        void checkFeesPosNetGross           (const DBA_DYNFLD_STP, bool &);
        void checkFeesNetVsGross            (const DBA_DYNFLD_STP, bool &, const char *, const FIELD_IDX_T, const FIELD_IDX_T);
        void checkNegativeExchangeRate      (const DBA_DYNFLD_STP, bool &);
        void checkCloseFutureFeesAccount3   (const DBA_DYNFLD_STP);
        void checkTotalCashAccount          (const ID_T);

        void        computeOnly               (const ID_T);
        std::string getComputedOpenedPositions();
        std::string getComputedOpenedTaxLot();
        std::string getComputedOpenedTaxLotInitial();
        std::string getComputedBalance        ();

        void getOperationsInvolved(DBA_DYNFLD_STP, std::string &);
        void saveSystemParameters ();
        void log                  (const std::string &);
        void logFile              (const std::string &);
        void logConsole           (const std::string &);

    private:
        void quickFusionTestCompareAndLog(const char *, DBA_DYNFLD_STP, const double, const double, const int, const double);
        void checkCurrenciesAmounts      (const ID_T);
        void checkBalanceVsBalance       (const std::string &, const std::vector<FIELD_IDX_T> &, const DBA_DYNFLD_STP, const DBA_DYNFLD_STP, bool &);
        void taxLotProcessing            (const ID_T, const bool, bool &, std::string &, std::string &);
        void _taxLotProcessing           (const ID_T, const bool, bool &);
        void writeBalance                (const std::vector<FIELD_IDX_T> &, const DBA_DYNFLD_STP, const bool = false);

        std::fstream                     m_streamLogFile;           /* Processing log file                                      */
        std::fstream                     m_streamFile;              /* Storage of difference if any                             */
        std::string                      m_ptfName;                 /* Current portfolio name                                   */
        std::string                      m_dateTime;                /* Time for the writing into the log                        */
        std::string                      m_computePositions;        /* Opened positions of the computation                      */
        std::string                      m_computeTaxLot;           /* Opened TaxLot of the computation                         */
        std::string                      m_computeTaxLotInitial;    /* Opened TaxLot of the computation                         */
        std::string                      m_computeBalance;          /* The balance ot the opened positions of the computation   */
        ID_T                             m_computePtfID;            /* Do only the computation for this portfolio ID            */
        bool                             m_logConsole;              /* do output console                                        */
        std::ostream *                   m_streamLog;               /* Processing log file                                      */
        DftFusionQuickCheckCtx           m_checkCtx;                /* Contains common properties for doing checks              */
        DftFusionQuickCheckTaxLot        m_taxLot;                  /* Validation of TaxLot                                     */
        DftFusionQuickCheckTaxLotInitial m_taxLotInitial;           /* Validation of TaxLot�Initial                             */
};


/************************************************************************
**
** Functions for testing the fusion
**
*************************************************************************/

extern void             DFT_TestFusion (const char *);
extern void             DFT_LoadFusionSecondTime(FIN_FUS_CONTEXT_STP);
extern bool             DFT_XMLDump (const DBA_DYNFLD_STP);
extern DBA_DYNFLD_STP   DFT_XMLDumpLoad(const char *);
extern void             DFT_TestsFusionModeValidation(std::ostringstream &output, const char *directory, const char * fileName);

#endif	 /* ifndef DFTTESTFUSION_H */

/************************************************************************
**      END        dfttestfusion.h                                    
*************************************************************************/


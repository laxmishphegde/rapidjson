/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBADEF_H
#define DBADEF_H

/* Disable message 956 031008 - PMO */
/*lint -save -e(956) */

typedef int OBJECT_ENUM;
#define szFormatObj "%d"

typedef short DBA_DYNST_ENUM;

#define NullEntityCst       -1
#define InvalidEntityCst     0

#define ApplParamCst 		100
#define CurrCst 			101
#define SectCst 			103
#define RatingCst 			104
#define TpCst 				105
#define CalendarCst		    106
#define NotepadCst 			107
#define TabModifStatCst 	109
#define CurrChronoCst 110
#define CurrModifCst 111
#define ClientConnectCst 112
#define CalendarConvCst 113
#define CalendarDateCst 114
#define CurrFreqCst 115
#define ArchiveCst 116
#define QuickSearchCst 117
#define OneCst 119
#define EmptyCst 120
#define OptiProfCst         122		/* REF11767 - CHU - 060331 */
#define OptiProfCompoCst    123		/* REF11767 - CHU - 060331 */
#define OptiProcCst         124		/* REF11767 - LJE - 060418 */
#define ApplCommentCst      125		/*  PMSTA-11368-HFI-110203  */
#define BoottimeCst         128     /* PMSTA-16365 - 140509 */

        /* Multilingual and synonyms */
#define DenomCst 200
#define ApplMsgCst 203
#define ApplMsgTxtCst 204
#define WarningMsgEntCst 205
#define RequestCodeCst 206 /*REF10604-BRO-040922*/

        /* Security */
#define ApplUserCst 300
#define DataSecuProfCst 301
#define FctSecuProfCst 302
#define FctSecuProfCompoCst 303
#define ScreenProfCst 305
#define ScreenProfCompoCst 306
#define PrinterCst 307
#define PrinterProfCst 308
#define PrinterProfCompoCst 309
#define ApplPswdHistCst 310
#define LoginFailedCst 312
#define DataProfCst 313
#define DataProfCompoCst 314
#define SearchCritCst       315     /*  FIH-REF9789-031222  */
#define SearchCritCompoCst  316     /*  FIH-REF9789-031222  */
#define SearchProfCst       317     /*  FIH-REF9789-031222  */
#define SearchProfCompoCst  318     /*  FIH-REF9789-031222  */
#define SelSearchCritCompoArgCst  319     /* PMSTA-15655 - LJE - 130121 */
#define SelFctSecuProfCompoArgCst 320       /*  HFI-PMSTA-35838-190515  */

#define ApplChannelProfCst			331 /* PMSTA-22551 - EFE - 20160323 */
#define ApplChannelProfCompoCst	332 /* PMSTA-22551 - EFE - 20160323 */

        /* List */
#define ListCst 400
#define ListCompoCst 401
#define ClassifCst 402
#define ClassifCompoCst 403
#define MktSegtCst 404
#define GridCst 405
#define CheckListCst 407
#define ReturnGridLnkCst 408
#define ListChronoCst 409
#define MktStructCst 410
#define MktSSubSetCst 411

        /* Investment guidelines */
#define StratCst 500
#define StratEltCst 501
#define StratLnkCst 502
#define StratHistCst 503
#define SearchLnkEntCst 504
#define EStratLnkCst 505
#define EStratEltCst 506
#define StratEltDetailCst 507
#define FctResultCst 508
#define BenchWeightCst 509
#define ModelConstrCst 510
#define ModelConstrEltCst 511
#define DerivedStratCst 512
#define DerivedStratEltCst 513
#define TradConstrCst 514
#define ConstrTemplateCst 515
#define TemplateEltCst 516
#define ConstraintParameterCst 517
#define StratCompoCst 518
#define ConstraintBreachCst 519
#define ComplianceChronoCst 520
#define CaseManagementCst 521			/* PMSTA07121-CHU-081008 */
#define CaseClarificationCst 522		/* PMSTA07121-CHU-081008 */
#define CaseLinkCst 523					/* PMSTA07121-CHU-081008 */
#define CaseMsgTemplateCst 524          /* PMSTA07121-CHU-081014 */
#define CaseMsgTemplateDefCst 525       /* PMSTA07121-CHU-081014 */
#define StratSynthCst 526				/* PMSTA08737 - LJE - 091109 */
#define VarStratEltCst 527				/* PMSTA08747-CHU-091112 */
#define RiskESEltCst 528				/* PMSTA-18426-CHU-140922 */
#define RiskValueEltCst 529				/* PMSTA-18426-CHU-140922 */
#define RiskESEltCompoCst 530			/* PMSTA-18426-CHU-141014 */
#define RiskValueEltCompoCst 531		/* PMSTA-18426-CHU-141014 */
#define	CaseRuleCst  532	        	/* PMSTA- 18760 -cashwini-140205 */
#define LombardCheckCst       533      /*  PMSTA-21045- cashwini-150818 */

        /* Third parties */
#define AddrCst 602
#define SectAttrCst 603
#define RatingAttrCst 604
#define ThirdFreqCst 605
#define BusEntityCst 606                /* 606 business_entity        - PMSTA-17089 - DDV - 131106 */
#define BusOrgaCst 607                  /* 607 business_orga          - PMSTA-17089 - DDV - 131106 */
#define BusEntityPtfCompoCst 608        /* 608 bus_entity_ptf_compo   - PMSTA-17089 - DDV - 131106 */
#define BusEntityInstrCompoCst 609      /* 609 bus_entity_instr_compo - PMSTA-17089 - DDV - 131106 */
#define BusEntityThirdCompoCst 610      /* 610 bus_entity_third_compo - PMSTA-17089 - DDV - 131106 */
#define BusEntityAddrCst      612       /* 612 bus_entity_address     - PMSTA-17089 - DDV - 131203 */
#define QuestHistoCst 613               /* 613 questionnaire_histo    - PMSTA-19243 - DDV - 150312 */


        /* Quotation infrastructure */
#define InstrPriceCst 700
#define ExchRateCst 701
#define ExchFmtCst 702
#define ScenaCst 703
#define ScenaCompoCst 704
#define ScenaEltCst 705
#define StatCst 706
#define RegrCst 707
#define RiskRatioCst 708

        /* Portfolios */
#define PtfCst 800
#define PtfChronoCst 801
#define PayInstructCst 802
#define MgrCst 803
#define PtfPosSetCst 804
#define BalPosRuleCst 805
#define BalPosRuleSetCst 806
#define AccPerParamCst 807
#define AdminMgrCst 808
#define CommMgrCst 809
#define PtfSynthCst 810
#define PtfFusionEntCst 811
#define PtfReturnCst 812
#define AccPerCst 813
#define AccPlanEltCst 814
#define FundValCst 815
#define FundValEltCst 816
#define AccPlanCst 817
#define FTConvCst 818
#define FTRateHistCst 819
#define FTRateCst 820
#define PtfFreqCst 821
#define PerfStorageParamCst 823
#define PerfAttribCst 824
#define StandardPerfCst 825
#define ExtRetAnalysisCst 826
#define PerfAttribDataCst 828
#define RetAnaDetailedCst 829
#define RetAnaGlobalCst 830
#define RetAnalysisIdCst 831
#define StdPerfDataCst 832
#define PSPPositionDataCst 833
#define PerfAttribIdCst 834
#define AccProfileHistoCst 835
#define AccProfileCst 836
#define AccProfileCompoCst 837
#define StandInstructCst 838		/*PMSTA06761-BRO-080704*/
#define PerfEffectDefCst 839 /* PMSTA08736 - LJE - 100115 */
#define PerfEffectLinkCst 840 /* PMSTA08736 - LJE - 100115 */
#define PerfCurrencyContribCst 841 /* PMSTA08736 - LJE - 100115 */
#define PerfInterBenchCst 842 /* PMSTA08736 - LJE - 100115 */
#define PlanRuleCst	843 /*PMSTA-21268 - SHR - 092115*/
#define PlanRuleHistoCst 844 /*PMSTA-21268 - SHR - 092115*/
#define PlanDefinitionCst 845 /*PMSTA-21268 - SHR - 092115*/
#define PlanObjectiveHistoCst 846 /*PMSTA-21268 - SHR - 092115*/
#define PlanInvestParamHistoCst 847 /*PMSTA-21268 - SHR - 092115*/
#define	PlanInvestDateCst	848 /*PMSTA-21268 - SHR - 092115*/
#define FreeDepositHistoCst 849 /*PMSTA-21268 - SHR - 092115*/
#define ExtOrderBlockIdCst 850 /*PMSTA-46001 - AAKASH - 161221*/


        /* Financial instruments */
#define InstrCst 900
#define ExchEvtCst 901
#define IncEvtCst 902
#define IssueEvtCst 903
#define EvtExclCst 905
#define InterCondCst 906
#define InstrCompoCst 907
#define InstrChronoCst 908
#define FundWgtCst 909
#define GuaranteeCst 910
#define UInterCst 911
#define YtmCst 912
#define InstrFlowCst 913
#define CompInstrChronoCst 914
#define AdvACst 915
#define InstrFreqCst 916
#define DataDescCst 917
#define DataDispCst 918
#define TradingPlaceCst 919
#define TradingCurrencyCst 920
#define CorporateActionCst     921 /*REF10603-EFE-041018*/
#define CorpActionDetailCst    922 /*REF10603-EFE-041018*/
#define InstrDepositCst 923        /*REF11718-BRO-060301*/
#define InstrRiskOrigCst 924 /* PMSTA-18096 - LJE - 140620 */
#define CompComplChronoCst 925 /* PMSTA-18426 - CHU - 141004 */
#define ComplianceChronoFreqCst 926 /*PMSTA-22458 - cashwini - 04062016*/

        /* Positions and transactions */
#define PosCst 1000
#define BalPosCst 1001
#define BalPosTpCst 1002
#define DepoCst 1003
#define OpCst 1004
#define EventSchedCst 1005
#define OpCompoCst 1006
#define EPosCst 1007
#define PValCst 1008
#define OpDomainEntCst 1009
#define BuyOpEntCst 1010
#define SellOpEntCst 1011
#define InvestOpEntCst 1012
#define WithdrOpEntCst 1013
#define IncOpEntCst 1014
#define ShareIssOpEntCst 1015
#define ShareRedmOpEntCst 1016
#define TransfOpEntCst 1017
#define BpTransfOpEntCst 1018
#define AdjustOpEntCst 1019
#define FtOpEntCst 1020
#define DocIndexCst 1021
#define EOpCst 1022
#define ShareOpInfoCst 1023
#define LockOpEntCst 1024
#define PtfTransfOpEntCst 1025
#define BookAdjOpEntCst 1026
#define PosValHistCst 1027
#define BookValueCst 1028
#define InitOpEntCst 1029
#define ExecutionEntCst 1030
#define GlExecFeeEntCst 1031
#define ExtExecutionEntCst 1032
#define ExtOrderCst           1033      /* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
#define UnMatchedExecutionCst 1034		/* REF9764 - CHU - 031222 */
#define ExtTransactionCst     1035      /* REF9764 - LJE - 040106 */
#define UnMatchedGlExecFeeCst 1036		/*REF10025-BRO-040401*/
#define CommunicationCst      1037		/*REF11810-BRO-060609*/
#define CombinedOpEntCst      1038      /*PMSTA06760-BRO-080701*/
#define	CompoundOrderRuleCst  1039		/*PMSTA- 18634 - SHR - 140904 */
#define	CompoundOrderMasterEltCst	1040	/*PMSTA- 18634 - SHR - 140904 */
#define	CompoundOrderSlaveEltCst	1041	/*PMSTA- 18634 - SHR - 140904 */
#define ExtTaxLotCst          1044      /* PMSTA-31342 - SANAND - 180528 */

        /* Meta dictionary */
#define DictUserCst 1099
#define DictDataTpCst 1100
#define DictEntityCst 1101
#define DictCriterCst 1102
#define DictAttrCst 1103
#define DictLabelCst 1104
#define DictPermValCst 1105
#define DictLangCst 1106
#define DictFctCst 1107
#define DictPanelCst 1108
#define DictScreenCst 1109
#define DictSprocCst 1110      /* PMSTA-11999 - RPO - 110504 */
#define DictSprocParamCst 1111 /* PMSTA-11999 - RPO - 110504 */
#define DictViewCst 1112       /* PMSTA-11999 - RPO - 110504 */
#define DictDatabaseCst 1113   /* PMSTA-13109 - LJE - 111123 */
#define DictSegmentCst 1114    /* PMSTA-13109 - LJE - 111123 */
#define DictFctAttribCst 1115  /* PMSTA13244 - DDV - 120120 */

	    /* Help system */
#define EntityCommentCst 1150
#define AttributeCommentCst 1151
#define PermValCommentCst 1152
#define ApplParamCommentCst 1153

	    /* Domain */
#define DomainCst 1200
#define FmtProfCst 1204
#define FmtProfCompoCst 1205
#define DocCst 1206
#define FolderCst 1207
#define PrintParamCst 1208
#define ReportCst 1209
#define ReportProfCst 1210
#define ReportProfCompoCst 1211
#define TabCntCst 1212
#define ReportGenCst 1213
#define ReportParamCst 1214
#define DataSetDefCst 1215					/*PMSTA01389-BRO-070314*/
#define ExportDataCst 1216					/* OCS42034-JPP-20121120 */

	    /* External Service */
#define ExtServiceCst 1221						/*PMSTA-18426-CHU-140922*/
#define ExtServiceCompoCst 1222					/*PMSTA-18426-CHU-140922*/

#define QuestScreenHistoCst   1223    /* 1223 questionnaire_screen_histo - PMSTA-19243 - DDV - 150312 */
#define DomainPtfCompoCst     1228    /* 1228 domain_portfolio_compo - PMSTA-21105 - cashwini - 150831*/
#define ExtServiceProfCst     1229    /* 1229 ext_service_profile - PMSTA-22496 - DDV - 160509 */
#define ExtServiceProfCompoCst 1230   /* 1230 ext_service_profile - PMSTA-22496 - DDV - 160509 */

	    /* Script */
#define ScriptDefCst 1300
#define ApplRuleCst 1301
#define RuleCompoCst 1302
#define ScriptLibraryCst 1303					/*REF11296-BRO-060406*/

	    /* Valuation rule */
#define ValRuleCst 1400
#define ValRuleHistCst 1401
#define ValRuleEltCst 1402
#define ValRuleCoeffCst 1403

		/* Risk rule */
#define RiskRuleCst 1404						/* PMSTA-18426 - CHU - 140922 */
#define RiskRuleCompoCst 1405					/* PMSTA-18426 - CHU - 140922 */

        /* Subscription */
#define EventCst 1501
#define MapCst 1502
#define AuditCst 1503
#define EventUpdateCst 1504
#define EventStatusCst 1506
#define EventGroupingIdCst 1507

#define OpenedPositionCst  2554          /* BSA - PMSTA01179 - 061215 */
#define TechnicalCst       2556

#define ArrayCst           5523
#define FusCst             5600
#define FinAnalysisCst     5602
#define OptiFctCst         5603
#define RemoteExecCst      5604
#define TestCst            5605
#define OpListCst          5607
#define EvalEntityCst      5608
#define EvalEntitiesCst    5611            /* PMSTA05247 - LJE - 071206 */
#define InputEntityCst     5614          /* PCC13654 - LJE - 090624 */
#define OutputEntityCst    5615          /* PCC13654 - LJE - 090624 */
#define OutputPermValCst   5616          /* PCC13654 - LJE - 090624 */
#define OutputMsgCst       5617          /* PCC13654 - LJE - 090624 */
#define PurgeEntityCst     5619          /* PMSTA15008-JPP-20120920 */

#define ReportModuleCompoCst    1635    /* PMSTA-25021 - TEB - 161110 */

#define StartFusionByCdCst              2600    /* PMSTA21215 - PCL */
#define ExecFinAnalysisAllDomainCst     2610    /* PMSTA-18593 - LJE - 151216 */
#define ExecSelEportDataByCdCst         2611    /* PMSTA-22169 - DLA - 160119 */

        /* Reserved -1 value for NullEntity */
extern OBJECT_ENUM      NullEntity;
        /* Reserved 0  value for InvalidEntity */
extern OBJECT_ENUM      InvalidEntity;

        /* Infrastructure */
extern OBJECT_ENUM      ApplParam;             /* 100 appl_param                  */
extern OBJECT_ENUM      Curr;                  /* 101 currency                    */
extern OBJECT_ENUM      Sect;                  /* 103 sector                      */
extern OBJECT_ENUM      Rating;                /* 104 rating                      */
extern OBJECT_ENUM      Tp;                    /* 105 type                        */
extern OBJECT_ENUM      Calendar;              /* 106 calendar                    */
extern OBJECT_ENUM      Notepad;               /* 107 notepad                     */
extern OBJECT_ENUM      TabModifStat;          /* 109 tab_modif_stat              */
extern OBJECT_ENUM      CurrChrono;            /* 110 curr_chrono                 */
extern OBJECT_ENUM	    CurrModif;	           /* 111 curr_modif		          */ /* DVP009 960304 DED */
extern OBJECT_ENUM	    ClientConnect;         /* 112 client_connection           */ /* DVP062 960520 RAK */
extern OBJECT_ENUM	    CalendarConv;          /* 113 calendar_conv               */ /* DVP496 970818 DED */
extern OBJECT_ENUM	    CalendarDate;          /* 114 calendar_date               */ /* DVP496 970606 RAK */
extern OBJECT_ENUM      CurrFreq;              /* 115 currency_freq               */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM      Archive;               /* 116 archive                     */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM      QuickSearch;           /* 117 quick_earch                 */ /* REF4497 - SKE - 000331 */
extern OBJECT_ENUM      One;                   /* 119 One                         */ /* MIGR R4.00 STEP6 - LJE - 020815 */
extern OBJECT_ENUM		Empty;				   /* 120 Empty						  */ /*REF7758-BRO-020911*/
extern OBJECT_ENUM      OptiProf;              /* 122 opti_profile                */ /* REF11767 - CHU - 060331 */
extern OBJECT_ENUM      OptiProfCompo;         /* 123 opti_prof_compo             */ /* REF11767 - CHU - 060331 */
extern OBJECT_ENUM      OptiProc;              /* 124 opti_proc                   */ /* REF11767 - LJE - 060418 */
extern OBJECT_ENUM      ApplComment;           /* 125 appl_comment                */    /*  HFI-PMSTA10733-101217   */
extern OBJECT_ENUM      Boottime;              /* 128 boot_time                   */ /* PMSTA-16365 - 140509 */


        /* Multilingual and synonyms */
extern OBJECT_ENUM      Denom;                 /* 200 denomination                */
extern OBJECT_ENUM      ApplMsg;               /* 203 appl_message                */ /* DVP019 960320 RAK */
extern OBJECT_ENUM      ApplMsgTxt;            /* 204 appl_msg_text               */ /* DVP019 960320 RAK */
extern OBJECT_ENUM      WarningMsgEnt;         /* 205 warning_message             */ /*REF7768*/ /* MIGR R4.00 STEP6 - LJE - 020816 */
extern OBJECT_ENUM      RequestCode;           /* 206 request_code                */ /*REF10604-BRO-040922*/

        /* Security */
extern OBJECT_ENUM      DataSecuProf;          /* 301 data_secu_prof              */
extern OBJECT_ENUM      FctSecuProf;           /* 302 func_secu_prof              */
extern OBJECT_ENUM      FctSecuProfCompo;      /* 303 func_secu_prof_compo	      */ /* DVP250 - 961113 - DED */
extern OBJECT_ENUM	    ScreenProf;	           /* 305 screen_profile              */ /* DVP338 - 970204 - RAK */
extern OBJECT_ENUM	    ScreenProfCompo;       /* 306 screen_prof_compo           */ /* DVP338 - 970204 - RAK */
extern OBJECT_ENUM	    Printer;               /* 307 printer                     */ /* DVP350 - 970225 - PEC */
extern OBJECT_ENUM	    PrinterProf;           /* 308 printer_prof                */ /* DVP350 - 970225 - PEC */
extern OBJECT_ENUM	    PrinterProfCompo;      /* 309 printer_prof_compo          */ /* DVP350 - 970225 - PEC */
extern OBJECT_ENUM	    ApplPswdHist;          /* 310 appl_password_history       */ /* 3.50 MODIF - RAK - 991124 */
extern OBJECT_ENUM	    LoginFailed;           /* 312 login_failed                */ /* 3.50 MODIF - RAK - 991124 */
extern OBJECT_ENUM      DataProf;              /* 313 data_profile                */ /* 3.51 REF5562 SKE 010119 */
extern OBJECT_ENUM      DataProfCompo;         /* 314 data_prof_compo             */ /* 3.51 REF5562 SKE 010119 */
extern OBJECT_ENUM      SearchCrit;            /* 315 search_criteria             */    /*  FIH-REF9789-031222  */
extern OBJECT_ENUM      SearchCritCompo;       /* 316 search_criteria_compo       */    /*  FIH-REF9789-031222  */
extern OBJECT_ENUM      SearchProf;            /* 317 search_profile              */    /*  FIH-REF9789-031222  */
extern OBJECT_ENUM      SearchProfCompo;       /* 318 search_profile_compo        */    /*  FIH-REF9789-031222  */
extern OBJECT_ENUM      SelSearchCritCompoArg; /* 319 sel_search_crit_compo_param   */    /* PMSTA-15655 - LJE - 130121 */
extern OBJECT_ENUM      SelFctSecuProfCompoArg;/* 320 sel_fct_secu_prof_compo_param */  /*  HFI-PMSTA-35838-190515  */


	/* Multi channel */
extern OBJECT_ENUM      ApplChannelProf;			/* 331 appl_channel_profile			*/  /* PMSTA-22551 - EFE - 20160323 */
extern OBJECT_ENUM      ApplChannelProfCompo;		/* 332 appl_channel_profile_compo	*/  /* PMSTA-22551 - EFE - 20160323 */
extern OBJECT_ENUM      ApplSessionHisto;		/* 334 appl_session_histo					*/  /* PMSTA-22551 - EFE - 20160323 */


        /* List */
extern OBJECT_ENUM      List;                  /* 400 list                        */
extern OBJECT_ENUM      ListCompo;             /* 401 list_compo                  */
extern OBJECT_ENUM      Classif;               /* 402 classification              */
extern OBJECT_ENUM      ClassifCompo;          /* 403 classif_compo               */
extern OBJECT_ENUM      MktSegt;               /* 404 market_segment              */
extern OBJECT_ENUM      Grid;                  /* 405 grid                        */
extern OBJECT_ENUM	    CheckList;             /* 407 check_list                  */
extern OBJECT_ENUM	    ReturnGridLnk;         /* 408 return_grid_link		      */ /* DVP252 - 961115 - DED */
extern OBJECT_ENUM		ListChrono;			   /* 409 list_chrono				  */ /* REF7292-BRO-020118 */
extern OBJECT_ENUM      MktStruct;             /* 410 market_structure            */ /* REF MODIF BD - RAK - 020501 */
extern OBJECT_ENUM      MktSSubSet;            /* 411 market_structure_subset     */ /* REF MODIF BD - RAK - 020501 */

        /* Investment guidelines */
extern OBJECT_ENUM      Strat;                 /* 500 strategy                    	    */
extern OBJECT_ENUM      StratElt;              /* 501 strategy_element            	    */
extern OBJECT_ENUM      StratLnk;              /* 502 strategy_link               	    */
extern OBJECT_ENUM      StratHist;             /* 503 strategy_history            	    */
extern OBJECT_ENUM	    EStratLnk;	           /* 505 ext. strategy link                */
extern OBJECT_ENUM	    EStratElt;	           /* 506 ext. strategy element           	*/
extern OBJECT_ENUM	    StratEltDetail;	       /* 507 strategy element detail (logical) */
extern OBJECT_ENUM	    FctResult;	           /* 508 function result                   */ /* DVP056 - RAK - 960520 */
extern OBJECT_ENUM	    BenchWeight;           /* 509 strategy weight                   */ /* DVP475 - GRD - 970526 */
extern OBJECT_ENUM      ModelConstr;           /* 510 model_constraint                  */ /* RAK - 010606 */
extern OBJECT_ENUM      ModelConstrElt;        /* 511 model_constr_elt                  */ /* RAK - 010606 */
extern OBJECT_ENUM      DerivedStrat;          /* 512 derived_strategy                  */ /* RAK - 010606 */
extern OBJECT_ENUM      DerivedStratElt;       /* 513 derived_strag_elt                 */ /* RAK - 010606 */
extern OBJECT_ENUM		ConstrTemplate;		   /* 515 constraint template				*/ /* REF7289-BRO-020129*/
extern OBJECT_ENUM		TemplateElt;		   /* 516 template element					*/ /* REF7289-BRO-020129*/
extern OBJECT_ENUM		ConstraintParameter;   /* 517 constraint parameter				*/ /* REF7289-BRO-020129*/
extern OBJECT_ENUM      StratCompo;            /* 518 strategy compo                    */ /* REF MODIF BD - RAK - 020501 */
extern OBJECT_ENUM      ConstraintBreach;      /* 519 constraint_breach                 */ /*REF7768*/ /* MIGR R4.00 STEP6 - LJE - 020816 */
extern OBJECT_ENUM      ComplianceChrono;      /* 520 compliance chrono                 */ /*PMSTA5345 - EFE -080215*/
extern OBJECT_ENUM      CaseManagement;        /* 521 case management                   */ /*PMSTA07121-CHU-081008*/
extern OBJECT_ENUM      CaseClarification;     /* 522 case clarification                */ /*PMSTA07121-CHU-081008*/
extern OBJECT_ENUM      CaseLink;              /* 523 case linked object(s)             */ /*PMSTA07121-CHU-081008*/
extern OBJECT_ENUM      CaseMsgTemplate;       /* 524 case message template             */ /*PMSTA07121-CHU-081014*/
extern OBJECT_ENUM      CaseMsgTemplateDef;    /* 525 case message template definition  */ /*PMSTA07121-DDV-081212*/
extern OBJECT_ENUM	    StratSynth;	           /* 526 strategy synthetic                */ /* PMSTA08737 - LJE - 091109 */
extern OBJECT_ENUM	    VarStratElt;	       /* 527 variable strategy element         */ /* PMSTA08747-CHU-091112 */
extern OBJECT_ENUM	    RiskESElt;             /* 528 risk extended strategy element    */ /* PMSTA-18426 - CHU - 140922 */
extern OBJECT_ENUM	    RiskValueElt;          /* 529 risk value element                */ /* PMSTA-18426 - CHU - 140922 */
extern OBJECT_ENUM	    RiskESEltCompo;        /* 530 risk extended strategy elt compo  */ /* PMSTA-18426-CHU-141014 */
extern OBJECT_ENUM	    RiskValueEltCompo;     /* 531 risk value element compo          */ /* PMSTA-18426-CHU-141014 */
extern OBJECT_ENUM		CaseRule;	           /* 532 case_rule			                */ /* PMSTA-18760-cashwini-140205 */
extern OBJECT_ENUM      LombardCheck;          /* 533 lombard_check                     */ /* PMSTA-21045-cashwini- 150818 */

        /* Third parties */
extern OBJECT_ENUM      Addr;                  /* 602 address                     */
extern OBJECT_ENUM      SectAttr;              /* 603 sector_attrib               */
extern OBJECT_ENUM      RatingAttr;            /* 604 rating_attrib               */
extern OBJECT_ENUM      ThirdFreq;             /* 605 third_freq                  */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM      BusEntity;             /* 606 business_entity             */ /* PMSTA-17089 - DDV - 131106 */
extern OBJECT_ENUM      BusOrga;               /* 607 business_orga               */ /* PMSTA-17089 - DDV - 131106 */
extern OBJECT_ENUM      BusEntityPtfCompo;     /* 608 bus_entity_ptf_compo        */ /* PMSTA-17089 - DDV - 131106 */
extern OBJECT_ENUM      BusEntityInstrCompo;   /* 609 bus_entity_instr_compo      */ /* PMSTA-17089 - DDV - 131106 */
extern OBJECT_ENUM      BusEntityThirdCompo;   /* 610 bus_entity_third_compo      */ /* PMSTA-17089 - DDV - 131106 */
extern OBJECT_ENUM      BusEntityAddr;         /* 612 bus_entity_address          */ /* PMSTA-17089 - DDV - 131203 */

        /* Quotation infrastructure */
extern OBJECT_ENUM      InstrPrice;            /* 700 instr_price                 */
extern OBJECT_ENUM      ExchRate;              /* 701 exch_rate                   */
extern OBJECT_ENUM      ExchFmt;               /* 702 exch_format                 */
extern OBJECT_ENUM      Scena;                 /* 703 scenario                    */
extern OBJECT_ENUM      ScenaCompo;            /* 704 scenario_compo              */
extern OBJECT_ENUM      ScenaElt;              /* 705 scenario_element            */
extern OBJECT_ENUM	    Stat;                  /* 706 statistics                  */
extern OBJECT_ENUM	    Regr;                  /* 707 regression                  */
extern OBJECT_ENUM      RiskRatio;             /* 708 risk_ratio                  */ /* REF8705 - LJE - 030123 */

        /* Portfolios */
extern OBJECT_ENUM      Ptf;                   /* 800 portfolio                   */
extern OBJECT_ENUM      PtfChrono;             /* 801 port_chrono                 */
extern OBJECT_ENUM      PayInstruct;           /* 802 payment_instruction         */
extern OBJECT_ENUM      Mgr;                   /* 803 manager                     */
extern OBJECT_ENUM      PtfPosSet;             /* 804 port_pos_set                */
extern OBJECT_ENUM      BalPosRule;            /* 805 bal_pos_rule                */
extern OBJECT_ENUM      BalPosRuleSet;         /* 806 bal_pos_rule_set            */
extern OBJECT_ENUM      AccPerParam;           /* 807 acc_period_param            */ /* DVP002 960229 RAK */
extern OBJECT_ENUM      AdminMgr;              /* 808 admin_manager               */
extern OBJECT_ENUM      CommMgr;               /* 809 comm_manager                */
extern OBJECT_ENUM      PtfSynth;              /* 810 port_synthetic              */
extern OBJECT_ENUM	    PtfFusionEnt;	       /* 811 port_fusion (logical)	      */
extern OBJECT_ENUM	    PtfReturn;	           /* 812 port_return (logical)	      */
extern OBJECT_ENUM	    AccPer;	               /* 813 acc_period                  */ /* DVP002 960229 RAK */
extern OBJECT_ENUM	    AccPlanElt;	           /* 814 acc_plan_element     	      */ /* DVP002 960229 RAK */
extern OBJECT_ENUM	    FundVal;	           /* 815 fund_valuation		      */ /* DVP037 960426 DED */
extern OBJECT_ENUM	    FundValElt;	           /* 816 fund_valuation_element      */ /* DVP037 960426 DED */
extern OBJECT_ENUM	    AccPlan;	           /* 817 acc_plan                    */ /* DVP339 970206 RAK */
extern OBJECT_ENUM	    FTConv;                /* 818 ft_convention               */ /* REF847 980107 DED */
extern OBJECT_ENUM	    FTRateHist;            /* 819 ft_rate_history             */ /* REF847 980107 DED */
extern OBJECT_ENUM	    FTRate;                /* 820 ft_rate                     */ /* REF847 980107 DED */
extern OBJECT_ENUM      PtfFreq;               /* 821 portfolio_freq              */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM		PerfStorageParam;      /* 823 perf_storage_param          */ /* REF7421 - LJE - 020711 */
extern OBJECT_ENUM		PerfAttrib;            /* 824 perf_attrib                 */ /* REF7421 - LJE - 020711 */
extern OBJECT_ENUM		StandardPerf;          /* 825 standard_perf               */ /* REF7421 - LJE - 020711 */
extern OBJECT_ENUM		ExtRetAnalysis;        /* 826 ext_ret_analysis (logical)  */ /* REF7421 - LJE - 020711 */
extern OBJECT_ENUM      PerfAttribData;        /* 828 perf_attrib_data            */ /* REF8798 - YST - 030310 */
extern OBJECT_ENUM		RetAnaDetailed;        /* 829 ret_analysis_detailed       */ /* REF8798 - YST - 030310 */
extern OBJECT_ENUM      RetAnaGlobal;          /* 830 ret_analysis_global         */ /* REF8798 - YST - 030310 */
extern OBJECT_ENUM      RetAnalysisId;         /* 831 ret_analysis_id             */ /* REF8798 - YST - 030310 */
extern OBJECT_ENUM      StdPerfData;           /* 832 standard_perf_data          */ /* REF8798 - YST - 030310 */
extern OBJECT_ENUM      PSPPositionData;       /* 833 psp_position_data           */ /* REF9125 - LJE - 030813 */
extern OBJECT_ENUM		PerfAttribId;          /* 834 perf_attrib_id              */ /* REF9924 - LJE - 040213 */
extern OBJECT_ENUM		AccProfileHisto;       /* 835 acc_profile_histo           */ /* PMSTA00488 - EFE - 061101 */
extern OBJECT_ENUM		AccProfile;            /* 836 acc_profile                 */ /* PMSTA00488 - EFE - 061101 */
extern OBJECT_ENUM		AccProfileCompo;       /* 837 acc_profile_compo           */ /* PMSTA00488 - EFE - 061101 */
extern OBJECT_ENUM		StandInstruct;         /* 838 standing_instruction        */ /*PMSTA06761-BRO-080704*/
extern OBJECT_ENUM      PerfEffectDef;         /* 839 perf_effect_def             */ /* PMSTA08736 - LJE - 100115 */
extern OBJECT_ENUM      PerfEffectLink;        /* 840 perf_effect_link            */ /* PMSTA08736 - LJE - 100115 */
extern OBJECT_ENUM      PerfCurrencyContrib;   /* 841 perf_currency_contrib       */ /* PMSTA08736 - LJE - 100115 */
extern OBJECT_ENUM      PerfInterBench;        /* 842 perf_inter_bench            */ /* PMSTA08736 - LJE - 100115 */
extern OBJECT_ENUM		PlanRule;			   /* 843 plan_rule					  */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM		PlanRuleHisto;		   /* 844 plan_rule_histo		      */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM		PlanDefinition;		   /* 845 plan_definition		      */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM      PlanObjectiveHisto;    /* 846 plan_objective_histo		  */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM      PlanInvestParamHisto;  /* 847 plan_invest_param_histo	  */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM      PlanInvestDate;		   /* 848 plan_invest_Date			  */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM      FreeDepositHisto;	   /* 849 free_deposit_histo		  */ /* PMSTA-21268 - SHR - 092115 */
extern OBJECT_ENUM      ExtOrderBlockId;	   /* 850 ext_order_alloc_block_id    */ /* PMSTA-46001 - AAKASH - 161221*/



        /* Financial instruments */
extern OBJECT_ENUM      Instr;                 /* 900 instrument                  */

extern OBJECT_ENUM      ExchEvt;               /* 901 exchange_event              */
extern OBJECT_ENUM      IncEvt;                /* 902 income_event                */
extern OBJECT_ENUM      IssueEvt;              /* 903 iss_redm_event              */
extern OBJECT_ENUM      EvtExcl;               /* 905 event_excl                  */
extern OBJECT_ENUM      InstrCompo;            /* 907 instr_compo                 */
extern OBJECT_ENUM      InstrChrono;           /* 908 instr_chrono                */
extern OBJECT_ENUM      FundWgt;               /* 909 fund_weight                 */
extern OBJECT_ENUM      Guarantee;             /* 910 guarantee                   */
extern OBJECT_ENUM      UInter;                /* 911 unitary interest (logical)  */
extern OBJECT_ENUM      Ytm;                   /* 912 yield to maturity (logical) */
extern OBJECT_ENUM      InstrFlow;             /* 913 instrument flow (logical)   */
extern OBJECT_ENUM      CompInstrChrono;       /* 914 compute_instr_chrono (log.) */ /* DVP264 - 961122 - DED */
extern OBJECT_ENUM      AdvA;       	       /* 915 advanced_analytics (log.)   */ /* REF1055 - 981016 - RAK */
extern OBJECT_ENUM      InstrFreq;             /* 916 instrument_freq             */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM      DataDesc;              /* 917 data_desc (logical)         */ /* 3.50 db modif - RAK - 000303 */
extern OBJECT_ENUM      DataDisp;              /* 918 data_disp (logical)         */ /* 3.50 db modif - RAK - 000303 */
extern OBJECT_ENUM      TradingPlace;		   /* 919 trading_place				  */ /*REF7296-BRO-020129*/
extern OBJECT_ENUM		TradingCurrency;	   /* 920 trading_currency			  */ /*REF7296-BRO-020129*/
extern OBJECT_ENUM		CorporateAction;	   /* 921 corporate_action            */ /*REF10603-EFE-041018*/
extern OBJECT_ENUM		CorpActionDetail;      /* 922 corp_action_detail          */ /*REF10603-EFE-041025*/
extern OBJECT_ENUM		InstrDeposit;          /* 923 instr_deposit               */ /*REF11718-BRO-060301*/
extern OBJECT_ENUM      InstrRiskOrig;         /* 924 instr_risk_orig             */ /* PMSTA-18096 - LJE - 140620 */
extern OBJECT_ENUM      CompComplChrono;       /* 925 compute_compl_chrono (log.) */ /* PMSTA-18426 - CHU - 141004 */
extern OBJECT_ENUM      ComplianceChronoFreq;  /* 926 compliance_chrono_freq      */  /* PMSTA-22458 - cashwini - 04062016 */

        /* Positions and transactions */
extern OBJECT_ENUM      Pos;                   /* 1000 position                   */
extern OBJECT_ENUM      BalPos;                /* 1001 balance_pos                */
extern OBJECT_ENUM      BalPosTp;              /* 1002 balance_pos_type           */
extern OBJECT_ENUM      Op;                    /* 1004 operation                  */
extern OBJECT_ENUM	    EventSched;	           /* 1005 event_scheduler            */
extern OBJECT_ENUM	    OpCompo;     	       /* 1006 oper_compo                 */
extern OBJECT_ENUM	    EPos;	       	       /* 1007 extended_position  (logical)   */
extern OBJECT_ENUM	    PVal;	               /* 1008 position_valuation             */
extern OBJECT_ENUM	    OpDomainEnt;	       /* 1009 op_domain (logical)            */
extern OBJECT_ENUM	    BuyOpEnt;	           /* 1010 buy_operation (logical)        */
extern OBJECT_ENUM	    SellOpEnt;	           /* 1011 sell_operation (logical)       */
extern OBJECT_ENUM	    InvestOpEnt;	       /* 1012 invest_operation (logical)     */
extern OBJECT_ENUM	    WithdrOpEnt;	       /* 1013 withdr_operation (logical)     */
extern OBJECT_ENUM	    IncOpEnt;	           /* 1014 income_operation (logical)     */
extern OBJECT_ENUM	    ShareIssOpEnt;	       /* 1015 share_iss_operation (logical)  */
extern OBJECT_ENUM	    ShareRedmOpEnt;	       /* 1016 share_redm_operation (logical) */
extern OBJECT_ENUM	    TransfOpEnt;	       /* 1017 transf_operation (logical)     */
extern OBJECT_ENUM	    BpTransfOpEnt;	       /* 1018 bp_transf_operation (logical)  */
extern OBJECT_ENUM	    AdjustOpEnt;	       /* 1019 adjust_operation (logical)     */
extern OBJECT_ENUM	    FtOpEnt;	           /* 1020 ft_operation (logical)         */
extern OBJECT_ENUM	    DocIndex;	           /* 1021 document_index		          */
extern OBJECT_ENUM	    EOp;	               /* 1022 ext_operation 		          */
extern OBJECT_ENUM	    ShareOpInfo;	       /* 1023 share_operation_info           */
extern OBJECT_ENUM	    LockOpEnt;	           /* 1024 lock_operation (logical)	      */ /* DVP183 - 960826 - DED */
extern OBJECT_ENUM	    PtfTransfOpEnt;        /* 1025 ptf_transf_operation (logical) */ /* DVP355 - 970303 - PEC */
extern OBJECT_ENUM	    BookAdjOpEnt;          /* 1026 book_adj_operation (logical)   */ /* DVP355 - 970303 - PEC */
extern OBJECT_ENUM	    PosValHist;            /* 1027 pos_val_hist                   */ /* DVP390 - 970317 - PEC */
extern OBJECT_ENUM	    BookValue;             /* 1028 book_value                     */ /* DVP430 - 970318 - XDI */
extern OBJECT_ENUM      InitOpEnt;             /* 1029 init_operation                 */ /* REF4306 - RAK - 000201 */
extern OBJECT_ENUM      ExecutionEnt;          /* 1030 Execution                      */ /* DLA - REF7560 - 020516 */
extern OBJECT_ENUM      GlExecFeeEnt;          /* 1031 global_execution_fee           */ /* DLA - REF7560 - 020516 */
extern OBJECT_ENUM      ExtExecutionEnt;       /* 1032 ext_execution                  */ /* DLA - REF7560 - 020516 */
extern OBJECT_ENUM      ExtOrder;              /* 1033 light_order                    */ /* DLA - REF7560 - 020614 */ /* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
extern OBJECT_ENUM      UnMatchedExecution;    /* 1034 unmatchedExecution             */ /* REF9764 - CHU - 031222 */
extern OBJECT_ENUM      ExtTransaction;        /* 1035 ext_unmatchedexecution         */
extern OBJECT_ENUM		UnMatchedGlExecFee;	   /* 1036 unmatched_global_exec_fee      */ /*REF10025-BRO-040401*/
extern OBJECT_ENUM		Communication;		   /* 1037 communication                  */ /*REF11810-BRO-060609*/
extern OBJECT_ENUM		CombinedOpEnt;		   /* 1038 combined_operation             */ /*PMSTA06760-BRO-080701*/
extern OBJECT_ENUM		CompoundOrderRule;	   /* 1039 compound_order_rule			  */ /*PMSTA- 18634 - SHR - 140904 */
extern OBJECT_ENUM		CompoundOrderMasterElt;/* 1040 compound_order_master_elt      */ /*PMSTA- 18634 - SHR - 140904 */
extern OBJECT_ENUM		CompoundOrderSlaveElt; /* 1041 compound_order_slave_elt		  */ /*PMSTA- 18634 - SHR - 140904 */
extern OBJECT_ENUM		ETaxLot;               /* 1044 extended_tax_lot      		  */ /* PMSTA-31342 - SANAND - 180528 */



        /* Meta dictionary */
extern OBJECT_ENUM      DictUser;              /* 1099 dict_user                  */
extern OBJECT_ENUM      DictDataTp;            /* 1100 dict_datatype              */
extern OBJECT_ENUM      DictCriter;            /* 1102 dict_criteria              */
extern OBJECT_ENUM      DictLabel;             /* 1104 dict_label                 */
extern OBJECT_ENUM      DictLang;              /* 1106 dict_language              */
extern OBJECT_ENUM	    DictPanel;             /* 1108 dict_panel                 */ /* DVP200+ - 961101 - DED */
extern OBJECT_ENUM	    DictScreen;            /* 1109 dict_screen                */ /* DVP200+ - 970122 - DED */
extern OBJECT_ENUM      DictSproc;             /* 1110 dict_sproc                 */ /* PMSTA-11999 - RPO - 110504 */
extern OBJECT_ENUM      DictSprocParam;        /* 1111 dict_sproc_param           */ /* PMSTA-11999 - RPO - 110504 */
extern OBJECT_ENUM      DictView;              /* 1112 dict_view                  */ /* PMSTA-11999 - RPO - 110504 */
extern OBJECT_ENUM      DictDatabase;          /* 1113 dict_database              */ /* PMSTA-13109 - LJE - 111123 */
extern OBJECT_ENUM      DictSegment;           /* 1114 dict_segment               */ /* PMSTA-13109 - LJE - 111123 */
extern OBJECT_ENUM      DictFctAttrib;         /* 1115 dict_function_attribute    */ /* PMSTA-13244 - DDV - 120119 */

	    /* Help system */
extern OBJECT_ENUM      EntityComment;         /* 1150 entity_comment             */ /* PMSTA11809-PRS-110428 */
extern OBJECT_ENUM      AttributeComment;      /* 1151 attribute_comment          */ /* PMSTA11809-PRS-110428 */
extern OBJECT_ENUM      PermValComment;        /* 1152 perm_value_comment         */ /* PMSTA11809-PRS-110428 */
extern OBJECT_ENUM      ApplParamComment;      /* 1153 appl_param_comment         */ /* PMSTA11809-PRS-110428 */

	    /* Domain */
extern OBJECT_ENUM	    Domain;                /* 1200 domain                     */
extern OBJECT_ENUM	    FmtProf;               /* 1204 format profile             */
extern OBJECT_ENUM	    FmtProfCompo;          /* 1205 format profile composition */
extern OBJECT_ENUM	    Doc;                   /* 1206 document                   */
extern OBJECT_ENUM	    Folder;                /* 1207 folder                     */
extern OBJECT_ENUM      PrintParam;            /* 1208 print_param (logical)      */ /* DVP068 - 980818 - OCE renamed from report_param */
extern OBJECT_ENUM	    Report;                /* 1209 report                     */
extern OBJECT_ENUM	    ReportProf;            /* 1210 report_profile             */
extern OBJECT_ENUM	    ReportProfCompo;       /* 1211 report_prof_compo          */
extern OBJECT_ENUM	    TabCnt;                /* 1212 table_content              */ /* SQL044 - 960403 - RAK */
extern OBJECT_ENUM	    ReportGen;             /* 1213 report_generation (logical)*/ /* DVP062 - 960520 - RAK */
extern OBJECT_ENUM	    ReportParam;           /* 1214 report_param 		      */ /* DVP068 - 980818 - OCE */
extern OBJECT_ENUM	    ReportModuleCompo;     /* 1635 report_module_compo        */ /* PMSTA-25021 - TEB - 161110 */
extern OBJECT_ENUM      DataSetDef;            /* 1215 data_set_def               */ /*PMSTA01389-BRO-070314*/
extern OBJECT_ENUM      ExportCtxArgEntity;    /* 1216 export_ctx_arg			  */ /* OCS42034-JPP-20121115 */

		/* External Service */
extern OBJECT_ENUM      ExtService;            /* 1221 external_service           */ /*PMSTA-18426-CHU-140922*/
extern OBJECT_ENUM      ExtServiceCompo;       /* 1222 extrenal_service_compo     */ /*PMSTA-18426-CHU-140922*/
extern OBJECT_ENUM      DomainPtfCompo;        /* 1228 domain_portfolio_compo       - PMSTA-21105 - cashwini - 150831*/
extern OBJECT_ENUM      ExtServiceProf;        /* 1229 ext_service_profile          - HFI-PMSTA-22496-160502    */
extern OBJECT_ENUM      ExtServiceProfCompo;   /* 1230 ext_service_prof_compo       - HFI-PMSTA-22496-160502    */

	    /* Script */
extern OBJECT_ENUM	    ScriptDef;             /* 1300 script_definition          */
extern OBJECT_ENUM	    ApplRule;	           /* 1301 appl_rule		          */ /* DVP037 960426 DED */
extern OBJECT_ENUM	    RuleCompo;	           /* 1302 rule_compo		          */ /* DVP037 960426 DED */
extern OBJECT_ENUM		ScriptLibrary;         /* 1303 script_library             */ /*REF11296-BRO-060406*/

	    /* Valuation rule */
extern OBJECT_ENUM	    ValRule;	           /* 1400 val_rule                   */ /* DVP338 - RAK - 970131 */
extern OBJECT_ENUM	    ValRuleHist;	       /* 1401 val_rule_history           */ /* DVP338 - RAK - 970131 */
extern OBJECT_ENUM	    ValRuleElt;	           /* 1402 val_rule_element           */ /* DVP338 - RAK - 970131 */
extern OBJECT_ENUM	    ValRuleCoeff;	       /* 1403 val_rule_coeff             */ /* DVP338 - RAK - 970205 */

extern OBJECT_ENUM	    RiskRule;	           /* 1404 risk_rule                  */ /* PMSTA-18426 - CHU - 140922 */
extern OBJECT_ENUM	    RiskRuleCompo;	       /* 1405 risk_rule_compo            */ /* PMSTA-18426 - CHU - 140922 */

        /* Subscription */
extern OBJECT_ENUM      Event;                 /* 1501 event                      */ /* REF4204 - RAK - 000201 */
extern OBJECT_ENUM      Map;                   /* 1502 map                        */ /* REF4204 - RAK - 000201 */
extern OBJECT_ENUM      Audit;                 /* 1503 audit                      */ /* REF4204 - RAK - 000201 */
extern OBJECT_ENUM      EventUpdate;           /* 1504 event_update               */ /* REF4204 - RAK - 000201 */
extern OBJECT_ENUM      EventStatus;           /* 1506 Event Status               */ /* PMSTA-17112 - EFE - 131210 */
extern OBJECT_ENUM      EventGroupingId;       /* 1507 Grouping Id                */ /* PMSTA-17793 - DDV - 140318 */


        /* Others */
extern OBJECT_ENUM	    Fus;
extern OBJECT_ENUM	    FinAnalysis;
extern OBJECT_ENUM	    OptiFct;
extern OBJECT_ENUM	    RemoteExec;		       /* REF1229 */
extern OBJECT_ENUM	    Test;
extern OBJECT_ENUM	    Technical;       	    /* REF2467 - DDV - 991215 */
extern OBJECT_ENUM	    OpList;                 /* REF3895 - OCE - 991231 */
extern OBJECT_ENUM	    EvalEntityEnt;          /* REF10342 - LJE - 040614 */
extern OBJECT_ENUM      OpenedPosition;         /* BSA - PMSTA - 01179 - 061219 */
extern OBJECT_ENUM	    EvalEntitiesEnt;        /* PMSTA05247 - LJE - 071206 */
extern OBJECT_ENUM      InputEntity;            /* PCC13654 - LJE - 090624 */
extern OBJECT_ENUM      OutputEntity;           /* PCC13654 - LJE - 090624 */
extern OBJECT_ENUM      OutputPermVal;          /* PCC13654 - LJE - 090624 */
extern OBJECT_ENUM      OutputMsg;              /* PCC13654 - LJE - 090624 */
extern OBJECT_ENUM      Array;                  /* PMSTA14453 - DDV - 120705 - Array definition not clean */
extern OBJECT_ENUM      PurgeEntity;            /* PMSTA15008-JPP-20120920 */
extern OBJECT_ENUM      StartFusionByCd;        /* PMSTA21215 - PCL */
extern OBJECT_ENUM      ExecFinAnalysisAllDomain; /* PMSTA-18593 - LJE - 151216 */
extern OBJECT_ENUM      ExecSelExportDataByCd;  /* PMSTA-22169 - DLA - 160119 */

extern OBJECT_ENUM	    LASTOBJECT;


extern OBJECT_ENUM	    LASTENTITYOBJECT;
extern OBJECT_ENUM	    LASTLOGENTITYOBJECT;
extern OBJECT_ENUM	    LASTUDTOBJECT; /* PMSTA-13109 - LJE - 111202 */

extern DBA_DYNST_ENUM	NullDynSt;
extern DBA_DYNST_ENUM	InvalidDynSt;   /* REF9789 - LJE - 031230 */
extern DBA_DYNST_ENUM	A_AccPer;       /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	S_AccPer;       /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	A_AccPerParam;  /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	S_AccPerParam;  /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	A_AccPlan;   	/* DVP339 970206 RAK */
extern DBA_DYNST_ENUM	S_AccPlan;   	/* DVP339 970206 RAK */
extern DBA_DYNST_ENUM	A_AccProfileHisto; /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	S_AccProfileHisto; /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	A_AccProfile;      /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	S_AccProfile;      /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	A_AccProfileCompo; /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	S_AccProfileCompo; /* PMSTA00488 EFE 061101 */
extern DBA_DYNST_ENUM	A_AccPlanElt;   /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	S_AccPlanElt;   /* DVP002 960229 RAK */
extern DBA_DYNST_ENUM	A_Addr;
extern DBA_DYNST_ENUM	S_Addr;
extern DBA_DYNST_ENUM    A_AdminMgr;     /* REF8844 - LJE - 030303 */
extern DBA_DYNST_ENUM	A_ApplMsg;      /* DVP019 960320 RAK */
extern DBA_DYNST_ENUM	S_ApplMsg;      /* DVP019 960320 RAK */
extern DBA_DYNST_ENUM	A_ApplMsgTxt;   /* DVP019 960320 RAK */
extern DBA_DYNST_ENUM	S_ApplMsgTxt;   /* DVP019 960320 RAK */
extern DBA_DYNST_ENUM	A_ApplParam;
extern DBA_DYNST_ENUM	S_ApplParam;
extern DBA_DYNST_ENUM	A_ApplPswdHist;	/* 3.50 DB MODIF - RAK - 991125 */
extern DBA_DYNST_ENUM	A_ApplRule;	    /* DVP037 960426 DED */
extern DBA_DYNST_ENUM	S_ApplRule;	    /* DVP037 960426 DED */
extern DBA_DYNST_ENUM	A_Archive;      /* REF4306 - RAK - 000201 */
extern DBA_DYNST_ENUM    S_Archive;      /* REF4309 - CSA/OCE - 000523 */
extern DBA_DYNST_ENUM	A_Audit;        /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_BalPos;
extern DBA_DYNST_ENUM	S_BalPos;
extern DBA_DYNST_ENUM	A_BalPosRule;
extern DBA_DYNST_ENUM	S_BalPosRule;
extern DBA_DYNST_ENUM	A_BalPosRuleSet;
extern DBA_DYNST_ENUM	S_BalPosRuleSet;
extern DBA_DYNST_ENUM	A_BalPosTp;
extern DBA_DYNST_ENUM	S_BalPosTp;
extern DBA_DYNST_ENUM   A_PAABreakCriteria; /* REF9264 - LJE - 030630 */
extern DBA_DYNST_ENUM   A_ObjectLnk;        /* REF7758 - DDV - 020925 */
extern DBA_DYNST_ENUM	A_BookValue;  /* DVP430 - 970417 - XDI */
extern DBA_DYNST_ENUM	A_BusEntity;            /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	S_BusEntity;            /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	A_BusOrga;              /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	S_BusOrga;              /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	A_BusEntityPtfCompo;    /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	S_BusEntityPtfCompo;    /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	A_BusEntityInstrCompo;  /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	S_BusEntityInstrCompo;  /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	A_BusEntityThirdCompo;  /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	S_BusEntityThirdCompo;  /* PMSTA-17089 - DDV - 131106 */
extern DBA_DYNST_ENUM	A_BusEntityAddr;        /* PMSTA-17089 - DDV - 131203 */
extern DBA_DYNST_ENUM	S_BusEntityAddr;        /* PMSTA-17089 - DDV - 131203 */
extern DBA_DYNST_ENUM	A_Calendar;
extern DBA_DYNST_ENUM	S_Calendar;
extern DBA_DYNST_ENUM	A_CalendarDate;		    /* DVP496 - RAK - 970606 */
extern DBA_DYNST_ENUM	S_CalendarDate;		    /* DVP496 - RAK - 970606 */
extern DBA_DYNST_ENUM	A_CalendarConv;		    /* DVP496 - RAK - 970606 */
extern DBA_DYNST_ENUM	S_CalendarConv;		    /* DVP496 - RAK - 970606 */
extern DBA_DYNST_ENUM	A_CaseManagement;   	/* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	S_CaseManagement;   	/* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	A_CaseClarification;    /* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	S_CaseClarification;    /* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	A_CaseLink;			    /* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	S_CaseLink;			    /* PMSTA07121-CHU-081008 */
extern DBA_DYNST_ENUM	A_CaseMsgTemplate;	    /* PMSTA07121-CHU-081014 */
extern DBA_DYNST_ENUM	S_CaseMsgTemplate;	    /* PMSTA07121-CHU-081014 */
extern DBA_DYNST_ENUM	A_CaseMsgTemplateDef;	/* PMSTA07121-DDV-081212 */
extern DBA_DYNST_ENUM	S_CaseMsgTemplateDef;   /* PMSTA07121-DDV-081212 */
extern DBA_DYNST_ENUM	A_CaseRule;         	/* PMSTA- 18760 -cashwini-140205 */
extern DBA_DYNST_ENUM	S_CaseRule;	            /* PMSTA- 18760 -cashwini-140205 */
extern DBA_DYNST_ENUM	A_LombardCheck;         /* PMSTA-21045-cashwini-150818 */
extern DBA_DYNST_ENUM	S_LombardCheck;         /* PMSTA-21045-cashwini-150818 */
extern DBA_DYNST_ENUM	A_CheckList;
extern DBA_DYNST_ENUM	A_Classif;
extern DBA_DYNST_ENUM	S_Classif;
extern DBA_DYNST_ENUM	A_ClassifCompo;
extern DBA_DYNST_ENUM	S_ClassifCompo;
extern DBA_DYNST_ENUM	E_ClassifCompo;
extern DBA_DYNST_ENUM	A_CheckScript;  /* PMSTA11221-PRS-180111 */
extern DBA_DYNST_ENUM	CheckScript_Arg;
extern DBA_DYNST_ENUM	A_ClientConnect; /* DVP062 960520 RAK */
extern DBA_DYNST_ENUM	S_ClientConnect; /* DVP062 960520 RAK */
extern DBA_DYNST_ENUM	A_Codif;
extern DBA_DYNST_ENUM	S_Codif;
extern DBA_DYNST_ENUM    A_CommMgr;             /* REF8844 - LJE - 030303 */
extern DBA_DYNST_ENUM   A_Communication; /*REF11810-BRO-060609*/
extern DBA_DYNST_ENUM   S_Communication; /*REF11810-BRO-060609*/
extern DBA_DYNST_ENUM  A_ComplianceChrono;    /*PMSTA5345-EFE-080215*/
extern DBA_DYNST_ENUM  S_ComplianceChrono;    /*PMSTA5345-EFE-080215*/
extern DBA_DYNST_ENUM    A_ConstraintBreach;    /* MIGR R4.00 STEP6 - LJE - 020816 */
extern DBA_DYNST_ENUM    S_ConstraintBreach;    /* MIGR R4.00 STEP6 - LJE - 020816 */
extern DBA_DYNST_ENUM	A_ConstraintParameter; /*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM	S_ConstraintParameter; /*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM	A_ConstrTemplate;      /*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM	S_ConstrTemplate;      /*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM  A_CorporateAction;          /*REF10603-EFE-041018*/
extern DBA_DYNST_ENUM  S_CorporateAction;          /*REF10603-EFE-041018*/
extern DBA_DYNST_ENUM  A_CorpActionDetail;       /*REF10603-EFE-041018*/
extern DBA_DYNST_ENUM  S_CorpActionDetail;       /*REF10603-EFE-041018*/
extern DBA_DYNST_ENUM	A_Curr;
extern DBA_DYNST_ENUM	S_Curr;
extern DBA_DYNST_ENUM	A_CurrChrono;
extern DBA_DYNST_ENUM	S_CurrChrono;
extern DBA_DYNST_ENUM	A_CurrFreq;     /* REF4306 - RAK -000201 */
extern DBA_DYNST_ENUM    A_DataDesc;     /* REF1055 - RAK - 000303 */
extern DBA_DYNST_ENUM    A_DataDisp;     /* REF1055 - RAK - 000303 */
extern DBA_DYNST_ENUM    A_DataProf;     /* REF5562 SKE 010119 */
extern DBA_DYNST_ENUM    S_DataProf;     /* REF5562 SKE 010119 */
extern DBA_DYNST_ENUM    A_DataProfCompo;/* REF5562 SKE 010119 */
extern DBA_DYNST_ENUM    S_DataProfCompo;/* REF5562 SKE 010119 */
extern DBA_DYNST_ENUM	A_DataSecuProf;
extern DBA_DYNST_ENUM	S_DataSecuProf;
extern DBA_DYNST_ENUM   A_DataSetDef;    /* PMSTA01389 - DDV - 070307 */
extern DBA_DYNST_ENUM   A_ExtService;    /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM   S_ExtService;    /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM   A_ExtServiceCompo;    /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM   S_ExtServiceCompo;    /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM   A_DomainPtfCompo;    /* PMSTA-21105 - cashwini - 150831 */
extern DBA_DYNST_ENUM   S_DomainPtfCompo;    /* PMSTA-21105 - cashwini - 150831*/
extern DBA_DYNST_ENUM   A_ExtServiceProf;    /*  HFI-PMSTA-22496-160502  */
extern DBA_DYNST_ENUM   S_ExtServiceProf;    /*  HFI-PMSTA-22496-160502  */
extern DBA_DYNST_ENUM   A_ExtServiceProfCompo;  /*  HFI-PMSTA-22496-160502  */
extern DBA_DYNST_ENUM   S_ExtServiceProfCompo;  /*  HFI-PMSTA-22496-160502  */
extern DBA_DYNST_ENUM    A_OptiProf;     /* REF11767 - CHU - 060331 */
extern DBA_DYNST_ENUM    S_OptiProf;     /* REF11767 - CHU - 060331 */
extern DBA_DYNST_ENUM    A_OptiProfCompo;/* REF11767 - CHU - 060331 */
extern DBA_DYNST_ENUM    S_OptiProfCompo;/* REF11767 - CHU - 060331 */
extern DBA_DYNST_ENUM    A_OptiProc;     /* REF11767 - LJE - 060418 */
extern DBA_DYNST_ENUM    S_OptiProc;     /* REF11767 - LJE - 060418 */
extern DBA_DYNST_ENUM  A_ApplComment;          /*PMSTA10733-TEB-101130*/
extern DBA_DYNST_ENUM  S_ApplComment;          /*PMSTA10733-TEB-101130*/
extern DBA_DYNST_ENUM	A_Denom;
extern DBA_DYNST_ENUM	S_Denom;
extern DBA_DYNST_ENUM    A_DerivedStrat;     /* RAK - 010606 */
extern DBA_DYNST_ENUM    S_DerivedStrat;     /* RAK - 010606 */
extern DBA_DYNST_ENUM    A_DerivedStratElt;  /* RAK - o10606 */
extern DBA_DYNST_ENUM	A_DictUser;
extern DBA_DYNST_ENUM	S_DictUser;
extern DBA_DYNST_ENUM	A_DictCriter;
extern DBA_DYNST_ENUM	S_DictCriter;
extern DBA_DYNST_ENUM	A_DictDataTp;
extern DBA_DYNST_ENUM	S_DictDataTp;
extern DBA_DYNST_ENUM	A_DictEntity;
extern DBA_DYNST_ENUM	S_DictEntity;
extern DBA_DYNST_ENUM	A_DictFct;
extern DBA_DYNST_ENUM   E_DictFct;    /*SHR - 150721 - PMSTA-17794*/
extern DBA_DYNST_ENUM	S_DictFct;
extern DBA_DYNST_ENUM	A_DictLabel;
extern DBA_DYNST_ENUM	S_DictLabel;
extern DBA_DYNST_ENUM	A_DictLang;
extern DBA_DYNST_ENUM	S_DictLang;
extern DBA_DYNST_ENUM	A_DictPanel;	/* ROI - 960910 - DVP200 */
extern DBA_DYNST_ENUM	S_DictPanel;	/* ROI - 960910 - DVP200 */
extern DBA_DYNST_ENUM	A_DictScreen;	/* DVP200+ - 970123 - DED */
extern DBA_DYNST_ENUM	S_DictScreen;   /* DVP200+ - 970123 - DED */
extern DBA_DYNST_ENUM	O_DictPermVal;    /* PMSTA-15655 - LJE - 130124 */
extern DBA_DYNST_ENUM	A_DictView;       /* PMSTA-11999 - RPO - 110504 */
extern DBA_DYNST_ENUM	S_DictView;       /* PMSTA-11999 - RPO - 110504 */
extern DBA_DYNST_ENUM	A_DictDatabase;   /* PMSTA-13109 - LJE - 111123 */
extern DBA_DYNST_ENUM	S_DictDatabase;   /* PMSTA-13109 - LJE - 111123 */
extern DBA_DYNST_ENUM	A_DictSegment;    /* PMSTA-13109 - LJE - 111123 */
extern DBA_DYNST_ENUM	S_DictSegment;    /* PMSTA-13109 - LJE - 111123 */
extern DBA_DYNST_ENUM	A_DictFctAttrib;  /* PMSTA-13244 - DDV - 120119 */
extern DBA_DYNST_ENUM	S_DictFctAttrib;  /* PMSTA-13244 - DDV - 120119 */
extern DBA_DYNST_ENUM	A_Doc;
extern DBA_DYNST_ENUM	S_Doc;
extern DBA_DYNST_ENUM	A_DocIndex;
extern DBA_DYNST_ENUM	S_DocIndex;
extern DBA_DYNST_ENUM	A_Domain;
extern DBA_DYNST_ENUM	S_Domain;
extern DBA_DYNST_ENUM	A_Empty;		/*REF7758-BRO-020911*/
extern DBA_DYNST_ENUM	A_EvtExcl;
extern DBA_DYNST_ENUM	S_EvtExcl;
extern DBA_DYNST_ENUM	A_ExchFmt;
extern DBA_DYNST_ENUM	S_ExchFmt;
extern DBA_DYNST_ENUM	A_ExchRate;
extern DBA_DYNST_ENUM	S_ExchRate;
extern DBA_DYNST_ENUM	A_ExtRetAnalysis; /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM	S_ExtRetAnalysis; /*REF7758-BRO-021018*/
extern DBA_DYNST_ENUM	Freq_ExchRate;
extern DBA_DYNST_ENUM	A_FctResult;    /* DV056 - RAK - 960520 */
extern DBA_DYNST_ENUM	S_FctResult;    /* DV056 - RAK - 960520 */
extern DBA_DYNST_ENUM	A_FctSecuProfCompo;	/* DVP250 - 961113 - DED */
extern DBA_DYNST_ENUM	S_FctSecuProfCompo;	/* DVP250 - 961113 - DED */
extern DBA_DYNST_ENUM	A_FctSecuProf;
extern DBA_DYNST_ENUM	S_FctSecuProf;
extern DBA_DYNST_ENUM	E_Fmt;
extern DBA_DYNST_ENUM	Sum_FmtElt;
extern DBA_DYNST_ENUM   A_InputEntity;  /* PCC13654 - LJE - 090624 */
extern DBA_DYNST_ENUM   A_OutputEntity; /* PCC13654 - LJE - 090624 */
extern DBA_DYNST_ENUM   A_OutputPermVal; /* PCC13654 - LJE - 090624 */
extern DBA_DYNST_ENUM   A_OutputMsg; /* PCC13654 - LJE - 090624 */
extern DBA_DYNST_ENUM	A_FmtProf;
extern DBA_DYNST_ENUM	S_FmtProf;
extern DBA_DYNST_ENUM	A_FmtProfCompo;
extern DBA_DYNST_ENUM	S_FmtProfCompo;
extern DBA_DYNST_ENUM	A_Folder;
extern DBA_DYNST_ENUM	S_Folder;
extern DBA_DYNST_ENUM	A_FundVal;	/* DVP037 960426 DED */
extern DBA_DYNST_ENUM	S_FundVal;	/* DVP037 960426 DED */
extern DBA_DYNST_ENUM	A_FundValElt;	/* DVP037 960426 DED */
extern DBA_DYNST_ENUM	S_FundValElt;	/* DVP037 960426 DED */
extern DBA_DYNST_ENUM	A_FundWgt;
extern DBA_DYNST_ENUM	S_FundWgt;
extern DBA_DYNST_ENUM	A_Event;        /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	S_Event;        /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_EventSched;
extern DBA_DYNST_ENUM	S_EventSched;
extern DBA_DYNST_ENUM	A_EventUpdate;  /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_EventStatus;  /* PMSTA-17112 - EFE - 131210 */
extern DBA_DYNST_ENUM	S_EventStatus;  /* PMSTA-17266 - DDV - 140128 */
extern DBA_DYNST_ENUM	A_Geo;
extern DBA_DYNST_ENUM	S_Geo;
extern DBA_DYNST_ENUM	A_Grid;
extern DBA_DYNST_ENUM	S_Grid;
extern DBA_DYNST_ENUM	A_Guarantee;
extern DBA_DYNST_ENUM	S_Guarantee;
extern DBA_DYNST_ENUM	A_IncEvt;
extern DBA_DYNST_ENUM	S_IncEvt;
extern DBA_DYNST_ENUM	A_Instr;
extern DBA_DYNST_ENUM	S_Instr;
extern DBA_DYNST_ENUM	A_InstrChrono;
extern DBA_DYNST_ENUM	S_InstrChrono;
extern DBA_DYNST_ENUM	Dim_InstrChrono;	/* DVP051 RAK 960509 */
extern DBA_DYNST_ENUM	Freq_InstrChrono;	/* DVP005 RAK 960314 */
extern DBA_DYNST_ENUM	A_InstrCompo;
extern DBA_DYNST_ENUM	S_InstrCompo;
extern DBA_DYNST_ENUM   A_InstrDeposit;     /*REF11718-BRO-060301*/
extern DBA_DYNST_ENUM   S_InstrDeposit;     /*REF11718-BRO-060301*/
extern DBA_DYNST_ENUM	A_InstrFreq;        /* REF4306 - RAK - 000201 */
extern DBA_DYNST_ENUM   A_InstrRiskOrig;    /* PMSTA-18096 - LJE - 140620 */
extern DBA_DYNST_ENUM	A_InstrPrice;
extern DBA_DYNST_ENUM	S_InstrPrice;
extern DBA_DYNST_ENUM	InstrPriceIdx;      /* REF2834 - DDV - 980923 */
extern DBA_DYNST_ENUM	Freq_InstrPrice;
extern DBA_DYNST_ENUM	A_IssueEvt;
extern DBA_DYNST_ENUM	S_IssueEvt;
extern DBA_DYNST_ENUM	A_List;
extern DBA_DYNST_ENUM	S_List;
extern DBA_DYNST_ENUM	A_ListChrono;		 /*REF7292-BRO-020121*/
extern DBA_DYNST_ENUM	S_ListChrono;		 /*REF7292-BRO-020121*/
extern DBA_DYNST_ENUM    A_Log;               /* MRA - 020709 - REF4333.2 */ /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM	Freq_ListChrono;     /* REF7292 - LJE - 020213 */
extern DBA_DYNST_ENUM	A_ListCompo;
extern DBA_DYNST_ENUM	S_ListCompo;
extern DBA_DYNST_ENUM	A_LoginFailed;		/* 3.50 DB MODIF - RAK - 991125 */
extern DBA_DYNST_ENUM	A_Map;              /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	S_Map;              /* REF4204 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_Mgr;
extern DBA_DYNST_ENUM	S_Mgr;
extern DBA_DYNST_ENUM	A_MktSegt;
extern DBA_DYNST_ENUM	S_MktSegt;
extern DBA_DYNST_ENUM    A_MktStruct;        /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM    S_MktStruct;        /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM    A_MktSSubSet;       /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM    S_MktSSubSet;       /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM    A_ModelConstrElt;   /* RAK - 010606 */
extern DBA_DYNST_ENUM    S_ModelConstrElt;   /* RAK - 010606 */
extern DBA_DYNST_ENUM	A_Notepad;
extern DBA_DYNST_ENUM	S_Notepad;
extern DBA_DYNST_ENUM    A_One;              /* MIGR R4.00 STEP6 - LJE - 020815 */
extern DBA_DYNST_ENUM    A_Boottime;         /* PMSTA-16365 - 140509 */
extern DBA_DYNST_ENUM	A_Op;
extern DBA_DYNST_ENUM	S_Op;
extern DBA_DYNST_ENUM	A_OpCompo;
extern DBA_DYNST_ENUM	S_OpCompo;
extern DBA_DYNST_ENUM	A_PayInstruct;
extern DBA_DYNST_ENUM	S_PayInstruct;
extern DBA_DYNST_ENUM	A_PerfAttribId;      /* REF9924 - LJE - 040213 */
extern DBA_DYNST_ENUM	S_PerfAttribId;
extern DBA_DYNST_ENUM	A_PerfAttrib;        /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM	S_PerfAttrib;        /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM    A_PerfAttribData;    /* REF8798 - YST - 030310 */
extern DBA_DYNST_ENUM	A_PerfStorageParam;  /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM	S_PerfStorageParam;  /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM   A_PSPPositionData;   /* REF9125 - LJE - 030813 */
extern DBA_DYNST_ENUM   S_PSPPositionData;   /* REF9125 - LJE - 030813 */
extern DBA_DYNST_ENUM   A_PerfEffectDef;     /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   S_PerfEffectDef;     /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   A_PerfEffectLink;	 /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   S_PerfEffectLink;    /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   A_PerfCurrencyContrib;	 /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   A_PerfInterBench;	 /* PMSTA08736 - LJE - 100115 */
extern DBA_DYNST_ENUM   A_PlanRule;			 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanRule;			 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_PlanRuleHisto;	 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanRuleHisto;	 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_PlanDefinition;	 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanDefinition;	 /* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_PlanObjectiveHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanObjectiveHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_PlanInvestParamHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanInvestParamHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_PlanInvestDate;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_PlanInvestDate;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   A_FreeDepositHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM   S_FreeDepositHisto;/* PMSTA-21268 - SHR - 092115 */
extern DBA_DYNST_ENUM	A_Ptf;
extern DBA_DYNST_ENUM	S_Ptf;
extern DBA_DYNST_ENUM	A_PtfChrono;
extern DBA_DYNST_ENUM	S_PtfChrono;
extern DBA_DYNST_ENUM	Freq_PtfChrono;		/* DVP005 RAK 960314 */
extern DBA_DYNST_ENUM	A_PtfFreq;          /* REF4306 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_PtfPosSet;
extern DBA_DYNST_ENUM	S_PtfPosSet;
extern DBA_DYNST_ENUM	A_PtfReturn;
extern DBA_DYNST_ENUM	A_PtfSynth;
extern DBA_DYNST_ENUM	S_PtfSynth;
extern DBA_DYNST_ENUM	Zero_PtfSynth;		/* REF1511 - RAK - 980406 */
extern DBA_DYNST_ENUM	A_Pos;
extern DBA_DYNST_ENUM	S_Pos;
extern DBA_DYNST_ENUM	A_Printer;		/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	S_Printer;		/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	A_PrinterProf;		/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	S_PrinterProf;		/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	A_PrinterProfCompo;	/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	S_PrinterProfCompo;	/* DVP350 970225 PEC */
extern DBA_DYNST_ENUM	A_PrintParam;		/* DVP068 980818 OCE  renamed from A_ReportParam */
extern DBA_DYNST_ENUM    A_QuickSearch;       /* REF4497 - SKE - 000331 */
extern DBA_DYNST_ENUM	A_Rating;
extern DBA_DYNST_ENUM	S_Rating;
extern DBA_DYNST_ENUM	A_RatingAttr;
extern DBA_DYNST_ENUM	S_RatingAttr;
extern DBA_DYNST_ENUM	A_Regr;			/* DVP005 960313 RAK */
extern DBA_DYNST_ENUM	A_Report;
extern DBA_DYNST_ENUM	S_Report;
extern DBA_DYNST_ENUM	A_ReportGen;		/* DVP062 960520 RAK */
extern DBA_DYNST_ENUM	A_ReportParam;		/* DVP068 980818 OCE */
extern DBA_DYNST_ENUM	S_ReportParam;		/* DVP068 980818 OCE */
extern DBA_DYNST_ENUM	A_ReportProf;
extern DBA_DYNST_ENUM	S_ReportProf;
extern DBA_DYNST_ENUM	A_ReportProfCompo;
extern DBA_DYNST_ENUM	S_ReportProfCompo;
extern DBA_DYNST_ENUM	A_ReportModuleCompo;	/* PMSTA-25021 - TEB - 161110 */
extern DBA_DYNST_ENUM	S_ReportModuleCompo;	/* PMSTA-25021 - TEB - 161110 */
extern DBA_DYNST_ENUM   A_RequestCode;       /*REF10604-BRO-040922*/
extern DBA_DYNST_ENUM   S_RequestCode;       /*REF10604-BRO-040922*/
extern DBA_DYNST_ENUM    A_RetAnaDetailed;   /* REF8798 - YST - 030310 */
extern DBA_DYNST_ENUM    A_RetAnaGlobal;     /* REF8798 - YST - 030310 */
extern DBA_DYNST_ENUM    A_RetAnalysisId;    /* REF8798 - YST - 030310 */
extern DBA_DYNST_ENUM    S_RetAnalysisId;    /* PMSTA-17060 - LJE - 131010 */
extern DBA_DYNST_ENUM    S_ExtOrderBlockId;  /* PMSTA-46001 - AAKASH - 161221 */
extern DBA_DYNST_ENUM	A_ReturnGridLnk;	/* DVP252 - 961115 - DED */
extern DBA_DYNST_ENUM	S_ReturnGridLnk;	/* DVP252 - 961115 - DED */
extern DBA_DYNST_ENUM    A_RiskRatio;        /* REF8705 - LJE - 030123 */
extern DBA_DYNST_ENUM    A_RuleCompo;		/* DVP037 - 960426 - DED */
extern DBA_DYNST_ENUM	S_RuleCompo;		/* DVP037 - 960426 - DED */
extern DBA_DYNST_ENUM	A_RiskRule;	        /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM	S_RiskRule;	        /* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM	A_RiskRuleCompo;	/* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM	S_RiskRuleCompo;	/* PMSTA-18426 - CHU - 140922 */
extern DBA_DYNST_ENUM	A_Scena;
extern DBA_DYNST_ENUM	S_Scena;
extern DBA_DYNST_ENUM	A_ScenaCompo;
extern DBA_DYNST_ENUM	S_ScenaCompo;
extern DBA_DYNST_ENUM	A_ScenaElt;
extern DBA_DYNST_ENUM	S_ScenaElt;
extern DBA_DYNST_ENUM	A_ScreenProf;		/* DVP338 - 970204 - RAK */
extern DBA_DYNST_ENUM	S_ScreenProf;		/* DVP338 - 970204 - RAK */
extern DBA_DYNST_ENUM	A_ScreenProfCompo;	/* DVP338 - 970204 - RAK */
extern DBA_DYNST_ENUM	S_ScreenProfCompo;	/* DVP338 - 970204 - RAK */
extern DBA_DYNST_ENUM	A_ScriptDef;
extern DBA_DYNST_ENUM	S_ScriptDef;
extern DBA_DYNST_ENUM	A_ScriptLibrary;	/*REF11296-BRO-060406*/
extern DBA_DYNST_ENUM	S_ScriptLibrary;	/*REF11296-BRO-060406*/
extern DBA_DYNST_ENUM	A_SearchCrit;       /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	S_SearchCrit;       /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	A_SearchCritCompo;  /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	S_SearchCritCompo;  /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	O_SearchCritCompo;  /* PMSTA-15655 - LJE - 130124 */
extern DBA_DYNST_ENUM	A_SearchProf;       /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	S_SearchProf;       /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	A_SearchProfCompo;  /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	S_SearchProfCompo;  /*  FIH-REF9789-031222  */
extern DBA_DYNST_ENUM	A_SelSearchCritCompoArg;  /* PMSTA-15655 - LJE - 130121 */
extern DBA_DYNST_ENUM	A_SelFctSecuProfCompoArg;   /*  HFI-PMSTA-35838-190515  */
extern DBA_DYNST_ENUM	A_Sect;
extern DBA_DYNST_ENUM	S_Sect;
extern DBA_DYNST_ENUM	A_SectAttr;
extern DBA_DYNST_ENUM	S_SectAttr;
extern DBA_DYNST_ENUM	A_ServConnect; /* DVP062 960520 RAK */
extern DBA_DYNST_ENUM	S_ServConnect; /* DVP062 960520 RAK */
extern DBA_DYNST_ENUM   A_ServRunning; /* PMSTA-23385 - LJE - 160707 */
extern DBA_DYNST_ENUM   S_ServRunning; /* PMSTA-23385 - LJE - 160707 */
extern DBA_DYNST_ENUM	A_ShareOpInfo; /* DVP151 */
extern DBA_DYNST_ENUM	A_StandardPerf;  /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM	S_StandardPerf;  /* REF7421 - LJE - 020711 */
extern DBA_DYNST_ENUM   A_StdPerfData;      /* REF8798 - YST - 030310 */
extern DBA_DYNST_ENUM   A_StandInstruct; /*PMSTA06761-BRO-080704*/
extern DBA_DYNST_ENUM   S_StandInstruct; /*PMSTA06761-BRO-080704*/
extern DBA_DYNST_ENUM	A_Stat;        /* DVP005 960313 RAK */
extern DBA_DYNST_ENUM	A_Strat;
extern DBA_DYNST_ENUM	S_Strat;
extern DBA_DYNST_ENUM    A_StratCompo;   /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM	S_StratCompo;   /* MODIF BD - RAK - 020105 */
extern DBA_DYNST_ENUM	A_StratElt;
extern DBA_DYNST_ENUM	S_StratElt;
extern DBA_DYNST_ENUM	A_StratLnk;
extern DBA_DYNST_ENUM	S_StratLnk;
extern DBA_DYNST_ENUM	A_StratHist;
extern DBA_DYNST_ENUM	S_StratHist;
extern DBA_DYNST_ENUM	A_StratEltDetail;
extern DBA_DYNST_ENUM	A_StratSynth;       /* PMSTA08737 - LJE - 091109 */
extern DBA_DYNST_ENUM	A_Synon;
extern DBA_DYNST_ENUM	S_Synon;
extern DBA_DYNST_ENUM	A_TabCnt;    /* SQL044 - 960403 - RAK */
extern DBA_DYNST_ENUM	S_TabCnt;    /* SQL044 - 960403 - RAK */
extern DBA_DYNST_ENUM	A_TabModifStat;
extern DBA_DYNST_ENUM	S_TabModifStat;
extern DBA_DYNST_ENUM	A_TemplateElt;		/*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM	S_TemplateElt;		/*REF7289-BRO-020205*/
extern DBA_DYNST_ENUM	Freq_ThirdChrono;	/* DVP005 BEGIN RAK 960314 */
extern DBA_DYNST_ENUM	A_ThirdFreq;        /* REF4306 - RAK - 000201 */
extern DBA_DYNST_ENUM	A_Tp;
extern DBA_DYNST_ENUM	S_Tp;
extern DBA_DYNST_ENUM	A_TradingCurrency;	/*REF7296-BRO-020205*/
extern DBA_DYNST_ENUM	S_TradingCurrency;  /*REF7296-BRO-020205*/
extern DBA_DYNST_ENUM	A_TradingPlace;     /*REF7296-BRO-020205*/
extern DBA_DYNST_ENUM	S_TradingPlace;     /*REF7296-BRO-020205*/
extern DBA_DYNST_ENUM	A_ValRule;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM	S_ValRule;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM	A_ValRuleCoeff;		/* DVP338 - RAK - 970205 */
extern DBA_DYNST_ENUM	S_ValRuleCoeff;		/* DVP338 - RAK - 970205 */
extern DBA_DYNST_ENUM	A_ValRuleElt;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM	S_ValRuleElt;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM	A_ValRuleHist;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM	S_ValRuleHist;		/* DVP338 - RAK - 970131 */
extern DBA_DYNST_ENUM    A_WarningMsg;       /* MIGR R4.00 STEP6 - LJE - 020816 */
extern DBA_DYNST_ENUM	ExtPos;
extern DBA_DYNST_ENUM	PosVal;
extern DBA_DYNST_ENUM	UnitInter;
extern DBA_DYNST_ENUM	A_Ytm;
extern DBA_DYNST_ENUM	A_AdvA;			/* REF1055 RAK 981012 */
extern DBA_DYNST_ENUM	AdvA_Arg;		/* REF1055 RAK 981012 */
extern DBA_DYNST_ENUM	RiskAmt;
extern DBA_DYNST_ENUM	Flow;
extern DBA_DYNST_ENUM	OpDomain;
extern DBA_DYNST_ENUM	BuyOp;
extern DBA_DYNST_ENUM	SellOp;
extern DBA_DYNST_ENUM	InvestOp;
extern DBA_DYNST_ENUM	WithdrOp;
extern DBA_DYNST_ENUM	IncOp;
extern DBA_DYNST_ENUM	ShareIssOp;
extern DBA_DYNST_ENUM	ShareRedmOp;
extern DBA_DYNST_ENUM	TransfOp;
extern DBA_DYNST_ENUM	BpTransfOp;
extern DBA_DYNST_ENUM	AdjustOp;
extern DBA_DYNST_ENUM	FtOp;
extern DBA_DYNST_ENUM	LockOp;		/* DVP183 - 960826 - DED */
extern DBA_DYNST_ENUM	PtfTransfOp;    /* DVP355 - 970303 - PEC */
extern DBA_DYNST_ENUM	BookAdjOp;      /* DVP355 - 970303 - PEC */
extern DBA_DYNST_ENUM	InitOp;         /* REF4306 - RAK - 000201 */
extern DBA_DYNST_ENUM   CombinedOp;     /*PMSTA06760-BRO-080701*/
extern DBA_DYNST_ENUM	A_PosValHist;   /* DVP390 - 970317 - PEC */
extern DBA_DYNST_ENUM	S_PosValHist;   /* DVP390 - 970317 - PEC */
extern DBA_DYNST_ENUM	Adm_Arg;
extern DBA_DYNST_ENUM	Array_X;        /* DVP005 RAK 960322 */
extern DBA_DYNST_ENUM	Array_XY;       /* DVP005 RAK 960322 */
extern DBA_DYNST_ENUM	Chrono_Arg;
extern DBA_DYNST_ENUM	Chrono_FreqArg; /* DVP005 RAK 960314 */
extern DBA_DYNST_ENUM   ExchRate_Arg;
extern DBA_DYNST_ENUM	ExchRate_FreqArg;
extern DBA_DYNST_ENUM	Sel_Arg;        /* DVP344 XDI 970219 */
extern DBA_DYNST_ENUM	InstrPrice_Arg;
extern DBA_DYNST_ENUM	InstrPrice_FreqArg;
extern DBA_DYNST_ENUM	Evt_Arg;
extern DBA_DYNST_ENUM	Fus_Arg;
extern DBA_DYNST_ENUM	Bu_Arg;         /* PMSTA-51720 - 160123 - Sathees */
extern DBA_DYNST_ENUM   UearEntity;     /* WEALTH-5698 - 290224 - Sathees */
extern DBA_DYNST_ENUM   Fus_Sync;       /* PMSTA-24510 - 220816 - PMO */
extern DBA_DYNST_ENUM   GetVersion_Arg; /* PMSTA-24510 - 220816 - PMO */
extern DBA_DYNST_ENUM   GetSrvEnv_Arg;  /* DLA - PMSTA-24751 - 161227 */
extern DBA_DYNST_ENUM	Chk_Arg;
extern DBA_DYNST_ENUM	Del_Arg;
extern DBA_DYNST_ENUM	Get_Arg;
extern DBA_DYNST_ENUM	Get_Arg2;	/* REF2338 - GRD - 981015 */
extern DBA_DYNST_ENUM	Flow_Arg;
extern DBA_DYNST_ENUM	ApplMsg_Arg;
extern DBA_DYNST_ENUM	FundVal_Arg;   /* DVP034 XDI 960509 */
extern DBA_DYNST_ENUM	Operator;
extern DBA_DYNST_ENUM	Srv_Connect;
extern DBA_DYNST_ENUM	A_Test;
extern DBA_DYNST_ENUM	Out_Date;
extern DBA_DYNST_ENUM	MeanCapReturn_Arg;
extern DBA_DYNST_ENUM   RiskRatio_Arg;   /* REF8705 - LJE - 030128 */
extern DBA_DYNST_ENUM   Io_Id;
extern DBA_DYNST_ENUM   Io_Ext;              /* PMSTA-34344 - LJE - 200925 */
extern DBA_DYNST_ENUM   Io_Flg;             /* PMSTA-47605 - JBC - 220113 */
extern DBA_DYNST_ENUM   Io_Info;
extern DBA_DYNST_ENUM	FmtEltDef;
extern DBA_DYNST_ENUM	DataDef;
extern DBA_DYNST_ENUM	PtfFusion;
extern DBA_DYNST_ENUM	ListMgmArg;
extern DBA_DYNST_ENUM	ExtStratLnk;
extern DBA_DYNST_ENUM	ExtStratElt;
extern DBA_DYNST_ENUM	ExtStratElt_Elt; 	/* DVP023 RAK 960422 */
extern DBA_DYNST_ENUM	SumRes;          	/* DVP023 RAK 960506 */
extern DBA_DYNST_ENUM	SumResElt;       	/* DVP023 RAK 960506 */
extern DBA_DYNST_ENUM	ExtOp;
extern DBA_DYNST_ENUM	Imp_OpV2;
extern DBA_DYNST_ENUM	Curr_Modif;
extern DBA_DYNST_ENUM	Msg;
extern DBA_DYNST_ENUM	Select_Res_Tab;
extern DBA_DYNST_ENUM	ExportCtx_Arg;          /* DVP437  - 970422 - PEC */
extern DBA_DYNST_ENUM	Export_FmtElt;          /* DVP437  - 970423 - PEC */
extern DBA_DYNST_ENUM	A_CellFmt;
extern DBA_DYNST_ENUM	A_CompInstrChrono;	/* DVP264  - 961122 - DED */
extern DBA_DYNST_ENUM	A_CompComplChrono;	/* PMSTA-18426 - CHU - 141004 */
extern DBA_DYNST_ENUM   A_ComplianceChronoFreq; /*PMSTA-22458 - cashwini - 04062016*/
extern DBA_DYNST_ENUM	Search_BestOper;	/* DVP282  - 961127 - GRD */
extern DBA_DYNST_ENUM	Current_Load;		/* DVP196  - 970131 - GRD */
extern DBA_DYNST_ENUM	PtfQtyAlloc;		/* DVP460  - 970516 - RAK */
extern DBA_DYNST_ENUM	MktSgtInstr;		/* DVP460  - 970605 - RAK */
extern DBA_DYNST_ENUM	Bench_Weight;		/* DVP475  - 970521 - GRD */
extern DBA_DYNST_ENUM	A_FTConv;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	S_FTConv;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	A_FTRateHist;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	S_FTRateHist;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	A_FTRate;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	S_FTRate;		/* REF847  - 980107 - DED */
extern DBA_DYNST_ENUM	Arg_AccountingRuleCompo; /* PMSTA-28335 - MSR - 171006 */
extern DBA_DYNST_ENUM   ArgAccRuleCompo;    /* PMSTA-29130 - 200818 - vkumar */
extern DBA_DYNST_ENUM	Arg_ApplUserPrefName; /* PMSTA-32230 - MSR - 130818 */
extern DBA_DYNST_ENUM	HolidaysRule;		/* DVP571  - 970826 - GRD */
extern DBA_DYNST_ENUM	CalendarOut;		/* DVP571  - 970828 - GRD */
extern DBA_DYNST_ENUM	A_Array;			/* REF385  - 971001 - GRD */ /* PMSTA14453 - DDV - 120705 - Array definition not clean */
extern DBA_DYNST_ENUM	Fusion_Status;		/* REF1047 - 971205 - GRD */
extern DBA_DYNST_ENUM	Syb_Remote_Exec;	/* REF1229 - 980226 - GPA/GRD */
extern DBA_DYNST_ENUM	Syb_Remote_ExecCb;	/* REF1229 - 980226 - GPA/GRD */
extern DBA_DYNST_ENUM	Msg_Log;		/* REF3072 - 990224 - GRD */
extern DBA_DYNST_ENUM	StratInstrDura;		/* REF3788 - SSO - 990708 */
extern DBA_DYNST_ENUM    Arg_Test;               /* NPE - 990921 for Java Test */
extern DBA_DYNST_ENUM	A_OpList;               /* REF3895 - OCE - 991231  */
extern DBA_DYNST_ENUM	A_SetEnv;               /* REF???? - GRD - 000314 */
extern DBA_DYNST_ENUM   A_SafeShutdown;         /* PMSTA-35209 - HLA - 190926 Safe Server Exit */
extern DBA_DYNST_ENUM	EvalEntity;		/* REF4497 - GRD/CSA - 000314 */
extern DBA_DYNST_ENUM	EvalEntities;		/* PMSTA05247 - LJE - 071206 */
extern DBA_DYNST_ENUM	EvalEntityValues;	/* REF4497 - GRD/CSA - 000314 */
extern DBA_DYNST_ENUM	EvalEntityEnum;		/* REF4497 - GRD/CSA - 000314 */
extern DBA_DYNST_ENUM	EvalEntityError;	/* REF4497 - GRD/CSA - 000314 */
extern DBA_DYNST_ENUM	EvalEntityRights;   /*  FIH-REF11818-060612 */
extern DBA_DYNST_ENUM    IdEntity;           /* REF5358 - CSY - 0008121 */
extern DBA_DYNST_ENUM	 A_UpdStratElt;	/* REF4908 - DED - 000619 */
extern DBA_DYNST_ENUM	 A_TradConstr;	/* REF6180 - DDV - 010717 */
extern DBA_DYNST_ENUM	 S_TradConstr;   /* REF6180 - DDV - 010717 */
extern DBA_DYNST_ENUM    Dynamic_Sql;                /* REF5506 SME */
extern DBA_DYNST_ENUM    A_Execution;       /* DLA - REF7560 - 020516 */
extern DBA_DYNST_ENUM    S_Execution;       /* DLA - REF7560 - 020527 */
extern DBA_DYNST_ENUM    A_GlExecFee;       /* DLA - REF7560 - 020516 */
extern DBA_DYNST_ENUM    S_GlExecFee;       /* DLA - REF7560 - 020516 */
extern DBA_DYNST_ENUM    A_ExtExecution;    /* DLA - REF7560 - 020516 */
extern DBA_DYNST_ENUM    Sql_Result;        /* REF11780 - 100406 - PMO */
extern DBA_DYNST_ENUM    A_VarStratElt;	    /* PMSTA08747-CHU-091112 */
extern DBA_DYNST_ENUM    A_RiskESElt;	    /* PMSTA-18426-CHU-140922 */
extern DBA_DYNST_ENUM    A_RiskValueElt;	    /* PMSTA-18426-CHU-140922 */
extern DBA_DYNST_ENUM    S_RiskValueElt;	    /* PMSTA-18426-CHU-140922 */
extern DBA_DYNST_ENUM	 A_RiskESEltCompo;      /* PMSTA-18426-CHU-141014 */
extern DBA_DYNST_ENUM	 A_RiskValueEltCompo;   /* PMSTA-18426-CHU-141014 */
extern DBA_DYNST_ENUM	 S_RiskValueEltCompo;   /* PMSTA-18426-CHU-141014 */
extern DBA_DYNST_ENUM    A_EventGroupingId;     /* PMSTA-17793 - 140318 - DDV */
extern DBA_DYNST_ENUM    S_EventGroupingId;     /* PMSTA-17793 - 140318 - DDV */
extern DBA_DYNST_ENUM	 A_CompoundOrderRule;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM	 S_CompoundOrderRule;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM	 A_CompoundOrderMasterElt;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM	 S_CompoundOrderMasterElt;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM	 A_CompoundOrderSlaveElt;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM	 S_CompoundOrderSlaveElt;	/*PMSTA- 18634 - SHR - 140904 */
extern DBA_DYNST_ENUM    Arg_TopN;                 /* PMSTA-34198 - 040419 - SGO */


/* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder (remove these structures ExtOp will be used) */
#if 0
extern DBA_DYNST_ENUM    A_LightOrder;    /* DLA - REF7560 - 020614 */
extern DBA_DYNST_ENUM    S_LightOrder;    /* DLA - REF7560 - 020614 */
#endif

extern DBA_DYNST_ENUM    GetFile_I;                  /* REF4333.2 PCL */
extern DBA_DYNST_ENUM    GetFile_O;                   /* REF4333.2 PCL */
extern DBA_DYNST_ENUM    A_UnMatchedExecution;     /* REF9764 - CHU - 031222 */
extern DBA_DYNST_ENUM    S_UnMatchedExecution;     /* REF9764 - CHU - 031222 */
extern DBA_DYNST_ENUM    A_ExtTransaction;         /* REF9764 - LJE - 040106 */
extern DBA_DYNST_ENUM    A_UnMatchedGlExecFee;	   /*REF10025-BRO-040401*/
extern DBA_DYNST_ENUM    AdvA_Vola;                /* REF10531 - TEB - 040806 */
extern DBA_DYNST_ENUM    OptiPurge;                /* REF11767 - CHU - 060411 */
extern DBA_DYNST_ENUM    OptiCheckIn;              /* REF11767 - CHU - 060504 */
extern DBA_DYNST_ENUM    OptiCheckOut;             /* REF11767 - CHU - 060504 */
extern DBA_DYNST_ENUM    SecuCheck;                 /*  FPL-REF11314-060516 */
extern DBA_DYNST_ENUM    A_OpenedPosition;          /* BSA - PMSTA01179 - 061219 */
extern DBA_DYNST_ENUM	 A_FamilyDef;				/* PMSTA05911 - DDV - 080404 */
extern DBA_DYNST_ENUM	 A_FamilyElt;			  	/* PMSTA05911 - DDV - 080404 */

extern DBA_DYNST_ENUM	 A_EntityComment;			/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 S_EntityComment;			/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 A_AttributeComment;   		/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 S_AttributeComment;  		/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 A_PermValComment;			/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 S_PermValComment;			/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 A_ApplParamComment;		/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 S_ApplParamComment;		/* PMSTA11809 - PRS - 110428 */
extern DBA_DYNST_ENUM	 SessionMgt;		        /* PMSTA13167 - DDV - 111215 - Add new structure for session management */
extern DBA_DYNST_ENUM    SqlRequest;                /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    CallRequest;               /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    AutoCreateItem;            /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    SqlRequestParam;           /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    SqlRequestResultSet;       /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    SqlRequestOutputDef;       /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    SqlRequestOutputParam;     /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    SqlRequestMsg;             /* PMSTA-34344 - LJE - 200928 */
extern DBA_DYNST_ENUM    TemenosPckHeader;          /* PMSTA-46681 - LJE - 240902 */
extern DBA_DYNST_ENUM    ProcessingContext;         /* PMSTA-46681 - LJE - 240902 */
extern DBA_DYNST_ENUM    A_PurgeEntity;		        /* PMSTA15008 - JPP - 120920 */
extern DBA_DYNST_ENUM    A_StartFusionByCd;         /* PMSTA21215 - PCL */
extern DBA_DYNST_ENUM    A_ExecFinAnalysisAllDomain; /* PMSTA-18593 - LJE - 151216 */
extern DBA_DYNST_ENUM    A_ExecSelExportDataByCd;   /* PMSTA-22169 - DLA - 160119 */

extern DBA_DYNST_ENUM	A_ApplChannelProf;			/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM	S_ApplChannelProf;			/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM	A_ApplChannelProfCompo;	/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM	S_ApplChannelProfCompo;	/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM	A_ApplSessionHisto;		/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM	S_ApplSessionHisto;		/* PMSTA-22551 - EFE - 20160323 */
extern DBA_DYNST_ENUM   ExtTaxLot;              /* PMSTA-31342 - SANAND - 180528 */
extern DBA_DYNST_ENUM   Get_Guid;               /* PMSTA-34827 - JBC - 190218 */
extern DBA_DYNST_ENUM   Arg_WS;                 /* PMSTA-37138 - 11092019 - sanand */
extern DBA_DYNST_ENUM   Arg_WS_OP;                 /* PMSTA-37138 - 09112019 - Lik */
extern DBA_DYNST_ENUM   Arg_OverlayInitFetch;      /* PMSTA-XXXX - 30012020 - Lik */
extern DBA_DYNST_ENUM   Arg_OverlayNextFetch;                 /* PMSTA-XXXX - 30010202 - Lik */
extern DBA_DYNST_ENUM   Arg_StratOvelayFetch;                 /* PMSTA-XXXX - 30010202 - Lik */
extern DBA_DYNST_ENUM   Arg_PtfOvelayFetch;                 /* PMSTA-XXXX - 30010202 - Lik */
extern DBA_DYNST_ENUM   StandInstructFilterArg;     /* PMSTA-40209 - LIK - 25082020 */
extern DBA_DYNST_ENUM   Out_Amount;                /* PMSTA-49587 - AIS - 220926 */
extern DBA_DYNST_ENUM   O_PackageDefinition;          /* PMSTA-46681 - LJE - 230915 */
extern DBA_DYNST_ENUM   InceptDtArg;        /* WEALTH-6158 - JBC - 20240330 */  


extern DBA_DYNST_ENUM    LASTDYNST;

extern long              EV_MaxDynStLenWithTextFld;     /* PMSTA07121 - Maximum lenght of a dynamic strcuture including text fields */
extern long              EV_MaxDynStLenWithoutTextFld;  /* PMSTA07121 - Maximum lenght of a dynamic strcuture excluding text fields */
extern long              EV_MaxMDDynStLenWithTextFld;   /* PMSTA07121 - Maximum lenght of a dynamic strcuture based on Metadictionnary definition including text fields */
extern long              EV_MaxMDDynStLenWithoutTextFld;/* PMSTA07121 - Maximum lenght of a dynamic strcuture based on Metadictionnary definition including text fields */
extern unsigned int      EV_MaxFieldLen;                /* PMSTA07121 - Maximum lenght of a dynamic strcuture's field */
extern unsigned int      EV_MaxFieldLenWithoutText;     /* PMSTA07121 - Maximum lenght of a dynamic strcuture's field (excluding text type) */

/* 031008 - PMO */
/*lint -restore */

#endif     /* ifndef DBADEF_H */
/************************************************************************
**      END        dbadef.h
*************************************************************************/


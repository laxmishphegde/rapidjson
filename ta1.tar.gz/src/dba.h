/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBA_H
#define DBA_H

#include <assert.h>

#ifndef ICU4AAA_H
#include "icu4aaa.h"
#endif

#include "conrole.h"

/************************************************************************
**      External Structure definitions
*************************************************************************/
class DbiConnection;
class DbiConnectionHelper;
class AAAConnectionDescription;
class BuildBindOption;

/* Here because of circular reference of include file :-O PMSTA-26427 - 240217 - PMO */
enum class AAAConnectionKind
{
    StandardConnection,
    UseGlobalProvider        // Dispatcher keep one global connection for each fusion server
};

#ifndef MD_DYNDEF_H
#define MD_DYNDEF_H
#include "md_dyndef.h"
#endif

#include <list>
#include "msg.h"
#include "dict.h"
#include "proc.h"
#include "dbi.h"
#include "fuscluster.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/* Access process definitions */

#ifndef TLS_H
#include "tls.h"
#endif

#ifndef TIMER_H
#include "timer.h"
#endif

#ifndef DBA_MSG_ORIGIN_ENUM_H
#include "dba_msg_origin_enum.h"    /* DLA - REF7264 - 020131 */
#endif

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

extern DBA_RDBMS_ENUM EV_RdbmsVendor;
extern DBA_RDBMS_ENUM EV_SourceRdbmsVendor;
extern DBA_RDBMS_ENUM EV_TargetRdbmsVendor;


static const unsigned char SV_CharFileSeparator=28;      /* caractère FS - File Separator   */
static const unsigned char SV_CharRecordSeparator=30;    /* caractère RS - Record Separator */
static const unsigned char SV_CharUnitSeparator=31;      /* caractère US - Unit Separator   */

#define USE_NEW_ACCESS_API(dbiConn)  ((dbiConn) != nullptr && (dbiConn)->isDbAccessByRequestHelper())

#define WAIT      0
#define NO_WAIT   1

#define DBA_CONN_NOT_FOUND   -1
#define DBA_CONN_PROBLEM     -2

#define DBA_NOT_USED_0001           0x0001
#define DBA_NO_CLOSE                0x0002
#define DBA_SET_CONN                0x0004
#define DBA_IN_TRAN                 0x0008
#define DBA_INS_ID                  0x0010
#define DBA_OP_BLOCK                0x0020      /* DVP291 */
#define DBA_CHECK_UD_AUDIT          0x0030
#define DBA_MANAGE_ORDER            0x0040
#define DBA_NO_MAIN_LEVEL           0x0060      /* DVP483 */
#define DBA_NO_OLD_DATA_AUDIT       0x0080      /* DLA - REF9952 - 041021 */
#define DBA_NO_ERROR                0x0100      /* DVP485 */ /* REF3298 - SSO - 990413 define was bad:0x0050->0x0100 */
#define DBA_NO_SUBS_AUDIT           0x0200      /* DLA - PMSTA06808 - 081114 */
#define DBA_NO_PROC_ERROR           0x0400      /* PMSTA-13946 - LJE - 120328 */

#define SEND_FINAL            0x0001
#define SEND_MORE             0x0002
#define SEND_ERROR            0x0004
#define SEND_COUNT            0x0008
#define SEND_FLUSH            0x0010
#define SEND_FINISHED         0x0020

#define CONNECTION_LEVEL        1
#define COMMAND_LEVEL           2

#define CANCEL_CURRENT          1
#define CANCEL_ATTN             2
#define CANCEL_ALL              3

#define DBA_RPC                 1
#define DBA_LANG                2

/* Define different roles for stored procedures */
#define DBA_ROLE_FUSION                            1
#define DBA_ROLE_UPD_UD_FIELDS                  1000
#define DBA_ROLE_LOAD_STRAT_LNK                 1001
#define DBA_ROLE_GET_LAST_STRAT_HIST            1002
#define DBA_ROLE_CURRENCY_MODIF	                1003
#define DBA_ROLE_SCPT_DEF_CONTROL               1004
#define DBA_ROLE_GET_LAST_DOMAIN                1005
#define DBA_ROLE_GET_DEF_DOMAIN                 1006
#define DBA_ROLE_DEL_LIST_COMPO_BY_DT           1007
#define DBA_ROLE_LIST_COMPO_FOR_DATE            1008
#define DBA_ROLE_EXECUTIONS                     1009	/* DVP168 - 960814 - DED */
#define DBA_ROLE_SEL_SH_TP_BY_INSTR             1011	/* DVP242 - 961106 - ROI */
#define DBA_ROLE_SEL_SH_TP_BY_OP                1012	/* DVP242 - 961106 - ROI */
#define DBA_ROLE_GET_SH_USER_RULE               1013	/* DVP305 - 961211 - ROI */
#define DBA_ROLE_LOCK_DB_FOR_INSERT             1014	/* DVP196 - 970203 - GRD */
#define DBA_ROLE_UNLOCK_DB_FOR_INSERT           1015   	/* DVP196 - 970203 - GRD */
#define DBA_ROLE_LOAD_ORDER_OPERATION           1016	/* DVP196 - 970203 - GRD */
#define DBA_ROLE_RECONCILE_STRATEGY             1017
#define DBA_ROLE_SEL_SH_ACC_PERIOD_BY_ACCPLAN   1018	/* ROI - 970403 - DVP412 */
#define DBA_GET_LAST                            1019    /* PEC - 970403 - DVP415 */
#define DBA_ROLE_EXPORT                         1020    /* PEC - 970423 - DVP437 */
#define DBA_ROLE_EXTOP_IS_COPY                  1021    /* GRD - 970619 - DVP508 */
#define DBA_ROLE_PTFSYNTH_ALL                   1022	/* RAK - 970707 - DVP535 */
#define DBA_ROLE_PORT_POS_SET                   1023
#define DBA_ROLE_CURRENCY_BY_DFLT               1024    /* GRD - 970806 - DVP548 */
#define DBA_ROLE_SEL_ALL_INTER_COND             1025	/* GRD - 970821 - DVP563 */
#define DBA_ROLE_INSERT_SCRIPT                  1026
#define DBA_ROLE_SEL_ATTRIBUTE_FOR_UDS          1027    /* FIH - 980428 - REF1983 */
#define DBA_ROLE_REVERSE                        1028    /* DED - 980604 - REF956  */
#define DBA_ROLE_FUSION_STAT_RUNNING            1029    /* SME - 980813 - REF2602 */
#define DBA_ROLE_START_IMPORT                   1030    /* SME - 980825 - REF697  */
#define DBA_ROLE_END_IMPORT                     1031    /* SME - 980825 - REF697  */
#define DBA_ROLE_OFFICIAL_VALUATION             1032    /* GRD - 981014 - REF2338 */
#define DBA_ROLE_LAST_UNIT_VALUATION            1033    /* GRD - 981014 - REF2338 */
#define DBA_ROLE_SCPT_DEF_STRAT                 1034    /* REF2996 - SSO - 990114 */
#define DBA_ROLE_EVENT_SCHED_LAST_DATE          1035	/* GRD - 990210 - REF1402 */
#define DBA_ROLE_LOAD_HIER_FMT                  1036	/* ROI - 990624 - REF3729 */
#define DBA_ROLE_SEL_MKTSEGT_FOR_SELECTION      1037    /* FIH - 990727 - REF3733 */
#define DBA_ROLE_UPDSTATUS_NOSUBSCRIPTION       1038    /* REF3852 - OCE - 990809 */
#define DBA_ROLE_SEL_ALL_CURRENCY               1039    /* REF4184 SME */
#define DBA_ROLE_INIT_CHILDREN                  1040    /* REF2467 - DDV - 000127*/
#define DBA_ROLE_INIT_PARENT                    1041    /* REF2467 - DDV - 000127*/
#define DBA_ROLE_DELETEALL_FCTRESULT            1043    /* FIH-REF4167-000216   */
#define DBA_ROLE_SCPT_DEF_UPDFIELD              1044    /* FIH-REF4281-000229   */
#if 0
#define DBA_ROLE_UPD_TXT_FIELDS                 1045    /* GRD - 000310 - REF4204 */
#endif
#define DBA_ROLE_SUBSCRIPTION                   1046	/* GRD - 000321 - REF4204 */
#define DBA_ROLE_START_EXPORT                   1047    /* REF4034 SME */
#define DBA_ROLE_END_EXPORT                     1048    /* REF4034 SME */
#define DBA_ROLE_SEL_SUBSCRIPTIONS              1049    /* REF4204 - 000609 - GRD */
#define DBA_ROLE_UPDATE_MODEL                   1050    /* REF4888 000609 SKE */
#define DBA_ROLE_SEL_PTFTHIRDCOMPO_BY_THIRD     1051    /* RAK - 000613 */
#define DBA_ROLE_NO_UPD_TXT_FIELDS              1052    /* GRD - 000720 - REF4946 */
#define DBA_ROLE_GET_ALL_CURR_FROM_DB           1053    /* MDE - REF5443 - 001122 */
#define DBA_ROLE_GET_ALL_CURR_BY_CD_FROM_DB     1054    /* MDE - REF5443 - 001122 */
#define DBA_ROLE_HIERPTF                        1055    /* SKE - REF5562 - 010205 */
#define DBA_ROLE_UPDATE_STATUS                  1056    /* DLA - REF6957 - 010829 */
#define DBA_ROLE_EMPTYLIST_LNK                  1057    /* RAK - REF7218 - 020129 */
#define DBA_ROLE_COLLECT                        1058    /* PCL - REF7386 - 020225 */
#define DBA_ROLE_CALL_WITH_COLLECTION           1059    /* PCL - REF7386 - 020225 */
#define DBA_ROLE_STOP                           1062    /* PCL - REF4333.3 - 020507 */
#define DBA_ROLE_STOP_ALL                       1063    /* PCL - REF4333.3 - 020508 */
#define DBA_ROLE_SEL_MKTSEGT_BY_MKTSTRUCT       1064    /*  HFI-REF7420-020711  */
#define DBA_ROLE_PERF_ATTRIB_RA                 1065    /* REF7421 - YST - 020807 */
#define DBA_ROLE_EXT_RET_ANALYSIS               1066    /* REF7421 - YST - 020809 */
#define DBA_ROLE_DEL_LIST_COMPO_IMPORT          1077    /* FPL-REF7774-020906 */
#define DBA_ROLE_DEL_NOTEPAD_BY_OBJECT          1078    /* PMO - REF7560 - 020906 */
#define DBA_ROLE_GET_OPER_FOR_NOTEPAD           1079    /* DLA - REF7560 - 020918 */
#define DBA_ROLE_FCT_RESULT						1080	/* RAK - REF7768 - 021002 */
#define DBA_ROLE_USE_VECTOR_ID                  1081	/* DDV - REF7758 - 021011 */
#define DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS  1082    /* PMO - REF8116 - 021023 */
#define DBA_ROLE_EVENT_SCHED_PERF_DATA          1083	/* RAK - REF9125 - 031009 */
#define DBA_ROLE_UNMATCHED_EXECUTIONS           1084    /* CHU - REF9764 - 031222 */
#define DBA_ROLE_UNMATCHED_EXECUTIONS_SKIP_UPD_UD_FIELDS  1085    /* CHU - REF9764 - 031222 */
#define DBA_ROLE_SCPT_OBJECT_AND_NATURE         1086    /* FIH-REF9789-040209  */
#define DBA_ROLE_GUI_CONTEXT                    1087    /* FIH-REF10391-040721 */
#define DBA_ROLE_NO_SUBSCRIPTION                1088    /* DLA - REF10497 - 040726 */
#define DBA_ROLE_DELETE_BY_OP                   1089    /* REF10567-EFE-041103     */
#define DBA_ROLE_MULTISELECT_INSTR              1090    /* CHU - REF10744 - 041112 */
#define DBA_ROLE_LOAD_SH_POS                    1091    /* DDV - REF10793 - 041206 */
#define DBA_ROLE_GET_INCEVT_FOR_IMPORT          1092    /* DLA - REF11013 - 050317 */
#define DBA_ROLE_STRAT_DOM                      1093    /* REF11435 - TEB - 051013 */
#define DBA_ROLE_DEL_POSITION_OPENOPERID        1094    /* REF10993 - 120505 - PMO */
#define DBA_ROLE_DEL_BALANCE_OPENOPERID         1095    /* REF10993 - 120505 - PMO */
#define DBA_ROLE_SEL_INCOME_FOR_VALO            1096    /* PMSTA00485 - CHU - 061011 */
#define DBA_ROLE_INSUPD_DICTFCT_BY_IMP          1097    /* DLA - PMSTA697 - 061018 */
#define DBA_ROLE_NOTIF_DISPATCH                 1098    /* DLA - PMSTA-160 - 070119 */
#define DBA_ROLE_TOPHIERPTF                     1099    /* PMSTA04637-CHU-080109 */
#define DBA_ROLE_SEL_SH_COMPL_CHRONO_BY_STRAT   1100    /*  FPL-080221-PMSTA05345   */
#define DBA_ROLE_DATA_DECURITY                  1102    /* PMSTA07121 - DDV - 090319 */
#define DBA_ROLE_COPY_COMPL_CHRONO_BY_STRAT     1103    /*PMSTA08368-BRO-090806*/
#define DBA_ROLE_TEST_FMK                       1104    /*PCC12748-SRU-100201*/
#define DBA_ROLE_ORDER_SESSION                  1106    /* PMSTA09451-DDV-100304 */
#define DBA_ROLE_DOMAIN_INSERT                  1107    /* OCS-36521 - TEB - 110124 */
#define DBA_ROLE_EXTERNAL_POS                   1108    /* PMSTA11101-CHU-110201 */
#define DBA_ROLE_DOMAIN_UPD                     1110    /* PMSTA-11273 - TEB - 110202 */
#define DBA_ROLE_UPD_PASSWD					    1111	/* DLA - PMSTA-10947 - 101123 */
#define DBA_ROLE_SCPT_CHECK_ELT					1112	/* PMSTA11221-PRS-110201 */
#define DBA_ROLE_SCPT_CHECK_CELL				1113	/* PMSTA11221-PRS-110201 */
#define DBA_ROLE_GET_SCRIPT_ACTION              1114    /*  FPL-PMSTA10714-110202   */
#define DBA_ROLE_SCPT_CHECK_SUBS				1115	/* PMSTA11221-PRS-110210 */
#define DBA_ROLE_STANDARD_INSERT                1116    /* OCS-37396 - TEB - 110310 */
#define DBA_ROLE_STANDARD_UPDATE                1117    /* OCS-37396 - TEB - 110310 */
#define DBA_ROLE_NO_OPTI                        1118    /* PMSTA11636 - DDV - 110318 */
#define DBA_ROLE_UDT                            1119    /* PMSTA-13109 - LJE - 111125 - For user defined tables purpose */
#define DBA_ROLE_USESTOREDPROC                  1120    /* PMSTA13876 - DDV- 130806 - Use stored procedure after treatment in 'C' function */
#define DBA_ROLE_TRANCOUNT                      1121    /* PMSTA-17137 - 251013 - PMO - Get Sybase @@trancount */
#define DBA_ROLE_BY_BUS_ENTITY                  1122    /* PMSTA-17089 - DDV - 131206 */
#define DBA_ROLE_UPDATE_REQUEST_STATUS          1123    /* PMSTA-17355 - PCL - 131219 */
#define DBA_ROLE_BACKUP                         1124    /* PMSTA-17764 - DDV - 140306 */
#define DBA_ROLE_CANCEL                         1125    /* PMSTA-17985 - DDV - 140428 */
#define DBA_ROLE_SCPT_DEF_VIEW                  1126    /*  HFI-PMSTA-18525-140815  */
#define DBA_ROLE_SCPT_ADD_LOAD                  1127    /* PMSTA-18601 - DDV - 141030 */
#define DBA_ROLE_COMPOUND_MASTER_ADMIN          1128    /* PMSTA-18601 - DDV - 141120 */
#define DBA_ROLE_MERGE_ORDER_SESSION            1129    /*  HFI-PMSTA-18895-141113  */
#define DBA_ROLE_UPD_ENTITY                     1130    /*  PMSTA-19243 - DDV - 150506 */
#define DBA_ROLE_BY_PLAN                        1131    /* PMSTA-21265 - DDV - 151110 */
#define DBA_ROLE_FORMAT                         1132    /* PMSTA-18593 - LJE - 150601 */
#define DBA_ROLE_IMPORT_USR_MD                  1133    /* PMSTA-18940 - EFE - 151005 */
#define DBA_ROLE_SCPT_CTRL_INIT                 1134    /* PMSTA-18593 - LJE - 160212 */
#define DBA_ROLE_SCPT_DEF_VAL_INIT              1135    /* PMSTA-18593 - LJE - 160212 */
#define DBA_ROLE_NO_COMP_DATA                   1136    /* LR-1743 - DLA - 160512 */
#define DBA_ROLE_SET_APPL_SESSION               1137    /* PMSTA-22902 - DDV - 160711 */
#define DBA_ROLE_UPD_APPL_SESSION_ACCESS        1138    /* PMSTA-22549 - DLA - 160712 */
#define DBA_ROLE_MANAGE_APPL_SESSION            1139    /* PMSTA-22549 - DLA - 160712 */
#define DBA_ROLE_GET_VERSION                    1140    /* PMSTA-24510 - 220816 - PMO */
#define DBA_ROLE_FUSION_SYNC                    1141    /* PMSTA-24510 - 220816 - PMO */
#define DBA_ROLE_SAVE_DOMAIN                    1142    /* HFI-PMSTA-25677-161213   Stored procedure to save last_domain_id in table appl_user  */
#define DBA_ROLE_GETENV                         1143    /* DLA - PMSTA-24751 - 161227 */
#define DBA_ROLE_ASSIGNED_AND_VALID             1144    /* PMSTA-26250 - DDV - 170426 */
#define DBA_ROLE_UPD_CHANGE_SET_APPL_SESSION    1145    /* PMSTA-26250 - DDV - 170428 */
#define DBA_ROLE_SEL_SHADOW                     1146    /* PMSTA-26250 - DDV - 170515 */
#define DBA_ROLE_SEL_FEATURE                    1147    /* PMSTA-26250 - LJE - 170531 */
#define DBA_ROLE_EXIST_EVT_POS                  1148    /* PMSTA-28945 - CHU - 171117 */
#define DBA_ROLE_SPLIT_FCTRESULT                1149    /* PMSTA-28596 - CHU - 171201 */
#define DBA_ROLE_LOAD_UTCOFFSET                 1150    /* PMSTA-30817 - DDV - 180501 */
#define DBA_ROLE_LOAD_DBTIMEZONE                1151    /* PMSTA-30817 - DDV - 180501 */
#define DBA_ROLE_MGMT_PAYOUT					1152	/* PMSTA-32690 - CHU - 180920 */
#define DBA_ROLE_GET_PTF_INSTR_PRICE            1153    /* PMSTA-32157 - SILPA - 180905 */
#define DBA_ROLE_CLUSTER                        1154    /* PMSTA-33371 - DLA - 181023 */
#define DBA_ROLE_BY_PARENT                      1155    /* PMSTA-34380 - DDV - 190213 */
#define DBA_ROLE_STRUCTURED_PRODUCT             1156    /* PMSTA-35040 - DDV - 190314 */
#define DBA_ROLE_NESTED_MULTISELECT             1157    /* PMSTA-36209 - JBC - 190812 */
#define DBA_ROLE_UPD_SRV_ACCESS                 1158    /* PMSTA-34845 - JJN - 200115 */
#define DBA_ROLE_PARENT_REFERENCE_FORMAT        1159    /*  HFI-PMSTA-38117-191209  */
#define DBA_ROLE_CHILD_REFERENCED_FORMAT        1160    /*  HFI-PMSTA-38117-191209   */
#define DBA_ROLE_REFERENCE_STATUS               1161    /*  HFI-PMSTA-38117-200129  */
#define DBA_ROLE_SELECT_REFERENCE_FORMAT        1162    /*  HFI-PMSTA-38117-200209  */
#define DBA_ROLE_FORCE_STORED_PROC              1163    /* PMSTA-37366 - LJE - 200406 */
#define DBA_ROLE_UPD_ACTIVE_F                   1164    /* PMSTA-37366 - LJE - 200406 */
#define DBA_ROLE_UPD_VALIDITY_D                 1165    /* PMSTA-37366 - LJE - 200406 */
#define DBA_ROLE_PARENT_REFERENCE               1166    /*  HFI-PMSTA-38117-191209  */
#define DBA_ROLE_CHILD_REFERENCE                1167    /*  HFI-PMSTA-38117-191209   */
#define DBA_ROLE_SELECTIVE_REPLOLD              1168    /* PMSTA-29302 - CHU - 180218 */
#define DBA_ROLE_MOVE_ORDERS                    1169    /* PMSTA-39396 - Silpakal - 200320 */
#define DBA_ROLE_FUS_CHECK                      1170    /* PMSTA-39396 - Silpakal - 200320 */
#define DBA_ROLE_SELECT_PACKAGE_DEFINTION       1171    /*  HFI-PMSTA-41842-200916  */
#define DBA_ROLE_HIERBLK_LOAD_ORDER             1172    /* PMSTA-42359 - LIK */
#define DBA_ROLE_PACKAGE_DEF_INSTALLATION       1173    /*  HFI-PMSTA-41842-200916  */
#define DBA_ROLE_INIT_LOAD                      1174    /* PMSTA-44492 - JBC - 210331 */
#define DBA_ROLE_LOAD_HEDG_FMT                  1175    /* PMSTA-44959 - LIK - 210429 */ 
#define DBA_ROLE_VIEW_MKTSEG_INSTR_BY_DT        1176    /* PMSTA-46842 - Deepthi - 220204 */
#define DBA_ROLE_BY_DATE                        1177    /* PMSTA-50418 - DDV - 210811 */
#define DBA_ROLE_SVC_CFG                        1178    /* PMSTA-49902 - JBC - 221010 */
#define DBA_ROLE_PROD_FEE                       1179    /* PMSTA-51324 KD-13461 */
#define DBA_ROLE_SET_OF_PROD_FEE                1180    /* PMSTA-51324 KD-13461 */
#define DBA_ROLE_OPERATION_FEE_DTL              1181    /* PMSTA-51324 KD-13461 */
#define DBA_ROLE_PERF_FIRST_OP                  1182    /* PMSTA-48227 - JBC - 220418 */
#define DBA_ROLE_FUSION_STAT_BLOCK              1183    /* PMSTA-54717 - JBC - 231031 */
#define DBA_ROLE_DB_ACCESS                      1200    /* PMSTA-45413 - LJE - 210617 */
#define DBA_ROLE_DB_STATUS                      1201    /* PMSTA-45413 - LJE - 210617 */
#define DBA_ROLE_DB_ACCESS_USR                  1202    /* PMSTA-45413 - LJE - 210617 */
#define DBA_ROLE_STATUS                         1203    /* PMSTA-45413 - LJE - 210617 */
#define DBA_ROLE_SCPT_DEF_VAL                   1204    /* PMSTA-45413 - LJE - 220224 */
#define DBA_ROLE_USE_DOM_PORT                   1205    /* PMSTA-54517 - DDV - 230928 */
#define DBA_ROLE_SEL_QUEST_COND_BY_QED          1206    /* PMSTA-54517 - DDV - 230928 */
#define DBA_ROLE_CHK_HIER_PTF                   1207    /* PMSTA-48867-Satya*/
#define DBA_ROLE_SEL_MENU_ITEM_BY_MPID          1208    /*  HFI-PMSTA-54127-2024-02-06  */
#define DBA_ROLE_SEL_MENU_ITEM_FOR_RPC          1209    /*  HFI-PMSTA-54127-2024-02-06  */

#define DBA_ROLE_SEL_GENERIC                    1210    /* PMSTA-46681 - LJE - 240704 */    

#define DBA_ROLE_LOGIN_DB                       9998
#define DBA_ROLE_EXTERNAL_USE                   9999    /* PMSTA-18593 - LJE - 150924 - Stored procedure use by an external tool (WUI, Report, Shell, ...) */

#define DBA_ROLE_DB_ACCESS_FACTOR              10000    /* PMSTA-45830 - LJE - 220426 */

/* different kind of modules available. GRD DVP404. */
#define MODULE_MASK_NONE         0x00000000  /* 00000000|00000000|00000000|00000000          0 */
#define MODULE_MASK_ALL          0xFFFFFFFF  /* 11111111|11111111|11111111|11111111 4294967295 */
#define MODULE_MASK_ATTRIB       0x00000001  /* 00000000|00000000|00000000|00000001          1 */
#define MODULE_MASK_RISK         0x00000002  /* 00000000|00000000|00000000|00000010          2 */
#define MODULE_MASK_ACC          0x00000004  /* 00000000|00000000|00000000|00000100          4 */
#define MODULE_MASK_FUND         0x00000008  /* 00000000|00000000|00000000|00001000          8 */
#define MODULE_MASK_CORPACTION   0x00000010  /* 00000000|00000000|00000000|00010000         16 */
#define MODULE_MASK_ADVANAL      0x00000020  /* 00000000|00000000|00000000|00100000         32 */
#define MODULE_MASK_COMPOMGR     0x00000040  /* 00000000|00000000|00000000|01000000         64 */
#define MODULE_MASK_EXCEL        0x00000080  /* 00000000|00000000|00000000|10000000        128 */
#define MODULE_MASK_PROD         0x00000100  /* 00000000|00000000|00000001|00000000        256 */
#define MODULE_MASK_CORE         0x00000200  /* 00000000|00000000|00000010|00000000        512 */
#define MODULE_MASK_RA           0x00000400  /* 00000000|00000000|00000100|00000000       1024 */
#define MODULE_MASK_ACM          0x00000800  /* 00000000|00000000|00001000|00000000       2048 */
#define MODULE_MASK_OM           0x00001000  /* 00000000|00000000|00010000|00000000       4096 */
#define MODULE_MASK_FREE19       0x00002000  /* 00000000|00000000|00100000|00000000       8192 */
#define MODULE_MASK_FREE18       0x00004000  /* 00000000|00000000|01000000|00000000      16384 */
#define MODULE_MASK_FREE17       0x00008000  /* 00000000|00000000|10000000|00000000      32768 */
#define MODULE_MASK_FREE16       0x00010000  /* 00000000|00000001|00000000|00000000      65536 */
#define MODULE_MASK_FREE15       0x00020000  /* 00000000|00000010|00000000|00000000     131072 */
#define MODULE_MASK_FREE14       0x00040000  /* 00000000|00000100|00000000|00000000     262144 */
#define MODULE_MASK_FREE13       0x00080000  /* 00000000|00001000|00000000|00000000     524288 */
#define MODULE_MASK_FREE12       0x00100000  /* 00000000|00010000|00000000|00000000    1048576 */
#define MODULE_MASK_FREE11       0x00200000  /* 00000000|00100000|00000000|00000000    2097152 */
#define MODULE_MASK_FREE10       0x00400000  /* 00000000|01000000|00000000|00000000    4194304 */
#define MODULE_MASK_FREE09       0x00800000  /* 00000000|10000000|00000000|00000000    8388608 */
#define MODULE_MASK_FREE08       0x01000000  /* 00000001|00000000|00000000|00000000   16777216 */
#define MODULE_MASK_FREE07       0x02000000  /* 00000010|00000000|00000000|00000000   33554432 */
#define MODULE_MASK_FREE06       0x04000000  /* 00000100|00000000|00000000|00000000   67108864 */
#define MODULE_MASK_FREE05       0x08000000  /* 00001000|00000000|00000000|00000000  134217728 */
#define MODULE_MASK_FREE04       0x10000000  /* 00010000|00000000|00000000|00000000  268435456 */
#define MODULE_MASK_FREE03       0x20000000  /* 00100000|00000000|00000000|00000000  536870912 */
#define MODULE_MASK_FREE02       0x40000000  /* 01000000|00000000|00000000|00000000 1073741824 */
#define MODULE_MASK_FREE01       0x80000000  /* 10000000|00000000|00000000|00000000 2147483648 */

/* Differents values used for "tempTablesMask" field in DBA_CONNECT_INFO_ST */
#define ALL_TEMP_TABLES				0xFFFFFFFF		/* DLA - PMSTA11512 - 110224 */
#define DOM_OPER                    0x00000001           /* DVP249 */
#define DOM_POSITION_INSTR_PORT     0x00000002      /* DVP249 */
#define TT_LIST_STRAT_LINK          0x00000004           /* Processing of the temporary tables #list_strat_link - PMSTA-46575 - 211214 - DDV */
#define OBJ_ID                      0x00000008           /* DVP249 */
#define DOM_STRAT                   0x00000010           /* REF3729 - RAK - 990615 */
#define TMP_OPER                    0x00000020		/* REF2467 - DDV - 991224 */
#define DOM_THIRD_CURR              0x00000040           /* REF4306 - DDV - 000223 */
#define DOM_LISTCOMPO               0x00000080           /* REF4306 - DDV - 000223 */
#define GRID_VECTOR                 0x00000100           /* REF4888 - 000626 - SKE */
#define STRAT_MARKET                0x00000200           /* REF4888 - 000626 - SKE */
#define DOM_PARENT_STRAT            0x00000400           /* REF4888 - 000626 - SKE */
#define TMP_STRAT_HIST              0x00000800           /* REF4888 - 000626 - SKE */
#define STRATEGY                    0x00001000           /* REF4888 - 000626 - SKE */
#define BUILD_LIST                  0x00002000           /* PMSTA-24012 - DDV - 160902 - Processing of the temporary table #current_compo and #new_compo */
#define TCT_VECTOR_ID               0x00004000 /* Processing of the temporary table #vector_id     REF7560 - PMO */
#define TCT_DOM_PORT_FUS            0x00008000 /* Processing of the temporary table #dom_port_fus  REF7560 - PMO */
#define TCT_FUS_TAB                 0x00010000 /* Processing of the temporary table #fus_tab       REF7560 - PMO */
#define DOM_PSP                     0x00020000 /* Processing of the temporary table #dom_psp */ /* REF7758 - LJE - 020919 */
#define IN_OBJECT                   0x00040000 /* Processing of the temporary table #in_object */ /*REF10694 - DDV - 041124 */
#define ARCHIVE_DELOP_LISTOPENOPER  0x00080000 /* Processing of the temporary tables #archive, #delete_op, #list_open_oper_id DLA - PMSTA11512 - 110224 */
#define SUBD_DOM_OPE                0x00100000 /* Processing of the temporary tables #dom_ope DLA - PMSTA11512 - 110224 */
#define APP_PLAN_ELEM               0x00200000 /* Processing of the temporary tables #tmp_app_plan_elem	 DLA - PMSTA11512 - 110225 */
#define APPL_PARAM                  0x00400000 /* Processing of the temporary tables #appl_param	 DLA - PMSTA11512 - 110225 */
#define WORK_BLOCK_OP               0x00800000 /* Processing of the temporary tables #work_block_op */ /* PMSTA-18593 - LJE - 141107 */
#define EXT_OP_LIST                 0x01000000 /* Processing of the temporary tables #ext_op_list	 PMSTA-16327 - 060513 - PMO */
#define PORT_SYNTH                  0x02000000 /* Processing of the temporary tables #port_synth  	 DLA - PMSTA11512 - 110225 */
#define WORK_HIER_LIST              0x04000000 /* Processing of the temporary tables #work_hier_list */  /* ORACLE - LJE - 141016 */
#define SCRIPT_DEF                  0x08000000 /* Processing of the temporary tables #script_definition DDV - PMSTA-18601 - 141016 */
#define TT_TAXLOT_PROCESS           0x10000000 /* Processing of the temporary tables taxlot_process PMSTA-34973 - 040319 - SGO */
#define TT_FORMAT                   0x20000000 /* Processing of the temporary tables #tt_format - PMSTA-38117 - KNI - 09032020 */
#define TT_HC_PTF_LIST              0x40000000 /* Processing of the temporary tables #hc_ptf_list - PMSTA-39010 - JJN - 07052020 */
#define TT_BUS_UNIT                 0x80000000 /* Processing of the temporary tables - #bus_unit_links, #linked_hier_bus_units, #bus_units_data_profile
														PMSTA-46366 - SRIDHARA - 13102021 */
/* Hierarchy types */
#define ONE_TO_ONE            1
#define ONE_TO_LIST           2

/* PMSTA13460 - TGU - 120420 */
#define  BIT64_ONE  static_cast<INT64_T>(1)

/* CHK_LIST */
#define CHK_LIST_NOT_CONST           1
#define CHK_LIST_ALREADY_BUILT       2
#define CHK_LIST_MUST_BE_BUILT       3
#define CHK_LIST_HIER_MUST_BE_BUILT  4
#define CHK_LIST_NON_PERIODIC        5
#define CHK_LIST_HIER_NON_PERIODIC   6

/* list of forbidden characters for a specified datatype */
#define DBA_FORBIDEN_DEFAULT  "\""
#define DBA_FORBIDEN_CODE     "!#%&'\"():;<>?@[\\]^`{|}~ "
#define DBA_FORBIDEN_SYSNAME  "!#%&'\"(),.:;<>?@[\\]^`{|}~ $+-/*"	/* REF3231 */
#define DBA_FORBIDEN_SCRIPT	"'"
#define DBA_FORBIDEN_PASSWORD   " "     /*  FPL-PMSTA12879-111012 with sybase 15, only space is not accepted as password    */
#define DBA_SYNONYM_CODE_ALLOW  "#"     /* PMSTA-44466 - DDV - 210324 - Allow # only in synonym's code */

/* Number of attributes for each block of F&T */				/* DVP166 - 970114 - DED */
#define DBA_BPTYPE_NBRLINESBLOCK    (ExtOp_Bp2TpId - ExtOp_Bp1TpId)		/* BUG418 - 970704 - GRD+PEN */

/* PMSTA-18393 - LJE - 140717 */
#define FWD_CASH_LEG 0

/***************************
** Macros GET_*
** return pointer on string for string fields or value for numeric fields
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#ifdef AAATRACEDYNFLD /* REF8844 - LJE - 030818 */
#define AAACHECKDYNFLD true
extern void    DICT_TestDynfld(DBA_DYNFLD_STP dynStp, int fldIdx, unsigned char accessDataType);
extern void    DICT_TestDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM); /* REF8712 - LJE - 031017 */
#else
#define AAACHECKDYNFLD EV_GenDdlContext.bCheck
#endif

extern void   *DICT_GetDynfld(DBA_DYNFLD_STP, int, unsigned char, FLAG_T);
extern bool     DICT_IsNullFld(DBA_DYNFLD_STP, int);

/* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define _GET_AMOUNT(p,f)        (*static_cast<AMOUNT_T*>    (DICT_GetDynfld(p,f,AmountType, TRUE)))
#define _GET_CODE(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,CodeType, TRUE)))
#define _GET_DATE(p,f)           ((*static_cast<DATETIME64_ST*> (DICT_GetDynfld(p,f,DateType, TRUE))).date())
#define _GET_DATETIME(p,f)       ((*static_cast<DATETIME64_ST*>  (DICT_GetDynfld(p,f,DatetimeType, TRUE))).dateTime())
#define _GET_ENUM(p,f)          (*static_cast<ENUM_T*>      (DICT_GetDynfld(p,f,EnumType, TRUE)))
#define _GET_EXCHANGE(p,f)      (*static_cast<EXCHANGE_T*>  (DICT_GetDynfld(p,f,ExchangeType, TRUE)))
#define _GET_FLAG(p,f)          (*static_cast<FLAG_T*>      (DICT_GetDynfld(p,f,FlagType, TRUE)))
#define _GET_ID(p,f)            (*static_cast<ID_T*>        (DICT_GetDynfld(p,f,IdType, TRUE)))
#define _GET_DICT(p,f)          (*static_cast<DICT_T*>      (DICT_GetDynfld(p,f,DictType, TRUE)))
#define _GET_INFO(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,InfoType, TRUE)))
#define _GET_INT(p,f)           (*static_cast<INT_T*>       (DICT_GetDynfld(p,f,IntType, TRUE)))
#define _GET_LONGAMOUNT(p,f)    (*static_cast<LONGAMOUNT_T*>(DICT_GetDynfld(p,f,LongamountType, TRUE)))
#define _GET_MASK(p,f)          (*static_cast<MASK_T*>      (DICT_GetDynfld(p,f,MaskType, TRUE)))
#define _GET_METHOD(p,f)        (*static_cast<METHOD_T*>    (DICT_GetDynfld(p,f,MethodType, TRUE)))
#define _GET_NAME(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,NameType, TRUE)))
#define _GET_NOTE(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,NoteType, TRUE)))
#define _GET_NUMBER(p,f)        (*static_cast<NUMBER_T*>    (DICT_GetDynfld(p,f,NumberType, TRUE)))
#define _GET_PERCENT(p,f)       (*static_cast<PERCENT_T*>   (DICT_GetDynfld(p,f,PercentType, TRUE)))
#define _GET_PERIOD(p,f)        (*static_cast<PERIOD_T*>    (DICT_GetDynfld(p,f,PeriodType, TRUE)))
#define _GET_PHONE(p,f)         (*static_cast<char**>       (DICT_GetDynfld(p,f,PhoneType, TRUE)))
#define _GET_PRICE(p,f)         (*static_cast<PRICE_T*>     (DICT_GetDynfld(p,f,PriceType, TRUE)))
#define _GET_SHORTINFO(p,f)     (*static_cast<char**>       (DICT_GetDynfld(p,f,ShortinfoType, TRUE)))
#define _GET_SMALLINT(p,f)      (*static_cast<SMALLINT_T*>  (DICT_GetDynfld(p,f,SmallintType, TRUE)))
#define _GET_SYSNAME(p,f)       (*static_cast<char**>       (DICT_GetDynfld(p,f,SysnameType, TRUE)))
#define _GET_LONGSYSNAME(p,f)   (*static_cast<char**>       (DICT_GetDynfld(p,f,LongSysnameType, TRUE)))   /* PMSTA-14086 - LJE - 121008 */
#define _GET_TEXT(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,TextType, TRUE)))
#define _GET_TIME(p,f)          (*static_cast<TIME_T*>      (DICT_GetDynfld(p,f,TimeType, TRUE)))
#define _GET_TINYINT(p,f)       (*static_cast<TINYINT_T*>   (DICT_GetDynfld(p,f,TinyintType, TRUE)))
#define _GET_LONGINT(p,f)       (*static_cast<LONGINT_T*>   (DICT_GetDynfld(p,f,LongintType, TRUE)))       /* PMSTA-20887 - LJE - 150909 */
#define _GET_YEAR(p,f)          (*static_cast<YEAR_T*>      (DICT_GetDynfld(p,f,YearType, TRUE)))
#define _GET_LONGSTRING(p,f)    (*static_cast<char**>       (DICT_GetDynfld(p,f,LongStringType, TRUE)))
#define _GET_URL(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,UrlType, TRUE)))
#define _GET_PTR(p,f)           (*static_cast<PTR*>         (DICT_GetDynfld(p,f,PtrType, TRUE)))           /*  FIH-REF8712-031009  */

#define _GET_UCODE(p,f)          (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniCodeType, TRUE)))
#define _GET_UINFO(p,f)          (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniInfoType, TRUE)))
#define _GET_UNAME(p,f)          (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniNameType, TRUE)))
#define _GET_UNOTE(p,f)          (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniNoteType, TRUE)))
#define _GET_UPHONE(p,f)         (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniPhoneType, TRUE)))
#define _GET_USHORTINFO(p,f)     (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniShortinfoType, TRUE)))
#define _GET_USYSNAME(p,f)       (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniSysnameType, TRUE)))
#define _GET_UTEXT(p,f)          (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniTextType, TRUE)))
#define _GET_UURL(p,f)           (*static_cast<UChar**>     (DICT_GetDynfld(p,f,UniUrlType, TRUE)))

 /* REF9303 - LJE - 030905 */
#define _GET_VINFO_ASCII(p,f)     DBA_GetVarStringASCII(p,f)
#define _GET_VNOTE_ASCII(p,f)     DBA_GetVarStringASCII(p,f)
#define _GET_VNAME_ASCII(p,f)     DBA_GetVarStringASCII(p,f)

/* REF11780 - 100406 - PMO */
#define _GET_TIMESTAMP(p,f)      (*static_cast<TIMESTAMP_T*>(DICT_GetDynfld(p,f,TimeStampType, TRUE)))

/* PMSTA13460 - TGU - 120420 */
#define GET_MASK64(p,f)         (*static_cast<ENUMMASK_T*>  (DICT_GetDynfld(p,f, EnumMaskType, FALSE)))
#define _GET_MASK64(p,f)        (*static_cast<ENUMMASK_T*>  (DICT_GetDynfld(p,f, EnumMaskType, TRUE)))
#define GET_MASK64_BIT(p,f,n)   GET_BIT64(GET_MASK64(p,f), n)
#define GET_BIT64(b,n)          (((b>>n)& BIT64_ONE)==0?FALSE:TRUE)

/* DLA - PMSTA05995 - 080410 */
#define _GET_BINARY(p,f)         (*static_cast<BINARY_T*>   (DICT_GetDynfld(p,f,BinaryType, 1)))

#define _GET_VARSTRING1000(p,f)  DBA_GetVarStringASCII(p,f) /*  DLA - PMSTA07121 - 081212 */
#define _GET_VARSTRING2000(p,f)  DBA_GetVarStringASCII(p,f)
#define _GET_VARSTRING3000(p,f)  DBA_GetVarStringASCII(p,f)
#define _GET_VARSTRING4000(p,f)  DBA_GetVarStringASCII(p,f)
#define _GET_VARSTRING7000(p,f)  DBA_GetVarStringASCII(p,f)
#define _GET_VARSTRING15000(p,f) DBA_GetVarStringASCII(p,f)

#define _GET_TZOFFSET(p,f)      (*static_cast<TZ_OFFSET_T*> (DICT_GetDynfld(p,f,TzOffsetType, TRUE)))  /* PMSTA-30818 - DLA - 180403 */

#define GET_AMOUNT(p,f)         (*static_cast<AMOUNT_T*>    (DICT_GetDynfld(p,f,AmountType, FALSE)))
#define GET_CODE(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,CodeType, FALSE)))
#define GET_DATE(p,f)           ((*static_cast<DATETIME64_ST*> (DICT_GetDynfld(p,f,DateType, FALSE))).date())
#define GET_DATETIME(p,f)       ((*static_cast<DATETIME64_ST*>  (DICT_GetDynfld(p,f,DatetimeType, FALSE))).dateTime())
#define GET_ENUM(p,f)           (*static_cast<ENUM_T*>      (DICT_GetDynfld(p,f,EnumType, FALSE)))
#define GET_EXCHANGE(p,f)       (*static_cast<EXCHANGE_T*>  (DICT_GetDynfld(p,f,ExchangeType, FALSE)))
#define GET_FLAG(p,f)           (*static_cast<FLAG_T*>      (DICT_GetDynfld(p,f,FlagType, FALSE)))
#define GET_ID(p,f)             (*static_cast<ID_T*>        (DICT_GetDynfld(p,f,IdType, FALSE)))
#define GET_DICT(p,f)           (*static_cast<DICT_T*>      (DICT_GetDynfld(p,f,DictType, FALSE)))
#define GET_INFO(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,InfoType, FALSE)))
#define GET_LONGAMOUNT(p,f)     (*static_cast<LONGAMOUNT_T*>(DICT_GetDynfld(p,f,LongamountType, FALSE)))
#define GET_MASK(p,f)           (*static_cast<MASK_T*>      (DICT_GetDynfld(p,f,MaskType, FALSE)))
#define GET_METHOD(p,f)         (*static_cast<METHOD_T*>    (DICT_GetDynfld(p,f,MethodType, FALSE)))
#define GET_NAME(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,NameType, FALSE)))
#define GET_NOTE(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,NoteType, FALSE)))
#define GET_NUMBER(p,f)         (*static_cast<NUMBER_T*>    (DICT_GetDynfld(p,f,NumberType, FALSE)))
#define GET_PERCENT(p,f)        (*static_cast<PERCENT_T*>   (DICT_GetDynfld(p,f,PercentType, FALSE)))
#define GET_PERIOD(p,f)         (*static_cast<PERIOD_T*>    (DICT_GetDynfld(p,f,PeriodType, FALSE)))
#define GET_PHONE(p,f)          (*static_cast<char**>       (DICT_GetDynfld(p,f,PhoneType, FALSE)))
#define GET_PRICE(p,f)          (*static_cast<PRICE_T*>     (DICT_GetDynfld(p,f,PriceType, FALSE)))
#define GET_SHORTINFO(p,f)      (*static_cast<char**>       (DICT_GetDynfld(p,f,ShortinfoType, FALSE)))
#define GET_SMALLINT(p,f)       (*static_cast<SMALLINT_T*>  (DICT_GetDynfld(p,f,SmallintType, FALSE)))
#define GET_SYSNAME(p,f)        (*static_cast<char**>       (DICT_GetDynfld(p,f,SysnameType, FALSE)))
#define GET_LONGSYSNAME(p,f)    (*static_cast<char**>       (DICT_GetDynfld(p,f,LongSysnameType, FALSE)))   /* PMSTA-14086 - LJE - 121008 */
#define GET_TEXT(p,f)           (*static_cast<char**>       (DICT_GetDynfld(p,f,TextType, FALSE)))
#define GET_TIME(p,f)           (*static_cast<TIME_T*>      (DICT_GetDynfld(p,f,TimeType, FALSE)))
#define GET_TINYINT(p,f)        (*static_cast<TINYINT_T*>   (DICT_GetDynfld(p,f,TinyintType, FALSE)))
#define GET_LONGINT(p,f)        (*static_cast<LONGINT_T*>   (DICT_GetDynfld(p,f,LongintType, FALSE)))       /* PMSTA-20887 - LJE - 150909 */
#define GET_YEAR(p,f)           (*static_cast<YEAR_T*>      (DICT_GetDynfld(p,f,YearType, FALSE)))
#define GET_LONGSTRING(p,f)     (*static_cast<char**>       (DICT_GetDynfld(p,f,LongStringType, FALSE)))
#define GET_URL(p,f)            (*static_cast<char**>       (DICT_GetDynfld(p,f,UrlType, FALSE)))
#define GET_PTR(p,f)            (*static_cast<PTR*>         (DICT_GetDynfld(p,f,PtrType, FALSE)))           /*  FIH-REF8712-031009  */

#define GET_UCODE(p,f)          (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniCodeType, FALSE)))
#define GET_UINFO(p,f)          (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniInfoType, FALSE)))
#define GET_UNAME(p,f)          (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniNameType, FALSE)))
#define GET_UNOTE(p,f)          (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniNoteType, FALSE)))
#define GET_UPHONE(p,f)         (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniPhoneType, FALSE)))
#define GET_USHORTINFO(p,f)     (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniShortinfoType, FALSE)))
#define GET_USYSNAME(p,f)       (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniSysnameType, FALSE)))
#define GET_UTEXT(p,f)          (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniTextType, FALSE)))
#define GET_UURL(p,f)           (*static_cast<UChar**>      (DICT_GetDynfld(p,f,UniUrlType, FALSE)))

 /* REF9303 - LJE - 030905 */
#define GET_VINFO_ASCII(p,f)     DBA_GetVarStringASCII(p,f)
#define GET_VNOTE_ASCII(p,f)     DBA_GetVarStringASCII(p,f)
#define GET_VNAME_ASCII(p,f)     DBA_GetVarStringASCII(p,f)


/* REF11780 - 100406 - PMO */
#define GET_TIMESTAMP(p,f)      (*static_cast<TIMESTAMP_T*> (DICT_GetDynfld(p,f,TimeStampType, FALSE)))

/* DLA - PMSTA05995 - 080410 */
#define GET_BINARY(p,f)         (*static_cast<BINARY_T*>    (DICT_GetDynfld(p,f,BinaryType, FALSE)))

#define GET_VARSTRING1000(p,f)  DBA_GetVarStringASCII(p,f) /*  DLA - PMSTA07121 - 081212 */
#define GET_VARSTRING2000(p,f)  DBA_GetVarStringASCII(p,f)
#define GET_VARSTRING3000(p,f)  DBA_GetVarStringASCII(p,f)
#define GET_VARSTRING4000(p,f)  DBA_GetVarStringASCII(p,f)
#define GET_VARSTRING7000(p,f)  DBA_GetVarStringASCII(p,f)
#define GET_VARSTRING15000(p,f) DBA_GetVarStringASCII(p,f)

#define GET_VINFO_DEFAULT(p,f)  DBA_SetFldToDefaultCharSet(p, f) /* PMSTA-27969 - CMILOS - 290817 */

#define GET_TZOFFSET(p,f)       (*static_cast<TZ_OFFSET_T*>(DICT_GetDynfld(p,f,TzOffsetType, FALSE)))  /* PMSTA-30818 - DLA - 180403 */



/***************************
** Macro TIME_DATETIME
** Extract time from datetime structure
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
***************************/
#define TIME_DATETIME(p,f)      TIME_DATETIMEST((p),(f))

/***************************
** Macro DATE_DATETIME
** Extract date from datetime structure
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
***************************/
#define DATE_DATETIME(p,f)      DATE_DATETIMEST((p),(f))

/***************************
** Macro DATETIME_CMP
** return -1 if first datetime is lower than second datetime
** return  0 if two datetimes are same
** return +1 if first datetime is upper than second datetime
** d1 = first datetime
** d2 = second datetime
***************************/
#define DATETIME_CMP(d1,d2) (((d1).date<(d2).date)?-1:((d1).date>(d2).date)?1:\
                 ((d1).time<(d2).time)?-1:((d1).time>(d2).time)?1:0)

/* + comparaison entre date et datetime ?? */

/***************************
** Macro GET_FLDPTR
** return pointer on data for all fields
** s = DBA_DYNST_ENUM
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_FLDPTR(s,p,f)   (   \
    (IS_STRINGFLD(s,f)==TRUE)?(PTR)p[f].data.strData.ptr:   \
    (IS_USTRINGFLD(s,f)==TRUE)?(PTR)p[f].data.ustrData.ptr: \
    (PTR)(&p[f].data.dbleValue))

/***************************
** Macro GET_FLDPTR_BY_DTP
** return pointer on data for all fields
** d = DATATYPE_ENUM
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_FLDPTR_BY_DTP(d,p,f)    (   \
    (GET_CTYPE(d)==CharPtrCType)?(PTR)p[f].data.strData.ptr:    \
    (GET_CTYPE(d)==TextPtrCType)?(PTR)p[f].data.strData.ptr:    \
    (GET_CTYPE(d)==UniCharPtrCType)?(PTR)p[f].data.ustrData.ptr:    \
    (GET_CTYPE(d)==UniTextPtrCType)?(PTR)p[f].data.ustrData.ptr:    \
    (GET_CTYPE(d)==DateTimeStCType)?(PTR)&(p[f].data.datetime64St):    \
    (PTR)&(p[f].data.dbleValue))	/* REF4204 */ /* PMSTA-42593 - DPT - 210218 */

/***************************
** Macro GET_DYNFLDSTP
** return pointer on dynamic structure
** o = origin pointer on dynamic structure (DBA_DYNFLD_STP)
** p = position in array
** s = size of one record
***************************/
#define GET_DYNFLDSTP(o,p,s) (&o[p*s])

#define DATATYPE_DICT_TO_ENUM(i) (static_cast<DATATYPE_ENUM>(i-1))
#define DATATYPE_ENUM_TO_DICT(e) ((static_cast<DICT_T>(e)+1))

/***************************
** Macros SET_*
** update field value and signal that data is not NULL
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
** s = source value (pointer for strings, value elsewhere)
***************************/

/* REF11780 - 100406 - PMO */
extern void DBA_SetTimeStamp(DBA_DYNFLD_STP, const int, const TIMESTAMP_T);

/* DLA - PMSTA05995 - 080410 */
extern void DBA_SetBinary(DBA_DYNFLD_STP, const int, const BINARY_T);
extern void SET_LONGLONG(const DBA_DYNFLD_STP, const FIELD_IDX_T &, const ID_T &);          /* PMSTA-32291 - 130818 - PMO */
extern int  fun_SET_STRING(DBA_DYNFLD_STP, int, const char*);                               /* PMSTA-32291 - 130818 - PMO */
extern int _fun_SET_STRING(DBA_DYNFLD_STP, int, const char*);                               /* PMSTA-32291 - 130818 - PMO */

#define  SET_STRING(p,f,s)  fun_SET_STRING(p,f,s)       /* PMSTA-16443 - 230713 - PMO */
#define SET_USTRING(p,f,s)  fun_SET_USTRING(p,f,s)      /* PMSTA-16443 - 230713 - PMO */
#define  _SET_STRING(p,f,s) _fun_SET_STRING(p,f,s)      /* PMSTA-16443 - 230713 - PMO / PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_USTRING(p,f,s) _fun_SET_USTRING(p,f,s)     /* PMSTA-16443 - 230713 - PMO / PMSTA13244 - DDV - 120123 - Trace DynFld usage */


#ifdef AAATRACEDYNFLD

#define SET_AMOUNT(p,f,s)        {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,AmountType);}
#define SET_CODE(p,f,s)          SET_STRING(p,f,s);DICT_TestDynfld(p,f,CodeType);                               /* no {} to allow memory the check */
#define SET_DATE(p,f,s)          {SET_DATEONLY(p,f,s); SET_TIMEONLY(p,f,0); DICT_TestDynfld(p,f,DateType);}     /* PMSTA-15918 - 070213 - PMO */
#define SET_DATETIME(p,f,s)      {SET_DATETIMEST(p,f,s);DICT_TestDynfld(p,f,DatetimeType);}
inline void SET_DICT(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const ID_T & value) {SET_LONGLONG(p,field,value);DICT_TestDynfld(p,field,DictType);}    /* PMSTA-32291 - 130818 - PMO / PMSTA08801 - DDV - 091126 */
#define SET_ENUM(p,f,s)          {SET_UCHAR(p,f,s);DICT_TestDynfld(p,f,EnumType);}
#define SET_EXCHANGE(p,f,s)      {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,ExchangeType);}
#define SET_FLAG(p,f,s)          {SET_UCHAR(p,f,(s?TRUE:FALSE));DICT_TestDynfld(p,f,FlagType);}
#define SET_FLAG_FALSE(p,f)      {SET_UCHAR(p,f,FALSE);DICT_TestDynfld(p,f,FlagType);}
#define SET_FLAG_TRUE(p,f)       {SET_UCHAR(p,f,TRUE);DICT_TestDynfld(p,f,FlagType);}

#define SET_ID(p,f,s)            {if (s==0) {SET_NULL_LONGLONG(p,f);}\
                                  else {SET_LONGLONG(p,f,s);};DICT_TestDynfld(p,f,IdType);} /* PMSTA08801 - DDV - 091126 */

#define SET_INFO(p,f,s)          {SET_STRING(p,f,s);DICT_TestDynfld(p,f,InfoType);}
#define SET_LONGAMOUNT(p,f,s)    {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,LongamountType);}
#define SET_MASK(p,f,s)          {SET_INT(p,f,s);DICT_TestDynfld(p,f,MaskType);}
#define SET_METHOD(p,f,s)        {SET_UCHAR(p,f,s);DICT_TestDynfld(p,f,MethodType);}
inline void SET_NAME(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const char * value) {SET_STRING(p,field,value);DICT_TestDynfld(p,field,NameType);}      /* PMSTA-32291 - 130818 - PMO */
#define SET_NOTE(p,f,s)          {SET_STRING(p,f,s);DICT_TestDynfld(p,f,NoteType);}
#define SET_NUMBER(p,f,s)        {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,NumberType);}
#define SET_PERCENT(p,f,s)       {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,PercentType);}
#define SET_PERIOD(p,f,s)        {SET_SHORT(p,f,s);DICT_TestDynfld(p,f,PeriodType);}
#define SET_PHONE(p,f,s)         {SET_STRING(p,f,s);DICT_TestDynfld(p,f,PhoneType);}
#define SET_PRICE(p,f,s)         {SET_DOUBLE(p,f,s);DICT_TestDynfld(p,f,PriceType);}
#define SET_SHORTINFO(p,f,s)     {SET_STRING(p,f,s);DICT_TestDynfld(p,f,ShortinfoType);}
#define SET_SMALLINT(p,f,s)      {SET_SHORT(p,f,s);DICT_TestDynfld(p,f,SmallintType);}
#define SET_SYSNAME(p,f,s)       {SET_STRING(p,f,s);DICT_TestDynfld(p,f,SysnameType);}
#define SET_LONGSYSNAME(p,f,s)   {SET_STRING(p,f,s);DICT_TestDynfld(p,f,LongSysnameType);} /* PMSTA-14086 - LJE - 121008 */
#define SET_TEXT(p,f,s)          {SET_STRING(p,f,s);DICT_TestDynfld(p,f,TextType);}
#define SET_TIME(p,f,s)          {SET_TIMEONLY(p,f,s);DICT_TestDynfld(p,f,TimeType);}                           /* PMSTA-15918 - 070213 - PMO */
#define SET_TINYINT(p,f,s)       {SET_UCHAR(p,f,s);DICT_TestDynfld(p,f,TinyintType);}
#define SET_LONGINT(p,f,s)       {SET_LONGLONG(p,f,s);DICT_TestDynfld(p,f,LongintType);} /* PMSTA-20887 - LJE - 150909 */
#define SET_YEAR(p,f,s)          {SET_USHORT(p,f,s);DICT_TestDynfld(p,f,YearType);}
#define SET_LONGSTRING(p,f,s)    {SET_STRING(p,f,s);DICT_TestDynfld(p,f,LongStringType);}			/* REF1229 */
#define SET_URL(p,f,s)           {SET_STRING(p,f,s);DICT_TestDynfld(p,f,UrlType);}
#define SET_PTR(p,f,s)           {SET_POINTER(p,f,s);DICT_TestDynfld(p,f,PtrType);}                 /*  FIH-REF8712-031009  */
#define SET_TZOFFSET(p,f,s)      {SET_SHORT(p,f,s);DICT_TestDynfld(p,f,TzOffsetType);}       /* PMSTA-30818 - DLA - 180403 */
#define SET_UCODE(p,f,s)         {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniCodeType);}
#define SET_UINFO(p,f,s)         {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniInfoType);}
#define SET_UNAME(p,f,s)         {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniNameType);}
#define SET_UNOTE(p,f,s)         {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniNoteType);}
#define SET_UPHONE(p,f,s)        {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniPhoneType);}
#define SET_USHORTINFO(p,f,s)    {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniShortinfoType);}
#define SET_USYSNAME(p,f,s)      {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniSysnameType);}
#define SET_UTEXT(p,f,s)         {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniTextType);}
#define SET_UURL(p,f,s)          {SET_USTRING(p,f,s);DICT_TestDynfld(p,f,UniUrlType);}

/* REF9303 - LJE - 030903 */
#define SET_VINFO_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)
#define SET_VNOTE_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)
#define SET_VNAME_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)


/* REF11780 - 100406 - PMO */
#define SET_TIMESTAMP(p,f,s)    {DBA_SetTimeStamp(p,f,s);DICT_TestDynfld(p,f,TimeStampType);}

/* DLA - PMSTA05995 - 080410 */
#define SET_BINARY(p,f,s)    {DBA_SetBinary(p,f,s);DICT_TestDynfld(p,f,BinaryType);}

/* PMSTA13460 - TGU - 120420 */
#define SET_MASK64(p,f,s) {SET_LONGLONG (p,f,s);DICT_TestDynfld(p,f,EnumMaskType);}
#define SET_BIT64(b,n,s) {b= s? b|(BIT64_ONE <<n): b&(~(BIT64_ONE <<n));}
#define SET_MASK64_BIT(p,f,n,s) { INT64_T  m;\
                                     m=GET_MASK64(p,f);\
                                     SET_BIT64(m,n,s);\
                                     SET_MASK64(p,f,m);}

/*  DLA - PMSTA07121 - 081212 */
#define SET_VARSTRING1000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING2000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING3000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING4000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING7000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING15000(p,f,s) DBA_SetVarStringASCII(p,f,s)

#else

#define SET_AMOUNT(p,f,s)        SET_DOUBLE(p,f,s)
#define SET_CODE(p,f,s)          SET_STRING(p,f,s)
#define SET_DATE(p,f,s)          {SET_DATEONLY(p,f,s); SET_TIMEONLY(p,f,0);}        /* PMSTA-15918 - 070213 - PMO */
#define SET_DATETIME(p,f,s)      SET_DATETIMEST(p,f,s)
#define SET_DICT(p,f,s)          SET_LONGLONG(p,f,s)    /* DLA - REF9089 - 030513 */ /* PMSTA08801 - DDV - 091126 */
#define SET_ENUM(p,f,s)          SET_UCHAR(p,f,s)
#define SET_EXCHANGE(p,f,s)      SET_DOUBLE(p,f,s)
#define SET_FLAG(p,f,s)          {switch(s) {\
                                  case FALSE : SET_UCHAR(p,f,FALSE);break;\
                                  case TRUE :\
                                  default: SET_UCHAR(p,f,TRUE);\
                                  }\
                                 }
#define SET_FLAG_FALSE(p,f) SET_UCHAR(p,f,FALSE) /* SME */
#define SET_FLAG_TRUE(p,f)  SET_UCHAR(p,f,TRUE)	/* SME */

/*
#define SET_FLAG(p,f,s)          {if (s==FALSE) {SET_UCHAR(p,f,FALSE);}\
                  else {SET_UCHAR(p,f,TRUE);}}
*/

/* --------------------- */
/* BUG082 - RAK - 960807 */
#define SET_ID(p,f,s)            {if (s==0) {SET_NULL_LONGLONG(p,f);}\
                  else {SET_LONGLONG(p,f,s);}} /* PMSTA08801 - DDV - 091126 */
/* --------------------- */
#define SET_INFO(p,f,s)          SET_STRING(p,f,s)
#define SET_LONGAMOUNT(p,f,s)    SET_DOUBLE(p,f,s)			/* DVP041 - 960429 - DED */
#define SET_MASK(p,f,s)          SET_INT(p,f,s)
#define SET_MASK64(p,f,s)        SET_LONGLONG(p,f,s)	/* PMSTA13460 - TGU - 120424 */
#define SET_METHOD(p,f,s)        SET_UCHAR(p,f,s)
#define SET_NAME(p,f,s)          SET_STRING(p,f,s)
#define SET_NOTE(p,f,s)          SET_STRING(p,f,s)
#define SET_NUMBER(p,f,s)        SET_DOUBLE(p,f,s)
#define SET_PERCENT(p,f,s)       SET_DOUBLE(p,f,s)
#define SET_PRICE(p,f,s)         SET_DOUBLE(p,f,s)
#define SET_PERIOD(p,f,s)        SET_SHORT(p,f,s)
#define SET_PHONE(p,f,s)         SET_STRING(p,f,s)
#define SET_SHORTINFO(p,f,s)     SET_STRING(p,f,s)
#define SET_SMALLINT(p,f,s)      SET_SHORT(p,f,s)
#define SET_SYSNAME(p,f,s)       SET_STRING(p,f,s)
#define SET_LONGSYSNAME(p,f,s)   SET_STRING(p,f,s) /* PMSTA-14086 - LJE - 121008 */
#define SET_TEXT(p,f,s)          SET_STRING(p,f,s)
#define SET_TIME(p,f,s)          SET_TIMEONLY(p,f,s);       /* PMSTA-15918 - 070213 - PMO */
#define SET_TINYINT(p,f,s)       SET_UCHAR(p,f,s)
#define SET_LONGINT(p,f,s)       SET_LONGLONG(p,f,s)  /* PMSTA-20887 - LJE - 151006 */
#define SET_YEAR(p,f,s)          SET_USHORT(p,f,s)
#define SET_LONGSTRING(p,f,s)    SET_STRING(p,f,s)			/* REF1229 */
#define SET_URL(p,f,s)           SET_STRING(p,f,s)
#define SET_PTR(p,f,s)           SET_POINTER(p,f,s)         /*  FIH-REF8712-031009  */
#define SET_TZOFFSET(p,f,s)      SET_SHORT(p,f,s)           /* PMSTA-30818 - DLA - 180403 */
#define SET_UCODE(p,f,s)         SET_USTRING(p,f,s)
#define SET_UINFO(p,f,s)         SET_USTRING(p,f,s)
#define SET_UNAME(p,f,s)         SET_USTRING(p,f,s)
#define SET_UNOTE(p,f,s)         SET_USTRING(p,f,s)
#define SET_UPHONE(p,f,s)        SET_USTRING(p,f,s)
#define SET_USHORTINFO(p,f,s)    SET_USTRING(p,f,s)
#define SET_USYSNAME(p,f,s)      SET_USTRING(p,f,s)
#define SET_UTEXT(p,f,s)         SET_USTRING(p,f,s)
#define SET_UURL(p,f,s)          SET_USTRING(p,f,s)

/* REF9303 - LJE - 030903 */
#define SET_VINFO_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)
#define SET_VNOTE_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)
#define SET_VNAME_ASCII(p,f,s)     DBA_SetVarStringASCII(p,f,s)

/* REF11780 - 100406 - PMO */
#define SET_TIMESTAMP DBA_SetTimeStamp

/* DLA - PMSTA05995 - 080410 */
#define SET_BINARY DBA_SetBinary

/*  DLA - PMSTA07121 - 081212 */
#define SET_VARSTRING1000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING2000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING3000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING4000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING7000(p,f,s)  DBA_SetVarStringASCII(p,f,s)
#define SET_VARSTRING15000(p,f,s) DBA_SetVarStringASCII(p,f,s)


/* PMSTA-40209 - LIK - 25082020 */
#define SET_BIT64(b,n,s) {b= s? b|(BIT64_ONE <<n): b&(~(BIT64_ONE <<n));}
#define SET_MASK64_BIT(p,f,n,s) { INT64_T  m;\
                                     m=GET_MASK64(p,f);\
                                     SET_BIT64(m,n,s);\
                                     SET_MASK64(p,f,m);}

#endif
/* #define SET_CUST_FLD(p,o,n,v)  set_cust(p,o,n,v) */

/***************************
** Macro SET_NULL_*
** update field value to 0 (EOS for string) and signal that data is NULL
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define SET_NULL_AMOUNT(p,f)        SET_NULL_DOUBLE(p,f)
#define SET_NULL_CODE(p,f)          SET_NULL_STRING(p,f)
#define SET_NULL_DATE(p,f)          SET_NULL_DATETIMEST(p,f)                /* PMSTA-15918 - 070213 - PMO */
#define SET_NULL_DATETIME(p,f)      SET_NULL_DATETIMEST(p,f)
#define SET_NULL_DICT(p,f)          SET_NULL_LONGLONG(p,f) /* DLA - REF9089 - 030815 */
#define SET_NULL_ENUM(p,f)          SET_NULL_UCHAR(p,f)
#define SET_NULL_EXCHANGE(p,f)      SET_NULL_DOUBLE(p,f)
#define SET_NULL_ID(p,f)            SET_NULL_LONGLONG(p,f)  /* DLA - REF9089 - 030815 */
#define SET_NULL_INFO(p,f)          SET_NULL_STRING(p,f)
#define SET_NULL_LONGAMOUNT(p,f)    SET_NULL_DOUBLE(p,f)			/* DVP041 - 960429 - DED */
#define SET_NULL_MASK(p,f)          SET_NULL_INT(p,f)
#define SET_NULL_METHOD(p,f)        SET_NULL_UCHAR(p,f)
#define SET_NULL_NAME(p,f)          SET_NULL_STRING(p,f)
#define SET_NULL_NOTE(p,f)          SET_NULL_STRING(p,f)
#define SET_NULL_NUMBER(p,f)        SET_NULL_DOUBLE(p,f)
#define SET_NULL_PERCENT(p,f)       SET_NULL_DOUBLE(p,f)
#define SET_NULL_PERIOD(p,f)        SET_NULL_SHORT(p,f)
#define SET_NULL_PHONE(p,f)         SET_NULL_STRING(p,f)
#define SET_NULL_PRICE(p,f)         SET_NULL_DOUBLE(p,f)
#define SET_NULL_SHORTINFO(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_SMALLINT(p,f)      SET_NULL_SHORT(p,f)
#define SET_NULL_SYSNAME(p,f)       SET_NULL_STRING(p,f)
#define SET_NULL_LONGSYSNAME(p,f)   SET_NULL_STRING(p,f) /* PMSTA-14086 - LJE - 121008 */
#define SET_NULL_TEXT(p,f)          SET_NULL_STRING(p,f)
#define SET_NULL_TIME(p,f)          SET_NULL_DATETIMEST(p,f)                /* PMSTA-15918 - 070213 - PMO */
#define SET_NULL_TINYINT(p,f)       SET_NULL_UCHAR(p,f)
#define SET_NULL_LONGINT(p,f)       SET_NULL_LONGLONG(p,f)  /* PMSTA-20887 - LJE - 150909 */
#define SET_NULL_YEAR(p,f)          SET_NULL_USHORT(p,f)
#define SET_NULL_LONGSTRING(p,f)    SET_NULL_STRING(p,f)			/* REF1229 */
#define SET_NULL_URL(p,f)           SET_NULL_STRING(p,f)
#define SET_NULL_MASK64(p,f)        SET_NULL_LONGLONG(p,f)			/* PMSTA13460 - TGU - 120420 */
#define SET_NULL_TZOFFSET(p,f)      SET_NULL_SHORT(p,f)		/* PMSTA-30818 - DLA - 180403 */

#define SET_NULL_UCODE(p,f)         SET_NULL_USTRING(p,f)
#define SET_NULL_UINFO(p,f)         SET_NULL_USTRING(p,f)
#define SET_NULL_UNAME(p,f)         SET_NULL_USTRING(p,f)
#define SET_NULL_UNOTE(p,f)         SET_NULL_USTRING(p,f)
#define SET_NULL_UPHONE(p,f)        SET_NULL_USTRING(p,f)
#define SET_NULL_USHORTINFO(p,f)    SET_NULL_USTRING(p,f)
#define SET_NULL_USYSNAME(p,f)      SET_NULL_USTRING(p,f)
#define SET_NULL_UTEXT(p,f)         SET_NULL_USTRING(p,f)
#define SET_NULL_UURL(p,f)          SET_NULL_USTRING(p,f)

/* REF9303 - LJE - 030902 */
#define SET_NULL_VINFO(p,f)         {if(p[f].dataType==InfoType)SET_NULL_STRING(p,f) else SET_NULL_USTRING(p,f)}

/* REF11780 - 100406 - PMO */
#define SET_NULL_TIMESTAMP DBA_SetNullTimeStamp
extern void DBA_SetNullTimeStamp(DBA_DYNFLD_STP, const int);


#define SET_NULL_BINARY DBA_SetNullBinary
extern void DBA_SetNullBinary(DBA_DYNFLD_STP, const int);

/*  DLA - PMSTA07121 - 081212 */
#define SET_NULL_STRING1000(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_STRING2000(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_STRING3000(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_STRING4000(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_STRING7000(p,f)     SET_NULL_STRING(p,f)
#define SET_NULL_STRING15000(p,f)    SET_NULL_STRING(p,f)
#define SET_NULL_UNISTRING1000(p,f)  SET_NULL_USTRING(p,f)
#define SET_NULL_UNISTRING2000(p,f)  SET_NULL_USTRING(p,f)
#define SET_NULL_UNISTRING3000(p,f)  SET_NULL_USTRING(p,f)
#define SET_NULL_UNISTRING4000(p,f)  SET_NULL_USTRING(p,f)
#define SET_NULL_UNISTRING7000(p,f)  SET_NULL_USTRING(p,f)
#define SET_NULL_UNISTRING15000(p,f) SET_NULL_USTRING(p,f)

extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const INT64_T &);            /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const UINT64_T &);           /* PMSTA-24564 - LJE - 161122 */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const int &);                /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const short &);              /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const unsigned char &);      /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const double &);             /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const char *);               /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const UChar *);              /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const DATE_T &);             /* PMSTA-18479 - 130814 - PMO */
extern bool DICT_SetDynfld(DBA_DYNFLD_STP, const FIELD_IDX_T, const DATATYPE_ENUM, const DATETIME64_ST &);      /* PMSTA-18479 - 130814 - PMO */


/***************************
**	Macros  SET_NULL
**	p = pointer on dynamic structure (DBA_DYNFLD_STP)
**	f = field number in dynamic structure
**	REF7758 - LJE - 021017
***************************/
#define SET_NULL(p,f,d)	{										    \
                                switch(d) {					        \
                                case CodeType :						\
                                    SET_NULL_CODE(p,f);				\
                                    break;							\
                                case DateType :						\
                                    SET_NULL_DATE(p,f);				\
                                    break;							\
                                case DatetimeType :					\
                                    SET_NULL_DATETIME(p,f);			\
                                    break;							\
                                case DictType :						\
                                    SET_NULL_DICT(p,f);				\
                                    break;							\
                                case EnumType :						\
                                    SET_NULL_ENUM(p,f);				\
                                    break;							\
                                case ExchangeType :					\
                                    SET_NULL_EXCHANGE(p,f);			\
                                    break;							\
                                case FlagType :						\
                                    SET_NULL_UCHAR(p,f);	        \
                                    break;							\
                                case IdType :						\
                                    SET_NULL_ID(p,f);				\
                                    break;							\
                                case InfoType :						\
                                    SET_NULL_INFO(p,f);				\
                                    break;							\
                                case IntType :						\
                                    SET_NULL_INT(p,f);				\
                                    break;							\
                                case MaskType :						\
                                    SET_NULL_MASK(p,f);				\
                                    break;							\
                                case EnumMaskType :					\
                                    SET_NULL_MASK64(p,f);			\
                                    break;							\
                                case MethodType :					\
                                    SET_NULL_METHOD(p,f);			\
                                    break;							\
                                case NameType :						\
                                    SET_NULL_NAME(p,f);				\
                                    break;							\
                                case NoteType :						\
                                    SET_NULL_NOTE(p,f);				\
                                    break;							\
                                case NumberType :					\
                                    SET_NULL_NUMBER(p,f);			\
                                    break;							\
                                case PercentType :					\
                                    SET_NULL_PERCENT(p,f);			\
                                    break;							\
                                case PeriodType :					\
                                    SET_NULL_PERIOD(p,f);			\
                                    break;							\
                                case PhoneType :					\
                                    SET_NULL_PHONE(p,f);			\
                                    break;							\
                                case PriceType :					\
                                    SET_NULL_PRICE(p,f);			\
                                    break;                          \
                                case SmallintType :					\
                                    SET_NULL_SMALLINT(p,f);			\
                                    break;							\
                                case SysnameType :					\
                                    SET_NULL_SYSNAME(p,f);			\
                                    break;							\
                                case LongSysnameType :			    \
                                    SET_NULL_LONGSYSNAME(p,f);	    \
                                    break;							\
                                case TextType :						\
                                    SET_NULL_TEXT(p,f);				\
                                    break;							\
                                case UrlType :						\
                                    SET_NULL_URL(p,f);				\
                                    break;							\
                                case TimeType :						\
                                    SET_NULL_TIME(p,f);				\
                                    break;							\
                                case TinyintType :					\
                                    SET_NULL_TINYINT(p,f);			\
                                    break;							\
								case LongintType :					\
									SET_NULL_LONGINT(p,f);			\
									break;							\
                                case YearType :						\
                                    SET_NULL_YEAR(p,f);				\
                                    break;							\
                                case AmountType :					\
                                    SET_NULL_AMOUNT(p,f);			\
                                    break;							\
                                case ShortinfoType :				\
                                    SET_NULL_SHORTINFO(p,f);		\
                                    break;							\
                                case LongamountType :				\
                                    SET_NULL_LONGAMOUNT(p,f);		\
                                    break;							\
                                case LongStringType :				\
                                    SET_NULL_LONGSTRING(p,f);		\
                                    break;							\
                                case PtrType :                      \
                                    SET_NULL_PTR(p,f);              \
                                    break;                          \
                                case UniCodeType :					\
                                    SET_NULL_UCODE(p,f);            \
                                    break;                          \
                                case UniInfoType :					\
                                    SET_NULL_UINFO(p,f);            \
                                    break;                          \
                                case UniNameType :					\
                                    SET_NULL_UNAME(p,f);            \
                                    break;                          \
                                case UniNoteType :					\
                                    SET_NULL_UNOTE(p,f);            \
                                    break;                          \
                                case UniPhoneType :					\
                                    SET_NULL_UPHONE(p,f);           \
                                    break;                          \
                                case UniShortinfoType :				\
                                    SET_NULL_USHORTINFO(p,f);       \
                                    break;                          \
                                case UniSysnameType :				\
                                    SET_NULL_USYSNAME(p,f);         \
                                    break;                          \
                                case UniTextType :					\
                                    SET_NULL_UTEXT(p,f);            \
                                    break;                          \
                                case UniUrlType :					\
                                    SET_NULL_UURL(p,f);             \
                                    break;                          \
                                case String1000Type:                \
                                    SET_NULL_STRING1000(p,f);       \
                                    break;                          \
                                case String2000Type:                \
                                    SET_NULL_STRING2000(p,f);       \
                                    break;                          \
                                case String3000Type:                \
                                    SET_NULL_STRING3000(p,f);       \
                                    break;                          \
                                case String4000Type:                \
                                    SET_NULL_STRING4000(p,f);       \
                                    break;                          \
                                case String7000Type:                \
                                    SET_NULL_STRING7000(p,f);       \
                                    break;                          \
                                case String15000Type:               \
                                    SET_NULL_STRING15000(p,f);      \
                                    break;                          \
                                case UniString1000Type:             \
                                    SET_NULL_UNISTRING1000(p,f);    \
                                    break;                          \
                                case UniString2000Type:             \
                                    SET_NULL_UNISTRING2000(p,f);    \
                                    break;                          \
                                case UniString3000Type:             \
                                    SET_NULL_UNISTRING3000(p,f);    \
                                    break;                          \
                                case UniString4000Type:             \
                                    SET_NULL_UNISTRING4000(p,f);    \
                                    break;                          \
                                case UniString7000Type:             \
                                    SET_NULL_UNISTRING7000(p,f);    \
                                    break;                          \
                                case UniString15000Type:            \
                                    SET_NULL_UNISTRING15000(p,f);   \
                                    break;                          \
                                case LastType: /* Compil warning */ \
                                    break;                          \
                                }									\
                            }

/***************************
**	Macros  SET_NULL_FLD
**	p = pointer on dynamic structure (DBA_DYNFLD_STP)
**	f = field number in dynamic structure
**	ROI - 990210 - REF2644
***************************/
#define SET_NULL_FLD(p,f)   SET_NULL(p,f,p[f].dataType)

/***************************
** Macros CAST_*
** d = double to cast
**
** i = currency identifier for CAST_AMOUNT()
**	REF3288 - SSO - 990205:  manage rounding issue
***************************/
#define CAST_AMOUNT(d,i)       FIN_Round(i, d, NULL)
#define CAST_EXCHANGE(d)       TLS_Round(d, TLS_GetNumericPrec(d, EXCHANGE_T_DEC, NULL), RndRule_Nearest) /* REF3288 - SSO - 990205 */
#define CAST_LONGAMOUNT(d,i)   FIN_Round(i, d, NULL) 				/* DVP041 - 960429 - DED */
/* REF10622 - TEB - 040921 */
/* Dont use new rounding method for CAST_NUMBER */
#define CAST_NUMBER(d)         TLS_Round2(d, TLS_GetNumericPrec(d, NUMBER_T_DEC, NULL), RndRule_Nearest, FALSE)  /* REF3288 - SSO - 990205 */
#define CAST_PERCENT(d)        TLS_Round(d, PERCENT_T_PREC,  RndRule_Nearest)
#define CAST_PRICE(d)          TLS_Round(d, TLS_GetNumericPrec(d, PRICE_T_DEC, NULL), RndRule_Nearest)

/* REF3722 - SSO - 000229 : truncate with max. precision (14 guaranted digits) */
#define CAST_MAXPREC(d)	       TLS_Round(d, TLS_GetNumericPrec(d, 14, NULL),   RndRule_Nearest)


/***************************
** Macros AAA_* (numeric operators for double)
** d1, d2 : double operands
**  dec: max # of digits after point (must be one of *_T_DEC)
**
**	REF3722 - SSO - 000211:  manage rounding issue
**	    digits which are not guaranted (14 digits, round off issues) are truncated
***************************/
#ifndef MAX
#define MAX(a,b)    (((a) > (b)) ? (a) : (b))     /* PMSTA-16124 - 250413 - PMO */
#endif

#define AAA_PLUS(d1, d2, dec) \
      TLS_Round(d1+d2, TLS_GetPrec( \
        MAX(MAX(TLS_GetPos1stDigit(d1), TLS_GetPos1stDigit(d2)), TLS_GetPos1stDigit(d1+d2)), dec), \
        RndRule_Nearest)

#define AAA_MINUS(d1, d2, dec) \
      TLS_Round(d1-d2, TLS_GetPrec( \
        MAX(MAX(TLS_GetPos1stDigit(d1), TLS_GetPos1stDigit(d2)), TLS_GetPos1stDigit(d1-d2)), dec), \
        RndRule_Nearest)

#define AAA_TIME(d1, d2, dec) \
      TLS_Round(d1*d2, TLS_GetPrec( \
        MAX(TLS_GetPos1stDigit(d1) + TLS_GetPos1stDigit(d2), TLS_GetPos1stDigit(d1*d2)), dec), \
        RndRule_Nearest)

#define AAA_DIV(d1, d2, dec) \
      TLS_Round(d1/d2, TLS_GetPrec( \
        MAX(TLS_GetPos1stDigit(d1) - TLS_GetPos1stDigit(d2) + 1, TLS_GetPos1stDigit(d1/d2)), dec), \
        RndRule_Nearest)

/* REF3722 - SSO - 000301: idem but with significant digits parameter */
#define AAA_PLUS_SD(d1, d2, dec, sd) \
      TLS_Round(d1+d2, TLS_GetPrecSignif( \
        MAX(MAX(TLS_GetPos1stDigit(d1), TLS_GetPos1stDigit(d2)), TLS_GetPos1stDigit(d1+d2)), dec, sd), \
        RndRule_Nearest)

#define AAA_MINUS_SD(d1, d2, dec, sd) \
      TLS_Round(d1-d2, TLS_GetPrecSignif( \
        MAX(MAX(TLS_GetPos1stDigit(d1), TLS_GetPos1stDigit(d2)), TLS_GetPos1stDigit(d1-d2)), dec, sd), \
        RndRule_Nearest)

#define AAA_TIME_SD(d1, d2, dec, sd) \
      TLS_Round(d1*d2, TLS_GetPrecSignif( \
        MAX(TLS_GetPos1stDigit(d1) + TLS_GetPos1stDigit(d2), TLS_GetPos1stDigit(d1*d2)), dec, sd), \
        RndRule_Nearest)

#define AAA_DIV_SD(d1, d2, dec, sd) \
      TLS_Round(d1/d2, TLS_GetPrecSignif( \
        MAX(TLS_GetPos1stDigit(d1) - TLS_GetPos1stDigit(d2) + 1, TLS_GetPos1stDigit(d1/d2)), dec, sd), \
        RndRule_Nearest)



/***************************
** Macros CMP_*
** x,y = double to compare
**
** i = currency identifier for CMP_AMOUNT()
** returns:	0	x = y
**		-1	x < y
**		1	x > y
***************************/
#define CMP_AMOUNT(x,y,i)      DBA_CmpAmount(x, y, i)               /* REF5248 - RAK - 001005 */
#define CMP_EXCHANGE(x,y)      TLS_Cmp(x ,y ,EXCHANGE_T_PREC)
#define CMP_LONGAMOUNT(x,y,i)  DBA_CmpAmount(x, y, i)				/* REF5248 - RAK - 001005 */
#define CMP_NUMBER(x,y)        TLS_Cmp(x ,y ,NUMBER_T_PREC)
#define CMP_PERCENT(x,y)       TLS_Cmp(x ,y ,PERCENT_T_PREC)
#define CMP_PRICE(x,y)         TLS_Cmp(x ,y ,PRICE_T_PREC)
#define CMP_ID(x,y)            TLS_CmpId(x, y) /* DLA - REF9089 - 030508 */
inline int CMP_MASK64(ENUMMASK_T x, ENUMMASK_T y) { if(x > y){return 1;} else { if(x < y){return -1;} else {return 0;}}} /* PMSTA-17133 - 051113 - PMO */
inline int CMP_ENUM(ENUM_T x, ENUM_T y)           { if(x > y){return 1;} else { if(x < y){return -1;} else {return 0;}}} /* PMSTA-26108 - 170929 - DDV */

/***************************
** Macro GET_FLD_ATTRIB
** Return field data type (DICT_ATTRIB_STP)
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_ATTRIB(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp)

/***************************
** Macro GET_FLD_TYPE
** Return field data type (DATATYPE_ENUM)
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_TYPE(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dataType)

/*************************** - PMSTA-26250 - DDV - 170331
** Macro GET_FLD_SQLNAME
** Return fld sqlname
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_SQLNAME(s,f) (&(EV_DynStPtr[s].dynStDefPtr[f].sqlName))

/***************************
** Macro GET_FLD_CTYPE
** Return field C type (CTYPE_ENUM)
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_CTYPE(s,f) (GET_CTYPE(GET_FLD_TYPE(s,f)))

/***************************
** Macro IS_STRINGFLD
** Return TRUE if data is a string, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_STRINGFLD(s,f) (IS_STRING_TYPE(GET_FLD_TYPE(s,f)))

/***************************
** Macro IS_USTRINGFLD
** Return TRUE if data is a unicode string, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_USTRINGFLD(s,f) (IS_USTRING_TYPE(GET_FLD_TYPE(s,f)))

/***************************
** Macro IS_VCHAREMPTY
** Return TRUE if string is empty
** psz = char* or UChar*
** b = flag : TRUE for  Uchar* and FALSE for char*
***************************/
#define IS_VCHAREMPTY(psz,b) ((((b == TRUE) &&\
                               ((static_cast<UChar*>(psz))[0] == END_OF_STRING)) ||\
                              ((b == FALSE) &&\
                               (psz[0] == END_OF_STRING)))?TRUE:FALSE)


/***************************
** Macro IS_ARRAYFLD
** Return TRUE if data is a array, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_ARRAYFLD(s,f) ((GET_FLD_CTYPE(s,f)==ArrayPtrCType)?TRUE:FALSE)

/***************************
** Macro IS_MULTIARRAYFLD
** Return TRUE if data is a array, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_MULTIARRAYFLD(s,f) ((GET_FLD_CTYPE(s,f)==MultiArrayPtrCType)?TRUE:FALSE)

/***************************
** Macro IS_FLAGFLD
** Return TRUE if data is a string, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_FLAGFLD(s,f) ((GET_FLD_TYPE(s,f)==FlagType)?TRUE:FALSE)

/***************************
** Macro IS_CHAINFLD
** Return TRUE if data is a chain info, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_CHAINFLD(s,f) ((GET_FLD_TYPE(s,f)==ChainedTypeType)?TRUE:FALSE)

/***************************
** Macro IS_EXTFLD
** Return TRUE if data is a extension, FALSE elsewhere.
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_EXTFLD(s,f) ((GET_FLD_CTYPE(s,f)==ExtPtrCType)?TRUE:FALSE)

/***************************
** Macro GET_FLD_STRLEN
** Return string length for string data.
** WARNING: size expressed in number of char
** It can be smaller than allocated size.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_FLD_STRLEN(p,f) (static_cast<int>(p[f].data.strData.ptr == nullptr ? 0 : strlen(p[f].data.strData.ptr)))

/***************************
** Macro GET_FLD_STRLEN
** Return string length for unicode string data.
** WARNING: size expressed in number of UChar
** It can be smaller than allocated size.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_FLD_USTRLEN(p,f) (static_cast<int>(p[f].data.ustrData.ptr == nullptr ? 0 : u_strlen(p[f].data.ustrData.ptr)))

/*************************** - REF9303 - LJE - 030904
** Macro GET_ASCII_FLD
** Return ascii field
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure
***************************/
#define GET_ASCII_FLD(p,f) (EV_DynStPtr[p[f].dynStEnum].dynStDefPtr[f].asciiField)

/*************************** - PMSTA-Memory - LJE - 181203
** Macro GET_INFO_FLD
** Return info field
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure
***************************/
#define GET_INFO_FLD(p,f) (EV_DynStPtr[p[f].dynStEnum].dynStDefPtr[f].infoField)

/**************************** PCC-17009 - LJE - 130318
** Macro GET_ANONYMIZE_ITEM
** Return anonymize item
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_ANONYMIZE_ITEM(s,f) (s > NullDynSt && EV_DynStPtr[s].dynStDefPtr != nullptr ? EV_DynStPtr[s].dynStDefPtr[f].anonymizeItem : f)  /* PMSTA-43500 - LJE - 210330 */

/**************************** PCC-17009 - LJE - 130318
** Macro GET_ANONYMIZE_SUBST
** Return anonymize substitute
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_ANONYMIZE_SUBST(s,f) (s > NullDynSt && EV_DynStPtr[s].dynStDefPtr != nullptr ? EV_DynStPtr[s].dynStDefPtr[f].anonymizeSubst : nullptr) /* PMSTA-43500 - LJE - 210330 */

/*************************** - REF8844 - LJE - 030408
** Macro GET_FLD_TYPE_MD
** Return field data type (DATATYPE_ENUM)
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_TYPE_MD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dataType)

/***************************
** Macro GET_FLD_DTP
** Return field data type (DATATYPE_ENUM)
** p = DBA_DYNFLD_STP
** f = field number in dynamic structure
** REF3927 - RAK - 990602
** PMSTA-19231 - 060115 - PMO : For the SUN 12.4 Compiler: cg: assertion failed in file ../src/codegen/map_switch.cc at line 2832
**                                                         cg: bad switch bounds
***************************/
inline DATATYPE_ENUM GET_FLD_DTP(const DBA_DYNFLD_STP p, const FIELD_IDX_T f) { return static_cast<DATATYPE_ENUM> (p[f].dataType); }

/***************************
** Macro GET_FLD_MAXLEN
** Return field maximum length
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_MAXLEN(s,f) (GET_MAXDATALEN(EV_DynStPtr[s].dynStDefPtr[f].dataType))    /* PMSTA-33077 - DLA - 181005 */

/***************************
** Macro GET_FLD_MD_MAXCHARLEN
** Return field meta-dictionary maximum character length
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_MD_MAXCHARLEN(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp && EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp->maxDbLenN ? EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp->maxDbLenN : GET_MAXCHARLEN(EV_DynStPtr[s].dynStDefPtr[f].dataType))  /* PMSTA-34373 - LJE - 190222 */

/***************************
** Macro GET_FLD_DFLTCONVFMT
** Return field default conversion format (CONVFMT_ENUM)
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define GET_FLD_DFLTCONVFMT(s,f) (GET_DFLTCONVFMT(EV_DynStPtr[s].dynStDefPtr[f].dataType))

/***************************
** Macro IS_DBFLD
** Return TRUE if field is in database, FALSE elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_DBFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dbFlg)

/***************************
** Macro IS_MDFLD
** Return TRUE if field is in meta-dictionary, FALSE elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_MDFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].mdFlg)

/***************************
** Macro IS_MAINFLD
** Return true if field is in the main table, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_MAINFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].bMain)

/***************************
** Macro IS_CUSTFLD
** Return true if field is a user defined field, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_CUSTFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].bCustom)

/***************************
** Macro IS_PRECOMPFLD
** Return true if field is a precomputed field, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_PRECOMPFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].bPrecomp)

/***************************
** Macro IS_PHISICALFLD
** Return true if field is in the table, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_PHISICALFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp != nullptr && EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp->isPhysicalAttribute() == true ? true : false)

/***************************
** Macro IS_CALCULATEDFLD
** Return true if field a calculated attribute, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_CALCULATEDFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp != nullptr && EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp->calcEn == DictAttr_Calculated ? true : false)

/***************************
** Macro IS_SPECIALFLD
** Return true if field is special (updated by trigger or special proc), false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_SPECIALFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp != nullptr && EV_DynStPtr[s].dynStDefPtr[f].dictAttribStp->isSpecialAttribute() == true ? true : false)

/***************************
** Macro IS_ME_PARTIAL
** Return true if field is MESI partial specialized, false elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_ME_PARTIAL(s,f) (EV_DynStPtr[s].dynStDefPtr[f].bMEPartial)

/***************************
** Macro IS_TECHFLD
** Return TRUE if field is technical, FALSE elsewhere
** s = DBA_DYNST_ENUM
** f = field number in dynamic structure
***************************/
#define IS_TECHFLD(s,f) (EV_DynStPtr[s].dynStDefPtr[f].isTech() ? TRUE : FALSE)    /* PMSTA-46259 - LJE - 211007 */

/***************************
** Macro COPY_DYNFLD
** Copy SRC dynamic structure field in DEST dynamic structure field
** Call the function DBA_CopyDynFld() in file dbadyn.c
** dest = destination structure pointer (DBA_DYNFLD_STP)
** d    = destination dynamic structure definition enum (DBA_DYNST_ENUM)
** df   = destination dynamic structure field number
** src  = source structure pointer (DBA_DYNFLD_STP)
** s    = source dynamic structure definition enum (DBA_DYNST_ENUM)
** sf   = source dynamic structure field number
***************************/
#define COPY_DYNFLD(dest,d,df,src,s,sf) ((void)DBA_CopyDynFld(dest,d,df,src,s,sf))

/***************************
** Macro COPY_DYNFLD_FLAG_NO_IMPACT             FPL-REF9215-030812
** Copy SRC dynamic structure field in DEST dynamic structure field
** Call the function DBA_CopyDynFld() in file dbadyn.c
** But do not overwrite flgMask of Flag field if field is NULL
** dest = destination structure pointer (DBA_DYNFLD_STP)
** d    = destination dynamic structure definition enum (DBA_DYNST_ENUM)
** df   = destination dynamic structure field number
** src  = source structure pointer (DBA_DYNFLD_STP)
** s    = source dynamic structure definition enum (DBA_DYNST_ENUM)
** sf   = source dynamic structure field number
***************************/
#define COPY_DYNFLD_FLAG_NO_IMPACT(dest,d,df,src,s,sf) ((void)DBA_CopyDynFldFlagNoImpact(dest,d,df,src,s,sf))

/***************************
** Macro COPY_DYNFLD_BY_DTP
** Copy SRC dynamic structure field in DEST dynamic structure field
** Call the function DBA_CopyDynFld() in file dbadyn.c
** dest = destination structure pointer (DBA_DYNFLD_STP)
** df   = destination dynamic structure field number
** src  = source structure pointer (DBA_DYNFLD_STP)
** sf   = source dynamic structure field number
** d    = datatype
***************************/
/* REF8844 - LJE - 030401 : Replace memcpy */
#define COPY_DYNFLD_BY_DTP(dest,df,src,sf,d) {if ((GET_CTYPE(d)==CharPtrCType)||(GET_CTYPE(d)==TextPtrCType))\
                        {SET_STRING(dest,df,GET_STRING(src,sf));}\
                         else if (GET_CTYPE(d) == UniCharPtrCType || GET_CTYPE(d) == UniTextPtrCType) /* REF17339 - DDV - 131213 */\
                        {SET_USTRING(dest, df, GET_USTRING(src, sf));}\
                          else\
                        {(dest)[df].flgMask    = (src)[sf].flgMask;\
                         (dest)[df].data       = (src)[sf].data;\
                        }\
                        (dest)[df].dataType = static_cast<unsigned char>(d);\
                        (src)[sf].dataType  = static_cast<unsigned char>(d);\
                         }

/***************************
** Macro CMP_DYNFLD
** Compare two dynst fields according to the datatype
** p1   = first dynst
** p2   = second dynst
** f1   = field compared in p1
** f2   = field compared in p2
**  d   = datatype of the compared field
***************************/
#define CMP_DYNFLD(p1, p2, f1, f2, d) (DBA_CmpDynFld(p1, p2, f1, f2, d, FALSE))

#define CMP_DYNFLD_SYB(p1, p2, f1, f2, d) (DBA_CmpDynFldSyb(p1, p2, f1, f2, d))

/***************************
** Macro CMP_DYNST
** Compare two dynst according to the dynStEnum
** p1   = first dynst
** p2   = second dynst
** s = DBA_DYNST_ENUM
** custFld define if customFld must be compare or not
** metaFld define if no Meta Fld must be compare or not FPL-REF10596-041020
***************************/
#define CMP_DYNST(p1, p2, s, custFld, metaFld) (DBA_CmpDynSt2(p1, p2, s, custFld, metaFld))

/***************************
** Macro ALLOC_DYNSTTAB
** Allocate one structure depending on dynamic structure definition.
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
** n = number of rows
***************************/
#define ALLOC_DYNSTTAB(s,n) (DICT_DynStTabAlloc(s,n))

/***************************
** Macro REALLOC_DYNSTTAB
** Reallocate one structure depending on dynamic structure definition.
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
** n = number of rows
***************************/
#define REALLOC_DYNSTTAB(p,s,n) (DICT_DynStTabRealloc(p,s,n))

/***************************
** Macro ALLOC_DYNST
** Allocate one structure depending on dynamic structure definition.
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define ALLOC_DYNST(s) (DICT_DynStAlloc(s))

/*************************** - REF8844 - LJE - 030328
** Macro RESET_DYNST_TAB
** Reset table of dynamic structure
** p = dynamic structure pointer (DBA_DYNFLD_STP)
** n = number of elements
***************************/
#define RESET_DYNST_TAB(p,n) {DBA_FreeDynStSupplFld(p,n);memset(p,0,sizeof(DBA_DYNFLD_ST)*n);} /* REF9743 - LJE - 040205 */

/*************************** - REF8844 - LJE - 030328
** Macro ALLOC_DYNST_WITHOUTDEF
** Allocate one structure not in DYNST_ENUM.
** f = Number of fields
***************************/
#define ALLOC_DYNST_WITHOUTDEF(f) (DICT_DynStWithoutDefAlloc(f))

/*************************** - REF8844 - LJE - 030328
** Macro ALLOC_DYNSTTAB_WITHOUTDEF
** Allocate one structure depending on dynamic structure definition.
** f = Number of fields
** n = number of rows
***************************/
#define ALLOC_DYNSTTAB_WITHOUTDEF(f,n) (DICT_DynStWithoutDefTabAlloc(f,n))

/*************************** - REF8844 - LJE - 030328
** Macro REALLOC_DYNSTTAB_WITHOUTDEF
** Reallocate one structure depending on dynamic structure definition.
** f = Number of fields
** n = number of rows
***************************/
#define REALLOC_DYNSTTAB_WITHOUTDEF(p,f,n) (DICT_DynStWithoutDefTabRealloc(p,f,n))

/***************************
** Macro ALLOC_DYNST_WITHDEF
** Allocate one structure not in DYNST_ENUM.
** f = Number of fields
** tp = Datatype array (DATATYPE_ENUM *)
***************************/
#define ALLOC_DYNST_WITHDEF(f, tp) (DICT_DynStWithDefAlloc(f, tp))

/***************************
** Macro ALLOC_DYNST_SUPPLFLD (REF3729)
** Allocate one structure depending on total fld nbr and
** update fields nature according to DBA_DYNST_ENUM.
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
** t = total field number
***************************/
#define ALLOC_DYNST_SUPPLFLD(s, t) (DICT_DynStAllocSupplFld(s, t))

/***************************
** Macro FREE_DYNST
** Free structure pointer depending on dynamic structure definition.
** In case of string fields, string pointer is free too.
** p = dynamic structure pointer (DBA_DYNFLD_STP)
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define FREE_DYNST(p,s)	{if((p)!=NULL){EV_DynStPtr[s].allocCpt--; DBA_FreeDynSt(p,s); FREE(p);}} /* REF9789 - LJE - 040102 */ /* PMSTA14474 - DDV - 120621 */

/***************************  REF7264 - LJE - 020129
** Macro FREE_DYNST_PTR
** Free structure pointer depending on dynamic structure definition.
** In case of string fields, string pointer is free too.
** p = dynamic structure pointer (PTR)
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define FREE_DYNST_PTR(p,s)	{if((p)!=NULL){EV_DynStPtr[s].allocCpt--;DBA_FreeDynSt(static_cast<DBA_DYNFLD_STP>(p),s); FREE(p);}} /* PMSTA14474 - DDV - 120625 */

/***************************
** Macro FREE_DYNST_SUPPLFLD
** Free structure pointer depending on datatype stored into dynFld.
** In case of string fields, string pointer is free too.
** p = dynamic structure pointer (DBA_DYNFLD_STP)
** n = fields number
***************************/
#define FREE_DYNST_SUPPLFLD(p,n)	{DBA_FreeDynStSupplFld(p,n); FREE(p);}

/***************************
** Macro FREE_DYNST_STR
** Free structure pointer depending on dynamic structure definition.
** In case of string fields, string pointer is free.
** Don't free origin structure pointer
** p = dynamic structure pointer (DBA_DYNFLD_STP)
** s = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define FREE_DYNST_STR(p,s) (DBA_FreeDynSt(p,s))

/***************************
** Macro COPY_CUSTST
** Copy All Customer Fields SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyCustSt() in file dbadyn.c
** Both structures must have the same number and the same order of customer fields.
** dest    = destination structure (DBA_DYNFLD_STP)
** destDef = destination dynamic structure definition enum (DBA_DYNST_ENUM)
** src     = source structure (DBA_DYNFLD_STP)
** srcDef  = source dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define COPY_CUSTST(dest, destDef, src, srcDef) (DBA_CopyCustSt(dest, destDef, src, srcDef))

/***************************
** Macro COPY_CUSTST_FLAG_NO_IMPACT             FPL-REF9215-030812
** Copy All Customer Fields SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyCustSt() in file dbadyn.c
** Both structures must have the same number and the same order of customer fields.
** But do not overwrite flgMask of Flag field if field is NULL
** dest    = destination structure (DBA_DYNFLD_STP)
** destDef = destination dynamic structure definition enum (DBA_DYNST_ENUM)
** src     = source structure (DBA_DYNFLD_STP)
** srcDef  = source dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define COPY_CUSTST_FLAG_NO_IMPACT(dest, destDef, src, srcDef) (DBA_CopyCustStFlagNoImpact(dest, destDef, src, srcDef))

/***************************
** Macro COPY_EXTENSION
** Copy an Extension Field from SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyExtension() in file dbadyn.c
** dest    = destination structure (DBA_DYNFLD_STP)
** df      = destination dynamic structure field number
** src     = source structure (DBA_DYNFLD_STP)
** sf      = source dynamic structure field number
***************************/
#define COPY_EXTENSION(dest, df, src, sf) (DBA_CopyExtension(dest, df, src, sf))        /* REF347 - 971020 - DED */

/***************************
** Macro COPY_DYNST
** Copy SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyDynSt() in file dbadyn.c
** Two structures must have same dynamic definition
** dest = destination structure (DBA_DYNFLD_STP)
** src  = source structure (DBA_DYNFLD_STP)
** s    = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define COPY_DYNST(dest,src,s) (DBA_CopyDynSt(dest,src,s))

/*************************** - REF9743 - LJE - 040203
** Macro CONVERT_DYNST
** Convert SRC dynamic structure in DEST dynamic structure
** Call the function DBA_ConvertDynSt() in file dbadyn.c
** Two structures must have same dynamic definition
** dest = destination structure (DBA_DYNFLD_STP)
** s1   = destination dynamic structure definition enum (DBA_DYNST_ENUM)
** src  = source structure (DBA_DYNFLD_STP)
** s2   = source dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define CONVERT_DYNST(dest,s1,src,s2) (DBA_ConvertDynSt(dest,src,false))

/***************************
** Macro COPY_DYNST_FLAG_NO_IMPACT
** Copy SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyDynStFlagNoImpact() in file dbadyn.c
** Two structures must have same dynamic definition
** dest = destination structure (DBA_DYNFLD_STP)
** src  = source structure (DBA_DYNFLD_STP)
** s    = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define COPY_DYNST_FLAG_NO_IMPACT(dest,src,s) (DBA_CopyDynStFlagNoImpact(dest,src,s))   /*  FIH-REF9215-030617  */

/***************************
** Macro COPY_DYNST_SUPPLFLD (REF3729)
** Copy SRC dynamic structure in DEST dynamic structure
** Call the function DBA_CopyDynStSupplFld() in file dbadyn.c
** Two structures must have same dynamic definition
** dest = destination structure (DBA_DYNFLD_STP)
** src  = source structure (DBA_DYNFLD_STP)
** n    = field number
***************************/
#define COPY_DYNST_SUPPLFLD(dest,src,n) (DBA_CopyDynStSupplFld(dest,src,n))

/***************************
** Macro COPY_DYNST_DISDOMTRACE - PMSTA-23209 - DDV - 160622
** Copy SRC dynamic structure in DEST dynamic structure and disable domain trace
** Call the function DBA_CopyDynStDisableDomainTrace() in file dbadyn.c
** Two structures must have same dynamic definition
** dest = destination structure (DBA_DYNFLD_STP)
** src  = source structure (DBA_DYNFLD_STP)
** s    = dynamic structure definition enum (DBA_DYNST_ENUM)
***************************/
#define COPY_DYNST_DISDOMTRACE(dest,src,s) (DBA_CopyDynStDisableDomainTrace(dest,src,s))

#define SET_NULL_DYNST(p,s) { DBA_SetNullDynSt(p,s);} /* DLA - CSC16664 - 011109 */

/*************************** - REF8844 - LJE - 030416
** Macros GET_OBJECT_CST
** return constante of object
** o = OBJECT_ENUM member
***************************/
#define GET_OBJECT_CST(o) (o>=0?EV_EntityGuiStPtr[o].objectCst:NullEntityCst)


/***************************
** Macro SET_BIT
** set one bit in a bit mask
** b = bit mask (long)
** n = bit position in bit mask
** s = source value (FALSE/TRUE)
***************************/
#define SET_BIT(b,n,s) {b= s? b|(0x00000001<<n): b&(~(0x00000001<<n));}


/***************************
** Macro GET_BIT
** return bit value( TRUE or FALSE) in a bitmask
** b = bitmask
** n = bit position in bit mask
***************************/
#define GET_BIT(b,n) (((b>>n)&1)==0?FALSE:TRUE)

/***************************
** Macro SET_MASKBIT
** set one bit in a bit mask field
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
** n = bit position in bit mask
** s = source value (FALSE/TRUE)
***************************/
#define SET_MASKBIT(p,f,n,s) {int m =GET_MASK(p,f);\
                              SET_BIT(m,n,s);\
                              SET_MASK(p,f,m);}

/***************************
** Macro GET_MASKBIT
** return bit value(TRUE or FALSE) in a bitmask field
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
** n = bit position in bit mask
***************************/
#define GET_MASKBIT(p,f,n) GET_BIT(GET_MASK(p,f), n)
#define _GET_MASKBIT(p,f,n) GET_BIT(_GET_MASK(p,f), n)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */

/************************************************************************
**      ENUM USED FOR DATA OPTIMISATION
*************************************************************************/
typedef enum {
    Check_GuiOptiStatus = 0,
    NoCheck_GuiOptiStatus,
    NextNoCheck_GuiOptiStatus
} GUI_OPTI_STATUS_ENUM;

typedef enum {
        Opti_None=-1,			/* REF11357 - RAK - 060518 */
        Opti_Local,             /* local only                          */
        Opti_Global,            /* global only                         */
        Opti_LocalGlobal,       /* local and then in global            */
        Opti_GlobalLocal        /* write global and after local        */
} DBA_OPTIMODE_ENUM;            /* read global after unsuccessed local */

/* REF11767 - CHU - 060518 */
typedef enum {
        Opti_SetMode_None=-1,
        Opti_SetMode_Set,
        Opti_SetMode_Upd
} DBA_OPTI_SETMODE_ENUM;

/************************************************************************
**      ENUM USED FOR CONNECTION HANDLING
*************************************************************************/

typedef enum {
    LoginPassed=-1,
    LogFailed_InvalidServerName,
    LogFailed_InvalidLogin,
    LogFailed_ServerNotRunning,
    LogFailed_DbAccessDenied
} DBA_LOG_FAILED_INFO_ENUM;

/************************************************************************************/


/* REF11818 - LJE - 060524 : Lock choose to lock server (avoid conditional file) */
typedef enum {
    DbaServLockNullLock=-1,
    DbaServLock_CreateVirtualEntity,
    DbaServLockOpt_NumberOfLocks       /* always the last line */
} DBA_SERV_LOCK_ENUM;

/************************************************************************
**      STRUCTURES USED AS INPUT ARGUMENT STRUCTURE
*************************************************************************/
typedef struct {
        ID_T        id;
        DICT_T		entityRefNo;
        CODE_T		code;
        ID_T		codificationId;
} DBA_ENTITY_ARG_ST, *DBA_ENTITY_ARG_STP;

/************************************************************************
**      STRUCTURE USED AS CONTEXT FOR EXPORTATION PROCEDURES
*************************************************************************/
typedef struct  {
    DbiConnection    *dbiConn;
    int              maxRowsNbr;
    OBJECT_ENUM      entity;
    ID_T             listId;
    TEXT_T           scriptCondition; /* DLA - REF9485 - 030923 */
    ID_T             fmtId;
	FLAG_T			 expformatfilter; /* PMSTA-43166 - AKT - 20210128 */
    int              nbCol;
    NOTE_T           *selElmList;
    DATATYPE_ENUM    *colTypeList;
    SMALLINT_T       *colWidthTab;
    NOTE_T           *dspFmtTab;
    DBA_DYNFLD_STP   *colDescrTab;
    ENUM_T 		 updstatus_sign;		 /* REF1317 - OCE - 19981015 */
    INT_T  		 updstatus_val;			 /* REF1317 - OCE - 19981015 */
    ENUM_T       exportMode;            /* PMSTA-52258 - JBC - 230308 */

} DBA_EXPORT_ST, *DBA_EXPORT_STP;

/************************************************************************
**      STRUCTURES USED FOR DATA & DESCRIPTION (SRV -> CLI DIALOG)
*************************************************************************/
typedef struct {
    INT_T           colNum,
                    dataType,
                    refKeyIndex,
                    refKeyNbr;
    DICT_T          refKeyEntDictId;
    DICT_T          fmtEntDictId;
    ID_T            classifId;
    INT_T           sortCol;
    char           *scptDef;
    PTR	            leaf;
    ID_T 	        fmtId;
    char        	zoomFlg;
    DBA_DYNFLD_STP  sumFmtElt;   /* REF3441 - SSO - 990714 */
    FLAG_T          colTotFlg;   /* REF7310 - LJE - 020115 */
    int             fmtEltNb;    /* REF7310 - LJE - 020116 */
    int             eltStartFmt; /* REF7310 - LJE - 020116 */
    FLAG_T          hideFlg;     /* REF11296 - LJE - 060616 */
    FLAG_T          computedFlg; /* REF11296 - LJE - 060616 */
} DBA_DATADEF_ST, *DBA_DATADEF_STP;

#ifndef DBA_SEND_MSG_OPTIONS_STRUCT_H
#include "dba_send_msg_options_struct.h"
#endif

typedef struct DBA_HIER_HEAD DBA_HIER_HEAD_ST, *DBA_HIER_HEAD_STP; /* REF7264 - LJE - 020131 */
typedef struct DBA_PROC_STRUCT DBA_PROC_ST, *DBA_PROC_STP;


/* Modifications des fonctions DBA */

/* Created new gravity/levels for messages */
#define RET_LEV_TECH_C_ERROR    0x20000000
#define RET_LEV_BUSINESS_ERROR  0x30000000
#define RET_LEV_TRIGGER_ERROR   0x40000000

#define RET_DBA_ERR_TRIGGER_MSG 0x4000001D

/* DDV - 990722 */
typedef struct {
        int                   count;
        int                   initState;
} DBA_YIELD_ST, *DBA_YIELD_STP;

/* Definition for index structures DBA_DYNSTDEF_ST and DBA_DYNFLD */
#include "descdyn.h"

/************************************************************************
**      STRUCTURES USED FOR DATA OPTIMISATION
*************************************************************************/
typedef struct DBA_OPTI {
    DBA_DYNFLD_STP dataPtr;        /* Init by 1st DBA_Get with optimised  */
                                   /* procedure. Contains access number   */
                                   /* (1 field), input arguments and      */
                                   /* output fields.                      */
    int            inputArgNbr;    /* Describe dataPtr composition, init  */
    int            outputFldNbr;   /* by 1st DBA_Get with optimized proc  */
    char           strArgFlg;      /* TRUE if 1 (or more) argument field  */
                                   /* is string, FALSE elsewhere          */
    int            currentReadNbr; /* current read access number          */
                                   /* updated (+,-) by DBA_ReadOpti       */
    unsigned int  eltNbr;          /* element nbr incremented by DBA_Get  */
    unsigned int  allocNbr;        /* allocated number                    */
    unsigned int  allocBloc;       /* global number to allocate           */
    unsigned int  maxAllocNbr;     /* global max element number to store  */
    unsigned int  locAllocBloc;    /* local number to allocate            */
    unsigned int  locMaxAllocNbr;  /* local max element number to store   */
    PTR           procPtr;         /* proc. info. pointer (DBA_PROC_STP)  */
    OBJECT_ENUM   **objLstPtr;     /* object Ptr list for optimization    */ /* REF8844 - LJE - 030417 */
    OBJECT_ENUM   *objLst;         /* object list for optimization        */ /* PMSTA-20269 - DDV  -150427 */
    DBA_OPTI_ENUM optiEnum;        /* enum value map for integrity check  */ /* PMSTA-53274 - JBC 230525 */
    unsigned int  cacheHint;       /* success number                      */ /* REF11767 - CHU - 060504 : changed int to unsigned int */
    unsigned int  nbCall;          /* number of call                      */ /* REF11767 - CHU - 060504 : changed int to unsigned int */
    int           *optiIndex;          /* pointer on index                    */
    int           *optiFree;           /* pointer in a list of record to free */
    unsigned int  maxFfree;        /* nb Max of record in *free           */
    unsigned int  currentFree;     /* current index in *free              */
    unsigned int  nbPurgeRecord;   /* current index in *free              */
    DBA_DYNST_ENUM outputDynSt;    /* output dynst enum                   */ /* REF8844 - LJE - 030408 */

    unsigned int  cacheHit;        /* Optimization statistics              */ /* REF11767 - CHU - 060329 */
    unsigned int  cacheMiss;       /* Optimization statistics              */ /* REF11767 - CHU - 060329 */
    DATETIME_T    *purgeTimeTab;   /* Optimization statistics              */ /* REF11767 - CHU - 060329 */
    int           purgeTimeNbr;    /* Optimization statistics              */ /* REF11767 - CHU - 060329 */
	SYS_LOCKRW_STP globalLock;	   /* SHR - PMSTA-20007*/
    FLAG_T         useShadowTableFlg; /* PMSTA-26250 - DDV - 170529 - If procedure has dependence on entity using shadow table, this flag is set to TRUE */
    FLAG_T         checkDlmeMaxFlg;      /* Add max dlm_e values as key for cache */ /* PMSTA-24030 - DDV - 161220 */
    FLAG_T         checkDataProfileFlg;  /* Add data profile as key for cache     */ /* PMSTA-24030 - DDV - 161220 */
    FLAG_T         checkBusinessEntityFlg;  /* Add data Connected BE as key for cache     */ /* PMSTA-24030 - DDV - 161220 */
    
} DBA_OPTI_ST, *DBA_OPTI_STP;



/* REF5495 - DDV - 001204 */
typedef struct {
    ID_T           classifId;
    int            totalListNb;
    DBA_DYNFLD_STP *eClassifCompoPtrTab; /* array of ptr on E_ClassifCompo */
} DBA_CLASSIFSTACK_ST, *DBA_CLASSIFSTACK_STP, SCPT_CLASSIFSTACK_ST, *SCPT_CLASSIFSTACK_STP;

/* REF5495 - DDV - 001204 */
typedef struct {
    int                  allocNbr;
    int                  classifNbr;
    DBA_CLASSIFSTACK_STP classifTab; /* array of ptr on DBA_CLASSIFSTACK_ST */
} DBA_CLASSIFSTACKHEAD_ST, *DBA_CLASSIFSTACKHEAD_STP;

/* REF5495 - DDV - 001206 */
typedef struct {
    ID_T listId;
    PTR  scriptTree;
} DBA_LISTOPTI_ST, *DBA_LISTOPTI_STP;

/* REF5495 - DDV - 001206 */
typedef struct {
    int                allocNbr;
    int                listNbr;
    DBA_LISTOPTI_STP   listTab; /* array of DBA_LISTOPTI_ST */
} DBA_LISTOPTIHEAD_ST, *DBA_LISTOPTIHEAD_STP;

/************************************************************************
**      STRUCTURES USED FOR SCRIPT DIALOG
*************************************************************************/
typedef struct {
    int	pos1,
        pos2;
} DBA_SCPTERRINFO_ST, *DBA_SCPTERRINFO_STP;



/* PMSTA-23726 - DDV - 160624 */
typedef enum {
    ExitReason_Default,
    ExitReason_InvalidSession
} EXITREASON_ENUM;

/************************************************************************
**      STRUCTURES USED FOR LOAD POS
*************************************************************************/
/* REF10744 - CHU - 041111 : Input structure definition for MultiSelect call in DBA_LoadPos() */
typedef struct {
    DBA_DYNST_ENUM *outputStLst;
    DBA_DYNST_ENUM  outputMatch;
}DBA_LOADPOSPARAM_ST, *DBA_LOADPOSPARAM_STP;

/************************************************************************
**      Class Used to Set Server User to On in a function and automatically and set it Off when leaving the scope - PMSTA-29656 - DDV - 180110
*************************************************************************/
class SetServerUserToOnGuard
{
    public:
        SetServerUserToOnGuard();
        ~SetServerUserToOnGuard();

        SetServerUserToOnGuard            (const LockGuard &) = delete;
        SetServerUserToOnGuard & operator=(const LockGuard &) = delete;
    private:
};


/************************************************************************
**      BEGIN External definitions for inline functions
*************************************************************************/
#ifdef  DBADYN_C                          /* PMSTA-16443 - 230713 - PMO */
       DBA_DYNST_STP    EV_DynStPtr = nullptr;
#else
extern DBA_DYNST_STP    EV_DynStPtr;
#endif


/************************************************************************
**      BEGIN Inline functions               PMSTA-16443 - 230713 - PMO *
*************************************************************************/


/***************************
** Macro GET_FLD_AUTH_UPD   FPL-REF10401-040630
** Return index of field authUpd in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_AUTH_UPD(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].authUpdFlgIdx;
}

/***************************
** Macro GET_FLD_AUTH_DEL   FPL-REF10401-040630
** Return index of field authDel in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_AUTH_DEL(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].authDelFlgIdx;
}

/***************************
** Macro GET_FLD_AUTH_UPD_SECU   HFI-PMSTA-32148-181003
** Return index of field authUpdSecuIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_AUTH_UPD_SECU(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].authUpdSecuIdx;
}

/***************************
** Macro GET_FLD_AUTH_DEL_SECU  PMSTA-26554 - LJE - 181116
** Return index of field authDelSecuIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_AUTH_DEL_SECU(const DBA_DYNST_ENUM s)
{
    if (EV_DynStPtr[s].authDelSecuIdx == Null_Dynfld)
    {
        return EV_DynStPtr[s].authUpdSecuIdx;
    }

    return EV_DynStPtr[s].authDelSecuIdx;
}

/***************************
** Macro GET_FLD_AUTH_REASON   HFI-PMSTA-32148-181012
** Return index of field authReasonIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_AUTH_REASON(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].authReasonIdx;
}

/***************************
** Macro GET_FLD_ME_REC_LOC HFI-PMSTA-32148-181023
** Return index of field meRecLocFldIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_ME_REC_LOC(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].meRecLocFldIdx;
}

/***************************
** Macro GET_FLD_CODIF_IDX  HFI-PMSTA-52805-2023-04-14
** Return index of field codifIdIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_CODIF_IDX(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].codifIdIdx;
}

/***************************
** Macro GET_FLD_INTERNAL - PMSTA-37366 - LJE - 200121
** Return index of field internalFldIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_INTERNAL(const DBA_DYNST_ENUM s)
{
    return s <= InvalidDynSt || s > LASTDYNST ? Null_Dynfld : EV_DynStPtr[s].internalFldIdx;
}

/***************************
** Macro GET_FLD_FK          PMSTA-46681 - LJE - 220825
** Return index of field foreignKeyFldIdx in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_FK(const DBA_DYNST_ENUM s)
{
    return s <= InvalidDynSt || s > LASTDYNST ? Null_Dynfld : EV_DynStPtr[s].foreignKeyFldIdx;
}

/***************************
** Macro GET_FLD_NBR
** Return total field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FLD_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].fldNbr; }

/***************************
** Macro GET_CUST_NBR
** Return customer field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_CUST_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].custFldNbr; }

/*************************** * PMSTA-11505 - LJE - 110615 *
** Macro GET_PRECOMP_NBR
** Return precomputed field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_PRECOMP_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].precompFldNbr; }

/*************************** * PMSTA-42814 - LJE - 210922 *
** Macro GET_LOGICAL_NBR
** Return logical field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_LOGICAL_NBR(const DBA_DYNST_ENUM s)
{
    return EV_DynStPtr[s].logicalFldNbr;
}

/***************************
** Macro GET_NOMD_NBR
** Return no meta-dictionary field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_NOMD_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].noMDFldNbr; }

/***************************
** Macro GET_TECH_NBR
** Return technical field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_TECH_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].techFldNbr; }

/***************************
** Macro GET_FIX_NBR
** Return fix field number in dynamic structure.
** Use DBA_DYNST_ST SV_DynStTab initialized in file dbadyn.c
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_FIX_NBR(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].fixFldNbr; }

/*************************** - REF8844 - LJE - 030416
** Macro GET_OBJ_DYNST
** Return object of dynamic structure
** Use DBA_DYNST_ST
** s = DBA_DYNST_ENUM
***************************/
inline OBJECT_ENUM GET_OBJ_DYNST(const DBA_DYNST_ENUM s)
{
    return s < InvalidDynSt || s > LASTDYNST ? NullEntity : EV_DynStPtr[s].entity;
}

/***************************
** Macro GET_DYNSTENUM
** return dynamic structure on data
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
***************************/

inline DBA_DYNST_ENUM GET_DYNSTENUM(const DBA_DYNFLD_STP p) { return  p != NULL ? p[0].dynStEnum : NullDynSt; }

/*************************** - REF9743 - LJE - 040202
** Macro GET_DYNST_TYPE
** Return dynamic structure type (DBA_DYNTYPE_ENUM)
** Use DBA_DYNST_ST
** s = DBA_DYNST_ENUM
***************************/
inline DBA_DYNTYPE_ENUM GET_DYNST_TYPE(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].dynTypeEnum; }

/*************************** - PMSTA-26250 - DDV - 170331
** Macro GET_DYNST_HIERIDX_FLDIDX
** Return fld idx for hier idx field
** Use DBA_DYNST_ST
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_DYNST_HIERIDX_FLDIDX(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].hierEltIdxFldIdx; }

/*************************** - PMSTA-26250 - DDV - 170331
** Macro GET_DYNST_OLDREC_EXTFLDIDX
** Return fld idx for extension on old record
** Use DBA_DYNST_ST
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_DYNST_OLDREC_EXTFLDIDX(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].changeSetOldRecExtFldIdx; }

/*************************** - PMSTA-26250 - DDV - 170331
** Macro GET_DYNST_NEWREC_EXTFLDIDX
** Return fld idx for extension on old record
** Use DBA_DYNST_ST
** s = DBA_DYNST_ENUM
***************************/
inline FIELD_IDX_T GET_DYNST_NEWREC_EXTFLDIDX(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].changeSetNewRecExtFldIdx; }

/* PMSTA-18094 - 130514 - PMO
 *  Clear a password
 */
inline void DBA_PasswordClear(void * p, size_t size)
{
    memset(p, 255, size);
    memset(p,   0, size);
}

/* Clear the memory/password when leaving the scope/function
*  Useful when there is a lot of return into a function and the memory/password must always be cleaned
*
*  AUTO_PASSWORD_CLEAR is defined to use a local string only!!!
*       char password[32];
*       AUTO_PASSWORD_CLEAR(password, sizeof(password));
*
* Typical usage:
* --------------
*       char password[32];
*       AUTO_PASSWORD_CLEAR(password, sizeof(password));    # AUTO_PASSWORD_CLEAR must be on the same scope than the variable
*
*       if (.. )
*       {   # No need to call DBA_PasswordClear :-)
*           return 0;
*       }
*       # No need to call DBA_PasswordClear :-)
*
*       In place of
*       -----------
*       char password[32];
*       if (.. )
*       {
*           DBA_PasswordClear(password, sizeof(password));
*           return 0;
*       }
*       DBA_PasswordClear(password, sizeof(password));
*/
#define AUTO_PASSWORD_CLEAR(p,s) STRUCT_AUTO_PASSWORD_CLEAR autoPasswordClear##p((void*)p,s)

/************************************************************************
**      BEGIN External definitions attached to : dbacurr.c  REF5248
*************************************************************************/

extern  RET_CODE DBA_GetAllCurrencyById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&),
                 DBA_GetAllCurrencyByCd(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&);


extern  int      DBA_CmpAmount(double, double, ID_T);

extern  double   DBA_GetCurrPrecision(DBA_DYNFLD_STP);

/************************************************************************
**      BEGIN External definitions attached to : dbapos.c
*************************************************************************/
extern RET_CODE	DBA_LoadPos(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP*,  /* REF10744 - CHU - 041105 : removed DBA_DYNST_ENUM */
    int, DBA_DYNFLD_STP*, int);				/* BUG467 - 970826 - DED */
extern RET_CODE	DBA_LoadPosOld(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP*,  /* REF10744 - CHU - 041105 : removed DBA_DYNST_ENUM */
                            int, DBA_DYNFLD_STP*, int);				/* BUG467 - 970826 - DED */
extern RET_CODE	DBA_LoadPos2(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP*, int);
extern RET_CODE DBA_LoadPosForSynthAdmin(DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
                                         DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP*, int);

extern RET_CODE DBA_LoadOperByBatch(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, FLAG_T, int*, int*, DbiConnection&), /* REF2467 - DDV - 000120 */
DBA_LoadOrders(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, FLAG_T, DbiConnection&), /* REF7560 - DDV - 020604 */
DBA_LoadExtExecutions(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int *); /* REF7560 - DDV - 020605 */

extern RET_CODE DBA_GenericInstr(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, const int, DATETIME_T),          /* PMSTA05966 - 090525 - PMO */
DBA_CreateCashLegInstr(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*),
DBA_UpdExtPosFld(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, PTR),
DBA_UpdPosValFld(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
DBA_UpdFwdTermInfo(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T),
DBA_SelectLastPtfSynth(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*),	/* REF2992 - RAK - 981230 */
DBA_SelectLastPerfData(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*),	/* REF9923 - CHU - 040216 */
DBA_SelectExchRateForPtfSynth(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, char, DbiConnection&, DBA_HIER_HEAD_STP),	/* REF2992 - RAK - 990112 */
DBA_SelPtfByDomain(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
DBA_SelectIncomeOperForValo(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP **, int *); /* PMSTA00485-CHU-061011 */ /* PMSTA-28086-CHU-170919 */

extern RET_CODE DBA_LoadPPSForPtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*);
extern FLAG_T   DBA_CheckPPSDim(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int);
extern RET_CODE DBA_SelectExtOpForAllocMan(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP), /* REF8509 - CHU - 021121 */
DBA_SelectExtOpForUnspecQty(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP), /* REF8376 - CHU - 040603 */
DBA_LoadPosHierLnkAndUpd(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T), /* REF9770 - LJE - 040115 */
DBA_LoadPosHierCreate(DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP *, int, DBA_DYNFLD_STP**, int*, const DBA_DYNST_ENUM**, FLAG_T, FLAG_T); /* PMSTA-10748 - LJE - 110210 - Extern */

extern RET_CODE DBA_LoadExtTransForSMatchO(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DbiConnection&); /* REF9764 - TEB - 040122 */
extern RET_CODE DBA_TransferDomPortToTSL(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, DbiConnectionHelper&);         /*  FPL-PMSTA11939-110607   */
extern RET_CODE DBA_LoadTascJobData(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, FLAG_T *); /* PMSTA13876 - DDV - 130815 */
extern RET_CODE DBA_PriceValidity(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int); /* PMSTA-34990 - CHU - 190326 : Made extern */


extern RET_CODE DBA_LoadPosPtfInstrDimension(DBA_DYNFLD_STP, DbiConnection&, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP*, int, DICT_T*, DBA_HIER_HEAD_STP* = nullptr);
extern RET_CODE DBA_CallMultiSelectForLoadPos(int, DBA_DYNFLD_STP, const DBA_DYNST_ENUM **, DBA_DYNFLD_STP **, int *, DbiConnection&);
extern RET_CODE DBA_CallMultiSelectForLoadPos2(int, DBA_DYNFLD_STP, const DBA_DYNST_ENUM **, DBA_DYNFLD_STP **, int *, DbiConnection&);
extern RET_CODE DBA_CheckDataBeforeLoadingHier(DBA_DYNFLD_STP , DBA_HIER_HEAD_STP *, const DBA_DYNST_ENUM **, int *, int, DBA_DYNFLD_STP **, int *, DbiConnection&, FLAG_T, DATETIME_T, FLAG_T, DATETIME_T,int *, DBA_DYNFLD_STP **);
extern int      DBA_LoadPosDropTempTables(DbiConnection&, DICT_FCT_ENUM);
extern void DBA_TreatAdjustmentAccountPosition(const DBA_DYNFLD_STP domainPtr, const DBA_DYNST_ENUM **, const int, DBA_DYNFLD_STP **, const int *);
extern void DBA_CopyOperationRemoveTargetPortfolioTransferPosition(const DBA_DYNFLD_STP, const DBA_DYNST_ENUM **, const int, DBA_DYNFLD_STP **, const int *);
extern void DBA_PropagateFusionE(const DBA_DYNFLD_STP, const DBA_DYNST_ENUM **, const int, DBA_DYNFLD_STP **, const int *);
extern void DBA_UpdateInterCondFlg(const DBA_DYNST_ENUM**, int, DBA_DYNFLD_STP **, int *);
extern RET_CODE DBA_LoadSessionOrder(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP hierHead, int *);
extern RET_CODE DBA_UpdateCostPrice(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);

/* REF7289 - LJE - 020228 */
/************************************************************************
**      BEGIN External definitions attached to : dbaproc.c
*************************************************************************/

/************************************************************************
**      BEGIN External definitions attached to : dbaserv.c
*************************************************************************/
extern RET_CODE DBA_CurrencyModify(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DbiConnection &, DATETIME_T & , DATE_T &, int &, LockPortfolioHelper &),	/* BUG252 - 970114 - DED */
DBA_SelStratLnkById(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DbiConnectionHelper&), /* DVP529 */
DBA_SelMCForPtfList(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),	/* REF11435 - TEB - 051021 */
DBA_SelCheckStratData(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T**, int*, MODELCONSTRVALID_ENUM), /* REF11435 - TEB - 051012 */ /* REF2755 - SSO - 990215*/
DBA_BenchStorageData(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP *),             /* REF7422 - RAK - 020403 */
DBA_UpdInstrStratElt(DBA_DYNFLD_STP),				    /* REF4908 - 000620 - DED */
DBA_SelConstrScriptStratData(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),	    /* REF2996 - SSO - 990114 */
/* REF7395 - CSY - 020322: moved from dbaserv.c, STATIC to extern */
DBA_SortUniqueStratId(DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*),
DBA_DelDomPortAndDomStratTables(int, FLAG_T),
DBA_InitStratLnk(DBA_DYNFLD_STP, int*, ID_T**, int*, DBA_DYNFLD_STP),
DBA_CreateDomPortAndDomStratTables(int, FLAG_T),
DBA_SelStratLnkByIdWithPtfs(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, int, int, DBA_ERRMSG_INFOS_STP, ID_T**, int*, FLAG_T, DBA_DYNFLD_STP);   /* PMSTA-12724-CHU-110907 */

extern  int     DBA_CmpSStratLnkPtfStrat(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
/* REF9875 - RAK - 050602 */
extern RET_CODE DBA_SelOneSslData(ID_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);
extern RET_CODE FIN_KRA(DBA_HIER_HEAD_STP* hierHeadPtr, DBA_DYNFLD_STP, ID_T *, int); /* OCS-38780-CHU-110802 */ /* OCS-47724 - CHU - 160217 moved from srvstra1 */
extern RET_CODE DBA_IsReplOldESLByPtfId(ID_T, ID_T, FLAG_T *, int, int *); /* PMSTA-29302 - CHU - 180206 */
extern RET_CODE DBA_FilterPtfForSelectiveReplaceOld(DBA_DYNFLD_STP, int *, ID_T **, int *, int, DBA_DYNFLD_STP **, int *, FLAG_T, DBA_HIER_HEAD_STP); /* PMSTA-29302 - CHU - 180206 */
extern RET_CODE DBA_GetHierHeadPTF(ID_T , ID_T *);

/************************************************************************
**      BEGIN External definitions attached to : dbadict.c
*************************************************************************/

extern RET_CODE    DBA_InitDictInfo(FLAG_T tryGetFromFileFlg=TRUE, FLAG_T lightLoadFlg=FALSE),
                   DBA_InvalidLogicalList(OBJECT_ENUM, ENUM_T, PTR, ENUM_T, PTR, OBJECT_ENUM**, int*),
                   DBA_SearchEntityBySqlName(const char * , DICT_ENTITY_STP *),          /* PMSTA-26108 - LJE - 170911 */
                   DBA_FillFunctionList(DICT_FCT_ENUM,PTR,PTR,PTR, FUNCTIONLIST_ENUM, FLAG_T),          /*  FPL-REF11288-060413 */
                   DBA_FillFunctionListAdminRight(PTR),                     /*  FPL-REF11313-050801 */
                   DBA_FillPermValTab(OBJECT_ENUM, int, PTR, int*, DICT_T),
                   DBA_GetAttribFieldIdx(OBJECT_ENUM, int, OBJECT_ENUM*, int*),
                   DBA_GetBusinessAttrib(OBJECT_ENUM, int*, DICT_ATTRIB_STP**),
                   DBA_GetPrimaryAttrib(OBJECT_ENUM, int*, DICT_ATTRIB_STP**),
                   DBA_GetDictFctInfo(DICT_T, short, PTR),
                   DBA_GetDictLangStruct(DICT_T, DBA_DYNFLD_STP),
                   DBA_InitAdmArgFromMeta(DBA_DYNFLD_STP, PTR, OBJECT_ENUM, OBJECT_ENUM, ID_T),
                   DBA_SearchAttribSqlName(OBJECT_ENUM, const char*, DICT_ATTRIB_STP *), /* DLA - REF8728 */
                   DBA_GetLinkedAttrib(OBJECT_ENUM     entityRef, DICT_ATTRIB_STP *dictAttrStPtr), /* PMSTA-18593 - LJE - 150521 */ /* PMSTA-26108 - LJE - 170911 */
                   DBA_SetDfltEntityFld(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                   DBA_SetDfltEntityFld(DBA_DYNFLD_STP),
                   DBA_SetDfltEntityNotDbFld(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP),  /* PMSTA-42198 - DDV - 201028 */
                   DBA_GetSelectModeInfo(OBJECT_ENUM, char*, int*, short*, ID_T*, ID_T*, DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),             /*  FPL-REF10391-041202 add dynListStp  */  /*  FPL-PMSTA08801-091119 long* to ID_T*    */
                   DBA_SetSelectModeInfo(OBJECT_ENUM, char*, int, short, ID_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, char*, FLAG_T),    /*  FPL-REF10391-041202 add dynListStp and dynQSearch */    /*  FPL-PMSTA08801-091119 long to ID_T  */
                   DBA_ConvertDynStToString(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, FLAG_T, void *, char **, int, FLAG_T, FLAG_T, DbiConnection&),			/* REF4204 */
                   DBA_ConvertDynStToString2(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, FLAG_T, void *, char **, int, FLAG_T, FLAG_T, DbiConnection&, FLAG_T, FLAG_T, FLAG_T,
                                             SubscriptionNatEn = SubscriptionNatEn::None), /* DLA - PMSTA-12367 - 110719 (cloned into r11 rbn 180811 PMSTA-12563) */ /*PMSTA-49250 - 20052022 - Lalby -use a full qualified name of attributes, default FALSE */
                   DBA_ConvDynStToStringWoFKSolved(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, char **, FLAG_T),   /*REF5309 - DLA - 001122 */
                   DBA_ConcatString(char *, char *, SUBSCRIPTION_ACTION_ENUM, char **),	/* REF4204 */
                   DBA_GetShortAllData(OBJECT_ENUM, DBA_DYNFLD_STP, FIELD_IDX_T, FLAG_T*, DBA_DYNFLD_STP*, int, int*, DBA_ERRMSG_INFOS_STP), /* REF4204 */  /* PMSTA-16677 - LJE - 130712 */
                   DBA_GetAllDictAttById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&),
                   DBA_GetShortDictAttById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&), /* REF9764 - LJE - 040107 */
                   DBA_GetAllDictEntityById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int *, int , DBA_ERRMSG_INFOS_STP ),
                   DBA_GetShortDictEntityById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int *, int , DBA_ERRMSG_INFOS_STP ), /* REF9764 - LJE - 040107 */
                   DBA_GetAllFunctionResultById(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*,DbiConnectionHelper&),
                   DBA_BackupExtension (OBJECT_ENUM, DBA_DYNFLD_STP , DBA_DYNFLD_STP ),                 /*  FIH-REF11457-051004 */
                   DBA_ConvertDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, bool), /* REF9743 - LJE - 040203 */
                   DBA_ConvertDynSt(DBA_DYNFLD_STP, DBA_DYNFLD_STP, bool),                                 /* PMSTA-46681 - LJE - 230914 */
                   DBA_ConvertFlagsTab(FLAG_T *, DBA_DYNST_ENUM, FLAG_T *, DBA_DYNST_ENUM), /* REF9764 - LJE - 040212 */
                   DBA_ConvertStructTab(PTR,DBA_DYNST_ENUM,PTR,DBA_DYNST_ENUM,PTR,void (*)(PTR,int,PTR,int,PTR)),
                   DBA_GetMandatoryFieldList(DBA_DYNST_ENUM, FLAG_T *, const size_t),   /* PMSTA-17133 - 051113 - PMO */
                   DBA_GetFieldToCompleteList(DBA_DYNST_ENUM, FLAG_T *, const size_t);  /* PMSTA-17133 - 051113 - PMO */

extern RET_CODE    DICT_LinkFieldsToEntity(DICT_ENTITY_STP, DICT_ENTITY_STP, FIELD_IDX_T, FIELD_IDX_T, FLAG_T, FLAG_T, FLAG_T);

extern FIELD_IDX_T DBA_ConvertFldIdx(DBA_DYNST_ENUM, DBA_DYNST_ENUM, FIELD_IDX_T);  /* FPL-REF10103-040402 */
extern DICT_T      DBA_ConvertAttributeDictId(DBA_DYNST_ENUM, DBA_DYNST_ENUM, DICT_T);  /*  FPL-REF10232-040430 */

extern INT_T       DBA_GetCustFldNbr(OBJECT_ENUM),
                   DBA_GetPrecompFldNbr(OBJECT_ENUM), /* PMSTA-11505 - LJE - 110615 */
                   DBA_GetFirstCustFld(OBJECT_ENUM entity);  /* PMSTA-11505 - LJE - 110615 */

extern void        DBA_SetFldDictInfo(DBA_DYNSTDEF_STP,  OBJECT_ENUM, int),
                   DBA_SetUseScreenFlag(OBJECT_ENUM, FLAG_T);

extern int         DBA_CmpDynSt(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP, const bool = false),   /* PMSTA-19029 - 041114 - PMO */
                   DBA_ExtractSpecificField (OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP),      /*  FIH-REF9546-031031  */
                   DBA_GetObjectEnum(DICT_T, OBJECT_ENUM *),
                   DBA_GetObjectEnumByDynSt(DBA_DYNST_ENUM, OBJECT_ENUM *), /* DDV - 981109 */
                   DBA_GetPermValEnum(OBJECT_ENUM, int, const char *), /* DLA - REF8728 */
                   DBA_GetPermValMax(OBJECT_ENUM, int),				/* DVP166 - 961003 - DED */
                   DBA_GetPermValNumber(OBJECT_ENUM,int),           /*  FIH-REF1587-980420  */
                   DBA_GetDictId(OBJECT_ENUM, DICT_T *),
                   DBA_GetBusiShortIndex(OBJECT_ENUM),
                   DBA_GetBusiIndex(OBJECT_ENUM),
                   DBA_IsAnOperationObject(OBJECT_ENUM),
                   DBA_CheckString(DATATYPE_ENUM, char *, DBA_DYNFLD_STP record = NULLDYNST, FIELD_IDX_T idx = 0),
                   DBA_GetEntityCodeIndex (OBJECT_ENUM);            /*  HFI-PMSTA-13647-120207  */

extern bool        DBA_IsAnExtOperationObject(OBJECT_ENUM);

extern OBJECT_ENUM DBA_GetObjectEnum(DICT_T);   /* PMSTA-48536 - LJE - 220405 */

extern SECURETYPE_ENUM  DBA_GetEntitySecuredType    (OBJECT_ENUM);          /*  FIH-REF10288-040608 */
extern int              DBA_GetSecuredTypeIndex     (OBJECT_ENUM,FLAG_T);   /*  FIH-REF10288-040608 */
extern int              DBA_GetSecuredSubTypeIndex  (OBJECT_ENUM,FLAG_T);   /*  FIH-REF10288-040608 */
extern int              DBA_GetSecuredStatusIndex   (OBJECT_ENUM,FLAG_T);   /*  FIH-REF10288-040608 */
extern int              DBA_CmpShortAttribRank      (PTR,PTR);              /*  HFI-PMSTA-33398-181024  */
extern int              DBA_CmpFunctionRank         (PTR,PTR);              /*  HFI-PMSTA-37848-191112  */

extern DICTATTR_ENUM    DBA_GetDictAttribCalcEn(OBJECT_ENUM, int);

extern TYPINGNAT_ENUM DBA_GetTypingNat(OBJECT_ENUM);

extern FLAG_T      DBA_GetMainFlag(OBJECT_ENUM),
                   DBA_GetUseScreenFlag(OBJECT_ENUM),
                   DBA_GetGuiMainEntFlag(OBJECT_ENUM),
                   DBA_GetEntityMainMenuFlag(DICT_T),           /* FPL-REF8446-021114 */
                   DBA_GetDictEntityDispBusiFlag(OBJECT_ENUM);  /*  FIH-REF10766-041116 */

extern PK_RULE_ENUM DBA_GetPkRuleEn(OBJECT_ENUM); /* PMSTA-18593 - LJE - 151027 */

extern DICT_PERM_VAL_STP DBA_GetDictPermValSt(OBJECT_ENUM, int, int); /* PMSTA-26108 - LJE - 170911 */
extern DICT_PERM_VAL_STP DBA_GetDictPermValByName(OBJECT_ENUM, int, const char *); /* PMSTA-26108 - LJE - 170911 */

extern const char  *DBA_GetDictAttribSqlName(OBJECT_ENUM, int),
                   *DBA_GetDictEntitySqlName(OBJECT_ENUM),
                   *DBA_GetDictEntityUdSqlName(OBJECT_ENUM),    /* REF10392 - LJE - 040624 */
                   *DBA_GetPermValPtr(OBJECT_ENUM, int, int),
                   *DBA_GetPermValName(OBJECT_ENUM, int, int),
                   *DBA_GetDictBusinessKey(OBJECT_ENUM, DICT_T),
                   *DBA_GetDataTypeSQLNameC(DATATYPE_ENUM);
extern void         DBA_GetShortSqlDyn(std::stringstream &shortFieldsStream, OBJECT_ENUM, const char *, FLAG_T, FLAG_T), /* REF8844 - LJE - 030505 */
                    DBA_CheckLicenseInfo (INFO_T,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*,short*), /*  HFI-PMSTA-35838-190515  */
                    DBA_CheckLicenseInfoFunction(std::vector<DICT_FCT_ST> &fctTab),                                                                                                                   /*  HFI-PMSTA-35838-190515  */
                    DBA_CheckLicenseInfoEntity (void);                                                                                                                                  /*  HFI-PMSTA-35838-190515  */

extern const UChar *DBA_GetUniPermValPtr(OBJECT_ENUM, int, int); /* REF9303 - LJE - 030915 */


extern FLAG_T      DBA_CheckPermVal(OBJECT_ENUM, int, int); /* DLA - REF6058 - 020515 */

extern DICT_T      DBA_GetDictTechKey(OBJECT_ENUM, char*);

extern DICT_ATTRIB_STP  DBA_GetDictAttribStByShortIdx(OBJECT_ENUM, FIELD_IDX_T),
                        DBA_GetDictAttribSt(OBJECT_ENUM, FIELD_IDX_T),
                        DBA_GetAttributeById(DICT_T);
extern FEATURE_AUTH_ENUM DBA_GetGlobalChangeSetAuth (void);             /*  HFI-PMSTA-27694-180723  */
extern FEATURE_AUTH_ENUM DBA_GetGlobalMultiEntityCategoryAuth(void);    /* PMSTA-34445 - LJE - 190313 */

extern DICT_ATTRIB_STP  DBA_GetAttributeBySqlName(OBJECT_ENUM object, const char *name, FLAG_T forceNameFlg = FALSE); /* DLA - REF8728 */

extern	RET_CODE	DICT_DynStDatatypeSet(DBA_DYNFLD_STP, DBA_DYNST_ENUM);
extern	DBA_DYNFLD_STP	DICT_DynStAlloc(DBA_DYNST_ENUM),
                        DICT_DynStTabAlloc(DBA_DYNST_ENUM,int), /* REF8844 - LJE - 030321 */
                        DICT_DynStWithoutDefAlloc(int),         /* REF8844 - LJE - 030331 */
                        DICT_DynStWithoutDefTabAlloc(int,int),  /* REF8844 - LJE - 030331 */
                        DICT_DynStWithoutDefTabRealloc(DBA_DYNFLD_STP,int,int),  /* REF8844 - LJE - 030331 */
                        DICT_DynStWithDefAlloc(int, const DATATYPE_ENUM *datatypeTab),   /* PMSTA-41519 - DDV - 200820 */
                        DICT_DynStTabRealloc(DBA_DYNFLD_STP,DBA_DYNST_ENUM,int), /* REF8844 - LJE - 030331 */
                        DICT_DynStAllocSupplFld(DBA_DYNST_ENUM, int);	/* REF3729 - RAK - 990602 */
extern DICT_T           DBA_GetRefEntityDictId (DICT_T*,OBJECT_ENUM,int,DBA_DYNFLD_STP);
extern RET_CODE         DBA_ConvShortDynstToAll(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP);   /* REF4204 */
extern size_t           DICT_GetAllocKbSizeDynStWithoutDefTabAlloc(const int, const int);       /* PMSTA-16443 - 230713 - PMO */
extern void             DBA_SetWarningMessageBox(bool (*)(const char *));                       /* PMSTA-16443 - 230713 - PMO */
extern void             DBA_SetGetDataSegmentSize(size_t (*)(void));                            /* PMSTA-16443 - 230713 - PMO */

typedef std::map<OBJECT_ENUM, std::map<DICT_T, std::map<DICT_T, std::map<ID_T, std::vector<DBA_DYNFLD_STP>>>>> subQueryMapType;

extern  RET_CODE        DBA_GetDynStpFromJSonString(const std::string &, std::vector<DBA_DYNFLD_STP> &, BuildBindOption &, MemoryPool &, DbiConnection &, bool); /* PMSTA-45027 - LJE - 210430 */
extern  RET_CODE        DBA_GetJSonStringFromDynStp(const std::vector<DBA_DYNFLD_STP> &, std::string &, BuildBindOption &, DbiConnection &);                     /* PMSTA-45027 - LJE - 210430 */
extern  RET_CODE        DBA_ExtractPackageDefinition(std::vector<DBA_DYNFLD_STP> &, BuildBindOption &, DbiConnection &);
extern  RET_CODE        DBA_CreateExportFiles(std::vector<DBA_DYNFLD_STP>&, BuildBindOption&, DbiConnection&);


extern  RET_CODE        DBA_CopyDataJSon(DbiConnectionHelper&, std::string, ProcessingMessageNatEn, std::string&);

extern  RET_CODE        DBA_FillFullRecord(DBA_DYNFLD_STP, BuildBindOption&, MemoryPool&, DbiConnectionHelper&, subQueryMapType &);

extern void             DBA_WriteGuiContext (FILE*,DBA_DYNFLD_STP,DBA_DYNFLD_STP);  /*  FIH-REF7207-011126  */  /*  FIH-REF9867-040226  */
extern PTR              DBA_GetDataFromDynStp (DATATYPE_ENUM,DBA_DYNFLD_STP);   /*  FIH-REF8683-030521  */
extern PTR              DBA_GetDataFromDynFldData(DATATYPE_ENUM, DBA_DYNFLDDATA_UN &);   /* PMSTA-nuodb - LJE - 190425 */
extern size_t           DBA_GetDataSizeFromDynFldData(DATATYPE_ENUM, DBA_DYNFLDDATA_UN&);   /* PMSTA-49178 - LJE - 220906 */
extern RET_CODE         DBA_GetAdmDictFct (OBJECT_ENUM , OBJECT_ENUM *, DICT_T *);   /* FPL-REF10253-040504 */  /*  FPL-PMSTA12499-110818 DICT_FCT_ENUM*->DICT_T*   */


/* PMSTA-34373 - LJE - 190222 */
extern unsigned int     DBA_GetMDMaxLen(DBA_DYNFLD_STP, FIELD_IDX_T);
extern bool	 			DBA_TruncateStringToMDLength(DBA_DYNFLD_STP, FIELD_IDX_T);
extern bool	 			DBA_TruncateDynStStringToMDLength(DBA_DYNFLD_STP);

extern DATATYPE_ENUM DBA_ConvDataTypeToUniDataType(DATATYPE_ENUM);
extern DATATYPE_ENUM DBA_ConvDataTypeToIsoDataType(DATATYPE_ENUM);
extern DATATYPE_ENUM DBA_ConvUniDataTypeToDataType(DATATYPE_ENUM);
extern FIELD_IDX_T   DBA_GetFieldIdxBySqlName(char*, char*);
extern int           DBA_CheckSynonymCode(char *code, ID_T codifId); /* PMSTA-44466 - DDV - 210324 - Allow # only in synonym's code */

extern ENUM_T           DBA_GetNatureForSelectAll(OBJECT_ENUM);

/************************************************************************
**      BEGIN External definitions attached to : dbalib01.c
*************************************************************************/

extern RET_CODE	                DBA_ConvertCTypeDataToFld(PTR, CTYPE_ENUM, DBA_DYNFLD_STP, int, DATATYPE_ENUM), /* REF8844 - LJE - 030404 */
                                DBA_InitConnect(void),
                                DBA_EndConnection(int),
                                DBA_EndConnection(DbiConnection**, bool isInError = FALSE),
                                DBA_GetDbDate(DATETIME_STP), /* DVP172 */
                                DBA_GetDbDateOnServer(DATETIME_STP, DbiConnection&), /* REF4521 */  /* PMSTA-37366 - LJE - 191112 */
                                DBA_SetConnMaxRows(DbiConnection &, int),
                                DBA_SetConnBindSt(DbiConnection *, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                                DBA_SetNullFlagsAndLength(DbiConnection &, DBI_SMALLINT *, DBI_INT *, DBI_SMALLINT *),
                                DBA_FreeNullFlagsAndLength(DbiConnection&),
                                DBA_CheckConnectNbCoherence(int),
                                DBA_FilterMsgInfos(DbiConnection&, RET_CODE *),
                                DBA_GimmeNetRunning(const char *, short *, short *, short *, short *, short *, short *,
                                                    short *, short *, short *, short *, short *, short *, short *),
                                DBA_CreateTempTables(int *, int),
                                DBA_CreateTempTables(DbiConnection &, int),
                                DBA_InitCreateTempTables(), /* PMSTA-18593 - LJE - 150520 */
                                DBA_InitDictUserMap();      /* PMSTA-28698 - LJE - 180523 */

extern                         RET_CODE DBA_AddCreateTempTables(DICT_ENTITY_STP, DBA_RDBMS_ENUM, const std::string&);

extern int                     DBA_GetMaxAvailConn(void),
							   DBA_GetConnection(DBA_SERVER_TYPE_ENUM, AAAConnectionRole = ROLE_USER),
							   DBA_GetUmnountedConn(void),
                               DBA_GetServiceNameBEFromDB(DbiConnection&, const std::string &, std::string &, std::string &, std::string &, ID_T &), /* PMSTA-41113 - KNI - 270720 */
                               DBA_GetExdClientConnectByCd(DbiConnection& , const char*, const char*, const std::string &, ID_T*,std::string &, std::string &, std::string &, std::string &, std::string &, std::string &); /* PMSTA-nuodb - LJE - 190425 */

extern DBA_SERVER_TYPE_ENUM    DBA_GetConnServerType(int);
extern void                    DBA_UpdTableModifStat(DbiConnection&, OBJECT_ENUM);
extern FLAG_T                  DBA_IsSubscriptionActive(OBJECT_ENUM object); /* PMSTA15199 - DDV - 121128 - Replace DBA_IsTrustedObject by DBA_IsSubscriptionActive */

extern RET_CODE                DBA_GetFinancialServerVersion(DBA_DYNFLD_STP);

extern int                     DBA_CloseDbiSrvConnection(DbiConnection*);

extern RET_CODE                DBA_GetAllLog(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&);

extern ID_T                     DBA_GetOpIdFromExtOp(const DBA_DYNFLD_STP); /* PMO */
extern FLAG_T                   IS_EXTOP_DATABASE_ID_MISSING(const DBA_DYNFLD_STP);
extern FLAG_T                   IS_EXTOP_DATABASE_ID_PRESENT(const DBA_DYNFLD_STP);
extern ID_T                     GET_EXTOP_DATABASE_ID(const DBA_DYNFLD_STP);

extern void                     DBA_DispatcherRecoveringFusionConnection(const char *); /* PMSTA-10140 - 041110 - PMO */
extern DbiConnection *			DBA_GetDbiConnection(const AAAConnectionDescription&, const AAAConnectionKind & = AAAConnectionKind::StandardConnection);   /* PMSTA-26427 - 240217 - PMO */
extern DbiConnection *			DBA_GetDbiConnection(DBA_SERVER_TYPE_ENUM = SqlServer, AAAConnectionRole = ROLE_USER);
extern DbiConnection *			DBA_GetDbiConnFromConnectNo(int connectNo);
extern DbiConnection *			DBA_GetDbiSrvConnection(AAAConnectionDescription&, const AAAConnectionKind & = AAAConnectionKind::StandardConnection, int level=0);      /* PMSTA-26427 - 240217 - PMO */

extern DbiConnection *			DBA_GetDbiConnFromCommandSt(PTR);
extern DbiConnection *			DBA_GetDbiConnFromConnectionSt(PTR);
extern RET_CODE                 DBA_LoadApplParam(DbiConnection&, ID_T userId);

extern SessionProperties       &DBA_GetConnProviderSessionProperties(const AAAConnectionDescription& desc = AAAConnectionDescription(ROLE_USER));
extern const SessionProperties &DBA_GetConnSessionProperties(DbiConnection &connection);

extern void                     DBA_CopyNullFlagsAndLengthDynFld(DBA_DYNFLD_STP, DBA_DYNST_ENUM, INT_T, short, int); /* PMSTA08801 - DDV - 091209 */
extern RET_CODE                 DBA_GetDbUTCOffset(DbiConnectionHelper &dbiConnHelper, TZ_OFFSET_T *); /* PMSTA-30187 - DDV - 180430 */

extern std::string              DBA_GetCreateTempTables(std::string, DBA_RDBMS_ENUM);
extern std::string              DBA_GetDeleteTempTables(std::string, DBA_RDBMS_ENUM);
extern std::string              DBA_GetTruncateTempTables(std::string, DBA_RDBMS_ENUM);



/************************************************************************
**      BEGIN External definitions attached to : dbadyn.c
*************************************************************************/
extern DBA_GUIDYNST_STP EV_EntityGuiStPtr;
extern OBJECT_ENUM      EV_EntityGuiStNb;          /* PMSTA-15031 - 210912 - PMO */

/***************************
** Macros GET_*GUIST
** return DBA_DYNST_ENUM for administration or edition
** o = OBJECT_ENUM member
***************************/
/* PMSTA-14961 - 110912 - PMO */ /* PMSTA-31875 - DDV - 180910 - Avoid out of bound access when NullEntity (-1) is given. And also change assert */
inline DBA_DYNST_ENUM GET_ADMINGUIST(const OBJECT_ENUM idx)
{
    assert(EV_EntityGuiStNb > idx && idx >= NullEntity);

    return((idx >= InvalidEntity) ? EV_EntityGuiStPtr[idx].admin : NullDynSt);
}
inline DBA_DYNST_ENUM * GET_ADMINGUISTPTR(const OBJECT_ENUM idx)
{
    assert(EV_EntityGuiStNb > idx && idx >= NullEntity);

    return((idx >= InvalidEntity) ?  &(EV_EntityGuiStPtr[idx].admin) : &NullDynSt);
}

inline DBA_DYNST_ENUM GET_EDITGUIST(const OBJECT_ENUM idx) {
    assert(EV_EntityGuiStNb > idx && idx >= NullEntity);

    return((idx >= InvalidEntity) ? EV_EntityGuiStPtr[idx].edit : NullDynSt);
}

inline DBA_DYNST_ENUM * GET_EDITGUISTPTR(const OBJECT_ENUM idx)
{
    assert(EV_EntityGuiStNb > idx && idx >= NullEntity);

    return((idx >= InvalidEntity) ? &(EV_EntityGuiStPtr[idx].edit) : &NullDynSt);
}

extern void     DBA_UpdateDataType(const char*, const int);

extern void     DBA_InitDynStPtr(void),
                DBA_InitObjectAndDynSt(),
                DBA_InitDataTypePtr(void);

extern int      DBA_CopyExtension(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP, int);    /* REF347 - 971020 - DED */
extern void     DBA_ResetGetSetFlg(DBA_DYNFLD_STP, DBA_DYNST_ENUM dynSt);  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
extern void     DBA_ResetGetSetFlg(DBA_DYNFLD_STP);  /* PMSTA-46681 - LJE - 240301 */
extern void     DBA_LogDomainUsage(DBA_DYNFLD_STP, FLAG_T, ID_T, CODE_T);                        /* PMSTA13244 - DDV - 120116 */

extern RET_CODE          DBA_CreateDynStDef(OBJECT_ENUM objectEn = NullEntity, bool = false);            /* REF8844 - LJE - 030303 */
extern RET_CODE          DBA_UpdateDynStMaxLength(void);      /* PMSTA07121 - DDV - 090306 */
extern const char        *DBA_GetDynStCName(DBA_DYNST_ENUM);  /* REF8844 - LJE - 030425 */
extern const char        *DBA_GetObjectCName(OBJECT_ENUM);    /* REF8844 - LJE - 030425 */
extern DBA_CFIELDDEF_STP DBA_GetCFieldDef(DBA_DYNST_ENUM, int, FLAG_T*), /* REF8844 - LJE - 030827 */
                         DBA_GetCFielBySqlName(DBA_DYNST_ENUM, const char *, FLAG_T*); /* PMSTA-13122 - LJE - 120420 */
extern DBA_DYNST_ENUM    DBA_GetDynStByCName(const char *);  /* REF8844 - LJE - 030425 */
extern OBJECT_ENUM       DBA_GetObjectByCName(const char *); /* REF8844 - LJE - 030425 */

extern OBJECT_ENUM       DBA_GetObjectBySqlName(const char *); /* PMSTA-18593 - LJE - 150316 */
extern DBA_OBJDEF_STP    DBA_GetObjDefBySqlName(const char *);  /* PMSTA-18593 - LJE - 151025 */
extern DBA_DYNDEF_DEF_STP DBA_GetDynStDefBySqlName(const char *sqlName, DBA_DYNTYPE_ENUM  dynTypeEnum); /* PMSTA-26108 - LJE - 170912 */
extern std::list<DBA_OBJDEF_STP> &DBA_GetCObjDefList(); /* PMSTA-26250 - LJE - 170327 */

/* REF9789 - LJE - 031231 */
extern RET_CODE    DBA_CreateVirtualObject(OBJECT_ENUM*),
                   DBA_AddFieldToVirtualObject(OBJECT_ENUM, FIELD_IDX_T*, DATATYPE_ENUM, FLAG_T, FLAG_T, const char *);
extern void        DBA_FreeVirtualObject(OBJECT_ENUM),
                   DBA_TestVirtualObjects(void);

extern DBA_DYNDEF_STP   DBA_GetDynDefStTab(const char *);
extern FIELD_IDX_T      DBA_GetIdxFieldName(const DBA_CFIELDDEF_STP, const char *, const FIELD_IDX_T, const FIELD_IDX_T);

extern int DBA_GetCTypeSize(CTYPE_ENUM);
extern void DBA_ResizeMaxLenDataType();

/************************************************************************
**      BEGIN External definitions attached to : dynlib.c
*************************************************************************/

extern RET_CODE DBA_CopyCustSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM);
extern RET_CODE DBA_CopyCustStFlagNoImpact(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM);     /*  FPL-REF9215-030812  */



extern void     DBA_FreeDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM),
                DBA_FreeDynStSupplFld(DBA_DYNFLD_STP, int),
                DBA_SetNullDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM), /* DLA - CSC16664 - 041109 */
                    /* "normal" output */
                DBA_DispDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM, OBJECT_ENUM),
                    /* output in stdout + concatenate in specified file */
                DBA_DispDynStF(DBA_DYNFLD_STP, DBA_DYNST_ENUM, OBJECT_ENUM, char*),/* REF3871 - SSO - 990803 */
                    /* output in stdout + concatenate in specified file with handler */
                DBA_DispDynStFH(DBA_DYNFLD_STP, DBA_DYNST_ENUM, OBJECT_ENUM, std::ostream *),/* REF4111 - SSO - 991221 */
                DBA_DispDynStFHByPtr(PTR, DBA_DYNST_ENUM, OBJECT_ENUM, std::ostream *),
                    /* output in stdout with string args */
                DBA_DispDynStStr(DBA_DYNFLD_STP, char*, char*),/* REF3871 - SSO - 990803 */
                    /* output in stdout + concatenate in specified file with string args */
                DBA_DispDynStStrF(DBA_DYNFLD_STP, const char*, const char*, char*),/* REF3871 - SSO - 990803 */ /* BSA-REF11860-060808 */

                /*< REF9264 - LJE - 030828 */
                DBA_NewDispDynStFH(const DBA_DYNFLD_STP, FILE*, int, const char*, FLAG_T),    /* PMSTA-15184 - 151012 - PMO */
                DBA_DispFieldValue(std::stringstream &, DBA_DYNFLD_STP, FIELD_IDX_T, std::string = "\""),
                DISP(const void *),
                DISP_TAB(const void **, const int, const int),
                DISP_TAB_CSV(const DBA_DYNFLD_STP *, const int, const int, bool = false);
                /*> REF9264 - LJE - 030828 */
extern void DBA_DispDynStToString(DBA_DYNFLD_STP p, std::string &, const int = 0);          /* PMSTA-24985 - 111016 - PMO */
extern void DBA_DispDynStLogFile(DBA_DYNFLD_STP,const char*,const char*); /* BSA-REF11860-060808 */

extern int      N2V(char*),
                DBA_CopyDynSt(DBA_DYNFLD_STP,DBA_DYNFLD_STP, DBA_DYNST_ENUM = NullDynSt),
                DBA_CopyDynStFlagNoImpact(DBA_DYNFLD_STP,DBA_DYNFLD_STP, DBA_DYNST_ENUM),   /*  FIH-REF9215-030617  */
                DBA_CopyDynStNoNoDbF(DBA_DYNFLD_STP,DBA_DYNFLD_STP, DBA_DYNST_ENUM),/* REF4329 - SSO - 000204 */
                DBA_CopyDynStSupplFld(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int), /* REF3729 */
                DBA_CopyDynStWithSetFld(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
                DBA_CopyDynStruct(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNST_ENUM, FLAG_T, FLAG_T, FLAG_T, FLAG_T, bool),   /* FPL-REF9215-030811 FIH forgot to add this comment ! */
                DBA_CmpDynFld(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int, int, DATATYPE_ENUM, char, bool),     /*  HFI-PMSTA-46330-211005  comparaison without taking account of precision for double  */
                DBA_CmpDynFld(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int, int, DATATYPE_ENUM, char),
                DBA_CmpDynFldSyb(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int, int, DATATYPE_ENUM), /* REF3678 - RAK - 990818 */
                DBA_CmpDynSt2(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNST_ENUM, FLAG_T, FLAG_T) , /* REF10175 - DDV - 041015 */   /*  FPL-REF10596-041020 */
                DBA_CmpDynRelevantFields(DBA_DYNFLD_STP,DBA_DYNFLD_STP,OBJECT_ENUM),            /*  HFI-PMSTA-38206-201128  */
                DBA_CopyDynFld(DBA_DYNFLD_STP, DBA_DYNST_ENUM, int, DBA_DYNFLD_STP, DBA_DYNST_ENUM, int),
                DBA_CopyDynFld(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP, int),
                DBA_CopyDynFldFlagNoImpact(DBA_DYNFLD_STP, DBA_DYNST_ENUM, int, DBA_DYNFLD_STP, DBA_DYNST_ENUM, int),   /*  FPL-REF9215-030812  */
                DBA_CopyDynStNoUDF(DBA_DYNFLD_STP , DBA_DYNFLD_STP , DBA_DYNST_ENUM), /* REF5031 SKE 000728 */
				DBA_CopyDynStDisableDomainTrace(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNST_ENUM), /* PMSTA-23209 - DDV - 160622 */
                DBA_StrCmp(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP, int),	/* BUG268 */
                DBA_StrToData(const char *, DBA_DYNFLD_STP, int);
/*<REF9751-EFE-050120*/

extern          void DBA_CopyDynFldNoImpact(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP, int); /* PMSTA-46681 - LJE - 230913 */
extern          void DBA_GetFieldValue(char *, size_t, DBA_DYNFLD_STP, FIELD_IDX_T fld, FLAG_T);

extern          void DBA_GetFieldDataType(char *, DBA_DYNFLD_STP, FIELD_IDX_T, DBA_CFIELDDEF_STP, FLAG_T);
extern			void DBA_GetDataTypeEnumToStr(char*, DATATYPE_ENUM); /* PMSTA-16395 - TGU - 150720 */
extern          void DBA_GetFieldName( char *, DBA_CFIELDDEF_STP );
/*>REF9751-EFE-050120*/

/* REF9303 - LJE - 030903 */
extern char       *DBA_GetVarStringASCII(DBA_DYNFLD_STP, int);
extern void        DBA_SetVarStringASCII(DBA_DYNFLD_STP, int, const char *);
extern void        DBA_SetVarStringXML(DBA_DYNFLD_STP, int, const char *);        /*  HFI-PMSTA-12258-110621  */

extern char		  *DBA_SetFldToDefaultCharSet(DBA_DYNFLD_STP, int);	/* PMSTA-27969 - CMILOS - 290817 */
extern char       *DBA_FldToStr(char*, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, char);
extern const char *DYN_V2N(DBA_DYNST_ENUM),*OBJ_V2N(OBJECT_ENUM), /* DLA - REF8728 */
                  *FIELD(DBA_DYNFLD_STP, FIELD_IDX_T); /* REF8844 - LJE - 030828 */

/************************************************************************
**      BEGIN External definitions attached to : dbalib02.c
*************************************************************************/
typedef struct
{
OBJECT_ENUM         mainEntity;
OBJECT_ENUM         dbAccessEntity;
DBA_DYNST_ENUM      all_inputStEn;
DBA_DYNST_ENUM      sho_inputStEn;
DBA_DYNST_ENUM      all_outputStEn;
DBA_DYNST_ENUM      sho_outputStEn;

FIELD_IDX_T A_ScriptSt_Id;
FIELD_IDX_T A_ScriptSt_AttrDictId;
FIELD_IDX_T A_ScriptSt_ObjId;
FIELD_IDX_T A_ScriptSt_NatEn;
FIELD_IDX_T A_ScriptSt_Rank;
FIELD_IDX_T A_ScriptSt_Def;
FIELD_IDX_T A_ScriptSt_DimEntityDictId;
FIELD_IDX_T A_ScriptSt_ScriptEntRefDictId;
FIELD_IDX_T A_ScriptSt_ActionEn;

FIELD_IDX_T S_ScriptSt_Id;
FIELD_IDX_T S_ScriptSt_AttrDictId;
FIELD_IDX_T S_ScriptSt_ObjId;
FIELD_IDX_T S_ScriptSt_NatEn;
FIELD_IDX_T S_ScriptSt_Rank;
FIELD_IDX_T S_ScriptSt_ActionEn;
} DBA_SCRIPT_DYN_ST, *DBA_SCRIPT_DYN_STP;

inline bool DBA_isScriptObject(OBJECT_ENUM objEn)
{
    if (objEn == ScriptDef ||
        objEn == HoldingConstraintScript ||
        objEn == TradingConstraintScript)
    {
        return true;
    }
    return false;
}

inline bool DBA_isScriptDynSt(DBA_DYNST_ENUM dynStEn)
{
    if (DBA_isScriptObject(GET_OBJ_DYNST(dynStEn)))
    {
        return true;
    }
    return false;
}


extern RET_CODE
    DBA_LoadFormats(DICT_T, ID_T, DICT_T, int, char*, PTR*),
    DBA_CheckConstList(ID_T, DBA_DYNFLD_STP, DBI_INT*),
	DBA_DynSqlStrPrep(std::string &sqlExecString, DBA_RDBMS_ENUM rdbmsEn, std::set<OBJECT_ENUM> *objectEnumSetPtr = nullptr),        /* PMSTA-28698 - LJE - 180706 */
    DBA_SqlExec(const char *, int, int), /* DLA - REF8728 */
    DBA_SqlExec(const char *sqlBuff, DbiConnection& dbiConn, bool bMultiCmd = false), /* PMSTA-18593 - LJE - 151130 */
    DBA_Fetch(DbiConnection&, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
    DBA_FreeDynStTab(DBA_DYNFLD_STP *, int, DBA_DYNST_ENUM = NullDynSt),
    DBA_FreeDynStVector(std::vector<DBA_DYNFLD_STP> &, DBA_DYNST_ENUM),
    DBA_FreeFinFctResults(DBA_DATARESULT_STP *, FLAG_T),
    DBA_GetDomainFctResults(DBA_DATARESULT_STP *, DBA_DYNFLD_STP),
    DBA_GetFinFctResults(DBA_DATARESULT_STP *, DBA_DYNFLD_STP, PTR),
    DBA_GetRecordByCd(OBJECT_ENUM, CODE_T, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, MemoryPool &mp, DbiConnectionHelper* connHelper = nullptr),
    DBA_GetRecordById(OBJECT_ENUM, ID_T, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, MemoryPool &mp, DbiConnectionHelper* connHelper = nullptr), /* PMSTA9740 - DDV - 100527 */
    DBA_ReadFinFctResults(DbiConnection&, DBA_DATARESULT_STP *),
    DBA_GetScptDef(DBA_DYNFLD_STP),
    DBA_GetScptDef(DBA_DYNFLD_STP, DbiConnection&),     /* REF5396, GRD - 001107. */
    DBA_SetScptDef(DBA_DYNFLD_STP, OBJECT_ENUM, OBJECT_ENUM, DBA_SCPTERRINFO_STP, DbiConnection &dbiConn),
    DBA_TestScptDef(DBA_DYNFLD_STP, OBJECT_ENUM),               /* FPL-REF8794-030218 */
    DBA_LoadSearchFormat(DBA_DYNFLD_STP, PTR *),		/* DVP219 - RAK - 970106 */
    DBA_LoadOper(ID_T, DBA_DYNFLD_STP *, OBJECT_ENUM *),
    DBA_GetRecordIdByCd(OBJECT_ENUM, CODE_T, ID_T *, DBA_DYNST_ENUM, int *, int),      /* PMSTA-32170 - JPR - 180801 */
    DBA_GetRecordCdById(OBJECT_ENUM, ID_T, CODE_T, PTR),
    DBA_SelectByListId(ID_T, OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP**, int, int, int*, int*),
    DBA_APAOptimLevel(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&), /* PMSTA-19118 - LJE - 0141201 */
    DBA_GetScriptDef(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&),
    DBA_GetHCParamDef(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&), /* PMSTA-30575 - CHU - 180319 */
    DBA_GetTCParamDef(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&), /* PMSTA-30575 - CHU - 180319 */
    DBA_GetScptDefAct(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&),                 /*  FPL-PMSTA10714-110202   */
    DBA_GetScriptLibDefByCodeSqlName(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnectionHelper&), /* REF11296 - LJE - 060620 */
    DBA_EndTransaction(int, const FLAG_T),
    DBA_BeginTransaction(int),
    DBA_GetNewDocIndex(DICT_T, ID_T, DATETIME_T, int, DBA_DYNFLD_STP),/* REF10603 - TEB - 041129 */ /* REF4229 - SSO - 000105 */
	DBA_GetNewDocIndexCodeFlag(ENUM_T, FLAG_T&), /* PMSTA-28686 - Silpakal - 190227 */
    DBA_GetApplMsgText(const CODE_T, DICT_T, APPLMSG_ENUM, DBA_DYNFLD_STP), /* Ref.: DVP061 */ /* DLA - REF8728 */
    DBA_GetShortByCd(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr),/* REF550 - 971114 - GRD */
    DBA_GetAllByTechKey(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *), /* REF1054 - 980316 - GRD */
    DBA_GetDfltCashInstrByCurr(PTR, DBA_DYNFLD_STP, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*),	/* PMSTA00485 - RAK - 061121 */
    DBA_GetPtfById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int *),  /* REF3913 - RAK - 990826 */
    DBA_GetStratById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int *),  /* REF9340 - DDV - 030821 */
    DBA_GetGridById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* REF7420 - RAK - 021031 */
    DBA_GetPPSById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int *),  /* REF4347 - 001124 - DED */
    DBA_GetListById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* REF10176 - LJE - 041125 */
    DBA_GetThirdById(ID_T, FLAG_T, FLAG_T*, DBA_DYNFLD_STP*, PTR, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* PMSTA06916 - LJE - 081105 */
    DBA_GetPtfSysCurrIdById(ID_T, PTR, ID_T*, DbiConnection* = nullptr),    /* REF4332 - RAK - 000210 */
    DBA_HandleAutocreateStack(DBA_DYNFLD_STP, DbiConnection&, FLAG_T, FLAG_T), /* PMSTA-35191 - JPR - 190319 */
    DBA_RestoreAutocreateContext(DBA_DYNFLD_STP, DBA_DYNST_ENUM), /* REF9112 - LJE - 030516 */
    DBA_SendExportRequest(DBA_EXPORT_STP), /* DLA - REF7264 - 020131*/
    DBA_GetExportedData(DBA_EXPORT_STP, DBA_DYNFLD_STP), /* DLA - REF7264 - 020131*/
    DBA_FreeDataInExportCtx(DBA_EXPORT_STP, FLAG_T), /* DLA - REF7264 - 020131*/
    DBA_GetConstrInfo(DICT_T, ID_T, ID_T*, DBA_DYNFLD_STP**, int*, int, int*, DBA_ERRMSG_INFOS_STP = nullptr),  /* REF7289 - LJE - 020606 */
    DBA_SelectConstrTemplateElt(ID_T, DBA_DYNFLD_STP**, int*, int, int, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* REF7289 - LJE - 020606 */
    DBA_GetConstrTemplateAll(ID_T, DBA_DYNFLD_STP*, DBA_DYNFLD_STP*, DBA_DYNFLD_STP**, int*, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* REF7289 - LJE - 020606 */
    DBA_GetConstrTemplate(ID_T, DBA_DYNFLD_STP*, int, int, int*, DBA_ERRMSG_INFOS_STP = nullptr), /* REF7289 - LJE - 020606 */
    DBA_UpdateCdByIdInDynSt(DBA_DYNFLD_STP, OBJECT_ENUM, int, int, PTR),
    DBA_BuildObjectListByListId(DBA_DYNFLD_STP),
    DBA_LoadPanels (DICT_T, DBA_HIER_HEAD_STP*, DICTPANELNAT_ENUM),                                   /*  FIH-REF11425-051027 */
    DBA_ManagedSqlExec(AAASQL_CONTEXT_STP context, int* status), /* PMSTA-18593 - LJE - 151021 */
    DBA_CallRpcMergeSession(DBA_DYNFLD_STP),                                            /*  HFI-PMSTA-18895-141113  */
    DBA_BuildListCompoDelete(DBA_DYNFLD_STP),                                           /* PMSTA-26108 - DDV - 170906 */
    DBA_BuildListCompoBuild(DBA_DYNFLD_STP),                                            /* PMSTA-26108 - DDV - 170907 */
    DBA_SetScriptDynStConfig(OBJECT_ENUM, DBA_SCRIPT_DYN_STP);                          /* PMSTA-28970 - CHU - 171215 */

extern RET_CODE DBA_GetObjDefValScptDefByAttr(OBJECT_ENUM, SYSNAME_T, ID_T, char **); /* PMSTA28705 - DDV - 180209 */

extern void   DBA_FillDataType(DBA_DATASET_STP);	/* MRA - 000307 - REF4481 */
extern FLAG_T DBA_CheckIfListHistorised(ID_T, int, int*);

extern DBA_WORK_ON_CLOSE_CONNECTION_STP DBA_CreateWorkOnCloseConnection(void);
extern FLAG_T DBA_AddWorkOnCloseConnection(DbiConnection&, DBA_WORK_ON_CLOSE_CONNECTION_STP);
extern void DBA_FreeWorkOnCloseConnection(DBA_WORK_ON_CLOSE_CONNECTION_STP);
extern int  DBA_GetScriptNumOfBlocks (char*);       /*  HFI-PMSTA-19072-150130  */

extern void DBA_UpdateServerPoolCompo(ID_T);     /* PMSTA-39659 - ankita - 05082020 */

/*****************************************************************/
/* Manage Household Portfolio Lists - PMSTA-46692 - CHU - 110222 */
/*****************************************************************/
extern RET_CODE DBA_LoadStratDataFromHousehold(DBA_HIER_HEAD_STP);
extern RET_CODE DBA_ManageHouseholdFromPtfs(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP /*ID_T *, int, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP **, int *, bool*/);

/***********************************************************************
**      BEGIN External definitions attached to : dbalib03.c
*************************************************************************/
typedef struct
{
    DBA_ACCESS_STP accessStp;
    int            accessAllocSz;  /* rem : si + de blanc, pas utile ! */
    int            accessNbr;
    int            insertNbr;
    int            startPtf;
    int            crtPtf;
    FLAG_T		    onlyOnePtfFlg;
    FLAG_T         delSynthFlg;
    char           *updPtfSql;         /* REF5392 - RAK - 001227 */
    int            updPtfSqlSz;        /* REF5392 - RAK - 001227 */
    DATETIME_T     oldSynthLastFD;     /* REF5392 - RAK - 001227 */
    DATETIME_T     oldSynthRecalcD;    /* REF5392 - RAK - 001227 */
} DBA_INSPTFSYNTH_ST, *DBA_INSPTFSYNTH_STP;

typedef struct
{
    DBA_DYNFLD_STP *paTab;
    int            paNbr;
    DBA_DYNFLD_STP *extRaTab;
    int            extRaNbr;
    DBA_DYNFLD_STP *stdPerfTab;
    int            stdPerfNbr;
	DBA_DYNFLD_STP *PerfCalcResTab;
	int            PerfCalcResNbr;
    DBA_ACCESS_STP accessStp;
    int            accessNbr;
    DBA_ACCESS_STP accessSecStp;     /* REF8798/REF8874 - YST - 030612 */
    int            accessSecNbr;      /* REF8798/REF8874 - YST - 030612 */
    DBA_ACCESS_STP storagePtfCompoTab;
    int            storagePtfCompoNbr;
} DBA_INSPAEXTRA_ST, *DBA_INSPAEXTRA_STP;

typedef enum {
    ListMgmFct_LoadPos,
    ListMgmFct_LoadStratLnk,
    ListMgmFct_Build,
    ListMgmFct_SelId,
    ListMgmFct_SelShort,
    ListMgmFct_SelAll,
    ListMgmFct_LoadEvtGenInstr, /* REF125 - XDI - 971217 - no position load */
    ListMgmFct_ObjectList,       /* PMSTA-34444 - LJE - 190205 */
    ListMgmFct_DataOrga          /* PMSTA-34445 - LJE - 190205 */
} SERV_LISTMGMFCT_ENUM;

extern RET_CODE DBA_DelPtfSynth(DATETIME_T, DATETIME_T, DBA_DYNFLD_STP*, int, int, int),
                DBA_InsManagerById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdManager(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_InsThirdById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdThird(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_InsApplCommentById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdApplComment(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdEventStatus(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&), /* PMSTA-17266 - DDV - 140128 */
                DBA_InsDomainById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdDomain(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_DelPtfSynthOnePtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, int),
                DBA_NewFctResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int*),
                DBA_InsDictFunctionById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdDictFunctionById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_InsApplUserById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_UpdApplUser(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_CheckDbAdminUser(SYSNAME_T, const PasswordEncrypted&),
                DBA_CheckDynStNumbers(DBA_DYNST_ENUM, DBA_DYNFLD_STP, int *),
                DBA_ChangePasswd(SYSNAME_T, PasswordEncrypted&, SYSNAME_T, PasswordEncrypted&), /* DLA - PMSTA09887 - 101115 */
                DBA_ModifyUserPasswordByBatch(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&), /* DLA - PMSTA-10948 - 101123 */
                DBA_GroupScriptDef(DBA_DYNFLD_STP*, int, char, char, DBA_DYNFLD_STP**, int*),			/* BUG165 */
                DBA_HideMagicDate(DBA_DYNFLD_STP, DBA_DYNST_ENUM),
                DBA_InsPtfSynth(DBA_DYNFLD_STP, PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PTR, DBA_INSPTFSYNTH_STP, FLAG_T),
                DBA_SelExtStratElt(ID_T, ID_T, ID_T, DBA_DYNFLD_STP, DATETIME_T, int, DBA_DYNFLD_STP*, int*, DBA_DYNFLD_STP),     /*  FPL-PMSTA05599-100122 add mktSeg  */
                DBA_SelHedgeRule(ID_T, ID_T, DBA_DYNFLD_STP, DATETIME_T, int, DBA_DYNFLD_STP*, int*, DBA_DYNFLD_STP),     /* PMSTA-44959 - LIK - 210429 */
                DBA_SetMagicDate(DBA_DYNFLD_STP, DBA_DYNST_ENUM, OBJECT_ENUM),
                DBA_InsScptDef(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
                DBA_CopyFtRate(OBJECT_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),	/* REF1598 */
                DBA_ScreenSelect(DICT_T,OBJECT_ENUM,DBA_DYNFLD_STP,DBA_DYNFLD_STP*,DBA_DYNFLD_STP*,int),
                DBA_GetCalendarFromInstr(DBA_DYNFLD_STP, ID_T*),	/* REF1055 */
                DBA_FamilyOrder(EXTOP_ACTION_ENUM,
                                DBA_DYNFLD_STP*,
                                int,
                                int,
                                RET_CODE (*fct)(FLAG_T, EXTOP_ACTION_ENUM, DBA_DYNFLD_STP *, int, int, int *, PTR), /* REF7264 - PMO */
                                PTR,
                                int,
                                DbiConnectionHelper&, /* PMSTA-26888 - CHU - 170629 */
                                DICT_T,
                                DBA_DYNFLD_STP,
                                DBA_DYNFLD_STP*, int, /* PMSTA07121-CHU-081030 added CaseManagement records */
                                DBA_DYNFLD_STP*,		/* PMSTA09118-CHU-1001221 draft Fct Result (publish_session) */
                                PTR, /* PMSTA-28596 - CHU - 171012 */
                                bool), /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
                DBA_LogSubscriptionEvents(OBJECT_ENUM, SUBSCRIPTION_ACTION_ENUM, DBA_DYNST_ENUM,
                                DBA_DYNFLD_STP, DBA_DYNFLD_STP, DbiConnection &, DBA_DYNFLD_STP *, int),						/* REF4204 */
                DBA_SendSubscriptionMulti( const int, DbiConnection &, const int),                              /* PMSTA-52258 - JBC - 230308 */
                DBA_StratUpdateModel(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&); /* REF4888 - 000613 - SKE */
extern void     DBA_FreeSubscriptionBlock(DbiConnection &);                                                     /* PMSTA-52258 - JBC - 230308 */
extern RET_CODE DBA_UpdStandInstructLastEventGenDate(DBA_DYNFLD_STP*, int); /* PMSTA06761 - DDV - 080807 */
extern FLAG_T   DBA_GetSubsCodif(DICT_T, ID_T *, DbiConnection&);    /* REF4204 */
extern FLAG_T   DBA_ScreenSelectConfirm(OBJECT_ENUM, DICT_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP, FLAG_T);      /*  FPL-PMSTA09056-091126   */
extern FLAG_T   DBA_ScreenSelectConfirmOne (OBJECT_ENUM, DICT_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, FLAG_T);   /*  FPL-PMSTA09056-091126   */
extern RET_CODE DBA_GetEventGroupingCode(CODE_T); /* PMSTA-17793 - DDV - 140318 */
extern RET_CODE DBA_NewSplitSession(DBA_DYNFLD_STP **, int *, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP *, int *, PTR); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE DBA_UpdatePtfLastRebalancingInfo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnectionHelper&); /* PMSTA-30897 - CHU - 180504 */


extern FLAG_T   DBA_IsPtfSynthToInsert(DBA_DYNFLD_STP); /* PMSTA-00948 - LJE - 070328 */

extern void DBA_SetTascJobPtfDim(DBA_DYNFLD_STP, int*); /* PMSTA08246 - LJE - 090722 */ /* PMSTA09899-CHU-100521 */ /* OCS-49362 - TEB - 170508 */
extern void DBA_RestorePtfDim(DBA_DYNFLD_STP); /* PMSTA09899-CHU-100521 */

extern bool     DBA_IsDboUser(DbiConnection       *dbiConn = nullptr);  /* PMSTA-28698 - LJE - 180523 */
extern bool     DBA_IsTascTechUser();                                   /* PMSTA-28698 - LJE - 180523 */

extern bool     DBA_IsDboUser(const std::string &user);        /* PMSTA-37366 - LJE - 200429 */
extern bool     DBA_IsTascTechUser(const std::string &user);   /* PMSTA-37366 - LJE - 200429 */

/* PMSTA-34344 - LJE - 201218 */
extern void     DBA_GetDboUser(std::string &user);
extern void     DBA_GetTascTechUser(std::string &user);
extern void     DBA_GetProxyUser(std::string &user);

extern DICT_T  DBA_GetQuestionnaireScreen(DICT_ENTITY_STP); /* PMSTA-19243 - DDV - 150427 */

extern FLAG_T DBA_GetOrderCodeInSessionSysParam(void); /* PMSTA-25183 - CHU - 161108 */

/* PMSTA-26108 - LJE - 170828 */
extern void DBA_GetConnAllowedBusEntity(DbiConnectionHelper &connHelper, DBA_DYNFLD_STP **busEntityCompoTab, int *busEntityCompoNbr);
extern void DBA_GetDefConnBusEntity(DbiConnectionHelper &connHelper, std::string &defBusEntityStr);
extern RET_CODE DBA_NewCaseSplitSession(DBA_DYNFLD_STP **,
                                        int *,
                                        DBA_DYNFLD_STP **,
                                        int,
                                        DBA_DYNFLD_STP **,
                                        int,
                                        DBA_DYNFLD_STP **,
                                        int,
                                        FLAG_T **,
                                        DBA_DYNFLD_STP,
                                        DBA_DYNFLD_STP **,
                                        int *,
                                        int *,
                                        PTR);
extern RET_CODE SERV_ListMgm(SERV_LISTMGMFCT_ENUM, DICT_T, ID_T, char *, DbiConnection &, DBA_DYNFLD_STP);
extern RET_CODE DBA_SelectPtfIdByDomain(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*);				/* DVP261 */
extern int DBA_LoadPosDropTempTables(DbiConnection&, DICT_FCT_ENUM);

extern RET_CODE DBA_LoadPerfCalcDef(DBA_HIER_HEAD_STP hierHead, DBA_DYNFLD_STP **perfCalcDefTab, int *perfCalcDefNbr); /* PMSTA47578 - DDV - 220215 */

extern RET_CODE DBA_LoadPerfCalcDefByProfileId(DBA_HIER_HEAD_STP hierHead, ID_T perfCalcDefProfileId, DBA_DYNFLD_STP **perfCalcDefTab, int *perfCalcDefNbr, DBA_DYNFLD_STP *perfCalcDefProfilePtr);/*PMSTA-51082 - SenthilKumar - 042423*/
extern RET_CODE DBA_SelPerfCalcDefCompoByProfileId(DBA_HIER_HEAD_STP hierHead, ID_T perfCalcDefProfileId, DBA_DYNFLD_STP** perfCalcDefCompoTab, int* perfCalcDefCompoNbr, MemoryPool & mpParam); /* PMSTA-54529 - DDV - 231010 - Use domain's perf_calc_def_profile */

extern RET_CODE DBA_FillDomPortByDomain(DBA_DYNFLD_STP domainPtr, bool bAllowRebuild, bool bManageEnumList, DbiConnectionHelper& dbiConnHelper); /* PMSTA-54517 - DDV - 230928 */

/************************************************************************
**      BEGIN External definitions attached to : dbalib04.c
*************************************************************************/

extern RET_CODE
            DBA_InsertByBlock(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, int, DbiConnection&, int),
            DBA_InsertByBlock(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, int, int),
            DBA_MultiAccess(DBA_ACCESS_STP, const int, int, int, DbiConnection&),
            DBA_MultiAccess(DBA_ACCESS_STP, const int, int, int, int *),
            DBA_HandleOperTabByBlock(DbiConnection&, DBA_ACCESS_STP, int, int, int, int, bool bStoreErrMsgInElt = false),
            DBA_HandleOperTab(DbiConnection&, DBA_ACCESS_STP, int *, int, int, bool bStoreErrMsgInElt = false),
            DBA_FreeOperTabForBlockHandling(DbiConnection&, DBA_ACCESS_STP, int, int, int);

extern int DBA_GetDynStMaxLen(DBA_DYNST_ENUM);

extern RET_CODE DBA_AddElemToBlockModeSt( DBA_ACTION_ENUM  ,
                                          int              ,
                                          OBJECT_ENUM      ,
                                          DBA_DYNST_ENUM   ,
                                          DBA_DYNFLD_STP   ,
                                          DbiConnection&);

extern std::string DBA_GetActionName               (const DBA_ACTION_ENUM &);
extern std::string DBA_GetDictEntitySqlOrObjectName(const OBJECT_ENUM &, const DBA_DYNST_ENUM &);

/************************************************************************
**      BEGIN External definitions attached to : dbalib05.c
*************************************************************************/

extern RET_CODE DBA_Notif(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int *, int);
extern RET_CODE DBA_Notif(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnection&, int);
extern RET_CODE DBA_Notif(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper &);

extern RET_CODE
    DBA_Cancel(DbiConnection&),
    DBA_Check(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Check(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Check(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_MultiFree(DBA_DYNFLD_STP **, const DBA_DYNST_ENUM **, int *, int), /* REF8844 - LJE - 030415 */
    DBA_CopyAutomatic(OBJECT_ENUM, OBJECT_ENUM, ID_T, ID_T, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_Copy(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Copy(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Copy(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_Get2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Get2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, DbiConnection&,DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_Get2(OBJECT_ENUM, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DbiConnection*),
    DBA_Insert2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Insert2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_Insert2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_InsUpd(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_InsUpd(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_InsUpd(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_Update2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Update2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_Update2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_Delete2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Delete2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_Delete2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_Select2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
                DBA_DYNST_ENUM, DBA_DYNFLD_STP **, int, int, int *, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Select2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
                DBA_DYNST_ENUM, DBA_DYNFLD_STP **, int, int, int *, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr, DBA_ERRMSG_HEADER_STP = nullptr),/* PMSTA-49780- BSV- 040722 */
    DBA_Select2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
                DBA_DYNST_ENUM, DBA_DYNFLD_STP **, int, int *, DbiConnectionHelper&),
    DBA_MultiSelect2(OBJECT_ENUM, int, DBA_DYNST_ENUM,
                     DBA_DYNFLD_STP, const DBA_DYNST_ENUM**, DBA_DYNFLD_STP **, int,
                     int, int *, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_MultiSelect2(OBJECT_ENUM, int, DBA_DYNST_ENUM,
                     DBA_DYNFLD_STP, const DBA_DYNST_ENUM**, DBA_DYNFLD_STP **, int,
                     int, int *, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_MultiSelect2(OBJECT_ENUM, int, DBA_DYNST_ENUM,
                     DBA_DYNFLD_STP, const DBA_DYNST_ENUM**, DBA_DYNFLD_STP **, int,
                     int, int *, DbiConnectionHelper&, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Notif2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, /* DVP196 970131 GRD */
               int, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Notif2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
               int, DbiConnection&, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Notif2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
               int, DbiConnectionHelper &, DBA_ERRMSG_INFOS_STP),
    DBA_Notif2(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
               DbiConnectionHelper&),
    DBA_Purge(int, DBA_DYNST_ENUM, DBA_DYNFLD_STP,              /* PMSTA15008-JPP-20120920 */
              int, int *, int *, DBA_ERRMSG_INFOS_STP = nullptr),
    DBA_Truncate(OBJECT_ENUM, int, int, int *, int *, DBA_ERRMSG_INFOS_STP = nullptr); /* PMSTA15008-JPP-20120920 */


/* PMSTA-34200 - LJE - 190111 */
extern void DBA_SetTimeout(DBA_PROC_STP procedure, DbiConnection * dbiConn);
extern RET_CODE DBA_SendMesgForProcResType(const char *procName, int resultType);

extern RET_CODE DBA_ReconnectIfNeed(DbiConnection&);
extern int  DBA_ReadSqlBlockResult(DbiConnection& , const DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern void DBA_SetFieldTimeStamp(const DBA_DYNST_ENUM, DBA_DYNFLD_STP, const TIMESTAMP_T);
extern void DBA_LogMesgProcedureNotFound(   DBA_ACTION_ENUM ,
                                            OBJECT_ENUM     ,
                                            int             ,
                                            DBA_DYNST_ENUM  ,
                                            DBA_DYNFLD_STP  ,
                                            DBA_DYNST_ENUM  ,
                                            bool            , 
                                            const char *    ,
                                            const char *    ,
                                            const char *    ,
                                            const char *   );

/*  Copy management: set null value on some field and cascade copy */   /*  HFI-PMSTA-41842-200916  */
typedef struct
{
    DICT_ENTITY_STP pdictent;
    ID_T            idFrom;
    ID_T            idTo;
    DBA_DYNFLD_STP  pdbadyn;
} DBA_COPY_OBJ_ST, *DBA_COPY_OBJ_STP;

extern void     DBA_SetNullAttribWhileCopying (DBA_DYNFLD_STP, OBJECT_ENUM, FLAG_T**, FLAG_T);
extern RET_CODE DBA_CopyCascadeManageCrossRef (DBA_COPY_OBJ_STP*, int, DBA_DYNFLD_STP, OBJECT_ENUM, DbiConnectionHelper& );
extern RET_CODE DBA_CopyOneEntity (DBA_COPY_OBJ_STP**, int *, DICT_ENTITY_STP, DICT_ENTITY_STP, DICT_ATTRIB_STP, ID_T, ID_T, DBA_DYNFLD_STP, DbiConnectionHelper&);



/************************************************************************
**      BEGIN External definitions attached to : dbalib06.c FPL-REF8928-030605
*************************************************************************/

extern  char*       DBA_GetStringFromDynStp ( DBA_DYNFLD_STP , OBJECT_ENUM , FLAG_T, FLAG_T, FLAG_T);                   /*  HFI-PMSTA-41842-200916  Add onlyBusinessKeyFlg  */
extern  RET_CODE    DBA_GetDynStpFromString ( OBJECT_ENUM, FLAG_T, char *, DBA_DYNFLD_STP *);
extern  RET_CODE    DBA_SetDomainObjId      ( char *, DBA_DYNFLD_STP);
extern  FLAG_T      DBA_CheckSecuCheck      ( DBA_DYNFLD_STP, DBA_DYNFLD_STP, ADMIN_RIGHTS_ENUM, OBJECT_ENUM, PTR, FLAG_T, FLAG_T, FLAG_T);
extern  FLAG_T      DBA_IsDeletedAttribute  ( OBJECT_ENUM, char *);  /* PMSTA-16528 - DDV - 140703 - Avoid error on deleted attribute (format_element.search_key_e) */
extern  RET_CODE    DBA_SetDynFldFromString (DATE_STYLE_ENUM, const std::string&, DBA_DYNFLD_STP, const FIELD_IDX_T);

extern  RET_CODE    DBA_EvalFilterScript(const char*, DBA_DYNFLD_STP, DICT_T, DbiConnection*, DBA_DYNFLD_STP**, int*, bool); /* PMSTA-46681 - LJE - 240129 */

extern  bool        DBA_EvalCheckScript(const char*, DBA_DYNFLD_STP);


/***********************************************************************
**      BEGIN External definitions attached to : dbachro.c
*************************************************************************/

extern RET_CODE DBA_GetCurrChrono(ID_T, ID_T, DATETIME_T, CURRCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP),
                /* REF4306 - CSY - 000315 */
                DBA_GetCurrChronoFromHier(ID_T, ID_T, DATETIME_T, CURRCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                DBA_SetDimChrono(ID_T, DATETIME_ST, NUMBER_T, FLAG_T, ID_T, CHRONONAT_ENUM, ID_T, ID_T, NUMBER_T, int, char *), /* REF10598 - LJE - 041011 */
                DBA_GetDimChrono(DBA_DYNFLD_STP, DBA_DYNFLD_STP),	/* REF1065 */
                DBA_GetChronoVal(OBJECT_ENUM, ID_T, ID_T, ENUM_T, DATETIME_T, TIMEDIM_ENUM, char, NUMBER_T*),
                DBA_GetInstrChrono(ID_T, DATETIME_T, CHRONONAT_ENUM, ID_T, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP), /* REF10598 - LJE - 041011 */
                DBA_GetPortChrono(ID_T, ID_T, DATETIME_T, PTFCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP),
                DBA_GetListChrono(ID_T, ID_T, DATETIME_T, LISTCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP), /* REF7292 - LJE - 020213 */
                /* REF4306 - CSY - 000314 */
                DBA_GetPortChronoFromHier(ID_T, ID_T, DATETIME_T, PTFCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                DBA_GetComplianceChronoFromHier(DBA_DYNFLD_STP, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP), /* PMSTA06646 - LJE - 080530 */
                DBA_GetComplianceChrono(DBA_DYNFLD_STP, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP), /* PMSTA06646 - LJE - 080530 */
                DBA_GetThirdChrono(ID_T, ID_T, DATETIME_T, THIRDCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP),
                DBA_GetThirdChronoFromHier(ID_T, ID_T, DATETIME_T, THIRDCHRONONAT_ENUM, TIMEDIM_ENUM, FLAG_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                DBA_InstrChronoByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int, ID_T, ENUM_T, ID_T, ID_T, FLAG_T, DBA_DYNFLD_STP**, int*), /* REF10598 - LJE - 041011 */
                DBA_PtfChronoByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int, ID_T, ENUM_T, DBA_DYNFLD_STP**, int*),
                DBA_ComplChronoByFreq(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*), /* PMSTA06646 - LJE - 080612 */
                DBA_ListChronoByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int, ID_T, ENUM_T, DBA_DYNFLD_STP**, int*), /* REF7292 - LJE - 020213 */
                DBA_SelectInstrChrono(ID_T, DATETIME_T, DATETIME_T, CHRONONAT_ENUM, ID_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP**, int*),     /* REF10598 - LJE - 041011 */ /* PMSTA-10748 - LJE - 110210 */
                DBA_ThirdChronoByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int, ID_T, ENUM_T, DBA_DYNFLD_STP**, int*),
                /* PMSTA-10748 - LJE - 110211 */
                DBA_SelectInstrChronoInHier(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int*, DBA_DYNFLD_STP**),
                DBA_GetInstrChronoInHier(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*);



/***********************************************************************
**      BEGIN External definitions attached to : dbaexch.c
*************************************************************************/

extern RET_CODE DBA_GetExchRate(DATETIME_T, ID_T, ID_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP,	/* PMSTA01649 - TGU - 070404 */
                    ENUM_T, PTR, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP*,int,DBA_DYNFLD_STP,FLAG_T), /* PMSTA - 41969 - AIS - 201005*/
        DBA_ExchRateByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int,
                                   ID_T, ID_T, ID_T, DBA_DYNFLD_STP, MISSINGDATA_METHOD_ENUM, /* REF7061 - TEB - 021223 */
                                   DBA_DYNFLD_STP**, int*);

extern char 	DBA_GetEuroConversionDate(DATE_T*, int);   /* REF2580 - SSO - 980727 */

extern int  DBA_GetConnectNoFromExchArg(PTR);    /* REF2580 - SSO - 980727 */
/* extern void DBA_SetConnectNoToExchArg(PTR, int); *//* REF2580 - SSO - 980727 */ /* REF4213 - SSO - 991221 */
extern void DBA_InitConnectNoToExchArg(PTR, DBA_HIER_HEAD_STP); /* REF4213 - SSO - 991221 */

typedef enum {
    InterCond_ByDt,
    InterCond_ByIdDt,
    InterCond_PreLoad /* PMSTA02452-CHU-070626 */
} INTERCONDBY_ENUM;

/***********************************************************************
**      BEGIN External definitions attached to : dbainstr.c
*************************************************************************/


extern RET_CODE DBA_GetInstrByIdCd(DBA_DYNFLD_STP, int, int, DBA_DYNFLD_STP*, FLAG_T *,
                                   PTR, int, int *),
                DBA_GetIncEvt(DBA_DYNFLD_STP, DATETIME_T, DBA_DYNFLD_STP),
        DBA_GetInstrYieldCurve(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, FLAG_T*, DBA_HIER_HEAD_STP, ID_T), /* REF3913 */
                DBA_GetTermEvt(DBA_DYNFLD_STP, DATE_T, DBA_DYNFLD_STP),
                DBA_GetDefOption(ENUM_T, ID_T, ID_T, DBA_DYNFLD_STP *),     /* DEV1055 - CSA - 16121999 */
        DBA_GetFinalIOREvt(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP),	/* BUG147 */
        DBA_InstrPriceByFreq(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, int, ID_T, DBA_DYNFLD_STP, ID_T,
            ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, MISSINGDATA_METHOD_ENUM, /* REF7061 - TEB - 021223 */
            DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP, ID_T), /* PMSTA - 32764 - SILPA - 181010 */

        DBA_SelectIncEvt(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP **, int *),
        DBA_SelectIncEvtByNatEn(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP **,
                                int *,INTERCONDNAT_ENUM),/* REF6004 -AKO - 011220 */

        DBA_SelectInstrCompo(ID_T, DATETIME_T, DBA_DYNFLD_STP**, int*),

        DBA_SelectInterCond(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP**, int*, FLAG_T*, DBA_HIER_HEAD_STP),/* REF6004 - AKO -011218 */
        DBA_SelectInterCond2(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP**, int*, FLAG_T*, DBA_HIER_HEAD_STP,INTERCONDNAT_ENUM),

        DBA_SelectIOREvt(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP **, int *),
        DBA_SelectExchEvt(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP **, int *, DBA_HIER_HEAD_STP),
        DBA_SelAllInterCond(INTERCONDBY_ENUM, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, FLAG_T*),
/*        DBA_SelAllInterCond2(INTERCONDBY_ENUM, PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, FLAG_T*,INTERCONDNAT_ENUM),*/ /* REF6004 - AKO - 011218 */
        DBA_UpdInterCondEndDate(DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP),
        DBA_GetInstrById(ID_T, FLAG_T, FLAG_T *, DBA_DYNFLD_STP *, DBA_HIER_HEAD_STP,int,int *),
        DBA_VerifInstrInHier(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP**, int*, DBA_DYNFLD_STP**, int*,DBA_DYNFLD_STP**, int*, DBA_DYNFLD_STP**, int*),
        DBA_UpdInstrFld(DBA_DYNFLD_STP *, int),
        DBA_SelectIOREvtForPEFundShare(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP **, int *, DBA_HIER_HEAD_STP), /*PMSTA-32106 -NRAO 180904*/
        DBA_GetLinkedInstrForPE(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, FLAG_T *, SUBNAT_ENUM), /*PMSTA-32106 -NRAO 180904*/
        DBA_GetLatestIssRedmEvent(ID_T, DATETIME_T, ENUM_T, DBA_DYNFLD_STP *), /*PMSTA-32106 -NRAO 180904*/
        DBA_GetAllLinkedInstrsForPE(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, FLAG_T *), /*PMSTA-32106 -NRAO 180904*/
        DBA_SelectUnderlyingPrices(DBA_HIER_HEAD_STP , DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T*, DATETIME_T*); /* PMSTA-34990 - CHU - 190326 */

extern int DBA_InterCondInstrIdByDtCmp(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
extern void DBA_SetInstrRedmEvent(DBA_DYNFLD_STP, DBA_DYNFLD_STP);	/* PMSTA-10889 - RAK - 110127 */
extern int DBA_CmpDate(DATE_T *, DATE_T *);
extern int DBA_IsPEFundShare(DBA_DYNFLD_STP, SUBNAT_ENUM); /*PMSTA-32106 -NRAO 180904*/

/***********************************************************************
**      BEGIN External definitions attached to : dbaop.c
*************************************************************************/

struct AutomaticFusionStock {
    ID_T *ptfToFuseTab;
    int nbPtfToFuseMax;
    int nbPtfToFuse;
};

/* REF437 SME */
extern RET_CODE DBA_DelExtOpByIdAndFuse(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_InsExtOpByIdAndFuse(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_InsExtOpByIdAndFuse2(DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnection&, FLAG_T),
    DBA_UpdExtOpByIdAndFuse(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);

extern void DBA_ExtOpUpdateTimeStamp(DBA_DYNFLD_STP);

extern RET_CODE DBA_UpdExtOpBeginD(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP); /* PMSTA09451 - DDV - 100305 */

extern RET_CODE DBA_ConvertExtOp2S_Op(DBA_DYNFLD_STP *, const DBA_DYNFLD_STP, const int);       /* REF7560 PMO            */
extern RET_CODE DBA_ConvertExtOp2Adm_Arg(DBA_DYNFLD_STP *, const DBA_DYNFLD_STP, const int);    /* REF9423 - 040216 - PMO */

extern RET_CODE DBA_PerformInsUpdDelExtOp(const DBA_ACTION_ENUM,
                                          DBA_DYNFLD_STP ,
                                          DBA_DYNFLD_STP ,
                                          DBA_DYNFLD_STP ,
                                          DBA_DYNFLD_STP *,
                                          int ,
                                          DbiConnection &,
                                          const FLAG_T,
                                          CODE_T ,
                                          struct AutomaticFusionStock *);

extern RET_CODE DBA_SaveUnmatchedExecution(DbiConnectionHelper&, DBA_DYNFLD_STP);                                   /*  FIH-REF9764-040205  */

extern RET_CODE DBA_InsExecutionById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);       /* REF7560 - 020814 - PMO */
extern RET_CODE DBA_UpdExecution(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);           /* REF7560 - 020814 - PMO */
extern RET_CODE DBA_InsExecutionFeeById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);    /* REF7560 - 020822 - PMO */
extern RET_CODE DBA_UpdExecutionFee(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);        /* REF7560 - 020822 - PMO */

extern RET_CODE DBA_InsUnMatchedExecutionById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int); /* REF9764 - CHU - 031222 */
extern RET_CODE DBA_UpdUnMatchedExecution(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int);     /* REF9764 - CHU - 031222 */

extern RET_CODE DBA_ClosingSecurity(DBA_DYNFLD_STP, FLAG_T, FLAG_T, DATETIME_T, DBA_ERRMSG_INFOS_STP), /* REF2631 - 980902 - DED */
    DBA_FusionRequestAllPtfNewOp(int, int),			/* REF1077 - 980316 - DED */
    DBA_InsOperationById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&),
    DBA_LoadExtOpByHier(DBA_DYNFLD_STP **,int *,const DBA_DYNST_ENUM **,const int,DBA_DYNFLD_STP **,int *), /* WEALTH-6326 - JBC - 20240507 */
    DBA_LoadExtOp(DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, int),	/*DVP247 - 961111 - DED */
    DBA_UpdOperationById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);

extern void 	DBA_ExtPosToBalPos(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        DBA_ExtPosToPos(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        DBA_InverseSign(DBA_DYNFLD_STP);				/* DVP464 - 970522 - DED */
extern void DBA_InversePriceSign(DBA_DYNFLD_STP);
extern RET_CODE DBA_GetOldDataForAudit(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnection &dbiConn, FLAG_T);

extern RET_CODE DBA_DefFusDateRuleForOpAcctValue(DATETIME_T *, DBA_DYNFLD_STP, const FUSDATERULE_ENUM);   /* REF7854 - PMO */
extern FUSDATERULE_ENUM DBA_GetFusDateRule(const DBA_DYNFLD_STP ,
                                           const int            ,
                                           const int            ,   /* REF10785 - 041129 - PMO */
                                           const DBA_DYNFLD_STP ,
                                           const int            ,                                           const DBA_DYNFLD_STP ,
                                           const DBA_DYNST_ENUM );
extern FUSDATERULE_ENUM DBA_GetOldFusDateRule(const DBA_DYNFLD_STP ,
                                              const int            ,
                                              const DBA_DYNFLD_STP ,
                                              const int            );
extern void DBA_GetFusDate(DATETIME_T *             ,
                           const FUSDATERULE_ENUM   ,
                           const DBA_DYNFLD_STP     ,
                           const int                ,
                           const int                ,
                           const int                );
extern void DBA_GetFusDateExtPos(DATETIME_T *              ,
                                 const FUSDATERULE_ENUM    ,
                                 const DBA_DYNFLD_STP      );

extern RET_CODE DBA_LoadPtf(DBA_DYNFLD_STP *, const ID_T, int *); /* DLA - REF11538 - 051111 */
extern RET_CODE DBA_LoadPPS(DBA_DYNFLD_STP *, const ID_T);
extern int DBA_CheckMatchingCode(const FLAG_T, const CODE_T, const DBA_DYNFLD_STP); /* PMSTA05966 - 090525 - PMO */
extern FLAG_T DBA_IsRejectedOrder(DBA_DYNFLD_STP); /* PMSTA-25573 - CHU - 170410 */

/* PMSTA09264-CHU-100211 : these 2 functions made extern */
extern RET_CODE DBA_GetAllNotepadFromOp(const DBA_DYNFLD_STP, DBA_DYNFLD_STP * *, int *);       /*REF11159-EFE-050509*/
extern RET_CODE DBA_SetAllNotepadToNewOp(const DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DbiConnection &dbiConn);    /*REF11159-EFE-050509*/

extern RET_CODE DBA_GetAllCommunicationFromOp(const DBA_DYNFLD_STP, DBA_DYNFLD_STP * *, int *);       /*PMSTA09264-CHU-100211*/
extern RET_CODE DBA_SetAllCommunicationToNewOp(const DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DbiConnection &dbiConn);    /*PMSTA09264-CHU-100211*/

extern RET_CODE DBA_SelectAllNotepad(const DBA_DYNFLD_STP, DBA_DYNFLD_STP * *, int *, OBJECT_ENUM, DbiConnection &);       /*PMSTA-28772-NRAO-171017*/
extern RET_CODE DBA_SelectAllCommunication(const DBA_DYNFLD_STP, DBA_DYNFLD_STP * *, int *, OBJECT_ENUM, DbiConnection &);  /*PMSTA-28772-NRAO-171017*/

extern bool DBA_IsAutomaticFusionEnable(DbiConnection & dbiConn); /* PMSTA-32288 - JBC - 190205 */
/************************************************************************
**      BEGIN External definitions attached to : dbamem.c
*************************************************************************/
extern DBA_OPTI_STP   EV_OptiPtr;

extern bool DBA_DisableLocalCache (const DBA_OPTI_ENUM);
extern RET_CODE DBA_GetCurrByCd(CODE_T currCd, DBA_DYNFLD_STP *currPtr, FLAG_T *); /* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
extern RET_CODE DBA_GetCurrById(ID_T currId, DBA_DYNFLD_STP *currPtr, FLAG_T *);
extern RET_CODE DBA_CurrenciesMapInit(void);
extern RET_CODE DBA_CurrHashTableAdd(DBA_DYNFLD_STP aCurr,FLAG_T callFromInit);
extern void DBA_CurrHashTableFree(void);

extern int      DBA_SetNullOpti(DBA_OPTI_STP);

extern RET_CODE DBA_FreeOpti(DBA_OPTI_STP);
extern RET_CODE DBA_GetMemory(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DBA_OPTIMODE_ENUM) ;
extern RET_CODE DBA_SelectMemory(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP**, DBA_DYNFLD_STP**, int*, DBA_OPTIMODE_ENUM);
extern RET_CODE DBA_LoadingTabInMemory(void);
extern RET_CODE DBA_ReadOpti(struct DBA_PROC_STRUCT*, DBA_OPTIMODE_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int*, int*, DbiConnectionHelper* = nullptr);
extern RET_CODE DBA_SetMemory(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_OPTIMODE_ENUM);
extern RET_CODE DBA_SelectSetMemory(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_OPTIMODE_ENUM);
extern RET_CODE DBA_WriteOpti(struct DBA_PROC_STRUCT*, DBA_OPTIMODE_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP, FLAG_T, int, int);
extern RET_CODE DBA_GetUserInfo(int, PTR);
extern RET_CODE DBA_GetUserInfo2(int, PTR, FLAG_T);	/* REF11476 - TEB - 051006 */
extern RET_CODE DBA_GetDictFctTabByUserId(ID_T, std::vector<DICT_FCT_ST>*&); /* PMSTA-nuodb - LJE - 190507 */
extern RET_CODE DBA_LoadServerInfos(ID_T serverId); /* REF11767 - LJE - 060412 */
extern RET_CODE DBA_OpenConnForUser(const char*, const PasswordEncrypted&, DbiConnection**, AAAConnectionRole = ROLE_USER);
extern RET_CODE DBA_IsEntityWatched(OBJECT_ENUM);
extern RET_CODE DBA_IsEntityUpdated(OBJECT_ENUM, DATETIME_T);
extern RET_CODE DBA_FinSelStratLnkById(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*);
extern RET_CODE DBA_SetHierOptiPtr(PTR);  /* DVP563 */
extern RET_CODE DBA_FreeHierOptiPtr(PTR); /* DVP563 */
extern RET_CODE DBA_SetEvalEntityFlag(FLAG_T);                /*  FPL-PMSTA09698-100604   */
extern RET_CODE DBA_HandleExportedRecord(OBJECT_ENUM, DBA_DYNFLD_STP, int, char*, bool, DbiConnection *); /*Add Count Variable PMSTA02768 - TGN - 070727 */	/* REF1317 - OCE - 981020 */
extern RET_CODE DBA_SendSubscriptionOutbox(DbiConnection &, bool);                                                     /* PMSTA-52258 - JBC - 230308 */
extern RET_CODE DBA_GetUpdStatus(ENUM_T*, INT_T*);					/* REF1317 - OCE - 981020 */
extern RET_CODE DBA_GetShDynByHierarchy(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&);
extern RET_CODE DBA_AddOptiPurgeTime(DBA_OPTI_STP); /* REF11767 - CHU - 060403 */
extern RET_CODE DBA_SetSrvOpti(DBA_OPTI_SETMODE_ENUM); /* REF11767 - CHU - 060403 */
extern RET_CODE DBA_ValidateDatabaseCredential(const char* userName, const  PasswordEncrypted& userPassword); /* PMSTA-49139 - FME - 2022-06-03*/

extern  void  DBA_SetServerUserToOn(void);
extern  void  DBA_SetServerUserToOff(void);

extern  void  DBA_SetProxyUserToOn(void);
extern  void  DBA_SetProxyUserToOff(void);

extern RET_CODE DBA_InitOptiTab(DbiConnectionHelper &dbiConnHelper);

extern RET_CODE       DBA_SetUserSessionInfo(DbiConnectionHelper &dbiConnHelper, DBA_DYNFLD_STP aApplSessionStp);                           /* PMSTA-22549 - CHU - 160512 */ /* PMSTA-26108 - LJE - 171120 */
extern void           DBA_GetApplSessionCode(CODE_T *, AAAConnectionRole role = ROLE_USER, SessionProperties *sessionPropertiesPtr = nullptr); /* PMSTA-22549 - CHU - 160512 */ /* PMSTA-24079 - LJE - 160719 */ /* PMSTA-34402 - LJE - 190121 */
extern ID_T           DBA_GetApplSessionChangeSetId();                                      /* PMSTA-26250 - DDV - 170411 */
extern void           DBA_DelUserInfo(PTR);                                                     /* PMSTA-23716 - CHU - 160622 */
extern RET_CODE       DBA_DelApplSession(DbiConnectionHelper&, const char *, APPLSESSION_INVALIDATION_NATURE_ENUM);  /* PMSTA-22549 - CHU - 160512 */
extern void           DBA_DeleteApplSessionOnExit(APPLSESSION_INVALIDATION_NATURE_ENUM, DbiConnection * = nullptr );        /* PMSTA-22549 - CHU - 160512 */
extern void           DBA_DeleteAllApplSessionByUser(APPLSESSION_INVALIDATION_NATURE_ENUM, DbiConnection*, const std::string &);       /* PMSTA-43741 - LJE - 210223 */
extern RET_CODE       DBA_DelApplSessionByCd(OBJECT_ENUM,DBA_DYNST_ENUM,DBA_DYNFLD_STP,DbiConnectionHelper&);       /*  HFI-PMSTA-47796-220125  */
extern APPLSESSION_INVALIDATION_NATURE_ENUM DBA_CheckApplSessionValidity(DBA_DYNFLD_STP);       /* PMSTA-30522 - DLA - 180327 */
extern void           DBA_GetChannelCd(CODE_T);                                                 /* PMSTA-22549 - CHU - 160518 */
extern RET_CODE       DBA_UpdApplSessionLastAccessDate(DbiConnectionHelper &, DBA_DYNFLD_STP);      /* PMSTA-23914 - CHU - 160705 */        /* PMSTA-nuodb - LJE - 190722 */
extern RET_CODE       DBA_GetSessionTimeOut(CODE_T, unsigned long *);                           /* PMSTA-23914 - CHU - 160706 */

extern void   DBA_UpdOptiTab(DBA_OPTI_STP, OBJECT_ENUM),
              DBA_FlushOptimisation(OBJECT_ENUM = NullEntity),
                      DBA_OptiGetUsedSizeByProc(struct DBA_PROC_STRUCT *, DBA_OPTIMODE_ENUM, int,LONGINT_T *, FILE *),
                      DBA_OptiStat(int, char *, char *),
              DBA_UpdateApplParam(void);

extern int            DBA_ForceVerifOptiTab(DbiConnectionHelper * = nullptr);       /*  HFI-PMSTA-39502-200407  */
extern int            DBA_VerifOptiTab(DbiConnectionHelper * = nullptr);
extern DBA_DYNFLD_STP DBA_GetDomainPtr(int threadConnNbr=0);   /* PMSTA52459 - DDV - Parameter is now optional (no more used in the function) */
extern uint64_t       DBA_GetTascCounter(void);
extern void DBA_ReflectDomainUsage(DBA_DYNFLD_STP);                /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
extern void DBA_TraceDomainCopy(DBA_DYNFLD_STP, DBA_DYNFLD_STP);   /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */

extern DBA_CLASSIFSTACKHEAD_STP DBA_GetClassifStackHeadPtr(void);                     /* REF5495 - DDV - 001204 */
extern RET_CODE DBA_FreeClassifStack(DBA_CLASSIFSTACKHEAD_STP);                       /* REF5495 - DDV - 001204 */
extern RET_CODE DBA_AddClassifToStack(DBA_CLASSIFSTACKHEAD_STP,DBA_DYNFLD_STP *,int, ID_T); /* REF5495 - DDV - 001204 */

extern DBA_LISTOPTIHEAD_STP DBA_GetListOptiHeadPtr(void);                    /* REF5495 - DDV - 001206 */
extern RET_CODE DBA_FreeListOpti(DBA_LISTOPTIHEAD_STP);                      /* REF5495 - DDV - 001206 */
extern RET_CODE DBA_AddListToListOpti(DBA_LISTOPTIHEAD_STP, ID_T, PTR);      /* REF5495 - DDV - 001206 */
extern RET_CODE DBA_SearchListInListOpti(DBA_LISTOPTIHEAD_STP, ID_T, PTR *); /* REF5495 - DDV - 001206 */


extern void	      DBA_InitConnectNoToHier(PTR); /* REF2580 */
extern PTR            DBA_GetHierOptiPtr(void);         /* DVP563 */
extern FLAG_T   DBA_GetEvalEntityFlag(void);    /*  FPL-PMSTA09698-100604   */
extern const void    *DBA_GetCurrThread(void);	/* REF3847 */
extern int      DBA_GetThreadConnNbr(void);/* REF4213 - SSO - 991221 */
extern RET_CODE DBA_CheckPasswdHistory(SYSNAME_T user_code, PasswordEncrypted&); /* REF4170 */ /* DLA - PMSTA09887 - 101115 */
extern int  DBA_InsertPasswdHistory(SYSNAME_T user_code, PasswordEncrypted&, DbiConnectionHelper&); /* REF4170 */ /* DLA - PMSTA09887 - 101115 */
extern int DBA_CheckExpiredPassword(void);	/* REF4170 */
extern int DBA_CheckMaxRunningGui(void); /* REF4170 */
extern int DBA_CleanLoginFailed(void); /* REF4170 */
extern int DBA_LockIfServer(DBA_SERV_LOCK_ENUM, const char *, const int ); /* REF4333.3 */ /* REF11791-EFE-060531 */
extern int DBA_UnlockIfServer(DBA_SERV_LOCK_ENUM, const char *, const int ); /* REF4333.3 */ /* REF11791-EFE-060531 */
extern FLAG_T  DBA_IsGuiMultiThreading(void);       /*  FPL-PMSTA09858-100526   */
/* PCC13654 - LJE - 090701 */
extern RET_CODE DBA_GetCurrCodifInfoTab(DBA_DYNFLD_STP **, int *);
extern RET_CODE DBA_SetCodifInfoTabAsCurr();

extern void     DBA_LoadAndCheckDbTimeZone(bool dispTzDataVersionFlg); /* PMSTA-30817 - DDV - 180430 */

extern bool DBA_SetFmtEltInfo(const char *);		/* PMSTA-17979 - TGU - 151001 */
extern bool DBA_GetFmtEltInfo(char *);		/* PMSTA-17979 - TGU - 151001 */

extern RET_CODE DBA_SetESRVOptiHeadPtr(PTR); /* PMSTA-22496 - DDV - 160616 */
extern PTR      DBA_GetESRVOptiHeadPtr();    /* PMSTA-22496 - DDV - 160616 */

/* REF10304 - 040707 - PMO */
extern unsigned int EV_SucLocSeek;
extern unsigned int EV_SucGloSeek;
extern unsigned int EV_UnsucLocSeek;
extern unsigned int EV_UnsucGloSeek;
extern unsigned int EV_LocWrite;
extern unsigned int EV_GloWrite;
extern TIMER_ST DBA_TimeLnkRec;


extern EXITREASON_ENUM DBA_GetExitReason();      /* PMSTA-23726 - DDV - 160624 */
extern void DBA_SetExitReason(EXITREASON_ENUM);  /* PMSTA-23726 - DDV - 160624 */

/************************************************************************
**      BEGIN External definitions attached to : dbaloadpaa.c
*************************************************************************/
extern RET_CODE    DBA_LoadDomPspTable(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, DbiConnectionHelper&), /* REF7758 - LJE - 020919 */
                   DBA_RemoveUnusedPSPFromHier(DBA_HIER_HEAD_STP);

/* REF9770 - LJE - 040317 */
extern RET_CODE DBA_ConsolidObjectLinks(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);

extern RET_CODE FIN_GetDefPPDa(DBA_DYNFLD_STP *);	/* PMSTA-7398 - RAK - 100625 */

/************************************************************************
**      BEGIN External definitions attached to : dbasession.c
*************************************************************************/
typedef enum
{
    sessionMgtMode_Copy,			/* 0 */
    sessionMgtMode_Amend,			/* 1 */
    sessionMgtMode_Trade,			/* 2 */
    sessionMgtMode_Cancel,			/* 3 */
    sessionMgtMode_Clean,			/* 4 */
    sessionMgtMode_PostValidation,	/* 5 */ /* PMSTA15852-CHU-130125 */

    sessionMgtMode_Last
} SESSION_MGT_MODE_ENUM;

typedef enum
{
    sessionMgtOption_AddBuySell,		/*  0 */
    sessionMgtOption_AddExternPos,		/*  1 */
    sessionMgtOption_AddOrCleanAll = 99 /* 99 */
} SESSION_MGT_OPTION_ENUM;

extern RET_CODE DBA_NewExtOpForCopySession(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										DBA_DYNFLD_STP, DATETIME_T, int *),  /* PMSTA11002-CHU-101220 */ /* PMSTA-21231 - CHU - 150915 */
				DBA_NewExtOpForManageSession(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										DBA_DYNFLD_STP, DATETIME_T, SESSION_MGT_MODE_ENUM, int *),  /* PMSTA11002-CHU-101220 */ /* PMSTA-21231 - CHU - 150915 */
				DBA_NewCommentForManageSession(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										DBA_DYNFLD_STP, DATETIME_T, int *),  /* PMSTA11002-CHU-101220 */ /* PMSTA-21231 - CHU - 150915 */
				DBA_NewDomainPtfCompoForManageSession(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										DBA_DYNFLD_STP, DATETIME_T, int *),  /* PMSTA-21529 - CHU - 151021 */
				DBA_InitDataForSessionHandling(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DBA_DYNFLD_STP *, DbiConnection &dbiConn), /* PMSTA11002-CHU-101220 */
				DBA_UpdateDomainsForManageSession(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T,
										SESSION_MGT_MODE_ENUM, FLAG_T *, FLAG_T *),
				DBA_CleanSession(DBA_DYNFLD_STP, int *, FLAG_T, DBA_DYNFLD_STP), /* PMSTA11002-CHU-101220 */
				DBA_LoadSessionExternalPos(DBA_DYNFLD_STP, PTR, int *, FLAG_T, DBA_DYNFLD_STP **, int *), /* PMSTA11101-CHU-110201 */
				DBA_BuildCopyArgTab(DBA_DYNFLD_STP, OBJECT_ENUM, char *, DBA_DYNFLD_STP **, int *), /* PMSTA13167 - DDV - 111222 */
				DBA_LoadDataToCopy(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP ***, int **, int *), /* PMSTA13167 - DDV - 111222 */
				DBA_UpdateDataToCopy(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP **, int *, int *), /* PMSTA13167 - DDV - 111222 */
				DBA_InsertDataToCopy(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP **, int *, DbiConnectionHelper&, FLAG_T *); /* PMSTA13167 - DDV - 111222 */

extern int  FIN_FilterESLCrtPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* PMSTA-28852 - CHU - 171025 */
            FIN_FilterESECrtPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* PMSTA-28852 - CHU - 171025 */
            FIN_FilterExtLinkMP(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfIdDynSt), /* PMSTA-38323 - 01102020 - SGO */
            FIN_FilterESLStratIP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);



#ifndef DBAMAC_H /* Force dbamac.h to be included, but #typedef of dba.h must be done before */
#include "dbamac.h"
#endif

#ifndef MD_DBAMAC_H
#define MD_DBAMAC_H
#include "md_dbamac.h"
#endif

/************************************************************************
**      BEGIN External definitions attached to : dbafmt.c
*************************************************************************/
extern RET_CODE DBA_GenerateFormatElement(GenerateFmteltScopeEn, ID_T, ID_T, ID_T, DICT_T, FLAG_T, GenerateFmteltCheckApplParamEn, std::set<std::string> *childrenFmtSet = nullptr);
extern RET_CODE DBA_CheckReferenceFormatElement(ID_T, DBA_DYNFLD_STP**, int*, FLAG_T*, FLAG_T*, DBA_DYNFLD_STP, DBA_ERRMSG_INFOS_STP);
extern RET_CODE DBA_GenerateReferenceFormatElement(ID_T, ID_T);
extern RET_CODE DBA_CheckGenerateReferenceFormatElement(ID_T, ID_T, char **);
extern RET_CODE DBA_InsFmtById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&); /* PMSTA13876 - DDV - 130806 */
extern RET_CODE DBA_UpdFmt(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);     /* PMSTA13876 - DDV - 130806 */
extern RET_CODE DBA_DelFmt(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);     /* PMSTA13876 - DDV - 130806 */
extern RET_CODE DBA_InsFmtEltById(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);     /* PMSTA13876 - DDV - 130807 */
extern RET_CODE DBA_UpdFmtElt(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);         /* PMSTA13876 - DDV - 130807 */
extern RET_CODE DBA_DelFmtElt(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);         /* PMSTA13876 - DDV - 130807 */
extern RET_CODE DBA_CopyFmtElt(OBJECT_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);  /* PMSTA13876 - DDV - 130904 */


/************************************************************************
**      BEGIN External definitions attached to : ddlgen.c
*************************************************************************/
/* PMSTA-45413 - LJE - 210616 - ddlgen */
extern RET_CODE DBA_GetXdObject(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&);
extern RET_CODE DBA_InsXdObject(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);
extern RET_CODE DBA_UpdXdObject(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);
extern RET_CODE DBA_DelXdObject(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);
extern RET_CODE DBA_SelXdObject(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, DbiConnectionHelper&);
extern RET_CODE DBA_UpdHelpDoc(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);

extern RET_CODE DBA_ResetDictSprocByEntity(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);

extern const char* GetXdObjectConst;
extern const char* SelXdObjectConst;
extern const char* InsXdObjectConst;
extern const char* UpdXdObjectConst;
extern const char* DelXdObjectConst;

extern const char* SelScriptDefConst;
extern const char* InsScptDefConst;
extern const char* UpdScptDefConst;
extern const char* DelScptDefConst;


#endif
/* ifndef DBA_H */

/************************************************************************
**      END        dba.h
*************************************************************************/

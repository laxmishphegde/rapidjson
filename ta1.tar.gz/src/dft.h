/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DFT_H
#define DFT_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to dft.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  DFT_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN void DFT_WaitToBeUnlocked(const char *),
	        DFT_Enable(),
	        DFT_Disable();
	    
#endif					/* ifndef DICT_H */
/************************************************************************
**      END        dft.h                                     ODYSSEY
*************************************************************************/


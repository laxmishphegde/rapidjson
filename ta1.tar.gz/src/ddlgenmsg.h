/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENMSG_H
#define DDLGENMSG_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenmsg.cpp
*************************************************************************/
#include <string>
#include <sstream>
#include <iostream>
#include <list>
#include <vector>
#include <algorithm>
#include <ctime>
#include <chrono>

extern const char* DDL_SPACE;

inline std::string& rtrim(std::string& s, const char* t = DDL_SPACE)
{
    s.erase(s.find_last_not_of(t) + 1);
    return s;
}

inline std::string& ltrim(std::string& s, const char* t = DDL_SPACE)
{
    s.erase(0, s.find_first_not_of(t));
    return s;
}

inline std::string& trim(std::string& s, const char* t = DDL_SPACE)
{
    return ltrim(rtrim(s, t), t);
}

static char my_toupper(char c)
{
	return static_cast<char>(toupper(c));
}

inline std::string upper(const std::string& s)
{
	std::string upStr = s;
	std::transform(upStr.begin(), upStr.end(), upStr.begin(), my_toupper);
	return upStr;
}

/* PMSTA-26011 - DDV - 170125 */
static char my_tolower(char c)
{
	return static_cast<char>(tolower(c));
}

/* PMSTA-26011 - DDV - 170125 */
inline std::string lower(const std::string& s)
{
	std::string lowStr = s;
	std::transform(lowStr.begin(), lowStr.end(), lowStr.begin(), my_tolower);
	return lowStr;
}

typedef enum
{
    DdlObj_None,
    DdlObj_View,
    DdlObj_SProc,
    DdlObj_Func,
    DdlObj_Trigger,
    DdlObj_Table,
    DdlObj_Index,

    /* Not in permitted values */
    DdlObj_TriggerBody,
    DdlObj_TriggerUdField,
    DdlObj_TriggerUdFieldBody,
    DdlObj_TempTableIndex,
    DdlObj_TempTable,
    DdlObj_SpecSProc,
    DdlObj_Constraint,
    DdlObj_ViewLegacy,
    DdlObj_PrimaryKey,
    DdlObj_ForeignKey,
    DdlObj_Column,
    DdlObj_Sql,
    DdlObj_SubSql,
    DdlObj_SubDdlObj,
    DdlObj_ReversedForeignKey,
    DdlObj_Migration,        /* PMSTA-32145 - LJE - 180730 */
    DdlObj_RuntimeSql,
    DdlObj_SubQuery,          /* PMSTA-46861 - LJE - 220120 */
    DdlObj_Type
} DDL_OBJ_ENUM;

/* PMSTA-11505 - LJE - 110314 */
typedef enum
{
    View_None,
    View_FullAllSecured,       /* "All" structure with ud_ fields and ext_ fields with secure access, with authorize flag (_vw) */
    View_FullAll,              /* "All" structure with ud_ fields and ext_ fields without secure access (_uvw)*/
    View_LightAll,             /* "All" structure without any linked tables with secure access (_lvw) */
    View_ShortSecured,         /* "Short" structure with secure access */
    View_Short,                /* "Short" structure without secure access */
    View_FullAll4ForeignKey,   /* "All" structure with ud_ fields and ext_ fields with optional (ENABLE_SECU_ON_FK_VIEW) secure access, without authorize flags */ /* OCS-41131 - LJE - 120723 */ /* PMSTA-43625 - LJE - 210308 */
    View_AllSecured,           /* "All" structure with ud_ fields and ext_ fields with secure access, without authorize flags */ /* PMSTA-43625 - LJE - 210308 */
    View_Custom,
    View_ForUpdateByTech,       /* OCS-48064 - LJE - 160420 */
    View_Shadow,                /* PMSTA-26250 - LJE - 170327 */
    View_MultiEntitySpec,       /* PMSTA-26108 - LJE - 170904 */
    View_User,                  /* PMSTA-26108 - LJE - 171103 - For user view where Triple'A role having access */
    View_Export,                /* "All" structure for export like View_FullAllSecured  but select on current business entity only (MESI) */ /* PMSTA-29982 - LJE - 180209 */
    View_MainTable,             /* Main table only (no join on other tables), without security but with business entity selection (MESI) */
    View_Tech                   /* Technical view with ud_ but not ext_ attributes, no granted (_xvw) */
} DDL_VIEW_ENUM;

/* PMSTA-26250 - LJE - 170327 */
typedef enum
{
    DdlGenMode_Standard,
    DdlGenMode_Shadow,
    DdlGenMode_ValidateShadow,
    DdlGenMode_MultiEntity      /* PMSTA-26108 - LJE - 170904 */
} DDL_GEN_MODE_ENUM;

class DdlGenContext;

class DdlGenMsg:public AAAObject
{
public:
    typedef std::unique_ptr<DdlGenMsg> Ptr;

    // Constructors
    DdlGenMsg(DdlGenContext *, bool = false);

    DdlGenMsg(const DdlGenMsg &ref)
        : DdlGenMsg(ref.ddlGenContextPtr, ref.m_isStandalone)
    {
        this->msgSqlName         = ref.msgSqlName;
        this->msgEntitySqlName   = ref.msgEntitySqlName;
        this->msgFileName        = ref.msgFileName;
        this->msgObjTypeStr      = ref.msgObjTypeStr;
        this->lastErrRetCode     = ref.lastErrRetCode;
        this->m_ddlObjEn         = ref.m_ddlObjEn;
        this->ddlGenContextPtr   = ref.ddlGenContextPtr;
    }

    DdlGenMsg& operator = (const DdlGenMsg &ref)
    {
        this->msgSqlName         = ref.msgSqlName;
        this->msgEntitySqlName   = ref.msgEntitySqlName;
        this->msgFileName        = ref.msgFileName;
        this->msgObjTypeStr      = ref.msgObjTypeStr;
        this->lastErrRetCode     = ref.lastErrRetCode;
        this->m_ddlObjEn         = ref.m_ddlObjEn;
        this->ddlGenContextPtr   = ref.ddlGenContextPtr;
        return *this;
    }

    // Destructor
    virtual ~DdlGenMsg();

    // Methods
    virtual void           printMsg(RET_CODE retCode, const std::string &paramMsg, bool isNewLine = true, int sprocLine = -1);
    void                   printCatchMsg(const char *file, const int line, const char *exeptMsg);

    void                   printMsgData(RET_CODE retCode, DBA_DYNFLD_STP dataStp);

    void                   printConfig();

    void                   setDdlObjEn(DDL_OBJ_ENUM  paramDlObjEn);
    DDL_OBJ_ENUM           getDdlObjEn();
    std::string            getDdlObjEnStr();
    static std::string     getDdlObjEnStr(DDL_OBJ_ENUM);

    bool                   isProcedureBehavior();

    static DDL_OBJ_ENUM    getDdlObjEnFromStr(const std::string &ddlObjEnStr);
    static DDL_VIEW_ENUM   getViewEnFromStr(const std::string &viewEnStr); /* PMSTA-16194 - LJE - 130522 */

    void                   setMsgInfo(const DdlGenMsg &copyDdlGenMsg);
    void                   setMsgEntitySqlName(const std::string &entitySqlName);
    void                   setMsgSqlName(const std::string &sqlName);
    void                   setMsgObjType(const std::string &objTypeStr);

    bool                   getSilentMode();

    const std::string     &getMsgEntitySqlName() const;
    const std::string     &getMsgSqlName() const;
    const std::string     &getMsgObjType() const;

    inline DdlGenContext    *getDdlGenContextPtr()
    {
        return this->ddlGenContextPtr;
    }

    void               startTimer();
    void               stopTimer();
    void               resetTimer();
    const std::string  printTimer(bool bLastOnly);

    static void        checkComments(const std::string& lineStr, bool& inComment, std::stringstream& target, bool bSingleLine, bool bTrim = false);
    static void        removeComments(std::stringstream& source, std::stringstream& target);
    static void        removeComments(std::string& source);
    static void        incPosWOComment(const std::string& lineStr, size_t& pos);
    static bool        compareString(const std::string& source, const std::string& target);

    void               copyDynFld(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP, int);   /* PMSTA-45413 - LJE - 210622 */

    std::string        msgSqlName;
    std::string        msgEntitySqlName;
    std::string        msgFileName;
    std::string        msgObjTypeStr;

    RET_CODE           lastErrRetCode;

protected:
    DDL_OBJ_ENUM       m_ddlObjEn;
    DdlGenContext     *ddlGenContextPtr;
    bool               m_isStandalone;

    MemoryPool         m_mp;

private:

    std::chrono::steady_clock::time_point              m_startTime;
    std::vector<double>                                m_totalDurationVector;
    bool                                               m_bTimerStarted;
};

#endif	                               /* ifndef DDLGENMSG_H */
/************************************************************************
**      END       ddlgenmsg.h                                   Odyssey
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define CMPLIB_C

/************************************************************************
**      Include files
*************************************************************************/
#define	STDIO_H
#define	STRING_H
#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "cmp.h"

/************************************************************************
**      Static definitions & data
*************************************************************************/

/************************************************************************
**
**  Function    :   CMP_ShCurrency()
**
**  Description :   Function used by TLS_Sort() to sort 
**                  an DBA_DYNFLD_ST dynamic structure.
**                  Elements are sorted 
**                  - by rank, 
**		    - by alphabetical order on code 
**		      (in asked codification or not)
**
**  Arguments   :   stp1    Pointer on first element to compare
**                  stp2    Pointer on second element to compare
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
int CMP_ShCurrency(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
{
	/* If same rank, sort by code */
	if (GET_SMALLINT(stp1[0], S_Curr_Rank) == 
	    GET_SMALLINT(stp2[0], S_Curr_Rank))
		return(strcmp(GET_CODE(stp1[0], S_Curr_Cd), 
			      GET_CODE(stp2[0], S_Curr_Cd)));
	/* Sort by rank */
	else
		return((int) (GET_SMALLINT(stp1[0], S_Curr_Rank) - 
			      GET_SMALLINT(stp2[0], S_Curr_Rank)));
}

/************************************************************************
**
**  Function    :   CMP_InterCondByIdDt()
**
**  Description :   Order A_InterCond by:
**                  A_InterCond_InterCalcRuleEn ascending,
**                  A_InterCond_BegDate         ascending.
**
**  Arguments   :   flow1 and flow2 for comparison.
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   DVP563 - 970813 - GRD
**  Last modif. :
**
*************************************************************************/
int CMP_InterCondByIdDt(DBA_DYNFLD_STP *flow1, DBA_DYNFLD_STP *flow2)
{

        /* First, compare A_InterCond_InterCalcRuleEn. */
        if (GET_ENUM((*flow1), A_InterCond_IntCalcRuleEn) == GET_ENUM((*flow2), A_InterCond_IntCalcRuleEn))
        {
                if (GET_DATE((*flow1), A_InterCond_BeginDate) > GET_DATE((*flow2), A_InterCond_BeginDate))
			return(1);

		if (GET_DATE((*flow1), A_InterCond_BeginDate) < GET_DATE((*flow2), A_InterCond_BeginDate))
			return(-1);

		return(0);
        }

	if (GET_ENUM((*flow1), A_InterCond_IntCalcRuleEn) > GET_ENUM((*flow2), A_InterCond_IntCalcRuleEn))
		return(1);

	return(-1);
}

/************************************************************************
**
**  Function    :   CMP_InterCondByDt()
**
**  Description :   Order A_InterCond by:
**                  A_InterCond_InterCalcRuleEn ascending,
**                  A_InterCond_ValidDate       descending,
**                  A_InterCond_BegDate         descending.
**
**  Arguments   :   flow1 and flow2 for comparison
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   DVP563 - 970813 - GRD
**  Last modif. :
**
*************************************************************************/
int CMP_InterCondByDt(DBA_DYNFLD_STP *flow1, DBA_DYNFLD_STP *flow2)
{

        /* First, compare A_InterCond_InterCalcRuleEn. */
        if (GET_ENUM((*flow1), A_InterCond_IntCalcRuleEn) == GET_ENUM((*flow2), A_InterCond_IntCalcRuleEn))
        {
                if (GET_DATE((*flow1), A_InterCond_ValidDate) == GET_DATE((*flow2), A_InterCond_ValidDate))
                {
			if (GET_DATE((*flow1), A_InterCond_BeginDate) > GET_DATE((*flow2), A_InterCond_BeginDate))
				return(-1);

                        if (GET_DATE((*flow1), A_InterCond_BeginDate) < GET_DATE((*flow2), A_InterCond_BeginDate))
                                return(1);

			return(0);
                }

		if (GET_DATE((*flow1), A_InterCond_ValidDate) > GET_DATE((*flow2), A_InterCond_ValidDate))
			return(-1);

		return(1);
        }

	if (GET_ENUM((*flow1), A_InterCond_IntCalcRuleEn) > GET_ENUM((*flow2), A_InterCond_IntCalcRuleEn))
		return(1);

	return(-1);
}

/************************************************************************
**
**  Function    :   CMP_ExchEvtByDt()
**
**  Description :   Order A_ExchEvent by:
**                  A_ExchEvt_ValidDate       
**                  A_ExchEvt_Priority       
**
**  Arguments   :   exchEvt1 and exchEvt2 for comparison
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   REF1132 - DDV - 980312
**  Last modif. :
**
*************************************************************************/
int CMP_ExchEvtByDt(DBA_DYNFLD_STP *exchEvt1, DBA_DYNFLD_STP *exchEvt2)
{

        if (GET_DATE((*exchEvt1), A_ExchEvt_ValidDate) == GET_DATE((*exchEvt2), A_ExchEvt_ValidDate))
        {
		if (GET_DATE((*exchEvt1), A_ExchEvt_Priority) > GET_DATE((*exchEvt2), A_ExchEvt_Priority))
			return(1);

                if (GET_DATE((*exchEvt1), A_ExchEvt_Priority) < GET_DATE((*exchEvt2), A_ExchEvt_Priority))
                        return(-1);

		return(0);
        }

	if (GET_DATE((*exchEvt1), A_InterCond_ValidDate) > GET_DATE((*exchEvt2), A_InterCond_ValidDate))
		return(1);

	return(-1);
}

/************************************************************************
**   END  cmplib.c                                            UNICIBLE **	
*************************************************************************/

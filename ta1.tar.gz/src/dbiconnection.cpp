
/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif
#include <cmath>
#include "QDir"

#include "unidef.h"

#include "dba.h"
#include "conpool.h"
#include "conexcept.h"
#include "ddlgenfromfile.h"
#include "httpclient.h"
#include "json.h"
#include "httpconnection.h"
#include "callstack.h"
#include "scptyl.h"
#include "quuid.h"
#include "aaatelemetry.h"

#ifdef NTWIN
#pragma warning (pop)
#endif



extern char                         EV_SetProcParametersFlg;
extern TIMER_STP                    EV_ExtractFileTimerPtr;
extern bool                         EV_PrintAllMessages;
extern int                          EV_SqlTraceParam;
extern int                          EV_AAAInstallLevel;
extern FLAG_T                       EV_IsSubscriptionActive;

extern int SYS_GetWaitTime();
extern int SYS_TimeWaitedSoFar();
extern int SYS_MaxWaitThreshold();
extern void SYS_ResetRetryDelayWaitTimers();



bool                                EV_CheckTransState   = false;

int                                 EV_MaxNumberArgument = MAX_SHORT;
std::map<std::string, std::string>  EV_MaxArgSProTableMap;


/************************************************************************
*   Function             :  DbaCallGuard::DbaCallGuard
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-45413 - LJE - 210804
*
*   Modif.               :
*
*************************************************************************/
DbaCallGuard::DbaCallGuard(DbiConnectionHelper &dbiConnectionHelper)
    : m_dbiConnectionHelper(dbiConnectionHelper)
    , m_fromDbaAccess(dbiConnectionHelper.m_fromDbaAccess)
{
}

/************************************************************************
*   Function             :  DbaCallGuard::~DbaCallGuard
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-45413 - LJE - 210804
*
*   Modif.               :
*
*************************************************************************/
DbaCallGuard::~DbaCallGuard()
{
    this->m_dbiConnectionHelper.setCurrProcedure(nullptr);
    this->m_dbiConnectionHelper.m_fromDbaAccess = m_fromDbaAccess;
}

/************************************************************************
*   Function             :  DbaTransactionGuard::DbaTransactionGuard
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-46681 - LJE - 230911
*
*   Modif.               :
*
*************************************************************************/
DbaTransactionGuard::DbaTransactionGuard(DbiConnection& dbiConnection, RET_CODE& retCode)
    : m_dbiConnection(dbiConnection)
    , m_retCode(retCode)
    , m_isInTransaction(dbiConnection.isInTransaction())
    , m_modifStat(dbiConnection.getTargetSessionProperties().getModifStat())
{
}

/************************************************************************
*   Function             :  DbaTransactionGuard::~DbaTransactionGuard
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-46681 - LJE - 230911
*
*   Modif.               :
*
*************************************************************************/
DbaTransactionGuard::~DbaTransactionGuard()
{
    if (this->m_isInTransaction == false &&
        this->m_dbiConnection.isInTransaction())
    {
        this->m_dbiConnection.endTransaction(RET_GET_LEVEL(this->m_retCode) == RET_LEV_ERROR ? FALSE : TRUE);
    }

    this->m_dbiConnection.setModifStat(this->m_modifStat);
}

/************************************************************************
*   Function             :  DbaTransactionGuard::beginTransaction
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-46681 - LJE - 230911
*
*   Modif.               :
*
*************************************************************************/
RET_CODE DbaTransactionGuard::beginTransaction()
{
    if (this->m_dbiConnection.isInTransaction() == false)
    {
        return this->m_dbiConnection.beginTransaction();
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             :  DbaTransactionGuard::setModifStat
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-46681 - LJE - 230911
*
*   Modif.               :
*
*************************************************************************/
void DbaTransactionGuard::setModifStat(int modifStat)
{
    this->m_dbiConnection.setModifStat(modifStat);
}


/************************************************************************
*   Function             :  DBA_CONNECT_INFO_STRUCT::DBA_CONNECT_INFO_STRUCT()
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*   Modif.               :
*
*************************************************************************/
DBA_CONNECT_INFO_STRUCT::DBA_CONNECT_INFO_STRUCT() :    maxRows(0),
                                                        blockMode(0),
                                                        noDeleteMessageInfo(0),
                                                        msgOptions(nullptr),
                                                        notifyCanAutoReconnect(false),
                                                        disableEventSchedNotification(false),
                                                        preserveConfirmedFlg(0),
                                                        passwordChange(false),
                                                        poolConnectNo(0),
                                                        timeOut(0)
{
    SYS_Bzero(&blockModeExt,    sizeof(blockModeExt));
    SYS_Bzero(&subscriptionElem,sizeof(subscriptionElem));
}

/************************************************************************
*   Function             :  DbiOutboxManager::DbiOutboxManager()
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
DbiOutboxManager::DbiOutboxManager(DbiConnection& dbiConn)
    : m_dbiConn(dbiConn)
    , m_totalInsertedNbr(0)
{
}

/************************************************************************
*   Function             :  ~DbiOutboxManager::DbiOutboxManager()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
DbiOutboxManager::~DbiOutboxManager()
{
    this->flush(true);
}

/************************************************************************
*   Function             :  DbiOutboxManager::addRecord()
*
*   Description          :  Add a modified record
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
void DbiOutboxManager::addRecord(DBA_DYNFLD_STP recordStp, DBA_ACTION_ENUM actionEn, OutboxEventModeEn outboxEventModeEn)
{
    if (outboxEventModeEn != OutboxEventModeEn::None &&
        (actionEn == Insert || actionEn == Update || actionEn == Delete) &&
        recordStp != nullptr &&
        recordStp->getDynStEn() != A_OutboxEvent &&
        recordStp->getDynStEn() != A_ApplSession &&
        recordStp->getDynStEn() != S_ApplSession &&
        recordStp->getDynStEn() != A_ApplSessionHisto &&
        recordStp->getDynStEn() != S_ApplSessionHisto)
    {
        OutboxEventModeEn applOutboxEventModeEn = OutboxEventModeEn::None;
        GEN_GetApplInfo(ApplOutboxEventModeEnum, &applOutboxEventModeEn);
        if (outboxEventModeEn == applOutboxEventModeEn)
        {
            auto dictEntityStp = recordStp->getDictEntityStp();
            if (dictEntityStp != nullptr &&
                dictEntityStp->auditAuthEn == FeatureAuth_Enable)
            {
                this->m_recordActionMap[recordStp->getObjectEn()][actionEn].push_back(this->m_mp.duplicate(FILEINFO, recordStp));
                this->flush(false);
            }
        }
    }
}

/************************************************************************
*   Function             :  DbiOutboxManager::addRecord()
*
*   Description          :  Add a modified record
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
void DbiOutboxManager::addRecord(DBA_DYNFLD_STP recordStp, DBA_PROC_STP procedureStp)
{
    if (procedureStp->subObj != DBA_ROLE_UPD_UD_FIELDS &&
        procedureStp->server == SqlServer)
    {
        this->addRecord(recordStp, procedureStp->action, OutboxEventModeEn::Entity);
    }
}

/************************************************************************
*   Function             :  DbiOutboxManager::getBkInfo()
*
*   Description          :  Flush outbox data
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
void DbiOutboxManager::getBkInfo(std::string& attribListStr, std::string& valueListStr, DBA_DYNFLD_STP recordStp)
{
    FormatFieldsFlat formatFields(&this->m_dbiConn);
    formatFields.setCharsetUtf8(true);
    formatFields.setErrorCallback(MSG_SendMesg);

    BuildBindOption buildBindOption(BuildBindOption::Categ::OutboxEventBusinessKeyOnly);
    DBA_DYNST_ENUM  dynStEn = recordStp->getDynStEn();
    OBJECT_ENUM     objectEn = NullEntity;
    DbiBindDataDef  mapBindDataDef;
    ReaderParser::buildBindMapFromData(std::string(), objectEn, dynStEn, nullptr, mapBindDataDef, buildBindOption);

    formatFields.formatAllFields(recordStp, mapBindDataDef, buildBindOption);

    formatFields.getDataSerialized(attribListStr, true);
    formatFields.getDataSerialized(valueListStr, false);
}

/************************************************************************
*   Function             :  DbiOutboxManager::flush()
*
*   Description          :  Flush outbox data
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
RET_CODE DbiOutboxManager::flush(bool bForce)
{
    if (this->m_recordActionMap.empty() == false &&
        (bForce ||this->m_recordActionMap.size() >= RequestHelper::getDefBatchBlockSize(this->m_dbiConn.getDbaRDBMS())))
    {
        MemoryPool    mp;

        for (auto& updRecordMap : this->m_recordActionMap)
        {
            RequestHelper requestHelper(&this->m_dbiConn);
            requestHelper.setTransactionMode(RequestHelper::TransactionMode::External);

            int  totalInsertedNbr = 0;
            auto dictEntityStp = DBA_GetDictEntitySt(updRecordMap.first);

            for (auto& updRecordVector : updRecordMap.second)
            {
                BuildBindOption outputBindOption(BuildBindOption::Categ::OutboxEvent);
                outputBindOption.setExportMode(NullEntity, EntityConfigExportModeEn::NotNullOnly);

                for (auto& updRecordStp : updRecordVector.second)
                {
                    DBA_DYNFLD_STP  outboxEventStp = mp.allocDynstSetDefaultFld(FILEINFO, A_OutboxEvent);

                    std::string outputString;
                    std::vector<DBA_DYNFLD_STP> inputDynStpVector;
                    inputDynStpVector.push_back(updRecordStp);
                    RET_CODE ret = updRecordVector.first != Delete ?
                        DBA_GetJSonStringFromDynStp(inputDynStpVector,
                                                    outputString,
                                                    outputBindOption,
                                                    this->m_dbiConn) :
                        RET_SUCCEED;

                    if (ret == RET_SUCCEED)
                    {
                        auto uuid = QUuid::createUuid();

                        SET_STRING(outboxEventStp, A_OutboxEvent_EventIdentifier, uuid.toString(QUuid::StringFormat::WithoutBraces).toUtf8().constData());
                        OBJECT_ENUM  parentObjectEn = updRecordStp->getDictEntityStp()->getParentObjectEn(updRecordStp);
                        if (parentObjectEn != NullEntity)
                        {
                            auto subDictEntityStp = DBA_GetDictEntitySt(parentObjectEn);
                            SET_STRING(outboxEventStp, A_OutboxEvent_EntityName, SYS_Stringer(dictEntityStp->mdSqlName, "-", subDictEntityStp->mdSqlName).c_str());
                        }
                        else
                        {
                            SET_STRING(outboxEventStp, A_OutboxEvent_EntityName, dictEntityStp->mdSqlName);
                        }

                        SET_STRING(outboxEventStp, A_OutboxEvent_DataT, outputString.c_str());
                        SET_A_OutboxEvent_StatusEn(outboxEventStp, OutboxEventStatusEn::ToPublish);

                        switch (updRecordVector.first)
                        {
                            case Insert:
                                SET_ENUM(outboxEventStp, A_OutboxEvent_ActionEn, Subscription_Action_Insert);
                                break;

                            case Update:
                                SET_ENUM(outboxEventStp, A_OutboxEvent_ActionEn, Subscription_Action_Update);
                                break;

                            case Delete:
                                SET_ENUM(outboxEventStp, A_OutboxEvent_ActionEn, Subscription_Action_Delete);
                                break;
                        }
                        SET_STRING(outboxEventStp, A_OutboxEvent_BusEntityCd, SYS_GetThreadCurrBusinessEntity().c_str());

                        std::string attribListStr;
                        std::string valueListStr;
                        this->getBkInfo(attribListStr, valueListStr, updRecordStp);
                        SET_STRING(outboxEventStp, A_OutboxEvent_BusinesskeyAttribList, attribListStr.c_str());
                        SET_STRING(outboxEventStp, A_OutboxEvent_Businesskey, valueListStr.c_str());

                        requestHelper.startProcedureCallForBatch(Insert, OutboxEvent, UNUSED, outboxEventStp);
                        requestHelper.setNewRecordForBatch(outboxEventStp);
                    }
                }

                if (updRecordVector.first == Insert)
                {
                    totalInsertedNbr += CAST_INT(updRecordVector.second.size());
                }
            }

            if (RET_GET_LEVEL(requestHelper.executeBatch()) != RET_LEV_ERROR)
            {
                this->m_totalInsertedNbr += totalInsertedNbr;
            }
        }

        this->clean();
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function             :  DbiOutboxManager::clean()
*
*   Description          :  Clean structure
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
void DbiOutboxManager::clean()
{
    this->m_recordActionMap.clear();
    this->m_mp.freeAll();
}

/************************************************************************
*   Function             :  DbiOutboxManager::getTotalInsertedNbr()
*
*   Description          :  Clean structure
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
int DbiOutboxManager::getTotalInsertedNbr()
{
    return this->m_totalInsertedNbr;
}

/************************************************************************
*   Function             :  DbiOutboxManager::resetTotalInsertedNbr()
*
*   Description          :  Clean structure
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-55439 - LJE - 240305
*
*************************************************************************/
void DbiOutboxManager::resetTotalInsertedNbr()
{
    this->m_totalInsertedNbr = 0;
}

/************************************************************************
*   Function             :  DbiConnection::DbiConnection()
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation             :
*
*   Modif.               :  PMSTA-26764 - 230317 - PMO : Core file generated
*
*************************************************************************/
DbiConnection::DbiConnection(const AAAConnectionSpecification& spec, const int& id)
    : AAAConnection(spec, id)
    , m_connectToRDBMS(UnknownRdbms)
    , m_lastResultType(0)
    , m_lastResultRetCode(RET_SUCCEED)
    , m_transactCpt(0)
    , m_bSettingsForDdl(false)
    , m_parentDictEntity(0)
    , m_bindNullFlags(nullptr)
    , m_bindFieldLength(nullptr)
    , m_bindFlags(nullptr)
    , m_bindDynStEn(NullDynSt)
    , m_bindColNbr(0)
    , m_bindDynStp(nullptr)
    , m_insertIdentityOn(false)
    , m_oneRecordExpected(false)
    , m_bOnBatchOutput(false)
    , m_resultSetPos(-1)
    , m_ddlGenContextPtr(nullptr)
    , m_scriptDdlGenPtr(nullptr)
    , m_currCharSetEn(CurrentCharsetCode_IsNull)
    , m_dbCommCharSetEn(CurrentCharsetCode_IsNull)
    , m_activitiesSinceLastCommit(0)                         /* PMSTA-37366 - LJE - 191112 */
    , m_fetchSize(0)
    , m_bOptimDataAlloc(false)
    , m_batchBlockSize(1000)
    , m_batchSize(0)
    , m_batchMode(BatchMode::RowByRow)
    , m_ddlGenDbaAccessPtr(nullptr)
    , m_outboxManagerPtr(nullptr)
    , m_TimeOutMiliSec(0)
    , m_isMultiAccessLangRequest(false) /* PMSTA-30586 - DLA - 180404 */
    , m_bCurrentRequestOutputBinded(false)
    , m_bExternalMsgManagement(false)            /* PMSTA-37366 - LJE - 190612 */
    , m_isGUIBehavior(false)
    , m_beginTransToDo(false)
    , m_isAutoTransaction(false)
    , m_transactionInProgress(false)
    , m_bReadOnly(false)
    , m_bDefaultReadOnly(true)
    , m_isDBConnectRetryRequired(false)
    , m_delimiter("~")
{
    this->pushSqlRequest(KindOfRequest::Init);
    this->resetReadOnly();
}

DbiConnection::~DbiConnection()
{
    if (this->m_usedConnectionNbr != 0)
    {
        SYS_BreakOnDebug();
    }

    if (this->getOwningPool() != nullptr)
    {
        this->getOwningPool()->remove(this);
    }

    if (this->getOwingLocalProvider() != nullptr)
    {
        this->getOwingLocalProvider()->remove(this);
    }

    delete this->m_scriptDdlGenPtr;
    delete this->m_ddlGenContextPtr;

    if (this->m_bindDynStEn != NullDynSt && this->m_bindDynStp != nullptr)
    {
        FREE_DYNST(this->m_bindDynStp, this->m_bindDynStEn);
    }

    if (this->m_bindNullFlags != nullptr)
    {
        FREE(this->m_bindNullFlags);
    }

    if (this->m_bindFieldLength != nullptr)
    {
        FREE(this->m_bindFieldLength);
    }

    /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    if (this->m_bindFlags != nullptr)
    {
        FREE(this->m_bindFlags);
    }
    this->clearRequestOutputVector();

    /* PMSTA-55439 - LJE - 240305 */
    if (this->m_outboxManagerPtr != nullptr)
    {
        delete this->m_outboxManagerPtr;
        this->m_outboxManagerPtr = nullptr;
    }
}

DBA_CONNECT_INFO_STP DbiConnection::getConnectionInfo(const int& id)
{
    DBA_CONNECT_INFO_STP res = nullptr;
    DbiConnection* dbiCon = DbiConnection::getConnection(id);
    if (dbiCon != nullptr)
    {
        res = dbiCon->getConnStructPtr();
    }
    return res;
}

void DbiConnection::clean()
{
    this->sendAllMsg();
    this->m_msgStructHeaderSt.clear();

    DBA_CONNECT_INFO_STP connectInfoPtr       = &this->connectSt;
    connectInfoPtr->blockMode                 = 0;
    connectInfoPtr->noDeleteMessageInfo       = 0;
    connectInfoPtr->msgOptions                = NULL;
    connectInfoPtr->preserveConfirmedFlg      = FALSE;					            /* REF11338 */

    connectInfoPtr->subscriptionElem.eventNat = Event_Nature_None;
    FREE_DYNST(connectInfoPtr->subscriptionElem.auditRecStp, connectInfoPtr->subscriptionElem.auditRecSt);

    for (int i = 0; i < connectInfoPtr->subscriptionElem.accessNbr; i++)
    {
        FREE_DYNST(connectInfoPtr->subscriptionElem.accessStp[i].data, connectInfoPtr->subscriptionElem.accessStp[i].entity);
    }
    connectInfoPtr->subscriptionElem.accessNbr = 0;
    FREE(connectInfoPtr->subscriptionElem.accessStp);

    connectInfoPtr->subscriptionElem.currAction = NullAction;
    DBA_FreeDynStTab(connectInfoPtr->subscriptionElem.subscripCodifCompoStp,connectInfoPtr->subscriptionElem.subscripCodifCompoNmb,S_SubscriptionCodifCompo);

    this->resetReadOnly();
    this->m_isGUIBehavior = false;

    this->m_msgStack.clear();

    if (this->m_bindDynStEn != NullDynSt)
    {
        if (this->m_bindDynStp != nullptr)
        {
            FREE_DYNST(this->m_bindDynStp, this->m_bindDynStEn);
        }
        this->m_bindDynStEn = NullDynSt;
    }

    if (this->m_bindNullFlags != nullptr)
    {
        FREE(this->m_bindNullFlags);
    }
    if (this->m_bindFieldLength != nullptr)
    {
        FREE(this->m_bindFieldLength);
    }
    /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    if (this->m_bindFlags != nullptr)
    {
        FREE(this->m_bindFlags);
    }

    /* If a maximum was specified */
    if ((connectInfoPtr->maxRows > 0))
    {
        this->setConnMaxRows(0);
        connectInfoPtr->maxRows = NO_VALUE;
    }

    this->m_usedConnectionNbr        = 0;
    this->m_transactCpt              = 0;
    this->m_lastResultRetCode        = RET_SUCCEED;
    this->m_lastResultType           = 0;
    this->m_resultSetPos             = -1;
    this->m_isMultiAccessLangRequest = false;
    this->m_ddlGenDbaAccessPtr     = nullptr; /* PMSTA-45413 - LJE - 210616 */

    if (this->m_sqlRequestVector.size() != 1 &&
        this->m_sqlRequestVector.back().m_isInit == true)
    {
        SYS_BreakOnDebug(); /* The request vector should equal to 1 on clean, else the callers requests helper called be failed after */
    }

    KindOfRequest kindOfRequest = this->getSqlRequest().m_kindOfRequest;
    this->popSqlRequest(kindOfRequest);

    this->setExternalMsgManagement(false);
    this->m_activitiesSinceLastCommit = 0;

    this->getTargetSessionProperties().resetSessionproperties();

    /* PMSTA-55439 - LJE - 240305 */
    if (this->m_outboxManagerPtr != nullptr)
    {
        delete this->m_outboxManagerPtr;
        this->m_outboxManagerPtr = nullptr;
    }
}

DBA_RDBMS_ENUM DbiConnection::getDbaRDBMS()
{
    return this->m_connectToRDBMS;
}

bool DbiConnection::isInTransaction()
{
    return(this->m_transactCpt > 0 || this->m_transactionInProgress);
}

bool DbiConnection::isAutoTransaction()
{
    return(this->m_isAutoTransaction);
}

/************************************************************************
*   Function             : DbiConnection::bindRecvDynSt()
*
*   Description          : Bind an Oracle result column in a result set with
*                          an application variable
*
*   Arguments            : dbiConn    : a connection object
*                          dynStType  : the format number of the result data
*                          bindData   : the structure used for binding result
*                                      columns.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*************************************************************************/
RET_CODE DbiConnection::bindRecvDynSt(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData)
{
    DBI_SMALLINT      *nullFlags = NULL;
    DBI_SMALLINT      *bindFlags = NULL;
    DBI_INT           *fieldLength = NULL;
    int                colIndex, colNumber, i;
    RET_CODE           retCode = RET_SUCCEED;

    if (this->getCommandPtr() == nullptr)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Retrieve the field number of a dynamic struct. format */
    colNumber = GET_FLD_NBR(dynStType);

    if ((nullFlags = (DBI_SMALLINT*)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    if ((fieldLength = (DBI_INT*)CALLOC(colNumber, sizeof(DBI_INT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    if ((bindFlags = (DBI_SMALLINT *)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        FREE(nullFlags);
        FREE(fieldLength);
        return(RET_MEM_ERR_ALLOC);
    }

    DBA_SetNullFlagsAndLength(*this, nullFlags, fieldLength, bindFlags);

    colIndex = 0;
    for (i = 0; i < colNumber && retCode == RET_SUCCEED; i++)
    {
        /* Test if the current field is a non DB field (not returned by the request */
        if ((IS_DBFLD(dynStType, i) != TRUE && this->getDescription().getType() == SqlServer) ||
            IS_TECHFLD(dynStType, i) == TRUE)
        {
            nullFlags[i] = -1;
            fieldLength[i] = 0;
            bindFlags[i] = 0;
            continue;
        }
        else
        {
            colIndex++;
            bindFlags[i] = 1;
        }

        retCode = this->bindRecvDynFld(dynStType,
                                       bindData,
                                       i,
                                       colIndex,
                                       &nullFlags[i]);
    }

    return(retCode);
}

/************************************************************************
*   Function             : DbiConnection::bindRecvDynFld()
*
*   Description          : Bind a RDBMS result column in a dynFld
*
*   Arguments            : connectNo  : a connection number in the conn. list
*                          dynStType  : the format number of the result data
*                          bindData   : the structure used for binding result
*                                      columns.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*************************************************************************/
RET_CODE DbiConnection::bindRecvDynFld(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData, INT_T  fldIdx, INT_T colIndex, short *nullFlgPtr)
{
    RET_CODE retCode = RET_SUCCEED;
    size_t   allocSize = 0;

    if (CharPtrCType == GET_CTYPE(GET_FLD_TYPE(dynStType, fldIdx)) ||
        TextPtrCType == GET_CTYPE(GET_FLD_TYPE(dynStType, fldIdx)))
    {
        allocSize = GET_MAXDATALEN(GET_FLD_TYPE_MD(dynStType, fldIdx));
        ALLOC_STRFLD(bindData[fldIdx], allocSize);
    }
    else if (UniCharPtrCType == GET_CTYPE(GET_FLD_TYPE(dynStType, fldIdx)) ||
             UniTextPtrCType == GET_CTYPE(GET_FLD_TYPE(dynStType, fldIdx)))
    {
        allocSize = GET_MAXLEN(GET_FLD_TYPE_MD(dynStType, fldIdx));
        ALLOC_USTRFLD(bindData[fldIdx], allocSize);
    }

    retCode = this->colBind(colIndex, GET_FLD_TYPE(dynStType, fldIdx), *GET_FLD_SQLNAME(dynStType, fldIdx), &(bindData[fldIdx]).data, allocSize, nullptr, nullFlgPtr, true, &(bindData[fldIdx]).flgMask, nullptr);

    return(retCode);
}

RET_CODE DbiConnection::bindRecvDynSqlEntity(OBJECT_ENUM object, DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData)
{
    DBI_SMALLINT   *nullFlags = NULL;
    DBI_SMALLINT   *bindFlags = NULL;
    DBI_INT        *fieldLength = NULL;
    int             colIndex, colNumber, i;

    /* Retrieve the field number of a dynamic struct. format */
    colNumber = GET_FLD_NBR(dynStType);

    if ((nullFlags = (DBI_SMALLINT*)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    if ((fieldLength = (DBI_INT*)CALLOC(colNumber, sizeof(DBI_INT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    if ((bindFlags = (DBI_SMALLINT *)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        FREE(nullFlags);
        FREE(fieldLength);
        return(RET_MEM_ERR_ALLOC);
    }

    DBA_SetNullFlagsAndLength(*this, nullFlags, fieldLength, bindFlags);

    colIndex = 0;
    for (i = 0; i < colNumber; i++)
    {
        /* Test if the current field is a non DB field (not returned by the request */
        if (IS_DBFLD(dynStType, i) != TRUE ||
            (GET_EDITGUIST(object) == dynStType && DBA_GetDictAttribCalcEn(object, i) == DictAttr_Calculated) ||
            IS_TECHFLD(dynStType, i) == TRUE)   /* PMSTA-18593 - LJE - 151130 */
        {
            nullFlags[i] = -1;
            fieldLength[i] = 0;
            bindFlags[i] = 0;
            continue;
        }
        else
        {
            colIndex++;
            bindFlags[i] = 1;
        }

        this->bindRecvDynFld(dynStType,
                             bindData,
                             i,
                             colIndex,
                             &nullFlags[i]);
    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DbiConnection::filterMsgInfos()
*
*   Description          : Send the message
*
*   Arguments            : file         : FILEINFO
*                          line         : FILEINFO
*                          errMsg       : Error message
*
*   Functions call       :
*
*   Return               : None
*
*   Creation date        :
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::filterMsgInfos(RET_CODE *retCode, FLAG_T *samePwdMsgFlag)
{
    DBA_CONNECT_INFO_STP connInfo = this->getConnStructPtr();

    /* Keep only errors */
    if (RET_GET_LEVEL(this->m_lastResultRetCode) != RET_LEV_ERROR)
    {
        this->m_lastResultRetCode = RET_SUCCEED;
    }

    if (retCode != nullptr)
    {
        *retCode = this->m_lastResultRetCode;
    }

    /* PMSTA-18048 - SHR - FIX user import error, ignore message raise for same password */
    if (this->isSamePasswordMsg())
    {
        if (samePwdMsgFlag != NULL)
        {
            *samePwdMsgFlag = TRUE;
        }
    }
    else
    {
        int               msgNbr   = this->m_msgStack.size();
        DbaMsgStackClass &msgStack = this->m_msgStack;
        char              minMsgLevel = 10;

        for (int i = 0; i < msgNbr; i++)
        {
            DbaMsgStackMemberClass &msgMember = msgStack.getMember(i);
            RET_CODE                currRetCode = RET_SUCCEED;

            if (msgMember.isTrfToMsgStruct)
            {
                continue;
            }

            int techMsg = FALSE;

            switch (msgMember.msgOrigin)
            {
                case ServerHandler:
                {
                    /* If the message is generated by a trigger (with a GUI message) */
                    size_t levelPos = msgMember.msgString.find("lev=");
                    size_t msgPos = std::string::npos;

                    if (levelPos != std::string::npos)
                    {
                        msgPos = msgMember.msgString.find(":", levelPos);
                    }

                    if (msgPos != std::string::npos)
                    {
                        msgPos += 2;

                        char msgLevel = msgMember.msgString[levelPos + 4] - 48;

                        DbaErrmsgInfosClass &msgStructSt = this->m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                        msgMember.isTrfToMsgStruct = true;

                        msgStructSt.techMsg              = FALSE;
                        msgStructSt.gravity              = msgLevel;
                        msgStructSt.msgOrigin            = ServerHandler;
                        msgStructSt.rdbmsMsgNb           = msgMember.rdbmsMsgNb;
                        msgStructSt.retCode              = msgMember.retCode;
                        msgStructSt.line                 = msgMember.line; /* PMSTA-14452 - LJE - 130115 */
                        msgStructSt.isAlreadyWritedInLog = msgMember.isAlreadyWritedInLog;
                        msgStructSt.serverName           = msgMember.serverName;
                        msgStructSt.procedure            = msgMember.procedure;
                        msgStructSt.rdbmsMsgString       = msgMember.msgString;
                        msgStructSt.msgString            = msgMember.msgString.substr(msgPos);

                        size_t eolPos = msgStructSt.msgString.find("\n");
                        if (eolPos != std::string::npos)
                        {
                            msgStructSt.msgString.erase(eolPos);
                        }

                        this->m_lastResultRetCode = msgMember.retCode;

                        /**** BEGIN DVP209 ****/
                        if (this->m_lastResultRetCode == RET_SRV_LIB_ERR_DUPLICATEKEY && strstr(msgStructSt.msgString.c_str(), "operation") != NULL)
                        {
                            continue;
                        }
                        /**** END  DVP209 ****/

                        /* PMSTA-20887 - LJE - 150914 */
                        /* update failed(entity "..." having code "...") due to a mismatch of the external sequence number; message 20289 */
                        if (this->m_lastResultRetCode == RET_DBA_INFO_EXTERNAL_SEQ)
                        {
                            continue;
                        }

                        if (msgLevel < minMsgLevel)
                        {
                            if (msgLevel == 1)
                                this->m_lastResultRetCode = RET_SRV_LIB_ERR_TRIGGER_MSG;
                            else
                                this->m_lastResultRetCode = RET_SRV_INFO_TRIGGER_MSG;

                            minMsgLevel = msgLevel;
                        }

                        continue;
                    }

                    currRetCode = msgMember.retCode;
                    techMsg = DBI_MsgError::isTechMsg(currRetCode);
                    switch (currRetCode)
                    {
                        case RET_SRV_LIB_ERR_DEADLOCK:
                            if (this->isInTransaction())
                            {
                                this->m_transactCpt = -1; /* REF4001 - SSO - 991004 */
                                /* if we where outside transaction (transactCpt == 0), we leave the value
                                (only the last command has been aborted and NOT a whole block) */
                            }
                            break;
                        case RET_FIN_ERR_SECURITY_ISSUE:
                            msgMember.retCode = RET_FIN_ERR_SECURITY_ISSUE;
                            break;
                    }


                    if (currRetCode != RET_SUCCEED)
                    {
                        DbaErrmsgInfosClass &msgStructSt = this->m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                        msgMember.isTrfToMsgStruct = true;

                        msgStructSt.gravity              = RET_GET_LEVEL(currRetCode);
                        msgStructSt.msgOrigin            = ServerHandler;
                        msgStructSt.rdbmsMsgNb           = msgMember.rdbmsMsgNb;
                        msgStructSt.retCode              = msgMember.retCode;
                        msgStructSt.line                 = msgMember.line; /* PMSTA-14452 - LJE - 130115 */
                        msgStructSt.isAlreadyWritedInLog = msgMember.isAlreadyWritedInLog;
                        msgStructSt.serverName           = msgMember.serverName;
                        msgStructSt.procedure            = msgMember.procedure;
                        msgStructSt.msgString            = msgMember.msgString;
                        msgStructSt.rdbmsMsgString       = msgMember.msgString;
                        msgStructSt.result               = currRetCode;

                        if (techMsg == TRUE &&
                            msgMember.isAlreadyWritedInLog == false &&
                            this->isExternalMsgManagement() == false)
                        {
                            msgStructSt.techMsg = TRUE;
                            MSG_LogMesgWithMsgStruct(currRetCode, &msgStructSt, FILEINFO);
                        }

                        if (this->m_ddlGenDbaAccessPtr != nullptr &&
                            this->m_ddlGenDbaAccessPtr->getDdlGenContext().m_buildBindOptionPtr != nullptr)
                        {
                            this->m_ddlGenDbaAccessPtr->getDdlGenContext().m_buildBindOptionPtr->printMsg(ProcessingMessageNatEn::Error, msgStructSt.retCode, msgStructSt.msgString);
                        }
                    }

                    /* Warning during fetch: cannot convert in client character set. PEN/GRD 23/09/1998 */
                    if (currRetCode == RET_SRV_INFO_CHARSET_CONV_ISSUE) /* PMSTAXXX - DLA - 180910 */
                    {
                        currRetCode = RET_SUCCEED;
                    }
                }
                break;

                case ClientHandler:
                    currRetCode = msgMember.retCode;
                    break;
            }

            /* Keep the first error */
            if (RET_GET_LEVEL(this->m_lastResultRetCode) != RET_LEV_ERROR)
            {
                this->m_lastResultRetCode = currRetCode;
            }
        }
    }

    if (connInfo->noDeleteMessageInfo == 0)
    {
        this->m_msgStack.clear();
    }

    if (retCode != nullptr)
    {
        *retCode = this->m_lastResultRetCode;
    }
}

/************************************************************************
*   Function             : DbiConnection::sendAllMsg()
*
*   Description          : Send the message
*
*   Arguments            :
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-37366 - LJE - 190606
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::sendAllMsg()
{
    if (this->emptyMsg() == false && this->isExternalMsgManagement() == false)
    {
        for (auto msgStructIt = this->m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != this->m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
        {
            if (msgStructIt->isAlreadyWritedInLog == false)
            {
                MSG_LogMesgWithMsgStruct(msgStructIt->retCode, &(*msgStructIt), msgStructIt->m_file, msgStructIt->m_line);
                msgStructIt->isAlreadyWritedInLog = true;
            }
        }
    }
}

/************************************************************************
*   Function             : DbiConnection::sendAllMsgFromMA()
*
*   Description          : Send the message
*
*   Arguments            :
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-37366 - LJE - 190606
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::sendAllMsgFromMA()
{
    if (this->emptyMsg() == false)
    {
        for (auto msgStructIt = this->m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != this->m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
        {
            if (msgStructIt->isAlreadyWritedInLog == false)
            {
                MSG_SendMsgInfosFromMA(&(*msgStructIt));
                msgStructIt->isAlreadyWritedInLog = true;
            }
        }
    }
}

/************************************************************************
*   Function             : DbiConnection::dispAllMsgText()
*
*   Description          : Send the message
*
*   Arguments            :
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-37366 - LJE - 190606
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::dispAllMsgText()
{
    if (this->emptyMsg() == false)
    {
        for (auto msgStructIt = this->m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != this->m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
        {
            if (msgStructIt->isAlreadyWritedInLog == false)
            {
                MSG_DispMsgText(msgStructIt->retCode, msgStructIt->getMsgString().c_str());
                msgStructIt->isAlreadyWritedInLog = true;
            }
        }
    }
}

/************************************************************************
*   Function             : DbiConnection::emptyMsg()
*
*   Description          : Send the message
*
*   Arguments            :
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-37366 - LJE - 190606
*
*   Last Modif. Date     :
*
*************************************************************************/
bool DbiConnection::emptyMsg()
{
    if (this->m_msgStructHeaderSt.empty())
    {
        RET_CODE retCode;
        this->filterMsgInfos(&retCode);

        if (retCode != RET_SUCCEED)
        {
            this->m_lastResultRetCode = retCode;
        }
    }

    return this->m_msgStructHeaderSt.empty();
}

/************************************************************************
*   Function             : DbiConnection::clearMsg()
*
*   Description          : Send the message
*
*   Arguments            :
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-37366 - LJE - 200619
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::clearMsg()
{
    if (this->m_msgStructHeaderSt.empty() == false)
    {
        if (EV_PrintAllMessages)
        {
            for (auto msgStructIt = this->m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != this->m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
            {
                if (msgStructIt->isAlreadyWritedInLog == false)
                {
                    MSG_DispMsgText(msgStructIt->retCode, msgStructIt->getMsgString().c_str());
                }
            }
        }
        this->m_msgStructHeaderSt.clear();
    }
}

/************************************************************************
*   Function             : DbiConnection::sendMsg()
*
*   Description          : Send the message
*
*   Arguments            : file         : FILEINFO
*                          line         : FILEINFO
*                          errMsg       : Error message
*
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*   Last Modif. Date     :
*
*************************************************************************/
void DbiConnection::sendMsg(const char * file, const int line, const std::string & errMsg)
{
    if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
    {
        MSG_SendMesg(file, line, errMsg);
    }
    else
    {
        MSG_SendStrToLog(errMsg);
    }
}

/************************************************************************
*   Function             :  DbiConnection:setExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::setExternalMsgManagement(bool bExternalMsgManagement)
{
    this->m_bExternalMsgManagement = bExternalMsgManagement;
}

/************************************************************************
*   Function             :  DbiConnection:isExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnection::isExternalMsgManagement()
{
    return this->m_bExternalMsgManagement && EV_PrintAllMessages == false;
}

/************************************************************************
*   Function             :  DbiConnection:isAutoCommit()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnection::isAutoCommit()
{
    return (this->isDbTransactionRequired() == false);
}

/************************************************************************
*   Function             :  DbiConnection:initRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191216
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::initRequest(DBA_ACTION_ENUM currentAction, bool bFromRequestHelper)
{
    if (this->getSqlRequest().m_isInit == false)
    {
        this->getSqlRequest().m_isInit             = true;
        this->getSqlRequest().m_bFromRequestHelper = bFromRequestHelper;
        this->setCurrentAction(currentAction);
        this->setCurrProcedure(nullptr);
    }
}

/************************************************************************
*   Function             : DbiConnection::doStartRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE DbiConnection::doStartRequest()
{
    /* Must be empty */
    return RET_SUCCEED;
}


/************************************************************************
*   Function             :  DbiConnection:startRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::startRequest()
{
    bool beginTransDone = (this->m_transactionInProgress && this->m_isAutoTransaction == false);

    if (this->isValid() == false ||
        this->doReleaseCommand() != RET_SUCCEED)
    {
        if (this->reconnect() == false)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
        }
    }
    else if (this->isInTransaction() == false)
    {
        this->m_activitiesSinceLastCommit = 0;
    }

    this->m_msgStack.clear();
    this->m_msgStructHeaderSt.clear();
    this->m_messageVector.clear();
    this->m_errorConstraint.clear();
    this->getSqlRequest().m_batchOutputSet.clear();

    this->m_lastResultRetCode = this->applyPropertiesOnConnection();

    if (RET_GET_LEVEL(this->m_lastResultRetCode) != RET_LEV_ERROR)
    {
        this->m_lastResultRetCode = RET_SUCCEED;
    }
    else
    {
        if (this->isValid() == false || this->reconnect() == false)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
        }
        else
        {
            this->m_lastResultRetCode = this->applyPropertiesOnConnection();

            if (RET_GET_LEVEL(this->m_lastResultRetCode) != RET_LEV_ERROR)
            {
                this->m_lastResultRetCode = RET_SUCCEED;
            }
        }
    }

    this->m_lastResultType                = DBI_CMD_SUCCEED;
    this->m_lastResultRetCode             = this->doStartRequest();
    this->m_activitiesSinceLastCommit++;
    this->m_bCurrentRequestOutputBinded   = false;
    this->m_batchSize                     = 0;
    this->getSqlRequest().m_currResultSet = 0;

    if (this->m_beginTransToDo &&
        this->m_transactionInProgress == false)
    {
        this->m_beginTransToDo = false;

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

        this->pushSqlRequest(KindOfRequest::Internal);

        if (EV_sqlFile != NULL || sqlTraceLog.isInfoEnabled())
        {
            auto& sqlTrace = this->getSqlTrace();
            sqlTrace.m_command = "begin_transaction";
            sqlTrace.m_procedure = "begin_transaction";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_logLevel = AAALogger::Level::Info;
        }

        this->m_lastResultRetCode     = this->doBeginTransaction();
        if (RET_GET_LEVEL(this->m_lastResultRetCode) == RET_LEV_ERROR &&
            this->isValid() == false)
        {
            if (this->reconnect() == false)
            {
                this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
            }
            this->m_lastResultRetCode = this->doBeginTransaction();
        }

        this->m_transactionInProgress = true;

        if (EV_sqlFile != NULL || sqlTraceLog.isInfoEnabled())
        {
            this->sendSqlTrace();
        }
        this->popSqlRequest();
    }

    this->m_lastResultRetCode             = this->doStartRequest();              /* PMSTA-45413 - LJE - 220217 */
    if (RET_GET_LEVEL(this->m_lastResultRetCode) == RET_LEV_ERROR &&
        beginTransDone &&
        this->isValid() == false)
    {
        if (this->reconnect() == false)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
        }
        this->m_lastResultRetCode = this->doStartRequest();
    }
}

/************************************************************************
**
**  Function    :   DbiConnection::connect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool DbiConnection::connect()
{
    this->m_msgStructHeaderSt.clear();
    this->getConnSessionPropertiesForUpd().resetSessionproperties();

    bool ret = this->doConnect();

    if (ret == true)
    {
        setConnectionStatus(true);
    }
    else
    {
        setConnectionStatus(false);
        if (m_isDBConnectRetryRequired == true)
        {
            /* retry till a global max waiting threshold */
            while (SYS_TimeWaitedSoFar() < SYS_MaxWaitThreshold())
            {
                int waitTime = SYS_GetWaitTime();
                const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
                if (connectionLog.isDebugEnabled())
                {
                    std::string	logMessage = SYS_Stringer("Unable to get database connection, thread - ",
                                                           SYS_GetThreadDescriptionForLog().c_str(),
                                                           " - waiting for ", waitTime, " milliseconds before retry...");
                    connectionLog.debug(logMessage);
                }
                SYS_MilliSleep(waitTime);
                if (this->doConnect())
                {
                    m_isDBConnectRetryRequired = false;
                    setConnectionStatus(true);
                    break; /* got a connection, come out of the retry loop */
                }

                if (SYS_TimeWaitedSoFar() >= SYS_MaxWaitThreshold())
                {
                    /* Waited enough for a db connection, now shutdown immediate fin server */
                    if (connectionLog.isDebugEnabled())
                    {
                        std::string	logMessage = SYS_Stringer("Unable to get database connection, thread - ",
                            SYS_GetThreadDescriptionForLog().c_str(),
                            " - after waiting for ", SYS_MaxWaitThreshold(), " milliseconds. Shutting down the server...");
                        connectionLog.debug(logMessage);
                    }
                    SYS_Shutdown(EXIT_FAILURE);
                }
            }
        }
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

    if (EV_sqlFile != NULL || sqlTraceLog.isTraceEnabled())
    {
        DbiSqlTrace sqlTrace;

        sqlTrace.m_command = "ct_connect";
        sqlTrace.m_procedure = "ct_connect";
        sqlTrace.m_retCode = ret;
        sqlTrace.m_request << "connection";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Connection;
        sqlTrace.m_logLevel= AAALogger::Level::Trace;

        sqlTrace.sendSqlTrace();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DbiConnection::disconnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool DbiConnection::disconnect()
{
    this->m_bSettingsForDdl           = false;
    this->m_tempTablesMask            = 0;
    this->m_activitiesSinceLastCommit = 0;
    this->m_transactCpt               = 0;
    this->closeMessageBehavior();

    this->getConnSessionPropertiesForUpd().resetSessionproperties();

    bool res = this->doDisconnect();

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isTraceEnabled())
    {
        DbiSqlTrace sqlTrace;

        sqlTrace.m_command = "ct_disconnect";
        sqlTrace.m_procedure = "ct_disconnect";
        sqlTrace.m_retCode = res;
        sqlTrace.m_request << "disconnection";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Connection;
        sqlTrace.m_logLevel = AAALogger::Level::Trace;

        sqlTrace.sendSqlTrace();
    }

    this->setConnected(false);

    return res;
}

/************************************************************************
**
**  Function    :   DbiConnection::reconnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :   PMSTA-37366 - LJE - 200617
**
**  Last modif. :   HFI-PMSTA-52746-2023-04-18  Error in create temp tables on reconnection
**
*************************************************************************/
bool DbiConnection::reconnect()
{
    bool bIsInTran = this->isInTransaction();
    if (bIsInTran == false || this->m_activitiesSinceLastCommit == 0)
    {
        int          usedConnectionNbr    = this->m_usedConnectionNbr;
        unsigned int tempTablesMask       = this->m_tempTablesMask;
        this->m_activitiesSinceLastCommit = 0;

        if (this->isConnected())
        {
            this->disconnect();
        }
        if (this->connect() == false)
        {
            return false;
        }
        this->m_usedConnectionNbr = usedConnectionNbr;

        if (this->isValid())
        {
            if (this->m_onApplySessionProperties == false)
            {
                this->applyPropertiesOnConnection();
                DBA_CreateTempTables(*this, tempTablesMask);
                if (bIsInTran)
                {
                    this->beginTransaction();
                }

                for (auto &it : this->m_disableIdentitySet)
                {
                    this->disableIdentity(it.first, it.second);
                }
            }
        }
        else
        {
            return false;
        }

        return true;
    }

    return false;
}

/************************************************************************
*   Function             :  DbiConnection::release()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::release(void)
{
    AAAConnection::release();

    this->getSqlRequest().m_isInit = false;
    this->setCurrentAction(NullAction);

    if (this->isInUse())
    {
        this->clean();
        this->setState(AAAConnectionState::AVAILABLE);

        if (this->getOwingLocalProvider() != nullptr)
        {
            this->getOwingLocalProvider()->release(this);
        }
        else if (this->getOwningPool() != nullptr)
        {
            this->getOwningPool()->release(this);
        }
    }
    else /* Release an unused connection is not normal... */
    {
        SYS_BreakOnDebug();
    }
}

/************************************************************************
*   Function             :  DbiConnection::endConnection()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnection::endConnection(bool isInError)
{
    /* PMSTA-34402 - LJE - 190122 */
    if (this->m_usedConnectionNbr > 1)
    {
        this->m_usedConnectionNbr--;

        return RET_GEN_INFO_NOACTION;
    }

    if (this->isInTransaction())
    {
        char* buffer = (char*)CALLOC(255, sizeof(char));

        sprintf(buffer, "Warning: DBA_EndConnection called with non-zero transaction counter (connection %d/ tran %d) ROLLBACK done",
                this->getId(), this->m_transactCpt);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
        FREE(buffer);
        this->endTransaction(FALSE);
    }
    else if (this->isReadOnly() == false)
    {
        /* PMSTA-18593 - LJE - 151030 - Put here to manage all time the transaction */
        this->endTransaction(TRUE);
    }
    else if (EV_CheckTransState)
    {
        int transState = this->getTransState();
        if (transState > 0)
        {
            char* buffer = (char*)CALLOC(255, sizeof(char));

            sprintf(buffer, "Warning: DBA_EndConnection called with transaction state > 0 (connection %d/ tran %d) ROLLBACK done",
                    this->getId(), transState);
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
            FREE(buffer);
            this->endTransaction(FALSE);
        }
    }

    if (isInError)
    {
        this->setValidConnection(false);
    }

    this->release();

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DbiConnection::reopenOnThreadChange()
**
**  Description :
**
**  Argument    :
**
**  Return               :  true    Connection was reopened
**                          false   Nothing was done
**
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool DbiConnection::reopenOnThreadChange()
{
    return false;
}

/************************************************************************
**
**  Function    :   DbiConnection::setOptimDataAlloc()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
void DbiConnection::setOptimDataAlloc()
{
    this->m_bOptimDataAlloc = true;
}

/************************************************************************
**
**  Function    :   DbiConnection::setBatchBlockSize()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
void DbiConnection::setBatchBlockSize(int batchBlockSize)
{
    this->m_batchBlockSize = batchBlockSize;
}

/************************************************************************
**
**  Function    :   DbiConnection::addBatch()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DbiConnection::addBatch()
{
    this->m_lastResultRetCode = this->doAddBatch();

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        this->m_batchSize++;
    }

    return this->m_lastResultRetCode;
}

/************************************************************************
**
**  Function    :   DbiConnection::executeBatch()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DbiConnection::executeBatch()
{
    this->m_lastResultRetCode = this->doExecuteBatch();

    this->m_batchSize = 0;

    return this->m_lastResultRetCode;
}

/************************************************************************
**
**  Function    :   DbiConnection::setDelimiter()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
void DbiConnection::setDelimiter(std::string delimiter)
{
    this->m_delimiter = delimiter;
}

/************************************************************************
**
**  Function    :   DbiConnection::getDelimiter()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
std::string DbiConnection::getDelimiter()
{
    return this->m_delimiter;
}


DbiConnection* DbiConnection::getConnection(const int& id)
{
    DbiConnection* dbiCon = AAALocalConnectionProvider::get().getConnection(id);
    return dbiCon;
}

void DbiConnection::incTransaction()
{
    if (this->m_transactCpt <= 0)
    {
        this->setReadOnly(false);
        this->m_transactCpt = 1;
    }
    else
    {
        this->m_transactCpt++;
    }
}

void DbiConnection::decTransaction(const FLAG_T status)
{
    if (this->m_transactCpt < 0)
    {
        this->m_transactCpt = 0;
    }
    else
    {
        this->m_transactCpt--;
    }

    /* All transaction are closed and some works must be done / REF9538 - 031507 - PMO */
    if (this->isInTransaction() == false &&
        this->m_workOnCloseConnectionVector.empty() == false)
    { /* Yes */

        auto workOnCloseConnectionVector = this->m_workOnCloseConnectionVector;
        this->m_workOnCloseConnectionVector.clear();

        for (auto it = workOnCloseConnectionVector.begin(); it != workOnCloseConnectionVector.end(); ++it)
        {
            switch (status)
            {
                case FALSE: /* Rollback */
                    if (nullptr != it->onRollback)
                    {
                        it->onRollback(it->pData, *this);
                    }
                    break;

                case TRUE: /* Commit */
                    if (nullptr != it->onCommit)
                    {
                        it->onCommit(it->pData, *this);
                    }
                    break;

                default:
                    /* No code */
                    break;
            }

            /* Free memory */
            if (nullptr != it->free)
            {
                it->free(it->pData);
                FREE(it->pData);
            }

        } /* End for */
    }

    if (this->m_transactCpt == 0)
    {
        this->resetReadOnly();
    }
}

RET_CODE DbiConnection::setPropertyByStoredProc(const std::string &storedProcSqlName, ID_T valueId)
{
    std::string str;
    GEN_GetApplInfo(ApplSqlDbName, str);
    if (str.empty() == false)
    {
        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);
        requestHelper.setCommand("#EXEC " + str + "." + storedProcSqlName + " ?");
        requestHelper.addNewParamId(valueId);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_procedure = "DynSql.setPropertyBySProc";
        }

        return requestHelper.sendAndGetCommand();
    }
    return RET_DBA_INFO_NODATA;
}

RET_CODE DbiConnection::setPropertyByStoredProc(const std::string &storedProcSqlName, INT_T valueInt)
{
    std::string str;
    GEN_GetApplInfo(ApplSqlDbName, str);
    if (str.empty() == false)
    {
        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);
        requestHelper.setCommand("#EXEC " + str + "." + storedProcSqlName + " ?");
        requestHelper.addNewParamInt(valueInt);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_procedure = "DynSql.setPropertyBySProc";
        }

        return requestHelper.sendAndGetCommand();
    }
    return RET_DBA_INFO_NODATA;
}

RET_CODE DbiConnection::setPropertyByStoredProc(const std::string &storedProcSqlName, ENUM_T valueEn)
{
    std::string str;
    GEN_GetApplInfo(ApplSqlDbName, str);
    if (str.empty() == false)
    {
        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);
        requestHelper.setCommand("#EXEC " + str + "." + storedProcSqlName + " ?");
        requestHelper.addNewParamUChar(valueEn);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_procedure = "DynSql.setPropertyBySProc";
        }

        return requestHelper.sendAndGetCommand();
    }
    return RET_DBA_INFO_NODATA;
}

RET_CODE DbiConnection::setPropertyByStoredProc(const std::string &storedProcSqlName)
{
    std::string str;
    GEN_GetApplInfo(ApplSqlDbName, str);
    if (str.empty() == false)
    {
        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("#EXEC " + str + "." + storedProcSqlName);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_procedure = "DynSql.setPropertyBySProc";
        }

        return requestHelper.sendAndGetCommand();
    }
    return RET_DBA_INFO_NODATA;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setApplSession()
*
*   Description          :  Set current appl session on connection
*
*   Arguments            :
*
*   Return               :  RET_CODE
*   Creation             :  PMSTA-28916 - LJE - 171213
*   Modif.               :
*
*************************************************************************/
RET_CODE DbiConnection::setApplSession(DBA_DYNFLD_STP applSessionStp)
{
    RET_CODE ret = RET_SUCCEED;
    if (applSessionStp != nullptr)
    {
        RequestHelper requestHelper(this);
        std::string str;
        GEN_GetApplInfo(ApplSqlDbName, str);
        requestHelper.useDb(str);
        this->useDb(str);

        ret = DBA_Update2(ApplSession, DBA_ROLE_SET_APPL_SESSION, A_ApplSession, applSessionStp, DBA_SET_CONN | DBA_NO_CLOSE, *this, nullptr);

        if (ret == RET_SUCCEED)
        {
            this->getConnSessionPropertiesForUpd().setApplSessionStp(applSessionStp);
        }
        else
        {
            this->getConnSessionPropertiesForUpd().setApplSessionCd("Invalid");
        }
    }
    return ret;
}


/************************************************************************
*   Function             :  DbiConnection::setAppContext()
*
*   Description          :  Set current appl context on connection
*
*   Arguments            :
*
*   Return               :  RET_CODE
*   Creation             :  PMSTA-28916 - LJE - 171213
*   Modif.               :
*
*************************************************************************/
RET_CODE DbiConnection::setAppContext(const std::string &propertyName, ID_T propertyValueId)
{
    std::stringstream stream;
    stream << propertyValueId;

    return this->setAppContextProperty(propertyName, stream.str());
}


/************************************************************************
*   Function             :  DbiConnection::setLanguageDictId()
*
*   Description          :  Set current language_dict_id on connection
*
*   Arguments            :
*
*   Return               :  RET_CODE
*   Creation             :  PMSTA-34344 - LJE - 201224
*   Modif.               :
*
*************************************************************************/
RET_CODE DbiConnection::setLanguageDictId(DICT_T propertyValueId)
{
    RequestHelper requestHelper(this);

    std::stringstream stream;
    stream << "#EXEC #AAAMAIN_DB.set_language_dict_id " << propertyValueId;

    requestHelper.setCommand(stream.str());
    requestHelper.sendAndGetCommand();

    return requestHelper.getLastRetCode();
}

/************************************************************************
*   Function             :  DbiConnection::isTechMsg()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  true if messages have at least one technical
*
*   Creation             :  PMSTA-43018 - LJE - 220601
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isTechMsg()
{
    for (int i = 0; i < this->m_msgStack.size(); i++)
    {
        if (DBI_MsgError::isTechMsg(this->m_msgStack.getMember(i).retCode))
        {
            return true;
        }
    }
    return false;
}

/************************************************************************
*   Function             :  DbiConnection::isDbAccessByRequestHelper()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  The timeout value in millisecond
*
*   Creation             :  PMSTA-34344 - LJE - 201001
*
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isDbAccessByRequestHelper()
{
    switch (this->m_connectToRDBMS)
    {
        case Sybase:
        case Oracle:
            return false;
    }

    if (this->getDescription().getType() == FinServer ||
        this->getDescription().getType() == DispatchServer)
    {
        return false;
    }

    return true;
}

/************************************************************************
*   Function             :  DbiConnection::isStatementInProgress()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  The timeout value in millisecond
*
*   Creation             :  PMSTA-37366 - LJE - 190502
*
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isStatementInProgress()
{
    return(this->m_lastResultType == DBI_ROW_RESULT);
}

/************************************************************************
*   Function             :  DbiConnection::isReadOnly()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation             :  PMSTA-34402 - LJE - 161129
*
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isReadOnly()
{
    return this->m_bReadOnly;
}

/************************************************************************
*   Function             :  DbiConnection::setReadOnly()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-34402 - LJE - 161129
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setReadOnly(bool bReadOnly)
{
    if (this->m_bDefaultReadOnly ||
        (bReadOnly == false && this->m_bReadOnly == true))
    {
        this->m_bReadOnly = bReadOnly;
        this->m_bDefaultReadOnly = false;
    }
}

/************************************************************************
*   Function             :  DbiConnection::setReadOnly()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-34402 - LJE - 190111
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setReadOnly(DBA_PROC_STP procStp)
{
    DBA_CONNECT_TYPE_ENUM  procDmlAccess = procStp->connection;

    if (procDmlAccess == Synchronous)
    {
        if (procStp->server == FinServer ||
            procStp->server == InternalProc)    /* PMSTA-45413 - LJE - 210729 */
        {
            procDmlAccess = ReadOnly;
        }
        else
        {
            switch (procStp->action)
            {
                case Get:
                case Select:
                case Check:
                    procDmlAccess = ReadOnly;
                    break;

                case MultiSelect:
                case Notif:
                    procDmlAccess = WriteTempTable;
                    break;

                case Truncate:
                case Insert:
                case InsUpd:
                case Delete:
                case Update:
                case Copy:
                default:
                    procDmlAccess = WriteTable;
                    break;
            }
        }
    }

    this->setReadOnly(procDmlAccess == ReadOnly);
}

/************************************************************************
*   Function             :  DbiConnection::resetReadOnly()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-34402 - LJE - 190111
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::resetReadOnly()
{
    this->m_bReadOnly = (this->getSpecification().getType() == SqlServer || this->getSpecification().getType() == DispatchServer ) ? false : true;
    this->m_bDefaultReadOnly = true;
}


/************************************************************************
*   Function             :  DbiConnection::getTimeOutMiliSec()
*
*   Description          :  Get the timeout value in millisecond
*
*   Arguments            :  None
*
*   Return               :  The timeout value in millisecond
*
*   Creation             :  PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*
*   Modif.               :
*
*************************************************************************/
unsigned  DbiConnection::getTimeOutMiliSec()
{
    return m_TimeOutMiliSec;
}

/************************************************************************
*   Function             :  DbiConnection::setTimeOutMSec()
*
*   Description          :  Define the timeout value in millisecond
*
*   Arguments            :  The timeout in millisecond
*
*   Return               :  None
*
*   Creation             :  PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setTimeOutMiliSec(const unsigned timeOutMiliSec)
{
    m_TimeOutMiliSec = timeOutMiliSec;
}

/************************************************************************
*   Function             :  DbiConnection::isMultiAccessLangRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-30586 - DLA - 180404
*
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isMultiAccessLangRequest()
{
    return m_isMultiAccessLangRequest;
}

/************************************************************************
*   Function             :  DbiConnection::setMultiAccessLangRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-30586 - DLA - 180404
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setMultiAccessLangRequest(const bool pVal)
{
    m_isMultiAccessLangRequest = pVal;
}

/************************************************************************
*   Function             :  DbiConnection::setFetchSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-37374 - LJE - 201026
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setFetchSize(int fetchSize)
{
    this->m_fetchSize = fetchSize;
}

/************************************************************************
*   Function             :  DbiConnection::getFetchSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-37374 - LJE - 201026
*
*   Modif.               :
*
*************************************************************************/
int DbiConnection::getFetchSize()
{
    return this->m_fetchSize;
}

/************************************************************************
*   Function             :  DbiConnection::isBatchMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-37366 - LJE - 200402
*
*   Modif.               :
*
*************************************************************************/
bool DbiConnection::isBatchMode()
{
    return this->m_batchMode != BatchMode::RowByRow;
}

/************************************************************************
*   Function             :  DbiConnection::getBatchMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-37366 - LJE - 200402
*
*   Modif.               :
*
*************************************************************************/
DbiConnection::BatchMode DbiConnection::getBatchMode()
{
    return this->m_batchMode;
}

/************************************************************************
*   Function             :  DbiConnection::setBatchMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation             :  PMSTA-37366 - LJE - 200402
*
*   Modif.               :
*
*************************************************************************/
void DbiConnection::setBatchMode(DbiConnection::BatchMode &batchMode)
{
    this->m_batchMode = batchMode;

    if (this->m_batchMode == DbiConnection::BatchMode::TryBCP &&
        this->isBcpAllowed() == false)
    {
        this->m_batchMode = DbiConnection::BatchMode::ExecuteOnce;
    }

    batchMode = this->m_batchMode;
}


std::string DbiConnection::endOfCmd()
{
    return std::string();
}

DBA_ACTION_ENUM DbiConnection::getCurrentAction()
{
    return this->getSqlRequest().m_currentAction;
}

void DbiConnection::setCurrentAction(DBA_ACTION_ENUM currentAction)
{
    this->getSqlRequest().m_currentAction = currentAction;
}

DBA_PROC_STP DbiConnection::getCurrProcedure()
{
    return this->getSqlRequest().m_currProcedure;
}

void DbiConnection::setCurrProcedure(DBA_PROC_STP currProcedure)
{
    this->getSqlRequest().m_currProcedure = currProcedure;
}

/************************************************************************
*   Function             :  DbiConnection::setGUIBehavior()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201223
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::setGUIBehavior(bool isGUIBehavior)
{
    this->m_isGUIBehavior = isGUIBehavior;
}

/************************************************************************
*   Function             :  DbiConnection::isGUIBehavior()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201223
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnection::isGUIBehavior()
{
    return this->m_isGUIBehavior;
}

/************************************************************************
*   Function             :  DbiConnection::getSubscriptionModuleEn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201223
*
*   Last Modification    :
*
*************************************************************************/
SubscriptionModuleEn DbiConnection::getSubscriptionModuleEn()
{
    return  ((SYS_IsGuiMode() == TRUE || this->isGUIBehavior()) ? SubscriptionModuleEn::Gui :
        (SYS_IsSrvMode() == TRUE) ? SubscriptionModuleEn::Server :
             (SYS_IsBatchMode() == TRUE) ? SubscriptionModuleEn::Import : SubscriptionModuleEn::Other);
}


/************************************************************************
*   Function             :  DbiConnection::setDdlGenDbaAccessPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-45413 - LJE - 210616
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::setDdlGenDbaAccessPtr(DdlGenDbaAccess *ddlGenDbaAccessPtr)
{
    this->m_ddlGenDbaAccessPtr = ddlGenDbaAccessPtr;
    this->m_ddlGenDbaAccessPtr->getDdlGenContext().setExtDbiConn(this);
}


/************************************************************************
*   Function             :  DbiConnection::getDdlGenDbaAccessPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-45413 - LJE - 210616
*
*   Last Modification    :
*
*************************************************************************/
DdlGenDbaAccess *DbiConnection::getDdlGenDbaAccessPtr()
{
    return this->m_ddlGenDbaAccessPtr;
}

void DbiConnection::setConnectionStatus(bool status)
{
    this->setConnected(status);
    this->setValidConnection(status);
    if (status)
    {
        SYS_ResetRetryDelayWaitTimers();
    }
}

/************************************************************************
*   Function             : getDatatypeFromDesc()





*   Functions call       :
*
*   Return               :
*
*   Last Modification    :
*************************************************************************/
DATATYPE_ENUM DbiConnection::getDatatypeFromDesc(CTYPE_ENUM cType, int& dataSize, int precision, int scale)
{
    DATATYPE_ENUM dataType, defaultDataType = NullDataType;
    std::string nativType;
    int defaultDataSize = 0;

    switch (cType)
    {
        case DoubleCType:
            nativType = "numeric";
            defaultDataType = NumberType;
            break;
        case CharPtrCType:
            nativType = "varchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UIntCType:
        case IntCType:
            nativType = "int";
            defaultDataType = IntType;
            break;
        case ShortCType:
        case UShortCType:
            nativType = "smallint";
            defaultDataType = SmallintType;
            break;
        case UCharCType:
            nativType = "tinyint";
            defaultDataType = FlagType;
            break;
        case DateTimeStCType:
            defaultDataType = DatetimeType;
            break;
        case TextPtrCType:
            nativType = "text";
            defaultDataType = TextType;
            defaultDataSize = MAX_USHORT;
            break;
        case UniCharPtrCType:
            nativType = "univarchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UniTextPtrCType:
            nativType = "unitext";
            defaultDataType = UniTextType;
            defaultDataSize = MAX_USHORT;
            break;
        case LongLongCType:
            nativType = "numeric";
            defaultDataType = IdType;
            break;
        case TimeStampCType:
            nativType = "timestamp";
            defaultDataType = TimeStampType;
            break;
        case BinaryCType:
            nativType = "binary";
            defaultDataType = BinaryType;
            break;

        case VarTextPtrCType:
        case VarCharPtrCType:
        case PtrCType:
        case ExtPtrCType:
        case ArrayPtrCType:
        case MultiArrayPtrCType:
            nativType = "unknown";
            break;
    }

    dataType = DBA_GetDataTypeFromEquivType(this->getDbaRDBMS(), nativType, precision, scale);

    if (dataType == NullDataType)
    {
        dataType = defaultDataType;
        if (defaultDataSize)
        {
            dataSize = defaultDataSize;
        }
    }
    return dataType;
}

void DbiConnection::pushSqlRequest(KindOfRequest kindOfRequest)
{
    this->m_sqlRequestVector.push_back(DbiSqlRequest(kindOfRequest));

    this->m_bCurrentRequestOutputBinded = false;
}

void DbiConnection::popSqlRequest(KindOfRequest kindOfRequest)
{
    if (this->m_sqlRequestVector.size() > 0)
    {
        this->clearRequestBindDataVector();
        this->clearRequestOutputVector();
        this->clearRequestParamMap();

        this->m_sqlRequestVector.pop_back();
    }

    if (kindOfRequest != KindOfRequest::Default)
    {
        this->pushSqlRequest(kindOfRequest);
    }
    else if (this->m_sqlRequestVector.empty())
    {
        this->pushSqlRequest(KindOfRequest::Init);
    }
}

DbiSqlRequest &DbiConnection::getSqlRequest()
{
    return this->m_sqlRequestVector.back();
}

void DbiConnection::initMessageBehavior()
{
    this->m_messageVector.clear();
    this->m_actionVector.clear();
}

std::vector<std::string> &DbiConnection::getMessageVector()
{
    return this->m_messageVector;
}

std::vector<std::string>& DbiConnection::getActionVector()
{
    return this->m_actionVector;
}

std::string DbiConnection::getNextAction()
{
    if (this->m_actionVector.empty())
    {
        return std::string();
    }
    std::string sqlCmd = *this->m_actionVector.begin();

    this->m_actionVector.erase(this->m_actionVector.begin());

    return sqlCmd;
}

DbiOutboxManager& DbiConnection::getOutboxManager()
{
    if (this->m_outboxManagerPtr == nullptr)
    {
        this->m_outboxManagerPtr = new DbiOutboxManager(*this);
    }

    return *this->m_outboxManagerPtr;
}

void DbiConnection::addMessage(const std::string &message)
{
    if (message.find("~SQLCMD~") == 0)
    {
        this->m_actionVector.push_back(message.substr(8));
    }
    else
    {
        this->m_messageVector.push_back(message);
    }
}

void DbiConnection::getPrintAndClearMessages(std::ostream& stream)
{
    for (auto it = this->m_messageVector.begin(); it != this->m_messageVector.end(); ++it)
    {
        stream << (*it) << std::endl;
    }

    this->m_messageVector.clear();
}

void DbiConnection::closeMessageBehavior()
{
    this->initMessageBehavior();
}

std::string &DbiConnection::getRequest()
{
    return this->getSqlRequest().m_requestStr;
}

std::string DbiConnection::getRequestToSend()
{
    std::string convRequest = this->getRequest();

    std::string findWord("?");
    int i = 1;
    {
        std::string::size_type pos = 0;
        while ((pos = DdlGen::find_word(convRequest, findWord, pos)) != std::string::npos)
        {
            if (this->convParamFromPos(convRequest, pos, i, findWord))
            {
                pos++;
            }
            i++;
        }
    }

    auto& requestParamMap = this->getRequestParamMap();
    if (i == 1 && requestParamMap.empty() == false)
    {
        std::map<FIELD_IDX_T, DbiInOutData*> newRequestParamMap;
        int paramNbr = 0;
        for (auto& it : requestParamMap)
        {
            std::string::size_type pos = 0;
            std::string findParam = SYS_Stringer("?", paramNbr);
            while ((pos = DdlGen::find_word(convRequest, findParam, pos)) != std::string::npos)
            {
                if (this->convParamFromPos(convRequest, pos, i, findParam))
                {
                    convRequest.replace(pos, findParam.size(), "?");
                    pos += findParam.size();
                    newRequestParamMap[i - 1] = it.second;
                    i++;
                }
            }
            paramNbr++;

            if (newRequestParamMap.empty())
            {
                i = paramNbr + 1;
            }
        }

        if (newRequestParamMap.empty() == false)
        {
            requestParamMap = newRequestParamMap;
        }
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (requestParamMap.empty() == false)
    {
        if (this->getCurrentAction() == Custom)
        {
            for (auto &it : requestParamMap)
            {
                if (it.second->m_bOutput)
                {
                    this->setCurrentAction(AllStdProcs);
                    break;
                }
            }
        }

        if (static_cast<int>(requestParamMap.size()) + 1 != i)
        {
            std::stringstream msg;
            msg << "Wrong parameters defined in the call (set=" << requestParamMap.size() << ", needed:" << i - 1 << "): " << convRequest;
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                this->getSqlTrace().m_request << convRequest;
            }
        }
        else if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            if (sqlTraceLog.isWarnEnabled() || EV_SqlTraceParam != 0)
            {
                std::string sqlTraceRequest(this->getRequest());
                i = 1;
                std::string::size_type pos = 0;
                auto paramIt = requestParamMap.begin();

                while ((pos = DdlGen::find_word(sqlTraceRequest, findWord, pos)) != std::string::npos &&
                       paramIt != requestParamMap.end())
                {
                    if (paramIt->second->m_sqlTraceHide == false)
                    {
                        std::stringstream valueStream;
                        DBI_FldToDbDataStr(valueStream,
                                           paramIt->second->getDynFldStp(),
                                           0,
                                           paramIt->second->m_dataType,
                                           this->getCurrentAction() == Special ? false : true,   /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                                           this->getDbaRDBMS());

                        sqlTraceRequest.replace(pos, 1, valueStream.str());
                        pos += valueStream.str().length();
                    }

                    i++;
                    paramIt++;
                }
                this->getSqlTrace().m_request << sqlTraceRequest;
            }
            else
            {
                this->getSqlTrace().m_request << convRequest;
            }
        }

        if (this->getCurrentAction() == Special)
        {
            i = 1;
            std::string::size_type pos = 0;

            auto paramIt = requestParamMap.begin();
            while ((pos = DdlGen::find_word(convRequest, findWord, pos)) != std::string::npos &&
                   paramIt != requestParamMap.end())
            {
                std::stringstream valueStream;
                DBI_FldToDbDataStr(valueStream, paramIt->second->getDynFldStp(), 0, paramIt->second->m_dataType, false, this->getDbaRDBMS());
                convRequest.replace(pos, 1, valueStream.str());
                pos += valueStream.str().length();

                i++;
                paramIt++;
            }

            requestParamMap.clear();
        }
    }
    else
    {
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            if (this->m_sqlTraceHideEnd.empty() == false)
            {
                auto hidePos = this->getRequest().find(this->m_sqlTraceHideEnd);
                if (hidePos != std::string::npos)
                {
                    this->getSqlTrace().m_request << this->getRequest().substr(0, hidePos + this->m_sqlTraceHideEnd.length()) << "xxxxxxxxx";
                }
                else
                {
                    this->getSqlTrace().m_request << this->getRequest();
                }
            }
            else
            {
                this->getSqlTrace().m_request << this->getRequest();
            }
        }
    }

    return convRequest;
}

std::map<FIELD_IDX_T, DbiInOutData*>& DbiConnection::getRequestParamMap()
{
    return this->getSqlRequest().m_requestParamMap;
}

void DbiConnection::clearRequestParamMap()
{
    this->getRequestParamMap().clear();

    this->clearColInfoVector();
}

std::vector<DbiColInfo>& DbiConnection::getColInfoVector()
{
    return this->getSqlRequest().m_colInfoVector;
}

void DbiConnection::clearColInfoVector()
{
    this->getColInfoVector().clear();
}

std::vector<DbiInOutData*>& DbiConnection::getRequestOutputVector()
{
    auto &sqlRequest = this->getSqlRequest();
    if (sqlRequest.m_requestOutputVector.size() <= sqlRequest.m_currResultSet)
    {
        sqlRequest.m_requestOutputVector.resize(sqlRequest.m_currResultSet + 1);
    }

    return sqlRequest.m_requestOutputVector[sqlRequest.m_currResultSet];
}

void DbiConnection::clearRequestOutputVector()
{
    this->getSqlRequest().m_requestOutputVector.clear();
    this->m_bCurrentRequestOutputBinded = false;
}

std::vector<DbiBindData>& DbiConnection::getRequestBindDataVector()
{
    return this->getSqlRequest().m_requestBindDataVector;
}

void DbiConnection::clearRequestBindDataVector()
{
    this->getSqlRequest().m_requestBindDataVector.clear();
}

DdlGenFromFile *DbiConnection::getScriptDdlGenPtr()
{
    if (this->m_ddlGenContextPtr == nullptr)
    {
        this->m_ddlGenContextPtr = new DdlGenContext(this->m_connectToRDBMS, true);   /* PMSTA-34344 - TEB - 190805 */
    }
    if (this->m_scriptDdlGenPtr == nullptr)
    {
        this->m_scriptDdlGenPtr = new DdlGenFromFile(*this->m_ddlGenContextPtr);
        this->m_scriptDdlGenPtr->setAvoidSecurity(true);
    }
    return this->m_scriptDdlGenPtr;
}

RET_CODE DbiConnection::bindRequestOutput()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_lastResultType == DBI_ROW_RESULT &&
        this->m_bCurrentRequestOutputBinded == false)
    {
        std::vector<DbiInOutData*> &outputVector = this->getRequestOutputVector();
        if (outputVector.empty() == false)
        {
            int i = 1;
            for (auto outputIt = outputVector.begin(); outputIt != outputVector.end(); ++outputIt)
            {
                if (*outputIt)
                {
                    this->colBind(i++,
                                  (*outputIt)->m_dataType,
                                  (*outputIt)->m_sqlName,
                                  (*outputIt)->m_valuePtr,
                                  (*outputIt)->getAllocSize(),
                                  &(*outputIt)->m_dataLength,
                                  &(*outputIt)->m_nullInd,
                                  false,
                                  nullptr,
                                  (*outputIt));
                }
                else
                {
                    ret = RET_DBA_ERR_SYBBIND;
                }
            }
        }
        this->m_bCurrentRequestOutputBinded = true;
    }
    return ret;
}

RET_CODE DbiConnection::readObjectData(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindSt, int *rowsNbr, DBA_DYNFLD_STP **outputData)
{
    int            cpt, packetSize = 100; /* PMSTA-17973 - CHU - 140416 */
    int			   maxPacketSize = 100000; /* limit reallocation to this max at a time, when max # of records reached */ /* PMSTA-17973 - CHU - 140422 */
    DBA_DYNFLD_STP *resultData = NULL, *oldResultPtr;
    RET_CODE    retCode;

    cpt = 0;

    /* PMSTA-17973 - CHU - 140416 : increase packetSize considering number of records */
    /* packetSize = 100; */

    /* REF7264 - PMO */
    if ((resultData = (DBA_DYNFLD_STP *)CALLOC(packetSize, sizeof(DBA_DYNFLD_STP))) == NULL) /* REF7264 - PMO */
    {
        return(RET_MEM_ERR_ALLOC);
    }

    FIELD_IDX_T portPosSetIdField = Null_Dynfld;

    /* DVP480 - 970522 - PEC - Special case for ExtPos */
    if (dynStType == ExtPos || dynStType == A_PtfSynth || dynStType == S_PtfSynth || dynStType == ExtOp)
    {
        /* REF8844 - LJE - 030416 */
        if (dynStType == ExtPos)
        {
            portPosSetIdField = ExtPos_PtfPosSetId;
        }
        else if (dynStType == A_PtfSynth)
        {
            portPosSetIdField = A_PtfSynth_PtfPosSetId;
        }
        else if (dynStType == S_PtfSynth)
        {
            portPosSetIdField = S_PtfSynth_PtfPosSetId;
        }
        else if (dynStType == ExtOp)
        {
            portPosSetIdField = ExtOp_PortPosSetId;
        }
    }

    /* Loop on each record */
    while ((retCode = this->fetch()) == RET_SUCCEED)
    {
        if ((resultData[cpt] = ALLOC_DYNST(dynStType)) == NULL)
        {
            for (int i = 0; i<cpt; i++)
                FREE_DYNST(resultData[i], dynStType);
            FREE(resultData);
            return(RET_MEM_ERR_ALLOC);
        }

        DBI_CopyNullFlagsAndLengthDynSt(*this, bindSt, dynStType);

        /* DVP480 - 970522 - PEC */
        if (portPosSetIdField != Null_Dynfld &&                     /* PMSTA-37366 - LJE - 190807 */
            IS_NULLFLD(bindSt, portPosSetIdField) == FALSE &&
            GET_ID(bindSt, portPosSetIdField) == 0)
        {
            SET_NULL_ID(bindSt, portPosSetIdField);
        }
        /* DVP480 - 970522 - PEC */

        /* PMSTA-16443 - 230713 - PMO */
        if (FALSE == COPY_DYNST(resultData[cpt], bindSt, dynStType))
        {
            for (int i = 0; i < cpt; i++)
                FREE_DYNST(resultData[i], dynStType);
            FREE(resultData);
            return(RET_MEM_ERR_ALLOC);
        }

        if (this->getCurrCharsetEn() != this->getDbCommCharsetEn())
        {
            MemoryPool mp;
            int      colNumber = GET_FLD_NBR(dynStType);
            int      currUCharSize = 0;
            UChar* currUChar = nullptr;
            char* currChar = nullptr;

            for (int i = 0; i < colNumber; i++)
            {
                if (IS_STRINGFLD(dynStType, i) == TRUE)
                {
                    char* value = GET_STRING(resultData[cpt], i);

                    if (ICU4AAA_GetCharSet(value) != CurrentCharsetCode_Ascii_7)
                    {
                        int cursorLen = (int)strlen(value) + 1, uCharLen = 0, isoLen = 0;

                        if (cursorLen > currUCharSize)
                        {
                            currUChar = static_cast<UChar*>(mp.realloc(currUChar, cursorLen * sizeof(UChar)));
                            currChar = static_cast<char*>(mp.realloc(currChar, cursorLen * sizeof(char)));
                            currUCharSize = cursorLen;
                        }

                        ICU4AAA_ConvertFromDefaultCharSet(value, cursorLen, currUChar, cursorLen, &uCharLen, this->getDbCommCharsetEn());
                        ICU4AAA_ConvertToDefaultCharSet(currUChar, uCharLen, &currChar, &isoLen, this->getCurrCharsetEn());

                        _SET_STRING(resultData[cpt], i, currChar);
                    }
                }
            }
        }

        ++cpt;

        if (cpt % packetSize == 0)
        {
            /* PMSTA-17973 - CHU - 140422 */
            if (packetSize < maxPacketSize)
                packetSize *= 10;

            oldResultPtr = resultData;
            /* REF7264 - PMO */
            resultData = (DBA_DYNFLD_STP *)REALLOC(resultData,
                                                    (cpt + packetSize)*sizeof(DBA_DYNFLD_STP));

            /* If allocation failed */
            if (resultData == NULL)
            {
                for (int i = 0; i<cpt; i++)
                    FREE_DYNST(oldResultPtr[i], dynStType);
                FREE(oldResultPtr);
                return(RET_MEM_ERR_ALLOC);
            }

            memset((void *)(resultData + cpt), 0, packetSize);
        }
    }

    if (retCode != RET_DBA_INFO_NO_MORE_DATA) /* REF3955 - SSO - 991216 */
    {
        if (resultData != NULL)
        {
            for (int i = 0; i<cpt; i++)
                FREE_DYNST(resultData[i], dynStType);
            FREE(resultData);
        }
        return(RET_DBA_ERR_DBPROBLEM);
    }

    /* Memory leak - ROI - 000423 - REF???? */
    if (cpt == 0)
        FREE(resultData);

    /* Memorize the number of retrieved rows in the result set */
    if (rowsNbr != NULL)
        *rowsNbr = cpt;

    if (outputData != NULL)
        *outputData = resultData;

    return(RET_SUCCEED);
}


/************************************************************************
*   Function             :  DbiConnection::setModifStat
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-28916 - LJE - 171218
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::setModifStat(int modifStat)
{
    if (this->getTargetSessionProperties().getModifStat() != modifStat)
    {
        this->getTargetSessionProperties().setModifStat(modifStat);
        this->applyPropertiesOnConnection();
    }
}


/************************************************************************
*   Function             :  DbiConnection::getSqlTrace
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190910
*
*   Last Modification    :
*
*************************************************************************/
DbiSqlTrace &DbiConnection::getSqlTrace()
{
    return this->getSqlRequest().m_sqlTrace;
}

/************************************************************************
*   Function             :  DbiConnection::sendSqlTrace
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190910
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnection::sendSqlTrace()
{
    auto &sqlTrace = this->getSqlTrace();
    sqlTrace.sendSqlTrace(this->getConnSessionProperties().getDbName(), this->getId(), &(this->m_msgStack), this->m_sqlRequestVector.size() - 1);
}

/************************************************************************
*   Function             :  DbiSqlTrace::sendSqlTrace
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - DDV - 200109
*
*   Last Modification    :
*
*************************************************************************/
void DbiSqlTrace::sendSqlTrace(std::string dbName, int connectNo, DbaMsgStackClass *msgStack, size_t requestLevel)
{
    if (this->m_command.empty() == false || this->m_procedure.empty() == false)
    {
        /* Timer for format elements are already stopped */
        if (this->m_logLevel != AAALogger::Level::Debug)
        {
            if (this->m_mode != DbiSqlTrace::Mode::FmtElt) 
            {
                DATE_StopTimer(&this->m_timer, TIMER_MASK_GEN);
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }

        if (EV_sqlFile != nullptr)
        {
            fprintf(EV_sqlFile, "%s() - %s - Connect=%d - Request=\"%s\"...", this->m_command.c_str(), (RET_GET_LEVEL(this->m_retCode) == RET_LEV_ERROR ? "Failed" : "Succeed"), connectNo, this->m_request.str().c_str());
            fprintf(EV_sqlFile, "%d.%06d\n",
                    (int)this->m_timer.cumul.tv_sec,
                    (int)this->m_timer.cumul.tv_usec);

            /* Update file */
            fflush(EV_sqlFile);
        }

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        const AAALogger& sqlTraceFmtLog = AAALogger::get(AAALogger::Logger::SqlTraceFmt);

        std::string _sqlFmtRowNbr;
        std::string _sqlFmtColNbr;
        INT64_T _duration_ms = 0;

        if (sqlTraceLog.isErrorEnabled() || sqlTraceFmtLog.isErrorEnabled())
        {
            AAALogger::putMDC(AAALogger::MDC_keys::SqlCommand, this->m_command);

            if (sqlTraceLog.isTraceEnabled())
            {
                AAALogger::putMDC(AAALogger::MDC_keys::CallStack, SYS_GetCallStack());
            }
            else
            {
                AAALogger::putMDC(AAALogger::MDC_keys::CallStack, "");
            }


            {
                std::ostringstream oss;
                oss << requestLevel;
                AAALogger::putMDC(AAALogger::MDC_keys::SqlRequestLevel, oss.str());
            }

            switch(this->m_mode)
            {
                case DbiSqlTrace::Mode::Rpc:
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlMode, "RPC");
                    break;
                case DbiSqlTrace::Mode::Lang:
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlMode, "LANG");
                    break;
                case DbiSqlTrace::Mode::FmtElt:
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlMode, "FMTELT");
                    break;
                case DbiSqlTrace::Mode::Connection:
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlMode, "CONN");
                    break;
                default:
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlMode, "UNDEFINED");
                    break;
            }

            {
                std::ostringstream oss;

                AAALogger::putMDC(AAALogger::MDC_keys::SqlDbMsgStrings, "");

                if (RET_GET_LEVEL(this->m_retCode) == RET_LEV_ERROR)
                {
                    oss << "Failed";
                    if (msgStack != nullptr && msgStack->size() > 0)
                    {
                        std::ostringstream ossMsgStrings;

                        oss << ":";
                        for (int i = 0; i < msgStack->size(); i++)
                        {
                            if (i > 0)
                            {
                                oss << " / ";
                                ossMsgStrings << " / ";
                            }

                            oss << msgStack->getMember(i).rdbmsMsgNb;
                            ossMsgStrings << msgStack->getMember(i).msgString;
                        }

                        AAALogger::putMDC(AAALogger::MDC_keys::SqlDbMsgStrings, ossMsgStrings.str());
                    }
                }
                else
                {
                    oss << "Succeed";
                }

                AAALogger::putMDC(AAALogger::MDC_keys::SqlStatus, oss.str());
            }

            if (dbName.empty() == false)
            {
                AAALogger::putMDC(AAALogger::MDC_keys::SqlDatabase, dbName);
            }
            else
            {
                AAALogger::putMDC(AAALogger::MDC_keys::SqlDatabase, "");
            }


            AAALogger::putMDC(AAALogger::MDC_keys::Procedure, this->m_procedure);

            if (sqlTraceFmtLog.isDebugEnabled())
            {
                if (this->m_fmtEltInfo.empty())
                {
                    char		fmtEltInfo[256] = "";
                    if (DBA_GetFmtEltInfo(fmtEltInfo))
                    {
                        this->m_fmtEltInfo = fmtEltInfo;
                    }
                }

                AAALogger::putMDC(AAALogger::MDC_keys::SqlFmtEltInfo, this->m_fmtEltInfo);
                

                if (this->m_fmtRowNbr != NO_VALUE)
                {
                    std::ostringstream ossFmtRowNbr;
                    ossFmtRowNbr << this->m_fmtRowNbr;
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlFmtRowNbr, ossFmtRowNbr.str());
                    _sqlFmtRowNbr = ossFmtRowNbr.str();
                }
                else
                {
                    AAALogger::putMDC(AAALogger::MDC_keys::SqlFmtRowNbr, "");
                }
            }
            else
            {
                AAALogger::putMDC(AAALogger::MDC_keys::SqlFmtEltInfo, "");
                AAALogger::putMDC(AAALogger::MDC_keys::SqlFmtRowNbr, "");
            }

            {
                if (this->m_mode == DbiSqlTrace::Mode::FmtElt &&
                    sqlTraceFmtLog.getLogLevel() >= AAALogger::Level::Debug)
                {
                    if ((EV_TimerMask & TIMER_MASK_GEN) == 1)
                    {
                        _duration_ms = this->m_timer.cumul.tv_sec * 1000 + (this->m_timer.cumul.tv_usec / 1000);
                    }
                    else
                    {
                        SYS_BreakOnDebug();
                    }
                }
                else if (sqlTraceLog.isWarnEnabled() &&
                         this->m_logLevel >= AAALogger::Level::Warn &&
                         this->m_startTime_ms > 0)
                {
                    _duration_ms = DATE_currentMilliSecsSinceEpoch() - this->m_startTime_ms;
                }

                std::ostringstream ossMs;
                ossMs << _duration_ms;
                AAALogger::putMDC(AAALogger::MDC_keys::SqlDurationMs, ossMs.str());

                char buff[64];
                sprintf(buff, "%.3f", float(_duration_ms / 1000.0));
                AAALogger::putMDC(AAALogger::MDC_keys::SqlDurationS, buff);
            }

            {
                std::ostringstream oss;
                oss << connectNo;
                AAALogger::putMDC(AAALogger::MDC_keys::SqlConnection, oss.str());
            }
            std::string _request;
            {
                std::ostringstream oss;

                if (this->m_request.str().empty())
                {
                    if (this->m_command.empty())
                    {
                        oss << "{" << this->m_procedure << "}";
                    }
                    else
                    {
                        oss << "{" << this->m_command << "}";
                    }
                }
                else
                {
                    oss << this->m_request.str();
                }
                _request = oss.str();

                if (this->m_logLevel <= sqlTraceFmtLog.getLogLevel() && this->m_fmtEltInfo.empty() == false)
                {
                    sqlTraceFmtLog.log(RET_GET_LEVEL(this->m_retCode) == RET_LEV_ERROR ? AAALogger::Level::Error : this->m_logLevel, oss.str());
                }
                else
                {
                    sqlTraceLog.log(RET_GET_LEVEL(this->m_retCode) == RET_LEV_ERROR ? AAALogger::Level::Error : this->m_logLevel, oss.str());
                }
            }

            if (sqlTraceFmtLog.isDebugEnabled() && this->m_fmtEltInfo.empty() == false)
            {
                auto meter = AAATelemetry::GetMeter(AAAMeter::MeterName::General);
                auto sql_traceformat_histogram = meter->registerHistogramMeter("formatPerformance", "Trace format performance", "ms");
                // wait for https://github.com/open-telemetry/opentelemetry-cpp/pull/3029
                // https://github.com/open-telemetry/opentelemetry-cpp/issues/2279
                // auto sql_traceformat_gauge = meter->registerSynchronousGauge("formatPerformance", "Trace format performance", "ms");


                std::map<std::string, std::string> attributes;
                attributes.emplace(std::make_pair("finfunction", this->m_function));

                if (sqlTraceFmtLog.isTraceEnabled())
                {
                    attributes.emplace(std::make_pair("format.rownb", _sqlFmtRowNbr));
                    attributes["datasetNumber.columnNumber"] = this->m_fmtEltInfo;
                    attributes["formatElementUsage"] = _request;
                }
                sql_traceformat_histogram->Record(_duration_ms, attributes);
            }

        }
    }
    this->clear();
}

/************************************************************************
*   Function             :  DbiConnection::sendCommand
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190910
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnection::sendCommand(const std::string &request, DBA_DYNST_ENUM outputSt)
{
    this->startRequest();

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_command = "command";
        sqlTrace.m_logLevel = AAALogger::Level::Warn;
    }

    if (request.empty() == false)
    {
        std::string sqlResquest(request);
        DBA_DynSqlStrPrep(sqlResquest, this->m_connectToRDBMS);
        this->getRequest() = sqlResquest;
    }

    this->m_lastResultRetCode = this->doSendCommand(outputSt);

    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace     = this->getSqlTrace();
        sqlTrace.m_retCode = this->m_lastResultRetCode;
    }

    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             : DbiConnection::releaseCommand()
*
*   Description :
*
*   Arguments :
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
RET_CODE DbiConnection::releaseCommand()
{
    this->sendSqlTrace();

    this->setCurrentAction(Custom);
    this->setCurrProcedure(nullptr);
    this->clearRequestParamMap();

    this->getSqlRequest().m_isInit = false;
    this->m_batchTableSqlName.clear();

    this->m_resultSetPos = -1;
    this->m_bOnBatchOutput = false;

    if (this->m_ddlGenContextPtr != nullptr &&
        this->m_onApplySessionProperties == false)
    {
        this->m_ddlGenContextPtr->m_inputVariableVector.clear();
    }

    if (this->m_transactCpt == 0)
    {
        this->m_beginTransToDo           = false;
        this->m_isAutoTransaction        = false;
    }

    return this->doReleaseCommand();
}

/************************************************************************
*   Function             : DbiConnection::getCurrCharsetEn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*************************************************************************/
CURRENTCHARSETCODE_ENUM DbiConnection::getCurrCharsetEn()
{
    if (this->m_currCharSetEn == CurrentCharsetCode_IsNull)
    {
        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &this->m_currCharSetEn);
    }
    return this->m_currCharSetEn;
}

/************************************************************************
*   Function             : DbiConnection::setCurrCharsetEn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*************************************************************************/
void DbiConnection::setCurrCharsetEn(CURRENTCHARSETCODE_ENUM currCharSetEn)
{
    this->m_currCharSetEn = currCharSetEn;
}

/************************************************************************
*   Function             : DbiConnection::getDbCommCharsetEn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*************************************************************************/
CURRENTCHARSETCODE_ENUM DbiConnection::getDbCommCharsetEn()
{
    if (this->m_dbCommCharSetEn == CurrentCharsetCode_IsNull)
    {
        GEN_GetApplInfo(ApplDbCommCharsetCodeEnum, &this->m_dbCommCharSetEn);

        if (this->m_dbCommCharSetEn == CurrentCharsetCode_IsNull)
        {
            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &this->m_dbCommCharSetEn);
            GEN_SetApplInfo(ApplDbCommCharsetCodeEnum, &this->m_dbCommCharSetEn);
        }
    }
    return this->m_dbCommCharSetEn;
}

/************************************************************************
*   Function             : DbiConnection::setDbCommCharsetEn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*************************************************************************/
void DbiConnection::setDbCommCharsetEn(CURRENTCHARSETCODE_ENUM dbCommCharSetEn)
{
    this->m_dbCommCharSetEn = dbCommCharSetEn;
}

/************************************************************************
*   Function             : DbiConnection::beginTransaction()
*
*   Description          : Send a "begin tran" command to the server and retrieve
*                          returned status
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE DbiConnection::beginTransaction(bool isTransaction)
{
    if (this->m_transactionInProgress == false)
    {
        this->m_isAutoTransaction = isTransaction;
        this->m_beginTransToDo = true;
        this->m_activitiesSinceLastCommit = 0;
    }
    else
    {
        SYS_BreakOnDebug();
    }

    this->incTransaction();
    return RET_SUCCEED;
}


/************************************************************************
*   Function             : DbiConnection::endTransaction()
*
*   Description          : Send a "commit tran" or "rollback tran" command to
*                          the server according to the given status.
*
*   WARNING              : if status is different from TRUE or FALSE or if given
*                          connection number is invalid, no command
*                          is sent to the server to close the transaction and the
*                          tables concerned by the transaction stays locked.
*
*   Arguments            : status       : TRUE or FALSE
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input argument problem
*
*************************************************************************/
RET_CODE DbiConnection::endTransaction(const FLAG_T status)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_outboxManagerPtr != nullptr)
    {
        this->m_outboxManagerPtr->flush(true);
    }

    if ((this->m_transactionInProgress ||
         (this->m_transactCpt && this->m_activitiesSinceLastCommit > 0 && this->isAutoCommit() == false)) &&
         this->isValid())
    {
        if (this->m_transactCpt <= 1 || status == FALSE)
        {
            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

            if (EV_sqlFile != NULL || sqlTraceLog.isInfoEnabled())
            {
                this->sendSqlTrace();
            }

            this->pushSqlRequest(KindOfRequest::Internal);

            if (EV_sqlFile != NULL || sqlTraceLog.isInfoEnabled())
            {
                auto& sqlTrace       = this->getSqlTrace();
                sqlTrace.m_command   = "end_transaction";
                sqlTrace.m_procedure = sqlTrace.m_command;
                sqlTrace.m_mode      = DbiSqlTrace::Mode::Lang;
                sqlTrace.m_logLevel  = AAALogger::Level::Info;
            }

            ret = this->doEndTransaction(status);

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR || this->isValid() == false)
            {
                this->m_transactionInProgress = false;
                this->m_activitiesSinceLastCommit = 0;
                this->m_isAutoTransaction = false;

                this->m_transactCpt = 0;
            }

            if (EV_sqlFile != NULL || sqlTraceLog.isInfoEnabled())
            {
                auto& sqlTrace = this->getSqlTrace();

                switch (status)
                {
                    case FALSE:
                        sqlTrace.m_command = "rollback";
                        break;
                    case TRUE:
                        sqlTrace.m_command = "commit";
                        break;
                }
                sqlTrace.m_procedure = sqlTrace.m_command;
                sqlTrace.m_retCode   = ret;

                this->sendSqlTrace();
            }

            this->popSqlRequest();
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    else
    {
        this->m_beginTransToDo            = false;
        this->m_transactionInProgress     = false;
        this->m_activitiesSinceLastCommit = 0;

        if (this->isValid())
        {
            this->decTransaction(status);
        }
        else
        {
            this->m_transactCpt = 0;
        }
    }

    this->closeMessageBehavior();

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
        RET_GET_LEVEL(this->m_lastResultRetCode) != RET_LEV_ERROR)
    {
        this->m_lastResultRetCode = ret;
    }

    return ret;
}

bool DbiConnection::useDb(const std::string& database)
{
    bool ret = false;
    if (database.empty())
    {
        std::string defaultDatabase;
        GEN_GetApplInfo(ApplSqlDbName, defaultDatabase);
        if (defaultDatabase.empty() == false)
        {
            ret = RET_SUCCEED == this->useDb(defaultDatabase);
        }
    }
    else if (database == this->getActualDbName() ||
             this->getDescription().getType() != AAAConnectionType::SqlServer ||
             EV_AAAInstallLevel == 20)
    {
        ret = true;
    }
    else
    {
        std::string line = DdlGenDbi::getCmdUseDb(database, this->m_connectToRDBMS);

        if (line.empty() == false)
        {
            RequestHelper requestHelper(this, true);
            requestHelper.setReadOnly(true);
            requestHelper.setExternalMsgManagement(EV_AAAInstallLevel > 9); /* PMSTA-37366 - LJE - 191220 - Hide the use database on bootstrap */

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto& sqlTrace = this->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.UseDb " + database;
            }

            if (RET_GET_LEVEL(this->sqlExecSt(line.c_str())) != RET_LEV_ERROR)
            {
                this->getConnSessionPropertiesForUpd().setDbName(database);
                ret = true;
            }
            else if (requestHelper.isExternalMsgManagement())
            {
                requestHelper.printMsg();
                this->m_msgStructHeaderSt.clear();
                ret = true;
            }
        }
    }
    return(ret);
}


/************************************************************************
*   Function             : DbiConnection::sqlExecSt()
*
*   Description          : Send a character std::string representing a SQL Dynamic
*                          request. Bind status
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*                          status          : pointer on status to be binded
*                          msgStructPtr    : pointer to the message structure
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Last Modification    :
*************************************************************************/
RET_CODE DbiConnection::sqlExecSt(const char *sqlBuff, DBI_INT *status, bool bKeepCommand)
{
    RET_CODE            retCode = RET_SUCCEED;
    signed char         transLevel = this->m_transactCpt;

    DBA_ACTION_ENUM savedAction = this->getCurrentAction();

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    this->initRequest(Custom, false);

    retCode = this->sendCommand(sqlBuff);

    if (retCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        retCode = RET_SUCCEED;
    }

    if (status)
    {
        *status = 0;
    }

    if (!bKeepCommand || retCode != RET_SUCCEED)
    {
        this->releaseCommand();
    }

    this->setCurrentAction(savedAction);

    if (this->m_transactCpt > transLevel)
    {
        this->endTransaction(TRUE);
    }

    return retCode;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::DbiConnectionHelper()
*
*   Description          :  Constructor
*
*   Arguments            :  useTran
*                           server
*                           role
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnectionHelper::DbiConnectionHelper(AAATransactionEnum useTran, const DBA_SERVER_TYPE_ENUM server, const AAAConnectionRole role)
    : m_dbiConn(nullptr)                                                /* DLA - PMSTA-29886 - 180126 */
    , m_usetran(useTran == AAATransactionEnum::Transactionnal)          /* DLA - PMSTA-29886 - 180126 */
    , m_uselocaltran(false)
    , m_releaseConnection(true)
    , m_options(UNUSED)
    , m_maxRows(0)
    , m_connNotFound(DBA_CONN_NOT_FOUND)
    , m_desc(server, std::string(), role)
    , m_connectionKind(AAAConnectionKind::StandardConnection)
    , m_bSilentMode(false)
    , m_notifyReopen(false)
    , m_notifyRetry(0)
    , m_previousExternalMsgManagement(false)
    , m_isGUIBehavior(false)
    , m_currProcedureStp(nullptr)                /* PMSTA-45413 - LJE - 210804 */
    , m_fromDbaAccess(false)
{
}

/************************************************************************
*   Function             :  DbiConnectionHelper::DbiConnectionHelper()
*
*   Description          :  Constructor
*
*   Arguments            :  server
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
DbiConnectionHelper::DbiConnectionHelper(const DBA_SERVER_TYPE_ENUM & server)
    : DbiConnectionHelper(AAATransactionEnum::NotTransactionnal, server)  /* DLA - PMSTA-29886 - 180126 */
{
}

/************************************************************************
*   Function             :  DbiConnectionHelper::DbiConnectionHelper()
*
*   Description          :  Constructor
*
*   Arguments            :  serverName
*                           role
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*************************************************************************/
DbiConnectionHelper::DbiConnectionHelper(const std::string & serverName, const AAAConnectionKind& connectionKind)
    : m_dbiConn(nullptr)
    , m_usetran(false)
    , m_uselocaltran(false)
    , m_releaseConnection(true)
    , m_options(UNUSED)
    , m_maxRows(0)
    , m_connNotFound(DBA_CONN_NOT_FOUND)
    , m_desc(DBA_SERVER_TYPE_ENUM::FinServer, serverName, ROLE_USER)
    , m_connectionKind(connectionKind)
    , m_bSilentMode(false)
    , m_notifyReopen(false)
    , m_notifyRetry(0)
    , m_previousExternalMsgManagement(false)
    , m_isGUIBehavior(false)
    , m_currProcedureStp(nullptr)                /* PMSTA-45413 - LJE - 210804 */
    , m_fromDbaAccess(false)
{
}

/************************************************************************
*   Function             :  DbiConnectionHelper::DbiConnectionHelper()
*
*   Description          :  Constructor of class DbiConnectionHelper with assignation of an existent connection object
*
*   Arguments            :  dbiConnection dbiConn : the connection to assign
*                           bool          releaseConnectionOnDeleteObject : if true the connection assigned is released at destruction
*
*   Return               :  None
*
*   Last modif.          : PMSTA-24963 - 051016 - PMO : Fusion not running after installing TA 21.0.01
*
*************************************************************************/
DbiConnectionHelper::DbiConnectionHelper(DbiConnection* dbiConn, bool releaseConnectionOnDeleteObject)
    : m_dbiConn(dbiConn)
    , m_usetran(false)                                                /* PMSTA-24963 - 051016 - PMO */
    , m_uselocaltran(false)
    , m_releaseConnection(releaseConnectionOnDeleteObject)
    , m_options(UNUSED)
    , m_maxRows(0)
    , m_connNotFound(DBA_CONN_NOT_FOUND)
    , m_desc(
        dbiConn ? dbiConn->getSpecification().getType() : DBA_SERVER_TYPE_ENUM::SqlServer,
        dbiConn ? dbiConn->getSpecification().getServerName() : std::string(),
        dbiConn ? dbiConn->getSpecification().getRole() : ROLE_USER)
    , m_connectionKind(AAAConnectionKind::StandardConnection)
    , m_bSilentMode(false)
    , m_notifyReopen(false)
    , m_notifyRetry(0)
    , m_previousExternalMsgManagement(false)
    , m_isGUIBehavior(false)
    , m_currProcedureStp(nullptr)                /* PMSTA-45413 - LJE - 210804 */
    , m_fromDbaAccess(false)
{
    /* PMSTA-24963 - 051016 - PMO */
    if (nullptr != this->m_dbiConn)
    {
        this->m_usetran                       = this->m_dbiConn->isInTransaction() && releaseConnectionOnDeleteObject;
        this->m_previousExternalMsgManagement = this->m_dbiConn->isExternalMsgManagement();
    }
    else
    {
        this->m_releaseConnection = true;
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::DbiConnectionHelper()
*
*   Description          :  Constructor of class DbiConnectionHelper with assignation of an existent connection object
*
*   Arguments            :
*
*   Return               :  None
*
*   Last modif.          : PMSTA-37366 - LJE - 190607
*
*************************************************************************/
DbiConnectionHelper::DbiConnectionHelper(int *connectNoPtr)
    : DbiConnectionHelper()
{
    if ((connectNoPtr != nullptr) && (*connectNoPtr != NO_VALUE))
    {
        this->m_releaseConnection = false;
        this->m_dbiConn = DBA_GetDbiConnFromConnectNo(*connectNoPtr);
    }
    else
    {
        this->m_releaseConnection = true;
        this->isValidAndInit();
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::~DbiConnectionHelper()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnectionHelper::~DbiConnectionHelper()
{
    this->endConnection();        /* PMSTA-19735 - 020415 - PMO */

    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->setExternalMsgManagement(this->m_previousExternalMsgManagement);
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setDbiConnection()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*                           PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*************************************************************************/
void DbiConnectionHelper::setDbiConnection()
{
    if (DBA_SERVER_TYPE_ENUM::FinServer == this->m_desc.getType() ||
        DBA_SERVER_TYPE_ENUM::DispatchServer == this->m_desc.getType())
    { /* Financial server */

        /* PMSTA-37366 - LJE - 190723 */
        this->m_desc.setSilentMode(this->m_bSilentMode);

        if (this->m_desc.getModel() == UnknownRdbms)
        {
            /* PMSTA-24563 - LJE - 160830 */
            AAAConnectionDescription desc(this->m_desc.getType(), this->m_desc.getServerName(), this->m_desc.getRole());
            this->m_desc = desc;
            this->m_desc.setSilentMode(this->m_bSilentMode);

            /* PMSTA-37366 - LJE - 190723 */
            if (this->m_desc.getSilentMode() == true)
            {
                return;
            }
        }

        this->m_dbiConn = DBA_GetDbiSrvConnection(this->m_desc, this->m_connectionKind);          /* PMSTA-26427 - 240217 - PMO */
        if (this->m_dbiConn != nullptr &&
            this->m_dbiConn->isValid() == false)
        {
            this->m_dbiConn->reconnect();
        }
    }
    else
    { /* Database server */
        this->m_dbiConn = DBA_GetDbiConnection(this->m_desc);

        if (this->m_dbiConn != nullptr)
        {
            if (this->m_dbiConn->isValid() == false)
            {
                this->m_dbiConn->reconnect();
            }

            if (this->m_usetran)
            {
                if (RET_GET_LEVEL(this->m_dbiConn->beginTransaction()) == RET_LEV_ERROR)
                {
                    this->rollback();
                }
            }
        }
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setOnError()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-37366 - LJE - 200701
*
*************************************************************************/
void DbiConnectionHelper::setOnError(bool isInError)
{
    if (this->m_dbiConn != nullptr && isInError)
    {
        this->m_dbiConn->setValidConnection(false);
 	    this->m_dbiConn->clean();
    }
}


/************************************************************************
*   Function             :  DbiConnectionHelper::setCurrBusinessEntity()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-37366 - LJE - 200701
*
*************************************************************************/
bool DbiConnectionHelper::setCurrBusinessEntity(const std::string &busEntityCd)
{
    if(GEN_IsMultiEntity() && (SYS_GetThreadCurrBusinessEntity() != busEntityCd || isConnBusEntityEqualTo(busEntityCd) == false))
    {
        this->endConnection();
        SYS_SetThreadCurrBusinessEntity(busEntityCd);
    }
    return this->isValidAndInit();
}

/************************************************************************
*   Function             :  DbiConnectionHelper::getConnection()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnection* DbiConnectionHelper::getConnection()
{
    if (this->m_dbiConn == nullptr)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DbiConnectionHelper used without initialization");
        SYS_BreakOnDebug();
    }

    if (this->m_dbiConn == nullptr)
    {
        this->setDbiConnection();
    }

    return this->m_dbiConn;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isValidAndInit()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*************************************************************************/
bool DbiConnectionHelper::isValidAndInit()
{
    if (this->m_dbiConn == nullptr)
    {
        this->setDbiConnection();

        if (this->m_dbiConn != nullptr)
        {
            this->m_dbiConn->setDbName(std::string());
        }
    }
    else
    {
        this->reopenHttpOnThreadChange();

        if (false == this->m_dbiConn->isValid())
        {
            if (this->m_dbiConn->reconnect() == false)
            {
                return false;
            }
        }
    }

    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->setGUIBehavior(this->isGUIBehavior());
    }

    return (this->isConnected());
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isConnected()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-37366 - LJE - 200701
*
*************************************************************************/
bool DbiConnectionHelper::isConnected()
{
    return (this->m_dbiConn != nullptr && this->m_dbiConn->isValid());
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isInTransaction()
*
*   Description          :  Return true if a transaction is opened
*
*   Arguments            :  None
*
*   Return               :  true    if a transaction is opened
*                           false   if no transaction is opened or the connection is not established
*
*   Creation Date        :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isInTransaction()
{
    DbiConnection * dbiConn = this->getConnection();

    return nullptr != dbiConn ? dbiConn->isInTransaction() : false;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::beginTransaction()
*
*   Description          :  Open a transaction
*
*   Arguments            :  None
*
*   Return               :  RET_CODE
*                           RET_DBA_ERR_DISCONNECTED  if no connection
*
*   Creation Date        :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::beginTransaction()
{
    DbiConnection * dbiConn = getConnection();

    const RET_CODE ret = nullptr != dbiConn ? dbiConn->beginTransaction() : RET_DBA_ERR_DISCONNECTED;

    this->m_uselocaltran = ret == RET_SUCCEED; /* PMSTA-24563 - LJE - 160908 */

    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::finishConnection()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*                           PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
void DbiConnectionHelper::endConnection()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_uselocaltran && this->m_dbiConn != nullptr && this->m_dbiConn->isInTransaction())
    {
        std::stringstream msg;
        msg << "Connection ended while a transaction is open: "
            << "ConnectNo=" << m_dbiConn->getId(); /* to complete */
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
        this->m_dbiConn->endTransaction(FALSE);
    }

    if (this->m_dbiConn != nullptr)
    {
        if (this->m_releaseConnection == true)
        {
            ret = this->m_dbiConn->endConnection((RET_GET_LEVEL(this->m_dbiConn->m_lastResultRetCode) == RET_LEV_ERROR));
        }
        this->m_dbiConn = nullptr;
    }
}


/************************************************************************
*   Function             :  DbiConnectionHelper::reopen()
*
*   Description          :  Reopen the connection
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*                           PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*                           PMSTA-34425 - 240219 - PMO : Fusion synchronized processing of a group of big portfolios
*
*************************************************************************/
void DbiConnectionHelper::reopen()
{
    /* Avoid to close a connection with a transaction opened PMSTA-34425 - 240219 - PMO */
    if (true == isInTransaction())
    {
        this->rollback();
    }
    if (this->isConnected())
    {
        this->getConnection()->reconnect();
    }
    else
    {
        this->isValidAndInit();
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setSilentMode()
*
*   Description          :  Set the silent connection mode
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        : PMSTA-24563 - LJE - 160907
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::setSilentMode(bool bSilentMode)
{
    this->m_bSilentMode = bSilentMode;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::getSilentMode()
*
*   Description          :  get the silent connection mode
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::getSilentMode()
{
    return this->m_bSilentMode;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isDbaAccess()
*
*   Description          :  Return try if the tool DdlGenDbaAccess is used to optimize the DBA access
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isDbaAccess(DBA_ACTION_ENUM actionEn)
{
    return (this->m_fromDbaAccess == false &&
            this->m_dbiConn != nullptr &&
            this->m_dbiConn->getDdlGenDbaAccessPtr() != nullptr &&
            (actionEn == Get ||
             actionEn == Select ||
             this->m_dbiConn->getDdlGenDbaAccessPtr()->getDdlGenContext().ddlGenAction.m_fromImport));
}

/************************************************************************
*   Function             :  DbiConnectionHelper::getDdlGenDbaAccessPtr()
*
*   Description          :  Return a DdlGenDbaAccessPtr if used
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
DdlGenDbaAccess *DbiConnectionHelper::getDdlGenDbaAccessPtr(DBA_ACTION_ENUM actionEn)
{
    return (this->isDbaAccess(actionEn) ? this->m_dbiConn->getDdlGenDbaAccessPtr() : nullptr);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::reopenHttpOnThreadChange()
*
*   Description          :  Reopen the HTTP connection in case the thread ID has changed.
*                           This seems a limitation of how QT is managing HTTP connection (signal/slot/event processing).
*
*                           Used to avoid QT message when recycling a HTTP connection:
*                           2016-08-24-15:37:41.211 1 WARNING 16272 QObject::setParent: Cannot set parent, new parent is in a different thread
*
*   Arguments            :  None
*
*   Return               :  true    Connection was reopened
*                           false   Nothing was done
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*                           PMSTA-25009 - 131016 - PMO : Regression: Core file generated while running the 20_Env_Sync_Quality_Checks/JDE_CHK_130_LARGE_TEST TaAutomator test case
*                           PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*************************************************************************/
bool DbiConnectionHelper::reopenHttpOnThreadChange()
{
    bool ret = false;

    if (nullptr != this->m_dbiConn)
    {
        if (this->m_dbiConn->reopenOnThreadChange())
        {
            this->isValidAndInit();
            ret = true;
        }
    }

    return ret;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::reopenHttpOnThreadChangeForOnlineBatch()
*
*   Description          :  Reopen the HTTP connection in case the thread ID has changed.
*                           This seems a limitation of how QT is managing HTTP connection (signal/slot/event processing).
*                           special case for Online interface Only !!!
*
*
*   Arguments            :  None
*
*   Return               :  true    Connection was reopened
*                           false   Nothing was done
*
*   Creation Date        : DLA - PMSTA-29743 - 180214
*
*
*************************************************************************/
bool DbiConnectionHelper::reopenHttpOnThreadChangeForOnlineBatch()
{
    bool ret = false;

    if (nullptr != this->m_dbiConn && QtHttp == this->m_dbiConn->m_connectToRDBMS)                                /* PMSTA-25009 - 131016 - PMO */
    {
        HttpClient * httpClient = static_cast<HttpClient *>(this->m_dbiConn->getConnectionPtr());
        TID_T theadOsId = SYS_GetOsThreadId();                                                                      /* DLA - PMSTA-30238 - 180216 */
        if (nullptr != httpClient && httpClient->getThreadId() != theadOsId)
        {
            this->reopen();
            httpClient = static_cast<HttpClient *>(this->m_dbiConn->getConnectionPtr());           /* PMSTA-26427 - 240217 - PMO */
            httpClient->setThreadId(theadOsId);                                                       /* PMSTA-26427 - 240217 - PMO */
            this->isValidAndInit();
            ret = true;
        }
    }

    return ret;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::setConnectionKind()
*
*   Description          :  For the dispatcher and his connection to fusion server
*
*   Arguments            :  Connection kind
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::setConnectionKind(const AAAConnectionKind & connectionKind)
{
    this->m_connectionKind = connectionKind;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::endTransaction()
*
*   Description          :  Commit or Rollback
*
*   Arguments            :  commitFlag  Commit?
*
*   Return               :  RET_CODE
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::endTransaction(const FLAG_T commitFlag)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_dbiConn != nullptr && this->m_dbiConn->isInTransaction())
    {
        ret = this->m_dbiConn->endTransaction(commitFlag);
    }

    this->m_uselocaltran = ret != RET_SUCCEED;

    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::commit()
*
*   Description          :  Commit
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
RET_CODE DbiConnectionHelper::commit()
{
    return endTransaction(TRUE);    /* PMSTA-19735 - 020415 - PMO */
}

/************************************************************************
*   Function             :  DbiConnectionHelper::rollback()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
RET_CODE DbiConnectionHelper::rollback()
{
    return endTransaction(FALSE);   /* PMSTA-19735 - 020415 - PMO */
}

/************************************************************************
*   Function             :  DbiConnectionHelper::sendAllMsg()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190611
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::sendAllMsg()
{
    if (this->m_dbiConn != nullptr && this->isExternalMsgManagement() == false)
    {
        this->m_dbiConn->sendAllMsg();
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::sendAllMsgFromMA()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190611
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::sendAllMsgFromMA()
{
    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->sendAllMsgFromMA();
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::emptyMsg()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190611
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::emptyMsg()
{
    if (this->m_dbiConn != nullptr)
    {
        return this->m_dbiConn->emptyMsg();
    }
    return true;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::clearMsg()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 200619
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::clearMsg()
{
    if (this->m_dbiConn != nullptr)
    {
        return this->m_dbiConn->clearMsg();
    }
}

/************************************************************************
*   Function             :  DbiConnectionHelper::getNewErrMsgInfoStp()
*
*   Description          :  Rollback
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-37366 - LJE - 190611
*
*   Last Modification    :
*
*************************************************************************/
DbaErrmsgInfosClass *DbiConnectionHelper::getNewErrMsgInfoStp(const char *file, int line)
{
    if (this->m_dbiConn != nullptr)
    {
        return &this->m_dbiConn->m_msgStructHeaderSt.getNewErrMsgInfoSt(file, line);
    }
    return nullptr;
}

/************************************************************************
*   Function             :  DbiConnectionHelper:setExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::setExternalMsgManagement(bool bExternalMsgManagement)
{
    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->setExternalMsgManagement(bExternalMsgManagement);
    }
}

/************************************************************************
*   Function             :  RequestHelper:isExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isExternalMsgManagement()
{
    if (this->m_dbiConn != nullptr)
    {
        return this->m_dbiConn->isExternalMsgManagement();
    }
    return false;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::getId()
*
*   Description          :  Return the connection ID
*
*   Arguments            :  None
*
*   Return               :  connection ID
*                           DBA_CONN_NOT_FOUND if the connection is not established
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*************************************************************************/
int & DbiConnectionHelper::getId()
{
    DbiConnection * dbiConn = getConnection();

    return nullptr != dbiConn ? dbiConn->getId() : m_connNotFound;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::getDescription()
*
*   Description          :  Return a copy of the connection description.
*                           Empty object might be returned if there is no connection
*
*   Arguments            :  None
*
*   Return               :  a copy of the connection description
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
AAAConnectionDescription &DbiConnectionHelper::getDescription()
{
    if (nullptr != this->m_dbiConn)
    {
        return this->m_dbiConn->getDescription();
    }

    return this->m_desc;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::reloadDescription()
*
*   Description          :  Reload the description (configuration has changed)
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void DbiConnectionHelper::reloadDescription()
{
    if (nullptr != this->m_dbiConn)
    {
        this->m_dbiConn->reloadDescription();
    }
    else
    {
        this->isValidAndInit();
    }
}


/************************************************************************
*   Function             :  DbiConnectionHelper::dbaInsert()
*
*   Description          :  Insert a record usig the connectionHelper facility
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaInsert(OBJECT_ENUM    object,
                                        int            role,
                                        DBA_DYNFLD_STP inputData)
{
    RET_CODE ret = RET_SUCCEED;
    if (isValidAndInit())
    {
        this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;
        ret = DBA_Insert2(object,
                          role,
                          GET_DYNSTENUM(inputData),
                          inputData,
                          *this);
    }
    else
    {
        ret = RET_DBA_ERR_CONNOTFOUND;
    }
    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaUpdate()
*
*   Description          :  Update a record using the connectionHelper facility
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaUpdate(OBJECT_ENUM    object,
                                        int            role,
                                        DBA_DYNFLD_STP inputData)
{
    RET_CODE ret = RET_SUCCEED;
    if (isValidAndInit())
    {
        this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;
        ret = DBA_Update2(object,
                          role,
                          GET_DYNSTENUM(inputData),
                          inputData,
                          *this);
    }
    else
    {
        ret = RET_DBA_ERR_CONNOTFOUND;
    }
    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaDelete()
*
*   Description          :  Delete a record usig the connectionHelper facility
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaDelete(OBJECT_ENUM    object,
                                        int            role,
                                        DBA_DYNFLD_STP inputData)
{
    RET_CODE ret = RET_SUCCEED;
    if (isValidAndInit())
    {
        this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;
        ret = DBA_Delete2(object,
                          role,
                          GET_DYNSTENUM(inputData),
                          inputData,
                          *this);
    }
    else
    {
        ret = RET_DBA_ERR_CONNOTFOUND;
    }
    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaInsUpd()
*
*   Description          :  Insert or update a record if this record exists
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaInsUpd(OBJECT_ENUM    object,
                                        int            role,
                                        DBA_DYNFLD_STP inputData)
{
    RET_CODE ret = RET_SUCCEED;
    if (isValidAndInit())
    {
        this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;
        ret = DBA_InsUpd(object,
                         role,
                         GET_DYNSTENUM(inputData),
                         inputData,
                         *this);
    }
    else
    {
        ret = RET_DBA_ERR_CONNOTFOUND;
    }
    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaSelect()
*
*   Description          :  return an array of records from database
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           DBA_DYNFLD_STP **outputData
*                           int            role
*                           int            option
*                           int            maxRow
*                           int            *resultRows
*
*   Return               :  RET_CODE
*
*   Last modif.          :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaSelect(OBJECT_ENUM    object,
                                        int            role,
                                        DBA_DYNFLD_STP inputData,
                                        DBA_DYNST_ENUM outputDynStEnum,
                                        DBA_DYNFLD_STP **outputData,
                                        int            *resultRows)
{
    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    return DBA_Select2(object,
                       role,
                       GET_DYNSTENUM(inputData),
                       inputData,
                       outputDynStEnum,
                       outputData,
                       m_maxRows,
                       resultRows,
                       *this);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaMultiSelect()
*
*   Description          :  return multiple array of records from database
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           DBA_DYNFLD_STP **outputData
*                           int            role
*                           int            maxRow
*                           int            *resultRows
*
*   Return               :  RET_CODE
*
*   Last modif.          :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaMultiSelect(OBJECT_ENUM            object,
                                             int                    role,
                                             DBA_DYNFLD_STP         inputData,
                                             const DBA_DYNST_ENUM **outputStLstPtr,
                                             DBA_DYNFLD_STP       **outputDataLst,
                                             int                   *resultRows)
{
    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    return DBA_MultiSelect2(object,
                       role,
                       GET_DYNSTENUM(inputData),
                       inputData,
                       outputStLstPtr,
                       outputDataLst,
                       m_options,
                       m_maxRows,
                       resultRows,
                       *this,
                       nullptr);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaMultiSelect()
*
*   Description          :  return multiple array of records from database
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           DBA_DYNFLD_STP **outputData
*                           int            role
*                           int            maxRow
*                           int            *resultRows
*
*   Return               :  RET_CODE
*
*   Last modif.          :  PMSTA-37366 - LJE - 190807
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaMultiSelect(OBJECT_ENUM            object,
                                             int                    role,
                                             DBA_DYNFLD_STP         inputData,
                                             DBA_DYNFLD_STP       **outputDataLst,
                                             int                   *resultRows)
{
    if (outputDataLst == nullptr || resultRows == nullptr)
    {
        return RET_DBA_ERR_ARGNOMATCH;
    }

    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    DBA_DYNST_ENUM inputSt  = GET_DYNSTENUM(inputData);
    RET_CODE       retCode  = RET_SUCCEED;

    /* Initialize the result row number to 0 */
    *resultRows = 0;

    /* Choose a procedure in the object procedures list and store the necessary parameter */
    const DBA_PROC_STP procedure = DBA_GetStoredProcs(MultiSelect, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure was found */
    if (procedure == NULL)
    {
        if ((this->m_options & DBA_NO_PROC_ERROR) == 0)
        {
            char    objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */
            const char  *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char        entityStrIn[13];        /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            /* PMSTA-13122 - LJE - 120420 */
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(MultiSelect, object, role, inputSt, inputData, NullDynSt, false, "MultiSelect", objString, entitySqlNameIn, "none");
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    /* PMSTA-37366 - LJE - 200625 */
    if (this->getDescription().getType() != procedure->server)
    {
        DbiConnectionHelper localDbiConnHelper(procedure->server);
        return localDbiConnHelper.dbaMultiSelect(object, role, inputData, outputDataLst, resultRows);
    }

    try
    {
        RequestHelper requestHelper(*this);

        if (requestHelper.startProcedureCall(procedure, inputData) == false)
        {
            return(requestHelper.getLastResultRetCode());
        }

        const DBA_DYNST_ENUM **outputStLstPtr = procedure->multiOutputDynStPtr;

        int idx = 0;
        do
        {
            /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
            DBA_DYNST_ENUM dynStEn  = *(outputStLstPtr[idx]);
            OBJECT_ENUM    objectEn = NullEntity;

            if (dynStEn == InvalidDynSt)
            {
                std::string msg("Too many results-set returns when call of stored procedure: ");
                msg += procedure->procName;

                MSG_SendMesg(RET_DBA_ERR_DIALOG, 1, FILEINFO, msg.c_str());
                break;
            }
            else
            {
                objectEn = GET_DYNST_ENTITY(dynStEn);
                requestHelper.setDynStOutputData(dynStEn);

                /* Retrieve all rows in the result set */
                retCode = requestHelper.readAllRecord(&(resultRows[idx]), &(outputDataLst[idx]));

                if (resultRows[idx] == 0)
                {
                    FREE(outputDataLst[idx]);
                }
            }
            idx++;
        } while (RET_GET_LEVEL(retCode) != RET_LEV_ERROR &&
                 requestHelper.getLastResultType() == DBI_ROW_RESULT);
    }
    catch (std::exception &)
    {
        retCode = RET_DBA_ERR_DBPROBLEM;
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }

    return(retCode);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaGet()
*
*   Description          :  return a record from database
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           DBA_DYNFLD_STP *outputData
*                           int            role
*                           int            option
*
*   Return               :  RET_CODE
*
*   Last modif.          :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaGet(OBJECT_ENUM    object,
                                     int            role,
                                     DBA_DYNFLD_STP inputData,
                                     DBA_DYNFLD_STP *outputData,
                                     DBA_PROC_STP   procedure  )    /* PMSTA-34344 - TEB - 190319 */
{
    DbaCallGuard dbaCallGuard(*this);

    if (this->isDbaAccess(Get) && procedure == nullptr)
    {
        return this->m_dbiConn->getDdlGenDbaAccessPtr()->dbaGet(object, role, inputData, *outputData);
    }

    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    DBA_DYNFLD_STP  bindSt         = NULL;
    DBA_DYNFLD_STP  savedInputData = NULL;
    DBI_INT         status         = 0,
                    resultType     = 0;
    RET_CODE        ret,
                    finalResult    = RET_SUCCEED,
                    retCode;
    int             posIndexLocal  = -1, posIndexGlobal = -1;
    OBJECT_ENUM     objectEn       = NullEntity;
    DBA_DYNST_ENUM  inputSt        = GET_DYNSTENUM(inputData);
    DBA_DYNST_ENUM  outputSt       = GET_DYNSTENUM(*outputData);

    /* Test ouput data argument validity */
    if (*outputData == NULL)
        return(RET_DBA_ERR_ARGNOMATCH);

    /* Retrieve a procedure in the object procedures list */
    /* PMSTA-34344 - TEB - 190319 */
    if (procedure == NULL)
    {
        procedure = DBA_GetStoredProcs(Get, object, role, inputSt, inputData, outputSt);

        /* PMSTA-45413 - LJE - 220111 */
        if (role == DBA_ROLE_DB_ACCESS &&
            SYS_IsDdlGenMode() &&
            procedure->server == InternalProc)
        {
            procedure = DBA_GetStoredProcs(Get, object, DBA_ROLE_DB_ACCESS_USR, inputSt, inputData, outputSt);
        }
    }

    /* If no procedure was found */
    if (procedure == NULL)
    {
        if ((this->dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
            const char	    *entitySqlNameIn = NULL, *entitySqlNameOut = NULL;  /* REF2697 - SSO - 000510 */
            char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */
            char	    entityStrOut[13];	    /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            /* PMSTA-13122 - LJE - 120420 */
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }
            DBA_GetObjectEnumByDynSt(outputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameOut = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameOut == NULL)
            {
                sprintf(entityStrOut, "unknown(%d)", outputSt);
                entitySqlNameOut = entityStrOut;
            }

            DBA_LogMesgProcedureNotFound(Get, object, role, inputSt, inputData, outputSt, false, "Get", objString, entitySqlNameIn, entitySqlNameOut);  /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }
    this->setCurrProcedure(procedure);

    /* If Procedure is an internal proc, call a C function, not a stored procedure */
    if (procedure->server == InternalProc)
    {
        /* Procedure is optimised and we are in server mode */
        if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
        {
            /* Search if element is stored in local and then in global */
            DATE_START_TIMER(10, TIMER_MASK_SQLC);
            ret = DBA_ReadOpti(procedure, Opti_LocalGlobal, inputData, *outputData, NULL,
                               &posIndexLocal, &posIndexGlobal);
            DATE_STOP_TIMER(10, TIMER_MASK_SQLC);

            switch (ret)
            {
                case RET_SUCCEED:
                    return RET_SUCCEED;

                    /* REF9108 - YST - 030703 - return RET_DBA_INFO_NODATAWITHOPTI */
                case RET_DBA_INFO_NODATA:
                    return RET_DBA_INFO_NODATAWITHOPTI;

                case RET_DBA_INFO_NODATAOPTI:
                default:
                    break;
            }
        }

        /* REF10488 - DDV - 041018 - If the internal function is optimised, backup input arg.
           If the internal function modified the input args, there is no effect on optimisation */
        if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
        {
            savedInputData = ALLOC_DYNST(inputSt);
            COPY_DYNST_FLAG_NO_IMPACT(savedInputData, inputData, inputSt);
        }

        if (this->isValidAndInit() == false)
        {
            return(RET_DBA_ERR_CONNOTFOUND);
        }
        retCode = procedure->fctDefSt.getFct(object, inputData, outputData, *this);

        switch (retCode)
        {
            case RET_SUCCEED:
                if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
                {
                    DATE_START_TIMER(11, TIMER_MASK_SQLC);
                    ret = DBA_WriteOpti(procedure, Opti_GlobalLocal, savedInputData, *outputData, FALSE,
                                        posIndexLocal, posIndexGlobal);
                    DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

                    if (ret != RET_SUCCEED)
                    {
                        retCode = RET_GEN_ERR_INVARG;
                    }
                }

                FREE_DYNST(savedInputData, inputSt);

                return retCode;

            case RET_DBA_INFO_NO_MORE_DATA:
                if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
                {
                    DATE_START_TIMER(11, TIMER_MASK_SQLC);
                    /* DLA - PMSTA-22791 - 160317 */
                    /*ret = */DBA_WriteOpti(procedure, Opti_Local, savedInputData, NULL, FALSE,
                                            posIndexLocal, posIndexGlobal);
                    DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
                }

                FREE_DYNST(savedInputData, inputSt);
                return(RET_DBA_INFO_NODATA);

            /* PMSTA-46681 - LJE - 230413 */
            case RET_DBA_INFO_NODATAWITHOPTI:
                FREE_DYNST(savedInputData, inputSt);
                return retCode;

            default:
                FREE_DYNST(savedInputData, inputSt);

                return(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    bool found = false;

    /* Procedure is optimised and we are in server mode */
    if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
    {
#ifdef AAADEBUG
        DBA_PROCPARAM_STP 	procParam = NULL;
        int			paramIndex = 0;

        /***** CHECK NON_AUTHORIZED NULL FIELD *****/
        procParam = procedure->procParamDefPtr;
        while (procParam[paramIndex].paramName[0] != END_OF_STRING)
        {
            if (GET_FLD_TYPE(inputSt, *(procParam[paramIndex].fldNbrPtr)) == FlagType &&         /*  FIH-REF11254-050617 Replace .fldNbr by .fldNbrPtr   */
                IS_NULLFLD(inputData, *(procParam[paramIndex].fldNbrPtr)) == TRUE)
            {
                SET_FLAG(inputData, *(procParam[paramIndex].fldNbrPtr), 0);
                MSG_LogMesg(RET_DBA_ERR_SETPARAM, 1, FILEINFO,
                            procParam[paramIndex].paramName,
                            procedure->procName);
            }
            paramIndex++;
        }
#endif

        /* Search if element is stored in local and then in global */
    /* PMSTA00178 - TGU - 070201 - Backup input argument , If outputData and inputData are pointing same memory location.
    ** because if record not found in local cash and found in global case we will modify the outputData pointer and
    ** call "DBA_WriteOpti()" to wright the record in local cash.
    */
        if (inputData == *outputData)
        {
            savedInputData = ALLOC_DYNST(inputSt);
            COPY_DYNST_FLAG_NO_IMPACT(savedInputData, inputData, inputSt);

            DATE_START_TIMER(10, TIMER_MASK_SQLC);
            ret = DBA_ReadOpti(procedure, Opti_LocalGlobal, savedInputData, *outputData, NULL,
                               &posIndexLocal, &posIndexGlobal, this);
            DATE_STOP_TIMER(10, TIMER_MASK_SQLC);

            FREE_DYNST(savedInputData, inputSt);
        }
        else
        {
            DATE_START_TIMER(10, TIMER_MASK_SQLC);
            ret = DBA_ReadOpti(procedure, Opti_LocalGlobal, inputData, *outputData, NULL,
                               &posIndexLocal, &posIndexGlobal, this);
            DATE_STOP_TIMER(10, TIMER_MASK_SQLC);
        }

        switch (ret)
        {
            case RET_SUCCEED:
                found = true;
                break;

                /* REF9108 - YST - 030703 */    /* Usage RET_DBA_INFO_NODATAWITHOPTI:
               Opti returns no data, because no data found in database and "no data" stored for optimisation (local ?) */
            case RET_DBA_INFO_NODATA:
                return RET_DBA_INFO_NODATAWITHOPTI;

            case RET_DBA_INFO_NODATAOPTI:
            default:
                break;
        }
    }


    /* Optimisation doesn't exist for this procedure or nothing found */
    /* in optimisation search. */
    if (false == found)
    {
        if (this->isValidAndInit() == false)
        {
            return(RET_DBA_ERR_CONNOTFOUND);
        }

        ThreadErrorContext  threadErrorContext;                             /* PMSTA-32315 - 260718 - PMO */
        threadErrorContext.setDbiCon(this->getConnection());
        threadErrorContext.addErrorCode(RET_WUI_USER_DOES_NOT_HAVE_DATA_SECURITY_ACCESS);

        if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE && inputData == *outputData)
        {
            savedInputData = ALLOC_DYNST(inputSt);
            COPY_DYNST_FLAG_NO_IMPACT(savedInputData, inputData, inputSt);
        }

        if (USE_NEW_ACCESS_API(this->getConnection()))
        {
            RequestHelper requestHelper(*this);

            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                return(requestHelper.getLastResultRetCode());
            }

            requestHelper.setDynStOutputData(outputSt);

            /* Retrieve all rows in the result set */
            retCode = requestHelper.readOneRecord(*outputData);

            if (retCode == RET_DBA_INFO_NO_MORE_DATA)
            {
                /* Procedure is optimised and we are in server mode */
                if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
                {
                    /* Store null element in local only */
                    if (savedInputData != NULL)
                    {
                        DATE_START_TIMER(11, TIMER_MASK_SQLC);
                        /* DDV - 151007 - If writeOpti failed, DBA_GET2 must continue, it's wrong to make it fail */
                        DBA_WriteOpti(procedure, Opti_GlobalLocal, savedInputData, NULL, FALSE, posIndexLocal, posIndexGlobal);
                        DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

                        FREE_DYNST(savedInputData, inputSt);
                    }
                    else
                    {
                        DATE_START_TIMER(11, TIMER_MASK_SQLC);
                        /* DDV - 151007 - If writeOpti failed, DBA_GET2 must continue, it's wrong to make it fail */
                        /* DLA - PMSTA-22791 - 160317 */
                        /*ret = */ DBA_WriteOpti(procedure, Opti_GlobalLocal, inputData, NULL, FALSE,
                                                 posIndexLocal, posIndexGlobal);
                        DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
                    }
                }
                return(RET_DBA_INFO_NODATA);
            }
            else if (RET_GET_LEVEL(retCode) != RET_LEV_ERROR &&
                     requestHelper.fetch() != RET_DBA_INFO_NO_MORE_DATA)
            {
                std::stringstream msg;
                msg << "The procedure " << procedure->procName << " having the action 'get' returns more than one record";
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
            }
            else if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
            {
                return (retCode);
            }
        }
        else
        {
            DbiConnection      &dbiConn = *this->getConnection();

            dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

            /* Optional setting of the timestamp PMSTA-25587 - 191016 - PMO */
            DBA_SetTimeout(procedure, &dbiConn);

            OBJECT_ENUM procObjEn = NullEntity;

            /* PMSTA-18593 - LJE - 151217 */
            if (*(procedure->inputDynStPtr) != NullEntity && procedure->procParamDefPtr == UNUSED)
            {
                procObjEn = GET_OBJ_DYNST(*(procedure->inputDynStPtr));
            }

            /* Memorize the necessary parameters for the request in the */
            /* command structure */
            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure, procObjEn) != RET_SUCCEED)
            {
                /* DLA VOIR COMMENT UTILISER LE POOL POUR GERER AU MIEUX UNE RECONNECTION AVEC PDE */
                FLAG_T		isReconnectSucceeded = FALSE;	/* REF3016 */

                dbiConn.releaseCommand();

                if ((this->dbaGetOptions() & DBA_NO_CLOSE) == DBA_NO_CLOSE)
                {
                    AAALocalConnectionProvider::get().reconnect(dbiConn);
                    /* If the server is reached. */
                    if (dbiConn.isValid() && dbiConn.isConnected())
                    {
                        if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) == RET_SUCCEED)
                        {
                            isReconnectSucceeded = TRUE;
                        }
                    }
                }

                if (isReconnectSucceeded == FALSE)	/* REF3016 */
                {
                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_ERR_SETPARAM);
                }
            }

            /* Send the request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();
                /* Try to reconnect to the server. */

                if ((this->dbaGetOptions() & DBA_SET_CONN) == DBA_SET_CONN)
                {
                    if(getSilentMode() == false)   /* PMSTA-45390 - JBC - 210607 */
                    {
                        if (dbiConn.m_msgStructHeaderSt.empty())
                        {
                            MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);
                        }
                        else
                        {
                            dbiConn.sendAllMsg();
                        }
                    }

                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_ERR_DIALOG);
                }

                AAALocalConnectionProvider::get().reconnect(dbiConn);

                if (!dbiConn.isConnected() || !dbiConn.isValid()) /* DLA - PMSTA-14249 - 160804 */
                {
                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_ERR_CONNOTFOUND);
                }

                /* REF3955 - SSO - 000111 added test */
                if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
                {
                    dbiConn.releaseCommand();

                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_ERR_SETPARAM);
                }

                if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
                {
                    dbiConn.releaseCommand();
                    MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);

                    FREE_DYNST(savedInputData, inputSt);

                    if(getSilentMode())   /* PMSTA-45390 - JBC - 210607 */
                    {
                         return RET_DBA_ERR_DBPROBLEM;
                    }

                    if (dbiConn.m_msgStructHeaderSt.empty() == false)
                    {
                        dbiConn.sendAllMsg();
                        return RET_DBA_ERR_DBPROBLEM;
                    }
                    else
                    {
                        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                    }
                }
            }

            if (resultType != DBI_ROW_RESULT)
            {
                RET_CODE locRet;
                /* Call to function which will filter received messages during Get operation */
                dbiConn.filterMsgInfos(&finalResult);
                /* REF3955 - SSO - 000107 */
                if (finalResult == RET_SRV_LIB_ERR_INV_PARAM_VALUE)
                {
                    this->getConnection()->setValidConnection(false);
                }
                else
                {
                    dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
                    dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */
                }

                if (finalResult != RET_SUCCEED)
                    locRet = finalResult;
                else
                {
                    if (status == 0)
                        locRet = RET_DBA_INFO_NODATA;
                    else
                    {
                        DBA_SendMesgForProcResType(procedure->procName, resultType);
                        locRet = RET_DBA_ERR_DBPROBLEM;
                    }
                }

                dbiConn.releaseCommand();

                FREE_DYNST(savedInputData, inputSt);

                return(locRet);
            }

            /* Call to function which will filter received messages during
               insert operation */
            dbiConn.filterMsgInfos(&finalResult);

            if (finalResult != RET_SUCCEED)
            {
                /* REF3955 - SSO - 000107 */
                if (finalResult == RET_SRV_LIB_ERR_INV_PARAM_VALUE)
                {
                    this->getConnection()->setValidConnection(false);
                }
                dbiConn.releaseCommand();

                FREE_DYNST(savedInputData, inputSt);

                return(finalResult);
            }

            /* Allocate memory for the bind structure */
            if ((bindSt = ALLOC_DYNST(outputSt)) == NULL)
            {
                dbiConn.releaseCommand();

                FREE_DYNST(savedInputData, inputSt);

                return(RET_MEM_ERR_ALLOC);
            }

            /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
            objectEn = GET_DYNST_ENTITY(outputSt);

            /* Bind result columns with output data dynamic struct.   */

            if (dbiConn.bindRecvDynSt(outputSt, bindSt) != RET_SUCCEED)
            {
                FREE_DYNST(bindSt, outputSt);
                dbiConn.releaseCommand();

                FREE_DYNST(savedInputData, inputSt);

                return(RET_DBA_ERR_SYBBIND);
            }

            /* Retrieve the row in the result set */
            retCode = dbiConn.fetch();/* PMSTA-23385 - LJE - 160630 */

            switch (retCode)
            {
                case RET_DBA_INFO_NO_MORE_DATA:
                    /* Procedure is optimised and we are in server mode */
                    if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
                    {
                        /* Store null element in local only */
                        if (savedInputData != NULL)
                        {
                            DATE_START_TIMER(11, TIMER_MASK_SQLC);
                            /* DDV - 151007 - If writeOpti failed, DBA_GET2 must continue, it's wrong to make it fail */
                            DBA_WriteOpti(procedure, Opti_GlobalLocal, savedInputData, NULL, FALSE, posIndexLocal, posIndexGlobal);
                            DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

                            FREE_DYNST(savedInputData, inputSt);
                        }
                        else
                        {
                            DATE_START_TIMER(11, TIMER_MASK_SQLC);
                            /* DDV - 151007 - If writeOpti failed, DBA_GET2 must continue, it's wrong to make it fail */
                            /* DLA - PMSTA-22791 - 160317 */
                            /*ret = */ DBA_WriteOpti(procedure, Opti_GlobalLocal, inputData, NULL, FALSE,
                                                     posIndexLocal, posIndexGlobal);
                            DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
                        }
                    }

                    FREE_DYNST(bindSt, outputSt);
                    dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
                    dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */

                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_INFO_NODATA);

                case RET_SUCCEED:
                    while (dbiConn.fetch() == TRUE); /* PMSTA-23385 - LJE - 160630 */
                    break;

                default:
                    while (dbiConn.fetch() == TRUE); /* PMSTA-23385 - LJE - 160630 */

                    FREE_DYNST(bindSt, outputSt);
                    dbiConn.releaseCommand();

                    FREE_DYNST(savedInputData, inputSt);

                    return(RET_DBA_ERR_READ_DATA);
            }

            /* Update the  NULL flag for each field of the result struct / REF11780 - 100406 - PMO */
            DBI_CopyNullFlagsAndLengthDynSt(dbiConn, bindSt, outputSt); /* REF8844 - LJE - 030407 */

            /* Copy the bind structure in the data structure */
            /* REF4329 - SSO - 000204 : do not overwrite NON-database fields ...   if (COPY_DYNST(*outputData, bindStEn, outputSt) == FALSE) */
            if (DBA_CopyDynStNoNoDbF(*outputData, bindSt, outputSt) == FALSE)
            {
                FREE_DYNST(bindSt, outputSt);
                dbiConn.releaseCommand();

                FREE_DYNST(savedInputData, inputSt);

                return(RET_GEN_ERR_INVARG);
            }

            /* Free the bind structure */
            FREE_DYNST(bindSt, outputSt);
            dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
            dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */
        }

        if (objectEn != NullEntity)
        {
            DBA_SetDfltEntityNotDbFld(objectEn, outputSt, *outputData); /* PMSTA-42198 - DDV - 201028 - Use a new function to skip fields returned by database */
        }

        /* Procedure is optimised and we are in server mode */
        if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
        {
            /* Store element in global and then in local */
            if (savedInputData != NULL)
            {
                DATE_START_TIMER(11, TIMER_MASK_SQLC);
                ret = DBA_WriteOpti(procedure, Opti_GlobalLocal, savedInputData, *outputData, FALSE,
                                    posIndexLocal, posIndexGlobal);
                DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

                if (ret != RET_SUCCEED)
                {
                    FREE_DYNST(bindSt, outputSt);
                    FREE_DYNST(savedInputData, inputSt);
                    return(RET_GEN_ERR_INVARG);
                }
            }
            else
            {
                DATE_START_TIMER(11, TIMER_MASK_SQLC);
                /* ret = */DBA_WriteOpti(procedure, Opti_GlobalLocal, inputData, *outputData, FALSE,
                                         posIndexLocal, posIndexGlobal);
                DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
            }
        }
        FREE_DYNST(savedInputData, inputSt);

    }

    if (EV_ExtractFile && EV_SetProcParametersFlg)
    {
        DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        EV_SetProcParametersFlg = FALSE;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaNotif()
*
*   Description          :  Note: If Insert/Updating DB with Notif, must use begintransaction/endtransaction(commit/rollback) to affect DB!
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*                           int            *notifStatus
*
*   Return               :  RET_CODE
*
*   Last modif.          :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*                           PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*                           PMSTA-29084 - 101117 - PMO : Connections issue between the dispatcher and the fusion server
**
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaNotif(OBJECT_ENUM    object,
                                       int            role,
                                       DBA_DYNFLD_STP inputData)
{
    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    ThreadRetryPrefixMessage    threadRetryPrefixMessage("Retrying");                               /* PMSTA-25644 - 141216 - PMO */
    RET_CODE                    ret = RET_SUCCEED;

    for (int retry = 0; retry <= m_notifyRetry; retry++ )                                           /* PMSTA-25644 - 141216 - PMO */
    {
        if((ret = DBA_Notif2(object, role, GET_DYNSTENUM(inputData), inputData, *this)) == RET_SUCCEED)    /* PMSTA-22990 - 080416 - PMO */
        {
            break;
        }

        // Error
        if (m_notifyReopen)
        {
            if (GEN_IsDispatcherChanged())
            { // Dispatcher has changed
                MemoryTracing mt;

                /* PMSTA-28392 - 111017 - CMILOS */
                if (retry == m_notifyRetry)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "Fusion server cannot notify dispatcher at start up%1", NameType, mt.getMemoryLine().c_str());
                }
                else
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "The configuration of the dispatcher has been changed or restarted%1", NameType, mt.getMemoryLine().c_str());
                }
            }
        }
    }

    return ret;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::setNotifRetry()
*
*   Description          :  Define how much time we retry in case of error
*
*   Arguments            :  retry   # of retry
*
*   Return               :  None
*
*   Last modif.          :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void DbiConnectionHelper::setNotifRetry(const int retry)
{
    m_notifyRetry = retry -1;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::setNotifReopen()
*
*   Description          :  Define if we reopen the connection in case of error
*
*   Arguments            :  reopen
*
*   Return               :  None
*
*   Last modif.          :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void DbiConnectionHelper::setNotifReopen(const bool reopen)
{
    m_notifyReopen = reopen;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::dbaCheck()
*
*   Description          :
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*                           int            *checkStatus
*
*   Return               :  RET_CODE
*
*   Last modif.          :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*                           PMSTA-46404 - DDV - 211005 - Remove checkStatus parameter
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaCheck(OBJECT_ENUM    object,
                                       int            role,
                                       DBA_DYNFLD_STP inputData)
{
    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;

    return DBA_Check(object,
                     role,
                     GET_DYNSTENUM(inputData),
                     inputData,
                     *this);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaInsertByBlock()
*
*   Description          :
*
*   Arguments            :  DBA_DYNFLD_STP inputData
*                           int            role
*                           int            option
*                           int            *checkStatus
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaInsertByBlock(OBJECT_ENUM          object,
                                               int                  role,
                                               DBA_DYNFLD_STP       *inputDataTab,
                                               int                  inputRecNbr,
                                               int                  maxRecInBuf)
{
    this->m_options = this->m_options | DBA_IN_TRAN | DBA_SET_CONN | DBA_NO_CLOSE;

    return DBA_InsertByBlock(object,
                             role,
                             (*inputDataTab)->dynStEnum,
                             inputDataTab,
                             inputRecNbr,
                             this->m_options,
                             *this->getConnection(),
                             maxRecInBuf);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaCopy()
*
*   Description          :  copy a record in database
*
*   Arguments            :  OBJECT_ENUM    object
*                           DBA_DYNFLD_STP inputData
*                           int            role
*
*   Return               :  RET_CODE
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaCopy(OBJECT_ENUM    object,
                                      int            role,
                                      DBA_DYNFLD_STP inputData)
{
    this->m_options = this->m_options | DBA_SET_CONN | DBA_NO_CLOSE;
    return DBA_Copy(object,
                    role,
                    GET_DYNSTENUM(inputData),
                    inputData,
                    *this);
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaGetMsgStructHeader()
*
*   Description          :
*
*   Arguments            :  Current Procedure
*
*   Return               :  None
*
*************************************************************************/
void DbiConnectionHelper::setCurrProcedure(DBA_PROC_STP currProcedure)
{
    this->m_currProcedureStp = currProcedure;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaGetMsgStructHeader()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  Current Procedure
*
*************************************************************************/
DBA_PROC_STP DbiConnectionHelper::getCurrProcedure()
{
    return this->m_currProcedureStp;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaGetMsgStructHeader()
*
*   Description          :  return the message structure Header ptr filled after a call to dbaInsertByBlock function if an error occurs
*
*   Arguments            :  None
*
*   Return               :  DBA_ERRMSG_INFOS_STP
*
*************************************************************************/
DBA_ERRMSG_HEADER_STP DbiConnectionHelper::dbaGetMsgStructHeader()
{
    if (this->m_dbiConn != nullptr)
    {
        RET_CODE finalResult = RET_SUCCEED;
        this->m_dbiConn->filterMsgInfos(&finalResult);
        return &this->m_dbiConn->m_msgStructHeaderSt;
    }
    return nullptr;
}

int DbiConnectionHelper::dbaGetOptions()
{
    return m_options;
}

void DbiConnectionHelper::dbaSetOptions(int options)
{
    m_options = options;
}

int DbiConnectionHelper::dbaGetSelectMaxRows()
{
    return m_maxRows;
}

void DbiConnectionHelper::dbaSetSelectMaxRows(int maxRows)
{
    m_maxRows = maxRows;
}

/************************************************************************
*   Function             :  DbiInOutData:DbiInOutData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171028
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData::DbiInOutData(DATATYPE_ENUM dataType, bool bInpout, bool bOutput, const std::string &sqlName, bool bToAllocate)
    : m_dataType(dataType)
    , m_nullInd(DBI_NULLDATA)
    , m_dataLength(0)
    , m_valuePtr(nullptr)
    , m_outputDynFldStp(nullptr)
    , m_sqlName(sqlName)
    , m_bInput(bInpout)
    , m_bOutput(bOutput)
    , m_bOutputOnly(false)
    , m_paramDataType(NullDataType)
    , m_fieldIdx(Null_Dynfld)
    , m_colPos(Null_Dynfld)
    , m_outputFieldIdx(Null_Dynfld)
    , m_sqlTraceHide(false)
    , m_strLenInd(0)
    , m_size(0)
    , m_allocSize(0)
    , m_ptrToFree(nullptr)
{
    SYS_Bzero(&this->m_dynFldSt, sizeof(this->m_dynFldSt));
    this->m_dynFldSt.dataType = static_cast<unsigned char>(dataType);

    if (bToAllocate)
    {
	    SET_MAXALLOCFLG_T(this->getDynFldStp(), 0);

        switch (GET_CTYPE(this->m_dataType))
        {
            case CharPtrCType:
            case TextPtrCType:
                this->m_size = sizeof(char);
                this->m_allocSize = GET_MAXDATALEN(this->m_dataType);
                this->getDataPtr()->strData.ptr = static_cast<char*>(CALLOC(this->m_allocSize + this->m_size, sizeof(char)));
                this->setPtrToFree(this->getDataPtr()->strData.ptr);
                break;

            case UniCharPtrCType:
            case UniTextPtrCType:
                this->m_size = sizeof(UChar);
                this->m_allocSize = GET_MAXDATALEN(this->m_dataType);
                this->getDataPtr()->ustrData.ptr = static_cast<UChar*>(CALLOC(this->m_allocSize + this->m_size, sizeof(UChar)));
                this->setPtrToFree(this->getDataPtr()->ustrData.ptr);
                break;

            default:
                this->m_size = sizeof(*this->getDataPtr());
                break;
        }
        this->m_valuePtr = DBA_GetDataFromDynFldData(this->m_dataType, *this->getDataPtr());
    }
}

/************************************************************************
*   Function             :  DbiInOutData:DbiInOutData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171028
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData::DbiInOutData(DBA_DYNFLD_STP dynFldStp, bool bInpout, bool bOutput, const std::string &sqlName)
    : DbiInOutData(static_cast<DATATYPE_ENUM>(dynFldStp->dataType), bInpout, bOutput, sqlName, false)
{
    this->m_dynFldSt = *dynFldStp;
    this->m_valuePtr = DBA_GetDataFromDynFldData(this->m_dataType, *this->getDataPtr());
}

/************************************************************************
*   Function             :  DbiInOutData:~DbiInOutData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171028
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData::~DbiInOutData()
{
    FREE(this->m_ptrToFree);
}

/************************************************************************
*   Function             :  DbiInOutData:setOutputDynFldStp()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190918
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::setOutputDynFldStp(DBA_DYNFLD_STP outputDynFldStp)
{
    this->m_outputDynFldStp = outputDynFldStp;
}

/************************************************************************
*   Function             :  DbiInOutData:initNullValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190507
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::initNullValue()
{
    if (this->m_nullInd == DBI_NULLDATA)
    {
        SYS_Bzero(this->m_valuePtr, this->m_size);
        SET_NOTNULLFLG_F(&this->m_dynFldSt, 0);
    }
    else
    {
        SET_NOTNULLFLG_T(&this->m_dynFldSt, 0);
    }
}

/************************************************************************
*   Function             :  DbiInOutData:getDynFldStp()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190507
*
*   Last Modification    :
*
*************************************************************************/
DBA_DYNFLD_STP DbiInOutData::getDynFldStp()
{
    return &this->m_dynFldSt;
}

/************************************************************************
*   Function             :  DbiInOutData:getDataPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190507
*
*   Last Modification    :
*
*************************************************************************/
DBA_DYNFLDDATA_UN *DbiInOutData::getDataPtr()
{
    return &this->m_dynFldSt.data;
}

/************************************************************************
*   Function             :  DbiInOutData:getAllocSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200302
*
*   Last Modification    :
*
*************************************************************************/
size_t DbiInOutData::getAllocSize()
{
    return this->m_allocSize;
}

/************************************************************************
*   Function             :  DbiInOutData:getDataSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220906
*
*   Last Modification    :
*
*************************************************************************/
size_t DbiInOutData::getDataSize()
{
    if (this->m_allocSize != 0)
    {
        return this->m_allocSize;
    }

    return DBA_GetDataSizeFromDynFldData(this->m_dataType, this->m_dynFldSt.data);
}

/************************************************************************
*   Function             :  DbiInOutData:setCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-41612 - LJE - 200914
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::setCharPtr(const char *newParamStr)
{
#ifdef AAATRACEDYNFLD
    if (this->getAllocSize() <= strlen(newParamStr))
    {
        SYS_BreakOnDebug();
    }
#endif

    SET_STRING(this->getDynFldStp(), 0, newParamStr);
    this->setPtrToFree(this->getDynFldStp()->data.strData.ptr);
}

/************************************************************************
*   Function             :  DbiInOutData:getCharPtr()
*
*   Description :
    *
    *   Arguments :
    *
    *   Return :
    *
    *   Creation Date : PMSTA - 37366 - LJE - 200302
    *
    *   Last Modification :
*
*************************************************************************/
const char *DbiInOutData::getCharPtr()
{
    return this->getDataPtr()->strData.ptr;
}

/************************************************************************
*   Function             :  DbiInOutData:setUCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-41612 - LJE - 200914
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::setUCharPtr(const UChar *newParamStr)
{
    SET_USTRING(this->getDynFldStp(), 0, newParamStr);
    this->setPtrToFree(this->getDynFldStp()->data.ustrData.ptr);
}

/************************************************************************
*   Function             :  DbiInOutData:getUCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200302
*
*   Last Modification    :
*
*************************************************************************/
const UChar *DbiInOutData::getUCharPtr()
{
    return this->getDataPtr()->ustrData.ptr;
}

/************************************************************************
*   Function             :  DbiInOutData:isNull()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190507
*
*   Last Modification    :
*
*************************************************************************/
bool DbiInOutData::isNull()
{
    return this->m_nullInd == DBI_NULLDATA;
}

/************************************************************************
*   Function             :  DbiInOutData:updOutputData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190918
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::updOutputData()
{
    if (this->m_bOutput &&
        this->m_outputDynFldStp != nullptr)
    {
        if (GET_CTYPE(this->m_dynFldSt.dataType) != GET_CTYPE(this->m_outputDynFldStp[0].dataType))
        {
            SYS_BreakOnDebug();
        }

        if (IS_NULLFLD(&this->m_dynFldSt, 0) == FALSE)
        {
            SET_NOTNULLFLG_T(this->m_outputDynFldStp, 0);

            switch (GET_CTYPE(this->m_dynFldSt.dataType))
            {
                case DoubleCType:
                case IntCType:
                case UIntCType:
                case ShortCType:
                case UCharCType:
                case UShortCType:
                case DateTimeStCType:
                case LongLongCType:
                case TimeStampCType:
                case BinaryCType:
                    this->m_outputDynFldStp[0].data = this->m_dynFldSt.data;
                    break;

                case CharPtrCType:
                case TextPtrCType:
                    SET_STRING(this->m_outputDynFldStp, 0, GET_STRING(&this->m_dynFldSt, 0));
                    break;

                case UniCharPtrCType:
                case UniTextPtrCType:
                    SET_USTRING(this->m_outputDynFldStp, 0, GET_USTRING(&this->m_dynFldSt, 0));
                    break;

                case ArrayPtrCType:
                case MultiArrayPtrCType:
                case VarCharPtrCType:
                case VarTextPtrCType:
                case ExtPtrCType:
                case PtrCType:
                default:
                    assert(this->m_dynFldSt.dataType == LastCtype);
            }
        }
        else
        {
            SET_NULL(this->m_outputDynFldStp, 0, this->m_outputDynFldStp[0].dataType);
        }
    }
}

/************************************************************************
*   Function             :  DbiInOutData:clear()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190507
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::clear()
{
    this->m_nullInd = DBI_NULLDATA;
    this->m_outputDynFldStp = nullptr;

    SET_NULL(this->getDynFldStp(), 0, this->m_dataType);
}

/************************************************************************
*   Function             :  DbiInOutData:setPtrToFree()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-43500 - LJE - 210329
*
*   Last Modification    :
*
*************************************************************************/
void DbiInOutData::setPtrToFree(void *ptrToFree)
{
    if (this->m_ptrToFree != nullptr &&
        this->m_ptrToFree != ptrToFree)
    {
        FREE(this->m_ptrToFree);
    }
    this->m_ptrToFree = ptrToFree;
}

/************************************************************************
*   Function             :  RequestHelper:RequestHelper()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::RequestHelper()
    : m_useAlternativeDataServer(false)
    , m_dbiConn(nullptr)
    , m_bKeepConnectProps(false)
    , m_localConnectionHelper(AAATransactionEnum::NotTransactionnal)
    , m_batchPos(0)
    , m_batchBlock(0)
    , m_bApplyDV(false)
    , m_bApplyIC(false)
    , m_bFlushStat(false)
    , m_outSubscriptionTab(nullptr)
    , m_outSubscriptionNbr(0)
    , m_oldRecordStp(nullptr)
    , m_previousAction(NullAction)
    , m_lastStatus(0)
    , m_lastRetCode(RET_SUCCEED)
    , m_bSendDone(false)
    , m_bFetchStarted(false)
    , m_bFetchDone(false)
    , m_bMsgPrinted(false)
    , m_bReadOnly(false)
    , m_bDdlGen(false)
    , m_fetchSize(0)
    , m_procedureStp(nullptr)
    , m_targetTableEn(TargetTable_Main)
    , m_bInsertMain(false)
    , m_bInsertUd(false)
    , m_entityNatEn(EntityNat_All)
    , m_paramDynStEn(NullDynSt)
    , m_paramDataStp(nullptr)
    , m_paramPos(0)
    , m_outputDynStEn(NullDynSt)
    , m_defOutDataStp(nullptr)
    , m_previousExternalMsgManagement(false)
    , m_managemInsertIdentity(false)
    , m_batchObjEn(NullEntity)
    , m_batchMode(DbiConnection::BatchMode::TryAndRetryRowByRow)
    , m_transactionMode(TransactionMode::AllOrNothing)
    , m_bOverFlow(false)
    , m_bBatchASync(false)
    , m_parallel(1)
    , m_threadNb(0)
    , m_batchThreadPoolPtr(nullptr)
    , m_batchRetCode(RET_SUCCEED)
    , m_bOptimDataAlloc(false)
    , m_bUseNativeQuery(false)
    , m_bSubRequestHelper(false)
    , m_currCharSet(CurrentCharsetCode_IsNull)
    , m_currUChar(nullptr)
    , m_currChar(nullptr)
    , m_currUCharSize(0)
{
    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &this->m_currCharSet);
}

/************************************************************************
*   Function             :  RequestHelper:RequestHelper()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::RequestHelper(DbiConnection *dbiConn, bool bKeepConnectProps)
    : RequestHelper()
{
    this->m_dbiConn            = dbiConn;
    this->m_bKeepConnectProps = bKeepConnectProps;

    if (this->m_dbiConn == nullptr)
    {
        if (this->m_localConnectionHelper.isValidAndInit() == false ||
            (this->m_dbiConn = this->m_localConnectionHelper.getConnection()) == nullptr)
        {
            throw AAAPoolUsageException("Login failed");
        }
    }

    this->init();
}

/************************************************************************
*   Function             :  RequestHelper:RequestHelper()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::RequestHelper(DbiConnectionHelper &dbiConnHelper)
    : RequestHelper()
{
    if (dbiConnHelper.isValidAndInit() == false ||
        (this->m_dbiConn = dbiConnHelper.getConnection()) == nullptr)
    {
        throw AAAPoolUsageException("Login failed");
    }

    this->init();

    /* If a maximum rows number is specified */
    if (dbiConnHelper.dbaGetSelectMaxRows() != UNUSED)
    {
        DBA_SetConnMaxRows(*this->m_dbiConn, dbiConnHelper.dbaGetSelectMaxRows());
    }
}

/************************************************************************
*   Function             :  RequestHelper:RequestHelper()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::RequestHelper(RequestHelper* requestHelperPtr, const std::vector< DBA_DYNFLD_STP>& recordsForBatch)
    : RequestHelper()
{
    this->setBatchBlockSize(requestHelperPtr->getBatchBlockSize());
    this->setBatchMode(requestHelperPtr->getBatchMode());
    this->setTransactionMode(requestHelperPtr->getTransactionMode());
    this->m_bOptimDataAlloc   = requestHelperPtr->m_bOptimDataAlloc;
    this->m_bSubRequestHelper = true;

    requestHelperPtr->getParallelRecords(this);

    if (this->m_localConnectionHelper.isValidAndInit() == false ||
        (this->m_dbiConn = this->m_localConnectionHelper.getConnection()) == nullptr)
    {
        throw AAAPoolUsageException("Login failed");
    }

    if (requestHelperPtr->m_dbiConn != nullptr &&
        requestHelperPtr->m_dbiConn->m_insertIdentityOn)
    {
        for (auto& identityIt : requestHelperPtr->m_dbiConn->m_disableIdentitySet)
        {
            this->m_dbiConn->disableIdentity(identityIt.first, identityIt.second);
        }

        this->m_dbiConn->m_insertIdentityOn = true;
        this->m_managemInsertIdentity       = true;
    }

    this->m_dbiConn->setBatchBlockSize(this->getBatchBlockSize());

    this->getScriptDdlGenPtr()->getDdlGenContextPtr()->ddlGenAction.m_bOraNologgingHint =
        requestHelperPtr->getScriptDdlGenPtr()->getDdlGenContextPtr()->ddlGenAction.m_bOraNologgingHint;

    this->setBatchInfo(requestHelperPtr->m_targetDbName, requestHelperPtr->m_tableSqlName, requestHelperPtr->m_batchObjEn);
    this->setTargetTable(requestHelperPtr->m_targetTableEn);

    this->m_recordsForBatch = recordsForBatch;
}

/************************************************************************
*   Function             :  RequestHelper:init()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::init()
{
    this->setReadOnly(this->m_dbiConn->isReadOnly());
    this->m_dbiConn->pushSqlRequest(KindOfRequest::RequestHelper);
    this->m_previousExternalMsgManagement = this->m_dbiConn->isExternalMsgManagement();
    this->m_previousDbSqlName             = this->m_dbiConn->getTargetSessionProperties().getDbName();
    this->m_previousDbNameOption          = this->m_dbiConn->m_dbNameOption;

    this->m_previousMsgStructHeaderSt = this->m_dbiConn->m_msgStructHeaderSt;
    this->m_dbiConn->m_msgStructHeaderSt.clear();

    if (this->m_dbiConn->isInTransaction() == true)
    {
        this->m_transactionMode = TransactionMode::External;
    }
}

/************************************************************************
*   Function             :  RequestHelper:~RequestHelper()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::~RequestHelper()
{
    this->free();

    if (this->m_dbiConn != nullptr)
    {
        if (this->m_dbiConn->m_insertIdentityOn && this->m_managemInsertIdentity)
        {
            auto identityIt = this->m_dbiConn->m_disableIdentitySet.begin();
            while (identityIt != this->m_dbiConn->m_disableIdentitySet.end())
            {
                this->m_dbiConn->enableIdentity(identityIt->first, identityIt->second);
                identityIt = this->m_dbiConn->m_disableIdentitySet.begin();
            }

            this->m_dbiConn->m_insertIdentityOn = false;
        }

        this->m_dbiConn->setExternalMsgManagement(this->m_previousExternalMsgManagement);

        for (auto &it : this->m_previousMsgStructHeaderSt.msgStructTab)
        {
            this->m_dbiConn->m_msgStructHeaderSt.msgStructTab.push_back(it);
        }
    }
}

/************************************************************************
*   Function             :  RequestHelper:reset()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::free()
{
    if (this->m_dbiConn != nullptr)
    {
        if (this->m_transactionMode != TransactionMode::External &&
            this->m_dbiConn->isInTransaction())
        {
            if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR ||
                this->m_transactionMode == TransactionMode::MostAsPossible)
            {
                this->m_dbiConn->endTransaction(TRUE);
            }
            else
            {
                this->m_dbiConn->endTransaction(FALSE);
            }
        }

        if ((this->m_bFetchStarted || this->m_bFetchDone || this->m_bSendDone || this->m_batchPos > 0))
        {
            this->m_dbiConn->releaseCommand();
        }
        else
        {
            this->m_dbiConn->sendSqlTrace();
        }

        for (auto it = this->m_onReleaseCommands.begin(); it != this->m_onReleaseCommands.end(); ++it)
        {
            RequestHelper requestHelper(this->m_dbiConn);
            requestHelper.setCommand(*it);
            requestHelper.sendAndGetCommand();
        }
        this->m_onReleaseCommands.clear();
    }

    this->printMsg();

    if (this->m_dbiConn != nullptr)
    {
        this->clearParamData();
        this->clearOutputData();

        this->m_dbiConn->popSqlRequest();

        if (this->m_bKeepConnectProps == false &&
            this->m_previousDbSqlName.empty() == false)
        {
            this->m_dbiConn->setDbName(this->m_previousDbSqlName);
        }

        if (this->m_bKeepConnectProps == false &&
            this->m_previousDbNameOption.empty() == false)
        {
            this->m_dbiConn->m_dbNameOption = this->m_previousDbNameOption;
        }

        DdlGenFromFile* ddlGenFromFilePtr = this->m_dbiConn->getScriptDdlGenPtr();
        if (ddlGenFromFilePtr != nullptr &&
            ddlGenFromFilePtr->getDdlGenContextPtr() != nullptr)
        {
            ddlGenFromFilePtr->getDdlGenContextPtr()->setExtDbiConn(nullptr);
        }
    }
    this->m_lastStatus            = 0;
    this->m_bSendDone             = false;
    this->m_bFetchDone            = false;
    this->m_bFetchStarted         = false;
    this->m_bReadOnly             = false;
    this->m_bDdlGen               = false;
    this->m_fetchSize             = 0;

    this->m_procedureStp          = nullptr;
    this->m_targetTableEn         = TargetTable_Main;
    this->m_bInsertMain           = false;
    this->m_bInsertUd             = false;
    this->m_entityNatEn           = EntityNat_All;
    this->m_batchObjEn            = NullEntity;
    this->m_paramDynStEn          = NullDynSt;
    this->m_paramDataStp          = nullptr;
    this->m_paramPos              = 0;

    if (this->m_defOutDataStp != nullptr)
    {
        FREE_DYNST(this->m_defOutDataStp, this->m_outputDynStEn);
    }
    this->m_outputDynStEn         = NullDynSt;

    this->m_requestMp.freeAll();
}

/************************************************************************
*   Function             :  RequestHelper:clearOutputData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::clearOutputData()
{
    this->m_dbiConn->clearRequestOutputVector();
    this->m_dbiConn->clearRequestBindDataVector();
}

/************************************************************************
*   Function             :  RequestHelper:clearParamData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::clearParamData()
{
    this->m_paramDynStEn = NullDynSt;

    this->m_dbiConn->clearRequestParamMap();
}

/************************************************************************
*   Function             :  RequestHelper:setReadOnly()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setReadOnly(bool  bReadOnly)
{
    this->m_bReadOnly = bReadOnly;
}

/************************************************************************
*   Function             :  RequestHelper:setDdlGen()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setDdlGen()
{
    this->m_bDdlGen = true;
    this->setReadOnly(this->m_dbiConn->isDdlGenOnTran() == false);
}

/************************************************************************
*   Function             :  RequestHelper:setFetchSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201026
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setFetchSize(int fetchSize)
{
    this->m_fetchSize = fetchSize;
}

/************************************************************************
*   Function             :  RequestHelper:startProcedureCall()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::startProcedureCall(DBA_PROC_STP procedureStp, DBA_DYNFLD_STP inputDataStp)
{
    try
    {
        this->m_lastRetCode = RET_SUCCEED;

        this->m_dbiConn->reopenOnThreadChange(); /* PMSTA-43741 - LJE - 210304 */

        this->m_procedureStp = procedureStp;
        this->m_paramDataStp = inputDataStp;
        this->m_paramDynStEn = inputDataStp != nullptr ? GET_DYNSTENUM(inputDataStp) : NullDynSt;

        if (this->m_procedureStp->action == Update ||
            this->m_procedureStp->action == Insert)
        {
            DBA_SetMagicDate(this->m_paramDataStp, this->m_paramDataStp->getDynStEn(), this->m_paramDataStp->getObjectEn());
        }

        /* PMSTA-49178 - LJE - 221018 */
        if ((this->m_procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM)
        {
            auto inputEntityStp = this->m_paramDataStp->getDictEntityStp();
            if (inputEntityStp != nullptr)
            {
                std::string tableSqlName = "pp_";
                tableSqlName += inputEntityStp->mdSqlName;

                if ((this->m_recordsForBatch.empty() || this->m_batchMode == DbiConnection::BatchMode::RowByRow))
                {
                    auto createTempTable = DBA_GetCreateTempTables(inputEntityStp->mdSqlName, this->m_dbiConn->m_connectToRDBMS);
                    createTempTable += "truncate table " + tableSqlName + ";";
                    createTempTable += "create temporary table if not exists #batch_output (row_num_n numeric(10,0) null, id bigint null , row_version numeric(20,0) null);";
                    createTempTable += "grant all on #batch_output to triplea_owner;";
                    RequestHelper requestHelper(this->m_dbiConn);
                    requestHelper.setCommand(createTempTable);
                    requestHelper.sendAndGetCommand();
                    requestHelper.finishRequest();

                    requestHelper.setBatchInfo(std::string(), tableSqlName, this->m_paramDataStp->getObjectEn());
                    requestHelper.setTargetTable(TargetTable_Main);

                    this->m_dbiConn->setCurrProcedure(this->m_procedureStp);

                    this->m_dbiConn->m_insertIdentityOn = true;
                    requestHelper.setNewRecordForBatch(this->m_paramDataStp);
                    requestHelper.executeBatch();
                    this->m_dbiConn->m_insertIdentityOn = false;
                }
            }
        }

        this->m_dbiConn->setReadOnly(this->m_procedureStp);
        this->setReadOnly(this->m_dbiConn->isReadOnly());

        DBA_SetTimeout(this->m_procedureStp, this->m_dbiConn);

        this->m_dbiConn->initRequest(this->m_procedureStp->action, true);
        this->m_dbiConn->startRequest();
        this->clearParamData();
        this->m_dbiConn->setCurrProcedure(this->m_procedureStp);

        this->m_dbiConn->setDefaultReadOnly(this->m_procedureStp, this);

        this->m_paramPos = 0;

        if (this->m_procedureStp->procParamDefPtr != nullptr)
        {
            int paramPos = 0;
            while (this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr != UNUSED)
            {
                bool bOutput = (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output ||
                                this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output_Indexed);
                bool bInput = (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Input ||
                               this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Input_NoCheck);

                if (bInput || bOutput)
                {
                    this->setOneDynFldParam(this->m_paramDataStp,
                                            *(this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr),
                                            paramPos,
                                            NullDataType,
                                            true,
                                            bOutput,
                                            false,
                                            this->m_procedureStp->procParamDefPtr[paramPos].paramName,
                                            (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output_Indexed ? this->m_procedureStp->procParamDefPtr[paramPos].outputFldNbrPtr : nullptr),
                                            (this->m_procedureStp->action == Insert ||
                                             this->m_procedureStp->action == Update ||
                                             this->m_procedureStp->action == InsUpd) ? true : false);   /* PMSTA-42378 - DDV - 201109 - Set default_c on parameters only when action is Insert, Update or InsUpd */

                    /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
                    if (this->m_lastRetCode != RET_SUCCEED)
                    {
                        auto &msgStructSt = this->m_dbiConn->m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                        msgStructSt.techMsg = FALSE;
                        msgStructSt.retCode = RET_DBA_ERR_SETPARAM;
                        msgStructSt.msgString = SYS_Stringer("Arithmetic overflow occurred on attribute ", this->m_procedureStp->procParamDefPtr[paramPos].paramName);
                        this->m_dbiConn->m_lastResultRetCode = RET_DBA_ERR_SETPARAM;
                        return(false);
                    }
                }
                paramPos++;
            }
        }

        std::stringstream sqlQueryStream;

        sqlQueryStream << "#EXEC " << this->m_procedureStp->procName;
        for (size_t i = 0; i < this->m_dbiConn->getRequestParamMap().size(); i++)
        {
            if (i)
            {
                sqlQueryStream << ",";
            }
            sqlQueryStream << " ?";
        }

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->m_dbiConn->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Rpc;
            sqlTrace.m_procedure = procedureStp->procName;
        }

        this->setCommand(sqlQueryStream.str());

        this->m_lastRetCode = this->sendCommandForFetch();

        if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR &&                      /* PMSTA-37366 - LJE - 201103 */
            (*procedureStp->outputDynStPtr) == NullDynSt &&
            procedureStp->multiOutputDynStPtr == nullptr)
        {
            this->m_paramDynStEn = inputDataStp != nullptr ? GET_DYNSTENUM(inputDataStp) : NullDynSt;

            if (this->m_paramDynStEn != NullDynSt)
            {
                this->m_lastRetCode = this->m_dbiConn->processAllResults(&this->m_lastStatus,
                                                                         GET_OBJ_DYNST(this->m_paramDynStEn),
                                                                         this->m_paramDynStEn,
                                                                         this->m_paramDataStp,
                                                                         this->m_procedureStp);
            }
        }

        /* PMSTA-55439 - LJE - 240305 */
        this->m_dbiConn->getOutboxManager().addRecord(this->m_paramDataStp, this->m_procedureStp);
    }
    catch (...)
    {
        this->m_lastRetCode = RET_DBA_ERR_DBPROBLEM;
    }

    if (this->m_lastRetCode != RET_SUCCEED ||
        this->getLastResultType() != DBI_ROW_RESULT)
    {
        this->printMsg();
    }

    return (this->m_lastRetCode == RET_SUCCEED);
}

/************************************************************************
*   Function             :  RequestHelper:finishRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::finishRequest()
{
    this->free();

    if (this->m_dbiConn)
    {
        this->m_dbiConn->pushSqlRequest(KindOfRequest::RequestHelper);
    }
}

/************************************************************************
*   Function             :  RequestHelper:setCommand()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setCommand(const std::string &sqlCmd)
{
    if (this->m_dbiConn->m_connectToRDBMS != QtHttp &&
        sqlCmd.find("#") != std::string::npos)
    {
        std::string bufferString(sqlCmd);
        auto ddlGenFromFilePtr = this->m_dbiConn->getScriptDdlGenPtr();

        ddlGenFromFilePtr->m_bSendRequestWithProc = false;
        ddlGenFromFilePtr->m_lastPhysicalTable.clear();

        auto ddlGenContextPtr = ddlGenFromFilePtr->getDdlGenContextPtr();
        DdlGenConnGuard ddlGenConnGuard(*ddlGenContextPtr);

        ddlGenContextPtr->m_useAlternativeDataServer = this->m_useAlternativeDataServer;
        ddlGenContextPtr->setDefDdlDestDbName(this->m_dbiConn->getTargetSessionProperties().getDbName());
        ddlGenContextPtr->setExtDbiConn(this->m_dbiConn);           /* PMSTA-37366 - LJE - 210208 */
        ddlGenContextPtr->m_inputVariableVector.clear();
        ddlGenContextPtr->m_outputVariableVector.clear();

        if (ddlGenFromFilePtr->m_bSendRequestWithProc)
        {
            DdlGen ddlGen(Empty,
                          TargetTable_Main,
                          *ddlGenFromFilePtr);

            auto now = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
            std::string tmpProcName(SYS_Stringer("tmp_proc_", now));

            std::string dropProcCmd = ddlGen.getCmdIfExsists(ddlGen.getCmdSelObjInDb(this->m_dbiConn->getActualDbName(), ddlGen.getEntitySqlName(), tmpProcName, DdlObj_SProc),
                                                             "\t" + ddlGen.getDdlModif(ddlGen.getCmdDrop(this->m_dbiConn->getActualDbName(), ddlGen.getEntitySqlName(), tmpProcName, DdlObj_SProc)),
                                                             std::string());

            ddlGen.bodySqlBlock << dropProcCmd;
            ddlGen.cmdType = DDlCmdType_Drop;
            (void)ddlGen.flush();

            ddlGen.bodySqlBlock << ddlGen.getCmdCreate(this->m_dbiConn->getActualDbName(),
                                                       ddlGen.getEntitySqlName(),
                                                       tmpProcName,
                                                       DdlObj_SProc);
            ddlGen.printBeginProc(ddlGen.bodySqlBlock.bodyStream(), nullptr);

            ddlGen.bodySqlBlock << bufferString;
            ddlGen.bodySqlBlock << std::endl << "end" << ddlGen.getCmdEndOfCmd() << std::endl;
            ddlGen.cmdType = DDlCmdType_Create;
            (void)ddlGen.flush();

            this->m_dbiConn->getRequest() = "exec " + tmpProcName;

            this->m_onReleaseCommands.push_back(dropProcCmd);
        }
        else
        {
            if (this->m_dbiConn->m_connectToRDBMS == Sqlite)
            {
                this->m_dbiConn->getTargetSessionProperties().setDbName(ddlGenFromFilePtr->getDdlGenContextPtr()->getDdlDestDbName());
                if (ddlGenFromFilePtr->m_lastPhysicalTable.empty() == false)
                {
                    this->setDbNameOption(ddlGenFromFilePtr->m_lastPhysicalTable);
                }
            }
            this->m_dbiConn->getRequest() = bufferString;
        }
        ddlGenFromFilePtr->context->m_parentDictEntity = this->m_dbiConn->m_parentDictEntity;
        ddlGenFromFilePtr->context->m_paramVectorVector.push_back(this->m_dbiConn->getRequestParamMap());
        {
            RequestHelper requestHelper(this->m_dbiConn); /* To push/pop the current request on connection before script analysis */
            DdlGenDbi::convertSqlBlock(bufferString, ddlGenFromFilePtr);
        }
        ddlGenFromFilePtr->context->m_paramVectorVector.pop_back();

        this->m_dbiConn->getRequest() = bufferString;
    }
    else
    {
        this->m_dbiConn->getRequest() = sqlCmd;
    }
}

/************************************************************************
*   Function             :  RequestHelper:isConnection()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200609
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::isConnection(DbiConnection *dbiConnToCheck)
{
    if (dbiConnToCheck != nullptr &&
        this->m_dbiConn != nullptr &&
        this->m_dbiConn == dbiConnToCheck)
    {
        return true;
    }
    return false;
}


/************************************************************************
*   Function             :  RequestHelper:getDbiConn()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 230911
*
*   Last Modification    :
*
*************************************************************************/
DbiConnection& RequestHelper::getDbiConn()
{
    return *this->m_dbiConn;
}

/************************************************************************
*   Function             :  RequestHelper:sendAndGetCommand()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::sendAndGetCommand()
{
    AAAValueGuard<bool> oneRecordExpected(this->m_dbiConn->m_oneRecordExpected, true);

    (void)this->sendCommandForFetch();

    if (this->m_lastRetCode == RET_SUCCEED)
    {
        (void)this->fetch();

        if (this->m_dbiConn->m_lastResultType != 0 &&
            this->m_dbiConn->m_lastResultType != DBI_CMD_FAIL)
        {
            while (this->fetch() == RET_SUCCEED)
            {
            }
        }
    }

    if (this->m_lastRetCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        this->m_lastRetCode = RET_SUCCEED;
    }

    if (this->m_lastRetCode != RET_SUCCEED &&
        (this->m_lastRetCode == RET_SRV_LIB_ERR_DEADLOCK ||
         this->m_lastRetCode == RET_SRV_LIB_ERR_SYNTAX ||
         this->m_lastRetCode == RET_DBA_ERR_CONNLOST ||
         this->m_lastRetCode == RET_SRV_LIB_ERR_CONNLOST_AND_WAIT))
    {
        (void)this->sendCommandForFetch();

        if (this->m_lastRetCode == RET_SUCCEED)
        {
            (void)this->fetch();

            if (this->m_dbiConn->m_lastResultType != 0 &&
                this->m_dbiConn->m_lastResultType != DBI_CMD_FAIL)
            {
                while (this->fetch() == RET_SUCCEED)
                {
                }
            }
        }

        if (this->m_lastRetCode == RET_DBA_INFO_NO_MORE_DATA)
        {
            this->m_lastRetCode = RET_SUCCEED;
        }
    }

    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:sendCommandForFetch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::sendCommandForFetch()
{
    this->m_bMsgPrinted = false;

    if (this->m_dbiConn->getRequest().empty() == false)
    {
        this->m_dbiConn->setReadOnly(this->m_bReadOnly);
        this->m_dbiConn->setFetchSize(this->m_fetchSize);

        if (this->m_dbiConn->isInTransaction() == false &&
            this->m_dbiConn->isReadOnly()      == false &&
            this->m_dbiConn->isAutoCommit()    == false &&
            (this->m_bDdlGen == false || this->m_dbiConn->isDdlGenOnTran()))
        {
            this->m_dbiConn->beginTransaction(true);
        }

        this->m_lastRetCode = this->m_dbiConn->sendCommand();
        this->m_bSendDone   = true;

        if ((this->m_lastRetCode == RET_SUCCEED ||
             this->m_lastRetCode == RET_DBA_INFO_NO_MORE_DATA) &&
            this->getLastResultType() != DBI_ROW_RESULT)
        {
            if (this->getLastResultType() == DBI_CMD_SUCCEED ||
                this->getLastResultType() == DBI_STATUS_RESULT ||
                this->getLastResultType() == DBI_PARAM_RESULT)
            {
                DBI_INT  status = 0;

                /* PMSTA-37374 - LJE - 201214 - Try to get a result-set */
                this->m_dbiConn->processAllResults(&status);
            }

            if (this->getLastResultType() != DBI_ROW_RESULT)
            {
                this->m_lastRetCode = RET_DBA_INFO_NO_MORE_DATA;
            }
        }
        else if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
        {
            if (this->m_dbiConn->isAutoTransaction() == false)
            {
                if (this->m_lastRetCode == RET_DBA_ERR_WITH_COMMIT)
                {
                    this->m_dbiConn->endTransaction(TRUE);
                    this->m_lastRetCode = RET_DBA_ERR_DBPROBLEM;
                }
                else
                {
                    this->m_dbiConn->endTransaction(FALSE);
                }
            }
            this->printMsg();
        }

        return this->m_lastRetCode;
    }
    return (this->m_lastRetCode = RET_DBA_INFO_NODATA);
}

/************************************************************************
*   Function             :  RequestHelper:startProcedureCallForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::startProcedureCallForBatch(DBA_PROC_STP procedureStp)
{
    this->m_lastRetCode = RET_SUCCEED;

    if (this->m_procedureStp != nullptr &&
        this->m_procedureStp != procedureStp)
    {
        this->executeBatch();
        if (this->m_lastRetCode != RET_SUCCEED)
            return false;
    }

    this->m_procedureStp = procedureStp;
    if (this->m_procedureStp == nullptr)
    {
        return false;
    }

    return true;
}

/************************************************************************
*   Function             :  RequestHelper:startProcedureCallForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::startProcedureCallForBatch(DBA_ACTION_ENUM action,
                                               OBJECT_ENUM     object,
                                               int             role,
                                               DBA_DYNFLD_STP  inputData)
{
    if (this->m_procedureStp == nullptr)
    {
        DBA_PROC_STP procedureStp = DBA_GetStoredProcs(action,
                                                       object,
                                                       role,
                                                       inputData->getDynStEn(),
                                                       inputData,
                                                       NullDynSt);
        if (procedureStp != nullptr)
        {
            return this->startProcedureCallForBatch(procedureStp);
        }

        return false;
    }

    return true;
}

/************************************************************************
*   Function             :  RequestHelper:addProcedureCallForBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::addProcedureCallForBatchMulti(DBA_ACTION_ENUM action,
                                                  OBJECT_ENUM     object,
                                                  int             role,
                                                  DBA_DYNFLD_STP  inputData,
                                                  size_t          batchRank)
{
    DBA_PROC_STP procedureStp = DBA_GetStoredProcs(action,
                                                   object,
                                                   role,
                                                   GET_DYNSTENUM(inputData),
                                                   inputData,
                                                   NullDynSt);
    if (procedureStp == nullptr &&
        action == Delete &&
        inputData->isAllDynSt())
    {
        auto shInputDataStp = this->m_globalMp.allocDynst(FILEINFO, GET_ADMINGUIST(inputData->getObjectEn()));
        CONVERT_DYNST(shInputDataStp, shInputDataStp->getDynStEn(), inputData, inputData->getDynStEn());

        return this->addProcedureCallForBatchMulti(action,
                                                   object,
                                                   role,
                                                   shInputDataStp,
                                                   batchRank);
    }

    if (procedureStp != nullptr)
    {
        /* PMSTA-45413 - LJE - 210617 */
        if (procedureStp->server == InternalProc)
        {
            procedureStp = nullptr;

            if (role == UNUSED)
            {
                procedureStp = DBA_GetStoredProcs(action,
                                                  object,
                                                  DBA_ROLE_DB_ACCESS,
                                                  GET_DYNSTENUM(inputData),
                                                  inputData,
                                                  NullDynSt);
            }
            else if (role == DBA_ROLE_UDT || role == DBA_ROLE_STATUS)
            {
                procedureStp = DBA_GetStoredProcs(action,
                                                  object,
                                                  DBA_ROLE_DB_STATUS,
                                                  GET_DYNSTENUM(inputData),
                                                  inputData,
                                                  NullDynSt);
            }
            else if (role == DBA_ROLE_IMPORT_USR_MD)
            {
                procedureStp = DBA_GetStoredProcs(action,
                                                  object,
                                                  DBA_ROLE_DB_ACCESS_USR,
                                                  GET_DYNSTENUM(inputData),
                                                  inputData,
                                                  NullDynSt);
            }
            else
            {
                procedureStp = DBA_GetStoredProcs(action,
                                                  object,
                                                  role + DBA_ROLE_DB_ACCESS_FACTOR,
                                                  GET_DYNSTENUM(inputData),
                                                  inputData,
                                                  NullDynSt);
            }

            if (procedureStp == nullptr)
            {
                DbiConnectionHelper dbiConnHelper(this->m_dbiConn);

                if (this->getTransactionMode() == RequestHelper::TransactionMode::AllOrNothing &&
                    this->m_dbiConn->isInTransaction() == false)
                {
                    this->setTransactionMode(RequestHelper::TransactionMode::External);
                    this->m_dbiConn->beginTransaction();
                }

                switch (action)
                {
                    case Insert:
                        if ((this->m_lastRetCode = dbiConnHelper.dbaInsert(object, role, inputData)) == RET_SUCCEED)
                        {
                            return true;
                        }
                        return false;

                    case Update:
                        if ((this->m_lastRetCode = dbiConnHelper.dbaUpdate(object, role, inputData)) == RET_SUCCEED)
                        {
                            return true;
                        }
                        return false;

                    case Delete:
                        if ((this->m_lastRetCode = dbiConnHelper.dbaDelete(object, role, inputData)) == RET_SUCCEED)
                        {
                            return true;
                        }
                        return false;
                }
            }

            if (procedureStp == nullptr)
            {
                SYS_BreakOnDebug();
            }
        }

        auto &batchRecordMap = this->m_batchRecordMultiMap[batchRank];
        auto &batchRecordVec = batchRecordMap[procedureStp];
        batchRecordVec.push_back(inputData);

        return true;
    }
    else
    {
        SYS_BreakOnDebug();
    }
    return false;
}

/************************************************************************
*   Function             :  RequestHelper:setCopyIdForBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200228
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setCopyIdForBatchMulti(size_t         batchRankBefore,
                                           DBA_DYNFLD_STP targetDynStp,
                                           FIELD_IDX_T    targetFldIdx,
                                           DBA_DYNFLD_STP srcDynStp,
                                           FIELD_IDX_T    srcFldIdx)
{
    COPY_DYNFLD(targetDynStp, targetDynStp->getDynStEn(), targetFldIdx, srcDynStp, srcDynStp->getDynStEn(), srcFldIdx);

    this->m_batchToCopyMap[batchRankBefore].push_back(CopyInfo(targetDynStp, targetFldIdx, srcDynStp, srcFldIdx));
}

/************************************************************************
*   Function             :  RequestHelper:setCopyIdForBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200228
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setCopyIdForBatchMulti(ID_T *idPtr, DBA_DYNFLD_STP srcDynStp, FIELD_IDX_T srcFldIdx, size_t batchRankAfter)
{
    *idPtr = GET_ID(srcDynStp, srcFldIdx);

    this->m_batchToCopyIdMap[batchRankAfter][&(srcDynStp[srcFldIdx])] = idPtr;
}

/************************************************************************
*   Function             :  RequestHelper:setBatchMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setBatchMode(DbiConnection::BatchMode batchMode)
{
    this->m_batchMode = batchMode;
}

/************************************************************************
*   Function             :  RequestHelper:getBatchMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
DbiConnection::BatchMode RequestHelper::getBatchMode()
{
    return this->m_batchMode;
}

/************************************************************************
*   Function             :  RequestHelper:setTransactionMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setTransactionMode(TransactionMode transactionMode)
{
    this->m_transactionMode = transactionMode;
}

/************************************************************************
*   Function             :  RequestHelper:getTransactionMode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-33082 - DDV - 210311
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::TransactionMode RequestHelper::getTransactionMode(void)
{
    return(this->m_transactionMode);
}

/************************************************************************
*   Function             :  RequestHelper:sendCommandForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::prepareStatementForBatch()
{
    if (this->m_recordsForBatch.empty() == false)
    {
        this->m_bMsgPrinted = false;

        std::stringstream sqlQueryStream;
        bool         bSqlTrace = false;

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            DbiSqlTrace *sqlTrace = &(this->m_dbiConn->getSqlTrace());
            sqlTrace->m_logLevel = AAALogger::Level::Warn;
            sqlTrace->m_mode = DbiSqlTrace::Mode::Rpc;
            sqlTrace->m_command = "executeBatch";
            sqlTrace->m_fmtRowNbr = static_cast<int>(this->m_recordsForBatch.size());

            bSqlTrace = true;
        }

        this->m_dbiConn->setBatchMode(this->m_batchMode);

        if (this->m_transactionMode != TransactionMode::External &&
            this->m_batchMode != DbiConnection::BatchMode::TryBCP &&
            this->m_dbiConn->isInTransaction() == false)
        {
            this->m_dbiConn->beginTransaction();
        }

        this->m_dbiConn->startRequest();

        if (this->m_procedureStp == nullptr)
        {
            if (this->m_batchObjEn == NullEntity &&
                (this->m_paramDynStEn == NullDynSt ||
                 this->m_paramDynStEn == InvalidDynSt))
            {
                this->useDb(this->m_targetDbName);

                sqlQueryStream << "insert into " << this->m_targetDbName << DdlGenDbi::getCmdDbAccess(this->m_dbiConn->getDbaRDBMS()) << this->m_tableSqlName;
                std::stringstream valuesStream;

                std::map<FIELD_IDX_T, std::string> nameMap;

                bool bName  = true;
                bool bFirst = true;

                for (auto &it : this->m_colInfoVector)
                {
                    if (it.m_isDb)
                    {
                        if (bFirst)
                        {
                            bFirst = false;
                        }
                        else
                        {
                            valuesStream << ", ";
                        }
                        if (it.m_columnName.empty())
                        {
                            bName = false;
                        }
                        else if (bName)
                        {
                            nameMap[it.m_columnPos] = it.m_columnName;
                        }
                        valuesStream << "?";
                    }
                }

                if (bName)
                {
                    bFirst = true;
                    sqlQueryStream << " (";

                    for (auto& it : nameMap)
                    {
                        if (bFirst)
                        {
                            bFirst = false;
                        }
                        else
                        {
                            sqlQueryStream << ", ";
                        }
                        sqlQueryStream << it.second;
                    }

                    sqlQueryStream << ")";
                }
                this->m_dbiConn->getColInfoVector() = this->m_colInfoVector;

                sqlQueryStream << " values (" << valuesStream.str() << ")";
            }
            else
            {
                OBJECT_ENUM     objectEn = (this->m_batchObjEn != NullEntity ? this->m_batchObjEn : GET_OBJ_DYNST(this->m_paramDynStEn));
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

                if (this->m_paramDynStEn == NullDynSt ||
                    this->m_paramDynStEn == InvalidDynSt)
                {
                    this->m_paramDynStEn = GET_EDITGUIST(objectEn);
                }
                if (this->m_targetDbName.empty() == false)
                {
                    this->useDb(this->m_targetDbName);
                }

                if (this->m_targetTableEn == TargetTable_Main)
                {
                    if (this->m_tableSqlName.empty())
                    {
                        this->m_bInsertMain = dictEntityStp->isPhysicalEntity(TargetTable_Main);
                    }
                    else
                    {
                        this->m_bInsertMain = true;
                    }
                }
                else if (this->m_targetTableEn == TargetTable_UserDefinedFields)
                {
                    this->m_bInsertUd = dictEntityStp->isPhysicalEntity(TargetTable_UserDefinedFields);
                }

                sqlQueryStream
                    << "#NO_MULTI_ENTITY";

                if (this->m_bInsertMain)
                {
                    sqlQueryStream
                        << std::endl << "#INSERT " << dictEntityStp->mdSqlName << " full std " << (this->m_tableSqlName == dictEntityStp->dbSqlName ? "" : this->m_tableSqlName)
                        << std::endl << "#VALUES"
                        << std::endl << "#END";
                }
                else if (this->m_bInsertUd)
                {
                    sqlQueryStream
                        << std::endl << "#INSERT " << dictEntityStp->mdSqlName << " udf std "
                        << std::endl << "#VALUES"
                        << std::endl << "#END";
                }
            }

            this->setCommand(sqlQueryStream.str());

            if (bSqlTrace)
            {
                DbiSqlTrace* sqlTrace = &(this->m_dbiConn->getSqlTrace());
                sqlTrace->m_procedure = "insert";
            }
        }
        else if (this->m_bUseNativeQuery)
        {
            OBJECT_ENUM     objectEn = GET_OBJ_DYNST(*this->m_procedureStp->inputDynStPtr);
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

            if (this->m_targetDbName.empty() == false)
            {
                this->useDb(this->m_targetDbName);
            }

            sqlQueryStream
                << "#NO_MULTI_ENTITY";

            if (this->m_procedureStp->action == Insert)
            {
                if (this->m_procedureStp->subObj == DBA_ROLE_DB_STATUS)
                {
                    sqlQueryStream
                        << std::endl << "#INSERT " << dictEntityStp->mdSqlName << " null";

                    int paramPos = 0;
                    while (this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr != UNUSED)
                    {
                        auto attripStp = dictEntityStp->getDictAttribBySqlName(&(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1]));

                        if (attripStp != nullptr &&
                            (attripStp->primFlg == FALSE || attripStp->dictEntityStp->pkRuleEn != PkRule_Identity))
                        {
                            sqlQueryStream
                                << std::endl << &(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1]);
                        }
                        paramPos++;
                    }

                    sqlQueryStream
                        << std::endl << "#VALUES"
                        << std::endl << "#IDENTITY"
                        << std::endl << "#END";
                }
                else
                {
                    sqlQueryStream
                        << std::endl << "#INSERT " << dictEntityStp->mdSqlName << " all_db"
                        << std::endl << "#VALUES"
                        << std::endl << "#IDENTITY"
                        << std::endl << "#END";
                }

                if (bSqlTrace)
                {
                    DbiSqlTrace* sqlTrace = &(this->m_dbiConn->getSqlTrace());
                    sqlTrace->m_procedure = "insert";
                }
            }
            else if (this->m_procedureStp->action == Update)
            {
                sqlQueryStream
                    << std::endl << "#UPDATE " << dictEntityStp->mdSqlName << " null";

                int paramPos = 0;
                while (this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr != UNUSED)
                {
                    auto attripStp = dictEntityStp->getDictAttribBySqlName(&(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1]));

                    if (attripStp != nullptr && attripStp->primFlg == FALSE)
                    {
                        sqlQueryStream
                            << std::endl << &(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1])
                            << " = " << &(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1]);
                    }
                    paramPos++;
                }

                sqlQueryStream
                    << std::endl << "#WHERE"
                    << std::endl << "pk"
                    << std::endl << "#END";

                if (bSqlTrace)
                {
                    DbiSqlTrace* sqlTrace = &(this->m_dbiConn->getSqlTrace());
                    sqlTrace->m_procedure = "Update";
                }

            }
            else if (this->m_procedureStp->action == Delete)
            {
                sqlQueryStream
                    << std::endl << "#DELETE " << dictEntityStp->mdSqlName
                    << std::endl << "#WHERE"
                    << std::endl << "pk"
                    << std::endl << "#END";

                if (bSqlTrace)
                {
                    DbiSqlTrace* sqlTrace = &(this->m_dbiConn->getSqlTrace());
                    sqlTrace->m_procedure = "Delete";
                }

            }

            this->setCommand(sqlQueryStream.str());
        }
        else if ((this->m_procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM)
        {
            OBJECT_ENUM     objectEn      = GET_OBJ_DYNST(*this->m_procedureStp->inputDynStPtr);
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

            if (this->m_targetDbName.empty() == false)
            {
                this->useDb(this->m_targetDbName);
            }

            {
                std::string tableSqlName = "pp_";
                tableSqlName += dictEntityStp->mdSqlName;
                auto createTempTable = DBA_GetCreateTempTables(dictEntityStp->mdSqlName, this->m_dbiConn->m_connectToRDBMS);
                createTempTable += "truncate table " + tableSqlName + ";";
                createTempTable += "create temporary table if not exists #batch_output (row_num_n numeric(10,0) null, id bigint null , row_version numeric(20,0) null);";
                createTempTable += "grant all on #batch_output to triplea_owner;";
                RequestHelper requestHelper(this->m_dbiConn);
                requestHelper.setCommand(createTempTable);
                requestHelper.sendAndGetCommand();
                requestHelper.finishRequest();
            }

            sqlQueryStream
                << "#NO_MULTI_ENTITY" << std::endl
                << "#INSERT " << dictEntityStp->mdSqlName << " full null pp_" << dictEntityStp->mdSqlName << std::endl
                << "#VALUES" << std::endl
                << "#END";

            this->m_bInsertMain = true;
            this->m_dbiConn->m_insertIdentityOn = true;
            this->setCommand(sqlQueryStream.str());
        }
        else
        {
            this->m_paramDynStEn = *this->m_procedureStp->inputDynStPtr;

            sqlQueryStream << "#EXEC " << this->m_procedureStp->procName;
            for (size_t i = 0; this->m_procedureStp->procParamDefPtr[i].fldNbrPtr != nullptr; i++)
            {
                if (i)
                {
                    sqlQueryStream << ",";
                }
                sqlQueryStream << " ?";
            }

            DBA_SetTimeout(this->m_procedureStp, this->m_dbiConn);

            this->m_dbiConn->initRequest(this->m_procedureStp->action, true);
            this->m_dbiConn->setCurrProcedure(this->m_procedureStp);
            this->m_paramPos = 0;

            this->setCommand(sqlQueryStream.str());

            if (bSqlTrace)
            {
                DbiSqlTrace* sqlTrace = &(this->m_dbiConn->getSqlTrace());
                sqlTrace->m_procedure = this->m_procedureStp->procName;
            }
        }

        this->setReadOnly(false);

        if (this->m_dbiConn->getRequest().empty() == false)
        {
            this->m_lastRetCode = this->m_dbiConn->createStatement(this->m_dbiConn->getRequestToSend(), this->m_dbiConn->getCurrentAction());
            this->m_bSendDone = true;

            this->printMsg();

            return this->m_lastRetCode;
        }
    }
    return (this->m_lastRetCode = RET_DBA_INFO_NODATA);
}

/************************************************************************
*   Function             :  RequestHelper:resetBatchBlockSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::resetBatchBlockSize()
{
    this->m_batchBlock = 0;
}

/************************************************************************
*   Function             :  RequestHelper:setBatchBlockSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setBatchBlockSize(unsigned int batchBlock)
{
    this->m_batchBlock = batchBlock;
}

/************************************************************************
*   Function             :  RequestHelper:getBatchBlockSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
unsigned int RequestHelper::getBatchBlockSize()
{
    if (RequestHelper::m_batchBlock == 0)
    {
        this->m_batchBlock = RequestHelper::getDefBatchBlockSize(this->m_dbiConn->getDbaRDBMS());
    }
    return this->m_batchBlock;
}

/************************************************************************
*   Function             :  RequestHelper:getDefBatchBlockSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
unsigned int RequestHelper::getDefBatchBlockSize(DBA_RDBMS_ENUM rdbmsEn)
{
    static unsigned int defBatchBlock = 0;

    if (defBatchBlock == 0)
    {
        defBatchBlock = (rdbmsEn == Sybase ? 500 : 10000);

        if (SYS_IsSrvMode())
        {
            static int commitSz = -1;
            if (commitSz < 0)
            {
                GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);
            }
            if (commitSz > 0)
            {
                defBatchBlock = commitSz;
            }
        }

        defBatchBlock = SYS_GetEnvUnsignedOrDefValue("AAABATCHBLOCKSIZE", defBatchBlock);
    }

    return defBatchBlock;
}

/************************************************************************
*   Function             :  RequestHelper:getBatchSize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
unsigned int RequestHelper::getBatchSize()
{
    return this->m_batchPos;
}

/************************************************************************
*   Function             :  RequestHelper:getNewRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getNewRecordForBatch(DBA_DYNST_ENUM dynStEn, DBA_DYNFLD_STP& newRecordStp)
{
    (void)this->flushBatch(false);

    if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
    {
        this->m_lastRetCode = RET_SUCCEED;
    }

    try
    {
        LockGuard lockGuard(this->m_lock);

        if (this->m_availableRecordsVector.empty() == false)
        {
            newRecordStp = this->m_availableRecordsVector.back();

            if (dynStEn != NullDynSt)
            {
                SET_NULL_DYNST(newRecordStp, dynStEn)
            }
            else
            {
                for (size_t i = 0; i < this->m_colInfoVector.size(); i++)
                {
                    SET_NULL(newRecordStp, CAST_INT(i), newRecordStp[i].dataType);
                }
            }

            this->m_availableRecordsVector.pop_back();
        }
        else
        {
            if (dynStEn == NullDynSt)
            {
                if (this->m_colInfoVector.empty() == false)
                {
                    newRecordStp = this->m_requestMp.allocDynstWithOutDef(FILEINFO, this->m_colInfoVector.size());

                    for (size_t i = 0; i < this->m_colInfoVector.size(); i++)
                    {
                        newRecordStp[i].dataType = static_cast<unsigned char>(this->m_colInfoVector[i].m_dataType);
                        newRecordStp[i].dynStEnum = NullDynSt;
                    }
                }
                else
                {
                    return RET_DBA_ERR_INVDATA;
                }
            }
            else
            {
                newRecordStp = this->m_requestMp.allocDynst(FILEINFO, dynStEn);

                OBJECT_ENUM objectEn = GET_DYNST_ENTITY(dynStEn);

                if (objectEn != NullEntity)
                {
                    DBA_SetDfltEntityFld(objectEn, dynStEn, newRecordStp);
                }
            }
        }

        if (this->m_batchObjEn == NullEntity &&
            this->m_paramDynStEn == NullDynSt)
        {
            this->m_paramDynStEn = dynStEn;
        }

        (void)this->setNewRecordForBatch(newRecordStp);
    }
    catch (...)
    {
        return RET_MEM_ERR_ALLOC;
    }

    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:getNewRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
DBA_DYNFLD_STP RequestHelper::getNewRecordForBatch(DBA_DYNST_ENUM dynStEn)
{
    DBA_DYNFLD_STP newRecordStp = nullptr;
    this->getNewRecordForBatch(dynStEn, newRecordStp);
    return newRecordStp;
}

/************************************************************************
*   Function             :  RequestHelper:setNewRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 191125
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::setNewRecordForBatch(DBA_DYNFLD_STP newRecordStp)
{
    (void)this->flushBatch(false);
    this->m_recordsForBatchInQueue.push_back(newRecordStp);

    if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
    {
        this->m_lastRetCode = RET_SUCCEED;
    }

    if (this->m_batchObjEn == NullEntity &&
        this->m_paramDynStEn == NullDynSt)
    {
        this->m_paramDynStEn = GET_DYNSTENUM(newRecordStp);
    }
    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:removeLastRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-47578 - LJE - 220411
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::removeLastRecordForBatch()
{
    this->m_recordsForBatchInQueue.pop_back();
}

/************************************************************************
*   Function             :  RequestHelper:executeBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setTargetTable(TARGET_TABLE_ENUM targetTableEn)
{
    this->m_targetTableEn = targetTableEn;
}

/************************************************************************
**
**  Function    :   DBA_InsertBatch()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37374 - LJE - 201116
**  Last modif. :
**
*************************************************************************/
void DBA_InsertBatch(ThreadArg *paramBatchInfo)
{
    auto batchInfo = dynamic_cast<RequestHelper::ASyncBatchInfo*>(paramBatchInfo);

    batchInfo->m_retCode = batchInfo->m_requestHelperPtr->realFlushBatch(batchInfo->m_bForceFlush);
}

/************************************************************************
**
**  Function    :   DBA_InsertBatchParallel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-55968 - LJE - 240718
**  Last modif. :
**
*************************************************************************/
void DBA_InsertBatchParallel(ThreadArg* paramBatchInfo)
{
    auto batchInfo = dynamic_cast<RequestHelper::ParallelBatchInfo*>(paramBatchInfo);

    auto writeStartTime = std::chrono::steady_clock::now();

    RequestHelper requestHelper(batchInfo->m_requestHelperPtr, batchInfo->m_recordsForBatch);
    batchInfo->m_retCode = requestHelper.realFlushBatch(batchInfo->m_bForceFlush);

    batchInfo->m_requestHelperPtr->trfRecordForBatch(requestHelper);

    batchInfo->m_writeDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - writeStartTime);
}

/************************************************************************
*   Function             :  RequestHelper:clearRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201119
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::clearRecordForBatch(bool bForceFlush)
{
    if (this->m_bOptimDataAlloc)
    {
        LockGuard lockGuard(this->m_lock);

        for (auto &it : this->m_recordsForBatch)
        {
            this->m_availableRecordsVector.push_back(it);
        }

        for (auto &it : this->m_allDbiInOutDataVector)
        {
            this->m_availableDbiInOutDataMap[it->m_colPos].push_back(it);
        }

    }
    else
    {
        if (bForceFlush == false)
        {
            this->m_requestMp.freeAll();
        }

        for (auto &it : this->m_recordsForBatch)
        {
            this->m_requestMp.freeDynStp(it);
        }
    }
    this->m_recordsForBatch.clear();
    this->m_allDbiInOutDataVector.clear();
}

/************************************************************************
*   Function             :  RequestHelper:getParallelRecords()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::getParallelRecords(RequestHelper* toRequestHelperPtr)
{
    if (toRequestHelperPtr != nullptr && this->m_bOptimDataAlloc)
    {
        LockGuard lockGuard(this->m_lock);

        if (this->m_parallelDbiInOutDataVector.empty() == false)
        {
            for (auto& it : this->m_parallelDbiInOutDataVector.back())
            {
                toRequestHelperPtr->m_availableDbiInOutDataMap[it->m_colPos].push_back(it);
            }
            this->m_parallelDbiInOutDataVector.pop_back();
        }
    }
}

/************************************************************************
*   Function             :  RequestHelper:trfRecordForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::trfRecordForBatch(RequestHelper &fromRequestHelper)
{
    LockGuard lockGuard(this->m_lock);

    if (this->m_bOptimDataAlloc)
    {
        for (auto& it : fromRequestHelper.m_availableRecordsVector)
        {
            this->m_availableRecordsVector.push_back(it);
        }
        fromRequestHelper.m_availableRecordsVector.clear();

        this->m_parallelDbiInOutDataVector.push_back(fromRequestHelper.m_allDbiInOutDataVector);
        if (fromRequestHelper.m_allDbiInOutDataVector.empty())
        {
            auto& allDbiInOutDataVector = this->m_parallelDbiInOutDataVector.back();
            for (auto& it : fromRequestHelper.m_availableDbiInOutDataMap)
            {
                for (auto& it2 : it.second)
                {
                    allDbiInOutDataVector.push_back(it2);
                }
            }
        }
        else
        {
            for (auto& it : fromRequestHelper.m_allDbiInOutDataVector)
            {
                this->m_requestMp.ownerObject(it);
                fromRequestHelper.m_requestMp.removeObject(it);
            }
        }
        fromRequestHelper.m_allDbiInOutDataVector.clear();
		fromRequestHelper.m_availableDbiInOutDataMap.clear();
    }

    for (auto& it : fromRequestHelper.m_onErrorRequests)
    {
        this->m_onErrorRequests.push_back(it);
    }
    fromRequestHelper.m_onErrorRequests.clear();

    for (auto& it : fromRequestHelper.m_errorConstraints)
    {
        this->m_errorConstraints.push_back(it);
    }
    fromRequestHelper.m_errorConstraints.clear();
}

/************************************************************************
*   Function             :  RequestHelper:printErrorOnFile()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::printErrorOnFile(const std::string& badFileName, int batchRowNbr, DdlGenMsg &ddlGenMsg)
{
    LockGuard lockGuard(this->m_lock);

    if (this->m_onErrorRequests.empty() == false)
    {
        if (CAST_INT(this->m_onErrorRequests.size()) != batchRowNbr)
        {
            if (badFileName.empty())
            {
                const AAALogger& logger = AAALogger::get(AAALogger::Logger::Message);
                for (auto& it : this->m_onErrorRequests)
                {
                    logger.error(it);
                }
            }
            else
            {
                std::ofstream badStream;
                badStream.open(badFileName.c_str(), std::ifstream::out | std::ifstream::binary);

                for (auto& it : this->m_onErrorRequests)
                {
                    badStream << it << std::endl;
                }
                badStream.close();
            }
        }
        this->m_onErrorRequests.clear();
    }

    if (this->m_errorConstraints.empty() == false)
    {
        std::stringstream   msg;
        msg << "Check failed on constraint: ";
        for (auto it = this->m_errorConstraints.begin(); it != this->m_errorConstraints.end(); ++it)
        {
            if (it != this->m_errorConstraints.begin())
            {
                msg << ", ";
            }
            msg << (*it);
        }

        ddlGenMsg.printMsg(RET_DBA_ERR_DBPROBLEM, msg.str());
        this->m_errorConstraints.clear();
    }
}

/************************************************************************
*   Function             :  RequestHelper:flushBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::flushBatch(bool bForceFlush, DdlGenMsg* ddlGenMsgPtr)
{
    if ((bForceFlush || this->m_recordsForBatchInQueue.size() >= this->getBatchBlockSize()) &&
        this->m_recordsForBatchInQueue.empty() == false)
    {
        this->m_dbiConn->setBatchBlockSize(this->getBatchBlockSize());

        if (this->m_bBatchASync &&
            this->m_batchThreadPoolPtr == nullptr)
        {
            this->m_batchThreadPoolPtr = new ThreadPool();
            this->m_globalMp.ownerObject(this->m_batchThreadPoolPtr);

            this->m_batchThreadPoolPtr->setStackSize(SYS_GetStackSize());
            this->m_batchThreadPoolPtr->setThreadParallelSize(this->getParallel());
        }

        if (this->m_batchThreadPoolPtr != nullptr)
        {
            if (this->getParallel() <= 1 || bForceFlush)
            {
                this->m_batchThreadPoolPtr->waitForDone(10);
            }

            this->clearRecordForBatch(bForceFlush);

            this->m_recordsForBatch = this->m_recordsForBatchInQueue;
            this->m_recordsForBatchInQueue.clear();

            if (this->getParallel() > 1)
            {
                if (this->m_batchThreadPoolPtr->getNbThread() == 0 ||
                    this->m_threadNb > (10 * this->getParallel()))
                {
                    this->m_threadNb = 1;
                }
                else
                {
                    this->m_threadNb++;
                }
                this->m_batchThreadPoolPtr->add(true,
                                                &DBA_InsertBatchParallel,
                                                new ParallelBatchInfo(this, bForceFlush, this->m_recordsForBatch, ddlGenMsgPtr),
                                                SYS_Stringer("RequestHelper-InsertBatch-", this->m_tableSqlName, "-", this->m_threadNb).c_str(),
                                                nullptr,
                                                ThreadFunctionalType::UNKNOWN,
                                                nullptr);
                this->m_recordsForBatch.clear();
            }
            else
            {
                this->m_batchThreadPoolPtr->add(true,
                                                &DBA_InsertBatch,
                                                new ASyncBatchInfo(this, bForceFlush),
                                                SYS_Stringer("RequestHelper-InsertBatch-", this->m_tableSqlName).c_str(),
                                                nullptr,
                                                ThreadFunctionalType::UNKNOWN,
                                                nullptr);
            }

            return RET_SUCCEED;
        }

        this->m_recordsForBatch = this->m_recordsForBatchInQueue;
        this->m_recordsForBatchInQueue.clear();
        return this->realFlushBatch(bForceFlush);
    }

    this->m_lastRetCode = RET_GEN_INFO_NOACTION;

    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:getRealRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46508 - LJE - 211012
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::getRealRequest(std::string &realRequest)
{
    auto              &requestParamVector = this->m_dbiConn->getRequestParamMap();

    std::string findWord("?");

    for (auto &it : requestParamVector)
    {
        std::string::size_type  pos = 0;

        if ((pos = DdlGen::find_word(realRequest, findWord, pos)) != std::string::npos)
        {
            std::stringstream     valueStream;
            if (it.second->isNull() == false &&
                (IS_STRING_TYPE(it.second->m_dataType) || IS_USTRING_TYPE(it.second->m_dataType)))
            {
                valueStream << "'";
            }
            DBI_FldToDbDataStr(valueStream, it.second->getDynFldStp(), 0, it.second->m_dataType, true, this->m_dbiConn->getDbaRDBMS(), nullptr);  /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
            if (it.second->isNull() == false &&
                (IS_STRING_TYPE(it.second->m_dataType) || IS_USTRING_TYPE(it.second->m_dataType)))
            {
                valueStream << "'";
            }
            realRequest.replace(pos, 1, valueStream.str());
            pos += valueStream.str().length();
        }
    }
}

/************************************************************************
*   Function             :  RequestHelper:realFlushBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200529
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::realFlushBatch(bool bForceFlush, bool bRetry)
{
    RET_CODE firstErrorCode = RET_SUCCEED;

    if (this->m_dbiConn->getDbaRDBMS() == QtHttp &&
        this->m_batchMode != DbiConnection::BatchMode::RowByRow)
    {
        this->m_batchMode = DbiConnection::BatchMode::RowByRow;
    }

    auto batchMode       = this->getBatchMode();
    auto transactionMode = this->getTransactionMode();

    if ((this->m_batchMode != DbiConnection::BatchMode::RowByRow && this->getBatchBlockSize() > 1) ||
        this->m_procedureStp == nullptr)
    {
        if (this->prepareStatementForBatch() == RET_SUCCEED)
        {
            DbiSqlTrace      *sqlTrace = nullptr;
            std::string       sqlRequestCopy;
            bool              bStatementPrepared = true;

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                sqlTrace = &(this->m_dbiConn->getSqlTrace());
                if (sqlTraceLog.isWarnEnabled())
                {
                    sqlRequestCopy = sqlTrace->m_request.str();
                    sqlTrace->m_request.str("");
                }
            }

            this->m_batchPos = 0;
            this->m_dbiConn->m_batchTableSqlName = this->m_tableSqlName;

            for (auto &eltToInsertIt : this->m_recordsForBatch)
            {
                if (bStatementPrepared == false)
                {
                    if (this->prepareStatementForBatch() != RET_SUCCEED)
                    {
                        break;
                    }
                    bStatementPrepared = true;
                }

                this->m_paramDataStp = eltToInsertIt;
                this->m_paramDynStEn = this->m_paramDataStp != nullptr ? GET_DYNSTENUM(this->m_paramDataStp) : NullDynSt;

                if (this->m_procedureStp == nullptr ||
                    this->m_procedureStp->action == Update ||
                    this->m_procedureStp->action == Insert)
                {
                    DBA_SetMagicDate(this->m_paramDataStp, this->m_paramDataStp->getDynStEn(), this->m_paramDataStp->getObjectEn());
                }

                this->clearParamData();

                if (this->m_procedureStp == nullptr ||
                    (this->m_procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM)
                {
                    this->m_dbiConn->getOutboxManager().addRecord(this->m_paramDataStp, Insert, OutboxEventModeEn::Entity);

                    if (this->m_bInsertUd)
                    {
                        this->setDynFldStpParam(this->m_paramDataStp, TargetTable_UserDefinedFields, true);
                    }
                    else if (this->m_bInsertMain)
                    {
                        this->setDynFldStpParam(this->m_paramDataStp, TargetTable_Main, true);
                    }
                    else if (this->m_entityNatEn != EntityNat_All)
                    {
                        this->setDynFldStpParam(this->m_paramDataStp, TargetTable_Main, true);
                    }
                }
                else if (this->m_procedureStp->procParamDefPtr != nullptr)
                {
                    this->m_dbiConn->getOutboxManager().addRecord(this->m_paramDataStp, this->m_procedureStp);

                    if (this->m_procedureStp->action == Update ||
                        this->m_procedureStp->action == Insert)
                    {
                        OBJECT_ENUM object = this->m_batchObjEn;
                        if (object == NullEntity)
                        {
                            DBA_GetObjectEnumByDynSt(this->m_paramDynStEn, &object);
                        }
                        DBA_SetMagicDate(this->m_paramDataStp, this->m_paramDynStEn, object);
                    }

                    int paramPos = 0;

                    if (this->m_bUseNativeQuery)
                    {
                        auto& inputVariableVector = this->m_dbiConn->getScriptDdlGenPtr()->getDdlGenContextPtr()->m_inputVariableVector;
                        std::map<std::string, DBA_PROCPARAM_STP> procParamDefMap;

                        while (this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr != UNUSED)
                        {
                            procParamDefMap[&(this->m_procedureStp->procParamDefPtr[paramPos].paramName[1])] = &this->m_procedureStp->procParamDefPtr[paramPos];
                            paramPos++;
                        }

                        paramPos = 0;
                        for (auto it = inputVariableVector.begin(); it != inputVariableVector.end(); ++it, paramPos++)
                        {
                            auto paramIt = procParamDefMap.find(it->m_sqlname);
                            if (paramIt != procParamDefMap.end())
                            {
                                bool bOutput = (paramIt->second->procParamTypeEn == ProcParamType_Output ||
                                                paramIt->second->procParamTypeEn == ProcParamType_Output_Indexed);

                                this->setOneDynFldParam(this->m_paramDataStp,
                                                        *(paramIt->second->fldNbrPtr),
                                                        paramPos,
                                                        NullDataType,
                                                        true,
                                                        bOutput,
                                                        false,
                                                        paramIt->first.c_str(),
                                                        nullptr,
                                                        true);

                                procParamDefMap.erase(it->m_sqlname);
                            }
                            else
                            {
                                SYS_BreakOnDebug();
                            }
                        }

                        auto& outputVariableVector = this->m_dbiConn->getScriptDdlGenPtr()->getDdlGenContextPtr()->m_outputVariableVector;
                        for (auto it = outputVariableVector.begin(); it != outputVariableVector.end(); ++it, paramPos++)
                        {
                            auto paramIt = procParamDefMap.find(it->m_sqlname);
                            if (paramIt != procParamDefMap.end())
                            {
                                this->setOneDynFldParam(this->m_paramDataStp,
                                                        *(paramIt->second->fldNbrPtr),
                                                        paramPos,
                                                        NullDataType,
                                                        false,
                                                        true,
                                                        true,
                                                        paramIt->first.c_str(),
                                                        nullptr,
                                                        true);
                            }
                        }

                    }
                    else
                    {
                        while (this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr != UNUSED)
                        {
                            bool bOutput = (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output ||
                                            this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output_Indexed);
                            bool bInput = (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Input ||
                                           this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Input_NoCheck);

                            if (bInput || bOutput)
                            {
                                this->setOneDynFldParam(this->m_paramDataStp,
                                                        *(this->m_procedureStp->procParamDefPtr[paramPos].fldNbrPtr),
                                                        paramPos,
                                                        NullDataType,
                                                        true,
                                                        bOutput,
                                                        false,
                                                        this->m_procedureStp->procParamDefPtr[paramPos].paramName,
                                                        (this->m_procedureStp->procParamDefPtr[paramPos].procParamTypeEn == ProcParamType_Output_Indexed ? this->m_procedureStp->procParamDefPtr[paramPos].outputFldNbrPtr : nullptr),
                                                        true);
                            }

                            /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
                            if (this->m_lastRetCode != RET_SUCCEED)
                            {
                                auto& msgStructSt = this->m_dbiConn->m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                                msgStructSt.techMsg = FALSE;
                                msgStructSt.retCode = RET_DBA_ERR_SETPARAM;
                                msgStructSt.msgString = SYS_Stringer("Arithmetic overflow occurred on attribute ", this->m_procedureStp->procParamDefPtr[paramPos].paramName);

                                this->m_dbiConn->m_lastResultRetCode = RET_DBA_ERR_SETPARAM;
                                return(false);
                            }
                            paramPos++;
                        }
                    }
                }

                if (this->m_bOverFlow)
                {
                    std::stringstream     valuesStream;

                    valuesStream << "Overflow while setting the following data - entity: " << this->m_tableSqlName << std::endl;

                    auto &requestParamMap = this->m_dbiConn->getRequestParamMap();

                    for (auto it = requestParamMap.begin(); it != requestParamMap.end(); ++it)
                    {
                        if (it != requestParamMap.begin())
                        {
                            valuesStream << ", ";
                        }
                        valuesStream << (it->second->m_sqlName.empty() ? SYS_Stringer("Col ", it->first + 1) : it->second->m_sqlName) << " = ";

                        DBI_FldToDbDataStr(valuesStream, this->m_paramDataStp, it->second->m_colPos, it->second->m_dataType, true, this->m_dbiConn->getDbaRDBMS(), nullptr);
                    }

                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, valuesStream.str().c_str());

                    this->m_bOverFlow = false;
                }

                if (sqlTraceLog.isDebugEnabled())
                {
                    std::string        sqlTraceRequest = sqlRequestCopy;
                    this->getRealRequest(sqlTraceRequest);
                    sqlTrace->m_request << "\n" << sqlTraceRequest;
                }

                this->m_lastRetCode = this->m_dbiConn->addBatch();
                this->m_batchPos++;

                if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR &&
                    (this->m_batchMode       != DbiConnection::BatchMode::RowByRow ||
                     this->m_transactionMode != TransactionMode::MostAsPossible))
                {
                    break;
                }

                if (this->m_batchMode == DbiConnection::BatchMode::RowByRow)
                {
                    this->m_lastRetCode = this->m_dbiConn->executeBatch();

                    bStatementPrepared = false;
                    if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
                    {
                        this->printMsg();

                        if (this->m_transactionMode != TransactionMode::MostAsPossible)
                        {
                            break;
                        }

                        if (firstErrorCode == RET_SUCCEED)
                        {
                            firstErrorCode = this->m_lastRetCode;
                        }

                        if (this->m_dbiConn->isExternalMsgManagement())
                        {
                            std::string requestStr = this->m_dbiConn->getRequest();
                            this->getRealRequest(requestStr);
                            this->m_onErrorRequests.push_back(requestStr);
                        }

                        if (this->m_dbiConn->m_errorConstraint.empty() == false)
                        {
                            this->m_errorConstraints.push_back(this->m_dbiConn->m_errorConstraint);
                        }

                        this->m_dbiConn->endTransaction(FALSE);
                    }
                    else
                    {
                        this->m_lastRetCode = RET_SUCCEED;
                        this->updateOutputValue();

                        if (this->m_transactionMode == TransactionMode::MostAsPossible)
                        {
                            this->m_dbiConn->endTransaction(TRUE);
                        }
                    }

                    this->m_batchPos = 0;
                }
            }
        }

        if (this->m_batchMode != DbiConnection::BatchMode::RowByRow)
        {
            if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
            {
                if (this->m_procedureStp != nullptr &&
                    (this->m_procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM)
                {
                    (void)this->startProcedureCall(this->m_procedureStp, this->m_paramDataStp);
                    this->m_dbiConn->m_insertIdentityOn = false;
                }

                this->m_lastRetCode = this->m_dbiConn->executeBatch();
            }

            if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
            {
                this->printMsg();
            }
            else
            {
                this->m_lastRetCode = RET_SUCCEED;
                this->updateOutputValue();
            }
        }
    }
    else
    {
        for (auto eltToInsertIt = this->m_recordsForBatch.begin(); eltToInsertIt != this->m_recordsForBatch.end(); ++eltToInsertIt)
        {
            this->m_paramDataStp = *eltToInsertIt;
            this->m_paramDynStEn = this->m_paramDataStp != nullptr ? GET_DYNSTENUM(this->m_paramDataStp) : NullDynSt;

            if (this->m_procedureStp->server == InternalProc)
            {
                DbiConnectionHelper dbiConnHelpr(this->m_dbiConn);

                switch (this->m_procedureStp->action)
                {
                    case Insert:
                        this->m_lastRetCode = dbiConnHelpr.dbaInsert(GET_OBJ_DYNST(this->m_paramDynStEn), this->m_procedureStp->subObj, this->m_paramDataStp);
                        break;

                    case Update:
                        this->m_lastRetCode = dbiConnHelpr.dbaUpdate(GET_OBJ_DYNST(this->m_paramDynStEn), this->m_procedureStp->subObj, this->m_paramDataStp);
                        break;

                    case Delete:
                        this->m_lastRetCode = dbiConnHelpr.dbaDelete(GET_OBJ_DYNST(this->m_paramDynStEn), this->m_procedureStp->subObj, this->m_paramDataStp);
                        break;
                }
            }
            else if (this->startProcedureCall(this->m_procedureStp, this->m_paramDataStp) == false &&
                     this->m_transactionMode != TransactionMode::MostAsPossible)
            {
                break;
            }

            if (this->m_batchMode       == DbiConnection::BatchMode::RowByRow &&
                this->m_transactionMode == TransactionMode::MostAsPossible)
            {
                if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
                {
                    this->m_dbiConn->endTransaction(TRUE);
                }
                else
                {
                    this->m_dbiConn->endTransaction(FALSE);
                }
            }
        }
    }

    if (this->m_transactionMode != TransactionMode::External &&
        this->m_batchMode != DbiConnection::BatchMode::TryBCP)
    {
        if (this->m_batchMode       != DbiConnection::BatchMode::RowByRow &&
            this->m_batchMode       != DbiConnection::BatchMode::TryAndRetryRowByRow &&
            this->m_transactionMode != TransactionMode::MostAsPossible)
        {
            if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
            {
                this->m_dbiConn->endTransaction(TRUE);
            }
            else
            {
                this->m_dbiConn->endTransaction(FALSE);
            }
        }
        else
        {
            if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
            {
                this->m_dbiConn->endTransaction(TRUE);
            }
            else
            {
                this->m_dbiConn->endTransaction(FALSE);

                if (this->m_batchMode != DbiConnection::BatchMode::RowByRow &&
                    (this->m_transactionMode == TransactionMode::MostAsPossible ||
                    this->m_batchMode == DbiConnection::BatchMode::TryAndRetryRowByRow))
                {
                    bool tmpExtMsg = this->m_dbiConn->isExternalMsgManagement();

                    if (this->m_batchMode == DbiConnection::BatchMode::TryAndRetryRowByRow)
                    {
                        this->m_dbiConn->setExternalMsgManagement(false);
                    }
                    else
                    {
                        this->m_dbiConn->setExternalMsgManagement(true);
                    }


                    this->m_batchPos    = 0;
                    this->m_batchMode   = DbiConnection::BatchMode::RowByRow;

                    this->m_dbiConn->releaseCommand();
                    this->m_dbiConn->reconnect();
                    this->m_lastRetCode = this->realFlushBatch(true, true);

                    this->m_dbiConn->setExternalMsgManagement(tmpExtMsg);
                }
            }
        }
    }

    if (bRetry == false)
    {
        this->m_dbiConn->releaseCommand();

        if (this->m_batchThreadPoolPtr == nullptr)
        {
            this->clearRecordForBatch(bForceFlush);
        }
    }

    if (firstErrorCode != RET_SUCCEED)
    {
        this->m_lastRetCode = firstErrorCode;
    }

    this->setBatchMode(batchMode);
    this->setTransactionMode(transactionMode);

    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:executeBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::executeBatch(DdlGenMsg* ddlGenMsgPtr)
{
    RET_CODE retCode = this->flushBatch(true, ddlGenMsgPtr);

    if (this->m_batchThreadPoolPtr != nullptr)
    {
        this->m_batchThreadPoolPtr->waitForDone(10);

        retCode = this->m_lastRetCode;
    }
    this->finishRequest();

    if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
    {
        this->m_lastRetCode = retCode;
    }
    else
    {
        this->m_lastRetCode = RET_SUCCEED;
    }
    return this->m_lastRetCode;
}


/************************************************************************
**
**  Function    :   RequestHelper::DefValHandler::~DefValHandler()
**
**  Description :
**
**
*************************************************************************/
RequestHelper::DefValHandler::~DefValHandler()
{
    SCPT_FreeEntityDefVal(this->dfltValStPtr);
}

/************************************************************************
**
**  Function    :   RequestHelper::computeDV()
**
**  Description :
**
**  Argument    :   object
**                  flags
**                  record
**                  previous
**                  mode
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
RET_CODE RequestHelper::computeDV(DBA_DYNFLD_STP recordStp)
{
    RET_CODE            status   = RET_SUCCEED;
    DBA_DYNST_ENUM      dynStEn  = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM         objectEn = GET_DYNST_ENTITY(dynStEn);
    auto               &handler  = this->m_scptDfltValMap[objectEn];

    if (handler.dfltValStPtr == nullptr &&
        handler.m_bInit == false)
    {
        handler.m_bInit = true;
        if (SCPT_InitEntityDefVal(objectEn, &handler.dfltValStPtr, FALSE, 0) == RET_SUCCEED)
        {
            handler.flags = static_cast<FLAG_T*>(handler.m_mp.calloc(GET_FLD_NBR(dynStEn), sizeof(FLAG_T)));
        }
        else
        {
            return RET_SCPT_ERR_INV_ARG;
        }
    }

    if (handler.dfltValStPtr != nullptr)
    {
        //SCPT_SetOldRecord(handlers->handle, previous);

        bool bDVToDo = false;

        SYS_Bzero(handler.flags, GET_FLD_NBR(dynStEn));
        for (int i = 0; i < GET_FLD_NBR(dynStEn); i++)
        {
            if (IS_SETFLD(recordStp, i) == TRUE)
            {
                handler.flags[i] = TRUE;
            }
            else
            {
                bDVToDo = true;
            }
        }

        if (bDVToDo)
        {
            SCPT_InitConnectNoFldEntityDefVal(handler.dfltValStPtr, this->m_dbiConn->getId());

            if (SCPT_AnalyseEntityDefVal(handler.dfltValStPtr, handler.flags, NULL, recordStp, TRUE, EvalType_DefVal, NULL, NULL, FALSE) != RET_SUCCEED)
            {
                status = RET_SCPT_ERR_INV_ARG;
            }
        }
        SCPT_SetOldRecord(handler.dfltValStPtr, nullptr);
    }

    return status;
}


/************************************************************************
**
**  Function    :   RequestHelper::DefValHandler::~ICHandler()
**
**  Description :
**
**
*************************************************************************/
RequestHelper::ICHandler::~ICHandler()
{
    SCPT_FreeEntityControl(this->icStPtr);
}

/************************************************************************
**
**  Function    :   RequestHelper::computeIC()
**
**  Description :
**
**  Argument    :   object
**                  record
**                  previous
**                  message
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
RET_CODE RequestHelper::computeIC(DBA_DYNFLD_STP recordStp, std::vector<DBA_DYNFLD_STP> &messageVector)
{
    RET_CODE            status = RET_SUCCEED;
    DBA_DYNST_ENUM      dynStEn  = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM         objectEn = GET_DYNST_ENTITY(dynStEn);
    auto               &handler = this->m_scptICMap[objectEn];

    if (handler.icStPtr == nullptr &&
        handler.m_bInit == false)
    {
        handler.m_bInit = true;
        if (SCPT_InitEntityControl(objectEn, &handler.icStPtr, FALSE, 0, NullDictFct, NullEntity, 0) != RET_SUCCEED)
        {
            return RET_SCPT_ERR_INV_ARG;
        }
    }

    if (handler.icStPtr != nullptr)
    {
        // SCPT_SetOldRecordControl(handlers->handle, previous);

        DBA_DYNFLD_STP *messageRecTab = nullptr;
        int		             messageNbRows = 0;

        if (SCPT_AnalyseEntityControl(handler.icStPtr, recordStp, &messageRecTab, &messageNbRows, NULL, ScptActionNone, this->m_dbiConn) != RET_SUCCEED)
        {
            status = RET_SCPT_ERR_INV_ARG;
        }

        for (int i = 0; i < messageNbRows; i++)
        {
            messageVector.push_back(messageRecTab[i]);
            this->m_requestMp.ownerDynStp(messageRecTab[i]);
        }
        FREE(messageRecTab);

        SCPT_SetOldRecordControl(handler.icStPtr, NULL);
    }

    return status;
}

/************************************************************************
*   Function             :  RequestHelper:executeBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200211
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::executeBatchMulti(bool bRowByRow)
{
    DbaTransactionGuard dbaTransactionGuard(*this->m_dbiConn, this->m_lastRetCode);

    std::set<DBA_DYNFLD_STP>           eltToSkipSet;
    std::map<DBA_DYNST_ENUM, int>      dynStMaxSizeMap;
    auto                               originalBatchBlockSize = this->getBatchBlockSize();

    auto savedTransMode = this->getTransactionMode();

    if (this->getTransactionMode() == RequestHelper::TransactionMode::AllOrNothing)
    {
        this->setTransactionMode(RequestHelper::TransactionMode::External);

        dbaTransactionGuard.beginTransaction();
    }

    if (this->m_bFlushStat)
    {
        dbaTransactionGuard.setModifStat(2);
    }

    std::set<OBJECT_ENUM> allObjectsEnSet;

    for (auto &batchRecordMap : this->m_batchRecordMultiMap)
    {
        auto toCopyMap = this->m_batchToCopyMap.find(batchRecordMap.first);
        if (toCopyMap != this->m_batchToCopyMap.end())
        {
            for (auto toCopyIt = toCopyMap->second.begin(); toCopyIt != toCopyMap->second.end(); ++toCopyIt)
            {
                if (IS_NULLFLD(toCopyIt->m_srcDynStp, toCopyIt->m_srcFldIdx) == FALSE)
                {
                    SET_ID(toCopyIt->m_targetDynStp, toCopyIt->m_targetFldIdx, GET_ID(toCopyIt->m_srcDynStp, toCopyIt->m_srcFldIdx));
                }
                else
                {
                    eltToSkipSet.insert(toCopyIt->m_targetDynStp);
                }
            }

            this->m_batchToCopyMap.erase(batchRecordMap.first);
        }

        for (auto &batchRecordVec : batchRecordMap.second)
        {
            if (batchRecordVec.second.empty() == false)
            {
                auto bApplyDV          = this->m_bApplyDV;
                auto bApplyIC          = this->m_bApplyIC;
                DBA_DYNST_ENUM dynStEn = (*batchRecordVec.second.begin())->getDynStEn();
                int       dynStMaxSize = dynStMaxSizeMap[dynStEn];

                if (bApplyDV || bApplyIC)
                {
                    auto dictEntityStp = (*batchRecordVec.second.begin())->getDictEntityStp();
                    if (dictEntityStp != nullptr &&
                        dictEntityStp->bIsInitEntity == true)
                    {
                        bApplyDV = false;
                        bApplyIC = false;
                    }
                }

                if (dynStMaxSize == 0)
                {
                    dynStMaxSize = DBA_GetDynStMaxLen(dynStEn);
                    dynStMaxSizeMap[dynStEn] = dynStMaxSize;
                }

                if (bRowByRow == false)
                {
                    if (dynStMaxSize > 10000)
                    {
                        this->setBatchBlockSize(originalBatchBlockSize / 2);
                    }
                    else
                    {
                        this->setBatchBlockSize(originalBatchBlockSize);
                    }

                    this->startProcedureCallForBatch(batchRecordVec.first);
                }

                for (auto recIt = batchRecordVec.second.begin(); recIt != batchRecordVec.second.end(); ++recIt)
                {
                    if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR &&
                        this->m_transactionMode != TransactionMode::MostAsPossible)
                    {
                        break;
                    }

                    if (eltToSkipSet.empty() == false &&
                        eltToSkipSet.find(*recIt) != eltToSkipSet.end())
                    {
                        continue;
                    }

                    if (this->m_bFlushStat)
                    {
                        allObjectsEnSet.insert(GET_OBJ_DYNST(dynStEn));
                    }

                    if (batchRecordVec.first->action != Delete)
                    {
                        if (bApplyDV)
                        {
                            this->m_lastRetCode = this->computeDV(*recIt);
                        }
                        if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR &&
                            bApplyIC)
                        {
                            std::vector<DBA_DYNFLD_STP> messageVector;

                            this->m_lastRetCode = this->computeIC(*recIt, messageVector);
                        }
                    }

                    if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
                    {
                        if (bRowByRow == false)
                        {
                            this->setNewRecordForBatch(*recIt);

                            if (RET_GET_LEVEL(this->getLastRetCode()) == RET_LEV_ERROR)
                            {
                                break;
                            }
                        }
                        else
                        {
                            this->startProcedureCall(batchRecordVec.first, *recIt);
                        }
                    }
                }

                if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
                {
                    this->executeBatch();
                }

                if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
                {
                    if (this->m_transactionMode != TransactionMode::MostAsPossible)
                    {
                        return this->m_lastRetCode;
                    }
                }
            }
        }

        /* PMSTA-45413 - LJE - 210706 */
        auto fixIdMapIt = this->m_batchToCopyIdMap.find(batchRecordMap.first);
        if (fixIdMapIt != this->m_batchToCopyIdMap.end())
        {
            for (auto fixIdIt = fixIdMapIt->second.begin(); fixIdIt != fixIdMapIt->second.end(); ++fixIdIt)
            {
                *fixIdIt->second = GET_ID(fixIdIt->first, 0);
            }

            fixIdMapIt->second.clear();
            this->m_batchToCopyIdMap.erase(fixIdMapIt);
        }
    }
    this->m_batchToCopyIdMap.clear();

    if (bRowByRow == false &&
        RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR &&
        this->m_batchMode == DbiConnection::BatchMode::TryAndRetryRowByRow &&
        this->getBatchBlockSize() > 1)
    {
        this->m_dbiConn->endTransaction(FALSE);
        this->m_dbiConn->beginTransaction();

        this->executeBatchMulti(true);
    }

    if (this->m_bFlushStat &&
        RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
    {
        for (auto it = allObjectsEnSet.begin(); it != allObjectsEnSet.end(); ++it)
        {
            DBA_UpdTableModifStat(*this->m_dbiConn, (*it));
        }
    }

    this->setTransactionMode(savedTransMode);

    this->m_batchRecordMultiMap.clear();

    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:updateOutputValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200122
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::updateOutputValue()
{
    if (this->m_dbiConn->getSqlRequest().m_batchOutputSet.empty() == false)
    {
        if (this->m_dbiConn->getSqlRequest().m_batchOutputSet.size() == this->m_recordsForBatch.size())
        {
            FIELD_IDX_T idPos         = Null_Dynfld;
            FIELD_IDX_T rowVersionPos = Null_Dynfld;

            for (auto &it : this->m_dbiConn->getRequestParamMap())
            {
                if (it.second->m_bOutput)
                {
                    if (idPos == Null_Dynfld &&
                        (it.second->m_dataType == IdType ||
                         it.second->m_dataType == DictType))
                    {
                        idPos = it.second->m_outputFieldIdx;
                    }

                    if (rowVersionPos == Null_Dynfld &&
                        it.second->m_dataType == TimeStampType)
                    {
                        rowVersionPos = it.second->m_outputFieldIdx;
                    }
                }
            }

            auto outputDateIt = this->m_dbiConn->getSqlRequest().m_batchOutputSet.begin();

            for (auto eltInsertedIt = this->m_recordsForBatch.begin(); eltInsertedIt != this->m_recordsForBatch.end(); ++eltInsertedIt, ++outputDateIt)
            {
                this->m_paramDataStp = *eltInsertedIt;

                if (idPos != Null_Dynfld)
                {
                    SET_ID(this->m_paramDataStp, idPos, outputDateIt->id);
                }
                if (rowVersionPos != Null_Dynfld)
                {
                    SET_TIMESTAMP(this->m_paramDataStp, rowVersionPos, outputDateIt->rowVersion);
                }
            }
        }
        else if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Invalid output values return on batch mode");

            this->m_lastRetCode = RET_DBA_ERR_DBPROBLEM;
        }
    }
}

/************************************************************************
*   Function             :  RequestHelper:getColumnCount()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getColumnCount()
{
    return this->m_dbiConn->getColumnCount();
}

/************************************************************************
*   Function             :  RequestHelper:getColumnName()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getColumnName(int colNum, std::string &colName)
{
    return this->m_dbiConn->getColumnName(colNum, colName);
}

/************************************************************************
*   Function             :  RequestHelper:getColumnType()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getColumnType(int colNum, CTYPE_ENUM &cType)
{
    return this->m_dbiConn->getColumnType(colNum, cType);
}

/************************************************************************
*   Function             :  RequestHelper:getPrecision()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getPrecision(int colNum)
{
    return this->m_dbiConn->getPrecision(colNum);
}

/************************************************************************
*   Function             :  RequestHelper:getScale()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getScale(int colNum)
{
    return this->m_dbiConn->getScale(colNum);
}

/************************************************************************
*   Function             :  RequestHelper:getColumnMaxLength()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getColumnMaxLength(int colNum)
{
    return this->m_dbiConn->getColumnMaxLength(colNum);
}


/************************************************************************
*   Function             :  RequestHelper:getColumnDisplaySize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getColumnDisplaySize(int colNum)
{
    return this->m_dbiConn->getColumnDisplaySize(colNum);
}


/************************************************************************
*   Function             :  RequestHelper:fetch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::fetch()
{
    this->m_lastRetCode = RET_DBA_INFO_NO_MORE_DATA;

    if (this->m_bSendDone)
    {
        if (this->m_dbiConn->m_lastResultType == DBI_ROW_RESULT)
        {
            this->m_lastRetCode = this->m_dbiConn->fetch();

            if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
            {
                this->printMsg();
            }
            else if (this->m_lastRetCode != RET_DBA_INFO_NO_MORE_DATA)
            {
                for (auto &it : this->m_dbiConn->getRequestOutputVector())
                {
                    it->initNullValue();
                }
                this->m_bFetchStarted = true;
            }
        }

        if (this->m_dbiConn->m_lastResultType != DBI_ROW_RESULT)
        {
            if (this->m_dbiConn->m_lastResultType == DBI_CMD_SUCCEED)
            {
                this->m_bFetchDone    = true;
                this->m_bFetchStarted = false;

                if ((this->m_lastRetCode = this->getNextResultSet()) == RET_SUCCEED)
                {
                    this->m_lastRetCode = RET_DBA_INFO_NO_MORE_DATA;
                    return this->m_lastRetCode;
                }

                if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
                {
                    this->m_dbiConn->m_lastResultType = DBI_CMD_FAIL;
                    return this->m_lastRetCode;
                }
            }

            this->m_lastRetCode = this->m_dbiConn->processAllResults(&this->m_lastStatus);

            if (this->m_lastRetCode == RET_SUCCEED &&
                this->m_dbiConn->m_lastResultType == DBI_CMD_SUCCEED)
            {
                this->m_dbiConn->m_lastResultType = DBI_CMD_DONE;
            }

            this->printMsg();

            if (RET_GET_LEVEL(this->m_lastRetCode) == RET_LEV_ERROR)
            {
                this->m_dbiConn->m_lastResultType = DBI_CMD_FAIL;
            }
            else
            {
                this->m_lastRetCode = RET_DBA_INFO_NO_MORE_DATA;
            }
        }
    }
    else
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Invalid call to fetch command, please send the command before !!!!");
    }

    return this->m_lastRetCode;
}


/************************************************************************
*   Function             :  RequestHelper:getNextResultSet()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getNextResultSet()
{
    if (this->m_defOutDataStp != nullptr)
    {
        FREE_DYNST(this->m_defOutDataStp, this->m_outputDynStEn);
    }
    this->m_outputDynStEn = NullDynSt;

    /* PMSTA-34344 - LJE - 200928 */
    if (this->m_dbiConn->getSqlRequest().m_requestOutputVector.size() > 1 &&
        this->m_dbiConn->getSqlRequest().m_requestOutputVector.size() > this->m_dbiConn->getSqlRequest().m_currResultSet)
    {
        this->m_dbiConn->getSqlRequest().m_currResultSet++;

        this->m_bFetchDone = false;

        this->m_dbiConn->m_bCurrentRequestOutputBinded = false;
        this->m_dbiConn->clearRequestBindDataVector();
    }
    else
    {
        this->m_dbiConn->getSqlRequest().m_currResultSet = 0;
    }

    return (this->m_lastRetCode = this->m_dbiConn->getNextResultSet());
}

/************************************************************************
*   Function             :  RequestHelper:setExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setExternalMsgManagement(bool bExternalMsgManagement)
{
    this->m_dbiConn->setExternalMsgManagement(bExternalMsgManagement);
}

/************************************************************************
*   Function             :  RequestHelper:isExternalMsgManagement()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::isExternalMsgManagement()
{
    return this->m_dbiConn->isExternalMsgManagement();
}

/************************************************************************
*   Function             :  RequestHelper:printMsg()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::printMsg()
{
    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->sendAllMsg();
        this->m_lastRetCode = this->m_dbiConn->m_lastResultRetCode;
    }
    else
    {
        this->m_lastRetCode = RET_DBA_ERR_CONNOTFOUND;
    }
}

/************************************************************************
*   Function             :  RequestHelper:clearMsg()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-53403 - LJE - 230622
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::clearMsg()
{
	if (this->m_dbiConn != nullptr)
	{
		this->m_dbiConn->clearMsg();
	}
}

/************************************************************************
*   Function             :  RequestHelper:addNewResultSet()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 200928
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::addNewResultSet()
{
    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->getSqlRequest().m_currResultSet++;
    }
}

/************************************************************************
*   Function             :  RequestHelper:getNewParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190426
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::getNewParam(DATATYPE_ENUM dataType, DbiInOutData *dynFldStp)
{
    if (this->m_bSendDone && this->m_bFetchStarted == false)
    {
        this->m_bSendDone = false;
        this->m_bFetchDone = false;

        this->m_dbiConn->clearRequestOutputVector();
        this->m_dbiConn->initRequest(this->m_dbiConn->getCurrentAction(), true);
        this->clearParamData();
        this->clearOutputData();
    }
    else if (this->m_bFetchStarted)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "It's not allowed to try to add parameter while all the previous command has not been fully fetched !!!!");
    }

    DbiInOutData *locDynFldStp = dynFldStp;

    if (this->m_dbiConn->getRequestParamMap().find(this->m_paramPos) != this->m_dbiConn->getRequestParamMap().end()  &&
        locDynFldStp == nullptr)
    {
        locDynFldStp = this->m_dbiConn->getRequestParamMap()[this->m_paramPos];
        locDynFldStp->clear();
    }
    else
    {
        if (locDynFldStp == nullptr)
        {
            if (this->m_bOptimDataAlloc)
            {
                auto dbiInOutDataVector = this->m_availableDbiInOutDataMap.find(this->m_paramPos);
                if (dbiInOutDataVector != this->m_availableDbiInOutDataMap.end() &&
                    dbiInOutDataVector->second.empty() == false)
                {
                    locDynFldStp = dbiInOutDataVector->second.back();
                    locDynFldStp->clear();

                    dbiInOutDataVector->second.pop_back();
                }
            }

            if (locDynFldStp == nullptr)
            {
                locDynFldStp = new DbiInOutData(dataType, true, false);
                this->m_requestMp.ownerObject(locDynFldStp);
            }
            
            if (this->m_bOptimDataAlloc)
            {
                this->m_allDbiInOutDataVector.push_back(locDynFldStp);
            }

            locDynFldStp->m_bInput  = true;
            locDynFldStp->m_bOutput = false;
        }

        this->m_dbiConn->getRequestParamMap()[this->m_paramPos] = locDynFldStp;
    }
    locDynFldStp->m_colPos = this->m_paramPos;

    this->m_paramPos++;

    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::addNewParam(DbiInOutData *newParamStp)
{
    if (IS_NULLFLD(newParamStp->getDynFldStp(), 0) == FALSE)
    {
        newParamStp->m_nullInd = DBI_GOODDATA;
    }
}

/************************************************************************
*   Function             :  RequestHelper:addNewParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParam(DATATYPE_ENUM dataType)
{
    DbiInOutData *locDynFldStp = this->getNewParam(dataType);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParam(DBA_DYNFLD_STP dynFldStp, bool bFixCharSet)
{
    if (bFixCharSet &&
        IS_STRING_TYPE(static_cast<DATATYPE_ENUM>(dynFldStp->dataType)) &&
        this->m_dbiConn->getCurrCharsetEn() != this->m_dbiConn->getDbCommCharsetEn())
    {
        auto charSet = ICU4AAA_GetCharSet(GET_STRING(dynFldStp, 0));

        if (charSet != CurrentCharsetCode_Ascii_7 &&
            charSet != CurrentCharsetCode_UTF8)
        {
            int    cursorLen = static_cast<int>(strlen(GET_STRING(dynFldStp, 0)) + 1);
            int    uCharLen = 0;
            int    isoLen = 0;
            UChar* cursorUChar = static_cast<UChar*>(CALLOC(cursorLen, sizeof(UChar)));
            ICU4AAA_ConvertFromDefaultCharSet(GET_STRING(dynFldStp, 0), cursorLen, cursorUChar, cursorLen, &uCharLen, this->m_dbiConn->getCurrCharsetEn());

            cursorLen *= 4;
            char* utf8Char = static_cast<char*>(CALLOC(cursorLen, sizeof(char)));
            ICU4AAA_ConvertToUTF8(cursorUChar, uCharLen, utf8Char, cursorLen, &isoLen);


            auto newOutputDataPtr = this->addNewParamCharPtr(utf8Char, static_cast<DATATYPE_ENUM>(dynFldStp->dataType));


            FREE(cursorUChar);
            FREE(utf8Char);

            return newOutputDataPtr;
        }
    }

    auto locDynFldStp = this->getNewParam(static_cast<DATATYPE_ENUM>(dynFldStp->dataType), new DbiInOutData(dynFldStp, true, false)); /* PMSTA-36208 - DDV - 190909 - Set parameter as In */
    this->m_requestMp.ownerObject(locDynFldStp);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamString()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamString(const std::string &newParamStr, DATATYPE_ENUM dataType)
{
    return this->addNewParamCharPtr(newParamStr.c_str(), dataType);
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamCharPtr(const char *newParamStr, DATATYPE_ENUM dataType)
{
    DbiInOutData *locDynFldStp = this->getNewParam(dataType);

    if (newParamStr != nullptr)
    {
        if (IS_STRING_TYPE(dataType) == TRUE)
        {
            locDynFldStp->setCharPtr(newParamStr);
        }
        else
        {
            DBA_SetDynFldFromString(DateStyle_Iso,
                                    newParamStr,
                                    locDynFldStp->getDynFldStp(),
                                    0);
        }
    }

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamCharPtr(const std::string &newParamStr, DATATYPE_ENUM dataType)
{
    return this->addNewParamCharPtr(newParamStr.c_str(), dataType);
}


/************************************************************************
*   Function             :  RequestHelper:addNewParamUCharPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamUCharPtr(const UChar *newParamStr, DATATYPE_ENUM dataType)
{
    DbiInOutData *locDynFldStp = this->getNewParam(dataType);

    locDynFldStp->setUCharPtr(newParamStr);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamUChar()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamUChar(UCHAR_T newParamUc)
{
    DbiInOutData *locDynFldStp = this->getNewParam(TinyintType);

    SET_UCHAR(locDynFldStp->getDynFldStp(), 0, newParamUc);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamInt()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamInt(INT_T newParamInt)
{
    DbiInOutData *locDynFldStp = this->getNewParam(IntType);

    SET_INT(locDynFldStp->getDynFldStp(), 0, newParamInt);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamShort()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamShort(SMALLINT_T newParamShort)
{
    DbiInOutData *locDynFldStp = this->getNewParam(SmallintType);

    SET_SHORT(locDynFldStp->getDynFldStp(), 0, newParamShort);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamUShort()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamUShort(YEAR_T newParamUShort)
{
    DbiInOutData *locDynFldStp = this->getNewParam(YearType);

    SET_USHORT(locDynFldStp->getDynFldStp(), 0, newParamUShort);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamDatetime()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamDatetime(const DATETIME_T &newParamDateTime)
{
    DbiInOutData *locDynFldStp = this->getNewParam(DatetimeType);

    SET_DATETIME(locDynFldStp->getDynFldStp(), 0, newParamDateTime);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamDatetime()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamDatetime(const DATETIME64_ST &newParamDateTime)
{
    DbiInOutData *locDynFldStp = this->getNewParam(DatetimeType);

    SET_DATETIMEST(locDynFldStp->getDynFldStp(), 0, newParamDateTime);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamUInt()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190527
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamUInt(TIME_T newParamUInt)
{
    DbiInOutData *locDynFldStp = this->getNewParam(TimeType);

    SET_TIME(locDynFldStp->getDynFldStp(), 0, newParamUInt);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamLongLong()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamLongLong(INT64_T newParamId)
{
    DbiInOutData *locDynFldStp = this->getNewParam(LongintType);

    SET_LONGINT(locDynFldStp->getDynFldStp(), 0, newParamId);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamId()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200602
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamId(ID_T newParamId, DATATYPE_ENUM dataType)
{
    DbiInOutData *locDynFldStp = this->getNewParam(dataType);

    if (dataType == IdType)
    {
        SET_ID(locDynFldStp->getDynFldStp(), 0, newParamId);
    }
    else
    {
        SET_DICT(locDynFldStp->getDynFldStp(), 0, newParamId);
    }

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamDouble()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamDouble(NUMBER_T newParamDbl, DATATYPE_ENUM dataType)
{
    double max = GET_MAX_DOUBLE(dataType);
    DbiInOutData *locDynFldStp = this->getNewParam(dataType);

    if (fabs(newParamDbl) > max)
    {
        this->m_lastRetCode = RET_SRV_LIB_ERR_DB_OVERFLOW;

        if (newParamDbl < 0.0)
        {
            max *= -1;
        }
        SET_DOUBLE(locDynFldStp->getDynFldStp(), 0, max); /* PMSTA-33082 - DDV - 210311 - Set max or -max instead of 0 */
    }
    else
    {
        SET_DOUBLE(locDynFldStp->getDynFldStp(), 0, newParamDbl);
    }

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamTimeStamp()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamTimeStamp(TIMESTAMP_T newParamTimeStamp)
{
    DbiInOutData *locDynFldStp = this->getNewParam(TimeStampType);

    SET_TIMESTAMP(locDynFldStp->getDynFldStp(), 0, newParamTimeStamp);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamBinary()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26000 - LJE - 170130
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamBinary(UINT64_T newParamBin)
{
    DbiInOutData *locDynFldStp = this->getNewParam(BinaryType);

    SET_BINARY(locDynFldStp->getDynFldStp(), 0, newParamBin);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewParamDynStp()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201221
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewParamDynStp(DBA_DYNFLD_STP newParamDynStp)
{
    DbiInOutData *locDynFldStp = this->getNewParam(PtrType);

    SET_PTR(locDynFldStp->getDynFldStp(), 0, newParamDynStp);

    this->addNewParam(locDynFldStp);
    return locDynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:addNewOutputData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171028
*
*   Last Modification    :
*
*************************************************************************/
DbiInOutData *RequestHelper::addNewOutputData(DATATYPE_ENUM dataType, const char *sqlName)
{
    if (this->m_bFetchDone == true)
    {
        this->m_bFetchDone = false;
        this->clearOutputData();
    }
    else if (this->m_bFetchStarted)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "It's not allowed to try to add parameter while all the previous command has not been fully fetched !!!!");
    }

    this->m_dbiConn->getRequestOutputVector().push_back(new DbiInOutData(dataType, false, true, (sqlName != nullptr ? sqlName : std::string())));
    this->m_dbiConn->getRequestOutputVector().back()->m_colPos = static_cast<FIELD_IDX_T>(this->m_dbiConn->getRequestOutputVector().size()) - 1;
    this->m_requestMp.ownerObject(this->m_dbiConn->getRequestOutputVector().back());

    return this->m_dbiConn->getRequestOutputVector().back();
}

/************************************************************************
*   Function             :  RequestHelper:getBindVariablePtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::getBindVariablePtr(DBA_DYNFLDDATA_UN*  &dynFldDataValue)
{
    dynFldDataValue = (this->m_dbiConn->getRequestOutputVector().back()->getDataPtr());
}


/************************************************************************
*   Function             :  RequestHelper:isNullValue
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::isNullValue(int colNum)
{
    return ((size_t)colNum >= this->m_dbiConn->getRequestOutputVector().size() ||
            this->m_dbiConn->getRequestOutputVector()[colNum]->m_nullInd == DBI_NULLDATA);
}

/************************************************************************
*   Function             :  RequestHelper:getCharPtrValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
const char *RequestHelper::getCharPtrValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.strData.ptr;
    }
    return nullptr;
}

/************************************************************************
*   Function             :  RequestHelper:getUCharPtrValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
const UChar *RequestHelper::getUCharPtrValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.ustrData.ptr;
    }
    return nullptr;
}

/************************************************************************
*   Function             :  RequestHelper:getLongLongValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
INT64_T RequestHelper::getLongLongValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.longlongValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getDoubleValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
double RequestHelper::getDoubleValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.dbleValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getIntValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getIntValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.intValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getShortValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
short RequestHelper::getShortValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.shortValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getUIntValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
unsigned int RequestHelper::getUIntValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.uintValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getUShortValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
unsigned short RequestHelper::getUShortValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.ushortValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getUCharValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
unsigned char RequestHelper::getUCharValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.ucharValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getBinaryValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
BINARY_T RequestHelper::getBinaryValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.binaryValue;
    }
    return 0;
}

/************************************************************************
*   Function             :  RequestHelper:getLongLongValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
DATETIME_ST RequestHelper::getDateTimeValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return GET_DATETIME(this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp(), 0);
    }
    DATETIME_ST datetimeSt = {0, 0};
    return datetimeSt;
}

/************************************************************************
*   Function             :  RequestHelper:getLongLongValue()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190830
*
*   Last Modification    :
*
*************************************************************************/
DATE_ST RequestHelper::getDateValue(int colNum)
{
    if (this->isNullValue(colNum) == false)
    {
        return this->m_dbiConn->getRequestOutputVector()[colNum]->getDynFldStp()->data.dateView;
    }
    DATE_ST dateSt = { 0 };
    return dateSt;
}

/************************************************************************
*   Function             :  RequestHelper:setDynFldStpParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setDynFldStpParam(DBA_DYNFLD_STP dynFldStp, TARGET_TABLE_ENUM targetTableEn, bool bOnlyPhisical)
{
    /* Retrieve the field number of a dynamic structure format */
    DBA_DYNST_ENUM dynStEn   = GET_DYNSTENUM(dynFldStp);

    if (dynStEn == this->m_paramDynStEn)
    {
        this->clearParamData();
    }

    if (this->m_colInfoVector.empty() == false)
    {
        int i = 0;
        for (auto it = this->m_colInfoVector.begin(); it != this->m_colInfoVector.end(); ++it, ++i)
        {
            if (it->m_isDb)
            {
                this->setOneDynFldParam(dynFldStp, i, it->m_columnPos, it->m_dataType, true, false, false, it->m_columnName.c_str(), nullptr, true);
            }
        }
    }
    else
    {
        int            colNumber = GET_FLD_NBR(dynStEn);
        FIELD_IDX_T    colPos = 0;

        std::map<std::string, FIELD_IDX_T> posIdxMap;
        if (this->m_procedureStp != nullptr &&
            this->m_procedureStp->procParamDefPtr != nullptr &&
            (this->m_procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM)
        {
            for (int i = 0; this->m_procedureStp->procParamDefPtr[i].fldNbrPtr != nullptr; ++i)
            {
                posIdxMap[&(this->m_procedureStp->procParamDefPtr[i].paramName[1])] = *(this->m_procedureStp->procParamDefPtr[i].fldNbrPtr);
            }
        }

        for (int i = 0; i < colNumber; i++)
        {
            /* Test if the current field is a non DB field (not returned by the request */
            if ((targetTableEn == TargetTable_Main && IS_MAINFLD(dynStEn, i) == true) ||
                (targetTableEn == TargetTable_UserDefinedFields && IS_CUSTFLD(dynStEn, i) == true) ||
                (targetTableEn == TargetTable_Precomp && IS_PRECOMPFLD(dynStEn, i) == true) ||
                 (targetTableEn == TargetTable_LocalBusinessEntity && IS_ME_PARTIAL(dynStEn, i) == TRUE))
            {
                if (bOnlyPhisical)
                {
                    if (IS_PHISICALFLD(dynStEn, i) == false ||
                        (EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp != nullptr &&
                         (EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp == EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp->dictEntityStp->optimisticLockingAttrStp &&
                          DdlGenDbi::getOptimisticLockingRule(EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp, this->m_dbiConn->m_connectToRDBMS) == OptimisticLocking_DbAttrib &&
                          this->m_batchMode != DbiConnection::BatchMode::TryBCP) ||
                         EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp->primFlg == TRUE &&
                         EV_DynStPtr[dynStEn].dynStDefPtr[i].dictAttribStp->dictEntityStp->pkRuleEn == PkRule_Identity &&
                         this->m_dbiConn->m_insertIdentityOn == false))
                    {
                        continue;
                    }
                }
                FIELD_IDX_T fieldIdx = i;

                if (posIdxMap.empty() == false &&
                    posIdxMap.find(*GET_FLD_SQLNAME(dynStEn, i)) != posIdxMap.end())
                {
                    fieldIdx = posIdxMap[*GET_FLD_SQLNAME(dynStEn, i)];
                }
                this->setOneDynFldParam(dynFldStp, fieldIdx, colPos++, NullDataType, true, false, false, *GET_FLD_SQLNAME(dynStEn, i), nullptr, true);
            }
        }

        this->m_paramDynStEn = dynStEn;
    }
    this->m_paramDataStp = dynFldStp;
}

/************************************************************************
*   Function             :  RequestHelper:setDefDynSt()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200528
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setDefDynSt(DBA_ENTITY_NAT_ENUM entityNatEn, const std::string &dbName, const std::string &tableName, const std::vector<DbiColInfo> &colInfoVector)
{
    this->m_entityNatEn  = entityNatEn;
    this->m_targetDbName = dbName;
    this->m_tableSqlName = tableName;

    if (this->m_entityNatEn == EntityNat_ReportFmt)
    {
        for (auto it = colInfoVector.begin(); it != colInfoVector.end(); ++it)
        {
            this->m_colInfoVector.push_back(*it);
            this->m_colInfoVector.back().m_columnPos += 2;
        }

        this->m_colInfoVector.push_back(DbiColInfo(0, "r_dataset_id", IdType, true));
        this->m_colInfoVector.push_back(DbiColInfo(1, "r_nature_e", EnumType, true));
    }
    else
    {
        this->m_colInfoVector = colInfoVector;
    }

    this->m_batchObjEn   = NullEntity;
    this->m_paramDynStEn = NullDynSt;
}

/************************************************************************
*   Function             :  RequestHelper:setBatchInfo()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201113
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setBatchInfo(const std::string &dbName, const std::string &tableName, OBJECT_ENUM objectEn)
{
    this->m_targetDbName = dbName;
    this->m_tableSqlName = tableName;
    this->m_batchObjEn   = objectEn;

    this->m_paramDynStEn = NullDynSt;

    this->m_colInfoVector.clear();
}

/************************************************************************
*   Function             :  RequestHelper:setOneDynFldParam()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setOneDynFldParam(DBA_DYNFLD_STP  dynFldStp,
                                      FIELD_IDX_T     fieldIdx,
                                      FIELD_IDX_T     colPos,
                                      DATATYPE_ENUM   dataTypeEn,
                                      bool            bInputParam,
                                      bool            bOutputParam,
                                      bool            bOutputOnlyParam,
                                      const char     *sqlName,
                                      FIELD_IDX_T    *indexedFieldIdxPtr,
                                      bool            setDefaultFld)
{
    DBA_DYNST_ENUM dynStEn          = GET_DYNSTENUM(dynFldStp);
    DbiInOutData*  newOutputDataPtr = nullptr;

    this->m_paramPos = colPos;

    if (dataTypeEn == NullDataType)
    {
        dataTypeEn = GET_FLD_TYPE(dynStEn, fieldIdx);
    }

    if (setDefaultFld)                     /* PMSTA-42378 - DDV - 201109 - Do it only when setDefaultFld is true (used for Insert, Update and InsUpd) */
    {
        if (dynStEn != NullDynSt &&
            dynStEn != InvalidDynSt &&
            IS_NULLFLD(dynFldStp, fieldIdx) == TRUE &&
            (dataTypeEn == EnumType || dataTypeEn == FlagType))
        {
            if (EV_DynStPtr[dynStEn].dynStDefPtr[fieldIdx].dictAttribStp != nullptr &&
                EV_DynStPtr[dynStEn].dynStDefPtr[fieldIdx].dictAttribStp->dfltVal.empty() == false)
            {
                if (dataTypeEn == EnumType)
                {
                    SET_ENUM(dynFldStp, fieldIdx, static_cast<ENUM_T>(atoi(EV_DynStPtr[dynStEn].dynStDefPtr[fieldIdx].dictAttribStp->dfltVal.c_str())));
                }
                else
                {
                    SET_FLAG(dynFldStp, fieldIdx, static_cast<FLAG_T>(atoi(EV_DynStPtr[dynStEn].dynStDefPtr[fieldIdx].dictAttribStp->dfltVal.c_str())));
                }
            }
            else
            {
                if (dataTypeEn == EnumType)
                {
                    SET_ENUM(dynFldStp, fieldIdx, 0);
                }
                else
                {
                    SET_FLAG_FALSE(dynFldStp, fieldIdx);
                }
            }
        }
    }
    else /* PMSTA-49605 - DDV - 201120 */
    {
        if (IS_NULLFLD(dynFldStp, fieldIdx) == TRUE &&
            dataTypeEn == FlagType)
        {
            SET_FLAG(dynFldStp, fieldIdx, 0);
        }
    }

    if (IS_NULLFLD(dynFldStp, fieldIdx) == TRUE)
    {
        switch (GET_CTYPE(dataTypeEn))
        {
            case UniCharPtrCType:
            case UniTextPtrCType:
                if (this->m_dbiConn->isUtf16Allowed())
                {
                    newOutputDataPtr = this->addNewParam(dataTypeEn);
                }
                else
                {
                    newOutputDataPtr = this->addNewParam(DBA_ConvDataTypeToIsoDataType(dataTypeEn));
                }
                break;

            default:
                newOutputDataPtr = this->addNewParam(dataTypeEn);
        }
    }
    else
    {
        switch (GET_CTYPE(dataTypeEn))
        {
            case DoubleCType:
                newOutputDataPtr = this->addNewParamDouble(GET_DOUBLE(dynFldStp, fieldIdx), dataTypeEn);

                if (this->m_lastRetCode == RET_SRV_LIB_ERR_DB_OVERFLOW)
                {
                    if (this->m_tableSqlName.empty())
                    {
                        MSG_LogMesg(this->m_lastRetCode, 3, FILEINFO, DBA_GetDynStCName(dynStEn), fieldIdx, sqlName, GET_DOUBLE(dynFldStp, fieldIdx));
                    }
                    else
                    {
                        MSG_LogMesg(this->m_lastRetCode, 2, FILEINFO, this->m_tableSqlName.c_str(), colPos, sqlName, GET_DOUBLE(dynFldStp, fieldIdx));
                    }

					/* PMSTA-49982 - JBC - 220825 */
					FLAG_T applRoundOverflowOnInsUpdBatch = FALSE;
					GEN_GetApplInfo(ApplRoundOverflowOnInsUpdBatch, &applRoundOverflowOnInsUpdBatch);

					if ((this->m_batchMode != DbiConnection::BatchMode::RowByRow &&
						this->m_transactionMode == TransactionMode::MostAsPossible)
						|| applRoundOverflowOnInsUpdBatch == TRUE)
                    {
                        this->m_bOverFlow   = true;
                        this->m_lastRetCode = RET_SUCCEED;
                    }
                }
                break;

            case IntCType:
                newOutputDataPtr = this->addNewParamInt(GET_INT(dynFldStp, fieldIdx));
                break;

            case UIntCType:
                newOutputDataPtr = this->addNewParamUInt(GET_UINT(dynFldStp, fieldIdx));
                break;

            case ShortCType:
                newOutputDataPtr = this->addNewParamShort(GET_SHORT(dynFldStp, fieldIdx));
                break;

            case UCharCType:
                newOutputDataPtr = this->addNewParamUChar(GET_UCHAR(dynFldStp, fieldIdx));
                break;

            case UShortCType:
                newOutputDataPtr = this->addNewParamUShort(GET_USHORT(dynFldStp, fieldIdx));
                break;

            case DateTimeStCType:
                newOutputDataPtr = this->addNewParamDatetime(GET_DATETIMEST(dynFldStp, fieldIdx));
                break;

            case CharPtrCType:
            case TextPtrCType:
                if (this->m_dbiConn->getCurrCharsetEn() != this->m_dbiConn->getDbCommCharsetEn())
                {
                    auto charSet = ICU4AAA_GetCharSet(GET_STRING(dynFldStp, fieldIdx));

                    if (charSet != CurrentCharsetCode_Ascii_7 &&
                        charSet != CurrentCharsetCode_UTF8)
                    {
                        int    cursorLen = static_cast<int>(strlen(GET_STRING(dynFldStp, fieldIdx)) + 1);
                        int    uCharLen = 0;
                        int    isoLen = 0;
                        UChar* cursorUChar = static_cast<UChar*>(CALLOC(cursorLen, sizeof(UChar)));
                        ICU4AAA_ConvertFromDefaultCharSet(GET_STRING(dynFldStp, fieldIdx), cursorLen, cursorUChar, cursorLen, &uCharLen, this->m_dbiConn->getCurrCharsetEn());

                        cursorLen *= 4;
                        char* utf8Char = static_cast<char*>(CALLOC(cursorLen, sizeof(char)));
                        ICU4AAA_ConvertToUTF8(cursorUChar, uCharLen, utf8Char, cursorLen, &isoLen);

                        newOutputDataPtr = this->addNewParamCharPtr(utf8Char, dataTypeEn);

                        FREE(cursorUChar);
                        FREE(utf8Char);
                    }
                    else
                    {
                        newOutputDataPtr = this->addNewParamCharPtr(GET_STRING(dynFldStp, fieldIdx), dataTypeEn);
                    }
                }
                else
                {
                    newOutputDataPtr = this->addNewParamCharPtr(GET_STRING(dynFldStp, fieldIdx), dataTypeEn);
                }
                break;

            case UniCharPtrCType:
            case UniTextPtrCType:
                if (this->m_dbiConn->isUtf16Allowed() == false)
                {
                    char *cursorIso = nullptr;
                    int   isoLen = 0;

                    ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(dynFldStp, fieldIdx), -1, &cursorIso, &isoLen, this->m_dbiConn->getDbCommCharsetEn());
                    newOutputDataPtr = this->addNewParamCharPtr(cursorIso, DBA_ConvDataTypeToIsoDataType(dataTypeEn));

                    FREE(cursorIso);
                }
                else
                {
                    newOutputDataPtr = this->addNewParamUCharPtr(GET_USTRING(dynFldStp, fieldIdx), dataTypeEn);
                }
                break;

            case LongLongCType:
                if (dataTypeEn == IdType || dataTypeEn == DictType)
                {
                    newOutputDataPtr = this->addNewParamId(GET_ID(dynFldStp, fieldIdx), dataTypeEn);
                }
                else
                {
                    newOutputDataPtr = this->addNewParamLongLong(GET_LONGLONG(dynFldStp, fieldIdx));
                }
                break;

            case TimeStampCType:
                newOutputDataPtr = this->addNewParamTimeStamp(_GET_TIMESTAMP(dynFldStp, fieldIdx));
                break;

            case BinaryCType:
                newOutputDataPtr = this->addNewParamBinary(_GET_BINARY(dynFldStp, fieldIdx));
                break;

            case ExtPtrCType:
                /* PMSTA-34344 - LJE - 201221 - Allow extensions for GUI without Database... */
                if (GET_EXTENSION_NBR(dynFldStp, fieldIdx) > 0 &&
                    GET_EXTENSION_PTR(dynFldStp, fieldIdx) != nullptr)
                {
                    newOutputDataPtr = this->addNewParamDynStp(GET_EXTENSION_PTR(dynFldStp, fieldIdx)[0]);
                }
                break;

            case ArrayPtrCType:
            case MultiArrayPtrCType:
            case VarCharPtrCType:
            case VarTextPtrCType:
            case PtrCType:
            default:
                assert(dataTypeEn == LastCtype);
        }
    }

    if (newOutputDataPtr != nullptr)
    {
        newOutputDataPtr->m_sqlName       = sqlName;
        newOutputDataPtr->m_fieldIdx      = fieldIdx;
        newOutputDataPtr->m_colPos        = colPos;
        newOutputDataPtr->m_bInput        = bInputParam;
        newOutputDataPtr->m_bOutput       = bOutputParam;
        newOutputDataPtr->m_bOutputOnly   = bOutputOnlyParam;
        newOutputDataPtr->m_paramDataType = dataTypeEn;
        newOutputDataPtr->m_nullInd       = (IS_NULLFLD(dynFldStp, fieldIdx) == TRUE ? DBI_NULLDATA : DBI_GOODDATA);

        if (indexedFieldIdxPtr != nullptr && *indexedFieldIdxPtr != Null_Dynfld)
        {
            newOutputDataPtr->setOutputDynFldStp(&dynFldStp[*indexedFieldIdxPtr]);
            newOutputDataPtr->m_outputFieldIdx = *indexedFieldIdxPtr;
        }
        else if (newOutputDataPtr->m_bOutput)
        {
            newOutputDataPtr->setOutputDynFldStp(&dynFldStp[fieldIdx]);
            newOutputDataPtr->m_outputFieldIdx = fieldIdx;
        }

        if (bOutputParam &&
            this->m_dbiConn->getCurrentAction() == Custom)
        {
            this->m_dbiConn->setCurrentAction(AllStdProcs);
        }
    }
}

/************************************************************************
*   Function             :  RequestHelper:readAllRecord()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::readAllRecord(int *rowsNbr, DBA_DYNFLD_STP **outputData)
{
    int			   packetSize = 100, maxPacketSize = 100000;
    DBA_DYNFLD_STP *resultData = NULL;
    if ((resultData = (DBA_DYNFLD_STP *)CALLOC(packetSize, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        this->m_lastRetCode = RET_MEM_ERR_ALLOC;
        return(this->m_lastRetCode);
    }

    this->m_lastRetCode = RET_SUCCEED;

    FIELD_IDX_T portPosSetIdField = Null_Dynfld;

    if (this->m_outputDynStEn == ExtPos)
    {
        portPosSetIdField = ExtPos_PtfPosSetId;
    }
    else if (this->m_outputDynStEn == A_PtfSynth)
    {
        portPosSetIdField = A_PtfSynth_PtfPosSetId;
    }
    else if (this->m_outputDynStEn == S_PtfSynth)
    {
        portPosSetIdField = S_PtfSynth_PtfPosSetId;
    }
    else if (this->m_outputDynStEn == ExtOp)
    {
        portPosSetIdField = ExtOp_PortPosSetId;
    }

    /* Loop on each record */
    int  cpt = 0;
    while (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR &&
           this->fetch() == RET_SUCCEED)
    {
        if ((resultData[cpt] = ALLOC_DYNST(this->m_outputDynStEn)) == nullptr)
        {
            this->m_lastRetCode = RET_MEM_ERR_ALLOC;
        }
        else
        {
            this->readData(resultData[cpt]);

            if (portPosSetIdField != Null_Dynfld &&
                IS_NULLFLD(resultData[cpt], portPosSetIdField) == FALSE &&
                GET_ID(resultData[cpt], portPosSetIdField) == 0)
            {
                SET_NULL_ID(resultData[cpt], portPosSetIdField);
            }

            ++cpt;

            if (cpt % packetSize == 0)
            {
                if (packetSize < maxPacketSize)
                {
                    packetSize *= 10;
                }

                DBA_DYNFLD_STP *oldResultPtr = resultData;
                resultData = (DBA_DYNFLD_STP *)REALLOC(resultData, (cpt + packetSize) * sizeof(DBA_DYNFLD_STP));

                /* If allocation failed */
                if (resultData == nullptr)
                {
                    resultData = oldResultPtr;
                    this->m_lastRetCode = RET_MEM_ERR_ALLOC;
                }
                else
                {
                    memset((void *)(resultData + cpt), 0, packetSize * sizeof(DBA_DYNFLD_STP));
                }
            }
        }
    }

    if (this->m_lastRetCode != RET_DBA_INFO_NO_MORE_DATA)
    {
        if (resultData != nullptr)
        {
            for (int i = 0; i < cpt; i++)
                FREE_DYNST(resultData[i], this->m_outputDynStEn);
            FREE(resultData);
        }
        if(this->m_lastRetCode != RET_SRV_LIB_ERR_DEADLOCK)
            this->m_lastRetCode = RET_DBA_ERR_DBPROBLEM;
        return(this->m_lastRetCode);
    }

    this->m_lastRetCode = RET_SUCCEED;

    if (cpt == 0)
    {
        FREE(resultData);
    }

    /* Memorize the number of retrieved rows in the result set */
    if (rowsNbr != nullptr)
        *rowsNbr = cpt;

    if (outputData != nullptr)
        *outputData = resultData;

    return (this->m_lastRetCode);
}

/************************************************************************
*   Function             :  RequestHelper:readOneRecord()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190909
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::readOneRecord(DBA_DYNFLD_STP dynFldStp)
{
    this->m_lastRetCode = RET_SUCCEED;

    if (RET_GET_LEVEL(this->m_lastRetCode) != RET_LEV_ERROR && this->fetch() == RET_SUCCEED)
    {
        this->readData(dynFldStp);
    }

    return (this->m_lastRetCode);
}

/************************************************************************
*   Function             :  RequestHelper:readData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::readData(DBA_DYNFLD_STP dynFldStp)
{
    DBA_DYNST_ENUM dynStEn = GET_DYNSTENUM(dynFldStp);
    auto &requestOutputVector = this->m_dbiConn->getRequestOutputVector();

    for (auto &it : requestOutputVector)
    {
        DbiInOutData *outputDataPtr = it;
        int ret = TRUE;

        if (outputDataPtr->m_nullInd == DBI_GOODDATA)
        {
            switch (GET_CTYPE(outputDataPtr->m_dataType))
            {
                case DoubleCType:
                    SET_DOUBLE(dynFldStp, outputDataPtr->m_fieldIdx, GET_DOUBLE(outputDataPtr->getDynFldStp(), 0));
                    break;

                case IntCType:
                    SET_INT(dynFldStp, outputDataPtr->m_fieldIdx, GET_INT(outputDataPtr->getDynFldStp(), 0));
                    break;

                case UIntCType:
                    SET_UINT(dynFldStp, outputDataPtr->m_fieldIdx, GET_UINT(outputDataPtr->getDynFldStp(), 0));
                    break;

                case ShortCType:
                    SET_SHORT(dynFldStp, outputDataPtr->m_fieldIdx, GET_SHORT(outputDataPtr->getDynFldStp(), 0));
                    break;

                case UCharCType:
                    SET_UCHAR(dynFldStp, outputDataPtr->m_fieldIdx, GET_UCHAR(outputDataPtr->getDynFldStp(), 0));
                    break;

                case UShortCType:
                    SET_USHORT(dynFldStp, outputDataPtr->m_fieldIdx, GET_USHORT(outputDataPtr->getDynFldStp(), 0));
                    break;

                case DateTimeStCType:
                    SET_DATETIMEST(dynFldStp, outputDataPtr->m_fieldIdx, GET_DATETIMEST(outputDataPtr->getDynFldStp(), 0));
                    break;

                case CharPtrCType:
                case TextPtrCType:
                {
                    char *value    = GET_STRING(outputDataPtr->getDynFldStp(), 0);

                    if (this->m_dbiConn->getDbCommCharsetEn() != this->m_currCharSet &&
                        ICU4AAA_GetCharSet(value) != CurrentCharsetCode_Ascii_7)
                    {
                        int cursorLen = (int)strlen(value) + 1, uCharLen = 0, isoLen = 0;

                        if (cursorLen > this->m_currUCharSize)
                        {
                            this->m_currUChar = static_cast<UChar *>(this->m_requestMp.realloc(this->m_currUChar, cursorLen * sizeof(UChar)));
                            this->m_currChar = static_cast<char *>(this->m_requestMp.realloc(this->m_currChar, cursorLen * sizeof(char)));
                            this->m_currUCharSize = cursorLen;
                        }

                        ICU4AAA_ConvertFromDefaultCharSet(value, cursorLen, this->m_currUChar, cursorLen, &uCharLen, this->m_dbiConn->getDbCommCharsetEn());
                        ICU4AAA_ConvertToDefaultCharSet(this->m_currUChar, uCharLen, &this->m_currChar, &isoLen, this->m_currCharSet);

                        value = this->m_currChar;
                    }

                    ret = _SET_STRING(dynFldStp, outputDataPtr->m_fieldIdx, value);
                    break;
                }

                case UniCharPtrCType:
                case UniTextPtrCType:
                    ret = _SET_USTRING(dynFldStp, outputDataPtr->m_fieldIdx, GET_USTRING(outputDataPtr->getDynFldStp(), 0));
                    break;

                case LongLongCType:
                    SET_LONGLONG(dynFldStp, outputDataPtr->m_fieldIdx, GET_LONGLONG(outputDataPtr->getDynFldStp(), 0));
                    break;

                case TimeStampCType:
                    SET_TIMESTAMP(dynFldStp, outputDataPtr->m_fieldIdx, GET_TIMESTAMP(outputDataPtr->getDynFldStp(), 0));
                    break;

                case BinaryCType:
                    SET_BINARY(dynFldStp, outputDataPtr->m_fieldIdx, GET_BINARY(outputDataPtr->getDynFldStp(), 0));
                    break;

                case ArrayPtrCType:
                case MultiArrayPtrCType:
                case VarCharPtrCType:
                case VarTextPtrCType:
                case ExtPtrCType:
                case PtrCType:
                default:
                    assert(GET_CTYPE(outputDataPtr->m_dataType) == LastCtype);
            }
        }
        else
        {
            SET_NULL(dynFldStp, outputDataPtr->m_fieldIdx, outputDataPtr->m_dataType);
        }

        if (ret == FALSE)
        {
            RESET_DYNST_TAB(dynFldStp, GET_FLD_NBR(dynStEn))
            this->m_lastRetCode = RET_MEM_ERR_ALLOC;

            return (this->m_lastRetCode);
        }
    }

    int colNumber = GET_FLD_NBR(dynStEn);
    for (int i = 0; i < colNumber; i++)
    {
        if (_IS_NULLFLD(dynFldStp, i) == TRUE &&
            _IS_NULLFLD(this->m_defOutDataStp, i) == FALSE &&
            IS_DBFLD(dynStEn, i) == FALSE)
        {
            COPY_DYNFLD(dynFldStp, dynStEn, i, this->m_defOutDataStp, dynStEn, i);
        }
    }

    return (this->m_lastRetCode);
}

/************************************************************************
*   Function             :  RequestHelper:setBatchASync()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201116
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setBatchASync()
{
    this->m_bBatchASync = true;
}

/************************************************************************
*   Function             :  RequestHelper:setParallel()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240719
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setParallel(unsigned parallel)
{
    this->m_parallel = parallel;

    if (this->m_parallel > 1)
    {
        this->setBatchASync();
    }
}

/************************************************************************
*   Function             :  RequestHelper:getParallel()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240719
*
*   Last Modification    :
*
*************************************************************************/
unsigned RequestHelper::getParallel()
{
    return this->m_parallel;
}

/************************************************************************
*   Function             :  RequestHelper:optimDataAlloc()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200907
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::optimDataAlloc()
{
    this->m_bOptimDataAlloc = true;
    this->m_dbiConn->setOptimDataAlloc();
    this->m_availableRecordsVector.reserve(this->getBatchBlockSize() * 2);
}

/************************************************************************
*   Function             :  RequestHelper:useNativeQueryForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 200907
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::useNativeQueryForBatch()
{
    this->m_bUseNativeQuery = true;
}

/************************************************************************
*   Function             :  RequestHelper:useProcQueryForBatch()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 231206
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::useProcQueryForBatch()
{
    this->m_bUseNativeQuery = false;
}


/************************************************************************
*   Function             :  RequestHelper:isSubscription()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 240422
*
*   Last Modification    :
*
*************************************************************************/
bool RequestHelper::isSubscription(DBA_PROC_STP procedureStp, DBA_DYNFLD_STP recordStp)
{
    if (procedureStp == nullptr || 
        recordStp    == nullptr || 
        (procedureStp->action != Insert &&
         procedureStp->action != Update &&
         procedureStp->action != Delete &&
         procedureStp->action != InsUpd))
    {
        return false;
    }

    if (((procedureStp->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION) &&
        (procedureStp->subObj != DBA_ROLE_UPD_UD_FIELDS) &&
        ((DBA_IsSubscriptionActive(recordStp->getObjectEn()) == TRUE) &&
         (procedureStp->subObj != DBA_ROLE_UPDSTATUS_NOSUBSCRIPTION) &&
         (procedureStp->server != InternalProc) && (EV_IsSubscriptionActive == TRUE) &&
         (recordStp->getObjectEn() != EOp) && (this->getDbiConn().getConnStructPtr()->blockMode == FALSE)))
    {
        auto dictEntityStp = recordStp->getDictEntityStp();

        if (dictEntityStp != nullptr)
        {
            auto inSubscriptionSt = this->m_requestMp.allocDynst(FILEINFO, A_Subscription);

            SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, dictEntityStp->entDictId);
            SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, static_cast<ENUM_T>((procedureStp->action == Insert) ? Subscription_Action_Insert :
                                                                                    (procedureStp->action == Delete) ? Subscription_Action_Delete :
                                                                                    Subscription_Action_Update));
            SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, this->getDbiConn().getSubscriptionModuleEn());

            /* Is there any subscription for this entity. */
            DBA_Select2(Subscription,
                        DBA_ROLE_SEL_SUBSCRIPTIONS,
                        A_Subscription,
                        inSubscriptionSt,
                        A_Subscription,
                        &this->m_outSubscriptionTab,
                        DBA_SET_CONN | DBA_NO_CLOSE,
                        UNUSED,
                        &this->m_outSubscriptionNbr,
                        this->getDbiConn());

            this->m_requestMp.ownerDynStpTab(this->m_outSubscriptionTab, this->m_outSubscriptionNbr);

            /*
             * Verify if there are entities to be audited.
             * If so, we have to load and keep the current DYNFLDST from database
             * BEFORE modifying it.
             */

            if (this->m_outSubscriptionNbr > 0)
            {
                /*
                 * Get the old value for the given entity.
                 */
                if (DBA_GetOldDataForAudit(recordStp->getObjectEn(), recordStp->getDynStEn(), recordStp, this->getDbiConn(), FALSE) != RET_SUCCEED)
                {
                    return false;
                }
                this->m_oldRecordStp = this->getDbiConn().getConnStructPtr()->subscriptionElem.auditRecStp;
                this->getDbiConn().getConnStructPtr()->subscriptionElem.auditRecStp = NULL;
            }
        }
    }

    return false;
}

/************************************************************************
*   Function             :  RequestHelper:manageSubscription()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 240422
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::manageSubscription(DBA_DYNFLD_STP recordStp)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_outSubscriptionNbr > 0)
    {
        ret = DBA_LogSubscriptionEvents(recordStp->getObjectEn(),
                                        static_cast<SUBSCRIPTION_ACTION_ENUM>(GET_ENUM(this->m_outSubscriptionTab[0], A_Subscription_ActionEn)),
                                        recordStp->getDynStEn(),
                                        recordStp,
                                        this->m_oldRecordStp,
                                        this->getDbiConn(),
                                        this->m_outSubscriptionTab,
                                        this->m_outSubscriptionNbr);
    }

    return ret;
}

/************************************************************************
*   Function             :  RequestHelper:getScriptDdlGenPtr()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49523 - LJE - 220719
*
*   Last Modification    :
*
*************************************************************************/
DdlGenFromFile *RequestHelper::getScriptDdlGenPtr()
{
    return this->m_dbiConn->getScriptDdlGenPtr();
}

/************************************************************************
*   Function             :  RequestHelper:setDynStOutputData()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setDynStOutputData(DBA_DYNST_ENUM dynStEn, TARGET_TABLE_ENUM targetTableEn, bool bOnlyPhisical)
{
    /* Retrieve the field number of a dynamic structure format */
    int colNumber = GET_FLD_NBR(dynStEn);

    this->clearOutputData();

    for (int i = 0; i < colNumber; i++)
    {
        /* Test if the current field is a non DB field (not returned by the request */
        if ((targetTableEn == TargetTable_Undefined            && IS_DBFLD(dynStEn, i) == TRUE) ||
            (targetTableEn == TargetTable_Main                && IS_MAINFLD(dynStEn, i) == true) ||
            (targetTableEn == TargetTable_UserDefinedFields   && IS_CUSTFLD(dynStEn, i) == true) ||
            (targetTableEn == TargetTable_Precomp             && IS_PRECOMPFLD(dynStEn, i) == true) ||
            (targetTableEn == TargetTable_View && IS_DBFLD(dynStEn, i) == TRUE && IS_CALCULATEDFLD(dynStEn, i) == false) ||
            (targetTableEn == TargetTable_LocalBusinessEntity && IS_ME_PARTIAL(dynStEn, i) == TRUE))
        {
            if (bOnlyPhisical && IS_PHISICALFLD(dynStEn, i) == false)
            {
                continue;
            }

            DbiInOutData *newOutputDataPtr = this->addNewOutputData(GET_FLD_TYPE(dynStEn, i), *GET_FLD_SQLNAME(dynStEn, i));
            newOutputDataPtr->m_fieldIdx   = i;
            newOutputDataPtr->m_colPos     = i;
        }
    }

    this->m_outputDynStEn = dynStEn;
    this->m_defOutDataStp = ALLOC_DYNST(this->m_outputDynStEn);

    DBA_SetDfltEntityFld(GET_OBJ_DYNST(dynStEn), dynStEn, this->m_defOutDataStp);
}

/************************************************************************
*   Function             :  RequestHelper:useDb()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::useDb(const std::string &dbSqlName)
{
    if (this->m_previousDbSqlName.empty())
    {
        this->m_previousDbSqlName = this->m_dbiConn->getTargetSessionProperties().getDbName();
    }
    this->m_dbiConn->setDbName(dbSqlName);

    if (this->m_batchMode == DbiConnection::BatchMode::TryBCP)
    {
        this->m_targetDbName = dbSqlName;
    }
}

/************************************************************************
*   Function             :  RequestHelper::ASyncBatchInfo::ASyncBatchInfo()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::ASyncBatchInfo::ASyncBatchInfo(RequestHelper* requestHelperPtr,
                                              bool           bForceFlush)
    : m_requestHelperPtr(requestHelperPtr)
    , m_bForceFlush(bForceFlush)
    , m_retCode(RET_SUCCEED)
{
}

/************************************************************************
*   Function             :  RequestHelper::ASyncBatchInfo::~ASyncBatchInfo()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::ASyncBatchInfo::~ASyncBatchInfo()
{
}

/************************************************************************
*   Function             :  RequestHelper::ParallelBatchInfo::ParallelBatchInfo()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::ParallelBatchInfo::ParallelBatchInfo(RequestHelper*                     requestHelperPtr, 
                                                    bool                               bForceFlush, 
                                                    const std::vector<DBA_DYNFLD_STP>& recordsForBatch,
                                                    DdlGenMsg*                         ddlGenMsgPtr)
    : m_requestHelperPtr(requestHelperPtr)
    , m_ddlGenMsgPtr(nullptr)
    , m_recordsForBatch(recordsForBatch)
    , m_bForceFlush(bForceFlush)
    , m_retCode(RET_SUCCEED)
    , m_writeDuration(0)
{
    if (ddlGenMsgPtr != nullptr)
    {
        this->m_ddlGenMsgPtr = new DdlGenMsg(*ddlGenMsgPtr);
        this->m_mp.ownerObject(this->m_ddlGenMsgPtr);
    }
}


/************************************************************************
*   Function             :  RequestHelper::ParallelBatchInfo::~ParallelBatchInfo()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-55968 - LJE - 240722
*
*   Last Modification    :
*
*************************************************************************/
RequestHelper::ParallelBatchInfo::~ParallelBatchInfo()
{
    auto infoStr = SYS_Stringer(" (", this->m_recordsForBatch.size(), " rows loaded in ", this->m_writeDuration.count(), " sec)");

    const AAALogger& logger = AAALogger::getApplicationLogger();
    if (logger.isInfoEnabled())
    {
        logger.info(infoStr);
    }

    if (this->m_ddlGenMsgPtr != nullptr &&
        this->m_ddlGenMsgPtr->getSilentMode() == false)
    {
        this->m_ddlGenMsgPtr->printMsg(this->m_retCode, infoStr);
    }
}


/************************************************************************
*   Function             :  RequestHelper:setDbNameOption()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
void RequestHelper::setDbNameOption(const std::string& dbNameOption)
{
    this->m_dbiConn->m_dbNameOption = dbNameOption;
}

/************************************************************************
*   Function             :  RequestHelper:getLastStatus()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getLastStatus()
{
    return this->m_lastStatus;
}

/************************************************************************
*   Function             :  RequestHelper:getLastResultType()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
int RequestHelper::getLastResultType()
{
    if (this->m_dbiConn == nullptr)
    {
        return DBI_CMD_FAIL;
    }
    return this->m_dbiConn->m_lastResultType;
}

/************************************************************************
*   Function             :  RequestHelper:getLastResultRetCode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getLastResultRetCode()
{
    if (this->m_dbiConn == nullptr)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }
    return this->m_dbiConn->m_lastResultRetCode;
}

/************************************************************************
*   Function             :  RequestHelper:getLastRetCode()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37366 - LJE - 190425
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE RequestHelper::getLastRetCode()
{
    return this->m_lastRetCode;
}

/************************************************************************
*   Function             :  RequestHelper::dbaGetMsgStructHeader()
*
*   Description          :  return the message structure Header ptr filled after a call to dbaInsertByBlock function if an error occurs
*
*   Arguments            :  None
*
*   Return               :  DBA_ERRMSG_INFOS_STP
*
*************************************************************************/
DBA_ERRMSG_HEADER_ST &RequestHelper::getMsgStructHeader()
{
    return this->m_dbiConn->m_msgStructHeaderSt;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaCreateTempTables()
*
*   Description          :  Move errors message if any
*
*   Arguments            :  tmpTablesMask   Temporary table mask
*
*   Return               :  true    Ok
*                           false   Error with the connection or the creation of any temporary table
*
*   Creation Date        :  PMSTA-26258 - 080217 - PMO : Fusion Process Very Slow, Dispatcher going down
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::dbaCreateTempTables(const int tmpTablesMask)
{
    bool ret = isValidAndInit();

    if (true == ret)
    {
        ret = RET_SUCCEED == DBA_CreateTempTables(*getConnection(), tmpTablesMask);
    }

    return ret;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::execSqlExecByBloc()
*
*   Description          :  Executes the queries by block
*
*   Arguments            :  sqlExec SQL queries
*
*   Return               :  RET_CODE
*
*   Creation Date        :  PMSTA-26258 - 080217 - PMO : Fusion Process Very Slow, Dispatcher going down
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::execSqlExecByBloc(DbiSqlExecByBlock & sqlExec)
{
    RET_CODE ret = RET_DBA_ERR_CONNOTFOUND;

    if (true == isValidAndInit())
    {
        ret = sqlExec.execSqlExecByBloc(getConnection());
    }

    return ret;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::getConnectedBusinessEntityId()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171121
*
*   Last Modification    :
*
*************************************************************************/
ID_T DbiConnectionHelper::getConnectedBusinessEntityId()
{
    if (true == this->isValidAndInit())
    {
        return this->getConnection()->getConnSessionProperties().getBusinessEntityId();
    }
    return ZERO_ID;
}

/************************************************************************
*   Function        :   isConnBusEntityEqualTo
*
*   Description     :   Utility that checks if the BE is changes and the connection should be
*                       reset.
*
*   Arguments       :  expectedBeCode - desired entity
*
*  Returns          :
*
*   Creation Date   :   PMSTA-39774 - JBC - 200207
*
*   Last Modif.     :
*
*************************************************************************/
bool DbiConnectionHelper::isConnBusEntityEqualTo(const std::string & expectedBeCode)
{
    if(GEN_IsMultiEntity())
    {
        static auto busEntityCds = SYS_GetApplSessionRankedBusEntCds(true);
        static auto busEntityNb = static_cast<int>(busEntityCds.size());
        const  auto currConnBusEntityId = getConnectedBusinessEntityId();
        std::string currConnBusEntityCd;
        /* lookups */
        for (int i = 0; i < busEntityNb;i++)
        {
            if(busEntityCds[i].second == currConnBusEntityId)
            {
                currConnBusEntityCd = busEntityCds[i].first;
                break;
            }
        }

       if(expectedBeCode != currConnBusEntityCd)
        {
            return false;
        }
    }

    return true;
}

/************************************************************************
*   Function        :   isConnBusEntityEqualTo
*
*   Description     :   Utility that checks if the BE is changes and the connection should be
*                       reset.
*
*   Arguments       :  expectedBeId - desired entity
*
*  Returns          :
*
*   Creation Date   :   PMSTA-43265 - JBC - 210118
*
*   Last Modif.     :
*
*************************************************************************/
bool DbiConnectionHelper::isConnBusEntityIdEqualTo(const ID_T expectedBeId)
{
    if(GEN_IsMultiEntity())
    {
        return  expectedBeId == getConnectedBusinessEntityId();
    }
    return true;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isHttp()
*
*   Description          :  Is it an http connection ?
*
*   Arguments            :  None
*
*   Return               :  true  yes
*                           false no
*
*   Creation Date        :  PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isHttp()
{
    return nullptr != m_dbiConn && QtHttp == m_dbiConn->getDbaRDBMS();
}


/************************************************************************
*   Function             :  DbiConnectionHelper::isBlockMode()
*
*   Description          :  Is Block Mode activated
*
*   Arguments            :  None
*
*   Return               :  true  yes
*                           false no
*
*   Creation Date        :  HFI-PMSTA-52884-2023-04-21
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isBlockMode()
{
    return nullptr != m_dbiConn && TRUE == m_dbiConn->getConnStructPtr()->blockMode;
}


/************************************************************************
*   Function             :  DbiConnectionHelper::httpReceiveFile()
*
*   Description          :  Allow to save a retrived file through HTTP (ONLY!)
*
*   Arguments            :  outputFileName  Full path file name where the file will be written
*                           request         A std::string that will be checked and parsed on the server
*
*   Return               :  RET_DBA_ERR_EXT_SERVICE_FAILURE if the connection is not of type HTTP
*
*   Creation Date        :  PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::httpReceiveFile(const std::string & outputFileName, const std::string & rpcName, const std::string & request)
{
    RET_CODE ret = RET_DBA_ERR_EXT_SERVICE_FAILURE;

    if (isValidAndInit() && isHttp())
    {
        ret = HTTP_GetFileChunk(*m_dbiConn, rpcName, outputFileName, request);
    }

    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setGUIBehavior()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201223
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::setGUIBehavior()
{
    this->m_isGUIBehavior = true;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::isGUIBehavior()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201223
*
*   Last Modification    :
*
*************************************************************************/
bool DbiConnectionHelper::isGUIBehavior()
{
    return this->m_isGUIBehavior;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::setFromDbaAccess()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 231102
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::setFromDbaAccess()
{
    this->m_fromDbaAccess = true;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::resetFromDbaAccess()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 231102
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::resetFromDbaAccess()
{
    this->m_fromDbaAccess = false;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::dbaSqlExec()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-29159 - 111217 - PMO : Financial server crash while running the PerformanceAnalysis/PVN_PMSTA_11389 TaAutomator test case
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbiConnectionHelper::dbaSqlExec(const std::string & sqlCmd)
{
    RET_CODE ret = RET_DBA_ERR_CONNOTFOUND;

    if (true == this->isValidAndInit()) /* PMSTA-28705 - DDV - 180302 */
    {
        ret= this->m_dbiConn->sqlExecSt(sqlCmd.c_str());
    }

    return ret;
}

/************************************************************************
*   Function             :  DbiConnectionHelper::updateServerPoolCfg()
*
*   Description          :  update the server pool cache
*
*   Arguments            :  poolName
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void DbiConnectionHelper::updateServerPoolCfg(const std::string& poolName)
{
    AAAConnectionDescription desc = getDescription();

    if (desc.getServerName().compare(poolName) == 0)
    {
        desc.updateSrvPoolCfg();
    }
}

DBI_MsgError::DBI_MsgError()
{
}

DBI_MsgError::~DBI_MsgError()
{
}

bool DBI_MsgError::isTechMsg(RET_CODE retCode)
{
    bool ret = false;
    switch (retCode)
    {
        case RET_SRV_LIB_ERR_CONNFAILED:
        case RET_SRV_LIB_ERR_COMMAND_ABORTED:
        case RET_SRV_LIB_ERR_STORED_PROC:
        case RET_SRV_LIB_ERR_DB_TABLE:
        case RET_SRV_LIB_ERR_PARAMNOTSUPPLIED:
        case RET_SRV_LIB_ERR_PERM_DENIED:
        case RET_SRV_LIB_ERR_FOREIGNKEY:
        case RET_SRV_LIB_ERR_CHECKCONSTRAINT:
        case RET_SRV_LIB_ERR_DIVIDE_BY_ZERO:
        case RET_SRV_LIB_ERR_DB_OVERFLOW:
        case RET_SRV_LIB_ERR_INVALID_USER_IN_DB:
        case RET_DBA_ERR_LOGIN:
        case RET_SRV_LIB_ERR_DB_IS_FULL:
        case RET_SRV_LIB_ERR_PROC_CACHE_MEMORY:
        case RET_SRV_LIB_ERR_CONVERSION:
        case RET_SRV_LIB_ERR_INV_PARAM_VALUE:
        case RET_SRV_LIB_ERR_NO_NUM_INPASSWORD:
            ret = true;
            break;

        case RET_SRV_LIB_ERR_DUPLICATEKEY:
        case RET_DBA_INFO_EXTERNAL_SEQ:
        case RET_SRV_LIB_ERR_TRIGGER_MSG:
        case RET_SRV_INFO_TRIGGER_MSG:
        case RET_SRV_LIB_ERR_NULLCOLVALUE:
        case RET_SRV_LIB_ERR_DEADLOCK:
        case RET_SRV_LIB_ERR_SYNTAX:
        case RET_SRV_LIB_ERR_LIMITEXCEED:
        case RET_SUCCEED:
            break;
        default:
            ret = true;
            break;
    }
    return ret;
}

DbiSqlTrace::DbiSqlTrace()
{
    this->m_retCode = RET_GEN_INFO_NOACTION;
    this->m_fmtRowNbr = NO_VALUE;
    this->m_logLevel = AAALogger::Level::Trace;
    this->m_mode = DbiSqlTrace::Mode::Undefined;

    DATE_ResetTimer(&this->m_timer, TIMER_MASK_GEN);
    DATE_StartTimer(&this->m_timer, TIMER_MASK_GEN);

    this->m_startTime_ms = DATE_currentMilliSecsSinceEpoch();
}



void DbiSqlTrace::clear()
{
    this->m_command.clear();
    this->m_procedure.clear();
    this->m_request.str(std::string());
    this->m_request.clear();
    this->m_retCode = RET_GEN_INFO_NOACTION;
    this->m_logLevel = AAALogger::Level::Trace;
    this->m_fmtEltInfo.clear();
    this->m_fmtRowNbr = NO_VALUE;
    this->m_mode = DbiSqlTrace::Mode::Undefined;
    DATE_ResetTimer(&this->m_timer, TIMER_MASK_GEN);
    DATE_StartTimer(&this->m_timer, TIMER_MASK_GEN);
    this->m_startTime_ms = DATE_currentMilliSecsSinceEpoch();;
}

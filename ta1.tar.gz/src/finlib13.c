/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB13_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define STDLIB_H

#include "unidef.h"         /* Mandatory */
#include "fin.h"
#include "scptyl.h"
#include "fus.h"  /* PMSTA-38314 - sanand - 29012020 */
#include "fmtorder.h"
#include "fmtlib01.h"

/************************************************************************
**      External entry points
**
** Ex	FIN_InsUpdModelConstrData     Update extended modeling constraint.
************************************************************************/

STATIC RET_CODE FIN_hierGroupOrder(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP *extOpTab,
    int extOpNbr,
    DBA_DYNFLD_STP  domainPtr,
    DICT_FCT_STP        pdictfctGrouping,
    DICT_FCT_STP        pdictfctOrigin,
    SCPT_FMTDATADEF_STP pscptFmtDataDef,
    bool criteriaChecked,
    int iNbCol);

/************************************************************************
**
**  Function    :   FIN_MceGetMceHist
**
**  Description :   Insert new Modeling Constraint history and update A_ModelConstr.
**
**  Arguments   :   MCPtr	strategy header pointer
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   MCA - 010128 - REF7216
**
*************************************************************************/
RET_CODE FIN_MceGetMceHist(DBA_HIER_HEAD_STP stratHierPtr, DBA_DYNFLD_STP *MCPtr)

{
    RET_CODE			ret       = RET_SUCCEED;
	DBA_DYNFLD_STP     *MCTab     = NULLDYNSTPTR;
    int					MCNbr     = 0;


    *MCPtr = NULLDYNST;

	/* Only one model constraint in hierarchy */
    if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
			                         A_ModelConstr,
			                         FALSE,
                                     NULLFCT,
                                     NULLFCT,
			                         &MCNbr,
                                     &MCTab)) != RET_SUCCEED)
        return(ret);


    if (MCNbr == 1 && MCTab != NULLDYNSTPTR)
        *MCPtr = MCTab[0];
    else
        ret = RET_GEN_ERR_INVARG;

	FREE(MCTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_MceNewMceHist
**  Description :   Insert new strategy history and update A_ModelConstr, ??ExtStratElt and ExtStratLnk
**
**  Arguments   :   stratHierPtr	strategy header pointer
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   RAK - 990915 - REF3729
**  Modif.      :   MCA - 010208 - REF7216
**
*************************************************************************/
RET_CODE FIN_MceNewMceHist(DBA_HIER_HEAD_STP    stratHierPtr, DBA_DYNFLD_STP       modMCPtr)
{
    RET_CODE			ret = RET_SUCCEED;
    DBA_DYNFLD_STP     *MCEltTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP	    MCPtr;
	DBA_HIER_UPDDB_ST	hierUpdDbSt;
    DBA_HIER_MODIF_ENUM state;
    ID_T                newMCId = -1;
    int					i,j =0;
    int					MCEltNbr = 0;
    int                 connectNo = DBA_CONN_NOT_FOUND;

    /* Get current ModelConstr to replace it by modified ModelConstr */
    if ((ret = FIN_MceGetMceHist(stratHierPtr, &MCPtr)) != RET_SUCCEED)
        return(ret);

	/* The creation of ModelConstr must be done inside a transaction */

    /* Get connection */
    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
    {
        MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
    }
    /* Open transaction mode */
    if ((ret = DBA_BeginTransaction(connectNo)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* Get ModelConstrElt */
	if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
			                         A_ModelConstrElt,
			                         FALSE,
                                     NULL,
                                     NULLFCT,
			                         &MCEltNbr,
                                     &MCEltTab)) != RET_SUCCEED)
	{
        return(ret);
    }

	SET_NULL_ID(MCPtr, A_ModelConstr_Id);

   
    COPY_DYNFLD(MCPtr, A_ModelConstr, A_ModelConstr_BeginDate, 
		        (DBA_DYNFLD_STP) modMCPtr, A_ModelConstr, A_ModelConstr_BeginDate);

	COPY_DYNFLD(MCPtr, A_ModelConstr, A_ModelConstr_EndDate,
		        (DBA_DYNFLD_STP) modMCPtr, A_ModelConstr, A_ModelConstr_EndDate);

	COPY_DYNFLD(MCPtr, A_ModelConstr, A_ModelConstr_CompositeFlg,
		        (DBA_DYNFLD_STP) modMCPtr, A_ModelConstr, A_ModelConstr_CompositeFlg);

    ret = DBA_Insert2(ModelConstr,
					  UNUSED,
			          A_ModelConstr,
					  MCPtr,
					  DBA_SET_CONN | DBA_NO_CLOSE,
					  &connectNo);

    if (ret == RET_SUCCEED)
    {
		newMCId = GET_ID(MCPtr, A_ModelConstr_Id);

        for (i=0; i<MCEltNbr && ret == RET_SUCCEED ; i++)
	    {
		    /* Set new ModelConstr identifier toelements */
		    SET_ID(MCEltTab[i], A_ModelConstrElt_ModelConstrId, newMCId);

            ret = DBA_GetHierEltRecState(stratHierPtr,
			                         A_ModelConstrElt,
			                         MCEltTab[j],
                                     &state);

            if (ret == RET_SUCCEED)
            {
                if (state == HierModDel)
                {
                    DBA_DelHierEltRec(stratHierPtr, A_ModelConstrElt, MCEltTab[i]);
                    continue;
                }

			    /* Signal that A_ModelConstrElt must be inserted ... */
			    ret = DBA_SetStatusHierModInsert(stratHierPtr, A_ModelConstrElt, MCEltTab[i]);
		    }
        }
	}

    if (ret == RET_SUCCEED)
    {
	    memset(&hierUpdDbSt, 0, sizeof(DBA_HIER_UPDDB_ST));
	    hierUpdDbSt.hierHead        = stratHierPtr;
	    hierUpdDbSt.hierDynStEn      = A_ModelConstrElt;   /* PMSTA-13295 - JPP - 20111219 */
	    hierUpdDbSt.entity          = ModelConstrElt;
	    hierUpdDbSt.type            = FALSE; /* Don't use link  */
	    hierUpdDbSt.insFct          = FIN_StratInsDbModelConstrElt;
        hierUpdDbSt.transFlag       = FALSE;
        hierUpdDbSt.connectNo       = connectNo;
        hierUpdDbSt.modifOptions    = DBA_SET_CONN | DBA_NO_CLOSE;

        /*
            Insert ModelConstr Element into database
        */
	    ret = DBA_HierUpdateDatabase(&hierUpdDbSt);
    }

    /* Close transaction */
    DBA_EndTransaction(connectNo, (ret == RET_SUCCEED) ? TRUE : FALSE);
    /* Close connection */
    DBA_EndConnection(connectNo);

	FREE(MCEltTab);

	return(ret);
}
/************************************************************************
**
**  Function    :   FIN_StratInsDbStratElt()
**
**  Description :   Insert A_ModelConstrElt in database
**
**  Arguments   :   DBA_HIER_HEAD_STP hierStp
**		    DBA_DYNFLD_STP    MCEltPtr
**		    DBA_DYNST_ENUM    dynStTp
**		    OBJECT_ENUM       entity
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   RAK - 990914 - REF3729
**  Modif	    :  	MCA - 010112 - REF7216 - for modeling constraint elt
**
*************************************************************************/
RET_CODE FIN_StratInsDbModelConstrElt(PTR                     hierHeadPtr,
								      DBA_DYNFLD_STP          MCEltPtr,
								      DBA_DYNST_ENUM          dynStTp,
								      OBJECT_ENUM             entity,
								      int                     insOptions,		/* MDE - 991129 - REF4047 */
									  int                     *allocConn,
                                      DBA_ERRMSG_INFOS_STP     )   /* MDE - 991129 - REF4047 */
{
    RET_CODE            retCode = RET_SUCCEED;
	DBA_DYNFLD_STP      ESEPtr  = NULLDYNST;


	/* Test given arguments */
	if (hierHeadPtr == NULLDYNST ||
	    MCEltPtr    == NULLDYNST ||
	    dynStTp     == NullDynSt ||
	    entity      == NullEntity)
	{
	    MSG_RETURN(RET_GEN_ERR_INVARG);
	}


    /* Get the ESE linked to A_ModelConstrElt */
    if (IS_NULLFLD(MCEltPtr, A_ModelConstrElt_Id) == FALSE)
    {
        ESEPtr = DBA_SearchHierRecById((DBA_HIER_HEAD_STP) hierHeadPtr,
		                               ExtStratElt,
				                       ExtStratElt_ModelConstrEltId,
                                       GET_ID(MCEltPtr, A_ModelConstrElt_Id));

    }

	/* Insert element */
	retCode = DBA_Insert2(entity,
                          UNUSED,
                          dynStTp,
                          MCEltPtr,
                          insOptions,		/* MDE - 991129 - REF4047 */
                          allocConn);	    /* MDE - 991129 - REF4047 */

	if (retCode == RET_SUCCEED)
	{
	    if (ESEPtr != NULLDYNST)
	    {
			SET_ID(ESEPtr, ExtStratElt_ModelConstrEltId, GET_ID(MCEltPtr, A_ModelConstrElt_Id));
	    }
	}

	return(retCode);
}


/************************************************************************
**
**  Function    :   FIN_SelDispModelConstrElt
**
**  Description :   alloc memory to a new constraint element during the edition of a new one
**
**  Arguments   :   stratHierPtr	strategy header pointer
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   MCA - 010129 - REF7216
**
*************************************************************************/
RET_CODE FIN_SelDispModelConstrElt(DBA_HIER_HEAD_STP stratHierPtr, DBA_DYNFLD_STP**MCEltTab, int *MCEltNbr)
{
    RET_CODE				ret=RET_SUCCEED;
    int					    j, k, allocSz =0;
    DBA_DYNFLD_STP			*MCETab=NULLDYNSTPTR;
    DBA_HIER_MODIF_ENUM		state;

    *MCEltNbr = 0;
    *MCEltTab = NULLDYNSTPTR;


    if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
			                         A_ModelConstrElt,
			                         FALSE,
                                     NULL,
                                     NULLFCT,
			                         MCEltNbr,
                                     &MCETab)) != RET_SUCCEED)
	return(ret);

	        if (*MCEltNbr >= allocSz && *MCEltNbr > 0)
	        {

		        *MCEltTab = (DBA_DYNFLD_STP*) CALLOC(*MCEltNbr,sizeof(DBA_DYNFLD_STP));

		        if ((*MCEltTab) == NULLDYNSTPTR)
		        {
		            FREE(MCETab);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, allocSz);
		            return(RET_MEM_ERR_ALLOC);
		        }
	        }

 	       	 /* Allocate memory */
	        for (j=0, k=0; j<*MCEltNbr; j++)
	        {
		        if ((ret = DBA_GetHierEltRecState(stratHierPtr, A_ModelConstrElt,
			                MCETab[j], &state)) != RET_SUCCEED)
		        {
		            FREE(MCETab);
		            FREE((*MCEltTab));
		            MCEltNbr = 0;
		            return(ret);
		        }

		        switch(state)
                {
		            case HierModIns :
		            case HierModUpd :
		                (*MCEltTab)[k] = MCETab[j];
		                k++;
			            break;
		        }
	        }
	        *MCEltNbr = k;


    FREE(MCETab);
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterAllocationMCByPtfId()
**
**  Description :   Filter Alloc modeling constraint by ptfId or for all ptf.
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**                  ptfIdDynStp 
**
**  Return      : TRUE or FALSE
**
*   Creation      :   WEALTH-10570-Ravindra-02082024
**
************************************************************************/
int FIN_FilterAllocationMCByPtfId(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp,
    DBA_DYNFLD_STP ptfIdDynStp)
{

    DICT_T              dictidEntPtf;

    if ((DBA_GetDictId(Ptf, &dictidEntPtf) == TRUE) &&
        (IS_NULLFLD(dynSt, A_ModelConstr_DimPortDictId) == FALSE) &&
        (GET_DICT(dynSt, A_ModelConstr_DimPortDictId) == dictidEntPtf) &&
        ((ptfIdDynStp != NULLDYNST && GET_ID(dynSt, A_ModelConstr_PortObjId) == GET_ID(ptfIdDynStp, 0)) ||
            ptfIdDynStp == NULLDYNST) &&
        (GET_ENUM(dynSt, A_ModelConstr_NatEn) == (ENUM_T)ModelConstr_AllocConstr))
        return(TRUE);

    return(FALSE);
}

/************************************************************************
*************** INSERT UPDATE DELETE ************************************
*************************************************************************
**
**  Function    :   FIN_MCEUpdHierAndValue()
**
**  Description :   Update hierarchy information for current record.
**
**  Arguments   :   stratHierPtr    strategy hierarchy header pointer
**					ESEPtr          extended modeling constraint to update
**					action          action to perfome with given ExtStratElt.
**                  field           modified field -> update A_StratElt with corresponding nature
**					context			current context for new lines.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	MCA - 010109 - REF7216
**
*************************************************************************/
RET_CODE FIN_MCEUpdHierAndValue(DBA_HIER_HEAD_STP      stratHierPtr,
                                 DBA_DYNFLD_STP         domainPtr,
                                 DBA_DYNFLD_STP         ESEPtr,
                                 DBA_ACTION_ENUM        action,
                                 int                    field,
                                 int                    selOptions,
                                 int*                   connectNo,
                                 DBA_ERRMSG_INFOS_STP   msgStructPtr)
{
    RET_CODE			ret             = RET_SUCCEED;
    int                 MCNbr          = 0;
    DBA_DYNFLD_STP     *MCTab          = NULLDYNSTPTR;
    DBA_DYNFLD_STP      MCEPtr          = NULLDYNST;
    DBA_DYNFLD_ST ptfIdDynSt;
    memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST));
    SET_ID((&ptfIdDynSt), 0, GET_ID(domainPtr, A_Domain_PtfObjId)); 

	if (ESEPtr==NULLDYNST)
	    return(RET_GEN_ERR_INVARG);

    /* Get current ExtStratLnk to get history and all strategy element list */
    /* WEALTH - 10570 - Ravindra - 02082024 */    
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                     A_ModelConstr,
			                                     FALSE,
                                                 FIN_FilterAllocationMCByPtfId,
                                                 &ptfIdDynSt,
                                                 NULLFCT,
                                                 &MCNbr,
	                                             &MCTab)) != RET_SUCCEED)
    {
	    return(ret);
    }

	/* Always 1 ExtStratLnk */
    if (MCNbr < 1 || MCTab == NULLDYNSTPTR)
    {
		return(RET_DBA_ERR_HIER);
    }


    /* Update ESE (to update format) */
    if ((ret = DBA_UpdHierEltRec(stratHierPtr, ExtStratElt, ESEPtr)) != RET_SUCCEED)
    {
     	FREE(MCTab);
    	return(ret);
    }

    /* Gestion record et hierarchy */
	if (IS_NULLFLD(ESEPtr, ExtStratElt_ModelConstrEltId) == TRUE)
	{
		if (((IS_NULLFLD(ESEPtr, field) == FALSE) &&
             (field != ExtStratElt_ConstrBoundNatEn)) ||                                                                        /*  FIH-REF11350-PMSTA00236-060223 */
            ((field == ExtStratElt_ConstrBoundNatEn) &&                                                                         /*  FIH-REF11350-PMSTA00236-060223 */
			 (IS_NULLFLD(ESEPtr, ExtStratElt_ConstrBoundNatEn) == FALSE) ||                                                     /*  FIH-REF11350-PMSTA00236-060223 */
			 (ModelConstrEltBoundNat_None != (MODELCONSTRELTBOUNDNAT_ENUM) GET_ENUM(ESEPtr, ExtStratElt_ConstrBoundNatEn))))    /*  FIH-REF11350-PMSTA00236-060223 */
		{
			MCEPtr = ALLOC_DYNST(A_ModelConstrElt); /* create a new MCE where no found it in the DataBase */
            if ((MCEPtr) == NULLDYNST)
		    {
		        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO);
		        return(RET_MEM_ERR_ALLOC);
		    }

			/* PMSTA-30291 - DDV - 180320 - Big refactoring to use CONVERT_DYNST */
			SET_ID(ESEPtr, ExtStratElt_ModelConstrId,GET_ID(MCTab[0],A_ModelConstr_Id));

            DBA_SetDfltEntityFld(ModelConstrElt, A_ModelConstrElt, MCEPtr); /* PMSTA-30291 - DDV - 180320 */
            CONVERT_DYNST(MCEPtr, A_ModelConstrElt, ESEPtr, ExtStratElt);

			SET_ENUM(MCEPtr, A_ModelConstrElt_NatEn, 1);

            if ((MODELCONSTRELTBOUNDNAT_ENUM)GET_ENUM(ESEPtr, ExtStratElt_ConstrBoundNatEn)==ModelConstrEltBoundNat_Amt &&
	            GET_FLAG(ESEPtr, ExtStratElt_FixedCellFlg) == FALSE)
            {
	            COPY_DYNFLD(MCEPtr, A_ModelConstrElt, A_ModelConstrElt_ConstrBoundCurrId,
			            ESEPtr, ExtStratElt, ExtStratElt_RefCurrId);
            }


			if ((ret = DBA_AddHierRecord(stratHierPtr,
									     MCEPtr,
									     A_ModelConstrElt,
								         FALSE,
								         HierAddRec_TestMandatLnk))!= RET_SUCCEED)
			 {
   		         FREE(MCTab);
			     return(ret);
			 }

			SET_ID(ESEPtr, ExtStratElt_ModelConstrEltId, GET_ID(MCEPtr,A_ModelConstrElt_Id));/* allocate the MCE Id*/

			ret = DBA_SetStatusHierModInsert(stratHierPtr,A_ModelConstrElt,MCEPtr); /* status necessary for the DB information*/
		}
	}
	else
	{
	    /* Extract in the hierarchie the MCE existant */
	     MCEPtr = DBA_SearchHierRecById(stratHierPtr,
									    A_ModelConstrElt,
									    A_ModelConstr_Id,
									    GET_ID(ESEPtr, ExtStratElt_ModelConstrEltId));

        /*  To avoid fatal error    */  /*  FIH-REF11350-PMSTA00236-060203 */
        if (MCEPtr == NULL)
            return ret;

        /* PMSTA-30291 - DDV - 180321 */
        if (GET_DYNSTENUM(MCEPtr) <= InvalidDynSt)
            DICT_DynStDatatypeSet(MCEPtr, A_ModelConstrElt);

		/* PMSTA-30291 - DDV - 180320 - Big refactoring to use CONVERT_DYNST */
        CONVERT_DYNST(MCEPtr, A_ModelConstrElt, ESEPtr, ExtStratElt);

		if ((MODELCONSTRELTBOUNDNAT_ENUM)GET_ENUM(ESEPtr, ExtStratElt_ConstrBoundNatEn)==ModelConstrEltBoundNat_Amt &&
			GET_FLAG(ESEPtr, ExtStratElt_FixedCellFlg) == FALSE)
		{
			COPY_DYNFLD(MCEPtr, A_ModelConstrElt, A_ModelConstrElt_ConstrBoundCurrId,
						ESEPtr, ExtStratElt, ExtStratElt_RefCurrId);
		}

		/*treatement of a MCE to delete or to update*/
    	if (IS_NULLFLD(ESEPtr, ExtStratElt_MinWeightContrib) == TRUE &&
			IS_NULLFLD(ESEPtr, ExtStratElt_MaxWeightContrib) == TRUE &&
			((IS_NULLFLD(ESEPtr, ExtStratElt_ConstrBoundNatEn) == TRUE) ||                                                          /*  FIH-REF11350-PMSTA00236-060223 */
			 (ModelConstrEltBoundNat_None == (MODELCONSTRELTBOUNDNAT_ENUM) GET_ENUM(ESEPtr, ExtStratElt_ConstrBoundNatEn))) &&      /*  FIH-REF11350-PMSTA00236-060223 */
			GET_FLAG(ESEPtr, ExtStratElt_FixedCellFlg) == 0)
		{
			SET_NULL_ID(ESEPtr, ExtStratElt_ModelConstrEltId); /* suppress the id in the ESE before to delete the MCE*/
		    ret = DBA_DelHierEltRec(stratHierPtr, A_ModelConstrElt, MCEPtr);/* also verify the DB status*/
			if (ret != RET_SUCCEED)
            {
                FREE(MCTab);
                return(ret);
            }
		}
		else
		{
		    ret = DBA_UpdHierEltRec(stratHierPtr, A_ModelConstrElt, MCEPtr); /* also verify the DB status*/
			if (ret != RET_SUCCEED)
            {
                FREE(MCTab);
                return(ret);
            }
		}
	}

    FREE(MCTab);
    return(RET_SUCCEED);

}/*FIN_MCEUpdHierAndValue*/
/*************************************************************************/
/************************************************************************
**
**  Function    :   FIN_InsUpdModelConstrData
**
**  Description :   Update extended modeling constraint.
**
**  Arguments   :   stratHierPtr	strategy hierarchy eader pointer
**					domainPtr		domain pointer
**					ESEPtr			extended strategy element to update
**					action          action to perfome with given ExtStratElt.
**                  field			modified field (update A_ModelConstr according to is value)
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	MCA - 010109 - REF7216
**
*************************************************************************/
RET_CODE FIN_InsUpdModelConstrData(DBA_HIER_HEAD_STP      stratHierPtr,
                                   DBA_DYNFLD_STP         domainPtr,
								   DBA_DYNFLD_STP         ESEPtr,
								   DBA_ACTION_ENUM        action,
								   int                    field,
								   RETCODEFCT            *fct,
								   PTR                    context,
								   FLAG_T                *dfltValTab)
{
		RET_CODE ret = RET_SUCCEED;

				ret = FIN_MCEUpdHierAndValue(stratHierPtr,
                                             domainPtr,
											 ESEPtr,
											 action,
											 field,
											 UNUSED,
											 UNUSED,
											 UNUSED);
				if (ret != RET_SUCCEED)
					return(ret);


    return(ret);
} /*end FIN_InsUpdModelConstrData*/

/************************************************************************
**
**  Function    :   FIN_AccountingRuleCompoLookup
**
**  Description :   Look up accounting rule for position, given instrument, portfolio, and date.
**
**  Arguments   :   portfolioId
**					instrumentId    extended strategy element to update
**					date          action to perfome with given ExtStratElt.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	MSR - 100217 - PMSTA-
**
*************************************************************************/
RET_CODE FIN_AccountingRuleCompoLookup(ID_T instrumentId, ID_T portfolioId, DATE_T date, DBA_DYNFLD_STP* result) {

    DBA_DYNFLD_STP arc_arg = ALLOC_DYNST(Arg_AccountingRuleCompo);
    SET_ID(arc_arg, AccRuleCompoArg_InstrumentId, instrumentId);
    SET_ID(arc_arg, AccRuleCompoArg_PortfolioId, portfolioId);
    SET_DATE(arc_arg, AccRuleCompoArg_Date, date);

    const DBA_DYNST_ENUM * outputStLst[] = { &A_AccountingRuleCompo, &A_AccountingRuleCompo, &A_AccountingRuleCompo };
    const int outputBlkNb = sizeof (outputStLst) / sizeof(outputStLst[0]);
    DBA_DYNFLD_STP *        data[] = { NULL, NULL, NULL, NULL };
    int                     rows[] = { 0, 0, 0, 0 };
    int dbaOptions = 0, maxRows = 0;
    DBA_DYNFLD_STP functionResult = NULLDYNST;

    RET_CODE ret = DBA_MultiSelect2(AccountingRuleCompo, UNUSED, Arg_AccountingRuleCompo,
        arc_arg, outputStLst, data, dbaOptions, maxRows, rows, UNUSED, UNUSED);
    if (ret != RET_SUCCEED)
    {
        MSG_LogMesg(ret, 1, FILEINFO, "DBA_MultiSelect failed");
    }
    else
    {
        FLAG_T stop = FALSE;
        for (int i = 0; i < 3 && stop == FALSE; i++) {
            for (int j = 0; j < rows[i] && stop == FALSE; j++) {
                DBA_DYNFLD_STP row = data[i][j];

                FLAG_T		isInList = FALSE;
                DATETIME_T      dateHisto;
                memset(&dateHisto, 0, sizeof(DATETIME_T));
                dateHisto.date = date;

                ret = FIN_IsInList(NULL, instrumentId, NULLDYNST, Instr,
                    GET_ID(row, A_AccountingRuleCompo_InstrListId),
                    NULLDYNST, nullptr, TRUE, &dateHisto, &isInList);

                if (ret != RET_SUCCEED)
                {
                    MSG_LogMesg(ret, 1, FILEINFO, "DBA_MultiSelect failed - call to FIN_IsInList failed");

                    stop = TRUE;
                }
                else if (isInList == TRUE)
                {
                    // Extract first match from the dynamic structure array (will not be freed by DBA_MultiFree() call below).
                    functionResult = row;
                    data[i][j] = NULLDYNST;
                    stop = TRUE;
                }
            }
        }
    }
    *result = functionResult;

    FREE_DYNST(arc_arg, Arg_AccountingRuleCompo);
    DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
    return ret;
}

/************************************************************************
**
**  Function    :   FIN_IsTradableInstrument
**
**  Description :   Check if the instrument is tradable
**
**  Arguments   :   Instrument ID
**
**  Return      :   boolean
**
**  Creation	:	PMSTA-32131 - DLA - 180731
**
*************************************************************************/
bool   FIN_IsTradableInstrument(DBA_HIER_HEAD_STP stratHierHead, ID_T instrId)
{
    //PMSTA-32131 - DLA - 180731
    // The rules mut be defined, using a new field ?
    // for test I'm using A_Instr_NegociableFlg
    // The  GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_CapProtectNotes is a

    DBA_DYNFLD_STP  instrPtr = nullptr;
    FLAG_T          allocFlg = FALSE;
    bool            bRet     = true;

    if (DBA_GetInstrById(instrId,
                         TRUE,
                         &allocFlg,
                         &instrPtr,
                         stratHierHead,
                         UNUSED,
                         UNUSED) == RET_SUCCEED)
    {
        /*
        if (GET_FLAG(instrPtr, A_Instr_NegociableFlg) == FALSE)
        {
            bRet = false;
        }
        */
    }

    if(allocFlg == TRUE)
    {
        FREE_DYNST(instrPtr, A_Instr);
    }
    return bRet;
}

/********************************************************************************************
**  Function             :  FIN_CheckPortfolioHierNetting()
**
**  Description          :  Check the Portfolio Hierarchy for order netting
**
**  Arguments            :	stratHierHead	strategy hierarchy header pointer
**							ptf				portfolio structure pointer
**
**
**  Return               :  PtfOrderNettingEn : NotConsideredForOrderNetting
**                                                    or
**							PtfOrderNettingEn :ConsideredForOrderNetting
**
**
**  Creation 		     :  PMSTA-38675 -290120 - grace
**
**  Modif.               :
**********************************************************************************************/
PtfOrderNettingEn FIN_CheckPortfolioHierNetting(DBA_HIER_HEAD_STP stratHierHead, DBA_DYNFLD_STP ptf)
{
	DBA_DYNFLD_STP parentPtf = NULL, childPtf = NULL;
	RET_CODE ret = RET_SUCCEED;
	FLAG_T	allocPtfFlg;
	childPtf = ptf;

	if (PtfOrderNettingEn::InheritedFromParent == static_cast<PtfOrderNettingEn>(GET_ENUM(ptf, A_Ptf_OrderNettingEn)))
	{
		do
		{
			if (TRUE == IS_NULLFLD(childPtf, A_Ptf_ParentPortId))
			{
				return(PtfOrderNettingEn::ConsideredForOrderNetting);
			}	
			else
			{
				ID_T parentPtfId = GET_ID(childPtf, A_Ptf_ParentPortId);
				ret = DBA_GetRecPtrFromHierById((DBA_HIER_HEAD_STP)stratHierHead,
					parentPtfId,
					A_Ptf,
					&parentPtf);
				if (RET_SUCCEED != ret || NULL == parentPtf)
				{
					if ((ret = DBA_GetPtfById(parentPtfId, TRUE, &allocPtfFlg, &parentPtf, (PTR)stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
					{
						MSG_SendMesg(FILEINFO, "FIN_CheckPortfolioHierNetting: Unable to get Parent Ptf by Id");
						
					}
				}
				childPtf = parentPtf;
			}

		} while (PtfOrderNettingEn::InheritedFromParent == static_cast<PtfOrderNettingEn>(GET_ENUM(parentPtf, A_Ptf_OrderNettingEn)));

		return (static_cast<PtfOrderNettingEn>GET_ENUM(parentPtf, A_Ptf_OrderNettingEn));
	}
	return (static_cast<PtfOrderNettingEn>GET_ENUM(ptf, A_Ptf_OrderNettingEn));
}

/********************************************************************************************
**  Function             :  FIN_GetMininumTradingQuantity()
**
**  Description          :  To get the minimum trading quantity.
**
**  Arguments            :	stratHierHead	strategy hierarchy header pointer
**							domainPtr     	domain structure pointer
**							instrPtr        instrument structure pointer
**							minPtr          pointer to minimum quantity
**							instrPrice      price of the instrument
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-37908 - 231219 - grace
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_GetMininumTradingQuantity(DBA_HIER_HEAD_STP stratHierHead,
    DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP instrPtr,
    DBA_DYNFLD_STP ptfPtr,
    NUMBER_T       *minPtr,
    AMOUNT_T       instrPrice)
{
    RET_CODE ret = RET_SUCCEED;
    FIN_EXCHARG_ST  exchArgSt;
    EXCHANGE_T	 exchRate;
    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	AMOUNT_T roundUnit = GET_NUMBER(instrPtr, A_Instr_OddLotQty);
	RNDRULE_ENUM roundRule = static_cast<RNDRULE_ENUM>GET_ENUM(domainPtr, A_Domain_RoundingMethodEn);
    AMOUNT_T minAmt = GET_AMOUNT(domainPtr, A_Domain_MinOrderAmt);
    /*Get Exchange rate when domain CCY not equal to Instr CCY*/
    if (0 != CMP_ID(GET_ID(domainPtr, A_Domain_MinOrderAmtCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)))
    {
        DBA_InitConnectNoToExchArg(&exchArgSt, stratHierHead);
        ret = FIN_GetExchRate(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
            GET_ID(domainPtr, A_Domain_MinOrderAmtCurrId),
            GET_ID(instrPtr, A_Instr_RefCurrId),
            (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchRate);

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            minAmt *= exchRate;
            ret = RET_SUCCEED;   /*if FIN_GetExchRate return wasn't success but wasn't an error either, */
                                 /*we want FIN_GetMininumTradingQuantity to return success*/
        }
    }

    std::vector<NUMBER_T> qtyList;
    qtyList.push_back(TLS_Round(FUS_DIV(minAmt, instrPrice), roundUnit, roundRule));
    qtyList.push_back(TLS_Round(FUS_DIV(GET_AMOUNT(instrPtr, A_Instr_MinTradingAmt), instrPrice), roundUnit,roundRule));
    qtyList.push_back(TLS_Round(FUS_DIV(GET_AMOUNT(instrPtr, A_Instr_RoundLotAmt), instrPrice), roundUnit, roundRule));
    qtyList.push_back(GET_NUMBER(instrPtr, A_Instr_OddLotQty));
    qtyList.push_back(GET_NUMBER(instrPtr, A_Instr_MinTradeQty));


    /*Recalculating Min trad.quantity when Domain MinOrderPercent is given*/
    if (FALSE == IS_NULLFLD(domainPtr, A_Domain_MinOrderPercent))
    {
        NUMBER_T ptfVal = GET_NUMBER(ptfPtr, A_Ptf_MktValM);
        qtyList.push_back(TLS_Round(FUS_DIV((ptfVal * GET_PERCENT(domainPtr, A_Domain_MinOrderPercent) / 100.0), instrPrice), roundUnit, roundRule));
    }
    sort(qtyList.begin(), qtyList.end()); /*Sorting in ascending order and fetching max of minimum quantity*/
	*minPtr = qtyList.back();

    return(ret);

}

/* To sort the Buy and Sell Orders */
class OperationComparator
{
public:

    bool operator()(const DBA_DYNFLD_STP & extOp1, const DBA_DYNFLD_STP & extOp2)
    {
        /* Criteria - Quantity  - Ascending */
        return (-1 == CMP_DYNFLD(extOp1, extOp2, ExtOp_Qty, ExtOp_Qty, GET_FLD_TYPE(ExtOp, ExtOp_Qty)));
    }
};

/********************************************************************************************
**  Function             :  FIN_SetOrderNettingCriteria()
**
**  Description          :  Set the Netting criteria according to the function script provided.
**
**  Arguments            :	dynScptDefStp   Script definition
**                          order           Order for which the Netting criteria to be set
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-38809 - sanand - 30012020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_SetOrderNettingCriteria(DBA_DYNFLD_STP dynScptDefStp,DBA_DYNFLD_STP order)
{
    RET_CODE                retCode = RET_SUCCEED;
    char                    *pszScript = NULL;
    SCPT_ARG_STP            genCtxStp = (SCPT_ARG_STP)NULL;
    INFO_T                  nettingCriteria;
    DBA_DYNFLD_STP          retFldStp = NULLDYNSTPTR;
    DBA_DYNFLD_ST           retFldSt;
    retFldStp = &retFldSt;
    memset(retFldStp, 0, sizeof(DBA_DYNFLD_ST));

    if (IS_NULLFLD(dynScptDefStp, A_ScriptDef_Def) == FALSE)
    {
        pszScript = GET_INFO(dynScptDefStp, A_ScriptDef_Def);

        /* Call script analysis */
        retCode = SCPT_GenerateScptTree(pszScript
                                        , EOp
                                        , InternalSMode
                                        , NullDataType
                                        , &genCtxStp);
    }
    if ((retCode == RET_SUCCEED) && (genCtxStp != NULL))
    {
        nettingCriteria[0] = END_OF_STRING;
        retCode = SCPT_ExecScptTreeSpec(genCtxStp
                                        , NULLDYNST
                                        , NULL
                                        , order
                                        , InfoType
                                        , retFldStp
                                        , 0
                                        , order
                                        , (SCPT_FMTDATADEF_STP)NULL
                                        , TRUE
                                        , FALSE);
        if (IS_NULLFLD(retFldStp, 0) == FALSE)
        {
            strcpy(nettingCriteria, GET_INFO(retFldStp, 0));
            SET_INFO(order, ExtOp_NettingCriteria, nettingCriteria);
        }
    }
    return retCode;
}

/********************************************************************************************
**  Function             :  FIN_NetOrders()
**
**  Description          :  Perform OrderNetting of the list of Orders provided.
**
**  Arguments            :	orderCount      Number of Orders
**                          ordersTab       List of Orders
**							domainPtr     	domain structure pointer
**							stratHierHead	strategy hierarchy header pointer
**							iNbCol          Number of Columns along with the supplementary fields
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-38314 - sanand - 29012020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_NetOrders(int orderCount, DBA_DYNFLD_STP *ordersTab, DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP stratHierHead, int iNbCol)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      instrPtr = NULL,
                        ptfPtr = NULL;
    ID_T                instrId = ZERO_ID,
                        ptfId = ZERO_ID;
    AMOUNT_T            price = ZERO_AMOUNT,
                        priceIns = ZERO_AMOUNT;
    NUMBER_T            minQty = ZERO_NUMBER;
    FLAG_T			    allocPtfFlg;
    char                hierFlg;
	AMOUNT_T            opNetAmt = ZERO_AMOUNT ;
	NETAMT_CURR_ENUM    amtCurr = NetAmt_Oper_Curr;
	DBA_DYNST_ENUM      enDbaDynst;
	OBJECT_ENUM         enObject;
	DBA_DYNFLD_STP      resultOperOp , buyOper, sellOper, netBuyOper, netSellOper = NULLDYNST;
    DBA_ERRMSG_INFOS_ST msgStruct(FILEINFO);
    MemoryPool          mp;

    typedef std::pair<std::vector<DBA_DYNFLD_STP>, std::vector<DBA_DYNFLD_STP>> buySellList;
    /* Creating a map of NettingCriteriainstrumentID String -> Pair of <BuyList, SellList> */
    std::map <std::string, buySellList> netCritInstrStringToOperationsMap;


    /* PMSTA - 38809 - sanand - 30012020 - Get Script definition */
    DICT_T                  attrDictId = -1;
    DBA_DYNFLD_STP          dynScptDefStp = NULLDYNST,rightScrDef= NULLDYNST;
    FLAG_T                  *pflag = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_Domain), sizeof(FLAG_T));
   
    memset(pflag, (int)TRUE, GET_FLD_NBR(A_Domain) * sizeof(FLAG_T));
    pflag[A_Domain_OrderNettingFctDictId] = FALSE;
   
    /* PMSTA-39183 - adarshn - 10032020 - To fetch the appropriate function's order_netting_fct_dict_id */
    SCPT_ComputeScreenDV(Domain,
                         GET_DICT(domainPtr, A_Domain_FctDictId),
                         pflag,
                         NULL,
                         domainPtr,
                         NULL,
                         domainPtr,
                         NULLDYNST,
                         TRUE,
                         TRUE,
                         EvalType_DefVal,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         DictScreen,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if ( IS_NULLFLD(domainPtr, A_Domain_OrderNettingFctDictId) ) 
    {
        MSG_SendMesg(FILEINFO, "FIN_NetOrders: Netting Function Dict ID Unavailable");
        return RET_SUCCEED;
    }

    DbiConnectionHelper dbiConnHelper;
    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

    if (GET_ID(domainPtr, A_Domain_OrderNettingFctDictId) > 0)
    {
        DICT_ATTRIB_STP nettingCriteriaAttrib = DBA_GetAttributeBySqlName(EOp, "netting_criteria");
        attrDictId = nettingCriteriaAttrib->attrDictId;
        dynScptDefStp = mp.allocDynst(FILEINFO, A_ScriptDef);

        SET_DICT(dynScptDefStp, A_ScriptDef_AttrDictId, attrDictId);
        SET_DICT(dynScptDefStp, A_ScriptDef_ObjId, GET_ID(domainPtr, A_Domain_OrderNettingFctDictId));
        SET_ENUM(dynScptDefStp, A_ScriptDef_NatEn, ScriptDef_UpdateFieldsDefVal);

        ret = DBA_GetScptDef(dynScptDefStp, *dbiConnHelper.getConnection());
    }

    if (( RET_SUCCEED == ret ) && 
        ( NULLDYNST != dynScptDefStp ) &&
        ( TRUE == IS_NULLFLD(dynScptDefStp, A_ScriptDef_Def )))
    {
        /* No Netting to be done if there is no function script defined */
        MSG_SendMesg(FILEINFO, "FIN_NetOrders: No Netting criteria defined!!");
        return RET_SUCCEED;
    }

    if (GET_ID(domainPtr, A_Domain_OrderNettingFctDictId) > 0)
    {
        DICT_ATTRIB_STP nettingCriteriaAttrib = DBA_GetAttributeBySqlName(EOp, "right_to_run_f");
        attrDictId = nettingCriteriaAttrib->attrDictId;
        rightScrDef = mp.allocDynst(FILEINFO, A_ScriptDef);

        SET_DICT(rightScrDef, A_ScriptDef_AttrDictId, attrDictId);
        SET_DICT(rightScrDef, A_ScriptDef_ObjId, GET_ID(domainPtr, A_Domain_OrderNettingFctDictId));
        SET_ENUM(rightScrDef, A_ScriptDef_NatEn, ScriptDef_UpdateFieldsDefVal);

        ret = DBA_GetScptDef(rightScrDef, *dbiConnHelper.getConnection());
    }

    if ((RET_SUCCEED == ret) &&
        (NULLDYNST != rightScrDef) &&
        (TRUE == IS_NULLFLD(rightScrDef, A_ScriptDef_Def)))
    {
        /* No Netting to be done if there is no function rights defined */
        MSG_SendMesg(FILEINFO, "FIN_NetOrders: No Netting rights defined!!");
        return RET_SUCCEED;
    }


    char                    *pszScript = NULL;
    pszScript = GET_INFO(rightScrDef, A_ScriptDef_Def);

    SCPT_ARG_STP            genCtxStp = (SCPT_ARG_STP)NULL;

    ret = SCPT_GenerateScptTree(pszScript
        , EOp
        , InternalSMode
        , NullDataType
        , &genCtxStp);

    if (ret != RET_SUCCEED)
    {
        SCPT_FreeScptTree(genCtxStp);
        MSG_SendMesg(FILEINFO, "FIN_NetOrders: Netting rights Error!!");
        return RET_SUCCEED;
    }

    /* Iterate through the sorted Orders, build the map structure */
    for (int opIndex = 0; opIndex < orderCount; opIndex++)
    {
        DBA_DYNFLD_STP orderDetail = ordersTab[opIndex];

        /* Call script analysis to check function rights */
        
        DBA_DYNFLD_STP          retFldStp = NULLDYNSTPTR;
        DBA_DYNFLD_ST           retFldSt;
        bool                    havingRights = false;

        retFldStp = &retFldSt;
        retFldStp = mp.allocDynstWithOutDef(FILEINFO, sizeof(DBA_DYNFLD_ST));

        if ((ret == RET_SUCCEED) && (genCtxStp != NULL))
        {
            /*execute the script and get result*/
            ret = SCPT_ExecScptTreeSpec(genCtxStp
                , NULLDYNST
                , NULL
                , orderDetail
                , EnumType
                , retFldStp
                , 0
                , orderDetail
                , (SCPT_FMTDATADEF_STP)NULL
                , TRUE
                , FALSE);
            if (IS_NULLFLD(retFldStp, 0) == FALSE)
            {
                ENUM_T orderNettingRights = GET_ENUM(retFldStp, 0);
                if (orderNettingRights == 1)
                {
                    havingRights = true;
                }
            }
        }

        if (havingRights == false)
            continue;

        instrId = GET_ID(orderDetail, ExtOp_InstrId);
        /* PMSTA - 38809 - sanand - 30012020 */
        ret = FIN_SetOrderNettingCriteria(dynScptDefStp, orderDetail);
        if (IS_NULLFLD(orderDetail, ExtOp_CompoundOrderCode) == TRUE) /*Checking for compound order*/
        {
            /*  PMSTA - 38609 - sanand - 20200120 - Check the Portfolio hierarchy for Order netting status,
                                                    to decide which orders should be netted */
            DBA_DYNFLD_STP ptf;
            if (NULL != GET_EXTENSION_PTR(orderDetail, ExtOp_A_Ptf_Ext))
            {
                ptf = *(GET_EXTENSION_PTR(orderDetail, ExtOp_A_Ptf_Ext));
            }
            else
            {
                if ((ret = DBA_GetPtfById(GET_ID(orderDetail, ExtOp_PtfId), FALSE, &allocPtfFlg, &ptf,
                    (PTR)stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    SCPT_FreeScptTree(genCtxStp);
                    MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_NetOrders : error loading portfolio (ID=%1)",
                        IdType, GET_ID(orderDetail, ExtOp_PtfId));
                    return (ret);
                }
            }  
            if (NULLDYNSTPTR != ptf)
            {
                if (PtfOrderNettingEn::ConsideredForOrderNetting == FIN_CheckPortfolioHierNetting(stratHierHead, ptf))
                {
                    char  nettCriteriaInstrIdString[1024];
                    sprintf(nettCriteriaInstrIdString, "%s-%d" ,
                                  GET_INFO(orderDetail, ExtOp_NettingCriteria), (int)instrId);
                    std::string strValue(nettCriteriaInstrIdString);
					if (ORDER_NETTING_ENUM::OrderNetting_None == static_cast<ORDER_NETTING_ENUM>GET_ENUM(orderDetail, ExtOp_OrderNettingEn) ||
                        ORDER_NETTING_ENUM::OrderNetting_UserChoice == static_cast<ORDER_NETTING_ENUM>GET_ENUM(orderDetail, ExtOp_OrderNettingEn))
					{
						if (OPNAT_ENUM::OpNat_Buy == static_cast<OPNAT_ENUM>(GET_ENUM(orderDetail, ExtOp_NatureEn)))
						{
							/* Populate BuyOrderList */
							netCritInstrStringToOperationsMap[strValue].first.push_back(orderDetail);
						}
                        if (OPNAT_ENUM::OpNat_Sell == static_cast<OPNAT_ENUM>(GET_ENUM(orderDetail, ExtOp_NatureEn)))
						{
							/* Populate SellOrderList */
							netCritInstrStringToOperationsMap[strValue].second.push_back(orderDetail);
						}
					}
                }
            }
        }
    }

    SCPT_FreeScptTree(genCtxStp);

    OperationComparator sortExtOp;
    auto mapIter = netCritInstrStringToOperationsMap.cbegin();
    /* To Iterate through all the Instruments of the map */
    while (mapIter != netCritInstrStringToOperationsMap.cend())
    {
        /* For each Instrument, get the Buy Orders , Sell Orders */
        auto buyOrderList = (mapIter->second).first, sellOrderList = (mapIter->second).second;
        /* When the order netting is executed from the Context Menu, the records
           are not sorted , hence needs sorting */

        std::sort(buyOrderList.begin(), buyOrderList.end(), sortExtOp);
        std::sort(sellOrderList.begin(), sellOrderList.end(), sortExtOp);
        /* No Netting to be done, if any( BuyOrders, SellOrders ) of the list is empty */
        if (!buyOrderList.empty() && !sellOrderList.empty())
        {
            auto buyIter = buyOrderList.cbegin(), sellIter = sellOrderList.cbegin();
            NUMBER_T buyQty = GET_NUMBER(*buyIter, ExtOp_Qty), sellQty = GET_NUMBER(*sellIter, ExtOp_Qty);
            instrId = GET_ID(*buyIter, ExtOp_InstrId);
			priceIns = GET_PRICE(*buyIter, ExtOp_Price);
            if (NULL != GET_EXTENSION_PTR(*buyIter, ExtOp_A_Instr_Ext))
            {
                instrPtr = *(GET_EXTENSION_PTR(*buyIter, ExtOp_A_Instr_Ext));
            }
            else
            {
                ret = FIN_GetHierInstr(stratHierHead,
                    instrId,
                    &hierFlg,
                    &instrPtr);
                if (RET_SUCCEED != ret)
                {
                    MSG_SendMesg(FILEINFO, "FIN_NetOrders: Unable to get Instrument from hierarchy");
                    return(ret);
                }
            }
            /* Iterate through the buyOrders, sellOrders until we run out of one list */
            while (buyIter != buyOrderList.cend() && sellIter != sellOrderList.cend())
            {
                if (buyQty > sellQty)
                {
                    buyQty -= sellQty;
                    SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
                    /* PMSTA-38609 - sanand - 20200120 - Fix for ptfId not
                       getting picked up when there is just a single order buy and sell */
                    ptfId = GET_ID(*sellIter, ExtOp_PtfId);
                    /* Remaining buyQty is to be netted with the next SellQty */
                    if (++sellIter != sellOrderList.cend())
                    {
                        sellQty = GET_NUMBER(*sellIter, ExtOp_Qty);
                        if (NULL != GET_EXTENSION_PTR(*sellIter, ExtOp_A_Ptf_Ext))
                        {
                            ptfPtr = *(GET_EXTENSION_PTR(*sellIter, ExtOp_A_Ptf_Ext));
                        }
                    }
                }
                else if (buyQty < sellQty)
                {
                    sellQty -= buyQty;
                    SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
                    /* PMSTA-38609 - sanand - 20200120 - Fix for ptfId not
                       getting picked up when there is just a single order buy and sell */
                    ptfId = GET_ID(*buyIter, ExtOp_PtfId);
                    /* Remaining sellQty is to be netted with the next buyQty */
                    if (++buyIter != buyOrderList.cend())
                    {
                        buyQty = GET_NUMBER(*buyIter, ExtOp_Qty);
                        if (NULL != GET_EXTENSION_PTR(*buyIter, ExtOp_A_Ptf_Ext))
                        {
                            ptfPtr = *(GET_EXTENSION_PTR(*buyIter, ExtOp_A_Ptf_Ext));
                        }
                    }
                }
                else if (buyQty == sellQty)
                {
                    /* PMSTA-43499 - sanand - 01022021 */
                    ptfId = GET_ID(*buyIter, ExtOp_PtfId);
                    SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
                    SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
                    if (++buyIter != buyOrderList.cend())
                    {
                        buyQty = GET_NUMBER(*buyIter, ExtOp_Qty);
                    }
                    if (++sellIter != sellOrderList.cend())
                    {
                        sellQty = GET_NUMBER(*sellIter, ExtOp_Qty);
                    }
                }
            }
            if (NULL == ptfPtr)
            {
                ret = DBA_GetRecPtrFromHierById((DBA_HIER_HEAD_STP)stratHierHead,
                    ptfId,
                    A_Ptf,
                    &ptfPtr);
                if (RET_SUCCEED != ret)
                {
                    if ((ret = DBA_GetPtfById(ptfId, FALSE, &allocPtfFlg, &ptfPtr,
                                              (PTR)stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(FILEINFO, "FIN_NetOrders: Unable to get Ptf from hierarchy by Id");
                        return(ret);
                    }
                }
            }

            /*Trading criteria */
            /*Getting the minimum trading quantity*/
            ret = FIN_GetMininumTradingQuantity(stratHierHead, domainPtr, instrPtr, ptfPtr, &minQty, priceIns);
            if (RET_SUCCEED != ret)
            {
                MSG_SendMesg(FILEINFO, "FIN_NetOrders: Unable to get minimum quantity");
                return(ret);
            }
            /*Checking if the netting resultant meets the minimum trading criteria*/
            DBA_DYNFLD_STP  netBuy = NULLDYNST;
            DBA_DYNFLD_STP  netSell = NULLDYNST;
			/*If the min trading quanting is greater than allocated quantity, undo the negative order generated*/
			if ((minQty > 1) && ((buyIter == buyOrderList.end() && minQty < buyQty && sellQty < minQty) || (sellIter == sellOrderList.end() && minQty < sellQty && buyQty < minQty)))
			{
				if (sellIter == sellOrderList.end())
				{
					sellIter--;
				}
				else if (buyIter == buyOrderList.end())
				{
					buyIter--;
				}
				/*Populating the original Buy, Sell quantities*/
				netBuy = ALLOC_DYNST_SUPPLFLD(ExtOp, iNbCol);
				COPY_DYNST(netBuy, *buyIter, ExtOp);
				COPY_DYNFLD(netBuy, ExtOp, ExtOp_OriginalQty, *buyIter, ExtOp, ExtOp_Qty);
				netSell = ALLOC_DYNST_SUPPLFLD(ExtOp, iNbCol);
				COPY_DYNST(netSell, *sellIter, ExtOp);
				COPY_DYNFLD(netSell, ExtOp, ExtOp_OriginalQty, *sellIter, ExtOp, ExtOp_Qty);

				/*When net buy/net sell doesnot meet the trading criteria*/
				if (buyQty < sellQty)
				{
					SET_NUMBER(*sellIter, ExtOp_Qty, minQty);
					NUMBER_T resultantSell = sellQty - minQty;
					SET_NUMBER(*buyIter, ExtOp_Qty, GET_NUMBER(*buyIter, ExtOp_Qty) - resultantSell);
				}
				else if (buyQty > sellQty)
				{
					SET_NUMBER(*buyIter, ExtOp_Qty, minQty);
					NUMBER_T resultantBuy = buyQty - minQty;
					SET_NUMBER(*sellIter, ExtOp_Qty, GET_NUMBER(*sellIter, ExtOp_Qty) - resultantBuy);
				}

				if (GET_NUMBER(*sellIter, ExtOp_Qty) >= minQty && GET_NUMBER(*buyIter, ExtOp_Qty) >= minQty) /*Checking if the net Buy/Sell still meets trading criteria*/
				{
					price = GET_PRICE(*buyIter, ExtOp_Price); /* PMSTA-38658 - Adarsh - 27012020 */
					/*Creating netbuy after meeting trading criteria and adding to hierarchy*/
					SET_NUMBER(netBuy, ExtOp_Qty, GET_NUMBER(*buyIter, ExtOp_Qty));
					SET_NUMBER(*buyIter, ExtOp_Qty, GET_NUMBER(netBuy, ExtOp_OriginalQty) - GET_NUMBER(*buyIter, ExtOp_Qty));
					SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
					SET_ENUM(netBuy, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_OrderGenFromNetting);
					SET_AMOUNT(*buyIter, ExtOp_AcctNetAmt, GET_NUMBER(*buyIter, ExtOp_Qty)*price);
					SET_AMOUNT(*buyIter, ExtOp_OpGrossAmt, GET_NUMBER(*buyIter, ExtOp_Qty)*price);
					SET_AMOUNT(netBuy, ExtOp_AcctNetAmt, GET_NUMBER(netBuy, ExtOp_Qty)*price); /* PMSTA-39189 - grace - 04032020 */
					SET_AMOUNT(netBuy, ExtOp_OpGrossAmt, GET_NUMBER(netBuy, ExtOp_Qty)*price);
					SET_ENUM(netBuy, ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
					/* WSC- 16067 - Grace -15042020  */
					OPE_OperNatToDictEnum(OPNAT_ENUM::OpNat_Buy, &enDbaDynst, &enObject); /* Getting corresponding operation OBJECT_ENUM for Buy:OPNAT_ENUM to be passed as arg to func OPE_ComputeNetAmount */
					buyOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					OPE_ExtOpToOp(*buyIter, buyOper, stratHierHead, TRUE);/* Transform the'extended'operation record into an operation record to compute Net Amount in OPE_ComputeNetAmount*/
					OPE_ComputeNetAmount(enObject, buyOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					SET_AMOUNT(*buyIter, ExtOp_OpNetAmt, opNetAmt);
					netBuyOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					OPE_ExtOpToOp(netBuy, netBuyOper,stratHierHead, TRUE);
					OPE_ComputeNetAmount(enObject, netBuyOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					SET_AMOUNT(netBuy, ExtOp_OpNetAmt, opNetAmt);
					ret = DBA_AddHierRecord((DBA_HIER_HEAD_STP)stratHierHead, netBuy, ExtOp, TRUE, HierAddRec_NoLnk);	
					while (++buyIter != buyOrderList.cend())
					{
						SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_Processed);
					}

					price = GET_PRICE(*sellIter, ExtOp_Price); /* PMSTA-38658 - Adarsh - 27012020 */
					/*Creating netsell after meeting trading criteria and adding to hierarchy*/
					SET_NUMBER(netSell, ExtOp_Qty, GET_NUMBER(*sellIter, ExtOp_Qty));
					SET_NUMBER(*sellIter, ExtOp_Qty, GET_NUMBER(netSell, ExtOp_OriginalQty) - GET_NUMBER(*sellIter, ExtOp_Qty));
					SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
					SET_ENUM(netSell, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_OrderGenFromNetting);
					SET_AMOUNT(*sellIter, ExtOp_AcctNetAmt, GET_NUMBER(*sellIter, ExtOp_Qty)*price);
					SET_AMOUNT(*sellIter, ExtOp_OpGrossAmt, GET_NUMBER(*sellIter, ExtOp_Qty)*price);
					SET_AMOUNT(netSell, ExtOp_AcctNetAmt, GET_NUMBER(netSell, ExtOp_Qty)*price); /* PMSTA-39189 - grace - 04032020 */
					SET_AMOUNT(netSell, ExtOp_OpGrossAmt, GET_NUMBER(netSell, ExtOp_Qty)*price);
					SET_ENUM(netSell, ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
					/* WSC- 16067 - grace -15042020 */
					OPE_OperNatToDictEnum(OPNAT_ENUM::OpNat_Sell, &enDbaDynst, &enObject);/* Getting corresponding operation OBJECT_ENUM for Sell:OPNAT_ENUM to be passed as arg to func OPE_ComputeNetAmount */
					sellOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					OPE_ExtOpToOp(*sellIter, sellOper, stratHierHead, TRUE); /* Transform the'extended'operation record into an operation record to compute Net Amount in OPE_ComputeNetAmount*/
					OPE_ComputeNetAmount(enObject, sellOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					SET_AMOUNT(*sellIter, ExtOp_OpNetAmt, opNetAmt);
					netSellOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					OPE_ExtOpToOp(netSell, netSellOper, stratHierHead, TRUE);
					OPE_ComputeNetAmount(enObject, netSellOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					SET_AMOUNT(netSell, ExtOp_OpNetAmt, opNetAmt);
					ret = DBA_AddHierRecord(stratHierHead, netSell, ExtOp, TRUE, HierAddRec_NoLnk);
					while (++sellIter != sellOrderList.cend())
					{
						SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_Processed);
					}
				}
			}
			
            else
            {
                /* Create a resultant of the remaining buy or sell quantity after netting */
                DBA_DYNFLD_STP  resultantOp = NULLDYNST;
                if (buyIter != buyOrderList.cend() && buyQty > 0)
                {
                    /* PMSTA-43829 - sanand - 01032021
                       Avoid creation of resultant when the buys and sells are cancelling each 
                       other out and there are some buy orders remaining */
                    if (CMP_NUMBER(buyQty, GET_NUMBER(*buyIter, ExtOp_Qty)) != 0)
                    {
                        price = GET_PRICE(*buyIter, ExtOp_Price); /* PMSTA-38658 - Adarsh - 27012020 */
                        resultantOp = ALLOC_DYNST_SUPPLFLD(ExtOp, iNbCol);
                        COPY_DYNST(resultantOp, *buyIter, ExtOp);
                        SET_NULL_PTR(resultantOp, ExtOp_EditBackupPtr);                     /*  To avoid crash while run from the GUI   PMSTA-47419 */
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_OriginalQty, *buyIter, ExtOp, ExtOp_Qty);
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_InstrId, *buyIter, ExtOp, ExtOp_InstrId);
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_PtfId, *buyIter, ExtOp, ExtOp_PtfId);
                        SET_NUMBER(resultantOp, ExtOp_Qty, buyQty);
                        SET_AMOUNT(resultantOp, ExtOp_AcctNetAmt, buyQty*price);
                        SET_AMOUNT(resultantOp, ExtOp_OpGrossAmt, buyQty*price);
                        SET_ENUM(resultantOp, ExtOp_NatureEn, OPNAT_ENUM::OpNat_Buy);
                        SET_NUMBER(*buyIter, ExtOp_Qty, GET_NUMBER(*buyIter, ExtOp_Qty) - buyQty);
                        SET_AMOUNT(*buyIter, ExtOp_AcctNetAmt, GET_NUMBER(*buyIter, ExtOp_Qty)*price);
                        SET_AMOUNT(*buyIter, ExtOp_OpGrossAmt, GET_NUMBER(*buyIter, ExtOp_Qty)*price);
                        SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
                        SET_ENUM(resultantOp, ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
					    /* WSC- 16067 - Grace -15042020 */
					    OPE_OperNatToDictEnum(OPNAT_ENUM::OpNat_Buy, &enDbaDynst, &enObject); /* Getting corresponding operation OBJECT_ENUM for Buy:OPNAT_ENUM to be passed as arg to func OPE_ComputeNetAmount */
					    buyOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					    OPE_ExtOpToOp(*buyIter, buyOper, stratHierHead, TRUE);
					    OPE_ComputeNetAmount(enObject, buyOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);/* Transform the'extended'operation record into an operation record to compute Net Amount in OPE_ComputeNetAmount*/
					    SET_AMOUNT(*buyIter, ExtOp_OpNetAmt, opNetAmt);
					    resultOperOp = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					    OPE_ExtOpToOp(resultantOp, resultOperOp, stratHierHead, TRUE);
					    OPE_ComputeNetAmount(enObject, resultOperOp, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					    SET_AMOUNT(resultantOp, ExtOp_OpNetAmt, opNetAmt);
                    }
                    /* Go to the next order and beyond if any in the buy Order list, set them to Processed */
                    while (++buyIter != buyOrderList.cend())
                    {
                        SET_ENUM(*buyIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_Processed);
                    }
                }
                else if (sellIter != sellOrderList.cend() && sellQty > 0)
                {
                    /* PMSTA-43829 - sanand - 01032021
                       Avoid creation of resultant when the buys and sells are cancelling each
                       other out and there are some sell orders remaining */
                    if(CMP_NUMBER(sellQty, GET_NUMBER(*sellIter, ExtOp_Qty)) != 0)
                    {
                        price = GET_PRICE(*sellIter, ExtOp_Price); /* PMSTA-38658 - Adarsh - 27012020 */
                        resultantOp = ALLOC_DYNST_SUPPLFLD(ExtOp, iNbCol);
                        COPY_DYNST(resultantOp, *sellIter, ExtOp);
                        SET_NULL_PTR(resultantOp, ExtOp_EditBackupPtr);                     /*  To avoid crash while run from the GUI   PMSTA-47419 */
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_OriginalQty, *sellIter, ExtOp, ExtOp_Qty);
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_InstrId, *sellIter, ExtOp, ExtOp_InstrId);
                        COPY_DYNFLD(resultantOp, ExtOp, ExtOp_PtfId, *sellIter, ExtOp, ExtOp_PtfId);
                        SET_ENUM(resultantOp , ExtOp_NatureEn , OPNAT_ENUM::OpNat_Sell);
                        SET_NUMBER(resultantOp, ExtOp_Qty, sellQty);
                        SET_AMOUNT(resultantOp, ExtOp_AcctNetAmt, sellQty*price);
                        SET_AMOUNT(resultantOp, ExtOp_OpGrossAmt, sellQty*price);
                        SET_NUMBER(*sellIter, ExtOp_Qty, GET_NUMBER(*sellIter, ExtOp_Qty) - sellQty);
                        SET_AMOUNT(*sellIter, ExtOp_AcctNetAmt, GET_NUMBER(*sellIter, ExtOp_Qty)*price);
                        SET_AMOUNT(*sellIter, ExtOp_OpGrossAmt, GET_NUMBER(*sellIter, ExtOp_Qty)*price);
                        SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_NettedOrder);
					    /* WSC- 16067 - Grace -15042020 */
					    OPE_OperNatToDictEnum(OPNAT_ENUM::OpNat_Sell, &enDbaDynst, &enObject);/* Getting corresponding operation OBJECT_ENUM for Sell:OPNAT_ENUM to be passed as arg to func OPE_ComputeNetAmount */
					    sellOper = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					    OPE_ExtOpToOp(*sellIter, sellOper, stratHierHead, TRUE);
					    OPE_ComputeNetAmount(enObject, sellOper, &opNetAmt, amtCurr, &msgStruct, stratHierHead);/* Transform the'extended'operation record into an operation record to compute Net Amount in OPE_ComputeNetAmount*/
					    SET_AMOUNT(*sellIter, ExtOp_OpNetAmt, opNetAmt);
                        SET_ENUM(resultantOp, ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
					    resultOperOp = ALLOC_DYNST_SUPPLFLD(enDbaDynst, iNbCol);
					    OPE_ExtOpToOp(resultantOp, resultOperOp, stratHierHead, TRUE);
					    OPE_ComputeNetAmount(enObject, resultOperOp, &opNetAmt, amtCurr, &msgStruct, stratHierHead);
					    SET_AMOUNT(resultantOp, ExtOp_OpNetAmt, opNetAmt);
                    }
                    /* Go to the next order if any in the sell Order list, set them to Processed */
                    while (++sellIter != sellOrderList.cend())
                    {
                        SET_ENUM(*sellIter, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_Processed);
                    }
                }
                if (resultantOp != NULLDYNST)
                {
                    SET_ENUM(resultantOp, ExtOp_OrderNettingEn, ORDER_NETTING_ENUM::OrderNetting_OrderGenFromNetting);
                    if( RET_SUCCEED == FIN_SetOrderNettingCriteria(dynScptDefStp,resultantOp) ) /* PMSTA - 38809 - sanand - 30012020 */
                    {
                    if ((ret = DBA_AddHierRecord(stratHierHead, resultantOp, ExtOp, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(FILEINFO, "FIN_NetOrders: Unable to add ExtOp to hierarchy");
                        FREE(ordersTab);
                        return ret;
                    }
                }
            }
        }
        }
        /* Advance the iterator to the next Instrument collection */
        mapIter++;
    }

    return ret;
}

/********************************************************************************************
**  Function             :  FIN_CheckPtfHierGroupingStatus()
**
**  Description          :  Check the Portfolio Hierarchy for Hierarchy Grouping
**
**  Arguments            :	stratHierHead	strategy hierarchy header pointer
**							ptf				portfolio structure pointer
**
**
**  Return               :  PtfHierGroupOrderEn : NotConsideredForHierarchyGrouping
**                                                    or
**							PtfHierGroupOrderEn : ConsideredForHierarchyGrouping
**
**
**  Creation 		     :  PMSTA-40208 -26102020 - adarshn
**
**  Modif.               :
**********************************************************************************************/
PtfHierGroupOrderEn FIN_CheckPtfHierGroupingStatus(DBA_HIER_HEAD_STP stratHierHead, DBA_DYNFLD_STP ptf)
{
    DBA_DYNFLD_STP parentPtf = NULL, 
                   childPtf  = ptf;
    RET_CODE       ret       = RET_SUCCEED;
    FLAG_T	       allocPtfFlg = FALSE;
    PtfHierGroupOrderEn         parStatus;
    ID_T           parPtfId  = GET_ID(childPtf, A_Ptf_ParentPortId),
                   parentPtfId;

    if (PtfHierGroupOrderEn::InheritedFromHierarchyHead == static_cast<PtfHierGroupOrderEn>(GET_ENUM(ptf, A_Ptf_HierGroupOrderEn)))
    {
        do
        {
            parentPtfId = parPtfId;
            if ((ret = DBA_GetPtfById(parentPtfId, TRUE, &allocPtfFlg, &parentPtf, (PTR)stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                MSG_SendMesg(FILEINFO, "FIN_CheckPtfHierGroupingStatus: Unable to get Parent Ptf by Id");
                return PtfHierGroupOrderEn::NotConsideredForHierarchyGrouping;
            }
            parPtfId = GET_ID(parentPtf, A_Ptf_ParentPortId);
            parStatus = static_cast<PtfHierGroupOrderEn>(GET_ENUM(parentPtf, A_Ptf_HierGroupOrderEn));

            if(allocPtfFlg == TRUE)
                FREE_DYNST(parentPtf, A_Ptf);

        } while (PtfHierGroupOrderEn::InheritedFromHierarchyHead == parStatus);

        return parStatus;
    }
    return (static_cast<PtfHierGroupOrderEn>GET_ENUM(ptf, A_Ptf_HierGroupOrderEn));
}

/********************************************************************************************
**  Function             :  FIN_IsPtfEligible()
**
**  Description          :  Check for Hierrchy Grouping Consideration
**
**  Arguments            :	stratHierHead	strategy hierarchy header pointer 
**							extOp		    ExtOp structure pointer
**
**
**  Return               :  true / false
**
**
**  Creation 		     :  PMSTA-40208 -26102020 - adarshn
**
**  Modif.               :
**********************************************************************************************/
bool FIN_IsPtfEligible(DBA_HIER_HEAD_STP stratHierHead, DBA_DYNFLD_STP extOp)
{
    DBA_DYNFLD_STP ptf         = NULLDYNST;
    FLAG_T		   allocPtfFlg = FALSE;
    RET_CODE       ret         = RET_SUCCEED;

    if ((IS_NULLFLD(extOp, ExtOp_A_Ptf_Ext) == FALSE) &&
        ((ptf = *(GET_EXTENSION_PTR(extOp, ExtOp_A_Ptf_Ext))) != NULLDYNST))
    {
        if (PtfHierGroupOrderEn::NotConsideredForHierarchyGrouping == FIN_CheckPtfHierGroupingStatus(stratHierHead, ptf))
        {
            return false;
        }
    }
    else
    {
        if ((ret = DBA_GetPtfById(GET_ID(extOp, ExtOp_PtfId), TRUE, &allocPtfFlg, &ptf,
                                  (PTR)stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_IsPtfEligible : error loading portfolio (ID=%1)",
                           IdType, GET_ID(extOp, ExtOp_PtfId));
            return false;
        }
        if (PtfHierGroupOrderEn::NotConsideredForHierarchyGrouping == FIN_CheckPtfHierGroupingStatus(stratHierHead, ptf))
        {
            if (allocPtfFlg == TRUE)
                FREE_DYNST(ptf, A_Ptf);
            return false;
        }
    }
    if (allocPtfFlg == TRUE)
        FREE_DYNST(ptf, A_Ptf);

    return true;
}

/********************************************************************************************
**  Function             :  FIN_IsNonCashInstr()
**
**  Description          :  Check for cash instrument
**
**  Arguments            :	stratHierHead	strategy hierarchy header pointer
**							extOp		    ExtOp structure pointer
**
**
**  Return               :  true / false
**
**
**  Creation 		     :  PMSTA-40208 -26102020 - adarshn
**
**  Modif.               :
**********************************************************************************************/
bool FIN_IsNonCashInstr(DBA_HIER_HEAD_STP stratHierHead, DBA_DYNFLD_STP extOp)
{
    DBA_DYNFLD_STP instrPtr   = NULLDYNST;
    FLAG_T		   allocFlg   = FALSE;
    RET_CODE       ret        = RET_SUCCEED;

    if ((IS_NULLFLD(extOp, ExtOp_A_Instr_Ext) == FALSE) &&
        ((instrPtr = *(GET_EXTENSION_PTR(extOp, ExtOp_A_Instr_Ext))) != NULLDYNST))
    {
        if (INSTRNAT_ENUM::InstrNat_CashAcct == static_cast<INSTRNAT_ENUM>GET_ENUM(instrPtr, A_Instr_NatEn))
        {
            return false;
        }
    }
    else
    {
        if ((ret = DBA_GetInstrById(GET_ID(extOp, ExtOp_InstrId), TRUE, &allocFlg, &instrPtr,
                                    stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_IsNonCashInstr : error loading instrument (ID=%1)",
                           IdType, GET_ID(extOp, ExtOp_InstrId));
            return false;
        }
        if (INSTRNAT_ENUM::InstrNat_CashAcct == static_cast<INSTRNAT_ENUM>GET_ENUM(instrPtr, A_Instr_NatEn))
        {
            if (allocFlg == TRUE)
                FREE_DYNST(instrPtr, A_Instr);
            return false;
        }
    }
    if (allocFlg == TRUE)
        FREE_DYNST(instrPtr, A_Instr);

    return true;
}

/********************************************************************************************
**  Function             :  FIN_SetCriteria()
**
**  Description          :  Set the appropriate criteria according to the function script provided.
**
**  Arguments            :	dynScptDefStp   Script definition
**                          order           Order for which the Netting criteria to be set
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-40208 - sanand - 27092020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_SetCriteria(DBA_DYNFLD_STP dynScptDefStp,DBA_DYNFLD_STP order, FIELD_IDX_T opCriteria)
{
    RET_CODE                retCode = RET_SUCCEED;
    char                    *pszScript = NULL;
    SCPT_ARG_STP            genCtxStp = (SCPT_ARG_STP)NULL;
    INFO_T                  operationCriteria;
    DBA_DYNFLD_STP          retFldStp = NULLDYNSTPTR;
    DBA_DYNFLD_ST           retFldSt;
    retFldStp = &retFldSt;
    memset(retFldStp, 0, sizeof(DBA_DYNFLD_ST));

    if (IS_NULLFLD(dynScptDefStp, A_ScriptDef_Def) == FALSE)
    {
        pszScript = GET_INFO(dynScptDefStp, A_ScriptDef_Def);

        /* Call script analysis */
        retCode = SCPT_GenerateScptTree(pszScript
                                        , EOp
                                        , InternalSMode
                                        , NullDataType
                                        , &genCtxStp);
    }
    if ((retCode == RET_SUCCEED) && (genCtxStp != NULL))
    {
        operationCriteria[0] = END_OF_STRING;
        retCode = SCPT_ExecScptTreeSpec(genCtxStp
                                        , NULLDYNST
                                        , NULL
                                        , order
                                        , InfoType
                                        , retFldStp
                                        , 0
                                        , order
                                        , (SCPT_FMTDATADEF_STP)NULL
                                        , TRUE
                                        , FALSE);
        if (IS_NULLFLD(retFldStp, 0) == FALSE)
        {
            strcpy(operationCriteria, GET_INFO(retFldStp, 0));
            SET_INFO(order, opCriteria, operationCriteria);
        }
    }
    return retCode;
}

/********************************************************************************************
**  Function             :  FIN_SetHierarchyGroupingCriteria()
**
**  Description          :  Set hierarchy grouping criteria according to the function script provided.
**
**  Arguments            :	dynScptDefStp   Script definition
**                          order           Order for which the Netting criteria to be set
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-40208 - sanand - 27092020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_SetHierarchyGroupingCriteria(DBA_DYNFLD_STP dynScptDefStp, DBA_DYNFLD_STP order)
{
    return (FIN_SetCriteria(dynScptDefStp, order, ExtOp_HierGroupingCriteria));
}

RET_CODE getScriptDefinition(OBJECT_ENUM entityObjEn, DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP dynScptDefStp)
{
    RET_CODE                               ret = RET_SUCCEED;
    DICT_ATTRIB_STP hierGroupingCriteriaAttrib = DBA_GetAttributeBySqlName(entityObjEn, "hier_grouping_criteria");
    DICT_T                          attrDictId = hierGroupingCriteriaAttrib->attrDictId;

    SET_DICT(dynScptDefStp, A_ScriptDef_AttrDictId, attrDictId);
    SET_DICT(dynScptDefStp, A_ScriptDef_ObjId, GET_ID(domainPtr, A_Domain_HierGroupingFctDictId));
    SET_ENUM(dynScptDefStp, A_ScriptDef_NatEn, ScriptDef_UpdateFieldsDefVal);

    DbiConnectionHelper dbiConnHelper;
    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

    if ((ret = DBA_GetScptDef(dynScptDefStp, *dbiConnHelper.getConnection())) != RET_SUCCEED)
    {
        /* Getting script definition failed, log a message */
        return ret;
    }
    return ret;
}

/********************************************************************************************
**  Function             :  FIN_isRightsEnabled()
**
**  Description          :  return true or false based on rights set.
**
**  Arguments            :	generalContextPtr
**                          inDynStp        record for which rights need to be checked using generalContextPtr
**
**  Return               :  true/false
**
**
**
**  Creation 		     :  PMSTA-40208 - sanand - 27092020
**
**  Modif.               :
**********************************************************************************************/
bool FIN_isRightsEnabled(SCPT_ARG_STP 	   generalContextPtr,
                     DBA_DYNFLD_STP    inDynStp)
{
    MemoryPool              mp;
    RET_CODE                ret = RET_SUCCEED;
    DBA_DYNFLD_STP          retFldStp = NULLDYNSTPTR;
    DBA_DYNFLD_ST           retFldSt;

    retFldStp = &retFldSt;
    retFldStp = mp.allocDynstWithOutDef(FILEINFO, sizeof(DBA_DYNFLD_ST));

    ret = SCPT_ExecScptTreeSpec(generalContextPtr
        , NULLDYNST
        , NULL
        , inDynStp
        , EnumType
        , retFldStp
        , 0
        , inDynStp
        , (SCPT_FMTDATADEF_STP)NULL
        , TRUE
        , FALSE);

    if (IS_NULLFLD(retFldStp, 0) == FALSE)
    {
        ENUM_T derivedFuncRits = GET_ENUM(retFldStp, 0);
        if ( 1 == derivedFuncRits)
        {
            /*function right set for this record*/
            return true;
        }
    }

    return false;
}


/********************************************************************************************
**  Function             :  FIN_getRightsScrDef()
**
**  Description          :  return hierarchy rights function script ctx.
**
**  Arguments            :	functionDictId     :- dict id for which rights should be checked
**                          object             :- object for which rights should be checked (Eop)
**                          *generalContextPt  
**
**
**  Return               :  true/false
**                          generalContextPt
**
**
**  Creation 		     :  PMSTA-40208 - sanand - 27092020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_getRightsScrDef(ID_T              functionDictId,
                     OBJECT_ENUM 	   object,
                     SCPT_ARG_STP 	   *generalContextPtr)
{
    MemoryPool                              mp;
    RET_CODE                               ret = RET_SUCCEED;
    DBA_DYNFLD_STP               dynScptDefStp = mp.allocDynst(FILEINFO, A_ScriptDef);
    DICT_ATTRIB_STP       rightsCriteriaAttrib = DBA_GetAttributeBySqlName(object, "right_to_run_f");
    DICT_T                          attrDictId = rightsCriteriaAttrib->attrDictId;

    SET_DICT(dynScptDefStp, A_ScriptDef_AttrDictId, attrDictId);
    SET_DICT(dynScptDefStp, A_ScriptDef_ObjId, functionDictId);
    SET_ENUM(dynScptDefStp, A_ScriptDef_NatEn, ScriptDef_UpdateFieldsDefVal);

    DbiConnectionHelper dbiConnHelper;
    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

    if ((ret = DBA_GetScptDef(dynScptDefStp, *dbiConnHelper.getConnection())) != RET_SUCCEED)
    {
        MSG_SendMesg(FILEINFO, "FIN_getRightsScrDef: Unable to get Rights for dict function");
        return ret;
    }
    if (TRUE == IS_NULLFLD(dynScptDefStp, A_ScriptDef_Def))
    {
        /* Script definition not present , return false*/
        return ret;
    }

    char                    *pszScript = NULL;
    pszScript = GET_INFO(dynScptDefStp, A_ScriptDef_Def);

    ret = SCPT_GenerateScptTree(pszScript
        , object
        , InternalSMode
        , NullDataType
        , generalContextPtr);

    if (ret != RET_SUCCEED || generalContextPtr == NULL)
    {
        MSG_SendMesg(FILEINFO, "Rights script definition Error!!");
        return ret;
    }

    return ret;
}

/********************************************************************************************
**  Function             :  FIN_GroupOrdersByHierarchy()
**
**  Description          :  Perform Hierarchy Grouping of the list of Orders provided.
**
**  Arguments            :	orderCount      Number of Orders
**                          ordersTab       List of Orders
**							domainPtr     	domain structure pointer
**							stratHierHead	strategy hierarchy header pointer
**							iNbCol          Number of Columns along with the supplementary fields
**
**  Return               :  RET_SUCEED or Error code
**
**
**
**  Creation 		     :  PMSTA-40208 - sanand - 24092020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_GroupOrdersByHierarchy(int orderCount,
                                    DBA_DYNFLD_STP *ordersTab,
                                    DBA_DYNFLD_STP domainPtr,
                                    DBA_HIER_HEAD_STP stratHierHead,
                                    int iNbCol,
                                    DICT_FCT_STP        pdictfctGrouping,
                                    DICT_FCT_STP        pdictfctOrigin,
                                    SCPT_FMTDATADEF_STP pscptFmtDataDef)
{
    RET_CODE            ret = RET_SUCCEED;

    if (NULLDYNST == ordersTab)
        return ret;

    FLAG_T           *pflag = NULL;
    MemoryPool                  mp;
    if ((pflag = (FLAG_T *)CALLOC(GET_FLD_NBR(A_Domain), sizeof(FLAG_T))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }
    mp.owner(pflag);
    memset(pflag, (int)TRUE, GET_FLD_NBR(A_Domain) * sizeof(FLAG_T));
    pflag[A_Domain_HierGroupingFctDictId] = FALSE;

    /* Fetch the appropriate function dict id and make sure its valid */
    SCPT_ComputeScreenDV(Domain,
                         GET_DICT(domainPtr, A_Domain_FctDictId),
                         pflag,
                         NULL,
                         domainPtr,
                         NULL,
                         domainPtr,
                         NULLDYNST,
                         TRUE,
                         TRUE,
                         EvalType_DefVal,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         DictScreen,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if (IS_NULLFLD(domainPtr, A_Domain_HierGroupingFctDictId))
    {
        MSG_SendMesg(FILEINFO, "FIN_GroupOrdersByHierarchy: Hierarchy Grouping Function Dict ID Unavailable");
        return RET_SUCCEED;
    }


    DBA_DYNFLD_STP      buyScptDefStp = mp.allocDynst(FILEINFO, A_ScriptDef);
    DBA_DYNFLD_STP      sellScptDefStp = mp.allocDynst(FILEINFO, A_ScriptDef);
    DBA_DYNFLD_STP      dynScptDefStp = NULLDYNST;

    /* Get the script definition for the Buy Operation */
    if ((ret = getScriptDefinition(BuyOpEnt, domainPtr, buyScptDefStp)) != RET_SUCCEED)
    {
        MSG_SendMesg(FILEINFO, "FIN_GroupOrdersByHierarchy: Unable to retrieve the buy function script definition");
        return ret;
    }
    /* Get the script definition for the Sell Operation */
    if ((ret = getScriptDefinition(SellOpEnt, domainPtr, sellScptDefStp)) != RET_SUCCEED)
    {
        MSG_SendMesg(FILEINFO, "FIN_GroupOrdersByHierarchy: Unable to retrieve the sell function script definition");
        return ret;
    }
    /* Function script definition needs to be added for all the orders */
    for (int orderIdx = 0; orderIdx < orderCount; orderIdx++)
    {
        DBA_DYNFLD_STP orderDetail = ordersTab[orderIdx];
        dynScptDefStp = ((OPNAT_ENUM)OpNat_Buy == GET_ENUM(orderDetail, ExtOp_NatureEn)) ?
            buyScptDefStp : sellScptDefStp;
         
        if ((ret = FIN_SetHierarchyGroupingCriteria(dynScptDefStp, orderDetail)) != RET_SUCCEED)
        {
            /* Getting criteria failed, log a message */
            MSG_SendMesg(FILEINFO, "FIN_GroupOrdersByHierarchy: Unable to set grouping criteria script definition");
            return ret;
        }
    }

    ret = FIN_hierGroupOrder(stratHierHead,ordersTab,orderCount,domainPtr,pdictfctGrouping,pdictfctOrigin,pscptFmtDataDef,false,iNbCol);

    return ret;
}



/********************************************************************************************
**  Function             :  checkAndgetHierParent()
**
**  Description          :  Automatic hier grouping - get hier parent. check hier first, if not exist, make a db call.
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC bool getBlockPtfId(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP extOp,
    DBA_DYNFLD_STP refExtOp,
    SCPT_FMTDATADEF_STP scptFmtDataDef,
    FLAG_T* pflag,
    DICT_T dictId)
{
    SET_NULL_ID(extOp, ExtOp_PtfId);
    pflag[ExtOp_PtfId] = FALSE;
    COPY_DYNFLD(extOp, ExtOp, ExtOp_NatureEn, refExtOp, ExtOp, ExtOp_NatureEn);

    SCPT_ComputeScreenDV(EOp,
        dictId,
        pflag,
        NULL,
        extOp,
        NULL,
        domainPtr,
        NULLDYNST,
        TRUE,
        TRUE,
        EvalType_DefValAndFilter,
        0,
        NULL,
        NULL,
        hierHead,
        -1,
        DictScreen,
        NULL,
        NULL,
        scptFmtDataDef,
        refExtOp,
        refExtOp,
        EOp,
        FALSE,
        TRUE,
        0);

    return (IS_NULLFLD(extOp, ExtOp_PtfId) == FALSE);
}

/********************************************************************************************
**  Function             :  FIN_checkRightsAndDeriveCriteria()
**
**  Description          :  Automatic hier grouping - check function righs and dervice creiteria
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC bool FIN_checkRightsAndDeriveCriteria(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP extOp,
    DBA_DYNFLD_STP domainPtr,
    DICT_FCT_STP dictfctGrouping,
    DICT_FCT_STP dictfctOrigin,
    SCPT_FMTDATADEF_STP scptFmtDataDef,
    FLAG_T* righToRunFlg,
    int rghtIndex)
{
    if (IS_NULLFLD(extOp, ExtOp_CompoundOrderCode) == FALSE ||
        GET_FLAG(extOp, ExtOp_ExcludeFromBlockFlg) == TRUE ||
        ORDER_NETTING_ENUM::OrderNetting_NettedOrder == static_cast<ORDER_NETTING_ENUM>(GET_ENUM(extOp, ExtOp_OrderNettingEn))
        )
    {
        return false;
    }

    
            righToRunFlg[rghtIndex] = TRUE;
            righToRunFlg[ExtOp_HierGroupingCriteria] = FALSE;


            SCPT_ComputeScreenDV(EOp,
                dictfctGrouping->dictId,
                righToRunFlg,
                        NULL,
                extOp,
                NULL,
                domainPtr,
                        NULLDYNST,
                TRUE,
                TRUE,
                        EvalType_DefVal,
                0,
                (int*)NULL,
                NULL,
                        hierHead,
                -1,
                        DictScreen,
                NULL,
                NULL,
                scptFmtDataDef,
                extOp,   /*  Currently selected data (format data)   */
                extOp,   /*  Refernce data (real data)               */
                EOp,
                FALSE,             /*  True DV on Buy or Sell                  */
                        FALSE,             /*  Flag Impact         */
                0
            );

            righToRunFlg[rghtIndex] = FALSE;
            righToRunFlg[ExtOp_HierGroupingCriteria] = TRUE;

    return (!IS_NULLFLD(extOp, ExtOp_HierGroupingCriteria));
}

/********************************************************************************************
**  Function             :  childInit()
**
**  Description          :  Automatic hier grouping - init child order based on head. no error check.
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC void childInit(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP blockExtOpPtr,
    DBA_DYNFLD_STP child,
    DICT_T dictId,
    SCPT_FMTDATADEF_STP scptFmtDataDef)
{
    FLAG_T* pflagtabVar = nullptr;
    if ((pflagtabVar = (FLAG_T*)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
    {
        return;
    }
    SCPT_ComputeScreenDV(EOp,
        dictId,
        pflagtabVar,
        NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
        child,
        NULL,
        domainPtr,
        NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
        TRUE,
        TRUE,
        EvalType_ChildInit,
        0,
        NULL,
        NULL,
        hierHead,         /*  HFI-PMSTA-22893-160327  */
        -1,
        DictScreen,
        NULL,
        NULL,
        scptFmtDataDef,
        blockExtOpPtr,
        blockExtOpPtr,
        EOp,
        FALSE,
        TRUE,
        0);

    FREE(pflagtabVar);
}
/********************************************************************************************
**  Function             :  createOrder()
**
**  Description          :  Automatic hier grouping - create block order and init values
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC RET_CODE createOrder(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP domainPtr,
    DICT_FCT_STP dictfctGrouping,
    DICT_FCT_STP dictfctOrigin,
    SCPT_FMTDATADEF_STP scptFmtDataDef,
    std::map<std::string, std::vector<std::pair<ID_T, DBA_DYNFLD_STP>>> & inputMap,
    FLAG_T* scptFlagTab,
    FLAG_T* tempScptFlagTab,
    FIELD_IDX_T copyFields[],
    int fldSize,
    unsigned int min,
    unsigned int max,
    int iNbCol)
{
    MemoryPool pool;
    ID_T fctResultId = GET_ID(domainPtr, A_Domain_FctResultId);

    for (auto iter = inputMap.begin(); iter != inputMap.end(); ++iter)
    {
        /* check min-max criteria. 0 in max means no limit */
        if (iter->second.size() >= min && (iter->second.size() <= max || max == 0))
        {
            bool first = true;
            DBA_DYNFLD_STP     blockExtOpPtr = nullptr;
            NUMBER_T locQty = ZERO_NUMBER;

            for (auto innerIter = iter->second.begin(); innerIter != iter->second.end(); ++innerIter)
            {
                if (first)
                {
                    first = false;
                    if ((blockExtOpPtr = ALLOC_DYNST_SUPPLFLD(ExtOp, iNbCol)) == nullptr)
                    {
                        return (RET_MEM_ERR_ALLOC);
                    }

                    /* init block */
                    SET_ID(blockExtOpPtr, ExtOp_PtfId, innerIter->first);

                    /*Copy a few fields from child to parent  */
                    for (int i = 0; i < fldSize; ++i)
                        COPY_DYNFLD(blockExtOpPtr, ExtOp, copyFields[i], innerIter->second, ExtOp, copyFields[i]);

                    /* Function script for block order init */
                    /*  Fill new global order with default values  */
                    SCPT_ComputeScreenDV(EOp,
                        dictfctGrouping->dictId,
                        scptFlagTab,
                        NULL,
                        blockExtOpPtr,
                        NULL,
                        domainPtr,
                        NULLDYNST,
                        TRUE,
                        TRUE,
                        EvalType_DefValAndFilter,
                        0,
                        NULL,
                        NULL,
                        hierHead,
                        -1,
                        DictScreen,
                        NULL,
                        NULL,
                        scptFmtDataDef,
                        innerIter->second,
                        innerIter->second,
                        EOp,
                        FALSE,
                        TRUE,
                        0);

                    
                    SET_ENUM(blockExtOpPtr, ExtOp_FusionEn, OpFusion_Untreated);
                    SET_ENUM(blockExtOpPtr, ExtOp_HierOperNatEn, HierOpNatEn::HierOpNat_BlockOrder);
                    SET_ENUM(blockExtOpPtr, ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
                    if (IS_NULLFLD(blockExtOpPtr, ExtOp_StatusEn))
                    {
                        COPY_DYNFLD(blockExtOpPtr, ExtOp, ExtOp_StatusEn, innerIter->second, ExtOp, ExtOp_StatusEn);
                    }

                    if (dictfctGrouping->parFctDictId == DictFct_HierarchyGrouping)
                        SET_ENUM(blockExtOpPtr, ExtOp_CheckParentEn, CheckParent_Disable);

                    SET_FLAG(blockExtOpPtr, ExtOp_ConfirmedFlg, TRUE);

                    /*add to hier to get id */
                    if (DBA_AddHierRecordSupplFld(hierHead, blockExtOpPtr, ExtOp, FALSE, iNbCol, HierAddRec_NoLnk) != RET_SUCCEED) /* add links later if needed. now no values, do don't*/
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_hierGroupOrder() : Add to hier blockExtOp failed");
                        FREE_DYNST_SUPPLFLD(blockExtOpPtr, iNbCol);
                        return RET_DBA_ERR_HIER;
                    }
                    /*init block end */
                }
                /* add only qty. rest ignore. */
                locQty += (GET_NUMBER(innerIter->second, ExtOp_Qty));
                /* call child init script */
                childInit(hierHead, domainPtr, blockExtOpPtr, innerIter->second, dictfctGrouping->dictId, scptFmtDataDef);

                SET_ID(innerIter->second, ExtOp_ParentHierExtOpId, GET_EXTOP_DATABASE_ID(blockExtOpPtr)); /* shold be ExtOp_DbId or Draft_order id?? remap after adding to hier/db*/
                COPY_DYNFLD(innerIter->second, ExtOp, ExtOp_HierOperationCd, blockExtOpPtr, ExtOp, ExtOp_Cd); /* this will be moslty null. need to check. ??*/
                SET_ENUM(innerIter->second, ExtOp_HierOperNatEn, HierOpNatEn::HierOpNat_ChildOrder);
                SET_ENUM(innerIter->second, ExtOp_ParOpNatEn, ParOpNat_None);
                SET_ID(innerIter->second, ExtOp_FctResultId, fctResultId);

                /* make force links */
                if (dictfctOrigin->dictId == DictFct_OrderEntry || dictfctOrigin->dictId == DictFct_OrderList)
                {
                SET_ID(innerIter->second, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(blockExtOpPtr));
                    SET_ID(innerIter->second, ExtOp_ParentHierExtOpId, GET_ID(blockExtOpPtr , ExtOp_Id));
                }
                else
                SET_ID(innerIter->second, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(blockExtOpPtr));
                /*  Force data link                                             */
                DBA_ForceLink(hierHead, ExtOp, ExtOp_ParExtOp_Ext, innerIter->second, blockExtOpPtr);
                DBA_ForceLink(hierHead, ExtOp, ExtOp_ChildExtOp_Ext, blockExtOpPtr, innerIter->second);

                /*  Fill some fields                                                */
                if (dictfctOrigin->parFctDictId == DictFct_OrderEntry)
                {
                    if (GET_ENUM(innerIter->second, ExtOp_DbStatusEn) == ExtOpDbStatus_SimulUpToDate)
                        SET_ENUM(innerIter->second, ExtOp_DbStatusEn, ExtOpDbStatus_SimulToUpdate);
                }
                SET_ENUM(innerIter->second, ExtOp_ConfirmedFlg, TRUE);

            }
            /* set final qty */
            SET_NUMBER(blockExtOpPtr, ExtOp_Qty, locQty);
            SET_NUMBER(blockExtOpPtr, ExtOp_EffectChildQty, locQty); /*This number should normally be equal to the quantity of the 'parent' order */

            /* Run screen dv to compute other field values.*/
            memset(tempScptFlagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));

            OPE_InitOrderWithFctScreenScript(dictfctOrigin->dictId,
                0,
                blockExtOpPtr,
                domainPtr,
                tempScptFlagTab,
                hierHead);
            /*Add head to map*/
            SET_ENUM(blockExtOpPtr, ExtOp_ParOpNatEn, ParOpNat_None);
            SET_ID(blockExtOpPtr, ExtOp_FctResultId, fctResultId);
            iter->second.push_back(std::make_pair((GET_ID(blockExtOpPtr, ExtOp_PtfId)), blockExtOpPtr)); /* last one in vector will be block order extop*/

        }
    }
    return RET_SUCCEED;
}


/********************************************************************************************
**  Function             :  createHierBlock()
**
**  Description          :  Automatic hier grouping - dervive values needed for creating block order
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC RET_CODE createHierBlock(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP domainPtr,
    DICT_FCT_STP dictfctGrouping,
    DICT_FCT_STP dictfctOrigin,
    SCPT_FMTDATADEF_STP scptFmtDataDef,
    DBA_DYNFLD_STP* extOpTab,
    int extOpNbr,
    bool rightsAndCriteriaChecked,
    int iNbCol)
{

    FLAG_T		              *scptFlagTab = nullptr;
    FLAG_T                    *tempScptFlagTab = nullptr;
    FLAG_T                    *righToRunFlg = nullptr;
    FLAG_T                    *dummyBlockInitFlag = nullptr;
    DBA_DYNFLD_STP      dummyExtOp = nullptr;

    MemoryPool              pool;
    int                           rightIndex = DBA_GetRightToRunIndex(EOp);

    std::map<std::string, std::vector<std::pair<ID_T, DBA_DYNFLD_STP>>> buyExtOp;
    std::map<std::string, std::vector<std::pair<ID_T, DBA_DYNFLD_STP>>> sellExtOp;

    unsigned int minChildOrdersPerBlock = 0;
    unsigned int maxChildOrdersPerBlock = 0;

    GEN_GetApplInfo(ApplMinChildOrdersHierGroup, &minChildOrdersPerBlock);
    GEN_GetApplInfo(ApplMaxChildOrdersHierGroup, &maxChildOrdersPerBlock);

    /* copy fields */
    FIELD_IDX_T copyFields[] = { ExtOp_NatureEn, ExtOp_ConfirmedFlg, ExtOp_InstrId,
        ExtOp_OpDate, ExtOp_AcctDate, ExtOp_ValueDate, ExtOp_InstrCurrId, ExtOp_FctResultId , ExtOp_DbStatusEn };

    int fldSize = sizeof(copyFields) / sizeof(FIELD_IDX_T);

    /* allocate mem*/
    try {
        scptFlagTab = (FLAG_T*)pool.calloc(FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
        tempScptFlagTab = (FLAG_T*)pool.calloc(FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
        righToRunFlg = (FLAG_T*)pool.calloc(FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
        dummyBlockInitFlag = (FLAG_T*)pool.calloc(FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
        dummyExtOp = pool.allocDynst(FILEINFO, ExtOp);
    }
    catch (std::bad_alloc & ba)
    {
        MSG_SendExceptionMesg(FILEINFO, "", ba.what());
        return (RET_MEM_ERR_ALLOC);
    }

    memset(scptFlagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));
    memset(tempScptFlagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));
    memset(righToRunFlg, 1, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));
    memset(dummyBlockInitFlag, 1, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));


    for (int i = 0; i < fldSize; ++i)
        scptFlagTab[copyFields[i]] = TRUE;

    scptFlagTab[ExtOp_PtfId] = TRUE;

    righToRunFlg[rightIndex] = FALSE;

    dummyBlockInitFlag[ExtOp_PtfId] = FALSE;
    DBA_SetDfltEntityFld(EOp, ExtOp, dummyExtOp);

    SCPT_ARG_STP            genCtxStp = (SCPT_ARG_STP)NULL;

    if (!FIN_getRightsScrDef(GET_ID(domainPtr, A_Domain_HierGroupingFctDictId), EOp, &genCtxStp) || genCtxStp == NULL)
    {
        MSG_SendMesg(FILEINFO, "createHierBlock: rights script not avilable for execution of Hierarchy grouping function");
        return RET_SUCCEED;
    }

    /* init maps */
    for (int extOpIndex = 0; extOpIndex < extOpNbr; ++extOpIndex)
    {
        if (!FIN_isRightsEnabled(genCtxStp, extOpTab[extOpIndex])) /*if no rights continoue*/
            continue;

        if (!FIN_IsPtfEligible(hierHead, extOpTab[extOpIndex])) /* Check for HierGroupOrderEnum */
            continue;

        if (!FIN_IsNonCashInstr(hierHead, extOpTab[extOpIndex])) /* Check for Cash Intrument */
            continue;

        if (rightsAndCriteriaChecked || FIN_checkRightsAndDeriveCriteria(hierHead,
            extOpTab[extOpIndex],
            domainPtr,
            dictfctGrouping,
            dictfctOrigin,
            scptFmtDataDef,
            righToRunFlg,
            rightIndex))
        {

            std::string key(GET_INFO(extOpTab[extOpIndex], ExtOp_HierGroupingCriteria));

            if (getBlockPtfId(hierHead, domainPtr, dummyExtOp, extOpTab[extOpIndex], scptFmtDataDef, dummyBlockInitFlag, dictfctGrouping->dictId))
            {
                key.append(std::to_string((GET_ID(dummyExtOp, ExtOp_PtfId))));

                switch (GET_ENUM(extOpTab[extOpIndex], ExtOp_NatureEn))
                {
                case OpNat_Buy:
                    buyExtOp[key].push_back(std::make_pair(GET_ID(dummyExtOp, ExtOp_PtfId), extOpTab[extOpIndex]));
                    break;
                case OpNat_Sell:
                    sellExtOp[key].push_back(std::make_pair(GET_ID(dummyExtOp, ExtOp_PtfId), extOpTab[extOpIndex]));
                    break;
                }
            }
        }
    }
    /* end init maps */

    /* loop thru orders eligile for grouping */
    if (RET_SUCCEED != createOrder(hierHead,
        domainPtr,
        dictfctGrouping,
        dictfctOrigin,
        scptFmtDataDef,
        buyExtOp,
        scptFlagTab,
        tempScptFlagTab,
        copyFields,
        fldSize,
        minChildOrdersPerBlock,
        maxChildOrdersPerBlock,
        iNbCol))
    {
        return RET_GEN_ERR_NOACTION;
    }
    if (RET_SUCCEED != createOrder(hierHead,
        domainPtr,
        dictfctGrouping,
        dictfctOrigin,
        scptFmtDataDef,
        sellExtOp,
        scptFlagTab,
        tempScptFlagTab,
        copyFields,
        fldSize,
        minChildOrdersPerBlock,
        maxChildOrdersPerBlock,
        iNbCol))
    {
        return RET_GEN_ERR_NOACTION;
    }

    return RET_SUCCEED;
}
/********************************************************************************************
**  Function             :  FIN_hierGroupOrder()
**
**  Description          :  Automatic hier grouping
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
STATIC RET_CODE FIN_hierGroupOrder(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP *extOpTab,
    int extOpNbr,
    DBA_DYNFLD_STP  domainPtr,
    DICT_FCT_STP        pdictfctGrouping,
    DICT_FCT_STP        pdictfctOrigin,
    SCPT_FMTDATADEF_STP pscptFmtDataDef,
    bool criteriaChecked,
    int iNbCol)
{

    return (createHierBlock(hierHead,
        domainPtr,
        pdictfctGrouping,
        pdictfctOrigin,
        pscptFmtDataDef,
        extOpTab,
        extOpNbr,
        criteriaChecked,
        iNbCol));
}


/********************************************************************************************
**  Function             :  FIN_autoHierGroupOrder()
**
**  Description          :  Automatic hier grouping
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-40208 - LIK - 27092020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE FIN_autoHierGroupOrder(DBA_HIER_HEAD_STP hierHead,
    DBA_DYNFLD_STP  domainPtr,
    DICT_T intitialFctDictId,
    DICT_FCT_STP pdictfctOrigin,
    DBA_DYNFLD_STP	*caseMgtTab,
    int				caseMgtNbr,
    EXTOP_ACTION_ENUM	actionEn,
    bool              splitSessionFlag
)
{
    RET_CODE ret = RET_SUCCEED;
    DICT_FCT_STP    pdictfctGrouping = NULL;
    int     extNbr = 0;
    DBA_DYNFLD_STP*     extOpTab = nullptr;
    int     newExtNbr = 0;
    DBA_DYNFLD_STP*     NEOpTab = nullptr;


    if (DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_HierGroupingFctDictId), DictFctInfo_Stp, &pdictfctGrouping) != RET_SUCCEED ||
        pdictfctGrouping == NULL ||
        pdictfctGrouping->parFctDictId != DictFct_HierarchyGrouping) /* todo - change to our */
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_hierGroupOrder", "A_Domain_HierGroupingFctDictId");
        ret = RET_GEN_ERR_INVARG;
        return (ret);
    }

    if ((ret = DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE,
        NULLFCT, NULLFCT, &extNbr, &extOpTab)) != RET_SUCCEED || extNbr == 0)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_hierGroupOrder() : Zero ExtOp in hier. returning success");
        return ret;
    }
    int iNbCol = GET_FLD_NBR(ExtOp);
    ret = FIN_hierGroupOrder(hierHead,
        extOpTab,
        extNbr,
        domainPtr,
        pdictfctGrouping,
        pdictfctOrigin,
        NULL,
        false,
        iNbCol
    );

    FREE(extOpTab);

    if ((ret = DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE,
        NULLFCT, NULLFCT, &newExtNbr, &NEOpTab)) != RET_SUCCEED || extNbr == 0)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_hierGroupOrder() : Zero ExtOp in hier. returning success");
        return ret;
    }

    if (newExtNbr > 0) {
        /* An EO could be NULL, but FamilyOrder isn't able to treat it correctly (and crash) */
        int     locExtNbr = 0;
        DBA_DYNFLD_STP*     loxExtOpTab = (DBA_DYNFLD_STP*)CALLOC(newExtNbr, sizeof(DBA_DYNFLD_STP));
        ID_T                fctResultId = GET_ID(domainPtr, A_Domain_FctResultId);                                                                             /* PMSTA-42373 - vkumar - 041120 */

        if (loxExtOpTab != NULL)
        {

            for (int i = 0; i < newExtNbr; ++i)
            {
                if (NEOpTab[i] != NULLDYNST)
                {
                    loxExtOpTab[locExtNbr] = NEOpTab[i];

                    if (IS_NULLFLD(loxExtOpTab[locExtNbr], ExtOp_FctResultId) == TRUE)                                                                         /* PMSTA-42373 - vkumar - 041120 */
                        SET_ID(loxExtOpTab[locExtNbr], ExtOp_FctResultId, fctResultId);

                    if ((IS_NULLFLD(loxExtOpTab[locExtNbr], ExtOp_HierOperNatEn) ||
                         HierOpNatEn::HierOpNat_BlockOrder != static_cast<HierOpNatEn>(GET_ENUM(loxExtOpTab[locExtNbr], ExtOp_HierOperNatEn))) &&              /* PMSTA-42373 - vkumar - 041120 */
                        !(intitialFctDictId == DictFct_HierarchyGrouping &&
                            pdictfctOrigin->dictId == DictFct_HierarchyGrouping &&
                            pdictfctOrigin->parFctDictId == DictFct_HierarchyGrouping))
                    {
                        /*  Already saved orders could not have the db status insert    */
                        /*  Else these orders will not be saved by DbaFamilyOrder       */
                        if (IS_EXTOP_DATABASE_ID_PRESENT(loxExtOpTab[locExtNbr]) == TRUE)
                        {
                            SET_ENUM(loxExtOpTab[locExtNbr], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToUpdate);
                        }
                        else
                        {
                            SET_ENUM(loxExtOpTab[locExtNbr], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
                        }
                    }

                    if ((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
                    {
                        /*  Already saved orders could not have the db status insert    */
                        /*  Else these orders will not be saved by DbaFamilyOrder       */
                        if (IS_EXTOP_DATABASE_ID_PRESENT(loxExtOpTab[locExtNbr]) == TRUE)
                        {
                            SET_ENUM(loxExtOpTab[locExtNbr], ExtOp_DbStatusEn, ExtOpDbStatus_ToUpdate);
                        }
                        else
                        {
                            SET_ENUM(loxExtOpTab[locExtNbr], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
                        }
                    }
                    ++locExtNbr;
                }
            }

            if (locExtNbr > 0)
            {
                DbiConnectionHelper  dbiConnHelper;

                ret = DBA_FamilyOrder(actionEn,
                    (DBA_DYNFLD_STP*)loxExtOpTab,
                    locExtNbr, 0,
                    NULL, (PTR)NULL,
                    DBA_NO_ERROR,
                    dbiConnHelper, /* PMSTA-26888 - CHU 170629 */
                    GET_DICT(domainPtr, A_Domain_FctDictId),
                    domainPtr,
                    caseMgtTab, caseMgtNbr,	/* CaseManagement */
                    NULLDYNSTPTR,
                    (PTR)NULL,
                    splitSessionFlag);  /* to know if session splitting was already performed */
            }

            FREE(loxExtOpTab);
        }
    }

    FREE(NEOpTab);
    return ret;
}

/* hier grouping execution handling - start */
/********************************************************************************************
**  Function             :  calcAlreadyAllocated()
**
**  Description          :  calculated allocated qty
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-42678  - LIK - 27112020
**
**  Modif.               :
**********************************************************************************************/

STATIC RET_CODE calcAlreadyAllocated(DBA_DYNFLD_STP childExtOrder,
    DBA_DYNFLD_STP* accExecutions, int accExecutionsNbr,
    DBA_DYNFLD_STP* extExecutions, int extExecutionsNbr,
    NUMBER_T& alreadyAllocated)
{
    alreadyAllocated = 0.0;

    for (int i = 0; i < accExecutionsNbr; ++i)
    {
        if(CMP_DYNFLD((accExecutions[i]), childExtOrder, A_Execution_ExtOrderId, ExtOp_DbId, IdType) == 0)
            alreadyAllocated += (GET_NUMBER((accExecutions[i]), A_Execution_Quantity));
    }
    for (int i = 0; i < extExecutionsNbr; ++i)
    {
        if (CMP_DYNFLD((extExecutions[i]), childExtOrder, A_Execution_ExtOrderId, ExtOp_DbId, IdType) == 0)
           alreadyAllocated += (GET_NUMBER((extExecutions[i]), A_Execution_Quantity));
    }

    return RET_SUCCEED;
}

/********************************************************************************************
**  Function             :  setHierBps()
**
**  Description          :  BP amount calculation for splitting
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-42678  - LIK - 27112020
**
**  Modif.               :
**********************************************************************************************/
STATIC RET_CODE setHierBps(DBA_DYNFLD_STP inExecution,
    DBA_DYNFLD_STP outExecution,
    AMOUNT_T* bpMultiplyAmts,
    AMOUNT_T* bpRemainingAmt,
    FIELD_IDX_T* bpFldsAmt,
    FIELD_IDX_T* bpFldsCurr,
    FIELD_IDX_T* bpFldsTp,
    int bpFldCount)
{
    NUMBER_T allocatedQty = GET_NUMBER(outExecution, A_Execution_Quantity);

    for (int i = 0; i < bpFldCount; ++i)
    {
        AMOUNT_T bpxAmt = CAST_AMOUNT((allocatedQty * bpMultiplyAmts[i]), (GET_ID(inExecution, (bpFldsCurr[i]))));
        if (CMP_AMOUNT(bpxAmt, bpRemainingAmt[i], (GET_ID(inExecution, (bpFldsCurr[i])))) != 1)
        {
            SET_AMOUNT(outExecution, bpFldsAmt[i], bpxAmt);
            bpRemainingAmt[i] -= bpxAmt;
        }
        else
        {
            SET_AMOUNT(outExecution, bpFldsAmt[i], bpRemainingAmt[i]);
            bpRemainingAmt[i] = 0;
        }
        COPY_DYNFLD(outExecution, A_Execution, bpFldsCurr[i], inExecution, A_Execution, bpFldsCurr[i]);
        COPY_DYNFLD(outExecution, A_Execution, bpFldsTp[i], inExecution, A_Execution, bpFldsTp[i]);
    }
    return RET_SUCCEED;
}
/********************************************************************************************
**  Function             :  FIN_CmpExtOpQtyBigFirst()/FIN_CmpExtOpQtySmallFirst
**
**  Description          :  comp. for sorting 
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-42678  - LIK - 27112020
**
**  Modif.               :
**********************************************************************************************/
STATIC int FIN_CmpExtOpQtyBigFirst(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return (CMP_DYNFLD((*ptr2), (*ptr1),
        ExtOp_Qty, ExtOp_Qty, NumberType));
}

STATIC int FIN_CmpExtOpQtySmallFirst(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return (CMP_DYNFLD((*ptr1), (*ptr2),
        ExtOp_Qty, ExtOp_Qty, NumberType));
}
/********************************************************************************************
**  Function             :  createHierExecution()
**
**  Description          :  split paent ececution to child execution
**
**  Arguments            :
**
**  Return               :  RET_SUCEED or Error code
**
**  Creation 		     :  PMSTA-42678 - LIK - 27112020
**
**  Modif.               :
**********************************************************************************************/
RET_CODE createHierExecution(OBJECT_ENUM object,
    DBA_DYNST_ENUM inputSt,
    DBA_DYNFLD_STP aExecution,
    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;
    if (A_Execution == inputSt)
    {
        DBA_DYNFLD_STP extOp = mp.allocDynst(FILEINFO, ExtOp);
        SET_ID(extOp, ExtOp_DbId, (GET_ID(aExecution, A_Execution_ExtOrderId)));
        
        ret = DBA_Get2(ExtOrder, UNUSED, ExtOp, extOp, ExtOp, &extOp, UNUSED, UNUSED, UNUSED);
        
        if (RET_SUCCEED == ret &&
            HierOpNatEn::HierOpNat_BlockOrder == static_cast<HierOpNatEn>(GET_ENUM(extOp, ExtOp_HierOperNatEn)))
        {
            /* Here, we have to split the execution to child orders.
                We will fetch
                    1. all accounted execution as ext_order ?
                    2. all the child ext_order with parent as above ext_order
                    3. instrument - for oldd lot qty
                    4. portfolios - just fetch it
                    5. will add based on requiremnt
            */



            DBA_DYNFLD_STP getArg = mp.allocDynst(FILEINFO, Get_Arg);
            SET_CODE(getArg, Get_Arg_Cd, (GET_CODE(extOp, ExtOp_Cd)));
                                                                    
            const DBA_DYNST_ENUM *   outputStLst[]  = { &ExtOp, &A_Execution, &A_Execution, &A_Instr }; /* child order (sort-qty desc), accounted execution, not accounted but soon, instr */
            DBA_DYNFLD_STP *            data[]            = { NULL, NULL, NULL, NULL };
            int                                    rows[]            = { 0, 0, 0 , 0};
            const size_t                       outputBlkNb    = sizeof(outputStLst) / sizeof(outputStLst[0]);
            const int INSTR_IDX = 3, CHILD_ORDER_IDX = 0, ACC_EXEC = 1, EXT_EXEC = 2;

            if ((ret = dbiConnHelper.dbaMultiSelect(ExecutionEnt, UNUSED, getArg, outputStLst, data, rows)) != RET_SUCCEED)
            {
                MSG_SendMesg(FILEINFO, "DBA_MultiSelect for hier group failed");
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return ret;
            }

            if (rows[INSTR_IDX] == 0)
            {
                MSG_SendMesg(FILEINFO, "Error : No instr selected for the order");
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return RET_GEN_ERR_INVARG;
            }

            /*BP related fields */
            FIELD_IDX_T bpFldsAmt[] = { A_Execution_Bp1Amt, A_Execution_Bp2Amt , A_Execution_Bp3Amt , A_Execution_Bp4Amt , A_Execution_Bp5Amt , A_Execution_Bp6Amt , A_Execution_Bp7Amt, A_Execution_Bp8Amt , A_Execution_Bp9Amt ,A_Execution_Bp10Amt };
            FIELD_IDX_T bpFldsCurr[] = { A_Execution_Bp1CurrencyId, A_Execution_Bp2CurrencyId , A_Execution_Bp3CurrencyId , A_Execution_Bp4CurrencyId , A_Execution_Bp5CurrencyId , A_Execution_Bp6CurrencyId , A_Execution_Bp7CurrencyId, A_Execution_Bp8CurrencyId , A_Execution_Bp9CurrencyId ,A_Execution_Bp10CurrencyId };
            FIELD_IDX_T bpFldsTypeId[] = { A_Execution_Bp1TypeId, A_Execution_Bp2TypeId , A_Execution_Bp3TypeId , A_Execution_Bp4TypeId , A_Execution_Bp5TypeId , A_Execution_Bp6TypeId , A_Execution_Bp7TypeId, A_Execution_Bp8TypeId , A_Execution_Bp9TypeId ,A_Execution_Bp10TypeId };
            AMOUNT_T    bpMultiplyAmts[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            AMOUNT_T    bpRemainingAmt[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            int               bpFldCount = sizeof(bpFldsAmt) / sizeof(bpFldsAmt[0]);

            /* common copy fields */
            FIELD_IDX_T copyExecFields[] = { A_Execution_CheckStratEn , A_Execution_AccountDate ,A_Execution_OperationDate , A_Execution_ValueDate ,
            A_Execution_StatusEn , A_Execution_SequenceNo , A_Execution_BeginDate, A_Execution_ExecutionDate , A_Execution_ExecutionSetCriteria ,
            A_Execution_NatureEn , A_Execution_Price , A_Execution_PriceCalcRuleEn , A_Execution_Quote , A_Execution_Rate , A_Execution_InstrId , A_Execution_NoPositionFlg ,
            A_Execution_OpCurrencyId };
            int               commonCopyCount = sizeof(copyExecFields) / sizeof(copyExecFields[0]);

            /* get Hier alloc method*/
            HIER_ALLOC_METHOD_ENUM applHierAllocMethod = HierAllocMethod_Prorata;
            GEN_GetApplInfo(ApplHierAllocMethod, &applHierAllocMethod);

            /*get odd lot qty */
            NUMBER_T oddLotQty = (IS_NULLFLD(data[INSTR_IDX][0], A_Instr_OddLotQty) ? 1.0 : GET_NUMBER(data[INSTR_IDX][0], A_Instr_OddLotQty));
            std::vector<DBA_DYNFLD_STP> childExecutions;
            std::vector<NUMBER_T> allocVector;

            /*init flags for screen dv */
            FLAG_T* flags = (FLAG_T*)mp.calloc(FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
            for (int i = 0; i < GET_FLD_NBR(A_Execution); ++i)
            {
                flags[i] = FALSE;
            }
            for (int i = 0; i < commonCopyCount; ++i)
            {
                flags[copyExecFields[i]] = TRUE;
            }
            /* init bp multiplier */
            for (int bpIndex = 0; bpIndex < bpFldCount; ++bpIndex)
            {
                bpMultiplyAmts[bpIndex] = (GET_AMOUNT(aExecution, (bpFldsAmt[bpIndex]))) / (GET_NUMBER(aExecution, A_Execution_Quantity));
                bpRemainingAmt[bpIndex] = GET_AMOUNT(aExecution, (bpFldsAmt[bpIndex]));

                /*no need to calc screen dv for bp fields */
                flags[bpFldsAmt[bpIndex]] = TRUE;
                flags[bpFldsCurr[bpIndex]] = TRUE;
                flags[bpFldsTypeId[bpIndex]] = TRUE;
            }
            

            /* each ext_order is a child order */

            if (rows[CHILD_ORDER_IDX] > 1) 
            {
                switch (applHierAllocMethod)
                {
                case HierAllocMethod_Prorata:
                case HierAllocMethod_BiggestFirst:
                        TLS_Sort((char *)data[CHILD_ORDER_IDX], rows[CHILD_ORDER_IDX], sizeof(DBA_DYNFLD_STP),
                        (TLS_CMPFCT*)FIN_CmpExtOpQtyBigFirst, (PTR **)NULL, SortRtnTp_None);
                    break;
                case HierAllocMethod_SmallestFirst:
                    TLS_Sort((char *)data[CHILD_ORDER_IDX], rows[CHILD_ORDER_IDX], sizeof(DBA_DYNFLD_STP),
                        (TLS_CMPFCT*)FIN_CmpExtOpQtySmallFirst, (PTR **)NULL, SortRtnTp_None);
                    break;
                default:
                    break;
                }
            }

            NUMBER_T remainingQty = GET_NUMBER(aExecution, A_Execution_Quantity);
            NUMBER_T parExecQty = remainingQty;
            NUMBER_T parExtOpQty = GET_NUMBER(extOp, ExtOp_Qty);

            for (int index = 0; index < rows[CHILD_ORDER_IDX]; ++index)
            {
                if (CMP_NUMBER(remainingQty, ZERO_NUMBER) == 0)
                {
                    break;
                }

                NUMBER_T alreadyAllocated = 0.0;
                if((ret = calcAlreadyAllocated(data[CHILD_ORDER_IDX][index], data[ACC_EXEC], rows[ACC_EXEC], 
                    data[EXT_EXEC], rows[EXT_EXEC], alreadyAllocated)) == RET_SUCCEED)
                    {

                    DBA_DYNFLD_STP outExecution = mp.allocDynst(FILEINFO, A_Execution);
                    /* set db default vals */
                    DBA_SetDfltEntityFld(ExecutionEnt, A_Execution, outExecution);

                    NUMBER_T childExtOpQty = GET_NUMBER((data[CHILD_ORDER_IDX][index]), ExtOp_Qty);
                    NUMBER_T childExecQty = 0;
                    switch (applHierAllocMethod)
                    {
                    case HierAllocMethod_BiggestFirst:
                    case HierAllocMethod_SmallestFirst:
                        childExecQty = childExtOpQty - alreadyAllocated;
                        break;
                    case HierAllocMethod_Prorata:
                        childExecQty = ((childExtOpQty / parExtOpQty) * parExecQty);
                        childExecQty = TLS_Round(childExecQty, oddLotQty, RndRule_Down);
                        
                        if (CMP_NUMBER((childExecQty + alreadyAllocated), childExtOpQty) == 1)
                        {
                            /* allocation exceeded actual child qty*/
                            childExecQty = childExtOpQty - alreadyAllocated;
                        }
                        break;
                    default:
                        MSG_SendMesg(FILEINFO, "Error : Inavlid hier alloc method ");
                        break;
                    }

                    if (CMP_NUMBER(childExecQty, remainingQty) == 1)
                    {
                        childExecQty = remainingQty;
                        remainingQty = 0.0;
                    }
                    else
                    {
                        remainingQty -= childExecQty;
                    }
                    SET_NUMBER(outExecution, A_Execution_Quantity, childExecQty);
                    flags[A_Execution_Quantity] = TRUE;

                    ret = setHierBps(aExecution, outExecution, bpMultiplyAmts, bpRemainingAmt,
                        bpFldsAmt, bpFldsCurr, bpFldsTypeId, bpFldCount);
                        
                    /* set some specifc values */
                    COPY_DYNFLD(outExecution, A_Execution, A_Execution_PtfId, (data[CHILD_ORDER_IDX][index]), ExtOp, ExtOp_PtfId);
                    flags[A_Execution_PtfId] = TRUE;
                    COPY_DYNFLD(outExecution, A_Execution, A_Execution_ExtOrderId, (data[CHILD_ORDER_IDX][index]), ExtOp, ExtOp_DbId);
                    flags[A_Execution_ExtOrderId] = TRUE;

                    /* copy remainging fields from parent exec to child exec*/
                    for (int i = 0; i < commonCopyCount; ++i)
                    {
                        COPY_DYNFLD(outExecution, A_Execution, copyExecFields[i],
                            aExecution, A_Execution, copyExecFields[i]);
                    }

                    /* compute screen dv. */
                    if (0 != SCPT_ComputeDV(ExecutionEnt, flags, outExecution, TRUE, TRUE, NULL))
                    {
                        MSG_SendMesg(FILEINFO, "setValues: default value calc failed.");
                    }
                    childExecutions.push_back(outExecution);
                    allocVector.push_back(childExecQty + alreadyAllocated);
                }

                if (RET_SUCCEED != ret)
                {
                    break;
                }
            }

            if (RET_SUCCEED == ret)
            {
                /*allocated everything, if still there is somethng remains, allocate to the first one */
                if (CMP_NUMBER(remainingQty, ZERO_NUMBER) == 1)
                {
                    int j = 0;
                    for (auto iter = childExecutions.begin(); iter != childExecutions.end(); ++iter)
                    {
                        if (CMP_NUMBER(remainingQty, ZERO_NUMBER) == 0)
                            break;
                        /* vector and child ext orders will be in same order */
                        NUMBER_T availableQty = GET_NUMBER(data[CHILD_ORDER_IDX][j], ExtOp_Qty) - allocVector[j];
                        if (CMP_NUMBER(availableQty, remainingQty) == -1)
                        {
                            remainingQty -= availableQty;
                            SET_NUMBER((*iter), A_Execution_Quantity, (availableQty + allocVector[j]));
                        }
                        else
                        {
                            SET_NUMBER((*iter), A_Execution_Quantity, (remainingQty + allocVector[j]));
                            remainingQty = 0.0;
                        }
                        if (0 != SCPT_ComputeDV(ExecutionEnt, flags, (*iter), TRUE, TRUE, NULL))
                        {
                            MSG_SendMesg(FILEINFO, "setValues: default value calc failed.");
                        }
                    }
                }
                /*allocate remaining bp if any*/
                if (!childExecutions.empty())
                {
                    bool runDv = false;
                    for (int bpIndex = 0; bpIndex < bpFldCount; ++bpIndex)
                    {

                        if (CMP_AMOUNT(bpRemainingAmt[bpIndex], ZERO_AMOUNT, bpFldsCurr[bpIndex]) == 1)
                        {
                            AMOUNT_T temp = GET_AMOUNT(childExecutions[0], bpFldsAmt[bpIndex]) + bpRemainingAmt[bpIndex];
                            SET_AMOUNT(childExecutions[0], bpFldsAmt[bpIndex], temp);
                            runDv = true;
                        }
                    }

                    if (runDv)
                    {
                        if (0 != SCPT_ComputeDV(ExecutionEnt, flags, (childExecutions[0]), TRUE, TRUE, NULL))
                        {
                            MSG_SendMesg(FILEINFO, "setValues: default value calc failed.");
                        }
                    }
                }

                /* insert into db one by one */
                for (auto iter = childExecutions.begin(); iter != childExecutions.end(); ++iter)
                {
                    if ((ret = dbiConnHelper.dbaInsert(ExecutionEnt, UNUSED, *iter)) != RET_SUCCEED)
                    {
                        break;
                    }
                }
            }
        }
        else
        {
            /*if fetch retunrs null or if its not a hier block order, return success. so that caller can continue*/
            ret = RET_SUCCEED;
        }
    }
    return ret;
}

/* hier grouping execution handling - end */

/************************************************************************
**      END  finlib13.c                                          UNICIBLE
*************************************************************************/

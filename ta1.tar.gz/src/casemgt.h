/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef CASEMGT_H
#define CASEMGT_H

/************************************************************************
**  BEGIN : Global variables & external definitions attached to casemgt.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  CASEMGT_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_CreateConstraintCase(DBA_DYNFLD_STP, PTR, DBA_DYNFLD_STP),
				FIN_AddCaseLinkedObject(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DICT_T, ID_T),
				FIN_GetCaseLinkedObject(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP*, FLAG_T *, int, int *),
				FIN_GenerateCaseDescriptionFromTemplate(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_GetBestCaseMsgTemplate(DBA_DYNFLD_STP, SMALLINT_T, SMALLINT_T, DBA_DYNFLD_STP *, int, int *),
                FIN_LoadCaseMsgTemplateDef(DBA_DYNFLD_STP, DICT_T langId, char **, int, int *),
                FIN_GenerateCasesOnMessages(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, int*), /*  FPL-PMSTA10166-100706   */
				FIN_CheckIfSessionIsClearToGo(DBA_DYNFLD_STP);	/* DLA - PMSTA-11605 - 110415 */
EXTERN FLAG_T FIN_CaseSessionBlockingCheckConfirmedFlag(DBA_DYNFLD_STP); /* PMSTA09793-CHU-100514 */
RET_CODE FIN_CreateCaseRuleCase(DBA_DYNFLD_STP, PTR);
RET_CODE FIN_LoadCaseRule(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*);

/************************************************************************
**  BEGIN : Global variables & external definitions attached to casemgt01.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  CASEMGT01_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_CreateConstrBreachCase(DBA_DYNFLD_STP, PTR, DBA_DYNFLD_STP);
EXTERN RET_CODE FIN_GenerateConstrBreachFromCase(DBA_DYNFLD_STP, PTR);
EXTERN int		FIN_FilterCasesForCB(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/************************************************************************
**  BEGIN : Global variables & external definitions attached to casemgt02.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  CASEMGT02_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_CreateObjectiveMarginCase(DBA_DYNFLD_STP, PTR, DBA_DYNFLD_STP);

/* PMSTA-41728 sriharshabv 14092020  Added Custom Case Management Nature range from 100 to 255*/
#define CustomCaseManagementNatureEMinimum    100
#define CustomCaseManagementNatureEMaximum    255


#endif /* CASEMGT_H */

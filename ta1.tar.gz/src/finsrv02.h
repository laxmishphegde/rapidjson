/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINSRV02_H
#define FINSRV02_H

/************************************************************************
**      BEGIN : Global definitions attached to finsrv02.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINSRV02_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_AnalysisOpHist(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
	            FIN_AnalysisOpList(DBA_DYNFLD_STP, PTR),
	            FIN_AnalysisPerfo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
	            FIN_AnalysisValo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
	            FIN_AnalysisAccHist(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
	            FIN_AnalysisAccPerClosing(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
		        FIN_AnalysisFundValo(DBA_DYNFLD_STP , DBA_HIER_HEAD_STP),
                FIN_CheckLogicalFusion(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, int,
				                       DBA_DYNFLD_STP*, LOGICIDRULE_ENUM*, bool isMergeReprocess = FALSE),
                FIN_UpdPosRefAmt(DBA_DYNFLD_STP *, int, ID_T, DICT_FCT_ENUM, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP), /* BUG119 */  /*REF2580 - SSO - 980727 */ /* REF6220 - LJE - 020306 */
	            FIN_ValoProcess(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, HIER_FLTFCT*), /* REF7264 - LJE - 020131 */
		        FIN_UpdPosSysAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int), /* REF3178 - SSO - 990106 */
                FIN_AnalysisOrderList(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
                FIN_AnalysisOpSearchPhase1(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T, int),
                FIN_AnalysisOpSearchPhase2(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
				FIN_AnalysisOrderGrouping(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DICT_T, DICT_FCT_STP),	/* REF11764 - RAK - 060404 */
				FIN_AnalysisUpdateField(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DICT_T, DICT_FCT_STP),   /*  HFI-PMSTA-35324-190328  */
				FIN_AnalysisInitiateOrder(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DICT_T, DICT_FCT_STP, FLAG_T),	/* DLA - PMSTA04685 - 071213 */
                FIN_PosNetVal(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP,
			                  DBA_DYNFLD_STP, DBA_DYNFLD_STP, FIN_AIARG_STP),
                FIN_PosExtValo(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_AnalysisDisplayChrono(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,DBA_DYNFLD_STP), /* REF4306 - CSY - 000207 */
				FIN_AnalysisDisplayComplianceChrono(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP), /* PMSTA-18759 - CHU - 150401 */
                FIN_AnalysisOpSearchPhaseOrder(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, int *), /* REF7560 - DDV - 020604 */
                FIN_AnalysisSMatchO(DBA_DYNFLD_STP , DBA_HIER_HEAD_STP),  /* REF9764 - TEB - 040122 */
                FIN_AnalysisPurgeOrder(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF8723 - TEB - 040218 */
                FIN_ManageFutureCashFlows(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* PMSTA00485 - CHU - 061016 */
				FIN_PosGetDateRuleExchDate(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DBA_DYNFLD_STP*, FUSDATERULE_ENUM*, DATETIME_T*), /* PMSTA05045 - LJE - 080104 */
				FIN_ExecuteOrderGrouping(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DICT_T, DICT_FCT_STP, DBA_DYNFLD_STP *, int, EXTOP_ACTION_ENUM, bool), /* PMSTA15221-CHU-121214 */ /* PMSTA-31673 - CHU - 180607 */
				FIN_ExecuteOrderSwitching(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DICT_T, DICT_FCT_STP, DBA_DYNFLD_STP *, int, EXTOP_ACTION_ENUM, bool), /* PMSTA-37086 - Silpakal - 190905  */
                FIN_ManageSession(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* PMSTA-30897 - CHU - 180503 */
                FIN_ManagePayout(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),  /* PMSTA-30894 - CHU - 180711 */
                FIN_TaxLotValo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);  /* PMSTA-28086 - SANAND - 170319 */

EXTERN int 	FIN_CmpCheckLogicFus(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), 	/* REF1211 */ /* REF7264 - LJE - 020201 */
                FIN_FilterStock(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020201 */
                FIN_FilterInitStock(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020201 */
				FIN_FilterInitStockNoBP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF9383 - CHU - 030814 */
                FIN_FilterFinalStock(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020201 */
		FIN_FilterMainFlow(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),		/* DVP166 - 970106 - DED */ /* REF7264 - LJE - 020201 */
		FIN_FilterMainFlowNoPPS(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),	/* BUG380 - XDI - 970528 */ /* REF7264 - LJE - 020201 */
		FIN_FilterMainFlowPPSwithTransfer(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),	/* REF4359 - 000511 - DED */
        FIN_FilterPStock(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
        FIN_FilterPStockExcludeZeroPos(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); 	/* PMSTA-61292 - DDV - 241205 */

EXTERN FLAG_T   FIN_SetPriceToPos(DATETIME_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF2580 - SSO - 980727 */
                FIN_OpSearchUseOnlyOpTable(DBA_DYNFLD_STP); /* REF7560 - DDV - 020604 */

/* PMSTA-32690 - CHU - 180830 */
extern int  FIN_FilterExtPosCrtPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP crtPtfSt),
            FIN_FilterExtPosBPType(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed);

EXTERN RET_CODE FIN_CreateForwardRiskOrigin(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead);
EXTERN RET_CODE FIN_ResetRiskOriginToForward(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead);
EXTERN RET_CODE FIN_CreateFXSplitLegs(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead);
EXTERN POSNAT_ENUM FIN_GetFXFwdWithTwoLegsPosNat(DBA_DYNFLD_STP pos);

extern RET_CODE FIN_DraftOrderValo(PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP);  /* PMSTA-36202 - 200619 - vkumar */
extern RET_CODE FIN_GetCashBalance(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, AMOUNT_T*);

typedef enum
{
	OrderGroupingMode_None,			/* 0 */
	OrderGroupingMode_FinFct,		/* 1 */
	OrderGroupingMode_OrderAndProd,	/* 2 */

	OrderGroupingMode_Last
} ORDER_GROUPING_MODE_ENUM;

/*  PMSTA-37086 - Silpakal - 190905 */
enum class ORDER_SWITCHING_MODE_ENUM
{
	OrderSwitchingMode_None,			/* 0 */
	OrderSwitchingMode_FinFct,			/* 1 */
	OrderSwitchingMode_OrderAndProd,	/* 2 */
};


#endif /* FINSRV02_H */


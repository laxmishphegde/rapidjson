/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBI_H
#define DBI_H

#include <string>

#include "contype.h"

#include "proc.h"
#include "conallocator.h"

extern FIELD_IDX_T Null_Dynfld;

class RequestHelper;

typedef class AaaSqlContext AAASQL_CONTEXT_ST, *AAASQL_CONTEXT_STP;

/* Remapping Sybase data-types */
/* The following typedef are checked in sybserv.h */
typedef short                DBI_SMALLINT;  /* 2 byte: integer */
typedef unsigned char        DBI_BYTE;      /* 1 byte: byte */
typedef void                *DBI_PTR;
typedef char                 DBI_CHAR;
typedef void *               DBI_DATEREC;

#if defined( __alpha) || defined(SYB_LP64) || defined(SYB_LLP64) || defined(_AIX)
typedef int                  DBI_INT;
typedef int                  DBI_RETCODE;
typedef int                  DBI_BOOL;
#else
typedef long                  DBI_INT;
typedef long                  DBI_RETCODE;
typedef long                  DBI_BOOL;
#endif
/* PMSTA-40978 - Smitha - datatype corresponding to SQLLEN in Ms Sql Server */
#ifdef _WIN64
typedef INT64_T               DBI_INT64;
#else
typedef long                  DBI_INT64;
#endif

#if defined (SYB_LP64) || defined (SYB_LLP64) || defined (_AIX)
typedef unsigned int DBI_MSGNUM;
#else
typedef long DBI_MSGNUM;
#endif

#define DBI_FAIL                static_cast<DBI_RETCODE>(0)
#define DBI_SUCCEED             static_cast<DBI_RETCODE>(1)

#define DBI_GOODDATA            static_cast<DBI_SMALLINT>(0)
#define DBI_NULLDATA            static_cast<DBI_SMALLINT>(-1)

#define DBI_ROW_RESULT          4040
#define DBI_CURSOR_RESULT       4041
#define DBI_PARAM_RESULT        4042
#define DBI_STATUS_RESULT       4043
#define DBI_MSG_RESULT          4044
#define DBI_COMPUTE_RESULT      4045
#define DBI_CMD_DONE            4046
#define DBI_CMD_SUCCEED         4047
#define DBI_CMD_FAIL            4048
#define DBI_ROWFMT_RESULT       4049
#define DBI_COMPUTEFMT_RESULT   4050
#define DBI_DESCRIBE_RESULT     4051
#define DBI_ORA_FAILCMD         4060

#define DBI_SEVERITY(S)         static_cast<DBI_MSGNUM>(((S) >> 8) & 0xff)
#define DBI_NUMBER(N)           static_cast<DBI_MSGNUM>((N) & 0xff)

/***********************************************************************
*** STRUCTURE USED FOR CONNECTIONS HANDLING
************************************************************************/

typedef struct
{
    int            colNbr;
    int            maxRowsNbr;
    DATATYPE_ENUM  *datatypeTab;
    PTR            scriptContextTab;
    int            rowsNbr;
    ENUM_T         updstatus_sign;		       /* REF1317 - GRD - 19981020 */
    INT_T          updstatus_val;		       /* REF1317 - GRD - 19981020 */
    PTR            fmtDataDef;                 /* (SCPT_FMTDATADEF_STP) / DLA - REF9795 - 040503 */
    DBA_DYNFLD_STP *sListCompoTab;             /* PMSTA07422 - DDV - 090527 - New script keyword LIST_RANK */
    int            sListCompoNbr;              /* PMSTA07422 - DDV - 090527 - New script keyword LIST_RANK */
    DBA_DYNFLD_STP exportCtx;                  /* PMSTA07422 - DDV - 090527 - New script keyword LIST_RANK */
    PTR            defGenContext;              /* PMSTA07422 - DDV - 090527 - script tree linked for definition parameter */
    int            subsNbr;
} DBA_GENEXPORTCTX_ST, *DBA_GENEXPORTCTX_STP;

class DbaErrmsgInfosClass
{
public:
    DbaErrmsgInfosClass(const char *file, int line)
        : firstInList(0)
        , lastInList(0)
        , status(0)
        , gravity(0)
        , techMsg(0)
        , msgOrigin(NullHandler)
        , rdbmsMsgNb(0)
        , retCode(RET_SUCCEED)
        , line(0)
        , affectedRows(0)
        , unkownMessage("Unknown message")
        , result(0)
        , action(NullAction)
        , isAlreadyWritedInLog(false)
        , m_file(file)
        , m_line(line)
    {
    }

    virtual ~DbaErrmsgInfosClass()
    {
    }

    DbaErrmsgInfosClass(const DbaErrmsgInfosClass &ref)
        : DbaErrmsgInfosClass(ref.m_file, ref.m_line)
    {
        *this = ref;
    }

    DbaErrmsgInfosClass & operator=(const DbaErrmsgInfosClass &toCopy)
    {
       this->firstInList          = toCopy.firstInList;
       this->lastInList           = toCopy.lastInList;
       this->status               = toCopy.status;
       this->gravity              = toCopy.gravity;
       this->techMsg              = toCopy.techMsg;
       this->msgOrigin            = toCopy.msgOrigin;
       this->rdbmsMsgNb           = toCopy.rdbmsMsgNb;
       this->retCode              = toCopy.retCode;
       this->line                 = toCopy.line;
       this->affectedRows         = toCopy.affectedRows;
       this->serverName           = toCopy.serverName;
       this->procedure            = toCopy.procedure;
       this->msgString            = toCopy.msgString;
       this->rdbmsMsgString       = toCopy.rdbmsMsgString;
       this->m_callStack          = toCopy.m_callStack;
       this->result               = toCopy.result;
       this->action               = toCopy.action;
       this->isAlreadyWritedInLog = toCopy.isAlreadyWritedInLog;
       this->m_file               = toCopy.m_file;
       this->m_line               = toCopy.m_line;

       return *this;
    }

    bool emptyString()
    {
        return this->msgString.empty() && this->rdbmsMsgString.empty();
    }

    const std::string &getMsgString() const
    {
        return (this->msgString.empty() == false
         ? this->msgString
         : this->rdbmsMsgString.empty() == false
         ? this->rdbmsMsgString
         : unkownMessage);
    }

    int                          firstInList;
    int                          lastInList;
    int                          status;
    int                          gravity;
    int                          techMsg;
    DBA_MSG_ORIGIN_ENUM          msgOrigin;
    int                          rdbmsMsgNb;
    RET_CODE                     retCode;
    int                          line;                     /* PMSTA-14452 - LJE - 121205 */
    int                          affectedRows;
    std::string                  serverName;
    std::string                  procedure;
    std::string                  msgString;
    std::string                  rdbmsMsgString;
    std::string                  m_callStack;
    std::string                  unkownMessage;
    int                          result;
    DBA_ACTION_ENUM		         action;
    bool                         isAlreadyWritedInLog;

    const char                  *m_file;
    int                          m_line;
};
typedef DbaErrmsgInfosClass DBA_ERRMSG_INFOS_ST, *DBA_ERRMSG_INFOS_STP;

class DbaErrmsgHeaderClass
{
public:
    DbaErrmsgHeaderClass()
        : autoRefRecPtr(nullptr)
        , startPos(0)
    {
    }

    /* PMSTA-49780- BSV- 040722 */
    //Added members for the deep copy of DbaErrMsgHeaderClass  objects
    void copyDbaErrMsgHeaderClassObject(const DbaErrmsgHeaderClass &copyFrom);
    void freeDbaErrMsgHeaderClassMemory();

    virtual ~DbaErrmsgHeaderClass()
    {
        freeDbaErrMsgHeaderClassMemory();
    }

    DbaErrmsgHeaderClass(const DbaErrmsgHeaderClass &ref)
        : DbaErrmsgHeaderClass()
    {
        *this = ref;
    }

    DbaErrmsgHeaderClass & operator=(const DbaErrmsgHeaderClass &toCopy)
    {
        this->msgStructTab        = toCopy.msgStructTab;
        this->autoRefRecPtr       = toCopy.autoRefRecPtr;
        this->autoInputCtrlMsgTab = toCopy.autoInputCtrlMsgTab;
        this->startPos            = 0;
        return *this;
    }

    bool empty()
    {
        return this->msgStructTab.empty();
    }

    void clear()
    {
        this->msgStructTab.clear();
        this->startPos = 0;
    }

    void start()
    {
        this->startPos = 0;
    }

    void patchLastMsg(const char *file, int line, int firstInList, int lastInList, DBA_ACTION_ENUM action)
    {
        for (size_t i = this->startPos; i < this->msgStructTab.size(); ++i)
        {
            auto &it = this->msgStructTab[i];
            it.m_file      = file;
            it.m_line      = line;
            it.firstInList = firstInList;
            it.lastInList  = lastInList;
            it.action      = action;
        }
    }

    DbaErrmsgInfosClass &getNewErrMsgInfoSt(const char *file, int line)
    {
        this->msgStructTab.push_back(DbaErrmsgInfosClass(file, line));
        return this->msgStructTab.back();
    }

    DbaErrmsgInfosClass &getMostGravityErrMsgInfoSt(const char *file, int line)
    {
        DbaErrmsgInfosClass *errMsgInfoStp = nullptr;

        for (auto it = this->msgStructTab.begin(); it != this->msgStructTab.end(); ++it)
        {
            if (errMsgInfoStp == nullptr || it->gravity > errMsgInfoStp->gravity)
            {
                errMsgInfoStp = &(*it);
            }
        }

        if (errMsgInfoStp == nullptr)
        {
            errMsgInfoStp = &this->getNewErrMsgInfoSt(file, line);
        }

        return *errMsgInfoStp;
    }

    std::vector<DBA_ERRMSG_INFOS_ST>   msgStructTab;
    size_t                             startPos;

    DBA_DYNFLD_STP               autoRefRecPtr;
    std::vector<DBA_DYNFLD_STP>  autoInputCtrlMsgTab;
};

typedef DbaErrmsgHeaderClass DBA_ERRMSG_HEADER_ST, *DBA_ERRMSG_HEADER_STP;

typedef struct
{
    DBA_ACTION_ENUM       action;
    int                   role;
    OBJECT_ENUM           object;
    DBA_DYNST_ENUM        entity;
    DBA_DYNFLD_STP        data;
    DBA_DYNFLD_STP        newData;            /* REF5644 - GRD - 000202 */
    int                   stamp;
    int                   errorType;          /* DLA - REF9764 - 040304 */
    DBA_ERRMSG_HEADER_STP msgStructHeaderStp; /* To use it, use DbaMultiAccessHelper */
} DBA_ACCESS_ST, *DBA_ACCESS_STP;


typedef struct
{
    DBA_ACCESS_ST  delOp;
    DBA_ACCESS_ST  insOp;
    DBA_ACCESS_ST  auditOp;         /* REF4204 - GRD - 000321 */
    int            extDataNbr;
    int            extDataTabSize;
    DBA_ACCESS_STP extDataTab;
} DBA_OPER_STEP_ST, *DBA_OPER_STEP_STP;

class DbaMultiAccessHelper
{
public:
    DbaMultiAccessHelper()
        : m_accessTabSize(0)
    {
    }

    DbaMultiAccessHelper(DBA_ACCESS_STP        accessTabPtr,
                         const int             accessTabSize)
        : DbaMultiAccessHelper()
    {
        this->setAccessTab(accessTabPtr, accessTabSize);
    }

    virtual ~DbaMultiAccessHelper()
    {
        for (std::vector<DBA_ACCESS_STP>::iterator it = m_accessVector.begin(); it != m_accessVector.end(); ++it)
        {
            delete((*it)->msgStructHeaderStp);
            (*it)->msgStructHeaderStp = nullptr;
        }
    }

    void setAccessTab(DBA_ACCESS_STP        accessTabPtr,
                      const int             accessTabSize)
    {
        this->m_accessTabSize = accessTabSize;
        this->m_accessVector.resize(this->m_accessTabSize);

        for (int i = 0; i < accessTabSize; i++)
        {
            this->m_accessVector[i] = &(accessTabPtr[i]);
        }
    }

    void sendAllMultiAccessMsg()
    {
        for (auto it = this->m_accessVector.begin(); it != this->m_accessVector.end(); ++it)
        {
            if ((*it)->msgStructHeaderStp != nullptr)
            {
                for (auto msgStructIt = (*it)->msgStructHeaderStp->msgStructTab.begin(); msgStructIt != (*it)->msgStructHeaderStp->msgStructTab.end(); ++msgStructIt)
                {
                    if (msgStructIt->isAlreadyWritedInLog == false)
                    {
                        MSG_SendMsgInfosFromMA(&(*msgStructIt));
                        msgStructIt->isAlreadyWritedInLog = true;
                    }
                }
            }
        }
    }

    RET_CODE callMultiAccess(int                   maxRecInBuf,
                             int                   options,
                             int *                 allocConn,
                             bool                  bStoreErrMsgInElt);

    RET_CODE callMultiAccess(int                   maxRecInBuf,
                             int                   options,
                             DbiConnection&        dbiConn,
                             bool                  bStoreErrMsgInElt);
private:
    std::vector<DBA_ACCESS_STP>    m_accessVector;
    int                            m_accessTabSize;
};

typedef struct
{
    int stepNbr;
    int stepDataSize;
    DBA_OPER_STEP_STP stepData;
} DBA_ACTION_STEP_ST, *DBA_ACTION_STEP_STP;

typedef struct
{
    int curRec;
    int curRecStep;
    DBA_ACTION_STEP_STP recTab;
    DATETIME_T          creation_d;              /* DLA - REF8880 - 030317 */
} DBA_BLOCK_MODE_ST, *DBA_BLOCK_MODE_STP;

typedef struct
{
    EVENT_NATURE_ENUM      eventNat;                /* REF4204 */
    DBA_DYNST_ENUM         auditRecSt;              /* REF4204 */
    DBA_DYNFLD_STP         auditRecStp;             /* REF4204 */
    DBA_ACCESS_STP accessStp;
    int            accessNbr;

    //int                    nbElementTab;
    DBA_ACTION_ENUM        currAction;              /* REF4204 */
    DBA_DYNFLD_STP         *subscripCodifCompoStp;  /* REF4204 */
    int                    subscripCodifCompoNmb;   /* REF4204 */
    DATETIME_T             creation_d;              /* DLA - REF6935 - 020213 */
} DBA_SUBSCRIPTION_ST, *DBA_SUBSCRIPTION_STP;

/************************************************************************
**      STRUCTURES USED FOR SYNTHETICS INSERTION    - REF5392 - RAK - 001121
*************************************************************************/

#define DBA_ALLOC_STEPBLOC  5

struct DBA_CONNECT_INFO_STRUCT
{
    DBA_CONNECT_INFO_STRUCT();                                                       /* PMSTA-24510 - 220816 - PMO */

    DBA_CONNECT_INFO_STRUCT            (const DBA_CONNECT_INFO_STRUCT &) = delete;   /* PMSTA-24510 - 220816 - PMO */
    DBA_CONNECT_INFO_STRUCT & operator=(const DBA_CONNECT_INFO_STRUCT &) = delete;   /* PMSTA-24510 - 220816 - PMO */

    // Common data
    int                                     maxRows;
    int                                     blockMode;                      /* DVP291  */
    DBA_BLOCK_MODE_ST                       blockModeExt;                   /* DVP291  */
    DBA_SUBSCRIPTION_ST                     subscriptionElem;               /* REF4204 */
    int                                     noDeleteMessageInfo;            /* REF7164 */
    DBA_SEND_MSG_OPTIONS_STP                msgOptions;                     /* To change something in a message / REF10729 - 041103 - PMO */
    bool                                    notifyCanAutoReconnect;         /* Used to handle the stop and the start of server  REF10883    - 050621 - PMO */
    bool                                    disableEventSchedNotification;  /* Disable the event scheduler notification         PMSTA-13613 - 070212 - PMO */
    FLAG_T                                  preserveConfirmedFlg;           /* REF11338 - CHU - 051011 */
    bool                                    passwordChange;                 /* PMSTA-18094 - 130514 - PMO */
    size_t                                  poolConnectNo;
    int                                     timeOut;
} ;

typedef struct DBA_CONNECT_INFO_STRUCT   DBA_CONNECT_INFO_ST;
typedef struct DBA_CONNECT_INFO_STRUCT * DBA_CONNECT_INFO_STP;

extern DBA_CONNECT_INFO_STP    DBA_GetConnStructPtr(int);


typedef struct
{
    int 		colNb,
        rowNb;
    DBA_DYNFLD_STP	dataDef;		/* type de structure dyn : DataDef */
    DBA_DYNFLD_STP	data;			/* aucun type de structure dyn particulier */
    OBJECT_ENUM	entity;			/* DVP375 */
    char		addedEntityFlg;		/* TRUE si la structure All de l'entity ... */
    /* ... est ajoutee en en-tete du DataSet */
    FLAG_T		tabPtrFlag;		/* FALSE => data is a data tab, TRUE => data is a ptr tab */
    DATETIME_T  dateTimeSt;     /* MRA - 031110 - REF9598 last modif date */
} DBA_DATASET_ST, *DBA_DATASET_STP;

typedef struct
{
    int 		fmtEltNb,
        dataSetNb;
    ID_T            fctResId;               /* 29.05.96 - Ref.: DVP056+ */
    DBA_DYNFLD_STP  fmtEltDef;		/* type de structure dyn : FmtEltDef */
    DBA_DATASET_STP	dataSetStTab;		/* tableau de structures DBA_DATASET_ST */
} DBA_DATARESULT_ST, *DBA_DATARESULT_STP;


#include "dbiconnection.h"
class RpcProperties;

#define DBI_FORCE_EXIT		300
#define DBI_FORCE_CLOSE		301
#define DBI_UNUSED			CS_UNUSED

extern RET_CODE DBI_LoadDict(std::vector<DICT_LANG_ST>     &loadDictLangTabPtr,
                             std::vector<DICT_DATATP_ST>   &loadDictDataTpTabPtr);

extern RET_CODE DBI_LoadDictForMig();

extern RET_CODE DBI_LoadDictForSql(std::vector<DICT_LANG_ST>     &loadDictLangTabPtr,
                                   std::vector<DICT_DATATP_ST>   &loadDictDataTpTabPtr);

extern const std::string &DBI_GetSqlServerName(std::string = "");     /* PMSTA-18593 - LJE - 150901 */ /* PMSTA-41113 - KNI - 270720 */
extern const std::string DBI_GetSqlServerNameByRdbms(DBA_RDBMS_ENUM rdbmsEn, bool bTargetDataSource);   /* PMSTA-nuodb - LJE - 190412 */
extern RET_CODE DBI_InitializeContext(const bool );
extern void     DBI_FreeContext();
extern RET_CODE DBI_LoadDictFct();
extern RET_CODE DBI_LoadDictFctByUserId(ID_T, std::vector<DICT_FCT_ST>&);
extern RET_CODE DBI_LoadApplParam(DbiConnection&, ID_T userId, std::map<std::string,std::string>& map_param_bootstrap);
extern RET_CODE DBI_GetDbDateOnServer(DATETIME_STP, DbiConnection& );   /* PMSTA-37366 - LJE - 191112 */
extern RET_CODE DBI_ConfigureClientLibrary(int);
extern RET_CODE DBI_GimmeNetRunning(const char	*appName,
    short	*netCoreNb,
    short	*netProdModNb,
    short	*netAttribModNb,
    short	*netRiskModNb,
    short	*netAccModNb,
    short	*netFundModNb,
    short	*netCorpActionsModNb,
    short	*netAdvAnalyticsModNb,
    short	*netCompManagementModNb,
    short	*netExcelReportModNb,
    short	*netRAModNb,
    short	*netACMModNb,
    short	*netOMModNb);
extern int DBI_InsertPasswdHistory(SYSNAME_T, PasswordEncrypted&, DbiConnectionHelper&);
extern int DBI_CheckExpiredPassword();
extern int DBI_CheckMaxRunningGui();
extern int DBI_CleanLoginFailed();
extern void DBI_SetDateApplInfo(const GEN_APPLINFO_ENUM, INFO_T );
extern int DBI_FetchDBServiceNameBE(const std::string&, std::string &, ID_T &); /* PMSTA-41113 - KNI - 270720 */
extern int DBI_ScanCfg(int mode, ...);
extern bool DBI_CheckSecurity(const char *);
extern RET_CODE DBI_ManagedSqlExec(AAASQL_CONTEXT_STP context, int* status = NULL);   /* PMSTA-18593 - LJE - 151021 */
extern bool DBI_IsRpcProc(const std::string & rpcName);
extern bool DBI_GetRpcParamInfoStp(const std::string & rpcName, RpcProperties &rpcProperties);
extern int DBI_SetProcParameters(DbiConnection&, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_PROC_STP, OBJECT_ENUM  object = NullEntityCst, char udFlg = FALSE);
extern int DBI_CopyNullFlagsAndLengthDynSt(DbiConnection&, DBA_DYNFLD_STP, DBA_DYNST_ENUM);
extern int DBI_CopyNullFlagsAndLength(DbiConnection&, DBA_DYNFLD_STP, int, DATATYPE_ENUM );
extern void DBI_PrintVersion();
extern bool DBI_CheckUserRole(DbiConnection&, const std::string& role);
extern AAACONNECTION_ALLOCATOR_FPTR DBI_GetConnAllocatorPtr(DBA_SERVER_TYPE_ENUM, DBA_RDBMS_ENUM serverModel);
extern int DBI_InsApplUserById(DBA_DYNFLD_STP, DbiConnection&);
extern int DBI_InsApplUserDbLogin(DBA_DYNFLD_STP, DbiConnection&); /* PMSTA-45027 - LJE - 210503 */
extern int DBI_UpdApplUser(DBA_DYNFLD_STP, DbiConnection&);
extern RET_CODE DBI_CheckMinPasswdLength(char*, DbiConnection&);
extern RET_CODE DBI_ChangePasswd(SYSNAME_T adminUser,
                                 PasswordEncrypted& adminPasswd,
                                 SYSNAME_T userCode,
                                 PasswordEncrypted& newPasswd);
extern RET_CODE DBI_SetServerConnectApplInfo(DbiConnection&, int*, FLAG_T *, FLAG_T *);
extern RET_CODE DBI_FldToDbDataStr(char *, size_t, DBA_DYNFLD_STP, int, DATATYPE_ENUM, int *, bool);
extern RET_CODE DBI_FldToDbDataStr(std::stringstream &, DBA_DYNFLD_STP, FIELD_IDX_T, DATATYPE_ENUM, bool, DBA_RDBMS_ENUM, const char * = "'");    /* PMSTA-nuodb - LJE - 190910 */
extern RET_CODE DBI_ProcessAllAccessResults(DbiConnection&,
                                            int,
                                            int,
                                            int,
                                            DBA_ACCESS_STP,
                                            int *,
                                            DBA_DYNFLD_STP *,
                                            DBA_ACTION_ENUM,
                                            OBJECT_ENUM,
                                            int *,
                                            const int,
                                            DBA_PROC_STP);
extern RET_CODE DBI_ReadFinFctResults(DbiConnection&, DBA_DATARESULT_STP *);


extern std::string  DBI_PrintSqlReqParamEqualValue(const std::string &, const std::string &);
extern void         DBI_PrintSqlReqHeader(std::string &, int, DBA_DYNFLD_STP, DBA_PROC_STP, OBJECT_ENUM, int, bool&);
extern void         DBI_PrintSqlReqBodyStart(std::string&, DBA_PROC_STP);
extern void         DBI_PrintSqlReqBodyEnd(std::string& recBuffer);
extern void         DBI_PrintSqlReqFooter(std::string& recBuffer, bool &bFirst);
extern void         DBI_PrintSqlReqParam(std::string&, std::string&, int, DBA_PROC_STP, int, DATATYPE_ENUM, int*, DBA_DYNFLD_STP, RequestHelper &);
extern std::string  DBI_GetSqlStatementBegin();
extern std::string  DBI_GetSqlStatementEnd();
extern std::string  DBI_GetSqlStatementSeparator();
extern std::string  to_stringSql(const bool);		/* PMSTA-20159 - TEB - 151110 */
extern std::string  to_stringSql(const ID_T);


extern RET_CODE DBI_GetFinancialServerVersionEx(DBA_DYNFLD_STP, const std::string & = "");

extern bool DBI_CheckVersion(const std::string &, const bool &, std::string &);

extern void         DBA_CreateSQLCall(std::string &, char *, const int, const DBA_ACCESS_STP, DBA_PROC_STP);

#endif
/************************************************************************
**      END        dbi.h
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB01_H
#define FINLIB01_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib01.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINLIB01_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN double   FIN_Round(ID_T, double, CODE_T),
                FIN_Qty(DBA_DYNFLD_STP, NUMBER_T);

EXTERN int      FIN_Cmp_Amount(double, double, ID_T);

EXTERN RET_CODE FIN_MktVal(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, 	/* REF1457 */
			               DATETIME_T, FIN_AIARG_STP, FIN_MKTVAL_STP, DBA_HIER_HEAD_STP), 
		        FIN_GenAccrNetValuePos(PTR),
		        FIN_ComputeDebtScript(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, HIER_FLTFCT *),
		        FIN_ComputeDebtSimpleScript(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, HIER_FLTFCT *), /* REF2338 - DDV - 981029 */ /* REF7264 - LJE - 020131 */
		        FIN_ComputeDebtSimpleScriptPos(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, /* REF2338 - DDV - 981029 */
                                               DBA_DYNFLD_STP, NUMBER_T *, NUMBER_T *),
                FIN_PtfDefAccount(ID_T, ID_T, ENUM_T, ID_T, ID_T, DBA_DYNFLD_STP,DBA_HIER_HEAD_STP),
                FIN_NetValFutFwdValDiff(PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, double, NUMBER_T*);
EXTERN FLAG_T	FIN_SetZeroPosAmt(DBA_DYNFLD_STP); /* REF3082 - RAK - 981130 */
EXTERN RET_CODE FIN_GetChronoNatUnpPrct(DBA_DYNFLD_STP,NUMBER_T*,DATETIME_T,DBA_HIER_HEAD_STP), /* REF5922.3511 - AKO - 010702 */
				FIN_UpdDomainRefCurr(DBA_DYNFLD_STP, DBA_DYNFLD_STP); /* REF6220 - LJE - 020319 */

EXTERN int      FIN_CmpPosInstrIdRefNat(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);    /* PMSTA05966 - 090525 - PMO */

EXTERN RET_CODE FIN_GetAccFlag(DBA_DYNFLD_STP, DBA_DYNFLD_STP, FLAG_T*, FLAG_T*, FLAG_T*); /* PMSTA-13140 - LJE - 120319 */

EXTERN void FIN_DelTechnicalPosFromHier(DBA_HIER_HEAD_STP);         /* PMSTA-22582 - DDV - 160301 - Remove technical positions */

extern bool FIN_IsPerfTimingRuleSet(DBA_HIER_HEAD_STP, const DBA_DYNFLD_STP, INVESTTIMINGRULE_ENUM &);
extern bool FIN_IsPerfTimingRuleSet(DBA_HIER_HEAD_STP, const DBA_DYNFLD_STP, PerfTimingRuleTimingRuleEn &);

#endif /* FINLIB01_H */


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENDBACCESS_CPP

/************************************************************************
**      Includes
*************************************************************************/

#include           "unidef.h"     /* Mandatory */
#include              "gen.h"
#include    "dbiconnection.h"
#include              "dba.h"
#include           "ddlgen.h"
#include           "dbafmt.h"
#include             "itfc.h"
#include        "callstack.h"


/************************************************************************
**      External entry points
**
*************************************************************************/
extern int            EV_AAAInstallLevel;

extern bool           EV_UseAlternativeDataSource;
extern DdlGenCfgFile* EV_SourceCfgFile;


/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
const char* GetXdObjectConst  = "DBA_GetXdObject";
const char* SelXdObjectConst  = "DBA_SelXdObject";
const char* UpdXdObjectConst  = "DBA_UpdXdObject";
const char* InsXdObjectConst  = "DBA_InsXdObject";
const char* DelXdObjectConst  = "DBA_DelXdObject";

#define NESTED_ERASE(vector, iterator) { \
    iterator = vector.erase(iterator); \
    if (iterator == vector.end())\
    {\
        break;\
    }\
    if (iterator == vector.begin())\
    {\
       continue; \
    } \
    iterator--;\
    }


#define OPTIM_LIMIT_SIZE 10

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DBA_GetXdObject()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_GetXdObject(OBJECT_ENUM           objectEn,
                         DBA_DYNFLD_STP        inputData,
                         DBA_DYNFLD_STP       *outputData,
                         DbiConnectionHelper  &dbiConnHelper)
{
    auto currProcStp = dbiConnHelper.getCurrProcedure();
    int role = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

    if (ddlGenAllEntititesPtr != nullptr)
    {
        auto recordStp = *outputData;

        RET_CODE ret = ddlGenAllEntititesPtr->dbaGet(objectEn, role, inputData, recordStp);
        if (recordStp != nullptr)
        {
            if (*outputData == nullptr)
            {
                *outputData = ALLOC_DYNST(recordStp->getDynStEn());
            }

            CONVERT_DYNST(*outputData, (*outputData)->getDynStEn(), recordStp, recordStp->getDynStEn());
        }
        return ret;
    }

    return dbiConnHelper.dbaGet(objectEn, DBA_ROLE_DB_ACCESS, inputData, outputData);
}

/************************************************************************
**
**  Function    :   DBA_InsXdObject()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_InsXdObject(OBJECT_ENUM           objectEn,
                         DBA_DYNST_ENUM        inputStEn,
                         DBA_DYNFLD_STP        inputData,
                         DbiConnectionHelper  &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    auto currProcStp = dbiConnHelper.getCurrProcedure();
    int role = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenAllEntititesPtr != nullptr && 
        (ddlGenAllEntititesPtr->isLoaded(objectEn) ||
         ddlGenAllEntititesPtr->getDdlGenContext().ddlGenAction.m_fromImport))
    {
        DBA_DYNFLD_STP dataToUpdStp = ddlGenAllEntititesPtr->duplicateDynStp(FILEINFO, inputData);

        bool bToCopy = false;
        if (dataToUpdStp == nullptr)
        {
            dataToUpdStp = inputData;
            bToCopy = true;
        }

        if (role == UNUSED &&
            ddlGenAllEntititesPtr->isStatusOnIns(inputData))
        {
            role = DBA_ROLE_UDT;
        }

        ddlGenAllEntititesPtr->manageDenormAttributes(dataToUpdStp);

        ret = ddlGenAllEntititesPtr->insUpdDelRecord(Insert, objectEn, role, dataToUpdStp, bToCopy);

        /* Copy only modified fields */
        const FIELD_IDX_T fieldNbr = GET_FLD_NBR(inputStEn);
        for (FIELD_IDX_T i = 0; i < fieldNbr; i++)
        {
            if (CMP_DYNFLD(inputData, dataToUpdStp, i, i, GET_FLD_DTP(inputData, i)) != 0)
            {
                DBA_CopyDynFld(inputData, i, dataToUpdStp, i);
            }
        }

        return ret;
    }

    int dbaRole = DBA_ROLE_DB_ACCESS;

    switch (role)
    {
        case DBA_ROLE_UDT:
        case DBA_ROLE_STATUS:
            dbaRole = DBA_ROLE_DB_STATUS;
            break;

        case DBA_ROLE_IMPORT_USR_MD:
            dbaRole = DBA_ROLE_DB_ACCESS_USR;
            break;
    }

    dbiConnHelper.setFromDbaAccess();
    ret = dbiConnHelper.dbaInsert(objectEn, dbaRole, inputData);
    dbiConnHelper.resetFromDbaAccess();

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_UpdHelpDoc()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-11388 - AAKASH - 20240923
**  Modification
**
*************************************************************************/
RET_CODE DBA_UpdHelpDoc(OBJECT_ENUM           objectEn,
    DBA_DYNST_ENUM        inputStEn,
    DBA_DYNFLD_STP        inputData,
    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE retCode = RET_SUCCEED;

    if (inputData == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdHelpDoc", "inputData");
        return RET_GEN_ERR_INVARG;
    }

    SET_A_XdEntityDoc_StatusEn(inputData, DocumentationTemplateStatusEn::InProgress);

    if (objectEn == XdPermValDoc)
    {
        MemoryPool mp;
        DBA_DYNFLD_STP inputPtr = mp.allocDynst(FILEINFO, S_XdAttributeDoc);
        DBA_DYNFLD_STP outPtr   = mp.allocDynst(FILEINFO, A_XdAttributeDoc);

        SET_ID(inputPtr, A_XdAttributeDoc_Id, GET_ID(inputData, A_XdPermValDoc_XdAttribDocId));

        retCode = dbiConnHelper.dbaGet(XdAttributeDoc,
            UNUSED,
            inputPtr, &outPtr, nullptr);

        if (retCode == RET_SUCCEED)
        {
            SET_A_XdAttributeDoc_StatusEn(outPtr, DocumentationTemplateStatusEn::InProgress);

            retCode = dbiConnHelper.dbaUpdate(XdAttributeDoc, DBA_ROLE_STATUS, outPtr);

        }

        if (retCode == RET_SUCCEED)
        {
            ID_T entityDoc_Id = GET_ID(outPtr, A_XdAttributeDoc_XdEntityDocId);;
            inputPtr = mp.allocDynst(FILEINFO, S_XdEntityDoc);
            outPtr = mp.allocDynst(FILEINFO, A_XdEntityDoc);

            SET_ID(inputPtr, A_XdEntityDoc_Id, entityDoc_Id);

            retCode = dbiConnHelper.dbaGet(XdEntityDoc,
                UNUSED,
                inputPtr, &outPtr, nullptr);

            if (retCode == RET_SUCCEED)
            {
                SET_A_XdAttributeDoc_StatusEn(outPtr, DocumentationTemplateStatusEn::InProgress);

                retCode = dbiConnHelper.dbaUpdate(XdEntityDoc, DBA_ROLE_STATUS, outPtr);

            }
        }
    }
    else if (objectEn == XdAttributeDoc)
    {
        MemoryPool mp;
        DBA_DYNFLD_STP inputPtr = mp.allocDynst(FILEINFO, S_XdEntityDoc);
        DBA_DYNFLD_STP outPtr = mp.allocDynst(FILEINFO, A_XdEntityDoc);

        SET_ID(inputPtr, A_XdEntityDoc_Id, GET_ID(inputData, A_XdAttributeDoc_XdEntityDocId));

        retCode = dbiConnHelper.dbaGet(XdEntityDoc,
            UNUSED,
            inputPtr, &outPtr, nullptr);

        if (retCode == RET_SUCCEED)
        {
            SET_A_XdAttributeDoc_StatusEn(outPtr, DocumentationTemplateStatusEn::InProgress);

            retCode = dbiConnHelper.dbaUpdate(XdEntityDoc, DBA_ROLE_STATUS, outPtr);

        }
    }

    retCode = dbiConnHelper.dbaUpdate(objectEn, DBA_ROLE_STATUS, inputData);
    
    return retCode;
}
/************************************************************************
**
**  Function    :   DBA_UpdXdObject()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_UpdXdObject(OBJECT_ENUM           objectEn,
                         DBA_DYNST_ENUM        inputStEn,
                         DBA_DYNFLD_STP        inputData,
                         DbiConnectionHelper  &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    auto currProcStp = dbiConnHelper.getCurrProcedure();
    int role = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenAllEntititesPtr != nullptr && 
        (ddlGenAllEntititesPtr->isLoaded(objectEn) ||
         ddlGenAllEntititesPtr->getDdlGenContext().ddlGenAction.m_fromImport))
    {
        if (ddlGenAllEntititesPtr->manageCustoData(inputData, role))
        {
            return RET_SUCCEED;
        }
        else
        {
            DBA_DYNFLD_STP dataToUpdStp = ddlGenAllEntititesPtr->getRecord(objectEn, inputData);

            bool bToCopy = false;
            if (dataToUpdStp == nullptr)
            {
                dataToUpdStp = inputData;
                bToCopy = true;
            }
            else if (dataToUpdStp != inputData)
            {
                ddlGenAllEntititesPtr->manageDenormAttributes(inputData);

                /* Copy only modified fields */
                const FIELD_IDX_T fieldNbr = GET_FLD_NBR(inputStEn);
                for (FIELD_IDX_T i = 0; i < fieldNbr; i++)
                {
                    if (IS_MDFLD(inputStEn, i) == TRUE &&
                        CMP_DYNFLD(inputData, dataToUpdStp, i, i, GET_FLD_DTP(inputData, i)) != 0 &&
                        (role != UNUSED || 
                         IS_SPECIALFLD(inputStEn, i) == false))
                    {
                        DBA_CopyDynFld(dataToUpdStp, i, inputData, i);
                    }
                }
            }

            if (role == UNUSED &&
                ddlGenAllEntititesPtr->isStatusOnIns(inputData))
            {
                role = DBA_ROLE_UDT;
            }

            return ddlGenAllEntititesPtr->insUpdDelRecord(Update, objectEn, role, dataToUpdStp, bToCopy);
        }
    }

    int dbaRole = DBA_ROLE_DB_ACCESS;

    switch (role)
    {
        case DBA_ROLE_UDT:
        case DBA_ROLE_STATUS:
            dbaRole = DBA_ROLE_DB_STATUS;
            break;

        case DBA_ROLE_IMPORT_USR_MD:
            dbaRole = DBA_ROLE_DB_ACCESS_USR;
            break;
    }

    dbiConnHelper.setFromDbaAccess();
    ret = dbiConnHelper.dbaUpdate(objectEn, dbaRole, inputData);
    dbiConnHelper.resetFromDbaAccess();

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_DelXdObject()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_DelXdObject(OBJECT_ENUM           objectEn,
                         DBA_DYNST_ENUM        inputStEn,
                         DBA_DYNFLD_STP        inputData,
                         DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    auto currProcStp = dbiConnHelper.getCurrProcedure();
    int role = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenAllEntititesPtr != nullptr &&
        (ddlGenAllEntititesPtr->isLoaded(objectEn) ||
         ddlGenAllEntititesPtr->getDdlGenContext().ddlGenAction.m_fromImport))
    {
        DBA_DYNFLD_STP dataToUpdStp = ddlGenAllEntititesPtr->getRecord(inputData->getObjectEn(), inputData);

        ret = ddlGenAllEntititesPtr->insUpdDelRecord(Delete, objectEn, role, (dataToUpdStp == nullptr ? inputData : dataToUpdStp), false);

        return ret;
    }

    int dbaRole = DBA_ROLE_DB_ACCESS;

    dbiConnHelper.setFromDbaAccess();
    ret = dbiConnHelper.dbaDelete(objectEn, dbaRole, inputData);
    dbiConnHelper.resetFromDbaAccess();

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_ResetDictSprocByEntity()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_ResetDictSprocByEntity(OBJECT_ENUM           objectEn,
                                    DBA_DYNST_ENUM,
                                    DBA_DYNFLD_STP        inputData,
                                    DbiConnectionHelper  &dbiConnHelper)
{
    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenAllEntititesPtr != nullptr && ddlGenAllEntititesPtr->isLoaded(objectEn))
    {
        RET_CODE ret = RET_SUCCEED;

        std::vector<DBA_DYNFLD_STP> outputRecords;
        dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr()->selRecords(objectEn, DBA_ROLE_UDT, inputData, outputRecords);

        for (auto it = outputRecords.begin(); it != outputRecords.end(); ++it)
        {
            SET_A_DictSproc_XdActionEn((*it), XdEntityXdActionEn::ToPhysicallyDelete);

            ret = ddlGenAllEntititesPtr->insUpdDelRecord(Update, objectEn, UNUSED, (*it), false);
        }

        return ret;
    }

    return dbiConnHelper.dbaUpdate(objectEn, DBA_ROLE_DB_ACCESS, inputData);
}

/************************************************************************
**
**  Function    :   DBA_SelXdObject()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-45413 - LJE - 210616
**  Modification
**
*************************************************************************/
RET_CODE DBA_SelXdObject(OBJECT_ENUM           objectEn,
                         DBA_DYNFLD_STP        inputData,
                         DBA_DYNFLD_STP      **outputData,
                         int                  *rowsNbr,
                         DbiConnectionHelper  &dbiConnHelper)
{
    /*
     *  Initialization
     */
    *outputData = NULL;
    *rowsNbr = 0;

    auto           currProcStp = dbiConnHelper.getCurrProcedure();
    int dbaRole = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

    DBA_DYNST_ENUM outputDynStEn = (currProcStp == nullptr ? GET_EDITGUIST(objectEn) : (*currProcStp->outputDynStPtr));

    auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenDbaAccessPtr != nullptr && dbaRole != DBA_ROLE_DB_ACCESS && dbaRole < DBA_ROLE_DB_ACCESS_FACTOR)
    {
        int            role = (currProcStp == nullptr ? UNUSED : currProcStp->subObj);

        std::vector<DBA_DYNFLD_STP> outputRecords;
        ddlGenDbaAccessPtr->selRecords(objectEn, role, inputData, outputRecords);

        if (outputRecords.empty() == false)
        {
            *outputData = static_cast<DBA_DYNFLD_STP *>(CALLOC(outputRecords.size(), sizeof(DBA_DYNFLD_STP)));

            for (auto it = outputRecords.begin(); it != outputRecords.end(); ++it)
            {
                (*outputData)[(*rowsNbr)] = ALLOC_DYNST(outputDynStEn);
                CONVERT_DYNST((*outputData)[(*rowsNbr)], outputDynStEn, (*it), (*it)->getDynStEn());
                (*rowsNbr)++;
            }

            return RET_SUCCEED;
        }
        else if (dbaRole != DBA_ROLE_FORMAT &&
                 (ddlGenDbaAccessPtr->isLoaded(objectEn) ||
                  ddlGenDbaAccessPtr->checkRecord(inputData, false) == false))
        {
            return RET_DBA_INFO_NO_MORE_DATA;
        }
    }

    dbiConnHelper.setFromDbaAccess();

    switch (dbaRole)
    {
        case UNUSED:
        case DBA_ROLE_FORMAT:
            dbaRole = DBA_ROLE_DB_ACCESS;
            break;

        default:
            dbaRole += DBA_ROLE_DB_ACCESS_FACTOR;
    }

    if (currProcStp != nullptr &&
        DBA_GetStoredProcs(currProcStp->action, objectEn, dbaRole, *currProcStp->inputDynStPtr, inputData, *currProcStp->outputDynStPtr) == nullptr)
    {
        dbaRole = currProcStp->subObj;
    }

    RET_CODE ret = dbiConnHelper.dbaSelect(objectEn, dbaRole, inputData, outputDynStEn, outputData, rowsNbr);

    if (ddlGenDbaAccessPtr != nullptr)
    {
        for (int i = 0; i < *rowsNbr; ++i)
        {
            ID_T newId = 0;
            ddlGenDbaAccessPtr->insRecord((*outputData)[i], newId, true, true, true);
        }
    }
    dbiConnHelper.resetFromDbaAccess();

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdAttrib()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC bool DDL_CmpXdAttrib(DBA_DYNFLD_STP ptr1, DBA_DYNFLD_STP ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_ShortOnlyFlg, A_XdAttrib_ShortOnlyFlg, FlagType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_Prog, A_XdAttrib_Prog, IntType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_OldProg, A_XdAttrib_OldProg, IntType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_ProgPk, A_XdAttrib_ProgPk, SmallintType)) != 0)
        return cmp < 0;

    if (GET_SMALLINT((ptr1), A_XdAttrib_DispRank) > 0 && GET_SMALLINT((ptr2), A_XdAttrib_DispRank) == 0)
        return false;

    if (GET_SMALLINT((ptr1), A_XdAttrib_DispRank) == 0 && GET_SMALLINT((ptr2), A_XdAttrib_DispRank) > 0)
        return true;

    if (GET_SMALLINT((ptr1), A_XdAttrib_DispRank) > 0 &&
        GET_SMALLINT((ptr2), A_XdAttrib_DispRank) > 0 &&
        (cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_DispRank, A_XdAttrib_DispRank, SmallintType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr2), (ptr1), A_XdAttrib_MultiLangFlg, A_XdAttrib_MultiLangFlg, FlagType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_ShortIdx, A_XdAttrib_ShortIdx, SmallintType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_AttribDictId, A_XdAttrib_AttribDictId, DictType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_SqlName, A_XdAttrib_SqlName, SysnameType)) != 0)
        return cmp < 0;

    if ((cmp = CMP_DYNFLD((ptr1), (ptr2), A_XdAttrib_Id, A_XdAttrib_Id, IdType)) != 0)
        return cmp < 0;

    return cmp < 0;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdPartition()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DDL_CmpXdPartition(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    /* NULL in first */
    if ((cmp = CMP_DYNFLD((*ptr2), (*ptr1), A_XdPartition_ParentXdPartitionId, A_XdPartition_ParentXdPartitionId, IdType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdPartition_Rank, A_XdPartition_Rank, SmallintType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdPartition_XdStatusEn, A_XdPartition_XdStatusEn, EnumType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdPartition_Id, A_XdPartition_Id, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdPartitionIndex()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DDL_CmpXdPartitionIndex(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdPartitionIndex_XdPartitionId, A_XdPartitionIndex_XdPartitionId, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DdlGenRequestHelper::DdlGenRequestHelper(DbiConnection *dbiConn, DdlGenContext &ddlGenContext)
    : RequestHelper(dbiConn)
    , m_ddlGenContext(ddlGenContext)
{

}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DdlGenRequestHelper::DdlGenRequestHelper(DbiConnectionHelper &dbiConnHelper, DdlGenContext &ddlGenContext)
    : RequestHelper(dbiConnHelper)
    , m_ddlGenContext(ddlGenContext)
{

}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DdlGenRequestHelper::~DdlGenRequestHelper()
{
}


/************************************************************************
*   Function             :  DdlGenRequestHelper:setCopyIdForBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 230209
*
*   Last Modification    :
*
*************************************************************************/
void DdlGenRequestHelper::setCopyIdForBatchMulti(size_t         batchRankBefore,
                                                 DBA_DYNFLD_STP targetDynStp,
                                                 FIELD_IDX_T    targetFldIdx,
                                                 DBA_DYNFLD_STP srcDynStp,
                                                 FIELD_IDX_T    srcFldIdx)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);

    if (ddlGenDbaAccessGuard.getDdlGenDbaAccess().isLoaded(targetDynStp->getObjectEn()))
    {
        COPY_DYNFLD(targetDynStp, targetDynStp->getDynStEn(), targetFldIdx, srcDynStp, srcDynStp->getDynStEn(), srcFldIdx);
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().m_batchToCopyMap[batchRankBefore].push_back(CopyInfo(targetDynStp, targetFldIdx, srcDynStp, srcFldIdx));
    }
    else
    {
        RequestHelper::setCopyIdForBatchMulti(batchRankBefore, targetDynStp, targetFldIdx, srcDynStp, srcFldIdx);
    }
}


/************************************************************************
*   Function             :  DdlGenRequestHelper:setCopyIdForBatchMulti()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 230209
*
*   Last Modification    :
*
*************************************************************************/
void DdlGenRequestHelper::setCopyIdForBatchMulti(ID_T* idPtr, DBA_DYNFLD_STP srcDynStp, FIELD_IDX_T srcFldIdx, size_t batchRankAfter)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);

    if (ddlGenDbaAccessGuard.getDdlGenDbaAccess().isLoaded(srcDynStp->getObjectEn()))
    {
        *idPtr = GET_ID(srcDynStp, srcFldIdx);
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().m_batchToCopyIdMap[batchRankAfter][&(srcDynStp[srcFldIdx])] = idPtr;
    }
    else
    {
        RequestHelper::setCopyIdForBatchMulti(idPtr, srcDynStp, srcFldIdx, batchRankAfter);
    }
}


/************************************************************************
*   Function             :  DdlGenRequestHelper:copyBatchToCopyMap()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-46681 - LJE - 230209
*
*   Last Modification    :
*
*************************************************************************/
void DdlGenRequestHelper::copyBatchToCopyMap(std::map<size_t, std::vector<RequestHelper::CopyInfo>> &batchToCopyMap, 
                                             std::map<size_t, std::map<DBA_DYNFLD_STP, ID_T*>>      &batchToCopyIdMap,
                                             std::set<size_t> &currentBatchRankSet)
{
    for (auto it = batchToCopyMap.begin(); it != batchToCopyMap.end(); ++it)
    {
        if (currentBatchRankSet.find(it->first) != currentBatchRankSet.end())
        {
            for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
            {
                RequestHelper::setCopyIdForBatchMulti(it->first, it2->m_targetDynStp, it2->m_targetFldIdx, it2->m_srcDynStp, it2->m_srcFldIdx); /* PMSTA-52962 - DDV - 230509 - exchange target and source */
            }
        }
    }
    for (auto it = batchToCopyIdMap.begin(); it != batchToCopyIdMap.end(); ++it)
    {
        if (currentBatchRankSet.find(it->first) != currentBatchRankSet.end())
        {
            for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
            {
                RequestHelper::setCopyIdForBatchMulti(it2->second, it2->first, 0, it->first);
            }
        }
    }
    currentBatchRankSet.clear();
}


/************************************************************************
**
**  Function    :   DdlGenRequestHelper::dbaCall()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
RET_CODE DdlGenRequestHelper::dbaCall(DBA_ACTION_ENUM  action,
                                      OBJECT_ENUM      objectEn,
                                      int              role,
                                      DBA_DYNFLD_STP  &inputDataStp,
                                      size_t           batchRank,
                                      DBA_DYNFLD_STP   parentDataStp)
{
    RET_CODE ret = RET_SUCCEED;

    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);

    if (ddlGenDbaAccessGuard.getDdlGenDbaAccess().isLoaded(objectEn))
    {
        ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().insUpdDelRecord(action,
                                                                        objectEn,
                                                                        role,
                                                                        inputDataStp,
                                                                        false,
                                                                        batchRank,
                                                                        parentDataStp);
    }
    else
    {
        if (parentDataStp != nullptr)
        {
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);
            if (dictEntityStp != nullptr &&
                dictEntityStp->parentAttrStp != nullptr)
            {
                COPY_DYNFLD(inputDataStp,
                            inputDataStp->getDynStEn(), 
                            dictEntityStp->parentAttrStp->progN,
                            parentDataStp, parentDataStp->getDynStEn(),
                            dictEntityStp->primKeyTab[0]->progN);
            }
        }
        DbiConnectionHelper dbiConnHelper(this->m_dbiConn);

        switch (action)
        {
            case Insert:
                ret = dbiConnHelper.dbaInsert(objectEn, role, inputDataStp);
                break;

            case Update:
                ret = dbiConnHelper.dbaUpdate(objectEn, role, inputDataStp);
                break;

            case Delete:
                ret = dbiConnHelper.dbaDelete(objectEn, role, inputDataStp);
                break;

            default:
                SYS_BreakOnDebug();

        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::dbaGet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
RET_CODE DdlGenRequestHelper::dbaGet(OBJECT_ENUM     objectEn,
                                     int             role,
                                     DBA_DYNFLD_STP  inputData,
                                     DBA_DYNFLD_STP &outputData)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    if (ddlGenDbaAccessGuard.getDdlGenDbaAccess().isLoaded(objectEn))
    {
        return ddlGenDbaAccessGuard.getDdlGenDbaAccess().dbaGet(objectEn,
                                                                role,
                                                                inputData,
                                                                outputData);
    }

    DbiConnectionHelper dbiConnHelper(this->m_dbiConn);

    if (outputData == nullptr)
    {
        outputData = this->allocDynSt(FILEINFO, GET_EDITGUIST(objectEn));
    }

    return dbiConnHelper.dbaGet(objectEn, role, inputData, &outputData);
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::insUpdRecord()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14086 - LJE - 121004
**
*************************************************************************/
RET_CODE DdlGenRequestHelper::insUpdRecord(DBA_DYNFLD_STP &xdObjectStp, DBA_ACTION_ENUM &actionDone, DBA_DYNFLD_STP parentXdObjectStp, bool bRemoveFromMp)
{
    MemoryPool      mp;
    RET_CODE        ret             = RET_SUCCEED;
    DBA_DYNST_ENUM  xdObjectStEn    = GET_DYNSTENUM(xdObjectStp);
    OBJECT_ENUM     xdObjectObjEn   = GET_OBJ_DYNST(xdObjectStEn);
    DBA_DYNST_ENUM  shXdObjectStEn  = GET_ADMINGUIST(xdObjectObjEn);
    DICT_ENTITY_STP xdDictEntityStp = DBA_GetDictEntitySt(xdObjectObjEn);
    bool            bForceUdtRole   = false;
    bool            bDoUdtRole      = true;
    DBA_DYNFLD_STP  shXdObjectStp   = mp.allocDynst(FILEINFO, shXdObjectStEn);
    bool            bTryGet         = false;

    if (xdObjectObjEn == XdEntityFeature ||
        xdObjectObjEn == XdEntity ||
        xdObjectObjEn == XdAttrib)
    {
        bForceUdtRole = true;
    }

    if (xdObjectObjEn == DictLabel ||
        xdObjectObjEn == ApplMsgTxt)
    {
        bDoUdtRole = false;
    }

    /* PMSTA-30453 - LJE - 180327 */
    for (int i = 0; i < xdDictEntityStp->primKeyNbr; i++)
    {
        if (xdDictEntityStp->primKeyTab[i]->isNullShortIdx == false &&
            IS_NULLFLD(xdObjectStp, xdDictEntityStp->primKeyTab[i]->progN) == FALSE)
        {
            bTryGet = true;
            COPY_DYNFLD(shXdObjectStp, shXdObjectStEn, xdDictEntityStp->primKeyTab[i]->shortIdx, xdObjectStp, xdObjectStEn, xdDictEntityStp->primKeyTab[i]->progN);
        }
    }

    int bkOkNbr = 0;
    for (int i = 0; i < xdDictEntityStp->bkAttrNbr; i++)
    {
        if (xdDictEntityStp->bkAttr[i]->isNullShortIdx == false &&
            (IS_NULLFLD(xdObjectStp, xdDictEntityStp->bkAttr[i]->progN) == FALSE || xdDictEntityStp->bkAttr[i]->dbMandatoryFlg == FALSE))
        {
            bkOkNbr++;
            COPY_DYNFLD(shXdObjectStp, shXdObjectStEn, xdDictEntityStp->bkAttr[i]->shortIdx, xdObjectStp, xdObjectStEn, xdDictEntityStp->bkAttr[i]->progN);
        }
    }

    if (bTryGet == false && bkOkNbr == xdDictEntityStp->bkAttrNbr)
    {
        bTryGet = true;
    }

    DBA_DYNFLD_STP  aXdObjectStp = nullptr;
    if (bTryGet == false ||
        this->dbaGet(xdObjectObjEn, UNUSED, shXdObjectStp, aXdObjectStp) != RET_SUCCEED)
    {
        actionDone = Insert;
        this->dbaCall(Insert,
                      xdObjectObjEn,
                      bForceUdtRole ? DBA_ROLE_UDT : UNUSED,
                      xdObjectStp,
                      xdDictEntityStp->bkAttrNbr,
                      parentXdObjectStp);
    }
    else
    {
        if (xdObjectStp != aXdObjectStp)
        {
            /* Keep the PK */
            for (int i = 0; i < xdDictEntityStp->primKeyNbr; i++)
            {
                COPY_DYNFLD(xdObjectStp, 
                            xdObjectStp->getDynStEn(), 
                            xdDictEntityStp->primKeyTab[i]->progN, 
                            aXdObjectStp, 
                            aXdObjectStp->getDynStEn(), 
                            xdDictEntityStp->primKeyTab[i]->progN);
            }

            DBA_CopyDynStWithSetFld(aXdObjectStp, xdObjectStp);

            if (bRemoveFromMp)
            {
                this->freeDynStp(xdObjectStp);
            }

            xdObjectStp = aXdObjectStp;
        }

        actionDone = Update;
        this->dbaCall(Update,
                      xdObjectObjEn,
                      bForceUdtRole ? DBA_ROLE_UDT : UNUSED,
                      xdObjectStp,
                      xdDictEntityStp->bkAttrNbr,
                      parentXdObjectStp);
    }

    if (bForceUdtRole == false && bDoUdtRole == true)
    {
        this->dbaCall(Update,
                      xdObjectObjEn,
                      DBA_ROLE_STATUS,
                      xdObjectStp,
                      CAST_SIZE(xdDictEntityStp->bkAttrNbr) + 1,
                      parentXdObjectStp);
    }

    return ret;
}

/************************************************************************
*   Function             :  DdlGenRequestHelper::sendAllMsg()
*
*   Description          :  
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-49178 - LJE - 221128
*
*   Last Modification    :
*
*************************************************************************/
void DdlGenRequestHelper::sendAllMsg()
{
    this->m_dbiConn->sendAllMsg();
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::allocDynSt
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenRequestHelper::allocDynSt(const char *fileName, const int line, const DBA_DYNST_ENUM & dynstEn)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    return ddlGenDbaAccessGuard.getDdlGenDbaAccess().allocDynSt(fileName, line, dynstEn);
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::duplicateDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenRequestHelper::duplicateDynStp(const char *fileName, const int line, const DBA_DYNFLD_STP dynStp)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    return ddlGenDbaAccessGuard.getDdlGenDbaAccess().duplicateDynStp(fileName, line, dynStp);
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::ownerDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230222
**
*************************************************************************/
void DdlGenRequestHelper::ownerDynStp(DBA_DYNFLD_STP dynStp)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    ddlGenDbaAccessGuard.getDdlGenDbaAccess().ownerDynStp(dynStp);
}

/************************************************************************
**
**  Function    :   DdlGenRequestHelper::freeDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
void DdlGenRequestHelper::freeDynStp(DBA_DYNFLD_STP &dynStp)
{
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    ddlGenDbaAccessGuard.getDdlGenDbaAccess().freeDynStp(dynStp);
}

/************************************************************************
**
**  Function    :   DdlSelectElt()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150519
**
*************************************************************************/
DdlSelectElt::DdlSelectElt()
{
    this->datatype      = NullDataType;
    this->bOutput       = false;
    this->bMandatory    = false;    /* PMSTA-26250 - LJE - 170327 */
    this->bPrintDefValIfNull = false;
    this->bShadowAttrib = false; /* PMSTA-26250 - LJE - 170425 */
    this->bPrimaryKey   = false; /* PMSTA-27525 - LJE - 170613 */
    this->attribStp     = nullptr; /* PMSTA-32145 - LJE - 180718 */
}

DdlSelectElt::DdlSelectElt(const DdlSelectElt& toCopy)
{
    this->sqlName         = toCopy.sqlName;
    this->mdSqlName       = toCopy.mdSqlName;
    this->varName         = toCopy.varName;
    this->colAlias        = toCopy.colAlias;
    this->tblAlias        = toCopy.tblAlias;
    this->datatype        = toCopy.datatype;
    this->value           = toCopy.value;
    this->bOutput         = toCopy.bOutput;
    this->bMandatory      = toCopy.bMandatory; /* PMSTA-26250 - LJE - 170327 */
    this->bPrintDefValIfNull = toCopy.bPrintDefValIfNull;
    this->defaultValueStr = toCopy.defaultValueStr; /* PMSTA-26250 - LJE - 170327 */
    this->bShadowAttrib   = toCopy.bShadowAttrib; /* PMSTA-26250 - LJE - 170425 */
    this->bPrimaryKey     = toCopy.bPrimaryKey; /* PMSTA-27525 - LJE - 170613 */
    this->attribStp       = toCopy.attribStp; /* PMSTA-32145 - LJE - 180718 */
}


/************************************************************************
**
**  Function    :   ~DdlSelectElt()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150519
**
*************************************************************************/
DdlSelectElt::~DdlSelectElt()
{

}

/************************************************************************
**
**  Function    :   operator =
**
**  Description :   Operator =
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-21197 - LJE - 160421
**
*************************************************************************/
DdlSelectElt& DdlSelectElt::operator = (const DdlSelectElt& toCopy)
{
    this->sqlName         = toCopy.sqlName;
    this->mdSqlName       = toCopy.mdSqlName;
    this->varName         = toCopy.varName;
    this->colAlias        = toCopy.colAlias;
    this->tblAlias        = toCopy.tblAlias;
    this->datatype        = toCopy.datatype;
    this->value           = toCopy.value;
    this->bOutput         = toCopy.bOutput;
    this->bMandatory      = toCopy.bMandatory;      /* PMSTA-26250 - LJE - 170327 */
    this->defaultValueStr = toCopy.defaultValueStr; /* PMSTA-26250 - LJE - 170327 */
    this->bShadowAttrib   = toCopy.bShadowAttrib;   /* PMSTA-26250 - LJE - 170425 */
    this->bPrimaryKey     = toCopy.bPrimaryKey;     /* PMSTA-27525 - LJE - 170613 */
    this->attribStp       = toCopy.attribStp;       /* PMSTA-32145 - LJE - 180718 */

    return *this;
}

/************************************************************************
**
**  Function    :   DdlGenImportFile()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlGenImportFile::DdlGenImportFile(const std::string             &rootPath,
                                   const std::string             &path,
                                   const std::string             &fileName, 
                                   const std::string             &fileExt,
                                   DdlGenImportFile::KindOfData   kindOfData)
    : m_fileName(fileName)
    , m_fileExt(fileExt)
    , m_kindOfData(kindOfData)
    , m_rootPath(rootPath)
    , m_path(path)
    , m_fullPath(rootPath + path)
{
    if (rootPath.find("ddl") != (rootPath.size() - 3))
    {
        this->m_logPath = rootPath + "/ddl/log/";
    }
    else
    {
        this->m_logPath = rootPath + "/log/";
    }

    if (this->m_fullPath[m_fullPath.size() - 1] != '/')
    {
        this->m_fullPath += "/";
    }

    if (this->m_fileName.empty() == false)
    {
        this->m_fullName = this->m_fullPath + this->m_fileName;

        if (this->m_fileExt.empty() == false)
        {
            this->m_fullName += "." + this->m_fileExt;
        }

        this->m_logName = fileName + ".log";
    }
}

/************************************************************************
**
**  Function    :   ~DdlGenImportFile()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlGenImportFile::~DdlGenImportFile()
{
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::DdlGenDbaAccess()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlGenDbaAccess::DdlGenDbaAccess(DdlGenContext &ddlGenContext)
    : m_isMetaDictLoaded(false)
    , m_isExtendedLoaded(false)
    , m_ddlGenContext(ddlGenContext)
    , m_newId(0)
    , m_kindOfImportFile(DdlGenImportFile::KindOfData::None)
    , m_packageCompositionStp(nullptr)
{
    this->m_isLoadAvoidedObjectSet.insert(ScriptDef);
    this->m_isLoadAvoidedObjectSet.insert(HoldingConstraintScript);
    this->m_isLoadAvoidedObjectSet.insert(TradingConstraintScript);
    this->m_isLoadAvoidedObjectSet.insert(DictLabel);
    this->m_isLoadAvoidedObjectSet.insert(DictDepends);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::~DdlGenDbaAccess()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlGenDbaAccess::~DdlGenDbaAccess()
{

}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::insRecordById(std::map<ID_T, DBA_DYNFLD_STP> &recordBIdMap, DBA_DYNFLD_STP recordStp, FIELD_IDX_T idIdxPos, bool bFromDB)
{
    this->m_mp.ownerDynStp(recordStp);
    this->m_allRecordsMap[recordStp] = XdAction_None;
    SET_BIT_REFFLG_T(recordStp);

    recordBIdMap[GET_ID(recordStp, idIdxPos)] = recordStp;

    this->insRecordDepends(recordStp, bFromDB);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::insRecord(DBA_DYNFLD_STP recordStp, ID_T &outId, bool bDoCopy, bool bFromDB, bool bCheckBeforeInsert)
{
    LockGuard lockGuard(this->m_lock);

    DBA_DYNST_ENUM  objectStEn     = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn       = GET_OBJ_DYNST(objectStEn);
    DICT_ENTITY_STP dictEntityStp  = DBA_GetDictEntitySt(objectEn);
    DBA_DYNFLD_STP  recordToInsStp = recordStp;

    outId = 0;

    if (bCheckBeforeInsert)
    {
        AAAValueGuardBool fromImport(this->m_ddlGenContext.ddlGenAction.m_fromImport, false);

        auto existsRecordStp = this->getRecord(recordStp->getObjectEn(), recordStp, false);
        if (existsRecordStp != nullptr)
        {
            if (bFromDB == false)
            {
                DBA_CopyDynSt(existsRecordStp, recordStp);
            }
            return existsRecordStp;
        }
    }

#ifdef AAATRACEDYNFLD
    {
        DBA_DYNFLD_STP chkRecordStp = nullptr;
        if (bCheckBeforeInsert == false &&
            DBA_isScriptObject(objectEn) == false &&
            (chkRecordStp = this->getRecord(recordStp->getObjectEn(), recordStp, false)) != nullptr)
        {
            SYS_BreakOnDebug();
        }
    }
#endif

    if (bDoCopy)
    {
        recordToInsStp = ALLOC_DYNST(objectStEn);
        COPY_DYNST(recordToInsStp, recordStp, objectStEn);
    }

    if (dictEntityStp != nullptr && 
        dictEntityStp->isId() && 
        DBA_IsAnExtOperationObject(dictEntityStp->objectEn) == false)
    {
        FIELD_IDX_T idIdxPos = dictEntityStp->primKeyTab[0]->progN;

        if (IS_NULLFLD(recordToInsStp, idIdxPos) == TRUE)
        {
            bFromDB = false;

            this->m_newId--;
            if (this->m_recordNewId.insert(std::make_pair(this->m_newId, recordToInsStp)).second == false)
            {
                SYS_BreakOnDebug();
            }

            SET_ID(recordToInsStp, idIdxPos, this->m_newId);
            SET_ID(recordStp, idIdxPos, this->m_newId);

            outId = this->m_newId;
        }
        else
        {
            outId = GET_ID(recordToInsStp, idIdxPos);
        }

        auto &recordByIdMap = this->m_mapIdByObjEnMap[objectEn];
        this->insRecordById(recordByIdMap, recordToInsStp, idIdxPos, bFromDB);

    }
    else
    {
        this->m_mp.ownerDynStp(recordToInsStp);
        this->m_allRecordsMap.insert(std::make_pair(recordToInsStp, XdAction_None));
        SET_BIT_REFFLG_T(recordToInsStp);

        this->insRecordDepends(recordToInsStp, bFromDB);
    }

    if (bFromDB)
    {
        SET_INTERNAL(recordToInsStp, INTERNAL_DB);
    }

    return recordToInsStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insToLoadRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::insToLoadRecord(DBA_DYNFLD_STP recordStp)
{
    this->m_toLoadRecordMap[recordStp->getDynStEn()].insert(recordStp);

    SET_NOTDEFAULTFLG_T(recordStp, 0);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::clearProvidedRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240206
**
*************************************************************************/
void DdlGenDbaAccess::clearProvidedRecord()
{
    this->m_providedKeyMap.clear();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::setProvidedRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240206
**
*************************************************************************/
void DdlGenDbaAccess::setProvidedRecord(DBA_DYNFLD_STP recordStp)
{
    if (recordStp == nullptr)
    {
        return;
    }

    if (this->getDdlGenContext().m_buildBindOptionPtr != nullptr)
    {
        if (this->getDdlGenContext().m_buildBindOptionPtr->isCleanUpProvidedOnly(recordStp->getObjectEn()))
        {
            this->m_providedKeyMap[recordStp->getObjectEn()].insert(this->getKey(recordStp, true));
        }

        auto dictEntityStp = recordStp->getDictEntityStp();
        for (auto& logicalAttribStp : dictEntityStp->logicalTab)
        {
            if (GET_EXTENSION_PTR(recordStp, logicalAttribStp->progN) != nullptr)
            {
                auto extTab = GET_EXTENSION_PTR(recordStp, logicalAttribStp->progN);
                auto extNbr = GET_EXTENSION_NBR(recordStp, logicalAttribStp->progN);

                for (int i = 0; i < extNbr; ++i)
                {
                    this->setProvidedRecord(extTab[i]);
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isProvidedRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240206
**
*************************************************************************/
bool DdlGenDbaAccess::isProvidedRecord(DBA_DYNFLD_STP recordStp)
{
    if (this->getDdlGenContext().m_buildBindOptionPtr != nullptr)
    {
        auto objectIt = this->m_providedKeyMap.find(recordStp->getObjectEn());
        if (objectIt != this->m_providedKeyMap.end())
        {
            return (objectIt->second.find(this->getKey(recordStp, true)) != objectIt->second.end());
        }
    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::addToAllDbRecords
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::addToAllDbRecords(DBA_DYNFLD_STP recordStp)
{
    this->m_allDbRecordsMap.insert(std::make_pair(recordStp, this->m_mp.duplicate(FILEINFO, recordStp)));
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insRecordDepends
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::insRecordDepends(DBA_DYNFLD_STP recordStp, bool bFromDB)
{
    std::string keyStr;

    switch (recordStp->getObjectCst())
    {
        case XdEntityCst:
            break;

        case DictEntityCst:
            break;

        case XdAttribCst:
            this->m_xdEntityAttribBySqlNameMap[GET_ID(recordStp, A_XdAttrib_XdEntityId)][GET_SYSNAME(recordStp, A_XdAttrib_SqlName)] = recordStp;
            this->m_xdAttributesByEntityMap[GET_ID(recordStp, A_XdAttrib_XdEntityId)].push_back(recordStp);

            if (bFromDB)
            {
                COPY_DYNFLD(recordStp, A_XdAttrib, A_XdAttrib_OldProg,
                            recordStp, A_XdAttrib, A_XdAttrib_Prog);
            }
            break;

        case XdEntityFeatureCst:
            this->m_xdEntityFeaturesByEntityMap
                [GET_ID(recordStp, A_XdEntityFeature_XdEntityId)][GET_A_XdEntityFeature_FeatureEn(recordStp)] = recordStp;
            break;

        case XdPermValCst:
            this->m_xdPemValuesByXdAttribNatMap[GET_ID(recordStp, A_XdPermVal_XdAttribId)][GET_ENUM(recordStp, A_XdPermVal_PermValNatEn)] = recordStp;
            this->m_xdPemValuesByXdAttribNameMap[GET_ID(recordStp, A_XdPermVal_XdAttribId)][GET_NAME(recordStp, A_XdPermVal_Name)] = recordStp;
            break;

        case XdLabelCst:
            this->m_xdLabelMap
                [GET_DICT(recordStp, A_XdLabel_EntityDictId)]
            [GET_ID(recordStp, A_XdLabel_ObjId)]
            [GET_DICT(recordStp, A_XdLabel_LangDictId)]
            [GET_A_XdLabel_NatEn(recordStp)] = recordStp;
            break;

        case XdPartitionCst:
            this->m_xdPartitionByEntityMap[GET_ID(recordStp, A_XdPartition_XdEntityId)].push_back(recordStp);
            break;

        case XdAttributeCustoCst:
            this->m_xdAttribCustoByAttribMap[GET_ID(recordStp, A_XdAttributeCusto_XdAttribId)].push_back(recordStp);

            if (IS_NULLFLD(recordStp, A_XdAttributeCusto_XdEntityId))
            {
                auto xdAttributeStp = this->getRecordById(XdAttrib, GET_ID(recordStp, A_XdAttributeCusto_XdAttribId), false);
                if (xdAttributeStp != nullptr)
                {
                    COPY_DYNFLD(recordStp, A_XdAttributeCusto, A_XdAttributeCusto_XdEntityId, xdAttributeStp, A_XdAttrib, A_XdAttrib_XdEntityId);
                }
                else
                {
                    SYS_BreakOnDebug();
                }
            }

            this->m_xdAttribCustoByEntityMap[GET_ID(recordStp, A_XdAttributeCusto_XdEntityId)].push_back(recordStp);
            break;

        case XdIndexCst:
            this->m_xdIndexByEntityMap[GET_ID(recordStp, A_XdIndex_XdEntityId)].push_back(recordStp);
            this->m_xdEntityIndexByEntityMap[GET_ID(recordStp, A_XdIndex_XdEntityId)][GET_SYSNAME(recordStp, A_XdIndex_SqlName)] = recordStp;
            break;

        case XdIndexAttribCst:
            this->m_xdIndexAttribByIndexMap[GET_ID(recordStp, A_XdIndexAttrib_XdIdxId)].push_back(recordStp);
            this->m_xdIndexAttribByBkMap[GET_ID(recordStp, A_XdIndexAttrib_XdIdxId)][GET_ID(recordStp, A_XdIndexAttrib_XdAttribId)] = recordStp;
            break;

        case XdPartitionIndexCst:
            this->m_xdPartitonIndexByIndexMap[GET_ID(recordStp, A_XdPartitionIndex_XdIdxId)].push_back(recordStp);
            break;

        case XdAttributeDocCst:
            this->m_objectByKeyMapMap[recordStp->getObjectEn()][this->getKey(recordStp)] = recordStp;
            this->m_xdHelpDocMap
                [recordStp->getObjectEn()]
                [GET_ID(recordStp, A_XdAttributeDoc_ObjId)] = recordStp;
            break;

        case XdEntityDocCst:
            this->m_objectByKeyMapMap[recordStp->getObjectEn()][this->getKey(recordStp)] = recordStp;
            this->m_xdHelpDocMap
                [recordStp->getObjectEn()]
                [GET_ID(recordStp, A_XdEntityDoc_ObjId)] = recordStp;
            break;

        case XdPermValDocCst:
            this->m_objectByKeyMapMap[recordStp->getObjectEn()][this->getKey(recordStp)] = recordStp;
            this->m_xdHelpDocMap
                [recordStp->getObjectEn()]
                [GET_ID(recordStp, A_XdPermValDoc_ObjId)] = recordStp;
            break;

        case DictAttrCst:
            this->m_dictAttributesMap.insert(std::make_pair(GET_DICT(recordStp, A_DictAttr_DictId), recordStp));
            this->m_dictEntityAttribBySqlNameMap[GET_DICT(recordStp, A_DictAttr_EntityDictId)][GET_SYSNAME(recordStp, A_DictAttr_SqlName)] = recordStp;
            break;

        case DictPermValCst:
            this->m_dictPemValuesByAttribMap[GET_DICT(recordStp, A_DictPermVal_AttribDictId)][GET_ENUM(recordStp, A_DictPermVal_PermValNatEn)] = recordStp;
            break;

        case DictCriterCst:
            this->m_dictEntityCriteriaBySqlNameMap[GET_DICT(recordStp, A_DictCriter_EntDictId)]
                [GET_ENUM(recordStp, A_DictCriter_DynNat)][GET_SYSNAME(recordStp, A_DictCriter_SqlName)] = recordStp;

            this->m_dictCriteriaByKeyMap[GET_ENUM(recordStp, A_DictCriter_DynNat)][this->getKeyFromRecord(recordStp)] = recordStp;
            break;

        case DictSprocCst:
            this->m_dictSprocBySqlNameMap[GET_SYSNAME(recordStp, A_DictSproc_SqlName)][GET_SYSNAME(recordStp, A_DictSproc_Database)] = recordStp;
            break;

        case DictSprocParamCst:
            this->m_dictSprocParamByProcMap[GET_DICT(recordStp, A_DictSprocParam_SprocDictId)][GET_SYSNAME(recordStp, A_DictSprocParam_SqlName)] = recordStp;
            break;

        case DictSprocReturnsCst:
            this->m_dictSprocReturnsByProcMap[GET_DICT(recordStp, A_DictSprocReturns_SprocDictId)][GET_SMALLINT(recordStp, A_DictSprocReturns_Rank)] = recordStp;
            break;

        case DictLabelCst:
            this->m_dictLabelMap
                [GET_DICT(recordStp, A_DictLabel_EntDictId)]
            [GET_ID(recordStp, A_DictLabel_ObjDictId)]
            [GET_DICT(recordStp, A_DictLabel_LangDictId)] = recordStp;
            break;

        case DictEntityConstraintsCst:
            keyStr = SYS_Stringer(GET_DICT(recordStp, A_DictEntityConstraints_RefEntityDictId), "~", 
                                  GET_DICT(recordStp, A_DictEntityConstraints_RefAttribDictId));

            this->m_dictEntityConstrByEntityMap[GET_DICT(recordStp, A_DictEntityConstraints_EntityDictId)][keyStr] = recordStp;
            break;

        case DictDependsCst:
            keyStr = SYS_Stringer(GET_STRING(recordStp, A_DictDepends_SqlName), "~",
                                  GET_STRING(recordStp, A_DictDepends_Database), "~",
                                  GET_STRING(recordStp, A_DictDepends_DepSqlName), "~",
                                  CAST_INT(GET_ENUM(recordStp, A_DictDepends_AccessEn)));

            this->m_dictEntityDependsByKeyMap[keyStr] = recordStp;

            if (strcmp(GET_STRING(recordStp, A_DictDepends_ObjType), "procedure") == 0 &&
                GET_DICT(recordStp, A_DictDepends_DepEntityDictId) == DictEntityCst &&
                (GET_A_DictDepends_AccessEn(recordStp) == DictDependsAccessEn::Returns ||
                 GET_A_DictDepends_AccessEn(recordStp) == DictDependsAccessEn::Insert ||
                 GET_A_DictDepends_AccessEn(recordStp) == DictDependsAccessEn::Update) &&
                 (GET_ENUM(recordStp, A_DictDepends_DynNatEn) == DynType_All ||
                  GET_ENUM(recordStp, A_DictDepends_DynNatEn) == DynType_Short ||
                  GET_ENUM(recordStp, A_DictDepends_DynNatEn) == DynType_UdOnly))
            {
                this->m_dictEntityDependsByDepEntityMap[GET_DICT(recordStp, A_DictDepends_DepObjDictId)].push_back(recordStp);
            }
            break;

        case XdAttribCommentCst:
        {
            keyStr = SYS_Stringer(GET_ID(recordStp, A_XdAttribComment_XdAttribId), "~",
                                  GET_ID(recordStp, A_XdAttribComment_LangDictId), "~",
                                  CAST_INT(GET_ENUM(recordStp, A_XdAttribComment_NatEn)));

            this->m_xdAttributeComnentByKeyMap[keyStr] = recordStp;

            auto xdAttributeStp = this->getRecordById(XdAttrib, GET_ID(recordStp, A_XdAttribComment_XdAttribId), false);

            if (xdAttributeStp != nullptr)
            {
                this->m_xdAttribCommentByEntityMap[GET_ID(xdAttributeStp, A_XdAttrib_XdEntityId)].push_back(recordStp);
            }
            break;
        }

        case DictAttribCommentCst:
        {
            keyStr = SYS_Stringer(GET_ID(recordStp, A_DictAttribComment_AttribDictId), "~",
                                  GET_ID(recordStp, A_DictAttribComment_LangDictId));

            this->m_dictAttributeComnentByKeyMap[keyStr] = recordStp;

            break;
        }

        case DictLangCst:
            this->m_dictLanguageBySqlNameMap[GET_SYSNAME(recordStp, A_DictLang_SqlName)] = recordStp;
            break;

        case ScriptDefCst:
        case HoldingConstraintScriptCst:
        case TradingConstraintScriptCst:
        {
            auto &scptDefAttMap = this->m_scriptDefMap[GET_DICT(recordStp, A_ScriptDef_AttrDictId)];
            auto &scptDefNatMap = scptDefAttMap[static_cast<SCRIPTDEFNAT_ENUM>(GET_ENUM(recordStp, A_ScriptDef_NatEn))];

            scptDefNatMap[GET_SMALLINT(recordStp, A_ScriptDef_Rank)] = recordStp;

            this->m_objectByKeyMapMap[recordStp->getObjectEn()][this->getKey(recordStp)] = recordStp;
            break;
        }

        case BalPosTpCst:
            if (IS_NOTNULL(recordStp, A_DictErrMsg_Error))
            {
                this->m_objectByKeyMapMap[recordStp->getObjectEn()][SYS_Stringer("~", GET_INT(recordStp, A_BalPosTp_Rank))] = recordStp;
            }
        case ApplParamCst:
        case ApplMsgCst:
        case ApplMsgTxtCst:
        case DictErrMsgCst:
        case QuestDefCst:
        default:
            this->m_objectByKeyMapMap[recordStp->getObjectEn()][this->getKey(recordStp)] = recordStp;
            break;
    }

    auto objectEn      = recordStp->getObjectEn();
    auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

    if (dictEntityStp != nullptr)
    {
        if (dictEntityStp->isCode() &&
            IS_NOTNULL(recordStp, dictEntityStp->bkAttr[0]->progN))
        {
            this->m_mapCodeByObjEnMap[objectEn][GET_SYSNAME(recordStp, dictEntityStp->bkAttr[0]->progN)] = recordStp;
        }

        if (dictEntityStp->parentAttrStp != nullptr)
        {
            OBJECT_ENUM subObjectEn = NullEntity;

            if (dictEntityStp->parentAttrStp->linkedAttrDictStp != nullptr &&
                dictEntityStp->parentAttrStp->linkedAttrDictStp->dataTpProgN == DictType)
            {
                DICT_T lnkDictId = GET_DICT(recordStp, dictEntityStp->parentAttrStp->linkedAttrDictStp->progN);
                subObjectEn = DBA_GetObjectEnum(lnkDictId);
            }
            if (recordStp->getDictEntityStp()->isId())
            {
                this->m_mapIdByParentMap[objectEn][subObjectEn][GET_ID(recordStp, dictEntityStp->parentAttrStp->progN)][GET_ID(recordStp, recordStp->getIdIdx())].push_back(recordStp);
            }
            else
            {
                this->m_mapIdByParentMap[objectEn][subObjectEn][GET_ID(recordStp, dictEntityStp->parentAttrStp->progN)][0].push_back(recordStp);
            }
            
        }
        else if (dictEntityStp->bkAttrNbr > 1 &&
                 dictEntityStp->bkAttr[1]->linkedAttrDictStp == dictEntityStp->bkAttr[0] &&
                 dictEntityStp->bkAttr[0]->dataTpProgN == DictType)
        {
            DICT_T lnkDictId = GET_DICT(recordStp, dictEntityStp->bkAttr[0]->progN);
            OBJECT_ENUM subObjectEn = DBA_GetObjectEnum(lnkDictId);

            if (recordStp->getDictEntityStp()->isId())
            {
                this->m_mapIdByParentMap[objectEn][subObjectEn][GET_ID(recordStp, dictEntityStp->bkAttr[1]->progN)][GET_ID(recordStp, recordStp->getIdIdx())].push_back(recordStp);
            }
            else
            {
                this->m_mapIdByParentMap[objectEn][subObjectEn][GET_ID(recordStp, dictEntityStp->bkAttr[1]->progN)][0].push_back(recordStp);
            }
        }
    }
    this->manageDenormAttributes(recordStp);

    if (bFromDB)
    {
        this->addToAllDbRecords(recordStp);
    }

    this->m_existsObjectSet.insert(objectEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::eraseRecordDepends
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::eraseRecordDepends(DBA_DYNFLD_STP recordStp)
{
    switch (recordStp->getObjectCst())
    {
        case DictCriterCst:
            this->m_dictEntityCriteriaBySqlNameMap[GET_DICT(recordStp, A_DictCriter_EntDictId)]
                [GET_ENUM(recordStp, A_DictCriter_DynNat)][GET_SYSNAME(recordStp, A_DictCriter_SqlName)] = nullptr;

            this->m_dictCriteriaByKeyMap[GET_ENUM(recordStp, A_DictCriter_DynNat)][this->getKeyFromRecord(recordStp)] = nullptr;
            break;

        case DictPermValCst:
            this->m_dictPemValuesByAttribMap[GET_DICT(recordStp, A_DictPermVal_AttribDictId)][GET_ENUM(recordStp, A_DictPermVal_PermValNatEn)] = nullptr;
            break;

        default:
            SYS_BreakOnDebug();
    }

    this->m_allRecordsMap.erase(recordStp);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::load()
**
**  Description :   Load all data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::load(const std::string &entityToLoad, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(entityToLoad);
    if (dictEntityStp == nullptr ||
        dictEntityStp->xdStatusEn != XdStatus_Inserted ||
        this->m_isLoadedObjectSet.find(dictEntityStp->objectEn) != this->m_isLoadedObjectSet.end())
    {
        if (dictEntityStp != nullptr &&
            dictEntityStp->xdStatusEn == XdStatus_Untreated)
        {
            this->m_isLoadedObjectSet.insert(dictEntityStp->objectEn);
        }
        return RET_DBA_INFO_NODATA;
    }

    if (dbiConnHelper.isValidAndInit())
    {
        OBJECT_ENUM objectEn = dictEntityStp->objectEn;
        bool bExists = this->m_existsObjectSet.find(objectEn) != this->m_existsObjectSet.end();

        std::string processStr("Loading all data");
        DdlGenMsg  processMsg(&this->m_ddlGenContext, true);

        processMsg.setMsgObjType("Load");
        processMsg.setMsgSqlName(std::string());
        processMsg.setMsgEntitySqlName(entityToLoad);

        processMsg.printMsg(RET_SRV_INFO_RUNNING, processStr);

        DBA_DYNST_ENUM  dynStEn = GET_EDITGUIST(dictEntityStp->objectEn);

        if (dictEntityStp->isId())
        {
            (void)this->m_mapIdByObjEnMap[dictEntityStp->objectEn];
        }
        FIELD_IDX_T codeIdx = Null_Dynfld;
        if (dictEntityStp->isCode())
        {
            (void)this->m_mapCodeByObjEnMap[dictEntityStp->objectEn];
            codeIdx = dictEntityStp->bkAttr[0]->progN;
        }
        

        auto recordBIdMap = this->m_mapIdByObjEnMap.find(dictEntityStp->objectEn);
        auto recordBySqlNameMap = this->m_mapCodeByObjEnMap.find(dictEntityStp->objectEn);

        std::stringstream readStream;

        if (entityToLoad.find("xd_label") == 0)
        {
            if (this->m_isMetaDictLoaded == false)
            {
                readStream
                    << std::endl << "#NO_MULTI_ENTITY"
                    << std::endl << "#NO_SECURED"
                    << std::endl << "#SELECT xd_label all xl"
                    << std::endl << "#FROM"
                    << std::endl << "#WHERE"
                    << std::endl << "xl.entity_dict_id in (1120, 1121, 1124)"
                    << std::endl << "#END";
            }
            else
            {
                readStream
                    << std::endl << "#NO_MULTI_ENTITY"
                    << std::endl << "#NO_SECURED"
                    << std::endl << "#SELECT xd_label all xl"
                    << std::endl << "#FROM"
                    << std::endl << "#WHERE"
                    << std::endl << "xl.entity_dict_id not in (1120, 1121, 1124)"
                    << std::endl << "#END";
            }
        }
        else
        {
            readStream
                << std::endl << "#NO_MULTI_ENTITY"
                << std::endl << "#NO_SECURED"
                << std::endl << "#SELECT " << entityToLoad << " all std"
                << std::endl << "#FROM"
                << std::endl << "#WHERE"
                << std::endl << "#END";
        }

        RequestHelper readRequestHelper(dbiConnHelper);

        readRequestHelper.m_useAlternativeDataServer = EV_UseAlternativeDataSource;
        readRequestHelper.setReadOnly(true);
        readRequestHelper.setDbNameOption(entityToLoad);
        readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());
        readRequestHelper.setCommand(readStream.str());

        size_t rowCount = 0;
        if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
        {
            readRequestHelper.setDynStOutputData(dynStEn);

            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                (ret = readRequestHelper.fetch()) == RET_SUCCEED)
            {
                rowCount++;

                DBA_DYNFLD_STP recordStp = this->allocDynSt(FILEINFO, dynStEn);
                readRequestHelper.readData(recordStp);

                if (bExists == false ||
                    this->getRecord(objectEn, recordStp, false) == nullptr)
                {
                    if (recordBIdMap == this->m_mapIdByObjEnMap.end())
                    {
                        ID_T           recId = 0;
                        this->insRecord(recordStp, recId, false, true);
                    }
                    else
                    {
                        this->insRecordById(recordBIdMap->second, recordStp, dictEntityStp->primKeyTab[0]->progN, true);
                    }

                    if (codeIdx != Null_Dynfld)
                    {
                        recordBySqlNameMap->second.insert(std::make_pair(GET_SYSNAME(recordStp, codeIdx), recordStp));
                    }
                }
            }
        }

        processMsg.printMsg(ret, SYS_Stringer(processStr, ", row count: ", rowCount));

        this->m_isLoadedObjectSet.insert(objectEn);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadByParent()
**
**  Description :   Load all data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadByParent(DICT_ENTITY_STP dictEntityStp, ID_T parentId, OBJECT_ENUM subObjectEn, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    if (dictEntityStp != nullptr &&
        (dictEntityStp->parentAttrStp != nullptr || subObjectEn != NullEntity) &&
        dbiConnHelper.isValidAndInit())
    {
        DBA_DYNST_ENUM  dynStEn = GET_EDITGUIST(dictEntityStp->objectEn);

        RequestHelper readRequestHelper(dbiConnHelper);

        readRequestHelper.m_useAlternativeDataServer = EV_UseAlternativeDataSource;
        readRequestHelper.setReadOnly(true);
        readRequestHelper.setDbNameOption(dictEntityStp->mdSqlName);
        readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());

        std::stringstream readStream;
        readStream
            << std::endl << "#NO_MULTI_ENTITY"
            << std::endl << "#NO_SECURED"
            << std::endl << "#SELECT " << dictEntityStp->mdSqlName << " all std"
            << std::endl << "#FROM"
            << std::endl << "#WHERE";

        if (subObjectEn != NullEntity)
        {
            if (dictEntityStp->bkAttrNbr > 1 &&
                dictEntityStp->bkAttr[0]->dataTpProgN == DictType &&
                dictEntityStp->bkAttr[1]->linkedAttrDictStp != nullptr)
            {
                readStream
                    << std::endl << dictEntityStp->bkAttr[1]->linkedAttrDictStp->sqlName << " = ?";
                readRequestHelper.addNewParamId(GET_OBJECT_CST(subObjectEn));

                readStream
                    << std::endl << dictEntityStp->bkAttr[1]->sqlName << " = ?";
            }
            else
            {
                SYS_BreakOnDebug();

                return RET_DBA_ERR_INVDATA;
            }
        }
        else
        {
            readStream
                << std::endl << dictEntityStp->parentAttrStp->sqlName << " = ?";
        }
        readRequestHelper.addNewParamId(parentId);
        readStream
            << std::endl << "#END";

        readRequestHelper.setCommand(readStream.str());

        size_t rowCount = 0;
        if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
        {
            readRequestHelper.setDynStOutputData(dynStEn);

            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                   (ret = readRequestHelper.fetch()) == RET_SUCCEED)
            {
                rowCount++;

                DBA_DYNFLD_STP recordStp = this->allocDynSt(FILEINFO, dynStEn);
                readRequestHelper.readData(recordStp);

                if (this->getRecord(dictEntityStp->objectEn, recordStp, false) == nullptr)
                {
                    ID_T           recId = 0;
                    this->insRecord(recordStp, recId, false, true);
                }
            }
        }
        this->m_isLoadedByParentMap[dictEntityStp->objectEn][subObjectEn].insert(parentId);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadById()
**
**  Description :   Load all data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadById(OBJECT_ENUM objectEn, ID_T id, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;
    auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

    if (dictEntityStp != nullptr &&
        dictEntityStp->isId() &&
        dbiConnHelper.isValidAndInit())
    {
        DBA_DYNST_ENUM  dynStEn = GET_EDITGUIST(dictEntityStp->objectEn);

        std::stringstream readStream;

        readStream
            << std::endl << "#NO_MULTI_ENTITY"
            << std::endl << "#NO_SECURED"
            << std::endl << "#SELECT " << dictEntityStp->mdSqlName << " all std"
            << std::endl << "#FROM"
            << std::endl << "#WHERE";
        readStream
            << std::endl << dictEntityStp->primKeyTab[0]->sqlName << " = ?"
            << std::endl << "#END";

        RequestHelper readRequestHelper(dbiConnHelper);

        readRequestHelper.m_useAlternativeDataServer = EV_UseAlternativeDataSource;
        readRequestHelper.setReadOnly(true);
        readRequestHelper.setDbNameOption(dictEntityStp->mdSqlName);
        readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());
        readRequestHelper.setCommand(readStream.str());

        readRequestHelper.addNewParamId(id);

        size_t rowCount = 0;
        if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
        {
            readRequestHelper.setDynStOutputData(dynStEn);

            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                   (ret = readRequestHelper.fetch()) == RET_SUCCEED)
            {
                rowCount++;

                DBA_DYNFLD_STP recordStp = this->allocDynSt(FILEINFO, dynStEn);
                readRequestHelper.readData(recordStp);

                ID_T           recId = 0;
                this->insRecord(recordStp, recId, false, true, true);
            }
        }
    }
    this->m_isLoadedByIdMap[dictEntityStp->objectEn].insert(id);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadByCode()
**
**  Description :   Load all data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadByCode(OBJECT_ENUM objectEn, const std::string &code, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;
    auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

    if (dictEntityStp != nullptr &&
        dictEntityStp->isCode() &&
        dbiConnHelper.isValidAndInit())
    {
        DBA_DYNST_ENUM  dynStEn = GET_EDITGUIST(dictEntityStp->objectEn);

        std::stringstream readStream;

        readStream
            << std::endl << "#NO_MULTI_ENTITY"
            << std::endl << "#NO_SECURED"
            << std::endl << "#SELECT " << dictEntityStp->mdSqlName << " all std"
            << std::endl << "#FROM"
            << std::endl << "#WHERE";
        readStream
            << std::endl << dictEntityStp->bkAttr[0]->sqlName << " = ?"
            << std::endl << "#END";

        RequestHelper readRequestHelper(dbiConnHelper);

        readRequestHelper.m_useAlternativeDataServer = EV_UseAlternativeDataSource;
        readRequestHelper.setReadOnly(true);
        readRequestHelper.setDbNameOption(dictEntityStp->mdSqlName);
        readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());
        readRequestHelper.setCommand(readStream.str());

        readRequestHelper.addNewParamString(code, CodeType);

        size_t rowCount = 0;
        if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
        {
            readRequestHelper.setDynStOutputData(dynStEn);

            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                   (ret = readRequestHelper.fetch()) == RET_SUCCEED)
            {
                rowCount++;

                DBA_DYNFLD_STP recordStp = this->allocDynSt(FILEINFO, dynStEn);
                readRequestHelper.readData(recordStp);

                ID_T           recId = 0;
                this->insRecord(recordStp, recId, false, true);
            }
        }
    }
    this->m_isLoadedByCodeMap[dictEntityStp->objectEn].insert(code);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getDdlGenContext()
**
**  Description :   
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231103
**
*************************************************************************/
DdlGenContext &DdlGenDbaAccess::getDdlGenContext()
{
    return this->m_ddlGenContext;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadMetaDict()
**
**  Description :   Load meta-dictionary data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadMetaDict()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_isMetaDictLoaded == false)
    {
        std::string processStr("Loading meta-dictionary data");

        if (this->getDdlGenContext().ddlGenAction.m_fromImport == false)
        {
            /* Flush and clear the previous data */
            (void)this->flushData();
            this->clear();
        }

        DdlGenMsg  processMsg(&this->m_ddlGenContext, true);
        processMsg.setMsgObjType(std::string());
        processMsg.setMsgSqlName(std::string());
        processMsg.setMsgEntitySqlName(std::string());

        processMsg.printMsg(RET_SRV_INFO_RUNNING, processStr);

        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

        if (dbiConnHelper.isValidAndInit())
        {
            if (this->m_ddlGenContext.optimLevelEn != DdlGenContext::OptimLevel::Full &&
                this->m_ddlGenContext.ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable)
            {
                dbiConnHelper.beginTransaction();

                if (this->m_ddlGenContext.ddlGenAction.m_bSingleEntity)
                {
                    for (auto shXdEntityIt = this->m_ddlGenContext.ddlGenAction.m_shXdEntityVector.begin(); 
                         shXdEntityIt != this->m_ddlGenContext.ddlGenAction.m_shXdEntityVector.end();
                         ++shXdEntityIt)
                    {
                        if ((ret = dbiConnHelper.dbaCopy(XdAttrib, DBA_ROLE_UDT, (*shXdEntityIt))) != RET_SUCCEED)
                        {
                            ddlGenConnGuard.getDbiConn().sendAllMsg();
                            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Copy table information");
                            dbiConnHelper.rollback();

                            return(RET_DBA_ERR_NODATA);
                        }
                    }
                }
                else
                {
                    if ((ret = dbiConnHelper.dbaCopy(XdAttrib, DBA_ROLE_UDT, nullptr)) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Copy table information");
                        dbiConnHelper.rollback();

                        return(RET_DBA_ERR_NODATA);
                    }
                }

                dbiConnHelper.commit();
            }

            this->load("xd_entity", dbiConnHelper);
            this->load("xd_attribute", dbiConnHelper);
            this->load("xd_entity_feature", dbiConnHelper);
            this->load("xd_perm_value", dbiConnHelper);
            this->load("xd_partition", dbiConnHelper);
            this->load("xd_attribute_custo", dbiConnHelper);

            this->load("xd_index", dbiConnHelper);
            this->load("xd_index_attrib", dbiConnHelper);

            this->load("dict_entity", dbiConnHelper);
            this->load("dict_attribute", dbiConnHelper);
            this->load("dict_criteria", dbiConnHelper);
            this->load("dict_perm_value", dbiConnHelper);
            this->load("dict_datatype", dbiConnHelper);

            this->load("dict_segment", dbiConnHelper);
            this->load("dict_database", dbiConnHelper);

            this->load("dict_language", dbiConnHelper);
            this->load("xd_label", dbiConnHelper);

            if (this->m_ddlGenContext.ddlGenAction.m_bSingleEntity)
            {
                this->load("dict_depends", dbiConnHelper);
            }

            DdlGenDbi ddlGenDbi(DdlObj_Sql, this->m_ddlGenContext, nullptr, nullptr, TargetTable_Main);

            auto &allDbSet = this->m_ddlGenContext.getAllDbSet();
                  
            this->m_allDdlObjLoadedSet.insert(DdlObj_PrimaryKey);
            this->m_allDdlObjLoadedSet.insert(DdlObj_SProc);
            this->m_allDdlObjLoadedSet.insert(DdlObj_Func);

            for (auto it = allDbSet.begin(); it != allDbSet.end(); ++it)
            {
                /* PMSTA-64533 - VTBR - 20250122 */
                if (this->m_ddlGenContext.ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_ReportFmt)
                {
                    /* For Report Format Structure Creation, no need to load meta-dict from TSLTEMPDB and TSLPERMDB */
                    if ((*it) == this->m_ddlGenContext.getPermTslDbName() ||
                        (*it) == this->m_ddlGenContext.getTempTslDbName())
                    {
                        continue;
                    }
                }

                for (auto ddlObjIt = this->m_allDdlObjLoadedSet.begin(); ddlObjIt != this->m_allDdlObjLoadedSet.end(); ++ddlObjIt)
                {
                    auto& allDdlObjMap = this->m_allDdlObjDefMap[(*ddlObjIt)];

                    ddlGenDbi.getAllDdlObjListFromDb(allDdlObjMap, (*it), std::string(), std::string(), (*ddlObjIt));
                }
            }

            this->m_allDdlObjLoadedSet.insert(DdlObj_SpecSProc);

            this->m_isLoadedObjectSet.insert(NullEntity);
            this->m_isMetaDictLoaded = true;
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            processMsg.printMsg(ret, processStr.append(" done!"));
        }
        else
        {
            processMsg.printMsg(ret, processStr.append(" failed!"));
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadExtended()
**
**  Description :   Load all extended data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadExtended()
{
    RET_CODE ret = RET_SUCCEED;

    this->loadMetaDict();

    if (this->m_isExtendedLoaded == false)
    {
        std::string processStr("Loading additional data");

        this->m_ddlGenContext.printMsg(RET_SRV_INFO_RUNNING, processStr);

        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

        if (dbiConnHelper.isValidAndInit())
        {
            this->load("xd_partition_index", dbiConnHelper);
            this->load("dict_criteria", dbiConnHelper);

            if (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt)
            {
                this->load("dict_sproc", dbiConnHelper);
                this->load("dict_sproc_param", dbiConnHelper);
                this->load("dict_sproc_returns", dbiConnHelper);
                this->load("xd_attribute_comment", dbiConnHelper);
                this->load("dict_attribute_comment", dbiConnHelper);
                this->load("dict_depends", dbiConnHelper);
                this->load("table_modif_stat", dbiConnHelper);
            }

            if (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_Questionnaire)
            {
                this->load("script_definition", dbiConnHelper);
                this->load("dict_label", dbiConnHelper);
                this->load("questionnaire_def", dbiConnHelper);
            }

            this->m_isExtendedLoaded = true;
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            this->m_ddlGenContext.printMsg(ret, processStr.append(" done!"));
        }
        else
        {
            this->m_ddlGenContext.printMsg(ret, processStr.append(" failed!"));
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::load()
**
**  Description :   Load data of one entity
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::load(DBA_DYNFLD_STP shXdEntityStp, bool bForceLoad)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->isLoaded(shXdEntityStp) == false || bForceLoad)
    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

        DBA_DYNFLD_STP  *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
        int             rows[] = { 0, 0, 0, 0, 0, 0 };
        std::string          sqlName = GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName);

        if (dbiConnHelper.isValidAndInit())
        {
            std::vector<DBA_DYNFLD_STP> xdAttribVector;

            if (this->m_ddlGenContext.ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt)
            {
                DBA_DYNFLD_STP xdEntityStp = this->allocDynSt(FILEINFO, A_XdEntity);

                DBA_GetXdFromFmt(dbiConnHelper, sqlName.c_str(), xdEntityStp, xdAttribVector, this->m_mp);

                ID_T entityId = 0;
                this->insRecord(xdEntityStp, entityId);
                for (auto it = xdAttribVector.begin(); it != xdAttribVector.end(); ++it)
                {
                    ID_T attribId = 0;
                    SET_ID((*it), A_XdAttrib_XdEntityId, entityId);

                    this->insRecord((*it), attribId);
                }
            }
            else
            {
                if (this->m_ddlGenContext.ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable && bForceLoad == true)
                {
                    dbiConnHelper.beginTransaction();

                    if ((ret = dbiConnHelper.dbaCopy(XdAttrib,
                                                     DBA_ROLE_UDT,
                                                     shXdEntityStp)) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Copy table information");
                        dbiConnHelper.rollback();

                        return(RET_DBA_ERR_NODATA);
                    }
                    dbiConnHelper.commit();
                }

                if ((ret = dbiConnHelper.dbaMultiSelect(XdEntity, UNUSED, shXdEntityStp, data, rows)) != RET_SUCCEED ||
                    rows[0] == 0)
                {
                    if (this->m_ddlGenContext.ddlGenAction.isBootStrapLevel() == false)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving System tables information");
                    }
                    return(RET_DBA_ERR_NODATA);
                }

                int dataPos = 0;

                if (rows[dataPos] == 1)
                {
                    ID_T recId = 0;

                    while (dataPos < (sizeof(rows) / sizeof(int)))
                    {
                        if (rows[dataPos] > 0)
                        {
                            for (int i = 0; i < rows[dataPos]; i++)
                            {
                                auto existsRecStp = this->insRecord(data[dataPos][i], recId, false, false, true);
                                if (existsRecStp != data[dataPos][i])
                                {
                                    FREE_DYNST(data[dataPos][i], data[dataPos][i]->getDynStEn());
                                }
                            }
                            FREE(data[dataPos]);
                        }
                        dataPos++;
                    }

                    this->m_isLoadedXdEntitySet.insert(sqlName);
                }
                else
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving System tables information");
                    return(RET_DBA_ERR_NODATA);
                }
            }
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving System tables information");
            return(RET_DBA_ERR_NODATA);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadXdLabels()
**
**  Description :   
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::loadXdLabels(DBA_DYNFLD_STP shXdEntityStp, bool bForceLoad)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->isLoaded(shXdEntityStp) == false || bForceLoad)
    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

        DBA_DYNFLD_STP  *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
        int             rows[] = { 0, 0, 0 };
        std::string          sqlName = GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName);

        if (dbiConnHelper.isValidAndInit())
        {
            if ((ret = dbiConnHelper.dbaMultiSelect(XdLabel, UNUSED, shXdEntityStp, data, rows)) != RET_SUCCEED ||
                rows[0] == 0)
            {
                ddlGenConnGuard.getDbiConn().sendAllMsg();
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving labels information");
                return(RET_DBA_ERR_NODATA);
            }
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving labels information");
            return(RET_DBA_ERR_NODATA);
        }

        int dataPos = 0;

        if (rows[dataPos] == 1)
        {
            ID_T recId = 0;

            while (dataPos < (sizeof(rows) / sizeof(int)))
            {
                if (rows[dataPos] > 0)
                {
                    for (int i = 0; i < rows[dataPos]; i++)
                    {
                        this->insRecord(data[dataPos][i], recId);
                    }
                    FREE(data[dataPos]);
                }
                dataPos++;
            }
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving labels information");
            return(RET_DBA_ERR_NODATA);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getIdFromKey()
**
**  Description :   
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
ID_T DdlGenDbaAccess::getIdFromKey(const std::string &key, OBJECT_ENUM objectEn, OBJECT_ENUM realObjectEn)
{
    MemoryPool      mp;

    DBA_DYNST_ENUM  dynStEn = GET_ADMINGUIST(objectEn);
    DBA_DYNFLD_STP  searchRecordStp = mp.allocDynst(FILEINFO, dynStEn);
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    std::vector<std::string> tokens;
    DdlGen::tokenizeStr(tokens, key, ";");

    if (objectEn == XdAttrib && realObjectEn == DictCriter)
    {
        if (tokens.size() == 2)
        {
            SET_ID(searchRecordStp, S_XdAttrib_XdEntityId, this->getIdFromKey(tokens[0], XdEntity, realObjectEn));
            SET_SMALLINT(searchRecordStp, S_XdAttrib_ShortIdx, CAST_SHORT(atoi(tokens[1].c_str())));
        }
        else
        {
            return 0;
        }
    }
    else
    {
        size_t tokenPos = 0;

        for (int bkPos = 0; bkPos < dictEntityStp->bkAttrNbr; ++bkPos)
        {
            if (bkPos < CAST_INT(tokens.size()))
            {
                switch (dictEntityStp->bkAttr[bkPos]->dataTpProgN)
                {
                    case IdType:
                    case DictType:
                    {
                        DICT_ENTITY_STP refDictEntityStp = dictEntityStp->bkAttr[bkPos]->refDictEntityStp;
                        std::string          subRefKey;
                        for (int i = 0; i < refDictEntityStp->bkAttrNbr; i++)
                        {
                            subRefKey += tokens[tokenPos++] + ";";
                        }
                        SET_ID(searchRecordStp, dictEntityStp->bkAttr[bkPos]->shortIdx, this->getIdFromKey(subRefKey, refDictEntityStp->objectEn, realObjectEn));
                        break;
                    }

                    case SysnameType:
                        SET_SYSNAME(searchRecordStp, dictEntityStp->bkAttr[bkPos]->shortIdx, tokens[tokenPos++].c_str());
                        break;

                    case CodeType:
                        if (dictEntityStp->objectEn == DictLang)
                        {
                            SET_SYSNAME(searchRecordStp, S_DictLang_SqlName, tokens[tokenPos++].c_str());
                        }
                        else
                        {
                            SET_CODE(searchRecordStp, dictEntityStp->bkAttr[bkPos]->shortIdx, tokens[tokenPos++].c_str());
                        }
                        break;

                    case EnumType:
                        SET_ENUM(searchRecordStp, dictEntityStp->bkAttr[bkPos]->shortIdx, CAST_SHORT(atoi(tokens[tokenPos++].c_str())));
                        break;

                    default:
                        SYS_BreakOnDebug();
                }
            }
            else
            {
                return 0;
            }
        }
    }

    DBA_DYNFLD_STP mainRecordStp = this->getRecord(objectEn, searchRecordStp);

    if (mainRecordStp != nullptr)
    {
        return GET_ID(mainRecordStp, dictEntityStp->primKeyTab[0]->progN);
    }

    return 0;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getKeyFromId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::string DdlGenDbaAccess::getKeyFromId(ID_T id, DICT_T entityDictId)
{
    std::string key;

    OBJECT_ENUM objectEn = NullEntity;
    DBA_GetObjectEnum(entityDictId, &objectEn);

    if (objectEn == NullEntity)
    {
        return std::string();
    }

    DBA_DYNFLD_STP recordStp = this->getRecordById(objectEn, id, true);

    if (recordStp != nullptr)
    {
        return this->getKeyFromRecord(recordStp);
    }
    else if (objectEn == DictLang)
    {
        recordStp = this->m_mp.allocDynst(FILEINFO, A_DictLang);
        DBA_GetDictLangStruct(id, recordStp);

        ID_T newId = 0;
        this->insRecord(recordStp, newId, false, true);

        key = GET_CODE(recordStp, A_DictLang_Cd);
    }
    else
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_INVDATA, SYS_Stringer("Unknown record: entity_dict_id=", entityDictId, ", id =", id));
    }

    return key;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getKeyFromId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::string DdlGenDbaAccess::getKeyFromRecord(DBA_DYNFLD_STP recordStp)
{
    std::string key;

    if (recordStp != nullptr)
    {
        OBJECT_ENUM     objectEn      = recordStp->getObjectEn();
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp != nullptr && dictEntityStp->isCode())
        {
            key = dictEntityStp->getCode(recordStp);
        }
        else if (objectEn == XdAttrib)
        {
            DICT_T xdEntityDictId = 0;
            DBA_GetDictId(XdEntity, &xdEntityDictId);

            if (GET_FLAG(recordStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
            {
                key = SYS_Stringer(this->getKeyFromId(GET_ID(recordStp, A_XdAttrib_XdEntityId), xdEntityDictId),
                                   ";",
                                   GET_SMALLINT(recordStp, A_XdAttrib_ShortIdx));
            }
            else
            {
                key = SYS_Stringer(this->getKeyFromId(GET_ID(recordStp, A_XdAttrib_XdEntityId), xdEntityDictId),
                                   ";",
                                   GET_SYSNAME(recordStp, A_XdAttrib_SqlName));
            }
        }
        else if (objectEn == XdPermVal)
        {
            DICT_T xdAttribDictId = 0;
            DBA_GetDictId(XdAttrib, &xdAttribDictId);

            key = SYS_Stringer(this->getKeyFromId(GET_ID(recordStp, A_XdPermVal_XdAttribId), xdAttribDictId),
                               ";",
                               static_cast<int>(GET_ENUM(recordStp, A_XdPermVal_PermValNatEn)));
        }
        else if (objectEn == ApplMsg)
        {
            key = SYS_Stringer(GET_CODE(recordStp, A_ApplMsg_Cd),
                               ";",
                               static_cast<int>(GET_ENUM(recordStp, A_ApplMsg_NatEn)));
        }
        else if (objectEn == DictCriter)
        {
            DICT_T entityDictId = 0;
            DBA_GetDictId(DictEntity, &entityDictId);

            key = SYS_Stringer(this->getKeyFromId(GET_ID(recordStp, A_DictCriter_EntDictId), entityDictId),
                               ";",
                               GET_SMALLINT(recordStp, A_DictCriter_Prog));
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }

    return key;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadHelpDoc()
**
**  Description :   Load all help document from database
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbaAccess::loadHelpDoc()
{
    LockGuard lockGuard(this->m_lock);
    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    std::string processStr("Loading Help Document");
    DdlGenMsg  processMsg(&this->m_ddlGenContext, true);

    processMsg.setMsgObjType("Help Document");
    processMsg.setMsgSqlName(std::string());
    processMsg.setMsgEntitySqlName(std::string());

    processMsg.printMsg(RET_SRV_INFO_RUNNING, processStr);

    this->load("xd_entity_doc", dbiConnHelper);
    this->load("xd_attribute_doc", dbiConnHelper);
    this->load("xd_perm_val_doc", dbiConnHelper);

}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadLabels()
**
**  Description :   Load all labels from files
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::loadLabels()
{
    if (this->m_isMetaDictLoaded == false ||
        this->m_isExtendedLoaded == false)
    {
        return;
    }

    std::string processStr("Loading labels");
    DdlGenMsg  processMsg(&this->m_ddlGenContext, true);

    processMsg.setMsgObjType("Label");
    processMsg.setMsgSqlName(std::string());
    processMsg.setMsgEntitySqlName(std::string());

    processMsg.printMsg(RET_SRV_INFO_RUNNING, processStr);

    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

        if (dbiConnHelper.isValidAndInit())
        {
            this->m_isLoadedObjectSet.erase(XdLabel);

            this->load("dict_language", dbiConnHelper);
            this->load("xd_label", dbiConnHelper);
            this->load("dict_label", dbiConnHelper);
        }
    }

    MemoryPool           mp;

    std::map<ID_T, std::string> langMap;
    for (auto it = this->m_dictLanguageBySqlNameMap.begin(); it != this->m_dictLanguageBySqlNameMap.end(); ++it)
    {
        langMap[GET_ID(it->second, A_DictLang_Id)] = it->first;
    }

    CURRENTCHARSETCODE_ENUM charSet = CurrentCharsetCode_UTF8;
    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charSet);

    DdlGenCfgFile labelCfgFile(this->m_ddlGenContext, CfgFileType_Label);
    labelCfgFile.loadCfgFile();

    for (auto entityStrIt = labelCfgFile.m_allLabelsMap.begin(); entityStrIt != labelCfgFile.m_allLabelsMap.end(); ++entityStrIt)
    {
        OBJECT_ENUM  objectEn     = NullEntity;
        OBJECT_ENUM  realObjectEn = NullEntity;

        if (entityStrIt->first == "ENTITY")
        {
            objectEn = XdEntity;
            realObjectEn = XdEntity;
        }
        else if (entityStrIt->first == "ATTRIBUTE")
        {
            objectEn = XdAttrib;
            realObjectEn = XdAttrib;
        }
        else if (entityStrIt->first == "CRITERIA")
        {
            objectEn = XdAttrib;
            realObjectEn = DictCriter;
        }
        else if (entityStrIt->first == "FUNCTION")
        {
            objectEn = DictFct;
            realObjectEn = DictFct;
        }
        else if (entityStrIt->first == "LANGUAGE")
        {
            objectEn = DictLang;
            realObjectEn = DictLang;
        }
        else if (entityStrIt->first == "MESSAGE")
        {
            objectEn = ApplMsg;
            realObjectEn = ApplMsg;
        }
        else if (entityStrIt->first == "PERMITTED VALUE")
        {
            objectEn = XdPermVal;
            realObjectEn = XdPermVal;
        }
        else
        {
            SYS_BreakOnDebug();
            continue;
        }

        if (this->m_isLoadedObjectSet.find(realObjectEn) == this->m_isLoadedObjectSet.end())
        {
            continue;
        }

        auto   dictEntityStp = DBA_GetDictEntitySt(objectEn);
        DICT_T entityDictId = dictEntityStp->entDictId;

        for (auto langIt = entityStrIt->second.begin(); langIt != entityStrIt->second.end(); ++langIt)
        {
            for (auto labelIt = langIt->second.begin(); labelIt != langIt->second.end(); ++labelIt)
            {
                auto  xdLabelStp = mp.allocDynst(FILEINFO, A_XdLabel);

                DBA_SetDfltEntityFld(xdLabelStp);

                SET_DICT(xdLabelStp, A_XdLabel_EntityDictId, entityDictId);
                SET_DICT(xdLabelStp, A_XdLabel_LangDictId, labelIt->m_languageDictId);
                SET_ENUM(xdLabelStp, A_XdLabel_NatEn, labelIt->m_natureEn);
                SET_ENUM(xdLabelStp, A_XdLabel_XdActionEn, XdAction_ToInsert);

                if (labelIt->m_isoLabel != nullptr)
                {
                    SET_NAME(xdLabelStp, A_XdLabel_Name, labelIt->m_isoLabel);
                }
                else if (labelIt->m_uniLabel != nullptr &&
                         GET_CTYPE(GET_FLD_DTP(xdLabelStp, A_XdLabel_Name)) == UniCharPtrCType)
                {
                    SET_UNAME(xdLabelStp, A_XdLabel_Name, labelIt->m_uniLabel);
                }
                else
                {
                    SET_NAME(xdLabelStp, A_XdLabel_Name, labelIt->m_label.c_str());
                }

                auto& xdLabelInTab = this->m_xdLabelByKeyMap
                    [GET_DICT(xdLabelStp, A_XdLabel_EntityDictId)]
                    [labelIt->m_key]
                    [GET_DICT(xdLabelStp, A_XdLabel_LangDictId)]
                    [GET_A_XdLabel_NatEn(xdLabelStp)];

                if (xdLabelInTab == nullptr)
                {
                    xdLabelInTab = xdLabelStp;
                    this->m_mp.owner(xdLabelStp);
                    mp.remove(xdLabelStp);
                }
                else
                {
                    COPY_DYNFLD(xdLabelInTab, A_XdLabel, A_XdLabel_Name, xdLabelStp, A_XdLabel, A_XdLabel_Name);
                }

                if (objectEn == XdEntity || objectEn == XdAttrib || objectEn == XdPermVal)
                {
                    ID_T xdObjectId = this->getIdFromKey(labelIt->m_key, objectEn, realObjectEn);

                    if (xdObjectId == 0)
                    {
                        if (this->m_ddlGenContext.ddlGenAction.m_bSingleEntity == false &&
                            (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable ||
                             this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_Label))
                        {
                            std::stringstream msg;
                            msg << "Label defined on unknown object, Entity: " << dictEntityStp->nameStr
                                << ", Language: " << langMap[GET_DICT(xdLabelInTab, A_XdLabel_LangDictId)]
                                << ", Key: " << labelIt->m_key
                                << ", Label: ";

                            if (IS_STRINGFLD(A_XdLabel, A_XdLabel_Name) == TRUE)
                            {
                                msg << GET_STRING(xdLabelInTab, A_XdLabel_Name);
                            }
                            else
                            {
                                char* ptr = NULL;
                                ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(xdLabelInTab, A_XdLabel_Name), -1, &ptr, NULL);
                                msg << ptr;
                                FREE(ptr);
                            }

                            processMsg.printMsg(RET_DBA_INFO_EXIST, msg.str());
                        }
                    }
                    else
                    {
                        SET_ID(xdLabelInTab, A_XdLabel_ObjId, xdObjectId);
                        this->insUpdDelRecord(Insert, XdLabel, UNUSED, xdLabelInTab, false);
                    }
                }
            }
        }
    }

    processMsg.printMsg(RET_SUCCEED, "done");
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::processLabels()
**
**  Description :   Process all labels not in meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230215
**
*************************************************************************/
void DdlGenDbaAccess::processLabels()
{
    std::string processStr("Processing labels");
    DdlGenMsg  processMsg(&this->m_ddlGenContext, true);

    processMsg.setMsgObjType("Label");
    processMsg.setMsgSqlName(std::string());
    processMsg.setMsgEntitySqlName(std::string());

    processMsg.printMsg(RET_SRV_INFO_RUNNING, processStr);

    MemoryPool          mp;
    auto                requestHelperPtr = this->m_ddlGenContext.getRequestHelper();
    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);

    if (requestHelperPtr == nullptr)
    {
        requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), this->m_ddlGenContext);
        mp.ownerObject(requestHelperPtr);
    }

    std::map<ID_T, std::string> langMap;
    for (auto it = this->m_dictLanguageBySqlNameMap.begin(); it != this->m_dictLanguageBySqlNameMap.end(); ++it)
    {
        langMap[GET_ID(it->second, A_DictLang_Id)] = it->first;
    }

    DICT_T dictCriteriaDictId = 0;
    DBA_GetDictId(DictCriter, &dictCriteriaDictId);

    for (auto entityIt = this->m_xdLabelByKeyMap.begin(); entityIt != this->m_xdLabelByKeyMap.end(); ++entityIt)
    {
        auto dictEntityStp = DBA_GetDictEntityByDictId(entityIt->first);
        if (dictEntityStp != nullptr)
        {
            if ((this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_Label &&
                 this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_AllTable) ||
                this->m_ddlGenContext.ddlGenAction.m_fromImport)
            {
                for (auto objectIt = entityIt->second.begin(); objectIt != entityIt->second.end(); ++objectIt)
                {
                    for (auto languageIt = objectIt->second.begin(); languageIt != objectIt->second.end(); ++languageIt)
                    {
                        for (auto it = languageIt->second.begin(); it != languageIt->second.end(); ++it)
                        {
                            if (GET_ENUM(it->second, A_XdLabel_XdActionEn) != XdAction_None)
                            {
                                auto dbRecordIt = this->m_allDbRecordsMap.find(it->second);
                                if (dbRecordIt != this->m_allDbRecordsMap.end())
                                {
                                    COPY_DYNFLD(it->second, A_XdLabel, A_XdLabel_ObjId, dbRecordIt->second, A_XdLabel, A_XdLabel_ObjId);
                                    COPY_DYNFLD(it->second, A_XdLabel, A_XdLabel_XdStatusEn, dbRecordIt->second, A_XdLabel, A_XdLabel_XdStatusEn);
                                    COPY_DYNFLD(it->second, A_XdLabel, A_XdLabel_BuildDate, dbRecordIt->second, A_XdLabel, A_XdLabel_BuildDate);

                                    SET_ENUM(it->second, A_XdLabel_XdActionEn, XdAction_None);
                                    requestHelperPtr->dbaCall(Update,
                                                              XdLabel,
                                                              DBA_ROLE_STATUS,
                                                              it->second);
                                }
                            }
                        }
                    }
                }

                continue;
            }

            if ((dictEntityStp->objectEn == XdEntity ||
                 dictEntityStp->objectEn == XdAttrib ||
                 dictEntityStp->objectEn == XdPermVal))
            {
                continue;
            }

            OBJECT_ENUM targetObjectEn = NullEntity;
            FIELD_IDX_T targetObjIdIdx = Null_Dynfld;

            switch (GET_OBJECT_CST(dictEntityStp->objectEn))
            {
                case XdEntityCst:
                    targetObjectEn = DictEntity;
                    targetObjIdIdx = A_XdEntity_EntityDictId;
                    break;

                case XdAttribCst:
                    targetObjectEn = DictAttr;
                    targetObjIdIdx = A_XdAttrib_AttribDictId;
                    break;

                case XdPermValCst:
                    targetObjectEn = DictPermVal;
                    break;

                case DictFctCst:
                    targetObjectEn = DictFct;
                    targetObjIdIdx = A_DictFct_DictId;
                    break;

                case DictLangCst:
                    targetObjectEn = DictLang;
                    targetObjIdIdx = A_DictLang_Id;
                    break;

                case ApplMsgCst:
                    targetObjectEn = ApplMsg;
                    targetObjIdIdx = A_ApplMsg_Id;
                    break;

                default:
                    SYS_BreakOnDebug();
            }

            auto   targetDictEntityStp = DBA_GetDictEntitySt(targetObjectEn);
            DICT_T targetDictId = targetDictEntityStp->entDictId;

            for (auto objectIt = entityIt->second.begin(); objectIt != entityIt->second.end(); ++objectIt)
            {
                ID_T objectId = 0;
                for (auto languageIt = objectIt->second.begin(); languageIt != objectIt->second.end(); ++languageIt)
                {
                    XD_STATUS_ENUM xdStatusEn = XdStatus_Deleted;

                    auto xdLabelIt = languageIt->second.end();
                    while (--xdLabelIt != languageIt->second.begin() &&
                           GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) != XdAction_ToInsert &&
                           (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) != XdAction_None ||
                            GET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn) != XdStatus_Inserted))
                    { }

                    if (objectId == 0)
                    {
                        if (IS_NULLFLD(xdLabelIt->second, A_XdLabel_ObjId))
                        {
                            objectId = this->getIdFromKey(objectIt->first, 
                                                          dictEntityStp->objectEn, 
                                                          (dictEntityStp->objectEn == XdAttrib ? DictCriter : dictEntityStp->objectEn));
                        }
                        else
                        {
                            objectId = GET_ID(xdLabelIt->second, A_XdLabel_ObjId);
                        }
                    }

                    if (objectId != 0)
                    {
                        SET_ID(xdLabelIt->second, A_XdLabel_ObjId, objectId);

                        auto recordStp = this->getRecordById(dictEntityStp->objectEn, objectId, true);

                        if (recordStp != nullptr)
                        {
                            if (targetObjectEn == ApplMsg)
                            {
                                DBA_DYNFLD_STP   applMsgTxtStp = requestHelperPtr->allocDynSt(FILEINFO, A_ApplMsgTxt);

                                COPY_DYNFLD(applMsgTxtStp, A_ApplMsgTxt, A_ApplMsgTxt_MsgId,
                                            recordStp, recordStp->getDynStEn(), targetObjIdIdx);
                                COPY_DYNFLD(applMsgTxtStp, A_ApplMsgTxt, A_ApplMsgTxt_LangDictId,
                                            xdLabelIt->second, A_XdLabel, A_XdLabel_LangDictId);
                                COPY_DYNFLD(applMsgTxtStp, A_ApplMsgTxt, A_ApplMsgTxt_MsgTxt,
                                            xdLabelIt->second, A_XdLabel, A_XdLabel_Name);


                                bool bCheck = true;

                                if (IS_STRINGFLD(A_XdLabel, A_XdLabel_Name) == TRUE)
                                {
                                    if (strstr(GET_STRING(xdLabelIt->second, A_XdLabel_Name), "\"") != nullptr)
                                    {
                                        bCheck = false;
                                    }
                                }
                                else
                                {
                                    if (u_strstr(GET_USTRING(xdLabelIt->second, A_XdLabel_Name), u"\"") != nullptr)
                                    {
                                        bCheck = false;
                                    }
                                }

                                if (bCheck)
                                {
                                    DBA_ACTION_ENUM actionDone = NullAction;
                                    requestHelperPtr->insUpdRecord(applMsgTxtStp, actionDone, recordStp);

                                    xdStatusEn = XdStatus_Inserted;
                                }
                                else
                                {
                                    std::stringstream msg;
                                    msg << "The double quote character is not allowed in the message texts: ";

                                    if (IS_STRINGFLD(A_XdLabel, A_XdLabel_Name) == TRUE)
                                    {
                                        msg << GET_STRING(xdLabelIt->second, A_XdLabel_Name);
                                    }
                                    else
                                    {
                                        char* ptr = NULL;
                                        ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(xdLabelIt->second, A_XdLabel_Name), -1, &ptr, NULL);
                                        msg << ptr;
                                        FREE(ptr);
                                    }

                                    processMsg.printMsg(RET_DBA_INFO_EXIST, msg.str());
                                }
                            }
                            else
                            {
                                DBA_DYNFLD_STP   dictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);

                                CONVERT_DYNST(dictLabelStp, A_DictLabel, xdLabelIt->second, A_XdLabel);

                                SET_DICT(dictLabelStp, A_DictLabel_EntDictId, targetDictId);

                                if (targetObjIdIdx == Null_Dynfld)
                                {
                                    objectId = this->getIdFromKey(objectIt->first, targetObjectEn, targetObjectEn);

                                    if (objectId != 0)
                                    {
                                        SET_ID(dictLabelStp, A_DictLabel_ObjDictId, objectId);
                                    }
                                    else
                                    {
                                        SYS_BreakOnDebug();
                                    }
                                }
                                else if (targetObjIdIdx == A_XdAttrib_AttribDictId && IS_NULLFLD(recordStp, targetObjIdIdx))
                                {
                                    SET_DICT(dictLabelStp, A_DictLabel_EntDictId, dictCriteriaDictId);

                                    std::string key = this->getKeyFromRecord(recordStp);
                                    auto   criterIt = this->m_dictCriteriaByKeyMap[DynType_Short].find(key);
                                    if (criterIt != this->m_dictCriteriaByKeyMap[DynType_Short].end())
                                    {
                                        COPY_DYNFLD(dictLabelStp, A_DictLabel, A_DictLabel_ObjDictId,
                                                    criterIt->second, A_DictCriter, A_DictCriter_DictId);

                                    }
                                }
                                else
                                {
                                    COPY_DYNFLD(dictLabelStp, A_DictLabel, A_DictLabel_ObjDictId,
                                                recordStp, recordStp->getDynStEn(), targetObjIdIdx);
                                }

                                if (IS_NULLFLD(dictLabelStp, A_DictLabel_ObjDictId) == false)
                                {
                                    DBA_ACTION_ENUM actionDone = NullAction;
                                    requestHelperPtr->insUpdRecord(dictLabelStp, actionDone, recordStp);

                                    xdStatusEn = XdStatus_Inserted;
                                }
                                else
                                {
                                    SYS_BreakOnDebug();
                                }
                            }

                            SET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn, XdAction_None);
                            SET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn, xdStatusEn);

                            requestHelperPtr->dbaCall(Update,
                                                      XdLabel,
                                                      DBA_ROLE_STATUS,
                                                      xdLabelIt->second);

                            for (auto it = languageIt->second.begin(); it != xdLabelIt; ++it)
                            {
                                SET_ID(it->second, A_XdLabel_ObjId, objectId);
                                SET_ENUM(it->second, A_XdLabel_XdActionEn, XdAction_None);
                                SET_ENUM(it->second, A_XdLabel_XdStatusEn, XdStatus_Untreated);

                                requestHelperPtr->dbaCall(Update,
                                                          XdLabel,
                                                          DBA_ROLE_STATUS,
                                                          it->second);
                            }
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                    else if (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable ||
                             this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_Label)
                    {
                        std::stringstream msg;
                        msg << "Label defined on unknown object, Entity: " << targetDictEntityStp->mdSqlName
                            << ", Language: " << langMap[languageIt->first]
                            << ", Key: " << objectIt->first
                            << ", Label: ";

                        if (IS_STRINGFLD(A_XdLabel, A_XdLabel_Name) == TRUE)
                        {
                            msg << GET_STRING(xdLabelIt->second, A_XdLabel_Name);
                        }
                        else
                        {
                            char* ptr = NULL;
                            ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(xdLabelIt->second, A_XdLabel_Name), -1, &ptr, NULL);
                            msg << ptr;
                            FREE(ptr);
                        }

                        processMsg.printMsg(RET_DBA_INFO_EXIST, msg.str());
                    }
                }
            }
        }
    }

    processMsg.printMsg(RET_SUCCEED, "done");
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::importData()
**
**  Description :   Import data from file
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::importData(const DdlGenImportFile &fileInfo, ITFC_CONTEXT_STP globalContextStp)
{
    MemoryPool   mp;
    RET_CODE     ret = RET_SUCCEED;

    std::string fullFileName = fileInfo.getFullName();

    std::string processStr("Importing data file");

    this->m_ddlGenContext.setMsgObjType("Import");
    this->m_ddlGenContext.setMsgSqlName(std::string());
    this->m_ddlGenContext.setMsgEntitySqlName(std::string());

    this->m_ddlGenContext.printMsg(RET_SRV_INFO_RUNNING, processStr + ": " + fullFileName);

    ITFC_CONTEXT_ST  context;
    context.mode = TripleAMode;
    ITFC_CONTEXT_STP contextStp = globalContextStp;

    if (contextStp == nullptr)
    {
        ITFC_Init(&context);
        contextStp = &context;
    }

    if (fileInfo.m_kindOfData == DdlGenImportFile::KindOfData::ScriptDef)
    {
        this->cleanUpScriptDef();
    }

    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
    contextStp->externalConnPtr = &ddlGenConnGuard.getDbiConn();

    if (ret == RET_SUCCEED)
    {
        contextStp->mode = TripleAMode;

        /* Force UTF8 for all import files */
        CURRENTCHARSETCODE_ENUM charsetCode = CurrentCharsetCode_UTF8;
        GEN_SetApplInfo(ApplCurrentCharsetOutputEnum, &charsetCode);
        GEN_SetApplInfo(ApplCurrentCharsetInputEnum, &charsetCode);

        AAAValueGuard<int> tmpInstallLevel(EV_AAAInstallLevel);


        switch (fileInfo.m_kindOfData)
        {
            case DdlGenImportFile::KindOfData::MetaDictionary:
            case DdlGenImportFile::KindOfData::PckMetaDictionary:
            case DdlGenImportFile::KindOfData::OptionMetaDictionary:
                EV_AAAInstallLevel = 6;
                break;

            case DdlGenImportFile::KindOfData::CustoMetaDictionary:
                EV_AAAInstallLevel = 5;
                break;

            case DdlGenImportFile::KindOfData::InfraData:
                EV_AAAInstallLevel = 2;
                break;

            case DdlGenImportFile::KindOfData::CustoInfraData:
                EV_AAAInstallLevel = 1;
                break;

            case DdlGenImportFile::KindOfData::None:
            case DdlGenImportFile::KindOfData::ScriptDef:
                break;
        }

        std::string logFileStr = fileInfo.m_logPath + fileInfo.m_logName;
        char* logFile = mp.allocChar(FILEINFO, logFileStr.length() + 1);
        strcpy(logFile, logFileStr.c_str());
        ITFC_SetOStream(contextStp, logFile, FALSE);

        std::string errFileStr = fileInfo.m_logPath + fileInfo.getFileName() + ".err";
        char* errFile = mp.allocChar(FILEINFO, errFileStr.length() + 1);
        strcpy(errFile, errFileStr.c_str());
        ITFC_SetEStream(contextStp, errFile, FALSE);

        char* fileName = mp.allocChar(FILEINFO, fullFileName.length() + 1);
        strcpy(fileName, fullFileName.c_str());
        ITFC_AddIStream(contextStp, fileName);

        this->m_kindOfImportFile = fileInfo.m_kindOfData;

        {
            char* line = nullptr;

            if (fileInfo.m_kindOfData == DdlGenImportFile::KindOfData::CustoMetaDictionary)
            {
                ITFC_TripleAParse(contextStp, "SET AUTOMATIC xd_entity ON");
                ITFC_TripleAParse(contextStp, "SET AUTOMATIC xd_attribute ON");
            }

            while (ITFC_LoadILine(contextStp, &line) == 0)
            {
                ITFC_TripleAParse(contextStp, line);
            }
            FREE(line);
        }

        this->m_kindOfImportFile = DdlGenImportFile::KindOfData::None;

        if (globalContextStp == nullptr)
        {
            ITFC_Done(&context);
        }

        if (contextStp->lineEnumCountMap.find(ITFC_MSG_ENUM::Error) != contextStp->lineEnumCountMap.end())
        {
            ret = RET_ITFC_ERR_FATAL;
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            this->m_ddlGenContext.printMsg(ret, processStr.append(" done!"));
        }
        else
        {
            std::stringstream msg;
            msg << processStr << " failed, " << contextStp->lineEnumCountMap[ITFC_MSG_ENUM::Error] << " error(s) found see log file: " << logFileStr;
            this->m_ddlGenContext.printMsg(RET_DBA_ERR_MD, msg.str());
        }
    }

    contextStp->lineEnumCountMap.clear();

    this->m_ddlGenContext.setMsgObjType(std::string());

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::manageDenormAttributes()
**
**  Description :   Manage denormalized attributes
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::manageDenormAttributes(DBA_DYNFLD_STP recordStp)
{
    switch (recordStp->getObjectCst())
    {
        case XdIndexAttribCst:
            if (IS_NULLFLD(recordStp, A_XdIndexAttrib_XdAttribSqlName) == TRUE &&
                IS_NULLFLD(recordStp, A_XdIndexAttrib_XdAttribId) == FALSE)
            {
                DBA_DYNFLD_STP xdAttribStp = this->getRecordById(XdAttrib, GET_ID(recordStp, A_XdIndexAttrib_XdAttribId), true);
                if (xdAttribStp != nullptr)
                {
                    COPY_DYNFLD(recordStp, A_XdIndexAttrib, A_XdIndexAttrib_XdAttribSqlName, xdAttribStp, A_XdAttrib, A_XdAttrib_SqlName);
                }
                else
                {
                    SYS_BreakOnDebug();
                }
            }
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getXdActionStatusFieldPos()
**
**  Description :   
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::getXdActionStatusFieldPos(DBA_DYNFLD_STP recordStp, FIELD_IDX_T &xdActionField, FIELD_IDX_T &xdStatusField)
{
    xdStatusField = Null_Dynfld;
    xdActionField = Null_Dynfld;

    switch (recordStp->getObjectCst())
    {
        case XdEntityCst:
            xdActionField = A_XdEntity_XdActionEn;
            xdStatusField = A_XdEntity_XdStatusEn;
            break;

        case XdAttribCst:
            xdActionField = A_XdAttrib_XdActionEn;
            xdStatusField = A_XdAttrib_XdStatusEn;
            break;

        case XdAttributeCustoCst:
            xdActionField = A_XdAttributeCusto_XdActionEn;
            xdStatusField = A_XdAttributeCusto_XdStatusEn;
            break;

        case XdPermValCst:
            xdActionField = A_XdPermVal_XdActionEn;
            xdStatusField = A_XdPermVal_XdStatusEn;
            break;

        case XdLabelCst:
            xdActionField = A_XdLabel_XdActionEn;
            xdStatusField = A_XdLabel_XdStatusEn;
            break;

        case XdIndexCst:
            xdActionField = A_XdIndex_XdActionEn;
            xdStatusField = A_XdIndex_XdStatusEn;
            break;

        case XdIndexAttribCst:
            xdActionField = A_XdIndexAttrib_XdActionEn;
            xdStatusField = A_XdIndexAttrib_XdStatusEn;
            break;

        case XdPartitionCst:
            xdActionField = A_XdPartition_XdActionEn;
            xdStatusField = A_XdPartition_XdStatusEn;
            break;

        case XdEntityFeatureCst:
            xdActionField = A_XdEntityFeature_XdActionEn;
            xdStatusField = A_XdEntityFeature_XdStatusEn;
            break;

        case XdAttribCommentCst:
            xdActionField = A_XdAttribComment_XdActionEn;
            xdStatusField = A_XdAttribComment_XdStatusEn;
            break;

        case DictSprocCst:
            /* Don't manage the xd_status_e and xd_action_e here */
            break;

        case DictDataTpCst:
        case DictEntityCst:
        case DictAttrCst:
        case DictLangCst:
        case DictFctCst:
        case DictErrMsgCst:
        case DictPermValCst:
        case DictSprocParamCst:
        case DictSprocReturnsCst:
        case DictCriterCst:
        case DictAttribCommentCst:
        case DictLabelCst:
        case DictDependsCst:
        case DictEntityConstraintsCst:
        case DictSegmentCst:
        case DictDatabaseCst:
        case TabModifStatCst:
        case ApplParamCst:
        case ApplMsgCst:
        case ApplMsgTxtCst:
        case HoldingConstraintScriptCst:
        case TradingConstraintScriptCst:
        case ScriptDefCst:
        case QuestDefCst:
        case FmtCst:
        case FmtEltCst:
        case DenomCst:
            break;

        default:
            if (SYS_IsDdlGenMode())
            {
                SYS_BreakOnDebug();
            }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::setXdAction()
**
**  Description :   Set the new xd_action_e
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::setXdAction(DBA_DYNFLD_STP recordStp, XD_ACTION_ENUM xdActionEn)
{
    FIELD_IDX_T xdStatusField = Null_Dynfld;
    FIELD_IDX_T xdActionField = Null_Dynfld;

    this->getXdActionStatusFieldPos(recordStp, xdActionField, xdStatusField);

    if (xdActionField != Null_Dynfld)
    {
        if ((xdActionEn != XdAction_ToInsert ||
             (GET_ENUM(recordStp, xdActionField) != XdAction_ToDelete &&
              GET_ENUM(recordStp, xdActionField) != XdAction_ToPhysicallyDelete)) &&
            (xdActionEn != XdAction_ToDeprecate || 
             (GET_ENUM(recordStp, xdStatusField) != XdStatus_Deprecated && 
              GET_ENUM(recordStp, xdStatusField) != XdStatus_Deleted &&
              GET_ENUM(recordStp, xdStatusField) != XdStatus_PhysicallyDeleted)))
        {
            SET_ENUM(recordStp, xdActionField, xdActionEn);
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::resetAllMetaDict()
**
**  Description :   Push to deprecated all the meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::resetAllMetaDict()
{
    for (auto &recordIt : this->m_allRecordsMap)
    {
        recordIt.second = XdAction_ToDeprecate;
        this->setXdAction(recordIt.first, XdAction_ToDeprecate);
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::cleanUpMetaDict()
**
**  Description :   Clean-up the meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221031
**
*************************************************************************/
void DdlGenDbaAccess::cleanUpMetaDict()
{
    FIELD_IDX_T xdStatusField = Null_Dynfld;
    FIELD_IDX_T xdActionField = Null_Dynfld;
    OBJECT_ENUM lastObjEn     = NullEntity;

    for (auto &recordIt : this->m_allRecordsMap)
    {
        DBA_DYNFLD_STP recordStp = recordIt.first;

        if (lastObjEn != recordStp->getObjectEn())
        {
            lastObjEn = recordStp->getObjectEn();
            this->getXdActionStatusFieldPos(recordStp, xdActionField, xdStatusField);
        }

        if (xdActionField != Null_Dynfld &&
            GET_ENUM(recordStp, xdActionField) == XdAction_ToDeprecate &&
            lastObjEn != XdLabel)
        {
            if (xdStatusField != Null_Dynfld)
            {
                SET_ENUM(recordStp, xdStatusField, XdStatus_Deleted);
                SET_ENUM(recordStp, xdActionField, XdAction_None);

                this->insUpdDelRecord(Update, lastObjEn, DBA_ROLE_STATUS, recordStp, false);
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::cleanUpDictLabels()
**
**  Description :   Clean-up all the dict_labels
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230207
**
*************************************************************************/
void DdlGenDbaAccess::cleanUpDictLabels()
{
    LockGuard lockGuard(this->m_lock);
    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    this->load("dict_function", dbiConnHelper);
    this->load("appl_message", dbiConnHelper);
    this->load("dict_label", dbiConnHelper);

    for (auto entityIt = this->m_dictLabelMap.begin(); entityIt != this->m_dictLabelMap.end(); ++entityIt)
    {
        for (auto objectIt = entityIt->second.begin(); objectIt != entityIt->second.end(); ++objectIt)
        {
            for (auto langIt = objectIt->second.begin(); langIt != objectIt->second.end(); ++langIt)
            {
                DBA_DYNFLD_STP recordStp = langIt->second;

                this->m_recordActionVector[recordStp].push_back(DdlGenDbaAccess::Action(Delete, DictLabel, UNUSED));
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::cleanUpOneEntity()
**
**  Description :   Clean-up one entity
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231109
**
*************************************************************************/
void DdlGenDbaAccess::cleanUpOneEntity(DBA_DYNFLD_STP xdEntityStp)
{
    if (IS_NOTNULL(xdEntityStp, A_XdEntity_Id))
    {
        DICT_T xdEntityDictId, xdAttribDictId, xdPermValDictId;

        DBA_GetDictId(XdEntity, &xdEntityDictId);
        DBA_GetDictId(XdAttrib, &xdAttribDictId);
        DBA_GetDictId(XdPermVal, &xdPermValDictId);

        DICT_T dictEntityDictId, dictAttribDictId, dictPermValDictId;

        DBA_GetDictId(DictEntity, &dictEntityDictId);
        DBA_GetDictId(DictAttr, &dictAttribDictId);
        DBA_GetDictId(DictPermVal, &dictPermValDictId);

        SET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn, XdStatus_Deleted);
        SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_None);
        this->insUpdDelRecord(Update, XdEntity, DBA_ROLE_STATUS, xdEntityStp, false);

        if (IS_NOTNULL(xdEntityStp, A_XdEntity_EntityDictId))
        {
            auto dictEntityStp = this->getRecordById(DictEntity, GET_DICT(xdEntityStp, A_XdEntity_EntityDictId), true);
            this->insUpdDelRecord(Delete, DictEntity, DBA_ROLE_STATUS, dictEntityStp, false);

            auto &dictEntityLabelsMap = this->m_dictLabelMap[dictEntityDictId][GET_DICT(xdEntityStp, A_XdEntity_EntityDictId)];
            for (auto dictEntityLabelsIt : dictEntityLabelsMap)
            {
                SET_ENUM(dictEntityLabelsIt.second, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
                SET_ENUM(dictEntityLabelsIt.second, A_XdAttrib_XdActionEn, XdAction_None);
                this->insUpdDelRecord(Delete, DictLabel, DBA_ROLE_STATUS, dictEntityLabelsIt.second, false);
            }
        }

        auto &xdEntityLabelsMap = this->m_xdLabelMap[xdEntityDictId][GET_ID(xdEntityStp, A_XdEntity_Id)];
        for (auto xdEntityLabelsNatMap : xdEntityLabelsMap)
        {
            for (auto &xdEntityLabelsIt : xdEntityLabelsNatMap.second)
            {
                SET_ENUM(xdEntityLabelsIt.second, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
                SET_ENUM(xdEntityLabelsIt.second, A_XdAttrib_XdActionEn, XdAction_None);
                this->insUpdDelRecord(Update, XdLabel, DBA_ROLE_STATUS, xdEntityLabelsIt.second, false);
            }
        }

        auto &xdAttributeMap = this->m_xdAttributesByEntityMap[GET_ID(xdEntityStp, A_XdEntity_Id)];
        for (auto xdAttribStp : xdAttributeMap)
        {
            SET_ENUM(xdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
            SET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn, XdAction_None);
            this->insUpdDelRecord(Update, XdAttrib, DBA_ROLE_STATUS, xdAttribStp, false);

            auto xdPermValMap = this->m_xdPemValuesByXdAttribNatMap[GET_ID(xdAttribStp, A_XdAttrib_Id)];
            for (auto &xdPermValIt : xdPermValMap)
            {
                SET_ENUM(xdPermValIt.second, A_XdPermVal_XdStatusEn, XdStatus_Deleted);
                SET_ENUM(xdPermValIt.second, A_XdPermVal_XdActionEn, XdAction_None);
                this->insUpdDelRecord(Update, XdPermVal, DBA_ROLE_STATUS, xdPermValIt.second, false);
            }
        }

        auto &dictAttributeMap = this->m_dictEntityAttribBySqlNameMap[GET_ID(xdEntityStp, A_XdEntity_Id)];
        for (auto &dictAttributeIt : dictAttributeMap)
        {
            this->insUpdDelRecord(Delete, DictAttr, DBA_ROLE_STATUS, dictAttributeIt.second, false);

            auto dictPermValMap = this->m_dictPemValuesByAttribMap[GET_DICT(dictAttributeIt.second, A_DictAttr_DictId)];
            for (auto &dictPermValIt : dictPermValMap)
            {
                this->insUpdDelRecord(Delete, DictPermVal, DBA_ROLE_STATUS, dictPermValIt.second, false);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::importAllData()
**
**  Description :   Push to deprecated all the meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::importAllData()
{
    RET_CODE ret = RET_SUCCEED;

    std::vector<DdlGenImportFile> fileToImportVector;

    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data/", "dict_language", "imp", DdlGenImportFile::KindOfData::InfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data.usr/", "dict_language.usr", "imp", DdlGenImportFile::KindOfData::CustoInfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install", "dict_err_msg", "imp", DdlGenImportFile::KindOfData::InfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data/", "appl_message", "imp", DdlGenImportFile::KindOfData::InfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data.usr/", "appl_message.usr", "imp", DdlGenImportFile::KindOfData::CustoInfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data/", "dict_function", "imp", DdlGenImportFile::KindOfData::InfraData));
    fileToImportVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/install/data.usr/", "dict_function.usr", "imp", DdlGenImportFile::KindOfData::CustoInfraData));

    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

    if (dbiConnHelper.isValidAndInit())
    {
        this->load("dict_language", dbiConnHelper);
        this->load("appl_message", dbiConnHelper);
        this->load("appl_msg_text", dbiConnHelper);
        this->load("dict_function", dbiConnHelper);
        this->load("dict_err_msg", dbiConnHelper);
    }

    for (auto fileIt = fileToImportVector.begin(); fileIt != fileToImportVector.end(); ++fileIt)
    {
        const auto impRet = this->importData((*fileIt));
        if (RET_GET_LEVEL(impRet) == RET_LEV_ERROR)
        {
            ret = impRet;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   copyXdAttrib()
**
**  Description :   Copy attribute if needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::copyXdAttrib(DBA_DYNFLD_STP                  refXdEntityStp, 
                                   DBA_DYNFLD_STP                  refXdAttribStp, 
                                   DICT_BUILD_RULE_ENUM            dictBuildRuleEn,
                                   DBA_DYNFLD_STP                 &newXdAttribStp, 
                                   std::map<ID_T, DBA_DYNFLD_STP> &xdEntitiesMap)
{
    if (GET_A_XdAttrib_FeatureEn(refXdAttribStp) != XdEntityFeatureFeatureEn::None ||
        GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE ||
        (GET_ENUM(refXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert &&
         (GET_ENUM(refXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_None || GET_ENUM(refXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_Inserted)))
    {
        return;
    }

    if (newXdAttribStp == nullptr)
    {
        newXdAttribStp = this->m_mp.allocDynst(FILEINFO, A_XdAttrib);
    }

    bool bToInsert = false;
    switch (dictBuildRuleEn)
    {
        case DictBuildRule_All:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                bToInsert = true;
            }
            break;

        case DictBuildRule_AllForcePhysical:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);

                if (GET_FLAG(newXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                    (GET_ENUM(newXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Denorm ||
                     GET_ENUM(newXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Calculated))
                {
                    SET_ENUM(newXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Physical);
                    SET_NULL_ID(newXdAttribStp, A_XdAttrib_PhysicalXdAttribId);
                }

                SET_ENUM(newXdAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
                bToInsert = true;
            }
            break;

        case DictBuildRule_Ud:
        case DictBuildRule_ToUd:
            if (GET_ENUM(refXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
                GET_ENUM(refXdAttribStp, A_XdAttrib_ModelBankEn) != ModelBank_None)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                bToInsert = true;
            }
            break;

        case DictBuildRule_Pk:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                SET_ENUM(newXdAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
                bToInsert = true;
            }
            break;

        case DictBuildRule_Bk:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                SET_ENUM(newXdAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
                bToInsert = true;
            }
            break;

        case DictBuildRule_PkBk:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE ||
                GET_FLAG(refXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                SET_ENUM(newXdAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
                bToInsert = true;
            }
            break;

        case DictBuildRule_Sh:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                DictAttribClass::isPhysicalCalcEn(static_cast<DICTATTR_ENUM>(GET_ENUM(refXdAttribStp, A_XdAttrib_CalcEn))))
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                bToInsert = true;

                SET_NULL_SMALLINT(newXdAttribStp, A_XdAttrib_ShortIdx);
                SET_NULL_SMALLINT(newXdAttribStp, A_XdAttrib_ShortDispRank);
                SET_ENUM(newXdAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
            }
            break;

        case DictBuildRule_AllDb:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                DictAttribClass::isPhysicalCalcEn(static_cast<DICTATTR_ENUM>(GET_ENUM(refXdAttribStp, A_XdAttrib_CalcEn))))
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                bToInsert = true;
            }
            break;

        case DictBuildRule_PartialSpecialization:
            if (GET_FLAG(refXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                GET_FLAG(refXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                DictAttribClass::isPhysicalCalcEn(static_cast<DICTATTR_ENUM>(GET_ENUM(refXdAttribStp, A_XdAttrib_CalcEn))) &&
                (GET_FLAG(refXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE || GET_ENUM(refXdAttribStp, A_XdAttrib_MeSpecialisationEn) == MeSpecialisation_Applied))
            {
                COPY_DYNST(newXdAttribStp, refXdAttribStp, A_XdAttrib);
                bToInsert = true;

                SET_NULL_SMALLINT(newXdAttribStp, A_XdAttrib_ShortIdx);
                SET_NULL_SMALLINT(newXdAttribStp, A_XdAttrib_ShortDispRank);
                SET_ENUM(newXdAttribStp, A_XdAttrib_MeSpecialisationEn, MeSpecialisation_NotApplicable);
            }
            break;

        case DictBuildRule_None:
            break;
    }

    if (bToInsert)
    {
        ID_T recId = 0;

        SET_NULL_ID(newXdAttribStp, A_XdAttrib_Join1XdAttribId);
        SET_NULL_ID(newXdAttribStp, A_XdAttrib_Join2XdAttribId);
        SET_FLAG_FALSE(newXdAttribStp, A_XdAttrib_VerticalSearchFlg);
        SET_FLAG_FALSE(newXdAttribStp, A_XdAttrib_VerticalPatternFlg);

        if (GET_ENUM(refXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
        {
            if (DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumType ||
                DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == FlagType)
            {
                SET_FLAG_TRUE(newXdAttribStp, A_XdAttrib_MandatoryFlg);
                if (IS_NULLFLD(newXdAttribStp, A_XdAttrib_Default))
                {
                    SET_STRING(newXdAttribStp, A_XdAttrib_Default, "0");
                }
            }
            else
            {
                SET_FLAG_FALSE(newXdAttribStp, A_XdAttrib_MandatoryFlg);
            }
        }

        if (IS_NULLFLD(newXdAttribStp, A_XdAttrib_ParentXdAttribId))
        {
            if (dictBuildRuleEn == DictBuildRule_Ud || dictBuildRuleEn == DictBuildRule_ToUd)
            {
                COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
            }
            else if (DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumType ||
                     DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == FlagType ||
                     DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumMaskType ||
                     DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == CodeType ||
                     DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == NameType)
            {
                COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
            }
            else if (DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == IdType &&
                     IS_NULLFLD(newXdAttribStp, A_XdAttrib_RefXdEntityId) == FALSE)
            {
                auto refXdEntityIt = xdEntitiesMap.find(GET_ID(newXdAttribStp, A_XdAttrib_RefXdEntityId));
                if (refXdEntityIt != xdEntitiesMap.end() &&
                    strcmp(GET_SYSNAME(refXdEntityIt->second, A_XdEntity_SqlName), "type") == 0)
                {
                    COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
                }
            }
        }

        SET_NULL_ID(newXdAttribStp, A_XdAttrib_Id);
        SET_NULL_DICT(newXdAttribStp, A_XdAttrib_AttribDictId);
        SET_ID(newXdAttribStp, A_XdAttrib_XdEntityId, GET_ID(refXdEntityStp, A_XdEntity_Id));

        auto existsRecordStp = this->getRecord(XdAttrib, newXdAttribStp);
        if (existsRecordStp != nullptr)
        {
            COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId, existsRecordStp, A_XdAttrib, A_XdAttrib_AttribDictId);
            COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_XdStatusEn, existsRecordStp, A_XdAttrib, A_XdAttrib_XdStatusEn);

            if (GET_ENUM(existsRecordStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert)
            {
                if (IS_NOTNULL(existsRecordStp, A_XdAttrib_Prog))
                {
                    COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_Prog, existsRecordStp, A_XdAttrib, A_XdAttrib_Prog);
                }

                if (DATATYPE_DICT_TO_ENUM(GET_DICT(newXdAttribStp, A_XdAttrib_DataTpDictId)) == IdType)
                {
                    if (IS_NULLFLD(existsRecordStp, A_XdAttrib_RefXdEntityId) == false)
                    {
                        COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_RefXdEntityId, existsRecordStp, A_XdAttrib, A_XdAttrib_RefXdEntityId);
                    }

                    if (GET_ENUM(existsRecordStp, A_XdAttrib_RefDeleteRuleEn) != RefDelRule_None)
                    {
                        COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_RefDeleteRuleEn, existsRecordStp, A_XdAttrib, A_XdAttrib_RefDeleteRuleEn);
                    }
                }
            }

            if (IS_NULLFLD(newXdAttribStp, A_XdAttrib_ParentXdAttribId) == false &&
                IS_NULLFLD(refXdAttribStp, A_XdAttrib_ParentXdAttribId))
            {
                auto xdPemValuesMapIt = this->m_xdPemValuesByXdAttribNatMap.find(GET_ID(existsRecordStp, A_XdAttrib_Id));
                if (xdPemValuesMapIt != this->m_xdPemValuesByXdAttribNatMap.end())
                {
                    std::string msg = "Removing permitted value for attribute ";
                    msg += std::string(GET_SYSNAME(refXdEntityStp, A_XdEntity_SqlName)) + "." + std::string(GET_SYSNAME(newXdAttribStp, A_XdAttrib_SqlName));
                    msg += ", having parent attribute";
                    this->m_ddlGenContext.printMsg(RET_SUCCEED, msg);

                    for (auto it = xdPemValuesMapIt->second.begin(); it != xdPemValuesMapIt->second.end(); ++it)
                    {
                        SET_ENUM(it->second, A_XdPermVal_XdActionEn, XdAction_None);
                        SET_ENUM(it->second, A_XdPermVal_XdStatusEn, XdStatus_Deleted);

                        this->insUpdDelRecord(Update, XdPermVal, DBA_ROLE_STATUS, it->second, false);
                    }
                }
            }

        }

        if (IS_NULLFLD(newXdAttribStp, A_XdAttrib_ParentXdAttribId) == false &&
            IS_NULLFLD(refXdAttribStp, A_XdAttrib_ParentXdAttribId) == false &&
            CMP_DYNFLD(newXdAttribStp, refXdAttribStp, A_XdAttrib_ParentXdAttribId, A_XdAttrib_ParentXdAttribId, IdType) == 0)
        {
            if (existsRecordStp != nullptr &&
                CMP_DYNFLD(refXdAttribStp, existsRecordStp, A_XdAttrib_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
            {
                SET_NULL_ID(refXdAttribStp, A_XdAttrib_ParentXdAttribId);
                (void)this->insUpdRecord(refXdAttribStp, recId, UNUSED, false);

                COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);

                if (this->m_xdPemValuesByXdAttribNatMap.end() == this->m_xdPemValuesByXdAttribNatMap.find(GET_ID(refXdAttribStp, A_XdAttrib_Id)))
                {
                    auto xdPemValuesMapIt = this->m_xdPemValuesByXdAttribNatMap.find(GET_ID(newXdAttribStp, A_XdAttrib_Id));
                    if (xdPemValuesMapIt != this->m_xdPemValuesByXdAttribNatMap.end())
                    {
                        for (auto it = xdPemValuesMapIt->second.begin(); it != xdPemValuesMapIt->second.end(); ++it)
                        {
                            COPY_DYNFLD(it->second, A_XdPermVal, A_XdPermVal_XdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
                        }
                    }
                }
            }
        }

        if (IS_NULLFLD(newXdAttribStp, A_XdAttrib_TemplateXdAttribId))
        {
            COPY_DYNFLD(newXdAttribStp, A_XdAttrib, A_XdAttrib_TemplateXdAttribId, refXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
        }

        (void)this->insUpdRecord(newXdAttribStp, recId, DBA_ROLE_UDT, false);
        newXdAttribStp = nullptr;
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::copyXdEntityDictBuildRule()
**
**  Description :   Copy entities and attributes when needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::copyXdEntityDictBuildRule()
{
    auto          &xdEntitiesMap  = this->m_mapIdByObjEnMap[XdEntity];
    DBA_DYNFLD_STP newXdAttribStp = nullptr;

    std::set<std::string>    entitySubSet;

    if (this->m_ddlGenContext.ddlGenAction.m_bSingleEntity)
    {
        for (auto shXdEntityIt = this->m_ddlGenContext.ddlGenAction.m_shXdEntityVector.begin(); 
             shXdEntityIt != this->m_ddlGenContext.ddlGenAction.m_shXdEntityVector.end(); 
             ++shXdEntityIt)
        {
            entitySubSet.insert(GET_SYSNAME((*shXdEntityIt), S_XdEntity_SqlName));
        }
    }

    std::map<DICT_BUILD_RULE_ENUM, std::vector<DBA_DYNFLD_STP>> dictBuildRuleMap;
    for (auto &recordIt : xdEntitiesMap)
    {
        DICT_BUILD_RULE_ENUM dictBuildRule = static_cast<DICT_BUILD_RULE_ENUM>(GET_ENUM(recordIt.second, A_XdEntity_DictBuildRuleEn));
        if (dictBuildRule != DictBuildRule_None &&
            GET_ENUM(recordIt.second, A_XdEntity_XdActionEn) == XdAction_ToInsert &&
            IS_NULLFLD(recordIt.second, A_XdEntity_LinkedXdEntityId) == FALSE)
        {
            if (entitySubSet.empty() == false &&
                entitySubSet.find(GET_SYSNAME(recordIt.second, A_XdEntity_SqlName)) == entitySubSet.end())
            {
                continue;
            }

            dictBuildRuleMap[dictBuildRule].push_back(recordIt.second);
        }
    }

    for (auto &recordIt : dictBuildRuleMap[DictBuildRule_ToUd])
    {
        auto linkedXdEntityIt = xdEntitiesMap.find(GET_ID(recordIt, A_XdEntity_LinkedXdEntityId));
        auto xdAttribMapIt = this->m_xdAttributesByEntityMap.find(GET_ID(recordIt, A_XdEntity_Id));

        if (linkedXdEntityIt != xdEntitiesMap.end() &&
            xdAttribMapIt != this->m_xdAttributesByEntityMap.end())
        {
            for (auto &xdAttribIt : xdAttribMapIt->second)
            {
                if (GET_ENUM(xdAttribIt, A_XdAttrib_CustomFlg) != Custom_No ||
                    GET_ENUM(xdAttribIt, A_XdAttrib_ModelBankEn) != ModelBank_None)
                {
                    this->copyXdAttrib(linkedXdEntityIt->second, xdAttribIt, DictBuildRule_ToUd, newXdAttribStp, xdEntitiesMap);
                }
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    dictBuildRuleMap.erase(DictBuildRule_ToUd);

    for (auto &recordIt : dictBuildRuleMap[DictBuildRule_PartialSpecialization])
    {
        auto linkedXdEntityIt = xdEntitiesMap.find(GET_ID(recordIt, A_XdEntity_LinkedXdEntityId));
        auto linkedXdAttribIt = this->m_xdAttributesByEntityMap.find(GET_ID(recordIt, A_XdEntity_LinkedXdEntityId));

        if (linkedXdEntityIt != xdEntitiesMap.end() &&
            linkedXdAttribIt != this->m_xdAttributesByEntityMap.end())
        {
            for (auto &xdAttribIt : linkedXdAttribIt->second)
            {
                this->copyXdAttrib(recordIt, xdAttribIt, DictBuildRule_PartialSpecialization, newXdAttribStp, xdEntitiesMap);
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    dictBuildRuleMap.erase(DictBuildRule_PartialSpecialization);

    for (auto &recordItMap : dictBuildRuleMap)
    {
        for (auto &recordIt : recordItMap.second)
        {
            auto linkedXdEntityIt = xdEntitiesMap.find(GET_ID(recordIt, A_XdEntity_LinkedXdEntityId));
            auto linkedXdAttribIt = this->m_xdAttributesByEntityMap.find(GET_ID(recordIt, A_XdEntity_LinkedXdEntityId));

            if (linkedXdEntityIt != xdEntitiesMap.end() &&
                linkedXdAttribIt != this->m_xdAttributesByEntityMap.end())
            {
                for (auto &xdAttribIt : linkedXdAttribIt->second)
                {
                    this->copyXdAttrib(recordIt, xdAttribIt, recordItMap.first, newXdAttribStp, xdEntitiesMap);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }
    }

    if (newXdAttribStp != nullptr)
    {
        this->m_mp.freeDynStp(newXdAttribStp);
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::applyCusto()
**
**  Description :   Manage xd_attribute_custo
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   
**
*************************************************************************/
void DdlGenDbaAccess::applyCusto()
{
    auto &xdAttribCustoMap = this->m_mapIdByObjEnMap[XdAttributeCusto];
    auto &xdAttribMap      = this->m_mapIdByObjEnMap[XdAttrib];

    for (auto &xdAttribCustoIt : xdAttribCustoMap)
    {
        auto &xdAttribCustoStp = xdAttribCustoIt.second;

        if (GET_A_XdAttributeCusto_XdActionEn(xdAttribCustoStp) == XdEntityXdActionEn::ToInsert ||
            GET_A_XdAttributeCusto_XdActionEn(xdAttribCustoStp) == XdEntityXdActionEn::ToRefresh ||
            (GET_A_XdAttributeCusto_XdActionEn(xdAttribCustoStp) == XdEntityXdActionEn::None &&
             GET_A_XdAttributeCusto_XdStatusEn(xdAttribCustoStp) == XdEntityXdStatusEn::Inserted))
        {
            auto xdAttribIt = xdAttribMap.find(GET_ID(xdAttribCustoStp, A_XdAttributeCusto_XdAttribId));
            if (xdAttribIt != xdAttribMap.end())
            {
                auto &currXdAttribStp = xdAttribIt->second;

                switch (GET_A_XdAttributeCusto_NatEn(xdAttribCustoStp))
                {
                    case XdAttributeCustoNatEn::Display:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_DispRank, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_DispRank);
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_OldDispRank, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_DispRank);
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_SubTpMask, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_SubTpMask);
                        break;

                    case XdAttributeCustoNatEn::Edition:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_EditEn, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_EditEn);
                        break;

                    case XdAttributeCustoNatEn::Search:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_QuickSearchMask, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_QuickSearchMask);
                        break;

                    case XdAttributeCustoNatEn::StringLength:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_MaxDbLen, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_MaxDbLen);
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_DefaultDispLen, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_DefaultDispLen);
                        break;

                    case XdAttributeCustoNatEn::Export:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_ExportEn, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_ExportEn);
                        break;

                    case XdAttributeCustoNatEn::MultiEntity:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_MeSpecialisationEn, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_MeSpecialisationEn);
                        break;

                    case XdAttributeCustoNatEn::TSLSearch:
                        if (GET_A_XdAttributeCusto_TslSearchEn(xdAttribCustoStp) == XdAttributeCustoTslSearchEn::VerticalSearch)
                        {
                            SET_FLAG_TRUE(currXdAttribStp, A_XdAttrib_VerticalSearchFlg);
                        }
                        else if (GET_A_XdAttributeCusto_TslSearchEn(xdAttribCustoStp) == XdAttributeCustoTslSearchEn::VerticalPattern)
                        {
                            SET_FLAG_TRUE(currXdAttribStp, A_XdAttrib_VerticalPatternFlg);
                        }
                        break;

                    case XdAttributeCustoNatEn::ObjectModifStat:
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_ObjModifStatEn, xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_ObjModifStatEn);
                        break;
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::copyXdEntityByName()
**
**  Description :   Copy entities and attributes when needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::copyXdEntityByName(DBA_DYNFLD_STP fromXdEntityStp, XdEntityDictBuildRuleEn dictBuildRuleEn)
{
    MemoryPool mp;

    std::string toEntitySqlname(GET_SYSNAME(fromXdEntityStp, A_XdEntity_SqlName));
    std::string toEntityShortSqlname(GET_SYSNAME(fromXdEntityStp, A_XdEntity_ShortSqlName));
    std::string toEntityAliasSqlname(GET_SYSNAME(fromXdEntityStp, A_XdEntity_AliasSqlName));

    INT_T  toDictEntityValue = GET_INT(fromXdEntityStp, A_XdEntity_DictEntityValue);

    std::string toCustSqlname;

    std::string sufix;

    switch (dictBuildRuleEn)
    {
        case XdEntityDictBuildRuleEn::AllLinkedEntityForShadow:
            sufix = "_sh";
            toDictEntityValue += 4000000;
            break;

        case XdEntityDictBuildRuleEn::PKOfTheLinkedEntity:
        case XdEntityDictBuildRuleEn::PKAndBKOfTheLinkedEntity:
            sufix = "_pk";
            toDictEntityValue += 2000000;
            break;

        case XdEntityDictBuildRuleEn::PartialSpecialization:
            sufix = "_be";
            toDictEntityValue += 5000000;
            break;

        default:
            SYS_BreakOnDebug();
    }

    toEntitySqlname += sufix;
    toEntityShortSqlname += sufix;
    toEntityAliasSqlname += sufix;

    DBA_DYNFLD_STP toXdEntityStp = this->getRecordByCode(XdEntity, toEntitySqlname);
    DBA_DYNFLD_STP oldXdEntityStp = nullptr;

    if (toXdEntityStp == nullptr)
    {
        toXdEntityStp = this->m_mp.allocDynst(FILEINFO, A_XdEntity);
    }
    else if (GET_ENUM(toXdEntityStp, A_XdEntity_XdActionEn) != XdAction_ToInsert)
    {
        oldXdEntityStp    = mp.duplicate(FILEINFO, toXdEntityStp);
        toDictEntityValue = GET_INT(toXdEntityStp, A_XdEntity_DictEntityValue);
    }
    else
    {
        return;
    }

    COPY_DYNST(toXdEntityStp, fromXdEntityStp, A_XdEntity);

    SET_SYSNAME(toXdEntityStp, A_XdEntity_SqlName, toEntitySqlname.c_str());
    SET_SYSNAME(toXdEntityStp, A_XdEntity_DbSqlName, toEntitySqlname.c_str());
    SET_SYSNAME(toXdEntityStp, A_XdEntity_ShortSqlName, toEntityShortSqlname.c_str());
    SET_SYSNAME(toXdEntityStp, A_XdEntity_AliasSqlName, toEntityAliasSqlname.c_str());
    SET_INT(toXdEntityStp, A_XdEntity_DictEntityValue, toDictEntityValue);
    SET_NULL_SYSNAME(toXdEntityStp, A_XdEntity_PrecompSqlName);
    SET_NULL_DICT(toXdEntityStp, A_XdEntity_PrecompSegmentDictId);
    SET_ENUM(toXdEntityStp, A_XdEntity_DictBuildRuleEn, dictBuildRuleEn);
    SET_MASK(toXdEntityStp, A_XdEntity_AutomaticMask, 0);

    if (oldXdEntityStp != nullptr)
    {
        COPY_DYNFLD(toXdEntityStp, A_XdEntity, A_XdEntity_Id,            oldXdEntityStp, A_XdEntity, A_XdEntity_Id);
        COPY_DYNFLD(toXdEntityStp, A_XdEntity, A_XdEntity_EntityDictId,  oldXdEntityStp, A_XdEntity, A_XdEntity_EntityDictId);
        COPY_DYNFLD(toXdEntityStp, A_XdEntity, A_XdEntity_XdStatusEn,    oldXdEntityStp, A_XdEntity, A_XdEntity_XdStatusEn);
        COPY_DYNFLD(toXdEntityStp, A_XdEntity, A_XdEntity_BuildDate,     oldXdEntityStp, A_XdEntity, A_XdEntity_BuildDate);
    }
    else
    {
        SET_NULL_ID(toXdEntityStp, A_XdEntity_Id);
        SET_NULL_DICT(toXdEntityStp, A_XdEntity_EntityDictId);
    }

    bool bCreateShadow = false;

    switch (dictBuildRuleEn)
    {
        case XdEntityDictBuildRuleEn::PKOfTheLinkedEntity:
        case XdEntityDictBuildRuleEn::PKAndBKOfTheLinkedEntity:
        case XdEntityDictBuildRuleEn::BKOfTheLinkedEntity:

            SET_ENUM(toXdEntityStp, A_XdEntity_DbRuleEn, DbRule_PrimaryKeyTable);
            SET_NULL_SYSNAME(toXdEntityStp, A_XdEntity_CustSqlName);
            SET_ENUM(toXdEntityStp, A_XdEntity_CustAuthFlg, Custom_No);
            SET_FLAG_FALSE(toXdEntityStp, A_XdEntity_SynonymFlg);
            SET_ENUM(toXdEntityStp, A_XdEntity_DmlModifTrackEn, FeatureAuth_Forbidden);
            SET_ENUM(toXdEntityStp, A_XdEntity_ObjModifStatEn, LastModif_NoTracking);
            SET_ENUM(toXdEntityStp, A_XdEntity_TableModifStatEn, LastModif_NoTracking);
            SET_ENUM(toXdEntityStp, A_XdEntity_LastModifEn, LastModif_NoTracking);
            SET_ENUM(toXdEntityStp, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
            break;

        case XdEntityDictBuildRuleEn::AllLinkedEntityForShadow:

            SET_ENUM(toXdEntityStp, A_XdEntity_PkRuleEn, PkRule_ExternalPk);
            SET_FLAG(toXdEntityStp, A_XdEntity_IdentityFlg, FALSE);
            SET_ENUM(toXdEntityStp, A_XdEntity_DbRuleEn, DbRule_ShadowTable);
            SET_ENUM(toXdEntityStp, A_XdEntity_MultiEntityCategoryEn, MultiEntityCategory_None);
            SET_ENUM(toXdEntityStp, A_XdEntity_ObjModifStatEn, LastModif_NoTracking);
            SET_ENUM(toXdEntityStp, A_XdEntity_TableModifStatEn, LastModif_NoTracking);
            break;

        case XdEntityDictBuildRuleEn::PartialSpecialization:
        {
            SET_ENUM(toXdEntityStp, A_XdEntity_PkRuleEn, PkRule_ExternalPk);
            SET_FLAG(toXdEntityStp, A_XdEntity_IdentityFlg, FALSE);
            SET_ENUM(toXdEntityStp, A_XdEntity_DbRuleEn, DbRule_PartialSpecialization);
            SET_ENUM(toXdEntityStp, A_XdEntity_MultiEntityCategoryEn, MultiEntityCategory_BusinessEntityOnly);
            SET_NULL_SYSNAME(toXdEntityStp, A_XdEntity_CustSqlName);
            SET_ENUM(toXdEntityStp, A_XdEntity_CustAuthFlg, Custom_No);
            SET_ENUM(toXdEntityStp, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
            SET_ENUM(toXdEntityStp, A_XdEntity_InterfaceEn, 0);

            auto xdEntityFeatureMap = this->m_xdEntityFeaturesByEntityMap.find(GET_ID(fromXdEntityStp, A_XdEntity_Id));
            if (xdEntityFeatureMap != this->m_xdEntityFeaturesByEntityMap.end())
            {
                auto changeSetIt = xdEntityFeatureMap->second.find(XdEntityFeatureFeatureEn::ChangeSet);
                if (changeSetIt != xdEntityFeatureMap->second.end() &&
                    GET_A_XdEntityFeature_AuthEn(changeSetIt->second) == XdEntityFeatureAuthEn::FeatureEnable)
                {
                    bCreateShadow = true;
                }
            }
            break;
        }

        case XdEntityDictBuildRuleEn::AllForcePhysical:
            SET_ENUM(toXdEntityStp, A_XdEntity_ObjModifStatEn, LastModif_NoTracking);
            SET_ENUM(toXdEntityStp, A_XdEntity_TableModifStatEn, LastModif_NoTracking);
            break;

        case XdEntityDictBuildRuleEn::None:
        case XdEntityDictBuildRuleEn::AllLinkedEntity:
        case XdEntityDictBuildRuleEn::AllDbAttribLinkedEntity:
        case XdEntityDictBuildRuleEn::UDFieldsOfTheLinkedEntity:
        case XdEntityDictBuildRuleEn::UDFieldsToTheLinkedEntity:
            break;
    }

    if (GET_ENUM(toXdEntityStp, A_XdEntity_CustAuthFlg) != Custom_No)
    {
        toCustSqlname = "ud_" + toEntitySqlname;

        SET_SYSNAME(toXdEntityStp, A_XdEntity_CustSqlName, toCustSqlname.c_str());
    }

    SET_ENUM(toXdEntityStp, A_XdEntity_NatEn, EntityNat_DerivedEntity);
    SET_NULL_ID(toXdEntityStp, A_XdEntity_NatXdAttribId);
    SET_NULL_ID(toXdEntityStp, A_XdEntity_ParentXdAttribId);
    SET_ID(toXdEntityStp, A_XdEntity_LinkedXdEntityId, GET_ID(fromXdEntityStp, A_XdEntity_Id));
    SET_FLAG_FALSE(toXdEntityStp, A_XdEntity_ListFlg);
    SET_FLAG_FALSE(toXdEntityStp, A_XdEntity_SynonymFlg);
    SET_FLAG_FALSE(toXdEntityStp, A_XdEntity_PrecompFlg);

    SET_ENUM(toXdEntityStp, A_XdEntity_ExternalSeqAuthEn, FeatureAuth_Forbidden);
    SET_ENUM(toXdEntityStp, A_XdEntity_UpdFctAuthEn, FeatureAuth_Forbidden);
    
    SET_ENUM(toXdEntityStp, A_XdEntity_XdActionEn, XdAction_ToInsert);

    ID_T recId = 0;
    (void)this->insUpdRecord(toXdEntityStp, recId, DBA_ROLE_UDT, false);

    if (bCreateShadow)
    {
        this->copyXdEntityByName(toXdEntityStp, XdEntityDictBuildRuleEn::AllLinkedEntityForShadow);
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::manageXdEntityFeature()
**
**  Description :   Manage ins/upd of a xd_entity_feature record
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
void DdlGenDbaAccess::manageXdEntityFeature(DBA_DYNFLD_STP xdEntityFeatureStp, size_t batchRank)
{
    if (this->m_kindOfImportFile != DdlGenImportFile::KindOfData::None)
    {
        if (GET_A_XdEntityFeature_FeatureEn(xdEntityFeatureStp) == XdEntityFeatureFeatureEn::ChangeSet &&
            GET_A_XdEntityFeature_AuthEn(xdEntityFeatureStp) == XdEntityFeatureAuthEn::FeatureEnable)
        {
            DBA_DYNFLD_STP xdEntityStp = this->getXdEntityById(GET_ID(xdEntityFeatureStp, A_XdEntityFeature_XdEntityId));

            this->copyXdEntityByName(xdEntityStp, XdEntityDictBuildRuleEn::AllLinkedEntityForShadow);
            this->copyXdEntityByName(xdEntityStp, XdEntityDictBuildRuleEn::PKOfTheLinkedEntity);
        }

        if (GET_A_XdEntityFeature_FeatureEn(xdEntityFeatureStp) == XdEntityFeatureFeatureEn::ExternalPkEntity &&
            GET_A_XdEntityFeature_AuthEn(xdEntityFeatureStp) == XdEntityFeatureAuthEn::FeatureEnable)
        {
            /*PMSTA-56937 - VPR - 240712*/
            DBA_DYNFLD_STP xdEntityStp = this->getXdEntityById(GET_ID(xdEntityFeatureStp, A_XdEntityFeature_XdEntityId));
            this->copyXdEntityByName(xdEntityStp, XdEntityDictBuildRuleEn::PKOfTheLinkedEntity);
        }

        if (GET_A_XdEntityFeature_AuthEn(xdEntityFeatureStp) != XdEntityFeatureAuthEn::FeatureForbidden &&
            (GET_A_XdEntityFeature_AuthEn(xdEntityFeatureStp) == XdEntityFeatureAuthEn::FeatureEnable) ||
            GET_A_XdEntityFeature_GenRuleEn(xdEntityFeatureStp) == XdEntityFeatureGenRuleEn::Always ||
            GET_A_XdEntityFeature_GenRuleEn(xdEntityFeatureStp) == XdEntityFeatureGenRuleEn::AlwaysButVirtual ||
            GET_A_XdEntityFeature_GenRuleEn(xdEntityFeatureStp) == XdEntityFeatureGenRuleEn::AlwaysButCalculated ||
            GET_A_XdEntityFeature_GenRuleEn(xdEntityFeatureStp) == XdEntityFeatureGenRuleEn::AlwaysButDenorm)
        {
            auto dictAttributeTemplateStp = this->getRecordByCode(XdEntity, "dict_attribute_template");
            if (dictAttributeTemplateStp != nullptr)
            {
                auto xdEntityStp = this->getRecordById(XdEntity, GET_ID(xdEntityFeatureStp, A_XdEntityFeature_XdEntityId), true);

                auto xdAttribMap = this->m_xdAttributesByEntityMap.find(GET_ID(dictAttributeTemplateStp, A_XdEntity_Id));

                if (xdAttribMap->second.empty() == false)
                {
                    for (auto xdAttribIt = xdAttribMap->second.begin(); xdAttribIt != xdAttribMap->second.end(); ++xdAttribIt)
                    {
                        if (CMP_DYNFLD(xdEntityFeatureStp, (*xdAttribIt), A_XdEntityFeature_FeatureEn, A_XdAttrib_FeatureEn, EnumType) == 0)
                        {
                            auto newAttribStp = this->duplicateDynStp(FILEINFO, (*xdAttribIt));

                            SET_NULL_ID(newAttribStp, A_XdAttrib_Id);
                            SET_NULL_DICT(newAttribStp, A_XdAttrib_AttribDictId);
                            COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_XdEntityId, xdEntityFeatureStp, A_XdEntityFeature, A_XdEntityFeature_XdEntityId);

                            DBA_DYNFLD_STP existAttribStp = nullptr;
                            this->dbaGet(XdAttrib, UNUSED, newAttribStp, existAttribStp);

                            if (existAttribStp != nullptr)
                            {
                                COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_Id,           existAttribStp, A_XdAttrib, A_XdAttrib_Id);
                                COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId, existAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId);
                                COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_BuildDate,    existAttribStp, A_XdAttrib, A_XdAttrib_BuildDate);
                            }
                            SET_NULL_INT(newAttribStp, A_XdAttrib_Prog);
                            COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_TemplateXdAttribId, (*xdAttribIt), A_XdAttrib, A_XdAttrib_Id);

                            this->insUpdDelRecord(Insert, XdAttrib, DBA_ROLE_UDT, newAttribStp, false, batchRank, xdEntityStp);

                            this->m_ddlGenContext.printMsg(RET_DBA_INFO_EXIST, 
                                                           SYS_Stringer("The attribute ", 
                                                                        GET_SYSNAME(newAttribStp, A_XdAttrib_SqlName), 
                                                                        " copied from dict_attribute_template"));
                        }
                    }
                }
                else
                {
                    this->m_ddlGenContext.printMsg(RET_DBA_ERR_CONNOTFOUND, "Unable to copy dict_attribute_template records, list is empty");
                }

            }
            else
            {
                this->m_ddlGenContext.printMsg(RET_DBA_ERR_CONNOTFOUND, "Unable to copy dict_attribute_template records, entity not found");
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::importAllMetaDict()
**
**  Description :   Import data from file
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211025
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::importAllMetaDict()
{
    RET_CODE     ret = RET_SUCCEED;

    std::map<ENUM_T, std::vector<std::pair<std::string, std::string>>> packageToExtractMap;
    std::vector<DBA_DYNFLD_STP>                                        packageToApplyVector;
    BuildBindOption                                                    buildBindOption(BuildBindOption::Categ::ExportFullObject);

    if (this->m_ddlGenContext.m_bIsInstallFromScratch      == false &&
        this->m_ddlGenContext.ddlGenAction.m_ddlObjNatEn   == DbObjDdlObjNat_AllTable &&
        this->m_ddlGenContext.ddlGenAction.m_bSingleEntity == false &&
        this->m_ddlGenContext.getDdlGenEntityPtr("package_definition") != nullptr)
    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        RequestHelper  requestHelper(&ddlGenConnGuard.getDbiConn());
        requestHelper.setReadOnly(true);
        requestHelper.m_useAlternativeDataServer = true;

        std::string packageKeyCmd("select xe.sqlname_c, pc.key_c, pc.action_e "
                                  "from package_definition pd "
                                  "inner join package_installation pi2 on pd.id = pi2.package_definition_id "
                                  "inner join package_composition pc on pc.package_definition_id = pd.id "
                                  "inner join package_entity pe on pe.id = pc.package_entity_id "
                                  "inner join xd_entity xe on xe.entity_dict_id = pe.entity_dict_id "
                                  "where pe.install_index_n < 10");

        requestHelper.setCommand(packageKeyCmd);

        char* entitySqlName = nullptr;
        char* keyC = nullptr;
        ENUM_T* actionEn = nullptr;

        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(entitySqlName);
        requestHelper.addNewOutputData(String1000Type);
        requestHelper.getBindVariablePtr(keyC);
        requestHelper.addNewOutputData(EnumType);
        requestHelper.getBindVariablePtr(actionEn);

        if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {
                packageToExtractMap[*actionEn].push_back(std::make_pair(entitySqlName, keyC));
            }
        }

        auto actionIt = packageToExtractMap.find(static_cast<ENUM_T>(PackageCompositionActionEn::Extend));
        if (actionIt != packageToExtractMap.end())
        {
            for (auto& it : actionIt->second)
            {
                std::stringstream fullPckStream;
                fullPckStream << "{\"" << it.first << "\" : " << it.second << "}";

                ret = DBA_GetDynStpFromJSonString(fullPckStream.str(),
                                                  packageToApplyVector,
                                                  buildBindOption,
                                                  this->m_mp,
                                                  ddlGenConnGuard.getDbiConn(),
                                                  true);

                this->m_ddlGenContext.printMsg(RET_DBA_INFO_EXIST,
                                               SYS_Stringer("The insertion of ", fullPckStream.str(), " will be proceeded"));

            }
        }
    }

    if (this->m_ddlGenContext.ddlGenAction.m_bInitEntityOnly || 
        this->m_ddlGenContext.m_bIsInstallFromScratch ||
        this->m_ddlGenContext.ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable)
    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

        this->load("script_definition", dbiConnHelper);
        ITFC_CONTEXT_ST context;
        context.mode = TripleAMode;
        ITFC_Init(&context);
        DdlGenImportFile scptDefImpFile(this->m_ddlGenContext.getAaaHomePath(), "/install", "md_system_script_definition", "imp", DdlGenImportFile::KindOfData::ScriptDef);
        this->importData(scptDefImpFile, &context);
        ITFC_Done(&context);
    }

    this->resetAllMetaDict();

    std::vector<DdlGenImportFile>    dirVector;
    std::vector<DdlGenImportFile>    importFileVector;

    EV_OptiMemFlg = FALSE;

    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/sys", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));

    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/std", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/tech", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/temptb", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/tsl", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/pck", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/ddl/md/ds", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/ddl/md/usr", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));

    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getDdlGenPath(), "/md/opt", std::string(), std::string(), DdlGenImportFile::KindOfData::OptionMetaDictionary));

    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/ddl/md/feature", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/ddl/md/mb", std::string(), std::string(), DdlGenImportFile::KindOfData::MetaDictionary));
    dirVector.push_back(DdlGenImportFile(this->m_ddlGenContext.getAaaHomePath(), "/ddl/md/custo", std::string(), std::string(), DdlGenImportFile::KindOfData::CustoMetaDictionary));

    for (auto dirIt = dirVector.begin(); dirIt != dirVector.end(); ++dirIt)
    {
        std::vector<SYS_FileInfo> fileList;

        if (dirIt->m_kindOfData == DdlGenImportFile::KindOfData::OptionMetaDictionary)
        {
            auto & optionSectionVector = this->m_ddlGenContext.getCfgFileHelper().optionSectionVector;
            for (auto optFileIt = optionSectionVector.begin(); optFileIt != optionSectionVector.end(); ++optFileIt)
            {
                std::string::size_type extPos = std::string::npos;

                if (optFileIt->apply == "<YES>" &&
                    (extPos = optFileIt->fileName.find(".imp")) == optFileIt->fileName.size() - 4)
                {
                    importFileVector.push_back(DdlGenImportFile(dirIt->getRootPath(),
                                               dirIt->getPath(),
                                               optFileIt->fileName.substr(0, extPos),
                                               optFileIt->fileName.substr(extPos + 1),
                                               DdlGenImportFile::KindOfData::MetaDictionary));
                }
            }
        }
        else if (SYS_DIRentryList(dirIt->getFullPath(), fileList, true))
        {
            for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
            {
                std::string::size_type extPos = std::string::npos;
                if (fileIt->isFile &&
                    fileIt->isReadable &&
                    (extPos = fileIt->fileName.find(".imp")) == fileIt->fileName.size() - 4)
                {
                    importFileVector.push_back(DdlGenImportFile(dirIt->getRootPath(),
                                                                dirIt->getPath(),
                                                                fileIt->fileName.substr(0, extPos), 
                                                                fileIt->fileName.substr(extPos + 1), 
                                                                (*dirIt).m_kindOfData));
                }
            }
            for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
            {
                std::string::size_type extPos = std::string::npos;
                if (fileIt->isFile &&
                    fileIt->isReadable &&
                    (extPos = fileIt->fileName.find(".imp_2")) == fileIt->fileName.size() - 6)
                {
                    importFileVector.push_back(DdlGenImportFile(dirIt->getRootPath(),
                                                                dirIt->getPath(),
                                                                fileIt->fileName.substr(0, extPos),
                                                                fileIt->fileName.substr(extPos + 1),
                                                                (*dirIt).m_kindOfData));
                }
            }
        }
    }

    
    ITFC_CONTEXT_ST context;
    context.mode = TripleAMode;
    ITFC_Init(&context);

    DdlGenImportFile tplAttribImpFile(this->m_ddlGenContext.getDdlGenPath(), "/md/sys", "1137_dict_attribute_template", "imp", DdlGenImportFile::KindOfData::MetaDictionary);

    auto pivot = std::find_if(importFileVector.begin(),
                              importFileVector.end(),
                              [&tplAttribImpFile](const DdlGenImportFile& s) -> bool
                              {
                                  return s.getFileName() == tplAttribImpFile.getFileName();
                              });
    if (pivot != importFileVector.end())
    {
        std::rotate(importFileVector.begin(), pivot, pivot + 1);
    }

    RET_CODE gblRet = ret;
    bool     bFirstPck = true;

    for (auto impIt = importFileVector.begin(); impIt != importFileVector.end(); ++impIt)
    {
        if ((ret = this->importData((*impIt), &context)) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        auto     nextIt = impIt + 1; 
        if (bFirstPck &&
            (nextIt == importFileVector.end() ||
             nextIt->m_kindOfData == DdlGenImportFile::KindOfData::PckMetaDictionary ||
             nextIt->m_kindOfData == DdlGenImportFile::KindOfData::CustoMetaDictionary))
        {
            auto actionIt = packageToExtractMap.find(static_cast<ENUM_T>(PackageCompositionActionEn::Remove));
            if (actionIt != packageToExtractMap.end())
            {
                DdlGenConnGuard              ddlGenConnGuard(this->m_ddlGenContext);
                std::vector<DBA_DYNFLD_STP>  packageToDeleteVector;

                buildBindOption.setOutputMode(NullEntity, Null_Dynfld, EntityConfigOutputModeEn::BusinessKey);
                for (auto& it : actionIt->second)
                {
                    std::stringstream fullPckStream;
                    fullPckStream << "{\"" << it.first << "\" : " << it.second << "}";

                    ret = DBA_GetDynStpFromJSonString(fullPckStream.str(),
                                                      packageToApplyVector,
                                                      buildBindOption,
                                                      this->m_mp,
                                                      ddlGenConnGuard.getDbiConn(),
                                                      true);

                    this->m_ddlGenContext.printMsg(RET_DBA_INFO_EXIST,
                                                   SYS_Stringer("Delete processing of ", fullPckStream.str()));

                }

                for (auto& it : packageToApplyVector)
                {
                    this->insUpdDelFullRecord(Delete, it);
                }
            }

            for (auto& it : packageToApplyVector)
            {
                this->insUpdDelFullRecord(Insert, it);
            }

            bFirstPck = false;
        }
    }

    ITFC_Done(&context);

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isLoaded()
**
**  Description :   Is empty
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isLoaded(DBA_DYNFLD_STP xdEntityStp)
{
    if ((this->m_isMetaDictLoaded == false || this->m_isExtendedLoaded == false) && xdEntityStp != nullptr)
    {
        std::string sqlName = (xdEntityStp->isAllDynSt() ? GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName) : GET_SYSNAME(xdEntityStp, S_XdEntity_SqlName));

        return (this->m_isLoadedXdEntitySet.find(sqlName) != this->m_isLoadedXdEntitySet.end());
    }
    return this->m_isMetaDictLoaded && this->m_isExtendedLoaded;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isLoaded()
**
**  Description :   Is empty
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isLoaded(OBJECT_ENUM objectEn)
{
    return (this->m_isLoadedObjectSet.find(objectEn) != this->m_isLoadedObjectSet.end());
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::loadManagement()
**
**  Description :   Management of the loading of data
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231114
**
*************************************************************************/
void DdlGenDbaAccess::loadManagement(OBJECT_ENUM objectEn)
{
    if (this->isLoaded(objectEn) == false &&
        this->m_isLoadAvoidedObjectSet.find(objectEn) == m_isLoadAvoidedObjectSet.end())
    {
        auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp->bIsInitEntity ||
            dictEntityStp->objectEn == DictFct ||
            dictEntityStp->objectEn == TslPrecJobElementCompo ||
            dictEntityStp->objectEn == TslPrecJobElement ||
            dictEntityStp->objectEn == TslPrecJob ||
            dictEntityStp->objectEn == ReportFinServiceFormat)
        {
            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

            this->load(dictEntityStp->mdSqlName, dbiConnHelper);
        }
    }
    else
    {
        this->m_isLoadAvoidedObjectSet.insert(objectEn);
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isLoaded()
**
**  Description :   Is empty
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isLoaded(DDL_OBJ_ENUM ddlObjEn)
{
    if (this->m_isMetaDictLoaded == true)
    {
        return (this->m_allDdlObjLoadedSet.find(ddlObjEn) != this->m_allDdlObjLoadedSet.end());
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::getData(DdlGenEntity &ddlGenEntity, bool bForceLoad)
{
    LockGuard lockGuard(this->m_lock);

    ddlGenEntity.m_xdEntityStp = this->getXdEntityBySqlName(ddlGenEntity.m_sqlName);

    if (ddlGenEntity.m_xdEntityStp != nullptr)
    {
        if (ddlGenEntity.m_sqlName != ddlGenEntity.m_targetSqlName)
        {
            ddlGenEntity.m_xdEntityStp = this->m_mp.duplicate(FILEINFO, ddlGenEntity.m_xdEntityStp);
        }

        ddlGenEntity.aDictEntityStp = this->getDictEntityBySqlName(ddlGenEntity.m_sqlName);
        ddlGenEntity.m_xdAttribVector = this->m_xdAttributesByEntityMap[GET_ID(ddlGenEntity.m_xdEntityStp, A_XdEntity_Id)];
        ddlGenEntity.sortAttributes();

        for (auto attribIt = ddlGenEntity.m_xdAttribVector.begin(); attribIt != ddlGenEntity.m_xdAttribVector.end(); ++attribIt)
        {
            ID_T permValAttribId = (IS_NULLFLD((*attribIt), A_XdAttrib_ParentXdAttribId) == FALSE && this->m_isMetaDictLoaded ?
                                    GET_ID((*attribIt), A_XdAttrib_ParentXdAttribId) :
                                    GET_ID((*attribIt), A_XdAttrib_Id));

            auto xdPemValuesMapIt = this->m_xdPemValuesByXdAttribNatMap.find(permValAttribId);
            if (xdPemValuesMapIt != this->m_xdPemValuesByXdAttribNatMap.end())
            {
                auto& xdAttribPermValMap = ddlGenEntity.m_xdAttrPermValMap[permValAttribId];

                if (xdAttribPermValMap.empty())
                {
                    for (auto permValIt = xdPemValuesMapIt->second.begin(); permValIt != xdPemValuesMapIt->second.end(); ++permValIt)
                    {
                        xdAttribPermValMap.insert(std::make_pair(GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn), permValIt->second));
                        ddlGenEntity.m_xdPermValMap.insert(std::make_pair(GET_ID(permValIt->second, A_XdPermVal_Id), permValIt->second));
                    }
                }
            }

            if (permValAttribId != GET_ID((*attribIt), A_XdAttrib_Id))
            {
                xdPemValuesMapIt = this->m_xdPemValuesByXdAttribNatMap.find(GET_ID((*attribIt), A_XdAttrib_Id));
                if (xdPemValuesMapIt != this->m_xdPemValuesByXdAttribNatMap.end())
                {
                    auto& xdAttribPermValMap = ddlGenEntity.m_xdAttrPermValMap[GET_ID((*attribIt), A_XdAttrib_Id)];

                    if (xdAttribPermValMap.empty())
                    {
                        for (auto permValIt = xdPemValuesMapIt->second.begin(); permValIt != xdPemValuesMapIt->second.end(); ++permValIt)
                        {
                            xdAttribPermValMap.insert(std::make_pair(GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn), permValIt->second));
                            ddlGenEntity.m_xdPermValMap.insert(std::make_pair(GET_ID(permValIt->second, A_XdPermVal_Id), permValIt->second));
                        }
                    }
                }
            }
        }

        ddlGenEntity.xdEntityFeatureMap = this->m_xdEntityFeaturesByEntityMap[GET_ID(ddlGenEntity.m_xdEntityStp, A_XdEntity_Id)];
        ddlGenEntity.m_xdPartitionVector = this->m_xdPartitionByEntityMap[GET_ID(ddlGenEntity.m_xdEntityStp, A_XdEntity_Id)];

        auto xdAttribCustoMap = this->m_xdAttribCustoByEntityMap.find(GET_ID(ddlGenEntity.m_xdEntityStp, A_XdEntity_Id));
        if (xdAttribCustoMap != this->m_xdAttribCustoByEntityMap.end())
        {
            for (auto &it : xdAttribCustoMap->second)
            {
                ddlGenEntity.m_xdAttribCustoMap[GET_ID(it, A_XdAttributeCusto_XdAttribId)].push_back(it);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::fillExtFromMemory()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231124
**
*************************************************************************/
void DdlGenDbaAccess::fillExtFromMemory(DdlGenEntity &ddlGenEntity)
{
    LockGuard lockGuard(this->m_lock);

    ddlGenEntity.m_xdEntityStp = this->getXdEntityBySqlName(ddlGenEntity.m_sqlName);

    if (ddlGenEntity.m_xdEntityStp != nullptr)
    {
        MemoryPool mp;

        /* sel_fmt_elt_from_tsl_prec_job */
        auto &tslPrecJobMap         = this->selAllRecords(TslPrecJob, true, false);

        DBA_DYNFLD_STP tslPrecJobStp = nullptr;

        std::vector<TslPrecJobPackagingNatEn> tslPrecJobPackagingNatEnVector;

        tslPrecJobPackagingNatEnVector.push_back(TslPrecJobPackagingNatEn::Custom);
        tslPrecJobPackagingNatEnVector.push_back(TslPrecJobPackagingNatEn::ModelBank);
        tslPrecJobPackagingNatEnVector.push_back(TslPrecJobPackagingNatEn::Standard);

        for (auto &tslPrecJobPackagingNatEnIt : tslPrecJobPackagingNatEnVector)
        {
            for (auto tslPrecJobIt : tslPrecJobMap)
            {
                if (GET_A_TslPrecJob_NatEn(tslPrecJobIt.second) == TslPrecJobNatEn::MasterExtension &&
                    GET_A_TslPrecJob_PackagingNatEn(tslPrecJobIt.second) == tslPrecJobPackagingNatEnIt &&
                    CMP_DYNFLD(tslPrecJobIt.second, ddlGenEntity.m_xdEntityStp, A_TslPrecJob_EntityDictId, A_XdEntity_EntityDictId, DictType) == 0 &&
                    (tslPrecJobStp == nullptr ||
                     CMP_DYNFLD(tslPrecJobIt.second, tslPrecJobStp, A_TslPrecJob_Priority, A_TslPrecJob_Priority, NumberType) > 0))
                {
                    tslPrecJobStp = tslPrecJobIt.second;
                }
            }

            if (tslPrecJobStp != nullptr)
            {
                std::map<std::string, DBA_DYNFLD_STP> fmtMap;
                std::vector<DBA_DYNFLD_STP>           tslPrecJobEltVector;

                this->selRecordsByParent(TslPrecJobElement, GET_ID(tslPrecJobStp, A_TslPrecJob_Id), true, tslPrecJobEltVector);
                for (auto tslPrecJobEltIt : tslPrecJobEltVector)
                {
                    std::vector<DBA_DYNFLD_STP> tslPrecJobEltCompoVector;
                    this->selRecordsByParent(TslPrecJobElementCompo, GET_ID(tslPrecJobEltIt, A_TslPrecJobElement_Id), true, tslPrecJobEltCompoVector);

                    for (auto tslPrecJobEltCompoIt : tslPrecJobEltCompoVector)
                    {
                        auto fmtStp = this->getRecordById(Fmt, GET_ID(tslPrecJobEltCompoIt, A_TslPrecJobElementCompo_FmtId), true);
                        fmtMap[GET_CODE(fmtStp, A_Fmt_Cd)] = fmtStp;
                    }
                }

                for (auto &fmtIt : fmtMap)
                {
                    std::vector<DBA_DYNFLD_STP> fmtEltVector;
                    this->selRecordsByParent(FmtElt, GET_ID(fmtIt.second, A_Fmt_Id), true, fmtEltVector);

                    std::sort(fmtEltVector.begin(), fmtEltVector.end(),
                              [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                              {
                                  int iCmp = CMP_DYNFLD(a, b, A_FmtElt_DispColumn, A_FmtElt_DispColumn, SmallintType);
                                  if (iCmp < 0)
                                  {
                                      return true;
                                  }
                                  else if (iCmp != 0)
                                  {
                                      return false;
                                  }
                                  iCmp = CMP_DYNFLD(a, b, A_FmtElt_Rank, A_FmtElt_Rank, SmallintType);
                                  if (iCmp < 0)
                                  {
                                      return true;
                                  }
                                  else if (iCmp != 0)
                                  {
                                      return false;
                                  }
                                  return CMP_DYNFLD(a, b, A_FmtElt_SqlName, A_FmtElt_SqlName, SysnameType) < 0;
                              });

                    for (auto &fmtEltIt : fmtEltVector)
                    {
                        if (GET_FLAG(fmtEltIt, A_FmtElt_TslExtensionFlg) == TRUE)
                        {
                            ddlGenEntity.m_extFmtEltVector.push_back(fmtEltIt);

                            std::vector<DBA_DYNFLD_STP> denomVector;
                            this->selRecordsByParent(Denom, GET_ID(fmtEltIt, A_FmtElt_Id), true, denomVector, FmtElt);

                            std::sort(denomVector.begin(), denomVector.end(),
                                      [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                                      {
                                          return CMP_DYNFLD(a, b, A_Denom_LangEntDictId, A_Denom_LangEntDictId, DictType) < 0;
                                      });

                            for (auto& denomStp : denomVector)
                            {
                                ddlGenEntity.m_extFmtEltDenomMap[GET_ID(denomStp, A_Denom_ObjId)].push_back(denomStp);
                            }
                        }
                    }
                }

                break;
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getExtendedData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211104
**
*************************************************************************/
void DdlGenDbaAccess::getExtendedData(DdlGenEntity &ddlGenEntity)
{
    if (ddlGenEntity.bIsExtLoaded == false)
    {
        LockGuard lockGuard(this->m_lock);

        if (ddlGenEntity.bIsIdxLoaded == false && this->isLoaded(XdIndex))
        {
            auto xIndexVectorIt = this->m_xdIndexByEntityMap.find(GET_ID(ddlGenEntity.m_xdEntityStp, A_XdEntity_Id));
            if (xIndexVectorIt != this->m_xdIndexByEntityMap.end())
            {
                for (auto idxIt = xIndexVectorIt->second.begin(); idxIt != xIndexVectorIt->second.end(); ++idxIt)
                {
                    if (ddlGenEntity.m_sqlName == ddlGenEntity.m_targetSqlName)
                    {
                        ddlGenEntity.m_xdIndexVector.push_back((*idxIt));

                        auto& xdIndexAttribVector = this->m_xdIndexAttribByIndexMap[GET_ID((*idxIt), A_XdIndex_Id)];

                        for (auto idxAttribIt = xdIndexAttribVector.begin(); idxAttribIt != xdIndexAttribVector.end(); ++idxAttribIt)
                        {
                            ddlGenEntity.m_xdIndexAttribMapVector[(*idxIt)].push_back((*idxAttribIt));
                        }

                        auto& xdPartitonIndexVector = this->m_xdPartitonIndexByIndexMap[GET_ID((*idxIt), A_XdIndex_Id)];

                        for (auto idxPartitonIt = xdPartitonIndexVector.begin(); idxPartitonIt != xdPartitonIndexVector.end(); ++idxPartitonIt)
                        {
                            ddlGenEntity.m_xdPartitionIndexMapVector[(*idxIt)].push_back((*idxPartitonIt));
                        }
                    }
                    else if (GET_ENUM((*idxIt), A_XdIndex_IdxFctEn) != IdxFunction_FromTemplate)
                    {
                        auto xdIndexStp = this->m_mp.duplicate(FILEINFO, (*idxIt));

                        SET_NULL_ID(xdIndexStp, A_XdIndex_Id);

                        ddlGenEntity.m_xdIndexVector.push_back(xdIndexStp);

                        auto& xdIndexAttribVector = this->m_xdIndexAttribByIndexMap[GET_ID((*idxIt), A_XdIndex_Id)];

                        for (auto idxAttribIt = xdIndexAttribVector.begin(); idxAttribIt != xdIndexAttribVector.end(); ++idxAttribIt)
                        {
                            if (GET_ENUM((*idxAttribIt), A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted)
                            {
                                auto xdIndexAttribStp = this->m_mp.duplicate(FILEINFO, (*idxAttribIt));

                                SET_NULL_ID(xdIndexAttribStp, A_XdIndexAttrib_Id);

                                ddlGenEntity.m_xdIndexAttribMapVector[xdIndexStp].push_back(xdIndexAttribStp);
                            }
                        }
                    }
                }
            }

            ddlGenEntity.bIsIdxLoaded = true;
        }

        if (ddlGenEntity.m_xdEntityStp != nullptr &&
            IS_NULLFLD(ddlGenEntity.m_xdEntityStp, A_XdEntity_EntityDictId) == FALSE &&
            (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension ||
            (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
            this->m_ddlGenContext.ddlGenAction.m_bSingleEntity)))
        {
            auto depEltMap = this->m_dictEntityDependsByDepEntityMap.find(GET_DICT(ddlGenEntity.m_xdEntityStp, A_XdEntity_EntityDictId));
            if (depEltMap != this->m_dictEntityDependsByDepEntityMap.end())
            {
                for (auto it = depEltMap->second.begin(); it != depEltMap->second.end(); ++it)
                {
                    this->m_ddlGenContext.depEntityPscSqlNameSet.insert(GET_SYSNAME((*it), A_DictDepends_GenEntityName));

                    if (this->m_ddlGenContext.bForceReBuild == false)
                    {
                        this->m_ddlGenContext.depSprocSqlNameSet.insert(GET_SYSNAME((*it), A_DictDepends_SqlName));
                    }
                }
            }
        }

        ddlGenEntity.bIsExtLoaded = true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getLabels()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::getLabels(DdlGenEntity &ddlGenEntity)
{
    LockGuard lockGuard(this->m_lock);
    DICT_T xdEntityDictId, xdAttribDictId, xdPermValDictId;

    DBA_GetDictId(XdEntity, &xdEntityDictId);
    DBA_GetDictId(XdAttrib, &xdAttribDictId);
    DBA_GetDictId(XdPermVal, &xdPermValDictId);

    DICT_T            enLangDictId = 1;
    std::vector<DICT_LANG_ST> dictLangTab = DBA_GetDictLangTab();
    for (auto it = dictLangTab.begin(); it != dictLangTab.end(); ++it)
    {
        if (strcmp(it->code, "en") == 0)
        {
            enLangDictId = it->dictId;
            break;
        }
    }

    XdLabelNatEn entXdLabelNatEn = (GET_ENUM(ddlGenEntity.getXdEntityStp(), A_XdEntity_NatEn) == EntityNat_Custom ||
                                    GET_ENUM(ddlGenEntity.getXdEntityStp(), A_XdEntity_NatEn) == EntityNat_CustomDS) ? XdLabelNatEn::UserDefined : XdLabelNatEn::Application;


    auto& xdEntityLabels = this->m_xdLabelMap[xdEntityDictId][GET_ID(ddlGenEntity.getXdEntityStp(), A_XdEntity_Id)];

    if (ddlGenEntity.getDictEntityStp()->entNatEn == EntityNat_Questionnaire)
    {
        for (auto& chkLabelsMapIt : xdEntityLabels)
        {
            for (auto& chkLabelsIt : chkLabelsMapIt.second)
            {
                if (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToDeprecate)
                {
                    SET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn, XdAction_ToInsert);
                }
            }
        }
    }

    bool bOneEnValid = false;
    for (auto& chkLabelsMapIt : xdEntityLabels)
    {
        if (chkLabelsMapIt.first == enLangDictId)
        {
            for (auto& chkLabelsIt : chkLabelsMapIt.second)
            {
                if ((GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                     (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_None &&
                      GET_ENUM(chkLabelsIt.second, A_XdLabel_XdStatusEn) == XdStatus_Inserted)))
                {
                    bOneEnValid = true;
                    break;
                }
            }
        }
        if (bOneEnValid)
        {
            break;
        }
    }
    if (bOneEnValid == false)
    {
        auto newLabelStp = this->m_mp.allocDynst(FILEINFO, A_XdLabel);

        SET_DICT(newLabelStp, A_XdLabel_EntityDictId, xdEntityDictId);
        SET_ID(newLabelStp, A_XdLabel_ObjId, GET_ID(ddlGenEntity.getXdEntityStp(), A_XdEntity_Id));
        SET_ID(newLabelStp, A_XdLabel_LangDictId, enLangDictId);
        SET_A_XdLabel_NatEn(newLabelStp, entXdLabelNatEn);
        COPY_DYNFLD(newLabelStp, A_XdLabel, A_XdLabel_Name, ddlGenEntity.getXdEntityStp(), A_XdEntity, A_XdEntity_Name);
        SET_A_XdLabel_XdActionEn(newLabelStp, XdEntityXdActionEn::ToInsert);

        ID_T recId = 0;
        this->insUpdRecord(newLabelStp, recId, UNUSED, false);
    }

    ddlGenEntity.m_xdEntityLabelMap = xdEntityLabels;

    for (auto attribIt = ddlGenEntity.m_xdAttribVector.begin(); attribIt != ddlGenEntity.m_xdAttribVector.end(); ++attribIt)
    {
        auto& xdAttribLabels = this->m_xdLabelMap[xdAttribDictId][GET_ID((*attribIt), A_XdAttrib_Id)];

        if (ddlGenEntity.getDictEntityStp()->entNatEn == EntityNat_Questionnaire)
        {
            for (auto& chkLabelsMapIt : xdAttribLabels)
            {
                for (auto& chkLabelsIt : chkLabelsMapIt.second)
                {
                    if (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToDeprecate)
                    {
                        SET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn, XdAction_ToInsert);
                    }
                }
            }
        }

        bOneEnValid = false;
        for (auto& chkLabelsMapIt : xdAttribLabels)
        {
            if (chkLabelsMapIt.first == enLangDictId)
            {
                for (auto& chkLabelsIt : chkLabelsMapIt.second)
                {
                    if ((GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                         (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_None &&
                          GET_ENUM(chkLabelsIt.second, A_XdLabel_XdStatusEn) == XdStatus_Inserted)))
                    {
                        bOneEnValid = true;
                        break;
                    }
                }
            }

            if (bOneEnValid)
            {
                break;
            }
        }

        if (bOneEnValid == false &&
            GET_FLAG((*attribIt), A_XdAttrib_ShortOnlyFlg) == TRUE &&
            IS_NULLFLD((*attribIt), A_XdAttrib_RefXdEntityId) == false)
        {
            auto &refEntityLabels = this->m_xdLabelMap[xdEntityDictId][GET_ID((*attribIt), A_XdAttrib_RefXdEntityId)];

            for (auto it = refEntityLabels.begin(); it != refEntityLabels.end(); ++it)
            {
                for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
                {
                    auto newLabelStp = this->m_mp.duplicate(FILEINFO, it2->second);

                    SET_NULL_ID(newLabelStp, A_XdLabel_Id);
                    SET_DICT(newLabelStp, A_XdLabel_EntityDictId, xdAttribDictId);
                    SET_ID(newLabelStp, A_XdLabel_ObjId, GET_ID((*attribIt), A_XdAttrib_Id));

                    ID_T recId = 0;
                    this->insUpdRecord(newLabelStp, recId, UNUSED, false);

                    bOneEnValid = true;
                }
            }
        }

        if (bOneEnValid == false && 
            IS_NULLFLD((*attribIt), A_XdAttrib_TemplateXdAttribId) == false)
        {
            auto& xdAttribTpltLabels = this->m_xdLabelMap[xdAttribDictId][GET_ID((*attribIt), A_XdAttrib_TemplateXdAttribId)];

            for (auto it = xdAttribTpltLabels.begin(); it != xdAttribTpltLabels.end(); ++it)
            {
                for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
                {
                    auto newLabelStp = this->m_mp.duplicate(FILEINFO, it2->second);

                    SET_NULL_ID(newLabelStp, A_XdLabel_Id);
                    SET_DICT(newLabelStp, A_XdLabel_EntityDictId, xdAttribDictId);
                    SET_ID(newLabelStp, A_XdLabel_ObjId, GET_ID((*attribIt), A_XdAttrib_Id));

                    ID_T recId = 0;
                    this->insUpdRecord(newLabelStp, recId, UNUSED, false);

                    bOneEnValid = true;
                }
            }
        }

        if (bOneEnValid == false)
        {
            auto newLabelStp = this->m_mp.allocDynst(FILEINFO, A_XdLabel);

            SET_DICT(newLabelStp, A_XdLabel_EntityDictId, xdAttribDictId);
            SET_ID(newLabelStp, A_XdLabel_ObjId, GET_ID((*attribIt), A_XdAttrib_Id));
            SET_ID(newLabelStp, A_XdLabel_LangDictId, enLangDictId);
            SET_A_XdLabel_NatEn(newLabelStp, GET_ENUM((*attribIt), A_XdAttrib_CustomFlg) == Custom_No ? entXdLabelNatEn : XdLabelNatEn::UserDefined);
            COPY_DYNFLD(newLabelStp, A_XdLabel, A_XdLabel_Name, (*attribIt), A_XdAttrib, A_XdAttrib_Name);
            SET_A_XdLabel_XdActionEn(newLabelStp, XdEntityXdActionEn::ToInsert);

            ID_T recId = 0;
            this->insUpdRecord(newLabelStp, recId, UNUSED, false);
        }

        ddlGenEntity.m_xdAttribLabelMap[GET_ID((*attribIt), A_XdAttrib_Id)] = xdAttribLabels;

        if (IS_NULLFLD((*attribIt), A_XdAttrib_ParentXdAttribId) == TRUE)
        {
            auto xdPemValuesMapIt = this->m_xdPemValuesByXdAttribNatMap.find(GET_ID((*attribIt), A_XdAttrib_Id));
            if (xdPemValuesMapIt != this->m_xdPemValuesByXdAttribNatMap.end())
            {
                for (auto permValIt = xdPemValuesMapIt->second.begin(); permValIt != xdPemValuesMapIt->second.end(); ++permValIt)
                {
                    auto& xdPermValLabels = this->m_xdLabelMap[xdPermValDictId][GET_ID(permValIt->second, A_XdPermVal_Id)];

                    if (ddlGenEntity.getDictEntityStp()->entNatEn == EntityNat_Questionnaire)
                    {
                        for (auto& chkLabelsMapIt : xdPermValLabels)
                        {
                            for (auto& chkLabelsIt : chkLabelsMapIt.second)
                            {
                                if (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToDeprecate)
                                {
                                    SET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn, XdAction_ToInsert);
                                }
                            }
                        }
                    }

                    bOneEnValid = false;
                    for (auto& chkLabelsMapIt : xdPermValLabels)
                    {
                        if (chkLabelsMapIt.first == enLangDictId)
                        {
                            for (auto& chkLabelsIt : chkLabelsMapIt.second)
                            {
                                if ((GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                                     (GET_ENUM(chkLabelsIt.second, A_XdLabel_XdActionEn) == XdAction_None &&
                                      GET_ENUM(chkLabelsIt.second, A_XdLabel_XdStatusEn) == XdStatus_Inserted)))
                                {
                                    bOneEnValid = true;
                                    break;
                                }
                            }
                        }
                        if (bOneEnValid)
                        {
                            break;
                        }
                    }

                    if (bOneEnValid == false)
                    {
                        auto newLabelStp = this->m_mp.allocDynst(FILEINFO, A_XdLabel);

                        SET_DICT(newLabelStp, A_XdLabel_EntityDictId, xdPermValDictId);
                        SET_ID(newLabelStp, A_XdLabel_ObjId, GET_ID(permValIt->second, A_XdPermVal_Id));
                        SET_ID(newLabelStp, A_XdLabel_LangDictId, enLangDictId);
                        SET_A_XdLabel_NatEn(newLabelStp, GET_ENUM((*attribIt), A_XdAttrib_CustomFlg) == Custom_No ? entXdLabelNatEn : XdLabelNatEn::UserDefined);
                        COPY_DYNFLD(newLabelStp, A_XdLabel, A_XdLabel_Name, permValIt->second, A_XdPermVal, A_XdPermVal_Name);
                        SET_A_XdLabel_XdActionEn(newLabelStp, XdEntityXdActionEn::ToInsert);

                        ID_T recId = 0;
                        this->insUpdRecord(newLabelStp, recId, UNUSED, false);
                    }

                    ddlGenEntity.m_xdPermValLabelMap[GET_ID(permValIt->second, A_XdPermVal_Id)] = xdPermValLabels;
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getRecordByCode
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getRecordByCode(OBJECT_ENUM objectEn, const std::string &code)
{
    LockGuard       lockGuard(this->m_lock);

    auto &allRecordsMap = this->getCodeByObjEnMap(objectEn);
    auto recordIt = allRecordsMap.find(code);

    if (recordIt != allRecordsMap.end())
    {
        return recordIt->second;
    }

    if (this->isLoaded(objectEn) == false)
    {
        auto &isLoadedSet = this->m_isLoadedByCodeMap[objectEn];

        if (isLoadedSet.find(code) == isLoadedSet.end())
        {
            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

            this->loadByCode(objectEn, code, dbiConnHelper);

            recordIt = allRecordsMap.find(code);
            if (recordIt != allRecordsMap.end())
            {
                return recordIt->second;
            }
        }
    }

    return nullptr;
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getRecordById
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getRecordById(OBJECT_ENUM objectEn, ID_T id, bool bLoad)
{
    LockGuard       lockGuard(this->m_lock);

    if (objectEn == NullEntity)
    {
        if (id < 0)
        {
            auto it = this->m_recordNewId.find(id);
            if (it != this->m_recordNewId.end())
            {
                return it->second;
            }
        }

        {
            auto it = this->m_newIdLinks.find(id);
            if (it != this->m_newIdLinks.end())
            {
                objectEn = it->second.first;
                id       = it->second.second;
            }
            else
            {
                SYS_BreakOnDebug();
                return nullptr;
            }
        }
    }

    auto &allRecordsMap = this->getIdByObjEnMap(objectEn);
    auto recordIt = allRecordsMap.find(id);

    if (recordIt != allRecordsMap.end())
    {
        return recordIt->second;
    }

    if (bLoad && this->isLoaded(objectEn) == false)
    {
        auto &isLoadedSet = this->m_isLoadedByIdMap[objectEn];

        if (isLoadedSet.find(id) == isLoadedSet.end())
        {
            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

            this->loadById(objectEn, id, dbiConnHelper);

            recordIt = allRecordsMap.find(id);
            if (recordIt != allRecordsMap.end())
            {
                return recordIt->second;
            }
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getDdlObjDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlObjDef *DdlGenDbaAccess::getDdlObjDef(DdlObjDefKey &ddlObjDefKey)
{
    auto allDdlObjIt = this->m_allDdlObjDefMap.find(ddlObjDefKey.getDdlObjEn());

    if (allDdlObjIt != this->m_allDdlObjDefMap.end())
    {
        auto ddlObjIt = allDdlObjIt->second.find(ddlObjDefKey);
        if (ddlObjIt != allDdlObjIt->second.end())
        {
            return &ddlObjIt->second;
        }
    }
    else
    {
        this->addDdlObjDefByKey(ddlObjDefKey);

        allDdlObjIt = this->m_allDdlObjDefMap.find(ddlObjDefKey.getDdlObjEn());

        if (allDdlObjIt != this->m_allDdlObjDefMap.end())
        {
            auto ddlObjIt = allDdlObjIt->second.find(ddlObjDefKey);
            if (ddlObjIt != allDdlObjIt->second.end())
            {
                return &ddlObjIt->second;
            }
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::addDdlObjDefByKey
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::addDdlObjDefByKey(DdlObjDefKey& ddlObjDefKey)
{
    auto& allDbDefMap = this->m_allDdlObjDefMap[ddlObjDefKey.getDdlObjEn()];

    DdlGenDbi ddlGenDbi(DdlObj_Sql, this->m_ddlGenContext, nullptr, nullptr, TargetTable_Main);

    ddlGenDbi.getAllDdlObjListFromDb(allDbDefMap,
                                     ddlObjDefKey.getDbName(),
                                     ddlObjDefKey.getEntitySqlName(),
                                     ddlObjDefKey.getObjName(),
                                     ddlObjDefKey.getDdlObjEn());
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::addDdlObjDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::addDdlObjDef(DdlObjDef &ddlObjDef)
{
    this->m_allDdlObjDefMap[ddlObjDef.getDdlObjEn()].insert(std::make_pair(ddlObjDef, ddlObjDef));
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::eraseDdlObjDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::eraseDdlObjDef(DdlObjDefKey &ddlObjDefKey)
{
    this->m_allDdlObjDefMap[ddlObjDefKey.getDdlObjEn()].erase(ddlObjDefKey);
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getXdEntityBySqlName
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getXdEntityBySqlName(const std::string &sqlName)
{
    return this->getRecordByCode(XdEntity, sqlName);
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getXdEntityById
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getXdEntityById(ID_T id)
{
    return this->getRecordById(XdEntity, id, true);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getDictEntityBySqlName
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getDictEntityBySqlName(const std::string &sqlName)
{
    return this->getRecordByCode(DictEntity, sqlName);
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getDictEntityById
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getDictEntityById(DICT_T id)
{
    return this->getRecordById(DictEntity, id, true);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getKey
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::string DdlGenDbaAccess::getKey(DBA_DYNFLD_STP recordStp, bool bWithoutParent)
{
    switch (recordStp->getObjectCst())
    {
        case ApplParamCst:
            return SYS_Stringer(GET_NAME(recordStp, (recordStp->isAllDynSt() ? A_ApplParam_ParamName : S_ApplParam_ParamName)), "~",
                                GET_ID(recordStp, (recordStp->isAllDynSt() ? A_ApplParam_UserId : S_ApplParam_UserId)));
            break;

        case ApplMsgCst:
            return SYS_Stringer(GET_NAME(recordStp, (recordStp->isAllDynSt() ? A_ApplMsg_Cd : S_ApplMsg_Cd)), "~",
                                GET_ENUM(recordStp, (recordStp->isAllDynSt() ? A_ApplMsg_NatEn : S_ApplMsg_NatEn)));
            break;

        case ApplMsgTxtCst:
            return SYS_Stringer(GET_ID(recordStp, (recordStp->isAllDynSt() ? A_ApplMsgTxt_MsgId : S_ApplMsgTxt_MsgId)), "~",
                                GET_DICT(recordStp, (recordStp->isAllDynSt() ? A_ApplMsgTxt_LangDictId : S_ApplMsgTxt_LangDictId)));
            break;

        case DictErrMsgCst:
            return SYS_Stringer(GET_INT(recordStp, (recordStp->isAllDynSt() ? A_DictErrMsg_Error : S_DictErrMsg_Error)), "~",
                                GET_DICT(recordStp, (recordStp->isAllDynSt() ? A_DictErrMsg_LangDictId : S_DictErrMsg_LangDictId)));
            break;

        case BalPosTpCst:
            if (IS_NULLFLD(recordStp, (recordStp->isAllDynSt() ? A_BalPosTp_Cd : S_BalPosTp_Cd)))
            {
                return SYS_Stringer("~", GET_INT(recordStp, (recordStp->isAllDynSt() ? A_BalPosTp_Rank : S_BalPosTp_Rank)));
            }
    }

    /* Generic part */
    bool          bIsAll        = recordStp->isAllDynSt();
    auto          dictEntityStp = recordStp->getDictEntityStp();
    std::stringstream  bufStream;

    for (int bkAttrPos = 0; bkAttrPos < dictEntityStp->bkAttrNbr; bkAttrPos++)
    {
        if (bkAttrPos != 0)
        {
            bufStream << "~";
        }

        if (bWithoutParent == false ||
            dictEntityStp->isNullParIndex ||
            dictEntityStp->parIndex != dictEntityStp->bkAttr[bkAttrPos]->progN)
        {
            DBA_DispFieldValue(bufStream, recordStp, bIsAll ? dictEntityStp->bkAttr[bkAttrPos]->progN : dictEntityStp->bkAttr[bkAttrPos]->shortIdx);
        }
    }

    return bufStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getRecord(OBJECT_ENUM objectEn, DBA_DYNFLD_STP inputStp, bool bAutoLoad, bool bAllRecord)
{
    LockGuard       lockGuard(this->m_lock);

    DBA_DYNFLD_STP  allRecordStp = nullptr;

    if (bAutoLoad)
    {
        this->loadManagement(objectEn);
    }

    if ((inputStp->isAllDynSt() || inputStp->isShortDynSt()) && 
        (objectEn == inputStp->getObjectEn() ||
         (DBA_IsAnExtOperationObject(objectEn) && DBA_IsAnExtOperationObject(inputStp->getObjectEn()))))
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp != nullptr)
        {
            if (dictEntityStp->isId())
            {
                FIELD_IDX_T idIdxPos = (inputStp->isAllDynSt() ? dictEntityStp->primKeyTab[0]->progN : dictEntityStp->primKeyTab[0]->shortIdx);

                if (_IS_NULLFLD(inputStp, idIdxPos) == FALSE)
                {
                    auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                    auto xdEntityIt = recordBIdMap.find(GET_ID(inputStp, idIdxPos));
                    if (xdEntityIt != recordBIdMap.end() &&
                        (bAllRecord == false || IS_DFLTFLD(xdEntityIt->second, 0) == TRUE))
                    {
                        return xdEntityIt->second;
                    }

                    if (this->m_ddlGenContext.ddlGenAction.m_fromImport)
                    {
                        ID_T id = GET_ID(inputStp, idIdxPos);
                        SET_NULL_ID(inputStp, idIdxPos);
                        auto recordStp = this->getRecord(objectEn, inputStp, bAutoLoad, bAllRecord);
                        SET_ID(inputStp, idIdxPos, id);

                        if (recordStp != nullptr)
                        {
                            this->m_mapConvIdByObjEnMap[objectEn][id] = GET_ID(recordStp, idIdxPos);

                            SET_ID(recordStp, idIdxPos, id);
                            recordBIdMap[id] = recordStp;

                            return recordStp;
                        }
                    }

                    return nullptr;
                }
            }

            if (dictEntityStp->isCode())
            {
                FIELD_IDX_T  codeIdxPos = (inputStp->isAllDynSt() ? dictEntityStp->bkAttr[0]->progN : dictEntityStp->bkAttr[0]->shortIdx);

                if (_IS_NULLFLD(inputStp, codeIdxPos) == FALSE)
                {
                    auto& recordBySqlNameMap = this->m_mapCodeByObjEnMap[objectEn];

                    auto xdEntityIt = recordBySqlNameMap.find(GET_SYSNAME(inputStp, codeIdxPos));
                    if (xdEntityIt != recordBySqlNameMap.end() &&
                        (bAllRecord == false || IS_DFLTFLD(xdEntityIt->second, 0) == TRUE))
                    {
                        return xdEntityIt->second;
                    }

                    return nullptr;
                }
            }
        }

        switch (GET_OBJECT_CST(objectEn))
        {
            case XdAttribCst:
            {
                if (_IS_NULLFLD(inputStp, (inputStp->isAllDynSt() ? A_XdAttrib_SqlName : S_XdAttrib_SqlName)) == FALSE)
                {
                    auto& attribByEntityMap = this->m_xdEntityAttribBySqlNameMap[GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdAttrib_XdEntityId : S_XdAttrib_XdEntityId))];
                    auto xdAttribIt = attribByEntityMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_XdAttrib_SqlName : S_XdAttrib_SqlName)));
                    if (xdAttribIt != attribByEntityMap.end())
                    {
                        return xdAttribIt->second;
                    }
                }
                else
                {
                    auto& attribByEntityVector = this->m_xdAttributesByEntityMap[GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdAttrib_XdEntityId : S_XdAttrib_XdEntityId))];
                    FIELD_IDX_T  inputIdxPos = ((inputStp->isAllDynSt() ? A_XdAttrib_Prog : S_XdAttrib_Prog));
                    FIELD_IDX_T  idxPos = A_XdAttrib_Prog;

                    if (_IS_NULLFLD(inputStp, inputIdxPos) == TRUE)
                    {
                        inputIdxPos = ((inputStp->isAllDynSt() ? A_XdAttrib_ShortIdx : S_XdAttrib_ShortIdx));
                        idxPos = A_XdAttrib_ShortIdx;
                    }

                    for (auto xdAttribIt = attribByEntityVector.begin(); xdAttribIt != attribByEntityVector.end(); ++xdAttribIt)
                    {
                        if (CMP_DYNFLD((*xdAttribIt), inputStp, idxPos, inputIdxPos, SmallintType) == 0)
                        {
                            return (*xdAttribIt);
                        }
                    }
                }
                break;
            }

            case XdAttributeCustoCst:
            {
                if (_IS_NULLFLD(inputStp, (inputStp->isAllDynSt() ? A_XdAttributeCusto_XdAttribId : S_XdAttributeCusto_XdAttribId)) == FALSE)
                {
                    auto xdAttribCustoByXdAttribIt = this->m_xdAttribCustoByAttribMap.find(GET_ID(inputStp, (inputStp->isAllDynSt() ?
                                                                                                             A_XdAttributeCusto_XdAttribId :
                                                                                                             S_XdAttributeCusto_XdAttribId)));
                    if (xdAttribCustoByXdAttribIt != this->m_xdAttribCustoByAttribMap.end())
                    {
                        for (auto it = xdAttribCustoByXdAttribIt->second.begin(); it != xdAttribCustoByXdAttribIt->second.end(); ++it)
                        {
                            if (CMP_DYNFLD(inputStp,
                                           (*it),
                                           (inputStp->isAllDynSt() ? A_XdAttributeCusto_NatEn : S_XdAttributeCusto_NatEn),
                                           A_XdAttributeCusto_NatEn,
                                           EnumType) == 0)
                            {
                                return (*it);
                            }
                        }
                    }
                }
                else
                {
                    SYS_BreakOnDebug();
                }
                break;
            }

            case DictAttrCst:
            {
                auto dictId = GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictAttr_EntityDictId : S_DictAttr_EntityDictId));
                auto& attribByEntityMap = this->m_dictEntityAttribBySqlNameMap[dictId];
                auto xdAttribIt = attribByEntityMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictAttr_SqlName : S_DictAttr_SqlName)));
                if (xdAttribIt != attribByEntityMap.end())
                {
                    return xdAttribIt->second;
                }

                if (this->m_ddlGenContext.ddlGenAction.m_fromImport)
                {
                    auto dictEntityIt = this->m_mapConvIdByObjEnMap[DictEntity].find(dictId);
                    if (dictEntityIt != this->m_mapConvIdByObjEnMap[DictEntity].end())
                    {
                        SET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictAttr_EntityDictId : S_DictAttr_EntityDictId), dictEntityIt->second);
                        auto recordStp = this->getRecord(objectEn, inputStp, bAutoLoad, bAllRecord);
                        SET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictAttr_EntityDictId : S_DictAttr_EntityDictId), dictId);
                        if (recordStp != nullptr)
                        {
                            return recordStp;
                        }
                    }
                }
                break;
            }

            case XdIndexCst:
            {
                auto& indexByEntityMap = this->m_xdEntityIndexByEntityMap[GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdIndex_XdEntityId : S_XdIndex_XdEntityId))];
                auto xdAttribIt = indexByEntityMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_XdIndex_SqlName : S_XdIndex_SqlName)));
                if (xdAttribIt != indexByEntityMap.end())
                {
                    return xdAttribIt->second;
                }
                break;
            }

            case XdPermValCst:
            {
                auto permValNatEnIdx = (inputStp->isAllDynSt() ? A_XdPermVal_PermValNatEn : S_XdPermVal_PermValNatEn);
                if (IS_NULLFLD(inputStp, permValNatEnIdx))
                {
                    auto& xdPermValuesByAttribMap = this->m_xdPemValuesByXdAttribNameMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_XdPermVal_XdAttribId : S_XdPermVal_XdAttribId))];

                    auto xdPermValuesIt = xdPermValuesByAttribMap.find(GET_NAME(inputStp, (inputStp->isAllDynSt() ? A_XdPermVal_Name : S_XdPermVal_Name)));
                    if (xdPermValuesIt != xdPermValuesByAttribMap.end())
                    {
                        return xdPermValuesIt->second;
                    }
                }
                else
                {
                    auto& xdPermValuesByAttribMap = this->m_xdPemValuesByXdAttribNatMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_XdPermVal_XdAttribId : S_XdPermVal_XdAttribId))];

                    auto xdPermValuesIt = xdPermValuesByAttribMap.find(GET_ENUM(inputStp, permValNatEnIdx));
                    if (xdPermValuesIt != xdPermValuesByAttribMap.end())
                    {
                        return xdPermValuesIt->second;
                    }
                }
                break;
            }

            case XdIndexAttribCst:
            {
                auto& indexAttribByBkMap = this->m_xdIndexAttribByBkMap[GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdIndexAttrib_XdIdxId : S_XdIndexAttrib_XdIdxId))];
                auto xdIdxAttribIt = indexAttribByBkMap.find(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdIndexAttrib_XdAttribId : S_XdIndexAttrib_XdAttribId)));
                if (xdIdxAttribIt != indexAttribByBkMap.end())
                {
                    return xdIdxAttribIt->second;
                }
                break;
            }

            case XdEntityFeatureCst:
            {
                auto& featuresByEntityMap = this->m_xdEntityFeaturesByEntityMap[GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdEntityFeature_XdEntityId : S_XdEntityFeature_XdEntityId))];
                auto xdFeaturesIt = featuresByEntityMap.find((inputStp->isAllDynSt() ? GET_A_XdEntityFeature_FeatureEn(inputStp) : GET_S_XdEntityFeature_FeatureEn(inputStp)));
                if (xdFeaturesIt != featuresByEntityMap.end())
                {
                    return xdFeaturesIt->second;
                }
                break;
            }

            case DictCriterCst:
            {
                auto& criteriaByEntityMap = this->m_dictEntityCriteriaBySqlNameMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictCriter_EntDictId : S_DictCriter_EntDictId))];
                auto criteriaNatIt = criteriaByEntityMap.find(GET_ENUM(inputStp, (inputStp->isAllDynSt() ? A_DictCriter_DynNat : S_DictCriter_DynNat)));
                if (criteriaNatIt != criteriaByEntityMap.end())
                {
                    auto criteriaIt = criteriaNatIt->second.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictCriter_SqlName : S_DictCriter_SqlName)));
                    if (criteriaIt != criteriaNatIt->second.end())
                    {
                        return criteriaIt->second;
                    }
                }
                break;
            }

            case DictPermValCst:
            {
                auto& dictPermValuesByAttribMap = this->m_dictPemValuesByAttribMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictPermVal_AttribDictId : S_DictPermVal_AttribDictId))];
                auto dictPermValuesIt = dictPermValuesByAttribMap.find(GET_ENUM(inputStp, (inputStp->isAllDynSt() ? A_DictPermVal_PermValNatEn : S_DictPermVal_PermValNatEn)));
                if (dictPermValuesIt != dictPermValuesByAttribMap.end())
                {
                    return dictPermValuesIt->second;
                }
                break;
            }

            case DictSprocCst:
            {
                auto& dictSprocBySqlNameMap = this->m_dictSprocBySqlNameMap[GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictSproc_SqlName : S_DictSproc_SqlName))];
                auto dictSprocBySqlNameIt = dictSprocBySqlNameMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictSproc_Database : S_DictSproc_Database)));
                if (dictSprocBySqlNameIt != dictSprocBySqlNameMap.end())
                {
                    return dictSprocBySqlNameIt->second;
                }
                break;
            }

            case DictSprocParamCst:
            {
                auto& dictSprocParamByProcMap = this->m_dictSprocParamByProcMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictSprocParam_SprocDictId : S_DictSprocParam_SprocDictId))];
                auto dictSprocParamByProcIt = dictSprocParamByProcMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictSprocParam_SqlName : S_DictSprocParam_SqlName)));
                if (dictSprocParamByProcIt != dictSprocParamByProcMap.end())
                {
                    return dictSprocParamByProcIt->second;
                }
                break;
            }

            case DictSprocReturnsCst:
            {
                auto& dictSprocReturnsByProcMap = this->m_dictSprocReturnsByProcMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictSprocReturns_SprocDictId : S_DictSprocReturns_SprocDictId))];
                auto dictSprocReturnsByProcIt = dictSprocReturnsByProcMap.find(GET_SMALLINT(inputStp, (inputStp->isAllDynSt() ? A_DictSprocReturns_Rank : S_DictSprocReturns_Rank)));
                if (dictSprocReturnsByProcIt != dictSprocReturnsByProcMap.end())
                {
                    return dictSprocReturnsByProcIt->second;
                }
                break;
            }

            case DictEntityConstraintsCst:
            {
                auto& dictEntityConstrByEntityMap = this->m_dictEntityConstrByEntityMap[GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictEntityConstraints_EntityDictId : S_DictEntityConstraints_EntityDictId))];
                std::string keyStr(SYS_Stringer(GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictEntityConstraints_RefEntityDictId : S_DictEntityConstraints_RefEntityDictId)),
                                           "~",
                                           GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictEntityConstraints_RefAttribDictId : S_DictEntityConstraints_RefAttribDictId))));

                auto dictEntityConstrByEntityIt = dictEntityConstrByEntityMap.find(keyStr);
                if (dictEntityConstrByEntityIt != dictEntityConstrByEntityMap.end())
                {
                    return dictEntityConstrByEntityIt->second;
                }
                break;
            }

            case DictDependsCst:
            {
                std::string keyStr(SYS_Stringer(GET_STRING(inputStp, (inputStp->isAllDynSt() ? A_DictDepends_SqlName : S_DictDepends_SqlName)), "~",
                                           GET_STRING(inputStp, (inputStp->isAllDynSt() ? A_DictDepends_Database : S_DictDepends_Database)), "~",
                                           GET_STRING(inputStp, (inputStp->isAllDynSt() ? A_DictDepends_DepSqlName : S_DictDepends_DepSqlName)), "~",
                                           CAST_INT(GET_ENUM(inputStp, (inputStp->isAllDynSt() ? A_DictDepends_AccessEn : S_DictDepends_AccessEn)))));

                auto dictEntityConstrByEntityIt = this->m_dictEntityDependsByKeyMap.find(keyStr);
                if (dictEntityConstrByEntityIt != this->m_dictEntityDependsByKeyMap.end())
                {
                    return dictEntityConstrByEntityIt->second;
                }
                break;
            }

            case XdLabelCst:
            {
                auto xdLabelByEntityIt = this->m_xdLabelMap.find(GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_XdLabel_EntityDictId : S_XdLabel_EntityDictId)));
                if (xdLabelByEntityIt != this->m_xdLabelMap.end())
                {
                    auto xdLabelByObjIt = xdLabelByEntityIt->second.find(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdLabel_ObjId : S_XdLabel_ObjId)));
                    if (xdLabelByObjIt != xdLabelByEntityIt->second.end())
                    {
                        auto xdLabelByLangIt = xdLabelByObjIt->second.find(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdLabel_LangDictId : S_XdLabel_LangDictId)));
                        if (xdLabelByLangIt != xdLabelByObjIt->second.end())
                        {
                            auto xdLabelByNatIt = xdLabelByLangIt->second.find(GET_A_XdLabel_NatEn(inputStp));
                            if (xdLabelByNatIt != xdLabelByLangIt->second.end())
                            {
                                return xdLabelByNatIt->second;
                            }
                        }
                    }
                }
                break;
            }

            case DictLabelCst:
            {
                auto dictLabelByEntityIt = this->m_dictLabelMap.find(GET_DICT(inputStp, (inputStp->isAllDynSt() ? A_DictLabel_EntDictId : S_DictLabel_EntDictId)));
                if (dictLabelByEntityIt != this->m_dictLabelMap.end())
                {
                    auto dictLabelByObjIt = dictLabelByEntityIt->second.find(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_DictLabel_ObjDictId : S_DictLabel_ObjDictId)));
                    if (dictLabelByObjIt != dictLabelByEntityIt->second.end())
                    {
                        auto dictLabelByLangIt = dictLabelByObjIt->second.find(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_DictLabel_LangDictId : S_DictLabel_LangDictId)));
                        if (dictLabelByLangIt != dictLabelByObjIt->second.end())
                        {
                            return dictLabelByLangIt->second;
                        }
                    }
                }
                break;
            }

            case XdAttribCommentCst:
            {
                std::string keyStr(SYS_Stringer(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdAttribComment_XdAttribId : S_XdAttribComment_XdAttribId)), "~",
                                           GET_ID(inputStp, (inputStp->isAllDynSt() ? A_XdAttribComment_LangDictId : S_XdAttribComment_LangDictId)), "~",
                                           CAST_INT(GET_ENUM(inputStp, (inputStp->isAllDynSt() ? A_XdAttribComment_NatEn : S_XdAttribComment_NatEn)))));

                auto xdAttributeComnentByKeyIt = this->m_xdAttributeComnentByKeyMap.find(keyStr);
                if (xdAttributeComnentByKeyIt != this->m_xdAttributeComnentByKeyMap.end())
                {
                    return xdAttributeComnentByKeyIt->second;
                }
                break;
            }

            case DictAttribCommentCst:
            {
                std::string keyStr(SYS_Stringer(GET_ID(inputStp, (inputStp->isAllDynSt() ? A_DictAttribComment_AttribDictId : S_DictAttribComment_AttribDictId)), "~",
                                           GET_ID(inputStp, (inputStp->isAllDynSt() ? A_DictAttribComment_LangDictId : S_DictAttribComment_LangDictId))));

                auto dictAttributeComnentByKeyIt = this->m_dictAttributeComnentByKeyMap.find(keyStr);
                if (dictAttributeComnentByKeyIt != this->m_dictAttributeComnentByKeyMap.end())
                {
                    return dictAttributeComnentByKeyIt->second;
                }
                break;
            }

            case DictLangCst:
            {
                auto dictLangugaeBySqlNameIt = this->m_dictLanguageBySqlNameMap.find(GET_SYSNAME(inputStp, (inputStp->isAllDynSt() ? A_DictLang_SqlName : S_DictLang_SqlName)));
                if (dictLangugaeBySqlNameIt != this->m_dictLanguageBySqlNameMap.end())
                {
                    return dictLangugaeBySqlNameIt->second;
                }
                break;
            }

            case ApplParamCst:
            case ApplMsgCst:
            case ApplMsgTxtCst:
            case DictErrMsgCst:
            case ScriptDefCst:
            case HoldingConstraintScriptCst:
            case TradingConstraintScriptCst:
            case QuestDefCst:
            default:
            {
                auto objectByKeyMapIt = this->m_objectByKeyMapMap.find(objectEn);
                if (objectByKeyMapIt != this->m_objectByKeyMapMap.end())
                {
                    auto objectByKeyIt = objectByKeyMapIt->second.find(this->getKey(inputStp));
                    if (objectByKeyIt != objectByKeyMapIt->second.end())
                    {
                        return objectByKeyIt->second;
                    }
                }
                break;
            }
        }
    }
    else
    {
        DBA_DYNST_ENUM  objectStEn    = GET_DYNSTENUM(inputStp);
        DBA_DYNST_ENUM  shObjectStEn  = GET_ADMINGUIST(objectEn);
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp != nullptr && dictEntityStp->isId())
        {
            FIELD_IDX_T pkIdxPos = (objectStEn == Adm_Arg ? Adm_Arg_Id
                                    : objectStEn == shObjectStEn ? dictEntityStp->primKeyTab[0]->shortIdx
                                    : dictEntityStp->primKeyTab[0]->progN);

            if (IS_NOTNULL(inputStp, pkIdxPos))
            {
                ID_T id = GET_ID(inputStp, pkIdxPos);

                auto objectIt = this->m_mapIdByObjEnMap.find(objectEn);
                if (objectIt != this->m_mapIdByObjEnMap.end())
                {
                    auto searchIt = objectIt->second.find(id);
                    if (searchIt != objectIt->second.end())
                    {
                        allRecordStp = searchIt->second;
                    }
                }
            }
            else if (dictEntityStp->isCode())
            {
                FIELD_IDX_T bkIdxPos = (objectStEn == Adm_Arg ? Adm_Arg_Code
                                        : objectStEn == shObjectStEn ? dictEntityStp->bkAttr[0]->shortIdx
                                        : dictEntityStp->bkAttr[0]->progN);

                if (IS_NOTNULL(inputStp, bkIdxPos))
                {
                    auto objectIt = this->m_mapCodeByObjEnMap.find(objectEn);
                    if (objectIt != this->m_mapCodeByObjEnMap.end())
                    {
                        auto searchIt = objectIt->second.find(GET_STRING(inputStp, bkIdxPos));
                        if (searchIt != objectIt->second.end())
                        {
                            allRecordStp = searchIt->second;
                        }
                    }
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }

    return allRecordStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insUpdRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::insUpdRecord(DBA_DYNFLD_STP recordStp, ID_T &recId, int role, bool bDoCopy)
{
    LockGuard       lockGuard(this->m_lock);

    auto outRecordStp = recordStp;
    auto objectEn     = recordStp->getObjectEn();

    if (objectEn == FmtElt &&
        GET_A_FmtElt_TslMultilingualEn(recordStp) == FmtEltTslMultilingualEn::Multilingual)
    {
        auto &allDictLangMap = this->selAllRecords(DictLang, true, false);
        for (auto &it : allDictLangMap)
        {
            if (GET_FLAG(it.second, A_DictLang_TslMultilingualFlg) == TRUE)
            {
                auto childFmtEltStp = this->duplicateDynStp(FILEINFO, recordStp);

                SET_NULL_ID(childFmtEltStp, A_FmtElt_Id);
                SET_A_FmtElt_TslMultilingualEn(childFmtEltStp, FmtEltTslMultilingualEn::MultilingualChild);
                DBA_CopyDynFld(childFmtEltStp, A_FmtElt_LangDictId, it.second, A_DictLang_Id);
                SET_NULL_SMALLINT(childFmtEltStp, A_FmtElt_DispColumn);
                SET_SYSNAME(childFmtEltStp, A_FmtElt_SqlName, SYS_Stringer(GET_SYSNAME(recordStp, A_FmtElt_SqlName), "_", GET_CODE(it.second, A_DictLang_Cd)).c_str());

                if (IS_STRINGFLD(A_FmtElt, A_FmtElt_Denom) == TRUE)
                {
                    if (IS_NOTNULL(recordStp, A_FmtElt_Denom))
                    {
                        SET_INFO(childFmtEltStp, A_FmtElt_Denom, SYS_Stringer(GET_CODE(it.second, A_DictLang_Cd), "_", GET_INFO(recordStp, A_FmtElt_Denom)).substr(0, 80).c_str());
                    }
                    else
                    {
                        SET_INFO(childFmtEltStp, A_FmtElt_Denom, SYS_Stringer(GET_CODE(it.second, A_DictLang_Cd), "_").substr(0, 80).c_str());
                    }
                }
                else
                {
                    UnicodeString uStr(GET_CODE(it.second, A_DictLang_Cd));
                    uStr += "_";

                    if (IS_NOTNULL(recordStp, A_FmtElt_Denom))
                    {
                        uStr += GET_UINFO(recordStp, A_FmtElt_Denom);
                        SET_UINFO(childFmtEltStp, A_FmtElt_Denom, uStr.tempSubString(0, 80).getTerminatedBuffer());
                    }
                    else
                    {
                        SET_UINFO(childFmtEltStp, A_FmtElt_Denom, uStr.tempSubString(0, 80).getTerminatedBuffer());
                    }
                }

                ID_T fmtEltId = 0;
                this->insUpdRecord(childFmtEltStp, fmtEltId, role, false);
            }
        }
    }
    else if (DBA_isScriptObject(objectEn))
    {
        if (GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_SysGuiDefVal ||
            GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_SysGuiCtrlVal ||
            GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_SysBatchDefVal ||
            GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_SysBatchCtrlVal ||
            GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_UserGuiFilter ||
            GET_ENUM(recordStp, A_ScriptDef_NatEn) == ScriptDef_SysGuiFilter)
        {
            auto dictAttribStp = this->getRecordById(DictAttr, GET_DICT(recordStp, A_ScriptDef_AttrDictId), true);
            if (dictAttribStp != nullptr)
            {
                SET_DICT(recordStp, A_ScriptDef_ScriptEntRefDictId, GET_DICT(dictAttribStp, A_DictAttr_EntityDictId));
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }

        if (IS_NULLFLD(recordStp, A_ScriptDef_ObjId))
        {
            SET_DICT(recordStp, A_ScriptDef_DimEntityDictId, 0);
        }
    }

    if (recordStp->getObjectEn() == XdAttrib &&
        GET_A_XdAttrib_MeSpecialisationEn(recordStp) == XdAttribMeSpecialisationEn::Applied)
    {
        DBA_DYNFLD_STP xdEntityStp = this->getXdEntityById(GET_ID(recordStp, A_XdAttrib_XdEntityId));
        if (xdEntityStp != nullptr)
        {
            this->copyXdEntityByName(xdEntityStp, XdEntityDictBuildRuleEn::PartialSpecialization);
        }
    }
    else if (recordStp->getObjectEn() == XdAttributeCusto &&
             GET_A_XdAttributeCusto_NatEn(recordStp) == XdAttributeCustoNatEn::MultiEntity &&
             GET_A_XdAttributeCusto_MeSpecialisationEn(recordStp) == XdAttribMeSpecialisationEn::Applied)
    {
        DBA_DYNFLD_STP xdEntityStp = this->getXdEntityById(GET_ID(recordStp, A_XdAttributeCusto_XdEntityId));
        if (xdEntityStp != nullptr)
        {
            this->copyXdEntityByName(xdEntityStp, XdEntityDictBuildRuleEn::PartialSpecialization);
        }
    }

    if (role == DBA_ROLE_IMPORT_USR_MD)
    {
        role = DBA_ROLE_UDT;

        if (outRecordStp->getDynStEn() == A_XdLabel)
        {
            SET_ENUM(recordStp, A_XdLabel_NatEn, XdLabelNat_Usr);
        }
    }

    if (recordStp->getDynStEn() == A_DictFct && 
        (role == UNUSED || role == DBA_ROLE_UDT))
    {
        if ((IS_NULLFLD(recordStp, A_DictFct_DictId) || GET_ID(recordStp, A_DictFct_DictId) < 0))
        {
            role = DBA_ROLE_INSUPD_DICTFCT_BY_IMP;
        }
        else
        {
            role = DBA_ROLE_FORCE_STORED_PROC;
        }
    }

    auto searchIt = this->m_allRecordsMap.find(recordStp);
    if (searchIt == this->m_allRecordsMap.end())
    {
        outRecordStp = this->getRecord(objectEn, recordStp);
        if (outRecordStp == nullptr)
        {
            outRecordStp = this->insRecord(recordStp, recId, bDoCopy);
        }
        else
        {
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

            recId = dictEntityStp->getId(outRecordStp);
            DBA_CopyDynStWithSetFld(outRecordStp, recordStp);

            dictEntityStp->setId(outRecordStp, recId);
        }

        searchIt = this->m_allRecordsMap.find(outRecordStp);
    }

    auto &currRecordActionVector = this->m_recordActionVector[outRecordStp];

    DBA_ACTION_ENUM action = Update;

    if (searchIt->second == XdAction_None)
    {
        if (currRecordActionVector.empty() &&
            this->m_allDbRecordsMap.find(outRecordStp) == this->m_allDbRecordsMap.end())
        {
            searchIt->second = XdAction_ToInsert;
            action = Insert;
        }
        else
        {
            searchIt->second = XdAction_ToRefresh;
        }
    }

    if (action == Update &&
        currRecordActionVector.empty() == false &&
        currRecordActionVector.back().m_action == Delete)
    {
        if (role == DBA_ROLE_STATUS)
        {
            return outRecordStp;
        }
        action = Insert;
    }
    else if (action == Insert &&
             objectEn == MktSegt)
    {
        action = Update;
    }

    currRecordActionVector.push_back(DdlGenDbaAccess::Action(action, objectEn, role));

    if (action == Insert &&
        role == DBA_ROLE_STATUS)
    {
        auto& reqAction = currRecordActionVector.back();
        reqAction.m_role = DBA_ROLE_UDT;
    }

    if (role != DBA_ROLE_STATUS)
    {
        this->setXdAction(outRecordStp, XdAction_ToInsert);

        this->manageDenormAttributes(outRecordStp);
        this->setPackageCompositionLink(outRecordStp);
    }

    return outRecordStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insUpdDelRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE  DdlGenDbaAccess::insUpdDelRecord(DBA_ACTION_ENUM  action,
                                           OBJECT_ENUM      object,
                                           int              role,
                                           DBA_DYNFLD_STP  &inputDataStp,
                                           bool             bToCopy,
                                           size_t           batchRank,
                                           DBA_DYNFLD_STP   parentDataStp)
{
    LockGuard lockGuard(this->m_lock);

    if (action == Delete)
    {
        if (object == DictCriter &&
            GET_DYNSTENUM(inputDataStp) == Adm_Arg)
        {
            if (IS_NOTNULL(inputDataStp, Adm_Arg_EntDictId))
            {
                auto &criteriaByEntMap = this->m_dictEntityCriteriaBySqlNameMap[GET_DICT(inputDataStp, Adm_Arg_EntDictId)];

                for (auto &criteriaNatIt : criteriaByEntMap)
                {
                    for (auto &criteriaIt : criteriaNatIt.second)
                    {
                        this->insUpdDelRecord(action, object, role, criteriaIt.second, bToCopy, batchRank, parentDataStp);
                    }
                }
            }
        }
        else if (object == DictSprocParam &&
                 GET_DYNSTENUM(inputDataStp) == A_DictSproc)
        {
            if (IS_NOTNULL(inputDataStp, A_DictSproc_DictId))
            {
                auto &sprocParamBySprocMap = this->m_dictSprocParamByProcMap[GET_DICT(inputDataStp, A_DictSproc_DictId)];

                for (auto &sprocParamIt : sprocParamBySprocMap)
                {
                    this->insUpdDelRecord(action, object, role, sprocParamIt.second, bToCopy, batchRank, inputDataStp);
                }
            }
        }
        else if (object == DictSprocReturns &&
                 GET_DYNSTENUM(inputDataStp) == A_DictSproc)
        {
            if (IS_NOTNULL(inputDataStp, A_DictSproc_DictId))
            {
                auto &sprocReturnBySprocMap = this->m_dictSprocReturnsByProcMap[GET_DICT(inputDataStp, A_DictSproc_DictId)];

                for (auto &sprocParamIt : sprocReturnBySprocMap)
                {
                    this->insUpdDelRecord(action, object, role, sprocParamIt.second, bToCopy, batchRank, inputDataStp);
                }
            }
        }
        else if (object == DictPermVal &&
                 GET_DYNSTENUM(inputDataStp) == A_XdAttrib)
        {
            if (IS_NOTNULL(inputDataStp, A_XdAttrib_AttribDictId))
            {
                auto &permValByAttribDictIdMap = this->m_dictPemValuesByAttribMap[GET_DICT(inputDataStp, A_XdAttrib_AttribDictId)];

                for (auto &permValIt : permValByAttribDictIdMap)
                {
                    this->insUpdDelRecord(action, object, role, permValIt.second, bToCopy, batchRank, inputDataStp);
                }
            }
        }
        else if (object == DictEntityConstraints &&
                 GET_DYNSTENUM(inputDataStp) == S_DictEntityConstraints)
        {
            if (IS_NOTNULL(inputDataStp, S_DictEntityConstraints_EntityDictId))
            {
                auto &dictEntityConstrByEntityMap = this->m_dictEntityConstrByEntityMap[GET_DICT(inputDataStp, S_DictEntityConstraints_EntityDictId)];

                for (auto dictEntityConstrByEntityIt : dictEntityConstrByEntityMap)
                {
                    this->insUpdDelRecord(action, object, role, dictEntityConstrByEntityIt.second, bToCopy, batchRank);
                }
            }
        }
        else
        {
            DBA_DYNST_ENUM  objectStEn    = GET_DYNSTENUM(inputDataStp);
            OBJECT_ENUM     objectEn      = GET_OBJ_DYNST(objectStEn);
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);
            DBA_DYNST_ENUM  shObjectStEn  = GET_ADMINGUIST(objectEn);

            if (dictEntityStp != nullptr && dictEntityStp->isId())
            {
                FIELD_IDX_T pkIdxPos = (objectStEn == Adm_Arg ? Adm_Arg_Id
                                        : objectStEn == shObjectStEn ? dictEntityStp->primKeyTab[0]->shortIdx
                                        : dictEntityStp->primKeyTab[0]->progN);

                if (IS_NULLFLD(inputDataStp, pkIdxPos) == FALSE)
                {
                    auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                    auto objectIt = recordBIdMap.find(GET_ID(inputDataStp, pkIdxPos));
                    if (objectIt != recordBIdMap.end())
                    {
                        auto& reqAllAction = this->m_recordActionVector[objectIt->second];

                        if (reqAllAction.empty() ||
                            reqAllAction.back().m_action != Delete)
                        {
                            reqAllAction.push_back(DdlGenDbaAccess::Action(action, objectIt->second->getObjectEn(), role));
                        }
                    }
                    else
                    {
                        SYS_BreakOnDebug();
                    }
                }
                else
                {
                    auto& reqAllAction = this->m_recordActionVector[inputDataStp];

                    if (reqAllAction.empty() ||
                        reqAllAction.back().m_action != Delete)
                    {
                        reqAllAction.push_back(DdlGenDbaAccess::Action(action, inputDataStp->getObjectEn(), role));
                    }
                }
            }
            else
            {
                auto recordStp = this->getRecord(inputDataStp->getObjectEn(), inputDataStp);
                auto recordIt = this->m_allRecordsMap.find(recordStp);
                if (recordIt != this->m_allRecordsMap.end())
                {
                    auto& reqAllAction = this->m_recordActionVector[recordIt->first];

                    if (reqAllAction.empty() ||
                        reqAllAction.back().m_action != Delete)
                    {
                        reqAllAction.push_back(DdlGenDbaAccess::Action(action, recordIt->first->getObjectEn(), role));
                    }
                }
            }
        }
    }
    else
    {
        ID_T newId = 0;
        inputDataStp = this->insUpdRecord(inputDataStp, newId, role, bToCopy);

        if (object == XdEntityFeature)
        {
            this->manageXdEntityFeature(inputDataStp, batchRank);
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::insUpdDelRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240516
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::insUpdDelFullRecord(DBA_ACTION_ENUM  action,
                                              DBA_DYNFLD_STP   recordStp)
{
    RET_CODE ret           = RET_SUCCEED;
    auto     dictEntityStp = recordStp->getDictEntityStp();

    if (dictEntityStp != nullptr)
    {
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp->logicalFlg == TRUE || dictAttribStp->attrDictId == 1143003)
            {
                break;
            }

            if (IS_ID_TYPE(dictAttribStp->dataTpProgN) &&
                dictAttribStp->isCompostion() &&
                IS_NOTNULL(recordStp, dictAttribStp->progN) &&
                GET_FK_RECORD(recordStp, dictAttribStp->progN) != nullptr)
            {
                this->insUpdDelFullRecord(action, GET_FK_RECORD(recordStp, dictAttribStp->progN));
            }
        }

        auto toInsRecordStp = recordStp;
        this->insUpdDelRecord(action, dictEntityStp->objectEn, UNUSED, toInsRecordStp, false);

        for (auto dictAttribStp : dictEntityStp->logicalTab)
        {
            if (dictAttribStp->progN != GET_FLD_FK(recordStp->getDynStEn()) &&
                GET_EXTENSION_PTR(recordStp, dictAttribStp->progN) != nullptr)
            {
                for (auto i = 0; i < GET_EXTENSION_NBR(recordStp, dictAttribStp->progN); ++i)
                {
                    this->insUpdDelFullRecord(action, GET_EXTENSION_PTR(recordStp, dictAttribStp->progN)[i]);
                }
            }
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::dbaGet
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::dbaGet(OBJECT_ENUM     objectEn,
                                 int             role,
                                 DBA_DYNFLD_STP  inputData,
                                 DBA_DYNFLD_STP &outputData,
                                 bool            bForceGet)
{
    RET_CODE       ret = RET_SUCCEED;
    OBJECT_ENUM    recordObjectEn = (outputData != nullptr ? outputData->getObjectEn() : objectEn);
    DBA_DYNFLD_STP recordStp = (bForceGet ? nullptr : this->getRecord(objectEn, inputData));

    if ((recordStp == nullptr && this->isLoaded(objectEn) == false) || bForceGet)
    {
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

        auto dictEntityStp = DBA_GetDictEntitySt(recordObjectEn);

        dbiConnHelper.setFromDbaAccess();

        recordStp = this->allocDynSt(FILEINFO, GET_EDITGUIST(recordObjectEn));

        auto procStp = DBA_GetStoredProcs(Get, objectEn, role, inputData->getDynStEn(), inputData, recordStp->getDynStEn());

        if (procStp != nullptr &&
            procStp->server == InternalProc &&
            procStp->fctDefSt.getFct == DBA_GetXdObject &&
            role == UNUSED)
        {
            role = DBA_ROLE_DB_ACCESS;
        }

        if (inputData->getDynStEn() == Adm_Arg &&
            procStp == nullptr &&
            recordStp->getDictEntityStp()->isId())
        {
            if (GET_ID(inputData, Adm_Arg_Id) > 0)
            {
                MemoryPool mp;
                DBA_DYNFLD_STP shInputData = mp.allocDynst(FILEINFO, GET_ADMINGUIST(recordObjectEn));

                COPY_DYNFLD(shInputData, shInputData->getDynStEn(), recordStp->getDictEntityStp()->getIdIdx(DynType_All),
                            inputData, Adm_Arg, Adm_Arg_Id);

                ret = dbiConnHelper.dbaGet(objectEn, role, shInputData, &recordStp);
            }
        }
        else
        {
            bool bToSearch = true;
            if (dictEntityStp != nullptr)
            {
                for (int i = 0; i < dictEntityStp->primKeyNbr; i++)
                {
                    if (IS_ID_TYPE(dictEntityStp->primKeyTab[i]->dataTpProgN) &&
                        GET_ID(inputData, (inputData->isAllDynSt() ? dictEntityStp->primKeyTab[i]->progN : dictEntityStp->primKeyTab[i]->shortIdx)) < 0)
                    {
                        bToSearch = false;
                        break;
                    }
                }

                if (bToSearch)
                {
                    for (int i = 0; i < dictEntityStp->bkAttrNbr; i++)
                    {
                        if (IS_ID_TYPE(dictEntityStp->bkAttr[i]->dataTpProgN) &&
                            GET_ID(inputData, (inputData->isAllDynSt() ? dictEntityStp->bkAttr[i]->progN : dictEntityStp->bkAttr[i]->shortIdx)) < 0)
                        {
                            bToSearch = false;
                            break;
                        }
                    }
                }
            }

            if (bToSearch)
            {
                if (inputData->isShortDynSt() &&
                    (outputData != nullptr && outputData->isShortDynSt()))
                {
                    dbiConnHelper.dbaSetOptions(DBA_NO_PROC_ERROR);
                    ret = dbiConnHelper.dbaGet(objectEn, role, inputData, &recordStp);

                    if (ret != RET_SUCCEED && 
                        dbiConnHelper.dbaGet(objectEn, role, inputData, &outputData) == RET_SUCCEED)
                    {
                        ret = RET_DBA_INFO_EXIST;
                    }
                    dbiConnHelper.dbaSetOptions(0);
                }
                else
                {
                    ret = dbiConnHelper.dbaGet(objectEn, role, inputData, &recordStp);
                }
            }
            else
            {
                this->freeDynStp(recordStp);
                ret = RET_DBA_INFO_NO_MORE_DATA;
            }
        }

        dbiConnHelper.resetFromDbaAccess();

        if (ret == RET_SUCCEED)
        {
            ID_T     recId = 0;
            recordStp = this->insRecord(recordStp, recId, false, true, (role != UNUSED));
        }
        else if (inputData->isShortDynSt() && 
                 (outputData != nullptr && outputData->isShortDynSt()) &&
                 recordStp != nullptr)
        {
            if (recordStp->getObjectEn() != inputData->getObjectEn())
            {
                this->m_mp.freeDynStp(recordStp);
                recordStp = this->allocDynSt(FILEINFO, GET_EDITGUIST(inputData->getObjectEn()));
            }

            ID_T     recId = 0;
            if (ret == RET_DBA_INFO_EXIST)
            {
                DBA_ConvertDynSt(recordStp, outputData, true);
            }
            else
            {
                DBA_ConvertDynSt(recordStp, inputData, true);
            }
            
            SET_INTERNAL(recordStp, (GET_INTERNAL(recordStp) | INTERNAL_BK));

            recordStp = this->insRecord(recordStp, recId, false, true, (role != UNUSED));

            ret = RET_SUCCEED;
        }
    }

    if (recordStp == nullptr)
    {
        return RET_DBA_ERR_NODATA;
    }

    if (ret == RET_SUCCEED)
    {
        if (outputData != nullptr)
        {
            DBA_ConvertDynSt(outputData, recordStp, true);
        }
        else
        {
            outputData = recordStp;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selAllRecords
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::map<ID_T, DBA_DYNFLD_STP>   &DdlGenDbaAccess::selAllRecords(OBJECT_ENUM objectEn, bool bGetFromDb, bool bAll)
{
    if (bGetFromDb)
    {
        this->loadManagement(objectEn);
    }

    auto& validIdByObjEnMap = this->m_validIdByObjEnMap[objectEn];

    if (validIdByObjEnMap.empty() || validIdByObjEnMap.begin()->first < 0)
    {
        validIdByObjEnMap.clear();

        auto& idByObjEnMap = this->m_mapIdByObjEnMap[objectEn];
        for (auto& it : idByObjEnMap)
        {
            if ((it.first > 0 || it.first == GET_ID(it.second, it.second->getIdIdx())) &&
                (bAll || (GET_INTERNAL(it.second) & INTERNAL_TREATED) == 0))
            {
                validIdByObjEnMap.insert(it);
            }
        }
    }

    return validIdByObjEnMap;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::addProcedureCallForBatchMulti
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 220615
**
*************************************************************************/
bool DdlGenDbaAccess::addProcedureCallForBatchMulti(DBA_ACTION_ENUM action,
                                                    OBJECT_ENUM     object,
                                                    int             role,
                                                    DBA_DYNFLD_STP  inputData,
                                                    size_t          batchRank)
{
    auto autoRecIt = this->m_autoRecordMap.find(inputData);
    if (autoRecIt != this->m_autoRecordMap.end())
    {
        for (auto it : autoRecIt->second)
        {
            this->m_toLoadRecordMap[it->getDynStEn()].insert(it);
        }
    }

    auto requestHelperPtr = this->m_ddlGenContext.getRequestHelper();

    auto dictEntityStp = DBA_GetDictEntitySt(object);

    if (object == DictEntity)
    {
        if (GET_ENUM(inputData, A_DictEntity_LoadDictRuleEn) != LoadDictRule_Never)
        {
            this->m_objModifStatSet.insert(object);
        }
    }
    else if (object == DictAttr)
    {
        if (dictEntityStp != nullptr &&
            dictEntityStp->loadDictRuleEn != LoadDictRule_Never)
        {
            this->m_objModifStatSet.insert(object);
            /* PMSTA-62069 - KKM - 28112024 */
            if (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt)
            {
                this->m_objModifStatSet.insert(DictEntity);
            }
        }
    }
    else if (SYS_IsDdlGenMode() == FALSE)
    {
        if (dictEntityStp != nullptr && 
            dictEntityStp->tableModifStatEn != LastModif_NoTracking)
        {
            this->m_objModifStatSet.insert(object);
        }
    }

    return requestHelperPtr->addProcedureCallForBatchMulti(action, object, role, inputData, batchRank);
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::cleanUpRecordAction
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231222
**
*************************************************************************/
void DdlGenDbaAccess::cleanUpRecordAction()
{
    this->m_modifiedSet.clear();

    if (this->m_recordActionVector.empty() == false)
    {
        std::set<DBA_DYNST_ENUM>      keepDeleteSet;

        keepDeleteSet.insert(DictCriter);
        keepDeleteSet.insert(DictPermVal);
        keepDeleteSet.insert(FctSecuProfCompo);

        std::vector<DBA_DYNFLD_STP> unchangedRecVector;
        unchangedRecVector.reserve(this->m_recordActionVector.size());

        for (auto& it : this->m_recordActionVector)
        {
            bool bExists     = false;
            DBA_SetMagicDate(it.first, it.first->getDynStEn(), it.first->getObjectEn());
            bool bIsModified = this->isModified(it.first, bExists, it.second);

            if (bIsModified || bExists)
            {
                for (auto& actionIt : it.second)
                {
                    actionIt.m_bExists = bExists;
                    actionIt.m_bIsModified = bIsModified;
                }
            }
        }

        for (auto& it : this->m_recordActionVector)
        {
            bool bToDo           = false;
            bool bToDelete       = false;
            bool bToOneDelete    = false;
            bool bToRemoveDelete = false;
            bool bIsModifed      = it.second.begin()->m_bIsModified;
            bool bExists         = it.second.begin()->m_bExists;
            for (auto& actionIt : it.second)
            {
                if (actionIt.m_bToDo)
                {
                    if (actionIt.m_action == Delete)
                    {
                        bToDelete = true;

                        if (bToOneDelete)
                        {
                            actionIt.m_bToDo = false;
                        }
                        else if (actionIt.m_object != FctSecuProfCompo ||
                                 this->m_modifiedSet.find(actionIt.m_object) == this->m_modifiedSet.end())
                        {
                            bToOneDelete = true;

                            if (actionIt.m_bExists)
                            {
                                bToRemoveDelete = false;
                            }
                            else
                            {
                                bToRemoveDelete = true;
                            }
                        }
                        else if (bIsModifed == false)
                        {
                            bIsModifed = true;
                            bToDo = true;

                            for (auto& actionForUpIt : it.second)
                            {
                                actionForUpIt.m_bIsModified = true;
                            }
                        }
                        continue;
                    }
                    else if (bToDelete &&
                             actionIt.m_action == Update)
                    {
                        bToDelete = false;

                        if (actionIt.m_bExists == false)
                        {
                            actionIt.m_action = Insert;
                        }

                        if (keepDeleteSet.find(actionIt.m_object) != keepDeleteSet.end())
                        {
                            actionIt.m_action = Insert;
                            bToRemoveDelete = false;
                        }
                        else
                        {
                            bToRemoveDelete = true;
                        }

                        if (actionIt.m_role == DBA_ROLE_STATUS)
                        {
                            actionIt.m_bToDo = false;
                            continue;
                        }
                    }
                    else if (bToDelete &&
                             actionIt.m_bExists &&
                             actionIt.m_action == Insert)
                    {
                        bToDelete = false;

                        if (keepDeleteSet.find(actionIt.m_object) == keepDeleteSet.end())
                        {
                            actionIt.m_action = Update;
                            bToRemoveDelete = true;
                        }

                        if (actionIt.m_bIsModified == false)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        bToDelete = false;
                    }

                    bToDo = true;
                }
            }

            bool bUnchanged = false;
            if (bToDelete)
            {
                if (bExists)
                {
                    for (auto& actionIt : it.second)
                    {
                        if (actionIt.m_action != Delete)
                        {
                            actionIt.m_bToDo = false;
                        }
                    }
                }
                else
                {
                    bUnchanged = true;
                }
            }
            else if (bToDo && bIsModifed)
            {
                if (bToRemoveDelete)
                {
                    for (auto& actionIt : it.second)
                    {
                        if (actionIt.m_action == Delete)
                        {
                            actionIt.m_bToDo = false;
                        }
                    }
                }
                this->linkRecords(it.first, true);
            }
            else
            {
                bUnchanged = true;
            }

            if (bUnchanged)
            {
                unchangedRecVector.push_back(it.first);
            }
            else if (this->m_modifiedSet.find(it.second.begin()->m_object) == this->m_modifiedSet.end())
            {
                this->m_modifiedSet.insert(it.second.begin()->m_object);
            }
        }

        for (auto &it : unchangedRecVector)
        {
            this->m_recordActionVector.erase(it);
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::fillRecordsId
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240129
**
*************************************************************************/
void DdlGenDbaAccess::fillRecordsId(bool bFinal)
{
    auto& toLoadRecordMap = (bFinal ? this->m_toLoadFinalRecordMap : this->m_toLoadRecordMap);

    if (toLoadRecordMap.empty() == false)
    {
        MemoryPool mp;
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);

        std::map<DBA_DYNST_ENUM, std::set<DBA_DYNFLD_STP>>                  toReLoadRecordMap;
        std::map<DBA_DYNST_ENUM, std::set<DBA_DYNFLD_STP>>                  complexRecordMap;
        std::map<DBA_DYNFLD_STP, std::map<FIELD_IDX_T, DBA_DYNFLD_STP>>     recordLinks;

        std::map<std::string, DBA_DYNFLD_STP> resultMap;

        auto toLoadSize = toLoadRecordMap.size();

        for (auto& recordToLoadIt : toLoadRecordMap)
        {
            auto refEntityStp = DBA_GetDictEntitySt(GET_OBJ_DYNST(recordToLoadIt.first));
            if (refEntityStp != nullptr &&
                refEntityStp->bkAttrNbr == 1 &&
                refEntityStp->primKeyNbr == 1 &&
                IS_ID_TYPE(refEntityStp->primKeyTab[0]->dataTpProgN))
            {
                bool bIsId = IS_ID_TYPE(refEntityStp->bkAttr[0]->dataTpProgN);

                RequestHelper       requestHelper(&ddlGenConnGuard.getDbiConn());
                bool                bOptim = (recordToLoadIt.second.size() > OPTIM_LIMIT_SIZE);
                std::stringstream   filter;

                auto& recordByIdMap = this->m_mapIdByObjEnMap[GET_OBJ_DYNST(recordToLoadIt.first)];

                if (bOptim)
                {
                    DBA_CreateTempTables(requestHelper.getDbiConn(), IN_OBJECT);
                }

                if (bOptim == false)
                {
                    filter
                        << std::endl << refEntityStp->bkAttr[0]->sqlName << " IN (";
                }

                bool bFirst = true;
                for (auto& recordIt : recordToLoadIt.second)
                {
                    if (GET_ID(recordIt, refEntityStp->primKeyTab[0]->progN) > 0)
                    {
                        continue;
                    }

                    if (bOptim)
                    {
                        if (bFirst)
                        {
                            bFirst = false;
                        }

                        auto inObjectStp = mp.allocDynst(FILEINFO, A_InObject);
                        if (bIsId)
                        {
                            SET_ID(inObjectStp, A_InObject_ObjId, GET_ID(recordIt, refEntityStp->bkAttr[0]->progN));
                        }
                        else
                        {
                            SET_STRING(inObjectStp, A_InObject_ObjCd, GET_STRING(recordIt, refEntityStp->bkAttr[0]->progN));
                        }
                        requestHelper.setNewRecordForBatch(inObjectStp);
                    }
                    else
                    {
                        if (bFirst)
                        {
                            bFirst = false;
                        }
                        else
                        {
                            filter << ", ";
                        }
                        if (bIsId)
                        {
                            filter
                                << GET_ID(recordIt, refEntityStp->bkAttr[0]->progN);
                        }
                        else
                        {
                            filter
                                << "'" << GET_STRING(recordIt, refEntityStp->bkAttr[0]->progN) << "'";
                        }
                    }

                    if (bIsId)
                    {
                        resultMap[SYS_Stringer(GET_ID(recordIt, refEntityStp->bkAttr[0]->progN))] = recordIt;
                    }
                    else
                    {
                        resultMap[GET_STRING(recordIt, refEntityStp->bkAttr[0]->progN)] = recordIt;
                    }
                }

                if (bFirst)
                {
                    continue;
                }

                filter
                    << ")";

                std::stringstream requestCmd;

                requestCmd
                    << std::endl << "#SELECT " << refEntityStp->mdSqlName << " null E"
                    << std::endl << refEntityStp->bkAttr[0]->sqlName
                    << std::endl << refEntityStp->primKeyTab[0]->sqlName
                    << std::endl << "#FROM";

                if (bOptim)
                {
                    requestHelper.executeBatch();

                    if (bIsId)
                    {
                        requestCmd
                            << std::endl << "inner join #in_object io on io.object_id = E." << refEntityStp->bkAttr[0]->sqlName
                            << std::endl << "#WHERE";
                    }
                    else
                    {
                        requestCmd
                            << std::endl << "inner join #in_object io on io.object_cd = E." << refEntityStp->bkAttr[0]->sqlName
                            << std::endl << "#WHERE";
                    }
                }
                else
                {
                    requestCmd
                        << std::endl << "#WHERE"
                        << filter.str();
                }

                requestCmd
                    << std::endl << "#END";

                requestHelper.setReadOnly(true);
                requestHelper.setCommand(requestCmd.str());

                char* businessyKey = nullptr;
                ID_T* primaryKey = nullptr;

                requestHelper.addNewOutputData(CodeType);
                requestHelper.getBindVariablePtr(businessyKey);
                requestHelper.addNewOutputData(IdType);
                requestHelper.getBindVariablePtr(primaryKey);

                auto ret = requestHelper.sendCommandForFetch();
                while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                       requestHelper.fetch() == RET_SUCCEED)
                {
                    if (primaryKey != nullptr && businessyKey != nullptr)
                    {
                        auto recordIt = resultMap.find(businessyKey);
                        if (recordIt != resultMap.end())
                        {
                            this->m_mapConvIdByObjEnMap[recordIt->second->getObjectEn()][*primaryKey] = GET_ID(recordIt->second, recordIt->second->getIdIdx());

                            SET_ID(recordIt->second, refEntityStp->primKeyTab[0]->progN, *primaryKey);
                            recordByIdMap[*primaryKey] = recordIt->second;
                        }
                    }
                }
            }
            else
            {
                complexRecordMap[recordToLoadIt.first] = recordToLoadIt.second;
            }
        }

        if (complexRecordMap.empty() == false)
        {
            for (auto& recordLinkIt : this->m_recordLinks)
            {
                for (auto& recordIt : recordLinkIt.second)
                {
                    ID_T id = GET_ID(recordIt.second, recordIt.second->getIdIdx());
                    if (id > 0)
                    {
                        SET_ID(recordLinkIt.first, recordIt.first, id);
                    }
                }
            }

            for (auto& recordToLoadIt : complexRecordMap)
            {
                auto& recordByIdMap = this->m_mapIdByObjEnMap[GET_OBJ_DYNST(recordToLoadIt.first)];
                auto refEntityStp = DBA_GetDictEntitySt(GET_OBJ_DYNST(recordToLoadIt.first));

                if (refEntityStp != nullptr && refEntityStp->primKeyNbr == 1)
                {
                    std::stringstream requestCmd;
                    requestCmd
                        << std::endl << "#SELECT " << refEntityStp->mdSqlName << " null E"
                        << std::endl << refEntityStp->primKeyTab[0]->sqlName
                        << std::endl << "#FROM"
                        << std::endl << "#WHERE";

                    for (int bkPos = 0; bkPos < refEntityStp->bkAttrNbr; bkPos++)
                    {
                        requestCmd
                            << std::endl << refEntityStp->bkAttr[bkPos]->sqlName << " = ?";
                    }

                    requestCmd
                        << std::endl << "#END";

                    for (auto& recordStp : recordToLoadIt.second)
                    {
                        ID_T* primaryKey = nullptr;

                        RequestHelper       requestHelper(&ddlGenConnGuard.getDbiConn());

                        requestHelper.setReadOnly(true);
                        requestHelper.setCommand(requestCmd.str());

                        requestHelper.addNewOutputData(IdType);
                        requestHelper.getBindVariablePtr(primaryKey);

                        bool bToGet = true;
                        for (int bkPos = 0; bkPos < refEntityStp->bkAttrNbr; bkPos++)
                        {
                            if (IS_ID_TYPE(refEntityStp->bkAttr[bkPos]->dataTpProgN) &&
                                refEntityStp->bkAttr[bkPos]->refDictEntityStp != nullptr &&
                                GET_ID(recordStp, refEntityStp->bkAttr[bkPos]->progN))
                            {
                                auto refRecordByIdMap = this->m_mapIdByObjEnMap[refEntityStp->bkAttr[bkPos]->refDictEntityStp->objectEn];
                                auto it = refRecordByIdMap.find(GET_ID(recordStp, refEntityStp->bkAttr[bkPos]->progN));
                                if (it != recordByIdMap.end() && 
                                    GET_ID(it->second, 0) > 0)
                                { 
                                    SET_ID(recordStp, refEntityStp->bkAttr[bkPos]->progN, GET_ID(it->second, 0));
                                }
                                else
                                {
                                    bToGet = false;
                                }
                            }
                            requestHelper.addNewParam(&(recordStp[refEntityStp->bkAttr[bkPos]->progN]), false);
                        }

                        if (bToGet)
                        {
                            auto ret = requestHelper.sendCommandForFetch();
                            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                                requestHelper.fetch() == RET_SUCCEED)
                            {
                                if (primaryKey != nullptr)
                                {
                                    this->m_mapConvIdByObjEnMap[recordStp->getObjectEn()][*primaryKey] = GET_ID(recordStp, recordStp->getIdIdx());

                                    SET_ID(recordStp, refEntityStp->primKeyTab[0]->progN, *primaryKey);
                                    recordByIdMap[*primaryKey] = recordStp;
                                }
                            }
                        }
                    }
                }
            }

            for (auto& recordLinkIt : this->m_recordLinks)
            {
                for (auto& recordIt : recordLinkIt.second)
                {
                    ID_T id = GET_ID(recordIt.second, recordIt.second->getIdIdx());
                    if (id > 0)
                    {
                        SET_ID(recordLinkIt.first, recordIt.first, id);
                    }
                    else
                    {
                        SET_NULL_ID(recordIt.second, recordIt.second->getIdIdx());
                        auto existsRecordStp = this->getRecord(recordIt.second->getObjectEn(), recordIt.second, false, true);
                        if (existsRecordStp != nullptr &&
                            existsRecordStp != recordIt.second &&
                            id != GET_ID(existsRecordStp, existsRecordStp->getIdIdx()))
                        {
                            SET_ID(recordLinkIt.first, recordIt.first, GET_ID(existsRecordStp, existsRecordStp->getIdIdx()));
                        }
                        else
                        {
                            SET_ID(recordIt.second, recordIt.second->getIdIdx(), id);
                            recordLinks[recordLinkIt.first][recordIt.first] = recordIt.second;
                            toReLoadRecordMap[recordIt.second->getDynStEn()].insert(recordIt.second);
                            if (bFinal == false)
                            {
                                this->m_toLoadFinalRecordMap[recordIt.second->getDynStEn()].insert(recordIt.second);
                            }
                        }
                    }
                }
            }
        }

        this->m_recordLinks.clear();
        this->m_recordLinks = recordLinks;
        toLoadRecordMap.clear();

        if (toReLoadRecordMap.empty() == false &&
            toReLoadRecordMap.size() != toLoadSize &&
            complexRecordMap.empty() == false)
        {
            this->fillRecordsId(bFinal);
        }
    }

    if (bFinal)
    {
        std::map<DBA_DYNFLD_STP, std::map<FIELD_IDX_T, DBA_DYNFLD_STP>> recordLinks;

        recordLinks = this->m_recordLinks;
        this->m_recordLinks.clear();

        for (auto& recordLinkIt : recordLinks)
        {
            if (recordLinkIt.first->getDynStEn() == Io_Ext)
            {
                auto newIdIt = this->m_recordNewId.find(GET_ID(recordLinkIt.first, 0));
                if (newIdIt != this->m_recordNewId.end())
                {
                    this->m_recordLinks[newIdIt->second] = recordLinkIt.second;
                }
                else
                {
                    SYS_BreakOnDebug();
                }
            }
            else
            {
                this->m_recordLinks[recordLinkIt.first] = recordLinkIt.second;
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isDataModelChanged
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231222
**
*************************************************************************/
bool DdlGenDbaAccess::isDataModelChanged()
{
    bool bDataModelChanged = false;

    this->cleanUpRecordAction();

    if (this->m_recordActionVector.empty() == false)
    {
        std::set<OBJECT_ENUM> dataModelChnagedObjectSet;

        dataModelChnagedObjectSet.insert(DictEntity);
        dataModelChnagedObjectSet.insert(DictAttr);
        dataModelChnagedObjectSet.insert(DictPermVal);
        dataModelChnagedObjectSet.insert(XdIndex);
        dataModelChnagedObjectSet.insert(XdIndexAttrib);

        for (auto it : dataModelChnagedObjectSet)
        {
            if (this->isModifiedObject(it))
            {
                bDataModelChanged = true;
                break;
            }
        }
    }

    return bDataModelChanged;
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::checkSecurity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-55668 - LJE - 240313
**
*************************************************************************/
bool DdlGenDbaAccess::checkSecurity()
{
    if (this->m_recordActionVector.empty() == false &&
        DBA_IsDboUser(&this->m_ddlGenContext.getRequestHelper()->getDbiConn()) == FALSE)
    {
        for (auto& it : this->m_recordActionVector)
        {
            std::set< ADMIN_RIGHTS_ENUM> adminRightToCheckSet;
            for (auto actionIt : it.second)
            {
                if (actionIt.m_bToDo)
                {
                    switch (actionIt.m_action)
                    {
                        case Insert:
                            adminRightToCheckSet.insert(AdminRights_Create);
                            break;

                        case Update:
                            adminRightToCheckSet.insert(AdminRights_Update);
                            break;

                        case Delete:
                            adminRightToCheckSet.insert(AdminRights_Delete);
                            break;
                    }
                }
            }

            for (auto actionIt : adminRightToCheckSet)
            {
                if (DBA_CheckSecuCheck(nullptr,
                                       it.first,
                                       actionIt,
                                       it.first->getObjectEn(),
                                       nullptr,
                                       TRUE,
                                       TRUE,
                                       FALSE) == FALSE)
                {
                    return false;
                }
            }
        }
    }

    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::flushData
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenDbaAccess::flushData()
{
    LockGuard lockGuard(this->m_lock);

    if (this->m_recordActionVector.empty())
    {
        return RET_GEN_INFO_NOACTION;
    }

    RET_CODE ret    = RET_SUCCEED;
    RET_CODE gblRet = RET_SUCCEED;

    std::string processStr("Saving data");
    DdlGenMsg  processMsg(&this->m_ddlGenContext, true);

    processMsg.setMsgObjType(std::string());
    processMsg.setMsgSqlName(std::string());
    processMsg.setMsgEntitySqlName(std::string());

    {
        CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
        processMsg.printMsg(RET_SRV_INFO_RUNNING, SYS_Stringer(processStr, " : ", now.formatYYYYMMDDSPHMSUS()));
    }

    std::set<DBA_DYNFLD_STP> recordToTreat;

    std::map<DBA_DYNST_ENUM, size_t>      priorityMap;

    priorityMap[A_XdEntity]    = 10;
    priorityMap[A_XdAttrib]    = 20;
    priorityMap[A_XdPermVal]   = 25;
    priorityMap[A_DictEntity]  = 30;
    priorityMap[A_DictAttr]    = 40;
    priorityMap[A_DictCriter]  = 50;
    priorityMap[A_DictPermVal] = 60;
    priorityMap[A_DictFct]     = 70;
    priorityMap[A_XdLabel]     = 97;
    priorityMap[A_DictLabel]   = 98;
    priorityMap[A_ApplMsgTxt]  = 99;

    std::map<DBA_DYNFLD_STP, ID_T> newIdByRecord;

    std::set<DBA_DYNST_ENUM>       insertLast;
    insertLast.insert(A_TabModifStat);

    this->m_objModifStatSet.clear();

    this->fillRecordsId(true);
    this->cleanUpRecordAction();

    std::map<std::string, std::map<DBA_ACTION_ENUM, size_t>> statMap;

    if (this->m_recordActionVector.empty() == false)
    {
        {
            this->m_ddlGenContext.initConnection(nullptr, true);
            DdlGenBatchMultiGuard ddlGenBatchMultiGuard(this->m_ddlGenContext);

            if (this->checkSecurity() == false)
            {
                gblRet = RET_FIN_ERR_SECURITY_ISSUE;
                processMsg.printMsg(gblRet, SYS_Stringer("Check Security failed !"));
                return gblRet;
            }

            for (auto &it : this->m_recordNewId)
            {
                newIdByRecord.insert(std::make_pair(it.second, it.first));
            }

            auto requestHelperPtr = this->m_ddlGenContext.getRequestHelper();
            {
                std::set<DdlGenDbaAccess::Action> serverProcSet;
                auto recordActionVector = this->m_recordActionVector;
                for (auto& it : recordActionVector)
                {
                    for (auto& actionIt : it.second)
                    {
                        if (actionIt.m_bToDo &&
                            serverProcSet.find(actionIt) == serverProcSet.end())
                        {
                            bool bToDo = true;
                            auto procedureStp = DBA_GetStoredProcs(actionIt.m_action,
                                                                   actionIt.m_object,
                                                                   actionIt.m_role,
                                                                   GET_DYNSTENUM(it.first),
                                                                   it.first,
                                                                   NullDynSt);
                            if (procedureStp != nullptr &&
                                procedureStp->server == InternalProc &&
                                procedureStp->fctDefSt.insFct != DBA_InsXdObject &&
                                procedureStp->fctDefSt.updFct != DBA_UpdXdObject &&
                                procedureStp->fctDefSt.delFct != DBA_DelXdObject)
                            {
                                auto& fixActionVector = this->m_recordActionVector[it.first];
                                for (auto& fixActionIt : fixActionVector)
                                {
                                    if (actionIt.m_action == fixActionIt.m_action &&
                                        actionIt.m_object == fixActionIt.m_object &&
                                        actionIt.m_role == fixActionIt.m_role)
                                    {
                                        if (actionIt.m_object == Fmt)
                                        {
                                            bToDo = false;
                                            fixActionIt.m_role = DBA_ROLE_USESTOREDPROC;
                                        }
                                        else if (actionIt.m_object == FmtElt)
                                        {
                                            bToDo = false;
                                            fixActionIt.m_role = DBA_ROLE_DB_ACCESS;
                                        }
                                        else if (actionIt.m_object == ApplUser ||
                                                 actionIt.m_object == Mgr ||
                                                 DBA_IsAnExtOperationObject(actionIt.m_object))
                                        {
                                            bToDo = false;
                                        }
                                        else
                                        {
                                            fixActionIt.m_bToDo = false;
                                            fixActionIt.m_bTreated = true;
                                        }
                                    }
                                }

                                if (bToDo)
                                {
                                    DbiConnectionHelper dbiConnHelper(&requestHelperPtr->getDbiConn());
                                    auto callRecordStp = this->duplicateDynStp(FILEINFO, it.first);

                                    switch (actionIt.m_action)
                                    {
                                        case Insert:
                                            if ((ret = dbiConnHelper.dbaInsert(actionIt.m_object, actionIt.m_role, callRecordStp)) != RET_SUCCEED)
                                            {
                                                gblRet = ret;
                                            }
                                            break;

                                        case Update:
                                            if ((ret = dbiConnHelper.dbaUpdate(actionIt.m_object, actionIt.m_role, callRecordStp)) == RET_SUCCEED)
                                            {
                                                gblRet = ret;
                                            }
                                            break;

                                        case Delete:
                                            if ((ret = dbiConnHelper.dbaDelete(actionIt.m_object, actionIt.m_role, callRecordStp)) == RET_SUCCEED)
                                            {
                                                gblRet = ret;
                                            }
                                            break;
                                    }
                                }
                            }
                            else
                            {
                                serverProcSet.insert(actionIt);
                            }
                        }
                    }
                }
            }

            for (auto& it : this->m_recordNewId)
            {
                if (GET_ID(it.second, it.second->getIdIdx()) == it.first)
                {
                    SET_NULL_ID(it.second, it.second->getIdIdx());
                }
            }

            auto fromImport = this->m_ddlGenContext.ddlGenAction.m_fromImport;
            this->m_ddlGenContext.ddlGenAction.m_fromImport = false;

            DbaTransactionGuard dbaTransactionGuard(requestHelperPtr->getDbiConn(), gblRet);

            RequestHelper::TransactionMode transactionMode = RequestHelper::TransactionMode::AllOrNothing;
            if (fromImport)
            {
                requestHelperPtr->setApplyDVBatchMulti();
                requestHelperPtr->setApplyICBatchMulti();

                requestHelperPtr->setBatchMode(DbiConnection::BatchMode::ExecuteOnce);

                requestHelperPtr->useProcQueryForBatch();
            }
            else
            {
                requestHelperPtr->setBatchMode(DbiConnection::BatchMode::TryAndRetryRowByRow);
                transactionMode = RequestHelper::TransactionMode::MostAsPossible;
            }

            if (transactionMode == RequestHelper::TransactionMode::AllOrNothing)
            {
                requestHelperPtr->setTransactionMode(RequestHelper::TransactionMode::External);
                dbaTransactionGuard.beginTransaction();
                dbaTransactionGuard.setModifStat(2);
            }
            else
            {
                requestHelperPtr->setTransactionMode(transactionMode);
            }
            requestHelperPtr->useDb(this->m_ddlGenContext.getMainDbName());

            for (auto it = this->m_recordActionVector.begin(); it != this->m_recordActionVector.end(); ++it)
            {
                for (auto actionIt = it->second.begin(); actionIt != it->second.end(); ++actionIt)
                {
                    if (actionIt->m_action == Delete &&
                        actionIt->m_bToDo)
                    {
                        auto nextActionIt = actionIt + 1;
                        if (nextActionIt == it->second.end() && it->second.begin()->m_action == Insert)
                        {
                            for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
                            {
                                it2->m_bToDo = false;
                            }
                        }
                        else
                        {
                            if (nextActionIt == it->second.end() || it->second.begin()->m_bIsModified)
                            {
                                if (it->second.begin()->m_action != Insert)
                                {
                                    statMap[it->first->getDictEntityStp()->mdSqlName][actionIt->m_action]++;

                                    size_t  rank = 0;
                                    if (it->first->getDynStEn() == A_FctSecuProfCompo)
                                    {
                                        if (IS_NULLFLD(it->first, A_FctSecuProfCompo_EntDictId))
                                        {
                                            rank = 1000;
                                        }
                                    }

                                    actionIt->m_bTreated = true;
                                    this->addProcedureCallForBatchMulti(actionIt->m_action, actionIt->m_object, actionIt->m_role, it->first, rank);
                                }

                                if (nextActionIt != it->second.end())
                                {
                                    if (nextActionIt->m_action == Update)
                                    {
                                        if (nextActionIt->m_role == DBA_ROLE_STATUS)
                                        {
                                            nextActionIt->m_bToDo = false;
                                        }
                                        else
                                        {
                                            nextActionIt->m_action = Insert;
                                        }
                                    }

                                    if (nextActionIt->m_action == Insert && it->first->getDictEntityStp()->isId())
                                    {
                                        newIdByRecord.insert(std::make_pair(it->first, GET_ID(it->first, it->first->getIdIdx())));
                                    }
                                }
                            }
                            else
                            {
                                nextActionIt->m_action = Update;
                            }
                        }
                        actionIt->m_bToDo = false;
                    }
                }
            }
            ret = requestHelperPtr->executeBatchMulti(false);
            this->fillRecordsId(false);

            size_t skippedRecordNbr = 0;
            std::set<size_t>  currentBatchRankSet;
            int          emptyToTreatCpt = 0;

            do
            {
                bool bInsertAll = (recordToTreat.empty() && skippedRecordNbr > 0);

                skippedRecordNbr = 0;
                recordToTreat.clear();

                /* Manage loop */
                std::map<DBA_DYNFLD_STP, std::map<FIELD_IDX_T, ID_T>> loopManagementMap;
                if (bInsertAll && this->m_recordLinks.empty() == false)
                {
                    for (auto mainIt = this->m_recordLinks.begin(); mainIt != this->m_recordLinks.end(); ++mainIt)
                    {
                        for (auto childIt = mainIt->second.begin(); childIt != mainIt->second.end(); ++childIt)
                        {
                            auto dictattribStp = mainIt->first[childIt->first].getDictAttribStp();
                            if (dictattribStp != nullptr &&
                                dictattribStp->dbMandatoryFlg == FALSE &&
                                dictattribStp->isNullProgBkN == TRUE &&
                                IS_NULLFLD(mainIt->first, childIt->first) == FALSE)
                            {
                                loopManagementMap[mainIt->first][childIt->first] = GET_ID(mainIt->first, childIt->first);
                                SET_NULL_ID(mainIt->first, childIt->first);
                            }
                        }
                    }

                    for (auto loopIt = loopManagementMap.begin(); loopIt != loopManagementMap.end(); ++loopIt)
                    {
                        auto recordLinksIt = this->m_recordLinks.find(loopIt->first);
                        if (recordLinksIt != this->m_recordLinks.end())
                        {
                            for (auto it = loopIt->second.begin(); it != loopIt->second.end(); ++it)
                            {
                                recordLinksIt->second.erase(it->first);
                            }

                            bool bToErase = recordLinksIt->second.empty();
                            for (auto it = recordLinksIt->second.begin(); bToErase && it != recordLinksIt->second.end(); ++it)
                            {
                                if (GET_ID(loopIt->first, it->first) < 0)
                                {
                                    auto newIdIt = this->m_recordNewId.find(GET_ID(loopIt->first, it->first));

                                    if (newIdIt != this->m_recordNewId.end() &&
                                        GET_ID(newIdIt->second, newIdIt->second->getIdIdx()) > 0)
                                    {
                                        SET_ID(loopIt->first, it->first, GET_ID(newIdIt->second, newIdIt->second->getIdIdx()));
                                    }
                                    else
                                    {
                                        bToErase = false;
                                    }
                                }
                            }

                            if (bToErase)
                            {
                                this->m_recordLinks.erase(recordLinksIt->first);
                            }
                        }
                    }

                    if (loopManagementMap.empty() == false && emptyToTreatCpt < 2)
                    {
                        bInsertAll = false;
                    }
                }

                struct CallForBatchStruct
                {
                    DBA_ACTION_ENUM action;
                    OBJECT_ENUM     object;
                    int             role;
                    DBA_DYNFLD_STP  inputData;
                    size_t          batchRank;
                };
                std::map<ID_T, CallForBatchStruct> toInsertMap;

                for (auto it = this->m_recordActionVector.begin(); it != this->m_recordActionVector.end(); ++it)
                {
                    for (auto actionIt = it->second.begin(); actionIt != it->second.end(); ++actionIt)
                    {
                        if (actionIt->m_action == Insert &&
                            actionIt->m_bToDo &&
                            insertLast.find(GET_DYNSTENUM(it->first)) == insertLast.end())
                        {
                            DBA_ACTION_ENUM lastAction = actionIt->m_action;
                            for (auto nextActionIt = actionIt + 1; nextActionIt != it->second.end(); ++nextActionIt)
                            {
                                if (nextActionIt->m_action == Delete)
                                {
                                    nextActionIt->m_bToDo = false;
                                    actionIt->m_bToDo = false;
                                }
                                else
                                {
                                    actionIt->m_bToDo = true;
                                    if (nextActionIt->m_action == Insert)
                                    {
                                        nextActionIt->m_action = Update;
                                    }

                                    if (nextActionIt->m_action == Update &&
                                        nextActionIt->m_role == UNUSED)
                                    {
                                        nextActionIt->m_bToDo = false;
                                    }
                                }
                                lastAction = nextActionIt->m_action;
                            }

                            if (actionIt->m_bToDo == false)
                            {
                                if (lastAction == Delete && actionIt == it->second.begin())
                                {
                                    for (auto nextActionIt = it->second.begin(); nextActionIt != it->second.end(); ++nextActionIt)
                                    {
                                        nextActionIt->m_bToDo = false;
                                    }
                                }
                                continue;
                            }

                            if (bInsertAll ||
                                this->m_recordLinks.find(it->first) == this->m_recordLinks.end())
                            {
                                size_t rank = priorityMap[it->first->getDynStEn()];
                                if (rank == 0)
                                {
                                    rank = MAX_SHORT;

                                    if (it->first->getDynStEn() == A_FctSecuProfCompo)
                                    {
                                        if (IS_NULLFLD(it->first, A_FctSecuProfCompo_EntDictId))
                                        {
                                            rank = 1000;
                                        }
                                    }
                                    else
                                    {
                                        priorityMap[GET_DYNSTENUM(it->first)] = rank;
                                    }
                                }

                                if (this->checkRecord(it->first, false))
                                {
                                    statMap[it->first->getDictEntityStp()->mdSqlName][actionIt->m_action]++;

                                    auto newIdIt = newIdByRecord.find(it->first);
                                    if (newIdIt != newIdByRecord.end())
                                    {
                                        auto& callStruct = toInsertMap[-newIdIt->second];
                                        callStruct.action = actionIt->m_action;
                                        callStruct.object = actionIt->m_object;
                                        callStruct.role = actionIt->m_role;
                                        callStruct.inputData = it->first;
                                        callStruct.batchRank = rank;
                                    }
                                    else
                                    {
                                        this->addProcedureCallForBatchMulti(actionIt->m_action, actionIt->m_object, actionIt->m_role, it->first, rank);
                                        currentBatchRankSet.insert(rank);
                                    }
                                    actionIt->m_bTreated = true;

                                    recordToTreat.insert(it->first);
                                }

                                if (actionIt->m_bTreated &&
                                    loopManagementMap.find(it->first) == loopManagementMap.end())
                                {
                                    actionIt->m_bToDo = false;

                                    if (actionIt->m_role == DBA_ROLE_UDT && this->isStatusOnIns(it->first))
                                    {
                                        for (auto otherActionIt = it->second.begin(); otherActionIt != it->second.end(); ++otherActionIt)
                                        {
                                            if (otherActionIt->m_role == actionIt->m_role ||
                                                otherActionIt->m_role == UNUSED ||
                                                otherActionIt->m_role == DBA_ROLE_STATUS)
                                            {
                                                otherActionIt->m_bToDo = false;
                                            }
                                        }
                                    }
                                }
                                else if (loopManagementMap.empty() == false)
                                {
                                    actionIt->m_action = Update;
                                }
                                break;
                            }
                            else
                            {
                                skippedRecordNbr++;
                            }
                        }
                    }
                }

                for (auto it = toInsertMap.begin(); it != toInsertMap.end(); ++it)
                {
                    if (this->addProcedureCallForBatchMulti(it->second.action, it->second.object, it->second.role, it->second.inputData, it->second.batchRank) == false)
                    {
                        gblRet = requestHelperPtr->getLastRetCode();

                        processMsg.printMsg(gblRet, "Error while insert/update/delete data see log files");
                        requestHelperPtr->printMsg();

                        if (transactionMode == RequestHelper::TransactionMode::AllOrNothing)
                        {
                            break;
                        }
                    }
                    currentBatchRankSet.insert(it->second.batchRank);
                }

                requestHelperPtr->copyBatchToCopyMap(this->m_batchToCopyMap, this->m_batchToCopyIdMap, currentBatchRankSet);

                if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR || transactionMode == RequestHelper::TransactionMode::MostAsPossible)
                {
                    ret = requestHelperPtr->executeBatchMulti(false);
                    this->fillRecordsId(false);

                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR || transactionMode == RequestHelper::TransactionMode::MostAsPossible)
                    {
                        for (auto it = loopManagementMap.begin(); it != loopManagementMap.end(); ++it)
                        {
                            for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2)
                            {
                                SET_ID(it->first, it2->first, it2->second);
                            }

                            this->linkRecords(it->first, true);
                        }

                        if (recordToTreat.empty() == false)
                        {
                            std::vector<DBA_DYNFLD_STP> treatedVector;

                            for (auto& it : recordToTreat)
                            {
                                if (newIdByRecord.find(it) != newIdByRecord.end())
                                {
                                    this->m_mapIdByObjEnMap[it->getObjectEn()][GET_ID(it, it->getIdIdx())] = it;
                                }
                            }

                            for (auto it = this->m_recordLinks.begin(); it != this->m_recordLinks.end(); ++it)
                            {
                                for (auto progIt = it->second.begin(); progIt != it->second.end();)
                                {
                                    auto linkIt = recordToTreat.find(progIt->second);
                                    if (linkIt != recordToTreat.end() &&
                                        GET_ID(progIt->second, 0) > 0)
                                    {
                                        SET_ID(it->first, progIt->first, GET_ID(progIt->second, 0));
                                        this->insRecordDepends(it->first, false);

                                        it->second.erase(progIt);

                                        if ((progIt = it->second.begin()) == it->second.end())
                                        {
                                            treatedVector.push_back(it->first);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        ++progIt;
                                    }
                                }
                            }

                            for (auto it = treatedVector.begin(); it != treatedVector.end(); ++it)
                            {
                                this->m_recordLinks.erase(*it);
                            }
                        }
                    }
                    else
                    {
                        gblRet = ret;
                    }
                }

                if (recordToTreat.empty())
                {
                    emptyToTreatCpt++;
                }
                else
                {
                    emptyToTreatCpt = 0;
                }

            } while ((recordToTreat.empty() == false || skippedRecordNbr > 0) &&
                     (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR || transactionMode == RequestHelper::TransactionMode::MostAsPossible));

            if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR || transactionMode == RequestHelper::TransactionMode::MostAsPossible)
            {
                for (auto it = this->m_recordActionVector.begin(); it != this->m_recordActionVector.end(); ++it)
                {
                    for (auto actionIt = it->second.begin(); actionIt != it->second.end(); ++actionIt)
                    {
                        if (actionIt->m_bToDo)
                        {
                            if (this->checkRecord(it->first, true))
                            {
                                statMap[it->first->getDictEntityStp()->mdSqlName][actionIt->m_action]++;
                                actionIt->m_bTreated = true;
                                this->addProcedureCallForBatchMulti(actionIt->m_action, actionIt->m_object, actionIt->m_role, it->first, actionIt->m_role);
                                currentBatchRankSet.insert(priorityMap[GET_DYNSTENUM(it->first)]);
                            }
                            else
                            {
                                gblRet = RET_DBA_ERR_NODATA;

                                BuildBindOption outputBindOption = BuildBindOption::Categ::BusinessKeyOnlyShort;
                                outputBindOption.setDescObject(true);

                                std::vector<DBA_DYNFLD_STP> resultDynStpVector;
                                resultDynStpVector.push_back(it->first);

                                std::string resultString;
                                DBA_GetJSonStringFromDynStp(resultDynStpVector,
                                                            resultString,
                                                            outputBindOption,
                                                            requestHelperPtr->getDbiConn());

                                processMsg.printMsg(gblRet, SYS_Stringer("Unable to insert/update record: ", resultString));
                            }

                            if (actionIt->m_role == DBA_ROLE_UDT && this->isStatusOnIns(it->first))
                            {
                                for (auto otherActionIt = actionIt; otherActionIt != it->second.end(); ++otherActionIt)
                                {
                                    if (otherActionIt->m_role == actionIt->m_role ||
                                        otherActionIt->m_role == UNUSED ||
                                        otherActionIt->m_role == DBA_ROLE_STATUS)
                                    {
                                        otherActionIt->m_bToDo = false;
                                    }
                                }
                            }
                            else
                            {
                                for (auto otherActionIt = actionIt; otherActionIt != it->second.end(); ++otherActionIt)
                                {
                                    if (otherActionIt->m_role == actionIt->m_role)
                                    {
                                        otherActionIt->m_bToDo = false;
                                    }
                                }
                            }
                        }
                    }
                }

                if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
                {
                    requestHelperPtr->copyBatchToCopyMap(this->m_batchToCopyMap, this->m_batchToCopyIdMap, currentBatchRankSet);

                    ret = this->m_ddlGenContext.finishBatchMulti();

                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        for (auto it = this->m_recordActionVector.begin(); it != this->m_recordActionVector.end(); ++it)
                        {
                            auto dbIt = this->m_allDbRecordsMap.find(it->first);
                            if (dbIt != this->m_allDbRecordsMap.end())
                            {
                                if (it->second.back().m_action == Delete)
                                {
                                    this->m_allDbRecordsMap.erase(dbIt);
                                }
                                else
                                {
                                    COPY_DYNST(dbIt->second, dbIt->first, GET_DYNSTENUM(dbIt->first));
                                }
                            }
                            else
                            {
                                this->addToAllDbRecords(it->first);
                            }
                        }
                    }
                    else
                    {
                        gblRet = ret;
                    }
                }

                this->m_recordActionVector.clear();
                this->m_recordLinks.clear();
            }

            if ((RET_GET_LEVEL(gblRet) != RET_LEV_ERROR || transactionMode == RequestHelper::TransactionMode::MostAsPossible) &&
                this->m_ddlGenContext.ddlGenAction.m_bInitEntityOnly == false)
            {
                for (auto& it : this->m_objModifStatSet)
                {
                    if (DBA_IsDboUser(SYS_GetThreadUser()) == FALSE)
                    {
                        DBA_UpdTableModifStat(requestHelperPtr->getDbiConn(), it);
                    }
                    else
                    {
                        auto dictEntityStp = DBA_GetDictEntitySt(it);

                        std::stringstream updTablModifStatStream;
                        updTablModifStatStream
                            << "#UPDATE table_modif_stat null" << std::endl
                            << "last_modif_d = #GETDATE" << std::endl
                            << "#WHERE" << std::endl
                            << "entity_dict_id = " << dictEntityStp->entDictId << std::endl
                            << "#END";

                        requestHelperPtr->setCommand(updTablModifStatStream.str());
                        ret = requestHelperPtr->sendAndGetCommand();

                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            processMsg.printMsg(ret, SYS_Stringer("Error while updating table_modif_stat (", dictEntityStp->entDictId, ")"));
                        }
                    }
                }
            }

            if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR &&
                transactionMode == RequestHelper::TransactionMode::AllOrNothing)
            {
                for (auto it : newIdByRecord)
                {
                    SET_ID(it.first, it.first->getIdIdx(), it.second);
                }
            }
            else
            {
                for (auto it : newIdByRecord)
                {
                    if (IS_NULLFLD(it.first, it.first->getIdIdx()))
                    {
                        SET_ID(it.first, it.first->getIdIdx(), it.second);
                    }
                }
            }

            this->m_ddlGenContext.ddlGenAction.m_fromImport = fromImport;
        }
    }

    if (this->m_ddlGenContext.ddlGenAction.isPrintSummary())
    {
        processMsg.setDdlObjEn(DdlObj_Sql);
        if (this->m_ddlGenContext.ddlGenAction.m_fromImport)
        {
            processMsg.setMsgObjType("");
            if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR)
            {
                processMsg.printMsg(RET_DBA_INFO_MD, "Saving data failed!");
            }
        }
        else
        {
            processMsg.setMsgObjType("Summary");
            processMsg.printMsg(RET_DBA_INFO_MD, "");
        }
        
        if (statMap.empty())
        {
            processMsg.printMsg(RET_DBA_INFO_MD, "Nothing to write");
        }
        else
        {
            for (auto entityIt = statMap.begin(); entityIt != statMap.end(); ++entityIt)
            {
                for (auto actionIt = entityIt->second.begin(); actionIt != entityIt->second.end(); ++actionIt)
                {
                    std::stringstream msgStream;
                    msgStream 
                        << "Entity written: " << std::left << std::setw(30) << entityIt->first
                        << " - action: " << std::left << std::setw(20) << DBA_GetActionName(actionIt->first)
                        << " - count: " << actionIt->second;

                    processMsg.printMsg(RET_DBA_INFO_MD, msgStream.str());
                }
            }
        }
        processMsg.printMsg(RET_DBA_INFO_MD, "");
    }

    if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
    {
        this->m_ddlGenContext.commit();
        {
            CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
            processMsg.printMsg(RET_DBA_INFO_MD, SYS_Stringer(processStr, " done : ", now.formatYYYYMMDDSPHMSUS()));
        }

        if (statMap.empty())
        {
            gblRet = RET_GEN_INFO_NOACTION;
        }
    }
    else
    {
        this->m_ddlGenContext.rollback();
        {
            CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
            processMsg.printMsg(gblRet, SYS_Stringer(processStr, " failed : ", now.formatYYYYMMDDSPHMSUS()));
        }
    }

    this->m_ddlGenContext.endConnection();

    this->m_batchToCopyMap.clear();
    this->m_batchToCopyIdMap.clear();

    for (auto& it : this->m_recordNewId)
    {
        this->m_newIdLinks[it.first] = std::make_pair(it.second->getObjectEn(), GET_ID(it.second, it.second->getIdIdx()));
    }

    this->m_recordNewId.clear();
    this->m_modifiedSet.clear();

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::clear
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::clear()
{
    LockGuard lockGuard(this->m_lock);

    this->m_isMetaDictLoaded = false;
    this->m_isExtendedLoaded = false;
    this->m_isLoadedXdEntitySet.clear();
    this->m_isLoadedObjectSet.clear();
    this->m_mapIdByObjEnMap.clear();
    this->m_mapCodeByObjEnMap.clear();
    this->m_allRecordsMap.clear();
    this->m_allDbRecordsMap.clear();
    this->m_xdEntityAttribBySqlNameMap.clear();
    this->m_xdAttributesByEntityMap.clear();
    this->m_xdEntityFeaturesByEntityMap.clear();
    this->m_xdPemValuesByXdAttribNatMap.clear();
    this->m_xdLabelMap.clear();
    this->m_xdPartitionByEntityMap.clear();
    this->m_xdAttribCustoByEntityMap.clear();
    this->m_xdIndexByEntityMap.clear();
    this->m_xdEntityIndexByEntityMap.clear();
    this->m_xdIndexAttribByIndexMap.clear();
    this->m_xdIndexAttribByBkMap.clear();
    this->m_xdPartitonIndexByIndexMap.clear();
    this->m_dictAttributesMap.clear();
    this->m_dictEntityAttribBySqlNameMap.clear();
    this->m_dictEntityCriteriaBySqlNameMap.clear();
    this->m_dictPemValuesByAttribMap.clear();
    this->m_dictSprocBySqlNameMap.clear();
    this->m_dictSprocParamByProcMap.clear();
    this->m_dictSprocReturnsByProcMap.clear();
    this->m_dictEntityConstrByEntityMap.clear();
    this->m_dictEntityDependsByKeyMap.clear();
    this->m_dictEntityDependsByDepEntityMap.clear();
    this->m_dictLabelMap.clear();
    this->m_xdAttributeComnentByKeyMap.clear();
    this->m_dictAttributeComnentByKeyMap.clear();
    this->m_newId = 0;
    this->m_recordActionVector.clear();
    this->m_recordLinks.clear();
    this->m_recordNewId.clear();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::allocDynSt
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::allocDynSt(const char *fileName, const int line, const DBA_DYNST_ENUM & dynstEn)
{
    return this->m_mp.allocDynst(fileName, line, dynstEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::duplicateDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::duplicateDynStp(const char *fileName, const int line, const DBA_DYNFLD_STP dynStp)
{
    auto newDynStp = this->m_mp.duplicate(fileName, line, dynStp);
    for (int fldPos = 0; fldPos < GET_FLD_NBR(dynStp->getDynStEn()); ++fldPos)
    {
        if (IS_SETFLD(dynStp, fldPos) == TRUE)
        {
            SET_SETFLG_T(newDynStp, fldPos);
        }
    }
    return newDynStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::ownerDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
void DdlGenDbaAccess::ownerDynStp(const DBA_DYNFLD_STP dynstStp)
{
    this->m_mp.ownerDynStp(dynstStp);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::freeDynSt
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210714
**
*************************************************************************/
void DdlGenDbaAccess::freeDynStp(DBA_DYNFLD_STP &dynstStp)
{
    this->m_mp.freeDynStp(dynstStp);
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::linkRecords
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::linkRecords(DBA_DYNFLD_STP recordStp, bool bCheck)
{
    if (recordStp->isAllDynSt())
    {
        DICT_ENTITY_STP dictEntityStp = recordStp->getDictEntityStp();
        if (dictEntityStp != nullptr)
        {
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if (IS_ID_TYPE(dictAttribStp->dataTpProgN) &&
                    (dictAttribStp->refDictEntityStp != nullptr || dictAttribStp->linkedAttrDictStp != nullptr) &&
                    (dictAttribStp->primFlg == FALSE || dictEntityStp->isId() == false || dictEntityStp->pkRuleEn == PkRule_NoIdentity) &&
                    dictAttribStp->precompFlg == FALSE &&
                    dictAttribStp->custFlg == FALSE &&
                    dictAttribStp->isPhysicalAttribute() &&
                    IS_NULLFLD(recordStp, dictAttribStp->progN) == FALSE &&
                    GET_ID(recordStp, dictAttribStp->progN) != 0)
                {
                    if (bCheck && GET_ID(recordStp, dictAttribStp->progN) < 0)
                    {
                        auto checkIt = this->m_recordNewId.find(GET_ID(recordStp, dictAttribStp->progN));
                        if (checkIt != this->m_recordNewId.end() &&
                            GET_ID(checkIt->second, 0) > 0)
                        {
                            SET_ID(recordStp, dictAttribStp->progN, GET_ID(checkIt->second, 0));

                            if (dictAttribStp->busKeyFlg == TRUE || dictAttribStp->primFlg == TRUE)
                            {
                                this->insRecordDepends(recordStp, false);
                            }
                        }
                    }

                    if (GET_ID(recordStp, dictAttribStp->progN) > 0)
                    {
                        DBA_DYNFLD_STP parentRecordStp = nullptr;
                        
                        if (dictAttribStp->refDictEntityStp != nullptr)
                        {
                            if (dictAttribStp->refDictEntityStp->pkRuleEn == PkRule_NoIdentity)
                            {
                                parentRecordStp = this->getRecordById(dictAttribStp->refDictEntityStp->objectEn, GET_ID(recordStp, dictAttribStp->progN), true);
                            }
                        }
                        else if (dictAttribStp->linkedAttrDictStp != nullptr &&
                                 dictAttribStp->linkedAttrDictStp->dataTpProgN == DictType &&
                                 dictAttribStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
                                 dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity &&
                                 IS_NULLFLD(recordStp, dictAttribStp->linkedAttrDictStp->progN) == FALSE)
                        {
                            auto refDictEntityStp = DBA_GetDictEntityByDictId(GET_DICT(recordStp, dictAttribStp->linkedAttrDictStp->progN));

                            parentRecordStp = this->getRecordById(refDictEntityStp->objectEn, GET_ID(recordStp, dictAttribStp->progN), true);
                        }
                        
                        if (parentRecordStp != nullptr)
                        {
                            auto allActionIt = this->m_recordActionVector.find(parentRecordStp);
                            if (allActionIt != this->m_recordActionVector.end())
                            {
                                bool bDeleted = false;
                                for (auto actionIt = allActionIt->second.begin(); actionIt != allActionIt->second.end(); ++actionIt)
                                {
                                    if (actionIt->m_bTreated || actionIt->m_bToDo == false)
                                    {
                                        continue;
                                    }

                                    if (actionIt->m_action == Insert ||
                                        (bDeleted && actionIt->m_action == Update))
                                    {
                                        this->linkOneRecord(recordStp, dictAttribStp->progN, parentRecordStp);
                                        break;
                                    }
                                    else if (actionIt->m_action == Delete)
                                    {
                                        bDeleted = true;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        auto parentRecordStp = this->getRecordById(NullEntity, GET_ID(recordStp, dictAttribStp->progN), true);

                        if (parentRecordStp != nullptr)
                        {
                            this->linkOneRecord(recordStp, dictAttribStp->progN, parentRecordStp);
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::linkOneRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::linkOneRecord(DBA_DYNFLD_STP recordStp, FIELD_IDX_T progN, DBA_DYNFLD_STP parentRecordStp)
{
    this->m_recordLinks[recordStp][progN] = parentRecordStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::replaceLinkRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::replaceLinkRecord(DBA_DYNFLD_STP oldRecordStp, FIELD_IDX_T oldProgN, DBA_DYNFLD_STP newRecordStp, FIELD_IDX_T newProgN)
{
    auto linkRecordsIt = this->m_recordLinks.find(oldRecordStp);
    if (linkRecordsIt != this->m_recordLinks.end())
    {
        if (oldProgN == Null_Dynfld)
        {
            this->m_recordLinks[newRecordStp] = linkRecordsIt->second;
            this->m_recordLinks.erase(oldRecordStp);
        }
        else
        {
            auto progIt = linkRecordsIt->second.find(oldProgN);
            if (progIt != linkRecordsIt->second.end())
            {
                this->m_recordLinks[newRecordStp][newProgN] = progIt->second;

                linkRecordsIt->second.erase(progIt);
            }

            if (linkRecordsIt->second.empty())
            {
                this->m_recordLinks.erase(linkRecordsIt);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::checkRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::checkRecord(DBA_DYNFLD_STP recordStp, bool bPrintMsg)
{
    if (recordStp != nullptr &&
        recordStp->isAllDynSt())
    {
        DICT_ENTITY_STP dictEntityStp = recordStp->getDictEntityStp();
        if (dictEntityStp != nullptr)
        {
            DdlGenMsg  processMsg(&this->m_ddlGenContext, true);
            processMsg.setMsgObjType(std::string());
            processMsg.setMsgSqlName(std::string());
            processMsg.setMsgEntitySqlName(std::string());

            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if (IS_ID_TYPE(dictAttribStp->dataTpProgN) &&
                    (dictAttribStp->primFlg == FALSE || dictEntityStp->isId() == false || dictEntityStp->pkRuleEn == PkRule_NoIdentity) &&
                    dictAttribStp->precompFlg == FALSE &&
                    dictAttribStp->custFlg == FALSE &&
                    dictAttribStp->isPhysicalAttribute() &&
                    GET_ID(recordStp, dictAttribStp->progN) < 0)
                {
                    auto checkIt = this->m_recordNewId.find(GET_ID(recordStp, dictAttribStp->progN));
                    if (checkIt != this->m_recordNewId.end() &&
                        GET_ID(checkIt->second, 0) > 0)
                    {
                        SET_ID(recordStp, dictAttribStp->progN, GET_ID(checkIt->second, 0));

                        if (dictAttribStp->busKeyFlg == TRUE || dictAttribStp->primFlg == TRUE)
                        {
                            this->insRecordDepends(recordStp, false);
                        }
                    }
                    else if (checkIt != this->m_recordNewId.end() &&
                             checkIt->second->getObjectEn() == MktSegt)
                    {
                        if (this->checkRecord(checkIt->second, true))
                        {
                            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
                            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());
                            RequestHelper       requestHelper(dbiConnHelper);
                            requestHelper.setReadOnly(true);

                            std::stringstream requestCmd;
                            requestCmd
                                << std::endl << "#SELECT market_segment null std"
                                << std::endl << "id"
                                << std::endl << "#FROM"
                                << std::endl << "#WHERE"
                                << std::endl << "grid_id = " << GET_ID(checkIt->second, A_MktSegt_GridId);

                            if (IS_NULLFLD(checkIt->second, A_MktSegt_AbcissaListId))
                            {
                                requestCmd
                                    << std::endl << "abcissa_list_id is null ";
                            }
                            else
                            {
                                requestCmd
                                    << std::endl << "abcissa_list_id = " << GET_ID(checkIt->second, A_MktSegt_AbcissaListId);
                            }
                            if (IS_NULLFLD(checkIt->second, A_MktSegt_OrdinateListId))
                            {
                                requestCmd
                                    << std::endl << "ordinate_list_id is null ";
                            }
                            else
                            {
                                requestCmd
                                    << std::endl << "ordinate_list_id = " << GET_ID(checkIt->second, A_MktSegt_OrdinateListId);
                            }
                            if (IS_NULLFLD(checkIt->second, A_MktSegt_MktStructId))
                            {
                                requestCmd
                                    << std::endl << "market_structure_id is null ";
                            }
                            else
                            {
                                requestCmd
                                    << std::endl << "market_structure_id = " << GET_ID(checkIt->second, A_MktSegt_MktStructId);
                            }
                            requestCmd
                                << std::endl << "#END";

                            requestHelper.setCommand(requestCmd.str());

                            ID_T* primaryKey = nullptr;
                            requestHelper.addNewOutputData(IdType);
                            requestHelper.getBindVariablePtr(primaryKey);

                            RET_CODE ret = requestHelper.sendCommandForFetch();
                            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                            {
                                ret = requestHelper.fetch();
                            }

                            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && 
                                primaryKey != nullptr)
                            {
                                SET_ID(checkIt->second, A_MktSegt_Id, *primaryKey);

                                this->m_recordNewId[GET_ID(recordStp, dictAttribStp->progN)] = checkIt->second;

                                SET_ID(recordStp, dictAttribStp->progN, GET_ID(checkIt->second, 0));
                            }
                            else
                            {
                                processMsg.printMsg(RET_DBA_ERR_NODATA, 
                                                    SYS_Stringer("Unknown record of 'maket_segment': ", this->getKey(checkIt->second)));
                            }
                        }
                    }
                    else
                    {
                        auto it = this->m_newIdLinks.find(GET_ID(recordStp, dictAttribStp->progN));
                        if (it != this->m_newIdLinks.end())
                        {
                            SET_ID(recordStp, dictAttribStp->progN, it->second.second);
                        }

                        if (bPrintMsg)
                        {
                            if (checkIt != this->m_recordNewId.end())
                            {
                                auto refDictEntityStp = checkIt->second->getDictEntityStp();

                                if (refDictEntityStp != nullptr)
                                {
                                    processMsg.printMsg(RET_DBA_ERR_NODATA,
                                                        SYS_Stringer("Unknown record of '", refDictEntityStp->mdSqlName, "': ", this->getKey(checkIt->second)));
                                }
                                else
                                {
                                    processMsg.printMsg(RET_DBA_ERR_NODATA,
                                                        SYS_Stringer("Unknown record of structure '", DBA_GetDynStCName(checkIt->second->getDynStEn()), "': ", this->getKey(checkIt->second)));
                                }
                            }
                            else
                            {
                                processMsg.printMsg(RET_DBA_ERR_NODATA,
                                                    SYS_Stringer("Unknown record of '", 
                                                                 dictEntityStp->mdSqlName, 
                                                                 ".",
                                                                 dictAttribStp->sqlName));
                            }
                        }

                        return false;
                    }
                }
            }
        }
    }

    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selRecords
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::selRecords(OBJECT_ENUM objectEn, int role, DBA_DYNFLD_STP inputData, std::vector<DBA_DYNFLD_STP> &outputRecords)
{
    switch (GET_OBJECT_CST(objectEn))
    {
        case XdEntityCst:
            if (role == DBA_ROLE_UDT &&
                inputData->getDynStEn() == S_XdEntity &&
                IS_NULLFLD(inputData, S_XdEntity_SqlName) == false)
            {
                /* sel_sh_xd_entity_by_sqlname */
                DBA_DYNFLD_STP recordStp = this->getRecord(objectEn, inputData);

                if (recordStp != nullptr)
                {
                    outputRecords.push_back(recordStp);

                    auto& recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                    if (IS_NULLFLD(recordStp, A_XdEntity_LinkedXdEntityId) == false)
                    {
                        auto mainRecordIt = recordBIdMap.find(GET_ID(recordStp, A_XdEntity_LinkedXdEntityId));
                        if (mainRecordIt != recordBIdMap.end())
                        {
                            outputRecords.push_back(mainRecordIt->second);
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }

                    for (auto &xdEntityIt : recordBIdMap)
                    {
                        if (CMP_DYNFLD(recordStp, xdEntityIt.second, A_XdEntity_LinkedXdEntityId, A_XdEntity_Id, IdType) == 0)
                        {
                            outputRecords.push_back(xdEntityIt.second);
                        }
                    }
                }
            }
            else if (role == UNUSED &&
                     (inputData->getDynStEn() == S_XdEntity && IS_NULLFLD(inputData, S_XdEntity_NatEn) == false) ||
                     (inputData->getDynStEn() == Adm_Arg && IS_NULLFLD(inputData, Adm_Arg_NatEn) == false))
            {
                /* sel_sh_xd_entity_by_nat */
                ENUM_T entNatEn = (inputData->getDynStEn() == S_XdEntity ? GET_ENUM(inputData, S_XdEntity_NatEn) : GET_ENUM(inputData, Adm_Arg_NatEn));

                auto& recordBIdMap = this->m_mapIdByObjEnMap[objectEn];
                for (auto &xdEntityIt : recordBIdMap)
                {
                    if (entNatEn == 0 || GET_ENUM(xdEntityIt.second, A_XdEntity_NatEn) == entNatEn)
                    {
                        outputRecords.push_back(xdEntityIt.second);
                    }
                }
            }
            else if (role == DBA_ROLE_FORMAT &&
                     (inputData->getDynStEn() == S_XdEntity && IS_NULLFLD(inputData, S_XdEntity_NatEn) == false))
            {
                /* sel_denom_format_for_xd */

                auto fmtStp = this->getRecordByCode(Fmt, GET_SYSNAME(inputData, S_XdEntity_SqlName));
                if (fmtStp != nullptr)
                {
                    DICT_T fmtDictId = 0;
                    DICT_T fmtEltDictId = 0;
                    DBA_GetDictId(Fmt, &fmtDictId);
                    DBA_GetDictId(FmtElt, &fmtEltDictId);

                    std::vector<DBA_DYNFLD_STP> fmtDenomVector;
                    this->selRecordsByParent(Denom, GET_ID(fmtStp, A_Fmt_Id), true, fmtDenomVector, Fmt);
                    for (auto &denomStp : fmtDenomVector)
                    {
                        outputRecords.push_back(denomStp);
                    }

                    std::vector<DBA_DYNFLD_STP> fmtEltVector;
                    this->selRecordsByParent(FmtElt, GET_ID(fmtStp, A_Fmt_Id), true, fmtEltVector);
                    for (auto &fmtEltStp : fmtEltVector)
                    {
                        std::vector<DBA_DYNFLD_STP> fmtEltDenomVector;
                        this->selRecordsByParent(Denom, GET_ID(fmtEltStp, A_FmtElt_Id), true, fmtEltDenomVector, FmtElt);
                        for (auto &denomStp : fmtEltDenomVector)
                        {
                            outputRecords.push_back(denomStp);
                        }
                    }
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }

            if (outputRecords.size() > 1 && role != DBA_ROLE_FORMAT)
            {
                std::sort(outputRecords.begin(), outputRecords.end(),
                          [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                          {
                              if (IS_NULLFLD(a, A_XdEntity_DictEntityValue) == false &&
                                  IS_NULLFLD(b, A_XdEntity_DictEntityValue) == false)
                              {
                                  return GET_INT(a, A_XdEntity_DictEntityValue) < GET_INT(b, A_XdEntity_DictEntityValue);
                              }
                              else if (IS_NULLFLD(a, A_XdEntity_DictEntityValue) == false)
                              {
                                  return true;
                              }
                              return false;
                          });
            }
            break;

        case XdAttribCst:
        {
            if (role == UNUSED &&
                inputData->getDynStEn() == S_XdEntity &&
                IS_NULLFLD(inputData, S_XdEntity_Id) == false)
            {
                auto& xdAttribVector = this->m_xdAttributesByEntityMap[GET_ID(inputData, S_XdEntity_Id)];

                for (auto& it : xdAttribVector)
                {
                    outputRecords.push_back(it);
                }
            }
            break;
        }

        case XdLabelCst:
        {
            if (role == DBA_ROLE_FORMAT &&
                inputData->getDynStEn() == S_XdEntity &&
                IS_NULLFLD(inputData, S_XdEntity_SqlName) == false)
            {
                auto& xdEntity = this->m_mapCodeByObjEnMap[XdEntity][GET_SYSNAME(inputData, S_XdEntity_SqlName)];

                if (xdEntity != nullptr)
                {
                    DICT_T entityDictId = 0;
                    DBA_GetDictId(XdEntity, &entityDictId);

                    auto& xdLabelEntityMap = this->m_xdLabelMap[entityDictId][GET_ID(xdEntity, A_XdEntity_Id)];

                    for (auto& langIt : xdLabelEntityMap)
                    {
                        for (auto& natIt : langIt.second)
                        {
                            outputRecords.push_back(natIt.second);
                        }
                    }

                    DICT_T attribDictId = 0;
                    DBA_GetDictId(XdAttrib, &attribDictId);
                    auto& xdAttribVector = this->m_xdAttributesByEntityMap[GET_ID(xdEntity, A_XdEntity_Id)];

                    for (auto it = xdAttribVector.begin(); it != xdAttribVector.end(); ++it)
                    {
                        auto& xdLabelAttribMap = this->m_xdLabelMap[attribDictId][GET_ID((*it), A_XdAttrib_Id)];

                        for (auto& langIt : xdLabelAttribMap)
                        {
                            for (auto& natIt : langIt.second)
                            {
                                outputRecords.push_back(natIt.second);
                            }
                        }
                    }
                }
            }
            break;
        }

        case DictEntityCst:
            if (role == UNUSED &&
                     (inputData->getDynStEn() == S_DictEntity && IS_NULLFLD(inputData, S_DictEntity_NatEn) == false) ||
                     (inputData->getDynStEn() == Adm_Arg && IS_NULLFLD(inputData, Adm_Arg_NatEn) == false))
            {
                ENUM_T entNatEn = (inputData->getDynStEn() == S_DictEntity ? GET_ENUM(inputData, S_DictEntity_NatEn) : GET_ENUM(inputData, Adm_Arg_NatEn));

                auto& recordBIdMap = this->m_mapIdByObjEnMap[objectEn];
                for (auto xdEntityIt = recordBIdMap.begin(); xdEntityIt != recordBIdMap.end(); ++xdEntityIt)
                {
                    if (entNatEn == 0 || GET_ENUM(xdEntityIt->second, A_DictEntity_NatEn) == entNatEn)
                    {
                        outputRecords.push_back(xdEntityIt->second);
                    }
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }

            std::sort(outputRecords.begin(), outputRecords.end(),
                      [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                      {
                          return GET_INT(a, A_DictEntity_DictId) < GET_INT(b, A_DictEntity_DictId);
                      });
            break;

        case DictSprocCst:
        {
            auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

            for (auto it = recordBIdMap.begin(); it != recordBIdMap.end(); ++it)
            {
                if (CMP_DYNFLD(inputData, it->second, S_DictSproc_EntityDictId, A_DictSproc_EntityDictId, DictType) == 0)
                {
                    outputRecords.push_back(it->second);
                }
            }
            break;
        }

        case DictSegmentCst:
        {
            auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

            for (auto it = recordBIdMap.begin(); it != recordBIdMap.end(); ++it)
            {
                if (inputData == nullptr ||
                    CMP_DYNFLD(inputData, it->second, Adm_Arg_Id, A_DictSegment_DbDictId, DictType) == 0)
                {
                    outputRecords.push_back(it->second);
                }
            }
            break;
        }

        case DictDatabaseCst:
        {
            auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

            for (auto it = recordBIdMap.begin(); it != recordBIdMap.end(); ++it)
            {
                outputRecords.push_back(it->second);
            }
            break;
        }

        case DictDependsCst:
        {
            if (role == UNUSED &&
                inputData->getDynStEn() == S_DictDepends &&
                IS_NULLFLD(inputData, S_DictDepends_SqlName) == false)
            {
                auto& recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                for (auto it = recordBIdMap.begin(); it != recordBIdMap.end(); ++it)
                {
                    if (CMP_DYNFLD(inputData, it->second, S_DictDepends_SqlName, A_DictDepends_SqlName, LongSysnameType) == 0)
                    {
                        outputRecords.push_back(it->second);
                    }
                }
            }
            else if (role == UNUSED &&
                     inputData->getDynStEn() == A_DictDepends &&
                     IS_NULLFLD(inputData, A_DictDepends_ObjType) == false &&
                     IS_NULLFLD(inputData, A_DictDepends_DepSqlName) == false)
            {
                auto& recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                for (auto it = recordBIdMap.begin(); it != recordBIdMap.end(); ++it)
                {
                    if (CMP_DYNFLD(inputData, it->second, A_DictDepends_ObjType, A_DictDepends_ObjType, SysnameType) == 0 &&
                        CMP_DYNFLD(inputData, it->second, A_DictDepends_DepSqlName, A_DictDepends_DepSqlName, LongSysnameType) == 0)
                    {
                        outputRecords.push_back(it->second);
                    }
                }
            }
            else if (role == UNUSED &&
                     inputData->getDynStEn() == S_DictDepends &&
                     IS_NOTNULL(inputData, S_DictDepends_DictId))
            {
                auto &recordBIdMap = this->m_mapIdByObjEnMap[objectEn];

                /* sel_all_dict_depends_by_dedid
                #SELECT dict_depends all std
                    #FROM
                    #WHERE
                    object_type = 'procedure'
                    dep_entity_dict_id = $DICT_ENTITY
                    dep_object_dict_id = @dep_object_dict_id
                    access_e in($DICT_DEPENDS_ACCESS_RETURNS, $DICT_DEPENDS_ACCESS_INSERT, $DICT_DEPENDS_ACCESS_UPDATE, $DICT_DEPENDS_ACCESS_PARAM, $DICT_DEPENDS_ACCESS_CALL_PARAM)
                    dyn_nat_e in($DYN_NAT_ALL, $DYN_NAT_SHORT, $DYN_NAT_UD_ONLY, $DYN_NAT_ALL_DB)
                    #END
                */

                for (auto &it : recordBIdMap)
                {
                    if (GET_DICT(it.second, A_DictDepends_DepEntityDictId) == DictEntityCst &&
                        strcmp(GET_SYSNAME(it.second, A_DictDepends_ObjType), "procedure") == 0 &&
                        CMP_DYNFLD(inputData, it.second, S_DictDepends_DictId, A_DictDepends_DepObjDictId, DictType) == 0)
                    {
                        switch (GET_A_DictDepends_AccessEn(it.second))
                        {
                            case DictDependsAccessEn::Returns:
                            case DictDependsAccessEn::Insert:
                            case DictDependsAccessEn::Update:
                            case DictDependsAccessEn::Parameter:
                            case DictDependsAccessEn::CallParameter:
                                switch (static_cast<DBA_DYNTYPE_ENUM>(GET_ENUM(it.second, A_DictDepends_DynNatEn)))
                                {
                                    case DynType_All:
                                    case DynType_Short:
                                    case DynType_UdOnly:
                                    case DynType_AllDb:
                                        outputRecords.push_back(it.second);
                                        break;

                                    default:
                                        break;
                                }
                                break;

                            case DictDependsAccessEn::Access:
                            case DictDependsAccessEn::None:
                            case DictDependsAccessEn::Delete:
                            case DictDependsAccessEn::Truncate:
                            case DictDependsAccessEn::Call:
                            case DictDependsAccessEn::Create:
                                break;
                        }
                    }
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
            break;
        }

        case XdIndexCst:
        {
            if (role == UNUSED &&
                inputData->getDynStEn() == A_XdEntity &&
                IS_NULLFLD(inputData, A_XdEntity_Id) == false)
            {
                auto& idxBIdVector = this->m_xdIndexByEntityMap[GET_ID(inputData, A_XdEntity_Id)];

                for (auto it : idxBIdVector)
                {
                    outputRecords.push_back(it);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
            break;
        }

        case XdIndexAttribCst:
        {
            if (role == UNUSED &&
                inputData->getDynStEn() == A_XdIndex &&
                IS_NULLFLD(inputData, A_XdIndex_Id) == false)
            {
                auto& xdIdxAttribVector = this->m_xdIndexAttribByIndexMap[GET_ID(inputData, A_XdIndex_Id)];

                for (auto &xdIdxAttribIt : xdIdxAttribVector)
                {
                    outputRecords.push_back(xdIdxAttribIt);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
            break;
        }

        case XdAttribCommentCst:
        {
            if (role == UNUSED &&
                inputData->getDynStEn() == Adm_Arg &&
                IS_NULLFLD(inputData, Adm_Arg_Id) == false)
            {
                auto& xdXdAttribCommentVector = this->m_xdAttribCommentByEntityMap[GET_ID(inputData, Adm_Arg_Id)];

                for (auto &xdAttribCommentIt : xdXdAttribCommentVector)
                {
                    outputRecords.push_back(xdAttribCommentIt);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
            break;
        }

        case QuestDefCst:
        {
            if (role == UNUSED && inputData == nullptr)
            {
                auto& questDefMap = this->m_mapIdByObjEnMap[objectEn];

                for (auto &questDefIt : questDefMap)
                {
                    outputRecords.push_back(questDefIt.second);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
            break;
        }

        case ScriptDefCst:
        case HoldingConstraintScriptCst:
        case TradingConstraintScriptCst:
            this->selScriptDef(objectEn,
                               role,
                               inputData,
                               outputRecords);
            break;

        default:
        {
            auto dictEntityStp = DBA_GetDictEntitySt(objectEn);
            if (dictEntityStp != nullptr)
            {
                if (inputData == nullptr ||
                    (dictEntityStp->parentAttrStp != nullptr &&
                     dictEntityStp->parentAttrStp->refDictEntityStp != nullptr &&
                     dictEntityStp->parentAttrStp->refDictEntityStp->isId() &&
                     (dictEntityStp->parentAttrStp->refDictEntityStp->objectEn == inputData->getObjectEn() ||
                      inputData->getDynStEn() == Adm_Arg)))
                {
                    auto        &subRecordMap = this->m_mapIdByObjEnMap[objectEn];
                    FIELD_IDX_T idIdx         = (inputData->getDynStEn() == Adm_Arg ? Adm_Arg_Id : inputData->getIdIdx());

                    for (auto &subRecordlIt : subRecordMap)
                    {
                        if (inputData == nullptr ||
                            CMP_DYNFLD(subRecordlIt.second, inputData, dictEntityStp->parentAttrStp->progN, idIdx, IdType) == 0)
                        {
                            outputRecords.push_back(subRecordlIt.second);
                        }
                    }
                }
                else
                {
                    SYS_BreakOnDebug();
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }
    }

    switch (GET_OBJECT_CST(objectEn))
    {
        case FmtEltCst:
            if (outputRecords.size() > 1)
            {
                std::sort(outputRecords.begin(), outputRecords.end(),
                          [](const DBA_DYNFLD_STP& a, const DBA_DYNFLD_STP& b) -> bool
                          {
                              int iCmp = CMP_DYNFLD(a, b, A_FmtElt_Rank, A_FmtElt_Rank, SmallintType);
                              if (iCmp < 0)
                              {
                                  return true;
                              }
                              else if (iCmp > 0)
                              {
                                  return false;
                              }

                              iCmp = CMP_DYNFLD(a, b, A_FmtElt_LangDictId, A_FmtElt_LangDictId, DictType);
                              if (iCmp < 0)
                              {
                                  return true;
                              }
                              else if (iCmp > 0)
                              {
                                  return false;
                              }

                              iCmp = CMP_DYNFLD(a, b, A_FmtElt_SqlName, A_FmtElt_SqlName, SysnameType);
                              if (iCmp < 0)
                              {
                                  return true;
                              }

                              return false;
                          });
            }
            break;
    }

}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selRecords
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231106
**
*************************************************************************/
void DdlGenDbaAccess::selRecords(OBJECT_ENUM objectEn, int role, DBA_DYNFLD_STP inputData, DBA_DYNFLD_STP *&recordTab, int &row, MemoryPool &mp)
{
    std::vector<DBA_DYNFLD_STP> outputRecords;

    this->selRecords(objectEn, role, inputData, outputRecords);

    if (outputRecords.empty() == false)
    {
        if (recordTab == nullptr)
        {
            recordTab = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, outputRecords.size(), sizeof(DBA_DYNFLD_STP)));
        }
        else
        {
            recordTab = static_cast<DBA_DYNFLD_STP *>(mp.realloc(recordTab, (outputRecords.size() + row) * sizeof(DBA_DYNFLD_STP)));
        }
        
        for (auto &it : outputRecords)
        {
            recordTab[row++] = it;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selRecordsByParent
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231127
**
*************************************************************************/
void DdlGenDbaAccess::selRecordsByParent(OBJECT_ENUM                  objectEn, 
                                         ID_T                         parentId, 
                                         bool                         bGetFromDb,
                                         std::vector<DBA_DYNFLD_STP> &outputRecords,
                                         OBJECT_ENUM                  subObjectEn)
{
    if (bGetFromDb)
    {
        auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp != nullptr &&
            (dictEntityStp->parentAttrStp != nullptr || subObjectEn != NullEntity) &&
            parentId > 0 &&
            this->isLoaded(objectEn) == false)
        {
            auto &mapisLoadedByParentMap = this->m_isLoadedByParentMap[objectEn][subObjectEn];
            if (mapisLoadedByParentMap.find(parentId) == mapisLoadedByParentMap.end())
            {
                DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
                DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

                this->loadByParent(dictEntityStp, parentId, subObjectEn, dbiConnHelper);
            }
        }
    }

    auto &mapIdByParentMap = this->m_mapIdByParentMap[objectEn][subObjectEn][parentId];
    if (mapIdByParentMap.empty() == false)
    {
        outputRecords.reserve(mapIdByParentMap.size());
        for (auto &it : mapIdByParentMap)
        {
            for (auto &recIt : it.second)
            {
                if (recIt->getIdIdx() < 0 || it.first == GET_ID(recIt, recIt->getIdIdx()))
                {
                    outputRecords.push_back(recIt);
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selScriptDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::selScriptDefByAttribNat(DICT_T                       attrDictId,
                                              SCRIPTDEFNAT_ENUM            natEn,
                                              DBA_DYNFLD_STP               inputData,
                                              std::vector<DBA_DYNFLD_STP> &outputRecords)
{
    DBA_SCRIPT_DYN_ST   scpt_DynStCfg;
    DBA_SetScriptDynStConfig(inputData->getObjectEn(), &scpt_DynStCfg);

    bool bFound = false;
    auto scptDefAttMapIt = this->m_scriptDefMap.find(attrDictId);
    if (scptDefAttMapIt != this->m_scriptDefMap.end())
    {
        auto scptDefNatMapIt = scptDefAttMapIt->second.find(natEn);

        if (scptDefNatMapIt != scptDefAttMapIt->second.end())
        {
            for (auto &it : scptDefNatMapIt->second)
            {
                if (IS_NOTNULL(it.second, A_ScriptDef_Rank) &&
                    ((inputData->getDynStEn() == Get_Arg && IS_NULLFLD(it.second, scpt_DynStCfg.A_ScriptSt_ObjId)) ||
                     (inputData->getDynStEn() == A_ScriptDef &&
                      CMP_DYNFLD(inputData, it.second, scpt_DynStCfg.A_ScriptSt_ObjId, scpt_DynStCfg.A_ScriptSt_ObjId, IdType) == 0 &&
                      CMP_DYNFLD(inputData, it.second, scpt_DynStCfg.A_ScriptSt_ActionEn, scpt_DynStCfg.A_ScriptSt_ActionEn, EnumType) == 0) ||
                     (inputData->getDynStEn() == S_ScriptDef &&
                      CMP_DYNFLD(inputData, it.second, scpt_DynStCfg.S_ScriptSt_ObjId, scpt_DynStCfg.A_ScriptSt_ObjId, IdType) == 0 &&
                      CMP_DYNFLD(inputData, it.second, scpt_DynStCfg.S_ScriptSt_ActionEn, scpt_DynStCfg.A_ScriptSt_ActionEn, EnumType) == 0)))
                {
                    outputRecords.push_back(it.second);
                    bFound = true;
                }
            }
        }
    }

    return bFound;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::selScriptDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::selScriptDef(OBJECT_ENUM                  objectEn, 
                                   int                          role, 
                                   DBA_DYNFLD_STP               inputData, 
                                   std::vector<DBA_DYNFLD_STP> &outputRecords)
{

    if (inputData->getDynStEn() == Get_Arg)
    {
        auto dictEntityStp = DBA_GetDictEntityByDictId(GET_DICT(inputData, Get_Arg_EntDictId));

        if (dictEntityStp != nullptr)
        {
            std::vector<SCRIPTDEFNAT_ENUM> searchNatVector;

            if (role == DBA_ROLE_SCPT_DEF_VAL_INIT)
            {
                searchNatVector.push_back(ScriptDef_SysBatchDefVal);
                searchNatVector.push_back(ScriptDef_SysGuiDefVal);
            }
            else if (role == DBA_ROLE_SCPT_CTRL_INIT)
            {
                searchNatVector.push_back(ScriptDef_SysBatchCtrlVal);
            }
            else if (role == DBA_ROLE_SCPT_DEF_VAL)
            {
                searchNatVector.push_back(ScriptDef_SysBatchDefVal);
                searchNatVector.push_back(ScriptDef_UserBatchDefVal);
                searchNatVector.push_back(ScriptDef_SysGuiDefVal);
                searchNatVector.push_back(ScriptDef_UserGuiDefVal);
            }
            else if (role == DBA_ROLE_SCPT_DEF_CONTROL)
            {
                searchNatVector.push_back(ScriptDef_SysBatchCtrlVal);
                searchNatVector.push_back(ScriptDef_UserBatchCtrlVal);
                searchNatVector.push_back(ScriptDef_SysGuiCtrlVal);
                searchNatVector.push_back(ScriptDef_UserGuiCtrlVal);
            }


            for (auto &attribIt : dictEntityStp->attribMap)
            {
                for (auto &natIt : searchNatVector)
                {
                    if (selScriptDefByAttribNat(attribIt.second->attrDictId, natIt, inputData, outputRecords))
                    {
                        break;
                    }
                }
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    else if (inputData->getDynStEn() == A_ScriptDef ||
             inputData->getDynStEn() == A_HoldingConstraintScript ||
             inputData->getDynStEn() == A_TradingConstraintScript)
    {
        if (role == UNUSED &&
            IS_NOTNULL(inputData, A_ScriptDef_AttrDictId) &&
            IS_NOTNULL(inputData, A_ScriptDef_NatEn))
        {
            if (selScriptDefByAttribNat(GET_DICT(inputData, A_ScriptDef_AttrDictId),
                                        static_cast<SCRIPTDEFNAT_ENUM>(GET_ENUM(inputData, A_ScriptDef_NatEn)),
                                        inputData,
                                        outputRecords))
            {

                std::sort(outputRecords.begin(), outputRecords.end(),
                          [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                          {
                              return GET_SMALLINT(a, A_ScriptDef_Rank) < GET_SMALLINT(b, A_ScriptDef_Rank);
                          });
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    else if (inputData->getDynStEn() == S_ScriptDef ||
             inputData->getDynStEn() == S_HoldingConstraintScript ||
             inputData->getDynStEn() == S_TradingConstraintScript)
    {
        if (role == UNUSED &&
            IS_NOTNULL(inputData, S_ScriptDef_AttrDictId) &&
            IS_NOTNULL(inputData, S_ScriptDef_NatEn))
        {
            if (selScriptDefByAttribNat(GET_DICT(inputData, S_ScriptDef_AttrDictId),
                                        static_cast<SCRIPTDEFNAT_ENUM>(GET_ENUM(inputData, S_ScriptDef_NatEn)),
                                        inputData,
                                        outputRecords))
            {
                std::sort(outputRecords.begin(), outputRecords.end(),
                          [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                          {
                              return GET_SMALLINT(a, A_ScriptDef_Rank) < GET_SMALLINT(b, A_ScriptDef_Rank);
                          });
            }
        }
        else
        {
            SYS_BreakOnDebug();
        }
    }
    else
    {
        SYS_BreakOnDebug();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::cleanUpScriptDef
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::cleanUpScriptDef()
{

    for (auto dictEntityIt = AaaMetaDict::getDictEntityVector().begin(); dictEntityIt != AaaMetaDict::getDictEntityVector().end(); ++dictEntityIt)
    {
        if ((*dictEntityIt)->loadDictRuleEn != LoadDictRule_BootStrap)
        {
            continue;
        }

        for (auto attribIt = (*dictEntityIt)->attribMap.begin(); attribIt != (*dictEntityIt)->attribMap.end(); ++attribIt)
        {
            if (attribIt->second->custFlg == TRUE)
            {
                continue;
            }

            auto scptDefAttMapIt = this->m_scriptDefMap.find(attribIt->second->attrDictId);
            if (scptDefAttMapIt != this->m_scriptDefMap.end())
            {
                for (auto scptDefAttNatIt = scptDefAttMapIt->second.begin(); scptDefAttNatIt != scptDefAttMapIt->second.end(); ++scptDefAttNatIt)
                {
                    if (scptDefAttNatIt->first == ScriptDef_SysGuiDefVal ||
                        scptDefAttNatIt->first == ScriptDef_UserGuiDefVal ||
                        scptDefAttNatIt->first == ScriptDef_SysBatchDefVal ||
                        scptDefAttNatIt->first == ScriptDef_UserBatchDefVal ||
                        scptDefAttNatIt->first == ScriptDef_SysGuiCtrlVal ||
                        scptDefAttNatIt->first == ScriptDef_UserGuiCtrlVal ||
                        scptDefAttNatIt->first == ScriptDef_SysBatchCtrlVal ||
                        scptDefAttNatIt->first == ScriptDef_UserBatchCtrlVal ||
                        scptDefAttNatIt->first == ScriptDef_SysGuiFilter)
                    {
                        for (auto scptDefIt = scptDefAttNatIt->second.begin(); scptDefIt != scptDefAttNatIt->second.end(); ++scptDefIt)
                        {
                            this->insUpdDelRecord(Delete, ScriptDef, UNUSED, scptDefIt->second, false);
                        }
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::addAutoRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240925
**
*************************************************************************/
void DdlGenDbaAccess::addAutoRecord(DBA_DYNFLD_STP recordStp, DBA_DYNFLD_STP subRecordStp)
{
    m_autoRecordMap[recordStp].insert(subRecordStp);

    auto& reqAllAction = this->m_recordActionVector[subRecordStp];
    if (reqAllAction.empty() == false ||
        reqAllAction[0].m_action == Insert)
    {
        reqAllAction[0].m_action = Update;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getDatabaseStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getDatabaseStp(DICT_T segmentDictId)
{
    DBA_DYNFLD_STP dictSegmentStp = this->getRecordById(DictSegment, segmentDictId, true);
    if (dictSegmentStp != nullptr)
    {
        DBA_DYNFLD_STP dictDatabaseStp = this->getRecordById(DictDatabase, GET_DICT(dictSegmentStp, A_DictSegment_DbDictId), true);
        if (dictDatabaseStp != nullptr)
        {
            return dictDatabaseStp;
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::updRecordStatus
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
void DdlGenDbaAccess::updRecordStatus(DBA_DYNFLD_STP recordStp)
{
    LockGuard       lockGuard(this->m_lock);

    auto searchIt = this->m_allRecordsMap.find(recordStp);
    if (searchIt != this->m_allRecordsMap.end())
    {
        if (searchIt->second != XdAction_ToInsert)
        {
            searchIt->second = XdAction_ToRefresh;
        }
    }
    else
    {
        SYS_BreakOnDebug();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isStatusOnIns
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isStatusOnIns(DBA_DYNFLD_STP recordStp)
{
    if (recordStp->getDynStEn() == A_XdEntity ||
        recordStp->getDynStEn() == A_XdIndex ||
        recordStp->getDynStEn() == A_XdAttrib ||
        recordStp->getDynStEn() == A_XdEntityFeature)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::manageCustoData
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-54413 - LJE - 230901
**
*************************************************************************/
bool DdlGenDbaAccess::manageCustoData(DBA_DYNFLD_STP recordStp, int role)
{
    if (role == DBA_ROLE_IMPORT_USR_MD &&
        recordStp->getDynStEn() == A_XdAttrib &&
        GET_ENUM(recordStp, A_XdAttrib_CustomFlg) == Custom_No)
    {
        MemoryPool mp;
        ID_T tmpRecId = 0;
        auto stdXdAttribStp = this->getRecordById(XdAttrib, GET_ID(recordStp, A_XdAttrib_Id), true);
        auto xdEntityStp = this->getRecordById(XdEntity, GET_ID(recordStp, A_XdAttrib_XdEntityId), true);

        if (stdXdAttribStp != nullptr &&
            (xdEntityStp == nullptr || (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Custom &&
                                        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_CustomDS &&
                                        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ModelBank)))
        {
            auto xdAttribCustoTplStp = mp.allocDynst(FILEINFO, A_XdAttributeCusto);
            SET_ID(xdAttribCustoTplStp, A_XdAttributeCusto_XdAttribId, GET_ID(recordStp, A_XdAttrib_Id));
            SET_ID(xdAttribCustoTplStp, A_XdAttributeCusto_XdEntityId, GET_ID(recordStp, A_XdAttrib_XdEntityId));

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_DispRank, A_XdAttrib_DispRank, SmallintType) != 0 ||
                CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_SubTpMask, A_XdAttrib_SubTpMask, MaskType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::Display);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_DispRank, recordStp, A_XdAttrib, A_XdAttrib_DispRank);
                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_SubTpMask, recordStp, A_XdAttrib, A_XdAttrib_SubTpMask);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_EditEn, A_XdAttrib_EditEn, EnumType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::Edition);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_EditEn, recordStp, A_XdAttrib, A_XdAttrib_EditEn);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_QuickSearchMask, A_XdAttrib_QuickSearchMask, MaskType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::Search);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_QuickSearchMask, recordStp, A_XdAttrib, A_XdAttrib_QuickSearchMask);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_MaxDbLen, A_XdAttrib_MaxDbLen, SmallintType) != 0 ||
                CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_DefaultDispLen, A_XdAttrib_DefaultDispLen, SmallintType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::StringLength);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_MaxDbLen, recordStp, A_XdAttrib, A_XdAttrib_MaxDbLen);
                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_DefaultDispLen, recordStp, A_XdAttrib, A_XdAttrib_DefaultDispLen);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_ExportEn, A_XdAttrib_ExportEn, EnumType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::Export);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_ExportEn, recordStp, A_XdAttrib, A_XdAttrib_ExportEn);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_MeSpecialisationEn, A_XdAttrib_MeSpecialisationEn, EnumType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::MultiEntity);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_MeSpecialisationEn, recordStp, A_XdAttrib, A_XdAttrib_MeSpecialisationEn);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_ObjModifStatEn, A_XdAttrib_ObjModifStatEn, EnumType) != 0)
            {
                auto xdAttribCustoStp = mp.duplicate(FILEINFO, xdAttribCustoTplStp);
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::ObjectModifStat);

                COPY_DYNFLD(xdAttribCustoStp, A_XdAttributeCusto, A_XdAttributeCusto_ObjModifStatEn, recordStp, A_XdAttrib, A_XdAttrib_ObjModifStatEn);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_VerticalSearchFlg, A_XdAttrib_VerticalSearchFlg, FlagType) != 0)
            {
                auto xdAttribCustoStp = mp.allocDynst(FILEINFO, A_XdAttributeCusto);
                SET_ID(xdAttribCustoStp, A_XdAttributeCusto_XdAttribId, GET_ID(recordStp, A_XdAttrib_Id));
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::TSLSearch);

                SET_A_XdAttributeCusto_TslSearchEn(xdAttribCustoStp, XdAttributeCustoTslSearchEn::VerticalSearch);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }
            else if (CMP_DYNFLD(stdXdAttribStp, recordStp, A_XdAttrib_VerticalPatternFlg, A_XdAttrib_VerticalPatternFlg, FlagType) != 0)
            {
                auto xdAttribCustoStp = mp.allocDynst(FILEINFO, A_XdAttributeCusto);
                SET_ID(xdAttribCustoStp, A_XdAttributeCusto_XdAttribId, GET_ID(recordStp, A_XdAttrib_Id));
                SET_A_XdAttributeCusto_NatEn(xdAttribCustoStp, XdAttributeCustoNatEn::TSLSearch);

                SET_A_XdAttributeCusto_TslSearchEn(xdAttribCustoStp, XdAttributeCustoTslSearchEn::VerticalPattern);

                this->insUpdRecord(xdAttribCustoStp, tmpRecId, UNUSED, true);
            }

            return true;
        }
    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isModifiedObject
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isModifiedObject(OBJECT_ENUM objectEn)
{
    return this->m_modifiedSet.find(objectEn) != this->m_modifiedSet.end();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isDbRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isDbRecord(DBA_DYNFLD_STP recordStp)
{
    return (this->m_allDbRecordsMap.find(recordStp) != this->m_allDbRecordsMap.end());
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::setPackageCompositionStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240425
**
*************************************************************************/
void DdlGenDbaAccess::setPackageCompositionStp(DBA_DYNFLD_STP packageCompositionStp)
{
    this->m_packageCompositionStp = packageCompositionStp;
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::setPackageCompositionLink
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240425
**
*************************************************************************/
void DdlGenDbaAccess::setPackageCompositionLink(DBA_DYNFLD_STP recordStp)
{
    if (this->m_packageCompositionStp != nullptr)
    {
        this->m_packageCompositionMap.insert(std::make_pair(recordStp, this->m_packageCompositionStp));
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getPackageCompositionStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenDbaAccess::getPackageCompositionStp(DBA_DYNFLD_STP recordStp)
{
    auto pckCompoLnkIt = this->m_packageCompositionMap.find(recordStp);

    if (pckCompoLnkIt != this->m_packageCompositionMap.end())
    {
        return pckCompoLnkIt->second;
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isModified
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isModified(DBA_DYNFLD_STP recordStp, bool &bExists, std::vector<DdlGenDbaAccess::Action> &actionVector)
{
    bool bModified = true;
    auto dbRecordIt = this->m_allDbRecordsMap.find(recordStp);
    if (dbRecordIt != this->m_allDbRecordsMap.end())
    {
        DICT_ENTITY_STP dictEntityStp = recordStp->getDictEntityStp();

        bExists   = true;
        bModified = false;
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp->isInAll() &&
                dictAttribStp->isPhysicalAttribute() &&
                dictAttribStp->calcEn != DictAttr_LastModifManagment &&
                dictAttribStp->calcEn != DictAttr_CreationManagment &&
                dictAttribStp->precompFlg == FALSE)
            {
                if (CMP_DYNFLD(dbRecordIt->first, dbRecordIt->second, dictAttribStp->progN, dictAttribStp->progN, dictAttribStp->dataTpProgN) != 0)
                {
                    if (recordStp->getDynStEn() == A_XdAttrib)
                    {
                        if (dictAttribStp->progN != A_XdAttrib_BuildDate &&
                            dictAttribStp->progN != A_XdAttrib_DbProg &&
                            dictAttribStp->progN != A_XdAttrib_OldProg &&
                            dictAttribStp->progN != A_XdAttrib_OldShortIdx &&
                            dictAttribStp->progN != A_XdAttrib_OldDispRank)
                        {
                            bModified = true;
                            break;
                        }
                    }
                    else
                    {
                        if ((dictEntityStp->entNatEn == EntityNat_System && strcmp(dictAttribStp->sqlName, "build_d") != 0) ||
                            dictEntityStp->entNatEn != EntityNat_System)
                        {
                            if (dictAttribStp->exportEn == Export_NotExported ||
                                dictAttribStp->calcEn == DictAttr_PhysSpecUpd)
                            {
                                for (auto& actionIt : actionVector)
                                {
                                    if (actionIt.m_action == Update &&
                                        actionIt.m_role != UNUSED)
                                    {
                                        auto procedureStp = DBA_GetStoredProcs(actionIt.m_action,
                                                                               actionIt.m_object,
                                                                               actionIt.m_role,
                                                                               GET_DYNSTENUM(recordStp),
                                                                               recordStp,
                                                                               NullDynSt,
                                                                               true);

                                        if (procedureStp != nullptr && 
                                            procedureStp->procParamDefPtr != nullptr)
                                        {
                                            for (int i = 0; procedureStp->procParamDefPtr[i].fldNbrPtr != UNUSED; ++i)
                                            {
                                                if ((*procedureStp->procParamDefPtr[i].fldNbrPtr) == dictAttribStp->progN)
                                                {
                                                    bModified = true;
                                                    break;
                                                }
                                            }
                                        }

                                        if (bModified)
                                        {
                                            break;
                                        }
                                    }
                                }

                                if (bModified)
                                {
                                    break;
                                }
                            }
                            else
                            {
                                bModified = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        bExists = false;
    }
    return bModified;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::isSimulation
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenDbaAccess::isSimulation()
{
    return this->m_ddlGenContext.bSimulation;
}


/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getIdByObjEnMap
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::map<ID_T, DBA_DYNFLD_STP> &DdlGenDbaAccess::getIdByObjEnMap(OBJECT_ENUM objectEn)
{
    auto idByObjEnMap = this->m_mapIdByObjEnMap.find(objectEn);
    if (idByObjEnMap == this->m_mapIdByObjEnMap.end())
    {
        if (this->m_isMetaDictLoaded)
        {
            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

            if (dbiConnHelper.isValidAndInit())
            {
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);
                if (dictEntityStp != nullptr)
                {
                    this->load(dictEntityStp->mdSqlName, dbiConnHelper);
                }
            }
        }
        return this->m_mapIdByObjEnMap[objectEn];
    }

    return idByObjEnMap->second;
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccess::getCodeByObjEnMap
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
std::map<std::string, DBA_DYNFLD_STP> &DdlGenDbaAccess::getCodeByObjEnMap(OBJECT_ENUM objectEn)
{
    auto sqlByObjEnMap = this->m_mapCodeByObjEnMap.find(objectEn);
    if (sqlByObjEnMap == this->m_mapCodeByObjEnMap.end())
    {
        if (this->m_isMetaDictLoaded)
        {
            DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

            if (dbiConnHelper.isValidAndInit())
            {
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);
                if (dictEntityStp != nullptr)
                {
                    this->load(dictEntityStp->mdSqlName, dbiConnHelper);
                }
            }
        }
        return this->m_mapCodeByObjEnMap[objectEn];
    }

    return sqlByObjEnMap->second;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::DdlGenEntity()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DdlGenEntity::DdlGenEntity(std::string sqlName, DdlGenContext &ddlGenContext)
    : bMultiEntityOnPrecomp(false)
    , bMultiEntityOnCustom(false)
    , m_xdEntityStp(nullptr)
    , m_sqlName(sqlName)
    , m_targetSqlName(sqlName)
    , m_ddlGenContext(ddlGenContext)
    , m_ddlGenDbi(DdlObj_None, m_ddlGenContext, nullptr, nullptr, TargetTable_Undefined)
{
    this->sysXdEntityStp       = NULL;
    this->sysXdPartitionTab    = NULL;
    this->sysXdPartitionNbr    = 0;
    this->bIsLoaded            = false;
    this->bIsIdxLoaded         = false;
    this->bIsExtLoaded         = false;
    this->xdPartitionTab       = NULL;
    this->xdPartitionNbr       = 0;
    this->xdPartitionIndexTab  = NULL;
    this->xdPartitionIndexNbr  = 0;
    this->shXdEntityStp        = this->m_mp.allocDynst(FILEINFO, S_XdEntity);
    this->shDictEntityStp      = this->m_mp.allocDynst(FILEINFO, S_DictEntity);
    this->aDictEntityStp       = nullptr;
    this->m_dictEntityStp      = nullptr;
    this->m_refDictEntityTab   = nullptr;
    this->m_attDictId          = 0;
    this->m_UDFAttDictId       = 0;
    this->m_extAttDictId       = 0;
    this->m_maxAttDictId       = 0;
    this->m_maxUDFAttDictId    = 0;
    this->m_maxExtAttDictId    = 0;
    
    this->m_ddlGenContext.m_ddlGenContextForConn = &ddlGenContext;
    this->m_ddlGenContext.ddlGenAction.m_entitySqlnameStr = this->m_sqlName;
    SET_SYSNAME(this->shXdEntityStp, S_XdEntity_SqlName, this->m_sqlName.c_str());

    this->m_invalidDictEntitySt.objectEn = InvalidEntity;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::~DdlGenEntity()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DdlGenEntity::~DdlGenEntity()
{
    FREE_DYNST(this->sysXdEntityStp, A_XdEntity);

    /* PMSTA-24007 - LJE - 170721 */
    DBA_FreeDynStTab(this->sysXdPartitionTab, this->sysXdPartitionNbr, A_XdPartition);
    this->sysXdPartitionTab = NULL;
    this->sysXdPartitionNbr = 0;

    this->clearXdEntityFeatures();

    this->m_xdAttrPermValMap.clear();
    this->m_xdPermValMap.clear();

    /* PMSTA-24007 - LJE - 170714 */
    this->clearXdPartition();
    this->clearXdPartitionIndex();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::setXdEntityFromDict()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
RET_CODE DdlGenEntity::setXdEntityFromDict(DICT_ENTITY_STP srcDictEntityStp)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_xdEntityStp == nullptr &&
        (this->m_xdEntityStp = this->m_mp.allocDynst(FILEINFO, A_XdEntity)) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (this->aDictEntityStp == nullptr)
    {
        this->aDictEntityStp = this->m_mp.allocDynst(FILEINFO, A_DictEntity);
    }

    DBA_SetDfltEntityFld(DictEntity, A_DictEntity, this->aDictEntityStp);

    this->m_dictEntityStp = srcDictEntityStp;

    SET_DICT(this->shDictEntityStp, S_DictEntity_DictId, this->m_dictEntityStp->entDictId);
    DBA_GetAllDictEntityById(this->m_dictEntityStp->objectEn,
                             this->shDictEntityStp,
                             &(this->aDictEntityStp),
                             NULL,
                             UNUSED,
                             NULL);

    if (this->m_targetSqlName.empty())
    {
        CONVERT_DYNST(this->m_xdEntityStp, A_XdEntity, this->aDictEntityStp, A_DictEntity);
    }
    else
    {
        auto tmplDdlGenEntityPtr = this->m_ddlGenContext.getDdlGenEntityPtr(srcDictEntityStp->mdSqlName, std::string(), false);
        DBA_DYNFLD_STP tmplXdEntityStp = nullptr;
        if (tmplDdlGenEntityPtr != nullptr &&
            tmplDdlGenEntityPtr != this &&
            (tmplXdEntityStp = tmplDdlGenEntityPtr->getXdEntityStp()) != nullptr &&
            IS_NULLFLD(tmplXdEntityStp, A_XdEntity_Id) == false)
        {
            COPY_DYNST(this->m_xdEntityStp, tmplXdEntityStp, A_XdEntity);
        }
        else
        {
            CONVERT_DYNST(this->m_xdEntityStp, A_XdEntity, this->aDictEntityStp, A_DictEntity);
            SET_ID(this->m_xdEntityStp, A_XdEntity_Id, srcDictEntityStp->xdEntityId);
        }
    }

    this->bIsLoaded = true;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::check()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
bool DdlGenEntity::check()
{
    if (this->getXdEntityStp() == nullptr)
    {
        return false;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::insUpdXdIndex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-37366 - LJE - 200330
**
*************************************************************************/
RET_CODE DdlGenEntity::insUpdXdIndex(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP &xdIndexStp, DBA_DYNFLD_STP xdEntityStp)
{
    RET_CODE ret                 = RET_SUCCEED;
    DBA_ACTION_ENUM actionDone   = NullAction;

    if (this->m_ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildVirtualFromFmt)
    {
        if (GET_A_XdIndex_XdActionEn(xdIndexStp) == XdEntityXdActionEn::ToDelete)
        {
            if (IS_NULLFLD(xdIndexStp, A_XdIndex_Id) ||
                GET_ID(xdIndexStp, A_XdIndex_Id) < 0)
            {
                actionDone = Delete;
                requestHelper.dbaCall(actionDone,
                                      XdIndex,
                                      UNUSED,
                                      xdIndexStp);

                for (auto it = this->m_xdIndexVector.begin(); it != this->m_xdIndexVector.end(); ++it)
                {
                    if (*it == xdIndexStp)
                    {
                        this->m_xdIndexVector.erase(it);
                        break;
                    }
                }

                auto& xdIndexAttribVector = this->getXdIndexAttribVector(xdIndexStp);
                for (auto &xdIndexAttribStp : xdIndexAttribVector)
                {
                    actionDone = Delete;
                    requestHelper.dbaCall(actionDone,
                                          XdIndex,
                                          UNUSED,
                                          xdIndexAttribStp);
                }
                xdIndexAttribVector.clear();
            }
            else
            {
                if ((ret = requestHelper.insUpdRecord(xdIndexStp, actionDone, xdEntityStp)) != RET_SUCCEED)
                {
                    this->m_ddlGenContext.printMsg(ret, "Unable to update xd_index");
                    return ret;
                }

                if (GET_A_XdIndex_XdStatusEn(xdIndexStp) == XdEntityXdStatusEn::Untreated ||
                    GET_A_XdIndex_XdStatusEn(xdIndexStp) == XdEntityXdStatusEn::Deleted ||
                    GET_A_XdIndex_XdStatusEn(xdIndexStp) == XdEntityXdStatusEn::PhysicallyDeleted)
                {
                    SET_A_XdIndex_XdActionEn(xdIndexStp, XdEntityXdActionEn::None);
                }
            }
        }
        else if ((ret = requestHelper.insUpdRecord(xdIndexStp, actionDone, xdEntityStp)) != RET_SUCCEED)
        {
            this->m_ddlGenContext.printMsg(ret, "Unable to create xd_index");
            return ret;
        }
    }
    else
    {
        actionDone = Insert;
        SET_ID(xdIndexStp, A_XdIndex_Id, -1 * (this->getXdIndexVector().size() + 1));
    }

    if (actionDone == Insert)
    {
        this->addXdIndex(xdIndexStp);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::insXdIndexAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14452 - LJE - 130205
**
*************************************************************************/
RET_CODE DdlGenEntity::insXdIndexAttrib(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP currXdAttribStp, DBA_DYNFLD_STP xdIndexStp, DBA_DYNFLD_STP xdIndexAttribStp)
{
    RET_CODE    ret = RET_SUCCEED;
    bool        bToCreate = true;
    std::string colExpr;

    auto &xdIndexAttribVector = this->getXdIndexAttribVector(xdIndexStp);

    /* Check if the index attribute doesn't exists */
    for (auto it = xdIndexAttribVector.begin(); it != xdIndexAttribVector.end() && bToCreate == true; ++it)
    {
        DBA_DYNFLD_STP currXdIndexAttribStp = (*it);

        if (CMP_DYNFLD(currXdIndexAttribStp, xdIndexStp, A_XdIndexAttrib_XdIdxId, A_XdIndex_Id, IdType) == 0 &&
            ((currXdAttribStp != nullptr && CMP_DYNFLD(currXdIndexAttribStp, currXdAttribStp, A_XdIndexAttrib_XdAttribId, A_XdAttrib_Id, IdType) == 0) ||
            (currXdAttribStp == nullptr && CMP_DYNFLD(currXdIndexAttribStp, xdIndexAttribStp, A_XdIndexAttrib_XdAttribId, A_XdIndexAttrib_XdAttribId, IdType) == 0)))
        {
            /* Keep some new values */
            this->m_ddlGenContext.copyDynFld(currXdIndexAttribStp, A_XdIndexAttrib_Rank,
                                             xdIndexAttribStp, A_XdIndexAttrib_Rank);
            this->m_ddlGenContext.copyDynFld(currXdIndexAttribStp, A_XdIndexAttrib_SortRuleEn,
                                             xdIndexAttribStp, A_XdIndexAttrib_SortRuleEn);

            if (IS_NULLFLD(xdIndexAttribStp, A_XdIndexAttrib_Id) == FALSE)
            {
                this->m_ddlGenContext.copyDynFld(currXdIndexAttribStp, A_XdIndexAttrib_ColumnExpression,
                                                 xdIndexAttribStp, A_XdIndexAttrib_ColumnExpression);
            }

            xdIndexAttribStp = currXdIndexAttribStp;
            bToCreate = false;
        }
    }

    if (currXdAttribStp != nullptr)
    {
        this->m_ddlGenContext.copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId,
                                         currXdAttribStp, A_XdAttrib_Id);
        this->m_ddlGenContext.copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdAttribSqlName,
                                         currXdAttribStp, A_XdAttrib_SqlName);
    }

    if (bToCreate)
    {
        DBA_ACTION_ENUM actionDone = NullAction;

        SET_NULL_ID(xdIndexAttribStp, A_XdIndexAttrib_Id);

        this->m_ddlGenContext.copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdIdxId,
                                         xdIndexStp, A_XdIndex_Id);

        if (this->m_ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildVirtualFromFmt &&
            (ret = requestHelper.insUpdRecord(xdIndexAttribStp, actionDone, xdIndexStp)) != RET_SUCCEED)
        {
            std::string msg;
            msg = "Error when building xd_index_attribute for index " + std::string(GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName));
            MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, msg.c_str());

            return ret;
        }

        xdIndexAttribVector.push_back(xdIndexAttribStp);

        if (this->m_ddlGenContext.ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt)
        {
            this->m_dictEntityStp->xdIndexAttribMap[this->m_dictEntityStp->xdIndexMap[GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName)]].
                push_back(this->m_dictEntityStp->m_mp.duplicate(FILEINFO, xdIndexAttribStp));
        }
    }
    else
    {
        DBA_ACTION_ENUM actionDone = NullAction;

        if (this->m_ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildVirtualFromFmt &&
            (ret = requestHelper.insUpdRecord(xdIndexAttribStp, actionDone, xdIndexStp)) != RET_SUCCEED)
        {
            std::string msg;
            msg = "Error when building xd_index_attribute for index " + std::string(GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName));
            MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, msg.c_str());

            return ret;
        }
    }

    SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdEntityStp()
{
    if (this->m_xdEntityStp == nullptr ||
        IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_Id) == TRUE)
    {
        if (this->loadExdEntityInfo(false) != RET_SUCCEED)
        {
            return nullptr;
        }
    }
    return this->m_xdEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getSysXdEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130205
**
*************************************************************************/
DBA_DYNFLD_STP    DdlGenEntity::getSysXdEntityStp(std::string &realSqlName)
{
    if (this->loadExdEntityFromSysInfo(realSqlName) != RET_SUCCEED)
    {
        return nullptr;
    }

    return this->sysXdEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getADictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111124
**
*************************************************************************/
DBA_DYNFLD_STP &DdlGenEntity::getADictEntityStp()
{
    return this->aDictEntityStp;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::addXdAttribInTab()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
void DdlGenEntity::addXdAttribInTab(DBA_DYNFLD_STP newXdAttrib)
{
    this->m_xdAttribVector.push_back(newXdAttrib);
    this->sortAttributes();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::sortAttributes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
void DdlGenEntity::sortAttributes()
{
    std::sort(this->m_xdAttribVector.begin(), this->m_xdAttribVector.end(), DDL_CmpXdAttrib);
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdAttrib(int xdAttribPos)
{
    return this->m_xdAttribVector[xdAttribPos];
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttribNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
int DdlGenEntity::getXdAttribNbr()
{
    return static_cast<int>(this->m_xdAttribVector.size());
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttribNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
DBA_DYNFLD_STP *DdlGenEntity::getSortedXdAttribTab(TLS_CMPFCT *icmp)
{
    DBA_DYNFLD_STP *sortedXdAttribTab = static_cast<DBA_DYNFLD_STP *>(CALLOC(this->m_xdAttribVector.size(), sizeof(DBA_DYNFLD_STP)));

    int i = 0;
    for (auto it = this->m_xdAttribVector.begin(); it != this->m_xdAttribVector.end(); ++it, i++)
    {
        sortedXdAttribTab[i] = (*it);
    }

    TLS_Sort((char *)sortedXdAttribTab,
             this->getXdAttribNbr(),
             sizeof(DBA_DYNFLD_STP),
             icmp,
             nullptr,
             SortRtnTp_None);

    return sortedXdAttribTab;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::isChangedPartition()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180118
**
*************************************************************************/
bool DdlGenEntity::isChangedPartition(std::string &realSqlName)
{
    bool bChanged = false;

    if (this->getSysXdEntityStp(realSqlName) &&
        GET_ENUM(this->getXdEntityStp(), A_XdEntity_PartAuthEn) != GET_ENUM(this->getSysXdEntityStp(realSqlName), A_XdEntity_PartAuthEn) &&
        (GET_ENUM(this->getXdEntityStp(), A_XdEntity_PartAuthEn) == FeatureAuth_Enable ||
         GET_ENUM(this->getSysXdEntityStp(realSqlName), A_XdEntity_PartAuthEn) == FeatureAuth_Enable))
    {
        bChanged = true;

        if (GET_ENUM(this->getXdEntityStp(), A_XdEntity_PartAuthEn) != FeatureAuth_Enable)
        {
            int                    partitionNbr = this->getXdPartitionNbr();
            DBA_DYNFLD_STP        *partitionTab = this->getXdPartitionTab();

            for (int i = 0; i < partitionNbr; i++)
            {
                if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) == XdStatus_Inserted)
                {
                    SET_ENUM(partitionTab[i], A_XdPartition_XdActionEn, XdAction_ToPhysicallyDelete);
                }
            }
        }
    }
    else if (GET_ENUM(this->getXdEntityStp(), A_XdEntity_PartAuthEn) == FeatureAuth_Enable)
    {
        this->sortPartitions(false);
        this->sortPartitions(true);

        int                    partitionNbr = this->getXdPartitionNbr();
        DBA_DYNFLD_STP        *partitionTab = this->getXdPartitionTab();

        int                    sysPartitionNbr = this->sysXdPartitionNbr;
        DBA_DYNFLD_STP        *sysPartitionTab = this->sysXdPartitionTab;

        int                    i, j;
        bChanged = false;
        for (i = 0, j = 0; i < partitionNbr && j < sysPartitionNbr && bChanged == false; i++)
        {
            if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) == XdStatus_Untreated)
            {
                bChanged = true;
                continue;
            }
            else if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) != XdStatus_Inserted)
            {
                continue;
            }

            if (strcasecmp(GET_SYSNAME(partitionTab[i], A_XdPartition_SqlName), GET_SYSNAME(sysPartitionTab[j], A_XdPartition_SqlName)) ||
                CMP_DYNFLD(partitionTab[i], sysPartitionTab[j], A_XdPartition_SegmentDictId, A_XdPartition_SegmentDictId, DictType) ||
                CMP_DYNFLD(partitionTab[i], sysPartitionTab[j], A_XdPartition_XdAttrib1Id, A_XdPartition_XdAttrib1Id, IdType) ||
                CMP_DYNFLD(partitionTab[i], sysPartitionTab[j], A_XdPartition_XdAttrib2Id, A_XdPartition_XdAttrib2Id, IdType) ||
                CMP_DYNFLD(partitionTab[i], sysPartitionTab[j], A_XdPartition_ParentXdPartitionId, A_XdPartition_ParentXdPartitionId, IdType) ||
                CMP_DYNFLD(partitionTab[i], sysPartitionTab[j], A_XdPartition_PartTypeEn, A_XdPartition_PartTypeEn, EnumType))
            {
                bChanged = true;
            }

            j++;
        }

        for (; i < partitionNbr && bChanged == false; i++)
        {
            if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) == XdAction_ToInsert ||
                GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) == XdStatus_Untreated)
            {
                bChanged = true;
                continue;
            }
        }

        if (bChanged)
        {
            for (i = 0; i < partitionNbr; i++)
            {
                if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) == XdStatus_Inserted)
                {
                    SET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn, XdStatus_Untreated);
                }
            }
        }
    }

    return bChanged;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionTab()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DBA_DYNFLD_STP *DdlGenEntity::getXdPartitionTab()
{
    return this->xdPartitionTab;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
int DdlGenEntity::getXdPartitionNbr()
{
    return this->xdPartitionNbr;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::isMesiPartitioned()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34418 - LJE - 190201
**
*************************************************************************/
bool DdlGenEntity::isMesiPartitioned()
{
    if (static_cast<DBA_ENTITY_NAT_ENUM>(GET_ENUM(this->m_xdEntityStp, A_XdEntity_NatEn)) != EntityNat_SearchFmt)
    {
        MultiEntityHelper entityMultiEntityCateg(static_cast<MULTI_ENTITY_CATEGORY_ENUM>(GET_ENUM(this->m_xdEntityStp, A_XdEntity_MultiEntityCategoryEn)));

        if (entityMultiEntityCateg.isMultiEntityCateg() && entityMultiEntityCateg.get() != MultiEntityCategory_MasterOnlyPrecOnBEOnly)
        {
            DdlGenEntity *tplDdlGenEntityPtr = this->m_ddlGenContext.getTemplateDdlGenEntityPtr();

            if (tplDdlGenEntityPtr == nullptr)
            {
                return false;
            }

            DBA_DYNFLD_STP* tplXdPartionTab = tplDdlGenEntityPtr->getXdPartitionTab();
            int             tplXdPartionNbr = tplDdlGenEntityPtr->getXdPartitionNbr();

            if (tplXdPartionNbr == 1 &&
                IS_NULLFLD(tplXdPartionTab[0], A_XdPartition_SqlName) == FALSE &&
                strcmp(GET_SYSNAME(tplXdPartionTab[0], A_XdPartition_SqlName), "business_entity") == 0 &&
                DBA_GetDictEntitySt(BusEntity) != nullptr)
            {
                return true;
            }
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionBySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdPartitionBySqlName(DBA_DYNFLD_STP newXdPartition)
{
    for (int i = 0; i < this->xdPartitionNbr; i++)
    {
        if (CMP_DYNFLD(newXdPartition, this->xdPartitionTab[i], A_XdPartition_SqlName, A_XdPartition_SqlName, SysnameType) == 0)
        {
            return this->xdPartitionTab[i];
        }
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionById()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdPartitionById(ID_T partitionId)
{
    for (int i = 0; i < this->xdPartitionNbr; i++)
    {
        if (partitionId == GET_ID(this->xdPartitionTab[i], A_XdPartition_Id))
        {
            return this->xdPartitionTab[i];
        }
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::addXdPartition()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
RET_CODE DdlGenEntity::addXdPartition(DdlGenRequestHelper  &requestHelper, DBA_DYNFLD_STP tplXdPartition, DdlGenEntity *tplDdlGenEntityPtr)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP newXdPartition = ALLOC_DYNST(A_XdPartition);

    if (newXdPartition != nullptr)
    {
        COPY_DYNST(newXdPartition, tplXdPartition, A_XdPartition);

        SET_ID(newXdPartition, A_XdPartition_XdEntityId, GET_ID(this->m_xdEntityStp, A_XdEntity_Id));
        SET_NULL_ID(newXdPartition, A_XdPartition_Id);

        if (this->getXdAttribById(GET_ID(newXdPartition, A_XdPartition_XdAttrib1Id)) == nullptr)
        {
            DBA_DYNFLD_STP tplXdAttribStp = tplDdlGenEntityPtr->getXdAttribById(GET_ID(newXdPartition, A_XdPartition_XdAttrib1Id));
            if (tplXdAttribStp != nullptr)
            {
                if (IS_NULLFLD(tplXdAttribStp, A_XdAttrib_FeatureEn) == TRUE ||
                    this->getFeatureAuth(GET_A_XdAttrib_FeatureEn(tplXdAttribStp)) == FeatureAuth_Enable)
                {
                    DBA_DYNFLD_STP currXdAttribStp = this->getXdAttribBySqlName(GET_SYSNAME(tplXdAttribStp, A_XdAttrib_SqlName));

                    if (currXdAttribStp != nullptr)
                    {
                        DBA_ACTION_ENUM actionDone = NullAction;

                        SET_ID(newXdPartition, A_XdPartition_XdAttrib1Id, GET_ID(currXdAttribStp, A_XdAttrib_Id));

                        this->xdPartitionNbr++;
                        this->xdPartitionTab = (DBA_DYNFLD_STP*)REALLOC(this->xdPartitionTab, this->xdPartitionNbr * sizeof(DBA_DYNFLD_STP));

                        this->xdPartitionTab[this->xdPartitionNbr - 1] = newXdPartition;

                        this->sortPartitions();

                        SET_ENUM(newXdPartition, A_XdPartition_XdActionEn, XdAction_ToInsert);
                        if ((ret = requestHelper.insUpdRecord(newXdPartition, actionDone)) != RET_SUCCEED)
                        {
                            this->m_ddlGenContext.printMsg(ret, "Unable to create xd_partition");
                            return ret;
                        }

                        newXdPartition = nullptr;
                    }
                    else
                    {
                        ret = RET_DBA_ERR_MD;
                        this->m_ddlGenContext.printMsg(ret, "Unknown partition attribute std::set in dict_attribute_template entity '" + std::string(GET_SYSNAME(tplXdAttribStp, A_XdAttrib_SqlName)) + "'");
                    }
                }
            }
        }
    }

    if (newXdPartition != nullptr)
    {
        FREE_DYNST(newXdPartition, A_XdPartition);
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::sortPartitions()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
void DdlGenEntity::sortPartitions(bool bSysPartition)
{
    if (bSysPartition)
    {
        TLS_Sort((char *)this->sysXdPartitionTab,
                 this->sysXdPartitionNbr,
                 sizeof(DBA_DYNFLD_STP),
                 (TLS_CMPFCT *)DDL_CmpXdPartition,
                 (PTR **)NULL,
                 SortRtnTp_None);
    }
    else
    {
        TLS_Sort((char *)this->xdPartitionTab,
                 this->xdPartitionNbr,
                 sizeof(DBA_DYNFLD_STP),
                 (TLS_CMPFCT *)DDL_CmpXdPartition,
                 (PTR **)NULL,
                 SortRtnTp_None);
    }
}

/************************************************************************
**
**  Function    :   DdlGenEntity::clearXdPartition()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
void DdlGenEntity::clearXdPartition()
{
    DBA_FreeDynStTab(this->xdPartitionTab, this->xdPartitionNbr, A_XdPartition);
    this->xdPartitionTab = NULL;
    this->xdPartitionNbr = 0;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::clearXdPartitionIndex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
void DdlGenEntity::clearXdPartitionIndex()
{
    DBA_FreeDynStTab(this->xdPartitionIndexTab, this->xdPartitionIndexNbr, A_XdPartitionIndex);
    this->xdPartitionIndexTab = NULL;
    this->xdPartitionIndexNbr = 0;

    this->m_sysXdIdxPartitionVector.clear();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionIndexTab()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DBA_DYNFLD_STP   *DdlGenEntity::getXdPartitionIndexTab()
{
    return this->xdPartitionIndexTab;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPartitionIndexNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
int DdlGenEntity::getXdPartitionIndexNbr()
{
    return this->xdPartitionIndexNbr;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::addXdPartitionIndexInTab()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
void DdlGenEntity::addXdPartitionIndexInTab(DBA_DYNFLD_STP newXdPartitionIndex)
{
    this->xdPartitionIndexNbr++;
    this->xdPartitionIndexTab = (DBA_DYNFLD_STP*)REALLOC(this->xdPartitionIndexTab, this->xdPartitionIndexNbr * sizeof(DBA_DYNFLD_STP));

    this->xdPartitionTab[this->xdPartitionIndexNbr - 1] = newXdPartitionIndex;

    this->sortPartitionIndexes();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::sortPartitionIndexes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
void DdlGenEntity::sortPartitionIndexes()
{
    TLS_Sort((char *)this->xdPartitionIndexTab,
             this->xdPartitionIndexNbr,
             sizeof(DBA_DYNFLD_STP),
             (TLS_CMPFCT *)DDL_CmpXdPartitionIndex,
             (PTR **)NULL,
             SortRtnTp_None);
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getNextAttributeDictId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DICT_T DdlGenEntity::getNextAttributeDictId(DBA_DYNFLD_STP xdAttribStp)
{
    DICT_T attrDictId = 0;

    if (this->m_attDictId == 0)
    {
        this->m_attDictId = (this->m_dictEntityStp->entDictId * 1000);
        this->m_UDFAttDictId = (this->m_dictEntityStp->entDictId * 1000) + 300;
        this->m_extAttDictId = (this->m_dictEntityStp->entDictId * 1000) + 700;

        this->m_maxAttDictId = this->m_UDFAttDictId - 1;
        this->m_maxUDFAttDictId = this->m_extAttDictId - 1;
        this->m_maxExtAttDictId = (this->m_dictEntityStp->entDictId * 1000) + 999;

        for (auto it = this->m_dbXdAttribMap.begin(); it != this->m_dbXdAttribMap.end(); ++it)
        {
            DBA_DYNFLD_STP currXdAttribStp = it->second;

            if ((GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE ||
                 DdlGen::getXIdSqlName() == GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName) ||
                 (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::TSLExtensions &&
                  IS_NULLFLD(currXdAttribStp, A_XdAttrib_TemplateXdAttribId) == FALSE)) &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
            {
                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE &&
                    GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None &&
                    this->m_extAttDictId < GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId))
                {
                    this->m_extAttDictId = GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                }
            }
            else if ((GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
                      GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None) ||
                     DdlGen::getUdIdSqlName() == GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName))
            {
                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE &&
                    this->m_UDFAttDictId < GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId))
                {
                    this->m_UDFAttDictId = GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                }
            }
            else
            {
                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE &&
                    this->m_attDictId < GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId))
                {
                    this->m_attDictId = GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                }
            }
        }

        for (auto& attribIt : this->m_dictEntityStp->attribMap)
        {
            if (attribIt.second->precompFlg == TRUE)
            {
                if (this->m_extAttDictId < attribIt.first)
                {
                    this->m_extAttDictId = attribIt.first;
                }
            }
            else if (attribIt.second->custFlg == TRUE &&
                attribIt.second->featureEn == XdEntityFeatureFeatureEn::None)
            {
                if (this->m_UDFAttDictId < attribIt.first)
                {
                    this->m_UDFAttDictId = attribIt.first;
                }
            }
            else
            {
                if (this->m_attDictId < attribIt.first)
                {
                    this->m_attDictId = attribIt.first;
                }
            }
        }

        if (this->m_attDictId > this->m_maxAttDictId)
        {
            this->m_maxAttDictId = ID_T_MAX;
        }
        if (this->m_UDFAttDictId > this->m_maxUDFAttDictId)
        {
            this->m_maxUDFAttDictId = ID_T_MAX;
        }
        if (this->m_extAttDictId > this->m_maxExtAttDictId)
        {
            this->m_maxExtAttDictId = ID_T_MAX;
        }
    }

    if (IS_NULLFLD(xdAttribStp, A_XdAttrib_AttribDictId) == FALSE && GET_DICT(xdAttribStp, A_XdAttrib_AttribDictId) > 0)
    {
        attrDictId = GET_DICT(xdAttribStp, A_XdAttrib_AttribDictId);
    }
    else if (GET_ENUM(xdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
    {
        this->m_UDFAttDictId++;

        if (this->m_UDFAttDictId > this->m_maxUDFAttDictId)
        {
            /* 10SEEEEEAAA */
            this->m_UDFAttDictId = (this->m_dictEntityStp->entDictId * 10000000000) + 1;
            this->m_maxUDFAttDictId = ID_T_MAX;
        }
        attrDictId = this->m_UDFAttDictId;
    }
    else if (GET_FLAG(xdAttribStp, A_XdAttrib_PrecompFlg) == TRUE)
    {
        this->m_extAttDictId++;

        if (this->m_extAttDictId > this->m_maxExtAttDictId)
        {
            /* 100SEEEEEAAA */
            this->m_extAttDictId = (this->m_dictEntityStp->entDictId * 100000000000) + 1;
            this->m_maxExtAttDictId = ID_T_MAX;
        }
        attrDictId = this->m_extAttDictId;
    }
    else
    {
        this->m_attDictId++;

        if (this->m_attDictId > this->m_maxAttDictId)
        {
            /* 1SEEEEEAAA - S = Special entities (from cpy_xd_entity_by_nm) (1), E = Entity (5), A = Attribute (3) */
            this->m_attDictId = (this->m_dictEntityStp->entDictId * 1000000000) + 1;
            this->m_maxAttDictId = ID_T_MAX;
        }
        attrDictId = this->m_attDictId;
    }

    assert(attrDictId < ID_T_MAX && attrDictId > 0);

    SET_DICT(xdAttribStp, A_XdAttrib_AttribDictId, attrDictId);

    return attrDictId;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::freeNoSysRecords()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46168 - LJE - 210907
**
*************************************************************************/
void DdlGenEntity::freeNoSysRecords()
{
    for (auto it = this->m_extFmtEltDenomMap.begin(); it != this->m_extFmtEltDenomMap.end(); ++it)
    {
        for (auto denomIt = it->second.begin(); denomIt != it->second.end(); ++denomIt)
        {
            this->m_mp.freeDynStp((*denomIt));
        }
        it->second.clear();
    }
}

/************************************************************************
**
**  Function    :   DdlGenEntity::addXdEntityFeature()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170322
**
*************************************************************************/
void DdlGenEntity::addXdEntityFeature(DdlGenRequestHelper      &requestHelper, 
                                      XdEntityFeatureFeatureEn  featureEn,
                                      GEN_RULE_ENUM             genRuleEn, 
                                      FEATURE_AUTH_ENUM         featureAuthEn,
                                      bool                      bResetAction)
{
    auto           featureIt = this->xdEntityFeatureMap.find(featureEn);
    DBA_DYNFLD_STP newFeatureStp = nullptr;

    if (featureIt == this->xdEntityFeatureMap.end())
    {
        newFeatureStp = requestHelper.allocDynSt(FILEINFO, A_XdEntityFeature);

        this->xdEntityFeatureMap.insert(std::make_pair(featureEn, newFeatureStp));

        SET_ID(newFeatureStp, A_XdEntityFeature_XdEntityId, GET_ID(this->getXdEntityStp(), A_XdEntity_Id));
        SET_ENUM(newFeatureStp, A_XdEntityFeature_FeatureEn, featureEn);
        SET_ENUM(newFeatureStp, A_XdEntityFeature_XdStatusEn, XdStatus_Untreated);
    }
    else
    {
        newFeatureStp = featureIt->second;

        /* Keep gen rule for intermediary multi-entity migration */
        if (featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
            this->m_ddlGenContext.getMultiEntityLevel() != MultiEntityLevel_Active &&
            (GEN_RULE_ENUM)GET_ENUM(newFeatureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysNotMandatory)
        {
            genRuleEn = (GEN_RULE_ENUM)GET_ENUM(newFeatureStp, A_XdEntityFeature_GenRuleEn);
        }
    }

    SET_ENUM(newFeatureStp, A_XdEntityFeature_GenRuleEn, genRuleEn);
    SET_ENUM(newFeatureStp, A_XdEntityFeature_AuthEn, featureAuthEn);
    SET_ENUM(newFeatureStp, A_XdEntityFeature_XdActionEn, XdAction_ToInsert);

    DBA_ACTION_ENUM actionDone = NullAction;
    requestHelper.insUpdRecord(newFeatureStp, actionDone);

    if (bResetAction)
    {
        SET_ENUM(newFeatureStp, A_XdEntityFeature_XdActionEn, XdAction_None);
    }

}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdIndexVector()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
std::vector<DBA_DYNFLD_STP> &DdlGenEntity::getXdIndexVector()
{
    this->loadExdIndexInfo();

    return this->m_xdIndexVector;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::addXdIndex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-41612 - LJE - 201006
**
*************************************************************************/
void DdlGenEntity::addXdIndex(DBA_DYNFLD_STP newXdIndexStp)
{
    this->m_xdIndexVector.push_back(newXdIndexStp);

    if (this->m_ddlGenContext.ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt)
    {
        this->m_dictEntityStp->xdIndexMap[GET_SYSNAME(newXdIndexStp, A_XdIndex_SqlName)] = this->m_dictEntityStp->m_mp.duplicate(FILEINFO, newXdIndexStp);
    }
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdIndexAttribVector()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180117
**
*************************************************************************/
std::vector<DBA_DYNFLD_STP> &DdlGenEntity::getXdIndexAttribVector(DBA_DYNFLD_STP xdIndexStp)
{
    auto idxAttribIt = this->m_xdIndexAttribMapVector.find(xdIndexStp);
    if (idxAttribIt == this->m_xdIndexAttribMapVector.end())
    {
        return this->m_xdIndexAttribMapVector[xdIndexStp];
    }
    return idxAttribIt->second;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdIndexAttriByRankbMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180117
**
*************************************************************************/
std::map<SMALLINT_T, DBA_DYNFLD_STP> &DdlGenEntity::getXdIndexAttribByRankMap(DBA_DYNFLD_STP xdIndexStp)
{
    auto &xdIndexAttribByRankMap = this->m_xdIndexAttribByRankMapMap[xdIndexStp];

    if (xdIndexAttribByRankMap.empty())
    {
        auto &xdIndexAttribVector = this->getXdIndexAttribVector(xdIndexStp);
        for (auto it = xdIndexAttribVector.begin(); it != xdIndexAttribVector.end(); ++it)
        {
            DBA_DYNFLD_STP xdIndexAttribStp = (*it);

            if ((GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_None && 
                 GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted) ||
                (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_None &&
                 GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Untreated) ||
                GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
            {
                xdIndexAttribByRankMap.insert(std::make_pair(GET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank), xdIndexAttribStp));
            }
        }
    }

    return xdIndexAttribByRankMap;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getSysXdIndexVector()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
std::vector<DBA_DYNFLD_STP> &DdlGenEntity::getSysXdIndexVector()
{
    this->loadExdIndexFromSysInfo();

    return this->m_sysXdIndexVector;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getSysXdIndexAttribMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180117
**
*************************************************************************/
std::map<SMALLINT_T, DBA_DYNFLD_STP> &DdlGenEntity::getSysXdIndexAttribByRankMap(DBA_DYNFLD_STP xdIndexStp)
{
    return this->m_sysXdIndexAttribByRankMapMap[xdIndexStp];
}


/************************************************************************
**
**  Function    :   DdlGenEntity::getDbXdAttribMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180117
**
*************************************************************************/
std::map<std::string, DBA_DYNFLD_STP> &DdlGenEntity::getDbXdAttribMap()
{
    return this->m_dbXdAttribMap;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPermValByAttribMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200408
**
*************************************************************************/
std::map<ENUM_T, DBA_DYNFLD_STP> *DdlGenEntity::getXdPermValByAttribMap(ID_T xdAttribId)
{
    auto xdPermValIt = this->m_xdAttrPermValMap.find(xdAttribId);
    if (xdPermValIt != this->m_xdAttrPermValMap.end())
    {
        return &xdPermValIt->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPermValByAttribMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200408
**
*************************************************************************/
std::map<ENUM_T, DBA_DYNFLD_STP>* DdlGenEntity::getXdPermValByAttribMap(DBA_DYNFLD_STP xdAttribStp)
{
    return this->getXdPermValByAttribMap(IS_NULLFLD(xdAttribStp, A_XdAttrib_ParentXdAttribId) ? 
                                         GET_ID(xdAttribStp, A_XdAttrib_Id) : 
                                         GET_ID(xdAttribStp, A_XdAttrib_ParentXdAttribId));
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdPermValById()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200408
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdPermValById(ID_T xdPermValId)
{
    auto it = this->m_xdPermValMap.find(xdPermValId);
    if (it != this->m_xdPermValMap.end())
    {
        return it->second;
    }
    return nullptr;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttribStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdAttribStp(DICT_ATTRIB_STP dictAttribStp)
{
    if (dictAttribStp->progN < this->getXdAttribNbr())
    {
        if (strcmp(GET_SYSNAME(this->m_xdAttribVector[dictAttribStp->progN], A_XdAttrib_SqlName), dictAttribStp->sqlName) == 0)
        {
            return this->m_xdAttribVector[dictAttribStp->progN];
        }
    }

    for (int i = 0; i < this->getXdAttribNbr(); i++)
    {
        if (strcmp(GET_SYSNAME(this->m_xdAttribVector[i], A_XdAttrib_SqlName), dictAttribStp->sqlName) == 0)
        {
            return this->m_xdAttribVector[i];
        }
    }

    return NULL;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttribBySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-23385 - LJE - 160707
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdAttribBySqlName(const std::string &attribSqlName)
{
    for (int i = 0; i < this->getXdAttribNbr(); i++)
    {
        if (attribSqlName.compare(GET_SYSNAME(this->m_xdAttribVector[i], A_XdAttrib_SqlName)) == 0)
        {
            return this->m_xdAttribVector[i];
        }
    }

    return NULL;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getDbXdAttribBySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-23385 - LJE - 160707
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getDbXdAttribBySqlName(const std::string &attribSqlName)
{
    auto attribIt = this->m_dbXdAttribMap.find(attribSqlName);
    if (attribIt != this->m_dbXdAttribMap.end())
    {
        return attribIt->second;
    }
    return NULL;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdAttribById()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170509
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getXdAttribById(ID_T xdAttribId)
{
    for (int i = 0; i < this->getXdAttribNbr(); i++)
    {
        if (GET_ID(this->m_xdAttribVector[i], A_XdAttrib_Id) == xdAttribId)
        {
            return this->m_xdAttribVector[i];
        }
    }
    return NULL;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getSysXdAttribStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::getSysXdAttribStp(TARGET_TABLE_ENUM targetTableEn, const std::string &attribSqlName)
{
    if (this->sysXdAttribMapMap.empty() == true)
    {
        return nullptr;
    }

    auto targetSysXdAttribMapIt = this->sysXdAttribMapMap.find(targetTableEn);
    if (targetSysXdAttribMapIt == this->sysXdAttribMapMap.end())
    {
        return nullptr;
    }

    auto sysXdAttribMapIt = targetSysXdAttribMapIt->second.find(attribSqlName);
    if (sysXdAttribMapIt != targetSysXdAttribMapIt->second.end())
    {
        return sysXdAttribMapIt->second;
    }

    sysXdAttribMapIt = targetSysXdAttribMapIt->second.find(lower(attribSqlName));
    if (sysXdAttribMapIt != targetSysXdAttribMapIt->second.end())
    {
        return sysXdAttribMapIt->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getSysMandatoryAttribSqlNameSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171206
**
*************************************************************************/
void DdlGenEntity::getSysMandatoryAttribSqlNameSet(std::map<std::string, DBA_DYNFLD_STP> &mandatorySet, TARGET_TABLE_ENUM targetTableEn)
{
    mandatorySet.clear();

    auto targetSysXdAttribMapIt = this->sysXdAttribMapMap.find(targetTableEn);

    if (targetSysXdAttribMapIt != this->sysXdAttribMapMap.end())
    {
        for (auto it = targetSysXdAttribMapIt->second.begin(); it != targetSysXdAttribMapIt->second.end(); ++it)
        {
            if (GET_FLAG(it->second, A_XdAttrib_DbMandatoryFlg) == TRUE &&
                IS_NULLFLD(it->second, A_XdAttrib_Default) == TRUE)
            {
                mandatorySet.insert(std::make_pair(it->first, it->second));
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenEntity::removeDeletedAttributes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121214
**
*************************************************************************/
RET_CODE DdlGenEntity::removeDeletedAttributes()
{
    RET_CODE        ret = RET_SUCCEED;

    for (auto it = this->m_xdAttribVector.begin(); it != this->m_xdAttribVector.end(); ++it)
    {
        if (GET_ENUM((*it), A_XdAttrib_XdActionEn) != XdAction_ToInsert)
        {
            NESTED_ERASE(this->m_xdAttribVector, it)
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getDictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150708
**
*************************************************************************/
DICT_ENTITY_STP DdlGenEntity::getDictEntityStp()
{
    if (this->m_dictEntityStp == nullptr)
    {
        this->m_dictEntityStp = DBA_GetEntityBySqlName(this->m_sqlName, true);
    }

    if (this->m_xdEntityStp != nullptr && this->m_dictEntityStp == nullptr)
    {
        OBJECT_ENUM objectEn = NullEntity;

        /* Try to find the object enum in the hard-coded table values */
        if (IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_DictEntityValue) == FALSE)
        {
            objectEn = DBA_GetObjectBySqlName(GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_SqlName));
        }

        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
        DICT_CreateVirtualEntity(&objectEn,
                                 GET_NAME(this->m_xdEntityStp, A_XdEntity_Name),
                                 GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_SqlName),
                                 GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_DbSqlName),
                                 this->m_xdEntityStp,
                                 false,
                                 &ddlGenConnGuard.getDbiConn());

        this->m_dictEntityStp = DBA_GetDictEntitySt(objectEn);
        this->m_dictEntityStp->virtualEntFlg = FALSE;
        this->m_dictEntityStp->xdStatusEn = (XD_STATUS_ENUM)GET_ENUM(this->m_xdEntityStp, A_XdEntity_XdStatusEn);

#ifdef AAADEBUGMSG
        assert(strcmp(this->m_dictEntityStp->mdSqlName, GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_SqlName)) == 0);
#endif
        this->m_dictEntityStp->entDefInCFlg = TRUE;
        SET_DICT(this->m_xdEntityStp, A_XdEntity_EntityDictId, this->m_dictEntityStp->entDictId);
    }
    else if (this->m_xdEntityStp && this->m_dictEntityStp->entNatEn == EntityNat_All && IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_DictEntityValue) == FALSE)
    {
        this->m_dictEntityStp = &DICT_AddNewDictEntity(GET_INT(this->m_xdEntityStp, A_XdEntity_DictEntityValue),
                                                       this->m_dictEntityStp->objectEn,
                                                       GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_SqlName),
                                                       (IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_DbSqlName) ?
                                                        GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_SqlName) :
                                                        GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_DbSqlName)));
    }

    if (this->m_dictEntityStp == nullptr)
    {
        return &m_invalidDictEntitySt;
    }
    else
    {
        return this->m_dictEntityStp;
    }

}

/************************************************************************
**
**  Function    :   DdlGenEntity::getPkSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34373 - LJE - 190221
**
*************************************************************************/
std::string DdlGenEntity::getPkSqlName(TARGET_TABLE_ENUM targetTableEn)
{
    if (this->m_ddlGenDbi.isAutoIndexOnPK())
    {
        /* it is not allowed to create multiple objects with same name (even if the object is a constraint) in Sql Server */

        if (targetTableEn == TargetTable_Main)
        {
            if (this->m_pkSqlName.empty())
            {
                this->m_pkSqlName = "pk_" + std::to_string(this->getDictEntityStp()->entDictId);
            }
            return this->m_pkSqlName;
        }
        else if (targetTableEn == TargetTable_UserDefinedFields)
        {
            if (this->m_udPkSqlName.empty())
            {
                this->m_udPkSqlName = "ud_pk_" + std::to_string(this->getDictEntityStp()->entDictId);
            }
            return this->m_udPkSqlName;
        }
        else if (targetTableEn == TargetTable_Precomp)
        {
            if (this->m_xPkSqlName.empty())
            {
                this->m_xPkSqlName = "x_pk_" + std::to_string(this->getDictEntityStp()->entDictId);
            }
            return this->m_xPkSqlName;
        }
    }

    if (targetTableEn == TargetTable_Main)
    {
        if (this->m_pkSqlName.empty())
        {
            this->m_pkSqlName = this->getDictEntityStp()->mdSqlName;
            this->m_pkSqlName += "_pk";
            if (this->m_pkSqlName.length() > this->m_ddlGenDbi.getMaxDDLObjLength())
            {
                this->m_pkSqlName = this->getDictEntityStp()->shortSqlname;
                this->m_pkSqlName += "_pk";
            }
        }
        return this->m_pkSqlName;
    }
    else if (targetTableEn == TargetTable_UserDefinedFields)
    {
        if (this->m_udPkSqlName.empty())
        {
            this->m_udPkSqlName = this->getDictEntityStp()->custSqlName;
            this->m_udPkSqlName += "_pk";
            if (this->m_udPkSqlName.length() > this->m_ddlGenDbi.getMaxDDLObjLength())
            {
                this->m_udPkSqlName = "ud_";
                this->m_udPkSqlName += this->getDictEntityStp()->shortSqlname;
                this->m_udPkSqlName += "_pk";
            }
        }
        return this->m_udPkSqlName;
    }
    else if (targetTableEn == TargetTable_Precomp)
    {
        if (this->m_xPkSqlName.empty())
        {
            this->m_xPkSqlName = this->getDictEntityStp()->precompSqlName;
            this->m_xPkSqlName += "_pk";
            if (this->m_udPkSqlName.length() > this->m_ddlGenDbi.getMaxDDLObjLength())
            {
                this->m_udPkSqlName = "x_";
                this->m_udPkSqlName += this->getDictEntityStp()->shortSqlname;
                this->m_udPkSqlName += "_pk";
            }
        }
        return this->m_xPkSqlName;
    }

    SYS_BreakOnDebug();
    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getFeatureAuth()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150708
**
*************************************************************************/
FEATURE_AUTH_ENUM DdlGenEntity::getFeatureAuth(XdEntityFeatureFeatureEn featureEn)
{
    auto it = this->xdEntityFeatureMap.find(featureEn);
    if (it != this->xdEntityFeatureMap.end())
    {
        DBA_DYNFLD_STP featureStp = it->second;
        if (GET_A_XdEntityFeature_FeatureEn(featureStp) == featureEn &&
            ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToInsert ||
            ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_None && (XD_STATUS_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdStatusEn) == XdStatus_Inserted)))
        {
            return (FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn);
        }
    }
    return FeatureAuth_Forbidden;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::clearXdEntityFeatures()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170811
**
*************************************************************************/
void DdlGenEntity::clearXdEntityFeatures()
{
    this->xdEntityFeatureMap.clear();
}

/************************************************************************
**
**  Function    :   DdlGenEntity::loadExdEntityInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120514
**
*************************************************************************/
RET_CODE DdlGenEntity::loadExdEntityInfo(bool bForceLoad)
{
    RET_CODE        ret = RET_SUCCEED;

    /* PMSTA-29879 - LJE - 180212 */
    if ((this->bIsLoaded && bForceLoad == false) ||
        this->m_ddlGenContext.ddlGenAction.m_buildRuleEn == DdlGenBuildRule_ForceBuild &&
        this->m_ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildVirtualFromFmt)
    {
        return ret;
    }

    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);
    DbiConnectionHelper dbiConnHelper((EV_UseAlternativeDataSource == false ? &ddlGenConnGuard.getDbiConn() : nullptr), false);
    MemoryPool           mp;

    this->m_xdAttribVector.clear();

    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(this->m_ddlGenContext);
    DdlGenDbaAccess& ddlGenDbaAccess = ddlGenDbaAccessGuard.getDdlGenDbaAccess();

    this->m_xdEntityStp = nullptr;

    /* PMSTA-37366 - LJE - 200203 */
    this->m_extFmtEltVector.clear();
    this->m_extFmtEltDenomMap.clear();

    this->clearXdEntityFeatures();

    this->m_xdPermValMap.clear();
    this->m_xdAttrPermValMap.clear();

    this->clearXdPartition();

    if (ddlGenDbaAccess.isLoaded(XdEntity) == false &&
        ddlGenDbaAccess.isLoaded(this->shXdEntityStp) == false &&
        ddlGenDbaAccess.load(this->shXdEntityStp) != RET_SUCCEED)
    {
        return(RET_DBA_ERR_NODATA);
    }

    ddlGenDbaAccess.getData(*this, bForceLoad);

    if (this->m_sqlName != this->m_targetSqlName &&
        this->m_targetSqlName.find("check_") != 0)
    {
        ddlGenDbaAccess.getExtendedData(*this);
    }

    if (this->m_xdEntityStp != nullptr)
    {
        if (EV_UseAlternativeDataSource)
        {
            SET_NULL_SYSNAME(this->m_xdEntityStp, A_XdEntity_Segment);
            SET_NULL_DICT(this->m_xdEntityStp, A_XdEntity_SegmentDictId);
            SET_NULL_SYSNAME(this->m_xdEntityStp, A_XdEntity_PrecompDatabase);
            SET_NULL_SYSNAME(this->m_xdEntityStp, A_XdEntity_PrecompSegment);
            SET_NULL_DICT(this->m_xdEntityStp, A_XdEntity_PrecompDatabaseDictId);
            SET_NULL_DICT(this->m_xdEntityStp, A_XdEntity_PrecompSegmentDictId);

            if (IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_Database) == FALSE)
            {
                std::string database = GET_SYSNAME(this->m_xdEntityStp, A_XdEntity_Database);
                this->m_ddlGenContext.getConvertValue(database);
                SET_SYSNAME(this->m_xdEntityStp, A_XdEntity_Database, database.c_str());
            }
        }

        if (bForceLoad == true &&
            (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension ||
             (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
              this->m_ddlGenContext.ddlGenAction.isBootStrapLevel() == false &&
              this->m_ddlGenContext.ddlGenAction.m_bInitEntityOnly == false &&
              this->m_ddlGenContext.m_bIsInstallFromScratch == false &&
              this->m_ddlGenContext.m_bDatAll == false)) &&
            IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_EntityDictId) == FALSE &&
            GET_FLAG(this->m_xdEntityStp, A_XdEntity_PrecompFlg) == TRUE)
        {
            if (this->m_ddlGenContext.ddlGenAction.m_fromImport)
            {
                ddlGenDbaAccess.fillExtFromMemory(*this);
            }
            else
            {
                DBA_DYNFLD_STP  tslPrecJobStp = mp.allocDynst(FILEINFO, A_TslPrecJob);

                DBA_DYNFLD_STP *extData[] = { NULLDYNSTPTR, NULLDYNSTPTR };
                int              extRows[] = { 0, 0 };

                SET_DICT(tslPrecJobStp, A_TslPrecJob_EntityDictId, GET_DICT(this->m_xdEntityStp, A_XdEntity_EntityDictId));

                SET_A_TslPrecJob_PackagingNatEn(tslPrecJobStp, TslPrecJobPackagingNatEn::Custom);

                if ((ret = dbiConnHelper.dbaMultiSelect(FmtElt, UNUSED, tslPrecJobStp, extData, extRows)) != RET_SUCCEED)
                {
                    ddlGenConnGuard.getDbiConn().sendAllMsg();
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Unable to load Master extension(Custom) attributes information");
                }

                if (extRows[0] == 0)
                {
                    SET_A_TslPrecJob_PackagingNatEn(tslPrecJobStp, TslPrecJobPackagingNatEn::ModelBank);

                    if ((ret = dbiConnHelper.dbaMultiSelect(FmtElt, UNUSED, tslPrecJobStp, extData, extRows)) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Unable to load Master extension(Model Bank) attributes information");
                    }
                }
                if (extRows[0] == 0)
                {
                    SET_A_TslPrecJob_PackagingNatEn(tslPrecJobStp, TslPrecJobPackagingNatEn::Standard);

                    if ((ret = dbiConnHelper.dbaMultiSelect(FmtElt, UNUSED, tslPrecJobStp, extData, extRows)) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Unable to load Master extension(Standard) attributes information");
                    }
                }

                for (int i = 0; i < extRows[0]; ++i)
                {
                    this->m_extFmtEltVector.push_back(extData[0][i]);
                    this->m_mp.ownerDynStp(extData[0][i]);
                }
                for (int i = 0; i < extRows[1]; ++i)
                {
                    this->m_extFmtEltDenomMap[GET_ID(extData[1][i], A_Denom_ObjId)].push_back(extData[1][i]);
                    this->m_mp.ownerDynStp(extData[1][i]);
                }

                FREE(extData[0]);
                FREE(extData[1]);
            }
        }

        if (bForceLoad == true &&
            ddlGenDbaAccess.isLoaded(DictDepends) == false &&
            IS_NULLFLD(this->m_xdEntityStp, A_XdEntity_EntityDictId) == FALSE &&
            (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension ||
             (this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
              this->m_ddlGenContext.ddlGenAction.m_bSingleEntity &&
              this->m_ddlGenContext.ddlGenAction.m_subRequest == false)))
        {
            DBA_DYNFLD_STP  shDictDepends = mp.allocDynst(FILEINFO, S_DictDepends);

            SET_DICT(shDictDepends, S_DictDepends_DictId, GET_DICT(this->m_xdEntityStp, A_XdEntity_EntityDictId));

            DBA_DYNFLD_STP* depEltTab = nullptr;
            int             depEltNbr = 0;

            if ((ret = dbiConnHelper.dbaSelect(DictDepends, UNUSED, shDictDepends, A_DictDepends, &depEltTab, &depEltNbr)) != RET_SUCCEED)
            {
                ddlGenConnGuard.getDbiConn().sendAllMsg();
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Unable to load meta-dictionary dependencies");
            }
            else
            {
                for (int i = 0; i < depEltNbr; i++)
                {
                    this->m_ddlGenContext.depEntityPscSqlNameSet.insert(GET_SYSNAME(depEltTab[i], A_DictDepends_GenEntityName));

                    if (this->m_ddlGenContext.bForceReBuild == false)
                    {
                        this->m_ddlGenContext.depSprocSqlNameSet.insert(GET_SYSNAME(depEltTab[i], A_DictDepends_SqlName));
                    }
                }
            }
            DBA_FreeDynStTab(depEltTab, depEltNbr, A_DictDepends);
        }

        bool            bActionPending = false;

        for (auto it = this->m_xdAttribVector.begin(); it != this->m_xdAttribVector.end(); ++it)
        {
            DBA_DYNFLD_STP dbXdAttribStp = ddlGenDbaAccess.duplicateDynStp(FILEINFO, (*it));
            this->m_dbXdAttribMap.insert(std::make_pair(GET_SYSNAME(dbXdAttribStp, A_XdAttrib_SqlName), dbXdAttribStp));

            if (this->m_extFmtEltVector.empty() == 0 &&
                GET_FLAG(this->m_xdEntityStp, A_XdEntity_PrecompFlg) == TRUE &&
                GET_FLAG((*it), A_XdAttrib_PrecompFlg) == TRUE)
            {
                SET_ENUM((*it), A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }
            else if (static_cast<XD_ACTION_ENUM>(GET_ENUM((*it), A_XdAttrib_XdActionEn)) != XdAction_None)
            {
                bActionPending = true;
            }
        }

        if (bActionPending &&
            bForceLoad == true &&
            this->m_ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension &&
            GET_ENUM(this->m_xdEntityStp, A_XdEntity_NatEn) != EntityNat_SearchFmt &&
            GET_ENUM(this->m_xdEntityStp, A_XdEntity_NatEn) != EntityNat_PersistedFmt &&
            GET_ENUM(this->m_xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt &&
            GET_ENUM(this->m_xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_Template)
        {
            ret = RET_DBA_ERR_INVDATA;

            std::stringstream msg;
            msg << "Some attributes of entity '" << GET_SYSNAME(this->shXdEntityStp, S_XdEntity_SqlName) << "' are action pending, please launch 'install_ddl dat dict' before run TSL extensions computation";
            this->m_ddlGenContext.printMsg(ret, msg.str());
        }
    }
    else
    {
        ret = RET_DBA_INFO_NODATA;
    }

    this->bIsLoaded = true;     /* PMSTA-29879 - LJE - 180212 */
    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenEntity:loadExdIndexInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30453 - LJE - 180328
**
*************************************************************************/
RET_CODE DdlGenEntity::loadExdIndexInfo(bool bForceLoad)
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->bIsIdxLoaded && bForceLoad == false)
    {
        return ret;
    }

    auto xdEntityStp = this->getXdEntityStp();

    if (xdEntityStp == nullptr ||
        ((IS_NULLFLD(xdEntityStp, A_XdEntity_Id) || GET_ID(xdEntityStp, A_XdEntity_Id) < 0) &&
         this->m_dictEntityStp->xdIndexMap.empty()))
    {
        return ret;
    }

    MemoryPool            mp;
    DdlGenConnGuard       ddlGenConnGuard(this->m_ddlGenContext);
    DbiConnectionHelper   dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

    DBA_FreeDynStTab(this->xdPartitionIndexTab, this->xdPartitionIndexNbr, A_XdPartitionIndex);
    this->xdPartitionIndexTab = NULL;
    this->xdPartitionIndexNbr = 0;

    this->m_xdIndexVector.clear();
    this->m_xdIndexAttribMapVector.clear();
    this->m_xdIndexAttribByRankMapMap.clear();

    DBA_DYNFLD_STP admArgStp = mp.allocDynst(FILEINFO, Adm_Arg);

    SET_ID(admArgStp, Adm_Arg_Id, GET_ID(xdEntityStp, A_XdEntity_Id));

    auto ddlGenAllEntititesPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenAllEntititesPtr != nullptr &&
        ddlGenAllEntititesPtr->isLoaded(XdIndex))
    {
        ddlGenAllEntititesPtr->selRecords(XdIndex, UNUSED, xdEntityStp, this->m_xdIndexVector);

        for (auto it = this->m_xdIndexVector.begin(); it != this->m_xdIndexVector.end(); ++it)
        {
            auto& xdIndexAttribVector = this->m_xdIndexAttribMapVector[*it];
            ddlGenAllEntititesPtr->selRecords(XdIndexAttrib, UNUSED, *it, xdIndexAttribVector);
        }
    }
    else if (this->m_ddlGenContext.ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild)
    {
        DBA_DYNFLD_STP* data[] = { NULL, NULL, NULL };
        int            	      rows[] = { 0, 0, 0 };

        if ((ret = dbiConnHelper.dbaMultiSelect(XdIndex, UNUSED, admArgStp, data, rows)) != RET_SUCCEED)
        {
            ddlGenConnGuard.getDbiConn().sendAllMsg();
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Indexes information");
            return(RET_DBA_ERR_NODATA);
        }

        for (int i = 0; i < rows[0]; i++)
        {
            this->m_xdIndexVector.push_back(data[0][i]);
            this->m_mp.owner(data[0][i]);
        }
        FREE(data[0]);

        if (this->m_xdIndexVector.empty() == false && rows[1] > 0)
        {
            int         xdIdxAttPos = 0;

            for (auto it = this->m_xdIndexVector.begin(); it != this->m_xdIndexVector.end(); ++it)
            {
                auto& xdIndexAttribVector = this->m_xdIndexAttribMapVector[*it];

                for (; xdIdxAttPos < rows[1]; xdIdxAttPos++)
                {
                    if (GET_ID(*it, A_XdIndex_Id) != GET_ID(data[1][xdIdxAttPos], A_XdIndexAttrib_XdIdxId))
                    {
                        break;
                    }

                    xdIndexAttribVector.push_back(data[1][xdIdxAttPos]);

                    this->m_mp.ownerDynStp(data[1][xdIdxAttPos]);
                }
            }
        }
        FREE(data[1]);

        if (rows[2] > 0)
        {
            this->xdPartitionIndexTab = data[2];
            this->xdPartitionIndexNbr = rows[2];
        }
    }
    else
    {
        if (this->m_dictEntityStp->xdIndexMap.empty())
        {
            DBA_DYNFLD_STP* xdIndexTab = nullptr;
            int             xdIndexNbr = 0;
            if ((ret = dbiConnHelper.dbaSelect(XdIndex, UNUSED, admArgStp, A_XdIndex, &xdIndexTab, &xdIndexNbr)) != RET_SUCCEED)
            {
                ddlGenConnGuard.getDbiConn().sendAllMsg();
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Indexes information");
                return(RET_DBA_ERR_NODATA);
            }

            for (int i = 0; i < xdIndexNbr; i++)
            {
                if (GET_ENUM(xdIndexTab[i], A_XdIndex_XdStatusEn) == XdStatus_Inserted ||
                    GET_ENUM(xdIndexTab[i], A_XdIndex_XdStatusEn) == XdStatus_Untreated)
                {
                    SET_ENUM(xdIndexTab[i], A_XdIndex_XdActionEn, XdAction_ToInsert);
                }

                this->m_xdIndexVector.push_back(xdIndexTab[i]);
                this->m_mp.owner(xdIndexTab[i]);
            }
            FREE(xdIndexTab);

            if (this->m_xdIndexVector.empty() == false)
            {
                DBA_DYNFLD_STP* xdIndexAttribTab = nullptr;
                int             xdIndexAttribNbr = 0;
                if ((ret = dbiConnHelper.dbaSelect(XdIndexAttrib, UNUSED, admArgStp, A_XdIndexAttrib, &xdIndexAttribTab, &xdIndexAttribNbr)) != RET_SUCCEED)
                {
                    ddlGenConnGuard.getDbiConn().sendAllMsg();
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Indexes attribute information");
                    return(RET_DBA_ERR_NODATA);
                }

                int         xdIdxAttPos = 0;

                for (auto it = this->m_xdIndexVector.begin(); it != this->m_xdIndexVector.end(); ++it)
                {
                    auto& xdIndexAttribVector = this->m_xdIndexAttribMapVector[*it];

                    for (; xdIdxAttPos < xdIndexAttribNbr; xdIdxAttPos++)
                    {
                        if (GET_ID(*it, A_XdIndex_Id) != GET_ID(xdIndexAttribTab[xdIdxAttPos], A_XdIndexAttrib_XdIdxId))
                        {
                            break;
                        }

                        if (GET_ENUM(xdIndexAttribTab[xdIdxAttPos], A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted ||
                            GET_ENUM(xdIndexAttribTab[xdIdxAttPos], A_XdIndexAttrib_XdStatusEn) == XdStatus_Untreated ||
                            GET_ENUM(xdIndexAttribTab[xdIdxAttPos], A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                        {
                            SET_ENUM(xdIndexAttribTab[xdIdxAttPos], A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                            xdIndexAttribVector.push_back(xdIndexAttribTab[xdIdxAttPos]);
                        }

                        this->m_mp.ownerDynStp(xdIndexAttribTab[xdIdxAttPos]);
                    }
                }
                FREE(xdIndexAttribTab);
            }
        }
        else
        {
            for (auto it = this->m_dictEntityStp->xdIndexMap.begin(); it != this->m_dictEntityStp->xdIndexMap.end(); ++it)
            {
                auto defXdIndexAttribMap = this->m_dictEntityStp->xdIndexAttribMap[it->second];

                if (defXdIndexAttribMap.empty() == false)
                {
                    this->m_xdIndexVector.push_back(it->second);

                    auto& xdIndexAttribVector = this->m_xdIndexAttribMapVector[it->second];

                    for (auto it2 = defXdIndexAttribMap.begin(); it2 != defXdIndexAttribMap.end(); ++it2)
                    {
                        xdIndexAttribVector.push_back((*it2));
                    }
                }
            }
        }
    }

    this->bIsIdxLoaded = true;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity:setExdIndexInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30453 - LJE - 180328
**
*************************************************************************/
void DdlGenEntity::setExdIndexInfo(std::map<ID_T, DBA_DYNFLD_STP> &paramXdIndexMap, std::map<ID_T, std::vector<DBA_DYNFLD_STP>> &paramXdIndexAttribTabMap)
{
    for (auto idxIt = paramXdIndexMap.begin(); idxIt != paramXdIndexMap.end(); ++idxIt)
    {
        this->m_xdIndexVector.push_back(idxIt->second);

        auto &xdIndexAttribVector = this->getXdIndexAttribVector(idxIt->second);
        auto indexAttribMap = paramXdIndexAttribTabMap[GET_ID(idxIt->second, A_XdIndex_Id)];

        for (auto idxAttIt = indexAttribMap.begin(); idxAttIt != indexAttribMap.end(); ++idxAttIt)
        {
            xdIndexAttribVector.push_back((*idxAttIt));
        }
    }

    this->bIsIdxLoaded = true;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::loadExdEntityFromSysInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32145 - LJE - 180730
**
*************************************************************************/
TARGET_TABLE_ENUM DdlGenEntity::getTargetTableEnum(DBA_DYNFLD_STP paramXdAttribStp)
{
    if (GET_FLAG(paramXdAttribStp, A_XdAttrib_CustomFlg) == TRUE)
    {
        return TargetTable_UserDefinedFields;
    }

    if (GET_FLAG(paramXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE)
    {
        return TargetTable_Precomp;
    }

    return TargetTable_Main;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::loadExdEntityFromSysInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120514
**
*************************************************************************/
RET_CODE DdlGenEntity::loadExdEntityFromSysInfo(std::string &realSqlName, bool bForceLoad)
{
    RET_CODE               ret = RET_SUCCEED;

    if ((this->m_ddlGenContext.ddlGenAction.m_installLevel == 99 && this->m_ddlGenContext.migrationMode == DdlGenContext::MigrationMode::None) ||
        this->m_ddlGenContext.ddlGenAction.m_buildRuleEn == DdlGenBuildRule_ForceBuild ||
        this->m_ddlGenContext.ddlGenAction.m_bUseNativeQuery)
    {
        return ret;
    }

    /* PMSTA-58084 - LJE - 240729 */
    if (DdlGenDbi::getTempTableSpec(this->m_ddlGenContext.m_rdbmsEn, this->m_xdEntityStp) != DdlGenDbi::TempTableSpec::None)
    {
        realSqlName = DdlGenDbi::getTempTablePrefix(this->m_ddlGenContext.m_rdbmsEn, this->m_xdEntityStp) + this->m_sqlName;
    }
    std::string                 sqlNameToGet = (realSqlName.empty() ? this->m_sqlName : realSqlName);

    if (this->sysLoadedSqlName.compare(sqlNameToGet) != 0 || bForceLoad)
    {
        DBA_DYNFLD_STP       *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
        int                   rows[] = { 0, 0, 0 };

        FREE_DYNST(this->sysXdEntityStp, A_XdEntity);

        this->sysXdAttribMapMap.clear();

        /* PMSTA-24007 - LJE - 170721 */
        DBA_FreeDynStTab(this->sysXdPartitionTab, this->sysXdPartitionNbr, A_XdPartition);
        this->sysXdPartitionTab = NULL;
        this->sysXdPartitionNbr = 0;

        SET_SYSNAME(this->shXdEntityStp, S_XdEntity_SqlName, sqlNameToGet.c_str());
        if (this->m_xdEntityStp != NULL)
        {
            COPY_DYNFLD(this->shXdEntityStp, S_XdEntity, S_XdEntity_Database, this->m_xdEntityStp, A_XdEntity, A_XdEntity_Database);
        }

        DbiConnection      *dbiConn = nullptr;
        DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);

        dbiConn = &ddlGenConnGuard.getDbiConnForDdl();
        dbiConn->setDbName(this->m_ddlGenContext.getMainDbName());

        DbiConnectionHelper dbiConnHelper(dbiConn);

        if (dbiConnHelper.dbaMultiSelect(XdEntity, DBA_ROLE_UDT, this->shXdEntityStp, data, rows) != RET_SUCCEED)
        {
            ddlGenConnGuard.getDbiConn().sendAllMsg();

            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving System tables information failed");
            return(RET_DBA_ERR_NODATA);
        }

        if (realSqlName.empty() == false)
        {
            SET_SYSNAME(this->shXdEntityStp, S_XdEntity_SqlName, this->m_sqlName.c_str());
        }

        if (rows[0] == 1)
        {
            this->sysXdEntityStp = data[0][0];
            FREE(data[0]);
        }

        if (rows[1] > 0)
        {
            for (int i = 0; i < rows[1]; i++)
            {
                this->sysXdAttribMapMap[this->getTargetTableEnum(data[1][i])].insert(std::make_pair(lower(GET_SYSNAME(data[1][i], A_XdAttrib_SqlName)), data[1][i]));
                this->m_mp.owner(data[1][i]);
            }
            FREE(data[1]);
        }

        /* PMSTA-24007 - LJE - 170721 */
        if (rows[2] > 0)
        {
            this->sysXdPartitionTab = data[2];
            this->sysXdPartitionNbr = rows[2];

            TLS_Sort((char *)this->sysXdPartitionTab,
                     this->sysXdPartitionNbr,
                     sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)DDL_CmpXdPartition,
                     (PTR **)NULL,
                     SortRtnTp_None);
        }

        this->sysLoadedSqlName = sqlNameToGet;
    }

    if (this->sysXdEntityStp == nullptr && this->sysXdAttribMapMap.size() == 0)
    {
        ret = RET_DBA_INFO_NODATA;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::laodExdIndexFromSysInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30453 - LJE - 180328
**
*************************************************************************/
RET_CODE DdlGenEntity::loadExdIndexFromSysInfo(bool bForceLoad)
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->m_ddlGenContext.ddlGenAction.m_buildRuleEn == DdlGenBuildRule_ForceBuild ||
        this->m_ddlGenContext.bGenFromDbi == true ||
        this->m_ddlGenContext.ddlGenAction.m_bUseNativeQuery ||
        (GET_ENUM(this->getXdEntityStp(), A_XdEntity_NatEn) == EntityNat_TempTable && 
         DdlGenDbi::getTempTableSpec(this->m_ddlGenContext.m_rdbmsEn, this->getXdEntityStp()) == DdlGenDbi::TempTableSpec::Session))
    {
        return ret;
    }

    bool            bIsSysIndexLoaded = (this->m_ddlGenDbi.isSysMdFullAccessiblity() ? 
                                         this->m_sysIdxLoadedDbNameSet.empty() == false :
                                         this->m_sysIdxLoadedDbNameSet.find(GET_SYSNAME(this->getXdEntityStp(), A_XdEntity_Database)) != this->m_sysIdxLoadedDbNameSet.end());

    if (bIsSysIndexLoaded && bForceLoad == false)
    {
        return ret;
    }

    MemoryPool            mp;
    DBA_DYNFLD_STP        xdEntityStp = mp.duplicate(FILEINFO, this->getXdEntityStp());

    DbiConnection        *dbiConn = nullptr;
    DdlGenConnGuard     ddlGenConnGuard(this->m_ddlGenContext);

    dbiConn = &ddlGenConnGuard.getDbiConnForDdl();
    DbiConnectionHelper dbiConnHelper(dbiConn);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }
    RequestHelper requestHelper(dbiConnHelper); /* PMSTA-45830 - LJE - 220831 - To keep connection properties */

    if (bForceLoad)
    {
        this->m_sysXdIndexVector.clear();
        this->m_sysXdIndexAttribByRankMapMap.clear();
        this->m_sysXdIdxPartitionVector.clear();
    }

    if (this->m_targetSqlName.empty() == false)
    {
        SET_SYSNAME(xdEntityStp, A_XdEntity_SqlName, this->m_targetSqlName.c_str());
    }

    std::vector<std::string> dbNameVector;

    dbNameVector.push_back(GET_SYSNAME(xdEntityStp, A_XdEntity_Database));

    if (this->m_ddlGenDbi.isSysMdFullAccessiblity() == false &&
        IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompDatabase) == false &&
        strcmp(GET_SYSNAME(xdEntityStp, A_XdEntity_PrecompDatabase), GET_SYSNAME(xdEntityStp, A_XdEntity_Database)) != 0)
    {
        dbNameVector.push_back(GET_SYSNAME(xdEntityStp, A_XdEntity_PrecompDatabase));
    }

    if (IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSqlName) == FALSE &&
        IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompDatabase) == TRUE)
    {
        COPY_DYNFLD(xdEntityStp, A_XdEntity, A_XdEntity_PrecompDatabase, xdEntityStp, A_XdEntity, A_XdEntity_Database);
    }

    for (auto dbName = dbNameVector.begin(); dbName != dbNameVector.end(); ++dbName)
    {
        DBA_DYNFLD_STP* data[] = { NULL, NULL, NULL };
        int            	      rows[] = { 0, 0, 0 };

        if (dbName->empty() == false)
        {
            SET_SYSNAME(xdEntityStp, A_XdEntity_Database, dbName->c_str());
            dbiConnHelper.getConnection()->setDbName(*dbName);
        }

        if ((ret = dbiConnHelper.dbaMultiSelect(XdIndex, DBA_ROLE_UDT, xdEntityStp, data, rows)) != RET_SUCCEED)
        {
            ddlGenConnGuard.getDbiConn().sendAllMsg();
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Indexes information");
            return(RET_DBA_ERR_NODATA);
        }
        this->m_sysIdxLoadedDbNameSet.insert((*dbName));

        for (int i = 0; i < rows[0]; i++)
        {
            DBA_DYNFLD_STP sysXdIndex = data[0][i];

            COPY_DYNFLD(sysXdIndex, A_XdIndex, A_XdIndex_XdEntityId, this->getXdEntityStp(), A_XdEntity, A_XdEntity_Id);

            this->m_sysXdIndexVector.push_back(sysXdIndex);
            this->m_mp.ownerDynStp(sysXdIndex);
        }

        if (this->m_sysXdIndexVector.empty() == false)
        {
            int         xdIdxAttPos = 0;
            SMALLINT_T  rankN = -1;

            for (int i = 0; i < rows[0]; i++)
            {
                DBA_DYNFLD_STP  sysXdIndex                = data[0][i];
                auto           &sysXdIndexAttribByRankMap = this->m_sysXdIndexAttribByRankMapMap[sysXdIndex];

                for (; xdIdxAttPos < rows[1]; xdIdxAttPos++)
                {
                    if (rankN >= GET_SMALLINT(data[1][xdIdxAttPos], A_XdIndexAttrib_Rank))
                    {
                        rankN = -1;
                        break;
                    }

                    if (IS_NULLFLD(data[1][xdIdxAttPos], A_XdIndexAttrib_ColumnExpression) == FALSE)
                    {
                        std::string colExpr = GET_STRING(data[1][xdIdxAttPos], A_XdIndexAttrib_ColumnExpression);

                        if (colExpr.find("AS  ") == 0)
                        {
                            colExpr.erase(0, 4);
                            colExpr.erase(colExpr.length() - 13);
                            SET_STRING(data[1][xdIdxAttPos], A_XdIndexAttrib_ColumnExpression, colExpr.c_str());
                        }

                        if (IS_NULLFLD(data[1][xdIdxAttPos], A_XdIndexAttrib_XdAttribId) == TRUE)
                        {
                            std::string attrExpr;
                            size_t pos = colExpr.find("\"");
                            size_t endPos = std::string::npos;

                            if (pos != std::string::npos)
                            {
                                endPos = colExpr.find("\"", ++pos);
                                if (endPos != std::string::npos)
                                {
                                    attrExpr = lower(colExpr.substr(pos, endPos - pos));
                                }
                            }

                            if (attrExpr.empty() == false)
                            {
                                DBA_DYNFLD_STP xdAttribStp = this->getXdAttribBySqlName(attrExpr);
                                if (xdAttribStp)
                                {
                                    SET_ID(data[1][xdIdxAttPos], A_XdIndexAttrib_XdAttribId, GET_ID(xdAttribStp, A_XdAttrib_Id));

                                    if (pos == 1 && endPos == colExpr.length() - 1)
                                    {
                                        SET_SYSNAME(data[1][xdIdxAttPos], A_XdIndexAttrib_XdAttribSqlName, GET_SYSNAME(xdAttribStp, A_XdAttrib_SqlName));
                                        SET_NULL_STRING(data[1][xdIdxAttPos], A_XdIndexAttrib_ColumnExpression);
                                    }
                                }
                            }
                        }
                    }

                    rankN = GET_SMALLINT(data[1][xdIdxAttPos], A_XdIndexAttrib_Rank);
                    sysXdIndexAttribByRankMap[rankN] = data[1][xdIdxAttPos];

                    this->m_mp.ownerDynStp(data[1][xdIdxAttPos]);
                }
            }
        }

        for (int i = 0; i < rows[2]; i++)
        {
            this->m_sysXdIdxPartitionVector.push_back(data[2][i]);
            this->m_mp.ownerDynStp(data[2][i]);
        }

        FREE(data[0]);
        FREE(data[1]);
        FREE(data[2]);
    }
    dbiConnHelper.getConnection()->setDbName(std::string());

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenEntity::getXdEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14086 - LJE - 121005
**
*************************************************************************/
ID_T DdlGenEntity::getXdEntityId(OBJECT_ENUM paramObjectEn)
{
    DICT_ENTITY_STP locDictEntityStp;

    locDictEntityStp = DBA_GetDictEntitySt(paramObjectEn);

    if (locDictEntityStp != NULL)
    {
        return locDictEntityStp->xdEntityId;
    }
    else
    {
        return 0;
    }
}


/************************************************************************
**
**  Function    :   DdlGenEntity::fixTemplateAttributeId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29879 - LJE - 180207
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenEntity::fixTemplateAttributeId(DBA_DYNFLD_STP xdObjectStp, FIELD_IDX_T lnkAttribIdx)
{
    DBA_DYNFLD_STP locAttribStp = nullptr;

    /* PMSTA-29879 - LJE - 180207 - Fix attribute id when the attributes reference dict_attribute_template */
    if (IS_NULLFLD(xdObjectStp, lnkAttribIdx) == FALSE &&
        (locAttribStp = this->getXdAttribById(GET_ID(xdObjectStp, lnkAttribIdx))) == nullptr)
    {
        DdlGenEntity *tplDdlGenEntityPtr = this->m_ddlGenContext.getTemplateDdlGenEntityPtr();

        if (tplDdlGenEntityPtr == nullptr)
        {
            return nullptr;
        }

        DBA_DYNFLD_STP lnkAttribStp = tplDdlGenEntityPtr->getXdAttribById(GET_ID(xdObjectStp, lnkAttribIdx));
        if (lnkAttribStp)
        {
            if ((locAttribStp = this->getXdAttribBySqlName(GET_SYSNAME(lnkAttribStp, A_XdAttrib_SqlName))) != nullptr)
            {
                SET_ID(xdObjectStp, lnkAttribIdx, GET_ID(locAttribStp, A_XdAttrib_Id));
            }
            else
            {
                SET_NULL_ID(xdObjectStp, lnkAttribIdx);
            }
        }
    }

    return locAttribStp;
}


/************************************************************************
**
**  Function    :   DdlGenEntity::setStatistics()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211011
**
*************************************************************************/
void DdlGenEntity::setStatistics(TARGET_TABLE_ENUM targetTableEn, DdlGenContext *ddlGenContextPtr)
{
    DICT_ENTITY_STP targetDictEntityStp = this->getDictEntityStp();

    auto& statistics = this->m_statisticsMap[targetTableEn];

    if (targetDictEntityStp->entNatEn == EntityNat_ReportFmt ||
        targetDictEntityStp->entNatEn == EntityNat_SearchFmt ||
        targetDictEntityStp->entNatEn == EntityNat_PersistedFmt ||
        targetDictEntityStp->entNatEn == EntityNat_TempTable)
    {
        statistics.m_targetTotRows = 0;
        statistics.m_sourceTotRows = 0;
        statistics.m_statisticInfo = "Skipped due to the entity nature";
        return;
    }

    if (targetDictEntityStp->dbRuleEn == DbRule_NotInDatabase)
    {
        statistics.m_targetTotRows = 0;
        statistics.m_sourceTotRows = 0;
        statistics.m_statisticInfo = "Not in database";
        return;
    }

    if (targetDictEntityStp->logicalFlg == TRUE)
    {
        statistics.m_targetTotRows = 0;
        statistics.m_sourceTotRows = 0;
        statistics.m_statisticInfo = "Logical";
        return;
    }

    DdlGenDbiPtr ddlGenDbi(new DdlGenDbi(DdlObj_None, *ddlGenContextPtr, nullptr, nullptr, TargetTable_Undefined));

    if (statistics.m_targetTotRows < 0 && targetDictEntityStp != nullptr)
    {
        std::map<DdlObjDefKey, DdlObjDef>    ddlObjDefMap;
        ddlGenDbi->getAllDdlObjListFromDb(ddlObjDefMap, 
                                          targetDictEntityStp->databaseName, 
                                          targetDictEntityStp->dbSqlName,
                                          targetDictEntityStp->dbSqlName, 
                                          DdlObj_Table);
        if (ddlObjDefMap.empty() == false)
        {
            ddlGenDbi->getCountRecord(targetDictEntityStp, std::string(), std::string(), statistics.m_targetTotRows, false);
        }
        else
        {
            statistics.m_targetTotRows = 0;
        }
    }

    if (EV_UseAlternativeDataSource && statistics.m_sourceTotRows < 0)
    {
        DICT_ENTITY_STP sourceDictEntityStp = DBA_GetEntityBySqlName(targetDictEntityStp->mdSqlName, true, true);

        if (sourceDictEntityStp == nullptr && EV_SourceCfgFile != nullptr)
        {
            CFG_OBJECT_SECTION* cfgObjSectionStp = EV_SourceCfgFile->getCfgObjectSectonStp(targetDictEntityStp);

            if (cfgObjSectionStp != nullptr)
            {
                auto dbIter = EV_SourceCfgFile->dbSectionMap.find(cfgObjSectionStp->dbFct);
                if (dbIter != EV_SourceCfgFile->dbSectionMap.end())
                {
                    if (this->m_ddlGenContext.m_parentContext->tablesFromSrcSysMap[dbIter->second.dbSqlName].find(targetDictEntityStp->dbSqlName) !=
                        this->m_ddlGenContext.m_parentContext->tablesFromSrcSysMap[dbIter->second.dbSqlName].end())
                    {
                        DdlGen localDdlGen(targetDictEntityStp->objectEn, DdlObj_Sql, this->m_ddlGenContext, nullptr, this, nullptr, TargetTable_Main);
                        sourceDictEntityStp = localDdlGen.getDictEntityStp(true);
                    }
                }
            }
        }

        if (sourceDictEntityStp != nullptr)
        {
            if (sourceDictEntityStp->dbRuleEn != targetDictEntityStp->dbRuleEn)
            {
                sourceDictEntityStp->dbRuleEn = targetDictEntityStp->dbRuleEn;
            }

            ddlGenDbi->getCountRecord(sourceDictEntityStp, std::string(), std::string(), statistics.m_sourceTotRows, true);

            statistics.m_transfertSize = static_cast<size_t>(sourceDictEntityStp->attribMap.size() - sourceDictEntityStp->logicalTab.size());

            if (targetTableEn == TargetTable_Main)
            {
                for (auto it = sourceDictEntityStp->attribMap.begin(); it != sourceDictEntityStp->attribMap.end(); ++it)
                {
                    if (it->second->logicalFlg == FALSE &&
                        (it->second->custFlg == TRUE || it->second->precompFlg == TRUE))
                    {
                        statistics.m_transfertSize--;
                    }
                }
            }
            else if (targetTableEn == TargetTable_UserDefinedFields)
            {
                for (auto it = sourceDictEntityStp->attribMap.begin(); it != sourceDictEntityStp->attribMap.end(); ++it)
                {
                    if (it->second->logicalFlg == FALSE &&
                        (it->second->custFlg == FALSE || it->second->precompFlg == TRUE))
                    {
                        statistics.m_transfertSize--;
                    }
                }
            }
            statistics.m_transfertSize *= statistics.m_sourceTotRows;
        }
        else
        {
            statistics.m_statisticInfo = "Don't exist in the source environment";
            statistics.m_sourceTotRows = 0;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenEntity::setDdlGenActionInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45830 - LJE - 220404
**
*************************************************************************/
void DdlGenEntity::setDdlGenActionInfo(const DdlGenAction& ddlGenAction)
{
    this->m_ddlGenContext.ddlGenAction.m_installLevel  = ddlGenAction.m_installLevel;
    this->m_ddlGenContext.ddlGenAction.m_bSingleEntity = ddlGenAction.m_bSingleEntity;
}

/*************************************************************************
**   END  ddlgendbaccess.cpp                                        Odyssey **
*************************************************************************/


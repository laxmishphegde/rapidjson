
/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**

**                     Portfolio Management System
**
*************************************************************************/

#ifndef DESCDYN_C
#define DESCDYN_C

/* Disable messages 10 19 129 750 031008 - PMO */
/*lint -save -e(10) -e(19) -e(129) -e(750) */

        /* Reserved -1 value for NullEntity */
OBJECT_ENUM      NullEntity=-1;

OBJECT_ENUM      InvalidEntity=0;       /* REF9789 - LJE - 031230 */

 /* Infrastructure */
OBJECT_ENUM      Curr;                  /* 101 currency                    */
OBJECT_ENUM      Sect;                  /* 103 sector                      */
OBJECT_ENUM      Rating;                /* 104 rating                      */
OBJECT_ENUM      Calendar;              /* 106 calendar                    */
OBJECT_ENUM      Notepad;               /* 107 notepad                     */
OBJECT_ENUM      TabModifStat;          /* 109 tab_modif_stat              */
OBJECT_ENUM      CurrChrono;            /* 110 curr_chrono                 */
OBJECT_ENUM      CurrModif;             /* 111 curr_modif                 */ /* DVP009 960304 DED */
OBJECT_ENUM      ClientConnect;         /* 112 client_connection           */ /* DVP062 960520 RAK */
OBJECT_ENUM      CalendarConv;          /* 113 calendar_conv               */ /* DVP496 970818 DED */
OBJECT_ENUM      CalendarDate;          /* 114 calendar_date               */ /* DVP496 970606 RAK */
OBJECT_ENUM      CurrFreq;              /* 115 currency_freq               */ /* REF4306 - RAK - 000201 */
OBJECT_ENUM      Archive;               /* 116 archive                     */ /* REF4306 - RAK - 000201 */
OBJECT_ENUM      QuickSearch;           /* 117 quick_earch                 */ /* REF4497 - SKE - 000331 */
OBJECT_ENUM      One;                   /* 119 One                         */ /* MIGR R4.00 STEP6 - LJE - 020815 */
OBJECT_ENUM      Empty;                 /* 120 Empty                       */ /* REF7758-BRO-020911 */
OBJECT_ENUM      OptiProf;              /* 122 opti_profile                */ /* REF11767 - CHU - 060331 */
OBJECT_ENUM      OptiProfCompo;         /* 123 opti_prof_compo             */ /* REF11767 - CHU - 060331 */
OBJECT_ENUM      OptiProc;              /* 124 opti_proc                   */ /* REF11767 - LJE - 060418 */
OBJECT_ENUM      ApplComment;           /* 125 appl_comment                */ /*PMSTA10733-TEB-101130*/
OBJECT_ENUM      Boottime;              /* 128 boot_time                   */ /*PMSTA-16365 - 140509 */


 /* Multilingual and synonyms */
OBJECT_ENUM      Denom;                 /* 200 denomination                */
OBJECT_ENUM      ApplMsg;               /* 203 appl_message                */ /* DVP019 960320 RAK */
OBJECT_ENUM      ApplMsgTxt;            /* 204 appl_msg_text               */ /* DVP019 960320 RAK */
OBJECT_ENUM      WarningMsgEnt;         /* 205 warning_message             */ /*REF7768*/ /* MIGR R4.00 STEP6 - LJE - 020816 */
OBJECT_ENUM      RequestCode;           /* 206 request_code                */ /*REF10604-BRO-040922*/

 /* Security */
OBJECT_ENUM      DataSecuProf;          /* 301 data_secu_prof              */
OBJECT_ENUM      FctSecuProf;           /* 302 func_secu_prof              */
OBJECT_ENUM      FctSecuProfCompo;      /* 303 func_secu_prof_compo       */ /* DVP250 - 961113 - DED */
OBJECT_ENUM     ScreenProf;            /* 305 screen_profile              */ /* DVP338 - 970204 - RAK */
OBJECT_ENUM     ScreenProfCompo;       /* 306 screen_prof_compo           */ /* DVP338 - 970204 - RAK */
OBJECT_ENUM     Printer;               /* 307 printer                     */ /* DVP350 - 970225 - PEC */
OBJECT_ENUM     PrinterProf;           /* 308 printer_prof                */ /* DVP350 - 970225 - PEC */
OBJECT_ENUM     PrinterProfCompo;      /* 309 printer_prof_compo          */ /* DVP350 - 970225 - PEC */
OBJECT_ENUM     ApplPswdHist;          /* 310 appl_password_history       */ /* 3.50 MODIF - RAK - 991124 */
OBJECT_ENUM     LoginFailed;           /* 312 login_failed                */ /* 3.50 MODIF - RAK - 991124 */
OBJECT_ENUM     DataProf;              /* 313 data_profile                */ /* 3.51 REF5562 SKE 010119 */
OBJECT_ENUM     DataProfCompo;         /* 314 data_prof_compo             */ /* 3.51 REF5562 SKE 010119 */
OBJECT_ENUM     SearchCrit;            /* 315 search_criteria             */    /*  FIH-REF9789-031222  */
OBJECT_ENUM     SearchCritCompo;       /* 316 search_criteria_compo       */    /*  FIH-REF9789-031222  */
OBJECT_ENUM     SearchProf;            /* 317 search_profile              */    /*  FIH-REF9789-031222  */
OBJECT_ENUM     SearchProfCompo;       /* 318 search_profile_compo        */    /*  FIH-REF9789-031222  */
OBJECT_ENUM     SelSearchCritCompoArg; /* 319 sel_search_criteria_compo_param   */    /* PMSTA-15655 - LJE - 130121 */
OBJECT_ENUM     SelFctSecuProfCompoArg;/* 320 sel_fct_secu_prof_compo_param     */  /*  HFI-PMSTA-35838-190515  */

/* Multi channel */
OBJECT_ENUM      ApplChannelProf;       /* 331 appl_channel_profile         */  /* PMSTA-22551 - EFE - 20160323 */
OBJECT_ENUM      ApplChannelProfCompo;  /* 332 appl_channel_profile_compo   */  /* PMSTA-22551 - EFE - 20160323 */


 /* List */
/*OBJECT_ENUM      List;            */      /* 400 list                        */
OBJECT_ENUM      ListCompo;             /* 401 list_compo                  */
OBJECT_ENUM      Classif;               /* 402 classification              */
OBJECT_ENUM      ClassifCompo;          /* 403 classif_compo               */
OBJECT_ENUM      MktSegt;               /* 404 market_segment              */
OBJECT_ENUM      Grid;                  /* 405 grid                        */
OBJECT_ENUM     CheckList;             /* 407 check_list                  */
OBJECT_ENUM     ReturnGridLnk;         /* 408 return_grid_link            */ /* DVP252 - 961115 - DED */
OBJECT_ENUM     ListChrono;            /* 409 list_chrono                 */ /* REF7292-BRO-020118 */
OBJECT_ENUM      MktStruct;             /* 410 market_structure            */ /* REF MODIF BD - RAK - 020501 */
OBJECT_ENUM      MktSSubSet;            /* 411 market_structure_subset     */ /* REF MODIF BD - RAK - 020501 */

 /* Investment guidelines */
OBJECT_ENUM     StratElt;              /* 501 strategy_element                 */
OBJECT_ENUM     StratLnk;              /* 502 strategy_link                    */
OBJECT_ENUM     StratHist;             /* 503 strategy_history                 */
OBJECT_ENUM     EStratLnk;             /* 505 ext. strategy link                */
OBJECT_ENUM     EStratElt;             /* 506 ext. strategy element             */
OBJECT_ENUM     StratEltDetail;        /* 507 strategy element detail (logical) */
OBJECT_ENUM     FctResult;             /* 508 function result                   */ /* DVP056 - RAK - 960520 */
OBJECT_ENUM     BenchWeight;           /* 509 strategy weight                   */ /* DVP475 - GRD - 970526 */
OBJECT_ENUM     ModelConstrElt;        /* 511 model_constr_elt                  */ /* RAK - 010606 */
OBJECT_ENUM     DerivedStrat;          /* 512 derived_strategy                  */ /* RAK - 010606 */
OBJECT_ENUM     DerivedStratElt;       /* 513 derived_strag_elt                 */ /* RAK - 010606 */
OBJECT_ENUM     ConstrTemplate;        /* 515 constraint template               */ /* REF7289-BRO-020129*/
OBJECT_ENUM     TemplateElt;           /* 516 template element                  */ /* REF7289-BRO-020129*/
OBJECT_ENUM     ConstraintParameter;   /* 517 constraint parameter              */ /* REF7289-BRO-020129*/
OBJECT_ENUM     StratCompo;            /* 518 strategy compo                    */ /* REF MODIF BD - RAK - 020501 */
OBJECT_ENUM     ConstraintBreach;      /* 519 constraint_breach                 */ /*REF7768*/ /* MIGR R4.00 STEP6 - LJE - 020816 */
OBJECT_ENUM     ComplianceChrono;      /* 520 compliance chrono                */ /*PMSTA5345 - EFE -080215*/
OBJECT_ENUM     CaseClarification;     /* 522 case clarification               */ /*PMSTA07121-CHU-081008*/
OBJECT_ENUM     CaseLink;              /* 523 case linked object(s)            */ /*PMSTA07121-CHU-081008*/
OBJECT_ENUM     CaseMsgTemplate;       /* 524 case message template            */ /*PMSTA07121-CHU-081014*/
OBJECT_ENUM     CaseMsgTemplateDef;    /* 525 case message template definition */ /*PMSTA07121-DDV-081212*/
OBJECT_ENUM     StratSynth;            /* 526 strategy_synthetic               */ /* PMSTA08737 - LJE - 091109 */
OBJECT_ENUM	    VarStratElt;           /* 527 variable strategy element        */ /* PMSTA08747-CHU-091112 */
OBJECT_ENUM	    RiskESElt;             /* 528 risk extended strategy element    */ /* PMSTA-18426 - CHU - 140922 */
OBJECT_ENUM	    RiskESEltCompo;        /* 530 risk extended strategy elt compo  */ /* PMSTA-18426 - CHU - 141014 */
OBJECT_ENUM	    RiskValueEltCompo;     /* 531 risk value element compo          */ /* PMSTA-18426 - CHU - 141014 */
OBJECT_ENUM		CaseRule;	           /* 532 case_rule			                */ /* PMSTA- 18760 -cashwini-140205 */
OBJECT_ENUM     LombardCheck;          /* 533 lombard_check                     */ /* PMSTA-21045 - cashwini--150818 */

 /* Third parties */
OBJECT_ENUM      SectAttr;              /* 603 sector_attrib               */
OBJECT_ENUM      RatingAttr;            /* 604 rating_attrib               */
OBJECT_ENUM      ThirdFreq;             /* 605 third_freq                  */ /* REF4306 - RAK - 000201 */
OBJECT_ENUM      BusEntity;             /* 606 business_entity             */ /* PMSTA-17089 - DDV - 131106 */
OBJECT_ENUM      BusOrga;               /* 607 business_orga               */ /* PMSTA-17089 - DDV - 131106 */
OBJECT_ENUM      BusEntityPtfCompo;     /* 608 bus_entity_ptf_compo        */ /* PMSTA-17089 - DDV - 131106 */
OBJECT_ENUM      BusEntityInstrCompo;   /* 609 bus_entity_instr_compo      */ /* PMSTA-17089 - DDV - 131106 */
OBJECT_ENUM      BusEntityThirdCompo;   /* 610 bus_entity_third_compo      */ /* PMSTA-17089 - DDV - 131106 */
OBJECT_ENUM      BusEntityAddr;         /* 612 bus_entity_address          */ /* PMSTA-17089 - DDV - 131203 */

 /* Quotation infrastructure */
OBJECT_ENUM      InstrPrice;            /* 700 instr_price                 */
OBJECT_ENUM      ExchRate;              /* 701 exch_rate                   */
OBJECT_ENUM      ExchFmt;               /* 702 exch_format                 */
OBJECT_ENUM      Scena;                 /* 703 scenario                    */
OBJECT_ENUM      ScenaCompo;            /* 704 scenario_compo              */
OBJECT_ENUM      ScenaElt;              /* 705 scenario_element            */
OBJECT_ENUM     Stat;                  /* 706 statistics                  */
OBJECT_ENUM     Regr;                  /* 707 regression                  */
OBJECT_ENUM      RiskRatio;             /* 708 risk_ratio                  */ /* REF8705 - LJE - 030123 */

 /* Portfolios */
OBJECT_ENUM      PtfChrono;             /* 801 port_chrono                 */
OBJECT_ENUM      PayInstruct;           /* 802 payment_instruction         */
OBJECT_ENUM      Mgr;                   /* 803 manager                     */
OBJECT_ENUM      PtfPosSet;             /* 804 port_pos_set                */
OBJECT_ENUM      BalPosRule;            /* 805 bal_pos_rule                */
OBJECT_ENUM      BalPosRuleSet;         /* 806 bal_pos_rule_set            */
OBJECT_ENUM      AccPerParam;           /* 807 acc_period_param            */ /* DVP002 960229 RAK */
OBJECT_ENUM      AdminMgr;              /* 808 admin_manager               */
OBJECT_ENUM      CommMgr;               /* 809 comm_manager                */
OBJECT_ENUM      PtfSynth;              /* 810 port_synthetic              */
OBJECT_ENUM      PtfFusionEnt;          /* 811 port_fusion (logical)          */
OBJECT_ENUM      AccPer;                /* 813 acc_period                  */ /* DVP002 960229 RAK */
OBJECT_ENUM      AccPlanElt;            /* 814 acc_plan_element               */ /* DVP002 960229 RAK */
OBJECT_ENUM      FundVal;               /* 815 fund_valuation             */ /* DVP037 960426 DED */
OBJECT_ENUM      FundValElt;            /* 816 fund_valuation_element      */ /* DVP037 960426 DED */
OBJECT_ENUM      AccPlan;               /* 817 acc_plan                    */ /* DVP339 970206 RAK */
OBJECT_ENUM      FTConv;                /* 818 ft_convention               */ /* REF847 980107 DED */
OBJECT_ENUM      FTRateHist;            /* 819 ft_rate_history             */ /* REF847 980107 DED */
OBJECT_ENUM      FTRate;                /* 820 ft_rate                     */ /* REF847 980107 DED */
OBJECT_ENUM      PtfFreq;               /* 821 portfolio_freq              */ /* REF4306 - RAK - 000201 */
OBJECT_ENUM      PerfAttrib;            /* 824 perf_attrib                 */ /* REF7421 - LJE - 020711 */
OBJECT_ENUM      StandardPerf;          /* 825 standard_perf               */ /* REF7421 - LJE - 020711 */
OBJECT_ENUM      ExtRetAnalysis;        /* 826 ext_ret_analysis (logical)  */ /* REF7421 - LJE - 020711 */
OBJECT_ENUM      PerfAttribData;        /* 828 perf_attrib_data            */ /* REF8798 - YST - 030310 */
OBJECT_ENUM      RetAnaDetailed;        /* 829 ret_analysis_detailed       */ /* REF8798 - YST - 030310 */
OBJECT_ENUM      RetAnaGlobal;          /* 830 ret_analysis_global         */ /* REF8798 - YST - 030310 */
OBJECT_ENUM      RetAnalysisId;         /* 831 ret_analysis_id             */ /* REF8798 - YST - 030310 */
OBJECT_ENUM      StdPerfData;           /* 832 standard_perf_data          */ /* REF8798 - YST - 030310 */
OBJECT_ENUM      PSPPositionData;       /* 833 psp_position_data           */ /* REF9125 - LJE - 030812 */
OBJECT_ENUM      PerfAttribId;          /* 834 perf_attrib_id              */ /* REF9924 - LJE - 040213 */
OBJECT_ENUM		 AccProfileHisto;       /* 835 acc_profile_histo           */ /* PMSTA00488 - EFE - 061101 */
OBJECT_ENUM		 AccProfile;            /* 836 acc_profile                 */ /* PMSTA00488 - EFE - 061101 */
OBJECT_ENUM		 AccProfileCompo;       /* 837 acc_profile_compo           */ /* PMSTA00488 - EFE - 061101 */
OBJECT_ENUM      StandInstruct;         /* 838 standing_instruction        */ /*PMSTA06761-BRO-080704*/
OBJECT_ENUM      PerfEffectDef;         /* 839 perf_effect_def             */ /* PMSTA08736 - LJE - 100115 */
OBJECT_ENUM      PerfEffectLink;        /* 840 perf_effect_link            */ /* PMSTA08736 - LJE - 100115 */
OBJECT_ENUM      PerfCurrencyContrib;   /* 841 perf_currency_contrib       */ /* PMSTA08736 - LJE - 100115 */
OBJECT_ENUM      PerfInterBench;        /* 842 perf_inter_bench            */ /* PMSTA08736 - LJE - 100115 */
OBJECT_ENUM      ExtOrderBlockId;       /* 843 ext_order_alloc_block_id    */ /* PMSTA-46001 - AAKASH - 161221*/



 /* Financial instruments */
OBJECT_ENUM      IssueEvt;              /* 903 iss_redm_event              */
OBJECT_ENUM      EvtExcl;               /* 905 event_excl                  */

OBJECT_ENUM      InstrChrono;           /* 908 instr_chrono                */
OBJECT_ENUM      FundWgt;               /* 909 fund_weight                 */
OBJECT_ENUM      Guarantee;             /* 910 guarantee                   */
OBJECT_ENUM      UInter;                /* 911 unitary interest (logical)  */
OBJECT_ENUM      Ytm;                   /* 912 yield to maturity (logical) */
OBJECT_ENUM      InstrFlow;             /* 913 instrument flow (logical)   */
OBJECT_ENUM      CompInstrChrono;       /* 914 compute_instr_chrono (log.) */ /* DVP264 - 961122 - DED        */
OBJECT_ENUM      AdvA;                  /* 915 advanced_analytics (log.)   */ /* REF1055 - 981016 - RAK       */
OBJECT_ENUM      InstrFreq;             /* 916 instrument_freq             */ /* REF4306 - RAK - 000201       */
OBJECT_ENUM      DataDesc;              /* 917 data_desc (logical)         */ /* 3.50 db modif - RAK - 000303 */
OBJECT_ENUM      DataDisp;              /* 918 data_disp (logical)         */ /* 3.50 db modif - RAK - 000303 */
OBJECT_ENUM      TradingPlace;          /* 919 trading_place               */ /* REF7296-BRO-020129           */
OBJECT_ENUM     TradingCurrency;        /* 920 trading_currency            */ /* REF7296-BRO-020129           */
OBJECT_ENUM     CorporateAction;        /* 921 Corporate action            */ /* REF10603-EFE-041018          */
OBJECT_ENUM		InstrDeposit;			/* 923 instr_deposit               */ /*REF11718-BRO-060301*/
OBJECT_ENUM      InstrRiskOrig;         /* 924 instr_risk_orig             */ /* PMSTA-18096 - LJE - 140620 */
OBJECT_ENUM      CompComplChrono;       /* 925 compute_compl_chrono (log.) */ /* PMSTA-18426 - CHU - 141004   */
OBJECT_ENUM      ComplianceChronoFreq;  /* 926 compliance chrono freq      */ /* PMSTA-22458 - cashwini - 04062016*/
OBJECT_ENUM      PlanRule;				/* 843 plan_rule				   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM      PlanRuleHisto;			/* 844 plan_rule_histo			   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM      PlanDefinition;		/* 845 plan_definition			   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM		 PlanObjectiveHisto;    /* 846 plan_objective_histo		   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM      PlanInvestParamHisto;	/* 847 plan_invest_param_histo	   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM		 PlanInvestDate;		/* 848 plan_invest_date			   */ /* PMSTA-21268 - SHR - 092115 */
OBJECT_ENUM		 FreeDepositHisto;		/* 849 free_deposit_histo		   */ /* PMSTA-21268 - SHR - 092115 */

 /* Positions and transactions */
OBJECT_ENUM      Pos;                   /* 1000 position                   */
OBJECT_ENUM      BalPos;                /* 1001 balance_pos                */
OBJECT_ENUM      BalPosTp;              /* 1002 balance_pos_type           */
OBJECT_ENUM      Op;                    /* 1004 operation                  */
OBJECT_ENUM     OpCompo;               /* 1006 oper_compo                 */
OBJECT_ENUM     EPos;                  /* 1007 extended_position  (logical)   */
OBJECT_ENUM     PVal;                  /* 1008 position_valuation             */
OBJECT_ENUM     OpDomainEnt;           /* 1009 op_domain (logical)            */
OBJECT_ENUM     BuyOpEnt;              /* 1010 buy_operation (logical)        */
OBJECT_ENUM     SellOpEnt;             /* 1011 sell_operation (logical)       */
OBJECT_ENUM     InvestOpEnt;           /* 1012 invest_operation (logical)     */
OBJECT_ENUM     WithdrOpEnt;           /* 1013 withdr_operation (logical)     */
OBJECT_ENUM     IncOpEnt;              /* 1014 income_operation (logical)     */
OBJECT_ENUM     ShareIssOpEnt;         /* 1015 share_iss_operation (logical)  */
OBJECT_ENUM     ShareRedmOpEnt;        /* 1016 share_redm_operation (logical) */
OBJECT_ENUM     TransfOpEnt;           /* 1017 transf_operation (logical)     */
OBJECT_ENUM     BpTransfOpEnt;         /* 1018 bp_transf_operation (logical)  */
OBJECT_ENUM     AdjustOpEnt;           /* 1019 adjust_operation (logical)     */
OBJECT_ENUM     FtOpEnt;               /* 1020 ft_operation (logical)         */
OBJECT_ENUM     DocIndex;              /* 1021 document_index                 */
OBJECT_ENUM     EOp;                   /* 1022 ext_operation                  */
OBJECT_ENUM     ShareOpInfo;           /* 1023 share_operation_info           */
OBJECT_ENUM     LockOpEnt;             /* 1024 lock_operation (logical)       */ /* DVP183 - 960826 - DED */
OBJECT_ENUM     PtfTransfOpEnt;        /* 1025 ptf_transf_operation (logical) */ /* DVP355 - 970303 - PEC */
OBJECT_ENUM     BookAdjOpEnt;          /* 1026 book_adj_operation (logical)   */ /* DVP355 - 970303 - PEC */
OBJECT_ENUM     PosValHist;            /* 1027 pos_val_hist                   */ /* DVP390 - 970317 - PEC */
OBJECT_ENUM     BookValue;             /* 1028 book_value                     */ /* DVP430 - 970318 - XDI */
OBJECT_ENUM     InitOpEnt;             /* 1029 init_operation                 */ /* REF4306 - RAK - 000201 */
OBJECT_ENUM     ExecutionEnt;          /* 1030 Execution                      */ /* DLA - REF7560 - 020516 */
OBJECT_ENUM     GlExecFeeEnt;          /* 1031 global_execution_fee           */ /* DLA - REF7560 - 020516 */
OBJECT_ENUM     ExtExecutionEnt;       /* 1032 ext_execution                  */ /* DLA - REF7560 - 020516 */
OBJECT_ENUM     ExtOrder;              /* 1033 ext_order                      */ /* DLA - REF7560 - 020614 */ /* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
OBJECT_ENUM     UnMatchedExecution;    /* 1034 unmatchedExecution             */ /* REF9764 - CHU - 031222 */
OBJECT_ENUM     ExtTransaction;        /* 1035 ext_transaction                */ /* REF9764 - LJE - 040106 */
OBJECT_ENUM     UnMatchedGlExecFee;    /* 1036 unmatched_global_exec_fee      */ /*REF10025-BRO-040401*/
OBJECT_ENUM		Communication;         /* 1037 communication                  */ /*REF11810-BRO-060609*/
OBJECT_ENUM		CombinedOpEnt;         /* 1038 combined_operation (logical)   */ /*PMSTA06760-BRO-080701*/
OBJECT_ENUM		CompoundOrderRule;	   /* 1039 compound_order_rule			  */ /*PMSTA- 18634 - SHR - 140904 */
OBJECT_ENUM		CompoundOrderMasterElt;/* 1040 compound_order_master_elt	  */ /*PMSTA- 18634 - SHR - 140904 */
OBJECT_ENUM		CompoundOrderSlaveElt; /* 1041 compound_order_slave_elt		  */ /*PMSTA- 18634 - SHR - 140904 */
OBJECT_ENUM		ETaxLot;               /* 1044 Extended Tax Lot (logical)	  */ /*PMSTA- 31342 - SANAND - 180515 */

 /* Meta dictionary */
OBJECT_ENUM      DictUser;              /* 1099 dict_user                  */
OBJECT_ENUM      DictDataTp;            /* 1100 dict_datatype              */
OBJECT_ENUM      DictCriter;            /* 1102 dict_criteria              */
OBJECT_ENUM      DictLabel;             /* 1104 dict_label                 */
OBJECT_ENUM      DictLang;              /* 1106 dict_language              */
OBJECT_ENUM     DictPanel;             /* 1108 dict_panel                 */ /* DVP200+ - 961101 - DED */
OBJECT_ENUM     DictScreen;            /* 1109 dict_screen                */ /* DVP200+ - 970122 - DED */
OBJECT_ENUM     DictView;              /* 1112 dict_view                  */ /* PMSTA-11999 - RPO - 110504 */
OBJECT_ENUM      DictDatabase;          /* 1113 dict_database              */ /* PMSTA-13109 - LJE - 111123 */
OBJECT_ENUM      DictSegment;           /* 1114 dict_segment               */ /* PMSTA-13109 - LJE - 111123 */
OBJECT_ENUM      DictFctAttrib;         /* 1115 dict_function_attribute    */ /* PMSTA-13244 - DDV - 120119 */

OBJECT_ENUM      EntityComment;         /* 1150 entity_comment             */ /* PMSTA11809-PRS-110428 */
OBJECT_ENUM      AttributeComment;      /* 1151 attribute_comment          */ /* PMSTA11809-PRS-110428 */
OBJECT_ENUM      PermValComment;        /* 1152 perm_value_comment         */ /* PMSTA11809-PRS-110428 */
OBJECT_ENUM      ApplParamComment;      /* 1153 appl_param_comment         */ /* PMSTA11809-PRS-110428 */

 /* Domain */
OBJECT_ENUM     Domain;                /* 1200 domain                     */
OBJECT_ENUM     FmtProf;               /* 1204 format profile             */
OBJECT_ENUM     FmtProfCompo;          /* 1205 format profile composition */
OBJECT_ENUM     Doc;                   /* 1206 document                   */
OBJECT_ENUM     Folder;                /* 1207 folder                     */
OBJECT_ENUM     PrintParam;            /* 1208 print_param                */ /* DVP068 - 980818 - OCE renamed from report_param */
OBJECT_ENUM     Report;                /* 1209 report                     */
OBJECT_ENUM     ReportProf;            /* 1210 report_profile             */
OBJECT_ENUM     ReportProfCompo;       /* 1211 report_prof_compo          */
OBJECT_ENUM     TabCnt;                /* 1212 table_content              */ /* SQL044 - 960403 - RAK */
OBJECT_ENUM     ReportGen;             /* 1213 report_generation (logical)*/ /* DVP062 - 960520 - RAK */
OBJECT_ENUM     ReportParam;           /* 1214 report_param               */ /* DVP068 - 980818 - OCE */
OBJECT_ENUM     DataSetDef;            /* 1215 data_set_def               */ /*PMSTA01389-BRO-070314*/
OBJECT_ENUM     ExportCtxArgEntity;	   /* 1216 export_ctx_arg			  */ /* OCS42034-JPP-20121115 */

 /* External Service */
OBJECT_ENUM      ExtServiceCompo;      /* 1222 extrenal_service_compo     */ /*PMSTA-18426-CHU-140922*/

OBJECT_ENUM     DomainPtfCompo;        /* 1228 domain_portfolio_com         - PMSTA-21105 - cashwini - 150831*/
OBJECT_ENUM     ExtServiceProf;        /* 1229 ext_service_profile          - HFI-PMSTA-22496-160502    */
OBJECT_ENUM     ExtServiceProfCompo;   /* 1230 ext_service_prof_compo       - HFI-PMSTA-22496-160502    */

 /* Script */
OBJECT_ENUM     ScriptDef;             /* 1300 script_definition          */
OBJECT_ENUM     ApplRule;              /* 1301 appl_rule                  */ /* DVP037 960426 DED */
OBJECT_ENUM     RuleCompo;             /* 1302 rule_compo                 */ /* DVP037 960426 DED */
OBJECT_ENUM		ScriptLibrary;		   /* 1303 script_library			  */ /*REF11296-BRO-060406*/

 /* Risk rule */
OBJECT_ENUM     RiskRule;              /* 1404 risk_rule                  */ /* PMSTA-18426 - CHU - 140922 */
OBJECT_ENUM     RiskRuleCompo;         /* 1405 risk_rule_compo            */ /* PMSTA-18426 - CHU - 140922 */

 /* Subscription */
OBJECT_ENUM      Event;                 /* 1501 event                      */ /* REF4204 - RAK - 000201 */
OBJECT_ENUM      Map;                   /* 1502 map                        */ /* REF4204 - RAK - 000201 */
OBJECT_ENUM      Audit;                 /* 1503 audit                      */ /* REF4204 - RAK - 000201 */
OBJECT_ENUM      EventUpdate;           /* 1504 event_update               */ /* REF4204 - RAK - 000201 */

OBJECT_ENUM      EventGroupingId;       /* 1507 Grouping Id                */ /* PMSTA-17793 - DDV - 140318 */

OBJECT_ENUM     ReportModuleCompo;      /* 1635 report_module_compo        */ /* PMSTA-25021 - TEB - 161110 */

 /* Others */
OBJECT_ENUM     Fus;
OBJECT_ENUM     FinAnalysis;
OBJECT_ENUM     OptiFct;
OBJECT_ENUM     RemoteExec;             /* REF1229 */
OBJECT_ENUM     Test;
OBJECT_ENUM     Technical;              /* REF2467 - DDV - 991215 */
OBJECT_ENUM     OpList;                 /* REF3895 - OCE - 991231 */
OBJECT_ENUM     EvalEntityEnt;          /* REF10342 - LJE - 040614 */
OBJECT_ENUM     EvalEntitiesEnt;        /* PMSTA05247 - LJE - 071206 */
OBJECT_ENUM     OpenedPosition;         /* Opened Position */ /* BSA - PMSTA01179 - 061219 */
OBJECT_ENUM     InputEntity;            /* PCC13654 - LJE - 090624 */
OBJECT_ENUM     OutputEntity;           /* PCC13654 - LJE - 090624 */
OBJECT_ENUM     OutputPermVal;          /* PCC13654 - LJE - 090624 */
OBJECT_ENUM     OutputMsg;              /* PCC13654 - LJE - 090624 */
OBJECT_ENUM     Array;                  /* PMSTA14453 - DDV - 120705 - Array definition not clean */
OBJECT_ENUM     PurgeEntity;            /* PMSTA15008-JPP-20120920 */
OBJECT_ENUM     StartFusionByCd;        /* PMSTA21215 - PCL */
OBJECT_ENUM     ExecFinAnalysisAllDomain;    /* PMSTA-18593 - LJE - 151216 */
OBJECT_ENUM     ExecSelExportDataByCd;  /* PMSTA-22169 - DLA - 160119 */

OBJECT_ENUM     LASTOBJECT;
OBJECT_ENUM     LASTENTITYOBJECT;
OBJECT_ENUM     LASTLOGENTITYOBJECT;
OBJECT_ENUM     LASTUDTOBJECT=0; /* PMSTA-13109 - LJE - 111202 */

DBA_DYNST_ENUM  NullDynSt=-1;
DBA_DYNST_ENUM  InvalidDynSt=0; /* REF9789 - LJE - 031230 */
DBA_DYNST_ENUM  A_AccPer;       /* DVP002 960229 RAK */
DBA_DYNST_ENUM  S_AccPer;       /* DVP002 960229 RAK */
DBA_DYNST_ENUM  A_AccPerParam;  /* DVP002 960229 RAK */
DBA_DYNST_ENUM  S_AccPerParam;  /* DVP002 960229 RAK */
DBA_DYNST_ENUM  A_AccPlan;      /* DVP339 970206 RAK */
DBA_DYNST_ENUM  S_AccPlan;      /* DVP339 970206 RAK */
DBA_DYNST_ENUM  A_AccPlanElt;   /* DVP002 960229 RAK */
DBA_DYNST_ENUM  S_AccPlanElt;   /* DVP002 960229 RAK */
DBA_DYNST_ENUM  A_AccProfileHisto; /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  S_AccProfileHisto; /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  A_AccProfile;      /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  S_AccProfile;      /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  A_AccProfileCompo; /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  S_AccProfileCompo; /* PMSTA00488 - EFE -061101 */
DBA_DYNST_ENUM  Arg_AccountingRuleCompo; /* PMSTA-28335 - MSR - 171006 */
DBA_DYNST_ENUM  Arg_ApplUserPrefName; /* PMSTA-32230 - MSR - 130818 */
DBA_DYNST_ENUM  ArgAccRuleCompo; /* PMSTA-29130 - 200818 - vkumar */
DBA_DYNST_ENUM  Arg_TopN;        /* PMSTA-34198 - 040419 - SGO */

DBA_DYNST_ENUM    A_AdminMgr;     /* REF8844 - LJE - 030303 */
DBA_DYNST_ENUM  A_ApplMsg;      /* DVP019 960320 RAK */
DBA_DYNST_ENUM  S_ApplMsg;      /* DVP019 960320 RAK */
DBA_DYNST_ENUM  A_ApplMsgTxt;   /* DVP019 960320 RAK */
DBA_DYNST_ENUM  S_ApplMsgTxt;   /* DVP019 960320 RAK */
DBA_DYNST_ENUM  A_ApplPswdHist; /* 3.50 DB MODIF - RAK - 991125 */
DBA_DYNST_ENUM  A_ApplRule;     /* DVP037 960426 DED */
DBA_DYNST_ENUM  S_ApplRule;     /* DVP037 960426 DED */
DBA_DYNST_ENUM  A_Archive;      /* REF4306 - RAK - 000201 */
DBA_DYNST_ENUM    S_Archive;      /* REF4309 - CSA/OCE - 000523 */
DBA_DYNST_ENUM  A_Audit;        /* REF4204 - RAK - 000201 */
DBA_DYNST_ENUM  A_BalPos;
DBA_DYNST_ENUM  S_BalPos;
DBA_DYNST_ENUM  A_BalPosRule;
DBA_DYNST_ENUM  S_BalPosRule;
DBA_DYNST_ENUM  A_BalPosRuleSet;
DBA_DYNST_ENUM  S_BalPosRuleSet;
DBA_DYNST_ENUM  A_BalPosTp;
DBA_DYNST_ENUM  S_BalPosTp;
DBA_DYNST_ENUM    A_ObjectLnk;     /* REF7758 - DDV - 020925 */
DBA_DYNST_ENUM  A_BookValue;  /* DVP430 - 970417 - XDI */
DBA_DYNST_ENUM	A_BusEntity;           /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	S_BusEntity;           /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	A_BusOrga;             /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	S_BusOrga;             /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	A_BusEntityPtfCompo;   /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	S_BusEntityPtfCompo;   /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	A_BusEntityInstrCompo; /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	S_BusEntityInstrCompo; /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	A_BusEntityThirdCompo; /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	S_BusEntityThirdCompo; /* PMSTA-17089 - DDV - 131106 */
DBA_DYNST_ENUM	A_BusEntityAddr;       /* PMSTA-17089 - DDV - 131203 */
DBA_DYNST_ENUM	S_BusEntityAddr;       /* PMSTA-17089 - DDV - 131203 */
DBA_DYNST_ENUM  A_Calendar;
DBA_DYNST_ENUM  S_Calendar;
DBA_DYNST_ENUM  A_CalendarDate;       /* DVP496 - RAK - 970606 */
DBA_DYNST_ENUM  S_CalendarDate;       /* DVP496 - RAK - 970606 */
DBA_DYNST_ENUM  A_CalendarConv;       /* DVP496 - RAK - 970606 */
DBA_DYNST_ENUM  S_CalendarConv;       /* DVP496 - RAK - 970606 */
DBA_DYNST_ENUM  A_CaseClarification;  /* PMSTA07121-CHU-081008 */
DBA_DYNST_ENUM  S_CaseClarification;  /* PMSTA07121-CHU-081008 */
DBA_DYNST_ENUM  A_CaseLink;           /* PMSTA07121-CHU-081008 */
DBA_DYNST_ENUM  S_CaseLink;           /* PMSTA07121-CHU-081008 */
DBA_DYNST_ENUM  A_CaseMsgTemplate;    /* PMSTA07121-CHU-081014 */
DBA_DYNST_ENUM  S_CaseMsgTemplate;    /* PMSTA07121-CHU-081014 */
DBA_DYNST_ENUM  A_CaseMsgTemplateDef; /* PMSTA07121-DDV-081212 */
DBA_DYNST_ENUM  S_CaseMsgTemplateDef; /* PMSTA07121-DDV-081212 */
DBA_DYNST_ENUM	A_CaseRule;	          /* PMSTA- 18760 -cashwini-140205 */
DBA_DYNST_ENUM	S_CaseRule;		      /* PMSTA- 18760 -cashwini-140205 */
DBA_DYNST_ENUM  A_LombardCheck;       /* PMSTA-21045 - cashwini--150818 */
DBA_DYNST_ENUM  S_LombardCheck;       /* PMSTA-21045 - cashwini--150818 */
DBA_DYNST_ENUM  A_CheckList;
DBA_DYNST_ENUM  A_Classif;
DBA_DYNST_ENUM  S_Classif;
DBA_DYNST_ENUM  A_ClassifCompo;
DBA_DYNST_ENUM  S_ClassifCompo;
DBA_DYNST_ENUM  E_ClassifCompo;
DBA_DYNST_ENUM  A_CheckScript; /* PMSTA11221-PRS-180111 */
DBA_DYNST_ENUM  CheckScript_Arg;
DBA_DYNST_ENUM  A_ClientConnect; /* DVP062 960520 RAK */
DBA_DYNST_ENUM  S_ClientConnect; /* DVP062 960520 RAK */
DBA_DYNST_ENUM  A_CommMgr;             /* REF8844 - LJE - 030303 */
DBA_DYNST_ENUM  A_Communication;       /*REF11810-BRO-060612*/
DBA_DYNST_ENUM  S_Communication;       /*REF11810-BRO-060612*/
DBA_DYNST_ENUM  A_ComplianceChrono;    /*PMSTA5345-EFE-080215*/
DBA_DYNST_ENUM  S_ComplianceChrono;    /*PMSTA5345-EFE-080215*/
DBA_DYNST_ENUM  A_ConstraintBreach;    /* MIGR R4.00 STEP6 - LJE - 020816 */
DBA_DYNST_ENUM  S_ConstraintBreach;    /* MIGR R4.00 STEP6 - LJE - 020816 */
DBA_DYNST_ENUM  A_ConstraintParameter; /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  S_ConstraintParameter; /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  A_ConstrTemplate;      /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  S_ConstrTemplate;      /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  A_CorporateAction;         /*REF10603-EFE-041008*/
DBA_DYNST_ENUM  S_CorporateAction;         /*REF10603-EFE-041008*/
DBA_DYNST_ENUM  A_Curr;
DBA_DYNST_ENUM  S_Curr;
DBA_DYNST_ENUM  A_CurrChrono;
DBA_DYNST_ENUM  S_CurrChrono;
DBA_DYNST_ENUM  A_CurrFreq;             /* REF4306 - RAK -000201 */
DBA_DYNST_ENUM  A_DataDesc;             /* REF1055 - RAK - 000303 */
DBA_DYNST_ENUM  A_DataDisp;             /* REF1055 - RAK - 000303 */
DBA_DYNST_ENUM  A_DataProf;             /* REF5562 SKE 010119 */
DBA_DYNST_ENUM  S_DataProf;             /* REF5562 SKE 010119 */
DBA_DYNST_ENUM  A_DataProfCompo;        /* REF5562 SKE 010119 */
DBA_DYNST_ENUM  S_DataProfCompo;        /* REF5562 SKE 010119 */
DBA_DYNST_ENUM  A_DataSecuProf;
DBA_DYNST_ENUM  S_DataSecuProf;
DBA_DYNST_ENUM  A_DataSetDef;           /* PMSTA01389 - DDV - 070307 */
DBA_DYNST_ENUM  S_DataSetDef;           /* PMSTA01389 - DDV - 070307 */
DBA_DYNST_ENUM  A_ExtServiceCompo;      /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  S_ExtServiceCompo;      /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  A_OptiProf;             /* REF11767 - CHU - 060331 */
DBA_DYNST_ENUM  S_OptiProf;             /* REF11767 - CHU - 060331 */
DBA_DYNST_ENUM  A_OptiProfCompo;        /* REF11767 - CHU - 060331 */
DBA_DYNST_ENUM  S_OptiProfCompo;        /* REF11767 - CHU - 060331 */
DBA_DYNST_ENUM  A_OptiProc;             /* REF11767 - LJE - 060418 */
DBA_DYNST_ENUM  S_OptiProc;             /* REF11767 - LJE - 060418 */
DBA_DYNST_ENUM  A_ApplComment;          /*PMSTA10733-TEB-101130*/
DBA_DYNST_ENUM  S_ApplComment;          /*PMSTA10733-TEB-101130*/
DBA_DYNST_ENUM  A_Denom;
DBA_DYNST_ENUM  S_Denom;
DBA_DYNST_ENUM    A_DerivedStrat;     /* RAK - 010606 */
DBA_DYNST_ENUM    S_DerivedStrat;     /* RAK - 010606 */
DBA_DYNST_ENUM    A_DerivedStratElt;  /* RAK - o10606 */
DBA_DYNST_ENUM  A_DictUser;
DBA_DYNST_ENUM  S_DictUser;
DBA_DYNST_ENUM  A_DictCriter;
DBA_DYNST_ENUM  S_DictCriter;
DBA_DYNST_ENUM  A_DictDataTp;
DBA_DYNST_ENUM  S_DictDataTp;
DBA_DYNST_ENUM  E_DictFct;     /*SHR - 150721 - PMSTA-17794*/
DBA_DYNST_ENUM  A_DictLabel;
DBA_DYNST_ENUM  S_DictLabel;
DBA_DYNST_ENUM  A_DictLang;
DBA_DYNST_ENUM  S_DictLang;
DBA_DYNST_ENUM  A_DictPanel;    /* ROI - 960910 - DVP200 */
DBA_DYNST_ENUM  S_DictPanel;    /* ROI - 960910 - DVP200 */
DBA_DYNST_ENUM  A_DictScreen;   /* DVP200+ - 970123 - DED */
DBA_DYNST_ENUM  S_DictScreen;   /* DVP200+ - 970123 - DED */
DBA_DYNST_ENUM  O_DictPermVal;    /* PMSTA-15655 - LJE - 130124 */
DBA_DYNST_ENUM	A_DictView;       /* PMSTA-11999 - RPO - 110504 */
DBA_DYNST_ENUM	S_DictView;       /* PMSTA-11999 - RPO - 110504 */
DBA_DYNST_ENUM	A_DictDatabase;   /* PMSTA-13109 - LJE - 111123 */
DBA_DYNST_ENUM	S_DictDatabase;   /* PMSTA-13109 - LJE - 111123 */
DBA_DYNST_ENUM	A_DictSegment;    /* PMSTA-13109 - LJE - 111123 */
DBA_DYNST_ENUM	S_DictSegment;    /* PMSTA-13109 - LJE - 111123 */
DBA_DYNST_ENUM	A_DictFctAttrib;  /* PMSTA-13244 - DDV - 120119 */
DBA_DYNST_ENUM	S_DictFctAttrib;  /* PMSTA-13244 - DDV - 120119 */
DBA_DYNST_ENUM  A_Doc;
DBA_DYNST_ENUM  S_Doc;
DBA_DYNST_ENUM  A_DocIndex;
DBA_DYNST_ENUM  S_DocIndex;
DBA_DYNST_ENUM  A_Domain;
DBA_DYNST_ENUM  S_Domain;
DBA_DYNST_ENUM  A_Empty;        /*REF7758-BRO-020911*/
DBA_DYNST_ENUM  A_EvtExcl;
DBA_DYNST_ENUM  S_EvtExcl;
DBA_DYNST_ENUM  A_ExchFmt;
DBA_DYNST_ENUM  S_ExchFmt;
DBA_DYNST_ENUM  A_ExchRate;
DBA_DYNST_ENUM  S_ExchRate;
DBA_DYNST_ENUM  A_ExtRetAnalysis; /* REF7421 - LJE - 020711 */
DBA_DYNST_ENUM  S_ExtRetAnalysis; /*REF7758-BRO-021018*/
DBA_DYNST_ENUM  Freq_ExchRate;
DBA_DYNST_ENUM  A_FctResult;    /* DV056 - RAK - 960520 */
DBA_DYNST_ENUM  S_FctResult;    /* DV056 - RAK - 960520 */
DBA_DYNST_ENUM  A_FctSecuProfCompo; /* DVP250 - 961113 - DED */
DBA_DYNST_ENUM  S_FctSecuProfCompo; /* DVP250 - 961113 - DED */
DBA_DYNST_ENUM  A_FctSecuProf;
DBA_DYNST_ENUM  S_FctSecuProf;
DBA_DYNST_ENUM  E_Fmt;
DBA_DYNST_ENUM  Sum_FmtElt;
DBA_DYNST_ENUM  A_InputEntity;  /* PCC13654 - LJE - 090624 */
DBA_DYNST_ENUM  A_OutputEntity; /* PCC13654 - LJE - 090624 */
DBA_DYNST_ENUM  A_OutputPermVal; /* PCC13654 - LJE - 090624 */
DBA_DYNST_ENUM  A_OutputMsg; /* PCC13654 - LJE - 090624 */
DBA_DYNST_ENUM  A_FmtProf;
DBA_DYNST_ENUM  S_FmtProf;
DBA_DYNST_ENUM  A_FmtProfCompo;
DBA_DYNST_ENUM  S_FmtProfCompo;
DBA_DYNST_ENUM  A_Folder;
DBA_DYNST_ENUM  S_Folder;
DBA_DYNST_ENUM  A_FundVal;  /* DVP037 960426 DED */
DBA_DYNST_ENUM  S_FundVal;  /* DVP037 960426 DED */
DBA_DYNST_ENUM  A_FundValElt;   /* DVP037 960426 DED */
DBA_DYNST_ENUM  S_FundValElt;   /* DVP037 960426 DED */
DBA_DYNST_ENUM  A_FundWgt;
DBA_DYNST_ENUM  S_FundWgt;
DBA_DYNST_ENUM  A_Event;        /* REF4204 - RAK - 000201 */
DBA_DYNST_ENUM  S_Event;        /* REF4204 - RAK - 000201 */

DBA_DYNST_ENUM  A_EventUpdate;  /* REF4204 - RAK - 000201 */
DBA_DYNST_ENUM  A_Grid;
DBA_DYNST_ENUM  S_Grid;
DBA_DYNST_ENUM  A_EventGroupingId; /* PMSTA_17793 - DDV - 140318 */
DBA_DYNST_ENUM  S_EventGroupingId; /* PMSTA_17793 - DDV - 140318 */
DBA_DYNST_ENUM  A_Guarantee;
DBA_DYNST_ENUM  S_Guarantee;
DBA_DYNST_ENUM  A_InstrChrono;
DBA_DYNST_ENUM  S_InstrChrono;
DBA_DYNST_ENUM  Dim_InstrChrono;    /* DVP051 RAK 960509 */
DBA_DYNST_ENUM  Freq_InstrChrono;   /* DVP005 RAK 960314 */
DBA_DYNST_ENUM  A_InstrDeposit;     /*REF11718-BRO-060301*/
DBA_DYNST_ENUM  S_InstrDeposit;     /*REF11718-BRO-060301*/
DBA_DYNST_ENUM  A_InstrFreq;        /* REF4306 - RAK - 000201 */
DBA_DYNST_ENUM  A_InstrRiskOrig;    /* PMSTA-18096 - LJE - 140620 */
DBA_DYNST_ENUM  A_InstrPrice;
DBA_DYNST_ENUM  S_InstrPrice;
DBA_DYNST_ENUM  InstrPriceIdx;      /* REF2834 - DDV - 980923 */
DBA_DYNST_ENUM  Freq_InstrPrice;

DBA_DYNST_ENUM  A_IssueEvt;
DBA_DYNST_ENUM  S_IssueEvt;
DBA_DYNST_ENUM  A_ListChrono;        /*REF7292-BRO-020121*/
DBA_DYNST_ENUM  S_ListChrono;        /*REF7292-BRO-020121*/
DBA_DYNST_ENUM  Freq_ListChrono;     /* REF7292 - LJE - 020213 */
DBA_DYNST_ENUM  A_ListCompo;
DBA_DYNST_ENUM  S_ListCompo;
DBA_DYNST_ENUM  A_LoginFailed;      /* 3.50 DB MODIF - RAK - 991125 */
DBA_DYNST_ENUM  A_Map;              /* REF4204 - RAK - 000201 */
DBA_DYNST_ENUM  S_Map;              /* REF4204 - RAK - 000201 */
DBA_DYNST_ENUM  A_Mgr;
DBA_DYNST_ENUM  S_Mgr;
DBA_DYNST_ENUM  A_MktSegt;
DBA_DYNST_ENUM  S_MktSegt;
DBA_DYNST_ENUM    A_MktStruct;        /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM    S_MktStruct;        /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM    A_MktSSubSet;       /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM    S_MktSSubSet;       /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM    A_ModelConstrElt;   /* RAK - 010606 */
DBA_DYNST_ENUM    S_ModelConstrElt;   /* RAK - 010606 */
DBA_DYNST_ENUM  A_Notepad;
DBA_DYNST_ENUM  S_Notepad;
DBA_DYNST_ENUM    A_One;              /* MIGR R4.00 STEP6 - LJE - 020815 */
DBA_DYNST_ENUM    A_Boottime;         /* PMSTA-16365 - 140509 */
DBA_DYNST_ENUM  A_Op;
DBA_DYNST_ENUM  S_Op;
DBA_DYNST_ENUM  A_OpCompo;
DBA_DYNST_ENUM  S_OpCompo;
DBA_DYNST_ENUM  A_PayInstruct;
DBA_DYNST_ENUM  S_PayInstruct;
DBA_DYNST_ENUM  A_PAABreakCriteria;  /* REF9264 - LJE - 030630 */
DBA_DYNST_ENUM  A_PerfAttribId;      /* REF9924 - LJE - 040213 */
DBA_DYNST_ENUM  S_PerfAttribId;
DBA_DYNST_ENUM  A_PerfAttrib;        /* REF7421 - LJE - 020711 */
DBA_DYNST_ENUM  S_PerfAttrib;        /* REF7421 - LJE - 020711 */
DBA_DYNST_ENUM    A_PerfAttribData;    /* REF8798 - YST - 030310 */
DBA_DYNST_ENUM  A_PSPPositionDate;   /* REF9125 - LJE - 030813 */
DBA_DYNST_ENUM  S_PSPPositionDate;   /* REF9125 - LJE - 030813 */
DBA_DYNST_ENUM  A_PerfEffectDef;     /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  S_PerfEffectDef;     /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  A_PerfEffectLink;	 /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  S_PerfEffectLink;    /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  A_PerfCurrencyContrib;	 /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  A_PerfInterBench;	 /* PMSTA08736 - LJE - 100115 */
DBA_DYNST_ENUM  A_PlanRule;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanRule;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PlanRuleHisto;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanRuleHisto;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PlanDefinition;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanDefinition;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PlanObjectiveHisto;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanObjectiveHisto;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PlanInvestParamHisto;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanInvestParamHisto;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PlanInvestDate;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_PlanInvestDate;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_FreeDepositHisto;	     /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  S_FreeDepositHisto;		 /* PMSTA-21268 - SHR - 092115 */
DBA_DYNST_ENUM  A_PtfChrono;
DBA_DYNST_ENUM  S_PtfChrono;
DBA_DYNST_ENUM  Freq_PtfChrono;     /* DVP005 RAK 960314 */
DBA_DYNST_ENUM  A_PtfFreq;          /* REF4306 - RAK - 000201 */
DBA_DYNST_ENUM  A_PtfPosSet;
DBA_DYNST_ENUM  S_PtfPosSet;
DBA_DYNST_ENUM  A_PtfSynth;
DBA_DYNST_ENUM  S_PtfSynth;
DBA_DYNST_ENUM  Zero_PtfSynth;      /* REF1511 - RAK - 980406 */
DBA_DYNST_ENUM  A_Pos;
DBA_DYNST_ENUM  S_Pos;
DBA_DYNST_ENUM  A_Printer;      /* DVP350 970225 PEC */
DBA_DYNST_ENUM  S_Printer;      /* DVP350 970225 PEC */
DBA_DYNST_ENUM  A_PrinterProf;      /* DVP350 970225 PEC */
DBA_DYNST_ENUM  S_PrinterProf;      /* DVP350 970225 PEC */
DBA_DYNST_ENUM  A_PrinterProfCompo; /* DVP350 970225 PEC */
DBA_DYNST_ENUM  S_PrinterProfCompo; /* DVP350 970225 PEC */
DBA_DYNST_ENUM  A_PrintParam;       /* DVP068 980818 OCE  renamed from A_ReportParam */
DBA_DYNST_ENUM  A_PSPPositionData;   /* REF9125 - LJE - 030812 */
DBA_DYNST_ENUM  S_PSPPositionData;   /* REF9125 - LJE - 030812 */
DBA_DYNST_ENUM    A_QuickSearch;       /* REF4497 - SKE - 000331 */
DBA_DYNST_ENUM  A_Rating;
DBA_DYNST_ENUM  S_Rating;
DBA_DYNST_ENUM  A_RatingAttr;
DBA_DYNST_ENUM  S_RatingAttr;
DBA_DYNST_ENUM  A_Regr;         /* DVP005 960313 RAK */
DBA_DYNST_ENUM  A_Report;
DBA_DYNST_ENUM  S_Report;
DBA_DYNST_ENUM  A_ReportGen;        /* DVP062 960520 RAK */
DBA_DYNST_ENUM  A_ReportParam;      /* DVP068 980818 OCE */
DBA_DYNST_ENUM  S_ReportParam;      /* DVP068 980818 OCE */
DBA_DYNST_ENUM  A_ReportProf;
DBA_DYNST_ENUM  S_ReportProf;
DBA_DYNST_ENUM  A_ReportProfCompo;
DBA_DYNST_ENUM  S_ReportProfCompo;
DBA_DYNST_ENUM  A_ReportModuleCompo;	/* PMSTA-25021 - TEB - 161110 */
DBA_DYNST_ENUM  S_ReportModuleCompo;	/* PMSTA-25021 - TEB - 161110 */
DBA_DYNST_ENUM  A_RequestCode;       /*REF10604-BRO-040922*/
DBA_DYNST_ENUM  S_RequestCode;       /*REF10604-BRO-040922*/
DBA_DYNST_ENUM    A_RetAnaDetailed;   /* REF8798 - YST - 030310 */
DBA_DYNST_ENUM    A_RetAnaGlobal;     /* REF8798 - YST - 030310 */
DBA_DYNST_ENUM    A_RetAnalysisId;    /* REF8798 - YST - 030310 */
DBA_DYNST_ENUM    S_RetAnalysisId;   /* PMSTA-17060 - LJE - 131010 */
DBA_DYNST_ENUM    S_ExtOrderBlockId; /* PMSTA-46001 - AAKASH - 161221*/
DBA_DYNST_ENUM  A_ReturnGridLnk;    /* DVP252 - 961115 - DED */
DBA_DYNST_ENUM  S_ReturnGridLnk;    /* DVP252 - 961115 - DED */
DBA_DYNST_ENUM    A_RiskRatio;        /* REF8705 - LJE - 030123 */
DBA_DYNST_ENUM    A_RuleCompo;      /* DVP037 - 960426 - DED */
DBA_DYNST_ENUM  S_RuleCompo;        /* DVP037 - 960426 - DED */
DBA_DYNST_ENUM  A_Scena;
DBA_DYNST_ENUM  S_Scena;
DBA_DYNST_ENUM  A_ScenaCompo;
DBA_DYNST_ENUM  S_ScenaCompo;
DBA_DYNST_ENUM  A_ScenaElt;
DBA_DYNST_ENUM  S_ScenaElt;
DBA_DYNST_ENUM  A_ScreenProf;       /* DVP338 - 970204 - RAK */
DBA_DYNST_ENUM  S_ScreenProf;       /* DVP338 - 970204 - RAK */
DBA_DYNST_ENUM  A_ScreenProfCompo;  /* DVP338 - 970204 - RAK */
DBA_DYNST_ENUM  S_ScreenProfCompo;  /* DVP338 - 970204 - RAK */
DBA_DYNST_ENUM  A_ScriptDef;
DBA_DYNST_ENUM  S_ScriptDef;
DBA_DYNST_ENUM  A_ScriptLibrary;	/*REF11296-BRO-060406*/
DBA_DYNST_ENUM  S_ScriptLibrary;	/*REF11296-BRO-060406*/
DBA_DYNST_ENUM  A_SearchCrit;           /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  S_SearchCrit;           /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  A_SearchCritCompo;      /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  S_SearchCritCompo;      /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  O_SearchCritCompo;      /* PMSTA-15655 - LJE - 130124 */
DBA_DYNST_ENUM  A_SearchProf;           /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  S_SearchProf;           /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  A_SearchProfCompo;      /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  S_SearchProfCompo;      /*  FIH-REF9789-031222  */
DBA_DYNST_ENUM  A_SelSearchCritCompoArg;   /* PMSTA-15655 - LJE - 130121 */
DBA_DYNST_ENUM  A_SelFctSecuProfCompoArg;   /*  HFI-PMSTA-35838-190515  */
DBA_DYNST_ENUM  A_Sect;
DBA_DYNST_ENUM  S_Sect;
DBA_DYNST_ENUM  A_SectAttr;
DBA_DYNST_ENUM  S_SectAttr;
DBA_DYNST_ENUM  A_ShareOpInfo; /* DVP151 */
DBA_DYNST_ENUM  A_StandardPerf;  /* REF7421 - LJE - 020711 */
DBA_DYNST_ENUM  S_StandardPerf;  /* REF7421 - LJE - 020711 */
DBA_DYNST_ENUM  A_StdPerfData;      /* REF8798 - YST - 030310 */
DBA_DYNST_ENUM  A_StandInstruct; /*PMSTA06761-BRO-080704*/
DBA_DYNST_ENUM  S_StandInstruct; /*PMSTA06761-BRO-080704*/
DBA_DYNST_ENUM  A_Stat;        /* DVP005 960313 RAK */
DBA_DYNST_ENUM    A_StratCompo;   /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM  S_StratCompo;   /* MODIF BD - RAK - 020105 */
DBA_DYNST_ENUM  A_StratElt;
DBA_DYNST_ENUM  S_StratElt;
DBA_DYNST_ENUM  A_StratLnk;
DBA_DYNST_ENUM  S_StratLnk;
DBA_DYNST_ENUM  A_StratHist;
DBA_DYNST_ENUM  S_StratHist;
DBA_DYNST_ENUM  A_StratEltDetail;
DBA_DYNST_ENUM  A_StratSynth;       /* PMSTA08737 - LJE - 091109 */
DBA_DYNST_ENUM  A_TabCnt;    /* SQL044 - 960403 - RAK */
DBA_DYNST_ENUM  S_TabCnt;    /* SQL044 - 960403 - RAK */
DBA_DYNST_ENUM  A_TabModifStat;
DBA_DYNST_ENUM  S_TabModifStat;
DBA_DYNST_ENUM  A_TemplateElt;      /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  S_TemplateElt;      /*REF7289-BRO-020205*/
DBA_DYNST_ENUM  Freq_ThirdChrono;   /* DVP005 BEGIN RAK 960314 */
DBA_DYNST_ENUM  A_ThirdFreq;        /* REF4306 - RAK - 000201 */
DBA_DYNST_ENUM  A_TradingCurrency;  /*REF7296-BRO-020205*/
DBA_DYNST_ENUM  S_TradingCurrency;  /*REF7296-BRO-020205*/
DBA_DYNST_ENUM  A_TradingPlace;     /*REF7296-BRO-020205*/
DBA_DYNST_ENUM  S_TradingPlace;     /*REF7296-BRO-020205*/
DBA_DYNST_ENUM  A_RiskRule;         /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  S_RiskRule;         /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  A_RiskRuleCompo;    /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  S_RiskRuleCompo;    /* PMSTA-18426 - CHU - 140922 */
DBA_DYNST_ENUM  A_WarningMsg;       /* MIGR R4.00 STEP6 - LJE - 020816 */
DBA_DYNST_ENUM  ExtPos;
DBA_DYNST_ENUM  PosVal;
DBA_DYNST_ENUM  UnitInter;
DBA_DYNST_ENUM  A_Ytm;
DBA_DYNST_ENUM  A_AdvA;         /* REF1055 RAK 981012 */
DBA_DYNST_ENUM  AdvA_Arg;       /* REF1055 RAK 981012 */
DBA_DYNST_ENUM  RiskAmt;
DBA_DYNST_ENUM  Flow;
DBA_DYNST_ENUM  OpDomain;
DBA_DYNST_ENUM  BuyOp;
DBA_DYNST_ENUM  SellOp;
DBA_DYNST_ENUM  InvestOp;
DBA_DYNST_ENUM  WithdrOp;
DBA_DYNST_ENUM  IncOp;
DBA_DYNST_ENUM  ShareIssOp;
DBA_DYNST_ENUM  ShareRedmOp;
DBA_DYNST_ENUM  TransfOp;
DBA_DYNST_ENUM  BpTransfOp;
DBA_DYNST_ENUM  AdjustOp;
DBA_DYNST_ENUM  FtOp;
DBA_DYNST_ENUM  LockOp;     /* DVP183 - 960826 - DED */
DBA_DYNST_ENUM  PtfTransfOp;    /* DVP355 - 970303 - PEC */
DBA_DYNST_ENUM  BookAdjOp;      /* DVP355 - 970303 - PEC */
DBA_DYNST_ENUM  InitOp;         /* REF4306 - RAK - 000201 */
DBA_DYNST_ENUM  CombinedOp;     /*PMSTA06760-BRO-080701*/
DBA_DYNST_ENUM  A_PosValHist;   /* DVP390 - 970317 - PEC */
DBA_DYNST_ENUM  S_PosValHist;   /* DVP390 - 970317 - PEC */
DBA_DYNST_ENUM  Adm_Arg;
DBA_DYNST_ENUM  Array_X;        /* DVP005 RAK 960322 */
DBA_DYNST_ENUM  Array_XY;       /* DVP005 RAK 960322 */
DBA_DYNST_ENUM  Chrono_Arg;
DBA_DYNST_ENUM  Chrono_FreqArg; /* DVP005 RAK 960314 */
DBA_DYNST_ENUM  ExchRate_Arg;
DBA_DYNST_ENUM  ExchRate_FreqArg;
DBA_DYNST_ENUM  Sel_Arg;        /* DVP344 XDI 970219 */
DBA_DYNST_ENUM  InstrPrice_Arg;
DBA_DYNST_ENUM  InstrPrice_FreqArg;
DBA_DYNST_ENUM  Evt_Arg;
DBA_DYNST_ENUM  Fus_Arg;
DBA_DYNST_ENUM  Bu_Arg;         /* PMSTA-51720 - 160123 - Sathees */
DBA_DYNST_ENUM  UearEntity;     /* WEALTH-5698 - 290224 - Sathees */
DBA_DYNST_ENUM  Fus_Sync;       /* PMSTA-24510 - 220816 - PMO */
DBA_DYNST_ENUM  GetVersion_Arg; /* PMSTA-24510 - 220816 - PMO */
DBA_DYNST_ENUM  GetSrvEnv_Arg;     /* DLA - PMSTA-24751 - 161227 */
DBA_DYNST_ENUM  Chk_Arg;
DBA_DYNST_ENUM  Del_Arg;
DBA_DYNST_ENUM  Get_Arg;
DBA_DYNST_ENUM  Get_Arg2;   /* REF2338 - GRD - 981015 */
DBA_DYNST_ENUM  Flow_Arg;
DBA_DYNST_ENUM  ApplMsg_Arg;
DBA_DYNST_ENUM  FundVal_Arg;   /* DVP034 XDI 960509 */
DBA_DYNST_ENUM  Operator;
DBA_DYNST_ENUM  Srv_Connect;
DBA_DYNST_ENUM  A_Test;
DBA_DYNST_ENUM  Out_Date;
DBA_DYNST_ENUM  MeanCapReturn_Arg;
DBA_DYNST_ENUM  RiskRatio_Arg;   /* REF8705 - LJE - 030128 */
DBA_DYNST_ENUM  Io_Id;
DBA_DYNST_ENUM  Io_Ext;             /* PMSTA-34344 - LJE - 200925 */
DBA_DYNST_ENUM  Io_Flg;             /* PMSTA-47605 - JBC - 220113 */
DBA_DYNST_ENUM  Io_Info;
DBA_DYNST_ENUM  FmtEltDef;
DBA_DYNST_ENUM  DataDef;
DBA_DYNST_ENUM  PtfFusion;
DBA_DYNST_ENUM  ListMgmArg;
DBA_DYNST_ENUM  ExtStratLnk;
DBA_DYNST_ENUM  ExtStratElt;
DBA_DYNST_ENUM  ExtStratElt_Elt;    /* DVP023 RAK 960422 */
DBA_DYNST_ENUM  SumRes;             /* DVP023 RAK 960506 */
DBA_DYNST_ENUM  SumResElt;          /* DVP023 RAK 960506 */
DBA_DYNST_ENUM  ExtOp;
DBA_DYNST_ENUM  Imp_OpV2;
DBA_DYNST_ENUM  Curr_Modif;
DBA_DYNST_ENUM  Msg;
DBA_DYNST_ENUM  Select_Res_Tab;
DBA_DYNST_ENUM  ExportCtx_Arg;          /* DVP437  - 970422 - PEC */
DBA_DYNST_ENUM  Export_FmtElt;          /* DVP437  - 970423 - PEC */
DBA_DYNST_ENUM  A_CellFmt;
DBA_DYNST_ENUM  A_CompInstrChrono;  /* DVP264  - 961122 - DED */
DBA_DYNST_ENUM  A_CompComplChrono;  /* PMSTA-18426 - CHU - 141004 */
DBA_DYNST_ENUM  A_ComplianceChronoFreq;  /* PMSTA-22458 - cashwini - 04062016*/
DBA_DYNST_ENUM  Search_BestOper;    /* DVP282  - 961127 - GRD */
DBA_DYNST_ENUM  Current_Load;       /* DVP196  - 970131 - GRD */
DBA_DYNST_ENUM  PtfQtyAlloc;        /* DVP460  - 970516 - RAK */
DBA_DYNST_ENUM  MktSgtInstr;        /* DVP460  - 970605 - RAK */
DBA_DYNST_ENUM  Bench_Weight;       /* DVP475  - 970521 - GRD */
DBA_DYNST_ENUM  A_FTConv;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  S_FTConv;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  A_FTRateHist;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  S_FTRateHist;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  A_FTRate;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  S_FTRate;       /* REF847  - 980107 - DED */
DBA_DYNST_ENUM  HolidaysRule;       /* DVP571  - 970826 - GRD */
DBA_DYNST_ENUM  CalendarOut;        /* DVP571  - 970828 - GRD */
DBA_DYNST_ENUM  A_Array;          /* REF385  - 971001 - GRD */ /* PMSTA14453 - DDV - 120705 - Array definition not clean */
DBA_DYNST_ENUM  Fusion_Status;      /* REF1047 - 971205 - GRD */
DBA_DYNST_ENUM  Syb_Remote_Exec;    /* REF1229 - 980226 - GPA/GRD */
DBA_DYNST_ENUM  Syb_Remote_ExecCb;  /* REF1229 - 980226 - GPA/GRD */
DBA_DYNST_ENUM  Msg_Log;        /* REF3072 - 990224 - GRD */
DBA_DYNST_ENUM  StratInstrDura;     /* REF3788 - SSO - 990708 */
DBA_DYNST_ENUM    Arg_Test;               /* NPE - 990921 for Java Test */
DBA_DYNST_ENUM  A_OpList;               /* REF3895 - OCE - 991231  */
DBA_DYNST_ENUM  A_SetEnv;               /* REF???? - GRD - 000314 */
DBA_DYNST_ENUM  A_SafeShutdown;         /* PMSTA-35209 - HLA - 190926 Safe Server Exit */
DBA_DYNST_ENUM  EvalEntity;     /* REF4497 - GRD/CSA - 000314 */
DBA_DYNST_ENUM  EvalEntities;      /* PMSTA05247 - LJE - 071206 */
DBA_DYNST_ENUM  EvalEntityValues;   /* REF4497 - GRD/CSA - 000314 */
DBA_DYNST_ENUM  EvalEntityEnum;     /* REF4497 - GRD/CSA - 000314 */
DBA_DYNST_ENUM  EvalEntityError;    /* REF4497 - GRD/CSA - 000314 */
DBA_DYNST_ENUM  EvalEntityRights;   /*  FIH-REF11818-060612 */
DBA_DYNST_ENUM    IdEntity;           /* REF5358 - CSY - 0008121 */
DBA_DYNST_ENUM  A_UpdStratElt;  /* REF4908 - DED - 000619 */
DBA_DYNST_ENUM    Dynamic_Sql;      /* REF5506 SME */
DBA_DYNST_ENUM    A_Execution;      /* DLA - REF7560 - 020516 */
DBA_DYNST_ENUM    S_Execution;      /* DLA - REF7560 - 020527 */
DBA_DYNST_ENUM    A_GlExecFee;      /* DLA - REF7560 - 020516 */
DBA_DYNST_ENUM    S_GlExecFee;      /* DLA - REF7560 - 020516 */
DBA_DYNST_ENUM    A_ExtExecution;   /* DLA - REF7560 - 020516 */
DBA_DYNST_ENUM    Sql_Result;       /* REF11780 - 100406 - PMO */
DBA_DYNST_ENUM    A_VarStratElt;    /* PMSTA08747-CHU-091112 */
DBA_DYNST_ENUM    A_RiskESElt;	    /* PMSTA-18426-CHU-140922 */
DBA_DYNST_ENUM    A_RiskESEltCompo; /* PMSTA-18426-CHU-141014 */
DBA_DYNST_ENUM    A_RiskValueEltCompo;	/* PMSTA-18426-CHU-141014 */
DBA_DYNST_ENUM    S_RiskValueEltCompo;	/* PMSTA-18426-CHU-141014 */
DBA_DYNST_ENUM	  A_CompoundOrderRule;		/*PMSTA- 18634 - SHR - 140904 */
DBA_DYNST_ENUM	  S_CompoundOrderRule;		/*PMSTA- 18634 - SHR - 140904 */
DBA_DYNST_ENUM	  A_CompoundOrderMasterElt;		/*PMSTA- 18634 - SHR - 140904 */
DBA_DYNST_ENUM	  S_CompoundOrderMasterElt;		/*PMSTA- 18634 - SHR - 140904 */
DBA_DYNST_ENUM	  A_CompoundOrderSlaveElt;		/*PMSTA- 18634 - SHR - 140904 */
DBA_DYNST_ENUM	  S_CompoundOrderSlaveElt;		/*PMSTA- 18634 - SHR - 140904 */

/* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
#if 0
DBA_DYNST_ENUM    A_LightOrder;    /* DLA - REF7560 - 020614 */
DBA_DYNST_ENUM    S_LightOrder;    /* DLA - REF7560 - 020614 */
#endif

DBA_DYNST_ENUM    GetFile_I;                  /* REF4333.2 PCL */
DBA_DYNST_ENUM    GetFile_O;                   /* REF4333.2 PCL */
DBA_DYNST_ENUM    A_UnMatchedExecution;     /* REF9764 - CHU - 031222 */
DBA_DYNST_ENUM    S_UnMatchedExecution;     /* REF9764 - CHU - 031222 */
DBA_DYNST_ENUM    A_ExtTransaction;         /* REF9764 - LJE - 040106 */
DBA_DYNST_ENUM    A_UnMatchedGlExecFee;     /*REF10025-BRO-040401*/
DBA_DYNST_ENUM    AdvA_Vola;				/* REF10531 - TEB - 040806 */
DBA_DYNST_ENUM    OptiPurge;				/* REF11767 - CHU - 060411 */
DBA_DYNST_ENUM    OptiCheckIn;				/* REF11767 - CHU - 060504 */
DBA_DYNST_ENUM    OptiCheckOut;				/* REF11767 - CHU - 060504 */
DBA_DYNST_ENUM    SecuCheck ;               /*  FPL-REF11314-060516 no db entity to save right  */
DBA_DYNST_ENUM    A_OpenedPosition;         /*  Opened Position                */ /* BSA - PMSTA01179 - 061219 */
DBA_DYNST_ENUM	  A_FamilyDef;				/* PMSTA05911 - DDV - 080404 */
DBA_DYNST_ENUM	  A_FamilyElt;			    /* PMSTA05911 - DDV - 080404 */

DBA_DYNST_ENUM    A_EntityComment;          /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    S_EntityComment;          /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    A_AttributeComment;            /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    S_AttributeComment;            /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    A_PermValComment;         /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    S_PermValComment;         /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    A_ApplParamComment;       /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM    S_ApplParamComment;       /* PMSTA11809 - PRS - 110428 */
DBA_DYNST_ENUM	  SessionMgt;		        /* PMSTA13167 - DDV - 111215 - Add new structure for session management */
DBA_DYNST_ENUM    SqlRequest;               /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    CallRequest;              /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    AutoCreateItem;           /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    SqlRequestParam;          /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    SqlRequestResultSet;      /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    SqlRequestOutputDef;      /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    SqlRequestOutputParam;    /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    SqlRequestMsg;            /* PMSTA-34344 - LJE - 200928 */
DBA_DYNST_ENUM    TemenosPckHeader;         /* PMSTA-46681 - LJE - 240902 */
DBA_DYNST_ENUM    ProcessingContext;         /* PMSTA-46681 - LJE - 240902 */
DBA_DYNST_ENUM	  A_PurgeEntity;            /* PMSTA15008-JPP-20120920 */
DBA_DYNST_ENUM	  A_StartFusionByCd;
DBA_DYNST_ENUM    A_ExecFinAnalysisAllDomain; /* PMSTA-18593 - LJE - 151216 */
DBA_DYNST_ENUM    A_ExecSelExportDataByCd;  /* PMSTA-22169 - DLA - 160119 */

DBA_DYNST_ENUM    A_DomainPtfCompo;         /* PMSTA-21105 - cashwini - 150831*/
DBA_DYNST_ENUM    S_DomainPtfCompo;         /* PMSTA-21105 - cashwini - 150831*/
DBA_DYNST_ENUM    A_ExtServiceProf;         /*  HFI-PMSTA-22496-160502  */
DBA_DYNST_ENUM    S_ExtServiceProf;         /*  HFI-PMSTA-22496-160502  */
DBA_DYNST_ENUM    A_ExtServiceProfCompo;    /*  HFI-PMSTA-22496-160502  */
DBA_DYNST_ENUM    S_ExtServiceProfCompo;    /*  HFI-PMSTA-22496-160502  */

DBA_DYNST_ENUM	A_ApplChannelProf;      /* PMSTA-22551 - EFE - 20160323 */
DBA_DYNST_ENUM	S_ApplChannelProf;      /* PMSTA-22551 - EFE - 20160323 */
DBA_DYNST_ENUM	A_ApplChannelProfCompo; /* PMSTA-22551 - EFE - 20160323 */
DBA_DYNST_ENUM	S_ApplChannelProfCompo; /* PMSTA-22551 - EFE - 20160323 */
DBA_DYNST_ENUM  ExtTaxLot;              /* PMSTA-31342 - SANAND � 180528 */
DBA_DYNST_ENUM  Get_Guid;               /* PMSTA-34827 - JBC - 190218 */
DBA_DYNST_ENUM  Arg_WS;        /* PMSTA-37138 - 11092019 - sanand */
DBA_DYNST_ENUM  Arg_WS_OP;        /* PMSTA-37138 - 09112019 - Lik */
DBA_DYNST_ENUM  Arg_OverlayInitFetch; /* PMSTA XXXX - LIK 30012020 */
DBA_DYNST_ENUM	 Arg_OverlayNextFetch; /* PMSTA XXXX - LIK 30012020 */
DBA_DYNST_ENUM	 Arg_StratOvelayFetch; /* PMSTA XXXX - LIK 30012020 */
DBA_DYNST_ENUM	 Arg_PtfOvelayFetch; /* PMSTA XXXX - LIK 30012020 */
DBA_DYNST_ENUM  StandInstructFilterArg;
DBA_DYNST_ENUM  Out_Amount;         /* PMSTA-49587 - AIS - 220926 */
DBA_DYNST_ENUM  O_PackageDefinition;  /* PMSTA-46681 - LJE - 230915 */
DBA_DYNST_ENUM  InceptDtArg;        /* WEALTH-6158 - JBC - 20240330 */  

DBA_DYNST_ENUM    LASTDYNST;
long              EV_MaxDynStLenWithTextFld;     /* PMSTA07121 - Maximum length of a dynamic structure including text fields */
long              EV_MaxDynStLenWithoutTextFld;  /* PMSTA07121 - Maximum length of a dynamic structure excluding text fields */
long              EV_MaxMDDynStLenWithTextFld;   /* PMSTA07121 - Maximum length of a dynamic structure based on Metadictionary definition including text fields */
long              EV_MaxMDDynStLenWithoutTextFld;/* PMSTA07121 - Maximum length of a dynamic structure based on Metadictionary definition including text fields */
unsigned int      EV_MaxFieldLen;                /* PMSTA07121 - Maximum length of a dynamic structure's field */
unsigned int      EV_MaxFieldLenWithoutText;     /* PMSTA07121 - Maximum length of a dynamic structure's field (excluding text type) */

FIELD_IDX_T Null_Dynfld                              = -1;

FIELD_IDX_T A_AccPer_Id                              = 0;
FIELD_IDX_T A_AccPer_Cd                              = 1;
FIELD_IDX_T A_AccPer_Name                            = 2;
FIELD_IDX_T A_AccPer_PtfId                           = 3;
FIELD_IDX_T A_AccPer_AccPlanId                       = 4;
FIELD_IDX_T A_AccPer_BegDate                         = 5;
FIELD_IDX_T A_AccPer_EndDate                         = 6;
FIELD_IDX_T A_AccPer_ClosingDate                     = 7;
FIELD_IDX_T A_AccPer_FinalClosingFlg                 = 8;


FIELD_IDX_T S_AccPer_Id                              = 0;
FIELD_IDX_T S_AccPer_Cd                              = 1;
FIELD_IDX_T S_AccPer_Name                            = 2;
FIELD_IDX_T S_AccPer_PtfId                           = 3;
FIELD_IDX_T S_AccPer_AccPlanId                       = 4;
FIELD_IDX_T S_AccPer_AccPlanCd                       = 5;
FIELD_IDX_T S_AccPer_BegDate                         = 6;
FIELD_IDX_T S_AccPer_FinalClosingFlg                 = 7;


FIELD_IDX_T A_AccPerParam_Id                         = 0;
FIELD_IDX_T A_AccPerParam_DataTpEntDictId            = 1;
FIELD_IDX_T A_AccPerParam_AccPerId                   = 2;
FIELD_IDX_T A_AccPerParam_ValidityDate               = 3;
FIELD_IDX_T A_AccPerParam_NatEn                      = 4;
FIELD_IDX_T A_AccPerParam_Val                        = 5;
FIELD_IDX_T A_AccPerParam_ValText                    = 6;
FIELD_IDX_T A_AccPerParam_ValDate                    = 7;
FIELD_IDX_T A_AccPerParam_RoundUnit                  = 8;
FIELD_IDX_T A_AccPerParam_RoundRuleEn                = 9;
FIELD_IDX_T A_AccPerParam_UpdFlg                     = 10;


FIELD_IDX_T S_AccPerParam_Id                         = 0;
FIELD_IDX_T S_AccPerParam_DataTpEntDictId            = 1;
FIELD_IDX_T S_AccPerParam_AccPerId                   = 2;
FIELD_IDX_T S_AccPerParam_ValidityDate               = 3;
FIELD_IDX_T S_AccPerParam_NatEn                      = 4;
FIELD_IDX_T S_AccPerParam_Val                        = 5;
FIELD_IDX_T S_AccPerParam_ValText                    = 6;
FIELD_IDX_T S_AccPerParam_ValDate                    = 7;
FIELD_IDX_T S_AccPerParam_UpdFlg                     = 8;
FIELD_IDX_T S_AccPerParam_RoundUnit                  = 9;


FIELD_IDX_T A_AccPlan_Id                             = 0;
FIELD_IDX_T A_AccPlan_Cd                             = 1;
FIELD_IDX_T A_AccPlan_ParPtfId                       = 2;


FIELD_IDX_T S_AccPlan_Id                             = 0;
FIELD_IDX_T S_AccPlan_Cd                             = 1;


FIELD_IDX_T A_AccPlanElt_Id                          = 0;
FIELD_IDX_T A_AccPlanElt_Name                        = 1;
FIELD_IDX_T A_AccPlanElt_Denom                       = 2;
FIELD_IDX_T A_AccPlanElt_AccPerId                    = 3;
FIELD_IDX_T A_AccPlanElt_InstrId                     = 4;
FIELD_IDX_T A_AccPlanElt_AccNbr                      = 5;
FIELD_IDX_T A_AccPlanElt_Rank                        = 6;
FIELD_IDX_T A_AccPlanElt_NatEn                       = 7;
FIELD_IDX_T A_AccPlanElt_DataNatEn                   = 8;
FIELD_IDX_T A_AccPlanElt_DispNatEn                   = 9;
FIELD_IDX_T A_AccPlanElt_InvDataSignFlg              = 10;
FIELD_IDX_T A_AccPlanElt_DispQuantFlg                = 11;
FIELD_IDX_T A_AccPlanElt_ClassifFlg                  = 12;
FIELD_IDX_T A_AccPlanElt_DataSrcEn                   = 13;
FIELD_IDX_T A_AccPlanElt_ItemDisp                    = 14;
FIELD_IDX_T A_AccPlanElt_ItemNatEn                   = 15;
FIELD_IDX_T A_AccPlanElt_ScptDef                     = 16;
FIELD_IDX_T A_AccPlanElt_A_FundValElt_Ext            = 17;


FIELD_IDX_T S_AccPlanElt_Id                          = 0;
FIELD_IDX_T S_AccPlanElt_Name                        = 1;
FIELD_IDX_T S_AccPlanElt_AccPerId                    = 2;
FIELD_IDX_T S_AccPlanElt_AccNbr                      = 3;
FIELD_IDX_T S_AccPlanElt_Rank                        = 4;
FIELD_IDX_T S_AccPlanElt_NatEn                       = 5;

/*< PMSTA00488 - EFE -061101*/
FIELD_IDX_T A_AccProfile_Id                          = 0;
FIELD_IDX_T A_AccProfile_Cd                          = 1;
FIELD_IDX_T A_AccProfile_Remark                      = 2;
FIELD_IDX_T A_AccProfile_NatureEn                    = 3;
FIELD_IDX_T A_AccProfile_ClassifId                   = 4;

FIELD_IDX_T S_AccProfile_Id                          = 0;
FIELD_IDX_T S_AccProfile_Cd                          = 1;
FIELD_IDX_T S_AccProfile_NatureEn                    = 2;
FIELD_IDX_T S_AccProfile_ClassifId                   = 3;
FIELD_IDX_T S_AccProfile_ClassifCd                   = 4;

FIELD_IDX_T A_AccProfileCompo_Id                     = 0;
FIELD_IDX_T A_AccProfileCompo_AccProfileId           = 1;
FIELD_IDX_T A_AccProfileCompo_NatureEn               = 2;
FIELD_IDX_T A_AccProfileCompo_FusRuleEn              = 3;
FIELD_IDX_T A_AccProfileCompo_InstrId                = 4;
FIELD_IDX_T A_AccProfileCompo_InstrNatEn             = 5;
FIELD_IDX_T A_AccProfileCompo_InstrTypeId            = 6;
FIELD_IDX_T A_AccProfileCompo_InstrSubtypeId         = 7;
FIELD_IDX_T A_AccProfileCompo_BegDate                = 8;
FIELD_IDX_T A_AccProfileCompo_EndDate                = 9;

FIELD_IDX_T S_AccProfileCompo_Id                     = 0;
FIELD_IDX_T S_AccProfileCompo_AccProfileId           = 1;
FIELD_IDX_T S_AccProfileCompo_NatureEn               = 2;
FIELD_IDX_T S_AccProfileCompo_FusRuleEn              = 3;
FIELD_IDX_T S_AccProfileCompo_InstrId                = 4;
FIELD_IDX_T S_AccProfileCompo_InstrNatEn             = 5;
FIELD_IDX_T S_AccProfileCompo_InstrTypeId            = 6;
FIELD_IDX_T S_AccProfileCompo_InstrSubtypeId         = 7;
FIELD_IDX_T S_AccProfileCompo_BegDate                = 8;
FIELD_IDX_T S_AccProfileCompo_InstrCd                = 9;
FIELD_IDX_T S_AccProfileCompo_TypeCd                 = 10;
FIELD_IDX_T S_AccProfileCompo_SubtypeCd              = 11;


FIELD_IDX_T A_AccProfileHisto_PtfId                  = 0;
FIELD_IDX_T A_AccProfileHisto_AccProfileId           = 1;
FIELD_IDX_T A_AccProfileHisto_BegDate                = 2;
FIELD_IDX_T A_AccProfileHisto_EndDate                = 3;

FIELD_IDX_T S_AccProfileHisto_PtfId                  = 0;
FIELD_IDX_T S_AccProfileHisto_AccProfileId           = 1;
FIELD_IDX_T S_AccProfileHisto_BegDate                = 2;
FIELD_IDX_T S_AccProfileHisto_EndDate                = 3;
FIELD_IDX_T S_AccProfileHisto_AccCode                = 4;


FIELD_IDX_T A_AdminMgr_Id                            = 0;


FIELD_IDX_T A_ApplMsg_Id                             = 0;
FIELD_IDX_T A_ApplMsg_Cd                             = 1;
FIELD_IDX_T A_ApplMsg_Denom                          = 2;
FIELD_IDX_T A_ApplMsg_NatEn                          = 3;


FIELD_IDX_T S_ApplMsg_Id                             = 0;
FIELD_IDX_T S_ApplMsg_Cd                             = 1;
FIELD_IDX_T S_ApplMsg_Denom                          = 2;
FIELD_IDX_T S_ApplMsg_NatEn                          = 3;


FIELD_IDX_T A_ApplMsgTxt_MsgId                       = 0;
FIELD_IDX_T A_ApplMsgTxt_LangDictId                  = 1;
FIELD_IDX_T A_ApplMsgTxt_MsgTxt                      = 2;
FIELD_IDX_T A_ApplMsgTxt_LastModifDate               = 3;       /*  HFI-PMSTA-28976-180228  */
FIELD_IDX_T A_ApplMsgTxt_LastUserId                  = 4;       /*  HFI-PMSTA-28976-180228  */


FIELD_IDX_T S_ApplMsgTxt_MsgId                       = 0;
FIELD_IDX_T S_ApplMsgTxt_LangDictId                  = 1;
FIELD_IDX_T S_ApplMsgTxt_MsgTxt                      = 2;
FIELD_IDX_T S_ApplMsgTxt_MsgCd                       = 3;
FIELD_IDX_T S_ApplMsgTxt_LangName                    = 4;


FIELD_IDX_T A_ApplPswdHist_Id                        = 0;
FIELD_IDX_T A_ApplPswdHist_UserId                    = 1;
FIELD_IDX_T A_ApplPswdHist_CreationDate              = 2;
FIELD_IDX_T A_ApplPswdHist_CryptedPswd               = 3;
FIELD_IDX_T A_ApplPswdHist_DataSecuProfId            = 4; /* PMSTA-22305- DDV - 160509 */


FIELD_IDX_T A_ApplRule_Id                            = 0;
FIELD_IDX_T A_ApplRule_Cd                            = 1;
FIELD_IDX_T A_ApplRule_Denom                         = 2;
FIELD_IDX_T A_ApplRule_EntDictId                     = 3;


FIELD_IDX_T S_ApplRule_Id                            = 0;
FIELD_IDX_T S_ApplRule_Cd                            = 1;
FIELD_IDX_T S_ApplRule_Denom                         = 2;


FIELD_IDX_T A_Archive_Id                             = 0;
FIELD_IDX_T A_Archive_ArcEntDictId                   = 1;
FIELD_IDX_T A_Archive_EntDictId                      = 2;
FIELD_IDX_T A_Archive_DimEntDictId                   = 3;
FIELD_IDX_T A_Archive_ObjectId                       = 4;
FIELD_IDX_T A_Archive_Date                           = 5;
FIELD_IDX_T A_Archive_Nature                         = 6;
FIELD_IDX_T A_Archive_AllFlg                         = 7;
FIELD_IDX_T A_Archive_FileName                       = 8;
FIELD_IDX_T A_Archive_ArcEnt_cd                      = 9;
FIELD_IDX_T A_Archive_Ent_cd                         = 10;
FIELD_IDX_T A_Archive_DimEnt_cd                      = 11;
FIELD_IDX_T A_Archive_Object_cd                      = 12;
FIELD_IDX_T A_Archive_Nature_cd                      = 13;
FIELD_IDX_T A_Archive_ReturnStatus                   = 14;

FIELD_IDX_T S_Archive_Id                             = 0;
FIELD_IDX_T S_Archive_ArcEntDictId                   = 1;
FIELD_IDX_T S_Archive_EntDictId                      = 2;
FIELD_IDX_T S_Archive_DimEntDictId                   = 3;
FIELD_IDX_T S_Archive_ObjectId                       = 4;
FIELD_IDX_T S_Archive_Date                           = 5;
FIELD_IDX_T S_Archive_Nature                         = 6;
FIELD_IDX_T S_Archive_AllFlg                         = 7;
FIELD_IDX_T S_Archive_FileName                       = 8;
FIELD_IDX_T S_Archive_Object_cd                      = 9;


FIELD_IDX_T A_Audit_Hostname                         = 0;
FIELD_IDX_T A_Audit_User                             = 1;
FIELD_IDX_T A_Audit_EntityDictId                     = 2;
FIELD_IDX_T A_Audit_FctDictId                        = 3;
FIELD_IDX_T A_Audit_ActionEn                         = 4;
FIELD_IDX_T A_Audit_ModuleEn                         = 5;
FIELD_IDX_T A_Audit_CreationDate                     = 6;
FIELD_IDX_T A_Audit_MapId                            = 7;
FIELD_IDX_T A_Audit_EntityNatEn                      = 8;
FIELD_IDX_T A_Audit_Data                             = 9;


FIELD_IDX_T A_BalPos_Id                              = 0;
FIELD_IDX_T A_BalPos_PtfId                           = 1;
FIELD_IDX_T A_BalPos_PtfPosSetId                     = 2;
FIELD_IDX_T A_BalPos_InstrId                         = 3;
FIELD_IDX_T A_BalPos_BalPosTpId                      = 4;
FIELD_IDX_T A_BalPos_PosCurrId                       = 5;
FIELD_IDX_T A_BalPos_InstrCurrId                     = 6;
FIELD_IDX_T A_BalPos_PtfCurrId                       = 7;
FIELD_IDX_T A_BalPos_OpenOpId                        = 8;
FIELD_IDX_T A_BalPos_CloseOpId                       = 9;
FIELD_IDX_T A_BalPos_TermTpId                        = 10;
FIELD_IDX_T A_BalPos_LockTpId                        = 11;
FIELD_IDX_T A_BalPos_OpenOpNatEn                     = 12;
FIELD_IDX_T A_BalPos_AdjustNatEn                     = 13;
FIELD_IDX_T A_BalPos_OpenOpCd                        = 14;
FIELD_IDX_T A_BalPos_CloseOpCd                       = 15;
FIELD_IDX_T A_BalPos_RefOpCd                         = 16;
FIELD_IDX_T A_BalPos_RefNatEn                        = 17;
FIELD_IDX_T A_BalPos_ExecOpCd                        = 18;
FIELD_IDX_T A_BalPos_ExecOpNatEn                     = 19;
FIELD_IDX_T A_BalPos_ExecOpStatEn                    = 20;
FIELD_IDX_T A_BalPos_RevOpCd                         = 21;
FIELD_IDX_T A_BalPos_RevOpNatEn                      = 22;
FIELD_IDX_T A_BalPos_EventCd                         = 23;
FIELD_IDX_T A_BalPos_EventNbr                        = 24;
FIELD_IDX_T A_BalPos_StatEn                          = 25;
FIELD_IDX_T A_BalPos_PrimaryEn                       = 26;
FIELD_IDX_T A_BalPos_MainFlag                        = 27;
FIELD_IDX_T A_BalPos_PosNatEn                        = 28;
FIELD_IDX_T A_BalPos_Fus                             = 29;
FIELD_IDX_T A_BalPos_FusRuleEn                       = 30;
FIELD_IDX_T A_BalPos_BegDate                         = 31;
FIELD_IDX_T A_BalPos_EndDate                         = 32;
FIELD_IDX_T A_BalPos_OpDate                          = 33;
FIELD_IDX_T A_BalPos_AcctDate                        = 34;
FIELD_IDX_T A_BalPos_ValDate                         = 35;
FIELD_IDX_T A_BalPos_Remark                          = 36;
FIELD_IDX_T A_BalPos_PosExchRate                     = 37;
FIELD_IDX_T A_BalPos_InstrExchRate                   = 38;
FIELD_IDX_T A_BalPos_SysExchRate                     = 39;
FIELD_IDX_T A_BalPos_Qty                             = 40;
FIELD_IDX_T A_BalPos_Price                           = 41;
FIELD_IDX_T A_BalPos_PosGrossAmt                     = 42;
FIELD_IDX_T A_BalPos_PosNetAmt                       = 43;
FIELD_IDX_T A_BalPos_InstrGrossAmt                   = 44;
FIELD_IDX_T A_BalPos_InstrNetAmt                     = 45;
FIELD_IDX_T A_BalPos_PtfGrossAmt                     = 46;
FIELD_IDX_T A_BalPos_PtfNetAmt                       = 47;
FIELD_IDX_T A_BalPos_SysGrossAmt                     = 48;
FIELD_IDX_T A_BalPos_SysNetAmt                       = 49;
FIELD_IDX_T A_BalPos_Bp1PosAmt                       = 50;
FIELD_IDX_T A_BalPos_Bp2PosAmt                       = 51;
FIELD_IDX_T A_BalPos_Bp3PosAmt                       = 52;
FIELD_IDX_T A_BalPos_Bp4PosAmt                       = 53;
FIELD_IDX_T A_BalPos_Bp5PosAmt                       = 54;
FIELD_IDX_T A_BalPos_Bp6PosAmt                       = 55;
FIELD_IDX_T A_BalPos_Bp7PosAmt                       = 56;
FIELD_IDX_T A_BalPos_Bp8PosAmt                       = 57;
FIELD_IDX_T A_BalPos_Bp9PosAmt                       = 58;
FIELD_IDX_T A_BalPos_Bp10PosAmt                      = 59;
FIELD_IDX_T A_BalPos_TimingRuleEn                    = 60;


FIELD_IDX_T S_BalPos_Id                              = 0;


FIELD_IDX_T A_BalPosRule_Id                          = 0;
FIELD_IDX_T A_BalPosRule_SetId                       = 1;
FIELD_IDX_T A_BalPosRule_BpTpId                      = 2;
FIELD_IDX_T A_BalPosRule_OpTpId                      = 3;
FIELD_IDX_T A_BalPosRule_Rank                        = 4;


FIELD_IDX_T S_BalPosRule_Id                          = 0;
FIELD_IDX_T S_BalPosRule_BpTpCd                      = 1;
FIELD_IDX_T S_BalPosRule_OpTpCd                      = 2;


FIELD_IDX_T A_BalPosRuleSet_Id                       = 0;
FIELD_IDX_T A_BalPosRuleSet_Cd                       = 1;
FIELD_IDX_T A_BalPosRuleSet_Name                     = 2;
FIELD_IDX_T A_BalPosRuleSet_Denom                    = 3;
FIELD_IDX_T A_BalPosRuleSet_DfltFlg                  = 4;


FIELD_IDX_T S_BalPosRuleSet_Id                       = 0;
FIELD_IDX_T S_BalPosRuleSet_Cd                       = 1;
FIELD_IDX_T S_BalPosRuleSet_Name                     = 2;


FIELD_IDX_T A_BalPosTp_Id                            = 0;
FIELD_IDX_T A_BalPosTp_Cd                            = 1;
FIELD_IDX_T A_BalPosTp_Name                          = 2;
FIELD_IDX_T A_BalPosTp_Denom                         = 3;
FIELD_IDX_T A_BalPosTp_NatEn                         = 4;
FIELD_IDX_T A_BalPosTp_Rank                          = 5;
FIELD_IDX_T	A_BalPosTp_ParentBpTypeId                = 6; /* WEALTH-5030 - CHANDRU - 05022024 */


FIELD_IDX_T S_BalPosTp_Id                            = 0;
FIELD_IDX_T S_BalPosTp_Cd                            = 1;
FIELD_IDX_T S_BalPosTp_NatEn                         = 2;
FIELD_IDX_T S_BalPosTp_Rank                          = 3;



FIELD_IDX_T A_ObjectLnk_Id                           = 0; /* REF9770 - LJE - 031217 */
FIELD_IDX_T A_ObjectLnk_Nature                       = 1;
FIELD_IDX_T A_ObjectLnk_Rank                         = 2;
FIELD_IDX_T A_ObjectLnk_FromEntDictId                = 3;
FIELD_IDX_T A_ObjectLnk_FromObjectId                 = 4;
FIELD_IDX_T A_ObjectLnk_FromBreakCriteria            = 5; /* REF9264 - LJE - 030630 */
FIELD_IDX_T A_ObjectLnk_ToEntDictId                  = 6;
FIELD_IDX_T A_ObjectLnk_ToObjectId                   = 7;
FIELD_IDX_T A_ObjectLnk_ToBreakCriteria              = 8; /* REF9264 - LJE - 030630 */
FIELD_IDX_T A_ObjectLnk_BeginDate                    = 9;
FIELD_IDX_T A_ObjectLnk_EndDate                      =10;
FIELD_IDX_T A_ObjectLnk_MinOnLineDate                =11;
FIELD_IDX_T A_ObjectLnk_MaxOnLineDate                =12;


FIELD_IDX_T A_BookValue_PtfNetAmt                    = 0;
FIELD_IDX_T A_BookValue_OpNetAmt                     = 1;
FIELD_IDX_T A_BookValue_InstrNetAmt                  = 2;
FIELD_IDX_T A_BookValue_SysNetAmt                    = 3;
FIELD_IDX_T A_BookValue_OpExchRate                   = 4;
FIELD_IDX_T A_BookValue_InstrExchRate                = 5;
FIELD_IDX_T A_BookValue_SysExchRate                  = 6;
FIELD_IDX_T A_BookValue_Price                        = 7;
FIELD_IDX_T A_BookValue_Quote                        = 8;
FIELD_IDX_T A_BookValue_ValRuleEltId                 = 9;
FIELD_IDX_T A_BookValue_EvalRuleEn                   = 10;
FIELD_IDX_T A_BookValue_MaxConstrEn                  = 11;
FIELD_IDX_T A_BookValue_ValRuleId                    = 12;
FIELD_IDX_T A_BookValue_ValRuleHistId                = 13;


FIELD_IDX_T A_Calendar_Id                            = 0;
FIELD_IDX_T A_Calendar_Cd                            = 1;
FIELD_IDX_T A_Calendar_Name                          = 2;
FIELD_IDX_T A_Calendar_Denom                         = 3;
FIELD_IDX_T A_Calendar_BusinessDateRuleEn            = 4;
FIELD_IDX_T A_Calendar_NextBusinessDateRuleEn        = 5;
FIELD_IDX_T A_Calendar_AddDaysNum                    = 6;


FIELD_IDX_T S_Calendar_Id                            = 0;
FIELD_IDX_T S_Calendar_Cd                            = 1;
FIELD_IDX_T S_Calendar_Name                          = 2;


FIELD_IDX_T A_CalendarDate_Id                        = 0;
FIELD_IDX_T A_CalendarDate_CalendarId                = 1;
FIELD_IDX_T A_CalendarDate_Date                      = 2;
FIELD_IDX_T A_CalendarDate_Denom                     = 3;
FIELD_IDX_T A_CalendarDate_NatEn                     = 4;


FIELD_IDX_T S_CalendarDate_Id                        = 0;
FIELD_IDX_T S_CalendarDate_CalendarId                = 1;
FIELD_IDX_T S_CalendarDate_Date                      = 2;
FIELD_IDX_T S_CalendarDate_NatEn                     = 3;


FIELD_IDX_T A_CalendarConv_Id                        = 0;
FIELD_IDX_T A_CalendarConv_CalendarId                = 1;
FIELD_IDX_T A_CalendarConv_Term                      = 2;
FIELD_IDX_T A_CalendarConv_WeekdayEn                 = 3;
FIELD_IDX_T A_CalendarConv_Day                       = 4;
FIELD_IDX_T A_CalendarConv_AnchorDayEn               = 5;
FIELD_IDX_T A_CalendarConv_Denom                     = 6;
FIELD_IDX_T A_CalendarConv_NatEn                     = 7;
FIELD_IDX_T A_CalendarConv_OffsetSaturdayEn          = 8;
FIELD_IDX_T A_CalendarConv_OffsetSundayEn            = 9;


FIELD_IDX_T S_CalendarConv_Id                        = 0;
FIELD_IDX_T S_CalendarConv_CalendarId                = 1;
FIELD_IDX_T S_CalendarConv_Term                      = 2;
FIELD_IDX_T S_CalendarConv_WeekdayEn                 = 3;
FIELD_IDX_T S_CalendarConv_Day                       = 4;
FIELD_IDX_T S_CalendarConv_AnchorDayEn               = 5;
FIELD_IDX_T S_CalendarConv_Denom                     = 6;
FIELD_IDX_T S_CalendarConv_NatEn                     = 7;
FIELD_IDX_T S_CalendarConv_CalendarCd                = 8;

FIELD_IDX_T A_CaseClarification_Id                   = 0;
FIELD_IDX_T A_CaseClarification_Cd                   = 1;
FIELD_IDX_T A_CaseClarification_CaseId               = 2;
FIELD_IDX_T A_CaseClarification_Reason               = 3;
FIELD_IDX_T A_CaseClarification_LastUserId           = 4;
FIELD_IDX_T A_CaseClarification_LastModifDate        = 5;
FIELD_IDX_T A_CaseClarification_TpId                 = 6;
FIELD_IDX_T A_CaseClarification_OldCaseId            = 7;

FIELD_IDX_T S_CaseClarification_Id                   = 0;
FIELD_IDX_T S_CaseClarification_Cd                   = 1;
FIELD_IDX_T S_CaseClarification_CaseId               = 2;
FIELD_IDX_T S_CaseClarification_Reason               = 3;
FIELD_IDX_T S_CaseClarification_LastUserId           = 4;
FIELD_IDX_T S_CaseClarification_LastModifDate        = 5;
FIELD_IDX_T S_CaseClarification_TpId                 = 6;

FIELD_IDX_T A_CaseLink_Id                            = 0;
FIELD_IDX_T A_CaseLink_CaseId                        = 1;
FIELD_IDX_T A_CaseLink_EntDictId                     = 2;
FIELD_IDX_T A_CaseLink_ObjId                         = 3;
FIELD_IDX_T A_CaseLink_OldCaseId                     = 4;

FIELD_IDX_T S_CaseLink_Id                            = 0;
FIELD_IDX_T S_CaseLink_CaseId                        = 1;
FIELD_IDX_T S_CaseLink_EntDictId                     = 2;
FIELD_IDX_T S_CaseLink_ObjId                         = 3;

FIELD_IDX_T A_CaseMsgTemplate_Id                     = 0;
FIELD_IDX_T A_CaseMsgTemplate_Cd                     = 1;
FIELD_IDX_T A_CaseMsgTemplate_Denom                  = 2;
FIELD_IDX_T A_CaseMsgTemplate_CaseNatEn              = 3;
FIELD_IDX_T A_CaseMsgTemplate_CaseSubNatEn           = 4;
FIELD_IDX_T A_CaseMsgTemplate_CaseTpId               = 5;
FIELD_IDX_T A_CaseMsgTemplate_Priority               = 6;
FIELD_IDX_T A_CaseMsgTemplate_MainEntDictId          = 7;
FIELD_IDX_T A_CaseMsgTemplate_DefaultLanguage        = 8;
FIELD_IDX_T A_CaseMsgTemplate_LastUserId             = 9;
FIELD_IDX_T A_CaseMsgTemplate_LastModifDate          = 10;

FIELD_IDX_T S_CaseMsgTemplate_Id                     = 0;
FIELD_IDX_T S_CaseMsgTemplate_Cd                     = 1;
FIELD_IDX_T S_CaseMsgTemplate_Denom                  = 2;
FIELD_IDX_T S_CaseMsgTemplate_CaseNatEn              = 3;
FIELD_IDX_T S_CaseMsgTemplate_CaseSubNatEn           = 4;
FIELD_IDX_T S_CaseMsgTemplate_CaseTpId               = 5;
FIELD_IDX_T S_CaseMsgTemplate_Priority               = 6;

/* PMSTA07121-DDV-081212 */
FIELD_IDX_T A_CaseMsgTemplateDef_Id                  = 0;
FIELD_IDX_T A_CaseMsgTemplateDef_TemplateId          = 1;
FIELD_IDX_T A_CaseMsgTemplateDef_LangDictId          = 2;
FIELD_IDX_T A_CaseMsgTemplateDef_MainEntDictId       = 3;

FIELD_IDX_T S_CaseMsgTemplateDef_Id                  = 0;
FIELD_IDX_T S_CaseMsgTemplateDef_TemplateId          = 1;
FIELD_IDX_T S_CaseMsgTemplateDef_LangDictId          = 2;
FIELD_IDX_T S_CaseMsgTemplateDef_TemplateCd          = 3;
FIELD_IDX_T S_CaseMsgTemplateDef_LanguageName        = 4;

/* PMSTA- 18760 -cashwini-140205 */
FIELD_IDX_T A_CaseRule_Id							 =0;
FIELD_IDX_T A_CaseRule_Cd							 =1;
FIELD_IDX_T A_CaseRule_Name							 =2;
FIELD_IDX_T A_CaseRule_Denom     					 =3;
FIELD_IDX_T A_CaseRule_FunctionDictId                =4;
FIELD_IDX_T A_CaseRule_EntityDictId                  =5;
FIELD_IDX_T A_CaseRule_ActiveFlag                    =6;

FIELD_IDX_T S_CaseRule_Id				        	 =0;
FIELD_IDX_T S_CaseRule_Cd			        		 =1;
FIELD_IDX_T S_CaseRule_Name		              		 =2;

/* cashwini-PMSTA-21045-150818 */
FIELD_IDX_T A_LombardCheck_Id                       = 0;
FIELD_IDX_T A_LombardCheck_FunctionResultId         = 1;
FIELD_IDX_T A_LombardCheck_PtfId                    = 2;
FIELD_IDX_T A_LombardCheck_ThirdId                  = 3;
FIELD_IDX_T A_LombardCheck_CurrId                   = 4;
FIELD_IDX_T A_LombardCheck_InstrId                  = 5;
FIELD_IDX_T A_LombardCheck_MarketVal                = 6;
FIELD_IDX_T A_LombardCheck_MarginVal                = 7;
FIELD_IDX_T A_LombardCheck_Liabilities              = 8;
FIELD_IDX_T A_LombardCheck_SurplusDeficit           = 9;
FIELD_IDX_T A_LombardCheck_CheckResult              = 10;

FIELD_IDX_T S_LombardCheck_Id                       = 0;
FIELD_IDX_T S_LombardCheck_FunctionResultId         = 1;
FIELD_IDX_T S_LombardCheck_PtfId                    = 2;
FIELD_IDX_T S_LombardCheck_ThirdId                  = 3;
FIELD_IDX_T S_LombardCheck_InstrId                  = 4;
FIELD_IDX_T S_LombardCheck_FunctionResultCd         = 5;
FIELD_IDX_T S_LombardCheck_PtfCd                    = 6;
FIELD_IDX_T S_LombardCheck_ThirdCd                  = 7;
FIELD_IDX_T S_LombardCheck_InstrCd                  = 8;

FIELD_IDX_T A_CheckList_EntDictId                    = 0;
FIELD_IDX_T A_CheckList_ObjId                        = 1;

FIELD_IDX_T A_Classif_Id                             = 0;
FIELD_IDX_T A_Classif_Cd                             = 1;
FIELD_IDX_T A_Classif_Name                           = 2;
FIELD_IDX_T A_Classif_Denom                          = 3;
FIELD_IDX_T A_Classif_EntDictId                      = 4;
FIELD_IDX_T A_Classif_DataSecuProfId                 = 5; /*PMSTA07407-BRO-090529*/


FIELD_IDX_T S_Classif_Id                             = 0;
FIELD_IDX_T S_Classif_Cd                             = 1;
FIELD_IDX_T S_Classif_Name                           = 2;
FIELD_IDX_T S_Classif_EntDictId                      = 3;


FIELD_IDX_T A_ClassifCompo_ListId                    = 0;
FIELD_IDX_T A_ClassifCompo_ClassifId                 = 1;
FIELD_IDX_T A_ClassifCompo_Rank                      = 2;
FIELD_IDX_T A_ClassifCompo_Priority                  = 3;


FIELD_IDX_T S_ClassifCompo_ListId                    = 0;
FIELD_IDX_T S_ClassifCompo_ClassifId                 = 1;
FIELD_IDX_T S_ClassifCompo_Rank                      = 2;
FIELD_IDX_T S_ClassifCompo_Priority                  = 3;
FIELD_IDX_T S_ClassifCompo_ListCd                    = 4;
FIELD_IDX_T S_ClassifCompo_ListName                  = 5;


FIELD_IDX_T E_ClassifCompo_ListId                    = 0;
FIELD_IDX_T E_ClassifCompo_Rank                      = 2;
FIELD_IDX_T E_ClassifCompo_Priority                  = 3;
FIELD_IDX_T E_ClassifCompo_List_EntDictId            = 7;
FIELD_IDX_T E_ClassifCompo_List_NatEn                = 10;
FIELD_IDX_T E_ClassifCompo_List_ValidPeriod          = 12;
FIELD_IDX_T E_ClassifCompo_List_HistoricalListFlg    = 14;
FIELD_IDX_T E_ClassifCompo_List_ScptDef              = 17;


/* PMSTA11221-PRS-110119 */
FIELD_IDX_T A_CheckScript_Cd                         = 0;
FIELD_IDX_T A_CheckScript_Rank						 = 1;
FIELD_IDX_T A_CheckScript_DefinitionC                = 2;
FIELD_IDX_T A_CheckScript_EntDictId                  = 3;
FIELD_IDX_T A_CheckScript_ProcName                   = 4;

/* PMSTA11221-PRS-110127 : definition for structure to pass args to stored-proc */
FIELD_IDX_T CheckScript_Arg_AttrDictId               = 0;

FIELD_IDX_T A_ClientConnect_UserCd                   = 0;
FIELD_IDX_T A_ClientConnect_Display                  = 1;
FIELD_IDX_T A_ClientConnect_ServId                   = 2;
FIELD_IDX_T A_ClientConnect_Status                   = 3;


FIELD_IDX_T S_ClientConnect_UserCd                   = 0;
FIELD_IDX_T S_ClientConnect_Display                  = 1;
FIELD_IDX_T S_ClientConnect_ServId                   = 2;
FIELD_IDX_T S_ClientConnect_ServName                 = 3;
FIELD_IDX_T S_ClientConnect_Status                   = 4;
FIELD_IDX_T S_ClientConnect_LoginTime                = 5;

FIELD_IDX_T A_CommMgr_Id                             = 0;


/*<REF11810-BRO-060612*/
FIELD_IDX_T A_Communication_Id                       = 0;
FIELD_IDX_T A_Communication_EntDictId				 = 1;  /*PMSTA-28772-NRAO-171017*/
FIELD_IDX_T A_Communication_OpId                     = 2;
FIELD_IDX_T A_Communication_CommDate                 = 3;
FIELD_IDX_T A_Communication_CommText                 = 4;
FIELD_IDX_T A_Communication_CommTypeId               = 5;
FIELD_IDX_T A_Communication_CommSrcTypeId            = 6;
FIELD_IDX_T A_Communication_CommThirdId              = 7;


FIELD_IDX_T S_Communication_Id                       = 0;
FIELD_IDX_T S_Communication_EntDictId				 = 1;  /*PMSTA-28772-NRAO-171017*/
FIELD_IDX_T S_Communication_OpId                     = 2;
FIELD_IDX_T S_Communication_CommSrcTypeId            = 3;
FIELD_IDX_T S_Communication_OpCd                     = 4;
FIELD_IDX_T S_Communication_CommSrcTypeCd            = 5;
/*>REF11810-BRO-060612*/


/*<PMSTA5345-EFE-080215*/
FIELD_IDX_T A_ComplianceChrono_PtfId                      = 0;
FIELD_IDX_T A_ComplianceChrono_StratId                    = 1;
FIELD_IDX_T A_ComplianceChrono_NatEn                      = 2;
FIELD_IDX_T A_ComplianceChrono_CompNatEn                  = 3;
FIELD_IDX_T A_ComplianceChrono_ValidDate                  = 4;
FIELD_IDX_T A_ComplianceChrono_SubNatTypeId               = 5;
FIELD_IDX_T A_ComplianceChrono_ThirdPartyId               = 6;
FIELD_IDX_T A_ComplianceChrono_Val                        = 7;
FIELD_IDX_T A_ComplianceChrono_CurrId                     = 8;
FIELD_IDX_T A_ComplianceChrono_Comment                    = 9;
FIELD_IDX_T A_ComplianceChrono_LastUserId                 = 10; /*PMSTA06578-BRO-080605*/
FIELD_IDX_T A_ComplianceChrono_LastModifDate              = 11; /*PMSTA06578-BRO-080605*/
FIELD_IDX_T A_ComplianceChrono_Min                        = 12; /*PMSTA-18426 - CHU - 141008*/
FIELD_IDX_T A_ComplianceChrono_Max                        = 13; /*PMSTA-18426 - CHU - 141008*/
FIELD_IDX_T A_ComplianceChrono_CriticalnessEn             = 14; /*PMSTA-18426 - CHU - 141008*/
FIELD_IDX_T A_ComplianceChrono_ConfidenceLevel            = 15; /*PMSTA-18426 - CHU - 141008*/
FIELD_IDX_T A_ComplianceChrono_TimeHorizon                = 16; /*PMSTA-18426 - CHU - 141008*/
FIELD_IDX_T A_ComplianceChrono_TimeHorizonUnitEn          = 17; /*PMSTA-18426 - CHU - 141008*/

FIELD_IDX_T S_ComplianceChrono_PtfId                      = 0;
FIELD_IDX_T S_ComplianceChrono_StratId                    = 1;
FIELD_IDX_T S_ComplianceChrono_NatEn                      = 2;
FIELD_IDX_T S_ComplianceChrono_CompNatEn                  = 3;
FIELD_IDX_T S_ComplianceChrono_ValidDate                  = 4;
FIELD_IDX_T S_ComplianceChrono_SubNatTypeId               = 5;
FIELD_IDX_T S_ComplianceChrono_ThirdPartyId               = 6;
FIELD_IDX_T S_ComplianceChrono_Val                        = 7;
FIELD_IDX_T S_ComplianceChrono_ConfidenceLevel            = 8;
FIELD_IDX_T S_ComplianceChrono_TimeHorizon                = 9;
FIELD_IDX_T S_ComplianceChrono_TimeHorizonUnitEn          = 10;
FIELD_IDX_T S_ComplianceChrono_PtfCd                      = 11;
FIELD_IDX_T S_ComplianceChrono_StratCd                    = 12;
FIELD_IDX_T S_ComplianceChrono_CurrCd                     = 13;
FIELD_IDX_T S_ComplianceChrono_ThirdPartyCd               = 14;
FIELD_IDX_T S_ComplianceChrono_SubNatTypeCd               = 15;
FIELD_IDX_T S_ComplianceChrono_CriticalnessEn             = 16; /*PMSTA-18426 - CHU - 141008*/

/*>PMSTA5345-EFE-080215*/

/*<PMSTA- 18634 - SHR - 140904 */
FIELD_IDX_T A_CompoundOrderRule_Id								=0;
FIELD_IDX_T A_CompoundOrderRule_Cd								=1;
FIELD_IDX_T A_CompoundOrderRule_Name							=2;
FIELD_IDX_T A_CompoundOrderRule_Denom							=3;
FIELD_IDX_T A_CompoundOrderRule_Denomination					=4;
FIELD_IDX_T A_CompoundOrderRule_CompoundOrderMasterElt			=5;

FIELD_IDX_T S_CompoundOrderRule_Id					=0;
FIELD_IDX_T S_CompoundOrderRule_Cd					=1;
FIELD_IDX_T S_CompoundOrderRule_Name				=2;
FIELD_IDX_T S_CompoundOrderRule_Denom				=3;
/*<PMSTA- 18634 - SHR - 140904 */

/*<PMSTA- 18634 - SHR - 140904 */
FIELD_IDX_T A_CompoundOrderMasterElt_Id						=0;
FIELD_IDX_T A_CompoundOrderMasterElt_Cd						=1;
FIELD_IDX_T A_CompoundOrderMasterElt_Name					=2;
FIELD_IDX_T A_CompoundOrderMasterElt_Denom					=3;
FIELD_IDX_T A_CompoundOrderMasterElt_CompoundOrderRuleId	=4;
FIELD_IDX_T A_CompoundOrderMasterElt_OpNature				=5;
FIELD_IDX_T A_CompoundOrderMasterElt_OpTypeId				=6;
FIELD_IDX_T A_CompoundOrderMasterElt_OpSubTypeId			=7;
FIELD_IDX_T A_CompoundOrderMasterElt_OpOrderTypeId			=8;
FIELD_IDX_T A_CompoundOrderMasterElt_ScreenDictId    		=9;
FIELD_IDX_T A_CompoundOrderMasterElt_Denomination			=10;
FIELD_IDX_T A_CompoundOrderMasterElt_CompoundOrderSlaveElt	=11;

FIELD_IDX_T S_CompoundOrderMasterElt_Id					=0;
FIELD_IDX_T S_CompoundOrderMasterElt_Cd					=1;
FIELD_IDX_T S_CompoundOrderMasterElt_Name				=2;
FIELD_IDX_T S_CompoundOrderMasterElt_OpNature			=3;
FIELD_IDX_T S_CompoundOrderMasterElt_OpTypeId			=4;
FIELD_IDX_T S_CompoundOrderMasterElt_OpSubTypeId		=5;
FIELD_IDX_T S_CompoundOrderMasterElt_OpOrderTypeId		=6;
/*<PMSTA- 18634 - SHR - 140904 */

/*<PMSTA- 18634 - SHR - 140904 */
FIELD_IDX_T A_CompoundOrderSlaveElt_Id						=0;
FIELD_IDX_T A_CompoundOrderSlaveElt_CompoundOrderMasterElt	=1;
FIELD_IDX_T A_CompoundOrderSlaveElt_Cd						=2;
FIELD_IDX_T A_CompoundOrderSlaveElt_Name					=3;
FIELD_IDX_T A_CompoundOrderSlaveElt_Denom					=4;
FIELD_IDX_T A_CompoundOrderSlaveElt_OpNature				=5;
FIELD_IDX_T A_CompoundOrderSlaveElt_OpTypeId				=6;
FIELD_IDX_T A_CompoundOrderSlaveElt_OpSubTypeId				=7;
FIELD_IDX_T A_CompoundOrderSlaveElt_OpOrderTypeId			=8;
FIELD_IDX_T A_CompoundOrderSlaveElt_ScreenDictId			=9;
FIELD_IDX_T A_CompoundOrderSlaveElt_Rank					=10;
FIELD_IDX_T A_CompoundOrderSlaveElt_LegNature				=11;
FIELD_IDX_T A_CompoundOrderSlaveElt_MaxLegNumber			=12;
FIELD_IDX_T A_CompoundOrderSlaveElt_Denomination			=13;


FIELD_IDX_T S_CompoundOrderSlaveElt_Id						=0;
FIELD_IDX_T S_CompoundOrderSlaveElt_CompoundOrderMasterElt	=1;
FIELD_IDX_T S_CompoundOrderSlaveElt_Cd						=1;
FIELD_IDX_T S_CompoundOrderSlaveElt_Name					=2;
FIELD_IDX_T S_CompoundOrderSlaveElt_OpNature				=3;
FIELD_IDX_T S_CompoundOrderSlaveElt_OpTypeId				=4;
FIELD_IDX_T S_CompoundOrderSlaveElt_OpSubTypeId				=5;
FIELD_IDX_T S_CompoundOrderSlaveElt_OpOrderTypeId			=6;
/*<PMSTA- 18634 - SHR - 140904 */


FIELD_IDX_T A_ConstraintBreach_Id                     = 0;
FIELD_IDX_T A_ConstraintBreach_NatureEn               = 1;
FIELD_IDX_T A_ConstraintBreach_StrategyEltId          = 2;
FIELD_IDX_T A_ConstraintBreach_ModelConstrEltId       = 3;
FIELD_IDX_T A_ConstraintBreach_TradingConstraintId    = 4;
FIELD_IDX_T A_ConstraintBreach_DraftOrderId           = 5;
FIELD_IDX_T A_ConstraintBreach_OrderId                = 6;
FIELD_IDX_T A_ConstraintBreach_PortfolioId            = 7;
FIELD_IDX_T A_ConstraintBreach_ExtOp_DraftOrderId_Ext = 8;	/* REF10533 - RAK - 040908 - Used for script (to avoid access in db and use ExtOp in hier) */
FIELD_IDX_T A_ConstraintBreach_ExtStrategyEltId       = 9;  /*PMSTA-50420 -Lalby- to use ese criticalness for dynamic severity */

FIELD_IDX_T S_ConstraintBreach_Id                    = 0;
FIELD_IDX_T S_ConstraintBreach_NatureEn              = 1;
FIELD_IDX_T S_ConstraintBreach_StrategyEltId         = 2;
FIELD_IDX_T S_ConstraintBreach_ModelConstrEltId      = 3;
FIELD_IDX_T S_ConstraintBreach_TradingConstraintId   = 4;
FIELD_IDX_T S_ConstraintBreach_DraftOrderId          = 5;
FIELD_IDX_T S_ConstraintBreach_OrderId               = 6;
FIELD_IDX_T S_ConstraintBreach_PortfolioId           = 7;
FIELD_IDX_T S_ConstraintBreach_Denom                 = 8;


FIELD_IDX_T A_ConstraintParameter_Id                 = 0;
FIELD_IDX_T A_ConstraintParameter_TemplateEltId      = 1;
FIELD_IDX_T A_ConstraintParameter_DimConstraintDictId = 2;
FIELD_IDX_T A_ConstraintParameter_ConstrObjId        = 3;
FIELD_IDX_T A_ConstraintParameter_InstrSetId         = 4;
FIELD_IDX_T A_ConstraintParameter_ObjectiveNbr       = 5;
FIELD_IDX_T A_ConstraintParameter_Date               = 6;
FIELD_IDX_T A_ConstraintParameter_OperatorEn         = 7;


FIELD_IDX_T S_ConstraintParameter_Id                 = 0;
FIELD_IDX_T S_ConstraintParameter_TemplateEltId      = 1;
FIELD_IDX_T S_ConstraintParameter_DimConstraintDictId = 2;
FIELD_IDX_T S_ConstraintParameter_ConstrObjId        = 3;


FIELD_IDX_T A_ConstrTemplate_Id                      = 0;
FIELD_IDX_T A_ConstrTemplate_Cd                      = 1;
FIELD_IDX_T A_ConstrTemplate_ConstrNatEn             = 2;
FIELD_IDX_T A_ConstrTemplate_Name                    = 3;
FIELD_IDX_T A_ConstrTemplate_Denom                   = 4;
FIELD_IDX_T A_ConstrTemplate_ActiveFlg               = 5;
FIELD_IDX_T A_ConstrTemplate_ParameterFlg            = 6;
FIELD_IDX_T A_ConstrTemplate_CriticalnessEn          = 7; /*REF11231-EFE-050705*/


FIELD_IDX_T S_ConstrTemplate_Id                      = 0;
FIELD_IDX_T S_ConstrTemplate_Cd                      = 1;
FIELD_IDX_T S_ConstrTemplate_ConstrNatEn             = 2;
FIELD_IDX_T S_ConstrTemplate_Name                    = 3;
FIELD_IDX_T S_ConstrTemplate_Denom                   = 4;


/*<REF10603-EFE-041018*/
FIELD_IDX_T A_CorporateAction_Id                         = 0;
FIELD_IDX_T A_CorporateAction_Cd                         = 1 ;
FIELD_IDX_T A_CorporateAction_InstrId                    = 2 ;
FIELD_IDX_T A_CorporateAction_SendRefCd                  = 3 ;
FIELD_IDX_T A_CorporateAction_ProviderId                 = 4 ;
FIELD_IDX_T A_CorporateAction_EvTypeId                   = 5 ;
FIELD_IDX_T A_CorporateAction_SubEvTypeId                = 6 ;
FIELD_IDX_T A_CorporateAction_MsgTypeId                  = 7 ;
FIELD_IDX_T A_CorporateAction_MandatoryEn                = 8;
FIELD_IDX_T A_CorporateAction_ProcessStatusEn            = 9 ;
FIELD_IDX_T A_CorporateAction_EffectiveDate              = 10 ;
FIELD_IDX_T A_CorporateAction_AnnounceDate               = 11 ;
FIELD_IDX_T A_CorporateAction_NexusStatusEn              = 12 ;
FIELD_IDX_T A_CorporateAction_ShortDescCd                = 13 ;


FIELD_IDX_T S_CorporateAction_Id                         = 0;
FIELD_IDX_T S_CorporateAction_Cd                         = 1;
FIELD_IDX_T S_CorporateAction_InstrId                    = 2;
FIELD_IDX_T S_CorporateAction_ProviderId                 = 3;
FIELD_IDX_T S_CorporateAction_AnnounceDate               = 4;
FIELD_IDX_T S_CorporateAction_ShortDescCd                = 5;
FIELD_IDX_T S_CorporateAction_TypeCd                     = 6;
FIELD_IDX_T S_CorporateAction_ProviderCd                 = 7;
/*>REF10603-EFE-041018*/


FIELD_IDX_T A_Curr_Id                                = 0;
FIELD_IDX_T A_Curr_Cd                                = 1;
FIELD_IDX_T A_Curr_Name                              = 2;
FIELD_IDX_T A_Curr_Denom                             = 3;
FIELD_IDX_T A_Curr_GeoId                             = 4;
FIELD_IDX_T A_Curr_ProvThirdId                       = 5;
FIELD_IDX_T A_Curr_LastExchThirdId                   = 6;
FIELD_IDX_T A_Curr_MktThirdId                        = 7;
FIELD_IDX_T A_Curr_LastExchTpId                      = 8;
FIELD_IDX_T A_Curr_CalendarId                        = 9;
FIELD_IDX_T A_Curr_AutoCreatedFlg                    = 10;
FIELD_IDX_T A_Curr_Rank                              = 11;
FIELD_IDX_T A_Curr_EuroExchRate                      = 12;
FIELD_IDX_T A_Curr_LastExchDate                      = 13;
FIELD_IDX_T A_Curr_RoundUnitEn                       = 14;
FIELD_IDX_T A_Curr_RoundRuleEn                       = 15;
FIELD_IDX_T A_Curr_LastNoteDate                      = 16;
FIELD_IDX_T A_Curr_EuroConvDate                      = 17;
FIELD_IDX_T A_Curr_LendingValRuleEltId               = 18;


FIELD_IDX_T S_Curr_Id                                = 0;
FIELD_IDX_T S_Curr_Cd                                = 1;
FIELD_IDX_T S_Curr_Name                              = 2;
FIELD_IDX_T S_Curr_Rank                              = 3;
FIELD_IDX_T S_Curr_CodifId                           = 4;


FIELD_IDX_T A_CurrChrono_CurrId                      = 0;
FIELD_IDX_T A_CurrChrono_UnderCurrId                 = 1;
FIELD_IDX_T A_CurrChrono_NatEn                       = 2;
FIELD_IDX_T A_CurrChrono_Date                        = 3;
FIELD_IDX_T A_CurrChrono_Val                         = 4;
FIELD_IDX_T A_CurrChrono_TimeDimEn                   = 5;
FIELD_IDX_T A_CurrChrono_ValidFlg                    = 6;


FIELD_IDX_T S_CurrChrono_CurrId                      = 0;
FIELD_IDX_T S_CurrChrono_UnderCurrId                 = 1;
FIELD_IDX_T S_CurrChrono_NatEn                       = 2;
FIELD_IDX_T S_CurrChrono_Date                        = 3;
FIELD_IDX_T S_CurrChrono_Val                         = 4;
FIELD_IDX_T S_CurrChrono_CurrCd                      = 5;
FIELD_IDX_T S_CurrChrono_UnderCurrCd                 = 6;


FIELD_IDX_T A_CurrFreq_FreqDate                      = 0;
FIELD_IDX_T A_CurrFreq_CurrId                        = 1;
FIELD_IDX_T A_CurrFreq_A_Curr_Ext                    = 2;


FIELD_IDX_T A_DataDesc_Id                            = 0;
FIELD_IDX_T A_DataDesc_RefDate                       = 1;
FIELD_IDX_T A_DataDesc_InstrId                       = 2;
FIELD_IDX_T A_DataDesc_DbFlg                         = 3;
FIELD_IDX_T A_DataDesc_A_DataDisp_Ext                = 4;


FIELD_IDX_T A_DataDisp_Id                            = 0;
FIELD_IDX_T A_DataDisp_DataDescId                    = 1;
FIELD_IDX_T A_DataDisp_RefDate                       = 2;
FIELD_IDX_T A_DataDisp_InstrId                       = 3;
FIELD_IDX_T A_DataDisp_ParInstrId                    = 4;
FIELD_IDX_T A_DataDisp_NumDays                       = 5;
FIELD_IDX_T A_DataDisp_ValueN                        = 6;
FIELD_IDX_T A_DataDisp_DbFlg                         = 7;
FIELD_IDX_T A_DataDisp_RateFreq                      = 8;
FIELD_IDX_T A_DataDisp_RateFreqUnitEn                = 9;
FIELD_IDX_T A_DataDisp_StartDate                     = 10;
FIELD_IDX_T A_DataDisp_A_DataDesc_Ext                = 11;


FIELD_IDX_T A_DataProf_Id                            = 0;
FIELD_IDX_T A_DataProf_Cd                            = 1;
FIELD_IDX_T A_DataProf_ApplUserId					 = 2;


FIELD_IDX_T S_DataProf_Id                            = 0;
FIELD_IDX_T S_DataProf_Cd                            = 1;


FIELD_IDX_T A_DataProfCompo_Id                       = 0;
FIELD_IDX_T A_DataProfCompo_DataProfId               = 1;
FIELD_IDX_T A_DataProfCompo_DataSecuProfId           = 2;
FIELD_IDX_T A_DataProfCompo_AuthUpdFlg               = 3;
FIELD_IDX_T A_DataProfCompo_AuthDelFlg               = 4;


FIELD_IDX_T S_DataProfCompo_Id                       = 0;
FIELD_IDX_T S_DataProfCompo_DataProfId               = 1;
FIELD_IDX_T S_DataProfCompo_DataSecuProfId           = 2;
FIELD_IDX_T S_DataProfCompo_AuthUpdFlg               = 3;
FIELD_IDX_T S_DataProfCompo_AuthDelFlg               = 4;
FIELD_IDX_T S_DataProfCompo_DataProfCd               = 5;
FIELD_IDX_T S_DataProfCompo_DataSecuProfCd           = 6;


FIELD_IDX_T A_DataSecuProf_Id                        = 0;
FIELD_IDX_T A_DataSecuProf_Cd                        = 1;

FIELD_IDX_T S_DataSecuProf_Id                        = 0;
FIELD_IDX_T S_DataSecuProf_Cd                        = 1;

/* PMSTA01389 - DDV - 070307 */
FIELD_IDX_T A_DataSetDef_EntityDictId                = 0;
FIELD_IDX_T A_DataSetDef_Rank                        = 1;
FIELD_IDX_T A_DataSetDef_DynType                     = 2;
FIELD_IDX_T A_DataSetDef_FieldList                   = 3;
FIELD_IDX_T A_DataSetDef_FilterScript                = 4;


/* PMSTA-18426 - CHU - 140922 */
FIELD_IDX_T A_ExtServiceCompo_Id                     = 0;
FIELD_IDX_T A_ExtServiceCompo_ExtServiceId           = 1;
FIELD_IDX_T A_ExtServiceCompo_Rank                   = 2;
FIELD_IDX_T A_ExtServiceCompo_DirectionEn            = 3;
FIELD_IDX_T A_ExtServiceCompo_SrcEntityDictId        = 4;
FIELD_IDX_T A_ExtServiceCompo_DestEntityDictId       = 5;
FIELD_IDX_T A_ExtServiceCompo_FormatId               = 6;
FIELD_IDX_T A_ExtServiceCompo_ScreenDictId           = 7;

/* PMSTA-18426 - CHU - 140922 */
FIELD_IDX_T S_ExtServiceCompo_Id                     = 0;
FIELD_IDX_T S_ExtServiceCompo_ExtServiceId           = 1;
FIELD_IDX_T S_ExtServiceCompo_ExtServiceCd           = 2;
FIELD_IDX_T S_ExtServiceCompo_Rank                   = 3;
FIELD_IDX_T S_ExtServiceCompo_DirectionEn            = 4;
FIELD_IDX_T S_ExtServiceCompo_SrcEntityDictId        = 5;
FIELD_IDX_T S_ExtServiceCompo_SrcEntityCd            = 6;
FIELD_IDX_T S_ExtServiceCompo_DestEntityDictId       = 7;
FIELD_IDX_T S_ExtServiceCompo_DestEntityCd           = 8;
FIELD_IDX_T S_ExtServiceCompo_FormatId               = 9;
FIELD_IDX_T S_ExtServiceCompo_FormatCd               = 10;
FIELD_IDX_T S_ExtServiceCompo_ScreenDictId           = 11;
FIELD_IDX_T S_ExtServiceCompo_ScreenCd               = 12;

/*  HFI-PMSTA-22496-160502  */
FIELD_IDX_T A_ExtServiceProf_Id                      = 0;
FIELD_IDX_T A_ExtServiceProf_Cd                      = 1;
FIELD_IDX_T A_ExtServiceProf_LastUserId              = 2;
FIELD_IDX_T A_ExtServiceProf_LastModifDate           = 3;

/*  HFI-PMSTA-22496-160502  */
FIELD_IDX_T S_ExtServiceProf_Id                      = 0;
FIELD_IDX_T S_ExtServiceProf_Cd                      = 1;

/*  HFI-PMSTA-22496-160502  */
FIELD_IDX_T A_ExtServiceProfCompo_Id                 = 0;
FIELD_IDX_T A_ExtServiceProfCompo_ProfileId          = 1;
FIELD_IDX_T A_ExtServiceProfCompo_ExtServId          = 2;
FIELD_IDX_T A_ExtServiceProfCompo_NatureEn           = 3;
FIELD_IDX_T A_ExtServiceProfCompo_FctDictId          = 4;
FIELD_IDX_T A_ExtServiceProfCompo_RankN              = 5;
FIELD_IDX_T A_ExtServiceProfCompo_LastUserId         = 6;
FIELD_IDX_T A_ExtServiceProfCompo_LastModifDate      = 7;


/*  HFI-PMSTA-22496-160502  */
FIELD_IDX_T S_ExtServiceProfCompo_Id                 = 0;
FIELD_IDX_T S_ExtServiceProfCompo_ProfileId          = 1;
FIELD_IDX_T S_ExtServiceProfCompo_ExtServId          = 2;
FIELD_IDX_T S_ExtServiceProfCompo_NatureEn           = 3;
FIELD_IDX_T S_ExtServiceProfCompo_FctDictId          = 4;
FIELD_IDX_T S_ExtServiceProfCompo_ProfileCd          = 5;
FIELD_IDX_T S_ExtServiceProfCompo_ExtServCd          = 6;
FIELD_IDX_T S_ExtServiceProfCompo_FctName            = 7;

/* < REF11767 - CHU - 060331 */
FIELD_IDX_T A_OptiProf_Id                            = 0;
FIELD_IDX_T A_OptiProf_Cd                            = 1;
FIELD_IDX_T A_OptiProf_Denom                         = 2;

FIELD_IDX_T S_OptiProf_Id                            = 0;
FIELD_IDX_T S_OptiProf_Cd                            = 1;

FIELD_IDX_T A_OptiProfCompo_Id                       = 0;
FIELD_IDX_T A_OptiProfCompo_OptiProfId               = 1;
FIELD_IDX_T A_OptiProfCompo_ProcId                   = 2;
FIELD_IDX_T A_OptiProfCompo_GlobalAlloc              = 3;
FIELD_IDX_T A_OptiProfCompo_GlobalMaxAlloc           = 4;
FIELD_IDX_T A_OptiProfCompo_LocalAlloc               = 5;
FIELD_IDX_T A_OptiProfCompo_LocalMaxAlloc            = 6;
FIELD_IDX_T A_OptiProfCompo_Remark                   = 7;
FIELD_IDX_T A_OptiProfCompo_EntityDictId             = 8;
FIELD_IDX_T A_OptiProfCompo_ProcSqlName              = 9;

FIELD_IDX_T S_OptiProfCompo_Id                       = 0;
FIELD_IDX_T S_OptiProfCompo_OptiProfId               = 1;
FIELD_IDX_T S_OptiProfCompo_ProcId                   = 2;
FIELD_IDX_T S_OptiProfCompo_EntityDictId             = 3;
FIELD_IDX_T S_OptiProfCompo_ProcSqlName              = 4;
FIELD_IDX_T S_OptiProfCompo_EntitySqlName            = 5;

FIELD_IDX_T A_OptiProc_Id                            = 0;
FIELD_IDX_T A_OptiProc_SqlName                       = 1;
FIELD_IDX_T A_OptiProc_EntityDictId                  = 2;

FIELD_IDX_T S_OptiProc_Id                            = 0;
FIELD_IDX_T S_OptiProc_SqlName                       = 1;
FIELD_IDX_T S_OptiProc_EntityDictId                  = 2;
FIELD_IDX_T S_OptiProc_EntitySqlName                 = 3;
/* > REF11767 - CHU - 060331 */

FIELD_IDX_T A_ApplComment_Id                         = 0; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_EntityDictId               = 1; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_ObjectId                   = 2; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_CreationDate               = 3; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_LastUserId                 = 4; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_LastModifDate              = 5; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_TypeId                     = 6; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_LanguageDictId             = 7; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_Comment                    = 8; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T A_ApplComment_SelectedEn                 = 9; /*PMSTA10733-TEB-101130*/

FIELD_IDX_T S_ApplComment_Id                         =0; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T S_ApplComment_EntityDictId               =1; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T S_ApplComment_ObjectId                   =2; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T S_ApplComment_CreationDate               =3; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T S_ApplComment_TypeId                     =4; /*PMSTA10733-TEB-101130*/
FIELD_IDX_T S_ApplComment_LanguageDictId             =5; /*PMSTA10733-TEB-101130*/

FIELD_IDX_T A_Denom_EntDictId                        = 0;
FIELD_IDX_T A_Denom_ObjId                            = 1;
FIELD_IDX_T A_Denom_LangEntDictId                    = 2;
FIELD_IDX_T A_Denom_Denom                            = 3;


FIELD_IDX_T S_Denom_EntDictId                        = 0;
FIELD_IDX_T S_Denom_ObjId                            = 1;
FIELD_IDX_T S_Denom_LangEntDictId                    = 2;
FIELD_IDX_T S_Denom_LangName                         = 3;
FIELD_IDX_T S_Denom_Denom                            = 4;


FIELD_IDX_T A_DerivedStrat_Id                        = 0;
FIELD_IDX_T A_DerivedStrat_StratId                   = 1;
FIELD_IDX_T A_DerivedStrat_PtfId                     = 2;
FIELD_IDX_T A_DerivedStrat_NatEn                     = 3;
FIELD_IDX_T A_DerivedStrat_BegD                      = 4;
FIELD_IDX_T A_DerivedStrat_LastModifDate             = 5;
FIELD_IDX_T A_DerivedStrat_A_DerivedStratElt_Ext     = 6;
FIELD_IDX_T A_DerivedStrat_RefStratId                = 7;


FIELD_IDX_T S_DerivedStrat_Id                        = 0;
FIELD_IDX_T S_DerivedStrat_StratId                   = 1;
FIELD_IDX_T S_DerivedStrat_PtfId                     = 2;
FIELD_IDX_T S_DerivedStrat_NatEn                     = 3; /* REF8844 - LJE - 030612 */
FIELD_IDX_T S_DerivedStrat_StratCd                   = 4;
FIELD_IDX_T S_DerivedStrat_PtfCd                     = 5;


FIELD_IDX_T A_DerivedStratElt_Id                     = 0;
FIELD_IDX_T A_DerivedStratElt_DerivedStratId         = 1;
FIELD_IDX_T A_DerivedStratElt_MktSgtId               = 2;
FIELD_IDX_T A_DerivedStratElt_InstrId                = 3;
FIELD_IDX_T A_DerivedStratElt_NatEn                  = 4;
FIELD_IDX_T A_DerivedStratElt_Weight                 = 5;
FIELD_IDX_T A_DerivedStratElt_FluctMargin            = 6;
FIELD_IDX_T A_DerivedStratElt_BenchEntDictId         = 7;
FIELD_IDX_T A_DerivedStratElt_BenchObjId             = 8;
FIELD_IDX_T A_DerivedStratElt_Rank                   = 9;
FIELD_IDX_T A_DerivedStratElt_OldWeight              = 10;
FIELD_IDX_T A_DerivedStratElt_WeightFactor           = 11;
FIELD_IDX_T A_DerivedStratElt_ContribValue           = 12;
FIELD_IDX_T A_DerivedStratElt_OldContribValue        = 13;

FIELD_IDX_T A_DictUser_DictId;
FIELD_IDX_T A_DictUser_UserName;
FIELD_IDX_T A_DictUser_Database;
FIELD_IDX_T A_DictUser_EnvironName;
FIELD_IDX_T A_DictUser_ApplOwnerFlg;
FIELD_IDX_T A_DictUser_TechnicalFlg;
FIELD_IDX_T A_DictUser_GroupName;


FIELD_IDX_T S_DictUser_DictId;
FIELD_IDX_T S_DictUser_UserName;

FIELD_IDX_T A_DictCriter_DictId                      = 0;
FIELD_IDX_T A_DictCriter_EntDictId                   = 1;
FIELD_IDX_T A_DictCriter_AttrDictId                  = 2;
FIELD_IDX_T A_DictCriter_Prog                        = 3;
FIELD_IDX_T A_DictCriter_SortRank                    = 4;
FIELD_IDX_T A_DictCriter_SortRuleEn                  = 5;
FIELD_IDX_T A_DictCriter_FkIndex                     = 6;
FIELD_IDX_T A_DictCriter_DynNat                      = 7;    /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T A_DictCriter_SqlName                     = 8;    /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T A_DictCriter_Index                       = 9;    /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T A_DictCriter_Par1Prog                    = 10;   /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T A_DictCriter_Par2Prog                    = 11;   /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T A_DictCriter_AttrEntDictId               = 12;   /*  FIH-REF11553-060217 */


FIELD_IDX_T S_DictCriter_DictId                      = 0;
FIELD_IDX_T S_DictCriter_EntDictId                   = 1;
FIELD_IDX_T S_DictCriter_AttrDictId                  = 2;
FIELD_IDX_T S_DictCriter_Prog                        = 3;
FIELD_IDX_T S_DictCriter_SortRank                    = 4;
FIELD_IDX_T S_DictCriter_DynNat                      = 5; /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T S_DictCriter_SqlName                     = 6; /* PMSTA-11903 - RPO - 110509 */
FIELD_IDX_T S_DictCriter_EntSqlName                  = 7; /*REF11553-BRO-051215*/
FIELD_IDX_T S_DictCriter_AttrSqlName                 = 8; /*REF11553-BRO-051215*/

/* PMSTA-13109 - LJE - 111122 */
FIELD_IDX_T A_DictDatabase_DictId                   ;
FIELD_IDX_T A_DictDatabase_Code                     ;
FIELD_IDX_T A_DictDatabase_SqlName                  ;

/* PMSTA-13109 - LJE - 111122 */
FIELD_IDX_T S_DictDatabase_DictId                   ;
FIELD_IDX_T S_DictDatabase_Code                     ;
FIELD_IDX_T S_DictDatabase_SqlName                  ;

/* PMSTA-13109 - LJE - 111122 */
FIELD_IDX_T A_DictSegment_DictId                    ;
FIELD_IDX_T A_DictSegment_Code                      ;
FIELD_IDX_T A_DictSegment_SqlName                   ;
FIELD_IDX_T A_DictSegment_DbDictId                  ;

/* PMSTA-13109 - LJE - 111122 */
FIELD_IDX_T S_DictSegment_DictId                    ;
FIELD_IDX_T S_DictSegment_Code                      ;
FIELD_IDX_T S_DictSegment_SqlName                   ;
FIELD_IDX_T S_DictSegment_DbDictId                  ;

FIELD_IDX_T A_DictDataTp_DictId                      = 0;
FIELD_IDX_T A_DictDataTp_Name                        = 1;
FIELD_IDX_T A_DictDataTp_SqlName                     = 2;
FIELD_IDX_T A_DictDataTp_EquivTp                     = 3;
FIELD_IDX_T A_DictDataTp_Prog                        = 4;
FIELD_IDX_T A_DictDataTp_CustAuthFlg                 = 5;


FIELD_IDX_T S_DictDataTp_DictId                      = 0;
FIELD_IDX_T S_DictDataTp_Name                        = 1;
FIELD_IDX_T S_DictDataTp_SqlName                     = 2; /* PMSTA-11505 - LJE - 110625 */

/*SHR - 150721 - PMSTA-17794*/

FIELD_IDX_T E_DictFct_DictId					        = 0;
FIELD_IDX_T E_DictFct_Name						        = 1;
FIELD_IDX_T E_DictFct_Label						        = 2;
FIELD_IDX_T E_DictFct_ProcName					        = 3;
FIELD_IDX_T E_DictFct_ParFctDictId				        = 4;
FIELD_IDX_T E_DictFct_EntDictId					        = 5;
FIELD_IDX_T E_DictFct_OrderEntryFctDictId               = 6;
FIELD_IDX_T E_DictFct_NatEn						        = 7;
FIELD_IDX_T E_DictFct_TypeId					        = 8;
FIELD_IDX_T E_DictFct_SubTypeId					        = 9;
FIELD_IDX_T E_DictFct_HelpNode					        = 10;
FIELD_IDX_T E_DictFct_IconName					        = 11;
FIELD_IDX_T E_DictFct_Rank						        = 12;
FIELD_IDX_T E_DictFct_FuncSecuProfId			        = 13;
FIELD_IDX_T E_DictFct_EntityDictId				        = 14;
FIELD_IDX_T E_DictFct_MinOpStatus				        = 15;
FIELD_IDX_T E_DictFct_MaxOpStatus				        = 16;
FIELD_IDX_T E_DictFct_SecurityLevel				        = 17;
FIELD_IDX_T E_DictFct_CreateFlg					        = 18;
FIELD_IDX_T E_DictFct_UpdateFlg					        = 19;
FIELD_IDX_T E_DictFct_DeleteFlg					        = 20;
FIELD_IDX_T E_DictFct_RiskViewFlg				        = 21;
FIELD_IDX_T E_DictFct_RealTimeFlg				        = 22;
FIELD_IDX_T E_DictFct_ViewFlg					        = 23;
FIELD_IDX_T E_DictFct_VisibleFlg				        = 24;
FIELD_IDX_T E_DictFct_LicenseKeyEn				        = 25;
FIELD_IDX_T E_DictFct_AccessStatus				        = 26;

FIELD_IDX_T A_DictLabel_LangDictId                   = 0;
FIELD_IDX_T A_DictLabel_EntDictId                    = 1;
FIELD_IDX_T A_DictLabel_ObjDictId                    = 2;
FIELD_IDX_T A_DictLabel_Name                         = 3;


FIELD_IDX_T S_DictLabel_LangDictId                   = 0;
FIELD_IDX_T S_DictLabel_EntDictId                    = 1;
FIELD_IDX_T S_DictLabel_ObjDictId                    = 2;
FIELD_IDX_T S_DictLabel_Name                         = 3;
FIELD_IDX_T S_DictLabel_LangName                     = 4;


FIELD_IDX_T A_DictLang_Id                            = 0;
FIELD_IDX_T A_DictLang_Cd                            = 1;
FIELD_IDX_T A_DictLang_Name                          = 2;
FIELD_IDX_T A_DictLang_Denom                         = 3;
FIELD_IDX_T A_DictLang_SqlName                       = 4;
FIELD_IDX_T A_DictLang_ThousSep                      = 5;
FIELD_IDX_T A_DictLang_DecimSep                      = 6;
FIELD_IDX_T A_DictLang_DateFmt                       = 7;
FIELD_IDX_T A_DictLang_TslMultilingualFlg            = 8;    /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */


FIELD_IDX_T S_DictLang_Id                            = 0;
FIELD_IDX_T S_DictLang_Cd                            = 1;
FIELD_IDX_T S_DictLang_Name                          = 2;
FIELD_IDX_T S_DictLang_SqlName = 3;
FIELD_IDX_T S_DictLang_CodifId = 4;


FIELD_IDX_T A_DictPanel_DictId                       = 0;
FIELD_IDX_T A_DictPanel_Name                         = 1;
FIELD_IDX_T A_DictPanel_ScreenDictId                 = 2;
FIELD_IDX_T A_DictPanel_AttribDictId                 = 3;
FIELD_IDX_T A_DictPanel_ParPanelDictId               = 4;
FIELD_IDX_T A_DictPanel_NatEn                        = 5;
FIELD_IDX_T A_DictPanel_WgtEn                        = 6;
FIELD_IDX_T A_DictPanel_Rank                         = 7;
FIELD_IDX_T A_DictPanel_LeftCoord                    = 8;
FIELD_IDX_T A_DictPanel_TopCoord                     = 9;
FIELD_IDX_T A_DictPanel_Width                        = 10;
FIELD_IDX_T A_DictPanel_Height                       = 11;
FIELD_IDX_T A_DictPanel_LabelWidth                   = 12;
FIELD_IDX_T A_DictPanel_LabelPosEn                   = 13;
FIELD_IDX_T A_DictPanel_FgColor                      = 14;
FIELD_IDX_T A_DictPanel_BgColor                      = 15;
FIELD_IDX_T A_DictPanel_PenEn                        = 16;
FIELD_IDX_T A_DictPanel_VertScrollBarFlg             = 17;
FIELD_IDX_T A_DictPanel_EditEn                       = 18;
FIELD_IDX_T A_DictPanel_MandatoryFlg                 = 19;
FIELD_IDX_T A_DictPanel_SecuLevelEn                  = 20;
FIELD_IDX_T A_DictPanel_KeyChar                      = 21;
FIELD_IDX_T A_DictPanel_FileName                     = 22;
FIELD_IDX_T A_DictPanel_DatatypeDictId               = 23;
FIELD_IDX_T A_DictPanel_AttachTopFlg                 = 24;
FIELD_IDX_T A_DictPanel_AttachBottomFlg              = 25;
FIELD_IDX_T A_DictPanel_AttachLeftFlg                = 26;
FIELD_IDX_T A_DictPanel_AttachRightFlg               = 27;
FIELD_IDX_T A_DictPanel_FixedWidthFlg                = 28;
FIELD_IDX_T A_DictPanel_FixedHeighFlg                = 29;
FIELD_IDX_T A_DictPanel_SubScreenDictId              = 30; /*REF9031-BRO-030714*/
FIELD_IDX_T A_DictPanel_Denom                        = 31;
FIELD_IDX_T A_DictPanel_PanelScriptDef               = 32;
FIELD_IDX_T A_DictPanel_AttachMask                   = 33;
FIELD_IDX_T A_DictPanel_WgtPtr                       = 34;
FIELD_IDX_T A_DictPanel_AttribIdx                    = 35;
FIELD_IDX_T A_DictPanel_A_ParPanel_Ext               = 36;
FIELD_IDX_T A_DictPanel_A_ChildPanel_Ext             = 37;
FIELD_IDX_T A_DictPanel_NotCopyScptFlg               = 40;
FIELD_IDX_T A_DictPanel_AvailabilityDef              = 41;  /*  FIH-REF10671-041025 */
FIELD_IDX_T A_DictPanel_HardCodedStateEn             = 42;  /*  FPL-REF10671-041109 */
FIELD_IDX_T A_DictPanel_CurrentStateEn               = 43;  /*  FPL-REF10671-041109 */


FIELD_IDX_T S_DictPanel_DictId                       = 0;
FIELD_IDX_T S_DictPanel_Name                         = 1;
FIELD_IDX_T S_DictPanel_ScreenDictId                 = 2;
FIELD_IDX_T S_DictPanel_AttribDictId                 = 3;
FIELD_IDX_T S_DictPanel_NatEn                        = 4;


FIELD_IDX_T A_DictScreen_DictId                      = 0;
FIELD_IDX_T A_DictScreen_Name                        = 1;
FIELD_IDX_T A_DictScreen_EntDictId                   = 2;
FIELD_IDX_T A_DictScreen_RuleId                      = 3;
FIELD_IDX_T A_DictScreen_Denom                       = 4;
FIELD_IDX_T A_DictScreen_ReferenceScreenDictId       = 5;


FIELD_IDX_T S_DictScreen_DictId                      = 0;
FIELD_IDX_T S_DictScreen_Name                        = 1;
FIELD_IDX_T S_DictScreen_EntDictId                   = 2;
FIELD_IDX_T S_DictScreen_EntSqlName                  = 3;


/* PMSTA-15655 - LJE - 130124 */
FIELD_IDX_T O_DictPermVal_AttrDictId                 = 0;
FIELD_IDX_T O_DictPermVal_AttrSqlName                = 1;
FIELD_IDX_T O_DictPermVal_PermValNatEn               = 2;
FIELD_IDX_T O_DictPermVal_PermValId                  = 3;
FIELD_IDX_T O_DictPermVal_Name                       = 4;
FIELD_IDX_T O_DictPermVal_Label                      = 5;
FIELD_IDX_T O_DictPermVal_Rank                       = 6;
FIELD_IDX_T O_DictPermVal_RefEntityDictId            = 7;
FIELD_IDX_T O_DictPermVal_PermValRuleEn              = 8;
FIELD_IDX_T O_DictPermVal_DefSelFlg                  = 9;


FIELD_IDX_T A_DictView_DictId                        = 0;
FIELD_IDX_T A_DictView_EntDictId                     = 1;
FIELD_IDX_T A_DictView_AuthSelFlg                    = 2;
FIELD_IDX_T A_DictView_AuthInsFlg                    = 3;
FIELD_IDX_T A_DictView_AuthUpdFlg                    = 4;
FIELD_IDX_T A_DictView_AutoFlg                       = 5;
FIELD_IDX_T A_DictView_LastBuildDate                 = 6;
FIELD_IDX_T A_DictView_ViewNatEn                     = 7;
FIELD_IDX_T A_DictView_Name                          = 8;


FIELD_IDX_T S_DictView_DictId                        = 0;
FIELD_IDX_T S_DictView_EntDictId                     = 1;
FIELD_IDX_T S_DictView_ViewNatEn                     = 2;
FIELD_IDX_T S_DictView_Name                          = 3;

/* PMSTA13244 - DDV - 120119 */
FIELD_IDX_T A_DictFctAttrib_DictId                   = 0;
FIELD_IDX_T A_DictFctAttrib_FctDictId                = 1;
FIELD_IDX_T A_DictFctAttrib_FmtId                    = 2; /* PMSTA13655 - DDV - 120305 */
FIELD_IDX_T A_DictFctAttrib_EntitySqlName            = 3;
FIELD_IDX_T A_DictFctAttrib_AttributeSqlName         = 4;
FIELD_IDX_T A_DictFctAttrib_KeyEncodingEn            = 5;

/* PMSTA13244 - DDV - 120119 */
FIELD_IDX_T S_DictFctAttrib_Id                       = 0;
FIELD_IDX_T S_DictFctAttrib_FctDictId                = 1;
FIELD_IDX_T S_DictFctAttrib_FmtId                    = 2; /* PMSTA13655 - DDV - 120305 */
FIELD_IDX_T S_DictFctAttrib_EntitySqlName            = 3;
FIELD_IDX_T S_DictFctAttrib_AttributeSqlName         = 4;
FIELD_IDX_T S_DictFctAttrib_KeyEncodingEn            = 5;
FIELD_IDX_T S_DictFctAttrib_FctName                  = 6;
FIELD_IDX_T S_DictFctAttrib_FmtCd                    = 7; /* PMSTA13655 - DDV - 120305 */

FIELD_IDX_T A_Doc_Id                                 = 0;
FIELD_IDX_T A_Doc_Cd                                 = 1;
FIELD_IDX_T A_Doc_Name                               = 2;
FIELD_IDX_T A_Doc_FolderId                           = 3;
FIELD_IDX_T A_Doc_FctId                              = 4;
FIELD_IDX_T A_Doc_DomainId                           = 5;
FIELD_IDX_T A_Doc_TiledFlg                           = 6;
FIELD_IDX_T A_Doc_Rank                               = 7;
FIELD_IDX_T A_Doc_LastNoteDate                       = 8;
FIELD_IDX_T A_Doc_A_Domain_Ext                       = 9;
FIELD_IDX_T A_Doc_A_DictFct_Ext                      = 10;


FIELD_IDX_T S_Doc_Id                                 = 0;
FIELD_IDX_T S_Doc_Cd                                 = 1;
FIELD_IDX_T S_Doc_Name                               = 2;


FIELD_IDX_T A_DocIndex_EntityDictId                  = 0;
FIELD_IDX_T A_DocIndex_PtfId                         = 1;
FIELD_IDX_T A_DocIndex_RefDate                       = 2;
FIELD_IDX_T A_DocIndex_NatEn                         = 3;
FIELD_IDX_T A_DocIndex_Index                         = 4;


FIELD_IDX_T S_DocIndex_EntityDictId                  = 0;
FIELD_IDX_T S_DocIndex_PtfId                         = 1;
FIELD_IDX_T S_DocIndex_RefDate                       = 2;
FIELD_IDX_T S_DocIndex_NatEn                         = 3;


FIELD_IDX_T A_Domain_Id                              = 0;
FIELD_IDX_T A_Domain_CurrId                          = 1;
FIELD_IDX_T A_Domain_DimPtfDictId                    = 2;
FIELD_IDX_T A_Domain_DimInstrDictId                  = 3;
FIELD_IDX_T A_Domain_DimStratDictId                  = 4;
FIELD_IDX_T A_Domain_UsrId                           = 5;
FIELD_IDX_T A_Domain_LangDictId                      = 6;
FIELD_IDX_T A_Domain_FctDictId                       = 7;
FIELD_IDX_T A_Domain_ScenaId                         = 8;
FIELD_IDX_T A_Domain_QuoteValRuleId                  = 9;
FIELD_IDX_T A_Domain_ExchValRuleId                   = 10;
FIELD_IDX_T A_Domain_PtfObjId                        = 11;
FIELD_IDX_T A_Domain_InstrObjId                      = 12;
FIELD_IDX_T A_Domain_StratObjId                      = 13;
FIELD_IDX_T A_Domain_ReportId                        = 14;
FIELD_IDX_T A_Domain_AccPeriodId                     = 15;
FIELD_IDX_T A_Domain_FctResultId                     = 16;
FIELD_IDX_T A_Domain_GridId                          = 17;
FIELD_IDX_T A_Domain_AccPlanId                       = 18;
FIELD_IDX_T A_Domain_BookPtfId                       = 19;
FIELD_IDX_T A_Domain_ConsPtfId                       = 20;
FIELD_IDX_T A_Domain_PortPosSetId                    = 21;
FIELD_IDX_T A_Domain_MktSegId                        = 22;
FIELD_IDX_T A_Domain_CashCurrId                      = 23;
FIELD_IDX_T A_Domain_BuyOrderRuleId                  = 24;
FIELD_IDX_T A_Domain_SellOrderRuleId                 = 25;
FIELD_IDX_T A_Domain_LastUserId                      = 26;
FIELD_IDX_T A_Domain_BuyPtfClassifId                 = 27;
FIELD_IDX_T A_Domain_SellPtfClassifId                = 28;
FIELD_IDX_T A_Domain_LastModifDate                   = 29;
FIELD_IDX_T A_Domain_FusDateRuleEn                   = 30;
FIELD_IDX_T A_Domain_FusRuleEn                       = 31;
FIELD_IDX_T A_Domain_MinStatEn                       = 32;
FIELD_IDX_T A_Domain_MaxStatEn                       = 33;
FIELD_IDX_T A_Domain_FundSplitRuleEn                 = 34;
FIELD_IDX_T A_Domain_ZeroQtyFlg                      = 35;
FIELD_IDX_T A_Domain_RiskExpoFlg                     = 36;
FIELD_IDX_T A_Domain_OptRiskRuleEn                   = 37;
FIELD_IDX_T A_Domain_UnderFlg                        = 38;
FIELD_IDX_T A_Domain_PtfConsRuleEn                   = 39;
FIELD_IDX_T A_Domain_StatusFusFlg                    = 40;
FIELD_IDX_T A_Domain_ClosPosFlg                      = 41;
FIELD_IDX_T A_Domain_PosLogicEn                      = 42;
FIELD_IDX_T A_Domain_FromDateCompRule                = 43;
FIELD_IDX_T A_Domain_TillDateCompRule                = 44;
FIELD_IDX_T A_Domain_StratDateCompRule               = 45;
FIELD_IDX_T A_Domain_FreqDateCompRule                = 46;
FIELD_IDX_T A_Domain_Freq1                           = 47;
FIELD_IDX_T A_Domain_Freq1UnitEn                     = 48;
FIELD_IDX_T A_Domain_Freq2                           = 49;
FIELD_IDX_T A_Domain_Freq2UnitEn                     = 50;
FIELD_IDX_T A_Domain_DefCurrFlg                      = 51;
FIELD_IDX_T A_Domain_DefLangFlg                      = 52;
FIELD_IDX_T A_Domain_DfltFlg                         = 53;
FIELD_IDX_T A_Domain_PtfQuoteRetrFlg                 = 54;
FIELD_IDX_T A_Domain_DfltFusDateRuleFlg              = 55;
FIELD_IDX_T A_Domain_DebtFlg                         = 56;
FIELD_IDX_T A_Domain_LoadPosFlg                      = 57;
FIELD_IDX_T A_Domain_FusSubNatFlg                    = 58;
FIELD_IDX_T A_Domain_StratLnkNatEn                   = 59;
FIELD_IDX_T A_Domain_ForceLnkFlg                     = 60;
FIELD_IDX_T A_Domain_CheckedPtfFlg                   = 61;
FIELD_IDX_T A_Domain_MinLnkPriority                  = 62;
FIELD_IDX_T A_Domain_MaxLnkPriority                  = 63;
FIELD_IDX_T A_Domain_ConvFactor                      = 64;
FIELD_IDX_T A_Domain_PosValRuleEn                    = 65;
FIELD_IDX_T A_Domain_EvtOperStatEn                   = 66;
FIELD_IDX_T A_Domain_EvtGenNatEn                     = 67;
FIELD_IDX_T A_Domain_EvtFlowNatEn                    = 68;
FIELD_IDX_T A_Domain_EvtFlowSubNatEn                 = 69;
FIELD_IDX_T A_Domain_EvtFlowSubNatLst                = 70;
FIELD_IDX_T A_Domain_FromAccNbr                      = 71;
FIELD_IDX_T A_Domain_TillAccNbr                      = 72;
FIELD_IDX_T A_Domain_ClosingNatEn                    = 73;
FIELD_IDX_T A_Domain_StratCheckDetNatEn              = 74;
FIELD_IDX_T A_Domain_CompDataEn                      = 75;
FIELD_IDX_T A_Domain_FctResultCd                     = 76;
FIELD_IDX_T A_Domain_DispResultFlg                   = 77;
FIELD_IDX_T A_Domain_RefDateCompRule                 = 78;
FIELD_IDX_T A_Domain_ValoSeqNo                       = 79;
FIELD_IDX_T A_Domain_ListHistEn                      = 80;
FIELD_IDX_T A_Domain_EvtPlRuleEn                     = 81;
FIELD_IDX_T A_Domain_RetDetLevelEn                   = 82;
FIELD_IDX_T A_Domain_SubGridFlg                      = 83;
FIELD_IDX_T A_Domain_PpsLoadEn                       = 84;
FIELD_IDX_T A_Domain_PpsTypeFlg                      = 85;
FIELD_IDX_T A_Domain_PpsConsPflFlg                   = 86;
FIELD_IDX_T A_Domain_PpsCurrFlg                      = 87;
FIELD_IDX_T A_Domain_LoadHierFlg                     = 88;
FIELD_IDX_T A_Domain_OrderNatEn                      = 89;
FIELD_IDX_T A_Domain_GenGlobalOrderEn                = 90;
FIELD_IDX_T A_Domain_OrderAllocNatEn                 = 91;
FIELD_IDX_T A_Domain_ObjWeightContPrct               = 92;
FIELD_IDX_T A_Domain_ObjWeightContMargPrct           = 93;
FIELD_IDX_T A_Domain_QtyAllocNatEn                   = 94;
FIELD_IDX_T A_Domain_CashAllocNatEn                  = 95;
FIELD_IDX_T A_Domain_CashObjWeightPrct               = 96;
FIELD_IDX_T A_Domain_CheckStratEn                    = 97;
FIELD_IDX_T A_Domain_OrderStatusEn                   = 98;
FIELD_IDX_T A_Domain_EvtDateRuleEn                   = 99;
FIELD_IDX_T A_Domain_OpSearch                        = 100;
FIELD_IDX_T A_Domain_ExtOpSearch                     = 101;
FIELD_IDX_T A_Domain_HistListFlg                     = 102;
FIELD_IDX_T A_Domain_MinOrderAmt                     = 103;
FIELD_IDX_T A_Domain_MinOrderAmtCurrId               = 104;
FIELD_IDX_T A_Domain_MktSgtRebalFlg                  = 105;
FIELD_IDX_T A_Domain_InstrListDef                    = 106;
FIELD_IDX_T A_Domain_PtfListDef                      = 107;
FIELD_IDX_T A_Domain_LoadGlobOrderEn                 = 108;
FIELD_IDX_T A_Domain_InterpFromDate                  = 109;
FIELD_IDX_T A_Domain_InterpStratDate                 = 110;
FIELD_IDX_T A_Domain_FctResultStatEn                 = 111;
FIELD_IDX_T A_Domain_CompLevelEn                     = 112;
FIELD_IDX_T A_Domain_DerivationEn                    = 113;
FIELD_IDX_T A_Domain_DynWeightFlg                    = 114;
FIELD_IDX_T A_Domain_ConstrNatEn                     = 115;
FIELD_IDX_T A_Domain_ExtPosListId                    = 116;
FIELD_IDX_T A_Domain_LoadNonDiscretFlg               = 117;
FIELD_IDX_T A_Domain_CheckTradingFlg                 = 118;
FIELD_IDX_T A_Domain_ExecDetailsFlg                  = 119;
FIELD_IDX_T A_Domain_RoundingMethodEn                = 120;
FIELD_IDX_T A_Domain_DimEntityDictId                 = 121;
FIELD_IDX_T A_Domain_Bench1EntityDictId              = 122;
FIELD_IDX_T A_Domain_Bench1ObjectId                  = 123;
FIELD_IDX_T A_Domain_Bench2EntityDictId              = 124;
FIELD_IDX_T A_Domain_Bench2ObjectId                  = 125;
FIELD_IDX_T A_Domain_Bench3EntityDictId              = 126;
FIELD_IDX_T A_Domain_Bench3ObjectId                  = 127;
FIELD_IDX_T A_Domain_RiskFreeInstrId                 = 128;
FIELD_IDX_T A_Domain_ReturnAnalysisEn                = 129;
FIELD_IDX_T A_Domain_PerfAttribMethodEn              = 130;
FIELD_IDX_T A_Domain_PerfAttribFreqEn                = 131;
FIELD_IDX_T A_Domain_PSPPositionDataId               = 132; /* REF9125 - LJE - 030811 */
FIELD_IDX_T A_Domain_PLMethodEn                      = 133; /* REF9125 - LJE - 030811 */
FIELD_IDX_T A_Domain_AuthOnlinePeriods               = 134; /* REF9125 - LJE - 030811 */
FIELD_IDX_T A_Domain_UnmatchedExecSearch             = 135; /*REF9764-BRO-040119*/
FIELD_IDX_T A_Domain_PurgeOrderMethodEn              = 136; /*REF8723-BRO-040204*/
FIELD_IDX_T A_Domain_FileName                        = 137; /*REF8723-BRO-040204*/
FIELD_IDX_T A_Domain_CashFlowMgtEn                   = 138; /*PMSTA00485-BRO-061103*/
FIELD_IDX_T A_Domain_DummyMinStatEn                  = 139; /*PMSTA00344-CHU-070122*/
FIELD_IDX_T A_Domain_DummyMaxStatEn                  = 140; /*PMSTA00344-CHU-070122*/
FIELD_IDX_T A_Domain_FctResultListDef                = 141; /*  FPL-090209-PMSTA07121   */
FIELD_IDX_T A_Domain_DimFctResultDictId              = 142; /*  FPL-090209-PMSTA07121   */
FIELD_IDX_T A_Domain_CaseMgtSearch                   = 143; /*  FPL-090209-PMSTA07121   */
FIELD_IDX_T A_Domain_FormatProfileId                 = 144; /*PMSTA07861-EFE-090309*/
FIELD_IDX_T A_Domain_JobReference                    = 145; /*PMSTA07861-EFE-090309*/
FIELD_IDX_T A_Domain_InterpTillDate                  = 146;
FIELD_IDX_T A_Domain_InterpFreqDate                  = 147;
FIELD_IDX_T A_Domain_CalcRefDate                     = 148;
FIELD_IDX_T A_Domain_TslDbName                       = 149;  /* PMSTA9318-EFE-100209 */
FIELD_IDX_T A_Domain_SessionCreationDate             = 150;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_SessionCreationUserId           = 151;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_SessionDescriptionInfo          = 152;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_SessionNatureEn                 = 153;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_ProposalNatureEn                = 154;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_ParentSessionId                 = 155;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_DefaultStrategyId               = 156;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_SimulationFlg                   = 157;  /* PMSTA10733-EFE-101108*/
FIELD_IDX_T A_Domain_SessionStatusEn                 = 158; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_IncludeExternalPosFlg           = 159; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_ActivateIncludeOrderFlg         = 160; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_ValidationDate                  = 161; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_ValidationUserId                = 162; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_MinOrderPercent                 = 163;	/* PMSTA10173-CHU-110309 */
FIELD_IDX_T A_Domain_RepColorEn                      = 164; /*<PMSTA11542-BRO-110502*/
FIELD_IDX_T A_Domain_RepAnonymousEn                  = 165;
FIELD_IDX_T A_Domain_RepStyleSheetEn                 = 166;
FIELD_IDX_T A_Domain_RepTocEn                        = 167;
FIELD_IDX_T A_Domain_RepValoEn                       = 168;
FIELD_IDX_T A_Domain_RepStockChartEn                 = 169;
FIELD_IDX_T A_Domain_RepBondChartEn                  = 170;
FIELD_IDX_T A_Domain_RepOverviewEn                   = 171;
FIELD_IDX_T A_Domain_RepCashflowEn                   = 172;
FIELD_IDX_T A_Domain_RepCurrChartEn                  = 173;
FIELD_IDX_T A_Domain_RepMaturityChartEn              = 174;
FIELD_IDX_T A_Domain_RepOrdersEn                     = 175;
FIELD_IDX_T A_Domain_RepOpHistEn                     = 176;
FIELD_IDX_T A_Domain_RepPerfEn                       = 177;
FIELD_IDX_T A_Domain_RepComplianceEn                 = 178;
FIELD_IDX_T A_Domain_RepIntroEn                      = 179;
FIELD_IDX_T A_Domain_RepValo2En                      = 180;
FIELD_IDX_T A_Domain_RepStockChart2En                = 181;
FIELD_IDX_T A_Domain_RepBondChart2En                 = 182;
FIELD_IDX_T A_Domain_RepCashflow2En                  = 183;
FIELD_IDX_T A_Domain_RepCurrChart2En                 = 184;
FIELD_IDX_T A_Domain_RepMaturityChart2En             = 185;
FIELD_IDX_T A_Domain_RepCompliance2En                = 186;
FIELD_IDX_T A_Domain_RepPreviewFlg                   = 187;
FIELD_IDX_T A_Domain_RepPrinterId                    = 188;
FIELD_IDX_T A_Domain_RepCopy                         = 189;
FIELD_IDX_T A_Domain_RepFileOutputFlg                = 190;
FIELD_IDX_T A_Domain_RepFileOutputNatEn              = 191;
FIELD_IDX_T A_Domain_RepFileOutputName               = 192;
FIELD_IDX_T A_Domain_RepRoiOutputName                = 193;
FIELD_IDX_T A_Domain_RepDeleteDataFlg                = 194;
FIELD_IDX_T A_Domain_RepExecutionCd                  = 195;
FIELD_IDX_T A_Domain_RepExecutionStatusEn            = 196;
FIELD_IDX_T A_Domain_RepBurstListId                  = 197;
FIELD_IDX_T A_Domain_RepFinishDate                   = 198;
FIELD_IDX_T A_Domain_RepLaunchDate                   = 199;
FIELD_IDX_T A_Domain_RepConfigNatEn                  = 200;
FIELD_IDX_T A_Domain_RepStockGroupEn                 = 201;
FIELD_IDX_T A_Domain_RepFundGroupEn                  = 202;
FIELD_IDX_T A_Domain_RepModuleTraceFlg               = 203;
FIELD_IDX_T A_Domain_RepStyleTraceFlg                = 204;
FIELD_IDX_T A_Domain_RepGlobalTraceFlg               = 205;
FIELD_IDX_T A_Domain_RepPrintEn                      = 206; /*>PMSTA11542-BRO-110502*/
FIELD_IDX_T A_Domain_RepAdditionalInfo               = 207; /*PMSTA11542-BRO-110623*/
FIELD_IDX_T A_Domain_DataSecuProfId                  = 208; /*PMSTA11805-BRO-110502*/
FIELD_IDX_T A_Domain_OwnershipRuleEn                 = 209; /*PMSTA11875-BRO-110502*/
FIELD_IDX_T A_Domain_ThirdCompoEn                    = 210; /*PMSTA11875-BRO-110502*/
FIELD_IDX_T A_Domain_TypeId                          = 211; /*PMSTA11542-BRO-110502*/
FIELD_IDX_T A_Domain_SessionOrigin                   = 212; /*PMSTA12266-BRO-110624*/
FIELD_IDX_T A_Domain_ManagerLinkId                   = 213; /*PMSTA13166-EFE-120110*/
FIELD_IDX_T A_Domain_DimTypeEn                       = 214; /*PMSTA13166-EFE-120110*/
FIELD_IDX_T A_Domain_RepJobPriority                  = 215; /*OCS40593-BRO-120509*/
FIELD_IDX_T A_Domain_RepNotificationFlg              = 216; /*OCS40593-BRO-120509*/
FIELD_IDX_T A_Domain_CalcPivotDate                   = 217; /* PMSTA-14375-EFE-120615*/
FIELD_IDX_T A_Domain_DataSecuProf2Id                 = 218; /*PMSTA14309-EFE-120622*/
FIELD_IDX_T A_Domain_ChildSessionId                  = 219; /*PMSTA15463-CHU-121129*/
FIELD_IDX_T A_Domain_ExpirationDate                  = 220; /*PMSTA15756-BRO-130121*/
FIELD_IDX_T A_Domain_RepPtccEn                       = 221; /*LR1088-BRO-130121*/
FIELD_IDX_T A_Domain_RepPtccChartEn                  = 222; /*LR1088-BRO-130121*/
FIELD_IDX_T A_Domain_RepPerfAttribChartEn            = 223; /*OCS42372-BRO-130121*/
FIELD_IDX_T A_Domain_RepPerfContribLevelEn           = 224; /*OCS42372-BRO-130121*/
FIELD_IDX_T A_Domain_OrderGroupingFctDictId          = 225; /*PMSTA15221-CHU-130116*/
FIELD_IDX_T A_Domain_RepStorageEn					 = 226; /*OCS-43245-TGU-130820*/
FIELD_IDX_T A_Domain_RepExecutionEn					 = 227; /*OCS-43245-TGU-130820*/
FIELD_IDX_T A_Domain_QueryDefinition                 = 228; /* PMSTA18184-EFE-140528 */
FIELD_IDX_T A_Domain_ComputationModeEn               = 229; /*PMSTA-18426-CHU-140919*/
FIELD_IDX_T A_Domain_RiskRuleId                      = 230; /*PMSTA-18426-CHU-140919*/
FIELD_IDX_T A_Domain_ThirdId                         = 231;
FIELD_IDX_T A_Domain_NonEnumInstrFlg                 = 232;
FIELD_IDX_T A_Domain_ReturnFctFlg                    = 233;
FIELD_IDX_T A_Domain_FundSplitLevel                  = 234;
FIELD_IDX_T A_Domain_FmtId                           = 235;
FIELD_IDX_T A_Domain_OutputTpEn                      = 236;
FIELD_IDX_T A_Domain_DataSetId                       = 237;
FIELD_IDX_T A_Domain_PpsId                           = 238;
FIELD_IDX_T A_Domain_DataProfId                      = 239;
FIELD_IDX_T A_Domain_InitialFctDictId                = 240;
FIELD_IDX_T A_Domain_ExternalDefinitionUrl           = 241; /*REF9510-BRO-030929*/
FIELD_IDX_T A_Domain_SelectOrderEntry                = 242; /*PMSTA02061-BRO-071130*/
FIELD_IDX_T A_Domain_GenerateCaseFlg                 = 243; /* PMSTA08705 - 091104 - DDV - Activate case creation in CheckStrat */
FIELD_IDX_T A_Domain_CheckStratDuraFlg               = 244;
FIELD_IDX_T A_Domain_CheckStratBetaFlg               = 245;
FIELD_IDX_T A_Domain_CheckStratCrtYieldFlg           = 246;
FIELD_IDX_T A_Domain_CheckStratRatingFlg             = 247;
FIELD_IDX_T A_Domain_DebtFullCouponFlg               = 248;
FIELD_IDX_T A_Domain_OpNatEn                         = 249;
FIELD_IDX_T A_Domain_StratCheckReconcEn              = 250;
FIELD_IDX_T A_Domain_SysDate                         = 251;
FIELD_IDX_T A_Domain_PerfDetLevelEn                  = 252;
FIELD_IDX_T A_Domain_SavedOrderAllocNatEn            = 253; /*PMSTA03336-CHU-071030*/
FIELD_IDX_T A_Domain_RpcFctDictId                    = 254; /* PMSTA04773 - DDV - 071114 */
FIELD_IDX_T A_Domain_FullLoadHierProcessedFlg        = 255; /* PMSTA04637-CHU-080208 */
FIELD_IDX_T A_Domain_FullLoadHierOldPtfId            = 256; /* PMSTA04637-CHU-080208 */
FIELD_IDX_T A_Domain_FullLoadHierOldDimPtfDictId     = 257; /* PMSTA04637-CHU-080208 */
FIELD_IDX_T A_Domain_SaveZeroQtyFlg                  = 258; /* DLA - PMSTA04851 - 080312 */
FIELD_IDX_T A_Domain_ChunkNumber                     = 259; /* PMSTA9318-EFE-100209 */
FIELD_IDX_T A_Domain_TSLPtfDimModifiedFlg            = 260; /* PMSTA09899-CHU-100521 */
FIELD_IDX_T A_Domain_SavedDimEntityDictId            = 261; /* PMSTA09899-CHU-100521 */
FIELD_IDX_T A_Domain_SavedDimPtfDictId               = 262; /* PMSTA09899-CHU-100521 */
FIELD_IDX_T A_Domain_SavedPtfObjId                   = 263; /* PMSTA09899-CHU-100521 */
FIELD_IDX_T A_Domain_SavedPtfListDef                 = 264; /* PMSTA08999-CHU-100521 */
FIELD_IDX_T A_Domain_SessionInErrorFlg               = 265; /*  FPL-PMSTA10166-100714   */
FIELD_IDX_T A_Domain_ValidationRightFlg              = 266; /* PMSTA10733-TEB-101222 */
FIELD_IDX_T A_Domain_CaseToClarify                   = 267; /* PMSTA10444-CHU-110405 */
FIELD_IDX_T A_Domain_Summary                         = 268; /*PMSTA11600-BRO-110504*/
FIELD_IDX_T A_Domain_LogCommentC                     = 269; /* PMSTA11860-RBN-110420 */
FIELD_IDX_T A_Domain_SimulEvtGenNatEn                = 270; /* PMSTA14190-CHU-120429 */
FIELD_IDX_T A_Domain_WeightFlg                       = 271; /* PMSTA-14214 - JPP - 20120504 */
FIELD_IDX_T A_Domain_ExpandStratEn                   = 272; /* PMSTA-14214 - JPP - 20120504 */
FIELD_IDX_T A_Domain_InitialFromDate                 = 273; /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */
FIELD_IDX_T A_Domain_MinTradingAmtFlg				 = 274;
FIELD_IDX_T A_Domain_DecisionState					 = 275;	/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T A_Domain_ApplSessionCd                   = 276;  /* PMSTA-22549 - CHU - 160426 */
FIELD_IDX_T A_Domain_DlmModeEn                       = 277; /* PMSTA-24026 - DDV - 161019 */
FIELD_IDX_T A_Domain_InstrQueryDefinitionT           = 278; /* OCS-49233 - KIC - 170123 */
FIELD_IDX_T A_Domain_TaxLotEn                        = 279; /* PMSTA-28286-CHU-170905 */
FIELD_IDX_T A_Domain_PlanDefinitionId                = 280; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_Domain_OrderSwitchingFctDictId		 = 281; /*PMSTA-35586 - Silpakal - 190516*/
FIELD_IDX_T A_Domain_OrderSwitchingFlg				 = 282; /*PMSTA-35586 - Silpakal - 190516*/
FIELD_IDX_T A_Domain_LoadHierHistFlg                 = 283; /*PMSTA-37064 - Vishnu   - 190904*/
FIELD_IDX_T	A_Domain_GenOrderNettingEn				 = 284; /*PMSTA-37908 - adarshn  - 191119*/
FIELD_IDX_T A_Domain_MultiLvlModelMgmtFlg            = 285; /*PMSTA-37101 - vkumar   - 191205*/
FIELD_IDX_T	A_Domain_NumberOfOrders                  = 286;	/* NumberType */ /*PMSTA-38945 - Kramadevi - 17022020*/
FIELD_IDX_T	A_Domain_OrderNettingFctDictId           = 287;	/* PMSTA-37908 - adarshn - 08032020*/
FIELD_IDX_T A_Domain_RebalMethodEn                   = 288; /* PMSTA-39048 - vkumar - 240220 */
FIELD_IDX_T	A_Domain_QuasiCashEn                     = 289;	/* PMSTA-39968 - Vishnu - 27042020*/
FIELD_IDX_T A_Domain_OrderAllocRuleEn				 = 290; /* PMSTA-40063 - vmuthu - 050520 */
FIELD_IDX_T A_Domain_OrderBuyAllocRuleEn			 = 291; /* PMSTA-40063 - vmuthu - 050520 */
FIELD_IDX_T A_Domain_CashRealignMethodEn             = 292; /* PMSTA-41494 - Kramadevi - 18082020*/
FIELD_IDX_T A_Domain_SmartRoundingFlg				 = 293; /* PMSTA-40493-badhri-08252020: smart rounding rule  */
FIELD_IDX_T A_Domain_SmartRoundingRuleId			 = 294; /* PMSTA-40493-badhri-08252020: smart rounding rule  */
FIELD_IDX_T	A_Domain_OrigPortObjId					 = 295; /* PMSTA-41704-lalby -overlay compliance warn   */
FIELD_IDX_T	A_Domain_HierGroupingFctDictId           = 296;	/* PMSTA-40208 - adarshn - 28082020*/
FIELD_IDX_T A_Domain_OrderStatusFctDictId            = 297; /* PMSTA-41770 -Vishnu- 15092020*/
FIELD_IDX_T A_Domain_ComplianceMethodEn              = 298; /* PMSTA-42402 -Vishnu- 11112020*/
FIELD_IDX_T A_Domain_LoadReceivFlg = 299; /*PMSTA- 42330 -CHANDRU-01102020*/
FIELD_IDX_T A_Domain_CheckHierConsFlg = 300; /*PMSTA-43325 -LIK-01212021*/
FIELD_IDX_T A_Domain_HierHoldCheckFlg = 301; /*PMSTA-43325-LIK-01212021*/
FIELD_IDX_T A_Domain_ConsiderWitReqFlg               = 302; /* PMSTA-43671 -adarshn- 10032021 */
FIELD_IDX_T A_Domain_HedgingTypeEn = 303; /* PMSTA-44959 - LIK - 210429  */
FIELD_IDX_T A_Domain_OverHedgeFlg = 304; /* PMSTA-44959 - LIK - 210429 */
FIELD_IDX_T A_Domain_InclNonManagedEn = 305; /* PMSTA-44324 - vishnu - 27042021 */
FIELD_IDX_T	A_Domain_OverrideFlg                     = 306; /*PMSTA-46649 - CHANDRU - 02112021*/
FIELD_IDX_T	A_Domain_modelRebalEn = 307;  /*PMSTA46691 - 151221 - ASahay*/
FIELD_IDX_T A_Domain_modelId = 308;       /*PMSTA46691 - 151221 - ASahay*/
FIELD_IDX_T A_Domain_CheckSeverityRuleFlg = 309;  /*PMSTA-47502-Lalby-04032022*/
FIELD_IDX_T	A_Domain_PtfScopeEn                      = 310;	/* PMSTA - 48508 - CHANDRU - 18032022 */
FIELD_IDX_T A_Domain_CaseManagementGenFlg = 311;  /* PMSTA-48704-LEK-220414 Enabling Case management for Check Strategy */
FIELD_IDX_T A_Domain_CaseManagementStorageFlg = 312;  /* PMSTA-48704-LEK-220414 Enabling Case management for Check Strategy */
FIELD_IDX_T A_Domain_ForwardRenewalFlg               = 313; /* WEALTH-157 - KKM - 170423 */
FIELD_IDX_T A_Domain_LoadDimPtfHistFlg               = 314; /* PMSTA-48083 - JBC - 221012 */
FIELD_IDX_T A_Domain_PerfCalcDefProfId               = 315; /* PMSTA-54529 - JBC - 230914 */
FIELD_IDX_T A_Domain_OrigCompDataEn                  = 316; /* WEALTH-4101 - Ravindra - 110124 */
FIELD_IDX_T A_Domain_OrigLoadHierFlg                 = 317; /* WEALTH-5157-Lalby-07032024 */
FIELD_IDX_T A_Domain_OrigBeginDate                   = 318; /* WEALTH-9917-Lalby-08082024- Historical group perf */
FIELD_IDX_T A_Domain_OrigEndDate                     = 319; /* WEALTH-9917-Lalby-08082024- Historical group perf */
FIELD_IDX_T A_Domain_PtfHierChangeFlg                = 320; /* PMSTA-64818 - Deepthi - 20250210 */

FIELD_IDX_T S_Domain_Id                              = 0;
FIELD_IDX_T S_Domain_CurrId                          = 1;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_DimPtfDictId                    = 2;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_DimInstrDictId                  = 3;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_UsrId                           = 4;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_LangDictId                      = 5;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_FctDictId                       = 6;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_ScenaId                         = 7;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_QuoteValRuleId                  = 8;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_ExchValRuleId                   = 9;   /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_PtfObjId                        = 10;  /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_InstrObjId                      = 11;  /*  PMSTA-11731-HFI-110203  */
FIELD_IDX_T S_Domain_FctResultId					 = 12;	/* PMSTA-30891 - RAK - 180430 */
FIELD_IDX_T S_Domain_ExtStratEltNatAllocFlg			 = 13;	/* PMSTA-30891 - RAK - 180430 */
FIELD_IDX_T S_Domain_TaxLotEn                        = 14;	/* PMSTA-34295 - sanand - 100319 */
FIELD_IDX_T S_Domain_InitDimFlg                      = 15;

FIELD_IDX_T A_Empty_Id                               = 0;


FIELD_IDX_T A_EvtExcl_Id                             = 0;
FIELD_IDX_T A_EvtExcl_IssueDecisFlg                  = 1;


FIELD_IDX_T S_EvtExcl_Id                             = 0;


FIELD_IDX_T A_ExchFmt_CurrId                         = 0;
FIELD_IDX_T A_ExchFmt_UnderCurrId                    = 1;
FIELD_IDX_T A_ExchFmt_Mult                           = 2;
FIELD_IDX_T A_ExchFmt_InverseFlg                     = 3;


FIELD_IDX_T S_ExchFmt_CurrId                         = 0;
FIELD_IDX_T S_ExchFmt_UnderCurrId                    = 1;
FIELD_IDX_T S_ExchFmt_UnderCurrCd                    = 2;
FIELD_IDX_T S_ExchFmt_Mult                           = 3;
FIELD_IDX_T S_ExchFmt_InverseFlg                     = 4;


FIELD_IDX_T A_ExchRate_CurrId                        = 0;
FIELD_IDX_T A_ExchRate_UnderCurrId                   = 1;
FIELD_IDX_T A_ExchRate_TpId                          = 2;
FIELD_IDX_T A_ExchRate_ThirdId                       = 3;
FIELD_IDX_T A_ExchRate_MktThirdId                    = 4;
FIELD_IDX_T A_ExchRate_ExchDate                      = 5;
FIELD_IDX_T A_ExchRate_DailyDfltFlg                  = 6;
FIELD_IDX_T A_ExchRate_ExchRate                      = 7;
FIELD_IDX_T A_ExchRate_ValRuleId                     = 8;
FIELD_IDX_T A_ExchRate_ValRuleEltId                  = 9;
FIELD_IDX_T A_ExchRate_ValRuleCoef                   = 10;
FIELD_IDX_T A_ExchRate_CoefNatEn                     = 11;
FIELD_IDX_T A_ExchRate_InverseFlg                    = 12;


FIELD_IDX_T S_ExchRate_CurrId                        = 0;
FIELD_IDX_T S_ExchRate_UnderCurrId                   = 1;
FIELD_IDX_T S_ExchRate_TpId                          = 2;
FIELD_IDX_T S_ExchRate_ThirdId                       = 3;
FIELD_IDX_T S_ExchRate_MktThirdId                    = 4;
FIELD_IDX_T S_ExchRate_ExchDate                      = 5;
FIELD_IDX_T S_ExchRate_CurrCd                        = 6;
FIELD_IDX_T S_ExchRate_UnderCurrCd                   = 7;
FIELD_IDX_T S_ExchRate_TpCd                          = 8;
FIELD_IDX_T S_ExchRate_ThirdCd                       = 9;
FIELD_IDX_T S_ExchRate_ExchRate                      = 10;
FIELD_IDX_T S_ExchRate_MktThirdCd                    = 11; /* PMSTA-32142 CMILOS 130918 */


FIELD_IDX_T A_ExtRetAnalysis_Id                      = 0;
FIELD_IDX_T A_ExtRetAnalysis_PerfStorParamId         = 1;
FIELD_IDX_T A_ExtRetAnalysis_EntDictId               = 2;
FIELD_IDX_T A_ExtRetAnalysis_ObjId                   = 3;
FIELD_IDX_T A_ExtRetAnalysis_FreqEn                  = 4;
FIELD_IDX_T A_ExtRetAnalysis_CurrId                  = 5;
FIELD_IDX_T A_ExtRetAnalysis_PosDataId               = 6;
FIELD_IDX_T A_ExtRetAnalysis_GridId                  = 7;
FIELD_IDX_T A_ExtRetAnalysis_PerfAttribRtnEn         = 8;
FIELD_IDX_T A_ExtRetAnalysis_InitialDate             = 9;
FIELD_IDX_T A_ExtRetAnalysis_FinalDate               = 10;
FIELD_IDX_T A_ExtRetAnalysis_MktSegtId               = 11;
FIELD_IDX_T A_ExtRetAnalysis_InstrId                 = 12;
FIELD_IDX_T A_ExtRetAnalysis_InitialMktVal           = 13;
FIELD_IDX_T A_ExtRetAnalysis_FinalMktVal             = 14;
FIELD_IDX_T A_ExtRetAnalysis_Fees                    = 15;
FIELD_IDX_T A_ExtRetAnalysis_Taxes                   = 16;
FIELD_IDX_T A_ExtRetAnalysis_Flows                   = 17;
FIELD_IDX_T A_ExtRetAnalysis_ProfitLoss              = 18;
FIELD_IDX_T A_ExtRetAnalysis_FlowMeanCap             = 19;
FIELD_IDX_T A_ExtRetAnalysis_MeanCapital             = 20;
FIELD_IDX_T A_ExtRetAnalysis_Rtn                     = 21;
FIELD_IDX_T A_ExtRetAnalysis_Adjust                  = 22; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_ExtRetAnalysis_RtnGross                = 23; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_ExtRetAnalysis_TaxCredit               = 24;
FIELD_IDX_T A_ExtRetAnalysis_DeltaNetGross           = 25;
FIELD_IDX_T A_ExtRetAnalysis_Dividend                = 26;
FIELD_IDX_T A_ExtRetAnalysis_MeanInvestCap           = 27;
FIELD_IDX_T A_ExtRetAnalysis_Rtn1                    = 28;
FIELD_IDX_T A_ExtRetAnalysis_Invest                  = 29;
FIELD_IDX_T A_ExtRetAnalysis_Withdr                  = 30;
FIELD_IDX_T A_ExtRetAnalysis_Inc1                    = 31;
FIELD_IDX_T A_ExtRetAnalysis_Inc2                    = 32;
FIELD_IDX_T A_ExtRetAnalysis_CapPl1                  = 33;
FIELD_IDX_T A_ExtRetAnalysis_CapPl2                  = 34;
FIELD_IDX_T A_ExtRetAnalysis_CurrPl1                 = 35;
FIELD_IDX_T A_ExtRetAnalysis_CurrPl2                 = 36;
FIELD_IDX_T A_ExtRetAnalysis_Rtn2                    = 37;
FIELD_IDX_T A_ExtRetAnalysis_Rtn3                    = 38;
FIELD_IDX_T A_ExtRetAnalysis_CapEffect               = 39;
FIELD_IDX_T A_ExtRetAnalysis_CurrEffect              = 40;
FIELD_IDX_T A_ExtRetAnalysis_FeesTaxEffect           = 41;
FIELD_IDX_T A_ExtRetAnalysis_IncEffect               = 42;
FIELD_IDX_T A_ExtRetAnalysis_PortSynthId             = 43;
FIELD_IDX_T A_ExtRetAnalysis_GblExtRetAnalysisId     = 44;
FIELD_IDX_T A_ExtRetAnalysis_ExtStratEltId           = 45;
FIELD_IDX_T A_ExtRetAnalysis_InstrFreqId             = 46;
FIELD_IDX_T A_ExtRetAnalysis_PtfFreqId               = 47;
FIELD_IDX_T A_ExtRetAnalysis_RiskFreeId              = 48;
FIELD_IDX_T A_ExtRetAnalysis_BenchId                 = 49;
FIELD_IDX_T A_ExtRetAnalysis_ParentId                = 50;
FIELD_IDX_T A_ExtRetAnalysis_AbcissaRank             = 51;
FIELD_IDX_T A_ExtRetAnalysis_OrdinateRank            = 52;
FIELD_IDX_T A_ExtRetAnalysis_CompletePeriodFlg       = 53; /* REF9770 - LJE - 031212 */
FIELD_IDX_T A_ExtRetAnalysis_RecInfoMask             = 54;
FIELD_IDX_T A_ExtRetAnalysis_PreviousId              = 0; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_NextId                  = 0; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_OverPeriodId            = 0; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_ParentObjId             = 0; /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_ExtRetAnalysis_MergeParentObjId        = 55;
FIELD_IDX_T A_ExtRetAnalysis_BreakCriteria           = 56; /* REF9187 - LJE - 030625 */
FIELD_IDX_T A_ExtRetAnalysis_ParentBreakCriteria     = 57; /* REF9344 - LJE - 031014 */
FIELD_IDX_T A_ExtRetAnalysis_GblExtRetAnalysis_Ext   = 58;
FIELD_IDX_T A_ExtRetAnalysis_RiskFree_Ext            = 59;
FIELD_IDX_T A_ExtRetAnalysis_Bench_Ext               = 60;
FIELD_IDX_T A_ExtRetAnalysis_Parent_Ext              = 61;
FIELD_IDX_T A_ExtRetAnalysis_Previous_Ext            = 62; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_Next_Ext                = 63; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_OverPeriod_Ext          = 64; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_ExtRetAnalysis_ParentObj_Ext           = 0;  /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_ExtRetAnalysis_PerfCalcResult_Ext      = 65;
FIELD_IDX_T A_ExtRetAnalysis_SubSetBreakCriteria     = 66;  /* REF10276 - LJE - 041110 : For optim */
FIELD_IDX_T A_ExtRetAnalysis_PerfTimRuleEn           = 67;  /* PMSTA-42147 - lalby - 10022021*/
FIELD_IDX_T A_ExtRetAnalysis_FirstOpNatEn            = 68;  /* PMSTA-42147 - lalby - 10022021*/
FIELD_IDX_T A_ExtRetAnalysis_HeadPtf_Ext             = 69;  /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
FIELD_IDX_T A_ExtRetAnalysis_RecStatusEn             = 70;  /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */
FIELD_IDX_T A_ExtRetAnalysis_PtfInAdjust             = 71;  /* WEALTH-9725 - Lalby - 25062024- Manage Ptf in and out using PCP */
FIELD_IDX_T A_ExtRetAnalysis_PtfOutAdjust            = 72;
FIELD_IDX_T A_ExtRetAnalysis_MktSegInAdjust          = 73;
FIELD_IDX_T A_ExtRetAnalysis_MktSegOutAdjust         = 74;

FIELD_IDX_T S_ExtRetAnalysis_Id                      = 0;
FIELD_IDX_T S_ExtRetAnalysis_PerfStorParamId         = 1;
FIELD_IDX_T S_ExtRetAnalysis_EntDictId               = 2;
FIELD_IDX_T S_ExtRetAnalysis_ObjId                   = 3;
FIELD_IDX_T S_ExtRetAnalysis_FreqEn                  = 4;
FIELD_IDX_T S_ExtRetAnalysis_CurrId                  = 5;
FIELD_IDX_T S_ExtRetAnalysis_PosDataId               = 6;
FIELD_IDX_T S_ExtRetAnalysis_GridId                  = 7;
FIELD_IDX_T S_ExtRetAnalysis_PerfAttribRtnEn         = 8;
FIELD_IDX_T S_ExtRetAnalysis_InitialDate             = 9;
FIELD_IDX_T S_ExtRetAnalysis_FinalDate               = 10;
FIELD_IDX_T S_ExtRetAnalysis_MktSegtId               = 11;
FIELD_IDX_T S_ExtRetAnalysis_InstrId                 = 12;


FIELD_IDX_T Freq_ExchRate_CurrId                     = 0;
FIELD_IDX_T Freq_ExchRate_UnderCurrId                = 1;
FIELD_IDX_T Freq_ExchRate_TpId                       = 2;
FIELD_IDX_T Freq_ExchRate_ThirdId                    = 3;
FIELD_IDX_T Freq_ExchRate_MktThirdId                 = 4;
FIELD_IDX_T Freq_ExchRate_ExchDate                   = 5;
FIELD_IDX_T Freq_ExchRate_DailyDfltFlg               = 6;
FIELD_IDX_T Freq_ExchRate_ExchRate                   = 7;
FIELD_IDX_T Freq_ExchRate_RequestDate                = 8;


FIELD_IDX_T A_FctResult_Id                           = 0;
FIELD_IDX_T A_FctResult_Cd                           = 1;
FIELD_IDX_T A_FctResult_FctDictId                    = 2;
FIELD_IDX_T A_FctResult_DomainId                     = 3;
FIELD_IDX_T A_FctResult_UserId                       = 4;
FIELD_IDX_T A_FctResult_ModifDate                    = 5;
FIELD_IDX_T A_FctResult_CalcFromDate                 = 6;
FIELD_IDX_T A_FctResult_CalcTillDate                 = 7;
FIELD_IDX_T A_FctResult_CalcRefDate                  = 8;
FIELD_IDX_T A_FctResult_CalcStratDate                = 9;
FIELD_IDX_T A_FctResult_CalcFreqDate                 = 10;
FIELD_IDX_T A_FctResult_StatusEn                     = 11;
FIELD_IDX_T A_FctResult_DimPtfDictId                 = 12;
FIELD_IDX_T A_FctResult_PtfObjId                     = 13;
FIELD_IDX_T A_FctResult_DimInstrDictId               = 14;
FIELD_IDX_T A_FctResult_InstrObjId                   = 15;
FIELD_IDX_T A_FctResult_DimStratDictId               = 16;
FIELD_IDX_T A_FctResult_StratObjId                   = 17;


FIELD_IDX_T S_FctResult_Id                           = 0;
FIELD_IDX_T S_FctResult_Cd                           = 1;
FIELD_IDX_T S_FctResult_FctName                      = 2;
FIELD_IDX_T S_FctResult_DomainId                     = 3;
FIELD_IDX_T S_FctResult_DimPtfSqlName                = 4;
FIELD_IDX_T S_FctResult_PtfObjCd                     = 5;
FIELD_IDX_T S_FctResult_DimInstrSqlName              = 6;
FIELD_IDX_T S_FctResult_InstrObjCd                   = 7;
FIELD_IDX_T S_FctResult_DimStratSqlName              = 8;
FIELD_IDX_T S_FctResult_StratObjCd                   = 9;
FIELD_IDX_T S_FctResult_MinStatusEn                  = 10;
FIELD_IDX_T S_FctResult_MaxStatusEn                  = 11;
FIELD_IDX_T S_FctResult_ModifDate                    = 12;
FIELD_IDX_T S_FctResult_CalcFromDate                 = 13;
FIELD_IDX_T S_FctResult_CalcTillDate                 = 14;
FIELD_IDX_T S_FctResult_CalcRefDate                  = 15;
FIELD_IDX_T S_FctResult_CalcStratDate                = 16;
FIELD_IDX_T S_FctResult_CalcFreqDate                 = 17;
FIELD_IDX_T S_FctResult_StatusEn                     = 18;
FIELD_IDX_T S_FctResult_FctDictId                    = 19;      /*  FIH-REF10295-040621 */


FIELD_IDX_T A_FctSecuProfCompo_FctSecuProfId         = 0;
FIELD_IDX_T A_FctSecuProfCompo_FctDictId             = 1;
FIELD_IDX_T A_FctSecuProfCompo_EntDictId             = 2;
FIELD_IDX_T A_FctSecuProfCompo_TpId                  = 3;
FIELD_IDX_T A_FctSecuProfCompo_SubTpId               = 4;
FIELD_IDX_T A_FctSecuProfCompo_MinStatEn             = 5;
FIELD_IDX_T A_FctSecuProfCompo_MaxStatEn             = 6;
FIELD_IDX_T A_FctSecuProfCompo_CreateFlg             = 7;
FIELD_IDX_T A_FctSecuProfCompo_UpdFlg                = 8;
FIELD_IDX_T A_FctSecuProfCompo_DelFlg                = 9;
FIELD_IDX_T A_FctSecuProfCompo_SecuLevelEn           = 10;
FIELD_IDX_T A_FctSecuProfCompo_RiskViewFlg           = 11;
FIELD_IDX_T A_FctSecuProfCompo_RealTimeFlg           = 12;
FIELD_IDX_T A_FctSecuProfCompo_ViewFlg               = 13;
FIELD_IDX_T A_FctSecuProfCompo_VisibleFlg            = 14;
FIELD_IDX_T A_FctSecuProfCompo_SlicingTreshold       = 15; /*<PMSTA11810-BRO-110415*/
FIELD_IDX_T A_FctSecuProfCompo_AsyncTreshold         = 16;
FIELD_IDX_T A_FctSecuProfCompo_ExecTreshold          = 17; /*>PMSTA11810-BRO-110415*/
FIELD_IDX_T A_FctSecuProfCompo_MaxStatusParam		 = 18; /* PMSTA-12034 RBN 09/08/11*/
FIELD_IDX_T A_FctSecuProfCompo_MinStatusParam		 = 19; /* PMSTA-12034 RBN 09/08/11*/


FIELD_IDX_T S_FctSecuProfCompo_FctSecuProfId         = 0;
FIELD_IDX_T S_FctSecuProfCompo_FctDictId             = 1;
FIELD_IDX_T S_FctSecuProfCompo_EntDictId             = 2;
FIELD_IDX_T S_FctSecuProfCompo_TpId                  = 3;
FIELD_IDX_T S_FctSecuProfCompo_SubTpId               = 4;
FIELD_IDX_T S_FctSecuProfCompo_MinStatEn             = 5;
FIELD_IDX_T S_FctSecuProfCompo_MaxStatEn             = 6;
FIELD_IDX_T S_FctSecuProfCompo_CreateFlg             = 7;
FIELD_IDX_T S_FctSecuProfCompo_UpdFlg                = 8;
FIELD_IDX_T S_FctSecuProfCompo_DelFlg                = 9;
FIELD_IDX_T S_FctSecuProfCompo_SecuLevelEn           = 10;
FIELD_IDX_T S_FctSecuProfCompo_RiskViewFlg           = 11;
FIELD_IDX_T S_FctSecuProfCompo_RealTimeFlg           = 12;
FIELD_IDX_T S_FctSecuProfCompo_FctName               = 13;
FIELD_IDX_T S_FctSecuProfCompo_EntSqlName            = 14;
FIELD_IDX_T S_FctSecuProfCompo_TpCd                  = 15;
FIELD_IDX_T S_FctSecuProfCompo_SubTpCd               = 16;
FIELD_IDX_T S_FctSecuProfCompo_ViewFlg               = 17;


FIELD_IDX_T A_FctSecuProf_Id                         = 0;
FIELD_IDX_T A_FctSecuProf_Cd                         = 1;


FIELD_IDX_T S_FctSecuProf_Id                         = 0;
FIELD_IDX_T S_FctSecuProf_Cd                         = 1;


FIELD_IDX_T E_Fmt_Id                                 = 0;
FIELD_IDX_T E_Fmt_Cd                                 = 1;
FIELD_IDX_T E_Fmt_Name                               = 2;
FIELD_IDX_T E_Fmt_Denom                              = 3;
FIELD_IDX_T E_Fmt_FctDictId                          = 4;
FIELD_IDX_T E_Fmt_ParFmtId                           = 5;
FIELD_IDX_T E_Fmt_EntDictId                          = 6;
FIELD_IDX_T E_Fmt_RiskFlg                            = 7;
FIELD_IDX_T E_Fmt_NatEn                              = 8;
FIELD_IDX_T E_Fmt_BreakCritName                      = 9;
FIELD_IDX_T E_Fmt_BreakVal                           = 10;
FIELD_IDX_T E_Fmt_Filter                             = 11;
FIELD_IDX_T E_Fmt_GraphTpEn                          = 12;
FIELD_IDX_T E_Fmt_GraphViewEn                        = 13;
FIELD_IDX_T E_Fmt_Overlap                            = 14;
FIELD_IDX_T E_Fmt_ModifDate                          = 15;
FIELD_IDX_T E_Fmt_LevelNum                           = 16;
FIELD_IDX_T E_Fmt_IconName                           = 17;
FIELD_IDX_T E_Fmt_MaxBreak                           = 18;
FIELD_IDX_T E_Fmt_Rank                               = 19;
FIELD_IDX_T E_Fmt_DfltFlg                            = 20;
FIELD_IDX_T E_Fmt_ScreenDictId                       = 21;
FIELD_IDX_T E_Fmt_AutoWidthFlg                       = 22;  /*  FPL-PMSTA09887-101206   */
FIELD_IDX_T E_Fmt_ReferenceFmtId                     = 23;  /*  HFI-PMSTA-38117-200228  */
FIELD_IDX_T E_Fmt_ReferenceStatusEn                  = 24;  /*  HFI-PMSTA-38117-200228  */
FIELD_IDX_T E_Fmt_E_ChildFmt_Ext                     = 25;
FIELD_IDX_T E_Fmt_A_FmtElt_Ext                       = 26;



FIELD_IDX_T Sum_FmtElt_FmtId                         = 0;
FIELD_IDX_T Sum_FmtElt_FmtCd                         = 1;
FIELD_IDX_T Sum_FmtElt_FmtName                       = 2;
FIELD_IDX_T Sum_FmtElt_FmtDenom                      = 3;
FIELD_IDX_T Sum_FmtElt_FmtFctDictId                  = 4;
FIELD_IDX_T Sum_FmtElt_FmtParFmtId                   = 5;
FIELD_IDX_T Sum_FmtElt_FmtEntDictId                  = 6;
FIELD_IDX_T Sum_FmtElt_FmtRiskFlg                    = 7;
FIELD_IDX_T Sum_FmtElt_FmtNatEn                      = 8;
FIELD_IDX_T Sum_FmtElt_FmtBreakCritName              = 9;
FIELD_IDX_T Sum_FmtElt_FmtBreakVal                   = 10;
FIELD_IDX_T Sum_FmtElt_FmtFilter                     = 11;
FIELD_IDX_T Sum_FmtElt_FmtGraphTpEn                  = 12;
FIELD_IDX_T Sum_FmtElt_FmtGraphViewEn                = 13;
FIELD_IDX_T Sum_FmtElt_FmtOverlap                    = 14;
FIELD_IDX_T Sum_FmtElt_FmtModifDate                  = 15;
FIELD_IDX_T Sum_FmtElt_FmtLevelNum                   = 16;
FIELD_IDX_T Sum_FmtElt_FmtIconName                   = 17;
FIELD_IDX_T Sum_FmtElt_FmtMaxBreak                   = 18;
FIELD_IDX_T Sum_FmtElt_FmtScreenDictId               = 19;
FIELD_IDX_T Sum_FmtElt_Id                            = 20;
FIELD_IDX_T Sum_FmtElt_SqlName                       = 21;
FIELD_IDX_T Sum_FmtElt_Rank                          = 22;
FIELD_IDX_T Sum_FmtElt_Name                          = 23;
FIELD_IDX_T Sum_FmtElt_Denom                         = 24;
FIELD_IDX_T Sum_FmtElt_DataTpDictId                  = 25;
FIELD_IDX_T Sum_FmtElt_AttrDictId                    = 26;
FIELD_IDX_T Sum_FmtElt_DspFmt                        = 27;
FIELD_IDX_T Sum_FmtElt_DspCol                        = 28;
FIELD_IDX_T Sum_FmtElt_DspRow                        = 29;
FIELD_IDX_T Sum_FmtElt_DspContext                    = 30;
FIELD_IDX_T Sum_FmtElt_FxdFlg                        = 31;
FIELD_IDX_T Sum_FmtElt_ConsFlg                       = 32;
FIELD_IDX_T Sum_FmtElt_SubTotFlg                     = 33;
FIELD_IDX_T Sum_FmtElt_Tot                           = 34;
FIELD_IDX_T Sum_FmtElt_SrtRank                       = 35;
FIELD_IDX_T Sum_FmtElt_SrtRuleEn                     = 36;
FIELD_IDX_T Sum_FmtElt_HorizCoord                    = 37;
FIELD_IDX_T Sum_FmtElt_VertCoord                     = 38;
FIELD_IDX_T Sum_FmtElt_ColWidth                      = 39;
FIELD_IDX_T Sum_FmtElt_ZoomFlg                       = 40;
FIELD_IDX_T Sum_FmtElt_BackgrCol                     = 41;
FIELD_IDX_T Sum_FmtElt_ForegrCol                     = 42;
FIELD_IDX_T Sum_FmtElt_ItalicFlg                     = 43;
FIELD_IDX_T Sum_FmtElt_BoldFlg                       = 44;
FIELD_IDX_T Sum_FmtElt_JustifEn                      = 45;
FIELD_IDX_T Sum_FmtElt_EditFlg                       = 46;
FIELD_IDX_T Sum_FmtElt_HierNatEn                     = 47;
FIELD_IDX_T Sum_FmtElt_TlsMultilingualEn             = 48; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
FIELD_IDX_T Sum_FmtElt_LangDictId                    = 49; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
FIELD_IDX_T Sum_FmtElt_TslProcessingNatEn            = 40; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
FIELD_IDX_T Sum_FmtElt_Definition                    = 51;
FIELD_IDX_T Sum_FmtElt_ClassifId                     = 52;
FIELD_IDX_T Sum_FmtElt_ColNb                         = 53;
FIELD_IDX_T Sum_FmtElt_DataSetNb                     = 54;
FIELD_IDX_T Sum_FmtElt_DataSetBreakCriteria          = 55; /* PMSTA09776 - DDV - 100505 */


FIELD_IDX_T A_FmtProf_Id                             = 0;
FIELD_IDX_T A_FmtProf_Cd                             = 1;
FIELD_IDX_T A_FmtProf_OwnerUserId                    = 2;


FIELD_IDX_T S_FmtProf_Id                             = 0;
FIELD_IDX_T S_FmtProf_Cd                             = 1;


FIELD_IDX_T A_FmtProfCompo_Id                        = 0;
FIELD_IDX_T A_FmtProfCompo_FmtProfId                 = 1;
FIELD_IDX_T A_FmtProfCompo_FmtId                     = 2;
FIELD_IDX_T A_FmtProfCompo_RefFmtId                  = 3;
FIELD_IDX_T A_FmtProfCompo_Rank                      = 4;
FIELD_IDX_T A_FmtProfCompo_DfltFlg                   = 5;


FIELD_IDX_T S_FmtProfCompo_Id                        = 0;
FIELD_IDX_T S_FmtProfCompo_FmtProfId                 = 1;
FIELD_IDX_T S_FmtProfCompo_FmtId                     = 2;
FIELD_IDX_T S_FmtProfCompo_Rank                      = 3;
FIELD_IDX_T S_FmtProfCompo_FmtProfCd                 = 4;
FIELD_IDX_T S_FmtProfCompo_FmtCd                     = 5;
FIELD_IDX_T S_FmtProfCompo_FctName                   = 6;
FIELD_IDX_T S_FmtProfCompo_FmtNatEn                  = 7;

/* PCC13654 - LJE - 090624 */
FIELD_IDX_T A_InputEntity_Sqlname                    = 0;
FIELD_IDX_T A_InputEntity_Param                      = 1;
FIELD_IDX_T A_InputEntity_OutputTypeEn               = 2;
FIELD_IDX_T A_InputEntity_OptionEn                   = 3;
FIELD_IDX_T A_InputEntity_ScreenDictId               = 4;
FIELD_IDX_T A_InputEntity_UserId                     = 5;
FIELD_IDX_T A_InputEntity_DataProfileId              = 6;
FIELD_IDX_T A_InputEntity_LanguageDictId             = 7;
FIELD_IDX_T A_InputEntity_FunctionDictId             = 8;
FIELD_IDX_T A_InputEntity_Codifications              = 9;
FIELD_IDX_T A_InputEntity_TextConverterEn            =10;
FIELD_IDX_T A_InputEntity_ApplSessionCd              =11; /* PMSTA-22549 - CHU - 160512 */

FIELD_IDX_T A_OutputEntity_Rank                      = 0;
FIELD_IDX_T A_OutputEntity_Result                    = 1;

FIELD_IDX_T A_OutputPermVal_AttibSqlname             = 0;
FIELD_IDX_T A_OutputPermVal_Rank                     = 1;
FIELD_IDX_T A_OutputPermVal_Result                   = 2;

FIELD_IDX_T A_OutputMsg_FullName                     = 0;
FIELD_IDX_T A_OutputMsg_NatEn                        = 1;
FIELD_IDX_T A_OutputMsg_Rank                         = 2;
FIELD_IDX_T A_OutputMsg_Message                      = 3;

FIELD_IDX_T A_Folder_Id                              = 0;
FIELD_IDX_T A_Folder_Cd                              = 1;
FIELD_IDX_T A_Folder_Name                            = 2;
FIELD_IDX_T A_Folder_UserId                          = 3;
FIELD_IDX_T A_Folder_CrtFlag                         = 4;
FIELD_IDX_T A_Folder_Rank                            = 5;
FIELD_IDX_T A_Folder_LastNoteDate                    = 6;
FIELD_IDX_T A_Folder_IconName                        = 7;


FIELD_IDX_T S_Folder_Id                              = 0;
FIELD_IDX_T S_Folder_Cd                              = 1;
FIELD_IDX_T S_Folder_Name                            = 2;
FIELD_IDX_T S_Folder_UserId                          = 3;


FIELD_IDX_T A_FundVal_Id                             = 0;
FIELD_IDX_T A_FundVal_PtfId                          = 1;
FIELD_IDX_T A_FundVal_ValuationDate                  = 2;
FIELD_IDX_T A_FundVal_ValoSeqNo                      = 3;
FIELD_IDX_T A_FundVal_OfficialFlg                    = 4;


FIELD_IDX_T S_FundVal_Id                             = 0;
FIELD_IDX_T S_FundVal_PtfId                          = 1;
FIELD_IDX_T S_FundVal_ValuationDate                  = 2;
FIELD_IDX_T S_FundVal_ValoSeqNo                      = 3;
FIELD_IDX_T S_FundVal_OfficialFlg                    = 4;


FIELD_IDX_T A_FundValElt_Id                          = 0;
FIELD_IDX_T A_FundValElt_FundValId                   = 1;
FIELD_IDX_T A_FundValElt_AccPlanEltId                = 2;
FIELD_IDX_T A_FundValElt_InstrId                     = 3;
FIELD_IDX_T A_FundValElt_ValuationAmt                = 4;


FIELD_IDX_T S_FundValElt_Id                          = 0;
FIELD_IDX_T S_FundValElt_FundValId                   = 1;
FIELD_IDX_T S_FundValElt_AccPlanEltId                = 2;
FIELD_IDX_T S_FundValElt_InstrId                     = 3;
FIELD_IDX_T S_FundValElt_ValuationAmt                = 4;
FIELD_IDX_T S_FundValElt_PtfId                       = 5;
FIELD_IDX_T S_FundValElt_ValuationDate               = 6;
FIELD_IDX_T S_FundValElt_ValoSeqNo                   = 7;
FIELD_IDX_T S_FundValElt_AccPlanEltName              = 8;
FIELD_IDX_T S_FundValElt_AccPlanEltDenom             = 9;
FIELD_IDX_T S_FundValElt_ItemDisp                    = 10;
FIELD_IDX_T S_FundValElt_ItemNatEn                   = 11;


FIELD_IDX_T A_FundWgt_InstrId                        = 0;
FIELD_IDX_T A_FundWgt_BegDate                        = 1;
FIELD_IDX_T A_FundWgt_PtfId                          = 2;
FIELD_IDX_T A_FundWgt_WgtPrct                        = 3;
FIELD_IDX_T A_FundWgt_ShareNum                       = 4;


FIELD_IDX_T S_FundWgt_InstrId                        = 0;
FIELD_IDX_T S_FundWgt_BegDate                        = 1;
FIELD_IDX_T S_FundWgt_PtfId                          = 2;
FIELD_IDX_T S_FundWgt_InstrCd                        = 3;
FIELD_IDX_T S_FundWgt_WgtPrct                        = 4;
FIELD_IDX_T S_FundWgt_ShareNum                       = 5;


FIELD_IDX_T A_Event_Id                               = 0;
FIELD_IDX_T A_Event_FunctionResultId                 = 1; /* DLA - REF10247 - 050708 */
FIELD_IDX_T A_Event_Hostname                         = 2;
FIELD_IDX_T A_Event_User                             = 3;
FIELD_IDX_T A_Event_StatusEn                         = 4;
FIELD_IDX_T A_Event_NatureEn                         = 5;
FIELD_IDX_T A_Event_EntSqlName                       = 6;
FIELD_IDX_T A_Event_FctSqlName                       = 7;
FIELD_IDX_T A_Event_ActionEn                         = 8;
FIELD_IDX_T A_Event_ModuleEn                         = 9;
FIELD_IDX_T A_Event_CreationDate                     = 10;
FIELD_IDX_T A_Event_ExecutionDate                    = 11;
FIELD_IDX_T A_Event_UpdateStsName                    = 12;
FIELD_IDX_T A_Event_MapStorage                       = 13;
FIELD_IDX_T A_Event_FormatId                         = 14;
FIELD_IDX_T A_Event_DestinationCd                    = 15; /* DLA - REF10247 - 050708 */
FIELD_IDX_T A_Event_Priority                         = 16; /* DLA - REF10247 - 050708 */
FIELD_IDX_T A_Event_OperationStatusEn                = 17; /* DLA - REF10247 - 050708 */
FIELD_IDX_T A_Event_OperationCd                      = 18; /* DLA - REF10247 - 050708 */
FIELD_IDX_T A_Event_SubscriptionCd                   = 19; /* DLA - REF10247 - 050714 */
FIELD_IDX_T A_Event_OpTimeStamp                      = 20; /* DLA - PMSTA05995 - 080407 */
FIELD_IDX_T A_Event_Data                             = 21;
FIELD_IDX_T A_Event_BusEntityCd                      = 22; /* PMSTA-17089 - DDV - 131202 */
FIELD_IDX_T A_Event_RequestStatusEn                  = 23; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T A_Event_EventStatusFlg                   = 24; /* PMSTA-17112 - PCL - 131217 */
FIELD_IDX_T A_Event_GroupingCode                     = 25; /* PMSTA-17793 - DDV - 140314 */



FIELD_IDX_T S_Event_Id                               = 0;
FIELD_IDX_T S_Event_FunctionResultId                 = 1; /* DLA - REF10247 - 050708 */
FIELD_IDX_T S_Event_Hostname                         = 2;
FIELD_IDX_T S_Event_User                             = 3;
FIELD_IDX_T S_Event_CreationDate                     = 4;
FIELD_IDX_T S_Event_NatureEn                         = 5;
FIELD_IDX_T S_Event_EntSqlName                       = 6;
FIELD_IDX_T S_Event_FctSqlName                       = 7;
FIELD_IDX_T S_Event_ActionEn                         = 8;
FIELD_IDX_T S_Event_StatusEn                         = 9;
FIELD_IDX_T S_Event_DestinationCd                    = 10; /* DLA - REF10247 - 050708 */
FIELD_IDX_T S_Event_Priority                         = 11; /* DLA - REF10247 - 050708 */
FIELD_IDX_T S_Event_OperationStatusEn                = 12; /* DLA - REF10247 - 050708 */
FIELD_IDX_T S_Event_OperationCd                      = 13; /* DLA - REF10247 - 050708 */

FIELD_IDX_T A_EventUpdate_LastModifDate              = 0;

FIELD_IDX_T A_FamilyDef_Id                           = 0;
FIELD_IDX_T A_FamilyDef_DynSt                        = 1;
FIELD_IDX_T A_FamilyDef_ParentFldIdx                 = 2;
FIELD_IDX_T A_FamilyDef_IdFldIdx                     = 3;
FIELD_IDX_T A_FamilyDef_RootNb                       = 4;
FIELD_IDX_T A_FamilyDef_RootExt                      = 5;

FIELD_IDX_T A_FamilyElt_FamilyId                     = 0;
FIELD_IDX_T A_FamilyElt_FamilyExt                    = 1;
FIELD_IDX_T A_FamilyElt_EltId                        = 2;
FIELD_IDX_T A_FamilyElt_EltExt                       = 3;
FIELD_IDX_T A_FamilyElt_ParentId                     = 4;
FIELD_IDX_T A_FamilyElt_ParentExt                    = 5;
FIELD_IDX_T A_FamilyElt_ChildrenExt                  = 6;


FIELD_IDX_T A_Grid_Id                                = 0;
FIELD_IDX_T A_Grid_Cd                                = 1;
FIELD_IDX_T A_Grid_Name                              = 2;
FIELD_IDX_T A_Grid_Denom                             = 3;
FIELD_IDX_T A_Grid_TypeId                            = 4; /*REF11734-EFE-060320*/
FIELD_IDX_T A_Grid_ParMktSegtId                      = 5;
FIELD_IDX_T A_Grid_AbcissaClassifId                  = 6;
FIELD_IDX_T A_Grid_OrdinateClassifId                 = 7;
FIELD_IDX_T A_Grid_PrimGridFlg                       = 8;
FIELD_IDX_T A_Grid_NatEn                             = 9;
FIELD_IDX_T A_Grid_GlobalGridId                      = 10;
FIELD_IDX_T A_Grid_DataSecuProfId                    = 11; /*PMSTA07407-BRO-090529*/
FIELD_IDX_T A_Grid_Abcissa_A_Classif_Ext             = 12;
FIELD_IDX_T A_Grid_Ordinate_A_Classif_Ext            = 13;
FIELD_IDX_T A_Grid_S_MktSegt_Ext                     = 14;
FIELD_IDX_T A_Grid_ListCompoLevel                    = 15;
FIELD_IDX_T A_Grid_ParMktSegtGridId                  = 16;


FIELD_IDX_T S_Grid_Id                                = 0;
FIELD_IDX_T S_Grid_Cd                                = 1;
FIELD_IDX_T S_Grid_Name                              = 2;
FIELD_IDX_T S_Grid_NatEn                             = 3;
FIELD_IDX_T S_Grid_GlobalGridId                      = 4;

FIELD_IDX_T A_Guarantee_Id                           = 0;
FIELD_IDX_T A_Guarantee_InstrId                      = 1;
FIELD_IDX_T A_Guarantee_ThirdId                      = 2;
FIELD_IDX_T A_Guarantee_TpId                         = 3;
FIELD_IDX_T A_Guarantee_GuaranteePrct                = 4;

/* PMSTA-17793 - DDV - 140318 */
FIELD_IDX_T A_EventGroupingId_Id                     = 0;

/* PMSTA-17793 - DDV - 140318 */
FIELD_IDX_T S_EventGroupingId_Id                     = 0;
FIELD_IDX_T S_EventGroupingId_BlockSize              = 1;
FIELD_IDX_T S_EventGroupingId_IdentityResSize        = 2;

FIELD_IDX_T S_Guarantee_Id                           = 0;
FIELD_IDX_T S_Guarantee_InstrId                      = 1;
FIELD_IDX_T S_Guarantee_ThirdId                      = 2;
FIELD_IDX_T S_Guarantee_TpId                         = 3;
FIELD_IDX_T S_Guarantee_ThirdCd                      = 4;
FIELD_IDX_T S_Guarantee_TpCd                         = 5;
FIELD_IDX_T S_Guarantee_GuaranteePrct                = 6;


FIELD_IDX_T A_InstrChrono_InstrId                    = 0;
FIELD_IDX_T A_InstrChrono_NatEn                      = 1;
FIELD_IDX_T A_InstrChrono_ValidDate                  = 2;
FIELD_IDX_T A_InstrChrono_ThirdPartyId               = 3;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T A_InstrChrono_CurrId                     = 4;
FIELD_IDX_T A_InstrChrono_Val                        = 5;
FIELD_IDX_T A_InstrChrono_SubNatTypeId               = 6;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T A_InstrChrono_RetCd                      = 7;
FIELD_IDX_T A_InstrChrono_OptiDate                   = 8;  /* PMSTA-10748 - LJE - 110210 */
FIELD_IDX_T A_InstrChrono_DefMarket                  = 9;


FIELD_IDX_T S_InstrChrono_InstrId                    = 0;
FIELD_IDX_T S_InstrChrono_NatEn                      = 1;
FIELD_IDX_T S_InstrChrono_ValidDate                  = 2;
FIELD_IDX_T S_InstrChrono_ThirdPartyId               = 3;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T S_InstrChrono_Val                        = 4;
FIELD_IDX_T S_InstrChrono_SubNatTypeId               = 5;  /* REF10598 - LJE - 041008 */
FIELD_IDX_T S_InstrChrono_InstrCd                    = 6;
FIELD_IDX_T S_InstrChrono_CurrCd                     = 7;
FIELD_IDX_T S_InstrChrono_TimeDimEn                  = 8;
FIELD_IDX_T S_InstrChrono_ValidFlg                   = 9;
FIELD_IDX_T S_InstrChrono_ThirdPartyCd               = 10;  /* REF10598 - LJE - 041221 */
FIELD_IDX_T S_InstrChrono_SubNatTypeCd               = 11;  /*PMSTA04275-BRO-071025*/
FIELD_IDX_T S_InstrChrono_DefMarket                  = 12;


FIELD_IDX_T Dim_InstrChrono_InstrId                  = 0;
FIELD_IDX_T Dim_InstrChrono_RefDate                  = 1;
FIELD_IDX_T Dim_InstrChrono_ValidPeriod              = 2;
FIELD_IDX_T Dim_InstrChrono_ThirdPartyId             = 3;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Dim_InstrChrono_SubNatTypeId             = 4;  /* REF10598 - LJE - 041007 */
FIELD_IDX_T Dim_InstrChrono_SubNatFlg                = 5;  /* REF10598 - LJE - 041007 */
FIELD_IDX_T Dim_InstrChrono_NatEn                    = 6;
FIELD_IDX_T Dim_InstrChrono_ComputeFlg               = 7;
FIELD_IDX_T Dim_InstrChrono_ThirdPartyFlg            = 8;  /* PMSTA13097-SRU-111115 */
FIELD_IDX_T Dim_InstrChrono_DomQuoteValRuleId        = 9;  /* PMSTA14879 - DDV - 120920 */
FIELD_IDX_T Dim_InstrChrono_CurrId                   = 10; /* PMSTA-17571 -cashwini -150616-Parameter currency is missing in INSTR_CHRONO*/
FIELD_IDX_T Dim_InstrChrono_DefMarket                = 11; /* suparna-PMSTA-53526-2023-09-01 - adding new Parameter def_market to INSTR_CHRONO */

FIELD_IDX_T Freq_InstrChrono_InstrId                 = 0;
FIELD_IDX_T Freq_InstrChrono_NatEn                   = 1;
FIELD_IDX_T Freq_InstrChrono_ValidDate               = 2;
FIELD_IDX_T Freq_InstrChrono_ThirdPartyId            = 3;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Freq_InstrChrono_CurrId                  = 4;
FIELD_IDX_T Freq_InstrChrono_Val                     = 5;
FIELD_IDX_T Freq_InstrChrono_SubNatTypeId            = 6;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Freq_InstrChrono_RequestDate             = 7;

/*<REF11718-BRO-060301*/
FIELD_IDX_T A_InstrDeposit_Id                         = 0;
FIELD_IDX_T A_InstrDeposit_InstrId                    = 1;
FIELD_IDX_T A_InstrDeposit_DepositId                  = 2;
FIELD_IDX_T A_InstrDeposit_Rank                       = 3;
FIELD_IDX_T A_InstrDeposit_MainDepositFlg             = 4;
FIELD_IDX_T A_InstrDeposit_LastUserId                 = 5;
FIELD_IDX_T A_InstrDeposit_LastModifDate              = 6;
FIELD_IDX_T A_InstrDeposit_PaymentOption              = 7; /* PMSTA-30658 - AiswaryaM -20180503 */

FIELD_IDX_T S_InstrDeposit_Id                         = 0;
FIELD_IDX_T S_InstrDeposit_InstrId                    = 1;
FIELD_IDX_T S_InstrDeposit_DepositId                  = 2;
FIELD_IDX_T S_InstrDeposit_Rank                       = 3;
FIELD_IDX_T S_InstrDeposit_MainDepositFlg             = 4;
FIELD_IDX_T S_InstrDeposit_InstrCd                    = 5;
FIELD_IDX_T S_InstrDeposit_InstrName                  = 6;
FIELD_IDX_T S_InstrDeposit_DepositCd                  = 7;
/*>REF11718-BRO-060301*/


FIELD_IDX_T A_InstrFreq_Id                           = 0;
FIELD_IDX_T A_InstrFreq_FreqDate                     = 1;
FIELD_IDX_T A_InstrFreq_InstrId                      = 2;
FIELD_IDX_T A_InstrFreq_InitialDate                  = 3;
FIELD_IDX_T A_InstrFreq_PSPId                        = 4; /* REF9125 - LJE - 030818 */
FIELD_IDX_T A_InstrFreq_A_Instr_Ext                  = 5;

/* PMSTA-18096 - LJE - 140620 */
FIELD_IDX_T A_InstrRiskOrig_Id                = 0;
FIELD_IDX_T A_InstrRiskOrig_InstrId           = 1;
FIELD_IDX_T A_InstrRiskOrig_RiskOriginInstrId = 2;


FIELD_IDX_T A_InstrPrice_InstrId                     = 0;
FIELD_IDX_T A_InstrPrice_CurrId                      = 1;
FIELD_IDX_T A_InstrPrice_TpId                        = 2;
FIELD_IDX_T A_InstrPrice_ThirdId                     = 3;
FIELD_IDX_T A_InstrPrice_TermTpId                    = 4;
FIELD_IDX_T A_InstrPrice_MktThirdId                  = 5;
FIELD_IDX_T A_InstrPrice_QuoteDate                   = 6;
FIELD_IDX_T A_InstrPrice_DailyDfltFlg                = 7;
FIELD_IDX_T A_InstrPrice_Quote                       = 8;
FIELD_IDX_T A_InstrPrice_Price                       = 9;
FIELD_IDX_T A_InstrPrice_PriceCalcRuleEn             = 10;
FIELD_IDX_T A_InstrPrice_UnicityFlg                  = 11;
FIELD_IDX_T A_InstrPrice_ValRuleId                   = 12;
FIELD_IDX_T A_InstrPrice_ValRuleEltId                = 13;
FIELD_IDX_T A_InstrPrice_ValRuleCoef                 = 14;
FIELD_IDX_T A_InstrPrice_CoefNatEn                   = 15;
FIELD_IDX_T A_InstrPrice_ActuRate                    = 16;
FIELD_IDX_T A_InstrPrice_FwdSpotPrice                = 17;
FIELD_IDX_T A_InstrPrice_BegCoveredPerDate           = 18;
FIELD_IDX_T A_InstrPrice_EndCoveredPerDate           = 19;
FIELD_IDX_T A_InstrPrice_DiscFac                     = 20;
FIELD_IDX_T A_InstrPrice_ExtendedLoadFlg             = 21; /* PMSTA-30132 - DDV - 180315 */


FIELD_IDX_T S_InstrPrice_InstrId                     = 0;
FIELD_IDX_T S_InstrPrice_CurrId                      = 1;
FIELD_IDX_T S_InstrPrice_TpId                        = 2;
FIELD_IDX_T S_InstrPrice_ThirdId                     = 3;
FIELD_IDX_T S_InstrPrice_TermTpId                    = 4;
FIELD_IDX_T S_InstrPrice_MktThirdId                  = 5;
FIELD_IDX_T S_InstrPrice_QuoteDate                   = 6;
FIELD_IDX_T S_InstrPrice_InstrCd                     = 7;
FIELD_IDX_T S_InstrPrice_CurrCd                      = 8;
FIELD_IDX_T S_InstrPrice_TpCd                        = 9;
FIELD_IDX_T S_InstrPrice_ThirdCd                     = 10;
FIELD_IDX_T S_InstrPrice_TermTpCd                    = 11;
FIELD_IDX_T S_InstrPrice_MktThirdCd                  = 12;
FIELD_IDX_T S_InstrPrice_Quote                       = 13;


FIELD_IDX_T InstrPriceIdx_InstrId                    = 0;
FIELD_IDX_T InstrPriceIdx_InstrPriceTab_Ext          = 1;
FIELD_IDX_T InstrPriceIdx_InstrPriceNbr              = 2;


FIELD_IDX_T Freq_InstrPrice_InstrId                  = 0;
FIELD_IDX_T Freq_InstrPrice_CurrId                   = 1;
FIELD_IDX_T Freq_InstrPrice_TpId                     = 2;
FIELD_IDX_T Freq_InstrPrice_ThirdId                  = 3;
FIELD_IDX_T Freq_InstrPrice_TermTpId                 = 4;
FIELD_IDX_T Freq_InstrPrice_MktThirdId               = 5;
FIELD_IDX_T Freq_InstrPrice_QuoteDate                = 6;
FIELD_IDX_T Freq_InstrPrice_DailyDfltFlg             = 7;
FIELD_IDX_T Freq_InstrPrice_Quote                    = 8;
FIELD_IDX_T Freq_InstrPrice_Price                    = 9;
FIELD_IDX_T Freq_InstrPrice_PriceCalcRuleEn          = 10;
FIELD_IDX_T Freq_InstrPrice_UnicityFlg               = 11;
FIELD_IDX_T Freq_InstrPrice_RequestDate              = 12;

FIELD_IDX_T A_IssueEvt_InstrId                       = 0;
FIELD_IDX_T A_IssueEvt_ValidDate                     = 1;
FIELD_IDX_T A_IssueEvt_BegDate                       = 2;
FIELD_IDX_T A_IssueEvt_NatEn                         = 3;
FIELD_IDX_T A_IssueEvt_Cd                            = 4;
FIELD_IDX_T A_IssueEvt_CurrId                        = 5;
FIELD_IDX_T A_IssueEvt_ExclId                        = 6;
FIELD_IDX_T A_IssueEvt_YieldCurveInstrId             = 7;
FIELD_IDX_T A_IssueEvt_AnnounceDate                  = 8;
FIELD_IDX_T A_IssueEvt_EndDate                       = 9;
FIELD_IDX_T A_IssueEvt_EndValidDate                  = 0;
FIELD_IDX_T A_IssueEvt_Price                         = 11;
FIELD_IDX_T A_IssueEvt_Quote                         = 12;
FIELD_IDX_T A_IssueEvt_Freq                          = 13;
FIELD_IDX_T A_IssueEvt_FreqUnitEn                    = 14;
FIELD_IDX_T A_IssueEvt_ProporPrct                    = 15;
FIELD_IDX_T A_IssueEvt_FxdExchRate                   = 16;
FIELD_IDX_T A_IssueEvt_SettlDays                     = 17;
FIELD_IDX_T A_IssueEvt_EffectiveDate                 = 18;
FIELD_IDX_T A_IssueEvt_NoticeDay                     = 19;
FIELD_IDX_T A_IssueEvt_InstrNatEn                    = 20;
FIELD_IDX_T A_IssueEvt_InstrTpId                     = 21;
FIELD_IDX_T A_IssueEvt_InstrSubTpId                  = 22;
FIELD_IDX_T A_IssueEvt_ProporApplEn                  = 23;  /* PMSTA-32106 - AiswaryaM - 20180723*/
FIELD_IDX_T A_IssueEvt_EventStatusEn                 = 24;	/* EnumType            */
FIELD_IDX_T A_IssueEvt_EventTypeId                   = 25;	/* IdType              */
FIELD_IDX_T A_IssueEvt_CommitmentReference           = 26;	/* InfoType            */
FIELD_IDX_T A_IssueEvt_EventAmount                   = 27;	/* AmountType          */

FIELD_IDX_T S_IssueEvt_InstrId                       = 0;
FIELD_IDX_T S_IssueEvt_ValidDate                     = 1;
FIELD_IDX_T S_IssueEvt_BegDate                       = 2;
FIELD_IDX_T S_IssueEvt_NatEn                         = 3;
FIELD_IDX_T S_IssueEvt_Cd                            = 4;
FIELD_IDX_T S_IssueEvt_InstrNatEn                    = 5;

FIELD_IDX_T A_ListChrono_ListId                      = 0;
FIELD_IDX_T A_ListChrono_CurrId                      = 1;
FIELD_IDX_T A_ListChrono_ValidDate                   = 2;
FIELD_IDX_T A_ListChrono_NatEn                       = 3;
FIELD_IDX_T A_ListChrono_Val                         = 4;
FIELD_IDX_T A_ListChrono_TimeDimEn                   = 5;
FIELD_IDX_T A_ListChrono_ValidFlg                    = 6;


FIELD_IDX_T S_ListChrono_ListId                      = 0;
FIELD_IDX_T S_ListChrono_CurrId                      = 1;
FIELD_IDX_T S_ListChrono_ValidDate                   = 2;
FIELD_IDX_T S_ListChrono_NatEn                       = 3;
FIELD_IDX_T S_ListChrono_ListCd                      = 4;
FIELD_IDX_T S_ListChrono_Val                         = 5;
FIELD_IDX_T S_ListChrono_CurrCd                      = 6;


FIELD_IDX_T Freq_ListChrono_ListId                   = 0;
FIELD_IDX_T Freq_ListChrono_CurrId                   = 1;
FIELD_IDX_T Freq_ListChrono_ValidDate                = 2;
FIELD_IDX_T Freq_ListChrono_NatEn                    = 3;
FIELD_IDX_T Freq_ListChrono_Val                      = 4;
FIELD_IDX_T Freq_ListChrono_RequestDate              = 5;


FIELD_IDX_T A_ListCompo_Id                           = 0;
FIELD_IDX_T A_ListCompo_EntDictId                    = 1;
FIELD_IDX_T A_ListCompo_ObjId                        = 2;
FIELD_IDX_T A_ListCompo_ValidDt                      = 3;
FIELD_IDX_T A_ListCompo_Rank                         = 4;
FIELD_IDX_T A_ListCompo_A_Grid_Ext                   = 5;


FIELD_IDX_T S_ListCompo_Id                           = 0;
FIELD_IDX_T S_ListCompo_EntDictId                    = 1;
FIELD_IDX_T S_ListCompo_ObjId                        = 2;
FIELD_IDX_T S_ListCompo_ValidDt                      = 3;
FIELD_IDX_T S_ListCompo_ObjCd                        = 4;
FIELD_IDX_T S_ListCompo_ObjName                      = 5;
FIELD_IDX_T S_ListCompo_Rank                         = 6;
FIELD_IDX_T S_ListCompo_TypeId                       = 7; /* obnilouf-PMSTA-33569-190109 */


FIELD_IDX_T A_LoginFailed_UserCode                   = 0;
FIELD_IDX_T A_LoginFailed_LoginHistId                = 1;
FIELD_IDX_T A_LoginFailed_Display                    = 2;
FIELD_IDX_T A_LoginFailed_NatEn                      = 3;


FIELD_IDX_T A_Map_Id                                 = 0;
FIELD_IDX_T A_Map_Code                               = 1;
FIELD_IDX_T A_Map_Denom                              = 2;
FIELD_IDX_T A_Map_EntityDictId                       = 3;
FIELD_IDX_T A_Map_Storage                            = 4;


FIELD_IDX_T S_Map_Id                                 = 0;
FIELD_IDX_T S_Map_Code                               = 1;
FIELD_IDX_T S_Map_Denom                              = 2;
FIELD_IDX_T S_Map_EntityDictId                       = 3;
FIELD_IDX_T S_Map_Storage                            = 4;
FIELD_IDX_T S_Map_EntitySqlName                      = 5;


FIELD_IDX_T A_Mgr_Id                                 = 0;
FIELD_IDX_T A_Mgr_Cd                                 = 1;
FIELD_IDX_T A_Mgr_Name                               = 2;
FIELD_IDX_T A_Mgr_Denom                              = 3;
FIELD_IDX_T A_Mgr_AutoCreatedFlg                     = 4;
FIELD_IDX_T A_Mgr_Phone                              = 5;
FIELD_IDX_T A_Mgr_ExternFlg                          = 6;
FIELD_IDX_T A_Mgr_LastNoteDate                       = 7;
FIELD_IDX_T A_Mgr_LangEntDictId                      = 8;
FIELD_IDX_T A_Mgr_Password                           = 9;
FIELD_IDX_T A_Mgr_DataProfId                         = 10;
FIELD_IDX_T A_Mgr_DataSecuProfId                     = 11;
FIELD_IDX_T A_Mgr_EMailAdr                           = 12;
FIELD_IDX_T A_Mgr_CurrencyId                         = 13;
FIELD_IDX_T A_Mgr_WuiProfileEn                       = 14; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_WuiRoleEn                          = 15; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_ReportProfileId                    = 16; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_UserId                             = 17; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_ActiveFlg                          = 18; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_HeartUploadEn                      = 19; /*REF9446-BRO-030926*/
FIELD_IDX_T A_Mgr_DataSecuProf2Id                    = 20; /* PMSTA-14647 - LJE - 120712 */
FIELD_IDX_T A_Mgr_InputPassword                      = 21;
FIELD_IDX_T A_Mgr_SmartRoundingRuleId				 = 22; /* PMSTA-40493-badhri-08252020: smart rounding rule  */


FIELD_IDX_T S_Mgr_Id                                 = 0;
FIELD_IDX_T S_Mgr_Cd                                 = 1;
FIELD_IDX_T S_Mgr_Name                               = 2;
FIELD_IDX_T S_Mgr_CodifId                            = 5;


FIELD_IDX_T A_MktSegt_Id                             = 0;
FIELD_IDX_T A_MktSegt_Name                           = 1;
FIELD_IDX_T A_MktSegt_Denom                          = 2;
FIELD_IDX_T A_MktSegt_GridId                         = 3;
FIELD_IDX_T A_MktSegt_AbcissaListId                  = 4;
FIELD_IDX_T A_MktSegt_OrdinateListId                 = 5;
FIELD_IDX_T A_MktSegt_MktStructId                    = 6;
FIELD_IDX_T A_MktSegt_CashMktSegtEn                  = 7; /* REF10605-EFE-041005 */
FIELD_IDX_T A_MktSegt_CurrId                         = 8; /* PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_MktSegt_ParMktSegtId                   = 9; /* PMSTA08736 - LJE - 100216 */
FIELD_IDX_T A_MktSegt_VirtualCashMktSegtId           =10; /* PMSTA08736 - LJE - 100216 */
FIELD_IDX_T A_MktSegt_Level                          =11;
FIELD_IDX_T A_MktSegt_ParMktSegt_Ext                 =12; /* PMSTA08736 - LJE - 100216 */
FIELD_IDX_T A_MktSegt_ChildrenMktSegt_Ext            =13; /* PMSTA08736 - LJE - 100216 */
FIELD_IDX_T A_MktSegt_VirtualCashMktSegt_Ext         =14; /* PMSTA08736 - LJE - 100216 */
FIELD_IDX_T A_MktSegt_PerfEffectLink_Ext             =15; /* PMSTA-14965 - LJE - 120919 */
FIELD_IDX_T A_MktSegt_S_MktSegt_Ext                  =16; /* PMSTA-14965 - LJE - 120919 */


FIELD_IDX_T S_MktSegt_Id                             = 0;
FIELD_IDX_T S_MktSegt_Name                           = 1;
FIELD_IDX_T S_MktSegt_GridId                         = 2;
FIELD_IDX_T S_MktSegt_GridCd                         = 3;
FIELD_IDX_T S_MktSegt_AbcissaListId                  = 4;
FIELD_IDX_T S_MktSegt_AbcissaListCd                  = 5;
FIELD_IDX_T S_MktSegt_AbcissaListName                = 6;
FIELD_IDX_T S_MktSegt_AbcissaListRank                = 7;
FIELD_IDX_T S_MktSegt_OrdinateListId                 = 8;
FIELD_IDX_T S_MktSegt_OrdinateListCd                 = 9;
FIELD_IDX_T S_MktSegt_OrdinateListName               = 10;
FIELD_IDX_T S_MktSegt_OrdinateListRank               = 11;
FIELD_IDX_T S_MktSegt_AbcissaClassifId               = 12;
FIELD_IDX_T S_MktSegt_AbcissaClassifCd               = 13;
FIELD_IDX_T S_MktSegt_OrdinateClassifId              = 14;
FIELD_IDX_T S_MktSegt_OrdinateClassifCd              = 15;
FIELD_IDX_T S_MktSegt_MktStructId                    = 16;
FIELD_IDX_T S_MktSegt_ParMktSegtName                 = 17; /*REF10647-BRO-041117*/
FIELD_IDX_T S_MktSegt_CurrId                         = 18;
FIELD_IDX_T S_MktSegt_MktStructLevel                 = 19;
FIELD_IDX_T S_MktSegt_ParMktSegtId                   = 20;
FIELD_IDX_T S_MktSegt_Level                          = 21;
FIELD_IDX_T S_MktSegt_AbcissaParentId                = 22;	/* REF10679 - TEB - 041007 */
FIELD_IDX_T S_MktSegt_OrdinateParentId               = 23;	/* REF10679 - TEB - 041007 */
FIELD_IDX_T S_MktSegt_CashMktSegmentEn				 = 24;	/*PMSTA-43175-Badhri-21122020*/

FIELD_IDX_T A_MktStruct_Id                           = 0;
FIELD_IDX_T A_MktStruct_RefGridId                    = 1;
FIELD_IDX_T A_MktStruct_GridId                       = 2;
FIELD_IDX_T A_MktStruct_ParMktSegtId                 = 3;
FIELD_IDX_T A_MktStruct_ParMktStructId               = 4;
FIELD_IDX_T A_MktStruct_Rank                         = 5;
FIELD_IDX_T A_MktStruct_Level                        = 6;
FIELD_IDX_T A_MktStruct_S_MktSegt_Ext                = 7;


FIELD_IDX_T S_MktStruct_Id                           = 0;
FIELD_IDX_T S_MktStruct_RefGridId                    = 1;
FIELD_IDX_T S_MktStruct_RefGridName                  = 2;
FIELD_IDX_T S_MktStruct_RefGridCd                    = 3;
FIELD_IDX_T S_MktStruct_Rank                         = 4;
FIELD_IDX_T S_MktStruct_GridId                       = 5;
FIELD_IDX_T S_MktStruct_GridName                     = 6;
FIELD_IDX_T S_MktStruct_ParMktSegtId                 = 7;
FIELD_IDX_T S_MktStruct_ParMktSegtName               = 8;
FIELD_IDX_T S_MktStruct_ParRank                      = 9;
FIELD_IDX_T S_MktStruct_PmsGridName                  = 10;
FIELD_IDX_T S_MktStruct_PmsGridId                    = 11;


FIELD_IDX_T A_MktSSubSet_Id                          = 0;
FIELD_IDX_T A_MktSSubSet_RefGridId                   = 1;
FIELD_IDX_T A_MktSSubSet_MktStructId                 = 2;


FIELD_IDX_T S_MktSSubSet_Id                          = 0;
FIELD_IDX_T S_MktSSubSet_RefGridId                   = 1;
FIELD_IDX_T S_MktSSubSet_MktStructId                 = 2;
FIELD_IDX_T S_MktSSubSet_RefGridCd                   = 3;
FIELD_IDX_T S_MktSSubSet_RefGridName                 = 4;
FIELD_IDX_T S_MktSSubSet_MSRefGridId                 = 5;
FIELD_IDX_T S_MktSSubSet_MSRefGridName               = 6;
FIELD_IDX_T S_MktSSubSet_MSRank                      = 7;
FIELD_IDX_T S_MktSSubSet_MSGridId                    = 8;
FIELD_IDX_T S_MktSSubSet_MSGridName                  = 9;
FIELD_IDX_T S_MktSSubSet_MSParMSId                   = 10;
FIELD_IDX_T S_MktSSubSet_MSParMSName                 = 11;
FIELD_IDX_T S_MktSSubSet_MSParMSParRank              = 12;


FIELD_IDX_T A_ModelConstrElt_Id                      = 0;
FIELD_IDX_T A_ModelConstrElt_ModelConstrId           = 1;
FIELD_IDX_T A_ModelConstrElt_MktSgtId                = 2;
FIELD_IDX_T A_ModelConstrElt_DimInstrDictId          = 3;
FIELD_IDX_T A_ModelConstrElt_InstrObjId              = 4;
FIELD_IDX_T A_ModelConstrElt_ConstrBoundCurrId       = 5; /*REF10599-BRO-041019*/
FIELD_IDX_T A_ModelConstrElt_NatEn                   = 6;
FIELD_IDX_T A_ModelConstrElt_Denom                   = 7;
FIELD_IDX_T A_ModelConstrElt_MinWeight               = 8;
FIELD_IDX_T A_ModelConstrElt_MaxWeight               = 9;
FIELD_IDX_T A_ModelConstrElt_FixedCellFlg            = 10;
FIELD_IDX_T A_ModelConstrElt_ConstrBoundNatEn        = 11; /*REF10599-BRO-040914*/
FIELD_IDX_T A_ModelConstrElt_TradingOrderNatEn       = 12; /*REF10599-BRO-041019*/
FIELD_IDX_T A_ModelConstrElt_ApplFieldEn             = 13; /*REF10599-BRO-040914*/
FIELD_IDX_T A_ModelConstrElt_Priority                = 14; /*REF10599-BRO-040914*/
FIELD_IDX_T A_ModelConstrElt_ConstrTreatEn           = 15; /*REF10599-BRO-040914*/
FIELD_IDX_T A_ModelConstrElt_CriticalnessEn          = 16; /*REF11231-CHU-050608*/
FIELD_IDX_T A_ModelConstrElt_CreationModeEn          = 17; /*REF11810-EFE-060608*/
FIELD_IDX_T A_ModelConstrElt_IgnoreMarginFlg         = 18; /*PMSTA00970-BRO-070201*/
FIELD_IDX_T A_ModelConstrElt_EndDate                 = 19; /*PMSTA00965-EFE-070227*/
FIELD_IDX_T A_ModelConstrElt_ConstrNatEn             = 20; /*REF10599-BRO-041019*/
FIELD_IDX_T A_ModelConstrElt_CalcMinWeight           = 21; /*REF10633-RAK-041012*/
FIELD_IDX_T A_ModelConstrElt_CalcMaxWeight           = 22; /*REF10633-RAK-041012*/
FIELD_IDX_T A_ModelConstrElt_TreatedFlg              = 23;
FIELD_IDX_T A_ModelConstrElt_InstrObjCd              = 24;	/* REF11481 - TEB - 051010 */
FIELD_IDX_T A_ModelConstrElt_InstrObjNatEn           = 25;	/* PMSTA07902 - DDV - 090504 */
FIELD_IDX_T A_ModelConstrElt_InstrObjSubNatEn        = 26;	/* PMSTA07902 - DDV - 090504 */
FIELD_IDX_T A_ModelConstrElt_ConstrBoundCurrCd       = 27;	/* REF11481 - TEB - 051010 */
FIELD_IDX_T A_ModelConstrElt_CalcMinOptWeight        = 28;  /* REF11478 - CHU - 060227 */
FIELD_IDX_T A_ModelConstrElt_CalcMaxOptWeight        = 29;  /* REF11478 - CHU - 060227 */
FIELD_IDX_T A_ModelConstrElt_CalcMinChkWeight        = 30;  /* REF11478 - CHU - 060227 */
FIELD_IDX_T A_ModelConstrElt_CalcMaxChkWeight        = 31;  /* REF11478 - CHU - 060227 */
FIELD_IDX_T A_ModelConstrElt_InitCalcMinWeight       = 32;  /* REF11478 - CHU - 060406 */
FIELD_IDX_T A_ModelConstrElt_InitCalcMaxWeight       = 33;  /* REF11478 - CHU - 060406 */
FIELD_IDX_T A_ModelConstrElt_LittleBrol              = 34;  /* PMSTA00327 - CHU - 060926 */ /*Business Residue Of Leftover*/
FIELD_IDX_T A_ModelConstrElt_InstrTreatedFlg         = 35;	/* PMSTA10636-CHU-101007 */
FIELD_IDX_T A_ModelConstrElt_DimStratDictId			 = 36;	/* PMSTA-39045-BADHRI-140220*/
FIELD_IDX_T A_ModelConstrElt_StratObjId				 = 37;  /* PMSTA-39045-BADHRI-140220*/
FIELD_IDX_T A_ModelConstrElt_ApplicationScopeEn		 = 38;  /* PMSTA-41153-Vishnu-130720*/
FIELD_IDX_T A_ModelConstrElt_HierHeadPtfId 	         = 39;  /* PMSTA-41153-Vishnu-150720*/
FIELD_IDX_T A_ModelConstrElt_ptfId                   = 40;  /* PMSTA-41153-Vishnu-150720*/
FIELD_IDX_T A_ModelConstrElt_ModelConstrNatEn        = 41;  /* PMSTA-41153-Vishnu-150720*/
FIELD_IDX_T A_ModelConstrElt_ModelTypeId			 = 42;  /* PMSTA-42156-badhri-20102020*/
FIELD_IDX_T	A_ModelConstrElt_CreationUserId          = 43;	/* PMSTA-42750-vmu-01122020*/
FIELD_IDX_T	A_ModelConstrElt_CreationTimeDate        = 44;	/* PMSTA-42750-vmu-01122020*/
FIELD_IDX_T	A_ModelConstrElt_TypeId                  = 45;	/* PMSTA-42750-vmu-01122020*/
FIELD_IDX_T	A_ModelConstrElt_SubTypeId               = 46;	/* PMSTA-42750-vmu-01122020*/
FIELD_IDX_T A_ModelConstrElt_SkippedConstrFlg		 = 47;  /* PMSTA-42156-Badhri-25112020*/
FIELD_IDX_T A_ModelConstrElt_QuasiCashEn 			 = 48;  /* PMSTA-43175-Badhri-21122020*/
FIELD_IDX_T A_ModelConstrElt_OriginTypeId			 = 49;  /* PMSTA-51507 - KKM - 222012 */
FIELD_IDX_T A_ModelConstrElt_CaseMgtTypeId           = 50;  /* WEALTH-9979 - KKM - 12072024 */

FIELD_IDX_T S_ModelConstrElt_Id                      = 0;
FIELD_IDX_T S_ModelConstrElt_ModelConstrId           = 1;
FIELD_IDX_T S_ModelConstrElt_MktSgtId                = 2;
FIELD_IDX_T S_ModelConstrElt_DimInstrDictId          = 3;
FIELD_IDX_T S_ModelConstrElt_InstrObjId              = 4;
FIELD_IDX_T S_ModelConstrElt_ConstrBoundNatEn        = 5; /*REF10599-BRO-041019*/
FIELD_IDX_T S_ModelConstrElt_TradingOrderNatEn       = 6; /*REF10599-BRO-041019*/
FIELD_IDX_T S_ModelConstrElt_MinWeight               = 7; /*REF10599-BRO-041019*/
FIELD_IDX_T S_ModelConstrElt_MaxWeight               = 8; /*REF10599-BRO-041019*/
FIELD_IDX_T S_ModelConstrElt_ModelConstrNatEn        = 9;
FIELD_IDX_T S_ModelConstrElt_ModelConstrDimPtfId     = 10; /*REF10599-BRO-040917*/
FIELD_IDX_T S_ModelConstrElt_ModelConstrPtfId        = 11;
FIELD_IDX_T S_ModelConstrElt_ModelConstrBegD         = 12;
FIELD_IDX_T S_ModelConstrElt_ModelConstrPtfCd        = 13;
FIELD_IDX_T S_ModelConstrElt_Dimension               = 14;
FIELD_IDX_T S_ModelConstrElt_ObjectCd                = 15;
FIELD_IDX_T S_ModelConstrElt_ObjectName              = 16;
FIELD_IDX_T S_ModelConstrElt_ApplScope               = 19; /*WEALTH-7122-Ravindra-28042024*/


FIELD_IDX_T A_Notepad_EntDictId                      = 0;
FIELD_IDX_T A_Notepad_ObjId                          = 1;
FIELD_IDX_T A_Notepad_NoteDate                       = 2;
FIELD_IDX_T A_Notepad_UserId                         = 3;
FIELD_IDX_T A_Notepad_TpId                           = 4;
FIELD_IDX_T A_Notepad_Title                          = 5;
FIELD_IDX_T A_Notepad_Note                           = 6;


FIELD_IDX_T S_Notepad_EntDictId                      = 0;
FIELD_IDX_T S_Notepad_ObjId                          = 1;
FIELD_IDX_T S_Notepad_NoteDate                       = 2;
FIELD_IDX_T S_Notepad_UserId                         = 3;
FIELD_IDX_T S_Notepad_TpId                           = 4;
FIELD_IDX_T S_Notepad_TpCd                           = 5;
FIELD_IDX_T S_Notepad_UserCd                         = 6;


FIELD_IDX_T A_One_Id                                 = 0;
FIELD_IDX_T A_Boottime_Id                            = 0;    /* PMSTA-16365 - 140509 */


FIELD_IDX_T A_Op_Id                                  = 0;
FIELD_IDX_T A_Op_Cd                                  = 1;
FIELD_IDX_T A_Op_Fus                                 = 2;
FIELD_IDX_T A_Op_InputUserId                         = 3;
FIELD_IDX_T A_Op_TpId                                = 4;
FIELD_IDX_T A_Op_SubTpId                             = 5;
FIELD_IDX_T A_Op_MktThirdId                          = 6;
FIELD_IDX_T A_Op_InterThirdId                        = 7;
FIELD_IDX_T A_Op_PtfId                               = 8;
FIELD_IDX_T A_Op_PortPosSetId                        = 9;
FIELD_IDX_T A_Op_AdjPtfId                            = 10;
FIELD_IDX_T A_Op_CashPtfId                           = 11;
FIELD_IDX_T A_Op_InstrId                             = 12;
FIELD_IDX_T A_Op_ToInstrId                           = 13;
FIELD_IDX_T A_Op_AdjInstrId                          = 14;
FIELD_IDX_T A_Op_AccInstrId                          = 15;
FIELD_IDX_T A_Op_Acc2InstrId                         = 16;
FIELD_IDX_T A_Op_Acc3InstrId                         = 17;
FIELD_IDX_T A_Op_DepoId                              = 18;
FIELD_IDX_T A_Op_TradeCurrId                         = 19;
FIELD_IDX_T A_Op_MgrId                               = 20;
FIELD_IDX_T A_Op_RuleId                              = 21;
FIELD_IDX_T A_Op_ExtOrderId                          = 22;
FIELD_IDX_T A_Op_OrderModeTypeId                     = 23; /*REF11810-BRO-060608*/
FIELD_IDX_T A_Op_TraderMgrId						 = 24; /*REF11810-BRO-060608*/
FIELD_IDX_T A_Op_OrderCd                             = 25;
FIELD_IDX_T A_Op_ExecSetCriteria                     = 26;
FIELD_IDX_T A_Op_ParOpCd                             = 27;
FIELD_IDX_T A_Op_LastUserId                          = 28;
FIELD_IDX_T A_Op_LastModifDate                       = 29;
FIELD_IDX_T A_Op_NatEn                               = 30;
FIELD_IDX_T A_Op_OrderNatEn                          = 31;
FIELD_IDX_T A_Op_CreationTime                        = 32;
FIELD_IDX_T A_Op_AcctExchRate                        = 33;
FIELD_IDX_T A_Op_Acct2ExchRate                       = 34;
FIELD_IDX_T A_Op_Acct3ExchRate                       = 35;
FIELD_IDX_T A_Op_TradeExchRate                       = 36;
FIELD_IDX_T A_Op_CashPtfExchRate                     = 37;
FIELD_IDX_T A_Op_AdjPtfExchRate                      = 38;
FIELD_IDX_T A_Op_AcctDate                            = 39;
FIELD_IDX_T A_Op_OpDate                              = 40;
FIELD_IDX_T A_Op_ValuationDate                       = 41;
FIELD_IDX_T A_Op_OrderLimitDate                      = 42;
FIELD_IDX_T A_Op_ValDate                             = 43;
FIELD_IDX_T A_Op_OpRefCd                             = 44;
FIELD_IDX_T A_Op_RefNatEn                            = 45;
FIELD_IDX_T A_Op_StatEn                              = 46;
FIELD_IDX_T A_Op_LastNoteDate                        = 47;
FIELD_IDX_T A_Op_SequenceNo                          = 48;
FIELD_IDX_T A_Op_AcctCd                              = 49;
FIELD_IDX_T A_Op_SrcCd                               = 50;
FIELD_IDX_T A_Op_LimitQuote                          = 51;
FIELD_IDX_T A_Op_LimitPrice                          = 52;
FIELD_IDX_T A_Op_StopQuote                           = 53;
FIELD_IDX_T A_Op_StopPrice                           = 54;
FIELD_IDX_T A_Op_OrderPriceNatEn                     = 55;
FIELD_IDX_T A_Op_OrderValidNatEn                     = 56;
FIELD_IDX_T A_Op_MinOrderQty                         = 57;
FIELD_IDX_T A_Op_ValoSeqNo                           = 58;
FIELD_IDX_T A_Op_ParOpNatEn                          = 59;
FIELD_IDX_T A_Op_CheckParentEn                       = 60;
FIELD_IDX_T A_Op_CheckStratEn                        = 61;
FIELD_IDX_T A_Op_AutoRenewalEn					     = 62; /*<REF11810-BRO-060608*/
FIELD_IDX_T A_Op_RenewalTreatmtEn				     = 63;
FIELD_IDX_T A_Op_RenewalEndValDate				     = 64;
FIELD_IDX_T A_Op_RenewalLength					     = 65;
FIELD_IDX_T A_Op_RenewalLengthUnitEn				 = 66;
FIELD_IDX_T A_Op_ClientInitEn                        = 67;
FIELD_IDX_T A_Op_ContractNumber					     = 68;
FIELD_IDX_T A_Op_TransactionNatEn				     = 69; /*>REF11810-BRO-060608*/
FIELD_IDX_T A_Op_RenewalIntRate                      = 70; /*REF11810-BRO-060628*/
FIELD_IDX_T A_Op_RenewalAmount                       = 71; /*REF11810-BRO-060628*/
FIELD_IDX_T A_Op_DraftOrderId                        = 72;  /* REF8500 - 040510 - PMO */
FIELD_IDX_T A_Op_TargetNatureEn                      = 73; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_TargetNumber                        = 74; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_TargetAmount                        = 75; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_MarketSegmentId                     = 76; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_FactSheetEn                         = 77; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_LastQuoteDate                       = 78; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_LastQuoteNumber                     = 79; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_LastPriceNumber                     = 80; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_CommunicationDate                   = 81; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_CommunicationTypeId                 = 82; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_CommPartyTypeId                     = 83; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T A_Op_Remark1                             = 84; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_Remark2                             = 85; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_Remark3                             = 86; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_TransmissionDate                    = 87; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_TransmissionTypeId                  = 88; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_OrderTypeId                         = 89; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_MMInterestAmount                    = 90; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_FxMarketRate                        = 91; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_FxClientRate                        = 92; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T A_Op_FxRateDirection                     = 93; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T A_Op_InterestMarketRate                  = 94; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_DebitToSysCurrRate                  = 95; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_CreditToSysCurrRate                 = 96; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_ContractLengthNumber                = 97; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_ContractLengthUnitEn                = 98; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T A_Op_FxMarginNumber                      = 99; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T A_Op_FxMarginPrct                        = 100; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T A_Op_FxMarginAmount                      = 101; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T A_Op_Summary                             = 102; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T A_Op_TimeStamp                           = 103;/* REF11780 - 100406 - PMO */
FIELD_IDX_T A_Op_DerivativeOrdEn					 = 104; /* OCS-43683 - TGU - 131107 */
FIELD_IDX_T A_Op_FxFarLegAmount						 = 105; /* OCS43532-CHU-131112 */
FIELD_IDX_T A_Op_FxSpotQuote					     = 106; /* OCS43532-CHU-131112 */
FIELD_IDX_T A_Op_FxQuote						     = 107; /* OCS43532-CHU-131112 */
FIELD_IDX_T A_Op_FxSpotLegAmount				     = 108; /* OCS43532-CHU-131112 */
FIELD_IDX_T A_Op_OrderFeeEn							 = 109; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T A_Op_OrderFeePrct						 = 110; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T A_Op_MaxOrderQty						 = 111; /*OCS-43526-CHU-131213*/
FIELD_IDX_T A_Op_STPOrderEn							 = 112; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T A_Op_UnpaidPrct							 = 113; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T A_Op_EventStatusId                       = 114; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T A_Op_EventActionEn                       = 115; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T A_Op_CompoundOrderMasterEltId			 = 116;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T A_Op_CompoundOrderSlaveEltId			 = 117; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T A_Op_CompoundOrderCode					 = 118; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T A_Op_CompoundOrderSlaveNbr				 = 119; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T A_Op_CompoundImpactRule					 = 120; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T A_Op_DisplayCondition					 = 121;	/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T A_Op_OrderType							 = 122;	/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T A_Op_CommonRef                           = 123; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T A_Op_OrderInclusionEn                    = 125; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T A_Op_OrderRejectionDate                  = 126; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T A_Op_OrderRejectionComment               = 127; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T A_Op_AcquisitionDate                     = 128; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Op_CorporateActionNatEn                = 129; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Op_TaxLotSourceCd                      = 130; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Op_StandInstructId                     = 131; /* PMSTA-30043 - CHU - 180201 */
FIELD_IDX_T A_Op_BankFeePrct                         = 132; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T A_Op_BankFeeAmount                       = 133; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T A_Op_BankFeeCurrId                       = 134; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T A_Op_BidTypeEn                           = 135; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid1Qty                             = 136; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid1Quote                           = 137; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid2Qty                             = 138; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid2Quote                           = 139; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid3Qty                             = 140; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_Bid3Quote                           = 141; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T A_Op_CounterpartAccount                  = 142; /* PMSTA-32693 - SME - 20180827*/
FIELD_IDX_T A_Op_CounterpartCurrencyId               = 143; /* PMSTA-32693 - SME - 20180827*/
FIELD_IDX_T A_Op_OpFusionRuleEn                      = 144; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T A_Op_GlobalPosFlg                        = 145; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T	A_Op_OtcOrderEn							 = 146;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T	A_Op_DefaultFusRuleEn					 = 147;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T A_Op_CoolCancelEndDate                   = 148; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T A_Op_FusionPrioEn                        = 149; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T A_Op_ExternalBankBic                     = 150; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T A_Op_ExternalBankName                    = 151; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T A_Op_ExternalBankAcctOwnrName            = 152; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T A_Op_HedgeTradeEn                        = 153; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T A_Op_FixingDate                          = 154; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr1              = 155; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr2              = 156; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr3              = 157; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr4              = 158; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_PayRef1                             = 159; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_PayRef2                             = 160; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_PayRef3                             = 161; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_PayRef4                             = 162; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T A_Op_ExternalTradeFlg                    = 163; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	A_Op_OriginalQty						 = 164;	/* PMSTA-37908 - adarshn    - 19112019 */
FIELD_IDX_T	A_Op_OrderNettingEn						 = 165;	/* PMSTA-37908 - adarshn    - 19112019 */
FIELD_IDX_T A_Op_PaymentDate                         = 166; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Op_PaymentStatusEn                     = 167; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Op_SettlementDate                      = 168; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Op_SettleStatusEn                      = 169; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	A_Op_CommissionCdEn                      = 170;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_ChargeCdEn                          = 171;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_OriginalAmount                      = 172;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_CounterpartOrgAmount                = 173;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_ExternalFeeM                        = 174;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_TotalChargesM                       = 175;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_CounterpartAmount                   = 176;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_OpLinkageCd                         = 177;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	A_Op_ChargedCustomerName                 = 178;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T A_Op_BoPtfId                             = 179;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T A_Op_BoAccountId                         = 180;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_OpSplitRuleEn                       = 181;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_AdjBoPtfId                          = 182;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_CoaExDate                           = 183;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_BoCashAcctId                        = 184;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_BoCashPtfId                         = 185;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_SplitParentOperId                   = 186;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_Op_OriginalNetAmount = 187;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	A_Op_SplitParOpCd = 188;	/* PMSTA-40714*/
FIELD_IDX_T A_Op_RuleApplicabilityEn				 = 189; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_Op_SmartRoundingQty					 = 190; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_Op_SmartRoundingOrgQty				 = 191; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_Op_RoundingOrgQty						 = 192; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_Op_SmartRoundingFlg					 = 193; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_Op_SmartRoundingRuleId				 = 194; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	A_Op_HierOperNatEn                       = 195;	/* PMSTA-40208 - adarshn - 28082020*/
FIELD_IDX_T	A_Op_HierOperationCd                     = 196;	/* PMSTA-40208 - adarshn - 28082020*/
FIELD_IDX_T	A_Op_CashPlanId                          = 197;	/*PMSTA-42402 Autocash Vishnu 16112020*/
FIELD_IDX_T	A_Op_NotionalInstrId                     = 198;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	A_Op_InvestLimitEn                       = 199;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T A_Op_SetOfFeesId						 = 200; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_Op_SetOfProductFeesId					 = 201; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_Op_BoRoutingBusEntityId				 = 202; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T A_Op_OrderSubTypeId                      = 203; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	A_Op_SetOfOtherFeesId                    = 204; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	A_Op_TraderThirdId                       = 205; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	A_Op_NetSettleAmount                     = 206; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T S_Op_Id                                  = 0;
FIELD_IDX_T S_Op_Cd                                  = 1;
FIELD_IDX_T S_Op_SequenceNo                          = 2;
FIELD_IDX_T S_Op_StatEn                              = 3;
FIELD_IDX_T S_Op_NatEn                               = 4;
FIELD_IDX_T S_Op_AudModifDate                        = 5;
FIELD_IDX_T S_Op_DbStatusEn                          = 6;
FIELD_IDX_T S_Op_CheckParentEn                       = 7;
FIELD_IDX_T S_Op_NoCheckImpactFlg                    = 8;
FIELD_IDX_T S_Op_FusionPrioEn                        = 9;


FIELD_IDX_T A_OpCompo_OpTpId                         = 0;
FIELD_IDX_T A_OpCompo_BalPosTpId                     = 1;
FIELD_IDX_T A_OpCompo_OpNatEn                        = 2;
FIELD_IDX_T A_OpCompo_Rank                           = 3;


FIELD_IDX_T S_OpCompo_OpTpId                         = 0;
FIELD_IDX_T S_OpCompo_BalPosTpId                     = 1;
FIELD_IDX_T S_OpCompo_OpNatEn                        = 2;


FIELD_IDX_T A_PayInstruct_PtfId                      = 0;
FIELD_IDX_T A_PayInstruct_AccInstrId                 = 1;
FIELD_IDX_T A_PayInstruct_CurrId                     = 2;
FIELD_IDX_T A_PayInstruct_OpTpId                     = 3;
FIELD_IDX_T A_PayInstruct_OpSubTpId                  = 4;
FIELD_IDX_T A_PayInstruct_OpNatEn                    = 5;


FIELD_IDX_T S_PayInstruct_PtfId                      = 0;
FIELD_IDX_T S_PayInstruct_AccInstrId                 = 1;
FIELD_IDX_T S_PayInstruct_CurrId                     = 2;
FIELD_IDX_T S_PayInstruct_OpTpId                     = 3;
FIELD_IDX_T S_PayInstruct_OpSubTpId                  = 4;
FIELD_IDX_T S_PayInstruct_OpNatEn                    = 5;
FIELD_IDX_T S_PayInstruct_OpTpCd                     = 6;
FIELD_IDX_T S_PayInstruct_OpSubTpCd                  = 7;
FIELD_IDX_T S_PayInstruct_CurrCd                     = 8;
FIELD_IDX_T S_PayInstruct_AccInstrCd                 = 9;

/* REF9264 - LJE - 030630 */
FIELD_IDX_T A_PAABreakCriteria_BreakCriteriaId      ; /* PSMTA02254 - DDV - 070711 */
FIELD_IDX_T A_PAABreakCriteria_BreakCriteriaVal     ;
FIELD_IDX_T A_PAABreakCriteria_EntDictId            ;
FIELD_IDX_T A_PAABreakCriteria_ObjectId             ;
FIELD_IDX_T A_PAABreakCriteria_SubObjectId          ; /* PMSTA-47578 - LJE - 220314 */
FIELD_IDX_T A_PAABreakCriteria_GridId               ;
FIELD_IDX_T A_PAABreakCriteria_ObjectLnkId          ;
FIELD_IDX_T A_PAABreakCriteria_DynSt                ;
FIELD_IDX_T A_PAABreakCriteria_MultiGridFlg         ; /* REF9770 - LJE - 031208 */
FIELD_IDX_T A_PAABreakCriteria_MainObjFlg           ; /* REF9770 - LJE - 031217 */
FIELD_IDX_T A_PAABreakCriteria_BeginDate            ; /* REF9770 - LJE - 031208 */
FIELD_IDX_T A_PAABreakCriteria_EndDate              ; /* REF9770 - LJE - 031208 */
FIELD_IDX_T A_PAABreakCriteria_SubSetBreakCriteria  ; /* REF10276 - LJE - 041110 : For optim */


FIELD_IDX_T A_PerfAttribId_Id                        = 0; /* REF9924 - LJE - 040213 */

FIELD_IDX_T S_PerfAttribId_Id                        = 0;
FIELD_IDX_T S_PerfAttribId_BlockSize                 = 1;
FIELD_IDX_T S_PerfAttribId_IdentityResSize           = 2;

FIELD_IDX_T A_PerfAttrib_Id                          = 0;
FIELD_IDX_T A_PerfAttrib_PerfStorParamId             = 1;
FIELD_IDX_T A_PerfAttrib_EntDictId                   = 2;
FIELD_IDX_T A_PerfAttrib_ObjId                       = 3;
FIELD_IDX_T A_PerfAttrib_FreqEn                      = 4;
FIELD_IDX_T A_PerfAttrib_CurrId                      = 5;
FIELD_IDX_T A_PerfAttrib_PosDataId                   = 6;
FIELD_IDX_T A_PerfAttrib_GridId                      = 7;
FIELD_IDX_T A_PerfAttrib_PerfAttribRtnEn             = 8;
FIELD_IDX_T A_PerfAttrib_InitialDate                 = 9;
FIELD_IDX_T A_PerfAttrib_FinalDate                   = 10;
FIELD_IDX_T A_PerfAttrib_MktSegtId                   = 11;
FIELD_IDX_T A_PerfAttrib_InstrId                     = 12;
FIELD_IDX_T A_PerfAttrib_SubPeriodMask               = 13;
FIELD_IDX_T A_PerfAttrib_InitialMktVal               = 14;
FIELD_IDX_T A_PerfAttrib_FlowMeanCap                 = 15;
FIELD_IDX_T A_PerfAttrib_WgtFactor                   = 16;
FIELD_IDX_T A_PerfAttrib_Wgt                         = 17;
FIELD_IDX_T A_PerfAttrib_Rtn                         = 18;
FIELD_IDX_T A_PerfAttrib_RtnCurr                     = 19;
FIELD_IDX_T A_PerfAttrib_Dura                        = 19;
FIELD_IDX_T A_PerfAttrib_BenchEntDictId              = 20; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_PerfAttrib_BenchObjId                  = 21; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_PerfAttrib_FinalMktVal                 = 22; /*REF9743-BRO-040205*/
FIELD_IDX_T A_PerfAttrib_Adjust                      = 23; /*REF9743-BRO-040205*/
FIELD_IDX_T A_PerfAttrib_PortSynthId                 = 24;
FIELD_IDX_T A_PerfAttrib_ExtStratEltId               = 25;
FIELD_IDX_T A_PerfAttrib_StratSynthId                = 26; /* PMSTA08736 - LJE - 100120 */
FIELD_IDX_T A_PerfAttrib_GlobalPerfAttribId          = 27;
FIELD_IDX_T A_PerfAttrib_Bench1PerfAttribId          = 28;
FIELD_IDX_T A_PerfAttrib_Bench2PerfAttribId          = 29;
FIELD_IDX_T A_PerfAttrib_Bench3PerfAttribId          = 30;
FIELD_IDX_T A_PerfAttrib_RiskFreeStdPerfId           = 31;
FIELD_IDX_T A_PerfAttrib_PaMktSelection              = 32;
FIELD_IDX_T A_PerfAttrib_PaStockPicking              = 33;
FIELD_IDX_T A_PerfAttrib_PaInteraction               = 34;
FIELD_IDX_T A_PerfAttrib_PaCurrSelection             = 35;
FIELD_IDX_T A_PerfAttrib_ParentId                    = 36;
FIELD_IDX_T A_PerfAttrib_ReturnContribution          = 37;
FIELD_IDX_T A_PerfAttrib_DuraContrib                 = 38;
FIELD_IDX_T A_PerfAttrib_BenchmarkFactor             = 39;
FIELD_IDX_T A_PerfAttrib_AbcissaRank                 = 40;
FIELD_IDX_T A_PerfAttrib_OrdinateRank                = 41;
FIELD_IDX_T A_PerfAttrib_ReturnCurrContrib           = 42; /* REF9227 - LJE - 030918 */
FIELD_IDX_T A_PerfAttrib_ReturnCapContrib            = 43; /* REF9227 - LJE - 030918 */
FIELD_IDX_T A_PerfAttrib_CompletePeriodFlg           = 44; /* REF9770 - LJE - 031212 */
FIELD_IDX_T A_PerfAttrib_RecInfoMask                 = 45;
FIELD_IDX_T A_PerfAttrib_PreviousId                  = 46; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_NextId                      = 47; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_OverPeriodId                = 48; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_ParentObjId                 = 0; /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_PerfAttrib_FirstPerfInterBenchId       = 49; /* PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_PerfAttrib_LastPerfInterBenchId        = 50; /* PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_PerfAttrib_ObjLnkBreakCriteria         = 51; /* REF9264 - LJE - 030630 */
FIELD_IDX_T A_PerfAttrib_MergeParentObjId            = 52;
FIELD_IDX_T A_PerfAttrib_BreakCriteria               = 53; /* REF9264 - LJE - 030625 */
FIELD_IDX_T A_PerfAttrib_ParentBreakCriteria         = 54; /* REF9344 - LJE - 031014 */
FIELD_IDX_T A_PerfAttrib_GlobalPerfAttrib_Ext        = 56;
FIELD_IDX_T A_PerfAttrib_Bench1PerfAttrib_Ext        = 57;
FIELD_IDX_T A_PerfAttrib_Bench2PerfAttrib_Ext        = 58;
FIELD_IDX_T A_PerfAttrib_Bench3PerfAttrib_Ext        = 59;
FIELD_IDX_T A_PerfAttrib_RiskFreeStdPerf_Ext         = 60;
FIELD_IDX_T A_PerfAttrib_Parent_Ext                  = 61;
FIELD_IDX_T A_PerfAttrib_Previous_Ext                = 62; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_Next_Ext                    = 63; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_OverPeriod_Ext              = 64; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_PerfAttrib_ParentObj_Ext               = 0;  /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_PerfAttrib_SubSetBreakCriteria         = 65; /* REF10276 - LJE - 041110 : For optim */
FIELD_IDX_T A_PerfAttrib_BenchInitialDate            = 66; /* REF11462 - LJE - 051206 */
FIELD_IDX_T A_PerfAttrib_BenchFinalDate              = 67; /* REF11462 - LJE - 051206 */
FIELD_IDX_T A_PerfAttrib_FirstPerfInterBench_Ext     = 68; /* PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_PerfAttrib_LastPerfInterBench_Ext      = 69; /* PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_PerfAttrib_Children_Ext                = 70; /* PMSTA08736 - LJE - 100203 */
FIELD_IDX_T A_PerfAttrib_HeadPtf_Ext                 = 71; /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
FIELD_IDX_T A_PerfAttrib_RecStatusEn                 = 72; /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */

FIELD_IDX_T S_PerfAttrib_Id                          = 0;
FIELD_IDX_T S_PerfAttrib_PerfStorParamId             = 1;
FIELD_IDX_T S_PerfAttrib_EntDictId                   = 2;
FIELD_IDX_T S_PerfAttrib_ObjId                       = 3;
FIELD_IDX_T S_PerfAttrib_FreqEn                      = 4;
FIELD_IDX_T S_PerfAttrib_CurrId                      = 5;
FIELD_IDX_T S_PerfAttrib_PosDataId                   = 6;
FIELD_IDX_T S_PerfAttrib_GridId                      = 7;
FIELD_IDX_T S_PerfAttrib_PerfAttribRtnEn             = 8;
FIELD_IDX_T S_PerfAttrib_InitialDate                 = 9;
FIELD_IDX_T S_PerfAttrib_FinalDate                   = 10;
FIELD_IDX_T S_PerfAttrib_MktSegtId                   = 11;
FIELD_IDX_T S_PerfAttrib_InstrId                     = 12;


FIELD_IDX_T A_PerfAttribData_Id                      = 0;
FIELD_IDX_T A_PerfAttribData_PspId                   = 1;
FIELD_IDX_T A_PerfAttribData_InitialDate             = 2;
FIELD_IDX_T A_PerfAttribData_FinalDate               = 3;
FIELD_IDX_T A_PerfAttribData_MktSegtId               = 4;
FIELD_IDX_T A_PerfAttribData_InstrId                 = 5;
FIELD_IDX_T A_PerfAttribData_SubPeriodMask           = 6;
FIELD_IDX_T A_PerfAttribData_InitialMktVal           = 7;
FIELD_IDX_T A_PerfAttribData_FlowMeanCap             = 8;
FIELD_IDX_T A_PerfAttribData_WgtFactor               = 9;
FIELD_IDX_T A_PerfAttribData_Wgt                     = 10;
FIELD_IDX_T A_PerfAttribData_Rtn                     = 11;
FIELD_IDX_T A_PerfAttribData_RtnCurr                 = 12;
FIELD_IDX_T A_PerfAttribData_Dura                    = 13; /* PMSTA08736 - LJE - 100118 */
FIELD_IDX_T A_PerfAttribData_BenchEntDictId          = 14; /* REF9125 - LJE - 030818 */
FIELD_IDX_T A_PerfAttribData_BenchObjId              = 15; /* REF9125 - LJE - 030818 */
FIELD_IDX_T A_PerfAttribData_FinalMktVal             = 16; /*REF9743-BRO-040205*/
FIELD_IDX_T A_PerfAttribData_Adjust                  = 17; /*REF9743-BRO-040205*/

/* REF9125 - LJE - 030811 */
FIELD_IDX_T A_PSPPositionData_Id                     = 0;
FIELD_IDX_T A_PSPPositionData_Code                   = 1;
FIELD_IDX_T A_PSPPositionData_Name                   = 2; /*PMSTA15347-BRO-130121*/
FIELD_IDX_T A_PSPPositionData_Denom                  = 3; /*PMSTA15347-BRO-130121*/
FIELD_IDX_T A_PSPPositionData_PPSLoadEn              = 4;
FIELD_IDX_T A_PSPPositionData_PortPosTypeId          = 5;
FIELD_IDX_T A_PSPPositionData_ConsPtfId              = 6;
FIELD_IDX_T A_PSPPositionData_StratLnkNatEn          = 7;
FIELD_IDX_T A_PSPPositionData_MinLnkPriority         = 8;
FIELD_IDX_T A_PSPPositionData_MaxLnkPriority         = 9;
FIELD_IDX_T A_PSPPositionData_FundSplitRuleEn        = 10;
FIELD_IDX_T A_PSPPositionData_RiskExpoFlg            = 11;
FIELD_IDX_T A_PSPPositionData_OptRiskRuleEn          = 12;
FIELD_IDX_T A_PSPPositionData_DebtFlg                = 13;
FIELD_IDX_T A_PSPPositionData_FusRuleEn              = 14;
FIELD_IDX_T A_PSPPositionData_PosLogicalEn           = 15;
FIELD_IDX_T A_PSPPositionData_FusDateRuleEn          = 16;
FIELD_IDX_T A_PSPPositionData_QuoteValRuleId         = 17;
FIELD_IDX_T A_PSPPositionData_ExchValRuleId          = 18;
FIELD_IDX_T A_PSPPositionData_PosValRuleEn           = 19;
FIELD_IDX_T A_PSPPositionData_ExtPosListId           = 20;
FIELD_IDX_T A_PSPPositionData_MinStatEn              = 21;
FIELD_IDX_T A_PSPPositionData_MaxStatEn              = 22;

/* REF9125 - LJE - 030811 */
FIELD_IDX_T S_PSPPositionData_Id                     = 0;
FIELD_IDX_T S_PSPPositionData_Code                   = 1;
FIELD_IDX_T S_PSPPositionData_Name                   = 2; /*PMSTA15347-BRO-130121*/
FIELD_IDX_T S_PSPPositionData_Denom                  = 3; /*PMSTA15347-BRO-130121*/

/*< PMSTA08736 - LJE - 100115 */
FIELD_IDX_T A_PerfEffectDef_Id                       = 0;
FIELD_IDX_T A_PerfEffectDef_Cd                       = 1;
FIELD_IDX_T A_PerfEffectDef_Name                     = 2;
FIELD_IDX_T A_PerfEffectDef_Denom                    = 3;
FIELD_IDX_T A_PerfEffectDef_PerfEffectNatEn          = 4;
FIELD_IDX_T A_PerfEffectDef_Rank                     = 5;
FIELD_IDX_T A_PerfEffectDef_A_PerfEffectLink_Ext     = 6;
FIELD_IDX_T A_PerfEffectDef_BreakCriteria            = 7; /* PMSTA-15017 - LJE - 120925 */

FIELD_IDX_T S_PerfEffectDef_Id                       = 0;
FIELD_IDX_T S_PerfEffectDef_Cd                       = 1;
FIELD_IDX_T S_PerfEffectDef_Name                     = 2;
FIELD_IDX_T S_PerfEffectDef_PerfEffectNatEn          = 4;

FIELD_IDX_T A_PerfEffectLink_MktSegtId               = 0;
FIELD_IDX_T A_PerfEffectLink_PerfEffectDefId         = 1;
FIELD_IDX_T A_PerfEffectLink_Rank                    = 2;
FIELD_IDX_T A_PerfEffectLink_InitPerfEffectDefId     = 3; /* PMSTA-14877 - LJE - 120913 */
FIELD_IDX_T A_PerfEffectLink_A_MktSgt_Ext            = 3;
FIELD_IDX_T A_PerfEffectLink_A_PerfEffectDef_Ext     = 4;
FIELD_IDX_T A_PerfEffectLink_Grouping                = 6; /* PMSTA-14965 - LJE - 120919 */
FIELD_IDX_T A_PerfEffectLink_BreakCriteria           = 7; /* PMSTA-15017 - LJE - 120925 */
FIELD_IDX_T A_PerfEffectLink_GridId                  = 8; /* PMSTA-15017 - LJE - 120925 */

FIELD_IDX_T S_PerfEffectLink_MktSegtId               = 0;
FIELD_IDX_T S_PerfEffectLink_PerfEffectDefId         = 1;
FIELD_IDX_T S_PerfEffectLink_PerfEffectDefCd         = 2;
FIELD_IDX_T S_PerfEffectLink_Rank                    = 3;
FIELD_IDX_T S_PerfEffectLink_PerfEffectNatEn         = 4;

FIELD_IDX_T A_PerfCurrencyContrib_Id                 = 0;
FIELD_IDX_T A_PerfCurrencyContrib_RefCurrId          = 1;
FIELD_IDX_T A_PerfCurrencyContrib_CurrId             = 2;
FIELD_IDX_T A_PerfCurrencyContrib_InitialDate        = 3;
FIELD_IDX_T A_PerfCurrencyContrib_FinalDate          = 4;
FIELD_IDX_T A_PerfCurrencyContrib_Return             = 5;
FIELD_IDX_T A_PerfCurrencyContrib_ShTermIntRate      = 6;
FIELD_IDX_T A_PerfCurrencyContrib_RiskFreeEarning    = 7;
FIELD_IDX_T A_PerfCurrencyContrib_InitialRate        = 8;
FIELD_IDX_T A_PerfCurrencyContrib_FinalRate          = 9;

FIELD_IDX_T A_PerfInterBench_Id                      = 0;
FIELD_IDX_T A_PerfInterBench_PerfEffectDefId         = 1;
FIELD_IDX_T A_PerfInterBench_Effect                  = 2;
FIELD_IDX_T A_PerfInterBench_Weight                  = 3;
FIELD_IDX_T A_PerfInterBench_Return                  = 4;
FIELD_IDX_T A_PerfInterBench_ReturnContrib           = 5;
FIELD_IDX_T A_PerfInterBench_Dura                    = 6;
FIELD_IDX_T A_PerfInterBench_DuraContrib             = 7;
FIELD_IDX_T A_PerfInterBench_NextPerfInterBenchId    = 8;
FIELD_IDX_T A_PerfInterBench_LinkedPerfAttribId      = 9;
FIELD_IDX_T A_PerfInterBench_InitPerfEffectDefId     =10; /* PMSTA-14877 - LJE - 120912 */
FIELD_IDX_T A_PerfInterBench_EffectMarketSegmentId   =11; /* PMSTA-15017 - LJE - 120925 */
FIELD_IDX_T A_PerfInterBench_NextPerfInterBench_Ext  =12;
FIELD_IDX_T A_PerfInterBench_LinkedPerfAttrib_Ext    =13;
FIELD_IDX_T A_PerfInterBench_IdxFld                  =14;
/*> PMSTA08736 - LJE - 100115 */
/*<PMSTA-21268 - SHR - 092115*/

FIELD_IDX_T A_PlanRule_Id							= 0;
FIELD_IDX_T A_PlanRule_Cd							= 1;
FIELD_IDX_T A_PlanRule_Name							= 2;
FIELD_IDX_T A_PlanRule_Denom						= 3;
FIELD_IDX_T A_PlanRule_PlanNatureEn					= 4;
FIELD_IDX_T A_PlanRule_GeoId						= 5;
FIELD_IDX_T A_PlanRule_CreationDate					= 6;
FIELD_IDX_T A_PlanRule_CreationUserId				= 7;
FIELD_IDX_T A_PlanRule_LastModifDate				= 8;
FIELD_IDX_T A_PlanRule_LastUserId					= 9;
FIELD_IDX_T A_PlanRule_CurrentPlanRuleHisto	        = 14;
FIELD_IDX_T A_PlanRule_LastPlanRuleHisto	        = 15;
FIELD_IDX_T A_PlanRule_Denomination					= 16;
FIELD_IDX_T A_PlanRule_PlanRuleHisto				= 17;

FIELD_IDX_T S_PlanRule_Id							= 0;
FIELD_IDX_T S_PlanRule_Cd							= 1;
FIELD_IDX_T S_PlanRule_Name							= 2;


FIELD_IDX_T A_PlanRuleHisto_Id						= 0;
FIELD_IDX_T A_PlanRuleHisto_PlanRuleId				= 1;
FIELD_IDX_T A_PlanRuleHisto_BeginDate				= 2;
FIELD_IDX_T A_PlanRuleHisto_PeriodFreqUnit			= 3;
FIELD_IDX_T A_PlanRuleHisto_PeriodFreq				= 4;
FIELD_IDX_T A_PlanRuleHisto_LastInvestDate			= 5;
FIELD_IDX_T A_PlanRuleHisto_MinAmount				= 6;
FIELD_IDX_T A_PlanRuleHisto_MaxAmount				= 7;
FIELD_IDX_T A_PlanRuleHisto_CurrId					= 8;
FIELD_IDX_T A_PlanRuleHisto_AmountNature			= 9;
FIELD_IDX_T A_PlanRuleHisto_TaxRate					= 10;
FIELD_IDX_T A_PlanRuleHisto_CreationDate			= 11;
FIELD_IDX_T A_PlanRuleHisto_CreationUserId			= 12;
FIELD_IDX_T A_PlanRuleHisto_LastModifDate			= 13;
FIELD_IDX_T A_PlanRuleHisto_LastUserId				= 14;

FIELD_IDX_T S_PlanRuleHisto_Id						= 0;
FIELD_IDX_T S_PlanRuleHisto_PlanRuleId				= 1;
FIELD_IDX_T S_PlanRuleHisto_PlanRuleCd				= 2;
FIELD_IDX_T S_PlanRuleHisto_BeginDate				= 3;

FIELD_IDX_T A_PlanDefinition_Id						  = 0;
FIELD_IDX_T A_PlanDefinition_Cd						  = 1;
FIELD_IDX_T A_PlanDefinition_Name					  = 2;
FIELD_IDX_T A_PlanDefinition_Denom					  = 3;
FIELD_IDX_T A_PlanDefinition_Nature					  = 4;
FIELD_IDX_T A_PlanDefinition_TypeId					  = 5;
FIELD_IDX_T A_PlanDefinition_Status					  = 6;
FIELD_IDX_T A_PlanDefinition_ThirdPartyId			  = 7;
FIELD_IDX_T A_PlanDefinition_PortfolioId			  = 8;
FIELD_IDX_T A_PlanDefinition_ObjectiveNature		  = 9;
FIELD_IDX_T A_PlanDefinition_PlanRuleId				  = 10;
FIELD_IDX_T A_PlanDefinition_CreationDate			  = 11;
FIELD_IDX_T A_PlanDefinition_CreationUserId			  = 12;
FIELD_IDX_T A_PlanDefinition_LastModifDate			  = 13;
FIELD_IDX_T A_PlanDefinition_LastUserId				  = 14;
FIELD_IDX_T A_PlanDefinition_ValidationDate			  = 15;
FIELD_IDX_T A_PlanDefinition_ValidationUserId         = 16;
FIELD_IDX_T A_PlanDefinition_DepositExecRuleEn        = 17; /* PMSTA-33148 - RAK - 181003 */
FIELD_IDX_T A_PlanDefinition_CurrentObjective	      = 23;
FIELD_IDX_T A_PlanDefinition_LastObjective            = 24;
FIELD_IDX_T A_PlanDefinition_CurrentInvestParam	      = 25;
FIELD_IDX_T A_PlanDefinition_LastInvestParam          = 26;
FIELD_IDX_T A_PlanDefinition_PlanObjectiveHisto_Ext   = 27;
FIELD_IDX_T A_PlanDefinition_PlanInvestParamHisto_Ext = 28;
FIELD_IDX_T A_PlanDefinition_StandInstruct_Ext        = 29;
FIELD_IDX_T A_PlanDefinition_CashAllocModeEn          = 30;	/* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_PlanDefinition_CashRealignMethodEn      = 31;	/* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_PlanDefinition_InvestPlanTypeId         = 32;
FIELD_IDX_T S_PlanDefinition_Id						= 0;
FIELD_IDX_T S_PlanDefinition_Cd						= 1;
FIELD_IDX_T S_PlanDefinition_Name					= 2;


FIELD_IDX_T A_PlanObjectiveHisto_Id					= 0;
FIELD_IDX_T A_PlanObjectiveHisto_PlanDefinitionId	= 1;
FIELD_IDX_T A_PlanObjectiveHisto_BeginDate			= 3;
FIELD_IDX_T A_PlanObjectiveHisto_ObjectiveDate		= 4;
FIELD_IDX_T A_PlanObjectiveHisto_PeriodFreqUnit		= 5;
FIELD_IDX_T A_PlanObjectiveHisto_PeriodFreq			= 6;
FIELD_IDX_T A_PlanObjectiveHisto_MinAmount			= 7;
FIELD_IDX_T A_PlanObjectiveHisto_MaxAmount			= 8;
FIELD_IDX_T A_PlanObjectiveHisto_CurrId				= 9;
FIELD_IDX_T A_PlanObjectiveHisto_AmountNature		= 10;
FIELD_IDX_T A_PlanObjectiveHisto_MinAmtIndexRule	= 11;
FIELD_IDX_T A_PlanObjectiveHisto_MinAmtIndexValue	= 12;
FIELD_IDX_T A_PlanObjectiveHisto_MaxAmtIndexRule	= 13;
FIELD_IDX_T A_PlanObjectiveHisto_MaxAmtIndexValue	= 14;
FIELD_IDX_T A_PlanObjectiveHisto_ExtpectedAmt = 15;	/* PMSTA-33148 - RAK - 181003 */
FIELD_IDX_T A_PlanObjectiveHisto_CreationDate		= 16;
FIELD_IDX_T A_PlanObjectiveHisto_CreationUserId		= 17;
FIELD_IDX_T A_PlanObjectiveHisto_LastModifDate		= 18;
FIELD_IDX_T A_PlanObjectiveHisto_LastUserId			= 19;
FIELD_IDX_T	A_PlanObjectiveHisto_InvestP            = 20;

FIELD_IDX_T S_PlanObjectiveHisto_Id					= 0;
FIELD_IDX_T S_PlanObjectiveHisto_PlanDefinitionId	= 1;
FIELD_IDX_T S_PlanObjectiveHisto_PlanDefinitionCd	= 2;
FIELD_IDX_T S_PlanObjectiveHisto_BeginDate			= 3;

FIELD_IDX_T A_PlanInvestParamHisto_Id							= 0;
FIELD_IDX_T A_PlanInvestParamHisto_PlanDefinitionId				= 1;
FIELD_IDX_T A_PlanInvestParamHisto_BeginDate					= 3;
FIELD_IDX_T A_PlanInvestParamHisto_FirstInvestDate				= 4;
FIELD_IDX_T A_PlanInvestParamHisto_EndOfMonthConv				= 5;
FIELD_IDX_T A_PlanInvestParamHisto_InvestFreqUnit				= 6;
FIELD_IDX_T A_PlanInvestParamHisto_InvestFreq					= 7;
FIELD_IDX_T A_PlanInvestParamHisto_UpdAmtToObjective			= 8;
FIELD_IDX_T A_PlanInvestParamHisto_UpdAmtToCash					= 9;
FIELD_IDX_T A_PlanInvestParamHisto_MaxInvestAmt					= 10;
FIELD_IDX_T A_PlanInvestParamHisto_TransferFromAcctId			= 11;
FIELD_IDX_T A_PlanInvestParamHisto_TransferFromPortfolioId		= 12;
FIELD_IDX_T A_PlanInvestParamHisto_InvestAcctId					= 13;
FIELD_IDX_T A_PlanInvestParamHisto_GenCashOp					= 14;
FIELD_IDX_T A_PlanInvestParamHisto_CreationDate					= 15;
FIELD_IDX_T A_PlanInvestParamHisto_CreationUserId				= 16;
FIELD_IDX_T A_PlanInvestParamHisto_LastModifDate				= 17;
FIELD_IDX_T A_PlanInvestParamHisto_LastUserId					= 18;
FIELD_IDX_T A_PlanInvestParamHisto_InvestmentDay				= 19;
FIELD_IDX_T A_PlanInvestParamHisto_NextInvestDay				= 20;
FIELD_IDX_T A_PlanInvestParamHisto_PlanInvestDate_Ext			= 21;
FIELD_IDX_T A_PlanInvestParamHisto_RetryFreq                    = 22; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestParamHisto_RetryFreqUnit                = 23; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestParamHisto_MaxRetry                     = 24; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestParamHisto_LastInvestDate               = 25; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestParamHisto_OrderCycles                  = 26; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestParamHisto_StandingOrderExtRef			= 27; /* PMSTA-33148-RAK-181005 */
FIELD_IDX_T A_PlanInvestParamHisto_CounterpartAcctC				= 28; /* PMSTA-33148-RAK-181005 */
FIELD_IDX_T A_PlanInvestParamHisto_EndDateConfigEnum   			= 29; /* PMSTA-46432-Autocash-08102021 */

FIELD_IDX_T S_PlanInvestParamHisto_Id							= 0;
FIELD_IDX_T S_PlanInvestParamHisto_PlanDefinitionId				= 1;
FIELD_IDX_T S_PlanInvestParamHisto_PlanDefinitionCd				= 2;
FIELD_IDX_T S_PlanInvestParamHisto_BeginDate					= 3;

FIELD_IDX_T A_PlanInvestDate_Id								= 0;
FIELD_IDX_T A_PlanInvestDate_PlanInvestParamHistoId			= 1;
FIELD_IDX_T A_PlanInvestDate_InvestmentDate					= 2;
FIELD_IDX_T A_PlanInvestDate_Status							= 3;
FIELD_IDX_T A_PlanInvestDate_CreationDate					= 4;
FIELD_IDX_T A_PlanInvestDate_RetryNumber					= 5; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestDate_EventNumber					= 6; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestDate_EventCd						= 7; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_PlanInvestDate_ValidFlag					    = 8;
FIELD_IDX_T A_PlanInvestDate_DbActionEn                     = 9;
FIELD_IDX_T A_PlanInvestDate_FreeDepositHistoId             = 10;

FIELD_IDX_T S_PlanInvestDate_Id								= 0;
FIELD_IDX_T S_PlanInvestDate_PlanInvestParamHistoId			= 1;
FIELD_IDX_T S_PlanInvestDate_InvestmentDate					= 2;
FIELD_IDX_T S_PlanInvestDate_Status                         = 3;
FIELD_IDX_T S_PlanInvestDate_RetryNumber                    = 4;

FIELD_IDX_T A_FreeDepositHisto_Id							=  0;
FIELD_IDX_T A_FreeDepositHisto_Cd							=  1;
FIELD_IDX_T A_FreeDepositHisto_PlanDefinitionId				=  2;
FIELD_IDX_T A_FreeDepositHisto_InvestmentDate			    =  3;
FIELD_IDX_T A_FreeDepositHisto_NatureEn					    =  4;
FIELD_IDX_T A_FreeDepositHisto_Status					    =  5;
FIELD_IDX_T A_FreeDepositHisto_TransferFromAcctId		    =  6;
FIELD_IDX_T A_FreeDepositHisto_TransferFromPortfolioId		=  7;
FIELD_IDX_T A_FreeDepositHisto_Amount						=  8;
FIELD_IDX_T A_FreeDepositHisto_CurrId						=  9;
FIELD_IDX_T A_FreeDepositHisto_UpdAmtToCash					= 10;
FIELD_IDX_T A_FreeDepositHisto_CreationDate					= 11;
FIELD_IDX_T A_FreeDepositHisto_CreationUserId				= 12;
FIELD_IDX_T A_FreeDepositHisto_LastModifDate				= 13;
FIELD_IDX_T A_FreeDepositHisto_LastUserId					= 14;
FIELD_IDX_T A_FreeDepositHisto_CounterpartAcctC				= 15; /* PMSTA-33148-RAK-181005 */

FIELD_IDX_T S_FreeDepositHisto_Id							= 0;
FIELD_IDX_T S_FreeDepositHisto_Cd                           = 1;
FIELD_IDX_T S_FreeDepositHisto_InvestmentDate			    = 2;


FIELD_IDX_T A_PtfChrono_PtfId                        = 0;
FIELD_IDX_T A_PtfChrono_CurrId                       = 1;
FIELD_IDX_T A_PtfChrono_ValidDate                    = 2;
FIELD_IDX_T A_PtfChrono_NatEn                        = 3;
FIELD_IDX_T A_PtfChrono_Val                          = 4;
FIELD_IDX_T A_PtfChrono_Comment                      = 5;
FIELD_IDX_T A_PtfChrono_TimeDimEn                    = 6;
FIELD_IDX_T A_PtfChrono_ValidFlg                     = 7;


FIELD_IDX_T S_PtfChrono_PtfId                        = 0;
FIELD_IDX_T S_PtfChrono_CurrId                       = 1;
FIELD_IDX_T S_PtfChrono_ValidDate                    = 2;
FIELD_IDX_T S_PtfChrono_NatEn                        = 3;
FIELD_IDX_T S_PtfChrono_PtfCd                        = 4;
FIELD_IDX_T S_PtfChrono_Val                          = 5;
FIELD_IDX_T S_PtfChrono_CurrCd                       = 6;


FIELD_IDX_T Freq_PtfChrono_PtfId                     = 0;
FIELD_IDX_T Freq_PtfChrono_CurrId                    = 1;
FIELD_IDX_T Freq_PtfChrono_ValidDate                 = 2;
FIELD_IDX_T Freq_PtfChrono_NatEn                     = 3;
FIELD_IDX_T Freq_PtfChrono_Val                       = 4;
FIELD_IDX_T Freq_PtfChrono_RequestDate               = 5;


FIELD_IDX_T A_PtfFreq_Id                             = 0;
FIELD_IDX_T A_PtfFreq_PtfId                          = 1;
FIELD_IDX_T A_PtfFreq_InitialDate                    = 2;
FIELD_IDX_T A_PtfFreq_FreqDate                       = 3;
FIELD_IDX_T A_PtfFreq_PtfStatus                      = 4;
FIELD_IDX_T A_PtfFreq_A_Ptf_Ext                      = 5;


FIELD_IDX_T A_PtfPosSet_Id                           = 0;
FIELD_IDX_T A_PtfPosSet_PtfId                        = 1;
FIELD_IDX_T A_PtfPosSet_CurrId                       = 2;
FIELD_IDX_T A_PtfPosSet_TpId                         = 3;
FIELD_IDX_T A_PtfPosSet_ConsPtfId                    = 4;
FIELD_IDX_T A_PtfPosSet_QuoteValRuleId               = 5;
FIELD_IDX_T A_PtfPosSet_ExchValRuleId                = 6;
FIELD_IDX_T A_PtfPosSet_BookValRuleId                = 7;
FIELD_IDX_T A_PtfPosSet_AccPlanId                    = 8;
FIELD_IDX_T A_PtfPosSet_FusRuleEn                    = 9;
FIELD_IDX_T A_PtfPosSet_FusDateRuleEn                = 10;
FIELD_IDX_T A_PtfPosSet_PosLogicalEn                 = 11;
FIELD_IDX_T A_PtfPosSet_BegDate                      = 12;
FIELD_IDX_T A_PtfPosSet_EndDate                      = 13;
FIELD_IDX_T A_PtfPosSet_BookAdjFreq                  = 14;
FIELD_IDX_T A_PtfPosSet_BookAdjFreqUnitEn            = 15;
FIELD_IDX_T A_PtfPosSet_TransferCompFlg              = 16;
FIELD_IDX_T A_PtfPosSet_BookPreAdjFlg                = 17;
FIELD_IDX_T A_PtfPosSet_PtfSynthFlg                  = 18;
FIELD_IDX_T A_PtfPosSet_PnLRuleId                    = 19;
FIELD_IDX_T A_PtfPosSet_OldFusDateRuleEn             = 20; /*REF10256-BRO-040716*/


FIELD_IDX_T S_PtfPosSet_Id                           = 0;
FIELD_IDX_T S_PtfPosSet_PtfId                        = 1;
FIELD_IDX_T S_PtfPosSet_CurrId                       = 2;
FIELD_IDX_T S_PtfPosSet_TpId                         = 3;
FIELD_IDX_T S_PtfPosSet_ConsPtfId                    = 4;
FIELD_IDX_T S_PtfPosSet_CurrCd                       = 5;
FIELD_IDX_T S_PtfPosSet_TpCd                         = 6;
FIELD_IDX_T S_PtfPosSet_ConsPtfCd                    = 7;



FIELD_IDX_T A_PtfSynth_Id                            = 0;
FIELD_IDX_T A_PtfSynth_PtfId                         = 1;
FIELD_IDX_T A_PtfSynth_PtfPosSetId                   = 2;
FIELD_IDX_T A_PtfSynth_CurrId                        = 3;
FIELD_IDX_T A_PtfSynth_InstrId                       = 4;
FIELD_IDX_T A_PtfSynth_MktSegtId                     = 5;
FIELD_IDX_T A_PtfSynth_GridId                        = 6;
FIELD_IDX_T A_PtfSynth_AbsMktSegId                   = 7;
FIELD_IDX_T A_PtfSynth_OrdMktSegId                   = 8;
FIELD_IDX_T A_PtfSynth_ParMktSegId                   = 9;
FIELD_IDX_T A_PtfSynth_ParGridId                     = 10;
FIELD_IDX_T A_PtfSynth_HeadGridId                    = 11;
FIELD_IDX_T A_PtfSynth_RiskNatEn                     = 12;
FIELD_IDX_T A_PtfSynth_InitialDate                   = 13;
FIELD_IDX_T A_PtfSynth_FinalDate                     = 14;
FIELD_IDX_T A_PtfSynth_InitialNumDays                = 15;
FIELD_IDX_T A_PtfSynth_FinalNumDays                  = 16;
FIELD_IDX_T A_PtfSynth_FirstFlowNumDays              = 17;
FIELD_IDX_T A_PtfSynth_Level                         = 18;
FIELD_IDX_T A_PtfSynth_NetRealCapP                   = 19;
FIELD_IDX_T A_PtfSynth_GrossRealCapP                 = 20;
FIELD_IDX_T A_PtfSynth_NetRealCapL                   = 21;
FIELD_IDX_T A_PtfSynth_GrossRealCapL                 = 22;
FIELD_IDX_T A_PtfSynth_NetRealCurrP                  = 23;
FIELD_IDX_T A_PtfSynth_GrossRealCurrP                = 24;
FIELD_IDX_T A_PtfSynth_NetRealCurrL                  = 25;
FIELD_IDX_T A_PtfSynth_GrossRealCurrL                = 26;
FIELD_IDX_T A_PtfSynth_NetRecInc                     = 27;
FIELD_IDX_T A_PtfSynth_GrossRecInc                   = 28;
FIELD_IDX_T A_PtfSynth_NetPaidInc                    = 29;
FIELD_IDX_T A_PtfSynth_GrossPaidInc                  = 30;
FIELD_IDX_T A_PtfSynth_RecAccrInter                  = 31;
FIELD_IDX_T A_PtfSynth_PaidAccrInter                 = 32;
FIELD_IDX_T A_PtfSynth_PtfFees                       = 33;
FIELD_IDX_T A_PtfSynth_PtfTax                        = 34;
FIELD_IDX_T A_PtfSynth_TaxCred                       = 35;
FIELD_IDX_T A_PtfSynth_NetCostVal                    = 36;
FIELD_IDX_T A_PtfSynth_GrossCostVal                  = 37;
FIELD_IDX_T A_PtfSynth_NetUnrealCapP                 = 38;
FIELD_IDX_T A_PtfSynth_GrossUnrealCapP               = 39;
FIELD_IDX_T A_PtfSynth_NetUnrealCapL                 = 40;
FIELD_IDX_T A_PtfSynth_GrossUnrealCapL               = 41;
FIELD_IDX_T A_PtfSynth_NetUnrealCurrP                = 42;
FIELD_IDX_T A_PtfSynth_GrossUnrealCurrP              = 43;
FIELD_IDX_T A_PtfSynth_NetUnrealCurrL                = 44;
FIELD_IDX_T A_PtfSynth_GrossUnrealCurrL              = 45;
FIELD_IDX_T A_PtfSynth_NetInvest                     = 46;
FIELD_IDX_T A_PtfSynth_GrossInvest                   = 47;
FIELD_IDX_T A_PtfSynth_NetWithdr                     = 48;
FIELD_IDX_T A_PtfSynth_GrossWithdr                   = 49;
FIELD_IDX_T A_PtfSynth_NetAdj                        = 50;
FIELD_IDX_T A_PtfSynth_GrossAdj                      = 51;
FIELD_IDX_T A_PtfSynth_InitialMktVal                 = 52;
FIELD_IDX_T A_PtfSynth_FinalMktVal                   = 53;
FIELD_IDX_T A_PtfSynth_UnrealRecAccrInter            = 54;
FIELD_IDX_T A_PtfSynth_UnrealPaidAccrInter           = 55;
FIELD_IDX_T A_PtfSynth_WeightNetInvest               = 56;
FIELD_IDX_T A_PtfSynth_WeightGrossInvest             = 57;
FIELD_IDX_T A_PtfSynth_WeightNetWithdr               = 58;
FIELD_IDX_T A_PtfSynth_WeightGrossWithdr             = 59;
FIELD_IDX_T A_PtfSynth_WeightTaxCred                 = 60;
FIELD_IDX_T A_PtfSynth_WeightNetAdj                  = 61;
FIELD_IDX_T A_PtfSynth_WeightGrossAdj                = 62;
FIELD_IDX_T A_PtfSynth_NetPurchases                  = 63;
FIELD_IDX_T A_PtfSynth_GrossPurchases                = 64;
FIELD_IDX_T A_PtfSynth_NetSales                      = 65;
FIELD_IDX_T A_PtfSynth_GrossSales                    = 66;
FIELD_IDX_T A_PtfSynth_WeightNetPurchases            = 67;
FIELD_IDX_T A_PtfSynth_WeightGrossPurchases          = 68;
FIELD_IDX_T A_PtfSynth_WeightNetSales                = 69;
FIELD_IDX_T A_PtfSynth_WeightGrossSales              = 70;
FIELD_IDX_T A_PtfSynth_WeightNetRecInc               = 71;
FIELD_IDX_T A_PtfSynth_WeightGrossRecInc             = 72;
FIELD_IDX_T A_PtfSynth_WeightNetPaidInc              = 73;
FIELD_IDX_T A_PtfSynth_WeightGrossPaidInc            = 74;
FIELD_IDX_T A_PtfSynth_WeightPtfFees                 = 75;
FIELD_IDX_T A_PtfSynth_WeightPtfTax                  = 76;
FIELD_IDX_T A_PtfSynth_InitUnrealRecAI               = 77;
FIELD_IDX_T A_PtfSynth_FinUnrealRecAI                = 78;
FIELD_IDX_T A_PtfSynth_InitUnrealPaidAI              = 79;
FIELD_IDX_T A_PtfSynth_FinUnrealPaidAI               = 80;
FIELD_IDX_T A_PtfSynth_PersistEn                     = 81;
FIELD_IDX_T A_PtfSynth_PeriodNatEn                   = 82;
FIELD_IDX_T A_PtfSynth_InitialNotInvestedDays        = 83; /* PMSTA-52459 - DDV - 230414 */
FIELD_IDX_T A_PtfSynth_FinalNotInvestedDays          = 84; /* PMSTA-52459 - DDV - 230414 */
FIELD_IDX_T A_PtfSynth_IntradayNIPFlg                = 85; /* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
FIELD_IDX_T A_PtfSynth_PSPId                         = 86; /* REF9125 - LJE - 030818 */
FIELD_IDX_T A_PtfSynth_Qty                           = 87; /* REF9338 - LJE - 030923 */
FIELD_IDX_T A_PtfSynth_PosFees                       = 88; /* REF11269 - LJE - 051220 */
FIELD_IDX_T A_PtfSynth_PosTax                        = 89; /* REF11269 - LJE - 051220 */
FIELD_IDX_T A_PtfSynth_WeightPosFees                 = 90; /* REF11269 - LJE - 051220 */
FIELD_IDX_T A_PtfSynth_WeightPosTax                  = 91; /* REF11269 - LJE - 051220 */
FIELD_IDX_T A_PtfSynth_Dura                          = 92; /* PMSTA08736 - LJE - 100120 */
FIELD_IDX_T A_PtfSynth_PurchasesAccrInter            = 93;
FIELD_IDX_T A_PtfSynth_SalesAccrInter                = 94;
FIELD_IDX_T A_PtfSynth_InvestAccrInter               = 95;
FIELD_IDX_T A_PtfSynth_WithdrAccrInter               = 96;
FIELD_IDX_T A_PtfSynth_CostPriceAdjCapP				 = 97; /* PMSTA-9217 - RAK - 100223 */
FIELD_IDX_T A_PtfSynth_CostPriceAdjCapL				 = 98; /* PMSTA-9217 - RAK - 100223 */
FIELD_IDX_T A_PtfSynth_CostPriceAdjCurrP			 = 99; /* PMSTA-9217 - RAK - 100223 */
FIELD_IDX_T A_PtfSynth_CostPriceAdjCurrL			 = 100; /* PMSTA-9217 - RAK - 100223 */
FIELD_IDX_T A_PtfSynth_LastFlowNumDays				 = 101;
FIELD_IDX_T A_PtfSynth_GridLinkNatEn                 = 102;
FIELD_IDX_T A_PtfSynth_ParentId                      = 103; /* REF9743 - LJE - 040216 */
FIELD_IDX_T A_PtfSynth_Parent_Ext                    = 104; /* REF9743 - LJE - 040216 */
FIELD_IDX_T A_PtfSynth_ToInsertEn                    = 105; /* PMSTA06591 - LJE - 080522 */
FIELD_IDX_T A_PtfSynth_RiskOriginAdjFlg              = 106;
FIELD_IDX_T A_PtfSynth_ParentSplit_Ext               = 107;
FIELD_IDX_T A_PtfSynth_FundSplitNatEn                = 108;
FIELD_IDX_T A_PtfSynth_FirstOpNatEn                  = 109; /* PMSTA-42154 - vkumar - 011220 */
FIELD_IDX_T A_PtfSynth_HeadPspId                     = 110; /*PMSTA-48195*/
FIELD_IDX_T A_PtfSynth_AddedInParentFlg              = 111; /*PMSTA-48195 -to find good to remove synth -Lalby-060722*/
FIELD_IDX_T A_PtfSynth_ListId                        = 112; /* PMSTA-53952 - Lalby - 14112023  */
FIELD_IDX_T A_PtfSynth_GblPtfSynth_Ext               = 113; /* Deepthi - PMSTA-55377 - 240117*/
FIELD_IDX_T A_PtfSynth_PtfInAdj                      = 114; /* WEALTH-9725 - Lalby - 25062024- Manage Ptf in and out using PCP */
FIELD_IDX_T A_PtfSynth_PtfOutAdj                     = 115; 
FIELD_IDX_T A_PtfSynth_MktSegInAdj                   = 116; 
FIELD_IDX_T A_PtfSynth_MktSegOutAdj                  = 117; 
FIELD_IDX_T A_PtfSynth_NextMktSegtId                 = 118; /* WEALTH-8023 - DDV - 240627 */

FIELD_IDX_T S_PtfSynth_Id                            = 0;
FIELD_IDX_T S_PtfSynth_PtfId                         = 1;
FIELD_IDX_T S_PtfSynth_PtfPosSetId                   = 2;
FIELD_IDX_T S_PtfSynth_CurrId                        = 3;
FIELD_IDX_T S_PtfSynth_InstrId                       = 4;
FIELD_IDX_T S_PtfSynth_MktSegtId                     = 5;
FIELD_IDX_T S_PtfSynth_RiskNatEn                     = 6;
FIELD_IDX_T S_PtfSynth_InitialDate                   = 7;
FIELD_IDX_T S_PtfSynth_FinalDate                     = 8;
FIELD_IDX_T S_PtfSynth_PersistEn                     = 9;


FIELD_IDX_T Zero_PtfSynth_PtfId                      = 0;
FIELD_IDX_T Zero_PtfSynth_PtfPosSetId                = 1;
FIELD_IDX_T Zero_PtfSynth_CurrId                     = 2;
FIELD_IDX_T Zero_PtfSynth_InstrId                    = 3;
FIELD_IDX_T Zero_PtfSynth_GridId                     = 4;
FIELD_IDX_T Zero_PtfSynth_MktSegtId                  = 5;
FIELD_IDX_T Zero_PtfSynth_RiskNatEn                  = 6;
FIELD_IDX_T Zero_PtfSynth_FirstFlowNumDays           = 7;
FIELD_IDX_T Zero_PtfSynth_FinalNumDays               = 8;
FIELD_IDX_T Zero_PtfSynth_ZeroFlg                    = 9;
FIELD_IDX_T Zero_PtfSynth_PSPId                      = 10; /* REF9743 - LJE - 040218 */
FIELD_IDX_T Zero_PtfSynth_PersistEn                  = 11;



FIELD_IDX_T A_Pos_Id                                 = 0;
FIELD_IDX_T A_Pos_PtfId                              = 1;
FIELD_IDX_T A_Pos_PtfPosSetId                        = 2;
FIELD_IDX_T A_Pos_InstrId                            = 3;
FIELD_IDX_T A_Pos_DepoId                             = 4;
FIELD_IDX_T A_Pos_PosCurrId                          = 5;
FIELD_IDX_T A_Pos_InstrCurrId                        = 6;
FIELD_IDX_T A_Pos_PtfCurrId                          = 7;
FIELD_IDX_T A_Pos_CntPtyThirdId                      = 8;
FIELD_IDX_T A_Pos_OpenOpId                           = 9;
FIELD_IDX_T A_Pos_CloseOpId                          = 10;
FIELD_IDX_T A_Pos_TermTpId                           = 11;
FIELD_IDX_T A_Pos_LockTpId                           = 12;
FIELD_IDX_T A_Pos_ValRuleEltId                       = 13;
FIELD_IDX_T A_Pos_OpenOpNatEn                        = 14;
FIELD_IDX_T A_Pos_AdjustNatEn                        = 15;
FIELD_IDX_T A_Pos_OpenOpCd                           = 16;
FIELD_IDX_T A_Pos_CloseOpCd                          = 17;
FIELD_IDX_T A_Pos_RefOpCd                            = 18;
FIELD_IDX_T A_Pos_RefNatEn                           = 19;
FIELD_IDX_T A_Pos_ExecOpCd                           = 20;
FIELD_IDX_T A_Pos_ExecOpNatEn                        = 21;
FIELD_IDX_T A_Pos_ExecOpStatEn                       = 22;
FIELD_IDX_T A_Pos_RevOpCd                            = 23;
FIELD_IDX_T A_Pos_RevOpNatEn                         = 24;
FIELD_IDX_T A_Pos_LockOpCd                           = 25;
FIELD_IDX_T A_Pos_LockNatEn                          = 26;
FIELD_IDX_T A_Pos_EventCd                            = 27;
FIELD_IDX_T A_Pos_EventNbr                           = 28;
FIELD_IDX_T A_Pos_StatEn                             = 29;
FIELD_IDX_T A_Pos_PrimaryEn                          = 30;
FIELD_IDX_T A_Pos_MainFlag                           = 31;
FIELD_IDX_T A_Pos_PosNatEn                           = 32;
FIELD_IDX_T A_Pos_SubPosNatEn                        = 33;
FIELD_IDX_T A_Pos_SubPosNat2En                       = 34;
FIELD_IDX_T A_Pos_SubPosNat3En                       = 35;
FIELD_IDX_T A_Pos_ExCouponFlag                       = 36;
FIELD_IDX_T A_Pos_Fus                                = 37;
FIELD_IDX_T A_Pos_FusRuleEn                          = 38;
FIELD_IDX_T A_Pos_BegDate                            = 39;
FIELD_IDX_T A_Pos_EndDate                            = 40;
FIELD_IDX_T A_Pos_OpDate                             = 41;
FIELD_IDX_T A_Pos_AcctDate                           = 42;
FIELD_IDX_T A_Pos_ValDate                            = 43;
FIELD_IDX_T A_Pos_LockLimitDate                      = 44;
FIELD_IDX_T A_Pos_ExpirDate                          = 45;
FIELD_IDX_T A_Pos_AccrAmt                            = 46;
FIELD_IDX_T A_Pos_OrderLimitDate                     = 47;
FIELD_IDX_T A_Pos_Remark                             = 48;
FIELD_IDX_T A_Pos_PosExchRate                        = 49;
FIELD_IDX_T A_Pos_InstrExchRate                      = 50;
FIELD_IDX_T A_Pos_SysExchRate                        = 51;
FIELD_IDX_T A_Pos_BookPosExchRate                    = 52;
FIELD_IDX_T A_Pos_BookInstrExchRate                  = 53;
FIELD_IDX_T A_Pos_BookSysExchRate                    = 54;
FIELD_IDX_T A_Pos_Qty                                = 55;
FIELD_IDX_T A_Pos_Price                              = 56;
FIELD_IDX_T A_Pos_SpotPrice                          = 57;
FIELD_IDX_T A_Pos_BookPrice                          = 58;
FIELD_IDX_T A_Pos_PriceCalcRuleEn                    = 59;
FIELD_IDX_T A_Pos_Quote                              = 60;
FIELD_IDX_T A_Pos_SpotQuote                          = 61;
FIELD_IDX_T A_Pos_BookQuote                          = 62;
FIELD_IDX_T A_Pos_Rate                               = 63;
FIELD_IDX_T A_Pos_SupplAmt                           = 64;
FIELD_IDX_T A_Pos_PosGrossAmt                        = 65;
FIELD_IDX_T A_Pos_PosNetAmt                          = 66;
FIELD_IDX_T A_Pos_InstrGrossAmt                      = 67;
FIELD_IDX_T A_Pos_InstrNetAmt                        = 68;
FIELD_IDX_T A_Pos_PtfGrossAmt                        = 69;
FIELD_IDX_T A_Pos_PtfNetAmt                          = 70;
FIELD_IDX_T A_Pos_SysGrossAmt                        = 71;
FIELD_IDX_T A_Pos_SysNetAmt                          = 72;
FIELD_IDX_T A_Pos_BookPosAmt                         = 73;
FIELD_IDX_T A_Pos_BookInstrAmt                       = 74;
FIELD_IDX_T A_Pos_BookPtfAmt                         = 75;
FIELD_IDX_T A_Pos_BookSysAmt                         = 76;
FIELD_IDX_T A_Pos_Bp1PosAmt                          = 77;
FIELD_IDX_T A_Pos_Bp2PosAmt                          = 78;
FIELD_IDX_T A_Pos_Bp3PosAmt                          = 79;
FIELD_IDX_T A_Pos_Bp4PosAmt                          = 80;
FIELD_IDX_T A_Pos_Bp5PosAmt                          = 81;
FIELD_IDX_T A_Pos_Bp6PosAmt                          = 82;
FIELD_IDX_T A_Pos_Bp7PosAmt                          = 83;
FIELD_IDX_T A_Pos_Bp8PosAmt                          = 84;
FIELD_IDX_T A_Pos_Bp9PosAmt                          = 85;
FIELD_IDX_T A_Pos_Bp10PosAmt                         = 86;
FIELD_IDX_T A_Pos_HistQuote                          = 87;  /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T A_Pos_UnpaidPrct                         = 88;  /* PMSTA-16533 - 221113 - PMO */
FIELD_IDX_T A_Pos_PosNetIncreaseAmt                  = 89; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosGrossIncreaseAmt                = 90; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosNetDecreaseAmt                  = 91; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosGrossDecreaseAmt                = 92; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosNetIncreaseYearAmt              = 93; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosGrossIncreaseYearAmt            = 94; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosNetDecreaseYearAmt              = 95; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PosGrossDecreaseYearAmt            = 96; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfNetIncreaseAmt                   = 97; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfGrossIncreaseAmt                 = 98; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfNetDecreaseAmt                   = 99; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfGrossDecreaseAmt                 =100; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfNetIncreaseYearAmt               =101; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfGrossIncreaseYearAmt             =102; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfNetDecreaseYearAmt               =103; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_PfGrossDecreaseYearAmt             =104; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_AcquisitionDate                    =105; /* PMSTA-28286 - JBC - 207699 */
FIELD_IDX_T A_Pos_AcquisitionOpenOpId                =106; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_TaxLotInitialId                    =107; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_BpPosExchangeRate                  =108; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_BpFiExchangeRate                   =109; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_BpSysExchangeRate                  =110; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_CorporateActionNatEn               =111; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_TaxLotSourceCd                     =112; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T A_Pos_StandInstructId                    =113; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T A_Pos_PaymentOption                      =114; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T A_Pos_PaymentDate                        =115; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Pos_PaymentStatusEn                    =116; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Pos_SettlementDate                     =117; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Pos_SettleStatusEn                     =118; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T A_Pos_LockQuantity                       =119; /*PMSTA-39162 -NRAO- 03052020*/

FIELD_IDX_T A_Pos_BusinessAcquisitionDate            =120; /* PMSTA-49603 - AIS - 220626 */
FIELD_IDX_T	A_Pos_FlowInfoEn                         =121; /* PMSTA-47578 - DDV - 220117 */
FIELD_IDX_T	A_Pos_TimingRuleEn                       =122; /* PMSTA-47578 - DDV - 220117 */

FIELD_IDX_T S_Pos_Id                                 = 0;
FIELD_IDX_T S_Pos_PtfId                              = 1;
FIELD_IDX_T S_Pos_InstrId                            = 2;
FIELD_IDX_T S_Pos_OpenOpNatEn                        = 3;
FIELD_IDX_T S_Pos_OpenOpCd                           = 4;
FIELD_IDX_T S_Pos_RefNatEn                           = 5;
FIELD_IDX_T S_Pos_PrimaryEn                          = 6;
FIELD_IDX_T S_Pos_BegDate                            = 7;
FIELD_IDX_T S_Pos_EndDate                            = 8;
FIELD_IDX_T S_Pos_Qty                                = 9;
FIELD_IDX_T S_Pos_Price                              = 10;
FIELD_IDX_T S_Pos_PriceCalcRuleEn                    = 11;
FIELD_IDX_T S_Pos_Quote                              = 12;
FIELD_IDX_T S_Pos_InstrNetAmt                        = 13;
FIELD_IDX_T S_Pos_PosGrossAmt                        = 14;
FIELD_IDX_T S_Pos_PosNetAmt                          = 15;


FIELD_IDX_T A_Printer_Id                             = 0;
FIELD_IDX_T A_Printer_Cd                             = 1;
FIELD_IDX_T A_Printer_PrintModeEn                    = 2;
FIELD_IDX_T A_Printer_Comment                        = 3;
FIELD_IDX_T A_Printer_Device                         = 4;
FIELD_IDX_T A_Printer_Command                        = 5;


FIELD_IDX_T S_Printer_Id                             = 0;
FIELD_IDX_T S_Printer_Cd                             = 1;
FIELD_IDX_T S_Printer_PrintModeEn                    = 2;
FIELD_IDX_T S_Printer_Comment                        = 3;


FIELD_IDX_T A_PrinterProf_Id                         = 0;
FIELD_IDX_T A_PrinterProf_Cd                         = 1;


FIELD_IDX_T S_PrinterProf_Id                         = 0;
FIELD_IDX_T S_PrinterProf_Cd                         = 1;


FIELD_IDX_T A_PrinterProfCompo_PrintProfId           = 0;
FIELD_IDX_T A_PrinterProfCompo_PrinterId             = 1;
FIELD_IDX_T A_PrinterProfCompo_Display               = 2;


FIELD_IDX_T S_PrinterProfCompo_PrintProfId           = 0;
FIELD_IDX_T S_PrinterProfCompo_PrinterId             = 1;
FIELD_IDX_T S_PrinterProfCompo_Display               = 2;
FIELD_IDX_T S_PrinterProfCompo_PrintProfCd           = 3;
FIELD_IDX_T S_PrinterProfCompo_PrintCd               = 4;


FIELD_IDX_T A_PrintParam_OutputTpEn                  = 0;
FIELD_IDX_T A_PrintParam_OutputName                  = 1;
FIELD_IDX_T A_PrintParam_RoiOutputName               = 2;
FIELD_IDX_T A_PrintParam_DestiEn                     = 3;
FIELD_IDX_T A_PrintParam_Copy                        = 4;
FIELD_IDX_T A_PrintParam_DelFlg                      = 5;
FIELD_IDX_T A_PrintParam_DbgOption                   = 6;
FIELD_IDX_T A_PrintParam_PrinterId                   = 7;
FIELD_IDX_T A_PrintParam_PrinterFlg                  = 8;
FIELD_IDX_T A_PrintParam_PreviewFlg                  = 9;
FIELD_IDX_T A_PrintParam_FileFlg                     = 10;
FIELD_IDX_T A_PrintParam_DebugLineFlg                = 11;
FIELD_IDX_T A_PrintParam_DebugProcFlg                = 12;
FIELD_IDX_T A_PrintParam_DebugTimeFlg                = 13;
FIELD_IDX_T A_PrintParam_DebugDomainFlg              = 14;
FIELD_IDX_T A_PrintParam_DebugDelimitedFlg           = 15;


FIELD_IDX_T A_QuickSearch_Id                         = 0;


FIELD_IDX_T A_Rating_Id                              = 0;
FIELD_IDX_T A_Rating_Cd                              = 1;
FIELD_IDX_T A_Rating_CodifId                         = 2;
FIELD_IDX_T A_Rating_AutoCreatedFlg                  = 3;
FIELD_IDX_T A_Rating_Rank                            = 4;


FIELD_IDX_T S_Rating_Id                              = 0;
FIELD_IDX_T S_Rating_CodifCd                         = 1;
FIELD_IDX_T S_Rating_Cd                              = 2;
FIELD_IDX_T S_Rating_Rank                            = 3;
FIELD_IDX_T S_Rating_CodifId                         = 4;


FIELD_IDX_T A_RatingAttr_EntDictId                   = 0;
FIELD_IDX_T A_RatingAttr_ObjId                       = 1;
FIELD_IDX_T A_RatingAttr_CodifId                     = 2;
FIELD_IDX_T A_RatingAttr_BegDate                     = 3;
FIELD_IDX_T A_RatingAttr_RatingId                    = 4;


FIELD_IDX_T S_RatingAttr_EntDictId                   = 0;
FIELD_IDX_T S_RatingAttr_ObjId                       = 1;
FIELD_IDX_T S_RatingAttr_CodifId                     = 2;
FIELD_IDX_T S_RatingAttr_BegDate                     = 3;
FIELD_IDX_T S_RatingAttr_RatingCd                    = 4;
FIELD_IDX_T S_RatingAttr_CodifCd                     = 5;


FIELD_IDX_T A_Regr_Array1                            = 0;
FIELD_IDX_T A_Regr_Array2                            = 1;
FIELD_IDX_T A_Regr_RecNbr                            = 2;
FIELD_IDX_T A_Regr_Alpha                             = 3;
FIELD_IDX_T A_Regr_Beta                              = 4;
FIELD_IDX_T A_Regr_Covariance                        = 5;
FIELD_IDX_T A_Regr_CorrelationCoef                   = 6;
FIELD_IDX_T A_Regr_DetermCoefR2                      = 7;
FIELD_IDX_T A_Regr_ChiSquared                        = 8;
FIELD_IDX_T A_Regr_StdDeviationAlpha                 = 9;
FIELD_IDX_T A_Regr_StdDeviationBeta                  = 10;
FIELD_IDX_T A_Regr_GoodnessFitProbQ                  = 11;


FIELD_IDX_T A_Report_Id                              = 0;
FIELD_IDX_T A_Report_Cd                              = 1;
FIELD_IDX_T A_Report_Denom                           = 2;
FIELD_IDX_T A_Report_FmtProfId                       = 3;
FIELD_IDX_T A_Report_TitleMsgId                      = 4;
FIELD_IDX_T A_Report_TabContentId                    = 5;
FIELD_IDX_T A_Report_TypeId                          = 6; /*REF9782-BRO-040203*/
FIELD_IDX_T A_Report_NatEn                           = 7;
FIELD_IDX_T A_Report_AutoGenFlg                      = 8;
FIELD_IDX_T A_Report_OrienFlg                        = 9;
FIELD_IDX_T A_Report_HeaderName                      = 10;
FIELD_IDX_T A_Report_FooterName                      = 11;
FIELD_IDX_T A_Report_BeforePageName                  = 12;
FIELD_IDX_T A_Report_AfterPageName                   = 13;
FIELD_IDX_T A_Report_LastGenDt                       = 14;
FIELD_IDX_T A_Report_TocHeadFlg                      = 15;
FIELD_IDX_T A_Report_TocFootFlg                      = 16;
FIELD_IDX_T A_Report_BefPageHeadFlg                  = 17;
FIELD_IDX_T A_Report_BefPageFootFlg                  = 18;
FIELD_IDX_T A_Report_AftPageHeadFlg                  = 19;
FIELD_IDX_T A_Report_AftPageFootFlg                  = 20;
FIELD_IDX_T A_Report_ExtAppl                         = 21;
FIELD_IDX_T A_Report_DfltDomainFlg                   = 22;
FIELD_IDX_T A_Report_BusinessNatureEn                = 23;  /* PMSTA-17248 - EFE - 20131121 */
FIELD_IDX_T A_Report_ClassName						 = 24;  /*PMSTA- 20039 - SHR - 20150225 */


FIELD_IDX_T S_Report_Id                              = 0;
FIELD_IDX_T S_Report_Cd                              = 1;
FIELD_IDX_T S_Report_Denom                           = 2;
FIELD_IDX_T S_Report_NatEn                           = 3;
FIELD_IDX_T S_Report_TypeId                          = 4;      /*REF9782-PRO-040212*/
FIELD_IDX_T S_Report_ClassName						 = 5;  /*PMSTA- 20126 - Cashwini - 04072015 */


FIELD_IDX_T A_ReportGen_ReportId                     = 0;
FIELD_IDX_T A_ReportGen_AllReportFlg                 = 1;
FIELD_IDX_T A_ReportGen_ActionEn                     = 2;
FIELD_IDX_T A_ReportGen_ForceFlg                     = 3;


FIELD_IDX_T A_ReportParam_Id                         = 0;
FIELD_IDX_T A_ReportParam_ReportId                   = 1;
FIELD_IDX_T A_ReportParam_Rank                       = 2;
FIELD_IDX_T A_ReportParam_ParAttrDictId              = 3;
FIELD_IDX_T A_ReportParam_ExtFlg                     = 4;
FIELD_IDX_T A_ReportParam_AttrSqlName                = 5;
FIELD_IDX_T A_ReportParam_DataTpDictId               = 6;


FIELD_IDX_T S_ReportParam_Id                         = 0;
FIELD_IDX_T S_ReportParam_ReportId                   = 1;
FIELD_IDX_T S_ReportParam_Rank                       = 2;
FIELD_IDX_T S_ReportParam_ParAttrDictId              = 3;
FIELD_IDX_T S_ReportParam_ExtFlg                     = 4;
FIELD_IDX_T S_ReportParam_AttrSqlName                = 5;
FIELD_IDX_T S_ReportParam_DataTpDictId               = 6;
FIELD_IDX_T S_ReportParam_ReportCd                   = 7;
FIELD_IDX_T S_ReportParam_DataTpName                 = 8;


FIELD_IDX_T A_ReportProf_Id                          = 0;
FIELD_IDX_T A_ReportProf_Cd                          = 1;


FIELD_IDX_T S_ReportProf_Id                          = 0;
FIELD_IDX_T S_ReportProf_Cd                          = 1;


FIELD_IDX_T A_ReportProfCompo_ReportProfId           = 0;
FIELD_IDX_T A_ReportProfCompo_ReportId               = 1;


FIELD_IDX_T S_ReportProfCompo_ReportProfId           = 0;
FIELD_IDX_T S_ReportProfCompo_ReportId               = 1;
FIELD_IDX_T S_ReportProfCompo_ReportCd               = 2;

/* PMSTA-25021 - TEB - 161110 */
FIELD_IDX_T A_ReportModuleCompo_Id                   = 0;
FIELD_IDX_T A_ReportModuleCompo_ReportId             = 1;
FIELD_IDX_T A_ReportModuleCompo_ModuleId             = 2;
FIELD_IDX_T A_ReportModuleCompo_Rank                 = 3;
FIELD_IDX_T A_ReportModuleCompo_PageCountResetFlg    = 4;
FIELD_IDX_T A_ReportModuleCompo_PageToCountFlg       = 5;
FIELD_IDX_T A_ReportModuleCompo_PaginationStyleEn    = 6;
FIELD_IDX_T A_ReportModuleCompo_PositionEn           = 7;
FIELD_IDX_T A_ReportModuleCompo_VisibleInTocFlg      = 8;

/* PMSTA-25021 - TEB - 161110 */
FIELD_IDX_T S_ReportModuleCompo_Id                   = 0;
FIELD_IDX_T S_ReportModuleCompo_ReportId             = 1;
FIELD_IDX_T S_ReportModuleCompo_ReportModuleId       = 2;
FIELD_IDX_T S_ReportModuleCompo_Rank                 = 3;
FIELD_IDX_T S_ReportModuleCompo_ModuleName           = 4;


/*<REF10604-BRO-040922*/
FIELD_IDX_T A_RequestCode_Id                         = 0;
FIELD_IDX_T A_RequestCode_RequestCodeCd              = 1;
FIELD_IDX_T A_RequestCode_TradingPlaceId             = 2;
FIELD_IDX_T A_RequestCode_CodifId                    = 3;

FIELD_IDX_T S_RequestCode_Id                         = 0;
FIELD_IDX_T S_RequestCode_RequestCodeCd              = 1;
FIELD_IDX_T S_RequestCode_TradingPlaceId             = 2;
FIELD_IDX_T S_RequestCode_CodifId                    = 3;
FIELD_IDX_T S_RequestCode_CodifCd                    = 4;
/*>REF10604-BRO-040922*/


FIELD_IDX_T A_RetAnaDetailed_Id                      = 0;
FIELD_IDX_T A_RetAnaDetailed_PspId                   = 1;
FIELD_IDX_T A_RetAnaDetailed_MktSegtId               = 2;
FIELD_IDX_T A_RetAnaDetailed_InstrId                 = 3;
FIELD_IDX_T A_RetAnaDetailed_InitialDate             = 4;
FIELD_IDX_T A_RetAnaDetailed_FinalDate               = 5;
FIELD_IDX_T A_RetAnaDetailed_InitialMktVal           = 6;
FIELD_IDX_T A_RetAnaDetailed_FinalMktVal             = 7;
FIELD_IDX_T A_RetAnaDetailed_Fees                    = 8;
FIELD_IDX_T A_RetAnaDetailed_Taxes                   = 9;
FIELD_IDX_T A_RetAnaDetailed_Flows                   = 10;
FIELD_IDX_T A_RetAnaDetailed_ProfitLoss              = 11;
FIELD_IDX_T A_RetAnaDetailed_FlowMeanCap             = 12;
FIELD_IDX_T A_RetAnaDetailed_MeanCapital             = 13;
FIELD_IDX_T A_RetAnaDetailed_Rtn                     = 14;
FIELD_IDX_T A_RetAnaDetailed_TaxCredit               = 15;
FIELD_IDX_T A_RetAnaDetailed_DeltaNetGross           = 16;
FIELD_IDX_T A_RetAnaDetailed_Dividend                = 17;
FIELD_IDX_T A_RetAnaDetailed_MeanInvestCap           = 18;
FIELD_IDX_T A_RetAnaDetailed_Rtn1                    = 19;
FIELD_IDX_T A_RetAnaDetailed_Adjust                  = 20; /* REF9125 - LJE - 030818 */
FIELD_IDX_T A_RetAnaDetailed_RtnGross                = 21; /* REF9125 - LJE - 030818 */
FIELD_IDX_T	A_RetAnaDetailed_Income1M                = 22;
FIELD_IDX_T	A_RetAnaDetailed_Income2M                = 23;
FIELD_IDX_T	A_RetAnaDetailed_CapPl1M                 = 24;
FIELD_IDX_T	A_RetAnaDetailed_CapPl2M                 = 25;
FIELD_IDX_T	A_RetAnaDetailed_CurrPl1M                = 26;
FIELD_IDX_T	A_RetAnaDetailed_CurrPl2M                = 27;
FIELD_IDX_T	A_RetAnaDetailed_CapEffect               = 28;
FIELD_IDX_T	A_RetAnaDetailed_CurrEffect              = 29;
FIELD_IDX_T	A_RetAnaDetailed_FeesTaxEffect           = 30;
FIELD_IDX_T	A_RetAnaDetailed_IncomeEffect            = 31;


FIELD_IDX_T A_RetAnaGlobal_Id                        = 0;
FIELD_IDX_T A_RetAnaGlobal_TaxCredit                 = 1;
FIELD_IDX_T A_RetAnaGlobal_DeltaNetGross             = 2;
FIELD_IDX_T A_RetAnaGlobal_Dividend                  = 3;
FIELD_IDX_T A_RetAnaGlobal_MeanInvestCap             = 4;
FIELD_IDX_T A_RetAnaGlobal_Rtn1                      = 5;
FIELD_IDX_T A_RetAnaGlobal_Invest                    = 6;
FIELD_IDX_T A_RetAnaGlobal_Withdr                    = 7;
FIELD_IDX_T A_RetAnaGlobal_Inc1                      = 8;
FIELD_IDX_T A_RetAnaGlobal_Inc2                      = 9;
FIELD_IDX_T A_RetAnaGlobal_CapPl1                    = 10;
FIELD_IDX_T A_RetAnaGlobal_CapPl2                    = 11;
FIELD_IDX_T A_RetAnaGlobal_CurrPl1                   = 12;
FIELD_IDX_T A_RetAnaGlobal_CurrPl2                   = 13;
FIELD_IDX_T A_RetAnaGlobal_Rtn2                      = 14;
FIELD_IDX_T A_RetAnaGlobal_Rtn3                      = 15;
FIELD_IDX_T A_RetAnaGlobal_CapEffect                 = 16;
FIELD_IDX_T A_RetAnaGlobal_CurrEffect                = 17;
FIELD_IDX_T A_RetAnaGlobal_FeesTaxEffect             = 18;
FIELD_IDX_T A_RetAnaGlobal_IncEffect                 = 19;
FIELD_IDX_T A_RetAnaGlobal_Adjust                    = 20; /*REF9743-BRO-040206*/


FIELD_IDX_T A_RetAnalysisId_Id                       = 0;

FIELD_IDX_T S_RetAnalysisId_Id                       = 0;
FIELD_IDX_T S_RetAnalysisId_BlockSize                = 1;
FIELD_IDX_T S_RetAnalysisId_IdentityResSize          = 2;

FIELD_IDX_T S_ExtOrderBlockId_Id					 = 0; /* PMSTA-46001 - AAKASH - 161221*/
FIELD_IDX_T S_ExtOrderBlockId_BlockSize				 = 1;
FIELD_IDX_T S_ExtOrderBlockId_IdentityResSize		 = 2;


FIELD_IDX_T A_ReturnGridLnk_GridId                   = 0;
FIELD_IDX_T A_ReturnGridLnk_EntDictId                = 1;
FIELD_IDX_T A_ReturnGridLnk_ObjId                    = 2;
FIELD_IDX_T A_ReturnGridLnk_NatEn                    = 3;


FIELD_IDX_T S_ReturnGridLnk_GridId                   = 0;
FIELD_IDX_T S_ReturnGridLnk_EntDictId                = 1;
FIELD_IDX_T S_ReturnGridLnk_ObjId                    = 2;
FIELD_IDX_T S_ReturnGridLnk_GridCd                   = 3;
FIELD_IDX_T S_ReturnGridLnk_NatEn                    = 4;


FIELD_IDX_T A_RiskRatio_AMean                        = 0;
FIELD_IDX_T A_RiskRatio_GMean                        = 1;
FIELD_IDX_T A_RiskRatio_Volatility                   = 2;
FIELD_IDX_T A_RiskRatio_Min                          = 3;
FIELD_IDX_T A_RiskRatio_Max                          = 4;
FIELD_IDX_T A_RiskRatio_BenchAMean                   = 5;
FIELD_IDX_T A_RiskRatio_BenchGMean                   = 6;
FIELD_IDX_T A_RiskRatio_BenchVolat                   = 7;
FIELD_IDX_T A_RiskRatio_BenchMin                     = 8;
FIELD_IDX_T A_RiskRatio_BenchMax                     = 9;
FIELD_IDX_T A_RiskRatio_RFAMean                      = 10;
FIELD_IDX_T A_RiskRatio_RFGMean                      = 11;
FIELD_IDX_T A_RiskRatio_RFVolat                      = 12;
FIELD_IDX_T A_RiskRatio_RFMin                        = 13;
FIELD_IDX_T A_RiskRatio_RFMax                        = 14;
FIELD_IDX_T A_RiskRatio_Sharpe                       = 15;
FIELD_IDX_T A_RiskRatio_BenchSharpe                  = 16;
FIELD_IDX_T A_RiskRatio_Beta                         = 17;
FIELD_IDX_T A_RiskRatio_Treynor                      = 18;
FIELD_IDX_T A_RiskRatio_Jensen                       = 19;
FIELD_IDX_T A_RiskRatio_ExcessReturn                 = 20;
FIELD_IDX_T A_RiskRatio_TrackingError                = 21;
FIELD_IDX_T A_RiskRatio_InformationRatio             = 22;


FIELD_IDX_T A_RuleCompo_RuleId                       = 0;
FIELD_IDX_T A_RuleCompo_AttribDictId                 = 1;


FIELD_IDX_T S_RuleCompo_RuleId                       = 0;
FIELD_IDX_T S_RuleCompo_AttribDictId                 = 1;
FIELD_IDX_T S_RuleCompo_EntSqlName                   = 2;
FIELD_IDX_T S_RuleCompo_AttribSqlName                = 3;


FIELD_IDX_T A_Scena_Id                               = 0;
FIELD_IDX_T A_Scena_Cd                               = 1;
FIELD_IDX_T A_Scena_Name                             = 2;


FIELD_IDX_T S_Scena_Id                               = 0;
FIELD_IDX_T S_Scena_Cd                               = 1;
FIELD_IDX_T S_Scena_Name                             = 2;


FIELD_IDX_T A_ScenaCompo_ParScenaId                  = 0;
FIELD_IDX_T A_ScenaCompo_ChildScenaId                = 1;
FIELD_IDX_T A_ScenaCompo_WgtPrct                     = 2;


FIELD_IDX_T S_ScenaCompo_ParScenaId                  = 0;
FIELD_IDX_T S_ScenaCompo_ChildScenaId                = 1;
FIELD_IDX_T S_ScenaCompo_WgtPrct                     = 2;
FIELD_IDX_T S_ScenaCompo_ParScenaCd                  = 3;


FIELD_IDX_T A_ScenaElt_ScenaId                       = 0;
FIELD_IDX_T A_ScenaElt_DictId                        = 1;
FIELD_IDX_T A_ScenaElt_ObjId                         = 2;
FIELD_IDX_T A_ScenaElt_ValidDate                     = 3;
FIELD_IDX_T A_ScenaElt_NatEn                         = 4;
FIELD_IDX_T A_ScenaElt_Val                           = 5;
FIELD_IDX_T A_ScenaElt_GrowthPrct                    = 6;


FIELD_IDX_T S_ScenaElt_ScenaId                       = 0;


FIELD_IDX_T A_ScreenProf_Id                          = 0;
FIELD_IDX_T A_ScreenProf_Cd                          = 1;


FIELD_IDX_T S_ScreenProf_Id                          = 0;
FIELD_IDX_T S_ScreenProf_Cd                          = 1;


FIELD_IDX_T A_ScreenProfCompo_ScreenProfId           = 0;
FIELD_IDX_T A_ScreenProfCompo_EntDictId              = 1;
FIELD_IDX_T A_ScreenProfCompo_NatAttrDictId          = 2;
FIELD_IDX_T A_ScreenProfCompo_TpAttrDictId           = 3;
FIELD_IDX_T A_ScreenProfCompo_SubTpAttrDictId        = 4;
FIELD_IDX_T A_ScreenProfCompo_TpId                   = 5;
FIELD_IDX_T A_ScreenProfCompo_SubTpId                = 6;
FIELD_IDX_T A_ScreenProfCompo_NatEn                  = 7;
FIELD_IDX_T A_ScreenProfCompo_ScreenDictId           = 8;
FIELD_IDX_T A_ScreenProfCompo_RuleId                 = 9;
FIELD_IDX_T A_ScreenProfCompo_FctDictId              = 10;
FIELD_IDX_T A_ScreenProfCompo_ReportId               = 11;
FIELD_IDX_T A_ScreenProfCompo_Rank                   = 12;


FIELD_IDX_T S_ScreenProfCompo_ScreenProfId           = 0;
FIELD_IDX_T S_ScreenProfCompo_EntDictId              = 1;
FIELD_IDX_T S_ScreenProfCompo_NatAttrDictId          = 2;
FIELD_IDX_T S_ScreenProfCompo_TpAttrDictId           = 3;
FIELD_IDX_T S_ScreenProfCompo_SubTpAttrDictId        = 4;
FIELD_IDX_T S_ScreenProfCompo_TpId                   = 5;
FIELD_IDX_T S_ScreenProfCompo_SubTpId                = 6;
FIELD_IDX_T S_ScreenProfCompo_NatEn                  = 7;
FIELD_IDX_T S_ScreenProfCompo_ScreenDictId           = 8;
FIELD_IDX_T S_ScreenProfCompo_FctDictId              = 9;
FIELD_IDX_T S_ScreenProfCompo_ReportId               = 10;
FIELD_IDX_T S_ScreenProfCompo_EntSqlName             = 11;
FIELD_IDX_T S_ScreenProfCompo_TpAttrName             = 12;
FIELD_IDX_T S_ScreenProfCompo_SubTpAttrName          = 13;
FIELD_IDX_T S_ScreenProfCompo_NatAttrName            = 14;
FIELD_IDX_T S_ScreenProfCompo_TpCd                   = 15;
FIELD_IDX_T S_ScreenProfCompo_SubTpCd                = 16;
FIELD_IDX_T S_ScreenProfCompo_ScreenName             = 17;
FIELD_IDX_T S_ScreenProfCompo_Denom                  = 18;
FIELD_IDX_T S_ScreenProfCompo_FctName                = 19;
FIELD_IDX_T S_ScreenProfCompo_ReportCd               = 20;
FIELD_IDX_T S_ScreenProfCompo_Rank                   = 21;


FIELD_IDX_T A_ScriptDef_Id                           = 0;
FIELD_IDX_T A_ScriptDef_AttrDictId                   = 1;
FIELD_IDX_T A_ScriptDef_ObjId                        = 2;
FIELD_IDX_T A_ScriptDef_NatEn                        = 3;
FIELD_IDX_T A_ScriptDef_Rank                         = 4;
FIELD_IDX_T A_ScriptDef_LastUserId                   = 5;
FIELD_IDX_T A_ScriptDef_LastModifDate                = 6;
FIELD_IDX_T A_ScriptDef_Def                          = 7;
FIELD_IDX_T A_ScriptDef_DimEntityDictId              = 8; /*REF11296-EFE-050714*/
FIELD_IDX_T A_ScriptDef_ScriptEntRefDictId           = 9; /*REF11296-EFE-050714*/
FIELD_IDX_T A_ScriptDef_ActionEn                     = 10; /*REF11296-EFE-050714*/


FIELD_IDX_T S_ScriptDef_Id                           = 0;
FIELD_IDX_T S_ScriptDef_AttrDictId                   = 1;
FIELD_IDX_T S_ScriptDef_ObjId                        = 2;
FIELD_IDX_T S_ScriptDef_NatEn                        = 3;
FIELD_IDX_T S_ScriptDef_Rank                         = 4;
FIELD_IDX_T S_ScriptDef_ActionEn                     = 5;


/*<REF11296-BRO-060406*/
FIELD_IDX_T A_ScriptLibrary_Id						 = 0;
FIELD_IDX_T A_ScriptLibrary_Cd                       = 1;
FIELD_IDX_T A_ScriptLibrary_SqlName                  = 2;
FIELD_IDX_T A_ScriptLibrary_EntDictId                = 3;
FIELD_IDX_T A_ScriptLibrary_Denom                    = 4;
FIELD_IDX_T A_ScriptLibrary_NatEn                    = 5;


FIELD_IDX_T S_ScriptLibrary_Id						 = 0;
FIELD_IDX_T S_ScriptLibrary_Cd						 = 1;
FIELD_IDX_T S_ScriptLibrary_SqlName					 = 2;
FIELD_IDX_T S_ScriptLibrary_EntSqlName				 = 3;
/*>REF11296-BRO-060406*/


FIELD_IDX_T A_Sect_Id                                = 0;
FIELD_IDX_T A_Sect_Cd                                = 1;
FIELD_IDX_T A_Sect_Name                              = 2;
FIELD_IDX_T A_Sect_Denom                             = 3;
FIELD_IDX_T A_Sect_CodifId                           = 4;
FIELD_IDX_T A_Sect_ParSectId                         = 5;
FIELD_IDX_T A_Sect_AutoCreatedFlg                    = 6;


FIELD_IDX_T S_Sect_Id                                = 0;
FIELD_IDX_T S_Sect_CodifCd                           = 1;
FIELD_IDX_T S_Sect_Cd                                = 2;
FIELD_IDX_T S_Sect_Name                              = 3;
FIELD_IDX_T S_Sect_ParSectCd                         = 4;
FIELD_IDX_T S_Sect_CodifId                           = 5;
FIELD_IDX_T S_Sect_SynCodifId                        = 6;


/*  FIH-REF9789-031222  */
FIELD_IDX_T A_SearchCrit_Id                          = 0;
FIELD_IDX_T A_SearchCrit_Cd                          = 1;
FIELD_IDX_T A_SearchCrit_FuncDictId                  = 2;
FIELD_IDX_T A_SearchCrit_EntDictId                   = 3;


FIELD_IDX_T S_SearchCrit_Id                          = 0;
FIELD_IDX_T S_SearchCrit_Cd                          = 1;
FIELD_IDX_T S_SearchCrit_FuncDictId                  = 2;
FIELD_IDX_T S_SearchCrit_EntDictId                   = 3;
FIELD_IDX_T S_SearchCrit_EntSqlName                  = 4;
FIELD_IDX_T S_SearchCrit_FctName                     = 5;


/*  FIH-REF9789-031222  */
FIELD_IDX_T A_SearchCritCompo_Id                     = 0;
FIELD_IDX_T A_SearchCritCompo_SearchCritId           = 1;
FIELD_IDX_T A_SearchCritCompo_AttrDictId             = 2;
FIELD_IDX_T A_SearchCritCompo_TpId                   = 3;
FIELD_IDX_T A_SearchCritCompo_MandatoryFlg           = 4;
FIELD_IDX_T A_SearchCritCompo_Rank                   = 5;
FIELD_IDX_T A_SearchCritCompo_SearchNatEn            = 6; /*REF9764-BRO-040209*/
FIELD_IDX_T A_SearchCritCompo_DefOperatorEn          = 7; /*REF9764-BRO-040209*/
FIELD_IDX_T A_SearchCritCompo_ModifiableFlg          = 8; /*REF10294-BRO-040921*/



FIELD_IDX_T S_SearchCritCompo_Id                     = 0;
FIELD_IDX_T S_SearchCritCompo_SearchCritId           = 1;
FIELD_IDX_T S_SearchCritCompo_AttrDictId             = 2;
FIELD_IDX_T S_SearchCritCompo_TpId                   = 3;
FIELD_IDX_T S_SearchCritCompo_MandatoryFlg           = 4;
FIELD_IDX_T S_SearchCritCompo_Rank                   = 5;
FIELD_IDX_T S_SearchCritCompo_SearchNatEn            = 6; /*REF9764-BRO-040209*/
FIELD_IDX_T S_SearchCritCompo_DefOperatorEn          = 7; /*REF9764-BRO-040209*/
FIELD_IDX_T S_SearchCritCompo_ModifiableFlg          = 8; /*  FPL-REF10294-040929 */
FIELD_IDX_T S_SearchCritCompo_AttrName               = 9;
FIELD_IDX_T S_SearchCritCompo_TpCd                   = 10;

FIELD_IDX_T O_SearchCritCompo_Id                     = 0;
FIELD_IDX_T O_SearchCritCompo_SearchCritId           = 1;
FIELD_IDX_T O_SearchCritCompo_AttrSqlName            = 2;
FIELD_IDX_T O_SearchCritCompo_AttrDictId             = 3;
FIELD_IDX_T O_SearchCritCompo_TpId                   = 4;
FIELD_IDX_T O_SearchCritCompo_TpCd                   = 5;
FIELD_IDX_T O_SearchCritCompo_MandatoryFlg           = 6;
FIELD_IDX_T O_SearchCritCompo_Rank                   = 7;
FIELD_IDX_T O_SearchCritCompo_SearchNatEn            = 8;
FIELD_IDX_T O_SearchCritCompo_DefOperatorEn          = 9;
FIELD_IDX_T O_SearchCritCompo_ModifiableFlg          =10;

/*  FIH-REF9789-031222  */
FIELD_IDX_T A_SearchProf_Id                          = 0;
FIELD_IDX_T A_SearchProf_Cd                          = 1;
FIELD_IDX_T A_SearchProf_FullSearchFlg               = 2;


FIELD_IDX_T S_SearchProf_Id                          = 0;
FIELD_IDX_T S_SearchProf_Cd                          = 1;
FIELD_IDX_T S_SearchProf_FullSearchFlg               = 2;


/*  FIH-REF9789-031222  */
FIELD_IDX_T A_SearchProfCompo_Id                     = 0;
FIELD_IDX_T A_SearchProfCompo_SearchProfId           = 1;
FIELD_IDX_T A_SearchProfCompo_SearchCritId           = 2;
FIELD_IDX_T A_SearchProfCompo_FullSearchFlg          = 3;
FIELD_IDX_T A_SearchProfCompo_SearchCritCd           = 4;
FIELD_IDX_T A_SearchProfCompo_SearchCritEntDictId    = 5;
FIELD_IDX_T A_SearchProfCompo_SearchCritFuncDictId   = 6;


FIELD_IDX_T S_SearchProfCompo_Id                     = 0;
FIELD_IDX_T S_SearchProfCompo_SearchProfId           = 1;
FIELD_IDX_T S_SearchProfCompo_SearchCritId           = 2;
FIELD_IDX_T S_SearchProfCompo_FullSearchFlg          = 3;
FIELD_IDX_T S_SearchProfCompo_SearchCritCd           = 4;
FIELD_IDX_T S_SearchProfCompo_SearchCritEntDictId    = 5;
FIELD_IDX_T S_SearchProfCompo_SearchCritFuncDictId   = 6;
FIELD_IDX_T S_SearchProfCompo_SearchCritEntSqlName   = 7;
FIELD_IDX_T S_SearchProfCompo_SearchCritFctName      = 8;

/* PMSTA-15655 - LJE - 130121 */
FIELD_IDX_T A_SelSearchCritCompoArg_CommandEn    =  0;
FIELD_IDX_T A_SelSearchCritCompoArg_FctDictId    =  1;
FIELD_IDX_T A_SelSearchCritCompoArg_FctProcName  =  2;
FIELD_IDX_T A_SelSearchCritCompoArg_EntDictId    =  3;
FIELD_IDX_T A_SelSearchCritCompoArg_EntSqlName   =  4;
FIELD_IDX_T A_SelSearchCritCompoArg_OutputParam  =  6;
FIELD_IDX_T A_SelSearchCritCompoArg_UserId       =  7;
FIELD_IDX_T A_SelSearchCritCompoArg_LangDictId   =  8;
FIELD_IDX_T A_SelSearchCritCompoArg_SearchProfId =  9;
FIELD_IDX_T A_SelSearchCritCompoArg_FullSearchFlg= 10;
FIELD_IDX_T A_SelSearchCritCompoArg_SearchCritId = 11;
FIELD_IDX_T A_SelSearchCritCompoArg_ApplSessionCd= 12; /* PMSTA-22549 - CHU - 160512 */

/*  HFI-PMSTA-35838-190515  */
FIELD_IDX_T A_SelFctSecuProfCompoArg_ApplSessionCd   = 0;
FIELD_IDX_T A_SelFctSecuProfCompoArg_FctProcName     = 1;
FIELD_IDX_T A_SelFctSecuProfCompoArg_ParFctProcName  = 2;
FIELD_IDX_T A_SelFctSecuProfCompoArg_AuthOnlyFlag    = 3;

FIELD_IDX_T A_SectAttr_EntDictId                     = 0;
FIELD_IDX_T A_SectAttr_ObjId                         = 1;
FIELD_IDX_T A_SectAttr_CodifId                       = 2;
FIELD_IDX_T A_SectAttr_ValidDt                       = 3;
FIELD_IDX_T A_SectAttr_SectId                        = 4;


FIELD_IDX_T S_SectAttr_EntDictId                     = 0;
FIELD_IDX_T S_SectAttr_ObjId                         = 1;
FIELD_IDX_T S_SectAttr_CodifId                       = 2;
FIELD_IDX_T S_SectAttr_ValidDt                       = 3;
FIELD_IDX_T S_SectAttr_CodifCd                       = 4;
FIELD_IDX_T S_SectAttr_SectCd                        = 5;
FIELD_IDX_T S_SectAttr_SectName                      = 6;


FIELD_IDX_T A_ShareOpInfo_PtfId                      = 0;
FIELD_IDX_T A_ShareOpInfo_InstrId                    = 1;
FIELD_IDX_T A_ShareOpInfo_ValDate                    = 2;
FIELD_IDX_T A_ShareOpInfo_ValoSeqNo                  = 3;
FIELD_IDX_T A_ShareOpInfo_Info1Name                  = 4;
FIELD_IDX_T A_ShareOpInfo_Info1Data                  = 5;
FIELD_IDX_T A_ShareOpInfo_Info2Name                  = 6;
FIELD_IDX_T A_ShareOpInfo_Info2Data                  = 7;
FIELD_IDX_T A_ShareOpInfo_Info3Name                  = 8;
FIELD_IDX_T A_ShareOpInfo_Info3Data                  = 9;
FIELD_IDX_T A_ShareOpInfo_Info4Name                  = 10;
FIELD_IDX_T A_ShareOpInfo_Info4Data                  = 11;
FIELD_IDX_T A_ShareOpInfo_Info5Name                  = 12;
FIELD_IDX_T A_ShareOpInfo_Info5Data                  = 13;
FIELD_IDX_T A_ShareOpInfo_Info6Name                  = 14;
FIELD_IDX_T A_ShareOpInfo_Info6Data                  = 15;
FIELD_IDX_T A_ShareOpInfo_Info7Name                  = 16;
FIELD_IDX_T A_ShareOpInfo_Info7Data                  = 17;
FIELD_IDX_T A_ShareOpInfo_Info8Name                  = 18;
FIELD_IDX_T A_ShareOpInfo_Info8Data                  = 19;
FIELD_IDX_T A_ShareOpInfo_Info9Name                  = 20;
FIELD_IDX_T A_ShareOpInfo_Info9Data                  = 21;
FIELD_IDX_T A_ShareOpInfo_Info10Name                 = 22;
FIELD_IDX_T A_ShareOpInfo_Info10Data                 = 23;
FIELD_IDX_T A_ShareOpInfo_Info11Name                 = 24;
FIELD_IDX_T A_ShareOpInfo_Info11Data                 = 25;
FIELD_IDX_T A_ShareOpInfo_Info12Name                 = 26;
FIELD_IDX_T A_ShareOpInfo_Info12Data                 = 27;
FIELD_IDX_T A_ShareOpInfo_Info13Name                 = 28;
FIELD_IDX_T A_ShareOpInfo_Info13Data                 = 29;
FIELD_IDX_T A_ShareOpInfo_Info14Name                 = 30;
FIELD_IDX_T A_ShareOpInfo_Info14Data                 = 31;
FIELD_IDX_T A_ShareOpInfo_Info15Name                 = 32;
FIELD_IDX_T A_ShareOpInfo_Info15Data                 = 33;
FIELD_IDX_T A_ShareOpInfo_Info16Name                 = 34;
FIELD_IDX_T A_ShareOpInfo_Info16Data                 = 35;
FIELD_IDX_T A_ShareOpInfo_EntDictId                  = 36;
FIELD_IDX_T A_ShareOpInfo_Qty                        = 37;


FIELD_IDX_T A_StandardPerf_Id                        = 0;
FIELD_IDX_T A_StandardPerf_PerfStorParamId           = 1;
FIELD_IDX_T A_StandardPerf_EntDictId                 = 2;
FIELD_IDX_T A_StandardPerf_ObjId                     = 3;
FIELD_IDX_T A_StandardPerf_FreqEn                    = 4;
FIELD_IDX_T A_StandardPerf_CurrId                    = 5;
FIELD_IDX_T A_StandardPerf_PosDataId                 = 6;
FIELD_IDX_T A_StandardPerf_GridId                    = 7;
FIELD_IDX_T A_StandardPerf_PerfAttribRtnEn           = 8;
FIELD_IDX_T A_StandardPerf_InitialDate               = 9;
FIELD_IDX_T A_StandardPerf_FinalDate                 = 10;
FIELD_IDX_T A_StandardPerf_InitialMktVal             = 11;
FIELD_IDX_T A_StandardPerf_FinalMktVal               = 12;
FIELD_IDX_T A_StandardPerf_Fees                      = 13;
FIELD_IDX_T A_StandardPerf_Taxes                     = 14;
FIELD_IDX_T A_StandardPerf_Flows                     = 15;
FIELD_IDX_T A_StandardPerf_ProfitLoss                = 16;
FIELD_IDX_T A_StandardPerf_FlowMeanCap               = 17;
FIELD_IDX_T A_StandardPerf_MeanCapital               = 18;
FIELD_IDX_T A_StandardPerf_Rtn                       = 19;
FIELD_IDX_T A_StandardPerf_RtnGross                  = 20; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_StandardPerf_StdDeviation              = 21; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_StandardPerf_NbPtf                     = 22; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_StandardPerf_PortSynthId               = 23;
FIELD_IDX_T A_StandardPerf_ExtStratEltId             = 24;
FIELD_IDX_T A_StandardPerf_StratSynthId              = 25;
FIELD_IDX_T A_StandardPerf_InstrFreqId               = 26;
FIELD_IDX_T A_StandardPerf_PtfFreqId                 = 27;
FIELD_IDX_T A_StandardPerf_RiskFreeId                = 28;
FIELD_IDX_T A_StandardPerf_BenchId                   = 29;
FIELD_IDX_T A_StandardPerf_CompletePeriodFlg         = 30; /* REF9770 - LJE - 031212 */
FIELD_IDX_T A_StandardPerf_RecInfoMask               = 31;
FIELD_IDX_T A_StandardPerf_PreviousId                = 32; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_NextId                    = 33; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_OverPeriodId              = 34; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_ParentObjId               = 0; /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_StandardPerf_MergeParentObjId          = 35;
FIELD_IDX_T A_StandardPerf_RiskFree_Ext              = 37;
FIELD_IDX_T A_StandardPerf_Bench_Ext                 = 38;
FIELD_IDX_T A_StandardPerf_Previous_Ext              = 39; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_Next_Ext                  = 40; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_OverPeriod_Ext            = 41; /* PMSTA07393 - LJE - 081203 */
FIELD_IDX_T A_StandardPerf_ParentObj_Ext             = 0;  /* WEALTH-7754 - DDV - 241024 */
FIELD_IDX_T A_StandardPerf_ObjLnkBreakCriteria       = 42; /* REF9264 - LJE - 030630 */
FIELD_IDX_T A_StandardPerf_BreakCriteria             = 44; /* REF9187 - LJE - 030625 */
FIELD_IDX_T A_StandardPerf_ParentBreakCriteria       = 45; /* REF9344 - LJE - 031014 */
FIELD_IDX_T A_StandardPerf_SubSetBreakCriteria       = 46; /* REF10276 - LJE - 041110 : For optim */
FIELD_IDX_T A_StandardPerf_BenchInitialDate          = 47; /* REF11462 - LJE - 051206 */
FIELD_IDX_T A_StandardPerf_BenchFinalDate            = 48; /* REF11462 - LJE - 051206 */
FIELD_IDX_T A_StandardPerf_PerfCalcResult_Ext        = 49;  /* PMSTA-47578 - LJE - 220404 */
FIELD_IDX_T A_StandardPerf_HeadPtf_Ext               = 50; /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
FIELD_IDX_T A_StandardPerf_RecStatusEn               = 51; /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */


FIELD_IDX_T S_StandardPerf_Id                        = 0;
FIELD_IDX_T S_StandardPerf_PerfStorParamId           = 1;
FIELD_IDX_T S_StandardPerf_EntDictId                 = 2;
FIELD_IDX_T S_StandardPerf_ObjId                     = 3;
FIELD_IDX_T S_StandardPerf_FreqEn                    = 4;
FIELD_IDX_T S_StandardPerf_CurrId                    = 5;
FIELD_IDX_T S_StandardPerf_PosDataId                 = 6;
FIELD_IDX_T S_StandardPerf_GridId                    = 7;
FIELD_IDX_T S_StandardPerf_PerfAttribRtnEn           = 8;
FIELD_IDX_T S_StandardPerf_InitialDate               = 9;
FIELD_IDX_T S_StandardPerf_FinalDate                 = 10;


FIELD_IDX_T A_StdPerfData_Id                         = 0;
FIELD_IDX_T A_StdPerfData_PspId                      = 1;
FIELD_IDX_T A_StdPerfData_InitialDate                = 2;
FIELD_IDX_T A_StdPerfData_FinalDate                  = 3;
FIELD_IDX_T A_StdPerfData_InitialMktVal              = 4;
FIELD_IDX_T A_StdPerfData_FinalMktVal                = 5;
FIELD_IDX_T A_StdPerfData_Fees                       = 6;
FIELD_IDX_T A_StdPerfData_Taxes                      = 7;
FIELD_IDX_T A_StdPerfData_Flows                      = 8;
FIELD_IDX_T A_StdPerfData_ProfitLoss                 = 9;
FIELD_IDX_T A_StdPerfData_FlowMeanCap                = 10;
FIELD_IDX_T A_StdPerfData_MeanCapital                = 11;
FIELD_IDX_T A_StdPerfData_Rtn                        = 12;
/*FIELD_IDX_T A_StdPerfData_Adjust                   = 13; */ /* REF9125 - LJE - 030812 */ /*REF9743-BRO-040206*/
FIELD_IDX_T A_StdPerfData_RtnGross                   = 13; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_StdPerfData_StdDeviation               = 14; /* REF9125 - LJE - 030812 */
FIELD_IDX_T A_StdPerfData_NbPtf                      = 15; /* REF9125 - LJE - 030812 */


/*<PMSTA06761-BRO-080703*/
FIELD_IDX_T A_StandInstruct_Id                       = 0;
FIELD_IDX_T A_StandInstruct_Cd                       = 1;
FIELD_IDX_T A_StandInstruct_Name                     = 2;
FIELD_IDX_T A_StandInstruct_Denom                    = 3;
FIELD_IDX_T A_StandInstruct_PtfId                    = 4;
FIELD_IDX_T A_StandInstruct_BegDate                  = 5;
FIELD_IDX_T A_StandInstruct_EndDate                  = 6;
FIELD_IDX_T A_StandInstruct_StatusEn                 = 7;
FIELD_IDX_T A_StandInstruct_FreqUnitEn               = 8;
FIELD_IDX_T A_StandInstruct_Freq                     = 9;
FIELD_IDX_T A_StandInstruct_OpNatEn                  = 10;
FIELD_IDX_T A_StandInstruct_InstrId                  = 11;
FIELD_IDX_T A_StandInstruct_OpAmt                    = 12;
FIELD_IDX_T A_StandInstruct_OpAmtCurrId              = 13;
FIELD_IDX_T A_StandInstruct_Comment                  = 14;
FIELD_IDX_T A_StandInstruct_LastEvntGenDate          = 15;
FIELD_IDX_T A_StandInstruct_LastUserId               = 16;
FIELD_IDX_T A_StandInstruct_LastModifDate            = 17;
FIELD_IDX_T A_StandInstruct_PlanDefinitionId		 = 18;
FIELD_IDX_T A_StandInstruct_Weight					 = 19;
FIELD_IDX_T A_StandInstruct_MinInvestAmt             = 20;  /* PMSTA-21265 - DDV - 151027 */
FIELD_IDX_T A_StandInstruct_FreqChoiceEn             = 21;
FIELD_IDX_T A_StandInstruct_DaySunFlg                = 22;
FIELD_IDX_T A_StandInstruct_DayMonFlg                = 23;
FIELD_IDX_T A_StandInstruct_DayTueFlg                = 24;
FIELD_IDX_T A_StandInstruct_DayWedFlg                = 25;
FIELD_IDX_T A_StandInstruct_DayThuFlg                = 26;
FIELD_IDX_T A_StandInstruct_DayFriFlg                = 27;
FIELD_IDX_T A_StandInstruct_DaySatFlg                = 28;
FIELD_IDX_T A_StandInstruct_ExecMonth                = 29;
FIELD_IDX_T A_StandInstruct_ExecDay                  = 30;
FIELD_IDX_T A_StandInstruct_ExecUnitEn               = 31;
FIELD_IDX_T A_StandInstruct_ExecUnitRankEn           = 32;
FIELD_IDX_T A_StandInstruct_OrderFeeEn               = 33; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_StandInstruct_OrderFeePct              = 34; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_StandInstruct_OrderFeeCurrId           = 35; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_StandInstruct_OrderFeeAmt              = 36; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_StandInstruct_CalendarId               = 37; /* PMSTA-28684-CHU-171023 */
FIELD_IDX_T A_StandInstruct_PaymentOption            = 38;  /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T A_StandInstruct_CashPtfId                   = 39; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_AccountId                   = 40; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_TypeId                       = 41; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_SubTpId                     = 42; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_ExternalBankAcctOwnrName = 43; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_CounterpartAccount            = 44; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_ExtrnlBnkAcctOwnrAddr1      = 45; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_ExternalBankBic                 = 46; /* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T A_StandInstruct_UpdGenDateFlg                  = 47;
FIELD_IDX_T A_StandInstruct_FlowEvtNbr                        = 48; /* PMSTA-40209 - LIK - 25082020 */


FIELD_IDX_T S_StandInstruct_Id                       = 0;
FIELD_IDX_T S_StandInstruct_Cd                       = 1;
FIELD_IDX_T S_StandInstruct_PtfId                    = 2;
FIELD_IDX_T S_StandInstruct_BegDate                  = 3;
FIELD_IDX_T S_StandInstruct_StatusEn                 = 4;
FIELD_IDX_T S_StandInstruct_PtfCd                    = 5;
/*>PMSTA06761-BRO-080704*/


FIELD_IDX_T A_Stat_Array                             = 0;
FIELD_IDX_T A_Stat_RecNbr                            = 1;
FIELD_IDX_T A_Stat_Mean                              = 2;
FIELD_IDX_T A_Stat_StdDeviation                      = 3;
FIELD_IDX_T A_Stat_StdDeviationEntPop                = 4;
FIELD_IDX_T A_Stat_Variance                          = 5;
FIELD_IDX_T A_Stat_VarianceEntPop                    = 6;
FIELD_IDX_T A_Stat_Median                            = 7;
FIELD_IDX_T A_Stat_Centile                           = 8;
FIELD_IDX_T A_Stat_Min                               = 9;
FIELD_IDX_T A_Stat_Max                               = 10;


FIELD_IDX_T A_StratCompo_Id                          = 0;
FIELD_IDX_T A_StratCompo_StratHistId                 = 1;
FIELD_IDX_T A_StratCompo_EntDictId                   = 2;
FIELD_IDX_T A_StratCompo_ObjId                       = 3;
FIELD_IDX_T A_StratCompo_LinkNatEn                   = 4;
FIELD_IDX_T A_StratCompo_Priority                    = 5;
FIELD_IDX_T A_StratCompo_Weight                      = 6;  /*REF10600-PRO-041103*/
FIELD_IDX_T A_StratCompo_MinBuyAmount                = 7;  /*REF10600-PRO-041103*/
FIELD_IDX_T A_StratCompo_MinBuyPercentage            = 8;  /*REF10600-PRO-041103*/
FIELD_IDX_T A_StratCompo_MinSellAmount               = 9;  /*REF10600-PRO-041103*/
FIELD_IDX_T A_StratCompo_MinSellPercentage           = 10;  /*REF10600-PRO-041103*/
FIELD_IDX_T A_StratCompo_WeightNature_e              = 11; /* REF11810-EFE-060608*/
FIELD_IDX_T A_StratCompo_CriticalnessEn				 = 12; /*PMSTA37310-SPB-171219*/
FIELD_IDX_T A_StratCompo_Margin						 = 13; /*PMSTA37310-SPB-171219*/
FIELD_IDX_T A_StratCompo_MktSegmentId                = 14; /*PMSTA-38428-Vishnu-01012020*/
FIELD_IDX_T A_StratCompo_NoTargetWeightEn            = 15; /*PMSTA-40203-sanand-16072020*/
FIELD_IDX_T A_StratCompo_LowerMarg					 = 16; /*PMSTA-40213-vmuthu-20082020*/
FIELD_IDX_T A_StratCompo_UpperMarg					 = 17; /*PMSTA-40213-vmuthu-20082020*/

FIELD_IDX_T S_StratCompo_Id                          = 0;
FIELD_IDX_T S_StratCompo_StratHistId                 = 1;
FIELD_IDX_T S_StratCompo_EntDictId                   = 2;
FIELD_IDX_T S_StratCompo_ObjId                       = 3;
FIELD_IDX_T S_StratCompo_StratCode                   = 4;
FIELD_IDX_T S_StratCompo_EntDictName                 = 5;
FIELD_IDX_T S_StratCompo_ObjName                     = 6;
FIELD_IDX_T S_StratCompo_LinkNatEn                   = 7;
FIELD_IDX_T S_StratCompo_Priority                    = 8;
FIELD_IDX_T S_StratCompo_WeightNature_e              = 9; /* REF11810-EFE-060608*/
FIELD_IDX_T S_StratCompo_Weight                      = 10;/*PMSTA7387-VST-090219*/


FIELD_IDX_T A_StratElt_Id                            = 0;
FIELD_IDX_T A_StratElt_Denom                         = 1;
FIELD_IDX_T A_StratElt_StratHistId                   = 2;
FIELD_IDX_T A_StratElt_MktSegtId                     = 3;
FIELD_IDX_T A_StratElt_InstrId                       = 4;
FIELD_IDX_T A_StratElt_BenchEntDictId                = 5;
FIELD_IDX_T A_StratElt_BenchObjId                    = 6;
FIELD_IDX_T A_StratElt_HedgeCurrId                   = 7;
FIELD_IDX_T A_StratElt_AnaBenchEntDictId             = 8;
FIELD_IDX_T A_StratElt_AnaBenchObjId                 = 9;
FIELD_IDX_T A_StratElt_Rank                          = 10;
FIELD_IDX_T A_StratElt_NatEn                         = 11;
FIELD_IDX_T A_StratElt_LimitNatEn                    = 12;
FIELD_IDX_T A_StratElt_Value                         = 13;
FIELD_IDX_T A_StratElt_FluctMargin                   = 14;
FIELD_IDX_T A_StratElt_RecomNatEn                    = 15;
FIELD_IDX_T A_StratElt_Priority                      = 16;
FIELD_IDX_T A_StratElt_ConstrTemplate                = 17;
FIELD_IDX_T A_StratElt_CriticalnessEn                = 18; /* REF11231-CHU-050608 */
FIELD_IDX_T A_StratElt_Min                           = 19; /*PMSTA05345-BRO-080219*/
FIELD_IDX_T A_StratElt_Max                           = 20; /*PMSTA05345-BRO-080219*/
/*FIELD_IDX_T A_StratElt_MktSegt_A_StratElt_Ext      = 21; */ /* BSA - PMSTA00183 - 061212 */
FIELD_IDX_T A_StratElt_ObjTrackErr                   = 21; /*PMSTA05345-CHU-080428*/
FIELD_IDX_T A_StratElt_ObjTrackErrMarg               = 22; /*PMSTA05345-CHU-080428*/
FIELD_IDX_T A_StratElt_ActualTrackErr                = 23; /*PMSTA05345-CHU-080428*/
FIELD_IDX_T A_StratElt_EffTrackErr                   = 24; /*PMSTA05345-CHU-080428*/
FIELD_IDX_T A_StratElt_ObjTrackErrCheckEn            = 25; /*PMSTA05345-CHU-080428*/
FIELD_IDX_T A_StratElt_CompChronoNat                 = 26; /*PMSTA05345-CHU-080430*/
FIELD_IDX_T A_StratElt_CompChronoCompNat             = 27; /*PMSTA05345-CHU-080430*/
FIELD_IDX_T A_StratElt_ExcludedFlg                   = 28; /* PMSTA-39969-sanand-05052020 */
FIELD_IDX_T A_StratElt_NoTargetWeightEn              = 29; /* PMSTA-40203-sanand-24062020 */
FIELD_IDX_T A_StratElt_A_ScriptDef_Ext               = 30;
FIELD_IDX_T A_StratElt_ExtStratElt_Id                = 31;
FIELD_IDX_T A_StratElt_OldValue                      = 32;
FIELD_IDX_T A_StratElt_PrimaryFlg                    = 33;
FIELD_IDX_T A_StratElt_TreatedFlg                    = 34;
FIELD_IDX_T A_StratElt_ContribValue                  = 35;
FIELD_IDX_T A_StratElt_WeightFactor                  = 36;
FIELD_IDX_T A_StratElt_VarNbr                        = 37;
FIELD_IDX_T A_StratElt_MinWeightConstr               = 38;
FIELD_IDX_T A_StratElt_MaxWeightConstr               = 39;
FIELD_IDX_T A_StratElt_SubStratFlg                   = 40;
FIELD_IDX_T A_StratElt_Return                        = 41;
FIELD_IDX_T A_StratElt_AbsoluteReturn                = 42;
FIELD_IDX_T A_StratElt_ReturnCurr                    = 43; /* REF9227 - LJE - 030919 */
FIELD_IDX_T A_StratElt_AbsoluteReturnCurr            = 44; /* REF9227 - LJE - 030919 */
FIELD_IDX_T A_StratElt_InstrCodifId                  = 45;
FIELD_IDX_T A_StratElt_DBValue                       = 46; /* REF8286 - CHU - 031002 */
FIELD_IDX_T A_StratElt_RefStratId                    = 47;	/* REF10274 - RAK - 040510 */
FIELD_IDX_T A_StratElt_MktSegtName                   = 48; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_InstrCd					     = 49; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_InstrNatEn					 = 50; /* PMSTA05319 - LJE - 080128 */
FIELD_IDX_T A_StratElt_InstrSubNatEn  		         = 51; /* PMSTA05319 - LJE - 080128 */
FIELD_IDX_T A_StratElt_BenchEntDictSqlName		     = 52; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_BenchObjCd				     = 53; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_HedgeCurrCd				     = 54; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_AnaBenchEntDictSqlName	     = 55; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_AnaBenchObjCd				 = 56; /* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratElt_DynValue 					 = 57; /* REF11457 - RAK - 050928 */
FIELD_IDX_T A_StratElt_PtfIdForMissingPM             = 58; /* REF11559 - CHU - 051123 */
FIELD_IDX_T A_StratElt_ParStratEltId                 = 59; /* PMSTA07813-CHU-090211 */
FIELD_IDX_T A_StratElt_DepthLevel                    = 60; /* PMSTA07813-CHU-090211 */
FIELD_IDX_T A_StratElt_ParMktSgtId                   = 61; /* PMSTA07813-CHU-090211 */
FIELD_IDX_T A_StratElt_FixedCellFlg                  = 62; /* PMSTA07813-CHU-090224 */
FIELD_IDX_T A_StratElt_BlendValue                    = 63; /* PMSTA7387 -SRU-090226 */
FIELD_IDX_T A_StratElt_BlendWeight                   = 64; /* PMSTA7387 -SRU-090226 */
FIELD_IDX_T A_StratElt_MarginNature                  = 65; /* PMSTA7387 -SRU-090319 */
FIELD_IDX_T A_StratElt_EditBackupPtr                 = 66; /*   HFI-PMSTA-13470-120120  Manage OLD() in edit strategy objectives    */
FIELD_IDX_T A_StratElt_CoreSatOrigStratId            = 67; /* PMSTA-18284 - CHU- 140619 */
FIELD_IDX_T A_StratElt_A_HoldConstrScript_Ext        = 68; /* PMSTA-28970 - CHU - 171227 */
FIELD_IDX_T A_StratElt_A_TradConstrScript_Ext        = 69; /* PMSTA-28970 - CHU - 171227 */
FIELD_IDX_T A_StratElt_LowerMarg					 = 70; /* PMSTA-40213 -vmuthu - 20082020 */
FIELD_IDX_T A_StratElt_UpperMarg			         = 71; /* PMSTA-40213 -vmuthu - 20082020 */
FIELD_IDX_T A_StratElt_MinThreshold                  = 72; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_StratElt_MaxThreshold                  = 73; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_StratElt_CashForecastM                 = 74; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_StratElt_MinCashForecastM              = 75; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T A_StratElt_MaxCashForecastM              = 76; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	A_StratElt_QuasiCashEn                   = 77; /* PMSTA-43175-Badhri-21122020 */
FIELD_IDX_T	A_StratElt_InvestLimitAmount             = 78; /* PMSTA-45637-CHANDRU-07072021 */
FIELD_IDX_T	A_StratElt_MinAmount                     = 79; /* PMSTA-45637-CHANDRU-07072021 */
FIELD_IDX_T	A_StratElt_MaxAmount                     = 80; /* PMSTA-45637-CHANDRU-07072021 */
FIELD_IDX_T	A_StratElt_MinThresAmount                = 81; /* PMSTA-45637-CHANDRU-07072021 */
FIELD_IDX_T	A_StratElt_MaxThresAmount                = 82; /* PMSTA-45637-CHANDRU-07072021 */
FIELD_IDX_T	A_StratElt_A_InstrMktsegOverride_Ext	 = 83; /* PMSTA-46842-SENTHIL-10022022 */
FIELD_IDX_T	A_StratElt_OverrideMktSeg_Id			 = 84;
FIELD_IDX_T	A_StratElt_StdMktSeg_Id					 = 85;
FIELD_IDX_T	A_StratElt_StratValSetFlg				 = 86; /* PMSTA-47449-CHANDRU-13052022 */
FIELD_IDX_T A_StratElt_OriginTypeId					 = 87; /* PMSTA-51507 - KKM - 222012 */
FIELD_IDX_T A_StratElt_CaseMgtTypeId                 = 88; /* WEALTH-9979 - KKM - 12072024 */


FIELD_IDX_T S_StratElt_Id                            = 0;
FIELD_IDX_T S_StratElt_Denom                         = 1;
FIELD_IDX_T S_StratElt_StratHistId                   = 2;
FIELD_IDX_T S_StratElt_Rank                          = 3;
FIELD_IDX_T S_StratElt_NatEn                         = 4;
FIELD_IDX_T S_StratElt_Value                         = 5;
FIELD_IDX_T S_StratElt_FluctMargin                   = 6;
FIELD_IDX_T S_StratElt_LimitNatEn                    = 7;
FIELD_IDX_T S_StratElt_RecomNatEn                    = 8;
FIELD_IDX_T S_StratElt_MktSegId                      = 9;
FIELD_IDX_T S_StratElt_InstrId                       = 10;
FIELD_IDX_T S_StratElt_CompChronoNat                 = 11;
FIELD_IDX_T S_StratElt_InstrCd                       = 12;
FIELD_IDX_T S_StratElt_InstrName                     = 13;
FIELD_IDX_T S_StratElt_StratId                       = 14;
FIELD_IDX_T S_StratElt_NoMktSgtFlg                   = 15;
FIELD_IDX_T S_StratElt_LowerMarg					 = 16; /* PMSTA-40213 -vmuthu - 20082020 */
FIELD_IDX_T S_StratElt_UpperMarg			         = 17; /* PMSTA-40213 -vmuthu - 20082020 */

/* PMSTA08747-CHU-091112 */
FIELD_IDX_T A_VarStratElt_Id                         = 0;
FIELD_IDX_T A_VarStratElt_StratId                    = 1;
FIELD_IDX_T A_VarStratElt_StratEltId                 = 2;
FIELD_IDX_T A_VarStratElt_PtfId                      = 3;
FIELD_IDX_T A_VarStratElt_MktSgtId                   = 4;
FIELD_IDX_T A_VarStratElt_MktSgtName                 = 5;
FIELD_IDX_T A_VarStratElt_InstrId                    = 6;
FIELD_IDX_T A_VarStratElt_InstrCd                    = 7;
FIELD_IDX_T A_VarStratElt_ParMktSgtId                = 8;
FIELD_IDX_T A_VarStratElt_ParMktSgtName              = 9;
FIELD_IDX_T A_VarStratElt_ParentId                   = 10;
FIELD_IDX_T A_VarStratElt_ActualWeight               = 11;
FIELD_IDX_T A_VarStratElt_AbsoluteWeight             = 12;
FIELD_IDX_T A_VarStratElt_ObjectiveWeight            = 13;
FIELD_IDX_T A_VarStratElt_DerivedWeight              = 14;
FIELD_IDX_T A_VarStratElt_ExpectedWeight             = 15;
FIELD_IDX_T A_VarStratElt_TestResultOkFlg            = 16;
FIELD_IDX_T A_VarStratElt_LockedQty                  = 17;
FIELD_IDX_T A_VarStratElt_VarNb                      = 18;
FIELD_IDX_T A_VarStratElt_OldVarNb                   = 19;
FIELD_IDX_T A_VarStratElt_MinWeight                  = 20;
FIELD_IDX_T A_VarStratElt_MaxWeight                  = 21;
FIELD_IDX_T A_VarStratElt_MinOptWeight               = 22;
FIELD_IDX_T A_VarStratElt_MaxOptWeight               = 23;
FIELD_IDX_T A_VarStratElt_MinChkWeight               = 24;
FIELD_IDX_T A_VarStratElt_MaxChkWeight               = 25;
FIELD_IDX_T A_VarStratElt_DataLevel                  = 26;
FIELD_IDX_T A_VarStratElt_CostFlag                   = 27;
FIELD_IDX_T A_VarStratElt_Par_A_VarStratElt_Ext      = 28;
FIELD_IDX_T A_VarStratElt_Child_A_VarStratElt_Ext    = 29;
FIELD_IDX_T A_VarStratElt_FixedCellFlg               = 30;
FIELD_IDX_T A_VarStratElt_ConstrObjectiveWeight      = 31;
FIELD_IDX_T A_VarStratElt_Priority                   = 32;
FIELD_IDX_T A_VarStratElt_OldMktSgtName              = 33;
FIELD_IDX_T A_VarStratElt_StratNatEn				 = 34; /* PMSTA-39045-BADHRI-140220 */
FIELD_IDX_T A_VarStratElt_SubModelFlg				 = 35; /* PMSTA-39045-BADHRI-12042020 */
FIELD_IDX_T A_VarStratElt_ParSubModelStratId		 = 36; /* PMSTA-39045-BADHRI-12042020 */
FIELD_IDX_T A_VarStratElt_NoTargetWeightEn           = 37; /* PMSTA-40203-sanand-20072020 */
FIELD_IDX_T A_VarStratElt_AppliedConstrNatEn         = 38; /* PMSTA-42156-Badhri-21122020 */

FIELD_IDX_T A_StratLnk_Id                            = 0;
FIELD_IDX_T A_StratLnk_StratId                       = 1;
FIELD_IDX_T A_StratLnk_EntDictId                     = 2;
FIELD_IDX_T A_StratLnk_ObjId                         = 3;
FIELD_IDX_T A_StratLnk_DataSecuProfId                = 4;
FIELD_IDX_T A_StratLnk_LnkNatEn                      = 5;
FIELD_IDX_T A_StratLnk_BegDate                       = 6;
FIELD_IDX_T A_StratLnk_EndDate                       = 7;
FIELD_IDX_T A_StratLnk_Priority                      = 8;
FIELD_IDX_T A_StratLnk_DataSecuProf2Id               = 9; /*PMSTA-14309-EFE-120611*/
/* end physical */
FIELD_IDX_T A_StratLnk_FromEntDictId                    ; /* REF9187 - LJE - 030618 */
FIELD_IDX_T A_StratLnk_FromObjId                        ; /* REF9187 - LJE - 030618 */
FIELD_IDX_T A_StratLnk_ToEntDictId                      ; /* REF9187 - LJE - 030618 */
FIELD_IDX_T A_StratLnk_ToObjId                          ; /* REF9187 - LJE - 030618 */
FIELD_IDX_T A_StratLnk_ParStratLnkId                    ; /* REF9187 - LJE - 030618 */
FIELD_IDX_T A_StratLnk_Rank                             ; /* REF9187 - LJE - 030618 */


FIELD_IDX_T S_StratLnk_Id                            =  0;
FIELD_IDX_T S_StratLnk_StratId                       =  1;
FIELD_IDX_T S_StratLnk_LnkObjDictId                  =  2;
FIELD_IDX_T S_StratLnk_ObjId                         =  3;
FIELD_IDX_T S_StratLnk_LnkNatEn                      =  4;
FIELD_IDX_T S_StratLnk_BegDate                       =  5;
FIELD_IDX_T S_StratLnk_EndDate                       =  6;
FIELD_IDX_T S_StratLnk_Priority                      =  7;
FIELD_IDX_T S_StratLnk_DataSecuProfId                =  8; /* PMSTA08114-CHU-090508 */
FIELD_IDX_T S_StratLnk_FromEntDictId                 =  9; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_FromObjId                     = 10; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_ToEntDictId                   = 11; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_ToObjId                       = 12; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_ParStratLnkId                 = 13; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_Rank                          = 14; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_StratCd                       = 15;
FIELD_IDX_T S_StratLnk_StratNatEn                    = 16;
FIELD_IDX_T S_StratLnk_ObjCd                         = 17;
FIELD_IDX_T S_StratLnk_DirectFlg                     = 18;
FIELD_IDX_T S_StratLnk_EnumFlg                       = 19;
FIELD_IDX_T S_StratLnk_PtfId                         = 20;
FIELD_IDX_T S_StratLnk_PtfCd                         = 21;
FIELD_IDX_T S_StratLnk_ListId                        = 22;
FIELD_IDX_T S_StratLnk_ListCd                        = 23;
FIELD_IDX_T S_StratLnk_ParStratId                    = 24;
FIELD_IDX_T S_StratLnk_DimGridDictId                 = 25;
FIELD_IDX_T S_StratLnk_GridObjId                     = 26;
FIELD_IDX_T S_StratLnk_ParGridId                     = 27;
FIELD_IDX_T S_StratLnk_MktSegId                      = 28;
FIELD_IDX_T S_StratLnk_FromEntCd                     = 29; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_FromObjCd                     = 30; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_ToEntCd                       = 31; /* REF9187 - LJE - 030618 */
FIELD_IDX_T S_StratLnk_ToObjCd                       = 32; /* REF9187 - LJE - 030618 */
FIELD_IDX_T	S_StratLnk_CriticalnessEn                = 35; /* PMSTA07121-CHU-081106 */
FIELD_IDX_T S_StratLnk_HeadPtfId                     = 36; /* PMSTA-41153 Vishnu 05082020*/
FIELD_IDX_T S_StratLnk_MandatoryFlg                  = 38;


FIELD_IDX_T A_StratHist_Id                           = 0;
FIELD_IDX_T A_StratHist_Denom                        = 1;
FIELD_IDX_T A_StratHist_StratId                      = 2;
FIELD_IDX_T A_StratHist_BegDate                      = 3;
FIELD_IDX_T A_StratHist_EndDate                      = 4;
FIELD_IDX_T A_StratHist_ApplicDate                   = 5;
FIELD_IDX_T A_StratHist_StratNatEn                   = 6;
FIELD_IDX_T A_StratHist_A_StratElt_Ext               = 7;
FIELD_IDX_T A_StratHist_RefStratId                   = 8;	/* REF10274 - RAK - 040510 */
FIELD_IDX_T A_StratHist_StratCd						 = 10;	/* REF11349 - RAK - 050804 */
FIELD_IDX_T A_StratHist_A_StratCompo_Ext             = 11; /* PMSTA08736 - LJE - 100202 */
FIELD_IDX_T A_StratHist_ParentStratId                = 12; /* PMSTA-10748 - LJE - 110209 */
FIELD_IDX_T A_StratHist_ParentWeight                 = 13; /* PMSTA-10748 - LJE - 110209 */


FIELD_IDX_T S_StratHist_Id                           = 0;
FIELD_IDX_T S_StratHist_Denom                        = 1;
FIELD_IDX_T S_StratHist_StratId                      = 2;
FIELD_IDX_T S_StratHist_BegDate                      = 3;
FIELD_IDX_T S_StratHist_EndDate                      = 4;
FIELD_IDX_T S_StratHist_StratCd                      = 5;
FIELD_IDX_T S_StratHist_StratName                    = 6;
FIELD_IDX_T S_StratHist_StratNatEn                   = 7;
FIELD_IDX_T S_StratHist_DimGridDictId                = 8;
FIELD_IDX_T S_StratHist_GridObjId                    = 9;
FIELD_IDX_T S_StratHist_CurrCd                       = 10;
FIELD_IDX_T S_StratHist_MktSegGridCd                 = 11;
FIELD_IDX_T S_StratHist_MktSegAbsListCd              = 12;
FIELD_IDX_T S_StratHist_MktSegOrdListCd              = 13;
FIELD_IDX_T S_StratHist_BenchTpName                  = 14;
FIELD_IDX_T S_StratHist_BenchObjCd                   = 15;


FIELD_IDX_T A_StratEltDetail_Id                      = 0;

/* PMSTA08737 - LJE - 091105 */
FIELD_IDX_T A_StratSynth_Id                            = 0;
FIELD_IDX_T A_StratSynth_StratId                       = 1;
FIELD_IDX_T A_StratSynth_StratHistId                   = 2;
FIELD_IDX_T A_StratSynth_RefStratId                    = 3;
FIELD_IDX_T A_StratSynth_GridId                        = 4;
FIELD_IDX_T A_StratSynth_MktSegtId                     = 6;
FIELD_IDX_T A_StratSynth_BeginDate                     = 7;
FIELD_IDX_T A_StratSynth_EndDate                       = 8;
FIELD_IDX_T A_StratSynth_InstrId                       = 9;
FIELD_IDX_T A_StratSynth_BenchEntDictId                = 10;
FIELD_IDX_T A_StratSynth_BenchObjId                    = 11;
FIELD_IDX_T A_StratSynth_Weight                        = 12;
FIELD_IDX_T A_StratSynth_Return                        = 13;
FIELD_IDX_T A_StratSynth_ReturnCurr                    = 14;
FIELD_IDX_T A_StratSynth_Dura                          = 15;
FIELD_IDX_T A_StratSynth_OriginalWeight                = 16;
FIELD_IDX_T A_StratSynth_RebalDate                     = 17;
FIELD_IDX_T A_StratSynth_RebalReturn                   = 18;
FIELD_IDX_T A_StratSynth_SubPeriodMask                 = 19;
FIELD_IDX_T A_StratSynth_ParentId                      = 20;
FIELD_IDX_T A_StratSynth_GlobalId                      = 21;
FIELD_IDX_T A_StratSynth_RefBeginDate                  = 22;
FIELD_IDX_T A_StratSynth_RefEndDate                    = 23;
FIELD_IDX_T A_StratSynth_Parent_Ext                    = 24;
FIELD_IDX_T A_StratSynth_Children_Ext                  = 25;
FIELD_IDX_T A_StratSynth_Global_Ext                    = 26;


FIELD_IDX_T A_TabCnt_Id                              = 0;
FIELD_IDX_T A_TabCnt_Cd                              = 1;
FIELD_IDX_T A_TabCnt_Denom                           = 2;
FIELD_IDX_T A_TabCnt_TitleMsgId                      = 3;
FIELD_IDX_T A_TabCnt_CntHeadMsgId                    = 4;
FIELD_IDX_T A_TabCnt_PageHeadMsgId                   = 5;
FIELD_IDX_T A_TabCnt_HeadFrameEn                     = 6;
FIELD_IDX_T A_TabCnt_JustifEn                        = 7;
FIELD_IDX_T A_TabCnt_FontEn                          = 8;
FIELD_IDX_T A_TabCnt_FontSz                          = 9;
FIELD_IDX_T A_TabCnt_Thick                           = 10;
FIELD_IDX_T A_TabCnt_TitleJustifEn                   = 11;
FIELD_IDX_T A_TabCnt_TitleFontEn                     = 12;
FIELD_IDX_T A_TabCnt_TitleFontSz                     = 13;
FIELD_IDX_T A_TabCnt_PageColWidth                    = 14;
FIELD_IDX_T A_TabCnt_PageDispFmt                     = 15;
FIELD_IDX_T A_TabCnt_CntColWidth                     = 16;
FIELD_IDX_T A_TabCnt_CntPos                          = 17;
FIELD_IDX_T A_TabCnt_Indent                          = 18;


FIELD_IDX_T S_TabCnt_Id                              = 0;
FIELD_IDX_T S_TabCnt_Cd                              = 1;
FIELD_IDX_T S_TabCnt_Denom                           = 2;


FIELD_IDX_T A_TabModifStat_DictId                    = 0;
FIELD_IDX_T A_TabModifStat_LastModifDate             = 1;
FIELD_IDX_T A_TabModifStat_LastModifDateMs           = 2; /* PMSTA10087 - DDV - 100729 - Returns milliseconds from table_modif_stat */


FIELD_IDX_T S_TabModifStat_DictId                    = 0;


FIELD_IDX_T A_TemplateElt_Id                         = 0;
FIELD_IDX_T A_TemplateElt_ConstrTemplateId           = 1;
FIELD_IDX_T A_TemplateElt_Cd                         = 2;
FIELD_IDX_T A_TemplateElt_ParamNatEn                 = 3;
FIELD_IDX_T A_TemplateElt_SortRank                   = 4;
FIELD_IDX_T A_TemplateElt_Name                       = 5;
FIELD_IDX_T A_TemplateElt_Denom                      = 6;
FIELD_IDX_T A_TemplateElt_DisplayFormat              = 7;
FIELD_IDX_T A_TemplateElt_EntityDictId               = 8;
FIELD_IDX_T A_TemplateElt_AttributeDictId            = 9;
FIELD_IDX_T A_TemplateElt_TypeId                     = 10; /*REF9790-BRO-040206*/
FIELD_IDX_T A_TemplateElt_MandatoryFlg               = 11; /*REF9790-BRO-040206*/


FIELD_IDX_T S_TemplateElt_Id                         = 0;
FIELD_IDX_T S_TemplateElt_ConstrTemplateId           = 1;
FIELD_IDX_T S_TemplateElt_Cd                         = 2;
FIELD_IDX_T S_TemplateElt_ParamNatEn                 = 3;


FIELD_IDX_T Freq_ThirdChrono_ThirdId                 = 0;
FIELD_IDX_T Freq_ThirdChrono_NatEn                   = 1;
FIELD_IDX_T Freq_ThirdChrono_ValidDate               = 2;
FIELD_IDX_T Freq_ThirdChrono_CurrId                  = 3;
FIELD_IDX_T Freq_ThirdChrono_Val                     = 4;
FIELD_IDX_T Freq_ThirdChrono_RequestDate             = 5;


FIELD_IDX_T A_ThirdFreq_FreqDate                     = 0;
FIELD_IDX_T A_ThirdFreq_ThirdId                      = 1;
FIELD_IDX_T A_ThirdFreq_A_Third_Ext                  = 2;


FIELD_IDX_T A_TradingCurrency_Id                     = 0;
FIELD_IDX_T A_TradingCurrency_InstrumentId           = 1;
FIELD_IDX_T A_TradingCurrency_CurrencyId             = 2;
FIELD_IDX_T A_TradingCurrency_MainCurrencyFlg        = 3;


FIELD_IDX_T S_TradingCurrency_Id                     = 0;
FIELD_IDX_T S_TradingCurrency_InstrumentId           = 1;
FIELD_IDX_T S_TradingCurrency_CurrencyId             = 2;
FIELD_IDX_T S_TradingCurrency_InstrumentCd           = 3;
FIELD_IDX_T S_TradingCurrency_CurrencyCd             = 4;


FIELD_IDX_T A_TradingPlace_Id                        = 0;
FIELD_IDX_T A_TradingPlace_InstrumentId              = 1;
FIELD_IDX_T A_TradingPlace_MarketPlaceId             = 2;
FIELD_IDX_T A_TradingPlace_CurrencyId                = 3;
FIELD_IDX_T A_TradingPlace_MainPlaceFlg              = 4;


FIELD_IDX_T S_TradingPlace_Id                        = 0;
FIELD_IDX_T S_TradingPlace_InstrumentId              = 1;
FIELD_IDX_T S_TradingPlace_MarketPlaceId             = 2;
FIELD_IDX_T S_TradingPlace_CurrencyId                = 3;
FIELD_IDX_T S_TradingPlace_CurrencyCd                = 4;
FIELD_IDX_T S_TradingPlace_MarketPlaceCd             = 5;


FIELD_IDX_T A_RiskRule_Id                            = 0;
FIELD_IDX_T A_RiskRule_Cd                            = 1;
FIELD_IDX_T A_RiskRule_Name                          = 2;
FIELD_IDX_T A_RiskRule_Denom                         = 3;

FIELD_IDX_T S_RiskRule_Id                            = 0;
FIELD_IDX_T S_RiskRule_Cd                            = 1;
FIELD_IDX_T S_RiskRule_Name                          = 2;

FIELD_IDX_T A_RiskRuleCompo_Id                       = 0;
FIELD_IDX_T A_RiskRuleCompo_RiskRuleId               = 1;
FIELD_IDX_T A_RiskRuleCompo_Rank                     = 2;
FIELD_IDX_T A_RiskRuleCompo_RuleTypeId               = 3;
FIELD_IDX_T A_RiskRuleCompo_Denom                    = 4;
FIELD_IDX_T A_RiskRuleCompo_ConfidenceLevel          = 5;
FIELD_IDX_T A_RiskRuleCompo_TimeHorizon              = 6;
FIELD_IDX_T A_RiskRuleCompo_TimeHorizonUnitEn        = 7;
FIELD_IDX_T A_RiskRuleCompo_ExtServiceId             = 8;  /* PMSTA-30991 - CHU - 180418 */
FIELD_IDX_T A_RiskRuleCompo_StressTestScenarioTpId   = 9; /* PMSTA-34473 - CHU - 190226 */


FIELD_IDX_T S_RiskRuleCompo_Id                       = 0;
FIELD_IDX_T S_RiskRuleCompo_RiskRuleId               = 1;
FIELD_IDX_T S_RiskRuleCompo_RiskRuleCd               = 2;
FIELD_IDX_T S_RiskRuleCompo_RuleTypeId               = 3;
FIELD_IDX_T S_RiskRuleCompo_RuleTypeCd               = 4;
FIELD_IDX_T S_RiskRuleCompo_Rank                     = 5;
FIELD_IDX_T S_RiskRuleCompo_StressTestScenarionTpId  = 6; /* PMSTA-34473 - CHU - 190226 */
FIELD_IDX_T S_RiskRuleCompo_StressTestScenarionTpCd  = 7; /* PMSTA-34473 - CHU - 190226 */

FIELD_IDX_T A_WarningMsg_NatureEn                    = 0;
FIELD_IDX_T A_WarningMsg_MsgText                     = 1;
FIELD_IDX_T A_WarningMsg_OrderCd                     = 2;
FIELD_IDX_T A_WarningMsg_PtfId                       = 3;
FIELD_IDX_T A_WarningMsg_InstrId                     = 4;
FIELD_IDX_T A_WarningMsg_OperationDate               = 5;
FIELD_IDX_T A_WarningMsg_ExtOpExt                    = 6;


FIELD_IDX_T ExtPos_Id                                = 0;
FIELD_IDX_T ExtPos_PosObjId                          = 1;
FIELD_IDX_T ExtPos_PtfId                             = 2;
FIELD_IDX_T ExtPos_PtfPosSetId                       = 3;
FIELD_IDX_T ExtPos_InstrId                           = 4;
FIELD_IDX_T ExtPos_DepoId                            = 5;
FIELD_IDX_T ExtPos_BalPosTpId                        = 6;
FIELD_IDX_T ExtPos_PosCurrId                         = 7;
FIELD_IDX_T ExtPos_InstrCurrId                       = 8;
FIELD_IDX_T ExtPos_RefCurrId                         = 9;
FIELD_IDX_T ExtPos_CntPtyThirdId                     = 10;
FIELD_IDX_T ExtPos_OpenOpId                          = 11;
FIELD_IDX_T ExtPos_CloseOpId                         = 12;
FIELD_IDX_T ExtPos_TermTpId                          = 13;
FIELD_IDX_T ExtPos_LockTpId                          = 14;
FIELD_IDX_T ExtPos_MainExtPosId                      = 15;
FIELD_IDX_T ExtPos_AcctExtPosId                      = 16;
FIELD_IDX_T ExtPos_AdjustExtPosId                    = 17;
FIELD_IDX_T ExtPos_PosValId                          = 18;
FIELD_IDX_T ExtPos_RiskParInstrId                    = 19;
FIELD_IDX_T ExtPos_RiskOriginExtPosId                = 20;
FIELD_IDX_T ExtPos_ValRuleEltId                      = 21;
FIELD_IDX_T ExtPos_NatEn                             = 22;
FIELD_IDX_T ExtPos_ForecastFlg                       = 23;
FIELD_IDX_T ExtPos_RiskNatEn                         = 24;
FIELD_IDX_T ExtPos_AcctFlg                           = 25;
FIELD_IDX_T ExtPos_Proba                             = 26;
FIELD_IDX_T ExtPos_OpenOpNatEn                       = 27;
FIELD_IDX_T ExtPos_AdjustNatEn                       = 28;
FIELD_IDX_T ExtPos_OpenOpCd                          = 29;
FIELD_IDX_T ExtPos_CloseOpCd                         = 30;
FIELD_IDX_T ExtPos_SrcCd                             = 31;
FIELD_IDX_T ExtPos_RefOpCd                           = 32;
FIELD_IDX_T ExtPos_RefNatEn                          = 33;
FIELD_IDX_T ExtPos_ExecOpCd                          = 34;
FIELD_IDX_T ExtPos_ExecNatEn                         = 35;
FIELD_IDX_T ExtPos_ExecOpStatEn                      = 36;
FIELD_IDX_T ExtPos_RevOpCd                           = 37;
FIELD_IDX_T ExtPos_RevNatEn                          = 38;
FIELD_IDX_T ExtPos_LockOpCd                          = 39;
FIELD_IDX_T ExtPos_LockNatEn                         = 40;
FIELD_IDX_T ExtPos_EvtCd                             = 41;
FIELD_IDX_T ExtPos_EvtNbr                            = 42;
FIELD_IDX_T ExtPos_StatEn                            = 43;
FIELD_IDX_T ExtPos_PrimaryEn                         = 44;
FIELD_IDX_T ExtPos_MainFlg                           = 45;
FIELD_IDX_T ExtPos_PosNatEn                          = 46;
FIELD_IDX_T ExtPos_SubPosNatEn                       = 47;
FIELD_IDX_T ExtPos_SubPosNat2En                      = 48;
FIELD_IDX_T ExtPos_SubPosNat3En                      = 49;
FIELD_IDX_T ExtPos_ExCouponFlg                       = 50;
FIELD_IDX_T ExtPos_Fus                               = 51;
FIELD_IDX_T ExtPos_FusRuleEn                         = 52;
FIELD_IDX_T ExtPos_ExtPosDate                        = 53;
FIELD_IDX_T ExtPos_BegDate                           = 54;
FIELD_IDX_T ExtPos_EndDate                           = 55;
FIELD_IDX_T ExtPos_OpDate                            = 56;
FIELD_IDX_T ExtPos_AcctDate                          = 57;
FIELD_IDX_T ExtPos_ValDate                           = 58;
FIELD_IDX_T ExtPos_LockLimitDate                     = 59;
FIELD_IDX_T ExtPos_ExpirDate                         = 60;
FIELD_IDX_T ExtPos_AccrAmt                           = 61;
FIELD_IDX_T ExtPos_OrderLimitDate                    = 62;
FIELD_IDX_T ExtPos_Remark                            = 63;
FIELD_IDX_T ExtPos_PosExchRate                       = 64;
FIELD_IDX_T ExtPos_InstrExchRate                     = 65;
FIELD_IDX_T ExtPos_SysExchRate                       = 66;
FIELD_IDX_T ExtPos_BookPosExchRate                   = 67;
FIELD_IDX_T ExtPos_BookInstrExchRate                 = 68;
FIELD_IDX_T ExtPos_BookSysExchRate                   = 69;
FIELD_IDX_T ExtPos_Qty                               = 70;
FIELD_IDX_T ExtPos_Price                             = 71;
FIELD_IDX_T ExtPos_SpotPrice                         = 72;
FIELD_IDX_T ExtPos_BookPrice                         = 73;
FIELD_IDX_T ExtPos_PriceCalcRuleEn                   = 74;
FIELD_IDX_T ExtPos_Quote                             = 75;
FIELD_IDX_T ExtPos_SpotQuote                         = 76;
FIELD_IDX_T ExtPos_BookQuote                         = 77;
FIELD_IDX_T ExtPos_Rate                              = 78;
FIELD_IDX_T ExtPos_SupplAmt                          = 79;
FIELD_IDX_T ExtPos_PosGrossAmt                       = 80;
FIELD_IDX_T ExtPos_PosNetAmt                         = 81;
FIELD_IDX_T ExtPos_InstrGrossAmt                     = 82;
FIELD_IDX_T ExtPos_InstrNetAmt                       = 83;
FIELD_IDX_T ExtPos_RefGrossAmt                       = 84;
FIELD_IDX_T ExtPos_RefNetAmt                         = 85;
FIELD_IDX_T ExtPos_SysGrossAmt                       = 86;
FIELD_IDX_T ExtPos_SysNetAmt                         = 87;
FIELD_IDX_T ExtPos_BookPosNetAmt                     = 88;
FIELD_IDX_T ExtPos_BookInstrNetAmt                   = 89;
FIELD_IDX_T ExtPos_BookRefNetAmt                     = 90;
FIELD_IDX_T ExtPos_BookSysNetAmt                     = 91;
FIELD_IDX_T ExtPos_Bp1PosAmt                         = 92;
FIELD_IDX_T ExtPos_Bp2PosAmt                         = 93;
FIELD_IDX_T ExtPos_Bp3PosAmt                         = 94;
FIELD_IDX_T ExtPos_Bp4PosAmt                         = 95;
FIELD_IDX_T ExtPos_Bp5PosAmt                         = 96;
FIELD_IDX_T ExtPos_Bp6PosAmt                         = 97;
FIELD_IDX_T ExtPos_Bp7PosAmt                         = 98;
FIELD_IDX_T ExtPos_Bp8PosAmt                         = 99;
FIELD_IDX_T ExtPos_Bp9PosAmt                         = 100;
FIELD_IDX_T ExtPos_Bp10PosAmt                        = 101;
FIELD_IDX_T ExtPos_HistQuote                         = 102; /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T ExtPos_UnpaidPrct                        = 123; /* PMSTA-16533 - 221113 - PMO */
FIELD_IDX_T ExtPos_CashPortfolioId                   = 104; /* DLA - PMSTA06921 - 081022 / PMSTA-6921 - 311008 - PMO */
FIELD_IDX_T ExtPos_OpPortfolioId                     = 105; /* DLA - PMSTA06921 - 081022 / PMSTA-6921 - 311008 - PMO */
FIELD_IDX_T ExtPos_FundSplitNatEn                    = 106;
FIELD_IDX_T ExtPos_AccrInterExtPosId                 = 107;
FIELD_IDX_T ExtPos_CntPtyExtPosId                    = 108;
FIELD_IDX_T ExtPos_PosDateRuleEn                     = 109;
FIELD_IDX_T ExtPos_InstrExtPosId                     = 110;
FIELD_IDX_T ExtPos_AdjustSecExtPosId                 = 111;
FIELD_IDX_T ExtPos_Acct2ExtPosId                     = 112;
FIELD_IDX_T ExtPos_Acct3ExtPosId                     = 113;
FIELD_IDX_T ExtPos_BVAdjProfitExtPosId               = 114;
FIELD_IDX_T ExtPos_BVAdjLossExtPosId                 = 115;
FIELD_IDX_T ExtPos_LockingExtPosId                   = 116;
FIELD_IDX_T ExtPos_ChildPtfId                        = 117;
FIELD_IDX_T ExtPos_InitExtPosId                      = 118;
FIELD_IDX_T ExtPos_FlowId                            = 119;
FIELD_IDX_T ExtPos_ExecutionId                       = 121;
FIELD_IDX_T ExtPos_GlobalExecutionFeeId              = 122;
FIELD_IDX_T ExtPos_FusStateEn                        = 123;
FIELD_IDX_T ExtPos_AdjTinyInt                        = 124;
FIELD_IDX_T ExtPos_ValueOrBegDate                    = 125;
FIELD_IDX_T ExtPos_InstrNat                          = 126;
FIELD_IDX_T ExtPos_DbStatus                          = 127;
FIELD_IDX_T ExtPos_A_Ptf_Ext                         = 128;
FIELD_IDX_T ExtPos_A_Instr_Ext                       = 129;
FIELD_IDX_T ExtPos_Open_A_Op_Ext                     = 130;
FIELD_IDX_T ExtPos_Close_A_Op_Ext                    = 131;
FIELD_IDX_T ExtPos_Main_ExtPos_Ext                   = 132;
FIELD_IDX_T ExtPos_Acct_ExtPos_Ext                   = 133;
FIELD_IDX_T ExtPos_Adjust_ExtPos_Ext                 = 134;
FIELD_IDX_T ExtPos_BalPos_ExtPos_Ext                 = 135;
FIELD_IDX_T ExtPos_PosVal_Ext                        = 136;
FIELD_IDX_T ExtPos_RefOp_ExtPos_Ext                  = 137;
FIELD_IDX_T ExtPos_ExecOp_ExtPos_Ext                 = 138;
FIELD_IDX_T ExtPos_RevOp_ExtPos_Ext                  = 139;
FIELD_IDX_T ExtPos_LockOp_ExtPos_Ext                 = 140;
FIELD_IDX_T ExtPos_RiskPar_A_Instr_Ext               = 141;
FIELD_IDX_T ExtPos_RiskOrigin_ExtPos_Ext             = 142;
FIELD_IDX_T ExtPos_AccrInter_ExtPos_Ext              = 143;
FIELD_IDX_T ExtPos_CntPty_ExtPos_Ext                 = 144;
FIELD_IDX_T ExtPos_Instr_ExtPos_Ext                  = 145;
FIELD_IDX_T ExtPos_AdjustSec_ExtPos_Ext              = 146;
FIELD_IDX_T ExtPos_A_AccPlanElt_Ext                  = 147;
FIELD_IDX_T ExtPos_Acct2_ExtPos_Ext                  = 148;
FIELD_IDX_T ExtPos_Acct3_ExtPos_Ext                  = 149;
FIELD_IDX_T ExtPos_Attach_ExtPos_Ext                 = 150;
FIELD_IDX_T ExtPos_BVAdjProfit_ExtPos_Ext            = 151;
FIELD_IDX_T ExtPos_BVAdjLoss_ExtPos_Ext              = 152;
FIELD_IDX_T ExtPos_PtfPosSet_Ext                     = 153;
FIELD_IDX_T ExtPos_Locking_ExtPos_Ext                = 154;
FIELD_IDX_T ExtPos_ToInstr_ExtPos_Ext                = 155;
FIELD_IDX_T ExtPos_ToBalPos_ExtPos_Ext               = 156;
FIELD_IDX_T ExtPos_LendingValRuleEltId               = 157;
FIELD_IDX_T ExtPos_ToPtfId                           = 158;
FIELD_IDX_T ExtPos_ChildPtf_Ext                      = 159;
FIELD_IDX_T ExtPos_ExecFlg                           = 160;
FIELD_IDX_T ExtPos_ClosedbyReversedFlg               = 161;
FIELD_IDX_T ExtPos_ExcludeFlg                        = 162;
FIELD_IDX_T ExtPos_DBPrimaryEn                       = 163;
FIELD_IDX_T ExtPos_DataSource                        = 165;
FIELD_IDX_T ExtPos_SortDate                          = 166;
FIELD_IDX_T ExtPos_LogicalId                         = 167; /*REF9751-EFE-050125 used for fusion debug */
FIELD_IDX_T ExtPos_TracedPos                         = 168; /* BSA - REF11817 - 060517 */
FIELD_IDX_T ExtPos_ExtOrderSavedPosition             = 169; /* BSA - PMSTA-1019 - 061130 */
FIELD_IDX_T ExtPos_Acct1IdFus                        = 170; /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T ExtPos_Acct2IdFus                        = 171; /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T ExtPos_HistQuoteQty                      = 172; /* PMSTA-5207 - 050208 - PMO */
FIELD_IDX_T ExtPos_HistQuoteAver                     = 173; /* PMSTA-5207 - 050208 - PMO */
FIELD_IDX_T ExtPos_HistQuoteTransQty                 = 174; /* PMSTA-5207 - 050208 - PMO */
FIELD_IDX_T ExtPos_HistQuoteTransAver                = 175; /* PMSTA-5207 - 050208 - PMO */
FIELD_IDX_T ExtPos_SortCd                            = 176; /* PMSTA-8062 - 190509 - PMO */
FIELD_IDX_T ExtPos_CompoundOrderMasterEltId			 = 177;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtPos_CompoundOrderSlaveEltId			 = 178; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtPos_CompoundOrderCode					 = 179; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtPos_CompoundOrderSlaveNbr				 = 180; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtPos_CompoundImpactRule				 = 181; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtPos_CommonRef                         = 182; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T ExtPos_PosNetIncreaseAmt                 = 183; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosGrossIncreaseAmt               = 184; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosNetDecreaseAmt                 = 185; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosGrossDecreaseAmt               = 186; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosNetIncreaseYearAmt             = 187; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosGrossIncreaseYearAmt           = 188; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosNetDecreaseYearAmt             = 189; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PosGrossDecreaseYearAmt           = 190; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfNetIncreaseAmt                  = 191; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfGrossIncreaseAmt                = 192; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfNetDecreaseAmt                  = 193; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfGrossDecreaseAmt                = 194; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfNetIncreaseYearAmt              = 195; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfGrossIncreaseYearAmt            = 196; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfNetDecreaseYearAmt              = 197; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_PfGrossDecreaseYearAmt            = 198; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_AcquisitionDate                   = 199; /* PMSTA-28286 - JBC - 297699 */
FIELD_IDX_T ExtPos_AcquisitionOpenOpId               = 200; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_TaxLotInitialId                   = 201; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_BpPosExchangeRate                 = 202; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_BpFiExchangeRate                  = 203; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_BpSysExchangeRate                 = 204; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_CorporateActionNatEn              = 205; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_TaxLotSourceCd                    = 206; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtPos_StandInstructId                   = 207; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T ExtPos_DetailFlg                         = 208;
FIELD_IDX_T ExtPos_TaxLot_Ext                        = 209;
FIELD_IDX_T ExtPos_PaymentOption                     = 210; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T ExtPos_AccrIntChronoFlg                  = 211; /*PMSTA-27729 - Smitha - 180115*/
FIELD_IDX_T ExtPos_PaymentDate                       = 212; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtPos_PaymentStatusEn                   = 213; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtPos_SettlementDate                    = 214; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtPos_SettleStatusEn                    = 215; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtPos_LockQuantity                      = 216; /*PMSTA-39162 -NRAO- 03052020*/
FIELD_IDX_T	ExtPos_LinkedInstrId                     = 217;	/* PMSTA - 42330 - CHANDRU - 22102020 */
FIELD_IDX_T ExtPos_IncEvtCurrId                      = 218;
FIELD_IDX_T	ExtPos_BusinessAcquisitionDate           = 219; /* PMSTA-49603 - AIS - 220626 */
FIELD_IDX_T ExtPos_IncEvtBegDate                     = 220;
FIELD_IDX_T ExtPos_IncEvtEndDate                     = 221;
FIELD_IDX_T	ExtPos_FlowInfoEn                        = 222; /* PMSTA-47578 - DDV - 220117 */
FIELD_IDX_T	ExtPos_TimingRuleEn                      = 223; /* PMSTA-47578 - DDV - 220117 */
FIELD_IDX_T ExtPos_OpenOpTpId                        = 224; /* PMSTA-47582 - JBC - 220406 */
FIELD_IDX_T ExtPos_OpenOpSubTpId                     = 225; /* PMSTA-47582 - JBC - 220406 */
FIELD_IDX_T ExtPos_IsProcessed                       = 226; /* WEALTH-15873 - Lalby - 05112024 */

/* PMSTA-31342 - SANAND � 180528 */
FIELD_IDX_T    ExtTaxLot_Id							= 0;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_TaxLotInitialId			= 1;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_OpenOperId					= 2;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_MovementNatEn				= 3;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_OperNatEn					= 4;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_LockNatEn					= 5;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_CorporateActionNatEn		= 6;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_PrimaryEn					= 7;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_BeginDate					= 8;	/* DatetimeType        */
FIELD_IDX_T    ExtTaxLot_EndDate					= 9;	/* DatetimeType        */
FIELD_IDX_T    ExtTaxLot_InstrId					= 10;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_QuoteNum 		  		    = 11;	/* PriceType           */
FIELD_IDX_T    ExtTaxLot_PriceNum					= 12;	/* PriceType           */
FIELD_IDX_T    ExtTaxLot_PriceCalcRuleEn			= 13;	/* EnumType            */
FIELD_IDX_T    ExtTaxLot_QuantityNum                = 14;	/* NumberType          */
FIELD_IDX_T    ExtTaxLot_PosCurrId					= 15;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_PfCurrId					= 16;	/* IdType              */
FIELD_IDX_T    ExtTaxLot_PosGrossAmount 			= 17;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosNetAmount 				= 18;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfGrossAmount 				= 19;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfNetAmount				= 20;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_OpPosGrossAmount			= 21;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_OpPosNetAmount	  	    	= 22;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_OpPfGrossAmount 		    = 23;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_OpPfNetAmount 				= 24;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosPlStGrossAmount 		= 25;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosPlLtGrossAmount     	= 26;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosPlStNetAmount			= 27;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosPlLtNetAmount			= 28;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfPlStGrossAmount			= 29;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfPlLtGrossAmount			= 30;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfPlStNetAmount			= 31;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfPlLtNetAmount			= 32;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosYplStGrossAmount		= 33;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosYplLtGrossAmount		= 34;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosYplStNetAmount			= 35;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PosYplLtNetAmount			= 36;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfYplStGrossAmount  		= 37;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfYplLtGrossAmount	    	= 38;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfYplStNetAmount			= 39;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_PfYplLtNetAmount			= 40;	/* AmountType          */
FIELD_IDX_T    ExtTaxLot_TaxLotId                   = 41;   /* IdType              */
FIELD_IDX_T    ExtTaxLot_ExtPosId                   = 42;   /* IdType              */
FIELD_IDX_T    ExtTaxLot_NatEn                      = 43;	/* EnumType            */

FIELD_IDX_T PosVal_Id                                = 0;
FIELD_IDX_T PosVal_Date                              = 1;
FIELD_IDX_T PosVal_PosId                             = 2;
FIELD_IDX_T PosVal_AccrInterCurrId                   = 3;
FIELD_IDX_T PosVal_TermTpId                          = 4;
FIELD_IDX_T PosVal_PriceThirdId                      = 5;
FIELD_IDX_T PosVal_PriceTpId                         = 6;
FIELD_IDX_T PosVal_PriceCurrId                       = 7;
FIELD_IDX_T PosVal_QuoteDate                         = 8;
FIELD_IDX_T PosVal_Quote                             = 9;
FIELD_IDX_T PosVal_SpotQuote                         = 10;
FIELD_IDX_T PosVal_PriceCalcRuleEn                   = 11;
FIELD_IDX_T PosVal_Price                             = 12;
FIELD_IDX_T PosVal_SpotPrice                         = 13;
FIELD_IDX_T PosVal_ActuRate                          = 14;
FIELD_IDX_T PosVal_PosMktValAmt                      = 15;
FIELD_IDX_T PosVal_PosAccrInterAmt                   = 16;
FIELD_IDX_T PosVal_PosNetAmt                         = 17;
FIELD_IDX_T PosVal_RefMktValAmt                      = 18;
FIELD_IDX_T PosVal_RefAccrInterAmt                   = 19;
FIELD_IDX_T PosVal_RefNetAmt                         = 20;
FIELD_IDX_T PosVal_InstrMktValAmt                    = 21;
FIELD_IDX_T PosVal_InstrAccrInterAmt                 = 22;
FIELD_IDX_T PosVal_InstrNetAmt                       = 23;
FIELD_IDX_T PosVal_AccrInter                         = 24;
FIELD_IDX_T PosVal_AccrInterNumPeriod                = 25;
FIELD_IDX_T PosVal_AccrInterDenomPeriod              = 26;
FIELD_IDX_T PosVal_AccrInterExchRate                 = 27;
FIELD_IDX_T PosVal_PriceExchRate                     = 28;
FIELD_IDX_T PosVal_PosExchRate                       = 29;
FIELD_IDX_T PosVal_InstrExchRate                     = 30;
FIELD_IDX_T PosVal_DebtBaseVal                       = 31;
FIELD_IDX_T PosVal_ExtPosId                          = 32;
FIELD_IDX_T PosVal_DiscFac                           = 33;
FIELD_IDX_T PosVal_ExtPos_Ext                        = 34;


FIELD_IDX_T UnitInter_InstrId                        = 0;
FIELD_IDX_T UnitInter_ValidDate                      = 1;
FIELD_IDX_T UnitInter_ExCouponFlg                    = 2;
FIELD_IDX_T UnitInter_CurrId                         = 3;
FIELD_IDX_T UnitInter_UnitAccrInter                  = 4;
FIELD_IDX_T UnitInter_NumPeriod                      = 5;
FIELD_IDX_T UnitInter_DenomPeriod                    = 6;
FIELD_IDX_T UnitInter_UnitFlg                        = 7;
FIELD_IDX_T UnitInter_InterCalcRuleEn                = 8;
FIELD_IDX_T UnitInter_CalcFlg                        = 9;
FIELD_IDX_T UnitInter_FullCoupFlg                    = 10;
FIELD_IDX_T UnitInter_FusDateRuleEn                  = 11;
FIELD_IDX_T UnitInter_BegDate                        = 12;
FIELD_IDX_T UnitInter_AccrRuleEn                     = 13; /* REF11218 - TEB - 050627 */


FIELD_IDX_T A_Ytm_Ytm                                = 0;
FIELD_IDX_T A_Ytm_RedempDate                         = 1;
FIELD_IDX_T A_Ytm_RedempPrice                        = 2;
FIELD_IDX_T A_Ytm_NatEn                              = 3;


FIELD_IDX_T A_AdvA_Price                             = 0;
FIELD_IDX_T A_AdvA_NPV                               = 1;
FIELD_IDX_T A_AdvA_Dura                              = 2;
FIELD_IDX_T A_AdvA_Conv                              = 3;
FIELD_IDX_T A_AdvA_BPV                               = 4;
FIELD_IDX_T A_AdvA_Delta                             = 5;
FIELD_IDX_T A_AdvA_Delta2                            = 6;
FIELD_IDX_T A_AdvA_Gamma                             = 7;
FIELD_IDX_T A_AdvA_Gamma2                            = 8;
FIELD_IDX_T A_AdvA_GammaMix                          = 9;
FIELD_IDX_T A_AdvA_Vega                              = 10;
FIELD_IDX_T A_AdvA_DVegaDVol                         = 11;
FIELD_IDX_T A_AdvA_DpDc                              = 12;
FIELD_IDX_T A_AdvA_D2pDc2                            = 13;
FIELD_IDX_T A_AdvA_Theta                             = 14;
FIELD_IDX_T A_AdvA_Rho                               = 15;
FIELD_IDX_T A_AdvA_DRhoDr                            = 16;
FIELD_IDX_T A_AdvA_SwapRateSens                      = 17;
FIELD_IDX_T A_AdvA_ZeroYldSens                       = 18;
FIELD_IDX_T A_AdvA_Ctd                               = 19;
FIELD_IDX_T A_AdvA_Dlv_Date                          = 20;
FIELD_IDX_T A_AdvA_Cf                                = 21;
FIELD_IDX_T A_AdvA_DpDivYield                        = 22; /* REF9082 - TEB - 030610 */
FIELD_IDX_T A_AdvA_ImpliedVol                        = 23; /* REF9082 - LJE - 030611 */


FIELD_IDX_T AdvA_Arg_InstrId                         = 0;
FIELD_IDX_T AdvA_Arg_CalendarId                      = 1;
FIELD_IDX_T AdvA_Arg_KeyWordEn                       = 2;
FIELD_IDX_T AdvA_Arg_Date                            = 3;
FIELD_IDX_T AdvA_Arg_Spread                          = 4;
FIELD_IDX_T AdvA_Arg_Shock                           = 5;
FIELD_IDX_T AdvA_Arg_Margin                          = 6;
FIELD_IDX_T AdvA_Arg_Domestic                        = 7;
FIELD_IDX_T AdvA_Arg_MarketCTD                       = 8;
FIELD_IDX_T AdvA_Arg_Black                           = 9;
FIELD_IDX_T AdvA_Arg_Volatility                      = 10;
FIELD_IDX_T AdvA_Arg_Steps                           = 11;
FIELD_IDX_T AdvA_Arg_Flg                             = 12;
FIELD_IDX_T AdvA_Arg_InstrId2                        = 13;
FIELD_IDX_T AdvA_Arg_YieldCurveInstrId               = 14;
FIELD_IDX_T AdvA_Arg_PaidYcInstrId                   = 15;
FIELD_IDX_T AdvA_Arg_FloatingInstrYcId               = 16;
FIELD_IDX_T AdvA_Arg_PaidFloatingInstrYcId           = 17;
FIELD_IDX_T AdvA_Arg_UnderYcInstrId                  = 18;
FIELD_IDX_T AdvA_Arg_CalendarKeyWFlg                 = 19;
FIELD_IDX_T AdvA_Arg_AddMarginPrct                   = 20;
FIELD_IDX_T AdvA_Arg_RefDate                         = 21;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_Rate                            = 22;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_EndDate                         = 23;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_CurrentPrice                    = 24;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_RedemptionPrice                 = 25;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_CouponTaxRate                   = 26;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_CapitalGainTaxRate              = 27;  /* REF9082 - TEB - 030507 */
FIELD_IDX_T AdvA_Arg_PricingModelEn                  = 28;  /* REF9082 - TEB - 030603 */
FIELD_IDX_T AdvA_Arg_SceOutEn                        = 29;  /* REF9082 - TEB - 030604 */
FIELD_IDX_T AdvA_Arg_SensitivityEn                   = 30;  /* REF9082 - TEB - 030610 */
FIELD_IDX_T AdvA_Arg_UnderlyingPrice                 = 31;  /* REF9082 - TEB - 030613 */
FIELD_IDX_T AdvA_Arg_Ytm                             = 32;  /* REF9082 - TEB - 030626 */
FIELD_IDX_T AdvA_Arg_FusDateRuleEn                   = 33;  /* REF9085 - TEB - 030627 */
FIELD_IDX_T AdvA_Arg_YieldTpEn                       = 34;  /* REF10620 - TEB - 041006 */
FIELD_IDX_T AdvA_Arg_AccrRuleEn                      = 35;  /* REF11218 - TEB - 050627 */
FIELD_IDX_T AdvA_Arg_FromDate						 = 36;	/* PMSTA05878 - RAK - 080425 */

FIELD_IDX_T AdvA_Vola_InstrId                        = 0;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_InstrCurrId                    = 1;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_RefDate                        = 2;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_HistoRuleEn                    = 3;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_HistoFreq                      = 4;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_HistoFreqUnitEn                = 5;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_HistoReading                   = 6;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_ForceCalcFlg                   = 7;	/* REF10531 - TEB - 040806 */
FIELD_IDX_T AdvA_Vola_OptioArgFlg                    = 8;	/* REF10531 - TEB - 040806 */


FIELD_IDX_T RiskAmt_Price                            = 0;
FIELD_IDX_T RiskAmt_CompoQty                         = 1;
FIELD_IDX_T RiskAmt_SupplAmt                         = 2;
FIELD_IDX_T RiskAmt_PosGrossAmt                      = 3;
FIELD_IDX_T RiskAmt_PosNetAmt                        = 4;
FIELD_IDX_T RiskAmt_InstrGrossAmt                    = 5;
FIELD_IDX_T RiskAmt_InstrNetAmt                      = 6;
FIELD_IDX_T RiskAmt_RefGrossAmt                      = 7;
FIELD_IDX_T RiskAmt_RefNetAmt                        = 8;
FIELD_IDX_T RiskAmt_SysGrossAmt                      = 9;
FIELD_IDX_T RiskAmt_SysNetAmt                        = 10;
FIELD_IDX_T RiskAmt_Bp1PosAmt                        = 11;
FIELD_IDX_T RiskAmt_Bp2PosAmt                        = 12;
FIELD_IDX_T RiskAmt_Bp3PosAmt                        = 13;
FIELD_IDX_T RiskAmt_Bp4PosAmt                        = 14;
FIELD_IDX_T RiskAmt_Bp5PosAmt                        = 15;
FIELD_IDX_T RiskAmt_Bp6PosAmt                        = 16;
FIELD_IDX_T RiskAmt_Bp7PosAmt                        = 17;
FIELD_IDX_T RiskAmt_Bp8PosAmt                        = 18;
FIELD_IDX_T RiskAmt_Bp9PosAmt                        = 19;
FIELD_IDX_T RiskAmt_Bp10PosAmt                       = 20;
FIELD_IDX_T RiskAmt_PosCurrId                        = 21;
FIELD_IDX_T RiskAmt_PosMktValAmt                     = 22;
FIELD_IDX_T RiskAmt_RefMktValAmt                     = 23;


FIELD_IDX_T Flow_Id                                  = 0;
FIELD_IDX_T Flow_InstrId                             = 1;
FIELD_IDX_T Flow_EvtCd                               = 2;
FIELD_IDX_T Flow_EvtNbr                              = 3;
FIELD_IDX_T Flow_NatEn                               = 4;
FIELD_IDX_T Flow_BegPayDate                          = 5;
FIELD_IDX_T Flow_EndPayDate                          = 6;
FIELD_IDX_T Flow_SettlDays                           = 7;
FIELD_IDX_T Flow_OptimalDate                         = 8;
FIELD_IDX_T Flow_OptimalValDate                      = 9;
FIELD_IDX_T Flow_IoRPrct                             = 10;
FIELD_IDX_T Flow_Quote                               = 11;
FIELD_IDX_T Flow_RefQty                              = 12;
FIELD_IDX_T Flow_AmtUnit                             = 13;
FIELD_IDX_T Flow_AmtCurrId                           = 14;
FIELD_IDX_T Flow_NewInstrId                          = 15;
FIELD_IDX_T Flow_QtyUnit                             = 16;
FIELD_IDX_T Flow_OptClassEn                          = 17;
FIELD_IDX_T Flow_OptStyleEn                          = 18;
FIELD_IDX_T Flow_Proba                               = 19;
FIELD_IDX_T Flow_Yield                               = 20;
FIELD_IDX_T Flow_Freq                                = 21;
FIELD_IDX_T Flow_FreqUnitEn                          = 22;
FIELD_IDX_T Flow_ExDate                              = 23;
FIELD_IDX_T Flow_FxdExchRate                         = 24;
FIELD_IDX_T Flow_CtdConvFact                         = 25;
FIELD_IDX_T Flow_CtdConvRatio                        = 26;
FIELD_IDX_T Flow_CtdInstrId                          = 27;
FIELD_IDX_T Flow_PhysicalFlg                         = 28;
FIELD_IDX_T Flow_Priority                            = 29;
FIELD_IDX_T Flow_EffectiveFlg                        = 30;
FIELD_IDX_T Flow_SubNatEn                            = 31;
FIELD_IDX_T Flow_ReplaceFlg                          = 32;
FIELD_IDX_T Flow_EuroConvRuleEn                      = 33;
FIELD_IDX_T Flow_RoundRuleEn                         = 34;
FIELD_IDX_T Flow_OddLotCompEn                        = 35;
FIELD_IDX_T Flow_RoundLevelEn                        = 36;
FIELD_IDX_T Flow_NewInstrMinDenom                    = 37;
FIELD_IDX_T Flow_DiscountFactor                      = 38;  /* TGU - PMSTA01045 - 070125 */
FIELD_IDX_T Flow_ReceivedAmtUnit					 = 39;	/* TGU - PMSTA01659 - 070307 */
FIELD_IDX_T Flow_PaidAmtUnit						 = 40;	/* TGU - PMSTA01659 - 070307 */
FIELD_IDX_T Flow_ConfirmedFlg                        = 41;
FIELD_IDX_T Flow_StandInstructId                     = 42;  /* PMSTA06761 - DDV - 080805 */
FIELD_IDX_T Flow_DiscFactReceivedInstr               = 43;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_DiscFactPaidInstr                   = 44;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_DiscFactReceivedFloat               = 45;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_DiscFactPaidFloat                   = 46;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_AnnualReceivedRate                  = 47;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_AnnualPaidRate                      = 48;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
FIELD_IDX_T Flow_ExtOp_Ext                           = 49;
FIELD_IDX_T Flow_A_Instr_Ext                         = 50;
FIELD_IDX_T Flow_FilterFlg                           = 51;
FIELD_IDX_T Flow_StatusEn                            = 52;
FIELD_IDX_T Flow_YieldCurveInstrId                   = 53;
FIELD_IDX_T Flow_LinkedInstrId                       = 54; /* PMSTA - 42330 - CHANDRU - 22102020*/
FIELD_IDX_T Flow_TpId                                = 55;



FIELD_IDX_T OpDomain_OpId                            = 0;
FIELD_IDX_T OpDomain_DimPtfDictId                    = 1;
FIELD_IDX_T OpDomain_PtfObjId                        = 2;
FIELD_IDX_T OpDomain_InstrId                         = 3;
FIELD_IDX_T OpDomain_OpNatEn                         = 4;
FIELD_IDX_T OpDomain_TpId                            = 5;
FIELD_IDX_T OpDomain_SubTpId                         = 6;
FIELD_IDX_T OpDomain_Cd                              = 7;
FIELD_IDX_T OpDomain_StatusEn                        = 8;
FIELD_IDX_T OpDomain_SequenceNo                      = 9;
FIELD_IDX_T OpDomain_AcctCd                          = 10;
FIELD_IDX_T OpDomain_ExtOpDbId                       = 11;      /*  FIH-REF9043-030429  */
FIELD_IDX_T OpDomain_DraftOrderId                    = 12;      /* REF8500 - 040510 - PMO */


FIELD_IDX_T BuyOp_Id                                 = 0;
FIELD_IDX_T BuyOp_Cd                                 = 1;
FIELD_IDX_T BuyOp_InputUserId                        = 2;
FIELD_IDX_T BuyOp_TpId                               = 3;
FIELD_IDX_T BuyOp_SubTpId                            = 4;
FIELD_IDX_T BuyOp_MktThirdId                         = 5;
FIELD_IDX_T BuyOp_IntermThirdId                      = 6;
FIELD_IDX_T BuyOp_MgrId                              = 7;
FIELD_IDX_T BuyOp_RuleId                             = 8;
FIELD_IDX_T BuyOp_SrcCd                              = 9;
FIELD_IDX_T BuyOp_SubPosNatEn                        = 10;
FIELD_IDX_T BuyOp_SubPosNat2En                       = 11;
FIELD_IDX_T BuyOp_SubPosNat3En                       = 12;
FIELD_IDX_T BuyOp_LockSubPosNatEn                    = 13;
FIELD_IDX_T BuyOp_LockSubPosNat2En                   = 14;
FIELD_IDX_T BuyOp_LockSubPosNat3En                   = 15;
FIELD_IDX_T BuyOp_LimitQuote                         = 16;
FIELD_IDX_T BuyOp_LimitPrice                         = 17;
FIELD_IDX_T BuyOp_StopQuote                          = 18;
FIELD_IDX_T BuyOp_StopPrice                          = 19;
FIELD_IDX_T BuyOp_OrderPriceNatEn                    = 20;
FIELD_IDX_T BuyOp_OrderValidNatEn                    = 21;
FIELD_IDX_T BuyOp_MinOrderQty                        = 22;
FIELD_IDX_T BuyOp_ParOpCd                            = 23;
FIELD_IDX_T BuyOp_ParOpNatEn                         = 24;
FIELD_IDX_T BuyOp_CheckParentEn                      = 25;
FIELD_IDX_T BuyOp_CheckStratEn                       = 26;
FIELD_IDX_T BuyOp_OrderNatEn                         = 27;
FIELD_IDX_T BuyOp_AcctDate                           = 28;
FIELD_IDX_T BuyOp_OpDate                             = 29;
FIELD_IDX_T BuyOp_OrderLimitDate                     = 30;
FIELD_IDX_T BuyOp_ValueDate                          = 31;
FIELD_IDX_T BuyOp_RefOpCd                            = 32;
FIELD_IDX_T BuyOp_RefNatEn                           = 33;
FIELD_IDX_T BuyOp_StatusEn                           = 34;
FIELD_IDX_T BuyOp_SequenceNo                         = 35;
FIELD_IDX_T BuyOp_AcctCd                             = 36;
FIELD_IDX_T BuyOp_PtfId                              = 37;
FIELD_IDX_T BuyOp_CashPtfId                          = 38;
FIELD_IDX_T BuyOp_InstrId                            = 39;
FIELD_IDX_T BuyOp_AcctId                             = 40;
FIELD_IDX_T BuyOp_Acct2Id                            = 41;
FIELD_IDX_T BuyOp_Acct3Id                            = 42;
FIELD_IDX_T BuyOp_LockInstrId                        = 43;
FIELD_IDX_T BuyOp_DepoId                             = 44;
FIELD_IDX_T BuyOp_LockDepoId                         = 45;
FIELD_IDX_T BuyOp_OpCurrId                           = 46;
FIELD_IDX_T BuyOp_InstrCurrId                        = 47;
FIELD_IDX_T BuyOp_PtfCurrId                          = 48;
FIELD_IDX_T BuyOp_AcctCurrId                         = 49;
FIELD_IDX_T BuyOp_Acct2CurrId                        = 50;
FIELD_IDX_T BuyOp_Acct3CurrId                        = 51;
FIELD_IDX_T BuyOp_TradeCurrId                        = 52;
FIELD_IDX_T BuyOp_CashPtfCurrId                      = 53;
FIELD_IDX_T BuyOp_LockOpCurrId                       = 54;
FIELD_IDX_T BuyOp_LockFiCurrId                       = 55;
FIELD_IDX_T BuyOp_CntPtyThirdId                      = 56;
FIELD_IDX_T BuyOp_TermTpId                           = 57;
FIELD_IDX_T BuyOp_LockTpId                           = 58;
FIELD_IDX_T BuyOp_AccrIntrBpTpId                     = 59;
FIELD_IDX_T BuyOp_ExtOrderId                         = 60;
FIELD_IDX_T BuyOp_OrderCd                            = 61;
FIELD_IDX_T BuyOp_ExecSetCriteria                    = 62;
FIELD_IDX_T BuyOp_ExecOpId                           = 63;
FIELD_IDX_T BuyOp_ExecOpCd                           = 64;
FIELD_IDX_T BuyOp_ExecOpNatEn                        = 65;
FIELD_IDX_T BuyOp_ExecOpStatEn                       = 66;
FIELD_IDX_T BuyOp_RevOpCd                            = 67;
FIELD_IDX_T BuyOp_RevOpNatEn                         = 68;
FIELD_IDX_T BuyOp_LockOpCd                           = 69;
FIELD_IDX_T BuyOp_LockNatEn                          = 70;
FIELD_IDX_T BuyOp_EvtCd                              = 71;
FIELD_IDX_T BuyOp_EvtNbr                             = 72;
FIELD_IDX_T BuyOp_ExCouponFlg                        = 73;
FIELD_IDX_T BuyOp_FusRuleEn                          = 74;
FIELD_IDX_T BuyOp_LockLimitDate                      = 75;
FIELD_IDX_T BuyOp_ExpirDate                          = 76;
FIELD_IDX_T BuyOp_Remark                             = 77;
FIELD_IDX_T BuyOp_OpExchRate                         = 78;
FIELD_IDX_T BuyOp_InstrExchRate                      = 79;
FIELD_IDX_T BuyOp_SysExchRate                        = 80;
FIELD_IDX_T BuyOp_AcctExchRate                       = 81;
FIELD_IDX_T BuyOp_Acct2ExchRate                      = 82;
FIELD_IDX_T BuyOp_Acct3ExchRate                      = 83;
FIELD_IDX_T BuyOp_TradeExchRate                      = 84;
FIELD_IDX_T BuyOp_CashPtfExchRate                    = 85;
FIELD_IDX_T BuyOp_LockOpExchRate                     = 86;
FIELD_IDX_T BuyOp_LockFiExchRate                     = 87;
FIELD_IDX_T BuyOp_Qty                                = 88;
FIELD_IDX_T BuyOp_LockQty                            = 89;
FIELD_IDX_T BuyOp_Price                              = 90;
FIELD_IDX_T BuyOp_SpotPrice                          = 91;
FIELD_IDX_T BuyOp_LockDirtyPrice                     = 92;
FIELD_IDX_T BuyOp_LockCleanPrice                     = 93;
FIELD_IDX_T BuyOp_PriceCalcRuleEn                    = 94;
FIELD_IDX_T BuyOp_Quote                              = 95;
FIELD_IDX_T BuyOp_SpotQuote                          = 96;
FIELD_IDX_T BuyOp_LockDirtyQuote                     = 97;
FIELD_IDX_T BuyOp_LockCleanQuote                     = 98;
FIELD_IDX_T BuyOp_Rate                               = 99;
FIELD_IDX_T BuyOp_LockPriceMargin                    = 100;
FIELD_IDX_T BuyOp_SupplAmt                           = 101;
FIELD_IDX_T BuyOp_OpGrossAmt                         = 102;
FIELD_IDX_T BuyOp_AccrIntrAmt                        = 103;
FIELD_IDX_T BuyOp_OpNetAmt                           = 104;
FIELD_IDX_T BuyOp_InstrNetAmt                        = 105;
FIELD_IDX_T BuyOp_PtfNetAmt                          = 106;
FIELD_IDX_T BuyOp_SysNetAmt                          = 107;
FIELD_IDX_T BuyOp_AcctNetAmt                         = 108;
FIELD_IDX_T BuyOp_Acct2NetAmt                        = 109;
FIELD_IDX_T BuyOp_Acct3NetAmt                        = 110;
FIELD_IDX_T BuyOp_Bp1TpId                            = 111;
FIELD_IDX_T BuyOp_Bp1CurrId                          = 112;
FIELD_IDX_T BuyOp_Bp1Amt                             = 113;
FIELD_IDX_T BuyOp_Bp2TpId                            = 114;
FIELD_IDX_T BuyOp_Bp2CurrId                          = 115;
FIELD_IDX_T BuyOp_Bp2Amt                             = 116;
FIELD_IDX_T BuyOp_Bp3TpId                            = 117;
FIELD_IDX_T BuyOp_Bp3CurrId                          = 118;
FIELD_IDX_T BuyOp_Bp3Amt                             = 119;
FIELD_IDX_T BuyOp_Bp4TpId                            = 120;
FIELD_IDX_T BuyOp_Bp4CurrId                          = 121;
FIELD_IDX_T BuyOp_Bp4Amt                             = 122;
FIELD_IDX_T BuyOp_Bp5TpId                            = 123;
FIELD_IDX_T BuyOp_Bp5CurrId                          = 124;
FIELD_IDX_T BuyOp_Bp5Amt                             = 125;
FIELD_IDX_T BuyOp_Bp6TpId                            = 126;
FIELD_IDX_T BuyOp_Bp6CurrId                          = 127;
FIELD_IDX_T BuyOp_Bp6Amt                             = 128;
FIELD_IDX_T BuyOp_Bp7TpId                            = 129;
FIELD_IDX_T BuyOp_Bp7CurrId                          = 130;
FIELD_IDX_T BuyOp_Bp7Amt                             = 131;
FIELD_IDX_T BuyOp_Bp8TpId                            = 132;
FIELD_IDX_T BuyOp_Bp8CurrId                          = 133;
FIELD_IDX_T BuyOp_Bp8Amt                             = 134;
FIELD_IDX_T BuyOp_Bp9TpId                            = 135;
FIELD_IDX_T BuyOp_Bp9CurrId                          = 136;
FIELD_IDX_T BuyOp_Bp9Amt                             = 137;
FIELD_IDX_T BuyOp_Bp10TpId                           = 138;
FIELD_IDX_T BuyOp_Bp10CurrId                         = 139;
FIELD_IDX_T BuyOp_Bp10Amt                            = 140;
FIELD_IDX_T BuyOp_FlowId                             = 141;
FIELD_IDX_T BuyOp_InitExtPosId                       = 142;
FIELD_IDX_T BuyOp_LastUserId                         = 143;
FIELD_IDX_T BuyOp_LastModifDate                      = 144;
FIELD_IDX_T BuyOp_CreationTime                       = 145;
FIELD_IDX_T BuyOp_SysCurrId                          = 146;
FIELD_IDX_T BuyOp_ConfirmedFlg                       = 147;
FIELD_IDX_T BuyOp_GroupingCriteria                   = 148;
FIELD_IDX_T BuyOp_OrderGroupingCd                    = 149;
FIELD_IDX_T BuyOp_OrderModeTypeId				     = 150; /*<REF11810-BRO-060608*/
FIELD_IDX_T BuyOp_TraderMgrId					     = 151;
FIELD_IDX_T BuyOp_AutoRenewalEn					     = 152;
FIELD_IDX_T BuyOp_RenewalTreatmtEn				     = 153;
FIELD_IDX_T BuyOp_RenewalEndValDate				     = 154;
FIELD_IDX_T BuyOp_RenewalLength					     = 155;
FIELD_IDX_T BuyOp_RenewalLengthUnitEn			     = 156;
FIELD_IDX_T BuyOp_ClientInitEn					     = 157;
FIELD_IDX_T BuyOp_ContractNumber					 = 158;
FIELD_IDX_T BuyOp_TransactionNatEn				     = 159; /*>REF11810-BRO-060608*/
FIELD_IDX_T BuyOp_RenewalIntRate                     = 160; /*REF11810-BRO-060628*/
FIELD_IDX_T BuyOp_RenewalAmount                      = 161; /*REF11810-BRO-060628*/
FIELD_IDX_T BuyOp_TargetNatureEn                     = 162; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_TargetNumber                       = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_TargetAmount                       = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_MarketSegmentId                    = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_FactSheetEn                        = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_LastQuoteDate                      = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_LastQuoteNumber                    = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_LastPriceNumber                    = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_CommunicationDate                  = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_CommunicationTypeId                = 171; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_CommPartyTypeId                    = 172; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BuyOp_Remark1                            = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_Remark2                            = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_Remark3                            = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_TransmissionDate                   = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_TransmissionTypeId                 = 177; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_OrderTypeId                        = 178; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_MMInterestAmount                   = 179; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_FxMarketRate                       = 180; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_FxClientRate                       = 181; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BuyOp_FxRateDirection                    = 182; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BuyOp_InterestMarketRate                 = 183; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_DebitToSysCurrRate                 = 184; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_CreditToSysCurrRate                = 185; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_ContractLengthNumber               = 186; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_ContractLengthUnitEn               = 187; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BuyOp_FxMarginNumber                     = 188; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BuyOp_FxMarginPrct                       = 189; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BuyOp_FxMarginAmount                     = 190; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BuyOp_TimeStamp                          = 191; /* REF11780 - 100406 - PMO */
FIELD_IDX_T BuyOp_DerivativeOrdEn					 = 192; /* OCS43683-CHU-131112 */
FIELD_IDX_T BuyOp_FxFarLegAmount					 = 193; /* OCS43532-CHU-131112 */
FIELD_IDX_T BuyOp_FxSpotQuote					     = 194; /* OCS43532-CHU-131112 */
FIELD_IDX_T BuyOp_FxQuote						     = 195; /* OCS43532-CHU-131112 */
FIELD_IDX_T BuyOp_OrderFeeEn						 = 196; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BuyOp_OrderFeePrct						 = 197; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BuyOp_MaxOrderQty						 = 198; /*OCS-43526-CHU-131213*/
FIELD_IDX_T BuyOp_STPOrderEn						 = 199; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T BuyOp_UnpaidPrct						 = 200; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T BuyOp_FxSpotLegAmount				     = 201; /* OCS43532-CHU-131112 */
FIELD_IDX_T BuyOp_ExecutedFlg                        = 202;
FIELD_IDX_T BuyOp_FctResultId                        = 203;
FIELD_IDX_T BuyOp_HistQuote                          = 204; /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T BuyOp_ExtOpId                            = 205;
FIELD_IDX_T BuyOp_ExtOp_Ext                          = 206;
FIELD_IDX_T BuyOp_AutoIndex                          = 207;
FIELD_IDX_T BuyOp_ExtOpDbId                          = 208;
FIELD_IDX_T BuyOp_BeginDate                          = 209;
FIELD_IDX_T BuyOp_EndDate                            = 210;
FIELD_IDX_T BuyOp_DraftOrderId						 = 211;	/* REF8500 - 040510 - PMO */
FIELD_IDX_T BuyOp_Summary                            = 212; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BuyOp_EventStatusId                      = 213; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T BuyOp_EventActionEn                      = 214; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T BuyOp_CompoundOrderMasterEltId			 = 215;	/* PMSTA-18636 - SHR - 140905 *///
FIELD_IDX_T BuyOp_CompoundOrderSlaveEltId			 = 216; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BuyOp_CompoundOrderCode					 = 217; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BuyOp_CompoundOrderSlaveNbr				 = 218; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BuyOp_CompoundImpactRule				 = 219; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BuyOp_DisplayCondition					 = 220;	/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BuyOp_OrderType							 = 221;	/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BuyOp_CommonRef                          = 222; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T BuyOp_OrderInclusionEn                   = 223; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BuyOp_OrderRejectionDate                 = 224; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BuyOp_OrderRejectionComment              = 225; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BuyOp_AcquisitionDate                    = 226; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BuyOp_CorporateActionNatEn               = 227; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BuyOp_TaxLotSourceCd                     = 228; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BuyOp_StandInstructId                    = 229; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T BuyOp_BankFeePrct                        = 230; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BuyOp_BankFeeAmount                      = 231; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BuyOp_BankFeeCurrId                      = 232; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BuyOp_PaymentOption                      = 233; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T BuyOp_BidTypeEn                          = 234; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid1Qty                            = 235; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid1Quote                          = 236; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid2Qty                            = 237; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid2Quote                          = 238; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid3Qty                            = 239; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_Bid3Quote                          = 240; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BuyOp_OpFusionRuleEn                     = 241; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T BuyOp_GlobalPosFlg                       = 242; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T	BuyOp_OtcOrderEn						 = 243;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T	BuyOp_DefaultFusRuleEn					 = 244;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T BuyOp_CoolCancelEndDate                  = 245; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T BuyOp_FusionPrioEn                       = 246; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T BuyOp_ExternalBankBic                    = 247; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BuyOp_ExternalBankName                   = 248; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BuyOp_ExternalBankAcctOwnrName           = 249; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BuyOp_HedgeTradeEn                       = 250; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T BuyOp_FixingDate                         = 251; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr1             = 252; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr2             = 253; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr3             = 254; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr4             = 255; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_PayRef1                            = 256; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_PayRef2                            = 257; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_PayRef3                            = 258; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_PayRef4                            = 259; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BuyOp_ExternalTradeFlg                   = 260; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T BuyOp_OriginalQty						 = 261;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T BuyOp_OrderNettingEn					 = 262;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T BuyOp_NettingCriteria                    = 263;/* PMSTA-37908 - adarshn	- 08012020 */
FIELD_IDX_T BuyOp_PaymentDate                        = 264; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BuyOp_PaymentStatusEn                    = 265; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BuyOp_SettlementDate                     = 266; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BuyOp_SettleStatusEn                     = 267; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	BuyOp_CommissionCdEn                     = 268;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_ChargeCdEn                         = 269;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_OriginalAmount                     = 270;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_CounterpartOrgAmount               = 271;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_ExternalFeeM                       = 272;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_TotalChargesM                      = 273;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_CounterpartAmount                  = 274;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_OpLinkageCd                        = 275;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BuyOp_ChargedCustomerName                = 276;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T BuyOp_BoPtfId                            = 277;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T BuyOp_BoAccountId                        = 278;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_OpSplitRuleEn                      = 279;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_AdjBoPtfId                         = 280;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_CoaExDate                          = 281;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_BoCashAcctId                       = 282;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_BoCashPtfId                        = 283;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_SplitParentOperId                  = 284;	/* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BuyOp_OriginalNetAmount					 = 285;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	BuyOp_SplitParOpCd						 = 286;	/* PMSTA-40714 */
FIELD_IDX_T BuyOp_RuleApplicabilityEn				 = 287; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_SmartRoundingQty					 = 288; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_SmartRoundingOrgQty				 = 289; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_RoundingOrgQty				     = 290; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_SmartRoundingFlg					 = 291; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_SmartRoundingRuleId				 = 292; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BuyOp_HierOperNatEn                      = 293; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BuyOp_HierOperationCd                    = 294; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BuyOp_HierGroupingCriteria               = 295; /* PMSTA-40208 - sanand	- 24092020 */
FIELD_IDX_T	BuyOp_CashPlanId                         = 296; /*PMSTA-42402 Autocash Vishnu 12012021*/
FIELD_IDX_T	BuyOp_NotionalInstrId                    = 297;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	BuyOp_InvestLimitEn                      = 298; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T BuyOp_SetOfFeesId						 = 299; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T BuyOp_SetOfProductFeesId				 = 300; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T BuyOp_BoRoutingBusEntityId				 = 301; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T BuyOp_OrderSubTypeId                     = 302; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	BuyOp_SetOfOtherFeesId                   = 303; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	BuyOp_TraderThirdId                      = 304; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	BuyOp_NetSettleAmount                    = 305; /* WEALTH-9095 - SENTHIL - 20240529 */
FIELD_IDX_T BuyOp_PremiumCurrencyId                  = 306; /* WEALTH-8559 - Senthil - 20240607 */
FIELD_IDX_T BuyOp_PremiumAmount                      = 307; /* WEALTH-8559 - Senthil - 20240607 */


FIELD_IDX_T SellOp_Id                                = 0;
FIELD_IDX_T SellOp_Cd                                = 1;
FIELD_IDX_T SellOp_InputUserId                       = 2;
FIELD_IDX_T SellOp_TpId                              = 3;
FIELD_IDX_T SellOp_SubTpId                           = 4;
FIELD_IDX_T SellOp_MktThirdId                        = 5;
FIELD_IDX_T SellOp_IntermThirdId                     = 6;
FIELD_IDX_T SellOp_MgrId                             = 7;
FIELD_IDX_T SellOp_RuleId                            = 8;
FIELD_IDX_T SellOp_SrcCd                             = 9;
FIELD_IDX_T SellOp_SubPosNatEn                       = 10;
FIELD_IDX_T SellOp_SubPosNat2En                      = 11;
FIELD_IDX_T SellOp_SubPosNat3En                      = 12;
FIELD_IDX_T SellOp_LockSubPosNatEn                   = 13;
FIELD_IDX_T SellOp_LockSubPosNat2En                  = 14;
FIELD_IDX_T SellOp_LockSubPosNat3En                  = 15;
FIELD_IDX_T SellOp_LimitQuote                        = 16;
FIELD_IDX_T SellOp_LimitPrice                        = 17;
FIELD_IDX_T SellOp_StopQuote                         = 18;
FIELD_IDX_T SellOp_StopPrice                         = 19;
FIELD_IDX_T SellOp_OrderPriceNatEn                   = 20;
FIELD_IDX_T SellOp_OrderValidNatEn                   = 21;
FIELD_IDX_T SellOp_MinOrderQty                       = 22;
FIELD_IDX_T SellOp_ParOpCd                           = 23;
FIELD_IDX_T SellOp_ParOpNatEn                        = 24;
FIELD_IDX_T SellOp_CheckParentEn                     = 25;
FIELD_IDX_T SellOp_CheckStratEn                      = 26;
FIELD_IDX_T SellOp_OrderNatEn                        = 27;
FIELD_IDX_T SellOp_AcctDate                          = 28;
FIELD_IDX_T SellOp_OpDate                            = 29;
FIELD_IDX_T SellOp_OrderLimitDate                    = 30;
FIELD_IDX_T SellOp_ValueDate                         = 31;
FIELD_IDX_T SellOp_RefOpCd                           = 32;
FIELD_IDX_T SellOp_RefNatEn                          = 33;
FIELD_IDX_T SellOp_StatusEn                          = 34;
FIELD_IDX_T SellOp_SequenceNo                        = 35;
FIELD_IDX_T SellOp_AcctCd                            = 36;
FIELD_IDX_T SellOp_PtfId                             = 37;
FIELD_IDX_T SellOp_CashPtfId                         = 38;
FIELD_IDX_T SellOp_InstrId                           = 39;
FIELD_IDX_T SellOp_AcctId                            = 40;
FIELD_IDX_T SellOp_Acct2Id                           = 41;
FIELD_IDX_T SellOp_Acct3Id                           = 42;
FIELD_IDX_T SellOp_LockInstrId                       = 43;
FIELD_IDX_T SellOp_DepoId                            = 44;
FIELD_IDX_T SellOp_LockDepositId                     = 45;
FIELD_IDX_T SellOp_OpCurrId                          = 46;
FIELD_IDX_T SellOp_InstrCurrId                       = 47;
FIELD_IDX_T SellOp_PtfCurrId                         = 48;
FIELD_IDX_T SellOp_AcctCurrId                        = 49;
FIELD_IDX_T SellOp_Acct2CurrId                       = 50;
FIELD_IDX_T SellOp_Acct3CurrId                       = 51;
FIELD_IDX_T SellOp_TradeCurrId                       = 52;
FIELD_IDX_T SellOp_CashPtfCurrId                     = 53;
FIELD_IDX_T SellOp_LockOpCurrId                      = 54;
FIELD_IDX_T SellOp_LockFiCurrId                      = 55;
FIELD_IDX_T SellOp_CntPtyThirdId                     = 56;
FIELD_IDX_T SellOp_TermTpId                          = 57;
FIELD_IDX_T SellOp_LockTpId                          = 58;
FIELD_IDX_T SellOp_AccrIntrBpTpId                    = 59;
FIELD_IDX_T SellOp_ExtOrderId                        = 60;
FIELD_IDX_T SellOp_OrderCd                           = 61;
FIELD_IDX_T SellOp_ExecSetCriteria                   = 62;
FIELD_IDX_T SellOp_ExecOpId                          = 63;
FIELD_IDX_T SellOp_ExecOpCd                          = 64;
FIELD_IDX_T SellOp_ExecOpNatEn                       = 65;
FIELD_IDX_T SellOp_ExecOpStatEn                      = 66;
FIELD_IDX_T SellOp_RevOpCd                           = 67;
FIELD_IDX_T SellOp_RevOpNatEn                        = 68;
FIELD_IDX_T SellOp_LockOpCd                          = 69;
FIELD_IDX_T SellOp_LockNatEn                         = 70;
FIELD_IDX_T SellOp_EvtCd                             = 71;
FIELD_IDX_T SellOp_EvtNbr                            = 72;
FIELD_IDX_T SellOp_ExCouponFlg                       = 73;
FIELD_IDX_T SellOp_FusRuleEn                         = 74;
FIELD_IDX_T SellOp_LockLimitDate                     = 75;
FIELD_IDX_T SellOp_ExpirDate                         = 76;
FIELD_IDX_T SellOp_Remark                            = 77;
FIELD_IDX_T SellOp_OpExchRate                        = 78;
FIELD_IDX_T SellOp_InstrExchRate                     = 79;
FIELD_IDX_T SellOp_SysExchRate                       = 80;
FIELD_IDX_T SellOp_AcctExchRate                      = 81;
FIELD_IDX_T SellOp_Acct2ExchRate                     = 82;
FIELD_IDX_T SellOp_Acct3ExchRate                     = 83;
FIELD_IDX_T SellOp_TradeExchRate                     = 84;
FIELD_IDX_T SellOp_CashPtfExchRate                   = 85;
FIELD_IDX_T SellOp_LockOpExchRate                    = 86;
FIELD_IDX_T SellOp_LockFiExchRate                    = 87;
FIELD_IDX_T SellOp_Qty                               = 88;
FIELD_IDX_T SellOp_LockQtyN                          = 89;
FIELD_IDX_T SellOp_Price                             = 90;
FIELD_IDX_T SellOp_SpotPrice                         = 91;
FIELD_IDX_T SellOp_LockDirtyPriceN                   = 92;
FIELD_IDX_T SellOp_LockCleanPriceN                   = 93;
FIELD_IDX_T SellOp_PriceCalcRuleEn                   = 94;
FIELD_IDX_T SellOp_Quote                             = 95;
FIELD_IDX_T SellOp_SpotQuote                         = 96;
FIELD_IDX_T SellOp_LockDirtyQuoteN                   = 97;
FIELD_IDX_T SellOp_LockCleanQuoteN                   = 98;
FIELD_IDX_T SellOp_Rate                              = 99;
FIELD_IDX_T SellOp_LockPriceMarginP                  = 100;
FIELD_IDX_T SellOp_SupplAmt                          = 101;
FIELD_IDX_T SellOp_OpGrossAmt                        = 102;
FIELD_IDX_T SellOp_AccrIntrAmt                       = 103;
FIELD_IDX_T SellOp_OpNetAmt                          = 104;
FIELD_IDX_T SellOp_InstrNetAmt                       = 105;
FIELD_IDX_T SellOp_PtfNetAmt                         = 106;
FIELD_IDX_T SellOp_SysNetAmt                         = 107;
FIELD_IDX_T SellOp_AcctNetAmt                        = 108;
FIELD_IDX_T SellOp_Acct2NetAmt                       = 109;
FIELD_IDX_T SellOp_Acct3NetAmt                       = 110;
FIELD_IDX_T SellOp_Bp1TpId                           = 111;
FIELD_IDX_T SellOp_Bp1CurrId                         = 112;
FIELD_IDX_T SellOp_Bp1Amt                            = 113;
FIELD_IDX_T SellOp_Bp2TpId                           = 114;
FIELD_IDX_T SellOp_Bp2CurrId                         = 115;
FIELD_IDX_T SellOp_Bp2Amt                            = 116;
FIELD_IDX_T SellOp_Bp3TpId                           = 117;
FIELD_IDX_T SellOp_Bp3CurrId                         = 118;
FIELD_IDX_T SellOp_Bp3Amt                            = 119;
FIELD_IDX_T SellOp_Bp4TpId                           = 120;
FIELD_IDX_T SellOp_Bp4CurrId                         = 121;
FIELD_IDX_T SellOp_Bp4Amt                            = 122;
FIELD_IDX_T SellOp_Bp5TpId                           = 123;
FIELD_IDX_T SellOp_Bp5CurrId                         = 124;
FIELD_IDX_T SellOp_Bp5Amt                            = 125;
FIELD_IDX_T SellOp_Bp6TpId                           = 126;
FIELD_IDX_T SellOp_Bp6CurrId                         = 127;
FIELD_IDX_T SellOp_Bp6Amt                            = 128;
FIELD_IDX_T SellOp_Bp7TpId                           = 129;
FIELD_IDX_T SellOp_Bp7CurrId                         = 130;
FIELD_IDX_T SellOp_Bp7Amt                            = 131;
FIELD_IDX_T SellOp_Bp8TpId                           = 132;
FIELD_IDX_T SellOp_Bp8CurrId                         = 133;
FIELD_IDX_T SellOp_Bp8Amt                            = 134;
FIELD_IDX_T SellOp_Bp9TpId                           = 135;
FIELD_IDX_T SellOp_Bp9CurrId                         = 136;
FIELD_IDX_T SellOp_Bp9Amt                            = 137;
FIELD_IDX_T SellOp_Bp10TpId                          = 138;
FIELD_IDX_T SellOp_Bp10CurrId                        = 139;
FIELD_IDX_T SellOp_Bp10Amt                           = 140;
FIELD_IDX_T SellOp_FlowId                            = 141;
FIELD_IDX_T SellOp_InitExtPosId                      = 142;
FIELD_IDX_T SellOp_LastUserId                        = 143;
FIELD_IDX_T SellOp_LastModifDate                     = 144;
FIELD_IDX_T SellOp_CreationTime                      = 145;
FIELD_IDX_T SellOp_SysCurrId                         = 146;
FIELD_IDX_T SellOp_ConfirmedFlg                      = 147;
FIELD_IDX_T SellOp_GroupingCriteria                  = 148;
FIELD_IDX_T SellOp_OrderGroupingCd                   = 149;
FIELD_IDX_T SellOp_OrderModeTypeId				     = 150; /*<REF11810-BRO-060608*/
FIELD_IDX_T SellOp_TraderMgrId					     = 151;
FIELD_IDX_T SellOp_AutoRenewalEn					 = 152;
FIELD_IDX_T SellOp_RenewalTreatmtEn				     = 153;
FIELD_IDX_T SellOp_RenewalEndValDate				 = 154;
FIELD_IDX_T SellOp_RenewalLength					 = 155;
FIELD_IDX_T SellOp_RenewalLengthUnitEn			     = 156;
FIELD_IDX_T SellOp_ClientInitEn					     = 157;
FIELD_IDX_T SellOp_ContractNumber				     = 158;
FIELD_IDX_T SellOp_TransactionNatEn				     = 159; /*>REF11810-BRO-060608*/
FIELD_IDX_T SellOp_RenewalIntRate                    = 160; /*REF11810-BRO-060628*/
FIELD_IDX_T SellOp_RenewalAmount                     = 161; /*REF11810-BRO-060628*/
FIELD_IDX_T SellOp_TargetNatureEn                     = 162; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_TargetNumber                       = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_TargetAmount                       = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_MarketSegmentId                    = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_FactSheetEn                        = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_LastQuoteDate                      = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_LastQuoteNumber                    = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_LastPriceNumber                    = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_CommunicationDate                  = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_CommunicationTypeId                = 171; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_CommPartyTypeId                    = 172; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T SellOp_Remark1                            = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_Remark2                            = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_Remark3                            = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_TransmissionDate                   = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_TransmissionTypeId                 = 177; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_OrderTypeId                        = 178; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_MMInterestAmount                   = 179; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_FxMarketRate                       = 180; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_FxClientRate                       = 181; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T SellOp_FxRateDirection                    = 182; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T SellOp_InterestMarketRate                 = 183; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_DebitToSysCurrRate                 = 184; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_CreditToSysCurrRate                = 185; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_ContractLengthNumber               = 186; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_ContractLengthUnitEn               = 187; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T SellOp_FxMarginNumber                     = 188; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T SellOp_FxMarginPrct                       = 189; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T SellOp_FxMarginAmount                     = 190; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T SellOp_TimeStamp                          = 191; /* REF11780 - 100406 - PMO */
FIELD_IDX_T SellOp_DerivativeOrdEn					  = 192; /* OCS43683-CHU-131112 */
FIELD_IDX_T SellOp_FxFarLegAmount					  = 193; /* OCS43532-CHU-131112 */
FIELD_IDX_T SellOp_FxSpotQuote					      = 194; /* OCS43532-CHU-131112 */
FIELD_IDX_T SellOp_FxQuote						      = 195; /* OCS43532-CHU-131112 */
FIELD_IDX_T SellOp_OrderFeeEn					      = 196; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T SellOp_OrderFeePrct						  = 197; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T SellOp_MaxOrderQty						  = 198; /*OCS-43526-CHU-131213*/
FIELD_IDX_T SellOp_STPOrderEn						  = 199; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T SellOp_UnpaidPrct						  = 200; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T SellOp_FxSpotLegAmount				      = 201; /* OCS43532-CHU-131112 */
FIELD_IDX_T SellOp_ExecutedFlg                        = 202;
FIELD_IDX_T SellOp_FctResultId                        = 203;
FIELD_IDX_T SellOp_HistQuote                          = 204; /* PMSTA-4559 - 011107 - PMO */
FIELD_IDX_T SellOp_ExtOpId                            = 205;
FIELD_IDX_T SellOp_ExtOp_Ext                          = 206;
FIELD_IDX_T SellOp_AutoIndex                          = 207;
FIELD_IDX_T SellOp_ExtOpDbId                          = 208;
FIELD_IDX_T SellOp_BeginDate                          = 209;
FIELD_IDX_T SellOp_EndDate                            = 210;
FIELD_IDX_T SellOp_DraftOrderId						  = 211;	/* REF8500 - 040510 - PMO */
FIELD_IDX_T SellOp_Summary                            = 212; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T SellOp_EventStatusId                      = 213; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T SellOp_EventActionEn                      = 214; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T SellOp_CompoundOrderMasterEltId			  = 215;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T SellOp_CompoundOrderSlaveEltId			  = 216; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T SellOp_CompoundOrderCode				  = 217; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T SellOp_CompoundOrderSlaveNbr			  = 218; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T SellOp_CompoundImpactRule				  = 219; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T SellOp_DisplayCondition					  = 200;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T SellOp_OrderType						  = 201;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T SellOp_CommonRef                          = 222; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T SellOp_OrderInclusionEn                   = 223; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T SellOp_OrderRejectionDate                 = 224; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T SellOp_OrderRejectionComment              = 225; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T SellOp_AcquisitionDate                    = 226; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T SellOp_CorporateActionNatEn               = 227; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T SellOp_TaxLotSourceCd                     = 228; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T SellOp_StandInstructId                    = 229; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T SellOp_BankFeePrct                        = 230; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T SellOp_BankFeeAmount                      = 231; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T SellOp_BankFeeCurrId                      = 232; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T SellOp_PaymentOption                      = 233; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T SellOp_BidTypeEn                          = 234; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid1Qty                            = 235; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid1Quote                          = 236; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid2Qty                            = 237; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid2Quote                          = 238; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid3Qty                            = 239; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_Bid3Quote                          = 240; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T SellOp_OpFusionRuleEn                     = 241; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T SellOp_GlobalPosFlg                       = 242; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T	SellOp_OtcOrderEn						  = 243;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T	SellOp_DefaultFusRuleEn					  = 244;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T SellOp_CoolCancelEndDate                  = 245; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T SellOp_FusionPrioEn                       = 246; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T SellOp_ExternalBankBic                    = 247; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T SellOp_ExternalBankName                   = 248; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T SellOp_ExternalBankAcctOwnrName           = 249; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T SellOp_HedgeTradeEn                       = 250; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T SellOp_FixingDate                         = 251; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr1             = 252; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr2             = 253; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr3             = 254; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr4             = 255; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_PayRef1                            = 256; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_PayRef2                            = 257; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_PayRef3                            = 258; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_PayRef4                            = 259; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T SellOp_ExternalTradeFlg                   = 260; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	SellOp_OriginalQty						  = 261; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	SellOp_OrderNettingEn					  = 262; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T SellOp_NettingCriteria                    = 263; /* PMSTA-37908 - adarshn	- 24012020 */
FIELD_IDX_T SellOp_PaymentDate                        = 264; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T SellOp_PaymentStatusEn                    = 265; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T SellOp_SettlementDate                     = 266; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T SellOp_SettleStatusEn                     = 267; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	SellOp_CommissionCdEn                     = 268;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_ChargeCdEn                         = 269;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_OriginalAmount                     = 270;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_CounterpartOrgAmount               = 271;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_ExternalFeeM                       = 272;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_TotalChargesM                      = 273;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_CounterpartAmount                  = 274;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_OpLinkageCd                        = 275;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	SellOp_ChargedCustomerName                = 276;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T SellOp_BoPtfId                            = 277; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T SellOp_BoAccountId                        = 278; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_OpSplitRuleEn                      = 279; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_AdjBoPtfId                         = 280; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_CoaExDate                          = 281; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_BoCashAcctId                       = 282; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_BoCashPtfId                        = 283; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_SplitParentOperId                  = 284; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	SellOp_OriginalNetAmount				  = 285; /* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	SellOp_SplitParOpCd						  = 286; /* PMSTA-40714 */
FIELD_IDX_T SellOp_RuleApplicabilityEn				  = 287; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T SellOp_SmartRoundingQty					  = 288; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T SellOp_SmartRoundingOrgQty				  = 289; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T SellOp_RoundingOrgQty					  = 290; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T SellOp_SmartRoundingFlg					  = 291; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T SellOp_SmartRoundingRuleId				  = 292; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	SellOp_HierOperNatEn                      = 293; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	SellOp_HierOperationCd                    = 294; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	SellOp_HierGroupingCriteria               = 295; /* PMSTA-40208 - sanand	- 24092020 */
FIELD_IDX_T	SellOp_CashPlanId                         = 296; /*PMSTA-42402 Autocash Vishnu 12012021*/
FIELD_IDX_T	SellOp_NotionalInstrId                    = 297; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	SellOp_InvestLimitEn                      = 298; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T SellOp_SetOfFeesId						  = 299; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T SellOp_SetOfProductFeesId				  = 300; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T SellOp_BoRoutingBusEntityId				  = 301; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T SellOp_OrderSubTypeId                     = 302; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	SellOp_SetOfOtherFeesId                   = 303; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	SellOp_TraderThirdId                      = 304; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	SellOp_NetSettleAmount                    = 305; /* WEALTH-9095 - SENTHIL - 20240529 */
FIELD_IDX_T SellOp_PremiumCurrencyId                  = 306; /* WEALTH-8559 - Senthil - 20240607 */
FIELD_IDX_T SellOp_PremiumAmount                      = 307; /* WEALTH-8559 - Senthil - 20240607 */


FIELD_IDX_T InvestOp_Id                              = 0;
FIELD_IDX_T InvestOp_Cd                              = 1;
FIELD_IDX_T InvestOp_InputUserId                     = 2;
FIELD_IDX_T InvestOp_TpId                            = 3;
FIELD_IDX_T InvestOp_SubTpId                         = 4;
FIELD_IDX_T InvestOp_MktThirdId                      = 5;
FIELD_IDX_T InvestOp_IntermThirdId                   = 6;
FIELD_IDX_T InvestOp_MgrId                           = 7;
FIELD_IDX_T InvestOp_RuleId                          = 8;
FIELD_IDX_T InvestOp_SrcCd                           = 9;
FIELD_IDX_T InvestOp_SubPosNatEn                     = 10;
FIELD_IDX_T InvestOp_SubPosNat2En                    = 11;
FIELD_IDX_T InvestOp_SubPosNat3En                    = 12;
FIELD_IDX_T InvestOp_LimitQuote                      = 13;
FIELD_IDX_T InvestOp_LimitPrice                      = 14;
FIELD_IDX_T InvestOp_StopQuote                       = 15;
FIELD_IDX_T InvestOp_StopPrice                       = 16;
FIELD_IDX_T InvestOp_OrderPriceNatEn                 = 17;
FIELD_IDX_T InvestOp_OrderValidNatEn                 = 18;
FIELD_IDX_T InvestOp_MinOrderQty                     = 19;
FIELD_IDX_T InvestOp_ParOpCd                         = 20;
FIELD_IDX_T InvestOp_ParOpNatEn                      = 21;
FIELD_IDX_T InvestOp_CheckParentEn                   = 22;
FIELD_IDX_T InvestOp_OrderNatEn                      = 23;
FIELD_IDX_T InvestOp_AcctDate                        = 24;
FIELD_IDX_T InvestOp_OpDate                          = 25;
FIELD_IDX_T InvestOp_OrderLimitDate                  = 26;
FIELD_IDX_T InvestOp_ValueDate                       = 27;
FIELD_IDX_T InvestOp_RefOpCd                         = 28;
FIELD_IDX_T InvestOp_RefNatEn                        = 29;
FIELD_IDX_T InvestOp_StatusEn                        = 30;
FIELD_IDX_T InvestOp_SequenceNo                      = 31;
FIELD_IDX_T InvestOp_AcctCd                          = 32;
FIELD_IDX_T InvestOp_PtfId                           = 33;
FIELD_IDX_T InvestOp_CashPtfId                       = 34;
FIELD_IDX_T InvestOp_InstrId                         = 35;
FIELD_IDX_T InvestOp_BalPosTpId                      = 36;
FIELD_IDX_T InvestOp_AcctId                          = 37;
FIELD_IDX_T InvestOp_Acct2Id                         = 38;
FIELD_IDX_T InvestOp_Acct3Id                         = 39;
FIELD_IDX_T InvestOp_DepoId                          = 40;
FIELD_IDX_T InvestOp_OpCurrId                        = 41;
FIELD_IDX_T InvestOp_InstrCurrId                     = 42;
FIELD_IDX_T InvestOp_PtfCurrId                       = 43;
FIELD_IDX_T InvestOp_AcctCurrId                      = 44;
FIELD_IDX_T InvestOp_Acct2CurrId                     = 45;
FIELD_IDX_T InvestOp_Acct3CurrId                     = 46;
FIELD_IDX_T InvestOp_TradeCurrId                     = 47;
FIELD_IDX_T InvestOp_CashPtfCurrId                   = 48;
FIELD_IDX_T InvestOp_CntPtyThirdId                   = 49;
FIELD_IDX_T InvestOp_TermTpId                        = 50;
FIELD_IDX_T InvestOp_LockTpId                        = 51;
FIELD_IDX_T InvestOp_AccrIntrBpTpId                  = 52;
FIELD_IDX_T InvestOp_ExecOpId                        = 53;
FIELD_IDX_T InvestOp_ExecOpCd                        = 54;
FIELD_IDX_T InvestOp_ExecOpNatEn                     = 55;
FIELD_IDX_T InvestOp_ExecOpStatEn                    = 56;
FIELD_IDX_T InvestOp_RevOpCd                         = 57;
FIELD_IDX_T InvestOp_RevOpNatEn                      = 58;
FIELD_IDX_T InvestOp_LockOpCd                        = 59;
FIELD_IDX_T InvestOp_LockNatEn                       = 60;
FIELD_IDX_T InvestOp_EvtCd                           = 61;
FIELD_IDX_T InvestOp_EvtNbr                          = 62;
FIELD_IDX_T InvestOp_ExCouponFlg                     = 63;
FIELD_IDX_T InvestOp_FusRuleEn                       = 64;
FIELD_IDX_T InvestOp_LockLimitDate                   = 65;
FIELD_IDX_T InvestOp_ExpirDate                       = 66;
FIELD_IDX_T InvestOp_Remark                          = 67;
FIELD_IDX_T InvestOp_OpExchRate                      = 68;
FIELD_IDX_T InvestOp_InstrExchRate                   = 69;
FIELD_IDX_T InvestOp_SysExchRate                     = 70;
FIELD_IDX_T InvestOp_AcctExchRate                    = 71;
FIELD_IDX_T InvestOp_Acct2ExchRate                   = 72;
FIELD_IDX_T InvestOp_Acct3ExchRate                   = 73;
FIELD_IDX_T InvestOp_TradeExchRate                   = 74;
FIELD_IDX_T InvestOp_CashPtfExchRate                 = 75;
FIELD_IDX_T InvestOp_HistOpExchRate                  = 76;
FIELD_IDX_T InvestOp_HistInstrExchRate               = 77;
FIELD_IDX_T InvestOp_HistSysExchRate                 = 78;
FIELD_IDX_T InvestOp_Qty                             = 79;
FIELD_IDX_T InvestOp_Price                           = 80;
FIELD_IDX_T InvestOp_SpotPrice                       = 81;
FIELD_IDX_T InvestOp_HistPrice                       = 82;
FIELD_IDX_T InvestOp_PriceCalcRuleEn                 = 83;
FIELD_IDX_T InvestOp_Quote                           = 84;
FIELD_IDX_T InvestOp_SpotQuote                       = 85;
FIELD_IDX_T InvestOp_HistQuote                       = 86;
FIELD_IDX_T InvestOp_Rate                            = 87;
FIELD_IDX_T InvestOp_SupplAmt                        = 88;
FIELD_IDX_T InvestOp_OpGrossAmt                      = 89;
FIELD_IDX_T InvestOp_AccrIntrAmt                     = 90;
FIELD_IDX_T InvestOp_OpNetAmt                        = 91;
FIELD_IDX_T InvestOp_InstrNetAmt                     = 92;
FIELD_IDX_T InvestOp_PtfNetAmt                       = 93;
FIELD_IDX_T InvestOp_SysNetAmt                       = 94;
FIELD_IDX_T InvestOp_AcctNetAmt                      = 95;
FIELD_IDX_T InvestOp_Acct2NetAmt                     = 96;
FIELD_IDX_T InvestOp_Acct3NetAmt                     = 97;
FIELD_IDX_T InvestOp_HistOpNetAmt                    = 98;
FIELD_IDX_T InvestOp_HistInstrNetAmt                 = 99;
FIELD_IDX_T InvestOp_HistPtfNetAmt                   = 100;
FIELD_IDX_T InvestOp_HistSysNetAmt                   = 101;
FIELD_IDX_T InvestOp_Bp1TpId                         = 102;
FIELD_IDX_T InvestOp_Bp1CurrId                       = 103;
FIELD_IDX_T InvestOp_Bp1Amt                          = 104;
FIELD_IDX_T InvestOp_Bp2TpId                         = 105;
FIELD_IDX_T InvestOp_Bp2CurrId                       = 106;
FIELD_IDX_T InvestOp_Bp2Amt                          = 107;
FIELD_IDX_T InvestOp_Bp3TpId                         = 108;
FIELD_IDX_T InvestOp_Bp3CurrId                       = 109;
FIELD_IDX_T InvestOp_Bp3Amt                          = 110;
FIELD_IDX_T InvestOp_Bp4TpId                         = 111;
FIELD_IDX_T InvestOp_Bp4CurrId                       = 112;
FIELD_IDX_T InvestOp_Bp4Amt                          = 113;
FIELD_IDX_T InvestOp_Bp5TpId                         = 114;
FIELD_IDX_T InvestOp_Bp5CurrId                       = 115;
FIELD_IDX_T InvestOp_Bp5Amt                          = 116;
FIELD_IDX_T InvestOp_Bp6TpId                         = 117;
FIELD_IDX_T InvestOp_Bp6CurrId                       = 118;
FIELD_IDX_T InvestOp_Bp6Amt                          = 119;
FIELD_IDX_T InvestOp_Bp7TpId                         = 120;
FIELD_IDX_T InvestOp_Bp7CurrId                       = 121;
FIELD_IDX_T InvestOp_Bp7Amt                          = 122;
FIELD_IDX_T InvestOp_Bp8TpId                         = 123;
FIELD_IDX_T InvestOp_Bp8CurrId                       = 124;
FIELD_IDX_T InvestOp_Bp8Amt                          = 125;
FIELD_IDX_T InvestOp_Bp9TpId                         = 126;
FIELD_IDX_T InvestOp_Bp9CurrId                       = 127;
FIELD_IDX_T InvestOp_Bp9Amt                          = 128;
FIELD_IDX_T InvestOp_Bp10TpId                        = 129;
FIELD_IDX_T InvestOp_Bp10CurrId                      = 130;
FIELD_IDX_T InvestOp_Bp10Amt                         = 131;
FIELD_IDX_T InvestOp_FlowId                          = 132;
FIELD_IDX_T InvestOp_InitExtPosId                    = 133;
FIELD_IDX_T InvestOp_LastUserId                      = 134;
FIELD_IDX_T InvestOp_LastModifDate                   = 135;
FIELD_IDX_T InvestOp_CreationTime                    = 136;
FIELD_IDX_T InvestOp_SysCurrId                       = 137;
FIELD_IDX_T InvestOp_ConfirmedFlg                    = 138;
FIELD_IDX_T InvestOp_FctResultId                     = 139;
FIELD_IDX_T InvestOp_OrderModeTypeId				 = 140; /*<REF11810-BRO-060608*/
FIELD_IDX_T InvestOp_TraderMgrId					 = 141;
FIELD_IDX_T InvestOp_AutoRenewalEn				     = 142;
FIELD_IDX_T InvestOp_RenewalTreatmtEn			     = 143;
FIELD_IDX_T InvestOp_RenewalEndValDate			     = 144;
FIELD_IDX_T InvestOp_RenewalLength				     = 145;
FIELD_IDX_T InvestOp_RenewalLengthUnitEn			 = 146;
FIELD_IDX_T InvestOp_ClientInitEn				     = 147;
FIELD_IDX_T InvestOp_ContractNumber				     = 148;
FIELD_IDX_T InvestOp_TransactionNatEn			     = 149; /*>REF11810-BRO-060608*/
FIELD_IDX_T InvestOp_RenewalIntRate                  = 150; /*REF11810-BRO-060628*/
FIELD_IDX_T InvestOp_RenewalAmount                   = 151; /*REF11810-BRO-060628*/
FIELD_IDX_T InvestOp_TargetNatureEn                  = 152; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_TargetNumber                    = 153; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_TargetAmount                    = 154; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_MarketSegmentId                 = 155; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_FactSheetEn                     = 156; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_LastQuoteDate                   = 157; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_LastQuoteNumber                 = 158; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_LastPriceNumber                 = 159; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_CommunicationDate               = 160; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_CommunicationTypeId             = 161; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_CommPartyTypeId                 = 162; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InvestOp_Remark1                         = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_Remark2                         = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_Remark3                         = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_TransmissionDate                = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_TransmissionTypeId              = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_OrderTypeId                     = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_MMInterestAmount                = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_FxMarketRate                    = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_FxClientRate                    = 171; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InvestOp_FxRateDirection                 = 172; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InvestOp_InterestMarketRate              = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_DebitToSysCurrRate              = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_CreditToSysCurrRate             = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_ContractLengthNumber            = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_ContractLengthUnitEn            = 177; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InvestOp_FxMarginNumber                  = 178; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InvestOp_FxMarginPrct                    = 179; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InvestOp_FxMarginAmount                  = 180; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InvestOp_TimeStamp                       = 181; /* REF11780 - 100406 - PMO */
FIELD_IDX_T InvestOp_DerivativeOrdEn				 = 182; /* OCS43683-CHU-131112 */
FIELD_IDX_T InvestOp_FxFarLegAmount					 = 183; /* OCS43532-CHU-131112 */
FIELD_IDX_T InvestOp_FxSpotQuote				     = 184; /* OCS43532-CHU-131112 */
FIELD_IDX_T InvestOp_FxQuote					     = 185; /* OCS43532-CHU-131112 */
FIELD_IDX_T InvestOp_OrderFeeEn					     = 186; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T InvestOp_OrderFeePrct					 = 187; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T InvestOp_MaxOrderQty					 = 188; /*OCS-43526-CHU-131213*/
FIELD_IDX_T InvestOp_STPOrderEn						 = 113; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T InvestOp_UnpaidPrct						 = 114; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T InvestOp_FxSpotLegAmount			     = 189; /* OCS43532-CHU-131112 */
FIELD_IDX_T InvestOp_ExtOpId                         = 190;
FIELD_IDX_T InvestOp_ExtOp_Ext                       = 191;
FIELD_IDX_T InvestOp_AutoIndex                       = 192;
FIELD_IDX_T InvestOp_ExtOpDbId                       = 193;
FIELD_IDX_T InvestOp_BeginDate                       = 194;
FIELD_IDX_T InvestOp_EndDate                         = 195;
FIELD_IDX_T InvestOp_DraftOrderId                    = 196; /* REF8500 - 040510 - PMO */
FIELD_IDX_T InvestOp_Summary                         = 197; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InvestOp_EventStatusId                   = 198; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T InvestOp_EventActionEn                   = 199; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T InvestOp_CompoundOrderMasterEltId		 = 200;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InvestOp_CompoundOrderSlaveEltId		 = 201; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InvestOp_CompoundOrderCode				 = 202; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InvestOp_CompoundOrderSlaveNbr			 = 203; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InvestOp_CompoundImpactRule				 = 204; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InvestOp_DisplayCondition				 = 205;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T InvestOp_OrderType						 = 206;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T InvestOp_CommonRef                       = 207; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T InvestOp_OrderInclusionEn                = 208; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InvestOp_OrderRejectionDate              = 209; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InvestOp_OrderRejectionComment           = 210; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InvestOp_AcquisitionDate                 = 211; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InvestOp_CorporateActionNatEn            = 212; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InvestOp_TaxLotSourceCd                  = 213; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InvestOp_StandInstructId                 = 214; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T InvestOp_BankFeePrct                     = 215; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InvestOp_BankFeeAmount                   = 216; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InvestOp_BankFeeCurrId                   = 217; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InvestOp_PaymentOption                   = 218; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T InvestOp_BidTypeEn                       = 219; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid1Qty                         = 220; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid1Quote                       = 221; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid2Qty                         = 222; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid2Quote                       = 223; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid3Qty                         = 224; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_Bid3Quote                       = 225; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InvestOp_CounterpartAccount              = 226;
FIELD_IDX_T InvestOp_CounterpartCurrencyId           = 227;
FIELD_IDX_T InvestOp_OpFusionRuleEn                  = 228; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T InvestOp_GlobalPosFlg                    = 229; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T	InvestOp_OtcOrderEn						 = 230;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T	InvestOp_DefaultFusRuleEn				 = 231;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T InvestOp_CoolCancelEndDate               = 232; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T InvestOp_FusionPrioEn                    = 233; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T InvestOp_ExternalBankBic                 = 234; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InvestOp_ExternalBankName                = 235; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InvestOp_ExternalBankAcctOwnrName        = 236; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InvestOp_HedgeTradeEn                    = 237; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T InvestOp_FixingDate                      = 238; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr1          = 239; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr2          = 240; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr3          = 241; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr4          = 242; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_PayRef1                         = 243; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_PayRef2                         = 244; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_PayRef3                         = 245; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_PayRef4                         = 246; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InvestOp_ExternalTradeFlg                = 247; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	InvestOp_OriginalQty					 = 248;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	InvestOp_OrderNettingEn					 = 249;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T InvestOp_PaymentDate                     = 250; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InvestOp_PaymentStatusEn                 = 251; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InvestOp_SettlementDate                  = 252; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InvestOp_SettleStatusEn                  = 253; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	InvestOp_CommissionCdEn                  = 254;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_ChargeCdEn                      = 255;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_OriginalAmount                  = 256;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_CounterpartOrgAmount            = 257;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_ExternalFeeM                    = 258;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_TotalChargesM                   = 259;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_CounterpartAmount               = 260;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_OpLinkageCd                     = 261;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InvestOp_ChargedCustomerName             = 262;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T InvestOp_BoPtfId                         = 263; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T InvestOp_BoAccountId                     = 264; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_OpSplitRuleEn                   = 265; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_AdjBoPtfId                      = 266; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_CoaExDate                       = 267; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_BoCashAcctId                    = 268; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_BoCashPtfId                     = 269; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_SplitParentOperId               = 270; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InvestOp_OriginalNetAmount				 = 271;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	InvestOp_SplitParOpCd					 = 272;	/* PMSTA-40714 */
FIELD_IDX_T InvestOp_RuleApplicabilityEn			 = 273; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InvestOp_SmartRoundingQty				 = 274; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InvestOp_SmartRoundingOrgQty			 = 275; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InvestOp_RoundingOrgQty					 = 276; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InvestOp_SmartRoundingFlg				 = 277; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InvestOp_SmartRoundingRuleId			 = 278; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	InvestOp_HierOperNatEn                   = 279; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	InvestOp_HierOperationCd                 = 280; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	InvestOp_NotionalInstrId                 = 281;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	InvestOp_InvestLimitEn                   = 282;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	InvestOp_CashPlanId                      = 283;	/*PMSTA-46635 Autocash Vishnu 17112021*/
FIELD_IDX_T InvestOp_SetOfFeesId					 = 284; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T InvestOp_SetOfProductFeesId              = 285; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T InvestOp_BoRoutingBusEntityId			 = 286; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T InvestOp_OrderSubTypeId                  = 287; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	InvestOp_SetOfOtherFeesId                = 288; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	InvestOp_TraderThirdId                   = 289; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	InvestOp_NetSettleAmount                 = 290; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T WithdrOp_Id                              = 0;
FIELD_IDX_T WithdrOp_Cd                              = 1;
FIELD_IDX_T WithdrOp_InputUserId                     = 2;
FIELD_IDX_T WithdrOp_TpId                            = 3;
FIELD_IDX_T WithdrOp_SubTpId                         = 4;
FIELD_IDX_T WithdrOp_MktThirdId                      = 5;
FIELD_IDX_T WithdrOp_IntermThirdId                   = 6;
FIELD_IDX_T WithdrOp_MgrId                           = 7;
FIELD_IDX_T WithdrOp_RuleId                          = 8;
FIELD_IDX_T WithdrOp_SrcCd                           = 9;
FIELD_IDX_T WithdrOp_SubPosNatEn                     = 10;
FIELD_IDX_T WithdrOp_SubPosNat2En                    = 11;
FIELD_IDX_T WithdrOp_SubPosNat3En                    = 12;
FIELD_IDX_T WithdrOp_LimitQuote                      = 13;
FIELD_IDX_T WithdrOp_LimitPrice                      = 14;
FIELD_IDX_T WithdrOp_StopQuote                       = 15;
FIELD_IDX_T WithdrOp_StopPrice                       = 16;
FIELD_IDX_T WithdrOp_OrderPriceNatEn                 = 17;
FIELD_IDX_T WithdrOp_OrderValidNatEn                 = 18;
FIELD_IDX_T WithdrOp_MinOrderQty                     = 19;
FIELD_IDX_T WithdrOp_ParOpCd                         = 20;
FIELD_IDX_T WithdrOp_ParOpNatEn                      = 21;
FIELD_IDX_T WithdrOp_CheckParentEn                   = 22;
FIELD_IDX_T WithdrOp_OrderNatEn                      = 23;
FIELD_IDX_T WithdrOp_AcctDate                        = 24;
FIELD_IDX_T WithdrOp_OpDate                          = 25;
FIELD_IDX_T WithdrOp_OrderLimitDate                  = 26;
FIELD_IDX_T WithdrOp_ValueDate                       = 27;
FIELD_IDX_T WithdrOp_RefOpCd                         = 28;
FIELD_IDX_T WithdrOp_RefNatEn                        = 29;
FIELD_IDX_T WithdrOp_StatusEn                        = 30;
FIELD_IDX_T WithdrOp_SequenceNo                      = 31;
FIELD_IDX_T WithdrOp_AcctCd                          = 32;
FIELD_IDX_T WithdrOp_PtfId                           = 33;
FIELD_IDX_T WithdrOp_CashPtfId                       = 34;
FIELD_IDX_T WithdrOp_InstrId                         = 35;
FIELD_IDX_T WithdrOp_BalPosTpId                      = 36;
FIELD_IDX_T WithdrOp_AcctId                          = 37;
FIELD_IDX_T WithdrOp_Acct2Id                         = 38;
FIELD_IDX_T WithdrOp_Acct3Id                         = 39;
FIELD_IDX_T WithdrOp_DepoId                          = 40;
FIELD_IDX_T WithdrOp_OpCurrId                        = 41;
FIELD_IDX_T WithdrOp_InstrCurrId                     = 42;
FIELD_IDX_T WithdrOp_PtfCurrId                       = 43;
FIELD_IDX_T WithdrOp_AcctCurrId                      = 44;
FIELD_IDX_T WithdrOp_Acct2CurrId                     = 45;
FIELD_IDX_T WithdrOp_Acct3CurrId                     = 46;
FIELD_IDX_T WithdrOp_TradeCurrId                     = 47;
FIELD_IDX_T WithdrOp_CashPtfCurrId                   = 48;
FIELD_IDX_T WithdrOp_CntPtyThirdId                   = 49;
FIELD_IDX_T WithdrOp_TermTpId                        = 50;
FIELD_IDX_T WithdrOp_LockTpId                        = 51;
FIELD_IDX_T WithdrOp_AccrIntrBpTpId                  = 52;
FIELD_IDX_T WithdrOp_ExecOpId                        = 53;
FIELD_IDX_T WithdrOp_ExecOpCd                        = 54;
FIELD_IDX_T WithdrOp_ExecOpNatEn                     = 55;
FIELD_IDX_T WithdrOp_ExecOpStatEn                    = 56;
FIELD_IDX_T WithdrOp_RevOpCd                         = 57;
FIELD_IDX_T WithdrOp_RevOpNatEn                      = 58;
FIELD_IDX_T WithdrOp_LockOpCd                        = 59;
FIELD_IDX_T WithdrOp_LockNatEn                       = 60;
FIELD_IDX_T WithdrOp_EvtCd                           = 61;
FIELD_IDX_T WithdrOp_EvtNbr                          = 62;
FIELD_IDX_T WithdrOp_ExCouponFlg                     = 63;
FIELD_IDX_T WithdrOp_FusRuleEn                       = 64;
FIELD_IDX_T WithdrOp_LockLimitDate                   = 65;
FIELD_IDX_T WithdrOp_ExpirDate                       = 66;
FIELD_IDX_T WithdrOp_Remark                          = 67;
FIELD_IDX_T WithdrOp_OpExchRate                      = 68;
FIELD_IDX_T WithdrOp_InstrExchRate                   = 69;
FIELD_IDX_T WithdrOp_SysExchRate                     = 70;
FIELD_IDX_T WithdrOp_AcctExchRate                    = 71;
FIELD_IDX_T WithdrOp_Acct2ExchRate                   = 72;
FIELD_IDX_T WithdrOp_Acct3ExchRate                   = 73;
FIELD_IDX_T WithdrOp_TradeExchRate                   = 74;
FIELD_IDX_T WithdrOp_CashPtfExchRate                 = 75;
FIELD_IDX_T WithdrOp_HistOpExchRate                  = 76;
FIELD_IDX_T WithdrOp_HistInstrExchRate               = 77;
FIELD_IDX_T WithdrOp_HistSysExchRate                 = 78;
FIELD_IDX_T WithdrOp_Qty                             = 79;
FIELD_IDX_T WithdrOp_Price                           = 80;
FIELD_IDX_T WithdrOp_SpotPrice                       = 81;
FIELD_IDX_T WithdrOp_HistPrice                       = 82;
FIELD_IDX_T WithdrOp_PriceCalcRuleEn                 = 83;
FIELD_IDX_T WithdrOp_Quote                           = 84;
FIELD_IDX_T WithdrOp_SpotQuote                       = 85;
FIELD_IDX_T WithdrOp_HistQuote                       = 86;
FIELD_IDX_T WithdrOp_Rate                            = 87;
FIELD_IDX_T WithdrOp_SupplAmt                        = 88;
FIELD_IDX_T WithdrOp_OpGrossAmt                      = 89;
FIELD_IDX_T WithdrOp_AccrIntrAmt                     = 90;
FIELD_IDX_T WithdrOp_OpNetAmt                        = 91;
FIELD_IDX_T WithdrOp_InstrNetAmt                     = 92;
FIELD_IDX_T WithdrOp_PtfNetAmt                       = 93;
FIELD_IDX_T WithdrOp_SysNetAmt                       = 94;
FIELD_IDX_T WithdrOp_AcctNetAmt                      = 95;
FIELD_IDX_T WithdrOp_Acct2NetAmt                     = 96;
FIELD_IDX_T WithdrOp_Acct3NetAmt                     = 97;
FIELD_IDX_T WithdrOp_HistOpNetAmt                    = 98;
FIELD_IDX_T WithdrOp_HistInstrNetAmt                 = 99;
FIELD_IDX_T WithdrOp_HistPtfNetAmt                   = 100;
FIELD_IDX_T WithdrOp_HistSysNetAmt                   = 101;
FIELD_IDX_T WithdrOp_Bp1TpId                         = 102;
FIELD_IDX_T WithdrOp_Bp1CurrId                       = 103;
FIELD_IDX_T WithdrOp_Bp1Amt                          = 104;
FIELD_IDX_T WithdrOp_Bp2TpId                         = 105;
FIELD_IDX_T WithdrOp_Bp2CurrId                       = 106;
FIELD_IDX_T WithdrOp_Bp2Amt                          = 107;
FIELD_IDX_T WithdrOp_Bp3TpId                         = 108;
FIELD_IDX_T WithdrOp_Bp3CurrId                       = 109;
FIELD_IDX_T WithdrOp_Bp3Amt                          = 110;
FIELD_IDX_T WithdrOp_Bp4TpId                         = 111;
FIELD_IDX_T WithdrOp_Bp4CurrId                       = 112;
FIELD_IDX_T WithdrOp_Bp4Amt                          = 113;
FIELD_IDX_T WithdrOp_Bp5TpId                         = 114;
FIELD_IDX_T WithdrOp_Bp5CurrId                       = 115;
FIELD_IDX_T WithdrOp_Bp5Amt                          = 116;
FIELD_IDX_T WithdrOp_Bp6TpId                         = 117;
FIELD_IDX_T WithdrOp_Bp6CurrId                       = 118;
FIELD_IDX_T WithdrOp_Bp6Amt                          = 119;
FIELD_IDX_T WithdrOp_Bp7TpId                         = 120;
FIELD_IDX_T WithdrOp_Bp7CurrId                       = 121;
FIELD_IDX_T WithdrOp_Bp7Amt                          = 122;
FIELD_IDX_T WithdrOp_Bp8TpId                         = 123;
FIELD_IDX_T WithdrOp_Bp8CurrId                       = 124;
FIELD_IDX_T WithdrOp_Bp8Amt                          = 125;
FIELD_IDX_T WithdrOp_Bp9TpId                         = 126;
FIELD_IDX_T WithdrOp_Bp9CurrId                       = 127;
FIELD_IDX_T WithdrOp_Bp9Amt                          = 128;
FIELD_IDX_T WithdrOp_Bp10TpId                        = 129;
FIELD_IDX_T WithdrOp_Bp10CurrId                      = 130;
FIELD_IDX_T WithdrOp_Bp10Amt                         = 131;
FIELD_IDX_T WithdrOp_FlowId                          = 132;
FIELD_IDX_T WithdrOp_InitExtPosId                    = 133;
FIELD_IDX_T WithdrOp_LastUserId                      = 134;
FIELD_IDX_T WithdrOp_LastModifDate                   = 135;
FIELD_IDX_T WithdrOp_CreationTime                    = 136;
FIELD_IDX_T WithdrOp_SysCurrId                       = 137;
FIELD_IDX_T WithdrOp_ConfirmedFlg                    = 138;
FIELD_IDX_T WithdrOp_FctResultId                     = 139;
FIELD_IDX_T WithdrOp_OrderModeTypeId				 = 140; /*<REF11810-BRO-060608*/
FIELD_IDX_T WithdrOp_TraderMgrId					 = 141;
FIELD_IDX_T WithdrOp_AutoRenewalEn				     = 142;
FIELD_IDX_T WithdrOp_RenewalTreatmtEn			     = 143;
FIELD_IDX_T WithdrOp_RenewalEndValDate			     = 144;
FIELD_IDX_T WithdrOp_RenewalLength				     = 145;
FIELD_IDX_T WithdrOp_RenewalLengthUnitEn			 = 146;
FIELD_IDX_T WithdrOp_ClientInitEn				     = 147;
FIELD_IDX_T WithdrOp_ContractNumber				     = 148;
FIELD_IDX_T WithdrOp_TransactionNatEn			     = 149; /*>REF11810-BRO-060608*/
FIELD_IDX_T WithdrOp_RenewalIntRate                  = 150; /*REF11810-BRO-060628*/
FIELD_IDX_T WithdrOp_RenewalAmount                   = 151; /*REF11810-BRO-060628*/
FIELD_IDX_T WithdrOp_TargetNatureEn                  = 152; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_TargetNumber                    = 153; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_TargetAmount                    = 154; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_MarketSegmentId                 = 155; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_FactSheetEn                     = 156; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_LastQuoteDate                   = 157; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_LastQuoteNumber                 = 158; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_LastPriceNumber                 = 159; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_CommunicationDate               = 160; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_CommunicationTypeId             = 161; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_CommPartyTypeId                 = 162; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T WithdrOp_Remark1                         = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_Remark2                         = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_Remark3                         = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_TransmissionDate                = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_TransmissionTypeId              = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_OrderTypeId                     = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_MMInterestAmount                = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_FxMarketRate                    = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_FxClientRate                    = 171; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T WithdrOp_FxRateDirection                 = 172; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T WithdrOp_InterestMarketRate              = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_DebitToSysCurrRate              = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_CreditToSysCurrRate             = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_ContractLengthNumber            = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_ContractLengthUnitEn            = 177; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T WithdrOp_FxMarginNumber                  = 178; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T WithdrOp_FxMarginPrct                    = 179; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T WithdrOp_FxMarginAmount                  = 180; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T WithdrOp_TimeStamp                       = 181; /* REF11780 - 100406 - PMO */
FIELD_IDX_T WithdrOp_DerivativeOrdEn				 = 182; /* OCS43683-CHU-131112 */
FIELD_IDX_T WithdrOp_FxFarLegAmount					 = 183; /* OCS43532-CHU-131112 */
FIELD_IDX_T WithdrOp_FxSpotQuote				     = 184; /* OCS43532-CHU-131112 */
FIELD_IDX_T WithdrOp_FxQuote					     = 185; /* OCS43532-CHU-131112 */
FIELD_IDX_T WithdrOp_OrderFeeEn					     = 186; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T WithdrOp_OrderFeePrct					 = 187; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T WithdrOp_MaxOrderQty					 = 188; /*OCS-43526-CHU-131213*/
FIELD_IDX_T WithdrOp_STPOrderEn						 = 189; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T WithdrOp_UnpaidPrct						 = 190; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T WithdrOp_FxSpotLegAmount			     = 191; /* OCS43532-CHU-131112 */
FIELD_IDX_T WithdrOp_ExtOpId                         = 192;
FIELD_IDX_T WithdrOp_ExtOp_Ext                       = 193;
FIELD_IDX_T WithdrOp_AutoIndex                       = 194;
FIELD_IDX_T WithdrOp_ExtOpDbId                       = 195;
FIELD_IDX_T WithdrOp_BeginDate                       = 196;
FIELD_IDX_T WithdrOp_EndDate                         = 197;
FIELD_IDX_T WithdrOp_DraftOrderId                    = 198; /* REF8500 - 040510 - PMO */
FIELD_IDX_T WithdrOp_Summary                         = 199; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T WithdrOp_EventStatusId                   = 200; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T WithdrOp_EventActionEn                   = 201; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T WithdrOp_CompoundOrderMasterEltId		 = 202;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T WithdrOp_CompoundOrderSlaveEltId		 = 203; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T WithdrOp_CompoundOrderCode				 = 204; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T WithdrOp_CompoundOrderSlaveNbr			 = 205; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T WithdrOp_CompoundImpactRule				 = 206; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T WithdrOp_DisplayCondition				 = 207;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T WithdrOp_OrderType						 = 208;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T WithdrOp_CommonRef                       = 209; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T WithdrOp_OrderInclusionEn                = 210; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T WithdrOp_OrderRejectionDate              = 211; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T WithdrOp_OrderRejectionComment           = 212; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T WithdrOp_AcquisitionDate                 = 213; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T WithdrOp_CorporateActionNatEn            = 214; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T WithdrOp_TaxLotSourceCd                  = 215; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T WithdrOp_StandInstructId                 = 216; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T WithdrOp_PaymentOption                   = 217; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T WithdrOp_BankFeePrct                     = 218; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T WithdrOp_BankFeeAmount                   = 219; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T WithdrOp_BankFeeCurrId                   = 220; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T WithdrOp_BidTypeEn                       = 221; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid1Qty                         = 222; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid1Quote                       = 223; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid2Qty                         = 224; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid2Quote                       = 225; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid3Qty                         = 226; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_Bid3Quote                       = 227; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T WithdrOp_CounterpartAccount              = 228;
FIELD_IDX_T WithdrOp_CounterpartCurrencyId           = 229;
FIELD_IDX_T WithdrOp_OpFusionRuleEn                  = 230; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T WithdrOp_GlobalPosFlg                    = 231; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T WithdrOp_OtcOrderEn						 = 232;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T WithdrOp_DefaultFusRuleEn				 = 233;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T WithdrOp_CoolCancelEndDate               = 234; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T WithdrOp_FusionPrioEn                    = 235; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T WithdrOp_ExternalBankBic                 = 236; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T WithdrOp_ExternalBankName                = 237; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T WithdrOp_ExternalBankAcctOwnrName        = 238; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T WithdrOp_HedgeTradeEn                    = 239; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T WithdrOp_FixingDate                      = 240; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr1          = 241; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr2          = 242; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr3          = 243; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr4          = 244; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_PayRef1                         = 245; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_PayRef2                         = 246; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_PayRef3                         = 247; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_PayRef4                         = 248; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T WithdrOp_ExternalTradeFlg                = 249; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	WithdrOp_OriginalQty					 = 250;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	WithdrOp_OrderNettingEn					 = 251;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T WithdrOp_PaymentDate                     = 252; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T WithdrOp_PaymentStatusEn                 = 253; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T WithdrOp_SettlementDate                  = 254; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T WithdrOp_SettleStatusEn                  = 255; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	WithdrOp_CommissionCdEn                  = 256;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_ChargeCdEn                      = 257;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_OriginalAmount                  = 258;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_CounterpartOrgAmount            = 259;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_ExternalFeeM                    = 260;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_TotalChargesM                   = 261;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_CounterpartAmount               = 262;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_OpLinkageCd                     = 263;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	WithdrOp_ChargedCustomerName             = 264;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T WithdrOp_BoPtfId                         = 265; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T WithdrOp_BoAccountId                     = 266; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_OpSplitRuleEn                   = 267; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_AdjBoPtfId                      = 268; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_CoaExDate                       = 269; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_BoCashAcctId                    = 270; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_BoCashPtfId                     = 271; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_SplitParentOperId               = 272; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	WithdrOp_OriginalNetAmount				 = 273;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	WithdrOp_SplitParOpCd					 = 274;	/* PMSTA-40714 */
FIELD_IDX_T WithdrOp_RuleApplicabilityEn			 = 275; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T WithdrOp_SmartRoundingQty				 = 276; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T WithdrOp_SmartRoundingOrgQty			 = 277; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T WithdrOp_RoundingOrgQty					 = 278; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T WithdrOp_SmartRoundingFlg				 = 279; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T WithdrOp_SmartRoundingRuleId			 = 280; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	WithdrOp_HierOperNatEn                   = 281; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	WithdrOp_HierOperationCd                 = 282; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T WithdrOp_NotionalInstrId                 = 283;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	WithdrOp_InvestLimitEn                   = 284;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	WithdrOp_CashPlanId                      = 285; /*PMSTA-45637 Autocash Vishnu 22072021*/
FIELD_IDX_T WithdrOp_SetOfFeesId					 = 286; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T WithdrOp_SetOfProductFeesId				 = 287; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T WithdrOp_BoRoutingBusEntityId			 = 288; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T WithdrOp_OrderSubTypeId                  = 289; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	WithdrOp_SetOfOtherFeesId                = 290; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	WithdrOp_TraderThirdId                   = 291; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	WithdrOp_NetSettleAmount                 = 292; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T IncOp_Id                                 = 0;
FIELD_IDX_T IncOp_Cd                                 = 1;
FIELD_IDX_T IncOp_InputUserId                        = 2;
FIELD_IDX_T IncOp_TpId                               = 3;
FIELD_IDX_T IncOp_SubTpId                            = 4;
FIELD_IDX_T IncOp_MktThirdId                         = 5;
FIELD_IDX_T IncOp_IntermThirdId                      = 6;
FIELD_IDX_T IncOp_MgrId                              = 7;
FIELD_IDX_T IncOp_RuleId                             = 8;
FIELD_IDX_T IncOp_SrcCd                              = 9;
FIELD_IDX_T IncOp_ParOpCd                            = 10;
FIELD_IDX_T IncOp_ParOpNatEn                         = 11;
FIELD_IDX_T IncOp_CheckParentEn                      = 12;
FIELD_IDX_T IncOp_AcctDate                           = 13;
FIELD_IDX_T IncOp_OpDate                             = 14;
FIELD_IDX_T IncOp_ValueDate                          = 15;
FIELD_IDX_T IncOp_RefOpCd                            = 16;
FIELD_IDX_T IncOp_RefNatEn                           = 17;
FIELD_IDX_T IncOp_StatusEn                           = 18;
FIELD_IDX_T IncOp_SequenceNo                         = 19;
FIELD_IDX_T IncOp_AcctCd                             = 20;
FIELD_IDX_T IncOp_PtfId                              = 21;
FIELD_IDX_T IncOp_CashPtfId                          = 22;
FIELD_IDX_T IncOp_InstrId                            = 23;
FIELD_IDX_T IncOp_DepoId                             = 24;
FIELD_IDX_T IncOp_BalPosTpId                         = 25;
FIELD_IDX_T IncOp_AcctId                             = 26;
FIELD_IDX_T IncOp_Acct2Id                            = 27;
FIELD_IDX_T IncOp_Acct3Id                            = 28;
FIELD_IDX_T IncOp_OpCurrId                           = 29;
FIELD_IDX_T IncOp_InstrCurrId                        = 30;
FIELD_IDX_T IncOp_PtfCurrId                          = 31;
FIELD_IDX_T IncOp_AcctCurrId                         = 32;
FIELD_IDX_T IncOp_Acct2CurrId                        = 33;
FIELD_IDX_T IncOp_Acct3CurrId                        = 34;
FIELD_IDX_T IncOp_CashPtfCurrId                      = 35;
FIELD_IDX_T IncOp_CntPtyThirdId                      = 36;
FIELD_IDX_T IncOp_LockTpId                           = 37;
FIELD_IDX_T IncOp_ExecOpId                           = 38;
FIELD_IDX_T IncOp_ExecOpCd                           = 39;
FIELD_IDX_T IncOp_ExecOpNatEn                        = 40;
FIELD_IDX_T IncOp_ExecOpStatEn                       = 41;
FIELD_IDX_T IncOp_RevOpCd                            = 42;
FIELD_IDX_T IncOp_RevOpNatEn                         = 43;
FIELD_IDX_T IncOp_LockOpCd                           = 44;
FIELD_IDX_T IncOp_LockNatEn                          = 45;
FIELD_IDX_T IncOp_EvtCd                              = 46;
FIELD_IDX_T IncOp_EvtNbr                             = 47;
FIELD_IDX_T IncOp_FusRuleEn                          = 48;
FIELD_IDX_T IncOp_Remark                             = 49;
FIELD_IDX_T IncOp_OpExchRate                         = 50;
FIELD_IDX_T IncOp_InstrExchRate                      = 51;
FIELD_IDX_T IncOp_SysExchRate                        = 52;
FIELD_IDX_T IncOp_AcctExchRate                       = 53;
FIELD_IDX_T IncOp_Acct2ExchRate                      = 54;
FIELD_IDX_T IncOp_Acct3ExchRate                      = 55;
FIELD_IDX_T IncOp_CashPtfExchRate                    = 56;
FIELD_IDX_T IncOp_Qty                                = 57;
FIELD_IDX_T IncOp_UnitInc                            = 58;
FIELD_IDX_T IncOp_SupplAmt                           = 59;
FIELD_IDX_T IncOp_OpGrossAmt                         = 60;
FIELD_IDX_T IncOp_OpNetAmt                           = 61;
FIELD_IDX_T IncOp_InstrNetAmt                        = 62;
FIELD_IDX_T IncOp_PtfNetAmt                          = 63;
FIELD_IDX_T IncOp_SysNetAmt                          = 64;
FIELD_IDX_T IncOp_AcctNetAmt                         = 65;
FIELD_IDX_T IncOp_Acct2NetAmt                        = 66;
FIELD_IDX_T IncOp_Acct3NetAmt                        = 67;
FIELD_IDX_T IncOp_Bp1TpId                            = 68;
FIELD_IDX_T IncOp_Bp1CurrId                          = 69;
FIELD_IDX_T IncOp_Bp1Amt                             = 70;
FIELD_IDX_T IncOp_Bp2TpId                            = 71;
FIELD_IDX_T IncOp_Bp2CurrId                          = 72;
FIELD_IDX_T IncOp_Bp2Amt                             = 73;
FIELD_IDX_T IncOp_Bp3TpId                            = 74;
FIELD_IDX_T IncOp_Bp3CurrId                          = 75;
FIELD_IDX_T IncOp_Bp3Amt                             = 76;
FIELD_IDX_T IncOp_Bp4TpId                            = 77;
FIELD_IDX_T IncOp_Bp4CurrId                          = 78;
FIELD_IDX_T IncOp_Bp4Amt                             = 79;
FIELD_IDX_T IncOp_Bp5TpId                            = 80;
FIELD_IDX_T IncOp_Bp5CurrId                          = 81;
FIELD_IDX_T IncOp_Bp5Amt                             = 82;
FIELD_IDX_T IncOp_Bp6TpId                            = 83;
FIELD_IDX_T IncOp_Bp6CurrId                          = 84;
FIELD_IDX_T IncOp_Bp6Amt                             = 85;
FIELD_IDX_T IncOp_Bp7TpId                            = 86;
FIELD_IDX_T IncOp_Bp7CurrId                          = 87;
FIELD_IDX_T IncOp_Bp7Amt                             = 88;
FIELD_IDX_T IncOp_Bp8TpId                            = 89;
FIELD_IDX_T IncOp_Bp8CurrId                          = 90;
FIELD_IDX_T IncOp_Bp8Amt                             = 91;
FIELD_IDX_T IncOp_Bp9TpId                            = 92;
FIELD_IDX_T IncOp_Bp9CurrId                          = 93;
FIELD_IDX_T IncOp_Bp9Amt                             = 94;
FIELD_IDX_T IncOp_Bp10TpId                           = 95;
FIELD_IDX_T IncOp_Bp10CurrId                         = 96;
FIELD_IDX_T IncOp_Bp10Amt                            = 97;
FIELD_IDX_T IncOp_FlowId                             = 98;
FIELD_IDX_T IncOp_InitExtPosId                       = 99;
FIELD_IDX_T IncOp_LastUserId                         = 100;
FIELD_IDX_T IncOp_LastModifDate                      = 101;
FIELD_IDX_T IncOp_CreationTime                       = 102;
FIELD_IDX_T IncOp_SysCurrId                          = 103;
FIELD_IDX_T IncOp_ConfirmedFlg                       = 104;
FIELD_IDX_T IncOp_FctResultId                        = 105;
FIELD_IDX_T IncOp_OrderModeTypeId					 = 106; /*<REF11810-BRO-060608*/
FIELD_IDX_T IncOp_TraderMgrId						 = 107;
FIELD_IDX_T IncOp_AutoRenewalEn						 = 108;
FIELD_IDX_T IncOp_RenewalTreatmtEn					 = 109;
FIELD_IDX_T IncOp_RenewalEndValDate					 = 110;
FIELD_IDX_T IncOp_RenewalLength						 = 111;
FIELD_IDX_T IncOp_RenewalLengthUnitEn				 = 112;
FIELD_IDX_T IncOp_ClientInitEn						 = 113;
FIELD_IDX_T IncOp_ContractNumber				     = 114;
FIELD_IDX_T IncOp_TransactionNatEn					 = 115; /*>REF11810-BRO-060608*/
FIELD_IDX_T IncOp_RenewalIntRate                     = 116; /*REF11810-BRO-060628*/
FIELD_IDX_T IncOp_RenewalAmount                      = 117; /*REF11810-BRO-060628*/
FIELD_IDX_T IncOp_TargetNatureEn                     = 118; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_TargetNumber                       = 119; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_TargetAmount                       = 120; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_MarketSegmentId                    = 121; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_FactSheetEn                        = 122; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_LastQuoteDate                      = 123; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_LastQuoteNumber                    = 124; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_LastPriceNumber                    = 125; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_CommunicationDate                  = 126; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_CommunicationTypeId                = 127; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_CommPartyTypeId                    = 128; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T IncOp_Remark1                            = 129; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_Remark2                            = 130; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_Remark3                            = 131; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_TransmissionDate                   = 132; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_TransmissionTypeId                 = 133; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_OrderTypeId                        = 134; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_MMInterestAmount                   = 135; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_FxMarketRate                       = 136; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_FxClientRate                       = 137; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T IncOp_FxRateDirection                    = 138; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T IncOp_InterestMarketRate                 = 139; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_DebitToSysCurrRate                 = 140; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_CreditToSysCurrRate                = 141; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_ContractLengthNumber               = 142; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_ContractLengthUnitEn               = 143; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T IncOp_FxMarginNumber                     = 144; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T IncOp_FxMarginPrct                       = 145; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T IncOp_FxMarginAmount                     = 146; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T IncOp_ExtOpId                            = 147;
FIELD_IDX_T IncOp_ExtOp_Ext                          = 148;
FIELD_IDX_T IncOp_AutoIndex                          = 149;
FIELD_IDX_T IncOp_ExtOpDbId                          = 150;
FIELD_IDX_T IncOp_BeginDate                          = 151;
FIELD_IDX_T IncOp_EndDate                            = 152;
FIELD_IDX_T IncOp_DraftOrderId                       = 153; /* REF8500 - 040510 - PMO */
FIELD_IDX_T IncOp_Summary                            = 154; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T IncOp_TimeStamp                          = 155; /* REF11780 - 100406 - PMO */
FIELD_IDX_T IncOp_DerivativeOrdEn					 = 156; /* OCS43683-CHU-131112 */
FIELD_IDX_T IncOp_FxFarLegAmount					 = 157; /* OCS43532-CHU-131112 */
FIELD_IDX_T IncOp_FxSpotQuote					     = 158; /* OCS43532-CHU-131112 */
FIELD_IDX_T IncOp_FxQuote						     = 159; /* OCS43532-CHU-131112 */
FIELD_IDX_T IncOp_OrderFeeEn					     = 160; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T IncOp_OrderFeePrct						 = 161; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T IncOp_FxSpotLegAmount				     = 162; /* OCS43532-CHU-131112 */
FIELD_IDX_T IncOp_MaxOrderQty						 = 163; /*OCS-43526-CHU-131213*/
FIELD_IDX_T IncOp_STPOrderEn						 = 164; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T IncOp_UnpaidPrct						 = 165; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T IncOp_EventStatusId                      = 166; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T IncOp_EventActionEn                      = 167; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T IncOp_CompoundOrderMasterEltId			 = 168;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T IncOp_CompoundOrderSlaveEltId			 = 169; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T IncOp_CompoundOrderCode					 = 170; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T IncOp_CompoundOrderSlaveNbr				 = 171; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T IncOp_CompoundImpactRule				 = 172; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T IncOp_DisplayCondition					 = 173;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T IncOp_OrderType							 = 174;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T IncOp_CommonRef                          = 175; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T IncOp_OrderInclusionEn                   = 176; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T IncOp_OrderRejectionDate                 = 177; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T IncOp_OrderRejectionComment              = 178; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T IncOp_AcquisitionDate                    = 179; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T IncOp_CorporateActionNatEn               = 180; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T IncOp_TaxLotSourceCd                     = 181; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T IncOp_StandInstructId                    = 182; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T IncOp_BankFeePrct                        = 183; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T IncOp_BankFeeAmount                      = 184; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T IncOp_BankFeeCurrId                      = 185; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T IncOp_PaymentOption                      = 186; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T IncOp_BidTypeEn                          = 187; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid1Qty                            = 188; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid1Quote                          = 189; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid2Qty                            = 190; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid2Quote                          = 191; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid3Qty                            = 192; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_Bid3Quote                          = 193; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T IncOp_OpFusionRuleEn                     = 194; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T IncOp_GlobalPosFlg                       = 195; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T IncOp_OtcOrderEn						 = 196;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T IncOp_DefaultFusRuleEn					 = 197;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T IncOp_CoolCancelEndDate                  = 198; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T IncOp_FusionPrioEn                       = 199; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T IncOp_ExternalBankBic                    = 200; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T IncOp_ExternalBankName                   = 201; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T IncOp_ExternalBankAcctOwnrName           = 202; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T IncOp_HedgeTradeEn                       = 203; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T IncOp_FixingDate                         = 204; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr1             = 205; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr2             = 206; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr3             = 207; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr4             = 208; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_PayRef1                            = 209; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_PayRef2                            = 210; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_PayRef3                            = 211; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_PayRef4                            = 212; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T IncOp_ExternalTradeFlg                   = 213; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	IncOp_OriginalQty						 = 214;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	IncOp_OrderNettingEn					 = 215;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T IncOp_PaymentDate                        = 216; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T IncOp_PaymentStatusEn                    = 217; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T IncOp_SettlementDate                     = 218; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T IncOp_SettleStatusEn                     = 219; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	IncOp_CommissionCdEn                     = 220;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_ChargeCdEn                         = 221;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_OriginalAmount                     = 222;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_CounterpartOrgAmount               = 223;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_ExternalFeeM                       = 224;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_TotalChargesM                      = 225;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_CounterpartAmount                  = 226;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_OpLinkageCd                        = 227;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	IncOp_ChargedCustomerName                = 228;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T IncOp_BoPtfId                            = 229; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T IncOp_BoAccountId                        = 230; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_OpSplitRuleEn                      = 231; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_AdjBoPtfId                         = 232; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_CoaExDate                          = 233; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_BoCashAcctId                       = 234; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_BoCashPtfId                        = 235; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_SplitParentOperId                  = 236; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	IncOp_OriginalNetAmount					 = 237;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	IncOp_SplitParOpCd						 = 238;	/* PMSTA-40714 */
FIELD_IDX_T IncOp_RuleApplicabilityEn				 = 239; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T IncOp_SmartRoundingQty					 = 240; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T IncOp_SmartRoundingOrgQty				 = 241; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T IncOp_RoundingOrgQty					 = 242; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T IncOp_SmartRoundingFlg					 = 243; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T IncOp_SmartRoundingRuleId				 = 244; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	IncOp_HierOperNatEn                      = 245;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	IncOp_HierOperationCd                    = 246; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	IncOp_NotionalInstrId                    = 247;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	IncOp_InvestLimitEn                      = 248;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T IncOp_SetOfFeesId						 = 249; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T IncOp_SetOfProductFeesId                 = 250; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T IncOp_BoRoutingBusEntityId				 = 251; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T IncOp_OrderSubTypeId                     = 252; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	IncOp_SetOfOtherFeesId                   = 253; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	IncOp_TraderThirdId                      = 254; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	IncOp_NetSettleAmount                    = 255; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T ShareIssOp_Id                            = 0;
FIELD_IDX_T ShareIssOp_Cd                            = 1;
FIELD_IDX_T ShareIssOp_InputUserId                   = 2;
FIELD_IDX_T ShareIssOp_TpId                          = 3;
FIELD_IDX_T ShareIssOp_SubTpId                       = 4;
FIELD_IDX_T ShareIssOp_MktThirdId                    = 5;
FIELD_IDX_T ShareIssOp_IntermThirdId                 = 6;
FIELD_IDX_T ShareIssOp_MgrId                         = 7;
FIELD_IDX_T ShareIssOp_RuleId                        = 8;
FIELD_IDX_T ShareIssOp_SrcCd                         = 9;
FIELD_IDX_T ShareIssOp_ValoSeqNo                     = 10;
FIELD_IDX_T ShareIssOp_ParOpCd                       = 11;
FIELD_IDX_T ShareIssOp_ParOpNatEn                    = 12;
FIELD_IDX_T ShareIssOp_CheckParentEn                 = 13;
FIELD_IDX_T ShareIssOp_AcctDate                      = 14;
FIELD_IDX_T ShareIssOp_OpDate                        = 15;
FIELD_IDX_T ShareIssOp_ValuationDate                 = 16;
FIELD_IDX_T ShareIssOp_ValueDate                     = 17;
FIELD_IDX_T ShareIssOp_RefOpCd                       = 18;
FIELD_IDX_T ShareIssOp_RefNatEn                      = 19;
FIELD_IDX_T ShareIssOp_StatusEn                      = 20;
FIELD_IDX_T ShareIssOp_SequenceNo                    = 21;
FIELD_IDX_T ShareIssOp_AcctCd                        = 22;
FIELD_IDX_T ShareIssOp_PtfId                         = 23;
FIELD_IDX_T ShareIssOp_InstrId                       = 24;
FIELD_IDX_T ShareIssOp_BalPosTpId                    = 25;
FIELD_IDX_T ShareIssOp_AcctId                        = 26;
FIELD_IDX_T ShareIssOp_DepoId                        = 27;
FIELD_IDX_T ShareIssOp_OpCurrId                      = 28;
FIELD_IDX_T ShareIssOp_InstrCurrId                   = 29;
FIELD_IDX_T ShareIssOp_PtfCurrId                     = 30;
FIELD_IDX_T ShareIssOp_AcctCurrId                    = 31;
FIELD_IDX_T ShareIssOp_CntPtyThirdId                 = 32;
FIELD_IDX_T ShareIssOp_LockTpId                      = 33;
FIELD_IDX_T ShareIssOp_ExecOpId                      = 34;
FIELD_IDX_T ShareIssOp_ExecOpCd                      = 35;
FIELD_IDX_T ShareIssOp_ExecOpNatEn                   = 36;
FIELD_IDX_T ShareIssOp_ExecOpStatEn                  = 37;
FIELD_IDX_T ShareIssOp_RevOpCd                       = 38;
FIELD_IDX_T ShareIssOp_RevOpNatEn                    = 39;
FIELD_IDX_T ShareIssOp_LockOpCd                      = 40;
FIELD_IDX_T ShareIssOp_LockNatEn                     = 41;
FIELD_IDX_T ShareIssOp_EvtCd                         = 42;
FIELD_IDX_T ShareIssOp_EvtNbr                        = 43;
FIELD_IDX_T ShareIssOp_FusRuleEn                     = 44;
FIELD_IDX_T ShareIssOp_Remark                        = 45;
FIELD_IDX_T ShareIssOp_OpExchRate                    = 46;
FIELD_IDX_T ShareIssOp_InstrExchRate                 = 47;
FIELD_IDX_T ShareIssOp_SysExchRate                   = 48;
FIELD_IDX_T ShareIssOp_AcctExchRate                  = 49;
FIELD_IDX_T ShareIssOp_Qty                           = 50;
FIELD_IDX_T ShareIssOp_Price                         = 51;
FIELD_IDX_T ShareIssOp_SupplAmt                      = 52;
FIELD_IDX_T ShareIssOp_OpGrossAmt                    = 53;
FIELD_IDX_T ShareIssOp_OpNetAmt                      = 54;
FIELD_IDX_T ShareIssOp_InstrNetAmt                   = 55;
FIELD_IDX_T ShareIssOp_PtfNetAmt                     = 56;
FIELD_IDX_T ShareIssOp_SysNetAmt                     = 57;
FIELD_IDX_T ShareIssOp_AcctNetAmt                    = 58;
FIELD_IDX_T ShareIssOp_Bp1TpId                       = 59;
FIELD_IDX_T ShareIssOp_Bp1CurrId                     = 60;
FIELD_IDX_T ShareIssOp_Bp1Amt                        = 61;
FIELD_IDX_T ShareIssOp_Bp2TpId                       = 62;
FIELD_IDX_T ShareIssOp_Bp2CurrId                     = 63;
FIELD_IDX_T ShareIssOp_Bp2Amt                        = 64;
FIELD_IDX_T ShareIssOp_Bp3TpId                       = 65;
FIELD_IDX_T ShareIssOp_Bp3CurrId                     = 66;
FIELD_IDX_T ShareIssOp_Bp3Amt                        = 67;
FIELD_IDX_T ShareIssOp_Bp4TpId                       = 68;
FIELD_IDX_T ShareIssOp_Bp4CurrId                     = 69;
FIELD_IDX_T ShareIssOp_Bp4Amt                        = 70;
FIELD_IDX_T ShareIssOp_Bp5TpId                       = 71;
FIELD_IDX_T ShareIssOp_Bp5CurrId                     = 72;
FIELD_IDX_T ShareIssOp_Bp5Amt                        = 73;
FIELD_IDX_T ShareIssOp_Bp6TpId                       = 74;
FIELD_IDX_T ShareIssOp_Bp6CurrId                     = 75;
FIELD_IDX_T ShareIssOp_Bp6Amt                        = 76;
FIELD_IDX_T ShareIssOp_Bp7TpId                       = 77;
FIELD_IDX_T ShareIssOp_Bp7CurrId                     = 78;
FIELD_IDX_T ShareIssOp_Bp7Amt                        = 79;
FIELD_IDX_T ShareIssOp_Bp8TpId                       = 80;
FIELD_IDX_T ShareIssOp_Bp8CurrId                     = 81;
FIELD_IDX_T ShareIssOp_Bp8Amt                        = 82;
FIELD_IDX_T ShareIssOp_Bp9TpId                       = 83;
FIELD_IDX_T ShareIssOp_Bp9CurrId                     = 84;
FIELD_IDX_T ShareIssOp_Bp9Amt                        = 85;
FIELD_IDX_T ShareIssOp_Bp10TpId                      = 86;
FIELD_IDX_T ShareIssOp_Bp10CurrId                    = 87;
FIELD_IDX_T ShareIssOp_Bp10Amt                       = 88;
FIELD_IDX_T ShareIssOp_FlowId                        = 89;
FIELD_IDX_T ShareIssOp_InitExtPosId                  = 90;
FIELD_IDX_T ShareIssOp_LastUserId                    = 91;
FIELD_IDX_T ShareIssOp_LastModifDate                 = 92;
FIELD_IDX_T ShareIssOp_CreationTime                  = 93;
FIELD_IDX_T ShareIssOp_SysCurrId                     = 94;
FIELD_IDX_T ShareIssOp_FundValId                     = 95;
FIELD_IDX_T ShareIssOp_ConfirmedFlg                  = 96;
FIELD_IDX_T ShareIssOp_FctResultId                   = 97;
FIELD_IDX_T ShareIssOp_OrderModeTypeId			     = 98; /*<REF11810-BRO-060608*/
FIELD_IDX_T ShareIssOp_TraderMgrId					 = 99;
FIELD_IDX_T ShareIssOp_AutoRenewalEn			     = 100;
FIELD_IDX_T ShareIssOp_RenewalTreatmtEn			     = 101;
FIELD_IDX_T ShareIssOp_RenewalEndValDate		     = 102;
FIELD_IDX_T ShareIssOp_RenewalLength			     = 103;
FIELD_IDX_T ShareIssOp_RenewalLengthUnitEn		     = 104;
FIELD_IDX_T ShareIssOp_ClientInitEn					 = 105;
FIELD_IDX_T ShareIssOp_ContractNumber				 = 106;
FIELD_IDX_T ShareIssOp_TransactionNatEn			     = 107; /*>REF11810-BRO-060608*/
FIELD_IDX_T ShareIssOp_RenewalIntRate                = 108; /*REF11810-BRO-060628*/
FIELD_IDX_T ShareIssOp_RenewalAmount                 = 109; /*REF11810-BRO-060628*/
FIELD_IDX_T ShareIssOp_TargetNatureEn                = 110; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_TargetNumber                  = 111; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_TargetAmount                  = 112; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_MarketSegmentId               = 113; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_FactSheetEn                   = 114; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_LastQuoteDate                 = 115; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_LastQuoteNumber               = 116; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_LastPriceNumber               = 117; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_CommunicationDate             = 118; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_CommunicationTypeId           = 119; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_CommPartyTypeId               = 120; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareIssOp_Remark1                       = 121; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_Remark2                       = 122; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_Remark3                       = 123; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_TransmissionDate              = 124; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_TransmissionTypeId            = 125; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_OrderTypeId                   = 126; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_MMInterestAmount              = 127; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_FxMarketRate                  = 128; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_FxClientRate                  = 129; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareIssOp_FxRateDirection               = 130; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareIssOp_InterestMarketRate            = 131; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_DebitToSysCurrRate            = 132; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_CreditToSysCurrRate           = 133; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_ContractLengthNumber          = 134; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_ContractLengthUnitEn          = 135; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareIssOp_FxMarginNumber                = 136; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareIssOp_FxMarginPrct                  = 137; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareIssOp_FxMarginAmount                = 138; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareIssOp_ExtOpId                       = 139;
FIELD_IDX_T ShareIssOp_ExtOp_Ext                     = 140;
FIELD_IDX_T ShareIssOp_AutoIndex                     = 141;
FIELD_IDX_T ShareIssOp_ExtOpDbId                     = 142;
FIELD_IDX_T ShareIssOp_BeginDate                     = 143;
FIELD_IDX_T ShareIssOp_EndDate                       = 144;
FIELD_IDX_T ShareIssOp_DraftOrderId                  = 145; /* REF8500 - 040510 - PMO */
FIELD_IDX_T ShareIssOp_Summary                       = 146; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareIssOp_TimeStamp                     = 147; /* REF11780 - 100406 - PMO */
FIELD_IDX_T ShareIssOp_DerivativeOrdEn				 = 148; /* OCS43683-CHU-131112 */
FIELD_IDX_T ShareIssOp_FxFarLegAmount				 = 149; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareIssOp_FxSpotQuote				     = 150; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareIssOp_FxQuote					     = 151; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareIssOp_OrderFeeEn				     = 152; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ShareIssOp_OrderFeePrct					 = 153; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ShareIssOp_FxSpotLegAmount			     = 154; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareIssOp_MaxOrderQty					 = 155; /*OCS-43526-CHU-131213*/
FIELD_IDX_T ShareIssOp_STPOrderEn					 = 156; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T ShareIssOp_UnpaidPrct					 = 157; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T ShareIssOp_EventStatusId                 = 158; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T ShareIssOp_EventActionEn                 = 159; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T ShareIssOp_CompoundOrderMasterEltId		 = 160;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareIssOp_CompoundOrderSlaveEltId		 = 161; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareIssOp_CompoundOrderCode			 = 162; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareIssOp_CompoundOrderSlaveNbr		 = 163; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareIssOp_CompoundImpactRule		     = 164; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareIssOp_DisplayCondition				 = 165;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ShareIssOp_OrderType					 = 166;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ShareIssOp_CommonRef                     = 167; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T ShareIssOp_OrderInclusionEn              = 168; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareIssOp_OrderRejectionDate            = 169; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareIssOp_OrderRejectionComment         = 170; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareIssOp_AcquisitionDate               = 171; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareIssOp_CorporateActionNatEn          = 172; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareIssOp_TaxLotSourceCd                = 173; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareIssOp_StandInstructId               = 174; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T ShareIssOp_BankFeePrct                   = 175; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareIssOp_BankFeeAmount                 = 176; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareIssOp_BankFeeCurrId                 = 177; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareIssOp_PaymentOption                 = 178; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T ShareIssOp_BidTypeEn                     = 179; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid1Qty                       = 180; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid1Quote                     = 181; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid2Qty                       = 182; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid2Quote                     = 183; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid3Qty                       = 184; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_Bid3Quote                     = 185; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareIssOp_OpFusionRuleEn                = 184; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ShareIssOp_GlobalPosFlg                  = 185; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ShareIssOp_OtcOrderEn					 = 186;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ShareIssOp_DefaultFusRuleEn				 = 187;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ShareIssOp_CoolCancelEndDate             = 188; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T ShareIssOp_FusionPrioEn                  = 189; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T ShareIssOp_ExternalBankBic               = 190; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareIssOp_ExternalBankName              = 191; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareIssOp_ExternalBankAcctOwnrName      = 192; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareIssOp_HedgeTradeEn                  = 193; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T ShareIssOp_FixingDate                    = 194; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr1        = 195; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr2        = 196; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr3        = 197; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr4        = 198; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_PayRef1                       = 199; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_PayRef2                       = 200; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_PayRef3                       = 201; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_PayRef4                       = 202; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareIssOp_ExternalTradeFlg              = 203; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	ShareIssOp_OriginalQty					 = 204;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T ShareIssOp_OrderNettingEn				 = 205;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T ShareIssOp_PaymentDate                   = 206; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareIssOp_PaymentStatusEn               = 207; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareIssOp_SettlementDate                = 208; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareIssOp_SettleStatusEn                = 209; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	ShareIssOp_CommissionCdEn                = 210;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_ChargeCdEn                    = 211;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_OriginalAmount                = 212;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_CounterpartOrgAmount          = 213;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_ExternalFeeM                  = 214;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_TotalChargesM                 = 215;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_CounterpartAmount             = 216;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_OpLinkageCd                   = 217;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareIssOp_ChargedCustomerName           = 218;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T ShareIssOp_BoPtfId                       = 219; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T ShareIssOp_BoAccountId                   = 220; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_OpSplitRuleEn                 = 221; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_AdjBoPtfId                    = 222; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_CoaExDate                     = 223; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_BoCashAcctId                  = 224; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_BoCashPtfId                   = 225; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_SplitParentOperId             = 226; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareIssOp_OriginalNetAmount			 = 227;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	ShareIssOp_SplitParOpCd					 = 228;	/* PMSTA-40714 */
FIELD_IDX_T ShareIssOp_RuleApplicabilityEn			 = 229; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareIssOp_SmartRoundingQty				 = 230; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareIssOp_SmartRoundingOrgQty			 = 231; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareIssOp_RoundingOrgQty				 = 232; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareIssOp_SmartRoundingFlg				 = 233; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareIssOp_SmartRoundingRuleId			 = 234; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	ShareIssOp_HierOperNatEn                 = 235; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	ShareIssOp_HierOperationCd               = 236; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	ShareIssOp_NotionalInstrId               = 237;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	ShareIssOp_InvestLimitEn                 = 238;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T ShareIssOp_SetOfFeesId					 = 239; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ShareIssOp_SetOfProductFeesId			 = 240; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ShareIssOp_BoRoutingBusEntityId			 = 241; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T ShareIssOp_OrderSubTypeId                = 242; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	ShareIssOp_SetOfOtherFeesId              = 243; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	ShareIssOp_TraderThirdId                 = 244; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	ShareIssOp_NetSettleAmount               = 245; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T ShareRedmOp_Id                           = 0;
FIELD_IDX_T ShareRedmOp_Cd                           = 1;
FIELD_IDX_T ShareRedmOp_InputUserId                  = 2;
FIELD_IDX_T ShareRedmOp_TpId                         = 3;
FIELD_IDX_T ShareRedmOp_SubTpId                      = 4;
FIELD_IDX_T ShareRedmOp_MktThirdId                   = 5;
FIELD_IDX_T ShareRedmOp_IntermThirdId                = 6;
FIELD_IDX_T ShareRedmOp_MgrId                        = 7;
FIELD_IDX_T ShareRedmOp_RuleId                       = 8;
FIELD_IDX_T ShareRedmOp_SrcCd                        = 9;
FIELD_IDX_T ShareRedmOp_ValoSeqNo                    = 10;
FIELD_IDX_T ShareRedmOp_ParOpCd                      = 11;
FIELD_IDX_T ShareRedmOp_ParOpNatEn                   = 12;
FIELD_IDX_T ShareRedmOp_CheckParentEn                = 13;
FIELD_IDX_T ShareRedmOp_AcctDate                     = 14;
FIELD_IDX_T ShareRedmOp_OpDate                       = 15;
FIELD_IDX_T ShareRedmOp_ValuationDate                = 16;
FIELD_IDX_T ShareRedmOp_ValueDate                    = 17;
FIELD_IDX_T ShareRedmOp_RefOpCd                      = 18;
FIELD_IDX_T ShareRedmOp_RefNatEn                     = 19;
FIELD_IDX_T ShareRedmOp_StatusEn                     = 20;
FIELD_IDX_T ShareRedmOp_SequenceNo                   = 21;
FIELD_IDX_T ShareRedmOp_AcctCd                       = 22;
FIELD_IDX_T ShareRedmOp_PtfId                        = 23;
FIELD_IDX_T ShareRedmOp_InstrId                      = 24;
FIELD_IDX_T ShareRedmOp_BalPosTpId                   = 25;
FIELD_IDX_T ShareRedmOp_AcctId                       = 26;
FIELD_IDX_T ShareRedmOp_DepoId                       = 27;
FIELD_IDX_T ShareRedmOp_OpCurrId                     = 28;
FIELD_IDX_T ShareRedmOp_InstrCurrId                  = 29;
FIELD_IDX_T ShareRedmOp_PtfCurrId                    = 30;
FIELD_IDX_T ShareRedmOp_AcctCurrId                   = 31;
FIELD_IDX_T ShareRedmOp_CntPtyThirdId                = 32;
FIELD_IDX_T ShareRedmOp_LockTpId                     = 33;
FIELD_IDX_T ShareRedmOp_ExecOpId                     = 34;
FIELD_IDX_T ShareRedmOp_ExecOpCd                     = 35;
FIELD_IDX_T ShareRedmOp_ExecOpNatEn                  = 36;
FIELD_IDX_T ShareRedmOp_ExecOpStatEn                 = 37;
FIELD_IDX_T ShareRedmOp_RevOpCd                      = 38;
FIELD_IDX_T ShareRedmOp_RevOpNatEn                   = 39;
FIELD_IDX_T ShareRedmOp_LockOpCd                     = 40;
FIELD_IDX_T ShareRedmOp_LockNatEn                    = 41;
FIELD_IDX_T ShareRedmOp_EvtCd                        = 42;
FIELD_IDX_T ShareRedmOp_EvtNbr                       = 43;
FIELD_IDX_T ShareRedmOp_FusRuleEn                    = 44;
FIELD_IDX_T ShareRedmOp_Remark                       = 45;
FIELD_IDX_T ShareRedmOp_OpExchRate                   = 46;
FIELD_IDX_T ShareRedmOp_InstrExchRate                = 47;
FIELD_IDX_T ShareRedmOp_SysExchRate                  = 48;
FIELD_IDX_T ShareRedmOp_AcctExchRate                 = 49;
FIELD_IDX_T ShareRedmOp_Qty                          = 50;
FIELD_IDX_T ShareRedmOp_Price                        = 51;
FIELD_IDX_T ShareRedmOp_SupplAmt                     = 52;
FIELD_IDX_T ShareRedmOp_OpGrossAmt                   = 53;
FIELD_IDX_T ShareRedmOp_OpNetAmt                     = 54;
FIELD_IDX_T ShareRedmOp_InstrNetAmt                  = 55;
FIELD_IDX_T ShareRedmOp_PtfNetAmt                    = 56;
FIELD_IDX_T ShareRedmOp_SysNetAmt                    = 57;
FIELD_IDX_T ShareRedmOp_AcctNetAmt                   = 58;
FIELD_IDX_T ShareRedmOp_Bp1TpId                      = 59;
FIELD_IDX_T ShareRedmOp_Bp1CurrId                    = 60;
FIELD_IDX_T ShareRedmOp_Bp1Amt                       = 61;
FIELD_IDX_T ShareRedmOp_Bp2TpId                      = 62;
FIELD_IDX_T ShareRedmOp_Bp2CurrId                    = 63;
FIELD_IDX_T ShareRedmOp_Bp2Amt                       = 64;
FIELD_IDX_T ShareRedmOp_Bp3TpId                      = 65;
FIELD_IDX_T ShareRedmOp_Bp3CurrId                    = 66;
FIELD_IDX_T ShareRedmOp_Bp3Amt                       = 67;
FIELD_IDX_T ShareRedmOp_Bp4TpId                      = 68;
FIELD_IDX_T ShareRedmOp_Bp4CurrId                    = 69;
FIELD_IDX_T ShareRedmOp_Bp4Amt                       = 70;
FIELD_IDX_T ShareRedmOp_Bp5TpId                      = 71;
FIELD_IDX_T ShareRedmOp_Bp5CurrId                    = 72;
FIELD_IDX_T ShareRedmOp_Bp5Amt                       = 73;
FIELD_IDX_T ShareRedmOp_Bp6TpId                      = 74;
FIELD_IDX_T ShareRedmOp_Bp6CurrId                    = 75;
FIELD_IDX_T ShareRedmOp_Bp6Amt                       = 76;
FIELD_IDX_T ShareRedmOp_Bp7TpId                      = 77;
FIELD_IDX_T ShareRedmOp_Bp7CurrId                    = 78;
FIELD_IDX_T ShareRedmOp_Bp7Amt                       = 79;
FIELD_IDX_T ShareRedmOp_Bp8TpId                      = 80;
FIELD_IDX_T ShareRedmOp_Bp8CurrId                    = 81;
FIELD_IDX_T ShareRedmOp_Bp8Amt                       = 82;
FIELD_IDX_T ShareRedmOp_Bp9TpId                      = 83;
FIELD_IDX_T ShareRedmOp_Bp9CurrId                    = 84;
FIELD_IDX_T ShareRedmOp_Bp9Amt                       = 85;
FIELD_IDX_T ShareRedmOp_Bp10TpId                     = 86;
FIELD_IDX_T ShareRedmOp_Bp10CurrId                   = 87;
FIELD_IDX_T ShareRedmOp_Bp10Amt                      = 88;
FIELD_IDX_T ShareRedmOp_FlowId                       = 89;
FIELD_IDX_T ShareRedmOp_InitExtPosId                 = 90;
FIELD_IDX_T ShareRedmOp_LastUserId                   = 91;
FIELD_IDX_T ShareRedmOp_LastModifDate                = 92;
FIELD_IDX_T ShareRedmOp_CreationTime                 = 93;
FIELD_IDX_T ShareRedmOp_SysCurrId                    = 94;
FIELD_IDX_T ShareRedmOp_FundValId                    = 95;
FIELD_IDX_T ShareRedmOp_ConfirmedFlg                 = 96;
FIELD_IDX_T ShareRedmOp_FctResultId                  = 97;
FIELD_IDX_T ShareRedmOp_OrderModeTypeId			     = 98; /*<REF11810-BRO-060608*/
FIELD_IDX_T ShareRedmOp_TraderMgrId					 = 99;
FIELD_IDX_T ShareRedmOp_AutoRenewalEn			     = 100;
FIELD_IDX_T ShareRedmOp_RenewalTreatmtEn			 = 101;
FIELD_IDX_T ShareRedmOp_RenewalEndValDate		     = 102;
FIELD_IDX_T ShareRedmOp_RenewalLength			     = 103;
FIELD_IDX_T ShareRedmOp_RenewalLengthUnitEn		     = 104;
FIELD_IDX_T ShareRedmOp_ClientInitEn				 = 105;
FIELD_IDX_T ShareRedmOp_ContractNumber				 = 106;
FIELD_IDX_T ShareRedmOp_TransactionNatEn			 = 107; /*>REF11810-BRO-060608*/
FIELD_IDX_T ShareRedmOp_RenewalIntRate               = 108; /*REF11810-BRO-060628*/
FIELD_IDX_T ShareRedmOp_RenewalAmount                = 109; /*REF11810-BRO-060628*/
FIELD_IDX_T ShareRedmOp_TargetNatureEn               = 110; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_TargetNumber                 = 111; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_TargetAmount                 = 112; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_MarketSegmentId              = 113; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_FactSheetEn                  = 114; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_LastQuoteDate                = 115; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_LastQuoteNumber              = 116; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_LastPriceNumber              = 117; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_CommunicationDate            = 118; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_CommunicationTypeId          = 119; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_CommPartyTypeId              = 120; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareRedmOp_Remark1                      = 121; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_Remark2                      = 122; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_Remark3                      = 123; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_TransmissionDate             = 124; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_TransmissionTypeId           = 125; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_OrderTypeId                  = 126; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_MMInterestAmount             = 127; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_FxMarketRate                 = 128; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_FxClientRate                 = 129; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareRedmOp_FxRateDirection              = 130; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ShareRedmOp_InterestMarketRate           = 131; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_DebitToSysCurrRate           = 132; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_CreditToSysCurrRate          = 133; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_ContractLengthNumber         = 134; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_ContractLengthUnitEn         = 135; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ShareRedmOp_FxMarginNumber               = 136; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareRedmOp_FxMarginPrct                 = 137; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareRedmOp_FxMarginAmount               = 138; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareRedmOp_ExtOpId                      = 139;
FIELD_IDX_T ShareRedmOp_ExtOp_Ext                    = 140;
FIELD_IDX_T ShareRedmOp_AutoIndex                    = 141;
FIELD_IDX_T ShareRedmOp_ExtOpDbId                    = 142;
FIELD_IDX_T ShareRedmOp_BeginDate                    = 143;
FIELD_IDX_T ShareRedmOp_EndDate                      = 144;
FIELD_IDX_T ShareRedmOp_DraftOrderId                 = 145; /* REF8500 - 040510 - PMO */
FIELD_IDX_T ShareRedmOp_Summary                      = 146; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ShareRedmOp_TimeStamp                    = 147; /* REF11780 - 100406 - PMO */
FIELD_IDX_T ShareRedmOp_DerivativeOrdEn				 = 148; /* OCS43683-CHU-131112 */
FIELD_IDX_T ShareRedmOp_FxFarLegAmount				 = 149; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareRedmOp_FxSpotQuote				     = 150; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareRedmOp_FxQuote					     = 151; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareRedmOp_OrderFeeEn				     = 152; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ShareRedmOp_OrderFeePrct				 = 153; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ShareRedmOp_FxSpotLegAmount			     = 154; /* OCS43532-CHU-131112 */
FIELD_IDX_T ShareRedmOp_MaxOrderQty					 = 155; /*OCS-43526-CHU-131213*/
FIELD_IDX_T ShareRedmOp_STPOrderEn					 = 156; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T ShareRedmOp_UnpaidPrct					 = 157; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T ShareRedmOp_EventStatusId                = 158; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T ShareRedmOp_EventActionEn                = 159; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T ShareRedmOp_CompoundOrderMasterEltId	 = 160;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareRedmOp_CompoundOrderSlaveEltId		 = 161; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareRedmOp_CompoundOrderCode			 = 162; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareRedmOp_CompoundOrderSlaveNbr		 = 163; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareRedmOp_CompoundImpactRule		     = 164; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ShareRedmOp_DisplayCondition			 = 165;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ShareRedmOp_OrderType					 = 166;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ShareRedmOp_CommonRef                    = 167; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T ShareRedmOp_OrderInclusionEn             = 168; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareRedmOp_OrderRejectionDate           = 169; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareRedmOp_OrderRejectionComment        = 170; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ShareRedmOp_AcquisitionDate              = 171; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareRedmOp_CorporateActionNatEn         = 172; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareRedmOp_TaxLotSourceCd               = 174; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ShareRedmOp_StandInstructId              = 175; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T ShareRedmOp_BankFeePrct                  = 176; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareRedmOp_BankFeeAmount                = 177; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareRedmOp_BankFeeCurrId                = 178; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ShareRedmOp_PaymentOption                = 179; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T ShareRedmOp_BidTypeEn                    = 180; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid1Qty                      = 181; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid1Quote                    = 182; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid2Qty                      = 183; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid2Quote                    = 184; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid3Qty                      = 185; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_Bid3Quote                    = 186; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ShareRedmOp_OpFusionRuleEn               = 187; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ShareRedmOp_GlobalPosFlg                 = 188; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ShareRedmOp_OtcOrderEn					 = 189;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ShareRedmOp_DefaultFusRuleEn			 = 190;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ShareRedmOp_CoolCancelEndDate            = 191; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T ShareRedmOp_FusionPrioEn                 = 192; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T ShareRedmOp_ExternalBankBic              = 193; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareRedmOp_ExternalBankName             = 194; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareRedmOp_ExternalBankAcctOwnrName     = 195; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T ShareRedmOp_HedgeTradeEn                 = 196; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T ShareRedmOp_FixingDate                   = 197; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr1       = 198; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr2       = 199; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr3       = 200; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr4       = 201; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_PayRef1                      = 202; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_PayRef2                      = 203; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_PayRef3                      = 204; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_PayRef4                      = 205; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ShareRedmOp_ExternalTradeFlg             = 206; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T ShareRedmOp_OriginalQty					 = 207;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T ShareRedmOp_OrderNettingEn				 = 208;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T ShareRedmOp_PaymentDate                  = 209; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareRedmOp_PaymentStatusEn              = 210; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareRedmOp_SettlementDate               = 211; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ShareRedmOp_SettleStatusEn               = 212; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	ShareRedmOp_CommissionCdEn               = 213;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_ChargeCdEn                   = 214;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_OriginalAmount               = 215;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_CounterpartOrgAmount         = 216;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_ExternalFeeM                 = 217;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_TotalChargesM                = 218;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_CounterpartAmount            = 219;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_OpLinkageCd                  = 220;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ShareRedmOp_ChargedCustomerName          = 221;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T ShareRedmOp_BoPtfId                      = 222; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T ShareRedmOp_BoAccountId                  = 223; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_OpSplitRuleEn                = 224; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_AdjBoPtfId                   = 225; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_CoaExDate                    = 226; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_BoCashAcctId                 = 227; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_BoCashPtfId                  = 228; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_SplitParentOperId            = 229; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ShareRedmOp_OriginalNetAmount			 = 230;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	ShareRedmOp_SplitParOpCd				 = 231;	/* PMSTA-40714 */
FIELD_IDX_T ShareRedmOp_RuleApplicabilityEn			 = 232; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareRedmOp_SmartRoundingQty			 = 233; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareRedmOp_SmartRoundingOrgQty			 = 234; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareRedmOp_RoundingOrgQty				 = 235; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareRedmOp_SmartRoundingFlg			 = 236; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ShareRedmOp_SmartRoundingRuleId			 = 237; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	ShareRedmOp_HierOperNatEn                = 238; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	ShareRedmOp_HierOperationCd              = 239; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	ShareRedmOp_NotionalInstrId              = 240;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	ShareRedmOp_InvestLimitEn                = 241;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T ShareRedmOp_SetOfFeesId					 = 242; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ShareRedmOp_SetOfProductFeesId			 = 243; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ShareRedmOp_BoRoutingBusEntityId		 = 244; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T ShareRedmOp_OrderSubTypeId               = 245; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	ShareRedmOp_SetOfOtherFeesId             = 246; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	ShareRedmOp_TraderThirdId                = 247; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	ShareRedmOp_NetSettleAmount              = 248; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T TransfOp_Id                              = 0;
FIELD_IDX_T TransfOp_Cd                              = 1;
FIELD_IDX_T TransfOp_InputUserId                     = 2;
FIELD_IDX_T TransfOp_TpId                            = 3;
FIELD_IDX_T TransfOp_SubTpId                         = 4;
FIELD_IDX_T TransfOp_MktThirdId                      = 5;
FIELD_IDX_T TransfOp_IntermThirdId                   = 6;
FIELD_IDX_T TransfOp_MgrId                           = 7;
FIELD_IDX_T TransfOp_RuleId                          = 8;
FIELD_IDX_T TransfOp_ValRuleId                       = 9;
FIELD_IDX_T TransfOp_ValRuleHistId                   = 10;
FIELD_IDX_T TransfOp_ValRuleEltId                    = 11;
FIELD_IDX_T TransfOp_SrcCd                           = 12;
FIELD_IDX_T TransfOp_SubPosNatEn                     = 13;
FIELD_IDX_T TransfOp_SubPosNat2En                    = 14;
FIELD_IDX_T TransfOp_SubPosNat3En                    = 15;
FIELD_IDX_T TransfOp_LimitQuote                      = 16;
FIELD_IDX_T TransfOp_LimitPrice                      = 17;
FIELD_IDX_T TransfOp_StopQuote                       = 18;
FIELD_IDX_T TransfOp_StopPrice                       = 19;
FIELD_IDX_T TransfOp_OrderPriceNatEn                 = 20;
FIELD_IDX_T TransfOp_OrderValidNatEn                 = 21;
FIELD_IDX_T TransfOp_MinOrderQty                     = 22;
FIELD_IDX_T TransfOp_ParOpCd                         = 23;
FIELD_IDX_T TransfOp_ParOpNatEn                      = 24;
FIELD_IDX_T TransfOp_CheckParentEn                   = 25;
FIELD_IDX_T TransfOp_OrderNatEn                      = 26;
FIELD_IDX_T TransfOp_AcctDate                        = 27;
FIELD_IDX_T TransfOp_OpDate                          = 28;
FIELD_IDX_T TransfOp_ValuationDate                   = 29;
FIELD_IDX_T TransfOp_OrderLimitDate                  = 30;
FIELD_IDX_T TransfOp_ValueDate                       = 31;
FIELD_IDX_T TransfOp_RefOpCd                         = 32;
FIELD_IDX_T TransfOp_RefNatEn                        = 33;
FIELD_IDX_T TransfOp_StatusEn                        = 34;
FIELD_IDX_T TransfOp_SequenceNo                      = 35;
FIELD_IDX_T TransfOp_AcctCd                          = 36;
FIELD_IDX_T TransfOp_PtfId                           = 37;
FIELD_IDX_T TransfOp_PortPosSetId                    = 38;
FIELD_IDX_T TransfOp_InstrId                         = 39;
FIELD_IDX_T TransfOp_BalPosTpId                      = 40;
FIELD_IDX_T TransfOp_DepoId                          = 41;
FIELD_IDX_T TransfOp_OpCurrId                        = 42;
FIELD_IDX_T TransfOp_InstrCurrId                     = 43;
FIELD_IDX_T TransfOp_PtfCurrId                       = 44;
FIELD_IDX_T TransfOp_TradeCurrId                     = 45;
FIELD_IDX_T TransfOp_CntPtyThirdId                   = 46;
FIELD_IDX_T TransfOp_TermTpId                        = 47;
FIELD_IDX_T TransfOp_LockTpId                        = 48;
FIELD_IDX_T TransfOp_AccrIntrBpTpId                  = 49;
FIELD_IDX_T TransfOp_ExecOpId                        = 50;
FIELD_IDX_T TransfOp_ExecOpCd                        = 51;
FIELD_IDX_T TransfOp_ExecOpNatEn                     = 52;
FIELD_IDX_T TransfOp_ExecOpStatEn                    = 53;
FIELD_IDX_T TransfOp_RevOpCd                         = 54;
FIELD_IDX_T TransfOp_RevOpNatEn                      = 55;
FIELD_IDX_T TransfOp_LockOpCd                        = 56;
FIELD_IDX_T TransfOp_LockNatEn                       = 57;
FIELD_IDX_T TransfOp_EvtCd                           = 58;
FIELD_IDX_T TransfOp_EvtNbr                          = 59;
FIELD_IDX_T TransfOp_ExCouponFlg                     = 60;
FIELD_IDX_T TransfOp_FusRuleEn                       = 61;
FIELD_IDX_T TransfOp_LockLimitDate                   = 62;
FIELD_IDX_T TransfOp_ExpirDate                       = 63;
FIELD_IDX_T TransfOp_Remark                          = 64;
FIELD_IDX_T TransfOp_OpExchRate                      = 65;
FIELD_IDX_T TransfOp_InstrExchRate                   = 66;
FIELD_IDX_T TransfOp_SysExchRate                     = 67;
FIELD_IDX_T TransfOp_TradeExchRate                   = 68;
FIELD_IDX_T TransfOp_HistOpExchRate                  = 69;
FIELD_IDX_T TransfOp_HistInstrExchRate               = 70;
FIELD_IDX_T TransfOp_HistSysExchRate                 = 71;
FIELD_IDX_T TransfOp_BookOpExchRate                  = 72;
FIELD_IDX_T TransfOp_BookInstrExchRate               = 73;
FIELD_IDX_T TransfOp_BookSysExchRate                 = 74;
FIELD_IDX_T TransfOp_Qty                             = 75;
FIELD_IDX_T TransfOp_Price                           = 76;
FIELD_IDX_T TransfOp_SpotPrice                       = 77;
FIELD_IDX_T TransfOp_HistPrice                       = 78;
FIELD_IDX_T TransfOp_BookPrice                       = 79;
FIELD_IDX_T TransfOp_PriceCalcRuleEn                 = 80;
FIELD_IDX_T TransfOp_Quote                           = 81;
FIELD_IDX_T TransfOp_SpotQuote                       = 82;
FIELD_IDX_T TransfOp_HistQuote                       = 83;
FIELD_IDX_T TransfOp_BookQuote                       = 84;
FIELD_IDX_T TransfOp_Rate                            = 85;
FIELD_IDX_T TransfOp_SupplAmt                        = 86;
FIELD_IDX_T TransfOp_OpGrossAmt                      = 87;
FIELD_IDX_T TransfOp_AccrIntrAmt                     = 88;
FIELD_IDX_T TransfOp_OpNetAmt                        = 89;
FIELD_IDX_T TransfOp_InstrNetAmt                     = 90;
FIELD_IDX_T TransfOp_PtfNetAmt                       = 91;
FIELD_IDX_T TransfOp_SysNetAmt                       = 92;
FIELD_IDX_T TransfOp_HistOpNetAmt                    = 93;
FIELD_IDX_T TransfOp_HistInstrNetAmt                 = 94;
FIELD_IDX_T TransfOp_HistPtfNetAmt                   = 95;
FIELD_IDX_T TransfOp_HistSysNetAmt                   = 96;
FIELD_IDX_T TransfOp_BookOpNetAmt                    = 97;
FIELD_IDX_T TransfOp_BookInstrNetAmt                 = 98;
FIELD_IDX_T TransfOp_BookPtfNetAmt                   = 99;
FIELD_IDX_T TransfOp_BookSysNetAmt                   = 100;
FIELD_IDX_T TransfOp_Bp1TpId                         = 101;
FIELD_IDX_T TransfOp_Bp1CurrId                       = 102;
FIELD_IDX_T TransfOp_Bp1Amt                          = 103;
FIELD_IDX_T TransfOp_Bp2TpId                         = 104;
FIELD_IDX_T TransfOp_Bp2CurrId                       = 105;
FIELD_IDX_T TransfOp_Bp2Amt                          = 106;
FIELD_IDX_T TransfOp_Bp3TpId                         = 107;
FIELD_IDX_T TransfOp_Bp3CurrId                       = 108;
FIELD_IDX_T TransfOp_Bp3Amt                          = 109;
FIELD_IDX_T TransfOp_Bp4TpId                         = 110;
FIELD_IDX_T TransfOp_Bp4CurrId                       = 111;
FIELD_IDX_T TransfOp_Bp4Amt                          = 112;
FIELD_IDX_T TransfOp_Bp5TpId                         = 113;
FIELD_IDX_T TransfOp_Bp5CurrId                       = 114;
FIELD_IDX_T TransfOp_Bp5Amt                          = 115;
FIELD_IDX_T TransfOp_Bp6TpId                         = 116;
FIELD_IDX_T TransfOp_Bp6CurrId                       = 117;
FIELD_IDX_T TransfOp_Bp6Amt                          = 118;
FIELD_IDX_T TransfOp_Bp7TpId                         = 119;
FIELD_IDX_T TransfOp_Bp7CurrId                       = 120;
FIELD_IDX_T TransfOp_Bp7Amt                          = 121;
FIELD_IDX_T TransfOp_Bp8TpId                         = 122;
FIELD_IDX_T TransfOp_Bp8CurrId                       = 123;
FIELD_IDX_T TransfOp_Bp8Amt                          = 124;
FIELD_IDX_T TransfOp_Bp9TpId                         = 125;
FIELD_IDX_T TransfOp_Bp9CurrId                       = 126;
FIELD_IDX_T TransfOp_Bp9Amt                          = 127;
FIELD_IDX_T TransfOp_Bp10TpId                        = 128;
FIELD_IDX_T TransfOp_Bp10CurrId                      = 129;
FIELD_IDX_T TransfOp_Bp10Amt                         = 130;
FIELD_IDX_T TransfOp_FlowId                          = 131;
FIELD_IDX_T TransfOp_InitExtPosId                    = 132;
FIELD_IDX_T TransfOp_LastUserId                      = 133;
FIELD_IDX_T TransfOp_LastModifDate                   = 134;
FIELD_IDX_T TransfOp_CreationTime                    = 135;
FIELD_IDX_T TransfOp_SysCurrId                       = 136;
FIELD_IDX_T TransfOp_ConfirmedFlg                    = 137;
FIELD_IDX_T TransfOp_FctResultId                     = 138;
FIELD_IDX_T TransfOp_OrderModeTypeId			     = 139; /*<REF11810-BRO-060608*/
FIELD_IDX_T TransfOp_TraderMgrId					 = 140;
FIELD_IDX_T TransfOp_AutoRenewalEn					 = 141;
FIELD_IDX_T TransfOp_RenewalTreatmtEn				 = 142;
FIELD_IDX_T TransfOp_RenewalEndValDate				 = 143;
FIELD_IDX_T TransfOp_RenewalLength					 = 144;
FIELD_IDX_T TransfOp_RenewalLengthUnitEn		     = 145;
FIELD_IDX_T TransfOp_ClientInitEn					 = 146;
FIELD_IDX_T TransfOp_ContractNumber					 = 147;
FIELD_IDX_T TransfOp_TransactionNatEn				 = 148; /*>REF11810-BRO-060608*/
FIELD_IDX_T TransfOp_RenewalIntRate                  = 149; /*REF11810-BRO-060628*/
FIELD_IDX_T TransfOp_RenewalAmount                   = 150; /*REF11810-BRO-060628*/
FIELD_IDX_T TransfOp_TargetNatureEn                  = 151; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_TargetNumber                    = 152; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_TargetAmount                    = 153; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_MarketSegmentId                 = 154; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_FactSheetEn                     = 155; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_LastQuoteDate                   = 156; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_LastQuoteNumber                 = 157; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_LastPriceNumber                 = 158; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_CommunicationDate               = 159; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_CommunicationTypeId             = 160; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_CommPartyTypeId                 = 161; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T TransfOp_Remark1                         = 162; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_Remark2                         = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_Remark3                         = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_TransmissionDate                = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_TransmissionTypeId              = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_OrderTypeId                     = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_MMInterestAmount                = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_FxMarketRate                    = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_FxClientRate                    = 170; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T TransfOp_FxRateDirection                 = 171; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T TransfOp_InterestMarketRate              = 172; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_DebitToSysCurrRate              = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_CreditToSysCurrRate             = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_ContractLengthNumber            = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_ContractLengthUnitEn            = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T TransfOp_FxMarginNumber                  = 177; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T TransfOp_FxMarginPrct                    = 178; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T TransfOp_FxMarginAmount                  = 179; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T TransfOp_ExtOpId                         = 180;
FIELD_IDX_T TransfOp_ExtOp_Ext                       = 181;
FIELD_IDX_T TransfOp_AutoIndex                       = 182;
FIELD_IDX_T TransfOp_ExtOpDbId                       = 183;
FIELD_IDX_T TransfOp_BeginDate                       = 184;
FIELD_IDX_T TransfOp_EndDate                         = 185;
FIELD_IDX_T TransfOp_DraftOrderId                    = 186; /* REF8500 - 040510 - PMO */
FIELD_IDX_T TransfOp_Summary                         = 187; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T TransfOp_TimeStamp                       = 188; /* REF11780 - 100406 - PMO */
FIELD_IDX_T TransfOp_DerivativeOrdEn				 = 189; /* OCS43683-CHU-131112 */
FIELD_IDX_T TransfOp_FxFarLegAmount					 = 190; /* OCS43532-CHU-131112 */
FIELD_IDX_T TransfOp_FxSpotQuote				     = 191; /* OCS43532-CHU-131112 */
FIELD_IDX_T TransfOp_FxQuote					     = 192; /* OCS43532-CHU-131112 */
FIELD_IDX_T TransfOp_OrderFeeEn					     = 193; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T TransfOp_OrderFeePrct					 = 194; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T TransfOp_FxSpotLegAmount			     = 195; /* OCS43532-CHU-131112 */
FIELD_IDX_T TransfOp_MaxOrderQty					 = 196; /*OCS-43526-CHU-131213*/
FIELD_IDX_T TransfOp_STPOrderEn						 = 197; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T TransfOp_UnpaidPrct						 = 198; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T TransfOp_EventStatusId                   = 199; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T TransfOp_EventActionEn                   = 200; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T TransfOp_CompoundOrderMasterEltId		 = 201;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T TransfOp_CompoundOrderSlaveEltId		 = 202; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T TransfOp_CompoundOrderCode				 = 203; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T TransfOp_CompoundOrderSlaveNbr			 = 204; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T TransfOp_CompoundImpactRule				 = 205; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T TransfOp_DisplayCondition				 = 206;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T TransfOp_OrderType						 = 207;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T TransfOp_CommonRef                       = 208; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T TransfOp_OrderInclusionEn                = 209; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T TransfOp_OrderRejectionDate              = 210; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T TransfOp_OrderRejectionComment           = 211; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T TransfOp_AcquisitionDate                 = 212; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T TransfOp_CorporateActionNatEn            = 213; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T TransfOp_TaxLotSourceCd                  = 214; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T TransfOp_StandInstructId                 = 215; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T TransfOp_BankFeePrct                     = 216; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T TransfOp_BankFeeAmount                   = 217; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T TransfOp_BankFeeCurrId                   = 218; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T TransfOp_PaymentOption                   = 219; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T TransfOp_BidTypeEn                       = 220; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid1Qty                         = 221; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid1Quote                       = 222; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid2Qty                         = 223; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid2Quote                       = 224; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid3Qty                         = 225; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_Bid3Quote                       = 226; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T TransfOp_OpFusionRuleEn                  = 227; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T TransfOp_GlobalPosFlg                    = 228; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T TransfOp_OtcOrderEn						 = 229;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T TransfOp_DefaultFusRuleEn				 = 230;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T TransfOp_CoolCancelEndDate               = 231; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T TransfOp_FusionPrioEn                    = 232; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T TransfOp_ExternalBankBic                 = 233; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T TransfOp_ExternalBankName                = 234; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T TransfOp_ExternalBankAcctOwnrName        = 235; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T TransfOp_HedgeTradeEn                    = 236; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T TransfOp_FixingDate                      = 237; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr1          = 238; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr2          = 239; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr3          = 240; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr4          = 241; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_PayRef1                         = 242; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_PayRef2                         = 243; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_PayRef3                         = 244; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_PayRef4                         = 245; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T TransfOp_ExternalTradeFlg                = 246; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	TransfOp_OriginalQty					 = 247;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	TransfOp_OrderNettingEn					 = 248;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T TransfOp_PaymentDate                     = 249; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T TransfOp_PaymentStatusEn                 = 250; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T TransfOp_SettlementDate                  = 251; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T TransfOp_SettleStatusEn                  = 252; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	TransfOp_CommissionCdEn                  = 253;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_ChargeCdEn                      = 254;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_OriginalAmount                  = 255;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_CounterpartOrgAmount            = 256;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_ExternalFeeM                    = 257;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_TotalChargesM                   = 258;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_CounterpartAmount               = 259;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_OpLinkageCd                     = 260;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	TransfOp_ChargedCustomerName             = 261;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T TransfOp_BoPtfId                         = 262; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T TransfOp_BoAccountId                     = 263; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_OpSplitRuleEn                   = 264; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_AdjBoPtfId                      = 265; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_CoaExDate                       = 266; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_BoCashAcctId                    = 267; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_BoCashPtfId                     = 268; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_SplitParentOperId               = 269; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	TransfOp_OriginalNetAmount				 = 270;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	TransfOp_SplitParOpCd					 = 271;	/* PMSTA-40714  */
FIELD_IDX_T TransfOp_RuleApplicabilityEn			 = 272; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T TransfOp_SmartRoundingQty				 = 273; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T TransfOp_SmartRoundingOrgQty			 = 274; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T TransfOp_RoundingOrgQty					 = 275; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T TransfOp_SmartRoundingFlg				 = 276; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T TransfOp_SmartRoundingRuleId			 = 277; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	TransfOp_HierOperNatEn                   = 278; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	TransfOp_HierOperationCd                 = 279; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	TransfOp_NotionalInstrId                 = 280;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	TransfOp_InvestLimitEn                   = 281;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T TransfOp_SetOfFeesId					 = 282; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T TransfOp_SetOfProductFeesId				 = 283; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T TransfOp_BoRoutingBusEntityId			 = 284; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T TransfOp_OrderSubTypeId                  = 285; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	TransfOp_SetOfOtherFeesId                = 286; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	TransfOp_TraderThirdId                   = 287; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	TransfOp_NetSettleAmount                 = 288; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T BpTransfOp_Id                            = 0;
FIELD_IDX_T BpTransfOp_Cd                            = 1;
FIELD_IDX_T BpTransfOp_InputUserId                   = 2;
FIELD_IDX_T BpTransfOp_TpId                          = 3;
FIELD_IDX_T BpTransfOp_SubTpId                       = 4;
FIELD_IDX_T BpTransfOp_MktThirdId                    = 5;
FIELD_IDX_T BpTransfOp_IntermThirdId                 = 6;
FIELD_IDX_T BpTransfOp_MgrId                         = 7;
FIELD_IDX_T BpTransfOp_RuleId                        = 8;
FIELD_IDX_T BpTransfOp_SrcCd                         = 9;
FIELD_IDX_T BpTransfOp_ParOpCd                       = 10;
FIELD_IDX_T BpTransfOp_ParOpNatEn                    = 11;
FIELD_IDX_T BpTransfOp_CheckParentEn                 = 12;
FIELD_IDX_T BpTransfOp_AcctDate                      = 13;
FIELD_IDX_T BpTransfOp_OpDate                        = 14;
FIELD_IDX_T BpTransfOp_ValuationDate                 = 15;
FIELD_IDX_T BpTransfOp_ValueDate                     = 16;
FIELD_IDX_T BpTransfOp_RefOpCd                       = 17;
FIELD_IDX_T BpTransfOp_RefNatEn                      = 18;
FIELD_IDX_T BpTransfOp_StatusEn                      = 19;
FIELD_IDX_T BpTransfOp_SequenceNo                    = 20;
FIELD_IDX_T BpTransfOp_AcctCd                        = 21;
FIELD_IDX_T BpTransfOp_PtfId                         = 22;
FIELD_IDX_T BpTransfOp_PortPosSetId                  = 23;
FIELD_IDX_T BpTransfOp_InstrId                       = 24;
FIELD_IDX_T BpTransfOp_ToInstrId                     = 25;
FIELD_IDX_T BpTransfOp_FromBpTpId                    = 26;
FIELD_IDX_T BpTransfOp_ToBpTpId                      = 27;
FIELD_IDX_T BpTransfOp_PtfCurrId                     = 28;
FIELD_IDX_T BpTransfOp_InstrCurrId                   = 29;
FIELD_IDX_T BpTransfOp_ToInstrCurrId                 = 30;
FIELD_IDX_T BpTransfOp_ExecOpId                      = 31;
FIELD_IDX_T BpTransfOp_ExecOpCd                      = 32;
FIELD_IDX_T BpTransfOp_ExecOpNatEn                   = 33;
FIELD_IDX_T BpTransfOp_ExecOpStatEn                  = 34;
FIELD_IDX_T BpTransfOp_RevOpCd                       = 35;
FIELD_IDX_T BpTransfOp_RevOpNatEn                    = 36;
FIELD_IDX_T BpTransfOp_FusRuleEn                     = 37;
FIELD_IDX_T BpTransfOp_Remark                        = 38;
FIELD_IDX_T BpTransfOp_SysExchRate                   = 39;
FIELD_IDX_T BpTransfOp_PtfNetAmt                     = 40;
FIELD_IDX_T BpTransfOp_SysNetAmt                     = 41;
FIELD_IDX_T BpTransfOp_FlowId                        = 42;
FIELD_IDX_T BpTransfOp_InitExtPosId                  = 43;
FIELD_IDX_T BpTransfOp_LastUserId                    = 44;
FIELD_IDX_T BpTransfOp_LastModifDate                 = 45;
FIELD_IDX_T BpTransfOp_CreationTime                  = 46;
FIELD_IDX_T BpTransfOp_SysCurrId                     = 47;
FIELD_IDX_T BpTransfOp_ConfirmedFlg                  = 48;
FIELD_IDX_T BpTransfOp_FctResultId                   = 49;
FIELD_IDX_T BpTransfOp_OrderModeTypeId			     = 50; /*<REF11810-BRO-060608*/
FIELD_IDX_T BpTransfOp_TraderMgrId					 = 51;
FIELD_IDX_T BpTransfOp_AutoRenewalEn				 = 52;
FIELD_IDX_T BpTransfOp_RenewalTreatmtEn				 = 53;
FIELD_IDX_T BpTransfOp_RenewalEndValDate			 = 54;
FIELD_IDX_T BpTransfOp_RenewalLength				 = 55;
FIELD_IDX_T BpTransfOp_RenewalLengthUnitEn		     = 56;
FIELD_IDX_T BpTransfOp_ClientInitEn					 = 57;
FIELD_IDX_T BpTransfOp_ContractNumber				 = 58;
FIELD_IDX_T BpTransfOp_TransactionNatEn				 = 59; /*>REF11810-BRO-060608*/
FIELD_IDX_T BpTransfOp_RenewalIntRate                = 60; /*REF11810-BRO-060628*/
FIELD_IDX_T BpTransfOp_RenewalAmount                 = 61; /*REF11810-BRO-060628*/
FIELD_IDX_T BpTransfOp_TargetNatureEn                = 62; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_TargetNumber                  = 63; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_TargetAmount                  = 64; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_MarketSegmentId               = 65; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_FactSheetEn                   = 66; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_LastQuoteDate                 = 67; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_LastQuoteNumber               = 68; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_LastPriceNumber               = 69; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_CommunicationDate             = 70; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_CommunicationTypeId           = 71; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_CommPartyTypeId               = 72; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BpTransfOp_Remark1                       = 73; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_Remark2                       = 74; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_Remark3                       = 75; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_TransmissionDate              = 76; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_TransmissionTypeId            = 77; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_OrderTypeId                   = 78; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_MMInterestAmount              = 79; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_FxMarketRate                  = 80; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_FxClientRate                  = 81; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BpTransfOp_FxRateDirection               = 82; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BpTransfOp_InterestMarketRate            = 83; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_DebitToSysCurrRate            = 84; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_CreditToSysCurrRate           = 85; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_ContractLengthNumber          = 86; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_ContractLengthUnitEn          = 87; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BpTransfOp_FxMarginNumber                = 88; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BpTransfOp_FxMarginPrct                  = 89; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BpTransfOp_FxMarginAmount                = 90; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BpTransfOp_ExtOpId                       = 91;
FIELD_IDX_T BpTransfOp_ExtOp_Ext                     = 92;
FIELD_IDX_T BpTransfOp_AutoIndex                     = 93;
FIELD_IDX_T BpTransfOp_ExtOpDbId                     = 94;
FIELD_IDX_T BpTransfOp_BeginDate                     = 95;
FIELD_IDX_T BpTransfOp_EndDate                       = 96;
FIELD_IDX_T BpTransfOp_DraftOrderId                  = 97; /* REF8500 - 040510 - PMO */
FIELD_IDX_T BpTransfOp_Summary                       = 98; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BpTransfOp_TimeStamp                     = 99; /* REF11780 - 100406 - PMO */
FIELD_IDX_T BpTransfOp_DerivativeOrdEn				 = 100; /* OCS43683-CHU-131112 */
FIELD_IDX_T BpTransfOp_FxFarLegAmount				 = 101; /* OCS43532-CHU-131112 */
FIELD_IDX_T BpTransfOp_FxSpotQuote				     = 102; /* OCS43532-CHU-131112 */
FIELD_IDX_T BpTransfOp_FxQuote					     = 103; /* OCS43532-CHU-131112 */
FIELD_IDX_T BpTransfOp_OrderFeeEn				     = 104; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BpTransfOp_OrderFeePrct					 = 105; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BpTransfOp_FxSpotLegAmount			     = 106; /* OCS43532-CHU-131112 */
FIELD_IDX_T BpTransfOp_MaxOrderQty					 = 107; /*OCS-43526-CHU-131213*/
FIELD_IDX_T BpTransfOp_STPOrderEn					 = 108; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T BpTransfOp_UnpaidPrct					 = 109; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T BpTransfOp_EventStatusId                 = 110; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T BpTransfOp_EventActionEn                 = 111; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T BpTransfOp_CompoundOrderMasterEltId		 = 112;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BpTransfOp_CompoundOrderSlaveEltId		 = 113; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BpTransfOp_CompoundOrderCode			 = 114; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BpTransfOp_CompoundOrderSlaveNbr		 = 115; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BpTransfOp_CompoundImpactRule			 = 116; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BpTransfOp_DisplayCondition				 = 117;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BpTransfOp_OrderType					 = 118;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BpTransfOp_CommonRef                     = 119; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T BpTransfOp_OrderInclusionEn              = 120; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BpTransfOp_OrderRejectionDate            = 121; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BpTransfOp_OrderRejectionComment         = 122; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BpTransfOp_AcquisitionDate               = 123; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BpTransfOp_CorporateActionNatEn          = 124; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BpTransfOp_TaxLotSourceCd                = 125; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BpTransfOp_StandInstructId               = 126; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T BpTransfOp_BankFeePrct                   = 127; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BpTransfOp_BankFeeAmount                 = 128; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BpTransfOp_BankFeeCurrId                 = 129; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BpTransfOp_PaymentOption                 = 130; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T BpTransfOp_BidTypeEn                     = 131; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid1Qty                       = 132; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid1Quote                     = 133; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid2Qty                       = 134; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid2Quote                     = 135; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid3Qty                       = 136; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_Bid3Quote                     = 137; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BpTransfOp_OpFusionRuleEn                = 138; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T BpTransfOp_GlobalPosFlg                  = 139; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T BpTransfOp_OtcOrderEn					 = 140;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T BpTransfOp_DefaultFusRuleEn				 = 141;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T BpTransfOp_CoolCancelEndDate             = 142; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T BpTransfOp_FusionPrioEn                  = 143; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T BpTransfOp_ExternalBankBic               = 144; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BpTransfOp_ExternalBankName              = 145; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BpTransfOp_ExternalBankAcctOwnrName      = 146; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BpTransfOp_HedgeTradeEn                  = 147; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T BpTransfOp_FixingDate                    = 148; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr1        = 149; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr2        = 150; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr3        = 151; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr4        = 152; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_PayRef1                       = 153; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_PayRef2                       = 154; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_PayRef3                       = 155; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_PayRef4                       = 156; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BpTransfOp_ExternalTradeFlg              = 157; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	BpTransfOp_OriginalQty					 = 158;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	BpTransfOp_OrderNettingEn				 = 159;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T BpTransfOp_PaymentDate                   = 160; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BpTransfOp_PaymentStatusEn               = 161; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BpTransfOp_SettlementDate                = 162; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BpTransfOp_SettleStatusEn                = 163; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	BpTransfOp_CommissionCdEn                = 164;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_ChargeCdEn                    = 165;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_OriginalAmount                = 166;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_CounterpartOrgAmount          = 167;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_ExternalFeeM                  = 168;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_TotalChargesM                 = 169;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_CounterpartAmount             = 170;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_OpLinkageCd                   = 171;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BpTransfOp_ChargedCustomerName           = 172;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T BpTransfOp_BoPtfId                       = 173; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T BpTransfOp_BoAccountId                   = 174; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_OpSplitRuleEn                 = 175; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_AdjBoPtfId                    = 176; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_CoaExDate                     = 177; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_BoCashAcctId                  = 178; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_BoCashPtfId                   = 179; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_SplitParentOperId             = 180; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BpTransfOp_OriginalNetAmount             = 181;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T BpTransfOp_SplitParOpCd					 = 182; /*PMSTA-40714*/
FIELD_IDX_T BpTransfOp_RuleApplicabilityEn			 = 183; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BpTransfOp_SmartRoundingQty				 = 184; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BpTransfOp_SmartRoundingOrgQty			 = 185; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BpTransfOp_RoundingOrgQty				 = 186; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BpTransfOp_SmartRoundingFlg				 = 187; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BpTransfOp_SmartRoundingRuleId			 = 188; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	BpTransfOp_HierOperNatEn                 = 189; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BpTransfOp_HierOperationCd               = 190; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BpTransfOp_NotionalInstrId               = 191;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	BpTransfOp_InvestLimitEn                 = 192; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T BpTransfOp_OrderSubTypeId                = 193; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	BpTransfOp_SetOfOtherFeesId              = 194; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	BpTransfOp_TraderThirdId                 = 195; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	BpTransfOp_NetSettleAmount               = 196; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T AdjustOp_Id                              = 0;
FIELD_IDX_T AdjustOp_Cd                              = 1;
FIELD_IDX_T AdjustOp_InputUserId                     = 2;
FIELD_IDX_T AdjustOp_TpId                            = 3;
FIELD_IDX_T AdjustOp_SubTpId                         = 4;
FIELD_IDX_T AdjustOp_MktThirdId                      = 5;
FIELD_IDX_T AdjustOp_IntermThirdId                   = 6;
FIELD_IDX_T AdjustOp_MgrId                           = 7;
FIELD_IDX_T AdjustOp_RuleId                          = 8;
FIELD_IDX_T AdjustOp_SrcCd                           = 9;
FIELD_IDX_T AdjustOp_SubPosNatEn                     = 10;
FIELD_IDX_T AdjustOp_SubPosNat2En                    = 11;
FIELD_IDX_T AdjustOp_SubPosNat3En                    = 12;
FIELD_IDX_T AdjustOp_AdjSubPosNatEn                  = 13;
FIELD_IDX_T AdjustOp_AdjSubPosNat2En                 = 14;
FIELD_IDX_T AdjustOp_AdjSubPosNat3En                 = 15;
FIELD_IDX_T AdjustOp_LockSubPosNatEn                 = 16;
FIELD_IDX_T AdjustOp_LockSubPosNat2En                = 17;
FIELD_IDX_T AdjustOp_LockSubPosNat3En                = 18;
FIELD_IDX_T AdjustOp_ParOpCd                         = 19;
FIELD_IDX_T AdjustOp_ParOpNatEn                      = 20;
FIELD_IDX_T AdjustOp_CheckParentEn                   = 21;
FIELD_IDX_T AdjustOp_AcctDate                        = 22;
FIELD_IDX_T AdjustOp_OpDate                          = 23;
FIELD_IDX_T AdjustOp_ValuationDate                   = 24;
FIELD_IDX_T AdjustOp_ValueDate                       = 25;
FIELD_IDX_T AdjustOp_RefOpCd                         = 26;
FIELD_IDX_T AdjustOp_RefNatEn                        = 27;
FIELD_IDX_T AdjustOp_StatusEn                        = 28;
FIELD_IDX_T AdjustOp_SequenceNo                      = 29;
FIELD_IDX_T AdjustOp_AcctCd                          = 30;
FIELD_IDX_T AdjustOp_PtfId                           = 31;
FIELD_IDX_T AdjustOp_CashPtfId                       = 32;
FIELD_IDX_T AdjustOp_InstrId                         = 33;
FIELD_IDX_T AdjustOp_AcctId                          = 34;
FIELD_IDX_T AdjustOp_Acct2Id                         = 35;
FIELD_IDX_T AdjustOp_Acct3Id                         = 36;
FIELD_IDX_T AdjustOp_LockInstrId                     = 37;
FIELD_IDX_T AdjustOp_DepoId                          = 38;
FIELD_IDX_T AdjustOp_LockDepoId                      = 39;
FIELD_IDX_T AdjustOp_AdjInstrId                      = 40;
FIELD_IDX_T AdjustOp_AdjDepoId                       = 41;
FIELD_IDX_T AdjustOp_AdjBpTpId                       = 42;
FIELD_IDX_T AdjustOp_OpCurrId                        = 43;
FIELD_IDX_T AdjustOp_InstrCurrId                     = 44;
FIELD_IDX_T AdjustOp_PtfCurrId                       = 45;
FIELD_IDX_T AdjustOp_AcctCurrId                      = 46;
FIELD_IDX_T AdjustOp_Acct2CurrId                     = 47;
FIELD_IDX_T AdjustOp_Acct3CurrId                     = 48;
FIELD_IDX_T AdjustOp_TradeCurrId                     = 49;
FIELD_IDX_T AdjustOp_CashPtfCurrId                   = 50;
FIELD_IDX_T AdjustOp_AdjInstrCurrId                  = 51;
FIELD_IDX_T AdjustOp_AdjPosCurrId                    = 52;
FIELD_IDX_T AdjustOp_LockOpCurrId                    = 53;
FIELD_IDX_T AdjustOp_LockFiCurrId                    = 54;
FIELD_IDX_T AdjustOp_CntPtyThirdId                   = 55;
FIELD_IDX_T AdjustOp_TermTpId                        = 56;
FIELD_IDX_T AdjustOp_LockTpId                        = 57;
FIELD_IDX_T AdjustOp_AccrIntrBpTpId                  = 58;
FIELD_IDX_T AdjustOp_AdjNatEn                        = 59;
FIELD_IDX_T AdjustOp_ExecOpId                        = 60;
FIELD_IDX_T AdjustOp_ExecOpCd                        = 61;
FIELD_IDX_T AdjustOp_ExecOpNatEn                     = 62;
FIELD_IDX_T AdjustOp_ExecOpStatEn                    = 63;
FIELD_IDX_T AdjustOp_RevOpCd                         = 64;
FIELD_IDX_T AdjustOp_RevOpNatEn                      = 65;
FIELD_IDX_T AdjustOp_LockOpCd                        = 66;
FIELD_IDX_T AdjustOp_LockNatEn                       = 67;
FIELD_IDX_T AdjustOp_EvtCd                           = 68;
FIELD_IDX_T AdjustOp_EvtNbr                          = 69;
FIELD_IDX_T AdjustOp_ExCouponFlg                     = 70;
FIELD_IDX_T AdjustOp_FusRuleEn                       = 71;
FIELD_IDX_T AdjustOp_LockLimitDate                   = 72;
FIELD_IDX_T AdjustOp_ExpirDate                       = 73;
FIELD_IDX_T AdjustOp_Remark                          = 74;
FIELD_IDX_T AdjustOp_OpExchRate                      = 75;
FIELD_IDX_T AdjustOp_InstrExchRate                   = 76;
FIELD_IDX_T AdjustOp_SysExchRate                     = 77;
FIELD_IDX_T AdjustOp_AcctExchRate                    = 78;
FIELD_IDX_T AdjustOp_Acct2ExchRate                   = 79;
FIELD_IDX_T AdjustOp_Acct3ExchRate                   = 80;
FIELD_IDX_T AdjustOp_TradeExchRate                   = 81;
FIELD_IDX_T AdjustOp_CashPtfExchRate                 = 82;
FIELD_IDX_T AdjustOp_AdjInstrExchRate                = 83;
FIELD_IDX_T AdjustOp_AdjPosExchRate                  = 84;
FIELD_IDX_T AdjustOp_LockOpExchRate                  = 85;
FIELD_IDX_T AdjustOp_LockFiExchRate                  = 86;
FIELD_IDX_T AdjustOp_AdjQty                          = 87;
FIELD_IDX_T AdjustOp_Qty                             = 88;
FIELD_IDX_T AdjustOp_LockQty                         = 89;
FIELD_IDX_T AdjustOp_Price                           = 90;
FIELD_IDX_T AdjustOp_SpotPrice                       = 91;
FIELD_IDX_T AdjustOp_LockDirtyPrice                  = 92;
FIELD_IDX_T AdjustOp_LockCleanPrice                  = 93;
FIELD_IDX_T AdjustOp_PriceCalcRuleEn                 = 94;
FIELD_IDX_T AdjustOp_Quote                           = 95;
FIELD_IDX_T AdjustOp_SpotQuote                       = 96;
FIELD_IDX_T AdjustOp_LockDirtyQuote                  = 97;
FIELD_IDX_T AdjustOp_LockCleanQuote                  = 98;
FIELD_IDX_T AdjustOp_Rate                            = 99;
FIELD_IDX_T AdjustOp_LockPriceMargin                 = 100;
FIELD_IDX_T AdjustOp_SupplAmt                        = 101;
FIELD_IDX_T AdjustOp_OpGrossAmt                      = 102;
FIELD_IDX_T AdjustOp_AccrIntrAmt                     = 103;
FIELD_IDX_T AdjustOp_OpNetAmt                        = 104;
FIELD_IDX_T AdjustOp_InstrNetAmt                     = 105;
FIELD_IDX_T AdjustOp_PtfNetAmt                       = 106;
FIELD_IDX_T AdjustOp_SysNetAmt                       = 107;
FIELD_IDX_T AdjustOp_AcctNetAmt                      = 108;
FIELD_IDX_T AdjustOp_Acct2NetAmt                     = 109;
FIELD_IDX_T AdjustOp_Acct3NetAmt                     = 110;
FIELD_IDX_T AdjustOp_Bp1TpId                         = 111;
FIELD_IDX_T AdjustOp_Bp1CurrId                       = 112;
FIELD_IDX_T AdjustOp_Bp1Amt                          = 113;
FIELD_IDX_T AdjustOp_Bp2TpId                         = 114;
FIELD_IDX_T AdjustOp_Bp2CurrId                       = 115;
FIELD_IDX_T AdjustOp_Bp2Amt                          = 116;
FIELD_IDX_T AdjustOp_Bp3TpId                         = 117;
FIELD_IDX_T AdjustOp_Bp3CurrId                       = 118;
FIELD_IDX_T AdjustOp_Bp3Amt                          = 119;
FIELD_IDX_T AdjustOp_Bp4TpId                         = 120;
FIELD_IDX_T AdjustOp_Bp4CurrId                       = 121;
FIELD_IDX_T AdjustOp_Bp4Amt                          = 122;
FIELD_IDX_T AdjustOp_Bp5TpId                         = 123;
FIELD_IDX_T AdjustOp_Bp5CurrId                       = 124;
FIELD_IDX_T AdjustOp_Bp5Amt                          = 125;
FIELD_IDX_T AdjustOp_Bp6TpId                         = 126;
FIELD_IDX_T AdjustOp_Bp6CurrId                       = 127;
FIELD_IDX_T AdjustOp_Bp6Amt                          = 128;
FIELD_IDX_T AdjustOp_Bp7TpId                         = 129;
FIELD_IDX_T AdjustOp_Bp7CurrId                       = 130;
FIELD_IDX_T AdjustOp_Bp7Amt                          = 131;
FIELD_IDX_T AdjustOp_Bp8TpId                         = 132;
FIELD_IDX_T AdjustOp_Bp8CurrId                       = 133;
FIELD_IDX_T AdjustOp_Bp8Amt                          = 134;
FIELD_IDX_T AdjustOp_Bp9TpId                         = 135;
FIELD_IDX_T AdjustOp_Bp9CurrId                       = 136;
FIELD_IDX_T AdjustOp_Bp9Amt                          = 137;
FIELD_IDX_T AdjustOp_Bp10TpId                        = 138;
FIELD_IDX_T AdjustOp_Bp10CurrId                      = 139;
FIELD_IDX_T AdjustOp_Bp10Amt                         = 140;
FIELD_IDX_T AdjustOp_FlowId                          = 141;
FIELD_IDX_T AdjustOp_InitExtPosId                    = 142;
FIELD_IDX_T AdjustOp_LastUserId                      = 143;
FIELD_IDX_T AdjustOp_LastModifDate                   = 144;
FIELD_IDX_T AdjustOp_CreationTime                    = 145;
FIELD_IDX_T AdjustOp_SysCurrId                       = 146;
FIELD_IDX_T AdjustOp_ConfirmedFlg                    = 147;
FIELD_IDX_T AdjustOp_FctResultId                     = 148;
FIELD_IDX_T AdjustOp_OrderModeTypeId			     = 149; /*<REF11810-BRO-060608*/
FIELD_IDX_T AdjustOp_TraderMgrId				     = 150;
FIELD_IDX_T AdjustOp_AutoRenewalEn			         = 151;
FIELD_IDX_T AdjustOp_RenewalTreatmtEn			     = 152;
FIELD_IDX_T AdjustOp_RenewalEndValDate		         = 153;
FIELD_IDX_T AdjustOp_RenewalLength			         = 154;
FIELD_IDX_T AdjustOp_RenewalLengthUnitEn		     = 155;
FIELD_IDX_T AdjustOp_ClientInitEn				     = 156;
FIELD_IDX_T AdjustOp_ContractNumber			         = 157;
FIELD_IDX_T AdjustOp_TransactionNatEn			     = 158; /*>REF11810-BRO-060608*/
FIELD_IDX_T AdjustOp_RenewalIntRate                  = 159; /*REF11810-BRO-060628*/
FIELD_IDX_T AdjustOp_RenewalAmount                   = 160; /*REF11810-BRO-060628*/
FIELD_IDX_T AdjustOp_TargetNatureEn                  = 161; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_TargetNumber                    = 162; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_TargetAmount                    = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_MarketSegmentId                 = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_FactSheetEn                     = 165; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_LastQuoteDate                   = 166; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_LastQuoteNumber                 = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_LastPriceNumber                 = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_CommunicationDate               = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_CommunicationTypeId             = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_CommPartyTypeId                 = 171; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T AdjustOp_Remark1                         = 172; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_Remark2                         = 173; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_Remark3                         = 174; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_TransmissionDate                = 175; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_TransmissionTypeId              = 176; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_OrderTypeId                     = 177; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_MMInterestAmount                = 178; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_FxMarketRate                    = 179; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_FxClientRate                    = 180; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T AdjustOp_FxRateDirection                 = 181; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T AdjustOp_InterestMarketRate              = 182; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_DebitToSysCurrRate              = 183; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_CreditToSysCurrRate             = 184; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_ContractLengthNumber            = 185; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_ContractLengthUnitEn            = 186; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T AdjustOp_FxMarginNumber                  = 187; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T AdjustOp_FxMarginPrct                    = 188; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T AdjustOp_FxMarginAmount                  = 189; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T AdjustOp_ExtOpId                         = 190;
FIELD_IDX_T AdjustOp_ExtOp_Ext                       = 191;
FIELD_IDX_T AdjustOp_AutoIndex                       = 192;
FIELD_IDX_T AdjustOp_ExtOpDbId                       = 193;
FIELD_IDX_T AdjustOp_BeginDate                       = 194;
FIELD_IDX_T AdjustOp_EndDate                         = 195;
FIELD_IDX_T AdjustOp_DraftOrderId                    = 196; /* REF8500 - 040510 - PMO */
FIELD_IDX_T AdjustOp_Summary                         = 197; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T AdjustOp_TimeStamp                       = 198; /* REF11780 - 100406 - PMO */
FIELD_IDX_T AdjustOp_DerivativeOrdEn				 = 199; /* OCS43683-CHU-131112 */
FIELD_IDX_T AdjustOp_FxFarLegAmount					 = 200; /* OCS43532-CHU-131112 */
FIELD_IDX_T AdjustOp_FxSpotQuote				     = 201; /* OCS43532-CHU-131112 */
FIELD_IDX_T AdjustOp_FxQuote					     = 202; /* OCS43532-CHU-131112 */
FIELD_IDX_T AdjustOp_OrderFeeEn					     = 203; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T AdjustOp_OrderFeePrct					 = 204; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T AdjustOp_FxSpotLegAmount			     = 205; /* OCS43532-CHU-131112 */
FIELD_IDX_T AdjustOp_MaxOrderQty					 = 206; /*OCS-43526-CHU-131213*/
FIELD_IDX_T AdjustOp_STPOrderEn						 = 207; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T AdjustOp_UnpaidPrct						 = 208; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T AdjustOp_EventStatusId                   = 209; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T AdjustOp_EventActionEn                   = 210; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T AdjustOp_CompoundOrderMasterEltId	     = 211;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T AdjustOp_CompoundOrderSlaveEltId		 = 212; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T AdjustOp_CompoundOrderCode				 = 213; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T AdjustOp_CompoundOrderSlaveNbr			 = 214; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T AdjustOp_CompoundImpactRule				 = 215; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T AdjustOp_DisplayCondition				 = 216;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T AdjustOp_OrderType						 = 217;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T AdjustOp_CommonRef                       = 218; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T AdjustOp_OrderInclusionEn                = 219; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T AdjustOp_OrderRejectionDate              = 220; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T AdjustOp_OrderRejectionComment           = 221; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T AdjustOp_AcquisitionDate                 = 222; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T AdjustOp_CorporateActionNatEn            = 223; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T AdjustOp_TaxLotSourceCd                  = 224; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T AdjustOp_StandInstructId                 = 225; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T AdjustOp_BankFeePrct                     = 226; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T AdjustOp_BankFeeAmount                   = 227; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T AdjustOp_BankFeeCurrId                   = 228; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T AdjustOp_PaymentOption                   = 229; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T AdjustOp_BidTypeEn                       = 230; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid1Qty                         = 231; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid1Quote                       = 232; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid2Qty                         = 233; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid2Quote                       = 234; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid3Qty                         = 235; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_Bid3Quote                       = 236; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T AdjustOp_OpFusionRuleEn                  = 237; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T AdjustOp_GlobalPosFlg                    = 238; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T AdjustOp_AdjPosGrossAmt                  = 239; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T AdjustOp_OtcOrderEn						 = 240;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T AdjustOp_DefaultFusRuleEn				 = 241;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T AdjustOp_CoolCancelEndDate               = 242; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T AdjustOp_FusionPrioEn                    = 243; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T AdjustOp_ExternalBankBic                 = 244; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T AdjustOp_ExternalBankName                = 245; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T AdjustOp_ExternalBankAcctOwnrName        = 246; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T AdjustOp_HedgeTradeEn                    = 247; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T AdjustOp_FixingDate                      = 248; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr1          = 249; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr2          = 250; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr3          = 251; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr4          = 252; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_PayRef1                         = 253; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_PayRef2                         = 254; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_PayRef3                         = 255; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_PayRef4                         = 256; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T AdjustOp_ExternalTradeFlg                = 257; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T AdjustOp_OriginalQty					 = 258;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T AdjustOp_OrderNettingEn					 = 259;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T AdjustOp_PaymentDate                     = 260; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T AdjustOp_PaymentStatusEn                 = 261; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T AdjustOp_SettlementDate                  = 262; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T AdjustOp_SettleStatusEn                  = 263; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	AdjustOp_CommissionCdEn                  = 264;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_ChargeCdEn                      = 265;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_OriginalAmount                  = 266;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_CounterpartOrgAmount            = 267;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_ExternalFeeM                    = 268;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_TotalChargesM                   = 269;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_CounterpartAmount               = 270;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_OpLinkageCd                     = 271;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	AdjustOp_ChargedCustomerName             = 272;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T AdjustOp_BoPtfId                         = 273; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T AdjustOp_BoAccountId                     = 274; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_OpSplitRuleEn                   = 275; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_AdjBoPtfId                      = 276; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_CoaExDate                       = 277; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_BoCashAcctId                    = 278; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_BoCashPtfId                     = 279; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_SplitParentOperId               = 280; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	AdjustOp_OriginalNetAmount               = 281;	/* PMSTA-39927 - cha - 04292020 */
FIELD_IDX_T AdjustOp_SplitParOpCd					 = 282; /*PMSTA-40714 */
FIELD_IDX_T AdjustOp_RuleApplicabilityEn			 = 283; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T AdjustOp_SmartRoundingQty				 = 284; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T AdjustOp_SmartRoundingOrgQty			 = 285; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T AdjustOp_RoundingOrgQty					 = 286; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T AdjustOp_SmartRoundingFlg				 = 287; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T AdjustOp_SmartRoundingRuleId			 = 288; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	AdjustOp_HierOperNatEn                   = 289; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	AdjustOp_HierOperationCd                 = 290; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	AdjustOp_NotionalInstrId                 = 291;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	AdjustOp_InvestLimitEn                   = 292;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T AdjustOp_AdjRefNatEn                     = 293; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T AdjustOp_AdjRefOperCd                    = 294; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T AdjustOp_SetOfFeesId                     = 295; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T AdjustOp_SetOfProductFeesId              = 296; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T AdjustOp_BoRoutingBusEntityId			 = 297; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T AdjustOp_OrderSubTypeId                  = 298; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	AdjustOp_SetOfOtherFeesId                = 299; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	AdjustOp_TraderThirdId                   = 300; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	AdjustOp_NetSettleAmount                 = 301; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T FtOp_Id                                  = 0;
FIELD_IDX_T FtOp_Cd                                  = 1;
FIELD_IDX_T FtOp_InputUserId                         = 2;
FIELD_IDX_T FtOp_TpId                                = 3;
FIELD_IDX_T FtOp_SubTpId                             = 4;
FIELD_IDX_T FtOp_MktThirdId                          = 5;
FIELD_IDX_T FtOp_IntermThirdId                       = 6;
FIELD_IDX_T FtOp_MgrId                               = 7;
FIELD_IDX_T FtOp_RuleId                              = 8;
FIELD_IDX_T FtOp_SrcCd                               = 9;
FIELD_IDX_T FtOp_ParOpCd                             = 10;
FIELD_IDX_T FtOp_ParOpNatEn                          = 11;
FIELD_IDX_T FtOp_CheckParentEn                       = 12;
FIELD_IDX_T FtOp_AcctDate                            = 13;
FIELD_IDX_T FtOp_OpDate                              = 14;
FIELD_IDX_T FtOp_ValueDate                           = 15;
FIELD_IDX_T FtOp_RefOpCd                             = 16;
FIELD_IDX_T FtOp_RefNatEn                            = 17;
FIELD_IDX_T FtOp_StatusEn                            = 18;
FIELD_IDX_T FtOp_SequenceNo                          = 19;
FIELD_IDX_T FtOp_AcctCd                              = 20;
FIELD_IDX_T FtOp_PtfId                               = 21;
FIELD_IDX_T FtOp_DepoId                              = 22;
FIELD_IDX_T FtOp_CashPtfId                           = 23;
FIELD_IDX_T FtOp_AcctId                              = 24;
FIELD_IDX_T FtOp_Acct2Id                             = 25;
FIELD_IDX_T FtOp_Acct3Id                             = 26;
FIELD_IDX_T FtOp_BpTpId                              = 27;
FIELD_IDX_T FtOp_OpCurrId                            = 28;
FIELD_IDX_T FtOp_PtfCurrId                           = 29;
FIELD_IDX_T FtOp_AcctCurrId                          = 30;
FIELD_IDX_T FtOp_Acct2CurrId                         = 31;
FIELD_IDX_T FtOp_Acct3CurrId                         = 32;
FIELD_IDX_T FtOp_CashPtfCurrId                       = 33;
FIELD_IDX_T FtOp_CntPtyThirdId                       = 34;
FIELD_IDX_T FtOp_ExecOpId                            = 35;
FIELD_IDX_T FtOp_ExecOpCd                            = 36;
FIELD_IDX_T FtOp_ExecOpNatEn                         = 37;
FIELD_IDX_T FtOp_ExecOpStatEn                        = 38;
FIELD_IDX_T FtOp_RevOpCd                             = 39;
FIELD_IDX_T FtOp_RevOpNatEn                          = 40;
FIELD_IDX_T FtOp_EvtCd                               = 41;
FIELD_IDX_T FtOp_EvtNbr                              = 42;
FIELD_IDX_T FtOp_FusRuleEn                           = 43;
FIELD_IDX_T FtOp_Remark                              = 44;
FIELD_IDX_T FtOp_OpExchRate                          = 45;
FIELD_IDX_T FtOp_SysExchRate                         = 46;
FIELD_IDX_T FtOp_AcctExchRate                        = 47;
FIELD_IDX_T FtOp_Acct2ExchRate                       = 48;
FIELD_IDX_T FtOp_Acct3ExchRate                       = 49;
FIELD_IDX_T FtOp_CashPtfExchRate                     = 50;
FIELD_IDX_T FtOp_OpNetAmt                            = 51;
FIELD_IDX_T FtOp_OpGrossAmt                          = 52;
FIELD_IDX_T FtOp_PtfNetAmt                           = 53;
FIELD_IDX_T FtOp_SysNetAmt                           = 54;
FIELD_IDX_T FtOp_AcctNetAmt                          = 55;
FIELD_IDX_T FtOp_Acct2NetAmt                         = 56;
FIELD_IDX_T FtOp_Acct3NetAmt                         = 57;
FIELD_IDX_T FtOp_Bp1TpId                             = 58;
FIELD_IDX_T FtOp_Bp1CurrId                           = 59;
FIELD_IDX_T FtOp_Bp1Amt                              = 60;
FIELD_IDX_T FtOp_Bp2TpId                             = 61;
FIELD_IDX_T FtOp_Bp2CurrId                           = 62;
FIELD_IDX_T FtOp_Bp2Amt                              = 63;
FIELD_IDX_T FtOp_Bp3TpId                             = 64;
FIELD_IDX_T FtOp_Bp3CurrId                           = 65;
FIELD_IDX_T FtOp_Bp3Amt                              = 66;
FIELD_IDX_T FtOp_Bp4TpId                             = 67;
FIELD_IDX_T FtOp_Bp4CurrId                           = 68;
FIELD_IDX_T FtOp_Bp4Amt                              = 69;
FIELD_IDX_T FtOp_Bp5TpId                             = 70;
FIELD_IDX_T FtOp_Bp5CurrId                           = 71;
FIELD_IDX_T FtOp_Bp5Amt                              = 72;
FIELD_IDX_T FtOp_Bp6TpId                             = 73;
FIELD_IDX_T FtOp_Bp6CurrId                           = 74;
FIELD_IDX_T FtOp_Bp6Amt                              = 75;
FIELD_IDX_T FtOp_Bp7TpId                             = 76;
FIELD_IDX_T FtOp_Bp7CurrId                           = 77;
FIELD_IDX_T FtOp_Bp7Amt                              = 78;
FIELD_IDX_T FtOp_Bp8TpId                             = 79;
FIELD_IDX_T FtOp_Bp8CurrId                           = 80;
FIELD_IDX_T FtOp_Bp8Amt                              = 81;
FIELD_IDX_T FtOp_Bp9TpId                             = 82;
FIELD_IDX_T FtOp_Bp9CurrId                           = 83;
FIELD_IDX_T FtOp_Bp9Amt                              = 84;
FIELD_IDX_T FtOp_Bp10TpId                            = 85;
FIELD_IDX_T FtOp_Bp10CurrId                          = 86;
FIELD_IDX_T FtOp_Bp10Amt                             = 87;
FIELD_IDX_T FtOp_FlowId                              = 88;
FIELD_IDX_T FtOp_InitExtPosId                        = 89;
FIELD_IDX_T FtOp_LastUserId                          = 90;
FIELD_IDX_T FtOp_LastModifDate                       = 91;
FIELD_IDX_T FtOp_CreationTime                        = 92;
FIELD_IDX_T FtOp_SysCurrId                           = 93;
FIELD_IDX_T FtOp_ConfirmedFlg                        = 94;
FIELD_IDX_T FtOp_FctResultId                         = 95;
FIELD_IDX_T FtOp_OrderModeTypeId					 = 96; /*<REF11810-BRO-060608*/
FIELD_IDX_T FtOp_TraderMgrId						 = 97;
FIELD_IDX_T FtOp_AutoRenewalEn						 = 98;
FIELD_IDX_T FtOp_RenewalTreatmtEn					 = 99;
FIELD_IDX_T FtOp_RenewalEndValDate					 = 100;
FIELD_IDX_T FtOp_RenewalLength						 = 101;
FIELD_IDX_T FtOp_RenewalLengthUnitEn				 = 102;
FIELD_IDX_T FtOp_ClientInitEn						 = 103;
FIELD_IDX_T FtOp_ContractNumber						 = 104;
FIELD_IDX_T FtOp_TransactionNatEn					 = 105; /*>REF11810-BRO-060608*/
FIELD_IDX_T FtOp_RenewalIntRate                      = 106; /*REF11810-BRO-060628*/
FIELD_IDX_T FtOp_RenewalAmount                       = 107; /*REF11810-BRO-060628*/
FIELD_IDX_T FtOp_TargetNatureEn                      = 108; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_TargetNumber                        = 109; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_TargetAmount                        = 110; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_MarketSegmentId                     = 111; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_FactSheetEn                         = 112; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_LastQuoteDate                       = 113; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_LastQuoteNumber                     = 114; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_LastPriceNumber                     = 115; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_CommunicationDate                   = 116; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_CommunicationTypeId                 = 117; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_CommPartyTypeId                     = 118; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T FtOp_Remark1                             = 119; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_Remark2                             = 120; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_Remark3                             = 121; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_TransmissionDate                    = 122; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_TransmissionTypeId                  = 123; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_OrderTypeId                         = 124; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_MMInterestAmount                    = 125; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_FxMarketRate                        = 126; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_FxClientRate                        = 127; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T FtOp_FxRateDirection                     = 128; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T FtOp_InterestMarketRate                  = 129; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_DebitToSysCurrRate                  = 130; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_CreditToSysCurrRate                 = 131; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_ContractLengthNumber                = 132; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_ContractLengthUnitEn                = 133; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T FtOp_FxMarginNumber                      = 134; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T FtOp_FxMarginPrct                        = 135; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T FtOp_FxMarginAmount                      = 136; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T FtOp_ExtOpId                             = 137;
FIELD_IDX_T FtOp_ExtOp_Ext                           = 138;
FIELD_IDX_T FtOp_AutoIndex                           = 139;
FIELD_IDX_T FtOp_ExtOpDbId                           = 140;
FIELD_IDX_T FtOp_BeginDate                           = 141;
FIELD_IDX_T FtOp_EndDate                             = 142;
FIELD_IDX_T FtOp_DraftOrderId                        = 143; /* REF8500 - 040510 - PMO */
FIELD_IDX_T FtOp_Summary                             = 144; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T FtOp_TimeStamp                           = 145; /* REF11780 - 100406 - PMO */
FIELD_IDX_T FtOp_DerivativeOrdEn					 = 146; /* OCS43683-CHU-131112 */
FIELD_IDX_T FtOp_FxFarLegAmount						 = 147; /* OCS43532-CHU-131112 */
FIELD_IDX_T FtOp_FxSpotQuote					     = 148; /* OCS43532-CHU-131112 */
FIELD_IDX_T FtOp_FxQuote						     = 149; /* OCS43532-CHU-131112 */
FIELD_IDX_T FtOp_OrderFeeEn						     = 150; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T FtOp_OrderFeePrct						 = 151; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T FtOp_FxSpotLegAmount				     = 152; /* OCS43532-CHU-131112 */
FIELD_IDX_T FtOp_MaxOrderQty						 = 153; /*OCS-43526-CHU-131213*/
FIELD_IDX_T FtOp_STPOrderEn							 = 154; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T FtOp_UnpaidPrct							 = 155; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T FtOp_EventStatusId                       = 156; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T FtOp_EventActionEn                       = 157; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T FtOp_CompoundOrderMasterEltId			 = 158;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T FtOp_CompoundOrderSlaveEltId			 = 159; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T FtOp_CompoundOrderCode					 = 160; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T FtOp_CompoundOrderSlaveNbr				 = 161; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T FtOp_CompoundImpactRule					 = 162; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T FtOp_DisplayCondition					 = 163;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T FtOp_OrderType							 = 164;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T FtOp_CommonRef                           = 165; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T FtOp_OrderInclusionEn                    = 166; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T FtOp_OrderRejectionDate                  = 167; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T FtOp_OrderRejectionComment               = 168; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T FtOp_AcquisitionDate                     = 169; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T FtOp_CorporateActionNatEn                = 170; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T FtOp_TaxLotSourceCd                      = 171; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T FtOp_StandInstructId                     = 172; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T FtOp_BankFeePrct                         = 173; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T FtOp_BankFeeAmount                       = 174; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T FtOp_BankFeeCurrId                       = 175; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T FtOp_PaymentOption                       = 176; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T FtOp_BidTypeEn                           = 177; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid1Qty                             = 178; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid1Quote                           = 179; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid2Qty                             = 180; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid2Quote                           = 181; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid3Qty                             = 182; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_Bid3Quote                           = 183; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T FtOp_OpFusionRuleEn                      = 184; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T FtOp_GlobalPosFlg                        = 185; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T FtOp_OtcOrderEn							 = 186;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T FtOp_DefaultFusRuleEn					 = 187;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T FtOp_CoolCancelEndDate                   = 188; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T FtOp_FusionPrioEn                       = 189; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T FtOp_ExternalBankBic                     = 190; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T FtOp_ExternalBankName                    = 191; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T FtOp_ExternalBankAcctOwnrName            = 192; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T FtOp_HedgeTradeEn                        = 193; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T FtOp_FixingDate                          = 194; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr1              = 195; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr2              = 196; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr3              = 197; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr4              = 198; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_PayRef1                             = 199; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_PayRef2                             = 200; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_PayRef3                             = 201; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_PayRef4                             = 202; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T FtOp_ExternalTradeFlg                    = 203; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	FtOp_OriginalQty						 = 204;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	FtOp_OrderNettingEn						 = 205;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T FtOp_PaymentDate                         = 206; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T FtOp_PaymentStatusEn                     = 207; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T FtOp_SettlementDate                      = 208; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T FtOp_SettleStatusEn                      = 209; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	FtOp_CommissionCdEn                      = 210;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_ChargeCdEn                          = 211;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_OriginalAmount                      = 212;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_CounterpartOrgAmount                = 213;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_ExternalFeeM                        = 214;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_TotalChargesM                       = 215;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_CounterpartAmount                   = 216;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_OpLinkageCd                         = 217;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	FtOp_ChargedCustomerName                 = 218;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T FtOp_BoPtfId                             = 219; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T FtOp_BoAccountId                         = 220; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_OpSplitRuleEn                       = 221;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_AdjBoPtfId                          = 222;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_CoaExDate                           = 223;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_BoCashAcctId                        = 224;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_BoCashPtfId                         = 225;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_SplitParentOperId                   = 226;  /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	FtOp_OriginalNetAmount					 = 227;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	FtOp_SplitParOpCd						 = 228;	/* PMSTA-40714 */
FIELD_IDX_T FtOp_RuleApplicabilityEn				 = 229; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T FtOp_SmartRoundingQty					 = 230; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T FtOp_SmartRoundingOrgQty				 = 231; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T FtOp_RoundingOrgQty						 = 232; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T FtOp_SmartRoundingFlg					 = 233; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T FtOp_SmartRoundingRuleId				 = 234; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	FtOp_HierOperNatEn                       = 235; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	FtOp_HierOperationCd                     = 236; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	FtOp_NotionalInstrId                     = 237;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	FtOp_InvestLimitEn                       = 238;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T FtOp_SetOfFeesId					 	 = 239; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T FtOp_SetOfProductFeesId					 = 240; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T FtOp_BoRoutingBusEntityId				 = 241; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T FtOp_OrderSubTypeId                      = 242; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	FtOp_SetOfOtherFeesId                    = 243; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	FtOp_TraderThirdId                       = 244; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	FtOp_NetSettleAmount                     = 245; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T LockOp_Id                                = 0;
FIELD_IDX_T LockOp_Cd                                = 1;
FIELD_IDX_T LockOp_InputUserId                       = 2;
FIELD_IDX_T LockOp_TpId                              = 3;
FIELD_IDX_T LockOp_SubTpId                           = 4;
FIELD_IDX_T LockOp_MktThirdId                        = 5;
FIELD_IDX_T LockOp_IntermThirdId                     = 6;
FIELD_IDX_T LockOp_MgrId                             = 7;
FIELD_IDX_T LockOp_RuleId                            = 8;
FIELD_IDX_T LockOp_SrcCd                             = 9;
FIELD_IDX_T LockOp_SubPosNatEn                       = 10;
FIELD_IDX_T LockOp_SubPosNat2En                      = 11;
FIELD_IDX_T LockOp_SubPosNat3En                      = 12;
FIELD_IDX_T LockOp_ParOpCd                           = 13;
FIELD_IDX_T LockOp_ParOpNatEn                        = 14;
FIELD_IDX_T LockOp_CheckParentEn                     = 15;
FIELD_IDX_T LockOp_AcctDate                          = 16;
FIELD_IDX_T LockOp_OpDate                            = 17;
FIELD_IDX_T LockOp_ValueDate                         = 18;
FIELD_IDX_T LockOp_LockingLimitDate                  = 19;
FIELD_IDX_T LockOp_RefOpCd                           = 20;
FIELD_IDX_T LockOp_RefNatEn                          = 21;
FIELD_IDX_T LockOp_StatusEn                          = 22;
FIELD_IDX_T LockOp_SequenceNo                        = 23;
FIELD_IDX_T LockOp_AcctCd                            = 24;
FIELD_IDX_T LockOp_PtfId                             = 25;
FIELD_IDX_T LockOp_InstrId                           = 26;
FIELD_IDX_T LockOp_DepoId                            = 27;
FIELD_IDX_T LockOp_OpCurrId                          = 28;
FIELD_IDX_T LockOp_InstrCurrId                       = 29;
FIELD_IDX_T LockOp_PtfCurrId                         = 30;
FIELD_IDX_T LockOp_CntPtyThirdId                     = 31;
FIELD_IDX_T LockOp_LockTpId                          = 32;
FIELD_IDX_T LockOp_ExecOpId                          = 33;
FIELD_IDX_T LockOp_ExecOpCd                          = 34;
FIELD_IDX_T LockOp_ExecOpNatEn                       = 35;
FIELD_IDX_T LockOp_ExecOpStatEn                      = 36;
FIELD_IDX_T LockOp_RevOpCd                           = 37;
FIELD_IDX_T LockOp_RevOpNatEn                        = 38;
FIELD_IDX_T LockOp_LockOpCd                          = 39;
FIELD_IDX_T LockOp_LockNatEn                         = 40;
FIELD_IDX_T LockOp_EvtCd                             = 41;
FIELD_IDX_T LockOp_EvtNbr                            = 42;
FIELD_IDX_T LockOp_FusRuleEn                         = 43;
FIELD_IDX_T LockOp_Remark                            = 44;
FIELD_IDX_T LockOp_Qty                               = 45;
FIELD_IDX_T LockOp_FlowId                            = 46;
FIELD_IDX_T LockOp_InitExtPosId                      = 47;
FIELD_IDX_T LockOp_LastUserId                        = 48;
FIELD_IDX_T LockOp_LastModifDate                     = 49;
FIELD_IDX_T LockOp_CreationTime                      = 50;
FIELD_IDX_T LockOp_SysCurrId                         = 51;
FIELD_IDX_T LockOp_ConfirmedFlg                      = 52;
FIELD_IDX_T LockOp_FctResultId                       = 53;
FIELD_IDX_T LockOp_OrderModeTypeId					 = 54; /*<REF11810-BRO-060608*/
FIELD_IDX_T LockOp_TraderMgrId						 = 55;
FIELD_IDX_T LockOp_AutoRenewalEn					 = 56;
FIELD_IDX_T LockOp_RenewalTreatmtEn					 = 57;
FIELD_IDX_T LockOp_RenewalEndValDate			     = 58;
FIELD_IDX_T LockOp_RenewalLength					 = 59;
FIELD_IDX_T LockOp_RenewalLengthUnitEn				 = 60;
FIELD_IDX_T LockOp_ClientInitEn						 = 61;
FIELD_IDX_T LockOp_ContractNumber					 = 62;
FIELD_IDX_T LockOp_TransactionNatEn					 = 63; /*>REF11810-BRO-060608*/
FIELD_IDX_T LockOp_RenewalIntRate                    = 64; /*REF11810-BRO-060628*/
FIELD_IDX_T LockOp_RenewalAmount                     = 65; /*REF11810-BRO-060628*/
FIELD_IDX_T LockOp_TargetNatureEn                    = 66; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_TargetNumber                      = 67; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_TargetAmount                      = 68; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_MarketSegmentId                   = 69; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_FactSheetEn                       = 70; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_LastQuoteDate                     = 71; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_LastQuoteNumber                   = 72; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_LastPriceNumber                   = 73; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_CommunicationDate                 = 74; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_CommunicationTypeId               = 75; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_CommPartyTypeId                   = 76; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T LockOp_Remark1                           = 77; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_Remark2                           = 78; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_Remark3                           = 79; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_TransmissionDate                  = 80; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_TransmissionTypeId                = 81; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_OrderTypeId                       = 82; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_MMInterestAmount                  = 83; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_FxMarketRate                      = 84; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_FxClientRate                      = 85; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T LockOp_FxRateDirection                   = 86; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T LockOp_InterestMarketRate                = 87; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_DebitToSysCurrRate                = 88; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_CreditToSysCurrRate               = 89; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_ContractLengthNumber              = 90; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_ContractLengthUnitEn              = 91; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T LockOp_FxMarginNumber                    = 92; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T LockOp_FxMarginPrct                      = 93; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T LockOp_FxMarginAmount                    = 94; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T LockOp_ExtOpId                           = 95;
FIELD_IDX_T LockOp_ExtOp_Ext                         = 96;
FIELD_IDX_T LockOp_AutoIndex                         = 97;
FIELD_IDX_T LockOp_ExtOpDbId                         = 98;
FIELD_IDX_T LockOp_BeginDate                         = 99;
FIELD_IDX_T LockOp_EndDate                           = 100;
FIELD_IDX_T LockOp_DraftOrderId                      = 101; /* REF8500 - 040510 - PMO */
FIELD_IDX_T LockOp_Summary                           = 102; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T LockOp_TimeStamp                         = 103; /* REF11780 - 100406 - PMO */
FIELD_IDX_T LockOp_DerivativeOrdEn					 = 104; /* OCS43683-CHU-131112 */
FIELD_IDX_T LockOp_FxFarLegAmount					 = 105; /* OCS43532-CHU-131112 */
FIELD_IDX_T LockOp_FxSpotQuote					     = 106; /* OCS43532-CHU-131112 */
FIELD_IDX_T LockOp_FxQuote						     = 107; /* OCS43532-CHU-131112 */
FIELD_IDX_T LockOp_OrderFeeEn					     = 108; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T LockOp_OrderFeePrct						 = 109; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T LockOp_FxSpotLegAmount				     = 110; /* OCS43532-CHU-131112 */
FIELD_IDX_T LockOp_MaxOrderQty						 = 111; /*OCS-43526-CHU-131213*/
FIELD_IDX_T LockOp_STPOrderEn						 = 112; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T LockOp_UnpaidPrct						 = 113; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T LockOp_EventStatusId                     = 114; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T LockOp_EventActionEn                     = 115; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T LockOp_CompoundOrderMasterEltId		     = 116;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T LockOp_CompoundOrderSlaveEltId		     = 117; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T LockOp_CompoundOrderCode			     = 118; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T LockOp_CompoundOrderSlaveNbr		     = 119; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T LockOp_CompoundImpactRule			     = 120; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T LockOp_DisplayCondition				 	 = 121;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T LockOp_OrderType						 = 122;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T LockOp_CommonRef                         = 123; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T LockOp_OrderInclusionEn                  = 124; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T LockOp_OrderRejectionDate                = 125; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T LockOp_OrderRejectionComment             = 126; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T LockOp_AcquisitionDate                   = 127; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T LockOp_CorporateActionNatEn              = 128; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T LockOp_TaxLotSourceCd                    = 129; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T LockOp_StandInstructId                   = 130; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T LockOp_BankFeePrct                       = 131; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T LockOp_BankFeeAmount                     = 132; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T LockOp_BankFeeCurrId                     = 133; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T LockOp_PaymentOption                     = 134; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T LockOp_BidTypeEn                         = 135; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid1Qty                           = 136; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid1Quote                         = 137; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid2Qty                           = 138; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid2Quote                         = 139; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid3Qty                           = 140; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_Bid3Quote                         = 141; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T LockOp_OpFusionRuleEn                    = 142; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T LockOp_GlobalPosFlg                      = 143; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T LockOp_OtcOrderEn						 = 144;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T LockOp_DefaultFusRuleEn					 = 145;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T LockOp_CoolCancelEndDate                 = 146; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T LockOp_FusionPrioEn                      = 147; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T LockOp_ExternalBankBic                   = 148; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T LockOp_ExternalBankName                  = 149; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T LockOp_ExternalBankAcctOwnrName          = 150; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T LockOp_HedgeTradeEn                      = 151; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T LockOp_FixingDate                        = 152; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr1            = 153; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr2            = 154; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr3            = 155; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr4            = 156; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_PayRef1                           = 157; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_PayRef2                           = 158; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_PayRef3                           = 159; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_PayRef4                           = 160; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T LockOp_ExternalTradeFlg                  = 161; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	LockOp_OriginalQty						 = 162;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T LockOp_OrderNettingEn					 = 163;	/* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T LockOp_PaymentDate                       = 164; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T LockOp_PaymentStatusEn                   = 165; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T LockOp_SettlementDate                    = 166; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T LockOp_SettleStatusEn                    = 167; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	LockOp_CommissionCdEn                    = 168;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_ChargeCdEn                        = 169;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_OriginalAmount                    = 170;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_CounterpartOrgAmount              = 171;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_ExternalFeeM                      = 172;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_TotalChargesM                     = 173;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_CounterpartAmount                 = 174;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_OpLinkageCd                       = 175;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	LockOp_ChargedCustomerName               = 176;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T LockOp_BoPtfId                           = 177; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T LockOp_BoAccountId                       = 178; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_OpSplitRuleEn                     = 179; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_AdjBoPtfId                        = 180; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_CoaExDate                         = 181; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_BoCashAcctId                      = 182; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_BoCashPtfId                       = 183; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_SplitParentOperId                 = 184; /* PMSTA-38454 - srinivas   - 04022020 */
FIELD_IDX_T	LockOp_OriginalNetAmount				 = 185;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	LockOp_SplitParOpCd						 = 186;	/* PMSTA-40714 */
FIELD_IDX_T LockOp_RuleApplicabilityEn				 = 187; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T LockOp_SmartRoundingQty					 = 188; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T LockOp_SmartRoundingOrgQty				 = 189; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T LockOp_RoundingOrgQty					 = 190; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T LockOp_SmartRoundingFlg					 = 191; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T LockOp_SmartRoundingRuleId				 = 192; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	LockOp_HierOperNatEn                     = 193;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	LockOp_HierOperationCd                   = 194;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	LockOp_NotionalInstrId                   = 195;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	LockOp_InvestLimitEn                     = 196;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T LockOp_OrderSubTypeId                    = 197; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	LockOp_SetOfOtherFeesId                  = 198; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	LockOp_TraderThirdId                     = 199; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	LockOp_NetSettleAmount                   = 200; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T PtfTransfOp_Id                           = 0;
FIELD_IDX_T PtfTransfOp_Cd                           = 1;
FIELD_IDX_T PtfTransfOp_InputUserId                  = 2;
FIELD_IDX_T PtfTransfOp_TpId                         = 3;
FIELD_IDX_T PtfTransfOp_SubTpId                      = 4;
FIELD_IDX_T PtfTransfOp_MgrId                        = 5;
FIELD_IDX_T PtfTransfOp_RuleId                       = 6;
FIELD_IDX_T PtfTransfOp_SrcCd                        = 7;
FIELD_IDX_T PtfTransfOp_SubPosNatEn                  = 8;
FIELD_IDX_T PtfTransfOp_SubPosNat2En                 = 9;
FIELD_IDX_T PtfTransfOp_SubPosNat3En                 = 10;
FIELD_IDX_T PtfTransfOp_AdjSubPosNatEn               = 11;
FIELD_IDX_T PtfTransfOp_AdjSubPosNat2En              = 12;
FIELD_IDX_T PtfTransfOp_AdjSubPosNat3En              = 13;
FIELD_IDX_T PtfTransfOp_ParOpCd                      = 14;
FIELD_IDX_T PtfTransfOp_ParOpNatEn                   = 15;
FIELD_IDX_T PtfTransfOp_CheckParentEn                = 16;
FIELD_IDX_T PtfTransfOp_AcctDate                     = 17;
FIELD_IDX_T PtfTransfOp_OpDate                       = 18;
FIELD_IDX_T PtfTransfOp_ValueDate                    = 19;
FIELD_IDX_T PtfTransfOp_RefOpCd                      = 20;
FIELD_IDX_T PtfTransfOp_RefNatEn                     = 21;
FIELD_IDX_T PtfTransfOp_StatusEn                     = 22;
FIELD_IDX_T PtfTransfOp_SequenceNo                   = 23;
FIELD_IDX_T PtfTransfOp_AcctCd                       = 24;
FIELD_IDX_T PtfTransfOp_PtfId                        = 25;
FIELD_IDX_T PtfTransfOp_AdjPtfId                     = 26;
FIELD_IDX_T PtfTransfOp_InstrId                      = 27;
FIELD_IDX_T PtfTransfOp_BalPosTpId                   = 28;
FIELD_IDX_T PtfTransfOp_DepoId                       = 29;
FIELD_IDX_T PtfTransfOp_AdjDepoId                    = 30;
FIELD_IDX_T PtfTransfOp_AdjBpTpId                    = 31;
FIELD_IDX_T PtfTransfOp_OpCurrId                     = 32;
FIELD_IDX_T PtfTransfOp_InstrCurrId                  = 33;
FIELD_IDX_T PtfTransfOp_PtfCurrId                    = 34;
FIELD_IDX_T PtfTransfOp_AdjPosCurrId                 = 35;
FIELD_IDX_T PtfTransfOp_AdjPtfCurrId                 = 36;
FIELD_IDX_T PtfTransfOp_AccrBpTpId                   = 37;
FIELD_IDX_T PtfTransfOp_AdjNatEn                     = 38;
FIELD_IDX_T PtfTransfOp_ExecOpId                     = 39;
FIELD_IDX_T PtfTransfOp_ExecOpCd                     = 40;
FIELD_IDX_T PtfTransfOp_ExecOpNatEn                  = 41;
FIELD_IDX_T PtfTransfOp_ExecOpStatEn                 = 42;
FIELD_IDX_T PtfTransfOp_RevOpCd                      = 43;
FIELD_IDX_T PtfTransfOp_RevOpNatEn                   = 44;
FIELD_IDX_T PtfTransfOp_FusRuleEn                    = 45;
FIELD_IDX_T PtfTransfOp_Remark                       = 46;
FIELD_IDX_T PtfTransfOp_OpExchRate                   = 47;
FIELD_IDX_T PtfTransfOp_InstrExchRate                = 48;
FIELD_IDX_T PtfTransfOp_SysExchRate                  = 49;
FIELD_IDX_T PtfTransfOp_AdjPosExchRate               = 50;
FIELD_IDX_T PtfTransfOp_AdjPtfExchRate               = 51;
FIELD_IDX_T PtfTransfOp_Qty                          = 52;
FIELD_IDX_T PtfTransfOp_Price                        = 53;
FIELD_IDX_T PtfTransfOp_PriceCalcRuleEn              = 54;
FIELD_IDX_T PtfTransfOp_Quote                        = 55;
FIELD_IDX_T PtfTransfOp_SupplAmt                     = 56;
FIELD_IDX_T PtfTransfOp_OpGrossAmt                   = 57;
FIELD_IDX_T PtfTransfOp_AccrAmt                      = 58;
FIELD_IDX_T PtfTransfOp_OpNetAmt                     = 59;
FIELD_IDX_T PtfTransfOp_InstrNetAmt                  = 60;
FIELD_IDX_T PtfTransfOp_PtfNetAmt                    = 61;
FIELD_IDX_T PtfTransfOp_SysNetAmt                    = 62;
FIELD_IDX_T PtfTransfOp_AdjPosNetAmt                 = 63;
FIELD_IDX_T PtfTransfOp_AdjPtfNetAmt                 = 64;
FIELD_IDX_T PtfTransfOp_LastUserId                   = 65;
FIELD_IDX_T PtfTransfOp_LastModifDate                = 66;
FIELD_IDX_T PtfTransfOp_CreationTime                 = 67;
FIELD_IDX_T PtfTransfOp_SysCurrId                    = 68;
FIELD_IDX_T PtfTransfOp_ConfirmedFlg                 = 69;
FIELD_IDX_T PtfTransfOp_FctResultId                  = 70;
FIELD_IDX_T PtfTransfOp_OrderModeTypeId				 = 71; /*<REF11810-BRO-060608*/
FIELD_IDX_T PtfTransfOp_TraderMgrId					 = 72;
FIELD_IDX_T PtfTransfOp_AutoRenewalEn				 = 73;
FIELD_IDX_T PtfTransfOp_RenewalTreatmtEn			 = 74;
FIELD_IDX_T PtfTransfOp_RenewalEndValDate			 = 75;
FIELD_IDX_T PtfTransfOp_RenewalLength				 = 76;
FIELD_IDX_T PtfTransfOp_RenewalLengthUnitEn			 = 77;
FIELD_IDX_T PtfTransfOp_ClientInitEn				 = 78;
FIELD_IDX_T PtfTransfOp_ContractNumber				 = 79;
FIELD_IDX_T PtfTransfOp_TransactionNatEn			 = 80; /*>REF11810-BRO-060608*/
FIELD_IDX_T PtfTransfOp_RenewalIntRate               = 81; /*REF11810-BRO-060628*/
FIELD_IDX_T PtfTransfOp_RenewalAmount                = 82; /*REF11810-BRO-060628*/
FIELD_IDX_T PtfTransfOp_TargetNatureEn               = 83; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_TargetNumber                 = 84; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_TargetAmount                 = 85; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_MarketSegmentId              = 86; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_FactSheetEn                  = 87; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_LastQuoteDate                = 88; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_LastQuoteNumber              = 89; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_LastPriceNumber              = 90; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_CommunicationDate            = 91; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_CommunicationTypeId          = 92; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_CommPartyTypeId              = 93; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T PtfTransfOp_Remark1                      = 94; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_Remark2                      = 95; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_Remark3                      = 96; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_TransmissionDate             = 97; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_TransmissionTypeId           = 98; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_OrderTypeId                  = 99; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_MMInterestAmount             = 100; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_FxMarketRate                 = 101; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_FxClientRate                 = 102; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T PtfTransfOp_FxRateDirection              = 103; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T PtfTransfOp_InterestMarketRate           = 104; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_DebitToSysCurrRate           = 105; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_CreditToSysCurrRate          = 106; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_ContractLengthNumber         = 107; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_ContractLengthUnitEn         = 108; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T PtfTransfOp_FxMarginNumber               = 109; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T PtfTransfOp_FxMarginPrct                 = 110; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T PtfTransfOp_FxMarginAmount               = 111; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T PtfTransfOp_ExtOpId                      = 112;
FIELD_IDX_T PtfTransfOp_ExtOp_Ext                    = 113;
FIELD_IDX_T PtfTransfOp_AutoIndex                    = 114;
FIELD_IDX_T PtfTransfOp_ExtOpDbId                    = 115;
FIELD_IDX_T PtfTransfOp_BeginDate                    = 116;
FIELD_IDX_T PtfTransfOp_EndDate                      = 117;
FIELD_IDX_T PtfTransfOp_DraftOrderId                 = 118; /* REF8500 - 040510 - PMO */
FIELD_IDX_T PtfTransfOp_Summary                      = 119; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T PtfTransfOp_TimeStamp                    = 120; /* REF11780 - 100406 - PMO */
FIELD_IDX_T PtfTransfOp_DerivativeOrdEn				 = 121; /* OCS43683-CHU-131112 */
FIELD_IDX_T PtfTransfOp_FxFarLegAmount				 = 122; /* OCS43532-CHU-131112 */
FIELD_IDX_T PtfTransfOp_FxSpotQuote				     = 123; /* OCS43532-CHU-131112 */
FIELD_IDX_T PtfTransfOp_FxQuote					     = 124; /* OCS43532-CHU-131112 */
FIELD_IDX_T PtfTransfOp_OrderFeeEn				     = 125; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T PtfTransfOp_OrderFeePrct				 = 126; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T PtfTransfOp_FxSpotLegAmount			     = 127; /* OCS43532-CHU-131112 */
FIELD_IDX_T PtfTransfOp_MaxOrderQty					 = 128; /*OCS-43526-CHU-131213*/
FIELD_IDX_T PtfTransfOp_STPOrderEn					 = 129; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T PtfTransfOp_UnpaidPrct					 = 130; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T PtfTransfOp_EventStatusId                = 131; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T PtfTransfOp_EventActionEn                = 132; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T PtfTransfOp_CompoundOrderMasterEltId     = 133;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T PtfTransfOp_CompoundOrderSlaveEltId		 = 134; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T PtfTransfOp_CompoundOrderCode			 = 135; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T PtfTransfOp_CompoundOrderSlaveNbr		 = 136; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T PtfTransfOp_CompoundImpactRule			 = 137; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T PtfTransfOp_DisplayCondition			 = 138;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T PtfTransfOp_OrderType					 = 139;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T PtfTransfOp_CommonRef                    = 140; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T PtfTransfOp_OrderInclusionEn             = 141; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T PtfTransfOp_OrderRejectionDate           = 142; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T PtfTransfOp_OrderRejectionComment        = 143; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T PtfTransfOp_AcquisitionDate              = 144; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T PtfTransfOp_CorporateActionNatEn         = 145; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T PtfTransfOp_TaxLotSourceCd               = 146; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T PtfTransfOp_StandInstructId              = 147; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T PtfTransfOp_BankFeePrct                  = 148; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T PtfTransfOp_BankFeeAmount                = 149; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T PtfTransfOp_BankFeeCurrId                = 150; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T PtfTransfOp_PaymentOption                = 151; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T PtfTransfOp_BidTypeEn                    = 152; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid1Qty                      = 153; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid1Quote                    = 154; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid2Qty                      = 155; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid2Quote                    = 156; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid3Qty                      = 157; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_Bid3Quote                    = 158; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T PtfTransfOp_OpFusionRuleEn               = 159; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T PtfTransfOp_GlobalPosFlg                 = 160; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T PtfTransfOp_OtcOrderEn					 = 161;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T PtfTransfOp_DefaultFusRuleEn			 = 162;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T PtfTransfOp_CoolCancelEndDate            = 163; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T PtfTransfOp_FusionPrioEn                 = 164; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T PtfTransfOp_ExternalBankBic              = 165; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T PtfTransfOp_ExternalBankName             = 166; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T PtfTransfOp_ExternalBankAcctOwnrName     = 167; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T PtfTransfOp_HedgeTradeEn                 = 168; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T PtfTransfOp_FixingDate                   = 169; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr1       = 170; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr2       = 171; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr3       = 172; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr4       = 173; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_PayRef1                      = 174; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_PayRef2                      = 175; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_PayRef3                      = 176; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_PayRef4                      = 177; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T PtfTransfOp_ExternalTradeFlg             = 178; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	PtfTransfOp_OriginalQty					 = 179; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	PtfTransfOp_OrderNettingEn				 = 180; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T PtfTransfOp_PaymentDate                  = 181; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T PtfTransfOp_PaymentStatusEn              = 182; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T PtfTransfOp_SettlementDate               = 183; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T PtfTransfOp_SettleStatusEn               = 184; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	PtfTransfOp_CommissionCdEn               = 185;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_ChargeCdEn                   = 186;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_OriginalAmount               = 187;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_CounterpartOrgAmount         = 188;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_ExternalFeeM                 = 189;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_TotalChargesM                = 190;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_CounterpartAmount            = 191;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_OpLinkageCd                  = 192;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	PtfTransfOp_ChargedCustomerName          = 193;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T PtfTransfOp_BoPtfId                      = 194; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T PtfTransfOp_BoAccountId                  = 195; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_OpSplitRuleEn                = 196; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_AdjBoPtfId                   = 197; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_CoaExDate                    = 198; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_BoCashAcctId                 = 199; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_BoCashPtfId                  = 200; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_SplitParentOperId            = 201; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	PtfTransfOp_AcctCurrId                   = 202; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct2CurrId                  = 203; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct3CurrId                  = 204; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_AcctExchRate                 = 205; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct2ExchRate                = 206; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct3ExchRate                = 207; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_AcctNetAmt                   = 208; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct2NetAmt                  = 209; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct3NetAmt                  = 210; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_AcctId                       = 211; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct2Id                      = 212; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Acct3Id                      = 213; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp1TpId                      = 214; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp1CurrId                    = 215; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp1Amt                       = 216; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp2TpId                      = 217; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp2CurrId                    = 218; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp2Amt                       = 219; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp3TpId                      = 220; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp3CurrId                    = 221; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp3Amt                       = 222; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp4TpId                      = 223; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp4CurrId                    = 224; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp4Amt                       = 225; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp5TpId                      = 226; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp5CurrId                    = 227; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp5Amt                       = 228; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp6TpId                      = 229; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp6CurrId                    = 230; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp6Amt                       = 231; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp7TpId                      = 232; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp7CurrId                    = 233; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp7Amt                       = 234; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp8TpId                      = 235; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp8CurrId                    = 236; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp8Amt                       = 237; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp9TpId                      = 238; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp9CurrId                    = 239; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp9Amt                       = 240; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp10TpId                     = 241; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp10CurrId                   = 242; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_Bp10Amt                      = 243; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_TradeExchRate                = 244; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_TradeCurrId                  = 245; /* PMSTA-39717 - KNI - 22042020 */
FIELD_IDX_T	PtfTransfOp_OriginalNetAmount			 = 246;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	PtfTransfOp_SplitParOpCd				 = 247;	/* PMSTA-40714 */
FIELD_IDX_T PtfTransfOp_RuleApplicabilityEn			 = 248; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T PtfTransfOp_SmartRoundingQty			 = 249; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T PtfTransfOp_SmartRoundingOrgQty			 = 250; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T PtfTransfOp_RoundingOrgQty				 = 251; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T PtfTransfOp_SmartRoundingFlg			 = 252; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T PtfTransfOp_SmartRoundingRuleId			 = 253; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	PtfTransfOp_HierOperNatEn                = 254; /* PMSTA-40208 - adarshn - 01092020 */
FIELD_IDX_T	PtfTransfOp_HierOperationCd              = 255; /* PMSTA-40208 - adarshn - 01092020 */
FIELD_IDX_T	PtfTransfOp_CashPtfId                    = 256;	/* PMSTA-41252 - adarshn - 16112020 */
FIELD_IDX_T	PtfTransfOp_CashPfExchRate               = 257;	/* PMSTA-41252 - adarshn - 16112020 */
FIELD_IDX_T	PtfTransfOp_CashPfCurrId                 = 258;	/* PMSTA-41252 - adarshn - 16112020 */
FIELD_IDX_T	PtfTransfOp_NotionalInstrId              = 259; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/	
FIELD_IDX_T	PtfTransfOp_InvestLimitEn                = 260; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T PtfTransfOp_SetOfFeesId					 = 261; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T PtfTransfOp_SetOfProductFeesId			 = 262; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T PtfTransfOp_BoRoutingBusEntityId		 = 263; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T PtfTransfOp_OrderSubTypeId               = 264; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	PtfTransfOp_SetOfOtherFeesId             = 265; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	PtfTransfOp_TraderThirdId                = 266; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	PtfTransfOp_NetSettleAmount              = 267; /* WEALTH-9095 - SENTHIL - 20240529 */


FIELD_IDX_T BookAdjOp_Id                             = 0;
FIELD_IDX_T BookAdjOp_Cd                             = 1;
FIELD_IDX_T BookAdjOp_InputUserId                    = 2;
FIELD_IDX_T BookAdjOp_TpId                           = 3;
FIELD_IDX_T BookAdjOp_SubTpId                        = 4;
FIELD_IDX_T BookAdjOp_MgrId                          = 5;
FIELD_IDX_T BookAdjOp_RuleId                         = 6;
FIELD_IDX_T BookAdjOp_ValRuleId                      = 7;
FIELD_IDX_T BookAdjOp_ValRuleHistId                  = 8;
FIELD_IDX_T BookAdjOp_ValRuleEltId                   = 9;
FIELD_IDX_T BookAdjOp_SrcCd                          = 10;
FIELD_IDX_T BookAdjOp_SubPosNatEn                    = 11;
FIELD_IDX_T BookAdjOp_SubPosNat2En                   = 12;
FIELD_IDX_T BookAdjOp_SubPosNat3En                   = 13;
FIELD_IDX_T BookAdjOp_ParOpCd                        = 14;
FIELD_IDX_T BookAdjOp_ParOpNatEn                     = 15;
FIELD_IDX_T BookAdjOp_CheckParentEn                  = 16;
FIELD_IDX_T BookAdjOp_AcctDate                       = 17;
FIELD_IDX_T BookAdjOp_OpDate                         = 18;
FIELD_IDX_T BookAdjOp_ValueDate                      = 19;
FIELD_IDX_T BookAdjOp_RefOpCd                        = 20;
FIELD_IDX_T BookAdjOp_RefNatEn                       = 21;
FIELD_IDX_T BookAdjOp_StatusEn                       = 22;
FIELD_IDX_T BookAdjOp_SequenceNo                     = 23;
FIELD_IDX_T BookAdjOp_AcctCd                         = 24;
FIELD_IDX_T BookAdjOp_PtfId                          = 25;
FIELD_IDX_T BookAdjOp_PortPosSetId                   = 26;
FIELD_IDX_T BookAdjOp_InstrId                        = 27;
FIELD_IDX_T BookAdjOp_BalPosTpId                     = 28;
FIELD_IDX_T BookAdjOp_DepoId                         = 29;
FIELD_IDX_T BookAdjOp_OpCurrId                       = 30;
FIELD_IDX_T BookAdjOp_InstrCurrId                    = 31;
FIELD_IDX_T BookAdjOp_PtfCurrId                      = 32;
FIELD_IDX_T BookAdjOp_AdjNatEn                       = 33;
FIELD_IDX_T BookAdjOp_ExecOpId                       = 34;
FIELD_IDX_T BookAdjOp_ExecOpCd                       = 35;
FIELD_IDX_T BookAdjOp_ExecOpNatEn                    = 36;
FIELD_IDX_T BookAdjOp_ExecOpStatEn                   = 37;
FIELD_IDX_T BookAdjOp_RevOpCd                        = 38;
FIELD_IDX_T BookAdjOp_RevOpNatEn                     = 39;
FIELD_IDX_T BookAdjOp_FusRuleEn                      = 40;
FIELD_IDX_T BookAdjOp_Remark                         = 41;
FIELD_IDX_T BookAdjOp_OpExchRate                     = 42;
FIELD_IDX_T BookAdjOp_InstrExchRate                  = 43;
FIELD_IDX_T BookAdjOp_SysExchRate                    = 44;
FIELD_IDX_T BookAdjOp_Qty                            = 45;
FIELD_IDX_T BookAdjOp_Price                          = 46;
FIELD_IDX_T BookAdjOp_PriceCalcRuleEn                = 47;
FIELD_IDX_T BookAdjOp_Quote                          = 48;
FIELD_IDX_T BookAdjOp_BookOpNetAmt                   = 49;
FIELD_IDX_T BookAdjOp_BookInstrNetAmt                = 50;
FIELD_IDX_T BookAdjOp_BookPtfNetAmt                  = 51;
FIELD_IDX_T BookAdjOp_BookSysNetAmt                  = 52;
FIELD_IDX_T BookAdjOp_LastUserId                     = 53;
FIELD_IDX_T BookAdjOp_LastModifDate                  = 54;
FIELD_IDX_T BookAdjOp_CreationTime                   = 55;
FIELD_IDX_T BookAdjOp_SysCurrId                      = 56;
FIELD_IDX_T BookAdjOp_ConfirmedFlg                   = 57;
FIELD_IDX_T BookAdjOp_FctResultId                    = 58;
FIELD_IDX_T BookAdjOp_OrderModeTypeId				 = 59; /*<REF11810-BRO-060608*/
FIELD_IDX_T BookAdjOp_TraderMgrId					 = 60;
FIELD_IDX_T BookAdjOp_AutoRenewalEn				     = 61;
FIELD_IDX_T BookAdjOp_RenewalTreatmtEn			     = 62;
FIELD_IDX_T BookAdjOp_RenewalEndValDate			     = 63;
FIELD_IDX_T BookAdjOp_RenewalLength					 = 64;
FIELD_IDX_T BookAdjOp_RenewalLengthUnitEn			 = 65;
FIELD_IDX_T BookAdjOp_ClientInitEn					 = 66;
FIELD_IDX_T BookAdjOp_ContractNumber				 = 67;
FIELD_IDX_T BookAdjOp_TransactionNatEn				 = 68; /*>REF11810-BRO-060608*/
FIELD_IDX_T BookAdjOp_RenewalIntRate                 = 69; /*REF11810-BRO-060628*/
FIELD_IDX_T BookAdjOp_RenewalAmount                  = 70; /*REF11810-BRO-060628*/
FIELD_IDX_T BookAdjOp_TargetNatureEn                 = 71; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_TargetNumber                   = 72; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_TargetAmount                   = 73; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_MarketSegmentId                = 74; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_FactSheetEn                    = 75; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_LastQuoteDate                  = 76; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_LastQuoteNumber                = 77; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_LastPriceNumber                = 78; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_CommunicationDate              = 79; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_CommunicationTypeId            = 80; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_CommPartyTypeId                = 81; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BookAdjOp_Remark1                        = 82; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_Remark2                        = 83; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_Remark3                        = 84; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_TransmissionDate               = 85; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_TransmissionTypeId             = 86; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_OrderTypeId                    = 87; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_MMInterestAmount               = 88; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_FxMarketRate                   = 89; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_FxClientRate                   = 90; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BookAdjOp_FxRateDirection                = 91; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T BookAdjOp_InterestMarketRate             = 92; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_DebitToSysCurrRate             = 93; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_CreditToSysCurrRate            = 94; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_ContractLengthNumber           = 95; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_ContractLengthUnitEn           = 96; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T BookAdjOp_FxMarginNumber                 = 97; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BookAdjOp_FxMarginPrct                   = 98; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BookAdjOp_FxMarginAmount                 = 99; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BookAdjOp_ExtOpId                        = 100;
FIELD_IDX_T BookAdjOp_ExtOp_Ext                      = 101;
FIELD_IDX_T BookAdjOp_AutoIndex                      = 102;
FIELD_IDX_T BookAdjOp_ExtOpDbId                      = 103;
FIELD_IDX_T BookAdjOp_BeginDate                      = 104;
FIELD_IDX_T BookAdjOp_EndDate                        = 105;
FIELD_IDX_T BookAdjOp_DraftOrderId                   = 106; /* REF8500 - 040510 - PMO */
FIELD_IDX_T BookAdjOp_Summary                        = 107; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T BookAdjOp_TimeStamp                      = 108; /* REF11780 - 100406 - PMO */
FIELD_IDX_T BookAdjOp_DerivativeOrdEn				 = 109; /* OCS43683-CHU-131112 */
FIELD_IDX_T BookAdjOp_FxFarLegAmount				 = 110; /* OCS43532-CHU-131112 */
FIELD_IDX_T BookAdjOp_FxSpotQuote				     = 111; /* OCS43532-CHU-131112 */
FIELD_IDX_T BookAdjOp_FxQuote					     = 112; /* OCS43532-CHU-131112 */
FIELD_IDX_T BookAdjOp_OrderFeeEn				     = 113; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BookAdjOp_OrderFeePrct					 = 114; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T BookAdjOp_FxSpotLegAmount			     = 115; /* OCS43532-CHU-131112 */
FIELD_IDX_T BookAdjOp_MaxOrderQty					 = 116; /*OCS-43526-CHU-131213*/
FIELD_IDX_T BookAdjOp_STPOrderEn					 = 117; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T BookAdjOp_UnpaidPrct					 = 118; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T BookAdjOp_EventStatusId                  = 119; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T BookAdjOp_EventActionEn                  = 120; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T BookAdjOp_CompoundOrderMasterEltId       = 121;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BookAdjOp_CompoundOrderSlaveEltId		 = 122; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BookAdjOp_CompoundOrderCode			     = 123; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BookAdjOp_CompoundOrderSlaveNbr		     = 124; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BookAdjOp_CompoundImpactRule			 = 125; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T BookAdjOp_DisplayCondition				 = 126;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BookAdjOp_OrderType						 = 127;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T BookAdjOp_CommonRef                      = 128; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T BookAdjOp_OrderInclusionEn               = 129; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BookAdjOp_OrderRejectionDate             = 130; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BookAdjOp_OrderRejectionComment          = 131; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T BookAdjOp_AcquisitionDate                = 132; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BookAdjOp_CorporateActionNatEn           = 133; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BookAdjOp_TaxLotSourceCd                 = 136; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T BookAdjOp_StandInstructId                = 137; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T BookAdjOp_BankFeePrct                    = 138; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BookAdjOp_BankFeeAmount                  = 139; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BookAdjOp_BankFeeCurrId                  = 140; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T BookAdjOp_PaymentOption                  = 141; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T BookAdjOp_BidTypeEn                      = 142; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid1Qty                        = 143; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid1Quote                      = 144; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid2Qty                        = 145; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid2Quote                      = 146; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid3Qty                        = 147; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_Bid3Quote                      = 148; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T BookAdjOp_OpFusionRuleEn                 = 149; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T BookAdjOp_GlobalPosFlg                   = 150; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T BookAdjOp_OtcOrderEn					 = 151;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T BookAdjOp_DefaultFusRuleEn				 = 152;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T BookAdjOp_CoolCancelEndDate              = 153; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T BookAdjOp_FusionPrioEn                   = 154; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T BookAdjOp_ExternalBankBic                = 155; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BookAdjOp_ExternalBankName               = 156; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BookAdjOp_ExternalBankAcctOwnrName       = 157; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T BookAdjOp_HedgeTradeEn                   = 158; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T BookAdjOp_FixingDate                     = 159; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr1         = 160; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr2         = 161; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr3         = 162; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr4         = 163; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_PayRef1                        = 164; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_PayRef2                        = 165; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_PayRef3                        = 166; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_PayRef4                        = 167; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T BookAdjOp_ExternalTradeFlg               = 168; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	BookAdjOp_OriginalQty					 = 169; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	BookAdjOp_OrderNettingEn				 = 170; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T BookAdjOp_PaymentDate                    = 171; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BookAdjOp_PaymentStatusEn                = 172; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BookAdjOp_SettlementDate                 = 173; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T BookAdjOp_SettleStatusEn                 = 174; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	BookAdjOp_CommissionCdEn                 = 175;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_ChargeCdEn                     = 176;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_OriginalAmount                 = 177;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_CounterpartOrgAmount           = 178;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_ExternalFeeM                   = 179;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_TotalChargesM                  = 180;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_CounterpartAmount              = 181;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_OpLinkageCd                    = 182;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	BookAdjOp_ChargedCustomerName            = 183;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T BookAdjOp_BoPtfId                        = 184; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T BookAdjOp_BoAccountId                    = 185; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_OpSplitRuleEn                  = 186; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_AdjBoPtfId                     = 187; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_CoaExDate                      = 188; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_BoCashAcctId                   = 189; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_BoCashPtfId                    = 190; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_SplitParentOperId              = 191; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	BookAdjOp_OriginalNetAmount				 = 192;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	BookAdjOp_SplitParOpCd					 = 193;	/* PMSTA-40714 */
FIELD_IDX_T BookAdjOp_RuleApplicabilityEn			 = 194; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BookAdjOp_SmartRoundingQty				 = 195; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BookAdjOp_SmartRoundingOrgQty			 = 196; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BookAdjOp_RoundingOrgQty				 = 197; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BookAdjOp_SmartRoundingFlg				 = 198; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T BookAdjOp_SmartRoundingRuleId			 = 199; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	BookAdjOp_HierOperNatEn                  = 200;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BookAdjOp_HierOperationCd                = 201;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	BookAdjOp_NotionalInstrId                = 202;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	BookAdjOp_InvestLimitEn                  = 203;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T BookAdjOp_OrderSubTypeId                 = 204; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	BookAdjOp_SetOfOtherFeesId               = 205; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	BookAdjOp_TraderThirdId                  = 206; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	BookAdjOp_NetSettleAmount                = 207; /* WEALTH-9095 - SENTHIL - 20240529 */


/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T A_BusEntity_Id                           = 0;
FIELD_IDX_T A_BusEntity_Cd                           = 1;
FIELD_IDX_T A_BusEntity_Name                         = 2;
FIELD_IDX_T A_BusEntity_Denom                        = 3;
FIELD_IDX_T A_BusEntity_CurrId                       = 4;
FIELD_IDX_T A_BusEntity_Phone                        = 5;
FIELD_IDX_T A_BusEntity_Fax                          = 6;
FIELD_IDX_T A_BusEntity_Telex                        = 7;
FIELD_IDX_T A_BusEntity_ResidGeoId                   = 8;
FIELD_IDX_T A_BusEntity_Email                        = 9;
FIELD_IDX_T A_BusEntity_CalendarId                   = 10;
FIELD_IDX_T A_BusEntity_LegalNatEn                   = 11;
FIELD_IDX_T A_BusEntity_OrgaRoleEn                   = 12;
FIELD_IDX_T A_BusEntity_TypeId                       = 13;
FIELD_IDX_T A_BusEntity_StatusEn                     = 14;
FIELD_IDX_T A_BusEntity_ReferenceEn                  = 15;      /*  HFI-PMSTA-26560-170806  */
FIELD_IDX_T A_BusEntity_Theme                        = 17;
FIELD_IDX_T A_BusEntity_DataSecuProfId               = 18;
FIELD_IDX_T A_BusEntity_DataSecuProf2Id              = 19;
FIELD_IDX_T A_BusEntity_TimezoneId                   = 22; /* PMSTA-32150 - JBC - 180723 */
FIELD_IDX_T A_BusEntity_FiscalPeriodId               = 23; /* PMSTA-34965 - sanand - 030319 */
FIELD_IDX_T A_BusEntity_WashSaleCheckDaysBefore		 = 24; /* IntType          */
FIELD_IDX_T A_BusEntity_WashSaleCheckDaysAfter		 = 25; /* IntType          */
FIELD_IDX_T A_BusEntity_SmartRoundingRuleId			 = 26; /* PMSTA-40493-badhri-08252020: smart rounding rule  */

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T S_BusEntity_Id                          = 0;
FIELD_IDX_T S_BusEntity_Cd                          = 1;
FIELD_IDX_T S_BusEntity_Name                        = 2;
FIELD_IDX_T S_BusEntity_Denom                       = 3;
FIELD_IDX_T S_BusEntity_DataSecuProfId              = 4;
FIELD_IDX_T S_BusEntity_CodifId                     = 7;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T A_BusOrga_Id                             = 0;
FIELD_IDX_T A_BusOrga_BusEntityId                    = 1;
FIELD_IDX_T A_BusOrga_ParentBusEntityId              = 2;
FIELD_IDX_T A_BusOrga_RoleFunctionEn                 = 3;
FIELD_IDX_T A_BusOrga_TypeId                         = 4;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T S_BusOrga_Id                            = 1;
FIELD_IDX_T S_BusOrga_BusEntityId                   = 1;
FIELD_IDX_T S_BusOrga_BusEntityCd                   = 2;
FIELD_IDX_T S_BusOrga_ParentBusEntityId             = 3;
FIELD_IDX_T S_BusOrga_ParentBusEntityCd             = 4;
FIELD_IDX_T S_BusOrga_RoleFunctionEn                = 5;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T A_BusEntityPtfCompo_Id                   = 0;
FIELD_IDX_T A_BusEntityPtfCompo_PtfId                = 1;
FIELD_IDX_T A_BusEntityPtfCompo_BusEntityId          = 2;
FIELD_IDX_T A_BusEntityPtfCompo_MainBusEntityFlg     = 3;
FIELD_IDX_T A_BusEntityPtfCompo_RoleEn               = 4;
FIELD_IDX_T A_BusEntityPtfCompo_TypeId               = 5;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T S_BusEntityPtfCompo_Id                  = 0;
FIELD_IDX_T S_BusEntityPtfCompo_PtfId               = 1;
FIELD_IDX_T S_BusEntityPtfCompo_PtfCd               = 2;
FIELD_IDX_T S_BusEntityPtfCompo_BusEntityId         = 3;
FIELD_IDX_T S_BusEntityPtfCompo_BusEntityCd         = 4;
FIELD_IDX_T S_BusEntityPtfCompo_MainBusEntityFlg    = 5;
FIELD_IDX_T S_BusEntityPtfCompo_RoleEn              = 6;
FIELD_IDX_T S_BusEntityPtfCompo_TypeId              = 7; /* PMSTA-17466 - EFE - 140120 */
FIELD_IDX_T S_BusEntityPtfCompo_TypeCd              = 8; /* PMSTA-17466 - EFE - 140120 */

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T A_BusEntityInstrCompo_Id                   = 0;
FIELD_IDX_T A_BusEntityInstrCompo_InstrId              = 1;
FIELD_IDX_T A_BusEntityInstrCompo_BusEntityId          = 2;
FIELD_IDX_T A_BusEntityInstrCompo_MainBusEntityFlg     = 3;
FIELD_IDX_T A_BusEntityInstrCompo_RoleEn               = 4;
FIELD_IDX_T A_BusEntityInstrCompo_TypeId               = 5;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T S_BusEntityInstrCompo_Id                  = 0;
FIELD_IDX_T S_BusEntityInstrCompo_InstrId             = 1;
FIELD_IDX_T S_BusEntityInstrCompo_InstrCd             = 2;
FIELD_IDX_T S_BusEntityInstrCompo_BusEntityId         = 3;
FIELD_IDX_T S_BusEntityInstrCompo_BusEntityCd         = 4;
FIELD_IDX_T S_BusEntityInstrCompo_MainBusEntityFlg    = 5;
FIELD_IDX_T S_BusEntityInstrCompo_RoleEn              = 6;
FIELD_IDX_T S_BusEntityInstrCompo_TypeId              = 7; /* PMSTA-17466 - EFE - 140120 */
FIELD_IDX_T S_BusEntityInstrCompo_TypeCd              = 8; /* PMSTA-17466 - EFE - 140120 */

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T A_BusEntityThirdCompo_Id                   = 0;
FIELD_IDX_T A_BusEntityThirdCompo_ThirdId              = 1;
FIELD_IDX_T A_BusEntityThirdCompo_BusEntityId          = 2;
FIELD_IDX_T A_BusEntityThirdCompo_MainBusEntityFlg     = 3;
FIELD_IDX_T A_BusEntityThirdCompo_RoleEn               = 4;
FIELD_IDX_T A_BusEntityThirdCompo_TypeId               = 5;

/* PMSTA-17089 - DDV - 131106 */
FIELD_IDX_T S_BusEntityThirdCompo_Id                   = 0;
FIELD_IDX_T S_BusEntityThirdCompo_ThirdId              = 1;
FIELD_IDX_T S_BusEntityThirdCompo_ThirdCd              = 2;
FIELD_IDX_T S_BusEntityThirdCompo_BusEntityId          = 3;
FIELD_IDX_T S_BusEntityThirdCompo_BusEntityCd          = 4;
FIELD_IDX_T S_BusEntityThirdCompo_MainBusEntityFlg     = 5;
FIELD_IDX_T S_BusEntityThirdCompo_RoleEn               = 6;
FIELD_IDX_T S_BusEntityThirdCompo_TypeId               = 6; /* PMSTA-17466 - EFE - 140120 */
FIELD_IDX_T S_BusEntityThirdCompo_TypeCd               = 7; /* PMSTA-17466 - EFE - 140120 */

/* PMSTA-17089 - DDV - 131203 */
FIELD_IDX_T A_BusEntityAddr_Id                         = 0;
FIELD_IDX_T A_BusEntityAddr_BusEntityId                = 1;
FIELD_IDX_T A_BusEntityAddr_TpId                       = 2;
FIELD_IDX_T A_BusEntityAddr_GeoId                      = 3;
FIELD_IDX_T A_BusEntityAddr_DataSecuProfId             = 4;
FIELD_IDX_T A_BusEntityAddr_Addr                       = 5;
FIELD_IDX_T A_BusEntityAddr_Postal                     = 6;
FIELD_IDX_T A_BusEntityAddr_Phone                      = 7;
FIELD_IDX_T A_BusEntityAddr_Telex                      = 8;
FIELD_IDX_T A_BusEntityAddr_Fax                        = 9;

/* PMSTA-17089 - DDV - 131203 */
FIELD_IDX_T S_BusEntityAddr_Id                         = 0;
FIELD_IDX_T S_BusEntityAddr_BusEntityId                = 1;
FIELD_IDX_T S_BusEntityAddr_TpId                       = 2;
FIELD_IDX_T S_BusEntityAddr_GeoId                      = 3;
FIELD_IDX_T S_BusEntityAddr_DataSecuProfId             = 4;
FIELD_IDX_T S_BusEntityAddr_TpCd                       = 7;
FIELD_IDX_T S_BusEntityAddr_GeoCd                      = 8;


FIELD_IDX_T InitOp_Id                                = 0;
FIELD_IDX_T InitOp_Cd                                = 1;
FIELD_IDX_T InitOp_InputUserId                       = 2;
FIELD_IDX_T InitOp_TpId                              = 3;
FIELD_IDX_T InitOp_SubTpId                           = 4;
FIELD_IDX_T InitOp_MktThirdId                        = 5;
FIELD_IDX_T InitOp_IntermThirdId                     = 6;
FIELD_IDX_T InitOp_MgrId                             = 7;
FIELD_IDX_T InitOp_RuleId                            = 8;
FIELD_IDX_T InitOp_ValRuleEltId                      = 9;
FIELD_IDX_T InitOp_SrcCd                             = 10;
FIELD_IDX_T InitOp_SubPosNatEn                       = 11;
FIELD_IDX_T InitOp_SubPosNat2En                      = 12;
FIELD_IDX_T InitOp_SubPosNat3En                      = 13;
FIELD_IDX_T InitOp_LimitQuote                        = 14;
FIELD_IDX_T InitOp_LimitPrice                        = 15;
FIELD_IDX_T InitOp_StopQuote                         = 16;
FIELD_IDX_T InitOp_StopPrice                         = 17;
FIELD_IDX_T InitOp_OrderPriceNatEn                   = 18;
FIELD_IDX_T InitOp_OrderValidNatEn                   = 19;
FIELD_IDX_T InitOp_MinOrderQty                       = 20;
FIELD_IDX_T InitOp_ParOpCd                           = 21;
FIELD_IDX_T InitOp_ParOpNatEn                        = 22;
FIELD_IDX_T InitOp_CheckParentEn                     = 23;
FIELD_IDX_T InitOp_CheckStratEn                      = 24;
FIELD_IDX_T InitOp_OrderNatEn                        = 25;
FIELD_IDX_T InitOp_BeginDate                         = 26;
FIELD_IDX_T InitOp_AcctDate                          = 27;
FIELD_IDX_T InitOp_OpDate                            = 28;
FIELD_IDX_T InitOp_ValuationDate                     = 29;
FIELD_IDX_T InitOp_OrderLimitDate                    = 30;
FIELD_IDX_T InitOp_ValueDate                         = 31;
FIELD_IDX_T InitOp_RefOpCd                           = 32;
FIELD_IDX_T InitOp_RefNatEn                          = 33;
FIELD_IDX_T InitOp_StatusEn                          = 34;
FIELD_IDX_T InitOp_SequenceNo                        = 35;
FIELD_IDX_T InitOp_AcctCd                            = 36;
FIELD_IDX_T InitOp_OpenOperCd                        = 37;
FIELD_IDX_T InitOp_PtfId                             = 38;
FIELD_IDX_T InitOp_PortPosSetId                      = 39;
FIELD_IDX_T InitOp_InstrId                           = 40;
FIELD_IDX_T InitOp_BalPosTpId                        = 41;
FIELD_IDX_T InitOp_DepoId                            = 42;
FIELD_IDX_T InitOp_OpCurrId                          = 43;
FIELD_IDX_T InitOp_InstrCurrId                       = 44;
FIELD_IDX_T InitOp_ToInstrCurrId                     = 45;
FIELD_IDX_T InitOp_PtfCurrId                         = 46;
FIELD_IDX_T InitOp_TradeCurrId                       = 47;
FIELD_IDX_T InitOp_CntPtyThirdId                     = 48;
FIELD_IDX_T InitOp_TermTpId                          = 49;
FIELD_IDX_T InitOp_LockTpId                          = 50;
FIELD_IDX_T InitOp_AccrIntrBpTpId                    = 51;
FIELD_IDX_T InitOp_AdjNatEn                          = 52;
FIELD_IDX_T InitOp_ExecOpId                          = 53;
FIELD_IDX_T InitOp_ExecOpCd                          = 54;
FIELD_IDX_T InitOp_ExecOpNatEn                       = 55;
FIELD_IDX_T InitOp_ExecOpStatEn                      = 56;
FIELD_IDX_T InitOp_RevOpCd                           = 57;
FIELD_IDX_T InitOp_RevOpNatEn                        = 58;
FIELD_IDX_T InitOp_LockOpCd                          = 59;
FIELD_IDX_T InitOp_LockNatEn                         = 60;
FIELD_IDX_T InitOp_EvtCd                             = 61;
FIELD_IDX_T InitOp_EvtNbr                            = 62;
FIELD_IDX_T InitOp_ExCouponFlg                       = 63;
FIELD_IDX_T InitOp_FusRuleEn                         = 64;
FIELD_IDX_T InitOp_LockLimitDate                     = 65;
FIELD_IDX_T InitOp_ExpirDate                         = 66;
FIELD_IDX_T InitOp_Remark                            = 67;
FIELD_IDX_T InitOp_OpExchRate                        = 68;
FIELD_IDX_T InitOp_InstrExchRate                     = 69;
FIELD_IDX_T InitOp_SysExchRate                       = 70;
FIELD_IDX_T InitOp_TradeExchRate                     = 71;
FIELD_IDX_T InitOp_BookOpExchRate                    = 72;
FIELD_IDX_T InitOp_BookInstrExchRate                 = 73;
FIELD_IDX_T InitOp_BookSysExchRate                   = 74;
FIELD_IDX_T InitOp_Qty                               = 75;
FIELD_IDX_T InitOp_Price                             = 76;
FIELD_IDX_T InitOp_SpotPrice                         = 77;
FIELD_IDX_T InitOp_BookPrice                         = 78;
FIELD_IDX_T InitOp_PriceCalcRuleEn                   = 79;
FIELD_IDX_T InitOp_Quote                             = 80;
FIELD_IDX_T InitOp_SpotQuote                         = 81;
FIELD_IDX_T InitOp_HistQuote                         = 82;
FIELD_IDX_T InitOp_BookQuote                         = 83;
FIELD_IDX_T InitOp_Rate                              = 84;
FIELD_IDX_T InitOp_SupplAmt                          = 85;
FIELD_IDX_T InitOp_OpGrossAmt                        = 86;
FIELD_IDX_T InitOp_AccrIntrAmt                       = 87;
FIELD_IDX_T InitOp_OpNetAmt                          = 88;
FIELD_IDX_T InitOp_InstrNetAmt                       = 89;
FIELD_IDX_T InitOp_PtfNetAmt                         = 90;
FIELD_IDX_T InitOp_SysNetAmt                         = 91;
FIELD_IDX_T InitOp_BookOpNetAmt                      = 92;
FIELD_IDX_T InitOp_BookInstrNetAmt                   = 93;
FIELD_IDX_T InitOp_BookPtfNetAmt                     = 94;
FIELD_IDX_T InitOp_BookSysNetAmt                     = 95;
FIELD_IDX_T InitOp_Bp1TpId                           = 96;
FIELD_IDX_T InitOp_Bp1CurrId                         = 97;
FIELD_IDX_T InitOp_Bp1Amt                            = 98;
FIELD_IDX_T InitOp_Bp2TpId                           = 99;
FIELD_IDX_T InitOp_Bp2CurrId                         = 100;
FIELD_IDX_T InitOp_Bp2Amt                            = 101;
FIELD_IDX_T InitOp_Bp3TpId                           = 102;
FIELD_IDX_T InitOp_Bp3CurrId                         = 103;
FIELD_IDX_T InitOp_Bp3Amt                            = 104;
FIELD_IDX_T InitOp_Bp4TpId                           = 105;
FIELD_IDX_T InitOp_Bp4CurrId                         = 106;
FIELD_IDX_T InitOp_Bp4Amt                            = 107;
FIELD_IDX_T InitOp_Bp5TpId                           = 108;
FIELD_IDX_T InitOp_Bp5CurrId                         = 109;
FIELD_IDX_T InitOp_Bp5Amt                            = 110;
FIELD_IDX_T InitOp_Bp6TpId                           = 111;
FIELD_IDX_T InitOp_Bp6CurrId                         = 112;
FIELD_IDX_T InitOp_Bp6Amt                            = 113;
FIELD_IDX_T InitOp_Bp7TpId                           = 114;
FIELD_IDX_T InitOp_Bp7CurrId                         = 115;
FIELD_IDX_T InitOp_Bp7Amt                            = 116;
FIELD_IDX_T InitOp_Bp8TpId                           = 117;
FIELD_IDX_T InitOp_Bp8CurrId                         = 118;
FIELD_IDX_T InitOp_Bp8Amt                            = 119;
FIELD_IDX_T InitOp_Bp9TpId                           = 120;
FIELD_IDX_T InitOp_Bp9CurrId                         = 121;
FIELD_IDX_T InitOp_Bp9Amt                            = 122;
FIELD_IDX_T InitOp_Bp10TpId                          = 123;
FIELD_IDX_T InitOp_Bp10CurrId                        = 124;
FIELD_IDX_T InitOp_Bp10Amt                           = 125;
FIELD_IDX_T InitOp_ValRuleId                         = 126;
FIELD_IDX_T InitOp_ValRuleHistId                     = 127;
FIELD_IDX_T InitOp_LastUserId                        = 128;
FIELD_IDX_T InitOp_LastModifDate                     = 129;
FIELD_IDX_T InitOp_CreationTime                      = 130;
FIELD_IDX_T InitOp_SysCurrId                         = 131;
FIELD_IDX_T InitOp_ConfirmedFlg                      = 132;
FIELD_IDX_T InitOp_FctResultId                       = 133;
FIELD_IDX_T InitOp_OrderModeTypeId				     = 134; /*<REF11810-BRO-060608*/
FIELD_IDX_T InitOp_TraderMgrId					     = 135;
FIELD_IDX_T InitOp_AutoRenewalEn				     = 136;
FIELD_IDX_T InitOp_RenewalTreatmtEn			         = 137;
FIELD_IDX_T InitOp_RenewalEndValDate			     = 138;
FIELD_IDX_T InitOp_RenewalLength					 = 139;
FIELD_IDX_T InitOp_RenewalLengthUnitEn			     = 140;
FIELD_IDX_T InitOp_ClientInitEn					     = 141;
FIELD_IDX_T InitOp_ContractNumber				     = 142;
FIELD_IDX_T InitOp_TransactionNatEn				     = 143; /*>REF11810-BRO-060608*/
FIELD_IDX_T InitOp_RenewalIntRate                    = 144; /*REF11810-BRO-060628*/
FIELD_IDX_T InitOp_RenewalAmount                     = 145; /*REF11810-BRO-060628*/
FIELD_IDX_T InitOp_TargetNatureEn                    = 146; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_TargetNumber                      = 147; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_TargetAmount                      = 148; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_MarketSegmentId                   = 149; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_FactSheetEn                       = 150; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_LastQuoteDate                     = 151; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_LastQuoteNumber                   = 152; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_LastPriceNumber                   = 153; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_CommunicationDate                 = 154; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_CommunicationTypeId               = 155; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_CommPartyTypeId                   = 156; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InitOp_Remark1                           = 157; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_Remark2                           = 158; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_Remark3                           = 159; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_TransmissionDate                  = 160; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_TransmissionTypeId                = 161; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_OrderTypeId                       = 162; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_MMInterestAmount                  = 163; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_FxMarketRate                      = 164; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_FxClientRate                      = 165; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InitOp_FxRateDirection                   = 166; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T InitOp_InterestMarketRate                = 167; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_DebitToSysCurrRate                = 168; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_CreditToSysCurrRate               = 169; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_ContractLengthNumber              = 170; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_ContractLengthUnitEn              = 171; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T InitOp_FxMarginNumber                    = 172; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InitOp_FxMarginPrct                      = 173; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InitOp_FxMarginAmount                    = 174; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InitOp_ExtOpId                           = 175;
FIELD_IDX_T InitOp_ExtOp_Ext                         = 176;
FIELD_IDX_T InitOp_AutoIndex                         = 177;
FIELD_IDX_T InitOp_ExtOpDbId                         = 178;
FIELD_IDX_T InitOp_EndDate                           = 179;
FIELD_IDX_T InitOp_DraftOrderId                      = 180; /* REF8500 - 040510 - PMO */
FIELD_IDX_T InitOp_Summary                           = 181; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T InitOp_TimeStamp                         = 182; /* REF11780 - 100406 - PMO */
FIELD_IDX_T InitOp_DerivativeOrdEn					 = 183; /* OCS43683-CHU-131112 */
FIELD_IDX_T InitOp_FxFarLegAmount					 = 184; /* OCS43532-CHU-131112 */
FIELD_IDX_T InitOp_FxSpotQuote					     = 185; /* OCS43532-CHU-131112 */
FIELD_IDX_T InitOp_FxQuote						     = 186; /* OCS43532-CHU-131112 */
FIELD_IDX_T InitOp_OrderFeeEn					     = 187; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T InitOp_OrderFeePrct						 = 188; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T InitOp_FxSpotLegAmount				     = 189; /* OCS43532-CHU-131112 */
FIELD_IDX_T InitOp_MaxOrderQty						 = 190; /*OCS-43526-CHU-131213*/
FIELD_IDX_T InitOp_STPOrderEn						 = 191; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T InitOp_UnpaidPrct						 = 192; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T InitOp_EventStatusId                     = 193; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T InitOp_EventActionEn                     = 194; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T InitOp_CompoundOrderMasterEltId			= 195;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InitOp_CompoundOrderSlaveEltId			= 196; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InitOp_CompoundOrderCode			    = 197; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InitOp_CompoundOrderSlaveNbr		    = 198; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InitOp_CompoundImpactRule				= 199; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T InitOp_DisplayCondition			 		= 200;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T InitOp_OrderType						= 201;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T InitOp_CommonRef                        = 202; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T InitOp_OrderInclusionEn                 = 129; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InitOp_OrderRejectionDate               = 130; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InitOp_OrderRejectionComment            = 131; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T InitOp_AcquisitionDate                  = 132; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InitOp_CorporateActionNatEn             = 133; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InitOp_TaxLotSourceCd                   = 134; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T InitOp_StandInstructId                  = 135; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T InitOp_BankFeePrct                      = 136; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InitOp_BankFeeAmount                    = 137; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InitOp_BankFeeCurrId                    = 138; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T InitOp_PaymentOption                    = 139; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T InitOp_BidTypeEn                        = 140; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid1Qty                          = 141; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid1Quote                        = 142; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid2Qty                          = 143; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid2Quote                        = 144; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid3Qty                          = 145; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_Bid3Quote                        = 146; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T InitOp_OpFusionRuleEn                   = 147; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T InitOp_GlobalPosFlg                     = 148; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T InitOp_OtcOrderEn						= 149;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T InitOp_DefaultFusRuleEn					= 150;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T InitOp_CoolCancelEndDate                = 151; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T InitOp_FusionPrioEn                     = 152; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T InitOp_ExternalBankBic                  = 153; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InitOp_ExternalBankName                 = 154; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InitOp_ExternalBankAcctOwnrName         = 155; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T InitOp_HedgeTradeEn                     = 156; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T InitOp_FixingDate                       = 157; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr1           = 158; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr2           = 159; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr3           = 160; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr4           = 161; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_PayRef1                          = 162; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_PayRef2                          = 163; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_PayRef3                          = 164; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_PayRef4                          = 165; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T InitOp_ExternalTradeFlg                 = 166; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	InitOp_OriginalQty						= 167; /* PMSTA-37908 - adarshn	   - 19112019 */
FIELD_IDX_T	InitOp_OrderNettingEn					= 168; /* PMSTA-37908 - adarshn	   - 19112019 */
FIELD_IDX_T InitOp_PaymentDate                      = 169; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InitOp_PaymentStatusEn                  = 170; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InitOp_SettlementDate                   = 171; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T InitOp_SettleStatusEn                   = 172; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	InitOp_CommissionCdEn                   = 173;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_ChargeCdEn                       = 174;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_OriginalAmount                   = 175;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_CounterpartOrgAmount             = 176;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_ExternalFeeM                     = 177;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_TotalChargesM                    = 178;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_CounterpartAmount                = 179;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_OpLinkageCd                      = 180;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	InitOp_ChargedCustomerName              = 181;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T InitOp_BoPtfId                          = 182; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T InitOp_BoAccountId                      = 183; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_OpSplitRuleEn                    = 184; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_AdjBoPtfId                       = 185; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_CoaExDate                        = 186; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_BoCashAcctId                     = 187; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_BoCashPtfId                      = 188; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_SplitParentOperId                = 189; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	InitOp_OriginalNetAmount				= 190; /* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	InitOp_SplitParOpCd						= 191; /* PMSTA-40714 */
FIELD_IDX_T InitOp_RuleApplicabilityEn				= 192; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InitOp_SmartRoundingQty					= 193; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InitOp_SmartRoundingOrgQty				= 194; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InitOp_RoundingOrgQty					= 195; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InitOp_SmartRoundingFlg					= 196; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T InitOp_SmartRoundingRuleId				= 197; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	InitOp_HierOperNatEn                    = 198; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	InitOp_HierOperationCd                  = 199; /* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	InitOp_NotionalInstrId                  = 200; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	InitOp_InvestLimitEn                    = 201; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T InitOp_SetOfFeesId						= 202; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T InitOp_SetOfProductFeesId				= 203; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T InitOp_BoRoutingBusEntityId				= 204; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T InitOp_OrderSubTypeId                   = 205; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	InitOp_SetOfOtherFeesId                 = 206; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	InitOp_TraderThirdId                    = 207; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	InitOp_NetSettleAmount                  = 208; /* WEALTH-9095 - SENTHIL - 20240529 */


/*PMSTA06760-BRO-080701*/
FIELD_IDX_T CombinedOp_Id                            = 0;
FIELD_IDX_T CombinedOp_Cd                            = 1;
FIELD_IDX_T CombinedOp_InputUserId                   = 2;
FIELD_IDX_T CombinedOp_TpId                          = 3;
FIELD_IDX_T CombinedOp_SubTpId                       = 4;
FIELD_IDX_T CombinedOp_MktThirdId                    = 5;
FIELD_IDX_T CombinedOp_IntermThirdId                 = 6;
FIELD_IDX_T CombinedOp_MgrId                         = 7;
FIELD_IDX_T CombinedOp_RuleId                        = 8;
FIELD_IDX_T CombinedOp_SrcCd                         = 9;
FIELD_IDX_T CombinedOp_ParOpCd                       = 10;
FIELD_IDX_T CombinedOp_ParOpNatEn                    = 11;
FIELD_IDX_T CombinedOp_CheckParentEn                 = 12;
FIELD_IDX_T CombinedOp_AcctDate                      = 13;
FIELD_IDX_T CombinedOp_OpDate                        = 14;
FIELD_IDX_T CombinedOp_ValueDate                     = 15;
FIELD_IDX_T CombinedOp_StatusEn                      = 16;
FIELD_IDX_T CombinedOp_SequenceNo                    = 17;
FIELD_IDX_T CombinedOp_AcctCd                        = 18;
FIELD_IDX_T CombinedOp_PtfId                         = 19;
FIELD_IDX_T CombinedOp_ExecOpId                      = 20;
FIELD_IDX_T CombinedOp_ExecOpCd                      = 21;
FIELD_IDX_T CombinedOp_ExecOpNatEn                   = 22;
FIELD_IDX_T CombinedOp_ExecOpStatEn                  = 23;
FIELD_IDX_T CombinedOp_RevOpCd                       = 24;
FIELD_IDX_T CombinedOp_RevOpNatEn                    = 25;
FIELD_IDX_T CombinedOp_EvtCd                         = 26;
FIELD_IDX_T CombinedOp_EvtNbr                        = 27;
FIELD_IDX_T CombinedOp_Remark                        = 28;
FIELD_IDX_T CombinedOp_FlowId                        = 29;
FIELD_IDX_T CombinedOp_InitExtPosId                  = 30;
FIELD_IDX_T CombinedOp_LastUserId                    = 31;
FIELD_IDX_T CombinedOp_LastModifDate                 = 32;
FIELD_IDX_T CombinedOp_CreationTime                  = 33;
FIELD_IDX_T CombinedOp_ConfirmedFlg                  = 34;
FIELD_IDX_T CombinedOp_FctResultId                   = 35;
FIELD_IDX_T CombinedOp_OrderModeTypeId               = 36;
FIELD_IDX_T CombinedOp_TraderMgrId                   = 37;
FIELD_IDX_T CombinedOp_AutoRenewalEn                 = 38;
FIELD_IDX_T CombinedOp_RenewalTreatmtEn              = 39;
FIELD_IDX_T CombinedOp_RenewalEndValDate             = 40;
FIELD_IDX_T CombinedOp_RenewalLength                 = 41;
FIELD_IDX_T CombinedOp_RenewalLengthUnitEn           = 42;
FIELD_IDX_T CombinedOp_ClientInitEn                  = 43;
FIELD_IDX_T CombinedOp_ContractNumber                = 44;
FIELD_IDX_T CombinedOp_TransactionNatEn              = 45;
FIELD_IDX_T CombinedOp_RenewalIntRate                = 46;
FIELD_IDX_T CombinedOp_RenewalAmount                 = 47;
FIELD_IDX_T CombinedOp_TargetNatureEn                = 48; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_TargetNumber                  = 49; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_TargetAmount                  = 50; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_MarketSegmentId               = 51; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_FactSheetEn                   = 52; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_LastQuoteDate                 = 53; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_LastQuoteNumber               = 54; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_LastPriceNumber               = 55; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_CommunicationDate             = 56; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_CommunicationTypeId           = 57; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_CommPartyTypeId               = 58; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T CombinedOp_Remark1                       = 59; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_Remark2                       = 60; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_Remark3                       = 61; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_TransmissionDate              = 62; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_TransmissionTypeId            = 63; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_OrderTypeId                   = 64; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_MMInterestAmount              = 65; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_FxMarketRate                  = 66; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_FxClientRate                  = 67; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T CombinedOp_FxRateDirection               = 68; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T CombinedOp_InterestMarketRate            = 69; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_DebitToSysCurrRate            = 70; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_CreditToSysCurrRate           = 71; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_ContractLengthNumber          = 72; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_ContractLengthUnitEn          = 73; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T CombinedOp_FxMarginNumber                = 74; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T CombinedOp_FxMarginPrct                  = 75; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T CombinedOp_FxMarginAmount                = 76; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T CombinedOp_TimeStamp                     = 77;
FIELD_IDX_T CombinedOp_SysCurrId                     = 78;
FIELD_IDX_T CombinedOp_ExtOpId                       = 79;
FIELD_IDX_T CombinedOp_ExtOp_Ext                     = 80;
FIELD_IDX_T CombinedOp_AutoIndex                     = 81;
FIELD_IDX_T CombinedOp_ExtOpDbId                     = 82;
FIELD_IDX_T CombinedOp_BeginDate                     = 83;
FIELD_IDX_T CombinedOp_EndDate                       = 84;
FIELD_IDX_T CombinedOp_DraftOrderId                  = 85;
FIELD_IDX_T CombinedOp_Summary                       = 86; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T CombinedOp_DerivativeOrdEn				 = 87; /* OCS43683-CHU-131112 */
FIELD_IDX_T CombinedOp_FxFarLegAmount				 = 88; /* OCS43532-CHU-131112 */
FIELD_IDX_T CombinedOp_FxSpotQuote				     = 89; /* OCS43532-CHU-131112 */
FIELD_IDX_T CombinedOp_FxQuote					     = 90; /* OCS43532-CHU-131112 */
FIELD_IDX_T CombinedOp_OrderFeeEn				     = 91; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T CombinedOp_OrderFeePrct					 = 92; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T CombinedOp_FxSpotLegAmount			     = 93; /* OCS43532-CHU-131112 */
FIELD_IDX_T CombinedOp_MaxOrderQty					 = 94; /*OCS-43526-CHU-131213*/
FIELD_IDX_T CombinedOp_STPOrderEn					 = 95; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T CombinedOp_UnpaidPrct					 = 96; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T CombinedOp_EventStatusId                 = 97; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T CombinedOp_EventActionEn                 = 98; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T CombinedOp_CompoundOrderMasterEltId			 = 117;	/* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T CombinedOp_CompoundOrderSlaveEltId			 = 118; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T CombinedOp_CompoundOrderCode					 = 119; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T CombinedOp_CompoundOrderSlaveNbr				 = 120; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T CombinedOp_CompoundImpactRule					 = 121; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T CombinedOp_DisplayCondition				 = 122;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T CombinedOp_OrderType					 = 123;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T CombinedOp_CommonRef                     = 124; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T CombinedOp_OrderInclusionEn              = 125; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T CombinedOp_OrderRejectionDate            = 126; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T CombinedOp_OrderRejectionComment         = 127; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T CombinedOp_AcquisitionDate               = 128; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T CombinedOp_CorporateActionNatEn          = 129; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T CombinedOp_TaxLotSourceCd                = 130; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T CombinedOp_StandInstructId               = 131; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T CombinedOp_BankFeePrct                   = 132; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T CombinedOp_BankFeeAmount                 = 133; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T CombinedOp_BankFeeCurrId                 = 134; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T CombinedOp_PaymentOption                 = 135; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T CombinedOp_BidTypeEn                     = 136; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid1Qty                       = 137; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid1Quote                     = 138; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid2Qty                       = 139; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid2Quote                     = 140; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid3Qty                       = 141; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_Bid3Quote                     = 142; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T CombinedOp_OpFusionRuleEn                = 143; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T CombinedOp_GlobalPosFlg                  = 144; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T CombinedOp_OtcOrderEn					 = 145;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T CombinedOp_DefaultFusRuleEn				 = 146;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T CombinedOp_CoolCancelEndDate             = 147; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T CombinedOp_FusionPrioEn                  = 148; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T CombinedOp_ExternalBankBic               = 149; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T CombinedOp_ExternalBankName              = 150; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T CombinedOp_ExternalBankAcctOwnrName      = 151; /* PMSTA-35577 - Kramadevi  - 260419 */
FIELD_IDX_T CombinedOp_HedgeTradeEn                  = 152; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T CombinedOp_FixingDate                    = 153; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr1        = 154; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr2        = 155; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr3        = 156; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr4        = 157; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_PayRef1                       = 158; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_PayRef2                       = 159; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_PayRef3                       = 160; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_PayRef4                       = 161; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T CombinedOp_ExternalTradeFlg              = 162; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T	CombinedOp_OriginalQty					 = 163; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T	CombinedOp_OrderNettingEn				 = 164; /* PMSTA-37908 - adarshn	- 19112019 */
FIELD_IDX_T CombinedOp_PaymentDate                   = 165; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T CombinedOp_PaymentStatusEn               = 166; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T CombinedOp_SettlementDate                = 167; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T CombinedOp_SettleStatusEn                = 168; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	CombinedOp_CommissionCdEn                = 169;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_ChargeCdEn                    = 170;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_OriginalAmount                = 171;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_CounterpartOrgAmount          = 172;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_ExternalFeeM                  = 173;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_TotalChargesM                 = 174;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_CounterpartAmount             = 175;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_OpLinkageCd                   = 176;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	CombinedOp_ChargedCustomerName           = 177;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T CombinedOp_BoPtfId                       = 178; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T CombinedOp_BoAccountId                   = 179; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_OpSplitRuleEn                 = 180; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_AdjBoPtfId                    = 181; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_CoaExDate                     = 182; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_BoCashAcctId                  = 183; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_BoCashPtfId                   = 184; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_SplitParentOperId             = 185; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	CombinedOp_OriginalNetAmount			 = 186;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	CombinedOp_SplitParOpCd					 = 187;	/* PMSTA-40714 */
FIELD_IDX_T CombinedOp_RuleApplicabilityEn			 = 188; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T CombinedOp_SmartRoundingQty				 = 189; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T CombinedOp_SmartRoundingOrgQty			 = 190; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T CombinedOp_RoundingOrgQty				 = 191; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T CombinedOp_SmartRoundingFlg				 = 192; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T CombinedOp_SmartRoundingRuleId			 = 193; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	CombinedOp_HierOperNatEn                 = 194;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	CombinedOp_HierOperationCd               = 195;	/* PMSTA-40208 - adarshn	- 01092020 */
FIELD_IDX_T	CombinedOp_NotionalInstrId               = 196;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	CombinedOp_InvestLimitEn                 = 197;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T CombinedOp_OrderSubTypeId                = 198; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T	CombinedOp_SetOfOtherFeesId              = 199; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	CombinedOp_TraderThirdId                 = 200; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	CombinedOp_NetSettleAmount               = 201; /* WEALTH-9095 - SENTHIL - 20240529 */

FIELD_IDX_T A_PosValHist_PtfId                       = 0;
FIELD_IDX_T A_PosValHist_ValuationDate               = 1;
FIELD_IDX_T A_PosValHist_ConstructDate               = 2;


FIELD_IDX_T S_PosValHist_PtfId                       = 0;
FIELD_IDX_T S_PosValHist_ValuationDate               = 1;
FIELD_IDX_T S_PosValHist_ConstructDate               = 2;
FIELD_IDX_T S_PosValHist_PtfCd                       = 3;


FIELD_IDX_T Adm_Arg_Id                               = 0;
FIELD_IDX_T Adm_Arg_CodifId                          = 1;
FIELD_IDX_T Adm_Arg_PtfPpsInstrId                    = 2;
FIELD_IDX_T Adm_Arg_EntDictId                        = 3;
FIELD_IDX_T Adm_Arg_SynEntDictId                     = 4;
FIELD_IDX_T Adm_Arg_AttrDictId                       = 5;
FIELD_IDX_T Adm_Arg_UserId                           = 6;
FIELD_IDX_T Adm_Arg_FctDictId                        = 7;
FIELD_IDX_T Adm_Arg_NatEn                            = 8;
FIELD_IDX_T Adm_Arg_Date                             = 9;
FIELD_IDX_T Adm_Arg_Flag                             = 10;
FIELD_IDX_T Adm_Arg_Sysname                          = 11;
FIELD_IDX_T Adm_Arg_StatusEn                         = 12;
FIELD_IDX_T Adm_Arg_Code                             = 13;
FIELD_IDX_T Adm_Arg_Date2                            = 14;
FIELD_IDX_T Adm_Arg_Code2                            = 15;
FIELD_IDX_T Adm_Arg_InstrCodifId                     = 16;
FIELD_IDX_T Adm_Arg_CurrCodifId                      = 17;
FIELD_IDX_T Adm_Arg_DepositCodifId                   = 18;
FIELD_IDX_T Adm_Arg_LangageCodifId                   = 19;
FIELD_IDX_T Adm_Arg_GeoCodifId                       = 20;
FIELD_IDX_T Adm_Arg_ManagerCodifId                   = 21;
FIELD_IDX_T Adm_Arg_PtfCodifId                       = 22;
FIELD_IDX_T Adm_Arg_SectorCodifId                    = 23;
FIELD_IDX_T Adm_Arg_ThirdCodifId                     = 24;
FIELD_IDX_T Adm_Arg_TypeCodifId                      = 25;
FIELD_IDX_T Adm_Arg_LangDictId                       = 26;
FIELD_IDX_T Adm_Arg_TimeStamp                        = 27; /* REF11780 - 100406 - PMO */
FIELD_IDX_T Adm_Arg_ProcessId                        = 28; /* PMSTA7422 - DDV - 090528 */
FIELD_IDX_T Adm_Arg_BusEntityCodifId                 = 29;  /*  HFI-PMSTA-17655-140218  */
FIELD_IDX_T Adm_Arg_Date3                            = 30;  /* PMSTA-25331 - TEB - 20171018 */
FIELD_IDX_T Adm_Arg_Integer                          = 31; /* PMSTA-34827 - JBC - 19021 */
FIELD_IDX_T Adm_Arg_Note                             = 32;  /*  HFI-PMSTA-38849-200714  */
FIELD_IDX_T Adm_Arg_ReturnStatus                     = 33; /* PMSTA-46404 - DDV - 211006 */
FIELD_IDX_T Adm_Arg_Info                             = 34; /*PMSTA-37628 - AIS - 191029*/

/* REF11780 - 100406 - PMO */
FIELD_IDX_T Sql_Result_Id                            = 0;
FIELD_IDX_T Sql_Result_TimeStamp                     = 1;

FIELD_IDX_T Array_X_ArrayX                           = 0;


FIELD_IDX_T Array_XY_ArrayX                          = 0;
FIELD_IDX_T Array_XY_ArrayY                          = 1;


FIELD_IDX_T Chrono_Arg_InstrId                       = 0;
FIELD_IDX_T Chrono_Arg_NatEn                         = 1;
FIELD_IDX_T Chrono_Arg_BegDate                       = 2;
FIELD_IDX_T Chrono_Arg_EndDate                       = 3;
FIELD_IDX_T Chrono_Arg_CurrId                        = 4;
FIELD_IDX_T Chrono_Arg_TimeDimEn                     = 5;
FIELD_IDX_T Chrono_Arg_ValidityFlg                   = 6;
FIELD_IDX_T Chrono_Arg_ThirdPartyId                  = 7; /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_Arg_ThirdPartyFlg                 = 8; /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_Arg_SubNatTypeId                  = 9; /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_Arg_SubNatFlg                     =10; /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_Arg_StratId                       =11; /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_Arg_StratFlg                      =12; /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_Arg_ComplNatEn                    =13; /* PMSTA06646 - LJE - 080612 */


FIELD_IDX_T Chrono_FreqArg_ObjId                     = 0;
FIELD_IDX_T Chrono_FreqArg_NatEn                     = 1;
FIELD_IDX_T Chrono_FreqArg_TillDate                  = 2;
FIELD_IDX_T Chrono_FreqArg_Reading                   = 3;
FIELD_IDX_T Chrono_FreqArg_Freq                      = 4;
FIELD_IDX_T Chrono_FreqArg_FreqUnitEn                = 5;
FIELD_IDX_T Chrono_FreqArg_CurrId                    = 6;
FIELD_IDX_T Chrono_FreqArg_ObjEn                     = 7;
FIELD_IDX_T Chrono_FreqArg_MethodEn                  = 8;  /* REF7061 - TEB - 030826 */
FIELD_IDX_T Chrono_FreqArg_ThirdPartyId              = 9;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_FreqArg_ThirdPartyFlg             =10;  /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_FreqArg_SubNatTypeId              =11;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_FreqArg_SubNatFlg                 =12;  /* REF10598 - LJE - 041006 */
FIELD_IDX_T Chrono_FreqArg_StratId                   =13;  /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_FreqArg_StratFlg                  =14;  /* PMSTA06646 - LJE - 080612 */
FIELD_IDX_T Chrono_FreqArg_ComplNatEn                =15;  /* PMSTA06646 - LJE - 080612 */


FIELD_IDX_T ExchRate_Arg_CurrId                      = 0;
FIELD_IDX_T ExchRate_Arg_UnderCurrId                 = 1;
FIELD_IDX_T ExchRate_Arg_TpId                        = 2;
FIELD_IDX_T ExchRate_Arg_ThirdId                     = 3;
FIELD_IDX_T ExchRate_Arg_MktThirdId                  = 4;
FIELD_IDX_T ExchRate_Arg_ExchDate                    = 5;
FIELD_IDX_T ExchRate_Arg_TpMandatFlg                 = 6;
FIELD_IDX_T ExchRate_Arg_ThirdMandatFlg              = 7;


FIELD_IDX_T ExchRate_FreqArg_CurrId                  = 0;
FIELD_IDX_T ExchRate_FreqArg_UnderCurrId             = 1;
FIELD_IDX_T ExchRate_FreqArg_TillDate                = 2;
FIELD_IDX_T ExchRate_FreqArg_Reading                 = 3;
FIELD_IDX_T ExchRate_FreqArg_Freq                    = 4;
FIELD_IDX_T ExchRate_FreqArg_FreqUnitEn              = 5;
FIELD_IDX_T ExchRate_FreqArg_HistoRuleEn             = 6;


FIELD_IDX_T Sel_Arg_Id1                              =  0;
FIELD_IDX_T Sel_Arg_Id2                              =  1;
FIELD_IDX_T Sel_Arg_Id3                              =  2;
FIELD_IDX_T Sel_Arg_Id4                              =  3;
FIELD_IDX_T Sel_Arg_FromDate                         =  4;
FIELD_IDX_T Sel_Arg_TillDate                         =  5;
FIELD_IDX_T Sel_Arg_DistinctFlg                      =  6;
FIELD_IDX_T Sel_Arg_Enum1                            =  7; /* PMSTA-22496 - DDV - 160509 */
FIELD_IDX_T Sel_Arg_Enum2                            =  8;
FIELD_IDX_T Sel_Arg_DictId1                          =  9; /* PMSTA-22496 - DDV - 160511 */
FIELD_IDX_T Sel_Arg_ServerId                         = 10;
FIELD_IDX_T Sel_Arg_Flag1                            = 11;
FIELD_IDX_T Sel_Arg_Flag2                            = 12;
FIELD_IDX_T Sel_Arg_IntMin                           = 13;
FIELD_IDX_T Sel_Arg_IntMax                           = 14;


FIELD_IDX_T InstrPrice_Arg_InstrId                   = 0;
FIELD_IDX_T InstrPrice_Arg_CurrId                    = 1;
FIELD_IDX_T InstrPrice_Arg_TpId                      = 2;
FIELD_IDX_T InstrPrice_Arg_ThirdId                   = 3;
FIELD_IDX_T InstrPrice_Arg_TermTpId                  = 4;
FIELD_IDX_T InstrPrice_Arg_MktThirdId                = 5;
FIELD_IDX_T InstrPrice_Arg_QuoteDate                 = 6;
FIELD_IDX_T InstrPrice_Arg_BusEntityRule             = 7; /* PMSTA-32141 CMILOS 200718 */
FIELD_IDX_T InstrPrice_Arg_BusEntityMandatFlg        = 8; /* PMSTA-32141 CMILOS 200718 */
FIELD_IDX_T InstrPrice_Arg_CurrMandatFlg             = 9;
FIELD_IDX_T InstrPrice_Arg_TpMandatFlg               = 10;
FIELD_IDX_T InstrPrice_Arg_ThirdMandatFlg            = 11;
FIELD_IDX_T InstrPrice_Arg_TermMandatFlg             = 12;
FIELD_IDX_T InstrPrice_Arg_MktMandatFlg              = 13;
FIELD_IDX_T InstrPrice_Arg_ValRuleId                 = 14;
FIELD_IDX_T InstrPrice_Arg_ValRuleCoefNatEn          = 15;
FIELD_IDX_T InstrPrice_Arg_ValidityPeriod            = 16;
FIELD_IDX_T InstrPrice_Arg_AdjTypeRank               = 17; /* PMSTA-10049 - LJE - 101006 */
FIELD_IDX_T InstrPrice_Arg_PtfId					 = 18; /* PMSTA-32157 - SILPA - 180905*/


FIELD_IDX_T InstrPrice_FreqArg_InstrId               = 0;
FIELD_IDX_T InstrPrice_FreqArg_TillDate              = 1;
FIELD_IDX_T InstrPrice_FreqArg_Reading               = 2;
FIELD_IDX_T InstrPrice_FreqArg_Freq                  = 3;
FIELD_IDX_T InstrPrice_FreqArg_FreqUnitEn            = 4;
FIELD_IDX_T InstrPrice_FreqArg_HistoRuleEn           = 5;


FIELD_IDX_T Evt_Arg_InstrId                          = 0;
FIELD_IDX_T Evt_Arg_ValidDate                        = 1;
FIELD_IDX_T Evt_Arg_BegDate                          = 2;
FIELD_IDX_T Evt_Arg_EndDate                          = 3;
FIELD_IDX_T Evt_Arg_NatEn                            = 4;


FIELD_IDX_T Fus_Arg_DictId                           = 0;
FIELD_IDX_T Fus_Arg_Id                               = 1;
FIELD_IDX_T Fus_Arg_BegDate                          = 2;
FIELD_IDX_T Fus_Arg_EndDate                          = 3;
FIELD_IDX_T Fus_Arg_Flg                              = 4;
FIELD_IDX_T Fus_Arg_AutomaticFlg                     = 5;
FIELD_IDX_T Fus_Arg_PtfSize                          = 6;
FIELD_IDX_T Fus_Arg_RequestId                        = 7;
FIELD_IDX_T Fus_Arg_PtfTransfFlg                     = 8;
FIELD_IDX_T Fus_Arg_SyncModeFlg                      = 9;
FIELD_IDX_T Fus_Arg_SuperUserFlg                     = 10;
FIELD_IDX_T Fus_Arg_StockId                          = 11;
FIELD_IDX_T Fus_Arg_StockPtfNbr                      = 12;
FIELD_IDX_T Fus_Arg_PtfListId                        = 13;
FIELD_IDX_T Fus_Arg_PtfReqList                       = 14;
FIELD_IDX_T Fus_Arg_PrivateFusSrvId                  = 15; /* DLA - PMSTA07062 - 080827 */
FIELD_IDX_T Fus_Arg_ApplSessionCd                    = 16; /* DLA - PMSTA-28660 - 171002 */
FIELD_IDX_T Fus_Arg_ParentEventSchedId               = 17; /* PMSTA-32289 - 240718 - PMO */
FIELD_IDX_T Fus_Arg_FusionPrioEn                     = 18; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T Fus_Arg_ServerId                         = 19; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T Fus_Arg_SyncTimeOut                      = 20;
FIELD_IDX_T Fus_Arg_RequestUserId                    = 21;
FIELD_IDX_T Fus_Arg_FusionRetryNb                    = 22; /* PMSTA-61044 - JBC - 20241018 */

FIELD_IDX_T Bu_Arg_Id                                = 0;
FIELD_IDX_T Bu_Arg_Code                              = 1;
FIELD_IDX_T Bu_Arg_ApplSessionCd                     = 2;

FIELD_IDX_T UearEntity_Id                            = 0; /* WEALTH-5698 - 290224 - Sathees + */
FIELD_IDX_T UearEntity_DictId                        = 1;
FIELD_IDX_T UearEntityDSP_Id                         = 2;
FIELD_IDX_T UearEntityDSP2_Id                        = 3; /* WEALTH-5698 - 290224 - Sathees - */

FIELD_IDX_T Fus_Sync_RequestId                       = 0; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T Fus_Sync_SyncModeFlg                     = 1; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T Fus_Sync_SyncTimeOut                     = 2;
FIELD_IDX_T Fus_Sync_IoId                            = 3;

FIELD_IDX_T GetVersion_Arg_MajorCd                   = 0; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_MinorCd                   = 1; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_StampCd                   = 2; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_OsCd                      = 3; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_BitsCd                    = 4; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_Host                      = 5; /* PMSTA-24510 - 220816 - PMO *//* DLA - PMSTA-27503 - 170615 */
FIELD_IDX_T GetVersion_Arg_ServerName                = 6; /* PMSTA-24510 - 220816 - PMO */
FIELD_IDX_T GetVersion_Arg_Impl_Build                = 7;

FIELD_IDX_T GetSrvEnv_Arg_Environment                = 0; /* DLA - PMSTA-24751 - 161227 */

FIELD_IDX_T Chk_Arg_Id                               = 0;
FIELD_IDX_T Chk_Arg_EntDictId                        = 1;
FIELD_IDX_T Chk_Arg_MinLen                           = 2;
FIELD_IDX_T Chk_Arg_MaxLen                           = 3;
FIELD_IDX_T Chk_Arg_DefInt                           = 4;
FIELD_IDX_T Chk_Arg_SynEnt                           = 5;
FIELD_IDX_T Chk_Arg_Ent                              = 6;
FIELD_IDX_T Chk_Arg_Cd                               = 7;
FIELD_IDX_T Chk_Arg_Val                              = 8;
FIELD_IDX_T Chk_Arg_SybName                          = 9;
FIELD_IDX_T Chk_Arg_TpId                             = 10;
FIELD_IDX_T Chk_Arg_ParFlg                           = 11;
FIELD_IDX_T Chk_Arg_ParId                            = 12;
FIELD_IDX_T Chk_Arg_NatEn                            = 13;
FIELD_IDX_T Chk_Arg_ReturnStatus                     = 14;
FIELD_IDX_T Chk_Arg_Date							 = 15;


FIELD_IDX_T Del_Arg_Id                               = 0;
FIELD_IDX_T Del_Arg_Cd                               = 1;
FIELD_IDX_T Del_Arg_NatEn                            = 2;
FIELD_IDX_T Del_Arg_TypeId                           = 3;
FIELD_IDX_T Del_Arg_PtfId                            = 4;   /* PMSTA-6921 - 311008 - PMO */
FIELD_IDX_T Del_Arg_Integer                          = 5;   /* PMSTA-34827 - JBC - 19021 */

FIELD_IDX_T Get_Arg_Id                               = 0;
FIELD_IDX_T Get_Arg_ThirdId                          = 1;
FIELD_IDX_T Get_Arg_TpId                             = 2;
FIELD_IDX_T Get_Arg_CodifId                          = 3;
FIELD_IDX_T Get_Arg_ObjId                            = 4;
FIELD_IDX_T Get_Arg_RefCurrId                        = 5;
FIELD_IDX_T Get_Arg_Cd                               = 6;
FIELD_IDX_T Get_Arg_NatEn                            = 7;
FIELD_IDX_T Get_Arg_Date                             = 8;
FIELD_IDX_T Get_Arg_ShortDate                        = 9;
FIELD_IDX_T Get_Arg_EntDictId                        = 10;
FIELD_IDX_T Get_Arg_AttribDictId                     = 11;
FIELD_IDX_T Get_Arg_FctDictId                        = 12;
FIELD_IDX_T Get_Arg_UserId                           = 13;
FIELD_IDX_T Get_Arg_DateTime                         = 14;
FIELD_IDX_T Get_Arg_Integer                          = 15;
FIELD_IDX_T Get_Arg_Integer2                         = 16;
FIELD_IDX_T Get_Arg_NatEn2                           = 17;
FIELD_IDX_T Get_Arg_Flag                             = 18;
FIELD_IDX_T Get_Arg_Flag2                            = 19;
FIELD_IDX_T Get_Arg_Flag3                            = 20;
FIELD_IDX_T Get_Arg_Flag4                            = 21;
FIELD_IDX_T Get_Arg_Flag5                            = 22;
FIELD_IDX_T Get_Arg_DimPtfDictId                     = 23;
FIELD_IDX_T Get_Arg_PtfId                            = 24;
FIELD_IDX_T Get_Arg_InstrId                          = 25;
FIELD_IDX_T Get_Arg_PtfPosSetId                      = 26;
FIELD_IDX_T Get_Arg_StatEn                           = 27;
FIELD_IDX_T Get_Arg_PosNatEn                         = 28;
FIELD_IDX_T Get_Arg_Enum1                            = 29;
FIELD_IDX_T Get_Arg_Enum2                            = 30;
FIELD_IDX_T Get_Arg_Enum3                            = 31;
FIELD_IDX_T Get_Arg_Enum4                            = 32;
FIELD_IDX_T Get_Arg_Enum5                            = 33;
FIELD_IDX_T Get_Arg_DateTime2                        = 34;
FIELD_IDX_T Get_Arg_Cd2                              = 35;
FIELD_IDX_T Get_Arg_Number                           = 36;
FIELD_IDX_T Get_Arg_Longname                         = 37;
FIELD_IDX_T Get_Arg_ScreenDictId                     = 38;
FIELD_IDX_T Get_Arg_DerivedFlg                       = 39;
FIELD_IDX_T Get_Arg_LangDictId                       = 40;	/* REF9529 - LJE - 031008 */
FIELD_IDX_T	Get_Arg_Text							 = 41;	/* REF11832 - RAK - 060608 */
FIELD_IDX_T	Get_Arg_OpenOpId						 = 42;	/* REF11828 - RAK - 060608 */
FIELD_IDX_T	Get_Arg_BalPosTpId						 = 43;	/* REF11828 - RAK - 060608 */
FIELD_IDX_T	Get_Arg_String1000                       = 44;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T	Get_Arg_String2000                       = 45;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T	Get_Arg_String3000                       = 46;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T	Get_Arg_String4000                       = 47;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T	Get_Arg_String7000                       = 48;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T	Get_Arg_String15000                      = 49;  /* PMSTA13167 - DDV - 111215 */
FIELD_IDX_T Get_Arg_Smallint                         = 50;  /* PMSTA-18593 - LJE - 151026 */
FIELD_IDX_T Get_Arg_Smallint2                        = 51;  /* PMSTA-18593 - LJE - 151026 */
FIELD_IDX_T	Get_Arg_CompoundScreenDictId             = 52;  /* PMSTA-18601 - DDV - 141030 */
FIELD_IDX_T Get_Arg_ApplSessionCd                    = 54;  /* PMSTA-22549 - CHU - 160512 */
FIELD_IDX_T Get_Arg_EventId                          = 53;  /* PMSTA-32288 - JBC - 190215 */
FIELD_IDX_T Get_Arg_ServerId                         = 55;  /* PMSTA-32288 - JBC - 190215 */
FIELD_IDX_T Get_Arg_ReturnStatus                     = 56;  /*  HFI-PMSTA-44888-210423  */

FIELD_IDX_T Get_Arg2_Id                              = 0;
FIELD_IDX_T Get_Arg2_PtfId                           = 1;
FIELD_IDX_T Get_Arg2_FromDate                        = 2;
FIELD_IDX_T Get_Arg2_TillDate                        = 3;
FIELD_IDX_T Get_Arg2_AccNbr                          = 4;
FIELD_IDX_T Get_Arg2_ClientDataType                  = 5;
FIELD_IDX_T Get_Arg2_ClientVersion                   = 6;
FIELD_IDX_T Get_Arg2_OsVersion                       = 7;
FIELD_IDX_T Get_Arg2_UserCd                          = 8;
FIELD_IDX_T Get_Arg2_ProcessId                       = 9;
FIELD_IDX_T Get_Arg2_LoginDateTime                   = 10;
FIELD_IDX_T Get_Arg2_DeltaDateTime                   = 11;
FIELD_IDX_T Get_Arg2_Mode                            = 12;


FIELD_IDX_T Flow_Arg_InstrId                         = 0;
FIELD_IDX_T Flow_Arg_RefDate                         = 1;
FIELD_IDX_T Flow_Arg_ValDate                         = 2;
FIELD_IDX_T Flow_Arg_Pos                             = 3;
FIELD_IDX_T Flow_Arg_Cnt                             = 4;
FIELD_IDX_T Flow_Arg_NatEn                           = 5;
FIELD_IDX_T Flow_Arg_SubNatEn                        = 6;
FIELD_IDX_T Flow_Arg_EvtDateRule                     = 7;


FIELD_IDX_T ApplMsg_Arg_Cd                           = 0;
FIELD_IDX_T ApplMsg_Arg_LangDictId                   = 1;
FIELD_IDX_T ApplMsg_Arg_NatEn                        = 2;


FIELD_IDX_T FundVal_Arg_PtfId                        = 0;
FIELD_IDX_T FundVal_Arg_ValuationDate                = 1;
FIELD_IDX_T FundVal_Arg_TimeDimension                = 2;
FIELD_IDX_T FundVal_Arg_ValoSeqNo                    = 3;
FIELD_IDX_T FundVal_Arg_AccNbr                       = 4;
FIELD_IDX_T FundVal_Arg_InstrId                      = 5;
FIELD_IDX_T FundVal_Arg_OfficialFlg                  = 6;


FIELD_IDX_T Operator_DataTp                          = 0;
FIELD_IDX_T Operator_Value                           = 1;
FIELD_IDX_T Operator_Tp                              = 2;


FIELD_IDX_T Srv_Connect_Id                           = 0;
FIELD_IDX_T Srv_Connect_Status                       = 1;
FIELD_IDX_T Srv_Connect_Dialog                       = 2;
FIELD_IDX_T Srv_Connect_User                         = 3;
FIELD_IDX_T Srv_Connect_HostName                     = 4;
FIELD_IDX_T Srv_Connect_ModuleName                   = 5;
FIELD_IDX_T Srv_Connect_DateTime                     = 6;
FIELD_IDX_T Srv_Connect_Charset                      = 7;


FIELD_IDX_T A_Test_String                            = 0;
FIELD_IDX_T A_Test_Sequence                          = 1;

FIELD_IDX_T Out_Date_Date                            = 0;


FIELD_IDX_T Out_Number_Number                        = 0;


FIELD_IDX_T MeanCapReturn_Arg_FromDate               = 0;
FIELD_IDX_T MeanCapReturn_Arg_TillDate               = 1;
FIELD_IDX_T MeanCapReturn_Arg_PtfId                  = 2;
FIELD_IDX_T MeanCapReturn_Arg_MktSgtId               = 3;
FIELD_IDX_T MeanCapReturn_Arg_InstrId                = 4;
FIELD_IDX_T MeanCapReturn_Arg_GridId                 = 5;
FIELD_IDX_T MeanCapReturn_Arg_MethodEn               = 6;
FIELD_IDX_T MeanCapReturn_Arg_TaxCredFlg             = 7;
FIELD_IDX_T MeanCapReturn_Arg_GrossEffectFlg         = 8;
FIELD_IDX_T MeanCapReturn_Arg_GrossFeesFlg           = 9;
FIELD_IDX_T MeanCapReturn_Arg_GrossTaxFlg            = 10;
FIELD_IDX_T MeanCapReturn_Arg_RiskFlg                = 11;
FIELD_IDX_T MeanCapReturn_Arg_AnnualRuleEn           = 12;
FIELD_IDX_T MeanCapReturn_Arg_AlwaysInitialDtFlg     = 13;
FIELD_IDX_T MeanCapReturn_Arg_RetContribFlg          = 14;
FIELD_IDX_T MeanCapReturn_Arg_ExcludeIncFlg          = 15;
FIELD_IDX_T MeanCapReturn_Arg_Level                  = 16;
FIELD_IDX_T MeanCapReturn_Arg_PSPId                  = 17; /* REF9264 - LJE - 031021 */
FIELD_IDX_T MeanCapReturn_Arg_ExcludePosFeesFlg      = 18; /* REF11269 - LJE - 051220 */
FIELD_IDX_T MeanCapReturn_Arg_ExcludePosTaxFlg       = 19; /* REF11269 - LJE - 051220 */


FIELD_IDX_T RiskRatio_Arg_EndDate                    = 0;
FIELD_IDX_T RiskRatio_Arg_BeginDate                  = 1;
FIELD_IDX_T RiskRatio_Arg_FreqUnit                   = 2;
FIELD_IDX_T RiskRatio_Arg_YearFlg                    = 3;
FIELD_IDX_T RiskRatio_Arg_ScriptRtn                  = 4;
FIELD_IDX_T RiskRatio_Arg_ScriptBenchRtn             = 5;
FIELD_IDX_T RiskRatio_Arg_ScriptRiskRtn              = 6;


FIELD_IDX_T Io_Id_Id                                 = 0;

FIELD_IDX_T Io_Ext_Ext                               = 0;

FIELD_IDX_T Io_Info_Info                             = 0;

FIELD_IDX_T Io_Flg_Flg                               = 0;

FIELD_IDX_T FmtEltDef_FmtId                          = 0;
FIELD_IDX_T FmtEltDef_FmtEltRank                     = 1;
FIELD_IDX_T FmtEltDef_DataSetIndex                   = 2;
FIELD_IDX_T FmtEltDef_ColIndex                       = 3;
FIELD_IDX_T FmtEltDef_DspFmt                         = 4;
FIELD_IDX_T FmtEltDef_SqlName                        = 5;
FIELD_IDX_T FmtEltDef_HierNatEn                      = 6;
FIELD_IDX_T FmtEltDef_DataTpDictId                   = 7;
FIELD_IDX_T FmtEltDef_Denom                          = 8;


FIELD_IDX_T DataDef_ColNum                           = 0;
FIELD_IDX_T DataDef_Datatype                         = 1;
FIELD_IDX_T DataDef_RefKeyIndex                      = 2;
FIELD_IDX_T DataDef_RefKeyNbr                        = 3;
FIELD_IDX_T DataDef_RefKeyEntDictId                  = 4;
FIELD_IDX_T DataDef_ClassifId                        = 5;
FIELD_IDX_T DataDef_SortCol                          = 6;
FIELD_IDX_T DataDef_ZoomFlg                          = 7;


FIELD_IDX_T PtfFusion_DimPortDictId                  = 0;
FIELD_IDX_T PtfFusion_PortObjectId                   = 1;
FIELD_IDX_T PtfFusion_FusDate                        = 2;
FIELD_IDX_T PtfFusion_FusScopeFlg                    = 3;


FIELD_IDX_T ListMgmArg_FctEn                         = 0;
FIELD_IDX_T ListMgmArg_EntDictId                     = 1;
FIELD_IDX_T ListMgmArg_ListId                        = 2;
FIELD_IDX_T ListMgmArg_ScriptDef                     = 3;
FIELD_IDX_T ListMgmArg_AllEntListFlg                 = 4;


FIELD_IDX_T ExtStratLnk_Id                           = 0;
FIELD_IDX_T ExtStratLnk_StratId                      = 1;
FIELD_IDX_T ExtStratLnk_LnkObjDictId                 = 2;
FIELD_IDX_T ExtStratLnk_ObjId                        = 3;
FIELD_IDX_T ExtStratLnk_PtfId                        = 4;
FIELD_IDX_T ExtStratLnk_ListId                       = 5;
FIELD_IDX_T ExtStratLnk_ParStratId                   = 6;
FIELD_IDX_T ExtStratLnk_GridId                       = 7;
FIELD_IDX_T ExtStratLnk_GridListId                   = 8;
FIELD_IDX_T ExtStratLnk_ParGridId                    = 9;
FIELD_IDX_T ExtStratLnk_MktSegId                     = 10;
FIELD_IDX_T ExtStratLnk_FctResultId                  = 11;
FIELD_IDX_T ExtStratLnk_LnkParStratId                = 12;
FIELD_IDX_T ExtStratLnk_ParExtStratLnkId             = 13;
FIELD_IDX_T ExtStratLnk_ParStratMktSgtId             = 14;
FIELD_IDX_T ExtStratLnk_ParentPtfId                  = 15;
FIELD_IDX_T ExtStratLnk_TradConstrId                 = 16;
FIELD_IDX_T ExtStratLnk_DerivedStratId               = 17;
FIELD_IDX_T ExtStratLnk_ModelConstrId                = 18;
FIELD_IDX_T ExtStratLnk_RefStratId                   = 19;
FIELD_IDX_T ExtStratLnk_LnkNatEn                     = 20;
FIELD_IDX_T ExtStratLnk_BegDate                      = 21;
FIELD_IDX_T ExtStratLnk_EndDate                      = 22;
FIELD_IDX_T ExtStratLnk_Priority                     = 23;
FIELD_IDX_T ExtStratLnk_StratNatEn                   = 24;
FIELD_IDX_T ExtStratLnk_DirectFlg                    = 25;
FIELD_IDX_T ExtStratLnk_CheckedEn                    = 26;
FIELD_IDX_T ExtStratLnk_ConvFactPrct                 = 27;
FIELD_IDX_T ExtStratLnk_Level                        = 28;
FIELD_IDX_T ExtStratLnk_CalcEn                       = 29;
FIELD_IDX_T ExtStratLnk_SubNatEn                     = 30;
FIELD_IDX_T ExtStratLnk_ConstrNatEn                  = 31;
FIELD_IDX_T ExtStratLnk_DerivFailedReasonEn          = 32;
FIELD_IDX_T ExtStratLnk_CriticalnessEn               = 33;
FIELD_IDX_T ExtStratLnk_RiskFlg                      = 34;
FIELD_IDX_T ExtStratLnk_ParStrat_ExtStratLnk_Ext     = 35;
FIELD_IDX_T ExtStratLnk_ParGrid_ExtStratLnk_Ext      = 36;
FIELD_IDX_T ExtStratLnk_A_Strat_Ext                  = 37;
FIELD_IDX_T ExtStratLnk_A_StratHist_Ext              = 38;
FIELD_IDX_T ExtStratLnk_ExtStratElt_Ext              = 39;
FIELD_IDX_T ExtStratLnk_Par_ExtStratLnk_Ext          = 40;
FIELD_IDX_T ExtStratLnk_Child_ExtStratLnk_Ext        = 41;
FIELD_IDX_T ExtStratLnk_MktSgtInstr_Ext              = 42;
FIELD_IDX_T ExtStratLnk_Marg                         = 43;
FIELD_IDX_T ExtStratLnk_TotIdx                       = 44;
FIELD_IDX_T ExtStratLnk_A_Grid_Ext                   = 45;
FIELD_IDX_T ExtStratLnk_S_MktSgt_Ext                 = 46;
FIELD_IDX_T ExtStratLnk_A_ModelConstr_Ext            = 47;
FIELD_IDX_T ExtStratLnk_A_DerivedStrat_Ext           = 48;
FIELD_IDX_T ExtStratLnk_StratLevel                   = 49;
FIELD_IDX_T ExtStratLnk_Weight                       = 50; /* PMSTA7387-VST-090205 */
FIELD_IDX_T ExtStratLnk_WeightNatEn                  = 51; /* PMSTA7387-VST-090205 */
FIELD_IDX_T ExtStratLnk_StratNatIPId                 = 52; /* PMSTA-30897-CHU-180528 */
FIELD_IDX_T ExtStratLnk_UbikFlg                      = 53; /* OCS41979-CHU-121102 */
FIELD_IDX_T ExtStratLnk_SubModelFlg                  = 54; /*PMSTA06840-Vishnu-16012020 */
FIELD_IDX_T ExtStratLnk_ParModelStratId_Ext          = 55; /*PMSTA06840-Vishnu-16012020 */
FIELD_IDX_T ExtStratLnk_ParSubModelStratId           = 56; /*PMSTA06840-Vishnu-16012020 */
FIELD_IDX_T ExtStratLnk_ParModelValue 	             = 57; /*PMSTA06840-Vishnu-16012020 */
FIELD_IDX_T ExtStratLnk_OverlayPtfId                 = 58; /* PMSTA-39048 - vkumar - 240220 */
FIELD_IDX_T ExtStratLnk_NoTargetWeightEn             = 59; /* PMSTA-40203 - sanand - 20072020 */
FIELD_IDX_T ExtStratLnk_LowerMarg					 = 60; /* PMSTA-40213-badhri-23072020 */
FIELD_IDX_T ExtStratLnk_UpperMarg					 = 61; /* PMSTA-40213-badhri-23072020 */
FIELD_IDX_T ExtStratLnk_OriginalModelConstrId		 = 62; /*PMSTA-48867-Satya*/
FIELD_IDX_T ExtStratLnk_OrigPortfolioId              = 63; /* WEALTH-5953-Ravindra-25042024 */

FIELD_IDX_T ExtStratElt_Id                           = 0;
FIELD_IDX_T ExtStratElt_FctResultId                  = 1;
FIELD_IDX_T ExtStratElt_ExtStratLnkId                = 2;
FIELD_IDX_T ExtStratElt_ParExtStratEltId             = 3;
FIELD_IDX_T ExtStratElt_StratId                      = 4;
FIELD_IDX_T ExtStratElt_StratHistId                  = 5;
FIELD_IDX_T ExtStratElt_GridId                       = 6;
FIELD_IDX_T ExtStratElt_MktSegtId                    = 7;
FIELD_IDX_T ExtStratElt_AbsClassifId                 = 8;
FIELD_IDX_T ExtStratElt_OrdClassifId                 = 9;
FIELD_IDX_T ExtStratElt_AbsListId                    = 10;
FIELD_IDX_T ExtStratElt_OrdListId                    = 11;
FIELD_IDX_T ExtStratElt_ParStratId                   = 12;
FIELD_IDX_T ExtStratElt_ParMktSegtId                 = 13;
FIELD_IDX_T ExtStratElt_BenchEntDictId               = 14;
FIELD_IDX_T ExtStratElt_PtfId                        = 15;
FIELD_IDX_T ExtStratElt_PtfListId                    = 16;
FIELD_IDX_T ExtStratElt_InstrId                      = 17;
FIELD_IDX_T ExtStratElt_RiskParInstrId               = 18;
FIELD_IDX_T ExtStratElt_DepoId                       = 19;
FIELD_IDX_T ExtStratElt_PosCurrId                    = 20;
FIELD_IDX_T ExtStratElt_InstrCurrId                  = 21;
FIELD_IDX_T ExtStratElt_RefCurrId                    = 22;
FIELD_IDX_T ExtStratElt_CrtQuoteCurrId               = 23;
FIELD_IDX_T ExtStratElt_OrderQuoteCurrId             = 24;
FIELD_IDX_T ExtStratElt_AcctCurrId                   = 25;
FIELD_IDX_T ExtStratElt_HedgeCurrId                  = 26;
FIELD_IDX_T ExtStratElt_TermTpId                     = 27;
FIELD_IDX_T ExtStratElt_LockTpId                     = 28;
FIELD_IDX_T ExtStratElt_BenchObjId                   = 29;
FIELD_IDX_T ExtStratElt_OrdParExtStratEltId          = 30;
FIELD_IDX_T ExtStratElt_DispParExtStratEltId         = 31;
FIELD_IDX_T ExtStratElt_TradConstrId                 = 32;
FIELD_IDX_T ExtStratElt_ModelConstrEltId             = 33;
FIELD_IDX_T ExtStratElt_AnaBenchEntDictId            = 34;
FIELD_IDX_T ExtStratElt_AnaBenchObjId                = 35;
FIELD_IDX_T ExtStratElt_Level                        = 36;
FIELD_IDX_T ExtStratElt_Denom                        = 37;
FIELD_IDX_T ExtStratElt_Rank                         = 38;
FIELD_IDX_T ExtStratElt_NatEn                        = 39;
FIELD_IDX_T ExtStratElt_ForecastFlg                  = 40;
FIELD_IDX_T ExtStratElt_RiskNatEn                    = 41;
FIELD_IDX_T ExtStratElt_AcctFlg                      = 42;
FIELD_IDX_T ExtStratElt_Proba                        = 43;
FIELD_IDX_T ExtStratElt_StatusEn                     = 44;
FIELD_IDX_T ExtStratElt_OpDate                       = 45;
FIELD_IDX_T ExtStratElt_AcctDate                     = 46;
FIELD_IDX_T ExtStratElt_ValueDate                    = 47;
FIELD_IDX_T ExtStratElt_ActualQty                    = 48;
FIELD_IDX_T ExtStratElt_ObjQty                       = 49;
FIELD_IDX_T ExtStratElt_EffQty                       = 50;
FIELD_IDX_T ExtStratElt_OrderQty                     = 51;
FIELD_IDX_T ExtStratElt_CostQuote                    = 52;
FIELD_IDX_T ExtStratElt_CostPriceCalcRuleEn          = 53;
FIELD_IDX_T ExtStratElt_CostPrice                    = 54;
FIELD_IDX_T ExtStratElt_CostExchRate                 = 55;
FIELD_IDX_T ExtStratElt_CrtQuote                     = 56;
FIELD_IDX_T ExtStratElt_CrtPriceCalcRuleEn           = 57;
FIELD_IDX_T ExtStratElt_CrtPrice                     = 58;
FIELD_IDX_T ExtStratElt_CrtExchRate                  = 59;
FIELD_IDX_T ExtStratElt_OrderQuote                   = 60;
FIELD_IDX_T ExtStratElt_OrderPriceCalcRuleEn         = 61;
FIELD_IDX_T ExtStratElt_OrderPrice                   = 62;
FIELD_IDX_T ExtStratElt_AcctExchRate                 = 63;
FIELD_IDX_T ExtStratElt_CostGrossVal                 = 64;
FIELD_IDX_T ExtStratElt_CostNetVal                   = 65;
FIELD_IDX_T ExtStratElt_CrtNetVal                    = 66;
FIELD_IDX_T ExtStratElt_CrtMktVal                    = 67;
FIELD_IDX_T ExtStratElt_OrderAcctNetAmt              = 68;
FIELD_IDX_T ExtStratElt_ObjWeight                    = 69;
FIELD_IDX_T ExtStratElt_ObjWeightMarg                = 70;
FIELD_IDX_T ExtStratElt_ObjWeightContrib             = 71;
FIELD_IDX_T ExtStratElt_ObjWeightContribMarg         = 72;
FIELD_IDX_T ExtStratElt_MaxWeight                    = 73;
FIELD_IDX_T ExtStratElt_MaxWeightContrib             = 74;
FIELD_IDX_T ExtStratElt_MinWeight                    = 75;
FIELD_IDX_T ExtStratElt_MinWeightContrib             = 76;
FIELD_IDX_T ExtStratElt_ActualWeight                 = 77;
FIELD_IDX_T ExtStratElt_ActualWeightContrib          = 78;
FIELD_IDX_T ExtStratElt_EffWeight                    = 79;
FIELD_IDX_T ExtStratElt_EffWeightContrib             = 80;
FIELD_IDX_T ExtStratElt_ObjWeightCheckEn             = 81;
FIELD_IDX_T ExtStratElt_MaxWeightCheckEn             = 82;
FIELD_IDX_T ExtStratElt_MinWeightCheckEn             = 83;
FIELD_IDX_T ExtStratElt_ObjDura                      = 84;
FIELD_IDX_T ExtStratElt_ObjDuraMarg                  = 85;
FIELD_IDX_T ExtStratElt_ObjDuraContrib               = 86;
FIELD_IDX_T ExtStratElt_ObjDuraContribMarg           = 87;
FIELD_IDX_T ExtStratElt_ActualDura                   = 88;
FIELD_IDX_T ExtStratElt_ActualDuraContrib            = 89;
FIELD_IDX_T ExtStratElt_EffDura                      = 90;
FIELD_IDX_T ExtStratElt_EffDuraContrib               = 91;
FIELD_IDX_T ExtStratElt_ObjDuraCheckEn               = 92;
FIELD_IDX_T ExtStratElt_ObjBeta                      = 93;
FIELD_IDX_T ExtStratElt_ObjBetaMarg                  = 94;
FIELD_IDX_T ExtStratElt_ObjBetaContrib               = 95;
FIELD_IDX_T ExtStratElt_ObjBetaContribMarg           = 96;
FIELD_IDX_T ExtStratElt_ActualBeta                   = 97;
FIELD_IDX_T ExtStratElt_ActualBetaContrib            = 98;
FIELD_IDX_T ExtStratElt_EffBeta                      = 99;
FIELD_IDX_T ExtStratElt_EffBetaContrib               = 100;
FIELD_IDX_T ExtStratElt_ObjBetaCheckEn               = 101;
FIELD_IDX_T ExtStratElt_ObjCrtYield                  = 102;
FIELD_IDX_T ExtStratElt_ObjCrtYieldMarg              = 103;
FIELD_IDX_T ExtStratElt_ObjCrtYieldContrib           = 104;
FIELD_IDX_T ExtStratElt_ObjCrtYieldContribMarg       = 105;
FIELD_IDX_T ExtStratElt_ActualCrtYield               = 106;
FIELD_IDX_T ExtStratElt_ActualCrtYieldContrib        = 107;
FIELD_IDX_T ExtStratElt_EffCrtYield                  = 108;
FIELD_IDX_T ExtStratElt_EffCrtYieldContrib           = 109;
FIELD_IDX_T ExtStratElt_ObjCrtYieldCheckEn           = 110;
FIELD_IDX_T ExtStratElt_ObjTrackErr                  = 111;
FIELD_IDX_T ExtStratElt_ObjTrackErrMarg              = 112;
FIELD_IDX_T ExtStratElt_ActualTrackErr               = 113;
FIELD_IDX_T ExtStratElt_EffTrackErr                  = 114;
FIELD_IDX_T ExtStratElt_ObjTrackErrCheckEn           = 115;
FIELD_IDX_T ExtStratElt_CompChronoNat                = 116; /*PMSTA05345-CHU-080430*/
FIELD_IDX_T ExtStratElt_CompChronoCompNat            = 117; /*PMSTA05345-CHU-080430*/
FIELD_IDX_T ExtStratElt_MinRatingRank                = 118;
FIELD_IDX_T ExtStratElt_ActualRatingRank             = 119;
FIELD_IDX_T ExtStratElt_MinRatingCheckEn             = 120;
FIELD_IDX_T ExtStratElt_ObjConstrVal                 = 121;
FIELD_IDX_T ExtStratElt_ObjConstrMarg                = 122;
FIELD_IDX_T ExtStratElt_ObjConstrLimitNatEn          = 123;
FIELD_IDX_T ExtStratElt_ActConstrVal                 = 124;
FIELD_IDX_T ExtStratElt_ConstrCheckEn                = 125;
FIELD_IDX_T ExtStratElt_RecomNatEn                   = 126;
FIELD_IDX_T ExtStratElt_ActualOrderNatEn             = 127;
FIELD_IDX_T ExtStratElt_RecomCheckEn                 = 128;
FIELD_IDX_T ExtStratElt_StratCheckEn                 = 129;
FIELD_IDX_T ExtStratElt_SubstratCheckEn              = 130;
FIELD_IDX_T ExtStratElt_StratNatEn                   = 131;
FIELD_IDX_T ExtStratElt_StratLevel                   = 132;
FIELD_IDX_T ExtStratElt_ExtOpId                      = 133;
FIELD_IDX_T ExtStratElt_TradedNatureEn               = 134;
FIELD_IDX_T ExtStratElt_RoundLotQty                  = 135;
FIELD_IDX_T ExtStratElt_MinOrderQty                  = 136;
FIELD_IDX_T ExtStratElt_RoundLotAmt					 = 137; /* PMSTA-20988 - SHR - 150811 */
FIELD_IDX_T ExtStratElt_MinTradingAmt				 = 138; /* PMSTA-20988 - SHR - 150811 */
FIELD_IDX_T ExtStratElt_AvailableQty                 = 139;
FIELD_IDX_T ExtStratElt_OpNatEn                      = 140;
FIELD_IDX_T ExtStratElt_StratEltId                   = 141;
FIELD_IDX_T ExtStratElt_CalcEn                       = 142;
FIELD_IDX_T ExtStratElt_StopQuote                    = 143;
FIELD_IDX_T ExtStratElt_StopPrice                    = 144;
FIELD_IDX_T ExtStratElt_OrderValidityNatEn           = 145;
FIELD_IDX_T ExtStratElt_OrderLimitDate               = 146;
FIELD_IDX_T ExtStratElt_OrderSubNatEn                = 147;
FIELD_IDX_T ExtStratElt_SubPosNatEn                  = 148;
FIELD_IDX_T ExtStratElt_ChildPtfId                   = 149;
FIELD_IDX_T ExtStratElt_CriticalnessEn               = 150; /* REF11231-CHU-050630 */
FIELD_IDX_T ExtStratElt_MarketThirdId                = 151; /*PMSTA08359-BRO-090624*/
FIELD_IDX_T ExtStratElt_InvestProfileId				 = 152; /* PMSTA-38228 - LIK - 17122019 */
FIELD_IDX_T ExtStratElt_ModelConstrId                ;      /* PMSTA-13122 - LJE - 120628 */
FIELD_IDX_T ExtStratElt_ExtPosId                     ;
FIELD_IDX_T ExtStratElt_FixedCellFlg                 ;
FIELD_IDX_T ExtStratElt_Priority                     ;
FIELD_IDX_T ExtStratElt_ExcludedFlg                  ;  /* PMSTA-39969-sanand-05052020 */
FIELD_IDX_T ExtStratElt_NoTargetWeightEn             ;  /* PMSTA-40203-sanand-17062020 */
FIELD_IDX_T ExtStratElt_InitialDate                  ;
FIELD_IDX_T ExtStratElt_FinalDate                    ;
FIELD_IDX_T ExtStratElt_SubPeriodNatMask             ;
FIELD_IDX_T ExtStratElt_BenchRtn                     ;
FIELD_IDX_T ExtStratElt_PSPId                        ; /* REF9125 - LJE - 030818 */
FIELD_IDX_T ExtStratElt_BenchRtnCurr                 ; /* REF9227 - LJE - 030918 */
FIELD_IDX_T ExtStratElt_ConstrBoundNatEn             ; /*REF10599-BRO-041020*/
FIELD_IDX_T ExtStratElt_ConstrPriority               ; /*REF10599-BRO-041020*/
FIELD_IDX_T ExtStratElt_ConstrTreatEn                ; /*REF10599-BRO-041020*/
FIELD_IDX_T ExtStratElt_DynObjWeight			     ; /* REF11457-RAK-050928 */
FIELD_IDX_T ExtStratElt_OldObjWeight			     ; /* REF11457-EFE-051004 */
FIELD_IDX_T ExtStratElt_SelectedFlg                  ; /*  FIH-REF11457-051014 */
FIELD_IDX_T ExtStratElt_LeafFlg                      ; /*  FIH-REF11457-051024 */
FIELD_IDX_T ExtStratElt_IgnoreMarginFlg              ; /*PMSTA00970-BRO-070209*/
FIELD_IDX_T ExtStratElt_OrigObjWeightContrib         ; /* PMSTA15213-CHU-121107 */
FIELD_IDX_T ExtStratElt_TargetNatureEn               ; /* OCS43530-CHU-131015 */
FIELD_IDX_T ExtStratElt_ActRiskESEltId               ; /*PMSTA-18426-CHU-140919*/
FIELD_IDX_T ExtStratElt_EffRiskESEltId               ; /*PMSTA-18426-CHU-140919*/
FIELD_IDX_T ExtStratElt_LombardCheckId               ; /* PMSTA-20940-CHU-151006 */
FIELD_IDX_T ExtStratElt_EndDate                      ; /*PMSTA00965-CHU-070425*/
FIELD_IDX_T ExtStratElt_Min                          ; /*PMSTA05345-BRO-080219*/
FIELD_IDX_T ExtStratElt_Max                          ; /*PMSTA05345-BRO-080219*/
FIELD_IDX_T ExtStratElt_Par_ExtStratElt_Ext          ;
FIELD_IDX_T ExtStratElt_LnkPar_ExtStratElt_Ext       ;
FIELD_IDX_T ExtStratElt_OrdPar_ExtStratElt_Ext       ;
FIELD_IDX_T ExtStratElt_A_ScriptDef_Ext              ;
FIELD_IDX_T ExtStratElt_A_HoldConstrScript_Ext       ; /* PMSTA-28970 - CHU - 171226 */
FIELD_IDX_T ExtStratElt_A_TradConstrScript_Ext       ; /* PMSTA-28970 - CHU - 171226 */
FIELD_IDX_T ExtStratElt_ModelReading                 ;
FIELD_IDX_T ExtStratElt_NodeNatEn                    ;
FIELD_IDX_T ExtStratElt_ActualWeightContribCalc      ;
FIELD_IDX_T ExtStratElt_PosStatEn                    ;
FIELD_IDX_T ExtStratElt_CrtNetValForDura             ;
FIELD_IDX_T ExtStratElt_CrtMktValForDura             ;
FIELD_IDX_T ExtStratElt_WeightedDura				 ;	/* PMSTA-8822 - RAK - 091103 */
FIELD_IDX_T ExtStratElt_LimitQuote                   ;
FIELD_IDX_T ExtStratElt_LimitPrice                   ;
FIELD_IDX_T ExtStratElt_IntraMktSgtFlg               ;
FIELD_IDX_T ExtStratElt_SellPriority                 ;
FIELD_IDX_T ExtStratElt_EditBackupPtr                ;
FIELD_IDX_T ExtStratElt_MktSegtPriority              ;
FIELD_IDX_T ExtStratElt_MktStructLevel               ;
FIELD_IDX_T ExtStratElt_InstrNatEn                   ;
FIELD_IDX_T ExtStratElt_RefStratId                   ;	/* REF10270 - RAK - 040601 */
FIELD_IDX_T ExtStratElt_SubPosNat2En                 ; /* REF10624 - CHU - 040924 */
FIELD_IDX_T ExtStratElt_SubPosNat3En                 ; /* REF10624 - CHU - 040924 */
FIELD_IDX_T ExtStratElt_ChildBenchObjIdFlg           ; /* REF9125 - MCA - 031030 */ /*PMSTA00970-BRO-070209*/
FIELD_IDX_T ExtStratElt_OldObjWeightContribMarg      ; /* PMSTA00967-CHU-070104 */
FIELD_IDX_T ExtStratElt_DerivMarginToProcessFlg      ; /* PMSTA02593-CHU-070919 */
FIELD_IDX_T ExtStratElt_AttachToPtfHeadFlg           ; /* PMSTA06840-CHU-080723 */
FIELD_IDX_T ExtStratElt_Weight                       ; /* PMSTA7387-VST-090205 */
FIELD_IDX_T ExtStratElt_WeightNatEn                  ; /* PMSTA7387-VST-090205 */
FIELD_IDX_T ExtStratElt_CoreSatOrigStratId           ; /* PMSTA-18284 - CHU - 140619 */
FIELD_IDX_T ExtStratElt_RiskRuleCompoId              ; /* PMSTA-20235 - CHU - 150416  */
FIELD_IDX_T	ExtStratElt_MinInvestAmount				 ; /* PMSTA-38326-MUTHU-02012020 */
FIELD_IDX_T	ExtStratElt_MaxInvestAmount				 ; /* PMSTA-38326-MUTHU-02012020 */
FIELD_IDX_T ExtStratElt_InvestCheckEn				 ; /* PMSTA-38326-MUTHU-02012020 */
FIELD_IDX_T ExtStratElt_SubModelFlg		             ; /* PMSTA06840-Vishnu-16012020*/
FIELD_IDX_T ExtStratElt_DimStratDictId				 ; /* PMSTA-39045-BADHRI-140220 */
FIELD_IDX_T ExtStratElt_StratObjId					 ; /* PMSTA-39045-BADHRI-140220 */
FIELD_IDX_T ExtStratElt_OverlayPtfId                 ; /* PMSTA-39048 - vkumar - 240220 */
FIELD_IDX_T ExtStratElt_OrderAllocRulesEn			 ; /* PMSTA-40055 - vmuthu - 11052020 */
FIELD_IDX_T ExtStratElt_OrderBuyAllocRulesEn		 ; /* PMSTA-40055 - vmuthu - 11052020 */
FIELD_IDX_T ExtStratElt_ObjWeightExclSubModel        ; /* PMSTA-40170 - 130520 - vkumar */
FIELD_IDX_T ExtStratElt_ActWeightExclSubModel        ; /* PMSTA-40170 - 130520 - vkumar */
FIELD_IDX_T ExtStratElt_EffWeightExclSubModel        ; /* PMSTA-40170 - 130520 - vkumar */
FIELD_IDX_T ExtStratElt_AllocationRulePcnt			 ; /* PMSTA-40055 - vmuthu - 01062020 */
FIELD_IDX_T ExtStratElt_ProRataQty					 ; /* PMSTA-40055 - vmuthu - 01062020 */
FIELD_IDX_T ExtStratElt_ObjLowerMarg				 ; /* PMSTA-40213 - vmuthu - 20082020 */
FIELD_IDX_T ExtStratElt_ObjLowerContribMarg			 ; /* PMSTA-40213 - vmuthu - 20082020 */
FIELD_IDX_T ExtStratElt_ObjUpperMarg				 ; /* PMSTA-40213 - vmuthu - 20082020 */
FIELD_IDX_T ExtStratElt_ObjUpperContribMarg			 ; /* PMSTA-40213 - vmuthu - 20082020 */
FIELD_IDX_T ExtStratElt_OldObjLowerContribMarg		 ; /* PMSTA-40213 - badhri - 23072020 */
FIELD_IDX_T ExtStratElt_OldObjUpperContribMarg		 ; /* PMSTA-40213 - badhri - 23072020 */
FIELD_IDX_T ExtStratElt_OrderOrgQty					 ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtStratElt_SmartRoundingQty			 ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtStratElt_SmartRoundingRuleId			 ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtStratElt_OrigObjWgtContMarg		     ; /* PMSTA-41767 - VIG	   - 11092020 */
FIELD_IDX_T	ExtStratElt_MinThreshold                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_MaxThreshold                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_CashForecastM                ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_CashDeviationAmount          ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_MinForecast                  ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_MaxForecast                  ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
FIELD_IDX_T	ExtStratElt_OrdQtyPreFullRedemp          ; /* PMSTA-43100 - sanand - 29122020 */
FIELD_IDX_T ExtStratElt_QuasiCashEn 				 ; /* PMSTA-43175-Badhri-21122020 */
FIELD_IDX_T ExtStratElt_CrtMktValExclSubModelm 	     ; /* PMSTA-46776 - Vishnu - 26112021 autocash */
FIELD_IDX_T ExtStratElt_SeverityRuleId				 ; /*PMSTA-47502-Lalby-04032022*/
FIELD_IDX_T ExtStratElt_SeverityRuleElementId		 ; /*PMSTA-47502-Lalby-04032022*/
FIELD_IDX_T ExtStratElt_DeviationGapN				 ; /*PMSTA-47502-Lalby-04032022*/
FIELD_IDX_T ExtStratElt_DeviationDurationN           ; /*PMSTA-47502-Lalby-04032022*/
FIELD_IDX_T ExtStratElt_PtfOrderExistsFlg            ; /* PMSTA-50493 - JPR - 220920 */
FIELD_IDX_T ExtStratElt_ActMktVal                    ; /*PMSTA-51353-Satya-04012023*/
FIELD_IDX_T ExtStratElt_PtfScope                     ; /*PMSTA-51355-Satya*/
FIELD_IDX_T ExtStratElt_RiskVolElt                   ; /* WEALTH-1593 - JPR - 230831 */
FIELD_IDX_T ExtStratElt_SecInConstraint              ; /*PMSTA-52191-Ravindra-15092023*/
FIELD_IDX_T ExtStratElt_ModTradingConstraint         ; /*PMSTA-52191-Ravindra-15092023*/
FIELD_IDX_T ExtStratElt_OrderAmount                  ; /*WEALTH-16688-Satya*/
FIELD_IDX_T ExtStratElt_InitialDelFlg                ; /* PMSTA-62692 - KOR - 20241612 */

FIELD_IDX_T ExtStratElt_Elt_Dura                     = 0;
FIELD_IDX_T ExtStratElt_Elt_Beta                     = 1;
FIELD_IDX_T ExtStratElt_Elt_CrtYield                 = 2;
FIELD_IDX_T ExtStratElt_Elt_TrackErr                 = 3;
FIELD_IDX_T ExtStratElt_Elt_RatingRank               = 4;
FIELD_IDX_T ExtStratElt_Elt_Weight                   = 5;
FIELD_IDX_T ExtStratElt_Elt_WeightCalc               = 6;
FIELD_IDX_T ExtStratElt_Elt_CalcEn                   = 7;

/* PMSTA-18426 - CHU - 140923 */
FIELD_IDX_T A_RiskESElt_Id                           = 0;
FIELD_IDX_T A_RiskESElt_FctResultId                  = 1;
FIELD_IDX_T A_RiskESElt_ExtStratEltId                = 2;
FIELD_IDX_T A_RiskESElt_RiskStratId                  = 3;
FIELD_IDX_T A_RiskESElt_PostOrderFlg                 = 4;
FIELD_IDX_T A_RiskESElt_A_RiskESEltCompo_Ext         = 5;
FIELD_IDX_T A_RiskESElt_ValidDataFlg                 = 6;

/* PMSTA-18426 - CHU - 140923 */
FIELD_IDX_T A_RiskESEltCompo_Id                      = 0;
FIELD_IDX_T A_RiskESEltCompo_FctResultId             = 1;
FIELD_IDX_T A_RiskESEltCompo_RiskESEltId             = 2;
FIELD_IDX_T A_RiskESEltCompo_RiskNatEn               = 3;
FIELD_IDX_T A_RiskESEltCompo_DatatypeDictId          = 4;
FIELD_IDX_T A_RiskESEltCompo_ObjPct                  = 5;
FIELD_IDX_T A_RiskESEltCompo_ObjAmt                  = 6;
FIELD_IDX_T A_RiskESEltCompo_MinObjPct               = 7;
FIELD_IDX_T A_RiskESEltCompo_MaxObjPct               = 8;
FIELD_IDX_T A_RiskESEltCompo_MinObjAmt               = 9;
FIELD_IDX_T A_RiskESEltCompo_MaxObjAmt               = 10;
FIELD_IDX_T A_RiskESEltCompo_ActPct                  = 11;
FIELD_IDX_T A_RiskESEltCompo_ActAmt                  = 12;
FIELD_IDX_T A_RiskESEltCompo_SeverityEn              = 13;
FIELD_IDX_T A_RiskESEltCompo_CheckEn                 = 14;
FIELD_IDX_T A_RiskESEltCompo_Contrib                 = 15; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskESEltCompo_MarginalContrib         = 16; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskESEltCompo_IncrementalContrib      = 17; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskESEltCompo_StatusEn                = 18; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskESEltCompo_ComputationDate         = 19; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskESEltCompo_RiskValEltCmpId         = 20; /* PMSTA-64803 - VPR - 20250202*/


/* PMSTA-18426 - CHU - 141014 */
FIELD_IDX_T A_RiskValueEltCompo_Id                  = 0;
FIELD_IDX_T A_RiskValueEltCompo_RiskValueEltId      = 1;
FIELD_IDX_T A_RiskValueEltCompo_IndicatorNatEn      = 2;
FIELD_IDX_T A_RiskValueEltCompo_IndicatorValPct     = 3;
FIELD_IDX_T A_RiskValueEltCompo_IndicatorValAmt     = 4;
FIELD_IDX_T A_RiskValueEltCompo_Contrib             = 5; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskValueEltCompo_MarginalContrib     = 6; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskValueEltCompo_IncrementalContrib  = 7; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskValueEltCompo_StatusEn            = 8; /* PMSTA-30990 - CHU - 180417 */
FIELD_IDX_T A_RiskValueEltCompo_CurrId              = 9;

/* PMSTA-18426 - CHU - 141014 */
FIELD_IDX_T S_RiskValueEltCompo_Id                  = 0;
FIELD_IDX_T S_RiskValueEltCompo_RiskValueEltId      = 1;
FIELD_IDX_T S_RiskValueEltCompo_IndicatorNatEn      = 2;
FIELD_IDX_T S_RiskValueEltCompo_RiskValueElt        = 3;

FIELD_IDX_T SumRes_Id                                = 0;
FIELD_IDX_T SumRes_Level                             = 1;
FIELD_IDX_T SumRes_BreakVal                          = 2;
FIELD_IDX_T SumRes_Val                               = 3;
FIELD_IDX_T SumRes_CmpEn                             = 4;
FIELD_IDX_T SumRes_CmpVal                            = 5;
FIELD_IDX_T SumRes_CmpMarg                           = 6;
FIELD_IDX_T SumRes_CheckFlg                          = 7;
FIELD_IDX_T SumRes_SumResElt_Ext                     = 8;


FIELD_IDX_T SumResElt_ExtPosId                       = 0;
FIELD_IDX_T SumResElt_SumResId                       = 1;
FIELD_IDX_T SumResElt_Val                            = 2;
FIELD_IDX_T SumResElt_ExtPos_Ext                     = 3;


FIELD_IDX_T ExtOp_DbId                               = 0;
FIELD_IDX_T ExtOp_NatureEn                           = 1;
FIELD_IDX_T ExtOp_OpId                               = 2;
FIELD_IDX_T ExtOp_FctResultId                        = 3;
FIELD_IDX_T ExtOp_Cd                                 = 4;
FIELD_IDX_T ExtOp_FusionEn                           = 5;
FIELD_IDX_T ExtOp_InputUserId                        = 6;
FIELD_IDX_T ExtOp_TpId                               = 7;
FIELD_IDX_T ExtOp_SubTpId                            = 8;
FIELD_IDX_T ExtOp_MktThirdId                         = 9;
FIELD_IDX_T ExtOp_IntermThirdId                      = 10;
FIELD_IDX_T ExtOp_MgrId                              = 11;
FIELD_IDX_T ExtOp_RuleId                             = 12;
FIELD_IDX_T ExtOp_ValRuleEltId                       = 13;
FIELD_IDX_T ExtOp_SrcCd                              = 14;
FIELD_IDX_T ExtOp_SubPosNatEn                        = 15;
FIELD_IDX_T ExtOp_SubPosNat2En                       = 16;
FIELD_IDX_T ExtOp_SubPosNat3En                       = 17;
FIELD_IDX_T ExtOp_AdjSubPosNatEn                     = 18;
FIELD_IDX_T ExtOp_AdjSubPosNat2En                    = 19;
FIELD_IDX_T ExtOp_AdjSubPosNat3En                    = 20;
FIELD_IDX_T ExtOp_LockSubPosNatEn                    = 21;
FIELD_IDX_T ExtOp_LockSubPosNat2En                   = 22;
FIELD_IDX_T ExtOp_LockSubPosNat3En                   = 23;
FIELD_IDX_T ExtOp_LimitQuote                         = 24;
FIELD_IDX_T ExtOp_LimitPrice                         = 25;
FIELD_IDX_T ExtOp_StopQuote                          = 26;
FIELD_IDX_T ExtOp_StopPrice                          = 27;
FIELD_IDX_T ExtOp_OrderPriceNatEn                    = 28;
FIELD_IDX_T ExtOp_OrderValidNatEn                    = 29;
FIELD_IDX_T ExtOp_MinOrderQty                        = 30;
FIELD_IDX_T ExtOp_ValoSeqNo                          = 31;
FIELD_IDX_T ExtOp_ParOpCd                            = 32;
FIELD_IDX_T ExtOp_ParOpNatEn                         = 33;
FIELD_IDX_T ExtOp_CheckParentEn                      = 34;
FIELD_IDX_T ExtOp_CheckStratEn                       = 35;
FIELD_IDX_T ExtOp_OrderNatEn                         = 36;
FIELD_IDX_T ExtOp_BeginDate                          = 37;
FIELD_IDX_T ExtOp_EndDate                            = 38;
FIELD_IDX_T ExtOp_AcctDate                           = 39;
FIELD_IDX_T ExtOp_OpDate                             = 40;
FIELD_IDX_T ExtOp_ValuationDate                      = 41;
FIELD_IDX_T ExtOp_OrderLimitDate                     = 42;
FIELD_IDX_T ExtOp_ValueDate                          = 43;
FIELD_IDX_T ExtOp_RefOpCd                            = 44;
FIELD_IDX_T ExtOp_RefNatEn                           = 45;
FIELD_IDX_T ExtOp_StatusEn                           = 46;
FIELD_IDX_T ExtOp_SequenceNo                         = 47;
FIELD_IDX_T ExtOp_AcctCd                             = 48;
FIELD_IDX_T ExtOp_OpenOpCd                           = 49;
FIELD_IDX_T ExtOp_PtfId                              = 50;
FIELD_IDX_T ExtOp_PortPosSetId                       = 51;
FIELD_IDX_T ExtOp_AdjPtfId                           = 52;
FIELD_IDX_T ExtOp_CashPtfId                          = 53;
FIELD_IDX_T ExtOp_InstrId                            = 54;
FIELD_IDX_T ExtOp_ToInstrId                          = 55;
FIELD_IDX_T ExtOp_BalPosTpId                         = 56;
FIELD_IDX_T ExtOp_FromBpTpId                         = 57;
FIELD_IDX_T ExtOp_ToBpTpId                           = 58;
FIELD_IDX_T ExtOp_AcctId                             = 59;
FIELD_IDX_T ExtOp_Acct2Id                            = 60;
FIELD_IDX_T ExtOp_Acct3Id                            = 61;
FIELD_IDX_T ExtOp_LockInstrId                        = 62;
FIELD_IDX_T ExtOp_DepoId                             = 63;
FIELD_IDX_T ExtOp_LockDepoId                         = 64;
FIELD_IDX_T ExtOp_AdjInstrId                         = 65;
FIELD_IDX_T ExtOp_AdjDepoId                          = 66;
FIELD_IDX_T ExtOp_AdjBpTpId                          = 67;
FIELD_IDX_T ExtOp_OpCurrId                           = 68;
FIELD_IDX_T ExtOp_InstrCurrId                        = 69;
FIELD_IDX_T ExtOp_ToInstrCurrId                      = 70;
FIELD_IDX_T ExtOp_PtfCurrId                          = 71;
FIELD_IDX_T ExtOp_AcctCurrId                         = 72;
FIELD_IDX_T ExtOp_Acct2CurrId                        = 73;
FIELD_IDX_T ExtOp_Acct3CurrId                        = 74;
FIELD_IDX_T ExtOp_TradeCurrId                        = 75;
FIELD_IDX_T ExtOp_AdjInstrCurrId                     = 76;
FIELD_IDX_T ExtOp_AdjPosCurrId                       = 77;
FIELD_IDX_T ExtOp_AdjPortCurrId                      = 78;
FIELD_IDX_T ExtOp_CashPtfCurrId                      = 79;
FIELD_IDX_T ExtOp_LockOpCurrId                       = 80;
FIELD_IDX_T ExtOp_LockFiCurrId                       = 81;
FIELD_IDX_T ExtOp_CntPtyThirdId                      = 82;
FIELD_IDX_T ExtOp_TermTpId                           = 83;
FIELD_IDX_T ExtOp_LockTpId                           = 84;
FIELD_IDX_T ExtOp_AccrIntrBpTpId                     = 85;
FIELD_IDX_T ExtOp_ExtStratEltId                      = 86;
FIELD_IDX_T ExtOp_CloseOperId                        = 87;
FIELD_IDX_T ExtOp_CloseOperCd                        = 88;
FIELD_IDX_T ExtOp_ParentExtOpId                      = 89;
FIELD_IDX_T ExtOp_ExtOrderId                         = 90;
FIELD_IDX_T ExtOp_ExecSetCriteria                    = 91;
FIELD_IDX_T ExtOp_AdjNatEn                           = 92;
FIELD_IDX_T ExtOp_ExecOpId                           = 93;
FIELD_IDX_T ExtOp_ExecOpCd                           = 94;
FIELD_IDX_T ExtOp_ExecOpNatEn                        = 95;
FIELD_IDX_T ExtOp_ExecOpStatEn                       = 96;
FIELD_IDX_T ExtOp_RevOpCd                            = 97;
FIELD_IDX_T ExtOp_RevOpNatEn                         = 98;
FIELD_IDX_T ExtOp_LockOpCd                           = 99;
FIELD_IDX_T ExtOp_LockNatEn                          = 100;
FIELD_IDX_T ExtOp_EvtCd                              = 101;
FIELD_IDX_T ExtOp_EvtNbr                             = 102;
FIELD_IDX_T ExtOp_ExCouponFlg                        = 103;
FIELD_IDX_T ExtOp_FusRuleEn                          = 104;
FIELD_IDX_T ExtOp_LockLimitDate                      = 105;
FIELD_IDX_T ExtOp_ExpirDate                          = 106;
FIELD_IDX_T ExtOp_Remark                             = 107;
FIELD_IDX_T ExtOp_OpExchRate                         = 108;
FIELD_IDX_T ExtOp_InstrExchRate                      = 109;
FIELD_IDX_T ExtOp_SysExchRate                        = 110;
FIELD_IDX_T ExtOp_AcctExchRate                       = 111;
FIELD_IDX_T ExtOp_Acct2ExchRate                      = 112;
FIELD_IDX_T ExtOp_Acct3ExchRate                      = 113;
FIELD_IDX_T ExtOp_TradeExchRate                      = 114;
FIELD_IDX_T ExtOp_CashPtfExchRate                    = 115;
FIELD_IDX_T ExtOp_AdjInstrExchRate                   = 116;
FIELD_IDX_T ExtOp_AdjPosExchRate                     = 117;
FIELD_IDX_T ExtOp_AdjPtfExchRate                     = 118;
FIELD_IDX_T ExtOp_HistOpExchRate                     = 119;
FIELD_IDX_T ExtOp_HistInstrExchRate                  = 120;
FIELD_IDX_T ExtOp_HistSysExchRate                    = 121;
FIELD_IDX_T ExtOp_BookOpExchRate                     = 122;
FIELD_IDX_T ExtOp_BookInstrExchRate                  = 123;
FIELD_IDX_T ExtOp_BookSysExchRate                    = 124;
FIELD_IDX_T ExtOp_LockOpExchRate                     = 125;
FIELD_IDX_T ExtOp_LockFiExchRate                     = 126;
FIELD_IDX_T ExtOp_AdjQty                             = 127;
FIELD_IDX_T ExtOp_Qty                                = 128;
FIELD_IDX_T ExtOp_LockQty                            = 129;
FIELD_IDX_T ExtOp_Price                              = 130;
FIELD_IDX_T ExtOp_SpotPrice                          = 131;
FIELD_IDX_T ExtOp_HistPrice                          = 132;
FIELD_IDX_T ExtOp_BookPrice                          = 133;
FIELD_IDX_T ExtOp_LockDirtyPrice                     = 134;
FIELD_IDX_T ExtOp_LockCleanPrice                     = 135;
FIELD_IDX_T ExtOp_PriceCalcRuleEn                    = 136;
FIELD_IDX_T ExtOp_Quote                              = 137;
FIELD_IDX_T ExtOp_SpotQuote                          = 138;
FIELD_IDX_T ExtOp_HistQuote                          = 139;
FIELD_IDX_T ExtOp_BookQuote                          = 140;
FIELD_IDX_T ExtOp_LockDirtyQuote                     = 141;
FIELD_IDX_T ExtOp_LockCleanQuote                     = 142;
FIELD_IDX_T ExtOp_Rate                               = 143;
FIELD_IDX_T ExtOp_LockPriceMargin                    = 144;
FIELD_IDX_T ExtOp_SupplAmt                           = 145;
FIELD_IDX_T ExtOp_OpGrossAmt                         = 146;
FIELD_IDX_T ExtOp_AccrIntrAmt                        = 147;
FIELD_IDX_T ExtOp_OpNetAmt                           = 148;
FIELD_IDX_T ExtOp_InstrNetAmt                        = 149;
FIELD_IDX_T ExtOp_PtfNetAmt                          = 150;
FIELD_IDX_T ExtOp_SysNetAmt                          = 151;
FIELD_IDX_T ExtOp_AdjPosNetAmt                       = 152;
FIELD_IDX_T ExtOp_AdjPtfNetAmt                       = 153;
FIELD_IDX_T ExtOp_AcctNetAmt                         = 154;
FIELD_IDX_T ExtOp_Acct2NetAmt                        = 155;
FIELD_IDX_T ExtOp_Acct3NetAmt                        = 156;
FIELD_IDX_T ExtOp_HistOpNetAmt                       = 157;
FIELD_IDX_T ExtOp_HistInstrNetAmt                    = 158;
FIELD_IDX_T ExtOp_HistPtfNetAmt                      = 159;
FIELD_IDX_T ExtOp_HistSysNetAmt                      = 160;
FIELD_IDX_T ExtOp_BookOpNetAmt                       = 161;
FIELD_IDX_T ExtOp_BookInstrNetAmt                    = 162;
FIELD_IDX_T ExtOp_BookPtfNetAmt                      = 163;
FIELD_IDX_T ExtOp_BookSysNetAmt                      = 164;
FIELD_IDX_T ExtOp_Bp1TpId                            = 165;
FIELD_IDX_T ExtOp_Bp1CurrId                          = 166;
FIELD_IDX_T ExtOp_Bp1Amt                             = 167;
FIELD_IDX_T ExtOp_Bp2TpId                            = 168;
FIELD_IDX_T ExtOp_Bp2CurrId                          = 169;
FIELD_IDX_T ExtOp_Bp2Amt                             = 170;
FIELD_IDX_T ExtOp_Bp3TpId                            = 171;
FIELD_IDX_T ExtOp_Bp3CurrId                          = 172;
FIELD_IDX_T ExtOp_Bp3Amt                             = 173;
FIELD_IDX_T ExtOp_Bp4TpId                            = 174;
FIELD_IDX_T ExtOp_Bp4CurrId                          = 175;
FIELD_IDX_T ExtOp_Bp4Amt                             = 176;
FIELD_IDX_T ExtOp_Bp5TpId                            = 177;
FIELD_IDX_T ExtOp_Bp5CurrId                          = 178;
FIELD_IDX_T ExtOp_Bp5Amt                             = 179;
FIELD_IDX_T ExtOp_Bp6TpId                            = 180;
FIELD_IDX_T ExtOp_Bp6CurrId                          = 181;
FIELD_IDX_T ExtOp_Bp6Amt                             = 182;
FIELD_IDX_T ExtOp_Bp7TpId                            = 183;
FIELD_IDX_T ExtOp_Bp7CurrId                          = 184;
FIELD_IDX_T ExtOp_Bp7Amt                             = 185;
FIELD_IDX_T ExtOp_Bp8TpId                            = 186;
FIELD_IDX_T ExtOp_Bp8CurrId                          = 187;
FIELD_IDX_T ExtOp_Bp8Amt                             = 188;
FIELD_IDX_T ExtOp_Bp9TpId                            = 189;
FIELD_IDX_T ExtOp_Bp9CurrId                          = 190;
FIELD_IDX_T ExtOp_Bp9Amt                             = 191;
FIELD_IDX_T ExtOp_Bp10TpId                           = 192;
FIELD_IDX_T ExtOp_Bp10CurrId                         = 193;
FIELD_IDX_T ExtOp_Bp10Amt                            = 194;
FIELD_IDX_T ExtOp_ConfirmedFlg                       = 195;
FIELD_IDX_T ExtOp_DbStatusEn                         = 196;
FIELD_IDX_T ExtOp_AudUserName                        = 197;
FIELD_IDX_T ExtOp_AudModifDate                       = 198;
FIELD_IDX_T ExtOp_AudAction                          = 199;
FIELD_IDX_T ExtOp_LastUserId                         = 200;
FIELD_IDX_T ExtOp_LastModifDate                      = 201;
FIELD_IDX_T ExtOp_CreationTime                       = 202;
FIELD_IDX_T ExtOp_OrderCd                            = 203;
FIELD_IDX_T ExtOp_ExecutedFlg                        = 204;
FIELD_IDX_T ExtOp_OpActionEn                         = 205;
FIELD_IDX_T ExtOp_NoPositionFlg                      = 206;
FIELD_IDX_T ExtOp_OrderGroupingCd                    = 207;
FIELD_IDX_T ExtOp_OrderModeTypeId				     = 208; /*<REF11810-BRO-060608*/
FIELD_IDX_T ExtOp_TraderMgrId					     = 209;
FIELD_IDX_T ExtOp_AutoRenewalEn				         = 210;
FIELD_IDX_T ExtOp_RenewalTreatmtEn			         = 211;
FIELD_IDX_T ExtOp_RenewalEndValDate			         = 212;
FIELD_IDX_T ExtOp_RenewalLength					     = 213;
FIELD_IDX_T ExtOp_RenewalLengthUnitEn			     = 214;
FIELD_IDX_T ExtOp_ClientInitEn					     = 215;
FIELD_IDX_T ExtOp_ContractNumber				     = 216;
FIELD_IDX_T ExtOp_TransactionNatEn				     = 217; /*>REF11810-BRO-060608*/
FIELD_IDX_T ExtOp_RenewalIntRate                     = 218; /*REF11810-BRO-060628*/
FIELD_IDX_T ExtOp_RenewalAmount                      = 219; /*REF11810-BRO-060628*/
FIELD_IDX_T ExtOp_TargetNatureEn                     = 220; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_TargetNumber                       = 221; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_TargetAmount                       = 222; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_MarketSegmentId                    = 223; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_FactSheetEn                        = 224; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_LastQuoteDate                      = 225; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_LastQuoteNumber                    = 226; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_LastPriceNumber                    = 227; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_CommunicationDate                  = 228; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_CommunicationTypeId                = 229; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_CommPartyTypeId                    = 230; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ExtOp_Remark1                            = 231; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_Remark2                            = 232; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_Remark3                            = 233; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_TransmissionDate                   = 234; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_TransmissionTypeId                 = 235; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_OrderTypeId                        = 236; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_MMInterestAmount                   = 237; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_FxMarketRate                       = 238; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_FxClientRate                       = 239; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ExtOp_FxRateDirection                    = 240; /*PMSTA10733-TEB-101202*/
FIELD_IDX_T ExtOp_InterestMarketRate                 = 241; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_DebitToSysCurrRate                 = 242; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_CreditToSysCurrRate                = 243; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_ContractLengthNumber               = 244; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_ContractLengthUnitEn               = 245; /*PMSTA10733-TEB-101111*/
FIELD_IDX_T ExtOp_FxMarginNumber                     = 246; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ExtOp_FxMarginPrct                       = 247; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ExtOp_FxMarginAmount                     = 248; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ExtOp_ExecutionId                        = 249;
FIELD_IDX_T ExtOp_GlExecFeeId                        = 250;
FIELD_IDX_T ExtOp_DerivativeOrdEn					 = 251; /* OCS-43683 - TGU - 131107 */
FIELD_IDX_T ExtOp_FxFarLegAmount					 = 252; /* OCS43532-CHU-131112 */
FIELD_IDX_T ExtOp_FxSpotQuote					     = 253; /* OCS43532-CHU-131112 */
FIELD_IDX_T ExtOp_FxQuote						     = 254; /* OCS43532-CHU-131112 */
FIELD_IDX_T ExtOp_OrderFeeEn					     = 255; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ExtOp_OrderFeePrct						 = 256; /*PMSTA17221-CHU-131113*/
FIELD_IDX_T ExtOp_MaxOrderQty						 = 257; /*OCS-43526-CHU-131213*/
FIELD_IDX_T ExtOp_STPOrderEn						 = 258; /*PMSTA-16538-CHU-131204*/
FIELD_IDX_T ExtOp_UnpaidPrct						 = 259; /*PMSTA-16533-CHU-131204*/
FIELD_IDX_T ExtOp_FxSpotLegAmount				     = 260; /* OCS43532-CHU-131112 */
FIELD_IDX_T ExtOp_GroupingCriteria                   = 261;
FIELD_IDX_T ExtOp_EffectChildQty                     = 262;
FIELD_IDX_T ExtOp_FlowId                             = 263;
FIELD_IDX_T ExtOp_InitExtPosId                       = 264;
FIELD_IDX_T ExtOp_ExecQty                            = 265;
FIELD_IDX_T ExtOp_WeightMeanQuote                    = 266;
FIELD_IDX_T ExtOp_SelectedFlg                        = 267; /*  FIH-REF11457-051014 */
FIELD_IDX_T ExtOp_InSessionFlg                       = 268; /* PMSTA9052 - EFE - 091125 */
FIELD_IDX_T ExtOp_A_Flow_Ext                         = 270;
FIELD_IDX_T ExtOp_A_Ptf_Ext                          = 271;
FIELD_IDX_T ExtOp_A_Instr_Ext                        = 272;
FIELD_IDX_T ExtOp_Id                                 = 273;
FIELD_IDX_T ExtOp_ExtOp_Ext                          = 274;
FIELD_IDX_T ExtOp_ChildExtOp_Ext                     = 275;
FIELD_IDX_T ExtOp_ParExtOp_Ext                       = 276;
FIELD_IDX_T ExtOp_SysCurrId                          = 277;
FIELD_IDX_T ExtOp_PPSCurrId                          = 278;
FIELD_IDX_T ExtOp_CopiedPtfId                        = 279;
FIELD_IDX_T ExtOp_NoCheckImpactFlg                   = 280;
FIELD_IDX_T ExtOp_ParentId                           = 281;
FIELD_IDX_T ExtOp_NoCheckSynthAdminFlg               = 282;
FIELD_IDX_T ExtOp_AutoIndex                          = 283;
FIELD_IDX_T ExtOp_EditBackupPtr                      = 284;
FIELD_IDX_T ExtOp_ExtExecution_Ext                   = 286; /* REF8723 - TEB - 040218  */
FIELD_IDX_T ExtOp_DraftOrderId                       = 287;	/* REF8500 - 040510 - PMO  */
FIELD_IDX_T ExtOp_Summary                            = 288; /* PMSTA-11600 - RPO - 110322 */
FIELD_IDX_T ExtOp_EventStatusId                      = 289; /* PMSTA-17112 - EFE - 131210 */
FIELD_IDX_T ExtOp_EventActionEn                      = 290; /* PMSTA-17266 - DDV - 131217 */
FIELD_IDX_T ExtOp_TimeStamp                          = 291; /* Current value of the field  REF11780 - 100406 - PMO */
FIELD_IDX_T ExtOp_TimeStampNew                       = 292; /* New value after an "update" REF11780 - 100406 - PMO */
FIELD_IDX_T ExtOp_ChildPtfId                         = 293; /* PMSTA04637-CHU-080208 */
FIELD_IDX_T ExtOp_CompoundOrderMasterEltId           = 294; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtOp_CompoundOrderSlaveEltId            = 295; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtOp_CompoundOrderCode                  = 296; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtOp_CompoundOrderSlaveNbr              = 297; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtOp_CompoundImpactRule                 = 298; /* PMSTA-18636 - SHR - 140905 */
FIELD_IDX_T ExtOp_CompoundOrderMasterElt_Ext         = 299; /*  PMSTA-18639 - TGU - 141021 */
FIELD_IDX_T ExtOp_CompoundOrderSlaveElt_Ext          = 300; /*  PMSTA-18639 - TGU - 141021 */
FIELD_IDX_T ExtOp_CompoundScreenDictId               = 301; /* PMSTA-18601 - DDV - 141104 */
FIELD_IDX_T ExtOp_CompoundSlaveCode                  = 302; /* PMSTA-18601 - DDV - 141120 */
FIELD_IDX_T ExtOp_DisplayCondition					 = 301;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ExtOp_OrderType							 = 302;		/* PMSTA-21336 - TGU - 151013 */
FIELD_IDX_T ExtOp_CommonRef                          = 303; /* PMSTA-20886 - DDV - 151028 */
FIELD_IDX_T ExtOp_StandInstructIdx                   = 304; /* PMSTA-21265 - DDV - 151103 */
FIELD_IDX_T ExtOp_FlowIdx                            = 305; /* PMSTA-21265 - DDV - 151103 */
FIELD_IDX_T ExtOp_OrderInclusionEn                   = 306; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ExtOp_OrderRejectionDate                 = 307; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ExtOp_OrderRejectionComment              = 308; /* PMSTA-25576 - CHU - 170403 */
FIELD_IDX_T ExtOp_AcquisitionDate                    = 309; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtOp_CorporateActionNatEn               = 310; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtOp_TaxLotSourceCd                     = 311; /* PMSTA-28286 - CHU - 170905 */
FIELD_IDX_T ExtOp_StandInstructId                    = 312; /* PMSTA-28684 - CHU - 171024 */
FIELD_IDX_T ExtOp_BankFeePrct                        = 313; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ExtOp_BankFeeAmount                      = 314; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ExtOp_BankFeeCurrId 				     = 315; /* PMSTA-31134 - AiswaryaM - 20180504*/
FIELD_IDX_T ExtOp_PaymentOption                      = 316; /* PMSTA-30658 - AiswaryaM -20180503 */
FIELD_IDX_T ExtOp_BidTypeEn                          = 317; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid1Qty                            = 318; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid1Quote                          = 319; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid2Qty                            = 320; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid2Quote                          = 321; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid3Qty                            = 322; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_Bid3Quote                          = 323; /* PMSTA-31709 - AiswaryaM - 20180604*/
FIELD_IDX_T ExtOp_CounterpartAccount                 = 324;
FIELD_IDX_T ExtOp_CounterpartCurrencyId              = 325;
FIELD_IDX_T ExtOp_OpFusionRuleEn                     = 326; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ExtOp_GlobalPosFlg                       = 327; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ExtOp_AdjPosGrossAmt                     = 328; /* PMSTA-29531 - JBC - 171210 */
FIELD_IDX_T ExtOp_OtcOrderEn						 = 329;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ExtOp_DefaultFusRuleEn					 = 330;	/* PMSTA-34309 - RAK - 190130 */
FIELD_IDX_T ExtOp_CoolCancelEndDate                  = 331; /* PMSTA-34333 - Silpakal - 190201*/
FIELD_IDX_T ExtOp_FusionPrioEn                       = 332; /* PMSTA-32288 - JBC  - 190214 */
FIELD_IDX_T ExtOp_ExcludeFromBlockFlg                = 333; /* PMSTA-32251 - Smitha -180810 */
FIELD_IDX_T ExtOp_ExternalBankBic                    = 334; /* PMSTA-35577 - Kramadevi - 260419*/
FIELD_IDX_T ExtOp_ExternalBankName                   = 335; /* PMSTA-35577 - Kramadevi - 260419*/
FIELD_IDX_T ExtOp_ExternalBankAcctOwnrName           = 336; /* PMSTA-35577 - Kramadevi - 260419*/
FIELD_IDX_T ExtOp_HedgeTradeEn                       = 337; /* PMSTA-35985 - Kramadevi  - 230519 */
FIELD_IDX_T ExtOp_FixingDate                         = 338; /* PMSTA-36034 - KNI - 190603*/
FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr1             = 339; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr2             = 340; /* 2MSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr3             = 341; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr4             = 342; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_PayRef1                            = 343; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_PayRef2                            = 344; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_PayRef3                            = 345; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_PayRef4                            = 346; /* PMSTA-36651 - Kramadevi  - 19072019 */
FIELD_IDX_T ExtOp_ExternalTradeFlg                   = 347; /* PMSTA-36524 - Grace      - 03072019*/
FIELD_IDX_T ExtOp_SwitchingCriteria					 = 348; /* PMSTA-37058 - Silpakal - 190903*/
FIELD_IDX_T ExtOp_OrderCheckEn						 = 349;
FIELD_IDX_T	ExtOp_OriginalQty						 = 350;	/* PMSTA-37908 - adarshn	- 191119 */
FIELD_IDX_T	ExtOp_OrderNettingEn					 = 351;	/* PMSTA-37908 - adarshn	- 191119 */
FIELD_IDX_T ExtOp_NettingCriteria                    = 352; /* PMSTA-37908 - adarshn	- 24012020 */
FIELD_IDX_T ExtOp_PaymentDate                        = 353; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtOp_PaymentStatusEn                    = 354; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtOp_SettlementDate                     = 355; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T ExtOp_SettleStatusEn                     = 356; /* PMSTA-38730 - Silpakal - 200204 */
FIELD_IDX_T	ExtOp_CommissionCdEn                     = 357;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_ChargeCdEn                         = 358;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_OriginalAmount                     = 359;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_CounterpartOrgAmount               = 360;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_ExternalFeeM                       = 361;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_TotalChargesM                      = 362;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_CounterpartAmount                  = 363;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_OpLinkageCd                        = 364;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T	ExtOp_ChargedCustomerName                = 365;	/* PMSTA-38796 - cha - 03022020 */
FIELD_IDX_T ExtOp_BoPtfId                            = 366; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T ExtOp_BoAccountId                        = 367; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_OpSplitRuleEn                      = 368; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_AdjBoPtfId                         = 369; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_CoaExDate                          = 370; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_BoCashAcctId                       = 371; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_BoCashPtfId                        = 372; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_SplitParentOperId                  = 373; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	ExtOp_OriginalNetAmount					 = 374;	/* PMSTA-39927 - Siva - 04292020 */
FIELD_IDX_T	ExtOp_SplitParOpCd						 = 375;	/* PMSTA-40714 */
FIELD_IDX_T ExtOp_RuleApplicabilityEn				 = 376; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtOp_SmartRoundingQty					 = 377; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtOp_SmartRoundingOrgQty				 = 378; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtOp_RoundingOrgQty					 = 379; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtOp_SmartRoundingFlg					 = 380; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T ExtOp_SmartRoundingRuleId				 = 381; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T	ExtOp_HierOperNatEn                      = 382;	/* PMSTA-40208 - adarshn - 01092020 */
FIELD_IDX_T ExtOp_HierOperationCd                    = 383;	/* PMSTA-40208 - adarshn - 01092020 */
FIELD_IDX_T ExtOp_ParentHierExtOpId                  = 384;	/* PMSTA-40208 - adarshn - 01092020 */
FIELD_IDX_T ExtOp_OrderSeqRankNbr    				 = 385; /* PMSTA-41770 - Vishnu -270920 : order sequencing*/
FIELD_IDX_T	ExtOp_HierGroupingCriteria               = 386; /* PMSTA-40208 - sanand	- 24092020 */
FIELD_IDX_T ExtOp_CashPlanId                         = 387; /*PMSTA-42402 Autocash Vishnu 16112020*/
FIELD_IDX_T ExtOp_OrdQtyPreFullRedemp                = 388; /* PMSTA-43100 - sanand - 29122020 */
FIELD_IDX_T ExtOp_CumulativeAmt                      = 389; /* PMSTA-43100 - sanand - 29122020 */
FIELD_IDX_T	ExtOp_NotionalInstrId                    = 390;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	ExtOp_InvestLimitEn                      = 391; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	ExtOp_AdjRefNatEn                        = 392; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T	ExtOp_AdjRefOperCd                       = 393; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T ExtOp_SetOfFeesId						 = 394; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ExtOp_SetOfProductFeesId				 = 395; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T ExtOp_BoRoutingBusEntityId				 = 396; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T ExtOp_OrderSubTypeId                     = 397; /* WEALTH-157 - Deepthi - 20230404 */
FIELD_IDX_T ExtOp_ApplSessionCd                      = 398; /* WEALTH-3007 - JPR - 20231031 */
FIELD_IDX_T	ExtOp_SetOfOtherFeesId                   = 399; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	ExtOp_TraderThirdId                      = 400; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	ExtOp_ParAdjExtOp_Ext                    = 401; /* PMSTA - 54624 - SRS - 240118 */
FIELD_IDX_T	ExtOp_NetSettleAmount                    = 402; /* WEALTH-9095 - SENTHIL - 20240529 */
FIELD_IDX_T ExtOp_PremiumCurrencyId                  = 403; /* WEALTH-8559 - Senthil - 20240607 */
FIELD_IDX_T ExtOp_PremiumAmount                      = 404; /* WEALTH-8559 - Senthil - 20240607 */


FIELD_IDX_T Imp_OpV2_Cd                              = 0;
FIELD_IDX_T Imp_OpV2_NatEn                           = 1;
FIELD_IDX_T Imp_OpV2_FwdSplitFlg                     = 2;
FIELD_IDX_T Imp_OpV2_InstrId                         = 3;
FIELD_IDX_T Imp_OpV2_PtfId                           = 4;
FIELD_IDX_T Imp_OpV2_BeginDate                       = 5;
FIELD_IDX_T Imp_OpV2_EndDate                         = 6;


FIELD_IDX_T Curr_Modif_EntDictId                     = 0;
FIELD_IDX_T Curr_Modif_ObjId                         = 1;
FIELD_IDX_T Curr_Modif_PortModifEn                   = 2;
FIELD_IDX_T Curr_Modif_OldCurrId                     = 3;
FIELD_IDX_T Curr_Modif_NewCurrId                     = 4;
FIELD_IDX_T Curr_Modif_PortPosSetId                  = 5;
FIELD_IDX_T Curr_Modif_OldSysCurrId                  = 6;
FIELD_IDX_T Curr_Modif_NewSysCurrId                  = 7;
FIELD_IDX_T Curr_Modif_EntSqlName                    = 8;
FIELD_IDX_T Curr_Modif_ObjCd                         = 9;
FIELD_IDX_T Curr_Modif_OldCurrCd                     = 10;
FIELD_IDX_T Curr_Modif_NewCurrCd                     = 11;
FIELD_IDX_T Curr_Modif_PpsCurrCd                     = 12;
FIELD_IDX_T Curr_Modif_PpsTypeCd                     = 13;
FIELD_IDX_T Curr_Modif_PpsConsPtfCd                  = 14;
FIELD_IDX_T Curr_Modif_OldSysCurrCd                  = 15;
FIELD_IDX_T Curr_Modif_NewSysCurrCd                  = 16;
FIELD_IDX_T Curr_Modif_InstrBusEntityCd              = 17;
FIELD_IDX_T Curr_Modif_GuiFlg                        = 18;

FIELD_IDX_T Msg_NatEn                                = 0;
FIELD_IDX_T Msg_String                               = 1;
FIELD_IDX_T Msg_FldIdx                               = 2;
FIELD_IDX_T Msg_AttrSqlName                          = 3;        /*  HFI-PMSTA-19056-141106  */
FIELD_IDX_T Msg_EntDictId                            = 4;        /*  HFI-PMSTA-19056-141106  */
FIELD_IDX_T Msg_CaseMgtTypeId                        = 5;        /* WEALTH-9976 - KKM - 10072024 */


FIELD_IDX_T Select_Res_Tab_DataTab                   = 0;


FIELD_IDX_T ExportCtx_Arg_EntDictId         =   0;
FIELD_IDX_T ExportCtx_Arg_ListId            =   1;
FIELD_IDX_T ExportCtx_Arg_ListScript        =   2;
FIELD_IDX_T ExportCtx_Arg_FmtId             =   3;
FIELD_IDX_T ExportCtx_Arg_MaxRowsNbr        =   4;
FIELD_IDX_T ExportCtx_Arg_ColNbr            =   5;
FIELD_IDX_T ExportCtx_Arg_Updstatus_sign    =   6;
FIELD_IDX_T ExportCtx_Arg_Updstatus_val     =   7;
FIELD_IDX_T ExportCtx_Arg_LanguageDictId    =   8;  /* REF8952 - DDV - 030919 */
FIELD_IDX_T ExportCtx_Arg_UseFmtFilterFlg   =   9;  /* REF10743 - CHU - 041104 */
FIELD_IDX_T ExportCtx_Arg_ExportDate        =  10; /* REF11221 - TGU - 060421 */
FIELD_IDX_T ExportCtx_Arg_UserId            =  11; /* REF11476 - TEB - 051026 */
FIELD_IDX_T ExportCtx_Arg_Param1            =  12; /* PMSTA06646 - LJE - 080616 */
FIELD_IDX_T ExportCtx_Arg_Param2            =  13; /* PMSTA06646 - LJE - 080616 */
FIELD_IDX_T ExportCtx_Arg_Param3            =  14; /* PMSTA06646 - LJE - 080616 */
FIELD_IDX_T ExportCtx_Arg_Param4            =  15; /* PMSTA06646 - LJE - 080616 */
FIELD_IDX_T ExportCtx_Arg_Param5            =  16; /* PMSTA06646 - LJE - 080616 */
FIELD_IDX_T ExportCtx_Arg_DataProfId        =  17; /* PMSTA07422 - DDV - 090520 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol1   =  18;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol2   =  19;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol3   =  20;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol4   =  21;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol5   =  22;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol6   =  23;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol7   =  24;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol8   =  25;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol9   =  26;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol10	=  27;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol11	=  28;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol12	=  29;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol13	=  30;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol14	=  31;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol15	=  32;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol16	=  33;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol17	=  34;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol18	=  35;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol19	=  36;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol20	=  37;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol21	=  38;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol22	=  39;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol23	=  40;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol24	=  41;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol25	=  42;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol26	=  43;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol27	=  44;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol28	=  45;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol29	=  46;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol30	=  47;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol31	=  48;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol32	=  49;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol33	=  50;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol34	=  51;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol35	=  52;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol36	=  53;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol37	=  54;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol38	=  55;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol39	=  56;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol40	=  57;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol41	=  58;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol42	=  59;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol43	=  60;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol44	=  61;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol45	=  62;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol46	=  63;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol47	=  64;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol48	=  65;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol49	=  66;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol50	=  67;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol51	=  68;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol52	=  69;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol53	=  70;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol54	=  71;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol55	=  72;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol56	=  73;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol57	=  74;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol58	=  75;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol59	=  76;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol60	=  77;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol61	=  78;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol62	=  79;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol63	=  80;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol64	=  81;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol65	=  82;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol66	=  83;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol67	=  84;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol68	=  85;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol69	=  86;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol70	=  87;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol71	=  88;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol72	=  89;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol73	=  90;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol74	=  91;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol75	=  92;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol76	=  93;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol77	=  94;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol78	=  95;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol79	=  96;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol80	=  97;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol81	=  98;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol82	=  99;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol83	= 100;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol84	= 101;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol85	= 102;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol86	= 103;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol87	= 104;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol88	= 105;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol89	= 106;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol90	= 107;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol91	= 108;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol92	= 109;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol93	= 110;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol94	= 111;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol95	= 112;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol96	= 113;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol97	= 114;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol98	= 115;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol99	= 116;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol100	= 117;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol101	= 118;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol102	= 119;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol103	= 120;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol104	= 121;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol105	= 122;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol106	= 123;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol107	= 124;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol108	= 125;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol109	= 126;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol110	= 127;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol111	= 128;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol112	= 129;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol113	= 130;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol114	= 131;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol115	= 132;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol116	= 133;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol117	= 134;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol118	= 135;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol119	= 136;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol120	= 137;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol121	= 138;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol122	= 139;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol123	= 140;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol124	= 141;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol125	= 142;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol126	= 143;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol127	= 144;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol128	= 145;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol129	= 146;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol130	= 147;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol131	= 148;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol132	= 149;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol133	= 150;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol134	= 151;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol135	= 152;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol136	= 153;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol137	= 154;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol138	= 155;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol139	= 156;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol140	= 157;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol141	= 158;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol142	= 159;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol143	= 160;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol144	= 161;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol145	= 162;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol146	= 163;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol147	= 164;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol148	= 165;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol149	= 166;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol150	= 167;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol151	= 168;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol152	= 169;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol153	= 170;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol154	= 171;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol155	= 172;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol156	= 173;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol157	= 174;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol158	= 175;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol159	= 176;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol160	= 177;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol161	= 178;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol162	= 179;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol163	= 180;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol164	= 181;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol165	= 182;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol166	= 183;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol167	= 184;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol168	= 185;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol169	= 186;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol170	= 187;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol171	= 188;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol172	= 189;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol173	= 190;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol174	= 191;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol175	= 192;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol176	= 193;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol177	= 194;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol178	= 195;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol179	= 196;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol180	= 197;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol181	= 198;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol182	= 199;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol183	= 200;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol184	= 201;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol185	= 202;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol186	= 203;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol187	= 204;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol188	= 205;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol189	= 206;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol190	= 207;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol191	= 208;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol192	= 209;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol193	= 210;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol194	= 211;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol195	= 212;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol196	= 213;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol197	= 214;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol198	= 215;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol199	= 216;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol200	= 217;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol201	= 218;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol202	= 219;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol203	= 220;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol204	= 221;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol205	= 222;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol206	= 223;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol207	= 224;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol208	= 225;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol209	= 226;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol210	= 227;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol211	= 228;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol212	= 229;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol213	= 230;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol214	= 231;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol215	= 232;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol216	= 233;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol217	= 234;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol218	= 235;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol219	= 236;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol220	= 237;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol221	= 238;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol222	= 239;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol223	= 240;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol224	= 241;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol225	= 242;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol226	= 243;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol227	= 244;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol228	= 245;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol229	= 246;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol230	= 247;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol231	= 248;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol232	= 249;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol233	= 250;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol234	= 251;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol235	= 252;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol236	= 253;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol237	= 254;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol238	= 255;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol239	= 256;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol240	= 257;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol241	= 258;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol242	= 259;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol243	= 260;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol244	= 261;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol245	= 262;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol246	= 263;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol247	= 264;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol248	= 265;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol249	= 266;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol250	= 267;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol251	= 268;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol252	= 269;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol253	= 270;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol254	= 271;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol255	= 272;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol256	= 273;
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol257	= 274; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol258	= 275; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol259	= 276; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol260	= 277; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol261	= 278; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol262	= 279; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol263	= 280; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol264	= 281; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol265	= 282; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol266	= 283; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol267	= 284; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol268	= 285; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol269	= 286; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol270	= 287; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol271	= 288; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol272	= 289; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol273	= 290; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol274	= 291; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol275	= 292; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol276	= 293; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol277	= 294; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol278	= 295; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol279	= 296; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol280	= 297; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol281	= 298; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol282	= 299; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol283	= 300; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol284	= 301; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol285	= 302; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol286	= 303; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol287	= 304; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol288	= 305; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol289	= 306; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol290	= 307; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol291	= 308; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol292	= 309; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol293	= 310; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol294	= 311; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol295	= 312; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol296	= 313; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol297	= 314; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol298	= 315; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol299	= 316; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol300	= 317; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol301	= 318; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol302	= 319; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol303	= 320; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol304	= 321; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol305	= 322; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol306	= 323; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol307	= 324; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol308	= 325; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol309	= 326; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol310	= 327; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol311	= 328; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol312	= 329; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol313	= 330; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol314	= 331; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol315	= 332; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol316	= 333; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol317	= 334; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol318	= 335; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol319	= 336; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol320	= 337; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol321	= 338; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol322	= 339; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol323	= 340; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol324	= 341; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol325	= 342; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol326	= 343; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol327	= 344; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol328	= 345; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol329	= 346; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol330	= 347; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol331	= 348; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol332	= 349; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol333	= 350; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol334	= 351; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol335	= 352; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol336	= 353; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol337	= 354; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol338	= 355; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol339	= 356; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol340	= 357; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol341	= 358; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol342	= 359; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol343	= 360; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol344	= 361; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol345	= 362; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol346	= 363; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol347	= 364; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol348	= 365; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol349	= 366; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol350	= 367; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol351	= 368; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol352	= 369; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol353	= 370; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol354	= 371; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol355	= 372; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol356	= 373; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol357	= 374; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol358	= 375; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol359	= 376; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol360	= 377; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol361	= 378; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol362	= 379; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol363	= 380; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol364	= 381; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol365	= 382; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol366	= 383; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol367	= 384; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol368	= 385; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol369	= 386; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol370	= 387; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol371	= 388; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol372	= 389; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol373	= 390; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol374	= 391; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol375	= 392; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol376	= 393; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol377	= 394; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol378	= 395; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol379	= 396; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol380	= 397; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol381	= 398; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol382	= 399; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol383	= 400; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol384	= 401; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol385	= 402; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol386	= 403; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol387	= 404; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol388	= 405; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol389	= 406; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol390	= 407; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol391	= 408; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol392	= 409; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol393	= 410; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol394	= 411; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol395	= 412; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol396	= 413; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol397	= 414; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol398	= 415; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol399	= 416; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol400	= 417; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol401	= 418; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol402	= 419; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol403	= 420; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol404	= 421; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol405	= 422; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol406	= 423; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol407	= 424; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol408	= 425; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol409	= 426; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol410	= 427; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol411	= 428; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol412	= 429; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol413	= 430; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol414	= 431; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol415	= 432; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol416	= 433; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol417	= 434; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol418	= 435; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol419	= 436; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol420	= 437; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol421	= 438; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol422	= 439; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol423	= 440; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol424	= 441; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol425	= 442; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol426	= 443; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol427	= 444; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol428	= 445; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol429	= 446; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol430	= 447; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol431	= 448; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol432	= 449; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol433	= 450; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol434	= 451; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol435	= 452; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol436	= 453; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol437	= 454; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol438	= 455; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol439	= 456; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol440	= 457; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol441	= 458; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol442	= 459; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol443	= 460; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol444	= 461; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol445	= 462; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol446	= 463; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol447	= 464; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol448	= 465; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol449	= 466; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol450	= 467; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol451	= 468; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol452	= 469; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol453	= 470; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol454	= 471; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol455	= 472; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol456	= 473; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol457	= 474; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol458	= 475; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol459	= 476; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol460	= 477; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol461	= 478; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol462	= 479; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol463	= 480; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol464	= 481; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol465	= 482; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol466	= 483; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol467	= 484; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol468	= 485; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol469	= 486; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol470	= 487; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol471	= 488; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol472	= 489; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol473	= 490; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol474	= 491; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol475	= 492; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol476	= 493; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol477	= 494; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol478	= 495; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol479	= 496; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol480	= 497; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol481	= 498; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol482	= 499; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol483	= 500; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol484	= 501; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol485	= 502; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol486	= 503; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol487	= 504; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol488	= 505; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol489	= 506; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol490	= 507; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol491	= 508; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol492	= 509; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol493	= 510; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol494	= 511; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol495	= 512; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol496	= 513; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol497	= 514; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol498	= 515; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol499	= 516; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol500	= 517; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol501	= 518; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol502	= 519; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol503	= 520; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol504	= 521; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol505	= 522; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol506	= 523; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol507	= 524; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol508	= 525; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol509	= 526; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol510	= 527; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol511	= 528; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol512	= 529; /* EFE - PMSTA-27146 - 20180704 */
FIELD_IDX_T	ExportCtx_Arg_TslDbName	        = 530;
FIELD_IDX_T	ExportCtx_Arg_TslJobId	        = 531;
FIELD_IDX_T	ExportCtx_Arg_TslChunkNumber    = 532;
FIELD_IDX_T	ExportCtx_Arg_DataSetId         = 533;
FIELD_IDX_T ExportCtx_Arg_ApplSessionCd     = 534;  /* PMSTA-22549 - CHU - 160512 */
FIELD_IDX_T ExportCtx_Arg_ExportModeEn      = 535;  /* PMSTA-52258 - JBC - 230308 */


FIELD_IDX_T Export_FmtElt_ObjId                      = 0;
FIELD_IDX_T Export_FmtElt_Rank                       = 1;
FIELD_IDX_T Export_FmtElt_DataTpDictId               = 2;
FIELD_IDX_T Export_FmtElt_Def                        = 3;
FIELD_IDX_T Export_FmtElt_DspFmt                     = 4;
FIELD_IDX_T Export_FmtElt_ColWidth                   = 5;
FIELD_IDX_T Export_FmtElt_JustifEn                   = 6;
FIELD_IDX_T Export_FmtElt_Denom                      = 7;
FIELD_IDX_T Export_FmtElt_Sqlname                    = 8;  /* REF9007.4002 - DLA for DDV - 030818 */

#ifdef PMSTA17265
FIELD_IDX_T Export_FmtElt_LangDictId                 = 9;
FIELD_IDX_T Export_FmtElt_TlsMultilingualEn          =10;
#endif

FIELD_IDX_T A_CellFmt_Sqlname                        = 0;
FIELD_IDX_T A_CellFmt_MinVal                         = 1;
FIELD_IDX_T A_CellFmt_MinIncFlg                      = 2;
FIELD_IDX_T A_CellFmt_MaxVal                         = 3;
FIELD_IDX_T A_CellFmt_MaxIncFlg                      = 4;
FIELD_IDX_T A_CellFmt_IconName                       = 5;
FIELD_IDX_T A_CellFmt_BgColorEn                      = 6;
FIELD_IDX_T A_CellFmt_FgColorEn                      = 7;
FIELD_IDX_T A_CellFmt_BoldFlg                        = 8;
FIELD_IDX_T A_CellFmt_ItalicFlg                      = 9;
FIELD_IDX_T A_CellFmt_Justif                         = 10;
FIELD_IDX_T A_CellFmt_BumpFlg                        = 11;
FIELD_IDX_T A_CellFmt_BgColorName                    = 12;
FIELD_IDX_T A_CellFmt_FgColorName                    = 13;


FIELD_IDX_T A_CompInstrChrono_EntDictId              = 0;
FIELD_IDX_T A_CompInstrChrono_ObjId                  = 1;
FIELD_IDX_T A_CompInstrChrono_NatEn                  = 2;
FIELD_IDX_T A_CompInstrChrono_CalcDate               = 3;
FIELD_IDX_T A_CompInstrChrono_ForceFlg               = 4;
FIELD_IDX_T A_CompInstrChrono_DeleteFlg              = 5;
FIELD_IDX_T A_CompInstrChrono_NatMask                = 6;

/* PMSTA-18426 - CHU - 141004 */
FIELD_IDX_T A_CompComplChrono_EntDictId              = 0;
FIELD_IDX_T A_CompComplChrono_ObjId                  = 1;
FIELD_IDX_T A_CompComplChrono_NatEn                  = 2;
FIELD_IDX_T A_CompComplChrono_ConfidenceLevel        = 3;
FIELD_IDX_T A_CompComplChrono_TimeHorizon            = 4;
FIELD_IDX_T A_CompComplChrono_TimeHorizonUnitEn      = 5;
FIELD_IDX_T A_CompComplChrono_CalcDate               = 6;
FIELD_IDX_T A_CompComplChrono_ForceFlg               = 7;
FIELD_IDX_T A_CompComplChrono_DeleteFlg              = 8;
FIELD_IDX_T A_CompComplChrono_NatMask                = 9;

FIELD_IDX_T Search_BestOper_PtfObjId                 = 0;
FIELD_IDX_T Search_BestOper_InstrObjId               = 1;
FIELD_IDX_T Search_BestOper_OpNatEn                  = 2;
FIELD_IDX_T Search_BestOper_MinStatEn                = 3;
FIELD_IDX_T Search_BestOper_MaxStatEn                = 4;
FIELD_IDX_T Search_BestOper_InterpFromDate           = 5;
FIELD_IDX_T Search_BestOper_InterpTillDate           = 6;
FIELD_IDX_T Search_BestOper_FusDateRuleEn            = 7;
FIELD_IDX_T Search_BestOper_DateMargin               = 8;
FIELD_IDX_T Search_BestOper_Param1Attribute          = 9;
FIELD_IDX_T Search_BestOper_Param1Margin             = 10;
FIELD_IDX_T Search_BestOper_Param1Result             = 11;
FIELD_IDX_T Search_BestOper_Param2Attribute          = 12;
FIELD_IDX_T Search_BestOper_Param2Margin             = 13;
FIELD_IDX_T Search_BestOper_Param2Result             = 14;
FIELD_IDX_T Search_BestOper_Param3Attribute          = 15;
FIELD_IDX_T Search_BestOper_Param3Margin             = 16;
FIELD_IDX_T Search_BestOper_Param3Result             = 17;
FIELD_IDX_T Search_BestOper_Param4Attribute          = 18;
FIELD_IDX_T Search_BestOper_Param4Margin             = 19;
FIELD_IDX_T Search_BestOper_Param4Result             = 20;
FIELD_IDX_T Search_BestOper_Param5Attribute          = 21;
FIELD_IDX_T Search_BestOper_Param5Margin             = 22;
FIELD_IDX_T Search_BestOper_Param5Result             = 23;


FIELD_IDX_T Current_Load_ActivFusNbr                 = 0;
FIELD_IDX_T Current_Load_BigPtfFlg                   = 1;
FIELD_IDX_T Current_Load_ActiveStockIds              = 2;
FIELD_IDX_T Current_Load_NotifFail_StockId           = 3;
FIELD_IDX_T Current_Load_NotifFail_RequestId         = 4;
FIELD_IDX_T Current_Load_NotifFail_PtfListId         = 5;
FIELD_IDX_T Current_Load_NotifFail_PtfStsList        = 6;
FIELD_IDX_T Current_Load_NotifFail_BusEntityCd       = 7;
FIELD_IDX_T Current_Load_NotifFail_MoreToSendFlg     = 8;


FIELD_IDX_T PtfQtyAlloc_InstrId                      = 0;
FIELD_IDX_T PtfQtyAlloc_PtfId                        = 1;
FIELD_IDX_T PtfQtyAlloc_Qty                          = 2;


FIELD_IDX_T MktSgtInstr_InstrId                      = 0;
FIELD_IDX_T MktSgtInstr_GridId                       = 1;
FIELD_IDX_T MktSgtInstr_MktSgtId                     = 2;
FIELD_IDX_T MktSgtInstr_RecommStratId                = 3;


FIELD_IDX_T Bench_Weight_InstrId                     = 0;
FIELD_IDX_T Bench_Weight_ObjId                       = 1;
FIELD_IDX_T Bench_Weight_Weight                      = 2;
FIELD_IDX_T Bench_Weight_BeginDate                   = 3;
FIELD_IDX_T Bench_Weight_ApplicDate                  = 4;
FIELD_IDX_T Bench_Weight_RecomNatEn                  = 5;


FIELD_IDX_T A_FTConv_Id                              = 0;
FIELD_IDX_T A_FTConv_Code                            = 1;
FIELD_IDX_T A_FTConv_Name                            = 2;
FIELD_IDX_T A_FTConv_Denom                           = 3;
FIELD_IDX_T A_FTConv_ClassifId                       = 4;
FIELD_IDX_T A_FTConv_TaxGeoId                        = 5;
FIELD_IDX_T A_FTConv_DataSecuProfId                  = 6; /* REF9910 - LJE - 040218 */
FIELD_IDX_T A_FTConv_TaxStatEn                       = 7;
FIELD_IDX_T A_FTConv_NatureEn                        = 8;


FIELD_IDX_T S_FTConv_Id                              = 0;
FIELD_IDX_T S_FTConv_Code                            = 1;
FIELD_IDX_T S_FTConv_Name                            = 2;
FIELD_IDX_T S_FTConv_ClassifId                       = 3;
FIELD_IDX_T S_FTConv_NatEn                           = 4;
FIELD_IDX_T S_FTConv_TaxGeoCd                        = 5;
FIELD_IDX_T S_FTConv_TaxStatEn                       = 6;


FIELD_IDX_T A_FTRateHist_Id                          = 0;
FIELD_IDX_T A_FTRateHist_FTConvId                    = 1;
FIELD_IDX_T A_FTRateHist_BeginDate                   = 2;


FIELD_IDX_T S_FTRateHist_Id                          = 0;
FIELD_IDX_T S_FTRateHist_FTConvId                    = 1;
FIELD_IDX_T S_FTRateHist_BeginDate                   = 2;
FIELD_IDX_T S_FTRateHist_FTConvCd                    = 3;


FIELD_IDX_T A_FTRate_Id                              = 0;
FIELD_IDX_T A_FTRate_FTRateHistId                    = 1;
FIELD_IDX_T A_FTRate_Rank                            = 2;
FIELD_IDX_T A_FTRate_TaxGeoId                        = 3;
FIELD_IDX_T A_FTRate_InstrListId                     = 4;
FIELD_IDX_T A_FTRate_WithholdingTaxRate              = 5;
FIELD_IDX_T A_FTRate_ReclaimTaxRate                  = 6;
FIELD_IDX_T A_FTRate_CountableTaxRate                = 7;
FIELD_IDX_T A_FTRate_NoReclaimTaxRate                = 8;
FIELD_IDX_T A_FTRate_ShortTermCapTaxRate             = 9;
FIELD_IDX_T A_FTRate_LongTermCapTaxRate              = 10;
FIELD_IDX_T A_FTRate_LongTermPeriodUnitEn            = 11;
FIELD_IDX_T A_FTRate_LongTermPeriod                  = 12;
FIELD_IDX_T A_FTRate_TaxAccrualFlg                   = 13;
FIELD_IDX_T A_FTRate_TaxUnrealisedPLFlg              = 14;
FIELD_IDX_T A_FTRate_Rate                            = 15;
FIELD_IDX_T A_FTRate_NatureEn                        = 16;
FIELD_IDX_T A_FTRate_DiscountPercent                 = 17;              /* PMSTA-35006 - 090319 - vkumar */


FIELD_IDX_T S_FTRate_Id                              = 0;
FIELD_IDX_T S_FTRate_FTRateHistId                    = 1;
FIELD_IDX_T S_FTRate_Rank                            = 2;
FIELD_IDX_T S_FTRate_TaxGeoId                        = 3;
FIELD_IDX_T S_FTRate_InstrListId                     = 4;
FIELD_IDX_T S_FTRate_TaxGeoCd                        = 5;
FIELD_IDX_T S_FTRate_InstrListCd                     = 6;


FIELD_IDX_T HolidaysRule_StartDate                   = 0;
FIELD_IDX_T HolidaysRule_EndDate                     = 1;
FIELD_IDX_T HolidaysRule_CalendarId                  = 2;
FIELD_IDX_T HolidaysRule_ObjectId                    = 3;
FIELD_IDX_T HolidaysRule_NatureEn                    = 4;
FIELD_IDX_T HolidaysRule_GenericEn                   = 5;
FIELD_IDX_T HolidaysRule_Weekend                     = 6;
FIELD_IDX_T HolidaysRule_AddDays                     = 7;


FIELD_IDX_T CalendarOut_Date                         = 0;
FIELD_IDX_T CalendarOut_Flag                         = 1;
FIELD_IDX_T CalendarOut_Int                          = 2;


FIELD_IDX_T A_Array_Ptr                              = 0; /* PMSTA14453 - DDV - 120705 - Array definition not clean */


FIELD_IDX_T Fusion_Status_En                         = 0;
FIELD_IDX_T Fusion_Status_StockId                    = 1;
FIELD_IDX_T Fusion_Status_RequestId                  = 2;
FIELD_IDX_T Fusion_Status_PtfListId                  = 3;
FIELD_IDX_T Fusion_Status_PtfStsList                 = 4;
FIELD_IDX_T Fusion_Status_ServName                   = 5;
FIELD_IDX_T Fusion_Status_ApplSessionCd              = 6;


FIELD_IDX_T Syb_Remote_Exec_ResultFile               = 0;
FIELD_IDX_T Syb_Remote_Exec_ResultType               = 1;
FIELD_IDX_T Syb_Remote_Exec_ResultTiled              = 2;
FIELD_IDX_T Syb_Remote_Exec_ShellScript              = 3;


FIELD_IDX_T Syb_Remote_ExecCb_ThreadIdx              = 0;
FIELD_IDX_T Syb_Remote_ExecCb_ProcessId              = 1;


FIELD_IDX_T Msg_Log_ModeFlg                          = 0;
FIELD_IDX_T Msg_Log_ReportServer                     = 1;
FIELD_IDX_T Msg_Log_ReportCd                         = 2;
FIELD_IDX_T Msg_Log_ReportSts                        = 3;


FIELD_IDX_T StratInstrDura_PtfId                     = 0;
FIELD_IDX_T StratInstrDura_StratId                   = 1;
FIELD_IDX_T StratInstrDura_InstrArray                = 2;


FIELD_IDX_T Arg_Test_Amount                          = 0;
FIELD_IDX_T Arg_Test_Code                            = 1;
FIELD_IDX_T Arg_Test_Date                            = 2;
FIELD_IDX_T Arg_Test_Datetime                        = 3;
FIELD_IDX_T Arg_Test_Dict                            = 4;
FIELD_IDX_T Arg_Test_Enum                            = 5;
FIELD_IDX_T Arg_Test_Exchange                        = 6;
FIELD_IDX_T Arg_Test_Flag                            = 7;
FIELD_IDX_T Arg_Test_Id                              = 8;
FIELD_IDX_T Arg_Test_Info                            = 9;
FIELD_IDX_T Arg_Test_Int                             = 10;
FIELD_IDX_T Arg_Test_Longamount                      = 11;
FIELD_IDX_T Arg_Test_Longname                        = 12;
FIELD_IDX_T Arg_Test_Mask                            = 13;
FIELD_IDX_T Arg_Test_Method                          = 14;
FIELD_IDX_T Arg_Test_Name                            = 15;
FIELD_IDX_T Arg_Test_Note                            = 16;
FIELD_IDX_T Arg_Test_Number                          = 17;
FIELD_IDX_T Arg_Test_Percent                         = 18;
FIELD_IDX_T Arg_Test_Period                          = 19;
FIELD_IDX_T Arg_Test_Phone                           = 20;
FIELD_IDX_T Arg_Test_Shortinfo                       = 21;
FIELD_IDX_T Arg_Test_Smallint                        = 22;
FIELD_IDX_T Arg_Test_Sysname                         = 23;
FIELD_IDX_T Arg_Test_Text                            = 24;
FIELD_IDX_T Arg_Test_Time                            = 25;
FIELD_IDX_T Arg_Test_Tinyint                         = 26;
FIELD_IDX_T Arg_Test_Year                            = 27;
FIELD_IDX_T Arg_Test_UniCode                         = 28;
FIELD_IDX_T Arg_Test_UniInfo                         = 29;
FIELD_IDX_T Arg_Test_UniLongname                     = 30;
FIELD_IDX_T Arg_Test_UniName                         = 31;
FIELD_IDX_T Arg_Test_UniNote                         = 32;
FIELD_IDX_T Arg_Test_UniPhone                        = 33;
FIELD_IDX_T Arg_Test_UniShortinfo                    = 34;
FIELD_IDX_T Arg_Test_UniSysname                      = 35;
FIELD_IDX_T Arg_Test_String                          = 36;
FIELD_IDX_T Arg_Test_Id2                             = 37;     /* PMSTA-31569 - TEB - 180530 */


FIELD_IDX_T A_OpList_Id                              = 0;
FIELD_IDX_T A_OpList_Cd                              = 1;
FIELD_IDX_T A_OpList_FusionEn                        = 2;
FIELD_IDX_T A_OpList_SequenceNo                      = 3;
FIELD_IDX_T A_OpList_StatEn                          = 4;
FIELD_IDX_T A_OpList_ParOpNatEn                      = 5;
FIELD_IDX_T A_OpList_SrcCd                           = 6;
FIELD_IDX_T A_OpList_NewStatusEn                     = 7;
FIELD_IDX_T A_OpList_ErrCode                         = 8;


FIELD_IDX_T A_SetEnv_Param                           = 0;
FIELD_IDX_T A_SetEnv_Value                           = 1;

FIELD_IDX_T A_SafeShutdown_ImmediateFlg              = 0;
FIELD_IDX_T A_SafeShutdown_TimeoutSec                = 1; /* PMSTA-35209 - HLA - 190926 Safe Server Exit */
FIELD_IDX_T A_SafeShutdown_AsyncFlg                  = 2;
FIELD_IDX_T A_SafeShutdown_RestartFlg                = 3;

FIELD_IDX_T EvalEntity_CommandEn                     = 0;
FIELD_IDX_T EvalEntity_Sqlname                       = 1;
FIELD_IDX_T EvalEntity_Param                         = 2;
FIELD_IDX_T EvalEntity_ScreenDictId                  = 3;
FIELD_IDX_T EvalEntity_LanguageDictId                = 4;
FIELD_IDX_T EvalEntity_TextConverterEn               = 5; /* REF9303 - LJE - 030905 */
FIELD_IDX_T EvalEntity_UserId                        = 6; /* REF11476 - TEB - 051006 */
FIELD_IDX_T EvalEntity_FctProcName                   = 7;   /*  FIH-REF11818-060516 */
FIELD_IDX_T EvalEntity_OutputMode                    = 8; /* PMSTA05247 - LJE - 071224 */
FIELD_IDX_T EvalEntity_FilterOutputDesc              = 9; /*  PMSTA-9817-HFI-100512   */
FIELD_IDX_T EvalEntity_FormatCode                    = 10;  /*  PMSTA-10485-HFI-100830  */
FIELD_IDX_T EvalEntity_SessionId                     = 11;  /*  PMSTA-10702-HFI-101202  */
FIELD_IDX_T EvalEntity_ThirdId                       = 12;  /* OCS-39654 - LJE - 120214 */
FIELD_IDX_T EvalEntity_FunctionDictId                = 13;  /*  HFI-PMSTA-16165-130405  */
FIELD_IDX_T EvalEntity_ApplSessionCd                 = 14;  /* PMSTA-22549 - CHU - 160512 */
FIELD_IDX_T EvalEntity_MaxRecInError                 = 15;  /* PMSTA-22506 - DDV - 160526 */
FIELD_IDX_T EvalEntity_UpdateRuleEn                  = 16;  /* PMSTA-22506 - DDV - 160526 */
FIELD_IDX_T EvalEntity_ObjectOutputEn                = 17;  /*  HFI-PMSTA-30519-190806  */
FIELD_IDX_T EvalEntity_ObjectOutputDesc              = 18;  /*  HFI-PMSTA-30519-190806  */

FIELD_IDX_T EvalEntities_CommandEn                     = 0;
FIELD_IDX_T EvalEntities_Sqlname                       = 1;
FIELD_IDX_T EvalEntities_Param01                       = 2;
FIELD_IDX_T EvalEntities_Param02                       = 3;
FIELD_IDX_T EvalEntities_Param03                       = 4;
FIELD_IDX_T EvalEntities_Param04                       = 5;
FIELD_IDX_T EvalEntities_Param05                       = 6;
FIELD_IDX_T EvalEntities_Param06                       = 7;
FIELD_IDX_T EvalEntities_Param07                       = 8;
FIELD_IDX_T EvalEntities_Param08                       = 9;
FIELD_IDX_T EvalEntities_Param09                       = 0;
FIELD_IDX_T EvalEntities_Param10                       = 0;
FIELD_IDX_T EvalEntities_Param11                       = 0;
FIELD_IDX_T EvalEntities_Param12                       = 0;
FIELD_IDX_T EvalEntities_Param13                       = 0;
FIELD_IDX_T EvalEntities_Param14                       = 0;
FIELD_IDX_T EvalEntities_Param15                       = 0;
FIELD_IDX_T EvalEntities_Param16                       = 0;
FIELD_IDX_T EvalEntities_Param17                       = 0;
FIELD_IDX_T EvalEntities_Param18                       = 0;
FIELD_IDX_T EvalEntities_Param19                       = 0;
FIELD_IDX_T EvalEntities_Param20                       = 0;
FIELD_IDX_T EvalEntities_Param21                       = 0;
FIELD_IDX_T EvalEntities_Param22                       = 0;
FIELD_IDX_T EvalEntities_Param23                       = 0;
FIELD_IDX_T EvalEntities_Param24                       = 0;
FIELD_IDX_T EvalEntities_Param25                       = 0;
FIELD_IDX_T EvalEntities_Param26                       = 0;
FIELD_IDX_T EvalEntities_Param27                       = 0;
FIELD_IDX_T EvalEntities_Param28                       = 0;
FIELD_IDX_T EvalEntities_Param29                       = 0;
FIELD_IDX_T EvalEntities_Param30                       = 0;
FIELD_IDX_T EvalEntities_Param31                       = 0;
FIELD_IDX_T EvalEntities_Param32                       = 0;
FIELD_IDX_T EvalEntities_Param33                       = 0;
FIELD_IDX_T EvalEntities_Param34                       = 0;
FIELD_IDX_T EvalEntities_Param35                       = 0;
FIELD_IDX_T EvalEntities_Param36                       = 0;
FIELD_IDX_T EvalEntities_Param37                       = 0;
FIELD_IDX_T EvalEntities_Param38                       = 0;
FIELD_IDX_T EvalEntities_Param39                       = 0;
FIELD_IDX_T EvalEntities_Param40                       = 0;
FIELD_IDX_T EvalEntities_Param41                       = 0;
FIELD_IDX_T EvalEntities_Param42                       = 0;
FIELD_IDX_T EvalEntities_Param43                       = 0;
FIELD_IDX_T EvalEntities_Param44                       = 0;
FIELD_IDX_T EvalEntities_Param45                       = 0;
FIELD_IDX_T EvalEntities_Param46                       = 0;
FIELD_IDX_T EvalEntities_Param47                       = 0;
FIELD_IDX_T EvalEntities_Param48                       = 0;
FIELD_IDX_T EvalEntities_Param49                       = 0;
FIELD_IDX_T EvalEntities_Param50                       = 0;
FIELD_IDX_T EvalEntities_ScreenDictId                  = 0;
FIELD_IDX_T EvalEntities_LanguageDictId                = 0;
FIELD_IDX_T EvalEntities_TextConverterEn               = 0;
FIELD_IDX_T EvalEntities_UserId                        = 0;
FIELD_IDX_T EvalEntities_FctProcName                   = 0;
FIELD_IDX_T EvalEntities_ApplSessionCd                 = 0;


FIELD_IDX_T EvalEntityValues_ParamAttrib             = 0;
FIELD_IDX_T EvalEntityValues_DataTypeEn              = 1;
FIELD_IDX_T EvalEntityValues_Value                   = 2;
FIELD_IDX_T EvalEntityValues_ReportName              = 3;
FIELD_IDX_T EvalEntityValues_Sqlname                 = 4;
FIELD_IDX_T EvalEntityValues_Label                   = 5;
FIELD_IDX_T EvalEntityValues_SeqNb                   = 6; /* REF10342 - LJE - 040608 */


FIELD_IDX_T EvalEntityEnum_ParamAttrib               = 0;
FIELD_IDX_T EvalEntityEnum_ValueName                 = 1;
FIELD_IDX_T EvalEntityEnum_ValueEn                   = 2;
FIELD_IDX_T EvalEntityEnum_SeqNb                     = 3; /* REF10342 - LJE - 040608 */


FIELD_IDX_T EvalEntityError_ParamAttrib              = 0;
FIELD_IDX_T EvalEntityError_MessageEn                = 1;
FIELD_IDX_T EvalEntityError_MessageTxt               = 2;
FIELD_IDX_T EvalEntityError_SeqNb                    = 3; /* REF10342 - LJE - 040608 */

FIELD_IDX_T EvalEntityRights_RightsEn                = 0;   /*  FIH-REF11818-060612 */
FIELD_IDX_T EvalEntityRights_SeqNb                   = 1;   /*  FIH-REF11818-060612 */

FIELD_IDX_T IdEntity_Id                              = 0;
FIELD_IDX_T IdEntity_EntityDictId                    = 1;


FIELD_IDX_T A_UpdStratElt_DimStratDictId             = 0;
FIELD_IDX_T A_UpdStratElt_StratObjId                 = 1;
FIELD_IDX_T A_UpdStratElt_FromDate                   = 2;
FIELD_IDX_T A_UpdStratElt_OldInstrId                 = 3;
FIELD_IDX_T A_UpdStratElt_NewInstrId                 = 4;


FIELD_IDX_T Dynamic_Sql_Secu_Prof_Id                 = 0;
FIELD_IDX_T Dynamic_Sql_OutputSt                     = 1;
FIELD_IDX_T Dynamic_Sql_Cmd                          = 2;
FIELD_IDX_T Dynamic_Sql_Table                        = 3;
FIELD_IDX_T Dynamic_Sql_Valid                        = 4;
FIELD_IDX_T Dynamic_Sql_FromStr                      = 5; /* PMSTA-25761 - DDV - 170203 */
FIELD_IDX_T Dynamic_Sql_WhereStr                     = 6; /* PMSTA-25761 - DDV - 170203 */
FIELD_IDX_T Dynamic_Sql_AttributeDictId              = 7; /* PMSTA-25761 - DDV - 170203 */
FIELD_IDX_T Dynamic_Sql_AttributeSqlname             = 8; /* PMSTA-25761 - DDV - 170203 */


FIELD_IDX_T A_Execution_Id                           = 0;
FIELD_IDX_T A_Execution_ExtOrderId                   = 1;
FIELD_IDX_T A_Execution_TypeId                       = 2;
FIELD_IDX_T A_Execution_SubtypeId                    = 3;
FIELD_IDX_T A_Execution_MarketThirdId                = 4;
FIELD_IDX_T A_Execution_IntermedThirdId              = 5;
FIELD_IDX_T A_Execution_CheckStratEn                 = 6;
FIELD_IDX_T A_Execution_AccountDate                  = 7;
FIELD_IDX_T A_Execution_OperationDate                = 8;
FIELD_IDX_T A_Execution_ValueDate                    = 9;
FIELD_IDX_T A_Execution_StatusEn                     = 10;
FIELD_IDX_T A_Execution_SequenceNo                   = 11;
FIELD_IDX_T A_Execution_CashPortfolioId              = 12;
FIELD_IDX_T A_Execution_AccountId                    = 13;
FIELD_IDX_T A_Execution_Account2Id                   = 14;
FIELD_IDX_T A_Execution_Account3Id                   = 15;
FIELD_IDX_T A_Execution_DepositId                    = 16;
FIELD_IDX_T A_Execution_AccCurrencyId                = 17;
FIELD_IDX_T A_Execution_Acc2CurrencyId               = 18;
FIELD_IDX_T A_Execution_Acc3CurrencyId               = 19;
FIELD_IDX_T A_Execution_TradeCurrencyId              = 20;
FIELD_IDX_T A_Execution_CashPfCurrId                 = 21;
FIELD_IDX_T A_Execution_CounterpartyThirdId          = 22;
FIELD_IDX_T A_Execution_TermTypeId                   = 23;
FIELD_IDX_T A_Execution_AccrBpTypeId                 = 24;
FIELD_IDX_T A_Execution_AccountedFlg                 = 25;
FIELD_IDX_T A_Execution_BeginDate                    = 26;
FIELD_IDX_T A_Execution_ExecutionDate                = 27;
FIELD_IDX_T A_Execution_ExecutionSetCriteria         = 28;
FIELD_IDX_T A_Execution_NatureEn                     = 29;
FIELD_IDX_T A_Execution_Remark                       = 30;
FIELD_IDX_T A_Execution_OpExchRate                   = 31;
FIELD_IDX_T A_Execution_FiExchRate                   = 32;
FIELD_IDX_T A_Execution_SysExchRate                  = 33;
FIELD_IDX_T A_Execution_AccExchRate                  = 34;
FIELD_IDX_T A_Execution_Acc2ExchRate                 = 35;
FIELD_IDX_T A_Execution_Acc3ExchRate                 = 36;
FIELD_IDX_T A_Execution_TradeExchRate                = 37;
FIELD_IDX_T A_Execution_CashPfExchRate               = 38;
FIELD_IDX_T A_Execution_Quantity                     = 39;
FIELD_IDX_T A_Execution_Price                        = 40;
FIELD_IDX_T A_Execution_PriceCalcRuleEn              = 41;
FIELD_IDX_T A_Execution_Quote                        = 42;
FIELD_IDX_T A_Execution_Rate                         = 43;
FIELD_IDX_T A_Execution_SupplAmt                     = 44;
FIELD_IDX_T A_Execution_OpGrossAmt                   = 45;
FIELD_IDX_T A_Execution_AccrAmt                      = 46;
FIELD_IDX_T A_Execution_OpNetAmt                     = 47;
FIELD_IDX_T A_Execution_FiNetAmt                     = 48;
FIELD_IDX_T A_Execution_PfNetAmt                     = 49;
FIELD_IDX_T A_Execution_SysNetAmt                    = 50;
FIELD_IDX_T A_Execution_AccNetAmt                    = 51;
FIELD_IDX_T A_Execution_Acc2NetAmt                   = 52;
FIELD_IDX_T A_Execution_Acc3NetAmt                   = 53;
FIELD_IDX_T A_Execution_Bp1TypeId                    = 54;
FIELD_IDX_T A_Execution_Bp1CurrencyId                = 55;
FIELD_IDX_T A_Execution_Bp1Amt                       = 56;
FIELD_IDX_T A_Execution_Bp2TypeId                    = 57;
FIELD_IDX_T A_Execution_Bp2CurrencyId                = 58;
FIELD_IDX_T A_Execution_Bp2Amt                       = 59;
FIELD_IDX_T A_Execution_Bp3TypeId                    = 60;
FIELD_IDX_T A_Execution_Bp3CurrencyId                = 61;
FIELD_IDX_T A_Execution_Bp3Amt                       = 62;
FIELD_IDX_T A_Execution_Bp4TypeId                    = 63;
FIELD_IDX_T A_Execution_Bp4CurrencyId                = 64;
FIELD_IDX_T A_Execution_Bp4Amt                       = 65;
FIELD_IDX_T A_Execution_Bp5TypeId                    = 66;
FIELD_IDX_T A_Execution_Bp5CurrencyId                = 67;
FIELD_IDX_T A_Execution_Bp5Amt                       = 68;
FIELD_IDX_T A_Execution_Bp6TypeId                    = 69;
FIELD_IDX_T A_Execution_Bp6CurrencyId                = 70;
FIELD_IDX_T A_Execution_Bp6Amt                       = 71;
FIELD_IDX_T A_Execution_Bp7TypeId                    = 72;
FIELD_IDX_T A_Execution_Bp7CurrencyId                = 73;
FIELD_IDX_T A_Execution_Bp7Amt                       = 74;
FIELD_IDX_T A_Execution_Bp8TypeId                    = 75;
FIELD_IDX_T A_Execution_Bp8CurrencyId                = 76;
FIELD_IDX_T A_Execution_Bp8Amt                       = 77;
FIELD_IDX_T A_Execution_Bp9TypeId                    = 78;
FIELD_IDX_T A_Execution_Bp9CurrencyId                = 79;
FIELD_IDX_T A_Execution_Bp9Amt                       = 80;
FIELD_IDX_T A_Execution_Bp10TypeId                   = 81;
FIELD_IDX_T A_Execution_Bp10CurrencyId               = 82;
FIELD_IDX_T A_Execution_Bp10Amt                      = 83;
FIELD_IDX_T A_Execution_LastUserId				     = 84; /*REF11249-BRO-060524*/
FIELD_IDX_T A_Execution_LastModifDate                = 85; /*REF11249-BRO-060524*/
FIELD_IDX_T A_Execution_PtfId                        = 86;
FIELD_IDX_T A_Execution_InstrId                      = 87;
FIELD_IDX_T A_Execution_NoPositionFlg                = 88; /*PMSTA07201-BRO-090206*/
FIELD_IDX_T A_Execution_OpCurrencyId                 = 89;
FIELD_IDX_T A_Execution_BoPtfId                      = 90; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T A_Execution_BoAccountId                  = 91; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T A_Execution_SetOfFeesId					 = 92; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_Execution_SetOfProductFeesId			 = 93; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_Execution_BoRoutingBusEntityId		 = 94; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T	A_Execution_SetOfOtherFeesId             = 95; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	A_Execution_TraderThirdId                = 96; /* WEALTH-5053 - CHANDRU - 07022024 */


FIELD_IDX_T S_Execution_Id                           = 0;
FIELD_IDX_T S_Execution_ExtOrderId                   = 1;
FIELD_IDX_T S_Execution_SequenceNo                   = 2;
FIELD_IDX_T S_Execution_ExecutionSetCriteria         = 3;
FIELD_IDX_T S_Execution_StatusEn                     = 4;
FIELD_IDX_T S_Execution_AccountedFlg                 = 5;
FIELD_IDX_T S_Execution_NatureEn                     = 6;


FIELD_IDX_T A_GlExecFee_Id                           = 0;
FIELD_IDX_T A_GlExecFee_ExtOrderId                   = 1;
FIELD_IDX_T A_GlExecFee_TypeId                       = 2;
FIELD_IDX_T A_GlExecFee_SubtypeId                    = 3;
FIELD_IDX_T A_GlExecFee_AccountDate                  = 4;
FIELD_IDX_T A_GlExecFee_OperationDate                = 5;
FIELD_IDX_T A_GlExecFee_ValueDate                    = 6;
FIELD_IDX_T A_GlExecFee_StatusEn                     = 7;
FIELD_IDX_T A_GlExecFee_CashPortfolioId              = 8;
FIELD_IDX_T A_GlExecFee_BpTypeId                     = 9;
FIELD_IDX_T A_GlExecFee_AccountId                    = 10;
FIELD_IDX_T A_GlExecFee_Account2Id                   = 11;
FIELD_IDX_T A_GlExecFee_Account3Id                   = 12;
FIELD_IDX_T A_GlExecFee_AccCurrencyId                = 13;
FIELD_IDX_T A_GlExecFee_Acc2CurrencyId               = 14;
FIELD_IDX_T A_GlExecFee_Acc3CurrencyId               = 15;
FIELD_IDX_T A_GlExecFee_TradeCurrencyId              = 16;
FIELD_IDX_T A_GlExecFee_CashPfCurrId                 = 17;
FIELD_IDX_T A_GlExecFee_AccountedFlg                 = 18;
FIELD_IDX_T A_GlExecFee_BeginDate                    = 19;
FIELD_IDX_T A_GlExecFee_ExecutionSetCriteria         = 20;
FIELD_IDX_T A_GlExecFee_Remark                       = 21;
FIELD_IDX_T A_GlExecFee_OpExchRate                   = 22;
FIELD_IDX_T A_GlExecFee_SysExchRate                  = 23;
FIELD_IDX_T A_GlExecFee_AccExchRate                  = 24;
FIELD_IDX_T A_GlExecFee_Acc2ExchRate                 = 25;
FIELD_IDX_T A_GlExecFee_Acc3ExchRate                 = 26;
FIELD_IDX_T A_GlExecFee_TradeExchRate                = 27;
FIELD_IDX_T A_GlExecFee_CashPfExchRate               = 28;
FIELD_IDX_T A_GlExecFee_OpNetAmt                     = 29;
FIELD_IDX_T A_GlExecFee_PfNetAmt                     = 30;
FIELD_IDX_T A_GlExecFee_SysNetAmt                    = 31;
FIELD_IDX_T A_GlExecFee_AccNetAmt                    = 32;
FIELD_IDX_T A_GlExecFee_Acc2NetAmt                   = 33;
FIELD_IDX_T A_GlExecFee_Acc3NetAmt                   = 34;
FIELD_IDX_T A_GlExecFee_Bp1TypeId                    = 35;
FIELD_IDX_T A_GlExecFee_Bp1CurrencyId                = 36;
FIELD_IDX_T A_GlExecFee_Bp1Amt                       = 37;
FIELD_IDX_T A_GlExecFee_Bp2TypeId                    = 38;
FIELD_IDX_T A_GlExecFee_Bp2CurrencyId                = 39;
FIELD_IDX_T A_GlExecFee_Bp2Amt                       = 40;
FIELD_IDX_T A_GlExecFee_Bp3TypeId                    = 41;
FIELD_IDX_T A_GlExecFee_Bp3CurrencyId                = 42;
FIELD_IDX_T A_GlExecFee_Bp3Amt                       = 43;
FIELD_IDX_T A_GlExecFee_Bp4TypeId                    = 44;
FIELD_IDX_T A_GlExecFee_Bp4CurrencyId                = 45;
FIELD_IDX_T A_GlExecFee_Bp4Amt                       = 46;
FIELD_IDX_T A_GlExecFee_Bp5TypeId                    = 47;
FIELD_IDX_T A_GlExecFee_Bp5CurrencyId                = 48;
FIELD_IDX_T A_GlExecFee_Bp5Amt                       = 49;
FIELD_IDX_T A_GlExecFee_Bp6TypeId                    = 50;
FIELD_IDX_T A_GlExecFee_Bp6CurrencyId                = 51;
FIELD_IDX_T A_GlExecFee_Bp6Amt                       = 52;
FIELD_IDX_T A_GlExecFee_Bp7TypeId                    = 53;
FIELD_IDX_T A_GlExecFee_Bp7CurrencyId                = 54;
FIELD_IDX_T A_GlExecFee_Bp7Amt                       = 55;
FIELD_IDX_T A_GlExecFee_Bp8TypeId                    = 56;
FIELD_IDX_T A_GlExecFee_Bp8CurrencyId                = 57;
FIELD_IDX_T A_GlExecFee_Bp8Amt                       = 58;
FIELD_IDX_T A_GlExecFee_Bp9TypeId                    = 59;
FIELD_IDX_T A_GlExecFee_Bp9CurrencyId                = 60;
FIELD_IDX_T A_GlExecFee_Bp9Amt                       = 61;
FIELD_IDX_T A_GlExecFee_Bp10TypeId                   = 62;
FIELD_IDX_T A_GlExecFee_Bp10CurrencyId               = 63;
FIELD_IDX_T A_GlExecFee_Bp10Amt                      = 64;
FIELD_IDX_T A_GlExecFee_LastUserId				     = 65; /*REF11249-BRO-060524*/
FIELD_IDX_T A_GlExecFee_LastModifDate                = 66; /*REF11249-BRO-060524*/
FIELD_IDX_T A_GlExecFee_PtfId                        = 67;
FIELD_IDX_T A_GlExecFee_InstrId                      = 68;
FIELD_IDX_T A_GlExecFee_OpCurrencyId                 = 69;



FIELD_IDX_T S_GlExecFee_Id                           = 0;
FIELD_IDX_T S_GlExecFee_ExtOrderId                   = 1;
FIELD_IDX_T S_GlExecFee_ExecutionSetCriteria         = 2;
FIELD_IDX_T S_GlExecFee_StatusEn                     = 3;
FIELD_IDX_T S_GlExecFee_AccountedFlg                 = 4;


FIELD_IDX_T A_ExtExecution_Id                        = 0;
FIELD_IDX_T A_ExtExecution_ExtOrderId                = 1;
FIELD_IDX_T A_ExtExecution_ExecutionId               = 2;
FIELD_IDX_T A_ExtExecution_GlobalExecutionFeeId      = 3;
FIELD_IDX_T A_ExtExecution_TypeId                    = 4;
FIELD_IDX_T A_ExtExecution_SubtypeId                 = 5;
FIELD_IDX_T A_ExtExecution_MarketThirdId             = 6;
FIELD_IDX_T A_ExtExecution_IntermedThirdId           = 7;
FIELD_IDX_T A_ExtExecution_CheckStratEn              = 8;
FIELD_IDX_T A_ExtExecution_AccountDate               = 9;
FIELD_IDX_T A_ExtExecution_OperationDate             = 10;
FIELD_IDX_T A_ExtExecution_ValueDate                 = 11;
FIELD_IDX_T A_ExtExecution_StatusEn                  = 12;
FIELD_IDX_T A_ExtExecution_SequenceNo                = 13;
FIELD_IDX_T A_ExtExecution_CashPortfolioId           = 14;
FIELD_IDX_T A_ExtExecution_BpTypeId                  = 15;
FIELD_IDX_T A_ExtExecution_AccountId                 = 16;
FIELD_IDX_T A_ExtExecution_Account2Id                = 17;
FIELD_IDX_T A_ExtExecution_Account3Id                = 18;
FIELD_IDX_T A_ExtExecution_DepositId                 = 19;
FIELD_IDX_T A_ExtExecution_AccCurrencyId             = 20;
FIELD_IDX_T A_ExtExecution_Acc2CurrencyId            = 21;
FIELD_IDX_T A_ExtExecution_Acc3CurrencyId            = 22;
FIELD_IDX_T A_ExtExecution_TradeCurrencyId           = 23;
FIELD_IDX_T A_ExtExecution_CashPfCurrId              = 24;
FIELD_IDX_T A_ExtExecution_CounterpartyThirdId       = 25;
FIELD_IDX_T A_ExtExecution_TermTypeId                = 26;
FIELD_IDX_T A_ExtExecution_AccrBpTypeId              = 27;
FIELD_IDX_T A_ExtExecution_AccountedFlg              = 28;
FIELD_IDX_T A_ExtExecution_BeginDate                 = 29;
FIELD_IDX_T A_ExtExecution_ExecutionDate             = 30;
FIELD_IDX_T A_ExtExecution_ExecutionSetCriteria      = 31;
FIELD_IDX_T A_ExtExecution_NatureEn                  = 32;
FIELD_IDX_T A_ExtExecution_ExecutionNatureEn         = 33;
FIELD_IDX_T A_ExtExecution_Remark                    = 34;
FIELD_IDX_T A_ExtExecution_OpExchRate                = 35;
FIELD_IDX_T A_ExtExecution_FiExchRate                = 36;
FIELD_IDX_T A_ExtExecution_SysExchRate               = 37;
FIELD_IDX_T A_ExtExecution_AccExchRate               = 38;
FIELD_IDX_T A_ExtExecution_Acc2ExchRate              = 39;
FIELD_IDX_T A_ExtExecution_Acc3ExchRate              = 40;
FIELD_IDX_T A_ExtExecution_TradeExchRate             = 41;
FIELD_IDX_T A_ExtExecution_CashPfExchRate            = 42;
FIELD_IDX_T A_ExtExecution_Quantity                  = 43;
FIELD_IDX_T A_ExtExecution_Price                     = 44;
FIELD_IDX_T A_ExtExecution_PriceCalcRuleEn           = 45;
FIELD_IDX_T A_ExtExecution_Quote                     = 46;
FIELD_IDX_T A_ExtExecution_Rate                      = 47;
FIELD_IDX_T A_ExtExecution_SupplAmt                  = 48;
FIELD_IDX_T A_ExtExecution_OpGrossAmt                = 49;
FIELD_IDX_T A_ExtExecution_AccrAmt                   = 50;
FIELD_IDX_T A_ExtExecution_OpNetAmt                  = 51;
FIELD_IDX_T A_ExtExecution_FiNetAmt                  = 52;
FIELD_IDX_T A_ExtExecution_PfNetAmt                  = 53;
FIELD_IDX_T A_ExtExecution_SysNetAmt                 = 54;
FIELD_IDX_T A_ExtExecution_AccNetAmt                 = 55;
FIELD_IDX_T A_ExtExecution_Acc2NetAmt                = 56;
FIELD_IDX_T A_ExtExecution_Acc3NetAmt                = 57;
FIELD_IDX_T A_ExtExecution_Bp1TypeId                 = 58;
FIELD_IDX_T A_ExtExecution_Bp1CurrencyId             = 59;
FIELD_IDX_T A_ExtExecution_Bp1Amt                    = 60;
FIELD_IDX_T A_ExtExecution_Bp2TypeId                 = 61;
FIELD_IDX_T A_ExtExecution_Bp2CurrencyId             = 62;
FIELD_IDX_T A_ExtExecution_Bp2Amt                    = 63;
FIELD_IDX_T A_ExtExecution_Bp3TypeId                 = 64;
FIELD_IDX_T A_ExtExecution_Bp3CurrencyId             = 65;
FIELD_IDX_T A_ExtExecution_Bp3Amt                    = 66;
FIELD_IDX_T A_ExtExecution_Bp4TypeId                 = 67;
FIELD_IDX_T A_ExtExecution_Bp4CurrencyId             = 68;
FIELD_IDX_T A_ExtExecution_Bp4Amt                    = 69;
FIELD_IDX_T A_ExtExecution_Bp5TypeId                 = 70;
FIELD_IDX_T A_ExtExecution_Bp5CurrencyId             = 71;
FIELD_IDX_T A_ExtExecution_Bp5Amt                    = 72;
FIELD_IDX_T A_ExtExecution_Bp6TypeId                 = 73;
FIELD_IDX_T A_ExtExecution_Bp6CurrencyId             = 74;
FIELD_IDX_T A_ExtExecution_Bp6Amt                    = 75;
FIELD_IDX_T A_ExtExecution_Bp7TypeId                 = 76;
FIELD_IDX_T A_ExtExecution_Bp7CurrencyId             = 77;
FIELD_IDX_T A_ExtExecution_Bp7Amt                    = 78;
FIELD_IDX_T A_ExtExecution_Bp8TypeId                 = 79;
FIELD_IDX_T A_ExtExecution_Bp8CurrencyId             = 80;
FIELD_IDX_T A_ExtExecution_Bp8Amt                    = 81;
FIELD_IDX_T A_ExtExecution_Bp9TypeId                 = 82;
FIELD_IDX_T A_ExtExecution_Bp9CurrencyId             = 83;
FIELD_IDX_T A_ExtExecution_Bp9Amt                    = 84;
FIELD_IDX_T A_ExtExecution_Bp10TypeId                = 85;
FIELD_IDX_T A_ExtExecution_Bp10CurrencyId            = 86;
FIELD_IDX_T A_ExtExecution_Bp10Amt                   = 87;
FIELD_IDX_T A_ExtExecution_LastUserId	    	     = 88; /*REF11249-BRO-060524*/
FIELD_IDX_T A_ExtExecution_LastModifDate             = 89; /*REF11249-BRO-060524*/
FIELD_IDX_T A_ExtExecution_PtfId                     = 90;
FIELD_IDX_T A_ExtExecution_InstrId                   = 91;
FIELD_IDX_T A_ExtExecution_NoPositionFlg             = 92; /*PMSTA07201-BRO-090206*/
FIELD_IDX_T A_ExtExecution_OpCurrencyId              = 93;
FIELD_IDX_T A_ExtExecution_SelectedFlg               = 95;  /*  FIH-REF11457-051014 */
FIELD_IDX_T A_ExtExecution_ExtOrder_Ext              = 96;
FIELD_IDX_T A_ExtExecution_BoPtfId                   = 97; /* PMSTA-38454 - srinivas   - 06022020 */
FIELD_IDX_T A_ExtExecution_BoAccountId               = 98; /* PMSTA-38454 - srinivas   - 06022020 */


/* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
#if 0
FIELD_IDX_T A_LightOrder_Id                          = 0;
FIELD_IDX_T A_LightOrder_NatureEn                    = 1;
FIELD_IDX_T A_LightOrder_FunctionResultId            = 2;
FIELD_IDX_T A_LightOrder_Cd                          = 3;
FIELD_IDX_T A_LightOrder_InputUserId                 = 4;
FIELD_IDX_T A_LightOrder_TypeId                      = 5;
FIELD_IDX_T A_LightOrder_SubtypeId                   = 6;
FIELD_IDX_T A_LightOrder_MarketThirdId               = 7;
FIELD_IDX_T A_LightOrder_IntermedThirdId             = 8;
FIELD_IDX_T A_LightOrder_ManagerId                   = 9;
FIELD_IDX_T A_LightOrder_SourceCd                    = 10;
FIELD_IDX_T A_LightOrder_LimitQuote                  = 11;
FIELD_IDX_T A_LightOrder_LimitPrice                  = 12;
FIELD_IDX_T A_LightOrder_StopQuote                   = 13;
FIELD_IDX_T A_LightOrder_StopPrice                   = 14;
FIELD_IDX_T A_LightOrder_OrderPriceNatEn             = 15;
FIELD_IDX_T A_LightOrder_OrderValidityNatEn          = 16;
FIELD_IDX_T A_LightOrder_MinOrderQty                 = 17;
FIELD_IDX_T A_LightOrder_ParentOperationCd           = 18;
FIELD_IDX_T A_LightOrder_ParentOperNatEn             = 19;
FIELD_IDX_T A_LightOrder_CheckParentEn               = 20;
FIELD_IDX_T A_LightOrder_CheckStratEn                = 21;
FIELD_IDX_T A_LightOrder_OrderNatEn                  = 22;
FIELD_IDX_T A_LightOrder_OperationDate               = 23;
FIELD_IDX_T A_LightOrder_ValuationDate               = 24;
FIELD_IDX_T A_LightOrder_OrderLimitDate              = 25;
FIELD_IDX_T A_LightOrder_ValueDate                   = 26;
FIELD_IDX_T A_LightOrder_RefOperCd                   = 27;
FIELD_IDX_T A_LightOrder_RefNatEn                    = 28;
FIELD_IDX_T A_LightOrder_StatusEn                    = 29;
FIELD_IDX_T A_LightOrder_SequenceNo                  = 30;
FIELD_IDX_T A_LightOrder_PortfolioId                 = 31;
FIELD_IDX_T A_LightOrder_InstrId                     = 32;
FIELD_IDX_T A_LightOrder_DepositId                   = 33;
FIELD_IDX_T A_LightOrder_OpCurrencyId                = 34;
FIELD_IDX_T A_LightOrder_CounterpartyThirdId         = 35;
FIELD_IDX_T A_LightOrder_ExpirationDate              = 36;
FIELD_IDX_T A_LightOrder_Remark                      = 37;
FIELD_IDX_T A_LightOrder_Quantity                    = 38;
FIELD_IDX_T A_LightOrder_Rate                        = 39;
FIELD_IDX_T A_LightOrder_AudUsername                 = 40;
FIELD_IDX_T A_LightOrder_AudModifDate                = 41;
FIELD_IDX_T A_LightOrder_AudAction                   = 42;
FIELD_IDX_T A_LightOrder_LastUserId                  = 43;
FIELD_IDX_T A_LightOrder_LastModifDate               = 44;
FIELD_IDX_T A_LightOrder_CreationTimeDate            = 45;
FIELD_IDX_T A_LightOrder_AccountId                   = 46;
FIELD_IDX_T A_LightOrder_TradeCurrencyId             = 47; /*REF9446-BRO-030930*/


FIELD_IDX_T S_LightOrder_Id                          = 0;
FIELD_IDX_T S_LightOrder_Cd                          = 1;
#endif


FIELD_IDX_T GetFile_I_Name                           = 0;
FIELD_IDX_T GetFile_I_Text                           = 1;
FIELD_IDX_T GetFile_I_Size                           = 2;
FIELD_IDX_T GetFile_I_ApplSessionCd                  = 3; /* PMSTA-33865 - JBC - 190306 */

FIELD_IDX_T GetFile_O_Size                           = 0;
FIELD_IDX_T GetFile_O_Data                           = 1;

/* REF9764 - CHU - 031222 */
FIELD_IDX_T A_UnMatchedExecution_Id                           = 0;
FIELD_IDX_T A_UnMatchedExecution_ExtOrderId                   = 1;
FIELD_IDX_T A_UnMatchedExecution_ExecutionId                  = 2;      /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedExecution_GlobalExecFeeId              = 3;      /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedExecution_TypeId                       = 4;
FIELD_IDX_T A_UnMatchedExecution_SubtypeId                    = 5;
FIELD_IDX_T A_UnMatchedExecution_MarketThirdId                = 6;
FIELD_IDX_T A_UnMatchedExecution_IntermedThirdId              = 7;
FIELD_IDX_T A_UnMatchedExecution_CheckStratEn                 = 8;
FIELD_IDX_T A_UnMatchedExecution_AccountDate                  = 9;
FIELD_IDX_T A_UnMatchedExecution_OperationDate                = 10;
FIELD_IDX_T A_UnMatchedExecution_ValueDate                    = 11;
FIELD_IDX_T A_UnMatchedExecution_StatusEn                     = 12;
FIELD_IDX_T A_UnMatchedExecution_SequenceNo                   = 13;
FIELD_IDX_T A_UnMatchedExecution_CashPortfolioId              = 14;
FIELD_IDX_T A_UnMatchedExecution_BpTypeId                     = 15;     /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedExecution_AccountId                    = 16;
FIELD_IDX_T A_UnMatchedExecution_Account2Id                   = 17;
FIELD_IDX_T A_UnMatchedExecution_Account3Id                   = 18;
FIELD_IDX_T A_UnMatchedExecution_DepositId                    = 19;
FIELD_IDX_T A_UnMatchedExecution_AccCurrencyId                = 20;
FIELD_IDX_T A_UnMatchedExecution_Acc2CurrencyId               = 21;
FIELD_IDX_T A_UnMatchedExecution_Acc3CurrencyId               = 22;
FIELD_IDX_T A_UnMatchedExecution_TradeCurrencyId              = 23;
FIELD_IDX_T A_UnMatchedExecution_CashPfCurrId                 = 24;
FIELD_IDX_T A_UnMatchedExecution_CounterpartyThirdId          = 25;
FIELD_IDX_T A_UnMatchedExecution_TermTypeId                   = 26;
FIELD_IDX_T A_UnMatchedExecution_AccrBpTypeId                 = 27;
FIELD_IDX_T A_UnMatchedExecution_AccountedFlg                 = 28;
FIELD_IDX_T A_UnMatchedExecution_BeginDate                    = 29;
FIELD_IDX_T A_UnMatchedExecution_ExecutionDate                = 30;
FIELD_IDX_T A_UnMatchedExecution_ExecutionSetCriteria         = 31;
FIELD_IDX_T A_UnMatchedExecution_NatureEn                     = 32;
FIELD_IDX_T A_UnMatchedExecution_ExecNatureEn                 = 33;     /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedExecution_Remark                       = 34;
FIELD_IDX_T A_UnMatchedExecution_OpExchRate                   = 35;
FIELD_IDX_T A_UnMatchedExecution_FiExchRate                   = 36;
FIELD_IDX_T A_UnMatchedExecution_SysExchRate                  = 37;
FIELD_IDX_T A_UnMatchedExecution_AccExchRate                  = 38;
FIELD_IDX_T A_UnMatchedExecution_Acc2ExchRate                 = 39;
FIELD_IDX_T A_UnMatchedExecution_Acc3ExchRate                 = 40;
FIELD_IDX_T A_UnMatchedExecution_TradeExchRate                = 41;
FIELD_IDX_T A_UnMatchedExecution_CashPfExchRate               = 42;
FIELD_IDX_T A_UnMatchedExecution_Quantity                     = 43;
FIELD_IDX_T A_UnMatchedExecution_Price                        = 44;
FIELD_IDX_T A_UnMatchedExecution_PriceCalcRuleEn              = 45;
FIELD_IDX_T A_UnMatchedExecution_Quote                        = 46;
FIELD_IDX_T A_UnMatchedExecution_Rate                         = 47;
FIELD_IDX_T A_UnMatchedExecution_SupplAmt                     = 48;
FIELD_IDX_T A_UnMatchedExecution_OpGrossAmt                   = 49;
FIELD_IDX_T A_UnMatchedExecution_AccrAmt                      = 50;
FIELD_IDX_T A_UnMatchedExecution_OpNetAmt                     = 51;
FIELD_IDX_T A_UnMatchedExecution_FiNetAmt                     = 52;
FIELD_IDX_T A_UnMatchedExecution_PfNetAmt                     = 53;
FIELD_IDX_T A_UnMatchedExecution_SysNetAmt                    = 54;
FIELD_IDX_T A_UnMatchedExecution_AccNetAmt                    = 55;
FIELD_IDX_T A_UnMatchedExecution_Acc2NetAmt                   = 56;
FIELD_IDX_T A_UnMatchedExecution_Acc3NetAmt                   = 57;
FIELD_IDX_T A_UnMatchedExecution_Bp1TypeId                    = 58;
FIELD_IDX_T A_UnMatchedExecution_Bp1CurrencyId                = 59;
FIELD_IDX_T A_UnMatchedExecution_Bp1Amt                       = 60;
FIELD_IDX_T A_UnMatchedExecution_Bp2TypeId                    = 61;
FIELD_IDX_T A_UnMatchedExecution_Bp2CurrencyId                = 62;
FIELD_IDX_T A_UnMatchedExecution_Bp2Amt                       = 63;
FIELD_IDX_T A_UnMatchedExecution_Bp3TypeId                    = 64;
FIELD_IDX_T A_UnMatchedExecution_Bp3CurrencyId                = 65;
FIELD_IDX_T A_UnMatchedExecution_Bp3Amt                       = 66;
FIELD_IDX_T A_UnMatchedExecution_Bp4TypeId                    = 67;
FIELD_IDX_T A_UnMatchedExecution_Bp4CurrencyId                = 68;
FIELD_IDX_T A_UnMatchedExecution_Bp4Amt                       = 69;
FIELD_IDX_T A_UnMatchedExecution_Bp5TypeId                    = 70;
FIELD_IDX_T A_UnMatchedExecution_Bp5CurrencyId                = 71;
FIELD_IDX_T A_UnMatchedExecution_Bp5Amt                       = 72;
FIELD_IDX_T A_UnMatchedExecution_Bp6TypeId                    = 73;
FIELD_IDX_T A_UnMatchedExecution_Bp6CurrencyId                = 74;
FIELD_IDX_T A_UnMatchedExecution_Bp6Amt                       = 75;
FIELD_IDX_T A_UnMatchedExecution_Bp7TypeId                    = 76;
FIELD_IDX_T A_UnMatchedExecution_Bp7CurrencyId                = 77;
FIELD_IDX_T A_UnMatchedExecution_Bp7Amt                       = 78;
FIELD_IDX_T A_UnMatchedExecution_Bp8TypeId                    = 79;
FIELD_IDX_T A_UnMatchedExecution_Bp8CurrencyId                = 80;
FIELD_IDX_T A_UnMatchedExecution_Bp8Amt                       = 81;
FIELD_IDX_T A_UnMatchedExecution_Bp9TypeId                    = 82;
FIELD_IDX_T A_UnMatchedExecution_Bp9CurrencyId                = 83;
FIELD_IDX_T A_UnMatchedExecution_Bp9Amt                       = 84;
FIELD_IDX_T A_UnMatchedExecution_Bp10TypeId                   = 85;
FIELD_IDX_T A_UnMatchedExecution_Bp10CurrencyId               = 86;
FIELD_IDX_T A_UnMatchedExecution_Bp10Amt                      = 87;
FIELD_IDX_T A_UnMatchedExecution_PtfId                        = 88;
FIELD_IDX_T A_UnMatchedExecution_InstrId                      = 89;
FIELD_IDX_T A_UnMatchedExecution_FailedImportEn               = 90;
FIELD_IDX_T A_UnMatchedExecution_ImportModeEn                 = 91;
FIELD_IDX_T A_UnMatchedExecution_ExtOrderCd                   = 92;
FIELD_IDX_T A_UnMatchedExecution_OpCurrencyId                 = 93;
FIELD_IDX_T A_UnMatchedExecution_ConfirmFlg                   = 94;
FIELD_IDX_T A_UnMatchedExecution_A_Ptf_Ext                    = 95;
FIELD_IDX_T A_UnMatchedExecution_A_Instr_Ext                  = 96;
FIELD_IDX_T A_UnMatchedExecution_EditBackupPtr                = 97;     /*  FIH-REF9764-040211  */
FIELD_IDX_T A_UnMatchedExecution_TraderThirdId                = 98;


/* REF9764 - CHU - 031222 */
FIELD_IDX_T S_UnMatchedExecution_Id                           = 0;
FIELD_IDX_T S_UnMatchedExecution_ExtOrderId                   = 1;
FIELD_IDX_T S_UnMatchedExecution_SequenceNo                   = 2;
FIELD_IDX_T S_UnMatchedExecution_ExecutionSetCriteria         = 3;
FIELD_IDX_T S_UnMatchedExecution_StatusEn                     = 4;
FIELD_IDX_T S_UnMatchedExecution_AccountedFlg                 = 5;
FIELD_IDX_T S_UnMatchedExecution_NatureEn                     = 6;
FIELD_IDX_T S_UnMatchedExecution_FailedImportEn               = 7;
FIELD_IDX_T S_UnMatchedExecution_ImportModeEn                 = 8;
FIELD_IDX_T S_UnMatchedExecution_ExtOrderCd                   = 9;
FIELD_IDX_T S_UnMatchedExecution_ConfirmFlg                   = 10;

/*REF10234-PRO-040430*/
FIELD_IDX_T A_UnMatchedGlExecFee_Id                           = 0;
FIELD_IDX_T A_UnMatchedGlExecFee_ExtOrderId                   = 1;
FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionId                  = 2;      /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedGlExecFee_GlobalExecFeeId              = 3;      /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedGlExecFee_TypeId                       = 4;
FIELD_IDX_T A_UnMatchedGlExecFee_SubtypeId                    = 5;
FIELD_IDX_T A_UnMatchedGlExecFee_MarketThirdId                = 6;
FIELD_IDX_T A_UnMatchedGlExecFee_IntermedThirdId              = 7;
FIELD_IDX_T A_UnMatchedGlExecFee_CheckStratEn                 = 8;
FIELD_IDX_T A_UnMatchedGlExecFee_AccountDate                  = 9;
FIELD_IDX_T A_UnMatchedGlExecFee_OperationDate                = 10;
FIELD_IDX_T A_UnMatchedGlExecFee_ValueDate                    = 11;
FIELD_IDX_T A_UnMatchedGlExecFee_StatusEn                     = 12;
FIELD_IDX_T A_UnMatchedGlExecFee_SequenceNo                   = 13;
FIELD_IDX_T A_UnMatchedGlExecFee_CashPortfolioId              = 14;
FIELD_IDX_T A_UnMatchedGlExecFee_BpTypeId                     = 15;     /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedGlExecFee_AccountId                    = 16;
FIELD_IDX_T A_UnMatchedGlExecFee_Account2Id                   = 17;
FIELD_IDX_T A_UnMatchedGlExecFee_Account3Id                   = 18;
FIELD_IDX_T A_UnMatchedGlExecFee_DepositId                    = 19;
FIELD_IDX_T A_UnMatchedGlExecFee_AccCurrencyId                = 20;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc2CurrencyId               = 21;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc3CurrencyId               = 22;
FIELD_IDX_T A_UnMatchedGlExecFee_TradeCurrencyId              = 23;
FIELD_IDX_T A_UnMatchedGlExecFee_CashPfCurrId                 = 24;
FIELD_IDX_T A_UnMatchedGlExecFee_CounterpartyThirdId          = 25;
FIELD_IDX_T A_UnMatchedGlExecFee_TermTypeId                   = 26;
FIELD_IDX_T A_UnMatchedGlExecFee_AccrBpTypeId                 = 27;
FIELD_IDX_T A_UnMatchedGlExecFee_AccountedFlg                 = 28;
FIELD_IDX_T A_UnMatchedGlExecFee_BeginDate                    = 29;
FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionDate                = 30;
FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionSetCriteria         = 31;
FIELD_IDX_T A_UnMatchedGlExecFee_NatureEn                     = 32;
FIELD_IDX_T A_UnMatchedGlExecFee_ExecNatureEn                 = 33;     /*  FIH-REF9764-031229  */
FIELD_IDX_T A_UnMatchedGlExecFee_Remark                       = 34;
FIELD_IDX_T A_UnMatchedGlExecFee_OpExchRate                   = 35;
FIELD_IDX_T A_UnMatchedGlExecFee_FiExchRate                   = 36;
FIELD_IDX_T A_UnMatchedGlExecFee_SysExchRate                  = 37;
FIELD_IDX_T A_UnMatchedGlExecFee_AccExchRate                  = 38;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc2ExchRate                 = 39;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc3ExchRate                 = 40;
FIELD_IDX_T A_UnMatchedGlExecFee_TradeExchRate                = 41;
FIELD_IDX_T A_UnMatchedGlExecFee_CashPfExchRate               = 42;
FIELD_IDX_T A_UnMatchedGlExecFee_Quantity                     = 43;
FIELD_IDX_T A_UnMatchedGlExecFee_Price                        = 44;
FIELD_IDX_T A_UnMatchedGlExecFee_PriceCalcRuleEn              = 45;
FIELD_IDX_T A_UnMatchedGlExecFee_Quote                        = 46;
FIELD_IDX_T A_UnMatchedGlExecFee_Rate                         = 47;
FIELD_IDX_T A_UnMatchedGlExecFee_SupplAmt                     = 48;
FIELD_IDX_T A_UnMatchedGlExecFee_OpGrossAmt                   = 49;
FIELD_IDX_T A_UnMatchedGlExecFee_AccrAmt                      = 50;
FIELD_IDX_T A_UnMatchedGlExecFee_OpNetAmt                     = 51;
FIELD_IDX_T A_UnMatchedGlExecFee_FiNetAmt                     = 52;
FIELD_IDX_T A_UnMatchedGlExecFee_PfNetAmt                     = 53;
FIELD_IDX_T A_UnMatchedGlExecFee_SysNetAmt                    = 54;
FIELD_IDX_T A_UnMatchedGlExecFee_AccNetAmt                    = 55;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc2NetAmt                   = 56;
FIELD_IDX_T A_UnMatchedGlExecFee_Acc3NetAmt                   = 57;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp1TypeId                    = 58;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp1CurrencyId                = 59;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp1Amt                       = 60;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp2TypeId                    = 61;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp2CurrencyId                = 62;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp2Amt                       = 63;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp3TypeId                    = 64;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp3CurrencyId                = 65;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp3Amt                       = 66;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp4TypeId                    = 67;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp4CurrencyId                = 68;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp4Amt                       = 69;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp5TypeId                    = 70;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp5CurrencyId                = 71;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp5Amt                       = 72;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp6TypeId                    = 73;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp6CurrencyId                = 74;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp6Amt                       = 75;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp7TypeId                    = 76;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp7CurrencyId                = 77;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp7Amt                       = 78;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp8TypeId                    = 79;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp8CurrencyId                = 80;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp8Amt                       = 81;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp9TypeId                    = 82;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp9CurrencyId                = 83;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp9Amt                       = 84;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp10TypeId                   = 85;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp10CurrencyId               = 86;
FIELD_IDX_T A_UnMatchedGlExecFee_Bp10Amt                      = 87;
FIELD_IDX_T A_UnMatchedGlExecFee_PtfId                        = 88;
FIELD_IDX_T A_UnMatchedGlExecFee_InstrId                      = 89;
FIELD_IDX_T A_UnMatchedGlExecFee_FailedImportEn               = 90;
FIELD_IDX_T A_UnMatchedGlExecFee_ImportModeEn                 = 91;
FIELD_IDX_T A_UnMatchedGlExecFee_ExtOrderCd                   = 92;
FIELD_IDX_T A_UnMatchedGlExecFee_OpCurrencyId                 = 93;
FIELD_IDX_T A_UnMatchedGlExecFee_ConfirmFlg                   = 94;
FIELD_IDX_T A_UnMatchedGlExecFee_SetOfFeesId				  = 95;
FIELD_IDX_T A_UnMatchedGlExecFee_SetOfProductFeesId			  = 97;
FIELD_IDX_T A_UnMatchedGlExecFee_BoRoutingBusEntityId		  = 98; 

FIELD_IDX_T A_UnMatchedGlExecFee_A_Ptf_Ext                    = 99;
FIELD_IDX_T A_UnMatchedGlExecFee_A_Instr_Ext                  = 100;
FIELD_IDX_T A_UnMatchedGlExecFee_EditBackupPtr                = 101;     /*  FIH-REF9764-040211  */


/* BSA - PMSTA01179 - 061219 */
FIELD_IDX_T A_OpenedPosition_PtfId                            = 1;
FIELD_IDX_T A_OpenedPosition_InstrId                          = 2;
FIELD_IDX_T A_OpenedPosition_StatEn                           = 3;
FIELD_IDX_T A_OpenedPosition_PtfPosSetId                      = 4;
FIELD_IDX_T A_OpenedPosition_OpPosId                          = 5;

/* REF9764 - LJE - 040106 */
FIELD_IDX_T A_ExtTransaction_Id                               = 0;
FIELD_IDX_T A_ExtTransaction_SrcEntityDictId                  = 1;
FIELD_IDX_T A_ExtTransaction_SrcObjectId                      = 2;
FIELD_IDX_T A_ExtTransaction_ParentExtTransId                 = 3;
FIELD_IDX_T A_ExtTransaction_MatchedFlg                       = 4;
FIELD_IDX_T A_ExtTransaction_A_Ptf_Ext                        = 5;
FIELD_IDX_T A_ExtTransaction_A_Instr_Ext                      = 6;
FIELD_IDX_T A_ExtTransaction_Child_Ext                        = 7;
FIELD_IDX_T A_ExtTransaction_Parent_Ext                       = 8;
FIELD_IDX_T A_ExtTransaction_Clone_Ext                        = 9;
FIELD_IDX_T A_ExtTransaction_EditBackupPtr                    = 10;
FIELD_IDX_T	A_ExtTransaction_OriginalQty					  = 11;		/* PMSTA-37908 - adarshn - 191119 */
FIELD_IDX_T	A_ExtTransaction_OrderNettingEn					  = 12;		/* PMSTA-37908 - adarshn - 191119 */
FIELD_IDX_T	A_ExtTransaction_NettingCriteria                  = 13;     /* PMSTA-37908 - adarshn - 24012020 */
FIELD_IDX_T A_ExtTransaction_BoPtfId                          = 14; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T A_ExtTransaction_BoAccountId                      = 15; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_OpSplitRuleEn                    = 16; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_AdjBoPtfId                       = 17; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_CoaExDate                        = 18; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_BoCashAcctId                     = 19; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_BoCashPtfId                      = 20; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T	A_ExtTransaction_SplitParentOperId                = 21; /* PMSTA-38454 - srinivas   - 17022020 */
FIELD_IDX_T A_ExtTransaction_RuleApplicabilityEn			  = 22; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_SmartRoundingQty				  = 23; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_SmartRoundingOrgQty			  = 24; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_RoundingOrgQty					  = 25; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_SmartRoundingFlg				  = 26; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_SmartRoundingRuleId			  = 27; /* PMSTA-40493-badhri-08252020: smart rounding rule */
FIELD_IDX_T A_ExtTransaction_HierOperNatEn                    = 28;	/* PMSTA-40208 - adarshn	- 02092020 */
FIELD_IDX_T A_ExtTransaction_HierOperationCd                  = 29;	/* PMSTA-40208 - adarshn	- 02092020 */
FIELD_IDX_T A_ExtTransaction_ParentHierExtOpId                = 30; /* PMSTA-40208 - adarshn	- 02092020 */
FIELD_IDX_T A_ExtTransaction_CashPlanId                       = 31; /* PMSTA-42402 - Vishnu  16112020   */
FIELD_IDX_T	A_ExtTransaction_NotionalInstrId                  = 32;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	A_ExtTransaction_InvestLimitEn                    = 33;	/*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
FIELD_IDX_T	A_ExtTransaction_AdjRefNatEn                      = 34; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T A_ExtTransaction_AdjRefOperCd                     = 35; /* PMSTA-49729 - Deepthi - 220711 */
FIELD_IDX_T A_ExtTransaction_SetOfFeesId					  = 36; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_ExtTransaction_SetOfProductFeesId				  = 37; /* PMSTA-51324 - Lekshmi - 221128 */
FIELD_IDX_T A_ExtTransaction_BoRoutingBusEntityId			  = 38; /* PMSTA-52619 - Sathees - 230327 */
FIELD_IDX_T	A_ExtTransaction_SetOfOtherFeesId                 = 39; /* WEALTH-5030 - CHANDRU - 05022024 */
FIELD_IDX_T	A_ExtTransaction_TraderThirdId                    = 40; /* WEALTH-5053 - CHANDRU - 07022024 */
FIELD_IDX_T	A_ExtTransaction_NetSettleAmount                  = 41; 
FIELD_IDX_T A_ExtTransaction_PremiumCurrencyId			      = 42; /* WEALTH-8559 - Senthil - 20240607 */
FIELD_IDX_T A_ExtTransaction_PremiumAmount			          = 43; /* WEALTH-8559 - Senthil - 20240607 */


FIELD_IDX_T A_ExtTransaction_ExtOrderId                       = 102;
FIELD_IDX_T A_ExtTransaction_ImportMode                       = 0;
FIELD_IDX_T A_ExtTransaction_AccountedFlg                     = 32;     /*  FIH-REF10615-041015 */
FIELD_IDX_T A_ExtTransaction_SequenceNo                       = 17;
FIELD_IDX_T A_ExtTransaction_ConfirmedFlg                     = 0;
FIELD_IDX_T A_ExtTransaction_ExecNatureEn                     = 0;      /*  FIH-REF10234-040607 */
FIELD_IDX_T A_ExtTransaction_SelectedFlg                      = 0;      /*  FIH-REF11457-051014 */
FIELD_IDX_T A_ExtTransaction_InSessionFlg                     = 0;      /*  PMSTA9052-EFE-091126 */
FIELD_IDX_T A_ExtTransaction_DraftOrderId                     = 0;		/*  PMSTA09160-CHU-100106 */

/* REF11767 - CHU - 060411 */
FIELD_IDX_T OptiPurge_ProcCd                                  = 0;
FIELD_IDX_T OptiPurge_Entity                                  = 1;

/* REF11767 - CHU - 060504 */
FIELD_IDX_T OptiCheckIn_ProcCd                                = 0;
FIELD_IDX_T OptiCheckIn_Entity                                = 1;
FIELD_IDX_T OptiCheckIn_DetailEn                              = 2;

/* REF11767 - CHU - 060504 */
FIELD_IDX_T OptiCheckOut_SrvName                              = 0;
FIELD_IDX_T OptiCheckOut_ProcName                             = 1;
FIELD_IDX_T OptiCheckOut_EntityName                           = 2;
FIELD_IDX_T OptiCheckOut_AllocBloc                            = 3;
FIELD_IDX_T OptiCheckOut_MaxAllocBloc                         = 4;
FIELD_IDX_T OptiCheckOut_RequestNb                            = 5;
FIELD_IDX_T OptiCheckOut_FreeRequestNb                        = 6;
FIELD_IDX_T OptiCheckOut_PercentUsed                          = 7;
FIELD_IDX_T OptiCheckOut_PercentFree                          = 8;
FIELD_IDX_T OptiCheckOut_TotalReads                           = 9;
FIELD_IDX_T OptiCheckOut_ReadHits                             = 10;
FIELD_IDX_T OptiCheckOut_PercentReadHits                      = 11;
FIELD_IDX_T OptiCheckOut_ReadMisses                           = 12;
FIELD_IDX_T OptiCheckOut_PercentReadMisses                    = 13;
FIELD_IDX_T OptiCheckOut_CacheFull                            = 14;
FIELD_IDX_T OptiCheckOut_PurgeNumber                          = 15;
FIELD_IDX_T OptiCheckOut_LastPurgeDate                        = 16;
FIELD_IDX_T OptiCheckOut_UsedMemory                           = 17;

/*  FPL-REF11314-060516 */
FIELD_IDX_T SecuCheck_FctCreate                                 = 0 ;   /*  create right depending of fct secu prof */
FIELD_IDX_T SecuCheck_FctUpdate                                 = 1 ;   /*  update right depending of fct secu prof */
FIELD_IDX_T SecuCheck_FctDelete                                 = 2 ;   /*  delete right depending of fct secu prof */
FIELD_IDX_T SecuCheck_DataUpdate                                = 3 ;   /*  update right depending of data ptf      */
FIELD_IDX_T SecuCheck_DataDelete                                = 4 ;   /*  delete right depending of data ptf      */
FIELD_IDX_T SecuCheck_Gui                                       = 5 ;   /*  Gui hard coded right                    */
FIELD_IDX_T SecuCheck_Script                                    = 6 ;   /*  Right from script                       */

/* PMSTA11809 - PRS - 110428 */
/* entity comment */
FIELD_IDX_T A_EntityComment_Id                                = 0;
FIELD_IDX_T A_EntityComment_EntDictId                         = 1;
FIELD_IDX_T A_EntityComment_LangDictId                        = 2;
FIELD_IDX_T A_EntityComment_StatusEn                          = 3;
FIELD_IDX_T A_EntityComment_DraftComment                      = 4;
FIELD_IDX_T A_EntityComment_DraftUserId                       = 5;
FIELD_IDX_T A_EntityComment_DraftDate                         = 6;
FIELD_IDX_T A_EntityComment_Comment                           = 7;
FIELD_IDX_T A_EntityComment_UserId                            = 8;
FIELD_IDX_T A_EntityComment_CommentDate                       = 9;
FIELD_IDX_T A_EntityComment_Timestamp                         = 10;
FIELD_IDX_T A_EntityComment_NbAttributeToComment              = 11;
FIELD_IDX_T A_EntityComment_NbAttributeToReview               = 12;
FIELD_IDX_T A_EntityComment_NbAttributeToFinalReview          = 13;
FIELD_IDX_T A_EntityComment_NbPermValToComment                = 14;
FIELD_IDX_T A_EntityComment_NbPermValToReview                 = 15;
FIELD_IDX_T A_EntityComment_NbPermValToFinalReview            = 16;


FIELD_IDX_T S_EntityComment_Id                                = 0;
FIELD_IDX_T S_EntityComment_EntDictId                         = 1;
FIELD_IDX_T S_EntityComment_LangDictId                        = 2;
FIELD_IDX_T S_EntityComment_StatusEn                          = 3;
FIELD_IDX_T S_EntityComment_EntityName                        = 4;
FIELD_IDX_T S_EntityComment_LanguageName                      = 5;
FIELD_IDX_T S_EntityComment_NbAttributeToComment              = 6;
FIELD_IDX_T S_EntityComment_NbAttributeToReview               = 7;
FIELD_IDX_T S_EntityComment_NbAttributeToFinalReview          = 8;
FIELD_IDX_T S_EntityComment_NbPermValToComment                = 9;
FIELD_IDX_T S_EntityComment_NbPermValToReview                 = 10;
FIELD_IDX_T S_EntityComment_NbPermValToFinalReview            = 11;


/* attribute comment */
FIELD_IDX_T A_AttributeComment_Id                             = 0;
FIELD_IDX_T A_AttributeComment_AttrDictId                     = 1;
FIELD_IDX_T A_AttributeComment_LangDictId                     = 2;
FIELD_IDX_T A_AttributeComment_StatusEn                       = 3;
FIELD_IDX_T A_AttributeComment_DraftComment                   = 4;
FIELD_IDX_T A_AttributeComment_DraftUserId                    = 5;
FIELD_IDX_T A_AttributeComment_DraftDate                      = 6;
FIELD_IDX_T A_AttributeComment_Comment                        = 7;
FIELD_IDX_T A_AttributeComment_UserId                         = 8;
FIELD_IDX_T A_AttributeComment_CommentDate                    = 9;
FIELD_IDX_T A_AttributeComment_Timestamp                      = 10;
FIELD_IDX_T A_AttributeComment_EntityCommentId                = 11;
FIELD_IDX_T A_AttributeComment_NbPermValToComment             = 12;
FIELD_IDX_T A_AttributeComment_NbPermValToReview              = 13;
FIELD_IDX_T A_AttributeComment_NbPermValToFinalReview         = 14;

FIELD_IDX_T S_AttributeComment_Id                             = 0;
FIELD_IDX_T S_AttributeComment_AttrDictId                     = 1;
FIELD_IDX_T S_AttributeComment_LangDictId                     = 2;
FIELD_IDX_T S_AttributeComment_StatusEn                       = 3;
FIELD_IDX_T S_AttributeComment_EntityCommentId                = 4;
FIELD_IDX_T S_AttributeComment_AttributeName                  = 5;
FIELD_IDX_T S_AttributeComment_LanguageName                   = 6;
FIELD_IDX_T S_AttributeComment_NbPermValToComment             = 7;
FIELD_IDX_T S_AttributeComment_NbPermValToReview              = 8;
FIELD_IDX_T S_AttributeComment_NbPermValToFinalReview         = 9;

/* perm value comment */
FIELD_IDX_T A_PermValComment_Id                               =  0;
FIELD_IDX_T A_PermValComment_AttrDictId                       =  1;
FIELD_IDX_T A_PermValComment_AttributeCommentId               =  2;
FIELD_IDX_T A_PermValComment_NatEn                            =  3;
FIELD_IDX_T A_PermValComment_LangDictId                       =  4;
FIELD_IDX_T A_PermValComment_StatusEn                         =  5;
FIELD_IDX_T A_PermValComment_DraftComment                     =  6;
FIELD_IDX_T A_PermValComment_DraftUserId                      =  7;
FIELD_IDX_T A_PermValComment_DraftDate                        =  8;
FIELD_IDX_T A_PermValComment_Comment                          =  9;
FIELD_IDX_T A_PermValComment_UserId                           = 10;
FIELD_IDX_T A_PermValComment_CommentDate                      = 11;
FIELD_IDX_T A_PermValComment_Timestamp                        = 12;

FIELD_IDX_T S_PermValComment_Id                               = 0;
FIELD_IDX_T S_PermValComment_AttrDictId                       = 1;
FIELD_IDX_T S_PermValComment_AttributeCommentId               = 2;
FIELD_IDX_T S_PermValComment_StatusEn                         = 3;
FIELD_IDX_T S_PermValComment_NatEn                            = 4;
FIELD_IDX_T S_PermValComment_LangDictId                       = 5;
FIELD_IDX_T S_PermValComment_AttributeName                    = 6;
FIELD_IDX_T S_PermValComment_LanguageName                     = 7;
FIELD_IDX_T S_PermValComment_NatEnLabel                       = 8;

/* appl param comment */
FIELD_IDX_T A_ApplParamComment_Id                             = 0;
FIELD_IDX_T A_ApplParamComment_ParamName                      = 1;
FIELD_IDX_T A_ApplParamComment_LangDictId                     = 2;
FIELD_IDX_T A_ApplParamComment_StatusEn                       = 3;
FIELD_IDX_T A_ApplParamComment_DraftComment                   = 4;
FIELD_IDX_T A_ApplParamComment_DraftUserId                    = 5;
FIELD_IDX_T A_ApplParamComment_DraftDate                      = 6;
FIELD_IDX_T A_ApplParamComment_Comment                        = 7;
FIELD_IDX_T A_ApplParamComment_UserId                         = 8;
FIELD_IDX_T A_ApplParamComment_CommentDate                    = 9;
FIELD_IDX_T A_ApplParamComment_Timestamp                      = 10;

FIELD_IDX_T S_ApplParamComment_Id                             = 0;
FIELD_IDX_T S_ApplParamComment_ParamName                      = 1;
FIELD_IDX_T S_ApplParamComment_LangDictId                     = 2;
FIELD_IDX_T S_ApplParamComment_StatusEn                       = 3;
FIELD_IDX_T S_ApplParamComment_LanguageName                   = 4;

/* PMSTA13167 - DDV - 111215 - Add new structure for session management */
FIELD_IDX_T SessionMgt_FromId                                 = 0;
FIELD_IDX_T SessionMgt_FromCd                                 = 1;
FIELD_IDX_T SessionMgt_LangDictId                             = 2;
FIELD_IDX_T SessionMgt_UserId                                 = 3;
FIELD_IDX_T SessionMgt_Mode                                   = 4;
FIELD_IDX_T SessionMgt_OldOption                              = 5;
FIELD_IDX_T SessionMgt_KeepCommFlg                            = 6;
FIELD_IDX_T SessionMgt_BuySellFlg                             = 7;
FIELD_IDX_T SessionMgt_ExternalPosFlg                         = 8;
FIELD_IDX_T SessionMgt_CopyEntityList                         = 9;
FIELD_IDX_T SessionMgt_MergeCdList                            = 10;
FIELD_IDX_T SessionMgt_ApplSessionCd                          = 11; /* PMSTA-22549 - CHU - 160512 */
FIELD_IDX_T SessionMgt_OrderIdList							  = 12; /* PMSTA-39396 - Silpakal - 200320 */

/* PMSTA15008-JPP-20120920 */
FIELD_IDX_T A_PurgeEntity_Sqlname                       = 0; /* PMSTA15008-JPP-20120920 */
FIELD_IDX_T A_PurgeEntity_Filter                        = 1; /* PMSTA15008-JPP-20120920 */

/* PMSTA21215 - PCL */
FIELD_IDX_T A_StartFusionByCd_DimPortSqlName         = 0;
FIELD_IDX_T A_StartFusionByCd_PortObjectCd           = 1;
FIELD_IDX_T A_StartFusionByCd_BeginDate              = 2;
FIELD_IDX_T A_StartFusionByCd_FusionScopeFlg         = 3;
FIELD_IDX_T A_StartFusionByCd_SynchronousFlg         = 4;
FIELD_IDX_T A_StartFusionByCd_DimPortDictId          = 5;
FIELD_IDX_T A_StartFusionByCd_PortObjectId           = 6;
FIELD_IDX_T A_StartFusionByCd_EndDate                = 7;
FIELD_IDX_T A_StartFusionByCd_AutomaticFlg           = 8;
FIELD_IDX_T A_StartFusionByCd_PortfolioSizeEn        = 9;
FIELD_IDX_T A_StartFusionByCd_DispatchServer         = 10;
FIELD_IDX_T A_StartFusionByCd_SyncTimeOut            = 11;
FIELD_IDX_T A_StartFusionByCd_ServerId               = 12;
FIELD_IDX_T A_StartFusionByCd_ApplSessionCd          = 13;


/* PMSTA-21105 - cashwini - 150831 */
FIELD_IDX_T A_DomainPtfCompo_Id                       = 0;
FIELD_IDX_T A_DomainPtfCompo_FunctionResultId         = 1;
FIELD_IDX_T A_DomainPtfCompo_PtfId                    = 2;
FIELD_IDX_T A_DomainPtfCompo_ThirdId                  = 3;
FIELD_IDX_T A_DomainPtfCompo_PtfThirdCompoId          = 4;
FIELD_IDX_T A_DomainPtfCompo_DefaultStratId           = 5;
FIELD_IDX_T A_DomainPtfCompo_ForcedStratId            = 6;
FIELD_IDX_T A_DomainPtfCompo_ThirdCompo               = 7;
FIELD_IDX_T A_DomainPtfCompo_OnlyUsedForOrder         = 8;

FIELD_IDX_T S_DomainPtfCompo_Id                       = 0;
FIELD_IDX_T S_DomainPtfCompo_FunctionResultId         = 1;
FIELD_IDX_T S_DomainPtfCompo_FunctionResultCd         = 2;
FIELD_IDX_T S_DomainPtfCompo_PtfId                    = 3;
FIELD_IDX_T S_DomainPtfCompo_PtfCd                    = 4;

/*< PMSTA-22551 - EFE - 20160323 */

FIELD_IDX_T  A_ApplChannelProf_Id                        =  0;
FIELD_IDX_T  A_ApplChannelProf_Cd                        =  1;
FIELD_IDX_T  A_ApplChannelProf_MaxSession		         =  2;

FIELD_IDX_T  S_ApplChannelProf_Id						 =  0;
FIELD_IDX_T  S_ApplChannelProf_Cd						 =  1;

FIELD_IDX_T  A_ApplChannelProfCompo_Id                   = 0;
FIELD_IDX_T  A_ApplChannelProfCompo_ApplChannelProfId    = 1;
FIELD_IDX_T  A_ApplChannelProfCompo_ApplChanId           = 2;
FIELD_IDX_T  A_ApplChannelProfCompo_FuncSecuProfId       = 3;
FIELD_IDX_T  A_ApplChannelProfCompo_ReportProfId         = 4;
FIELD_IDX_T  A_ApplChannelProfCompo_ScreenProfId         = 5;
FIELD_IDX_T  A_ApplChannelProfCompo_SearchProfId         = 6;
FIELD_IDX_T  A_ApplChannelProfCompo_MaxSession           = 7;
FIELD_IDX_T  A_ApplChannelProfCompo_SessionTimeoutSec    = 8;

FIELD_IDX_T  S_ApplChannelProfCompo_Id                   = 0;
FIELD_IDX_T  S_ApplChannelProfCompo_ApplChannelProfId    = 1;
FIELD_IDX_T  S_ApplChannelProfCompo_ApplChanId           = 2;
FIELD_IDX_T  S_ApplChannelProfCompo_ApplChannelProfCd    = 3;
FIELD_IDX_T  S_ApplChannelProfCompo_ApplChanCd           = 4;

/*> PMSTA-22551 - EFE - 20160323 */

/* < PMSTA-22458 - cashwini - 160502 */
FIELD_IDX_T A_ComplianceChronoFreq_Id                = 0;
FIELD_IDX_T A_ComplianceChronoFreq_PtfId             = 1;
FIELD_IDX_T A_ComplianceChronoFreq_StratId           = 2;
FIELD_IDX_T A_ComplianceChronoFreq_ValidDate         = 3;
FIELD_IDX_T A_ComplianceChronoFreq_ThirdPartyId      = 4;
FIELD_IDX_T A_ComplianceChronoFreq_SubNatTypeId      = 5;
FIELD_IDX_T A_ComplianceChronoFreq_FreqDate          = 6;
FIELD_IDX_T A_ComplianceChronoFreq_CompNatEn         = 7;
FIELD_IDX_T A_ComplianceChronoFreq_NatEn             = 8;
FIELD_IDX_T A_ComplianceChronoFreq_Val               = 9;
FIELD_IDX_T A_ComplianceChronoFreq_CurrId            = 10;
FIELD_IDX_T A_ComplianceChronoFreq_Comment           = 11;
FIELD_IDX_T A_ComplianceChronoFreq_Min               = 12;
FIELD_IDX_T A_ComplianceChronoFreq_Max               = 13;
FIELD_IDX_T A_ComplianceChronoFreq_CriticalnessEn    = 14;
FIELD_IDX_T A_ComplianceChronoFreq_ConfidenceLevel   = 15;
FIELD_IDX_T A_ComplianceChronoFreq_TimeHorizon       = 16;
FIELD_IDX_T A_ComplianceChronoFreq_TimeHorizonUnitEn = 17;
FIELD_IDX_T A_ComplianceChronoFreq_A_Compl_Ext       = 18;
/* PMSTA-22458 - cashwini - 160502 > */

/* PMSTA-28335 - MSR - 171006 */
FIELD_IDX_T AccRuleCompoArg_PortfolioId = 0;
FIELD_IDX_T AccRuleCompoArg_InstrumentId = 1;
FIELD_IDX_T AccRuleCompoArg_Date = 2;
/* PMSTA-28335 - MSR - 171006 */


/* PMSTA-29130 - 200818 - vkumar */
FIELD_IDX_T ArgAccRuleCompo_PortfolioId = 0;
FIELD_IDX_T ArgAccRuleCompo_Date = 1;
/* PMSTA-29130 - 200818 - vkumar */

/* PMSTA-32230 - MSR - 130818 */
FIELD_IDX_T Arg_ApplUserPrefName_ParamName = 0;
/* PMSTA-32230 - MSR - 130818 */

/* PMSTA-34198 - 040419 - SGO */
FIELD_IDX_T Arg_TopN_FetchRows           = 0;
FIELD_IDX_T Arg_TopN_ThreadRank          = 1;
FIELD_IDX_T Arg_TopN_MaxRank             = 2;
FIELD_IDX_T Arg_TopN_EventId             = 3;
FIELD_IDX_T Arg_TopN_ServerId            = 4;
FIELD_IDX_T Arg_TopN_Enum1               = 5;
FIELD_IDX_T Arg_TopN_Enum2               = 6;
FIELD_IDX_T Arg_TopN_Flag1               = 7;
FIELD_IDX_T Arg_TopN_BusEntityId         = 8;



/* PMSTA-37138 - 11092019 - sanand */
FIELD_IDX_T Arg_WS_PortfolioId = 0;
FIELD_IDX_T Arg_WS_InstrId = 1;
FIELD_IDX_T Arg_WS_OpDate = 2;
FIELD_IDX_T Arg_WS_IdenticalInstrId = 3;
FIELD_IDX_T Arg_WS_Relation = 4;

FIELD_IDX_T Arg_WS_Op_Src = 0;

/* PMSTA XXXX LIK 30012020*/
FIELD_IDX_T Arg_OverlayInitFetch_PtfId = 0;
FIELD_IDX_T Arg_OverlayInitFetch_Date = 1;

FIELD_IDX_T Arg_OverlayNextFetch_StratId = 0;
FIELD_IDX_T Arg_OverlayNextFetch_PtfId = 1;
FIELD_IDX_T Arg_OverlayNextFetch_Date = 2;
FIELD_IDX_T Arg_OverlayNextFetch_IpFlag = 3;

FIELD_IDX_T Arg_StratOvelayFetch_StratId = 0;
FIELD_IDX_T Arg_StratOvelayFetch_Date = 1;

FIELD_IDX_T Arg_PtfOvelayFetch_PtfId = 0;
FIELD_IDX_T Arg_PtfOvelayFetch_StratId = 1;
FIELD_IDX_T Arg_PtfOvelayFetch_Date = 2;

/* PMSTA-40209 - LIK - 25082020 */
FIELD_IDX_T StandInstructFilterArg_AllFlag = 0;
FIELD_IDX_T StandInstructFilterArg_BuyFlag = 1;
FIELD_IDX_T StandInstructFilterArg_SellFlag = 2;
FIELD_IDX_T StandInstructFilterArg_InvestFlag = 3;
FIELD_IDX_T StandInstructFilterArg_WithdrawFlag = 4;
FIELD_IDX_T StandInstructFilterArg_CalcRefDate = 5;


/* PMSTA-34344 - LJE - 200916 */
FIELD_IDX_T SqlRequest_ProcSqlName       = 0;
FIELD_IDX_T SqlRequest_SqlCmd            = 1;
FIELD_IDX_T SqlRequest_ReadOnly          = 2;
FIELD_IDX_T SqlRequest_Parameters        = 3;
FIELD_IDX_T SqlRequest_ResultSet         = 4;
FIELD_IDX_T SqlRequest_ApplSessionCd     = 5;

FIELD_IDX_T CallRequest_ActionEn         = 0;
FIELD_IDX_T CallRequest_EntitySqlName    = 1;
FIELD_IDX_T CallRequest_ObjectEn         = 2;
FIELD_IDX_T CallRequest_Role             = 3;
FIELD_IDX_T CallRequest_InputData        = 4;
FIELD_IDX_T CallRequest_AutocreateItems  = 5;

FIELD_IDX_T AutoCreateItem_MainObject       = 0;
FIELD_IDX_T AutoCreateItem_MainFKeyFldIndex = 1;
FIELD_IDX_T AutoCreateItem_OldMainFKeyId    = 2;
FIELD_IDX_T AutoCreateItem_RefObject        = 3;
FIELD_IDX_T AutoCreateItem_RefRec           = 4;
FIELD_IDX_T AutoCreateItem_RefFKeyFldIndex  = 5;
FIELD_IDX_T AutoCreateItem_RefId            = 6;
FIELD_IDX_T AutoCreateItem_Action           = 7;
FIELD_IDX_T AutoCreateItem_insertFlg        = 8;

FIELD_IDX_T SqlRequestParam_SqlName      = 0;
FIELD_IDX_T SqlRequestParam_DataType     = 1;
FIELD_IDX_T SqlRequestParam_Value        = 2; 
FIELD_IDX_T SqlRequestParam_InputFlg     = 3;
FIELD_IDX_T SqlRequestParam_OutputFlg    = 4;

FIELD_IDX_T SqlRequestResultSet_DynSt    = 0;
FIELD_IDX_T SqlRequestResultSet_Items    = 1;

FIELD_IDX_T SqlRequestOutputDef_SqlName  = 0;
FIELD_IDX_T SqlRequestOutputDef_DataType = 1;

FIELD_IDX_T SqlRequestMsg_ErrorNo = 0;
FIELD_IDX_T SqlRequestMsg_Message = 1;

FIELD_IDX_T TemenosPckHeader_Id         = 0;
FIELD_IDX_T TemenosPckHeader_DsfApiType = 1;
FIELD_IDX_T TemenosPckHeader_MetaData   = 2;

FIELD_IDX_T ProcessingContext_Cmd           = 0;
FIELD_IDX_T ProcessingContext_EntitProfile  = 1;
FIELD_IDX_T ProcessingContext_BusEntityCd   = 2;
FIELD_IDX_T ProcessingContext_Config        = 3;
FIELD_IDX_T ProcessingContext_LockFields    = 4;

FIELD_IDX_T Out_Amount_Amount            = 0;  /* PMSTA-49587 - AIS - 220926 */

FIELD_IDX_T O_PackageDefinition_Code                      = 0;
FIELD_IDX_T O_PackageDefinition_Version                   = 1;
FIELD_IDX_T O_PackageDefinition_Name                      = 2;
FIELD_IDX_T O_PackageDefinition_Denomination              = 3;
FIELD_IDX_T O_PackageDefinition_Nature                    = 4;
FIELD_IDX_T O_PackageDefinition_Status                    = 5;
FIELD_IDX_T O_PackageDefinition_ParentPackageCode         = 6;
FIELD_IDX_T O_PackageDefinition_ParentPackageVersion      = 7;
FIELD_IDX_T O_PackageDefinition_RequiredCoreVersion       = 8;
FIELD_IDX_T O_PackageDefinition_PackageDefinition         = 9;
FIELD_IDX_T O_PackageDefinition_PackageComposition        = 10;

/* WEALTH-6158 - JBC - 20240330 */
FIELD_IDX_T InceptDtArg_DimEntityDictId = 0;             
FIELD_IDX_T InceptDtArg_DimPtfDictId    = 1;
FIELD_IDX_T InceptDtArg_PtfObjId        = 2;
FIELD_IDX_T InceptDtArg_LoadHierFlg     = 3;
FIELD_IDX_T InceptDtArg_PtfListDef      = 4;


/* 031008 - PMO */
/*lint -restore */

#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DATADEP_C

/************************************************************************
**      Include files
*************************************************************************/
#define MATH_H
#define STRING_H
#include "unidef.h"             /* Mandatory */

#include "date.h"
#include "gen.h"
#include "os.h"
#include "serv.h"
#include "syslib.h"
#include "dbiconnection.h"
#include "datadep.h"
#include "clusterconfig.h"
#include "conv.h"

extern void SERV_WaitForRpcRegistered();
extern ServerClientConfig EV_CurrentSrvConfig;


/************************************************************************
**      Static definitions & data
*************************************************************************/

static Atomic<ThreadState>  SV_ThreadDataDepLoop     (ThreadState::Initialization);     /* Flag if the data dependency thread must loop */
static Atomic<ThreadState>  SV_ThreadSessionPurgeLoop(ThreadState::Initialization);     /* Flag if the session purge   thread must loop */
static Lock                 SV_ThreadDataDepLock;
static Lock                 SV_ThreadSessionPurgeLock;

ID_T                        SV_ServerId = ZERO_ID;


static Atomic<TID_T>        SV_ThreadDataDepTID(0);
static Atomic<TID_T>        SV_ThreadSessionPurgeTID(0);

std::string                 serverInfo("None");

#define BE_EVENT_MAP_T std::map<std::string, EVENT_SET_T *>
#define EVENT_SET_T std::set<NEW_EVENT_STP>

struct NEW_EVENT {
    DBA_DYNFLD_STP  recordStp;
    OBJECT_ENUM     objectEn;
    DBA_ACTION_ENUM action;
};

typedef struct NEW_EVENT   NEW_EVENT_ST;
typedef struct NEW_EVENT * NEW_EVENT_STP;

/* PMSTA-26569 - DDV - 171212 - New class used to describe data dependency definition */
class DataDepDefinition
{
public:
    DataDepDefinition(DBA_DYNFLD_STP, SCPT_ARG_STP);
    DBA_DYNFLD_STP           getDataDepRec(void);
    SCPT_ARG_STP             getFiltertScriptTree(void);
    bool                     bInsertInMaster(void);
    bool                     bInsertInAllBE(void);
    bool                     bUpdateObjOnBE(void);

private:
    DBA_DYNFLD_STP            m_Record;                  /* data dependency record (A_DataDependency) */
    SCPT_ARG_STP              m_FilterScriptTree;        /* script tree of the data dependency's filter */
    bool                      m_InsertInMasterFlg;       /* boolean used to know if event can be created in Master (depend of the multi_entity_category_e of impacted table) */
    bool                      m_InsertInAllBEFlg;        /* boolean used to know if event can be created in BEs (depend of the multi_entity_category_e of impacted table) */
    bool                      m_UpdateObjOnBEFlg;        /* boolean used to know updated object can belong to a BE (depend of the multi_entity_category_e of updated table) */
};

class DataDepEntity;

/* PMSTA-26569 - DDV - 171212 - New class used to organise data dependency by entity. */
class DataDep
{
public :

	 static DataDep& getInstance()
	 {
		 static DataDep instance;
		 return instance;
	 }

	 DataDep():m_dataDepArray(nullptr), m_dataDepNbr(0), m_filterTreeTab(nullptr) {};

	 DataDep(DataDep const&) = delete;
	 void operator=(DataDep const&) = delete;

	 std::set <DataDepDefinition *> getDefinitionSet(DICT_T, OBJMODIFSTAT_ACTION_ENUM action);

	 void load(DBA_HIER_HEAD_STP, DbiConnectionHelper&);
	 void clear(void);

private:
    DBA_DYNFLD_STP       *m_dataDepArray;                     /* data dependency array */
    int                   m_dataDepNbr;                       /* data dependency array */
    SCPT_ARG_STP         *m_filterTreeTab;                    /* filter's script tree array */

    std::set <DataDepDefinition *>	    m_AllDataDepDef;      /* Set of all DataDepDefinition. It is only use to free them */
	std::map<DICT_T, DataDepEntity *>	m_DataDepEntityMap;   /* map by entity of corresponding data dependency */

};

/* PMSTA-26569 - DDV - 171212 - New class used to organise data dependency for one entity by action. */
class DataDepEntity
{
public :

	 DataDepEntity(){};

	 DataDepEntity(DataDepEntity const&) = delete;
	 void operator=(DataDepEntity const&) = delete;

	 std::set<DataDepDefinition *> getDefinitionSet(OBJMODIFSTAT_ACTION_ENUM);

	 void insert(OBJMODIFSTAT_ACTION_ENUM, DataDepDefinition *);
	 void clear(void);

private:
    std::set <DataDepDefinition *>	m_InsertSet; /* set of data dependency to use when action is Insert */
    std::set <DataDepDefinition *>	m_UpdateSet; /* set of data dependency to use when action is Update */
    std::set <DataDepDefinition *>	m_DeleteSet; /* set of data dependency to use when action is Delete */
};

/************************************************************************
**      Prototypes
*************************************************************************/
STATIC RET_CODE SERV_LoadActiveDataDependency(DBA_DYNFLD_STP **, int *, DbiConnectionHelper &);
STATIC RET_CODE SERV_LoadDataDependencyFilter(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *, int, DbiConnectionHelper &, SCPT_ARG_STP **);
STATIC int SERV_CmpDataDependencyRank(const void *, const void *);

STATIC RET_CODE SERV_LoadObjectModifStat( DBA_DYNFLD_STP **, int *, const int, DbiConnectionHelper&, const bool);
STATIC FLAG_T SERV_ApplyDataDependencyFilter(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, SCPT_ARG_STP);
STATIC void SERV_AddNewEvent(DBA_ACTION_ENUM, OBJECT_ENUM, DBA_DYNFLD_STP, BE_EVENT_MAP_T &, MemoryPool &);
STATIC RET_CODE DBA_ProcessDataDepOnCurrentBE(DBA_HIER_HEAD_STP, DataDepDefinition *, DBA_DYNFLD_STP, BE_EVENT_MAP_T&, ThreadStateCycle&, MemoryPool &);

STATIC RET_CODE DBA_InsertAllNewEvents(DbiConnectionHelper &, BE_EVENT_MAP_T&, ThreadStateCycle &); 		/* PMSTA-38290 - JBC  - 200207 */
STATIC RET_CODE DBA_DeleteObjectModifStat(DbiConnectionHelper &, BE_EVENT_MAP_T&, ThreadStateCycle &); 		/* PMSTA-38290 - JBC  - 200207 */

STATIC void DBA_FreeEventMapAndRecords(BE_EVENT_MAP_T&);
STATIC void SERV_FreeDataDependencyFilter(SCPT_ARG_STP **, int );
STATIC void SERV_FreeDataDependency( DBA_DYNFLD_STP **, int *);

/******* DataDepDefinition **********************************************/
DataDepDefinition::DataDepDefinition(DBA_DYNFLD_STP dataDependencyStp,	SCPT_ARG_STP filterTree) : 
    m_Record(dataDependencyStp),
	m_FilterScriptTree(filterTree),
	m_InsertInMasterFlg(false), 
    m_InsertInAllBEFlg(false), 
    m_UpdateObjOnBEFlg(false)
{
    if (!GEN_IsMultiEntity())
    {
        m_InsertInMasterFlg = false;
        m_InsertInAllBEFlg = false;
    }
    else
    {
        DICT_ENTITY_STP notifyDictEntityPtr = DBA_GetDictEntityByDictId(GET_DICT(dataDependencyStp, A_DataDependency_NotifyEntityDictId));

        switch(notifyDictEntityPtr->multiEntityCateg.get())
        {
            case MultiEntityCategory_None:
            case MultiEntityCategory_MasterOnly:
            case MultiEntityCategory_DerivedMasterOnly:
            case MultiEntityCategory_MasterOnlyPrecOnBEOnly:        /* PMSTA-30152 - LJE - 180509 */
                m_InsertInMasterFlg = true;
                m_InsertInAllBEFlg = false;
                break;

            case MultiEntityCategory_BusinessEntityOnly:
            case MultiEntityCategory_DerivedBusinessEntityOnly:
                m_InsertInMasterFlg = false;
                m_InsertInAllBEFlg = true;
                break;

            case MultiEntityCategory_OptionalLocalization:
            case MultiEntityCategory_OptionalSpecialisation:
            case MultiEntityCategory_DerivedOptionalLocalization:
            case MultiEntityCategory_AllBusinessEntityOnly:                /* PMSTA-30152 - LJE - 180509 */
            case MultiEntityCategory_DerivedAllBusinessEntityOnly:         /* PMSTA-30152 - LJE - 180509 */
                m_InsertInMasterFlg = true;
                m_InsertInAllBEFlg = true;
                break;

            case MultiEntityCategory_TechnicalInfrastructure:
            case MultiEntityCategory_NoAccessibilityConstraint:
            case MultiEntityCategory_FullOptionalLocalization:
            default:
                m_InsertInMasterFlg = false;
                m_InsertInAllBEFlg = false;
                break;
        }

        DICT_ENTITY_STP UpdatedDictEntityPtr = DBA_GetDictEntityByDictId(GET_DICT(dataDependencyStp, A_DataDependency_EntityDictId));

        switch(UpdatedDictEntityPtr->multiEntityCateg.get())
        {
            case MultiEntityCategory_BusinessEntityOnly:
            case MultiEntityCategory_DerivedBusinessEntityOnly:
            case MultiEntityCategory_OptionalLocalization:
            case MultiEntityCategory_OptionalSpecialisation:
            case MultiEntityCategory_DerivedOptionalLocalization:
            case MultiEntityCategory_AllBusinessEntityOnly:                /* PMSTA-30152 - LJE - 180509 */
            case MultiEntityCategory_DerivedAllBusinessEntityOnly:         /* PMSTA-30152 - LJE - 180509 */
                m_UpdateObjOnBEFlg = true;
                break;

            case MultiEntityCategory_None:
            case MultiEntityCategory_MasterOnly:
            case MultiEntityCategory_DerivedMasterOnly:
            case MultiEntityCategory_TechnicalInfrastructure:
            case MultiEntityCategory_NoAccessibilityConstraint:
            case MultiEntityCategory_FullOptionalLocalization:
            case MultiEntityCategory_MasterOnlyPrecOnBEOnly:        /* PMSTA-30152 - LJE - 180509 */
            default:
                m_UpdateObjOnBEFlg = false;
                break;
        }
    }
}

DBA_DYNFLD_STP DataDepDefinition::getDataDepRec()
{
    return(this->m_Record);
}

SCPT_ARG_STP DataDepDefinition::getFiltertScriptTree()
{
    return(this->m_FilterScriptTree);
}

bool DataDepDefinition::bInsertInMaster(void)
{
    return(this->m_InsertInMasterFlg);
}

bool DataDepDefinition::bInsertInAllBE(void)
{
    return(this->m_InsertInAllBEFlg);
}

bool DataDepDefinition::bUpdateObjOnBE(void)
{
    return(this->m_UpdateObjOnBEFlg);
}

/******* DataDep ***********************************************/
void DataDep::load(DBA_HIER_HEAD_STP     hierHead, DbiConnectionHelper&     dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;

    ret = SERV_LoadActiveDataDependency(&this->m_dataDepArray, &this->m_dataDepNbr, dbiConnHelper);

    if (RET_SUCCEED == ret && this->m_dataDepNbr > 0) /* PMSTA-41113 - KNI - 040920 */
    {
        ret = SERV_LoadDataDependencyFilter(hierHead, this->m_dataDepArray, this->m_dataDepNbr, dbiConnHelper, &this->m_filterTreeTab);
    }

    if (RET_SUCCEED == ret)
    {
        for (int i=0; i<this->m_dataDepNbr; i++)
        {
            DataDepDefinition *dataDepDef = new DataDepDefinition(this->m_dataDepArray[i], this->m_filterTreeTab[i]);
            m_AllDataDepDef.insert(dataDepDef);

            auto itEntity = this->m_DataDepEntityMap.find(GET_DICT(this->m_dataDepArray[i], A_DataDependency_EntityDictId));

            if (itEntity == this->m_DataDepEntityMap.end())
            {
                this->m_DataDepEntityMap.insert(std::make_pair(GET_DICT(this->m_dataDepArray[i], A_DataDependency_EntityDictId), new DataDepEntity()));
                itEntity = this->m_DataDepEntityMap.find(GET_DICT(this->m_dataDepArray[i], A_DataDependency_EntityDictId));
            }

            DataDepEntity *dataDepEntity = itEntity->second;

            if (GET_FLAG(this->m_dataDepArray[i], A_DataDependency_InsertFlg) == TRUE)
            {
                dataDepEntity->insert(ObjModifStatAction_Insert, dataDepDef);
            }

            if (GET_FLAG(this->m_dataDepArray[i], A_DataDependency_UpdateFlg) == TRUE)
            {
                dataDepEntity->insert(ObjModifStatAction_Update, dataDepDef);
            }

            if (GET_FLAG(this->m_dataDepArray[i], A_DataDependency_DeleteFlg) == TRUE)
            {
                dataDepEntity->insert(ObjModifStatAction_Delete, dataDepDef);
            }
        }
    }

    return;
}


std::set <DataDepDefinition *> DataDep::getDefinitionSet(DICT_T entityDictId, OBJMODIFSTAT_ACTION_ENUM action)
{
    auto it = this->m_DataDepEntityMap.find(entityDictId);

    if (it != this->m_DataDepEntityMap.end())
    {
        DataDepEntity *dataDepEntity = it->second;
        return(dataDepEntity->getDefinitionSet(action));
    }

    return std::set <DataDepDefinition *> ();
}

void DataDep::clear(void)
{
    SERV_FreeDataDependencyFilter(&m_filterTreeTab, m_dataDepNbr);
    SERV_FreeDataDependency(&m_dataDepArray, &m_dataDepNbr);

    /* Free all DataDepDefinition */
    for (auto it=m_AllDataDepDef.begin(); it != m_AllDataDepDef.end(); ++it)
    {
        delete(*it);
    }

    m_AllDataDepDef.clear();

    /* Free all DataDepEntity */
    for (auto it=m_DataDepEntityMap.begin(); it != m_DataDepEntityMap.end(); ++it)
    {
        it->second->clear();
        delete it->second;
    }
    m_DataDepEntityMap.clear();

    return;
}


/******* DataDepEntity *****************************************/

std::set<DataDepDefinition *> DataDepEntity::getDefinitionSet(OBJMODIFSTAT_ACTION_ENUM action)
{
    switch(action)
    {
        case ObjModifStatAction_Insert:
            return this->m_InsertSet;
            break;
        case ObjModifStatAction_Update:
            return this->m_UpdateSet;
            break;
        case ObjModifStatAction_Delete:
            return this->m_DeleteSet;
            break;
    }

    return std::set <DataDepDefinition *> ();
}

void DataDepEntity::insert(OBJMODIFSTAT_ACTION_ENUM action, DataDepDefinition *dataDepDefinition)
{
    switch(action)
    {
        case ObjModifStatAction_Insert:
            this->m_InsertSet.insert(dataDepDefinition);
            break;
        case ObjModifStatAction_Update:
            this->m_UpdateSet.insert(dataDepDefinition);
            break;
        case ObjModifStatAction_Delete:
            this->m_DeleteSet.insert(dataDepDefinition);
            break;
    }
    return;
}

void DataDepEntity::clear(void)
{
    this->m_InsertSet.clear();
    this->m_UpdateSet.clear();
    this->m_DeleteSet.clear();

    return;
}




/************************************************************************
*   Function            : isTrace()
*
*   Description         : returns if the trace is on
*
*************************************************************************/
bool isTrace()
{
    static int                  SV_Trace = -1;

    if (SV_Trace < 0)
    {
        SV_Trace = SYS_GetEnvBoolOrDefValue("AAADATADEPTRACE", false) ? 1 : 0;
    }

    return (SV_Trace == 1);

}


/************************************************************************
*   Function            : traceLogSrvMesg()
*
*   Description         : logs trace messages with a standard format
*
*************************************************************************/
void traceLogSrvMesg(std::string msg)
{
    MSG_LogSrvMesg(UNUSED, UNUSED, (";" + serverInfo + ";" + msg).c_str());
}


/************************************************************************
*   Function        :   SERV_CmpDataDependencyRank
*
*   Description     :   Compare the rank of two A_DataDependency structure
*
*   Arguments       :   pArg1   First element to compare
*                       pArg2   Second element to compare
*
*   Return          :   a negative value    if first element < second element
*                       zero                if first element = second element
*                       a positive value    if first element > second element
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :
*
*************************************************************************/
STATIC int SERV_CmpDataDependencyRank(const void * pArg1, const void * pArg2)
{
    int                 cmp=0;
    DBA_DYNFLD_STP     *ptr1 = (DBA_DYNFLD_STP *)pArg1;
    DBA_DYNFLD_STP     *ptr2 = (DBA_DYNFLD_STP *)pArg2;
    static FIELD_IDX_T  ownerBEIdFldIdx = 9999;

    if (ownerBEIdFldIdx == 9999)
    {
        if (!GEN_IsMultiEntity())
        {
            ownerBEIdFldIdx= Null_Dynfld;
        }
        else
        {
            auto dictAttrPtr = DBA_GetDictEntityStSafe(DataDependency)->ownerBusinessEntAttrStp;

            if (dictAttrPtr != NULL)
            {
                ownerBEIdFldIdx = dictAttrPtr->progN;
            }
        }
    }

    if (ownerBEIdFldIdx != Null_Dynfld)
    {
        if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, ownerBEIdFldIdx, ownerBEIdFldIdx, IdType)) != 0)
            return(cmp);
    }

    return(CMP_DYNFLD(*ptr1, *ptr2, A_DataDependency_EntityDictId, A_DataDependency_EntityDictId, DictType));
}


/************************************************************************
*   Function        :   SERV_LoadActiveDataDependency
*
*   Description     :   Load active data dependency into memory
*
*   Arguments       :   pDataDependencyTab  Data dependency loaded into memory
*                       pDataDependencyNb   # dependency loaded into memory
*                       dbiConnectionHelper Connection
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-23902 - 290616 - PMO : Merge TA/11.0.0 with TA/20.1.0 in TA/21.0.0
*                       PMSTA-26569 - DDV - 171208 : Multi entity and refoctoring.
*
*************************************************************************/
STATIC RET_CODE SERV_LoadActiveDataDependency(DBA_DYNFLD_STP ** pDataDependencyTab, int * pDataDependencyNb, DbiConnectionHelper & dbiConnectionHelper)    /* PMSTA-23902 - 290616 - PMO */
{
    /* PMSTA-41113 - KNI - 310820 */
    MemoryPool mp;
    DBA_DYNFLD_STP inpArg = nullptr;

    if ((inpArg = mp.allocDynst(FILEINFO, Get_Arg)) == nullptr)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    SET_NULL_ID(inpArg, Get_Arg_Id);
    if (SERVER_MODE())
    {
        SET_ID(inpArg, Get_Arg_Id, EV_CurrentSrvConfig.getBusEntityId());
    }
    /* PMSTA-41113 - KNI - 310820 */

    const RET_CODE ret = dbiConnectionHelper.dbaSelect(DataDependency,
                                                       UNUSED,
                                                       inpArg, // PMSTA-41113 - KNI - 310820
                                                       A_DataDependency,
                                                       pDataDependencyTab,
                                                       pDataDependencyNb);

    if (RET_SUCCEED == ret)
    { /* Ok */
        if (*pDataDependencyNb > 1)
        {
            TLS_Sort((char *)   *pDataDependencyTab,
                                *pDataDependencyNb,
                                sizeof(DBA_DYNFLD_STP),
		                        (TLS_CMPFCT *) SERV_CmpDataDependencyRank,
                                NULL,
                                SortRtnTp_None);
        }
    }
	else
    { /* Error */
		char errString[80];

		(void)snprintf(errString, sizeof(errString), "The loading of data dependency has failed with error [%x]", ret);
		(void)MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, errString);
    }

    return ret;
}


/************************************************************************
*   Function        :   SERV_FreeDataDependency
*
*   Description     :   Free loaded data dependency into memory
*
*   Arguments       :   pDataDependencyTab   Array to free
*                       pDataDependencyNb    # of elements in the array
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*************************************************************************/
STATIC void SERV_FreeDataDependency( DBA_DYNFLD_STP ** pDataDependencyTab, int * pDataDependencyNb)
{
    if (NULL != *pDataDependencyTab)
    {
        for (int idx = 0; idx < *pDataDependencyNb; idx++)
        {
            FREE_DYNST(((*pDataDependencyTab)[idx]), GET_DYNSTENUM(((*pDataDependencyTab)[idx])));
        }

        FREE(*pDataDependencyTab);
    }

    if (NULL != pDataDependencyNb)    /* PMSTA-17133 - 051113 - PMO */
    {
        *pDataDependencyNb = 0;
    }
}

/************************************************************************
*   Function        :   SERV_LoadDataDependencyFilter
*
*   Description     :   Load data dependency filters
*
*   Arguments       :   pDataDependencyTab  Data dependencies
*                       pDataDependencyNb   # dependencies
*                       dbiConnectionHelper Connection
*
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-16729 - LJE - 140220 - Scripting for RuBe
*
*   Last Modif.     :
*
*************************************************************************/
STATIC RET_CODE SERV_LoadDataDependencyFilter(DBA_HIER_HEAD_STP     hierHead,
                                              DBA_DYNFLD_STP *      dataDependencyTab,
                                              int                   dataDependencyNb,
                                              DbiConnectionHelper & dbiConnectionHelper,    /* PMSTA-23902 - 290616 - PMO */
                                              SCPT_ARG_STP **       pFilterTreeTab)

{
    RET_CODE         ret = RET_SUCCEED;
    SCPT_ARG_STP     localFilterTree = NULL;
    int              i;
    DICT_ATTRIB_STP	 dictAttrSt;
    DBA_DYNFLD_STP   scptRecStp = ALLOC_DYNST(A_ScriptDef);

    if (DBA_SearchAttribSqlName(DataDependency, "script_definition", &dictAttrSt) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_MD, 1, FILEINFO, "data_dependency", "script_definition");
        return RET_DBA_ERR_MD;
    }

    if (scptRecStp == NULL ||
        (*pFilterTreeTab = (SCPT_ARG_STP*)CALLOC(dataDependencyNb, sizeof(SCPT_ARG_STP))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, dataDependencyNb * sizeof(SCPT_ARG_STP));
        return RET_MEM_ERR_ALLOC;
    }

    /* Save script */
    SET_DICT(scptRecStp, A_ScriptDef_AttrDictId, dictAttrSt->attrDictId);
    SET_ENUM(scptRecStp, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

    for (i = 0; i < dataDependencyNb; i++)
    {
        OBJECT_ENUM entityObjectEnum;
        DBA_GetObjectEnum(GET_DICT(dataDependencyTab[i], A_DataDependency_EntityDictId), &entityObjectEnum);

        SET_NULL_STRING(scptRecStp, A_ScriptDef_Def);
        SET_ID(scptRecStp, A_ScriptDef_ObjId, GET_ID(dataDependencyTab[i], A_DataDependency_Id));

        if (DBA_GetScptDef(scptRecStp, *dbiConnectionHelper.getConnection()) == RET_SUCCEED &&        /* PMSTA-23902 - 290616 - PMO */
            IS_NULLFLD(scptRecStp, A_ScriptDef_Def) == FALSE &&
            GET_STRING(scptRecStp, A_ScriptDef_Def)[0] != 0)
        {
            if (SCPT_PrepTreeForFilter(GET_STRING(scptRecStp, A_ScriptDef_Def),
                hierHead,
                NULL,
                entityObjectEnum,
                &localFilterTree, 0, scptRecStp) == RET_SUCCEED)
            {
                (*pFilterTreeTab)[i] = localFilterTree;
            }
            else
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 1, FILEINFO, "data_dependency", GET_STRING(scptRecStp, A_ScriptDef_Def));
            }
        }
    }

    FREE_DYNST(scptRecStp, A_ScriptDef);

    return ret;
}

/************************************************************************
*   Function        :   SERV_ApplyDataDependencyFilter
*
*   Description     :   Check with the filter script if the object modif stat must be applied
*
*   Arguments       :   filterTreeTab
*                       pDataDependencyNb    # of elements in the array
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-16729 - LJE - 140220 - Scripting for RuBe
*
*   Last Modif.     :
*
*************************************************************************/
STATIC FLAG_T SERV_ApplyDataDependencyFilter(DBA_HIER_HEAD_STP hierHead,
                                             DBA_DYNFLD_STP objectModifStatStp,
                                             SCPT_ARG_STP filterTree)
{
    FLAG_T                resultFlg = TRUE;
    RET_CODE              ret = RET_SUCCEED;
    DbiConnectionHelper   dbiConnHelper;

    if (NULL != filterTree)
    {
        SCPT_ARG_STP     localFilterTree = filterTree;
        OBJECT_ENUM      entityObjectEnum = localFilterTree->context->object;
        int              incrNb = 0;
        DICT_ENTITY_STP  dictEntityStp = DBA_GetDictEntitySt(entityObjectEnum);
        DBA_DYNST_ENUM   sImpactedEnum = GET_ADMINGUIST(entityObjectEnum),
            aImpactedEnum = GET_EDITGUIST(entityObjectEnum);
        DBA_DYNFLD_STP   evalFltRec = NULL,
            aImpactedRecStp = ALLOC_DYNST(aImpactedEnum),
            sImpactedRecStp = ALLOC_DYNST(sImpactedEnum);

        ret = RET_GEN_ERR_INVARG;
        if (dictEntityStp->primKeyNbr == 1 &&
            (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
            dictEntityStp->primKeyTab[0]->dataTpProgN == DictType) &&
            dictEntityStp->primKeyTab[0]->isNullShortIdx == false)
        {
            ret = RET_SUCCEED;
            COPY_DYNFLD(sImpactedRecStp, sImpactedEnum, dictEntityStp->primKeyTab[0]->shortIdx,
                        objectModifStatStp, A_ObjectModifStat, A_ObjectModifStat_ImpactedObjId);
        }
        else if (dictEntityStp->primKeyNbr == 2 &&
                 dictEntityStp->primKeyTab[0]->dataTpProgN == DictType &&
                 dictEntityStp->primKeyTab[0]->isNullShortIdx == false &&
                 dictEntityStp->primKeyTab[1]->dataTpProgN == IdType &&
                 dictEntityStp->primKeyTab[1]->isNullShortIdx == false &&
                 dictEntityStp->primKeyTab[1]->linkedAttrDictStp->attrDictId == dictEntityStp->primKeyTab[0]->attrDictId)
        {
            ret = RET_SUCCEED;
            COPY_DYNFLD(sImpactedRecStp, sImpactedEnum, dictEntityStp->primKeyTab[0]->shortIdx,
                        objectModifStatStp, A_ObjectModifStat, A_ObjectModifStat_ImpactedEntityDictId);
            COPY_DYNFLD(sImpactedRecStp, sImpactedEnum, dictEntityStp->primKeyTab[1]->shortIdx,
                        objectModifStatStp, A_ObjectModifStat, A_ObjectModifStat_ImpactedObjId);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaGet(entityObjectEnum, UNUSED, sImpactedRecStp, &aImpactedRecStp);

			/* PMSTA-49109 - AKH - 250622 - To handle the ObjectModifStat record having the impacted_entity_dict_id as ext_order,
			if the corresponding record is not found in ext_order table, as Fusion has already treated it */
			if (!(ret == RET_SUCCEED) && (entityObjectEnum == ExtOrder))
			{
				MSG_LogSrvMesg(UNUSED, UNUSED, SYS_Stringer("The ", OBJ_V2N(entityObjectEnum), " id = ", GET_ID(objectModifStatStp, A_ObjectModifStat_ImpactedObjId), "  which we were trying to fetch was not found in the DataBase").c_str());

				resultFlg = FALSE;

			}
        }

        localFilterTree->objectModifStatRec = objectModifStatStp; /* PMSTA-21235 - DDV - 151120 - Set objectModifStat to allow OBJECT_MODIF_STAT usage */

        if (ret == RET_SUCCEED &&
            SCPT_IsRemoveWithFilterTree(hierHead,
            entityObjectEnum,
            &localFilterTree,
            aImpactedRecStp,
            &evalFltRec,
            &incrNb))  /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */
        {
            resultFlg = FALSE;
        }

        FREE_DYNST(aImpactedRecStp, aImpactedEnum);
        FREE_DYNST(sImpactedRecStp, sImpactedEnum);
    }

    return resultFlg;
}

/************************************************************************
*   Function        :   SERV_FreeDataDependencyFilter
*
*   Description     :   Free loaded data dependency filters into memory
*
*   Arguments       :   pFilterTreeTab   Array to free
*                       pDataDependencyNb    # of elements in the array
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-16729 - LJE - 140220 - Scripting for RuBe
*
*   Last Modif.     :
*
*************************************************************************/
STATIC void SERV_FreeDataDependencyFilter(SCPT_ARG_STP ** pFilterTreeTab, int dataDependencyNb)
{
    if (NULL != *pFilterTreeTab)
    {
        for (int idx = 0; idx < dataDependencyNb; idx++)
        {
            if ((*pFilterTreeTab)[idx] != NULL)
            {
                SCPT_FreeTreeForFilter(&((*pFilterTreeTab)[idx]));
            }
        }

        FREE(*pFilterTreeTab);
    }
}


/************************************************************************
*   Function        :   SERV_LoadObjectModifStat
*
*   Description     :   Load some ObjectModifStat into memory
*                       (limited by the system parameter)
*
*   Arguments       :   pObjectModifStatTab   ObjectModifStat loaded into memory
*                       pObjectModifStatNb    # ObjectModifStat loaded into memory
*                       dbMaxDbRead;            Maximum # of records read
*                       connHelper              Connection helper
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-16082 - 230413 - PMO : Dispatch server logs tons on log is the ASE has shutdown
*                       PMSTA-21985 - 060116 - PMO : Dispatch server logs tons on log if ORACLE is not reachable
*                       PMSTA-32288 - JBC - 190116 : Add cluster handling
*
*************************************************************************/
STATIC RET_CODE SERV_LoadObjectModifStat( DBA_DYNFLD_STP ** pObjectModifStatTab, int * pObjectModifStatNb, const int dbMaxDbRead, DbiConnectionHelper& connHelper, const bool useServerId)
{
    RET_CODE ret = RET_SUCCEED;

    if(useServerId  && SV_ServerId > ZERO_ID)
    {
        MemoryPool mp;
        DBA_DYNFLD_STP selArgs = mp.allocDynst(FILEINFO, Io_Id);
        SET_ID(selArgs, Io_Id_Id, SV_ServerId);

        /* sel_all_obj_modif_stat_by_sid */
        ret = DBA_Select2(ObjectModifStat, DBA_ROLE_CLUSTER, Io_Id,selArgs,
                            A_ObjectModifStat, pObjectModifStatTab, dbMaxDbRead, pObjectModifStatNb, connHelper);
    }
    else
    {
        /* PMSTA-41113 - KNI - 310820 */
        MemoryPool mp;
        DBA_DYNFLD_STP selArgs = mp.allocDynst(FILEINFO, Get_Arg);

        SET_NULL_ID(selArgs, Get_Arg_Id);
        if (SERVER_MODE())
        {
            SET_ID(selArgs, Get_Arg_Id, EV_CurrentSrvConfig.getBusEntityId());
        }

        /* sel_all_obj_modif_stat */
        ret = DBA_Select2(ObjectModifStat, UNUSED, Get_Arg, selArgs,
                            A_ObjectModifStat, pObjectModifStatTab, dbMaxDbRead, pObjectModifStatNb, connHelper);
        /* PMSTA-41113 - KNI - 310820 */
    }


    if (RET_SUCCEED != ret)
    { /* Error */
        MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, std::string("The loading of Object Modif Stat has failed with error [" + SYS_ToHexString(ret) +"]" ).c_str());   /* PMSTA-21985 - 060116 - PMO */
    }

    return ret;
}


/************************************************************************
*   Function        :   SERV_AddNewEvent
*
*   Description     :   Add the given event into the pNewEventTab given has argument
*                       Array growth automatically
*
*   Arguments       :   action          Database action to do (Insert or Delete)
*                       objectEn        OBJECT_ENUM of the current record
*                       recordStp       record
*                       eventMap        map use to store records to insert or delete group by BE
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :
*
*************************************************************************/
STATIC void SERV_AddNewEvent(DBA_ACTION_ENUM   action,
                                 OBJECT_ENUM       objectEn,
                                 DBA_DYNFLD_STP    recordStp,
                                 BE_EVENT_MAP_T &  eventMap,
                                 MemoryPool     &  mp)
{
    NEW_EVENT_STP newEventStp = (NEW_EVENT_STP) mp.calloc(1, sizeof(NEW_EVENT_ST));

    newEventStp->action = action;
    newEventStp->objectEn = objectEn;
    newEventStp->recordStp = recordStp;

    auto itMap = eventMap.find(SYS_GetThreadCurrBusinessEntity());
    EVENT_SET_T *typeSet;

    if (itMap == eventMap.end())
    {
        typeSet=new(EVENT_SET_T);
        eventMap.insert(std::make_pair(SYS_GetThreadCurrBusinessEntity(), typeSet));
        itMap = eventMap.find(SYS_GetThreadCurrBusinessEntity());
    }

    typeSet=itMap->second;
    typeSet->insert(newEventStp);

}

/************************************************************************
*   Function        :   DBA_FreeEventMapAndRecords
*
*   Description     :   Free all event records, object_modif stat records, event set and entity map
*
*   Arguments       :   eventMapByBE         map by BE containing a set of NEW_EVENT
*
*   Return          :   RET_CODE or error
*
*   Creation Date   :   PMSTA-26569 - DDV - 171212
*
*   Last Modif.     :
*
*************************************************************************/
STATIC void DBA_FreeEventMapAndRecords(BE_EVENT_MAP_T& eventMapByBE)
{
    for (auto itMap = eventMapByBE.begin(); itMap != eventMapByBE.end(); ++itMap)
    {
        EVENT_SET_T *eventSet = (itMap->second);
        /*for (auto itEvent = eventSet->begin(); itEvent != eventSet->end(); ++ itEvent)
        *{
        *    NEW_EVENT_STP  newEvent = *itEvent;
        *    FREE_DYNST(newEvent->recordStp, GET_DYNSTENUM(newEvent->recordStp));  
        *    FREE(newEvent); /
        *}
        *PMSTA-54147 - JBC - 230819 already in memorypool */
        eventSet->clear();
        delete(eventSet);
    }
    eventMapByBE.clear();

    return;
}

/************************************************************************
*   Function        :   DBA_InsertAllNewEvents
*
*   Description     :   Insert all event from the map having Insert as action
*
*   Arguments       :   eventMapByBE         map by BE containing a set of NEW_EVENT
*                       dbiConnectionHelper  connection helper
*
*   Return          :   RET_CODE or error
*
*   Creation Date   :   PMSTA-26569 - DDV - 171212
*
*   Last Modif.     :  PMSTA-38290 - JBC  - 200207 
*
*************************************************************************/
STATIC RET_CODE DBA_InsertAllNewEvents(DbiConnectionHelper & dbiConnHelper, BE_EVENT_MAP_T& eventMapByBE, ThreadStateCycle & threadStateCycle)
{
    RET_CODE            ret = RET_SUCCEED;
    RET_CODE            retFinal = RET_SUCCEED;

    for (auto itMap = eventMapByBE.begin(); itMap != eventMapByBE.end() && threadStateCycle.isRunning(); ++itMap)
    {
        EVENT_SET_T *eventSet = (itMap->second);
        if(GEN_IsMultiEntity())  /* PMSTA-38290 - JBC  - 200207 */
        {
            std::string busEntityCd = itMap->first;
            dbiConnHelper.setCurrBusinessEntity(busEntityCd);
        }
        
        for (auto itEvent = eventSet->begin(); itEvent != eventSet->end() && threadStateCycle.isRunning(); ++ itEvent)
        {
            NEW_EVENT_STP          newEvent = *itEvent;

            ret = RET_SUCCEED; /* PMSTA-29792 - DDV - 180111 */

            if (newEvent->action == Insert)
                ret = dbiConnHelper.dbaInsert(newEvent->objectEn, UNUSED, newEvent->recordStp);

            if (RET_SUCCEED != ret)
            { /* Error */
                char errString[128];

                (void)snprintf(errString, sizeof(errString), "Error while inserting the event object " szFormatObj " '%s'", newEvent->objectEn, OBJ_V2N(newEvent->objectEn));
                (void)MSG_SendMesg(FILEINFO, errString);
                retFinal = ret;
            }
        }
    }
    return(retFinal);
}


/************************************************************************
*   Function        :   DBA_UnlockObjectModifStat
*
*   Description     :   Sets serverid to null in object_modif_stat for a given server
*
*   Arguments       :   
*
*   Return          :   RET_CODE or error
*
*   Creation Date   :   PMSTA-26569 - DDV - 171212
*
*   Last Modif.     :   PMSTA-38290 - JBC  - 200207 
*
*************************************************************************/
void DBA_UnlockObjectModifStat(DbiConnectionHelper & connHelper)
{
    if(GEN_UseDispatcher() == false && SV_ServerId != ZERO_ID && connHelper.isValidAndInit())
    {
        MemoryPool mp;        
        DBA_DYNFLD_STP aObjModifStat = mp.allocDynst(FILEINFO, A_ObjectModifStat);
        SET_NULL_ID(aObjModifStat, A_ObjectModifStat_Id);
        SET_ID(aObjModifStat, A_ObjectModifStat_ServerId, SV_ServerId);

        auto busEntityCds = SYS_GetApplSessionRankedBusEntCds(true);
        const int busEntityNb = static_cast<int>(busEntityCds.size());

        for(int i=0;i<busEntityNb;i++)
        {   
            if(GEN_IsMultiEntity())
            {
                connHelper.setCurrBusinessEntity(busEntityCds[i].first);
            }
            
            /* upd_obj_modif_stat_sid - by entity */
            if(connHelper.dbaUpdate(ObjectModifStat, DBA_ROLE_CLUSTER, aObjModifStat) != RET_SUCCEED)
            {
                MSG_SendMesg(FILEINFO, "Unlock Object Modif Stat Failed");
                break;
            } 
        }
    }
}

/************************************************************************
*   Function        :   DBA_DeleteObjectModifStat
*
*   Description     :   Delete all event for Object modif stat having Delete as action
*
*   Arguments       :   eventMapByBE         map by BE containing a set of NEW_EVENT
*                       dbiConnectionHelper  connection helper
*
*   Return          :   RET_CODE or error
*
*   Creation Date   :   PMSTA-26569 - DDV - 171212
*
*   Last Modif.     :  PMSTA-38290 - JBC  - 200207 
*
*************************************************************************/
STATIC RET_CODE DBA_DeleteObjectModifStat(DbiConnectionHelper & dbiConnHelper, BE_EVENT_MAP_T& eventMapByBE, ThreadStateCycle & threadStateCycle)
{
    RET_CODE            ret = RET_SUCCEED;
    RET_CODE            retFinal = RET_SUCCEED;
    MemoryPool          mp;
    DBA_DYNFLD_STP      sObjectModifStatSt = mp.allocDynst(FILEINFO,S_ObjectModifStat);

    if (sObjectModifStatSt == NULL)
    {
        const int fldObjectModifStatNbr = GET_FLD_NBR(S_ObjectModifStat);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, fldObjectModifStatNbr * sizeof(DBA_DYNFLD_ST));
        return(RET_MEM_ERR_ALLOC);
    }

    for (auto itMap = eventMapByBE.begin(); itMap != eventMapByBE.end() && threadStateCycle.isRunning(); ++itMap)
    {
        EVENT_SET_T *eventSet = (itMap->second);
        if(GEN_IsMultiEntity())				/* PMSTA-38290 - JBC  - 200207 */
        {
            std::string busEntityCd = itMap->first;
            dbiConnHelper.setCurrBusinessEntity(busEntityCd);
        }

        for (auto itEvent = eventSet->begin(); itEvent != eventSet->end() && threadStateCycle.isRunning(); ++ itEvent)
        {
            NEW_EVENT_STP       newEvent = *itEvent;

            if (newEvent->action == Delete && newEvent->objectEn == ObjectModifStat)
            {
                COPY_DYNFLD(sObjectModifStatSt, S_ObjectModifStat, S_ObjectModifStat_Id, newEvent->recordStp, A_ObjectModifStat, A_ObjectModifStat_Id);
                ret = dbiConnHelper.dbaDelete(ObjectModifStat, UNUSED, sObjectModifStatSt);
            }

            if (RET_SUCCEED != ret)
            { /* Error */
                char errString[128];

                (void)snprintf(errString, sizeof(errString), "Error while inserting the event object " szFormatObj " '%s'", newEvent->objectEn, OBJ_V2N(newEvent->objectEn));
                (void)MSG_SendMesg(FILEINFO, errString);
                retFinal = ret;
            }
        }
    }

    return(retFinal);
}

/************************************************************************
*   Function        :   DBA_FillDataDependencyParam
*
*   Description     :   Update attribute data_dependency_param of toObjectStp  with the value
*                       of data_dependency.param_attr_dict_id
*
*   Arguments       :  objectModifStatRec Object Modif stats
*                   :  notifiedObjetEnum  Notified Object  Enum
                       notifiedObjectStp  Notified  Object to fill
                       dataDependencyStp data_dependenc rule
*
*   Return          :   notifiedObjectStp modified with data_dependency_param filled
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
STATIC void DBA_FillDataDependencyParam(DBA_DYNFLD_STP objectModifStatRec, OBJECT_ENUM notifiedObjetEnum, DBA_DYNFLD_STP notifiedObjectStp, DBA_DYNFLD_STP dataDependencyStp)
{
    DICT_T impactedEntityDictId = GET_DICT(dataDependencyStp, A_DataDependency_EntityDictId);
    DICT_ENTITY_STP  impactedDictEntityStp = (DICT_ENTITY_STP)DBA_GetDictEntityByDictId(impactedEntityDictId);
    OBJECT_ENUM impactedObjectEnum;
    DICT_ATTRIB_STP toAttr = DBA_GetAttributeBySqlName(notifiedObjetEnum, "data_dependency_param");
    (void)DBA_GetObjectEnum(impactedEntityDictId, &impactedObjectEnum);

    if (toAttr != NULL && impactedDictEntityStp->primKeyNbr == 1)
    {
        if (!IS_NULLFLD(dataDependencyStp, A_DataDependency_ParamAttrDictId))
        {
            DICT_ATTRIB_STP paramAttrib = DBA_GetAttributeById(GET_ID(dataDependencyStp, A_DataDependency_ParamAttrDictId));
                DbiConnectionHelper   dbiConnHelper;
                MemoryPool mp;
                DBA_DYNFLD_STP allImpactedStp = mp.allocDynst(FILEINFO, GET_EDITGUIST(impactedObjectEnum));
                DBA_DYNFLD_STP sImpactedStp = mp.allocDynst(FILEINFO, GET_ADMINGUIST(impactedObjectEnum));
                RET_CODE ret;

                COPY_DYNFLD(sImpactedStp, GET_ADMINGUIST(impactedObjectEnum), impactedDictEntityStp->primKeyTab[0]->shortIdx,
                    objectModifStatRec, A_ObjectModifStat, A_ObjectModifStat_ImpactedObjId);

                ret = dbiConnHelper.dbaGet(impactedObjectEnum, UNUSED, sImpactedStp, &allImpactedStp);
            if (ret == RET_SUCCEED)
            {
                if (!IS_NULLFLD(allImpactedStp, paramAttrib->progN)) {
                    char buff[NOTE_T_LEN];
                    PTR ptrData = NULL;
                    DATATYPE_ENUM dataType = NullDataType;
                    if (paramAttrib->refEntDictId != NULL)
                    {
                        DICT_ENTITY_STP  refDictEntityStp = (DICT_ENTITY_STP)DBA_GetDictEntityByDictId(paramAttrib->refEntDictId);
                        OBJECT_ENUM refObjectEnum;
                        (void)DBA_GetObjectEnum(paramAttrib->refEntDictId, &refObjectEnum);
                        if (refDictEntityStp->bkAttrNbr > 0)
                        {
                            DBA_DYNFLD_STP allRefStp = mp.allocDynst(FILEINFO, GET_EDITGUIST(refObjectEnum));
                            DBA_DYNFLD_STP sRefStp = mp.allocDynst(FILEINFO, GET_ADMINGUIST(refObjectEnum));

                            COPY_DYNFLD(sRefStp, GET_ADMINGUIST(refObjectEnum), refDictEntityStp->primKeyTab[0]->shortIdx,
                                allImpactedStp, GET_EDITGUIST(impactedObjectEnum), paramAttrib->progN);

                            ret = dbiConnHelper.dbaGet(refObjectEnum, UNUSED, sRefStp, &allRefStp);
                            if (ret == RET_SUCCEED)
                            {
                                dataType = refDictEntityStp->bkAttr[0]->dataTpProgN;
                                ptrData = DBA_GetDataFromDynStp(refDictEntityStp->bkAttr[0]->dataTpProgN, &allRefStp[refDictEntityStp->bkAttr[0]->progN]);
                            }
                            else
                            {
                                char szMsg[100];
                                snprintf(szMsg, sizeof(szMsg), "Cannot find entity '%s' with id %" szFormatId, refDictEntityStp->mdSqlName,
                                    GET_ID(sRefStp, refDictEntityStp->primKeyTab[0]->shortIdx));
                                (void)MSG_SendMesg(FILEINFO, szMsg);
                            }
                        }
                        else
                        {
                            //NO BK take the PK
                            dataType = paramAttrib->dataTpProgN;
                            ptrData = DBA_GetDataFromDynStp(paramAttrib->dataTpProgN, &allImpactedStp[paramAttrib->progN]);
                        }
                    }
                    else
                    {
                        dataType = paramAttrib->dataTpProgN;
                        ptrData = DBA_GetDataFromDynStp(paramAttrib->dataTpProgN, &allImpactedStp[paramAttrib->progN]);
                    }

                    if (ptrData != NULL)
                    {
                        CONV_DataToStr(buff, sizeof(buff), dataType, NULL, ptrData, TRUE, TextConversion_None);
                        SET_NOTE(notifiedObjectStp, toAttr->progN, buff);
                    }
                }
            }
            else
            {
                char szMsg[100];
                snprintf(szMsg, sizeof(szMsg), "Cannot find entity '%s' with id %" szFormatId, impactedDictEntityStp->mdSqlName,
                    GET_ID(sImpactedStp, impactedDictEntityStp->primKeyTab[0]->shortIdx));
                (void)MSG_SendMesg(FILEINFO, szMsg);
            }
        }
        else if (!IS_NULLFLD(dataDependencyStp, A_DataDependency_ParamValueT))
        {
            SET_NOTE(notifiedObjectStp, toAttr->progN, GET_NOTE(dataDependencyStp, A_DataDependency_ParamValueT));
        }
    }
}

/************************************************************************
*   Function        :   DBA_ProcessDataDepOnCurrentBE
*
*   Description     :   Process one data dependance for one object modif stat.
*                       It is done for current be set on Thread.
*
*   Arguments       :   hierHead            hierachy header
*                       dataDepDef          object the contain data dependency defition
*                       objectModifStatRec  object modif stat to treat
*                       eventMapByBE        map used to store new records by BE
*                       threadStateCycle    thread state
*
*
*   Return          :   RET_CODE or error
*
*   Creation Date   :   PMSTA-26569 - DDV - 171212
*
*   Last Modif.     :
*
*************************************************************************/
STATIC RET_CODE DBA_ProcessDataDepOnCurrentBE(DBA_HIER_HEAD_STP hierHead, DataDepDefinition *dataDepDef, DBA_DYNFLD_STP objectModifStatRec, BE_EVENT_MAP_T& eventMapByBE, 
    ThreadStateCycle& threadStateCycle, MemoryPool & mp)
{
    RET_CODE               ret=RET_SUCCEED;

    if (SERV_ApplyDataDependencyFilter(hierHead, objectModifStatRec, dataDepDef->getFiltertScriptTree()) == TRUE)
    {
        OBJECT_ENUM objectToProcess;
        const DICT_T dictIdToProcess = GET_DICT(dataDepDef->getDataDepRec(), A_DataDependency_NotifyEntityDictId);  /* PMSTA-14419 - 080612 - PMO */
        (void)DBA_GetObjectEnum(dictIdToProcess, &objectToProcess);

        const int fldNbr = GET_FLD_NBR(GET_EDITGUIST(objectToProcess));

        if (fldNbr > 0)                                                                                                         /* PMSTA-14419 - 080612 - PMO */
        { /* Standard processing */
            DBA_DYNFLD_STP  newRecordStp = mp.allocDynst(FILEINFO, GET_EDITGUIST(objectToProcess));

            /*Flag tab processing */
            FLAG_T * scptFlagTab = (FLAG_T *)mp.calloc(fldNbr, sizeof(FLAG_T));

            if (RET_SUCCEED == ret)
            {
                SET_ID(objectModifStatRec, A_ObjectModifStat_DataDependencyId, GET_ID(dataDepDef->getDataDepRec(), A_DataDependency_Id));
                DBA_FillDataDependencyParam(objectModifStatRec, objectToProcess, newRecordStp, dataDepDef->getDataDepRec());
                if (0 == SCPT_ComputeScreenDV ( objectToProcess,
                                                DictFct_0,
                                                scptFlagTab,
                                                NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                                newRecordStp,
                                                NULLDYNST,
                                                NULLDYNST,
                                                objectModifStatRec,   /* PMSTA13283 - DDV - 120117 */
                                                TRUE,
                                                FALSE,
                                                EvalType_DefVal,
                                                -1,
                                                NULL,               /* PMSTA-23902 - 290616 - PMO */
                                                NULL,
                                                hierHead,
                                                0,
                                                NullEntity,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NullEntity,
                                                FALSE,
                                                FALSE,
                                                0))
                { /* Ok */
                    /* Insert the "event" into memory */
                    SERV_AddNewEvent(Insert, objectToProcess, newRecordStp, eventMapByBE, mp);
                }
                else
                { /* Error */
                    char errString[80];

                    (void)snprintf(errString, sizeof(errString), "Error while evaluating the script of the object " szFormatObj, objectToProcess);
                    (void)MSG_SendMesg(FILEINFO, errString);
                }
            }
        }
        else
        { /* No fields !!! / PMSTA-14419 - 080612 - PMO */
            char errString[64];

            (void)snprintf(errString, sizeof(errString), "Error no fields for object:%d, dict_id:%" szFormatId, int(objectToProcess), dictIdToProcess);   /* PMSTA-17133 - 051113 - PMO */
            (void)MSG_SendMesg(FILEINFO, errString);
        }
    } /* End if */

    return(ret);
}

/************************************************************************
*   Function        :   DBA_FreeObjModifStatNoSrv
*
*   Description     :   Updates any object_modif_stat with down/non-existent
*                       server to null
*
*   Arguments       :  connHelper
*                   :  srvIdArg - Io_Id with serverId making request
*
*   Return          :   RET_CODE
*
*   Creation Date   :   PMSTA-32288 - JBC - 190126
*
*   Last Modif.     :
*
*************************************************************************/
RET_CODE DBA_FreeObjModifStatNoSrv(DbiConnectionHelper & connHelper, DBA_DYNFLD_STP ioIdArg)
{
    /* upd_obj_modif_stat_no_sid */
    return connHelper.dbaUpdate(ObjectModifStat, DBA_ROLE_CLUSTER, ioIdArg);
}

/************************************************************************
*   Function        :   SERV_ThreadDataDep
*
*   Description     :   The data dependency thread
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-14419 - 080612 - PMO : Dispatcher stop the data dependency's thread
*                       PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                       PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                       PMSTA-21985 - 060116 - PMO : Dispatch server logs tons on log if ORACLE is not reachable
*                       PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*
*************************************************************************/
void SERV_ThreadDataDep(ThreadArg *)
{
    ThreadStateCycle            threadStateCycle(SV_ThreadDataDepLoop); /* PMSTA-29083 - 041217 - PMO                   */
    unsigned                    dbReadInterval;                         /* The default is 5 seconds                     */
    unsigned                    elapsed             = 0;                /* Elapsed since last read (200ms resolution)   */
    int                         dbMaxDbRead;                            /* Maximum # of records read                    */
    RET_CODE                    ret                 = RET_SUCCEED;      /* functions return                             */
    DBA_HIER_HEAD_STP           hierHead            = DBA_CreateHier();
    BE_EVENT_MAP_T              eventMapByBE;

    SERV_WaitForRpcRegistered();                            /* PMSTA-19735 - 020415 - PMO                   */
    SYS_GetThreadStackLeft();                               /* PMSTA-19735 - 020415 - PMO                   */
    SYS_SetThreadMayLoop(true);                             /* PMSTA-21985 - 060116 - PMO                   */

    /* Retrieve dict id */
    if (  nullptr == DBA_GetDictEntitySt(DataDependency) || nullptr == DBA_GetDictEntitySt(ObjectModifStat)
       )
    { /* Fatal error */
        MSG_SendMesg(FILEINFO, "Unable to retrieve the dict entity. Check DataDependency and ObjectModifStat");
        threadStateCycle.setFatal();    /* Fatal error */
        MSG_SendMesg(FILEINFO, "Thread data dependency terminated because of a fatal error" );
        return;
    }

    /* The thread is started */
    threadStateCycle.setRunning();

    const DICT_T dataDependencyDictId  = DBA_GetDictEntityStSafe(DataDependency)->entDictId;
    const DICT_T objectModifStatDictId = DBA_GetDictEntityStSafe(ObjectModifStat)->entDictId;
    const DICT_T extOrderDictId        = DBA_GetDictEntityStSafe(ExtOrder)->entDictId;

    FIELD_IDX_T objModifStatOwnerBeFldIdx = Null_Dynfld;
    FIELD_IDX_T dataDepOwnerBEFldIdx      = Null_Dynfld;
    if (GEN_IsMultiEntity())
    {
        auto dictAttrPtr = DBA_GetDictEntityStSafe(ObjectModifStat)->ownerBusinessEntAttrStp;
        if (dictAttrPtr != NULL)
        {
            objModifStatOwnerBeFldIdx = dictAttrPtr->progN;
        }

        dictAttrPtr = DBA_GetDictEntityStSafe(DataDependency)->ownerBusinessEntAttrStp;
        if (dictAttrPtr != NULL)
        {
            dataDepOwnerBEFldIdx = dictAttrPtr->progN;
        }
    }

    { /* System parameters */
        INT_T dbInt = 0;

        /* Interval between two empty database load */
        (void)GEN_GetApplInfo(ApplDataDepDbReadInterval, &dbInt);
        if (dbInt <= 0)
        {
            dbInt = 5;
        }
        dbReadInterval = (unsigned)dbInt * 1000;

        (void)GEN_GetApplInfo(ApplDataDepMaxDbReadRecords, &dbInt);
        if (dbInt <= 0)
        {
            dbInt = 10000;
        }
        dbMaxDbRead = (int)dbInt;
    }

    /* Database connection - scoped */
    {
        DbiConnectionHelper         initConnHelper;        /* PMSTA-22990 - 080416 - PMO */

        if (!initConnHelper.isValidAndInit())
        {
            MSG_SendMesg(FILEINFO, "Unable to get a connection");

            threadStateCycle.setFatal();    /* Fatal error */
            ret = RET_DBA_INFO_DISCONNECTED;
        }

        /*
         *  Load all data dependencies into memory
         */
        DataDep::getInstance().clear();
        DataDep::getInstance().load(hierHead, initConnHelper);

        if (RET_SUCCEED != ret)
        { /* Error */
            threadStateCycle.setFatal();    /* Fatal error */
        }

        /* cluster config */
        if(GEN_UseDispatcher() == false)
        {
            AtomicInt delegate(1);
            FusionTimer timer("DataDepTimer");
            FusionTimer delayTimer("DataDepDelayTimer");
            AtomicBool  isDelegateValid(false);
            ClusterServerCfg clusterSrvCfg(initConnHelper, EV_CurrentSrvConfig.getServerName(),0, ClusterCfg_None, delegate, timer, isDelegateValid, delayTimer);
            SV_ServerId = clusterSrvCfg.getSrvId();
        }
    }

    /* Main loop */
    while (threadStateCycle.isRunning())
    {
        if(isTrace()) traceLogSrvMesg("Start data dependency treatment");

        DbiConnectionHelper dbiConnectionHelper;
        if(dbiConnectionHelper.isValidAndInit() == false)
        {
            MSG_SendMesg(RET_DBA_ERR_CANNOTCONNECT, 0, FILEINFO);
            SYS_MilliSleep(2000);
            continue; 
        }

        MemoryPool mp;

        /* Load some ObjectModifStat into memory */
        DBA_DYNFLD_STP * objectModifStatTab = nullptr;
        int objectModifStatNb = 0;

        ret = SERV_LoadObjectModifStat(&objectModifStatTab, &objectModifStatNb, dbMaxDbRead, dbiConnectionHelper, false);

        mp.ownerDynStpTab(objectModifStatTab,objectModifStatNb);

        if(isTrace()) traceLogSrvMesg("Start data dependency treatment");

        if (RET_SUCCEED == ret)
        {
            /* Active mode (No Dispatch) must get server lock on all objects */
            if (objectModifStatNb > 0 && GEN_UseDispatcher() == false)
            {
                if(isTrace()) traceLogSrvMesg("Start lock of object_modif_stat.server_id");
                DBA_DYNFLD_STP updObjModifStat = mp.allocDynst(FILEINFO, A_ObjectModifStat); /* PMSTA-46133 - JBC - 210915 */       

                /* get server lock on all objects */
                for (int objectModifStatIdx = 0; objectModifStatIdx < objectModifStatNb  && threadStateCycle.isRunning(); objectModifStatIdx++)
                {   /* serverId must be null already */
                    if(!IS_NULLFLD(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_ServerId))
                    {
                        continue;
                    }
                    /* set upd args */
                    SET_ID(updObjModifStat, A_ObjectModifStat_Id, GET_ID(objectModifStatTab[objectModifStatIdx],A_ObjectModifStat_Id));
                    SET_ID(updObjModifStat, A_ObjectModifStat_ServerId, SV_ServerId);

                    std::string busEntityCd;

                    if (GEN_IsMultiEntity())
                    {
                         busEntityCd = SYS_GetApplSessBusEntCdByDyn(objectModifStatTab[objectModifStatIdx],objModifStatOwnerBeFldIdx);
                         /* PMSTA-38290 - JBC  - 200207 */
                         if (dbiConnectionHelper.setCurrBusinessEntity(busEntityCd) == false)
                         {
                            break;
                         }
                    }

                    ret = dbiConnectionHelper.dbaUpdate(ObjectModifStat, DBA_ROLE_CLUSTER, updObjModifStat);

                    if(ret != RET_SUCCEED)
                    {
                        break;
                    }
                }

                /* clear and re-select objModifStat  for this server */
                if(ret == RET_SUCCEED && threadStateCycle.isRunning())
                {
                    if(isTrace()) traceLogSrvMesg("Start re-select of locked datadep records");
                    mp.freeAll();
                    objectModifStatTab = nullptr;
                    objectModifStatNb = 0;

                    ret = SERV_LoadObjectModifStat(&objectModifStatTab, &objectModifStatNb, dbMaxDbRead, dbiConnectionHelper, true);
                    mp.ownerDynStpTab(objectModifStatTab,objectModifStatNb);
                }
            }

            if(ret == RET_SUCCEED)
            {
                if (objectModifStatNb > 0)
                { /* Data to process */
                    DBA_OPTI_STP optiPtr = (DBA_OPTI_STP)NULL;

                    /* Flush local cache - DDV - 140312 */
                    if (threadStateCycle.isRunning() && OPTISCPT_MODE() == TRUE)
                    {
                        SERV_GetOptiPtr(NULL, &optiPtr);
                        if (optiPtr != NULL)
                            DBA_SetNullOpti(optiPtr);

                        DBA_VerifOptiTab(&dbiConnectionHelper); /* PMSTA-19954 - DDV - 150219 - Flush global cache if entities has changed */
                    }

                    for (int objectModifStatIdx = 0; objectModifStatIdx < objectModifStatNb  && threadStateCycle.isRunning(); objectModifStatIdx++)
                    {
                        /* Reload data dependency data ? */
                        if (  dataDependencyDictId == GET_DICT(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_ImpactedEntityDictId)
                            || dataDependencyDictId == GET_DICT(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_UpdatedEntityDictId))
                        { /* Yes */

                            DataDep::getInstance().clear();
                            DataDep::getInstance().load(hierHead, dbiConnectionHelper);
                            break;
                        }
                    }

                    /* Browse all data loaded */
                    for (int objectModifStatIdx = 0; objectModifStatIdx < objectModifStatNb && threadStateCycle.isRunning(); objectModifStatIdx++)
                    {
                        DICT_T                    impactedDictId = GET_DICT(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_ImpactedEntityDictId);
                        OBJMODIFSTAT_ACTION_ENUM  action = (OBJMODIFSTAT_ACTION_ENUM) GET_ENUM(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_ActionEn);
                        ID_T                      updatedObjectBEId = NO_VALUE;

                        if (GEN_IsMultiEntity())
                        {
                            SYS_SetThreadCurrBusinessEntity(SYS_GetApplSessBusEntCdByDyn(objectModifStatTab[objectModifStatIdx],objModifStatOwnerBeFldIdx));
                        }

                        /* Insert the "event" into memory */
                        SERV_AddNewEvent(Delete, ObjectModifStat, objectModifStatTab[objectModifStatIdx], eventMapByBE, mp); /* PMSTA-29792 - DDV - 180111 - remove ret code check */

                        /* Avoid infinite loop of an objectModifStat that impact an objectModifStat */
                        if (impactedDictId != objectModifStatDictId)
                        {
                            std::set <DataDepDefinition *> dataDepDefSet = DataDep::getInstance().getDefinitionSet(impactedDictId, action);

                            for (auto itDataDep = dataDepDefSet.begin();  itDataDep != dataDepDefSet.end() && threadStateCycle.isRunning(); ++itDataDep)
                            {
                                DataDepDefinition *dataDepDef = *itDataDep;
                                DBA_DYNFLD_STP    dataDependencyStp = dataDepDef->getDataDepRec();

                                if (GEN_IsMultiEntity() && dataDepDef->bUpdateObjOnBE() &&
                                    updatedObjectBEId == NO_VALUE && objModifStatOwnerBeFldIdx != Null_Dynfld)
                                {
                                    /* check object's owner_business_entity_id, update updatedObjectBEI to insert event only this BE */
                                    if (GET_ID(objectModifStatTab[objectModifStatIdx], objModifStatOwnerBeFldIdx) != EV_MasterBusinessEntityId)
                                        updatedObjectBEId = GET_ID(objectModifStatTab[objectModifStatIdx], objModifStatOwnerBeFldIdx);
                                }

                                /* PMSTA15858 - DDV - 130211 - Exeception to avoid too many upate when ext_order is inserted.
                                    When ext_order generate an oject_modif on an other entity, the depency is desactivate if rank_n is equal to 9999
                                    It is a temporary solution that will be removed later and replaced by scripting to allow dependency activation */
                                if (GET_DICT(objectModifStatTab[objectModifStatIdx], A_ObjectModifStat_UpdatedEntityDictId) == extOrderDictId &&
                                    GET_SMALLINT(dataDependencyStp, A_DataDependency_Rank) == (SMALLINT_T)9999)
                                    continue;

                                auto &applSessionMap = SYS_GetThreadApplSessionMap();
                                auto itSession = applSessionMap.begin();

                                do
                                {
                                    if (GEN_IsMultiEntity())
                                    {
                                        ID_T            businessEntityId;
                                        char           *businessEntityCd;

                                        businessEntityId = GET_ID(itSession->second, A_ApplSession_ConnectedBusEntityId);
                                        businessEntityCd = GET_CODE(itSession->second, A_ApplSession_ConnectedBusEntityCd);

                                        if (dataDepOwnerBEFldIdx != Null_Dynfld &&
                                            GET_DICT(dataDepDef->getDataDepRec(), dataDepOwnerBEFldIdx) != EV_MasterBusinessEntityId &&
                                            GET_DICT(dataDepDef->getDataDepRec(), dataDepOwnerBEFldIdx) != businessEntityId)
                                        {
                                            continue;
                                        }

                                        if (businessEntityId == EV_MasterBusinessEntityId)
                                        {
                                            if (!dataDepDef->bInsertInMaster() ||
                                                updatedObjectBEId != NO_VALUE)
                                                continue;
                                        }
                                        else
                                        {
                                            if (!dataDepDef->bInsertInAllBE())
                                                continue;

                                            if (updatedObjectBEId != NO_VALUE &&
                                                businessEntityId != updatedObjectBEId)
                                                continue;

                                        }

                                        SYS_SetThreadCurrBusinessEntity(businessEntityCd);
                                    }

                                    DBA_ProcessDataDepOnCurrentBE(hierHead, dataDepDef, objectModifStatTab[objectModifStatIdx], eventMapByBE, threadStateCycle, mp); /* PMSTA-29792 - DDV - 180111 - remove ret code check */

                                } while (++itSession != applSessionMap.end() && threadStateCycle.isRunning());
                            } /* End for */
                        } /* End if */
                    } /* End for */


                    /* Processing of events stored in memory */
                    DBA_InsertAllNewEvents(dbiConnectionHelper,eventMapByBE, threadStateCycle); /* PMSTA-29792 - DDV - 180111 - remove ret code check */
                    /* Purging objectModifStat */
                    DBA_DeleteObjectModifStat(dbiConnectionHelper, eventMapByBE, threadStateCycle); /* PMSTA-29792 - DDV - 180111 - remove ret code check */
                    DBA_FreeEventMapAndRecords(eventMapByBE);
                    /* FREE(objectModifStatTab); now handled in memorypool destructor */                    

                    if (dbMaxDbRead > objectModifStatNb)
                    {
                        DBA_FreeHierAllEltRecord(hierHead);
                        /* Wait a moment */
                        if(isTrace()) traceLogSrvMesg("Exit data dependency treatment");

                        while (threadStateCycle.isRunning() && elapsed < dbReadInterval)
                        {
                            SYS_MilliSleep(200);
                            elapsed += 200;
                        }

                        if (threadStateCycle.isRunning())
                            elapsed = 0;
                    }
                }
                else
                {   /* No data. Wait a moment */
               	    if(isTrace()) traceLogSrvMesg("Exit data dependency treatment");

                    while (threadStateCycle.isRunning() && elapsed < dbReadInterval)
                    {
                        SYS_MilliSleep(200);
                        elapsed += 200;
                    }

                    if (threadStateCycle.isRunning())
                        elapsed = 0;
                }
            }
        } /* End if */

        if (ret != RET_SUCCEED) /* DLA - SUPPORT-7418 - 170208 */
        {   /* unlock records */
            DBA_UnlockObjectModifStat(dbiConnectionHelper);
            dbiConnectionHelper.setOnError(true);
        }
    } /* End while */

    /* unlock records */
    DbiConnectionHelper endConnHelper;
    DBA_UnlockObjectModifStat(endConnHelper);
    DataDep::getInstance().clear();
    DBA_FreeHier(hierHead);
    SCPT_FreeScriptDV(NullEntity);

    if (threadStateCycle.isFatal())
    { /* Error */
        MSG_SendMesg(FILEINFO, "Thread data dependency terminated because of a fatal error" );
    }
}


/************************************************************************
*   Function        :   SERV_StartThreadDataDep
*
*   Description     :   Start the data dependency thread
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
void SERV_StartThreadDataDep(std::string & srvInfo)
{    
    if(nullptr != SYS_GetEnv("AAANODATADEP"))
    {
        static bool isLogged = false;
        if(isLogged == false) MSG_LogSrvMesg(UNUSED, UNUSED, "Environment variable AAANODATADEP exists. Data Dependency Thread will not process records in object_modif_stat.");
        isLogged = true;
        return;
    }

    LockGuard lock(SV_ThreadDataDepLock);

    serverInfo = srvInfo;
    if(isTrace()) {
        traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;LockGuard Enabled"));
        traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;SV_ThreadDataDepTID [",&SV_ThreadDataDepTID,"] tid=", SV_ThreadDataDepTID.load()));
        traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;SV_ThreadDataDepLoop [",&SV_ThreadDataDepLoop,"] = ",static_cast<int>(SV_ThreadDataDepLoop.load())));
    }

    TID_T expectedTreadId = 0;
    if (SV_ThreadDataDepTID.compare_exchange_strong(expectedTreadId, 0))
    {
         const ThreadState threadState = SV_ThreadDataDepLoop.load();
        if(isTrace()) {
            traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;Starting Data Dep Thread..."));
            traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;SV_ThreadDataDepLoop [",&SV_ThreadDataDepLoop,"] = ",static_cast<int>(threadState)));
        }

        if (threadState == ThreadState::Initialization || threadState == ThreadState::Stopped)
        {
            TID_T startedThreadId = SYS_SpawnAdministrativeThread(SERV_ThreadDataDep, nullptr, SYS_Stringer("Data Dependency ", srvInfo).c_str());   /* PMSTA-19735 - 020415 - PMO */

            if (SV_ThreadDataDepTID.compare_exchange_strong(expectedTreadId, startedThreadId) == false)
            {   /* Error */
                MSG_SendMesg(FILEINFO, SYS_Stringer("Start of the Data Dependency thread [ThreadState = ", static_cast<int>(threadState), "] failed for [", srvInfo, "]"));
                SV_ThreadDataDepTID.store(0);
                if (isTrace()) {
                    traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;Data Dep Start Failed SV_ThreadDataDepLoop [", &SV_ThreadDataDepLoop, "] = ", static_cast<int>(threadState)));
                }

                if (isTrace()) {
                    traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;Data Dep Start Success SV_ThreadDataDepLoop [", &SV_ThreadDataDepLoop, "] = ", static_cast<int>(threadState)));
                }
            }
        }
    }
    else if(isTrace())
    {
        traceLogSrvMesg(SYS_Stringer("SERV_StartThreadDataDep;Thread already started..."));
    }
}

/************************************************************************
*   Function        :   SERV_StopThreadDataDep()
*
*   Description     :   Stop the data dependency thread
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
*
*   Last Modif.     :   PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*                       PMSTA-30720 - 220418 - PMO : After Server shutdown request, several Invalid Application Session are reported
*
*************************************************************************/
void SERV_StopThreadDataDep(void)
{
    LockGuard lock(SV_ThreadDataDepLock);
    if(isTrace()) {
        traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;LockGuard Enabled"));
        traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;SV_ThreadDataDepTID [",&SV_ThreadDataDepTID,"] tid= ", SV_ThreadDataDepTID.load()));
        traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;SV_ThreadDataDepLoop [",&SV_ThreadDataDepLoop,"] = ",static_cast<int>(SV_ThreadDataDepLoop.load())));
    }

    /* PMSTA-29083 - 041217 - PMO */
    if (ThreadState::Running == SV_ThreadDataDepLoop.load())
    {   /* The thread is running */
        if(isTrace())
        {
            traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;Set Thread State to Leaving..."));
        }
        SV_ThreadDataDepLoop.store(ThreadState::Leaving);   /* PMSTA-29083 - 041217 - PMO */
    }
    TID_T currentTread= OS_GetTid();
    if ( SV_ThreadDataDepTID.compare_exchange_strong(currentTread, 0) )
    {
        if (isTrace())
        {
            traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;Stopped requested by itself thread..."));
        }

        SV_ThreadDataDepLoop.store(ThreadState::Stopped);
    }


    /* PMSTA-30720 - 220418 - PMO */
    if (ThreadState::Initialization == SV_ThreadDataDepLoop.load())
    { /* The thread was not started */
        if(isTrace())
        {
            traceLogSrvMesg(SYS_Stringer("SERV_StopThreadDataDep;Set Thread State to Stopped..."));
        }
        SV_ThreadDataDepLoop.store(ThreadState::Stopped);
    }

    while ( ThreadState::Stopped != SV_ThreadDataDepLoop.load() 
        && ThreadState::Fatal != SV_ThreadDataDepLoop.load())
    {
        SYS_MilliSleep(50);
    }
    SV_ThreadDataDepTID.store(0);
}

/************************************************************************
*   Function        :   SERV_IsThreadDataDepRunning
*
*   Description     :   Checks if data dep is running
*
*   Arguments       :   None
*
*   Return          :   true if data dep running
*
*   Creation Date   :  PMSTA-35990 - JBC - 160605
*
*   Last Modif.     :
*
*************************************************************************/
bool SERV_IsThreadDataDepRunning()
{
     LockGuard lock(SV_ThreadDataDepLock);

     return ThreadState::Running == SV_ThreadDataDepLoop.load();
}

/************************************************************************
*   Function        :   SERV_ThreadSessionPurge
*
*   Description     :   The Session Purge thread
*
*   Arguments       :   None
*
*   Return          :   NULL
*
*   Creation Date   :   PMSTA-22552 - CHU - 160617
*
*   Last Modif.     :   PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*
*************************************************************************/
void SERV_ThreadSessionPurge(ThreadArg *)
{
    ThreadStateCycle            threadStateCycle(SV_ThreadSessionPurgeLoop);    /* PMSTA-29083 - 041217 - PMO                   */
    unsigned                    dbReadInterval;                                 /* The default is 5 seconds                     */
    unsigned                    elapsed             = 0;                        /* Elapsed since last read (200ms resolution)   */
    INT_T                       dbInt               = 0;                        /* Time interval between purges (in seconds)    */

                                                                                /* The thread is started                        */
    SERV_WaitForRpcRegistered();                                                /* PMSTA-23902 - 290616 - PMO                   */
    SYS_GetThreadStackLeft();                                                   /* PMSTA-23902 - 290616 - PMO                   */
    SYS_SetThreadMayLoop(true);                                                 /* PMSTA-23902 - 290616 - PMO                   */

    threadStateCycle.setRunning();

    /* System parameter */
    /* Interval between two purges */
    (void)GEN_GetApplInfo(ApplSessionPurgeDbCheckInterval, &dbInt);
    if(dbInt <= 0)
    {
        dbInt = 5;
    }
    dbReadInterval = (unsigned)dbInt * 1000;

    /*
     * Database connection
     */
    DbiConnectionHelper         dbiConnectionHelper;        /* PMSTA-22990 - 080416 - PMO */

    if (!dbiConnectionHelper.isValidAndInit())
    {
        MSG_SendMesg(FILEINFO, "Unable to get a connection");

        threadStateCycle.setFatal();   /* Fatal error */
    }

    /* PMSTA-41113 - KNI - 310820 */
    MemoryPool mp;
    DBA_DYNFLD_STP inpArg = nullptr;

    if ((inpArg = mp.allocDynst(FILEINFO, Get_Arg)) == nullptr)
        MSG_SendMesg((RET_MEM_ERR_ALLOC), 0, FILEINFO);
    
    SET_NULL_ID(inpArg, Get_Arg_Id);
    if (SERVER_MODE())
    {
        SET_ID(inpArg, Get_Arg_Id, EV_CurrentSrvConfig.getBusEntityId());
    }
    /* PMSTA-41113 - KNI - 310820 */
    
    /* Main loop */
    while (threadStateCycle.isRunning())
    {
        /* Call purge stored procedure */
        if (dbiConnectionHelper.dbaDelete(ApplSession, UNUSED, inpArg) != RET_SUCCEED) //PMSTA-41113 - KNI - 310820
        { /* Error */
            threadStateCycle.setFatal();   /* Fatal error */
        }
        else
        {   /* purge ran fine, wait a while */
            while (threadStateCycle.isRunning() && elapsed < dbReadInterval)
            {
                SYS_MilliSleep(200);
                elapsed += 200;
            }

            if (threadStateCycle.isRunning())
                elapsed = 0;
        }
    } /* End while */

    if (threadStateCycle.isFatal())
    {   /* Error */
        MSG_SendMesg(FILEINFO, "Thread Session Purge terminated because of a fatal error");
    }
}

/************************************************************************
*   Function        :   SERV_StartThreadSessionPurge
*
*   Description     :   Start the Session Purge thread
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-22552 - CHU - 160617
*
*   Last Modif.     :   PMSTA-23902 - 290616 - PMO : Merge TA/11.0.0 with TA/20.1.0 in TA/21.0.0
*
*************************************************************************/
void SERV_StartThreadSessionPurge(std::string & srvInfo)
{
    if(nullptr != SYS_GetEnv("AAANOSESSIONPURGE"))
    {
        static bool isLogged = false;
        if(isLogged == false) MSG_LogSrvMesg(UNUSED, UNUSED, "Environment variable AAANOSESSIONPURGE exists. Purge of appl_session will not run.");
        isLogged = true;
        return;
    }
    
    LockGuard lock(SV_ThreadSessionPurgeLock);
    TID_T expectedTreadId = 0;
    if (SV_ThreadSessionPurgeTID.compare_exchange_strong(expectedTreadId, 0))
    {
        const ThreadState threadState = SV_ThreadSessionPurgeLoop.load();

        if (threadState == ThreadState::Initialization || threadState == ThreadState::Stopped)
        {
            TID_T startedThreadId = SYS_SpawnAdministrativeThread(SERV_ThreadSessionPurge, nullptr, SYS_Stringer("Session Purge ",srvInfo).c_str());           /* PMSTA-23902 - 290616 - PMO */

            if (SV_ThreadSessionPurgeTID.compare_exchange_strong(expectedTreadId, startedThreadId) == false)
            { /* Error */
                MSG_SendMesg(FILEINFO, SYS_Stringer("Start of the Session Purge thread [ThreadState = ", static_cast<int>(threadState), "] failed for ]", srvInfo, "]"));
                SV_ThreadSessionPurgeTID.store(0);
            }
        }
    }
}

/************************************************************************
*   Function        :   SERV_StopThreadSessionPurge
*
*   Description     :   Stop the Session Purge thread
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-22552 - CHU - 160617
*
*   Last Modif.     :   PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*                       PMSTA-30720 - 220418 - PMO : After Server shutdown request, several Invalid Application Session are reported
*
*************************************************************************/
void SERV_StopThreadSessionPurge(void)
{
     LockGuard lock(SV_ThreadSessionPurgeLock);

    /* PMSTA-29083 - 041217 - PMO */
    if (ThreadState::Running == SV_ThreadSessionPurgeLoop.load())
    { /* The thread is running */
        SV_ThreadSessionPurgeLoop.store(ThreadState::Leaving);      /* PMSTA-29083 - 041217 - PMO */
    }
    TID_T currentTread = OS_GetTid();
    if (SV_ThreadSessionPurgeTID.compare_exchange_strong(currentTread, 0))
    {
       // Stopped requested by itself thread
        SV_ThreadSessionPurgeLoop.store(ThreadState::Stopped);
    }

    /* PMSTA-30720 - 220418 - PMO */
    if (ThreadState::Initialization == SV_ThreadSessionPurgeLoop.load())
    { /* The thread was not started */
        SV_ThreadSessionPurgeLoop.store(ThreadState::Stopped);
    }
        
    while (ThreadState::Stopped != SV_ThreadSessionPurgeLoop.load() &&
           ThreadState::Fatal   != SV_ThreadSessionPurgeLoop.load())
    {
        SYS_MilliSleep(50);
    }
    SV_ThreadSessionPurgeTID.store(0);
}


/************************************************************************
*   Function        :   SERV_RpcShutdownWaitThreadDataDepSessionPurge
*
*   Description     :   Threads using session code must be finished before deleting sessions
*
*   Arguments       :   None
*
*   Return          :   None
*
*   Creation Date   :   PMSTA-30720 - 220418 - PMO : After Server shutdown request, several Invalid Application Session are reported
*
*   Last Modif.     :
*
*************************************************************************/
void SERV_RpcShutdownWaitThreadDataDepSessionPurge()
{
    if (ThreadState::Initialization != SV_ThreadSessionPurgeLoop.load() && ThreadState::Initialization != SV_ThreadDataDepLoop.load())
    {
        for(int loop = 0;
            loop < 200 && ThreadState::Stopped != SV_ThreadSessionPurgeLoop.load() && ThreadState::Stopped != SV_ThreadDataDepLoop.load();
            loop++)
        {
            SYS_MilliSleep(50);
        }
    }
}

ThreadState GET_ThreadSessionPurgeLoopState(void)
{
    return SV_ThreadSessionPurgeLoop.load();
}

ThreadState GET_ThreadDataDepLoopState(void)
{
    return SV_ThreadDataDepLoop.load();
}

/************************************************************************
 **   END  datadep.c                                          ODYSSEY **
 *************************************************************************/

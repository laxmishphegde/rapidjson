/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FININSTR_C

/************************************************************************
**      Include files
*************************************************************************/
#include <numeric>
#include <string>
#include <cmath>

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "hier.h"
#include "fin.h"
#include "scelib.h"
#include "fmtlib01.h"
#include "ddlgendbi.h"

#include "scpt.h"
#include "scptyl.h"

using namespace std;

/************************************************************************
**      External entry points
**
**  FIN_CreateDiscountInstr()	Create temporary discount instrument.
**  FIN_GenericInstrCompo()	    Generate an InstrCompo array.
**  FIN_GetHierInstr()		    Get instrument (use received id), search in hier, then read db.
**  FIN_InstrCategory()		    Return the category of an instr. depending of its underlying instr.
**  FIN_InstrGetNatureLeg()	    Get the nature of an instrument leg.
**  FIN_SplitInstrument()	    Split the instrument.
**  FIN_SwapLegInstr()		    Generate son Instrument records for swap.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**  FIN_AddLegsIntoHier()	        Add the legs into the hierarchy.
**  FIN_AllocMemoryInstrCompo()	    Set the memory allocation for the InstrCompo array.
**  FIN_ComputeQtyForInstrCompo()   Compute quantity for created A_InstrCompo (each leg).
**  FIN_ComputeQtyForLeg1BondForwards()
**  FIN_ComputeQtyForLeg2BondForwards()
**  FIN_ComputeQtyForLeg1BondFutures()
**  FIN_ComputeQtyForLeg2BondFutures()
**  FIN_ComputeQtyForLeg1Currency()
**  FIN_ComputeQtyForLeg2Currency()
**  FIN_ComputeQtyForLeg1Equity()
**  FIN_ComputeQtyForLeg2Equity()
**  FIN_ComputeQtyForLeg1SwapAndForexSwap()
**  FIN_ComputeQtyForLeg2SwapAndForexSwap()
**
**  FIN_CreateInstrLeg()	        Create a leg from the original instrument.
**  FIN_FilterDiscount()	        Verify if discount instr. are already in hierarchy.
**  FIN_FilterInstrLegs()	        Verify if instr legs are already in hierarchy.
**  FIN_GenInstrCompo()		        Fill the instrCompo array with the legs values.
**  FIN_GetAccrualRuleFromYieldCurveInstr() Get the accrual rule from the yield curve instr.
**  FIN_GetCTDInstrument()	        Get the CTD instrument from the daabase.
**  FIN_CpyCurrIdUnderlyInstrInfo()	Copy underlying instrument information in new leg.
**  FIN_GetInstrCategory()	        Get the category of an instr. depending of its underlying instr.
**  FIN_GetRiskCountryIdFromUnderlyInstr() Get the risk country id from the underlying instr.
**  FIN_GetRiskCurrIdFromUnderlyInstr()    Get the risk curr. id from the underlying instr.
**  FIN_MakeInstrLeg()		        Make the 2 legs and add them into the hierarchy.
**  FIN_SearchInstrLegInHier()	    Search the legs from the hierarchy.
**  FIN_SetOrderLegs()		        Set the order of the legs.
**  FIN_SetValuesLegs()		        Set values into the newer legs.
**  FIN_SetValuesForDiscountOfBondFutures()
**  FIN_SetValuesForDiscountOfEquity()
**  FIN_SetValuesForDiscountOfCurrencyLeg1()
**  FIN_SetValuesForDiscountOfCurrencyLeg2()
**  FIN_SetValuesForDiscountOfForexSwapPaidLeg()
**  FIN_SetValuesForDiscountOfForexSwapRecLeg()
**  FIN_SetValuesForDiscountOfSwapRecLeg()
**  FIN_SetValuesForDiscountOfSwapPaidLeg()
**  FIN_SetValuesForPaidSwapFloatLeg()
**  FIN_SetValuesForRecSwapFloatLeg()
**  FIN_SetValuesForPaidSwapFixLeg()
**  FIN_SetValuesForRecSwapFixLeg()
**  FIN_TestSwapBriseInterCond()
**  FIN_SetValuesForSwapBriseLegs()
**
*************************************************************************/
typedef struct
{
    OBJECT_ENUM         ruleObjEn;
    OBJECT_ENUM         ruleCompoObjEn;
    OBJECT_ENUM         destObjEn;
    FIELD_IDX_T         ruleCompoRuleIdFldIdx;
    FIELD_IDX_T         destFullTableNameFldIdx;
    FIELD_IDX_T         ptfByPtfFlgFldIdx;
	HIER_CMPFCT        *ruleCmpFct;
	HIER_CMPFCT        *ruleCompoCmpFct;
} IRL_RULEDEF_ST, *IRL_RULEDEF_STP;

/************************************************************************
**      Static definitions & data
*************************************************************************/
#define FWD_CASH_LEG 0

STATIC RET_CODE FIN_AddLegsIntoHier(DBA_DYNFLD_STP, FLAG_T, DBA_DYNFLD_STP, FLAG_T,
                            DBA_HIER_HEAD_STP, INSTRCATEGORY_ENUM),
		    FIN_AllocMemoryInstrCompo(DBA_DYNFLD_STP **, int),
        	FIN_CreateInstrLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP *),
        	FIN_GenInstrCompo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
                          	  DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T,
                          	  INSTRCATEGORY_ENUM, STNSPECTREATMENT_ENUM, DBA_DYNFLD_STP **), /* REF7475 - YST - 020516 */
        	FIN_GetCTDInstrument(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                             DBA_DYNFLD_STP, DBA_DYNFLD_STP *, NUMBER_T *),
        	/*FIN_CreateConvBondInstrLeg1FixIncom(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,  REF5049 - AKO - 001204
                             DBA_DYNFLD_STP, DBA_DYNFLD_STP*),*/
            FIN_CreateConvBondInstrLeg2AsOption(DBA_DYNFLD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP,
                                            DBA_DYNFLD_STP,DBA_DYNFLD_STP*),
            FIN_GetDeltaInstrument(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                             DBA_DYNFLD_STP, DBA_DYNFLD_STP *, NUMBER_T *, FLAG_T*),    /*  FPL-PMSTA09803-100510   */
            FIN_MakeInstrLeg(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
                         DBA_DYNFLD_STP *, DBA_DYNFLD_STP *, NUMBER_T *),
        	FIN_SetValuesLegs(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, INSTRCATEGORY_ENUM,
                          DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        	FIN_SetValuesForDiscountOfBondFutures(  DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                                DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        	FIN_SetValuesForDiscountOfEquity(   DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                            DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        	FIN_SetValuesForDiscountOfCurrencyLeg1( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                                DBA_DYNFLD_STP, DBA_DYNFLD_STP),
        	FIN_SetValuesForDiscountOfCurrencyLeg2( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                                DBA_DYNFLD_STP, DBA_DYNFLD_STP),
			FIN_SetValuesForFwdCashLeg2( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                                DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		    FIN_SetValuesForDiscountOfForexSwapPaidLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* REF7475 - YST - 020516 */
		    FIN_SetValuesForDiscountOfForexSwapRecLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP),/* REF7475 - YST - 020516 */
		    FIN_SetValuesForDiscountOfSwapPaidLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* REF7475 - YST - 020516 */
		    FIN_SetValuesForDiscountOfSwapRecLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* REF7475 - YST - 020516 */
            FIN_SetValuesForPaidSwapFloatLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP),/* REF7475 - YST - 020516 */
            FIN_SetValuesForRecSwapFloatLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP),/* REF7475 - YST - 020516 */
            FIN_SetValuesForPaidSwapFixLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP),/* REF7475 - YST - 020516 */
            FIN_SetValuesForRecSwapFixLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP),/* REF7475 - YST - 020516 */
            FIN_ComputeDeltaForOption( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T *),
            FIN_SetValuesForDiscountOfOptionLeg( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP),
            FIN_SetValuesForFixedIncOfOptionLeg( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP), /* REFi - RAK - 010216 */
            FIN_ComputeDeltaFactorWithAA_BS_OPT( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T *),
            FIN_ComputeDeltaFactorWithAA_CRR_OPT( DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T *),
            FIN_GetDefaultMarginForOptions(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T *),/* REF5049 - AKO - 001106 */ /* REF7475 - YST - 020516 */
            FIN_ComputeDeltaFactorWithAA_CRR_CONVBOND(DBA_DYNFLD_STP,DBA_HIER_HEAD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP,NUMBER_T*),
            FIN_SetValuesForConvertibleBondLeg(DBA_DYNFLD_STP,DBA_HIER_HEAD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP),
            FIN_SetValuesForConvertibleBondLeg2(DBA_DYNFLD_STP), /* REF7475 - YST - 020516 */
			FIN_CreateACDCCashInstrLeg(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, FLAG_T*, DBA_HIER_HEAD_STP);

STATIC int 	FIN_FilterInstrLegs(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int	FIN_FilterDiscount(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC INSTRCATEGORY_ENUM   FIN_GetInstrCategory(   ENUM_T, ENUM_T);
STATIC ENUM_T               FIN_GetAccrualRuleFromYieldCurveInstr(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_CpyCurrIdUnderlyInstrInfo(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC ID_T FIN_GetRiskCurrIdFromUnderlyInstr(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC ID_T FIN_GetRiskCountryIdFromUnderlyInstr(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC NUMBER_T FIN_ComputeQtyForLeg1BondFutures(DBA_DYNFLD_STP, NUMBER_T);/* REF7475 - YST - 020516 */ /* PMSTA01812-CHU-070402 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2BondFutures(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, NUMBER_T, DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1BondForwards(DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2BondForwards(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1Equity(DBA_DYNFLD_STP); /* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2Equity(DBA_DYNFLD_STP); /* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1Currency(DBA_DYNFLD_STP); /* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2Currency(DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1SwapAndForexSwap(DBA_DYNFLD_STP, DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2SwapAndForexSwap(DBA_DYNFLD_STP, DBA_DYNFLD_STP);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1Options(DBA_DYNFLD_STP, NUMBER_T);/* REF7475 - YST - 020516 */ /* PMSTA15709 - DDV - 130301 - add new parameter instrument */
STATIC NUMBER_T FIN_ComputeQtyForLeg2Options(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, NUMBER_T);/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg1OptionsConvertBond(DBA_DYNFLD_STP); /* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_ComputeQtyForLeg2OptionsConvertBond();/* REF7475 - YST - 020516 */
/* REF5049 - AKO - 001106 */
STATIC NUMBER_T FIN_COmputeQtyForLeg1ConvertibleBond();/* REF7475 - YST - 020516 */
STATIC NUMBER_T FIN_COmputeQtyForLeg2ConvertibleBond(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP); /* REF7475 - YST - 020516 */
STATIC LEGNAT_ENUM FIN_InstrGetNatureLegFromInstrCategory(INSTRCATEGORY_ENUM);
/* REF5149 - YST - 011218 changed 020508*/
STATIC RET_CODE FIN_TestSwapBriseInterCond(DBA_DYNFLD_STP*, int, DATE_T*, DATE_T*, ID_T*);
STATIC RET_CODE FIN_SetValuesForSwapBriseLegs(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, INTERCONDNAT_ENUM, INTERCONDNAT_ENUM,
                                              DATE_T, DATE_T, DATE_T, DATE_T, ID_T, ID_T);

STATIC RET_CODE FIN_GetDestFullTableName(OBJECT_ENUM, std::string &, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_StoreIRLByRuleDef(IRL_RULEDEF_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_StoreIRLByRuleCompo(char *, DBA_DYNFLD_STP, FIELD_IDX_T, bool, OBJECT_ENUM, DBA_DYNFLD_STP);
STATIC RET_CODE FIN_TranferDataIntoFinalTable(IRL_RULEDEF_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);

STATIC int FIN_CmpIrlInstrumentRuleRank(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int FIN_CmpIrlInstrumentRuleCompoLevel(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int FIN_CmpIrlPortfolioRuleRank(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int FIN_CmpIrlPortfolioRuleCompoLevel(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int FIN_CmpIrlApplUserRuleRank(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int FIN_CmpIrlApplUserRuleCompoLevel(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);



STATIC RET_CODE FIN_CreateInstrCompo(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnectionHelper&);     /* PMSTA-34686 - DDV - 190220 */
STATIC RET_CODE FIN_CreateNewInstrByNatureCateg(DBA_DYNFLD_STP, DBA_DYNFLD_STP, INSTRNAT_ENUM, INSTR_CATEG_ENUM,
                                                FLAG_T, FLAG_T, FLAG_T, DBA_HIER_HEAD_STP, DbiConnectionHelper&);                  /* PMSTA-34686 - DDV - 190220 */
STATIC RET_CODE FIN_CreateInstrPrice(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnectionHelper&);                     /* PMSTA-34686 - DDV - 190220 */
STATIC RET_CODE FIN_CreateInterCond(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnectionHelper&);                      /* PMSTA-34686 - DDV - 190220 */
STATIC RET_CODE FIN_CreateTermEvent(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DbiConnectionHelper&);                      /* PMSTA-34686 - DDV - 190220 */
STATIC RET_CODE FIN_CreateStructuredNotesFromTemplate(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);                          /* PMSTA-34378 - DDV - 190131 */

STATIC RET_CODE FIN_CreateStructuredProductFromTemplate(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,  DBA_HIER_HEAD_STP);                        /* PMSTA-34686 - DDV - 190219 */

extern RET_CODE DBA_LoadVectorIdByDomain(DBA_DYNFLD_STP,  DbiConnectionHelper&);                /* PMSTA-28705 - DDV - 180524 */
extern RET_CODE DBA_LoadVectorId(OBJECT_ENUM, OBJECT_ENUM, ID_T, char *, DbiConnectionHelper&); /* PMSTA-28705 - DDV - 180216 */

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    :   FIN_GetHierInstr()
**
**  Description :   Get instrument (use received identifier), first search in
**                  hierarchy, then read database.
**
**  Arguments   :   posHierHead    hierarchy pointer
**                  instrId        instrument identifier to find
**                  hierFlg        flag which will be TRUE if instrument is
**                                 already in hierarchy, FALSE if it is read in database
**                  instrPtr       instr structure pointer which will point on founded instr
**
**  Return      :   NULLDYNST or pointer on instrument
**
**  Modif       :   BUG086 - RAK - 960805
**                  DVP455 - RAK - 970505
**                  REF3913 - DDV - Call DBA_GetInstrById - 991004
**                  REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE FIN_GetHierInstr(PTR            posHierHeadPtr,
                          ID_T           instrId,
                          char           *hierFlg,
                          DBA_DYNFLD_STP *instrPtr)
{
    DBA_HIER_HEAD_STP posHierHead = (DBA_HIER_HEAD_STP) posHierHeadPtr; /* BUG086 / REF7264 - PMO */
    RET_CODE          retCode = RET_SUCCEED;
    FLAG_T            allocFlg = FALSE;

    retCode = DBA_GetInstrById(instrId, FALSE, &allocFlg,
                               instrPtr, posHierHead, UNUSED, UNUSED);

    *hierFlg = (char) !allocFlg;

    return(retCode);

}

/************************************************************************
**
**  Function    :   FIN_IsFutOptionFlg()
**
**  Description :   Test new "race" of future !
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED,  or error code
**
**  Creation    :   REF5300 - RAK - 010405
**
*************************************************************************/
RET_CODE FIN_IsFutOptionFlg(DBA_DYNFLD_STP  instrPtr,
                            DBA_HIER_HEAD_STP hierHead,
                            FLAG_T          *isFutOptionFlg)
{
    DBA_DYNFLD_STP  parInstrPtr=NULLDYNST;
    FLAG_T          allocFlg=FALSE;
    RET_CODE        ret=RET_SUCCEED;

    *isFutOptionFlg = FALSE;

    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Future)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_ParentInstrId) == FALSE)
        {
            if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_ParentInstrId),
                                        TRUE, &allocFlg, &parInstrPtr, hierHead,
                                        UNUSED, UNUSED)) == RET_SUCCEED)
            {
                if (GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_Option)
                    *isFutOptionFlg = TRUE;
            }
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_IsOptConvertBondFlg()
**
**  Description :   Test new "race" of option !
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED,  or error code
**
**  Creation    :   REF5049 - RAK - 010216
**
*************************************************************************/
RET_CODE FIN_IsOptConvertBondFlg(DBA_DYNFLD_STP  instrPtr,
                                 DBA_HIER_HEAD_STP hierHead,
                                 FLAG_T          *isOptConvertBondFlg)
{
    DBA_DYNFLD_STP  parInstrPtr=NULLDYNST;
    FLAG_T          allocFlg=FALSE;
    RET_CODE        ret=RET_SUCCEED;

    *isOptConvertBondFlg = FALSE;

    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Option)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_ParentInstrId) == FALSE)
        {
            if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_ParentInstrId),
                                        TRUE, &allocFlg, &parInstrPtr, hierHead,
                                        UNUSED, UNUSED)) == RET_SUCCEED)
            {
                if (GET_ENUM(parInstrPtr, A_Instr_NatEn) == InstrNat_ConvertBond)
                    *isOptConvertBondFlg = TRUE;
            }
        }
    }

    return(ret);
}

/************************************************************************
*
*  Function    : FIN_SwapLegInstr()
*
*  Description : Generate son Instrument records for swap
*
*
*  Arguments   : instrPtr     : parent instrument
*                posHierHead  : hierarchy
*                instrNbr     : number of Instrgenerate
*                instrTab     : array of Instr
*		 freeLegFlg   : will be TRUE if instruments pointer need to be freed, FALSE elsewhere
*
*  Return      : RET_SUCCEED or retcode
*
*  Creation D. : DVP510 - 970623 - XDI
*  Last modif. : BUG423 - 970708 - GRD
*                BUG434 - 970714 - GRD
*                REF1485 - 980324 - RAK
*		         REF1055 - Use new tools (and always add instrument in hier if exist ...)
*                REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
*                REF5926 - YST - 020306 - code reporting
*                REF7782 - YST - 020904
*
*************************************************************************/
RET_CODE FIN_SwapLegInstr(DBA_DYNFLD_STP    instrPtr,
                          DBA_HIER_HEAD_STP posHierHead,
                          DATETIME_T        valDateTime,
			              DBA_DYNFLD_STP    **instrTab,
                          int               *instrNbr,
			              FLAG_T	        *freeLegFlg)
{
    DBA_DYNFLD_STP  instrFloatPtr=NULLDYNST, instrFixPtr=NULLDYNST, getInstrPtr=NULLDYNST;
    int             i,j;
    ID_T            instrId;
    RET_CODE        ret = RET_SUCCEED;
    FLAG_T          allocFlg, foundFlg=FALSE;

    DBA_DYNFLD_STP  *compoTab=NULLDYNSTPTR, newInstrPtr=NULLDYNST;
    int	            compoNbr=0;

    *instrNbr = 0;

    if ((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFloatStdSwap &&
	    (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFixStdSwap &&
	    (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FltFltStdSwap &&   /*REF1485*/
        (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFltSwapHedgFix)	/* REF7782 - YST - 020904 */
    {
        if (GET_ID(instrPtr, A_Instr_Id) > 0)
            instrId = GET_ID(instrPtr, A_Instr_Id);
        else
            instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);

        if ((ret = DBA_SelectInstrCompo(instrId, valDateTime,
                                        &compoTab, &compoNbr)) != RET_SUCCEED)
            return(ret);

	    if (compoNbr == 0)
	        return(RET_SUCCEED);

	    /* REF1055 - RAK - 991214 - Search if instrument are already created and stored in hierarchy. */
	    if (posHierHead == NULL)
	    {
	        posHierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
	    }

	    if (posHierHead != NULL)
	    {
	    	/* Extract the legs if they exist */
		    ret =   DBA_ExtractHierEltRecWithFilterSt(posHierHead,
                                                      A_Instr,
                                                      FALSE,
					                                  FIN_FilterInstrLegs,
                                                      instrPtr,
                                                      NULLFCT,
					                                  instrNbr,
                                                      instrTab);
		    if (ret == RET_SUCCEED && *instrNbr == compoNbr)
		        foundFlg = TRUE;
	    }

	    if (foundFlg == FALSE)
	    {
	        if ((*instrTab = (DBA_DYNFLD_STP*) CALLOC(compoNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR) /* REF7264 - PMO */
	        {
                DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo); /* PURIFY - RAK - 000427 */
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        for (i=0; i<compoNbr; i++)
	        {
		        /* REF3913 - 990819 - DDV */
		        if (DBA_GetInstrById(GET_ID(compoTab[i], A_InstrCompo_InstrId), FALSE,
                                     &allocFlg,
				                     &getInstrPtr, posHierHead,
                                     UNUSED, UNUSED) != RET_SUCCEED)
		        {
		            SYSNAME_T entSqlName;
		            for (j=0; j<i; j++)
			            FREE_DYNST((*instrTab)[j], A_Instr);
		            FREE(*instrTab);
		            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
		            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
				                 entSqlName, GET_ID(compoTab[i],A_InstrCompo_InstrId));
                    DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo); /* PURIFY - RAK - 000427 */
		            return(RET_DBA_ERR_NODATA);
		        }

		        if (allocFlg == FALSE)
		        {
		            if ((newInstrPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
		            {
			            for (j=0; j<i; j++)
			                FREE_DYNST((*instrTab)[j], A_Instr);
                        DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo); /* PURIFY - RAK - 000427 */
			            MSG_RETURN(RET_MEM_ERR_ALLOC);
		            }
		            COPY_DYNST(newInstrPtr, getInstrPtr, A_Instr);
		        }
		        else
		            newInstrPtr = getInstrPtr;

		        /* Create a new instrument and add it in hierarchy */
                /* REF5979 - RAK - 010508 */
                SET_ID(newInstrPtr, A_Instr_InterCondInstrId,
                    GET_ID(newInstrPtr, A_Instr_Id));

		        SET_ID(newInstrPtr, A_Instr_ParentInstrId,
		            GET_ID(newInstrPtr, A_Instr_Id));

		        SET_ID(newInstrPtr, A_Instr_LegParInstrId,
		            GET_ID(compoTab[i], A_InstrCompo_InstrId));

		        SET_NULL_ID(newInstrPtr, A_Instr_Id);

		        COPY_DYNFLD(newInstrPtr, A_Instr, A_Instr_CompoQuantity,
			            compoTab[i], A_InstrCompo, A_InstrCompo_Quantity);
		        COPY_DYNFLD(newInstrPtr, A_Instr, A_Instr_CompoRank,
			            compoTab[i], A_InstrCompo, A_InstrCompo_Rank);

                /* REF5937 - YST - 020306 - code reporting from R3.51.x */
                COPY_DYNFLD(newInstrPtr, A_Instr, A_Instr_RefInstrId,
                        compoTab[i], A_InstrCompo, A_InstrCompo_ParentInstrId);

                /* REF6089 - YST - 020228 - Add management of freeLegFlg flag */
                *freeLegFlg = TRUE;

		        if (posHierHead == NULL)
		        {
		            posHierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
		        }

		        if (posHierHead != NULL)
		        {
		            if ((ret = DBA_AddHierRecord(posHierHead, newInstrPtr,
                                                 A_Instr, FALSE,
                                                 HierAddRec_TestMandatLnk)) != RET_SUCCEED)
		            {
			            for (j=0; j<i; j++)
			                FREE_DYNST((*instrTab)[j], A_Instr);
                        DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo); /* PURIFY - RAK - 000427 */
			            MSG_RETURN(RET_MEM_ERR_ALLOC);
		            }
                    *freeLegFlg = FALSE;

                    /* REF5938 - RAK - 010516 - We aren't sure that InterCond of legs are loading */
                    /* at the begin of the process like InterCond of portfolio's instruments      */
                    /* Set field to NULL, so in DBA_SelAllInterCond() we call database and update */
                    /* correctly hierarchy.                                                       */
                    if (IS_NULLFLD(newInstrPtr, A_Instr_Cond_A_Instr_Ext) == FALSE &&
                        GET_EXTENSION_PTR(newInstrPtr, A_Instr_Cond_A_Instr_Ext) == NULLDYNSTPTR &&
                        GET_EXTENSION_NBR(newInstrPtr, A_Instr_Cond_A_Instr_Ext) == 0)
                    {
                        SET_NULL_EXTENSION(newInstrPtr, A_Instr_Cond_A_Instr_Ext);
                    }
		        }

		        (*instrTab)[i] = newInstrPtr;
		        newInstrPtr = NULLDYNST;
	        }
        }

        *instrNbr = compoNbr;		/* BUG423 - 970708 - GRD */
        DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo); /* PURIFY - RAK - 000427 */
    }
    else
    {
        *instrNbr = 2;
        if ((*instrTab = (DBA_DYNFLD_STP*) CALLOC(*instrNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)  /* REF7264 - PMO */
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* create new instruments */
	    /* REF1055 - RAK - 991214 */
        /* if ((ret = FIN_SplitSwap(instrPtr, &instrFloatPtr,
				 &instrFixPtr, posHierHead)) != RET_SUCCEED) */
	    if ((ret = FIN_SplitInstrument(instrPtr, posHierHead, NULLDYNST,
				                       &instrFloatPtr, &instrFixPtr, freeLegFlg,
				                       (NUMBER_T*)NULL)) != RET_SUCCEED)
        {
	        *instrNbr = 0;
	        FREE(*instrTab);
            return(ret);
        }

	    (*instrTab)[0] = instrFloatPtr;
	    (*instrTab)[1] = instrFixPtr;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_CreateDiscountInstr()
*
*  Description : Create temporary discount instrument.
*
*  Arguments   : option  : input instrument.
*                discount : structure pointer for ouput (alloc in procedure)
*
*  Return      : RET_SUCCEED or retcode
*
*  Creation D. : REF1055 - 991104 - AKO
*
*************************************************************************/
RET_CODE FIN_CreateDiscountInstr(DBA_DYNFLD_STP	    option,
				                 DBA_DYNFLD_STP	    *discount,
				                 DATE_T		        discfacDate,
				                 DATE_T		        validDate,
				                 DBA_HIER_HEAD_STP  posHierHead)
{
	ID_T		    instrId;
	int		        discountNbr=0, i=0;
	DBA_DYNFLD_STP  *discountTab=NULLDYNSTPTR, termEvt=NULLDYNST;
	RET_CODE        retCd=RET_SUCCEED;
	FLAG_T		    foundFlg=FALSE;

	/* ------------------------------------------------------------	*/
	/* First verify if discount instrument is already in hierarchy,	*/
	/* if it is the case, set discount pointer and return.		*/
	/* Calling function verify on identifier and don't add		*/
	/* founded instrument in hierarchy a again.			*/
	/* ------------------------------------------------------------	*/
	if ((posHierHead != NULL) &&
	    ((retCd=DBA_ExtractHierEltRecWithFilterSt(posHierHead, A_Instr, FALSE,
					                              FIN_FilterDiscount, option,
						                          NULLFCT,
                                                  &discountNbr, &discountTab)) != RET_SUCCEED))
	{
		return(retCd);
	}

	if (discountNbr == 1)
	{
	    for (i=0; i<discountNbr && !foundFlg; i++)
	    { /* feature of temporary discount instrument generated */
		if (((INSTRNAT_ENUM)GET_ENUM(discountTab[i], A_Instr_NatEn) == InstrNat_Discount) &&
		    (((SUBNAT_ENUM) GET_ENUM(discountTab[i], A_Instr_SubNatEn) == SubNat_Barrier) ||
		     ((SUBNAT_ENUM) GET_ENUM(discountTab[i], A_Instr_SubNatEn) == SubNat_OneTouchDigital) ||
		     ((SUBNAT_ENUM) GET_ENUM(discountTab[i], A_Instr_SubNatEn) == SubNat_DoubleKnockOut))
		   )
		{
			(*discount) = discountTab[i]; foundFlg=TRUE;
		}
	    }
	    FREE(discountTab);
	    return(RET_SUCCEED);
	}
	FREE(discountTab);

	/* get term event table and underlying instrument*/
	if (RET_SUCCEED ==retCd)
	{
	    if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    if ((retCd=DBA_GetTermEvt(option, validDate, termEvt))!=RET_SUCCEED)
	    {
		FREE_DYNST(termEvt, A_TermEvt);
		return(retCd);
	    }
	}

	/* Not in hierarchy, so we must create it */
	if (((*discount) = ALLOC_DYNST(A_Instr)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	if (GET_ID(option, A_Instr_Id) <= 0)
		instrId = GET_ID((option), A_Instr_ParentInstrId);
	else
		instrId = GET_ID((option), A_Instr_Id);

	COPY_DYNST((*discount), option, A_Instr);
	SET_NULL_ID((*discount), A_Instr_Id);
	SET_ID((*discount), A_Instr_ParentInstrId, instrId);

	/* fill in discount instrument fields */
	SET_ENUM((*discount),   A_Instr_NatEn, InstrNat_Discount);
	SET_ENUM((*discount),   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);
	SET_ENUM((*discount),   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM((*discount),   A_Instr_AccrualRuleEn, AccrRule_Actual_360);
	SET_NUMBER((*discount),   A_Instr_InterestRateP, 0.0);

	/* Set end date to generated instrument, so TECH tools work correctly */
	/* if (IS_NULLFLD(termEvt, A_TermEvt_RebateAtHitFlg)!=TRUE) */

	if (IS_NULLFLD(termEvt, A_TermEvt_EndDate)!=TRUE)
	{
	    COPY_DYNFLD((*discount), A_Instr, A_Instr_EndDate, termEvt, A_TermEvt, A_TermEvt_EndDate);
	}

	/* depend on option subnature */
	/* barrier or one-touch-digital options */
	if ((GET_ENUM((*discount), A_Instr_SubNatEn) == SubNat_Barrier) ||
	    (GET_ENUM((*discount), A_Instr_SubNatEn) == SubNat_OneTouchDigital))
	{
	    if (IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)==TRUE)
	    {
		    if (TRUE == GET_FLAG(termEvt, A_TermEvt_RebateAtHitFlg))
		    {
		        SET_DATE((*discount), A_Instr_EndDate, discfacDate);
		    }
	    }
	    else
	    {
		    if (TRUE == GET_FLAG(termEvt, A_TermEvt_RebateAtHitFlg))
		    {
		        SET_DATE((*discount), A_Instr_EndDate, GET_DATE(termEvt, A_TermEvt_SeasonDate));
		    }
	    }
	}
	else
	{ /* double knock-out options */
	    if ((IS_NULLFLD(termEvt, A_TermEvt_FixDate)==TRUE) && (IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)==TRUE))
	    {
		    /* search quote of underlying instrument */
		    DBA_DYNFLD_STP	pricePtr=NULLDYNST, underInstr=NULLDYNST;
		    double		    quote=0.0;
		    DATETIME_T		dateVal;
		    FLAG_T		    underInstrFreeFlg=FALSE;

		    dateVal.date = validDate; dateVal.time = 0; /* if quotation is daily */

		    if ((retCd=DBA_GetInstrById(GET_ID(termEvt, A_TermEvt_UnderlyInstrId),
					                    TRUE, &underInstrFreeFlg, &underInstr,
					                    posHierHead, UNUSED, UNUSED))!=RET_SUCCEED)
		    {
		        return(retCd);
		    }

		    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
		    {
		        if (underInstrFreeFlg == TRUE) {FREE_DYNST(underInstr, A_Instr);}
		        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    }

		    if (FIN_InstrPrice(GET_ID(underInstr, A_Instr_Id),
		                       underInstr, dateVal, NULLDYNST, 0, NULL, NULLDYNST,
		                       NULLDYNST, posHierHead, pricePtr, FALSE) == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
		    {
			    quote = (double)GET_PRICE(pricePtr, A_InstrPrice_Quote);
		    }
		    else
		    {
		        FREE_DYNST(pricePtr, A_InstrPrice);
		        if (underInstrFreeFlg == TRUE) 	{FREE_DYNST(underInstr, A_Instr);}
		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_CreateDiscountInstr",
			                GET_CODE(underInstr, A_Instr_Cd),
			                "FIN_Instrprice failed");
		        return(RET_FIN_ERR_SCE);
		    }
		    FREE_DYNST(pricePtr, A_InstrPrice);
		    if (underInstrFreeFlg == TRUE) {FREE_DYNST(underInstr, A_Instr);}

		    /* the two dates are null - choose which barrier has been hit */
		    if (CMP_NUMBER(quote, GET_NUMBER(termEvt, A_TermEvt_UpperBarrier)) >= 0)
		    {
		        if (TRUE == GET_FLAG(termEvt, A_TermEvt_UpperRebateAtHitFlg))
		        {
			    SET_DATE((*discount), A_Instr_EndDate, discfacDate);
		        }
		    }
		    else
		    {
		        if (CMP_NUMBER(quote, GET_NUMBER(termEvt, A_TermEvt_Barrier)) <= 0)
		        {
			        if (TRUE == GET_FLAG(termEvt, A_TermEvt_RebateAtHitFlg))
			        {
			            SET_DATE((*discount), A_Instr_EndDate, discfacDate);
			        }
		        }
		    }
	    }
	    else if (IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)!=TRUE)
	    {
		    if (TRUE == GET_FLAG(termEvt, A_TermEvt_RebateAtHitFlg))
		    {
		        SET_DATE((*discount), A_Instr_EndDate, GET_DATE(termEvt, A_TermEvt_SeasonDate));
		    }
	    }
	    else
	    {
		    if (IS_NULLFLD(termEvt, A_TermEvt_FixDate)!=TRUE)
		    {
		        if (TRUE == GET_FLAG(termEvt, A_TermEvt_UpperRebateAtHitFlg))
		        {
			        SET_DATE((*discount), A_Instr_EndDate, GET_DATE(termEvt, A_TermEvt_FixDate));
		        }
		    }
	    }
	}

	if (TRUE==IS_NULLFLD((*discount), A_Instr_EndDate))
	{
	    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_CreateDiscountInstr",
		             GET_CODE(option, A_Instr_Cd),
		             "FIN_CreateDiscountInstr - instr.EnDdate not found");

	    retCd = RET_DBA_ERR_NODATA;
	}

	/* ----------------------- */
	/* Add record to hierarchy */
	/* ----------------------- */
	if (retCd == RET_SUCCEED)
	{
	    if ((posHierHead!=NULL) && (IS_NULLFLD((*discount), A_Instr_Id)==TRUE))
	    {
		    /* insert new instrument in hierarchy */
		    if ((retCd = DBA_AddHierRecord(posHierHead, (*discount),
					                       A_Instr, FALSE,
					                       /* HierAddRec_TestMandatLnk */
					                       HierAddRec_ForceInsert)) != RET_SUCCEED)
		    {
		        FREE_DYNST((*discount), A_Instr);
		        return(retCd);
		    }
	    }
	}

	FREE_DYNST(termEvt, A_TermEvt);
	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_FilterDiscount()
**
**  Description :   Verify if discount instr. are already in hierarchy.
**
**  Rem		:   Function called by DBA_ExtractHierEltRecWithFilterSt()
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            paramSt    parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   REF1055 - 991104 - AKO
**
*************************************************************************/
STATIC int FIN_FilterDiscount(DBA_DYNFLD_STP   discount,
                              DBA_DYNST_ENUM   ,
				              DBA_DYNFLD_STP   option)
{
	ID_T instrId;

	if (GET_ID(option, A_Instr_Id) <= 0)
		instrId = GET_ID(option, A_Instr_ParentInstrId);
	else
		instrId = GET_ID(option, A_Instr_Id);

	if ((GET_ID(discount, A_Instr_ParentInstrId) == instrId) &&
	    ((INSTRNAT_ENUM)GET_ENUM(discount, A_Instr_NatEn) == InstrNat_Discount) &&
	    (((SUBNAT_ENUM) GET_ENUM(discount, A_Instr_SubNatEn) == SubNat_Barrier) ||
	     ((SUBNAT_ENUM) GET_ENUM(discount, A_Instr_SubNatEn) == SubNat_OneTouchDigital) ||
	     ((SUBNAT_ENUM) GET_ENUM(discount, A_Instr_SubNatEn) == SubNat_DoubleKnockOut))
	   )
	{
		return(TRUE);
	}
    else
	{
		return(FALSE);
	}
}


/*************************************************************************
**
**  Function    :   FIN_GenericInstrCompo()
**
**  Description :   Generate an InstrCompo array.
**
**  Warning     :   You must test both the return code and compoNbr.
**
**  Arguments   :   instrPtr    :   parent instrument
**                  hierHead    :   Hierarchy
**                  compoTab    :   array of InstrCompo
**                  compoNbr    :   Number of InstrCompo in the array
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 19111999
**
**  History     :   REF1055 - RAK - 991215 - replace FIN_GenForexInstrCompo() and
**					FIN_GenSwapInstrCompo()
**
*************************************************************************/
RET_CODE FIN_GenericInstrCompo( DBA_DYNFLD_STP              instrPtr,
                                DBA_HIER_HEAD_STP           hierHead,
                                DBA_DYNFLD_STP              extPos,
                                DBA_DYNFLD_STP              **compoTab,
                                int                         *compoNbr,
	                            STNSPECTREATMENT_ENUM STNSpecificEn)  /* PMSTA-34752 - RAK - 190221 - Grand-father is a Tarko */
{
    FLAG_T  isOpConvertBondFlg=FALSE;

    /*  Local variables declaration */
    DBA_DYNFLD_STP      instrLeg1Ptr;
    DBA_DYNFLD_STP      instrLeg2Ptr;
    INSTRCATEGORY_ENUM  instrCategory;
    NUMBER_T            convertionFactor = 0;
    FLAG_T		        freeLegFlg=FALSE;
    RET_CODE            ret=RET_SUCCEED;
    /* REF5089 - AKO - 001026 */
	DBA_DYNFLD_STP  domainPtr=NULLDYNST,termEvt=NULLDYNST;
    DATE_T          valDate;
    ID_T            oldUnderInstrId=0, newUnderlyInstrId=0;
    ENUM_T          oldOptionClassEn=0, newOptionClassEn=0;
	NUMBER_T		oldUnderQty = 0.0, newUnderQty = 0.0;
    FLAG_T          oldStored=FALSE;

	domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
	valDate = GET_DATE(domainPtr, A_Domain_InterpFromDate);

    /* Test if the hierarchy is present If no, then, try to get it */
    if (hierHead == NULL)    /* REF5089 - AKO - 001026 */
    {
        if ((hierHead=(DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr())==NULL)
        {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		                 "FIN_GenericInstrCompo", "hierarchy is mandatory");
	        return(RET_GEN_ERR_INVARG);
        }
    }
    /* REF5089 - AKO - 001026 */
    /* -------------------------------------------------- */
    /* move termEvt underlying_Instr_Id to the instrument */
    /* -------------------------------------------------- */
    /* natureInstr = GET_ENUM( instrPtr, A_Instr_NatEn);  */
    switch((ENUM_T)GET_ENUM( instrPtr, A_Instr_NatEn))
    {
        case    InstrNat_Future:
        case    InstrNat_Forward:
        case    InstrNat_Option:
        case    InstrNat_ExoticOptions:
        case    InstrNat_SwapOptions:
		{
			DBA_DYNFLD_STP getData;
			MemoryPool mp;

			/* PMSTA-34140 - RAK - 190131 - Special case for AC/DC - as it don't use (correctly) the denormalisation in instrument */
			termEvt = mp.allocDynst(FILEINFO, A_TermEvt);

			if (InstrumentNature::isAccumulator(instrPtr) ||
				InstrumentNature::isDecumulator(instrPtr))
			{
				DbiConnectionHelper dbiConnHelper;

				getData = mp.allocDynst(FILEINFO, Evt_Arg);

				if (GET_ID(instrPtr, A_Instr_Id) < 0)
				{ SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));}
				else
				{ SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));}

				SET_DATE(getData, Evt_Arg_ValidDate, valDate);

				ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &termEvt);

				if (ret == RET_SUCCEED)	/* PMSTA-34140 - RAK - 190131 - same system as UnderlyInstrId */
				{
					NUMBER_T lifeTime = 0.0;

					/* started and not expired, compute lifeTime and newQty */
					if(FIN_STNKnockInStarted(valDate, termEvt, instrPtr) == TRUE &&
					   FIN_STNKnockOutExpired(valDate, termEvt, instrPtr) == FALSE)
					{
						oldUnderQty = GET_NUMBER(instrPtr, A_Instr_UnderlyQty);
						lifeTime = FIN_ACDCLifeTime(instrPtr, valDate, termEvt);
						newUnderQty = TLS_Round((GET_NUMBER(termEvt, A_TermEvt_TotalQty) * lifeTime), 1.0, RndRule_Nearest);
						SET_NUMBER(instrPtr, A_Instr_UnderlyQty, newUnderQty);
						/* use oldStoredFlg */
					}
				}
			}
			else
			{
				ret = DBA_GetTermEvt(instrPtr, valDate, termEvt);
			}

			if (ret == RET_SUCCEED)
			{
				oldUnderInstrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
				oldOptionClassEn = GET_ENUM(instrPtr, A_Instr_OptionClassEn);
				newUnderlyInstrId = GET_ID(termEvt, A_TermEvt_UnderlyInstrId);
				newOptionClassEn = GET_ENUM(termEvt, A_TermEvt_OptionClassEn);
				SET_ID(instrPtr, A_Instr_UnderlyInstrId, newUnderlyInstrId);
				SET_ENUM(instrPtr, A_Instr_OptionClassEn, newOptionClassEn);
				oldStored = TRUE;
			}
			break;
		}
        default:
                break;
    } /* END of REF5089 - AKO */

    /*  Get the category of the instrument  */
    instrCategory   =   FIN_InstrCategory(instrPtr, hierHead);

    /*  Shall we work, or not ? */
    switch  (instrCategory)
    {
    case    InstrCategory_BondFutures:
    case    InstrCategory_BondForwards:
    case    InstrCategory_EquityFutures:
    case    InstrCategory_CurrencyFutures:
    case    InstrCategory_EquityForwards:
    case    InstrCategory_CurrencyForwards:
    case    InstrCategory_Swap:
    case    InstrCategory_ForexSwap:
    case    InstrCategory_Options:
    case    InstrCategory_ExoticOptions:
    case    InstrCategory_ConvertibleBond:
	case	InstrCategory_ACDC:				/* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */

		/* PMSTA-34140 - RAK - 190131 - AC/DC Verify if we create composition */
		/* Knock-out and knock-in purpose (*compoNbr stay to 0) */
		/* PMSTA-35133 - RAK - 190314 */ /* PMSTA-35969 - RAK - 190520 */
		/*if (instrCategory == InstrCategory_ACDC && termEvt != NULLDYNST &&
			(FIN_STNKnockInStarted(valDate, termEvt, instrPtr) == FALSE ||
				FIN_STNKnockOutExpired(valDate, termEvt, instrPtr) == TRUE))
		{
			if (oldStored == TRUE)
			{
				SET_ID(instrPtr, A_Instr_UnderlyInstrId, oldUnderInstrId);
				SET_ENUM(instrPtr, A_Instr_OptionClassEn, oldOptionClassEn);
			}
			return(ret);
		}*/

        /*  Variables initialization    */
        /* REF5886 - RAK - 010304 - Convertible bond  */
        /* Generate only stock leg for option of convertible bond */
        FIN_IsOptConvertBondFlg(instrPtr, hierHead, &isOpConvertBondFlg);
        if (isOpConvertBondFlg == TRUE)
            *compoNbr = 1;  /* only one leg for option of convertible bond */
        else
            *compoNbr = 2;  /*  Because we known that we have 2 legs */
        instrLeg1Ptr    =   NULLDYNST;
        instrLeg2Ptr    =   NULLDYNST;

        /*  Array allocation    */
        ret =   FIN_AllocMemoryInstrCompo( compoTab, *compoNbr);

        /*  Select the 2 instruments, and add them into the hierarchy    */
        if  (ret==RET_SUCCEED)
            ret =   FIN_SplitInstrument(instrPtr,
                                        hierHead,
                                        extPos,
                                        &instrLeg1Ptr,
                                        &instrLeg2Ptr,
					                    &freeLegFlg,	/* will be always FALSE */
                                        &convertionFactor);


        /* REF5101 - AKO - 000915 */ /* Deliver with Cash Account instead of Discount */
		/* PMSTA-9473 - KRAK - 100316 - Must add an exception for future and forwards */
		/* as nature of leg are treated in FIN_ChangeInstrLegNatEn() or in leg creation. */
		/* so modify the != Swap ... and == Option or Exotic Options */
		/* PMSTA-10039 - RAK - 100608 - Add currency fwd */
        if ((RET_SUCCEED==ret && instrLeg2Ptr!=NULLDYNST) &&
            (instrCategory==InstrCategory_Options ||
             instrCategory==InstrCategory_ExoticOptions||
		     instrCategory==InstrCategory_ACDC || /* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */
			 instrCategory==InstrCategory_CurrencyForwards))
        {
            /* REF5049 - RAK - 010216 - Keep Bond of option from convertible bond */
            FLAG_T updCashFlg=TRUE;
            if (instrCategory == InstrCategory_Options)
            {
                isOpConvertBondFlg=FALSE;
                FIN_IsOptConvertBondFlg(instrPtr, hierHead, &isOpConvertBondFlg);

                if (isOpConvertBondFlg == TRUE)
                    updCashFlg = FALSE;

            }

            if (updCashFlg == TRUE)
            {
                SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct);
                /* PMSTA-9473 - KRAK - 100316 - removed as nature of leg are treated in FIN_ChangeInstrLegNatEn() or in leg creation. */
				/* PMSTA-10039 - RAK - 100608 - Keep currency fwd */
				if  ((instrCategory==InstrCategory_CurrencyForwards) /*|| (instrCategory==InstrCategory_CurrencyFutures)*/)
                {
                    SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_CashAcct);
                }
            }
        }

        /* REF5886 - RAK - 010304 - Convertible bond  */
        /* instrLeg1Ptr = Bond, instrLeg2Ptr = Option */
        /* Change order : first option, second bond   */
        if (instrCategory==InstrCategory_ConvertibleBond)
        {
            DBA_DYNFLD_STP instrSwapping = instrLeg1Ptr;
	        instrLeg1Ptr = instrLeg2Ptr;
	        instrLeg2Ptr = instrSwapping;
        }

        /* Generate two InstrCompo records  */
        /* REF5886 - RAK - 010304 - Convertible bond = 1 compoTab */
        if  (ret==RET_SUCCEED)
            ret =   FIN_GenInstrCompo(  instrPtr,
                                        hierHead,
                                        extPos,
                                        instrLeg1Ptr,
                                        instrLeg2Ptr,
                                        convertionFactor,
                                        instrCategory,
										STNSpecificEn,	/* PMSTA-34752 - RAK - 190221 - Options from Tarko */
                                        compoTab);		/* REF7475 - YST - 020516 */

       /* REF6018 - RAK - 010627 - Inverse legs */
       if (ret==RET_SUCCEED)
       {
           if (instrCategory == InstrCategory_CurrencyFutures ||
               instrCategory == InstrCategory_CurrencyForwards)
           {
               DBA_DYNFLD_STP swapCompoPtr=(*compoTab)[0];
               (*compoTab)[0] = (*compoTab)[1];
               (*compoTab)[1] = swapCompoPtr;
           }
        }

        /*  Exit from this case */
        break;

    /*  Others instruments
        Force RET_SUCCEED and 0 into compoNbr.*/
    case    InstrCategory_Others:

    default:
        *compoNbr = 0;
        ret =   RET_SUCCEED;
    }

    if (oldStored==TRUE) /* REF5089 - AKO - 001026 */
    {
        SET_ID(instrPtr, A_Instr_UnderlyInstrId, oldUnderInstrId);
        SET_ENUM(instrPtr, A_Instr_OptionClassEn, oldOptionClassEn);

		/* PMSTA-34140 - RAK - 190201 - suppl field */
		if (instrCategory == InstrCategory_ACDC)
		{ SET_NUMBER(instrPtr, A_Instr_UnderlyQty, oldUnderQty);}
    }

    /*  Return value    */
    return(ret);
}

RET_CODE FIN_SelectUnderlyingCompo(DBA_HIER_HEAD_STP, DATETIME_T refDateTime, DBA_DYNFLD_STP instrPtr, DBA_DYNFLD_STP **selInstrCompoTab, int *selInstrCompoNbr)
{
	RET_CODE	ret = RET_SUCCEED;

	/* PMSTA-35081 - RAK - 190528 - specific case for Mini Future Turbo and Plie */
	/* Le turbot est un tr�s bon poisson � je conseil de le faire r�ti au citron vert 8O))) D */
	/* Use term event information for : */
	/* Pay-off nature
	   Underlying
	   Initial fixing price
	   Exercise quote
	   Leverage
	   Barrier Nature
       Lower Barrier
       Knock-out Date */
	if (InstrumentNature::isMiniFuturesTurbo(instrPtr))
	{
		MemoryPool mp;
		DbiConnectionHelper dbiConnHelper;

		DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Evt_Arg);
		DBA_DYNFLD_STP vroumPtr = mp.allocDynst(FILEINFO, A_TermEvt);

		SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));
		SET_DATE(getData, Evt_Arg_ValidDate, refDateTime.date);

		if ((ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &vroumPtr)) != RET_SUCCEED)
			return(ret);

		/* PMSTA-35081 - RAK - 190611 */
		/* Karthik : As discussed now, let us go ahead with the below approach : -            */
		/* if underlying category is Single, check underlying from term event table */
		/* if is not single, then check composition directly            */
		/* and use leverage and pay - off nature values from term event */
		const INSTR_UNDERLYING_CATEGORY_ENUM instrUnderlyingCategory = static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(instrPtr, A_Instr_UnderlyCatEn));

		/* en voiture Simone (une seule) */
		if (instrUnderlyingCategory  == INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument && !IS_NULLFLD(vroumPtr, A_TermEvt_UnderlyInstrId))
		{
			if ((ret = FIN_AllocMemoryInstrCompo(selInstrCompoTab, 1)) == RET_SUCCEED)
			{
				*selInstrCompoNbr = 1;
				SET_ID((*selInstrCompoTab)[0], A_InstrCompo_InstrId, GET_ID(vroumPtr, A_TermEvt_UnderlyInstrId));
				SET_ID((*selInstrCompoTab)[0], A_InstrCompo_ParentInstrId, GET_ID(instrPtr, A_Instr_Id));
				SET_DATE((*selInstrCompoTab)[0], A_InstrCompo_BeginDate, refDateTime.date);
				SET_DATE((*selInstrCompoTab)[0], A_InstrCompo_EndDate, MAGIC_END_DATE);
				SET_NUMBER((*selInstrCompoTab)[0], A_InstrCompo_Quantity, GET_NUMBER(instrPtr, A_Instr_UnderlyQty));
				SET_PERCENT((*selInstrCompoTab)[0], A_InstrCompo_BasketWeightP, 100);  /* une seule voiture */
				SET_PRICE((*selInstrCompoTab)[0], A_InstrCompo_BasketFixingPrice, GET_PRICE(vroumPtr, A_TermEvt_UnderlyFixingPrice));
				SET_PRICE((*selInstrCompoTab)[0], A_InstrCompo_BasketExerPrice, GET_PRICE(vroumPtr, A_TermEvt_ExerPrice));
				SET_PERCENT((*selInstrCompoTab)[0], A_InstrCompo_BasketBarrierP, GET_NUMBER(instrPtr, A_Instr_LowerBarrierP));   /*PMSTA-32504 - SIL - 190115*/
			}
			return(ret);
		}
		else /* plusieurs voitures so don't use instrument in term event but composition */
		{
			/* Set input structure for select*/
			DBA_DYNFLD_STP      sInstrCompo = mp.allocDynst(FILEINFO, S_InstrCompo);

			SET_ID(sInstrCompo, S_InstrCompo_ParentInstrId, GET_ID(instrPtr, A_Instr_Id));
			SET_DATE(sInstrCompo, S_InstrCompo_BeginDate, refDateTime.date);

			ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, sInstrCompo, A_InstrCompo, selInstrCompoTab, UNUSED, UNUSED, selInstrCompoNbr, nullptr, nullptr);
		}
	}
	else if (!IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId))
	{
		if ((ret = FIN_AllocMemoryInstrCompo(selInstrCompoTab, 1)) == RET_SUCCEED)
		{
			*selInstrCompoNbr = 1;
			SET_ID((*selInstrCompoTab)[0],      A_InstrCompo_InstrId,           GET_ID(instrPtr, A_Instr_UnderlyInstrId));
			SET_ID((*selInstrCompoTab)[0],      A_InstrCompo_ParentInstrId,     GET_ID(instrPtr, A_Instr_Id));
			SET_DATE((*selInstrCompoTab)[0],    A_InstrCompo_BeginDate,         refDateTime.date);
			SET_DATE((*selInstrCompoTab)[0],    A_InstrCompo_EndDate,           MAGIC_END_DATE);
			SET_NUMBER((*selInstrCompoTab)[0],  A_InstrCompo_Quantity,          GET_NUMBER(instrPtr, A_Instr_UnderlyQty));
			SET_PERCENT((*selInstrCompoTab)[0], A_InstrCompo_BasketWeightP,     100);  /*PMSTA-34836 - Silpakala - 190221*/
            SET_PRICE((*selInstrCompoTab)[0], A_InstrCompo_BasketFixingPrice, GET_PRICE(instrPtr, A_Instr_UnderlyFixingPrice));
            SET_PRICE((*selInstrCompoTab)[0], A_InstrCompo_BasketExerPrice, GET_PRICE(instrPtr, A_Instr_ExerQuote));
            SET_PERCENT((*selInstrCompoTab)[0], A_InstrCompo_BasketBarrierP, GET_NUMBER(instrPtr, A_Instr_LowerBarrierP));   /*PMSTA-32504 - SIL - 190115*/
		}
	}
	else
	{
		MemoryPool  mp;

		/*
		* Set input structure for select
		*/
		DBA_DYNFLD_STP      sInstrCompo = mp.allocDynst(FILEINFO, S_InstrCompo);

		SET_ID(sInstrCompo, S_InstrCompo_ParentInstrId, GET_ID(instrPtr, A_Instr_Id));
		SET_DATE(sInstrCompo, S_InstrCompo_BeginDate, refDateTime.date);

		ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, sInstrCompo, A_InstrCompo, selInstrCompoTab, UNUSED, UNUSED, selInstrCompoNbr, nullptr, nullptr);
	}

	return(ret);
}



/*************************************************************************
**
**  Function    :   FIN_AllocMemoryInstrCompo()
**
**  Description :   Set the memory allocation for the InstrCompo array.
**
**  Arguments   :   compoTab    :   array of InstrCompo
**                  compoNbr    :   Number of InstrCompo in the array
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 19111999
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_AllocMemoryInstrCompo(DBA_DYNFLD_STP      **compoTab,
                                          int                 compoNbr)
{
    /*  Local variables */
    RET_CODE    ret = RET_SUCCEED;
    FLAG_T      allocArray = TRUE;
    int         i=0;
    int         j=0;

    /*  Memory allocation for the array  */
    *compoTab = (DBA_DYNFLD_STP*) CALLOC(compoNbr, sizeof(DBA_DYNFLD_STP)); /* REF7264 - PMO */
    if (*compoTab == NULLDYNSTPTR)
    {
        ret =   RET_MEM_ERR_ALLOC;
        allocArray  =   FALSE;
    }

    /*  Memory allocation for each element  */
    if  (ret==RET_SUCCEED)
    {
        for (i=0; i<compoNbr; i++)
        {
            (*compoTab)[i] = ALLOC_DYNST(A_InstrCompo); /*  Try */
            if ( (*compoTab)[i] == NULLDYNST)   /*  Can't do it */
                ret =   RET_MEM_ERR_ALLOC;
        }
    }

    /*  Purge memory in case of errors occurs   */
    if  (ret!=RET_SUCCEED)
    {
        /*  Purge elements  */
        for (j=0; j<i; j++)
            FREE_DYNST((*compoTab)[i], A_InstrCompo);

        /*  Purge array */
        if  (allocArray==TRUE)
            FREE(*compoTab);

        /*  Send a message to the log file  */
        MSG_RETURN(ret);
    }

    /*  Return value    */
    return(ret);
}



/*************************************************************************
**
**  Function    :   FIN_InstrCategory()
**
**  Description :   Return the category of an instrument depending of
**                  its underlying instrument..
**
**  Arguments   :   instrPtr    :   Pointer to the instrument.
**                  hierHead    :   Pointer to the hierarchy.
**
**  Return      :   INSTRCATEGORY_ENUM
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  Last modif. :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**              :   REF7782 - YST - 020904
**  Last modif  :   REF6057 - AKO - 020924
**  Modif       :   HFI-PMSTA-37839-200211  Test DBA_GetInstrById return
**
**
*************************************************************************/
INSTRCATEGORY_ENUM   FIN_InstrCategory(DBA_DYNFLD_STP       instrPtr,
                                       DBA_HIER_HEAD_STP    hierHead)
{
    /*  Local variables declarations    */
    INSTRCATEGORY_ENUM  instrCategory;
    DBA_DYNFLD_STP      underlyInstrPtr=NULLDYNST;
    ID_T                underlyInstrId=(ID_T)0;
    ENUM_T              instrNature;
    ENUM_T              undelyInstrNature;
    FLAG_T              allocFlag;

    /* REF5089 - AKO - 010221 */
    DBA_DYNFLD_STP  termEvt=NULLDYNST;
	DBA_DYNFLD_STP  domainPtr;
    DATE_T          validDate;

    /*  Get the Id of the underlying instrument */
    /* ----------------------------------------------------------------------------- */
    /* REF5089 - AKO - 010221 : load underlying instrument from the Term Event Table */
    /* ----------------------------------------------------------------------------- */
	if (IS_NULLFLD(instrPtr,A_Instr_UnderlyInstrId)==TRUE)
    {
        if ((TERMCD_ENUM)GET_ENUM(instrPtr, A_Instr_TermCdEn) != TermCd_None)
        {
            domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
            validDate = GET_DATE(domainPtr,A_Domain_InterpFromDate);
            if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
            {
                /* To be fixed with REF7343 */
	            MSG_RETURN(((INSTRCATEGORY_ENUM)RET_MEM_ERR_ALLOC)); /* REF7264 - PMO */
            }
            if (DBA_GetTermEvt( instrPtr, validDate, termEvt)==RET_SUCCEED)
            {
                 underlyInstrId = GET_ID(termEvt, A_TermEvt_UnderlyInstrId);
            }
            FREE_DYNST(termEvt, A_TermEvt);
        }
    } /* END REF5089 */
    else
    {
        underlyInstrId = GET_ID(instrPtr,A_Instr_UnderlyInstrId);
    }

    /*  Get the Id of the underlying instrument */
    /*underlyInstrId  =   GET_ID(instrPtr,A_Instr_UnderlyInstrId);*/

	/* PMSTA-32112 - RAK - 180907 - Structured Notes */
	instrCategory = InstrCategory_Others;	/*  Default value */

	if (InstrumentNature::isStructuredNotes(instrPtr))
	{
		instrCategory = InstrCategory_StructuredNotes;

		/* PMSTA-34140 - RAK - 190131 - Exception for AC/DC, use std option treatment */
		if (InstrumentNature::isAccumulator(instrPtr) ||
			InstrumentNature::isDecumulator(instrPtr))
			instrCategory = InstrCategory_ACDC;
	}

	/* Not a Structured Notes */
	if (instrCategory == InstrCategory_Others)
	{
		/*  Get the nature of the instrument */
		instrNature = GET_ENUM(instrPtr, A_Instr_NatEn);

		switch (instrNature)
		{
		case    InstrNat_ConvertBond:
			instrCategory = InstrCategory_ConvertibleBond;
			break;

		case    InstrNat_Option:
			instrCategory = InstrCategory_Options;
			break;

		case    InstrNat_ExoticOptions:
			instrCategory = InstrCategory_ExoticOptions;
			break;

		case    InstrNat_ForexSwaps:
			instrCategory = InstrCategory_ForexSwap;
			break;

		case    InstrNat_Swap:
			switch ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn))
			{
			case    SubNat_FixFloatStdSwap:
			case    SubNat_FixFixStdSwap:
			case    SubNat_FltFltStdSwap:
			case    SubNat_FixFltSwapHedgFix:   /* REF7782 - YST - 020904 */
				instrCategory = InstrCategory_Swap;
				break;
			}
			break;

		/* REF4763 - RAK - 000622 */
		case    InstrNat_FRA:
			instrCategory = InstrCategory_FRA;
			break;

		default:
			/*  The instrument has an underlying ?  */
			if (underlyInstrId != 0)
			{
				/*  Get the pointer to the underlying instrument    */
				if (DBA_GetInstrById(underlyInstrId, TRUE, &allocFlag, &underlyInstrPtr,
					                 hierHead, UNUSED, UNUSED) == RET_SUCCEED)
                {				/*  Get the nature of the undelying instrument  */
                    undelyInstrNature = GET_ENUM(underlyInstrPtr, A_Instr_NatEn);

                    /* REF6057 - AKO - 020924 */
                    if ((underlyInstrPtr != NULLDYNST) && (IS_NULLFLD(underlyInstrPtr, A_Instr_NatEn2) == TRUE))
                    {
                        SET_ENUM(underlyInstrPtr, A_Instr_NatEn2, undelyInstrNature);
                    }

                    if (IS_NULLFLD(underlyInstrPtr, A_Instr_NatEn2) != TRUE)
                    {
                        undelyInstrNature = GET_ENUM(underlyInstrPtr, A_Instr_NatEn2);
                    }

                    /*  Testing */
                    instrCategory = FIN_GetInstrCategory(instrNature, undelyInstrNature);

                    /*<PMSTA15800-JPP-130116 - other not treated, Warn Log */
                    if (instrNature == InstrNat_Future && instrCategory == InstrCategory_Others)
                    {
                        MSG_SendMesg(RET_FIN_ERR_RISKUNDERLYING, 0, FILEINFO, GET_CODE(instrPtr, A_Instr_Cd),
                                     DBA_GetPermValName(Instr, A_Instr_NatEn, undelyInstrNature));
                    }
                    /*PMSTA15800-JPP-130116 >*/

                    /*  Clean   */
                    if (allocFlag == TRUE)
                        FREE_DYNST(underlyInstrPtr, A_Instr);
                }
            }
        }
    }

    /* Return value */
    return(instrCategory);
}


/*************************************************************************
**
**  Function    :   FIN_GetInstrCategory()
**
**  Description :   Return the category of an instrument depending of
**                  its underlying instrument..
**
**  Arguments   :   instrNature         :   nature of the instrument
**                  underlyInstrNature  :   nature of the underlying instrument
**
**  Return      :   INSTRCATEGORY_ENUM
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  History     :
**
*************************************************************************/
STATIC INSTRCATEGORY_ENUM   FIN_GetInstrCategory(ENUM_T  instrNature,
                                                 ENUM_T  underlyInstrNature)
{
    /*  Local variables declarations    */
    INSTRCATEGORY_ENUM  instrCategory;

    /*  Default values  */
    instrCategory   =   InstrCategory_Others;

    /*  Switch on the nature of the instrument */
    switch  (instrNature)
    {

    /*  The instrument is a future  */
    case    InstrNat_Future:

        /*  Switch on the nature of the underlying instrument   */
        switch  (underlyInstrNature)
        {
        case    InstrNat_Bond:
        case    InstrNat_Deliverables:
            instrCategory   =   InstrCategory_BondFutures;
            break;

        case    InstrNat_Stock:
        case    InstrNat_Idx:
		case	InstrNat_Commodities:		/*PMSTA15800-JPP-130116 - commodities treated like a stock*/
            instrCategory   =   InstrCategory_EquityFutures;
            break;

        case    InstrNat_CashAcct:
            instrCategory   =   InstrCategory_CurrencyFutures;
            break;

        default:
            instrCategory   =   InstrCategory_Others;
			break;
        }
        break;


    /*  The instrument is a forward */
    case    InstrNat_Forward:

        /*  Switch on the nature of the underlying instrument   */
        switch  (underlyInstrNature)
        {
        case    InstrNat_Bond:
            instrCategory   =   InstrCategory_BondForwards;
            break;

        case    InstrNat_Stock:
        case    InstrNat_Idx:
            instrCategory   =   InstrCategory_EquityForwards;
            break;

        case    InstrNat_CashAcct:
            instrCategory   =   InstrCategory_CurrencyForwards;
            break;

        default:
            instrCategory   =   InstrCategory_Others;
        }
        break;

    default:
        instrCategory   =   InstrCategory_Others;
    }

    /*  Return value    */
    return(instrCategory);
}


/*************************************************************************
**
**  Function    :   FIN_SplitInstrument()
**
**  Description :   Split the instrument.
**                  At first, search in the hierarchy to see if the 2 legs
**                  are in it. If they are in the hierarchy, return the 2
**                  pointers. Else, make the 2 legs, and then add them into
**                  the hierarchy.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLeg1Ptr    :   Pointer of pointer to the first leg
**                  instrLeg2Ptr    :   Pointer of pointer to the second leg
**		            freeLegFlg	    :	will be TRUE if instr. pointer need to be freed, FALSE elsewhere
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  History     :   REF6938 - YST - 020307 - code reporting
**
*************************************************************************/
RET_CODE    FIN_SplitInstrument(DBA_DYNFLD_STP      instrPtr,
                                DBA_HIER_HEAD_STP   hierHead,
                                DBA_DYNFLD_STP      extPos,
                                DBA_DYNFLD_STP      *instrLeg1Ptr,
                                DBA_DYNFLD_STP      *instrLeg2Ptr,
				                FLAG_T		        *freeLegFlg,
                                NUMBER_T            *convertionFactor)
{
   /*  Local variables declarations    */
   RET_CODE        ret = RET_SUCCEED;
  /* REF5089 - AKO - 001026 - no more valid*/
  /*ENUM_T          natureInstr;
    DBA_DYNFLD_STP  termEvt = NULLDYNST;
	DBA_DYNFLD_STP  domainPtr;
    DATE_T          validDate;
    ID_T            oldUnderInstrId=0;
    ENUM_T          oldOptionClassEn=0;
    FLAG_T          oldStored = FALSE;
    ID_T            newUnderlyInstrId;
    ENUM_T          newOptionClassEn;*/

    /* REF5089 - AKO - 001026 */
    /*  Get the nature of the instrument    */
    /* Allocation of the term event structure */
    /* Store old values and replace with the ones which are in the term event structure */
    /* Get the domain pointer */
/*  natureInstr = GET_ENUM( instrPtr, A_Instr_NatEn);
    switch((ENUM_T)GET_ENUM( instrPtr, A_Instr_NatEn))
    {
        case    InstrNat_Future:
        case    InstrNat_Forward:
        case    InstrNat_Option:
        case    InstrNat_ExoticOptions:
        case    InstrNat_SwapOptions:
                domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
                validDate = GET_DATE(domainPtr,A_Domain_InterpFromDate);
                if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	                MSG_RETURN(RET_MEM_ERR_ALLOC);
                if ( (ret=DBA_GetTermEvt( instrPtr, validDate, termEvt))==RET_SUCCEED)
                {
                    oldUnderInstrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
                    oldOptionClassEn = GET_ENUM(instrPtr, A_Instr_OptionClassEn);
                    newUnderlyInstrId = GET_ID(termEvt, A_TermEvt_InstrUnderId);
                    newOptionClassEn = GET_ENUM(termEvt, A_TermEvt_OptClassEn);
                    SET_ID(instrPtr, A_Instr_UnderlyInstrId, newUnderlyInstrId);
                    SET_ENUM(instrPtr, A_Instr_OptionClassEn, newOptionClassEn);
                    oldStored = TRUE;
                }
                FREE_DYNST(termEvt, A_TermEvt);
        break;
        default:
                break;
    }
*/
    /*	By security */
    if  (ret==RET_SUCCEED)
    {
        *instrLeg1Ptr = NULLDYNST;
        *instrLeg2Ptr = NULLDYNST;
        *freeLegFlg	  = FALSE;
    }

    /*  Search in the hierarchy (if not exist, instrument will be created each time) */
    if (    (hierHead != NULL)  &&  (ret==RET_SUCCEED)  )
    {
	    ret =   FIN_SearchInstrLegInHier(   instrPtr,
                                            hierHead,
                                            instrLeg1Ptr,
                                            instrLeg2Ptr);
    }

    /*
        Test for the result of the Hierarchy search.
        If the pointers to the legs are equal to NULLDYNST, then
        make the 2 legs, and add them into the hierarchy.
    */
    if  ((ret==RET_SUCCEED)  &&  ((*instrLeg1Ptr==NULLDYNST)  ||  (*instrLeg2Ptr==NULLDYNST))  )
    {
        ret =   FIN_MakeInstrLeg(   instrPtr,
                                    hierHead,
                                    extPos,
                                    instrLeg1Ptr,
                                    instrLeg2Ptr,
                                    convertionFactor);
    }
    /* REF6938 - YST - 020307 : Load convertion factor from A_Instr_CompoQuantity temporary saved */
    else if ( (*instrLeg1Ptr)!=NULL && (*instrLeg2Ptr)!=NULL )
    {
       if ((InstrNat_Option==GET_ENUM( instrPtr, A_Instr_NatEn)) ||
           (InstrNat_ExoticOptions==GET_ENUM( instrPtr, A_Instr_NatEn)) ||
		   (InstrNat_Future == GET_ENUM(instrPtr, A_Instr_NatEn)))		/* PMSTA4551 - RAK - 080107 */
         {
            if (IS_NULLFLD((*instrLeg1Ptr), A_Instr_CompoQuantity)!=TRUE)
            {
                *convertionFactor = GET_NUMBER((*instrLeg1Ptr), A_Instr_CompoQuantity);
            }
        }
    }


    if (ret == RET_SUCCEED)
    {
	    ret =   FIN_SetOrderLegs(       instrPtr,
                                        hierHead,
                                        instrLeg1Ptr,
                                        instrLeg2Ptr);
    }

    /* Because of they couldn't be add in hiearchy */
    if (hierHead == NULL)
	    *freeLegFlg = TRUE;
    /* REF5089 - AKO - 001026 - no more valid */
    /* Replace stored values
    if  (oldStored==TRUE)
    {
        SET_ID(instrPtr, A_Instr_UnderlyInstrId, oldUnderInstrId);
        SET_ENUM(instrPtr, A_Instr_OptionClassEn, oldOptionClassEn);
    }*/

    /* Return value */
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_GenInstrCompo()
**
**  Description :   Fill the instrCompo array with the legs values.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLeg1Ptr    :   Pointer to the first leg
**                  instrLeg2Ptr    :   Pointer to the second leg
**                  instrCategory   :   Enum to the category of the instrument
**                  compoTab        :   Pointer to the array of Components
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  History     :   REF6938 - YST - 020307 - code reporting
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC RET_CODE FIN_GenInstrCompo(DBA_DYNFLD_STP      instrPtr,
                                  DBA_HIER_HEAD_STP   hierHead,
                                  DBA_DYNFLD_STP      extPos,
                                  DBA_DYNFLD_STP      instrLeg1Ptr,
                                  DBA_DYNFLD_STP      instrLeg2Ptr,
                                  NUMBER_T            convertionFactor,
                                  INSTRCATEGORY_ENUM  instrCategory,
	                              STNSPECTREATMENT_ENUM STNSpecificEn, /* PMSTA-34752 - RAK - 190221 - Grand-father is a Tarko */
                                  DBA_DYNFLD_STP      **compoTab)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    ID_T                parInstrId;
    ID_T                instrId;
    DATE_T              beginDate;
    DATE_T              endDate;
    NUMBER_T            quantity;
    ID_T                refCurrId;
    ID_T                leg1CurrId;
    ID_T                leg2CurrId;
    EXCHANGE_T          exchangeRate;
    DATETIME_T          refDateTime;
    FIN_EXCHARG_ST      exchArgSt;
    RET_CODE            ret =   RET_SUCCEED;
	DBA_DYNFLD_STP      domainPtr;
    DATE_T              validDate;
    FLAG_T              isOpConvertBondFlg=FALSE;

    /**************************************
    ***  Generate the first instrCompo  ***
    **************************************/

    /*  Set the parent instrument identifier    */
    parInstrId  =   GET_ID(instrLeg1Ptr, A_Instr_ParentInstrId);
    SET_ID( (*compoTab)[0], A_InstrCompo_ParentInstrId, parInstrId);

    /*  Set the instrument identifier   */
    instrId =   GET_ID(instrLeg1Ptr, A_Instr_Id);
    SET_ID( (*compoTab)[0], A_InstrCompo_InstrId, instrId);

    /*  Set the begin date  */
    beginDate   =   GET_DATE(instrLeg1Ptr, A_Instr_BeginDate);
	SET_DATE((*compoTab)[0], A_InstrCompo_BeginDate, beginDate);

    /*  Set the end date    */
    endDate   =   GET_DATE(instrLeg1Ptr, A_Instr_EndDate);
    SET_DATE( (*compoTab)[0], A_InstrCompo_EndDate, endDate);

    /*  Set the rank    */
    SET_SMALLINT( (*compoTab)[0], A_InstrCompo_Rank, 0);

    /*  Set the quantity    */
    ret    =   FIN_ComputeQtyForInstrCompo( instrPtr,
                                            hierHead,
                                            extPos,
                                            instrLeg1Ptr,
                                            instrCategory,
                                            convertionFactor,
                                            NULL,
                                            1,
                                            &quantity);

	if (STNSpecificEn == StnSpecific_FXTarkoOption)
	{
		SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, TLS_Round(quantity, 1.0, RndRule_Nearest));
	}
	else
	{
		SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, quantity);
	}

    /***************************************
    ***  Generate the second instrCompo  ***
    ***************************************/

    /* REF5886 - RAK - 010304 - Convertible bond  */
    /* Don't generate it if instrument is an option of convertible bond */
    FIN_IsOptConvertBondFlg(instrPtr, hierHead, &isOpConvertBondFlg);
    if (isOpConvertBondFlg == TRUE)
        return(RET_SUCCEED);

    /*  Set the parent instrument identifier    */
    parInstrId  =   GET_ID(instrLeg2Ptr, A_Instr_ParentInstrId);
    SET_ID( (*compoTab)[1], A_InstrCompo_ParentInstrId, parInstrId);

    /*  Set the instrument identifier   */
    instrId =   GET_ID(instrLeg2Ptr, A_Instr_Id);
    SET_ID( (*compoTab)[1], A_InstrCompo_InstrId, instrId);

    /*  Set the begin date  */
    beginDate   =   GET_DATE(instrLeg2Ptr, A_Instr_BeginDate);
	SET_DATE((*compoTab)[1], A_InstrCompo_BeginDate, beginDate);

    /*  Set the end date    */
    endDate   =   GET_DATE(instrLeg2Ptr, A_Instr_EndDate);
    SET_DATE( (*compoTab)[1], A_InstrCompo_EndDate, endDate);

    /*  Set the rank    */
    SET_SMALLINT( (*compoTab)[1], A_InstrCompo_Rank, 1);

    /*  Set the quantity    */
    if (ret == RET_SUCCEED)
    {
	    ret = FIN_ComputeQtyForInstrCompo(  instrPtr,
                                            hierHead,
                                            extPos,
                                            instrLeg2Ptr,
                                            instrCategory,
                                            convertionFactor,
                                            instrLeg1Ptr,
                                            2, &quantity);
		switch (instrCategory)
		{
		case  InstrCategory_Options:
		case  InstrCategory_ExoticOptions:
		case  InstrCategory_ACDC:			/* PMSTA-34140 - RAK - 190131  */
		{
			MemoryPool			mp;

			DBA_DYNFLD_STP termEvtPtr = mp.allocDynst(FILEINFO, A_TermEvt);

			domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)); /* Get the domain pointer */
			validDate = GET_DATE(domainPtr, A_Domain_InterpFromDate); /* Get the FromDate from the domain */

			/* Get term event */
			/* PMSTA-34140 - RAK - 190131 quantity of underlying * market price of underlying leg */
			if (instrCategory == InstrCategory_ACDC)
			{
				/* market price of underlying (first leg instrument) */
				PRICE_T		        underMktPrice = 1.0;
				EXCHANGE_T		exch = 1.0;
				DATETIME_T		refDate;

				DbiConnectionHelper dbiConnHelper;
				DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Evt_Arg);
				DBA_DYNFLD_STP pricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

				if (GET_ID(instrPtr, A_Instr_Id) < 0)
				{
					SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
				}
				else
				{
					SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));
				}

				SET_DATE(getData, Evt_Arg_ValidDate, validDate);

				ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &termEvtPtr);

				memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

				refDate.date = GET_DATE(domainPtr, A_Domain_InterpFromDate);
				refDate.time = 0;

				if (FIN_InstrPrice(GET_ID(instrLeg1Ptr, A_Instr_Id), instrLeg1Ptr, refDate, NULLDYNST, 0, NULL, NULLDYNST,
					NULLDYNST, hierHead, pricePtr, FALSE) == RET_SUCCEED)
				{
					if (GET_ID(domainPtr, A_Domain_CurrId) != GET_ID(pricePtr, A_InstrPrice_CurrId))
					{
						FIN_GetExchRate(refDate, GET_ID(pricePtr, A_InstrPrice_CurrId),
							GET_ID(domainPtr, A_Domain_CurrId), (ID_T)0, NULLDYNST,
							NULLDYNST, &exchArgSt, &exch);
					}

					underMktPrice = GET_PRICE(pricePtr, A_InstrPrice_Price) * exch;
				}
				quantity *= underMktPrice;

				/* PMSTA-34672 - RAK - 190215         */
				/* As received like this from T24     */
				/* Accu is PUT, Decu is CALL          */
				/* and in case of Accumulator -> buy  */
				/*            and Decumulator -> sell */
				if (InstrumentNature::isAccumulator(instrPtr))
				{
					/*  Second leg  */
					SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity*(-1));
				}
				else /* isDecumulator */
				{
					/*  Second leg  */
					SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity);

					/*  First leg   */
					quantity = GET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity);
					SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, quantity*(-1));
				}

				/* PMSTA-34672 - RAK - 190215 - Read the exercicePrice */
				if (ret == RET_SUCCEED)
				{
					SET_PRICE((*compoTab)[0], A_InstrCompo_BasketExerPrice, GET_PRICE(termEvtPtr, A_TermEvt_ExerPrice));
				}
			}
			else
			{
				ENUM_T optionClassEn = OptClass_None;

				/* PMSTA-34752 - RAK - 190305 - Grand father is a tarko used the instrument classification */
				if (STNSpecificEn == StnSpecific_FXTarkoOption)
				{
					optionClassEn = GET_ENUM(instrPtr, A_Instr_OptionClassEn);
				}
				else
				{
					ret = DBA_GetTermEvt(instrPtr, validDate, termEvtPtr);

					/* Get the class of the option */
					if (ret == RET_SUCCEED && termEvtPtr != nullptr)
					{
						optionClassEn = GET_ENUM(termEvtPtr, A_TermEvt_OptionClassEn);
					}
				}

				switch (optionClassEn)
				{
				case    OptClass_Call:
					/*  Second leg  */
					SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity*(-1));
					/*  First leg   */
					quantity = GET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity);
					SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, quantity);
					break;

				case    OptClass_Put:
					/* REF6938 - YST - 020307 : Perform quantity (i.e delta) following to OptRiskRule nature */
					/* PMSTA-35504 - RAK - 190517 specific Tarko */
					if (STNSpecificEn == StnSpecific_FXTarkoOption ||
						(OptDelta_Full == GET_ENUM(domainPtr, A_Domain_OptRiskRuleEn)) ||
						(OptDelta_None == GET_ENUM(domainPtr, A_Domain_OptRiskRuleEn)))
					{
						/*  Second leg  */
						SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity);
						/*  First leg   */
						quantity = GET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity);
						SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, quantity*(-1));
					}
					else if (OptDelta_Delta == GET_ENUM(domainPtr, A_Domain_OptRiskRuleEn))
					{
						/*  Second leg  */
						SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity * (-1));
						/*  First leg   */
						quantity = GET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity);
						SET_NUMBER((*compoTab)[0], A_InstrCompo_Quantity, quantity);
					}
					break;

				default:
					SET_NUMBER((*compoTab)[1], A_InstrCompo_Quantity, quantity);
					break;

				}
			}
			break;
		}

        case    InstrCategory_ConvertibleBond:  /* REF5049 - AKO - 001114 */
                SET_NUMBER( (*compoTab)[1], A_InstrCompo_Quantity, quantity);
                break;

        case        InstrCategory_Swap:
        case        InstrCategory_ForexSwap:
                SET_NUMBER( (*compoTab)[1], A_InstrCompo_Quantity, quantity);
                break;

        case        InstrCategory_BondFutures:
        case        InstrCategory_BondForwards:
        case        InstrCategory_EquityFutures:
        case        InstrCategory_EquityForwards:
        case        InstrCategory_CurrencyFutures:
        case        InstrCategory_CurrencyForwards:
        default:
                SET_NUMBER( (*compoTab)[1], A_InstrCompo_Quantity, quantity*(-1));
                break;
        }
    }

    /*  Apply the exchange rate */
    if (ret==RET_SUCCEED)
    {
            /*  Get the currency id of the parent instrument    */
            refCurrId = GET_ID(instrPtr,A_Instr_RefCurrId);

            /*  Get the currency id of the leg1 */
            leg1CurrId = GET_ID(instrLeg1Ptr,A_Instr_RefCurrId);

            /*  Get the currency id of the leg2 */
            leg2CurrId = GET_ID(instrLeg2Ptr,A_Instr_RefCurrId);

            /*  Get the begin date of the instrument    */
            beginDate = GET_DATE(instrPtr,A_Instr_BeginDate);

            /*  Store the date into the DATETIME_T structure    */
            refDateTime.date=beginDate;
            refDateTime.time=0;

            /*  Get the actual exchange rate    */
            exchangeRate = GET_PRICE(extPos,ExtPos_SpotPrice);

            /*
                Test if the currency of the first leg is the same from the currency of the parent instrument
                And if the actual exchange rate is equal to 1
            */
            if  (   (leg1CurrId!=refCurrId) &&  (exchangeRate==1)   )
            {
                    /*  Build arguments */
                    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

                    /*  Compute the exchange rate       */
                    ret = FIN_GetExchRate(      refDateTime,
                                                refCurrId,
                                                leg1CurrId,
                                                (ID_T) 0,
                                                NULLDYNST,
												extPos,			/* PMSTA01649 - TGU - 070402 */
                                                &exchArgSt,
                                                &exchangeRate);

                    if  (ret==RET_SUCCEED)
                    {
                            /*  Get the quantity stored in the composition array        */
                            quantity = GET_NUMBER((*compoTab)[0],A_InstrCompo_Quantity);

                            /*  Apply the exchange rate */
                            quantity = quantity * exchangeRate;

                            /* Store the new quantity into the composition array        */
                            SET_NUMBER((*compoTab)[0],A_InstrCompo_Quantity,quantity);
                    }
            }

            /*
                Test if the currency of the second leg is the same of the parent instrument
                And if the actual exchange rate is equal to 1
            */
            if  (       (leg2CurrId!=refCurrId) &&      (ret==RET_SUCCEED)  &&  (exchangeRate==1)   )
            {
                    /*  Build arguments */
                    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

                    /*  Compute the exchange rate       */
                    ret = FIN_GetExchRate(      refDateTime,
                                                refCurrId,
                                                leg2CurrId,
                                                (ID_T) 0,
                                                NULLDYNST,
												extPos,			/* PMSTA01649 - TGU - 070402 */
                                                &exchArgSt,
                                                &exchangeRate);

                    if  (ret==RET_SUCCEED)
                    {
                            /*  Get the quantity stored in the composition array        */
                            quantity = GET_NUMBER((*compoTab)[1],A_InstrCompo_Quantity);

                            /*  Apply the exchange rate */
                            quantity = quantity * exchangeRate;

                            /* Store the new quantity into the composition array        */
                            SET_NUMBER((*compoTab)[1],A_InstrCompo_Quantity,quantity);
                    }
            }
    }


    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_SearchInstrLegInHier()
**
**  Description :   Search the legs from the hierarchy.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLeg1Ptr    :   Pointer of pointer to the first leg
**                  instrLeg2Ptr    :   Pointer of pointer to the second leg
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  History     :
**
*************************************************************************/
RET_CODE FIN_SearchInstrLegInHier(       DBA_DYNFLD_STP      instrPtr,
                                         DBA_HIER_HEAD_STP   hierHead,
                                         DBA_DYNFLD_STP      *instrLeg1Ptr,
                                         DBA_DYNFLD_STP      *instrLeg2Ptr)
{
    /*  Local variables declarations    */
	DBA_DYNFLD_STP  *instrArray    =   (DBA_DYNFLD_STP*)NULL;
    RET_CODE        ret;
	int             instrNbr;

	/* Extract the legs if they exist */
    ret =   DBA_ExtractHierEltRecWithFilterSt(  hierHead,
                                                A_Instr,
                                                FALSE,
					                            FIN_FilterInstrLegs,
                                                instrPtr,
                                                NULLFCT,
					                            &instrNbr,
                                                &instrArray);

	/*  Test if the legs are extracted  */
    if  (   (ret==RET_SUCCEED)  &&  (instrNbr>1)    )
    {
        /*  Get the first leg   */
        *instrLeg1Ptr   =   instrArray[0];

        /*  Get the second leg  */
        *instrLeg2Ptr   =   instrArray[1];

        /*  Free the array  */
        FREE(instrArray);
    }

    /*  Return value    */
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_MakeInstrLeg()
**
**  Description :   Make the 2 legs and add them into the hierarchy.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLeg1Ptr    :   Pointer of pointer to the first leg
**                  instrLeg2Ptr    :   Pointer of pointer to the second leg
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22111999
**
**  History     :   REF6938 - YST - 020307 - code reporting
**
*************************************************************************/
STATIC RET_CODE FIN_MakeInstrLeg(DBA_DYNFLD_STP      instrPtr,
                                 DBA_HIER_HEAD_STP   hierHead,
                                 DBA_DYNFLD_STP      extPos,
                                 DBA_DYNFLD_STP      *instrLeg1Ptr,
                                 DBA_DYNFLD_STP      *instrLeg2Ptr,
                                 NUMBER_T            *convertionFactor)
{
    /*  Local variables declarations    */
    DBA_DYNFLD_STP      underInstr=NULLDYNST, *flowTab=NULLDYNSTPTR, domainPtr=NULLDYNST;
    RET_CODE            ret =   RET_SUCCEED;
    DATETIME_T          validDate;
    FLAG_T              addLeg1HierFlg=FALSE, addLeg2HierFlg=FALSE;
    INSTRCATEGORY_ENUM  instrCategory;
    int                 allocSz=0, flowNbr=0;
    FLAG_T              underInstrFreeFlg=FALSE;

    /*  Get the category of the instrument  */
    memset(&validDate,0,sizeof(DATETIME_T));
    /*domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)); AKO - 001113 */
    if ((domainPtr=DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)))==NULLDYNST)
    { return(RET_GEN_ERR_INVARG);}
    validDate.date = GET_DATE(domainPtr,A_Domain_InterpFromDate);

    instrCategory   =   FIN_InstrCategory(instrPtr, hierHead);

    /***************************
    ***  Make the first leg  ***
    ***************************/
    if  ((*instrLeg1Ptr)==NULLDYNST)
    {
        switch  (instrCategory)
        {
        case    InstrCategory_BondFutures:

            /*  Get the CTD instrument */
            /*  If CTD instrument wasn't in hierarchy, add it */
            ret =   FIN_GetCTDInstrument(   instrPtr,
                                            hierHead,
                                            extPos,
                                            instrLeg1Ptr,
                                            convertionFactor);

			/* PMSTA4551 - RAK - 080107 - Save convertion factor into A_Instr_CompoQuantity temporary */
			if (ret == RET_SUCCEED &&
                (*instrLeg1Ptr) != NULLDYNST &&
                instrPtr != NULLDYNST)
            {
                ID_T parInstrId=0;
                if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	                parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
                else
	                parInstrId = GET_ID(instrPtr, A_Instr_Id);

                SET_ID((*instrLeg1Ptr), A_Instr_ParentInstrId, parInstrId);

                if (IS_NULLFLD((*instrLeg1Ptr), A_Instr_LegParInstrId)==TRUE)
                {
                    SET_ID((*instrLeg1Ptr), A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));
                    SET_NUMBER((*instrLeg1Ptr), A_Instr_CompoQuantity, (*convertionFactor));
                }

            }
            addLeg1HierFlg = TRUE; /* PMSTA07185 - DDV - 081023 - Purify */
            break;

        case    InstrCategory_BondForwards:
        case    InstrCategory_EquityFutures:
        case    InstrCategory_EquityForwards:

            /*  Get the underlying instrument from database */
            ret =   DBA_GetInstrById(	GET_ID(instrPtr,A_Instr_UnderlyInstrId),
							            TRUE,            /* If it wasn't in hierarchy, add it */
							            &addLeg1HierFlg, /* because of add, will be FALSE */
							            instrLeg1Ptr,
							            hierHead,
							            UNUSED,
							            UNUSED);
            break;

        case    InstrCategory_CurrencyFutures:
        case    InstrCategory_CurrencyForwards:
	    case	InstrCategory_Swap:
	    case	InstrCategory_ForexSwap:
		case    InstrCategory_ConvertibleBond:
            ret = FIN_CreateInstrLeg(instrPtr, instrLeg1Ptr);
            addLeg1HierFlg = TRUE;
            break;


		case    InstrCategory_Options:
        case    InstrCategory_ExoticOptions:
		case	InstrCategory_ACDC: /* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */

			/*  Get the underly instrument and compute the delta */
			/*  If underly instrument wasn't in hierarchy, add it */
			ret = FIN_GetDeltaInstrument(instrPtr,
										hierHead,
										extPos,
										instrLeg1Ptr,
										convertionFactor,
										&addLeg1HierFlg);   /*  FPL-PMSTA09803-100510   */

/* REF5300 - RAK - 010405 */
			if (ret == RET_SUCCEED &&
				(*instrLeg1Ptr) != NULLDYNST &&
				instrPtr != NULLDYNST)
			{
				ID_T parInstrId = 0;
				if (GET_ID(instrPtr, A_Instr_Id) <= 0)
					parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
				else
					parInstrId = GET_ID(instrPtr, A_Instr_Id);

				SET_ID((*instrLeg1Ptr), A_Instr_ParentInstrId, parInstrId);

				/* REF6057 - AKO - 010914 : we must get this instrument later from hierarchy */
				if (IS_NULLFLD((*instrLeg1Ptr), A_Instr_LegParInstrId) == TRUE)
				{
					SET_ID((*instrLeg1Ptr), A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));
					/* REF6938 - YST - 020307 : Save convertion factor into A_Instr_CompoQuantity temporary */
					SET_NUMBER((*instrLeg1Ptr), A_Instr_CompoQuantity, (*convertionFactor));
				}

			}

			/*addLeg1HierFlg = TRUE;    FPL-PMSTA09803-100510   */ /* PMSTA07185 - DDV - 081023 - Purify */
			break;

		case    InstrCategory_Others:
		default:    /*  For the Lint utility    */
			break;
		}
	}

	/*****************************
	 ***  Make the second leg  ***
	 *****************************/
	if ((*instrLeg2Ptr) == NULLDYNST)
	{
		switch (instrCategory)
		{

		case    InstrCategory_ConvertibleBond:  /* REF5049 - AKO - 001205 */
			*convertionFactor = 0.0;
			if (RET_SUCCEED == ret)
			{
				if ((ret = SCE_GetExchEvtConvBondInstr(
					instrPtr, &underInstr, &flowTab, &allocSz, &flowNbr,
					&underInstrFreeFlg, validDate, hierHead)) != RET_SUCCEED)
				{
					MSG_SendMesg(RET_FIN_ERR_SCE_INVDATA, 1, FILEINFO, "FIN_MakeInstrLeg",
						GET_CODE(instrPtr, A_Instr_Cd),
						"SCE_GetExchEvtConvBondInstr : Retrieving Exchange Event failed !");
					ret = RET_FIN_ERR_SCE_INVDATA;
				}
			}
			if (RET_SUCCEED == ret)
			{
				if ((ret = FIN_CreateInstrLeg(instrPtr, instrLeg2Ptr)) == RET_SUCCEED)
				{
					addLeg2HierFlg = TRUE;
					if ((ret = FIN_CreateConvBondInstrLeg2AsOption(instrPtr,
						underInstr,
						flowTab[0],
						extPos,
						instrLeg2Ptr)) != RET_SUCCEED)
					{
						addLeg2HierFlg = FALSE;
						FREE_DYNST((*instrLeg2Ptr), A_Instr); /* PMSTA07185 - DDV - 081023 - Purify */
						if (addLeg1HierFlg == TRUE)
						{
							addLeg1HierFlg = FALSE;
							FREE_DYNST((*instrLeg1Ptr), A_Instr); /* PMSTA07185 - DDV - 081023 - Purify */
						}
					}
				}
			}
			break;

		/* PMSTA-34140 - RAK - 190201 - cash leg instrument */
		case InstrCategory_ACDC:
			if( (*instrLeg2Ptr) == NULLDYNST && ret == RET_SUCCEED)
			{
				ret = FIN_CreateACDCCashInstrLeg(instrPtr, instrLeg2Ptr, &addLeg2HierFlg, hierHead);

				/*  Should free the first leg ? */
				if ((ret != RET_SUCCEED) && (addLeg1HierFlg == TRUE))
				{
					FREE_DYNST((*instrLeg1Ptr), A_Instr);
					addLeg1HierFlg = FALSE;
				}
			}
			break;

         default:
            /****************************
            ***  Make the second leg ***
            ****************************/
            if  ((*instrLeg2Ptr)==NULLDYNST)
            {
                if  (ret==RET_SUCCEED)
                    ret =   FIN_CreateInstrLeg(instrPtr, instrLeg2Ptr);

                /*  Should free the first leg ? */
                if  ((ret!=RET_SUCCEED)  &&  (addLeg1HierFlg==TRUE))
                {
                    FREE_DYNST((*instrLeg1Ptr), A_Instr); /* PMSTA07185 - DDV - 081023 - Purify */
                    addLeg1HierFlg = FALSE ;    /*  FPL-PMSTA09803-100510   */
                }

                addLeg2HierFlg = TRUE;
            }
            break;
        }
    }


    /***********************************
    ***  Set values into the 2 legs  ***
    ***********************************/
    /* REF4367 - AKO - 020617 */
    if  (ret==RET_SUCCEED && (*instrLeg1Ptr) != NULLDYNST && (*instrLeg2Ptr) != NULLDYNST)
        ret =   FIN_SetValuesLegs(  instrPtr,
                                    hierHead,
                                    instrCategory,
                                    extPos,
                                    *instrLeg1Ptr,
                                    *instrLeg2Ptr);

    /************************************
    ***  Add them into the hierarchy  ***
    ************************************/
    if  (hierHead != NULL)
    {
        /* PMSTA07185 - DDV - 081023 - Purify */
        if  (ret==RET_SUCCEED)
        {
            ret =   FIN_AddLegsIntoHier(*instrLeg1Ptr,
                                        addLeg1HierFlg,
                                        *instrLeg2Ptr,
                                        addLeg2HierFlg,
                                        hierHead,
                                        instrCategory);
        }
        else
        {
            if (addLeg1HierFlg == TRUE) /*  FPL-PMSTA09803-100510   */
            {
                FREE_DYNST((*instrLeg1Ptr), A_Instr);
                addLeg1HierFlg = FALSE ;    /*  FPL-PMSTA09803-100510   */
            }
            FREE_DYNST((*instrLeg2Ptr), A_Instr);
        }
    }

    /*  Return value    */
    if (underInstrFreeFlg == TRUE) {FREE_DYNST(underInstr, A_Instr);}
    if (flowNbr>0 && allocSz>0) DBA_FreeDynStTab(flowTab, flowNbr, Flow);

    /* REF7836 - AKO - 020918 */
    if ( ((*instrLeg1Ptr)==NULLDYNST) || ((*instrLeg2Ptr)==NULLDYNST) )
    {
        MSG_SendMesg(RET_FIN_ERR_SCE_INVDATA, 1, FILEINFO,"FIN_MakeInstrLeg",
            GET_CODE(instrPtr, A_Instr_Cd),
            "At least one Leg of the parent instrument not created !");
        ret=RET_FIN_ERR_SCE_INVDATA;
    }


    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateACDCCashInstrLeg()
**
**  Description :   Create a leg from the original instrument.
**
**  Arguments   :   instrPtr        Pointer to the original instrument
**		            instrLegPtr     Pointer to the newer leg.
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-34140 - RAK - 190201
**
*************************************************************************/
STATIC RET_CODE FIN_CreateACDCCashInstrLeg(DBA_DYNFLD_STP    instrPtr,
										   DBA_DYNFLD_STP    *instrLegPtr,
										   FLAG_T		     *addLegHierFlg,
										   DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE	ret = RET_SUCCEED;

	MemoryPool mp;
	DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Get_Arg);
	DBA_DYNFLD_STP instrRefCurr = mp.allocDynst(FILEINFO, A_Instr);

	/* An offsetting cash position would be shown in the currency of the note */
	SET_ID(getData, Get_Arg_RefCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
	SET_ENUM(getData, Get_Arg_NatEn, InstrNat_CashAcct);

	if (DBA_Get2(Instr, UNUSED, Get_Arg, getData, A_Instr, &instrRefCurr,
		         UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/* clear error message */
		DBA_DYNFLD_STP	currPtr = NULL;
		FLAG_T          freeFlag = FALSE;

		if (DBA_GetCurrById(GET_ID(getData, Get_Arg_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 10, FILEINFO, GET_CODE(currPtr, A_Curr_Cd));}
		else
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 11, FILEINFO, GET_ID(getData, Get_Arg_RefCurrId));}

		if (freeFlag == TRUE) { FREE_DYNST(currPtr, A_Curr); }
		return(RET_DBA_ERR_NODATA);
	}

	ret = DBA_GetInstrById(GET_ID(instrRefCurr, A_Instr_Id),
						   TRUE, addLegHierFlg, instrLegPtr, hierHead,	/* add in hier, no free */
						   UNUSED, UNUSED);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrLeg()
**
**  Description :   Create a leg from the original instrument.
**
**  Arguments   :   instrPtr        Pointer to the original instrument
**		            instrLegPtr     Pointer to the newer leg.
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
**  Modification:   REF11114 - TEB - 050412
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrLeg(DBA_DYNFLD_STP  instrPtr,
                                   DBA_DYNFLD_STP  *instrLegPtr)
{
    /*  Memory allocation for the leg */
    *instrLegPtr   =   ALLOC_DYNST(A_Instr);

    /*  Test for success    */
	if  (*instrLegPtr == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

    /*  Copy the parent instrument to the leg */
	COPY_DYNST((*instrLegPtr), instrPtr, A_Instr);

	/* REF11114 - TEB - 050412 */
	/*  Set the identifier to null  */
    SET_NULL_ID((*instrLegPtr),A_Instr_Id);

    /*  Return value    */
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_FilterInstrLegs()
**
**  Description :   Verify if instr legs are already in hierarchy.
**
**  Arguments   :   instrLegPtr     dynamic structure pointer
**                  dynStTp         dynamic structure definition
**		            instrPtr        parameter structure pointer
**
**  Return      :   TRUE (extract) or FALSE
**
**  Creation	:   DEV1055 - CSA - 23111999
**
*************************************************************************/
STATIC int FIN_FilterInstrLegs( DBA_DYNFLD_STP  instrLegPtr,
                                DBA_DYNST_ENUM  ,
                                DBA_DYNFLD_STP  instrPtr)
{
	/*  Local variables declaration */
    int     ret =   FALSE;

    /*  Get the parent instr identifier */
    ID_T parentInstrId   =   GET_ID(instrPtr, A_Instr_Id);

    /*  Test if the parent identifier is equal to parent identifer to the leg   */
    if  (GET_ID(instrLegPtr, A_Instr_LegParInstrId) == parentInstrId)
        ret =   TRUE;

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesLegs()
**
**  Description :   Set values into the newer legs.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrCategory   Enum to the category of the instrument
**		            instrLeg1Ptr    Pointer to the first leg
**                  instrLeg2Ptr    Pointer to the second leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 23111999
**  Modification:   REF5049 - AKO - 001114
**  Modification:   REF6057 - AKO - 010914 - Wrong decomposition of futures, froward and options in risk view
**                  REF5941 - YST - 011219 - swap mgmt extension, swap "bris�"
**                  REF5941 - YST - 020213
**                  REF5941 - YST - 020508
**                  REF7782 - YST - 020904
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesLegs(DBA_DYNFLD_STP      instrPtr,
                                  DBA_HIER_HEAD_STP   hierHead,
                                  INSTRCATEGORY_ENUM  instrCategory,
                                  DBA_DYNFLD_STP      extPos,
                                  DBA_DYNFLD_STP      instrLeg1Ptr,
                                  DBA_DYNFLD_STP      instrLeg2Ptr)
{
	/*  Local variables declaration */
    DBA_DYNFLD_STP  *recInterCond = (DBA_DYNFLD_STP*)NULL, *paidInterCond = (DBA_DYNFLD_STP*)NULL;
    int             interCondNbr = 0, recInterCondNbr = 0, paidInterCondNbr = 0;
    DATETIME_T      fDateTime, tDateTime;
    FLAG_T          freeRecInterCondFlg = FALSE, freePaidInterCondFlg = FALSE;
    DATE_T          endDateRecInterCond = 0, endDatePaidInterCond = 0, begDateRecInterCond = 0,	begDatePaidInterCond=0; /* REF10094 - RAK - 040519 */
    ID_T            recFloatInstrId = 0, paidFloatInstrId = 0;
    RET_CODE        ret = RET_SUCCEED;

    /*  Set values for this cases   */
    switch  (instrCategory)
    {
    case    InstrCategory_BondFutures:
    case    InstrCategory_BondForwards:
            /*ret =   FIN_SetValuesForDiscountOfBondFutures( instrPtr, hierHead, extPos, instrLeg2Ptr);*/ /* REF6057 - AKO - 010914 */

        if ((ret =   FIN_SetValuesForDiscountOfBondFutures( instrPtr, hierHead, extPos, instrLeg2Ptr))==RET_SUCCEED)
         {  /* REF6057 - AKO - 010914 */
            /* Leg parent (because of legs must be different for generic instrument */
            SET_ID(instrLeg1Ptr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));
         }


        break;

    case    InstrCategory_EquityFutures:
    case    InstrCategory_EquityForwards:
        ret = FIN_SetValuesForDiscountOfEquity( instrPtr, hierHead, extPos, instrLeg2Ptr);
        if (instrLeg1Ptr!=NULLDYNST)    /* REF6045 - AKO - 010719 */
        {
            SET_ID(instrLeg1Ptr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));
        }

        break;

    case    InstrCategory_CurrencyFutures:
    ret =   FIN_SetValuesForDiscountOfCurrencyLeg1( instrPtr, hierHead, extPos, instrLeg1Ptr);
        if  (ret==RET_SUCCEED)
            ret = FIN_SetValuesForDiscountOfCurrencyLeg2( instrPtr, hierHead, extPos, instrLeg2Ptr);
        break;

	/* PMSTA-10439 - RAK - 100830 - treat differently fwd on currency */
	case    InstrCategory_CurrencyForwards:
		{
			MASK_T	applRiskCashLegRuleMask;	/* PMSTA-18096-CHU-140625 */

			ret =   FIN_SetValuesForDiscountOfCurrencyLeg1( instrPtr, hierHead, extPos, instrLeg1Ptr);
			if  (ret==RET_SUCCEED)
				ret = FIN_SetValuesForFwdCashLeg2( instrPtr, hierHead, extPos, instrLeg2Ptr);

			/* < PMSTA-18096-CHU-140625 */
			GEN_GetApplInfo(ApplRiskCashLegRuleMask, &applRiskCashLegRuleMask);
			if ((FLAG_T)GET_BIT(applRiskCashLegRuleMask, FWD_CASH_LEG) == TRUE)
			{
				ID_T riskOrigInstrId=0;
				if (GET_ID(instrPtr, A_Instr_Id) <= 0)
					riskOrigInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
				else
					riskOrigInstrId = GET_ID(instrPtr, A_Instr_Id);
				SET_ID((instrLeg1Ptr), A_Instr_RiskOrigInstrId, riskOrigInstrId);
				SET_ID((instrLeg2Ptr), A_Instr_RiskOrigInstrId, riskOrigInstrId);
			}
			/* > PMSTA-18096-CHU-140625 */
		}
        break;

    case    InstrCategory_ForexSwap:
	    ret =   FIN_SetValuesForDiscountOfForexSwapPaidLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
        if  (ret == RET_SUCCEED)
            ret = FIN_SetValuesForDiscountOfForexSwapRecLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
	break;

    case    InstrCategory_Swap:
        /* REF5941 - YST - 011219 */
        /* if InterCd_Evt, the interest rate condition sub-tables for the instrument swap
            should be only used in the case of "swap bris�" */
        if ((INTERCD_ENUM) GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Evt)
	    {
            fDateTime.date = GET_DATE(instrPtr, A_Instr_BeginDate);
		    fDateTime.time = 0;

            if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE)
                tDateTime.date = DATE_Move(fDateTime.date, 50, Year);
            else
                tDateTime.date = GET_DATE(instrPtr, A_Instr_EndDate);
		    tDateTime.time = 0;

            ret = DBA_SelectInterCond2(instrPtr, fDateTime, tDateTime, &recInterCond, &recInterCondNbr,
					                  &freeRecInterCondFlg, hierHead, InterCondNat_ToRecev);
            if (ret == RET_SUCCEED)
                 ret = DBA_SelectInterCond2(instrPtr, fDateTime, tDateTime, &paidInterCond, &paidInterCondNbr,
					                  &freePaidInterCondFlg, hierHead, InterCondNat_ToPaid);
            if (ret == RET_SUCCEED)
            {
                interCondNbr = recInterCondNbr + paidInterCondNbr;
                if ((interCondNbr < 3) || (interCondNbr > 6))
                {
                    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_SetValuesLegs",
			                GET_CODE(instrPtr, A_Instr_Cd),
			                "invalid number of interest rate conditions");
                    ret = RET_FIN_ERR_INVDATA;
                }
                else if (3 == interCondNbr || (1 == paidInterCondNbr && 3 == recInterCondNbr) ||
                        (1 == recInterCondNbr && 3 == paidInterCondNbr))
                {
                    /* REF5941 - YST 020201 - changed 0202113 and 020508
                       test if standard fixed/floating swap "bris�" is well defined */
                    ret = FIN_TestSwapBriseInterCond(recInterCond, recInterCondNbr, &begDateRecInterCond, &endDateRecInterCond, &recFloatInstrId);
                    if (ret == RET_SUCCEED)
                        ret = FIN_TestSwapBriseInterCond(paidInterCond, paidInterCondNbr, &begDatePaidInterCond, &endDatePaidInterCond, &paidFloatInstrId);

                    if (ret != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_SetValuesLegs",
			                GET_CODE(instrPtr, A_Instr_Cd),
			                "interest rate conditions not well defined");
                        ret = RET_FIN_ERR_INVDATA;
                    }
                    else if (extPos != NULLDYNST &&
                        (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
                        (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
                    {
                        /* REF5941 - YST - 020207 */
                       ret = FIN_SetValuesForSwapBriseLegs(instrPtr, instrLeg2Ptr, instrLeg1Ptr, InterCondNat_ToPaid,
                                                            InterCondNat_ToRecev,
															begDatePaidInterCond, begDateRecInterCond,	/* REF10094 - RAK - 040519 */
															endDatePaidInterCond, endDateRecInterCond,
                                                            recFloatInstrId, paidFloatInstrId);

                        if (ret == RET_SUCCEED && IS_NULLFLD(instrLeg1Ptr, A_Instr_FloatInstrId) == TRUE)
                        {
                            ret = FIN_SetValuesForPaidSwapFixLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFloatLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                        else if (ret == RET_SUCCEED)
                        {
                            ret = FIN_SetValuesForPaidSwapFloatLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFixLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                    }
                    else
                    {
                        /* REF5941 - YST - 020207 */
                        ret = FIN_SetValuesForSwapBriseLegs(instrPtr, instrLeg2Ptr, instrLeg1Ptr, InterCondNat_ToRecev,
                                                            InterCondNat_ToPaid,
															begDateRecInterCond, begDatePaidInterCond,	/* REF10094 - RAK - 040519 */
															endDateRecInterCond, endDatePaidInterCond,
                                                            recFloatInstrId, paidFloatInstrId);

                        if (ret == RET_SUCCEED && IS_NULLFLD(instrLeg1Ptr, A_Instr_FloatInstrId) == TRUE)
                        {
                           ret =   FIN_SetValuesForPaidSwapFloatLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFixLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                        else if (ret == RET_SUCCEED)
                        {
                            ret =   FIN_SetValuesForPaidSwapFixLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFloatLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                    }
                }
                /* interCondNbr == 4, 5 or 6  */
                else
                {
                    /* REF5941 - YST - 020201 - changed 020213 and 020508
                    test if floating/floating swap "bris�" is well defined */
                    ret = FIN_TestSwapBriseInterCond(recInterCond, recInterCondNbr, &begDateRecInterCond, &endDateRecInterCond, &recFloatInstrId);
                    if (ret == RET_SUCCEED)
                        ret = FIN_TestSwapBriseInterCond(paidInterCond, paidInterCondNbr, &begDatePaidInterCond, &endDatePaidInterCond, &paidFloatInstrId);

                    if (ret != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_SetValuesLegs",
			                GET_CODE(instrPtr, A_Instr_Cd),
			                "interest rate conditions not well defined");
                        ret = RET_GEN_ERR_INVARG;
                    }
                    else
                    {
                        /* REF5941 - YST - 020207 */
                        ret = FIN_SetValuesForSwapBriseLegs(instrPtr, instrLeg2Ptr, instrLeg1Ptr, InterCondNat_ToRecev,
                                                            InterCondNat_ToPaid,
															begDateRecInterCond, begDatePaidInterCond,	/* REF10094 - RAK - 040519 */
															endDateRecInterCond, endDatePaidInterCond,
                                                            recFloatInstrId, paidFloatInstrId);
                        if  (ret == RET_SUCCEED)
                            ret =   FIN_SetValuesForDiscountOfSwapPaidLeg(instrPtr, extPos, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                        if  (ret == RET_SUCCEED)
                            ret = FIN_SetValuesForDiscountOfSwapRecLeg(instrPtr, extPos, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                    }
                }
                if (freeRecInterCondFlg == TRUE)
                    DBA_FreeDynStTab(recInterCond, recInterCondNbr, A_InterCond);
                else
                    FREE(recInterCond);

                if (freePaidInterCondFlg == TRUE)
                    DBA_FreeDynStTab(paidInterCond, paidInterCondNbr, A_InterCond);
                else
                    FREE(paidInterCond);
            }
        }
        /* normal swap */
        else
        {

        /* REF5529 - RAK - 010201 */
            /*if ((VALRULE_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap &&
                extPos != NULLDYNST &&
                (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
                (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
            {
                ret =   FIN_SetValuesForDiscountOfSwapRecLeg( instrPtr, hierHead, extPos, instrLeg1Ptr);
                if  (ret == RET_SUCCEED)
                    ret = FIN_SetValuesForDiscountOfSwapPaidLeg( instrPtr, hierHead, extPos, instrLeg2Ptr);
            }
            else
            {
                ret =   FIN_SetValuesForDiscountOfSwapPaidLeg( instrPtr, hierHead, extPos, instrLeg1Ptr);
                if  (ret == RET_SUCCEED)
                    ret = FIN_SetValuesForDiscountOfSwapRecLeg( instrPtr, hierHead, extPos, instrLeg2Ptr);
            }
            */

            /* -------------------------------------------------------- */
            /* REF5529 - RAK - 010206 - The key of mystery              */
            /* -------------------------------------------------------- */
            /*                          | Paid            | Received    */
            /* -------------------------------------------------------- */
            /* FLOAT                    | (1) no copy     | (2) copy    */
            /* copy if float == NULL    | (4) copy        | (3) no copy */
            /* -------------------------------------------------------- */
            /* FIX                      | (2) no copy     | (1) copy    */
            /* copy if float != NULL    | (3) copy        | (4) no copy */
            /* -------------------------------------------------------- */
            /* (1)  swap sell + float != NULL                           */
            /* (2)  swap sell + float == NULL                           */
            /* (3)  swap buy  + float != NULL                           */
            /* (4)  swap buy  + float == NULL                           */
            /* -------------------------------------------------------- */
		    switch ((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn)) /* YST - 020201 - change cast of enum */
	        {
	            case SubNat_FixFloatStdSwap :
                case SubNat_FixFltSwapHedgFix:  /* REF7782 - YST - 020904 */
                    if (extPos != NULLDYNST &&
                        (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
                        (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
                    {
                        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE)
                        {
                            ret =   FIN_SetValuesForPaidSwapFixLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFloatLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                        else
                        {
                            ret =   FIN_SetValuesForPaidSwapFloatLeg(instrPtr,  instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFixLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                    }
                    else
                    {
                        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE)
                        {
                           ret =   FIN_SetValuesForPaidSwapFloatLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFixLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                        else
                        {
                            ret =   FIN_SetValuesForPaidSwapFixLeg(instrPtr, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                            if  (ret == RET_SUCCEED)
                                ret = FIN_SetValuesForRecSwapFloatLeg(instrPtr, instrLeg2Ptr); /* REF7475 - YST - 020516 */
                        }
                    }
		            break;

	            case SubNat_FixFixStdSwap :
                case SubNat_FltFltStdSwap :
                    ret =   FIN_SetValuesForDiscountOfSwapPaidLeg(instrPtr, extPos, instrLeg1Ptr); /* REF7475 - YST - 020516 */
                    if  (ret == RET_SUCCEED)
                        ret = FIN_SetValuesForDiscountOfSwapRecLeg(instrPtr, extPos, instrLeg2Ptr); /* REF7475 - YST - 020516 */
		            break;
	        }
        }
        break;
    case    InstrCategory_Options:
    case    InstrCategory_ExoticOptions:
    {
        FLAG_T  isOpConvertBondFlg=FALSE;
        FIN_IsOptConvertBondFlg(instrPtr, hierHead, &isOpConvertBondFlg);
        if (isOpConvertBondFlg == TRUE)
            ret =   FIN_SetValuesForFixedIncOfOptionLeg( instrPtr, hierHead, extPos, instrLeg2Ptr); /* REF7475 - YST - 020516 */
        else
	        ret =   FIN_SetValuesForDiscountOfOptionLeg( instrPtr, hierHead, extPos, instrLeg2Ptr); /* REF7475 - YST - 020516 */
    }
    break;

    case    InstrCategory_ConvertibleBond:
	        if ((ret=FIN_SetValuesForConvertibleBondLeg( instrPtr, hierHead, extPos, instrLeg1Ptr))==RET_SUCCEED)
            {
	            ret =   FIN_SetValuesForConvertibleBondLeg2(instrLeg2Ptr); /* REF7475 - YST - 020516 */
            }
	break;

    case    InstrCategory_Others:
    default:    /*  For the Lint utility    */
        break;
    }

    /*  Return value    */
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfOptionLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  extPos          Pointer to the extented Position
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 23022000
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfOptionLeg(    DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrEndDate;
    ENUM_T          yieldCurveAccrualRule;
    RET_CODE        ret =   RET_SUCCEED;

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount);    /* REF5101.3501 - AKO - 000915 */
    /*SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_CashAcct);*/

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Quote);

    /*  Set the end date  */
    instrEndDate = GET_DATE(extPos, ExtPos_EndDate);
    SET_DATE(instrLegPtr, A_Instr_EndDate, instrEndDate);

    /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the redemption quote  */
    SET_PRICE(instrLegPtr, A_Instr_RedempQuote, 1);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesForFixedIncOfOptionLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  extPos          Pointer to the extented Position
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5049 - RAK - 010216
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForFixedIncOfOptionLeg(    DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    FLAG_T          allocFlg=FALSE;
    DBA_DYNFLD_STP  underPtr=NULLDYNST;
    RET_CODE        ret =   RET_SUCCEED;

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    /* REF5049 - RAK - 010221 */
    if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId) == FALSE)
    {
        if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId),
                                    TRUE, &allocFlg, &underPtr,
                                    hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            return(ret);
        }

        SET_CODE(instrLegPtr, A_Instr_Cd, GET_CODE(underPtr, A_Instr_Cd));

        if (allocFlg == TRUE)
        { FREE_DYNST(underPtr, A_Instr);}
    }
    else
    {
        SET_CODE(instrLegPtr, A_Instr_Cd, GET_CODE(instrPtr, A_Instr_Cd));
    }

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Bond);

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Theo);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrPtr, A_Instr_BeginDate, instrBeginDate);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

   /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==(ENUM_T)-1)
    {
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    }
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForConvertibleBondLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  extPos          Pointer to the extented Position
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5049 - AKO - 001114
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForConvertibleBondLeg( DBA_DYNFLD_STP      instrPtr,
                                                    DBA_HIER_HEAD_STP   hierHead,
                                                    DBA_DYNFLD_STP      extPos,
                                                    DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    RET_CODE        ret =   RET_SUCCEED;
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    if (extPos==NULLDYNST || instrLegPtr==NULLDYNST)
	    return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr,A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote); /* PMSTA16573 - DDV - 130627 - As price is compted by difference, price calc rule must be quote instead of quote/100 */

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Bond);

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Theo);

    /*  Set the begin date  */
	/* REF9805 - RAK - 040106 - Not a good idea to update the instrPtr BegDate */
    instrBeginDate = GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrLegPtr, A_Instr_BeginDate, instrBeginDate);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn, RiskNat_InterRate);

   /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==(ENUM_T)-1)
    {
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    }
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForConvertibleBondLeg2()
**
**  Description :   Set values into the newer leg2 (The stock ).
**
**  Arguments   :   instrLegPtr        Pointer to the instruments leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5049 - AKO - 001114
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForConvertibleBondLeg2(DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    RET_CODE        ret =   RET_SUCCEED;

        /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfBondFutures()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfBondFutures(  DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    RET_CODE        ret =   RET_SUCCEED;

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount); /* REF5101.3501 - AKO - 000915 */
    /*SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_CashAcct);*/

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Quote);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrPtr, A_Instr_BeginDate, instrBeginDate);

    /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfEquity()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfEquity(   DBA_DYNFLD_STP      instrPtr,
                                                    DBA_HIER_HEAD_STP   hierHead,
                                                    DBA_DYNFLD_STP      extPos,
                                                    DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    RET_CODE        ret =   RET_SUCCEED;

    if (extPos == NULLDYNST)
	return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr,A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount);
    /*SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_CashAcct);*/    /* REF5101.3501 - AKO - 000915 */

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Quote);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrPtr, A_Instr_BeginDate, instrBeginDate);

    /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfCurrencyLeg1()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfCurrencyLeg1( DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    ID_T            riskCurrency;
    ID_T            riskCountry;
    RET_CODE        ret =   RET_SUCCEED;

    if (extPos == NULLDYNST)
	return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr,A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* PMSTA-8736 - RAK - 100129 - copy underlying information */
    FIN_CpyCurrIdUnderlyInstrInfo(instrLegPtr, instrPtr, hierHead);

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount);
    /*SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_CashAcct);*/  /* REF5101.3501 - AKO - 000915 */

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Theo);

    /*  Set the risk currency */
    riskCurrency    =   FIN_GetRiskCurrIdFromUnderlyInstr(instrPtr, hierHead);
    SET_ID(instrLegPtr, A_Instr_RiskCurrId, riskCurrency); /* REF11882 - CHU - 060828 */

    /*  Set the risk country    */
    riskCountry =   FIN_GetRiskCountryIdFromUnderlyInstr(instrPtr, hierHead);
    SET_ID(instrLegPtr, A_Instr_RiskGeoId, riskCountry); /* REF11882 - CHU - 060828 */

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrLegPtr, A_Instr_BeginDate, instrBeginDate); /* PMSTA-8736 - RAK - 100202 - put beg date in leg */

    /*  Set the accrual Rule    */	/* PMSTA-8736 - RAK - 100129 - use instrLegPtr */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr(instrLegPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
    SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfCurrencyLeg2()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfCurrencyLeg2( DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    RET_CODE        ret =   RET_SUCCEED;
	DBA_DYNFLD_STP	yieldInstrPtr=NULLDYNST;
	FLAG_T			yieldInstrFreeFlg=FALSE;

    if (extPos == NULLDYNST)
	return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount);

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Quote);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrLegPtr, A_Instr_BeginDate, instrBeginDate); /* PMSTA-8736 - RAK - 100202 - Put beg date in leg */

	/* PMSTA-8736 - RAK - 100201 */
	if ((ret = DBA_GetInstrYieldCurve(instrLegPtr, &yieldInstrPtr, &yieldInstrFreeFlg, hierHead, 0)) == RET_SUCCEED)
	{
		SET_ID(instrLegPtr, A_Instr_YieldCurveInstrId, GET_ID(yieldInstrPtr, A_Instr_YieldCurveInstrId));
	}
	if (yieldInstrFreeFlg == TRUE)
	{
		FREE_DYNST(yieldInstrPtr, A_Instr);
	}

	SET_DATE(instrLegPtr, A_Instr_EndDate, GET_DATE(instrPtr, A_Instr_EndDate));

    /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
		SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForFwdCashLeg2()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-10439 - RAK - 100830 (copy of FIN_SetValuesForDiscountOfCurrencyLeg2)
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForFwdCashLeg2(DBA_DYNFLD_STP      instrPtr,
                                            DBA_HIER_HEAD_STP   hierHead,
                                            DBA_DYNFLD_STP      extPos,
                                            DBA_DYNFLD_STP      instrLegPtr)
{
	/*  Local variables declaration */
    DATE_T          instrBeginDate;
    ENUM_T          yieldCurveAccrualRule;
    RET_CODE        ret =   RET_SUCCEED;
	DBA_DYNFLD_STP	yieldInstrPtr=NULLDYNST, acctPos=NULL, cashInstrPtr=NULL;
	FLAG_T			yieldInstrFreeFlg=FALSE;

    if (extPos == NULLDYNST)
	return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID(instrLegPtr, A_Instr_Id);

    /* PMSTA-10439 - RAK - 100830 - For performance analysis, classification of leg in cash */
	/* KRA/SKU : we think that this is not the good solution ... in fact we need to revue all leg creation */
	/* it seems to be a mess. In other side, we know that client (DEXIA) use non-documented functionality */
	/* and are happy with them. As we don't have an analysis describe the existant (and no regression test case) */
	/* we don't know how to modify them without put "errors" on client sides */
	if (GET_EXTENSION_PTR(extPos, ExtPos_Acct_ExtPos_Ext) != NULL  &&
	    (acctPos = *(GET_EXTENSION_PTR(extPos, ExtPos_Acct_ExtPos_Ext))) != NULL)
	{
		if (GET_EXTENSION_PTR(acctPos, ExtPos_A_Instr_Ext) != NULL  &&
	        (cashInstrPtr = *(GET_EXTENSION_PTR(acctPos, ExtPos_A_Instr_Ext))) != NULL)
			SET_ID(instrLegPtr, A_Instr_ParentInstrId,    GET_ID(cashInstrPtr, A_Instr_Id));
	}

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM(instrLegPtr, A_Instr_NatEn, InstrNat_Discount);

    /*  Set the valuation rule  */
    SET_ENUM(instrLegPtr, A_Instr_ValRuleEn, ValRule_Quote);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrLegPtr, A_Instr_BeginDate, instrBeginDate); /* PMSTA-8736 - RAK - 100202 - Put beg date in leg */

	/* PMSTA-8736 - RAK - 100201 */
	if ((ret = DBA_GetInstrYieldCurve(instrLegPtr, &yieldInstrPtr, &yieldInstrFreeFlg, hierHead, 0)) == RET_SUCCEED)
	{
		SET_ID(instrLegPtr, A_Instr_YieldCurveInstrId, GET_ID(yieldInstrPtr, A_Instr_YieldCurveInstrId));
	}
	if (yieldInstrFreeFlg == TRUE)
	{
		FREE_DYNST(yieldInstrPtr, A_Instr);
	}

	SET_DATE(instrLegPtr, A_Instr_EndDate, GET_DATE(instrPtr, A_Instr_EndDate));

    /*  Set the accrual Rule    */
    yieldCurveAccrualRule   =   FIN_GetAccrualRuleFromYieldCurveInstr( instrPtr, hierHead);
    if  (yieldCurveAccrualRule==-1)
        /*  REF4816 - CSA - 22052000
        ret = RET_FIN_ERR_INVDATA;
        */
        yieldCurveAccrualRule = GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
		SET_ENUM(instrLegPtr, A_Instr_AccrualRuleEn, yieldCurveAccrualRule);

    /*  Set the interest rate   */
    SET_NUMBER(instrLegPtr, A_Instr_InterestRateP, 0);

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /*  Return value    */
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfForexSwapPaidLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - RAK - 07121999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfForexSwapPaidLeg(DBA_DYNFLD_STP   instrPtr,
                                                        DBA_DYNFLD_STP      instrLegPtr)

{
	ID_T	parInstrId;

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

	SET_ENUM(instrLegPtr, A_Instr_NatEn,           InstrNat_Discount);
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr, A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr, A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		    instrPtr,    A_Instr, A_Instr_Id);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_RefCurrId,
	            instrPtr,    A_Instr, A_Instr_SwapPaidCurrId);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
	            instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	            instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);


	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfForexSwapRecLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - RAK - 07121999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfForexSwapRecLeg(DBA_DYNFLD_STP    instrPtr,
                                                        DBA_DYNFLD_STP      instrLegPtr)
{
	ID_T		  parInstrId;

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

	SET_ENUM(instrLegPtr,    A_Instr_NatEn,           InstrNat_Discount);
	SET_ENUM(instrLegPtr,    A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,    A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,    A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
	            instrPtr,    A_Instr, A_Instr_Id);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForPaidSwapFloatLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5529 - RAK - 010206 - We create 4 fct for more lisibility
**                  (it's already enough difficult to understand the swap treatment)
** Modification :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**                  REF5941 - YST - 011221 - swap mgmt extension (payment calendar)
**              :   REF7401 - YST - 020304
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForPaidSwapFloatLeg(DBA_DYNFLD_STP    instrPtr,
                                                 DBA_DYNFLD_STP    instrLegPtr)
{
	ID_T		        parInstrId;
    NUMBER_T	        compoQty;
	RET_CODE            ret=RET_SUCCEED;
    COMPLEXINSTR_ENUM   complexInstrEn = ComplexInstr_None; /* REF7782 - YST - 020904 */

    /* REF7782 - YST - 020904 - change A_Instr_IsComplexInstrFlg to A_Instr_ComplexInstrEn */
    complexInstrEn = (COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn);

    SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFloatLeg);

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if (complexInstrEn == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	    IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr,  A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);
    SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg,    TRUE/*FALSE*/);    /* REF9104 - YST - 030526 */
    SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		        instrPtr,    A_Instr, A_Instr_Id);

    if (GET_ID(instrPtr, A_Instr_SwapPaidCurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_CompoQuantity) == TRUE ||
		CMP_NUMBER(GET_NUMBER(instrPtr, A_Instr_CompoQuantity), 0.0) == 0)
		compoQty = -1.0;
	    else
		compoQty = GET_NUMBER(instrPtr, A_Instr_CompoQuantity) * -1.0;
	}
	else
	{
	    compoQty = -1.0;
	}

	SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity, compoQty);

    /* If floatInstrId is NULL, copy informations */
    /* REF5941 - YST - 020218 - different traitement for swap bris� (copy float instr id from interest rate cond.) */
    if ((complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE) ||
        (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == TRUE))
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_EomEn,
		            instrPtr,    A_Instr, A_Instr_PaidEomEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
		            instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_InterestRateP,
		            instrPtr,    A_Instr, A_Instr_PaidInterestRateP);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	                instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);

        /* REF5226 - RAK - 001003 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreq,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreq);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreqUnitEn,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreqUnitEn);

	    if (IS_NULLFLD(instrPtr, A_Instr_SwapPaidCurrId) == FALSE)
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_SwapPaidCurrId));
	    }
	    else
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_RefCurrId));
	    }

        /* REF5941 - YST - 011221 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_CalendarId);

         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompConvEn, instrPtr, A_Instr, A_Instr_PaidCompConvEn );
         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompFreq, instrPtr, A_Instr, A_Instr_PaidCompFreq );
         COPY_DYNFLD(instrLegPtr, A_Instr,  A_Instr_CompFreqUnitEn, instrPtr, A_Instr, A_Instr_PaidCompFreqUnitEn);
    }
    else
    {
        /* REF5941 - YST - 020110 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);
    }
    /* REF7401 - YST - 020304 - copy A_Instr_PaidFloatInstrId after using field A_Instr_FloatInstrId for testing */
    if (complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrPtr,    A_Instr, A_Instr_PaidFloatInstrId);
    }
    else if (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == TRUE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrLegPtr, A_Instr, A_Instr_PaidFloatInstrId);
    }

    /* REF9104 - YST - 030526 */
    if (complexInstrEn == ComplexInstr_BrokSwapHedgFix)
        SET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_BrokSwap);

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);


    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForRecSwapFloatLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5529 - RAK - 010206 - We create 4 fct for more lisibility
**                  (it's already enough difficult to understand the swap treatment)
** Modification :   REF5941 - YST - 020208 - swap mgmt extension
**              :   REF7401 - YST - 020304
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForRecSwapFloatLeg(DBA_DYNFLD_STP    instrPtr,
                                                 DBA_DYNFLD_STP    instrLegPtr)
{
    ID_T		        parInstrId;
	RET_CODE            ret=RET_SUCCEED;
    COMPLEXINSTR_ENUM   complexInstrEn = ComplexInstr_None; /* REF7782 - YST - 020904 */

    /* REF7782 - YST - 020904 - change A_Instr_IsComplexInstrFlg to A_Instr_ComplexInstrEn */
    complexInstrEn = (COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn);

    SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFloatLeg);

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if (complexInstrEn == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	    IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr,  A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);
    SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg,    TRUE/*FALSE*/);    /* REF9104 - YST - 030526 */
    SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		        instrPtr,    A_Instr, A_Instr_Id);

    SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity,       1.0);

    /* If floatInstrId is NULL, copy informations */
    /* REF5941 - YST - 020218 - different traitement for swap bris� (copy float instr id from interest rate cond.) */
    if ((complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE) ||
        (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == TRUE))
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_EomEn,
		            instrPtr,    A_Instr, A_Instr_PaidEomEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
		            instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_InterestRateP,
		            instrPtr,    A_Instr, A_Instr_PaidInterestRateP);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	                instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);

        /* REF5226 - RAK - 001003 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreq,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreq);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreqUnitEn,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreqUnitEn);

	    if (IS_NULLFLD(instrPtr, A_Instr_SwapPaidCurrId) == FALSE)
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_SwapPaidCurrId));
	    }
	    else
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_RefCurrId));
	    }

        /* REF5941 - YST - 011221 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_CalendarId);

         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompConvEn, instrPtr, A_Instr, A_Instr_PaidCompConvEn );
         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompFreq, instrPtr, A_Instr, A_Instr_PaidCompFreq );
         COPY_DYNFLD(instrLegPtr, A_Instr,  A_Instr_CompFreqUnitEn, instrPtr, A_Instr, A_Instr_PaidCompFreqUnitEn);

    }
    else
    {
        /* REF5941 - YST - 020110 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);
    }
    /* REF7401 - YST - 020304 - copy A_Instr_PaidFloatInstrId after using field A_Instr_FloatInstrId for testing */
    if (complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrPtr,    A_Instr, A_Instr_PaidFloatInstrId);
    }
    if (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == TRUE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrLegPtr, A_Instr, A_Instr_PaidFloatInstrId);
    }

    /* REF9104 - YST - 030526 */
    if (complexInstrEn == ComplexInstr_BrokSwapHedgFix)
        SET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_BrokSwap);

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);



    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForPaidSwapFixLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5529 - RAK - 010206 - We create 4 fct for more lisibility
**                  (it's already enough difficult to understand the swap treatment)
** Modification :   REF5941 - YST - 020218 - swap mgmt extension
**              :   REF7401 - YST - 020304
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForPaidSwapFixLeg(DBA_DYNFLD_STP    instrPtr,
                                                 DBA_DYNFLD_STP    instrLegPtr)
{
    ID_T		        parInstrId;
    NUMBER_T	        compoQty;
	RET_CODE            ret=RET_SUCCEED;
    COMPLEXINSTR_ENUM   complexInstrEn = ComplexInstr_None; /* REF7782 - YST - 020904 */

    /* REF7782 - YST - 020904 - change A_Instr_IsComplexInstrFlg to A_Instr_ComplexInstrEn */
    complexInstrEn = (COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn);

    SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFixedLeg);

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if (complexInstrEn == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	    IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr,  A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /* REF5306 - RAK - 010208 - For fixed leg AI is now computed = FALSE -> TRUE */
    SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg,    TRUE);

    SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		        instrPtr,    A_Instr, A_Instr_Id);

	if (GET_ID(instrPtr, A_Instr_SwapPaidCurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_CompoQuantity) == TRUE ||
		CMP_NUMBER(GET_NUMBER(instrPtr, A_Instr_CompoQuantity), 0.0) == 0)
		compoQty = -1.0;
	    else
		compoQty = GET_NUMBER(instrPtr, A_Instr_CompoQuantity) * -1.0;
	}
	else
	{
	    compoQty = -1.0;
	}

    /* REF5833 - RAK - 010322 */
    SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity, compoQty);

    /* If floatInstrId isn't NULL, copy informations */
    /* REF5941 - YST - 020218 - different traitement for swap bris� (copy float instr id from interest rate cond.) */
    if ((complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE) ||
        (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == FALSE))
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_EomEn,
		            instrPtr,    A_Instr, A_Instr_PaidEomEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
		            instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_InterestRateP,
		            instrPtr,    A_Instr, A_Instr_PaidInterestRateP);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	                instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);

        /* REF5226 - RAK - 001003 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreq,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreq);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreqUnitEn,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreqUnitEn);

	    if (IS_NULLFLD(instrPtr, A_Instr_SwapPaidCurrId) == FALSE)
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_SwapPaidCurrId));
	    }
	    else
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_RefCurrId));
	    }

        /* REF5941 - YST - 011221 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_CalendarId);

         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompConvEn, instrPtr, A_Instr, A_Instr_PaidCompConvEn );
         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompFreq, instrPtr, A_Instr, A_Instr_PaidCompFreq );
         COPY_DYNFLD(instrLegPtr, A_Instr,  A_Instr_CompFreqUnitEn, instrPtr, A_Instr, A_Instr_PaidCompFreqUnitEn);

    }
    else
    {
        /* REF5941 - YST - 020110 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);
    }
    /* REF7401 - YST - 020304 - copy A_Instr_PaidFloatInstrId after using field A_Instr_FloatInstrId for testing */
    if (complexInstrEn == ComplexInstr_None)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE)
        {
            COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                    instrPtr,    A_Instr, A_Instr_PaidFloatInstrId);
        }
        /* REF9104 - YST - 030526 */
        if (SubNat_FixFltSwapHedgFix == (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn))
        {
            SET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_SwapHedgFix);
        }
    }
    else if (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == FALSE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrLegPtr, A_Instr, A_Instr_PaidFloatInstrId);
    }

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);

    /* REF7837 - YST - 030131 - set business day convention to None for fixed leg of "brokSwapHedgFix" */
    if (complexInstrEn == ComplexInstr_BrokSwapHedgFix)
        SET_ENUM(instrLegPtr, A_Instr_BusDayConvEn, (INSTRBUSCONV_ENUM)InstrBusConv_None);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForRecSwapFixLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   REF5529 - RAK - 010206 - We create 4 fct for more lisibility
**                  (it's already enough difficult to understand the swap treatment)
** Modification :   REF5941 - YST - 020208 - swap mgmt extension
**              :   REF7401 - YST - 020304
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForRecSwapFixLeg(DBA_DYNFLD_STP    instrPtr,
                                              DBA_DYNFLD_STP    instrLegPtr)
{
    ID_T		        parInstrId;
	RET_CODE            ret=RET_SUCCEED;
    COMPLEXINSTR_ENUM   complexInstrEn = ComplexInstr_None; /* REF7782 - YST - 020904 */

    /* REF7782 - YST - 020904 - change A_Instr_IsComplexInstrFlg to A_Instr_ComplexInstrEn */
    complexInstrEn = (COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn);

    SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFixedLeg);

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if (complexInstrEn == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	         IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr,  A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /* REF5306 - RAK - 010208 - For fixed leg AI is now computed = FALSE -> TRUE */
    SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg,    TRUE);

    SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		        instrPtr,    A_Instr, A_Instr_Id);

    SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity,       1.0);

    /* If floatInstrId isn't NULL, copy informations */
    /* REF5941 - YST - 020218 - different traitement for swap bris� (copy float instr id from interest rate cond.) */
    if ((complexInstrEn == ComplexInstr_None && IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE) ||
        (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == FALSE))
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_EomEn,
		            instrPtr,    A_Instr, A_Instr_PaidEomEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
		            instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_InterestRateP,
		            instrPtr,    A_Instr, A_Instr_PaidInterestRateP);

	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	                instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);

        /* REF5226 - RAK - 001003 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreq,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreq);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreqUnitEn,
	                instrPtr,    A_Instr, A_Instr_PaidPayFreqUnitEn);

	    if (IS_NULLFLD(instrPtr, A_Instr_SwapPaidCurrId) == FALSE)
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_SwapPaidCurrId));
	    }
	    else
	    {
		    SET_ID(instrLegPtr, A_Instr_RefCurrId,
                        GET_ID(instrPtr, A_Instr_RefCurrId));
	    }

        /* REF5941 - YST - 011221 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);

        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_CalendarId);

         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompConvEn, instrPtr, A_Instr, A_Instr_PaidCompConvEn );
         COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompFreq, instrPtr, A_Instr, A_Instr_PaidCompFreq );
         COPY_DYNFLD(instrLegPtr, A_Instr,  A_Instr_CompFreqUnitEn, instrPtr, A_Instr, A_Instr_PaidCompFreqUnitEn);

    }
    else
    {
        /* REF5941 - YST - 020110 */
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	                instrPtr,    A_Instr, A_Instr_PaidCalendarId);
    }
    /* REF7401 - YST - 020304 - copy A_Instr_PaidFloatInstrId after using field A_Instr_FloatInstrId for testing */
    if (complexInstrEn == ComplexInstr_None)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE)
        {
            COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                    instrPtr,    A_Instr, A_Instr_PaidFloatInstrId);
        }
        /* REF9104 - YST - 030526 */
        if (SubNat_FixFltSwapHedgFix == (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn))
        {
            SET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_SwapHedgFix);
        }
    }
    else if (complexInstrEn != ComplexInstr_None && IS_NULLFLD(instrLegPtr, A_Instr_FloatInstrId) == FALSE)
    {
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrLegPtr, A_Instr, A_Instr_PaidFloatInstrId);
    }

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);

    /* REF7837 - YST - 030131 - set business day convention to None for fixed leg of "brokSwapHedgFix" */
    if (complexInstrEn == ComplexInstr_BrokSwapHedgFix)
        SET_ENUM(instrLegPtr, A_Instr_BusDayConvEn, (INSTRBUSCONV_ENUM)InstrBusConv_None);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfSwapRecLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - RAK - 07121999
**  Modif       :   REF6031 - RAK - 010703
**                  REF5941 - YST - 020218 - swap mgmt extension
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfSwapRecLeg(DBA_DYNFLD_STP    instrPtr,
                                                     DBA_DYNFLD_STP    extPos,
                                                     DBA_DYNFLD_STP    instrLegPtr)
{
	ID_T		  parInstrId;
	SUBNAT_ENUM	  swapRule;
	RET_CODE          ret=RET_SUCCEED;

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr,A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId,    parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if ((COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn) == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	    IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr,  A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /* REF5306 - RAK - 010208 - Moved at the end of fct */
    /* SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg, FALSE); */

    SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity,       1.0);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		    instrPtr,    A_Instr, A_Instr_Id);

    /* REF5941 - YST - 020110 */
    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	            instrPtr,    A_Instr, A_Instr_PaidCalendarId);

    /* REF1485 - Update sub-nature depending on swap sub-nature */
	swapRule = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);	/* YST - 020201 - change cast of enum */
	switch (swapRule)
	{
	case SubNat_FixFloatStdSwap :
    case SubNat_FixFltSwapHedgFix:   /* REF7782 - YST - 020904 */
        /* REF5080 - RAK - 000831 */
        /* If FloatInstrId is set, we receive a float and paid a fix */
        /* elsewhere, we receive a fix and paid a float              */
        /* (suppose that A_Instr_PaidFloatInstrId is set)         */
        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE)
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFloatLeg);
        }
        else
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFixedLeg);
        }
		break;

	case SubNat_FixFixStdSwap :
        /* REF6031 - RAK - 010627 */
		/* SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFixedLeg); */
        if (extPos != NULLDYNST &&
            (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
            (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFixedLeg);
        }
        else
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFixedLeg);
        }
		break;

	case SubNat_FltFltStdSwap :
		SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFloatLeg);
		break;
	}

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /* REF5306 - RAK - 010208 - For fixed leg AI is now computed */
    /* REF6031 - RAK - 010703 - For paid fixed leg too */
    /* REF9104 - YST - 030526 */
    SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, TRUE);
    /*if ((SUBNAT_ENUM)GET_ENUM(instrLegPtr, A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg ||
        (SUBNAT_ENUM)GET_ENUM(instrLegPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFixedLeg)
    { SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, TRUE); }
    else
    { SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, FALSE); }*/

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetValuesForDiscountOfSwapPaidLeg()
**
**  Description :   Set values into the newer leg.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - RAK - 07121999
**  Modif.      :   REF6031 - RAK - 010703
**                  REF5941 - YST - 020218 - swap mgmt extension
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**              :   REF7782 - YST - 020904
**              :   REF9104 - YST - 030526
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForDiscountOfSwapPaidLeg(DBA_DYNFLD_STP    instrPtr,
                                                     DBA_DYNFLD_STP    extPos,
                                                     DBA_DYNFLD_STP    instrLegPtr)
{
	ID_T		  parInstrId;
	NUMBER_T	  compoQty;
	SUBNAT_ENUM	  swapRule;
	RET_CODE          ret=RET_SUCCEED;

	/*  Set the identifier to null  */
	SET_NULL_ID(instrLegPtr, A_Instr_Id);

	/* Set parent database identifier */
	if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
	    parInstrId = GET_ID(instrPtr, A_Instr_Id);

	SET_ID(instrLegPtr, A_Instr_ParentInstrId, parInstrId);

	/* Leg parent (because of legs must be different for generic instrument */
	SET_ID(instrLegPtr, A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* REF3396 - Set end date to generated instrument, */
	/*           so TECH tools work correctly.         */
    /* REF7782 - YST - 020904 - tenor frequency used only for "normal" swap, i.e. not for swap bris� */
	if ((COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn) == ComplexInstr_None &&
        IS_NULLFLD(instrPtr, A_Instr_TenorFreqUnitEn) == FALSE &&
	    IS_NULLFLD(instrPtr, A_Instr_TenorFreq) == FALSE)
	{
		double	freq=0.0;
		DATE_T	endDate=0;

		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_TenorFreqUnitEn),  /* REF7264 - PMO */
				      GET_TINYINT(instrPtr, A_Instr_TenorFreq),
			              FreqUnit_Month, &freq) == RET_SUCCEED)
		{
		    endDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
		    SET_DATE(instrLegPtr, A_Instr_EndDate, endDate);
		}
	}

	SET_ENUM(instrLegPtr,   A_Instr_NatEn,           InstrNat_Bond);
	SET_ENUM(instrLegPtr,   A_Instr_RiskNatEn,       RiskNat_InterRate);
	SET_ENUM(instrLegPtr,   A_Instr_ValRuleEn,       ValRule_Theo);
	SET_ENUM(instrLegPtr,   A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /* REF5306 - RAK - 010208 - Moved at the end of fct */
	/* SET_FLAG(instrLegPtr,   A_Instr_AccruedIntFlg, FALSE); */

	if (GET_ID(instrPtr, A_Instr_SwapPaidCurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_CompoQuantity) == TRUE ||
		CMP_NUMBER(GET_NUMBER(instrPtr, A_Instr_CompoQuantity), 0.0) == 0)
		compoQty = -1.0;
	    else
		compoQty = GET_NUMBER(instrPtr, A_Instr_CompoQuantity) * -1.0;
	}
	else
	{
	    compoQty = -1.0;
	}

	SET_NUMBER(instrLegPtr, A_Instr_CompoQuantity, compoQty);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompoInstrId,
		    instrPtr,    A_Instr, A_Instr_Id);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_EomEn,
		    instrPtr,    A_Instr, A_Instr_PaidEomEn);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_AccrualRuleEn,
		    instrPtr,    A_Instr, A_Instr_PaidAccrualRuleEn);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_InterestRateP,
		    instrPtr,    A_Instr, A_Instr_PaidInterestRateP);

	COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_YieldCurveInstrId,
	            instrPtr,    A_Instr, A_Instr_SwapPaidYcInstrId);

    /* REF5941 - YST - 020218/REF7782 - YST - 020904
    different traitement for swap bris� (copy float instr id from interest rate cond.) */
    if ((COMPLEXINSTR_ENUM)GET_ENUM(instrLegPtr, A_Instr_ComplexInstrEn) == ComplexInstr_None)
	    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrPtr,    A_Instr, A_Instr_PaidFloatInstrId);
    else
        COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_FloatInstrId,
	                instrLegPtr, A_Instr, A_Instr_PaidFloatInstrId);

    /* REF5226 - RAK - 001003 */
    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreq,
	            instrPtr,    A_Instr, A_Instr_PaidPayFreq);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_PayFreqUnitEn,
	            instrPtr,    A_Instr, A_Instr_PaidPayFreqUnitEn);

    /* REF5941 - YST - 011221 */
    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CalendarId,
	            instrPtr,    A_Instr, A_Instr_PaidCalendarId);

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_OtherLegCalendarId,
	            instrPtr,    A_Instr, A_Instr_CalendarId);

	if (IS_NULLFLD(instrPtr, A_Instr_SwapPaidCurrId) == FALSE)
	{
		SET_ID(instrLegPtr, A_Instr_RefCurrId,
                    GET_ID(instrPtr, A_Instr_SwapPaidCurrId));
	}
	else
	{
		SET_ID(instrLegPtr, A_Instr_RefCurrId,
                    GET_ID(instrPtr, A_Instr_RefCurrId));
	}

    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompConvEn, instrPtr, A_Instr, A_Instr_PaidCompConvEn );
    COPY_DYNFLD(instrLegPtr, A_Instr, A_Instr_CompFreq, instrPtr, A_Instr, A_Instr_PaidCompFreq );
    COPY_DYNFLD(instrLegPtr, A_Instr,  A_Instr_CompFreqUnitEn, instrPtr, A_Instr, A_Instr_PaidCompFreqUnitEn);


	/* REF1485 - Update sub-nature depending on swap sub-nature */
	swapRule = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn); /* YST - 020201 - change cast of enum */
	switch (swapRule)
	{
	case SubNat_FixFloatStdSwap :
    case SubNat_FixFltSwapHedgFix:   /* REF7782 - YST - 020904 */
        /* REF5080 - RAK - 000831 */
        /* If FloatInstrId is set, we receive a float and paid a fix */
        /* elsewhere, we receive a fix and paid a float              */
        /* (suppose that A_Instr_PaidFloatInstrId is set)         */
        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE)
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFixedLeg);
        }
        else
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFloatLeg);
        }
		break;

	case SubNat_FixFixStdSwap :
        /* REF6031 - RAK - 010703 */
		/*SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFixedLeg); */
        if (extPos != NULLDYNST &&
            (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
            (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_RecSwapFixedLeg);
        }
        else
        {
            SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFixedLeg);
        }
		break;

	case SubNat_FltFltStdSwap :
		SET_ENUM(instrLegPtr, A_Instr_SubNatEn, SubNat_PaidSwapFloatLeg);
		break;
	}

    /*  Set the risk nature */
	SET_ENUM(instrLegPtr, A_Instr_RiskNatEn,       RiskNat_InterRate);

    /* REF5306 - RAK - 010208 - For fixed leg AI is now computed */
    /* REF6031 - RAK - 010703 - For received fixed leg too */
    /* REF9104 - YST - 030526 */
    SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, TRUE);
    /*if (GET_ENUM(instrLegPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFixedLeg ||
        GET_ENUM(instrLegPtr, A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg)
    { SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, TRUE); }
    else
    { SET_FLAG(instrLegPtr, A_Instr_AccruedIntFlg, FALSE); }*/

    /* REF5941 - YST - 020110 */
    if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == GET_TINYINT(instrPtr, A_Instr_PaidPayFreq) &&
        GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn) == GET_ENUM(instrPtr, A_Instr_PaidPayFreqUnitEn))
    {
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, TRUE);
    }
    else
        SET_FLAG(instrLegPtr, A_Instr_SamePayFreqFlg, FALSE);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetAccrualRuleFromYieldCurveInstr()
**
**  Description :   Get the accrual rule from the yield curve instrument.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**
**  Return      :   ENUM_T
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC ENUM_T   FIN_GetAccrualRuleFromYieldCurveInstr(  DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead)
{
    /*  Local variables declarations    */
    DBA_DYNFLD_STP  yieldCurveInstrPtr   =   NULLDYNST;
    FLAG_T          allocFlg    =   FALSE;
    ID_T            yieldCurveInstrId;
    ENUM_T          ret;
    RET_CODE        errorCode;

    /*  Get the identifier of the yield curve instrument    */
    yieldCurveInstrId   =   GET_ID(instrPtr, A_Instr_YieldCurveInstrId);

    /*  Get the pointer to the yield curve instrument   */
    errorCode = DBA_GetInstrById(	yieldCurveInstrId,
						            TRUE,
						            &allocFlg,
						            &yieldCurveInstrPtr,
						            hierHead,
						            UNUSED,
						            UNUSED);

    /*  Get the value of the accrual rule   */
    if  (errorCode==RET_SUCCEED)
    {
        ret = GET_ENUM(yieldCurveInstrPtr, A_Instr_AccrualRuleEn);
    }
    else
    {
	    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_GetAccrualRuleFromYieldCurveInstr",
		GET_CODE(instrPtr, A_Instr_Cd),
		"Yield curve instrument not exist");
        ret = (ENUM_T) -1;
    }

    /*  Free the yield curve instrument */
    if  (allocFlg==TRUE)
        FREE(yieldCurveInstrPtr);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CpyCurrIdUnderlyInstrInfo()
**
**  Description :   Get the currency identifier from the underlying instrument.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**
**  Return      :   ID_T
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_CpyCurrIdUnderlyInstrInfo(DBA_DYNFLD_STP      instrLegPtr,
											  DBA_DYNFLD_STP      instrPtr,
											  DBA_HIER_HEAD_STP   hierHead)
{
    /*  Local variables declarations    */
    DBA_DYNFLD_STP  underlyInstrPtr=NULLDYNST;
    FLAG_T          allocFlg=FALSE;
    ID_T            underlyInstrId;
    RET_CODE        ret=RET_SUCCEED;

    /*  Get the identifier of the underlying instrument */
    underlyInstrId  =   GET_ID(instrPtr, A_Instr_UnderlyInstrId);

    /*  Get the pointer to the underlying instrument    */
    ret = DBA_GetInstrById(	underlyInstrId,
							TRUE,
							&allocFlg,
							&underlyInstrPtr,
							hierHead,
							UNUSED,
							UNUSED);

    /*  Get the value of the yield curve */
	if (ret == RET_SUCCEED)
	{
		SET_ID(instrLegPtr, A_Instr_YieldCurveInstrId,
			GET_ID(underlyInstrPtr, A_Instr_YieldCurveInstrId));
        /*  FPL-PMSTA10039-111027  ref curr id must be copied   */
		SET_ID(instrLegPtr, A_Instr_RefCurrId,
			GET_ID(underlyInstrPtr, A_Instr_RefCurrId));

	}

	/*  Free the yield curve instrument */
    if  (allocFlg==TRUE)
        FREE(underlyInstrPtr);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_GetRiskCurrIdFromUnderlyInstr()
**
**  Description :   Get the risk currency identifier from
**                  the underlying instrument.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**
**  Return      :   ID_T
**
**  Creation	:   DEV1055 - CSA - 24111999
**
**  Modif       :   HFI-PMSTA-37839-200211  Test DBA_GetInstrById return
**
*************************************************************************/
STATIC ID_T FIN_GetRiskCurrIdFromUnderlyInstr(  DBA_DYNFLD_STP      instrPtr,
                                                DBA_HIER_HEAD_STP   hierHead)
{
    /*  Local variables declarations    */
    DBA_DYNFLD_STP  underlyInstrPtr =   NULLDYNST;
    FLAG_T          allocFlg    =   FALSE;
    ID_T            underlyInstrId;
    ID_T            ret = 0;

    /*  Get the identifier of the underlying instrument */
    underlyInstrId  =   GET_ID(instrPtr, A_Instr_UnderlyInstrId);

    /*  Get the pointer to the underlying instrument    */
    if (DBA_GetInstrById(	underlyInstrId,
						    TRUE,
						    &allocFlg,
						    &underlyInstrPtr,
						    hierHead,
						    UNUSED,
						    UNUSED) == RET_SUCCEED)
    {
        /*  Get the value of the accrual rule   */
        ret =   GET_ID(underlyInstrPtr, A_Instr_RiskCurrId); /* REF11683 - TEB - 060127 */

        /*  Free the yield curve instrument */
        if  (allocFlg==TRUE)
            FREE(underlyInstrPtr);
    }
    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_GetRiskCountryIdFromUnderlyInstr()
**
**  Description :   Get the risk country identifier from
**                  the underlying instrument.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**
**  Return      :   ID_T
**
**  Creation	:   DEV1055 - CSA - 24111999
**
**  Modif       :   HFI-PMSTA-37839-200211  Test DBA_GetInstrById return
**
*************************************************************************/
STATIC ID_T FIN_GetRiskCountryIdFromUnderlyInstr(   DBA_DYNFLD_STP      instrPtr,
                                                    DBA_HIER_HEAD_STP   hierHead)
{
    /*  Local variables declarations    */
    DBA_DYNFLD_STP  underlyInstrPtr =   NULLDYNST;
    FLAG_T          allocFlg    =   FALSE;
    ID_T            underlyInstrId;
    ID_T            ret = 0;

    /*  Get the identifier of the underlying instrument */
    underlyInstrId  =   GET_ID(instrPtr, A_Instr_UnderlyInstrId);

    /*  Get the pointer to the underlying instrument    */
    if (DBA_GetInstrById(	underlyInstrId,
						    TRUE,
						    &allocFlg,
						    &underlyInstrPtr,
						    hierHead,
						    UNUSED,
						    UNUSED) == RET_SUCCEED)
    {
        /*  Get the value of the accrual rule   */
        ret =   GET_ID(underlyInstrPtr, A_Instr_RiskGeoId);	/* REF11683 - TEB - 060127 */

        /*  Free the yield curve instrument */
        if  (allocFlg==TRUE)
            FREE(underlyInstrPtr);
    }
    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_AddLegsIntoHier()
**
**  Description :   Add the legs into the hierarchy.
**
**  Arguments   :   instrLeg1Ptr    Pointer to the first leg
**                  instrLeg2Ptr    Pointer to the second leg
**                  hierHead        Pointer to the hierarchy
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
STATIC RET_CODE FIN_AddLegsIntoHier(DBA_DYNFLD_STP      instrLeg1Ptr,
                                    FLAG_T              addLeg1HierFlg,
                                    DBA_DYNFLD_STP      instrLeg2Ptr,
                                    FLAG_T              addLeg2HierFlg,
                                    DBA_HIER_HEAD_STP   hierHead,
                                    INSTRCATEGORY_ENUM  instrCategory)
{
    /*  Local variables declarations    */
    RET_CODE    ret =   RET_SUCCEED;

    /*  Add the first leg into the hierarchy */
    switch  (instrCategory)
    {
    case    InstrCategory_BondFutures:
    case    InstrCategory_CurrencyFutures:
    case    InstrCategory_CurrencyForwards:
    case    InstrCategory_Swap:
    case    InstrCategory_ForexSwap:
    case    InstrCategory_ConvertibleBond:
        if (addLeg1HierFlg == TRUE)
        {
            ret = DBA_AddHierRecord(hierHead,
                                    instrLeg1Ptr,
		                            A_Instr,
                                    FALSE,
				                    HierAddRec_TestMandatLnk);
        }
        break;

    default:
        break;
    }

    /*  Add the second leg into the hierarchy */
    if  (ret==RET_SUCCEED && addLeg2HierFlg == TRUE)

        ret = DBA_AddHierRecord(    hierHead,
                                    instrLeg2Ptr,
		                            A_Instr,
                                    FALSE,
				                    HierAddRec_TestMandatLnk);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForInstrCompo()
**
**  Description :   Compute quantity for created A_InstrCompo (each leg).
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  instrLegPtr     Pointer to the leg
**                  instrCategory   Instrument category
**                  legNumber       Leg number
**
**  Return      :   NUMBER_T        The quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**
*************************************************************************/
RET_CODE FIN_ComputeQtyForInstrCompo(DBA_DYNFLD_STP     instrPtr,
                                    DBA_HIER_HEAD_STP   hierHead,
                                    DBA_DYNFLD_STP      extPos,
                                    DBA_DYNFLD_STP      ,
                                    INSTRCATEGORY_ENUM  instrCategory,
                                    NUMBER_T            convertionFactor,
                                    DBA_DYNFLD_STP      ctdInstrPtr,
                                    int                 legNumber,
					                NUMBER_T		    *qty)
{
    RET_CODE    ret=RET_SUCCEED;
    /* REF5049 - AKO - 001113 */
    DBA_DYNFLD_STP      /*underInstr=NULLDYNST,*/ *flowTab=NULLDYNSTPTR, domainPtr=NULLDYNST;
    DATETIME_T          validDate;
    int                 allocSz=0, flowNbr=0;

	/* For AC/DC, quantity of second leg is the quantity of first leg (underly) * his mkt price */
	if (instrCategory == InstrCategory_ACDC && legNumber == 2)
	{
		/* keep received qty */
		return(RET_SUCCEED);
	}

	*qty = 0.0;

    memset(&validDate,0,sizeof(DATETIME_T));
    if ((domainPtr=DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)))==NULLDYNST)
    {
        return(RET_GEN_ERR_INVARG);
    }
    validDate.date = GET_DATE(domainPtr,A_Domain_InterpFromDate);

    /*  Select a category of instrument */
    switch  (instrCategory)
    {
        case    InstrCategory_Options:
        case    InstrCategory_ExoticOptions:
		case	InstrCategory_ACDC:		/* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */
            {
                FLAG_T  isOpConvertBondFlg=FALSE;

	            if (extPos == NULLDYNST)
	                return(RET_GEN_ERR_INVARG);

                FIN_IsOptConvertBondFlg(instrPtr, hierHead, &isOpConvertBondFlg);

                if (isOpConvertBondFlg == TRUE)
                {
                    if  (legNumber==1)
                        *qty =   FIN_ComputeQtyForLeg1OptionsConvertBond(instrPtr); /* REF7475 - YST - 020516 */
                    else
                        *qty =   FIN_ComputeQtyForLeg2OptionsConvertBond(); /* REF7475 - YST - 020516 */
                }
                else
                {
                    if  (legNumber==1)
                        *qty =   FIN_ComputeQtyForLeg1Options(instrPtr, convertionFactor); /* REF7475 - YST - 020516 */  /* PMSTA15709 - DDV - 130301 - add new parameter instrument */
                    else
                        *qty =   FIN_ComputeQtyForLeg2Options(instrPtr, hierHead, convertionFactor); /* REF7475 - YST - 020516 */
                }
            }
            break;

        case    InstrCategory_BondFutures:
	        if (extPos == NULLDYNST)
	            return(RET_GEN_ERR_INVARG);

                if  (legNumber==1)
                    *qty =   FIN_ComputeQtyForLeg1BondFutures(extPos, convertionFactor);/* REF7475 - YST - 020516 */
                else
                    *qty =   FIN_ComputeQtyForLeg2BondFutures(instrPtr, hierHead, extPos, convertionFactor, ctdInstrPtr);/* REF7475 - YST - 020516 */
            break;

        case    InstrCategory_BondForwards:
	        if (extPos == NULLDYNST)
	            return(RET_GEN_ERR_INVARG);

                if  (legNumber==1)
                    *qty =   FIN_ComputeQtyForLeg1BondForwards(extPos); /* REF7475 - YST - 020516 */
                else
                    *qty =   FIN_ComputeQtyForLeg2BondForwards(instrPtr, hierHead, extPos); /* REF7475 - YST - 020516 */
            break;

        case    InstrCategory_EquityFutures:
        case    InstrCategory_EquityForwards:
	        if (extPos == NULLDYNST)
	            return(RET_GEN_ERR_INVARG);

                if  (legNumber==1)
                    *qty =   FIN_ComputeQtyForLeg1Equity(extPos); /* REF7475 - YST - 020516 */
                else
                    *qty =   FIN_ComputeQtyForLeg2Equity(extPos); /* REF7475 - YST - 020516 */
            break;

        case    InstrCategory_CurrencyFutures:
        case    InstrCategory_CurrencyForwards:
	        if (extPos == NULLDYNST)
	            return(RET_GEN_ERR_INVARG);

                if  (legNumber==1)
                    *qty =   FIN_ComputeQtyForLeg1Currency(extPos); /* REF7475 - YST - 020516 */
                else
                    *qty =   FIN_ComputeQtyForLeg2Currency(extPos); /* REF7475 - YST - 020516 */
                break;

        case    InstrCategory_Swap:
        case    InstrCategory_ForexSwap:
	        if  (legNumber==1)
                    *qty =   FIN_ComputeQtyForLeg1SwapAndForexSwap(instrPtr, extPos); /* REF7475 - YST - 020516 */
                else
                    *qty =   FIN_ComputeQtyForLeg2SwapAndForexSwap(instrPtr, extPos); /* REF7475 - YST - 020516 */
	        break;

        case    InstrCategory_ConvertibleBond: /* REF5049 - AKO - 001113 */
            /* Get the Id of the Action stored in the Exchange Event structure */
            if ((ret=SCE_GetExchEvtConvBondInstr( instrPtr , NULLDYNSTPTR, &flowTab, &allocSz, &flowNbr,
                                                  NULL, validDate, hierHead))==RET_SUCCEED)
            {
                if  (legNumber==1)
                    *qty =  FIN_COmputeQtyForLeg1ConvertibleBond(); /* REF7475 - YST - 020516 */
                else
                    *qty =  FIN_COmputeQtyForLeg2ConvertibleBond(instrPtr, hierHead, flowTab[0]); /* REF7475 - YST - 020516 */
                /* break;  PMSTA-21898 - DDV - 151211 - Purify */
            }
            if (flowNbr>0) DBA_FreeDynStTab(flowTab, flowNbr, Flow);
            break;
        case    InstrCategory_Others:
        default:
            break;
    }

    /*  Divide the quantity by the position quantity   */
    if (instrCategory != InstrCategory_Options &&
        instrCategory != InstrCategory_ExoticOptions &&
		instrCategory != InstrCategory_ACDC && /* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */
        instrCategory != InstrCategory_Swap &&
	    instrCategory != InstrCategory_ForexSwap &&
        instrCategory != InstrCategory_ConvertibleBond &&  /* REF5049 - AKO - 001121 */
        extPos != NULLDYNST)
    {
        *qty =   FIN_DIV(*qty, GET_NUMBER(extPos, ExtPos_Qty));     /* PMSTA-32547 - 130818 - PMO */
    }

    /*  Return value    */
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1Options()
**
**  Description :   Compute the qty for the leg n�1 of options or exotic options.
**
**  Arguments   :   deltaFactor     Delta factor
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 25022000
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**                  PMSTA15709 - DDV - 130301 - add new parameter instrument
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1Options(DBA_DYNFLD_STP      instrPtr,
											 NUMBER_T            deltaFactor)
{
	/* PMSTA15709 - DDV - 130301 - Apply underlying quantity define in the option */
	if (IS_NULLFLD(instrPtr, A_Instr_UnderlyQty) == FALSE &&
	    GET_NUMBER(instrPtr, A_Instr_UnderlyQty) != 0)
	{
		return(deltaFactor * GET_NUMBER(instrPtr, A_Instr_UnderlyQty));
	}
	else
	{
		return(deltaFactor);
	}
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2Options()
**
**  Description :   Compute the qty for the leg n�1 of options or exotic options.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  deltaFactor     Delta factor
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 25022000
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2Options(   DBA_DYNFLD_STP      instrPtr,
                                                DBA_HIER_HEAD_STP   hierHead,
                                                NUMBER_T            deltaFactor)
{
    /************************
    ***  Local variables  ***
    ************************/
    DBA_DYNFLD_STP  termEvt = NULLDYNST;
    NUMBER_T        qty;
    PRICE_T        exerciceQuote = 0;
    RET_CODE        ret = RET_SUCCEED;
	DBA_DYNFLD_STP  domainPtr;
    DATE_T          validDate;


    /*******************************
    ***  Get the domain pointer  ***
    *******************************/
    domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));


    /******************************************************
    ***  Get the FromDate from the domain  ***
    ******************************************************/
    validDate = GET_DATE(domainPtr,A_Domain_InterpFromDate);


    /***********************************************
    ***  Allocation of the term event structure  ***
    ***********************************************/
	if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	    ret = RET_MEM_ERR_ALLOC;


    /***********************
    ***  Get term event  ***
    ***********************/
    if  (ret==RET_SUCCEED)
        ret = DBA_GetTermEvt( instrPtr, validDate, termEvt);


    /***************************************************
    ***  Get the exercice quote from the term event  ***
    ***************************************************/
    if  (ret==RET_SUCCEED)
        exerciceQuote = GET_PRICE(termEvt, A_TermEvt_ExerQuote);


    /*****************************
    ***  Compute the quantity  ***
    *****************************/
	/* PMSTA15709 - DDV - 130306 - Apply underlying quantity define in the option (also for second leg)*/
	if (IS_NULLFLD(instrPtr, A_Instr_UnderlyQty) == FALSE &&
	    GET_NUMBER(instrPtr, A_Instr_UnderlyQty) != 0)
	{
	    qty = deltaFactor * exerciceQuote * GET_NUMBER(instrPtr, A_Instr_UnderlyQty);
	}
	else
	{
	    qty = deltaFactor * exerciceQuote;
	}

    /**************************************
    ***  Free the term event structure  ***
    **************************************/
    FREE_DYNST(termEvt, A_TermEvt);


    /************************
    ***  Return quantity  ***
    ************************/
	return(qty);
}

/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1OptionsConvertBond()
**
**  Description :   Compute the qty for the leg n�1 of options or exotic options.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 25022000
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1OptionsConvertBond(DBA_DYNFLD_STP      instrPtr)
{
    /* convertible exch_event new_instr_qty/ref_qty */
    return(GET_NUMBER(instrPtr, A_Instr_UnderlyQty));
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2OptionsConvertBond()
**
**  Description :   Compute the qty for the leg n�1 of options or exotic options.
**
**  Arguments   :   no
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   REF5049 - RAK - 010216
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2OptionsConvertBond()
{
    /* REF5049 - RAK - 010221 */
	return(-1.0);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1SwapAndForexSwap()
**
**  Description :   Compute the qty for the leg n�1 of swap or forex swap.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  extPos          Pointer to the extented position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - RAK - 08121999
**  Modif       :   REF6031 - RAK - 010703
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**  Modif       :   REF7782 - YST - 020904
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1SwapAndForexSwap(DBA_DYNFLD_STP      instrPtr,
                                                      DBA_DYNFLD_STP      extPos)
{
    NUMBER_T	qty=0.0, factor=-1.0;

    /* REF5529 - RAK - 010131 - Inverse sign for sell of a swap open */
    /* REF6031 - RAK - 010703 - for FixFix too */
    /* REF7782 - YST - 020904 - add SubNat_FixFltSwapHedgFix and change VALRULE_ENUM to SUBNAT_ENUM in exiting tests */
    if (((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
         (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFixStdSwap ||
         (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix) &&
        extPos != NULLDYNST &&
        (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
        (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
        factor = 1.0;
    else
        factor = -1.0;

    if (CMP_PRICE(GET_PRICE(instrPtr, A_Instr_RedempQuote), 0.0) != 0)
    {
	    qty = GET_PRICE(instrPtr, A_Instr_RedempQuote) * factor;	    /* REF1485 */
    }
    else
    {
	    qty = factor;
    }

    return(qty);
}

/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2SwapAndForexSwap()
**
**  Description :   Compute the qty for the case n�1.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  extPos          Pointer to extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - RAK - 08121999
**  Modif.      :   REF6031 - RAK - 010703
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**  Modif       :   REF7782 - YST - 020904
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2SwapAndForexSwap(DBA_DYNFLD_STP      instrPtr,
                                                      DBA_DYNFLD_STP      extPos)
{
    NUMBER_T	qty=1.0;

    /* REF5529 - RAK - 010131 - Inverse sign for sell of a swap open */
    /* REF6031 - RAK - 010703 - for FixFix too */
    /* REF7782 - YST - 020904 - add SubNat_FixFltSwapHedgFix and change VALRULE_ENUM to SUBNAT_ENUM in exiting tests */
    if (((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
         (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFixStdSwap ||
         (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix) &&
        extPos != NULLDYNST &&
        (OPNAT_ENUM) GET_ENUM(extPos, ExtPos_OpenOpNatEn) == OpNat_Sell &&
        (POSREFNAT_ENUM) GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
        qty = -1.0;
    else
        qty = 1.0;

    return(qty);
}

/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1BondFutures()
**
**  Description :   Compute the qty for the case n�1.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1BondFutures(DBA_DYNFLD_STP	extPos,
												 NUMBER_T		convertionFactor) /* PMSTA01812-CHU-070402 */
{
    /*  Local variables declarations    */
    NUMBER_T    ret=0.0;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

	/*  Multiply by the CTD convertion factor   */ /* PMSTA01812-CHU-070402 */
	ret *= (1.0 / convertionFactor);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_COmputeQtyForLeg1ConvertibleBond()
**
**  Description :   Compute the qty for the leg1
**
**  Arguments   :   no
**
**  Return      :   NUMBER_T    : Quantity computed
**
**  Creation	:   REF5049 - AKO - 20001106
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_COmputeQtyForLeg1ConvertibleBond()
{
    /*  Local variables declarations    */
    NUMBER_T    ret=0.0;

    /*  Get the quantity from the convertible bond instrument    */
    /* REF5049 - RAK - 010110 - in risk view, leg qty is multiplied by convertible qty */
    /* ret = GET_NUMBER(extPos, ExtPos_Qty); */
    ret = 1.0;

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_COmputeQtyForLeg2ConvertibleBond()
**
**  Description :   Compute the qty for Leg2.
**
**  Arguments   :   instrPtr    : parent instrument
**                  hierHead    : hierarchy
**                  extPos      : pointer on ExtPos
**
**  Return      :   NUMBER_T            Quantity computed
**
**  Creation	:   REF5049 - AKO - 20001106
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_COmputeQtyForLeg2ConvertibleBond(   DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      flowPtr)
{
    /*  Local variables declarations    */
    NUMBER_T        ret=0.0, extposQty=0.0, exchRefQty=0.0, newInstrQty=0.0;
    DBA_DYNFLD_STP  domainPtr=NULLDYNST;

    if ((domainPtr=DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)))==NULLDYNST)
        return(ret);

    /* new instrument quantity -  Quantity of stocks received in the flow */
    if ( (IS_NULLFLD(flowPtr, Flow_QtyUnit)==TRUE) ||
         ( CMP_NUMBER((newInstrQty=GET_NUMBER(flowPtr, Flow_QtyUnit)), 0.0)<=0))
    {
        MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_COmputeQtyForLeg2ConvertibleBond",
           GET_CODE(instrPtr, A_Instr_Cd), "Flow_QtyUnit is null !");
    }

    /* Describes for how many "units" of Convertible Bonds, the quantity exchanged applies */
    if ( (IS_NULLFLD(flowPtr, Flow_RefQty)==TRUE) ||
         ( CMP_NUMBER((exchRefQty=GET_NUMBER(flowPtr, Flow_RefQty)),0.0)==0))
    {
        MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_COmputeQtyForLeg2ConvertibleBond",
           GET_CODE(instrPtr, A_Instr_Cd), "Flow_RefQty is null, We cannot divide by zero (See Formula)!");
        return ret;
    }

    /* quantity_n - quantity of the position in Convertible Bonds  */
    /* REF5049 - RAK - 010110 - in risk view, leg qty is multiplied by convertible qty */
    /* ret = extposQty = GET_NUMBER(extPos, ExtPos_Qty); */
    ret = extposQty = 1.0;

    /* Suppressed AKO December 2001
    if (OptDelta_Full == GET_ENUM(domainPtr,A_Domain_OptRiskRuleEn))
    {
        ret = (extposQty / exchRefQty) *  newInstrQty ;
    }
    else if (OptDelta_Delta == GET_ENUM(domainPtr,A_Domain_OptRiskRuleEn))
    {
        ret = ((extposQty / exchRefQty) *  newInstrQty) * delta;
    }
    else
    {
        ret=GET_NUMBER(extPos, ExtPos_Qty);
    }
    */

    /*  Return value   */
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2BondFutures()
**
**  Description :   Compute the qty for the case n�2.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  instrLegPtr     Pointer to the leg
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Last modif. :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**                  REF7265 - YST - 020409
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**                  REF11218 - TEB - 050627
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2BondFutures(   DBA_DYNFLD_STP      instrPtr,
                                                    DBA_HIER_HEAD_STP   hierHead,
                                                    DBA_DYNFLD_STP      extPos,
                                                    NUMBER_T            convertionFactor,
                                                    DBA_DYNFLD_STP      ctdInstrPtr)
{
    /*  Local variables declarations    */
    FIN_AIARG_ST    accrInterest;
    FIN_MKTVAL_ST   resultAccrInterest;

    /*  Get the quantity from the future instrument    */
    NUMBER_T ret = GET_NUMBER(extPos, ExtPos_Qty);

    /*  Fill the structure for accrued interest */
    accrInterest.scptAIStp              =   NULL;
    accrInterest.fullCoupFlg            =   FALSE;
    accrInterest.fusDateRule            =   FusDateRule_None;           /* REF7264 - PMO */
    accrInterest.calcAccrInterFlg       =   FALSE;
    accrInterest.txdInterFlg            =   FALSE;
    accrInterest.accrInterMethod        =   AccrInterMethod_Default;    /* REF7265 - YST - 020409 */
    accrInterest.accrValFromDate.date   =   0;                          /* REF7265 - YST - 020409 */
    accrInterest.accrValFromDate.time   =   0;                          /* REF7265 - YST - 020409 */
    accrInterest.accrRule               = 	AccrRule_None;              /* REF11218 - TEB - 050627 */
    accrInterest.useDefinedDateFlg      =   FALSE;                      /* PMSTA08308 - 090609 - PMO */

    /*  Compute the accrued interest    */
    (void)FIN_AccrInter(  GET_DATETIME(instrPtr, A_Instr_EndDate),
                          GET_ID(ctdInstrPtr, A_Instr_Id),
                          NULLDYNST,
                          GET_ID(extPos, ExtPos_PosCurrId),
                          &accrInterest,
                          ret,
                          extPos,
                          &resultAccrInterest,
                          hierHead);

    /*  Multiply by the price of the position   */
    ret =   ret *   GET_PRICE(extPos, ExtPos_Price);

    /*  Multiply by the CTD convertion factor   */
    ret =   ret *   convertionFactor;

    /*  Adding the accrual interest */
    ret =   ret +   resultAccrInterest.accrInterRefCurr;

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1BondForwards()
**
**  Description :   Compute the qty for the case n�3.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1BondForwards(DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    NUMBER_T    ret=0.0;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2BondForwards()
**
**  Description :   Compute the qty for the case n�4.
**
**  Arguments   :   instrPtr        Pointer to the instrument
**                  hierHead        Pointer to the hierarchy
**                  extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Last modif. :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**                  REF7265 - YST - 020409
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**                  REF11218 - TEB - 050627
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2BondForwards(  DBA_DYNFLD_STP      instrPtr,
                                                    DBA_HIER_HEAD_STP   hierHead,
                                                    DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    FIN_AIARG_ST    accrInterest;
    FIN_MKTVAL_ST   resultAccrInterest;

    /*  Get the quantity from the forward instrument    */
    NUMBER_T ret = GET_NUMBER(extPos, ExtPos_Qty);

    /*  Fill the structure for accrued interest */
    accrInterest.scptAIStp              =   NULL;
    accrInterest.fullCoupFlg            =   FALSE;
    accrInterest.fusDateRule            =   FusDateRule_None;           /* REF7264 - PMO */
    accrInterest.calcAccrInterFlg       =   FALSE;
    accrInterest.txdInterFlg            =   FALSE;
    accrInterest.accrInterMethod        =   AccrInterMethod_Default;    /* REF7265 - YST - 020409 */
    accrInterest.accrValFromDate.date   =   0;                          /* REF7265 - YST - 020409 */
    accrInterest.accrValFromDate.time   =   0;                          /* REF7265 - YST - 020409 */
	accrInterest.accrRule               = 	AccrRule_None;              /* REF11218 - TEB - 050627 */
    accrInterest.useDefinedDateFlg      =   FALSE;                      /* PMSTA08308 - 090609 - PMO */

    /*  Compute the accrued interest    */
    FIN_AccrInter(  GET_DATETIME(instrPtr, A_Instr_EndDate),
                    GET_ID(instrPtr, A_Instr_UnderlyInstrId),
                    NULLDYNST,
                    GET_ID(extPos, ExtPos_PosCurrId),
                    &accrInterest,
                    ret,
                    extPos,
                    &resultAccrInterest,
                    hierHead);

    /*  Multiply by the price of the position   */
    ret =   ret *   GET_PRICE(extPos, ExtPos_Price);

    /*  Adding the accrual interest */
    ret =   ret +   resultAccrInterest.accrInterRefCurr;

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1Equity()
**
**  Description :   Compute the qty for the case n�5.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1Equity(DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    NUMBER_T    ret;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2Equity()
**
**  Description :   Compute the qty for the case n�6.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2Equity(DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    NUMBER_T        ret =   0;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

    /*  Multiply by the price of the position   */
    ret =   ret *   GET_PRICE(extPos, ExtPos_Price);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg1Currency()
**
**  Description :   Compute the qty for the case n�7.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg1Currency(DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    NUMBER_T    ret;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

    /*  Return value    */
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_ComputeQtyForLeg2Currency()
**
**  Description :   Compute the qty for the case n�8.
**
**  Arguments   :   extPos          Pointer on extended Position
**
**  Return      :   NUMBER_T        Quantity computed
**
**  Creation	:   DEV1055 - CSA - 24111999
**  Modif       :   REF7475 - YST - 020516 - remove unused argument in call
**
*************************************************************************/
STATIC NUMBER_T FIN_ComputeQtyForLeg2Currency(DBA_DYNFLD_STP      extPos)
{
    /*  Local variables declarations    */
    NUMBER_T        ret =   0;

    /*  Get the quantity from the forward instrument    */
    ret =   GET_NUMBER(extPos, ExtPos_Qty);

    /*  Multiply by the price of the position   */
    ret =   ret *   GET_PRICE(extPos, ExtPos_Price);

    /*  Return value    */
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_GetCTDInstrument()
**
**  Description :   Get the CTD instrument from the daabase.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLegPtr     :   Pointer of pointer to leg
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 26111999
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_GetCTDInstrument(DBA_DYNFLD_STP      instrPtr,
                                     DBA_HIER_HEAD_STP   hierHead,
                                     DBA_DYNFLD_STP      extPos,
                                     DBA_DYNFLD_STP      *instrLegPtr,
                                     NUMBER_T            *convertionFactor)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    ID_T            calendarId;
    ID_T            instrLegId;
    DBA_DYNFLD_STP  advArgStp   = NULLDYNST;
    DBA_DYNFLD_STP  advAStp     = NULLDYNST;
	DBA_DYNFLD_STP	underInstr  = NULLDYNST; /* PMSTA09442-CHU-100303 */
    FLAG_T          allocFlg;
    RET_CODE        ret;


    /**************************************
    ***  Memory allocation for the leg  ***
    **************************************/
    advArgStp   =   ALLOC_DYNST(AdvA_Arg);
    advAStp     =   ALLOC_DYNST(A_AdvA);

    /*  Test for success    */
	if  (advArgStp == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if  (advAStp == NULLDYNST)
	{
	    FREE(advArgStp);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    /****************************
    ***  Build the arguments  ***
    ****************************/

    /* Get the calendar identifier */
    ret =   DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	if (    (ret != RET_SUCCEED)    ||  (calendarId <= 0)   )
	    GEN_GetApplInfo(ApplSysCalendarId, &calendarId);

    /* CalendarId from reference currency. */
	SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
    SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 020109 */

	/* instrument Id */
	SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

	/* Margin */
	SET_FLAG(advArgStp, AdvA_Arg_Margin, (FLAG_T)TRUE);

	/* domestic */
	SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);

	/* ref date */
	if (extPos != NULLDYNST)
	{
	    SET_DATE(advArgStp, AdvA_Arg_Date, GET_DATE(extPos, ExtPos_ExtPosDate));
	}
	else
	{
	    DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

	    if (domainPtr != NULLDYNST)
	    {
		DATETIME_T  refDate;
		refDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
		SET_DATE(advArgStp, AdvA_Arg_Date, refDate.date);
	    }
	}

	/* spread */
	SET_NUMBER(advArgStp, AdvA_Arg_Spread, (NUMBER_T)0);

	/* shock */
	SET_NUMBER(advArgStp, AdvA_Arg_Shock, (NUMBER_T)0);

	/* CTD */
	SET_FLAG(advArgStp, AdvA_Arg_MarketCTD, (FLAG_T)TRUE);

	/* set the keyword nature */
	SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DF_Fut);


    /***********************************
    ***  Compute the CTD instrument  ***
    ***********************************/
    ret =   SCE_ComputeCurrKeyWord( advArgStp,
                                    instrPtr,
                                    extPos,
                                    hierHead,
                                    advAStp);


    /***********************************
    ***  Compute the CTD instrument  ***
    ***********************************/
	if (ret == RET_SUCCEED)
	{
        /*  Get the identifier to the instrument    */
        instrLegId  =   GET_ID(advAStp, A_AdvA_Ctd);

        /*  Set the convertion factor   */
        *convertionFactor    =   GET_NUMBER(advAStp, A_AdvA_Cf);

        /*  Search the instrument in database   */
        ret =   DBA_GetInstrById(   instrLegId,
					                TRUE,       /* If it wasn't in hierarchy, add it */
					                &allocFlg,  /* because of add, will be FALSE */
					                &underInstr, /*instrLegPtr*/ /* PMSTA09442-CHU-100303 put this one into hierarchy */
					                hierHead,
					                UNUSED,
					                UNUSED);

		/* PMSTA09442-CHU-100303
		 * Copy instrument to ensure initial code above this function still works the same way
		 */
		if ((*(instrLegPtr) = ALLOC_DYNST(A_Instr)) == NULLDYNST)
		{
			if (allocFlg == TRUE) { FREE_DYNST(underInstr, A_Instr); }
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		COPY_DYNST(*(instrLegPtr), underInstr, A_Instr);
    }

    FREE_DYNST(advArgStp, AdvA_Arg);
    FREE_DYNST(advAStp,   A_AdvA);

    /*  Return value    */
    return(ret);
}

/*************************************************************************
**
**  Function    :   FIN_CreateConvBondInstrLeg2AsOption()
**
**  Description :   Create convertivble Bond Leg2 as option Leg
**                  instrument.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  underInstr      :   pointer to underlying instr
**              :   flowPtr         :   pointer to event flow
**              :   extPos          :   pointer to extended position
**              :   instrLegPtr     :   Pointer of pointer to leg2
**
**  Return      :   RET_CODE
**
**  Creation    :   REF5049 - AKO - 001204
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateConvBondInstrLeg2AsOption(DBA_DYNFLD_STP    instrPtr,
                                                    DBA_DYNFLD_STP    underInstrPtr,
                                                    DBA_DYNFLD_STP    flowPtr,
                                                    DBA_DYNFLD_STP    extPos,
                                                    DBA_DYNFLD_STP    *instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    RET_CODE        ret=RET_SUCCEED;
    NUMBER_T        underQty=0.0, newInstrQty=0.0, exchRefQty=0.0;
    DATETIME_T      exchEvtBegD, exchEvtEndD, convBegD;


    if (extPos==NULLDYNST || instrLegPtr==NULLDYNSTPTR)
	    return(RET_GEN_ERR_INVARG);

    memset(&exchEvtBegD, 0, sizeof(DATE_T));
    memset(&exchEvtEndD, 0, sizeof(DATE_T));
    memset(&convBegD, 0, sizeof(DATE_T));


    /*  Memory allocation for the leg */

	/*if  ((*instrLegPtr=ALLOC_DYNST(A_Instr)) == NULLDYNST)
        {MSG_RETURN(RET_MEM_ERR_ALLOC);}*/

    /*  Set the identifier to null  */
    SET_NULL_ID((*instrLegPtr),A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	    parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
        parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID((*instrLegPtr), A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID((*instrLegPtr), A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /* -------------------- */
    /* donn�es financi�res  */
    /* -------------------- */
    /*  Set the price calculation rule  */
    SET_ENUM((*instrLegPtr), A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote);

    /*  Set the nature of the instrument    */
    SET_ENUM((*instrLegPtr), A_Instr_NatEn, InstrNat_Option);

    if (IS_NULLFLD(instrPtr, A_Instr_RefCurrId)!=TRUE)
        {SET_ID((*instrLegPtr), A_Instr_RefCurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));}
    else
        {return(RET_GEN_ERR_INVARG);}

    /*  Set the valuation rule  */
    SET_ENUM((*instrLegPtr), A_Instr_ValRuleEn, ValRule_Theo);

    /* set convertible yieldcurve */
    if (IS_NULLFLD(instrPtr, A_Instr_YieldCurveInstrId)!=TRUE)
        {SET_ID((*instrLegPtr), A_Instr_YieldCurveInstrId, GET_ID(instrPtr, A_Instr_YieldCurveInstrId));}
    else
        {SET_NULL_ID((*instrLegPtr),A_Instr_YieldCurveInstrId);}

    /*  Set the risk nature */
	SET_ENUM((*instrLegPtr), A_Instr_RiskNatEn,       RiskNat_Equity);

    /* set contract size to 1 */
    SET_NUMBER((*instrLegPtr), A_Instr_ContractSize, 1);

    /* begin date of the option */
    SET_DATE((*instrLegPtr), A_Instr_BeginDate, GET_DATE(instrPtr, A_Instr_BeginDate));

    /* endDate of the option */
    exchEvtBegD.date = GET_DATE(flowPtr, Flow_BegPayDate);
    exchEvtEndD.date = GET_DATE(flowPtr, Flow_BegPayDate);
    convBegD.date    = GET_DATE(flowPtr, Flow_BegPayDate);
    if (exchEvtEndD.date > convBegD.date)
    {
        SET_DATE((*instrLegPtr), A_Instr_EndDate, exchEvtEndD.date);
    }
    else
    {
        SET_DATE((*instrLegPtr), A_Instr_EndDate, exchEvtBegD.date);
    }

    /* new instrument quantity -  Quantity of stocks received in the flow */
    if ( (IS_NULLFLD(flowPtr, Flow_QtyUnit)==TRUE) ||
         ( CMP_NUMBER((newInstrQty=GET_NUMBER(flowPtr, Flow_QtyUnit)), 0.0)<=0))
    {
        MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_COmputeQtyForLeg2ConvertibleBond",
           GET_CODE(instrPtr, A_Instr_Cd), "Flow_QtyUnit is null !");
    }

    /* Describes for how many "units" of Convertible Bonds, the quantity exchanged applies */
    if ( (IS_NULLFLD(flowPtr, Flow_RefQty)==TRUE) ||
         ( CMP_NUMBER((exchRefQty=GET_NUMBER(flowPtr, Flow_RefQty)),0.0)==0))
    {
        MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_COmputeQtyForLeg2ConvertibleBond",
           GET_CODE(instrPtr, A_Instr_Cd), "Flow_RefQty is null, We cannot divide by zero (See Formula)!");
        return RET_GEN_ERR_INVARG;
    }
    /* underlying quantity */
    underQty = newInstrQty/exchRefQty;
    SET_NUMBER((*instrLegPtr), A_Instr_UnderlyQty, underQty);

    /* underlying instrId */
    SET_ID((*instrLegPtr), A_Instr_UnderlyInstrId, GET_ID(underInstrPtr, A_Instr_Id));

    /* ---------------------------- */
    /* retrieve quote of leg1       */
    /* ---------------------------- */
   	/* PMSTA-9860 - RAK - 100614 - wrong done (without identifier) but it is not necessary, could be NULL */
	/* if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
	{MSG_RETURN(RET_MEM_ERR_ALLOC);}
	if (FIN_InstrPrice(GET_ID((*instrLeg1Ptr), A_Instr_Id),
		               (*instrLeg1Ptr), fromDate, NULLDYNST, 0, NULL, NULLDYNST,
		               NULLDYNST, hierHead, pricePtr) == RET_SUCCEED)
	{
        quote = GET_PRICE(pricePtr, A_InstrPrice_Quote);
        SET_NUMBER((*instrLegPtr), A_Instr_RedempQuote, quote);
	}
	FREE_DYNST(pricePtr, A_InstrPrice);
	*/

    /*SET_CODE( (*instrLegPtr), A_Instr_Cd, (strcat(GET_CODE(instrPtr, A_Instr_Cd), "_Option")));
    SET_CODE( (*instrLegPtr), A_Instr_Name, (strcat(GET_CODE(instrPtr, A_Instr_Name), "_Option")));*/
    return(ret);
}
#if 0
/*************************************************************************
**
**  Function    :   FIN_CreateConvBondInstrLeg1FixIncom()
**
**  Description :   Create convertivble Bond Leg1 to FixeIncome (Bond=NatEn)
**                  instrument.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLegPtr     :   Pointer of pointer to leg
**
**  Return      :   RET_CODE
**
**  Creation    :   REF5049 - AKO - 001204
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateConvBondInstrLeg1FixIncom(    DBA_DYNFLD_STP    instrPtr,
                                                        DBA_HIER_HEAD_STP hierHead,
                                                        DBA_DYNFLD_STP    extPos,
                                                        DBA_DYNFLD_STP    *instrLegPtr)
{
	/*  Local variables declaration */
    ID_T            parInstrId;
    DATE_T          instrBeginDate;
    RET_CODE        ret =   RET_SUCCEED;

    if (extPos==NULLDYNST || instrLegPtr==NULLDYNSTPTR)
	    return(RET_GEN_ERR_INVARG);

    /*  Set the identifier to null  */
    SET_NULL_ID((*instrLegPtr),A_Instr_Id);

    /* Set parent database identifier */
    if (GET_ID(instrPtr, A_Instr_Id) <= 0)
	parInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    else
	parInstrId = GET_ID(instrPtr, A_Instr_Id);

    SET_ID((*instrLegPtr), A_Instr_ParentInstrId,    parInstrId);

    /* Leg parent (because of legs must be different for generic instrument */
    SET_ID((*instrLegPtr), A_Instr_LegParInstrId, GET_ID(instrPtr, A_Instr_Id));

    /*  Set the price calculation rule  */
    SET_ENUM((*instrLegPtr), A_Instr_PriceCalcRuleEn, PriceCalcRule_Quote100);

    /*  Set the nature of the instrument    */
    SET_ENUM((*instrLegPtr), A_Instr_NatEn, InstrNat_Bond);

    /*  Set the valuation rule  */
    SET_ENUM((*instrLegPtr), A_Instr_ValRuleEn, ValRule_Theo);

    /*  Set the begin date  */
    instrBeginDate  =   GET_DATE(extPos, ExtPos_BegDate);
    SET_DATE(instrPtr, A_Instr_BeginDate, instrBeginDate);

    /*  Set the risk nature */
	SET_ENUM((*instrLegPtr), A_Instr_RiskNatEn,       RiskNat_InterRate);


    /*  Return value    */
    return(ret);
}
#endif

/*************************************************************************
**
**  Function    :   FIN_GetDefaultMarginForOptions()
**
**  Description :   Compute the default margin for the option.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  defaultMargin   :   Pointer to the default margin
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 01032000
**
**  History     :   REF7475 - YST - 020516 - remove unused argument in call
**  Modif       :   HFI-PMSTA-37839-200211  Test DBA_GetInstrById return
**
*************************************************************************/
STATIC RET_CODE FIN_GetDefaultMarginForOptions( DBA_DYNFLD_STP      instrPtr,
                                                DBA_HIER_HEAD_STP   hierHead,
                                                FLAG_T              *defaultMargin)
{
    /************************
    ***  Local variables  ***
    ************************/
    ID_T            underlyInstrId;
    DBA_DYNFLD_STP  underlyInstrPtr = NULLDYNST;
    FLAG_T          allocFlg;
    ENUM_T          underlyInstrNature;
    RET_CODE        ret;


    /************************************
    ***  Get the underlying instr Id  ***
    ************************************/
    underlyInstrId = GET_ID( instrPtr, A_Instr_UnderlyInstrId);


    /**************************************************
    ***  Get the instrument pointer from hierarchy  ***
    **************************************************/
    if ((ret = DBA_GetInstrById(underlyInstrId,
                                TRUE,
                                &allocFlg,
                                &underlyInstrPtr,
                                hierHead,
                                UNUSED,
                                UNUSED)) == RET_SUCCEED)
    {

    /******************************************************
    ***  Get the nature from the underlying instrument  ***
    ******************************************************/
        underlyInstrNature = GET_ENUM( underlyInstrPtr, A_Instr_NatEn);


    /*****************************************************
    ***  Test the nature of the underlying instrument  ***
    *****************************************************/
        *(defaultMargin) = FALSE;
        if  (underlyInstrNature==InstrNat_Future)
            *(defaultMargin) = TRUE;

    }
    /********************
    ***  Return code  ***
    ********************/
    return(ret);
}

/*************************************************************************
**
**  Function    :   FIN_ComputeDeltaFactorWithAA_BS_OPT()
**
**  Description :   Compute the delta factor for the option.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  extPos          :   Pointer to the extented position
**                  domainPtr       :   Pointer to the domain
**                  deltaFactor     :   Pointer to the delta factor to compute
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 29022000
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeDeltaFactorWithAA_BS_OPT(    DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      domainPtr,
                                                        DBA_DYNFLD_STP      instrLegPtr,
                                                        NUMBER_T            *deltaFactor)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    ID_T            calendarId;
    DBA_DYNFLD_STP  advArgStp   = NULLDYNST;
    DBA_DYNFLD_STP  advAStp     = NULLDYNST;
    DBA_DYNFLD_STP  instrBidon  = NULLDYNST;
    RET_CODE        ret;
    DATETIME_T      refDate;
    OPTVOLATILITYRULE_ENUM          optionVolRuleEn;   /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    NUMBER_T        volatility=0.0;
    ID_T            instrId=0;
    FLAG_T          defaultMargin = FALSE;


    /*******************************************
    ***  Memory allocation for the argument  ***
    *******************************************/
    advArgStp   =   ALLOC_DYNST(AdvA_Arg);
    advAStp     =   ALLOC_DYNST(A_AdvA);


    /*******************************************
    ***  Test for memory allocation success  ***
    *******************************************/
	if  (advArgStp == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if  (advAStp == NULLDYNST)
	{
	    FREE(advArgStp);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}


    /****************************
    ***  Build the arguments  ***
    ****************************/

	/* set the keyword nature */
	SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_BS_Opt);

	/* instrument Id */
	SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

	/* ref date */
	refDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	SET_DATE(advArgStp, AdvA_Arg_Date, refDate.date);

    /* Set the spread */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Spread);

    /* Set the shock */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Shock);

    /* Get the calendar identifier */
    ret =   DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	if (    (ret != RET_SUCCEED)    ||  (calendarId <= 0)   )
	    GEN_GetApplInfo(ApplSysCalendarId, &calendarId);    /* Default calendar Id */
	SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
    SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 020109 */

	/* Set margin */
    ret = FIN_GetDefaultMarginForOptions(instrPtr, hierHead, &defaultMargin); /* REF7475 - YST - 020516 */

	SET_FLAG(advArgStp, AdvA_Arg_Margin, defaultMargin);

	/* Set domestic */
	SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);

    /* Set the black */
    SET_FLAG(advArgStp, AdvA_Arg_Black, (FLAG_T)TRUE);

    /* Set the volatility */
    GEN_GetApplInfo(ApplOptVolatilityRule, &optionVolRuleEn);	  /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    if  (optionVolRuleEn==OptVolatility_Historical)	       /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    {
        if  (GET_ENUM(instrLegPtr, A_Instr_NatEn)==InstrNat_CashAcct)
        {
            ret = DBA_GetDefOption( GET_ENUM(instrPtr,A_Instr_NatEn),
                                    GET_ID(instrPtr, A_Instr_RefCurrId),
                                    GET_ID(instrLegPtr, A_Instr_RefCurrId),
                                    &instrBidon);

            /* REF4586 - RAK - 000427 */
            /* If instrument isn't found, use underlying (like before) */
            if (ret == RET_SUCCEED && instrBidon != NULLDYNST)
            {
                instrId = GET_ID(instrBidon, A_Instr_Id);
            }
            else
            {
                instrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
            }

            FREE_DYNST(instrBidon, A_Instr);
        }
        else
        {
            instrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
        }

        /* REF4586 - RAK - 000427 */
        /* If no underlying (or default instrument), don't search volatility */
        if (instrId == 0)
        {
            ret = RET_GEN_INFO_NODATA;
        }
        else
        {
            ret = DBA_GetChronoVal( Instr,
                                instrId,
					            UNUSED,
			                    (ENUM_T) ChronoNat_Volatility,
                                refDate,
					            TimeDim_Last,
                                TRUE,
                                &volatility);
        }
    }
    else
    {
        instrId = GET_ID(instrPtr, A_Instr_Id);
        ret = DBA_GetChronoVal( Instr,
                                instrId,
					            UNUSED,
			                    (ENUM_T) ChronoNat_ImpVol,
                                refDate,
					            TimeDim_Last,
                                TRUE,
                                &volatility);
    }

    if  (ret!=RET_SUCCEED)  /* DEV1055 - CSA - Yes, I know that there has been an error. But the life continue...*/
    {
        ret = RET_SUCCEED;
        volatility = 0;
    }
    SET_NUMBER(advArgStp, AdvA_Arg_Volatility, volatility);


    /*********************************
    ***  Compute the delta factor  ***
    *********************************/
    if  (ret==RET_SUCCEED)
        ret =   SCE_ComputeCurrKeyWord( advArgStp,
                                        instrPtr,
                                        extPos,
                                        hierHead,
                                        advAStp);


    /*****************************
    ***  Get the delta factor  ***
    *****************************/
	if (ret == RET_SUCCEED)
        *deltaFactor = GET_NUMBER(advAStp, A_AdvA_Delta);

    FREE_DYNST(advArgStp, AdvA_Arg);
    FREE_DYNST(advAStp,   A_AdvA);

    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_ComputeDeltaFactorWithAA_CRR_OPT()
**
**  Description :   Compute the delta factor for the option.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  extPos          :   Pointer to the extented position
**                  domainPtr       :   Pointer to the domain
**                  deltaFactor     :   Pointer to the delta factor to compute
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 29022000
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeDeltaFactorWithAA_CRR_OPT(   DBA_DYNFLD_STP      instrPtr,
                                                        DBA_HIER_HEAD_STP   hierHead,
                                                        DBA_DYNFLD_STP      extPos,
                                                        DBA_DYNFLD_STP      domainPtr,
                                                        DBA_DYNFLD_STP      instrLegPtr,
                                                        NUMBER_T            *deltaFactor)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    ID_T            calendarId;
    DBA_DYNFLD_STP  advArgStp   = NULLDYNST;
    DBA_DYNFLD_STP  advAStp     = NULLDYNST;
    DBA_DYNFLD_STP  instrBidon  = NULLDYNST;
    RET_CODE        ret;
	DATETIME_T      refDate;
    OPTVOLATILITYRULE_ENUM          optionVolRuleEn;	  /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    NUMBER_T        volatility=0.0;
    ID_T            instrId=0;
    INT_T           steps;					  /* REF4769 - SSO - 000516  NUMBER_T  -> INT_T*/
    FLAG_T          defaultMargin = FALSE;


    /*******************************************
    ***  Memory allocation for the argument  ***
    *******************************************/
    advArgStp   =   ALLOC_DYNST(AdvA_Arg);
    advAStp     =   ALLOC_DYNST(A_AdvA);


    /*******************************************
    ***  Test for memory allocation success  ***
    *******************************************/
	if  (advArgStp == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if  (advAStp == NULLDYNST)
	{
	    FREE(advArgStp);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}


    /****************************
    ***  Build the arguments  ***
    ****************************/

	/* set the keyword nature */
	SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_CRR_Opt);

	/* instrument Id */
	SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

	/* ref date */
	refDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
	SET_DATE(advArgStp, AdvA_Arg_Date, refDate.date);

    /* Set the spread */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Spread);

    /* Set the shock */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Shock);

    /* Get the calendar identifier */
    ret =   DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	if (    (ret != RET_SUCCEED)    ||  (calendarId <= 0)   )
	    GEN_GetApplInfo(ApplSysCalendarId, &calendarId);    /* Default calendar Id */
	SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
    SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 020109 */

	/* Set margin */
    ret = FIN_GetDefaultMarginForOptions(instrPtr, hierHead, &defaultMargin); /* REF7475 - YST - 020516 */

	SET_FLAG(advArgStp, AdvA_Arg_Margin, defaultMargin);

	/* Set domestic */
	SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);

    /* Set the steps */
    GEN_GetApplInfo(ApplOptPeriodNbr, &steps);
    SET_NUMBER(advArgStp, AdvA_Arg_Steps, steps);

    /* Set the volatility */
    GEN_GetApplInfo(ApplOptVolatilityRule, &optionVolRuleEn);	  /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    if  (optionVolRuleEn==OptVolatility_Historical)	       /* REF4769 - SSO - 000516 FLAG_T->OPTVOLATILITYRULE_ENUM */
    {
        if  (GET_ENUM(instrLegPtr, A_Instr_NatEn)==InstrNat_CashAcct)
        {
            ret = DBA_GetDefOption( GET_ENUM(instrPtr,A_Instr_NatEn),
                                    GET_ID(instrPtr, A_Instr_RefCurrId),
                                    GET_ID(instrLegPtr, A_Instr_RefCurrId),
                                    &instrBidon);

            /* REF4586 - RAK - 000427 */
            /* If instrument isn't found, use underlying (like before) */
            if (ret == RET_SUCCEED && instrBidon != NULLDYNST)
            {
                instrId = GET_ID(instrBidon, A_Instr_Id);
            }
            else
            {
                instrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
            }

            FREE_DYNST(instrBidon, A_Instr);
        }
        else
        {
            instrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
        }

        /* REF4586 - RAK - 000427 */
        /* If no underlying (or default instrument), don't search volatility */
        if (instrId == 0)
        {
            ret = RET_GEN_INFO_NODATA;
        }
        else
        {
            ret = DBA_GetChronoVal( Instr,
                                    instrId,
					                UNUSED,
			                        (ENUM_T) ChronoNat_Volatility,
                                    refDate,
					                TimeDim_Last,
                                    TRUE,
                                    &volatility);
        }
    }
    else
    {
        instrId = GET_ID(instrPtr, A_Instr_Id);
        ret = DBA_GetChronoVal( Instr,
                                instrId,
					            UNUSED,
			                    (ENUM_T) ChronoNat_ImpVol,
                                refDate,
					            TimeDim_Last,
                                TRUE,
                                &volatility);
    }

    if  (ret!=RET_SUCCEED)  /* DEV1055 - CSA - Yes, I know that there has been an error. But the life continue...*/
    {
        ret = RET_SUCCEED;
        volatility = 0;
    }
    SET_NUMBER(advArgStp, AdvA_Arg_Volatility, volatility);


    /*********************************
    ***  Compute the delta factor  ***
    *********************************/
    if  (ret==RET_SUCCEED)
        ret =   SCE_ComputeCurrKeyWord( advArgStp,
                                        instrPtr,
                                        extPos,
                                        hierHead,
                                        advAStp);


    /*****************************
    ***  Get the delta factor  ***
    *****************************/
	if (ret == RET_SUCCEED)
        *deltaFactor = GET_NUMBER(advAStp, A_AdvA_Delta);

    FREE_DYNST(advArgStp, AdvA_Arg);
    FREE_DYNST(advAStp,   A_AdvA);

    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_ComputeDeltaFactorWithAA_CRR_CONVBOND()
**
**  Description :   Compute the delta factor for the convbond.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  extPos          :   Pointer to the extented position
**                  domainPtr       :   Pointer to the domain
**                  deltaFactor     :   Pointer to the delta factor to compute
**
**  Return      :   RET_CODE
**
**  Creation    :   REF5049 - AKO - 20001106
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeDeltaFactorWithAA_CRR_CONVBOND(  DBA_DYNFLD_STP      instrPtr,
                                                            DBA_HIER_HEAD_STP   hierHead,
                                                            DBA_DYNFLD_STP      underInstr,
                                                            DBA_DYNFLD_STP      extPos,
                                                            DBA_DYNFLD_STP      domainPtr,
                                                            NUMBER_T            *deltaFactor)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    ID_T            calendarId;
    DBA_DYNFLD_STP  advArgStp   = NULLDYNST;
    DBA_DYNFLD_STP  advAStp     = NULLDYNST;
    RET_CODE        ret;
	DATETIME_T      refDate;
    NUMBER_T        volatility=0.0;
    INT_T           steps;

    /*******************************************
    ***  Memory allocation for the argument  ***
    *******************************************/
    advArgStp   =   ALLOC_DYNST(AdvA_Arg);
    advAStp     =   ALLOC_DYNST(A_AdvA);


    /*******************************************
    ***  Test for memory allocation success  ***
    *******************************************/
	if  (advArgStp == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if  (advAStp == NULLDYNST)
	{
	    FREE(advArgStp);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    /****************************
    ***  Build the arguments  ***
    ****************************/
    /* ------------------------------------------------------------------------------------ */
    /* AA_CRR_CONVBOND ( instr, [date], [spread], [shock], [calendar], [steps], volatility) */
    /* ------------------------------------------------------------------------------------ */

	/* set the keyword nature */
	SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_CRR_Convbond);

	/* instrument Id */
	SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

	/* ref date */
	refDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
	SET_DATE(advArgStp, AdvA_Arg_Date, refDate.date);

    /* Set the spread */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Spread);

    /* Set the shock */
    SET_NULL_NUMBER(advArgStp, AdvA_Arg_Shock);

    /* Get the calendar identifier */
    ret =   DBA_GetCalendarFromInstr(instrPtr, &calendarId);
	if (    (ret != RET_SUCCEED)    ||  (calendarId <= 0)   )
	    GEN_GetApplInfo(ApplSysCalendarId, &calendarId);    /* Default calendar Id */
	SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
    SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 020109 */

    /* Set the steps */
    GEN_GetApplInfo(ApplOptPeriodNbr, &steps);
    SET_NUMBER(advArgStp, AdvA_Arg_Steps, steps);

    /* Set the volatility */
    /* GEN_GetApplInfo(ApplOptVolatilityRule, &optionVolRuleEn); */
    if (RET_SUCCEED == ret)
    {
        if ((ret=DBA_GetChronoVal( Instr,
                            GET_ID(underInstr, A_Instr_Id),
			                UNUSED,
		                    (ENUM_T)ChronoNat_Volatility,
                            refDate,
			                TimeDim_Last,
                            TRUE,
                            &volatility))!=RET_SUCCEED)
        {  /* DEV1055 - CSA - Yes, I know that there has been an error. But the life continue...*/
            ret = RET_SUCCEED;
            volatility = 0;
        }
        SET_NUMBER(advArgStp, AdvA_Arg_Volatility, volatility);
    }

    /*********************************
    ***  Compute the delta factor  ***
    *********************************/
    if  (ret==RET_SUCCEED)
    {
        ret=SCE_ComputeCurrKeyWord( advArgStp,
                                    instrPtr,
                                    extPos,
                                    hierHead,
                                    advAStp);
    }

    /*****************************
    ***  Get the delta factor  ***
    *****************************/
	if (ret == RET_SUCCEED)
        *deltaFactor = GET_NUMBER(advAStp, A_AdvA_Delta);

    FREE_DYNST(advArgStp, AdvA_Arg);
    FREE_DYNST(advAStp,   A_AdvA);

    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_ComputeDeltaForOption()
**
**  Description :   Compute the delta factor for the option.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  extPos          :   Pointer to the extented position
**                  deltaFactor     :   Pointer to the delta factor to compute
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22022000
**  Last modif. :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeDeltaForOption(  DBA_DYNFLD_STP      instrPtr,
                                            DBA_HIER_HEAD_STP   hierHead,
                                            DBA_DYNFLD_STP      extPos,
                                            DBA_DYNFLD_STP      instrLegPtr,
                                            NUMBER_T            *deltaFactor)
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    RET_CODE            ret = RET_SUCCEED;
    ENUM_T              optionRiskRuleEn;
    INSTRCATEGORY_ENUM  instrCategory;
    OPTMODEL_ENUM       defModelEn;
    OPTMODEL_ENUM       optionPricingModelParamEn;
    OPTVOLATILITYRULE_ENUM optionVolatilityRuleParamEn; /* REF4713 - RAK - 000509 */
	DBA_DYNFLD_STP      domainPtr, instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;


    /*******************************
    ***  Get the domain pointer  ***
    *******************************/
    domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));


    /******************************************************
    ***  Get the option risk rule enum from the domain  ***
    ******************************************************/
    optionRiskRuleEn = GET_ENUM(domainPtr, A_Domain_OptRiskRuleEn);


    /**************************
    ***  Compute the delta  ***
    **************************/
    *(deltaFactor) = 1.0;   /* Force the delta factor to 1 */
    if  (optionRiskRuleEn!=1)
    {
		/* PMSTA02881 - RAK - 070710 - Read chrono first */
		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     GET_ID(instrPtr, A_Instr_Id));
		SET_DATETIMEST(dimChronoPtr, Dim_InstrChrono_RefDate,   GET_DATETIMEST(domainPtr, A_Domain_InterpFromDate));
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_Delta);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		if (FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead) == RET_SUCCEED)
		{
			*deltaFactor = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);

			FREE_DYNST(instrChrono, A_InstrChrono);
			FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
			return(RET_SUCCEED);
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		/* Computation (like before) */
        /*******************************************
        ***  Get the category of the instrument  ***
        *******************************************/
        instrCategory = FIN_InstrCategory(instrPtr,hierHead);


        /*****************************************************
        ***  Get the default model enum of the instrument  ***
        *****************************************************/
        defModelEn = (OPTMODEL_ENUM) GET_ENUM(instrPtr,A_Instr_DefModelEn);    /* REF7264 - PMO */


        /***************************************************************
        ***  Get the default model enum from the default parameters  ***
        ***************************************************************/
        GEN_GetApplInfo( ApplOptPricingModel, &optionPricingModelParamEn);


        /***********************************************************
        ***  Get the option volatility rule from the parameters  ***
        ***********************************************************/
        GEN_GetApplInfo( ApplOptVolatilityRule, &optionVolatilityRuleParamEn);


        /**********************************
        ***  Call the good computation  ***
        **********************************/
        if  (
                (   (instrCategory==InstrCategory_Options)  ||  (instrCategory==InstrCategory_ExoticOptions)    )
            &&  ((   defModelEn==OptModel_BlackScholes   )
            ||  (   (optionPricingModelParamEn == OptModel_BlackScholes)    &&  (defModelEn==OptModel_None) ))
            )
        {
            /*****************************************
            ***  Call to the AA_BS_OPT() function  ***
            *****************************************/
            ret = FIN_ComputeDeltaFactorWithAA_BS_OPT(  instrPtr,
                                                        hierHead,
                                                        extPos,
                                                        domainPtr,
                                                        instrLegPtr,
                                                        deltaFactor);
        }
        else if (   (instrCategory==InstrCategory_Options)
                 && ((defModelEn==OptModel_Binomial)
                 || ((optionPricingModelParamEn == OptModel_Binomial)    &&  (defModelEn==OptModel_None) ))
                )
        {
            /******************************************
            ***  Call to the AA_CRR_OPT() function  ***
            ******************************************/
            ret = FIN_ComputeDeltaFactorWithAA_CRR_OPT( instrPtr,
                                                        hierHead,
                                                        extPos,
                                                        domainPtr,
                                                        instrLegPtr,
                                                        deltaFactor);
        }
        else if (instrCategory==InstrCategory_ConvertibleBond)
        {
            /***********************************************
            ***  Call to the AA_CRR_CONVBOND() function  ***
            ***********************************************/
            ret = FIN_ComputeDeltaFactorWithAA_CRR_CONVBOND( instrPtr,
                                                             hierHead,
                                                             extPos,
                                                             domainPtr,
                                                             instrLegPtr,
                                                             deltaFactor);
        }
    }


    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}

/*************************************************************************
**
**  Function    :   FIN_GetDeltaInstrument()
**
**  Description :   Get the underly instrument from the daabase
**                  and compute the delta factor.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  extPos          :   Pointer to the extented position
**                  instrLegPtr     :   Pointer of pointer to leg
**                  deltaFactor     :   Pointer to the delta factor to compute
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 22022000
**
**  History     :
**
*************************************************************************/
STATIC RET_CODE FIN_GetDeltaInstrument( DBA_DYNFLD_STP      instrPtr,
                                        DBA_HIER_HEAD_STP   hierHead,
                                        DBA_DYNFLD_STP      extPos,
                                        DBA_DYNFLD_STP      *instrLegPtr,
                                        NUMBER_T            *deltaFactor,
                                        FLAG_T              *allocFlg)      /*  FPL-PMSTA09803-100510   */
{
    /*************************************
    ***  Local variables declarations  ***
    *************************************/
    RET_CODE    ret;
    ID_T        underlyInstrId;
    /*FLAG_T      allocFlg; FPL-PMSTA09803-100510   */
	/*DBA_DYNFLD_STP underInstr=NULLDYNST; FPL-PMSTA09803-100510 remove code PMSTA09442 *//* PMSTA09442-CHU-100303 */


    /**************************************
    ***  Get the underly instrument id  ***
    **************************************/
    underlyInstrId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);


    /***********************************
    ***  Get the underly instrument  ***
    ***********************************/

    ret = DBA_GetInstrById( underlyInstrId,
                            TRUE,       /* If it wasn't in hierarchy, add it */
                            /*&*/allocFlg,  /* because of add, will be FALSE */ /*  FPL-PMSTA09803-100510 now pointer given as parameter    */
                            /*&underInstr,*/ instrLegPtr, /*    FPL-PMSTA09803-100510 remove code PMSTA09442    */ /* PMSTA09442-CHU-100303 put this one into hierarchy */
                            hierHead,
                            UNUSED,
                            UNUSED);


    /*********************************
    ***  Compute the delta factor  ***
    *********************************/
    if  (ret==RET_SUCCEED)
	{
		/* PMSTA09442-CHU-100303
		 * Copy instrument to ensure initial code above this function still works the same way
		 */
        /*  FPL-PMSTA09803-100510 remove code PMSTA09442
		if ((*(instrLegPtr) = ALLOC_DYNST(A_Instr)) == NULLDYNST)
		{
			if (allocFlg == TRUE) { FREE_DYNST(underInstr, A_Instr); }
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		COPY_DYNST(*(instrLegPtr), underInstr, A_Instr);*/

        ret = FIN_ComputeDeltaForOption(    instrPtr,
                                            hierHead,
                                            extPos,
                                            *(instrLegPtr),
                                            deltaFactor);
	}


    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}


/*************************************************************************
**
**  Function    :   FIN_SetOrderLegs()
**
**  Description :   Set the order of the legs.
**
**  Arguments   :   instrPtr        :   Pointer to the instrument
**                  hierHead        :   Pointer to the hierarchy
**                  instrLeg1Ptr    :   Pointer to pointer to the first leg
**                  instrLeg2Ptr    :   Pointer to pointer to the second leg
**
**  Return      :   RET_CODE
**
**  Creation    :   DEV1055 - CSA - 26111999
**
**  History     :
**
*************************************************************************/
RET_CODE FIN_SetOrderLegs(       DBA_DYNFLD_STP      instrPtr,
                                 DBA_HIER_HEAD_STP   hierHead,
                                 DBA_DYNFLD_STP      *instrLeg1Ptr,
                                 DBA_DYNFLD_STP      *instrLeg2Ptr)
{
    /*  Local variables declarations    */
    INSTRCATEGORY_ENUM  instrCategory;
    ENUM_T              instrLegNature;
    ENUM_T              instrLegPricing;
    DBA_DYNFLD_STP      instrSwapping;
    RET_CODE            ret =   RET_SUCCEED;    /*  For the fun ;-) */

    /*  Get the category of the instrument  */
    instrCategory   =   FIN_InstrCategory( instrPtr, hierHead);

    /*  Test for swap the 2 legs    */
    switch  (instrCategory)
    {
    case    InstrCategory_BondFutures:
    case    InstrCategory_BondForwards:
    case    InstrCategory_EquityFutures:
    case    InstrCategory_EquityForwards:
    case    InstrCategory_Options:
    case    InstrCategory_ExoticOptions:
	case	InstrCategory_ACDC: /* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */

        /*  Get the nature of the first leg */
        instrLegNature  =   GET_ENUM(instrLeg1Ptr[0],A_Instr_NatEn);

        /*  If the first leg is a discount instrument, then swap the 2 legs */
        if  (instrLegNature==InstrNat_Discount)
        {
            instrSwapping   =   *instrLeg1Ptr;
            *instrLeg1Ptr   =   *instrLeg2Ptr;
            *instrLeg2Ptr   =   instrSwapping;
        }
        break;

    case    InstrCategory_CurrencyFutures:
    case    InstrCategory_CurrencyForwards:

        /*  Get the valuation rule of the first leg */
        instrLegPricing =   GET_ENUM(instrLeg1Ptr[0],A_Instr_ValRuleEn);

        /*  If the valuation rule of the first leg is quoted, then swap the 2 legs */
        if  (instrLegPricing==ValRule_Quote)
        {
            instrSwapping   =   *instrLeg1Ptr;
            *instrLeg1Ptr   =   *instrLeg2Ptr;
            *instrLeg2Ptr   =   instrSwapping;
        }
        break;

    case    InstrCategory_Swap:

        /* Paid leg is first leg */
	    if ((SUBNAT_ENUM)
	        GET_ENUM((*instrLeg1Ptr), A_Instr_SubNatEn) == SubNat_RecSwapFloatLeg ||
	        (SUBNAT_ENUM)
	        GET_ENUM((*instrLeg1Ptr), A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg)
	    {
	        instrSwapping = *instrLeg1Ptr;
	        *instrLeg1Ptr = *instrLeg2Ptr;
	        *instrLeg2Ptr = instrSwapping;
	    }
	break;

    case    InstrCategory_ForexSwap:

	/* Paid leg is first leg */
	if (GET_ID(  (*instrLeg2Ptr), A_Instr_RefCurrId) == GET_ID(instrPtr, A_Instr_SwapPaidCurrId) &&
	    GET_ENUM((*instrLeg2Ptr), A_Instr_AccrualRuleEn) == GET_ENUM(instrPtr, A_Instr_PaidAccrualRuleEn) &&
	    GET_ID(  (*instrLeg2Ptr), A_Instr_YieldCurveInstrId) == GET_ID(instrPtr, A_Instr_SwapPaidYcInstrId))
	{
	    instrSwapping = *instrLeg1Ptr;
	    *instrLeg1Ptr = *instrLeg2Ptr;
	    *instrLeg2Ptr = instrSwapping;
	}
	break;

    case    InstrCategory_ConvertibleBond:  /* REF5049 - AKO - 001116 */
            instrLegNature  =   GET_ENUM(instrLeg1Ptr[0],A_Instr_NatEn);
            if (instrLegNature == InstrNat_Stock)
            {
	            instrSwapping = *instrLeg1Ptr;
	            *instrLeg1Ptr = *instrLeg2Ptr;
	            *instrLeg2Ptr = instrSwapping;
            }
        break;

    case    InstrCategory_Others:
    default:
        break;
    }

    /*  Return value    */
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrGetNatureLeg()
**
**  Description :   Get the nature of an instrument leg
**
**  Arguments   :   instrumentPtr   instrument structure pointer
**					hierHead		Current hierarchiy header pointer
**
**  Return      :   LEGNAT_ENUM
**
**  Create		:	DEV1055 - CSA - 13101999
**	Modif		:	DEV1055 - CSA - 16111999
**
*************************************************************************/
LEGNAT_ENUM FIN_InstrGetNatureLeg(	DBA_DYNFLD_STP instrumentPtr,
					DBA_HIER_HEAD_STP	hierHead)
{
	/*	Local variable declaration	*/
	DBA_DYNFLD_STP	parentInstr=NULLDYNST;
	FLAG_T			isInHier;
	ENUM_T			natInstr;
	INSTRCATEGORY_ENUM	instrCategory;

	/*	If the instrment identifier < 0 AND the valuation rule is
		equal to ValRule_Theo, then it's possible the instrument is
		a swap or a forex swap !!!
	*/
	if (GET_ENUM(instrumentPtr, A_Instr_ValRuleEn) == ValRule_Theo &&
	    GET_ID(instrumentPtr, A_Instr_Id) <0)
	{
		/*	Test for a bond	*/
		if (GET_ENUM(instrumentPtr,A_Instr_NatEn)==InstrNat_Bond)
		{	/*	Yes, it's a bond, so what is its subnature ?	*/
			switch(GET_ENUM(instrumentPtr,A_Instr_SubNatEn))
			{
			case    SubNat_RecSwapFloatLeg:
			case    SubNat_RecSwapFixedLeg:
			case    SubNat_PaidSwapFloatLeg:
			case    SubNat_PaidSwapFixedLeg:
				return(LegNat_Swap);		    /*	1 -> Swap	*/
				break;

			default:
				break;				    /*	Others cases	*/
			}
		}

		/*	Test for a discount	*/
		else if	(GET_ENUM(instrumentPtr,A_Instr_NatEn)==InstrNat_Discount)
		{
			/*	Get the parent instrument of the leg	*/
			DBA_GetInstrById(GET_ID(instrumentPtr,A_Instr_ParentInstrId),
					FALSE,
					&isInHier,
					&parentInstr,
					hierHead,
					UNUSED,
					UNUSED);

			/*	Get the nature	*/
			natInstr	=	GET_ENUM(parentInstr,A_Instr_NatEn);

			/*	Get the category of the instrument  */
			instrCategory   =   FIN_InstrCategory(parentInstr, hierHead);

			/*	Purge the instrument ???	*/
			if	(isInHier==TRUE)
				FREE_DYNST(parentInstr,A_Instr);

			/*	Test if its parent is a forex swap	*/
			if	(natInstr==InstrNat_ForexSwaps)
				return(LegNat_ForexSwap);	/*	2 -> Forex swap	*/

			/*	Test if its parent is a categorised instrument	*/
			return(FIN_InstrGetNatureLegFromInstrCategory(instrCategory));
		}
	}
	/*  If instrument is a "created" discount (negativ identifier) and parent is */
	/*  a BondFutures, BondForwards, ... then instrument is a leg		     */
	else if (GET_ENUM(instrumentPtr,A_Instr_NatEn)==InstrNat_Discount &&
	         IS_NULLFLD(instrumentPtr,A_Instr_ParentInstrId) == FALSE)
	{
		/*	Get the parent instrument of the leg	*/
			DBA_GetInstrById(GET_ID(instrumentPtr,A_Instr_ParentInstrId),
					FALSE,
					&isInHier,
					&parentInstr,
					hierHead,
					UNUSED,
					UNUSED);

		/*	Get the category of the instrument  */
		if (parentInstr != NULLDYNST)
		{
		    instrCategory   =   FIN_InstrCategory(parentInstr, hierHead);

		    /*	Purge the instrument ???	*/
		    if	(isInHier==TRUE)
		    { FREE_DYNST(parentInstr,A_Instr); }

		    return(FIN_InstrGetNatureLegFromInstrCategory(instrCategory));
		}
	}

	/*	Others cases	*/
	return(LegNat_Other);
}	/*	End function FIN_InstrGetNatureLeg	*/

/************************************************************************
**
**  Function    :   FIN_InstrGetNatureLegFromInstrCategory()
**
**  Description :   Get the nature of an instrument leg
**
**  Arguments   :   instrCategory   instrument category
**
**  Return      :   LEGNAT_ENUM
**
**  Create		:	DEV1055 - CSA - 08121999
**
*************************************************************************/
STATIC	LEGNAT_ENUM FIN_InstrGetNatureLegFromInstrCategory(INSTRCATEGORY_ENUM	instrCategory)
{
    switch(instrCategory)
    {
    case InstrCategory_BondFutures:
	return(LegNat_BondFutures);

    case InstrCategory_BondForwards:
	return(LegNat_BondForwards);

    case InstrCategory_EquityFutures:
	return(LegNat_EquityFutures);

    case InstrCategory_EquityForwards:
	return(LegNat_EquityForwards);

    case InstrCategory_CurrencyFutures:
	return(LegNat_CurrencyFutures);

    case InstrCategory_CurrencyForwards:
	return(LegNat_CurrencyForwards);

    default:
	return(LegNat_Other);
    }
}


/************************************************************************
**
**  Function    :   FIN_ChangeInstrLegNatEn()
**
**  Description :   Modify Nature of instr_Leg to Cash Account
**
**  Arguments   :   instrPtr        - current instrument
**                  posHierHead     - pointer to hierarchy
**
**  Return      :   LEGNAT_ENUM
**
**  Create		:	REF6057 - AKO/CSA - 010716
**  Modif.      :  REF6057.3504 - AKO - 010910
**                  REF6057 - CSY - 020906
**
*************************************************************************/
RET_CODE FIN_ChangeInstrLegNatEn(DBA_DYNFLD_STP         instrPtr,
                                 DBA_HIER_HEAD_STP      posHierHead)
{
    /******************
    ***  Variables  ***
    ******************/
    DBA_DYNFLD_STP      instrLeg1Ptr = NULLDYNST;
    DBA_DYNFLD_STP      instrLeg2Ptr = NULLDYNST;
    INSTRCATEGORY_ENUM  instrCategory;
    RET_CODE            retCd = RET_GEN_INFO_NOACTION;

    /********************************************************
    ***  On recherche les instruments dans la hierarchie  ***
    ********************************************************/
    if (posHierHead != NULL)
    {
	    retCd =   FIN_SearchInstrLegInHier( instrPtr,
                                            posHierHead,
                                            &instrLeg1Ptr,
                                            &instrLeg2Ptr);
    }

    instrCategory   =   FIN_InstrCategory(instrPtr, posHierHead);

    if ((RET_SUCCEED==retCd && instrLeg2Ptr!=NULLDYNST) &&
        (instrCategory!=InstrCategory_Swap &&
         instrCategory!=InstrCategory_ForexSwap))
    {
        /* REF6057.3502010614 - AKO - 010716 */
        RISKFUTRULE_ENUM        riskFut;
        RISKFWDRULE_ENUM        riskFwd;
        RISKOPTPROCESSRULE_ENUM riskOpt;

        GEN_GetApplInfo(ApplRiskFutRule, &riskFut);
	    GEN_GetApplInfo(ApplRiskFwdRule, &riskFwd);
   	    GEN_GetApplInfo(ApplRiskOptProcessRule, &riskOpt);

        /* REF6057 - CSY - 020906 separate cases on riskFwd, riskFut */
        /* AKO - 20020913 : re-code with switch tag and other stuff */
        switch(instrCategory)
        {
            case    InstrCategory_CurrencyFutures:
                    switch(riskFut)
                    {
                       case RiskFutRule_FutPos:
                            /* 1: fut + cash */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Future);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFutRule_UnderlyPos:
                            /* 2: fut + cash */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_CashAcct);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFutRule_FutDiscount:
                            /* 3: fut + disc */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Future);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFutRule_UnderlyDiscount:
                           /* 4: disc + disc*/
                           SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Discount);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            break;
                    }
                    break;
           case   InstrCategory_EquityFutures:
           case   InstrCategory_BondFutures:
                   switch(riskFut)
                   {
                       case RiskFutRule_FutPos:
                             /* 1: fut + cash */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Future);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFutRule_UnderlyPos:
                            /* 2: fut + cash */
                            /*SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_CashAcct);*/
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFutRule_FutDiscount:
                            /* 3: fut + disc */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Future);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            SET_CODE(instrLeg1Ptr, A_Instr_Cd, GET_CODE(instrPtr, A_Instr_Cd));
                            break;

                       case RiskFutRule_UnderlyDiscount:
                            /* 4: disc + disc*/
                            /*SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Discount);*/
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            break;
                   }
                   break;
           case InstrCategory_BondForwards:
           case InstrCategory_EquityForwards:
                if ((riskFwd ==RiskFwdRule_FwdPos ) || (RiskFwdRule_UnderlyPos == riskFwd))
                {    /* 1,2 = cash */
                    SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                }

                /* 3, 4 = discount */
                if ((riskFwd == RiskFwdRule_FwdDiscount) || (RiskFwdRule_UnderlyDiscount == riskFwd))
                {    /* 1,2 = cash */
                    SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                }
                break;
           case    InstrCategory_CurrencyForwards:
                   switch(riskFwd)
                   {
                       case RiskFwdRule_FwdPos:
                            /* 1: fwd + cash */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Forward);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                       break;

                       case RiskFwdRule_UnderlyPos:
                            /* 2: Fwd + cash */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_CashAcct);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct); /* logiquement est d�j� par d�faut  */
                            break;

                       case  RiskFwdRule_FwdDiscount:
                           /* 3: Fwd + disc */
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Forward);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            break;

                       case RiskFwdRule_UnderlyDiscount:
                            /* 4: disc + disc*/
                            SET_ENUM(instrLeg1Ptr, A_Instr_NatEn, InstrNat_Discount);
                            SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount); /* logiquement est d�j� par d�faut  */
                            break;
                    }
                    break;
           case InstrCategory_Options:
                if ((riskOpt == RiskOptRule_OptPos))
                {  /* riskOpt 1 = cash */
                    SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_CashAcct);
                }
                else
                {    /* RFE6057 - AKO - 010716 */
                    SET_ENUM(instrLeg2Ptr, A_Instr_NatEn, InstrNat_Discount);
                }
                break;

           default:
                break;
       }
    }
   return (retCd);
}


/************************************************************************
**
**  Function    :   FIN_TestSwapBriseInterCond()
**
**  Description :   Test if interest rate conditions for standard swap "bris�" are well defined, i.e.
**                  for one leg 1, 2 or 3 interest rate conditions can be defined.
**                  1 condition:
**                  - fixed A_InterCond_InterCalcRuleEn
**                  2 conditions:
**                  - two distinct A_InterCond_NatEn
**                  - 1 fixed and 1 floating A_InterCond_InterCalcRuleEn
**                  3 conditions:
**                  - two distinct A_InterCond_NatEn
**                  - 2 fixed and 1 floating A_InterCond_InterCalcRuleEn
**                  - with broken period at the beginning and end, i.e. in the time order: fixed - floating - fixed
**                  and returns end dates for leg and floating rate instr. Id
**
**                  (DBA_SelectInterCond2() sort
**                      1. fixed calc. rule 2. floating calc. rule 3. ascending begin date)
**
**  Arguments   : input
**                  interCond           - interest rate conditions
**                  interCondNbr        - number of interest rate conditions
**                output
**                  endDateInterCond    - end date of last inter. rate cond.
**                  floatInstrId        - floating rate instr. Id of interest rate cond. or 0 (if does not exist)
**
**  Return      :   RET_SUCCED or error code if conditions are bad
**
**  Creation	:   REF5941 - YST - 020508 - swap mgmt extension
**
*************************************************************************/
STATIC RET_CODE  FIN_TestSwapBriseInterCond(DBA_DYNFLD_STP  *interCond,
                                                int         interCondNbr,
												DATE_T		*begDateInterCond,	/* REF10094 - RAK - 040519 */
                                                DATE_T      *endDateInterCond,
                                                ID_T        *floatInstrId)
{
    DATE_T      interDate1, interDate2;
    RET_CODE    ret = RET_SUCCEED;

    if (1 == interCondNbr  &&
        InterCalcRule_Fixed == (INTERCALCRULE_ENUM)GET_ENUM(interCond[0], A_InterCond_IntCalcRuleEn))
    {
        *endDateInterCond = GET_DATE(interCond[0], A_InterCond_EndDate);

		/* REF10094 - RAK - 040519 */
		*begDateInterCond = GET_DATE(interCond[0], A_InterCond_BeginDate);
    }
    else if (2 == interCondNbr &&
        InterCalcRule_Fixed    == (INTERCALCRULE_ENUM)GET_ENUM(interCond[0], A_InterCond_IntCalcRuleEn) &&
        InterCalcRule_Floating == (INTERCALCRULE_ENUM)GET_ENUM(interCond[1], A_InterCond_IntCalcRuleEn))
    {
        interDate1 = GET_DATE(interCond[0], A_InterCond_EndDate);
        interDate2 = GET_DATE(interCond[1], A_InterCond_EndDate);
        *endDateInterCond = (interDate1 >= interDate2) ? interDate1 : interDate2;

        *floatInstrId = GET_ID(interCond[1], A_InterCond_BenchInstrId);

		/* REF10094 - RAK - 040519 */
		interDate1 = GET_DATE(interCond[0], A_InterCond_BeginDate);
        interDate2 = GET_DATE(interCond[1], A_InterCond_EndDate);
        *begDateInterCond = (interDate1 >= interDate2) ? interDate2 : interDate1;

    }
    else if (3 == interCondNbr &&
        InterCalcRule_Fixed    == (INTERCALCRULE_ENUM)GET_ENUM(interCond[0], A_InterCond_IntCalcRuleEn) &&
        InterCalcRule_Fixed    == (INTERCALCRULE_ENUM)GET_ENUM(interCond[1], A_InterCond_IntCalcRuleEn) &&
        InterCalcRule_Floating == (INTERCALCRULE_ENUM)GET_ENUM(interCond[2], A_InterCond_IntCalcRuleEn) &&
        GET_DATE(interCond[0], A_InterCond_EndDate) <= GET_DATE(interCond[2], A_InterCond_BeginDate) &&
        GET_DATE(interCond[2], A_InterCond_EndDate) <= GET_DATE(interCond[1], A_InterCond_BeginDate))
    {
		/* REF10094 - RAK - 040519 */
		*begDateInterCond = GET_DATE(interCond[0], A_InterCond_BeginDate);

        *endDateInterCond = GET_DATE(interCond[1], A_InterCond_EndDate);

        *floatInstrId = GET_ID(interCond[2], A_InterCond_BenchInstrId);
    }
    else
    {
        ret = RET_FIN_ERR_INVDATA;
    }

    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_SetValuesForSwapBriseLegs()
**
**  Description :   Initialises some fields in instrument legs of swap "bris�"
**                  and sets A_Instr_IsComplexInstrFlg = TRUE
**                  (Flag is currently used to distinguish normal swap (FALSE) from swap bris� (TRUE).)
**                  If fixed/floating swap set to NULL field A_Instr_FloatInstrId or A_Instr_PaidFloatInstrId,
**                  to be sure that instrument legs are well defined with informations of inter. rate condintions.
**
**                  Attention with the arguments at the call:
**                  If SELL of instrument
**                  - leg with subnature received setted with values from interest rate cond. paid
**                  - leg with subnature paid setted with values from interest rate cond. received
**
**
**  Arguments   :   instrLegPtr             - pointer of instrument
**                  recInstrLegPtr          - pointer of received leg
**                  paidInstrLegPtr         - pointer of paid leg
**                  recLegInterCondNat      - nature from corresponding interest rate cond. for received leg
**                  paidLegInterCondNatEn   - nature from corresponding interest rate cond. for paid leg
**                  recLegEndDate           - end date from corresponding interest rate cond. for received leg
**                  paidLegEndDate          - end date from corresponding interest rate cond. for paid leg
**                  recFloatInstrId         - floating rate instr. from received interest rate cond. (copied to both legs)
**                  paidFloatInstrId        - floating rate instr. from paid interest rate cond. (copied to both legs,
**                                            for further treatement in functions FIN_SetValuesForPaidSwapFloatLeg, etc.)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	 :  REF5941 - YST - 020207
**  Modification :  REF5941 - YST - 020508
**               :  REF7782 - YST - 020904
**
*************************************************************************/
STATIC RET_CODE FIN_SetValuesForSwapBriseLegs(DBA_DYNFLD_STP    instrPtr,
                                            DBA_DYNFLD_STP      recInstrLegPtr,
                                            DBA_DYNFLD_STP      paidInstrLegPtr,
                                            INTERCONDNAT_ENUM   recLegInterCondNat,
                                            INTERCONDNAT_ENUM   paidLegInterCondNat,
											DATE_T              recLegBegDate,			/* REF10094 - RAK - 040519 */
                                            DATE_T              paidLegBegDate,			/* REF10094 - RAK - 040519 */
                                            DATE_T              recLegEndDate,
                                            DATE_T              paidLegEndDate,
                                            ID_T                recFloatInstrId,
                                            ID_T                paidFloatInstrId)
{
    RET_CODE ret = RET_SUCCEED;

    /* REF7782 - YST - 020904 - change A_Instr_IsComplexInstrFlg to A_Instr_ComplexInstrEn */
    if ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix)
    {
        /* swap legs are ComplexInstr_BrokSwapHedgFix for swap of sub nature SubNat_FixFltSwapHedgFix */
        SET_ENUM(recInstrLegPtr,  A_Instr_ComplexInstrEn, ComplexInstr_BrokSwapHedgFix);
        SET_ENUM(paidInstrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_BrokSwapHedgFix);
    }
    else
    {
        /* swap legs are ComplexInstr_BrokSwap for all other broken swap (swap bris�) */
        SET_ENUM(recInstrLegPtr,  A_Instr_ComplexInstrEn, ComplexInstr_BrokSwap);
        SET_ENUM(paidInstrLegPtr, A_Instr_ComplexInstrEn, ComplexInstr_BrokSwap);
    }
    SET_ENUM(recInstrLegPtr,  A_Instr_InterCondNatEn, recLegInterCondNat);
    SET_ENUM(paidInstrLegPtr, A_Instr_InterCondNatEn, paidLegInterCondNat);
    /*  FPL-PMSTA13143-111109 end date cannot be after end date of instrument   */
    if (DATE_Cmp(recLegEndDate, GET_DATE(instrPtr, A_Instr_EndDate)) > 0)
        recLegEndDate =  GET_DATE(instrPtr, A_Instr_EndDate);
    if (DATE_Cmp(paidLegEndDate, GET_DATE(instrPtr, A_Instr_EndDate)) > 0)
        paidLegEndDate =  GET_DATE(instrPtr, A_Instr_EndDate);
    SET_DATE(recInstrLegPtr,  A_Instr_EndDate, recLegEndDate);
	SET_DATE(paidInstrLegPtr, A_Instr_EndDate, paidLegEndDate);

	/* REF10094 - RAK - 040519 */
	SET_DATE(recInstrLegPtr,  A_Instr_BeginDate, recLegBegDate);
	SET_DATE(paidInstrLegPtr, A_Instr_BeginDate, paidLegBegDate);

    /* set floating instrument id in both legs */
    if (recFloatInstrId > 0)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == TRUE ||
           (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) != TRUE &&
           recFloatInstrId == GET_ID(instrPtr, A_Instr_FloatInstrId)))
        {
            SET_ID(recInstrLegPtr, A_Instr_FloatInstrId, recFloatInstrId);
            SET_ID(paidInstrLegPtr, A_Instr_FloatInstrId, recFloatInstrId);
        }
        else
        {
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_SetValuesLegs",
			             GET_CODE(instrPtr, A_Instr_Cd), "different floating rate identifier");
            ret = RET_FIN_ERR_INVDATA;
        }
    }
    if (paidFloatInstrId > 0)
    {
        if (IS_NULLFLD(instrPtr, A_Instr_PaidFloatInstrId) == TRUE ||
            (IS_NULLFLD(instrPtr, A_Instr_PaidFloatInstrId) != TRUE &&
            paidFloatInstrId == GET_ID(instrPtr, A_Instr_PaidFloatInstrId)))
        {
            SET_ID(recInstrLegPtr, A_Instr_PaidFloatInstrId, paidFloatInstrId);
            SET_ID(paidInstrLegPtr, A_Instr_PaidFloatInstrId, paidFloatInstrId);
        }
        else
        {
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_SetValuesLegs",
			             GET_CODE(instrPtr, A_Instr_Cd), "different paid floating rate identifier");
            ret = RET_FIN_ERR_INVDATA;
        }
    }
    /* REF5941 - YST - 020508
       if not rec./paid floating instrument id then set rec./paid floating instrument id to NULL in both legs */
    if (ret == RET_SUCCEED)
    {
        if (recFloatInstrId <= 0)
        {
            SET_NULL_ID(recInstrLegPtr, A_Instr_FloatInstrId);
            SET_NULL_ID(paidInstrLegPtr, A_Instr_FloatInstrId);
        }
        else if (paidFloatInstrId <= 0)
        {
            SET_NULL_ID(recInstrLegPtr, A_Instr_PaidFloatInstrId);
            SET_NULL_ID(paidInstrLegPtr, A_Instr_PaidFloatInstrId);
        }
    }
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ComputeVolatility()
**
**  Description :   Compute underlying volatility
**
**  Arguments   :   instrPtr        - current instrument
**                  hierHead        - pointer to hierarchy
**                  volatility      - returned computed volatility
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	REF6940 - RAK - 020109
**  Last modif. :   REF7264 - 020206 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE FIN_ComputeVolatility(DBA_DYNFLD_STP    instrPtr,
                               DATETIME_T        refDateTime,
                               DBA_HIER_HEAD_STP hierHead,
                               NUMBER_T         *volatility)
{
    FLAG_T          allocOk=FALSE;
    DBA_DYNFLD_STP  underPtr=NULLDYNST, instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST, currChrono=NULLDYNST;
    RET_CODE        ret=RET_SUCCEED;

    *volatility = 0.0;

    if (instrPtr == NULLDYNST)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_ComputeVolatility", "instrPtr is mandatory");
	    return(RET_GEN_ERR_INVARG);
    }

    if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId) == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_ComputeVolatility", "underlying instrument is mandatory");
	    return(RET_GEN_ERR_INVARG);
    }

    if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId), FALSE, &allocOk,
                                &underPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        return(ret);

    if  (GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_CashAcct)
    {
        if ((currChrono = ALLOC_DYNST(A_CurrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(underPtr, A_Instr); }
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if (DBA_GetCurrChrono(GET_ID(underPtr, A_Instr_RefCurrId),
			                  GET_ID(instrPtr, A_Instr_RefCurrId), refDateTime,
			                  CurrChronoNat_Volatility, TimeDim_Last, TRUE,
			                  currChrono) == RET_SUCCEED)
	    {
		    *volatility = GET_NUMBER(currChrono, A_CurrChrono_Val);
		}

		FREE_DYNST(currChrono, A_CurrChrono);
    }
    else
    {
        if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(underPtr, A_Instr); }
	    	MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			FREE_DYNST(instrChrono, A_InstrChrono);
			if (allocOk == TRUE) { FREE_DYNST(underPtr, A_Instr); }
	    	MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     GET_ID(underPtr, A_Instr_Id));
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_Volatility);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		ret = FIN_InstrChrono(dimChronoPtr, underPtr, instrChrono, hierHead);  /* REF7264 - PMO */

	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		if (ret == RET_SUCCEED)
		{
			/*
			** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
			** instr_chrono.value_n has been changed from NUMBER to LONGAMOUTN.
			*/

		    *volatility = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
		}

        FREE_DYNST(instrChrono, A_InstrChrono);
    }

    if (allocOk == TRUE) { FREE_DYNST(underPtr, A_Instr); }
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrRecommLevelStorageCompute()
**
**  Description :   Store instrument recommendation level
**
**  Arguments   :   domainArg       - Domain given to financial function
**                  hierHead        - pointer to hierarchy
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	PMSTA-28705 - DDV - 180206
**  Last modif. :
**
*************************************************************************/
RET_CODE FIN_InstrRecommLevelStorageCompute(DBA_DYNFLD_STP     domainArg,
                                            DBA_HIER_HEAD_STP  hierHead)
{
    RET_CODE	            ret = RET_SUCCEED, finalRet = RET_SUCCEED;
    int                     ruleDefIdx=0;
    SetServerUserToOnGuard  setServerUserToOn;          /* This class set ServerUser to On and automatically set to Off when leaving the function */


    IRL_RULEDEF_ST      ruleDefTab[] = { {IrlInstrumentRule, IrlInstrumentRuleCompo, IrlInstrument, A_IrlInstrumentRuleCompo_IrlInstrumentRuleId, A_IrlInstrumentRuleCompo_DestFullTableName, NO_VALUE, FIN_CmpIrlInstrumentRuleRank, FIN_CmpIrlInstrumentRuleCompoLevel},
                                        {IrlPortfolioRule,  IrlPortfolioRuleCompo,  IrlPortfolio,  A_IrlPortfolioRuleCompo_IrlPtfRuleId,         A_IrlPortfolioRuleCompo_DestFullTableName,  NO_VALUE, FIN_CmpIrlPortfolioRuleRank,  FIN_CmpIrlPortfolioRuleCompoLevel},
                                        {IrlApplUserRule,   IrlApplUserRuleCompo,   IrlApplUser,   A_IrlApplUserRuleCompo_IrlApplUserRuleId,     A_IrlApplUserRuleCompo_DestFullTableName,   NO_VALUE, FIN_CmpIrlApplUserRuleRank,   FIN_CmpIrlApplUserRuleCompoLevel},
                                        {NullEntity,        NullEntity,             NullEntity,    NO_VALUE,                                     NO_VALUE,                                   NO_VALUE, NULLFCT,                      NULLFCT} };

    if (domainArg == NULLDYNST)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		                "FIN_InstrRecommLevelStorageCompute", "domain is mandatory");
	    return(RET_GEN_ERR_INVARG);
    }


    if (GET_ENUM(domainArg, A_Domain_CompDataEn) == CompData_CompNew ||
        GET_ENUM(domainArg, A_Domain_CompDataEn) == CompData_ReplOld)
    {
        for (ruleDefIdx=0; ruleDefTab[ruleDefIdx].ruleObjEn > InvalidEntity; ruleDefIdx++)
        {
            if ((ret = FIN_StoreIRLByRuleDef(&ruleDefTab[ruleDefIdx], domainArg, hierHead)) != RET_SUCCEED)
            {
                finalRet = ret;
            }
        }
    }

    if (GET_ENUM(domainArg, A_Domain_CompDataEn) == CompData_ReplOld ||
        GET_ENUM(domainArg, A_Domain_CompDataEn) == CompData_ReplaceExisting)
    {
        for (ruleDefIdx=0; ruleDefTab[ruleDefIdx].ruleObjEn > InvalidEntity; ruleDefIdx++)
        {
            if ((ret = FIN_TranferDataIntoFinalTable(&ruleDefTab[ruleDefIdx], domainArg, hierHead)) != RET_SUCCEED)
            {
                finalRet = ret;
            }
        }
    }

    return(finalRet);
}

/************************************************************************
**
**  Function    :   FIN_StoreIRLByRuleDef
**
**  Description :   Store all recommendation level for all rule of the same type (instrument rule or portfolio rule or appl_user rule)
**
**  Arguments   :   ruleDefPtr      - Rule definition (entity, destination entity, field position, . . .)
**                  domainPtr       - Domain given to financial function
**                  hierHead        - pointer to hierarchy
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	PMSTA-28705 - DDV - 180206
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_StoreIRLByRuleDef(IRL_RULEDEF_STP    ruleDefPtr,
                                      DBA_DYNFLD_STP     domainPtr,
                                      DBA_HIER_HEAD_STP  hierHead)
{
    RET_CODE	               ret = RET_SUCCEED, finalRet = RET_SUCCEED;
    std::string                destFullTableName;
    DBA_DYNFLD_STP            *ruleTab = NULLDYNSTPTR, *ruleCompoTab = NULLDYNSTPTR;
    int                        ruleIdx=0, ruleCompoIdx=0, ruleNbr=0, ruleCompoNbr=0;
    char                      *ruleScptDef=NULL;
    OBJECT_ENUM                ruleObjEn;
    OBJECT_ENUM                ruleCompoObjEn;
    OBJECT_ENUM                destTableObjectEnum;
    DICT_ATTRIB_STP            attribStp=NULL;
    FIELD_IDX_T                ruleStatusFldIdx=NO_VALUE;
    FIELD_IDX_T                ruleIdFldIdx=0;
    FIELD_IDX_T                ruleCompoIdFldIdx=0;
    MemoryPool                  mp;

    ruleObjEn = ruleDefPtr->ruleObjEn;
    ruleCompoObjEn = ruleDefPtr->ruleCompoObjEn;
    destTableObjectEnum = ruleDefPtr->destObjEn;

	DBA_SearchAttribSqlName(ruleObjEn, "status_e", &attribStp);
    if (attribStp != NULL)
    {
        ruleStatusFldIdx = attribStp->progN;
    }

	DBA_SearchAttribSqlName(ruleObjEn, "id", &attribStp);
    if (attribStp != NULL)
        ruleIdFldIdx = attribStp->progN;

	DBA_SearchAttribSqlName(ruleCompoObjEn, "id", &attribStp);
    if (attribStp != NULL)
        ruleCompoIdFldIdx = attribStp->progN;

    if ((ret = FIN_GetDestFullTableName(destTableObjectEnum, destFullTableName, domainPtr, hierHead)) != RET_SUCCEED)
        return(ret);

    /* Extract rules */
	DBA_ExtractHierEltRec(hierHead, GET_EDITGUIST(ruleObjEn), FALSE, NULL, ruleDefPtr->ruleCmpFct, &ruleNbr, &ruleTab);

    mp.ownerPtr(ruleTab);
        
    if(ruleNbr > 0)
	{
        /* Extract instrument rules compo */
	    DBA_ExtractHierEltRec(hierHead, GET_EDITGUIST(ruleCompoObjEn), FALSE, NULL, ruleDefPtr->ruleCompoCmpFct, &ruleCompoNbr, &ruleCompoTab);
         mp.ownerPtr(ruleCompoTab);
        for (ruleCompoIdx=0; ruleCompoIdx < ruleCompoNbr; ruleCompoIdx++)
        {
            SET_SYSNAME(ruleCompoTab[ruleCompoIdx], ruleDefPtr->destFullTableNameFldIdx, destFullTableName.c_str());
        }

        for (ruleIdx=0; ruleIdx < ruleNbr; ruleIdx++)
        {
            /* PMSTA-31688 - DDV - 180614 */
            if (ruleStatusFldIdx != NO_VALUE && (IRL_RULE_STATUS_ENUM) GET_ENUM(ruleTab[ruleIdx], ruleStatusFldIdx) != IrlRuleStatus_Active)
                continue;

            /* load rule definition */
            DBA_GetObjDefValScptDefByAttr(ruleObjEn, "include_filter", GET_ID(ruleTab[ruleIdx], A_IrlPortfolioRule_Id), &ruleScptDef);
            mp.ownerPtr(ruleScptDef);

            for (ruleCompoIdx=0; ruleCompoIdx < ruleCompoNbr; ruleCompoIdx++)
            {
                if (GET_ID(ruleTab[ruleIdx], ruleIdFldIdx) == GET_ID(ruleCompoTab[ruleCompoIdx], ruleDefPtr->ruleCompoRuleIdFldIdx))
                {
                    bool bPtfByPtf = (ruleCompoObjEn == IrlPortfolioRuleCompo && _GET_A_IrlPortfolioRuleCompo_NatEn(ruleCompoTab[ruleCompoIdx]) == IrlPortfolioRuleCompoNatEn::BIObjective);

                    if ((ret = FIN_StoreIRLByRuleCompo(ruleScptDef, ruleCompoTab[ruleCompoIdx], ruleCompoIdFldIdx, bPtfByPtf, destTableObjectEnum, domainPtr)) != RET_SUCCEED)
                    {
                        finalRet = ret;
                    }
                }
            }
        }
	}
    return(finalRet);
}

/************************************************************************
**
**  Function    :   FIN_StoreIRLByRuleCompo
**
**  Description :   Store all recommendation level for a rule compo (instrument rule or portfolio rule or appl_user rule)
**
**  Arguments   :   ruleScptDef         rule's include filter's script definition
**                  ruleCompoStp        rule compo's record
**                  idFldIdx            idx onf the id field in the rule compo structure
**                  destObjEnum         Object enum fo the destination entity
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	PMSTA-28705 - DDV - 180206
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_StoreIRLByRuleCompo(char               *ruleFilterScptDef,
                                        DBA_DYNFLD_STP      ruleCompoStp,
                                        FIELD_IDX_T         idFldIdx,
                                        bool                bPtfByPtf,
                                        OBJECT_ENUM         destObjectEnum,
                                        DBA_DYNFLD_STP      domainPtr)
{
    RET_CODE	     ret = RET_SUCCEED;
    char            *ruleCompoScptDef=NULL;
    MemoryPool       mp;

    /* load portfolio rule compo definition */
    DBA_GetObjDefValScptDefByAttr(GET_OBJ_DYNST(GET_DYNSTENUM(ruleCompoStp)), "script_definition", GET_ID(ruleCompoStp, idFldIdx), &ruleCompoScptDef);
    if (ruleCompoScptDef == NULL)
        return(RET_SUCCEED);

    mp.ownerPtr(ruleCompoScptDef);

    if (ruleCompoScptDef[0] == END_OF_STRING)
    {
        return(RET_SUCCEED);
    }

    if (ruleFilterScptDef != NULL && strlen(ruleFilterScptDef) > 0)
    {
        if ((ruleCompoScptDef = (char *)mp.reallocChar(FILEINFO,ruleCompoScptDef, sizeof(char) * (strlen(ruleCompoScptDef) + strlen(ruleFilterScptDef) + 10))) != NULL)
        {
            strcat(ruleCompoScptDef, " AND ");
            strcat(ruleCompoScptDef, ruleFilterScptDef);
        }
    }

    DbiConnectionHelper dbiConnHelper;

    dbiConnHelper.isValidAndInit();

    /* fill vector_id temp table */
    ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), TCT_VECTOR_ID); /*REF9125 MCA 030903*/ /* PMSTA06916 - LJE - 081113 */

    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
    {
        if ((ret = DBA_LoadVectorIdByDomain(domainPtr, dbiConnHelper)) != RET_SUCCEED)
        {
	        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadVectorIdByDomain() failed");
	        return(ret);
        }
    }

    /* PMSTA-50418 - DDV - 221013 - Force portfolio by portfolio based on rule compo nature */
    if (bPtfByPtf)
    {
        if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE)
        {
            /* PMSTA-50418 - DDV - 221024 - Fill vecor_id will all profolio having bi_objective */
            if ((ret = dbiConnHelper.dbaNotif(Ptf, DBA_ROLE_USE_VECTOR_ID, NULLDYNST)) != RET_SUCCEED)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "FIN_StoreIRLByRuleCompo: Loading portfolios having bi_objective in vector_id failed");
                return(ret);
            }
        }

        DBA_DYNFLD_STP  *ptfTab = nullptr;
        int             ptfNbr = 0;

        if (dbiConnHelper.dbaSelect(Ptf, DBA_ROLE_LOAD_STRAT_LNK, NULLDYNST, A_Ptf, &ptfTab, &ptfNbr) != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Portfolio loading in function FIN_StoreIRLByRuleCompo failed");
            DBA_FreeDynStTab(ptfTab, ptfNbr,A_Ptf);
            return(ret);
        }

        mp.ownerDynStpTab(ptfTab,ptfNbr);

        for (int i = 0; i < ptfNbr; i++)
        {
            std::stringstream  tmpScptDef;

            tmpScptDef << ruleCompoScptDef << " AND portfolio_id = " << GET_ID(ptfTab[i], A_Ptf_Id);

            /* store data for resulting script definition for current portfolio*/
            ret = SCPT_EvalCstList(CSTLIST_STORE_IRL_DATA_BI_OBJECTIVE,
                                    NULL,
                                    tmpScptDef.str().c_str(),
                                    destObjectEnum,
                                    0,
                                    NULL,
                                    dbiConnHelper.getId(),
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    0,
                                    0,
                                    ruleCompoStp, 
                                    nullptr,
                                    nullptr,
                                    nullptr,
                                    ptfTab[i]);

        }
    }
    else
    {
        /* store data for resulting script definition */
	    ret = SCPT_EvalCstList(CSTLIST_STORE_IRL_DATA,
			                   NULL,
			                   ruleCompoScptDef,
			                   destObjectEnum,
			                   0,
			                   NULL,
			                   dbiConnHelper.getId(),
			                   NULL,
			                   NULL,
			                   NULL,
			                   NULL,
			                   0,
			                   0,
                               ruleCompoStp);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TranferDataIntoFinalTable
**
**  Description :   Transfer all intermediate data into final table
**
**  Arguments   :   ruleDefPtr      - Rule definition (entity, destination entity, field position, . . .)
**                  domainArg       - Domain given to financial function
**                  hierHead        - pointer to hierarchy
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	PMSTA-28705 - DDV - 180206
**  Last modif. :   PMSTA-42568 - DDV - 210212 - Adapt query for multi-entity
**
*************************************************************************/
STATIC RET_CODE FIN_TranferDataIntoFinalTable(IRL_RULEDEF_STP    ruleDefPtr,
                                              DBA_DYNFLD_STP     domainPtr,
                                              DBA_HIER_HEAD_STP  hierHead)
{
    RET_CODE	                ret = RET_SUCCEED;
    std::string                 dataFullTableName;
    std::string                 finalFullTableName;
    OBJECT_ENUM                 dataTableObjectEnum, dimObject = InvalidEntity;
    DbiConnectionHelper         dbiConnHelper;

    dataTableObjectEnum = ruleDefPtr->destObjEn;

    if ((ret = FIN_GetDestFullTableName(dataTableObjectEnum, dataFullTableName, domainPtr, hierHead)) != RET_SUCCEED)
        return(ret);

    if ((ret = FIN_GetDestFullTableName(InstrumentRecommLevel, finalFullTableName, domainPtr, hierHead)) != RET_SUCCEED)
        return(ret);

    dbiConnHelper.isValidAndInit();

    /* fill vector_id temp table */
    ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), TCT_VECTOR_ID); /*REF9125 MCA 030903*/ /* PMSTA06916 - LJE - 081113 */

    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
    {
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject);

        if ((ret = DBA_LoadVectorIdByDomain(domainPtr, dbiConnHelper)) != RET_SUCCEED)
        {
	        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadVectorIdByDomain() failed");
	        return(ret);
        }
    }

    /* PMSTA-42568 - DDV - 210212 - Adapt query for multi-entity */
    DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(InstrumentRecommLevel);
    bool            isOwnerBEMandatory = dictEntityPtr->multiEntityCateg.isOwnerBusinessEntity();
    string          insSqlQueryStr, delSqlQueryStr, bEIdStr = "", instrCstStr, ptfCstStr, applUserCstStr;

    instrCstStr = SYS_Stringer(InstrCst);
    ptfCstStr = SYS_Stringer(PtfCst);
    applUserCstStr = SYS_Stringer(ApplUserCst);

    if (isOwnerBEMandatory)
    {
        bEIdStr = SYS_Stringer(SYS_GetThreadCurrBusinessEntityId());
    }

    switch (GET_OBJECT_CST(dataTableObjectEnum))
    {
        case IrlInstrumentCst:
            delSqlQueryStr = "delete from " + finalFullTableName + " where portfolio_id is null and appl_user_id is null ";

            if (isOwnerBEMandatory)
            {
                delSqlQueryStr += " and owner_business_entity_id = " + bEIdStr;
            }

            if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
            {
                if (dimObject == Instr)
                {
                    delSqlQueryStr += " and instr_id in (select vi.id from #vector_id vi where vi.entity_dict_id=" + instrCstStr  +") ";
                }
                else
                {
                    /* nothing to do */
                    return(RET_SUCCEED);
                }
            }

            insSqlQueryStr = "insert into " + finalFullTableName + " (instr_id, portfolio_id, appl_user_id, recomm_level_n";

            if (isOwnerBEMandatory)
                insSqlQueryStr += ", owner_business_entity_id";


            insSqlQueryStr += ") select instr_id, null, null, min(recomm_level_n)";


            if (isOwnerBEMandatory)
            { 
                insSqlQueryStr += ", " + bEIdStr;
            }

            insSqlQueryStr += " from " + dataFullTableName  + " group by instr_id";
            break;

        case IrlPortfolioCst:
            delSqlQueryStr = "delete from " + finalFullTableName + " where portfolio_id is not null and appl_user_id is null";

            if (isOwnerBEMandatory)
                delSqlQueryStr += " and owner_business_entity_id = " + bEIdStr;

            if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
            {
                if (dimObject == Instr)
                    delSqlQueryStr += " and instr_id in (select vi.id from #vector_id vi where vi.entity_dict_id=" + instrCstStr + ") ";
                else if (dimObject == Ptf)
                    delSqlQueryStr += " and portfolio_id in (select vi.id from #vector_id vi where vi.entity_dict_id=" + ptfCstStr + ") ";
                else
                {
                    /* nothing to do */
                    return(RET_SUCCEED);
                }
            }

            insSqlQueryStr = "insert into " + finalFullTableName + " (instr_id, portfolio_id, appl_user_id, recomm_level_n ";

            if (isOwnerBEMandatory)
                insSqlQueryStr += ", owner_business_entity_id";


            insSqlQueryStr += ") select instr_id, portfolio_id, null, min(recomm_level_n)";


            if (isOwnerBEMandatory)
                insSqlQueryStr += ", " + bEIdStr;

            insSqlQueryStr += " from " + dataFullTableName + " group by instr_id, portfolio_id";
            break;

        case IrlApplUserCst:
            delSqlQueryStr = "delete from " + finalFullTableName + " where portfolio_id is null and appl_user_id is not null";

            if (isOwnerBEMandatory)
                delSqlQueryStr += " and owner_business_entity_id = " + bEIdStr;

            if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
            {
                if (dimObject == Instr)
                    delSqlQueryStr += " and instr_id in (select vi.id from #vector_id vi where vi.entity_dict_id=" + instrCstStr + ") ";
                else if (dimObject == ApplUser)
                    delSqlQueryStr += " and appl_user_id in (select vi.id from #vector_id vi where vi.entity_dict_id=" + applUserCstStr + ") ";
                else
                {
                    /* nothing to do */
                    return(RET_SUCCEED);
                }
            }

            insSqlQueryStr += "insert into " + finalFullTableName + " (instr_id, portfolio_id, appl_user_id, recomm_level_n";

            if (isOwnerBEMandatory)
                insSqlQueryStr += ", owner_business_entity_id";


            insSqlQueryStr += ") select instr_id, null, appl_user_id, min(recomm_level_n)";


            if (isOwnerBEMandatory)
                insSqlQueryStr +=  ", " + bEIdStr;

            insSqlQueryStr += " from " + dataFullTableName + " group by instr_id, appl_user_id";
            break;
    }

    if (delSqlQueryStr[0] != END_OF_STRING)
		ret = dbiConnHelper.dbaSqlExec(delSqlQueryStr);

    if (ret == RET_SUCCEED && insSqlQueryStr[0] != END_OF_STRING)
		ret = dbiConnHelper.dbaSqlExec(insSqlQueryStr);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetDestFullTableName()
**
**  Description :   Get the name of the table into which the result must be store
**
**  Arguments   :   irlRuleOjectEnum - Entity of the rule to treat
**                  domainArg        - Domain given to financial function
**
**  Return      :   RET_SUCCEED or error code
**
**  Create		:	PMSTA-28705 - DDV - 180206
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_GetDestFullTableName(OBJECT_ENUM                  destObjectEnum,
                                         std::string                 &destTableName,
                                         DBA_DYNFLD_STP               domainArg,
                                         DBA_HIER_HEAD_STP            hierHead)
{
    if (destObjectEnum <= InvalidEntity)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		                "FIN_GetDestFullTableName", "destObjectEnum is mandatory");
	    return(RET_GEN_ERR_INVARG);
    }

    DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(destObjectEnum);

    if (dictEntityPtr != nullptr && dictEntityPtr->dbSqlName[0] != END_OF_STRING)
    {
        if (dictEntityPtr->dbRuleEn == DbRule_Template)
        {
            DBA_DYNFLD_STP    *tableTab = NULLDYNSTPTR;
            int                tableNbr = 0, i = 0;
            char              *fmtCd = NULL;

    	    DBA_ExtractHierEltRec(hierHead, A_TascJobTable, FALSE, NULL, NULL, &tableNbr, &tableTab);

    	    if (tableNbr == 0 && IS_NULLFLD(domainArg, A_Domain_JobReference) == FALSE)
            {
                DBA_DYNFLD_STP     sTascJobTableSt = NULLDYNST;


    		    if((sTascJobTableSt = ALLOC_DYNST(S_TascJobTable)) == NULL)
	    	    {
		    	    return(RET_MEM_ERR_ALLOC);
		        }

		        SET_ID(sTascJobTableSt, S_TascJobTable_JobId, (ID_T)atof(GET_NAME(domainArg, A_Domain_JobReference)));

		        if (DBA_Select2(TascJobTable, UNUSED, S_TascJobTable, sTascJobTableSt, A_TascJobTable, &tableTab,
						        UNUSED, UNUSED, &tableNbr, UNUSED, UNUSED) != RET_SUCCEED )
		        {
			        FREE_DYNST(sTascJobTableSt, S_TascJobTable);
			        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "TascJobTable select failed");
			        return(RET_GEN_ERR_INVARG);
		        }

    		    FREE_DYNST(sTascJobTableSt, S_TascJobTable);

                DBA_AddHierRecordList(hierHead, tableTab, tableNbr, A_TascJobTable, TRUE);
            }

            for (i=0; i < tableNbr; i++)
            {
                fmtCd = GET_CODE(tableTab[i], A_TascJobTable_FmtCd);

                if (fmtCd != NULL && fmtCd[0] != END_OF_STRING && strcmp(dictEntityPtr->dbSqlName, fmtCd) == 0)
                {
                    if (IS_NULLFLD(tableTab[i], A_TascJobTable_FullTableName) == FALSE)
                    {
                        destTableName = GET_LONGSYSNAME(tableTab[i], A_TascJobTable_FullTableName);
                    }
                    FREE(tableTab);
                    return(RET_SUCCEED);
                }
            }
            FREE(tableTab);
        }
        else
        {
            destTableName = DdlGenDbi::getTableFullDbName(dictEntityPtr->databaseName, "", dictEntityPtr->dbSqlName, EV_RdbmsVendor);
            return(RET_SUCCEED);
        }
    }

    return(RET_DBA_INFO_NODATA);
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlInstrumentRuleRank()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlInstrumentRule
**                  ptr2   pointer on dynamic structure type A_IrlInstrumentRule
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlInstrumentRuleRank(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlInstrumentRule_Rank, A_IrlInstrumentRule_Rank, IntType));
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlInstrRuleCompoLevel()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlInstrumentRuleCompo
**                  ptr2   pointer on dynamic structure type A_IrlInstrumentRuleCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlInstrumentRuleCompoLevel(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_IrlInstrumentRuleCompo_IrlInstrumentRuleId, A_IrlInstrumentRuleCompo_IrlInstrumentRuleId, IdType)) != 0)
        return(cmp);
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlInstrumentRuleCompo_RecommLevel, A_IrlInstrumentRuleCompo_RecommLevel, IntType));
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlPortfolioRuleRank()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlPortfolioRule
**                  ptr2   pointer on dynamic structure type A_IrlPortfolioRule
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlPortfolioRuleRank(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlPortfolioRule_Rank, A_IrlPortfolioRule_Rank, IntType));
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlPortfolioRuleCompoLevel()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlPortfolioRuleCompo
**                  ptr2   pointer on dynamic structure type A_IrlPortfolioRuleCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlPortfolioRuleCompoLevel(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_IrlPortfolioRuleCompo_IrlPtfRuleId, A_IrlPortfolioRuleCompo_IrlPtfRuleId, IdType)) != 0)
        return(cmp);
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlPortfolioRuleCompo_RecommLevel, A_IrlPortfolioRuleCompo_RecommLevel, IntType));
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlApplUserRuleRank()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlApplUserRule
**                  ptr2   pointer on dynamic structure type A_IrlApplUserRule
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlApplUserRuleRank(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlApplUserRule_Rank, A_IrlApplUserRule_Rank, IntType));
}

/************************************************************************
**
**  Function    :   FIN_CmpIrlApplUserRuleCompoLevel()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_IrlApplUserRuleCompo
**                  ptr2   pointer on dynamic structure type A_IrlApplUserRuleCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-28705 - DDV - 180209
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpIrlApplUserRuleCompoLevel(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_IrlApplUserRuleCompo_IrlApplUserRuleId, A_IrlApplUserRuleCompo_IrlApplUserRuleId, IdType)) != 0)
        return(cmp);
    return(CMP_DYNFLD((*ptr1), (*ptr2), A_IrlApplUserRuleCompo_RecommLevel, A_IrlApplUserRuleCompo_RecommLevel, IntType));
}

/************************************************************************
**  Function             : DBA_LoadVectorId()
**
**  Description          : Init #vector_id table for given parameter
**                         (dim_entity, entity, object_id, scptdef)
**
**  Arguments            : dimEntityObjEn   Dimension to treat (One, All, List, QSearch)
**                         entityObjEn      Domain pointer
**                         objectId         Id of the current object when dimension is One or List
**                         scptDef          Script definition use when Dimension is QSearch.
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA-28705 - DDV - 180216
**
**  Modif.		         :
**
**
*************************************************************************/
extern RET_CODE DBA_LoadVectorId(OBJECT_ENUM       dimEntityObjEn,
                                 OBJECT_ENUM       entityObjEn,
                                 ID_T              objectId,
                                 char              *scptDefStr,
                                 DbiConnectionHelper& dbiConnHelper)
{
	RET_CODE             ret=RET_SUCCEED;
    char                *sqlQueryStr;
    DICT_ENTITY_STP      dictEntityPtr = DBA_GetDictEntitySt(entityObjEn);

    switch(GET_OBJECT_CST(dimEntityObjEn))
    {
        case OneCst:
            if (dictEntityPtr == NULL)
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_LoadVectorId", "entityObjEn");
                return RET_GEN_ERR_INVARG;
            }

            if ((sqlQueryStr = (char *) CALLOC(1024, sizeof(char))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }

            sprintf(sqlQueryStr, "INSERT into #vector_id (entity_dict_id, id) values (%" szFormatId", %" szFormatId") ", dictEntityPtr->entDictId, objectId);

            ret = dbiConnHelper.dbaSqlExec(sqlQueryStr);
            FREE(sqlQueryStr);
            break;

        case ListCst:
            break;

        case QuickSearchCst:
            /* insert into vector_id all records corresponding to script definition */
            if (scptDefStr != NULL && scptDefStr[0] != END_OF_STRING)
            {
			    ret = SCPT_EvalCstList(CSTLIST_BUILD_VI_FCTRESULT,
                                       0,
                                       scptDefStr,
                                       entityObjEn,
                                       0,
                                       NULLDYNST,
                                       dbiConnHelper.getId(),
                                       (FLAG_T*) NULL,
                                       (DBA_DYNFLD_STP**) NULL,
                                       (int *)NULL,
                                       (DATETIME_STP)NULL,
                                       0,
                                       0);
            }
            break;
        case NullEntityCst:
            break;
        default:
            break;
    }

	return(ret);
}


/************************************************************************
**  Function             : DBA_LoadVectorIdByDomain()
**
**  Description          : Init #vector_id table for given domain
**
**  Arguments            : domainPtr        Domain pointer
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA-28705 - DDV - 180524
**
**  Modif.		         :
**
**
*************************************************************************/
extern RET_CODE DBA_LoadVectorIdByDomain(DBA_DYNFLD_STP       domainPtr,
                                         DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE         ret=RET_SUCCEED;
	OBJECT_ENUM	     dimObject, dimEntityObject;

    if (domainPtr == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_LoadVectorIdByDomain", "Domain");
        return RET_GEN_ERR_INVARG;
    }

    if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
    {
        ID_T                tascJobId=0;

		sscanf(GET_NAME(domainPtr, A_Domain_JobReference), szFormatIdSScanf, &tascJobId);

        DBA_DYNFLD_STP argument =  ALLOC_DYNST(Arg_Test);

        if (argument != NULL)
        {
            SET_ID(argument, Arg_Test_Id, tascJobId);
            if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

			SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

            if ((ret = dbiConnHelper.dbaNotif(TascJob, DBA_ROLE_USE_VECTOR_ID, argument)) != RET_SUCCEED)
			{
            	FREE_DYNST(argument, Arg_Test);
				return(ret);
			}

        	FREE_DYNST(argument, Arg_Test);
        }

    }
    else
    {
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject);
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimEntityDictId), &dimEntityObject);

        if ((ret = DBA_LoadVectorId(dimEntityObject,
                                    dimObject,
                                    GET_ID(domainPtr, A_Domain_PtfObjId),
                                    GET_STRING(domainPtr, A_Domain_PtfListDef),
                                    dbiConnHelper)) != RET_SUCCEED)
        {
	        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadVectorId() failed");
	        return(ret);
        }
    }
    return(RET_SUCCEED);
}


/************************************************************************
**  Function             : InstrumentSTNComputationCPNAverageBasket::compute()
**
**  Description          : Formulas for Capital Protection Notes: Average Basket computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**
*************************************************************************/
RET_CODE InstrumentSTNComputationCPNAverageBasket::compute()
{
    RET_CODE        ret               = RET_SUCCEED;
    const PERCENT_T capitalProtection = GET_NUMBER(m_input.getInstr(), A_Instr_CapProtection);

    if (FALSE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
    { // Initial test scenario 1
        const NUMBER_T rebate = GET_NUMBER(m_input.getInstr(), A_Instr_RebatePayoff);

        m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (capitalProtection + rebate));             /* PMSTA-34847 - 060319 - PMO */
    }
    else
    {
        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate))
        { // Initial test scenario 2
            const NUMBER_T participationLevel = GET_NUMBER(m_input.getInstr(), A_Instr_ParticipationLev);
            const PRICE_T  exerciseQuote = GET_PRICE(m_input.getInstr(), A_Instr_ExerQuote);
            const NUMBER_T leverage = instrNumberValueOr(A_Instr_Leverage, 1.0);

            ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

            if (RET_SUCCEED == ret)
            {
                const PRICE_T basketPrice = m_result.getPrice();

                if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_CapLevel))
                {
                    m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * std::max(capitalProtection, 1.0 + (participationLevel * deltaPercent(basketPrice, exerciseQuote))));                                                   /* PMSTA-34847 - 060319 - PMO */
                }
                else
                {
                    const PERCENT_T capitalProtectionLevel = GET_NUMBER(m_input.getInstr(), A_Instr_CapLevel);

                    m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (capitalProtection + std::min(capitalProtectionLevel, std::max(0.0, participationLevel / leverage * deltaPercent(basketPrice, exerciseQuote)))));     /* PMSTA-34847 - 060319 - PMO */
                }
            }
        }
        else
        { // Initial test scenario 3
            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * capitalProtection);                    /* PMSTA-34847 - 060319 - PMO */
        }
    }

    m_result.setQuote(100.0);

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationCPNSingleInstrument::compute()
**
**  Description          :  Formulas for Capital Protection Notes: Single instrument computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**
*************************************************************************/
RET_CODE InstrumentSTNComputationCPNSingleInstrument::compute()
{
    RET_CODE        ret               = RET_SUCCEED;
    const PERCENT_T capitalProtection = GET_NUMBER(m_input.getInstr(), A_Instr_CapProtection);

    if (FALSE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
    { // Initial test scenario 1
        const NUMBER_T rebate = GET_NUMBER(m_input.getInstr(), A_Instr_RebatePayoff);

        m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (capitalProtection + rebate));     /* PMSTA-34847 - 060319 - PMO */
    }
    else
    {
        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate))
        { // Initial test scenario 2
            ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

            if (RET_SUCCEED == ret)
            {
                const NUMBER_T participationLevel = GET_NUMBER(m_input.getInstr(), A_Instr_ParticipationLev);
                const PRICE_T  basketPrice = m_result.getPrice();

                m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * std::max(capitalProtection, 1.0 + instrNumberMinIfValue(A_Instr_CapLevel, participationLevel * basketPrice)));     /* PMSTA-34847 - 060319 - PMO */
            }
        }
        else
        { // Initial test scenario 3
            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * capitalProtection);            /* PMSTA-34847 - 060319 - PMO */
        }
    }

    m_result.setQuote(100.0);

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationCPNWorstOfBasket::compute()
**
**  Description          : Formulas for Capital Protection Notes: Worst Of Basket computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**                         PMSTA-35020 - 080319 - PMO : Dev Full Coverage - Journal - CPN's
**
*************************************************************************/
RET_CODE InstrumentSTNComputationCPNWorstOfBasket::compute()
{
    RET_CODE        ret               = RET_SUCCEED;
    const PERCENT_T capitalProtection = GET_NUMBER(m_input.getInstr(), A_Instr_CapProtection);

    if (FALSE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))                                      /* PMSTA-35020 - 080319 - PMO */
    { // Initial test scenario 1
        const NUMBER_T rebate = GET_NUMBER(m_input.getInstr(), A_Instr_RebatePayoff);

        m_result.setQty( -(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (capitalProtection + rebate)));     /* PMSTA-35020 - 080319 - PMO */
    }
    else
    {
        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate))
        {  // Initial test scenario 2
            const NUMBER_T participationLevel = GET_NUMBER(m_input.getInstr(), A_Instr_ParticipationLev);

            ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

            if (RET_SUCCEED == ret)
            {
                const PRICE_T price = deltaPercent(m_result.getPrice(), m_result.getExercisePrice());

                m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * std::max(capitalProtection, 1.0 + instrNumberMinIfValue(A_Instr_CapLevel, participationLevel * price)));   /* PMSTA-34847 - 060319 - PMO */
            }
        }
        else
        {  // Initial test scenario 3
            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * capitalProtection);               /* PMSTA-34847 - 060319 - PMO */
        }
    }

    m_result.setQuote(100.0);

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationRCNMCSingleAverageWorstOf::compute()
**
**  Description          : Formulas for Reverse Convertibles Notes & Memory Coupn: Single, Average Basket, Worst Of computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**                         PMSTA-35019 - 110319 - PMO : Dev Full Coverage - Journal - RCN's and MCN's
**
*************************************************************************/
RET_CODE InstrumentSTNComputationRCNMCSingleAverageWorstOf::compute()
{
    RET_CODE ret = RET_SUCCEED;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockInDate))
    { // Initial test scenario 1
        m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty));      /* PMSTA-34847 - 060319 - PMO */
    }
    else
    { // Initial test scenario 2 & 3
        ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

        if (RET_SUCCEED == ret)
        {
            NUMBER_T delta = ZERO_NUMBER;   /* PMSTA-35019 - 110319 - PMO */

            switch (static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(m_input.getInstr(), A_Instr_UnderlyCatEn)))
            {
                case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                    delta = m_result.getPrice();
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                    delta = deltaPercent(m_result.getPrice(), CAST_NUMBER(GET_PRICE(m_input.getInstr(), A_Instr_ExerQuote)));
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                    delta = deltaPercent(m_result.getPrice(), m_result.getInitialPrice());
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                    break;
            }

            const NUMBER_T participationLevel = instrNumberValueOr(A_Instr_ParticipationLev, 1.0);

            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1.0 + std::min(0.0, participationLevel * delta)));    /* PMSTA-34847 - 060319 - PMO */
        }
    }

    m_result.setQuote(100.0);

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationDCSingle::compute()
**
**  Description          : Formulas for discount certificates: single
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE InstrumentSTNComputationDCSingle::compute()
{
    RET_CODE        ret                     = RET_SUCCEED;
    const PERCENT_T capitalProtectionLevel  = GET_NUMBER(m_input.getInstr(), A_Instr_CapLevel);
    const PRICE_T  initialFixingPrice      = GET_PRICE(m_input.getInstr(), A_Instr_UnderlyFixingPrice);
    const PRICE_T   price                   = capitalProtectionLevel * initialFixingPrice;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockInDate))
    {
        m_result.setQuote(price);
    }
    else
    {
        ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

        if (RET_SUCCEED == ret)
        {
            const PRICE_T quote = m_result.getQuote();

            m_result.setQuote(std::min(quote, price));
        }
    }

    m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty));

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationDCAverageBasket::compute()
**
**  Description          : Formulas for discount certificates: single
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE InstrumentSTNComputationDCAverageBasket::compute()
{
    RET_CODE        ret                    = RET_SUCCEED;
    const PERCENT_T capitalProtectionLevel = GET_NUMBER(m_input.getInstr(), A_Instr_CapLevel);
    const PRICE_T  initialFixingPrice     = GET_PRICE(m_input.getInstr(), A_Instr_UnderlyFixingPrice);
    const PRICE_T  price                  = capitalProtectionLevel * initialFixingPrice;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockInDate))
    {
        m_result.setQuote(price);
    }
    else
    {
        ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

        if (RET_SUCCEED == ret)
        {
            const PRICE_T price2 = m_result.getPrice();

            m_result.setQuote(std::min(price, price2));
        }
    }

    m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty));

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationDCWorstOfBasket::compute()
**
**  Description          : Formulas for discount certificates: single
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE InstrumentSTNComputationDCWorstOfBasket::compute()
{
    const RET_CODE ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

    if (RET_SUCCEED == ret)
    {
        const PERCENT_T capitalProtectionLevel  = GET_NUMBER(m_input.getInstr(), A_Instr_CapLevel);
        const PRICE_T   worstInitialFixingPrice = m_result.getInitialPrice();
        const PRICE_T   price                   = capitalProtectionLevel * worstInitialFixingPrice;

        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockInDate))
        {
            m_result.setQuote(price);
        }
        else
        {
            const PRICE_T price2 = m_result.getPrice();

            m_result.setQuote(std::min(price, price2));
        }
    }

    m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty));

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationBNSingle::compute()
**
**  Description          : Formulas for discount certificates: single
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**                         PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**
*************************************************************************/
RET_CODE InstrumentSTNComputationBNSingle::compute()
{
    RET_CODE ret = RET_SUCCEED;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))                       // PMSTA-34774 - 070319 - PMO
    { // Initial test scenario 1 & 2
        ret = computeNotKnockedOut(false);
    }
    else
    { // Initial test scenario 3
        ret = computeKnockedOut(false);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationBNAverageBasket::compute()
**
**  Description          : Formulas for discount certificates: Average Basket
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         : PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**
*************************************************************************/
RET_CODE InstrumentSTNComputationBNAverageBasket::compute()
{
    RET_CODE ret = RET_SUCCEED;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
    { // Initial test scenario 1 & 2
        ret = computeNotKnockedOut(false);
    }
    else
    { // Initial test scenario 3
        ret = computeKnockedOut(true);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationBNWorstOfBasket::compute()
**
**  Description          : Formulas for discount certificates: Worst Of Basket
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         : PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**
*************************************************************************/
RET_CODE InstrumentSTNComputationBNWorstOfBasket::compute()
{
    RET_CODE ret = RET_SUCCEED;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
    { // Initial test scenario 1 & 2
        ret = computeNotKnockedOut(true);
    }
    else
    { // Initial test scenario 3
        ret = computeKnockedOut(true);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationTWCSingleAverageWorstOf::compute()
**
**  Description          : Formulas for twin win certificates: Single, Average Basket, Worst Of computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**                         PMSTA-35022 - 110319 - PMO : Dev Full Coverage - Journal - TW
**
*************************************************************************/
RET_CODE InstrumentSTNComputationTWCSingleAverageWorstOf::compute()
{
    const RET_CODE ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

    if (RET_SUCCEED == ret)
    {
        NUMBER_T delta = ZERO_NUMBER;                                                                               /* PMSTA-35022 - 110319 - PMO */

        switch (static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(m_input.getInstr(), A_Instr_UnderlyCatEn)))    /* PMSTA-35022 - 110319 - PMO */
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                delta = deltaPercent(m_result.getQuote(), CAST_NUMBER(GET_PRICE(m_input.getInstr(), A_Instr_ExerQuote)));
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                delta = deltaPercent(m_result.getPrice(), CAST_NUMBER(GET_PRICE(m_input.getInstr(), A_Instr_ExerQuote)));
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                delta = deltaPercent(m_result.getPrice(), m_result.getExercisePrice());
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }

        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
        {
            if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate))
            { // Initial test scenario 1
                const NUMBER_T participationLevel = instrNumberValueOr(A_Instr_ParticipationLev, 1.0);

                m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1.0 + instrNumberMinIfValue(A_Instr_CapLevel, participationLevel * delta)));  /* PMSTA-34847 - 060319 - PMO */
            }
            else
            { // Initial test scenario 2
                const NUMBER_T participationLevelDown = instrNumberValueOr(A_Instr_ParticipationLevDown, 1.0);                      /* PMSTA-35022 - 110319 - PMO */

                m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1.0 + std::abs(participationLevelDown* delta)));   /* PMSTA-34847 - 060319 - PMO */
            }
        }
        else
        { // Initial test scenario 3
            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1.0 + delta));                                         /* PMSTA-34847 - 060319 - PMO */
        }

        m_result.setQuote(100.0);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationABSingleAverageWorstOf::compute()
**
**  Description          : Formulas for air bag certificates:  Single, Average Basket, Worst Of computation
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-34847 - 060319 - PMO : All Journal Redemption Quantities must be negative
**                         PMSTA-35023 - 110319 - PMO : Dev Full Coverage - Journal - AB
**
*************************************************************************/
RET_CODE InstrumentSTNComputationABSingleAverageWorstOf::compute()
{
    const RET_CODE ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

    if (RET_SUCCEED == ret)
    {
        const PRICE_T  exerciseQuote       = GET_PRICE(m_input.getInstr(), A_Instr_ExerQuote);

        if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate) && TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_KnockOutDate))
        { // Initial test scenario 1
            const NUMBER_T  participationLevel = instrNumberValueOr(A_Instr_ParticipationLev, 1.0);
            NUMBER_T        delta              = ZERO_NUMBER;

            switch (static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(m_input.getInstr(), A_Instr_UnderlyCatEn)))    /* PMSTA-35022 - 110319 - PMO */
            {
                case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                    delta = deltaPercent(m_result.getQuote(), exerciseQuote);
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                    delta = deltaPercent(m_result.getPrice(), exerciseQuote);
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                    delta = m_result.getPrice();
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                    break;
            }

            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * ( 1.0 + instrNumberMinIfValue(A_Instr_CapLevel, participationLevel * delta)));     /* PMSTA-35023 - 110319 - PMO / PMSTA-34847 - 060319 - PMO */
        }
        else
        { // Initial test scenario 2 & 3
            const NUMBER_T  barrier           = GET_NUMBER(m_input.getInstr(), A_Instr_Barrier);
            NUMBER_T        airBagFactorPart0 = ZERO_NUMBER;
            NUMBER_T        airBagFactorPart1 = ZERO_NUMBER;
            NUMBER_T        delta             = ZERO_NUMBER;

            switch (static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(m_input.getInstr(), A_Instr_UnderlyCatEn)))    /* PMSTA-35023 - 110319 - PMO */
            {
                case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                    airBagFactorPart0 = FIN_DIV(exerciseQuote, barrier);
                    airBagFactorPart1 = FIN_DIV(m_result.getQuote(),      exerciseQuote);
                    delta             = deltaPercent(m_result.getQuote(), exerciseQuote);
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                    airBagFactorPart0 = FIN_DIV(exerciseQuote, barrier);
                    airBagFactorPart1 = FIN_DIV(m_result.getPrice(),      exerciseQuote);
                    delta             = deltaPercent(m_result.getPrice(), exerciseQuote);
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                    airBagFactorPart0 = FIN_DIV(m_result.getExercisePrice(), m_result.getBarrier());
                    airBagFactorPart1 = FIN_DIV(m_result.getPrice(),         m_result.getExercisePrice());
                    delta             = deltaPercent(m_result.getPrice(),    m_result.getExercisePrice());
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                    break;
            }

            const NUMBER_T  airBagFactorPart2 = airBagFactorPart0 - 1.0;
            const NUMBER_T airBagMutliplier  = airBagFactorPart1 * airBagFactorPart2;

            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1.0 + std::min(0.0, airBagMutliplier + delta)));      /* PMSTA-34847 - 060319 - PMO */
        }

        m_result.setQuote(100.0);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputation::InstrumentSTNComputation()
**
**  Description          : Constructor
**
**  Arguments            : hiearHead               Pointer on hierarchy. Might be NULL
**                         stock
**                         instr                   Instrument used has reference
**                         refDateTime             Reference date and time
**
**  Return               : None
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         :
**
*************************************************************************/
InstrumentSTNComputation::InstrumentSTNComputation(DBA_HIER_HEAD_STP    hierHead,
                                                   DBA_DYNFLD_STP       stock,
                                                   DBA_DYNFLD_STP       instr,
                                                   DATETIME_T &         refDateTime) : m_input (hierHead, stock, instr, refDateTime)
{
}

InstrumentSTNComputation::InstrumentSTNComputation(DBA_DYNFLD_STP   stock,
                                                   DBA_DYNFLD_STP   instr,
                                                   DATETIME_T &     fromDateTime) : InstrumentSTNComputation(nullptr, stock, instr, fromDateTime)
{
}


/************************************************************************
**  Function             : InstrumentSTNComputation::~InstrumentSTNComputation()
**
**  Description          : Destructor
**
**  Arguments            : None
**
**  Return               : None
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         :
**
*************************************************************************/
InstrumentSTNComputation::~InstrumentSTNComputation()
{
}




/************************************************************************
**  Function             : InstrumentSTNComputation::computeJournal()
**
**  Description          : Computation for the Journal
**
**  Arguments            : None
**
**  Return               : None
**
**  Creation             : PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.		         : PMSTA-35020 - 080319 - PMO : Dev Full Coverage - Journal - CPN's
**
*************************************************************************/
RET_CODE InstrumentSTNComputation::computeJournal()
{
    RET_CODE                             ret                     = RET_SUCCEED;
    const INSTR_UNDERLYING_CATEGORY_ENUM instrUnderlyingCategory = static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(m_input.getInstr(), A_Instr_UnderlyCatEn));

    if (  InstrumentNature::isCapProtectNotes(m_input.getInstr())
       || InstrumentNature::isCapProtectNotesWCoupon(m_input.getInstr())    /* PMSTA-35020 - 080319 - PMO */
       || InstrumentNature::isEquityLinkedNotes(m_input.getInstr())         /* PMSTA-35020 - 080319 - PMO */
       || InstrumentNature::isBondsLinkedNotes(m_input.getInstr())          /* PMSTA-35020 - 080319 - PMO */
       || InstrumentNature::isBondsCreditLinkedNotes(m_input.getInstr()))   /* PMSTA-35020 - 080319 - PMO */
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                {
                    InstrumentSTNComputationCPNSingleInstrument stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                {
                    InstrumentSTNComputationCPNAverageBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationCPNWorstOfBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }
    else if (  InstrumentNature::isReverseConvertibleELN(m_input.getInstr())
            || InstrumentNature::isReverseConvertibleBLN(m_input.getInstr())        /* PMSTA-35019 - 110319 - PMO */
            || InstrumentNature::isReverseConvertibleCLN(m_input.getInstr())        /* PMSTA-35019 - 110319 - PMO */
            || InstrumentNature::isReverseConvertible(m_input.getInstr())           /* PMSTA-35019 - 110319 - PMO */
            || InstrumentNature::isMemoryCoupons(m_input.getInstr())                /* PMSTA-35019 - 110319 - PMO */
            )
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationRCNMCSingleAverageWorstOf stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }
    else if (InstrumentNature::isDiscountCertificates(m_input.getInstr()))
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                {
                    InstrumentSTNComputationDCSingle stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                {
                    InstrumentSTNComputationDCAverageBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationDCWorstOfBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }
    else if (InstrumentNature::isBonusNotes(m_input.getInstr()))
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                {
                    InstrumentSTNComputationBNSingle stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                {
                    InstrumentSTNComputationBNAverageBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationBNWorstOfBasket stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }
    else if (InstrumentNature::isTwinWinCertificates(m_input.getInstr()))
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationTWCSingleAverageWorstOf stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }
    else if (InstrumentNature::isAirBagCertificates(m_input.getInstr()))
    {
        switch(instrUnderlyingCategory)
        {
            case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
            case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
            case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                {
                    InstrumentSTNComputationABSingleAverageWorstOf stn(m_input, m_result);
                    ret = stn.compute();
                }
                break;

            case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                break;
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   InstrumentSTNComputation::computeInstrumentPriceUnderlyingCategory()
**
**  Description :   Return the minimal value between value1 and the instrument field if the field is not null
**
**  Arguments   :   None
**
**  Return      :   The minimal value between value1 and the instrument field if the field is not null
**
**  Creation    :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif       :
**
*************************************************************************/
RET_CODE InstrumentSTNComputation::computeInstrumentPriceUnderlyingCategory()
{
    return FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);
}

/************************************************************************
**
**  Function    :   FIN_InstrUnderlyingCategory()
**
**  Description :   Return the minimal value between value1 and the instrument field if the field is not null
**
**  Arguments   :   field       Inmstrument field index
**                  value1      Returned valuie if the instrument[field] is null
**
**  Return      :   The minimal value between value1 and the instrument field if the field is not null
**
**  Creation    :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif       :
**
*************************************************************************/
NUMBER_T InstrumentSTNComputationBase::instrNumberMinIfValue(const FIELD_IDX_T & field, NUMBER_T value1) const
{
    NUMBER_T ret = value1;

    if (FALSE == IS_NULLFLD(m_input.getInstr(), field))
    {
        NUMBER_T value2 = GET_NUMBER(m_input.getInstr(), field);

        ret = std::min(value1, value2);
    }

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationBase::computeNotKnockedOut()
**
**  Description          : Computation when the instrument has not knocked out
**                         This correspond to scenario 1 & 2
**                         Resulting computed quote is stored with a call to m_result.setQuote()
**
**  Arguments            : worstFormula
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         : PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**
*************************************************************************/
RET_CODE InstrumentSTNComputationBase::computeNotKnockedOut(const bool worstFormula)
{
    RET_CODE ret = RET_SUCCEED;

    if (TRUE == IS_NULLFLD(m_input.getInstr(), A_Instr_BelowExerDate))
    { // Initial test scenario 1
        ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

        if (RET_SUCCEED == ret)
        { // Ok
            const PERCENT_T capitalProtectionLevel = GET_NUMBER(m_input.getInstr(), A_Instr_CapLevel);
            NUMBER_T        rightPartFormula       = ZERO_AMOUNT;

            if (true == worstFormula)                                                                                                   /* PMSTA-35021 - 260319 - PMO */
            {
                const NUMBER_T bonusLevel = GET_NUMBER(m_input.getInstr(), A_Instr_BonusLevel);
                rightPartFormula = bonusLevel * m_result.getDelta();
            }
            else
            {
                const NUMBER_T  participationLevel = instrNumberValueOr(A_Instr_ParticipationLev, 1.0);
                const PRICE_T   price              = m_result.getPrice();

                rightPartFormula = participationLevel * price;
            }

            m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1. + std::min(capitalProtectionLevel, rightPartFormula)));    /* PMSTA-35021 - 260319 - PMO */
        }
    }
    else
    { // Initial test scenario 2
        const NUMBER_T bonusLevel = GET_NUMBER(m_input.getInstr(), A_Instr_BonusLevel);

        m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1. + bonusLevel));                                                /* PMSTA-35021 - 260319 - PMO */
    }

    m_result.setPrice(  1.);
    m_result.setQuote(100.);

    return ret;
}


/************************************************************************
**  Function             : InstrumentSTNComputationBase::computeKnockedOut()
**
**  Description          : Computation when the instrument has knocked out
**                         This correspond to scenario 3
**                         Resulting computed quote is stored with a call to m_result.setQuote()
**
**  Arguments            : None
**
**  Return               : RET_CODE
**
**  Creation             : PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**
**  Modif.		         : PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**
*************************************************************************/
RET_CODE InstrumentSTNComputationBase::computeKnockedOut(const bool delta)
{
    const RET_CODE ret = FIN_ComputeInstrumentPriceUnderlyingCategory(m_input, m_result);

    if (RET_SUCCEED == ret)
    {
        m_result.setQty(GET_NUMBER(m_input.getStock(), ExtPos_Qty) * (1. + (true == delta ? m_result.getDelta() : m_result.getPrice())));   // PMSTA-35021 - 260319 - PMO
    }

    m_result.setPrice(  1.);
    m_result.setQuote(100.);

    return ret;
}




bool FIN_InstrumentSTNIsWorstFlg(ID_T instrId, InstrumentSTNComputationResult &  result)
{

	for (size_t x=0; x < result.getWorstInstrId().size(); x++)
		if (instrId == result.getWorstInstrId()[x])
			return(true);

	return(false);
}

/*PMSTA-35265 - Silpakala - 190626*/
RET_CODE FIN_WorstInstrumentsFromSTN(DBA_DYNFLD_STP **selInstrCompoTab,
								int *selInstrCompoNbr,
								InstrumentSTNComputationResult &  result,
								int *worstInstrNbr
)
{

	for (int i = 0; i < *selInstrCompoNbr; i++)
	{
		ID_T instrId = GET_ID((*selInstrCompoTab)[i], A_InstrCompo_InstrId);
		for (size_t x = 0; x < result.getWorstInstrId().size(); x++)
			if (instrId == result.getWorstInstrId()[x])
				(*worstInstrNbr)++;
	}
	return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   FIN_InstrUnderlyingCategory()
**
**  Description :   Compute instrument price from underlying instruments
**
**  Arguments   :   input       Input arguments
**                  result      Computation results
**
**  Return      :   None
**
**  Creation    :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif       :   PMSTA-35021 - 260319 - PMO : Dev Full Coverage - Journal - BN
**                  PMSTA-35210 - 270319 - PMO : Final Valuation Date and Quote
**
*************************************************************************/
RET_CODE FIN_ComputeInstrumentPriceUnderlyingCategory(const InstrumentSTNComputationInput  &  input,
                                                            InstrumentSTNComputationResult &  result)
{
    /*
     * Set input structure for select
     */
    DBA_DYNFLD_STP *    selInstrCompoTab = nullptr;
    int                 selInstrCompoNbr = 0;

    /* PMSTA-32502 -RAK - 180925 - Use same function as risk treatment and all Structured notes treatment */
    RET_CODE ret = FIN_SelectUnderlyingCompo(input.getHierHead(), input.getRefDateTime(), input.getInstr(), &selInstrCompoTab, &selInstrCompoNbr); /* PMSTA-32502 - RAK - 180924 */

    if (RET_SUCCEED == ret && selInstrCompoNbr > 0)
    {
        MemoryPool mp;

        mp.owner(selInstrCompoTab, selInstrCompoNbr);

        DBA_DYNFLD_STP compoPricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

        /* PMSTA-35210 - 270319 - PMO
         * Defining the price reference date
         */
        DATETIME_T priceReferenceDate = input.getRefDateTime();

        if (!IS_NULLFLD(input.getInstr(), A_Instr_FixDate))
        {
            ID_T calendarId = ZERO_ID;

            if (RET_SUCCEED == DBA_GetCalendarFromInstr(input.getInstr(), &calendarId))
            {
                long nbOfDays = 0l;

                DATE_DaysBetween( GET_DATE(input.getInstr(), A_Instr_FixDate)
                                , GET_DATE(input.getInstr(), A_Instr_BeginDate)
                                , static_cast<ACCRRULE_ENUM> (GET_ENUM(input.getInstr(), A_Instr_AccrualRuleEn))
                                , &nbOfDays
                                , calendarId
                                );

                if (0l != nbOfDays)
                {
                    DATE_T fixingEndDate = DATE_Move(GET_DATE(input.getInstr(), A_Instr_EndDate), static_cast<int>(-nbOfDays), Day, FALSE);

                    ret = SCE_CldrNextBusinessDateInstrConv(input.getInstr(), calendarId, fixingEndDate, &fixingEndDate);

                    if (  RET_SUCCEED == ret
                       && (  DATE_Between(fixingEndDate, input.getRefDateTime().date, GET_DATE(input.getInstr(), A_Instr_EndDate))
                          || (  DATE_Cmp(fixingEndDate,                               input.getRefDateTime().date) < 0
                             && DATE_Cmp(GET_DATE(input.getInstr(), A_Instr_EndDate), input.getRefDateTime().date) < 0
                             )
                          )
                       )
                    {
                        priceReferenceDate.date = fixingEndDate;
                    }
                }
            }
        }

        /*
         * Grab data for the computation of the field
         */
        std::vector<NUMBER_T>   barriers;
        std::vector<PRICE_T>    prices;
        std::vector<PRICE_T>    exercisePrices;
        std::vector<PRICE_T>    initialPrices;
        std::vector<PRICE_T>    weightedPrices;
        std::vector<ID_T>       weightedPricesInstrId;
        std::vector<NUMBER_T>   multipliers;

        for (int idx = 0 ; idx < selInstrCompoNbr && RET_SUCCEED == ret; idx++)
        {
            DBA_DYNFLD_STP      curentInstrCompo                    = selInstrCompoTab[idx];
            const PERCENT_T     currentInstrCompoWeight             = GET_PERCENT(curentInstrCompo, A_InstrCompo_BasketWeightP) * 0.01;
            const PRICE_T       currentInstrCompoBasketFixingPrice  = GET_PRICE (curentInstrCompo, A_InstrCompo_BasketFixingPrice);
            const PRICE_T       currentInstrInitialFixingPrice      = GET_PRICE (input.getInstr(), A_Instr_UnderlyFixingPrice);
            FLAG_T              allocInstrOk                        = FALSE;
            DBA_DYNFLD_STP      curentInstr                         = nullptr;

            ret = DBA_GetInstrById(GET_ID(curentInstrCompo, A_InstrCompo_InstrId), FALSE, &allocInstrOk, &curentInstr, input.getHierHead(), UNUSED, nullptr);

            if (RET_SUCCEED == ret)
            {
                ret = FIN_DefaultInstrPrice(curentInstr, priceReferenceDate, FALSE, nullptr, nullptr, nullptr, input.getHierHead(), compoPricePtr, FALSE);

                if (RET_SUCCEED == ret)
                {
                    prices.push_back(GET_PRICE(compoPricePtr, A_InstrPrice_Price));
                    weightedPrices.push_back(currentInstrCompoWeight * FIN_DIV(GET_PRICE(compoPricePtr, A_InstrPrice_Price), currentInstrCompoBasketFixingPrice));
                    weightedPricesInstrId.push_back(GET_ID(compoPricePtr, A_Instr_Id));
                    exercisePrices.push_back(GET_PRICE(curentInstrCompo, A_InstrCompo_BasketExerPrice));
                    initialPrices.push_back( GET_PRICE(curentInstrCompo, A_InstrCompo_BasketFixingPrice));
                    barriers.push_back(      GET_NUMBER(curentInstrCompo, A_InstrCompo_BasketBarrier));
                    multipliers.push_back(FIN_DIV(currentInstrInitialFixingPrice * currentInstrCompoWeight, currentInstrCompoBasketFixingPrice));
                }
                else
                {
                    weightedPrices.push_back(currentInstrCompoWeight * currentInstrCompoBasketFixingPrice);
                    weightedPricesInstrId.push_back(GET_ID(curentInstrCompo, A_Instr_Id));
                }

                if (TRUE == allocInstrOk)
                {
                    FREE_DYNST(curentInstr, A_Instr);
                }
            }
        }


        /*
         * Computation of the fields
         */
        if (RET_SUCCEED == ret)
        {
            const PRICE_T initialFixingPrice = GET_PRICE(input.getInstr(), A_Instr_UnderlyFixingPrice);

            switch(static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(input.getInstr(), A_Instr_UnderlyCatEn)))
            {
                case INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket:
                    if (false == weightedPrices.empty())
                    {
                        const PRICE_T sumWeightedPrices = std::accumulate(weightedPrices.begin(), weightedPrices.end(), ZERO_NUMBER);

                        result.setPrice(initialFixingPrice * sumWeightedPrices);

                        /* PMSTA-35021 - 260319 - PMO */
                        NUMBER_T delta = ZERO_NUMBER;

                        if (false == prices.empty() && prices.size() == multipliers.size())
                        {
                            for (size_t idx = 0; idx < prices.size(); idx++)
                            {
                                delta += prices[idx] * multipliers[idx];
                            }

                            delta = InstrumentSTNComputationBase::deltaPercent(delta, GET_PRICE(input.getInstr(), A_Instr_ExerQuote));
                        }

                        result.setDelta(delta);
                    }
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument:
                    result.setPrice(InstrumentSTNComputationBase::deltaPercent(prices[0], initialFixingPrice));
                    result.setQuote(prices[0]);
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket:
                    if (false == prices.empty())
                    {
                        std::vector<PRICE_T> pricesWorstDelta;

                        for (size_t idx = 0; idx < prices.size(); idx++)
                        {
                            pricesWorstDelta.push_back(InstrumentSTNComputationBase::deltaPercent(prices[idx], initialPrices[idx]));
                        }

                        const size_t worstIdx = std::distance(pricesWorstDelta.begin(), std::min_element(pricesWorstDelta.begin(), pricesWorstDelta.end()));

                        result.setPrice(prices                      [worstIdx]);
                        std::vector<ID_T> resultWorstInstrId;
                        resultWorstInstrId.push_back(weightedPricesInstrId[worstIdx]);

						result.setExercisePrice(exercisePrices      [worstIdx]);
                        result.setInitialPrice(initialPrices        [worstIdx]);
                        result.setBarrier(barriers                  [worstIdx]);
                        result.setDelta(InstrumentSTNComputationBase::deltaPercent(prices[worstIdx], exercisePrices[worstIdx]));    /* PMSTA-35021 - 260319 - PMO */

						/* PMSTA-35265 - 190617 - It could have several worst, ben oui y'a toujours pire */
						for (size_t idx=0; idx< pricesWorstDelta.size(); idx++)
							if (idx != worstIdx && pricesWorstDelta[idx] == pricesWorstDelta[worstIdx])
								resultWorstInstrId.push_back(weightedPricesInstrId[idx]);

						result.setWorstInstrId(resultWorstInstrId);
                    }
                    break;

                case INSTR_UNDERLYING_CATEGORY_ENUM::None:
                    break;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CreateMainInstrFromTemplate()
**
**  Description :   Create main intrument from template.
**                    - copy template instrument
**                    - remove PK/BK
**                    - Update it with value given in parameter of A_InstrTemplateArg
**                    - Run DV on remaining fields using screen if given
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34378 - DDV - 190131
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_CreateMainInstrFromTemplate(DBA_DYNFLD_STP   instrTemplateArgStp,
                                                DBA_DYNFLD_STP   templateInstrStp,
                                                DBA_DYNFLD_STP  *newInstrPtr)
{
    RET_CODE                 ret = RET_SUCCEED;
    MemoryPool               mp;
    DBA_DYNFLD_STP           instrStp = mp.allocDynst(FILEINFO, A_Instr);

    if (instrStp == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Instr");
        return(RET_MEM_ERR_ALLOC);
    }

    /* copy template instrument */
    DBA_CopyDynSt(instrStp, templateInstrStp, A_Instr);

    /* remove PK and BK */
    SET_NULL_ID(instrStp, A_Instr_Id);
    SET_NULL_CODE(instrStp, A_Instr_Cd);

    /* update new instrument with values given in the param arg and add it into collection */
    DBA_DYNFLD_STP          paramInstrStp = NULL;
    EVAL_DATA_ENTITY_STP    evalDataEntityStp = NULL;
    DEF_DATA_ENTITY_STP     defDataEntityStp = NULL;
    int                     connectNo = NO_VALUE;

    if ((ret = DICT_ImportRecord(GET_TEXT(instrTemplateArgStp, A_InstrTemplateArg_Parameter),
                                 "instrument",
                                 &paramInstrStp,
                                 EvalDataType_AllStruct,
                                 &evalDataEntityStp,
                                 &defDataEntityStp,
                                 &connectNo)) != RET_SUCCEED)
    {
        DICT_FreeEvalDataEntity(&evalDataEntityStp);
        DICT_FreeDefDataEntity(&defDataEntityStp);
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error during analysis of RPC parameter @parameter");
        return ret;
    }

    mp.owner(paramInstrStp);

    FIELD_IDX_T     fldIdx;
    FLAG_T          *flagTab = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_Instr), sizeof(FLAG_T));

    if (flagTab == nullptr)
    {
        DICT_FreeEvalDataEntity(&evalDataEntityStp);
        DICT_FreeDefDataEntity(&defDataEntityStp);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_Instr) * sizeof(FLAG_T));
        return(RET_MEM_ERR_ALLOC);
    }

    for (int i=0; i<evalDataEntityStp->evalDataFldNbr; i++)
    {
        if (evalDataEntityStp->evalDataFldStTab[i].attribStp != NULL)
        {
            DICT_ATTRIB_STP    dictAttrStp = evalDataEntityStp->evalDataFldStTab[i].attribStp;

            if ((fldIdx = dictAttrStp->progN) >= 0)
            {
                COPY_DYNFLD(instrStp, A_Instr, fldIdx, paramInstrStp, A_Instr, fldIdx);
                if (evalDataEntityStp->evalDataFldStTab[i].defDataFldStp->forcedFlg == TRUE)
                {
                    flagTab[fldIdx] = TRUE;
                }
            }
        }
    }

    /* PMSTA-34378 - DDV - 190205 - set parent_instr_id with template instrument id */
    COPY_DYNFLD(instrStp, A_Instr, A_Instr_ParentInstrId, templateInstrStp, A_Instr, A_Instr_Id);
    flagTab[A_Instr_ParentInstrId] = TRUE;

    /* PMSTA-34378 - DDV - 190205 - set usage_nat_e to unlisted */
    SET_ENUM(instrStp, A_Instr_UsageNatEn, InstrUsage_UnlistedInstr);
    flagTab[A_Instr_UsageNatEn] = TRUE;

    /* PMSTA-40319 - Kramadevi - 22052020 - set  A_Instr_TempDerivedInstrLocEn with template A_Instr_TempDerivedInstrLocEn*/
    SET_ENUM(instrStp, A_Instr_TempDerivedInstrLocEn, GET_ENUM(templateInstrStp, A_Instr_TempDerivedInstrLocEn));
    flagTab[A_Instr_TempDerivedInstrLocEn] = TRUE;

    /* If code has not been given, compute DV on it and set it as forced  */
    if (IS_NULLFLD(instrStp, A_Instr_Cd) == TRUE)
    {
        FLAG_T          *flagTabCd = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_Instr), sizeof(FLAG_T));

        if (flagTabCd == nullptr)
        {
            DICT_FreeEvalDataEntity(&evalDataEntityStp);
            DICT_FreeDefDataEntity(&defDataEntityStp);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_Instr) * sizeof(FLAG_T));
            return(RET_MEM_ERR_ALLOC);
        }

        for (int i = 0; i < GET_FLD_NBR(A_Instr); i++)
        {
            flagTabCd[i] = TRUE;
        }

        flagTabCd[A_Instr_Cd] = FALSE;

        SCPT_ComputeScreenDV(Instr,                                                            /* object                        */
                             GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                             flagTabCd,                                                        /* *flagsParam                   */
                             NULL,                                                             /* *pflagtabFilter               */
                             instrStp,                                                         /* record                        */
                             NULL,                                                             /* oldRecord                     */
                             NULLDYNST,                                                        /* domain                        */
                             NULLDYNST,                                                        /* objectModifStat               */
                             TRUE,			                                                   /* mode (analyseAllFlg)          */
                             TRUE,			                                                   /* type (guiFlg)  	              */
                             EvalType_DefVal,                                                  /* enEvalType                    */
                             0,				                                                   /* fldIdx                        */
                             NULL,                                                             /* *connPtr                      */
                             NULL,			                                                   /* filterTab                     */
                             NULL,	                                                           /* hierHead                      */
                             0,                                                                /* idScriptObject (screenDictId) */
                             DictScreen,                                                       /* enScriptObject                */
                             NULL,                                                             /* *pdictidScreen                */
                             NULL,                                                             /* *pdbadynOp                    */
                             NULL,                                                             /* pfmtDataDefTab                */
                             NULL,                                                             /* pdbadynFldTab                 */
                             NULL,                                                             /* pdbadynReference              */
                             NullEntity,                                                       /* enReferenceObject             */
                             FALSE,                                                            /* flagEOpCase                   */
                             FALSE,                                                            /* flagFlagNoImpact              */
                             0);                                                               /* compoundScreenDictId          */

        flagTab[A_Instr_Cd] = TRUE; /* force evaluation of field depending of code */
    }

    /* Call DV */
    SCPT_ComputeScreenDV(Instr,                                                            /* object                        */
                         GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                         flagTab,                                                          /* *flagsParam                   */
                         NULL,                                                             /* *pflagtabFilter               */
                         instrStp,                                                         /* record                        */
                         NULL,                                                             /* oldRecord                     */
                         NULLDYNST,                                                        /* domain                        */
                         NULLDYNST,                                                        /* objectModifStat               */
                         FALSE,			                                                   /* mode (analyseAllFlg)          */
                         TRUE,			                                                   /* type (guiFlg)  	            */
                         EvalType_DefVal,                                                  /* enEvalType                    */
                         0,				                                                   /* fldIdx                        */
                         NULL,                                                             /* *connPtr                      */
                         NULL,			                                                   /* filterTab                     */
                         NULL,	                                                           /* hierHead                      */
                         0,                                                                /* idScriptObject (screenDictId) */
                         DictScreen,                                                       /* enScriptObject                */
                         NULL,                                                             /* *pdictidScreen                */
                         NULL,                                                             /* *pdbadynOp                    */
                         NULL,                                                             /* pfmtDataDefTab                */
                         NULL,                                                             /* pdbadynFldTab                 */
                         NULL,                                                             /* pdbadynReference              */
                         NullEntity,                                                       /* enReferenceObject             */
                         FALSE,                                                            /* flagEOpCase                   */
                         FALSE,                                                            /* flagFlagNoImpact              */
                         0);                                                               /* compoundScreenDictId          */

    *newInstrPtr = instrStp;
    mp.remove(instrStp);

    DICT_FreeEvalDataEntity(&evalDataEntityStp);
    DICT_FreeDefDataEntity(&defDataEntityStp);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrCompo
**
**  Description :   Create a new intr_compo for given instrument and prant instrument. Insert it into database and hierarchy
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190220
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrCompo(DBA_DYNFLD_STP        instrTemplateArgStp,
                                     DBA_DYNFLD_STP        parentInstrStp,
                                     DBA_DYNFLD_STP        instrStp,
                                     DBA_HIER_HEAD_STP     hierHead,
                                     DbiConnectionHelper&  dbiConnHelper)
{
    RET_CODE                 ret = RET_SUCCEED;
    DBA_DYNFLD_STP           newRecStp;
    MemoryPool               mp;

    if ((newRecStp = mp.allocDynst(FILEINFO, A_InstrCompo)) != NULL)
    {
        FLAG_T          *flagTab = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_InstrCompo), sizeof(FLAG_T));

        if (flagTab != nullptr)
        {
            DBA_SetDfltEntityFld(InstrCompo, A_InstrCompo, newRecStp);

            flagTab[A_InstrCompo_ParentInstrId] = TRUE;
            COPY_DYNFLD(newRecStp, A_InstrCompo, A_InstrCompo_ParentInstrId, parentInstrStp, A_Instr, A_Instr_Id);

            flagTab[A_InstrCompo_InstrId] = TRUE;
            COPY_DYNFLD(newRecStp, A_InstrCompo, A_InstrCompo_InstrId, instrStp, A_Instr, A_Instr_Id);

            /* set a default rank to 1 to avoid insertion error */
            SET_SMALLINT(newRecStp, A_InstrCompo_Rank, 1);

            /* set a default quantity to 1 to avoid insertion error */
            SET_NUMBER(newRecStp, A_InstrCompo_Quantity, 1);

            SCPT_ComputeScreenDV(InstrCompo,                                                       /* object                        */
                                 GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                                 flagTab,                                                          /* *flagsParam                   */
                                 NULL,                                                             /* *pflagtabFilter               */
                                 newRecStp,                                                        /* record                        */
                                 NULL,                                                             /* oldRecord                     */
                                 NULLDYNST,                                                        /* domain                        */
                                 NULLDYNST,                                                        /* objectModifStat               */
                                 TRUE,			                                                   /* mode (analyseAllFlg)          */
                                 TRUE,			                                                   /* type (guiFlg)  	            */
                                 EvalType_DefVal,                                                  /* enEvalType                    */
                                 0,				                                                   /* fldIdx                        */
                                 &(dbiConnHelper.getId()),                                         /* *connPtr                      */
                                 NULL,			                                                   /* filterTab                     */
                                 NULL,	                                                           /* hierHead                      */
                                 0,                                                                /* idScriptObject (screenDictId) */
                                 DictScreen,                                                       /* enScriptObject                */
                                 NULL,                                                             /* *pdictidScreen                */
                                 NULL,                                                             /* *pdbadynOp                    */
                                 NULL,                                                             /* pfmtDataDefTab                */
                                 NULL,                                                             /* pdbadynFldTab                 */
                                 NULL,                                                             /* pdbadynReference              */
                                 NullEntity,                                                       /* enReferenceObject             */
                                 FALSE,                                                            /* flagEOpCase                   */
                                 FALSE,                                                            /* flagFlagNoImpact              */
                                 0);                                                               /* compoundScreenDictId          */

            if ((ret = dbiConnHelper.dbaInsert(InstrCompo, UNUSED, newRecStp)) == RET_SUCCEED)
            {
                if (hierHead != NULL)
                {
                    if ((ret = DBA_AddHierRecord(hierHead, newRecStp, A_InstrCompo, FALSE, HierAddRec_NoLnk)) == RET_SUCCEED)
                    {
                        mp.remove(newRecStp);
                    }
                    else
                    {
                        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    }
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_InstrCompo) * sizeof(FLAG_T));
            ret = RET_MEM_ERR_ALLOC;
        }
    }
    else
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_InstrCompo");
        ret = RET_MEM_ERR_ALLOC;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateNewInstrByNatureCateg()
**
**  Description :   Create main intrument with the given nature_e and categ. Also set parent instrument.
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190220
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateNewInstrByNatureCateg(DBA_DYNFLD_STP        instrTemplateArgStp,
                                                DBA_DYNFLD_STP        parentInstrStp,
                                                INSTRNAT_ENUM         instrNatureEn,
                                                INSTR_CATEG_ENUM      instrCategEn,
                                                FLAG_T                creatInstrCompoFlg,
                                                FLAG_T                insertInstrCompoInHierFlg,
                                                FLAG_T                creatTermEventFlg,
                                                DBA_HIER_HEAD_STP     hierHead,
                                                DbiConnectionHelper&  dbiConnHelper)
{
    RET_CODE                 ret = RET_SUCCEED;
    MemoryPool               mp;
    DBA_DYNFLD_STP           instrStp = mp.allocDynst(FILEINFO, A_Instr);

    if (instrStp == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Instr");
        return(RET_MEM_ERR_ALLOC);
    }

    FLAG_T          *flagTab = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_Instr), sizeof(FLAG_T));

    if (flagTab == nullptr)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_Instr) * sizeof(FLAG_T));
        return(RET_MEM_ERR_ALLOC);
    }

    DBA_SetDfltEntityFld(Instr, A_Instr, instrStp);

    /* set parent_instr_id with given instrument id */
    COPY_DYNFLD(instrStp, A_Instr, A_Instr_ParentInstrId, parentInstrStp, A_Instr, A_Instr_Id);
    flagTab[A_Instr_ParentInstrId] = TRUE;

    /* set usage_nat_e to unlisted */
    SET_ENUM(instrStp, A_Instr_UsageNatEn, InstrUsage_UnlistedInstr);
    flagTab[A_Instr_UsageNatEn] = TRUE;

    /* set instrument's nature_e with given parameter */
    SET_ENUM(instrStp, A_Instr_NatEn, instrNatureEn);
    flagTab[A_Instr_NatEn] = TRUE;

    /* set instrument's categ_e with given parameter */
    SET_ENUM(instrStp, A_Instr_CategEn, instrCategEn);
    flagTab[A_Instr_CategEn] = TRUE;

    /* Call DV */
    SCPT_ComputeScreenDV(Instr,                                                            /* object                        */
                         GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                         flagTab,                                                          /* *flagsParam                   */
                         NULL,                                                             /* *pflagtabFilter               */
                         instrStp,                                                         /* record                        */
                         NULL,                                                             /* oldRecord                     */
                         NULLDYNST,                                                        /* domain                        */
                         NULLDYNST,                                                        /* objectModifStat               */
                         TRUE,			                                                   /* mode (analyseAllFlg)          */
                         TRUE,			                                                   /* type (guiFlg)  	            */
                         EvalType_DefVal,                                                  /* enEvalType                    */
                         0,				                                                   /* fldIdx                        */
                         &(dbiConnHelper.getId()),                                         /* *connPtr                      */
                         NULL,			                                                   /* filterTab                     */
                         NULL,	                                                           /* hierHead                      */
                         0,                                                                /* idScriptObject (screenDictId) */
                         DictScreen,                                                       /* enScriptObject                */
                         NULL,                                                             /* *pdictidScreen                */
                         NULL,                                                             /* *pdbadynOp                    */
                         NULL,                                                             /* pfmtDataDefTab                */
                         NULL,                                                             /* pdbadynFldTab                 */
                         NULL,                                                             /* pdbadynReference              */
                         NullEntity,                                                       /* enReferenceObject             */
                         FALSE,                                                            /* flagEOpCase                   */
                         FALSE,                                                            /* flagFlagNoImpact              */
                         0);                                                               /* compoundScreenDictId          */

    if ((ret = dbiConnHelper.dbaInsert(Instr, UNUSED, instrStp)) == RET_SUCCEED)
    {
        if (hierHead != NULL)
        {
            if ((ret = DBA_AddHierRecord(hierHead, instrStp, A_Instr, FALSE, HierAddRec_NoLnk)) == RET_SUCCEED)
            {
                mp.remove(instrStp);
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            }
        }
    }
    else
    {
        MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
    }

    if (ret == RET_SUCCEED && creatInstrCompoFlg == TRUE)
    {
        if ((ret = FIN_CreateInstrCompo(instrTemplateArgStp, parentInstrStp, instrStp, (insertInstrCompoInHierFlg == TRUE) ? hierHead : NULL, dbiConnHelper)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of instrument compo for instrument", GET_CODE(parentInstrStp, A_Instr_Cd), "failed.");
        }
    }

    if (ret == RET_SUCCEED && creatTermEventFlg == TRUE)
    {
        if ((ret = FIN_CreateTermEvent(instrTemplateArgStp, instrStp, hierHead, dbiConnHelper)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of term_event for new instrument ", GET_CODE(instrStp, A_Instr_Cd), "failed.");
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrPrice
**
**  Description :   Create a new intr_price for given instrument. Insert it into database and hierarchy
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190220
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrPrice(DBA_DYNFLD_STP        instrTemplateArgStp,
                                     DBA_DYNFLD_STP        instrStp,
                                     DBA_HIER_HEAD_STP     hierHead,
                                     DbiConnectionHelper&  dbiConnHelper)
{
    RET_CODE                 ret = RET_SUCCEED;
    DBA_DYNFLD_STP           newRecStp;
    MemoryPool               mp;

    if ((newRecStp = mp.allocDynst(FILEINFO, A_InstrPrice)) != NULL)
    {
        FLAG_T          *flagTab = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_InstrPrice), sizeof(FLAG_T));

        if (flagTab != nullptr)
        {
            DBA_SetDfltEntityFld(InstrPrice, A_InstrPrice, newRecStp);

            flagTab[A_InstrPrice_InstrId] = TRUE;
            COPY_DYNFLD(newRecStp, A_InstrPrice, A_InstrPrice_InstrId, instrStp, A_Instr, A_Instr_Id);

            flagTab[A_InstrPrice_Quote] = TRUE;
            if (GET_ENUM(instrStp, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Quote100)
            {
                SET_PRICE(newRecStp, A_InstrPrice_Quote, 100);
            }
            else
            {
                SET_PRICE(newRecStp, A_InstrPrice_Quote, 1);
            }

            SCPT_ComputeScreenDV(InstrPrice,                                                       /* object                        */
                                 GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                                 flagTab,                                                          /* *flagsParam                   */
                                 NULL,                                                             /* *pflagtabFilter               */
                                 newRecStp,                                                        /* record                        */
                                 NULL,                                                             /* oldRecord                     */
                                 NULLDYNST,                                                        /* domain                        */
                                 NULLDYNST,                                                        /* objectModifStat               */
                                 TRUE,			                                                   /* mode (analyseAllFlg)          */
                                 TRUE,			                                                   /* type (guiFlg)  	            */
                                 EvalType_DefVal,                                                  /* enEvalType                    */
                                 0,				                                                   /* fldIdx                        */
                                 &(dbiConnHelper.getId()),                                         /* *connPtr                      */
                                 NULL,			                                                   /* filterTab                     */
                                 NULL,	                                                           /* hierHead                      */
                                 0,                                                                /* idScriptObject (screenDictId) */
                                 DictScreen,                                                       /* enScriptObject                */
                                 NULL,                                                             /* *pdictidScreen                */
                                 NULL,                                                             /* *pdbadynOp                    */
                                 NULL,                                                             /* pfmtDataDefTab                */
                                 NULL,                                                             /* pdbadynFldTab                 */
                                 NULL,                                                             /* pdbadynReference              */
                                 NullEntity,                                                       /* enReferenceObject             */
                                 FALSE,                                                            /* flagEOpCase                   */
                                 FALSE,                                                            /* flagFlagNoImpact              */
                                 0);                                                               /* compoundScreenDictId          */

            if ((ret = dbiConnHelper.dbaInsert(InstrPrice, UNUSED, newRecStp)) == RET_SUCCEED)
            {
                if (hierHead != NULL)
                {
                    if ((ret = DBA_AddHierRecord(hierHead, newRecStp, A_InstrPrice, FALSE, HierAddRec_NoLnk)) == RET_SUCCEED)
                    {
                        mp.remove(newRecStp);
                    }
                    else
                    {
                        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    }
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_InstrPrice) * sizeof(FLAG_T));
            ret = RET_MEM_ERR_ALLOC;
        }
    }
    else
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_InstrPrice");
        ret = RET_MEM_ERR_ALLOC;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateInterCond
**
**  Description :   Create a new interest_cond for given instrument. Insert it into database and hierarchy
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190220
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInterCond(DBA_DYNFLD_STP        instrTemplateArgStp,
                                    DBA_DYNFLD_STP        instrStp,
                                    DBA_HIER_HEAD_STP     hierHead,
                                    DbiConnectionHelper&  dbiConnHelper)
{
    RET_CODE                 ret = RET_SUCCEED;
    DBA_DYNFLD_STP           newRecStp;
    MemoryPool               mp;

    if ((newRecStp = mp.allocDynst(FILEINFO, A_InterCond)) != NULL)
    {
        FLAG_T          *flagTab = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_InterCond), sizeof(FLAG_T));

        if (flagTab != nullptr)
        {
            DBA_SetDfltEntityFld(InterCond, A_InterCond, newRecStp);

            flagTab[A_InterCond_InstrId] = TRUE;
            COPY_DYNFLD(newRecStp, A_InterCond, A_InterCond_InstrId, instrStp, A_Instr, A_Instr_Id);

            SCPT_ComputeScreenDV(InterCond,                                                        /* object                        */
                                    GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                                    flagTab,                                                          /* *flagsParam                   */
                                    NULL,                                                             /* *pflagtabFilter               */
                                    newRecStp,                                                        /* record                        */
                                    NULL,                                                             /* oldRecord                     */
                                    NULLDYNST,                                                        /* domain                        */
                                    NULLDYNST,                                                        /* objectModifStat               */
                                    TRUE,			                                                   /* mode (analyseAllFlg)          */
                                    TRUE,			                                                   /* type (guiFlg)  	            */
                                    EvalType_DefVal,                                                  /* enEvalType                    */
                                    0,				                                                   /* fldIdx                        */
                                    &(dbiConnHelper.getId()),                                         /* *connPtr                      */
                                    NULL,			                                                   /* filterTab                     */
                                    NULL,	                                                           /* hierHead                      */
                                    0,                                                                /* idScriptObject (screenDictId) */
                                    DictScreen,                                                       /* enScriptObject                */
                                    NULL,                                                             /* *pdictidScreen                */
                                    NULL,                                                             /* *pdbadynOp                    */
                                    NULL,                                                             /* pfmtDataDefTab                */
                                    NULL,                                                             /* pdbadynFldTab                 */
                                    NULL,                                                             /* pdbadynReference              */
                                    NullEntity,                                                       /* enReferenceObject             */
                                    FALSE,                                                            /* flagEOpCase                   */
                                    FALSE,                                                            /* flagFlagNoImpact              */
                                    0);                                                               /* compoundScreenDictId          */

            if ((ret = dbiConnHelper.dbaInsert(InterCond, UNUSED, newRecStp)) == RET_SUCCEED)
            {
                if (hierHead != NULL)
                {
                    if ((ret = DBA_AddHierRecord(hierHead, newRecStp, A_InterCond, FALSE, HierAddRec_NoLnk)) == RET_SUCCEED)
                    {
                        mp.remove(newRecStp);
                    }
                    else
                    {
                        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    }
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_InterCond) * sizeof(FLAG_T));
            ret = RET_MEM_ERR_ALLOC;
        }
    }
    else
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_InterCond");
        ret = RET_MEM_ERR_ALLOC;
    }
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateTermEvent
**
**  Description :   Create a new term_event for given instrument. Insert it into database and hierarchy
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190220
**
**  Modif       :
**
*************************************************************************/
STATIC RET_CODE FIN_CreateTermEvent(DBA_DYNFLD_STP        instrTemplateArgStp,
                                    DBA_DYNFLD_STP        instrStp,
                                    DBA_HIER_HEAD_STP     hierHead,
                                    DbiConnectionHelper&  dbiConnHelper)
{
    RET_CODE                 ret = RET_SUCCEED;
    DBA_DYNFLD_STP           newRecStp;
    MemoryPool               mp;

    if ((newRecStp = mp.allocDynst(FILEINFO, A_TermEvt)) != NULL)
    {
        FLAG_T          *flagTab = (FLAG_T *)mp.calloc(GET_FLD_NBR(A_TermEvt), sizeof(FLAG_T));

        if (flagTab != nullptr)
        {
            DBA_SetDfltEntityFld(TermEvt, A_TermEvt, newRecStp);

            flagTab[A_TermEvt_InstrId] = TRUE;
            COPY_DYNFLD(newRecStp, A_TermEvt, A_TermEvt_InstrId, instrStp, A_Instr, A_Instr_Id);

            SCPT_ComputeScreenDV(TermEvt,                                                        /* object                        */
                                 GET_DICT(instrTemplateArgStp, A_InstrTemplateArg_FctDictId),      /* functionDictId                */
                                 flagTab,                                                          /* *flagsParam                   */
                                 NULL,                                                             /* *pflagtabFilter               */
                                 newRecStp,                                                        /* record                        */
                                 NULL,                                                             /* oldRecord                     */
                                 NULLDYNST,                                                        /* domain                        */
                                 NULLDYNST,                                                        /* objectModifStat               */
                                 TRUE,			                                                   /* mode (analyseAllFlg)          */
                                 TRUE,			                                                   /* type (guiFlg)  	            */
                                 EvalType_DefVal,                                                  /* enEvalType                    */
                                 0,				                                                   /* fldIdx                        */
                                 &(dbiConnHelper.getId()),                                         /* *connPtr                      */
                                 NULL,			                                                   /* filterTab                     */
                                 NULL,	                                                           /* hierHead                      */
                                 0,                                                                /* idScriptObject (screenDictId) */
                                 DictScreen,                                                       /* enScriptObject                */
                                 NULL,                                                             /* *pdictidScreen                */
                                 NULL,                                                             /* *pdbadynOp                    */
                                 NULL,                                                             /* pfmtDataDefTab                */
                                 NULL,                                                             /* pdbadynFldTab                 */
                                 NULL,                                                             /* pdbadynReference              */
                                 NullEntity,                                                       /* enReferenceObject             */
                                 FALSE,                                                            /* flagEOpCase                   */
                                 FALSE,                                                            /* flagFlagNoImpact              */
                                 0);                                                               /* compoundScreenDictId          */

            if ((ret = dbiConnHelper.dbaInsert(TermEvt, UNUSED, newRecStp)) == RET_SUCCEED)
            {
                if (hierHead != NULL)
                {
                    if ((ret = DBA_AddHierRecord(hierHead, newRecStp, A_TermEvt, FALSE, HierAddRec_NoLnk)) == RET_SUCCEED)
                    {
                        mp.remove(newRecStp);
                    }
                    else
                    {
                        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    }
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(A_TermEvt) * sizeof(FLAG_T));
            ret = RET_MEM_ERR_ALLOC;
        }
    }
    else
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_TermEvt");
        ret = RET_MEM_ERR_ALLOC;
    }
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrInMaster()
**
**  Description :   Decide if instrument must be created into master database or not
**
**  Arguments   :   aInstrStp       new instrument
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-35512 - DDV - 190425
**
**  Modif       :   PMSTA-35662 - Kramadevi - 22042020
**
*************************************************************************/
FLAG_T FIN_CreateInstrInMaster(DBA_DYNFLD_STP aInstrStp)
{
    /* it has sense only when multi-entity is active */
    if (GEN_IsMultiEntity())
    {
        if ((GET_ENUM(aInstrStp, A_Instr_TempDerivedInstrLocEn) == InstrTempDerivedInstrLoc_Default && InstrumentNature::isDerivedFromStructuredNotesTemplate(aInstrStp))
            || GET_ENUM(aInstrStp, A_Instr_TempDerivedInstrLocEn) == InstrTempDerivedInstrLoc_Master)
        {
            return(TRUE);
        }
    }

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CreateStructuredNotesFromTemplate()
**
**  Description :   Create a new capital protected note instrument based on a template intrument
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34378 - DDV - 190131
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_CreateStructuredNotesFromTemplate(DBA_DYNFLD_STP instrTemplateArgStp, DBA_DYNFLD_STP templateInstrStp, DBA_DYNFLD_STP mainInstrStp, DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE                 ret = RET_SUCCEED;
    MemoryPool               mp;

    if (InstrumentNature::isDerivedFromStructuredNotesTemplate(mainInstrStp) == false)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "New instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "is not a stuctured notes (check nature sub_nature_e and instrument_class_e)");
        mp.owner(mainInstrStp);
        return(RET_GEN_ERR_PERSONAL);
    }

    { /* PMSTA-35512 - DDV - 190430 - Open a block to have to use the right connection provider in connection helper destructor */
        DbiConnectionHelper      dbiConnHelper;

        /* add instrument in hierarchy */
        if (ret == RET_SUCCEED)
        {
            dbiConnHelper.isValidAndInit();
            dbiConnHelper.beginTransaction();
            dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE);
            if ((ret = dbiConnHelper.dbaInsert(Instr, UNUSED, mainInstrStp)) == RET_SUCCEED)
            {
                if ((ret = DBA_AddHierRecord(hierHead, mainInstrStp, A_Instr, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    mp.owner(mainInstrStp); /*PMSTA-40535 -NRAO -Fix memory leaks*/
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
                mp.owner(mainInstrStp);
            }
        }

        /* create instr_price record and add it into hierarchy */
        if (ret == RET_SUCCEED && (ret = FIN_CreateInstrPrice(instrTemplateArgStp, mainInstrStp, hierHead, dbiConnHelper)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of main instrument's instr_price for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
        }

        /* create accr_inter record and add it into hierarchy */
        if (ret == RET_SUCCEED && (ret = FIN_CreateInterCond(instrTemplateArgStp, mainInstrStp, hierHead, dbiConnHelper))!=RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of main instrument's interest_cond for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
        }

        if (ret == RET_SUCCEED)
        {
            dbiConnHelper.commit();
        }
        else
        {
            dbiConnHelper.sendAllMsg();
            dbiConnHelper.rollback();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CreateOTCDerivativesFromTemplate()
**
**  Description :   Create a new capital protected note instrument based on a template intrument
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34685 - DDV - 190219
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_CreateOTCDerivativesFromTemplate(DBA_DYNFLD_STP instrTemplateArgStp, DBA_DYNFLD_STP templateInstrStp, DBA_DYNFLD_STP mainInstrStp, DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE                 ret = RET_SUCCEED;
    MemoryPool               mp;
    DbiConnectionHelper      dbiConnHelper;

    if (InstrumentNature::isDerivedFromOTCDerivativeTemplate(mainInstrStp) == false)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "New instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "is not a stuctured notes (check nature sub_nature_e and instrument_class_e)");
        mp.owner(mainInstrStp);
        return(RET_GEN_ERR_PERSONAL);
    }

    /* add instrument in hierarchy */
    if (ret == RET_SUCCEED)
    {
        dbiConnHelper.isValidAndInit();
        dbiConnHelper.beginTransaction();
        dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE);
        if ((ret = dbiConnHelper.dbaInsert(Instr, UNUSED, mainInstrStp)) == RET_SUCCEED)
        {
            if ((ret = DBA_AddHierRecord(hierHead, mainInstrStp, A_Instr, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            mp.owner(mainInstrStp);
        }
    }

    if (ret == RET_SUCCEED && (ret = FIN_CreateInstrPrice(instrTemplateArgStp, mainInstrStp, hierHead, dbiConnHelper)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of main instrument's instr_price for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
    }

    if (GET_ENUM(mainInstrStp, A_Instr_NatEn) == InstrNat_ExoticOptions)
    {
        if (ret == RET_SUCCEED && (ret = FIN_CreateTermEvent(instrTemplateArgStp, mainInstrStp, hierHead, dbiConnHelper)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of main instrument's term_event for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
        }
    }

    if (ret == RET_SUCCEED)
    {
        dbiConnHelper.commit();
    }
    else
    {
        dbiConnHelper.sendAllMsg();;
        dbiConnHelper.rollback();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CreateStructuredProductFromTemplate()
**
**  Description :   Create a new capital protected note instrument based on a template intrument
**
**  Arguments   :   input       Input arguments
**
**
**  Return      :   None
**
**  Creation    :   PMSTA-34686 - DDV - 190219
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_CreateStructuredProductFromTemplate(DBA_DYNFLD_STP instrTemplateArgStp, DBA_DYNFLD_STP templateInstrStp, DBA_DYNFLD_STP mainInstrStp, DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE                 ret = RET_SUCCEED;
    MemoryPool               mp;
    DbiConnectionHelper      dbiConnHelper;

    if (InstrumentNature::isDerivedFromStructuredProductTemplate(mainInstrStp) == false)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "New instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "is not a stuctured notes (check nature sub_nature_e and instrument_class_e)");
        mp.owner(mainInstrStp);
        return(RET_GEN_ERR_PERSONAL);
    }

    /* add instrument in hierarchy */
    if (ret == RET_SUCCEED)
    {
        dbiConnHelper.isValidAndInit();
        dbiConnHelper.beginTransaction();
        dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE);
        if ((ret = dbiConnHelper.dbaInsert(Instr, UNUSED, mainInstrStp)) == RET_SUCCEED)
        {
            if ((ret = DBA_AddHierRecord(hierHead, mainInstrStp, A_Instr, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            }
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
            mp.owner(mainInstrStp);
        }
    }

    if (ret == RET_SUCCEED)
    {
        switch(GET_ENUM(mainInstrStp, A_Instr_SubNatEn))
        {
            case SubNat_TripleCurrencyInvest:
                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_ExoticOptions, InstrCateg_SPOption2, TRUE /*Compo*/, FALSE /*addCompoInHier*/, TRUE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Option 2 for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }

                /* No break, all records created for Dual currency must also be created for Triple currency */

            case SubNat_DualCurrencyInvest:
                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_ExoticOptions, InstrCateg_SPOption1, TRUE /*Compo*/, FALSE /*addCompoInHier*/, TRUE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Option 1 for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }

                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_MoneyMkt, InstrCateg_SPMoneyMarket, TRUE  /*Compo*/, FALSE /*addCompoInHier*/, FALSE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Money Market for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }
                break;

            case SubNat_Accumulator:
            case SubNat_Decumulator:
                if (ret == RET_SUCCEED && (ret = FIN_CreateTermEvent(instrTemplateArgStp, mainInstrStp, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of main instrument's term_event for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }
                break;

            case SubNat_ParticipatingForward:
            case SubNat_TargetKnockOutForward:
                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_Option, InstrCateg_SPBuyOption, TRUE /*Compo*/, FALSE /*addCompoInHier*/, TRUE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Buy Option for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }

                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_Option, InstrCateg_SPSellOption, TRUE /*Compo*/, FALSE /*addCompoInHier*/, TRUE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Buy Option for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }

                if (ret == RET_SUCCEED && (ret = FIN_CreateNewInstrByNatureCateg(instrTemplateArgStp, mainInstrStp, InstrNat_Option, InstrCateg_SPVanillaOption, TRUE /*Compo*/, FALSE /*addCompoInHier*/, TRUE /*TermEvt*/, hierHead, dbiConnHelper)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Creation of Buy Option for new instrument based on template", GET_CODE(templateInstrStp, A_Instr_Cd), "failed.");
                }
                break;

            default:
                break;

        }
    }

    if (ret == RET_SUCCEED)
    {
        dbiConnHelper.commit();
    }
    else
    {
        dbiConnHelper.sendAllMsg();;
        dbiConnHelper.rollback();
    }

    return ret;
}

/************************************************************************
**  Function    :   FIN_CreateInstrFromTemplate()
**
**  Description : Create a new instrument based on a template intrument
**
**  Arguments : input       Input arguments
**
**
**  Return : None
* *
**  Creation : PMSTA - 34378 - DDV - 190131
* *
**  Modif :
**
*************************************************************************/
RET_CODE FIN_CreateInstrFromTemplate(DBA_DYNFLD_STP instrTemplateArgStp, DBA_DYNFLD_STP templateInstrStp, DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE                 ret = RET_SUCCEED;
    DBA_DYNFLD_STP           mainInstrStp;

    /* create new main instrument base on template and instrTemplateArg */
    ret = FIN_CreateMainInstrFromTemplate(instrTemplateArgStp, templateInstrStp, &mainInstrStp);

    FLAG_T              createInstrInMasterFlg = FIN_CreateInstrInMaster(mainInstrStp);
    const std::string   initialBusinessEntity = SYS_GetThread().getCurrBusinessEntity();

    if (createInstrInMasterFlg == TRUE)
    {
        SYS_SetThreadUseServerUser(true);
        SYS_SetThreadCurrBusinessEntity(EV_MasterBusinessEntity);
    }

	/* call function specific to instrument category */
    switch (GET_ENUM(templateInstrStp, A_Instr_UsageNatEn))
    {
        case InstrUsage_StructuredNotesTemplate:
            ret = FIN_CreateStructuredNotesFromTemplate(instrTemplateArgStp, templateInstrStp, mainInstrStp, hierHead);
            break;

        /* PMSTA-34685 - DDV - 190219 */
        case InstrUsage_OTCDerivativesTemplate:
        case InstrUsage_OTCCurrencyDerivativesTemplate:
            ret = FIN_CreateOTCDerivativesFromTemplate(instrTemplateArgStp, templateInstrStp, mainInstrStp, hierHead);
            break;

        /* PMSTA-34686 - DDV - 190219 */
        case InstrUsage_StructuredProductTemplate:
            ret = FIN_CreateStructuredProductFromTemplate(instrTemplateArgStp, templateInstrStp, mainInstrStp, hierHead);
            break;

        default:
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "Invalide usage_nat_e for template instrument", GET_CODE(templateInstrStp, A_Instr_Cd));
            ret = RET_GEN_ERR_INVARG;
            break;
	}

    if (createInstrInMasterFlg == TRUE)
    {
        SYS_SetThreadCurrBusinessEntity(initialBusinessEntity);
        SYS_SetThreadUseServerUser(false);
    }

	return ret;
}

/************************************************************************
**
**  Function    :   FIN_ACDCLifeTime()
**
**  Description :	Compute lifeTime for Accumulor/Decumulator STN
**
**                  If accumulator begin_d < current_date and current_date < end_d
**                  and current_date = settlement date and (knock-out date is null or knock-out date > current_date),
**                    Lifetime_part = (end_d � current_date / (end_d � begin_d)
**
**                  If accumulator begin_d < current_date and current_date < end_d
**                  and current_date <> settlement date and (knock-out date is null or knock-out date > current_date),
**					  Lifetime_part = (end_d � previous settlement date) / (end_d � begin_d)
**
**					If accumulator begin_d < current_date and current_date < end_d
**				    and knock-out date = current_date <> settlement date (with a protected date defined in the contract)
**					  Lifetime_part = (protected_d � previous settlement date) / (end_d � begin_d)
**					  If protected_d isn't defines, Lifetime_part = 0.
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-34140 - RAK - 190201
**
** Modification :	PMSTA-35010 - RAK - 190311 - New name as only called for ACDC
**					PMSTA-34854 - RAK - 190308 - Accumulator/Decumulator
**                  PMSTA-35133 - RAK - 190314
*************************************************************************/
NUMBER_T FIN_ACDCLifeTime(DBA_DYNFLD_STP instrPtr,  DATE_T valDate, DBA_DYNFLD_STP termEvtPtr)
{
	NUMBER_T	lifeTime=0.0;
	bool		debugFlg = false;

	if (IS_NULLFLD(termEvtPtr, A_TermEvt_BeginDate) ||
		IS_NULLFLD(termEvtPtr, A_TermEvt_EndDate))
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ACDCLifeTime term event begin and end date must be set", GET_CODE(instrPtr, A_Instr_Cd));
		return(0.0);
	}

	/* Compute lifetime */

	/* If accumulator begin_d > current_date : Lifetime_part = 1 */
	if (valDate < GET_DATE(termEvtPtr, A_TermEvt_BeginDate)) /* PMSTA-35133 - RAK - 190415 - Use TermEvt information */
	{
		lifeTime = 1.0;
	}
	else
	{
		DATE_T prevSettlementDate=0, settlementDate, endDate;
		long   endBeg, endSet;
		double freq = 0;

		/* Compute prevSettlementDate */
		/* Karthik: Quantity logic should be Total quantity (24000) * (end date - knock-in date)/ (end date - begin date) */
		/* since there is no previous settlement date. If there is no knock-in logic at all, then knock-in date should    */
		/* be replaced by begin date. This line was missed in the FDS, have added it now. */
		if (!IS_NULLFLD(instrPtr, A_Instr_FixDate))
			prevSettlementDate = GET_DATE(instrPtr, A_Instr_FixDate);
		else
			prevSettlementDate = GET_DATE(instrPtr, A_Instr_BeginDate); /* PMSTA-35638 - RAK - 190430 */

		if (prevSettlementDate == 0)
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ACDCLifeTime : missing first settlement date", GET_CODE(instrPtr, A_Instr_Cd));
			return(0.0); /* no risk decomposition */
		}

		/* First know the current settlement date and compute settlement current number */
		/* PMSTA-36022 - RAK - 190524 - PeriodUnitNbr could return SUCCEED and 0 frequency = high way to hell */
		if (FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
			                  GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq) == RET_SUCCEED && CMP_NUMBER(freq, 0.0) > 0)
		{
			settlementDate = prevSettlementDate;
			while (settlementDate <= valDate && settlementDate < GET_DATE(termEvtPtr, A_TermEvt_EndDate))
			{
				prevSettlementDate = settlementDate;
				settlementDate = DATE_Move(settlementDate, (int)freq, Month);
			}

			/* Not that test on knock-in knock-out and val date are done on call by FIN_STNKnockInStarted() and FIN_STNKnockOutExpired() */
			/* and accumulator begin_d < current_date and current_date < end_d  by std val process */

			/* If accumulator begin_d < current_date and current_date < end_d and      */
			/* current_date = settlement date and (knock - out date is null or         */
			/* knock - out date > current_date) :                                      */
			/* Lifetime_part = (end_d � current_date) / (end_d � begin_d)              */

			/* If accumulator begin_d < current_date and current_date < end_d and      */
			/* current_date <> settlement date and (knock - out date is null or        */
			/* knock - out date > current_date) :                                      */
			/* Lifetime_part = (end_d � previous settlement date*) / (end_d � begin_d) */

			/* PMSTA-35969 - RAK - 190521 */
			/* *If there is no previous settlement date, then use knock - in date (if available) */
			if (valDate < prevSettlementDate)
			{
				if (!IS_NULLFLD(instrPtr, A_Instr_KnockInDate))
				{
					prevSettlementDate = GET_DATE(instrPtr, A_Instr_KnockInDate);
				}
				/* PMSTA-35969 - RAK - 190520 */
				/* or begin date (if only knock - in date is not available and lower barrier is null or 0). */
				else if (IS_NULLFLD(termEvtPtr, A_TermEvt_LowerBarrierP) &&
					GET_ENUM(termEvtPtr, A_TermEvt_BarrierNatEn) == TermEvt_Barrier_None)
				{
					prevSettlementDate = GET_DATE(instrPtr, A_Instr_BeginDate);
				}
			}

			/* If accumulator begin_d < current_date and current_date < end_d and            */
			/* knock - out date = current_date <> settlement date (with a protected          */
			/* date defined in the contract) :                                               */
			/* Lifetime_part = (protected_d � previous settlement date*) / (end_d � begin_d) */
			if (GET_DATE(instrPtr, A_Instr_KnockOutDate) == valDate)
			{
				if (!IS_NULLFLD(termEvtPtr, A_TermEvt_ProtectedDate))
					endDate = GET_DATE(termEvtPtr, A_TermEvt_ProtectedDate);
				else
					return(lifeTime); /* 0.0 No risk decomposition */
			}
			else /* all others cases */
				endDate = GET_DATE(termEvtPtr, A_TermEvt_EndDate);

			/* PMSTA-35133 - RAK - 190426 - Use simcorp actual actual (isn't specify in the FDS anyway) */
			DATE_DaysBetween(endDate, prevSettlementDate, AccrRule_SceActAct, &endSet, 0);
			DATE_DaysBetween(GET_DATE(termEvtPtr, A_TermEvt_EndDate), GET_DATE(termEvtPtr, A_TermEvt_BeginDate), AccrRule_SceActAct, &endBeg, 0);

			if (debugFlg)
			{
				YEAR_T eyear, syear;
				MONTH_T emonth, smonth;
				DAY_T eday, sday;

				DATE_Get(endDate, &eyear, &emonth, &eday);
				DATE_Get(prevSettlementDate, &syear, &smonth, &sday);
				printf("\ndiff %02d/%02d/%04d -  %02d/%02d/%04d numerator %d end-begin %d", eday, emonth, eyear, sday, smonth, syear, endSet, endBeg);
			}

			lifeTime = (double)endSet / (double)endBeg;
		}
	}

	return(lifeTime);
}

/************************************************************************
**  Function    : FIN_LoadStructuredProduct()
**
**  Description : Load all data for structured product and store them into hierarchy
**
**  Arguments   : main instrument id
**
**
**  Return      : None
**
**  Creation    : PMSTA - 34378 - DDV - 190131
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_LoadStructuredProduct(DBA_DYNFLD_STP aInstrStp, DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE                 ret = RET_SUCCEED;
	MemoryPool               mp;

	const DBA_DYNST_ENUM *outputStLst[] = { &A_Instr,
											&A_InstrPrice,
											&A_InterCond ,
											&A_TermEvt,
											&A_InstrCompo };  /* PMSTA-34295 - sanand - 060319 */

	DBA_DYNFLD_STP        *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
	int                    rows[] = { 0,0,0,0,0,0 };
	int                    outputBlkNb = sizeof(outputStLst) / sizeof(outputStLst[0]);
	DbiConnectionHelper    dbiConnHelper;

	/* call Multiselect to load all data */
	dbiConnHelper.dbaMultiSelect(Instr, DBA_ROLE_STRUCTURED_PRODUCT, aInstrStp, outputStLst, data, rows);

	/* Store data into hierarchy */
	for (int i = 0; i < outputBlkNb; i++)
	{
		if ((ret = DBA_AddHierRecordList(hierHead, data[i], rows[i], *(outputStLst[i]), TRUE)) != RET_SUCCEED)
		{
			for (int j = 0; j < outputBlkNb; j++)
			{
				if (j >= i)
				{
					DBA_FreeDynStTab(data[j], rows[j], *(outputStLst[j]));
				}
				else
				{
					FREE(data[j]);
				}
			}
			return(ret);
		}
	}

    /*PMSTA-40535 -NRAO -Fix memory leaks*/
    for (int i = 0; i < outputBlkNb; i++)
    {
        FREE(data[i]);
    }

	return ret;
}


/************************************************************************
**
**  Function    :   FIN_STNKnockOutExpired()
**
**  Description :	If STN has the knock-out feature
**					(i.e. the lower or upper price is set and is not null or 0)
**					and knock-out date < current_date = settlement date and
**					(protected_d is null or protected_d < current_Date), STN is expired
**
**  Return      :  expiredFld
**
** Creation	    :   PMSTA-34140 - RAK - 190204
** Modification :   PMSTA-35133 - RAK - 190314
**
*************************************************************************/
FLAG_T FIN_STNKnockOutExpired(DATE_T crtDate, DBA_DYNFLD_STP termEvtPtr, DBA_DYNFLD_STP instrPtr)
{
	FLAG_T	expiredFlg = FALSE;
	/* PMSTA-34931 - RAK - 190327 - Last minute impact */
	/*if (!IS_NULLFLD(termEvtPtr, A_TermEvt_UpperBarrier) ||
		!IS_NULLFLD(termEvtPtr, A_TermEvt_Barrier))
	{*/
		if (!IS_NULLFLD(instrPtr, A_Instr_KnockOutDate) &&
			GET_DATE(instrPtr, A_Instr_KnockOutDate) < crtDate) /* expired */
		{
			expiredFlg = TRUE;
		}
	/*}*/

	return(expiredFlg);
}

/************************************************************************
**
**  Function    :   FIN_STNKnockInStarted()
**
**  Description :	If STN's knock-in levels (lower barrier) is not null or 0
**					and knock-in date is not available, then STN is not yet started
**
**  Return      :   startedFlg
**
** Creation	    :   PMSTA-34140 - RAK - 190204
** Modification :   PMSTA-35133 - RAK - 190314
**
*************************************************************************/
FLAG_T FIN_STNKnockInStarted(DATE_T crtDate, DBA_DYNFLD_STP termEvtPtr, DBA_DYNFLD_STP instrPtr)
{
	FLAG_T startedFlg = TRUE;

	/* PMSTA-35969 - RAK - 190520 - not yet started */
	if (GET_DATE(instrPtr, A_Instr_KnockInDate) > crtDate)
	{
		startedFlg = FALSE;
	}

	/* PMSTA-35969 - RAK - 190520 -  knock-in date not available in main instrument and also no lower barrier provided then the contract is knocked in */
	if (IS_NULLFLD(instrPtr, A_Instr_KnockInDate))
	{
		if (!IS_NULLFLD(termEvtPtr, A_TermEvt_LowerBarrierP) &&
			GET_ENUM(termEvtPtr, A_TermEvt_BarrierNatEn) != TermEvt_Barrier_None)
		{
			startedFlg = FALSE;
		}
	}

	return(startedFlg);
}


/************************************************************************
**      END  fininstr.c
*************************************************************************/

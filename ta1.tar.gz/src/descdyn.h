/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DESCDYN_H
#define DESCDYN_H

/* Disable message 956 031008 - PMO */
/*lint -save -e(956) */

/* Special entities */
extern FIELD_IDX_T Null_Dynfld;

extern FIELD_IDX_T A_AccPer_Id                             ;
extern FIELD_IDX_T A_AccPer_Cd                             ;
extern FIELD_IDX_T A_AccPer_Name                           ;
extern FIELD_IDX_T A_AccPer_PtfId                          ;
extern FIELD_IDX_T A_AccPer_AccPlanId                      ;
extern FIELD_IDX_T A_AccPer_BegDate                        ;
extern FIELD_IDX_T A_AccPer_EndDate                        ;
extern FIELD_IDX_T A_AccPer_ClosingDate                    ;
extern FIELD_IDX_T A_AccPer_FinalClosingFlg                ;

extern FIELD_IDX_T S_AccPer_Id                             ;
extern FIELD_IDX_T S_AccPer_Cd                             ;
extern FIELD_IDX_T S_AccPer_Name                           ;
extern FIELD_IDX_T S_AccPer_PtfId                          ;
extern FIELD_IDX_T S_AccPer_AccPlanId                      ;
extern FIELD_IDX_T S_AccPer_AccPlanCd                      ;
extern FIELD_IDX_T S_AccPer_BegDate                        ;
extern FIELD_IDX_T S_AccPer_FinalClosingFlg                ;

extern FIELD_IDX_T A_AccPerParam_Id                        ;
extern FIELD_IDX_T A_AccPerParam_DataTpEntDictId           ;
extern FIELD_IDX_T A_AccPerParam_AccPerId                  ;
extern FIELD_IDX_T A_AccPerParam_ValidityDate              ;
extern FIELD_IDX_T A_AccPerParam_NatEn                     ;
extern FIELD_IDX_T A_AccPerParam_Val                       ;
extern FIELD_IDX_T A_AccPerParam_ValText                   ;
extern FIELD_IDX_T A_AccPerParam_ValDate                   ;
extern FIELD_IDX_T A_AccPerParam_RoundUnit                 ;
extern FIELD_IDX_T A_AccPerParam_RoundRuleEn               ;
extern FIELD_IDX_T A_AccPerParam_UpdFlg                    ;


extern FIELD_IDX_T S_AccPerParam_Id                        ;
extern FIELD_IDX_T S_AccPerParam_DataTpEntDictId           ;
extern FIELD_IDX_T S_AccPerParam_AccPerId                  ;
extern FIELD_IDX_T S_AccPerParam_ValidityDate              ;
extern FIELD_IDX_T S_AccPerParam_NatEn                     ;
extern FIELD_IDX_T S_AccPerParam_Val                       ;
extern FIELD_IDX_T S_AccPerParam_ValText                   ;
extern FIELD_IDX_T S_AccPerParam_ValDate                   ;
extern FIELD_IDX_T S_AccPerParam_UpdFlg                    ;
extern FIELD_IDX_T S_AccPerParam_RoundUnit                 ;


extern FIELD_IDX_T A_AccPlan_Id                            ;
extern FIELD_IDX_T A_AccPlan_Cd                            ;
extern FIELD_IDX_T A_AccPlan_ParPtfId                      ;


extern FIELD_IDX_T S_AccPlan_Id                            ;
extern FIELD_IDX_T S_AccPlan_Cd                            ;


extern FIELD_IDX_T A_AccPlanElt_Id                         ;
extern FIELD_IDX_T A_AccPlanElt_Name                       ;
extern FIELD_IDX_T A_AccPlanElt_Denom                      ;
extern FIELD_IDX_T A_AccPlanElt_AccPerId                   ;
extern FIELD_IDX_T A_AccPlanElt_InstrId                    ;
extern FIELD_IDX_T A_AccPlanElt_AccNbr                     ;
extern FIELD_IDX_T A_AccPlanElt_Rank                       ;
extern FIELD_IDX_T A_AccPlanElt_NatEn                      ;
extern FIELD_IDX_T A_AccPlanElt_DataNatEn                  ;
extern FIELD_IDX_T A_AccPlanElt_DispNatEn                  ;
extern FIELD_IDX_T A_AccPlanElt_InvDataSignFlg             ;
extern FIELD_IDX_T A_AccPlanElt_DispQuantFlg               ;
extern FIELD_IDX_T A_AccPlanElt_ClassifFlg                 ;
extern FIELD_IDX_T A_AccPlanElt_DataSrcEn                  ;
extern FIELD_IDX_T A_AccPlanElt_ItemDisp                   ;
extern FIELD_IDX_T A_AccPlanElt_ItemNatEn                  ;
extern FIELD_IDX_T A_AccPlanElt_ScptDef                    ;
extern FIELD_IDX_T A_AccPlanElt_A_FundValElt_Ext           ;


extern FIELD_IDX_T S_AccPlanElt_Id                         ;
extern FIELD_IDX_T S_AccPlanElt_Name                       ;
extern FIELD_IDX_T S_AccPlanElt_AccPerId                   ;
extern FIELD_IDX_T S_AccPlanElt_AccNbr                     ;
extern FIELD_IDX_T S_AccPlanElt_Rank                       ;
extern FIELD_IDX_T S_AccPlanElt_NatEn                      ;

/*< PMSTA00488 - EFE -061101*/

extern FIELD_IDX_T A_AccProfile_Id                         ;
extern FIELD_IDX_T A_AccProfile_Cd                         ;
extern FIELD_IDX_T A_AccProfile_Remark                     ;
extern FIELD_IDX_T A_AccProfile_NatureEn                   ;
extern FIELD_IDX_T A_AccProfile_ClassifId                  ;

extern FIELD_IDX_T S_AccProfile_Id                         ;
extern FIELD_IDX_T S_AccProfile_Cd                         ;
extern FIELD_IDX_T S_AccProfile_NatureEn                   ;
extern FIELD_IDX_T S_AccProfile_ClassifId                  ;
extern FIELD_IDX_T S_AccProfile_ClassifCd                  ;

extern FIELD_IDX_T A_AccProfileCompo_Id                    ;
extern FIELD_IDX_T A_AccProfileCompo_AccProfileId          ;
extern FIELD_IDX_T A_AccProfileCompo_NatureEn              ;
extern FIELD_IDX_T A_AccProfileCompo_FusRuleEn             ;
extern FIELD_IDX_T A_AccProfileCompo_InstrId               ;
extern FIELD_IDX_T A_AccProfileCompo_InstrNatEn            ;
extern FIELD_IDX_T A_AccProfileCompo_InstrTypeId           ;
extern FIELD_IDX_T A_AccProfileCompo_InstrSubtypeId        ;
extern FIELD_IDX_T A_AccProfileCompo_BegDate               ;
extern FIELD_IDX_T A_AccProfileCompo_EndDate               ;

extern FIELD_IDX_T S_AccProfileCompo_Id                    ;
extern FIELD_IDX_T S_AccProfileCompo_AccProfileId          ;
extern FIELD_IDX_T S_AccProfileCompo_NatureEn              ;
extern FIELD_IDX_T S_AccProfileCompo_FusRuleEn             ;
extern FIELD_IDX_T S_AccProfileCompo_InstrId               ;
extern FIELD_IDX_T S_AccProfileCompo_InstrNatEn            ;
extern FIELD_IDX_T S_AccProfileCompo_InstrTypeId           ;
extern FIELD_IDX_T S_AccProfileCompo_InstrSubtypeId        ;
extern FIELD_IDX_T S_AccProfileCompo_BegDate               ;
extern FIELD_IDX_T S_AccProfileCompo_InstrCd               ;
extern FIELD_IDX_T S_AccProfileCompo_TypeCd                ;
extern FIELD_IDX_T S_AccProfileCompo_SubtypeCd             ;


extern FIELD_IDX_T A_AccProfileHisto_PtfId                 ;
extern FIELD_IDX_T A_AccProfileHisto_AccProfileId          ;
extern FIELD_IDX_T A_AccProfileHisto_BegDate               ;
extern FIELD_IDX_T A_AccProfileHisto_EndDate               ;

extern FIELD_IDX_T S_AccProfileHisto_PtfId                 ;
extern FIELD_IDX_T S_AccProfileHisto_AccProfileId          ;
extern FIELD_IDX_T S_AccProfileHisto_BegDate               ;
extern FIELD_IDX_T S_AccProfileHisto_EndDate               ;
extern FIELD_IDX_T S_AccProfileHisto_AccCode               ;


extern FIELD_IDX_T A_AdminMgr_Id                           ;


extern FIELD_IDX_T A_ApplMsg_Id                            ;
extern FIELD_IDX_T A_ApplMsg_Cd                            ;
extern FIELD_IDX_T A_ApplMsg_Denom                         ;
extern FIELD_IDX_T A_ApplMsg_NatEn                         ;


extern FIELD_IDX_T S_ApplMsg_Id                            ;
extern FIELD_IDX_T S_ApplMsg_Cd                            ;
extern FIELD_IDX_T S_ApplMsg_Denom                         ;
extern FIELD_IDX_T S_ApplMsg_NatEn                         ;


extern FIELD_IDX_T A_ApplMsgTxt_MsgId                      ;
extern FIELD_IDX_T A_ApplMsgTxt_LangDictId                 ;
extern FIELD_IDX_T A_ApplMsgTxt_LastUserId                 ;            /*  HFI-PMSTA-28976-180228  */
extern FIELD_IDX_T A_ApplMsgTxt_LastModifDate              ;            /*  HFI-PMSTA-28976-180228  */
extern FIELD_IDX_T A_ApplMsgTxt_MsgTxt                     ;


extern FIELD_IDX_T S_ApplMsgTxt_MsgId                      ;
extern FIELD_IDX_T S_ApplMsgTxt_LangDictId                 ;
extern FIELD_IDX_T S_ApplMsgTxt_MsgTxt                     ;
extern FIELD_IDX_T S_ApplMsgTxt_MsgCd                      ;
extern FIELD_IDX_T S_ApplMsgTxt_LangName                   ;


extern FIELD_IDX_T A_ApplPswdHist_Id                       ;
extern FIELD_IDX_T A_ApplPswdHist_UserId                   ;
extern FIELD_IDX_T A_ApplPswdHist_CreationDate             ;
extern FIELD_IDX_T A_ApplPswdHist_CryptedPswd              ;
extern FIELD_IDX_T A_ApplPswdHist_DataSecuProfId           ; /* PMSTA-22305- DDV - 160509 */


extern FIELD_IDX_T A_ApplRule_Id                           ;
extern FIELD_IDX_T A_ApplRule_Cd                           ;
extern FIELD_IDX_T A_ApplRule_Denom                        ;
extern FIELD_IDX_T A_ApplRule_EntDictId                    ;


extern FIELD_IDX_T S_ApplRule_Id                           ;
extern FIELD_IDX_T S_ApplRule_Cd                           ;
extern FIELD_IDX_T S_ApplRule_Denom                        ;



/* PMSTA-18426 - CHU - 140922 */
extern FIELD_IDX_T A_ExtServiceCompo_Id                    ;
extern FIELD_IDX_T A_ExtServiceCompo_ExtServiceId          ;
extern FIELD_IDX_T A_ExtServiceCompo_Rank                  ;
extern FIELD_IDX_T A_ExtServiceCompo_DirectionEn           ;
extern FIELD_IDX_T A_ExtServiceCompo_SrcEntityDictId       ;
extern FIELD_IDX_T A_ExtServiceCompo_DestEntityDictId      ;
extern FIELD_IDX_T A_ExtServiceCompo_FormatId              ;
extern FIELD_IDX_T A_ExtServiceCompo_ScreenDictId          ;

/* PMSTA-18426 - CHU - 140922 */
extern FIELD_IDX_T S_ExtServiceCompo_Id                    ;
extern FIELD_IDX_T S_ExtServiceCompo_ExtServiceId          ;
extern FIELD_IDX_T S_ExtServiceCompo_ExtServiceCd          ;
extern FIELD_IDX_T S_ExtServiceCompo_Rank                  ;
extern FIELD_IDX_T S_ExtServiceCompo_DirectionEn           ;
extern FIELD_IDX_T S_ExtServiceCompo_SrcEntityDictId       ;
extern FIELD_IDX_T S_ExtServiceCompo_SrcEntityCd           ;
extern FIELD_IDX_T S_ExtServiceCompo_DestEntityDictId      ;
extern FIELD_IDX_T S_ExtServiceCompo_DestEntityCd          ;
extern FIELD_IDX_T S_ExtServiceCompo_FormatId              ;
extern FIELD_IDX_T S_ExtServiceCompo_FormatCd              ;
extern FIELD_IDX_T S_ExtServiceCompo_ScreenDictId          ;
extern FIELD_IDX_T S_ExtServiceCompo_ScreenCd              ;

/*  HFI-PMSTA-22496-160502  */
extern FIELD_IDX_T A_ExtServiceProf_Id                     ;
extern FIELD_IDX_T A_ExtServiceProf_Cd                     ;
extern FIELD_IDX_T A_ExtServiceProf_LastUserId             ;
extern FIELD_IDX_T A_ExtServiceProf_LastModifDate          ;

/*  HFI-PMSTA-22496-160502  */
extern FIELD_IDX_T S_ExtServiceProf_Id                     ;
extern FIELD_IDX_T S_ExtServiceProf_Cd                     ;

/*  HFI-PMSTA-22496-160502  */
extern FIELD_IDX_T A_ExtServiceProfCompo_Id                ;
extern FIELD_IDX_T A_ExtServiceProfCompo_ProfileId         ;
extern FIELD_IDX_T A_ExtServiceProfCompo_ExtServId         ;
extern FIELD_IDX_T A_ExtServiceProfCompo_NatureEn          ;
extern FIELD_IDX_T A_ExtServiceProfCompo_FctDictId         ;
extern FIELD_IDX_T A_ExtServiceProfCompo_RankN             ;
extern FIELD_IDX_T A_ExtServiceProfCompo_LastUserId        ;
extern FIELD_IDX_T A_ExtServiceProfCompo_LastModifDate     ;

/*  HFI-PMSTA-22496-160502  */
extern FIELD_IDX_T S_ExtServiceProfCompo_Id                ;
extern FIELD_IDX_T S_ExtServiceProfCompo_ProfileId         ;
extern FIELD_IDX_T S_ExtServiceProfCompo_ExtServId         ;
extern FIELD_IDX_T S_ExtServiceProfCompo_NatureEn          ;
extern FIELD_IDX_T S_ExtServiceProfCompo_FctDictId         ;
extern FIELD_IDX_T S_ExtServiceProfCompo_ProfileCd         ;
extern FIELD_IDX_T S_ExtServiceProfCompo_ExtServCd         ;
extern FIELD_IDX_T S_ExtServiceProfCompo_FctName           ;

/* < REF11767 - CHU - 060331 */
extern FIELD_IDX_T A_OptiProf_Id                           ;
extern FIELD_IDX_T A_OptiProf_Cd                           ;
extern FIELD_IDX_T A_OptiProf_Denom                        ;

extern FIELD_IDX_T S_OptiProf_Id                           ;
extern FIELD_IDX_T S_OptiProf_Cd                           ;

extern FIELD_IDX_T A_OptiProfCompo_Id                      ;
extern FIELD_IDX_T A_OptiProfCompo_OptiProfId              ;
extern FIELD_IDX_T A_OptiProfCompo_ProcId                  ;
extern FIELD_IDX_T A_OptiProfCompo_GlobalAlloc             ;
extern FIELD_IDX_T A_OptiProfCompo_GlobalMaxAlloc          ;
extern FIELD_IDX_T A_OptiProfCompo_LocalAlloc              ;
extern FIELD_IDX_T A_OptiProfCompo_LocalMaxAlloc           ;
extern FIELD_IDX_T A_OptiProfCompo_Remark                  ;
extern FIELD_IDX_T A_OptiProfCompo_EntityDictId            ;
extern FIELD_IDX_T A_OptiProfCompo_ProcSqlName             ;

extern FIELD_IDX_T S_OptiProfCompo_Id                      ;
extern FIELD_IDX_T S_OptiProfCompo_OptiProfId              ;
extern FIELD_IDX_T S_OptiProfCompo_ProcId                  ;
extern FIELD_IDX_T S_OptiProfCompo_EntityDictId            ;
extern FIELD_IDX_T S_OptiProfCompo_ProcSqlName             ;
extern FIELD_IDX_T S_OptiProfCompo_EntitySqlName           ;

extern FIELD_IDX_T A_OptiProc_Id                           ;
extern FIELD_IDX_T A_OptiProc_SqlName                      ;
extern FIELD_IDX_T A_OptiProc_EntityDictId                 ;

extern FIELD_IDX_T S_OptiProc_Id                           ;
extern FIELD_IDX_T S_OptiProc_SqlName                      ;
extern FIELD_IDX_T S_OptiProc_EntityDictId                 ;
extern FIELD_IDX_T S_OptiProc_EntitySqlName                ;
/* > REF11767 - CHU - 060331 */

extern FIELD_IDX_T A_ApplComment_Id                        ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_EntityDictId              ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_ObjectId                  ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_CreationDate              ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_LastUserId                ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_LastModifDate             ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_TypeId                    ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_LanguageDictId            ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_Comment                   ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T A_ApplComment_SelectedEn                ; /*PMSTA10733-TEB-101130*/

extern FIELD_IDX_T S_ApplComment_Id                        ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T S_ApplComment_EntityDictId              ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T S_ApplComment_ObjectId                  ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T S_ApplComment_CreationDate              ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T S_ApplComment_TypeId                    ; /*PMSTA10733-TEB-101130*/
extern FIELD_IDX_T S_ApplComment_LanguageDictId            ; /*PMSTA10733-TEB-101130*/


extern FIELD_IDX_T A_Archive_Id                            ;
extern FIELD_IDX_T A_Archive_ArcEntDictId                  ;
extern FIELD_IDX_T A_Archive_EntDictId                     ;
extern FIELD_IDX_T A_Archive_DimEntDictId                  ;
extern FIELD_IDX_T A_Archive_ObjectId                      ;
extern FIELD_IDX_T A_Archive_Date                          ;
extern FIELD_IDX_T A_Archive_Nature                        ;
extern FIELD_IDX_T A_Archive_AllFlg                        ;
extern FIELD_IDX_T A_Archive_FileName                      ;
extern FIELD_IDX_T A_Archive_ArcEnt_cd                     ;
extern FIELD_IDX_T A_Archive_Ent_cd                        ;
extern FIELD_IDX_T A_Archive_DimEnt_cd                     ;
extern FIELD_IDX_T A_Archive_Object_cd                     ;
extern FIELD_IDX_T A_Archive_Nature_cd                     ;
extern FIELD_IDX_T A_Archive_ReturnStatus                  ;

extern FIELD_IDX_T S_Archive_Id                            ;
extern FIELD_IDX_T S_Archive_ArcEntDictId                  ;
extern FIELD_IDX_T S_Archive_EntDictId                     ;
extern FIELD_IDX_T S_Archive_DimEntDictId                  ;
extern FIELD_IDX_T S_Archive_ObjectId                      ;
extern FIELD_IDX_T S_Archive_Date                          ;
extern FIELD_IDX_T S_Archive_Nature                        ;
extern FIELD_IDX_T S_Archive_AllFlg                        ;
extern FIELD_IDX_T S_Archive_FileName                      ;
extern FIELD_IDX_T S_Archive_Object_cd                     ;


extern FIELD_IDX_T A_Audit_Hostname                        ;
extern FIELD_IDX_T A_Audit_User                            ;
extern FIELD_IDX_T A_Audit_EntityDictId                    ;
extern FIELD_IDX_T A_Audit_FctDictId                       ;
extern FIELD_IDX_T A_Audit_ActionEn                        ;
extern FIELD_IDX_T A_Audit_ModuleEn                        ;
extern FIELD_IDX_T A_Audit_CreationDate                    ;
extern FIELD_IDX_T A_Audit_MapId                           ;
extern FIELD_IDX_T A_Audit_EntityNatEn                     ;
extern FIELD_IDX_T A_Audit_Data                            ;


extern FIELD_IDX_T A_BalPos_Id                             ;
extern FIELD_IDX_T A_BalPos_PtfId                          ;
extern FIELD_IDX_T A_BalPos_PtfPosSetId                    ;
extern FIELD_IDX_T A_BalPos_InstrId                        ;
extern FIELD_IDX_T A_BalPos_BalPosTpId                     ;
extern FIELD_IDX_T A_BalPos_PosCurrId                      ;
extern FIELD_IDX_T A_BalPos_InstrCurrId                    ;
extern FIELD_IDX_T A_BalPos_PtfCurrId                      ;
extern FIELD_IDX_T A_BalPos_OpenOpId                       ;
extern FIELD_IDX_T A_BalPos_CloseOpId                      ;
extern FIELD_IDX_T A_BalPos_TermTpId                       ;
extern FIELD_IDX_T A_BalPos_LockTpId                       ;
extern FIELD_IDX_T A_BalPos_OpenOpNatEn                    ;
extern FIELD_IDX_T A_BalPos_AdjustNatEn                    ;
extern FIELD_IDX_T A_BalPos_OpenOpCd                       ;
extern FIELD_IDX_T A_BalPos_CloseOpCd                      ;
extern FIELD_IDX_T A_BalPos_RefOpCd                        ;
extern FIELD_IDX_T A_BalPos_RefNatEn                       ;
extern FIELD_IDX_T A_BalPos_ExecOpCd                       ;
extern FIELD_IDX_T A_BalPos_ExecOpNatEn                    ;
extern FIELD_IDX_T A_BalPos_ExecOpStatEn                   ;
extern FIELD_IDX_T A_BalPos_RevOpCd                        ;
extern FIELD_IDX_T A_BalPos_RevOpNatEn                     ;
extern FIELD_IDX_T A_BalPos_EventCd                        ;
extern FIELD_IDX_T A_BalPos_EventNbr                       ;
extern FIELD_IDX_T A_BalPos_StatEn                         ;
extern FIELD_IDX_T A_BalPos_PrimaryEn                      ;
extern FIELD_IDX_T A_BalPos_MainFlag                       ;
extern FIELD_IDX_T A_BalPos_PosNatEn                       ;
extern FIELD_IDX_T A_BalPos_Fus                            ;
extern FIELD_IDX_T A_BalPos_FusRuleEn                      ;
extern FIELD_IDX_T A_BalPos_BegDate                        ;
extern FIELD_IDX_T A_BalPos_EndDate                        ;
extern FIELD_IDX_T A_BalPos_OpDate                         ;
extern FIELD_IDX_T A_BalPos_AcctDate                       ;
extern FIELD_IDX_T A_BalPos_ValDate                        ;
extern FIELD_IDX_T A_BalPos_Remark                         ;
extern FIELD_IDX_T A_BalPos_PosExchRate                    ;
extern FIELD_IDX_T A_BalPos_InstrExchRate                  ;
extern FIELD_IDX_T A_BalPos_SysExchRate                    ;
extern FIELD_IDX_T A_BalPos_Qty                            ;
extern FIELD_IDX_T A_BalPos_Price                          ;
extern FIELD_IDX_T A_BalPos_PosGrossAmt                    ;
extern FIELD_IDX_T A_BalPos_PosNetAmt                      ;
extern FIELD_IDX_T A_BalPos_InstrGrossAmt                  ;
extern FIELD_IDX_T A_BalPos_InstrNetAmt                    ;
extern FIELD_IDX_T A_BalPos_PtfGrossAmt                    ;
extern FIELD_IDX_T A_BalPos_PtfNetAmt                      ;
extern FIELD_IDX_T A_BalPos_SysGrossAmt                    ;
extern FIELD_IDX_T A_BalPos_SysNetAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp1PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp2PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp3PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp4PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp5PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp6PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp7PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp8PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp9PosAmt                      ;
extern FIELD_IDX_T A_BalPos_Bp10PosAmt                     ;
extern FIELD_IDX_T A_BalPos_TimingRuleEn                   ;

extern FIELD_IDX_T S_BalPos_Id                             ;


extern FIELD_IDX_T A_BalPosRule_Id                         ;
extern FIELD_IDX_T A_BalPosRule_SetId                      ;
extern FIELD_IDX_T A_BalPosRule_BpTpId                     ;
extern FIELD_IDX_T A_BalPosRule_OpTpId                     ;
extern FIELD_IDX_T A_BalPosRule_Rank                       ;


extern FIELD_IDX_T S_BalPosRule_Id                         ;
extern FIELD_IDX_T S_BalPosRule_BpTpCd                     ;
extern FIELD_IDX_T S_BalPosRule_OpTpCd                     ;


extern FIELD_IDX_T A_BalPosRuleSet_Id                      ;
extern FIELD_IDX_T A_BalPosRuleSet_Cd                      ;
extern FIELD_IDX_T A_BalPosRuleSet_Name                    ;
extern FIELD_IDX_T A_BalPosRuleSet_Denom                   ;
extern FIELD_IDX_T A_BalPosRuleSet_DfltFlg                 ;


extern FIELD_IDX_T S_BalPosRuleSet_Id                      ;
extern FIELD_IDX_T S_BalPosRuleSet_Cd                      ;
extern FIELD_IDX_T S_BalPosRuleSet_Name                    ;


extern FIELD_IDX_T A_BalPosTp_Id                           ;
extern FIELD_IDX_T A_BalPosTp_Cd                           ;
extern FIELD_IDX_T A_BalPosTp_Name                         ;
extern FIELD_IDX_T A_BalPosTp_Denom                        ;
extern FIELD_IDX_T A_BalPosTp_NatEn                        ;
extern FIELD_IDX_T A_BalPosTp_Rank                         ;
extern FIELD_IDX_T A_BalPosTp_ParentBpTypeId               ; /* WEALTH-5030 - CHANDRU - 05022024 */


extern FIELD_IDX_T S_BalPosTp_Id                           ;
extern FIELD_IDX_T S_BalPosTp_Cd                           ;
extern FIELD_IDX_T S_BalPosTp_NatEn                        ;
extern FIELD_IDX_T S_BalPosTp_Rank                         ;


extern FIELD_IDX_T A_ObjectLnk_Id                          ; /* REF9770 - LJE - 031217 */
extern FIELD_IDX_T A_ObjectLnk_Nature                      ;
extern FIELD_IDX_T A_ObjectLnk_Rank                        ;
extern FIELD_IDX_T A_ObjectLnk_FromEntDictId               ;
extern FIELD_IDX_T A_ObjectLnk_FromObjectId                ;
extern FIELD_IDX_T A_ObjectLnk_FromBreakCriteria           ; /* REF9264 - LJE - 030630 */
extern FIELD_IDX_T A_ObjectLnk_ToEntDictId                 ;
extern FIELD_IDX_T A_ObjectLnk_ToObjectId                  ;
extern FIELD_IDX_T A_ObjectLnk_ToBreakCriteria             ; /* REF9264 - LJE - 030630 */
extern FIELD_IDX_T A_ObjectLnk_BeginDate                   ;
extern FIELD_IDX_T A_ObjectLnk_EndDate                     ;
extern FIELD_IDX_T A_ObjectLnk_MinOnLineDate               ; /* REF9340 - DDV - 030820 */
extern FIELD_IDX_T A_ObjectLnk_MaxOnLineDate               ; /* REF9340 - DDV - 030820 */

extern FIELD_IDX_T A_BookValue_PtfNetAmt                   ;
extern FIELD_IDX_T A_BookValue_OpNetAmt                    ;
extern FIELD_IDX_T A_BookValue_InstrNetAmt                 ;
extern FIELD_IDX_T A_BookValue_SysNetAmt                   ;
extern FIELD_IDX_T A_BookValue_OpExchRate                  ;
extern FIELD_IDX_T A_BookValue_InstrExchRate               ;
extern FIELD_IDX_T A_BookValue_SysExchRate                 ;
extern FIELD_IDX_T A_BookValue_Price                       ;
extern FIELD_IDX_T A_BookValue_Quote                       ;
extern FIELD_IDX_T A_BookValue_ValRuleEltId                ;
extern FIELD_IDX_T A_BookValue_EvalRuleEn                  ;
extern FIELD_IDX_T A_BookValue_MaxConstrEn                 ;
extern FIELD_IDX_T A_BookValue_ValRuleId                   ;
extern FIELD_IDX_T A_BookValue_ValRuleHistId               ;


extern FIELD_IDX_T A_Calendar_Id                           ;
extern FIELD_IDX_T A_Calendar_Cd                           ;
extern FIELD_IDX_T A_Calendar_Name                         ;
extern FIELD_IDX_T A_Calendar_Denom                        ;
extern FIELD_IDX_T A_Calendar_BusinessDateRuleEn           ;
extern FIELD_IDX_T A_Calendar_NextBusinessDateRuleEn       ;
extern FIELD_IDX_T A_Calendar_AddDaysNum                   ;


extern FIELD_IDX_T S_Calendar_Id                           ;
extern FIELD_IDX_T S_Calendar_Cd                           ;
extern FIELD_IDX_T S_Calendar_Name                         ;


extern FIELD_IDX_T A_CalendarDate_Id                       ;
extern FIELD_IDX_T A_CalendarDate_CalendarId               ;
extern FIELD_IDX_T A_CalendarDate_Date                     ;
extern FIELD_IDX_T A_CalendarDate_Denom                    ;
extern FIELD_IDX_T A_CalendarDate_NatEn                    ;


extern FIELD_IDX_T S_CalendarDate_Id                       ;
extern FIELD_IDX_T S_CalendarDate_CalendarId               ;
extern FIELD_IDX_T S_CalendarDate_Date                     ;
extern FIELD_IDX_T S_CalendarDate_NatEn                    ;


extern FIELD_IDX_T A_CalendarConv_Id                       ;
extern FIELD_IDX_T A_CalendarConv_CalendarId               ;
extern FIELD_IDX_T A_CalendarConv_Term                     ;
extern FIELD_IDX_T A_CalendarConv_WeekdayEn                ;
extern FIELD_IDX_T A_CalendarConv_Day                      ;
extern FIELD_IDX_T A_CalendarConv_AnchorDayEn              ;
extern FIELD_IDX_T A_CalendarConv_Denom                    ;
extern FIELD_IDX_T A_CalendarConv_NatEn                    ;
extern FIELD_IDX_T A_CalendarConv_OffsetSaturdayEn         ;
extern FIELD_IDX_T A_CalendarConv_OffsetSundayEn           ;


extern FIELD_IDX_T S_CalendarConv_Id                       ;
extern FIELD_IDX_T S_CalendarConv_CalendarId               ;
extern FIELD_IDX_T S_CalendarConv_Term                     ;
extern FIELD_IDX_T S_CalendarConv_WeekdayEn                ;
extern FIELD_IDX_T S_CalendarConv_Day                      ;
extern FIELD_IDX_T S_CalendarConv_AnchorDayEn              ;
extern FIELD_IDX_T S_CalendarConv_Denom                    ;
extern FIELD_IDX_T S_CalendarConv_NatEn                    ;
extern FIELD_IDX_T S_CalendarConv_CalendarCd               ;


extern FIELD_IDX_T A_CaseClarification_Id                  ;
extern FIELD_IDX_T A_CaseClarification_Cd                  ;
extern FIELD_IDX_T A_CaseClarification_CaseId              ;
extern FIELD_IDX_T A_CaseClarification_Reason              ;
extern FIELD_IDX_T A_CaseClarification_LastUserId          ;
extern FIELD_IDX_T A_CaseClarification_LastModifDate       ;
extern FIELD_IDX_T A_CaseClarification_TpId                ;
extern FIELD_IDX_T A_CaseClarification_OldCaseId           ;

extern FIELD_IDX_T S_CaseClarification_Id                  ;
extern FIELD_IDX_T S_CaseClarification_Cd                  ;
extern FIELD_IDX_T S_CaseClarification_CaseId              ;
extern FIELD_IDX_T S_CaseClarification_Reason              ;
extern FIELD_IDX_T S_CaseClarification_LastUserId          ;
extern FIELD_IDX_T S_CaseClarification_LastModifDate       ;
extern FIELD_IDX_T S_CaseClarification_TpId                ;

extern FIELD_IDX_T A_CaseLink_Id                           ;
extern FIELD_IDX_T A_CaseLink_CaseId                       ;
extern FIELD_IDX_T A_CaseLink_EntDictId                    ;
extern FIELD_IDX_T A_CaseLink_ObjId                        ;
extern FIELD_IDX_T A_CaseLink_OldCaseId                    ;

extern FIELD_IDX_T S_CaseLink_Id                           ;
extern FIELD_IDX_T S_CaseLink_CaseId                       ;
extern FIELD_IDX_T S_CaseLink_EntDictId                    ;
extern FIELD_IDX_T S_CaseLink_ObjId                        ;

extern FIELD_IDX_T A_CaseMsgTemplate_Id                    ;
extern FIELD_IDX_T A_CaseMsgTemplate_Cd                    ;
extern FIELD_IDX_T A_CaseMsgTemplate_Denom                 ;
extern FIELD_IDX_T A_CaseMsgTemplate_CaseNatEn             ;
extern FIELD_IDX_T A_CaseMsgTemplate_CaseSubNatEn          ;
extern FIELD_IDX_T A_CaseMsgTemplate_CaseTpId              ;
extern FIELD_IDX_T A_CaseMsgTemplate_Priority              ;
extern FIELD_IDX_T A_CaseMsgTemplate_MainEntDictId         ;
extern FIELD_IDX_T A_CaseMsgTemplate_DefaultLanguage       ;
extern FIELD_IDX_T A_CaseMsgTemplate_LastUserId            ;
extern FIELD_IDX_T A_CaseMsgTemplate_LastModifDate         ;

extern FIELD_IDX_T S_CaseMsgTemplate_Id                    ;
extern FIELD_IDX_T S_CaseMsgTemplate_Cd                    ;
extern FIELD_IDX_T S_CaseMsgTemplate_Denom                 ;
extern FIELD_IDX_T S_CaseMsgTemplate_CaseNatEn             ;
extern FIELD_IDX_T S_CaseMsgTemplate_CaseSubNatEn          ;
extern FIELD_IDX_T S_CaseMsgTemplate_CaseTpId              ;
extern FIELD_IDX_T S_CaseMsgTemplate_Priority              ;

/* PMSTA07121-DDV-081212 */
extern FIELD_IDX_T A_CaseMsgTemplateDef_Id                 ;
extern FIELD_IDX_T A_CaseMsgTemplateDef_TemplateId         ;
extern FIELD_IDX_T A_CaseMsgTemplateDef_LangDictId         ;
extern FIELD_IDX_T A_CaseMsgTemplateDef_MainEntDictId      ;

extern FIELD_IDX_T S_CaseMsgTemplateDef_Id                 ;
extern FIELD_IDX_T S_CaseMsgTemplateDef_TemplateId         ;
extern FIELD_IDX_T S_CaseMsgTemplateDef_LangDictId         ;
extern FIELD_IDX_T S_CaseMsgTemplateDef_TemplateCd         ;
extern FIELD_IDX_T S_CaseMsgTemplateDef_LanguageName       ;

/*<PMSTA- 18760 -cashwini-140205 */
extern FIELD_IDX_T A_CaseRule_Id							;
extern FIELD_IDX_T A_CaseRule_Cd							;
extern FIELD_IDX_T A_CaseRule_Name							;
extern FIELD_IDX_T A_CaseRule_Denom						    ;
extern FIELD_IDX_T A_CaseRule_FunctionDictId                ;
extern FIELD_IDX_T A_CaseRule_EntityDictId                  ;
extern FIELD_IDX_T A_CaseRule_ActiveFlag                    ;

extern FIELD_IDX_T S_CaseRule_Id							;
extern FIELD_IDX_T S_CaseRule_Cd							;
extern FIELD_IDX_T S_CaseRule_Name							;
/*>PMSTA- 18760 -cashwini-140205 */

/* cashwini-PMSTA-21045-150818 */
extern FIELD_IDX_T A_LombardCheck_Id                        ;
extern FIELD_IDX_T A_LombardCheck_FunctionResultId          ;
extern FIELD_IDX_T A_LombardCheck_PtfId                     ;
extern FIELD_IDX_T A_LombardCheck_ThirdId                   ;
extern FIELD_IDX_T A_LombardCheck_CurrId                    ;
extern FIELD_IDX_T A_LombardCheck_InstrId                   ;
extern FIELD_IDX_T A_LombardCheck_MarketVal                 ;
extern FIELD_IDX_T A_LombardCheck_MarginVal                 ;
extern FIELD_IDX_T A_LombardCheck_Liabilities               ;
extern FIELD_IDX_T A_LombardCheck_SurplusDeficit            ;
extern FIELD_IDX_T A_LombardCheck_CheckResult               ;

/* cashwini-PMSTA-21045-150818 */
extern FIELD_IDX_T S_LombardCheck_Id                        ;
extern FIELD_IDX_T S_LombardCheck_FunctionResultId          ;
extern FIELD_IDX_T S_LombardCheck_PtfId                     ;
extern FIELD_IDX_T S_LombardCheck_ThirdId                   ;
extern FIELD_IDX_T S_LombardCheck_InstrId                   ;
extern FIELD_IDX_T S_LombardCheck_FunctionResultCd          ;
extern FIELD_IDX_T S_LombardCheck_PtfCd                     ;
extern FIELD_IDX_T S_LombardCheck_ThirdCd                   ;
extern FIELD_IDX_T S_LombardCheck_InstrCd                   ;

extern FIELD_IDX_T A_CheckList_EntDictId                   ;
extern FIELD_IDX_T A_CheckList_ObjId                       ;


extern FIELD_IDX_T A_Classif_Id                            ;
extern FIELD_IDX_T A_Classif_Cd                            ;
extern FIELD_IDX_T A_Classif_Name                          ;
extern FIELD_IDX_T A_Classif_Denom                         ;
extern FIELD_IDX_T A_Classif_EntDictId                     ;
extern FIELD_IDX_T A_Classif_DataSecuProfId                ; /*PMSTA07407-BRO-090529*/


extern FIELD_IDX_T S_Classif_Id                            ;
extern FIELD_IDX_T S_Classif_Cd                            ;
extern FIELD_IDX_T S_Classif_Name                          ;
extern FIELD_IDX_T S_Classif_EntDictId                     ;


extern FIELD_IDX_T A_ClassifCompo_ListId                   ;
extern FIELD_IDX_T A_ClassifCompo_ClassifId                ;
extern FIELD_IDX_T A_ClassifCompo_Rank                     ;
extern FIELD_IDX_T A_ClassifCompo_Priority                 ;


extern FIELD_IDX_T S_ClassifCompo_ListId                   ;
extern FIELD_IDX_T S_ClassifCompo_ClassifId                ;
extern FIELD_IDX_T S_ClassifCompo_Rank                     ;
extern FIELD_IDX_T S_ClassifCompo_Priority                 ;
extern FIELD_IDX_T S_ClassifCompo_ListCd                   ;
extern FIELD_IDX_T S_ClassifCompo_ListName                 ;


extern FIELD_IDX_T E_ClassifCompo_ListId                   ;
extern FIELD_IDX_T E_ClassifCompo_Rank                     ;
extern FIELD_IDX_T E_ClassifCompo_Priority                 ;
extern FIELD_IDX_T E_ClassifCompo_List_EntDictId           ;
extern FIELD_IDX_T E_ClassifCompo_List_NatEn               ;
extern FIELD_IDX_T E_ClassifCompo_List_ValidPeriod         ;
extern FIELD_IDX_T E_ClassifCompo_List_HistoricalListFlg   ;
extern FIELD_IDX_T E_ClassifCompo_List_ScptDef             ;


/* PMSTA11221-PRS-110119 */
extern FIELD_IDX_T A_CheckScript_Cd                        ;
extern FIELD_IDX_T A_CheckScript_Rank                      ;
extern FIELD_IDX_T A_CheckScript_DefinitionC               ;
extern FIELD_IDX_T A_CheckScript_EntDictId                 ;
extern FIELD_IDX_T A_CheckScript_ProcName                  ;

/* and for the input args for the select... */
extern FIELD_IDX_T CheckScript_Arg_AttrDictId              ;

extern FIELD_IDX_T A_ClientConnect_UserCd                  ;
extern FIELD_IDX_T A_ClientConnect_Display                 ;
extern FIELD_IDX_T A_ClientConnect_ServId                  ;
extern FIELD_IDX_T A_ClientConnect_Status                  ;


extern FIELD_IDX_T S_ClientConnect_UserCd                  ;
extern FIELD_IDX_T S_ClientConnect_Display                 ;
extern FIELD_IDX_T S_ClientConnect_ServId                  ;
extern FIELD_IDX_T S_ClientConnect_ServName                ;
extern FIELD_IDX_T S_ClientConnect_Status                  ;
extern FIELD_IDX_T S_ClientConnect_LoginTime               ;

extern FIELD_IDX_T A_CommMgr_Id                            ;


/*<REF11810-BRO-060612*/
extern FIELD_IDX_T A_Communication_Id                      ;
extern FIELD_IDX_T A_Communication_EntDictId               ;  /*PMSTA-28772-NRAO-171017*/
extern FIELD_IDX_T A_Communication_OpId                    ;
extern FIELD_IDX_T A_Communication_CommDate                ;
extern FIELD_IDX_T A_Communication_CommText                ;
extern FIELD_IDX_T A_Communication_CommTypeId              ;
extern FIELD_IDX_T A_Communication_CommSrcTypeId           ;
extern FIELD_IDX_T A_Communication_CommThirdId             ;


extern FIELD_IDX_T S_Communication_Id                      ;
extern FIELD_IDX_T S_Communication_EntDictId               ;  /*PMSTA-28772-NRAO-171017*/
extern FIELD_IDX_T S_Communication_OpId                    ;
extern FIELD_IDX_T S_Communication_CommSrcTypeId           ;
extern FIELD_IDX_T S_Communication_OpCd                    ;
extern FIELD_IDX_T S_Communication_CommSrcTypeCd           ;
/*>REF11810-BRO-060612*/



/*<PMSTA5345-EFE-080215*/
extern FIELD_IDX_T A_ComplianceChrono_PtfId                ;
extern FIELD_IDX_T A_ComplianceChrono_StratId              ;
extern FIELD_IDX_T A_ComplianceChrono_NatEn                ;
extern FIELD_IDX_T A_ComplianceChrono_CompNatEn            ;
extern FIELD_IDX_T A_ComplianceChrono_ValidDate            ;
extern FIELD_IDX_T A_ComplianceChrono_SubNatTypeId         ;
extern FIELD_IDX_T A_ComplianceChrono_ThirdPartyId         ;
extern FIELD_IDX_T A_ComplianceChrono_Val                  ;
extern FIELD_IDX_T A_ComplianceChrono_CurrId               ;
extern FIELD_IDX_T A_ComplianceChrono_Comment              ;
extern FIELD_IDX_T A_ComplianceChrono_LastUserId           ; /*PMSTA06578-BRO-080605*/
extern FIELD_IDX_T A_ComplianceChrono_LastModifDate        ; /*PMSTA06578-BRO-080605*/
extern FIELD_IDX_T A_ComplianceChrono_Min                  ; /*PMSTA-18426 - CHU - 141008*/
extern FIELD_IDX_T A_ComplianceChrono_Max                  ; /*PMSTA-18426 - CHU - 141008*/
extern FIELD_IDX_T A_ComplianceChrono_CriticalnessEn       ; /*PMSTA-18426 - CHU - 141008*/
extern FIELD_IDX_T A_ComplianceChrono_ConfidenceLevel      ; /*PMSTA-18426 - CHU - 141008*/
extern FIELD_IDX_T A_ComplianceChrono_TimeHorizon          ; /*PMSTA-18426 - CHU - 141008*/
extern FIELD_IDX_T A_ComplianceChrono_TimeHorizonUnitEn    ; /*PMSTA-18426 - CHU - 141008*/


extern FIELD_IDX_T S_ComplianceChrono_PtfId                ;
extern FIELD_IDX_T S_ComplianceChrono_StratId              ;
extern FIELD_IDX_T S_ComplianceChrono_NatEn                ;
extern FIELD_IDX_T S_ComplianceChrono_CompNatEn            ;
extern FIELD_IDX_T S_ComplianceChrono_ValidDate            ;
extern FIELD_IDX_T S_ComplianceChrono_SubNatTypeId         ;
extern FIELD_IDX_T S_ComplianceChrono_ThirdPartyId         ;
extern FIELD_IDX_T S_ComplianceChrono_Val                  ;
extern FIELD_IDX_T S_ComplianceChrono_ConfidenceLevel      ;
extern FIELD_IDX_T S_ComplianceChrono_TimeHorizon          ;
extern FIELD_IDX_T S_ComplianceChrono_TimeHorizonUnitEn    ;
extern FIELD_IDX_T S_ComplianceChrono_PtfCd                ;
extern FIELD_IDX_T S_ComplianceChrono_StratCd              ;
extern FIELD_IDX_T S_ComplianceChrono_CurrCd               ;
extern FIELD_IDX_T S_ComplianceChrono_ThirdPartyCd         ;
extern FIELD_IDX_T S_ComplianceChrono_SubNatTypeCd         ;
extern FIELD_IDX_T S_ComplianceChrono_CriticalnessEn       ; /*PMSTA-18426 - CHU - 141008*/


/*>PMSTA5345-EFE-080215*/

/*<PMSTA- 18634 - SHR - 140904 */
extern FIELD_IDX_T A_CompoundOrderRule_Id							;
extern FIELD_IDX_T A_CompoundOrderRule_Cd							;
extern FIELD_IDX_T A_CompoundOrderRule_Name							;
extern FIELD_IDX_T A_CompoundOrderRule_Denom						;
extern FIELD_IDX_T A_CompoundOrderRule_Denomination					;
extern FIELD_IDX_T A_CompoundOrderRule_CompoundOrderMasterElt		;

extern FIELD_IDX_T S_CompoundOrderRule_Id							;
extern FIELD_IDX_T S_CompoundOrderRule_Cd							;
extern FIELD_IDX_T S_CompoundOrderRule_Name							;
extern FIELD_IDX_T S_CompoundOrderRule_Denom						;
/*>PMSTA- 18634 - SHR - 140904 */


/*<PMSTA- 18634 - SHR - 140904 */
extern FIELD_IDX_T A_CompoundOrderMasterElt_Id						;
extern FIELD_IDX_T A_CompoundOrderMasterElt_Cd						;
extern FIELD_IDX_T A_CompoundOrderMasterElt_Name					;
extern FIELD_IDX_T A_CompoundOrderMasterElt_Denom					;
extern FIELD_IDX_T A_CompoundOrderMasterElt_CompoundOrderRuleId		;
extern FIELD_IDX_T A_CompoundOrderMasterElt_OpNature				;
extern FIELD_IDX_T A_CompoundOrderMasterElt_OpTypeId				;
extern FIELD_IDX_T A_CompoundOrderMasterElt_OpSubTypeId				;
extern FIELD_IDX_T A_CompoundOrderMasterElt_OpOrderTypeId			;
extern FIELD_IDX_T A_CompoundOrderMasterElt_ScreenDictId			;
extern FIELD_IDX_T A_CompoundOrderMasterElt_Denomination			;
extern FIELD_IDX_T A_CompoundOrderMasterElt_CompoundOrderSlaveElt	;

extern FIELD_IDX_T S_CompoundOrderMasterElt_Id					;
extern FIELD_IDX_T S_CompoundOrderMasterElt_Cd					;
extern FIELD_IDX_T S_CompoundOrderMasterElt_Name				;
extern FIELD_IDX_T S_CompoundOrderMasterElt_OpNature			;
extern FIELD_IDX_T S_CompoundOrderMasterElt_OpTypeId			;
extern FIELD_IDX_T S_CompoundOrderMasterElt_OpSubTypeId			;
extern FIELD_IDX_T S_CompoundOrderMasterElt_OpOrderTypeId		;
/*<PMSTA- 18634 - SHR - 140904 */

/*<PMSTA- 18634 - SHR - 140904 */
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Id						;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_CompoundOrderMasterElt	;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Cd						;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Name						;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Denom					;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_OpNature					;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_OpTypeId					;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_OpSubTypeId				;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_OpOrderTypeId			;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_ScreenDictId				;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Rank						;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_LegNature				;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_MaxLegNumber				;
extern FIELD_IDX_T A_CompoundOrderSlaveElt_Denomination				;


extern FIELD_IDX_T S_CompoundOrderSlaveElt_Id						;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_CompoundOrderMasterElt	;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_Cd						;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_Name						;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_OpNature					;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_OpTypeId					;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_OpSubTypeId				;
extern FIELD_IDX_T S_CompoundOrderSlaveElt_OpOrderTypeId			;
/*<PMSTA- 18634 - SHR - 140904 */


extern FIELD_IDX_T A_ConstraintBreach_Id                   ;
extern FIELD_IDX_T A_ConstraintBreach_NatureEn             ;
extern FIELD_IDX_T A_ConstraintBreach_StrategyEltId        ;
extern FIELD_IDX_T A_ConstraintBreach_ModelConstrEltId     ;
extern FIELD_IDX_T A_ConstraintBreach_TradingConstraintId  ;
extern FIELD_IDX_T A_ConstraintBreach_DraftOrderId         ;
extern FIELD_IDX_T A_ConstraintBreach_OrderId              ;
extern FIELD_IDX_T A_ConstraintBreach_PortfolioId          ;
extern FIELD_IDX_T A_ConstraintBreach_ExtOp_DraftOrderId_Ext;	/* REF10533 - RAK - 040908 - Used for script (to avoid access in db and use ExtOp in hier) */
extern FIELD_IDX_T A_ConstraintBreach_ExtStrategyEltId     ;    /*PMSTA-50420 -Lalby- to use ese criticalness for dynamic severity */

extern FIELD_IDX_T S_ConstraintBreach_Id                   ;
extern FIELD_IDX_T S_ConstraintBreach_NatureEn             ;
extern FIELD_IDX_T S_ConstraintBreach_StrategyEltId        ;
extern FIELD_IDX_T S_ConstraintBreach_ModelConstrEltId     ;
extern FIELD_IDX_T S_ConstraintBreach_TradingConstraintId  ;
extern FIELD_IDX_T S_ConstraintBreach_DraftOrderId         ;
extern FIELD_IDX_T S_ConstraintBreach_OrderId              ;
extern FIELD_IDX_T S_ConstraintBreach_PortfolioId          ;
extern FIELD_IDX_T S_ConstraintBreach_Denom                ;


extern FIELD_IDX_T A_ConstraintParameter_Id                ;
extern FIELD_IDX_T A_ConstraintParameter_TemplateEltId     ;
extern FIELD_IDX_T A_ConstraintParameter_DimConstraintDictId;
extern FIELD_IDX_T A_ConstraintParameter_ConstrObjId       ;
extern FIELD_IDX_T A_ConstraintParameter_InstrSetId        ;
extern FIELD_IDX_T A_ConstraintParameter_ObjectiveNbr      ;
extern FIELD_IDX_T A_ConstraintParameter_Date              ;
extern FIELD_IDX_T A_ConstraintParameter_OperatorEn        ;


extern FIELD_IDX_T S_ConstraintParameter_Id                ;
extern FIELD_IDX_T S_ConstraintParameter_TemplateEltId     ;
extern FIELD_IDX_T S_ConstraintParameter_DimConstraintDictId;
extern FIELD_IDX_T S_ConstraintParameter_ConstrObjId       ;


extern FIELD_IDX_T A_ConstrTemplate_Id                     ;
extern FIELD_IDX_T A_ConstrTemplate_Cd                     ;
extern FIELD_IDX_T A_ConstrTemplate_ConstrNatEn            ;
extern FIELD_IDX_T A_ConstrTemplate_Name                   ;
extern FIELD_IDX_T A_ConstrTemplate_Denom                  ;
extern FIELD_IDX_T A_ConstrTemplate_ActiveFlg              ;
extern FIELD_IDX_T A_ConstrTemplate_ParameterFlg           ;
extern FIELD_IDX_T A_ConstrTemplate_CriticalnessEn         ; /*REF11231-EFE-050705*/


extern FIELD_IDX_T S_ConstrTemplate_Id                     ;
extern FIELD_IDX_T S_ConstrTemplate_Cd                     ;
extern FIELD_IDX_T S_ConstrTemplate_ConstrNatEn            ;
extern FIELD_IDX_T S_ConstrTemplate_Name                   ;
extern FIELD_IDX_T S_ConstrTemplate_Denom                  ;


/*<REF10603-EFE-041018*/
extern FIELD_IDX_T A_CorporateAction_Id                        ;
extern FIELD_IDX_T A_CorporateAction_Cd                        ;
extern FIELD_IDX_T A_CorporateAction_InstrId                   ;
extern FIELD_IDX_T A_CorporateAction_SendRefCd                 ;
extern FIELD_IDX_T A_CorporateAction_ProviderId                ;
extern FIELD_IDX_T A_CorporateAction_EvTypeId                  ;
extern FIELD_IDX_T A_CorporateAction_SubEvTypeId               ;
extern FIELD_IDX_T A_CorporateAction_MsgTypeId                 ;
extern FIELD_IDX_T A_CorporateAction_MandatoryEn               ;
extern FIELD_IDX_T A_CorporateAction_ProcessStatusEn           ;
extern FIELD_IDX_T A_CorporateAction_EffectiveDate             ;
extern FIELD_IDX_T A_CorporateAction_AnnounceDate              ;
extern FIELD_IDX_T A_CorporateAction_NexusStatusEn             ;
extern FIELD_IDX_T A_CorporateAction_ShortDescCd               ;


extern FIELD_IDX_T S_CorporateAction_Id                        ;
extern FIELD_IDX_T S_CorporateAction_Cd                        ;
extern FIELD_IDX_T S_CorporateAction_InstrId                   ;
extern FIELD_IDX_T S_CorporateAction_ProviderId                ;
extern FIELD_IDX_T S_CorporateAction_AnnounceDate              ;
extern FIELD_IDX_T S_CorporateAction_ShortDescCd               ;
extern FIELD_IDX_T S_CorporateAction_TypeCd                    ;
extern FIELD_IDX_T S_CorporateAction_ProviderCd                ;
/*>REF10603-EFE-041018*/

extern FIELD_IDX_T A_Curr_Id                               ;
extern FIELD_IDX_T A_Curr_Cd                               ;
extern FIELD_IDX_T A_Curr_Name                             ;
extern FIELD_IDX_T A_Curr_Denom                            ;
extern FIELD_IDX_T A_Curr_GeoId                            ;
extern FIELD_IDX_T A_Curr_ProvThirdId                      ;
extern FIELD_IDX_T A_Curr_LastExchThirdId                  ;
extern FIELD_IDX_T A_Curr_MktThirdId                       ;
extern FIELD_IDX_T A_Curr_LastExchTpId                     ;
extern FIELD_IDX_T A_Curr_CalendarId                       ;
extern FIELD_IDX_T A_Curr_AutoCreatedFlg                   ;
extern FIELD_IDX_T A_Curr_Rank                             ;
extern FIELD_IDX_T A_Curr_EuroExchRate                     ;
extern FIELD_IDX_T A_Curr_LastExchDate                     ;
extern FIELD_IDX_T A_Curr_RoundUnitEn                      ;
extern FIELD_IDX_T A_Curr_RoundRuleEn                      ;
extern FIELD_IDX_T A_Curr_LastNoteDate                     ;
extern FIELD_IDX_T A_Curr_EuroConvDate                     ;
extern FIELD_IDX_T A_Curr_LendingValRuleEltId              ;


extern FIELD_IDX_T S_Curr_Id                               ;
extern FIELD_IDX_T S_Curr_Cd                               ;
extern FIELD_IDX_T S_Curr_Name                             ;
extern FIELD_IDX_T S_Curr_Rank                             ;
extern FIELD_IDX_T S_Curr_CodifId                          ;


extern FIELD_IDX_T A_CurrChrono_CurrId                     ;
extern FIELD_IDX_T A_CurrChrono_UnderCurrId                ;
extern FIELD_IDX_T A_CurrChrono_NatEn                      ;
extern FIELD_IDX_T A_CurrChrono_Date                       ;
extern FIELD_IDX_T A_CurrChrono_Val                        ;
extern FIELD_IDX_T A_CurrChrono_TimeDimEn                  ;
extern FIELD_IDX_T A_CurrChrono_ValidFlg                   ;


extern FIELD_IDX_T S_CurrChrono_CurrId                     ;
extern FIELD_IDX_T S_CurrChrono_UnderCurrId                ;
extern FIELD_IDX_T S_CurrChrono_NatEn                      ;
extern FIELD_IDX_T S_CurrChrono_Date                       ;
extern FIELD_IDX_T S_CurrChrono_Val                        ;
extern FIELD_IDX_T S_CurrChrono_CurrCd                     ;
extern FIELD_IDX_T S_CurrChrono_UnderCurrCd                ;


extern FIELD_IDX_T A_CurrFreq_FreqDate                     ;
extern FIELD_IDX_T A_CurrFreq_CurrId                       ;
extern FIELD_IDX_T A_CurrFreq_A_Curr_Ext                   ;


extern FIELD_IDX_T A_DataDesc_Id                           ;
extern FIELD_IDX_T A_DataDesc_RefDate                      ;
extern FIELD_IDX_T A_DataDesc_InstrId                      ;
extern FIELD_IDX_T A_DataDesc_DbFlg                        ;
extern FIELD_IDX_T A_DataDesc_A_DataDisp_Ext               ;


extern FIELD_IDX_T A_DataDisp_Id                           ;
extern FIELD_IDX_T A_DataDisp_DataDescId                   ;
extern FIELD_IDX_T A_DataDisp_RefDate                      ;
extern FIELD_IDX_T A_DataDisp_InstrId                      ;
extern FIELD_IDX_T A_DataDisp_ParInstrId                   ;
extern FIELD_IDX_T A_DataDisp_NumDays                      ;
extern FIELD_IDX_T A_DataDisp_ValueN                       ;
extern FIELD_IDX_T A_DataDisp_DbFlg                        ;
extern FIELD_IDX_T A_DataDisp_RateFreq                     ;
extern FIELD_IDX_T A_DataDisp_RateFreqUnitEn               ;
extern FIELD_IDX_T A_DataDisp_StartDate                    ;
extern FIELD_IDX_T A_DataDisp_A_DataDesc_Ext               ;


extern FIELD_IDX_T A_DataProf_Id                           ;
extern FIELD_IDX_T A_DataProf_Cd                           ;
extern FIELD_IDX_T A_DataProf_ApplUserId				   ;

extern FIELD_IDX_T S_DataProf_Id                           ;
extern FIELD_IDX_T S_DataProf_Cd                           ;


extern FIELD_IDX_T A_DataProfCompo_Id                      ;
extern FIELD_IDX_T A_DataProfCompo_DataProfId              ;
extern FIELD_IDX_T A_DataProfCompo_DataSecuProfId          ;
extern FIELD_IDX_T A_DataProfCompo_AuthUpdFlg              ;
extern FIELD_IDX_T A_DataProfCompo_AuthDelFlg              ;


extern FIELD_IDX_T S_DataProfCompo_Id                      ;
extern FIELD_IDX_T S_DataProfCompo_DataProfId              ;
extern FIELD_IDX_T S_DataProfCompo_DataSecuProfId          ;
extern FIELD_IDX_T S_DataProfCompo_AuthUpdFlg              ;
extern FIELD_IDX_T S_DataProfCompo_AuthDelFlg              ;
extern FIELD_IDX_T S_DataProfCompo_DataProfCd              ;
extern FIELD_IDX_T S_DataProfCompo_DataSecuProfCd          ;


extern FIELD_IDX_T A_DataSecuProf_Id                       ;
extern FIELD_IDX_T A_DataSecuProf_Cd                       ;


extern FIELD_IDX_T S_DataSecuProf_Id                       ;
extern FIELD_IDX_T S_DataSecuProf_Cd                       ;


/* PMSTA01389 - DDV - 070307 */
extern FIELD_IDX_T A_DataSetDef_EntityDictId               ;
extern FIELD_IDX_T A_DataSetDef_Rank                       ;
extern FIELD_IDX_T A_DataSetDef_DynType                    ;
extern FIELD_IDX_T A_DataSetDef_FieldList                  ;
extern FIELD_IDX_T A_DataSetDef_FilterScript               ;

extern FIELD_IDX_T A_Denom_EntDictId                       ;
extern FIELD_IDX_T A_Denom_ObjId                           ;
extern FIELD_IDX_T A_Denom_LangEntDictId                   ;
extern FIELD_IDX_T A_Denom_Denom                           ;


extern FIELD_IDX_T S_Denom_EntDictId                       ;
extern FIELD_IDX_T S_Denom_ObjId                           ;
extern FIELD_IDX_T S_Denom_LangEntDictId                   ;
extern FIELD_IDX_T S_Denom_LangName                        ;
extern FIELD_IDX_T S_Denom_Denom                           ;


extern FIELD_IDX_T A_DerivedStrat_Id                       ;
extern FIELD_IDX_T A_DerivedStrat_StratId                  ;
extern FIELD_IDX_T A_DerivedStrat_PtfId                    ;
extern FIELD_IDX_T A_DerivedStrat_NatEn                    ;
extern FIELD_IDX_T A_DerivedStrat_BegD                     ;
extern FIELD_IDX_T A_DerivedStrat_LastModifDate            ;
extern FIELD_IDX_T A_DerivedStrat_A_DerivedStratElt_Ext    ;
extern FIELD_IDX_T A_DerivedStrat_RefStratId               ;


extern FIELD_IDX_T S_DerivedStrat_Id                       ;
extern FIELD_IDX_T S_DerivedStrat_StratId                  ;
extern FIELD_IDX_T S_DerivedStrat_PtfId                    ;
extern FIELD_IDX_T S_DerivedStrat_NatEn                    ; /* REF8844 - LJE - 030612 */
extern FIELD_IDX_T S_DerivedStrat_StratCd                  ;
extern FIELD_IDX_T S_DerivedStrat_PtfCd                    ;


extern FIELD_IDX_T A_DerivedStratElt_Id                    ;
extern FIELD_IDX_T A_DerivedStratElt_DerivedStratId        ;
extern FIELD_IDX_T A_DerivedStratElt_MktSgtId              ;
extern FIELD_IDX_T A_DerivedStratElt_InstrId               ;
extern FIELD_IDX_T A_DerivedStratElt_NatEn                 ;
extern FIELD_IDX_T A_DerivedStratElt_Weight                ;
extern FIELD_IDX_T A_DerivedStratElt_FluctMargin           ;
extern FIELD_IDX_T A_DerivedStratElt_BenchEntDictId        ;
extern FIELD_IDX_T A_DerivedStratElt_BenchObjId            ;
extern FIELD_IDX_T A_DerivedStratElt_Rank                  ;
extern FIELD_IDX_T A_DerivedStratElt_OldWeight             ;
extern FIELD_IDX_T A_DerivedStratElt_WeightFactor          ;
extern FIELD_IDX_T A_DerivedStratElt_ContribValue          ;
extern FIELD_IDX_T A_DerivedStratElt_OldContribValue       ;

extern FIELD_IDX_T A_DictUser_DictId;
extern FIELD_IDX_T A_DictUser_UserName;
extern FIELD_IDX_T A_DictUser_DictId;
extern FIELD_IDX_T A_DictUser_UserName;
extern FIELD_IDX_T A_DictUser_Database;
extern FIELD_IDX_T A_DictUser_EnvironName;
extern FIELD_IDX_T A_DictUser_ApplOwnerFlg;
extern FIELD_IDX_T A_DictUser_TechnicalFlg;
extern FIELD_IDX_T A_DictUser_GroupName;

extern FIELD_IDX_T S_DictUser_DictId;
extern FIELD_IDX_T S_DictUser_UserName;

extern FIELD_IDX_T A_DictCriter_DictId                     ;
extern FIELD_IDX_T A_DictCriter_EntDictId                  ;
extern FIELD_IDX_T A_DictCriter_AttrDictId                 ;
extern FIELD_IDX_T A_DictCriter_Prog                       ;
extern FIELD_IDX_T A_DictCriter_SortRank                   ;
extern FIELD_IDX_T A_DictCriter_SortRuleEn                 ;
extern FIELD_IDX_T A_DictCriter_FkIndex                    ;
extern FIELD_IDX_T A_DictCriter_DynNat                     ;   /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T A_DictCriter_SqlName                    ;   /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T A_DictCriter_Index                      ;   /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T A_DictCriter_Par1Prog                   ;   /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T A_DictCriter_Par2Prog                   ;   /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T A_DictCriter_AttrEntDictId              ;   /*  FIH-REF11553-060217 */


extern FIELD_IDX_T S_DictCriter_DictId                     ;
extern FIELD_IDX_T S_DictCriter_EntDictId                  ;
extern FIELD_IDX_T S_DictCriter_AttrDictId                 ;
extern FIELD_IDX_T S_DictCriter_Prog                       ;
extern FIELD_IDX_T S_DictCriter_SortRank                   ;
extern FIELD_IDX_T S_DictCriter_DynNat                     ; /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T S_DictCriter_SqlName                    ; /* PMSTA-11903 - RPO - 110509 */
extern FIELD_IDX_T S_DictCriter_EntSqlName                 ; /*REF11553-BRO-051215*/
extern FIELD_IDX_T S_DictCriter_AttrSqlName                ; /*REF11553-BRO-051215*/

/* PMSTA-13109 - LJE - 111122 */
extern FIELD_IDX_T A_DictDatabase_DictId                   ;
extern FIELD_IDX_T A_DictDatabase_Code                     ;
extern FIELD_IDX_T A_DictDatabase_SqlName                  ;

/* PMSTA-13109 - LJE - 111122 */
extern FIELD_IDX_T S_DictDatabase_DictId                   ;
extern FIELD_IDX_T S_DictDatabase_Code                     ;
extern FIELD_IDX_T S_DictDatabase_SqlName                  ;

/* PMSTA-13109 - LJE - 111122 */
extern FIELD_IDX_T A_DictSegment_DictId                    ;
extern FIELD_IDX_T A_DictSegment_Code                      ;
extern FIELD_IDX_T A_DictSegment_SqlName                   ;
extern FIELD_IDX_T A_DictSegment_DbDictId                  ;

/* PMSTA-13109 - LJE - 111122 */
extern FIELD_IDX_T S_DictSegment_DictId                    ;
extern FIELD_IDX_T S_DictSegment_Code                      ;
extern FIELD_IDX_T S_DictSegment_SqlName                   ;
extern FIELD_IDX_T S_DictSegment_DbDictId                  ;

extern FIELD_IDX_T A_DictDataTp_DictId                     ;
extern FIELD_IDX_T A_DictDataTp_Name                       ;
extern FIELD_IDX_T A_DictDataTp_SqlName                    ;
extern FIELD_IDX_T A_DictDataTp_EquivTp                    ;
extern FIELD_IDX_T A_DictDataTp_Prog                       ;
extern FIELD_IDX_T A_DictDataTp_CustAuthFlg                ;


extern FIELD_IDX_T S_DictDataTp_DictId                     ;
extern FIELD_IDX_T S_DictDataTp_Name                       ;
extern FIELD_IDX_T S_DictDataTp_SqlName                    ; /* PMSTA-11505 - LJE - 110625 */



extern FIELD_IDX_T E_DictFct_DictId                        ;
extern FIELD_IDX_T E_DictFct_Name						   ;
extern FIELD_IDX_T E_DictFct_Label						   ;
extern FIELD_IDX_T E_DictFct_ProcName					   ;
extern FIELD_IDX_T E_DictFct_ParFctDictId				   ;
extern FIELD_IDX_T E_DictFct_EntDictId					   ;
extern FIELD_IDX_T E_DictFct_OrderEntryFctDictId           ;
extern FIELD_IDX_T E_DictFct_NatEn						   ;
extern FIELD_IDX_T E_DictFct_TypeId						   ;
extern FIELD_IDX_T E_DictFct_SubTypeId					   ;
extern FIELD_IDX_T E_DictFct_HelpNode					   ;
extern FIELD_IDX_T E_DictFct_IconName					   ;
extern FIELD_IDX_T E_DictFct_Rank						   ;
extern FIELD_IDX_T E_DictFct_FuncSecuProfId			       ;
extern FIELD_IDX_T E_DictFct_EntityDictId				   ;
extern FIELD_IDX_T E_DictFct_MinOpStatus				   ;
extern FIELD_IDX_T E_DictFct_MaxOpStatus				   ;
extern FIELD_IDX_T E_DictFct_SecurityLevel				   ;
extern FIELD_IDX_T E_DictFct_CreateFlg					   ;
extern FIELD_IDX_T E_DictFct_UpdateFlg					   ;
extern FIELD_IDX_T E_DictFct_DeleteFlg					   ;
extern FIELD_IDX_T E_DictFct_RiskViewFlg				   ;
extern FIELD_IDX_T E_DictFct_RealTimeFlg				   ;
extern FIELD_IDX_T E_DictFct_ViewFlg					   ;
extern FIELD_IDX_T E_DictFct_VisibleFlg					   ;
extern FIELD_IDX_T E_DictFct_LicenseKeyEn				   ;
extern FIELD_IDX_T E_DictFct_AccessStatus				   ;

extern FIELD_IDX_T A_DictLabel_LangDictId                  ;
extern FIELD_IDX_T A_DictLabel_EntDictId                   ;
extern FIELD_IDX_T A_DictLabel_ObjDictId                   ;
extern FIELD_IDX_T A_DictLabel_Name                        ;


extern FIELD_IDX_T S_DictLabel_LangDictId                  ;
extern FIELD_IDX_T S_DictLabel_EntDictId                   ;
extern FIELD_IDX_T S_DictLabel_ObjDictId                   ;
extern FIELD_IDX_T S_DictLabel_Name                        ;
extern FIELD_IDX_T S_DictLabel_LangName                    ;


extern FIELD_IDX_T A_DictLang_Id                           ;
extern FIELD_IDX_T A_DictLang_Cd                           ;
extern FIELD_IDX_T A_DictLang_Name                         ;
extern FIELD_IDX_T A_DictLang_Denom                        ;
extern FIELD_IDX_T A_DictLang_SqlName                      ;
extern FIELD_IDX_T A_DictLang_ThousSep                     ;
extern FIELD_IDX_T A_DictLang_DecimSep                     ;
extern FIELD_IDX_T A_DictLang_DateFmt                      ;
extern FIELD_IDX_T A_DictLang_TslMultilingualFlg           ;    /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */


extern FIELD_IDX_T S_DictLang_Id                           ;
extern FIELD_IDX_T S_DictLang_Cd                           ;
extern FIELD_IDX_T S_DictLang_Name                         ;
extern FIELD_IDX_T S_DictLang_SqlName;
extern FIELD_IDX_T S_DictLang_CodifId                      ;


extern FIELD_IDX_T A_DictPanel_DictId                      ;
extern FIELD_IDX_T A_DictPanel_Name                        ;
extern FIELD_IDX_T A_DictPanel_ScreenDictId                ;
extern FIELD_IDX_T A_DictPanel_AttribDictId                ;
extern FIELD_IDX_T A_DictPanel_ParPanelDictId              ;
extern FIELD_IDX_T A_DictPanel_NatEn                       ;
extern FIELD_IDX_T A_DictPanel_WgtEn                       ;
extern FIELD_IDX_T A_DictPanel_Rank                        ;
extern FIELD_IDX_T A_DictPanel_LeftCoord                   ;
extern FIELD_IDX_T A_DictPanel_TopCoord                    ;
extern FIELD_IDX_T A_DictPanel_Width                       ;
extern FIELD_IDX_T A_DictPanel_Height                      ;
extern FIELD_IDX_T A_DictPanel_LabelWidth                  ;
extern FIELD_IDX_T A_DictPanel_LabelPosEn                  ;
extern FIELD_IDX_T A_DictPanel_FgColor                     ;
extern FIELD_IDX_T A_DictPanel_BgColor                     ;
extern FIELD_IDX_T A_DictPanel_PenEn                       ;
extern FIELD_IDX_T A_DictPanel_VertScrollBarFlg            ;
extern FIELD_IDX_T A_DictPanel_EditEn                      ;
extern FIELD_IDX_T A_DictPanel_MandatoryFlg                ;
extern FIELD_IDX_T A_DictPanel_SecuLevelEn                 ;
extern FIELD_IDX_T A_DictPanel_KeyChar                     ;
extern FIELD_IDX_T A_DictPanel_FileName                    ;
extern FIELD_IDX_T A_DictPanel_DatatypeDictId              ;
extern FIELD_IDX_T A_DictPanel_AttachTopFlg                ;
extern FIELD_IDX_T A_DictPanel_AttachBottomFlg             ;
extern FIELD_IDX_T A_DictPanel_AttachLeftFlg               ;
extern FIELD_IDX_T A_DictPanel_AttachRightFlg              ;
extern FIELD_IDX_T A_DictPanel_FixedWidthFlg               ;
extern FIELD_IDX_T A_DictPanel_FixedHeighFlg               ;
extern FIELD_IDX_T A_DictPanel_SubScreenDictId             ; /*REF9031-BRO-030714*/
extern FIELD_IDX_T A_DictPanel_Denom                       ;
extern FIELD_IDX_T A_DictPanel_PanelScriptDef              ;
extern FIELD_IDX_T A_DictPanel_AttachMask                  ;
extern FIELD_IDX_T A_DictPanel_WgtPtr                      ;
extern FIELD_IDX_T A_DictPanel_AttribIdx                   ;
extern FIELD_IDX_T A_DictPanel_A_ParPanel_Ext              ;
extern FIELD_IDX_T A_DictPanel_A_ChildPanel_Ext            ;
extern FIELD_IDX_T A_DictPanel_NotCopyScptFlg              ;
extern FIELD_IDX_T A_DictPanel_AvailabilityDef             ;    /*  FIH-REF10671-041025 */
extern FIELD_IDX_T A_DictPanel_HardCodedStateEn            ;    /*  FPL-REF10671-041109 */
extern FIELD_IDX_T A_DictPanel_CurrentStateEn              ;    /*  FPL-REF10671-041109 */


extern FIELD_IDX_T S_DictPanel_DictId                      ;
extern FIELD_IDX_T S_DictPanel_Name                        ;
extern FIELD_IDX_T S_DictPanel_ScreenDictId                ;
extern FIELD_IDX_T S_DictPanel_AttribDictId                ;
extern FIELD_IDX_T S_DictPanel_NatEn                       ;


extern FIELD_IDX_T A_DictScreen_DictId                     ;
extern FIELD_IDX_T A_DictScreen_Name                       ;
extern FIELD_IDX_T A_DictScreen_EntDictId                  ;
extern FIELD_IDX_T A_DictScreen_RuleId                     ;
extern FIELD_IDX_T A_DictScreen_Denom                      ;
extern FIELD_IDX_T A_DictScreen_ReferenceScreenDictId      ;


extern FIELD_IDX_T S_DictScreen_DictId                     ;
extern FIELD_IDX_T S_DictScreen_Name                       ;
extern FIELD_IDX_T S_DictScreen_EntDictId                  ;
extern FIELD_IDX_T S_DictScreen_EntSqlName                 ;


/* PMSTA-15655 - LJE - 130124 */
extern FIELD_IDX_T O_DictPermVal_AttrDictId                ;
extern FIELD_IDX_T O_DictPermVal_AttrSqlName               ;
extern FIELD_IDX_T O_DictPermVal_PermValNatEn              ;
extern FIELD_IDX_T O_DictPermVal_PermValId                 ;
extern FIELD_IDX_T O_DictPermVal_Name                      ;
extern FIELD_IDX_T O_DictPermVal_Label                     ;
extern FIELD_IDX_T O_DictPermVal_Rank                      ;
extern FIELD_IDX_T O_DictPermVal_RefEntityDictId           ;
extern FIELD_IDX_T O_DictPermVal_PermValRuleEn             ;
extern FIELD_IDX_T O_DictPermVal_DefSelFlg                 ;

extern FIELD_IDX_T A_DictView_DictId                       ;
extern FIELD_IDX_T A_DictView_EntDictId                    ;
extern FIELD_IDX_T A_DictView_AuthSelFlg                   ;
extern FIELD_IDX_T A_DictView_AuthInsFlg                   ;
extern FIELD_IDX_T A_DictView_AuthUpdFlg                   ;
extern FIELD_IDX_T A_DictView_AutoFlg                      ;
extern FIELD_IDX_T A_DictView_LastBuildDate                ;
extern FIELD_IDX_T A_DictView_ViewNatEn                    ;
extern FIELD_IDX_T A_DictView_Name                         ;


extern FIELD_IDX_T S_DictView_DictId                       ;
extern FIELD_IDX_T S_DictView_EntDictId                    ;
extern FIELD_IDX_T S_DictView_ViewNatEn                    ;
extern FIELD_IDX_T S_DictView_Name                         ;

/* PMSTA13244 - DDV - 120119 */
extern FIELD_IDX_T A_DictFctAttrib_DictId                  ;
extern FIELD_IDX_T A_DictFctAttrib_FctDictId               ;
extern FIELD_IDX_T A_DictFctAttrib_FmtId                   ; /* PMSTA13655 - DDV - 120305 */
extern FIELD_IDX_T A_DictFctAttrib_EntitySqlName           ;
extern FIELD_IDX_T A_DictFctAttrib_AttributeSqlName        ;
extern FIELD_IDX_T A_DictFctAttrib_KeyEncodingEn           ;

/* PMSTA13244 - DDV - 120119 */
extern FIELD_IDX_T S_DictFctAttrib_Id                      ;
extern FIELD_IDX_T S_DictFctAttrib_FctDictId               ;
extern FIELD_IDX_T S_DictFctAttrib_FmtId                   ; /* PMSTA13655 - DDV - 120305 */
extern FIELD_IDX_T S_DictFctAttrib_EntitySqlName           ;
extern FIELD_IDX_T S_DictFctAttrib_AttributeSqlName        ;
extern FIELD_IDX_T S_DictFctAttrib_KeyEncodingEn           ;
extern FIELD_IDX_T S_DictFctAttrib_FctName                 ;
extern FIELD_IDX_T S_DictFctAttrib_FmtCd                   ; /* PMSTA13655 - DDV - 120305 */


extern FIELD_IDX_T A_Doc_Id                                ;
extern FIELD_IDX_T A_Doc_Cd                                ;
extern FIELD_IDX_T A_Doc_Name                              ;
extern FIELD_IDX_T A_Doc_FolderId                          ;
extern FIELD_IDX_T A_Doc_FctId                             ;
extern FIELD_IDX_T A_Doc_DomainId                          ;
extern FIELD_IDX_T A_Doc_TiledFlg                          ;
extern FIELD_IDX_T A_Doc_Rank                              ;
extern FIELD_IDX_T A_Doc_LastNoteDate                      ;
extern FIELD_IDX_T A_Doc_A_Domain_Ext                      ;
extern FIELD_IDX_T A_Doc_A_DictFct_Ext                     ;


extern FIELD_IDX_T S_Doc_Id                                ;
extern FIELD_IDX_T S_Doc_Cd                                ;
extern FIELD_IDX_T S_Doc_Name                              ;


extern FIELD_IDX_T A_DocIndex_EntityDictId                 ;
extern FIELD_IDX_T A_DocIndex_PtfId                        ;
extern FIELD_IDX_T A_DocIndex_RefDate                      ;
extern FIELD_IDX_T A_DocIndex_NatEn                        ;
extern FIELD_IDX_T A_DocIndex_Index                        ;


extern FIELD_IDX_T S_DocIndex_EntityDictId                 ;
extern FIELD_IDX_T S_DocIndex_PtfId                        ;
extern FIELD_IDX_T S_DocIndex_RefDate                      ;
extern FIELD_IDX_T S_DocIndex_NatEn                        ;


extern FIELD_IDX_T A_Domain_Id                             ;
extern FIELD_IDX_T A_Domain_CurrId                         ;
extern FIELD_IDX_T A_Domain_DimPtfDictId                   ;
extern FIELD_IDX_T A_Domain_DimInstrDictId                 ;
extern FIELD_IDX_T A_Domain_DimStratDictId                 ;
extern FIELD_IDX_T A_Domain_UsrId                          ;
extern FIELD_IDX_T A_Domain_LangDictId                     ;
extern FIELD_IDX_T A_Domain_FctDictId                      ;
extern FIELD_IDX_T A_Domain_ScenaId                        ;
extern FIELD_IDX_T A_Domain_QuoteValRuleId                 ;
extern FIELD_IDX_T A_Domain_ExchValRuleId                  ;
extern FIELD_IDX_T A_Domain_PtfObjId                       ;
extern FIELD_IDX_T A_Domain_InstrObjId                     ;
extern FIELD_IDX_T A_Domain_StratObjId                     ;
extern FIELD_IDX_T A_Domain_ReportId                       ;
extern FIELD_IDX_T A_Domain_AccPeriodId                    ;
extern FIELD_IDX_T A_Domain_FctResultId                    ;
extern FIELD_IDX_T A_Domain_GridId                         ;
extern FIELD_IDX_T A_Domain_AccPlanId                      ;
extern FIELD_IDX_T A_Domain_BookPtfId                      ;
extern FIELD_IDX_T A_Domain_ConsPtfId                      ;
extern FIELD_IDX_T A_Domain_PortPosSetId                   ;
extern FIELD_IDX_T A_Domain_MktSegId                       ;
extern FIELD_IDX_T A_Domain_CashCurrId                     ;
extern FIELD_IDX_T A_Domain_BuyOrderRuleId                 ;
extern FIELD_IDX_T A_Domain_SellOrderRuleId                ;
extern FIELD_IDX_T A_Domain_LastUserId                     ;
extern FIELD_IDX_T A_Domain_BuyPtfClassifId                ;
extern FIELD_IDX_T A_Domain_SellPtfClassifId               ;
extern FIELD_IDX_T A_Domain_LastModifDate                  ;
extern FIELD_IDX_T A_Domain_FusDateRuleEn                  ;
extern FIELD_IDX_T A_Domain_FusRuleEn                      ;
extern FIELD_IDX_T A_Domain_MinStatEn                      ;
extern FIELD_IDX_T A_Domain_MaxStatEn                      ;
extern FIELD_IDX_T A_Domain_FundSplitRuleEn                ;
extern FIELD_IDX_T A_Domain_ZeroQtyFlg                     ;
extern FIELD_IDX_T A_Domain_RiskExpoFlg                    ;
extern FIELD_IDX_T A_Domain_OptRiskRuleEn                  ;
extern FIELD_IDX_T A_Domain_UnderFlg                       ;
extern FIELD_IDX_T A_Domain_PtfConsRuleEn                  ;
extern FIELD_IDX_T A_Domain_StatusFusFlg                   ;
extern FIELD_IDX_T A_Domain_ClosPosFlg                     ;
extern FIELD_IDX_T A_Domain_PosLogicEn                     ;
extern FIELD_IDX_T A_Domain_FromDateCompRule               ;
extern FIELD_IDX_T A_Domain_TillDateCompRule               ;
extern FIELD_IDX_T A_Domain_StratDateCompRule              ;
extern FIELD_IDX_T A_Domain_FreqDateCompRule               ;
extern FIELD_IDX_T A_Domain_Freq1                          ;
extern FIELD_IDX_T A_Domain_Freq1UnitEn                    ;
extern FIELD_IDX_T A_Domain_Freq2                          ;
extern FIELD_IDX_T A_Domain_Freq2UnitEn                    ;
extern FIELD_IDX_T A_Domain_DefCurrFlg                     ;
extern FIELD_IDX_T A_Domain_DefLangFlg                     ;
extern FIELD_IDX_T A_Domain_DfltFlg                        ;
extern FIELD_IDX_T A_Domain_PtfQuoteRetrFlg                ;
extern FIELD_IDX_T A_Domain_DfltFusDateRuleFlg             ;
extern FIELD_IDX_T A_Domain_DebtFlg                        ;
extern FIELD_IDX_T A_Domain_LoadPosFlg                     ;
extern FIELD_IDX_T A_Domain_FusSubNatFlg                   ;
extern FIELD_IDX_T A_Domain_StratLnkNatEn                  ;
extern FIELD_IDX_T A_Domain_ForceLnkFlg                    ;
extern FIELD_IDX_T A_Domain_CheckedPtfFlg                  ;
extern FIELD_IDX_T A_Domain_MinLnkPriority                 ;
extern FIELD_IDX_T A_Domain_MaxLnkPriority                 ;
extern FIELD_IDX_T A_Domain_ConvFactor                     ;
extern FIELD_IDX_T A_Domain_PosValRuleEn                   ;
extern FIELD_IDX_T A_Domain_EvtOperStatEn                  ;
extern FIELD_IDX_T A_Domain_EvtGenNatEn                    ;
extern FIELD_IDX_T A_Domain_EvtFlowNatEn                   ;
extern FIELD_IDX_T A_Domain_EvtFlowSubNatEn                ;
extern FIELD_IDX_T A_Domain_EvtFlowSubNatLst               ;
extern FIELD_IDX_T A_Domain_FromAccNbr                     ;
extern FIELD_IDX_T A_Domain_TillAccNbr                     ;
extern FIELD_IDX_T A_Domain_ClosingNatEn                   ;
extern FIELD_IDX_T A_Domain_StratCheckDetNatEn             ;
extern FIELD_IDX_T A_Domain_CompDataEn                     ;
extern FIELD_IDX_T A_Domain_OrigCompDataEn				   ;
extern FIELD_IDX_T A_Domain_FctResultCd                    ;
extern FIELD_IDX_T A_Domain_DispResultFlg                  ;
extern FIELD_IDX_T A_Domain_RefDateCompRule                ;
extern FIELD_IDX_T A_Domain_ValoSeqNo                      ;
extern FIELD_IDX_T A_Domain_ListHistEn                     ;
extern FIELD_IDX_T A_Domain_EvtPlRuleEn                    ;
extern FIELD_IDX_T A_Domain_RetDetLevelEn                  ;
extern FIELD_IDX_T A_Domain_SubGridFlg                     ;
extern FIELD_IDX_T A_Domain_PpsLoadEn                      ;
extern FIELD_IDX_T A_Domain_PpsTypeFlg                     ;
extern FIELD_IDX_T A_Domain_PpsConsPflFlg                  ;
extern FIELD_IDX_T A_Domain_PpsCurrFlg                     ;
extern FIELD_IDX_T A_Domain_LoadHierFlg                    ;
extern FIELD_IDX_T A_Domain_OrderNatEn                     ;
extern FIELD_IDX_T A_Domain_GenGlobalOrderEn               ;
extern FIELD_IDX_T A_Domain_OrderAllocNatEn                ;
extern FIELD_IDX_T A_Domain_ObjWeightContPrct              ;
extern FIELD_IDX_T A_Domain_ObjWeightContMargPrct          ;
extern FIELD_IDX_T A_Domain_QtyAllocNatEn                  ;
extern FIELD_IDX_T A_Domain_CashAllocNatEn                 ;
extern FIELD_IDX_T A_Domain_CashObjWeightPrct              ;
extern FIELD_IDX_T A_Domain_CheckStratEn                   ;
extern FIELD_IDX_T A_Domain_OrderStatusEn                  ;
extern FIELD_IDX_T A_Domain_EvtDateRuleEn                  ;
extern FIELD_IDX_T A_Domain_OpSearch                       ;
extern FIELD_IDX_T A_Domain_ExtOpSearch                    ;
extern FIELD_IDX_T A_Domain_HistListFlg                    ;
extern FIELD_IDX_T A_Domain_MinOrderAmt                    ;
extern FIELD_IDX_T A_Domain_MinOrderAmtCurrId              ;
extern FIELD_IDX_T A_Domain_MktSgtRebalFlg                 ;
extern FIELD_IDX_T A_Domain_InstrListDef                   ;
extern FIELD_IDX_T A_Domain_PtfListDef                     ;
extern FIELD_IDX_T A_Domain_LoadGlobOrderEn                ;
extern FIELD_IDX_T A_Domain_InterpFromDate                 ;
extern FIELD_IDX_T A_Domain_InterpStratDate                ;
extern FIELD_IDX_T A_Domain_FctResultStatEn                ;
extern FIELD_IDX_T A_Domain_CompLevelEn                    ;
extern FIELD_IDX_T A_Domain_DerivationEn                   ;
extern FIELD_IDX_T A_Domain_DynWeightFlg                   ;
extern FIELD_IDX_T A_Domain_ConstrNatEn                    ;
extern FIELD_IDX_T A_Domain_ExtPosListId                   ;
extern FIELD_IDX_T A_Domain_LoadNonDiscretFlg              ;
extern FIELD_IDX_T A_Domain_CheckTradingFlg                ;
extern FIELD_IDX_T A_Domain_ExecDetailsFlg                 ;
extern FIELD_IDX_T A_Domain_RoundingMethodEn               ;
extern FIELD_IDX_T A_Domain_DimEntityDictId                ;
extern FIELD_IDX_T A_Domain_Bench1EntityDictId             ;
extern FIELD_IDX_T A_Domain_Bench1ObjectId                 ;
extern FIELD_IDX_T A_Domain_Bench2EntityDictId             ;
extern FIELD_IDX_T A_Domain_Bench2ObjectId                 ;
extern FIELD_IDX_T A_Domain_Bench3EntityDictId             ;
extern FIELD_IDX_T A_Domain_Bench3ObjectId                 ;
extern FIELD_IDX_T A_Domain_RiskFreeInstrId                ;
extern FIELD_IDX_T A_Domain_ReturnAnalysisEn               ;
extern FIELD_IDX_T A_Domain_PerfAttribMethodEn             ;
extern FIELD_IDX_T A_Domain_PerfAttribFreqEn               ;
extern FIELD_IDX_T A_Domain_PSPPositionDataId              ; /* REF9125 - LJE - 030811 */
extern FIELD_IDX_T A_Domain_PLMethodEn                     ; /* REF9125 - LJE - 030811 */
extern FIELD_IDX_T A_Domain_AuthOnlinePeriods              ; /* REF9125 - LJE - 030811 */
extern FIELD_IDX_T A_Domain_UnmatchedExecSearch            ; /*REF9764-BRO-040119*/
extern FIELD_IDX_T A_Domain_PurgeOrderMethodEn             ; /*REF8723-BRO-040204*/
extern FIELD_IDX_T A_Domain_FileName                       ; /*REF8723-BRO-040204*/
extern FIELD_IDX_T A_Domain_CashFlowMgtEn                  ; /*PMSTA00485-BRO-061103*/
extern FIELD_IDX_T A_Domain_DummyMinStatEn                 ; /*PMSTA00344-CHU-070122*/
extern FIELD_IDX_T A_Domain_DummyMaxStatEn                 ; /*PMSTA00344-CHU-070122*/
extern FIELD_IDX_T A_Domain_FctResultListDef               ;    /*  FPL-090209-PMSTA07121   */
extern FIELD_IDX_T A_Domain_DimFctResultDictId             ;    /*  FPL-090209-PMSTA07121   */
extern FIELD_IDX_T A_Domain_CaseMgtSearch                  ;    /*  FPL-090209-PMSTA07121   */
extern FIELD_IDX_T A_Domain_FormatProfileId                ; /*PMSTA07861-EFE-090309*/
extern FIELD_IDX_T A_Domain_JobReference                   ; /*PMSTA07861-EFE-090309*/
extern FIELD_IDX_T A_Domain_InterpTillDate                 ;
extern FIELD_IDX_T A_Domain_InterpFreqDate                 ;
extern FIELD_IDX_T A_Domain_CalcRefDate                    ;
extern FIELD_IDX_T A_Domain_TslDbName                      ;  /* PMSTA9318-EFE-100209 */
extern FIELD_IDX_T A_Domain_SessionCreationDate            ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_SessionCreationUserId          ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_SessionDescriptionInfo         ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_SessionNatureEn                ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_ProposalNatureEn               ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_ParentSessionId                ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_DefaultStrategyId              ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_SimulationFlg                  ;  /* PMSTA10733-EFE-101108*/
extern FIELD_IDX_T A_Domain_SessionStatusEn                ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_IncludeExternalPosFlg          ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_ActivateIncludeOrderFlg        ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_ValidationRightFlg             ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_ValidationDate                 ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_ValidationUserId               ; /* PMSTA10733-TEB-101222 */
extern FIELD_IDX_T A_Domain_MinOrderPercent                ; /* PMSTA10173-CHU-110309 */
extern FIELD_IDX_T A_Domain_RepColorEn                     ; /*<PMSTA11542-BRO-110502*/
extern FIELD_IDX_T A_Domain_RepAnonymousEn                 ;
extern FIELD_IDX_T A_Domain_RepStyleSheetEn                ;
extern FIELD_IDX_T A_Domain_RepTocEn                       ;
extern FIELD_IDX_T A_Domain_RepValoEn                      ;
extern FIELD_IDX_T A_Domain_RepStockChartEn                ;
extern FIELD_IDX_T A_Domain_RepBondChartEn                 ;
extern FIELD_IDX_T A_Domain_RepOverviewEn                  ;
extern FIELD_IDX_T A_Domain_RepCashflowEn                  ;
extern FIELD_IDX_T A_Domain_RepCurrChartEn                 ;
extern FIELD_IDX_T A_Domain_RepMaturityChartEn             ;
extern FIELD_IDX_T A_Domain_RepOrdersEn                    ;
extern FIELD_IDX_T A_Domain_RepOpHistEn                    ;
extern FIELD_IDX_T A_Domain_RepPerfEn                      ;
extern FIELD_IDX_T A_Domain_RepComplianceEn                ;
extern FIELD_IDX_T A_Domain_RepIntroEn                     ;
extern FIELD_IDX_T A_Domain_RepValo2En                     ;
extern FIELD_IDX_T A_Domain_RepStockChart2En               ;
extern FIELD_IDX_T A_Domain_RepBondChart2En                ;
extern FIELD_IDX_T A_Domain_RepCashflow2En                 ;
extern FIELD_IDX_T A_Domain_RepCurrChart2En                ;
extern FIELD_IDX_T A_Domain_RepMaturityChart2En            ;
extern FIELD_IDX_T A_Domain_RepCompliance2En               ;
extern FIELD_IDX_T A_Domain_RepPreviewFlg                  ;
extern FIELD_IDX_T A_Domain_RepPrinterId                   ;
extern FIELD_IDX_T A_Domain_RepCopy                        ;
extern FIELD_IDX_T A_Domain_RepFileOutputFlg               ;
extern FIELD_IDX_T A_Domain_RepFileOutputNatEn             ;
extern FIELD_IDX_T A_Domain_RepFileOutputName              ;
extern FIELD_IDX_T A_Domain_RepRoiOutputName               ;
extern FIELD_IDX_T A_Domain_RepDeleteDataFlg               ;
extern FIELD_IDX_T A_Domain_RepExecutionCd                 ;
extern FIELD_IDX_T A_Domain_RepExecutionStatusEn           ;
extern FIELD_IDX_T A_Domain_RepBurstListId                 ;
extern FIELD_IDX_T A_Domain_RepFinishDate                  ;
extern FIELD_IDX_T A_Domain_RepLaunchDate                  ;
extern FIELD_IDX_T A_Domain_RepConfigNatEn                 ;
extern FIELD_IDX_T A_Domain_RepStockGroupEn                ;
extern FIELD_IDX_T A_Domain_RepFundGroupEn                 ;
extern FIELD_IDX_T A_Domain_RepModuleTraceFlg              ;
extern FIELD_IDX_T A_Domain_RepStyleTraceFlg               ;
extern FIELD_IDX_T A_Domain_RepGlobalTraceFlg              ;
extern FIELD_IDX_T A_Domain_RepPrintEn                     ; /*PMSTA11542-BRO-110502*/
extern FIELD_IDX_T A_Domain_RepAdditionalInfo              ; /*PMSTA11542-BRO-110623*/
extern FIELD_IDX_T A_Domain_DataSecuProfId                 ; /*PMSTA11805-BRO-110502*/
extern FIELD_IDX_T A_Domain_OwnershipRuleEn                ; /*PMSTA11875-BRO-110502*/
extern FIELD_IDX_T A_Domain_ThirdCompoEn                   ; /*PMSTA11875-BRO-110502*/
extern FIELD_IDX_T A_Domain_TypeId                         ; /*PMSTA11542-BRO-110505*/
extern FIELD_IDX_T A_Domain_SessionOrigin                  ; /*PMSTA12266-BRO-110624*/
extern FIELD_IDX_T A_Domain_ManagerLinkId                  ; /*PMSTA13166-EFE-120110*/
extern FIELD_IDX_T A_Domain_DimTypeEn                      ; /*PMSTA13166-EFE-120110*/
extern FIELD_IDX_T A_Domain_RepJobPriority                 ; /*OCS40593-BRO-120509*/
extern FIELD_IDX_T A_Domain_RepNotificationFlg             ; /*OCS40593-BRO-120509*/
extern FIELD_IDX_T A_Domain_CalcPivotDate                  ; /*PMSTA-14375-EFE-120615*/
extern FIELD_IDX_T A_Domain_DataSecuProf2Id                ; /*PMSTA14309-EFE-120622*/
extern FIELD_IDX_T A_Domain_ChildSessionId                 ; /*PMSTA15463-CHU-121129*/
extern FIELD_IDX_T A_Domain_ExpirationDate                 ; /*PMSTA15756-BRO-130121*/
extern FIELD_IDX_T A_Domain_RepPtccEn                      ; /*LR1088-BRO-130121*/
extern FIELD_IDX_T A_Domain_RepPtccChartEn                 ; /*LR1088-BRO-130121*/
extern FIELD_IDX_T A_Domain_RepPerfAttribChartEn           ; /*OCS42372-BRO-130121*/
extern FIELD_IDX_T A_Domain_RepPerfContribLevelEn          ; /*OCS42372-BRO-130121*/
extern FIELD_IDX_T A_Domain_OrderGroupingFctDictId         ; /*PMSTA15221-CHU-130116*/
extern FIELD_IDX_T A_Domain_RepStorageEn		           ; /*OCS-43245-TGU-130820*/
extern FIELD_IDX_T A_Domain_RepExecutionEn				   ; /*OCS-43245-TGU-130820*/
extern FIELD_IDX_T A_Domain_QueryDefinition                ; /* PMSTA18184-EFE-140528 */
extern FIELD_IDX_T A_Domain_ComputationModeEn              ; /*PMSTA-18426-CHU-140919*/
extern FIELD_IDX_T A_Domain_RiskRuleId                     ; /*PMSTA-18426-CHU-140919*/
extern FIELD_IDX_T A_Domain_ThirdId                        ;
extern FIELD_IDX_T A_Domain_NonEnumInstrFlg                ;
extern FIELD_IDX_T A_Domain_ReturnFctFlg                   ;
extern FIELD_IDX_T A_Domain_FundSplitLevel                 ;
extern FIELD_IDX_T A_Domain_FmtId                          ;
extern FIELD_IDX_T A_Domain_OutputTpEn                     ;
extern FIELD_IDX_T A_Domain_DataSetId                      ;
extern FIELD_IDX_T A_Domain_PpsId                          ;
extern FIELD_IDX_T A_Domain_DataProfId                     ;
extern FIELD_IDX_T A_Domain_InitialFctDictId               ;
extern FIELD_IDX_T A_Domain_ExternalDefinitionUrl          ; /*REF9510-BRO-030929*/
extern FIELD_IDX_T A_Domain_SelectOrderEntry               ; /*PMSTA02061-BRO-071130*/
extern FIELD_IDX_T A_Domain_GenerateCaseFlg                ; /* PMSTA08705 - 091104 - DDV - Activate case creation in CheckStrat */
extern FIELD_IDX_T A_Domain_CheckStratDuraFlg              ;
extern FIELD_IDX_T A_Domain_CheckStratBetaFlg              ;
extern FIELD_IDX_T A_Domain_CheckStratCrtYieldFlg          ;
extern FIELD_IDX_T A_Domain_CheckStratRatingFlg            ;
extern FIELD_IDX_T A_Domain_DebtFullCouponFlg              ;
extern FIELD_IDX_T A_Domain_OpNatEn                        ;
extern FIELD_IDX_T A_Domain_StratCheckReconcEn             ;
extern FIELD_IDX_T A_Domain_SysDate                        ;
extern FIELD_IDX_T A_Domain_PerfDetLevelEn                 ;
extern FIELD_IDX_T A_Domain_SavedOrderAllocNatEn           ; /*PMSTA03336-CHU-071030*/
extern FIELD_IDX_T A_Domain_RpcFctDictId                   ; /* PMSTA04773 - DDV - 071114 */
extern FIELD_IDX_T A_Domain_FullLoadHierProcessedFlg       ; /*PMSTA04637-CHU-080208*/
extern FIELD_IDX_T A_Domain_FullLoadHierOldPtfId           ; /*PMSTA04637-CHU-080208*/
extern FIELD_IDX_T A_Domain_FullLoadHierOldDimPtfDictId    ; /*PMSTA04637-CHU-080208*/
extern FIELD_IDX_T A_Domain_SaveZeroQtyFlg                 ; /* DLA - PMSTA04851 - 080312 */
extern FIELD_IDX_T A_Domain_ChunkNumber                    ; /* PMSTA9318-EFE-100209 */
extern FIELD_IDX_T A_Domain_TSLPtfDimModifiedFlg           ; /* PMSTA09899-CHU-100521 */
extern FIELD_IDX_T A_Domain_SavedDimEntityDictId           ; /* PMSTA09899-CHU-100521 */
extern FIELD_IDX_T A_Domain_SavedDimPtfDictId              ; /* PMSTA09899-CHU-100521 */
extern FIELD_IDX_T A_Domain_SavedPtfObjId                  ; /* PMSTA09899-CHU-100521 */
extern FIELD_IDX_T A_Domain_SavedPtfListDef                ; /* PMSTA09899-CHU-100521 */
extern FIELD_IDX_T A_Domain_SessionInErrorFlg              ; /* FPL-PMSTA10166-100714   */
extern FIELD_IDX_T A_Domain_CaseToClarify                  ; /* PMSTA10444-CHU-110405 */
extern FIELD_IDX_T A_Domain_Summary                        ; /*PMSTA11600-BRO-110504*/
extern FIELD_IDX_T A_Domain_LogCommentC                    ; /* PMSTA-11860-RBN-110420*/
extern FIELD_IDX_T A_Domain_SimulEvtGenNatEn               ; /* PMSTA14190-CHU-120429 */
extern FIELD_IDX_T A_Domain_WeightFlg                      ; /* PMSTA-14214 - JPP - 20120504 */
extern FIELD_IDX_T A_Domain_ExpandStratEn                  ; /* PMSTA-14214 - JPP - 20120504 */
extern FIELD_IDX_T A_Domain_InitialFromDate                ; /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */
extern FIELD_IDX_T A_Domain_MinTradingAmtFlg			   ;
extern FIELD_IDX_T A_Domain_DecisionState			       ; /* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T A_Domain_ApplSessionCd                  ; /* PMSTA-22549 - CHU - 160426 */
extern FIELD_IDX_T A_Domain_DlmModeEn                      ; /* PMSTA-24026 - DDV - 161019 */
extern FIELD_IDX_T A_Domain_InstrQueryDefinitionT          ; /* OCS-49233 - KIC - 170123 */
extern FIELD_IDX_T A_Domain_TaxLotEn                       ; /* PMSTA-28286-CHU-170905 */
extern FIELD_IDX_T A_Domain_PlanDefinitionId               ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_Domain_OrderSwitchingFctDictId		   ; /*PMSTA-35586 - Silpakal - 190516*/
extern FIELD_IDX_T A_Domain_OrderSwitchingFlg			   ; /*PMSTA-35586 - Silpakal - 190516*/
extern FIELD_IDX_T A_Domain_LoadHierHistFlg				   ; /*PMSTA-37064 - Vishnu   - 190904*/
extern FIELD_IDX_T A_Domain_GenOrderNettingEn			   ; /*PMSTA-37908 - adarshn  - 191119*/
extern FIELD_IDX_T A_Domain_MultiLvlModelMgmtFlg           ; /*PMSTA-37101 - vkumar   - 191205*/
extern FIELD_IDX_T A_Domain_NumberOfOrders                 ; /* 286: NumberType */ /*PMSTA-38945 - Kramadevi - 17022020*/
extern FIELD_IDX_T A_Domain_OrderNettingFctDictId          ; /* PMSTA-37908 - adarshn - 08032020*/
extern FIELD_IDX_T A_Domain_RebalMethodEn                  ; /* PMSTA-39048 - vkumar - 240220 */
extern FIELD_IDX_T A_Domain_QuasiCashEn                    ; /* PMSTA-39968 - Vishnu - 27042020*/
extern FIELD_IDX_T A_Domain_OrderAllocRuleEn			   ; /* PMSTA-40063 - vmuthu - 050520 */
extern FIELD_IDX_T A_Domain_OrderBuyAllocRuleEn			   ; /* PMSTA-40063 - vmuthu - 050520 */
extern FIELD_IDX_T A_Domain_CashRealignMethodEn            ; /* PMSTA-41494 - Kramadevi - 18082020*/
extern FIELD_IDX_T A_Domain_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule  */
extern FIELD_IDX_T A_Domain_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule  */
extern FIELD_IDX_T A_Domain_OrigPortObjId				   ; /* PMSTA-41704-lalby-to keep org pfid for overlay precomp */
extern FIELD_IDX_T A_Domain_HierGroupingFctDictId          ; /* PMSTA-40208 - adarshn - 28082020*/
extern FIELD_IDX_T A_Domain_OrderStatusFctDictId	       ; /* PMSTA-41770 - Vishnu -270920 : order sequencing*/
extern FIELD_IDX_T A_Domain_ComplianceMethodEn  	   ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_Domain_LoadReceivFlg                  ; /* PMSTA -42330 - CHANDRU - 01102020*/
extern FIELD_IDX_T A_Domain_CheckHierConsFlg;
extern FIELD_IDX_T A_Domain_HierHoldCheckFlg;
extern FIELD_IDX_T A_Domain_ConsiderWitReqFlg              ; /* PMSTA-43671 -adarshn- 10032021 */
extern FIELD_IDX_T A_Domain_HedgingTypeEn; /* PMSTA-44959 - LIK - 210429 */
extern FIELD_IDX_T A_Domain_OverHedgeFlg; /* PMSTA-44959 - LIK - 210429 */
extern FIELD_IDX_T A_Domain_InclNonManagedEn;    /* PMSTA-44324 - vishnu - 27042021 */
extern FIELD_IDX_T	A_Domain_OverrideFlg                   ; /*PMSTA-46649 - CHANDRU - 02112021*/
extern FIELD_IDX_T A_Domain_modelRebalEn;  /*PMSTA46691 - 151221 - ASahay*/
extern FIELD_IDX_T A_Domain_modelId;       /*PMSTA46691 - 151221 - ASahay*/
extern FIELD_IDX_T A_Domain_CheckSeverityRuleFlg;       /*PMSTA-47502-Lalby-04032022*/
extern FIELD_IDX_T A_Domain_PtfScopeEn                     ;	/* PMSTA - 48508 - CHANDRU - 18032022 */
extern FIELD_IDX_T A_Domain_CaseManagementGenFlg;       /* PMSTA-48704-LEK-220414 Enabling Case management for Check Strategy */
extern FIELD_IDX_T A_Domain_CaseManagementStorageFlg;       /* PMSTA-48704-LEK-220414 Enabling Case management for Check Strategy */
extern FIELD_IDX_T A_Domain_ForwardRenewalFlg              ; /* WEALTH-157 - KKM - 170423 */
extern FIELD_IDX_T A_Domain_LoadDimPtfHistFlg              ; /* PMSTA-48083 - JBC - 221012 */
extern FIELD_IDX_T A_Domain_PerfCalcDefProfId;             ; /* PMSTA-54529 - JBC - 230914 */
extern FIELD_IDX_T A_Domain_OrigLoadHierFlg                ; /* WEALTH-5157-Lalby-07032024 */
extern FIELD_IDX_T A_Domain_OrigBeginDate                  ; /* WEALTH-9917-Lalby-08082024- Historical group perf */
extern FIELD_IDX_T A_Domain_OrigEndDate                    ; /* WEALTH-9917-Lalby-08082024- Historical group perf */
extern FIELD_IDX_T A_Domain_PtfHierChangeFlg               ; /* PMSTA-64818 - Deepthi - 20250210 */

extern FIELD_IDX_T S_Domain_Id                             ;
extern FIELD_IDX_T S_Domain_CurrId                         ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_DimPtfDictId                   ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_DimInstrDictId                 ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_UsrId                          ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_LangDictId                     ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_FctDictId                      ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_ScenaId                        ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_QuoteValRuleId                 ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_ExchValRuleId                  ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_PtfObjId                       ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_InstrObjId                     ;    /*  PMSTA-11731-HFI-110203  */
extern FIELD_IDX_T S_Domain_FctResultId;						/* PMSTA-30891 - RAK - 180430 */
extern FIELD_IDX_T S_Domain_ExtStratEltNatAllocFlg;				/* PMSTA-30891 - RAK - 180430 */
extern FIELD_IDX_T S_Domain_TaxLotEn                       ;    /* PMSTA-34295 - sanand - 100319 */
extern FIELD_IDX_T S_Domain_InitDimFlg;

extern FIELD_IDX_T A_Empty_Id                              ;


extern FIELD_IDX_T A_EvtExcl_Id                            ;
extern FIELD_IDX_T A_EvtExcl_IssueDecisFlg                 ;


extern FIELD_IDX_T S_EvtExcl_Id                            ;


extern FIELD_IDX_T A_ExchFmt_CurrId                        ;
extern FIELD_IDX_T A_ExchFmt_UnderCurrId                   ;
extern FIELD_IDX_T A_ExchFmt_Mult                          ;
extern FIELD_IDX_T A_ExchFmt_InverseFlg                    ;


extern FIELD_IDX_T S_ExchFmt_CurrId                        ;
extern FIELD_IDX_T S_ExchFmt_UnderCurrId                   ;
extern FIELD_IDX_T S_ExchFmt_UnderCurrCd                   ;
extern FIELD_IDX_T S_ExchFmt_Mult                          ;
extern FIELD_IDX_T S_ExchFmt_InverseFlg                    ;


extern FIELD_IDX_T A_ExchRate_CurrId                       ;
extern FIELD_IDX_T A_ExchRate_UnderCurrId                  ;
extern FIELD_IDX_T A_ExchRate_TpId                         ;
extern FIELD_IDX_T A_ExchRate_ThirdId                      ;
extern FIELD_IDX_T A_ExchRate_MktThirdId                   ;
extern FIELD_IDX_T A_ExchRate_ExchDate                     ;
extern FIELD_IDX_T A_ExchRate_DailyDfltFlg                 ;
extern FIELD_IDX_T A_ExchRate_ExchRate                     ;
extern FIELD_IDX_T A_ExchRate_ValRuleId                    ;
extern FIELD_IDX_T A_ExchRate_ValRuleEltId                 ;
extern FIELD_IDX_T A_ExchRate_ValRuleCoef                  ;
extern FIELD_IDX_T A_ExchRate_CoefNatEn                    ;
extern FIELD_IDX_T A_ExchRate_InverseFlg                   ;


extern FIELD_IDX_T S_ExchRate_CurrId                       ;
extern FIELD_IDX_T S_ExchRate_UnderCurrId                  ;
extern FIELD_IDX_T S_ExchRate_TpId                         ;
extern FIELD_IDX_T S_ExchRate_ThirdId                      ;
extern FIELD_IDX_T S_ExchRate_MktThirdId                   ;
extern FIELD_IDX_T S_ExchRate_ExchDate                     ;
extern FIELD_IDX_T S_ExchRate_CurrCd                       ;
extern FIELD_IDX_T S_ExchRate_UnderCurrCd                  ;
extern FIELD_IDX_T S_ExchRate_TpCd                         ;
extern FIELD_IDX_T S_ExchRate_ThirdCd                      ;
extern FIELD_IDX_T S_ExchRate_ExchRate                     ;
extern FIELD_IDX_T S_ExchRate_MktThirdCd                   ; /* PMSTA-32142 CMILOS 130918 */

extern FIELD_IDX_T A_ExtRetAnalysis_Id                     ;
extern FIELD_IDX_T A_ExtRetAnalysis_PerfStorParamId        ;
extern FIELD_IDX_T A_ExtRetAnalysis_EntDictId              ;
extern FIELD_IDX_T A_ExtRetAnalysis_ObjId                  ;
extern FIELD_IDX_T A_ExtRetAnalysis_FreqEn                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_CurrId                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_PosDataId              ;
extern FIELD_IDX_T A_ExtRetAnalysis_GridId                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_PerfAttribRtnEn        ;
extern FIELD_IDX_T A_ExtRetAnalysis_InitialDate            ;
extern FIELD_IDX_T A_ExtRetAnalysis_FinalDate              ;
extern FIELD_IDX_T A_ExtRetAnalysis_MktSegtId              ;
extern FIELD_IDX_T A_ExtRetAnalysis_InstrId                ;
extern FIELD_IDX_T A_ExtRetAnalysis_InitialMktVal          ;
extern FIELD_IDX_T A_ExtRetAnalysis_FinalMktVal            ;
extern FIELD_IDX_T A_ExtRetAnalysis_Fees                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_Taxes                  ;
extern FIELD_IDX_T A_ExtRetAnalysis_Flows                  ;
extern FIELD_IDX_T A_ExtRetAnalysis_ProfitLoss             ;
extern FIELD_IDX_T A_ExtRetAnalysis_FlowMeanCap            ;
extern FIELD_IDX_T A_ExtRetAnalysis_MeanCapital            ;
extern FIELD_IDX_T A_ExtRetAnalysis_Rtn                    ;
extern FIELD_IDX_T A_ExtRetAnalysis_Adjust                 ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_ExtRetAnalysis_RtnGross               ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_ExtRetAnalysis_TaxCredit              ;
extern FIELD_IDX_T A_ExtRetAnalysis_DeltaNetGross          ;
extern FIELD_IDX_T A_ExtRetAnalysis_Dividend               ;
extern FIELD_IDX_T A_ExtRetAnalysis_MeanInvestCap          ;
extern FIELD_IDX_T A_ExtRetAnalysis_Rtn1                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_Invest                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_Withdr                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_Inc1                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_Inc2                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_CapPl1                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_CapPl2                 ;
extern FIELD_IDX_T A_ExtRetAnalysis_CurrPl1                ;
extern FIELD_IDX_T A_ExtRetAnalysis_CurrPl2                ;
extern FIELD_IDX_T A_ExtRetAnalysis_Rtn2                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_Rtn3                   ;
extern FIELD_IDX_T A_ExtRetAnalysis_CapEffect              ;
extern FIELD_IDX_T A_ExtRetAnalysis_CurrEffect             ;
extern FIELD_IDX_T A_ExtRetAnalysis_FeesTaxEffect          ;
extern FIELD_IDX_T A_ExtRetAnalysis_IncEffect              ;
extern FIELD_IDX_T A_ExtRetAnalysis_PortSynthId            ;
extern FIELD_IDX_T A_ExtRetAnalysis_GblExtRetAnalysisId    ;
extern FIELD_IDX_T A_ExtRetAnalysis_ExtStratEltId          ;
extern FIELD_IDX_T A_ExtRetAnalysis_InstrFreqId            ;
extern FIELD_IDX_T A_ExtRetAnalysis_PtfFreqId              ;
extern FIELD_IDX_T A_ExtRetAnalysis_RiskFreeId             ;
extern FIELD_IDX_T A_ExtRetAnalysis_BenchId                ;
extern FIELD_IDX_T A_ExtRetAnalysis_ParentId               ;
extern FIELD_IDX_T A_ExtRetAnalysis_AbcissaRank            ;
extern FIELD_IDX_T A_ExtRetAnalysis_OrdinateRank           ;
extern FIELD_IDX_T A_ExtRetAnalysis_CompletePeriodFlg      ; /* REF9770 - LJE - 031212 */
extern FIELD_IDX_T A_ExtRetAnalysis_RecInfoMask            ;
extern FIELD_IDX_T A_ExtRetAnalysis_PreviousId             ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_NextId                 ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_OverPeriodId           ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_ParentObjId            ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_ExtRetAnalysis_MergeParentObjId       ;
extern FIELD_IDX_T A_ExtRetAnalysis_BreakCriteria          ; /* REF9187 - LJE - 030625 */
extern FIELD_IDX_T A_ExtRetAnalysis_ParentBreakCriteria    ; /* REF9344 - LJE - 031014 */
extern FIELD_IDX_T A_ExtRetAnalysis_GblExtRetAnalysis_Ext  ;
extern FIELD_IDX_T A_ExtRetAnalysis_RiskFree_Ext           ;
extern FIELD_IDX_T A_ExtRetAnalysis_Bench_Ext              ;
extern FIELD_IDX_T A_ExtRetAnalysis_Parent_Ext             ;
extern FIELD_IDX_T A_ExtRetAnalysis_Previous_Ext           ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_Next_Ext               ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_OverPeriod_Ext         ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_ExtRetAnalysis_ParentObj_Ext          ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_ExtRetAnalysis_PerfCalcResult_Ext     ;
extern FIELD_IDX_T A_ExtRetAnalysis_SubSetBreakCriteria    ;  /* REF10276 - LJE - 041110 : For optim */
extern FIELD_IDX_T A_ExtRetAnalysis_PerfTimRuleEn          ;  /* PMSTA-42147 - lalby - 10022021 */
extern FIELD_IDX_T A_ExtRetAnalysis_FirstOpNatEn           ;  /* PMSTA-42147 - lalby - 10022021 */
extern FIELD_IDX_T A_ExtRetAnalysis_HeadPtf_Ext            ;  /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
extern FIELD_IDX_T A_ExtRetAnalysis_RecStatusEn            ;  /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */
extern FIELD_IDX_T A_ExtRetAnalysis_PtfInAdjust            ;  /* WEALTH-9725 - Lalby - 25062024- Manage Ptf in and out using PCP */
extern FIELD_IDX_T A_ExtRetAnalysis_PtfOutAdjust           ;
extern FIELD_IDX_T A_ExtRetAnalysis_MktSegInAdjust         ;
extern FIELD_IDX_T A_ExtRetAnalysis_MktSegOutAdjust        ;

extern FIELD_IDX_T S_ExtRetAnalysis_Id                     ;
extern FIELD_IDX_T S_ExtRetAnalysis_PerfStorParamId        ;
extern FIELD_IDX_T S_ExtRetAnalysis_EntDictId              ;
extern FIELD_IDX_T S_ExtRetAnalysis_ObjId                  ;
extern FIELD_IDX_T S_ExtRetAnalysis_FreqEn                 ;
extern FIELD_IDX_T S_ExtRetAnalysis_CurrId                 ;
extern FIELD_IDX_T S_ExtRetAnalysis_PosDataId              ;
extern FIELD_IDX_T S_ExtRetAnalysis_GridId                 ;
extern FIELD_IDX_T S_ExtRetAnalysis_PerfAttribRtnEn        ;
extern FIELD_IDX_T S_ExtRetAnalysis_InitialDate            ;
extern FIELD_IDX_T S_ExtRetAnalysis_FinalDate              ;
extern FIELD_IDX_T S_ExtRetAnalysis_MktSegtId              ;
extern FIELD_IDX_T S_ExtRetAnalysis_InstrId                ;


extern FIELD_IDX_T Freq_ExchRate_CurrId                    ;
extern FIELD_IDX_T Freq_ExchRate_UnderCurrId               ;
extern FIELD_IDX_T Freq_ExchRate_TpId                      ;
extern FIELD_IDX_T Freq_ExchRate_ThirdId                   ;
extern FIELD_IDX_T Freq_ExchRate_MktThirdId                ;
extern FIELD_IDX_T Freq_ExchRate_ExchDate                  ;
extern FIELD_IDX_T Freq_ExchRate_DailyDfltFlg              ;
extern FIELD_IDX_T Freq_ExchRate_ExchRate                  ;
extern FIELD_IDX_T Freq_ExchRate_RequestDate               ;


extern FIELD_IDX_T A_FctResult_Id                          ;
extern FIELD_IDX_T A_FctResult_Cd                          ;
extern FIELD_IDX_T A_FctResult_FctDictId                   ;
extern FIELD_IDX_T A_FctResult_DomainId                    ;
extern FIELD_IDX_T A_FctResult_UserId                      ;
extern FIELD_IDX_T A_FctResult_ModifDate                   ;
extern FIELD_IDX_T A_FctResult_CalcFromDate                ;
extern FIELD_IDX_T A_FctResult_CalcTillDate                ;
extern FIELD_IDX_T A_FctResult_CalcRefDate                 ;
extern FIELD_IDX_T A_FctResult_CalcStratDate               ;
extern FIELD_IDX_T A_FctResult_CalcFreqDate                ;
extern FIELD_IDX_T A_FctResult_StatusEn                    ;
extern FIELD_IDX_T A_FctResult_DimPtfDictId                ;
extern FIELD_IDX_T A_FctResult_PtfObjId                    ;
extern FIELD_IDX_T A_FctResult_DimInstrDictId              ;
extern FIELD_IDX_T A_FctResult_InstrObjId                  ;
extern FIELD_IDX_T A_FctResult_DimStratDictId              ;
extern FIELD_IDX_T A_FctResult_StratObjId                  ;

extern FIELD_IDX_T S_FctResult_Id                          ;
extern FIELD_IDX_T S_FctResult_Cd                          ;
extern FIELD_IDX_T S_FctResult_FctName                     ;
extern FIELD_IDX_T S_FctResult_DomainId                    ;
extern FIELD_IDX_T S_FctResult_DimPtfSqlName               ;
extern FIELD_IDX_T S_FctResult_PtfObjCd                    ;
extern FIELD_IDX_T S_FctResult_DimInstrSqlName             ;
extern FIELD_IDX_T S_FctResult_InstrObjCd                  ;
extern FIELD_IDX_T S_FctResult_DimStratSqlName             ;
extern FIELD_IDX_T S_FctResult_StratObjCd                  ;
extern FIELD_IDX_T S_FctResult_MinStatusEn                 ;
extern FIELD_IDX_T S_FctResult_MaxStatusEn                 ;
extern FIELD_IDX_T S_FctResult_ModifDate                   ;
extern FIELD_IDX_T S_FctResult_CalcFromDate                ;
extern FIELD_IDX_T S_FctResult_CalcTillDate                ;
extern FIELD_IDX_T S_FctResult_CalcRefDate                 ;
extern FIELD_IDX_T S_FctResult_CalcStratDate               ;
extern FIELD_IDX_T S_FctResult_CalcFreqDate                ;
extern FIELD_IDX_T S_FctResult_StatusEn                    ;
extern FIELD_IDX_T S_FctResult_FctDictId                   ;        /*  FIH-REF10295-040621 */


extern FIELD_IDX_T A_FctSecuProfCompo_FctSecuProfId        ;
extern FIELD_IDX_T A_FctSecuProfCompo_FctDictId            ;
extern FIELD_IDX_T A_FctSecuProfCompo_EntDictId            ;
extern FIELD_IDX_T A_FctSecuProfCompo_TpId                 ;
extern FIELD_IDX_T A_FctSecuProfCompo_SubTpId              ;
extern FIELD_IDX_T A_FctSecuProfCompo_MinStatEn            ;
extern FIELD_IDX_T A_FctSecuProfCompo_MaxStatEn            ;
extern FIELD_IDX_T A_FctSecuProfCompo_CreateFlg            ;
extern FIELD_IDX_T A_FctSecuProfCompo_UpdFlg               ;
extern FIELD_IDX_T A_FctSecuProfCompo_DelFlg               ;
extern FIELD_IDX_T A_FctSecuProfCompo_SecuLevelEn          ;
extern FIELD_IDX_T A_FctSecuProfCompo_RiskViewFlg          ;
extern FIELD_IDX_T A_FctSecuProfCompo_RealTimeFlg          ;
extern FIELD_IDX_T A_FctSecuProfCompo_ViewFlg              ;
extern FIELD_IDX_T A_FctSecuProfCompo_VisibleFlg           ;
extern FIELD_IDX_T A_FctSecuProfCompo_SlicingTreshold      ; /*<PMSTA11810-BRO-110415*/
extern FIELD_IDX_T A_FctSecuProfCompo_AsyncTreshold        ;
extern FIELD_IDX_T A_FctSecuProfCompo_ExecTreshold         ; /*>PMSTA11810-BRO-110415*/
extern FIELD_IDX_T A_FctSecuProfCompo_MaxStatusParam	   ; /* PMSTA-12034 RBN 09/08/11*/
extern FIELD_IDX_T A_FctSecuProfCompo_MinStatusParam	   ; /* PMSTA-12034 RBN 09/08/11*/


extern FIELD_IDX_T S_FctSecuProfCompo_FctSecuProfId        ;
extern FIELD_IDX_T S_FctSecuProfCompo_FctDictId            ;
extern FIELD_IDX_T S_FctSecuProfCompo_EntDictId            ;
extern FIELD_IDX_T S_FctSecuProfCompo_TpId                 ;
extern FIELD_IDX_T S_FctSecuProfCompo_SubTpId              ;
extern FIELD_IDX_T S_FctSecuProfCompo_MinStatEn            ;
extern FIELD_IDX_T S_FctSecuProfCompo_MaxStatEn            ;
extern FIELD_IDX_T S_FctSecuProfCompo_CreateFlg            ;
extern FIELD_IDX_T S_FctSecuProfCompo_UpdFlg               ;
extern FIELD_IDX_T S_FctSecuProfCompo_DelFlg               ;
extern FIELD_IDX_T S_FctSecuProfCompo_SecuLevelEn          ;
extern FIELD_IDX_T S_FctSecuProfCompo_RiskViewFlg          ;
extern FIELD_IDX_T S_FctSecuProfCompo_RealTimeFlg          ;
extern FIELD_IDX_T S_FctSecuProfCompo_FctName              ;
extern FIELD_IDX_T S_FctSecuProfCompo_EntSqlName           ;
extern FIELD_IDX_T S_FctSecuProfCompo_TpCd                 ;
extern FIELD_IDX_T S_FctSecuProfCompo_SubTpCd              ;
extern FIELD_IDX_T S_FctSecuProfCompo_ViewFlg              ;


extern FIELD_IDX_T A_FctSecuProf_Id                        ;
extern FIELD_IDX_T A_FctSecuProf_Cd                        ;


extern FIELD_IDX_T S_FctSecuProf_Id                        ;
extern FIELD_IDX_T S_FctSecuProf_Cd                        ;

extern FIELD_IDX_T E_Fmt_Id                                ;
extern FIELD_IDX_T E_Fmt_Cd                                ;
extern FIELD_IDX_T E_Fmt_Name                              ;
extern FIELD_IDX_T E_Fmt_Denom                             ;
extern FIELD_IDX_T E_Fmt_FctDictId                         ;
extern FIELD_IDX_T E_Fmt_ParFmtId                          ;
extern FIELD_IDX_T E_Fmt_EntDictId                         ;
extern FIELD_IDX_T E_Fmt_RiskFlg                           ;
extern FIELD_IDX_T E_Fmt_NatEn                             ;
extern FIELD_IDX_T E_Fmt_BreakCritName                     ;
extern FIELD_IDX_T E_Fmt_BreakVal                          ;
extern FIELD_IDX_T E_Fmt_Filter                            ;
extern FIELD_IDX_T E_Fmt_GraphTpEn                         ;
extern FIELD_IDX_T E_Fmt_GraphViewEn                       ;
extern FIELD_IDX_T E_Fmt_Overlap                           ;
extern FIELD_IDX_T E_Fmt_ModifDate                         ;
extern FIELD_IDX_T E_Fmt_LevelNum                          ;
extern FIELD_IDX_T E_Fmt_IconName                          ;
extern FIELD_IDX_T E_Fmt_MaxBreak                          ;
extern FIELD_IDX_T E_Fmt_Rank                              ;
extern FIELD_IDX_T E_Fmt_DfltFlg                           ;
extern FIELD_IDX_T E_Fmt_ScreenDictId                      ;
extern FIELD_IDX_T E_Fmt_AutoWidthFlg                      ;    /*  FPL-PMSTA09887-101206   */
extern FIELD_IDX_T E_Fmt_ReferenceFmtId                    ;    /*  HFI-PMSTA-38117-200228  */
extern FIELD_IDX_T E_Fmt_ReferenceStatusEn                 ;    /*  HFI-PMSTA-38117-200228  */
extern FIELD_IDX_T E_Fmt_E_ChildFmt_Ext                    ;
extern FIELD_IDX_T E_Fmt_A_FmtElt_Ext                      ;

extern FIELD_IDX_T Sum_FmtElt_FmtId                        ;
extern FIELD_IDX_T Sum_FmtElt_FmtCd                        ;
extern FIELD_IDX_T Sum_FmtElt_FmtName                      ;
extern FIELD_IDX_T Sum_FmtElt_FmtDenom                     ;
extern FIELD_IDX_T Sum_FmtElt_FmtFctDictId                 ;
extern FIELD_IDX_T Sum_FmtElt_FmtParFmtId                  ;
extern FIELD_IDX_T Sum_FmtElt_FmtEntDictId                 ;
extern FIELD_IDX_T Sum_FmtElt_FmtRiskFlg                   ;
extern FIELD_IDX_T Sum_FmtElt_FmtNatEn                     ;
extern FIELD_IDX_T Sum_FmtElt_FmtBreakCritName             ;
extern FIELD_IDX_T Sum_FmtElt_FmtBreakVal                  ;
extern FIELD_IDX_T Sum_FmtElt_FmtFilter                    ;
extern FIELD_IDX_T Sum_FmtElt_FmtGraphTpEn                 ;
extern FIELD_IDX_T Sum_FmtElt_FmtGraphViewEn               ;
extern FIELD_IDX_T Sum_FmtElt_FmtOverlap                   ;
extern FIELD_IDX_T Sum_FmtElt_FmtModifDate                 ;
extern FIELD_IDX_T Sum_FmtElt_FmtLevelNum                  ;
extern FIELD_IDX_T Sum_FmtElt_FmtIconName                  ;
extern FIELD_IDX_T Sum_FmtElt_FmtMaxBreak                  ;
extern FIELD_IDX_T Sum_FmtElt_FmtScreenDictId              ;
extern FIELD_IDX_T Sum_FmtElt_Id                           ;
extern FIELD_IDX_T Sum_FmtElt_SqlName                      ;
extern FIELD_IDX_T Sum_FmtElt_Rank                         ;
extern FIELD_IDX_T Sum_FmtElt_Name                         ;
extern FIELD_IDX_T Sum_FmtElt_Denom                        ;
extern FIELD_IDX_T Sum_FmtElt_DataTpDictId                 ;
extern FIELD_IDX_T Sum_FmtElt_AttrDictId                   ;
extern FIELD_IDX_T Sum_FmtElt_DspFmt                       ;
extern FIELD_IDX_T Sum_FmtElt_DspCol                       ;
extern FIELD_IDX_T Sum_FmtElt_DspRow                       ;
extern FIELD_IDX_T Sum_FmtElt_DspContext                   ;
extern FIELD_IDX_T Sum_FmtElt_FxdFlg                       ;
extern FIELD_IDX_T Sum_FmtElt_ConsFlg                      ;
extern FIELD_IDX_T Sum_FmtElt_SubTotFlg                    ;
extern FIELD_IDX_T Sum_FmtElt_Tot                          ;
extern FIELD_IDX_T Sum_FmtElt_SrtRank                      ;
extern FIELD_IDX_T Sum_FmtElt_SrtRuleEn                    ;
extern FIELD_IDX_T Sum_FmtElt_HorizCoord                   ;
extern FIELD_IDX_T Sum_FmtElt_VertCoord                    ;
extern FIELD_IDX_T Sum_FmtElt_ColWidth                     ;
extern FIELD_IDX_T Sum_FmtElt_ZoomFlg                      ;
extern FIELD_IDX_T Sum_FmtElt_BackgrCol                    ;
extern FIELD_IDX_T Sum_FmtElt_ForegrCol                    ;
extern FIELD_IDX_T Sum_FmtElt_ItalicFlg                    ;
extern FIELD_IDX_T Sum_FmtElt_BoldFlg                      ;
extern FIELD_IDX_T Sum_FmtElt_JustifEn                     ;
extern FIELD_IDX_T Sum_FmtElt_EditFlg                      ;
extern FIELD_IDX_T Sum_FmtElt_HierNatEn                    ;
extern FIELD_IDX_T Sum_FmtElt_TlsMultilingualEn            ; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
extern FIELD_IDX_T Sum_FmtElt_LangDictId                   ; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
extern FIELD_IDX_T Sum_FmtElt_TslProcessingNatEn           ; /* PMSTA11612 - 110524 - DDV - TSL Multilingual & Other TSL improvement */
extern FIELD_IDX_T Sum_FmtElt_Definition                   ;
extern FIELD_IDX_T Sum_FmtElt_ClassifId                    ;
extern FIELD_IDX_T Sum_FmtElt_ColNb                        ;
extern FIELD_IDX_T Sum_FmtElt_DataSetNb                    ;
extern FIELD_IDX_T Sum_FmtElt_DataSetBreakCriteria         ; /* PMSTA09776 - DDV - 100505 */


extern FIELD_IDX_T A_FmtProf_Id                            ;
extern FIELD_IDX_T A_FmtProf_Cd                            ;
extern FIELD_IDX_T A_FmtProf_OwnerUserId                   ;


extern FIELD_IDX_T S_FmtProf_Id                            ;
extern FIELD_IDX_T S_FmtProf_Cd                            ;


extern FIELD_IDX_T A_FmtProfCompo_Id                       ;
extern FIELD_IDX_T A_FmtProfCompo_FmtProfId                ;
extern FIELD_IDX_T A_FmtProfCompo_FmtId                    ;
extern FIELD_IDX_T A_FmtProfCompo_RefFmtId                 ;
extern FIELD_IDX_T A_FmtProfCompo_Rank                     ;
extern FIELD_IDX_T A_FmtProfCompo_DfltFlg                  ;


extern FIELD_IDX_T S_FmtProfCompo_Id                       ;
extern FIELD_IDX_T S_FmtProfCompo_FmtProfId                ;
extern FIELD_IDX_T S_FmtProfCompo_FmtId                    ;
extern FIELD_IDX_T S_FmtProfCompo_Rank                     ;
extern FIELD_IDX_T S_FmtProfCompo_FmtProfCd                ;
extern FIELD_IDX_T S_FmtProfCompo_FmtCd                    ;
extern FIELD_IDX_T S_FmtProfCompo_FctName                  ;
extern FIELD_IDX_T S_FmtProfCompo_FmtNatEn                 ;


/* PCC13654 - LJE - 090624 */
extern FIELD_IDX_T A_InputEntity_Sqlname                   ;
extern FIELD_IDX_T A_InputEntity_Param                     ;
extern FIELD_IDX_T A_InputEntity_OutputTypeEn              ;
extern FIELD_IDX_T A_InputEntity_OptionEn                  ;
extern FIELD_IDX_T A_InputEntity_ScreenDictId              ;
extern FIELD_IDX_T A_InputEntity_UserId                    ;
extern FIELD_IDX_T A_InputEntity_DataProfileId             ;
extern FIELD_IDX_T A_InputEntity_LanguageDictId            ;
extern FIELD_IDX_T A_InputEntity_FunctionDictId            ;
extern FIELD_IDX_T A_InputEntity_Codifications             ;
extern FIELD_IDX_T A_InputEntity_TextConverterEn           ;
extern FIELD_IDX_T A_InputEntity_ApplSessionCd             ; /* PMSTA-22549 - CHU - 160512 */

extern FIELD_IDX_T A_OutputEntity_Rank                     ;
extern FIELD_IDX_T A_OutputEntity_Result                   ;

extern FIELD_IDX_T A_OutputPermVal_AttibSqlname            ;
extern FIELD_IDX_T A_OutputPermVal_Rank                    ;
extern FIELD_IDX_T A_OutputPermVal_Result                  ;

extern FIELD_IDX_T A_OutputMsg_FullName                    ;
extern FIELD_IDX_T A_OutputMsg_NatEn                       ;
extern FIELD_IDX_T A_OutputMsg_Rank                        ;
extern FIELD_IDX_T A_OutputMsg_Message                     ;

extern FIELD_IDX_T A_Folder_Id                             ;
extern FIELD_IDX_T A_Folder_Cd                             ;
extern FIELD_IDX_T A_Folder_Name                           ;
extern FIELD_IDX_T A_Folder_UserId                         ;
extern FIELD_IDX_T A_Folder_CrtFlag                        ;
extern FIELD_IDX_T A_Folder_Rank                           ;
extern FIELD_IDX_T A_Folder_LastNoteDate                   ;
extern FIELD_IDX_T A_Folder_IconName                       ;


extern FIELD_IDX_T S_Folder_Id                             ;
extern FIELD_IDX_T S_Folder_Cd                             ;
extern FIELD_IDX_T S_Folder_Name                           ;
extern FIELD_IDX_T S_Folder_UserId                         ;


extern FIELD_IDX_T A_FundVal_Id                            ;
extern FIELD_IDX_T A_FundVal_PtfId                         ;
extern FIELD_IDX_T A_FundVal_ValuationDate                 ;
extern FIELD_IDX_T A_FundVal_ValoSeqNo                     ;
extern FIELD_IDX_T A_FundVal_OfficialFlg                   ;


extern FIELD_IDX_T S_FundVal_Id                            ;
extern FIELD_IDX_T S_FundVal_PtfId                         ;
extern FIELD_IDX_T S_FundVal_ValuationDate                 ;
extern FIELD_IDX_T S_FundVal_ValoSeqNo                     ;
extern FIELD_IDX_T S_FundVal_OfficialFlg                   ;


extern FIELD_IDX_T A_FundValElt_Id                         ;
extern FIELD_IDX_T A_FundValElt_FundValId                  ;
extern FIELD_IDX_T A_FundValElt_AccPlanEltId               ;
extern FIELD_IDX_T A_FundValElt_InstrId                    ;
extern FIELD_IDX_T A_FundValElt_ValuationAmt               ;


extern FIELD_IDX_T S_FundValElt_Id                         ;
extern FIELD_IDX_T S_FundValElt_FundValId                  ;
extern FIELD_IDX_T S_FundValElt_AccPlanEltId               ;
extern FIELD_IDX_T S_FundValElt_InstrId                    ;
extern FIELD_IDX_T S_FundValElt_ValuationAmt               ;
extern FIELD_IDX_T S_FundValElt_PtfId                      ;
extern FIELD_IDX_T S_FundValElt_ValuationDate              ;
extern FIELD_IDX_T S_FundValElt_ValoSeqNo                  ;
extern FIELD_IDX_T S_FundValElt_AccPlanEltName             ;
extern FIELD_IDX_T S_FundValElt_AccPlanEltDenom            ;
extern FIELD_IDX_T S_FundValElt_ItemDisp                   ;
extern FIELD_IDX_T S_FundValElt_ItemNatEn                  ;


extern FIELD_IDX_T A_FundWgt_InstrId                       ;
extern FIELD_IDX_T A_FundWgt_BegDate                       ;
extern FIELD_IDX_T A_FundWgt_PtfId                         ;
extern FIELD_IDX_T A_FundWgt_WgtPrct                       ;
extern FIELD_IDX_T A_FundWgt_ShareNum                      ;


extern FIELD_IDX_T S_FundWgt_InstrId                       ;
extern FIELD_IDX_T S_FundWgt_BegDate                       ;
extern FIELD_IDX_T S_FundWgt_PtfId                         ;
extern FIELD_IDX_T S_FundWgt_InstrCd                       ;
extern FIELD_IDX_T S_FundWgt_WgtPrct                       ;
extern FIELD_IDX_T S_FundWgt_ShareNum                      ;


extern FIELD_IDX_T A_Event_Id                              ;
extern FIELD_IDX_T A_Event_FunctionResultId                ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T A_Event_Hostname                        ;
extern FIELD_IDX_T A_Event_User                            ;
extern FIELD_IDX_T A_Event_StatusEn                        ;
extern FIELD_IDX_T A_Event_NatureEn                        ;
extern FIELD_IDX_T A_Event_EntSqlName                      ;
extern FIELD_IDX_T A_Event_FctSqlName                      ;
extern FIELD_IDX_T A_Event_ActionEn                        ;
extern FIELD_IDX_T A_Event_ModuleEn                        ;
extern FIELD_IDX_T A_Event_CreationDate                    ;
extern FIELD_IDX_T A_Event_ExecutionDate                   ;
extern FIELD_IDX_T A_Event_UpdateStsName                   ;
extern FIELD_IDX_T A_Event_MapStorage                      ;
extern FIELD_IDX_T A_Event_FormatId                        ;
extern FIELD_IDX_T A_Event_DestinationCd                   ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T A_Event_Priority                        ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T A_Event_OperationStatusEn               ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T A_Event_OperationCd                     ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T A_Event_SubscriptionCd                  ; /* DLA - REF10247 - 050714 */
extern FIELD_IDX_T A_Event_OpTimeStamp                     ; /* DLA - PMSTA05995 - 080407 */
extern FIELD_IDX_T A_Event_Data                            ;
extern FIELD_IDX_T A_Event_BusEntityCd                     ; /* PMSTA-17089 - DDV - 131202 */
extern FIELD_IDX_T A_Event_RequestStatusEn                 ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T A_Event_EventStatusFlg                  ; /* PMSTA-17112 - PCL - 131217 */
extern FIELD_IDX_T A_Event_GroupingCode                    ; /* PMSTA-17793 - DDV - 140314 */

extern FIELD_IDX_T S_Event_Id                              ;
extern FIELD_IDX_T S_Event_FunctionResultId                ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T S_Event_Hostname                        ;
extern FIELD_IDX_T S_Event_User                            ;
extern FIELD_IDX_T S_Event_CreationDate                    ;
extern FIELD_IDX_T S_Event_NatureEn                        ;
extern FIELD_IDX_T S_Event_EntSqlName                      ;
extern FIELD_IDX_T S_Event_FctSqlName                      ;
extern FIELD_IDX_T S_Event_ActionEn                        ;
extern FIELD_IDX_T S_Event_StatusEn                        ;
extern FIELD_IDX_T S_Event_DestinationCd                   ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T S_Event_Priority                        ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T S_Event_OperationStatusEn               ; /* DLA - REF10247 - 050708 */
extern FIELD_IDX_T S_Event_OperationCd                     ; /* DLA - REF10247 - 050708 */


extern FIELD_IDX_T A_EventUpdate_LastModifDate             ;

extern FIELD_IDX_T A_FamilyDef_Id                          ;
extern FIELD_IDX_T A_FamilyDef_DynSt                       ;
extern FIELD_IDX_T A_FamilyDef_ParentFldIdx                ;
extern FIELD_IDX_T A_FamilyDef_IdFldIdx                    ;
extern FIELD_IDX_T A_FamilyDef_RootNb                      ;
extern FIELD_IDX_T A_FamilyDef_RootExt                     ;

extern FIELD_IDX_T A_FamilyElt_FamilyId                    ;
extern FIELD_IDX_T A_FamilyElt_FamilyExt                   ;
extern FIELD_IDX_T A_FamilyElt_EltId                       ;
extern FIELD_IDX_T A_FamilyElt_EltExt                      ;
extern FIELD_IDX_T A_FamilyElt_ParentId                    ;
extern FIELD_IDX_T A_FamilyElt_ParentExt                   ;
extern FIELD_IDX_T A_FamilyElt_ChildrenExt                 ;


extern FIELD_IDX_T A_Grid_Id                               ;
extern FIELD_IDX_T A_Grid_Cd                               ;
extern FIELD_IDX_T A_Grid_Name                             ;
extern FIELD_IDX_T A_Grid_Denom                            ;
extern FIELD_IDX_T A_Grid_TypeId                           ; /*REF11734-EFE-060320*/
extern FIELD_IDX_T A_Grid_ParMktSegtId                     ;
extern FIELD_IDX_T A_Grid_AbcissaClassifId                 ;
extern FIELD_IDX_T A_Grid_OrdinateClassifId                ;
extern FIELD_IDX_T A_Grid_PrimGridFlg                      ;
extern FIELD_IDX_T A_Grid_NatEn                            ;
extern FIELD_IDX_T A_Grid_GlobalGridId                     ;
extern FIELD_IDX_T A_Grid_DataSecuProfId                   ; /*PMSTA07407-BRO-090529*/
extern FIELD_IDX_T A_Grid_Abcissa_A_Classif_Ext            ;
extern FIELD_IDX_T A_Grid_Ordinate_A_Classif_Ext           ;
extern FIELD_IDX_T A_Grid_S_MktSegt_Ext                    ;
extern FIELD_IDX_T A_Grid_ListCompoLevel                   ;
extern FIELD_IDX_T A_Grid_ParMktSegtGridId;


extern FIELD_IDX_T S_Grid_Id                               ;
extern FIELD_IDX_T S_Grid_Cd                               ;
extern FIELD_IDX_T S_Grid_Name                             ;
extern FIELD_IDX_T S_Grid_NatEn                            ;
extern FIELD_IDX_T S_Grid_GlobalGridId                     ; /*PMSTA07407-BRO-090529*/


extern FIELD_IDX_T A_Guarantee_Id                          ;
extern FIELD_IDX_T A_Guarantee_InstrId                     ;
extern FIELD_IDX_T A_Guarantee_ThirdId                     ;
extern FIELD_IDX_T A_Guarantee_TpId                        ;
extern FIELD_IDX_T A_Guarantee_GuaranteePrct               ;

/* PMSTA-17793 - DDV - 140318 */
extern FIELD_IDX_T A_EventGroupingId_Id                    ;

/* PMSTA-17793 - DDV - 140318 */
extern FIELD_IDX_T S_EventGroupingId_Id                    ;
extern FIELD_IDX_T S_EventGroupingId_BlockSize             ;
extern FIELD_IDX_T S_EventGroupingId_IdentityResSize       ;


extern FIELD_IDX_T S_Guarantee_Id                          ;
extern FIELD_IDX_T S_Guarantee_InstrId                     ;
extern FIELD_IDX_T S_Guarantee_ThirdId                     ;
extern FIELD_IDX_T S_Guarantee_TpId                        ;
extern FIELD_IDX_T S_Guarantee_ThirdCd                     ;
extern FIELD_IDX_T S_Guarantee_TpCd                        ;
extern FIELD_IDX_T S_Guarantee_GuaranteePrct               ;


extern FIELD_IDX_T A_InstrChrono_InstrId                   ;
extern FIELD_IDX_T A_InstrChrono_NatEn                     ;
extern FIELD_IDX_T A_InstrChrono_ValidDate                 ;
extern FIELD_IDX_T A_InstrChrono_ThirdPartyId              ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T A_InstrChrono_CurrId                    ;
extern FIELD_IDX_T A_InstrChrono_Val                       ;
extern FIELD_IDX_T A_InstrChrono_SubNatTypeId              ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T A_InstrChrono_RetCd                     ;
extern FIELD_IDX_T A_InstrChrono_OptiDate                  ;  /* PMSTA-10748 - LJE - 110210 */
extern FIELD_IDX_T A_InstrChrono_DefMarket                 ;  /* suparna-PMSTA-53526-2023-09-01 - adding new Parameter def_market to INSTR_CHRONO */


extern FIELD_IDX_T S_InstrChrono_InstrId                   ;
extern FIELD_IDX_T S_InstrChrono_NatEn                     ;
extern FIELD_IDX_T S_InstrChrono_ValidDate                 ;
extern FIELD_IDX_T S_InstrChrono_ThirdPartyId              ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T S_InstrChrono_Val                       ;
extern FIELD_IDX_T S_InstrChrono_SubNatTypeId              ;  /* REF10598 - LJE - 041008 */
extern FIELD_IDX_T S_InstrChrono_InstrCd                   ;
extern FIELD_IDX_T S_InstrChrono_CurrCd                    ;
extern FIELD_IDX_T S_InstrChrono_TimeDimEn                 ;
extern FIELD_IDX_T S_InstrChrono_ValidFlg                  ;
extern FIELD_IDX_T S_InstrChrono_ThirdPartyCd              ;  /* REF10598 - LJE - 041221 */
extern FIELD_IDX_T S_InstrChrono_SubNatTypeCd              ;  /*PMSTA04275-BRO-071025*/
extern FIELD_IDX_T S_InstrChrono_DefMarket                 ;  /* suparna-PMSTA-53526-2023-09-01 - adding new Parameter def_market to INSTR_CHRONO */


extern FIELD_IDX_T Dim_InstrChrono_InstrId                 ;
extern FIELD_IDX_T Dim_InstrChrono_RefDate                 ;
extern FIELD_IDX_T Dim_InstrChrono_ValidPeriod             ;
extern FIELD_IDX_T Dim_InstrChrono_ThirdPartyId            ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Dim_InstrChrono_SubNatTypeId            ;  /* REF10598 - LJE - 041007 */
extern FIELD_IDX_T Dim_InstrChrono_SubNatFlg               ;  /* REF10598 - LJE - 041007 */
extern FIELD_IDX_T Dim_InstrChrono_NatEn                   ;
extern FIELD_IDX_T Dim_InstrChrono_ComputeFlg              ;
extern FIELD_IDX_T Dim_InstrChrono_ThirdPartyFlg           ;  /* PMSTA13097-SRU-111115 */
extern FIELD_IDX_T Dim_InstrChrono_DomQuoteValRuleId       ;  /* PMSTA14879 - DDV - 120920 */
extern FIELD_IDX_T Dim_InstrChrono_CurrId                  ;  /* PMSTA-17571 -cashwini -150616-Parameter currency is missing in INSTR_CHRONO*/
extern FIELD_IDX_T Dim_InstrChrono_DefMarket               ;  /* suparna-PMSTA-53526-2023-09-01 - adding new Parameter def_market to INSTR_CHRONO */

extern FIELD_IDX_T Freq_InstrChrono_InstrId                ;
extern FIELD_IDX_T Freq_InstrChrono_NatEn                  ;
extern FIELD_IDX_T Freq_InstrChrono_ValidDate              ;
extern FIELD_IDX_T Freq_InstrChrono_ThirdPartyId           ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Freq_InstrChrono_CurrId                 ;
extern FIELD_IDX_T Freq_InstrChrono_Val                    ;
extern FIELD_IDX_T Freq_InstrChrono_SubNatTypeId           ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Freq_InstrChrono_RequestDate            ;

/*<REF11718-BRO-060301*/
extern FIELD_IDX_T A_InstrDeposit_Id                       ;
extern FIELD_IDX_T A_InstrDeposit_InstrId                  ;
extern FIELD_IDX_T A_InstrDeposit_DepositId                ;
extern FIELD_IDX_T A_InstrDeposit_Rank                     ;
extern FIELD_IDX_T A_InstrDeposit_MainDepositFlg           ;
extern FIELD_IDX_T A_InstrDeposit_LastUserId               ;
extern FIELD_IDX_T A_InstrDeposit_LastModifDate            ;
extern FIELD_IDX_T A_InstrDeposit_PaymentOption; /* PMSTA-30658 - AiswaryaM -20180503 */

extern FIELD_IDX_T S_InstrDeposit_Id                       ;
extern FIELD_IDX_T S_InstrDeposit_InstrId                  ;
extern FIELD_IDX_T S_InstrDeposit_DepositId                ;
extern FIELD_IDX_T S_InstrDeposit_Rank                     ;
extern FIELD_IDX_T S_InstrDeposit_MainDepositFlg           ;
extern FIELD_IDX_T S_InstrDeposit_InstrCd                  ;
extern FIELD_IDX_T S_InstrDeposit_InstrName                ;
extern FIELD_IDX_T S_InstrDeposit_DepositCd                ;
/*>REF11718-BRO-060301*/


extern FIELD_IDX_T A_InstrFreq_Id                          ;
extern FIELD_IDX_T A_InstrFreq_FreqDate                    ;
extern FIELD_IDX_T A_InstrFreq_InstrId                     ;
extern FIELD_IDX_T A_InstrFreq_InitialDate                 ;
extern FIELD_IDX_T A_InstrFreq_PSPId                       ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_InstrFreq_A_Instr_Ext                 ;

/* PMSTA-18096 - LJE - 140620 */
extern FIELD_IDX_T A_InstrRiskOrig_Id;
extern FIELD_IDX_T A_InstrRiskOrig_InstrId;
extern FIELD_IDX_T A_InstrRiskOrig_RiskOriginInstrId;

extern FIELD_IDX_T A_InstrPrice_InstrId                    ;
extern FIELD_IDX_T A_InstrPrice_CurrId                     ;
extern FIELD_IDX_T A_InstrPrice_TpId                       ;
extern FIELD_IDX_T A_InstrPrice_ThirdId                    ;
extern FIELD_IDX_T A_InstrPrice_TermTpId                   ;
extern FIELD_IDX_T A_InstrPrice_MktThirdId                 ;
extern FIELD_IDX_T A_InstrPrice_QuoteDate                  ;
extern FIELD_IDX_T A_InstrPrice_DailyDfltFlg               ;
extern FIELD_IDX_T A_InstrPrice_Quote                      ;
extern FIELD_IDX_T A_InstrPrice_Price                      ;
extern FIELD_IDX_T A_InstrPrice_PriceCalcRuleEn            ;
extern FIELD_IDX_T A_InstrPrice_UnicityFlg                 ;
extern FIELD_IDX_T A_InstrPrice_ValRuleId                  ;
extern FIELD_IDX_T A_InstrPrice_ValRuleEltId               ;
extern FIELD_IDX_T A_InstrPrice_ValRuleCoef                ;
extern FIELD_IDX_T A_InstrPrice_CoefNatEn                  ;
extern FIELD_IDX_T A_InstrPrice_ActuRate                   ;
extern FIELD_IDX_T A_InstrPrice_FwdSpotPrice               ;
extern FIELD_IDX_T A_InstrPrice_BegCoveredPerDate          ;
extern FIELD_IDX_T A_InstrPrice_EndCoveredPerDate          ;
extern FIELD_IDX_T A_InstrPrice_DiscFac                    ;
extern FIELD_IDX_T A_InstrPrice_ExtendedLoadFlg            ; /* PMSTA-30132 - DDV - 180315 */

extern FIELD_IDX_T S_InstrPrice_InstrId                    ;
extern FIELD_IDX_T S_InstrPrice_CurrId                     ;
extern FIELD_IDX_T S_InstrPrice_TpId                       ;
extern FIELD_IDX_T S_InstrPrice_ThirdId                    ;
extern FIELD_IDX_T S_InstrPrice_TermTpId                   ;
extern FIELD_IDX_T S_InstrPrice_MktThirdId                 ;
extern FIELD_IDX_T S_InstrPrice_QuoteDate                  ;
extern FIELD_IDX_T S_InstrPrice_InstrCd                    ;
extern FIELD_IDX_T S_InstrPrice_CurrCd                     ;
extern FIELD_IDX_T S_InstrPrice_TpCd                       ;
extern FIELD_IDX_T S_InstrPrice_ThirdCd                    ;
extern FIELD_IDX_T S_InstrPrice_TermTpCd                   ;
extern FIELD_IDX_T S_InstrPrice_MktThirdCd                 ;
extern FIELD_IDX_T S_InstrPrice_Quote                      ;


extern FIELD_IDX_T InstrPriceIdx_InstrId                   ;
extern FIELD_IDX_T InstrPriceIdx_InstrPriceTab_Ext         ;
extern FIELD_IDX_T InstrPriceIdx_InstrPriceNbr             ;


extern FIELD_IDX_T Freq_InstrPrice_InstrId                 ;
extern FIELD_IDX_T Freq_InstrPrice_CurrId                  ;
extern FIELD_IDX_T Freq_InstrPrice_TpId                    ;
extern FIELD_IDX_T Freq_InstrPrice_ThirdId                 ;
extern FIELD_IDX_T Freq_InstrPrice_TermTpId                ;
extern FIELD_IDX_T Freq_InstrPrice_MktThirdId              ;
extern FIELD_IDX_T Freq_InstrPrice_QuoteDate               ;
extern FIELD_IDX_T Freq_InstrPrice_DailyDfltFlg            ;
extern FIELD_IDX_T Freq_InstrPrice_Quote                   ;
extern FIELD_IDX_T Freq_InstrPrice_Price                   ;
extern FIELD_IDX_T Freq_InstrPrice_PriceCalcRuleEn         ;
extern FIELD_IDX_T Freq_InstrPrice_UnicityFlg              ;
extern FIELD_IDX_T Freq_InstrPrice_RequestDate             ;



extern FIELD_IDX_T A_IssueEvt_InstrId                      ;
extern FIELD_IDX_T A_IssueEvt_ValidDate                    ;
extern FIELD_IDX_T A_IssueEvt_BegDate                      ;
extern FIELD_IDX_T A_IssueEvt_NatEn                        ;
extern FIELD_IDX_T A_IssueEvt_Cd                           ;
extern FIELD_IDX_T A_IssueEvt_CurrId                       ;
extern FIELD_IDX_T A_IssueEvt_ExclId                       ;
extern FIELD_IDX_T A_IssueEvt_YieldCurveInstrId            ;
extern FIELD_IDX_T A_IssueEvt_AnnounceDate                 ;
extern FIELD_IDX_T A_IssueEvt_EndDate                      ;
extern FIELD_IDX_T A_IssueEvt_EndValidDate                 ;
extern FIELD_IDX_T A_IssueEvt_Price                        ;
extern FIELD_IDX_T A_IssueEvt_Quote                        ;
extern FIELD_IDX_T A_IssueEvt_Freq                         ;
extern FIELD_IDX_T A_IssueEvt_FreqUnitEn                   ;
extern FIELD_IDX_T A_IssueEvt_ProporPrct                   ;
extern FIELD_IDX_T A_IssueEvt_FxdExchRate                  ;
extern FIELD_IDX_T A_IssueEvt_SettlDays                    ;
extern FIELD_IDX_T A_IssueEvt_EffectiveDate                ;
extern FIELD_IDX_T A_IssueEvt_NoticeDay                    ;
extern FIELD_IDX_T A_IssueEvt_InstrNatEn                   ;
extern FIELD_IDX_T A_IssueEvt_InstrTpId                    ;
extern FIELD_IDX_T A_IssueEvt_InstrSubTpId                 ;
extern FIELD_IDX_T A_IssueEvt_ProporApplEn                 ;  /* PMSTA-32106 - AiswaryaM - 20180723*/
extern FIELD_IDX_T A_IssueEvt_EventStatusEn                ;	/*   24: EnumType            */
extern FIELD_IDX_T A_IssueEvt_EventTypeId                  ;	/*   25: IdType              */
extern FIELD_IDX_T A_IssueEvt_CommitmentReference          ;	/*   26: InfoType            */
extern FIELD_IDX_T A_IssueEvt_EventAmount                  ;	/*   27: AmountType          */


extern FIELD_IDX_T S_IssueEvt_InstrId                      ;
extern FIELD_IDX_T S_IssueEvt_ValidDate                    ;
extern FIELD_IDX_T S_IssueEvt_BegDate                      ;
extern FIELD_IDX_T S_IssueEvt_NatEn                        ;
extern FIELD_IDX_T S_IssueEvt_Cd                           ;
extern FIELD_IDX_T S_IssueEvt_InstrNatEn                   ;



extern FIELD_IDX_T A_ListChrono_ListId                     ;
extern FIELD_IDX_T A_ListChrono_CurrId                     ;
extern FIELD_IDX_T A_ListChrono_ValidDate                  ;
extern FIELD_IDX_T A_ListChrono_NatEn                      ;
extern FIELD_IDX_T A_ListChrono_Val                        ;
extern FIELD_IDX_T A_ListChrono_TimeDimEn                  ;
extern FIELD_IDX_T A_ListChrono_ValidFlg                   ;


extern FIELD_IDX_T S_ListChrono_ListId                     ;
extern FIELD_IDX_T S_ListChrono_CurrId                     ;
extern FIELD_IDX_T S_ListChrono_ValidDate                  ;
extern FIELD_IDX_T S_ListChrono_NatEn                      ;
extern FIELD_IDX_T S_ListChrono_ListCd                     ;
extern FIELD_IDX_T S_ListChrono_Val                        ;
extern FIELD_IDX_T S_ListChrono_CurrCd                     ;


extern FIELD_IDX_T Freq_ListChrono_ListId                  ;
extern FIELD_IDX_T Freq_ListChrono_CurrId                  ;
extern FIELD_IDX_T Freq_ListChrono_ValidDate               ;
extern FIELD_IDX_T Freq_ListChrono_NatEn                   ;
extern FIELD_IDX_T Freq_ListChrono_Val                     ;
extern FIELD_IDX_T Freq_ListChrono_RequestDate             ;


extern FIELD_IDX_T A_ListCompo_Id                          ;
extern FIELD_IDX_T A_ListCompo_EntDictId                   ;
extern FIELD_IDX_T A_ListCompo_ObjId                       ;
extern FIELD_IDX_T A_ListCompo_ValidDt                     ;
extern FIELD_IDX_T A_ListCompo_Rank                        ;
extern FIELD_IDX_T A_ListCompo_A_Grid_Ext                  ;


extern FIELD_IDX_T S_ListCompo_Id                          ;
extern FIELD_IDX_T S_ListCompo_EntDictId                   ;
extern FIELD_IDX_T S_ListCompo_ObjId                       ;
extern FIELD_IDX_T S_ListCompo_ValidDt                     ;
extern FIELD_IDX_T S_ListCompo_ObjCd                       ;
extern FIELD_IDX_T S_ListCompo_ObjName                     ;
extern FIELD_IDX_T S_ListCompo_Rank                        ;
extern FIELD_IDX_T S_ListCompo_TypeId                      ;

extern FIELD_IDX_T A_LoginFailed_UserCode                  ;
extern FIELD_IDX_T A_LoginFailed_LoginHistId               ;
extern FIELD_IDX_T A_LoginFailed_Display                   ;
extern FIELD_IDX_T A_LoginFailed_NatEn                     ;


extern FIELD_IDX_T A_Map_Id                                ;
extern FIELD_IDX_T A_Map_Code                              ;
extern FIELD_IDX_T A_Map_Denom                             ;
extern FIELD_IDX_T A_Map_EntityDictId                      ;
extern FIELD_IDX_T A_Map_Storage                           ;


extern FIELD_IDX_T S_Map_Id                                ;
extern FIELD_IDX_T S_Map_Code                              ;
extern FIELD_IDX_T S_Map_Denom                             ;
extern FIELD_IDX_T S_Map_EntityDictId                      ;
extern FIELD_IDX_T S_Map_Storage                           ;
extern FIELD_IDX_T S_Map_EntitySqlName                     ;


extern FIELD_IDX_T A_Mgr_Id                                ;
extern FIELD_IDX_T A_Mgr_Cd                                ;
extern FIELD_IDX_T A_Mgr_Name                              ;
extern FIELD_IDX_T A_Mgr_Denom                             ;
extern FIELD_IDX_T A_Mgr_AutoCreatedFlg                    ;
extern FIELD_IDX_T A_Mgr_Phone                             ;
extern FIELD_IDX_T A_Mgr_ExternFlg                         ;
extern FIELD_IDX_T A_Mgr_LastNoteDate                      ;
extern FIELD_IDX_T A_Mgr_LangEntDictId                     ;
extern FIELD_IDX_T A_Mgr_Password                          ;
extern FIELD_IDX_T A_Mgr_DataProfId                        ;
extern FIELD_IDX_T A_Mgr_DataSecuProfId                    ;
extern FIELD_IDX_T A_Mgr_EMailAdr                          ;
extern FIELD_IDX_T A_Mgr_CurrencyId                        ;
extern FIELD_IDX_T A_Mgr_WuiProfileEn                      ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_WuiRoleEn                         ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_ReportProfileId                   ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_UserId                            ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_ActiveFlg                         ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_HeartUploadEn                     ; /*REF9446-BRO-030926*/
extern FIELD_IDX_T A_Mgr_DataSecuProf2Id                   ; /* PMSTA-14647 - LJE - 120712 */
extern FIELD_IDX_T A_Mgr_InputPassword                     ;
extern FIELD_IDX_T A_Mgr_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule  */


extern FIELD_IDX_T S_Mgr_Id                                ;
extern FIELD_IDX_T S_Mgr_Cd                                ;
extern FIELD_IDX_T S_Mgr_Name                              ;
extern FIELD_IDX_T S_Mgr_CodifId                           ;


extern FIELD_IDX_T A_MktSegt_Id                            ;
extern FIELD_IDX_T A_MktSegt_Name                          ;
extern FIELD_IDX_T A_MktSegt_Denom                         ;
extern FIELD_IDX_T A_MktSegt_GridId                        ;
extern FIELD_IDX_T A_MktSegt_AbcissaListId                 ;
extern FIELD_IDX_T A_MktSegt_OrdinateListId                ;
extern FIELD_IDX_T A_MktSegt_MktStructId                   ;
extern FIELD_IDX_T A_MktSegt_CashMktSegtEn                 ; /* REF10605-EFE-041005 */
extern FIELD_IDX_T A_MktSegt_CurrId                        ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_MktSegt_ParMktSegtId                  ; /* PMSTA08736 - LJE - 100216 */
extern FIELD_IDX_T A_MktSegt_VirtualCashMktSegtId          ; /* PMSTA08736 - LJE - 100216 */
extern FIELD_IDX_T A_MktSegt_Level                         ; /* PMSTA08736 - LJE - 100603 */
extern FIELD_IDX_T A_MktSegt_ParMktSegt_Ext                ; /* PMSTA08736 - LJE - 100216 */
extern FIELD_IDX_T A_MktSegt_ChildrenMktSegt_Ext           ; /* PMSTA08736 - LJE - 100216 */
extern FIELD_IDX_T A_MktSegt_VirtualCashMktSegt_Ext        ; /* PMSTA08736 - LJE - 100216 */
extern FIELD_IDX_T A_MktSegt_PerfEffectLink_Ext            ; /* PMSTA-14965 - LJE - 120919 */
extern FIELD_IDX_T A_MktSegt_S_MktSegt_Ext                 ; /* PMSTA-14965 - LJE - 120919 */

extern FIELD_IDX_T S_MktSegt_Id                            ;
extern FIELD_IDX_T S_MktSegt_Name                          ;
extern FIELD_IDX_T S_MktSegt_GridId                        ;
extern FIELD_IDX_T S_MktSegt_GridCd                        ;
extern FIELD_IDX_T S_MktSegt_AbcissaListId                 ;
extern FIELD_IDX_T S_MktSegt_AbcissaListCd                 ;
extern FIELD_IDX_T S_MktSegt_AbcissaListName               ;
extern FIELD_IDX_T S_MktSegt_AbcissaListRank               ;
extern FIELD_IDX_T S_MktSegt_OrdinateListId                ;
extern FIELD_IDX_T S_MktSegt_OrdinateListCd                ;
extern FIELD_IDX_T S_MktSegt_OrdinateListName              ;
extern FIELD_IDX_T S_MktSegt_OrdinateListRank              ;
extern FIELD_IDX_T S_MktSegt_AbcissaClassifId              ;
extern FIELD_IDX_T S_MktSegt_AbcissaClassifCd              ;
extern FIELD_IDX_T S_MktSegt_OrdinateClassifId             ;
extern FIELD_IDX_T S_MktSegt_OrdinateClassifCd             ;
extern FIELD_IDX_T S_MktSegt_MktStructId                   ;
extern FIELD_IDX_T S_MktSegt_ParMktSegtName                ; /*REF10647-BRO-041117*/
extern FIELD_IDX_T S_MktSegt_CurrId                        ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T S_MktSegt_MktStructLevel                ;
extern FIELD_IDX_T S_MktSegt_ParMktSegtId                  ;
extern FIELD_IDX_T S_MktSegt_Level                         ;
extern FIELD_IDX_T S_MktSegt_AbcissaParentId               ;	/* REF10679 - TEB - 041007 */
extern FIELD_IDX_T S_MktSegt_OrdinateParentId              ;	/* REF10679 - TEB - 041007 */
extern FIELD_IDX_T S_MktSegt_CashMktSegmentEn			   ;	/*PMSTA-43175-Badhri-21122020*/


extern FIELD_IDX_T A_MktStruct_Id                          ;
extern FIELD_IDX_T A_MktStruct_RefGridId                   ;
extern FIELD_IDX_T A_MktStruct_GridId                      ;
extern FIELD_IDX_T A_MktStruct_ParMktSegtId                ;
extern FIELD_IDX_T A_MktStruct_ParMktStructId              ;
extern FIELD_IDX_T A_MktStruct_Rank                        ;
extern FIELD_IDX_T A_MktStruct_Level                       ;
extern FIELD_IDX_T A_MktStruct_S_MktSegt_Ext               ;


extern FIELD_IDX_T S_MktStruct_Id                          ;
extern FIELD_IDX_T S_MktStruct_RefGridId                   ;
extern FIELD_IDX_T S_MktStruct_RefGridName                 ;
extern FIELD_IDX_T S_MktStruct_RefGridCd                   ;
extern FIELD_IDX_T S_MktStruct_Rank                        ;
extern FIELD_IDX_T S_MktStruct_GridId                      ;
extern FIELD_IDX_T S_MktStruct_GridName                    ;
extern FIELD_IDX_T S_MktStruct_ParMktSegtId                ;
extern FIELD_IDX_T S_MktStruct_ParMktSegtName              ;
extern FIELD_IDX_T S_MktStruct_ParRank                     ;
extern FIELD_IDX_T S_MktStruct_PmsGridName                 ;
extern FIELD_IDX_T S_MktStruct_PmsGridId                   ;


extern FIELD_IDX_T A_MktSSubSet_Id                         ;
extern FIELD_IDX_T A_MktSSubSet_RefGridId                  ;
extern FIELD_IDX_T A_MktSSubSet_MktStructId                ;


extern FIELD_IDX_T S_MktSSubSet_Id                         ;
extern FIELD_IDX_T S_MktSSubSet_RefGridId                  ;
extern FIELD_IDX_T S_MktSSubSet_MktStructId                ;
extern FIELD_IDX_T S_MktSSubSet_RefGridCd                  ;
extern FIELD_IDX_T S_MktSSubSet_RefGridName                ;
extern FIELD_IDX_T S_MktSSubSet_MSRefGridId                ;
extern FIELD_IDX_T S_MktSSubSet_MSRefGridName              ;
extern FIELD_IDX_T S_MktSSubSet_MSRank                     ;
extern FIELD_IDX_T S_MktSSubSet_MSGridId                   ;
extern FIELD_IDX_T S_MktSSubSet_MSGridName                 ;
extern FIELD_IDX_T S_MktSSubSet_MSParMSId                  ;
extern FIELD_IDX_T S_MktSSubSet_MSParMSName                ;
extern FIELD_IDX_T S_MktSSubSet_MSParMSParRank             ;


extern FIELD_IDX_T A_ModelConstrElt_Id                     ;
extern FIELD_IDX_T A_ModelConstrElt_ModelConstrId          ;
extern FIELD_IDX_T A_ModelConstrElt_MktSgtId               ;
extern FIELD_IDX_T A_ModelConstrElt_DimInstrDictId         ;
extern FIELD_IDX_T A_ModelConstrElt_InstrObjId             ;
extern FIELD_IDX_T A_ModelConstrElt_ConstrBoundCurrId      ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T A_ModelConstrElt_NatEn                  ;
extern FIELD_IDX_T A_ModelConstrElt_Denom                  ;
extern FIELD_IDX_T A_ModelConstrElt_MinWeight              ;
extern FIELD_IDX_T A_ModelConstrElt_MaxWeight              ;
extern FIELD_IDX_T A_ModelConstrElt_FixedCellFlg           ;
extern FIELD_IDX_T A_ModelConstrElt_ConstrBoundNatEn       ; /*REF10599-BRO-040914*/
extern FIELD_IDX_T A_ModelConstrElt_TradingOrderNatEn      ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T A_ModelConstrElt_ApplFieldEn            ; /*REF10599-BRO-040914*/
extern FIELD_IDX_T A_ModelConstrElt_Priority               ; /*REF10599-BRO-040914*/
extern FIELD_IDX_T A_ModelConstrElt_ConstrTreatEn          ; /*REF10599-BRO-040914*/
extern FIELD_IDX_T A_ModelConstrElt_CriticalnessEn         ; /*REF11231-CHU-050608*/
extern FIELD_IDX_T A_ModelConstrElt_CreationModeEn         ; /*REF11810-EFE-060608*/
extern FIELD_IDX_T A_ModelConstrElt_EndDate                ; /*PMSTA00965-EFE-070227*/
extern FIELD_IDX_T A_ModelConstrElt_IgnoreMarginFlg        ; /*PMSTA00970-BRO-070201*/
extern FIELD_IDX_T A_ModelConstrElt_ConstrNatEn            ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T A_ModelConstrElt_CalcMinWeight          ; /*REF10633-RAK-041012*/
extern FIELD_IDX_T A_ModelConstrElt_CalcMaxWeight          ; /*REF10633-RAK-041012*/
extern FIELD_IDX_T A_ModelConstrElt_TreatedFlg             ;
extern FIELD_IDX_T A_ModelConstrElt_InstrObjCd             ;	/* REF11481 - TEB - 051010 */
extern FIELD_IDX_T A_ModelConstrElt_InstrObjNatEn          ;	/* PMSTA07902 - DDV - 090504 */
extern FIELD_IDX_T A_ModelConstrElt_InstrObjSubNatEn       ;	/* PMSTA07902 - DDV - 090504 */
extern FIELD_IDX_T A_ModelConstrElt_ConstrBoundCurrCd      ;	/* REF11481 - TEB - 051010 */
extern FIELD_IDX_T A_ModelConstrElt_CalcMinOptWeight       ;	/* REF11478 - CHU - 060227 */
extern FIELD_IDX_T A_ModelConstrElt_CalcMaxOptWeight       ;	/* REF11478 - CHU - 060227 */
extern FIELD_IDX_T A_ModelConstrElt_CalcMinChkWeight       ;	/* REF11478 - CHU - 060227 */
extern FIELD_IDX_T A_ModelConstrElt_CalcMaxChkWeight       ;	/* REF11478 - CHU - 060227 */
extern FIELD_IDX_T A_ModelConstrElt_InitCalcMinWeight      ;	/* REF11478 - CHU - 060406 */
extern FIELD_IDX_T A_ModelConstrElt_InitCalcMaxWeight      ;	/* REF11478 - CHU - 060406 */
extern FIELD_IDX_T A_ModelConstrElt_LittleBrol             ;	/* PMSTA00327 - CHU - 060926 */ /*Business Residue Of Leftover*/
extern FIELD_IDX_T A_ModelConstrElt_InstrTreatedFlg        ;	/* PMSTA10636-CHU-101007 */
extern FIELD_IDX_T A_ModelConstrElt_DimStratDictId		   ;	/* PMSTA-39045-BADHRI-140220 */
extern FIELD_IDX_T A_ModelConstrElt_StratObjId			   ;    /* PMSTA-39045-BADHRI-140220 */
extern FIELD_IDX_T A_ModelConstrElt_ApplicationScopeEn     ;    /* PMSTA-41153-Vishnu-130720*/
extern FIELD_IDX_T A_ModelConstrElt_HierHeadPtfId          ;    /* PMSTA-41153-Vishnu-150720*/
extern FIELD_IDX_T A_ModelConstrElt_ptfId                  ;    /* PMSTA-41153-Vishnu-150720*/
extern FIELD_IDX_T A_ModelConstrElt_ModelConstrNatEn       ;    /* PMSTA-41153-Vishnu-150720*/
extern FIELD_IDX_T A_ModelConstrElt_ModelTypeId			   ;    /* PMSTA-42156-badhri-20102020*/
extern FIELD_IDX_T A_ModelConstrElt_CreationUserId         ;	/* PMSTA-42750-vmu-01122020*/
extern FIELD_IDX_T A_ModelConstrElt_CreationTimeDate       ;	/* PMSTA-42750-vmu-01122020*/
extern FIELD_IDX_T A_ModelConstrElt_TypeId                 ;	/* PMSTA-42750-vmu-01122020*/
extern FIELD_IDX_T A_ModelConstrElt_SubTypeId              ;	/* PMSTA-42750-vmu-01122020*/
extern FIELD_IDX_T A_ModelConstrElt_SkippedConstrFlg	   ;    /* PMSTA-42156-Badhri-25112020*/
extern FIELD_IDX_T A_ModelConstrElt_QuasiCashEn  		   ;    /* PMSTA-43175-Badhri-21122020 */
extern FIELD_IDX_T A_ModelConstrElt_OriginTypeId		   ;    /* PMSTA - 51507 - KKM - 222012 */
extern FIELD_IDX_T A_ModelConstrElt_CaseMgtTypeId          ;    /* WEALTH-9979 - KKM - 12072024 */

extern FIELD_IDX_T S_ModelConstrElt_Id                     ;
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrId          ;
extern FIELD_IDX_T S_ModelConstrElt_MktSgtId               ;
extern FIELD_IDX_T S_ModelConstrElt_DimInstrDictId         ;
extern FIELD_IDX_T S_ModelConstrElt_InstrObjId             ;
extern FIELD_IDX_T S_ModelConstrElt_ConstrBoundNatEn       ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T S_ModelConstrElt_TradingOrderNatEn      ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T S_ModelConstrElt_MinWeight              ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T S_ModelConstrElt_MaxWeight              ; /*REF10599-BRO-041019*/
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrNatEn       ;
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrDimPtfId    ; /*REF10599-BRO-040917*/
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrPtfId       ;
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrBegD        ;
extern FIELD_IDX_T S_ModelConstrElt_ModelConstrPtfCd       ;
extern FIELD_IDX_T S_ModelConstrElt_Dimension              ;
extern FIELD_IDX_T S_ModelConstrElt_ObjectCd               ;
extern FIELD_IDX_T S_ModelConstrElt_ObjectName             ;
extern FIELD_IDX_T S_ModelConstrElt_ApplScope              ; /*WEALTH-7122-Ravindra-28042024*/


extern FIELD_IDX_T A_Notepad_EntDictId                     ;
extern FIELD_IDX_T A_Notepad_ObjId                         ;
extern FIELD_IDX_T A_Notepad_NoteDate                      ;
extern FIELD_IDX_T A_Notepad_UserId                        ;
extern FIELD_IDX_T A_Notepad_TpId                          ;
extern FIELD_IDX_T A_Notepad_Title                         ;
extern FIELD_IDX_T A_Notepad_Note                          ;


extern FIELD_IDX_T S_Notepad_EntDictId                     ;
extern FIELD_IDX_T S_Notepad_ObjId                         ;
extern FIELD_IDX_T S_Notepad_NoteDate                      ;
extern FIELD_IDX_T S_Notepad_UserId                        ;
extern FIELD_IDX_T S_Notepad_TpId                          ;
extern FIELD_IDX_T S_Notepad_TpCd                          ;
extern FIELD_IDX_T S_Notepad_UserCd                        ;


extern FIELD_IDX_T A_One_Id                                ;

extern FIELD_IDX_T A_Boottime_Id                           ;    /* PMSTA-16365 - 140509 */


extern FIELD_IDX_T A_Op_Id                                 ;
extern FIELD_IDX_T A_Op_Cd                                 ;
extern FIELD_IDX_T A_Op_Fus                                ;
extern FIELD_IDX_T A_Op_InputUserId                        ;
extern FIELD_IDX_T A_Op_TpId                               ;
extern FIELD_IDX_T A_Op_SubTpId                            ;
extern FIELD_IDX_T A_Op_MktThirdId                         ;
extern FIELD_IDX_T A_Op_InterThirdId                       ;
extern FIELD_IDX_T A_Op_PtfId                              ;
extern FIELD_IDX_T A_Op_PortPosSetId                       ;
extern FIELD_IDX_T A_Op_AdjPtfId                           ;
extern FIELD_IDX_T A_Op_CashPtfId                          ;
extern FIELD_IDX_T A_Op_InstrId                            ;
extern FIELD_IDX_T A_Op_ToInstrId                          ;
extern FIELD_IDX_T A_Op_AdjInstrId                         ;
extern FIELD_IDX_T A_Op_AccInstrId                         ;
extern FIELD_IDX_T A_Op_Acc2InstrId                        ;
extern FIELD_IDX_T A_Op_Acc3InstrId                        ;
extern FIELD_IDX_T A_Op_DepoId                             ;
extern FIELD_IDX_T A_Op_TradeCurrId                        ;
extern FIELD_IDX_T A_Op_MgrId                              ;
extern FIELD_IDX_T A_Op_RuleId                             ;
extern FIELD_IDX_T A_Op_ExtOrderId                         ;
extern FIELD_IDX_T A_Op_OrderModeTypeId                    ; /*REF11810-BRO-060531*/
extern FIELD_IDX_T A_Op_TraderMgrId						   ; /*REF11810-BRO-060531*/
extern FIELD_IDX_T A_Op_OrderCd                            ;
extern FIELD_IDX_T A_Op_ExecSetCriteria                    ;
extern FIELD_IDX_T A_Op_ParOpCd                            ;
extern FIELD_IDX_T A_Op_LastUserId                         ;
extern FIELD_IDX_T A_Op_LastModifDate                      ;
extern FIELD_IDX_T A_Op_NatEn                              ;
extern FIELD_IDX_T A_Op_OrderNatEn                         ;
extern FIELD_IDX_T A_Op_CreationTime                       ;
extern FIELD_IDX_T A_Op_AcctExchRate                       ;
extern FIELD_IDX_T A_Op_Acct2ExchRate                      ;
extern FIELD_IDX_T A_Op_Acct3ExchRate                      ;
extern FIELD_IDX_T A_Op_TradeExchRate                      ;
extern FIELD_IDX_T A_Op_CashPtfExchRate                    ;
extern FIELD_IDX_T A_Op_AdjPtfExchRate                     ;
extern FIELD_IDX_T A_Op_AcctDate                           ;
extern FIELD_IDX_T A_Op_OpDate                             ;
extern FIELD_IDX_T A_Op_ValuationDate                      ;
extern FIELD_IDX_T A_Op_OrderLimitDate                     ;
extern FIELD_IDX_T A_Op_ValDate                            ;
extern FIELD_IDX_T A_Op_OpRefCd                            ;
extern FIELD_IDX_T A_Op_RefNatEn                           ;
extern FIELD_IDX_T A_Op_StatEn                             ;
extern FIELD_IDX_T A_Op_LastNoteDate                       ;
extern FIELD_IDX_T A_Op_SequenceNo                         ;
extern FIELD_IDX_T A_Op_AcctCd                             ;
extern FIELD_IDX_T A_Op_SrcCd                              ;
extern FIELD_IDX_T A_Op_LimitQuote                         ;
extern FIELD_IDX_T A_Op_LimitPrice                         ;
extern FIELD_IDX_T A_Op_StopQuote                          ;
extern FIELD_IDX_T A_Op_StopPrice                          ;
extern FIELD_IDX_T A_Op_OrderPriceNatEn                    ;
extern FIELD_IDX_T A_Op_OrderValidNatEn                    ;
extern FIELD_IDX_T A_Op_MinOrderQty                        ;
extern FIELD_IDX_T A_Op_ValoSeqNo                          ;
extern FIELD_IDX_T A_Op_ParOpNatEn                         ;
extern FIELD_IDX_T A_Op_CheckParentEn                      ;
extern FIELD_IDX_T A_Op_CheckStratEn                       ;
extern FIELD_IDX_T A_Op_AutoRenewalEn					   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T A_Op_RenewalTreatmtEn				   ;
extern FIELD_IDX_T A_Op_RenewalEndValDate				   ;
extern FIELD_IDX_T A_Op_RenewalLength					   ;
extern FIELD_IDX_T A_Op_RenewalLengthUnitEn				   ;
extern FIELD_IDX_T A_Op_ClientInitEn                       ;
extern FIELD_IDX_T A_Op_ContractNumber					   ;
extern FIELD_IDX_T A_Op_TransactionNatEn				   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T A_Op_RenewalIntRate                     ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T A_Op_RenewalAmount                      ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T A_Op_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T A_Op_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T A_Op_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T A_Op_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T A_Op_FxMarginNumber                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T A_Op_FxMarginPrct                       ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T A_Op_FxMarginAmount                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T A_Op_Summary                            ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T A_Op_DraftOrderId                       ;	/* REF8500 - 040510 - PMO */
extern FIELD_IDX_T A_Op_TimeStamp                          ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T A_Op_DerivativeOrdEn					   ; /* OCS-43683 - TGU - 131107 */
extern FIELD_IDX_T A_Op_FxFarLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T A_Op_FxSpotQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T A_Op_FxQuote							   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T A_Op_FxSpotLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T A_Op_OrderFeeEn                         ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T A_Op_OrderFeePrct                       ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T A_Op_MaxOrderQty						   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T A_Op_STPOrderEn						   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T A_Op_UnpaidPrct						   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T A_Op_EventStatusId                      ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T A_Op_EventActionEn                      ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T A_Op_CompoundOrderMasterEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T A_Op_CompoundOrderSlaveEltId			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T A_Op_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T A_Op_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T A_Op_CompoundImpactRule				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T A_Op_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T A_Op_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T A_Op_CommonRef                          ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T A_Op_OrderInclusionEn                   ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T A_Op_OrderRejectionDate                 ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T A_Op_OrderRejectionComment              ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T A_Op_AcquisitionDate                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Op_CorporateActionNatEn               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Op_TaxLotSourceCd                     ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Op_StandInstructId                    ; /* PMSTA-30043 - CHU - 180201 */
extern FIELD_IDX_T A_Op_BankFeePrct                        ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T A_Op_BankFeeAmount                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T A_Op_BankFeeCurrId                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T A_Op_BidTypeEn                          ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid1Qty                            ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid1Quote                          ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid2Qty                            ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid2Quote                          ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid3Qty                            ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_Bid3Quote                          ;/* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T A_Op_CounterpartAccount;
extern FIELD_IDX_T A_Op_CounterpartCurrencyId;
extern FIELD_IDX_T A_Op_OpFusionRuleEn                     ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T A_Op_GlobalPosFlg                       ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T A_Op_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T A_Op_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T A_Op_CoolCancelEndDate                  ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T A_Op_FusionPrioEn                       ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T A_Op_ExternalBankBic                    ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T A_Op_ExternalBankName                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T A_Op_ExternalBankAcctOwnrName           ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T A_Op_HedgeTradeEn                       ; /* PMSTA-35985 - Kramadevi  - 230519 */
extern FIELD_IDX_T A_Op_FixingDate                         ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr1             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr2             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr3             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_ExtrnlBnkAcctOwnrAddr4             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_PayRef1                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_PayRef2                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_PayRef3                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_PayRef4                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T A_Op_ExternalTradeFlg                   ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T A_Op_OriginalQty						   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T A_Op_OrderNettingEn					   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T A_Op_PaymentDate                        ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Op_PaymentStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Op_SettlementDate                     ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Op_SettleStatusEn                     ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Op_CommissionCdEn                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_ChargeCdEn                         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_OriginalAmount                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_CounterpartOrgAmount               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_ExternalFeeM                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_TotalChargesM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_CounterpartAmount                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_OpLinkageCd                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_ChargedCustomerName                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T A_Op_BoPtfId                            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_BoAccountId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_OpSplitRuleEn                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_AdjBoPtfId                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_CoaExDate                          ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_BoCashAcctId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_BoCashPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_SplitParentOperId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Op_OriginalNetAmount                  ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T A_Op_SplitParOpCd;       /* PMSTA-40714 */
extern FIELD_IDX_T A_Op_RuleApplicabilityEn				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_SmartRoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_RoundingOrgQty					   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_SmartRoundingRuleId				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_Op_HierOperNatEn                      ; /* PMSTA-40208 - adarshn - 28082020*/
extern FIELD_IDX_T A_Op_HierOperationCd                    ; /* PMSTA-40208 - adarshn - 28082020*/
extern FIELD_IDX_T A_Op_CashPlanId                         ; /*PMSTA-42402 Autocash Vishnu 16112020*/
extern FIELD_IDX_T A_Op_NotionalInstrId                    ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T A_Op_InvestLimitEn                      ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T A_Op_SetOfFeesId                        ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_Op_SetOfProductFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_Op_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T A_Op_OrderSubTypeId                     ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T A_Op_SetOfOtherFeesId                   ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T A_Op_TraderThirdId                      ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T A_Op_NetSettleAmount                    ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T S_Op_Id                                 ;
extern FIELD_IDX_T S_Op_Cd                                 ;
extern FIELD_IDX_T S_Op_SequenceNo                         ;
extern FIELD_IDX_T S_Op_StatEn                             ;
extern FIELD_IDX_T S_Op_NatEn                              ;
extern FIELD_IDX_T S_Op_AudModifDate                       ;
extern FIELD_IDX_T S_Op_DbStatusEn                         ;
extern FIELD_IDX_T S_Op_CheckParentEn                      ;
extern FIELD_IDX_T S_Op_NoCheckImpactFlg                   ;
extern FIELD_IDX_T S_Op_FusionPrioEn                       ;


extern FIELD_IDX_T A_OpCompo_OpTpId                        ;
extern FIELD_IDX_T A_OpCompo_BalPosTpId                    ;
extern FIELD_IDX_T A_OpCompo_OpNatEn                       ;
extern FIELD_IDX_T A_OpCompo_Rank                          ;


extern FIELD_IDX_T S_OpCompo_OpTpId                        ;
extern FIELD_IDX_T S_OpCompo_BalPosTpId                    ;
extern FIELD_IDX_T S_OpCompo_OpNatEn                       ;


extern FIELD_IDX_T A_PayInstruct_PtfId                     ;
extern FIELD_IDX_T A_PayInstruct_AccInstrId                ;
extern FIELD_IDX_T A_PayInstruct_CurrId                    ;
extern FIELD_IDX_T A_PayInstruct_OpTpId                    ;
extern FIELD_IDX_T A_PayInstruct_OpSubTpId                 ;
extern FIELD_IDX_T A_PayInstruct_OpNatEn                   ;


extern FIELD_IDX_T S_PayInstruct_PtfId                     ;
extern FIELD_IDX_T S_PayInstruct_AccInstrId                ;
extern FIELD_IDX_T S_PayInstruct_CurrId                    ;
extern FIELD_IDX_T S_PayInstruct_OpTpId                    ;
extern FIELD_IDX_T S_PayInstruct_OpSubTpId                 ;
extern FIELD_IDX_T S_PayInstruct_OpNatEn                   ;
extern FIELD_IDX_T S_PayInstruct_OpTpCd                    ;
extern FIELD_IDX_T S_PayInstruct_OpSubTpCd                 ;
extern FIELD_IDX_T S_PayInstruct_CurrCd                    ;
extern FIELD_IDX_T S_PayInstruct_AccInstrCd                ;

/* REF9264 - LJE - 030630 */
extern FIELD_IDX_T A_PAABreakCriteria_BreakCriteriaId      ; /* PSMTA02254 - DDV - 070711 */
extern FIELD_IDX_T A_PAABreakCriteria_BreakCriteriaVal     ;
extern FIELD_IDX_T A_PAABreakCriteria_EntDictId            ;
extern FIELD_IDX_T A_PAABreakCriteria_ObjectId             ;
extern FIELD_IDX_T A_PAABreakCriteria_SubObjectId          ; /* PMSTA-47578 - LJE - 220314 */
extern FIELD_IDX_T A_PAABreakCriteria_GridId               ;
extern FIELD_IDX_T A_PAABreakCriteria_ObjectLnkId          ;
extern FIELD_IDX_T A_PAABreakCriteria_DynSt                ;
extern FIELD_IDX_T A_PAABreakCriteria_MultiGridFlg         ; /* REF9770 - LJE - 031208 */
extern FIELD_IDX_T A_PAABreakCriteria_MainObjFlg           ; /* REF9770 - LJE - 031217 */
extern FIELD_IDX_T A_PAABreakCriteria_BeginDate            ; /* REF9770 - LJE - 031208 */
extern FIELD_IDX_T A_PAABreakCriteria_EndDate              ; /* REF9770 - LJE - 031208 */
extern FIELD_IDX_T A_PAABreakCriteria_SubSetBreakCriteria  ; /* REF10276 - LJE - 041110 : For optim */


extern FIELD_IDX_T A_PerfAttribId_Id                       ; /* REF9924 - LJE - 040213 */

extern FIELD_IDX_T S_PerfAttribId_Id                       ;
extern FIELD_IDX_T S_PerfAttribId_BlockSize                ;
extern FIELD_IDX_T S_PerfAttribId_IdentityResSize          ;

extern FIELD_IDX_T A_PerfAttrib_Id                         ;
extern FIELD_IDX_T A_PerfAttrib_PerfStorParamId            ;
extern FIELD_IDX_T A_PerfAttrib_EntDictId                  ;
extern FIELD_IDX_T A_PerfAttrib_ObjId                      ;
extern FIELD_IDX_T A_PerfAttrib_FreqEn                     ;
extern FIELD_IDX_T A_PerfAttrib_CurrId                     ;
extern FIELD_IDX_T A_PerfAttrib_PosDataId                  ;
extern FIELD_IDX_T A_PerfAttrib_GridId                     ;
extern FIELD_IDX_T A_PerfAttrib_PerfAttribRtnEn            ;
extern FIELD_IDX_T A_PerfAttrib_InitialDate                ;
extern FIELD_IDX_T A_PerfAttrib_FinalDate                  ;
extern FIELD_IDX_T A_PerfAttrib_MktSegtId                  ;
extern FIELD_IDX_T A_PerfAttrib_InstrId                    ;
extern FIELD_IDX_T A_PerfAttrib_SubPeriodMask              ;
extern FIELD_IDX_T A_PerfAttrib_InitialMktVal              ;
extern FIELD_IDX_T A_PerfAttrib_FlowMeanCap                ;
extern FIELD_IDX_T A_PerfAttrib_WgtFactor                  ;
extern FIELD_IDX_T A_PerfAttrib_Wgt                        ;
extern FIELD_IDX_T A_PerfAttrib_Rtn                        ;
extern FIELD_IDX_T A_PerfAttrib_RtnCurr                    ;
extern FIELD_IDX_T A_PerfAttrib_Dura                       ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_BenchEntDictId             ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_PerfAttrib_BenchObjId                 ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_PerfAttrib_FinalMktVal                ; /*REF9743-BRO-040205*/
extern FIELD_IDX_T A_PerfAttrib_Adjust                     ; /*REF9743-BRO-040205*/
extern FIELD_IDX_T A_PerfAttrib_PortSynthId                ;
extern FIELD_IDX_T A_PerfAttrib_ExtStratEltId              ;
extern FIELD_IDX_T A_PerfAttrib_StratSynthId               ; /* PMSTA08736 - LJE - 100120 */
extern FIELD_IDX_T A_PerfAttrib_GlobalPerfAttribId         ;
extern FIELD_IDX_T A_PerfAttrib_Bench1PerfAttribId         ;
extern FIELD_IDX_T A_PerfAttrib_Bench2PerfAttribId         ;
extern FIELD_IDX_T A_PerfAttrib_Bench3PerfAttribId         ;
extern FIELD_IDX_T A_PerfAttrib_RiskFreeStdPerfId          ;
extern FIELD_IDX_T A_PerfAttrib_PaMktSelection             ;
extern FIELD_IDX_T A_PerfAttrib_PaStockPicking             ;
extern FIELD_IDX_T A_PerfAttrib_PaInteraction              ;
extern FIELD_IDX_T A_PerfAttrib_PaCurrSelection            ;
extern FIELD_IDX_T A_PerfAttrib_ParentId                   ;
extern FIELD_IDX_T A_PerfAttrib_ReturnContribution         ;
extern FIELD_IDX_T A_PerfAttrib_DuraContrib                ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_BenchmarkFactor            ;
extern FIELD_IDX_T A_PerfAttrib_AbcissaRank                ;
extern FIELD_IDX_T A_PerfAttrib_OrdinateRank               ;
extern FIELD_IDX_T A_PerfAttrib_ReturnCurrContrib          ; /* REF9227 - LJE - 030918 */
extern FIELD_IDX_T A_PerfAttrib_ReturnCapContrib           ; /* REF9227 - LJE - 030918 */
extern FIELD_IDX_T A_PerfAttrib_CompletePeriodFlg          ; /* REF9770 - LJE - 031212 */
extern FIELD_IDX_T A_PerfAttrib_RecInfoMask                ;
extern FIELD_IDX_T A_PerfAttrib_PreviousId                 ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_NextId                     ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_OverPeriodId               ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_ParentObjId                ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_PerfAttrib_FirstPerfInterBenchId      ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_LastPerfInterBenchId       ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_ObjLnkBreakCriteria        ; /* REF9264 - LJE - 030630 */
extern FIELD_IDX_T A_PerfAttrib_MergeParentObjId           ;
extern FIELD_IDX_T A_PerfAttrib_BreakCriteria              ; /* REF9264 - LJE - 030625 */
extern FIELD_IDX_T A_PerfAttrib_ParentBreakCriteria        ; /* REF9344 - LJE - 031014 */
extern FIELD_IDX_T A_PerfAttrib_GlobalPerfAttrib_Ext       ;
extern FIELD_IDX_T A_PerfAttrib_Bench1PerfAttrib_Ext       ;
extern FIELD_IDX_T A_PerfAttrib_Bench2PerfAttrib_Ext       ;
extern FIELD_IDX_T A_PerfAttrib_Bench3PerfAttrib_Ext       ;
extern FIELD_IDX_T A_PerfAttrib_RiskFreeStdPerf_Ext        ;
extern FIELD_IDX_T A_PerfAttrib_Parent_Ext                 ;
extern FIELD_IDX_T A_PerfAttrib_Previous_Ext               ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_Next_Ext                   ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_OverPeriod_Ext             ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_PerfAttrib_ParentObj_Ext              ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_PerfAttrib_SubSetBreakCriteria        ; /* REF10276 - LJE - 041110 : For optim */
extern FIELD_IDX_T A_PerfAttrib_BenchInitialDate           ; /* REF11462 - LJE - 051206 */
extern FIELD_IDX_T A_PerfAttrib_BenchFinalDate             ; /* REF11462 - LJE - 051206 */
extern FIELD_IDX_T A_PerfAttrib_FirstPerfInterBench_Ext    ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_LastPerfInterBench_Ext     ; /* PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfAttrib_Children_Ext               ; /* PMSTA08736 - LJE - 100203 */
extern FIELD_IDX_T A_PerfAttrib_HeadPtf_Ext                ; /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
extern FIELD_IDX_T A_PerfAttrib_RecStatusEn                ; /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */


extern FIELD_IDX_T S_PerfAttrib_Id                         ;
extern FIELD_IDX_T S_PerfAttrib_PerfStorParamId            ;
extern FIELD_IDX_T S_PerfAttrib_EntDictId                  ;
extern FIELD_IDX_T S_PerfAttrib_ObjId                      ;
extern FIELD_IDX_T S_PerfAttrib_FreqEn                     ;
extern FIELD_IDX_T S_PerfAttrib_CurrId                     ;
extern FIELD_IDX_T S_PerfAttrib_PosDataId                  ;
extern FIELD_IDX_T S_PerfAttrib_GridId                     ;
extern FIELD_IDX_T S_PerfAttrib_PerfAttribRtnEn            ;
extern FIELD_IDX_T S_PerfAttrib_InitialDate                ;
extern FIELD_IDX_T S_PerfAttrib_FinalDate                  ;
extern FIELD_IDX_T S_PerfAttrib_MktSegtId                  ;
extern FIELD_IDX_T S_PerfAttrib_InstrId                    ;


extern FIELD_IDX_T A_PerfAttribData_Id                     ;
extern FIELD_IDX_T A_PerfAttribData_PspId                  ;
extern FIELD_IDX_T A_PerfAttribData_InitialDate            ;
extern FIELD_IDX_T A_PerfAttribData_FinalDate              ;
extern FIELD_IDX_T A_PerfAttribData_MktSegtId              ;
extern FIELD_IDX_T A_PerfAttribData_InstrId                ;
extern FIELD_IDX_T A_PerfAttribData_SubPeriodMask          ;
extern FIELD_IDX_T A_PerfAttribData_InitialMktVal          ;
extern FIELD_IDX_T A_PerfAttribData_FlowMeanCap            ;
extern FIELD_IDX_T A_PerfAttribData_WgtFactor              ;
extern FIELD_IDX_T A_PerfAttribData_Wgt                    ;
extern FIELD_IDX_T A_PerfAttribData_Rtn                    ;
extern FIELD_IDX_T A_PerfAttribData_RtnCurr                ;
extern FIELD_IDX_T A_PerfAttribData_Dura                   ; /* PMSTA08736 - LJE - 100118 */
extern FIELD_IDX_T A_PerfAttribData_BenchEntDictId         ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_PerfAttribData_BenchObjId             ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_PerfAttribData_FinalMktVal            ; /*REF9743-BRO-040205*/
extern FIELD_IDX_T A_PerfAttribData_Adjust                 ; /*REF9743-BRO-040205*/

/* REF9125 - LJE - 030811 */
extern FIELD_IDX_T A_PSPPositionData_Id;
extern FIELD_IDX_T A_PSPPositionData_Code;
extern FIELD_IDX_T A_PSPPositionData_Name;  /*PMSTA15347-BRO-130121*/
extern FIELD_IDX_T A_PSPPositionData_Denom; /*PMSTA15347-BRO-130121*/
extern FIELD_IDX_T A_PSPPositionData_PPSLoadEn;
extern FIELD_IDX_T A_PSPPositionData_PortPosTypeId;
extern FIELD_IDX_T A_PSPPositionData_ConsPtfId;
extern FIELD_IDX_T A_PSPPositionData_StratLnkNatEn;
extern FIELD_IDX_T A_PSPPositionData_MinLnkPriority;
extern FIELD_IDX_T A_PSPPositionData_MaxLnkPriority;
extern FIELD_IDX_T A_PSPPositionData_FundSplitRuleEn;
extern FIELD_IDX_T A_PSPPositionData_RiskExpoFlg;
extern FIELD_IDX_T A_PSPPositionData_OptRiskRuleEn;
extern FIELD_IDX_T A_PSPPositionData_DebtFlg;
extern FIELD_IDX_T A_PSPPositionData_FusRuleEn;
extern FIELD_IDX_T A_PSPPositionData_PosLogicalEn;
extern FIELD_IDX_T A_PSPPositionData_FusDateRuleEn;
extern FIELD_IDX_T A_PSPPositionData_QuoteValRuleId;
extern FIELD_IDX_T A_PSPPositionData_ExchValRuleId;
extern FIELD_IDX_T A_PSPPositionData_PosValRuleEn;
extern FIELD_IDX_T A_PSPPositionData_ExtPosListId;
extern FIELD_IDX_T A_PSPPositionData_MinStatEn;
extern FIELD_IDX_T A_PSPPositionData_MaxStatEn;

/* REF9125 - LJE - 030811 */
extern FIELD_IDX_T S_PSPPositionData_Id;
extern FIELD_IDX_T S_PSPPositionData_Code;
extern FIELD_IDX_T S_PSPPositionData_Name;  /*PMSTA15347-BRO-130121*/
extern FIELD_IDX_T S_PSPPositionData_Denom; /*PMSTA15347-BRO-130121*/

/*< PMSTA08736 - LJE - 100115 */
extern FIELD_IDX_T A_PerfEffectDef_Id                       ;
extern FIELD_IDX_T A_PerfEffectDef_Cd                       ;
extern FIELD_IDX_T A_PerfEffectDef_Name                     ;
extern FIELD_IDX_T A_PerfEffectDef_Denom                    ;
extern FIELD_IDX_T A_PerfEffectDef_PerfEffectNatEn          ;
extern FIELD_IDX_T A_PerfEffectDef_Rank                     ;
extern FIELD_IDX_T A_PerfEffectDef_A_PerfEffectLink_Ext     ;
extern FIELD_IDX_T A_PerfEffectDef_BreakCriteria            ; /* PMSTA-15017 - LJE - 120925 */

extern FIELD_IDX_T S_PerfEffectDef_Id                       ;
extern FIELD_IDX_T S_PerfEffectDef_Cd                       ;
extern FIELD_IDX_T S_PerfEffectDef_Name                     ;
extern FIELD_IDX_T S_PerfEffectDef_PerfEffectNatEn          ;

extern FIELD_IDX_T A_PerfEffectLink_MktSegtId               ;
extern FIELD_IDX_T A_PerfEffectLink_PerfEffectDefId         ;
extern FIELD_IDX_T A_PerfEffectLink_Rank                    ;
extern FIELD_IDX_T A_PerfEffectLink_InitPerfEffectDefId     ; /* PMSTA-14877 - LJE - 120913 */
extern FIELD_IDX_T A_PerfEffectLink_A_MktSgt_Ext            ;
extern FIELD_IDX_T A_PerfEffectLink_A_PerfEffectDef_Ext     ;
extern FIELD_IDX_T A_PerfEffectLink_Grouping                ; /* PMSTA-14965 - LJE - 120919 */
extern FIELD_IDX_T A_PerfEffectLink_BreakCriteria           ; /* PMSTA-15017 - LJE - 120925 */
extern FIELD_IDX_T A_PerfEffectLink_GridId                  ; /* PMSTA-15017 - LJE - 120925 */

extern FIELD_IDX_T S_PerfEffectLink_MktSegtId               ;
extern FIELD_IDX_T S_PerfEffectLink_PerfEffectDefId         ;
extern FIELD_IDX_T S_PerfEffectLink_PerfEffectDefCd         ;
extern FIELD_IDX_T S_PerfEffectLink_Rank                    ;
extern FIELD_IDX_T S_PerfEffectLink_PerfEffectNatEn         ;

extern FIELD_IDX_T A_PerfCurrencyContrib_Id                 ;
extern FIELD_IDX_T A_PerfCurrencyContrib_RefCurrId          ;
extern FIELD_IDX_T A_PerfCurrencyContrib_CurrId             ;
extern FIELD_IDX_T A_PerfCurrencyContrib_InitialDate        ;
extern FIELD_IDX_T A_PerfCurrencyContrib_FinalDate          ;
extern FIELD_IDX_T A_PerfCurrencyContrib_Return             ;
extern FIELD_IDX_T A_PerfCurrencyContrib_ShTermIntRate      ;
extern FIELD_IDX_T A_PerfCurrencyContrib_RiskFreeEarning    ;
extern FIELD_IDX_T A_PerfCurrencyContrib_InitialRate        ;
extern FIELD_IDX_T A_PerfCurrencyContrib_FinalRate          ;

extern FIELD_IDX_T A_PerfInterBench_Id                     ;
extern FIELD_IDX_T A_PerfInterBench_PerfEffectDefId        ;
extern FIELD_IDX_T A_PerfInterBench_Effect                 ;
extern FIELD_IDX_T A_PerfInterBench_Weight                 ;
extern FIELD_IDX_T A_PerfInterBench_Return                 ;
extern FIELD_IDX_T A_PerfInterBench_ReturnContrib          ;
extern FIELD_IDX_T A_PerfInterBench_Dura                   ;
extern FIELD_IDX_T A_PerfInterBench_DuraContrib            ;
extern FIELD_IDX_T A_PerfInterBench_InitPerfEffectDefId    ; /* PMSTA-14877 - LJE - 120912 */
extern FIELD_IDX_T A_PerfInterBench_EffectMarketSegmentId  ; /* PMSTA-15017 - LJE - 120925 */
extern FIELD_IDX_T A_PerfInterBench_NextPerfInterBenchId   ;
extern FIELD_IDX_T A_PerfInterBench_LinkedPerfAttribId     ;
extern FIELD_IDX_T A_PerfInterBench_NextPerfInterBench_Ext ;
extern FIELD_IDX_T A_PerfInterBench_LinkedPerfAttrib_Ext   ;
extern FIELD_IDX_T A_PerfInterBench_IdxFld                 ;
/*> PMSTA08736 - LJE - 100115 */

/*<PMSTA-21268 - SHR - 092115*/
extern FIELD_IDX_T A_PlanRule_Id							;
extern FIELD_IDX_T A_PlanRule_Cd							;
extern FIELD_IDX_T A_PlanRule_Name							;
extern FIELD_IDX_T A_PlanRule_Denom							;
extern FIELD_IDX_T A_PlanRule_PlanNatureEn					;
extern FIELD_IDX_T A_PlanRule_GeoId							;
extern FIELD_IDX_T A_PlanRule_CreationDate					;
extern FIELD_IDX_T A_PlanRule_CreationUserId				;
extern FIELD_IDX_T A_PlanRule_LastModifDate					;
extern FIELD_IDX_T A_PlanRule_LastUserId					;
extern FIELD_IDX_T A_PlanRule_CurrentPlanRuleHisto	        ;
extern FIELD_IDX_T A_PlanRule_LastPlanRuleHisto	            ;
extern FIELD_IDX_T A_PlanRule_Denomination					;
extern FIELD_IDX_T A_PlanRule_PlanRuleHisto					;

extern FIELD_IDX_T S_PlanRule_Id							;
extern FIELD_IDX_T S_PlanRule_Cd							;
extern FIELD_IDX_T S_PlanRule_Name							;


extern FIELD_IDX_T A_PlanRuleHisto_Id						;
extern FIELD_IDX_T A_PlanRuleHisto_PlanRuleId				;
extern FIELD_IDX_T A_PlanRuleHisto_BeginDate				;
extern FIELD_IDX_T A_PlanRuleHisto_PeriodFreqUnit			;
extern FIELD_IDX_T A_PlanRuleHisto_PeriodFreq				;
extern FIELD_IDX_T A_PlanRuleHisto_LastInvestDate			;
extern FIELD_IDX_T A_PlanRuleHisto_MinAmount				;
extern FIELD_IDX_T A_PlanRuleHisto_MaxAmount				;
extern FIELD_IDX_T A_PlanRuleHisto_CurrId					;
extern FIELD_IDX_T A_PlanRuleHisto_AmountNature				;
extern FIELD_IDX_T A_PlanRuleHisto_TaxRate					;
extern FIELD_IDX_T A_PlanRuleHisto_CreationDate				;
extern FIELD_IDX_T A_PlanRuleHisto_CreationUserId			;
extern FIELD_IDX_T A_PlanRuleHisto_LastModifDate			;
extern FIELD_IDX_T A_PlanRuleHisto_LastUserId				;

extern FIELD_IDX_T S_PlanRuleHisto_Id						;
extern FIELD_IDX_T S_PlanRuleHisto_PlanRuleId				;
extern FIELD_IDX_T S_PlanRuleHisto_PlanRuleCd               ;
extern FIELD_IDX_T S_PlanRuleHisto_BeginDate				;

extern FIELD_IDX_T A_PlanDefinition_Id						;
extern FIELD_IDX_T A_PlanDefinition_Cd						;
extern FIELD_IDX_T A_PlanDefinition_Name					;
extern FIELD_IDX_T A_PlanDefinition_Denom					;
extern FIELD_IDX_T A_PlanDefinition_Nature					;
extern FIELD_IDX_T A_PlanDefinition_TypeId					;
extern FIELD_IDX_T A_PlanDefinition_Status					;
extern FIELD_IDX_T A_PlanDefinition_ThirdPartyId			;
extern FIELD_IDX_T A_PlanDefinition_PortfolioId				;
extern FIELD_IDX_T A_PlanDefinition_ObjectiveNature			;
extern FIELD_IDX_T A_PlanDefinition_PlanRuleId				;
extern FIELD_IDX_T A_PlanDefinition_CreationDate			;
extern FIELD_IDX_T A_PlanDefinition_CreationUserId			;
extern FIELD_IDX_T A_PlanDefinition_LastModifDate			;
extern FIELD_IDX_T A_PlanDefinition_LastUserId				;
extern FIELD_IDX_T A_PlanDefinition_ValidationDate			;
extern FIELD_IDX_T A_PlanDefinition_ValidationUserId		;
extern FIELD_IDX_T A_PlanDefinition_CurrentObjective	    ;
extern FIELD_IDX_T A_PlanDefinition_DepositExecRuleEn       ; /* PMSTA-33148 - RAK - 181003 */
extern FIELD_IDX_T A_PlanDefinition_LastObjective           ;
extern FIELD_IDX_T A_PlanDefinition_CurrentInvestParam	    ;
extern FIELD_IDX_T A_PlanDefinition_LastInvestParam         ;
extern FIELD_IDX_T A_PlanDefinition_PlanObjectiveHisto_Ext  ;
extern FIELD_IDX_T A_PlanDefinition_PlanInvestParamHisto_Ext;
extern FIELD_IDX_T A_PlanDefinition_StandInstruct_Ext       ;
extern FIELD_IDX_T A_PlanDefinition_CashAllocModeEn         ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_PlanDefinition_CashRealignMethodEn     ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_PlanDefinition_InvestPlanTypeId        ;

extern FIELD_IDX_T S_PlanDefinition_Id						;
extern FIELD_IDX_T S_PlanDefinition_Cd						;
extern FIELD_IDX_T S_PlanDefinition_Name					;


extern FIELD_IDX_T A_PlanObjectiveHisto_Id							;
extern FIELD_IDX_T A_PlanObjectiveHisto_PlanDefinitionId			;
extern FIELD_IDX_T A_PlanObjectiveHisto_BeginDate					;
extern FIELD_IDX_T A_PlanObjectiveHisto_ObjectiveDate				;
extern FIELD_IDX_T A_PlanObjectiveHisto_PeriodFreqUnit				;
extern FIELD_IDX_T A_PlanObjectiveHisto_PeriodFreq					;
extern FIELD_IDX_T A_PlanObjectiveHisto_MinAmount					;
extern FIELD_IDX_T A_PlanObjectiveHisto_MaxAmount					;
extern FIELD_IDX_T A_PlanObjectiveHisto_CurrId						;
extern FIELD_IDX_T A_PlanObjectiveHisto_AmountNature				;
extern FIELD_IDX_T A_PlanObjectiveHisto_MinAmtIndexRule				;
extern FIELD_IDX_T A_PlanObjectiveHisto_MinAmtIndexValue			;
extern FIELD_IDX_T A_PlanObjectiveHisto_MaxAmtIndexRule				;
extern FIELD_IDX_T A_PlanObjectiveHisto_MaxAmtIndexValue			;
extern FIELD_IDX_T A_PlanObjectiveHisto_ExtpectedAmt; /* PMSTA-33148 - RAK - 181003 */
extern FIELD_IDX_T A_PlanObjectiveHisto_CreationDate				;
extern FIELD_IDX_T A_PlanObjectiveHisto_CreationUserId				;
extern FIELD_IDX_T A_PlanObjectiveHisto_LastModifDate				;
extern FIELD_IDX_T A_PlanObjectiveHisto_LastUserId					;
extern FIELD_IDX_T A_PlanObjectiveHisto_InvestP                     ;

extern FIELD_IDX_T S_PlanObjectiveHisto_Id							;
extern FIELD_IDX_T S_PlanObjectiveHisto_PlanDefinitionId			;
extern FIELD_IDX_T S_PlanObjectiveHisto_PlanDefinitionCd			;
extern FIELD_IDX_T S_PlanObjectiveHisto_BeginDate					;

extern FIELD_IDX_T A_PlanInvestParamHisto_Id						;
extern FIELD_IDX_T A_PlanInvestParamHisto_PlanDefinitionId			;
extern FIELD_IDX_T A_PlanInvestParamHisto_BeginDate					;
extern FIELD_IDX_T A_PlanInvestParamHisto_FirstInvestDate			;
extern FIELD_IDX_T A_PlanInvestParamHisto_EndOfMonthConv			;
extern FIELD_IDX_T A_PlanInvestParamHisto_InvestFreqUnit			;
extern FIELD_IDX_T A_PlanInvestParamHisto_InvestFreq				;
extern FIELD_IDX_T A_PlanInvestParamHisto_UpdAmtToObjective			;
extern FIELD_IDX_T A_PlanInvestParamHisto_UpdAmtToCash				;
extern FIELD_IDX_T A_PlanInvestParamHisto_MaxInvestAmt				;
extern FIELD_IDX_T A_PlanInvestParamHisto_TransferFromAcctId		;
extern FIELD_IDX_T A_PlanInvestParamHisto_TransferFromPortfolioId	;
extern FIELD_IDX_T A_PlanInvestParamHisto_InvestAcctId				;
extern FIELD_IDX_T A_PlanInvestParamHisto_GenCashOp					;
extern FIELD_IDX_T A_PlanInvestParamHisto_CreationDate				;
extern FIELD_IDX_T A_PlanInvestParamHisto_CreationUserId			;
extern FIELD_IDX_T A_PlanInvestParamHisto_LastModifDate				;
extern FIELD_IDX_T A_PlanInvestParamHisto_LastUserId				;
extern FIELD_IDX_T A_PlanInvestParamHisto_InvestmentDay				;
extern FIELD_IDX_T A_PlanInvestParamHisto_NextInvestDay				;
extern FIELD_IDX_T A_PlanInvestParamHisto_PlanInvestDate_Ext		;
extern FIELD_IDX_T A_PlanInvestParamHisto_RetryFreq                 ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestParamHisto_RetryFreqUnit             ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestParamHisto_MaxRetry                  ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestParamHisto_LastInvestDate            ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestParamHisto_OrderCycles               ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestParamHisto_StandingOrderExtRef		; /* PMSTA-33148-RAK-181005 */
extern FIELD_IDX_T A_PlanInvestParamHisto_CounterpartAcctC			; /* PMSTA-33148-RAK-181005 */
extern FIELD_IDX_T A_PlanInvestParamHisto_EndDateConfigEnum   	    ; /* PMSTA-46432-Autocash-08102021 */

extern FIELD_IDX_T S_PlanInvestParamHisto_Id						;
extern FIELD_IDX_T S_PlanInvestParamHisto_PlanDefinitionId			;
extern FIELD_IDX_T S_PlanInvestParamHisto_PlanDefinitionCd			;
extern FIELD_IDX_T S_PlanInvestParamHisto_BeginDate					;

extern FIELD_IDX_T A_PlanInvestDate_Id								;
extern FIELD_IDX_T A_PlanInvestDate_PlanInvestParamHistoId			;
extern FIELD_IDX_T A_PlanInvestDate_InvestmentDate					;
extern FIELD_IDX_T A_PlanInvestDate_Status							;
extern FIELD_IDX_T A_PlanInvestDate_CreationDate					;
extern FIELD_IDX_T A_PlanInvestDate_RetryNumber						; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestDate_EventNumber						; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestDate_EventCd							; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_PlanInvestDate_ValidFlag						;
extern FIELD_IDX_T A_PlanInvestDate_DbActionEn                      ;
extern FIELD_IDX_T A_PlanInvestDate_FreeDepositHistoId              ;

extern FIELD_IDX_T S_PlanInvestDate_Id								;
extern FIELD_IDX_T S_PlanInvestDate_PlanInvestParamHistoId			;
extern FIELD_IDX_T S_PlanInvestDate_InvestmentDate					;
extern FIELD_IDX_T S_PlanInvestDate_Status                          ;
extern FIELD_IDX_T S_PlanInvestDate_RetryNumber                     ;

extern FIELD_IDX_T A_FreeDepositHisto_Id							;
extern FIELD_IDX_T A_FreeDepositHisto_Cd							;
extern FIELD_IDX_T A_FreeDepositHisto_PlanDefinitionId				;
extern FIELD_IDX_T A_FreeDepositHisto_InvestmentDate				;
extern FIELD_IDX_T A_FreeDepositHisto_NatureEn                      ;
extern FIELD_IDX_T A_FreeDepositHisto_Status						;
extern FIELD_IDX_T A_FreeDepositHisto_TransferFromAcctId			;
extern FIELD_IDX_T A_FreeDepositHisto_TransferFromPortfolioId		;
extern FIELD_IDX_T A_FreeDepositHisto_Amount						;
extern FIELD_IDX_T A_FreeDepositHisto_CurrId						;
extern FIELD_IDX_T A_FreeDepositHisto_UpdAmtToCash					;
extern FIELD_IDX_T A_FreeDepositHisto_CreationDate					;
extern FIELD_IDX_T A_FreeDepositHisto_CreationUserId				;
extern FIELD_IDX_T A_FreeDepositHisto_LastModifDate					;
extern FIELD_IDX_T A_FreeDepositHisto_LastUserId					;
extern FIELD_IDX_T A_FreeDepositHisto_CounterpartAcctC              ; /* PMSTA-33148-RAK-181005 */

extern FIELD_IDX_T S_FreeDepositHisto_Id							;
extern FIELD_IDX_T S_FreeDepositHisto_Cd                            ;
extern FIELD_IDX_T S_FreeDepositHisto_InvestmentDate				;


/*>PMSTA-21268 - SHR - 092115*/

extern FIELD_IDX_T A_PtfChrono_PtfId                       ;
extern FIELD_IDX_T A_PtfChrono_CurrId                      ;
extern FIELD_IDX_T A_PtfChrono_ValidDate                   ;
extern FIELD_IDX_T A_PtfChrono_NatEn                       ;
extern FIELD_IDX_T A_PtfChrono_Val                         ;
extern FIELD_IDX_T A_PtfChrono_Comment                     ;
extern FIELD_IDX_T A_PtfChrono_TimeDimEn                   ;
extern FIELD_IDX_T A_PtfChrono_ValidFlg                    ;


extern FIELD_IDX_T S_PtfChrono_PtfId                       ;
extern FIELD_IDX_T S_PtfChrono_CurrId                      ;
extern FIELD_IDX_T S_PtfChrono_ValidDate                   ;
extern FIELD_IDX_T S_PtfChrono_NatEn                       ;
extern FIELD_IDX_T S_PtfChrono_PtfCd                       ;
extern FIELD_IDX_T S_PtfChrono_Val                         ;
extern FIELD_IDX_T S_PtfChrono_CurrCd                      ;


extern FIELD_IDX_T Freq_PtfChrono_PtfId                    ;
extern FIELD_IDX_T Freq_PtfChrono_CurrId                   ;
extern FIELD_IDX_T Freq_PtfChrono_ValidDate                ;
extern FIELD_IDX_T Freq_PtfChrono_NatEn                    ;
extern FIELD_IDX_T Freq_PtfChrono_Val                      ;
extern FIELD_IDX_T Freq_PtfChrono_RequestDate              ;


extern FIELD_IDX_T A_PtfFreq_Id                            ;
extern FIELD_IDX_T A_PtfFreq_PtfId                         ;
extern FIELD_IDX_T A_PtfFreq_InitialDate                   ;
extern FIELD_IDX_T A_PtfFreq_FreqDate                      ;
extern FIELD_IDX_T A_PtfFreq_PtfStatus                     ;
extern FIELD_IDX_T A_PtfFreq_A_Ptf_Ext                     ;


extern FIELD_IDX_T A_PtfPosSet_Id                          ;
extern FIELD_IDX_T A_PtfPosSet_PtfId                       ;
extern FIELD_IDX_T A_PtfPosSet_CurrId                      ;
extern FIELD_IDX_T A_PtfPosSet_TpId                        ;
extern FIELD_IDX_T A_PtfPosSet_ConsPtfId                   ;
extern FIELD_IDX_T A_PtfPosSet_QuoteValRuleId              ;
extern FIELD_IDX_T A_PtfPosSet_ExchValRuleId               ;
extern FIELD_IDX_T A_PtfPosSet_BookValRuleId               ;
extern FIELD_IDX_T A_PtfPosSet_AccPlanId                   ;
extern FIELD_IDX_T A_PtfPosSet_FusRuleEn                   ;
extern FIELD_IDX_T A_PtfPosSet_FusDateRuleEn               ;
extern FIELD_IDX_T A_PtfPosSet_PosLogicalEn                ;
extern FIELD_IDX_T A_PtfPosSet_BegDate                     ;
extern FIELD_IDX_T A_PtfPosSet_EndDate                     ;
extern FIELD_IDX_T A_PtfPosSet_BookAdjFreq                 ;
extern FIELD_IDX_T A_PtfPosSet_BookAdjFreqUnitEn           ;
extern FIELD_IDX_T A_PtfPosSet_TransferCompFlg             ;
extern FIELD_IDX_T A_PtfPosSet_BookPreAdjFlg               ;
extern FIELD_IDX_T A_PtfPosSet_PtfSynthFlg                 ;
extern FIELD_IDX_T A_PtfPosSet_PnLRuleId                   ;
extern FIELD_IDX_T A_PtfPosSet_OldFusDateRuleEn            ; /*REF10256-BRO-040716*/


extern FIELD_IDX_T S_PtfPosSet_Id                          ;
extern FIELD_IDX_T S_PtfPosSet_PtfId                       ;
extern FIELD_IDX_T S_PtfPosSet_CurrId                      ;
extern FIELD_IDX_T S_PtfPosSet_TpId                        ;
extern FIELD_IDX_T S_PtfPosSet_ConsPtfId                   ;
extern FIELD_IDX_T S_PtfPosSet_CurrCd                      ;
extern FIELD_IDX_T S_PtfPosSet_TpCd                        ;
extern FIELD_IDX_T S_PtfPosSet_ConsPtfCd                   ;


extern FIELD_IDX_T A_PtfReturn_FromDate                    ;
extern FIELD_IDX_T A_PtfReturn_TillDate                    ;
extern FIELD_IDX_T A_PtfReturn_Method                      ;
extern FIELD_IDX_T A_PtfReturn_RiskNatEn                   ;
extern FIELD_IDX_T A_PtfReturn_TaxCredFlg                  ;
extern FIELD_IDX_T A_PtfReturn_GrossEffectFlg              ;
extern FIELD_IDX_T A_PtfReturn_RealCapP                    ;
extern FIELD_IDX_T A_PtfReturn_RealCapL                    ;
extern FIELD_IDX_T A_PtfReturn_RealCurrP                   ;
extern FIELD_IDX_T A_PtfReturn_RealCurrL                   ;
extern FIELD_IDX_T A_PtfReturn_RecInc                      ;
extern FIELD_IDX_T A_PtfReturn_PaidInc                     ;
extern FIELD_IDX_T A_PtfReturn_RecAccrInter                ;
extern FIELD_IDX_T A_PtfReturn_PaidAccrInter               ;
extern FIELD_IDX_T A_PtfReturn_PtfFees                     ;
extern FIELD_IDX_T A_PtfReturn_PtfTax                      ;
extern FIELD_IDX_T A_PtfReturn_TaxCred                     ;
extern FIELD_IDX_T A_PtfReturn_UnrealCapP                  ;
extern FIELD_IDX_T A_PtfReturn_UnrealCapL                  ;
extern FIELD_IDX_T A_PtfReturn_UnrealCurrP                 ;
extern FIELD_IDX_T A_PtfReturn_UnrealCurrL                 ;
extern FIELD_IDX_T A_PtfReturn_UnrealRecAccrInter          ;
extern FIELD_IDX_T A_PtfReturn_UnrealPaidAccrInter         ;
extern FIELD_IDX_T A_PtfReturn_TotalReturn                 ;
extern FIELD_IDX_T A_PtfReturn_CapEffect                   ;
extern FIELD_IDX_T A_PtfReturn_CurrEffect                  ;
extern FIELD_IDX_T A_PtfReturn_IncEffect                   ;
extern FIELD_IDX_T A_PtfReturn_FeesTaxEffect               ;
extern FIELD_IDX_T A_PtfReturn_RealCapEffect               ;
extern FIELD_IDX_T A_PtfReturn_RealCurrEffect              ;
extern FIELD_IDX_T A_PtfReturn_RealIncEffect               ;
extern FIELD_IDX_T A_PtfReturn_UnrealCapEffect             ;
extern FIELD_IDX_T A_PtfReturn_UnrealCurrEffect            ;
extern FIELD_IDX_T A_PtfReturn_UnrealIncEffect             ;
extern FIELD_IDX_T A_PtfReturn_MeanCap                     ;
extern FIELD_IDX_T A_PtfReturn_MeanCapGlobal;
extern FIELD_IDX_T A_PtfReturn_Flows                       ;
extern FIELD_IDX_T A_PtfReturn_PosFees                     ; /* REF11269 - LJE - 051222 */
extern FIELD_IDX_T A_PtfReturn_PosTax                      ; /* REF11269 - LJE - 051222 */
extern FIELD_IDX_T A_PtfReturn_InitNumDays                 ; /* PMSTA-11731 - LJE - 110420 */
extern FIELD_IDX_T A_PtfReturn_FinalNumDays                ; /* PMSTA-11731 - LJE - 110420 */


extern FIELD_IDX_T A_PtfSynth_Id                           ;
extern FIELD_IDX_T A_PtfSynth_PtfId                        ;
extern FIELD_IDX_T A_PtfSynth_PtfPosSetId                  ;
extern FIELD_IDX_T A_PtfSynth_CurrId                       ;
extern FIELD_IDX_T A_PtfSynth_InstrId                      ;
extern FIELD_IDX_T A_PtfSynth_MktSegtId                    ;
extern FIELD_IDX_T A_PtfSynth_GridId                       ;
extern FIELD_IDX_T A_PtfSynth_AbsMktSegId                  ;
extern FIELD_IDX_T A_PtfSynth_OrdMktSegId                  ;
extern FIELD_IDX_T A_PtfSynth_ParMktSegId                  ;
extern FIELD_IDX_T A_PtfSynth_ParGridId                    ;
extern FIELD_IDX_T A_PtfSynth_HeadGridId                   ;
extern FIELD_IDX_T A_PtfSynth_RiskNatEn                    ;
extern FIELD_IDX_T A_PtfSynth_InitialDate                  ;
extern FIELD_IDX_T A_PtfSynth_FinalDate                    ;
extern FIELD_IDX_T A_PtfSynth_InitialNumDays               ;
extern FIELD_IDX_T A_PtfSynth_FinalNumDays                 ;
extern FIELD_IDX_T A_PtfSynth_FirstFlowNumDays             ;
extern FIELD_IDX_T A_PtfSynth_Level                        ;
extern FIELD_IDX_T A_PtfSynth_NetRealCapP                  ;
extern FIELD_IDX_T A_PtfSynth_GrossRealCapP                ;
extern FIELD_IDX_T A_PtfSynth_NetRealCapL                  ;
extern FIELD_IDX_T A_PtfSynth_GrossRealCapL                ;
extern FIELD_IDX_T A_PtfSynth_NetRealCurrP                 ;
extern FIELD_IDX_T A_PtfSynth_GrossRealCurrP               ;
extern FIELD_IDX_T A_PtfSynth_NetRealCurrL                 ;
extern FIELD_IDX_T A_PtfSynth_GrossRealCurrL               ;
extern FIELD_IDX_T A_PtfSynth_NetRecInc                    ;
extern FIELD_IDX_T A_PtfSynth_GrossRecInc                  ;
extern FIELD_IDX_T A_PtfSynth_NetPaidInc                   ;
extern FIELD_IDX_T A_PtfSynth_GrossPaidInc                 ;
extern FIELD_IDX_T A_PtfSynth_RecAccrInter                 ;
extern FIELD_IDX_T A_PtfSynth_PaidAccrInter                ;
extern FIELD_IDX_T A_PtfSynth_PtfFees                      ;
extern FIELD_IDX_T A_PtfSynth_PtfTax                       ;
extern FIELD_IDX_T A_PtfSynth_TaxCred                      ;
extern FIELD_IDX_T A_PtfSynth_NetCostVal                   ;
extern FIELD_IDX_T A_PtfSynth_GrossCostVal                 ;
extern FIELD_IDX_T A_PtfSynth_NetUnrealCapP                ;
extern FIELD_IDX_T A_PtfSynth_GrossUnrealCapP              ;
extern FIELD_IDX_T A_PtfSynth_NetUnrealCapL                ;
extern FIELD_IDX_T A_PtfSynth_GrossUnrealCapL              ;
extern FIELD_IDX_T A_PtfSynth_NetUnrealCurrP               ;
extern FIELD_IDX_T A_PtfSynth_GrossUnrealCurrP             ;
extern FIELD_IDX_T A_PtfSynth_NetUnrealCurrL               ;
extern FIELD_IDX_T A_PtfSynth_GrossUnrealCurrL             ;
extern FIELD_IDX_T A_PtfSynth_NetInvest                    ;
extern FIELD_IDX_T A_PtfSynth_GrossInvest                  ;
extern FIELD_IDX_T A_PtfSynth_NetWithdr                    ;
extern FIELD_IDX_T A_PtfSynth_GrossWithdr                  ;
extern FIELD_IDX_T A_PtfSynth_NetAdj                       ;
extern FIELD_IDX_T A_PtfSynth_GrossAdj                     ;
extern FIELD_IDX_T A_PtfSynth_InitialMktVal                ;
extern FIELD_IDX_T A_PtfSynth_FinalMktVal                  ;
extern FIELD_IDX_T A_PtfSynth_UnrealRecAccrInter           ;
extern FIELD_IDX_T A_PtfSynth_UnrealPaidAccrInter          ;
extern FIELD_IDX_T A_PtfSynth_WeightNetInvest              ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossInvest            ;
extern FIELD_IDX_T A_PtfSynth_WeightNetWithdr              ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossWithdr            ;
extern FIELD_IDX_T A_PtfSynth_WeightTaxCred                ;
extern FIELD_IDX_T A_PtfSynth_WeightNetAdj                 ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossAdj               ;
extern FIELD_IDX_T A_PtfSynth_NetPurchases                 ;
extern FIELD_IDX_T A_PtfSynth_GrossPurchases               ;
extern FIELD_IDX_T A_PtfSynth_NetSales                     ;
extern FIELD_IDX_T A_PtfSynth_GrossSales                   ;
extern FIELD_IDX_T A_PtfSynth_WeightNetPurchases           ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossPurchases         ;
extern FIELD_IDX_T A_PtfSynth_WeightNetSales               ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossSales             ;
extern FIELD_IDX_T A_PtfSynth_WeightNetRecInc              ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossRecInc            ;
extern FIELD_IDX_T A_PtfSynth_WeightNetPaidInc             ;
extern FIELD_IDX_T A_PtfSynth_WeightGrossPaidInc           ;
extern FIELD_IDX_T A_PtfSynth_WeightPtfFees                ;
extern FIELD_IDX_T A_PtfSynth_WeightPtfTax                 ;
extern FIELD_IDX_T A_PtfSynth_InitUnrealRecAI              ;
extern FIELD_IDX_T A_PtfSynth_FinUnrealRecAI               ;
extern FIELD_IDX_T A_PtfSynth_InitUnrealPaidAI             ;
extern FIELD_IDX_T A_PtfSynth_FinUnrealPaidAI              ;
extern FIELD_IDX_T A_PtfSynth_PersistEn                    ;
extern FIELD_IDX_T A_PtfSynth_PeriodNatEn                  ;
extern FIELD_IDX_T A_PtfSynth_InitialNotInvestedDays       ; /* PMSTA-52459 - DDV - 230414 */
extern FIELD_IDX_T A_PtfSynth_FinalNotInvestedDays         ; /* PMSTA-52459 - DDV - 230414 */
extern FIELD_IDX_T A_PtfSynth_IntradayNIPFlg               ; /* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
extern FIELD_IDX_T A_PtfSynth_PSPId                        ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_PtfSynth_Qty                          ; /* REF9338 - LJE - 030923 */
extern FIELD_IDX_T A_PtfSynth_PosFees                      ; /* REF11269 - LJE - 051220 */
extern FIELD_IDX_T A_PtfSynth_PosTax                       ; /* REF11269 - LJE - 051220 */
extern FIELD_IDX_T A_PtfSynth_WeightPosFees                ; /* REF11269 - LJE - 051220 */
extern FIELD_IDX_T A_PtfSynth_WeightPosTax                 ; /* REF11269 - LJE - 051220 */
extern FIELD_IDX_T A_PtfSynth_Dura                         ; /* PMSTA08736 - LJE - 100120 */
extern FIELD_IDX_T A_PtfSynth_PurchasesAccrInter           ;
extern FIELD_IDX_T A_PtfSynth_SalesAccrInter               ;
extern FIELD_IDX_T A_PtfSynth_InvestAccrInter              ;
extern FIELD_IDX_T A_PtfSynth_WithdrAccrInter              ;
extern FIELD_IDX_T A_PtfSynth_CostPriceAdjCapP			   ; /* PMSTA-9217 - RAK - 100223 */
extern FIELD_IDX_T A_PtfSynth_CostPriceAdjCapL		       ; /* PMSTA-9217 - RAK - 100223 */
extern FIELD_IDX_T A_PtfSynth_CostPriceAdjCurrP		       ; /* PMSTA-9217 - RAK - 100223 */
extern FIELD_IDX_T A_PtfSynth_CostPriceAdjCurrL  	       ; /* PMSTA-9217 - RAK - 100223 */
extern FIELD_IDX_T A_PtfSynth_LastFlowNumDays              ;
extern FIELD_IDX_T A_PtfSynth_GridLinkNatEn                ;
extern FIELD_IDX_T A_PtfSynth_ParentId                     ; /* REF9743 - LJE - 040216 */
extern FIELD_IDX_T A_PtfSynth_Parent_Ext                   ; /* REF9743 - LJE - 040216 */
extern FIELD_IDX_T A_PtfSynth_ToInsertEn                   ; /* PMSTA06591 - LJE - 080522 */
extern FIELD_IDX_T A_PtfSynth_RiskOriginAdjFlg             ;
extern FIELD_IDX_T A_PtfSynth_ParentSplit_Ext              ;
extern FIELD_IDX_T A_PtfSynth_FundSplitNatEn               ;
extern FIELD_IDX_T A_PtfSynth_FirstOpNatEn                 ; /* PMSTA-42154 - vkumar - 011220 */
extern FIELD_IDX_T A_PtfSynth_AddedInParentFlg             ; /* PMSTA-48195 -to find good to remove synth -Lalby-060722*/
extern FIELD_IDX_T A_PtfSynth_HeadPspId                    ; /* PMSTA-48195 */
extern FIELD_IDX_T A_PtfSynth_ListId                       ; /* PMSTA-53952 - Lalby - 14112023  */
extern FIELD_IDX_T A_PtfSynth_GblPtfSynth_Ext			   ; /* Deepthi - PMSTA-55377- 240117*/
extern FIELD_IDX_T A_PtfSynth_PtfInAdj                     ; /* WEALTH-9725 - Lalby - 25062024- Manage Ptf in and out using PCP */
extern FIELD_IDX_T A_PtfSynth_PtfOutAdj                    ;
extern FIELD_IDX_T A_PtfSynth_MktSegInAdj                  ;
extern FIELD_IDX_T A_PtfSynth_MktSegOutAdj                 ;
extern FIELD_IDX_T A_PtfSynth_NextMktSegtId                ; /* WEALTH-8023 - DDV - 240627 */


extern FIELD_IDX_T S_PtfSynth_Id                           ;
extern FIELD_IDX_T S_PtfSynth_PtfId                        ;
extern FIELD_IDX_T S_PtfSynth_PtfPosSetId                  ;
extern FIELD_IDX_T S_PtfSynth_CurrId                       ;
extern FIELD_IDX_T S_PtfSynth_InstrId                      ;
extern FIELD_IDX_T S_PtfSynth_MktSegtId                    ;
extern FIELD_IDX_T S_PtfSynth_RiskNatEn                    ;
extern FIELD_IDX_T S_PtfSynth_InitialDate                  ;
extern FIELD_IDX_T S_PtfSynth_FinalDate                    ;
extern FIELD_IDX_T S_PtfSynth_PersistEn                    ;


extern FIELD_IDX_T Zero_PtfSynth_PtfId                     ;
extern FIELD_IDX_T Zero_PtfSynth_PtfPosSetId               ;
extern FIELD_IDX_T Zero_PtfSynth_CurrId                    ;
extern FIELD_IDX_T Zero_PtfSynth_InstrId                   ;
extern FIELD_IDX_T Zero_PtfSynth_GridId                    ;
extern FIELD_IDX_T Zero_PtfSynth_MktSegtId                 ;
extern FIELD_IDX_T Zero_PtfSynth_RiskNatEn                 ;
extern FIELD_IDX_T Zero_PtfSynth_FirstFlowNumDays          ;
extern FIELD_IDX_T Zero_PtfSynth_FinalNumDays              ;
extern FIELD_IDX_T Zero_PtfSynth_ZeroFlg                   ;
extern FIELD_IDX_T Zero_PtfSynth_PSPId                     ; /* REF9743 - LJE - 040218 */
extern FIELD_IDX_T Zero_PtfSynth_PersistEn                 ;



extern FIELD_IDX_T A_Pos_Id                                ;
extern FIELD_IDX_T A_Pos_PtfId                             ;
extern FIELD_IDX_T A_Pos_PtfPosSetId                       ;
extern FIELD_IDX_T A_Pos_InstrId                           ;
extern FIELD_IDX_T A_Pos_DepoId                            ;
extern FIELD_IDX_T A_Pos_PosCurrId                         ;
extern FIELD_IDX_T A_Pos_InstrCurrId                       ;
extern FIELD_IDX_T A_Pos_PtfCurrId                         ;
extern FIELD_IDX_T A_Pos_CntPtyThirdId                     ;
extern FIELD_IDX_T A_Pos_OpenOpId                          ;
extern FIELD_IDX_T A_Pos_CloseOpId                         ;
extern FIELD_IDX_T A_Pos_TermTpId                          ;
extern FIELD_IDX_T A_Pos_LockTpId                          ;
extern FIELD_IDX_T A_Pos_ValRuleEltId                      ;
extern FIELD_IDX_T A_Pos_OpenOpNatEn                       ;
extern FIELD_IDX_T A_Pos_AdjustNatEn                       ;
extern FIELD_IDX_T A_Pos_OpenOpCd                          ;
extern FIELD_IDX_T A_Pos_CloseOpCd                         ;
extern FIELD_IDX_T A_Pos_RefOpCd                           ;
extern FIELD_IDX_T A_Pos_RefNatEn                          ;
extern FIELD_IDX_T A_Pos_ExecOpCd                          ;
extern FIELD_IDX_T A_Pos_ExecOpNatEn                       ;
extern FIELD_IDX_T A_Pos_ExecOpStatEn                      ;
extern FIELD_IDX_T A_Pos_RevOpCd                           ;
extern FIELD_IDX_T A_Pos_RevOpNatEn                        ;
extern FIELD_IDX_T A_Pos_LockOpCd                          ;
extern FIELD_IDX_T A_Pos_LockNatEn                         ;
extern FIELD_IDX_T A_Pos_EventCd                           ;
extern FIELD_IDX_T A_Pos_EventNbr                          ;
extern FIELD_IDX_T A_Pos_StatEn                            ;
extern FIELD_IDX_T A_Pos_PrimaryEn                         ;
extern FIELD_IDX_T A_Pos_MainFlag                          ;
extern FIELD_IDX_T A_Pos_PosNatEn                          ;
extern FIELD_IDX_T A_Pos_SubPosNatEn                       ;
extern FIELD_IDX_T A_Pos_SubPosNat2En                      ;
extern FIELD_IDX_T A_Pos_SubPosNat3En                      ;
extern FIELD_IDX_T A_Pos_ExCouponFlag                      ;
extern FIELD_IDX_T A_Pos_Fus                               ;
extern FIELD_IDX_T A_Pos_FusRuleEn                         ;
extern FIELD_IDX_T A_Pos_BegDate                           ;
extern FIELD_IDX_T A_Pos_EndDate                           ;
extern FIELD_IDX_T A_Pos_OpDate                            ;
extern FIELD_IDX_T A_Pos_AcctDate                          ;
extern FIELD_IDX_T A_Pos_ValDate                           ;
extern FIELD_IDX_T A_Pos_LockLimitDate                     ;
extern FIELD_IDX_T A_Pos_ExpirDate                         ;
extern FIELD_IDX_T A_Pos_AccrAmt                           ;
extern FIELD_IDX_T A_Pos_OrderLimitDate                    ;
extern FIELD_IDX_T A_Pos_Remark                            ;
extern FIELD_IDX_T A_Pos_PosExchRate                       ;
extern FIELD_IDX_T A_Pos_InstrExchRate                     ;
extern FIELD_IDX_T A_Pos_SysExchRate                       ;
extern FIELD_IDX_T A_Pos_BookPosExchRate                   ;
extern FIELD_IDX_T A_Pos_BookInstrExchRate                 ;
extern FIELD_IDX_T A_Pos_BookSysExchRate                   ;
extern FIELD_IDX_T A_Pos_Qty                               ;
extern FIELD_IDX_T A_Pos_Price                             ;
extern FIELD_IDX_T A_Pos_SpotPrice                         ;
extern FIELD_IDX_T A_Pos_BookPrice                         ;
extern FIELD_IDX_T A_Pos_PriceCalcRuleEn                   ;
extern FIELD_IDX_T A_Pos_Quote                             ;
extern FIELD_IDX_T A_Pos_SpotQuote                         ;
extern FIELD_IDX_T A_Pos_BookQuote                         ;
extern FIELD_IDX_T A_Pos_Rate                              ;
extern FIELD_IDX_T A_Pos_SupplAmt                          ;
extern FIELD_IDX_T A_Pos_PosGrossAmt                       ;
extern FIELD_IDX_T A_Pos_PosNetAmt                         ;
extern FIELD_IDX_T A_Pos_InstrGrossAmt                     ;
extern FIELD_IDX_T A_Pos_InstrNetAmt                       ;
extern FIELD_IDX_T A_Pos_PtfGrossAmt                       ;
extern FIELD_IDX_T A_Pos_PtfNetAmt                         ;
extern FIELD_IDX_T A_Pos_SysGrossAmt                       ;
extern FIELD_IDX_T A_Pos_SysNetAmt                         ;
extern FIELD_IDX_T A_Pos_BookPosAmt                        ;
extern FIELD_IDX_T A_Pos_BookInstrAmt                      ;
extern FIELD_IDX_T A_Pos_BookPtfAmt                        ;
extern FIELD_IDX_T A_Pos_BookSysAmt                        ;
extern FIELD_IDX_T A_Pos_Bp1PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp2PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp3PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp4PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp5PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp6PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp7PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp8PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp9PosAmt                         ;
extern FIELD_IDX_T A_Pos_Bp10PosAmt                        ;
extern FIELD_IDX_T A_Pos_HistQuote                         ;  /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T A_Pos_UnpaidPrct                        ;  /* PMSTA-16533 - 221113 - PMO */
extern FIELD_IDX_T A_Pos_PosNetIncreaseAmt                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosGrossIncreaseAmt               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosNetDecreaseAmt                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosGrossDecreaseAmt               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosNetIncreaseYearAmt             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosGrossIncreaseYearAmt           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosNetDecreaseYearAmt             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PosGrossDecreaseYearAmt           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfNetIncreaseAmt                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfGrossIncreaseAmt                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfNetDecreaseAmt                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfGrossDecreaseAmt                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfNetIncreaseYearAmt              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfGrossIncreaseYearAmt            ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfNetDecreaseYearAmt              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_PfGrossDecreaseYearAmt            ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_AcquisitionDate                   ; /* PMSTA-28286 - JBC - 207699 */
extern FIELD_IDX_T A_Pos_AcquisitionOpenOpId               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_TaxLotInitialId                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_BpPosExchangeRate                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_BpFiExchangeRate                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_BpSysExchangeRate                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_CorporateActionNatEn              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_TaxLotSourceCd                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T A_Pos_StandInstructId                   ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T A_Pos_PaymentOption                     ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T A_Pos_LockQuantity                      ; /*PMSTA-39162 -NRAO- 03052020*/
extern FIELD_IDX_T A_Pos_PaymentDate                       ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Pos_PaymentStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Pos_SettlementDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Pos_SettleStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T A_Pos_BusinessAcquisitionDate           ; /* PMSTA-49603 - AIS - 220626 */
extern FIELD_IDX_T A_Pos_FlowInfoEn                        ; /* PMSTA-47578 - DDV - 220117 */
extern FIELD_IDX_T A_Pos_TimingRuleEn                      ; /* PMSTA-47578 - DDV - 220117 */

extern FIELD_IDX_T S_Pos_Id                                ;
extern FIELD_IDX_T S_Pos_PtfId                             ;
extern FIELD_IDX_T S_Pos_InstrId                           ;
extern FIELD_IDX_T S_Pos_OpenOpNatEn                       ;
extern FIELD_IDX_T S_Pos_OpenOpCd                          ;
extern FIELD_IDX_T S_Pos_RefNatEn                          ;
extern FIELD_IDX_T S_Pos_PrimaryEn                         ;
extern FIELD_IDX_T S_Pos_BegDate                           ;
extern FIELD_IDX_T S_Pos_EndDate                           ;
extern FIELD_IDX_T S_Pos_Qty                               ;
extern FIELD_IDX_T S_Pos_Price                             ;
extern FIELD_IDX_T S_Pos_PriceCalcRuleEn                   ;
extern FIELD_IDX_T S_Pos_Quote                             ;
extern FIELD_IDX_T S_Pos_InstrNetAmt                       ;
extern FIELD_IDX_T S_Pos_PosGrossAmt                       ;
extern FIELD_IDX_T S_Pos_PosNetAmt                         ;


extern FIELD_IDX_T A_Printer_Id                            ;
extern FIELD_IDX_T A_Printer_Cd                            ;
extern FIELD_IDX_T A_Printer_PrintModeEn                   ;
extern FIELD_IDX_T A_Printer_Comment                       ;
extern FIELD_IDX_T A_Printer_Device                        ;
extern FIELD_IDX_T A_Printer_Command                       ;


extern FIELD_IDX_T S_Printer_Id                            ;
extern FIELD_IDX_T S_Printer_Cd                            ;
extern FIELD_IDX_T S_Printer_PrintModeEn                   ;
extern FIELD_IDX_T S_Printer_Comment                       ;


extern FIELD_IDX_T A_PrinterProf_Id                        ;
extern FIELD_IDX_T A_PrinterProf_Cd                        ;


extern FIELD_IDX_T S_PrinterProf_Id                        ;
extern FIELD_IDX_T S_PrinterProf_Cd                        ;


extern FIELD_IDX_T A_PrinterProfCompo_PrintProfId          ;
extern FIELD_IDX_T A_PrinterProfCompo_PrinterId            ;
extern FIELD_IDX_T A_PrinterProfCompo_Display              ;


extern FIELD_IDX_T S_PrinterProfCompo_PrintProfId          ;
extern FIELD_IDX_T S_PrinterProfCompo_PrinterId            ;
extern FIELD_IDX_T S_PrinterProfCompo_Display              ;
extern FIELD_IDX_T S_PrinterProfCompo_PrintProfCd          ;
extern FIELD_IDX_T S_PrinterProfCompo_PrintCd              ;


extern FIELD_IDX_T A_PrintParam_OutputTpEn                 ;
extern FIELD_IDX_T A_PrintParam_OutputName                 ;
extern FIELD_IDX_T A_PrintParam_RoiOutputName              ;
extern FIELD_IDX_T A_PrintParam_DestiEn                    ;
extern FIELD_IDX_T A_PrintParam_Copy                       ;
extern FIELD_IDX_T A_PrintParam_DelFlg                     ;
extern FIELD_IDX_T A_PrintParam_DbgOption                  ;
extern FIELD_IDX_T A_PrintParam_PrinterId                  ;
extern FIELD_IDX_T A_PrintParam_PrinterFlg                 ;
extern FIELD_IDX_T A_PrintParam_PreviewFlg                 ;
extern FIELD_IDX_T A_PrintParam_FileFlg                    ;
extern FIELD_IDX_T A_PrintParam_DebugLineFlg               ;
extern FIELD_IDX_T A_PrintParam_DebugProcFlg               ;
extern FIELD_IDX_T A_PrintParam_DebugTimeFlg               ;
extern FIELD_IDX_T A_PrintParam_DebugDomainFlg             ;
extern FIELD_IDX_T A_PrintParam_DebugDelimitedFlg          ;


extern FIELD_IDX_T A_QuickSearch_Id                        ;


extern FIELD_IDX_T A_Rating_Id                             ;
extern FIELD_IDX_T A_Rating_Cd                             ;
extern FIELD_IDX_T A_Rating_CodifId                        ;
extern FIELD_IDX_T A_Rating_AutoCreatedFlg                 ;
extern FIELD_IDX_T A_Rating_Rank                           ;


extern FIELD_IDX_T S_Rating_Id                             ;
extern FIELD_IDX_T S_Rating_CodifCd                        ;
extern FIELD_IDX_T S_Rating_Cd                             ;
extern FIELD_IDX_T S_Rating_Rank                           ;
extern FIELD_IDX_T S_Rating_CodifId                        ;


extern FIELD_IDX_T A_RatingAttr_EntDictId                  ;
extern FIELD_IDX_T A_RatingAttr_ObjId                      ;
extern FIELD_IDX_T A_RatingAttr_CodifId                    ;
extern FIELD_IDX_T A_RatingAttr_BegDate                    ;
extern FIELD_IDX_T A_RatingAttr_RatingId                   ;


extern FIELD_IDX_T S_RatingAttr_EntDictId                  ;
extern FIELD_IDX_T S_RatingAttr_ObjId                      ;
extern FIELD_IDX_T S_RatingAttr_CodifId                    ;
extern FIELD_IDX_T S_RatingAttr_BegDate                    ;
extern FIELD_IDX_T S_RatingAttr_RatingCd                   ;
extern FIELD_IDX_T S_RatingAttr_CodifCd                    ;


extern FIELD_IDX_T A_Regr_Array1                           ;
extern FIELD_IDX_T A_Regr_Array2                           ;
extern FIELD_IDX_T A_Regr_RecNbr                           ;
extern FIELD_IDX_T A_Regr_Alpha                            ;
extern FIELD_IDX_T A_Regr_Beta                             ;
extern FIELD_IDX_T A_Regr_Covariance                       ;
extern FIELD_IDX_T A_Regr_CorrelationCoef                  ;
extern FIELD_IDX_T A_Regr_DetermCoefR2                     ;
extern FIELD_IDX_T A_Regr_ChiSquared                       ;
extern FIELD_IDX_T A_Regr_StdDeviationAlpha                ;
extern FIELD_IDX_T A_Regr_StdDeviationBeta                 ;
extern FIELD_IDX_T A_Regr_GoodnessFitProbQ                 ;


extern FIELD_IDX_T A_Report_Id                             ;
extern FIELD_IDX_T A_Report_Cd                             ;
extern FIELD_IDX_T A_Report_Denom                          ;
extern FIELD_IDX_T A_Report_FmtProfId                      ;
extern FIELD_IDX_T A_Report_TitleMsgId                     ;
extern FIELD_IDX_T A_Report_TabContentId                   ;
extern FIELD_IDX_T A_Report_TypeId                         ; /*REF9782-BRO-040203*/
extern FIELD_IDX_T A_Report_NatEn                          ;
extern FIELD_IDX_T A_Report_AutoGenFlg                     ;
extern FIELD_IDX_T A_Report_OrienFlg                       ;
extern FIELD_IDX_T A_Report_HeaderName                     ;
extern FIELD_IDX_T A_Report_FooterName                     ;
extern FIELD_IDX_T A_Report_BeforePageName                 ;
extern FIELD_IDX_T A_Report_AfterPageName                  ;
extern FIELD_IDX_T A_Report_LastGenDt                      ;
extern FIELD_IDX_T A_Report_TocHeadFlg                     ;
extern FIELD_IDX_T A_Report_TocFootFlg                     ;
extern FIELD_IDX_T A_Report_BefPageHeadFlg                 ;
extern FIELD_IDX_T A_Report_BefPageFootFlg                 ;
extern FIELD_IDX_T A_Report_AftPageHeadFlg                 ;
extern FIELD_IDX_T A_Report_AftPageFootFlg                 ;
extern FIELD_IDX_T A_Report_ExtAppl                        ;
extern FIELD_IDX_T A_Report_DfltDomainFlg                  ;
extern FIELD_IDX_T A_Report_BusinessNatureEn               ;  /* PMSTA-17248 - EFE - 20131121 */
extern FIELD_IDX_T A_Report_ClassName					   ;  /*PMSTA- 20039 - SHR - 20150225 */


extern FIELD_IDX_T S_Report_Id                             ;
extern FIELD_IDX_T S_Report_Cd                             ;
extern FIELD_IDX_T S_Report_Denom                          ;
extern FIELD_IDX_T S_Report_NatEn                          ;
extern FIELD_IDX_T S_Report_TypeId                         ; /*REF9782-PRO-040212*/
extern FIELD_IDX_T S_Report_ClassName						       ;  /*PMSTA- 20126 - Cashwini - 04072015 */

extern FIELD_IDX_T A_ReportGen_ReportId                    ;
extern FIELD_IDX_T A_ReportGen_AllReportFlg                ;
extern FIELD_IDX_T A_ReportGen_ActionEn                    ;
extern FIELD_IDX_T A_ReportGen_ForceFlg                    ;


extern FIELD_IDX_T A_ReportParam_Id                        ;
extern FIELD_IDX_T A_ReportParam_ReportId                  ;
extern FIELD_IDX_T A_ReportParam_Rank                      ;
extern FIELD_IDX_T A_ReportParam_ParAttrDictId             ;
extern FIELD_IDX_T A_ReportParam_ExtFlg                    ;
extern FIELD_IDX_T A_ReportParam_AttrSqlName               ;
extern FIELD_IDX_T A_ReportParam_DataTpDictId              ;


extern FIELD_IDX_T S_ReportParam_Id                        ;
extern FIELD_IDX_T S_ReportParam_ReportId                  ;
extern FIELD_IDX_T S_ReportParam_Rank                      ;
extern FIELD_IDX_T S_ReportParam_ParAttrDictId             ;
extern FIELD_IDX_T S_ReportParam_ExtFlg                    ;
extern FIELD_IDX_T S_ReportParam_AttrSqlName               ;
extern FIELD_IDX_T S_ReportParam_DataTpDictId              ;
extern FIELD_IDX_T S_ReportParam_ReportCd                  ;
extern FIELD_IDX_T S_ReportParam_DataTpName                ;


extern FIELD_IDX_T A_ReportProf_Id                         ;
extern FIELD_IDX_T A_ReportProf_Cd                         ;


extern FIELD_IDX_T S_ReportProf_Id                         ;
extern FIELD_IDX_T S_ReportProf_Cd                         ;


extern FIELD_IDX_T A_ReportProfCompo_ReportProfId          ;
extern FIELD_IDX_T A_ReportProfCompo_ReportId              ;


extern FIELD_IDX_T S_ReportProfCompo_ReportProfId          ;
extern FIELD_IDX_T S_ReportProfCompo_ReportId              ;
extern FIELD_IDX_T S_ReportProfCompo_ReportCd              ;

/* PMSTA-25021 - TEB - 161110 */
extern FIELD_IDX_T A_ReportModuleCompo_Id                  ;
extern FIELD_IDX_T A_ReportModuleCompo_ReportId;
extern FIELD_IDX_T A_ReportModuleCompo_ModuleId;
extern FIELD_IDX_T A_ReportModuleCompo_Rank;
extern FIELD_IDX_T A_ReportModuleCompo_PageCountResetFlg;
extern FIELD_IDX_T A_ReportModuleCompo_PageToCountFlg;
extern FIELD_IDX_T A_ReportModuleCompo_PaginationStyleEn;
extern FIELD_IDX_T A_ReportModuleCompo_PositionEn;
extern FIELD_IDX_T A_ReportModuleCompo_VisibleInTocFlg;

/* PMSTA-25021 - TEB - 161110 */
extern FIELD_IDX_T S_ReportModuleCompo_Id;
extern FIELD_IDX_T S_ReportModuleCompo_ReportId;
extern FIELD_IDX_T S_ReportModuleCompo_ReportModuleId;
extern FIELD_IDX_T S_ReportModuleCompo_Rank;
extern FIELD_IDX_T S_ReportModuleCompo_ModuleName;


/*<REF10604-BRO-040922*/
extern FIELD_IDX_T A_RequestCode_Id                        ;
extern FIELD_IDX_T A_RequestCode_RequestCodeCd             ;
extern FIELD_IDX_T A_RequestCode_TradingPlaceId            ;
extern FIELD_IDX_T A_RequestCode_CodifId                   ;

extern FIELD_IDX_T S_RequestCode_Id                        ;
extern FIELD_IDX_T S_RequestCode_RequestCodeCd             ;
extern FIELD_IDX_T S_RequestCode_TradingPlaceId            ;
extern FIELD_IDX_T S_RequestCode_CodifId                   ;
extern FIELD_IDX_T S_RequestCode_CodifCd                   ;
/*>REF10604-BRO-040922*/


extern FIELD_IDX_T A_RetAnaDetailed_Id                     ;
extern FIELD_IDX_T A_RetAnaDetailed_PspId                  ;
extern FIELD_IDX_T A_RetAnaDetailed_MktSegtId              ;
extern FIELD_IDX_T A_RetAnaDetailed_InstrId                ;
extern FIELD_IDX_T A_RetAnaDetailed_InitialDate            ;
extern FIELD_IDX_T A_RetAnaDetailed_FinalDate              ;
extern FIELD_IDX_T A_RetAnaDetailed_InitialMktVal          ;
extern FIELD_IDX_T A_RetAnaDetailed_FinalMktVal            ;
extern FIELD_IDX_T A_RetAnaDetailed_Fees                   ;
extern FIELD_IDX_T A_RetAnaDetailed_Taxes                  ;
extern FIELD_IDX_T A_RetAnaDetailed_Flows                  ;
extern FIELD_IDX_T A_RetAnaDetailed_ProfitLoss             ;
extern FIELD_IDX_T A_RetAnaDetailed_FlowMeanCap            ;
extern FIELD_IDX_T A_RetAnaDetailed_MeanCapital            ;
extern FIELD_IDX_T A_RetAnaDetailed_Rtn                    ;
extern FIELD_IDX_T A_RetAnaDetailed_TaxCredit              ;
extern FIELD_IDX_T A_RetAnaDetailed_DeltaNetGross          ;
extern FIELD_IDX_T A_RetAnaDetailed_Dividend               ;
extern FIELD_IDX_T A_RetAnaDetailed_MeanInvestCap          ;
extern FIELD_IDX_T A_RetAnaDetailed_Rtn1                   ;
extern FIELD_IDX_T A_RetAnaDetailed_Adjust                 ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_RetAnaDetailed_RtnGross               ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T A_RetAnaDetailed_Income1M			   ;
extern FIELD_IDX_T A_RetAnaDetailed_Income2M			   ;
extern FIELD_IDX_T A_RetAnaDetailed_CapPl1M				   ;
extern FIELD_IDX_T A_RetAnaDetailed_CapPl2M				   ;
extern FIELD_IDX_T A_RetAnaDetailed_CurrPl1M			   ;
extern FIELD_IDX_T A_RetAnaDetailed_CurrPl2M			   ;
extern FIELD_IDX_T A_RetAnaDetailed_CapEffect			   ;
extern FIELD_IDX_T A_RetAnaDetailed_CurrEffect			   ;
extern FIELD_IDX_T A_RetAnaDetailed_FeesTaxEffect		   ;
extern FIELD_IDX_T A_RetAnaDetailed_IncomeEffect		   ;

extern FIELD_IDX_T A_RetAnaGlobal_Id                       ;
extern FIELD_IDX_T A_RetAnaGlobal_TaxCredit                ;
extern FIELD_IDX_T A_RetAnaGlobal_DeltaNetGross            ;
extern FIELD_IDX_T A_RetAnaGlobal_Dividend                 ;
extern FIELD_IDX_T A_RetAnaGlobal_MeanInvestCap            ;
extern FIELD_IDX_T A_RetAnaGlobal_Rtn1                     ;
extern FIELD_IDX_T A_RetAnaGlobal_Invest                   ;
extern FIELD_IDX_T A_RetAnaGlobal_Withdr                   ;
extern FIELD_IDX_T A_RetAnaGlobal_Inc1                     ;
extern FIELD_IDX_T A_RetAnaGlobal_Inc2                     ;
extern FIELD_IDX_T A_RetAnaGlobal_CapPl1                   ;
extern FIELD_IDX_T A_RetAnaGlobal_CapPl2                   ;
extern FIELD_IDX_T A_RetAnaGlobal_CurrPl1                  ;
extern FIELD_IDX_T A_RetAnaGlobal_CurrPl2                  ;
extern FIELD_IDX_T A_RetAnaGlobal_Rtn2                     ;
extern FIELD_IDX_T A_RetAnaGlobal_Rtn3                     ;
extern FIELD_IDX_T A_RetAnaGlobal_CapEffect                ;
extern FIELD_IDX_T A_RetAnaGlobal_CurrEffect               ;
extern FIELD_IDX_T A_RetAnaGlobal_FeesTaxEffect            ;
extern FIELD_IDX_T A_RetAnaGlobal_IncEffect                ;
extern FIELD_IDX_T A_RetAnaGlobal_Adjust                   ; /*REF9743-BRO-040206*/


extern FIELD_IDX_T A_RetAnalysisId_Id                      ;

extern FIELD_IDX_T S_RetAnalysisId_Id                      ;
extern FIELD_IDX_T S_RetAnalysisId_BlockSize               ;
extern FIELD_IDX_T S_RetAnalysisId_IdentityResSize         ;

extern FIELD_IDX_T S_ExtOrderBlockId_Id					   ; /* PMSTA-46001 - AAKASH - 161221 */
extern FIELD_IDX_T S_ExtOrderBlockId_BlockSize			   ;
extern FIELD_IDX_T S_ExtOrderBlockId_IdentityResSize	   ;

extern FIELD_IDX_T A_ReturnGridLnk_GridId                  ;
extern FIELD_IDX_T A_ReturnGridLnk_EntDictId               ;
extern FIELD_IDX_T A_ReturnGridLnk_ObjId                   ;
extern FIELD_IDX_T A_ReturnGridLnk_NatEn                   ;


extern FIELD_IDX_T S_ReturnGridLnk_GridId                  ;
extern FIELD_IDX_T S_ReturnGridLnk_EntDictId               ;
extern FIELD_IDX_T S_ReturnGridLnk_ObjId                   ;
extern FIELD_IDX_T S_ReturnGridLnk_GridCd                  ;
extern FIELD_IDX_T S_ReturnGridLnk_NatEn                   ;


extern FIELD_IDX_T A_RiskRatio_AMean                       ;
extern FIELD_IDX_T A_RiskRatio_GMean                       ;
extern FIELD_IDX_T A_RiskRatio_Volatility                  ;
extern FIELD_IDX_T A_RiskRatio_Min                         ;
extern FIELD_IDX_T A_RiskRatio_Max                         ;
extern FIELD_IDX_T A_RiskRatio_BenchAMean                  ;
extern FIELD_IDX_T A_RiskRatio_BenchGMean                  ;
extern FIELD_IDX_T A_RiskRatio_BenchVolat                  ;
extern FIELD_IDX_T A_RiskRatio_BenchMin                    ;
extern FIELD_IDX_T A_RiskRatio_BenchMax                    ;
extern FIELD_IDX_T A_RiskRatio_RFAMean                     ;
extern FIELD_IDX_T A_RiskRatio_RFGMean                     ;
extern FIELD_IDX_T A_RiskRatio_RFVolat                     ;
extern FIELD_IDX_T A_RiskRatio_RFMin                       ;
extern FIELD_IDX_T A_RiskRatio_RFMax                       ;
extern FIELD_IDX_T A_RiskRatio_Sharpe                      ;
extern FIELD_IDX_T A_RiskRatio_BenchSharpe                 ;
extern FIELD_IDX_T A_RiskRatio_Beta                        ;
extern FIELD_IDX_T A_RiskRatio_Treynor                     ;
extern FIELD_IDX_T A_RiskRatio_Jensen                      ;
extern FIELD_IDX_T A_RiskRatio_ExcessReturn                ;
extern FIELD_IDX_T A_RiskRatio_TrackingError               ;
extern FIELD_IDX_T A_RiskRatio_InformationRatio            ;


extern FIELD_IDX_T A_RuleCompo_RuleId                      ;
extern FIELD_IDX_T A_RuleCompo_AttribDictId                ;


extern FIELD_IDX_T S_RuleCompo_RuleId                      ;
extern FIELD_IDX_T S_RuleCompo_AttribDictId                ;
extern FIELD_IDX_T S_RuleCompo_EntSqlName                  ;
extern FIELD_IDX_T S_RuleCompo_AttribSqlName               ;


extern FIELD_IDX_T A_Scena_Id                              ;
extern FIELD_IDX_T A_Scena_Cd                              ;
extern FIELD_IDX_T A_Scena_Name                            ;


extern FIELD_IDX_T S_Scena_Id                              ;
extern FIELD_IDX_T S_Scena_Cd                              ;
extern FIELD_IDX_T S_Scena_Name                            ;


extern FIELD_IDX_T A_ScenaCompo_ParScenaId                 ;
extern FIELD_IDX_T A_ScenaCompo_ChildScenaId               ;
extern FIELD_IDX_T A_ScenaCompo_WgtPrct                    ;


extern FIELD_IDX_T S_ScenaCompo_ParScenaId                 ;
extern FIELD_IDX_T S_ScenaCompo_ChildScenaId               ;
extern FIELD_IDX_T S_ScenaCompo_WgtPrct                    ;
extern FIELD_IDX_T S_ScenaCompo_ParScenaCd                 ;


extern FIELD_IDX_T A_ScenaElt_ScenaId                      ;
extern FIELD_IDX_T A_ScenaElt_DictId                       ;
extern FIELD_IDX_T A_ScenaElt_ObjId                        ;
extern FIELD_IDX_T A_ScenaElt_ValidDate                    ;
extern FIELD_IDX_T A_ScenaElt_NatEn                        ;
extern FIELD_IDX_T A_ScenaElt_Val                          ;
extern FIELD_IDX_T A_ScenaElt_GrowthPrct                   ;


extern FIELD_IDX_T S_ScenaElt_ScenaId                      ;


extern FIELD_IDX_T A_ScreenProf_Id                         ;
extern FIELD_IDX_T A_ScreenProf_Cd                         ;


extern FIELD_IDX_T S_ScreenProf_Id                         ;
extern FIELD_IDX_T S_ScreenProf_Cd                         ;


extern FIELD_IDX_T A_ScreenProfCompo_ScreenProfId          ;
extern FIELD_IDX_T A_ScreenProfCompo_EntDictId             ;
extern FIELD_IDX_T A_ScreenProfCompo_NatAttrDictId         ;
extern FIELD_IDX_T A_ScreenProfCompo_TpAttrDictId          ;
extern FIELD_IDX_T A_ScreenProfCompo_SubTpAttrDictId       ;
extern FIELD_IDX_T A_ScreenProfCompo_TpId                  ;
extern FIELD_IDX_T A_ScreenProfCompo_SubTpId               ;
extern FIELD_IDX_T A_ScreenProfCompo_NatEn                 ;
extern FIELD_IDX_T A_ScreenProfCompo_ScreenDictId          ;
extern FIELD_IDX_T A_ScreenProfCompo_RuleId                ;
extern FIELD_IDX_T A_ScreenProfCompo_FctDictId             ;
extern FIELD_IDX_T A_ScreenProfCompo_ReportId              ;
extern FIELD_IDX_T A_ScreenProfCompo_Rank                  ;


extern FIELD_IDX_T S_ScreenProfCompo_ScreenProfId          ;
extern FIELD_IDX_T S_ScreenProfCompo_EntDictId             ;
extern FIELD_IDX_T S_ScreenProfCompo_NatAttrDictId         ;
extern FIELD_IDX_T S_ScreenProfCompo_TpAttrDictId          ;
extern FIELD_IDX_T S_ScreenProfCompo_SubTpAttrDictId       ;
extern FIELD_IDX_T S_ScreenProfCompo_TpId                  ;
extern FIELD_IDX_T S_ScreenProfCompo_SubTpId               ;
extern FIELD_IDX_T S_ScreenProfCompo_NatEn                 ;
extern FIELD_IDX_T S_ScreenProfCompo_ScreenDictId          ;
extern FIELD_IDX_T S_ScreenProfCompo_FctDictId             ;
extern FIELD_IDX_T S_ScreenProfCompo_ReportId              ;
extern FIELD_IDX_T S_ScreenProfCompo_EntSqlName            ;
extern FIELD_IDX_T S_ScreenProfCompo_TpAttrName            ;
extern FIELD_IDX_T S_ScreenProfCompo_SubTpAttrName         ;
extern FIELD_IDX_T S_ScreenProfCompo_NatAttrName           ;
extern FIELD_IDX_T S_ScreenProfCompo_TpCd                  ;
extern FIELD_IDX_T S_ScreenProfCompo_SubTpCd               ;
extern FIELD_IDX_T S_ScreenProfCompo_ScreenName            ;
extern FIELD_IDX_T S_ScreenProfCompo_Denom                 ;
extern FIELD_IDX_T S_ScreenProfCompo_FctName               ;
extern FIELD_IDX_T S_ScreenProfCompo_ReportCd              ;
extern FIELD_IDX_T S_ScreenProfCompo_Rank                  ;


extern FIELD_IDX_T A_ScriptDef_Id                          ;
extern FIELD_IDX_T A_ScriptDef_AttrDictId                  ;
extern FIELD_IDX_T A_ScriptDef_ObjId                       ;
extern FIELD_IDX_T A_ScriptDef_NatEn                       ;
extern FIELD_IDX_T A_ScriptDef_Rank                        ;
extern FIELD_IDX_T A_ScriptDef_LastUserId                  ;
extern FIELD_IDX_T A_ScriptDef_LastModifDate               ;
extern FIELD_IDX_T A_ScriptDef_Def                         ;
extern FIELD_IDX_T A_ScriptDef_DimEntityDictId             ; /*REF11296-EFE-050714*/
extern FIELD_IDX_T A_ScriptDef_ScriptEntRefDictId          ; /*REF11296-EFE-050714*/
extern FIELD_IDX_T A_ScriptDef_ActionEn                    ; /*REF11296-EFE-050714*/

extern FIELD_IDX_T S_ScriptDef_Id                          ;
extern FIELD_IDX_T S_ScriptDef_AttrDictId                  ;
extern FIELD_IDX_T S_ScriptDef_ObjId                       ;
extern FIELD_IDX_T S_ScriptDef_NatEn                       ;
extern FIELD_IDX_T S_ScriptDef_Rank                        ;
extern FIELD_IDX_T S_ScriptDef_ActionEn                    ;


/*<REF11296-BRO-060406*/
extern FIELD_IDX_T A_ScriptLibrary_Id					   ;
extern FIELD_IDX_T A_ScriptLibrary_Cd                      ;
extern FIELD_IDX_T A_ScriptLibrary_SqlName                 ;
extern FIELD_IDX_T A_ScriptLibrary_EntDictId               ;
extern FIELD_IDX_T A_ScriptLibrary_Denom                   ;
extern FIELD_IDX_T A_ScriptLibrary_NatEn                   ;


extern FIELD_IDX_T S_ScriptLibrary_Id					   ;
extern FIELD_IDX_T S_ScriptLibrary_Cd					   ;
extern FIELD_IDX_T S_ScriptLibrary_SqlName				   ;
extern FIELD_IDX_T S_ScriptLibrary_EntSqlName			   ;
/*>REF11296-BRO-060406*/


/*  FIH-REF9789-031222  */
extern FIELD_IDX_T A_SearchCrit_Id                         ;
extern FIELD_IDX_T A_SearchCrit_Cd                         ;
extern FIELD_IDX_T A_SearchCrit_FuncDictId                 ;
extern FIELD_IDX_T A_SearchCrit_EntDictId                  ;


extern FIELD_IDX_T S_SearchCrit_Id                         ;
extern FIELD_IDX_T S_SearchCrit_Cd                         ;
extern FIELD_IDX_T S_SearchCrit_FuncDictId                 ;
extern FIELD_IDX_T S_SearchCrit_EntDictId                  ;
extern FIELD_IDX_T S_SearchCrit_EntSqlName                 ;
extern FIELD_IDX_T S_SearchCrit_FctName                    ;


/*  FIH-REF9789-031222  */
extern FIELD_IDX_T A_SearchCritCompo_Id                    ;
extern FIELD_IDX_T A_SearchCritCompo_SearchCritId          ;
extern FIELD_IDX_T A_SearchCritCompo_AttrDictId            ;
extern FIELD_IDX_T A_SearchCritCompo_TpId                  ;
extern FIELD_IDX_T A_SearchCritCompo_MandatoryFlg          ;
extern FIELD_IDX_T A_SearchCritCompo_Rank                  ;
extern FIELD_IDX_T A_SearchCritCompo_SearchNatEn           ; /*REF9743-BRO-040209*/
extern FIELD_IDX_T A_SearchCritCompo_DefOperatorEn         ; /*REF9743-BRO-040209*/
extern FIELD_IDX_T A_SearchCritCompo_ModifiableFlg         ; /*REF10294-BRO-040921*/

extern FIELD_IDX_T S_SearchCritCompo_Id                    ;
extern FIELD_IDX_T S_SearchCritCompo_SearchCritId          ;
extern FIELD_IDX_T S_SearchCritCompo_AttrDictId            ;
extern FIELD_IDX_T S_SearchCritCompo_TpId                  ;
extern FIELD_IDX_T S_SearchCritCompo_MandatoryFlg          ;
extern FIELD_IDX_T S_SearchCritCompo_Rank                  ;
extern FIELD_IDX_T S_SearchCritCompo_SearchNatEn           ; /*REF9743-BRO-040209*/
extern FIELD_IDX_T S_SearchCritCompo_DefOperatorEn         ; /*REF9743-BRO-040209*/
extern FIELD_IDX_T S_SearchCritCompo_ModifiableFlg         ;    /*  FPL-REF10294-040929 */
extern FIELD_IDX_T S_SearchCritCompo_AttrName              ;
extern FIELD_IDX_T S_SearchCritCompo_TpCd                  ;

extern FIELD_IDX_T O_SearchCritCompo_Id                    ;
extern FIELD_IDX_T O_SearchCritCompo_SearchCritId          ;
extern FIELD_IDX_T O_SearchCritCompo_AttrSqlName           ;
extern FIELD_IDX_T O_SearchCritCompo_AttrDictId            ;
extern FIELD_IDX_T O_SearchCritCompo_TpId                  ;
extern FIELD_IDX_T O_SearchCritCompo_TpCd                  ;
extern FIELD_IDX_T O_SearchCritCompo_MandatoryFlg          ;
extern FIELD_IDX_T O_SearchCritCompo_Rank                  ;
extern FIELD_IDX_T O_SearchCritCompo_SearchNatEn           ;
extern FIELD_IDX_T O_SearchCritCompo_DefOperatorEn         ;
extern FIELD_IDX_T O_SearchCritCompo_ModifiableFlg         ;


/*  FIH-REF9789-031222  */
extern FIELD_IDX_T A_SearchProf_Id                         ;
extern FIELD_IDX_T A_SearchProf_Cd                         ;
extern FIELD_IDX_T A_SearchProf_FullSearchFlg              ;


extern FIELD_IDX_T S_SearchProf_Id                         ;
extern FIELD_IDX_T S_SearchProf_Cd                         ;
extern FIELD_IDX_T S_SearchProf_FullSearchFlg              ;


/*  FIH-REF9789-031222  */
extern FIELD_IDX_T A_SearchProfCompo_Id                    ;
extern FIELD_IDX_T A_SearchProfCompo_SearchProfId          ;
extern FIELD_IDX_T A_SearchProfCompo_SearchCritId          ;
extern FIELD_IDX_T A_SearchProfCompo_FullSearchFlg         ;
extern FIELD_IDX_T A_SearchProfCompo_SearchCritCd          ;
extern FIELD_IDX_T A_SearchProfCompo_SearchCritEntDictId   ;
extern FIELD_IDX_T A_SearchProfCompo_SearchCritFuncDictId  ;


extern FIELD_IDX_T S_SearchProfCompo_Id                    ;
extern FIELD_IDX_T S_SearchProfCompo_SearchProfId          ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritId          ;
extern FIELD_IDX_T S_SearchProfCompo_FullSearchFlg         ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritCd          ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritEntDictId   ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritFuncDictId  ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritEntSqlName  ;
extern FIELD_IDX_T S_SearchProfCompo_SearchCritFctName     ;

/* PMSTA-15655 - LJE - 130121 */
extern FIELD_IDX_T A_SelSearchCritCompoArg_CommandEn    ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_FctDictId    ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_FctProcName  ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_EntDictId    ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_EntSqlName   ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_OutputParam  ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_UserId       ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_LangDictId   ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_SearchProfId ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_FullSearchFlg;
extern FIELD_IDX_T A_SelSearchCritCompoArg_SearchCritId ;
extern FIELD_IDX_T A_SelSearchCritCompoArg_ApplSessionCd; /* PMSTA-22549 - CHU - 160512 */

/*  HFI-PMSTA-35838-190515  */
extern FIELD_IDX_T A_SelFctSecuProfCompoArg_ApplSessionCd ;
extern FIELD_IDX_T A_SelFctSecuProfCompoArg_FctProcName   ;
extern FIELD_IDX_T A_SelFctSecuProfCompoArg_ParFctProcName;
extern FIELD_IDX_T A_SelFctSecuProfCompoArg_AuthOnlyFlag  ;

extern FIELD_IDX_T A_Sect_Id                               ;
extern FIELD_IDX_T A_Sect_Cd                               ;
extern FIELD_IDX_T A_Sect_Name                             ;
extern FIELD_IDX_T A_Sect_Denom                            ;
extern FIELD_IDX_T A_Sect_CodifId                          ;
extern FIELD_IDX_T A_Sect_ParSectId                        ;
extern FIELD_IDX_T A_Sect_AutoCreatedFlg                   ;


extern FIELD_IDX_T S_Sect_Id                               ;
extern FIELD_IDX_T S_Sect_CodifCd                          ;
extern FIELD_IDX_T S_Sect_Cd                               ;
extern FIELD_IDX_T S_Sect_Name                             ;
extern FIELD_IDX_T S_Sect_ParSectCd                        ;
extern FIELD_IDX_T S_Sect_CodifId                          ;
extern FIELD_IDX_T S_Sect_SynCodifId                       ;


extern FIELD_IDX_T A_SectAttr_EntDictId                    ;
extern FIELD_IDX_T A_SectAttr_ObjId                        ;
extern FIELD_IDX_T A_SectAttr_CodifId                      ;
extern FIELD_IDX_T A_SectAttr_ValidDt                      ;
extern FIELD_IDX_T A_SectAttr_SectId                       ;


extern FIELD_IDX_T S_SectAttr_EntDictId                    ;
extern FIELD_IDX_T S_SectAttr_ObjId                        ;
extern FIELD_IDX_T S_SectAttr_CodifId                      ;
extern FIELD_IDX_T S_SectAttr_ValidDt                      ;
extern FIELD_IDX_T S_SectAttr_CodifCd                      ;
extern FIELD_IDX_T S_SectAttr_SectCd                       ;
extern FIELD_IDX_T S_SectAttr_SectName                     ;


extern FIELD_IDX_T A_ShareOpInfo_PtfId                     ;
extern FIELD_IDX_T A_ShareOpInfo_InstrId                   ;
extern FIELD_IDX_T A_ShareOpInfo_ValDate                   ;
extern FIELD_IDX_T A_ShareOpInfo_ValoSeqNo                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info1Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info1Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info2Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info2Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info3Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info3Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info4Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info4Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info5Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info5Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info6Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info6Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info7Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info7Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info8Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info8Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info9Name                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info9Data                 ;
extern FIELD_IDX_T A_ShareOpInfo_Info10Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info10Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info11Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info11Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info12Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info12Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info13Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info13Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info14Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info14Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info15Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info15Data                ;
extern FIELD_IDX_T A_ShareOpInfo_Info16Name                ;
extern FIELD_IDX_T A_ShareOpInfo_Info16Data                ;
extern FIELD_IDX_T A_ShareOpInfo_EntDictId                 ;
extern FIELD_IDX_T A_ShareOpInfo_Qty                       ;


extern FIELD_IDX_T A_StandardPerf_Id                       ;
extern FIELD_IDX_T A_StandardPerf_PerfStorParamId          ;
extern FIELD_IDX_T A_StandardPerf_EntDictId                ;
extern FIELD_IDX_T A_StandardPerf_ObjId                    ;
extern FIELD_IDX_T A_StandardPerf_FreqEn                   ;
extern FIELD_IDX_T A_StandardPerf_CurrId                   ;
extern FIELD_IDX_T A_StandardPerf_PosDataId                ;
extern FIELD_IDX_T A_StandardPerf_GridId                   ;
extern FIELD_IDX_T A_StandardPerf_PerfAttribRtnEn          ;
extern FIELD_IDX_T A_StandardPerf_InitialDate              ;
extern FIELD_IDX_T A_StandardPerf_FinalDate                ;
extern FIELD_IDX_T A_StandardPerf_InitialMktVal            ;
extern FIELD_IDX_T A_StandardPerf_FinalMktVal              ;
extern FIELD_IDX_T A_StandardPerf_Fees                     ;
extern FIELD_IDX_T A_StandardPerf_Taxes                    ;
extern FIELD_IDX_T A_StandardPerf_Flows                    ;
extern FIELD_IDX_T A_StandardPerf_ProfitLoss               ;
extern FIELD_IDX_T A_StandardPerf_FlowMeanCap              ;
extern FIELD_IDX_T A_StandardPerf_MeanCapital              ;
extern FIELD_IDX_T A_StandardPerf_Rtn                      ;
extern FIELD_IDX_T A_StandardPerf_RtnGross                 ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_StandardPerf_StdDeviation             ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_StandardPerf_NbPtf                    ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_StandardPerf_PortSynthId              ;
extern FIELD_IDX_T A_StandardPerf_ExtStratEltId            ;
extern FIELD_IDX_T A_StandardPerf_StratSynthId             ;
extern FIELD_IDX_T A_StandardPerf_InstrFreqId              ;
extern FIELD_IDX_T A_StandardPerf_PtfFreqId                ;
extern FIELD_IDX_T A_StandardPerf_RiskFreeId               ;
extern FIELD_IDX_T A_StandardPerf_BenchId                  ;
extern FIELD_IDX_T A_StandardPerf_CompletePeriodFlg        ; /* REF9770 - LJE - 031212 */
extern FIELD_IDX_T A_StandardPerf_RecInfoMask              ;
extern FIELD_IDX_T A_StandardPerf_PreviousId               ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_NextId	               ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_OverPeriodId			   ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_ParentObjId              ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_StandardPerf_MergeParentObjId         ;
extern FIELD_IDX_T A_StandardPerf_RiskFree_Ext             ;
extern FIELD_IDX_T A_StandardPerf_Bench_Ext                ;
extern FIELD_IDX_T A_StandardPerf_Previous_Ext             ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_Next_Ext                 ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_OverPeriod_Ext           ; /* PMSTA07393 - LJE - 081203 */
extern FIELD_IDX_T A_StandardPerf_ParentObj_Ext            ; /* WEALTH-7754 - DDV - 241024 */
extern FIELD_IDX_T A_StandardPerf_ObjLnkBreakCriteria      ; /* REF9264 - LJE - 030630 */
extern FIELD_IDX_T A_StandardPerf_BreakCriteria            ; /* REF9264 - LJE - 030625 */
extern FIELD_IDX_T A_StandardPerf_ParentBreakCriteria      ; /* REF9344 - LJE - 031014 */
extern FIELD_IDX_T A_StandardPerf_SubSetBreakCriteria      ; /* REF10276 - LJE - 041110 : For optim */
extern FIELD_IDX_T A_StandardPerf_BenchInitialDate         ; /* REF11462 - LJE - 051206 */
extern FIELD_IDX_T A_StandardPerf_BenchFinalDate           ; /* REF11462 - LJE - 051206 */
extern FIELD_IDX_T A_StandardPerf_PerfCalcResult_Ext       ; /* PMSTA-47578 - LJE - 220404 */
extern FIELD_IDX_T A_StandardPerf_HeadPtf_Ext              ; /* WEALTH-4557 - MergedDetail - KOR - 20240320 */
extern FIELD_IDX_T A_StandardPerf_RecStatusEn              ; /* WEALTH-3485 - MergedDetail - Lalby - 04122023 */


extern FIELD_IDX_T S_StandardPerf_Id                       ;
extern FIELD_IDX_T S_StandardPerf_PerfStorParamId          ;
extern FIELD_IDX_T S_StandardPerf_EntDictId                ;
extern FIELD_IDX_T S_StandardPerf_ObjId                    ;
extern FIELD_IDX_T S_StandardPerf_FreqEn                   ;
extern FIELD_IDX_T S_StandardPerf_CurrId                   ;
extern FIELD_IDX_T S_StandardPerf_PosDataId                ;
extern FIELD_IDX_T S_StandardPerf_GridId                   ;
extern FIELD_IDX_T S_StandardPerf_PerfAttribRtnEn          ;
extern FIELD_IDX_T S_StandardPerf_InitialDate              ;
extern FIELD_IDX_T S_StandardPerf_FinalDate                ;


extern FIELD_IDX_T A_StdPerfData_Id                        ;
extern FIELD_IDX_T A_StdPerfData_PspId                     ;
extern FIELD_IDX_T A_StdPerfData_InitialDate               ;
extern FIELD_IDX_T A_StdPerfData_FinalDate                 ;
extern FIELD_IDX_T A_StdPerfData_InitialMktVal             ;
extern FIELD_IDX_T A_StdPerfData_FinalMktVal               ;
extern FIELD_IDX_T A_StdPerfData_Fees                      ;
extern FIELD_IDX_T A_StdPerfData_Taxes                     ;
extern FIELD_IDX_T A_StdPerfData_Flows                     ;
extern FIELD_IDX_T A_StdPerfData_ProfitLoss                ;
extern FIELD_IDX_T A_StdPerfData_FlowMeanCap               ;
extern FIELD_IDX_T A_StdPerfData_MeanCapital               ;
extern FIELD_IDX_T A_StdPerfData_Rtn                       ;
/*extern FIELD_IDX_T A_StdPerfData_Adjust                  ; */ /* REF9125 - LJE - 030812 */ /*REF9743-BRO-040206*/
extern FIELD_IDX_T A_StdPerfData_RtnGross                  ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_StdPerfData_StdDeviation              ; /* REF9125 - LJE - 030812 */
extern FIELD_IDX_T A_StdPerfData_NbPtf                     ; /* REF9125 - LJE - 030812 */


/*<PMSTA06761-BRO-080703*/
extern FIELD_IDX_T A_StandInstruct_Id                      ;
extern FIELD_IDX_T A_StandInstruct_Cd                      ;
extern FIELD_IDX_T A_StandInstruct_Name                    ;
extern FIELD_IDX_T A_StandInstruct_Denom                   ;
extern FIELD_IDX_T A_StandInstruct_PtfId                   ;
extern FIELD_IDX_T A_StandInstruct_BegDate                 ;
extern FIELD_IDX_T A_StandInstruct_EndDate                 ;
extern FIELD_IDX_T A_StandInstruct_StatusEn                ;
extern FIELD_IDX_T A_StandInstruct_FreqUnitEn              ;
extern FIELD_IDX_T A_StandInstruct_Freq                    ;
extern FIELD_IDX_T A_StandInstruct_OpNatEn                 ;
extern FIELD_IDX_T A_StandInstruct_InstrId                 ;
extern FIELD_IDX_T A_StandInstruct_OpAmt                   ;
extern FIELD_IDX_T A_StandInstruct_OpAmtCurrId             ;
extern FIELD_IDX_T A_StandInstruct_Comment                 ;
extern FIELD_IDX_T A_StandInstruct_LastEvntGenDate         ;
extern FIELD_IDX_T A_StandInstruct_LastUserId              ;
extern FIELD_IDX_T A_StandInstruct_LastModifDate           ;
extern FIELD_IDX_T A_StandInstruct_PlanDefinitionId        ;
extern FIELD_IDX_T A_StandInstruct_Weight				   ;
extern FIELD_IDX_T A_StandInstruct_MinInvestAmt            ;  /* PMSTA-21265 - DDV - 151027 */
extern FIELD_IDX_T A_StandInstruct_FreqChoiceEn            ;
extern FIELD_IDX_T A_StandInstruct_DaySunFlg               ;
extern FIELD_IDX_T A_StandInstruct_DayMonFlg               ;
extern FIELD_IDX_T A_StandInstruct_DayTueFlg               ;
extern FIELD_IDX_T A_StandInstruct_DayWedFlg               ;
extern FIELD_IDX_T A_StandInstruct_DayThuFlg               ;
extern FIELD_IDX_T A_StandInstruct_DayFriFlg               ;
extern FIELD_IDX_T A_StandInstruct_DaySatFlg               ;
extern FIELD_IDX_T A_StandInstruct_ExecMonth               ;
extern FIELD_IDX_T A_StandInstruct_ExecDay                 ;
extern FIELD_IDX_T A_StandInstruct_ExecUnitEn              ;
extern FIELD_IDX_T A_StandInstruct_ExecUnitRankEn          ;
extern FIELD_IDX_T A_StandInstruct_OrderFeeEn              ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_StandInstruct_OrderFeePct             ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_StandInstruct_OrderFeeCurrId          ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_StandInstruct_OrderFeeAmt             ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_StandInstruct_CalendarId              ; /* PMSTA-28684-CHU-171023 */
extern FIELD_IDX_T A_StandInstruct_PaymentOption        ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T A_StandInstruct_CashPtfId                ;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_AccountId                ;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_TypeId                    ;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_SubTpId                  ;      /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_ExternalBankAcctOwnrName;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_CounterpartAccount      ;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_ExtrnlBnkAcctOwnrAddr1;      /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_ExternalBankBic           ;       /* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T A_StandInstruct_UpdGenDateFlg            ;
extern FIELD_IDX_T A_StandInstruct_FlowEvtNbr                  ;  /* PMSTA-40209 - LIK - 25082020 */



extern FIELD_IDX_T S_StandInstruct_Id                      ;
extern FIELD_IDX_T S_StandInstruct_Cd                      ;
extern FIELD_IDX_T S_StandInstruct_PtfId                   ;
extern FIELD_IDX_T S_StandInstruct_BegDate                 ;
extern FIELD_IDX_T S_StandInstruct_StatusEn                ;
extern FIELD_IDX_T S_StandInstruct_PtfCd                   ;
/*>PMSTA06761-BRO-080704*/


extern FIELD_IDX_T A_Stat_Array                            ;
extern FIELD_IDX_T A_Stat_RecNbr                           ;
extern FIELD_IDX_T A_Stat_Mean                             ;
extern FIELD_IDX_T A_Stat_StdDeviation                     ;
extern FIELD_IDX_T A_Stat_StdDeviationEntPop               ;
extern FIELD_IDX_T A_Stat_Variance                         ;
extern FIELD_IDX_T A_Stat_VarianceEntPop                   ;
extern FIELD_IDX_T A_Stat_Median                           ;
extern FIELD_IDX_T A_Stat_Centile                          ;
extern FIELD_IDX_T A_Stat_Min                              ;
extern FIELD_IDX_T A_Stat_Max                              ;


extern FIELD_IDX_T A_StratCompo_Id                         ;
extern FIELD_IDX_T A_StratCompo_StratHistId                ;
extern FIELD_IDX_T A_StratCompo_EntDictId                  ;
extern FIELD_IDX_T A_StratCompo_ObjId                      ;
extern FIELD_IDX_T A_StratCompo_LinkNatEn                  ;
extern FIELD_IDX_T A_StratCompo_Priority                   ;
extern FIELD_IDX_T A_StratCompo_Weight                     ;  /*REF10600-PRO-041103*/
extern FIELD_IDX_T A_StratCompo_MinBuyAmount               ;  /*REF10600-PRO-041103*/
extern FIELD_IDX_T A_StratCompo_MinBuyPercentage           ;  /*REF10600-PRO-041103*/
extern FIELD_IDX_T A_StratCompo_MinSellAmount              ;  /*REF10600-PRO-041103*/
extern FIELD_IDX_T A_StratCompo_MinSellPercentage          ;  /*REF10600-PRO-041103*/
extern FIELD_IDX_T A_StratCompo_WeightNature_e             ; /* REF11810-EFE-060608*/
extern FIELD_IDX_T A_StratCompo_CriticalnessEn			   ; /*PMSTA37310-SPB-171219*/
extern FIELD_IDX_T A_StratCompo_Margin					   ; /*PMSTA37310-SPB-171219*/
extern FIELD_IDX_T A_StratCompo_MktSegmentId               ; /*PMSTA-38428-Vishnu-01012020*/
extern FIELD_IDX_T A_StratCompo_NoTargetWeightEn           ; /*PMSTA-40203-sanand-16072020*/
extern FIELD_IDX_T A_StratCompo_LowerMarg				   ; /*PMSTA-40213-vmuthu-20082020*/
extern FIELD_IDX_T A_StratCompo_UpperMarg				   ; /*PMSTA-40213-vmuthu-20082020*/


extern FIELD_IDX_T S_StratCompo_Id                         ;
extern FIELD_IDX_T S_StratCompo_StratHistId                ;
extern FIELD_IDX_T S_StratCompo_EntDictId                  ;
extern FIELD_IDX_T S_StratCompo_ObjId                      ;
extern FIELD_IDX_T S_StratCompo_StratCode                  ;
extern FIELD_IDX_T S_StratCompo_EntDictName                ;
extern FIELD_IDX_T S_StratCompo_ObjName                    ;
extern FIELD_IDX_T S_StratCompo_LinkNatEn                  ;
extern FIELD_IDX_T S_StratCompo_Priority                   ;
extern FIELD_IDX_T S_StratCompo_WeightNature_e             ; /* REF11810-EFE-060608*/
extern FIELD_IDX_T S_StratCompo_Weight                     ; /*PMSTA7387-VST-090219*/


extern FIELD_IDX_T A_StratElt_Id                           ;
extern FIELD_IDX_T A_StratElt_Denom                        ;
extern FIELD_IDX_T A_StratElt_StratHistId                  ;
extern FIELD_IDX_T A_StratElt_MktSegtId                    ;
extern FIELD_IDX_T A_StratElt_InstrId                      ;
extern FIELD_IDX_T A_StratElt_BenchEntDictId               ;
extern FIELD_IDX_T A_StratElt_BenchObjId                   ;
extern FIELD_IDX_T A_StratElt_HedgeCurrId                  ;
extern FIELD_IDX_T A_StratElt_AnaBenchEntDictId            ;
extern FIELD_IDX_T A_StratElt_AnaBenchObjId                ;
extern FIELD_IDX_T A_StratElt_Rank                         ;
extern FIELD_IDX_T A_StratElt_NatEn                        ;
extern FIELD_IDX_T A_StratElt_LimitNatEn                   ;
extern FIELD_IDX_T A_StratElt_Value                        ;
extern FIELD_IDX_T A_StratElt_FluctMargin                  ;
extern FIELD_IDX_T A_StratElt_RecomNatEn                   ;
extern FIELD_IDX_T A_StratElt_Priority                     ;
extern FIELD_IDX_T A_StratElt_ConstrTemplate               ;
extern FIELD_IDX_T A_StratElt_CriticalnessEn               ; /* REF11231-CHU-050608 */
extern FIELD_IDX_T A_StratElt_Min                          ; /*PMSTA05345-BRO-080219*/
extern FIELD_IDX_T A_StratElt_Max                          ; /*PMSTA05345-BRO-080219*/
/* extern FIELD_IDX_T A_StratElt_MktSegt_A_StratElt_Ext    ; */ /* BSA - PMSTA00183 - 061212 */
extern FIELD_IDX_T A_StratElt_ObjTrackErr                  ; /*PMSTA05345-CHU-080428*/
extern FIELD_IDX_T A_StratElt_ObjTrackErrMarg              ; /*PMSTA05345-CHU-080428*/
extern FIELD_IDX_T A_StratElt_ActualTrackErr               ; /*PMSTA05345-CHU-080428*/
extern FIELD_IDX_T A_StratElt_EffTrackErr                  ; /*PMSTA05345-CHU-080428*/
extern FIELD_IDX_T A_StratElt_ObjTrackErrCheckEn           ; /*PMSTA05345-CHU-080428*/
extern FIELD_IDX_T A_StratElt_CompChronoNat                ; /*PMSTA05345-CHU-080430*/
extern FIELD_IDX_T A_StratElt_CompChronoCompNat            ; /*PMSTA05345-CHU-080430*/
extern FIELD_IDX_T A_StratElt_ExcludedFlg                  ; /*PMSTA-39969-sanand-05052020*/
extern FIELD_IDX_T A_StratElt_NoTargetWeightEn             ; /*PMSTA-40203-sanand-17062020*/
extern FIELD_IDX_T A_StratElt_LowerMarg                    ; /*PMSTA-40213-vmuthu-20082020*/
extern FIELD_IDX_T A_StratElt_UpperMarg                    ; /*PMSTA-40213-vmuthu-20082020*/
extern FIELD_IDX_T A_StratElt_MinThreshold                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_StratElt_MaxThreshold                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_StratElt_CashForecastM                ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_StratElt_MinCashForecastM             ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_StratElt_MaxCashForecastM             ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T A_StratElt_OverrideMktSeg_Id            ;
extern FIELD_IDX_T A_StratElt_StdMktSeg_Id                 ;
extern FIELD_IDX_T	A_StratElt_StratValSetFlg			   ; /* PMSTA-47449-CHANDRU-13052022 */

extern FIELD_IDX_T A_StratElt_A_ScriptDef_Ext              ;
extern FIELD_IDX_T A_StratElt_ExtStratElt_Id               ;
extern FIELD_IDX_T A_StratElt_OldValue                     ;
extern FIELD_IDX_T A_StratElt_PrimaryFlg                   ;
extern FIELD_IDX_T A_StratElt_TreatedFlg                   ;
extern FIELD_IDX_T A_StratElt_ContribValue                 ;
extern FIELD_IDX_T A_StratElt_WeightFactor                 ;
extern FIELD_IDX_T A_StratElt_VarNbr                       ;
extern FIELD_IDX_T A_StratElt_MinWeightConstr              ;
extern FIELD_IDX_T A_StratElt_MaxWeightConstr              ;
extern FIELD_IDX_T A_StratElt_SubStratFlg                  ;
extern FIELD_IDX_T A_StratElt_Return                       ;
extern FIELD_IDX_T A_StratElt_AbsoluteReturn               ;
extern FIELD_IDX_T A_StratElt_ReturnCurr                   ; /* REF9227 - LJE - 030918 */
extern FIELD_IDX_T A_StratElt_AbsoluteReturnCurr           ; /* REF9227 - LJE - 030919 */
extern FIELD_IDX_T A_StratElt_InstrCodifId                 ;
extern FIELD_IDX_T A_StratElt_DBValue                      ; /* REF8286 - CHU - 031002 */
extern FIELD_IDX_T A_StratElt_RefStratId                   ; /* REF10274 - RAK - 040510 */
extern FIELD_IDX_T A_StratElt_MktSegtName                  ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_InstrCd					   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_InstrNatEn				   ; /* PMSTA05319 - LJE - 080128 */
extern FIELD_IDX_T A_StratElt_InstrSubNatEn  		       ; /* PMSTA05319 - LJE - 080128 */
extern FIELD_IDX_T A_StratElt_BenchEntDictSqlName		   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_BenchObjCd				   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_HedgeCurrCd				   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_AnaBenchEntDictSqlName	   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_AnaBenchObjCd				   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratElt_DynValue				       ;	/* REF11457 - RAK - 050928 */
extern FIELD_IDX_T A_StratElt_PtfIdForMissingPM            ;	/* REF11559 - CHU - 051123 */
extern FIELD_IDX_T A_StratElt_ParStratEltId                ;	/* PMSTA07813-CHU-090211 */
extern FIELD_IDX_T A_StratElt_DepthLevel                   ;	/* PMSTA07813-CHU-090211 */
extern FIELD_IDX_T A_StratElt_ParMktSgtId                  ;	/* PMSTA07813-CHU-090211 */
extern FIELD_IDX_T A_StratElt_FixedCellFlg                 ;	/* PMSTA07813-CHU-090224 */
extern FIELD_IDX_T A_StratElt_BlendValue                   ;	/* PMSTA7387 -SRU-090226 */
extern FIELD_IDX_T A_StratElt_BlendWeight                  ;	/* PMSTA7387 -SRU-090226 */
extern FIELD_IDX_T A_StratElt_MarginNature                 ;	/* PMSTA7387 -SRU-090319 */
extern FIELD_IDX_T A_StratElt_EditBackupPtr                ;	/*   HFI-PMSTA-13470-120120  Manage OLD() in edit strategy objectives    */
extern FIELD_IDX_T A_StratElt_CoreSatOrigStratId           ;	/* PMSTA-18284 - CHU- 140619 */
extern FIELD_IDX_T A_StratElt_A_HoldConstrScript_Ext       ;    /* PMSTA-28970 - CHU - 171227 */
extern FIELD_IDX_T A_StratElt_A_TradConstrScript_Ext       ;    /* PMSTA-28970 - CHU - 171227 */
extern FIELD_IDX_T A_StratElt_QuasiCashEn                  ;	/* PMSTA-43175-Badhri-21122020 */
extern FIELD_IDX_T A_StratElt_InvestLimitAmount            ;    /* PMSTA-45637-CHANDRU-07072021 */
extern FIELD_IDX_T A_StratElt_MinAmount                    ;    /* PMSTA-45637-CHANDRU-07072021 */
extern FIELD_IDX_T A_StratElt_MaxAmount                    ;    /* PMSTA-45637-CHANDRU-07072021 */
extern FIELD_IDX_T A_StratElt_MinThresAmount               ;    /* PMSTA-45637-CHANDRU-07072021 */
extern FIELD_IDX_T A_StratElt_MaxThresAmount               ;    /* PMSTA-45637-CHANDRU-07072021 */
extern FIELD_IDX_T A_StratElt_A_InstrMktsegOverride_Ext    ;    /* PMSTA-46842-SENTHIL-10022022 */
extern FIELD_IDX_T A_StratElt_OriginTypeId	               ;    /* PMSTA-51507 - KKM - 222012 */
extern FIELD_IDX_T A_StratElt_CaseMgtTypeId                ;    /* WEALTH-9979 - KKM - 12072024 */

extern FIELD_IDX_T S_StratElt_Id                           ;
extern FIELD_IDX_T S_StratElt_Denom                        ;
extern FIELD_IDX_T S_StratElt_StratHistId                  ;
extern FIELD_IDX_T S_StratElt_Rank                         ;
extern FIELD_IDX_T S_StratElt_NatEn                        ;
extern FIELD_IDX_T S_StratElt_Value                        ;
extern FIELD_IDX_T S_StratElt_FluctMargin                  ;
extern FIELD_IDX_T S_StratElt_LimitNatEn                   ;
extern FIELD_IDX_T S_StratElt_RecomNatEn                   ;
extern FIELD_IDX_T S_StratElt_MktSegId                     ;
extern FIELD_IDX_T S_StratElt_InstrId                      ;
extern FIELD_IDX_T S_StratElt_CompChronoNat                ;
extern FIELD_IDX_T S_StratElt_InstrCd                      ;
extern FIELD_IDX_T S_StratElt_InstrName                    ;
extern FIELD_IDX_T S_StratElt_StratId                      ;
extern FIELD_IDX_T S_StratElt_NoMktSgtFlg                  ;
extern FIELD_IDX_T S_StratElt_LowerMarg  				   ; /*PMSTA-40213-vmuthu-20082020*/
extern FIELD_IDX_T S_StratElt_UpperMarg 				   ; /*PMSTA-40213-vmuthu-20082020*/




/* PMSTA08747-CHU-091112 */
extern FIELD_IDX_T A_VarStratElt_Id                          ;
extern FIELD_IDX_T A_VarStratElt_StratId                     ;
extern FIELD_IDX_T A_VarStratElt_StratEltId                  ;
extern FIELD_IDX_T A_VarStratElt_PtfId                       ;
extern FIELD_IDX_T A_VarStratElt_MktSgtId                    ;
extern FIELD_IDX_T A_VarStratElt_MktSgtName                  ;
extern FIELD_IDX_T A_VarStratElt_InstrId                     ;
extern FIELD_IDX_T A_VarStratElt_InstrCd                     ;
extern FIELD_IDX_T A_VarStratElt_ParentId                    ;
extern FIELD_IDX_T A_VarStratElt_ParMktSgtId                 ;
extern FIELD_IDX_T A_VarStratElt_ParMktSgtName               ;
extern FIELD_IDX_T A_VarStratElt_ActualWeight                ;
extern FIELD_IDX_T A_VarStratElt_AbsoluteWeight              ;
extern FIELD_IDX_T A_VarStratElt_ObjectiveWeight             ;
extern FIELD_IDX_T A_VarStratElt_DerivedWeight               ;
extern FIELD_IDX_T A_VarStratElt_ExpectedWeight              ;
extern FIELD_IDX_T A_VarStratElt_TestResultOkFlg             ;
extern FIELD_IDX_T A_VarStratElt_LockedQty                   ;
extern FIELD_IDX_T A_VarStratElt_VarNb                       ;
extern FIELD_IDX_T A_VarStratElt_OldVarNb                    ;
extern FIELD_IDX_T A_VarStratElt_MinWeight                   ;
extern FIELD_IDX_T A_VarStratElt_MaxWeight                   ;
extern FIELD_IDX_T A_VarStratElt_MinOptWeight                ;
extern FIELD_IDX_T A_VarStratElt_MaxOptWeight                ;
extern FIELD_IDX_T A_VarStratElt_MinChkWeight                ;
extern FIELD_IDX_T A_VarStratElt_MaxChkWeight                ;
extern FIELD_IDX_T A_VarStratElt_DataLevel                   ;
extern FIELD_IDX_T A_VarStratElt_CostFlag                    ;
extern FIELD_IDX_T A_VarStratElt_Par_A_VarStratElt_Ext       ;
extern FIELD_IDX_T A_VarStratElt_Child_A_VarStratElt_Ext     ;
extern FIELD_IDX_T A_VarStratElt_FixedCellFlg                ;
extern FIELD_IDX_T A_VarStratElt_ConstrObjectiveWeight       ;
extern FIELD_IDX_T A_VarStratElt_Priority                    ;
extern FIELD_IDX_T A_VarStratElt_OldMktSgtName               ;
extern FIELD_IDX_T A_VarStratElt_StratNatEn					 ; /* PMSTA-39045-BADHRI-140220 */
extern FIELD_IDX_T A_VarStratElt_SubModelFlg				 ; /* PMSTA-39045-BADHRI-12042020 */
extern FIELD_IDX_T A_VarStratElt_ParSubModelStratId			 ; /* PMSTA-39045-BADHRI-12042020 */
extern FIELD_IDX_T A_VarStratElt_NoTargetWeightEn            ; /* PMSTA-40203-sanand-20072020 */
extern FIELD_IDX_T A_VarStratElt_AppliedConstrNatEn          ; /* PMSTA-42156-Badhri-21122020 */


extern FIELD_IDX_T A_StratLnk_Id                           ;
extern FIELD_IDX_T A_StratLnk_StratId                      ;
extern FIELD_IDX_T A_StratLnk_EntDictId                    ;
extern FIELD_IDX_T A_StratLnk_ObjId                        ;
extern FIELD_IDX_T A_StratLnk_DataSecuProfId               ;
extern FIELD_IDX_T A_StratLnk_LnkNatEn                     ;
extern FIELD_IDX_T A_StratLnk_BegDate                      ;
extern FIELD_IDX_T A_StratLnk_EndDate                      ;
extern FIELD_IDX_T A_StratLnk_Priority                     ;
extern FIELD_IDX_T A_StratLnk_DataSecuProf2Id              ; /*PMSTA-14309-EFE-120611*/
/* end physical */
extern FIELD_IDX_T A_StratLnk_FromEntDictId                ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T A_StratLnk_FromObjId                    ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T A_StratLnk_ToEntDictId                  ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T A_StratLnk_ToObjId                      ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T A_StratLnk_ParStratLnkId                ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T A_StratLnk_Rank                         ; /* REF9187 - LJE - 030618 */

extern FIELD_IDX_T S_StratLnk_Id                           ;
extern FIELD_IDX_T S_StratLnk_StratId                      ;
extern FIELD_IDX_T S_StratLnk_LnkObjDictId                 ;
extern FIELD_IDX_T S_StratLnk_ObjId                        ;
extern FIELD_IDX_T S_StratLnk_LnkNatEn                     ;
extern FIELD_IDX_T S_StratLnk_BegDate                      ;
extern FIELD_IDX_T S_StratLnk_EndDate                      ;
extern FIELD_IDX_T S_StratLnk_Priority                     ;
extern FIELD_IDX_T S_StratLnk_DataSecuProfId               ; /* PMSTA08114-CHU-090508 */
extern FIELD_IDX_T S_StratLnk_FromEntDictId                ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_FromObjId                    ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_ToEntDictId                  ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_ToObjId                      ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_ParStratLnkId                ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_Rank                         ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_StratCd                      ;
extern FIELD_IDX_T S_StratLnk_StratNatEn                   ;
extern FIELD_IDX_T S_StratLnk_ObjCd                        ;
extern FIELD_IDX_T S_StratLnk_DirectFlg                    ;
extern FIELD_IDX_T S_StratLnk_EnumFlg                      ;
extern FIELD_IDX_T S_StratLnk_PtfId                        ;
extern FIELD_IDX_T S_StratLnk_PtfCd                        ;
extern FIELD_IDX_T S_StratLnk_ListId                       ;
extern FIELD_IDX_T S_StratLnk_ListCd                       ;
extern FIELD_IDX_T S_StratLnk_ParStratId                   ;
extern FIELD_IDX_T S_StratLnk_DimGridDictId                ;
extern FIELD_IDX_T S_StratLnk_GridObjId                    ;
extern FIELD_IDX_T S_StratLnk_ParGridId                    ;
extern FIELD_IDX_T S_StratLnk_MktSegId                     ;
extern FIELD_IDX_T S_StratLnk_FromEntCd                    ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_FromObjCd                    ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_ToEntCd                      ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_ToObjCd                   ; /* REF9187 - LJE - 030618 */
extern FIELD_IDX_T S_StratLnk_CriticalnessEn               ; /* PMSTA07121-CHU-081106 */
extern FIELD_IDX_T S_StratLnk_HeadPtfId                    ;  /*PMSTA - 41153 Vishnu 05082020*/
extern FIELD_IDX_T S_StratLnk_MandatoryFlg                 ;


extern FIELD_IDX_T A_StratHist_Id                          ;
extern FIELD_IDX_T A_StratHist_Denom                       ;
extern FIELD_IDX_T A_StratHist_StratId                     ;
extern FIELD_IDX_T A_StratHist_BegDate                     ;
extern FIELD_IDX_T A_StratHist_EndDate                     ;
extern FIELD_IDX_T A_StratHist_ApplicDate                  ;
extern FIELD_IDX_T A_StratHist_StratNatEn                  ;
extern FIELD_IDX_T A_StratHist_A_StratElt_Ext              ;
extern FIELD_IDX_T A_StratHist_RefStratId                  ;	/* REF10274 - RAK - 040510 */
extern FIELD_IDX_T A_StratHist_StratCd					   ;	/* REF11349 - RAK - 050804 */
extern FIELD_IDX_T A_StratHist_A_StratCompo_Ext            ;    /* PMSTA08736 - LJE - 100202 */
extern FIELD_IDX_T A_StratHist_ParentStratId               ; /* PMSTA-10748 - LJE - 110209 */
extern FIELD_IDX_T A_StratHist_ParentWeight                ; /* PMSTA-10748 - LJE - 110209 */


extern FIELD_IDX_T S_StratHist_Id                          ;
extern FIELD_IDX_T S_StratHist_Denom                       ;
extern FIELD_IDX_T S_StratHist_StratId                     ;
extern FIELD_IDX_T S_StratHist_BegDate                     ;
extern FIELD_IDX_T S_StratHist_EndDate                     ;
extern FIELD_IDX_T S_StratHist_StratCd                     ;
extern FIELD_IDX_T S_StratHist_StratName                   ;
extern FIELD_IDX_T S_StratHist_StratNatEn                  ;
extern FIELD_IDX_T S_StratHist_DimGridDictId               ;
extern FIELD_IDX_T S_StratHist_GridObjId                   ;
extern FIELD_IDX_T S_StratHist_CurrCd                      ;
extern FIELD_IDX_T S_StratHist_MktSegGridCd                ;
extern FIELD_IDX_T S_StratHist_MktSegAbsListCd             ;
extern FIELD_IDX_T S_StratHist_MktSegOrdListCd             ;
extern FIELD_IDX_T S_StratHist_BenchTpName                 ;
extern FIELD_IDX_T S_StratHist_BenchObjCd                  ;


extern FIELD_IDX_T A_StratEltDetail_Id                     ;

/* PMSTA08737 - LJE - 091105 */
extern FIELD_IDX_T A_StratSynth_Id                       ;
extern FIELD_IDX_T A_StratSynth_StratId                  ;
extern FIELD_IDX_T A_StratSynth_StratHistId              ;
extern FIELD_IDX_T A_StratSynth_RefStratId               ;
extern FIELD_IDX_T A_StratSynth_GridId                   ;
extern FIELD_IDX_T A_StratSynth_MktSegtId                ;
extern FIELD_IDX_T A_StratSynth_BeginDate                ;
extern FIELD_IDX_T A_StratSynth_EndDate                  ;
extern FIELD_IDX_T A_StratSynth_InstrId                  ;
extern FIELD_IDX_T A_StratSynth_BenchEntDictId           ;
extern FIELD_IDX_T A_StratSynth_BenchObjId               ;
extern FIELD_IDX_T A_StratSynth_Weight                   ;
extern FIELD_IDX_T A_StratSynth_Return                   ;
extern FIELD_IDX_T A_StratSynth_ReturnCurr               ;
extern FIELD_IDX_T A_StratSynth_Dura                     ;
extern FIELD_IDX_T A_StratSynth_OriginalWeight           ;
extern FIELD_IDX_T A_StratSynth_RebalDate                ;
extern FIELD_IDX_T A_StratSynth_RebalReturn              ;
extern FIELD_IDX_T A_StratSynth_SubPeriodMask            ;
extern FIELD_IDX_T A_StratSynth_ParentId                 ;
extern FIELD_IDX_T A_StratSynth_GlobalId                 ;
extern FIELD_IDX_T A_StratSynth_RefBeginDate             ;
extern FIELD_IDX_T A_StratSynth_RefEndDate               ;
extern FIELD_IDX_T A_StratSynth_Parent_Ext               ;
extern FIELD_IDX_T A_StratSynth_Children_Ext             ;
extern FIELD_IDX_T A_StratSynth_Global_Ext               ;


extern FIELD_IDX_T A_TabCnt_Id                             ;
extern FIELD_IDX_T A_TabCnt_Cd                             ;
extern FIELD_IDX_T A_TabCnt_Denom                          ;
extern FIELD_IDX_T A_TabCnt_TitleMsgId                     ;
extern FIELD_IDX_T A_TabCnt_CntHeadMsgId                   ;
extern FIELD_IDX_T A_TabCnt_PageHeadMsgId                  ;
extern FIELD_IDX_T A_TabCnt_HeadFrameEn                    ;
extern FIELD_IDX_T A_TabCnt_JustifEn                       ;
extern FIELD_IDX_T A_TabCnt_FontEn                         ;
extern FIELD_IDX_T A_TabCnt_FontSz                         ;
extern FIELD_IDX_T A_TabCnt_Thick                          ;
extern FIELD_IDX_T A_TabCnt_TitleJustifEn                  ;
extern FIELD_IDX_T A_TabCnt_TitleFontEn                    ;
extern FIELD_IDX_T A_TabCnt_TitleFontSz                    ;
extern FIELD_IDX_T A_TabCnt_PageColWidth                   ;
extern FIELD_IDX_T A_TabCnt_PageDispFmt                    ;
extern FIELD_IDX_T A_TabCnt_CntColWidth                    ;
extern FIELD_IDX_T A_TabCnt_CntPos                         ;
extern FIELD_IDX_T A_TabCnt_Indent                         ;


extern FIELD_IDX_T S_TabCnt_Id                             ;
extern FIELD_IDX_T S_TabCnt_Cd                             ;
extern FIELD_IDX_T S_TabCnt_Denom                          ;


extern FIELD_IDX_T A_TabModifStat_DictId                   ;
extern FIELD_IDX_T A_TabModifStat_LastModifDate            ;
extern FIELD_IDX_T A_TabModifStat_LastModifDateMs          ;  /* PMSTA10087 - DDV - 100729 - Returns milliseconds from table_modif_stat */


extern FIELD_IDX_T S_TabModifStat_DictId                   ;


extern FIELD_IDX_T A_TemplateElt_Id                        ;
extern FIELD_IDX_T A_TemplateElt_ConstrTemplateId          ;
extern FIELD_IDX_T A_TemplateElt_Cd                        ;
extern FIELD_IDX_T A_TemplateElt_ParamNatEn                ;
extern FIELD_IDX_T A_TemplateElt_SortRank                  ;
extern FIELD_IDX_T A_TemplateElt_Name                      ;
extern FIELD_IDX_T A_TemplateElt_Denom                     ;
extern FIELD_IDX_T A_TemplateElt_DisplayFormat             ;
extern FIELD_IDX_T A_TemplateElt_EntityDictId              ;
extern FIELD_IDX_T A_TemplateElt_AttributeDictId           ;
extern FIELD_IDX_T A_TemplateElt_TypeId                    ; /*REF9790-BRO-040206*/
extern FIELD_IDX_T A_TemplateElt_MandatoryFlg              ; /*REF9790-BRO-040206*/


extern FIELD_IDX_T S_TemplateElt_Id                        ;
extern FIELD_IDX_T S_TemplateElt_ConstrTemplateId          ;
extern FIELD_IDX_T S_TemplateElt_Cd                        ;
extern FIELD_IDX_T S_TemplateElt_ParamNatEn                ;


extern FIELD_IDX_T Freq_ThirdChrono_ThirdId                ;
extern FIELD_IDX_T Freq_ThirdChrono_NatEn                  ;
extern FIELD_IDX_T Freq_ThirdChrono_ValidDate              ;
extern FIELD_IDX_T Freq_ThirdChrono_CurrId                 ;
extern FIELD_IDX_T Freq_ThirdChrono_Val                    ;
extern FIELD_IDX_T Freq_ThirdChrono_RequestDate            ;


extern FIELD_IDX_T A_ThirdFreq_FreqDate                    ;
extern FIELD_IDX_T A_ThirdFreq_ThirdId                     ;
extern FIELD_IDX_T A_ThirdFreq_A_Third_Ext                 ;


extern FIELD_IDX_T A_TradingCurrency_Id                    ;
extern FIELD_IDX_T A_TradingCurrency_InstrumentId          ;
extern FIELD_IDX_T A_TradingCurrency_CurrencyId            ;
extern FIELD_IDX_T A_TradingCurrency_MainCurrencyFlg       ;


extern FIELD_IDX_T S_TradingCurrency_Id                    ;
extern FIELD_IDX_T S_TradingCurrency_InstrumentId          ;
extern FIELD_IDX_T S_TradingCurrency_CurrencyId            ;
extern FIELD_IDX_T S_TradingCurrency_InstrumentCd          ;
extern FIELD_IDX_T S_TradingCurrency_CurrencyCd            ;


extern FIELD_IDX_T A_TradingPlace_Id                       ;
extern FIELD_IDX_T A_TradingPlace_InstrumentId             ;
extern FIELD_IDX_T A_TradingPlace_MarketPlaceId            ;
extern FIELD_IDX_T A_TradingPlace_CurrencyId               ;
extern FIELD_IDX_T A_TradingPlace_MainPlaceFlg             ;


extern FIELD_IDX_T S_TradingPlace_Id                       ;
extern FIELD_IDX_T S_TradingPlace_InstrumentId             ;
extern FIELD_IDX_T S_TradingPlace_MarketPlaceId            ;
extern FIELD_IDX_T S_TradingPlace_CurrencyId               ;
extern FIELD_IDX_T S_TradingPlace_CurrencyCd               ;
extern FIELD_IDX_T S_TradingPlace_MarketPlaceCd            ;


extern FIELD_IDX_T A_RiskRule_Id                           ;
extern FIELD_IDX_T A_RiskRule_Cd                           ;
extern FIELD_IDX_T A_RiskRule_Name                         ;
extern FIELD_IDX_T A_RiskRule_Denom                        ;

extern FIELD_IDX_T S_RiskRule_Id                           ;
extern FIELD_IDX_T S_RiskRule_Cd                           ;
extern FIELD_IDX_T S_RiskRule_Name                         ;

extern FIELD_IDX_T A_RiskRuleCompo_Id                      ;
extern FIELD_IDX_T A_RiskRuleCompo_RiskRuleId              ;
extern FIELD_IDX_T A_RiskRuleCompo_Rank                    ;
extern FIELD_IDX_T A_RiskRuleCompo_RuleTypeId              ;
extern FIELD_IDX_T A_RiskRuleCompo_Denom                   ;
extern FIELD_IDX_T A_RiskRuleCompo_ConfidenceLevel         ;
extern FIELD_IDX_T A_RiskRuleCompo_TimeHorizon             ;
extern FIELD_IDX_T A_RiskRuleCompo_TimeHorizonUnitEn       ;
extern FIELD_IDX_T A_RiskRuleCompo_ExtServiceId            ; /* PMSTA-30991 - CHU - 180418 */
extern FIELD_IDX_T A_RiskRuleCompo_StressTestScenarioTpId  ; /* PMSTA-34473 - CHU - 190226 */


extern FIELD_IDX_T S_RiskRuleCompo_Id                      ;
extern FIELD_IDX_T S_RiskRuleCompo_RiskRuleId              ;
extern FIELD_IDX_T S_RiskRuleCompo_RiskRuleCd              ;
extern FIELD_IDX_T S_RiskRuleCompo_RuleTypeId              ;
extern FIELD_IDX_T S_RiskRuleCompo_RuleTypeCd              ;
extern FIELD_IDX_T S_RiskRuleCompo_Rank                    ;
extern FIELD_IDX_T S_RiskRuleCompo_StressTestScenarionTpId ; /* PMSTA-34473 - CHU - 190226 */
extern FIELD_IDX_T S_RiskRuleCompo_StressTestScenarionTpCd ; /* PMSTA-34473 - CHU - 190226 */

extern FIELD_IDX_T A_WarningMsg_NatureEn                   ;
extern FIELD_IDX_T A_WarningMsg_MsgText                    ;
extern FIELD_IDX_T A_WarningMsg_OrderCd                    ;
extern FIELD_IDX_T A_WarningMsg_PtfId                      ;
extern FIELD_IDX_T A_WarningMsg_InstrId                    ;
extern FIELD_IDX_T A_WarningMsg_OperationDate              ;
extern FIELD_IDX_T A_WarningMsg_ExtOpExt                   ;


extern FIELD_IDX_T ExtPos_Id                               ;
extern FIELD_IDX_T ExtPos_PosObjId                         ;
extern FIELD_IDX_T ExtPos_PtfId                            ;
extern FIELD_IDX_T ExtPos_PtfPosSetId                      ;
extern FIELD_IDX_T ExtPos_InstrId                          ;
extern FIELD_IDX_T ExtPos_DepoId                           ;
extern FIELD_IDX_T ExtPos_BalPosTpId                       ;
extern FIELD_IDX_T ExtPos_PosCurrId                        ;
extern FIELD_IDX_T ExtPos_InstrCurrId                      ;
extern FIELD_IDX_T ExtPos_RefCurrId                        ;
extern FIELD_IDX_T ExtPos_CntPtyThirdId                    ;
extern FIELD_IDX_T ExtPos_OpenOpId                         ;
extern FIELD_IDX_T ExtPos_CloseOpId                        ;
extern FIELD_IDX_T ExtPos_TermTpId                         ;
extern FIELD_IDX_T ExtPos_LockTpId                         ;
extern FIELD_IDX_T ExtPos_MainExtPosId                     ;
extern FIELD_IDX_T ExtPos_AcctExtPosId                     ;
extern FIELD_IDX_T ExtPos_AdjustExtPosId                   ;
extern FIELD_IDX_T ExtPos_PosValId                         ;
extern FIELD_IDX_T ExtPos_RiskParInstrId                   ;
extern FIELD_IDX_T ExtPos_RiskOriginExtPosId               ;
extern FIELD_IDX_T ExtPos_ValRuleEltId                     ;
extern FIELD_IDX_T ExtPos_NatEn                            ;
extern FIELD_IDX_T ExtPos_ForecastFlg                      ;
extern FIELD_IDX_T ExtPos_RiskNatEn                        ;
extern FIELD_IDX_T ExtPos_AcctFlg                          ;
extern FIELD_IDX_T ExtPos_Proba                            ;
extern FIELD_IDX_T ExtPos_OpenOpNatEn                      ;
extern FIELD_IDX_T ExtPos_AdjustNatEn                      ;
extern FIELD_IDX_T ExtPos_OpenOpCd                         ;
extern FIELD_IDX_T ExtPos_CloseOpCd                        ;
extern FIELD_IDX_T ExtPos_SrcCd                            ;
extern FIELD_IDX_T ExtPos_RefOpCd                          ;
extern FIELD_IDX_T ExtPos_RefNatEn                         ;
extern FIELD_IDX_T ExtPos_ExecOpCd                         ;
extern FIELD_IDX_T ExtPos_ExecNatEn                        ;
extern FIELD_IDX_T ExtPos_ExecOpStatEn                     ;
extern FIELD_IDX_T ExtPos_RevOpCd                          ;
extern FIELD_IDX_T ExtPos_RevNatEn                         ;
extern FIELD_IDX_T ExtPos_LockOpCd                         ;
extern FIELD_IDX_T ExtPos_LockNatEn                        ;
extern FIELD_IDX_T ExtPos_EvtCd                            ;
extern FIELD_IDX_T ExtPos_EvtNbr                           ;
extern FIELD_IDX_T ExtPos_StatEn                           ;
extern FIELD_IDX_T ExtPos_PrimaryEn                        ;
extern FIELD_IDX_T ExtPos_MainFlg                          ;
extern FIELD_IDX_T ExtPos_PosNatEn                         ;
extern FIELD_IDX_T ExtPos_SubPosNatEn                      ;
extern FIELD_IDX_T ExtPos_SubPosNat2En                     ;
extern FIELD_IDX_T ExtPos_SubPosNat3En                     ;
extern FIELD_IDX_T ExtPos_ExCouponFlg                      ;
extern FIELD_IDX_T ExtPos_Fus                              ;
extern FIELD_IDX_T ExtPos_FusRuleEn                        ;
extern FIELD_IDX_T ExtPos_ExtPosDate                       ;
extern FIELD_IDX_T ExtPos_BegDate                          ;
extern FIELD_IDX_T ExtPos_EndDate                          ;
extern FIELD_IDX_T ExtPos_OpDate                           ;
extern FIELD_IDX_T ExtPos_AcctDate                         ;
extern FIELD_IDX_T ExtPos_ValDate                          ;
extern FIELD_IDX_T ExtPos_LockLimitDate                    ;
extern FIELD_IDX_T ExtPos_ExpirDate                        ;
extern FIELD_IDX_T ExtPos_AccrAmt                          ;
extern FIELD_IDX_T ExtPos_OrderLimitDate                   ;
extern FIELD_IDX_T ExtPos_Remark                           ;
extern FIELD_IDX_T ExtPos_PosExchRate                      ;
extern FIELD_IDX_T ExtPos_InstrExchRate                    ;
extern FIELD_IDX_T ExtPos_SysExchRate                      ;
extern FIELD_IDX_T ExtPos_BookPosExchRate                  ;
extern FIELD_IDX_T ExtPos_BookInstrExchRate                ;
extern FIELD_IDX_T ExtPos_BookSysExchRate                  ;
extern FIELD_IDX_T ExtPos_Qty                              ;
extern FIELD_IDX_T ExtPos_Price                            ;
extern FIELD_IDX_T ExtPos_SpotPrice                        ;
extern FIELD_IDX_T ExtPos_BookPrice                        ;
extern FIELD_IDX_T ExtPos_PriceCalcRuleEn                  ;
extern FIELD_IDX_T ExtPos_Quote                            ;
extern FIELD_IDX_T ExtPos_SpotQuote                        ;
extern FIELD_IDX_T ExtPos_BookQuote                        ;
extern FIELD_IDX_T ExtPos_Rate                             ;
extern FIELD_IDX_T ExtPos_SupplAmt                         ;
extern FIELD_IDX_T ExtPos_PosGrossAmt                      ;
extern FIELD_IDX_T ExtPos_PosNetAmt                        ;
extern FIELD_IDX_T ExtPos_InstrGrossAmt                    ;
extern FIELD_IDX_T ExtPos_InstrNetAmt                      ;
extern FIELD_IDX_T ExtPos_RefGrossAmt                      ;
extern FIELD_IDX_T ExtPos_RefNetAmt                        ;
extern FIELD_IDX_T ExtPos_SysGrossAmt                      ;
extern FIELD_IDX_T ExtPos_SysNetAmt                        ;
extern FIELD_IDX_T ExtPos_BookPosNetAmt                    ;
extern FIELD_IDX_T ExtPos_BookInstrNetAmt                  ;
extern FIELD_IDX_T ExtPos_BookRefNetAmt                    ;
extern FIELD_IDX_T ExtPos_BookSysNetAmt                    ;
extern FIELD_IDX_T ExtPos_Bp1PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp2PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp3PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp4PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp5PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp6PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp7PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp8PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp9PosAmt                        ;
extern FIELD_IDX_T ExtPos_Bp10PosAmt                       ;
extern FIELD_IDX_T ExtPos_FundSplitNatEn                   ;
extern FIELD_IDX_T ExtPos_AccrInterExtPosId                ;
extern FIELD_IDX_T ExtPos_CntPtyExtPosId                   ;
extern FIELD_IDX_T ExtPos_PosDateRuleEn                    ;
extern FIELD_IDX_T ExtPos_InstrExtPosId                    ;
extern FIELD_IDX_T ExtPos_AdjustSecExtPosId                ;
extern FIELD_IDX_T ExtPos_Acct2ExtPosId                    ;
extern FIELD_IDX_T ExtPos_Acct3ExtPosId                    ;
extern FIELD_IDX_T ExtPos_BVAdjProfitExtPosId              ;
extern FIELD_IDX_T ExtPos_BVAdjLossExtPosId                ;
extern FIELD_IDX_T ExtPos_LockingExtPosId                  ;
extern FIELD_IDX_T ExtPos_ChildPtfId                       ;
extern FIELD_IDX_T ExtPos_InitExtPosId                     ;
extern FIELD_IDX_T ExtPos_FlowId                           ;
extern FIELD_IDX_T ExtPos_ExecutionId                      ;
extern FIELD_IDX_T ExtPos_GlobalExecutionFeeId             ;
extern FIELD_IDX_T ExtPos_UnpaidPrct                       ;    /* PMSTA-16533 - 221113 - PMO */
extern FIELD_IDX_T ExtPos_PosNetIncreaseAmt                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosGrossIncreaseAmt              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosNetDecreaseAmt                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosGrossDecreaseAmt              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosNetIncreaseYearAmt            ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosGrossIncreaseYearAmt          ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosNetDecreaseYearAmt            ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PosGrossDecreaseYearAmt          ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfNetIncreaseAmt                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfGrossIncreaseAmt               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfNetDecreaseAmt                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfGrossDecreaseAmt               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfNetIncreaseYearAmt             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfGrossIncreaseYearAmt           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfNetDecreaseYearAmt             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_PfGrossDecreaseYearAmt           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_AcquisitionDate                  ; /* PMSTA-28286 - JBC - 207699 */
extern FIELD_IDX_T ExtPos_AcquisitionOpenOpId              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_TaxLotInitialId                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_BpPosExchangeRate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_BpFiExchangeRate                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_BpSysExchangeRate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_CorporateActionNatEn             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_TaxLotSourceCd                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtPos_StandInstructId                  ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T ExtPos_CashPortfolioId                  ;    /* DLA - PMSTA06921 - 081022 */
extern FIELD_IDX_T ExtPos_OpPortfolioId                    ;    /* DLA - PMSTA06921 - 081022 */
extern FIELD_IDX_T ExtPos_FusStateEn                       ;
extern FIELD_IDX_T ExtPos_AdjTinyInt                       ;
extern FIELD_IDX_T ExtPos_ValueOrBegDate                   ;
extern FIELD_IDX_T ExtPos_InstrNat                         ;
extern FIELD_IDX_T ExtPos_DbStatus                         ;
extern FIELD_IDX_T ExtPos_A_Ptf_Ext                        ;
extern FIELD_IDX_T ExtPos_A_Instr_Ext                      ;
extern FIELD_IDX_T ExtPos_Open_A_Op_Ext                    ;
extern FIELD_IDX_T ExtPos_Close_A_Op_Ext                   ;
extern FIELD_IDX_T ExtPos_Main_ExtPos_Ext                  ;
extern FIELD_IDX_T ExtPos_Acct_ExtPos_Ext                  ;
extern FIELD_IDX_T ExtPos_Adjust_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_BalPos_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_PosVal_Ext                       ;
extern FIELD_IDX_T ExtPos_RefOp_ExtPos_Ext                 ;
extern FIELD_IDX_T ExtPos_ExecOp_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_RevOp_ExtPos_Ext                 ;
extern FIELD_IDX_T ExtPos_LockOp_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_RiskPar_A_Instr_Ext              ;
extern FIELD_IDX_T ExtPos_RiskOrigin_ExtPos_Ext            ;
extern FIELD_IDX_T ExtPos_AccrInter_ExtPos_Ext             ;
extern FIELD_IDX_T ExtPos_CntPty_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_Instr_ExtPos_Ext                 ;
extern FIELD_IDX_T ExtPos_AdjustSec_ExtPos_Ext             ;
extern FIELD_IDX_T ExtPos_A_AccPlanElt_Ext                 ;
extern FIELD_IDX_T ExtPos_Acct2_ExtPos_Ext                 ;
extern FIELD_IDX_T ExtPos_Acct3_ExtPos_Ext                 ;
extern FIELD_IDX_T ExtPos_Attach_ExtPos_Ext                ;
extern FIELD_IDX_T ExtPos_BVAdjProfit_ExtPos_Ext           ;
extern FIELD_IDX_T ExtPos_BVAdjLoss_ExtPos_Ext             ;
extern FIELD_IDX_T ExtPos_PtfPosSet_Ext                    ;
extern FIELD_IDX_T ExtPos_Locking_ExtPos_Ext               ;
extern FIELD_IDX_T ExtPos_ToInstr_ExtPos_Ext               ;
extern FIELD_IDX_T ExtPos_ToBalPos_ExtPos_Ext              ;
extern FIELD_IDX_T ExtPos_LendingValRuleEltId              ;
extern FIELD_IDX_T ExtPos_ToPtfId                          ;
extern FIELD_IDX_T ExtPos_ChildPtf_Ext                     ;
extern FIELD_IDX_T ExtPos_ExecFlg                          ;
extern FIELD_IDX_T ExtPos_ClosedbyReversedFlg              ;
extern FIELD_IDX_T ExtPos_ExcludeFlg                       ;
extern FIELD_IDX_T ExtPos_DBPrimaryEn                      ;
extern FIELD_IDX_T ExtPos_DataSource                       ;
extern FIELD_IDX_T ExtPos_SortDate                         ;
extern FIELD_IDX_T ExtPos_LogicalId                        ; /*REF9751-EFE-050125 used for fusion debug */
extern FIELD_IDX_T ExtPos_TracedPos                        ; /* BSA - REF11817 - 060517 */
extern FIELD_IDX_T ExtPos_ExtOrderSavedPosition            ; /* BSA - PMSTA-1019 - 061130 */
extern FIELD_IDX_T ExtPos_HistQuote                        ; /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T ExtPos_Acct1IdFus                       ; /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T ExtPos_Acct2IdFus                       ; /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T ExtPos_Acct3IdFus                       ; /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T ExtPos_HistQuoteQty                     ; /* PMSTA-5207 - 050208 - PMO */
extern FIELD_IDX_T ExtPos_HistQuoteAver                    ; /* PMSTA-5207 - 050208 - PMO */
extern FIELD_IDX_T ExtPos_HistQuoteTransQty                ; /* PMSTA-5207 - 050208 - PMO */
extern FIELD_IDX_T ExtPos_HistQuoteTransAver               ; /* PMSTA-5207 - 050208 - PMO */
extern FIELD_IDX_T ExtPos_SortCd                           ; /* PMSTA-8062 - 190509 - PMO */
extern FIELD_IDX_T ExtPos_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtPos_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtPos_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtPos_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtPos_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtPos_CommonRef                        ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T ExtPos_DetailFlg                        ;
extern FIELD_IDX_T ExtPos_TaxLot_Ext                       ;
extern FIELD_IDX_T ExtPos_PaymentOption                    ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T ExtPos_AccrIntChronoFlg                 ; /*PMSTA-27729 - Smitha - 180115*/
extern FIELD_IDX_T ExtPos_LockQuantity                     ; /*PMSTA-39162 -NRAO- 03052020*/
extern FIELD_IDX_T ExtPos_PaymentDate                      ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtPos_PaymentStatusEn                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtPos_SettlementDate                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtPos_SettleStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtPos_LinkedInstrId                    ; /* PMSTA- 42330 - CHANDRU - 22102020 */

extern FIELD_IDX_T ExtPos_IncEvtCurrId                     ;
extern FIELD_IDX_T ExtPos_BusinessAcquisitionDate          ; /* PMSTA-49603 - AIS - 220626 */
extern FIELD_IDX_T ExtPos_IncEvtBegDate                    ;
extern FIELD_IDX_T ExtPos_IncEvtEndDate                    ;
extern FIELD_IDX_T ExtPos_FlowInfoEn                       ; /* PMSTA-47578 - DDV - 220117 */
extern FIELD_IDX_T ExtPos_TimingRuleEn                     ; /* PMSTA-47578 - DDV - 220117 */
extern FIELD_IDX_T ExtPos_OpenOpTpId                       ; /* PMSTA-47582 - JBC - 220406 */
extern FIELD_IDX_T ExtPos_OpenOpSubTpId                    ; /* PMSTA-47582 - JBC - 220406 */
extern FIELD_IDX_T ExtPos_IsProcessed                      ; /* WEALTH-15873 - Lalby - 05112024 */

/* PMSTA-31342 - SANAND - 180528 */
extern FIELD_IDX_T		ExtTaxLot_Id;					/*    0: IdType              */
extern FIELD_IDX_T		ExtTaxLot_TaxLotInitialId;		/*    1: IdType              */
extern FIELD_IDX_T		ExtTaxLot_OpenOperId;			/*    2: IdType              */
extern FIELD_IDX_T		ExtTaxLot_MovementNatEn;	    /*    3: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_OperNatEn;		    /*    4: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_LockNatEn;			/*    5: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_CorporateActionNatEn;	/*    6: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_PrimaryEn;			/*    7: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_BeginDate;			/*    8: DatetimeType        */
extern FIELD_IDX_T		ExtTaxLot_EndDate;				/*    9: DatetimeType        */
extern FIELD_IDX_T		ExtTaxLot_InstrId;				/*   10: IdType              */
extern FIELD_IDX_T		ExtTaxLot_QuoteNum;				/*   11: PriceType           */
extern FIELD_IDX_T		ExtTaxLot_PriceNum;				/*   12: PriceType           */
extern FIELD_IDX_T		ExtTaxLot_PriceCalcRuleEn;		/*   13: EnumType            */
extern FIELD_IDX_T		ExtTaxLot_QuantityNum;			/*   14: NumberType          */
extern FIELD_IDX_T		ExtTaxLot_PosCurrId;			/*   15: IdType              */
extern FIELD_IDX_T		ExtTaxLot_PfCurrId;				/*   16: IdType              */
extern FIELD_IDX_T		ExtTaxLot_PosGrossAmount;		/*   17: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosNetAmount;		    /*   18: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfGrossAmount;		/*   19: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfNetAmount;			/*   20: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_OpPosGrossAmount;	    /*   21: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_OpPosNetAmount;		/*   22: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_OpPfGrossAmount;		/*   23: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_OpPfNetAmount;		/*   24: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosPlStGrossAmount;	/*   25: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosPlLtGrossAmount;	/*   26: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosPlStNetAmount;	    /*   27: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosPlLtNetAmount;	    /*   28: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfPlStGrossAmount;	/*   29: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfPlLtGrossAmount;	/*   30: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfPlStNetAmount;		/*   31: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfPlLtNetAmount;		/*   32: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosYplStGrossAmount;	/*   33: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosYplLtGrossAmount;	/*   34: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosYplStNetAmount;	/*   35: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PosYplLtNetAmount;	/*   36: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfYplStGrossAmount;	/*   37: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfYplLtGrossAmount;	/*   38: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfYplStNetAmount;	    /*   39: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_PfYplLtNetAmount;	    /*   40: AmountType          */
extern FIELD_IDX_T		ExtTaxLot_TaxLotId;	            /*   41: IdType              */
extern FIELD_IDX_T		ExtTaxLot_ExtPosId;				/*   42: IdType              */
extern FIELD_IDX_T      ExtTaxLot_NatEn;			    /*   43: EnumType            */


extern FIELD_IDX_T PosVal_Id                               ;
extern FIELD_IDX_T PosVal_Date                             ;
extern FIELD_IDX_T PosVal_PosId                            ;
extern FIELD_IDX_T PosVal_AccrInterCurrId                  ;
extern FIELD_IDX_T PosVal_TermTpId                         ;
extern FIELD_IDX_T PosVal_PriceThirdId                     ;
extern FIELD_IDX_T PosVal_PriceTpId                        ;
extern FIELD_IDX_T PosVal_PriceCurrId                      ;
extern FIELD_IDX_T PosVal_QuoteDate                        ;
extern FIELD_IDX_T PosVal_Quote                            ;
extern FIELD_IDX_T PosVal_SpotQuote                        ;
extern FIELD_IDX_T PosVal_PriceCalcRuleEn                  ;
extern FIELD_IDX_T PosVal_Price                            ;
extern FIELD_IDX_T PosVal_SpotPrice                        ;
extern FIELD_IDX_T PosVal_ActuRate                         ;
extern FIELD_IDX_T PosVal_PosMktValAmt                     ;
extern FIELD_IDX_T PosVal_PosAccrInterAmt                  ;
extern FIELD_IDX_T PosVal_PosNetAmt                        ;
extern FIELD_IDX_T PosVal_RefMktValAmt                     ;
extern FIELD_IDX_T PosVal_RefAccrInterAmt                  ;
extern FIELD_IDX_T PosVal_RefNetAmt                        ;
extern FIELD_IDX_T PosVal_InstrMktValAmt                   ;
extern FIELD_IDX_T PosVal_InstrAccrInterAmt                ;
extern FIELD_IDX_T PosVal_InstrNetAmt                      ;
extern FIELD_IDX_T PosVal_AccrInter                        ;
extern FIELD_IDX_T PosVal_AccrInterNumPeriod               ;
extern FIELD_IDX_T PosVal_AccrInterDenomPeriod             ;
extern FIELD_IDX_T PosVal_AccrInterExchRate                ;
extern FIELD_IDX_T PosVal_PriceExchRate                    ;
extern FIELD_IDX_T PosVal_PosExchRate                      ;
extern FIELD_IDX_T PosVal_InstrExchRate                    ;
extern FIELD_IDX_T PosVal_DebtBaseVal                      ;
extern FIELD_IDX_T PosVal_ExtPosId                         ;
extern FIELD_IDX_T PosVal_DiscFac                          ;
extern FIELD_IDX_T PosVal_ExtPos_Ext                       ;


extern FIELD_IDX_T UnitInter_InstrId                       ;
extern FIELD_IDX_T UnitInter_ValidDate                     ;
extern FIELD_IDX_T UnitInter_ExCouponFlg                   ;
extern FIELD_IDX_T UnitInter_CurrId                        ;
extern FIELD_IDX_T UnitInter_UnitAccrInter                 ;
extern FIELD_IDX_T UnitInter_NumPeriod                     ;
extern FIELD_IDX_T UnitInter_DenomPeriod                   ;
extern FIELD_IDX_T UnitInter_UnitFlg                       ;
extern FIELD_IDX_T UnitInter_InterCalcRuleEn               ;
extern FIELD_IDX_T UnitInter_CalcFlg                       ;
extern FIELD_IDX_T UnitInter_FullCoupFlg                   ;
extern FIELD_IDX_T UnitInter_FusDateRuleEn                 ;
extern FIELD_IDX_T UnitInter_BegDate                       ;
extern FIELD_IDX_T UnitInter_AccrRuleEn                    ; /* REF11218 - TEB - 050627 */


extern FIELD_IDX_T A_Ytm_Ytm                               ;
extern FIELD_IDX_T A_Ytm_RedempDate                        ;
extern FIELD_IDX_T A_Ytm_RedempPrice                       ;
extern FIELD_IDX_T A_Ytm_NatEn                             ;


extern FIELD_IDX_T A_AdvA_Price                            ;
extern FIELD_IDX_T A_AdvA_NPV                              ;
extern FIELD_IDX_T A_AdvA_Dura                             ;
extern FIELD_IDX_T A_AdvA_Conv                             ;
extern FIELD_IDX_T A_AdvA_BPV                              ;
extern FIELD_IDX_T A_AdvA_Delta                            ;
extern FIELD_IDX_T A_AdvA_Delta2                           ;
extern FIELD_IDX_T A_AdvA_Gamma                            ;
extern FIELD_IDX_T A_AdvA_Gamma2                           ;
extern FIELD_IDX_T A_AdvA_GammaMix                         ;
extern FIELD_IDX_T A_AdvA_Vega                             ;
extern FIELD_IDX_T A_AdvA_DVegaDVol                        ;
extern FIELD_IDX_T A_AdvA_DpDc                             ;
extern FIELD_IDX_T A_AdvA_D2pDc2                           ;
extern FIELD_IDX_T A_AdvA_Theta                            ;
extern FIELD_IDX_T A_AdvA_Rho                              ;
extern FIELD_IDX_T A_AdvA_DRhoDr                           ;
extern FIELD_IDX_T A_AdvA_SwapRateSens                     ;
extern FIELD_IDX_T A_AdvA_ZeroYldSens                      ;
extern FIELD_IDX_T A_AdvA_Ctd                              ;
extern FIELD_IDX_T A_AdvA_Dlv_Date                         ;
extern FIELD_IDX_T A_AdvA_Cf                               ;
extern FIELD_IDX_T A_AdvA_DpDivYield                       ; /* REF9082 - TEB - 030610 */
extern FIELD_IDX_T A_AdvA_ImpliedVol                       ; /* REF9082 - LJE - 030611 */


extern FIELD_IDX_T AdvA_Arg_InstrId                        ;
extern FIELD_IDX_T AdvA_Arg_CalendarId                     ;
extern FIELD_IDX_T AdvA_Arg_KeyWordEn                      ;
extern FIELD_IDX_T AdvA_Arg_Date                           ;
extern FIELD_IDX_T AdvA_Arg_Spread                         ;
extern FIELD_IDX_T AdvA_Arg_Shock                          ;
extern FIELD_IDX_T AdvA_Arg_Margin                         ;
extern FIELD_IDX_T AdvA_Arg_Domestic                       ;
extern FIELD_IDX_T AdvA_Arg_MarketCTD                      ;
extern FIELD_IDX_T AdvA_Arg_Black                          ;
extern FIELD_IDX_T AdvA_Arg_Volatility                     ;
extern FIELD_IDX_T AdvA_Arg_Steps                          ;
extern FIELD_IDX_T AdvA_Arg_Flg                            ;
extern FIELD_IDX_T AdvA_Arg_InstrId2                       ;
extern FIELD_IDX_T AdvA_Arg_YieldCurveInstrId              ;
extern FIELD_IDX_T AdvA_Arg_PaidYcInstrId                  ;
extern FIELD_IDX_T AdvA_Arg_FloatingInstrYcId              ;
extern FIELD_IDX_T AdvA_Arg_PaidFloatingInstrYcId          ;
extern FIELD_IDX_T AdvA_Arg_UnderYcInstrId                 ;
extern FIELD_IDX_T AdvA_Arg_CalendarKeyWFlg                ;
extern FIELD_IDX_T AdvA_Arg_AddMarginPrct                  ;
extern FIELD_IDX_T AdvA_Arg_RefDate                        ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_Rate                           ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_EndDate                        ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_CurrentPrice                   ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_RedemptionPrice                ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_CouponTaxRate                  ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_CapitalGainTaxRate             ;  /* REF9082 - TEB - 030507 */
extern FIELD_IDX_T AdvA_Arg_PricingModelEn                 ;  /* REF9082 - TEB - 030603 */
extern FIELD_IDX_T AdvA_Arg_SceOutEn                       ;  /* REF9082 - TEB - 030604 */
extern FIELD_IDX_T AdvA_Arg_SensitivityEn                  ;  /* REF9082 - TEB - 030610 */
extern FIELD_IDX_T AdvA_Arg_UnderlyingPrice                ;  /* REF9082 - TEB - 030613 */
extern FIELD_IDX_T AdvA_Arg_Ytm                            ;  /* REF9082 - TEB - 030626 */
extern FIELD_IDX_T AdvA_Arg_FusDateRuleEn                  ;  /* REF9085 - TEB - 030627 */
extern FIELD_IDX_T AdvA_Arg_YieldTpEn                      ;  /* REF10620 - TEB - 041006 */
extern FIELD_IDX_T AdvA_Arg_AccrRuleEn                     ;  /* REF11218 - TEB - 050627 */
extern FIELD_IDX_T AdvA_Arg_FromDate                       ;  /* PMSTA05878 - RAK - 080425 */


extern FIELD_IDX_T AdvA_Vola_InstrId                       ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_InstrCurrId                   ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_RefDate                       ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_HistoRuleEn                   ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_HistoFreq                     ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_HistoFreqUnitEn               ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_HistoReading                  ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_ForceCalcFlg                  ;	/* REF10531 - TEB - 040806 */
extern FIELD_IDX_T AdvA_Vola_OptioArgFlg                   ;	/* REF10531 - TEB - 040806 */


extern FIELD_IDX_T RiskAmt_Price                           ;
extern FIELD_IDX_T RiskAmt_CompoQty                        ;
extern FIELD_IDX_T RiskAmt_SupplAmt                        ;
extern FIELD_IDX_T RiskAmt_PosGrossAmt                     ;
extern FIELD_IDX_T RiskAmt_PosNetAmt                       ;
extern FIELD_IDX_T RiskAmt_InstrGrossAmt                   ;
extern FIELD_IDX_T RiskAmt_InstrNetAmt                     ;
extern FIELD_IDX_T RiskAmt_RefGrossAmt                     ;
extern FIELD_IDX_T RiskAmt_RefNetAmt                       ;
extern FIELD_IDX_T RiskAmt_SysGrossAmt                     ;
extern FIELD_IDX_T RiskAmt_SysNetAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp1PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp2PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp3PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp4PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp5PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp6PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp7PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp8PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp9PosAmt                       ;
extern FIELD_IDX_T RiskAmt_Bp10PosAmt                      ;
extern FIELD_IDX_T RiskAmt_PosCurrId                       ;
extern FIELD_IDX_T RiskAmt_PosMktValAmt                    ;
extern FIELD_IDX_T RiskAmt_RefMktValAmt                    ;


extern FIELD_IDX_T Flow_Id                                 ;
extern FIELD_IDX_T Flow_InstrId                            ;
extern FIELD_IDX_T Flow_EvtCd                              ;
extern FIELD_IDX_T Flow_EvtNbr                             ;
extern FIELD_IDX_T Flow_NatEn                              ;
extern FIELD_IDX_T Flow_BegPayDate                         ;
extern FIELD_IDX_T Flow_EndPayDate                         ;
extern FIELD_IDX_T Flow_SettlDays                          ;
extern FIELD_IDX_T Flow_OptimalDate                        ;
extern FIELD_IDX_T Flow_OptimalValDate                     ;
extern FIELD_IDX_T Flow_IoRPrct                            ;
extern FIELD_IDX_T Flow_Quote                              ;
extern FIELD_IDX_T Flow_RefQty                             ;
extern FIELD_IDX_T Flow_AmtUnit                            ;
extern FIELD_IDX_T Flow_AmtCurrId                          ;
extern FIELD_IDX_T Flow_NewInstrId                         ;
extern FIELD_IDX_T Flow_QtyUnit                            ;
extern FIELD_IDX_T Flow_OptClassEn                         ;
extern FIELD_IDX_T Flow_OptStyleEn                         ;
extern FIELD_IDX_T Flow_Proba                              ;
extern FIELD_IDX_T Flow_Yield                              ;
extern FIELD_IDX_T Flow_Freq                               ;
extern FIELD_IDX_T Flow_FreqUnitEn                         ;
extern FIELD_IDX_T Flow_ExDate                             ;
extern FIELD_IDX_T Flow_FxdExchRate                        ;
extern FIELD_IDX_T Flow_CtdConvFact                        ;
extern FIELD_IDX_T Flow_CtdConvRatio                       ;
extern FIELD_IDX_T Flow_CtdInstrId                         ;
extern FIELD_IDX_T Flow_PhysicalFlg                        ;
extern FIELD_IDX_T Flow_Priority                           ;
extern FIELD_IDX_T Flow_EffectiveFlg                       ;
extern FIELD_IDX_T Flow_SubNatEn                           ;
extern FIELD_IDX_T Flow_ReplaceFlg                         ;
extern FIELD_IDX_T Flow_EuroConvRuleEn                     ;
extern FIELD_IDX_T Flow_RoundRuleEn                        ;
extern FIELD_IDX_T Flow_OddLotCompEn                       ;
extern FIELD_IDX_T Flow_RoundLevelEn                       ;
extern FIELD_IDX_T Flow_NewInstrMinDenom                   ;
extern FIELD_IDX_T Flow_DiscountFactor                     ;   /*  TGU - PMSTA01045 - 070125 */
extern FIELD_IDX_T Flow_ReceivedAmtUnit				       ;   /*  TGU - PMSTA01659 - 070302 */
extern FIELD_IDX_T Flow_PaidAmtUnit						   ;   /*  TGU - PMSTA01659 - 070302 */
extern FIELD_IDX_T Flow_ConfirmedFlg                       ;
extern FIELD_IDX_T Flow_ExtOp_Ext                          ;
extern FIELD_IDX_T Flow_A_Instr_Ext                        ;
extern FIELD_IDX_T Flow_FilterFlg                          ;
extern FIELD_IDX_T Flow_StatusEn                           ;
extern FIELD_IDX_T Flow_YieldCurveInstrId                  ;
extern FIELD_IDX_T Flow_StandInstructId                     ;   /* PMSTA06761 - DDV - 080805 */
extern FIELD_IDX_T Flow_DiscFactReceivedInstr              ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_DiscFactPaidInstr                  ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_DiscFactReceivedFloat              ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_DiscFactPaidFloat                  ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_AnnualReceivedRate                 ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_AnnualPaidRate                     ;  /* PMSTA10118 - DDV - 100623 - New fields for IRS */
extern FIELD_IDX_T Flow_LinkedInstrId                      ; /* PMSTA - 42330 - CHANDRU - 22102020*/
extern FIELD_IDX_T Flow_TpId                               ;



extern FIELD_IDX_T OpDomain_OpId                           ;
extern FIELD_IDX_T OpDomain_DimPtfDictId                   ;
extern FIELD_IDX_T OpDomain_PtfObjId                       ;
extern FIELD_IDX_T OpDomain_InstrId                        ;
extern FIELD_IDX_T OpDomain_OpNatEn                        ;
extern FIELD_IDX_T OpDomain_TpId                           ;
extern FIELD_IDX_T OpDomain_SubTpId                        ;
extern FIELD_IDX_T OpDomain_Cd                             ;
extern FIELD_IDX_T OpDomain_StatusEn                       ;
extern FIELD_IDX_T OpDomain_SequenceNo                     ;
extern FIELD_IDX_T OpDomain_AcctCd                         ;
extern FIELD_IDX_T OpDomain_ExtOpDbId                      ;        /*  FIH-REF9043-030429  */
extern FIELD_IDX_T OpDomain_DraftOrderId                   ;        /* REF8500 - 040510 - PMO */


extern FIELD_IDX_T BuyOp_Id                                ;
extern FIELD_IDX_T BuyOp_Cd                                ;
extern FIELD_IDX_T BuyOp_InputUserId                       ;
extern FIELD_IDX_T BuyOp_TpId                              ;
extern FIELD_IDX_T BuyOp_SubTpId                           ;
extern FIELD_IDX_T BuyOp_MktThirdId                        ;
extern FIELD_IDX_T BuyOp_IntermThirdId                     ;
extern FIELD_IDX_T BuyOp_MgrId                             ;
extern FIELD_IDX_T BuyOp_RuleId                            ;
extern FIELD_IDX_T BuyOp_SrcCd                             ;
extern FIELD_IDX_T BuyOp_SubPosNatEn                       ;
extern FIELD_IDX_T BuyOp_SubPosNat2En                      ;
extern FIELD_IDX_T BuyOp_SubPosNat3En                      ;
extern FIELD_IDX_T BuyOp_LockSubPosNatEn                   ;
extern FIELD_IDX_T BuyOp_LockSubPosNat2En                  ;
extern FIELD_IDX_T BuyOp_LockSubPosNat3En                  ;
extern FIELD_IDX_T BuyOp_LimitQuote                        ;
extern FIELD_IDX_T BuyOp_LimitPrice                        ;
extern FIELD_IDX_T BuyOp_StopQuote                         ;
extern FIELD_IDX_T BuyOp_StopPrice                         ;
extern FIELD_IDX_T BuyOp_OrderPriceNatEn                   ;
extern FIELD_IDX_T BuyOp_OrderValidNatEn                   ;
extern FIELD_IDX_T BuyOp_MinOrderQty                       ;
extern FIELD_IDX_T BuyOp_ParOpCd                           ;
extern FIELD_IDX_T BuyOp_ParOpNatEn                        ;
extern FIELD_IDX_T BuyOp_CheckParentEn                     ;
extern FIELD_IDX_T BuyOp_CheckStratEn                      ;
extern FIELD_IDX_T BuyOp_OrderNatEn                        ;
extern FIELD_IDX_T BuyOp_AcctDate                          ;
extern FIELD_IDX_T BuyOp_OpDate                            ;
extern FIELD_IDX_T BuyOp_OrderLimitDate                    ;
extern FIELD_IDX_T BuyOp_ValueDate                         ;
extern FIELD_IDX_T BuyOp_RefOpCd                           ;
extern FIELD_IDX_T BuyOp_RefNatEn                          ;
extern FIELD_IDX_T BuyOp_StatusEn                          ;
extern FIELD_IDX_T BuyOp_SequenceNo                        ;
extern FIELD_IDX_T BuyOp_AcctCd                            ;
extern FIELD_IDX_T BuyOp_PtfId                             ;
extern FIELD_IDX_T BuyOp_CashPtfId                         ;
extern FIELD_IDX_T BuyOp_InstrId                           ;
extern FIELD_IDX_T BuyOp_AcctId                            ;
extern FIELD_IDX_T BuyOp_Acct2Id                           ;
extern FIELD_IDX_T BuyOp_Acct3Id                           ;
extern FIELD_IDX_T BuyOp_LockInstrId                       ;
extern FIELD_IDX_T BuyOp_DepoId                            ;
extern FIELD_IDX_T BuyOp_LockDepoId                        ;
extern FIELD_IDX_T BuyOp_OpCurrId                          ;
extern FIELD_IDX_T BuyOp_InstrCurrId                       ;
extern FIELD_IDX_T BuyOp_PtfCurrId                         ;
extern FIELD_IDX_T BuyOp_AcctCurrId                        ;
extern FIELD_IDX_T BuyOp_Acct2CurrId                       ;
extern FIELD_IDX_T BuyOp_Acct3CurrId                       ;
extern FIELD_IDX_T BuyOp_TradeCurrId                       ;
extern FIELD_IDX_T BuyOp_CashPtfCurrId                     ;
extern FIELD_IDX_T BuyOp_LockOpCurrId                      ;
extern FIELD_IDX_T BuyOp_LockFiCurrId                      ;
extern FIELD_IDX_T BuyOp_CntPtyThirdId                     ;
extern FIELD_IDX_T BuyOp_TermTpId                          ;
extern FIELD_IDX_T BuyOp_LockTpId                          ;
extern FIELD_IDX_T BuyOp_AccrIntrBpTpId                    ;
extern FIELD_IDX_T BuyOp_ExtOrderId                        ;
extern FIELD_IDX_T BuyOp_OrderCd                           ;
extern FIELD_IDX_T BuyOp_ExecSetCriteria                   ;
extern FIELD_IDX_T BuyOp_ExecOpId                          ;
extern FIELD_IDX_T BuyOp_ExecOpCd                          ;
extern FIELD_IDX_T BuyOp_ExecOpNatEn                       ;
extern FIELD_IDX_T BuyOp_ExecOpStatEn                      ;
extern FIELD_IDX_T BuyOp_RevOpCd                           ;
extern FIELD_IDX_T BuyOp_RevOpNatEn                        ;
extern FIELD_IDX_T BuyOp_LockOpCd                          ;
extern FIELD_IDX_T BuyOp_LockNatEn                         ;
extern FIELD_IDX_T BuyOp_EvtCd                             ;
extern FIELD_IDX_T BuyOp_EvtNbr                            ;
extern FIELD_IDX_T BuyOp_ExCouponFlg                       ;
extern FIELD_IDX_T BuyOp_FusRuleEn                         ;
extern FIELD_IDX_T BuyOp_LockLimitDate                     ;
extern FIELD_IDX_T BuyOp_ExpirDate                         ;
extern FIELD_IDX_T BuyOp_Remark                            ;
extern FIELD_IDX_T BuyOp_OpExchRate                        ;
extern FIELD_IDX_T BuyOp_InstrExchRate                     ;
extern FIELD_IDX_T BuyOp_SysExchRate                       ;
extern FIELD_IDX_T BuyOp_AcctExchRate                      ;
extern FIELD_IDX_T BuyOp_Acct2ExchRate                     ;
extern FIELD_IDX_T BuyOp_Acct3ExchRate                     ;
extern FIELD_IDX_T BuyOp_TradeExchRate                     ;
extern FIELD_IDX_T BuyOp_CashPtfExchRate                   ;
extern FIELD_IDX_T BuyOp_LockOpExchRate                    ;
extern FIELD_IDX_T BuyOp_LockFiExchRate                    ;
extern FIELD_IDX_T BuyOp_Qty                               ;
extern FIELD_IDX_T BuyOp_LockQty                           ;
extern FIELD_IDX_T BuyOp_Price                             ;
extern FIELD_IDX_T BuyOp_SpotPrice                         ;
extern FIELD_IDX_T BuyOp_LockDirtyPrice                    ;
extern FIELD_IDX_T BuyOp_LockCleanPrice                    ;
extern FIELD_IDX_T BuyOp_PriceCalcRuleEn                   ;
extern FIELD_IDX_T BuyOp_Quote                             ;
extern FIELD_IDX_T BuyOp_SpotQuote                         ;
extern FIELD_IDX_T BuyOp_LockDirtyQuote                    ;
extern FIELD_IDX_T BuyOp_LockCleanQuote                    ;
extern FIELD_IDX_T BuyOp_Rate                              ;
extern FIELD_IDX_T BuyOp_LockPriceMargin                   ;
extern FIELD_IDX_T BuyOp_SupplAmt                          ;
extern FIELD_IDX_T BuyOp_OpGrossAmt                        ;
extern FIELD_IDX_T BuyOp_AccrIntrAmt                       ;
extern FIELD_IDX_T BuyOp_OpNetAmt                          ;
extern FIELD_IDX_T BuyOp_InstrNetAmt                       ;
extern FIELD_IDX_T BuyOp_PtfNetAmt                         ;
extern FIELD_IDX_T BuyOp_SysNetAmt                         ;
extern FIELD_IDX_T BuyOp_AcctNetAmt                        ;
extern FIELD_IDX_T BuyOp_Acct2NetAmt                       ;
extern FIELD_IDX_T BuyOp_Acct3NetAmt                       ;
extern FIELD_IDX_T BuyOp_Bp1TpId                           ;
extern FIELD_IDX_T BuyOp_Bp1CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp1Amt                            ;
extern FIELD_IDX_T BuyOp_Bp2TpId                           ;
extern FIELD_IDX_T BuyOp_Bp2CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp2Amt                            ;
extern FIELD_IDX_T BuyOp_Bp3TpId                           ;
extern FIELD_IDX_T BuyOp_Bp3CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp3Amt                            ;
extern FIELD_IDX_T BuyOp_Bp4TpId                           ;
extern FIELD_IDX_T BuyOp_Bp4CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp4Amt                            ;
extern FIELD_IDX_T BuyOp_Bp5TpId                           ;
extern FIELD_IDX_T BuyOp_Bp5CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp5Amt                            ;
extern FIELD_IDX_T BuyOp_Bp6TpId                           ;
extern FIELD_IDX_T BuyOp_Bp6CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp6Amt                            ;
extern FIELD_IDX_T BuyOp_Bp7TpId                           ;
extern FIELD_IDX_T BuyOp_Bp7CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp7Amt                            ;
extern FIELD_IDX_T BuyOp_Bp8TpId                           ;
extern FIELD_IDX_T BuyOp_Bp8CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp8Amt                            ;
extern FIELD_IDX_T BuyOp_Bp9TpId                           ;
extern FIELD_IDX_T BuyOp_Bp9CurrId                         ;
extern FIELD_IDX_T BuyOp_Bp9Amt                            ;
extern FIELD_IDX_T BuyOp_Bp10TpId                          ;
extern FIELD_IDX_T BuyOp_Bp10CurrId                        ;
extern FIELD_IDX_T BuyOp_Bp10Amt                           ;
extern FIELD_IDX_T BuyOp_FlowId                            ;
extern FIELD_IDX_T BuyOp_InitExtPosId                      ;
extern FIELD_IDX_T BuyOp_LastUserId                        ;
extern FIELD_IDX_T BuyOp_LastModifDate                     ;
extern FIELD_IDX_T BuyOp_CreationTime                      ;
extern FIELD_IDX_T BuyOp_SysCurrId                         ;
extern FIELD_IDX_T BuyOp_ConfirmedFlg                      ;
extern FIELD_IDX_T BuyOp_GroupingCriteria                  ;
extern FIELD_IDX_T BuyOp_OrderGroupingCd                   ;
extern FIELD_IDX_T BuyOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T BuyOp_TraderMgrId					   ;
extern FIELD_IDX_T BuyOp_AutoRenewalEn					   ;
extern FIELD_IDX_T BuyOp_RenewalTreatmtEn				   ;
extern FIELD_IDX_T BuyOp_RenewalEndValDate				   ;
extern FIELD_IDX_T BuyOp_RenewalLength					   ;
extern FIELD_IDX_T BuyOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T BuyOp_ClientInitEn					   ;
extern FIELD_IDX_T BuyOp_ContractNumber					   ;
extern FIELD_IDX_T BuyOp_TransactionNatEn				   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T BuyOp_RenewalIntRate                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BuyOp_RenewalAmount                     ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BuyOp_ExecutedFlg                       ;
extern FIELD_IDX_T BuyOp_FctResultId                       ;
extern FIELD_IDX_T BuyOp_ExtOpId                           ;
extern FIELD_IDX_T BuyOp_ExtOp_Ext                         ;
extern FIELD_IDX_T BuyOp_AutoIndex                         ;
extern FIELD_IDX_T BuyOp_ExtOpDbId                         ;
extern FIELD_IDX_T BuyOp_BeginDate                         ;
extern FIELD_IDX_T BuyOp_EndDate                           ;
extern FIELD_IDX_T BuyOp_DraftOrderId                      ;	/* REF8500 - 040510 - PMO */
extern FIELD_IDX_T BuyOp_TimeStamp                         ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T BuyOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T BuyOp_FxFarLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BuyOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BuyOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BuyOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BuyOp_OrderFeeEn                        ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BuyOp_OrderFeePrct                      ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BuyOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T BuyOp_STPOrderEn						   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T BuyOp_UnpaidPrct						   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T BuyOp_HistQuote                         ;    /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T BuyOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BuyOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BuyOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BuyOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BuyOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BuyOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BuyOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BuyOp_Summary                           ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BuyOp_EventStatusId                     ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T BuyOp_EventActionEn                     ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T BuyOp_CompoundOrderMasterEltId			;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BuyOp_CompoundOrderSlaveEltId			; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BuyOp_CompoundOrderCode					; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BuyOp_CompoundOrderSlaveNbr				; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BuyOp_CompoundImpactRule					; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BuyOp_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BuyOp_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BuyOp_CommonRef                         ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T BuyOp_OrderInclusionEn                  ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BuyOp_OrderRejectionDate                ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BuyOp_OrderRejectionComment             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BuyOp_AcquisitionDate                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BuyOp_CorporateActionNatEn              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BuyOp_TaxLotSourceCd                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BuyOp_StandInstructId                   ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T BuyOp_BankFeePrct                       ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BuyOp_BankFeeAmount                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BuyOp_BankFeeCurrId                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BuyOp_PaymentOption                     ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T BuyOp_BidTypeEn                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid1Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid1Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid2Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid2Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid3Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_Bid3Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BuyOp_OpFusionRuleEn                    ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BuyOp_GlobalPosFlg                      ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BuyOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BuyOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BuyOp_CoolCancelEndDate                 ;  /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T BuyOp_FusionPrioEn                      ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T BuyOp_ExternalBankBic                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BuyOp_ExternalBankName                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BuyOp_ExternalBankAcctOwnrName          ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BuyOp_HedgeTradeEn                      ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T BuyOp_FixingDate                        ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr1            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr2            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr3            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_ExtrnlBnkAcctOwnrAddr4            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_PayRef1                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_PayRef2                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_PayRef3                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_PayRef4                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BuyOp_ExternalTradeFlg                  ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T BuyOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BuyOp_OrderNettingEn					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BuyOp_NettingCriteria                   ; /* PMSTA-37908 - adarshn	- 08012020 */
extern FIELD_IDX_T BuyOp_PaymentDate                       ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BuyOp_PaymentStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BuyOp_SettlementDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BuyOp_SettleStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BuyOp_CommissionCdEn                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_ChargeCdEn                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_OriginalAmount                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_CounterpartOrgAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_ExternalFeeM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_TotalChargesM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_CounterpartAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_OpLinkageCd                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_ChargedCustomerName               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BuyOp_BoPtfId                           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_BoAccountId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_OpSplitRuleEn                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_AdjBoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_CoaExDate                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_BoCashAcctId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_BoCashPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_SplitParentOperId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BuyOp_OriginalNetAmount                 ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T BuyOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T BuyOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_SmartRoundingOrgQty               ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_RoundingOrgQty					   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BuyOp_HierOperNatEn                     ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BuyOp_HierOperationCd                   ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BuyOp_HierGroupingCriteria              ; /* PMSTA-40208 - sanand	- 24092020 */
extern FIELD_IDX_T BuyOp_CashPlanId                        ; /*PMSTA-42402 Autocash Vishnu 12012021*/
extern FIELD_IDX_T BuyOp_NotionalInstrId                   ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BuyOp_InvestLimitEn                     ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BuyOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T BuyOp_SetOfProductFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T BuyOp_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T BuyOp_OrderSubTypeId                    ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T BuyOp_SetOfOtherFeesId                  ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T BuyOp_TraderThirdId                     ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T BuyOp_NetSettleAmount                   ; /* WEALTH-9095 - SENTHIL - 20240529 */
extern FIELD_IDX_T BuyOp_PremiumCurrencyId                 ; /* WEALTH-8559 - Senthil - 20240607 */
extern FIELD_IDX_T BuyOp_PremiumAmount                     ; /* WEALTH-8559 - Senthil - 20240607 */


extern FIELD_IDX_T SellOp_Id                               ;
extern FIELD_IDX_T SellOp_Cd                               ;
extern FIELD_IDX_T SellOp_InputUserId                      ;
extern FIELD_IDX_T SellOp_TpId                             ;
extern FIELD_IDX_T SellOp_SubTpId                          ;
extern FIELD_IDX_T SellOp_MktThirdId                       ;
extern FIELD_IDX_T SellOp_IntermThirdId                    ;
extern FIELD_IDX_T SellOp_MgrId                            ;
extern FIELD_IDX_T SellOp_RuleId                           ;
extern FIELD_IDX_T SellOp_SrcCd                            ;
extern FIELD_IDX_T SellOp_SubPosNatEn                      ;
extern FIELD_IDX_T SellOp_SubPosNat2En                     ;
extern FIELD_IDX_T SellOp_SubPosNat3En                     ;
extern FIELD_IDX_T SellOp_LockSubPosNatEn                  ;
extern FIELD_IDX_T SellOp_LockSubPosNat2En                 ;
extern FIELD_IDX_T SellOp_LockSubPosNat3En                 ;
extern FIELD_IDX_T SellOp_LimitQuote                       ;
extern FIELD_IDX_T SellOp_LimitPrice                       ;
extern FIELD_IDX_T SellOp_StopQuote                        ;
extern FIELD_IDX_T SellOp_StopPrice                        ;
extern FIELD_IDX_T SellOp_OrderPriceNatEn                  ;
extern FIELD_IDX_T SellOp_OrderValidNatEn                  ;
extern FIELD_IDX_T SellOp_MinOrderQty                      ;
extern FIELD_IDX_T SellOp_ParOpCd                          ;
extern FIELD_IDX_T SellOp_ParOpNatEn                       ;
extern FIELD_IDX_T SellOp_CheckParentEn                    ;
extern FIELD_IDX_T SellOp_CheckStratEn                     ;
extern FIELD_IDX_T SellOp_OrderNatEn                       ;
extern FIELD_IDX_T SellOp_AcctDate                         ;
extern FIELD_IDX_T SellOp_OpDate                           ;
extern FIELD_IDX_T SellOp_OrderLimitDate                   ;
extern FIELD_IDX_T SellOp_ValueDate                        ;
extern FIELD_IDX_T SellOp_RefOpCd                          ;
extern FIELD_IDX_T SellOp_RefNatEn                         ;
extern FIELD_IDX_T SellOp_StatusEn                         ;
extern FIELD_IDX_T SellOp_SequenceNo                       ;
extern FIELD_IDX_T SellOp_AcctCd                           ;
extern FIELD_IDX_T SellOp_PtfId                            ;
extern FIELD_IDX_T SellOp_CashPtfId                        ;
extern FIELD_IDX_T SellOp_InstrId                          ;
extern FIELD_IDX_T SellOp_AcctId                           ;
extern FIELD_IDX_T SellOp_Acct2Id                          ;
extern FIELD_IDX_T SellOp_Acct3Id                          ;
extern FIELD_IDX_T SellOp_LockInstrId                      ;
extern FIELD_IDX_T SellOp_DepoId                           ;
extern FIELD_IDX_T SellOp_LockDepositId                    ;
extern FIELD_IDX_T SellOp_OpCurrId                         ;
extern FIELD_IDX_T SellOp_InstrCurrId                      ;
extern FIELD_IDX_T SellOp_PtfCurrId                        ;
extern FIELD_IDX_T SellOp_AcctCurrId                       ;
extern FIELD_IDX_T SellOp_Acct2CurrId                      ;
extern FIELD_IDX_T SellOp_Acct3CurrId                      ;
extern FIELD_IDX_T SellOp_TradeCurrId                      ;
extern FIELD_IDX_T SellOp_CashPtfCurrId                    ;
extern FIELD_IDX_T SellOp_LockOpCurrId                     ;
extern FIELD_IDX_T SellOp_LockFiCurrId                     ;
extern FIELD_IDX_T SellOp_CntPtyThirdId                    ;
extern FIELD_IDX_T SellOp_TermTpId                         ;
extern FIELD_IDX_T SellOp_LockTpId                         ;
extern FIELD_IDX_T SellOp_AccrIntrBpTpId                   ;
extern FIELD_IDX_T SellOp_ExtOrderId                       ;
extern FIELD_IDX_T SellOp_OrderCd                          ;
extern FIELD_IDX_T SellOp_ExecSetCriteria                  ;
extern FIELD_IDX_T SellOp_ExecOpId                         ;
extern FIELD_IDX_T SellOp_ExecOpCd                         ;
extern FIELD_IDX_T SellOp_ExecOpNatEn                      ;
extern FIELD_IDX_T SellOp_ExecOpStatEn                     ;
extern FIELD_IDX_T SellOp_RevOpCd                          ;
extern FIELD_IDX_T SellOp_RevOpNatEn                       ;
extern FIELD_IDX_T SellOp_LockOpCd                         ;
extern FIELD_IDX_T SellOp_LockNatEn                        ;
extern FIELD_IDX_T SellOp_EvtCd                            ;
extern FIELD_IDX_T SellOp_EvtNbr                           ;
extern FIELD_IDX_T SellOp_ExCouponFlg                      ;
extern FIELD_IDX_T SellOp_FusRuleEn                        ;
extern FIELD_IDX_T SellOp_LockLimitDate                    ;
extern FIELD_IDX_T SellOp_ExpirDate                        ;
extern FIELD_IDX_T SellOp_Remark                           ;
extern FIELD_IDX_T SellOp_OpExchRate                       ;
extern FIELD_IDX_T SellOp_InstrExchRate                    ;
extern FIELD_IDX_T SellOp_SysExchRate                      ;
extern FIELD_IDX_T SellOp_AcctExchRate                     ;
extern FIELD_IDX_T SellOp_Acct2ExchRate                    ;
extern FIELD_IDX_T SellOp_Acct3ExchRate                    ;
extern FIELD_IDX_T SellOp_TradeExchRate                    ;
extern FIELD_IDX_T SellOp_CashPtfExchRate                  ;
extern FIELD_IDX_T SellOp_LockOpExchRate                   ;
extern FIELD_IDX_T SellOp_LockFiExchRate                   ;
extern FIELD_IDX_T SellOp_Qty                              ;
extern FIELD_IDX_T SellOp_LockQtyN                         ;
extern FIELD_IDX_T SellOp_Price                            ;
extern FIELD_IDX_T SellOp_SpotPrice                        ;
extern FIELD_IDX_T SellOp_LockDirtyPriceN                  ;
extern FIELD_IDX_T SellOp_LockCleanPriceN                  ;
extern FIELD_IDX_T SellOp_PriceCalcRuleEn                  ;
extern FIELD_IDX_T SellOp_Quote                            ;
extern FIELD_IDX_T SellOp_SpotQuote                        ;
extern FIELD_IDX_T SellOp_LockDirtyQuoteN                  ;
extern FIELD_IDX_T SellOp_LockCleanQuoteN                  ;
extern FIELD_IDX_T SellOp_Rate                             ;
extern FIELD_IDX_T SellOp_LockPriceMarginP                 ;
extern FIELD_IDX_T SellOp_SupplAmt                         ;
extern FIELD_IDX_T SellOp_OpGrossAmt                       ;
extern FIELD_IDX_T SellOp_AccrIntrAmt                      ;
extern FIELD_IDX_T SellOp_OpNetAmt                         ;
extern FIELD_IDX_T SellOp_InstrNetAmt                      ;
extern FIELD_IDX_T SellOp_PtfNetAmt                        ;
extern FIELD_IDX_T SellOp_SysNetAmt                        ;
extern FIELD_IDX_T SellOp_AcctNetAmt                       ;
extern FIELD_IDX_T SellOp_Acct2NetAmt                      ;
extern FIELD_IDX_T SellOp_Acct3NetAmt                      ;
extern FIELD_IDX_T SellOp_Bp1TpId                          ;
extern FIELD_IDX_T SellOp_Bp1CurrId                        ;
extern FIELD_IDX_T SellOp_Bp1Amt                           ;
extern FIELD_IDX_T SellOp_Bp2TpId                          ;
extern FIELD_IDX_T SellOp_Bp2CurrId                        ;
extern FIELD_IDX_T SellOp_Bp2Amt                           ;
extern FIELD_IDX_T SellOp_Bp3TpId                          ;
extern FIELD_IDX_T SellOp_Bp3CurrId                        ;
extern FIELD_IDX_T SellOp_Bp3Amt                           ;
extern FIELD_IDX_T SellOp_Bp4TpId                          ;
extern FIELD_IDX_T SellOp_Bp4CurrId                        ;
extern FIELD_IDX_T SellOp_Bp4Amt                           ;
extern FIELD_IDX_T SellOp_Bp5TpId                          ;
extern FIELD_IDX_T SellOp_Bp5CurrId                        ;
extern FIELD_IDX_T SellOp_Bp5Amt                           ;
extern FIELD_IDX_T SellOp_Bp6TpId                          ;
extern FIELD_IDX_T SellOp_Bp6CurrId                        ;
extern FIELD_IDX_T SellOp_Bp6Amt                           ;
extern FIELD_IDX_T SellOp_Bp7TpId                          ;
extern FIELD_IDX_T SellOp_Bp7CurrId                        ;
extern FIELD_IDX_T SellOp_Bp7Amt                           ;
extern FIELD_IDX_T SellOp_Bp8TpId                          ;
extern FIELD_IDX_T SellOp_Bp8CurrId                        ;
extern FIELD_IDX_T SellOp_Bp8Amt                           ;
extern FIELD_IDX_T SellOp_Bp9TpId                          ;
extern FIELD_IDX_T SellOp_Bp9CurrId                        ;
extern FIELD_IDX_T SellOp_Bp9Amt                           ;
extern FIELD_IDX_T SellOp_Bp10TpId                         ;
extern FIELD_IDX_T SellOp_Bp10CurrId                       ;
extern FIELD_IDX_T SellOp_Bp10Amt                          ;
extern FIELD_IDX_T SellOp_FlowId                           ;
extern FIELD_IDX_T SellOp_InitExtPosId                     ;
extern FIELD_IDX_T SellOp_LastUserId                       ;
extern FIELD_IDX_T SellOp_LastModifDate                    ;
extern FIELD_IDX_T SellOp_CreationTime                     ;
extern FIELD_IDX_T SellOp_SysCurrId                        ;
extern FIELD_IDX_T SellOp_ConfirmedFlg                     ;
extern FIELD_IDX_T SellOp_GroupingCriteria                 ;
extern FIELD_IDX_T SellOp_OrderGroupingCd                  ;
extern FIELD_IDX_T SellOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T SellOp_TraderMgrId					   ;
extern FIELD_IDX_T SellOp_AutoRenewalEn					   ;
extern FIELD_IDX_T SellOp_RenewalTreatmtEn				   ;
extern FIELD_IDX_T SellOp_RenewalEndValDate				   ;
extern FIELD_IDX_T SellOp_RenewalLength					   ;
extern FIELD_IDX_T SellOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T SellOp_ClientInitEn					   ;
extern FIELD_IDX_T SellOp_ContractNumber				   ;
extern FIELD_IDX_T SellOp_TransactionNatEn				   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T SellOp_RenewalIntRate                   ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T SellOp_RenewalAmount                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T SellOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T SellOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T SellOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T SellOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T SellOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T SellOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T SellOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T SellOp_ExecutedFlg                      ;
extern FIELD_IDX_T SellOp_FctResultId                      ;
extern FIELD_IDX_T SellOp_ExtOpId                          ;
extern FIELD_IDX_T SellOp_ExtOp_Ext                        ;
extern FIELD_IDX_T SellOp_AutoIndex                        ;
extern FIELD_IDX_T SellOp_ExtOpDbId                        ;
extern FIELD_IDX_T SellOp_BeginDate                        ;
extern FIELD_IDX_T SellOp_EndDate                          ;
extern FIELD_IDX_T SellOp_DraftOrderId                     ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T SellOp_TimeStamp                        ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T SellOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T SellOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T SellOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T SellOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T SellOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T SellOp_OrderFeeEn                       ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T SellOp_OrderFeePrct                     ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T SellOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T SellOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T SellOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T SellOp_HistQuote                        ;    /* PMSTA-4559 - 011107 - PMO */
extern FIELD_IDX_T SellOp_Summary                          ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T SellOp_EventStatusId                    ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T SellOp_EventActionEn                    ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T SellOp_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T SellOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T SellOp_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T SellOp_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T SellOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T SellOp_DisplayCondition					;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T SellOp_OrderType							;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T SellOp_CommonRef                         ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T SellOp_OrderInclusionEn                  ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T SellOp_OrderRejectionDate                ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T SellOp_OrderRejectionComment             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T SellOp_AcquisitionDate                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T SellOp_CorporateActionNatEn              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T SellOp_TaxLotSourceCd                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T SellOp_StandInstructId                   ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T SellOp_BankFeePrct                       ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T SellOp_BankFeeAmount                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T SellOp_BankFeeCurrId                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T SellOp_PaymentOption                     ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T SellOp_BidTypeEn                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid1Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid1Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid2Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid2Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid3Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_Bid3Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T SellOp_OpFusionRuleEn                    ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T SellOp_GlobalPosFlg                      ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T SellOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T SellOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T SellOp_CoolCancelEndDate                 ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T SellOp_FusionPrioEn                      ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T SellOp_ExternalBankBic                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T SellOp_ExternalBankName                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T SellOp_ExternalBankAcctOwnrName          ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T SellOp_HedgeTradeEn                      ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T SellOp_FixingDate                        ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr1            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr2            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr3            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_ExtrnlBnkAcctOwnrAddr4            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_PayRef1                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_PayRef2                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_PayRef3                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_PayRef4                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T SellOp_ExternalTradeFlg                  ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T SellOp_OriginalQty						; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T SellOp_OrderNettingEn					; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T SellOp_NettingCriteria                   ; /* PMSTA-37908 - adarshn	- 08012020 */
extern FIELD_IDX_T SellOp_PaymentDate                       ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T SellOp_PaymentStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T SellOp_SettlementDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T SellOp_SettleStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T SellOp_CommissionCdEn                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_ChargeCdEn                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_OriginalAmount                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_CounterpartOrgAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_ExternalFeeM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_TotalChargesM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_CounterpartAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_OpLinkageCd                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_ChargedCustomerName               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T SellOp_BoPtfId                           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_BoAccountId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_OpSplitRuleEn                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_AdjBoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_CoaExDate                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_BoCashAcctId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_BoCashPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_SplitParentOperId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T SellOp_OriginalNetAmount                 ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T SellOp_SplitParOpCd						; /* PMSTA-40714 */
extern FIELD_IDX_T SellOp_RuleApplicabilityEn				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_SmartRoundingQty					; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_SmartRoundingOrgQty				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_RoundingOrgQty					; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_SmartRoundingFlg					; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_SmartRoundingRuleId				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T SellOp_HierOperNatEn                     ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T SellOp_HierOperationCd                   ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T SellOp_HierGroupingCriteria              ; /* PMSTA-40208 - sanand	- 24092020 */
extern FIELD_IDX_T SellOp_CashPlanId                        ; /*PMSTA-42402 Autocash Vishnu 12012021*/
extern FIELD_IDX_T SellOp_NotionalInstrId                   ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T SellOp_InvestLimitEn                     ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T SellOp_SetOfFeesId						; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T SellOp_SetOfProductFeesId				; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T SellOp_BoRoutingBusEntityId				; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T SellOp_OrderSubTypeId                    ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T SellOp_SetOfOtherFeesId                  ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T SellOp_TraderThirdId                     ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T SellOp_NetSettleAmount                   ; /* WEALTH-9095 - SENTHIL - 20240529 */
extern FIELD_IDX_T SellOp_PremiumCurrencyId                 ; /* WEALTH-8559 - Senthil - 20240607 */
extern FIELD_IDX_T SellOp_PremiumAmount                     ; /* WEALTH-8559 - Senthil - 20240607 */


extern FIELD_IDX_T InvestOp_Id                             ;
extern FIELD_IDX_T InvestOp_Cd                             ;
extern FIELD_IDX_T InvestOp_InputUserId                    ;
extern FIELD_IDX_T InvestOp_TpId                           ;
extern FIELD_IDX_T InvestOp_SubTpId                        ;
extern FIELD_IDX_T InvestOp_MktThirdId                     ;
extern FIELD_IDX_T InvestOp_IntermThirdId                  ;
extern FIELD_IDX_T InvestOp_MgrId                          ;
extern FIELD_IDX_T InvestOp_RuleId                         ;
extern FIELD_IDX_T InvestOp_SrcCd                          ;
extern FIELD_IDX_T InvestOp_SubPosNatEn                    ;
extern FIELD_IDX_T InvestOp_SubPosNat2En                   ;
extern FIELD_IDX_T InvestOp_SubPosNat3En                   ;
extern FIELD_IDX_T InvestOp_LimitQuote                     ;
extern FIELD_IDX_T InvestOp_LimitPrice                     ;
extern FIELD_IDX_T InvestOp_StopQuote                      ;
extern FIELD_IDX_T InvestOp_StopPrice                      ;
extern FIELD_IDX_T InvestOp_OrderPriceNatEn                ;
extern FIELD_IDX_T InvestOp_OrderValidNatEn                ;
extern FIELD_IDX_T InvestOp_MinOrderQty                    ;
extern FIELD_IDX_T InvestOp_ParOpCd                        ;
extern FIELD_IDX_T InvestOp_ParOpNatEn                     ;
extern FIELD_IDX_T InvestOp_CheckParentEn                  ;
extern FIELD_IDX_T InvestOp_OrderNatEn                     ;
extern FIELD_IDX_T InvestOp_AcctDate                       ;
extern FIELD_IDX_T InvestOp_OpDate                         ;
extern FIELD_IDX_T InvestOp_OrderLimitDate                 ;
extern FIELD_IDX_T InvestOp_ValueDate                      ;
extern FIELD_IDX_T InvestOp_RefOpCd                        ;
extern FIELD_IDX_T InvestOp_RefNatEn                       ;
extern FIELD_IDX_T InvestOp_StatusEn                       ;
extern FIELD_IDX_T InvestOp_SequenceNo                     ;
extern FIELD_IDX_T InvestOp_AcctCd                         ;
extern FIELD_IDX_T InvestOp_PtfId                          ;
extern FIELD_IDX_T InvestOp_CashPtfId                      ;
extern FIELD_IDX_T InvestOp_InstrId                        ;
extern FIELD_IDX_T InvestOp_BalPosTpId                     ;
extern FIELD_IDX_T InvestOp_AcctId                         ;
extern FIELD_IDX_T InvestOp_Acct2Id                        ;
extern FIELD_IDX_T InvestOp_Acct3Id                        ;
extern FIELD_IDX_T InvestOp_DepoId                         ;
extern FIELD_IDX_T InvestOp_OpCurrId                       ;
extern FIELD_IDX_T InvestOp_InstrCurrId                    ;
extern FIELD_IDX_T InvestOp_PtfCurrId                      ;
extern FIELD_IDX_T InvestOp_AcctCurrId                     ;
extern FIELD_IDX_T InvestOp_Acct2CurrId                    ;
extern FIELD_IDX_T InvestOp_Acct3CurrId                    ;
extern FIELD_IDX_T InvestOp_TradeCurrId                    ;
extern FIELD_IDX_T InvestOp_CashPtfCurrId                  ;
extern FIELD_IDX_T InvestOp_CntPtyThirdId                  ;
extern FIELD_IDX_T InvestOp_TermTpId                       ;
extern FIELD_IDX_T InvestOp_LockTpId                       ;
extern FIELD_IDX_T InvestOp_AccrIntrBpTpId                 ;
extern FIELD_IDX_T InvestOp_ExecOpId                       ;
extern FIELD_IDX_T InvestOp_ExecOpCd                       ;
extern FIELD_IDX_T InvestOp_ExecOpNatEn                    ;
extern FIELD_IDX_T InvestOp_ExecOpStatEn                   ;
extern FIELD_IDX_T InvestOp_RevOpCd                        ;
extern FIELD_IDX_T InvestOp_RevOpNatEn                     ;
extern FIELD_IDX_T InvestOp_LockOpCd                       ;
extern FIELD_IDX_T InvestOp_LockNatEn                      ;
extern FIELD_IDX_T InvestOp_EvtCd                          ;
extern FIELD_IDX_T InvestOp_EvtNbr                         ;
extern FIELD_IDX_T InvestOp_ExCouponFlg                    ;
extern FIELD_IDX_T InvestOp_FusRuleEn                      ;
extern FIELD_IDX_T InvestOp_LockLimitDate                  ;
extern FIELD_IDX_T InvestOp_ExpirDate                      ;
extern FIELD_IDX_T InvestOp_Remark                         ;
extern FIELD_IDX_T InvestOp_OpExchRate                     ;
extern FIELD_IDX_T InvestOp_InstrExchRate                  ;
extern FIELD_IDX_T InvestOp_SysExchRate                    ;
extern FIELD_IDX_T InvestOp_AcctExchRate                   ;
extern FIELD_IDX_T InvestOp_Acct2ExchRate                  ;
extern FIELD_IDX_T InvestOp_Acct3ExchRate                  ;
extern FIELD_IDX_T InvestOp_TradeExchRate                  ;
extern FIELD_IDX_T InvestOp_CashPtfExchRate                ;
extern FIELD_IDX_T InvestOp_HistOpExchRate                 ;
extern FIELD_IDX_T InvestOp_HistInstrExchRate              ;
extern FIELD_IDX_T InvestOp_HistSysExchRate                ;
extern FIELD_IDX_T InvestOp_Qty                            ;
extern FIELD_IDX_T InvestOp_Price                          ;
extern FIELD_IDX_T InvestOp_SpotPrice                      ;
extern FIELD_IDX_T InvestOp_HistPrice                      ;
extern FIELD_IDX_T InvestOp_PriceCalcRuleEn                ;
extern FIELD_IDX_T InvestOp_Quote                          ;
extern FIELD_IDX_T InvestOp_SpotQuote                      ;
extern FIELD_IDX_T InvestOp_HistQuote                      ;
extern FIELD_IDX_T InvestOp_Rate                           ;
extern FIELD_IDX_T InvestOp_SupplAmt                       ;
extern FIELD_IDX_T InvestOp_OpGrossAmt                     ;
extern FIELD_IDX_T InvestOp_AccrIntrAmt                    ;
extern FIELD_IDX_T InvestOp_OpNetAmt                       ;
extern FIELD_IDX_T InvestOp_InstrNetAmt                    ;
extern FIELD_IDX_T InvestOp_PtfNetAmt                      ;
extern FIELD_IDX_T InvestOp_SysNetAmt                      ;
extern FIELD_IDX_T InvestOp_AcctNetAmt                     ;
extern FIELD_IDX_T InvestOp_Acct2NetAmt                    ;
extern FIELD_IDX_T InvestOp_Acct3NetAmt                    ;
extern FIELD_IDX_T InvestOp_HistOpNetAmt                   ;
extern FIELD_IDX_T InvestOp_HistInstrNetAmt                ;
extern FIELD_IDX_T InvestOp_HistPtfNetAmt                  ;
extern FIELD_IDX_T InvestOp_HistSysNetAmt                  ;
extern FIELD_IDX_T InvestOp_Bp1TpId                        ;
extern FIELD_IDX_T InvestOp_Bp1CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp1Amt                         ;
extern FIELD_IDX_T InvestOp_Bp2TpId                        ;
extern FIELD_IDX_T InvestOp_Bp2CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp2Amt                         ;
extern FIELD_IDX_T InvestOp_Bp3TpId                        ;
extern FIELD_IDX_T InvestOp_Bp3CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp3Amt                         ;
extern FIELD_IDX_T InvestOp_Bp4TpId                        ;
extern FIELD_IDX_T InvestOp_Bp4CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp4Amt                         ;
extern FIELD_IDX_T InvestOp_Bp5TpId                        ;
extern FIELD_IDX_T InvestOp_Bp5CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp5Amt                         ;
extern FIELD_IDX_T InvestOp_Bp6TpId                        ;
extern FIELD_IDX_T InvestOp_Bp6CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp6Amt                         ;
extern FIELD_IDX_T InvestOp_Bp7TpId                        ;
extern FIELD_IDX_T InvestOp_Bp7CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp7Amt                         ;
extern FIELD_IDX_T InvestOp_Bp8TpId                        ;
extern FIELD_IDX_T InvestOp_Bp8CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp8Amt                         ;
extern FIELD_IDX_T InvestOp_Bp9TpId                        ;
extern FIELD_IDX_T InvestOp_Bp9CurrId                      ;
extern FIELD_IDX_T InvestOp_Bp9Amt                         ;
extern FIELD_IDX_T InvestOp_Bp10TpId                       ;
extern FIELD_IDX_T InvestOp_Bp10CurrId                     ;
extern FIELD_IDX_T InvestOp_Bp10Amt                        ;
extern FIELD_IDX_T InvestOp_FlowId                         ;
extern FIELD_IDX_T InvestOp_InitExtPosId                   ;
extern FIELD_IDX_T InvestOp_LastUserId                     ;
extern FIELD_IDX_T InvestOp_LastModifDate                  ;
extern FIELD_IDX_T InvestOp_CreationTime                   ;
extern FIELD_IDX_T InvestOp_SysCurrId                      ;
extern FIELD_IDX_T InvestOp_ConfirmedFlg                   ;
extern FIELD_IDX_T InvestOp_FctResultId                    ;
extern FIELD_IDX_T InvestOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T InvestOp_TraderMgrId					   ;
extern FIELD_IDX_T InvestOp_AutoRenewalEn				   ;
extern FIELD_IDX_T InvestOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T InvestOp_RenewalEndValDate			   ;
extern FIELD_IDX_T InvestOp_RenewalLength				   ;
extern FIELD_IDX_T InvestOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T InvestOp_ClientInitEn				   ;
extern FIELD_IDX_T InvestOp_ContractNumber				   ;
extern FIELD_IDX_T InvestOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T InvestOp_RenewalIntRate                 ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T InvestOp_RenewalAmount                  ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T InvestOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InvestOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InvestOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InvestOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InvestOp_FxMarginNumber                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InvestOp_FxMarginPrct                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InvestOp_FxMarginAmount                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InvestOp_ExtOpId                        ;
extern FIELD_IDX_T InvestOp_ExtOp_Ext                      ;
extern FIELD_IDX_T InvestOp_AutoIndex                      ;
extern FIELD_IDX_T InvestOp_ExtOpDbId                      ;
extern FIELD_IDX_T InvestOp_BeginDate                      ;
extern FIELD_IDX_T InvestOp_EndDate                        ;
extern FIELD_IDX_T InvestOp_DraftOrderId                   ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T InvestOp_Summary                        ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InvestOp_TimeStamp                      ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T InvestOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T InvestOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InvestOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InvestOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InvestOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InvestOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T InvestOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T InvestOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T InvestOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T InvestOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T InvestOp_EventStatusId                  ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T InvestOp_EventActionEn                  ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T InvestOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InvestOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InvestOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InvestOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InvestOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InvestOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T InvestOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T InvestOp_CommonRef                      ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T InvestOp_OrderInclusionEn               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InvestOp_OrderRejectionDate             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InvestOp_OrderRejectionComment          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InvestOp_AcquisitionDate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InvestOp_CorporateActionNatEn           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InvestOp_TaxLotSourceCd                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InvestOp_StandInstructId                ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T InvestOp_BankFeePrct                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InvestOp_BankFeeAmount                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InvestOp_BankFeeCurrId                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InvestOp_PaymentOption                  ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T InvestOp_BidTypeEn                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid1Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid1Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid2Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid2Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid3Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_Bid3Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InvestOp_CounterpartAccount             ;
extern FIELD_IDX_T InvestOp_CounterpartCurrencyId          ;
extern FIELD_IDX_T InvestOp_OpFusionRuleEn                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T InvestOp_GlobalPosFlg                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T InvestOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T InvestOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T InvestOp_CoolCancelEndDate               ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T InvestOp_FusionPrioEn                    ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T InvestOp_ExternalBankBic                 ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InvestOp_ExternalBankName                ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InvestOp_ExternalBankAcctOwnrName        ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InvestOp_HedgeTradeEn                    ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T InvestOp_FixingDate                      ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr1          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr2          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr3          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_ExtrnlBnkAcctOwnrAddr4          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_PayRef1                         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_PayRef2                         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_PayRef3                         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_PayRef4                         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InvestOp_ExternalTradeFlg                ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T InvestOp_OriginalQty						; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T InvestOp_OrderNettingEn					; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T InvestOp_PaymentDate                     ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InvestOp_PaymentStatusEn                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InvestOp_SettlementDate                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InvestOp_SettleStatusEn                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InvestOp_CommissionCdEn                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_ChargeCdEn                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_OriginalAmount                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_CounterpartOrgAmount            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_ExternalFeeM                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_TotalChargesM                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_CounterpartAmount               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_OpLinkageCd                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_ChargedCustomerName             ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InvestOp_BoPtfId                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_BoAccountId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_OpSplitRuleEn                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_AdjBoPtfId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_CoaExDate                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_BoCashAcctId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_BoCashPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_SplitParentOperId               ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T InvestOp_OriginalNetAmount               ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T InvestOp_SplitParOpCd					; /* PMSTA-40714 */
extern FIELD_IDX_T InvestOp_RuleApplicabilityEn				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_SmartRoundingQty				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_SmartRoundingOrgQty				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_RoundingOrgQty					; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_SmartRoundingFlg				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_SmartRoundingRuleId				; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InvestOp_HierOperNatEn                   ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T InvestOp_HierOperationCd                 ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T InvestOp_NotionalInstrId                 ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T InvestOp_InvestLimitEn                   ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T InvestOp_CashPlanId                      ; /*PMSTA-46635 Autocash Vishnu 17112021*/
extern FIELD_IDX_T InvestOp_SetOfFeesId						; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T InvestOp_SetOfProductFeesId				; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T InvestOp_BoRoutingBusEntityId			; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T InvestOp_OrderSubTypeId                  ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T InvestOp_SetOfOtherFeesId                ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T InvestOp_TraderThirdId                   ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T InvestOp_NetSettleAmount                 ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T WithdrOp_Id                             ;
extern FIELD_IDX_T WithdrOp_Cd                             ;
extern FIELD_IDX_T WithdrOp_InputUserId                    ;
extern FIELD_IDX_T WithdrOp_TpId                           ;
extern FIELD_IDX_T WithdrOp_SubTpId                        ;
extern FIELD_IDX_T WithdrOp_MktThirdId                     ;
extern FIELD_IDX_T WithdrOp_IntermThirdId                  ;
extern FIELD_IDX_T WithdrOp_MgrId                          ;
extern FIELD_IDX_T WithdrOp_RuleId                         ;
extern FIELD_IDX_T WithdrOp_SrcCd                          ;
extern FIELD_IDX_T WithdrOp_SubPosNatEn                    ;
extern FIELD_IDX_T WithdrOp_SubPosNat2En                   ;
extern FIELD_IDX_T WithdrOp_SubPosNat3En                   ;
extern FIELD_IDX_T WithdrOp_LimitQuote                     ;
extern FIELD_IDX_T WithdrOp_LimitPrice                     ;
extern FIELD_IDX_T WithdrOp_StopQuote                      ;
extern FIELD_IDX_T WithdrOp_StopPrice                      ;
extern FIELD_IDX_T WithdrOp_OrderPriceNatEn                ;
extern FIELD_IDX_T WithdrOp_OrderValidNatEn                ;
extern FIELD_IDX_T WithdrOp_MinOrderQty                    ;
extern FIELD_IDX_T WithdrOp_ParOpCd                        ;
extern FIELD_IDX_T WithdrOp_ParOpNatEn                     ;
extern FIELD_IDX_T WithdrOp_CheckParentEn                  ;
extern FIELD_IDX_T WithdrOp_OrderNatEn                     ;
extern FIELD_IDX_T WithdrOp_AcctDate                       ;
extern FIELD_IDX_T WithdrOp_OpDate                         ;
extern FIELD_IDX_T WithdrOp_OrderLimitDate                 ;
extern FIELD_IDX_T WithdrOp_ValueDate                      ;
extern FIELD_IDX_T WithdrOp_RefOpCd                        ;
extern FIELD_IDX_T WithdrOp_RefNatEn                       ;
extern FIELD_IDX_T WithdrOp_StatusEn                       ;
extern FIELD_IDX_T WithdrOp_SequenceNo                     ;
extern FIELD_IDX_T WithdrOp_AcctCd                         ;
extern FIELD_IDX_T WithdrOp_PtfId                          ;
extern FIELD_IDX_T WithdrOp_CashPtfId                      ;
extern FIELD_IDX_T WithdrOp_InstrId                        ;
extern FIELD_IDX_T WithdrOp_BalPosTpId                     ;
extern FIELD_IDX_T WithdrOp_AcctId                         ;
extern FIELD_IDX_T WithdrOp_Acct2Id                        ;
extern FIELD_IDX_T WithdrOp_Acct3Id                        ;
extern FIELD_IDX_T WithdrOp_DepoId                         ;
extern FIELD_IDX_T WithdrOp_OpCurrId                       ;
extern FIELD_IDX_T WithdrOp_InstrCurrId                    ;
extern FIELD_IDX_T WithdrOp_PtfCurrId                      ;
extern FIELD_IDX_T WithdrOp_AcctCurrId                     ;
extern FIELD_IDX_T WithdrOp_Acct2CurrId                    ;
extern FIELD_IDX_T WithdrOp_Acct3CurrId                    ;
extern FIELD_IDX_T WithdrOp_TradeCurrId                    ;
extern FIELD_IDX_T WithdrOp_CashPtfCurrId                  ;
extern FIELD_IDX_T WithdrOp_CntPtyThirdId                  ;
extern FIELD_IDX_T WithdrOp_TermTpId                       ;
extern FIELD_IDX_T WithdrOp_LockTpId                       ;
extern FIELD_IDX_T WithdrOp_AccrIntrBpTpId                 ;
extern FIELD_IDX_T WithdrOp_ExecOpId                       ;
extern FIELD_IDX_T WithdrOp_ExecOpCd                       ;
extern FIELD_IDX_T WithdrOp_ExecOpNatEn                    ;
extern FIELD_IDX_T WithdrOp_ExecOpStatEn                   ;
extern FIELD_IDX_T WithdrOp_RevOpCd                        ;
extern FIELD_IDX_T WithdrOp_RevOpNatEn                     ;
extern FIELD_IDX_T WithdrOp_LockOpCd                       ;
extern FIELD_IDX_T WithdrOp_LockNatEn                      ;
extern FIELD_IDX_T WithdrOp_EvtCd                          ;
extern FIELD_IDX_T WithdrOp_EvtNbr                         ;
extern FIELD_IDX_T WithdrOp_ExCouponFlg                    ;
extern FIELD_IDX_T WithdrOp_FusRuleEn                      ;
extern FIELD_IDX_T WithdrOp_LockLimitDate                  ;
extern FIELD_IDX_T WithdrOp_ExpirDate                      ;
extern FIELD_IDX_T WithdrOp_Remark                         ;
extern FIELD_IDX_T WithdrOp_OpExchRate                     ;
extern FIELD_IDX_T WithdrOp_InstrExchRate                  ;
extern FIELD_IDX_T WithdrOp_SysExchRate                    ;
extern FIELD_IDX_T WithdrOp_AcctExchRate                   ;
extern FIELD_IDX_T WithdrOp_Acct2ExchRate                  ;
extern FIELD_IDX_T WithdrOp_Acct3ExchRate                  ;
extern FIELD_IDX_T WithdrOp_TradeExchRate                  ;
extern FIELD_IDX_T WithdrOp_CashPtfExchRate                ;
extern FIELD_IDX_T WithdrOp_HistOpExchRate                 ;
extern FIELD_IDX_T WithdrOp_HistInstrExchRate              ;
extern FIELD_IDX_T WithdrOp_HistSysExchRate                ;
extern FIELD_IDX_T WithdrOp_Qty                            ;
extern FIELD_IDX_T WithdrOp_Price                          ;
extern FIELD_IDX_T WithdrOp_SpotPrice                      ;
extern FIELD_IDX_T WithdrOp_HistPrice                      ;
extern FIELD_IDX_T WithdrOp_PriceCalcRuleEn                ;
extern FIELD_IDX_T WithdrOp_Quote                          ;
extern FIELD_IDX_T WithdrOp_SpotQuote                      ;
extern FIELD_IDX_T WithdrOp_HistQuote                      ;
extern FIELD_IDX_T WithdrOp_Rate                           ;
extern FIELD_IDX_T WithdrOp_SupplAmt                       ;
extern FIELD_IDX_T WithdrOp_OpGrossAmt                     ;
extern FIELD_IDX_T WithdrOp_AccrIntrAmt                    ;
extern FIELD_IDX_T WithdrOp_OpNetAmt                       ;
extern FIELD_IDX_T WithdrOp_InstrNetAmt                    ;
extern FIELD_IDX_T WithdrOp_PtfNetAmt                      ;
extern FIELD_IDX_T WithdrOp_SysNetAmt                      ;
extern FIELD_IDX_T WithdrOp_AcctNetAmt                     ;
extern FIELD_IDX_T WithdrOp_Acct2NetAmt                    ;
extern FIELD_IDX_T WithdrOp_Acct3NetAmt                    ;
extern FIELD_IDX_T WithdrOp_HistOpNetAmt                   ;
extern FIELD_IDX_T WithdrOp_HistInstrNetAmt                ;
extern FIELD_IDX_T WithdrOp_HistPtfNetAmt                  ;
extern FIELD_IDX_T WithdrOp_HistSysNetAmt                  ;
extern FIELD_IDX_T WithdrOp_Bp1TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp1CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp1Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp2TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp2CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp2Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp3TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp3CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp3Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp4TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp4CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp4Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp5TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp5CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp5Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp6TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp6CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp6Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp7TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp7CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp7Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp8TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp8CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp8Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp9TpId                        ;
extern FIELD_IDX_T WithdrOp_Bp9CurrId                      ;
extern FIELD_IDX_T WithdrOp_Bp9Amt                         ;
extern FIELD_IDX_T WithdrOp_Bp10TpId                       ;
extern FIELD_IDX_T WithdrOp_Bp10CurrId                     ;
extern FIELD_IDX_T WithdrOp_Bp10Amt                        ;
extern FIELD_IDX_T WithdrOp_FlowId                         ;
extern FIELD_IDX_T WithdrOp_InitExtPosId                   ;
extern FIELD_IDX_T WithdrOp_LastUserId                     ;
extern FIELD_IDX_T WithdrOp_LastModifDate                  ;
extern FIELD_IDX_T WithdrOp_CreationTime                   ;
extern FIELD_IDX_T WithdrOp_SysCurrId                      ;
extern FIELD_IDX_T WithdrOp_ConfirmedFlg                   ;
extern FIELD_IDX_T WithdrOp_FctResultId                    ;
extern FIELD_IDX_T WithdrOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T WithdrOp_TraderMgrId					   ;
extern FIELD_IDX_T WithdrOp_AutoRenewalEn				   ;
extern FIELD_IDX_T WithdrOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T WithdrOp_RenewalEndValDate			   ;
extern FIELD_IDX_T WithdrOp_RenewalLength				   ;
extern FIELD_IDX_T WithdrOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T WithdrOp_ClientInitEn				   ;
extern FIELD_IDX_T WithdrOp_ContractNumber				   ;
extern FIELD_IDX_T WithdrOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T WithdrOp_RenewalIntRate                 ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T WithdrOp_RenewalAmount                  ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T WithdrOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T WithdrOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T WithdrOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T WithdrOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T WithdrOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T WithdrOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T WithdrOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T WithdrOp_ExtOpId                        ;
extern FIELD_IDX_T WithdrOp_ExtOp_Ext                      ;
extern FIELD_IDX_T WithdrOp_AutoIndex                      ;
extern FIELD_IDX_T WithdrOp_ExtOpDbId                      ;
extern FIELD_IDX_T WithdrOp_BeginDate                      ;
extern FIELD_IDX_T WithdrOp_EndDate                        ;
extern FIELD_IDX_T WithdrOp_DraftOrderId                   ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T WithdrOp_Summary                        ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T WithdrOp_TimeStamp                      ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T WithdrOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T WithdrOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T WithdrOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T WithdrOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T WithdrOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T WithdrOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T WithdrOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T WithdrOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T WithdrOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T WithdrOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T WithdrOp_EventStatusId                  ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T WithdrOp_EventActionEn                  ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T WithdrOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T WithdrOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T WithdrOp_CompoundOrderCode		       ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T WithdrOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T WithdrOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T WithdrOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T WithdrOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T WithdrOp_CommonRef                      ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T WithdrOp_OrderInclusionEn               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T WithdrOp_OrderRejectionDate             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T WithdrOp_OrderRejectionComment          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T WithdrOp_AcquisitionDate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T WithdrOp_CorporateActionNatEn           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T WithdrOp_TaxLotSourceCd                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T WithdrOp_StandInstructId                ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T WithdrOp_BankFeePrct                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T WithdrOp_BankFeeAmount                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T WithdrOp_BankFeeCurrId                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T WithdrOp_PaymentOption                  ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T WithdrOp_BidTypeEn                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid1Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid1Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid2Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid2Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid3Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_Bid3Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T WithdrOp_OpFusionRuleEn                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T WithdrOp_GlobalPosFlg                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T WithdrOp_CounterpartAccount             ;
extern FIELD_IDX_T WithdrOp_CounterpartCurrencyId          ;
extern FIELD_IDX_T WithdrOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T WithdrOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T WithdrOp_CoolCancelEndDate              ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T WithdrOp_FusionPrioEn                   ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T WithdrOp_ExternalBankBic                ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T WithdrOp_ExternalBankName               ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T WithdrOp_ExternalBankAcctOwnrName       ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T WithdrOp_HedgeTradeEn                   ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T WithdrOp_FixingDate                     ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr1         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr2         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr3         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_ExtrnlBnkAcctOwnrAddr4         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_PayRef1                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_PayRef2                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_PayRef3                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_PayRef4                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T WithdrOp_ExternalTradeFlg               ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T WithdrOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T WithdrOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T WithdrOp_PaymentDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T WithdrOp_PaymentStatusEn                ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T WithdrOp_SettlementDate                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T WithdrOp_SettleStatusEn                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T WithdrOp_CommissionCdEn                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_ChargeCdEn                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_OriginalAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_CounterpartOrgAmount           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_ExternalFeeM                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_TotalChargesM                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_CounterpartAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_OpLinkageCd                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_ChargedCustomerName            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T WithdrOp_BoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_BoAccountId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_OpSplitRuleEn                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_AdjBoPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_CoaExDate                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_BoCashAcctId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_BoCashPtfId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_SplitParentOperId              ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T WithdrOp_OriginalNetAmount              ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T WithdrOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T WithdrOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T WithdrOp_HierOperNatEn                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T WithdrOp_HierOperationCd                ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T WithdrOp_NotionalInstrId                ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T WithdrOp_InvestLimitEn                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T WithdrOp_CashPlanId                     ; /*PMSTA-45637 Autocash Vishnu 22072021*/
extern FIELD_IDX_T WithdrOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T WithdrOp_SetOfProductFeesId			   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T WithdrOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T WithdrOp_OrderSubTypeId                 ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T WithdrOp_SetOfOtherFeesId               ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T WithdrOp_TraderThirdId                  ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T WithdrOp_NetSettleAmount                ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T IncOp_Id                                ;
extern FIELD_IDX_T IncOp_Cd                                ;
extern FIELD_IDX_T IncOp_InputUserId                       ;
extern FIELD_IDX_T IncOp_TpId                              ;
extern FIELD_IDX_T IncOp_SubTpId                           ;
extern FIELD_IDX_T IncOp_MktThirdId                        ;
extern FIELD_IDX_T IncOp_IntermThirdId                     ;
extern FIELD_IDX_T IncOp_MgrId                             ;
extern FIELD_IDX_T IncOp_RuleId                            ;
extern FIELD_IDX_T IncOp_SrcCd                             ;
extern FIELD_IDX_T IncOp_ParOpCd                           ;
extern FIELD_IDX_T IncOp_ParOpNatEn                        ;
extern FIELD_IDX_T IncOp_CheckParentEn                     ;
extern FIELD_IDX_T IncOp_AcctDate                          ;
extern FIELD_IDX_T IncOp_OpDate                            ;
extern FIELD_IDX_T IncOp_ValueDate                         ;
extern FIELD_IDX_T IncOp_RefOpCd                           ;
extern FIELD_IDX_T IncOp_RefNatEn                          ;
extern FIELD_IDX_T IncOp_StatusEn                          ;
extern FIELD_IDX_T IncOp_SequenceNo                        ;
extern FIELD_IDX_T IncOp_AcctCd                            ;
extern FIELD_IDX_T IncOp_PtfId                             ;
extern FIELD_IDX_T IncOp_CashPtfId                         ;
extern FIELD_IDX_T IncOp_InstrId                           ;
extern FIELD_IDX_T IncOp_DepoId                            ;
extern FIELD_IDX_T IncOp_BalPosTpId                        ;
extern FIELD_IDX_T IncOp_AcctId                            ;
extern FIELD_IDX_T IncOp_Acct2Id                           ;
extern FIELD_IDX_T IncOp_Acct3Id                           ;
extern FIELD_IDX_T IncOp_OpCurrId                          ;
extern FIELD_IDX_T IncOp_InstrCurrId                       ;
extern FIELD_IDX_T IncOp_PtfCurrId                         ;
extern FIELD_IDX_T IncOp_AcctCurrId                        ;
extern FIELD_IDX_T IncOp_Acct2CurrId                       ;
extern FIELD_IDX_T IncOp_Acct3CurrId                       ;
extern FIELD_IDX_T IncOp_CashPtfCurrId                     ;
extern FIELD_IDX_T IncOp_CntPtyThirdId                     ;
extern FIELD_IDX_T IncOp_LockTpId                          ;
extern FIELD_IDX_T IncOp_ExecOpId                          ;
extern FIELD_IDX_T IncOp_ExecOpCd                          ;
extern FIELD_IDX_T IncOp_ExecOpNatEn                       ;
extern FIELD_IDX_T IncOp_ExecOpStatEn                      ;
extern FIELD_IDX_T IncOp_RevOpCd                           ;
extern FIELD_IDX_T IncOp_RevOpNatEn                        ;
extern FIELD_IDX_T IncOp_LockOpCd                          ;
extern FIELD_IDX_T IncOp_LockNatEn                         ;
extern FIELD_IDX_T IncOp_EvtCd                             ;
extern FIELD_IDX_T IncOp_EvtNbr                            ;
extern FIELD_IDX_T IncOp_FusRuleEn                         ;
extern FIELD_IDX_T IncOp_Remark                            ;
extern FIELD_IDX_T IncOp_OpExchRate                        ;
extern FIELD_IDX_T IncOp_InstrExchRate                     ;
extern FIELD_IDX_T IncOp_SysExchRate                       ;
extern FIELD_IDX_T IncOp_AcctExchRate                      ;
extern FIELD_IDX_T IncOp_Acct2ExchRate                     ;
extern FIELD_IDX_T IncOp_Acct3ExchRate                     ;
extern FIELD_IDX_T IncOp_CashPtfExchRate                   ;
extern FIELD_IDX_T IncOp_Qty                               ;
extern FIELD_IDX_T IncOp_UnitInc                           ;
extern FIELD_IDX_T IncOp_SupplAmt                          ;
extern FIELD_IDX_T IncOp_OpGrossAmt                        ;
extern FIELD_IDX_T IncOp_OpNetAmt                          ;
extern FIELD_IDX_T IncOp_InstrNetAmt                       ;
extern FIELD_IDX_T IncOp_PtfNetAmt                         ;
extern FIELD_IDX_T IncOp_SysNetAmt                         ;
extern FIELD_IDX_T IncOp_AcctNetAmt                        ;
extern FIELD_IDX_T IncOp_Acct2NetAmt                       ;
extern FIELD_IDX_T IncOp_Acct3NetAmt                       ;
extern FIELD_IDX_T IncOp_Bp1TpId                           ;
extern FIELD_IDX_T IncOp_Bp1CurrId                         ;
extern FIELD_IDX_T IncOp_Bp1Amt                            ;
extern FIELD_IDX_T IncOp_Bp2TpId                           ;
extern FIELD_IDX_T IncOp_Bp2CurrId                         ;
extern FIELD_IDX_T IncOp_Bp2Amt                            ;
extern FIELD_IDX_T IncOp_Bp3TpId                           ;
extern FIELD_IDX_T IncOp_Bp3CurrId                         ;
extern FIELD_IDX_T IncOp_Bp3Amt                            ;
extern FIELD_IDX_T IncOp_Bp4TpId                           ;
extern FIELD_IDX_T IncOp_Bp4CurrId                         ;
extern FIELD_IDX_T IncOp_Bp4Amt                            ;
extern FIELD_IDX_T IncOp_Bp5TpId                           ;
extern FIELD_IDX_T IncOp_Bp5CurrId                         ;
extern FIELD_IDX_T IncOp_Bp5Amt                            ;
extern FIELD_IDX_T IncOp_Bp6TpId                           ;
extern FIELD_IDX_T IncOp_Bp6CurrId                         ;
extern FIELD_IDX_T IncOp_Bp6Amt                            ;
extern FIELD_IDX_T IncOp_Bp7TpId                           ;
extern FIELD_IDX_T IncOp_Bp7CurrId                         ;
extern FIELD_IDX_T IncOp_Bp7Amt                            ;
extern FIELD_IDX_T IncOp_Bp8TpId                           ;
extern FIELD_IDX_T IncOp_Bp8CurrId                         ;
extern FIELD_IDX_T IncOp_Bp8Amt                            ;
extern FIELD_IDX_T IncOp_Bp9TpId                           ;
extern FIELD_IDX_T IncOp_Bp9CurrId                         ;
extern FIELD_IDX_T IncOp_Bp9Amt                            ;
extern FIELD_IDX_T IncOp_Bp10TpId                          ;
extern FIELD_IDX_T IncOp_Bp10CurrId                        ;
extern FIELD_IDX_T IncOp_Bp10Amt                           ;
extern FIELD_IDX_T IncOp_FlowId                            ;
extern FIELD_IDX_T IncOp_InitExtPosId                      ;
extern FIELD_IDX_T IncOp_LastUserId                        ;
extern FIELD_IDX_T IncOp_LastModifDate                     ;
extern FIELD_IDX_T IncOp_CreationTime                      ;
extern FIELD_IDX_T IncOp_SysCurrId                         ;
extern FIELD_IDX_T IncOp_ConfirmedFlg                      ;
extern FIELD_IDX_T IncOp_FctResultId                       ;
extern FIELD_IDX_T IncOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T IncOp_TraderMgrId					   ;
extern FIELD_IDX_T IncOp_AutoRenewalEn					   ;
extern FIELD_IDX_T IncOp_RenewalTreatmtEn				   ;
extern FIELD_IDX_T IncOp_RenewalEndValDate			       ;
extern FIELD_IDX_T IncOp_RenewalLength				       ;
extern FIELD_IDX_T IncOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T IncOp_ClientInitEn				       ;
extern FIELD_IDX_T IncOp_ContractNumber				       ;
extern FIELD_IDX_T IncOp_TransactionNatEn			       ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T IncOp_RenewalIntRate                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T IncOp_RenewalAmount                     ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T IncOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T IncOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T IncOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T IncOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T IncOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T IncOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T IncOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T IncOp_ExtOpId                           ;
extern FIELD_IDX_T IncOp_ExtOp_Ext                         ;
extern FIELD_IDX_T IncOp_AutoIndex                         ;
extern FIELD_IDX_T IncOp_ExtOpDbId                         ;
extern FIELD_IDX_T IncOp_BeginDate                         ;
extern FIELD_IDX_T IncOp_EndDate                           ;
extern FIELD_IDX_T IncOp_DraftOrderId                      ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T IncOp_Summary                           ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T IncOp_TimeStamp                         ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T IncOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T IncOp_FxFarLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T IncOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T IncOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T IncOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T IncOp_OrderFeeEn						   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T IncOp_OrderFeePrct					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T IncOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T IncOp_STPOrderEn						   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T IncOp_UnpaidPrct						   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T IncOp_EventStatusId                     ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T IncOp_EventActionEn                     ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T IncOp_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T IncOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T IncOp_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T IncOp_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T IncOp_CompoundImpactRule				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T IncOp_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T IncOp_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T IncOp_CommonRef                         ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T IncOp_OrderInclusionEn                  ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T IncOp_OrderRejectionDate                ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T IncOp_OrderRejectionComment             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T IncOp_AcquisitionDate                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T IncOp_CorporateActionNatEn              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T IncOp_TaxLotSourceCd                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T IncOp_StandInstructId                   ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T IncOp_BankFeePrct                       ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T IncOp_BankFeeAmount                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T IncOp_BankFeeCurrId                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T IncOp_PaymentOption                     ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T IncOp_BidTypeEn                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid1Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid1Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid2Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid2Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid3Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_Bid3Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T IncOp_OpFusionRuleEn                    ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T IncOp_GlobalPosFlg                      ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T IncOp_OtcOrderEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T IncOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T IncOp_CoolCancelEndDate                 ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T IncOp_FusionPrioEn                      ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T IncOp_ExternalBankBic                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T IncOp_ExternalBankName                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T IncOp_ExternalBankAcctOwnrName          ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T IncOp_HedgeTradeEn                      ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T IncOp_FixingDate                        ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr1            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr2            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr3            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_ExtrnlBnkAcctOwnrAddr4            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_PayRef1                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_PayRef2                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_PayRef3                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_PayRef4                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T IncOp_ExternalTradeFlg                  ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T IncOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T IncOp_OrderNettingEn					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T IncOp_PaymentDate                       ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T IncOp_PaymentStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T IncOp_SettlementDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T IncOp_SettleStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T IncOp_CommissionCdEn                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_ChargeCdEn                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_OriginalAmount                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_CounterpartOrgAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_ExternalFeeM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_TotalChargesM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_CounterpartAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_OpLinkageCd                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_ChargedCustomerName               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T IncOp_BoPtfId                           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_BoAccountId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_OpSplitRuleEn                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_AdjBoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_CoaExDate                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_BoCashAcctId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_BoCashPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_SplitParentOperId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T IncOp_OriginalNetAmount                 ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T IncOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T IncOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_RoundingOrgQty					   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T IncOp_HierOperNatEn                     ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T IncOp_HierOperationCd                   ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T IncOp_NotionalInstrId                   ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T IncOp_InvestLimitEn                     ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T IncOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T IncOp_SetOfProductFeesId                ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T IncOp_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T IncOp_OrderSubTypeId                    ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T IncOp_SetOfOtherFeesId                  ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T IncOp_TraderThirdId                     ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T IncOp_NetSettleAmount                   ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T ShareIssOp_Id                           ;
extern FIELD_IDX_T ShareIssOp_Cd                           ;
extern FIELD_IDX_T ShareIssOp_InputUserId                  ;
extern FIELD_IDX_T ShareIssOp_TpId                         ;
extern FIELD_IDX_T ShareIssOp_SubTpId                      ;
extern FIELD_IDX_T ShareIssOp_MktThirdId                   ;
extern FIELD_IDX_T ShareIssOp_IntermThirdId                ;
extern FIELD_IDX_T ShareIssOp_MgrId                        ;
extern FIELD_IDX_T ShareIssOp_RuleId                       ;
extern FIELD_IDX_T ShareIssOp_SrcCd                        ;
extern FIELD_IDX_T ShareIssOp_ValoSeqNo                    ;
extern FIELD_IDX_T ShareIssOp_ParOpCd                      ;
extern FIELD_IDX_T ShareIssOp_ParOpNatEn                   ;
extern FIELD_IDX_T ShareIssOp_CheckParentEn                ;
extern FIELD_IDX_T ShareIssOp_AcctDate                     ;
extern FIELD_IDX_T ShareIssOp_OpDate                       ;
extern FIELD_IDX_T ShareIssOp_ValuationDate                ;
extern FIELD_IDX_T ShareIssOp_ValueDate                    ;
extern FIELD_IDX_T ShareIssOp_RefOpCd                      ;
extern FIELD_IDX_T ShareIssOp_RefNatEn                     ;
extern FIELD_IDX_T ShareIssOp_StatusEn                     ;
extern FIELD_IDX_T ShareIssOp_SequenceNo                   ;
extern FIELD_IDX_T ShareIssOp_AcctCd                       ;
extern FIELD_IDX_T ShareIssOp_PtfId                        ;
extern FIELD_IDX_T ShareIssOp_InstrId                      ;
extern FIELD_IDX_T ShareIssOp_BalPosTpId                   ;
extern FIELD_IDX_T ShareIssOp_AcctId                       ;
extern FIELD_IDX_T ShareIssOp_DepoId                       ;
extern FIELD_IDX_T ShareIssOp_OpCurrId                     ;
extern FIELD_IDX_T ShareIssOp_InstrCurrId                  ;
extern FIELD_IDX_T ShareIssOp_PtfCurrId                    ;
extern FIELD_IDX_T ShareIssOp_AcctCurrId                   ;
extern FIELD_IDX_T ShareIssOp_CntPtyThirdId                ;
extern FIELD_IDX_T ShareIssOp_LockTpId                     ;
extern FIELD_IDX_T ShareIssOp_ExecOpId                     ;
extern FIELD_IDX_T ShareIssOp_ExecOpCd                     ;
extern FIELD_IDX_T ShareIssOp_ExecOpNatEn                  ;
extern FIELD_IDX_T ShareIssOp_ExecOpStatEn                 ;
extern FIELD_IDX_T ShareIssOp_RevOpCd                      ;
extern FIELD_IDX_T ShareIssOp_RevOpNatEn                   ;
extern FIELD_IDX_T ShareIssOp_LockOpCd                     ;
extern FIELD_IDX_T ShareIssOp_LockNatEn                    ;
extern FIELD_IDX_T ShareIssOp_EvtCd                        ;
extern FIELD_IDX_T ShareIssOp_EvtNbr                       ;
extern FIELD_IDX_T ShareIssOp_FusRuleEn                    ;
extern FIELD_IDX_T ShareIssOp_Remark                       ;
extern FIELD_IDX_T ShareIssOp_OpExchRate                   ;
extern FIELD_IDX_T ShareIssOp_InstrExchRate                ;
extern FIELD_IDX_T ShareIssOp_SysExchRate                  ;
extern FIELD_IDX_T ShareIssOp_AcctExchRate                 ;
extern FIELD_IDX_T ShareIssOp_Qty                          ;
extern FIELD_IDX_T ShareIssOp_Price                        ;
extern FIELD_IDX_T ShareIssOp_SupplAmt                     ;
extern FIELD_IDX_T ShareIssOp_OpGrossAmt                   ;
extern FIELD_IDX_T ShareIssOp_OpNetAmt                     ;
extern FIELD_IDX_T ShareIssOp_InstrNetAmt                  ;
extern FIELD_IDX_T ShareIssOp_PtfNetAmt                    ;
extern FIELD_IDX_T ShareIssOp_SysNetAmt                    ;
extern FIELD_IDX_T ShareIssOp_AcctNetAmt                   ;
extern FIELD_IDX_T ShareIssOp_Bp1TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp1CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp1Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp2TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp2CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp2Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp3TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp3CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp3Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp4TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp4CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp4Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp5TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp5CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp5Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp6TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp6CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp6Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp7TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp7CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp7Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp8TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp8CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp8Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp9TpId                      ;
extern FIELD_IDX_T ShareIssOp_Bp9CurrId                    ;
extern FIELD_IDX_T ShareIssOp_Bp9Amt                       ;
extern FIELD_IDX_T ShareIssOp_Bp10TpId                     ;
extern FIELD_IDX_T ShareIssOp_Bp10CurrId                   ;
extern FIELD_IDX_T ShareIssOp_Bp10Amt                      ;
extern FIELD_IDX_T ShareIssOp_FlowId                       ;
extern FIELD_IDX_T ShareIssOp_InitExtPosId                 ;
extern FIELD_IDX_T ShareIssOp_LastUserId                   ;
extern FIELD_IDX_T ShareIssOp_LastModifDate                ;
extern FIELD_IDX_T ShareIssOp_CreationTime                 ;
extern FIELD_IDX_T ShareIssOp_SysCurrId                    ;
extern FIELD_IDX_T ShareIssOp_FundValId                    ;
extern FIELD_IDX_T ShareIssOp_ConfirmedFlg                 ;
extern FIELD_IDX_T ShareIssOp_FctResultId                  ;
extern FIELD_IDX_T ShareIssOp_OrderModeTypeId			   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T ShareIssOp_TraderMgrId				   ;
extern FIELD_IDX_T ShareIssOp_AutoRenewalEn				   ;
extern FIELD_IDX_T ShareIssOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T ShareIssOp_RenewalEndValDate			   ;
extern FIELD_IDX_T ShareIssOp_RenewalLength				   ;
extern FIELD_IDX_T ShareIssOp_RenewalLengthUnitEn		   ;
extern FIELD_IDX_T ShareIssOp_ClientInitEn				   ;
extern FIELD_IDX_T ShareIssOp_ContractNumber			   ;
extern FIELD_IDX_T ShareIssOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T ShareIssOp_RenewalIntRate               ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ShareIssOp_RenewalAmount                ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ShareIssOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareIssOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareIssOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareIssOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareIssOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareIssOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareIssOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareIssOp_ExtOpId                      ;
extern FIELD_IDX_T ShareIssOp_ExtOp_Ext                    ;
extern FIELD_IDX_T ShareIssOp_AutoIndex                    ;
extern FIELD_IDX_T ShareIssOp_ExtOpDbId                    ;
extern FIELD_IDX_T ShareIssOp_BeginDate                    ;
extern FIELD_IDX_T ShareIssOp_EndDate                      ;
extern FIELD_IDX_T ShareIssOp_DraftOrderId                 ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T ShareIssOp_Summary                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareIssOp_TimeStamp                    ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T ShareIssOp_DerivativeOrdEn			   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T ShareIssOp_FxFarLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareIssOp_FxSpotQuote				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareIssOp_FxQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareIssOp_FxSpotLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareIssOp_OrderFeeEn				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ShareIssOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ShareIssOp_MaxOrderQty				   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T ShareIssOp_STPOrderEn				   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T ShareIssOp_UnpaidPrct				   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T ShareIssOp_EventStatusId                ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T ShareIssOp_EventActionEn                ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T ShareIssOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareIssOp_CompoundOrderSlaveEltId	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareIssOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareIssOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareIssOp_CompoundImpactRule		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareIssOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ShareIssOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ShareIssOp_CommonRef                    ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T ShareIssOp_OrderInclusionEn             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareIssOp_OrderRejectionDate           ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareIssOp_OrderRejectionComment        ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareIssOp_AcquisitionDate              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareIssOp_CorporateActionNatEn         ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareIssOp_TaxLotSourceCd               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareIssOp_StandInstructId              ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T ShareIssOp_BankFeePrct                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareIssOp_BankFeeAmount                ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareIssOp_BankFeeCurrId                ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareIssOp_PaymentOption                ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T ShareIssOp_BidTypeEn                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid1Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid1Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid2Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid2Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid3Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_Bid3Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareIssOp_OpFusionRuleEn               ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ShareIssOp_GlobalPosFlg                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ShareIssOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ShareIssOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ShareIssOp_CoolCancelEndDate            ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T ShareIssOp_FusionPrioEn                 ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T ShareIssOp_ExternalBankBic              ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareIssOp_ExternalBankName             ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareIssOp_ExternalBankAcctOwnrName     ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareIssOp_HedgeTradeEn                 ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T ShareIssOp_FixingDate                   ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr1       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr2       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr3       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_ExtrnlBnkAcctOwnrAddr4       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_PayRef1                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_PayRef2                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_PayRef3                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_PayRef4                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareIssOp_ExternalTradeFlg             ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T ShareIssOp_OriginalQty				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T ShareIssOp_OrderNettingEn			   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T ShareIssOp_PaymentDate                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareIssOp_PaymentStatusEn              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareIssOp_SettlementDate               ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareIssOp_SettleStatusEn               ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareIssOp_CommissionCdEn               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_ChargeCdEn                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_OriginalAmount               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_CounterpartOrgAmount         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_ExternalFeeM                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_TotalChargesM                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_CounterpartAmount            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_OpLinkageCd                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_ChargedCustomerName          ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareIssOp_BoPtfId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_BoAccountId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_OpSplitRuleEn                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_AdjBoPtfId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_CoaExDate                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_BoCashAcctId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_BoCashPtfId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_SplitParentOperId            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareIssOp_OriginalNetAmount            ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T ShareIssOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T ShareIssOp_RuleApplicabilityEn		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_SmartRoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_RoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_SmartRoundingRuleId		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareIssOp_HierOperNatEn                ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T ShareIssOp_HierOperationCd              ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T ShareIssOp_NotionalInstrId              ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ShareIssOp_InvestLimitEn                ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ShareIssOp_SetOfFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ShareIssOp_SetOfProductFeesId		   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ShareIssOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T ShareIssOp_OrderSubTypeId               ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T ShareIssOp_SetOfOtherFeesId             ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T ShareIssOp_TraderThirdId                ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T ShareIssOp_NetSettleAmount              ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T ShareRedmOp_Id                          ;
extern FIELD_IDX_T ShareRedmOp_Cd                          ;
extern FIELD_IDX_T ShareRedmOp_InputUserId                 ;
extern FIELD_IDX_T ShareRedmOp_TpId                        ;
extern FIELD_IDX_T ShareRedmOp_SubTpId                     ;
extern FIELD_IDX_T ShareRedmOp_MktThirdId                  ;
extern FIELD_IDX_T ShareRedmOp_IntermThirdId               ;
extern FIELD_IDX_T ShareRedmOp_MgrId                       ;
extern FIELD_IDX_T ShareRedmOp_RuleId                      ;
extern FIELD_IDX_T ShareRedmOp_SrcCd                       ;
extern FIELD_IDX_T ShareRedmOp_ValoSeqNo                   ;
extern FIELD_IDX_T ShareRedmOp_ParOpCd                     ;
extern FIELD_IDX_T ShareRedmOp_ParOpNatEn                  ;
extern FIELD_IDX_T ShareRedmOp_CheckParentEn               ;
extern FIELD_IDX_T ShareRedmOp_AcctDate                    ;
extern FIELD_IDX_T ShareRedmOp_OpDate                      ;
extern FIELD_IDX_T ShareRedmOp_ValuationDate               ;
extern FIELD_IDX_T ShareRedmOp_ValueDate                   ;
extern FIELD_IDX_T ShareRedmOp_RefOpCd                     ;
extern FIELD_IDX_T ShareRedmOp_RefNatEn                    ;
extern FIELD_IDX_T ShareRedmOp_StatusEn                    ;
extern FIELD_IDX_T ShareRedmOp_SequenceNo                  ;
extern FIELD_IDX_T ShareRedmOp_AcctCd                      ;
extern FIELD_IDX_T ShareRedmOp_PtfId                       ;
extern FIELD_IDX_T ShareRedmOp_InstrId                     ;
extern FIELD_IDX_T ShareRedmOp_BalPosTpId                  ;
extern FIELD_IDX_T ShareRedmOp_AcctId                      ;
extern FIELD_IDX_T ShareRedmOp_DepoId                      ;
extern FIELD_IDX_T ShareRedmOp_OpCurrId                    ;
extern FIELD_IDX_T ShareRedmOp_InstrCurrId                 ;
extern FIELD_IDX_T ShareRedmOp_PtfCurrId                   ;
extern FIELD_IDX_T ShareRedmOp_AcctCurrId                  ;
extern FIELD_IDX_T ShareRedmOp_CntPtyThirdId               ;
extern FIELD_IDX_T ShareRedmOp_LockTpId                    ;
extern FIELD_IDX_T ShareRedmOp_ExecOpId                    ;
extern FIELD_IDX_T ShareRedmOp_ExecOpCd                    ;
extern FIELD_IDX_T ShareRedmOp_ExecOpNatEn                 ;
extern FIELD_IDX_T ShareRedmOp_ExecOpStatEn                ;
extern FIELD_IDX_T ShareRedmOp_RevOpCd                     ;
extern FIELD_IDX_T ShareRedmOp_RevOpNatEn                  ;
extern FIELD_IDX_T ShareRedmOp_LockOpCd                    ;
extern FIELD_IDX_T ShareRedmOp_LockNatEn                   ;
extern FIELD_IDX_T ShareRedmOp_EvtCd                       ;
extern FIELD_IDX_T ShareRedmOp_EvtNbr                      ;
extern FIELD_IDX_T ShareRedmOp_FusRuleEn                   ;
extern FIELD_IDX_T ShareRedmOp_Remark                      ;
extern FIELD_IDX_T ShareRedmOp_OpExchRate                  ;
extern FIELD_IDX_T ShareRedmOp_InstrExchRate               ;
extern FIELD_IDX_T ShareRedmOp_SysExchRate                 ;
extern FIELD_IDX_T ShareRedmOp_AcctExchRate                ;
extern FIELD_IDX_T ShareRedmOp_Qty                         ;
extern FIELD_IDX_T ShareRedmOp_Price                       ;
extern FIELD_IDX_T ShareRedmOp_SupplAmt                    ;
extern FIELD_IDX_T ShareRedmOp_OpGrossAmt                  ;
extern FIELD_IDX_T ShareRedmOp_OpNetAmt                    ;
extern FIELD_IDX_T ShareRedmOp_InstrNetAmt                 ;
extern FIELD_IDX_T ShareRedmOp_PtfNetAmt                   ;
extern FIELD_IDX_T ShareRedmOp_SysNetAmt                   ;
extern FIELD_IDX_T ShareRedmOp_AcctNetAmt                  ;
extern FIELD_IDX_T ShareRedmOp_Bp1TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp1CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp1Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp2TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp2CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp2Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp3TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp3CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp3Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp4TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp4CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp4Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp5TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp5CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp5Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp6TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp6CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp6Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp7TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp7CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp7Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp8TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp8CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp8Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp9TpId                     ;
extern FIELD_IDX_T ShareRedmOp_Bp9CurrId                   ;
extern FIELD_IDX_T ShareRedmOp_Bp9Amt                      ;
extern FIELD_IDX_T ShareRedmOp_Bp10TpId                    ;
extern FIELD_IDX_T ShareRedmOp_Bp10CurrId                  ;
extern FIELD_IDX_T ShareRedmOp_Bp10Amt                     ;
extern FIELD_IDX_T ShareRedmOp_FlowId                      ;
extern FIELD_IDX_T ShareRedmOp_InitExtPosId                ;
extern FIELD_IDX_T ShareRedmOp_LastUserId                  ;
extern FIELD_IDX_T ShareRedmOp_LastModifDate               ;
extern FIELD_IDX_T ShareRedmOp_CreationTime                ;
extern FIELD_IDX_T ShareRedmOp_SysCurrId                   ;
extern FIELD_IDX_T ShareRedmOp_FundValId                   ;
extern FIELD_IDX_T ShareRedmOp_ConfirmedFlg                ;
extern FIELD_IDX_T ShareRedmOp_FctResultId                 ;
extern FIELD_IDX_T ShareRedmOp_OrderModeTypeId			   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T ShareRedmOp_TraderMgrId				   ;
extern FIELD_IDX_T ShareRedmOp_AutoRenewalEn			   ;
extern FIELD_IDX_T ShareRedmOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T ShareRedmOp_RenewalEndValDate		   ;
extern FIELD_IDX_T ShareRedmOp_RenewalLength			   ;
extern FIELD_IDX_T ShareRedmOp_RenewalLengthUnitEn		   ;
extern FIELD_IDX_T ShareRedmOp_ClientInitEn				   ;
extern FIELD_IDX_T ShareRedmOp_ContractNumber			   ;
extern FIELD_IDX_T ShareRedmOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T ShareRedmOp_RenewalIntRate              ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ShareRedmOp_RenewalAmount               ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ShareRedmOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareRedmOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareRedmOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ShareRedmOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ShareRedmOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareRedmOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareRedmOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareRedmOp_ExtOpId                     ;
extern FIELD_IDX_T ShareRedmOp_ExtOp_Ext                   ;
extern FIELD_IDX_T ShareRedmOp_AutoIndex                   ;
extern FIELD_IDX_T ShareRedmOp_ExtOpDbId                   ;
extern FIELD_IDX_T ShareRedmOp_BeginDate                   ;
extern FIELD_IDX_T ShareRedmOp_EndDate                     ;
extern FIELD_IDX_T ShareRedmOp_DraftOrderId                ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T ShareRedmOp_Summary                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ShareRedmOp_TimeStamp                   ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T ShareRedmOp_DerivativeOrdEn			   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T ShareRedmOp_FxFarLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareRedmOp_FxSpotQuote				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareRedmOp_FxQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareRedmOp_FxSpotLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ShareRedmOp_OrderFeeEn				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ShareRedmOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ShareRedmOp_MaxOrderQty				   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T ShareRedmOp_STPOrderEn				   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T ShareRedmOp_UnpaidPrct				   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T ShareRedmOp_EventStatusId               ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T ShareRedmOp_EventActionEn               ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T ShareRedmOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareRedmOp_CompoundOrderSlaveEltId	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareRedmOp_CompoundOrderCode		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareRedmOp_CompoundOrderSlaveNbr	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareRedmOp_CompoundImpactRule		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ShareRedmOp_DisplayCondition			   ; /* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ShareRedmOp_OrderType				   ; /* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ShareRedmOp_CommonRef                   ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T ShareRedmOp_OrderInclusionEn            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareRedmOp_OrderRejectionDate          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareRedmOp_OrderRejectionComment       ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ShareRedmOp_AcquisitionDate             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareRedmOp_CorporateActionNatEn        ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareRedmOp_TaxLotSourceCd              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ShareRedmOp_StandInstructId             ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T ShareRedmOp_BankFeePrct                 ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareRedmOp_BankFeeAmount               ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareRedmOp_BankFeeCurrId               ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ShareRedmOp_PaymentOption               ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T ShareRedmOp_BidTypeEn                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid1Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid1Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid2Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid2Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid3Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_Bid3Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ShareRedmOp_OpFusionRuleEn              ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ShareRedmOp_GlobalPosFlg                ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ShareRedmOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ShareRedmOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ShareRedmOp_CoolCancelEndDate           ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T ShareRedmOp_FusionPrioEn                ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T ShareRedmOp_ExternalBankBic             ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareRedmOp_ExternalBankName            ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareRedmOp_ExternalBankAcctOwnrName    ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ShareRedmOp_HedgeTradeEn                ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T ShareRedmOp_FixingDate                  ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr1      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr2      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr3      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_ExtrnlBnkAcctOwnrAddr4      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_PayRef1                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_PayRef2                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_PayRef3                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_PayRef4                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ShareRedmOp_ExternalTradeFlg            ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T ShareRedmOp_OriginalQty				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T ShareRedmOp_OrderNettingEn			   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T ShareRedmOp_PaymentDate                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareRedmOp_PaymentStatusEn             ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareRedmOp_SettlementDate              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareRedmOp_SettleStatusEn              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ShareRedmOp_CommissionCdEn              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_ChargeCdEn                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_OriginalAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_CounterpartOrgAmount        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_ExternalFeeM                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_TotalChargesM               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_CounterpartAmount           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_OpLinkageCd                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_ChargedCustomerName         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ShareRedmOp_BoPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_BoAccountId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_OpSplitRuleEn               ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_AdjBoPtfId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_CoaExDate                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_BoCashAcctId                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_BoCashPtfId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_SplitParentOperId           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ShareRedmOp_OriginalNetAmount           ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T ShareRedmOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T ShareRedmOp_RuleApplicabilityEn		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_SmartRoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_RoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_SmartRoundingRuleId		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ShareRedmOp_HierOperNatEn               ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T ShareRedmOp_HierOperationCd             ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T ShareRedmOp_NotionalInstrId             ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ShareRedmOp_InvestLimitEn               ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ShareRedmOp_SetOfFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ShareRedmOp_SetOfProductFeesId		   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ShareRedmOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T ShareRedmOp_OrderSubTypeId              ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T ShareRedmOp_SetOfOtherFeesId            ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T ShareRedmOp_TraderThirdId               ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T ShareRedmOp_NetSettleAmount             ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T TransfOp_Id                             ;
extern FIELD_IDX_T TransfOp_Cd                             ;
extern FIELD_IDX_T TransfOp_InputUserId                    ;
extern FIELD_IDX_T TransfOp_TpId                           ;
extern FIELD_IDX_T TransfOp_SubTpId                        ;
extern FIELD_IDX_T TransfOp_MktThirdId                     ;
extern FIELD_IDX_T TransfOp_IntermThirdId                  ;
extern FIELD_IDX_T TransfOp_MgrId                          ;
extern FIELD_IDX_T TransfOp_RuleId                         ;
extern FIELD_IDX_T TransfOp_ValRuleId                      ;
extern FIELD_IDX_T TransfOp_ValRuleHistId                  ;
extern FIELD_IDX_T TransfOp_ValRuleEltId                   ;
extern FIELD_IDX_T TransfOp_SrcCd                          ;
extern FIELD_IDX_T TransfOp_SubPosNatEn                    ;
extern FIELD_IDX_T TransfOp_SubPosNat2En                   ;
extern FIELD_IDX_T TransfOp_SubPosNat3En                   ;
extern FIELD_IDX_T TransfOp_LimitQuote                     ;
extern FIELD_IDX_T TransfOp_LimitPrice                     ;
extern FIELD_IDX_T TransfOp_StopQuote                      ;
extern FIELD_IDX_T TransfOp_StopPrice                      ;
extern FIELD_IDX_T TransfOp_OrderPriceNatEn                ;
extern FIELD_IDX_T TransfOp_OrderValidNatEn                ;
extern FIELD_IDX_T TransfOp_MinOrderQty                    ;
extern FIELD_IDX_T TransfOp_ParOpCd                        ;
extern FIELD_IDX_T TransfOp_ParOpNatEn                     ;
extern FIELD_IDX_T TransfOp_CheckParentEn                  ;
extern FIELD_IDX_T TransfOp_OrderNatEn                     ;
extern FIELD_IDX_T TransfOp_AcctDate                       ;
extern FIELD_IDX_T TransfOp_OpDate                         ;
extern FIELD_IDX_T TransfOp_ValuationDate                  ;
extern FIELD_IDX_T TransfOp_OrderLimitDate                 ;
extern FIELD_IDX_T TransfOp_ValueDate                      ;
extern FIELD_IDX_T TransfOp_RefOpCd                        ;
extern FIELD_IDX_T TransfOp_RefNatEn                       ;
extern FIELD_IDX_T TransfOp_StatusEn                       ;
extern FIELD_IDX_T TransfOp_SequenceNo                     ;
extern FIELD_IDX_T TransfOp_AcctCd                         ;
extern FIELD_IDX_T TransfOp_PtfId                          ;
extern FIELD_IDX_T TransfOp_PortPosSetId                   ;
extern FIELD_IDX_T TransfOp_InstrId                        ;
extern FIELD_IDX_T TransfOp_BalPosTpId                     ;
extern FIELD_IDX_T TransfOp_DepoId                         ;
extern FIELD_IDX_T TransfOp_OpCurrId                       ;
extern FIELD_IDX_T TransfOp_InstrCurrId                    ;
extern FIELD_IDX_T TransfOp_PtfCurrId                      ;
extern FIELD_IDX_T TransfOp_TradeCurrId                    ;
extern FIELD_IDX_T TransfOp_CntPtyThirdId                  ;
extern FIELD_IDX_T TransfOp_TermTpId                       ;
extern FIELD_IDX_T TransfOp_LockTpId                       ;
extern FIELD_IDX_T TransfOp_AccrIntrBpTpId                 ;
extern FIELD_IDX_T TransfOp_ExecOpId                       ;
extern FIELD_IDX_T TransfOp_ExecOpCd                       ;
extern FIELD_IDX_T TransfOp_ExecOpNatEn                    ;
extern FIELD_IDX_T TransfOp_ExecOpStatEn                   ;
extern FIELD_IDX_T TransfOp_RevOpCd                        ;
extern FIELD_IDX_T TransfOp_RevOpNatEn                     ;
extern FIELD_IDX_T TransfOp_LockOpCd                       ;
extern FIELD_IDX_T TransfOp_LockNatEn                      ;
extern FIELD_IDX_T TransfOp_EvtCd                          ;
extern FIELD_IDX_T TransfOp_EvtNbr                         ;
extern FIELD_IDX_T TransfOp_ExCouponFlg                    ;
extern FIELD_IDX_T TransfOp_FusRuleEn                      ;
extern FIELD_IDX_T TransfOp_LockLimitDate                  ;
extern FIELD_IDX_T TransfOp_ExpirDate                      ;
extern FIELD_IDX_T TransfOp_Remark                         ;
extern FIELD_IDX_T TransfOp_OpExchRate                     ;
extern FIELD_IDX_T TransfOp_InstrExchRate                  ;
extern FIELD_IDX_T TransfOp_SysExchRate                    ;
extern FIELD_IDX_T TransfOp_TradeExchRate                  ;
extern FIELD_IDX_T TransfOp_HistOpExchRate                 ;
extern FIELD_IDX_T TransfOp_HistInstrExchRate              ;
extern FIELD_IDX_T TransfOp_HistSysExchRate                ;
extern FIELD_IDX_T TransfOp_BookOpExchRate                 ;
extern FIELD_IDX_T TransfOp_BookInstrExchRate              ;
extern FIELD_IDX_T TransfOp_BookSysExchRate                ;
extern FIELD_IDX_T TransfOp_Qty                            ;
extern FIELD_IDX_T TransfOp_Price                          ;
extern FIELD_IDX_T TransfOp_SpotPrice                      ;
extern FIELD_IDX_T TransfOp_HistPrice                      ;
extern FIELD_IDX_T TransfOp_BookPrice                      ;
extern FIELD_IDX_T TransfOp_PriceCalcRuleEn                ;
extern FIELD_IDX_T TransfOp_Quote                          ;
extern FIELD_IDX_T TransfOp_SpotQuote                      ;
extern FIELD_IDX_T TransfOp_HistQuote                      ;
extern FIELD_IDX_T TransfOp_BookQuote                      ;
extern FIELD_IDX_T TransfOp_Rate                           ;
extern FIELD_IDX_T TransfOp_SupplAmt                       ;
extern FIELD_IDX_T TransfOp_OpGrossAmt                     ;
extern FIELD_IDX_T TransfOp_AccrIntrAmt                    ;
extern FIELD_IDX_T TransfOp_OpNetAmt                       ;
extern FIELD_IDX_T TransfOp_InstrNetAmt                    ;
extern FIELD_IDX_T TransfOp_PtfNetAmt                      ;
extern FIELD_IDX_T TransfOp_SysNetAmt                      ;
extern FIELD_IDX_T TransfOp_HistOpNetAmt                   ;
extern FIELD_IDX_T TransfOp_HistInstrNetAmt                ;
extern FIELD_IDX_T TransfOp_HistPtfNetAmt                  ;
extern FIELD_IDX_T TransfOp_HistSysNetAmt                  ;
extern FIELD_IDX_T TransfOp_BookOpNetAmt                   ;
extern FIELD_IDX_T TransfOp_BookInstrNetAmt                ;
extern FIELD_IDX_T TransfOp_BookPtfNetAmt                  ;
extern FIELD_IDX_T TransfOp_BookSysNetAmt                  ;
extern FIELD_IDX_T TransfOp_Bp1TpId                        ;
extern FIELD_IDX_T TransfOp_Bp1CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp1Amt                         ;
extern FIELD_IDX_T TransfOp_Bp2TpId                        ;
extern FIELD_IDX_T TransfOp_Bp2CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp2Amt                         ;
extern FIELD_IDX_T TransfOp_Bp3TpId                        ;
extern FIELD_IDX_T TransfOp_Bp3CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp3Amt                         ;
extern FIELD_IDX_T TransfOp_Bp4TpId                        ;
extern FIELD_IDX_T TransfOp_Bp4CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp4Amt                         ;
extern FIELD_IDX_T TransfOp_Bp5TpId                        ;
extern FIELD_IDX_T TransfOp_Bp5CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp5Amt                         ;
extern FIELD_IDX_T TransfOp_Bp6TpId                        ;
extern FIELD_IDX_T TransfOp_Bp6CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp6Amt                         ;
extern FIELD_IDX_T TransfOp_Bp7TpId                        ;
extern FIELD_IDX_T TransfOp_Bp7CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp7Amt                         ;
extern FIELD_IDX_T TransfOp_Bp8TpId                        ;
extern FIELD_IDX_T TransfOp_Bp8CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp8Amt                         ;
extern FIELD_IDX_T TransfOp_Bp9TpId                        ;
extern FIELD_IDX_T TransfOp_Bp9CurrId                      ;
extern FIELD_IDX_T TransfOp_Bp9Amt                         ;
extern FIELD_IDX_T TransfOp_Bp10TpId                       ;
extern FIELD_IDX_T TransfOp_Bp10CurrId                     ;
extern FIELD_IDX_T TransfOp_Bp10Amt                        ;
extern FIELD_IDX_T TransfOp_FlowId                         ;
extern FIELD_IDX_T TransfOp_InitExtPosId                   ;
extern FIELD_IDX_T TransfOp_LastUserId                     ;
extern FIELD_IDX_T TransfOp_LastModifDate                  ;
extern FIELD_IDX_T TransfOp_CreationTime                   ;
extern FIELD_IDX_T TransfOp_SysCurrId                      ;
extern FIELD_IDX_T TransfOp_ConfirmedFlg                   ;
extern FIELD_IDX_T TransfOp_FctResultId                    ;
extern FIELD_IDX_T TransfOp_OrderModeTypeId			       ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T TransfOp_TraderMgrId				       ;
extern FIELD_IDX_T TransfOp_AutoRenewalEn			       ;
extern FIELD_IDX_T TransfOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T TransfOp_RenewalEndValDate		       ;
extern FIELD_IDX_T TransfOp_RenewalLength			       ;
extern FIELD_IDX_T TransfOp_RenewalLengthUnitEn		       ;
extern FIELD_IDX_T TransfOp_ClientInitEn				   ;
extern FIELD_IDX_T TransfOp_ContractNumber			       ;
extern FIELD_IDX_T TransfOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T TransfOp_RenewalIntRate                 ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T TransfOp_RenewalAmount                  ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T TransfOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T TransfOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T TransfOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T TransfOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T TransfOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T TransfOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T TransfOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T TransfOp_ExtOpId                        ;
extern FIELD_IDX_T TransfOp_ExtOp_Ext                      ;
extern FIELD_IDX_T TransfOp_AutoIndex                      ;
extern FIELD_IDX_T TransfOp_ExtOpDbId                      ;
extern FIELD_IDX_T TransfOp_BeginDate                      ;
extern FIELD_IDX_T TransfOp_EndDate                        ;
extern FIELD_IDX_T TransfOp_DraftOrderId                   ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T TransfOp_Summary                        ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T TransfOp_TimeStamp                      ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T TransfOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T TransfOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T TransfOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T TransfOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T TransfOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T TransfOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T TransfOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T TransfOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T TransfOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T TransfOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T TransfOp_EventStatusId                  ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T TransfOp_EventActionEn                  ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T TransfOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T TransfOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T TransfOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T TransfOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T TransfOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T TransfOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T TransfOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T TransfOp_CommonRef                      ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T TransfOp_OrderInclusionEn               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T TransfOp_OrderRejectionDate             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T TransfOp_OrderRejectionComment          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T TransfOp_AcquisitionDate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T TransfOp_CorporateActionNatEn           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T TransfOp_TaxLotSourceCd                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T TransfOp_StandInstructId                ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T TransfOp_BankFeePrct                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T TransfOp_BankFeeAmount                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T TransfOp_BankFeeCurrId                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T TransfOp_PaymentOption                  ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T TransfOp_BidTypeEn                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid1Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid1Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid2Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid2Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid3Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_Bid3Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T TransfOp_OpFusionRuleEn                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T TransfOp_GlobalPosFlg                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T TransfOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T TransfOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T TransfOp_CoolCancelEndDate              ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T TransfOp_FusionPrioEn                   ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T TransfOp_ExternalBankBic                ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T TransfOp_ExternalBankName               ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T TransfOp_ExternalBankAcctOwnrName       ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T TransfOp_HedgeTradeEn                   ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T TransfOp_FixingDate                     ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr1         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr2         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr3         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_ExtrnlBnkAcctOwnrAddr4         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_PayRef1                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_PayRef2                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_PayRef3                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_PayRef4                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T TransfOp_ExternalTradeFlg               ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T TransfOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T TransfOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T TransfOp_PaymentDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T TransfOp_PaymentStatusEn                ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T TransfOp_SettlementDate                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T TransfOp_SettleStatusEn                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T TransfOp_CommissionCdEn                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_ChargeCdEn                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_OriginalAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_CounterpartOrgAmount           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_ExternalFeeM                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_TotalChargesM                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_CounterpartAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_OpLinkageCd                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_ChargedCustomerName            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T TransfOp_BoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_BoAccountId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_OpSplitRuleEn                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_AdjBoPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_CoaExDate                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_BoCashAcctId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_BoCashPtfId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_SplitParentOperId              ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T TransfOp_OriginalNetAmount              ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T TransfOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T TransfOp_RuleApplicabilityEn		       ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_SmartRoundingOrgQty		       ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_RoundingOrgQty			       ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_SmartRoundingRuleId		       ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T TransfOp_HierOperNatEn                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T TransfOp_HierOperationCd                ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T TransfOp_NotionalInstrId                ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T TransfOp_InvestLimitEn                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T TransfOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T TransfOp_SetOfProductFeesId             ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T TransfOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T TransfOp_OrderSubTypeId                 ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T TransfOp_SetOfOtherFeesId               ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T TransfOp_TraderThirdId                  ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T TransfOp_NetSettleAmount                ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T BpTransfOp_Id                           ;
extern FIELD_IDX_T BpTransfOp_Cd                           ;
extern FIELD_IDX_T BpTransfOp_InputUserId                  ;
extern FIELD_IDX_T BpTransfOp_TpId                         ;
extern FIELD_IDX_T BpTransfOp_SubTpId                      ;
extern FIELD_IDX_T BpTransfOp_MktThirdId                   ;
extern FIELD_IDX_T BpTransfOp_IntermThirdId                ;
extern FIELD_IDX_T BpTransfOp_MgrId                        ;
extern FIELD_IDX_T BpTransfOp_RuleId                       ;
extern FIELD_IDX_T BpTransfOp_SrcCd                        ;
extern FIELD_IDX_T BpTransfOp_ParOpCd                      ;
extern FIELD_IDX_T BpTransfOp_ParOpNatEn                   ;
extern FIELD_IDX_T BpTransfOp_CheckParentEn                ;
extern FIELD_IDX_T BpTransfOp_AcctDate                     ;
extern FIELD_IDX_T BpTransfOp_OpDate                       ;
extern FIELD_IDX_T BpTransfOp_ValuationDate                ;
extern FIELD_IDX_T BpTransfOp_ValueDate                    ;
extern FIELD_IDX_T BpTransfOp_RefOpCd                      ;
extern FIELD_IDX_T BpTransfOp_RefNatEn                     ;
extern FIELD_IDX_T BpTransfOp_StatusEn                     ;
extern FIELD_IDX_T BpTransfOp_SequenceNo                   ;
extern FIELD_IDX_T BpTransfOp_AcctCd                       ;
extern FIELD_IDX_T BpTransfOp_PtfId                        ;
extern FIELD_IDX_T BpTransfOp_PortPosSetId                 ;
extern FIELD_IDX_T BpTransfOp_InstrId                      ;
extern FIELD_IDX_T BpTransfOp_ToInstrId                    ;
extern FIELD_IDX_T BpTransfOp_FromBpTpId                   ;
extern FIELD_IDX_T BpTransfOp_ToBpTpId                     ;
extern FIELD_IDX_T BpTransfOp_PtfCurrId                    ;
extern FIELD_IDX_T BpTransfOp_InstrCurrId                  ;
extern FIELD_IDX_T BpTransfOp_ToInstrCurrId                ;
extern FIELD_IDX_T BpTransfOp_ExecOpId                     ;
extern FIELD_IDX_T BpTransfOp_ExecOpCd                     ;
extern FIELD_IDX_T BpTransfOp_ExecOpNatEn                  ;
extern FIELD_IDX_T BpTransfOp_ExecOpStatEn                 ;
extern FIELD_IDX_T BpTransfOp_RevOpCd                      ;
extern FIELD_IDX_T BpTransfOp_RevOpNatEn                   ;
extern FIELD_IDX_T BpTransfOp_FusRuleEn                    ;
extern FIELD_IDX_T BpTransfOp_Remark                       ;
extern FIELD_IDX_T BpTransfOp_SysExchRate                  ;
extern FIELD_IDX_T BpTransfOp_PtfNetAmt                    ;
extern FIELD_IDX_T BpTransfOp_SysNetAmt                    ;
extern FIELD_IDX_T BpTransfOp_FlowId                       ;
extern FIELD_IDX_T BpTransfOp_InitExtPosId                 ;
extern FIELD_IDX_T BpTransfOp_LastUserId                   ;
extern FIELD_IDX_T BpTransfOp_LastModifDate                ;
extern FIELD_IDX_T BpTransfOp_CreationTime                 ;
extern FIELD_IDX_T BpTransfOp_SysCurrId                    ;
extern FIELD_IDX_T BpTransfOp_ConfirmedFlg                 ;
extern FIELD_IDX_T BpTransfOp_FctResultId                  ;
extern FIELD_IDX_T BpTransfOp_OrderModeTypeId			   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T BpTransfOp_TraderMgrId				   ;
extern FIELD_IDX_T BpTransfOp_AutoRenewalEn			       ;
extern FIELD_IDX_T BpTransfOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T BpTransfOp_RenewalEndValDate		       ;
extern FIELD_IDX_T BpTransfOp_RenewalLength			       ;
extern FIELD_IDX_T BpTransfOp_RenewalLengthUnitEn		   ;
extern FIELD_IDX_T BpTransfOp_ClientInitEn				   ;
extern FIELD_IDX_T BpTransfOp_ContractNumber			   ;
extern FIELD_IDX_T BpTransfOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T BpTransfOp_RenewalIntRate               ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BpTransfOp_RenewalAmount                ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BpTransfOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BpTransfOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BpTransfOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BpTransfOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BpTransfOp_FxMarginNumber                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BpTransfOp_FxMarginPrct                       ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BpTransfOp_FxMarginAmount                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BpTransfOp_ExtOpId                      ;
extern FIELD_IDX_T BpTransfOp_ExtOp_Ext                    ;
extern FIELD_IDX_T BpTransfOp_AutoIndex                    ;
extern FIELD_IDX_T BpTransfOp_ExtOpDbId                    ;
extern FIELD_IDX_T BpTransfOp_BeginDate                    ;
extern FIELD_IDX_T BpTransfOp_EndDate                      ;
extern FIELD_IDX_T BpTransfOp_DraftOrderId                 ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T BpTransfOp_Summary                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BpTransfOp_TimeStamp                    ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T BpTransfOp_DerivativeOrdEn			   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T BpTransfOp_FxFarLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BpTransfOp_FxSpotQuote				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BpTransfOp_FxQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BpTransfOp_FxSpotLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BpTransfOp_OrderFeeEn				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BpTransfOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BpTransfOp_MaxOrderQty				   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T BpTransfOp_STPOrderEn				   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T BpTransfOp_UnpaidPrct				   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T BpTransfOp_EventStatusId                ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T BpTransfOp_EventActionEn                ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T BpTransfOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BpTransfOp_CompoundOrderSlaveEltId	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BpTransfOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BpTransfOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BpTransfOp_CompoundImpactRule		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BpTransfOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BpTransfOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BpTransfOp_CommonRef                    ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T BpTransfOp_OrderInclusionEn             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BpTransfOp_OrderRejectionDate           ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BpTransfOp_OrderRejectionComment        ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BpTransfOp_AcquisitionDate              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BpTransfOp_CorporateActionNatEn         ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BpTransfOp_TaxLotSourceCd               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BpTransfOp_StandInstructId              ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T BpTransfOp_BankFeePrct                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BpTransfOp_BankFeeAmount                ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BpTransfOp_BankFeeCurrId                ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BpTransfOp_PaymentOption                ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T BpTransfOp_BidTypeEn                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid1Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid1Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid2Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid2Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid3Qty                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_Bid3Quote                    ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BpTransfOp_OpFusionRuleEn               ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BpTransfOp_GlobalPosFlg                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BpTransfOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BpTransfOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BpTransfOp_CoolCancelEndDate            ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T BpTransfOp_FusionPrioEn                 ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T BpTransfOp_ExternalBankBic              ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BpTransfOp_ExternalBankName             ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BpTransfOp_ExternalBankAcctOwnrName     ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BpTransfOp_HedgeTradeEn                 ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T BpTransfOp_FixingDate                   ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr1       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr2       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr3       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_ExtrnlBnkAcctOwnrAddr4       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_PayRef1                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_PayRef2                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_PayRef3                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_PayRef4                      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BpTransfOp_ExternalTradeFlg             ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T BpTransfOp_OriginalQty				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BpTransfOp_OrderNettingEn			   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BpTransfOp_PaymentDate                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BpTransfOp_PaymentStatusEn              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BpTransfOp_SettlementDate               ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BpTransfOp_SettleStatusEn               ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BpTransfOp_CommissionCdEn               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_ChargeCdEn                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_OriginalAmount               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_CounterpartOrgAmount         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_ExternalFeeM                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_TotalChargesM                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_CounterpartAmount            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_OpLinkageCd                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_ChargedCustomerName          ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BpTransfOp_BoPtfId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_BoAccountId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_OpSplitRuleEn                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_AdjBoPtfId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_CoaExDate                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_BoCashAcctId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_BoCashPtfId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_SplitParentOperId            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BpTransfOp_OriginalNetAmount            ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T BpTransfOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T BpTransfOp_RuleApplicabilityEn		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_SmartRoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_RoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_SmartRoundingRuleId		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BpTransfOp_HierOperNatEn                ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BpTransfOp_HierOperationCd              ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BpTransfOp_NotionalInstrId              ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BpTransfOp_InvestLimitEn                ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BpTransfOp_OrderSubTypeId               ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T BpTransfOp_SetOfOtherFeesId             ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T BpTransfOp_TraderThirdId                ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T BpTransfOp_NetSettleAmount              ; /* WEALTH-9095 - SENTHIL - 20240529 */

extern FIELD_IDX_T AdjustOp_Id                             ;
extern FIELD_IDX_T AdjustOp_Cd                             ;
extern FIELD_IDX_T AdjustOp_InputUserId                    ;
extern FIELD_IDX_T AdjustOp_TpId                           ;
extern FIELD_IDX_T AdjustOp_SubTpId                        ;
extern FIELD_IDX_T AdjustOp_MktThirdId                     ;
extern FIELD_IDX_T AdjustOp_IntermThirdId                  ;
extern FIELD_IDX_T AdjustOp_MgrId                          ;
extern FIELD_IDX_T AdjustOp_RuleId                         ;
extern FIELD_IDX_T AdjustOp_SrcCd                          ;
extern FIELD_IDX_T AdjustOp_SubPosNatEn                    ;
extern FIELD_IDX_T AdjustOp_SubPosNat2En                   ;
extern FIELD_IDX_T AdjustOp_SubPosNat3En                   ;
extern FIELD_IDX_T AdjustOp_AdjSubPosNatEn                 ;
extern FIELD_IDX_T AdjustOp_AdjSubPosNat2En                ;
extern FIELD_IDX_T AdjustOp_AdjSubPosNat3En                ;
extern FIELD_IDX_T AdjustOp_LockSubPosNatEn                ;
extern FIELD_IDX_T AdjustOp_LockSubPosNat2En               ;
extern FIELD_IDX_T AdjustOp_LockSubPosNat3En               ;
extern FIELD_IDX_T AdjustOp_ParOpCd                        ;
extern FIELD_IDX_T AdjustOp_ParOpNatEn                     ;
extern FIELD_IDX_T AdjustOp_CheckParentEn                  ;
extern FIELD_IDX_T AdjustOp_AcctDate                       ;
extern FIELD_IDX_T AdjustOp_OpDate                         ;
extern FIELD_IDX_T AdjustOp_ValuationDate                  ;
extern FIELD_IDX_T AdjustOp_ValueDate                      ;
extern FIELD_IDX_T AdjustOp_RefOpCd                        ;
extern FIELD_IDX_T AdjustOp_RefNatEn                       ;
extern FIELD_IDX_T AdjustOp_StatusEn                       ;
extern FIELD_IDX_T AdjustOp_SequenceNo                     ;
extern FIELD_IDX_T AdjustOp_AcctCd                         ;
extern FIELD_IDX_T AdjustOp_PtfId                          ;
extern FIELD_IDX_T AdjustOp_CashPtfId                      ;
extern FIELD_IDX_T AdjustOp_InstrId                        ;
extern FIELD_IDX_T AdjustOp_AcctId                         ;
extern FIELD_IDX_T AdjustOp_Acct2Id                        ;
extern FIELD_IDX_T AdjustOp_Acct3Id                        ;
extern FIELD_IDX_T AdjustOp_LockInstrId                    ;
extern FIELD_IDX_T AdjustOp_DepoId                         ;
extern FIELD_IDX_T AdjustOp_LockDepoId                     ;
extern FIELD_IDX_T AdjustOp_AdjInstrId                     ;
extern FIELD_IDX_T AdjustOp_AdjDepoId                      ;
extern FIELD_IDX_T AdjustOp_AdjBpTpId                      ;
extern FIELD_IDX_T AdjustOp_OpCurrId                       ;
extern FIELD_IDX_T AdjustOp_InstrCurrId                    ;
extern FIELD_IDX_T AdjustOp_PtfCurrId                      ;
extern FIELD_IDX_T AdjustOp_AcctCurrId                     ;
extern FIELD_IDX_T AdjustOp_Acct2CurrId                    ;
extern FIELD_IDX_T AdjustOp_Acct3CurrId                    ;
extern FIELD_IDX_T AdjustOp_TradeCurrId                    ;
extern FIELD_IDX_T AdjustOp_CashPtfCurrId                  ;
extern FIELD_IDX_T AdjustOp_AdjInstrCurrId                 ;
extern FIELD_IDX_T AdjustOp_AdjPosCurrId                   ;
extern FIELD_IDX_T AdjustOp_LockOpCurrId                   ;
extern FIELD_IDX_T AdjustOp_LockFiCurrId                   ;
extern FIELD_IDX_T AdjustOp_CntPtyThirdId                  ;
extern FIELD_IDX_T AdjustOp_TermTpId                       ;
extern FIELD_IDX_T AdjustOp_LockTpId                       ;
extern FIELD_IDX_T AdjustOp_AccrIntrBpTpId                 ;
extern FIELD_IDX_T AdjustOp_AdjNatEn                       ;
extern FIELD_IDX_T AdjustOp_ExecOpId                       ;
extern FIELD_IDX_T AdjustOp_ExecOpCd                       ;
extern FIELD_IDX_T AdjustOp_ExecOpNatEn                    ;
extern FIELD_IDX_T AdjustOp_ExecOpStatEn                   ;
extern FIELD_IDX_T AdjustOp_RevOpCd                        ;
extern FIELD_IDX_T AdjustOp_RevOpNatEn                     ;
extern FIELD_IDX_T AdjustOp_LockOpCd                       ;
extern FIELD_IDX_T AdjustOp_LockNatEn                      ;
extern FIELD_IDX_T AdjustOp_EvtCd                          ;
extern FIELD_IDX_T AdjustOp_EvtNbr                         ;
extern FIELD_IDX_T AdjustOp_ExCouponFlg                    ;
extern FIELD_IDX_T AdjustOp_FusRuleEn                      ;
extern FIELD_IDX_T AdjustOp_LockLimitDate                  ;
extern FIELD_IDX_T AdjustOp_ExpirDate                      ;
extern FIELD_IDX_T AdjustOp_Remark                         ;
extern FIELD_IDX_T AdjustOp_OpExchRate                     ;
extern FIELD_IDX_T AdjustOp_InstrExchRate                  ;
extern FIELD_IDX_T AdjustOp_SysExchRate                    ;
extern FIELD_IDX_T AdjustOp_AcctExchRate                   ;
extern FIELD_IDX_T AdjustOp_Acct2ExchRate                  ;
extern FIELD_IDX_T AdjustOp_Acct3ExchRate                  ;
extern FIELD_IDX_T AdjustOp_TradeExchRate                  ;
extern FIELD_IDX_T AdjustOp_CashPtfExchRate                ;
extern FIELD_IDX_T AdjustOp_AdjInstrExchRate               ;
extern FIELD_IDX_T AdjustOp_AdjPosExchRate                 ;
extern FIELD_IDX_T AdjustOp_LockOpExchRate                 ;
extern FIELD_IDX_T AdjustOp_LockFiExchRate                 ;
extern FIELD_IDX_T AdjustOp_AdjQty                         ;
extern FIELD_IDX_T AdjustOp_Qty                            ;
extern FIELD_IDX_T AdjustOp_LockQty                        ;
extern FIELD_IDX_T AdjustOp_Price                          ;
extern FIELD_IDX_T AdjustOp_SpotPrice                      ;
extern FIELD_IDX_T AdjustOp_LockDirtyPrice                 ;
extern FIELD_IDX_T AdjustOp_LockCleanPrice                 ;
extern FIELD_IDX_T AdjustOp_PriceCalcRuleEn                ;
extern FIELD_IDX_T AdjustOp_Quote                          ;
extern FIELD_IDX_T AdjustOp_SpotQuote                      ;
extern FIELD_IDX_T AdjustOp_LockDirtyQuote                 ;
extern FIELD_IDX_T AdjustOp_LockCleanQuote                 ;
extern FIELD_IDX_T AdjustOp_Rate                           ;
extern FIELD_IDX_T AdjustOp_LockPriceMargin                ;
extern FIELD_IDX_T AdjustOp_SupplAmt                       ;
extern FIELD_IDX_T AdjustOp_OpGrossAmt                     ;
extern FIELD_IDX_T AdjustOp_AccrIntrAmt                    ;
extern FIELD_IDX_T AdjustOp_OpNetAmt                       ;
extern FIELD_IDX_T AdjustOp_InstrNetAmt                    ;
extern FIELD_IDX_T AdjustOp_PtfNetAmt                      ;
extern FIELD_IDX_T AdjustOp_SysNetAmt                      ;
extern FIELD_IDX_T AdjustOp_AcctNetAmt                     ;
extern FIELD_IDX_T AdjustOp_Acct2NetAmt                    ;
extern FIELD_IDX_T AdjustOp_Acct3NetAmt                    ;
extern FIELD_IDX_T AdjustOp_Bp1TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp1CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp1Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp2TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp2CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp2Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp3TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp3CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp3Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp4TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp4CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp4Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp5TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp5CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp5Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp6TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp6CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp6Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp7TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp7CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp7Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp8TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp8CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp8Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp9TpId                        ;
extern FIELD_IDX_T AdjustOp_Bp9CurrId                      ;
extern FIELD_IDX_T AdjustOp_Bp9Amt                         ;
extern FIELD_IDX_T AdjustOp_Bp10TpId                       ;
extern FIELD_IDX_T AdjustOp_Bp10CurrId                     ;
extern FIELD_IDX_T AdjustOp_Bp10Amt                        ;
extern FIELD_IDX_T AdjustOp_FlowId                         ;
extern FIELD_IDX_T AdjustOp_InitExtPosId                   ;
extern FIELD_IDX_T AdjustOp_LastUserId                     ;
extern FIELD_IDX_T AdjustOp_LastModifDate                  ;
extern FIELD_IDX_T AdjustOp_CreationTime                   ;
extern FIELD_IDX_T AdjustOp_SysCurrId                      ;
extern FIELD_IDX_T AdjustOp_ConfirmedFlg                   ;
extern FIELD_IDX_T AdjustOp_FctResultId                    ;
extern FIELD_IDX_T AdjustOp_OrderModeTypeId			       ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T AdjustOp_TraderMgrId				       ;
extern FIELD_IDX_T AdjustOp_AutoRenewalEn			       ;
extern FIELD_IDX_T AdjustOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T AdjustOp_RenewalEndValDate		       ;
extern FIELD_IDX_T AdjustOp_RenewalLength			       ;
extern FIELD_IDX_T AdjustOp_RenewalLengthUnitEn		       ;
extern FIELD_IDX_T AdjustOp_ClientInitEn				   ;
extern FIELD_IDX_T AdjustOp_ContractNumber			       ;
extern FIELD_IDX_T AdjustOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T AdjustOp_RenewalIntRate                 ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T AdjustOp_RenewalAmount                  ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T AdjustOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T AdjustOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T AdjustOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T AdjustOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T AdjustOp_FxMarginNumber                 ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T AdjustOp_FxMarginPrct                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T AdjustOp_FxMarginAmount                 ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T AdjustOp_ExtOpId                        ;
extern FIELD_IDX_T AdjustOp_ExtOp_Ext                      ;
extern FIELD_IDX_T AdjustOp_AutoIndex                      ;
extern FIELD_IDX_T AdjustOp_ExtOpDbId                      ;
extern FIELD_IDX_T AdjustOp_BeginDate                      ;
extern FIELD_IDX_T AdjustOp_EndDate                        ;
extern FIELD_IDX_T AdjustOp_DraftOrderId                   ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T AdjustOp_Summary                        ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T AdjustOp_TimeStamp                      ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T AdjustOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T AdjustOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T AdjustOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T AdjustOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T AdjustOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T AdjustOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T AdjustOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T AdjustOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T AdjustOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T AdjustOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T AdjustOp_EventStatusId                  ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T AdjustOp_EventActionEn                  ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T AdjustOp_CompoundOrderMasterEltId	   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T AdjustOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T AdjustOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T AdjustOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T AdjustOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T AdjustOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T AdjustOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T AdjustOp_CommonRef                      ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T AdjustOp_OrderInclusionEn               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T AdjustOp_OrderRejectionDate             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T AdjustOp_OrderRejectionComment          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T AdjustOp_AcquisitionDate                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T AdjustOp_CorporateActionNatEn           ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T AdjustOp_TaxLotSourceCd                 ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T AdjustOp_StandInstructId                ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T AdjustOp_BankFeePrct                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T AdjustOp_BankFeeAmount                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T AdjustOp_BankFeeCurrId                  ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T AdjustOp_PaymentOption                  ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T AdjustOp_BidTypeEn                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid1Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid1Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid2Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid2Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid3Qty                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_Bid3Quote                      ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T AdjustOp_OpFusionRuleEn                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T AdjustOp_GlobalPosFlg                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T AdjustOp_AdjPosGrossAmt                 ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T AdjustOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T AdjustOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T AdjustOp_CoolCancelEndDate              ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T AdjustOp_FusionPrioEn                   ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T AdjustOp_ExternalBankBic                ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T AdjustOp_ExternalBankName               ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T AdjustOp_ExternalBankAcctOwnrName       ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T AdjustOp_HedgeTradeEn                   ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T AdjustOp_FixingDate                     ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr1         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr2         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr3         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_ExtrnlBnkAcctOwnrAddr4         ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_PayRef1                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_PayRef2                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_PayRef3                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_PayRef4                        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T AdjustOp_ExternalTradeFlg               ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T AdjustOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T AdjustOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T AdjustOp_PaymentDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T AdjustOp_PaymentStatusEn                ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T AdjustOp_SettlementDate                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T AdjustOp_SettleStatusEn                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T AdjustOp_CommissionCdEn                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_ChargeCdEn                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_OriginalAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_CounterpartOrgAmount           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_ExternalFeeM                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_TotalChargesM                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_CounterpartAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_OpLinkageCd                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_ChargedCustomerName            ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T AdjustOp_BoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_BoAccountId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_OpSplitRuleEn                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_AdjBoPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_CoaExDate                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_BoCashAcctId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_BoCashPtfId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_SplitParentOperId              ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T AdjustOp_OriginalNetAmount              ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T AdjustOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T AdjustOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T AdjustOp_HierOperNatEn                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T AdjustOp_HierOperationCd                ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T AdjustOp_NotionalInstrId                ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T AdjustOp_InvestLimitEn                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T AdjustOp_AdjRefNatEn                    ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T AdjustOp_AdjRefOperCd                   ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T AdjustOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T AdjustOp_SetOfProductFeesId			   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T AdjustOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T AdjustOp_OrderSubTypeId                 ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T AdjustOp_SetOfOtherFeesId               ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T AdjustOp_TraderThirdId                  ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T AdjustOp_NetSettleAmount                ; /* WEALTH-9095 - SENTHIL - 20240529 */


extern FIELD_IDX_T FtOp_Id                                 ;
extern FIELD_IDX_T FtOp_Cd                                 ;
extern FIELD_IDX_T FtOp_InputUserId                        ;
extern FIELD_IDX_T FtOp_TpId                               ;
extern FIELD_IDX_T FtOp_SubTpId                            ;
extern FIELD_IDX_T FtOp_MktThirdId                         ;
extern FIELD_IDX_T FtOp_IntermThirdId                      ;
extern FIELD_IDX_T FtOp_MgrId                              ;
extern FIELD_IDX_T FtOp_RuleId                             ;
extern FIELD_IDX_T FtOp_SrcCd                              ;
extern FIELD_IDX_T FtOp_ParOpCd                            ;
extern FIELD_IDX_T FtOp_ParOpNatEn                         ;
extern FIELD_IDX_T FtOp_CheckParentEn                      ;
extern FIELD_IDX_T FtOp_AcctDate                           ;
extern FIELD_IDX_T FtOp_OpDate                             ;
extern FIELD_IDX_T FtOp_ValueDate                          ;
extern FIELD_IDX_T FtOp_RefOpCd                            ;
extern FIELD_IDX_T FtOp_RefNatEn                           ;
extern FIELD_IDX_T FtOp_StatusEn                           ;
extern FIELD_IDX_T FtOp_SequenceNo                         ;
extern FIELD_IDX_T FtOp_AcctCd                             ;
extern FIELD_IDX_T FtOp_PtfId                              ;
extern FIELD_IDX_T FtOp_DepoId                             ;
extern FIELD_IDX_T FtOp_CashPtfId                          ;
extern FIELD_IDX_T FtOp_AcctId                             ;
extern FIELD_IDX_T FtOp_Acct2Id                            ;
extern FIELD_IDX_T FtOp_Acct3Id                            ;
extern FIELD_IDX_T FtOp_BpTpId                             ;
extern FIELD_IDX_T FtOp_OpCurrId                           ;
extern FIELD_IDX_T FtOp_PtfCurrId                          ;
extern FIELD_IDX_T FtOp_AcctCurrId                         ;
extern FIELD_IDX_T FtOp_Acct2CurrId                        ;
extern FIELD_IDX_T FtOp_Acct3CurrId                        ;
extern FIELD_IDX_T FtOp_CashPtfCurrId                      ;
extern FIELD_IDX_T FtOp_CntPtyThirdId                      ;
extern FIELD_IDX_T FtOp_ExecOpId                           ;
extern FIELD_IDX_T FtOp_ExecOpCd                           ;
extern FIELD_IDX_T FtOp_ExecOpNatEn                        ;
extern FIELD_IDX_T FtOp_ExecOpStatEn                       ;
extern FIELD_IDX_T FtOp_RevOpCd                            ;
extern FIELD_IDX_T FtOp_RevOpNatEn                         ;
extern FIELD_IDX_T FtOp_EvtCd                              ;
extern FIELD_IDX_T FtOp_EvtNbr                             ;
extern FIELD_IDX_T FtOp_FusRuleEn                          ;
extern FIELD_IDX_T FtOp_Remark                             ;
extern FIELD_IDX_T FtOp_OpExchRate                         ;
extern FIELD_IDX_T FtOp_SysExchRate                        ;
extern FIELD_IDX_T FtOp_AcctExchRate                       ;
extern FIELD_IDX_T FtOp_Acct2ExchRate                      ;
extern FIELD_IDX_T FtOp_Acct3ExchRate                      ;
extern FIELD_IDX_T FtOp_CashPtfExchRate                    ;
extern FIELD_IDX_T FtOp_OpNetAmt                           ;
extern FIELD_IDX_T FtOp_OpGrossAmt                         ;
extern FIELD_IDX_T FtOp_PtfNetAmt                          ;
extern FIELD_IDX_T FtOp_SysNetAmt                          ;
extern FIELD_IDX_T FtOp_AcctNetAmt                         ;
extern FIELD_IDX_T FtOp_Acct2NetAmt                        ;
extern FIELD_IDX_T FtOp_Acct3NetAmt                        ;
extern FIELD_IDX_T FtOp_Bp1TpId                            ;
extern FIELD_IDX_T FtOp_Bp1CurrId                          ;
extern FIELD_IDX_T FtOp_Bp1Amt                             ;
extern FIELD_IDX_T FtOp_Bp2TpId                            ;
extern FIELD_IDX_T FtOp_Bp2CurrId                          ;
extern FIELD_IDX_T FtOp_Bp2Amt                             ;
extern FIELD_IDX_T FtOp_Bp3TpId                            ;
extern FIELD_IDX_T FtOp_Bp3CurrId                          ;
extern FIELD_IDX_T FtOp_Bp3Amt                             ;
extern FIELD_IDX_T FtOp_Bp4TpId                            ;
extern FIELD_IDX_T FtOp_Bp4CurrId                          ;
extern FIELD_IDX_T FtOp_Bp4Amt                             ;
extern FIELD_IDX_T FtOp_Bp5TpId                            ;
extern FIELD_IDX_T FtOp_Bp5CurrId                          ;
extern FIELD_IDX_T FtOp_Bp5Amt                             ;
extern FIELD_IDX_T FtOp_Bp6TpId                            ;
extern FIELD_IDX_T FtOp_Bp6CurrId                          ;
extern FIELD_IDX_T FtOp_Bp6Amt                             ;
extern FIELD_IDX_T FtOp_Bp7TpId                            ;
extern FIELD_IDX_T FtOp_Bp7CurrId                          ;
extern FIELD_IDX_T FtOp_Bp7Amt                             ;
extern FIELD_IDX_T FtOp_Bp8TpId                            ;
extern FIELD_IDX_T FtOp_Bp8CurrId                          ;
extern FIELD_IDX_T FtOp_Bp8Amt                             ;
extern FIELD_IDX_T FtOp_Bp9TpId                            ;
extern FIELD_IDX_T FtOp_Bp9CurrId                          ;
extern FIELD_IDX_T FtOp_Bp9Amt                             ;
extern FIELD_IDX_T FtOp_Bp10TpId                           ;
extern FIELD_IDX_T FtOp_Bp10CurrId                         ;
extern FIELD_IDX_T FtOp_Bp10Amt                            ;
extern FIELD_IDX_T FtOp_FlowId                             ;
extern FIELD_IDX_T FtOp_InitExtPosId                       ;
extern FIELD_IDX_T FtOp_LastUserId                         ;
extern FIELD_IDX_T FtOp_LastModifDate                      ;
extern FIELD_IDX_T FtOp_CreationTime                       ;
extern FIELD_IDX_T FtOp_SysCurrId                          ;
extern FIELD_IDX_T FtOp_ConfirmedFlg                       ;
extern FIELD_IDX_T FtOp_FctResultId                        ;
extern FIELD_IDX_T FtOp_OrderModeTypeId					   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T FtOp_TraderMgrId				       	   ;
extern FIELD_IDX_T FtOp_AutoRenewalEn			       	   ;
extern FIELD_IDX_T FtOp_RenewalTreatmtEn			   	   ;
extern FIELD_IDX_T FtOp_RenewalEndValDate		       	   ;
extern FIELD_IDX_T FtOp_RenewalLength			       	   ;
extern FIELD_IDX_T FtOp_RenewalLengthUnitEn		       	   ;
extern FIELD_IDX_T FtOp_ClientInitEn				   	   ;
extern FIELD_IDX_T FtOp_ContractNumber			       	   ;
extern FIELD_IDX_T FtOp_TransactionNatEn			   	   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T FtOp_RenewalIntRate                     ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T FtOp_RenewalAmount                      ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T FtOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T FtOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T FtOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T FtOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T FtOp_FxMarginNumber                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T FtOp_FxMarginPrct                       ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T FtOp_FxMarginAmount                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T FtOp_ExtOpId                            ;
extern FIELD_IDX_T FtOp_ExtOp_Ext                          ;
extern FIELD_IDX_T FtOp_AutoIndex                          ;
extern FIELD_IDX_T FtOp_ExtOpDbId                          ;
extern FIELD_IDX_T FtOp_BeginDate                          ;
extern FIELD_IDX_T FtOp_EndDate                            ;
extern FIELD_IDX_T FtOp_DraftOrderId                       ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T FtOp_Summary                            ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T FtOp_TimeStamp                          ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T FtOp_DerivativeOrdEn					   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T FtOp_FxFarLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T FtOp_FxSpotQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T FtOp_FxQuote							   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T FtOp_FxSpotLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T FtOp_OrderFeeEn						   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T FtOp_OrderFeePrct					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T FtOp_MaxOrderQty						   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T FtOp_STPOrderEn						   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T FtOp_UnpaidPrct						   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T FtOp_EventStatusId                      ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T FtOp_EventActionEn                      ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T FtOp_CompoundOrderMasterEltId			;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T FtOp_CompoundOrderSlaveEltId				; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T FtOp_CompoundOrderCode					; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T FtOp_CompoundOrderSlaveNbr				; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T FtOp_CompoundImpactRule					; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T FtOp_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T FtOp_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T FtOp_CommonRef                          ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T FtOp_OrderInclusionEn                   ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T FtOp_OrderRejectionDate                 ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T FtOp_OrderRejectionComment              ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T FtOp_AcquisitionDate                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T FtOp_CorporateActionNatEn               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T FtOp_TaxLotSourceCd                     ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T FtOp_StandInstructId                    ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T FtOp_BankFeePrct                        ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T FtOp_BankFeeAmount                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T FtOp_BankFeeCurrId                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T FtOp_PaymentOption                      ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T FtOp_BidTypeEn                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid1Qty                            ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid1Quote                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid2Qty                            ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid2Quote                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid3Qty                            ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_Bid3Quote                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T FtOp_OpFusionRuleEn                     ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T FtOp_GlobalPosFlg                       ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T FtOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T FtOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T FtOp_CoolCancelEndDate                  ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T FtOp_FusionPrioEn                       ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T FtOp_ExternalBankBic                    ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T FtOp_ExternalBankName                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T FtOp_ExternalBankAcctOwnrName           ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T FtOp_HedgeTradeEn                       ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T FtOp_FixingDate                         ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr1             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr2             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr3             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_ExtrnlBnkAcctOwnrAddr4             ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_PayRef1                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_PayRef2                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_PayRef3                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_PayRef4                            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T FtOp_ExternalTradeFlg                   ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T FtOp_OriginalQty						   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T FtOp_OrderNettingEn					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T FtOp_PaymentDate                        ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T FtOp_PaymentStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T FtOp_SettlementDate                     ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T FtOp_SettleStatusEn                     ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T FtOp_CommissionCdEn                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_ChargeCdEn                         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_OriginalAmount                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_CounterpartOrgAmount               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_ExternalFeeM                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_TotalChargesM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_CounterpartAmount                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_OpLinkageCd                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_ChargedCustomerName                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T FtOp_BoPtfId                            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_BoAccountId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_OpSplitRuleEn                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_AdjBoPtfId                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_CoaExDate                          ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_BoCashAcctId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_BoCashPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_SplitParentOperId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T FtOp_OriginalNetAmount                  ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T FtOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T FtOp_RuleApplicabilityEn                ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_SmartRoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_RoundingOrgQty					   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_SmartRoundingRuleId				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T FtOp_HierOperNatEn                      ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T FtOp_HierOperationCd                    ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T FtOp_NotionalInstrId                    ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T FtOp_InvestLimitEn                      ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T FtOp_SetOfFeesId						   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T FtOp_SetOfProductFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T FtOp_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T FtOp_OrderSubTypeId                     ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T FtOp_SetOfOtherFeesId                   ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T FtOp_TraderThirdId                      ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T FtOp_NetSettleAmount                    ; /* WEALTH-9095 - SENTHIL - 20240529 */

extern FIELD_IDX_T LockOp_Id                               ;
extern FIELD_IDX_T LockOp_Cd                               ;
extern FIELD_IDX_T LockOp_InputUserId                      ;
extern FIELD_IDX_T LockOp_TpId                             ;
extern FIELD_IDX_T LockOp_SubTpId                          ;
extern FIELD_IDX_T LockOp_MktThirdId                       ;
extern FIELD_IDX_T LockOp_IntermThirdId                    ;
extern FIELD_IDX_T LockOp_MgrId                            ;
extern FIELD_IDX_T LockOp_RuleId                           ;
extern FIELD_IDX_T LockOp_SrcCd                            ;
extern FIELD_IDX_T LockOp_SubPosNatEn                      ;
extern FIELD_IDX_T LockOp_SubPosNat2En                     ;
extern FIELD_IDX_T LockOp_SubPosNat3En                     ;
extern FIELD_IDX_T LockOp_ParOpCd                          ;
extern FIELD_IDX_T LockOp_ParOpNatEn                       ;
extern FIELD_IDX_T LockOp_CheckParentEn                    ;
extern FIELD_IDX_T LockOp_AcctDate                         ;
extern FIELD_IDX_T LockOp_OpDate                           ;
extern FIELD_IDX_T LockOp_ValueDate                        ;
extern FIELD_IDX_T LockOp_LockingLimitDate                 ;
extern FIELD_IDX_T LockOp_RefOpCd                          ;
extern FIELD_IDX_T LockOp_RefNatEn                         ;
extern FIELD_IDX_T LockOp_StatusEn                         ;
extern FIELD_IDX_T LockOp_SequenceNo                       ;
extern FIELD_IDX_T LockOp_AcctCd                           ;
extern FIELD_IDX_T LockOp_PtfId                            ;
extern FIELD_IDX_T LockOp_InstrId                          ;
extern FIELD_IDX_T LockOp_DepoId                           ;
extern FIELD_IDX_T LockOp_OpCurrId                         ;
extern FIELD_IDX_T LockOp_InstrCurrId                      ;
extern FIELD_IDX_T LockOp_PtfCurrId                        ;
extern FIELD_IDX_T LockOp_CntPtyThirdId                    ;
extern FIELD_IDX_T LockOp_LockTpId                         ;
extern FIELD_IDX_T LockOp_ExecOpId                         ;
extern FIELD_IDX_T LockOp_ExecOpCd                         ;
extern FIELD_IDX_T LockOp_ExecOpNatEn                      ;
extern FIELD_IDX_T LockOp_ExecOpStatEn                     ;
extern FIELD_IDX_T LockOp_RevOpCd                          ;
extern FIELD_IDX_T LockOp_RevOpNatEn                       ;
extern FIELD_IDX_T LockOp_LockOpCd                         ;
extern FIELD_IDX_T LockOp_LockNatEn                        ;
extern FIELD_IDX_T LockOp_EvtCd                            ;
extern FIELD_IDX_T LockOp_EvtNbr                           ;
extern FIELD_IDX_T LockOp_FusRuleEn                        ;
extern FIELD_IDX_T LockOp_Remark                           ;
extern FIELD_IDX_T LockOp_Qty                              ;
extern FIELD_IDX_T LockOp_FlowId                           ;
extern FIELD_IDX_T LockOp_InitExtPosId                     ;
extern FIELD_IDX_T LockOp_LastUserId                       ;
extern FIELD_IDX_T LockOp_LastModifDate                    ;
extern FIELD_IDX_T LockOp_CreationTime                     ;
extern FIELD_IDX_T LockOp_SysCurrId                        ;
extern FIELD_IDX_T LockOp_ConfirmedFlg                     ;
extern FIELD_IDX_T LockOp_FctResultId                      ;
extern FIELD_IDX_T LockOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T LockOp_TraderMgrId				       ;
extern FIELD_IDX_T LockOp_AutoRenewalEn			       	   ;
extern FIELD_IDX_T LockOp_RenewalTreatmtEn			   	   ;
extern FIELD_IDX_T LockOp_RenewalEndValDate		       	   ;
extern FIELD_IDX_T LockOp_RenewalLength			       	   ;
extern FIELD_IDX_T LockOp_RenewalLengthUnitEn		       ;
extern FIELD_IDX_T LockOp_ClientInitEn				   	   ;
extern FIELD_IDX_T LockOp_ContractNumber			       ;
extern FIELD_IDX_T LockOp_TransactionNatEn			   	   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T LockOp_RenewalIntRate                   ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T LockOp_RenewalAmount                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T LockOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T LockOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T LockOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T LockOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T LockOp_FxMarginNumber                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T LockOp_FxMarginPrct                       ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T LockOp_FxMarginAmount                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T LockOp_ExtOpId                          ;
extern FIELD_IDX_T LockOp_ExtOp_Ext                        ;
extern FIELD_IDX_T LockOp_AutoIndex                        ;
extern FIELD_IDX_T LockOp_ExtOpDbId                        ;
extern FIELD_IDX_T LockOp_BeginDate                        ;
extern FIELD_IDX_T LockOp_EndDate                          ;
extern FIELD_IDX_T LockOp_DraftOrderId                     ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T LockOp_Summary                          ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T LockOp_TimeStamp                        ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T LockOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T LockOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T LockOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T LockOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T LockOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T LockOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T LockOp_OrderFeePrct					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T LockOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T LockOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T LockOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T LockOp_EventStatusId                    ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T LockOp_EventActionEn                    ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T LockOp_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T LockOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T LockOp_CompoundOrderCode			       ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T LockOp_CompoundOrderSlaveNbr		       ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T LockOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T LockOp_DisplayCondition				;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T LockOp_OrderType						;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T LockOp_CommonRef                        ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T LockOp_OrderInclusionEn                 ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T LockOp_OrderRejectionDate               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T LockOp_OrderRejectionComment            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T LockOp_AcquisitionDate                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T LockOp_CorporateActionNatEn             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T LockOp_TaxLotSourceCd                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T LockOp_StandInstructId                  ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T LockOp_BankFeePrct                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T LockOp_BankFeeAmount                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T LockOp_BankFeeCurrId                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T LockOp_PaymentOption                    ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T LockOp_BidTypeEn                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid1Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid1Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid2Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid2Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid3Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_Bid3Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T LockOp_OpFusionRuleEn                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T LockOp_GlobalPosFlg                     ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T LockOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T LockOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T LockOp_CoolCancelEndDate                ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T LockOp_FusionPrioEn                      ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T LockOp_ExternalBankBic                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T LockOp_ExternalBankName                 ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T LockOp_ExternalBankAcctOwnrName         ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T LockOp_HedgeTradeEn                     ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T LockOp_FixingDate                       ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr1           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr2           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr3           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_ExtrnlBnkAcctOwnrAddr4           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_PayRef1                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_PayRef2                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_PayRef3                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_PayRef4                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T LockOp_ExternalTradeFlg                 ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T LockOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T LockOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T LockOp_PaymentDate                      ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T LockOp_PaymentStatusEn                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T LockOp_SettlementDate                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T LockOp_SettleStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T LockOp_CommissionCdEn                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_ChargeCdEn                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_OriginalAmount                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_CounterpartOrgAmount             ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_ExternalFeeM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_TotalChargesM                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_CounterpartAmount                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_OpLinkageCd                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_ChargedCustomerName              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T LockOp_BoPtfId                          ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_BoAccountId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_OpSplitRuleEn                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_AdjBoPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_CoaExDate                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_BoCashAcctId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_BoCashPtfId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_SplitParentOperId                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T LockOp_OriginalNetAmount                ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T LockOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T LockOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T LockOp_HierOperNatEn                    ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T LockOp_HierOperationCd                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T LockOp_NotionalInstrId                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T LockOp_InvestLimitEn                    ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T LockOp_OrderSubTypeId                   ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T LockOp_SetOfOtherFeesId                 ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T LockOp_TraderThirdId                    ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T LockOp_NetSettleAmount                  ; /* WEALTH-9095 - SENTHIL - 20240529 */ 

extern FIELD_IDX_T PtfTransfOp_Id                          ;
extern FIELD_IDX_T PtfTransfOp_Cd                          ;
extern FIELD_IDX_T PtfTransfOp_InputUserId                 ;
extern FIELD_IDX_T PtfTransfOp_TpId                        ;
extern FIELD_IDX_T PtfTransfOp_SubTpId                     ;
extern FIELD_IDX_T PtfTransfOp_MgrId                       ;
extern FIELD_IDX_T PtfTransfOp_RuleId                      ;
extern FIELD_IDX_T PtfTransfOp_SrcCd                       ;
extern FIELD_IDX_T PtfTransfOp_SubPosNatEn                 ;
extern FIELD_IDX_T PtfTransfOp_SubPosNat2En                ;
extern FIELD_IDX_T PtfTransfOp_SubPosNat3En                ;
extern FIELD_IDX_T PtfTransfOp_AdjSubPosNatEn              ;
extern FIELD_IDX_T PtfTransfOp_AdjSubPosNat2En             ;
extern FIELD_IDX_T PtfTransfOp_AdjSubPosNat3En             ;
extern FIELD_IDX_T PtfTransfOp_ParOpCd                     ;
extern FIELD_IDX_T PtfTransfOp_ParOpNatEn                  ;
extern FIELD_IDX_T PtfTransfOp_CheckParentEn               ;
extern FIELD_IDX_T PtfTransfOp_AcctDate                    ;
extern FIELD_IDX_T PtfTransfOp_OpDate                      ;
extern FIELD_IDX_T PtfTransfOp_ValueDate                   ;
extern FIELD_IDX_T PtfTransfOp_RefOpCd                     ;
extern FIELD_IDX_T PtfTransfOp_RefNatEn                    ;
extern FIELD_IDX_T PtfTransfOp_StatusEn                    ;
extern FIELD_IDX_T PtfTransfOp_SequenceNo                  ;
extern FIELD_IDX_T PtfTransfOp_AcctCd                      ;
extern FIELD_IDX_T PtfTransfOp_PtfId                       ;
extern FIELD_IDX_T PtfTransfOp_AdjPtfId                    ;
extern FIELD_IDX_T PtfTransfOp_InstrId                     ;
extern FIELD_IDX_T PtfTransfOp_BalPosTpId                  ;
extern FIELD_IDX_T PtfTransfOp_DepoId                      ;
extern FIELD_IDX_T PtfTransfOp_AdjDepoId                   ;
extern FIELD_IDX_T PtfTransfOp_AdjBpTpId                   ;
extern FIELD_IDX_T PtfTransfOp_OpCurrId                    ;
extern FIELD_IDX_T PtfTransfOp_InstrCurrId                 ;
extern FIELD_IDX_T PtfTransfOp_PtfCurrId                   ;
extern FIELD_IDX_T PtfTransfOp_AdjPosCurrId                ;
extern FIELD_IDX_T PtfTransfOp_AdjPtfCurrId                ;
extern FIELD_IDX_T PtfTransfOp_AccrBpTpId                  ;
extern FIELD_IDX_T PtfTransfOp_AdjNatEn                    ;
extern FIELD_IDX_T PtfTransfOp_ExecOpId                    ;
extern FIELD_IDX_T PtfTransfOp_ExecOpCd                    ;
extern FIELD_IDX_T PtfTransfOp_ExecOpNatEn                 ;
extern FIELD_IDX_T PtfTransfOp_ExecOpStatEn                ;
extern FIELD_IDX_T PtfTransfOp_RevOpCd                     ;
extern FIELD_IDX_T PtfTransfOp_RevOpNatEn                  ;
extern FIELD_IDX_T PtfTransfOp_FusRuleEn                   ;
extern FIELD_IDX_T PtfTransfOp_Remark                      ;
extern FIELD_IDX_T PtfTransfOp_OpExchRate                  ;
extern FIELD_IDX_T PtfTransfOp_InstrExchRate               ;
extern FIELD_IDX_T PtfTransfOp_SysExchRate                 ;
extern FIELD_IDX_T PtfTransfOp_AdjPosExchRate              ;
extern FIELD_IDX_T PtfTransfOp_AdjPtfExchRate              ;
extern FIELD_IDX_T PtfTransfOp_Qty                         ;
extern FIELD_IDX_T PtfTransfOp_Price                       ;
extern FIELD_IDX_T PtfTransfOp_PriceCalcRuleEn             ;
extern FIELD_IDX_T PtfTransfOp_Quote                       ;
extern FIELD_IDX_T PtfTransfOp_SupplAmt                    ;
extern FIELD_IDX_T PtfTransfOp_OpGrossAmt                  ;
extern FIELD_IDX_T PtfTransfOp_AccrAmt                     ;
extern FIELD_IDX_T PtfTransfOp_OpNetAmt                    ;
extern FIELD_IDX_T PtfTransfOp_InstrNetAmt                 ;
extern FIELD_IDX_T PtfTransfOp_PtfNetAmt                   ;
extern FIELD_IDX_T PtfTransfOp_SysNetAmt                   ;
extern FIELD_IDX_T PtfTransfOp_AdjPosNetAmt                ;
extern FIELD_IDX_T PtfTransfOp_AdjPtfNetAmt                ;
extern FIELD_IDX_T PtfTransfOp_LastUserId                  ;
extern FIELD_IDX_T PtfTransfOp_LastModifDate               ;
extern FIELD_IDX_T PtfTransfOp_CreationTime                ;
extern FIELD_IDX_T PtfTransfOp_SysCurrId                   ;
extern FIELD_IDX_T PtfTransfOp_ConfirmedFlg                ;
extern FIELD_IDX_T PtfTransfOp_FctResultId                 ;
extern FIELD_IDX_T PtfTransfOp_OrderModeTypeId			   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T PtfTransfOp_TraderMgrId				   ;
extern FIELD_IDX_T PtfTransfOp_AutoRenewalEn			   ;
extern FIELD_IDX_T PtfTransfOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T PtfTransfOp_RenewalEndValDate		   ;
extern FIELD_IDX_T PtfTransfOp_RenewalLength			   ;
extern FIELD_IDX_T PtfTransfOp_RenewalLengthUnitEn		   ;
extern FIELD_IDX_T PtfTransfOp_ClientInitEn				   ;
extern FIELD_IDX_T PtfTransfOp_ContractNumber			   ;
extern FIELD_IDX_T PtfTransfOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T PtfTransfOp_RenewalIntRate              ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T PtfTransfOp_RenewalAmount               ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T PtfTransfOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T PtfTransfOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T PtfTransfOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T PtfTransfOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T PtfTransfOp_FxMarginNumber                 ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T PtfTransfOp_FxMarginPrct                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T PtfTransfOp_FxMarginAmount                 ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T PtfTransfOp_ExtOpId                     ;
extern FIELD_IDX_T PtfTransfOp_ExtOp_Ext                   ;
extern FIELD_IDX_T PtfTransfOp_AutoIndex                   ;
extern FIELD_IDX_T PtfTransfOp_ExtOpDbId                   ;
extern FIELD_IDX_T PtfTransfOp_BeginDate                   ;
extern FIELD_IDX_T PtfTransfOp_EndDate                     ;
extern FIELD_IDX_T PtfTransfOp_DraftOrderId                ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T PtfTransfOp_Summary                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T PtfTransfOp_TimeStamp                   ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T PtfTransfOp_DerivativeOrdEn			   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T PtfTransfOp_FxFarLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T PtfTransfOp_FxSpotQuote				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T PtfTransfOp_FxQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T PtfTransfOp_FxSpotLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T PtfTransfOp_OrderFeeEn				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T PtfTransfOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T PtfTransfOp_MaxOrderQty				   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T PtfTransfOp_STPOrderEn				   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T PtfTransfOp_UnpaidPrct				   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T PtfTransfOp_EventStatusId               ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T PtfTransfOp_EventActionEn               ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T PtfTransfOp_CompoundOrderMasterEltId    ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T PtfTransfOp_CompoundOrderSlaveEltId	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T PtfTransfOp_CompoundOrderCode		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T PtfTransfOp_CompoundOrderSlaveNbr	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T PtfTransfOp_CompoundImpactRule		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T PtfTransfOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T PtfTransfOp_OrderType				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T PtfTransfOp_CommonRef                   ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T PtfTransfOp_OrderInclusionEn            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T PtfTransfOp_OrderRejectionDate          ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T PtfTransfOp_OrderRejectionComment       ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T PtfTransfOp_AcquisitionDate             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T PtfTransfOp_CorporateActionNatEn        ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T PtfTransfOp_TaxLotSourceCd              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T PtfTransfOp_StandInstructId             ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T PtfTransfOp_BankFeePrct                 ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T PtfTransfOp_BankFeeAmount               ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T PtfTransfOp_BankFeeCurrId               ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T PtfTransfOp_PaymentOption               ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T PtfTransfOp_BidTypeEn                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid1Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid1Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid2Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid2Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid3Qty                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_Bid3Quote                   ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T PtfTransfOp_OpFusionRuleEn              ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T PtfTransfOp_GlobalPosFlg                ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T PtfTransfOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T PtfTransfOp_DefaultFusRuleEn;	/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T PtfTransfOp_CoolCancelEndDate           ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T PtfTransfOp_FusionPrioEn                ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T PtfTransfOp_ExternalBankBic             ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T PtfTransfOp_ExternalBankName            ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T PtfTransfOp_ExternalBankAcctOwnrName    ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T PtfTransfOp_HedgeTradeEn                ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T PtfTransfOp_FixingDate                  ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr1      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr2      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr3      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_ExtrnlBnkAcctOwnrAddr4      ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_PayRef1                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_PayRef2                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_PayRef3                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_PayRef4                     ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T PtfTransfOp_ExternalTradeFlg            ;
extern FIELD_IDX_T PtfTransfOp_OriginalQty				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T PtfTransfOp_OrderNettingEn			   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T PtfTransfOp_PaymentDate                 ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T PtfTransfOp_PaymentStatusEn             ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T PtfTransfOp_SettlementDate              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T PtfTransfOp_SettleStatusEn              ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T PtfTransfOp_BoPtfId                     ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_BoAccountId                 ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_OpSplitRuleEn               ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_AdjBoPtfId                  ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_CoaExDate                   ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_BoCashAcctId                ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_BoCashPtfId                 ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_SplitParentOperId           ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T PtfTransfOp_AcctCurrId                  ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct2CurrId                 ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct3CurrId                 ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_AcctExchRate                ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct2ExchRate               ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct3ExchRate               ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_AcctNetAmt                  ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct2NetAmt                 ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct3NetAmt                 ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_AcctId                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct2Id                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Acct3Id                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp1TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp1CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp1Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp2TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp2CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp2Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp3TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp3CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp3Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp4TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp4CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp4Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp5TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp5CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp5Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp6TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp6CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp6Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp7TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp7CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp7Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp8TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp8CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp8Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp9TpId                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp9CurrId                   ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp9Amt                      ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp10TpId                    ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp10CurrId                  ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_Bp10Amt                     ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_TradeExchRate               ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_TradeCurrId                 ; /* PMSTA-39717 - KNI - 22042020 */
extern FIELD_IDX_T PtfTransfOp_SetOfFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T PtfTransfOp_SetOfProductFeesId		   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T PtfTransfOp_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */

extern FIELD_IDX_T PtfTransfOp_CommissionCdEn              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_ChargeCdEn                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_OriginalAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_CounterpartOrgAmount        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_ExternalFeeM                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_TotalChargesM               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_CounterpartAmount           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_OpLinkageCd                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_ChargedCustomerName         ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T PtfTransfOp_OriginalNetAmount           ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T PtfTransfOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T PtfTransfOp_RuleApplicabilityEn		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_SmartRoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_RoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_SmartRoundingFlg            ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_SmartRoundingRuleId         ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T PtfTransfOp_HierOperNatEn               ; /* PMSTA-40208 - adarshn - 01092020 */
extern FIELD_IDX_T PtfTransfOp_HierOperationCd             ; /* PMSTA-40208 - adarshn - 01092020 */
extern FIELD_IDX_T PtfTransfOp_CashPtfId                   ; /* PMSTA-41252 - adarshn - 16112020 */
extern FIELD_IDX_T PtfTransfOp_CashPfExchRate              ; /* PMSTA-41252 - adarshn - 16112020 */
extern FIELD_IDX_T PtfTransfOp_CashPfCurrId                ; /* PMSTA-41252 - adarshn - 16112020 */
extern FIELD_IDX_T PtfTransfOp_NotionalInstrId             ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T PtfTransfOp_InvestLimitEn               ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T PtfTransfOp_OrderSubTypeId              ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T PtfTransfOp_SetOfOtherFeesId            ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T PtfTransfOp_TraderThirdId               ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T PtfTransfOp_NetSettleAmount             ; /* WEALTH-9095 - SENTHIL - 20240529 */

extern FIELD_IDX_T BookAdjOp_Id                            ;
extern FIELD_IDX_T BookAdjOp_Cd                            ;
extern FIELD_IDX_T BookAdjOp_InputUserId                   ;
extern FIELD_IDX_T BookAdjOp_TpId                          ;
extern FIELD_IDX_T BookAdjOp_SubTpId                       ;
extern FIELD_IDX_T BookAdjOp_MgrId                         ;
extern FIELD_IDX_T BookAdjOp_RuleId                        ;
extern FIELD_IDX_T BookAdjOp_ValRuleId                     ;
extern FIELD_IDX_T BookAdjOp_ValRuleHistId                 ;
extern FIELD_IDX_T BookAdjOp_ValRuleEltId                  ;
extern FIELD_IDX_T BookAdjOp_SrcCd                         ;
extern FIELD_IDX_T BookAdjOp_SubPosNatEn                   ;
extern FIELD_IDX_T BookAdjOp_SubPosNat2En                  ;
extern FIELD_IDX_T BookAdjOp_SubPosNat3En                  ;
extern FIELD_IDX_T BookAdjOp_ParOpCd                       ;
extern FIELD_IDX_T BookAdjOp_ParOpNatEn                    ;
extern FIELD_IDX_T BookAdjOp_CheckParentEn                 ;
extern FIELD_IDX_T BookAdjOp_AcctDate                      ;
extern FIELD_IDX_T BookAdjOp_OpDate                        ;
extern FIELD_IDX_T BookAdjOp_ValueDate                     ;
extern FIELD_IDX_T BookAdjOp_RefOpCd                       ;
extern FIELD_IDX_T BookAdjOp_RefNatEn                      ;
extern FIELD_IDX_T BookAdjOp_StatusEn                      ;
extern FIELD_IDX_T BookAdjOp_SequenceNo                    ;
extern FIELD_IDX_T BookAdjOp_AcctCd                        ;
extern FIELD_IDX_T BookAdjOp_PtfId                         ;
extern FIELD_IDX_T BookAdjOp_PortPosSetId                  ;
extern FIELD_IDX_T BookAdjOp_InstrId                       ;
extern FIELD_IDX_T BookAdjOp_BalPosTpId                    ;
extern FIELD_IDX_T BookAdjOp_DepoId                        ;
extern FIELD_IDX_T BookAdjOp_OpCurrId                      ;
extern FIELD_IDX_T BookAdjOp_InstrCurrId                   ;
extern FIELD_IDX_T BookAdjOp_PtfCurrId                     ;
extern FIELD_IDX_T BookAdjOp_AdjNatEn                      ;
extern FIELD_IDX_T BookAdjOp_ExecOpId                      ;
extern FIELD_IDX_T BookAdjOp_ExecOpCd                      ;
extern FIELD_IDX_T BookAdjOp_ExecOpNatEn                   ;
extern FIELD_IDX_T BookAdjOp_ExecOpStatEn                  ;
extern FIELD_IDX_T BookAdjOp_RevOpCd                       ;
extern FIELD_IDX_T BookAdjOp_RevOpNatEn                    ;
extern FIELD_IDX_T BookAdjOp_FusRuleEn                     ;
extern FIELD_IDX_T BookAdjOp_Remark                        ;
extern FIELD_IDX_T BookAdjOp_OpExchRate                    ;
extern FIELD_IDX_T BookAdjOp_InstrExchRate                 ;
extern FIELD_IDX_T BookAdjOp_SysExchRate                   ;
extern FIELD_IDX_T BookAdjOp_Qty                           ;
extern FIELD_IDX_T BookAdjOp_Price                         ;
extern FIELD_IDX_T BookAdjOp_PriceCalcRuleEn               ;
extern FIELD_IDX_T BookAdjOp_Quote                         ;
extern FIELD_IDX_T BookAdjOp_BookOpNetAmt                  ;
extern FIELD_IDX_T BookAdjOp_BookInstrNetAmt               ;
extern FIELD_IDX_T BookAdjOp_BookPtfNetAmt                 ;
extern FIELD_IDX_T BookAdjOp_BookSysNetAmt                 ;
extern FIELD_IDX_T BookAdjOp_LastUserId                    ;
extern FIELD_IDX_T BookAdjOp_LastModifDate                 ;
extern FIELD_IDX_T BookAdjOp_CreationTime                  ;
extern FIELD_IDX_T BookAdjOp_SysCurrId                     ;
extern FIELD_IDX_T BookAdjOp_ConfirmedFlg                  ;
extern FIELD_IDX_T BookAdjOp_FctResultId                   ;
extern FIELD_IDX_T BookAdjOp_OrderModeTypeId			   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T BookAdjOp_TraderMgrId				   ;
extern FIELD_IDX_T BookAdjOp_AutoRenewalEn			       ;
extern FIELD_IDX_T BookAdjOp_RenewalTreatmtEn			   ;
extern FIELD_IDX_T BookAdjOp_RenewalEndValDate		       ;
extern FIELD_IDX_T BookAdjOp_RenewalLength			       ;
extern FIELD_IDX_T BookAdjOp_RenewalLengthUnitEn		   ;
extern FIELD_IDX_T BookAdjOp_ClientInitEn				   ;
extern FIELD_IDX_T BookAdjOp_ContractNumber			       ;
extern FIELD_IDX_T BookAdjOp_TransactionNatEn			   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T BookAdjOp_RenewalIntRate                ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BookAdjOp_RenewalAmount                 ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T BookAdjOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BookAdjOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BookAdjOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T BookAdjOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T BookAdjOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BookAdjOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BookAdjOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BookAdjOp_ExtOpId                       ;
extern FIELD_IDX_T BookAdjOp_ExtOp_Ext                     ;
extern FIELD_IDX_T BookAdjOp_AutoIndex                     ;
extern FIELD_IDX_T BookAdjOp_ExtOpDbId                     ;
extern FIELD_IDX_T BookAdjOp_BeginDate                     ;
extern FIELD_IDX_T BookAdjOp_EndDate                       ;
extern FIELD_IDX_T BookAdjOp_DraftOrderId                  ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T BookAdjOp_Summary                       ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T BookAdjOp_TimeStamp                     ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T BookAdjOp_DerivativeOrdEn			   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T BookAdjOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BookAdjOp_FxSpotQuote				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BookAdjOp_FxQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BookAdjOp_FxSpotLegAmount			   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T BookAdjOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BookAdjOp_OrderFeePrct				   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T BookAdjOp_MaxOrderQty				   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T BookAdjOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T BookAdjOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T BookAdjOp_EventStatusId                 ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T BookAdjOp_EventActionEn                 ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T BookAdjOp_CompoundOrderMasterEltId      ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BookAdjOp_CompoundOrderSlaveEltId	   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BookAdjOp_CompoundOrderCode			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BookAdjOp_CompoundOrderSlaveNbr		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BookAdjOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T BookAdjOp_DisplayCondition			   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BookAdjOp_OrderType					   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T BookAdjOp_CommonRef                         ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T BookAdjOp_OrderInclusionEn              ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BookAdjOp_OrderRejectionDate            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BookAdjOp_OrderRejectionComment         ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T BookAdjOp_AcquisitionDate               ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BookAdjOp_CorporateActionNatEn          ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BookAdjOp_TaxLotSourceCd                ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T BookAdjOp_StandInstructId               ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T BookAdjOp_BankFeePrct                   ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BookAdjOp_BankFeeAmount                 ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BookAdjOp_BankFeeCurrId                 ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T BookAdjOp_PaymentOption                 ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T BookAdjOp_BidTypeEn                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid1Qty                       ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid1Quote                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid2Qty                       ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid2Quote                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid3Qty                       ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_Bid3Quote                     ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T BookAdjOp_OpFusionRuleEn                ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BookAdjOp_GlobalPosFlg                  ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T BookAdjOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BookAdjOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T BookAdjOp_CoolCancelEndDate             ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T BookAdjOp_FusionPrioEn                  ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T BookAdjOp_ExternalBankBic               ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BookAdjOp_ExternalBankName              ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BookAdjOp_ExternalBankAcctOwnrName      ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T BookAdjOp_HedgeTradeEn                  ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T BookAdjOp_FixingDate                    ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr1        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr2        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr3        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_ExtrnlBnkAcctOwnrAddr4        ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_PayRef1                       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_PayRef2                       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_PayRef3                       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_PayRef4                       ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T BookAdjOp_ExternalTradeFlg              ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T BookAdjOp_OriginalQty				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BookAdjOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	- 19112019 */
extern FIELD_IDX_T BookAdjOp_PaymentDate                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BookAdjOp_PaymentStatusEn               ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BookAdjOp_SettlementDate                ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BookAdjOp_SettleStatusEn                ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T BookAdjOp_CommissionCdEn                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_ChargeCdEn                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_OriginalAmount                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_CounterpartOrgAmount          ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_ExternalFeeM                  ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_TotalChargesM                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_CounterpartAmount             ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_OpLinkageCd                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_ChargedCustomerName           ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T BookAdjOp_BoPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_BoAccountId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_OpSplitRuleEn                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_AdjBoPtfId                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_CoaExDate                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_BoCashAcctId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_BoCashPtfId                   ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_SplitParentOperId             ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T BookAdjOp_OriginalNetAmount             ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T BookAdjOp_SplitParOpCd				   ; /* PMSTA-40714 */
extern FIELD_IDX_T BookAdjOp_RuleApplicabilityEn		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_SmartRoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_SmartRoundingFlg			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_SmartRoundingRuleId		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T BookAdjOp_HierOperNatEn                 ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BookAdjOp_HierOperationCd               ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T BookAdjOp_NotionalInstrId               ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BookAdjOp_InvestLimitEn                 ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T BookAdjOp_OrderSubTypeId                ; /* WEALTH-157 - Deepthi - 20230404 */ 
extern FIELD_IDX_T BookAdjOp_SetOfOtherFeesId              ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T BookAdjOp_TraderThirdId                 ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T BookAdjOp_NetSettleAmount               ; /* WEALTH-9095 - SENTHIL - 20240529 */

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T A_BusEntity_Id                          ;
extern FIELD_IDX_T A_BusEntity_Cd                          ;
extern FIELD_IDX_T A_BusEntity_Name                        ;
extern FIELD_IDX_T A_BusEntity_Denom                       ;
extern FIELD_IDX_T A_BusEntity_CurrId                      ;
extern FIELD_IDX_T A_BusEntity_Phone                       ;
extern FIELD_IDX_T A_BusEntity_Fax                         ;
extern FIELD_IDX_T A_BusEntity_Telex                       ;
extern FIELD_IDX_T A_BusEntity_ResidGeoId                  ;
extern FIELD_IDX_T A_BusEntity_Email                       ;
extern FIELD_IDX_T A_BusEntity_CalendarId                  ;
extern FIELD_IDX_T A_BusEntity_LegalNatEn                  ;
extern FIELD_IDX_T A_BusEntity_OrgaRoleEn                  ;
extern FIELD_IDX_T A_BusEntity_TypeId                      ;
extern FIELD_IDX_T A_BusEntity_StatusEn                    ;
extern FIELD_IDX_T A_BusEntity_ReferenceEn                 ;
extern FIELD_IDX_T A_BusEntity_Theme                       ;        /*  HFI-PMSTA-26560-170806  */
extern FIELD_IDX_T A_BusEntity_DataSecuProfId              ;
extern FIELD_IDX_T A_BusEntity_DataSecuProf2Id             ;
extern FIELD_IDX_T A_BusEntity_TimezoneId                  ; /* PMSTA-32150 - JBC - 180723 */
extern FIELD_IDX_T A_BusEntity_FiscalPeriodId		       ; /* PMSTA-34965 - sanand - 030319 */
extern FIELD_IDX_T A_BusEntity_WashSaleCheckDaysBefore		;       /*   24: IntType          */
extern FIELD_IDX_T A_BusEntity_WashSaleCheckDaysAfter		;       /*   25: IntType          */
extern FIELD_IDX_T A_BusEntity_SmartRoundingRuleId			; /* PMSTA-40493-badhri-08252020: smart rounding rule  */


/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T S_BusEntity_Id                          ;
extern FIELD_IDX_T S_BusEntity_Cd                          ;
extern FIELD_IDX_T S_BusEntity_Name                        ;
extern FIELD_IDX_T S_BusEntity_Denom                       ;
extern FIELD_IDX_T S_BusEntity_DataSecuProfId              ;
extern FIELD_IDX_T S_BusEntity_CodifId                     ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T A_BusOrga_Id                            ;
extern FIELD_IDX_T A_BusOrga_BusEntityId                   ;
extern FIELD_IDX_T A_BusOrga_ParentBusEntityId             ;
extern FIELD_IDX_T A_BusOrga_RoleFunctionEn                ;
extern FIELD_IDX_T A_BusOrga_TypeId                        ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T S_BusOrga_Id                            ;
extern FIELD_IDX_T S_BusOrga_BusEntityId                   ;
extern FIELD_IDX_T S_BusOrga_BusEntityCd                   ;
extern FIELD_IDX_T S_BusOrga_ParentBusEntityId             ;
extern FIELD_IDX_T S_BusOrga_ParentBusEntityCd             ;
extern FIELD_IDX_T S_BusOrga_RoleFunctionEn                ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T A_BusEntityPtfCompo_Id                  ;
extern FIELD_IDX_T A_BusEntityPtfCompo_PtfId               ;
extern FIELD_IDX_T A_BusEntityPtfCompo_BusEntityId         ;
extern FIELD_IDX_T A_BusEntityPtfCompo_MainBusEntityFlg    ;
extern FIELD_IDX_T A_BusEntityPtfCompo_RoleEn              ;
extern FIELD_IDX_T A_BusEntityPtfCompo_TypeId              ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T S_BusEntityPtfCompo_Id                  ;
extern FIELD_IDX_T S_BusEntityPtfCompo_PtfId               ;
extern FIELD_IDX_T S_BusEntityPtfCompo_PtfCd               ;
extern FIELD_IDX_T S_BusEntityPtfCompo_BusEntityId         ;
extern FIELD_IDX_T S_BusEntityPtfCompo_BusEntityCd         ;
extern FIELD_IDX_T S_BusEntityPtfCompo_MainBusEntityFlg    ;
extern FIELD_IDX_T S_BusEntityPtfCompo_RoleEn              ;
extern FIELD_IDX_T S_BusEntityPtfCompo_TypeId              ; /* PMSTA-17466 - EFE - 140120 */
extern FIELD_IDX_T S_BusEntityPtfCompo_TypeCd              ; /* PMSTA-17466 - EFE - 140120 */


/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T A_BusEntityInstrCompo_Id                ;
extern FIELD_IDX_T A_BusEntityInstrCompo_InstrId           ;
extern FIELD_IDX_T A_BusEntityInstrCompo_BusEntityId       ;
extern FIELD_IDX_T A_BusEntityInstrCompo_MainBusEntityFlg  ;
extern FIELD_IDX_T A_BusEntityInstrCompo_RoleEn            ;
extern FIELD_IDX_T A_BusEntityInstrCompo_TypeId            ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T S_BusEntityInstrCompo_Id                ;
extern FIELD_IDX_T S_BusEntityInstrCompo_InstrId           ;
extern FIELD_IDX_T S_BusEntityInstrCompo_InstrCd           ;
extern FIELD_IDX_T S_BusEntityInstrCompo_BusEntityId       ;
extern FIELD_IDX_T S_BusEntityInstrCompo_BusEntityCd       ;
extern FIELD_IDX_T S_BusEntityInstrCompo_MainBusEntityFlg  ;
extern FIELD_IDX_T S_BusEntityInstrCompo_RoleEn            ;
extern FIELD_IDX_T S_BusEntityInstrCompo_TypeId            ; /* PMSTA-17466 - EFE - 140120 */
extern FIELD_IDX_T S_BusEntityInstrCompo_TypeCd            ; /* PMSTA-17466 - EFE - 140120 */

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T A_BusEntityThirdCompo_Id                ;
extern FIELD_IDX_T A_BusEntityThirdCompo_ThirdId           ;
extern FIELD_IDX_T A_BusEntityThirdCompo_BusEntityId       ;
extern FIELD_IDX_T A_BusEntityThirdCompo_MainBusEntityFlg  ;
extern FIELD_IDX_T A_BusEntityThirdCompo_RoleEn            ;
extern FIELD_IDX_T A_BusEntityThirdCompo_TypeId            ;

/* PMSTA-17089 - DDV - 131106 */
extern FIELD_IDX_T S_BusEntityThirdCompo_Id                ;
extern FIELD_IDX_T S_BusEntityThirdCompo_ThirdId           ;
extern FIELD_IDX_T S_BusEntityThirdCompo_ThirdCd           ;
extern FIELD_IDX_T S_BusEntityThirdCompo_BusEntityId       ;
extern FIELD_IDX_T S_BusEntityThirdCompo_BusEntityCd       ;
extern FIELD_IDX_T S_BusEntityThirdCompo_MainBusEntityFlg  ;
extern FIELD_IDX_T S_BusEntityThirdCompo_RoleEn            ;
extern FIELD_IDX_T S_BusEntityThirdCompo_TypeId            ; /* PMSTA-17466 - EFE - 140120 */
extern FIELD_IDX_T S_BusEntityThirdCompo_TypeCd            ; /* PMSTA-17466 - EFE - 140120 */


/* PMSTA-17089 - DDV - 131203 */
extern FIELD_IDX_T A_BusEntityAddr_Id                      ;
extern FIELD_IDX_T A_BusEntityAddr_BusEntityId             ;
extern FIELD_IDX_T A_BusEntityAddr_TpId                    ;
extern FIELD_IDX_T A_BusEntityAddr_GeoId                   ;
extern FIELD_IDX_T A_BusEntityAddr_DataSecuProfId          ;
extern FIELD_IDX_T A_BusEntityAddr_Addr                    ;
extern FIELD_IDX_T A_BusEntityAddr_Postal                  ;
extern FIELD_IDX_T A_BusEntityAddr_Phone                   ;
extern FIELD_IDX_T A_BusEntityAddr_Telex                   ;
extern FIELD_IDX_T A_BusEntityAddr_Fax                     ;

/* PMSTA-17089 - DDV - 131203 */
extern FIELD_IDX_T S_BusEntityAddr_Id                      ;
extern FIELD_IDX_T S_BusEntityAddr_BusEntityId             ;
extern FIELD_IDX_T S_BusEntityAddr_TpId                    ;
extern FIELD_IDX_T S_BusEntityAddr_GeoId                   ;
extern FIELD_IDX_T S_BusEntityAddr_DataSecuProfId          ;
extern FIELD_IDX_T S_BusEntityAddr_TpCd                    ;
extern FIELD_IDX_T S_BusEntityAddr_GeoCd                   ;


extern FIELD_IDX_T InitOp_Id                               ;
extern FIELD_IDX_T InitOp_Cd                               ;
extern FIELD_IDX_T InitOp_InputUserId                      ;
extern FIELD_IDX_T InitOp_TpId                             ;
extern FIELD_IDX_T InitOp_SubTpId                          ;
extern FIELD_IDX_T InitOp_MktThirdId                       ;
extern FIELD_IDX_T InitOp_IntermThirdId                    ;
extern FIELD_IDX_T InitOp_MgrId                            ;
extern FIELD_IDX_T InitOp_RuleId                           ;
extern FIELD_IDX_T InitOp_ValRuleEltId                     ;
extern FIELD_IDX_T InitOp_SrcCd                            ;
extern FIELD_IDX_T InitOp_SubPosNatEn                      ;
extern FIELD_IDX_T InitOp_SubPosNat2En                     ;
extern FIELD_IDX_T InitOp_SubPosNat3En                     ;
extern FIELD_IDX_T InitOp_LimitQuote                       ;
extern FIELD_IDX_T InitOp_LimitPrice                       ;
extern FIELD_IDX_T InitOp_StopQuote                        ;
extern FIELD_IDX_T InitOp_StopPrice                        ;
extern FIELD_IDX_T InitOp_OrderPriceNatEn                  ;
extern FIELD_IDX_T InitOp_OrderValidNatEn                  ;
extern FIELD_IDX_T InitOp_MinOrderQty                      ;
extern FIELD_IDX_T InitOp_ParOpCd                          ;
extern FIELD_IDX_T InitOp_ParOpNatEn                       ;
extern FIELD_IDX_T InitOp_CheckParentEn                    ;
extern FIELD_IDX_T InitOp_CheckStratEn                     ;
extern FIELD_IDX_T InitOp_OrderNatEn                       ;
extern FIELD_IDX_T InitOp_BeginDate                        ;
extern FIELD_IDX_T InitOp_AcctDate                         ;
extern FIELD_IDX_T InitOp_OpDate                           ;
extern FIELD_IDX_T InitOp_ValuationDate                    ;
extern FIELD_IDX_T InitOp_OrderLimitDate                   ;
extern FIELD_IDX_T InitOp_ValueDate                        ;
extern FIELD_IDX_T InitOp_RefOpCd                          ;
extern FIELD_IDX_T InitOp_RefNatEn                         ;
extern FIELD_IDX_T InitOp_StatusEn                         ;
extern FIELD_IDX_T InitOp_SequenceNo                       ;
extern FIELD_IDX_T InitOp_AcctCd                           ;
extern FIELD_IDX_T InitOp_OpenOperCd                       ;
extern FIELD_IDX_T InitOp_PtfId                            ;
extern FIELD_IDX_T InitOp_PortPosSetId                     ;
extern FIELD_IDX_T InitOp_InstrId                          ;
extern FIELD_IDX_T InitOp_BalPosTpId                       ;
extern FIELD_IDX_T InitOp_DepoId                           ;
extern FIELD_IDX_T InitOp_OpCurrId                         ;
extern FIELD_IDX_T InitOp_InstrCurrId                      ;
extern FIELD_IDX_T InitOp_ToInstrCurrId                    ;
extern FIELD_IDX_T InitOp_PtfCurrId                        ;
extern FIELD_IDX_T InitOp_TradeCurrId                      ;
extern FIELD_IDX_T InitOp_CntPtyThirdId                    ;
extern FIELD_IDX_T InitOp_TermTpId                         ;
extern FIELD_IDX_T InitOp_LockTpId                         ;
extern FIELD_IDX_T InitOp_AccrIntrBpTpId                   ;
extern FIELD_IDX_T InitOp_AdjNatEn                         ;
extern FIELD_IDX_T InitOp_ExecOpId                         ;
extern FIELD_IDX_T InitOp_ExecOpCd                         ;
extern FIELD_IDX_T InitOp_ExecOpNatEn                      ;
extern FIELD_IDX_T InitOp_ExecOpStatEn                     ;
extern FIELD_IDX_T InitOp_RevOpCd                          ;
extern FIELD_IDX_T InitOp_RevOpNatEn                       ;
extern FIELD_IDX_T InitOp_LockOpCd                         ;
extern FIELD_IDX_T InitOp_LockNatEn                        ;
extern FIELD_IDX_T InitOp_EvtCd                            ;
extern FIELD_IDX_T InitOp_EvtNbr                           ;
extern FIELD_IDX_T InitOp_ExCouponFlg                      ;
extern FIELD_IDX_T InitOp_FusRuleEn                        ;
extern FIELD_IDX_T InitOp_LockLimitDate                    ;
extern FIELD_IDX_T InitOp_ExpirDate                        ;
extern FIELD_IDX_T InitOp_Remark                           ;
extern FIELD_IDX_T InitOp_OpExchRate                       ;
extern FIELD_IDX_T InitOp_InstrExchRate                    ;
extern FIELD_IDX_T InitOp_SysExchRate                      ;
extern FIELD_IDX_T InitOp_TradeExchRate                    ;
extern FIELD_IDX_T InitOp_BookOpExchRate                   ;
extern FIELD_IDX_T InitOp_BookInstrExchRate                ;
extern FIELD_IDX_T InitOp_BookSysExchRate                  ;
extern FIELD_IDX_T InitOp_Qty                              ;
extern FIELD_IDX_T InitOp_Price                            ;
extern FIELD_IDX_T InitOp_SpotPrice                        ;
extern FIELD_IDX_T InitOp_BookPrice                        ;
extern FIELD_IDX_T InitOp_PriceCalcRuleEn                  ;
extern FIELD_IDX_T InitOp_Quote                            ;
extern FIELD_IDX_T InitOp_SpotQuote                        ;
extern FIELD_IDX_T InitOp_HistQuote                        ;
extern FIELD_IDX_T InitOp_BookQuote                        ;
extern FIELD_IDX_T InitOp_Rate                             ;
extern FIELD_IDX_T InitOp_SupplAmt                         ;
extern FIELD_IDX_T InitOp_OpGrossAmt                       ;
extern FIELD_IDX_T InitOp_AccrIntrAmt                      ;
extern FIELD_IDX_T InitOp_OpNetAmt                         ;
extern FIELD_IDX_T InitOp_InstrNetAmt                      ;
extern FIELD_IDX_T InitOp_PtfNetAmt                        ;
extern FIELD_IDX_T InitOp_SysNetAmt                        ;
extern FIELD_IDX_T InitOp_BookOpNetAmt                     ;
extern FIELD_IDX_T InitOp_BookInstrNetAmt                  ;
extern FIELD_IDX_T InitOp_BookPtfNetAmt                    ;
extern FIELD_IDX_T InitOp_BookSysNetAmt                    ;
extern FIELD_IDX_T InitOp_Bp1TpId                          ;
extern FIELD_IDX_T InitOp_Bp1CurrId                        ;
extern FIELD_IDX_T InitOp_Bp1Amt                           ;
extern FIELD_IDX_T InitOp_Bp2TpId                          ;
extern FIELD_IDX_T InitOp_Bp2CurrId                        ;
extern FIELD_IDX_T InitOp_Bp2Amt                           ;
extern FIELD_IDX_T InitOp_Bp3TpId                          ;
extern FIELD_IDX_T InitOp_Bp3CurrId                        ;
extern FIELD_IDX_T InitOp_Bp3Amt                           ;
extern FIELD_IDX_T InitOp_Bp4TpId                          ;
extern FIELD_IDX_T InitOp_Bp4CurrId                        ;
extern FIELD_IDX_T InitOp_Bp4Amt                           ;
extern FIELD_IDX_T InitOp_Bp5TpId                          ;
extern FIELD_IDX_T InitOp_Bp5CurrId                        ;
extern FIELD_IDX_T InitOp_Bp5Amt                           ;
extern FIELD_IDX_T InitOp_Bp6TpId                          ;
extern FIELD_IDX_T InitOp_Bp6CurrId                        ;
extern FIELD_IDX_T InitOp_Bp6Amt                           ;
extern FIELD_IDX_T InitOp_Bp7TpId                          ;
extern FIELD_IDX_T InitOp_Bp7CurrId                        ;
extern FIELD_IDX_T InitOp_Bp7Amt                           ;
extern FIELD_IDX_T InitOp_Bp8TpId                          ;
extern FIELD_IDX_T InitOp_Bp8CurrId                        ;
extern FIELD_IDX_T InitOp_Bp8Amt                           ;
extern FIELD_IDX_T InitOp_Bp9TpId                          ;
extern FIELD_IDX_T InitOp_Bp9CurrId                        ;
extern FIELD_IDX_T InitOp_Bp9Amt                           ;
extern FIELD_IDX_T InitOp_Bp10TpId                         ;
extern FIELD_IDX_T InitOp_Bp10CurrId                       ;
extern FIELD_IDX_T InitOp_Bp10Amt                          ;
extern FIELD_IDX_T InitOp_ValRuleId                        ;
extern FIELD_IDX_T InitOp_ValRuleHistId                    ;
extern FIELD_IDX_T InitOp_LastUserId                       ;
extern FIELD_IDX_T InitOp_LastModifDate                    ;
extern FIELD_IDX_T InitOp_CreationTime                     ;
extern FIELD_IDX_T InitOp_SysCurrId                        ;
extern FIELD_IDX_T InitOp_ConfirmedFlg                     ;
extern FIELD_IDX_T InitOp_FctResultId                      ;
extern FIELD_IDX_T InitOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T InitOp_TraderMgrId					   ;
extern FIELD_IDX_T InitOp_AutoRenewalEn					   ;
extern FIELD_IDX_T InitOp_RenewalTreatmtEn				   ;
extern FIELD_IDX_T InitOp_RenewalEndValDate				   ;
extern FIELD_IDX_T InitOp_RenewalLength					   ;
extern FIELD_IDX_T InitOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T InitOp_ClientInitEn					   ;
extern FIELD_IDX_T InitOp_ContractNumber			       ;
extern FIELD_IDX_T InitOp_TransactionNatEn				   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T InitOp_RenewalIntRate                   ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T InitOp_RenewalAmount                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T InitOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InitOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InitOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T InitOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T InitOp_FxMarginNumber                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InitOp_FxMarginPrct                     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InitOp_FxMarginAmount                   ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InitOp_ExtOpId                          ;
extern FIELD_IDX_T InitOp_ExtOp_Ext                        ;
extern FIELD_IDX_T InitOp_AutoIndex                        ;
extern FIELD_IDX_T InitOp_ExtOpDbId                        ;
extern FIELD_IDX_T InitOp_EndDate                          ;
extern FIELD_IDX_T InitOp_DraftOrderId                     ;    /* REF8500 - 040510 - PMO */
extern FIELD_IDX_T InitOp_Summary                          ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T InitOp_TimeStamp                        ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T InitOp_DerivativeOrdEn				   ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T InitOp_FxFarLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InitOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InitOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InitOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T InitOp_OrderFeeEn					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T InitOp_OrderFeePrct					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T InitOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T InitOp_STPOrderEn					   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T InitOp_UnpaidPrct					   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T InitOp_EventStatusId                    ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T InitOp_EventActionEn                    ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T InitOp_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InitOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InitOp_CompoundOrderCode			       ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InitOp_CompoundOrderSlaveNbr		       ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InitOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T InitOp_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T InitOp_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T InitOp_CommonRef                        ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T InitOp_OrderInclusionEn                 ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InitOp_OrderRejectionDate               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InitOp_OrderRejectionComment            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T InitOp_AcquisitionDate                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InitOp_CorporateActionNatEn             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InitOp_TaxLotSourceCd                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T InitOp_StandInstructId                  ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T InitOp_BankFeePrct                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InitOp_BankFeeAmount                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InitOp_BankFeeCurrId                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T InitOp_PaymentOption                    ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T InitOp_BidTypeEn                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid1Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid1Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid2Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid2Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid3Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_Bid3Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T InitOp_OpFusionRuleEn                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T InitOp_GlobalPosFlg                     ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T InitOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T InitOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T InitOp_CoolCancelEndDate                ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T InitOp_FusionPrioEn                     ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T InitOp_ExternalBankBic                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InitOp_ExternalBankName                 ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InitOp_ExternalBankAcctOwnrName         ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T InitOp_HedgeTradeEn                     ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T InitOp_FixingDate                       ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr1           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr2           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr3           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_ExtrnlBnkAcctOwnrAddr4           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_PayRef1                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_PayRef2                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_PayRef3                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_PayRef4                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T InitOp_ExternalTradeFlg                 ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T InitOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T InitOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T InitOp_PaymentDate                      ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InitOp_PaymentStatusEn                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InitOp_SettlementDate                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InitOp_SettleStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T InitOp_CommissionCdEn                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_ChargeCdEn                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_OriginalAmount                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_CounterpartOrgAmount             ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_ExternalFeeM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_TotalChargesM                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_CounterpartAmount                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_OpLinkageCd                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_ChargedCustomerName              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T InitOp_BoPtfId                          ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_BoAccountId                      ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_OpSplitRuleEn                    ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_AdjBoPtfId                       ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_CoaExDate                        ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_BoCashAcctId                     ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_BoCashPtfId                      ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_SplitParentOperId                ; /* PMSTA-38454 - srinivas   - 05022020 */
extern FIELD_IDX_T InitOp_OriginalNetAmount                ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T InitOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T InitOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T InitOp_HierOperNatEn                    ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T InitOp_HierOperationCd                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T InitOp_NotionalInstrId                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T InitOp_InvestLimitEn                    ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T InitOp_SetOfFeesId				       ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T InitOp_SetOfProductFeesId			   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T InitOp_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T InitOp_OrderSubTypeId                   ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T InitOp_SetOfOtherFeesId                 ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T InitOp_TraderThirdId                    ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T InitOp_NetSettleAmount                  ; /* WEALTH-9095 - SENTHIL - 20240529 */

/*PMSTA06760-BRO-080701*/
extern FIELD_IDX_T CombinedOp_Id                           ;
extern FIELD_IDX_T CombinedOp_Cd                           ;
extern FIELD_IDX_T CombinedOp_InputUserId                  ;
extern FIELD_IDX_T CombinedOp_TpId                         ;
extern FIELD_IDX_T CombinedOp_SubTpId                      ;
extern FIELD_IDX_T CombinedOp_MktThirdId                   ;
extern FIELD_IDX_T CombinedOp_IntermThirdId                ;
extern FIELD_IDX_T CombinedOp_MgrId                        ;
extern FIELD_IDX_T CombinedOp_RuleId                       ;
extern FIELD_IDX_T CombinedOp_SrcCd                        ;
extern FIELD_IDX_T CombinedOp_ParOpCd                      ;
extern FIELD_IDX_T CombinedOp_ParOpNatEn                   ;
extern FIELD_IDX_T CombinedOp_CheckParentEn                ;
extern FIELD_IDX_T CombinedOp_AcctDate                     ;
extern FIELD_IDX_T CombinedOp_OpDate                       ;
extern FIELD_IDX_T CombinedOp_ValueDate                    ;
extern FIELD_IDX_T CombinedOp_StatusEn                     ;
extern FIELD_IDX_T CombinedOp_SequenceNo                   ;
extern FIELD_IDX_T CombinedOp_AcctCd                       ;
extern FIELD_IDX_T CombinedOp_PtfId                        ;
extern FIELD_IDX_T CombinedOp_ExecOpId                     ;
extern FIELD_IDX_T CombinedOp_ExecOpCd                     ;
extern FIELD_IDX_T CombinedOp_ExecOpNatEn                  ;
extern FIELD_IDX_T CombinedOp_ExecOpStatEn                 ;
extern FIELD_IDX_T CombinedOp_RevOpCd                      ;
extern FIELD_IDX_T CombinedOp_RevOpNatEn                   ;
extern FIELD_IDX_T CombinedOp_EvtCd                        ;
extern FIELD_IDX_T CombinedOp_EvtNbr                       ;
extern FIELD_IDX_T CombinedOp_Remark                       ;
extern FIELD_IDX_T CombinedOp_FlowId                       ;
extern FIELD_IDX_T CombinedOp_InitExtPosId                 ;
extern FIELD_IDX_T CombinedOp_LastUserId                   ;
extern FIELD_IDX_T CombinedOp_LastModifDate                ;
extern FIELD_IDX_T CombinedOp_CreationTime                 ;
extern FIELD_IDX_T CombinedOp_ConfirmedFlg                 ;
extern FIELD_IDX_T CombinedOp_FctResultId                  ;
extern FIELD_IDX_T CombinedOp_OrderModeTypeId              ;
extern FIELD_IDX_T CombinedOp_TraderMgrId                  ;
extern FIELD_IDX_T CombinedOp_AutoRenewalEn                ;
extern FIELD_IDX_T CombinedOp_RenewalTreatmtEn             ;
extern FIELD_IDX_T CombinedOp_RenewalEndValDate            ;
extern FIELD_IDX_T CombinedOp_RenewalLength                ;
extern FIELD_IDX_T CombinedOp_RenewalLengthUnitEn          ;
extern FIELD_IDX_T CombinedOp_ClientInitEn                 ;
extern FIELD_IDX_T CombinedOp_ContractNumber               ;
extern FIELD_IDX_T CombinedOp_TransactionNatEn             ;
extern FIELD_IDX_T CombinedOp_RenewalIntRate               ;
extern FIELD_IDX_T CombinedOp_RenewalAmount                ;
extern FIELD_IDX_T CombinedOp_TargetNatureEn                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_TargetNumber                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_TargetAmount                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_MarketSegmentId                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_FactSheetEn                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_LastQuoteDate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_LastQuoteNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_LastPriceNumber                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_CommunicationDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_CommunicationTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_CommPartyTypeId                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T CombinedOp_Remark1                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_Remark2                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_Remark3                            ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_TransmissionDate                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_TransmissionTypeId                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_OrderTypeId                        ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_MMInterestAmount                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_FxMarketRate                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_FxClientRate                       ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T CombinedOp_FxRateDirection                    ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T CombinedOp_InterestMarketRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_DebitToSysCurrRate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_CreditToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_ContractLengthNumber               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_ContractLengthUnitEn               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T CombinedOp_FxMarginNumber			         ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T CombinedOp_FxMarginPrct					     ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T CombinedOp_FxMarginAmount					 ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T CombinedOp_TimeStamp					         ;
extern FIELD_IDX_T CombinedOp_DerivativeOrdEn					 ; /* OCS43683-CHU-131112 */
extern FIELD_IDX_T CombinedOp_FxFarLegAmount					 ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T CombinedOp_FxSpotQuote					     ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T CombinedOp_FxQuote						     ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T CombinedOp_FxSpotLegAmount				     ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T CombinedOp_OrderFeeEn						 ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T CombinedOp_OrderFeePrct						 ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T CombinedOp_MaxOrderQty					     ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T CombinedOp_STPOrderEn						 ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T CombinedOp_UnpaidPrct						 ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T CombinedOp_SysCurrId                          ;
extern FIELD_IDX_T CombinedOp_ExtOpId                            ;
extern FIELD_IDX_T CombinedOp_ExtOp_Ext                          ;
extern FIELD_IDX_T CombinedOp_AutoIndex                          ;
extern FIELD_IDX_T CombinedOp_ExtOpDbId                          ;
extern FIELD_IDX_T CombinedOp_BeginDate                          ;
extern FIELD_IDX_T CombinedOp_EndDate                            ;
extern FIELD_IDX_T CombinedOp_DraftOrderId                       ;
extern FIELD_IDX_T CombinedOp_Summary                            ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T CombinedOp_EventStatusId                      ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T CombinedOp_EventActionEn                      ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T CombinedOp_CompoundOrderMasterEltId		   ;	/* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T CombinedOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T CombinedOp_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T CombinedOp_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T CombinedOp_CompoundImpactRule			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T CombinedOp_DisplayCondition				   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T CombinedOp_OrderType						   ;	/* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T CombinedOp_CommonRef                        ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T CombinedOp_OrderInclusionEn                 ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T CombinedOp_OrderRejectionDate               ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T CombinedOp_OrderRejectionComment            ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T CombinedOp_AcquisitionDate                  ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T CombinedOp_CorporateActionNatEn             ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T CombinedOp_TaxLotSourceCd                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T CombinedOp_StandInstructId                  ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T CombinedOp_BankFeePrct                      ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T CombinedOp_BankFeeAmount                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T CombinedOp_BankFeeCurrId                    ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T CombinedOp_PaymentOption                    ; /* PMSTA-30658 - AiswaryaM -20180503 */
extern FIELD_IDX_T CombinedOp_BidTypeEn                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid1Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid1Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid2Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid2Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid3Qty                          ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_Bid3Quote                        ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T CombinedOp_OpFusionRuleEn                   ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T CombinedOp_GlobalPosFlg                     ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T CombinedOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T CombinedOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T CombinedOp_CoolCancelEndDate                ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T CombinedOp_FusionPrioEn                     ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T CombinedOp_ExternalBankBic                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T CombinedOp_ExternalBankName                 ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T CombinedOp_ExternalBankAcctOwnrName         ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T CombinedOp_HedgeTradeEn                     ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T CombinedOp_FixingDate                       ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr1           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr2           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr3           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_ExtrnlBnkAcctOwnrAddr4           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_PayRef1                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_PayRef2                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_PayRef3                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_PayRef4                          ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T CombinedOp_ExternalTradeFlg				   ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T CombinedOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T CombinedOp_OrderNettingEn				   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T CombinedOp_PaymentDate                      ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T CombinedOp_PaymentStatusEn                  ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T CombinedOp_SettlementDate                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T CombinedOp_SettleStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T CombinedOp_CommissionCdEn                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_ChargeCdEn                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_OriginalAmount                   ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_CounterpartOrgAmount             ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_ExternalFeeM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_TotalChargesM                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_CounterpartAmount                ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_OpLinkageCd                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_ChargedCustomerName              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T CombinedOp_BoPtfId                          ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_BoAccountId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_OpSplitRuleEn                    ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_AdjBoPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_CoaExDate                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_BoCashAcctId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_BoCashPtfId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_SplitParentOperId                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T CombinedOp_OriginalNetAmount                ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T CombinedOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T CombinedOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_RoundingOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T CombinedOp_HierOperNatEn                    ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T CombinedOp_HierOperationCd                  ; /* PMSTA-40208 - adarshn	- 01092020 */
extern FIELD_IDX_T CombinedOp_NotionalInstrId                  ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T CombinedOp_InvestLimitEn                    ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T CombinedOp_OrderSubTypeId                   ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T CombinedOp_SetOfOtherFeesId                 ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T CombinedOp_TraderThirdId                    ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T CombinedOp_NetSettleAmount                  ; /* WEALTH-9095 - SENTHIL - 20240529 */

extern FIELD_IDX_T A_PosValHist_PtfId                      ;
extern FIELD_IDX_T A_PosValHist_ValuationDate              ;
extern FIELD_IDX_T A_PosValHist_ConstructDate              ;


extern FIELD_IDX_T S_PosValHist_PtfId                      ;
extern FIELD_IDX_T S_PosValHist_ValuationDate              ;
extern FIELD_IDX_T S_PosValHist_ConstructDate              ;
extern FIELD_IDX_T S_PosValHist_PtfCd                      ;


extern FIELD_IDX_T Adm_Arg_Id                              ;
extern FIELD_IDX_T Adm_Arg_CodifId                         ;
extern FIELD_IDX_T Adm_Arg_PtfPpsInstrId                   ;
extern FIELD_IDX_T Adm_Arg_EntDictId                       ;
extern FIELD_IDX_T Adm_Arg_SynEntDictId                    ;
extern FIELD_IDX_T Adm_Arg_AttrDictId                      ;
extern FIELD_IDX_T Adm_Arg_UserId                          ;
extern FIELD_IDX_T Adm_Arg_FctDictId                       ;
extern FIELD_IDX_T Adm_Arg_NatEn                           ;
extern FIELD_IDX_T Adm_Arg_Date                            ;
extern FIELD_IDX_T Adm_Arg_Flag                            ;
extern FIELD_IDX_T Adm_Arg_Sysname                         ;
extern FIELD_IDX_T Adm_Arg_StatusEn                        ;
extern FIELD_IDX_T Adm_Arg_Code                            ;
extern FIELD_IDX_T Adm_Arg_Date2                           ;
extern FIELD_IDX_T Adm_Arg_Code2                           ;
extern FIELD_IDX_T Adm_Arg_InstrCodifId                    ;
extern FIELD_IDX_T Adm_Arg_CurrCodifId                     ;
extern FIELD_IDX_T Adm_Arg_DepositCodifId                  ;
extern FIELD_IDX_T Adm_Arg_LangageCodifId                  ;
extern FIELD_IDX_T Adm_Arg_GeoCodifId                      ;
extern FIELD_IDX_T Adm_Arg_ManagerCodifId                  ;
extern FIELD_IDX_T Adm_Arg_PtfCodifId                      ;
extern FIELD_IDX_T Adm_Arg_SectorCodifId                   ;
extern FIELD_IDX_T Adm_Arg_ThirdCodifId                    ;
extern FIELD_IDX_T Adm_Arg_TypeCodifId                     ;
extern FIELD_IDX_T Adm_Arg_LangDictId                      ;
extern FIELD_IDX_T Adm_Arg_TimeStamp                       ; /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T Adm_Arg_ProcessId                       ; /* PMSTA07422 - DDV - 090528 */
extern FIELD_IDX_T Adm_Arg_BusEntityCodifId                ;    /*  HFI-PMSTA-17655-140218  */
extern FIELD_IDX_T Adm_Arg_Date3                           ; /* PMSTA-25331 - TEB - 20171018 */
extern FIELD_IDX_T Adm_Arg_Integer                         ; /* PMSTA-34827 - JBC - 19021 */
extern FIELD_IDX_T Adm_Arg_Note                            ;    /*  HFI-PMSTA-38849-200714  */
extern FIELD_IDX_T Adm_Arg_ReturnStatus                    ; /* PMSTA-46404 - DDV - 211006 */
extern FIELD_IDX_T Adm_Arg_Info                            ; /*PMSTA-37628 - AIS - 191029*/

/* REF11780 - 100406 - PMO */
extern FIELD_IDX_T Sql_Result_Id                           ;
extern FIELD_IDX_T Sql_Result_TimeStamp                    ;

extern FIELD_IDX_T Array_X_ArrayX                          ;


extern FIELD_IDX_T Array_XY_ArrayX                         ;
extern FIELD_IDX_T Array_XY_ArrayY                         ;


extern FIELD_IDX_T Chrono_Arg_InstrId                      ;
extern FIELD_IDX_T Chrono_Arg_NatEn                        ;
extern FIELD_IDX_T Chrono_Arg_BegDate                      ;
extern FIELD_IDX_T Chrono_Arg_EndDate                      ;
extern FIELD_IDX_T Chrono_Arg_CurrId                       ;
extern FIELD_IDX_T Chrono_Arg_TimeDimEn                    ;
extern FIELD_IDX_T Chrono_Arg_ValidityFlg                  ;
extern FIELD_IDX_T Chrono_Arg_ThirdPartyId                 ; /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_Arg_ThirdPartyFlg                ; /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_Arg_SubNatTypeId                 ; /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_Arg_SubNatFlg                    ; /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_Arg_StratId                      ; /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_Arg_StratFlg                     ; /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_Arg_ComplNatEn                   ; /* PMSTA06646 - LJE - 080612 */

extern FIELD_IDX_T Chrono_FreqArg_ObjId                    ;
extern FIELD_IDX_T Chrono_FreqArg_NatEn                    ;
extern FIELD_IDX_T Chrono_FreqArg_TillDate                 ;
extern FIELD_IDX_T Chrono_FreqArg_Reading                  ;
extern FIELD_IDX_T Chrono_FreqArg_Freq                     ;
extern FIELD_IDX_T Chrono_FreqArg_FreqUnitEn               ;
extern FIELD_IDX_T Chrono_FreqArg_CurrId                   ;
extern FIELD_IDX_T Chrono_FreqArg_ObjEn                    ;
extern FIELD_IDX_T Chrono_FreqArg_MethodEn                 ;  /* REF7061 - TEB - 030826 */
extern FIELD_IDX_T Chrono_FreqArg_ThirdPartyId             ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_FreqArg_ThirdPartyFlg            ;  /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_FreqArg_SubNatTypeId             ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_FreqArg_SubNatFlg                ;  /* REF10598 - LJE - 041006 */
extern FIELD_IDX_T Chrono_FreqArg_StratId                  ;  /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_FreqArg_StratFlg                 ;  /* PMSTA06646 - LJE - 080612 */
extern FIELD_IDX_T Chrono_FreqArg_ComplNatEn               ;  /* PMSTA06646 - LJE - 080612 */


extern FIELD_IDX_T ExchRate_Arg_CurrId                     ;
extern FIELD_IDX_T ExchRate_Arg_UnderCurrId                ;
extern FIELD_IDX_T ExchRate_Arg_TpId                       ;
extern FIELD_IDX_T ExchRate_Arg_ThirdId                    ;
extern FIELD_IDX_T ExchRate_Arg_MktThirdId                 ;
extern FIELD_IDX_T ExchRate_Arg_ExchDate                   ;
extern FIELD_IDX_T ExchRate_Arg_TpMandatFlg                ;
extern FIELD_IDX_T ExchRate_Arg_ThirdMandatFlg             ;


extern FIELD_IDX_T ExchRate_FreqArg_CurrId                 ;
extern FIELD_IDX_T ExchRate_FreqArg_UnderCurrId            ;
extern FIELD_IDX_T ExchRate_FreqArg_TillDate               ;
extern FIELD_IDX_T ExchRate_FreqArg_Reading                ;
extern FIELD_IDX_T ExchRate_FreqArg_Freq                   ;
extern FIELD_IDX_T ExchRate_FreqArg_FreqUnitEn             ;
extern FIELD_IDX_T ExchRate_FreqArg_HistoRuleEn            ;


extern FIELD_IDX_T Sel_Arg_Id1                             ;
extern FIELD_IDX_T Sel_Arg_Id2                             ;
extern FIELD_IDX_T Sel_Arg_Id3                             ;
extern FIELD_IDX_T Sel_Arg_Id4                             ;
extern FIELD_IDX_T Sel_Arg_FromDate                        ;
extern FIELD_IDX_T Sel_Arg_TillDate                        ;
extern FIELD_IDX_T Sel_Arg_DistinctFlg                     ;
extern FIELD_IDX_T Sel_Arg_Enum1                           ; /* PMSTA-22496 - DDV - 160509 */
extern FIELD_IDX_T Sel_Arg_Enum2                           ;
extern FIELD_IDX_T Sel_Arg_DictId1                         ; /* PMSTA-22496 - DDV - 160511 */
extern FIELD_IDX_T Sel_Arg_ServerId                        ;
extern FIELD_IDX_T Sel_Arg_Flag1                           ;
extern FIELD_IDX_T Sel_Arg_Flag2                           ;
extern FIELD_IDX_T Sel_Arg_IntMin                          ;
extern FIELD_IDX_T Sel_Arg_IntMax                          ;

extern FIELD_IDX_T InstrPrice_Arg_InstrId                  ;
extern FIELD_IDX_T InstrPrice_Arg_CurrId                   ;
extern FIELD_IDX_T InstrPrice_Arg_TpId                     ;
extern FIELD_IDX_T InstrPrice_Arg_ThirdId                  ;
extern FIELD_IDX_T InstrPrice_Arg_TermTpId                 ;
extern FIELD_IDX_T InstrPrice_Arg_MktThirdId               ;
extern FIELD_IDX_T InstrPrice_Arg_QuoteDate                ;
extern FIELD_IDX_T InstrPrice_Arg_BusEntityRule            ; /* PMSTA-32141 CMILOS 200718 */
extern FIELD_IDX_T InstrPrice_Arg_BusEntityMandatFlg       ; /* PMSTA-32141 CMILOS 200718 */
extern FIELD_IDX_T InstrPrice_Arg_CurrMandatFlg            ;
extern FIELD_IDX_T InstrPrice_Arg_TpMandatFlg              ;
extern FIELD_IDX_T InstrPrice_Arg_ThirdMandatFlg           ;
extern FIELD_IDX_T InstrPrice_Arg_TermMandatFlg            ;
extern FIELD_IDX_T InstrPrice_Arg_MktMandatFlg             ;
extern FIELD_IDX_T InstrPrice_Arg_ValRuleId                ;
extern FIELD_IDX_T InstrPrice_Arg_ValRuleCoefNatEn         ;
extern FIELD_IDX_T InstrPrice_Arg_ValidityPeriod           ;
extern FIELD_IDX_T InstrPrice_Arg_AdjTypeRank              ; /* PMSTA-10049 - LJE - 101006 */
extern FIELD_IDX_T InstrPrice_Arg_PtfId					   ; /* PMSTA-32157 - SILPA - 180905*/


extern FIELD_IDX_T InstrPrice_FreqArg_InstrId              ;
extern FIELD_IDX_T InstrPrice_FreqArg_TillDate             ;
extern FIELD_IDX_T InstrPrice_FreqArg_Reading              ;
extern FIELD_IDX_T InstrPrice_FreqArg_Freq                 ;
extern FIELD_IDX_T InstrPrice_FreqArg_FreqUnitEn           ;
extern FIELD_IDX_T InstrPrice_FreqArg_HistoRuleEn          ;


extern FIELD_IDX_T Evt_Arg_InstrId                         ;
extern FIELD_IDX_T Evt_Arg_ValidDate                       ;
extern FIELD_IDX_T Evt_Arg_BegDate                         ;
extern FIELD_IDX_T Evt_Arg_EndDate                         ;
extern FIELD_IDX_T Evt_Arg_NatEn                           ;


extern FIELD_IDX_T Fus_Arg_DictId                          ;
extern FIELD_IDX_T Fus_Arg_Id                              ;
extern FIELD_IDX_T Fus_Arg_BegDate                         ;
extern FIELD_IDX_T Fus_Arg_EndDate                         ;
extern FIELD_IDX_T Fus_Arg_Flg                             ;
extern FIELD_IDX_T Fus_Arg_AutomaticFlg                    ;
extern FIELD_IDX_T Fus_Arg_PtfSize                         ;
extern FIELD_IDX_T Fus_Arg_RequestId                       ;
extern FIELD_IDX_T Fus_Arg_PtfTransfFlg                    ;
extern FIELD_IDX_T Fus_Arg_SyncModeFlg                     ;
extern FIELD_IDX_T Fus_Arg_SuperUserFlg                    ;
extern FIELD_IDX_T Fus_Arg_StockId                         ;
extern FIELD_IDX_T Fus_Arg_StockPtfNbr                     ;
extern FIELD_IDX_T Fus_Arg_PtfListId                       ;
extern FIELD_IDX_T Fus_Arg_PtfReqList                      ;
extern FIELD_IDX_T Fus_Arg_PrivateFusSrvId                 ; /* DLA - PMSTA07062 - 080825 */
extern FIELD_IDX_T Fus_Arg_ApplSessionCd                   ; /* DLA - PMSTA07062 - 080825 */
extern FIELD_IDX_T Fus_Arg_ParentEventSchedId              ; /* PMSTA-32289 - 240718 - PMO */
extern FIELD_IDX_T Fus_Arg_FusionPrioEn                    ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T Fus_Arg_ServerId                        ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T Fus_Arg_SyncTimeOut                     ;
extern FIELD_IDX_T Fus_Arg_RequestUserId                   ;
extern FIELD_IDX_T Fus_Arg_FusionRetryNb                   ; /* PMSTA-61044 - JBC - 20241018 */

extern FIELD_IDX_T Bu_Arg_Id                               ; /* PMSTA-51720 - 160123 - Sathees + */
extern FIELD_IDX_T Bu_Arg_Code                             ;
extern FIELD_IDX_T Bu_Arg_ApplSessionCd                    ; /* PMSTA-51720 - 160123 - Sathees - */

extern FIELD_IDX_T UearEntity_Id                           ; /* WEALTH-5698 - 290224 - Sathees + */
extern FIELD_IDX_T UearEntity_DictId                       ;
extern FIELD_IDX_T UearEntityDSP_Id                        ;
extern FIELD_IDX_T UearEntityDSP2_Id                       ; /* WEALTH-5698 - 290224 - Sathees - */

extern FIELD_IDX_T Fus_Sync_RequestId                      ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T Fus_Sync_SyncModeFlg                    ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T Fus_Sync_SyncTimeOut;
extern FIELD_IDX_T Fus_Sync_IoId;

extern FIELD_IDX_T GetVersion_Arg_MajorCd                  ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_MinorCd                  ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_StampCd                  ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_OsCd                     ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_BitsCd                   ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_Host                     ; /* PMSTA-24510 - 220816 - PMO *//* DLA - PMSTA-27503 - 170615 */
extern FIELD_IDX_T GetVersion_Arg_ServerName               ; /* PMSTA-24510 - 220816 - PMO */
extern FIELD_IDX_T GetVersion_Arg_Impl_Build               ;

extern FIELD_IDX_T GetSrvEnv_Arg_Environment               ;

extern FIELD_IDX_T Chk_Arg_Id                              ;
extern FIELD_IDX_T Chk_Arg_EntDictId                       ;
extern FIELD_IDX_T Chk_Arg_MinLen                          ;
extern FIELD_IDX_T Chk_Arg_MaxLen                          ;
extern FIELD_IDX_T Chk_Arg_DefInt                          ;
extern FIELD_IDX_T Chk_Arg_SynEnt                          ;
extern FIELD_IDX_T Chk_Arg_Ent                             ;
extern FIELD_IDX_T Chk_Arg_Cd                              ;
extern FIELD_IDX_T Chk_Arg_Val                             ;
extern FIELD_IDX_T Chk_Arg_SybName                         ;
extern FIELD_IDX_T Chk_Arg_TpId                            ;
extern FIELD_IDX_T Chk_Arg_ParFlg                          ;
extern FIELD_IDX_T Chk_Arg_ParId                           ;
extern FIELD_IDX_T Chk_Arg_NatEn                           ;
extern FIELD_IDX_T Chk_Arg_ReturnStatus;
extern FIELD_IDX_T Chk_Arg_Date;

extern FIELD_IDX_T Del_Arg_Id                              ;
extern FIELD_IDX_T Del_Arg_Cd                              ;
extern FIELD_IDX_T Del_Arg_NatEn                           ;
extern FIELD_IDX_T Del_Arg_TypeId                          ;
extern FIELD_IDX_T Del_Arg_PtfId                           ;    /* PMSTA-6921 - 311008 - PMO */
extern FIELD_IDX_T Del_Arg_Integer                         ;    /* PMSTA-34827 - JBC - 19021 */

extern FIELD_IDX_T Get_Arg_Id                              ;
extern FIELD_IDX_T Get_Arg_ThirdId                         ;
extern FIELD_IDX_T Get_Arg_TpId                            ;
extern FIELD_IDX_T Get_Arg_CodifId                         ;
extern FIELD_IDX_T Get_Arg_ObjId                           ;
extern FIELD_IDX_T Get_Arg_RefCurrId                       ;
extern FIELD_IDX_T Get_Arg_Cd                              ;
extern FIELD_IDX_T Get_Arg_NatEn                           ;
extern FIELD_IDX_T Get_Arg_Date                            ;
extern FIELD_IDX_T Get_Arg_ShortDate                       ;
extern FIELD_IDX_T Get_Arg_EntDictId                       ;
extern FIELD_IDX_T Get_Arg_AttribDictId                    ;
extern FIELD_IDX_T Get_Arg_FctDictId                       ;
extern FIELD_IDX_T Get_Arg_UserId                          ;
extern FIELD_IDX_T Get_Arg_DateTime                        ;
extern FIELD_IDX_T Get_Arg_Integer                         ;
extern FIELD_IDX_T Get_Arg_Integer2                        ;
extern FIELD_IDX_T Get_Arg_NatEn2                          ;
extern FIELD_IDX_T Get_Arg_Flag                            ;
extern FIELD_IDX_T Get_Arg_Flag2                           ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_Flag3                           ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_Flag4                           ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_Flag5                           ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_DimPtfDictId                    ;
extern FIELD_IDX_T Get_Arg_PtfId                           ;
extern FIELD_IDX_T Get_Arg_InstrId                         ;
extern FIELD_IDX_T Get_Arg_PtfPosSetId                     ;
extern FIELD_IDX_T Get_Arg_StatEn                          ;
extern FIELD_IDX_T Get_Arg_PosNatEn                        ;
extern FIELD_IDX_T Get_Arg_Enum1                           ;
extern FIELD_IDX_T Get_Arg_Enum2                           ;
extern FIELD_IDX_T Get_Arg_Enum3                           ;
extern FIELD_IDX_T Get_Arg_Enum4                           ;
extern FIELD_IDX_T Get_Arg_Enum5                           ;
extern FIELD_IDX_T Get_Arg_DateTime2                       ;
extern FIELD_IDX_T Get_Arg_Cd2                             ;
extern FIELD_IDX_T Get_Arg_Number                          ;
extern FIELD_IDX_T Get_Arg_Longname                        ;
extern FIELD_IDX_T Get_Arg_ScreenDictId                    ;
extern FIELD_IDX_T Get_Arg_DerivedFlg                      ;
extern FIELD_IDX_T Get_Arg_LangDictId                      ; /* REF9529 - LJE - 031008 */
extern FIELD_IDX_T Get_Arg_Text	                           ; /* REF11832 - RAK - 060608 */
extern FIELD_IDX_T Get_Arg_OpenOpId                        ; /* REF11828 - RAK - 060608 */
extern FIELD_IDX_T Get_Arg_BalPosTpId                      ; /* REF11828 - RAK - 060608 */
extern FIELD_IDX_T Get_Arg_String1000                      ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_String2000                      ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_String3000                      ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_String4000                      ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_String7000                      ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_String15000                     ; /* PMSTA13167 - DDV - 111215 */
extern FIELD_IDX_T Get_Arg_Smallint                        ; /* PMSTA-18593 - LJE - 151026 */
extern FIELD_IDX_T Get_Arg_Smallint2                       ; /* PMSTA-18593 - LJE - 151026 */
extern FIELD_IDX_T Get_Arg_CompoundScreenDictId            ; /* PMSTA-18601 - DDV - 141030 */
extern FIELD_IDX_T Get_Arg_ApplSessionCd                   ; /* PMSTA-22549 - CHU - 160512 */
extern FIELD_IDX_T Get_Arg_EventId                         ; /* PMSTA-32288 - JBC - 190215 */
extern FIELD_IDX_T Get_Arg_ServerId                        ; /* PMSTA-32288 - JBC - 190215 */
extern FIELD_IDX_T Get_Arg_ReturnStatus                    ;    /*  HFI-PMSTA-44888-210423  */

extern FIELD_IDX_T Get_Arg2_Id                             ;
extern FIELD_IDX_T Get_Arg2_PtfId                          ;
extern FIELD_IDX_T Get_Arg2_FromDate                       ;
extern FIELD_IDX_T Get_Arg2_TillDate                       ;
extern FIELD_IDX_T Get_Arg2_AccNbr                         ;
extern FIELD_IDX_T Get_Arg2_ClientDataType                 ;
extern FIELD_IDX_T Get_Arg2_ClientVersion                  ;
extern FIELD_IDX_T Get_Arg2_OsVersion                      ;
extern FIELD_IDX_T Get_Arg2_UserCd                         ;
extern FIELD_IDX_T Get_Arg2_ProcessId                      ;
extern FIELD_IDX_T Get_Arg2_LoginDateTime                  ;
extern FIELD_IDX_T Get_Arg2_DeltaDateTime                  ;
extern FIELD_IDX_T Get_Arg2_Mode                           ;


extern FIELD_IDX_T Flow_Arg_InstrId                        ;
extern FIELD_IDX_T Flow_Arg_RefDate                        ;
extern FIELD_IDX_T Flow_Arg_ValDate                        ;
extern FIELD_IDX_T Flow_Arg_Pos                            ;
extern FIELD_IDX_T Flow_Arg_Cnt                            ;
extern FIELD_IDX_T Flow_Arg_NatEn                          ;
extern FIELD_IDX_T Flow_Arg_SubNatEn                       ;
extern FIELD_IDX_T Flow_Arg_EvtDateRule                    ;


extern FIELD_IDX_T ApplMsg_Arg_Cd                          ;
extern FIELD_IDX_T ApplMsg_Arg_LangDictId                  ;
extern FIELD_IDX_T ApplMsg_Arg_NatEn                       ;


extern FIELD_IDX_T FundVal_Arg_PtfId                       ;
extern FIELD_IDX_T FundVal_Arg_ValuationDate               ;
extern FIELD_IDX_T FundVal_Arg_TimeDimension               ;
extern FIELD_IDX_T FundVal_Arg_ValoSeqNo                   ;
extern FIELD_IDX_T FundVal_Arg_AccNbr                      ;
extern FIELD_IDX_T FundVal_Arg_InstrId                     ;
extern FIELD_IDX_T FundVal_Arg_OfficialFlg                 ;


extern FIELD_IDX_T Operator_DataTp                         ;
extern FIELD_IDX_T Operator_Value                          ;
extern FIELD_IDX_T Operator_Tp                             ;


extern FIELD_IDX_T Srv_Connect_Id                          ;
extern FIELD_IDX_T Srv_Connect_Status                      ;
extern FIELD_IDX_T Srv_Connect_Dialog                      ;
extern FIELD_IDX_T Srv_Connect_User                        ;
extern FIELD_IDX_T Srv_Connect_HostName                    ;
extern FIELD_IDX_T Srv_Connect_ModuleName                  ;
extern FIELD_IDX_T Srv_Connect_DateTime                    ;
extern FIELD_IDX_T Srv_Connect_Charset                     ;


extern FIELD_IDX_T A_Test_String                           ;
extern FIELD_IDX_T A_Test_Sequence                         ;

/* REF10342 - LJE - 040608 */
extern FIELD_IDX_T A_CallCollectCmd_String                 ;
extern FIELD_IDX_T A_CallCollectCmd_Sequence               ;
extern FIELD_IDX_T A_CallCollectCmd_CommandEn              ;
extern FIELD_IDX_T A_CallCollectCmd_ScreenDictId           ;
extern FIELD_IDX_T A_CallCollectCmd_LanguageDictId         ;


extern FIELD_IDX_T Out_Date_Date                           ;


extern FIELD_IDX_T Out_Number_Number                       ;


extern FIELD_IDX_T MeanCapReturn_Arg_FromDate              ;
extern FIELD_IDX_T MeanCapReturn_Arg_TillDate              ;
extern FIELD_IDX_T MeanCapReturn_Arg_PtfId                 ;
extern FIELD_IDX_T MeanCapReturn_Arg_MktSgtId              ;
extern FIELD_IDX_T MeanCapReturn_Arg_InstrId               ;
extern FIELD_IDX_T MeanCapReturn_Arg_GridId                ;
extern FIELD_IDX_T MeanCapReturn_Arg_MethodEn              ;
extern FIELD_IDX_T MeanCapReturn_Arg_TaxCredFlg            ;
extern FIELD_IDX_T MeanCapReturn_Arg_GrossEffectFlg        ;
extern FIELD_IDX_T MeanCapReturn_Arg_GrossFeesFlg          ;
extern FIELD_IDX_T MeanCapReturn_Arg_GrossTaxFlg           ;
extern FIELD_IDX_T MeanCapReturn_Arg_RiskFlg               ;
extern FIELD_IDX_T MeanCapReturn_Arg_AnnualRuleEn          ;
extern FIELD_IDX_T MeanCapReturn_Arg_AlwaysInitialDtFlg    ;
extern FIELD_IDX_T MeanCapReturn_Arg_RetContribFlg         ;
extern FIELD_IDX_T MeanCapReturn_Arg_ExcludeIncFlg         ;
extern FIELD_IDX_T MeanCapReturn_Arg_Level                 ;
extern FIELD_IDX_T MeanCapReturn_Arg_PSPId                 ; /* REF9264 - LJE - 031021 */
extern FIELD_IDX_T MeanCapReturn_Arg_ExcludePosFeesFlg     ; /* REF11269 - LJE - 051220 */
extern FIELD_IDX_T MeanCapReturn_Arg_ExcludePosTaxFlg      ; /* REF11269 - LJE - 051220 */


extern FIELD_IDX_T RiskRatio_Arg_EndDate                   ;
extern FIELD_IDX_T RiskRatio_Arg_BeginDate                 ;
extern FIELD_IDX_T RiskRatio_Arg_FreqUnit                  ;
extern FIELD_IDX_T RiskRatio_Arg_YearFlg                   ;
extern FIELD_IDX_T RiskRatio_Arg_ScriptRtn                 ;
extern FIELD_IDX_T RiskRatio_Arg_ScriptBenchRtn            ;
extern FIELD_IDX_T RiskRatio_Arg_ScriptRiskRtn             ;


extern FIELD_IDX_T Io_Id_Id                                ;

extern FIELD_IDX_T Io_Ext_Ext                              ;

extern FIELD_IDX_T Io_Flg_Flg                              ;

extern FIELD_IDX_T Io_Info_Info                            ;

extern FIELD_IDX_T FmtEltDef_FmtId                         ;
extern FIELD_IDX_T FmtEltDef_FmtEltRank                    ;
extern FIELD_IDX_T FmtEltDef_DataSetIndex                  ;
extern FIELD_IDX_T FmtEltDef_ColIndex                      ;
extern FIELD_IDX_T FmtEltDef_DspFmt                        ;
extern FIELD_IDX_T FmtEltDef_SqlName                       ;
extern FIELD_IDX_T FmtEltDef_HierNatEn                     ;
extern FIELD_IDX_T FmtEltDef_DataTpDictId                  ;
extern FIELD_IDX_T FmtEltDef_Denom                         ;


extern FIELD_IDX_T DataDef_ColNum                          ;
extern FIELD_IDX_T DataDef_Datatype                        ;
extern FIELD_IDX_T DataDef_RefKeyIndex                     ;
extern FIELD_IDX_T DataDef_RefKeyNbr                       ;
extern FIELD_IDX_T DataDef_RefKeyEntDictId                 ;
extern FIELD_IDX_T DataDef_ClassifId                       ;
extern FIELD_IDX_T DataDef_SortCol                         ;
extern FIELD_IDX_T DataDef_ZoomFlg                         ;


extern FIELD_IDX_T PtfFusion_DimPortDictId                 ;
extern FIELD_IDX_T PtfFusion_PortObjectId                  ;
extern FIELD_IDX_T PtfFusion_FusDate                       ;
extern FIELD_IDX_T PtfFusion_FusScopeFlg                   ;


extern FIELD_IDX_T ListMgmArg_FctEn                        ;
extern FIELD_IDX_T ListMgmArg_EntDictId                    ;
extern FIELD_IDX_T ListMgmArg_ListId                       ;
extern FIELD_IDX_T ListMgmArg_ScriptDef                    ;
extern FIELD_IDX_T ListMgmArg_AllEntListFlg                ;


extern FIELD_IDX_T ExtStratLnk_Id                          ;
extern FIELD_IDX_T ExtStratLnk_StratId                     ;
extern FIELD_IDX_T ExtStratLnk_LnkObjDictId                ;
extern FIELD_IDX_T ExtStratLnk_ObjId                       ;
extern FIELD_IDX_T ExtStratLnk_PtfId                       ;
extern FIELD_IDX_T ExtStratLnk_ListId                      ;
extern FIELD_IDX_T ExtStratLnk_ParStratId                  ;
extern FIELD_IDX_T ExtStratLnk_GridId                      ;
extern FIELD_IDX_T ExtStratLnk_GridListId                  ;
extern FIELD_IDX_T ExtStratLnk_ParGridId                   ;
extern FIELD_IDX_T ExtStratLnk_MktSegId                    ;
extern FIELD_IDX_T ExtStratLnk_FctResultId                 ;
extern FIELD_IDX_T ExtStratLnk_LnkParStratId               ;
extern FIELD_IDX_T ExtStratLnk_ParExtStratLnkId            ;
extern FIELD_IDX_T ExtStratLnk_ParStratMktSgtId            ;
extern FIELD_IDX_T ExtStratLnk_ParentPtfId                 ;
extern FIELD_IDX_T ExtStratLnk_TradConstrId                ;
extern FIELD_IDX_T ExtStratLnk_DerivedStratId              ;
extern FIELD_IDX_T ExtStratLnk_ModelConstrId               ;
extern FIELD_IDX_T ExtStratLnk_RefStratId                  ;
extern FIELD_IDX_T ExtStratLnk_LnkNatEn                    ;
extern FIELD_IDX_T ExtStratLnk_BegDate                     ;
extern FIELD_IDX_T ExtStratLnk_EndDate                     ;
extern FIELD_IDX_T ExtStratLnk_Priority                    ;
extern FIELD_IDX_T ExtStratLnk_StratNatEn                  ;
extern FIELD_IDX_T ExtStratLnk_DirectFlg                   ;
extern FIELD_IDX_T ExtStratLnk_CheckedEn                   ;
extern FIELD_IDX_T ExtStratLnk_ConvFactPrct                ;
extern FIELD_IDX_T ExtStratLnk_Level                       ;
extern FIELD_IDX_T ExtStratLnk_CalcEn                      ;
extern FIELD_IDX_T ExtStratLnk_SubNatEn                    ;
extern FIELD_IDX_T ExtStratLnk_ConstrNatEn                 ;
extern FIELD_IDX_T ExtStratLnk_DerivFailedReasonEn         ;
extern FIELD_IDX_T ExtStratLnk_CriticalnessEn              ;
extern FIELD_IDX_T ExtStratLnk_RiskFlg                     ;
extern FIELD_IDX_T ExtStratLnk_ParStrat_ExtStratLnk_Ext    ;
extern FIELD_IDX_T ExtStratLnk_ParGrid_ExtStratLnk_Ext     ;
extern FIELD_IDX_T ExtStratLnk_A_Strat_Ext                 ;
extern FIELD_IDX_T ExtStratLnk_A_StratHist_Ext             ;
extern FIELD_IDX_T ExtStratLnk_ExtStratElt_Ext             ;
extern FIELD_IDX_T ExtStratLnk_Par_ExtStratLnk_Ext         ;
extern FIELD_IDX_T ExtStratLnk_Child_ExtStratLnk_Ext       ;
extern FIELD_IDX_T ExtStratLnk_MktSgtInstr_Ext             ;
extern FIELD_IDX_T ExtStratLnk_Marg                        ;
extern FIELD_IDX_T ExtStratLnk_TotIdx                      ;
extern FIELD_IDX_T ExtStratLnk_A_Grid_Ext                  ;
extern FIELD_IDX_T ExtStratLnk_S_MktSgt_Ext                ;
extern FIELD_IDX_T ExtStratLnk_A_ModelConstr_Ext           ;
extern FIELD_IDX_T ExtStratLnk_A_DerivedStrat_Ext          ;
extern FIELD_IDX_T ExtStratLnk_StratLevel                  ;
extern FIELD_IDX_T ExtStratLnk_Weight                      ; /* PMSTA7387-VST-090205 */
extern FIELD_IDX_T ExtStratLnk_WeightNatEn                 ; /* PMSTA7387-VST-090205 */
extern FIELD_IDX_T ExtStratLnk_UbikFlg                     ; /* OCS41979-CHU-121102 */
extern FIELD_IDX_T ExtStratLnk_StratNatIPId                ; /* PMSTA-30897-CHU-180528 */
extern FIELD_IDX_T ExtStratLnk_SubModelFlg                 ; /*PMSTA06840-Vishnu-16012020 */
extern FIELD_IDX_T ExtStratLnk_ParSubModelStratId          ; /*PMSTA06840-Vishnu-16012020 */
extern FIELD_IDX_T ExtStratLnk_ParModelValue               ; /*PMSTA06840-Vishnu-16012020 */
extern FIELD_IDX_T ExtStratLnk_OverlayPtfId                ; /* PMSTA-39048 - vkumar - 240220 */
extern FIELD_IDX_T ExtStratLnk_NoTargetWeightEn            ; /* PMSTA-40203 - sanand - 20072020 */
extern FIELD_IDX_T ExtStratLnk_LowerMarg				   ; /* PMSTA-40213-badhri-23072020 */
extern FIELD_IDX_T ExtStratLnk_UpperMarg				   ; /* PMSTA-40213-badhri-23072020 */
extern FIELD_IDX_T ExtStratLnk_OriginalModelConstrId	   ; /* PMSTA-48867-Satya */
extern FIELD_IDX_T ExtStratLnk_OrigPortfolioId			   ; /* WEALTH-5953-Ravindra-25042023 */

extern FIELD_IDX_T ExtStratElt_Id                          ;
extern FIELD_IDX_T ExtStratElt_FctResultId                 ;
extern FIELD_IDX_T ExtStratElt_ExtStratLnkId               ;
extern FIELD_IDX_T ExtStratElt_ParExtStratEltId            ;
extern FIELD_IDX_T ExtStratElt_StratId                     ;
extern FIELD_IDX_T ExtStratElt_StratHistId                 ;
extern FIELD_IDX_T ExtStratElt_GridId                      ;
extern FIELD_IDX_T ExtStratElt_MktSegtId                   ;
extern FIELD_IDX_T ExtStratElt_AbsClassifId                ;
extern FIELD_IDX_T ExtStratElt_OrdClassifId                ;
extern FIELD_IDX_T ExtStratElt_AbsListId                   ;
extern FIELD_IDX_T ExtStratElt_OrdListId                   ;
extern FIELD_IDX_T ExtStratElt_ParStratId                  ;
extern FIELD_IDX_T ExtStratElt_ParMktSegtId                ;
extern FIELD_IDX_T ExtStratElt_BenchEntDictId              ;
extern FIELD_IDX_T ExtStratElt_PtfId                       ;
extern FIELD_IDX_T ExtStratElt_PtfListId                   ;
extern FIELD_IDX_T ExtStratElt_InstrId                     ;
extern FIELD_IDX_T ExtStratElt_RiskParInstrId              ;
extern FIELD_IDX_T ExtStratElt_DepoId                      ;
extern FIELD_IDX_T ExtStratElt_PosCurrId                   ;
extern FIELD_IDX_T ExtStratElt_InstrCurrId                 ;
extern FIELD_IDX_T ExtStratElt_RefCurrId                   ;
extern FIELD_IDX_T ExtStratElt_CrtQuoteCurrId              ;
extern FIELD_IDX_T ExtStratElt_OrderQuoteCurrId            ;
extern FIELD_IDX_T ExtStratElt_AcctCurrId                  ;
extern FIELD_IDX_T ExtStratElt_HedgeCurrId                 ;
extern FIELD_IDX_T ExtStratElt_TermTpId                    ;
extern FIELD_IDX_T ExtStratElt_LockTpId                    ;
extern FIELD_IDX_T ExtStratElt_BenchObjId                  ;
extern FIELD_IDX_T ExtStratElt_OrdParExtStratEltId         ;
extern FIELD_IDX_T ExtStratElt_DispParExtStratEltId        ;
extern FIELD_IDX_T ExtStratElt_TradConstrId                ;
extern FIELD_IDX_T ExtStratElt_ModelConstrEltId            ;
extern FIELD_IDX_T ExtStratElt_AnaBenchEntDictId           ;
extern FIELD_IDX_T ExtStratElt_AnaBenchObjId               ;
extern FIELD_IDX_T ExtStratElt_Level                       ;
extern FIELD_IDX_T ExtStratElt_Denom                       ;
extern FIELD_IDX_T ExtStratElt_Rank                        ;
extern FIELD_IDX_T ExtStratElt_NatEn                       ;
extern FIELD_IDX_T ExtStratElt_ForecastFlg                 ;
extern FIELD_IDX_T ExtStratElt_RiskNatEn                   ;
extern FIELD_IDX_T ExtStratElt_AcctFlg                     ;
extern FIELD_IDX_T ExtStratElt_Proba                       ;
extern FIELD_IDX_T ExtStratElt_StatusEn                    ;
extern FIELD_IDX_T ExtStratElt_OpDate                      ;
extern FIELD_IDX_T ExtStratElt_AcctDate                    ;
extern FIELD_IDX_T ExtStratElt_ValueDate                   ;
extern FIELD_IDX_T ExtStratElt_ActualQty                   ;
extern FIELD_IDX_T ExtStratElt_ObjQty                      ;
extern FIELD_IDX_T ExtStratElt_EffQty                      ;
extern FIELD_IDX_T ExtStratElt_OrderQty                    ;
extern FIELD_IDX_T ExtStratElt_CostQuote                   ;
extern FIELD_IDX_T ExtStratElt_CostPriceCalcRuleEn         ;
extern FIELD_IDX_T ExtStratElt_CostPrice                   ;
extern FIELD_IDX_T ExtStratElt_CostExchRate                ;
extern FIELD_IDX_T ExtStratElt_CrtQuote                    ;
extern FIELD_IDX_T ExtStratElt_CrtPriceCalcRuleEn          ;
extern FIELD_IDX_T ExtStratElt_CrtPrice                    ;
extern FIELD_IDX_T ExtStratElt_CrtExchRate                 ;
extern FIELD_IDX_T ExtStratElt_OrderQuote                  ;
extern FIELD_IDX_T ExtStratElt_OrderPriceCalcRuleEn        ;
extern FIELD_IDX_T ExtStratElt_OrderPrice                  ;
extern FIELD_IDX_T ExtStratElt_AcctExchRate                ;
extern FIELD_IDX_T ExtStratElt_CostGrossVal                ;
extern FIELD_IDX_T ExtStratElt_CostNetVal                  ;
extern FIELD_IDX_T ExtStratElt_CrtNetVal                   ;
extern FIELD_IDX_T ExtStratElt_CrtMktVal                   ;
extern FIELD_IDX_T ExtStratElt_OrderAcctNetAmt             ;
extern FIELD_IDX_T ExtStratElt_ObjWeight                   ;
extern FIELD_IDX_T ExtStratElt_ObjWeightMarg               ;
extern FIELD_IDX_T ExtStratElt_ObjWeightContrib            ;
extern FIELD_IDX_T ExtStratElt_ObjWeightContribMarg        ;
extern FIELD_IDX_T ExtStratElt_MaxWeight                   ;
extern FIELD_IDX_T ExtStratElt_MaxWeightContrib            ;
extern FIELD_IDX_T ExtStratElt_MinWeight                   ;
extern FIELD_IDX_T ExtStratElt_MinWeightContrib            ;
extern FIELD_IDX_T ExtStratElt_ActualWeight                ;
extern FIELD_IDX_T ExtStratElt_ActualWeightContrib         ;
extern FIELD_IDX_T ExtStratElt_EffWeight                   ;
extern FIELD_IDX_T ExtStratElt_EffWeightContrib            ;
extern FIELD_IDX_T ExtStratElt_ObjWeightCheckEn            ;
extern FIELD_IDX_T ExtStratElt_MaxWeightCheckEn            ;
extern FIELD_IDX_T ExtStratElt_MinWeightCheckEn            ;
extern FIELD_IDX_T ExtStratElt_ObjDura                     ;
extern FIELD_IDX_T ExtStratElt_ObjDuraMarg                 ;
extern FIELD_IDX_T ExtStratElt_ObjDuraContrib              ;
extern FIELD_IDX_T ExtStratElt_ObjDuraContribMarg          ;
extern FIELD_IDX_T ExtStratElt_ActualDura                  ;
extern FIELD_IDX_T ExtStratElt_ActualDuraContrib           ;
extern FIELD_IDX_T ExtStratElt_EffDura                     ;
extern FIELD_IDX_T ExtStratElt_EffDuraContrib              ;
extern FIELD_IDX_T ExtStratElt_ObjDuraCheckEn              ;
extern FIELD_IDX_T ExtStratElt_ObjBeta                     ;
extern FIELD_IDX_T ExtStratElt_ObjBetaMarg                 ;
extern FIELD_IDX_T ExtStratElt_ObjBetaContrib              ;
extern FIELD_IDX_T ExtStratElt_ObjBetaContribMarg          ;
extern FIELD_IDX_T ExtStratElt_ActualBeta                  ;
extern FIELD_IDX_T ExtStratElt_ActualBetaContrib           ;
extern FIELD_IDX_T ExtStratElt_EffBeta                     ;
extern FIELD_IDX_T ExtStratElt_EffBetaContrib              ;
extern FIELD_IDX_T ExtStratElt_ObjBetaCheckEn              ;
extern FIELD_IDX_T ExtStratElt_ObjCrtYield                 ;
extern FIELD_IDX_T ExtStratElt_ObjCrtYieldMarg             ;
extern FIELD_IDX_T ExtStratElt_ObjCrtYieldContrib          ;
extern FIELD_IDX_T ExtStratElt_ObjCrtYieldContribMarg      ;
extern FIELD_IDX_T ExtStratElt_ActualCrtYield              ;
extern FIELD_IDX_T ExtStratElt_ActualCrtYieldContrib       ;
extern FIELD_IDX_T ExtStratElt_EffCrtYield                 ;
extern FIELD_IDX_T ExtStratElt_EffCrtYieldContrib          ;
extern FIELD_IDX_T ExtStratElt_ObjCrtYieldCheckEn          ;
extern FIELD_IDX_T ExtStratElt_ObjTrackErr                 ;
extern FIELD_IDX_T ExtStratElt_ObjTrackErrMarg             ;
extern FIELD_IDX_T ExtStratElt_ActualTrackErr              ;
extern FIELD_IDX_T ExtStratElt_EffTrackErr                 ;
extern FIELD_IDX_T ExtStratElt_ObjTrackErrCheckEn          ;
extern FIELD_IDX_T ExtStratElt_CompChronoNat               ; /*PMSTA05345-CHU-080430*/
extern FIELD_IDX_T ExtStratElt_CompChronoCompNat              ; /*PMSTA05345-CHU-080430*/
extern FIELD_IDX_T ExtStratElt_MinRatingRank               ;
extern FIELD_IDX_T ExtStratElt_ActualRatingRank            ;
extern FIELD_IDX_T ExtStratElt_MinRatingCheckEn            ;
extern FIELD_IDX_T ExtStratElt_ObjConstrVal                ;
extern FIELD_IDX_T ExtStratElt_ObjConstrMarg               ;
extern FIELD_IDX_T ExtStratElt_ObjConstrLimitNatEn         ;
extern FIELD_IDX_T ExtStratElt_ActConstrVal                ;
extern FIELD_IDX_T ExtStratElt_ConstrCheckEn               ;
extern FIELD_IDX_T ExtStratElt_RecomNatEn                  ;
extern FIELD_IDX_T ExtStratElt_ActualOrderNatEn            ;
extern FIELD_IDX_T ExtStratElt_RecomCheckEn                ;
extern FIELD_IDX_T ExtStratElt_StratCheckEn                ;
extern FIELD_IDX_T ExtStratElt_SubstratCheckEn             ;
extern FIELD_IDX_T ExtStratElt_StratNatEn                  ;
extern FIELD_IDX_T ExtStratElt_StratLevel                  ;
extern FIELD_IDX_T ExtStratElt_ExtOpId                     ;
extern FIELD_IDX_T ExtStratElt_TradedNatureEn              ;
extern FIELD_IDX_T ExtStratElt_RoundLotQty                 ;
extern FIELD_IDX_T ExtStratElt_MinOrderQty                 ;
extern FIELD_IDX_T ExtStratElt_RoundLotAmt                 ;
extern FIELD_IDX_T ExtStratElt_MinTradingAmt               ;
extern FIELD_IDX_T ExtStratElt_AvailableQty                ;
extern FIELD_IDX_T ExtStratElt_OpNatEn                     ;
extern FIELD_IDX_T ExtStratElt_StratEltId                  ;
extern FIELD_IDX_T ExtStratElt_CalcEn                      ;
extern FIELD_IDX_T ExtStratElt_StopQuote                   ;
extern FIELD_IDX_T ExtStratElt_StopPrice                   ;
extern FIELD_IDX_T ExtStratElt_OrderValidityNatEn          ;
extern FIELD_IDX_T ExtStratElt_OrderLimitDate              ;
extern FIELD_IDX_T ExtStratElt_OrderSubNatEn               ;
extern FIELD_IDX_T ExtStratElt_SubPosNatEn                 ;
extern FIELD_IDX_T ExtStratElt_ChildPtfId                  ;
extern FIELD_IDX_T ExtStratElt_CriticalnessEn              ; /* REF11231-CHU-050630 */
extern FIELD_IDX_T ExtStratElt_MarketThirdId               ; /*PMSTA08359-BRO-090624*/
extern FIELD_IDX_T ExtStratElt_InvestProfileId			   ; /* PMSTA-38228 - LIK - 17122019 */
extern FIELD_IDX_T ExtStratElt_ModelConstrId               ; /* PMSTA-13122 - LJE - 120628 */
extern FIELD_IDX_T ExtStratElt_ExtPosId                    ;
extern FIELD_IDX_T ExtStratElt_FixedCellFlg                ;
extern FIELD_IDX_T ExtStratElt_Priority                    ;
extern FIELD_IDX_T ExtStratElt_InitialDate                 ;
extern FIELD_IDX_T ExtStratElt_FinalDate                   ;
extern FIELD_IDX_T ExtStratElt_SubPeriodNatMask            ;
extern FIELD_IDX_T ExtStratElt_BenchRtn                    ;
extern FIELD_IDX_T ExtStratElt_PSPId                       ; /* REF9125 - LJE - 030818 */
extern FIELD_IDX_T ExtStratElt_BenchRtnCurr                ; /* REF9227 - LJE - 030918 */
extern FIELD_IDX_T ExtStratElt_ConstrBoundNatEn            ; /*REF10599-BRO-041020*/
extern FIELD_IDX_T ExtStratElt_ConstrPriority              ; /*REF10599-BRO-041020*/
extern FIELD_IDX_T ExtStratElt_ConstrTreatEn               ; /*REF10599-BRO-041020*/
extern FIELD_IDX_T ExtStratElt_DynObjWeight			       ; /* REF11457-RAK-050928 */
extern FIELD_IDX_T ExtStratElt_OldObjWeight			       ; /* REF11457-EFE-051004 */
extern FIELD_IDX_T ExtStratElt_SelectedFlg                 ; /*  FIH-REF11457-051014 */
extern FIELD_IDX_T ExtStratElt_LeafFlg                     ; /*  FIH-REF11457-051024 */
extern FIELD_IDX_T ExtStratElt_IgnoreMarginFlg             ; /*PMSTA00970-BRO-070209*/
extern FIELD_IDX_T ExtStratElt_OrigObjWeightContrib        ; /* PMSTA15213-CHU-121107 */
extern FIELD_IDX_T ExtStratElt_TargetNatureEn              ; /* OCS43530-CHU-131015 */
extern FIELD_IDX_T ExtStratElt_ActRiskESEltId              ; /*PMSTA-18426-CHU-140919*/
extern FIELD_IDX_T ExtStratElt_EffRiskESEltId              ; /*PMSTA-18426-CHU-140919*/
extern FIELD_IDX_T ExtStratElt_LombardCheckId              ; /* PMSTA-20940-CHU-151006 */
extern FIELD_IDX_T ExtStratElt_EndDate                     ; /*PMSTA00965-CHU-070425*/
extern FIELD_IDX_T ExtStratElt_Min                         ; /*PMSTA05345-BRO-080219*/
extern FIELD_IDX_T ExtStratElt_Max                         ; /*PMSTA05345-BRO-080219*/
extern FIELD_IDX_T ExtStratElt_Par_ExtStratElt_Ext         ;
extern FIELD_IDX_T ExtStratElt_LnkPar_ExtStratElt_Ext      ;
extern FIELD_IDX_T ExtStratElt_OrdPar_ExtStratElt_Ext      ;
extern FIELD_IDX_T ExtStratElt_A_ScriptDef_Ext             ;
extern FIELD_IDX_T ExtStratElt_A_HoldConstrScript_Ext      ; /* PMSTA-28970 - CHU - 171226 */
extern FIELD_IDX_T ExtStratElt_A_TradConstrScript_Ext      ; /* PMSTA-28970 - CHU - 171226 */
extern FIELD_IDX_T ExtStratElt_ModelReading                ;
extern FIELD_IDX_T ExtStratElt_NodeNatEn                   ;
extern FIELD_IDX_T ExtStratElt_ActualWeightContribCalc     ;
extern FIELD_IDX_T ExtStratElt_PosStatEn                   ;
extern FIELD_IDX_T ExtStratElt_CrtNetValForDura            ;
extern FIELD_IDX_T ExtStratElt_CrtMktValForDura            ;
extern FIELD_IDX_T ExtStratElt_WeightedDura				   ; /* PMSTA-8822 - RAK - 091103 */
extern FIELD_IDX_T ExtStratElt_LimitQuote                  ;
extern FIELD_IDX_T ExtStratElt_LimitPrice                  ;
extern FIELD_IDX_T ExtStratElt_IntraMktSgtFlg              ;
extern FIELD_IDX_T ExtStratElt_SellPriority                ;
extern FIELD_IDX_T ExtStratElt_EditBackupPtr               ;
extern FIELD_IDX_T ExtStratElt_MktSegtPriority             ;
extern FIELD_IDX_T ExtStratElt_MktStructLevel              ;
extern FIELD_IDX_T ExtStratElt_InstrNatEn                  ;
extern FIELD_IDX_T ExtStratElt_RefStratId                  ; /* REF10270 - RAK - 040601 */
extern FIELD_IDX_T ExtStratElt_SubPosNat2En                ; /* REF10624 - CHU - 040924 */
extern FIELD_IDX_T ExtStratElt_SubPosNat3En                ; /* REF10624 - CHU - 040924 */
extern FIELD_IDX_T ExtStratElt_ChildBenchObjIdFlg          ; /* REF9125 - MCA - 031030 */ /*PMSTA00970-BRO-070209*/
extern FIELD_IDX_T ExtStratElt_OldObjWeightContribMarg     ; /* PMSTA00967-CHU-070104 */
extern FIELD_IDX_T ExtStratElt_DerivMarginToProcessFlg     ; /* PMSTA02593-CHU-070919 */
extern FIELD_IDX_T ExtStratElt_AttachToPtfHeadFlg          ; /* PMSTA06840-CHU-080723 */
extern FIELD_IDX_T ExtStratElt_Weight                      ; /* PMSTA7387-VST-090205 */
extern FIELD_IDX_T ExtStratElt_WeightNatEn                 ; /* PMSTA7387-VST-090205 */
extern FIELD_IDX_T ExtStratElt_CoreSatOrigStratId          ; /* PMSTA-18284 - CHU - 140619 */
extern FIELD_IDX_T ExtStratElt_RiskRuleCompoId             ; /* PMSTA-20235 - CHU - 150416  */
extern FIELD_IDX_T ExtStratElt_MinInvestAmount			   ; /* PMSTA-38326-MUTHU-02012020 */
extern FIELD_IDX_T ExtStratElt_MaxInvestAmount			   ; /* PMSTA-38326-MUTHU-02012020 */
extern FIELD_IDX_T ExtStratElt_InvestCheckEn			   ; /* PMSTA-38326-MUTHU-02012020   */
extern FIELD_IDX_T ExtStratElt_SubModelFlg		           ; /* PMSTA06840-Vishnu-16012020*/
extern FIELD_IDX_T ExtStratElt_DimStratDictId			   ; /* PMSTA-39045-BADHRI-140220 */
extern FIELD_IDX_T ExtStratElt_StratObjId				   ; /* PMSTA-39045-BADHRI-140220 */
extern FIELD_IDX_T ExtStratElt_OverlayPtfId                ; /* PMSTA-39048 - vkumar - 240220 */
extern FIELD_IDX_T ExtStratElt_OrderAllocRulesEn		   ; /* PMSTA-40055 - vmuthu - 11052020 */
extern FIELD_IDX_T ExtStratElt_OrderBuyAllocRulesEn		   ; /* PMSTA-40055 - vmuthu - 11052020 */
extern FIELD_IDX_T ExtStratElt_ObjWeightExclSubModel       ; /* PMSTA-40170 - 130520 - vkumar */
extern FIELD_IDX_T ExtStratElt_ActWeightExclSubModel       ; /* PMSTA-40170 - 130520 - vkumar */
extern FIELD_IDX_T ExtStratElt_EffWeightExclSubModel       ; /* PMSTA-40170 - 130520 - vkumar */
extern FIELD_IDX_T ExtStratElt_AllocationRulePcnt		   ; /* PMSTA-40055 - vmuthu - 01062020 */
extern FIELD_IDX_T ExtStratElt_ProRataQty				   ; /* PMSTA-40055 - vmuthu - 01062020 */
extern FIELD_IDX_T ExtStratElt_ExcludedFlg                 ; /* PMSTA-39969 - sanand - 05052020 */
extern FIELD_IDX_T ExtStratElt_NoTargetWeightEn            ; /* PMSTA-40203 - sanand - 17062020*/
extern FIELD_IDX_T ExtStratElt_ObjLowerMarg				   ; /* PMSTA-40213 - vmuthu - 20082020 */
extern FIELD_IDX_T ExtStratElt_ObjLowerContribMarg		   ; /* PMSTA-40213 - vmuthu - 20082020 */
extern FIELD_IDX_T ExtStratElt_ObjUpperMarg				   ; /* PMSTA-40213 - vmuthu - 20082020 */
extern FIELD_IDX_T ExtStratElt_ObjUpperContribMarg		   ; /* PMSTA-40213 - vmuthu - 20082020 */
extern FIELD_IDX_T ExtStratElt_OldObjLowerContribMarg	   ; /* PMSTA-40213 - badhri - 23072020 */
extern FIELD_IDX_T ExtStratElt_OldObjUpperContribMarg	   ; /* PMSTA-40213 - badhri - 23072020 */
extern FIELD_IDX_T ExtStratElt_OrderOrgQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtStratElt_SmartRoundingQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtStratElt_SmartRoundingRuleId         ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtStratElt_OrigObjWgtContMarg		   ; /* PMSTA-41767 - VIG	 - 11092020 */
extern FIELD_IDX_T ExtStratElt_MinThreshold                ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_MaxThreshold                ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_CashForecastM               ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_CashDeviationAmount         ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_MinForecast                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_MaxForecast                 ; /* PMSTA-42402 -Vishnu- 11112020 Auto Cash*/
extern FIELD_IDX_T ExtStratElt_OrdQtyPreFullRedemp         ; /* PMSTA-43100 - sanand - 29122020 */
extern FIELD_IDX_T ExtStratElt_QuasiCashEn				   ; /* PMSTA-43175-Badhri-21122020 */
extern FIELD_IDX_T ExtStratElt_CrtMktValExclSubModelm      ; /* PMSTA-46776 - Vishnu - 26112021 autocash */
extern FIELD_IDX_T ExtStratElt_SeverityRuleId			   ; /*PMSTA-47502-Lalby-04032022*/
extern FIELD_IDX_T ExtStratElt_SeverityRuleElementId	   ; /*PMSTA-47502-Lalby-04032022*/
extern FIELD_IDX_T ExtStratElt_DeviationGapN			   ; /*PMSTA-47502-Lalby-04032022*/
extern FIELD_IDX_T ExtStratElt_DeviationDurationN		   ; /*PMSTA-47502-Lalby-04032022*/
extern FIELD_IDX_T ExtStratElt_PtfOrderExistsFlg           ; /* PMSTA-50493 - JPR - 220920 */
extern FIELD_IDX_T ExtStratElt_ActMktVal                   ; /*PMSTA-51353-Satya-04012023*/
extern FIELD_IDX_T ExtStratElt_PtfScope                    ; /*PMSTA-51355-Satya*/
extern FIELD_IDX_T ExtStratElt_RiskVolElt                  ; /* WEALTH-1593 - JPR - 230831 */
extern FIELD_IDX_T ExtStratElt_SecInConstraint			   ; /*PMSTA-52191-Ravindra-15092023*/
extern FIELD_IDX_T ExtStratElt_ModTradingConstraint		   ; /*PMSTA-52191-Ravindra-15092023*/
extern FIELD_IDX_T ExtStratElt_OrderAmount					; /*WEALTH-16688-Satya*/
extern FIELD_IDX_T ExtStratElt_InitialDelFlg               ; /* PMSTA-62692 - KOR - 20241612 */


extern FIELD_IDX_T ExtStratElt_Elt_Dura                    ;
extern FIELD_IDX_T ExtStratElt_Elt_Beta                    ;
extern FIELD_IDX_T ExtStratElt_Elt_CrtYield                ;
extern FIELD_IDX_T ExtStratElt_Elt_TrackErr                ;
extern FIELD_IDX_T ExtStratElt_Elt_RatingRank              ;
extern FIELD_IDX_T ExtStratElt_Elt_Weight                  ;
extern FIELD_IDX_T ExtStratElt_Elt_WeightCalc              ;
extern FIELD_IDX_T ExtStratElt_Elt_CalcEn                  ;

/* PMSTA-18426 - CHU - 140923 */
extern FIELD_IDX_T A_RiskESElt_Id                          ;
extern FIELD_IDX_T A_RiskESElt_ExtStratEltId               ;
extern FIELD_IDX_T A_RiskESElt_RiskStratId                 ;
extern FIELD_IDX_T A_RiskESElt_FctResultId                 ;
extern FIELD_IDX_T A_RiskESElt_PostOrderFlg                ;
extern FIELD_IDX_T A_RiskESElt_A_RiskESEltCompo_Ext        ;
extern FIELD_IDX_T A_RiskESElt_ValidDataFlg                ;

/* PMSTA-18426 - CHU - 141014 */
extern FIELD_IDX_T A_RiskESEltCompo_Id                     ;
extern FIELD_IDX_T A_RiskESEltCompo_FctResultId            ;
extern FIELD_IDX_T A_RiskESEltCompo_RiskESEltId            ;
extern FIELD_IDX_T A_RiskESEltCompo_RiskNatEn              ;
extern FIELD_IDX_T A_RiskESEltCompo_DatatypeDictId         ;
extern FIELD_IDX_T A_RiskESEltCompo_ObjPct                 ;
extern FIELD_IDX_T A_RiskESEltCompo_ObjAmt                 ;
extern FIELD_IDX_T A_RiskESEltCompo_MinObjPct              ;
extern FIELD_IDX_T A_RiskESEltCompo_MaxObjPct              ;
extern FIELD_IDX_T A_RiskESEltCompo_MinObjAmt              ;
extern FIELD_IDX_T A_RiskESEltCompo_MaxObjAmt              ;
extern FIELD_IDX_T A_RiskESEltCompo_ActPct                 ;
extern FIELD_IDX_T A_RiskESEltCompo_ActAmt                 ;
extern FIELD_IDX_T A_RiskESEltCompo_SeverityEn             ;
extern FIELD_IDX_T A_RiskESEltCompo_CheckEn                ;
extern FIELD_IDX_T A_RiskESEltCompo_Contrib                ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskESEltCompo_MarginalContrib        ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskESEltCompo_IncrementalContrib     ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskESEltCompo_StatusEn               ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskESEltCompo_ComputationDate        ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskESEltCompo_RiskValEltCmpId        ; /* PMSTA-64803 - VPR - 20250202*/

/* PMSTA-18426 - CHU - 141014 */
extern FIELD_IDX_T A_RiskValueEltCompo_Id                  ;
extern FIELD_IDX_T A_RiskValueEltCompo_RiskValueEltId      ;
extern FIELD_IDX_T A_RiskValueEltCompo_IndicatorNatEn      ;
extern FIELD_IDX_T A_RiskValueEltCompo_IndicatorValPct     ;
extern FIELD_IDX_T A_RiskValueEltCompo_IndicatorValAmt     ;
extern FIELD_IDX_T A_RiskValueEltCompo_Contrib             ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskValueEltCompo_MarginalContrib     ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskValueEltCompo_IncrementalContrib  ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskValueEltCompo_StatusEn            ; /* PMSTA-30990 - CHU - 180417 */
extern FIELD_IDX_T A_RiskValueEltCompo_CurrId              ;

/* PMSTA-18426 - CHU - 141014 */
extern FIELD_IDX_T S_RiskValueEltCompo_Id                  ;
extern FIELD_IDX_T S_RiskValueEltCompo_RiskValueEltId      ;
extern FIELD_IDX_T S_RiskValueEltCompo_IndicatorNatEn      ;
extern FIELD_IDX_T S_RiskValueEltCompo_RiskValueElt        ;

extern FIELD_IDX_T SumRes_Id                               ;
extern FIELD_IDX_T SumRes_Level                            ;
extern FIELD_IDX_T SumRes_BreakVal                         ;
extern FIELD_IDX_T SumRes_Val                              ;
extern FIELD_IDX_T SumRes_CmpEn                            ;
extern FIELD_IDX_T SumRes_CmpVal                           ;
extern FIELD_IDX_T SumRes_CmpMarg                          ;
extern FIELD_IDX_T SumRes_CheckFlg                         ;
extern FIELD_IDX_T SumRes_SumResElt_Ext                    ;


extern FIELD_IDX_T SumResElt_ExtPosId                      ;
extern FIELD_IDX_T SumResElt_SumResId                      ;
extern FIELD_IDX_T SumResElt_Val                           ;
extern FIELD_IDX_T SumResElt_ExtPos_Ext                    ;


extern FIELD_IDX_T ExtOp_DbId                              ;
extern FIELD_IDX_T ExtOp_NatureEn                          ;
extern FIELD_IDX_T ExtOp_OpId                              ;
extern FIELD_IDX_T ExtOp_FctResultId                       ;
extern FIELD_IDX_T ExtOp_Cd                                ;
extern FIELD_IDX_T ExtOp_FusionEn                          ;
extern FIELD_IDX_T ExtOp_InputUserId                       ;
extern FIELD_IDX_T ExtOp_TpId                              ;
extern FIELD_IDX_T ExtOp_SubTpId                           ;
extern FIELD_IDX_T ExtOp_MktThirdId                        ;
extern FIELD_IDX_T ExtOp_IntermThirdId                     ;
extern FIELD_IDX_T ExtOp_MgrId                             ;
extern FIELD_IDX_T ExtOp_RuleId                            ;
extern FIELD_IDX_T ExtOp_ValRuleEltId                      ;
extern FIELD_IDX_T ExtOp_SrcCd                             ;
extern FIELD_IDX_T ExtOp_SubPosNatEn                       ;
extern FIELD_IDX_T ExtOp_SubPosNat2En                      ;
extern FIELD_IDX_T ExtOp_SubPosNat3En                      ;
extern FIELD_IDX_T ExtOp_AdjSubPosNatEn                    ;
extern FIELD_IDX_T ExtOp_AdjSubPosNat2En                   ;
extern FIELD_IDX_T ExtOp_AdjSubPosNat3En                   ;
extern FIELD_IDX_T ExtOp_LockSubPosNatEn                   ;
extern FIELD_IDX_T ExtOp_LockSubPosNat2En                  ;
extern FIELD_IDX_T ExtOp_LockSubPosNat3En                  ;
extern FIELD_IDX_T ExtOp_LimitQuote                        ;
extern FIELD_IDX_T ExtOp_LimitPrice                        ;
extern FIELD_IDX_T ExtOp_StopQuote                         ;
extern FIELD_IDX_T ExtOp_StopPrice                         ;
extern FIELD_IDX_T ExtOp_OrderPriceNatEn                   ;
extern FIELD_IDX_T ExtOp_OrderValidNatEn                   ;
extern FIELD_IDX_T ExtOp_MinOrderQty                       ;
extern FIELD_IDX_T ExtOp_ValoSeqNo                         ;
extern FIELD_IDX_T ExtOp_ParOpCd                           ;
extern FIELD_IDX_T ExtOp_ParOpNatEn                        ;
extern FIELD_IDX_T ExtOp_CheckParentEn                     ;
extern FIELD_IDX_T ExtOp_CheckStratEn                      ;
extern FIELD_IDX_T ExtOp_OrderNatEn                        ;
extern FIELD_IDX_T ExtOp_BeginDate                         ;
extern FIELD_IDX_T ExtOp_EndDate                           ;
extern FIELD_IDX_T ExtOp_AcctDate                          ;
extern FIELD_IDX_T ExtOp_OpDate                            ;
extern FIELD_IDX_T ExtOp_ValuationDate                     ;
extern FIELD_IDX_T ExtOp_OrderLimitDate                    ;
extern FIELD_IDX_T ExtOp_ValueDate                         ;
extern FIELD_IDX_T ExtOp_RefOpCd                           ;
extern FIELD_IDX_T ExtOp_RefNatEn                          ;
extern FIELD_IDX_T ExtOp_StatusEn                          ;
extern FIELD_IDX_T ExtOp_SequenceNo                        ;
extern FIELD_IDX_T ExtOp_AcctCd                            ;
extern FIELD_IDX_T ExtOp_OpenOpCd                          ;
extern FIELD_IDX_T ExtOp_PtfId                             ;
extern FIELD_IDX_T ExtOp_PortPosSetId                      ;
extern FIELD_IDX_T ExtOp_AdjPtfId                          ;
extern FIELD_IDX_T ExtOp_CashPtfId                         ;
extern FIELD_IDX_T ExtOp_InstrId                           ;
extern FIELD_IDX_T ExtOp_ToInstrId                         ;
extern FIELD_IDX_T ExtOp_BalPosTpId                        ;
extern FIELD_IDX_T ExtOp_FromBpTpId                        ;
extern FIELD_IDX_T ExtOp_ToBpTpId                          ;
extern FIELD_IDX_T ExtOp_AcctId                            ;
extern FIELD_IDX_T ExtOp_Acct2Id                           ;
extern FIELD_IDX_T ExtOp_Acct3Id                           ;
extern FIELD_IDX_T ExtOp_LockInstrId                       ;
extern FIELD_IDX_T ExtOp_DepoId                            ;
extern FIELD_IDX_T ExtOp_LockDepoId                        ;
extern FIELD_IDX_T ExtOp_AdjInstrId                        ;
extern FIELD_IDX_T ExtOp_AdjDepoId                         ;
extern FIELD_IDX_T ExtOp_AdjBpTpId                         ;
extern FIELD_IDX_T ExtOp_OpCurrId                          ;
extern FIELD_IDX_T ExtOp_InstrCurrId                       ;
extern FIELD_IDX_T ExtOp_ToInstrCurrId                     ;
extern FIELD_IDX_T ExtOp_PtfCurrId                         ;
extern FIELD_IDX_T ExtOp_AcctCurrId                        ;
extern FIELD_IDX_T ExtOp_Acct2CurrId                       ;
extern FIELD_IDX_T ExtOp_Acct3CurrId                       ;
extern FIELD_IDX_T ExtOp_TradeCurrId                       ;
extern FIELD_IDX_T ExtOp_AdjInstrCurrId                    ;
extern FIELD_IDX_T ExtOp_AdjPosCurrId                      ;
extern FIELD_IDX_T ExtOp_AdjPortCurrId                     ;
extern FIELD_IDX_T ExtOp_CashPtfCurrId                     ;
extern FIELD_IDX_T ExtOp_LockOpCurrId                      ;
extern FIELD_IDX_T ExtOp_LockFiCurrId                      ;
extern FIELD_IDX_T ExtOp_CntPtyThirdId                     ;
extern FIELD_IDX_T ExtOp_TermTpId                          ;
extern FIELD_IDX_T ExtOp_LockTpId                          ;
extern FIELD_IDX_T ExtOp_AccrIntrBpTpId                    ;
extern FIELD_IDX_T ExtOp_ExtStratEltId                     ;
extern FIELD_IDX_T ExtOp_CloseOperId                       ;
extern FIELD_IDX_T ExtOp_CloseOperCd                       ;
extern FIELD_IDX_T ExtOp_ParentExtOpId                     ;
extern FIELD_IDX_T ExtOp_ExtOrderId                        ;
extern FIELD_IDX_T ExtOp_ExecSetCriteria                   ;
extern FIELD_IDX_T ExtOp_AdjNatEn                          ;
extern FIELD_IDX_T ExtOp_ExecOpId                          ;
extern FIELD_IDX_T ExtOp_ExecOpCd                          ;
extern FIELD_IDX_T ExtOp_ExecOpNatEn                       ;
extern FIELD_IDX_T ExtOp_ExecOpStatEn                      ;
extern FIELD_IDX_T ExtOp_RevOpCd                           ;
extern FIELD_IDX_T ExtOp_RevOpNatEn                        ;
extern FIELD_IDX_T ExtOp_LockOpCd                          ;
extern FIELD_IDX_T ExtOp_LockNatEn                         ;
extern FIELD_IDX_T ExtOp_EvtCd                             ;
extern FIELD_IDX_T ExtOp_EvtNbr                            ;
extern FIELD_IDX_T ExtOp_ExCouponFlg                       ;
extern FIELD_IDX_T ExtOp_FusRuleEn                         ;
extern FIELD_IDX_T ExtOp_LockLimitDate                     ;
extern FIELD_IDX_T ExtOp_ExpirDate                         ;
extern FIELD_IDX_T ExtOp_Remark                            ;
extern FIELD_IDX_T ExtOp_OpExchRate                        ;
extern FIELD_IDX_T ExtOp_InstrExchRate                     ;
extern FIELD_IDX_T ExtOp_SysExchRate                       ;
extern FIELD_IDX_T ExtOp_AcctExchRate                      ;
extern FIELD_IDX_T ExtOp_Acct2ExchRate                     ;
extern FIELD_IDX_T ExtOp_Acct3ExchRate                     ;
extern FIELD_IDX_T ExtOp_TradeExchRate                     ;
extern FIELD_IDX_T ExtOp_CashPtfExchRate                   ;
extern FIELD_IDX_T ExtOp_AdjInstrExchRate                  ;
extern FIELD_IDX_T ExtOp_AdjPosExchRate                    ;
extern FIELD_IDX_T ExtOp_AdjPtfExchRate                    ;
extern FIELD_IDX_T ExtOp_HistOpExchRate                    ;
extern FIELD_IDX_T ExtOp_HistInstrExchRate                 ;
extern FIELD_IDX_T ExtOp_HistSysExchRate                   ;
extern FIELD_IDX_T ExtOp_BookOpExchRate                    ;
extern FIELD_IDX_T ExtOp_BookInstrExchRate                 ;
extern FIELD_IDX_T ExtOp_BookSysExchRate                   ;
extern FIELD_IDX_T ExtOp_LockOpExchRate                    ;
extern FIELD_IDX_T ExtOp_LockFiExchRate                    ;
extern FIELD_IDX_T ExtOp_AdjQty                            ;
extern FIELD_IDX_T ExtOp_Qty                               ;
extern FIELD_IDX_T ExtOp_LockQty                           ;
extern FIELD_IDX_T ExtOp_Price                             ;
extern FIELD_IDX_T ExtOp_SpotPrice                         ;
extern FIELD_IDX_T ExtOp_HistPrice                         ;
extern FIELD_IDX_T ExtOp_BookPrice                         ;
extern FIELD_IDX_T ExtOp_LockDirtyPrice                    ;
extern FIELD_IDX_T ExtOp_LockCleanPrice                    ;
extern FIELD_IDX_T ExtOp_PriceCalcRuleEn                   ;
extern FIELD_IDX_T ExtOp_Quote                             ;
extern FIELD_IDX_T ExtOp_SpotQuote                         ;
extern FIELD_IDX_T ExtOp_HistQuote                         ;
extern FIELD_IDX_T ExtOp_BookQuote                         ;
extern FIELD_IDX_T ExtOp_LockDirtyQuote                    ;
extern FIELD_IDX_T ExtOp_LockCleanQuote                    ;
extern FIELD_IDX_T ExtOp_Rate                              ;
extern FIELD_IDX_T ExtOp_LockPriceMargin                   ;
extern FIELD_IDX_T ExtOp_SupplAmt                          ;
extern FIELD_IDX_T ExtOp_OpGrossAmt                        ;
extern FIELD_IDX_T ExtOp_AccrIntrAmt                       ;
extern FIELD_IDX_T ExtOp_OpNetAmt                          ;
extern FIELD_IDX_T ExtOp_InstrNetAmt                       ;
extern FIELD_IDX_T ExtOp_PtfNetAmt                         ;
extern FIELD_IDX_T ExtOp_SysNetAmt                         ;
extern FIELD_IDX_T ExtOp_AdjPosNetAmt                      ;
extern FIELD_IDX_T ExtOp_AdjPtfNetAmt                      ;
extern FIELD_IDX_T ExtOp_AcctNetAmt                        ;
extern FIELD_IDX_T ExtOp_Acct2NetAmt                       ;
extern FIELD_IDX_T ExtOp_Acct3NetAmt                       ;
extern FIELD_IDX_T ExtOp_HistOpNetAmt                      ;
extern FIELD_IDX_T ExtOp_HistInstrNetAmt                   ;
extern FIELD_IDX_T ExtOp_HistPtfNetAmt                     ;
extern FIELD_IDX_T ExtOp_HistSysNetAmt                     ;
extern FIELD_IDX_T ExtOp_BookOpNetAmt                      ;
extern FIELD_IDX_T ExtOp_BookInstrNetAmt                   ;
extern FIELD_IDX_T ExtOp_BookPtfNetAmt                     ;
extern FIELD_IDX_T ExtOp_BookSysNetAmt                     ;
extern FIELD_IDX_T ExtOp_Bp1TpId                           ;
extern FIELD_IDX_T ExtOp_Bp1CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp1Amt                            ;
extern FIELD_IDX_T ExtOp_Bp2TpId                           ;
extern FIELD_IDX_T ExtOp_Bp2CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp2Amt                            ;
extern FIELD_IDX_T ExtOp_Bp3TpId                           ;
extern FIELD_IDX_T ExtOp_Bp3CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp3Amt                            ;
extern FIELD_IDX_T ExtOp_Bp4TpId                           ;
extern FIELD_IDX_T ExtOp_Bp4CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp4Amt                            ;
extern FIELD_IDX_T ExtOp_Bp5TpId                           ;
extern FIELD_IDX_T ExtOp_Bp5CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp5Amt                            ;
extern FIELD_IDX_T ExtOp_Bp6TpId                           ;
extern FIELD_IDX_T ExtOp_Bp6CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp6Amt                            ;
extern FIELD_IDX_T ExtOp_Bp7TpId                           ;
extern FIELD_IDX_T ExtOp_Bp7CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp7Amt                            ;
extern FIELD_IDX_T ExtOp_Bp8TpId                           ;
extern FIELD_IDX_T ExtOp_Bp8CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp8Amt                            ;
extern FIELD_IDX_T ExtOp_Bp9TpId                           ;
extern FIELD_IDX_T ExtOp_Bp9CurrId                         ;
extern FIELD_IDX_T ExtOp_Bp9Amt                            ;
extern FIELD_IDX_T ExtOp_Bp10TpId                          ;
extern FIELD_IDX_T ExtOp_Bp10CurrId                        ;
extern FIELD_IDX_T ExtOp_Bp10Amt                           ;
extern FIELD_IDX_T ExtOp_ConfirmedFlg                      ;
extern FIELD_IDX_T ExtOp_DbStatusEn                        ;
extern FIELD_IDX_T ExtOp_AudUserName                       ;
extern FIELD_IDX_T ExtOp_AudModifDate                      ;
extern FIELD_IDX_T ExtOp_AudAction                         ;
extern FIELD_IDX_T ExtOp_LastUserId                        ;
extern FIELD_IDX_T ExtOp_LastModifDate                     ;
extern FIELD_IDX_T ExtOp_CreationTime                      ;
extern FIELD_IDX_T ExtOp_OrderCd                           ;
extern FIELD_IDX_T ExtOp_ExecutedFlg                       ;
extern FIELD_IDX_T ExtOp_OpActionEn                        ;
extern FIELD_IDX_T ExtOp_NoPositionFlg                     ;
extern FIELD_IDX_T ExtOp_OrderGroupingCd                   ;
extern FIELD_IDX_T ExtOp_OrderModeTypeId				   ; /*<REF11810-BRO-060608*/
extern FIELD_IDX_T ExtOp_TraderMgrId					   ;
extern FIELD_IDX_T ExtOp_AutoRenewalEn					   ;
extern FIELD_IDX_T ExtOp_RenewalTreatmtEn				   ;
extern FIELD_IDX_T ExtOp_RenewalEndValDate				   ;
extern FIELD_IDX_T ExtOp_RenewalLength					   ;
extern FIELD_IDX_T ExtOp_RenewalLengthUnitEn			   ;
extern FIELD_IDX_T ExtOp_ClientInitEn					   ;
extern FIELD_IDX_T ExtOp_ContractNumber					   ;
extern FIELD_IDX_T ExtOp_TransactionNatEn				   ; /*>REF11810-BRO-060608*/
extern FIELD_IDX_T ExtOp_RenewalIntRate                    ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ExtOp_RenewalAmount                     ; /*REF11810-BRO-060628*/
extern FIELD_IDX_T ExtOp_ExecutionId                       ;
extern FIELD_IDX_T ExtOp_GlExecFeeId                       ;
extern FIELD_IDX_T ExtOp_GroupingCriteria                  ;
extern FIELD_IDX_T ExtOp_EffectChildQty                    ;
extern FIELD_IDX_T ExtOp_FlowId                            ;
extern FIELD_IDX_T ExtOp_InitExtPosId                      ;
extern FIELD_IDX_T ExtOp_ExecQty                           ;
extern FIELD_IDX_T ExtOp_WeightMeanQuote                   ;
extern FIELD_IDX_T ExtOp_SelectedFlg                       ;    /*  FIH-REF11457-051014 */
extern FIELD_IDX_T ExtOp_InSessionFlg                      ;    /* PMSTA9052 - EFE - 091125 */
extern FIELD_IDX_T ExtOp_A_Flow_Ext                        ;
extern FIELD_IDX_T ExtOp_A_Ptf_Ext                         ;
extern FIELD_IDX_T ExtOp_A_Instr_Ext                       ;
extern FIELD_IDX_T ExtOp_Id                                ;
extern FIELD_IDX_T ExtOp_ExtOp_Ext                         ;
extern FIELD_IDX_T ExtOp_ChildExtOp_Ext                    ;
extern FIELD_IDX_T ExtOp_ParExtOp_Ext                      ;
extern FIELD_IDX_T ExtOp_SysCurrId                         ;
extern FIELD_IDX_T ExtOp_PPSCurrId                         ;
extern FIELD_IDX_T ExtOp_CopiedPtfId                       ;
extern FIELD_IDX_T ExtOp_NoCheckImpactFlg                  ;
extern FIELD_IDX_T ExtOp_ParentId                          ;
extern FIELD_IDX_T ExtOp_NoCheckSynthAdminFlg              ;
extern FIELD_IDX_T ExtOp_AutoIndex                         ;
extern FIELD_IDX_T ExtOp_EditBackupPtr                     ;
extern FIELD_IDX_T ExtOp_ExtExecution_Ext                  ;	/* REF8723 - TEB - 040218 */
extern FIELD_IDX_T ExtOp_DraftOrderId                      ;	/* REF8500 - 040510 - PMO */
extern FIELD_IDX_T ExtOp_TimeStamp                         ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T ExtOp_TimeStampNew                      ;    /* REF11780 - 100406 - PMO */
extern FIELD_IDX_T ExtOp_DerivativeOrdEn				   ; /* OCS-43683 - TGU - 131107 */
extern FIELD_IDX_T ExtOp_FxFarLegAmount					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ExtOp_FxSpotQuote					   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ExtOp_FxQuote						   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ExtOp_FxSpotLegAmount				   ; /* OCS43532-CHU-131112 */
extern FIELD_IDX_T ExtOp_OrderFeeEn						   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ExtOp_OrderFeePrct					   ; /*PMSTA17221-CHU-131113*/
extern FIELD_IDX_T ExtOp_MaxOrderQty					   ; /*OCS-43526-CHU-131213*/
extern FIELD_IDX_T ExtOp_STPOrderEn						   ; /*PMSTA-16538-CHU-131204*/
extern FIELD_IDX_T ExtOp_UnpaidPrct						   ; /*PMSTA-16533-CHU-131204*/
extern FIELD_IDX_T ExtOp_ChildPtfId                        ; /* PMSTA04637-CHU-080208 */
extern FIELD_IDX_T ExtOp_TargetNatureEn                    ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_TargetNumber                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_TargetAmount                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_MarketSegmentId                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_FactSheetEn                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_LastQuoteDate                     ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_LastQuoteNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_LastPriceNumber                   ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_CommunicationDate                 ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_CommunicationTypeId               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_CommPartyTypeId                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ExtOp_Remark1                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_Remark2                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_Remark3                           ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_TransmissionDate                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_TransmissionTypeId                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_OrderTypeId                       ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_MMInterestAmount                  ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_FxMarketRate                      ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_FxClientRate                      ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ExtOp_FxRateDirection                   ; /*PMSTA10733-TEB-101202*/
extern FIELD_IDX_T ExtOp_InterestMarketRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_DebitToSysCurrRate                ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_CreditToSysCurrRate               ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_ContractLengthNumber              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_ContractLengthUnitEn              ; /*PMSTA10733-TEB-101111*/
extern FIELD_IDX_T ExtOp_FxMarginNumber                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ExtOp_FxMarginPrct                      ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ExtOp_FxMarginAmount                    ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ExtOp_Summary                           ; /* PMSTA-11600 - RPO - 110322 */
extern FIELD_IDX_T ExtOp_EventStatusId                     ; /* PMSTA-17112 - EFE - 131210 */
extern FIELD_IDX_T ExtOp_EventActionEn                     ; /* PMSTA-17266 - DDV - 131217 */
extern FIELD_IDX_T ExtOp_CompoundOrderMasterEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtOp_CompoundOrderSlaveEltId		   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtOp_CompoundOrderCode				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtOp_CompoundOrderSlaveNbr			   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtOp_CompoundImpactRule				   ; /* PMSTA-18636 - SHR - 140905 */
extern FIELD_IDX_T ExtOp_CompoundOrderMasterElt_Ext		   ; /* PMSTA-18639 - TGU - 141021 */
extern FIELD_IDX_T ExtOp_CompoundOrderSlaveElt_Ext		   ; /* PMSTA-18639 - TGU - 141021 */
extern FIELD_IDX_T ExtOp_CompoundScreenDictId              ; /* PMSTA-18601 - DDV - 141104 */
extern FIELD_IDX_T ExtOp_CompoundSlaveCode                 ; /* PMSTA-18601 - DDV - 141120 */
extern FIELD_IDX_T ExtOp_DisplayCondition				   ; /* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ExtOp_OrderType						   ; /* PMSTA-21336 - TGU - 151013 */
extern FIELD_IDX_T ExtOp_CommonRef                         ; /* PMSTA-20886 - DDV - 151028 */
extern FIELD_IDX_T ExtOp_StandInstructIdx                  ; /* PMSTA-21265 - DDV - 151103 */
extern FIELD_IDX_T ExtOp_FlowIdx                           ; /* PMSTA-21265 - DDV - 151103 */
extern FIELD_IDX_T ExtOp_OrderInclusionEn                  ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ExtOp_OrderRejectionDate                ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ExtOp_OrderRejectionComment             ; /* PMSTA-25576 - CHU - 170403 */
extern FIELD_IDX_T ExtOp_AcquisitionDate                   ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtOp_CorporateActionNatEn              ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtOp_TaxLotSourceCd                    ; /* PMSTA-28286 - CHU - 170905 */
extern FIELD_IDX_T ExtOp_StandInstructId                   ; /* PMSTA-28684 - CHU - 171024 */
extern FIELD_IDX_T ExtOp_BankFeePrct                       ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ExtOp_BankFeeAmount                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ExtOp_BankFeeCurrId                     ; /* PMSTA-31134 - AiswaryaM - 20180504*/
extern FIELD_IDX_T ExtOp_PaymentOption                     ; /* PMSTA-30658 - AiswaryaM - 20180503*/
extern FIELD_IDX_T ExtOp_BidTypeEn                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid1Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid1Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid2Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid2Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid3Qty                           ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_Bid3Quote                         ; /* PMSTA-31709 - AiswaryaM - 20180604*/
extern FIELD_IDX_T ExtOp_CounterpartAccount                ;
extern FIELD_IDX_T ExtOp_CounterpartCurrencyId             ;
extern FIELD_IDX_T ExtOp_OpFusionRuleEn                    ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ExtOp_GlobalPosFlg                      ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ExtOp_AdjPosGrossAmt                    ; /* PMSTA-29531 - JBC - 171210 */
extern FIELD_IDX_T ExtOp_OtcOrderEn;			/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ExtOp_DefaultFusRuleEn;		/* PMSTA-34309 - RAK - 190130 */
extern FIELD_IDX_T ExtOp_CoolCancelEndDate                 ; /* PMSTA-34333 - Silpakal - 190201*/
extern FIELD_IDX_T ExtOp_FusionPrioEn                      ; /* PMSTA-32288 - JBC  - 190214 */
extern FIELD_IDX_T ExtOp_ExcludeFromBlockFlg               ; /* PMSTA-32251 -Smitha -180810*/
extern FIELD_IDX_T ExtOp_ExternalBankBic                   ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ExtOp_ExternalBankName                  ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ExtOp_ExternalBankAcctOwnrName          ; /* PMSTA-35577 - Kramadevi - 260419*/
extern FIELD_IDX_T ExtOp_HedgeTradeEn                      ; /* PMSTA-35985 - Kramadevi - 230519*/
extern FIELD_IDX_T ExtOp_FixingDate                        ; /* PMSTA-36034 - KNI - 190603*/
extern FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr1            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr2            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr3            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_ExtrnlBnkAcctOwnrAddr4            ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_PayRef1                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_PayRef2                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_PayRef3                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_PayRef4                           ; /* PMSTA-36651 - Kramadevi  - 19072019 */
extern FIELD_IDX_T ExtOp_ExternalTradeFlg                  ; /* PMSTA-36524 - Grace      - 03072019*/
extern FIELD_IDX_T ExtOp_SwitchingCriteria				   ; /* PMSTA-37058 - Silpakal - 190903*/
extern FIELD_IDX_T ExtOp_OrderCheckEn					   ; /*LIK*/
extern FIELD_IDX_T ExtOp_OriginalQty					   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T ExtOp_OrderNettingEn					   ; /* PMSTA-37908 - adarshn	 - 19112019 */
extern FIELD_IDX_T ExtOp_NettingCriteria                   ; /* PMSTA-37908 - adarshn	 - 24012020 */
extern FIELD_IDX_T ExtOp_PaymentDate                       ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtOp_PaymentStatusEn                   ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtOp_SettlementDate                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtOp_SettleStatusEn                    ; /* PMSTA-38730 - Silpakal - 200204 */
extern FIELD_IDX_T ExtOp_CommissionCdEn                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_ChargeCdEn                        ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_OriginalAmount                    ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_CounterpartOrgAmount              ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_ExternalFeeM                      ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_TotalChargesM                     ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_CounterpartAmount                 ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_OpLinkageCd                       ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_ChargedCustomerName               ; /* PMSTA-38796 - cha - 03022020 */
extern FIELD_IDX_T ExtOp_BoPtfId                           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_BoAccountId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_OpSplitRuleEn                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_AdjBoPtfId                        ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_CoaExDate                         ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_BoCashAcctId                      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_BoCashPtfId                       ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_SplitParentOperId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T ExtOp_OriginalNetAmount                 ; /* PMSTA-39927 - Siva - 04292020 */
extern FIELD_IDX_T ExtOp_SplitParOpCd					   ; /* PMSTA-40714 */
extern FIELD_IDX_T ExtOp_RuleApplicabilityEn			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_SmartRoundingQty				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_SmartRoundingOrgQty			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_RoundingOrgQty					   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_SmartRoundingFlg				   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_SmartRoundingRuleId			   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T ExtOp_HierOperNatEn                     ; /* PMSTA-40208 - adarshn - 01092020 */
extern FIELD_IDX_T ExtOp_HierOperationCd                   ; /* PMSTA-40208 - adarshn - 01092020 */
extern FIELD_IDX_T ExtOp_ParentHierExtOpId                 ; /* PMSTA-40208 - adarshn - 01092020 */
extern FIELD_IDX_T ExtOp_OrderSeqRankNbr     		       ; /* PMSTA-41770 - Vishnu -270920 */
extern FIELD_IDX_T ExtOp_HierGroupingCriteria              ; /* PMSTA-40208 - sanand	- 24092020 */
extern FIELD_IDX_T ExtOp_CashPlanId                        ; /*PMSTA-42402 Autocash Vishnu 16112020*/
extern FIELD_IDX_T ExtOp_OrdQtyPreFullRedemp               ; /* PMSTA-43100 - sanand - 29122020 */
extern FIELD_IDX_T ExtOp_CumulativeAmt                     ; /* PMSTA-43100 - sanand - 29122020 */
extern FIELD_IDX_T ExtOp_NotionalInstrId                   ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ExtOp_InvestLimitEn                     ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T ExtOp_AdjRefNatEn                       ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T ExtOp_AdjRefOperCd                      ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T ExtOp_SetOfFeesId					   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ExtOp_SetOfProductFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T ExtOp_BoRoutingBusEntityId			   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T ExtOp_OrderSubTypeId                    ; /* WEALTH-157 - Deepthi - 20230404 */
extern FIELD_IDX_T ExtOp_ApplSessionCd                     ; /* WEALTH-3007 - JPR - 20231031 */
extern FIELD_IDX_T ExtOp_SetOfOtherFeesId                  ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T ExtOp_TraderThirdId                     ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T ExtOp_ParAdjExtOp_Ext                   ; /* PMSTA - 54624 - SRS - 240118 */
extern FIELD_IDX_T ExtOp_NetSettleAmount				   ; /* WEALTH-9095 - SENTHIL - 20240529 */
extern FIELD_IDX_T ExtOp_PremiumCurrencyId                 ; /* WEALTH-8559 - Senthil - 20240607 */
extern FIELD_IDX_T ExtOp_PremiumAmount                     ; /* WEALTH-8559 - Senthil - 20240607 */


extern FIELD_IDX_T Imp_OpV2_Cd                             ;
extern FIELD_IDX_T Imp_OpV2_NatEn                          ;
extern FIELD_IDX_T Imp_OpV2_FwdSplitFlg                    ;
extern FIELD_IDX_T Imp_OpV2_InstrId                        ;
extern FIELD_IDX_T Imp_OpV2_PtfId                          ;
extern FIELD_IDX_T Imp_OpV2_BeginDate                      ;
extern FIELD_IDX_T Imp_OpV2_EndDate                        ;


extern FIELD_IDX_T Curr_Modif_EntDictId                    ;
extern FIELD_IDX_T Curr_Modif_ObjId                        ;
extern FIELD_IDX_T Curr_Modif_PortModifEn                  ;
extern FIELD_IDX_T Curr_Modif_OldCurrId                    ;
extern FIELD_IDX_T Curr_Modif_NewCurrId                    ;
extern FIELD_IDX_T Curr_Modif_PortPosSetId                 ;
extern FIELD_IDX_T Curr_Modif_OldSysCurrId                 ;
extern FIELD_IDX_T Curr_Modif_NewSysCurrId                 ;
extern FIELD_IDX_T Curr_Modif_EntSqlName                   ;
extern FIELD_IDX_T Curr_Modif_ObjCd                        ;
extern FIELD_IDX_T Curr_Modif_OldCurrCd                    ;
extern FIELD_IDX_T Curr_Modif_NewCurrCd                    ;
extern FIELD_IDX_T Curr_Modif_PpsCurrCd                    ;
extern FIELD_IDX_T Curr_Modif_PpsTypeCd                    ;
extern FIELD_IDX_T Curr_Modif_PpsConsPtfCd                 ;
extern FIELD_IDX_T Curr_Modif_OldSysCurrCd                 ;
extern FIELD_IDX_T Curr_Modif_NewSysCurrCd                 ;
extern FIELD_IDX_T Curr_Modif_InstrBusEntityCd             ;
extern FIELD_IDX_T Curr_Modif_GuiFlg                       ;

extern FIELD_IDX_T Msg_NatEn                               ;
extern FIELD_IDX_T Msg_String                              ;
extern FIELD_IDX_T Msg_FldIdx                              ;
extern FIELD_IDX_T Msg_AttrSqlName                         ;        /*  HFI-PMSTA-19056-141106  */
extern FIELD_IDX_T Msg_EntDictId                           ;        /*  HFI-PMSTA-19056-141106  */
extern FIELD_IDX_T Msg_CaseMgtTypeId                       ;        /* WEALTH-9976 - KKM - 10072024 */


extern FIELD_IDX_T Select_Res_Tab_DataTab                  ;


extern FIELD_IDX_T ExportCtx_Arg_EntDictId                 ;
extern FIELD_IDX_T ExportCtx_Arg_ListId                    ;
extern FIELD_IDX_T ExportCtx_Arg_ListScript                ;
extern FIELD_IDX_T ExportCtx_Arg_FmtId                     ;
extern FIELD_IDX_T ExportCtx_Arg_MaxRowsNbr                ;
extern FIELD_IDX_T ExportCtx_Arg_ColNbr                    ;
extern FIELD_IDX_T ExportCtx_Arg_Updstatus_sign            ;
extern FIELD_IDX_T ExportCtx_Arg_Updstatus_val             ;
extern FIELD_IDX_T ExportCtx_Arg_LanguageDictId            ;  /* REF8952 - DDV - 030919 */
extern FIELD_IDX_T ExportCtx_Arg_UseFmtFilterFlg           ;  /* REF10743 - CHU - 041104 */
extern FIELD_IDX_T ExportCtx_Arg_ExportDate                ;  /* REF11221 - TGU - 060421 */
extern FIELD_IDX_T ExportCtx_Arg_UserId					   ;  /* REF11476 - TEB - 051026 */
extern FIELD_IDX_T ExportCtx_Arg_Param1					   ; /* PMSTA06646 - LJE - 080616 */
extern FIELD_IDX_T ExportCtx_Arg_Param2			           ; /* PMSTA06646 - LJE - 080616 */
extern FIELD_IDX_T ExportCtx_Arg_Param3			           ; /* PMSTA06646 - LJE - 080616 */
extern FIELD_IDX_T ExportCtx_Arg_Param4			           ; /* PMSTA06646 - LJE - 080616 */
extern FIELD_IDX_T ExportCtx_Arg_Param5			           ; /* PMSTA06646 - LJE - 080616 */
extern FIELD_IDX_T ExportCtx_Arg_DataProfId                ; /* PMSTA07422 - DDV - 090520 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol1           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol2           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol3           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol4           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol5           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol6           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol7           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol8           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol9           ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol10          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol11          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol12          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol13          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol14          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol15          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol16          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol17          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol18          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol19          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol20          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol21          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol22          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol23          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol24          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol25          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol26          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol27          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol28          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol29          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol30          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol31          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol32          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol33          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol34          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol35          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol36          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol37          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol38          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol39          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol40          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol41          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol42          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol43          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol44          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol45          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol46          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol47          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol48          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol49          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol50          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol51          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol52          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol53          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol54          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol55          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol56          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol57          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol58          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol59          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol60          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol61          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol62          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol63          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol64          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol65          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol66          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol67          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol68          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol69          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol70          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol71          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol72          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol73          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol74          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol75          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol76          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol77          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol78          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol79          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol80          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol81          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol82          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol83          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol84          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol85          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol86          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol87          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol88          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol89          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol90          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol91          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol92          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol93          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol94          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol95          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol96          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol97          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol98          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol99          ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol100         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol101         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol102         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol103         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol104         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol105         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol106         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol107         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol108         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol109         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol110         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol111         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol112         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol113         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol114         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol115         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol116         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol117         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol118         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol119         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol120         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol121         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol122         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol123         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol124         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol125         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol126         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol127         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol128         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol129         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol130         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol131         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol132         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol133         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol134         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol135         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol136         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol137         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol138         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol139         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol140         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol141         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol142         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol143         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol144         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol145         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol146         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol147         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol148         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol149         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol150         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol151         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol152         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol153         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol154         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol155         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol156         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol157         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol158         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol159         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol160         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol161         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol162         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol163         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol164         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol165         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol166         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol167         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol168         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol169         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol170         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol171         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol172         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol173         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol174         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol175         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol176         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol177         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol178         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol179         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol180         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol181         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol182         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol183         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol184         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol185         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol186         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol187         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol188         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol189         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol190         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol191         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol192         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol193         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol194         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol195         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol196         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol197         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol198         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol199         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol200         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol201         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol202         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol203         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol204         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol205         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol206         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol207         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol208         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol209         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol210         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol211         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol212         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol213         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol214         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol215         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol216         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol217         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol218         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol219         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol220         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol221         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol222         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol223         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol224         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol225         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol226         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol227         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol228         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol229         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol230         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol231         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol232         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol233         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol234         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol235         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol236         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol237         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol238         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol239         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol240         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol241         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol242         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol243         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol244         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol245         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol246         ;
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol247         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol248         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol249         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol250         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol251         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol252         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol253         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol254         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol255         ; /* DLA - NOREF - 040109 */
extern FIELD_IDX_T ExportCtx_Arg_TypeAndScptCol256         ; /* DLA - NOREF - 040109 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol257        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol258        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol259        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol260        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol261        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol262        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol263        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol264        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol265        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol266        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol267        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol268        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol269        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol270        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol271        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol272        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol273        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol274        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol275        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol276        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol277        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol278        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol279        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol280        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol281        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol282        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol283        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol284        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol285        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol286        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol287        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol288        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol289        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol290        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol291        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol292        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol293        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol294        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol295        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol296        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol297        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol298        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol299        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol300        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol301        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol302        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol303        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol304        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol305        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol306        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol307        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol308        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol309        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol310        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol311        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol312        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol313        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol314        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol315        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol316        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol317        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol318        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol319        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol320        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol321        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol322        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol323        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol324        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol325        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol326        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol327        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol328        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol329        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol330        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol331        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol332        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol333        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol334        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol335        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol336        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol337        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol338        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol339        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol340        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol341        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol342        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol343        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol344        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol345        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol346        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol347        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol348        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol349        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol350        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol351        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol352        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol353        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol354        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol355        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol356        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol357        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol358        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol359        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol360        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol361        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol362        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol363        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol364        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol365        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol366        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol367        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol368        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol369        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol370        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol371        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol372        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol373        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol374        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol375        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol376        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol377        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol378        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol379        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol380        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol381        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol382        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol383        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol384        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol385        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol386        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol387        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol388        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol389        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol390        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol391        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol392        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol393        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol394        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol395        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol396        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol397        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol398        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol399        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol400        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol401        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol402        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol403        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol404        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol405        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol406        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol407        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol408        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol409        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol410        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol411        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol412        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol413        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol414        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol415        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol416        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol417        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol418        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol419        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol420        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol421        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol422        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol423        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol424        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol425        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol426        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol427        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol428        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol429        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol430        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol431        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol432        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol433        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol434        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol435        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol436        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol437        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol438        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol439        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol440        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol441        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol442        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol443        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol444        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol445        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol446        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol447        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol448        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol449        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol450        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol451        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol452        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol453        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol454        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol455        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol456        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol457        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol458        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol459        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol460        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol461        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol462        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol463        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol464        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol465        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol466        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol467        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol468        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol469        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol470        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol471        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol472        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol473        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol474        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol475        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol476        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol477        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol478        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol479        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol480        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol481        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol482        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol483        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol484        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol485        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol486        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol487        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol488        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol489        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol490        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol491        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol492        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol493        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol494        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol495        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol496        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol497        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol498        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol499        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol500        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol501        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol502        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol503        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol504        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol505        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol506        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol507        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol508        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol509        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol510        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol511        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T	ExportCtx_Arg_TypeAndScptCol512        ; /* EFE - PMSTA-27146 - 20180704 */
extern  FIELD_IDX_T ExportCtx_Arg_TslDbName                 ;
extern FIELD_IDX_T ExportCtx_Arg_TslJobId                  ;
extern FIELD_IDX_T ExportCtx_Arg_TslChunkNumber            ;
extern FIELD_IDX_T ExportCtx_Arg_DataSetId                 ;
extern FIELD_IDX_T ExportCtx_Arg_ApplSessionCd             ;  /* PMSTA-22549 - CHU - 160512 */
extern FIELD_IDX_T ExportCtx_Arg_ExportModeEn              ;  /* PMSTA-52258 - JBC - 230308 */


extern FIELD_IDX_T Export_FmtElt_ObjId                     ;
extern FIELD_IDX_T Export_FmtElt_Rank                      ;
extern FIELD_IDX_T Export_FmtElt_DataTpDictId              ;
extern FIELD_IDX_T Export_FmtElt_Def                       ;
extern FIELD_IDX_T Export_FmtElt_DspFmt                    ;
extern FIELD_IDX_T Export_FmtElt_ColWidth                  ;
extern FIELD_IDX_T Export_FmtElt_JustifEn                  ;
extern FIELD_IDX_T Export_FmtElt_Denom                     ;
extern FIELD_IDX_T Export_FmtElt_Sqlname                   ;  /* REF9007.4002 - DLA for DDV - 030818 */

#ifdef PMSTA17265
extern FIELD_IDX_T Export_FmtElt_LangDictId                ;
extern FIELD_IDX_T Export_FmtElt_TlsMultilingualEn         ;
#endif

extern FIELD_IDX_T A_CellFmt_Sqlname                       ;
extern FIELD_IDX_T A_CellFmt_MinVal                        ;
extern FIELD_IDX_T A_CellFmt_MinIncFlg                     ;
extern FIELD_IDX_T A_CellFmt_MaxVal                        ;
extern FIELD_IDX_T A_CellFmt_MaxIncFlg                     ;
extern FIELD_IDX_T A_CellFmt_IconName                      ;
extern FIELD_IDX_T A_CellFmt_BgColorEn                     ;
extern FIELD_IDX_T A_CellFmt_FgColorEn                     ;
extern FIELD_IDX_T A_CellFmt_BoldFlg                       ;
extern FIELD_IDX_T A_CellFmt_ItalicFlg                     ;
extern FIELD_IDX_T A_CellFmt_Justif                        ;
extern FIELD_IDX_T A_CellFmt_BumpFlg                       ;
extern FIELD_IDX_T A_CellFmt_BgColorName                   ;
extern FIELD_IDX_T A_CellFmt_FgColorName                   ;


extern FIELD_IDX_T A_CompInstrChrono_EntDictId             ;
extern FIELD_IDX_T A_CompInstrChrono_ObjId                 ;
extern FIELD_IDX_T A_CompInstrChrono_NatEn                 ;
extern FIELD_IDX_T A_CompInstrChrono_CalcDate              ;
extern FIELD_IDX_T A_CompInstrChrono_ForceFlg              ;
extern FIELD_IDX_T A_CompInstrChrono_DeleteFlg             ;
extern FIELD_IDX_T A_CompInstrChrono_NatMask               ;

/* PMSTA-18426 - CHU - 141004 */
extern FIELD_IDX_T A_CompComplChrono_EntDictId             ;
extern FIELD_IDX_T A_CompComplChrono_ObjId                 ;
extern FIELD_IDX_T A_CompComplChrono_NatEn                 ;
extern FIELD_IDX_T A_CompComplChrono_ConfidenceLevel       ;
extern FIELD_IDX_T A_CompComplChrono_TimeHorizon           ;
extern FIELD_IDX_T A_CompComplChrono_TimeHorizonUnitEn     ;
extern FIELD_IDX_T A_CompComplChrono_CalcDate              ;
extern FIELD_IDX_T A_CompComplChrono_ForceFlg              ;
extern FIELD_IDX_T A_CompComplChrono_DeleteFlg             ;
extern FIELD_IDX_T A_CompComplChrono_NatMask               ;


extern FIELD_IDX_T Search_BestOper_PtfObjId                ;
extern FIELD_IDX_T Search_BestOper_InstrObjId              ;
extern FIELD_IDX_T Search_BestOper_OpNatEn                 ;
extern FIELD_IDX_T Search_BestOper_MinStatEn               ;
extern FIELD_IDX_T Search_BestOper_MaxStatEn               ;
extern FIELD_IDX_T Search_BestOper_InterpFromDate          ;
extern FIELD_IDX_T Search_BestOper_InterpTillDate          ;
extern FIELD_IDX_T Search_BestOper_FusDateRuleEn           ;
extern FIELD_IDX_T Search_BestOper_DateMargin              ;
extern FIELD_IDX_T Search_BestOper_Param1Attribute         ;
extern FIELD_IDX_T Search_BestOper_Param1Margin            ;
extern FIELD_IDX_T Search_BestOper_Param1Result            ;
extern FIELD_IDX_T Search_BestOper_Param2Attribute         ;
extern FIELD_IDX_T Search_BestOper_Param2Margin            ;
extern FIELD_IDX_T Search_BestOper_Param2Result            ;
extern FIELD_IDX_T Search_BestOper_Param3Attribute         ;
extern FIELD_IDX_T Search_BestOper_Param3Margin            ;
extern FIELD_IDX_T Search_BestOper_Param3Result            ;
extern FIELD_IDX_T Search_BestOper_Param4Attribute         ;
extern FIELD_IDX_T Search_BestOper_Param4Margin            ;
extern FIELD_IDX_T Search_BestOper_Param4Result            ;
extern FIELD_IDX_T Search_BestOper_Param5Attribute         ;
extern FIELD_IDX_T Search_BestOper_Param5Margin            ;
extern FIELD_IDX_T Search_BestOper_Param5Result            ;


extern FIELD_IDX_T Current_Load_ActivFusNbr                ;
extern FIELD_IDX_T Current_Load_BigPtfFlg                  ;
extern FIELD_IDX_T Current_Load_ActiveStockIds             ;
extern FIELD_IDX_T Current_Load_NotifFail_StockId          ;
extern FIELD_IDX_T Current_Load_NotifFail_RequestId        ;
extern FIELD_IDX_T Current_Load_NotifFail_PtfListId        ;
extern FIELD_IDX_T Current_Load_NotifFail_PtfStsList       ;
extern FIELD_IDX_T Current_Load_NotifFail_BusEntityCd      ;
extern FIELD_IDX_T Current_Load_NotifFail_MoreToSendFlg    ;



extern FIELD_IDX_T PtfQtyAlloc_InstrId                     ;
extern FIELD_IDX_T PtfQtyAlloc_PtfId                       ;
extern FIELD_IDX_T PtfQtyAlloc_Qty                         ;


extern FIELD_IDX_T MktSgtInstr_InstrId                     ;
extern FIELD_IDX_T MktSgtInstr_GridId                      ;
extern FIELD_IDX_T MktSgtInstr_MktSgtId                    ;
extern FIELD_IDX_T MktSgtInstr_RecommStratId               ;


extern FIELD_IDX_T Bench_Weight_InstrId                    ;
extern FIELD_IDX_T Bench_Weight_ObjId                      ;
extern FIELD_IDX_T Bench_Weight_Weight                     ;
extern FIELD_IDX_T Bench_Weight_BeginDate                  ;
extern FIELD_IDX_T Bench_Weight_ApplicDate                 ;
extern FIELD_IDX_T Bench_Weight_RecomNatEn                 ;


extern FIELD_IDX_T A_FTConv_Id                             ;
extern FIELD_IDX_T A_FTConv_Code                           ;
extern FIELD_IDX_T A_FTConv_Name                           ;
extern FIELD_IDX_T A_FTConv_Denom                          ;
extern FIELD_IDX_T A_FTConv_ClassifId                      ;
extern FIELD_IDX_T A_FTConv_TaxGeoId                       ;
extern FIELD_IDX_T A_FTConv_DataSecuProfId                 ; /* REF9910 - LJE - 040218 */
extern FIELD_IDX_T A_FTConv_TaxStatEn                      ;
extern FIELD_IDX_T A_FTConv_NatureEn                       ;


extern FIELD_IDX_T S_FTConv_Id                             ;
extern FIELD_IDX_T S_FTConv_Code                           ;
extern FIELD_IDX_T S_FTConv_Name                           ;
extern FIELD_IDX_T S_FTConv_ClassifId                      ;
extern FIELD_IDX_T S_FTConv_NatEn                          ;
extern FIELD_IDX_T S_FTConv_TaxGeoCd                       ;
extern FIELD_IDX_T S_FTConv_TaxStatEn                      ;


extern FIELD_IDX_T A_FTRateHist_Id                         ;
extern FIELD_IDX_T A_FTRateHist_FTConvId                   ;
extern FIELD_IDX_T A_FTRateHist_BeginDate                  ;


extern FIELD_IDX_T S_FTRateHist_Id                         ;
extern FIELD_IDX_T S_FTRateHist_FTConvId                   ;
extern FIELD_IDX_T S_FTRateHist_BeginDate                  ;
extern FIELD_IDX_T S_FTRateHist_FTConvCd                   ;


extern FIELD_IDX_T A_FTRate_Id                             ;
extern FIELD_IDX_T A_FTRate_FTRateHistId                   ;
extern FIELD_IDX_T A_FTRate_Rank                           ;
extern FIELD_IDX_T A_FTRate_TaxGeoId                       ;
extern FIELD_IDX_T A_FTRate_InstrListId                    ;
extern FIELD_IDX_T A_FTRate_WithholdingTaxRate             ;
extern FIELD_IDX_T A_FTRate_ReclaimTaxRate                 ;
extern FIELD_IDX_T A_FTRate_CountableTaxRate               ;
extern FIELD_IDX_T A_FTRate_NoReclaimTaxRate               ;
extern FIELD_IDX_T A_FTRate_ShortTermCapTaxRate            ;
extern FIELD_IDX_T A_FTRate_LongTermCapTaxRate             ;
extern FIELD_IDX_T A_FTRate_LongTermPeriodUnitEn           ;
extern FIELD_IDX_T A_FTRate_LongTermPeriod                 ;
extern FIELD_IDX_T A_FTRate_TaxAccrualFlg                  ;
extern FIELD_IDX_T A_FTRate_TaxUnrealisedPLFlg             ;
extern FIELD_IDX_T A_FTRate_Rate                           ;
extern FIELD_IDX_T A_FTRate_NatureEn                       ;
extern FIELD_IDX_T A_FTRate_DiscountPercent                ;                             /* PMSTA-35006 - 090319 - vkumar */


extern FIELD_IDX_T S_FTRate_Id                             ;
extern FIELD_IDX_T S_FTRate_FTRateHistId                   ;
extern FIELD_IDX_T S_FTRate_Rank                           ;
extern FIELD_IDX_T S_FTRate_TaxGeoId                       ;
extern FIELD_IDX_T S_FTRate_InstrListId                    ;
extern FIELD_IDX_T S_FTRate_TaxGeoCd                       ;
extern FIELD_IDX_T S_FTRate_InstrListCd                    ;


extern FIELD_IDX_T HolidaysRule_StartDate                  ;
extern FIELD_IDX_T HolidaysRule_EndDate                    ;
extern FIELD_IDX_T HolidaysRule_CalendarId                 ;
extern FIELD_IDX_T HolidaysRule_ObjectId                   ;
extern FIELD_IDX_T HolidaysRule_NatureEn                   ;
extern FIELD_IDX_T HolidaysRule_GenericEn                  ;
extern FIELD_IDX_T HolidaysRule_Weekend                    ;
extern FIELD_IDX_T HolidaysRule_AddDays                    ;


extern FIELD_IDX_T CalendarOut_Date                        ;
extern FIELD_IDX_T CalendarOut_Flag                        ;
extern FIELD_IDX_T CalendarOut_Int                         ;


extern FIELD_IDX_T A_Array_Ptr                             ; /* PMSTA14453 - DDV - 120705 - Array definition not clean */


extern FIELD_IDX_T Fusion_Status_En                        ;
extern FIELD_IDX_T Fusion_Status_StockId                   ;
extern FIELD_IDX_T Fusion_Status_RequestId                 ;
extern FIELD_IDX_T Fusion_Status_PtfListId                 ;
extern FIELD_IDX_T Fusion_Status_PtfStsList                ;
extern FIELD_IDX_T Fusion_Status_ServName                  ;
extern FIELD_IDX_T Fusion_Status_ApplSessionCd             ;


extern FIELD_IDX_T Syb_Remote_Exec_ResultFile              ;
extern FIELD_IDX_T Syb_Remote_Exec_ResultType              ;
extern FIELD_IDX_T Syb_Remote_Exec_ResultTiled             ;
extern FIELD_IDX_T Syb_Remote_Exec_ShellScript             ;


extern FIELD_IDX_T Syb_Remote_ExecCb_ThreadIdx             ;
extern FIELD_IDX_T Syb_Remote_ExecCb_ProcessId             ;


extern FIELD_IDX_T Msg_Log_ModeFlg                         ;
extern FIELD_IDX_T Msg_Log_ReportServer                    ;
extern FIELD_IDX_T Msg_Log_ReportCd                        ;
extern FIELD_IDX_T Msg_Log_ReportSts                       ;


extern FIELD_IDX_T StratInstrDura_PtfId                    ;
extern FIELD_IDX_T StratInstrDura_StratId                  ;
extern FIELD_IDX_T StratInstrDura_InstrArray               ;


extern FIELD_IDX_T Arg_Test_Amount                         ;
extern FIELD_IDX_T Arg_Test_Code                           ;
extern FIELD_IDX_T Arg_Test_Date                           ;
extern FIELD_IDX_T Arg_Test_Datetime                       ;
extern FIELD_IDX_T Arg_Test_Dict                           ;
extern FIELD_IDX_T Arg_Test_Enum                           ;
extern FIELD_IDX_T Arg_Test_Exchange                       ;
extern FIELD_IDX_T Arg_Test_Flag                           ;
extern FIELD_IDX_T Arg_Test_Id                             ;
extern FIELD_IDX_T Arg_Test_Info                           ;
extern FIELD_IDX_T Arg_Test_Int                            ;
extern FIELD_IDX_T Arg_Test_Longamount                     ;
extern FIELD_IDX_T Arg_Test_Longname                       ;
extern FIELD_IDX_T Arg_Test_Mask                           ;
extern FIELD_IDX_T Arg_Test_Method                         ;
extern FIELD_IDX_T Arg_Test_Name                           ;
extern FIELD_IDX_T Arg_Test_Note                           ;
extern FIELD_IDX_T Arg_Test_Number                         ;
extern FIELD_IDX_T Arg_Test_Percent                        ;
extern FIELD_IDX_T Arg_Test_Period                         ;
extern FIELD_IDX_T Arg_Test_Phone                          ;
extern FIELD_IDX_T Arg_Test_Shortinfo                      ;
extern FIELD_IDX_T Arg_Test_Smallint                       ;
extern FIELD_IDX_T Arg_Test_Sysname                        ;
extern FIELD_IDX_T Arg_Test_Text                           ;
extern FIELD_IDX_T Arg_Test_Time                           ;
extern FIELD_IDX_T Arg_Test_Tinyint                        ;
extern FIELD_IDX_T Arg_Test_Year                           ;
extern FIELD_IDX_T Arg_Test_UniCode                        ;
extern FIELD_IDX_T Arg_Test_UniInfo                        ;
extern FIELD_IDX_T Arg_Test_UniLongname                    ;
extern FIELD_IDX_T Arg_Test_UniName                        ;
extern FIELD_IDX_T Arg_Test_UniNote                        ;
extern FIELD_IDX_T Arg_Test_UniPhone                       ;
extern FIELD_IDX_T Arg_Test_UniShortinfo                   ;
extern FIELD_IDX_T Arg_Test_UniSysname                     ;
extern FIELD_IDX_T Arg_Test_String                         ;
extern FIELD_IDX_T Arg_Test_Id2                            ;  /* PMSTA-31569 - TEB - 180530 */


extern FIELD_IDX_T A_OpList_Id                             ;
extern FIELD_IDX_T A_OpList_Cd                             ;
extern FIELD_IDX_T A_OpList_FusionEn                       ;
extern FIELD_IDX_T A_OpList_SequenceNo                     ;
extern FIELD_IDX_T A_OpList_StatEn                         ;
extern FIELD_IDX_T A_OpList_ParOpNatEn                     ;
extern FIELD_IDX_T A_OpList_SrcCd                          ;
extern FIELD_IDX_T A_OpList_NewStatusEn                    ;
extern FIELD_IDX_T A_OpList_ErrCode                        ;


extern FIELD_IDX_T A_SetEnv_Param                          ;
extern FIELD_IDX_T A_SetEnv_Value                          ;

extern FIELD_IDX_T A_SafeShutdown_ImmediateFlg             ;
extern FIELD_IDX_T A_SafeShutdown_TimeoutSec               ;
extern FIELD_IDX_T A_SafeShutdown_AsyncFlg                 ;
extern FIELD_IDX_T A_SafeShutdown_RestartFlg               ;

extern FIELD_IDX_T EvalEntity_CommandEn                    ;
extern FIELD_IDX_T EvalEntity_Sqlname                      ;
extern FIELD_IDX_T EvalEntity_Param                        ;
extern FIELD_IDX_T EvalEntity_ScreenDictId                 ;
extern FIELD_IDX_T EvalEntity_LanguageDictId               ;
extern FIELD_IDX_T EvalEntity_TextConverterEn              ; /* REF9303 - LJE - 030905 */
extern FIELD_IDX_T EvalEntity_UserId                       ; /* REF11476 - TEB - 051006 */
extern FIELD_IDX_T EvalEntity_FctProcName                  ;    /*  FIH-REF11818-060516 */
extern FIELD_IDX_T EvalEntity_OutputMode                   ; /* PMSTA05247 - LJE - 071224 */
extern FIELD_IDX_T EvalEntity_FilterOutputDesc             ; /*  PMSTA-9817-HFI-100512   */
extern FIELD_IDX_T EvalEntity_FormatCode                   ; /*  PMSTA-10485-HFI-100830  */
extern FIELD_IDX_T EvalEntity_SessionId                    ; /*  PMSTA-10702-HFI-101202  */
extern FIELD_IDX_T EvalEntity_ThirdId                      ; /* OCS-39654 - LJE - 120214 */
extern FIELD_IDX_T EvalEntity_FunctionDictId               ;    /*  HFI-PMSTA-16165-130405  */
extern FIELD_IDX_T EvalEntity_ApplSessionCd                ;  /* PMSTA-22549 - CHU - 160512 */
extern FIELD_IDX_T EvalEntity_MaxRecInError                ;  /* PMSTA-22506 - DDV - 160526 */
extern FIELD_IDX_T EvalEntity_UpdateRuleEn                 ;  /* PMSTA-22506 - DDV - 160526 */
extern FIELD_IDX_T EvalEntity_ObjectOutputEn               ;    /*  HFI-PMSTA-30519-190806  */
extern FIELD_IDX_T EvalEntity_ObjectOutputDesc             ;    /*  HFI-PMSTA-30519-190806  */


extern FIELD_IDX_T EvalEntities_CommandEn                     ;
extern FIELD_IDX_T EvalEntities_Sqlname                       ;
extern FIELD_IDX_T EvalEntities_Param01                       ;
extern FIELD_IDX_T EvalEntities_Param02                       ;
extern FIELD_IDX_T EvalEntities_Param03                       ;
extern FIELD_IDX_T EvalEntities_Param04                       ;
extern FIELD_IDX_T EvalEntities_Param05                       ;
extern FIELD_IDX_T EvalEntities_Param06                       ;
extern FIELD_IDX_T EvalEntities_Param07                       ;
extern FIELD_IDX_T EvalEntities_Param08                       ;
extern FIELD_IDX_T EvalEntities_Param09                       ;
extern FIELD_IDX_T EvalEntities_Param10                       ;
extern FIELD_IDX_T EvalEntities_Param11                       ;
extern FIELD_IDX_T EvalEntities_Param12                       ;
extern FIELD_IDX_T EvalEntities_Param13                       ;
extern FIELD_IDX_T EvalEntities_Param14                       ;
extern FIELD_IDX_T EvalEntities_Param15                       ;
extern FIELD_IDX_T EvalEntities_Param16                       ;
extern FIELD_IDX_T EvalEntities_Param17                       ;
extern FIELD_IDX_T EvalEntities_Param18                       ;
extern FIELD_IDX_T EvalEntities_Param19                       ;
extern FIELD_IDX_T EvalEntities_Param20                       ;
extern FIELD_IDX_T EvalEntities_Param21                       ;
extern FIELD_IDX_T EvalEntities_Param22                       ;
extern FIELD_IDX_T EvalEntities_Param23                       ;
extern FIELD_IDX_T EvalEntities_Param24                       ;
extern FIELD_IDX_T EvalEntities_Param25                       ;
extern FIELD_IDX_T EvalEntities_Param26                       ;
extern FIELD_IDX_T EvalEntities_Param27                       ;
extern FIELD_IDX_T EvalEntities_Param28                       ;
extern FIELD_IDX_T EvalEntities_Param29                       ;
extern FIELD_IDX_T EvalEntities_Param30                       ;
extern FIELD_IDX_T EvalEntities_Param31                       ;
extern FIELD_IDX_T EvalEntities_Param32                       ;
extern FIELD_IDX_T EvalEntities_Param33                       ;
extern FIELD_IDX_T EvalEntities_Param34                       ;
extern FIELD_IDX_T EvalEntities_Param35                       ;
extern FIELD_IDX_T EvalEntities_Param36                       ;
extern FIELD_IDX_T EvalEntities_Param37                       ;
extern FIELD_IDX_T EvalEntities_Param38                       ;
extern FIELD_IDX_T EvalEntities_Param39                       ;
extern FIELD_IDX_T EvalEntities_Param40                       ;
extern FIELD_IDX_T EvalEntities_Param41                       ;
extern FIELD_IDX_T EvalEntities_Param42                       ;
extern FIELD_IDX_T EvalEntities_Param43                       ;
extern FIELD_IDX_T EvalEntities_Param44                       ;
extern FIELD_IDX_T EvalEntities_Param45                       ;
extern FIELD_IDX_T EvalEntities_Param46                       ;
extern FIELD_IDX_T EvalEntities_Param47                       ;
extern FIELD_IDX_T EvalEntities_Param48                       ;
extern FIELD_IDX_T EvalEntities_Param49                       ;
extern FIELD_IDX_T EvalEntities_Param50                       ;
extern FIELD_IDX_T EvalEntities_ScreenDictId                ;
extern FIELD_IDX_T EvalEntities_LanguageDictId              ;
extern FIELD_IDX_T EvalEntities_TextConverterEn             ;
extern FIELD_IDX_T EvalEntities_UserId                      ;
extern FIELD_IDX_T EvalEntities_FctProcName                 ;
extern FIELD_IDX_T EvalEntities_ApplSessionCd               ;

extern FIELD_IDX_T EvalEntityValues_ParamAttrib            ;
extern FIELD_IDX_T EvalEntityValues_DataTypeEn             ;
extern FIELD_IDX_T EvalEntityValues_Value                  ;
extern FIELD_IDX_T EvalEntityValues_ReportName             ;
extern FIELD_IDX_T EvalEntityValues_Sqlname                ;
extern FIELD_IDX_T EvalEntityValues_Label                  ;
extern FIELD_IDX_T EvalEntityValues_SeqNb                  ; /* REF10342 - LJE - 040608 */


extern FIELD_IDX_T EvalEntityEnum_ParamAttrib              ;
extern FIELD_IDX_T EvalEntityEnum_ValueName                ;
extern FIELD_IDX_T EvalEntityEnum_ValueEn                  ;
extern FIELD_IDX_T EvalEntityEnum_SeqNb                    ; /* REF10342 - LJE - 040608 */


extern FIELD_IDX_T EvalEntityError_ParamAttrib             ;
extern FIELD_IDX_T EvalEntityError_MessageEn               ;
extern FIELD_IDX_T EvalEntityError_MessageTxt              ;
extern FIELD_IDX_T EvalEntityError_SeqNb                   ; /* REF10342 - LJE - 040608 */

extern FIELD_IDX_T EvalEntityRights_RightsEn               ;    /*  FIH-REF11818-060612 */
extern FIELD_IDX_T EvalEntityRights_SeqNb                  ;    /*  FIH-REF11818-060612 */


extern FIELD_IDX_T IdEntity_Id                             ;
extern FIELD_IDX_T IdEntity_EntityDictId                   ;


extern FIELD_IDX_T A_UpdStratElt_DimStratDictId            ;
extern FIELD_IDX_T A_UpdStratElt_StratObjId                ;
extern FIELD_IDX_T A_UpdStratElt_FromDate                  ;
extern FIELD_IDX_T A_UpdStratElt_OldInstrId                ;
extern FIELD_IDX_T A_UpdStratElt_NewInstrId                ;


extern FIELD_IDX_T Dynamic_Sql_Secu_Prof_Id                ;
extern FIELD_IDX_T Dynamic_Sql_OutputSt                    ;
extern FIELD_IDX_T Dynamic_Sql_Cmd                         ;
extern FIELD_IDX_T Dynamic_Sql_Table                       ;
extern FIELD_IDX_T Dynamic_Sql_Valid                       ;
extern FIELD_IDX_T Dynamic_Sql_FromStr                     ; /* PMSTA-25761 - DDV - 170203 */
extern FIELD_IDX_T Dynamic_Sql_WhereStr                    ; /* PMSTA-25761 - DDV - 170203 */
extern FIELD_IDX_T Dynamic_Sql_AttributeDictId             ; /* PMSTA-25761 - DDV - 170203 */
extern FIELD_IDX_T Dynamic_Sql_AttributeSqlname            ; /* PMSTA-25761 - DDV - 170203 */


extern FIELD_IDX_T A_Execution_Id                          ;
extern FIELD_IDX_T A_Execution_ExtOrderId                  ;
extern FIELD_IDX_T A_Execution_TypeId                      ;
extern FIELD_IDX_T A_Execution_SubtypeId                   ;
extern FIELD_IDX_T A_Execution_MarketThirdId               ;
extern FIELD_IDX_T A_Execution_IntermedThirdId             ;
extern FIELD_IDX_T A_Execution_CheckStratEn                ;
extern FIELD_IDX_T A_Execution_AccountDate                 ;
extern FIELD_IDX_T A_Execution_OperationDate               ;
extern FIELD_IDX_T A_Execution_ValueDate                   ;
extern FIELD_IDX_T A_Execution_StatusEn                    ;
extern FIELD_IDX_T A_Execution_SequenceNo                  ;
extern FIELD_IDX_T A_Execution_CashPortfolioId             ;
extern FIELD_IDX_T A_Execution_AccountId                   ;
extern FIELD_IDX_T A_Execution_Account2Id                  ;
extern FIELD_IDX_T A_Execution_Account3Id                  ;
extern FIELD_IDX_T A_Execution_DepositId                   ;
extern FIELD_IDX_T A_Execution_AccCurrencyId               ;
extern FIELD_IDX_T A_Execution_Acc2CurrencyId              ;
extern FIELD_IDX_T A_Execution_Acc3CurrencyId              ;
extern FIELD_IDX_T A_Execution_TradeCurrencyId             ;
extern FIELD_IDX_T A_Execution_CashPfCurrId                ;
extern FIELD_IDX_T A_Execution_CounterpartyThirdId         ;
extern FIELD_IDX_T A_Execution_TermTypeId                  ;
extern FIELD_IDX_T A_Execution_AccrBpTypeId                ;
extern FIELD_IDX_T A_Execution_AccountedFlg                ;
extern FIELD_IDX_T A_Execution_BeginDate                   ;
extern FIELD_IDX_T A_Execution_ExecutionDate               ;
extern FIELD_IDX_T A_Execution_ExecutionSetCriteria        ;
extern FIELD_IDX_T A_Execution_NatureEn                    ;
extern FIELD_IDX_T A_Execution_Remark                      ;
extern FIELD_IDX_T A_Execution_OpExchRate                  ;
extern FIELD_IDX_T A_Execution_FiExchRate                  ;
extern FIELD_IDX_T A_Execution_SysExchRate                 ;
extern FIELD_IDX_T A_Execution_AccExchRate                 ;
extern FIELD_IDX_T A_Execution_Acc2ExchRate                ;
extern FIELD_IDX_T A_Execution_Acc3ExchRate                ;
extern FIELD_IDX_T A_Execution_TradeExchRate               ;
extern FIELD_IDX_T A_Execution_CashPfExchRate              ;
extern FIELD_IDX_T A_Execution_Quantity                    ;
extern FIELD_IDX_T A_Execution_Price                       ;
extern FIELD_IDX_T A_Execution_PriceCalcRuleEn             ;
extern FIELD_IDX_T A_Execution_Quote                       ;
extern FIELD_IDX_T A_Execution_Rate                        ;
extern FIELD_IDX_T A_Execution_SupplAmt                    ;
extern FIELD_IDX_T A_Execution_OpGrossAmt                  ;
extern FIELD_IDX_T A_Execution_AccrAmt                     ;
extern FIELD_IDX_T A_Execution_OpNetAmt                    ;
extern FIELD_IDX_T A_Execution_FiNetAmt                    ;
extern FIELD_IDX_T A_Execution_PfNetAmt                    ;
extern FIELD_IDX_T A_Execution_SysNetAmt                   ;
extern FIELD_IDX_T A_Execution_AccNetAmt                   ;
extern FIELD_IDX_T A_Execution_Acc2NetAmt                  ;
extern FIELD_IDX_T A_Execution_Acc3NetAmt                  ;
extern FIELD_IDX_T A_Execution_Bp1TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp1CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp1Amt                      ;
extern FIELD_IDX_T A_Execution_Bp2TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp2CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp2Amt                      ;
extern FIELD_IDX_T A_Execution_Bp3TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp3CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp3Amt                      ;
extern FIELD_IDX_T A_Execution_Bp4TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp4CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp4Amt                      ;
extern FIELD_IDX_T A_Execution_Bp5TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp5CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp5Amt                      ;
extern FIELD_IDX_T A_Execution_Bp6TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp6CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp6Amt                      ;
extern FIELD_IDX_T A_Execution_Bp7TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp7CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp7Amt                      ;
extern FIELD_IDX_T A_Execution_Bp8TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp8CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp8Amt                      ;
extern FIELD_IDX_T A_Execution_Bp9TypeId                   ;
extern FIELD_IDX_T A_Execution_Bp9CurrencyId               ;
extern FIELD_IDX_T A_Execution_Bp9Amt                      ;
extern FIELD_IDX_T A_Execution_Bp10TypeId                  ;
extern FIELD_IDX_T A_Execution_Bp10CurrencyId              ;
extern FIELD_IDX_T A_Execution_Bp10Amt                     ;
extern FIELD_IDX_T A_Execution_LastUserId				   ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_Execution_LastModifDate               ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_Execution_PtfId                       ;
extern FIELD_IDX_T A_Execution_InstrId                     ;
extern FIELD_IDX_T A_Execution_NoPositionFlg               ; /*PMSTA07201-BRO-090206*/
extern FIELD_IDX_T A_Execution_OpCurrencyId                ;
extern FIELD_IDX_T A_Execution_BoPtfId                     ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Execution_BoAccountId                 ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_Execution_SetOfFeesId				   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_Execution_SetOfProductFeesId		   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_Execution_BoRoutingBusEntityId		   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T A_Execution_SetOfOtherFeesId            ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T A_Execution_TraderThirdId               ; /* WEALTH-5053 - CHANDRU - 07022024 */


extern FIELD_IDX_T S_Execution_Id                          ;
extern FIELD_IDX_T S_Execution_ExtOrderId                  ;
extern FIELD_IDX_T S_Execution_SequenceNo                  ;
extern FIELD_IDX_T S_Execution_ExecutionSetCriteria        ;
extern FIELD_IDX_T S_Execution_StatusEn                    ;
extern FIELD_IDX_T S_Execution_AccountedFlg                ;
extern FIELD_IDX_T S_Execution_NatureEn                    ;


extern FIELD_IDX_T A_GlExecFee_Id                          ;
extern FIELD_IDX_T A_GlExecFee_ExtOrderId                  ;
extern FIELD_IDX_T A_GlExecFee_TypeId                      ;
extern FIELD_IDX_T A_GlExecFee_SubtypeId                   ;
extern FIELD_IDX_T A_GlExecFee_AccountDate                 ;
extern FIELD_IDX_T A_GlExecFee_OperationDate               ;
extern FIELD_IDX_T A_GlExecFee_ValueDate                   ;
extern FIELD_IDX_T A_GlExecFee_StatusEn                    ;
extern FIELD_IDX_T A_GlExecFee_CashPortfolioId             ;
extern FIELD_IDX_T A_GlExecFee_BpTypeId                    ;
extern FIELD_IDX_T A_GlExecFee_AccountId                   ;
extern FIELD_IDX_T A_GlExecFee_Account2Id                  ;
extern FIELD_IDX_T A_GlExecFee_Account3Id                  ;
extern FIELD_IDX_T A_GlExecFee_AccCurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Acc2CurrencyId              ;
extern FIELD_IDX_T A_GlExecFee_Acc3CurrencyId              ;
extern FIELD_IDX_T A_GlExecFee_TradeCurrencyId             ;
extern FIELD_IDX_T A_GlExecFee_CashPfCurrId                ;
extern FIELD_IDX_T A_GlExecFee_AccountedFlg                ;
extern FIELD_IDX_T A_GlExecFee_BeginDate                   ;
extern FIELD_IDX_T A_GlExecFee_ExecutionSetCriteria        ;
extern FIELD_IDX_T A_GlExecFee_Remark                      ;
extern FIELD_IDX_T A_GlExecFee_OpExchRate                  ;
extern FIELD_IDX_T A_GlExecFee_SysExchRate                 ;
extern FIELD_IDX_T A_GlExecFee_AccExchRate                 ;
extern FIELD_IDX_T A_GlExecFee_Acc2ExchRate                ;
extern FIELD_IDX_T A_GlExecFee_Acc3ExchRate                ;
extern FIELD_IDX_T A_GlExecFee_TradeExchRate               ;
extern FIELD_IDX_T A_GlExecFee_CashPfExchRate              ;
extern FIELD_IDX_T A_GlExecFee_OpNetAmt                    ;
extern FIELD_IDX_T A_GlExecFee_PfNetAmt                    ;
extern FIELD_IDX_T A_GlExecFee_SysNetAmt                   ;
extern FIELD_IDX_T A_GlExecFee_AccNetAmt                   ;
extern FIELD_IDX_T A_GlExecFee_Acc2NetAmt                  ;
extern FIELD_IDX_T A_GlExecFee_Acc3NetAmt                  ;
extern FIELD_IDX_T A_GlExecFee_Bp1TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp1CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp1Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp2TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp2CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp2Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp3TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp3CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp3Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp4TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp4CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp4Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp5TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp5CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp5Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp6TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp6CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp6Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp7TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp7CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp7Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp8TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp8CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp8Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp9TypeId                   ;
extern FIELD_IDX_T A_GlExecFee_Bp9CurrencyId               ;
extern FIELD_IDX_T A_GlExecFee_Bp9Amt                      ;
extern FIELD_IDX_T A_GlExecFee_Bp10TypeId                  ;
extern FIELD_IDX_T A_GlExecFee_Bp10CurrencyId              ;
extern FIELD_IDX_T A_GlExecFee_Bp10Amt                     ;
extern FIELD_IDX_T A_GlExecFee_LastUserId				   ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_GlExecFee_LastModifDate               ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_GlExecFee_PtfId                       ;
extern FIELD_IDX_T A_GlExecFee_InstrId                     ;
extern FIELD_IDX_T A_GlExecFee_OpCurrencyId                ;


extern FIELD_IDX_T S_GlExecFee_Id                          ;
extern FIELD_IDX_T S_GlExecFee_ExtOrderId                  ;
extern FIELD_IDX_T S_GlExecFee_ExecutionSetCriteria        ;
extern FIELD_IDX_T S_GlExecFee_StatusEn                    ;
extern FIELD_IDX_T S_GlExecFee_AccountedFlg                ;


extern FIELD_IDX_T A_ExtExecution_Id                       ;
extern FIELD_IDX_T A_ExtExecution_ExtOrderId               ;
extern FIELD_IDX_T A_ExtExecution_ExecutionId              ;
extern FIELD_IDX_T A_ExtExecution_GlobalExecutionFeeId     ;
extern FIELD_IDX_T A_ExtExecution_TypeId                   ;
extern FIELD_IDX_T A_ExtExecution_SubtypeId                ;
extern FIELD_IDX_T A_ExtExecution_MarketThirdId            ;
extern FIELD_IDX_T A_ExtExecution_IntermedThirdId          ;
extern FIELD_IDX_T A_ExtExecution_CheckStratEn             ;
extern FIELD_IDX_T A_ExtExecution_AccountDate              ;
extern FIELD_IDX_T A_ExtExecution_OperationDate            ;
extern FIELD_IDX_T A_ExtExecution_ValueDate                ;
extern FIELD_IDX_T A_ExtExecution_StatusEn                 ;
extern FIELD_IDX_T A_ExtExecution_SequenceNo               ;
extern FIELD_IDX_T A_ExtExecution_CashPortfolioId          ;
extern FIELD_IDX_T A_ExtExecution_BpTypeId                 ;
extern FIELD_IDX_T A_ExtExecution_AccountId                ;
extern FIELD_IDX_T A_ExtExecution_Account2Id               ;
extern FIELD_IDX_T A_ExtExecution_Account3Id               ;
extern FIELD_IDX_T A_ExtExecution_DepositId                ;
extern FIELD_IDX_T A_ExtExecution_AccCurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Acc2CurrencyId           ;
extern FIELD_IDX_T A_ExtExecution_Acc3CurrencyId           ;
extern FIELD_IDX_T A_ExtExecution_TradeCurrencyId          ;
extern FIELD_IDX_T A_ExtExecution_CashPfCurrId             ;
extern FIELD_IDX_T A_ExtExecution_CounterpartyThirdId      ;
extern FIELD_IDX_T A_ExtExecution_TermTypeId               ;
extern FIELD_IDX_T A_ExtExecution_AccrBpTypeId             ;
extern FIELD_IDX_T A_ExtExecution_AccountedFlg             ;
extern FIELD_IDX_T A_ExtExecution_BeginDate                ;
extern FIELD_IDX_T A_ExtExecution_ExecutionDate            ;
extern FIELD_IDX_T A_ExtExecution_ExecutionSetCriteria     ;
extern FIELD_IDX_T A_ExtExecution_NatureEn                 ;
extern FIELD_IDX_T A_ExtExecution_ExecutionNatureEn        ;
extern FIELD_IDX_T A_ExtExecution_Remark                   ;
extern FIELD_IDX_T A_ExtExecution_OpExchRate               ;
extern FIELD_IDX_T A_ExtExecution_FiExchRate               ;
extern FIELD_IDX_T A_ExtExecution_SysExchRate              ;
extern FIELD_IDX_T A_ExtExecution_AccExchRate              ;
extern FIELD_IDX_T A_ExtExecution_Acc2ExchRate             ;
extern FIELD_IDX_T A_ExtExecution_Acc3ExchRate             ;
extern FIELD_IDX_T A_ExtExecution_TradeExchRate            ;
extern FIELD_IDX_T A_ExtExecution_CashPfExchRate           ;
extern FIELD_IDX_T A_ExtExecution_Quantity                 ;
extern FIELD_IDX_T A_ExtExecution_Price                    ;
extern FIELD_IDX_T A_ExtExecution_PriceCalcRuleEn          ;
extern FIELD_IDX_T A_ExtExecution_Quote                    ;
extern FIELD_IDX_T A_ExtExecution_Rate                     ;
extern FIELD_IDX_T A_ExtExecution_SupplAmt                 ;
extern FIELD_IDX_T A_ExtExecution_OpGrossAmt               ;
extern FIELD_IDX_T A_ExtExecution_AccrAmt                  ;
extern FIELD_IDX_T A_ExtExecution_OpNetAmt                 ;
extern FIELD_IDX_T A_ExtExecution_FiNetAmt                 ;
extern FIELD_IDX_T A_ExtExecution_PfNetAmt                 ;
extern FIELD_IDX_T A_ExtExecution_SysNetAmt                ;
extern FIELD_IDX_T A_ExtExecution_AccNetAmt                ;
extern FIELD_IDX_T A_ExtExecution_Acc2NetAmt               ;
extern FIELD_IDX_T A_ExtExecution_Acc3NetAmt               ;
extern FIELD_IDX_T A_ExtExecution_Bp1TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp1CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp1Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp2TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp2CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp2Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp3TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp3CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp3Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp4TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp4CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp4Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp5TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp5CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp5Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp6TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp6CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp6Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp7TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp7CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp7Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp8TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp8CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp8Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp9TypeId                ;
extern FIELD_IDX_T A_ExtExecution_Bp9CurrencyId            ;
extern FIELD_IDX_T A_ExtExecution_Bp9Amt                   ;
extern FIELD_IDX_T A_ExtExecution_Bp10TypeId               ;
extern FIELD_IDX_T A_ExtExecution_Bp10CurrencyId           ;
extern FIELD_IDX_T A_ExtExecution_Bp10Amt                  ;
extern FIELD_IDX_T A_ExtExecution_LastUserId			   ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_ExtExecution_LastModifDate            ; /*REF11249-BRO-060524*/
extern FIELD_IDX_T A_ExtExecution_PtfId                    ;
extern FIELD_IDX_T A_ExtExecution_InstrId                  ;
extern FIELD_IDX_T A_ExtExecution_NoPositionFlg            ; /*PMSTA07201-BRO-090206*/
extern FIELD_IDX_T A_ExtExecution_OpCurrencyId             ;
extern FIELD_IDX_T A_ExtExecution_ExtOrder_Ext             ;
extern FIELD_IDX_T A_ExtExecution_SelectedFlg              ;    /*  FIH-REF11457-051014 */
extern FIELD_IDX_T A_ExtExecution_BoPtfId                  ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtExecution_BoAccountId              ; /* PMSTA-38454 - srinivas   - 17022020 */

/* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
#if 0
extern FIELD_IDX_T A_LightOrder_Id                         ;
extern FIELD_IDX_T A_LightOrder_NatureEn                   ;
extern FIELD_IDX_T A_LightOrder_FunctionResultId           ;
extern FIELD_IDX_T A_LightOrder_Cd                         ;
extern FIELD_IDX_T A_LightOrder_InputUserId                ;
extern FIELD_IDX_T A_LightOrder_TypeId                     ;
extern FIELD_IDX_T A_LightOrder_SubtypeId                  ;
extern FIELD_IDX_T A_LightOrder_MarketThirdId              ;
extern FIELD_IDX_T A_LightOrder_IntermedThirdId            ;
extern FIELD_IDX_T A_LightOrder_ManagerId                  ;
extern FIELD_IDX_T A_LightOrder_SourceCd                   ;
extern FIELD_IDX_T A_LightOrder_LimitQuote                 ;
extern FIELD_IDX_T A_LightOrder_LimitPrice                 ;
extern FIELD_IDX_T A_LightOrder_StopQuote                  ;
extern FIELD_IDX_T A_LightOrder_StopPrice                  ;
extern FIELD_IDX_T A_LightOrder_OrderPriceNatEn            ;
extern FIELD_IDX_T A_LightOrder_OrderValidityNatEn         ;
extern FIELD_IDX_T A_LightOrder_MinOrderQty                ;
extern FIELD_IDX_T A_LightOrder_ParentOperationCd          ;
extern FIELD_IDX_T A_LightOrder_ParentOperNatEn            ;
extern FIELD_IDX_T A_LightOrder_CheckParentEn              ;
extern FIELD_IDX_T A_LightOrder_CheckStratEn               ;
extern FIELD_IDX_T A_LightOrder_OrderNatEn                 ;
extern FIELD_IDX_T A_LightOrder_OperationDate              ;
extern FIELD_IDX_T A_LightOrder_ValuationDate              ;
extern FIELD_IDX_T A_LightOrder_OrderLimitDate             ;
extern FIELD_IDX_T A_LightOrder_ValueDate                  ;
extern FIELD_IDX_T A_LightOrder_RefOperCd                  ;
extern FIELD_IDX_T A_LightOrder_RefNatEn                   ;
extern FIELD_IDX_T A_LightOrder_StatusEn                   ;
extern FIELD_IDX_T A_LightOrder_SequenceNo                 ;
extern FIELD_IDX_T A_LightOrder_PortfolioId                ;
extern FIELD_IDX_T A_LightOrder_InstrId                    ;
extern FIELD_IDX_T A_LightOrder_DepositId                  ;
extern FIELD_IDX_T A_LightOrder_OpCurrencyId               ;
extern FIELD_IDX_T A_LightOrder_CounterpartyThirdId        ;
extern FIELD_IDX_T A_LightOrder_ExpirationDate             ;
extern FIELD_IDX_T A_LightOrder_Remark                     ;
extern FIELD_IDX_T A_LightOrder_Quantity                   ;
extern FIELD_IDX_T A_LightOrder_Rate                       ;
extern FIELD_IDX_T A_LightOrder_AudUsername                ;
extern FIELD_IDX_T A_LightOrder_AudModifDate               ;
extern FIELD_IDX_T A_LightOrder_AudAction                  ;
extern FIELD_IDX_T A_LightOrder_LastUserId                 ;
extern FIELD_IDX_T A_LightOrder_LastModifDate              ;
extern FIELD_IDX_T A_LightOrder_CreationTimeDate           ;
extern FIELD_IDX_T A_LightOrder_AccountId                  ;
extern FIELD_IDX_T A_LightOrder_TradeCurrencyId            ; /*REF9446-BRO-030930*/


extern FIELD_IDX_T S_LightOrder_Id                         ;
extern FIELD_IDX_T S_LightOrder_Cd                         ;
#endif

extern FIELD_IDX_T GetFile_I_Name                          ;
extern FIELD_IDX_T GetFile_I_Text                          ;
extern FIELD_IDX_T GetFile_I_Size                          ;
extern FIELD_IDX_T GetFile_I_ApplSessionCd                 ; /* PMSTA-33865 - JBC - 190306 */

extern FIELD_IDX_T GetFile_O_Size                          ;
extern FIELD_IDX_T GetFile_O_Data                          ;

/* REF9464 - CHU - 031222 */
extern FIELD_IDX_T A_UnMatchedExecution_Id                 ;
extern FIELD_IDX_T A_UnMatchedExecution_ExtOrderId         ;
extern FIELD_IDX_T A_UnMatchedExecution_ExecutionId        ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedExecution_GlobalExecFeeId    ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedExecution_TypeId             ;
extern FIELD_IDX_T A_UnMatchedExecution_SubtypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_MarketThirdId      ;
extern FIELD_IDX_T A_UnMatchedExecution_IntermedThirdId    ;
extern FIELD_IDX_T A_UnMatchedExecution_CheckStratEn       ;
extern FIELD_IDX_T A_UnMatchedExecution_AccountDate        ;
extern FIELD_IDX_T A_UnMatchedExecution_OperationDate      ;
extern FIELD_IDX_T A_UnMatchedExecution_ValueDate          ;
extern FIELD_IDX_T A_UnMatchedExecution_StatusEn           ;
extern FIELD_IDX_T A_UnMatchedExecution_SequenceNo         ;
extern FIELD_IDX_T A_UnMatchedExecution_CashPortfolioId    ;
extern FIELD_IDX_T A_UnMatchedExecution_BpTypeId           ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedExecution_AccountId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Account2Id         ;
extern FIELD_IDX_T A_UnMatchedExecution_Account3Id         ;
extern FIELD_IDX_T A_UnMatchedExecution_DepositId          ;
extern FIELD_IDX_T A_UnMatchedExecution_AccCurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc2CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc3CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedExecution_TradeCurrencyId    ;
extern FIELD_IDX_T A_UnMatchedExecution_CashPfCurrId       ;
extern FIELD_IDX_T A_UnMatchedExecution_CounterpartyThirdId;
extern FIELD_IDX_T A_UnMatchedExecution_TermTypeId         ;
extern FIELD_IDX_T A_UnMatchedExecution_AccrBpTypeId       ;
extern FIELD_IDX_T A_UnMatchedExecution_AccountedFlg       ;
extern FIELD_IDX_T A_UnMatchedExecution_BeginDate          ;
extern FIELD_IDX_T A_UnMatchedExecution_ExecutionDate      ;
extern FIELD_IDX_T A_UnMatchedExecution_ExecutionSetCriteria;
extern FIELD_IDX_T A_UnMatchedExecution_NatureEn           ;
extern FIELD_IDX_T A_UnMatchedExecution_ExecNatureEn       ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedExecution_Remark             ;
extern FIELD_IDX_T A_UnMatchedExecution_OpExchRate         ;
extern FIELD_IDX_T A_UnMatchedExecution_FiExchRate         ;
extern FIELD_IDX_T A_UnMatchedExecution_SysExchRate        ;
extern FIELD_IDX_T A_UnMatchedExecution_AccExchRate        ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc2ExchRate       ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc3ExchRate       ;
extern FIELD_IDX_T A_UnMatchedExecution_TradeExchRate      ;
extern FIELD_IDX_T A_UnMatchedExecution_CashPfExchRate     ;
extern FIELD_IDX_T A_UnMatchedExecution_Quantity           ;
extern FIELD_IDX_T A_UnMatchedExecution_Price              ;
extern FIELD_IDX_T A_UnMatchedExecution_PriceCalcRuleEn    ;
extern FIELD_IDX_T A_UnMatchedExecution_Quote              ;
extern FIELD_IDX_T A_UnMatchedExecution_Rate               ;
extern FIELD_IDX_T A_UnMatchedExecution_SupplAmt           ;
extern FIELD_IDX_T A_UnMatchedExecution_OpGrossAmt         ;
extern FIELD_IDX_T A_UnMatchedExecution_AccrAmt            ;
extern FIELD_IDX_T A_UnMatchedExecution_OpNetAmt           ;
extern FIELD_IDX_T A_UnMatchedExecution_FiNetAmt           ;
extern FIELD_IDX_T A_UnMatchedExecution_PfNetAmt           ;
extern FIELD_IDX_T A_UnMatchedExecution_SysNetAmt          ;
extern FIELD_IDX_T A_UnMatchedExecution_AccNetAmt          ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc2NetAmt         ;
extern FIELD_IDX_T A_UnMatchedExecution_Acc3NetAmt         ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp1TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp1CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp1Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp2TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp2CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp2Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp3TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp3CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp3Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp4TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp4CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp4Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp5TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp5CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp5Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp6TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp6CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp6Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp7TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp7CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp7Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp8TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp8CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp8Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp9TypeId          ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp9CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp9Amt             ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp10TypeId         ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp10CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedExecution_Bp10Amt            ;
extern FIELD_IDX_T A_UnMatchedExecution_PtfId              ;
extern FIELD_IDX_T A_UnMatchedExecution_InstrId            ;
extern FIELD_IDX_T A_UnMatchedExecution_OpCurrencyId       ;
extern FIELD_IDX_T A_UnMatchedExecution_FailedImportEn     ;
extern FIELD_IDX_T A_UnMatchedExecution_ImportModeEn       ;
extern FIELD_IDX_T A_UnMatchedExecution_ExtOrderCd         ;
extern FIELD_IDX_T A_UnMatchedExecution_ConfirmFlg         ;
extern FIELD_IDX_T A_UnMatchedExecution_A_Ptf_Ext          ;
extern FIELD_IDX_T A_UnMatchedExecution_A_Instr_Ext        ;
extern FIELD_IDX_T A_UnMatchedExecution_EditBackupPtr      ;    /*  FIH-REF9764-040211  */
extern FIELD_IDX_T A_UnMatchedExecution_TraderThirdId      ;


/* REF9464 - CHU - 031222 */
extern FIELD_IDX_T S_UnMatchedExecution_Id                 ;
extern FIELD_IDX_T S_UnMatchedExecution_ExtOrderId         ;
extern FIELD_IDX_T S_UnMatchedExecution_SequenceNo         ;
extern FIELD_IDX_T S_UnMatchedExecution_ExecutionSetCriteria;
extern FIELD_IDX_T S_UnMatchedExecution_StatusEn           ;
extern FIELD_IDX_T S_UnMatchedExecution_AccountedFlg       ;
extern FIELD_IDX_T S_UnMatchedExecution_NatureEn           ;
extern FIELD_IDX_T S_UnMatchedExecution_FailedImportEn     ;
extern FIELD_IDX_T S_UnMatchedExecution_ImportModeEn       ;
extern FIELD_IDX_T S_UnMatchedExecution_ExtOrderCd         ;
extern FIELD_IDX_T S_UnMatchedExecution_ConfirmFlg         ;


/*REF10025-BRO-040401*/
extern FIELD_IDX_T A_UnMatchedGlExecFee_Id                 ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExtOrderId         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionId        ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedGlExecFee_GlobalExecFeeId    ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedGlExecFee_TypeId             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SubtypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_MarketThirdId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_IntermedThirdId    ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_CheckStratEn       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccountDate        ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_OperationDate      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ValueDate          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_StatusEn           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SequenceNo         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_CashPortfolioId    ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_BpTypeId           ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccountId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Account2Id         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Account3Id         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_DepositId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccCurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc2CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc3CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_TradeCurrencyId    ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_CashPfCurrId       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_CounterpartyThirdId;
extern FIELD_IDX_T A_UnMatchedGlExecFee_TermTypeId         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccrBpTypeId       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccountedFlg       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_BeginDate          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionDate      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExecutionSetCriteria;
extern FIELD_IDX_T A_UnMatchedGlExecFee_NatureEn           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExecNatureEn       ;    /*  FIH-REF9764-031229  */
extern FIELD_IDX_T A_UnMatchedGlExecFee_Remark             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_OpExchRate         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_FiExchRate         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SysExchRate        ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccExchRate        ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc2ExchRate       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc3ExchRate       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_TradeExchRate      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_CashPfExchRate     ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Quantity           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Price              ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_PriceCalcRuleEn    ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Quote              ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Rate               ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SupplAmt           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_OpGrossAmt         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccrAmt            ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_OpNetAmt           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_FiNetAmt           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_PfNetAmt           ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SysNetAmt          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_AccNetAmt          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc2NetAmt         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Acc3NetAmt         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp1TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp1CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp1Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp2TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp2CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp2Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp3TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp3CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp3Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp4TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp4CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp4Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp5TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp5CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp5Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp6TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp6CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp6Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp7TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp7CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp7Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp8TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp8CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp8Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp9TypeId          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp9CurrencyId      ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp9Amt             ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp10TypeId         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp10CurrencyId     ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_Bp10Amt            ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_PtfId              ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_InstrId            ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_OpCurrencyId       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_FailedImportEn     ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ImportModeEn       ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ExtOrderCd         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_ConfirmFlg         ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SetOfFeesId		   ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_SetOfProductFeesId ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_BoRoutingBusEntityId	;
extern FIELD_IDX_T A_UnMatchedGlExecFee_A_Ptf_Ext          ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_A_Instr_Ext        ;
extern FIELD_IDX_T A_UnMatchedGlExecFee_EditBackupPtr      ;    /*  FIH-REF9764-040211  */


/* REF9764 - LJE - 040106 */
extern FIELD_IDX_T A_ExtTransaction_Id                     ;
extern FIELD_IDX_T A_ExtTransaction_SrcEntityDictId        ;
extern FIELD_IDX_T A_ExtTransaction_SrcObjectId            ;
extern FIELD_IDX_T A_ExtTransaction_ParentExtTransId       ;
extern FIELD_IDX_T A_ExtTransaction_MatchedFlg             ;
extern FIELD_IDX_T A_ExtTransaction_ExtOrderId             ;
extern FIELD_IDX_T A_ExtTransaction_AccountedFlg           ;    /*  FIH-REF10615-041015 */
extern FIELD_IDX_T A_ExtTransaction_SequenceNo             ;
extern FIELD_IDX_T A_ExtTransaction_ConfirmedFlg           ;
extern FIELD_IDX_T A_ExtTransaction_ImportMode             ;
extern FIELD_IDX_T A_ExtTransaction_ExecNatureEn           ;    /*  FIH-REF10234-040607 */
extern FIELD_IDX_T A_ExtTransaction_SelectedFlg            ;    /*  FIH-REF11457-051014 */
extern FIELD_IDX_T A_ExtTransaction_InSessionFlg           ;    /*  PMSTA9052-EFE-091126 */
extern FIELD_IDX_T A_ExtTransaction_DraftOrderId           ;	/*  PMSTA09160-CHU-100106 */
extern FIELD_IDX_T A_ExtTransaction_A_Ptf_Ext              ;
extern FIELD_IDX_T A_ExtTransaction_A_Instr_Ext            ;
extern FIELD_IDX_T A_ExtTransaction_Child_Ext              ;
extern FIELD_IDX_T A_ExtTransaction_Parent_Ext             ;
extern FIELD_IDX_T A_ExtTransaction_Clone_Ext              ;
extern FIELD_IDX_T A_ExtTransaction_EditBackupPtr          ;
extern FIELD_IDX_T A_ExtTransaction_OriginalQty			   ;	/* PMSTA-37908 - adarshn - 191119 */
extern FIELD_IDX_T A_ExtTransaction_OrderNettingEn		   ;	/* PMSTA-37908 - adarshn - 191119 */
extern FIELD_IDX_T A_ExtTransaction_NettingCriteria        ;    /* PMSTA-37908 - adarshn - 08012020 */
extern FIELD_IDX_T A_ExtTransaction_BoPtfId                ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_BoAccountId            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_OpSplitRuleEn          ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_AdjBoPtfId             ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_CoaExDate              ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_BoCashAcctId           ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_BoCashPtfId            ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_SplitParentOperId      ; /* PMSTA-38454 - srinivas   - 17022020 */
extern FIELD_IDX_T A_ExtTransaction_RuleApplicabilityEn	   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_SmartRoundingQty       ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_SmartRoundingOrgQty	   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_RoundingOrgQty		   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_SmartRoundingFlg	   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_SmartRoundingRuleId	   ; /* PMSTA-40493-badhri-08252020: smart rounding rule */
extern FIELD_IDX_T A_ExtTransaction_HierOperNatEn          ; /* PMSTA-40208 - adarshn	- 02092020 */
extern FIELD_IDX_T A_ExtTransaction_HierOperationCd        ; /* PMSTA-40208 - adarshn	- 02092020 */
extern FIELD_IDX_T A_ExtTransaction_ParentHierExtOpId      ; /* PMSTA-40208 - adarshn	- 02092020 */
extern FIELD_IDX_T A_ExtTransaction_CashPlanId             ; /* PMSTA-42402 - Vishnu  16112020   */
extern FIELD_IDX_T A_ExtTransaction_NotionalInstrId        ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T A_ExtTransaction_InvestLimitEn          ; /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
extern FIELD_IDX_T A_ExtTransaction_AdjRefNatEn            ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T A_ExtTransaction_AdjRefOperCd           ; /* PMSTA-49729 - Deepthi - 220711 */
extern FIELD_IDX_T A_ExtTransaction_SetOfFeesId			   ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_ExtTransaction_SetOfProductFeesId     ; /* PMSTA-51324 - Lekshmi - 221128 */
extern FIELD_IDX_T A_ExtTransaction_BoRoutingBusEntityId   ; /* PMSTA-52619 - Sathees - 230327 */
extern FIELD_IDX_T A_ExtTransaction_SetOfOtherFeesId       ; /* WEALTH-5030 - CHANDRU - 05022024 */
extern FIELD_IDX_T A_ExtTransaction_TraderThirdId          ; /* WEALTH-5053 - CHANDRU - 07022024 */
extern FIELD_IDX_T A_ExtTransaction_NetSettleAmount        ; 
extern FIELD_IDX_T A_ExtTransaction_PremiumCurrencyId      ; /* WEALTH-8559 - Senthil - 20240607 */
extern FIELD_IDX_T A_ExtTransaction_PremiumAmount          ; /* WEALTH-8559 - Senthil - 20240607 */


/* REF11767 - CHU - 060411 */
extern FIELD_IDX_T OptiPurge_ProcCd                        ;
extern FIELD_IDX_T OptiPurge_Entity                        ;

/* REF11767 - CHU - 060504 */
extern FIELD_IDX_T OptiCheckIn_ProcCd                      ;
extern FIELD_IDX_T OptiCheckIn_Entity                      ;
extern FIELD_IDX_T OptiCheckIn_DetailEn                    ;

/* REF11767 - CHU - 060504 */
extern FIELD_IDX_T OptiCheckOut_SrvName                    ;
extern FIELD_IDX_T OptiCheckOut_ProcName                   ;
extern FIELD_IDX_T OptiCheckOut_EntityName                 ;
extern FIELD_IDX_T OptiCheckOut_AllocBloc                  ;
extern FIELD_IDX_T OptiCheckOut_MaxAllocBloc               ;
extern FIELD_IDX_T OptiCheckOut_RequestNb                  ;
extern FIELD_IDX_T OptiCheckOut_FreeRequestNb              ;
extern FIELD_IDX_T OptiCheckOut_PercentUsed                ;
extern FIELD_IDX_T OptiCheckOut_PercentFree                ;
extern FIELD_IDX_T OptiCheckOut_TotalReads                 ;
extern FIELD_IDX_T OptiCheckOut_ReadHits                   ;
extern FIELD_IDX_T OptiCheckOut_PercentReadHits            ;
extern FIELD_IDX_T OptiCheckOut_ReadMisses                 ;
extern FIELD_IDX_T OptiCheckOut_PercentReadMisses          ;
extern FIELD_IDX_T OptiCheckOut_CacheFull                  ;
extern FIELD_IDX_T OptiCheckOut_PurgeNumber                ;
extern FIELD_IDX_T OptiCheckOut_LastPurgeDate              ;
extern FIELD_IDX_T OptiCheckOut_UsedMemory                 ;

/*  FPL-REF11314-060516 */
extern FIELD_IDX_T SecuCheck_FctCreate                     ;
extern FIELD_IDX_T SecuCheck_FctUpdate                     ;
extern FIELD_IDX_T SecuCheck_FctDelete                     ;
extern FIELD_IDX_T SecuCheck_DataUpdate                    ;
extern FIELD_IDX_T SecuCheck_DataDelete                    ;
extern FIELD_IDX_T SecuCheck_Gui                           ;
extern FIELD_IDX_T SecuCheck_Script                        ;

/* BSA - PMSTA01179 - 061215 */
extern FIELD_IDX_T A_OpenedPosition_PtfId                  ;
extern FIELD_IDX_T A_OpenedPosition_InstrId                ;
extern FIELD_IDX_T A_OpenedPosition_StatEn                 ;
extern FIELD_IDX_T A_OpenedPosition_PtfPosSetId            ;
extern FIELD_IDX_T A_OpenedPosition_OpPosId                ;

/* PMSTA11809 - PRS - 110428 */
/* entity comment */
extern FIELD_IDX_T A_EntityComment_Id                      ;
extern FIELD_IDX_T A_EntityComment_EntDictId               ;
extern FIELD_IDX_T A_EntityComment_LangDictId              ;
extern FIELD_IDX_T A_EntityComment_StatusEn                ;
extern FIELD_IDX_T A_EntityComment_DraftComment            ;
extern FIELD_IDX_T A_EntityComment_DraftUserId             ;
extern FIELD_IDX_T A_EntityComment_DraftDate               ;
extern FIELD_IDX_T A_EntityComment_Comment                 ;
extern FIELD_IDX_T A_EntityComment_UserId                  ;
extern FIELD_IDX_T A_EntityComment_CommentDate             ;
extern FIELD_IDX_T A_EntityComment_Timestamp               ;
extern FIELD_IDX_T A_EntityComment_NbAttributeToComment    ;
extern FIELD_IDX_T A_EntityComment_NbAttributeToReview     ;
extern FIELD_IDX_T A_EntityComment_NbAttributeToFinalReview;
extern FIELD_IDX_T A_EntityComment_NbPermValToComment      ;
extern FIELD_IDX_T A_EntityComment_NbPermValToReview       ;
extern FIELD_IDX_T A_EntityComment_NbPermValToFinalReview  ;

extern FIELD_IDX_T S_EntityComment_Id                      ;
extern FIELD_IDX_T S_EntityComment_EntDictId               ;
extern FIELD_IDX_T S_EntityComment_LangDictId              ;
extern FIELD_IDX_T S_EntityComment_StatusEn                ;
extern FIELD_IDX_T S_EntityComment_EntityName              ;
extern FIELD_IDX_T S_EntityComment_LanguageName            ;
extern FIELD_IDX_T S_EntityComment_NbAttributeToComment    ;
extern FIELD_IDX_T S_EntityComment_NbAttributeToReview     ;
extern FIELD_IDX_T S_EntityComment_NbAttributeToFinalReview;
extern FIELD_IDX_T S_EntityComment_NbPermValToComment      ;
extern FIELD_IDX_T S_EntityComment_NbPermValToReview       ;
extern FIELD_IDX_T S_EntityComment_NbPermValToFinalReview  ;

/* attribute comment */
extern FIELD_IDX_T A_AttributeComment_Id                    ;
extern FIELD_IDX_T A_AttributeComment_AttrDictId            ;
extern FIELD_IDX_T A_AttributeComment_LangDictId            ;
extern FIELD_IDX_T A_AttributeComment_StatusEn              ;
extern FIELD_IDX_T A_AttributeComment_DraftComment          ;
extern FIELD_IDX_T A_AttributeComment_DraftUserId           ;
extern FIELD_IDX_T A_AttributeComment_DraftDate             ;
extern FIELD_IDX_T A_AttributeComment_Comment               ;
extern FIELD_IDX_T A_AttributeComment_UserId                ;
extern FIELD_IDX_T A_AttributeComment_CommentDate           ;
extern FIELD_IDX_T A_AttributeComment_Timestamp             ;
extern FIELD_IDX_T A_AttributeComment_EntityCommentId       ;
extern FIELD_IDX_T A_AttributeComment_NbPermValToComment    ;
extern FIELD_IDX_T A_AttributeComment_NbPermValToReview     ;
extern FIELD_IDX_T A_AttributeComment_NbPermValToFinalReview;

extern FIELD_IDX_T S_AttributeComment_Id                    ;
extern FIELD_IDX_T S_AttributeComment_AttrDictId            ;
extern FIELD_IDX_T S_AttributeComment_LangDictId            ;
extern FIELD_IDX_T S_AttributeComment_StatusEn              ;
extern FIELD_IDX_T S_AttributeComment_EntityCommentId       ;
extern FIELD_IDX_T S_AttributeComment_AttributeName         ;
extern FIELD_IDX_T S_AttributeComment_LanguageName          ;
extern FIELD_IDX_T S_AttributeComment_NbPermValToComment    ;
extern FIELD_IDX_T S_AttributeComment_NbPermValToReview     ;
extern FIELD_IDX_T S_AttributeComment_NbPermValToFinalReview;

/* perm value comment */
extern FIELD_IDX_T A_PermValComment_Id                     ;
extern FIELD_IDX_T A_PermValComment_AttrDictId             ;
extern FIELD_IDX_T A_PermValComment_AttributeCommentId     ;
extern FIELD_IDX_T A_PermValComment_NatEn                  ;
extern FIELD_IDX_T A_PermValComment_LangDictId             ;
extern FIELD_IDX_T A_PermValComment_StatusEn               ;
extern FIELD_IDX_T A_PermValComment_DraftComment           ;
extern FIELD_IDX_T A_PermValComment_DraftUserId            ;
extern FIELD_IDX_T A_PermValComment_DraftDate              ;
extern FIELD_IDX_T A_PermValComment_Comment                ;
extern FIELD_IDX_T A_PermValComment_UserId                 ;
extern FIELD_IDX_T A_PermValComment_CommentDate            ;
extern FIELD_IDX_T A_PermValComment_Timestamp              ;

extern FIELD_IDX_T S_PermValComment_Id                     ;
extern FIELD_IDX_T S_PermValComment_AttrDictId             ;
extern FIELD_IDX_T S_PermValComment_AttributeCommentId     ;
extern FIELD_IDX_T S_PermValComment_StatusEn               ;
extern FIELD_IDX_T S_PermValComment_NatEn                  ;
extern FIELD_IDX_T S_PermValComment_LangDictId             ;
extern FIELD_IDX_T S_PermValComment_AttributeName          ;
extern FIELD_IDX_T S_PermValComment_LanguageName           ;
extern FIELD_IDX_T S_PermValComment_NatEnLabel             ;

/* appl param comment */
extern FIELD_IDX_T A_ApplParamComment_Id                   ;
extern FIELD_IDX_T A_ApplParamComment_ParamName            ;
extern FIELD_IDX_T A_ApplParamComment_LangDictId           ;
extern FIELD_IDX_T A_ApplParamComment_StatusEn             ;
extern FIELD_IDX_T A_ApplParamComment_DraftComment         ;
extern FIELD_IDX_T A_ApplParamComment_DraftUserId          ;
extern FIELD_IDX_T A_ApplParamComment_DraftDate            ;
extern FIELD_IDX_T A_ApplParamComment_Comment              ;
extern FIELD_IDX_T A_ApplParamComment_UserId               ;
extern FIELD_IDX_T A_ApplParamComment_CommentDate          ;
extern FIELD_IDX_T A_ApplParamComment_Timestamp            ;

extern FIELD_IDX_T S_ApplParamComment_Id                   ;
extern FIELD_IDX_T S_ApplParamComment_ParamName            ;
extern FIELD_IDX_T S_ApplParamComment_LangDictId           ;
extern FIELD_IDX_T S_ApplParamComment_StatusEn             ;
extern FIELD_IDX_T S_ApplParamComment_LanguageName         ;

extern FIELD_IDX_T A_XdPermVal_Id                        ;
extern FIELD_IDX_T A_XdPermVal_XdAttribId                ;
extern FIELD_IDX_T A_XdPermVal_PermValNatEn              ;
extern FIELD_IDX_T A_XdPermVal_Name                      ;
extern FIELD_IDX_T A_XdPermVal_Rank                      ;
extern FIELD_IDX_T A_XdPermVal_RefXdEntityId             ;
extern FIELD_IDX_T A_XdPermVal_PermValRuleEn;
extern FIELD_IDX_T A_XdPermVal_DbRuleEn;
extern FIELD_IDX_T A_XdPermVal_XdActionEn                ;
extern FIELD_IDX_T A_XdPermVal_XdStatusEn                ;
extern FIELD_IDX_T A_XdPermVal_BuildDate                 ;
extern FIELD_IDX_T A_XdPermVal_DictId                    ;

extern FIELD_IDX_T S_XdPermVal_Id                        ;
extern FIELD_IDX_T S_XdPermVal_XdAttrId                  ;
extern FIELD_IDX_T S_XdPermVal_PermValNatEn              ;
extern FIELD_IDX_T S_XdPermVal_Name                      ;
extern FIELD_IDX_T S_XdPermVal_Rank                      ;

/* PMSTA13167 - DDV - 111215 - add new structure for session management */
extern FIELD_IDX_T SessionMgt_FromId                       ;
extern FIELD_IDX_T SessionMgt_FromCd                       ;
extern FIELD_IDX_T SessionMgt_LangDictId                   ;
extern FIELD_IDX_T SessionMgt_UserId                       ;
extern FIELD_IDX_T SessionMgt_Mode                         ;
extern FIELD_IDX_T SessionMgt_OldOption                    ;
extern FIELD_IDX_T SessionMgt_KeepCommFlg                  ;
extern FIELD_IDX_T SessionMgt_BuySellFlg                   ;
extern FIELD_IDX_T SessionMgt_ExternalPosFlg               ;
extern FIELD_IDX_T SessionMgt_CopyEntityList               ;
extern FIELD_IDX_T SessionMgt_MergeCdList                  ;
extern FIELD_IDX_T SessionMgt_ApplSessionCd                ; /* PMSTA-22549 - CHU - 160512 */
extern FIELD_IDX_T SessionMgt_OrderIdList				   ; /* PMSTA-39396 - Silpakal - 200320 */

extern FIELD_IDX_T A_PurgeEntity_Sqlname                     ; /* PMSTA15008-JPP-20120920 */
extern FIELD_IDX_T A_PurgeEntity_Filter                      ; /* PMSTA15008-JPP-20120920 */

/* PMSTA21215 - PCL */
extern FIELD_IDX_T A_StartFusionByCd_DimPortSqlName        ;
extern FIELD_IDX_T A_StartFusionByCd_PortObjectCd          ;
extern FIELD_IDX_T A_StartFusionByCd_BeginDate             ;
extern FIELD_IDX_T A_StartFusionByCd_FusionScopeFlg        ;
extern FIELD_IDX_T A_StartFusionByCd_SynchronousFlg        ;
extern FIELD_IDX_T A_StartFusionByCd_DimPortDictId         ;
extern FIELD_IDX_T A_StartFusionByCd_PortObjectId          ;
extern FIELD_IDX_T A_StartFusionByCd_EndDate               ;
extern FIELD_IDX_T A_StartFusionByCd_AutomaticFlg          ;
extern FIELD_IDX_T A_StartFusionByCd_PortfolioSizeEn       ;
extern FIELD_IDX_T A_StartFusionByCd_DispatchServer        ;
extern FIELD_IDX_T A_StartFusionByCd_SyncTimeOut           ;
extern FIELD_IDX_T A_StartFusionByCd_ServerId              ;
extern FIELD_IDX_T A_StartFusionByCd_ApplSessionCd         ;

/* PMSTA-21105 - cashwini - 150831 */
extern FIELD_IDX_T A_DomainPtfCompo_Id;
extern FIELD_IDX_T A_DomainPtfCompo_FunctionResultId;
extern FIELD_IDX_T A_DomainPtfCompo_PtfId;
extern FIELD_IDX_T A_DomainPtfCompo_ThirdId;
extern FIELD_IDX_T A_DomainPtfCompo_PtfThirdCompoId;
extern FIELD_IDX_T A_DomainPtfCompo_DefaultStratId;
extern FIELD_IDX_T A_DomainPtfCompo_ForcedStratId;
extern FIELD_IDX_T A_DomainPtfCompo_ThirdCompo;
extern FIELD_IDX_T A_DomainPtfCompo_OnlyUsedForOrder;

extern FIELD_IDX_T S_DomainPtfCompo_Id;
extern FIELD_IDX_T S_DomainPtfCompo_FunctionResultId;
extern FIELD_IDX_T S_DomainPtfCompo_FunctionResultCd;
extern FIELD_IDX_T S_DomainPtfCompo_PtfId;
extern FIELD_IDX_T S_DomainPtfCompo_PtfCd;


extern FIELD_IDX_T  A_ApplChannelProf_Id;
extern FIELD_IDX_T  A_ApplChannelProf_Cd;
extern FIELD_IDX_T  A_ApplChannelProf_MaxSession;

extern FIELD_IDX_T  S_ApplChannelProf_Id;
extern FIELD_IDX_T  S_ApplChannelProf_Cd;

extern FIELD_IDX_T  A_ApplChannelProfCompo_Id;
extern FIELD_IDX_T  A_ApplChannelProfCompo_ApplChannelProfId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_ApplChanId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_FuncSecuProfId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_ReportProfId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_ScreenProfId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_SearchProfId;
extern FIELD_IDX_T  A_ApplChannelProfCompo_MaxSession;
extern FIELD_IDX_T  A_ApplChannelProfCompo_SessionTimeoutSec;

extern FIELD_IDX_T  S_ApplChannelProfCompo_Id;
extern FIELD_IDX_T  S_ApplChannelProfCompo_ApplChannelProfId;
extern FIELD_IDX_T  S_ApplChannelProfCompo_ApplChanId;
extern FIELD_IDX_T  S_ApplChannelProfCompo_ApplChannelProfCd;
extern FIELD_IDX_T  S_ApplChannelProfCompo_ApplChanCd;

/*> PMSTA-22551 - EFE - 20160323 */

/* < PMSTA-22458 - cashwini - 160502 */
extern FIELD_IDX_T A_ComplianceChronoFreq_Id;
extern FIELD_IDX_T A_ComplianceChronoFreq_PtfId;
extern FIELD_IDX_T A_ComplianceChronoFreq_StratId;
extern FIELD_IDX_T A_ComplianceChronoFreq_ValidDate;
extern FIELD_IDX_T A_ComplianceChronoFreq_ThirdPartyId;
extern FIELD_IDX_T A_ComplianceChronoFreq_SubNatTypeId;
extern FIELD_IDX_T A_ComplianceChronoFreq_FreqDate;
extern FIELD_IDX_T A_ComplianceChronoFreq_CompNatEn;
extern FIELD_IDX_T A_ComplianceChronoFreq_NatEn;
extern FIELD_IDX_T A_ComplianceChronoFreq_Val;
extern FIELD_IDX_T A_ComplianceChronoFreq_CurrId;
extern FIELD_IDX_T A_ComplianceChronoFreq_Comment;
extern FIELD_IDX_T A_ComplianceChronoFreq_Min;
extern FIELD_IDX_T A_ComplianceChronoFreq_Max;
extern FIELD_IDX_T A_ComplianceChronoFreq_CriticalnessEn;
extern FIELD_IDX_T A_ComplianceChronoFreq_ConfidenceLevel;
extern FIELD_IDX_T A_ComplianceChronoFreq_TimeHorizon;
extern FIELD_IDX_T A_ComplianceChronoFreq_TimeHorizonUnitEn;
extern FIELD_IDX_T A_ComplianceChronoFreq_A_Compl_Ext;
/* PMSTA-22458 - cashwini - 160502 > */

/* PMSTA-28335 - MSR - 171006 > */
extern FIELD_IDX_T AccRuleCompoArg_PortfolioId;
extern FIELD_IDX_T AccRuleCompoArg_InstrumentId;
extern FIELD_IDX_T AccRuleCompoArg_Date;
/* PMSTA-28335 - MSR - 171006 > */

/* PMSTA-32230 - MSR - 130818 */
extern FIELD_IDX_T Arg_ApplUserPrefName_ParamName;
/* PMSTA-32230 - MSR - 130818 */

/* PMSTA-29130 - 200818 - vkumar */
extern FIELD_IDX_T ArgAccRuleCompo_PortfolioId;
extern FIELD_IDX_T ArgAccRuleCompo_Date;
/* PMSTA-29130 - 200818 - vkumar */

/* PMSTA-34198 - 040419 - SGO */
extern FIELD_IDX_T Arg_TopN_FetchRows;
extern FIELD_IDX_T Arg_TopN_ThreadRank;
extern FIELD_IDX_T Arg_TopN_MaxRank;
extern FIELD_IDX_T Arg_TopN_EventId;
extern FIELD_IDX_T Arg_TopN_ServerId;
extern FIELD_IDX_T Arg_TopN_Enum1;
extern FIELD_IDX_T Arg_TopN_Enum2;
extern FIELD_IDX_T Arg_TopN_Flag1;
extern FIELD_IDX_T Arg_TopN_BusEntityId;


/* PMSTA-37138 - 11092019 - sanand */
extern FIELD_IDX_T Arg_WS_PortfolioId;
extern FIELD_IDX_T Arg_WS_InstrId;
extern FIELD_IDX_T Arg_WS_OpDate;
extern FIELD_IDX_T Arg_WS_IdenticalInstrId;
extern FIELD_IDX_T Arg_WS_Relation;

extern FIELD_IDX_T Arg_WS_Op_Src;


/* PMSTA XXXX LIK 30012020*/
extern FIELD_IDX_T Arg_OverlayInitFetch_PtfId;
extern FIELD_IDX_T Arg_OverlayInitFetch_Date;

extern FIELD_IDX_T Arg_OverlayNextFetch_StratId;
extern FIELD_IDX_T Arg_OverlayNextFetch_PtfId;
extern FIELD_IDX_T Arg_OverlayNextFetch_Date;
extern FIELD_IDX_T Arg_OverlayNextFetch_IpFlag;

extern FIELD_IDX_T Arg_StratOvelayFetch_StratId;
extern FIELD_IDX_T Arg_StratOvelayFetch_Date;

extern FIELD_IDX_T Arg_PtfOvelayFetch_PtfId;
extern FIELD_IDX_T Arg_PtfOvelayFetch_StratId;
extern FIELD_IDX_T Arg_PtfOvelayFetch_Date;

/* PMSTA-40209 - LIK - 25082020 */
extern FIELD_IDX_T StandInstructFilterArg_AllFlag;
extern FIELD_IDX_T StandInstructFilterArg_BuyFlag;
extern FIELD_IDX_T StandInstructFilterArg_SellFlag;
extern FIELD_IDX_T StandInstructFilterArg_InvestFlag;
extern FIELD_IDX_T StandInstructFilterArg_WithdrawFlag;
extern FIELD_IDX_T StandInstructFilterArg_CalcRefDate;

extern FIELD_IDX_T SqlRequest_ProcSqlName;
extern FIELD_IDX_T SqlRequest_SqlCmd;
extern FIELD_IDX_T SqlRequest_ReadOnly;
extern FIELD_IDX_T SqlRequest_Parameters;
extern FIELD_IDX_T SqlRequest_ResultSet;

extern FIELD_IDX_T CallRequest_ActionEn;
extern FIELD_IDX_T CallRequest_ReadOnly;
extern FIELD_IDX_T CallRequest_EntitySqlName;
extern FIELD_IDX_T CallRequest_ObjectEn;
extern FIELD_IDX_T CallRequest_Role;
extern FIELD_IDX_T CallRequest_InputData;
extern FIELD_IDX_T CallRequest_AutocreateItems;

extern FIELD_IDX_T AutoCreateItem_MainObject;
extern FIELD_IDX_T AutoCreateItem_MainFKeyFldIndex;
extern FIELD_IDX_T AutoCreateItem_OldMainFKeyId;
extern FIELD_IDX_T AutoCreateItem_RefObject;
extern FIELD_IDX_T AutoCreateItem_RefRec;
extern FIELD_IDX_T AutoCreateItem_RefFKeyFldIndex;
extern FIELD_IDX_T AutoCreateItem_RefId;
extern FIELD_IDX_T AutoCreateItem_Action;
extern FIELD_IDX_T AutoCreateItem_insertFlg;


extern FIELD_IDX_T SqlRequestParam_SqlName;
extern FIELD_IDX_T SqlRequestParam_DataType;
extern FIELD_IDX_T SqlRequestParam_Value;
extern FIELD_IDX_T SqlRequestParam_InputFlg;
extern FIELD_IDX_T SqlRequestParam_OutputFlg;

extern FIELD_IDX_T SqlRequestResultSet_DynSt;
extern FIELD_IDX_T SqlRequestResultSet_Items;

extern FIELD_IDX_T SqlRequestOutputDef_SqlName;
extern FIELD_IDX_T SqlRequestOutputDef_DataType;

extern FIELD_IDX_T SqlRequestMsg_ErrorNo;
extern FIELD_IDX_T SqlRequestMsg_Message;

extern FIELD_IDX_T TemenosPckHeader_Id;
extern FIELD_IDX_T TemenosPckHeader_DsfApiType;
extern FIELD_IDX_T TemenosPckHeader_MetaData;

extern FIELD_IDX_T ProcessingContext_Cmd;
extern FIELD_IDX_T ProcessingContext_EntitProfile;
extern FIELD_IDX_T ProcessingContext_BusEntityCd;
extern FIELD_IDX_T ProcessingContext_Config;
extern FIELD_IDX_T ProcessingContext_LockFields;

extern FIELD_IDX_T Out_Amount_Amount;

extern FIELD_IDX_T O_PackageDefinition_Code;
extern FIELD_IDX_T O_PackageDefinition_Version;
extern FIELD_IDX_T O_PackageDefinition_Name;
extern FIELD_IDX_T O_PackageDefinition_Denomination;
extern FIELD_IDX_T O_PackageDefinition_Nature;
extern FIELD_IDX_T O_PackageDefinition_Status;
extern FIELD_IDX_T O_PackageDefinition_ParentPackageCode;
extern FIELD_IDX_T O_PackageDefinition_ParentPackageVersion;
extern FIELD_IDX_T O_PackageDefinition_RequiredCoreVersion;
extern FIELD_IDX_T O_PackageDefinition_PackageDefinition;
extern FIELD_IDX_T O_PackageDefinition_PackageComposition;

extern FIELD_IDX_T InceptDtArg_DimEntityDictId;
extern FIELD_IDX_T InceptDtArg_DimPtfDictId;
extern FIELD_IDX_T InceptDtArg_PtfObjId;
extern FIELD_IDX_T InceptDtArg_LoadHierFlg;
extern FIELD_IDX_T InceptDtArg_PtfListDef;

/* 031008 - PMO */
/*lint -restore */


#endif

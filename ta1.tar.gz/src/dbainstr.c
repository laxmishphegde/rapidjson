/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAINSTR_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "fin.h"
#include "date.h"
#include "cmp.h"
#include "tls.h"
#include "hier.h"
#include "scptyl.h"

/************************************************************************
**      External entry points
**
** DBA_GetIncEvt()		Get income event.
** DBA_GetInstrByIdCd 		Get an instrument depending on identifier received or code.
** DBA_GetInstrYieldCurve()	Get instrument yield curve.
** DBA_GetFinalIOREvt()		Get final redemption event.
** DBA_GetTermEvt()		Get valid term event.
** DBA_InstrPriceByFreq()	Search prices at determined frequency.
** DBA_SelectExchEvt()		Select valid exchange events in instrument or exchange event table.
** DBA_SelectIncEvt() 		Select valid income event(s) between two dates.
** DBA_SelectInstrCompo()	Select instrument composition.
** DBA_SelectInterCond()	Select valid interest condition between two dates.
** DBA_SelectIOREvt()		Select valid issue or redemption event(s) between two dates.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_CopyInstrIncEvt() 	Copy instrument income event from instrument.
** DBA_CmpInstrPriceDate	Compare intrument price date
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE DBA_CopyInstrIncEvt(DBA_DYNFLD_STP, DBA_DYNFLD_STP);
STATIC RET_CODE DBA_CopyInstrIncEvt2(DBA_DYNFLD_STP, DBA_DYNFLD_STP, INTERCONDNAT_ENUM); /* REF6004 - AKO - 011220 */
STATIC int	DBA_CmpInstrPriceDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);

STATIC RET_CODE	DBA_SelAllInterCondDt2(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*);
STATIC RET_CODE	DBA_SelAllInterCondIdDt2(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*, FLAG_T);
STATIC int	DBA_InterCondInstrIdByIdDtCmp(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC int	DBA_InterCondBegDValDCmp(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC RET_CODE	DBA_BuildValidInterCondTab(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP**, int*, FLAG_T);

STATIC int  DBA_CmpInstrInstrId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
	    DBA_CmpInstrChronoInstrId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
	    DBA_CmpInstrPriceInstrId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
	    DBA_CmpInterCondInstrId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);

STATIC FLAG_T DBA_IsInterCondValid(DBA_DYNFLD_STP interCond, DBA_DYNFLD_STP domainPtr);

/************************************************************************
**      FONCTIONS
************************************************************************/

/************************************************************************
**
**  Function    :   DBA_CmpInstrPriceDate()
**
**  Description :   Compare intrument price date
**
**  Arguments   :   instrPrice1 and instrPrice2 for comparison
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Modif:	REF2544 - SSO - 980717 - TLS_Sort is done in DBA_InstrPriceByFreq
**		    Thus, this function is moved from finlib04.c to dbainstr.c
**
**          REF7061 - TEB - 030106 - Modification and correction with
**                                   Freq_InstrPrice_RequestDate
**
*************************************************************************/
STATIC int DBA_CmpInstrPriceDate(DBA_DYNFLD_STP  *instrPrice1,
                                 DBA_DYNFLD_STP  *instrPrice2)
{
	return(CMP_DYNFLD((*instrPrice1), (*instrPrice2),
                          Freq_InstrPrice_RequestDate, Freq_InstrPrice_RequestDate, /*  REF7061 - TEB - 030106 */
                          DatetimeType));
}

/************************************************************************
*   Function             : DBA_SelectInterCond()
*
*   Description          : Select valid interest condition between two dates
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          interTab     pointer on interest condition table
*                                       which will be allocated and updated
*                          interNbr     pointer on interest condition number
*                                       which will be updated
*
*   Return               : RET_SUCCEED if no error
*
*   Modif		 : DVP561  - RAK - 970815
*   Modif		 : REF1055 - AKO - 981210
*   Modif		 : REF1055 - AKO - 990126
*   Modif		 : REF3696 - SSO - 990518: remove intercond which are beginning after end_date of instr.
*   Modif		 : REF3678 - RAK - 990819 : add freeRecFlg and hierHead parameters
*   Modif        : REF6004 - AKO - 011218 : new parameter due Flow instrument project
*
*************************************************************************/
RET_CODE DBA_SelectInterCond(DBA_DYNFLD_STP instrPtr,
			     DATETIME_T     fromDateTime,
			     DATETIME_T     tillDateTime,
			     DBA_DYNFLD_STP **interTab,
			     int            *interNbr,
			     FLAG_T	    *freeRecFlg,
			     DBA_HIER_HEAD_STP hierHead)
{
    INTERCONDNAT_ENUM InterCondNat=InterCondNat_None;
    return(DBA_SelectInterCond2(instrPtr, fromDateTime,tillDateTime, interTab,interNbr, freeRecFlg, hierHead,InterCondNat));
}

/************************************************************************
*   Function             : DBA_CopyInstrIncEvt()
*
*   Description          : Copy instrument income event from instrument
*
*   Arguments            : income pointer on income structure to fill
*                          instrPtr pointer on instrument structure
*
*   Return               : RET_SUCCEED if no error
*
*   Motif		 : BUG464 - RAK - 970820
*   Motif		 : REF158 - RAK - 971105
*
*************************************************************************/
STATIC RET_CODE DBA_CopyInstrIncEvt(DBA_DYNFLD_STP income,
                                    DBA_DYNFLD_STP instrPtr)
{
	DATETIME_T tmpDate, firstCoup;

	SET_NULL_CODE(income,   A_IncEvt_Cd);
	SET_NULL_DATE(income,   A_IncEvt_ValidDate);
	SET_NULL_ID(income,     A_IncEvt_ExclusiveId);
	SET_NULL_PRICE(income, A_IncEvt_Dividend);		/* DVP264 - 961122 - DED */

	SET_ID(income, A_IncEvt_InstrId, GET_ID(instrPtr, A_Instr_Id));
	SET_ID(income, A_IncEvt_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

        SET_FLAG(income,      A_IncEvt_DivProjectionFlg,   FALSE);
	SET_DATE(income,      A_IncEvt_EndValidDate, MAGIC_END_DATE);
	SET_EXCHANGE(income,  A_IncEvt_FixedExchRate,  1.0);

	if (IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_DatedDate);
            	SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == FALSE)
	    {
		tmpDate = GET_DATETIME(instrPtr, A_Instr_BeginDate);
            	SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
	    }
	    else
	    {
	        if (IS_NULLFLD(instrPtr, A_Instr_FirstCoupDate) == FALSE)
		{
		    tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstCoupDate);
            	    SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
		}
		else
		{
		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first coupon date"); */
		    return(RET_GEN_ERR_INVARG);
		}
	    }
	}

	/* REF158 - Suppress verification : */
	/* LastPayDate is updated with LastCoupDate or EndDate or perpetual date */
	/* if ((IS_NULLFLD(instrPtr, A_Instr_PayFreq) == TRUE ||
	     IS_NULLFLD(instrPtr, A_Instr_PayFreqUnitEn) == TRUE) &&
	     IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == TRUE)
	{
		return(RET_GEN_ERR_INVARG);
	}
	*/

	if (IS_NULLFLD(instrPtr, A_Instr_PayFreq) == FALSE)
	{
        	SET_TINYINT(income, A_IncEvt_PayFreq,
		    GET_TINYINT(instrPtr, A_Instr_PayFreq));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_PayFreqUnitEn) == FALSE)
	{
        	SET_ENUM(income, A_IncEvt_PayFreqUnitEn,
		    GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_FirstExDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstExDate);

		/* First ex date can't be before begin date */
		if (tmpDate.date < GET_DATE(income, A_IncEvt_BeginDate))
		{
   		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first ex date"); */
		    return(RET_GEN_ERR_INVARG);
		}

	        SET_DATE(income, A_IncEvt_FirstExDate, tmpDate.date);
	}

	if (IS_NULLFLD(instrPtr, A_Instr_FirstCoupDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstCoupDate);

		/* First coupon date can't be before begin date */
		if (tmpDate.date < GET_DATE(income, A_IncEvt_BeginDate))
		{
   		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first coupon date"); */
		    return(RET_GEN_ERR_INVARG);
		}

		/* PMSTA-11739 - RAK - 110411 - suppress verification */
		/* First coupon date can't be before first ex date */
		/* if (IS_NULLFLD(income, A_IncEvt_FirstExDate) != TRUE)
			if (tmpDate.date < GET_DATE(income, A_IncEvt_FirstExDate))
			{
   		    	/ * MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first ex date"); * /
		    	return(RET_GEN_ERR_INVARG);
			}
		*/
		SET_DATETIME(income, A_IncEvt_FirstCoupDate,
		    GET_DATETIME(instrPtr, A_Instr_FirstCoupDate));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_LastCoupDate);

	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&	/* RAK BUG208 */
		GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
	    {
		tmpDate = GET_DATETIME(instrPtr, A_Instr_EndDate);
	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	    }
	    else
	    {
		/* Perpetual */
		tmpDate.date = DATE_Put(2050, 12, 31);
	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	    }
	}

	/* Verify last payment date validity */
	tmpDate.date = GET_DATE(income, A_IncEvt_LastPayDate);

	/* Last payment date can't be before first ex date */
	if (IS_NULLFLD(income, A_IncEvt_FirstExDate) != TRUE)
	    if (tmpDate.date < GET_DATE(income, A_IncEvt_FirstExDate))	/* BUG464 */
	{
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	}

	/* Last payment date can't be before begin date */
	if (tmpDate.date <= GET_DATE(income, A_IncEvt_BeginDate))
	{
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	}

	/* Last payment date can't be before first coupon date */
	if (IS_NULLFLD(income, A_IncEvt_FirstCoupDate) != TRUE)
	{
	    firstCoup = GET_DATETIME(income, A_IncEvt_FirstCoupDate);
	    if (tmpDate.date < firstCoup.date)				/* BUG464 */
	    {
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	    }
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_CopyInstrIncEvt()
*
*   Description          : Copy instrument income event from instrument
*
*   Arguments            : income pointer on income structure to fill
*                          instrPtr pointer on instrument structure
*
*   Return               : RET_SUCCEED if no error
*
*   Creation             : REF6004 - AKO - 011220 : Flow instrument request
*
*************************************************************************/
STATIC RET_CODE DBA_CopyInstrIncEvt2(   DBA_DYNFLD_STP      income,
                                        DBA_DYNFLD_STP      instrPtr,
                                        INTERCONDNAT_ENUM   incEvtNatEn)
{
	DATETIME_T tmpDate, firstCoup;

    SET_ENUM(income, A_IncEvt_NatEn, incEvtNatEn); /* REF6004 - AKO - 011220 */
	SET_NULL_CODE(income,   A_IncEvt_Cd);
	SET_NULL_DATE(income,   A_IncEvt_ValidDate);
	SET_NULL_ID(income,     A_IncEvt_ExclusiveId);
	SET_NULL_PRICE(income, A_IncEvt_Dividend);		/* DVP264 - 961122 - DED */

	SET_ID(income, A_IncEvt_InstrId, GET_ID(instrPtr, A_Instr_Id));
	SET_ID(income, A_IncEvt_CurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));

        SET_FLAG(income,      A_IncEvt_DivProjectionFlg,   FALSE);
	SET_DATE(income,      A_IncEvt_EndValidDate, MAGIC_END_DATE);
	SET_EXCHANGE(income,  A_IncEvt_FixedExchRate,  1.0);

	if (IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_DatedDate);
            	SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == FALSE)
	    {
		tmpDate = GET_DATETIME(instrPtr, A_Instr_BeginDate);
            	SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
	    }
	    else
	    {
	        if (IS_NULLFLD(instrPtr, A_Instr_FirstCoupDate) == FALSE)
		{
		    tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstCoupDate);
            	    SET_DATE(income, A_IncEvt_BeginDate, tmpDate.date);
		}
		else
		{
		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first coupon date"); */
		    return(RET_GEN_ERR_INVARG);
		}
	    }
	}

	/* REF158 - Suppress verification : */
	/* LastPayDate is updated with LastCoupDate or EndDate or perpetual date */
	/* if ((IS_NULLFLD(instrPtr, A_Instr_PayFreq) == TRUE ||
	     IS_NULLFLD(instrPtr, A_Instr_PayFreqUnitEn) == TRUE) &&
	     IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == TRUE)
	{
		return(RET_GEN_ERR_INVARG);
	}
	*/

	if (IS_NULLFLD(instrPtr, A_Instr_PayFreq) == FALSE)
	{
        	SET_TINYINT(income, A_IncEvt_PayFreq,
		    GET_TINYINT(instrPtr, A_Instr_PayFreq));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_PayFreqUnitEn) == FALSE)
	{
        	SET_ENUM(income, A_IncEvt_PayFreqUnitEn,
		    GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_FirstExDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstExDate);

		/* First ex date can't be before begin date */
		if (tmpDate.date < GET_DATE(income, A_IncEvt_BeginDate))
		{
   		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first ex date"); */
		    return(RET_GEN_ERR_INVARG);
		}

	        SET_DATE(income, A_IncEvt_FirstExDate, tmpDate.date);
	}

	if (IS_NULLFLD(instrPtr, A_Instr_FirstCoupDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_FirstCoupDate);

		/* First coupon date can't be before begin date */
		if (tmpDate.date < GET_DATE(income, A_IncEvt_BeginDate))
		{
   		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first coupon date"); */
		    return(RET_GEN_ERR_INVARG);
		}

		/* PMSTA-11739 - RAK - 110411 - suppress verification */
		/* First coupon date can't be before first ex date */
		/* if (IS_NULLFLD(income, A_IncEvt_FirstExDate) != TRUE)
		   if (tmpDate.date < GET_DATE(income, A_IncEvt_FirstExDate))
		   {
   		    	/ * MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			         "DBA_CopyInstrIncEvt", "first ex date"); * /
		    	return(RET_GEN_ERR_INVARG);
		   }
	   */
	    SET_DATETIME(income, A_IncEvt_FirstCoupDate,
		    GET_DATETIME(instrPtr, A_Instr_FirstCoupDate));
	}

	if (IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == FALSE)
	{
		tmpDate = GET_DATETIME(instrPtr, A_Instr_LastCoupDate);

	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&	/* RAK BUG208 */
		GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
	    {
		tmpDate = GET_DATETIME(instrPtr, A_Instr_EndDate);
	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	    }
	    else
	    {
		/* Perpetual */
		tmpDate.date = DATE_Put(2050, 12, 31);
	    	SET_DATE(income, A_IncEvt_LastPayDate, tmpDate.date);
	    }
	}

	/* Verify last payment date validity */
	tmpDate.date = GET_DATE(income, A_IncEvt_LastPayDate);

	/* Last payment date can't be before first ex date */
	if (IS_NULLFLD(income, A_IncEvt_FirstExDate) != TRUE)
	    if (tmpDate.date < GET_DATE(income, A_IncEvt_FirstExDate))	/* BUG464 */
	{
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	}

	/* Last payment date can't be before begin date */
	if (tmpDate.date <= GET_DATE(income, A_IncEvt_BeginDate))
	{
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	}

	/* Last payment date can't be before first coupon date */
	if (IS_NULLFLD(income, A_IncEvt_FirstCoupDate) != TRUE)
	{
	    firstCoup = GET_DATETIME(income, A_IncEvt_FirstCoupDate);
	    if (tmpDate.date < firstCoup.date)				/* BUG464 */
	    {
   		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_CopyInstrIncEvt", "last payment date"); */
		return(RET_GEN_ERR_INVARG);
	    }
	}

    /* REF6004 - AKO - 020218 : add income nature */
    SET_ENUM(income, A_IncEvt_NatEn, incEvtNatEn);

	return(RET_SUCCEED);
}


/************************************************************************
*   Function             : DBA_GetIncEvt()
*
*   Description          : Get income event
*                          Read income code in instrument table :
*                           use instrument informations
*                           or call get on income event table
*
*   Arguments            : instrPtr    instrument pointer
*                          valDateTime validity date
*                          income      pointer on income event to fill
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_GetIncEvt(DBA_DYNFLD_STP instrPtr,
		       DATETIME_T     valDateTime,
		       DBA_DYNFLD_STP income)
{
	DBA_DYNFLD_STP ask=NULLDYNST;
	RET_CODE       ret;

	if ((INCCD_ENUM) GET_ENUM(instrPtr, A_Instr_IncomeCdEn) == IncCd_Instr)
	{
	    ret = DBA_CopyInstrIncEvt(income, instrPtr);
	}
	else
	{
	    if ((ask = ALLOC_DYNST(S_IncEvt)) == NULLDYNST)
    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	    {
		SET_ID(ask, S_IncEvt_InstrId,
                    GET_ID(instrPtr, A_Instr_ParentInstrId));
	    }
	    else
	    {
                SET_ID(ask, S_IncEvt_InstrId,
		    GET_ID(instrPtr, A_Instr_Id));
	    }

            SET_DATE(ask, S_IncEvt_ValidDate, valDateTime.date);

	    ret = DBA_Get2(IncEvt, UNUSED, S_IncEvt, ask, A_IncEvt, &income,
		           UNUSED, UNUSED, UNUSED);

	    if (ret != RET_SUCCEED)
	    {
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_GetIncEvt",
		    GET_CODE(instrPtr, A_Instr_Cd), "income event");
	    }
	    else
	    	ret = RET_SUCCEED;

	    FREE_DYNST(ask, S_IncEvt);
	}

	return(ret);
}

/************************************************************************
*
*  Function	: DBA_GetInstrYieldCurve()
*
*  Description	: Get instrument yield curve.
*
*  Arguments	: instrPtr      instrument struct pointer
*                 yieldCurvePtr pointer on yield curve struct pointer
*
*  Return	: RET_SUCCEED or error code
*
*  Creation	: REF1485 - RAK - 980327
*  Modif.	: REF3913 - RAK - 990825
*  Modif.	: REF5669 - DDV - 000216 - function can be call without InstrPtr but a currency id must be provided
*
*************************************************************************/
RET_CODE DBA_GetInstrYieldCurve(DBA_DYNFLD_STP instrPtr,
				DBA_DYNFLD_STP *yieldInstrPtr,
				FLAG_T	       *freeFlg,
				DBA_HIER_HEAD_STP hierHead,
                ID_T       currId)
{
	DBA_DYNFLD_STP	getArg=NULLDYNST;
	RET_CODE 	retCd=RET_SUCCEED;

	/* ------------------------------------------------------------------- */
	/* Which curve :                                                       */
	/* At the instrument level, a curve may be specified. If this is NULL, */
	/* a default curve is used. The default curve is a curve in the        */
	/* required ref currency and where the default flag is set to TRUE     */
	/* ------------------------------------------------------------------- */
	if (instrPtr == NULLDYNST || IS_NULLFLD(instrPtr, A_Instr_YieldCurveInstrId) == TRUE)
	{
        if (((*yieldInstrPtr) = ALLOC_DYNST(A_Instr)) == NULLDYNST)
	    { MSG_RETURN(RET_MEM_ERR_ALLOC); }

        /* Call get_exd_instrument_by_rcurr */
		if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
		{
			FREE_DYNST((*yieldInstrPtr), A_Instr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

        /* REF5669 - DDV - 010216 - Get currency from new parameter if instrument pointer is NULL */
        if (instrPtr != NULLDYNST)
        {
		    SET_ID(getArg,   Get_Arg_RefCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
        }
        else
        {
            if (currId >= 0)
		        SET_ID(getArg,   Get_Arg_RefCurrId, currId);
        }

		SET_ENUM(getArg, Get_Arg_NatEn,     (ENUM_T) InstrNat_YieldCurve);
		SET_FLAG(getArg, Get_Arg_Flag,      TRUE);

	    if ((retCd = DBA_Get2(Instr, DBA_ROLE_CURRENCY_BY_DFLT,
				              Get_Arg, getArg, A_Instr, yieldInstrPtr,
			                  UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
		{
			FREE_DYNST(getArg, Get_Arg);
			FREE_DYNST((*yieldInstrPtr), A_Instr);
			return(retCd);
		}
		FREE_DYNST(getArg, Get_Arg);
		*freeFlg = TRUE;
	}
	else
	{
		/* REF3913 - RAK - 990825
		And then insert yield curve in hierarchy ... (TRUE in 3th arguments)
		if ((getArg = ALLOC_DYNST(S_Instr)) == NULLDYNST)
		{
			FREE_DYNST((*yieldInstrPtr), A_Instr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

		SET_ID(getArg, S_Instr_Id, GET_ID(instrPtr, A_Instr_YieldCurveInstrId));

		if ((retCd = DBA_Get2(Instr, UNUSED, S_Instr, getArg, A_Instr, yieldInstrPtr,
		                      UNUSED, UNUSED, UNUSED)) != RET_SUCCEED) */
		if ((retCd = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_YieldCurveInstrId), TRUE, 
					                  freeFlg, yieldInstrPtr, hierHead, 
                                      UNUSED, UNUSED)) != RET_SUCCEED)
	    {
			return(retCd);
		}
	}

	return(retCd);
}


/************************************************************************
*   Function             : DBA_SelectIncEvtTable()
*
*   Description          : Select valid income event(s) between two dates
*                          including validity on income event table
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          incTab       pointer on income table
*                                       which will be allocated and updated
*                          incNbr       pointer on income number which will be
*                                       updated
*
*  Created               :  PMSTA-47762 - JBC - 220131
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
STATIC RET_CODE DBA_SelectIncEvtTable(DBA_DYNFLD_STP instrPtr,
			  DATETIME_T     fromDateTime,
			  DATETIME_T     tillDateTime,
			  DATETIME_T     valDateTime,
			  DBA_DYNFLD_STP **incTab,
			  int            *incNbr)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;
    ID_T instrId = GET_ID(instrPtr, A_Instr_Id) < 0 ? GET_ID(instrPtr, A_Instr_ParentInstrId) : GET_ID(instrPtr, A_Instr_Id);
    DBA_DYNFLD_STP evtArg = mp.allocDynst(FILEINFO,Evt_Arg);
    SET_ID(evtArg, Evt_Arg_InstrId, instrId);
    SET_DATE(evtArg, Evt_Arg_EndDate,   tillDateTime.date);
    SET_DATE(evtArg, Evt_Arg_ValidDate, valDateTime.date);

	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;

	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

	if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock)
	{
		SET_DATE(evtArg, Evt_Arg_BegDate, valDateTime.date);
	}
	else
	{
		SET_DATE(evtArg, Evt_Arg_BegDate, fromDateTime.date);
	}

	ret = DBA_Select2(IncEvt, UNUSED, Evt_Arg, evtArg,A_IncEvt, incTab, UNUSED, UNUSED, incNbr, UNUSED, UNUSED);

	if (ret != RET_SUCCEED)
	{
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectIncEvt",GET_CODE(instrPtr, A_Instr_Cd), "income event");
	}
    return ret;
}

/************************************************************************
*   Function             : DBA_SelectIncEvt()
*
*   Description          : Select valid income event(s) between two dates
*                          Read income code in instrument table :
*                           use instrument informations
*                           or call select on income event table
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          incTab       pointer on income table
*                                       which will be allocated and updated
*                          incNbr       pointer on income number which will be
*                                       updated
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_SelectIncEvt(DBA_DYNFLD_STP instrPtr,
			  DATETIME_T     fromDateTime,
			  DATETIME_T     tillDateTime,
			  DATETIME_T     valDateTime,
			  DBA_DYNFLD_STP **incTab,
			  int            *incNbr)
{
	RET_CODE       ret;

	*incNbr = 0;

	if ((INCCD_ENUM) GET_ENUM(instrPtr, A_Instr_IncomeCdEn) == IncCd_Instr)
	{
	    /* BUG197 - XDI - 961107 */
	    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock ||
	        GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare)
        {
		    return(RET_SUCCEED);
        }
	    *incNbr = 1;
	    if ((*incTab = (DBA_DYNFLD_STP*) CALLOC(*incNbr,
			    sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
        {
    		MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

	    if (((*incTab)[0] = ALLOC_DYNST(A_IncEvt)) == NULLDYNST)
	    {
		    FREE(*incTab);
    		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    ret = DBA_CopyInstrIncEvt((*incTab)[0], instrPtr);

	    if (ret != RET_SUCCEED)
	    {
		    FREE_DYNST((*incTab)[0],A_IncEvt);
            FREE(*incTab);
		    return(RET_GEN_ERR_INVARG);
	    }        
	}
	else
	{   /* get from income_event PMSTA-47762 - JBC - 220131 */
        ret = DBA_SelectIncEvtTable(instrPtr,fromDateTime,tillDateTime,valDateTime,incTab,incNbr);
	}

	return(ret);
}

/************************************************************************
*   Function             : DBA_SelectIncEvtByNatEn()
*
*   Description          : Select valid income event(s) between two dates
*                          Read income code in instrument table :
*                           use instrument informations
*                           or call select on income event table
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          incTab       pointer on income table
*                                       which will be allocated and updated
*                          incNbr       pointer on income number which will be
*                                       updated
*                          incEvtNatEn  nature of the income
*
*   Return               : RET_SUCCEED if no error
*   Created              : REF6004 - AKO - 011220 : Flow instrument project
*
*************************************************************************/
RET_CODE DBA_SelectIncEvtByNatEn(   DBA_DYNFLD_STP      instrPtr,
                                    DATETIME_T          fromDateTime,
                                    DATETIME_T          tillDateTime,
                                    DATETIME_T          valDateTime,
                                    DBA_DYNFLD_STP      **incTab,
                                    int                 *incNbr,
                                    INTERCONDNAT_ENUM   incEvtNatEn)
{
	RET_CODE       ret;

	*incNbr = 0;
	if ((INCCD_ENUM) GET_ENUM(instrPtr, A_Instr_IncomeCdEn) == IncCd_Instr)
	{
	    /* BUG197 - XDI - 961107 */
	    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock ||
	        GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare)
		return(RET_SUCCEED);

	    *incNbr = 1;
	    if ((*incTab = (DBA_DYNFLD_STP*) CALLOC(*incNbr,
			    sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (((*incTab)[0] = ALLOC_DYNST(A_IncEvt)) == NULLDYNST)
	    {
		FREE(*incTab);
    		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    ret = DBA_CopyInstrIncEvt2((*incTab)[0], instrPtr, incEvtNatEn); /* REF6004 - AO - 011220 */

	    if (ret != RET_SUCCEED)
	    {
		    DBA_FreeDynStTab(*incTab, *incNbr, A_IncEvt);
		    return(RET_GEN_ERR_INVARG);
	    }

	}
	else
	{   /* get from income_event PMSTA-47762 - JBC - 220131 */
        ret = DBA_SelectIncEvtTable(instrPtr,fromDateTime,tillDateTime,valDateTime,incTab,incNbr);
	}

	return(ret);
}

/************************************************************************
*   Function             : DBA_GetTermEvt()
*
*   Description          : Get valid term event
*                          Read term code in instrument table :
*                           use instrument informations
*                           or call get on term event table
*
*   Arguments            : instrPtr   pointer on instrument dynamic struct
*                          validDate  valid date for event
*                          termEvtPtr pointer on term event dynamic struct
*
*   Return               : RET_SUCCEED if no error
*
*   Modif		 : BUG230 - RAK - 961216
*
*************************************************************************/
RET_CODE DBA_GetTermEvt(DBA_DYNFLD_STP instrPtr,
			DATE_T         validDate,
			DBA_DYNFLD_STP termEvtPtr)
{
	RET_CODE       ret;
	char           getOk=FALSE;
	DBA_DYNFLD_STP getData=NULLDYNST;
	DATETIME_T     termValidDate;

	if ((TERMCD_ENUM) GET_ENUM(instrPtr, A_Instr_TermCdEn) == TermCd_None)
		getOk = FALSE;
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_TermValDate) == TRUE)
		getOk = TRUE;
	    else
	    {
			termValidDate = GET_DATETIME(instrPtr, A_Instr_TermValDate);
	    	if (validDate < termValidDate.date)
				getOk = TRUE;
	    }
	}

	if (getOk == TRUE)
	{
		/* PMSTA-34140 - 190131 - RAK - Use MemoryPool and DbiConnectionHelper */
		MemoryPool mp;
		DbiConnectionHelper dbiConnHelper;

		getData = mp.allocDynst(FILEINFO, Evt_Arg);

		if (GET_ID(instrPtr, A_Instr_Id) < 0)
		{ SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));}
		else
		{ SET_ID(getData, Evt_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));}

		SET_DATE(getData, Evt_Arg_ValidDate, validDate);

		if ((ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &termEvtPtr)) != RET_SUCCEED)
			ret = RET_DBA_ERR_NODATA;
	}
	else
	{
	    if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId) == TRUE)
	    {
			ret = RET_DBA_ERR_INVDATA;
   			MSG_SendMesg(ret, 1, FILEINFO, "DBA_GetTermEvt",
					 GET_CODE(instrPtr, A_Instr_Cd), "underlying");
	    }
	    else
	    {
		SET_NULL_DATE(termEvtPtr,     A_TermEvt_ValidDate);
		SET_NULL_CODE(termEvtPtr,     A_TermEvt_Cd);
		SET_NULL_ID(termEvtPtr,       A_TermEvt_ExclusiveId);
		SET_NULL_ID(termEvtPtr,       A_TermEvt_CheapestInstrId);
		SET_NULL_EXCHANGE(termEvtPtr, A_TermEvt_FixedExchRate);
		SET_NULL_NUMBER(termEvtPtr,   A_TermEvt_CtdConvFact);
		SET_NULL_NUMBER(termEvtPtr,   A_TermEvt_CtdConvRatio);

		SET_TINYINT(termEvtPtr, A_TermEvt_SettleDays,    0);
		SET_DATE(termEvtPtr,    A_TermEvt_EndValidDate, MAGIC_END_DATE);

		SET_ID(termEvtPtr, A_TermEvt_InstrId,
		    GET_ID(instrPtr, A_Instr_Id));

		SET_ID(termEvtPtr, A_TermEvt_UnderlyInstrId,
		    GET_ID(instrPtr, A_Instr_UnderlyInstrId));

		if (IS_NULLFLD(instrPtr, A_Instr_ExerCurrId) == TRUE)
		{
		    SET_ID(termEvtPtr,  A_TermEvt_CurrId,
		        GET_ID(instrPtr, A_Instr_RefCurrId));
		}
		else
		{
		    SET_ID(termEvtPtr,  A_TermEvt_CurrId,
		        GET_ID(instrPtr, A_Instr_ExerCurrId));
		}

		SET_DATE(termEvtPtr, A_TermEvt_BeginDate,
		    GET_DATE(instrPtr, A_Instr_BeginDate));
		SET_DATE(termEvtPtr, A_TermEvt_EndDate,
		    GET_DATE(instrPtr, A_Instr_EndDate));
		SET_FLAG(termEvtPtr,  A_TermEvt_PhysicalFlg,
		    GET_FLAG(instrPtr, A_Instr_PhysicalFlg));
		/* BEGIN BUG230 */
		SET_PRICE(termEvtPtr, A_TermEvt_ExerQuote,
		    GET_PRICE(instrPtr, A_Instr_RedempQuote));
		SET_PRICE(termEvtPtr, A_TermEvt_ExerPrice,
		    GET_PRICE(instrPtr, A_Instr_RedempPrice));
		/* END BUG230 */
		SET_ENUM(termEvtPtr, A_TermEvt_OptionClassEn,
		    GET_ENUM(instrPtr, A_Instr_OptionClassEn));
		SET_ENUM(termEvtPtr, A_TermEvt_OptStyleEn,
		    GET_ENUM(instrPtr, A_Instr_OptStyleEn));
		SET_TINYINT(termEvtPtr, A_TermEvt_Freq,
		    GET_TINYINT(instrPtr, A_Instr_PayFreq));
		SET_ENUM(termEvtPtr, A_TermEvt_FreqUnitEn,
		    GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn));
		SET_NUMBER(termEvtPtr,  A_TermEvt_UnderlyQty,
		    GET_NUMBER(instrPtr, A_Instr_UnderlyQty));
		SET_ENUM(termEvtPtr, A_TermEvt_PremiumPmtEn,	/* REF1055 - AKO - 991104 */
		    GET_ENUM(instrPtr, A_Instr_PremiumPmtEn));

		ret = RET_SUCCEED;
	    }
	}

	return(ret);
}

/************************************************************************
*   Function             : DBA_GetFinalIOREvt()
*
*   Description          : Get final redemption event
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          iorEvt       pointer on issue or redemption structure
*                                       which will be updated
*
*   Return               : RET_SUCCEED if no error
*
*   Creation		 : BUG147 - RAK - 960930
*
*   Warning		 : to optimise or create a new get
*
*************************************************************************/
RET_CODE DBA_GetFinalIOREvt(DBA_DYNFLD_STP instrPtr,
			    DATETIME_T     fromDateTime,
			    DATETIME_T     tillDateTime,
			    DATETIME_T     valDateTime,
			    DBA_DYNFLD_STP iorEvt)
{
	RET_CODE 	ret;
	int      	i, iorNbr, finalEvt;
	DATE_T		perpetual;
	DBA_DYNFLD_STP  *iorTab=(DBA_DYNFLD_STP*)NULL;

	/* Select all issue or redemption event */
	if ((ret = DBA_SelectIOREvt(instrPtr, fromDateTime, tillDateTime, valDateTime,
				    &iorTab, &iorNbr)) == RET_SUCCEED)
	{
	    /* Search final redemption event */
	    for (i=0, (finalEvt)=-1; i<iorNbr && (finalEvt)==-1; i++)
	    {
		if (GET_ENUM(iorTab[i], A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
		{
			finalEvt = i; /* remember position in array */
		}
	    }

	    if (finalEvt != -1)
	    {
		if (IS_NULLFLD(iorTab[finalEvt], A_IssueEvt_BegDate) == TRUE)
	        {
		    perpetual = DATE_Put(2050, 12, 31);
		    SET_DATE(iorTab[finalEvt], A_IssueEvt_BegDate, perpetual);
	        }

	        if (IS_NULLFLD(iorTab[finalEvt], A_IssueEvt_Price) == TRUE)
	        {
		    SET_PRICE(iorTab[finalEvt], A_IssueEvt_Price, 1.0);
	        }

		COPY_DYNST(iorEvt, iorTab[finalEvt], A_IssueEvt);

		ret = RET_SUCCEED;
	    }
	    else
	    {
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectIOREvt",
		    GET_CODE(instrPtr, A_Instr_Cd), "final redemption event");
	    }
	}

        DBA_FreeDynStTab(iorTab, iorNbr, A_IssueEvt);

	return(ret);
}

/************************************************************************
*   Function             : DBA_SelectIOREvt()
*
*   Description          : Select valid issue or redemption event(s) between
*                          two dates.
*                          Read issue code and redemption code in instrument
*                          table :
*	                   IssueCd_None : No issue event
* 		           IssueCd_Evt  : Issue event exist
*
*	                   RedempCd_Instr      : Redemption in instrument
*                          RedempCd_FinalInstr : Final redemption in instr,
*                                                others in event
*		           RedempCd_Evt        : All redemption in event
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          iorTab       pointer on issue or redemption table
*                                       which will be allocated and updated
*                          iorNbr       pointer on issue or redemption number
*                                       which will be updated
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_SelectIOREvt(DBA_DYNFLD_STP instrPtr,
			  DATETIME_T     fromDateTime,
			  DATETIME_T     tillDateTime,
			  DATETIME_T     valDateTime,
			  DBA_DYNFLD_STP **iorTab,
			  int            *iorNbr)
{
	RET_CODE      ret;
	int           i;
	char          sinking, instrEvt;
	ISSUECD_ENUM  issueCd;
	REDEMPCD_ENUM redempCd;

	*iorNbr = 0;

	redempCd = (REDEMPCD_ENUM) GET_ENUM(instrPtr, A_Instr_RedempCdEn);
	issueCd  = (ISSUECD_ENUM) GET_ENUM(instrPtr, A_Instr_IssueCdEn);
	ret      = RET_SUCCEED;

	if (issueCd == IssueCd_Evt ||
	    redempCd == RedempCd_FinalInstr || redempCd == RedempCd_Evt)
	{
	    DBA_DYNFLD_STP    ask=NULLDYNST;

	    if ((ask = ALLOC_DYNST(Evt_Arg)) == NULLDYNST)
    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	    {
		SET_ID(ask, Evt_Arg_InstrId,
                    GET_ID(instrPtr, A_Instr_ParentInstrId));
	    }
	    else
	    {
                SET_ID(ask, Evt_Arg_InstrId,
		    GET_ID(instrPtr, A_Instr_Id));
	    }

            SET_DATE(ask, Evt_Arg_BegDate,   fromDateTime.date);
            SET_DATE(ask, Evt_Arg_ValidDate, valDateTime.date);

	    ret = DBA_Select2(IssueEvt, UNUSED, Evt_Arg, ask,
		             A_IssueEvt, iorTab, UNUSED, UNUSED,
		             iorNbr, UNUSED, UNUSED);

	    if (ret != RET_SUCCEED)
	    {
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectIOREvt",
		    GET_CODE(instrPtr,A_Instr_Cd), "issue or redemption event");
	    }
	    else
	    	ret = RET_SUCCEED;

	    FREE_DYNST(ask, Evt_Arg);
	}

	/*** SINKING FUND REDEMPTION ***/
	sinking=FALSE;
	for (i=0; i<(*iorNbr) && sinking==FALSE; i++)
	{
	    if (GET_ENUM((*iorTab)[i], A_IssueEvt_NatEn) == IssRedmNat_Amort)
		sinking = TRUE;
	}

	/* All sinking information are in event table */
	if (sinking == TRUE)
	{
		instrEvt = FALSE;
	}
	else
	{
		if (redempCd == RedempCd_FinalInstr ||
		    redempCd == RedempCd_Instr)
			instrEvt = TRUE;
		else
			instrEvt = FALSE;
	}

	if (instrEvt == TRUE)
	{
		DBA_DYNFLD_STP final=NULLDYNST;
		int            crt;

		crt    = *iorNbr;
		(*iorNbr) += 1;

		if (((*iorTab) = (DBA_DYNFLD_STP *) REALLOC((*iorTab),
			       (*iorNbr) * sizeof(DBA_DYNFLD_STP)))
				== (DBA_DYNFLD_STP*)NULL)
		{
			DBA_FreeDynStTab(*iorTab, (*iorNbr)-1, A_IssueEvt);
    			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

	    	if (((*iorTab)[crt] = ALLOC_DYNST(A_IssueEvt)) == NULLDYNST)
	    	{
			DBA_FreeDynStTab(*iorTab, *iorNbr, A_IssueEvt);
    			MSG_RETURN(RET_MEM_ERR_ALLOC);
	    	}

		final = (*iorTab)[crt];

		/* PMSTA-10889 - RAK - 110127 - Create sub-function */
		DBA_SetInstrRedmEvent(instrPtr, final);

		ret = RET_SUCCEED;
	}

	return(ret);
}

void DBA_SetInstrRedmEvent(DBA_DYNFLD_STP instrPtr, DBA_DYNFLD_STP final)
{
	if (instrPtr != NULL && final != NULL)
	{
		SET_NULL_CODE(final,     A_IssueEvt_Cd);
		SET_NULL_ID(final,       A_IssueEvt_ExclId);
		SET_NULL_DATE(final,     A_IssueEvt_AnnounceDate);
		SET_NULL_DATE(final,     A_IssueEvt_ValidDate);
		SET_NULL_TINYINT(final,  A_IssueEvt_Freq);
		SET_NULL_ENUM(final,     A_IssueEvt_FreqUnitEn);
		SET_NULL_EXCHANGE(final, A_IssueEvt_FxdExchRate);

		SET_ENUM(final,    A_IssueEvt_NatEn, IssRedmNat_FinalRedm);
		SET_DATE(final,    A_IssueEvt_EndValidDate, MAGIC_END_DATE);
		SET_PERCENT(final, A_IssueEvt_ProporPrct, 100.0);
		SET_TINYINT(final, A_IssueEvt_SettlDays, 0);

		SET_ID(final, A_IssueEvt_InstrId,
		    GET_ID(instrPtr, A_Instr_Id));
		SET_ID(final, A_IssueEvt_CurrId,
		    GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_DATE(final, A_IssueEvt_BegDate,
		    GET_DATE(instrPtr, A_Instr_EndDate));
		SET_DATE(final, A_IssueEvt_EndDate,
		    GET_DATE(instrPtr, A_Instr_EndDate));

		if (IS_NULLFLD(instrPtr, A_Instr_RedempPrice) == TRUE)
		{
		     SET_NULL_PRICE(final, A_IssueEvt_Price);
		}
		else
		{
		     SET_PRICE(final, A_IssueEvt_Price,
		        GET_PRICE(instrPtr, A_Instr_RedempPrice));
		}

		if (IS_NULLFLD(instrPtr, A_Instr_RedempQuote) == TRUE)
		{
		     SET_NULL_PRICE(final, A_IssueEvt_Quote);
		}
		else
		{
		     SET_PRICE(final, A_IssueEvt_Quote,
		         GET_PRICE(instrPtr, A_Instr_RedempQuote));
		}

		COPY_DYNFLD(final, A_IssueEvt, A_IssueEvt_EffectiveDate, /* BUG302 - XDI - 970317 */
		            instrPtr, A_Instr, A_Instr_EffectiveDate);
	}
}


/************************************************************************
**
**  Function    :   DBA_GetInstrByIdCd
**
**  Description :   Get an instrument depending on identifier received or
**                  code
**
**  Arguments   :   argPtr   structure which contains id or code
**                  fldId    identifier position in structure
**                  fldCd    code position in structure
**                  instrPtr pointer on dynamic structure to fill
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetInstrByIdCd(DBA_DYNFLD_STP       argPtr,
			    int                  fldId,
			    int                  fldCd,
			    DBA_DYNFLD_STP       *instrPtr,
                            FLAG_T               *allocFlg,
                            PTR                  hierHead,
                            int                  getOptions,
                            int                  *allocConn)
{
	RET_CODE ret;
	DBA_DYNFLD_STP getInstr=NULLDYNST;

	if (IS_NULLFLD(argPtr, fldId) != TRUE)
	{
                /* REF3913 - 990819 - DDV */
                ret = DBA_GetInstrById(GET_ID(argPtr, fldId), FALSE, allocFlg,
                                       instrPtr, NULL, getOptions,
                                       allocConn);
	}
	else if (IS_NULLFLD(argPtr, fldCd) != TRUE)
	{
            if ((getInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
	        MSG_RETURN(RET_MEM_ERR_ALLOC);

            if (((*instrPtr) = ALLOC_DYNST(A_Instr)) == NULLDYNST)
            {
                FREE_DYNST(getInstr, S_Instr);
	        MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            *allocFlg = TRUE;
	    SET_CODE(getInstr, S_Instr_Cd, GET_CODE(argPtr, fldCd));

            ret = DBA_Get2(Instr, UNUSED, S_Instr, getInstr, A_Instr, instrPtr,
                           UNUSED, UNUSED, UNUSED);

            FREE_DYNST(getInstr, S_Instr);

	    if (ret != RET_SUCCEED)
            {
                *allocFlg = FALSE;
                FREE_DYNST((*instrPtr), A_Instr);
            }
	}
	else
	{
            *allocFlg = FALSE;
   	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_GetInstrByIdCd", "identifiers");
	    return(RET_GEN_ERR_INVARG);
	}

	if (ret != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
	    	MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, entSqlName);
   		return(RET_DBA_ERR_NODATA);
	}
	else
		return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_SelectInstrCompo()
**
**  Description :   Select instrument composition
**
**  Arguments   :   instrId  instrument identifier
**                  begDate  begin date
**                  compoTab pointer on component array
**                  compoNbr pointer on number of components
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_SelectInstrCompo(ID_T           instrId,
			      DATETIME_T     begDate,
			      DBA_DYNFLD_STP **compoTab,
			      int            *compoNbr)
{
	RET_CODE       ret;
	MemoryPool mp;
	DBA_DYNFLD_STP askCompo = mp.allocDynst(FILEINFO, S_InstrCompo); /* PMSTA_34140 - RAK - 190108 - Add sort and improve alloc */

	*compoNbr = 0;

	/*** COMPOSITE INSTRUMENT ***/
	SET_ID(askCompo,   S_InstrCompo_ParentInstrId, instrId);
	SET_DATE(askCompo, S_InstrCompo_BeginDate,    begDate.date);

	ret = DBA_Select2(InstrCompo, UNUSED, S_InstrCompo, askCompo,
		              A_InstrCompo, compoTab, UNUSED, UNUSED,
			          compoNbr, UNUSED, UNUSED);

	if (ret != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(InstrCompo));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, instrId);
		ret = RET_DBA_ERR_NODATA;
	}
	else

		ret = RET_SUCCEED;

	return(ret);
}



/************************************************************************
**
**  Function    :   DBA_InstrPriceByFreq()
**
**  Description :   Search prices at determined frequency
**
**  Arguments   :   date       end date of the series
**                  freq       frequency at which the data is extracted
**                  freqUnitEn frequency at which the data is extracted
**                  reading    how many occurrences are to be selected
**                  instrId    instrument identifier
**                  instrPtr   instrument pointer (use for generic)
**                  currId     currency identifier
**                  method     missing data resolution method - REF7061 - TEB - 021223
**                  priceTab   pointer on prices array to update
**                  priceNbr   pointer on prices number to update
**
**
**  Return      :   RET_SUCCEED           valuation rule ValRule_Quote and
**                                        prices found
**		    RET_DBA_ERR_NODATA    valuation rule ValRule_Quote and
**                                        prices not found
**	            RET_GEN_INFO_NOACTION valuation rule ValRule_Quote1
**	            RET_GEN_ERR_NOACTION  valuation rule not treated (tempo)
**                  or error code
**
** DVP005 : New function (96/03/13)
**
** Modif       : DVP142 - RAK - 960612
** Modif       : DVP344 - XDI - 970227
** Modif       : REF547 - RAK - 971021
** Modif       : REF2537 - RAK - 980710
** Modif	   : REF2544 - SSO - 980717
** Modif       : REF5714 - AKO - 010223 - setting retCod and new error messages
** Modif       : REF7061 - TEB - 021223
** Modif       : PMSTA - 32764 - SILPA - 181010 - usePtfInstrPrice flag to differentiate Signature Portfolio instruments
**
*************************************************************************/
RET_CODE DBA_InstrPriceByFreq(DATETIME_T              date,
                              TINYINT_T               freq,
                              FREQUNIT_ENUM           freqUnit,
                              int                     reading,
                              ID_T                    instrId,
                              DBA_DYNFLD_STP          inputInstrPtr,
                              ID_T                    currId,
                              ID_T                    valRuleId,
                              DBA_DYNFLD_STP          valRulePtr,
                              DBA_DYNFLD_STP          extPos,
                              MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 021223 */
                              DBA_DYNFLD_STP          **priceTab,
                              int                     *priceNbr,
                              DBA_HIER_HEAD_STP       hierHead,
                              ID_T                    ptfId)   /* PMSTA - 32764 - SILPA - 181010 */
{
	DBA_DYNFLD_STP    ask=NULLDYNST, instrPtr=NULLDYNST;
    DBA_DYNFLD_STP    instrPricePtr=NULLDYNST, *instrPriceTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP    tmpPtr=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	RET_CODE          ret=RET_SUCCEED;  /*REF5714 - AKO - 010223 : init */
	int               chronoNbr, i, j, k, x, correct, instrPriceNbr, validity, extValidity;
    FLAG_T            allocOk, usePtfInstrPrice=FALSE;  /* PMSTA - 32764 - SILPA - 181010 */
	EXCHANGE_T        exch;
	DATETIME_T        begDate, endDate, loadEndDate;
	DATETIME_T        extendedBegDate, extendedEndDate;
	PRICE_T           price;
	NUMBER_T	  correctFact;
	int               nbPrice;               /* REF7061 - TEB - 021223 */
	/*
	TINYINT_T         sqlFreq;
	DATE_SQLFREQ_ENUM sqlFreqUnit;
	*/
	DATE_UNIT_ENUM    dateUnit=Year;
	DBA_HIER_HEAD_STP tmpHier;
    PRICE_T           sumPrices, prevValue, nextValue; /* REF7061 - TEB - 021224 */
    FLAG_T            extendedLoadDoneFlg = FALSE, loadExtendedFlg=FALSE;
    MemoryPool        mp;

    sumPrices = 0; /* REF7061 - TEB - 021224 */

	*priceNbr = 0;
	extendedBegDate.date = 0;
	extendedBegDate.time = 0;
	extendedEndDate.date = 0;
	extendedEndDate.time = 0;

	/*if ((ret = DATE_SqlFreq(freqUnit, freq, &sqlFreqUnit, &sqlFreq)) != RET_SUCCEED)
		return(ret);*/

    /* Get position instrument */
	if (inputInstrPtr == NULLDYNST)
    {
		if (DBA_GetInstrById(instrId, FALSE, &allocOk, 
                                 &instrPtr, hierHead, 
                                 UNUSED, UNUSED) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
				     entSqlName, instrId);
	   		return(RET_DBA_ERR_NODATA);  /* ?? */
        }
    }
    else
    {
		instrPtr = inputInstrPtr;
        allocOk = FALSE;
    }

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
		instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
		instrId = GET_ID(instrPtr, A_Instr_Id);

    /* PMSTA - 32764 - SILPA - 181010 */
    if ((ptfId != ZERO_ID) &&
        GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare &&
        SubNat_ExternalProduct == static_cast<SUBNAT_ENUM> GET_ENUM(instrPtr, A_Instr_SubNatEn) &&
        PriceCalcRule_PortfolioSpecificPrice == static_cast<PRICECALCRULE_ENUM>GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
    {
        usePtfInstrPrice = TRUE;
    }

	switch((VALRULE_ENUM) GET_ENUM(instrPtr, A_Instr_ValRuleEn))
	{
	case ValRule_Quote :
	    if ((ask = mp.allocDynst(FILEINFO, Sel_Arg)) == NULLDYNST)
	    {
		    if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    switch(freqUnit)
	    {
                case FreqUnit_Day:
                    dateUnit = Day;
                    break;

                case FreqUnit_BusDay:
                    dateUnit = Day;
                    break;

                case FreqUnit_Week:
                    dateUnit = Week;
                    break;

                case FreqUnit_Month:
                    dateUnit = Month;
                    break;

                case FreqUnit_Quarter:
                    dateUnit = Quarter;
                    break;

                case FreqUnit_Semester:
                    dateUnit = Semester;
                    break;

                case FreqUnit_Year:
                    dateUnit = Year;
                    break;
        }

	    begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    begDate.time = 0;			/* BUG452 - 970806 - XMT */

	    GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
	    GEN_GetApplInfo(ApplExtPricePeriodValidity, &extValidity);

        /* PMSTA-30132 - DDV - 180319 - Compute extended period dates */
        if (extValidity > validity)
        {
            extendedBegDate.date = DATE_Move(begDate.date, (-1) * extValidity, Day);
	        extendedBegDate.time = 0;
        }

	    GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
        begDate.date = DATE_Move(begDate.date, (-1) * validity, Day);

		/* PMSTA-30132 - DDV - 180319 - Compute extended period dates */
        if (extValidity > validity)
        {
            extendedEndDate.date = DATE_Move(begDate.date, (-1) , Day);
    	    extendedEndDate.time = 0;
        }
        else
        {
            extendedLoadDoneFlg = TRUE;
        }

        loadEndDate.date = date.date;
	    loadEndDate.time = 0;

        if (usePtfInstrPrice == FALSE)
        {
            SET_ID(ask, Sel_Arg_Id1, instrId);
            SET_DATETIME(ask, Sel_Arg_FromDate, begDate);
            SET_DATETIME(ask, Sel_Arg_TillDate, date);
            SET_FLAG(ask, Sel_Arg_DistinctFlg, FALSE);

            /* sel_all_instr_price_by_dt_freq */	/* Select valid prices for the period */
            ret = DBA_Select2(InstrPrice, UNUSED, Sel_Arg, ask,
                A_InstrPrice, &instrPriceTab, UNUSED, UNUSED,
                &instrPriceNbr, UNUSED, UNUSED);
        }
        else
        {
            /* Fill the Sel_Arg structure for the input */
            SET_ID(ask, Sel_Arg_Id1, ptfId);
            SET_ID(ask, Sel_Arg_Id2, instrId);
            SET_DATETIME(ask, Sel_Arg_FromDate, begDate);
            SET_DATETIME(ask, Sel_Arg_TillDate, date);

            /* sel_all_port_instr_price_by_dt */	/* Select valid prices for the period */
            ret = DBA_Select2(PortfolioInstrPrice, UNUSED, Sel_Arg, ask,
                A_PortfolioInstrPrice, &instrPriceTab, UNUSED, UNUSED,
                &instrPriceNbr, UNUSED, UNUSED);
        }

   	    if (ret == RET_SUCCEED)
        {
            /* PMSTA-30132 - DDV - 180319 - No price found in validity period, load prices on extended validity period */
   	        if (instrPriceNbr==0)
            {
	            /* Select valid prices for the entended validity period */
	            SET_DATETIME(ask, Sel_Arg_FromDate,    extendedBegDate);
	            SET_DATETIME(ask, Sel_Arg_TillDate,    extendedEndDate);

                if (usePtfInstrPrice == FALSE)
                {
                    if (DBA_Select2(InstrPrice, UNUSED, Sel_Arg, ask,
                        A_InstrPrice, &instrPriceTab, UNUSED, UNUSED,
                        &instrPriceNbr, UNUSED, UNUSED) == RET_SUCCEED)
                    {

                        for (x = 0; x < instrPriceNbr; x++)
                        {
                            SET_DATETIME(instrPriceTab[x], A_InstrPrice_BegCoveredPerDate, extendedBegDate);
                            SET_DATETIME(instrPriceTab[x], A_InstrPrice_EndCoveredPerDate, loadEndDate);
                        }
                    }
                }
                else
                {
                    if (DBA_Select2(PortfolioInstrPrice, UNUSED, Sel_Arg, ask,
                        A_PortfolioInstrPrice, &instrPriceTab, UNUSED, UNUSED,
                        &instrPriceNbr, UNUSED, UNUSED) != RET_SUCCEED)
                    {
                    }
                }
                extendedLoadDoneFlg=TRUE;

            }
            else if (usePtfInstrPrice == FALSE)
            {
		        for (i=0; i< instrPriceNbr; i++)
		        {
		            SET_DATETIME(instrPriceTab[i], A_InstrPrice_BegCoveredPerDate, begDate);
		            SET_DATETIME(instrPriceTab[i], A_InstrPrice_EndCoveredPerDate, date);
		        }
            }
        }

        /* REF5714 - AKO - 010223 */
   	    if ((ret!=RET_SUCCEED) || (instrPriceNbr==0))
        {
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"DBA_InstrPriceByFreq",
                            GET_CODE(instrPtr, A_Instr_Cd),
                            "DBA_Select2 - valid prices for the period not found !");
            ret = RET_DBA_ERR_NODATA;
        }
	    else
	    {
		    /* Create a hierarchy to used optimisation of FIN_InstrPrice */	
            if ((tmpHier = DBA_CreateHier())==NULL) /* REF5239 - RAK - 001025 */
            {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                if (usePtfInstrPrice == FALSE)
                    DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
                else
                    DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_PortfolioInstrPrice);
                return (RET_MEM_ERR_ALLOC);
            }

		    /* insert all loaded instrument price into hierarchy */
            if (usePtfInstrPrice == FALSE)
            {
                ret = DBA_AddHierRecordList(tmpHier, instrPriceTab, instrPriceNbr, A_InstrPrice, TRUE);
            }
            else
            {
                ret = DBA_AddHierRecordList(tmpHier, instrPriceTab, instrPriceNbr, A_PortfolioInstrPrice, TRUE);
            }

            if (ret != RET_SUCCEED)
            {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        DBA_FreeHier(tmpHier);
                if (usePtfInstrPrice == FALSE)
       	            DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
                else
                    DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_PortfolioInstrPrice);

	            return(RET_DBA_ERR_HIER);
            }
            FREE(instrPriceTab);    /* PMSTA-41612 - LJE - 201006 */

		    /* insert instrument into hierarchy */
		    if (allocOk == FALSE)
		    {
        	    if ((tmpPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
        	    {
		            DBA_FreeHier(tmpHier);
           	        MSG_RETURN(RET_MEM_ERR_ALLOC);
        	    }
		        COPY_DYNST(tmpPtr, instrPtr, A_Instr);
		    }
		    else
		    {
		        allocOk = FALSE; /* BUG344 - XDI - 970415 */
		        tmpPtr = instrPtr;
		    }

            if ((ret = DBA_AddHierRecord(tmpHier, tmpPtr, A_Instr,
                                         FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
            {
		        DBA_FreeHier(tmpHier);
		        return(RET_DBA_ERR_HIER);
		    }

		    /* Alloc array for Freq_InstrPrice */
		    /* REF547 - Allocate maximal pointer number (use reading) */
		    /* REF2537 - priceTab will contain blank prices -> *priceNbr = reading */
		    *priceNbr = reading;
        	if ((*priceTab=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
        	{
		        DBA_FreeHier(tmpHier);
           	    MSG_RETURN(RET_MEM_ERR_ALLOC);
        	}

		    /* Alloc instrPrice structure */
        	if ((instrPricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
        	{
		        DBA_FreeHier(tmpHier);
		        FREE((*priceTab));	/* REF547 */
           	    MSG_RETURN(RET_MEM_ERR_ALLOC);
        	}

		    /*** ---------------------------------------------- ***/
		    /* Compute price for each date, we need to interprete */
		    /* valuation rules (coding in FIN_InstrPrice())       */
		    /*** ---------------------------------------------- ***/
		    for (i=0; i<reading; i++)
		    {
		        /* REF2537 - priceTab will contain blank prices */
		        if (((*priceTab)[i] = ALLOC_DYNST(Freq_InstrPrice)) == NULLDYNST)
		        {
		            DBA_FreeHier(tmpHier);
			        for (j=0; j<i; j++)
			        { FREE_DYNST((*priceTab)[j], Freq_InstrPrice); }
			        FREE((*priceTab));
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

    	        begDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

                if (usePtfInstrPrice == FALSE)
                {
                    ret = FIN_InstrPrice(instrId, instrPtr, begDate, NULLDYNST,
                        valRuleId, NULL, valRulePtr,
                        extPos, tmpHier, instrPricePtr, FALSE);
                }
                else
                {
                    DBA_DYNFLD_STP  instrPriceArg = NULLDYNST;
                    if ((instrPriceArg = ALLOC_DYNST(InstrPrice_Arg)) == NULLDYNST)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    SET_ID(instrPriceArg, InstrPrice_Arg_InstrId, instrId);
                    SET_ID(instrPriceArg, InstrPrice_Arg_PtfId, ptfId);

                    ret = FIN_InstrPrice(instrId, instrPtr, begDate, instrPriceArg,
                        valRuleId, NULL, valRulePtr,
                        extPos, tmpHier, instrPricePtr, FALSE);

                    FREE_DYNST(instrPriceArg, InstrPrice_Arg);
                }


		        /* REF547 - Allocate and copy only valid price (test return) */
		        if (ret == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
		        {
		    	    /* Copy InstrPrice into Freq_InstrPrice */
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_InstrId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_InstrId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_CurrId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_CurrId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_TpId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_TpId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_ThirdId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_ThirdId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_TermTpId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_TermTpId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_MktThirdId,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_MktThirdId);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_QuoteDate,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_QuoteDate);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_DailyDfltFlg,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_DailyDfltFlg);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_Quote,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_Quote);
                    /* REF7061 - TEB - 021224 - Adding test on method */
                    if ( method == MissingDataMethod_LastValid ||
                         DATETIME_CMP(GET_DATETIME(instrPricePtr, A_InstrPrice_QuoteDate), begDate) == 0)
                    {
                    	COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_Price,
                                    instrPricePtr, A_InstrPrice, A_InstrPrice_Price);
                    }
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_PriceCalcRuleEn,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_PriceCalcRuleEn);
                    COPY_DYNFLD((*priceTab)[i], Freq_InstrPrice, Freq_InstrPrice_UnicityFlg,
                                instrPricePtr, A_InstrPrice, A_InstrPrice_UnicityFlg);
                    SET_DATETIME((*priceTab)[i], Freq_InstrPrice_RequestDate, begDate);

					/* PMSTA-30132 - DDV - 180319 - Current price result from addition load in db, load prices for extended validity period  */
                    if (GET_FLAG(instrPricePtr , A_InstrPrice_ExtendedLoadFlg) == TRUE && extendedLoadDoneFlg == FALSE)
                    {
                        loadExtendedFlg = TRUE;
                    }

		        }
		        else
		        {
					/* PMSTA-30132 - DDV - 180319 - No price at this date, load prices for extended validity period  */
                    if (extendedLoadDoneFlg == FALSE)
                    {
                        loadExtendedFlg = TRUE;
                    }

			        SET_DATETIME((*priceTab)[i], Freq_InstrPrice_QuoteDate, begDate);
   	                if (ret!=RET_SUCCEED)   /* REF5714 - AKO - 010223 */
                    {
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"DBA_InstrPriceByFreq",
                                        GET_CODE(instrPtr, A_Instr_Cd),
                                        "FIN_InstrPrice - Price computing for this instrument failed !");
                    }
                }

				/* PMSTA-30132 - DDV - 180319 - Load prices for extended validity period  */
                if (loadExtendedFlg == TRUE && extendedLoadDoneFlg == FALSE)
                {
                    if (usePtfInstrPrice == FALSE)
                    {
                        if (DBA_ExtractHierEltRec(tmpHier, A_InstrPrice, FALSE, NULL, NULL, &instrPriceNbr, &instrPriceTab) == RET_SUCCEED &&
                            instrPriceNbr > 0)
                        {
                            for (x = 0; x < instrPriceNbr; x++)
                            {
                                SET_DATETIME(instrPriceTab[x], A_InstrPrice_BegCoveredPerDate, extendedBegDate);
                            }
                        }
                        FREE(instrPriceTab);    /* PMSTA-41612 - LJE - 201006 */

                        /* Select valid prices for the entended validity period */
                        SET_DATETIME(ask, Sel_Arg_FromDate, extendedBegDate);
                        SET_DATETIME(ask, Sel_Arg_TillDate, extendedEndDate);
                        if (DBA_Select2(InstrPrice, UNUSED, Sel_Arg, ask,
                            A_InstrPrice, &instrPriceTab, UNUSED, UNUSED,
                            &instrPriceNbr, UNUSED, UNUSED) == RET_SUCCEED)
                        {

                            for (x = 0; x < instrPriceNbr; x++)
                            {
                                SET_DATETIME(instrPriceTab[x], A_InstrPrice_BegCoveredPerDate, extendedBegDate);
                                SET_DATETIME(instrPriceTab[x], A_InstrPrice_EndCoveredPerDate, loadEndDate);
                            }

                            /* insert all loaded instrument price into hierarchy */
                            if (DBA_AddHierRecordList(tmpHier, instrPriceTab, instrPriceNbr,
                                                      A_InstrPrice, TRUE) != RET_SUCCEED)
                            {
                                if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
                                DBA_FreeHier(tmpHier);
                                DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);
                                return(RET_DBA_ERR_HIER);
                            }
                        }
                        FREE(instrPriceTab);    /* PMSTA-41612 - LJE - 201006 */

                    }
                    else
                    {
                        /* Select valid prices for the entended validity period */
                        SET_DATETIME(ask, Sel_Arg_FromDate, extendedBegDate);
                        SET_DATETIME(ask, Sel_Arg_TillDate, extendedEndDate);
                        if (DBA_Select2(PortfolioInstrPrice, UNUSED, Sel_Arg, ask,
                            A_PortfolioInstrPrice, &instrPriceTab, UNUSED, UNUSED,
                            &instrPriceNbr, UNUSED, UNUSED) == RET_SUCCEED)
                        {
                            /* insert all loaded instrument price into hierarchy */
                            if (DBA_AddHierRecordList(tmpHier, instrPriceTab, instrPriceNbr,
                                                      A_PortfolioInstrPrice, TRUE) != RET_SUCCEED)
                            {
                                if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
                                DBA_FreeHier(tmpHier);
                                DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_PortfolioInstrPrice);
                                return(RET_DBA_ERR_HIER);
                            }
                        }
                        FREE(instrPriceTab);    /* PMSTA-41612 - LJE - 201006 */
                    }

                    extendedLoadDoneFlg=TRUE;
                    loadExtendedFlg = FALSE;
                }
		    }

		    /* free hierarchy and instrPrice */
		    DBA_FreeHier(tmpHier);
		    FREE_DYNST(instrPricePtr, A_InstrPrice);

		    correctFact = 1.0;

		    for (i=0, begDate.date=0; i<*priceNbr && begDate.date==0; i++)
			    if (IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_QuoteDate) == FALSE)
				    begDate = GET_DATETIME((*priceTab)[i], Freq_InstrPrice_QuoteDate);

		    for (i=(*priceNbr)-1, endDate.date=0; i>=0 && endDate.date==0; i--)
			    if (IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_QuoteDate) == FALSE)
				    endDate = GET_DATETIME((*priceTab)[i], Freq_InstrPrice_QuoteDate);

		    if (begDate.date != 0 && endDate.date != 0)
		    {
				/* PMSTA08120 - LJE - 090408 : Add one day to avoid the price conversion factor at the beginning */
				begDate.date = DATE_Move(begDate.date, 1, Day);

		        /* Search current(s) conversion factor(s)  */
	                ret = DBA_SelectInstrChrono(instrId, begDate, endDate,
                        ChronoNat_PriceConvFactor, (ID_T)0, hierHead, &chronoTab, &chronoNbr); /* REF10598 - LJE - 041011 */
		    }
		    else
		    {
		        chronoNbr = 0;
		        ret = RET_SUCCEED;
		    }

		    if (ret == RET_SUCCEED)
		    {
		        /* Convert prices in instrument currency */
		        for (ret=RET_SUCCEED, i=0, correct=0; i<*priceNbr && ret==RET_SUCCEED; i++)
		        {
		            /* Multiply conversion factor validity */
		            /* date by validity date               */
		            while (correct < chronoNbr &&
			               DATETIME_CMP(GET_DATETIME(chronoTab[correct], A_InstrChrono_ValidDate),
			               GET_DATETIME((*priceTab)[i], Freq_InstrPrice_QuoteDate)) < 0)
		            {
						/*
						** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
						** instr_chrono.value_n has been changed from NUMBER to LONGAMOUTN.
						*/
			            correctFact *= GET_LONGAMOUNT(chronoTab[correct], A_InstrChrono_Val);
			            correct++;
		            }

		            if (IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_CurrId) == FALSE &&
			        IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_Price) == FALSE)
		            {
			            /* --------------------------- */
			            /* BEGIN DVP142 - RAK - 960612 */
			            /* if (GET_ID(instrPtr, A_Instr_RefCurrId) !=
			                GET_ID((*priceTab)[i], Freq_InstrPrice_CurrId)) */
			            if (currId != GET_ID((*priceTab)[i], Freq_InstrPrice_CurrId))
			            /* END DVP142 - RAK - 960612 */
			            /* ------------------------- */
			            {
				            FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
				            memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

			                if ((ret = FIN_GetExchRate(
					           GET_DATETIME((*priceTab)[i], Freq_InstrPrice_QuoteDate),
                                                   GET_ID((*priceTab)[i], Freq_InstrPrice_CurrId),
		                                   /* DVP142 GET_ID(instrPtr, A_Instr_RefCurrId)*/ currId,
					           (ID_T)0, NULLDYNST, extPos, &exchArgSt, &exch))==RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
			                {
				                exch *= (GET_PRICE((*priceTab)[i], Freq_InstrPrice_Price));

				                SET_PRICE((*priceTab)[i], Freq_InstrPrice_Price, CAST_PRICE(exch)); /* REF3288 - SSO - 990205 */
		    	                /* --------------------------- */
		    	                /* BEGIN DVP142 - RAK - 960612 */
				                /* SET_ID((*priceTab)[i], Freq_InstrPrice_CurrId,
			                    GET_ID(instrPtr, A_Instr_RefCurrId)); */
				                SET_ID((*priceTab)[i], Freq_InstrPrice_CurrId, currId);
			    	            /* END DVP142 - RAK - 960612 */
			    	            /* ------------------------- */
			                }
			                else
			                {
				                if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
				                DBA_FreeDynStTab(*priceTab, *priceNbr, Freq_InstrPrice);
				                /* ---------------------------------------- */
				                /* BEGIN BUG024                 960419 RAK  */
				                /* if (RET_GET_LEVEL(ret) != RET_LEV_ERROR) */
				                /* 	ret = RET_DBA_ERR_NODATA;           */
				                return(RET_DBA_ERR_NODATA);
				                /* END   BUG024                  960419 RAK */
				                /* ---------------------------------------- */
			                }
	                    }
	                }

			        if (IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_Price) == FALSE)
			        {
		                    price = GET_PRICE((*priceTab)[i],Freq_InstrPrice_Price) / correctFact;
		                    SET_PRICE((*priceTab)[i],Freq_InstrPrice_Price, CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
			        }
                }
		        /* REF2544 - SSO - 980717 - TLS_Sort is done in DBA_InstrPriceByFreq  */
		        /* REF2387 - DDV - 980619 - Sort price array ascending by date */
		        TLS_Sort((char *) *priceTab, *priceNbr, sizeof(DBA_DYNFLD_STP),
			         (TLS_CMPFCT *)DBA_CmpInstrPriceDate, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
		    }

            /* REF7061 - TEB - 021224 - Adding missing data resolution method - Begin modif. */
            nbPrice = 0;
            if (method == MissingDataMethod_Average)
		        for (i=0; i<reading; i++)
                    if (IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_Price) == FALSE)
                    {
                        sumPrices += GET_PRICE((*priceTab)[i], A_InstrPrice_Price);
                        nbPrice++;
                    }

		    for (i=0; i<reading; i++)
		    {
                if ( IS_NULLFLD((*priceTab)[i], Freq_InstrPrice_Price) == TRUE)
                {
                    switch(method)
                    {
                        case MissingDataMethod_IgnoreMissing:
                            (*priceNbr)--;
                            reading--;
                            FREE_DYNST((*priceTab)[i], Freq_InstrPrice);
                            for(j=i; j<reading; j++)
                                (*priceTab)[j] = (*priceTab)[j+1];
                            (*priceTab)[j] = NULLDYNST;
                            i--;
                            break;

                        case MissingDataMethod_Average:
                            if (nbPrice!=0)
                                SET_PRICE((*priceTab)[i], Freq_InstrPrice_Price, sumPrices/nbPrice);
                            break;

                        case MissingDataMethod_Encadrante:
                            if (i == 0)
                            {
                                reading--;
                                (*priceNbr)--;
                                FREE_DYNST((*priceTab)[i], Freq_InstrPrice);
                                for(j=i; j<reading; j++)
                                    (*priceTab)[j] = (*priceTab)[j+1];
                                (*priceTab)[j] = NULLDYNST;
                                i--;
                            }
                            else
                            {
                                prevValue = GET_PRICE((*priceTab)[i-1], Freq_InstrPrice_Price);

                                for (j=i;
                                     j<reading && IS_NULLFLD((*priceTab)[j], Freq_InstrPrice_Price) == TRUE;
                                     j++) ; /* I want it */

                                if (j<reading)
                                {
                                    nextValue = GET_PRICE((*priceTab)[j], Freq_InstrPrice_Price);
                                    for (k=i; k<j; k++)
                                        SET_PRICE((*priceTab)[k], Freq_InstrPrice_Price, (prevValue+nextValue)/2);
                                }
                                else
                                {
                                    for(j=i; j<reading; j++)
                                        FREE_DYNST((*priceTab)[j], Freq_InstrPrice);
                                    reading=i;
                                    (*priceNbr)=i;
                                }
                            }
                            break;
                    }
                }
            }
            /* REF7061 - TEB - 021224 - End modif */
	    }
	    break;

	case ValRule_Quote1 :
        /* REF5714 - AKO - 010223 */
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"DBA_InstrPriceByFreq",
                        GET_CODE(instrPtr, A_Instr_Cd),
                        "instrument not quoted, price is 1 !");
	    ret =  RET_GEN_INFO_NOACTION;
	    break;

	case ValRule_Quote0 :
	case ValRule_Composite :
	case ValRule_Theo :
	case ValRule_Debt :
	case ValRule_RefInstr :
	case ValRule_Script :
	case ValRule_ParInstr :
	default :
        /* REF5714 - AKO - 010223 */
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"DBA_InstrPriceByFreq",
                        GET_CODE(instrPtr, A_Instr_Cd),
                        "Instrument valuation rule does not match with a treatment !");
	    ret = RET_GEN_INFO_NOACTION; /* temporary ?? */
	}

    /* REF5714 - AKO - 010223 */
	/*if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	    	MSG_SendMesg(ret, 0, FILEINFO); */

	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SelAllInterCondDt2()
**
**  Description :   Loop on all A_InterCond elements, select criterias are:
**		    input A_InterCond_InstrId         == found A_InterCond_InstrId.         Mandatory.
**		    input A_InterCond_ValidDate       >= found A_InterCond_ValidDate.       Mandatory.
**		    input A_InterCond_BegDate         >= found A_InterCond_BegDate.         Mandatory.
**		    input A_InterCond_BegDate          < found A_InterCond_EndDate.         Mandatory.
**		    input A_InterCond_ValidDate        < found A_InterCond_EndValidDate.    Mandatory.
**		    input A_InterCond_InterCalcRuleEn == found A_InterCond_InterCalcRuleEn. Optional.
**		    like stored proc. sel_all_interest_cond_by_dt.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : REF3678 - RAK - 990819
**  Modification  : REF6004 - AKO - 011218 : New criteria intercondNat
**					REF11811 - TGU - 060609 - A_InterCond should also be selected if (A_InterCond_BegDate = found A_InterCond_EndDate).
**
*************************************************************************/
STATIC RET_CODE	DBA_SelAllInterCondDt2(     DBA_DYNFLD_STP      inputData,
                                            DBA_DYNFLD_STP      *tmpInterCondTab,
                                            int		            tmpInterCondNbr,
                                            DBA_DYNFLD_STP	    **aInterCondTab,
                                            int		            *aInterCondNbr,
											FLAG_T              freeFlg)
{
    int	                i;
    DBA_DYNFLD_STP      *validInterCondTab=NULLDYNSTPTR;
    int		            validInterCondNbr=0;

    *aInterCondTab=NULL;
    *aInterCondNbr=0;

	/* PMSTA-7731 - 100923 - RAK/DDV - report from 4.30.3 */
	if (tmpInterCondNbr <= 0)
		return(RET_SUCCEED);

    DBA_BuildValidInterCondTab(inputData, tmpInterCondTab, tmpInterCondNbr, &validInterCondTab, &validInterCondNbr, freeFlg);

	if (validInterCondNbr <= 0)
		return(RET_SUCCEED);

    if (((*aInterCondTab) = (DBA_DYNFLD_STP*)
	 CALLOC(validInterCondNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
	DBA_FreeDynStTab(validInterCondTab, validInterCondNbr, A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
	return(RET_MEM_ERR_ALLOC);
    }

    for (i=0, (*aInterCondNbr)=0; i<validInterCondNbr; i++)
    {
	    if (GET_ID(inputData, A_InterCond_InstrId) !=
		GET_ID(validInterCondTab[i], A_InterCond_InstrId))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond);  /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_ValidDate) <
		GET_DATE(validInterCondTab[i], A_InterCond_ValidDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_BeginDate) <
		GET_DATE(validInterCondTab[i], A_InterCond_BeginDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

		/* TGU - REF11811 - 060609 */
	    if (GET_DATE(inputData, A_InterCond_BeginDate) >
		GET_DATE(validInterCondTab[i], A_InterCond_EndDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_ValidDate) >=
		GET_DATE(validInterCondTab[i], A_InterCond_EndValidDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (IS_NULLFLD(inputData, A_InterCond_IntCalcRuleEn) == FALSE)
	    {
		if (GET_ENUM(inputData, A_InterCond_IntCalcRuleEn) !=
		    GET_ENUM(validInterCondTab[i], A_InterCond_IntCalcRuleEn))
			{
				FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
				continue;
			}
	    }

        if (IS_NULLFLD(inputData, A_InterCond_NatEn) == FALSE) /* REF6004 - AKO - 011218 */
	    {
            if (GET_ENUM(inputData,A_InterCond_NatEn) != InterCondNat_None)
            {
		        if (GET_ENUM(inputData, A_InterCond_NatEn) !=
		            GET_ENUM(validInterCondTab[i], A_InterCond_NatEn))
				{
					FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
					continue;
				}
            }
	    }

	    /* We found one A_InterCond matching the search criterias. */
	    (*aInterCondTab)[(*aInterCondNbr)++] = validInterCondTab[i];
    }

	FREE(validInterCondTab); /* PMSTA15548 - DDV - 121129 - Purify */
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_SelAllInterCondIdDt()
**
**  Description :   Loop on all A_InterCond elements, select criterias are:
**		    input A_InterCond_InstrId == found A_InterCond_InstrId.         Mandatory.
**		    input A_InterCond_EndDate >= found A_InterCond_BegDate.         Mandatory.
**		    input A_InterCond_BegDate <= found A_InterCond_EndDate.         Mandatory.
**		    input A_InterCond_BegDate <= found A_InterCond_EndValidDate.    Mandatory.
**		    like stored proc. sel_all_interest_cond_by_id_dt.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : REF3678 - RAK - 990819
**
*************************************************************************/
STATIC RET_CODE	DBA_SelAllInterCondIdDt2(   DBA_DYNFLD_STP	inputData,
                                            DBA_DYNFLD_STP	*tmpInterCondTab,
                                            int		        tmpInterCondNbr,
                                            DBA_DYNFLD_STP	**aInterCondTab,
                                            int		        *aInterCondNbr,
											FLAG_T          freeFlg)
{
    int	i;
    DBA_DYNFLD_STP      *validInterCondTab=NULLDYNSTPTR;
    int		            validInterCondNbr=0;

	/* PMSTA-7731 - 100923 - RAK/DDV - report from 4.30.3 */
	if (tmpInterCondNbr <= 0)
		return(RET_SUCCEED);
    DBA_BuildValidInterCondTab(inputData, tmpInterCondTab, tmpInterCondNbr, &validInterCondTab, &validInterCondNbr, freeFlg);

	if (validInterCondNbr <= 0)
		return(RET_SUCCEED);

    if (((*aInterCondTab) = (DBA_DYNFLD_STP*)
	 CALLOC(validInterCondNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
		DBA_FreeDynStTab(validInterCondTab, validInterCondNbr, A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
	return(RET_MEM_ERR_ALLOC);
    }

    for (i=0, (*aInterCondNbr)=0; i<validInterCondNbr; i++)
    {
	    if (GET_ID(inputData, A_InterCond_InstrId) !=
	        GET_ID(validInterCondTab[i], A_InterCond_InstrId))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_EndDate) <
	        GET_DATE(validInterCondTab[i], A_InterCond_BeginDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_BeginDate) >
	        GET_DATE(validInterCondTab[i], A_InterCond_EndDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_EndDate) <
	        GET_DATE(validInterCondTab[i], A_InterCond_ValidDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_BeginDate) >
	        GET_DATE(validInterCondTab[i], A_InterCond_EndValidDate))
		{
			FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
	        continue;
		}

        if (IS_NULLFLD(inputData, A_InterCond_NatEn) == FALSE) /* REF6004 - AKO - 011218 */
	    {
            if (GET_ENUM(inputData,A_InterCond_NatEn) != InterCondNat_None)
            {
		        if (GET_ENUM(inputData, A_InterCond_NatEn) !=
		            GET_ENUM(validInterCondTab[i], A_InterCond_NatEn))
					{
						FREE_DYNST(validInterCondTab[i], A_InterCond); /* PMSTA15548 - DDV - 121129 - Purify */
						continue;
					}
            }
	    }



	    /* We found one A_InterCond matching the search criterias. */
	    (*aInterCondTab)[(*aInterCondNbr)++] = validInterCondTab[i];
    }

	FREE(validInterCondTab); /* PMSTA15548 - DDV - 121129 - Purify */
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_InterCondInstrIdByDtCmp()
**
**  Description :   Index InterCond array by instrument identifier
**		            and sort like sel_all_interest_cond_by_dt.
**                  ! this proc is used for index creation in hierarchy tools ...
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**  Creation date   : REF3678 - RAK - 990819
**  Modif.          :   REF5702 - RAK - 010307
**
*************************************************************************/
int DBA_InterCondInstrIdByDtCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

    /* index is done on instrument identifier ... */
    int	diff = CMP_DYNFLD(*ptr1, *ptr2, A_InterCond_InstrId, A_InterCond_InstrId, IdType);

    if (diff == 0)
    {
	    /* Sort like stored proc sel_all_interest_cond_by_dt. */
	    /* A_InterCond_InterCalcRuleEn ascending,  */
	    /* A_InterCond_ValidDate       descending, (reverse ptr1, ptr2) */
            /* A_InterCond_BegDate         descending. (reverse ptr1, ptr2) */
	    diff = CMP_DYNFLD(*ptr1, *ptr2, A_InterCond_IntCalcRuleEn, A_InterCond_IntCalcRuleEn, EnumType);


        if (diff == 0)
	    {
            /* REF5702 - RAK - 010307 */
	        /* diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_ValidDate, A_InterCond_ValidDate, DateType);

	        if (diff == 0)
		        diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_BegDate, A_InterCond_BegDate, DateType);
	        */

            diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_BeginDate, A_InterCond_BeginDate, DateType);

	        if (diff == 0)
		        diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_ValidDate, A_InterCond_ValidDate, DateType);
        }
    }

    return(diff);
}

/************************************************************************
**
**  Function        :   DBA_InterCondInstrIdByIdDtCmp()
**
**  Description     :   Index InterCond array by instrument identifier
**		                and sort like sel_all_interest_cond_by_id_dt.
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   REF3678 - RAK - 990819
**  Modif.          :   REF5702 - RAK - 010307
**
*************************************************************************/
STATIC int DBA_InterCondInstrIdByIdDtCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    /* Sort like stored proc sel_all_interest_cond_by_id_dt. */
    /* A_InterCond_InterCalcRuleEn ascending,  */
    /* A_InterCond_BegDate         ascending.  */
    int	diff = CMP_DYNFLD(*ptr1, *ptr2, A_InterCond_IntCalcRuleEn, A_InterCond_IntCalcRuleEn, EnumType);

    if (diff == 0)
	    diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, A_InterCond_BeginDate, A_InterCond_BeginDate, DateType);

    /* REF5702 - RAK - 010307 */
    if (diff == 0)
        diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, A_InterCond_ValidDate, A_InterCond_ValidDate, DateType);

    return(diff);
}

/************************************************************************
**
**  Function    :   DBA_InterCondInstrIdByDtNatCmp()
**
**  Description :   Index InterCond array by instrument identifier
**		            and sort like sel_all_interest_cond_by_dt + nature !
**                  this proc is used in updating dates in DBA_UpdInterCondEndDate()
**
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**  Creation date   : PMSTA07712-CHU-090505
**
*************************************************************************/
int DBA_InterCondInstrIdByDtNatCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

    /* index is done on instrument identifier ... */
    int	diff = CMP_DYNFLD(*ptr1, *ptr2, A_InterCond_InstrId, A_InterCond_InstrId, IdType);

    if (diff == 0)
    {
	    /* Sort like stored proc sel_all_interest_cond_by_dt. */
	    /* A_InterCond_NatEn       ascending,  */
	    /* A_InterCond_ValidDate   descending, (reverse ptr1, ptr2) */
        /* A_InterCond_BegDate     descending. (reverse ptr1, ptr2) */
	    diff = CMP_DYNFLD(*ptr1, *ptr2, A_InterCond_NatEn, A_InterCond_NatEn, EnumType);

        if (diff == 0)
	    {
			diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_BeginDate, A_InterCond_BeginDate, DateType);

	        if (diff == 0)
		        diff = CMP_DYNFLD_SYB(*ptr2, *ptr1, A_InterCond_ValidDate, A_InterCond_ValidDate, DateType);
        }
    }

    return(diff);
}

/************************************************************************
**
**  Function    :   FIN_FilterCrtInstr
**
**  Description :   Extract current instrument poositions
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**					instrPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation date : PMSTA01512-CHU-070426
**
*************************************************************************/
STATIC int FIN_FilterCrtInstr(DBA_DYNFLD_STP dynSt,
			    DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP instrPtr)
{
	if (GET_ID(dynSt, ExtPos_InstrId) == GET_ID(instrPtr, A_Instr_Id))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpPosValDate()
**
**  Description :   sort positions on value date
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date : PMSTA01512-CHU-070426
**
*************************************************************************/
int FIN_CmpPosValDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return (DATETIME_CMP(GET_DATETIME((*ptr1), ExtPos_ValDate),
						 GET_DATETIME((*ptr2), ExtPos_ValDate)));
}

/************************************************************************
**
**  Function    :   DBA_GetOldestValDate()
**
**  Description :   Select oldest Value Date from positions on instrument
**
**  Arguments   :   argHierHead : pointer on hierarchy head
**                  instrPtr    : pointer on current instrument
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : PMSTA01512-CHU-070426
**
*************************************************************************/
STATIC DATETIME_T DBA_GetOldestValDate(DBA_HIER_HEAD_STP hierHead,
									   DBA_DYNFLD_STP	instrPtr)
{
	DATETIME_T			tmpDate;
	DBA_DYNFLD_STP		*extPosTab = NULL;
	int					extPosNbr = 0;

    tmpDate.date = 0;
    tmpDate.time = 0;

	/* look for extPos on instrument, sorted with oldest date first */
	if (DBA_ExtractHierEltRecWithFilterSt(hierHead, ExtPos,
										  FALSE,
										  FIN_FilterCrtInstr,
										  instrPtr,
										  FIN_CmpPosValDate,
										  &extPosNbr, &extPosTab) != RET_SUCCEED)

	{
		return(tmpDate);
	}

	if (extPosNbr > 0)
	{
		tmpDate = GET_DATETIME(extPosTab[0], ExtPos_ValDate);
	}
    FREE(extPosTab); /* PMSTA07185 - DDV - 081023 - Purify */

	return(tmpDate);
}

/************************************************************************
**
**  Function    :   DBA_SelAllInterCond()
**
**  Description :   Select instrument interest condition(s) according to received arguments
**
**		    Use instrument extension if possible or hiearchy element A_InterCond (indexed)
**		    or call stored proc.
**		    If parameter interCondBy is
**		    - InterCond_ByDt, selection is equal to proc sel_all_interest_cond_by_dt
**		    - InterCond_ByIdDt, selection is equal to proc sel_all_interest_cond_by_id_dt
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : REF6004 - AKO - 011218 : new parameter
**  Modif date    : REF6004 - AKO - 011221 : new parameter embedded in inputData
**                  PMSTA08450 - 200709 - PMO : Calculation of accrued interests are not always right computed
*************************************************************************/
RET_CODE  DBA_SelAllInterCond(  INTERCONDBY_ENUM    interCondBy,    /* REF6004 - AKO - 011221 :  DBA_SelAllInterCond2 redefined */
                                DBA_HIER_HEAD_STP   hierHeadParam,       /* DBA_SelAllInterCond again */
                                DBA_DYNFLD_STP      instrPtr,
                                DBA_DYNFLD_STP      inputData,
                                DBA_DYNFLD_STP      **aInterCondTab,
                                int                 *aInterCondNbr,
                                FLAG_T		        *freeFlg
                                /*INTERCONDNAT_ENUM   intercondNat*/) /* REF6004 - AKO - 011221 */
{
    RET_CODE	    ret=RET_SUCCEED;
    DBA_DYNFLD_ST   instrIdDynSt;
    DBA_DYNFLD_STP  *tmpInterCondTab=NULLDYNSTPTR;
    int		        tmpInterCondNbr=0, i;
    DBA_HIER_HEAD_STP hierHead=hierHeadParam; /* REF7264 - LJE - 020205 */
	FLAG_T			is_MM_or_FI_FundShareFlg = FALSE;
	FLAG_T			isInstrInHierFlg = TRUE;


	if (instrPtr != NULLDYNST &&
	(INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare  &&
	((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
	 (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
	{
		is_MM_or_FI_FundShareFlg = TRUE;
	}

	memset(&instrIdDynSt, 0, sizeof(DBA_DYNFLD_ST)); /* REF7264 - LJE - 020205 */

    *aInterCondTab = NULLDYNSTPTR;
    *aInterCondNbr = 0;
    *freeFlg = TRUE; /* PMSTA10461 - DDV - 110726 - Now it's allways a copy */

    /* If instrument isn't in hierarchy or link isn't already set, */
    /* first search in hierarchy using index, then select in database ... */
    if (instrPtr == NULLDYNST ||
		IS_NULLFLD(instrPtr, A_Instr_Cond_A_Instr_Ext) == TRUE ||
		IS_NULLFLD(instrPtr, A_Instr_InterCondInHerFlg) == TRUE || /* REF10696 - DDV - 041203*/
		GET_FLAG(instrPtr, A_Instr_InterCondInHerFlg) == FALSE)

    {
	if (hierHead == NULL)
	{
	    if (SYS_IsSrvMode() == TRUE)
	    {
		/* Is there any hierarchy stored in memory ? */
            hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
	    }
	}

	/* Search in hierarchy */
	if (hierHead != NULL)
	{
	    SET_ID((&instrIdDynSt), 0, GET_ID(inputData, A_InterCond_InstrId));
	    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_InterCond,         /* PMSTA-13295 - JPP - 20120213 */
                                                       A_InterCond_InstrId, instrIdDynSt, FALSE,
			                               NULLFCT, NULLDYNST,
			                               NULLFCT, FALSE,
					 	       &tmpInterCondNbr, &tmpInterCondTab)) != RET_SUCCEED)
	    {
		return(ret);
	    }
	    else if (tmpInterCondNbr > 0)
	    {
		/* Select interCond according to inputData criteria ... */
		if (interCondBy == InterCond_ByDt)
		{
			ret = DBA_SelAllInterCondDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									aInterCondTab, aInterCondNbr, FALSE);
			/* record are already sorted like stored proc (hierarchy index sort function) */
		}
		else
		{
			ret = DBA_SelAllInterCondIdDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									  aInterCondTab, aInterCondNbr, FALSE);
			/* Sort records like stored proc. */
			if ((*aInterCondNbr) > 1)
			TLS_Sort((char *) (*aInterCondTab), (*aInterCondNbr), sizeof(DBA_DYNFLD_STP),
				 (TLS_CMPFCT *)DBA_InterCondInstrIdByIdDtCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
		}
		FREE(tmpInterCondTab);
		return(ret);
		}
	}

	/* If nothing found in hiearchy or no hierarchy, select in database */

	/* PMSTA01512-CHU-070426 : special traitment for IC on FundShares */
	if (is_MM_or_FI_FundShareFlg == TRUE
		&& instrPtr != NULL)
	{
		DATETIME_T tmpDate;
		DBA_DYNFLD_STP tmpInputData, tmpInstrPtr;
		FLAG_T		preLoadFlg = (FLAG_T)(interCondBy == InterCond_PreLoad);

		if ((tmpInputData = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
			return(RET_MEM_ERR_ALLOC);
		}
		COPY_DYNST(tmpInputData, inputData, A_InterCond);

		/* Insert Instrument into Hierarchy if not present */
		DBA_GetRecPtrFromHierById(hierHead, GET_ID(instrPtr, A_Instr_Id), A_Instr, &tmpInstrPtr);
		if (tmpInstrPtr == NULL)
		{
			isInstrInHierFlg = FALSE;
			if ((tmpInstrPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
			{
                FREE_DYNST(tmpInputData, A_InterCond);  /* PMSTA08450 - 200709 - PMO */
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
				return(RET_MEM_ERR_ALLOC);
			}

			COPY_DYNST(tmpInstrPtr, instrPtr, A_Instr);

			if (DBA_AddHierRecord(hierHead, tmpInstrPtr, A_Instr, TRUE,
								  HierAddRec_ForceInsert) != RET_SUCCEED)
			{
                FREE_DYNST(tmpInputData, A_InterCond);  /* PMSTA08450 - 200709 - PMO */
				*aInterCondTab = NULLDYNSTPTR;
				*aInterCondNbr = 0;
				return(RET_SUCCEED);
			}
		}

		/* Get oldest valdate from positions on this instrument to get all valid Inter Cond stored in hierarchy */
		tmpDate = DBA_GetOldestValDate(hierHead, instrPtr);
		if (tmpDate.date > 0)
		{
			SET_DATETIME(tmpInputData, A_InterCond_BeginDate, tmpDate);
		}
		else
		{
			if (preLoadFlg == TRUE &&
				IS_NULLFLD(instrPtr, A_Instr_BeginDate) == FALSE)
			{
				SET_DATETIME(tmpInputData, A_InterCond_BeginDate, GET_DATETIME(instrPtr, A_Instr_BeginDate));
			}
		}


		/* PMSTA02452-CHU-070626 : Initialisation for IC PreLoad during Return Analysis */
		if (preLoadFlg == TRUE)
		{
			/* Treat tmpInputData : Check and init ValidDate */
			if (IS_NULLFLD(tmpInputData, A_InterCond_ValidDate) == TRUE &&
				IS_NULLFLD(tmpInputData, A_InterCond_BeginDate) == FALSE)
			{
				SET_DATETIME(tmpInputData, A_InterCond_ValidDate,
					GET_DATETIME(tmpInputData, A_InterCond_BeginDate));
			}
		}

		/* Get Inter Cond records from database */
	    if(IS_NULLFLD(tmpInputData, A_InterCond_BeginDate) == FALSE)
		{
		    ret = DBA_Select2(InterCond, UNUSED, A_InterCond, tmpInputData,
			      A_InterCond, aInterCondTab, UNUSED, UNUSED,
			      aInterCondNbr, UNUSED, UNUSED);
		}

        FREE_DYNST(tmpInputData, A_InterCond);  /* PMSTA08450 - 200709 - PMO */

		/* PMSTA05878 - DDV - 080429 - Set end date and end validity date */
		if ((*aInterCondNbr) > 1)
		{
			DBA_UpdInterCondEndDate((*aInterCondTab), (*aInterCondNbr), NULLDYNST);
		}

		/* Add Inter Cond in hierarchy */
		if (DBA_AddHierRecordList(hierHead, *aInterCondTab, *aInterCondNbr,
								  A_InterCond, TRUE) != RET_SUCCEED)
		{
			*aInterCondTab = NULLDYNSTPTR;
			*aInterCondNbr = 0;
			return(RET_SUCCEED);
		}

		/* Set links A_Instr -> A_InterCond to used, if not already done... */
		if (DBA_SetHierLnkUsed(hierHead, A_Instr, A_Instr_Cond_A_Instr_Ext) != RET_SUCCEED)
		{
			*aInterCondTab = NULLDYNSTPTR;
			*aInterCondNbr = 0;
			return(RET_SUCCEED);
		}

		/* Link all Interest Conditions to Instrument */
		for (i = 0; i < *aInterCondNbr; i++)
		{
			if (isInstrInHierFlg == TRUE)
				DBA_ForceLink(hierHead, A_Instr, A_Instr_Cond_A_Instr_Ext, instrPtr,    (*aInterCondTab)[i]);
			else
				DBA_ForceLink(hierHead, A_Instr, A_Instr_Cond_A_Instr_Ext, tmpInstrPtr, (*aInterCondTab)[i]);
		}

		/* PMSTA02452-CHU-070626 : PreLoad is done, quit the function */
		if (preLoadFlg == TRUE)
			return(RET_SUCCEED);

		/* Now select of Inter Cond can be based on initial inputdata */
		if (isInstrInHierFlg == TRUE)
		{
			tmpInterCondTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(instrPtr, A_Instr_Cond_A_Instr_Ext);
			tmpInterCondNbr = (int) GET_EXTENSION_NBR(instrPtr, A_Instr_Cond_A_Instr_Ext);
		}
		else
		{
			tmpInterCondTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(tmpInstrPtr, A_Instr_Cond_A_Instr_Ext);
			tmpInterCondNbr = (int) GET_EXTENSION_NBR(tmpInstrPtr, A_Instr_Cond_A_Instr_Ext);
		}

		/* No InterCond for instrument */
		if (tmpInterCondTab == NULLDYNSTPTR && tmpInterCondNbr == 0)
		{
			*aInterCondTab = NULLDYNSTPTR;
			*aInterCondNbr = 0;
			return(RET_SUCCEED);
		}

		/* Select interCond according to inputData criteria ... */
		if (interCondBy == InterCond_ByDt)
		{
			ret = DBA_SelAllInterCondDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									aInterCondTab, aInterCondNbr, FALSE);
			/* record are already sorted like stored proc (hierarchy index sort function) */
		}
		else
		{
			ret = DBA_SelAllInterCondIdDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									  aInterCondTab, aInterCondNbr, FALSE);
			/* Sort records like stored proc. */
			if ((*aInterCondNbr) > 1)
			TLS_Sort((char *) (*aInterCondTab), (*aInterCondNbr), sizeof(DBA_DYNFLD_STP),
				 (TLS_CMPFCT *)DBA_InterCondInstrIdByIdDtCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
		}
		return(RET_SUCCEED);
	}
	else
	{
		*freeFlg = TRUE;
		if(IS_NULLFLD(inputData, A_InterCond_BeginDate) == FALSE)
		{
		    ret = DBA_Select2(InterCond, UNUSED, A_InterCond, inputData,
					  A_InterCond, &tmpInterCondTab, UNUSED, UNUSED,
					  &tmpInterCondNbr, UNUSED, UNUSED);

		}

		/* No InterCond for instrument */
		if (tmpInterCondTab == NULLDYNSTPTR && tmpInterCondNbr == 0)
		{
			*aInterCondTab = NULLDYNSTPTR;
			*aInterCondNbr = 0;
			return(RET_SUCCEED);
		}

		/* PMSTA05878 - DDV - 080429 - Set end date and end validity date */
		if (tmpInterCondNbr > 1)    /*  FPL-PMSTA08704-100205   if ((*aInterCondNbr) > 1)   */
		{
			DBA_UpdInterCondEndDate(tmpInterCondTab, tmpInterCondNbr, NULLDYNST);
		}

		/* Select interCond according to inputData criteria ... */
		if (interCondBy == InterCond_ByDt)
		{
			ret = DBA_SelAllInterCondDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									aInterCondTab, aInterCondNbr, TRUE);
			/* record are already sorted like stored proc (hierarchy index sort function) */
		}
		else
		{
			ret = DBA_SelAllInterCondIdDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
									  aInterCondTab, aInterCondNbr, TRUE);
			/* Sort records like stored proc. */
			if ((*aInterCondNbr) > 1)
			TLS_Sort((char *) (*aInterCondTab), (*aInterCondNbr), sizeof(DBA_DYNFLD_STP),
				 (TLS_CMPFCT *)DBA_InterCondInstrIdByIdDtCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
		}
		FREE(tmpInterCondTab);
	}
	return(ret);	/* return selected record(s) */
    }
    /* instrument have extension on InterCond */
    else
    {
	tmpInterCondTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(instrPtr, A_Instr_Cond_A_Instr_Ext);
	tmpInterCondNbr = (int) GET_EXTENSION_NBR(instrPtr, A_Instr_Cond_A_Instr_Ext);

	/* No InterCond for instrument */
	if (tmpInterCondTab == NULLDYNSTPTR && tmpInterCondNbr == 0)
	{
	    *aInterCondTab = NULLDYNSTPTR;
	    *aInterCondNbr = 0;
	    return(RET_SUCCEED);
	}

	/* Select interCond according to inputData criteria ... */
	if (interCondBy == InterCond_ByDt)
	{
		ret = DBA_SelAllInterCondDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
						aInterCondTab, aInterCondNbr, FALSE);
		/* Sort records like stored proc. */
		if ((*aInterCondNbr) > 1)
		TLS_Sort((char *) (*aInterCondTab), (*aInterCondNbr), sizeof(DBA_DYNFLD_STP),
			 (TLS_CMPFCT *)DBA_InterCondInstrIdByDtCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
	}
	else
	{
		ret = DBA_SelAllInterCondIdDt2(inputData, tmpInterCondTab, tmpInterCondNbr,
						  aInterCondTab, aInterCondNbr, FALSE);
		/* Sort records like stored proc. */
		if ((*aInterCondNbr) > 1)
		TLS_Sort((char *) (*aInterCondTab), (*aInterCondNbr), sizeof(DBA_DYNFLD_STP),
			 (TLS_CMPFCT *)DBA_InterCondInstrIdByIdDtCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
	}

	return(RET_SUCCEED);
    }
}

/************************************************************************
*   Function             : DBA_SelectExchEvt()
*
*   Description          : Select valid exchange events in instrument (Euro conversion)
*                          and exchange event table.
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                          tillDateTime till date
*                          valDateTime  validity date
*                          exchTab      pointer on issue or redemption table
*                                       which will be allocated and updated
*                          exchNbr      pointer on issue or redemption number
*                                       which will be updated
*
*   Return               : RET_SUCCEED if no error
*
**  Creation             :   REF1132 - 980309 - DDV
**  Last modif.          :
**
*************************************************************************/
RET_CODE DBA_SelectExchEvt(DBA_DYNFLD_STP instrPtr,
			  DATETIME_T     fromDateTime,
			  DATETIME_T     tillDateTime,
			  DATETIME_T     valDateTime,
			  DBA_DYNFLD_STP **exchTab,
			  int            *exchNbr,
              DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE      ret=RET_SUCCEED;
        DBA_DYNFLD_STP  ask=NULLDYNST;

	*exchNbr = 0;

        if ((EXCHCD_ENUM) GET_ENUM(instrPtr, A_Instr_ExchangeCdEn) == ExchCd_Exist)
        {
        	if ((ask = ALLOC_DYNST(Evt_Arg)) == NULLDYNST)
                	MSG_RETURN(RET_MEM_ERR_ALLOC);

		/* Select all exchange event from echange event table */
		/* REF4522 - SSO - 000405 - handle generic instr case */
		if (GET_ID(instrPtr, A_Instr_Id) < 0)
		{
			SET_ID(ask,   Evt_Arg_InstrId,   GET_ID(instrPtr, A_Instr_ParentInstrId));
		}
		else
		{
			SET_ID(ask,   Evt_Arg_InstrId,   GET_ID(instrPtr, A_Instr_Id));
		}
        	SET_DATE(ask, Evt_Arg_BegDate,   fromDateTime.date);
        	SET_DATE(ask, Evt_Arg_EndDate,   tillDateTime.date);
        	SET_DATE(ask, Evt_Arg_ValidDate, valDateTime.date);

        	ret = DBA_Select2(ExchEvt, UNUSED, Evt_Arg, ask, A_ExchEvt, exchTab,
                                  UNUSED, UNUSED, exchNbr, UNUSED, UNUSED);
        	FREE_DYNST(ask, Evt_Arg);
	}

	/* If informations in intrument add one exchange event in array */
	if (IS_NULLFLD(instrPtr, A_Instr_NewEuroInstrId) == FALSE &&
            IS_NULLFLD(instrPtr, A_Instr_EuroConvDate) == FALSE &&
	    DATETIME_CMP(fromDateTime, GET_DATETIME(instrPtr, A_Instr_EuroConvDate)) <= 0 && /* REF1906 - DDV - 980427 */
	    DATETIME_CMP(tillDateTime, GET_DATETIME(instrPtr, A_Instr_EuroConvDate)) > 0 /* REF1906 - DDV - 980427 */
            )
	{
		DBA_DYNFLD_STP instrExchEvt=NULLDYNST, newInstrPtr=NULLDYNST;
		int            crt;
                FLAG_T         allocOk = FALSE;

		crt    = *exchNbr;
		(*exchNbr) += 1;

		if (((*exchTab) = (DBA_DYNFLD_STP *) REALLOC((*exchTab),
			          (*exchNbr) * sizeof(DBA_DYNFLD_STP)))
			          == (DBA_DYNFLD_STP*)NULL)
		{
			DBA_FreeDynStTab(*exchTab, (*exchNbr)-1, A_ExchEvt);
    			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

	    	if (((*exchTab)[crt] = ALLOC_DYNST(A_ExchEvt)) == NULLDYNST)
	    	{
			DBA_FreeDynStTab(*exchTab, *exchNbr, A_ExchEvt);
    			MSG_RETURN(RET_MEM_ERR_ALLOC);
	    	}

		instrExchEvt = (*exchTab)[crt];

		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_InstrId,
		            instrPtr,           A_Instr,         A_Instr_Id);
		SET_NULL_DATE(instrExchEvt,     A_ExchEvt_ValidDate);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt, A_ExchEvt_BeginDate,
		            instrPtr,           A_Instr,         A_Instr_EuroConvDate);
		SET_SMALLINT(instrExchEvt,      A_ExchEvt_Priority, 1);
		SET_ENUM(instrExchEvt,          A_ExchEvt_NatEn, ExchNat_Conv);
		SET_NULL_CODE(instrExchEvt,     A_ExchEvt_Cd);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_NewInstrId,
		            instrPtr,           A_Instr,         A_Instr_NewEuroInstrId);

		/* REF1906 - DDV - 980429 - ExchEvt_CurrId must be newinstr reference currency */
        /* REF3913 - 991004 - DDV */
        if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_NewEuroInstrId), FALSE, &allocOk,
                                    &newInstrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
	    {
		    return(ret);
		}

		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_CurrId,
		            newInstrPtr,        A_Instr,         A_Instr_RefCurrId);

		if (allocOk == TRUE) {FREE_DYNST(newInstrPtr, A_Instr);}


		SET_NULL_ID(instrExchEvt,	  A_ExchEvt_ExclusiveId);
		SET_NULL_NUMBER(instrExchEvt, A_ExchEvt_RefQty);
		SET_FLAG(instrExchEvt,          A_ExchEvt_DeliveryFlg, FALSE);
		SET_FLAG(instrExchEvt,          A_ExchEvt_ReplaceFlg,  TRUE);
                SET_NUMBER(instrExchEvt,        A_ExchEvt_NewInstrQty,1.0); /* REF1906 - DDV - 980427 */
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_EndDate,
		            instrPtr,           A_Instr,         A_Instr_EuroConvDate);
                SET_NULL_PRICE(instrExchEvt,   A_ExchEvt_Price);
                SET_NULL_NUMBER(instrExchEvt,   A_ExchEvt_Quote);
		SET_NULL_TINYINT(instrExchEvt,  A_ExchEvt_SettleDays);
		SET_NULL_DATE(instrExchEvt,     A_ExchEvt_EndValidDate);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_EuroConvRuleEn,
		            instrPtr,           A_Instr,         A_Instr_EuroConvRuleEn);
		SET_ENUM(instrExchEvt,          A_ExchEvt_RoundRuleEn, RndRule_None);
		SET_ENUM(instrExchEvt,          A_ExchEvt_OddLotCompEn, 0);
		SET_ENUM(instrExchEvt,          A_ExchEvt_RoundLevelEn, 0);
		SET_NULL_NUMBER(instrExchEvt,   A_ExchEvt_NewInstrMinDenom);
		SET_NULL_EXCHANGE(instrExchEvt, A_ExchEvt_FixedExchRate);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_InstrNatEn,
		            instrPtr,           A_Instr,         A_Instr_NatEn);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,		 A_ExchEvt_InstrTypeId,
		            instrPtr,           A_Instr,         A_Instr_TypeId);
		COPY_DYNFLD(instrExchEvt,       A_ExchEvt,       A_ExchEvt_InstrSubTpId,
		            instrPtr,           A_Instr,         A_Instr_SubTpId);

                /* REF1132 - DDV - 980312 - Sort all exchange event by validity date */
                TLS_Sort((char *) (*exchTab), *exchNbr, sizeof(DBA_DYNFLD_STP),
                         (TLS_CMPFCT *)CMP_ExchEvtByDt, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
	        ret = RET_SUCCEED;
	}

	if (ret != RET_SUCCEED)
	{
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectExchEvt",
		             GET_CODE(instrPtr, A_Instr_Cd), "exchange event");
	}
	return(ret);
}


/************************************************************************
*
*  Function     : DBA_GetInstrById()
*
*  Description  : Get instrument in hierarchy, if not found call database.
*
*  Arguments    : instrId         Id of instrument to load
*                 addInstrInHier  Flag to indicate if new intrument must be add in hierachy
*	          allocFlg        Flag to determine if the return intrument was allocated or not
*		  instrPtr        Pointer to instrument to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF3913    - DDV - 990819
**                PMSTA10131 - EFE   111011
*
*************************************************************************/
EXTERN RET_CODE DBA_GetInstrById(ID_T                   instrId,
                                 FLAG_T                 addInstrInHierFlg,
                                 FLAG_T                *allocFlg,
                                 DBA_DYNFLD_STP        *instrPtr,
                                 DBA_HIER_HEAD_STP      hierHeadParam,
                                 int                    getOptions,
                                 int                   *allocConn)
{
	DBA_DYNFLD_STP      getInstr    = NULLDYNST;
    DBA_HIER_HEAD_STP   hierHead;
	RET_CODE			ret_get; /* PMSTA10131-EFE-111011*/

	if (instrPtr == NULLDYNSTPTR || allocFlg == (FLAG_T *) NULL || instrId == ZERO_ID)
	{
            	return(RET_GEN_ERR_INVARG);
	}

    *allocFlg = FALSE;
	*instrPtr = NULLDYNST;

    if (hierHeadParam !=  NULL)
    {
        hierHead = hierHeadParam;
    }
    else
    {
        hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
    }

    if (hierHead != (DBA_HIER_HEAD_STP) NULL)
    {
        if (DBA_GetRecPtrFromHierById(hierHead,
                                      instrId,
                                      A_Instr,
                                      instrPtr) == RET_SUCCEED &&
            *instrPtr != NULLDYNST)
        {
            return(RET_SUCCEED);
        }
    }

	if (instrId <= (ID_T)0)
    {
        return(RET_DBA_ERR_NODATA);
    }

	if ((getInstr = ALLOC_DYNST(S_Instr))==NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	if (((*instrPtr) = ALLOC_DYNST(A_Instr))==NULLDYNST)
	{
		FREE_DYNST(getInstr, S_Instr);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
    *allocFlg = TRUE;

	SET_ID(getInstr,S_Instr_Id, instrId);
	ret_get = DBA_Get2(Instr,
                 UNUSED,
                 S_Instr,
                 getInstr,
                 A_Instr,
                 instrPtr,
	  	         getOptions,
                 allocConn) ;
	/*<PMSTA10131-EFE-111011*/
	if ( ret_get == RET_DBA_INFO_NODATA || ret_get ==  RET_DBA_INFO_NODATAWITHOPTI)
	{
		FREE_DYNST((*instrPtr), A_Instr);
        *allocFlg = FALSE;
		FREE_DYNST(getInstr, S_Instr);
		return(ret_get);
	}/*>PMSTA10131-EFE-111011*/
	else if ( ret_get != RET_SUCCEED )
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
		FREE_DYNST((*instrPtr), A_Instr);
        *allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(getInstr, S_Instr_Id));
		FREE_DYNST(getInstr, S_Instr);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getInstr, S_Instr);

    if (addInstrInHierFlg == TRUE &&
        hierHead != (DBA_HIER_HEAD_STP) NULL)
    {
        if (DBA_AddHierRecord(hierHead,
		       	              *instrPtr,
                              A_Instr,
                              TRUE,
		                      HierAddRec_ForceInsert) == RET_SUCCEED)
        {
            *allocFlg = FALSE;
        }
    }

	return(RET_SUCCEED);
}


/************************************************************************
*
*  Function     : DBA_GetDefOption()
*
*  Description  : Get an instrument
*
*  Arguments    : instrNature           The nature of the query instrument
*                 instrCurrencyId       The currency's id of the query instrument
*                 underlyInstrCurrId    The currency's id of the underly instrument
*                 instrPtr              The result-> the instrument's pointer.
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : DEV1055 - CSA - 15121999
*
*************************************************************************/
EXTERN RET_CODE DBA_GetDefOption(       ENUM_T                  instrNature,
                                        ID_T                    instrCurrencyId,
                                        ID_T                    underlyInstrCurrId,
                                        DBA_DYNFLD_STP          *instrPtr)
{
        /*************************************
        ***  Local variables declarations  ***
        *************************************/
        RET_CODE        ret = RET_SUCCEED;


        /*********************************************
        ***  Memory allocation for the instrument  ***
        *********************************************/
        *instrPtr = ALLOC_DYNST(A_Instr);
        if      ((*instrPtr)==NULLDYNST)
                ret = RET_MEM_ERR_ALLOC;


        /********************************
        ***  Set values for the Get2  ***
        ********************************/
        if      (ret == RET_SUCCEED)
        {
                SET_ENUM((*instrPtr), A_Instr_NatEn, instrNature);
                SET_ID((*instrPtr), A_Instr_RefCurrId, instrCurrencyId);
                SET_ID((*instrPtr), A_Instr_LastCurrId, underlyInstrCurrId);
        }


        /************************************
        *** Call to the stored procedure  ***
        ************************************/
        if      (ret == RET_SUCCEED)
        {
                ret = DBA_Get2( Instr,
                                UNUSED,
                                A_Instr,
                                *instrPtr,
                                A_Instr,
                                instrPtr,
                                UNUSED,
                                UNUSED,
                                UNUSED);
        }


        /****************************
        ***  Free the instrument  ***
        ****************************/
        if      (ret!=RET_SUCCEED)
                FREE(*instrPtr);


        /*********************
        ***  Return value  ***
        *********************/
        return(ret);
}

/************************************************************************
**
**  Function    :   DBA_VerifInstrInHier()
**
**  Description :   Check if instrument already exist in hierarchy,
**		    in that case suppress it from array and if it is received
*		    his InstrPrice, InstrChrono, InterCond.
**
**  Arguments   :   hierHeadPtr		hierarchy header pointer
**                  instrTab		instrument array
**		    instrNbr		instrument number
**                  instrChronoTab	instr chrono array
**		    instrChronoNbr	instr chrono number
**                  instrPriceTab	instr price array
**		    instrPriceNbr	instr price number
**                  interCondTab	inter cond array
**		    interCondNbr	inter cond number
**
**  Return      :   RET_SUCCEED if forward must be create,
**		    RET_DBA_INFO_EXIST if forward already exist
**		    or error code
**
*************************************************************************/
EXTERN RET_CODE DBA_VerifInstrInHier(DBA_HIER_HEAD_STP hierHead,
				     DBA_DYNFLD_STP **instrTabInput, int *instrNbrInput, 
				     DBA_DYNFLD_STP **instrChronoTabInput, int *instrChronoNbrInput,
				     DBA_DYNFLD_STP **instrPriceTabInput, int *instrPriceNbrInput,
				     DBA_DYNFLD_STP **interCondTabInput, int *interCondNbrInput)
{
    int		    i, hierInstrNbr=0, instrChronoIdx=0, instrPriceIdx=0, interCondIdx=0,
		    instrFreeNbr=0, instrChronoFreeNbr=0, instrPriceFreeNbr=0, interCondFreeNbr=0;
    DBA_DYNFLD_STP  instrPtr=NULLDYNST;
    DBA_DYNFLD_STP *instrTab=NULLDYNSTPTR, *instrChronoTab=NULLDYNSTPTR,
                   *instrPriceTab=NULLDYNSTPTR, *interCondTab=NULLDYNSTPTR;
    int            instrNbr=0, instrChronoNbr=0, instrPriceNbr=0, interCondNbr=0;
    RET_CODE	    ret;

    if (instrTabInput != NULL)
        instrTab=*instrTabInput;

    if (instrNbrInput != NULL)
        instrNbr=*instrNbrInput;

    if (instrChronoTabInput != NULL)
        instrChronoTab=*instrChronoTabInput;

    if (instrChronoNbrInput != NULL)
        instrChronoNbr=*instrChronoNbrInput;

    if (instrPriceTabInput != NULL)
        instrPriceTab=*instrPriceTabInput;

    if (instrPriceNbrInput != NULL)
        instrPriceNbr=*instrPriceNbrInput;

    if (interCondTabInput != NULL)
        interCondTab=*interCondTabInput;

    if (interCondNbrInput != NULL)
        interCondNbr=*interCondNbrInput;



    if (instrNbr <= 0 || instrTab == NULLDYNSTPTR)
    {
	return(RET_SUCCEED);	/* nothing to do ... */
    }

    ret = DBA_HierGetRecNbr(hierHead, A_Instr, NULLFCT, &hierInstrNbr, FALSE);
    if (ret != RET_SUCCEED || hierInstrNbr == 0)
    {
	/* error or no one instrument in hierarchy */
	return(ret);
    }

    /* Sort all array by instrument identifier ... */
    TLS_Sort((char*) instrTab, instrNbr, sizeof(DBA_DYNFLD_STP),
	     (TLS_CMPFCT *)DBA_CmpInstrInstrId, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    if (instrChronoTab != NULLDYNSTPTR && instrChronoNbr > 0)
	TLS_Sort((char*) instrChronoTab, instrChronoNbr, sizeof(DBA_DYNFLD_STP),
	         (TLS_CMPFCT *)DBA_CmpInstrChronoInstrId, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    if (instrPriceTab != NULLDYNSTPTR && instrPriceNbr > 0)
	TLS_Sort((char*) instrPriceTab, instrPriceNbr, sizeof(DBA_DYNFLD_STP),
	         (TLS_CMPFCT *)DBA_CmpInstrPriceInstrId, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    if (interCondTab != NULLDYNSTPTR && interCondNbr > 0)
	TLS_Sort((char*) interCondTab, interCondNbr, sizeof(DBA_DYNFLD_STP),
	         (TLS_CMPFCT *)DBA_CmpInterCondInstrId, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    for (i=0; i<instrNbr; i++)
    {
	/* Search instrument in hierarchy ... */
	instrPtr = NULLDYNST;
	instrPtr = DBA_SearchHierRecById(hierHead, A_Instr,
				         A_Instr_Id, GET_ID(instrTab[i], A_Instr_Id));

	/* If instrument is already in hierarchy */
	if (instrPtr != NULLDYNST)
	{
	    if (instrChronoTab != NULLDYNSTPTR && instrChronoNbr > 0)
	    {
		while(instrChronoIdx < instrChronoNbr &&
		      GET_ID(instrChronoTab[instrChronoIdx], A_InstrChrono_InstrId) <=
		      GET_ID(instrTab[i], A_Instr_Id))
		{
		    if (GET_ID(instrChronoTab[instrChronoIdx], A_InstrChrono_InstrId) ==
		        GET_ID(instrTab[i], A_Instr_Id))
		    {
			FREE_DYNST(instrChronoTab[instrChronoIdx], A_InstrChrono);
			instrChronoFreeNbr++;
		    }
		    instrChronoIdx++;
		}
	    }

	    if (instrPriceTab != NULLDYNSTPTR && instrPriceNbr > 0)
	    {
		while(instrPriceIdx < instrPriceNbr &&
		      GET_ID(instrPriceTab[instrPriceIdx], A_InstrPrice_InstrId) <=
		      GET_ID(instrTab[i], A_Instr_Id))
		{
		    if (GET_ID(instrPriceTab[instrPriceIdx], A_InstrPrice_InstrId) ==
		        GET_ID(instrTab[i], A_Instr_Id))
		    {
			FREE_DYNST(instrPriceTab[instrPriceIdx], A_InstrPrice);
			instrPriceFreeNbr++;
		    }
		    instrPriceIdx++;
		}
	    }

	    if (interCondTab != NULLDYNSTPTR && interCondNbr > 0)
	    {
		while(interCondIdx < interCondNbr &&
		      GET_ID(interCondTab[interCondIdx], A_InterCond_InstrId) <=
		      GET_ID(instrTab[i], A_Instr_Id))
		{
		    if (GET_ID(interCondTab[interCondIdx], A_InterCond_InstrId) ==
		        GET_ID(instrTab[i], A_Instr_Id))
		    {
			FREE_DYNST(interCondTab[interCondIdx], A_InterCond);
			interCondFreeNbr++;
		    }
		    interCondIdx++;
		}
	    }

	    FREE_DYNST(instrTab[i], A_Instr);
	    instrFreeNbr++;
	}
    }

    /* So we don't read all array for see that all record */
    /* are already free and won't be add in hierarchy     */
    if (instrTab != NULLDYNSTPTR && instrFreeNbr == instrNbr)
    {
	FREE((*instrTabInput));
	(*instrNbrInput) = 0;
    }

    if (instrChronoTab != NULLDYNSTPTR && instrChronoFreeNbr == instrChronoNbr)
    {
	FREE((*instrChronoTabInput));
	(*instrChronoNbrInput) = 0;
    }

    if (instrPriceTab != NULLDYNSTPTR && instrPriceFreeNbr == instrPriceNbr)
    {
	FREE((*instrPriceTabInput));
	(*instrPriceNbrInput) = 0;
    }

    if (interCondTab != NULLDYNSTPTR && interCondFreeNbr == interCondNbr)
    {
	FREE((*interCondTabInput));
	(*interCondNbrInput) = 0;
    }

    return(RET_SUCCEED);
}

STATIC int DBA_CmpInstrInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_Instr_Id) , GET_ID((*ptr2), A_Instr_Id))); /* DLA - REF9089 - 030508 */
}

STATIC int DBA_CmpInstrChronoInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_InstrChrono_InstrId) , GET_ID((*ptr2), A_InstrChrono_InstrId))); /* DLA - REF9089 - 030508 */
}

STATIC int DBA_CmpInstrPriceInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_InstrPrice_InstrId) , GET_ID((*ptr2), A_InstrPrice_InstrId))); /* DLA - REF9089 - 030508 */
}

STATIC int DBA_CmpInterCondInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_InterCond_InstrId) , GET_ID((*ptr2), A_InterCond_InstrId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**  Function             : DBA_UpdInstrFld()
**
**  Description          : Update loaded instrument, the new field
**                         A_Instr_InterCondInstrId is initialised.
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         fctLnkPtr     links state structure ( BUG515 - XDI - 970930 )
**
**  Return               : RET_SUCCEED or error code
**
**  Creation     : REF5001 - DDV - 000712
**  Modif.		 :
**
*************************************************************************/
EXTERN RET_CODE DBA_UpdInstrFld(DBA_DYNFLD_STP  *instrTab,
                                int             instrNb)
{
    int               i=0;
    ID_T              instrId=0;

    if (instrTab == NULLDYNSTPTR)
        return(RET_SUCCEED);

    for(i=0; i <instrNb; i++)
    {
        if (instrTab[i] == NULLDYNST)
            continue;

	    instrId = GET_ID(instrTab[i], A_Instr_Id);
	    if (instrId <= 0)
	    {
		    instrId = GET_ID(instrTab[i], A_Instr_ParentInstrId);
	    }

        SET_ID(instrTab[i], A_Instr_InterCondInstrId, instrId);
    }

	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_UpdInstrFld()
**
**  Description          : Update loaded instrument, the new field
**                         A_Instr_InterCondInstrId is initialised.
**                         Used only by development to check hierarchy coherence
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         fctLnkPtr     links state structure ( BUG515 - XDI - 970930 )
**
**  Return               : RET_SUCCEED or error code
**
**  Creation     : REF5001 - DDV - 000712
**  Modif.		 :
**
*************************************************************************/
EXTERN RET_CODE DBA_CheckInterCond(DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP    *instrTab=NULLDYNSTPTR, *tmpInterCondTab=NULLDYNSTPTR;
	int		          i=0, j=0, instrNb=0, tmpInterCondNbr=0;
    RET_CODE ret=RET_SUCCEED;
    DATE_FORMAT_ST format;
    char           dateStr[64];

	format.ordre = Dmy;
	strcpy(format.yearSep,  "/");
	strcpy(format.monthSep, "/");
	strcpy(format.daySep,   "/");
	format.yearFormat = 1;
	format.monthFormat = 0;

    if ((ret = DBA_ExtractHierEltRec(hierHead, A_Instr,
			 FALSE, NULL, NULL, &instrNb, &instrTab)) != RET_SUCCEED)
	{
	    return(ret);
	}

    printf("\n");
    printf("A_Instr_Id;A_Instr_ParentInstrId;A_Instr_InterCondInstrId;A_InterCond_InstrId;A_InterCond_BeginDate;A_InterCond_InstrId\n");

    for (i=0; i<instrNb;i++)
    {
        tmpInterCondNbr = 0;
        if (GET_EXTENSION_PTR(instrTab[i], A_Instr_Cond_A_Instr_Ext) != NULL &&
            (tmpInterCondTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(instrTab[i], A_Instr_Cond_A_Instr_Ext)) != NULLDYNSTPTR)
        {
            tmpInterCondNbr = (int) GET_EXTENSION_NBR(instrTab[i], A_Instr_Cond_A_Instr_Ext);
            for (j=0; j<tmpInterCondNbr; j++)
            {
                DATE_FormatToStr(dateStr, GET_DATE(tmpInterCondTab[j], A_InterCond_BeginDate), &format);
                printf("%" szFormatId";%" szFormatId";%" szFormatId";%" szFormatId";%s;%f\n", /* DLA - PMSTA08801 - 100209 */
                       GET_ID(instrTab[i], A_Instr_Id),
                       GET_ID(instrTab[i], A_Instr_ParentInstrId),
                       GET_ID(instrTab[i], A_Instr_InterCondInstrId),
                       GET_ID(tmpInterCondTab[j], A_InterCond_InstrId),
                       dateStr,
                       GET_PERCENT(tmpInterCondTab[j], A_InterCond_InterestRateP));
            }
        }

        if (tmpInterCondNbr == 0)
        {
            printf("%" szFormatId";%" szFormatId";%" szFormatId";NULL;NULL;NULL\n", /* DLA - PMSTA08801 - 100209 */
                   GET_ID(instrTab[i], A_Instr_Id),
                   GET_ID(instrTab[i], A_Instr_ParentInstrId),
                   GET_ID(instrTab[i], A_Instr_InterCondInstrId));
        }

    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function        : DBA_SelectInterCond()
*
*   Description     : Select valid interest condition between two dates
*
*   Arguments       : instrPtr     instrument pointer
*                    fromDateTime from date
*                    tillDateTime till date
*                    interTab     pointer on interest condition table
*                                 which will be allocated and updated
*                    interNbr     pointer on interest condition number
*                                 which will be updated
*
*   Return          : RET_SUCCEED if no error
*   Creation        : REF6004 - AKO - 011218 : new param for flow instrument project
*   Modification    : REF7432 - YST - 020319
*
*******************************************************************************************/
RET_CODE DBA_SelectInterCond2(  DBA_DYNFLD_STP      instrPtr,
                                DATETIME_T          fromDateTime,
                                DATETIME_T          tillDateTime,
                                DBA_DYNFLD_STP      **interTab,
                                int                 *interNbr,
                                FLAG_T	            *freeRecFlg,
                                DBA_HIER_HEAD_STP   hierHead,
                                INTERCONDNAT_ENUM   intercondNat)
{
	DBA_DYNFLD_STP      ask;
	RET_CODE            ret;
	DATE_T		        instrEndDate=BAD_DATE;	    /* REF3696 - SSO - 990518 */
	int		            i, selInterNbr=0;	    /* REF3696 - SSO - 990518 */
	DBA_DYNFLD_STP	    *selInterTab = NULL;	    /* REF3696 - SSO - 990518 */
	FLAG_T		        interCondToRemoveFlg =FALSE;/* REF3696 - SSO - 990518 */
    SUBNAT_ENUM         instrSubNatEn = SubNat_None;

	/* REF3678 - tmp */
	*freeRecFlg =  TRUE;

	*interNbr = 0;

#ifdef CHU_TEST
	/* PMSTA01459-CHU-070312 : May be an error to select all in certain circumstance */
	/* Please forgive me for this break, and check if you really need all inter cond natures ! */
	if (InterCondNat_None == intercondNat)
		SYS_BreakOnDebug();
#endif

	if ((INTERCD_ENUM)
	    GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Instr)
	{
	    *interNbr = 1;
	    if ((*interTab = (DBA_DYNFLD_STP*) CALLOC(*interNbr,
			    sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (((*interTab)[0] = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
	    {
		FREE(*interTab);
    		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_NULL_DATE((*interTab)[0],    A_InterCond_ValidDate);
	    SET_NULL_DATE((*interTab)[0], A_InterCond_BeginDate);
	    SET_NULL_CODE((*interTab)[0],    A_InterCond_Cd);
	    SET_NULL_ID((*interTab)[0],      A_InterCond_BenchInstrId);
	    SET_NULL_PERCENT((*interTab)[0], A_InterCond_MinIntP);
	    SET_NULL_PERCENT((*interTab)[0], A_InterCond_MaxIntP);
	    SET_NULL_NUMBER((*interTab)[0], A_InterCond_MultMargin);
	    SET_NULL_PERCENT((*interTab)[0], A_InterCond_AddMarginP);
	    SET_NULL_DATE((*interTab)[0],    A_InterCond_FirstResetDate);
	    SET_NULL_DATE((*interTab)[0],    A_InterCond_FirstBenchDate);
	    SET_NULL_TINYINT((*interTab)[0], A_InterCond_ResetFreq);
	    SET_NULL_ENUM((*interTab)[0],    A_InterCond_ResetFreqUnitEn);
	    SET_NULL_TINYINT((*interTab)[0], A_InterCond_CompoundFreq);
	    SET_NULL_ENUM((*interTab)[0],    A_InterCond_CompoundFreqUnitEn);

	    SET_ID((*interTab)[0], A_InterCond_InstrId,
		GET_ID(instrPtr, A_Instr_Id));

	    /* REF1055 - AKO - 991210 / REF7432 - YST - 020319 */
	    /* default Interest rate cal.Rule is floating for subnature FRN and floating legs of instrument swap */
        instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
	    if (instrSubNatEn == SubNat_FRN || instrSubNatEn == SubNat_RecSwapFloatLeg || instrSubNatEn == SubNat_PaidSwapFloatLeg)
	    {
		    SET_ENUM((*interTab)[0], A_InterCond_IntCalcRuleEn, (ENUM_T) InterCalcRule_Floating);
	    }
	    else
	    {
		    SET_ENUM((*interTab)[0], A_InterCond_IntCalcRuleEn, (ENUM_T) InterCalcRule_Fixed);
	    }

	    /* REF1055 - 990126 */
	    if (IS_NULLFLD(instrPtr, A_Instr_EndDate)==TRUE)
	    {
	    	SET_DATE((*interTab)[0], A_InterCond_EndDate, MAGIC_END_DATE);
	        SET_DATE((*interTab)[0], A_InterCond_EndValidDate, MAGIC_END_DATE);
	    }
	    else
	    {
	    	COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_EndDate,
			    instrPtr, A_Instr, A_Instr_EndDate);
	    	COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_EndValidDate,
			    instrPtr, A_Instr, A_Instr_EndDate);
	    }
	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_BenchInstrId,
			instrPtr, A_Instr, A_Instr_FloatInstrId);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_AddMarginP,
			instrPtr, A_Instr, A_Instr_AddMarginP);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_CompoundFreq,
			instrPtr, A_Instr, A_Instr_CompFreq);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_CompoundFreqUnitEn,
			instrPtr, A_Instr, A_Instr_CompFreqUnitEn);
	    /* END REF1055 - 990126 */

	    SET_PERCENT((*interTab)[0], A_InterCond_NegBalRateP,
		GET_PERCENT(instrPtr, A_Instr_InterestRateP));

	    SET_PERCENT((*interTab)[0], A_InterCond_InterestRateP,
		GET_PERCENT(instrPtr, A_Instr_InterestRateP));
		if((CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_RecSwapFloatLeg)==0)|| (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFloatLeg) == 0)|| (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFixedLeg) == 0)|| (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_RecSwapFixedLeg) == 0))
		{
			if (CMP_ENUM(GET_ENUM(instrPtr, A_Instr_MktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) != 0)
			{
				if (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_RecSwapFloatLeg) == 0)
				{
					SET_ENUM((*interTab)[0], A_InterCond_MktConvMethodEn, GET_ENUM(instrPtr, A_Instr_MktConvMethodEn));
					SET_ENUM((*interTab)[0], A_InterCond_LookbackConvEn, GET_ENUM(instrPtr, A_Instr_LookbackConvEn));
					SET_TINYINT((*interTab)[0], A_InterCond_LookbackDays, GET_TINYINT(instrPtr, A_Instr_LookbackDays));
					SET_TINYINT((*interTab)[0], A_InterCond_LockoutDays, GET_TINYINT(instrPtr, A_Instr_LockoutDays));
					SET_TINYINT((*interTab)[0], A_InterCond_SpreadInclusiveFlg, GET_TINYINT(instrPtr, A_Instr_SpreadInclusiveFlg));
				}
				else if ((CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFixedLeg) == 0) && CMP_ENUM(GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) == 0)
				{
					SET_ENUM((*interTab)[0], A_InterCond_MktConvMethodEn, GET_ENUM(instrPtr, A_Instr_MktConvMethodEn));
				}
			}
			if (CMP_ENUM(GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) != 0)
			{
				if (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFloatLeg)==0)
				{
					COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_BenchInstrId,
						instrPtr, A_Instr, A_Instr_PaidFloatInstrId);
					SET_ENUM((*interTab)[0], A_InterCond_MktConvMethodEn, GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn));
					COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_AddMarginP,
						instrPtr, A_Instr, A_Instr_Add2MarginP);
					SET_ENUM((*interTab)[0], A_InterCond_LookbackConvEn, GET_ENUM(instrPtr, A_Instr_PaidLookbackConvEn));
					SET_TINYINT((*interTab)[0], A_InterCond_LookbackDays, GET_TINYINT(instrPtr, A_Instr_PaidLookbackDays));
					SET_TINYINT((*interTab)[0], A_InterCond_LockoutDays, GET_TINYINT(instrPtr, A_Instr_PaidLockoutDays));
					SET_TINYINT((*interTab)[0], A_InterCond_SpreadInclusiveFlg, GET_TINYINT(instrPtr, A_Instr_PaidSpreadInclusiveFlg));
				}
				else if (CMP_ENUM(static_cast<ENUM_T>(instrSubNatEn), SUBNAT_ENUM::SubNat_RecSwapFixedLeg) == 0 && CMP_ENUM(GET_ENUM(instrPtr, A_Instr_MktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) == 0)
				{
					SET_ENUM((*interTab)[0], A_InterCond_MktConvMethodEn, GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn));
				}
			}
		}

	    /* DVP561 - New fields */
	    /* SET_PERCENT((*interTab)[0], A_InterCond_GrowthPrct,
		GET_PERCENT(instrPtr, A_Instr_ ?? */
	    /* SET_NUMBER((*interTab)[0], A_InterCond_AccrualFactor,
		GET_NUMBER(instrPtr, A_Instr_ ?? */

	    SET_ENUM((*interTab)[0], A_InterCond_CompConvEn,
		GET_ENUM(instrPtr, A_Instr_CompConvEn));

	    SET_FLAG((*interTab)[0], A_InterCond_AverFlg,
		GET_FLAG(instrPtr, A_Instr_AverFlg));

	    SET_TINYINT((*interTab)[0], A_InterCond_AverPeriod,
		GET_TINYINT(instrPtr, A_Instr_AverPeriod));

	    SET_ENUM((*interTab)[0], A_InterCond_AverPeriodUnitEn,
		GET_ENUM(instrPtr, A_Instr_AverPeriodUnitEn));

	    SET_FLAG((*interTab)[0], A_InterCond_BacksetFlg,
		GET_FLAG(instrPtr, A_Instr_BacksetFlg));

	    /* REF1055 - AKO - 981219 */ /* Advanced analytics */
	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_BeginDate,
		        instrPtr, A_Instr, A_Instr_BeginDate);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_ValidDate,
			instrPtr, A_Instr, A_Instr_BeginDate);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_FirstResetDate,
			instrPtr, A_Instr, A_Instr_BeginDate);

	    COPY_DYNFLD((*interTab)[0], A_InterCond, A_InterCond_FirstBenchDate,
			instrPtr, A_Instr, A_Instr_BeginDate);

        SET_ENUM((*interTab)[0], A_InterCond_NatEn, intercondNat); /* REF6004 - AKO - 011218 */

	    ret = RET_SUCCEED;
	}
	else
	{
	    if ((ask = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	    {
		    SET_ID(ask, A_InterCond_InstrId,
                    GET_ID(instrPtr, A_Instr_ParentInstrId));
	    }
	    else
	    {
                SET_ID(ask, A_InterCond_InstrId,
		    GET_ID(instrPtr, A_Instr_Id));
	    }

		SET_DATE(ask, A_InterCond_BeginDate, fromDateTime.date);
		SET_DATE(ask, A_InterCond_EndDate, tillDateTime.date);
		SET_ENUM(ask, A_InterCond_NatEn, intercondNat); /* REF5941 - YST - 020205 */

		/* PMSTA01512-CHU-070427 : Consider Fund Shares */
		if (instrPtr != NULLDYNST &&
			(INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare  &&
			((SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
			(SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
		{
			SET_DATE(ask, A_InterCond_ValidDate, fromDateTime.date);
		}

	    /* REF3678 - RAK - 990820 - Call new function ... */
	    ret = DBA_SelAllInterCond(  InterCond_ByIdDt, hierHead, instrPtr, ask,
                                     &selInterTab,
                                     &selInterNbr,
                                     freeRecFlg);
                                     /* intercondNat); */   /* REF6004 - AKO - 011221 : no more needed */

	    if (ret != RET_SUCCEED)
	    {
		    ret = RET_DBA_ERR_NODATA;
		    MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond",
		        GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
	    }
	    else
	    {
		    /* REF3696 - SSO - 990518: remove inter cond which are running after instr end date */

		    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&
		        GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
		    {
		        instrEndDate = GET_DATE(instrPtr, A_Instr_EndDate);
		    }
		    else
		    {
		        instrEndDate = MAGIC_END_DATE;
		    }

		    /* look if at least one must be removed (avoid copy of the whole array) */
		    interCondToRemoveFlg = FALSE;
		    for (i=0; i<selInterNbr ; i++)
		    {
			/*PMSTA-21692 - SHR - 152411 - Ignoring inter_calc_rule_e = range_accrual*/
			if (GET_DATE(selInterTab[i], A_InterCond_BeginDate) > instrEndDate) /* PMSTA-36699  - Silpakal - 191121  */
		        {
			        interCondToRemoveFlg = TRUE;
		        }
		    }

		    if (interCondToRemoveFlg == TRUE)
		    {
		        if ((*interTab = (DBA_DYNFLD_STP*) CALLOC(selInterNbr,
				        sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
		        {
			        FREE_DYNST(ask, A_InterCond);
			        DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
    			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

		        *interNbr = 0;
		        for (i=0; i< selInterNbr; i++)
		        {
				/*PMSTA-21692 - SHR - 152411 - Ignoring inter_calc_rule_e = range_accrual*/
				if (GET_DATE(selInterTab[i], A_InterCond_BeginDate) > instrEndDate)  /* PMSTA-36699  - Silpakal - 191121  */
			        {
			            /* must be removed */
			            if (*freeRecFlg == TRUE)	/* REF3679 - RAK - 990820 */
			            { FREE_DYNST(selInterTab[i], A_InterCond); }
			        }
			        else
			        {
			            /* keep -> copy pointer */
			            (*interTab)[*interNbr] = selInterTab[i];
			            (*interNbr)++;
			        }
			        selInterTab[i] = NULL;
		        }

		        FREE(selInterTab); /* free only array */
		    }
		    else
		    {
		        *interTab = selInterTab; /* the selected array is returned */
		        *interNbr = selInterNbr;
		    }

		    ret = RET_SUCCEED;
	    }

	    FREE_DYNST(ask, A_InterCond);
	}

	return(ret);
}

/************************************************************************
*   Function        : DBA_UpdInterCondGenerInstr()
*
*   Description     : Select valid interest condition between two dates,
*                     update fields in interest condition for generic instruments
*                     and finally set extension between instrument and interest rate conditions.
*                     The rate defined in the postition is copied to the interest rate conditions:
*                     If floating condition, then additive margin is updated.
*                     If fixing condition, then interest rate is updated.
*
*                     !  waiting for response from analyst
*
*   Arguments       : fromDateTime  from date
*                     instrPtr      instrument pointer
*                     hierHead      hierarchy pointer
*                     extPosRate    rate from extended position
*
*   Return          : RET_SUCCEED if no error
*
*   Creation        : REF7251 - YST - 020501
*
*******************************************************************************************/
/*EXTERN RET_CODE DBA_UpdInterCondGenerInstr(DATETIME_T          fromDateTime,
                                    DBA_DYNFLD_STP      instrPtr,
                                    PTR                 hierHead,
                                    PERCENT_T           extPosRate)
{
	DBA_DYNFLD_STP      ask;
	RET_CODE            ret;
	int		            i=0, interCondNbr=0;
	DBA_DYNFLD_STP	    *interCond = NULL;
    FLAG_T              freeRecFlg = FALSE;


	if ((ask = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
    	MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
	{
		SET_ID(ask, A_InterCond_InstrId,
                GET_ID(instrPtr, A_Instr_ParentInstrId));
	}
	else
	{
            SET_ID(ask, A_InterCond_InstrId,
		GET_ID(instrPtr, A_Instr_Id));
	}

    SET_DATE(ask, A_InterCond_BegDate, fromDateTime.date);
    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE && GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
	{
		SET_DATE(ask, A_InterCond_EndDate, GET_DATE(instrPtr, A_Instr_EndDate));
	}
	else
	{
		SET_DATE(ask, A_InterCond_EndDate, MAGIC_END_DATE);
	}
    SET_ENUM(ask, A_InterCond_NatEn, GET_ENUM(instrPtr, A_Instr_InterCondNatEn));

	if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, ask,
                                    &interCond, &interCondNbr, &freeRecFlg)) != RET_SUCCEED && interCondNbr > 0)
	{
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond",
		    GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
	}
	else
	{
        for (i=0; i<interCondNbr; i++)
        {
            if ((INTERCALCRULE_ENUM)GET_ENUM(interCond[i], A_InterCond_InterCalcRuleEn) == InterCalcRule_Floating)
            {
                SET_PERCENT(interCond[i], A_InterCond_AddMargPrct, extPosRate);
            }
	        else
	        {
		        SET_PERCENT(interCond[i], A_InterCond_InterRatePrct, extPosRate);
	        }
        }
        SET_EXTENSION(instrPtr, A_Instr_Cond_A_Instr_Ext, interCond, A_InterCond, (short)interCondNbr);
        if (freeRecFlg == TRUE)
		{
			for (i=0; i<interCondNbr; i++)
			{ FREE_DYNST(interCond[i], A_InterCond); }
		}
        else
		    FREE(interCond);

		ret = RET_SUCCEED;
	}

	FREE_DYNST(ask, A_InterCond);
    return(ret);
}
*/

/************************************************************************
**
**  Function    :   DBA_UpdInterCondEndDate()
**
**  Description :   Update end date and end validity date for interest conditions
**
**  Arguments       :   interCondTab  array of interest condition to update
**                      interCondNbr  number of interest condition in the array
**
**  Return          :   RET_SUCCEED
**
**  Creation date   :   PMSTA05878 - DDV - 080429
**  Modif.          :
**
*************************************************************************/
EXTERN RET_CODE DBA_UpdInterCondEndDate(DBA_DYNFLD_STP *interCondTab, int interCondNbr, DBA_DYNFLD_STP domainPtr)
{
    int	     i=0, previous=-1;

	if (interCondNbr > 1)
		TLS_Sort((char *) (interCondTab), interCondNbr, sizeof(DBA_DYNFLD_STP),
			 (TLS_CMPFCT *)DBA_InterCondInstrIdByDtNatCmp, (PTR **) NULL, SortRtnTp_None);

	for (i=0; i<interCondNbr; i++)
	{
        /* PMSTA08584 - DDV - 090820 - Remove all interest condition not valid */
        if (DBA_IsInterCondValid(interCondTab[i], domainPtr) == FALSE)
        {
            FREE_DYNST(interCondTab[i], A_InterCond);
            continue;
        }

        if (previous != -1)
        {
		    /* same instrument and Calculation rule */
		    if (CMP_DYNFLD(interCondTab[previous], interCondTab[i], A_InterCond_InstrId, A_InterCond_InstrId, IdType) == 0 &&
			    CMP_DYNFLD(interCondTab[previous], interCondTab[i], A_InterCond_NatEn, A_InterCond_NatEn, EnumType) == 0)
		    {
			    /* same begin date */
			    if (CMP_DYNFLD(interCondTab[previous], interCondTab[i], A_InterCond_BeginDate, A_InterCond_BeginDate, DateType) ==0)
			    {
				    /* if end validity date not set, update it */
				    if (IS_NULLFLD(interCondTab[i], A_InterCond_EndValidDate) == TRUE ||
					    GET_DATE(interCondTab[i], A_InterCond_EndValidDate) == MAGIC_END_DATE)
				    {
					    SET_DATE(interCondTab[i], A_InterCond_EndValidDate, GET_DATE(interCondTab[previous], A_InterCond_ValidDate));
				    }
			    }
			    else
			    {
			        /* PMSTA10461 - DDV - 110627 - Remove this code, now new function is used
				    if (IS_NULLFLD(interCondTab[i], A_InterCond_EndDate) == TRUE ||
					    GET_DATE(interCondTab[i], A_InterCond_EndDate) == MAGIC_END_DATE)
				    {
					    SET_DATE(interCondTab[i], A_InterCond_EndDate, GET_DATE(interCondTab[previous], A_InterCond_BegDate));
				    }
				    */
			    }
		    }
        }
        previous=i;
	}

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function        :   DBA_IsInterCondValid()
**
**  Description     :   Check if the interest condition is valid regarding its validitiy date
**
**  Arguments       :   interCond    interest condition to check
**                      domainPtr    the domain of the financial function
**
**  Return          :   RET_SUCCEED
**
**  Creation date   :   PMSTA08584 - DDV - 090820
**  Modif.          :
**
*************************************************************************/
STATIC FLAG_T DBA_IsInterCondValid(DBA_DYNFLD_STP interCond, DBA_DYNFLD_STP domainPtr)
{
    if (domainPtr == NULLDYNST)
        return(TRUE);

    switch(GET_DICT(domainPtr,A_Domain_FctDictId))
    {
        case DictFct_Journal:
        case DictFct_EventGeneration:
			if (CMP_DYNFLD(interCond, domainPtr, A_InterCond_ValidDate, A_Domain_CalcRefDate, DateType) > 0)
                return(FALSE);
            else
                return(TRUE);
            break;
        default:
            return(TRUE);
            break;
    }
}
/************************************************************************
**
**  Function    :   DBA_BuildValidInterCondTab()
**
**  Description :   Function used to build a array of all valid intercondittion during a period.
**                  Only valid interest condition are keeped.
**                  Interest condition covering several part of the period are duplicated.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : PMSTA10461 - DDV - 110627
**
**  Modification  : PMSTA-16674 - 120713 - PMO : Accrued interests are not computed for fixed income instruments when interest rate is defined in the interest rate condition
**
*************************************************************************/
STATIC RET_CODE	DBA_BuildValidInterCondTab( DBA_DYNFLD_STP      inputData,
                                            DBA_DYNFLD_STP      *tmpInterCondTab,
                                            int		            tmpInterCondNbr,
                                            DBA_DYNFLD_STP	    **aInterCondTab,
                                            int		            *aInterCondNbr,
                                            FLAG_T              freeFlg)
{
    int	                i=0, j=0, idx=0, prevIdx=-1;
    DATE_T              *dateTab;
    int                 dateNbr=0;
    DBA_DYNFLD_STP      *validInterCondTab=NULLDYNSTPTR;
    int		            validInterCondNbr=0;

    *aInterCondTab=NULL;
    *aInterCondNbr=0;

	if (tmpInterCondNbr <= 0)
		return(RET_SUCCEED);

    if (((validInterCondTab) = (DBA_DYNFLD_STP*)
	 CALLOC(tmpInterCondNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
	    return(RET_MEM_ERR_ALLOC);
    }

    if ((dateTab = (DATE_T *)
	 CALLOC((tmpInterCondNbr*2)+2, sizeof(DATE_T))) == NULL) /* PMSTA-10461 - LJE - 110711 */
    {
        FREE(validInterCondTab);
	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
	    return(RET_MEM_ERR_ALLOC);
    }

    /* keep only valid InterCond and buil a array of dates */
    dateTab[dateNbr] = GET_DATE(inputData, A_InterCond_BeginDate);
    dateNbr++;
    dateTab[dateNbr] = GET_DATE(inputData, A_InterCond_EndDate);
    dateNbr++;

    for (i=0, validInterCondNbr=0; i<tmpInterCondNbr; i++)
    {
	    if (GET_ID(inputData, A_InterCond_InstrId) !=
	        GET_ID(tmpInterCondTab[i], A_InterCond_InstrId))
		{
			if (freeFlg == TRUE) { FREE_DYNST(tmpInterCondTab[i], A_InterCond); }
	        continue;
		}

        /* PMSTA13086 DDV - 110111 - If end date is not given in inputData, don't check it */
	    if (IS_NULLFLD(inputData, A_InterCond_EndDate) == FALSE &&
	        GET_DATE(inputData, A_InterCond_EndDate) <
	        GET_DATE(tmpInterCondTab[i], A_InterCond_ValidDate))
		{
			if (freeFlg == TRUE) { FREE_DYNST(tmpInterCondTab[i], A_InterCond); }
	        continue;
		}

	    if (GET_DATE(inputData, A_InterCond_BeginDate) >
	        GET_DATE(tmpInterCondTab[i], A_InterCond_EndValidDate))
		{
			if (freeFlg == TRUE) { FREE_DYNST(tmpInterCondTab[i], A_InterCond); }
	        continue;
		}

		/* PMSTA16530 - DDV - 130620 - Check that validity date is before request date */
	    if (IS_NULLFLD(inputData, A_InterCond_ValidDate) == FALSE &&                        /* PMSTA-16674 - 120713 - PMO */
			GET_DATE(tmpInterCondTab[i], A_InterCond_ValidDate) >
	        GET_DATE(inputData, A_InterCond_ValidDate))
		{
			if (freeFlg == TRUE) { FREE_DYNST(tmpInterCondTab[i], A_InterCond); }
	        continue;
		}

		/* store dates in date array */
		dateTab[dateNbr] = GET_DATE(tmpInterCondTab[i], A_InterCond_BeginDate);
		dateNbr++;

		if (IS_NULLFLD(tmpInterCondTab[i], A_InterCond_EndDate) == FALSE)
		{
		    dateTab[dateNbr] = GET_DATE(tmpInterCondTab[i], A_InterCond_EndDate);
		    dateNbr++;
		}

	    /* InterCond is valid, keep it */
	    validInterCondTab[validInterCondNbr++] = tmpInterCondTab[i];
    }

    /* sort date Array */
    TLS_Sort((char *) dateTab, dateNbr, sizeof(DATE_T),
            (TLS_CMPFCT *) DBA_CmpDate, NULL, SortRtnTp_None);

    if (((*aInterCondTab) = (DBA_DYNFLD_STP*)
 	    CALLOC(dateNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
        FREE(validInterCondTab);
        FREE(dateTab);
    	MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
	    return(RET_MEM_ERR_ALLOC);
    }

	/* Sort records like stored proc. */
	if (validInterCondNbr > 1)
	TLS_Sort((char *) validInterCondTab, validInterCondNbr, sizeof(DBA_DYNFLD_STP),
		 (TLS_CMPFCT *)DBA_InterCondBegDValDCmp, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    /* Build new InterCond array */
    for (i=0; i<dateNbr-1; i++)
    {
        for (idx=-1, j=0; j<validInterCondNbr && GET_DATE(validInterCondTab[j], A_InterCond_BeginDate) <= dateTab[i]; j++)
        {
            /*  FPL-PMSTA12727-111011 copy this part of code from DBA_SelAllInterCondIdDt2 to filter earlier the
                inter cond. Necessary because we change how we search periods of inter cond */
            if (IS_NULLFLD(inputData, A_InterCond_NatEn) == FALSE)
            {
                if (GET_ENUM(inputData,A_InterCond_NatEn) != InterCondNat_None)
                {
	                if (GET_ENUM(inputData, A_InterCond_NatEn) !=
	                    GET_ENUM(validInterCondTab[j], A_InterCond_NatEn))
			        {
				        continue;
			        }
                }
            }

            if ((GET_DATE(validInterCondTab[j], A_InterCond_EndDate) > dateTab[i] ||
                 IS_NULLFLD(validInterCondTab[j], A_InterCond_EndDate) == TRUE)
                &&
                (idx == -1 ||
                 GET_DATE(validInterCondTab[j], A_InterCond_BeginDate) > GET_DATE(validInterCondTab[idx], A_InterCond_BeginDate) ||
                 GET_DATE(validInterCondTab[j], A_InterCond_ValidDate) > GET_DATE(validInterCondTab[idx], A_InterCond_ValidDate)))
            {
                idx=j;
            }
        }

        if (idx != -1)
        {
            if (idx != prevIdx)
            {
                (*aInterCondTab)[(*aInterCondNbr)]=ALLOC_DYNST(A_InterCond);
                COPY_DYNST((*aInterCondTab)[(*aInterCondNbr)], validInterCondTab[idx], A_InterCond);
                SET_DATE((*aInterCondTab)[(*aInterCondNbr)], A_InterCond_BeginDate, dateTab[i]);
                SET_DATE((*aInterCondTab)[(*aInterCondNbr)], A_InterCond_EndDate, dateTab[i+1]);
                (*aInterCondNbr)++;
	        }
	        else
	        {
                SET_DATE((*aInterCondTab)[(*aInterCondNbr)-1], A_InterCond_EndDate, dateTab[i+1]);
            }
            prevIdx=idx;
        }
    }
	/* PMSTA-18431 - SHR - 140722 - Code report from PMSTA - 18325*/
    if (freeFlg == TRUE)
    {
        DBA_FreeDynStTab(validInterCondTab, validInterCondNbr, A_InterCond);
    }
    else
    {
		FREE(validInterCondTab); /* PMSTA15548 - DDV - 121129 - Purify */
	}

	FREE(dateTab); /* PMSTA15548 - DDV - 121129 - Purify */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CmpDate()
**
**  Description :   Sort dates
**
**  Arguments   :   ptr1   pointer on date
**                  ptr2   pointer on date
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
EXTERN int DBA_CmpDate(DATE_T *ptr1, DATE_T *ptr2)
{
    return(DATE_Cmp(*ptr1, *ptr2));
}

/************************************************************************
**
**  Function        :   DBA_InterCondBegDValDCmp()
**
**  Description     :   Index InterCond array by being_d validity_d
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   PMSTA10461 - DDV - 110627
**  Modif.          :
**
*************************************************************************/
STATIC int DBA_InterCondBegDValDCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    /* Sort using these criterias: */
    /* A_InterCond_BegDate         ascending.  */
    /* A_InterCond_ValidDate         ascending.  */

    int	diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, A_InterCond_BeginDate, A_InterCond_BeginDate, DateType);

    if (diff == 0)
        diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, A_InterCond_ValidDate, A_InterCond_ValidDate, DateType);

    return(diff);
}

/************************************************************************
*
*  Function     : DBA_GetLinkedInstrForPE()
*
*  Description  : To fetch a different PE sub nature instrument for a given instrument,
*                          use common ref, parent instr id  links.
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     :  NRAO
*
*************************************************************************/
EXTERN RET_CODE DBA_GetLinkedInstrForPE(DBA_HIER_HEAD_STP hierHeadPtr,
										DBA_DYNFLD_STP    instrPtr,
										DBA_DYNFLD_STP    *linkedInstrPtr,
										FLAG_T            *freeInstrFlg,
										SUBNAT_ENUM       reqdFSSubNatEn)

{
	DBA_DYNFLD_STP      getInstr = NULLDYNST, workingInstr = NULLDYNST;
	RET_CODE			ret = RET_SUCCEED;
	FLAG_T              foundLinkedInstr = FALSE;
	DBA_DYNFLD_STP      *linkedInstrTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP      parentInstrPtr = NULLDYNST;
	int		            linkedInstrNbr = 0;

	*linkedInstrPtr = NULLDYNST;
	const SUBNAT_ENUM   instrSubNatEn = static_cast<SUBNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_SubNatEn));

	if (DBA_IsPEFundShare(instrPtr, SubNat_None) == FALSE)
		return(RET_GEN_ERR_NOACTION);


    if (instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown ||
        instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall ||
        instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity)
    {
        if (GET_EXTENSION_PTR(instrPtr, A_Instr_ParentInstr_Ext) != NULL &&
            (parentInstrPtr = *(GET_EXTENSION_PTR(instrPtr, A_Instr_ParentInstr_Ext))) != NULLDYNST)
        {
            if ((SUBNAT_ENUM)GET_ENUM(parentInstrPtr, A_Instr_SubNatEn) == reqdFSSubNatEn &&
                (CMP_DYNFLD(parentInstrPtr, instrPtr, A_Instr_CommonRef, A_Instr_CommonRef, InfoType) == 0)) /*PMSTA-37628 - AIS - 191029*/
            {
                *linkedInstrPtr = parentInstrPtr;
                foundLinkedInstr = TRUE;
            }
            else
            {
                workingInstr = parentInstrPtr;
            }
        }
    }
    else if (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment)
    {
        workingInstr = instrPtr;
    }

    if (workingInstr != NULLDYNST &&
        GET_EXTENSION_PTR(workingInstr, A_Instr_ChildInstr_Ext) != NULL &&
        (linkedInstrTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(workingInstr, A_Instr_ChildInstr_Ext)) != NULLDYNSTPTR)
    {
        int j = 0;
        linkedInstrNbr = (int)GET_EXTENSION_NBR(workingInstr, A_Instr_ChildInstr_Ext);
        for (j = 0; j < linkedInstrNbr; j++)
        {
            if ((SUBNAT_ENUM)GET_ENUM(linkedInstrTab[j], A_Instr_SubNatEn) == reqdFSSubNatEn &&
                (CMP_DYNFLD(linkedInstrTab[j], workingInstr, A_Instr_CommonRef, A_Instr_CommonRef, InfoType) == 0)) /*PMSTA-37628 - AIS - 191029*/
            {
                *linkedInstrPtr = linkedInstrTab[j];
                foundLinkedInstr = TRUE;
                break;
            }
        }
    }

	/* get the linked instrument using parentInstrId & common ref from db*/
	if (foundLinkedInstr == FALSE)
	{
		DBA_DYNST_ENUM instrDynEn = NullDynSt;
		if (((*linkedInstrPtr) = ALLOC_DYNST(A_Instr)) == NULLDYNSTPTR)
		{
			FREE_DYNST(getInstr, A_Instr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		*freeInstrFlg = TRUE;

		if (reqdFSSubNatEn == SubNat_PEInitialCommitment)
		{
			if ((getInstr = ALLOC_DYNST(S_Instr)) == NULLDYNST)
			{
				FREE_DYNST((*linkedInstrPtr), A_Instr);
				*freeInstrFlg = FALSE;
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}
			instrDynEn = S_Instr;
			SET_ID(getInstr, S_Instr_Id, GET_ID(instrPtr, A_Instr_ParentInstrId));
		}
		else
		{
			if ((getInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
			{
				FREE_DYNST((*linkedInstrPtr), A_Instr);
				*freeInstrFlg = FALSE;
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			instrDynEn = A_Instr;

			if (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment)
			{
				SET_ID(getInstr, A_Instr_ParentInstrId, GET_ID(instrPtr, A_Instr_Id));
			}
			else
			{
				SET_ID(getInstr, A_Instr_ParentInstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
			}

			SET_INFO(getInstr, A_Instr_CommonRef, GET_INFO(instrPtr, A_Instr_CommonRef)); /*PMSTA-37628 - AIS - 191029*/
			SET_ENUM(getInstr, A_Instr_SubNatEn, (ENUM_T)reqdFSSubNatEn);
		}

		if (instrDynEn != NullDynSt)
		{
			if ((ret = DBA_Get2(Instr,
								UNUSED,
								instrDynEn,
								getInstr,
								A_Instr,
								linkedInstrPtr,
								UNUSED,
								UNUSED,
								UNUSED)) != RET_SUCCEED)
			{
				FREE_DYNST((*linkedInstrPtr), A_Instr);
				*freeInstrFlg = FALSE;
                FREE_DYNST(getInstr, instrDynEn);
				return ret;
			}
			FREE_DYNST(getInstr, instrDynEn);
		}
		else
		{
		  return(RET_DBA_ERR_NODATA);
		}
	}
	return ret;
}

/************************************************************************
*   Function             : DBA_SelectIOREvtForPEFundShare()
*
*   Description          : Select valid issue or redemption event(s) between
*                          two dates.
*
*   Arguments            : instrPtr     instrument pointer
*                          fromDateTime from date
*                         tillDateTime till date
*                          valDateTime  validity date
*                          iorTab       pointer on issue or redemption table
*                                       which will be allocated and updated
*                          iorNbr       pointer on issue or redemption number
*                                       which will be updated
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_SelectIOREvtForPEFundShare(DBA_DYNFLD_STP instrPtr,
										DATETIME_T     fromDateTime,
										DATETIME_T     tillDateTime,
										DATETIME_T     valDateTime,
										DBA_DYNFLD_STP **iorTab,
										int            *iorNbr,
										DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE      ret = RET_SUCCEED;
	*iorNbr = 0;

	if (DBA_IsPEFundShare(instrPtr, SubNat_None) == TRUE)
	{
		DBA_DYNFLD_STP    evtArgIn = NULLDYNST;

		if ((evtArgIn = ALLOC_DYNST(Evt_Arg)) == NULLDYNST)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		if (DBA_IsPEFundShare(instrPtr, SubNat_PEInitialCommitment) == FALSE)
		{
			/*Fetch the Initial Commitment instrument using parent instr & common ref to fetch the IOR events*/
			DBA_DYNFLD_STP parentInstrPtr = NULLDYNST;
			FLAG_T freeInstrFlg = FALSE;

			if ((IS_NULLFLD(instrPtr, A_Instr_ParentInstrId) == FALSE) &&
				(ret = DBA_GetLinkedInstrForPE(hierHead, instrPtr, &parentInstrPtr, &freeInstrFlg,
				                               SubNat_PEInitialCommitment)) == RET_SUCCEED && parentInstrPtr != NULLDYNST)
			{
				SET_ID(evtArgIn, Evt_Arg_InstrId,
					GET_ID(parentInstrPtr, A_Instr_Id));
			}
			else
			{
				if (freeInstrFlg == TRUE)
					FREE_DYNST(parentInstrPtr, A_Instr);

				FREE_DYNST(evtArgIn, Evt_Arg);
				return(RET_DBA_ERR_NODATA);
			}

			if (freeInstrFlg == TRUE)
				FREE_DYNST(parentInstrPtr, A_Instr);
		}
		else
		{
			SET_ID(evtArgIn, Evt_Arg_InstrId,
				GET_ID(instrPtr, A_Instr_Id));
		}

		SET_DATE(evtArgIn, Evt_Arg_BegDate, fromDateTime.date);
		SET_DATE(evtArgIn, Evt_Arg_ValidDate, valDateTime.date);

		ret = DBA_Select2(IssueEvt, UNUSED, Evt_Arg, evtArgIn, A_IssueEvt,
			              iorTab, UNUSED, UNUSED,iorNbr, UNUSED, UNUSED);

		if (ret != RET_SUCCEED)
		{
			ret = RET_DBA_ERR_NODATA;
			MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectIOREvtForPEFundShare",
				         GET_CODE(instrPtr, A_Instr_Cd), "issue or redemption event");
		}

		FREE_DYNST(evtArgIn, Evt_Arg);
	}

	return(ret);

}

/************************************************************************
*
*  Function     : DBA_GetLatestIssRedmEvent()
*
*  Description  : To fetch the Issue redemption event of the given nature ,latest to the optimal date
*
*  Arguments    :
*                  instrId
*                  optimalDate               Date for which the latest Issue Redemption event to be fetched
*	               issRedmEventNature        Nature of the Issue Redemption Event to be fetched
*		           latestIssRedmEvent        Pointer to latest Issue Redemption Event
*
*  Return       : RET_SUCCEED
*
*  Creation     :  NRAO
*
*************************************************************************/
RET_CODE DBA_GetLatestIssRedmEvent(ID_T             instrId,
								   DATETIME_T       optimalDate,
								   ENUM_T           issRedmEventNature,
								   DBA_DYNFLD_STP  *latestIssRedmEvent)
{
	RET_CODE          ret = RET_SUCCEED;
	DBA_DYNFLD_STP    admArgIn = NULLDYNST, *issRdmTab = NULLDYNSTPTR;
	DATETIME_T        latestEvtDate;
	int               i = 0, issRdmNbr = 0;
	MemoryPool        mp;

	latestEvtDate.date = SYB_BEGIN_DATE;
	latestEvtDate.time = 0;
	admArgIn = mp.allocDynst(FILEINFO, Adm_Arg);

	SET_ID(admArgIn, Adm_Arg_Id, instrId);
	SET_ENUM(admArgIn, Adm_Arg_NatEn, issRedmEventNature);

	ret = DBA_Select2(IssueEvt, UNUSED, Adm_Arg, admArgIn, A_IssueEvt, &issRdmTab,
		              UNUSED, UNUSED, &issRdmNbr, UNUSED, UNUSED);

	for (i = 0; i < issRdmNbr; i++)
	{
		if (GET_DATE(issRdmTab[i], A_IssueEvt_EndDate) <= optimalDate.date &&
			GET_DATE(issRdmTab[i], A_IssueEvt_EndDate) > latestEvtDate.date)
		{
			latestEvtDate.date = GET_DATE(issRdmTab[i], A_IssueEvt_EndDate);
			*latestIssRedmEvent = issRdmTab[i];
		}
	}
	mp.owner(issRdmTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_IsPEFundShare()
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-32106 -NRAO 180904
*************************************************************************/
int DBA_IsPEFundShare(DBA_DYNFLD_STP instrPtr, SUBNAT_ENUM subNatEn)
{
    if (instrPtr == NULLDYNST)
        return(FALSE);

	const INSTRNAT_ENUM instrNatEn = static_cast<INSTRNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_NatEn));
	const SUBNAT_ENUM   instrSubNatEn = static_cast<SUBNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_SubNatEn));

	if ((instrNatEn == INSTRNAT_ENUM::InstrNat_FundShare) &&
		((instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment) ||
		(instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown) ||
		(instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall) ||
		(instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity)))
	{
		if (subNatEn == SubNat_None)
			return (TRUE);
		else if (subNatEn == SubNat_PEInitialCommitment)
			return instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment;
		else if (subNatEn == SubNat_PEDrawdown)
			return instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown;
		else if (subNatEn == SubNat_PECapitalCall)
			return instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall;
		else if (subNatEn == SubNat_ActualPESecurity)
			return instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity;
	}
	return (FALSE);
}

/************************************************************************
*
*  Function     : DBA_GetAllLinkedInstrsForPE()
*
*  Description  : Fetch all linked instruments for a given PE instrument
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     :  NRAO
*
*************************************************************************/
EXTERN RET_CODE DBA_GetAllLinkedInstrsForPE(DBA_HIER_HEAD_STP hierHeadPtr,
											DBA_DYNFLD_STP    instrPtr,
											DBA_DYNFLD_STP    **linkedInstrTab,
											int               *linkedInstrNbr,
                                            FLAG_T            *freeLinkedInstrTab)

{
    DBA_DYNFLD_STP parentInstrPtr = NULLDYNST;
    DBA_DYNFLD_STP *tmpLinkedInstrTab = NULLDYNSTPTR;
    int            tmpLinkedInstrNbr = 0;

    *linkedInstrNbr = 0;
    *freeLinkedInstrTab = FALSE;
    const SUBNAT_ENUM   instrSubNatEn = static_cast<SUBNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_SubNatEn));

    if (DBA_IsPEFundShare(instrPtr, SubNat_None) == FALSE)
        return(RET_GEN_ERR_NOACTION);

    if (instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown ||
        instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall ||
        instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity)
    {
        if (GET_EXTENSION_PTR(instrPtr, A_Instr_ParentInstr_Ext) != NULL &&
            (parentInstrPtr = *(GET_EXTENSION_PTR(instrPtr, A_Instr_ParentInstr_Ext))) != NULLDYNST &&
            (CMP_DYNFLD(instrPtr, parentInstrPtr, A_Instr_CommonRef, A_Instr_CommonRef, InfoType) == 0)) /*PMSTA-37628 - AIS - 191029*/
        {
            if (GET_EXTENSION_PTR(parentInstrPtr, A_Instr_ChildInstr_Ext) != NULL &&
                (tmpLinkedInstrTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(parentInstrPtr, A_Instr_ChildInstr_Ext)) != NULLDYNSTPTR)
            {
                tmpLinkedInstrNbr = (int)GET_EXTENSION_NBR(parentInstrPtr, A_Instr_ChildInstr_Ext);

                if (((*linkedInstrTab) = (DBA_DYNFLD_STP *)
                    CALLOC((tmpLinkedInstrNbr+1), sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                *freeLinkedInstrTab = TRUE;

                int j = 0;
                for (j = 0; j < tmpLinkedInstrNbr; j++)
                {
                    (*linkedInstrTab)[j] = tmpLinkedInstrTab[j];
                    (*linkedInstrNbr)++;
                }

                (*linkedInstrTab)[(*linkedInstrNbr)] = parentInstrPtr;
                (*linkedInstrNbr)++;
            }

        }
    }
    else if (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment)
    {
        if (GET_EXTENSION_PTR(instrPtr, A_Instr_ChildInstr_Ext) != NULL &&
            (tmpLinkedInstrTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(instrPtr, A_Instr_ChildInstr_Ext)) != NULLDYNSTPTR)
        {
            tmpLinkedInstrNbr = (int)GET_EXTENSION_NBR(instrPtr, A_Instr_ChildInstr_Ext);

            if (tmpLinkedInstrNbr > 0)
            {
                if (((*linkedInstrTab) = (DBA_DYNFLD_STP *)
                    CALLOC((tmpLinkedInstrNbr), sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                *freeLinkedInstrTab = TRUE;
            }

            int j = 0;
            for (j = 0; j < tmpLinkedInstrNbr; j++)
            {
                (*linkedInstrTab)[j] = tmpLinkedInstrTab[j];
                (*linkedInstrNbr)++;
            }

        }
    }
	return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_PriceValidity()
**
**  Description          : fill A_InstrPrice_BegCoveredPerDate and A_InstrPrice_EndCoveredPerDate
**
**  Arguments            : inputData   : pointer on the input dynamic structure
               data		pointer on record array to insert
**                         rows         record number on array
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		 : REF3985 - SSO - 990927 Handle prices special filling
**
**  Modif            : PMSTA-34990 - CHU - 190325 : Made extern
**
*************************************************************************/
RET_CODE DBA_PriceValidity(DBA_DYNFLD_STP inputData,
                           DBA_DYNFLD_STP *data,
                           int            rows)
{
    int		    i, validity = 0;
    DATETIME_T	begDate, endDate, begValDate, endValDate, quoteDate;
    FLAG_T		onePeriodFlg = TRUE, /* load of prices is done from only one period (continuous prices) */
                periodsOverlapFlg = FALSE,
                badLoadFlg = FALSE;
    ID_T		fctDictId;


    begDate = GET_DATETIME(inputData, A_Domain_InterpFromDate);
    endDate = GET_DATETIME(inputData, A_Domain_InterpTillDate);

    GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
    begValDate.date = DATE_Move(begDate.date, (-1) * validity, Day);
    begValDate.time = 0;
    endValDate.date = DATE_Move(endDate.date, (-1) * validity, Day);
    endValDate.time = 0;

    /* look at non single period price load */
    fctDictId = GET_ID(inputData, A_Domain_FctDictId);
    if (fctDictId == DictFct_Perfo ||
        (fctDictId == DictFct_Valo && GET_ENUM(inputData, A_Domain_PLMethodEn) == PLMethod_OnLineMktValPL))	/* PMSTA13795 - DDV - 120529 - For P&L restart on Valo, price loaded at ref and from date, set validity correctly */
    {
        onePeriodFlg = FALSE;
        /* prices are loaded in 2 periods: [begValDate, begDate] U [endValDate, endDate] */

        if (DATETIME_CMP(begDate, endValDate) >= 0)
        {
            periodsOverlapFlg = TRUE; /* THE period is [begValDate, endDate]: same thing than ONE period */
        }
    }

    for (i = 0; i < rows; i++)
    {
        /* REF3985 - SSO - 991004: records can be NULL because of DBA_VerifInstrInHier */
        if (data[i] == NULL)
        {
            continue;
        }

        /* check */
        quoteDate = GET_DATETIME(data[i], A_InstrPrice_QuoteDate);
        if (DATETIME_CMP(quoteDate, begValDate) < 0
            || DATETIME_CMP(quoteDate, endDate) > 0)
        {
            /* shouldn't occur! */
            badLoadFlg = TRUE;
            /* fields are left NULL */
        }
        else
        {
            if (onePeriodFlg == TRUE || periodsOverlapFlg == TRUE)
            {
                SET_DATETIME(data[i], A_InstrPrice_BegCoveredPerDate, begValDate);
                SET_DATETIME(data[i], A_InstrPrice_EndCoveredPerDate, endDate);
            }
            else
            {
                /* must find in which period the quote is */
                if (DATETIME_CMP(quoteDate, begDate) <= 0)
                {
                    SET_DATETIME(data[i], A_InstrPrice_BegCoveredPerDate, begValDate);
                    SET_DATETIME(data[i], A_InstrPrice_EndCoveredPerDate, begDate);
                }
                else
                {/* begDate < quoteDate. Verify that endValDate <= quoteDate <= endDate */
                    if (DATETIME_CMP(quoteDate, endValDate) < 0)
                    {
                        /* shouldn't occur! */
                        badLoadFlg = TRUE;
                        /* fields are left NULL */
                    }
                    else
                    {
                        SET_DATETIME(data[i], A_InstrPrice_BegCoveredPerDate, endValDate);
                        SET_DATETIME(data[i], A_InstrPrice_EndCoveredPerDate, endDate);
                    }
                }
            }
        }
    }

    if (badLoadFlg == TRUE)
    {
        MSG_LogMesg(RET_DBA_ERR_BAD_PRICE_LOAD, 0, FILEINFO);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_SelectUnderlyingPrices()
**
**  Description          : fill A_InstrPrice_BegCoveredPerDate and A_InstrPrice_EndCoveredPerDate
**
**  Arguments            : hierhead     hierarchy pointer
**                         domainPtr    domain pointer
**                         instrPtr     instrument pointer
**                         data		    pointer on record array to insert
**                         rows         record number on array
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : PMSTA-34990 - CHU - 190325 : Select underlying prices for ACDC
**
*************************************************************************/
RET_CODE DBA_SelectUnderlyingPrices(DBA_HIER_HEAD_STP   hierHead,
                                    DBA_DYNFLD_STP      domainPtr,
                                    DBA_DYNFLD_STP      instrPtr,
									DATETIME_T          *begDatePtr,	/* PMSTA-35262 - RAK - 190708 - KroFort je pik */
									DATETIME_T			*endDatePtr)
{
    RET_CODE        ret = RET_SUCCEED;

    DBA_DYNFLD_STP  *priceTab = NULLDYNSTPTR;    
    int             priceNbr = 0;
    MemoryPool      mp;

    /* input for sel_all_instr_price_by_iid_dt :
    static DBA_PROCPARAM_ST SV_ProcParamDef_InstrPrice6[] = {
    {&Sel_Arg_Id1,                   "@instr_id",           TRUE, ProcParamType_Input,&Null_Dynfld},
    {&Sel_Arg_FromDate,              "@from_d",             TRUE, ProcParamType_Input,&Null_Dynfld},
    {&Sel_Arg_TillDate,              "@till_d",             TRUE, ProcParamType_Input,&Null_Dynfld},
    {&Sel_Arg_DistinctFlg,           "@distinct_f",         TRUE, ProcParamType_Input,&Null_Dynfld},
    {UNUSED,                    "",                        UNUSED, ProcParamType_Invalid,&Null_Dynfld}
    };
    */

    DBA_DYNFLD_STP selArgPtr = mp.allocDynst(FILEINFO, Sel_Arg);

    SET_ID(selArgPtr, Sel_Arg_Id1, GET_ID(instrPtr, A_Instr_Id));

	/* PMSTA-35262 - RAK - 190708 - KroFort je pik */
	if (begDatePtr != nullptr && endDatePtr != nullptr)
	{
		SET_DATETIME(selArgPtr, Sel_Arg_FromDate, *begDatePtr);
		SET_DATETIME(selArgPtr, Sel_Arg_TillDate, *endDatePtr);
	}
	else
	{
		SET_DATETIME(selArgPtr, Sel_Arg_FromDate, GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
		SET_DATETIME(selArgPtr, Sel_Arg_TillDate, GET_DATETIME(domainPtr, A_Domain_InterpTillDate));
	}

    SET_FLAG(selArgPtr, Sel_Arg_DistinctFlg, FALSE);

    if ((DBA_Select2(InstrPrice, UNUSED, Sel_Arg, selArgPtr,
                     A_InstrPrice, &priceTab, UNUSED, UNUSED,
                     &priceNbr, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        SYSNAME_T entSqlName;
        strcpy(entSqlName, DBA_GetDictEntitySqlName(InstrPrice));
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
            entSqlName, GET_ID(selArgPtr, Sel_Arg_Id1));	/* ROI - 000706 - REF4979 */
        return(RET_DBA_ERR_NODATA);
    }

    mp.ownerPtr(priceTab);

    DBA_PriceValidity(domainPtr, priceTab, priceNbr);

    DBA_AddHierRecordList(hierHead,
                          priceTab, priceNbr,
                          A_InstrPrice, TRUE);

    return (ret);
}

/************************************************************************
**   END  dbainstr.c                                          UNICIBLE **
*************************************************************************/

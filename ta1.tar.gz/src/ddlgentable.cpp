/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENTABLE_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H                  /* PRO-528 - 260517 - PMO */

#include   <limits.h>

#include         "unidef.h"     /* Mandatory */
#include            "gen.h"
#include    "ddlgentable.h"
#include       "ddlgenfk.h"
#include      "ddlgendbi.h"
#include "ddlgenfromfile.h"
#include           "date.h"
#include            "str.h"

#include <iomanip>

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/
extern bool           EV_UseAlternativeDataSource;

extern DdlGenCfgFile *EV_SourceCfgFile;
extern DdlGenCfgFile *EV_TargetCfgFile;

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/
/************************************************************************
**
**  Function    :   DdlGenTable::DdlGenTable()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenTable::DdlGenTable(OBJECT_ENUM        paramObjectEn,
                         TARGET_TABLE_ENUM  paramTargetTableEn,
                         DdlGenContext     &paramDdlGenContext,
                         DdlGenEntity      *paramDdlGenEntityPtr,
                         DdlGenFile        *paramFileHelper)
    : DdlGen(paramObjectEn, DdlObj_Table, paramDdlGenContext, NULL, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
    , m_bForceTempTable(false)
{
    this->bCreate           = false;
    this->bOptim            = false;
    this->bCheckIfExists    = (this->ddlGenContextPtr->bGenFromDbi && this->isIfExistsClause(DdlObj_Table) == false);
    this->attribPrintedNbr  = 0;
    this->bForceUpgrade     = false;
    this->bNewIdentity      = false;
    this->bJoinMainTable    = false;
    this->bNewTable         = false;
    this->bTableDropped     = false;
    this->removeIdentitySqlName.clear(); /* PMSTA-43103 - LJE - 210111 */
    this->fileHelperTable   = paramFileHelper;

    this->m_bForceDrop      = this->ddlGenContextPtr->bForceReBuild && 
        (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_Table ||
         this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_ReportFmt ||
         this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_SearchFmt ||
         this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_PersistedFmt);

    this->bForceDropOnly    = (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_RemoveFromTemplate);    /* PMSTA-28698 - LJE - 180531 */
    this->bForceTruncate    = (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn == DdlGenBuildRule_Truncate);
    this->bToTruncate       = false;
    this->bToDrop           = this->targetTableEn == TargetTable_Precomp ? true : false;
    this->bAlterInfoPrinted = false;
    this->m_bPrimaryKey     = false;

    init(paramObjectEn,
         DynType_All,
         this->targetTableEn == TargetTable_UserDefinedFields ? TRUE : FALSE,
         this->targetTableEn == TargetTable_Precomp ? TRUE : FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
          FALSE);

    auto dictEntityStp = this->getDictEntityStp();

    /* PMSTA-16528 - DDV - 140716 - Force to drop the table to build it with attributes order based on FmtElt's rank */
    if (dictEntityStp->entNatEn == EntityNat_SearchFmt ||
        (this->ddlGenContextPtr->bForceReBuild == true && dictEntityStp->entNatEn == EntityNat_ReportFmt))
    {

	    this->bToDrop = true;
    }
    else if (dictEntityStp->entNatEn == EntityNat_Tsl)
    {
        if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate)
        {
            this->bToDrop = true;
        }
    }
    else if (dictEntityStp->entNatEn == EntityNat_TempTable)
    {
        if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Session)
        {
            this->m_bForceDrop = true;
        }
        /* PMSTA-58084 - LJE - 240729 */
        else if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
        {
            if (this->ddlGenContextPtr->m_bDatAll)
            {
                this->m_bForceDrop = true;
            }
            this->bToDrop       = true;
        }
        else if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Type)
        {
            this->setDdlObjEn(DdlObj_Type);

            if (this->ddlGenContextPtr->m_bDatAll)
            {
                this->m_bForceDrop = true;
            }
            this->bToDrop = true;
        }
        this->bCheckIfExists = false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenTable::~DdlGenTable()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenTable::~DdlGenTable()
{
}

/************************************************************************
**
**  Function    :   DdlGenTable::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::setName()
{
    RET_CODE            ret = RET_SUCCEED;

    this->setDdlObjFullSqlName(this->getTargetDBName(), this->getEntitySqlName());
    this->setDdlObjSqlName(this->getEntitySqlName());

    this->ddlGenContextPtr->ddlObjSqlName = this->getDdlObjSqlName();
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTable::drop()
{
    RET_CODE ret = RET_SUCCEED;
    string checkExistsStr;
    string dbName = this->getTargetDBName();

    this->standardize(dbName);

    map<DdlObjDefKey, DdlObjDef>  tableDbMap;

    if (this->ddlGenContextPtr->bGenFromDbi == false &&
        this->getDictEntityStp()->entNatEn != EntityNat_TempTable)
    {
        this->getAllDdlObjListFromDb(tableDbMap,
                                     dbName,
                                     this->getDdlObjSqlName(),
                                     this->getDdlObjSqlName(),
                                     DdlObj_Table);

        if (tableDbMap.empty())
        {
            return RET_SUCCEED;
        }
    }

    this->bodySqlBlock.clear();
    this->clearIndent();

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->cmdType = DDlCmdType_Drop;
        this->bodySqlBlock
            << this->getCmdPrintMsg("Dropping table " + this->getDdlObjFullSqlName(), false) << endl;
        ret = this->flush();
    }

    if (this->getDdlObjEn() == DdlObj_Table &&
        this->ddlGenContextPtr->bGenFromDbi == false)
    {
        if (this->isFkApplied() && 
            this->isCascadeAllowed(this->getDdlObjEn()) == false)
        {
            DdlGenFK ddlGenFk(*this);
            ddlGenFk.dropByRefEntity();
        }

        if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
        {
            this->bodySqlBlock << this->getCmdIfExsists("select * from syskeys k, sysobjects o where k.id=o.id and k.type=1 and o.name='" + this->getDdlObjSqlName() + "'",
                                                        "\texec sp_dropkey primary, " + this->getDdlObjSqlName() + "\n",
                                                        string());
        }
    }

    /* PMSTA-58084 - LJE - 240729 */
    if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
    {
        this->bodySqlBlock << "drop security policy if exists " << this->getDdlObjSqlName() << "_spid";
        this->cmdType = DDlCmdType_Drop;
        (void)this->flush();

        this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                               this->getEntitySqlName(),
                                               this->getDdlObjSqlName(),
                                               this->getDdlObjEn());
        this->cmdType = DDlCmdType_Drop;
        ret = this->flush();
    }
    else if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Type)
    {
        this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                               this->getEntitySqlName(),
                                               this->getDdlObjSqlName(),
                                               this->getDdlObjEn());
        this->cmdType = DDlCmdType_Drop;
        ret = this->flush();
    }
    else
    {
        if ((this->ddlGenContextPtr->bGenFromDbi ||
             this->getDictEntityStp()->entNatEn == EntityNat_TempTable) &&
            this->isIfExistsClause(DdlObj_Table) == false)
        {
            checkExistsStr = this->getCmdSelObjInDb(dbName, this->getDdlObjSqlName(), this->getDdlObjSqlName(), this->getDdlObjEn());
        }

        this->cmdType = DDlCmdType_Drop;
        if (checkExistsStr.find("select") == 0)
        {
            this->bodySqlBlock << this->getCmdIfExsists(checkExistsStr,
                                                        "\t" + this->getDdlModif(this->getCmdDrop(
                                                            dbName,
                                                            this->getDdlObjSqlName(),
                                                            this->getDdlObjSqlName(),
                                                            this->getDdlObjEn())),
                                                        string());
        }
        else if (checkExistsStr.empty())
        {
            this->bodySqlBlock
                << this->getCmdDrop(dbName,
                                    this->getDdlObjSqlName(),
                                    this->getDdlObjSqlName(),
                                    this->getDdlObjEn());

            if (this->ddlGenContextPtr->bGenFromDbi)
            {
                this->bodySqlBlock << this->endOfCmd();
            }
        }
        else
        {
            this->bodySqlBlock << this->getCmdIfThen(checkExistsStr + "\n",
                                                     "\t" + this->getDdlModif(this->getCmdDrop(
                                                         dbName,
                                                         this->getDdlObjSqlName(),
                                                         this->getDdlObjSqlName(),
                                                         this->getDdlObjEn())));
        }
        ret = this->flush();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::dropTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTable::dropTable()
{
    this->setName();

    return this->drop();
}

/************************************************************************
**
**  Function    :   DdlGenTable::printAlteredInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32672 - LJE - 180827
**
*************************************************************************/
void DdlGenTable::printAlteredInfo()
{
    if (this->bAlterInfoPrinted == false)
    {
        if (this->newAttribVector.size() > 0)
        {
            string msg = "Add the column(s): " + this->getAlteredAttrib(this->newAttribVector);
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->dropAttribVector.size() > 0)
        {
            string msg = "Drop the column(s): " + this->getAlteredAttrib(this->dropAttribVector);
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->alterAttribVector.size() > 0)
        {
            string msg = "Alter the column(s): " + this->getAlteredAttrib(this->alterAttribVector);
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->alterDbMandatoryAttribVector.size() > 0)
        {
            string msg = "Alter the column(s) (Db mandatory value or copy values): " + this->getAlteredAttrib(this->alterDbMandatoryAttribVector);
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->alterDbDefaultAttribVector.size() > 0)
        {
            string msg = "Alter the column(s) (Db default value): " + this->getAlteredAttrib(this->alterDbDefaultAttribVector);
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->bToTruncate)
        {
            string msg = "Table truncated";
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }

        if (this->bToDrop)
        {
            string msg = "Migration will done dropping table";
            this->printMsg(RET_DBA_INFO_EXIST, msg);
        }
        this->bAlterInfoPrinted = true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenTable::getAlteredAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32672 - LJE - 180827
**
*************************************************************************/
string DdlGenTable::getAlteredAttrib(std::vector<DdlGenUpgrade> &alterVector)
{
    stringstream outStream;
    string sep;

    for (auto it = alterVector.begin(); it != alterVector.end(); ++it)
    {
        outStream << sep << it->m_colSqlNameStr;
        if (sep.empty())
        {
            sep = ", ";
        }
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenTable::getSortedAlterCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-41906 - JJN - 061020
**
*************************************************************************/
DdlGenSqlBlock DdlGenTable::getSortedAlterCmd(std::vector<DdlGenUpgrade> &alterVector)
{
    map<string, DdlGenUpgrade> vectorSyncMap;
    DdlGenSqlBlock printAttribSqlBlock;
    string sep;

    for (auto it = alterVector.begin(); it != alterVector.end(); ++it)
    {
        vectorSyncMap.insert(make_pair(it->m_colSqlNameStr, *it));
    }

    for (auto it = this->newAttribVector.begin(); it != this->newAttribVector.end(); ++it)
    {
        auto atribIt = vectorSyncMap.find(it->m_colSqlNameStr);

        if (atribIt != vectorSyncMap.end())
        {
            printAttribSqlBlock << sep << (atribIt->second.m_alterCmdStr.empty() ? atribIt->second.m_colSqlNameStr : atribIt->second.m_alterCmdStr);

            if (sep.empty())
            {
                sep = ", ";
            }
        }

    }
    return printAttribSqlBlock;
}

/************************************************************************
**
**  Function    :   DdlGenTable::getAlterTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32672 - LJE - 180827
**
*************************************************************************/
string DdlGenTable::getAlterTable(std::vector<DdlGenUpgrade> &alterVector, DdlGenTable::KinOfAlterTable kindOfAlterTable)
{
    stringstream outStream;

    bool bFirst = true;
    for (auto it = alterVector.begin(); it != alterVector.end(); ++it)
    {
        if (it->m_bTreated)
        {
            continue;
        }

        if (it->m_upgradeCmdStr.empty() == false)
        {
            it->m_bTreated = true;

            outStream << it->m_upgradeCmdStr;
            break;
        }

        if (bFirst)
        {
            outStream << "alter table " << this->getEntityFullSqlName() << endl;
        }

        outStream << this->getCmdColAlterSepartor(bFirst, (kindOfAlterTable == DdlGenTable::KinOfAlterTable::AddNew));

        /* PMSTA-42136 - LJE - 201022 */
        if (kindOfAlterTable == DdlGenTable::KinOfAlterTable::AddNew)
        {
            outStream << this->getCmdAddColumn(bFirst);
        }
        else if (this->ddlGenContextPtr->m_rdbmsEn == MSSql && bFirst == false)
        {
            outStream << "alter table " << this->getEntityFullSqlName() << endl;
        }

        outStream << it->m_alterCmdStr << endl;

        it->m_bTreated = true;
        bFirst         = false;

        if (this->isOneRequestByAlter())
        {
            break;
        }
    }

    if (bFirst == false && kindOfAlterTable == DdlGenTable::KinOfAlterTable::AddNew)
    {
        outStream << this->getCmdEndAddColumn();
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenTable::getCreateTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32672 - LJE - 180827
**
*************************************************************************/
string DdlGenTable::getCreateTable()
{
    stringstream outStream;
    string       sep("  ");
    bool         bFirst = true;

    outStream << endl << "(";
    for (auto it = this->newAttribVector.begin(); it != this->newAttribVector.end(); ++it)
    {
        outStream << endl << sep << it->m_alterCmdStr;

        if (bFirst)
        {
            bFirst = false;
            sep    = ", ";
        }
    }

    /* PMSTA-58084 - LJE - 240729 */
    if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
    {
        outStream
            << std::endl << ", spid_filter  SMALLINT    NOT NULL   DEFAULT(@@spid)"
            << std::endl << "INDEX " << this->getDdlObjSqlName() << "_spid_idx NONCLUSTERED (spid_filter),";

        auto& xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();
        for (auto& xdIndexStp : xdIndexVector)
        {
            outStream
                << std::endl << "INDEX " << GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName) << " NONCLUSTERED (spid_filter";

            auto& currIndexAttribByRankMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(xdIndexStp);
            for (auto& xdIndexAttribIt : currIndexAttribByRankMap)
            {
                outStream << ", " << GET_SYSNAME(xdIndexAttribIt.second, A_XdIndexAttrib_XdAttribSqlName);

                if (GET_ENUM(xdIndexAttribIt.second, A_XdIndexAttrib_SortRuleEn) == SortRule_Descending)
                {
                    outStream << " desc";
                }
            }
            outStream << "),";
        }

        outStream
            << std::endl << "CONSTRAINT chk_" << this->getDdlObjSqlName() << " CHECK(spid_filter = @@spid)"
            << std::endl << ")"
            << std::endl << "WITH"
            << std::endl << "(MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY)";
    }
    else if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Type)
    {
        auto& xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();
        if (xdIndexVector.empty())
        {
            outStream
                << std::endl << "INDEX idx (";

            bFirst = true;
            for (auto& attribIt : this->getDictEntityStp()->attr)
            {
                if (attribIt->isPhysicalAttribute() == false)
                {
                    break;
                }
                if (bFirst)
                {
                    bFirst = false;
                }
                else
                {
                    outStream << ",";
                }
                outStream << attribIt->sqlName;
            }
            outStream << ")";
        }
        else
        {
            bFirst = true;
            for (auto& xdIndexStp : xdIndexVector)
            {
                if (bFirst)
                {
                    bFirst = false;
                }
                else
                {
                    outStream << ",";
                }
                outStream
                    << std::endl << "INDEX " << GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName) << " NONCLUSTERED (";

                bool bFirstAttrib = true;
                auto& currIndexAttribByRankMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(xdIndexStp);
                for (auto& xdIndexAttribIt : currIndexAttribByRankMap)
                {
                    if (bFirstAttrib)
                    {
                        bFirstAttrib = false;
                    }
                    else
                    {
                        outStream << ", ";
                    }
                    outStream << GET_SYSNAME(xdIndexAttribIt.second, A_XdIndexAttrib_XdAttribSqlName);

                    if (GET_ENUM(xdIndexAttribIt.second, A_XdIndexAttrib_SortRuleEn) == SortRule_Descending)
                    {
                        outStream << " desc";
                    }
                }
                outStream << ")";
            }
        }

        outStream
            << std::endl << ")"
            << std::endl << "WITH"
            << std::endl << "(MEMORY_OPTIMIZED = ON)";
    }
    else
    {
        outStream << endl << ")";
    }
    
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenTable::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::create()
{
    RET_CODE    ret = RET_SUCCEED;

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->bodySqlBlock
            << this->getCmdPrintMsg("Creating table " + this->getDdlObjFullSqlName(), false) << endl;

        this->cmdType = DDlCmdType_Init;
        ret = this->flush();

        this->bNoIndentReset = true;
    }
    else if (this->getDictEntityStp() != nullptr &&
             this->getDictEntityStp()->entNatEn != EntityNat_TempTable &&
             this->m_bForceTempTable == false &&
             this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild &&
             this->ddlGenContextPtr->ddlGenAction.m_bUseNativeQuery == false)
    {
        this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_View),
                                                    "\t" + this->getDdlModif(this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_View)),
                                                    string());
        this->cmdType = DDlCmdType_CleanUpView;
        ret = this->flush();
    }

    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->custFlg         = FALSE;
    this->precompFlg      = FALSE;

    AAAValueGuardBool bTmpCreate(this->bCreate, true);
    AAAValueGuardBool bTmpOptim(this->bOptim, false);

    if ((ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printBody()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        this->cmdType = DDlCmdType_Create;
        ret = this->flush();
    }

    if (ret == RET_SUCCEED)
    {
        this->getDictEntityStp()->xdStatusEn = XdStatus_Inserted;

        if (this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None &&
            this->getDictEntityStp()->entNatEn != EntityNat_System &&
            this->ddlGenContextPtr->getCfgFileHelper().getPropertyBoolOrDefValue("AAAMIGCREATEPK", false))
        {
            DdlGenFK ddlGenFk(*this);
            ddlGenFk.createPk();
        }

        if (bTmpOptim.getOld() == false &&
            (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None ||
             (this->ddlGenContextPtr->getCfgFileHelper().getPropertyBoolOrDefValue("AAAMIGCREATECONSTR", true) &&
              this->getDictEntityStp()->entNatEn != EntityNat_System)))                         /* Will do during the new install process
                                                                                                   due to the possibility to have to some errors on source meta-dictionary */
        {
            if ((ret = this->createConstraints()) != RET_SUCCEED)
            {
                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    this->printMsg(ret, "Creation of constraints skipped");
                }
                else
                {
                    this->printMsg(ret, "Creation of constraints failed");
                }
            }
            else
            {
                this->printMsg(ret, "Creation of constraints successful");
            }
            ret = RET_SUCCEED;
        }

        /* PMSTA-58084 - LJE - 240729 */
        if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
        {
            this->bodySqlBlock
                << std::endl << "CREATE SECURITY POLICY " << this->getDictEntityStp()->databaseName << "." << this->getDdlObjSqlName() << "_spid"
                << std::endl << "                ADD FILTER PREDICATE " << this->ddlGenContextPtr->getMainDbName() << ".fn_spid_filter(spid_filter)"
                << std::endl << "ON " << this->getDictEntityStp()->databaseName << "." << this->getDdlObjSqlName()
                << std::endl << "WITH(STATE = ON);";

            this->cmdType = DDlCmdType_Create;
            ret = this->flush();
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenTable::alter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::alter()
{
    RET_CODE     ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    stringstream physicalStream;
    bool         bUpgrade = false;

    /* PMSTA-24007 - LJE - 170718 */
    if (this->ddlGenEntityPtr->isChangedPartition(this->realSqlName))
    {
        this->bForceUpgrade = true;

        if (this->isPartitionsByAlter((FEATURE_AUTH_ENUM)GET_ENUM(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PartAuthEn)) == false)
        {
            return RET_DBA_INFO_NODATA;
        }

        physicalStream << this->getCmdCreatePhysicalProperties(string(), this->ddlGenEntityPtr->getXdEntityStp(), nullptr, *this->ddlGenEntityPtr);

        /* Remove all the indexes to be able to create the partitions */
        string currDbName = this->ddlGenContextPtr->getDdlDestDbName();
        if (this->isSysMdFullAccessiblity() == true)
        {
            this->ddlGenContextPtr->setDdlDestDbName(this->ddlGenContextPtr->getMainDbName(), this);
        }

        string scptToTreat = "#EXEC drop_all_idx_by_nm '" + this->getEntitySqlName() + "', '" + this->ddlGenContextPtr->getMainDbName() + "'";
        DdlGenDbi::convertSqlBlock(scptToTreat, this->scriptDdlGen);
        this->bodySqlBlock << scptToTreat;
        this->cmdType = DDlCmdType_Drop;
        if ((ret = this->flush()) != RET_SUCCEED)
            return ret;

        if (this->isSysMdFullAccessiblity() == true)
        {
            this->ddlGenContextPtr->setDdlDestDbName(currDbName, this);
        }
    }

    this->cmdType = DDlCmdType_Create;

    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->custFlg         = FALSE;
    this->precompFlg      = FALSE;

    if ((ret = this->initRequest()) != RET_SUCCEED)
        return ret;

    if ((gblRet = this->getAllAttrib(false)) == RET_SUCCEED)
    {
        if (this->attribPrintedNbr != 0 || physicalStream.str().empty() == false)
        {
            bUpgrade = true;

            this->printAlteredInfo();

            if (this->bToDrop)
            {
                /* PMSTA-58084 - LJE - 240729 */
                if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
                {
                    this->bodySqlBlock << "drop security policy " << this->getDdlObjSqlName() << "_spid";
                    this->cmdType = DDlCmdType_Drop;
                    ret = this->flush();
                    if (ret != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                }

                this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                                       this->getEntitySqlName(),
                                                       this->getDdlObjSqlName(),
                                                       this->getDdlObjEn());
                this->cmdType = DDlCmdType_Drop;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }

                return RET_DBA_INFO_EXIST;
            }

            if (this->bToTruncate)
            {
                this->bodySqlBlock << this->getCmdTruncateTable(this->getDictEntityStp(), true, false);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }

            if (gblRet == RET_SUCCEED)
            {
                gblRet = this->dropIndexToDrop();
            }

            if (gblRet == RET_SUCCEED)
            {
                gblRet = this->dropViewToDrop();
            }
            
            if (gblRet == RET_SUCCEED)
            {
                gblRet = this->dropConstraintToDrop();
            }



            if (gblRet == RET_SUCCEED &&
                this->alterDbDefaultAttribVector.empty() == false)
            {
                for (auto it = this->alterDbDefaultAttribVector.begin(); it != this->alterDbDefaultAttribVector.end(); ++it)
                {
                    this->bodySqlBlock << "alter table " << this->getEntityFullSqlName() << it->m_alterCmdStr;
                    this->cmdType = DDlCmdType_DbProcess;
                    ret = this->flush();
                    if (ret != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                }
            }

            if (EV_RdbmsDdlGen == Oracle && this->removeIdentitySqlName.empty() == false)
            {
                this->bodySqlBlock << "alter table " << this->getEntityFullSqlName() << " modify " << this->removeIdentitySqlName << " drop identity";
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }

            if (gblRet == RET_SUCCEED &&
                this->alterAttribVector.empty() == false)
            {
                do
                {
                    this->bodySqlBlock << this->getAlterTable(this->alterAttribVector, DdlGenTable::KinOfAlterTable::Modify);

                    if (this->bodySqlBlock.str().empty() == false)
                    {
                        this->cmdType = DDlCmdType_DbProcess;
                        ret = this->flush();
                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                    else
                    {
                        ret = RET_DBA_INFO_NO_MORE_DATA;
                    }
                } while (ret == RET_SUCCEED);
            }

            if (gblRet == RET_SUCCEED &&
                this->newAttribVector.empty() == false)
            {
                do
                {
                    this->bodySqlBlock << this->getAlterTable(this->newAttribVector, DdlGenTable::KinOfAlterTable::AddNew);

                    if (this->bodySqlBlock.str().empty() == false)
                    {
                        this->cmdType = DDlCmdType_DbProcess;
                        ret = this->flush();
                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                    else
                    {
                        ret = RET_DBA_INFO_NO_MORE_DATA;
                    }
                } while (ret == RET_SUCCEED);
            }

            if (gblRet == RET_SUCCEED &&
                this->alterDbMandatoryAttribVector.empty() == false)
            {
                bool         bTriggerDisable = false;
                bool         bCustomFlg      = false;

                stringstream fromLinkedUpgStream;

                for (auto it = this->alterDbMandatoryAttribVector.begin(); it != this->alterDbMandatoryAttribVector.end(); ++it)
                {
                    if (it->m_upgradeCmdStr.compare("from_linked") == 0)
                    {
                        string prefixStr("E");

                        if (it->m_bCustom)
                        {
                            bCustomFlg = true;
                            prefixStr  = "ud";
                        }

                        if (fromLinkedUpgStream.str().empty())
                        {
                            fromLinkedUpgStream
                                << "#NO_SECURED" << endl
                                << "#NO_MULTI_ENTITY" << endl
                                << "#UPDATE " << this->getDictEntityStp()->mdSqlName << " null be" << endl;
                        }

                        fromLinkedUpgStream
                            << "be." << it->m_colSqlNameStr << " = ";

                        if (it->m_bNewAttrib)
                        {
                            fromLinkedUpgStream
                                << prefixStr << "." << it->m_colSqlNameStr << endl;
                        }
                        else
                        {
                            fromLinkedUpgStream
                                << "#ISNULL(be." << it->m_colSqlNameStr << ", " << prefixStr << "." << it->m_colSqlNameStr << ")" << endl;
                        }
                    }
                    else if (it->m_upgradeCmdStr.empty() == false)
                    {
                        if (bTriggerDisable == false)
                        {
                            bTriggerDisable = true;
                            this->disableAllTriggers(this->getDictEntityStp()->dbSqlName);
                        }

                        stringstream msg;
                        msg << "Updating '" << it->m_colSqlNameStr << "' on NULL values";
                        this->printMsg(RET_SRV_INFO_RUNNING, msg.str());
                        this->bodySqlBlock << it->m_upgradeCmdStr;
                        this->cmdType = DDlCmdType_Grant;
                        if ((ret = this->flush()) != RET_SUCCEED)
                        {
                            this->printMsg(RET_DBA_ERR_INVDATA, "Updating the attribute " + it->m_colSqlNameStr + " failed");

                            if (ret != RET_SUCCEED)
                            {
                                gblRet = ret;
                            }
                        }
                    }
                }

                if (fromLinkedUpgStream.str().empty() == false)
                {
                    if (bTriggerDisable == false)
                    {
                        bTriggerDisable = true;
                        this->disableAllTriggers(this->getDictEntityStp()->dbSqlName);
                    }

                    fromLinkedUpgStream
                        << "#FROM" << endl
                        << "inner join " << this->getDictEntityStp()->linkedEntityStp->mdSqlName << " E ";

                    if (bCustomFlg)
                    {
                        if (this->getDictEntityStp()->linkedEntityStp->primKeyNbr == 1) /* PRO-12323 - LJE - 191031 */
                        {
                            fromLinkedUpgStream
                                << "inner join " << this->getDictEntityStp()->linkedEntityStp->custSqlName << " ud on E." << this->getDictEntityStp()->linkedEntityStp->primKeyTab[0]->sqlName << " = ud.ud_id "; /* PRO-12323 - LJE - 191031 */
                        }
                        else
                        {
                            gblRet = RET_GEN_ERR_INVARG;
                            this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                        }
                    }
                    fromLinkedUpgStream << "on";

                    int              ukNbr = this->getDictEntityStp()->primKeyNbr ? this->getDictEntityStp()->primKeyNbr : this->getDictEntityStp()->bkAttrNbr;
                    DICT_ATTRIB_STP *ukTab = this->getDictEntityStp()->primKeyNbr ? this->getDictEntityStp()->primKeyTab : this->getDictEntityStp()->bkAttr;

                    for (int i = 0; i < ukNbr; ++i)
                    {
                        if (i)
                        {
                            fromLinkedUpgStream << " and";
                        }
                        fromLinkedUpgStream
                            << " E." << ukTab[i]->sqlName << " = be." << ukTab[i]->sqlName;
                    }

                    fromLinkedUpgStream << endl
                        << "#WHERE" << endl
                        << "#END";

                    stringstream msg;
                    msg << "Updating new partial specialized attributes";
                    this->printMsg(RET_SRV_INFO_RUNNING, msg.str());
                    this->bodySqlBlock << this->scriptDdlGen->buildScript(fromLinkedUpgStream.str(), DdlObj_Sql);
                    this->cmdType = DDlCmdType_DbProcess;
                    if ((ret = this->flush()) != RET_SUCCEED)
                    {
                        this->printMsg(RET_DBA_ERR_INVDATA, "Updating new partial specialized attributes failed");

                        gblRet = ret;
                    }
                }

                if (gblRet == RET_SUCCEED)
                {
                    for (auto it = this->alterDbMandatoryAttribVector.begin(); it != this->alterDbMandatoryAttribVector.end(); ++it)
                    {
                        if (it->m_alterCmdStr.empty() == false) /* Partial specialization case */
                        {
                            this->bodySqlBlock << this->bodySqlBlock << "alter table " << this->getEntityFullSqlName() << " " << it->m_alterCmdStr;
                            this->cmdType = DDlCmdType_DbProcess;
                            if (this->flush() != RET_SUCCEED)
                            {
                                /* No ret variable is affected because do not consider as a fatal error (xd_status_e should be "inserted" instead of "Failed") */
                                this->printMsg(RET_DBA_ERR_HIER_WARN, "Unable to change the mandatory value to the attribute " + it->m_colSqlNameStr + ", see log file");
                            }
                        }
                    }
                }

                if (bTriggerDisable)
                {
                    this->enableAllTriggers(this->getDictEntityStp()->dbSqlName);
                }
            }

            /* PMSTA-30628 - LJE - 180423 */
            if (gblRet == RET_SUCCEED &&
                physicalStream.str().empty() == false)
            {
                this->bodySqlBlock << "alter table " << this->getEntityFullSqlName() << physicalStream.str();
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }
        }
        else
        {
            this->clear();
        }
    }

    if (gblRet != RET_DBA_INFO_NODATA && 
        this->bToDrop      == false && 
        this->m_bForceDrop == false)
    {
        /* PMSTA-29485 - LJE - 171206 */
        std::map<std::string, DBA_DYNFLD_STP> mandatoryMap;
        this->ddlGenEntityPtr->getSysMandatoryAttribSqlNameSet(mandatoryMap, this->targetTableEn);
        for (auto &attribIt : this->getDictEntityStp()->attr)
        {
            mandatoryMap.erase(lower(attribIt->sqlName));
        }

        if (mandatoryMap.empty() == false)
        {
            /* Refresh system info */
            (void)this->ddlGenEntityPtr->loadExdEntityFromSysInfo(this->realSqlName, true);

            this->ddlGenEntityPtr->getSysMandatoryAttribSqlNameSet(mandatoryMap, this->targetTableEn);
            for (auto &attribIt : this->getDictEntityStp()->attr)
            {
                mandatoryMap.erase(lower(attribIt->sqlName));
            }
        }

        if (mandatoryMap.empty() == false)
        {
            string optimLockAttribSqlName = this->getOptimisticLockingSqlName(this->getDictEntityStp());
            int    attribToUpdate = 0;

            this->bodySqlBlock << "alter table " << this->getEntityFullSqlName();
            for (auto sqlNameIt = mandatoryMap.begin(); sqlNameIt != mandatoryMap.end(); ++sqlNameIt)
            {
                if (optimLockAttribSqlName.compare(sqlNameIt->first))
                {
                    if (this->ddlGenContextPtr->m_rdbmsEn == MSSql && attribToUpdate != 0)
                    {
                        this->bodySqlBlock << "alter table " << this->getEntityFullSqlName();
                    }

                    this->bodySqlBlock << this->getCmdAlterSepartor(attribToUpdate==0) << this->getCmdModifyColumn() << sqlNameIt->first;
                    attribToUpdate++;

                    if (this->isDescAllInAlterTable() == true)
                    {
                        if (IS_NULLFLD(sqlNameIt->second, A_XdAttrib_CName))
                        {
                            this->bodySqlBlock << " " << this->getDataTypeSqlName(DATATYPE_DICT_TO_ENUM(GET_DICT(sqlNameIt->second, A_XdAttrib_DataTpDictId)));
                        }
                        else
                        {
                            this->bodySqlBlock << " " << GET_SYSNAME(sqlNameIt->second, A_XdAttrib_CName);
                        }
                    }
                    this->bodySqlBlock << this->getCmdNullable(true, true) << endl;
                }
            }

            if (attribToUpdate > 0)
            {
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }
        }

        if (gblRet == RET_SUCCEED &&
            (ret = this->checkAttribToPhysicallyDelete()) != RET_SUCCEED)
        {
            return ret;
        }

        if (gblRet == RET_SUCCEED &&
            this->dropAttribVector.size() > 0 &&
            this->dropIndexToDrop() == RET_SUCCEED &&
            this->dropConstraintToDrop() == RET_SUCCEED)
        {
            
            this->printMsg(ret, "Drop the column(s): " + this->getAlteredAttrib(this->dropAttribVector));

            for (auto it = this->dropAttribVector.begin(); ret == RET_SUCCEED && it != this->dropAttribVector.end(); ++it)
            {
                DBA_DYNFLD_STP attribToDelSpt = this->ddlGenEntityPtr->getDbXdAttribBySqlName(it->m_colSqlNameStr);
                if (attribToDelSpt != nullptr &&
                    IS_NULLFLD(attribToDelSpt, A_XdAttrib_RefXdEntityId) == false)
                {
                    string refEntitySqlName = this->ddlGenContextPtr->getXdEntitySqlNameById(GET_ID(attribToDelSpt, A_XdAttrib_RefXdEntityId));
                    string selObjInDb = this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(),
                                                               this->getEntitySqlName(),
                                                               this->getDdlObjSqlName(),
                                                               DdlObj_ForeignKey,
                                                               string(),
                                                               refEntitySqlName,
                                                               it->m_colSqlNameStr);

                    stringstream fkSqlNameStream;
                    fkSqlNameStream << "fk_" << GET_DICT(attribToDelSpt, A_XdAttrib_AttribDictId);

                    this->bodySqlBlock << this->getCmdIfExsists(selObjInDb,
                                                                "\t" + this->getDdlModif(
                                                                this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                                 this->getEntitySqlName(),
                                                                                 fkSqlNameStream.str(), 
                                                                                 DdlObj_ForeignKey,
                                                                                 nullptr,
                                                                                 refEntitySqlName)),
                                                                string());
                    this->cmdType = DDlCmdType_Drop;
                    ret = this->flush();
                    if (ret != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                }

                this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), it->m_colSqlNameStr, DdlObj_Column);
                this->cmdType = DDlCmdType_Drop;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }
        }
    }

    if (gblRet == RET_SUCCEED && bUpgrade)
    {
        this->cmdType = DDlCmdType_DbProcess;
        this->bodySqlBlock << this->getCmdCheckpoint();
        ret = this->flush();
        if (ret != RET_SUCCEED)
        {
            gblRet = ret;
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTable::alterByIntoExistingTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130205
**
*************************************************************************/
RET_CODE DdlGenTable::alterByIntoExistingTable()
{
    RET_CODE     ret = RET_SUCCEED, errRet = RET_SUCCEED;
    string       oriDdlObjSqlName = this->getEntitySqlName();
    string       tmpDdlObjSqlName = ("tmp_" + oriDdlObjSqlName).substr(0, this->getMaxDDLObjLength());
    string       scptToTreat;

    DdlGenSqlBlock  printAttribSqlBlock;

    this->cmdType = DDlCmdType_Create;

    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->custFlg         = FALSE;
    this->precompFlg      = FALSE;
    this->bJoinMainTable  = false;

    if ((ret = this->initRequest()) != RET_SUCCEED)
        return ret;

    if ((ret = this->getAllAttrib(false)) != RET_SUCCEED)
        return ret;

    if ((ret = this->checkAttribToPhysicallyDelete()) != RET_SUCCEED)
        return ret;

    this->printAlteredInfo();
    this->printMsg(RET_DBA_INFO_EXIST, "Migration done by insert/select");

    if (this->bForceUpgrade                       == false &&
        this->newAttribVector.size()              == 0 &&
        this->dropAttribVector.size()             == 0 &&
        this->alterAttribVector.size()            == 0 &&
        this->alterDbMandatoryAttribVector.size() == 0 &&
        this->alterDbDefaultAttribVector.size()   == 0)
    {
        /* Nothing to do */
        string  msg = "The entity " + oriDdlObjSqlName + " is up to date";
        this->printMsg(ret, msg);
        this->clear();
        return ret;
    }

    if (this->alterDbMandatoryAttribVector.empty() == false)
    {
        bool bTriggerDisable = false;

        for (auto it = this->alterDbMandatoryAttribVector.begin(); it != this->alterDbMandatoryAttribVector.end(); ++it)
        {
            if (it->m_upgradeCmdStr.empty() == false)
            {
                if (bTriggerDisable == false)
                {
                    bTriggerDisable = true;
                    this->disableAllTriggers(this->getDictEntityStp()->dbSqlName);
                }

                stringstream msg;
                msg << "Updating '" << it->m_colSqlNameStr << "' on NULL values";
                this->printMsg(RET_SRV_INFO_RUNNING, msg.str());
                this->bodySqlBlock << it->m_upgradeCmdStr;
                this->cmdType = DDlCmdType_DbProcess;
                if ((ret = this->flush()) != RET_SUCCEED)
                {
                    /* No ret variable is affected because do not consider as a fatal error (xd_status_e should be "inserted" instead of "Failed") */
                    this->printMsg(RET_DBA_ERR_INVDATA, "Updating the attribute " + it->m_colSqlNameStr + " failed");
                }
            }
        }

        if (bTriggerDisable)
        {
            this->enableAllTriggers(this->getDictEntityStp()->dbSqlName);
        }

        if (ret != RET_SUCCEED)
        {
            return ret;
        }
    }

    std::vector<DdlGenUpgrade> locAlterAttribVector = this->alterAttribVector;

    this->setDdlObjSqlName(tmpDdlObjSqlName);
    if ((ret = this->drop()) != RET_SUCCEED)
    {
        return ret;
    }

    string currDbName = this->ddlGenContextPtr->getDdlDestDbName();

    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        scptToTreat = "#DROP_DB_OBJECT(constraint, " + oriDdlObjSqlName + ")";
        this->bodySqlBlock << this->scriptDdlGen->buildScript(scptToTreat, DdlObj_Sql);
        this->cmdType = DDlCmdType_Drop;
        if ((ret = this->flush()) != RET_SUCCEED)
        {
            return ret;
        }
    }
    else
    {
        this->ddlGenContextPtr->setDdlDestDbName(this->ddlGenContextPtr->getMainDbName(), this);
        scptToTreat = "#EXEC drop_all_constr_by_nm '" + oriDdlObjSqlName + "'";
        this->bodySqlBlock << this->scriptDdlGen->buildScript(scptToTreat, DdlObj_RuntimeSql);
        this->cmdType = DDlCmdType_Drop;
        if ((ret = this->flush()) != RET_SUCCEED)
        {
            return ret;
        }
    }

    {
        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                        DdlObj_PrimaryKey,
                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                        this->getEntitySqlName(),
                                        this->getEntitySqlName(),
                                        this->getEntitySqlName());

        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().eraseDdlObjDef(searchDdlObjDefKey);
    }

    this->ddlGenContextPtr->setDdlDestDbName(currDbName, this);

    scptToTreat = "#RENAME " + oriDdlObjSqlName + ", " + tmpDdlObjSqlName;
    this->bodySqlBlock << this->scriptDdlGen->buildScript(scptToTreat, DdlObj_Migration);
    this->cmdType = DDlCmdType_DbProcess;
    if ((ret = this->flush()) != RET_SUCCEED)
        return ret;

    this->setDdlObjSqlName(oriDdlObjSqlName);

    if (this->isCreateAsSelectBehavior())
    {
        bool bAsSelect = (this->getDictEntityStp()->pkRuleEn != PkRule_Identity && this->getDictEntityStp()->partAuthEn != FeatureAuth_Enable);

        if (bAsSelect)
        {
            for (auto &it : locAlterAttribVector)
            {
                if (it.m_alterCmdStr == "NULL")
                {
                    bAsSelect = false;
                    break;
                }
            }
        }

        if (bAsSelect)
        {
            string sep;
            for (auto it = locAlterAttribVector.begin(); it != locAlterAttribVector.end(); ++it)
            {
                printAttribSqlBlock << sep << (it->m_alterCmdStr.empty() ? it->m_colSqlNameStr : it->m_alterCmdStr);

                if (sep.empty())
                {
                    sep = ", ";
                }
            }

            this->asSelectClause << " as select " << endl << printAttribSqlBlock.str() << endl << " from " << tmpDdlObjSqlName << endl;

            ret = this->create();

            /* PMSTA-29748 - LJE - 180110 - Recreate default values */
            if (this->alterDbDefaultAttribVector.empty() == false)
            {
                this->bodySqlBlock << this->getAlterTable(this->alterDbDefaultAttribVector, DdlGenTable::KinOfAlterTable::ModifyDefault);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush();

                if (ret != RET_SUCCEED)
                {
                    this->drop();
                }
            }
        }
        else
        {
            this->tmpTableSqlName = tmpDdlObjSqlName; /* PMSTA-34418 - LJE - 190204 */

            if ((ret = this->create()) == RET_SUCCEED)
            {
                this->selListStream
                    << "insert into " << oriDdlObjSqlName
                    << " select " << endl
                    << getSortedAlterCmd(locAlterAttribVector).str()
                    << endl << " from " << tmpDdlObjSqlName << endl;

                if (this->bJoinMainTable)
                {
                    if (this->getDictEntityStp()->primKeyNbr == 1) /* PRO-12323 - LJE - 191031 */
                    {
                        this->selListStream
                            << " inner join " << this->getDictEntityStp()->dbSqlName << " E on " << this->getDictEntityStp()->primKeyTab[0]->sqlName << " = ud_id " << endl; /* PRO-12323 - LJE - 191031 */
                    }
                    else
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                    }
                }

                this->cmdType = DDlCmdType_DbProcess;
                if ((ret = this->flush()) != RET_SUCCEED)
                {
                    if ((errRet = this->drop()) != RET_SUCCEED)
                    {
                        this->tmpTableSqlName.clear();
                        return errRet;
                    }
                }
            }

            this->tmpTableSqlName.clear();
        }
    }
    else
    {
        if ((ret = this->create()) == RET_SUCCEED)
        {
            if (this->removeIdentitySqlName.empty() == false)
            {
                this->selListStream
                    << "insert into " << oriDdlObjSqlName
                    << " select " << endl
                    << getSortedAlterCmd(locAlterAttribVector).str()
                    << endl << " from " << tmpDdlObjSqlName << endl;
            }
            else
            {
                this->selListStream
                    << "select " << endl
                    << getSortedAlterCmd(locAlterAttribVector).str()
                    << endl << "into existing table " << oriDdlObjSqlName << " from " << tmpDdlObjSqlName << endl;
            }

            this->cmdType = DDlCmdType_DbProcess;
            if ((ret = this->flush()) != RET_SUCCEED)
            {
                if ((errRet = this->drop()) != RET_SUCCEED)
                {
                    return errRet;
                }
            }
        }
    }

    if (ret != RET_SUCCEED)
    {
        scptToTreat = "#RENAME " + tmpDdlObjSqlName + ", " + oriDdlObjSqlName;
        this->bodySqlBlock << this->scriptDdlGen->buildScript(scptToTreat, DdlObj_Migration);
        this->cmdType = DDlCmdType_DbProcess;
        if ((errRet = this->flush()) != RET_SUCCEED)
        {
            return errRet;
        }

        return ret;
    }
    else
    {
        (void)this->grant();
    }

   this->setDdlObjSqlName(tmpDdlObjSqlName);
    if ((ret = this->drop()) != RET_SUCCEED)
    {
        this->setDdlObjSqlName(oriDdlObjSqlName);
        return ret;
    }
    this->setDdlObjSqlName(oriDdlObjSqlName);

    if ((ret = this->createConstraints()) != RET_SUCCEED)
    {
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            this->printMsg(ret, "Creation of constraints skipped");
        }
        else
        {
            this->printMsg(ret, "Creation of constraints failed");
        }
    }
    else
    {
        this->printMsg(ret, "Creation of constraints successful");
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::grant()
{
    RET_CODE            ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    stringstream        grantStream;
    string              currGrant;

    this->printGrantTable(grantStream, this->getDictEntityStp());

    while (getline(grantStream, currGrant))
    {
        this->bodySqlBlock << currGrant << endl;

        this->cmdType = DDlCmdType_Grant;
        ret = this->flush();

        if (ret != RET_SUCCEED)
        {
            gblRet = ret;
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTable::fillUdFieldsTable()
**
**  Description :   Fill the user defined fields table if needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121210
**
*************************************************************************/
RET_CODE DdlGenTable::fillUdFieldsTable(bool bForce)
{
    RET_CODE     ret = RET_SUCCEED;
    stringstream insStream, selStream, restrictStream;

    if (bForce == false &&
        (this->targetTableEn != TargetTable_UserDefinedFields ||
         this->getDictEntityStp()->isPhysicalEntity(this->targetTableEn) == false ||
         this->getDictEntityStp()->dbRuleEn == DbRule_NotMainTable ||
         this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None))
    {
        return ret;
    }

    if ((ret = this->initRequest()) != RET_SUCCEED)
        return ret;

    insStream << "insert into " << this->getDdlObjFullSqlName() << endl
        << "(" << DdlGen::getUdIdSqlName() << ")";

    selStream << "select E." << this->getDictEntityStp()->primKeyTab[0]->sqlName << endl
        << "from " << this->getDdlFullName(this->ddlGenContextPtr->getDdlDestDbName(), this->getDictEntityStp()->dbSqlName) << " E";

    if (bForce)
    {
        this->cmdType = DDlCmdType_Drop;
        this->bodySqlBlock << this->scriptDdlGen->buildScript(SYS_Stringer("#FORCE_TRUNCATE ", this->getDictEntityStp()->custSqlName), DdlObj_RuntimeSql);
        ret = this->flush();
    }
    else
    {
        restrictStream << "select 'x' " << endl
            << "                    from " << this->getDdlObjFullSqlName() << " ud" << endl
            << "                   where ud." << DdlGen::getUdIdSqlName() << " = E." << this->getDictEntityStp()->primKeyTab[0]->sqlName;
    }

    this->bodySqlBlock << this->getCmdInsertIntoOptim(insStream.str(), selStream.str(), restrictStream.str()) << this->getCmdEndDDLObj();

    this->cmdType = DDlCmdType_DML;
    ret = this->flush();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::fillPkTable()
**
**  Description :   Fill the primary key table if needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170407
**
*************************************************************************/
RET_CODE DdlGenTable::fillPkTable()
{
    RET_CODE     ret = RET_SUCCEED;
    stringstream insStream;

    if (this->targetTableEn != TargetTable_Main ||
        this->getDictEntityStp()->dbRuleEn != DbRule_PrimaryKeyTable)
    {
        return ret;
    }

    this->cmdType = DDlCmdType_Create;

    this->disableIdentity(this->getDictEntityStp(), this->getDictEntityStp());

    insStream
        << this->newLine() << "#NO_MULTI_ENTITY"
        << this->newLine() << "#NO_SECURED"
        << this->newLine() << "#INSERT " << this->getDictEntityStp()->mdSqlName << " all_db"
        << this->newLine() << "+pk"
        << this->newLine() << "#SELECT " << this->getDictEntityStp()->mdSqlName << " all_db pk_source " << this->getDictEntityStp()->linkedEntityStp->mdSqlName
        << this->newLine() << "+pk"
        << this->newLine() << "obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */";

    if (this->getDdlGenContextPtr()->getMultiEntityLevel() != MultiEntityLevel_None &&
        this->getDictEntityStp()->multiEntityCateg.isOwnerBusinessEntity() &&
        this->getDictEntityStp()->linkedEntityStp->multiEntityCateg.isOwnerBusinessEntity())
    {
        insStream
            << this->newLine() << "owner_business_entity_id = pk_source.owner_business_entity_id";
    }

    insStream
        << this->newLine() << "#FROM"
        << this->newLine() << "#WHERE"
        << this->newLine() << "#END"
        << this->newLine() << "#SECURED"
        << this->newLine() << "#MULTI_ENTITY";

    string scptToTreat = insStream.str();
    DdlGenDbi::convertSqlBlock(scptToTreat, this->scriptDdlGen);
    this->bodySqlBlock << scptToTreat;

    this->cmdType = DDlCmdType_DML;
    ret = this->flush();

    this->enableIdentity(this->getDictEntityStp(), this->getDictEntityStp());

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::executeBatch()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-48744 - LJE - 220414
**
*************************************************************************/
RET_CODE DdlGenTable::executeBatch(bool bForce, RequestHelper &writeRequestHelper, int batchRowNbr, DdlGenMsg& ddlGenMsg)
{
    RET_CODE ret = RET_SUCCEED;

    if (bForce)
    {
        ret = writeRequestHelper.executeBatch(&ddlGenMsg);
    }
    else
    {
        ret = writeRequestHelper.flushBatch(false, &ddlGenMsg);
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
        CAST_INT(writeRequestHelper.m_onErrorRequests.size()) != batchRowNbr)
    {
        writeRequestHelper.printErrorOnFile(std::string(), batchRowNbr, ddlGenMsg);

        if (writeRequestHelper.m_errorConstraints.empty() == false)
        {
            stringstream   msg;
            msg << "Check failed on constraint: ";
            for (auto it = writeRequestHelper.m_errorConstraints.begin(); it != writeRequestHelper.m_errorConstraints.end(); ++it)
            {
                if (it != writeRequestHelper.m_errorConstraints.begin())
                {
                    msg << ", ";
                }
                msg << (*it);
            }

            ddlGenMsg.printMsg(RET_DBA_ERR_DBPROBLEM, msg.str());
        }

        ret = RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::fillTable()
**
**  Description :   Fill the primary key table if needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190522
**
*************************************************************************/
RET_CODE DdlGenTable::fillTable()
{
    DICT_ENTITY_STP targetDictEntityStp = this->getDictEntityStp();
    DICT_ENTITY_STP sourceDictEntityStp = this->getDictEntityStp(true);

    /* PMSTA-48744 - LJE - 220427 */
    if (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None &&
        this->bCreate == false)
    {
        return RET_SUCCEED;
    }

    if (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None ||
        sourceDictEntityStp == nullptr)
    {
        return this->fillPkTable();
    }

    RET_CODE        ret = RET_SUCCEED;
    DdlGenMsg       ddlGenMsg(this->getDdlGenContextPtr());
    DdlGenConnGuard ddlGenConnGuard(*this->ddlGenContextPtr);

    string          currProcessStr = "Migration of data";
    stringstream    readStream, getIdStream;
    MemoryPool      mp;
    bool            bInsertBe = (targetDictEntityStp->dbRuleEn == DbRule_PartialSpecialization);
    bool            bInsertMain = (bInsertBe == false && targetDictEntityStp->dbRuleEn != DbRule_NotMainTable);
    bool            bInsertUd = this->targetTableEn == TargetTable_UserDefinedFields;
    DBA_DYNST_ENUM  dynStEn = NullDynSt;

    this->cmdType = DDlCmdType_Create;

    string      srcApplOwner;
    string      dstApplOwner;
    set<string> techUsersSet;
    string      migPasswordPattern;  /* Migration Pattern */

    std::chrono::steady_clock::time_point readStartTime = std::chrono::steady_clock::now();

    if (this->targetTableEn == TargetTable_Main &&
        strcmp(targetDictEntityStp->mdSqlName, "appl_user") == 0 &&
        EV_SourceCfgFile != nullptr &&
        EV_TargetCfgFile != nullptr)
    {
        if (SYS_GetEnvBoolOrDefValue("AAAMIGDBUSER", false))
        {
            migPasswordPattern = SYS_GetEnvStringOrDefValue("AAAMIGPASSWORDPATTERN", "%s!aB12");
            this->printMsg(RET_DBA_INFO_EXIST, "The migration password pattern (AAAMIGPASSWORDPATTERN, where \"%s\" will be the user name) is: " + migPasswordPattern);
        }
        else
        {
            this->printMsg(RET_DBA_INFO_EXIST, "To migrate database users please set AAAMIGDBUSER=true and AAAMIGPASSWORDPATTERN (default: \"%s!aB12\")");
        }

        for (auto srcIt = EV_SourceCfgFile->usrSectionMap.begin(); srcIt != EV_SourceCfgFile->usrSectionMap.end(); ++srcIt)
        {
            techUsersSet.insert(srcIt->second.userName);

            if (srcIt->second.bApplOwner)
            {
                srcApplOwner = srcIt->first;
                for (auto dstIt = EV_TargetCfgFile->usrSectionMap.begin(); dstIt != EV_TargetCfgFile->usrSectionMap.end(); ++dstIt)
                {
                    if (dstIt->second.bApplOwner)
                    {
                        dstApplOwner = dstIt->first;
                        break;
                    }
                }
            }
        }
        if (srcApplOwner == dstApplOwner)
        {
            srcApplOwner.clear();
            dstApplOwner.clear();
        }
    }

    map<FIELD_IDX_T, map<string, string>> databaseConvMap;
    /* PMSTA-48744 - LJE - 220425 - server_connect special case */
    if (this->targetTableEn == TargetTable_Main &&
        strcmp(targetDictEntityStp->mdSqlName, "server_connect") == 0 &&
        EV_SourceCfgFile != nullptr &&
        EV_TargetCfgFile != nullptr)
    {
        auto &dbConvMap = databaseConvMap[A_ServConnect_Database];
        for (auto srcIt = EV_SourceCfgFile->dbSectionMap.begin(); srcIt != EV_SourceCfgFile->dbSectionMap.end(); ++srcIt)
        {
            auto dstIt = EV_TargetCfgFile->dbSectionMap.find(srcIt->second.dbFct);
            if (dstIt != EV_TargetCfgFile->dbSectionMap.end())
            {
                dbConvMap[srcIt->second.dbSqlName] = dstIt->second.dbSqlName;
            }
        }
    }

    string filterScript;
    if (this->targetTableEn == TargetTable_Main ||
        this->targetTableEn == TargetTable_UserDefinedFields)
    {
        filterScript = this->ddlGenContextPtr->getFilterScript(sourceDictEntityStp);

        if (filterScript.empty() == false)
        {
            this->printMsg(RET_DBA_INFO_EXIST, "Filtered by : (" + filterScript + ")");
        }
    }


    bool        idCheck = false;
    FIELD_IDX_T idPos = Null_Dynfld;

    if ((sourceDictEntityStp->pkRuleEn == PkRule_Identity ||
        sourceDictEntityStp->pkRuleEn == PkRule_ExternalPk) &&
        sourceDictEntityStp->primKeyNbr > 0)
    {
        idCheck = true;
    }
    /* PMSTA-48744 - LJE - 220411 */
    else if (sourceDictEntityStp->pkRuleEn == PkRule_Undefined &&
             sourceDictEntityStp->primKeyNbr == 1 &&
             (sourceDictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
              sourceDictEntityStp->primKeyTab[0]->dataTpProgN == DictType))
    {
        idCheck = true;
    }

    if (bInsertUd)
    {
        idCheck = true;
        idPos = sourceDictEntityStp->getDictAttribBySqlName("ud_id")->progN;

        getIdStream
            << this->newLine() << "#NO_SECURED"
            << this->newLine() << "#NO_MULTI_ENTITY";

        if (filterScript.empty())
        {
            getIdStream
                << this->newLine() << "#SELECT " << sourceDictEntityStp->custSqlName << " null ud"
                << this->newLine() << "id = ud_id"
                << this->newLine() << "#FROM"
                << this->newLine() << "#WHERE"
                << this->newLine() << "#END";
        }
        else
        {
            getIdStream
                << this->newLine() << "#SELECT " << sourceDictEntityStp->custSqlName << " null ud"
                << this->newLine() << "id = ud_id"
                << this->newLine() << "#FROM"
                << this->newLine() << "inner join " << sourceDictEntityStp->mdSqlName << " E on E.id = ud.ud_id"
                << this->newLine() << "#WHERE"
                << this->newLine() << filterScript
                << this->newLine() << "#END";
        }
    }
    else
    {
        if (idCheck)
        {
            idPos = sourceDictEntityStp->primKeyTab[0]->progN;

            getIdStream
                << this->newLine() << "#NO_SECURED"
                << this->newLine() << "#NO_MULTI_ENTITY"
                << this->newLine() << "#SELECT " << sourceDictEntityStp->mdSqlName << " null E"
                << this->newLine() << "id = " << sourceDictEntityStp->primKeyTab[0]->sqlName
                << this->newLine() << "#FROM"
                << this->newLine() << "#WHERE";

            if (filterScript.empty() == false)
            {
                getIdStream
                    << this->newLine() << filterScript;
            }

            getIdStream
                << this->newLine() << "#END";
        }
    }

    ddlGenConnGuard.getDbiConn().setDbName(sourceDictEntityStp->databaseName);
    ddlGenConnGuard.getDbiConnForDdl().setDbName(targetDictEntityStp->databaseName);

    RequestHelper writeRequestHelper(&ddlGenConnGuard.getDbiConnForDdl());
    writeRequestHelper.setReadOnly(true);

    auto& statistics = this->ddlGenEntityPtr->m_statisticsMap[this->targetTableEn];

    if (this->ddlGenContextPtr->checkSourceDbConnection())
    {
        RequestHelper readRequestHelper(&ddlGenConnGuard.getDbiConn());
        readRequestHelper.m_useAlternativeDataServer = true;
        readRequestHelper.setReadOnly(true);

        ID_T targetTotRows = statistics.m_targetTotRows;
        if (targetTotRows < 0 || bInsertUd)
        {
            this->getCountRecord(targetDictEntityStp, string(), this->realSqlName, targetTotRows, false);
            statistics.m_targetTotRows = targetTotRows;
        }

        ID_T totRows = statistics.m_sourceTotRows;
        if (totRows < 0 || bInsertUd)
        {
            this->getCountRecord(sourceDictEntityStp, string(), string(), totRows, true);
            statistics.m_sourceTotRows = totRows;
        }

        if (bInsertUd && statistics.m_sourceTotRows > 0 && statistics.m_sourceTotRows != totRows)
        {
            stringstream msg;
            msg << "Number of ud table records (" << statistics.m_sourceTotRows << ") doesn't match with the main table records (" << totRows << ")";
            ddlGenMsg.printMsg(RET_DBA_INFO_NODATA, msg.str());
        }

        vector<ID_T> allIdsVector;
        if (getIdStream.str().empty() == false &&
            totRows > targetTotRows &&
            targetTotRows > 0)
        {
            writeRequestHelper.setFetchSize(writeRequestHelper.getBatchBlockSize());

            writeRequestHelper.setCommand(getIdStream.str());
            DbiInOutData* idOutputDataPtr = writeRequestHelper.addNewOutputData(IdType, "id");
            ret = writeRequestHelper.sendCommandForFetch();

            allIdsVector.reserve(static_cast<size_t>(totRows));

            stringstream msg;
            std::chrono::steady_clock::time_point readIdStartTime = std::chrono::steady_clock::now();

            msg << "Loading primary keys of already inserted records...";

            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msg.str());

            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                   writeRequestHelper.fetch() == RET_SUCCEED)
            {
                allIdsVector.push_back(GET_ID(idOutputDataPtr->getDynFldStp(), 0));
            }

            auto readIdDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - readIdStartTime);
            msg << " " << allIdsVector.size() << " records read, the duration was: " << readIdDuration.count() << " seconds";
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msg.str());

            std::sort(allIdsVector.begin(), allIdsVector.end());
            targetTotRows = allIdsVector.size();

            writeRequestHelper.finishRequest();
        }

        readStream
            << this->newLine() << "#NO_SECURED"
            << this->newLine() << "#NO_MULTI_ENTITY";

        if (bInsertUd)
        {
            ddlGenMsg.setMsgEntitySqlName(targetDictEntityStp->custSqlName);
            ddlGenMsg.setMsgSqlName(targetDictEntityStp->custSqlName);

            auto columnMap = this->ddlGenContextPtr->getColumnScript(sourceDictEntityStp->custSqlName);
            if (filterScript.empty())
            {
                readStream
                    << this->newLine() << "#SELECT " << sourceDictEntityStp->mdSqlName << " udf std";

                for (auto it = columnMap.begin(); it != columnMap.end(); ++it)
                {
                    readStream
                        << this->newLine() << it->first << " = " << it->second;
                }

                readStream
                    << this->newLine() << "#FROM"
                    << this->newLine() << "#WHERE"
                    << this->newLine() << "#END";
            }
            else
            {
                readStream
                    << this->newLine() << "#SELECT " << sourceDictEntityStp->mdSqlName << " udf ud";

                for (auto it = columnMap.begin(); it != columnMap.end(); ++it)
                {
                    readStream
                        << this->newLine() << it->first << " = " << it->second;
                }

                readStream
                    << this->newLine() << "#FROM"
                    << this->newLine() << "inner join " << sourceDictEntityStp->mdSqlName << " E on E.id = ud.ud_id"
                    << this->newLine() << "#WHERE"
                    << this->newLine() << filterScript
                    << this->newLine() << "#END";
            }
        }
        else
        {
            auto columnMap = this->ddlGenContextPtr->getColumnScript(sourceDictEntityStp->mdSqlName);

            readStream
                << this->newLine() << "#SELECT " << sourceDictEntityStp->mdSqlName << " all_db E";

            for (auto it = columnMap.begin(); it != columnMap.end(); ++it)
            {
                readStream
                    << this->newLine() << it->first << " = " << it->second;
            }

            readStream
                << this->newLine() << "#FROM"
                << this->newLine() << "#WHERE"
                ;

            if (filterScript.empty() == false)
            {
                readStream
                    << this->newLine() << filterScript;
            }

            readStream << this->newLine() << "#END";
        }

        string migrationNbrStr;

        if (totRows != targetTotRows && totRows > 0)
        {
            if (targetTotRows > 0 &&
                totRows != targetTotRows &&
                idCheck == false &&
                this->m_bForceDrop == false)
            {
                writeRequestHelper.setCommand(this->getCmdTruncateTable(targetDictEntityStp, true, false));
                writeRequestHelper.sendAndGetCommand();
                writeRequestHelper.finishRequest();

                targetTotRows = 0;
            }

            unsigned int batchSize = writeRequestHelper.getBatchBlockSize();
            double       percentDone = (targetTotRows == 0 ? 0 : (static_cast<double>(targetTotRows) / totRows) * 100.);
            double       percentAdd = 100;
            unsigned int lastDispProgress = 0;

            if (totRows > batchSize)
            {
                percentAdd = 100. / (totRows / batchSize);
            }

            string msg = SYS_Stringer(currProcessStr, " (", totRows, " rows)...");

            ddlGenMsg.printMsg(RET_SRV_INFO_RUNNING, msg);
            {
                stringstream msgStream;
                msgStream << percentDone << "% (" << targetTotRows << "/" << totRows << ")";

                ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msgStream.str());
            }

            this->prepareDataMigration(sourceDictEntityStp, targetDictEntityStp);

            readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());
            readRequestHelper.setCommand(readStream.str());

            bool bcpMode = SYS_GetEnvBoolOrDefValue("AAAMIGBCPMODE", false);

            if (bcpMode)
            {
                std::string defaultCharset = ddlGenConnGuard.getDbiConnForDdl().getDefaultCharset();
                const char *currCharset = GEN_GetCurCharset(ddlGenConnGuard.getDbiConnForDdl().getCurrCharsetEn(), CharsetCodeType_Rdbms);

                if (defaultCharset != currCharset)
                {
                    bcpMode = false;
                }
                else if (targetDictEntityStp->pkRuleEn == PkRule_Identity &&
                         ddlGenConnGuard.getDbiConnForDdl().m_insertIdentityOn == false)
                {
                    bcpMode = false;
                }

                ddlGenConnGuard.getDbiConnForDdl().getScriptDdlGenPtr()->getDdlGenContextPtr()->m_bBcpMode = bcpMode;
            }

            ddlGenConnGuard.getDbiConn().getScriptDdlGenPtr()->getDdlGenContextPtr()->m_parentContext = this->ddlGenContextPtr;
            readRequestHelper.setFetchSize(readRequestHelper.getBatchBlockSize());
            readRequestHelper.setCommand(readStream.str());
            ddlGenConnGuard.getDbiConn().getScriptDdlGenPtr()->getDdlGenContextPtr()->m_parentContext = ddlGenConnGuard.getDbiConn().getScriptDdlGenPtr()->getDdlGenContextPtr();

            writeRequestHelper.setBatchMode(bcpMode ? DbiConnection::BatchMode::TryBCP : DbiConnection::BatchMode::ExecuteOnce);
            writeRequestHelper.setTransactionMode(RequestHelper::TransactionMode::MostAsPossible);
            writeRequestHelper.optimDataAlloc();
            writeRequestHelper.setBatchInfo(this->ddlGenContextPtr->getDdlDestDbName(), this->getDdlObjSqlName(), targetDictEntityStp->objectEn);
            writeRequestHelper.getScriptDdlGenPtr()->getDdlGenContextPtr()->ddlGenAction.m_bOraNologgingHint = this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint;

            if (this->ddlGenContextPtr->ddlGenAction.m_parallelLoad > 0)
            {
                writeRequestHelper.setBatchASync();
                writeRequestHelper.setParallel(this->ddlGenContextPtr->ddlGenAction.m_parallelLoad);
            }

            dynStEn = GET_EDITGUIST(targetDictEntityStp->objectEn);

            double totReadDuration = 0.0;
            double totWriteDuration = 0.0;

            if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
            {
                DBA_DYNFLD_STP recordStp   = nullptr;
                LONGINT_T      rowNbr      = targetTotRows;
                int            batchRowNbr = 0;

                if (bInsertUd)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_UserDefinedFields);
                    writeRequestHelper.setTargetTable(TargetTable_UserDefinedFields);
                }
                else if (bInsertBe)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_LocalBusinessEntity);
                    writeRequestHelper.setTargetTable(TargetTable_LocalBusinessEntity);
                }
                else if (bInsertMain)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_Main, true);
                    writeRequestHelper.setTargetTable(TargetTable_Main);
                }
                else
                {
                    /* Invalid case */
                    SYS_BreakOnDebug();
                }

                double blkReadDuration = 0.0;
                double blkWriteDuration = 0.0;
                bool   bUseLastRecord = false;

                while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                       readRequestHelper.fetch() == RET_SUCCEED)
                {
                    if (bUseLastRecord == true ||
                        (ret = writeRequestHelper.getNewRecordForBatch(dynStEn, recordStp)) == RET_SUCCEED)
                    {
                        readRequestHelper.readData(recordStp);

                        if (allIdsVector.empty() == false &&
                            std::binary_search(allIdsVector.begin(), allIdsVector.end(), GET_ID(recordStp, idPos)))
                        {
                            bUseLastRecord = true;
                            continue;
                        }
                        bUseLastRecord = false;

                        rowNbr++;
                        batchRowNbr++;
                        if (srcApplOwner.empty() == false)
                        {
                            if (srcApplOwner.compare(GET_SYSNAME(recordStp, A_ApplUser_Cd)) == 0)
                            {
                                SET_SYSNAME(recordStp, A_ApplUser_Cd, dstApplOwner.c_str());
                                SET_SYSNAME(recordStp, A_ApplUser_Name, dstApplOwner.c_str());
                                SET_SYSNAME(recordStp, A_ApplUser_OsUser, dstApplOwner.c_str());
                            }
                            else if (GET_FLAG(recordStp, A_ApplUser_HasDbLoginFlg) == TRUE &&
                                     techUsersSet.find(GET_SYSNAME(recordStp, A_ApplUser_Cd)) == techUsersSet.end())
                            {
                                SET_SYSNAME(recordStp,
                                            A_ApplUser_SuperUserLogin,
                                            ddlGenConnGuard.getDbiConnForDdl().getSpecification().getCredentials().getUser().c_str());
                                SET_SYSNAME(recordStp,
                                            A_ApplUser_SuperUserPasswd,
                                            ddlGenConnGuard.getDbiConnForDdl().getSpecification().getCredentials().getPassword().getClearPassword().getPassword());

                                SET_ENUM(recordStp, A_ApplUser_LoginActionEn, LoginActionEn_Add);

                                string password;
                                SYS_StringFormat(password, migPasswordPattern.c_str(), GET_SYSNAME(recordStp, A_ApplUser_Cd));
                                SET_SYSNAME(recordStp, A_ApplUser_UserPassword, password.c_str());

                                /* PMSTA-46508 - LJE - 211005 - Use a new connection to avoid to use the ongoing standard (multi-thread) */
                                DbiConnectionHelper dbiConnHelper;
                                if (dbiConnHelper.isValidAndInit())
                                {
                                    ret = DBI_InsApplUserDbLogin(recordStp, *dbiConnHelper.getConnection());
                                }
                            }

                            SET_NULL_TEXT(recordStp, A_ApplUser_GuiContextT);
                        }

                        if (databaseConvMap.empty() == false)
                        {
                            for (auto dbConvMap = databaseConvMap.begin(); dbConvMap != databaseConvMap.end(); ++dbConvMap)
                            {
                                if (IS_NULLFLD(recordStp, dbConvMap->first) == false)
                                {
                                    auto dbConvIt = dbConvMap->second.find(GET_STRING(recordStp, dbConvMap->first));
                                    if (dbConvIt != dbConvMap->second.end())
                                    {
                                        SET_STRING(recordStp, dbConvMap->first, dbConvIt->second.c_str());
                                    }
                                }
                            }
                        }

                        auto readDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - readStartTime);

                        std::chrono::steady_clock::time_point  writeStartTime = std::chrono::steady_clock::now();

                        ret = this->executeBatch(false, writeRequestHelper, batchRowNbr, ddlGenMsg);

                        if (ret != RET_GEN_INFO_NOACTION)
                        {
                            auto writeDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - writeStartTime);
                            blkWriteDuration += writeDuration.count();

                            blkReadDuration += readDuration.count();

                            percentDone += percentAdd;

                            unsigned int currProgress = static_cast<int>(percentDone);
                            if (currProgress != lastDispProgress && currProgress != 100)
                            {
                                lastDispProgress = currProgress;

                                stringstream msgStream;
                                msgStream << currProgress << "% (" << rowNbr << "/" << totRows << ") " << std::fixed << std::setprecision(2) << " (r=" << blkReadDuration << " sec, w=" << blkWriteDuration << " sec)";

                                ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msgStream.str());

                                totReadDuration += blkReadDuration;
                                totWriteDuration += blkWriteDuration;
                                blkReadDuration = 0.0;
                                blkWriteDuration = 0.0;
                            }

                            readStartTime = std::chrono::steady_clock::now();
                            batchRowNbr = 0;
                        }
                    }
                }

                /* PMSTA-48744 - LJE - 220411 */
                if (bUseLastRecord)
                {
                    writeRequestHelper.removeLastRecordForBatch();
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    auto readDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - readStartTime);
                    blkReadDuration += readDuration.count();

                    std::chrono::steady_clock::time_point  writeStartTime = std::chrono::steady_clock::now();
                    ret = this->executeBatch(true, writeRequestHelper, batchRowNbr, ddlGenMsg);
                    auto writeDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - writeStartTime);
                    blkWriteDuration += writeDuration.count();

                    totReadDuration += blkReadDuration;
                    totWriteDuration += blkWriteDuration;
                }

                if (ret == RET_SUCCEED && rowNbr == totRows)
                {
                    stringstream msgStream;
                    msgStream << 100 << std::fixed << std::setprecision(2) << "% (r=" << totReadDuration << " sec, w=" << totWriteDuration << " sec)";

                    ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msgStream.str());
                    migrationNbrStr = SYS_Stringer(" (", rowNbr - targetTotRows, " rows migrated)");
                }
                else
                {
                    ret = RET_DBA_ERR_DBPROBLEM;
                    migrationNbrStr = SYS_Stringer(" failed (", rowNbr - statistics.m_targetTotRows - CAST_INT(writeRequestHelper.m_onErrorRequests.size()), " rows migrated), see $AAAHOME/msg/error.log file");
                }
            }

            this->releaseDataMigration(sourceDictEntityStp, targetDictEntityStp);
        }
        else if (totRows == 0)
        {
            migrationNbrStr = SYS_Stringer(" (nothing to migrate)");
        }
        else
        {
            migrationNbrStr = SYS_Stringer(" (", targetTotRows, " rows already migrated)");
        }

        ddlGenMsg.printMsg(ret, currProcessStr + migrationNbrStr);

        this->getCountRecord(targetDictEntityStp, string(), this->realSqlName, statistics.m_targetTotRows, false);
        targetTotRows = statistics.m_targetTotRows;

        if (totRows == targetTotRows && this->ddlGenContextPtr->bCheck)
        {
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, "Checking inserted data...");

            readRequestHelper.setReadOnly(true);
            writeRequestHelper.setReadOnly(true);

            readRequestHelper.setCommand(readStream.str());
            writeRequestHelper.setCommand(readStream.str());

            if ((ret = readRequestHelper.sendCommandForFetch()) == RET_SUCCEED &&
                (ret = writeRequestHelper.sendCommandForFetch()) == RET_SUCCEED)
            {
                if (bInsertUd)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_UserDefinedFields);
                    writeRequestHelper.setDynStOutputData(dynStEn, TargetTable_UserDefinedFields);
                }
                else if (bInsertBe)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_LocalBusinessEntity);
                    writeRequestHelper.setDynStOutputData(dynStEn, TargetTable_LocalBusinessEntity);

                }
                else if (bInsertMain)
                {
                    readRequestHelper.setDynStOutputData(dynStEn, TargetTable_Main, true);
                    writeRequestHelper.setDynStOutputData(dynStEn, TargetTable_Main, true);
                }
                else
                {
                    /* Invalid case */
                    SYS_BreakOnDebug();
                }

                DBA_DYNFLD_STP srcRecordStp = mp.allocDynst(FILEINFO, dynStEn);
                DBA_DYNFLD_STP dstRecordStp = mp.allocDynst(FILEINFO, dynStEn);

                targetTotRows = 0;
                while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                       readRequestHelper.fetch() == RET_SUCCEED &&
                       writeRequestHelper.fetch() == RET_SUCCEED)
                {
                    readRequestHelper.readData(srcRecordStp);
                    writeRequestHelper.readData(dstRecordStp);

                    bool bOk = true;
                    for (auto it = targetDictEntityStp->attr.begin(); it != targetDictEntityStp->attr.end() && bOk; ++it)
                    {
                        if ((*it)->isPhysicalAttribute())
                        {
                            if (CMP_DYNFLD(srcRecordStp, dstRecordStp, (*it)->progN, (*it)->progN, (*it)->dataTpProgN) != 0)
                            {
                                string textStr = SYS_Stringer("Difference found on attribute: ", (*it)->sqlName);
                                ddlGenMsg.printMsg(RET_DBA_ERR_DBPROBLEM, textStr);

                                std::string srcDispData;
                                DBA_DispDynStToString(srcRecordStp, srcDispData, 1);
                                std::string dstDispData;
                                DBA_DispDynStToString(dstRecordStp, dstDispData, 1);

                                textStr += "\nSource: \n" + srcDispData + "\nDestination:\n" + dstDispData;

                                MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                            1,
                                            this->getMsgSqlName().c_str(),
                                            0,
                                            textStr.c_str());

                                bOk = false;
                            }
                        }
                    }

                    if (bOk)
                    {
                        targetTotRows++;
                    }
                }
            }
        }

        if (totRows == targetTotRows)
        {
            ddlGenMsg.printMsg(RET_SUCCEED, SYS_Stringer("Check successful, ", targetTotRows, " rows migrated"));
            ret = RET_SUCCEED;

            if (this->targetTableEn == TargetTable_Main &&
                targetDictEntityStp->custAuthFlg == TRUE &&
                sourceDictEntityStp != nullptr &&
                sourceDictEntityStp->custAuthFlg == FALSE)
            {
                string msg("Filling ud fields records...");
                ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msg);

                if ((ret = this->fillUdFieldsTable(false)) != RET_SUCCEED)
                {
                    msg += " failed";
                }
                else
                {
                    msg += " done";
                }
                this->printMsg(ret, msg);
            }
        }
        else
        {
            if (this->ddlGenContextPtr->getFilterScript(targetDictEntityStp).empty())
            {
                ddlGenMsg.printMsg(RET_DBA_ERR_DBPROBLEM, SYS_Stringer("Check failed, ", targetTotRows, " rows migrated instead of ", totRows));
                ret = RET_DBA_ERR_DBPROBLEM;
            }
            else
            {
                ddlGenMsg.printMsg(RET_DBA_ERR_HIER_WARN, SYS_Stringer("Check failed, ", targetTotRows, " rows migrated instead of ", totRows));
            }
        }

        ddlGenMsg.printMsg(ret, currProcessStr + migrationNbrStr);


        size_t pos = migrationNbrStr.find_first_not_of(" (");

        stringstream migDataStat;

        migDataStat
            << " on entity "
            << std::left << std::setw(30)
            << (bInsertUd ? sourceDictEntityStp->custSqlName : sourceDictEntityStp->mdSqlName)
            << " - "
            << migrationNbrStr.substr(pos, migrationNbrStr.find_first_of(")") - pos);

        this->ddlGenContextPtr->m_migDataStatVector.push_back(migDataStat.str());

    }
    else
    {
        ret = RET_DBA_ERR_DBPROBLEM;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::fillMultiEntityInfo()
**
**  Description :   Fill the user defined fields table if needed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-36919 - LJE - 191004
**
*************************************************************************/
RET_CODE DdlGenTable::fillMultiEntityInfo()
{
    RET_CODE     ret = RET_SUCCEED;
    stringstream insStream;

    if (this->targetTableEn != TargetTable_Main ||
        this->getDdlGenContextPtr()->getMultiEntityLevel() == MultiEntityLevel_None ||
        this->ddlGenEntityPtr->getDictEntityStp()->multiEntityCateg.isOwnerBusinessEntity() == false ||
        this->ddlGenEntityPtr->getDictEntityStp()->ownerBusinessEntAttrStp == nullptr ||
        this->ddlGenContextPtr->isEntityMtmFirstLevel(NullEntity) == true ||
        this->ddlGenContextPtr->isEntityMtmFirstLevel(this->ddlGenEntityPtr->getDictEntityStp()->entDictId) == false)
    {
        return ret;
    }

    string msg("Migration of multi-entity data");
    auto newXdAttribMap = this->ddlGenEntityPtr->newXdAttribMapMap[TargetTable_Main];
    string ownerBESqlName = this->ddlGenEntityPtr->getDictEntityStp()->ownerBusinessEntAttrStp->sqlName;

    if (newXdAttribMap.find(ownerBESqlName) == newXdAttribMap.end())
    {
        return ret;
    }

    this->cmdType = DDlCmdType_Create;

    DdlGenCfgTemplateKey cfgKey(CfgTemplate_Upgrade, 1, DdlObj_Sql, ownerBESqlName);
    auto upgradeTemplate = this->ddlGenContextPtr->getUpgradeFileHelper().getCfgTemplate(cfgKey);

    if (upgradeTemplate != nullptr && upgradeTemplate->bodyStr.empty() == false)
    {
        DdlGenContextPtr tplDlGenContextPtr(new DdlGenContext(this->ddlGenContextPtr->m_rdbmsEn, true));
        DdlGenTriggerPtr ddlGenTriggerPtr(new DdlGenTrigger(this->ddlGenEntityPtr->getDictEntityStp()->objectEn,
                                                            DdlObj_Trigger,
                                                            *tplDlGenContextPtr,
                                                            nullptr,
                                                            this->ddlGenEntityPtr,
                                                            this->fileHelper,
                                                            TargetTable_Main));
        ddlGenTriggerPtr->init(DmlEvent_All, EventPos_All, TriggerPos_None);
        ddlGenTriggerPtr->build();

        string scptToTreat = upgradeTemplate->bodyStr;
        DdlGenDbi::convertSqlBlock(scptToTreat, this->scriptDdlGen);

        if (EV_RdbmsDdlGen == Sybase)
        {
            string tmpProcName("ddlgen_upgrade");

            string dropProcCmd = this->getCmdIfExsists(this->getCmdSelObjInDb(this->getTargetDBName(), this->getEntitySqlName(), tmpProcName, DdlObj_SProc),
                                                        "\t" + this->getDdlModif(this->getCmdDrop(this->getTargetDBName(), this->getEntitySqlName(), tmpProcName, DdlObj_SProc)),
                                                        string());

            this->bodySqlBlock << dropProcCmd;
            (void)this->flush();

            this->bodySqlBlock << this->getCmdCreate(this->getTargetDBName(),
                                                     this->getEntitySqlName(),
                                                     tmpProcName,
                                                     DdlObj_SProc);
            this->printBeginProc(this->bodySqlBlock.bodyStream(), nullptr);

            this->bodySqlBlock << scptToTreat;
            this->bodySqlBlock  << endl << "end" << this->getCmdEndOfCmd() << endl;

            ret = this->flush();

            if (ret == RET_SUCCEED)
            {
                this->bodySqlBlock << "exec " << tmpProcName;
                ret = this->flush(msg);
            }

            this->bodySqlBlock << dropProcCmd;
            (void)this->flush();
        }
        else
        {
            this->bodySqlBlock << scptToTreat;
            ret = this->flush(msg);
        }

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), ownerBESqlName, DdlObj_Column);
            (void)this->flush();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::build()
{
    RET_CODE ret = RET_SUCCEED;
    string   msg;

    bool     bUpdate = (this->m_bForceDrop == false && this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild);

    if (this->getDictEntityStp()->entNatEn == EntityNat_TempTable &&
        DdlGenDbi::isTempTableRuntime(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()))
    {
        return ret;
    }

    if (this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None)
    {
        if (this->getDictEntityStp()->multiEntityCateg.get() != MultiEntityCategory_None &&
            this->ddlGenContextPtr->m_parentContext->m_bHaveMultiEntityCateg == false)
        {
            this->ddlGenContextPtr->m_parentContext->m_bHaveMultiEntityCateg = true;
        }

        DICT_ENTITY_STP targetDictEntityStp = this->getDictEntityStp();
        DICT_ENTITY_STP sourceDictEntityStp = this->getDictEntityStp(true);

        if (this->getDdlGenContextPtr()->isEntityToMigrate(sourceDictEntityStp, targetDictEntityStp, this->targetTableEn) == false)
        {
            return ret;
        }

        if (this->targetTableEn == TargetTable_UserDefinedFields &&
            sourceDictEntityStp != nullptr &&
            sourceDictEntityStp->custAuthFlg == FALSE)
        {
            return RET_SUCCEED;
        }
    }

    if ((ret = DdlGen::build()) != RET_SUCCEED)
    {
        msg += " failed";
        this->printMsg(ret, msg);
        return ret;
    }

    this->dropAttribVector.clear();

    if (this->targetTableEn == TargetTable_UserDefinedFields)
    {
        if (this->getDictEntityStp()->custAuthFlg == FALSE ||
            this->getDictEntityStp()->isPhysicalEntity(this->targetTableEn) == false)
        {
            return RET_GEN_INFO_NOACTION;
        }

        if (this->getDictEntityStp()->primKeyNbr != 1)
        {
            stringstream msgStream;

            ret = RET_GEN_ERR_INVARG;

            msgStream << "Invalid cust_auth_f, the entity " << this->getDictEntityStp()->mdSqlName << " MUST have one and only one primary key attribute!";
            this->printMsg(ret, msgStream.str());
        }
    }

    if (EV_UseAlternativeDataSource)
    {
        DBA_DYNFLD_STP      xdEntityStp = this->ddlGenEntityPtr->getXdEntityStp();
        if (EV_TargetCfgFile != nullptr)
        {
            CFG_OBJECT_SECTION *cfgObjSectionStp = EV_TargetCfgFile->getCfgObjectSectonStp(this->getDictEntityStp());

            if (cfgObjSectionStp != nullptr)
            {
                map<string, CFG_SEG_SECTION>::iterator segIter, idxSegIter;

                this->ddlGenEntityPtr->m_dbFct = cfgObjSectionStp->dbFct;

                if (this->targetTableEn == TargetTable_Precomp)
                {
                    map<string, CFG_TSL_SECTION>::iterator tslIter;

                    if ((tslIter = this->ddlGenContextPtr->getCfgFileHelper().tslSectionMap.find("permanent")) != this->ddlGenContextPtr->getCfgFileHelper().tslSectionMap.end() &&
                        (segIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(tslIter->second.tbSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end() &&
                        (idxSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(tslIter->second.idxSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_PrecompSegmentDictId, segIter->second.segDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_PrecompSegment, segIter->second.segSqlName.c_str());
                    }
                }
                else if (this->targetTableEn == TargetTable_Main ||
                    (this->targetTableEn == TargetTable_UserDefinedFields && IS_NULLFLD(xdEntityStp, A_XdEntity_Segment) == TRUE))
                {
                    if ((segIter = EV_TargetCfgFile->segSectionMap.find(cfgObjSectionStp->tbSeg)) != EV_TargetCfgFile->segSectionMap.end() &&
                        (idxSegIter = EV_TargetCfgFile->segSectionMap.find(cfgObjSectionStp->idxSeg)) != EV_TargetCfgFile->segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_SegmentDictId, segIter->second.segDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Segment, segIter->second.segSqlName.c_str());
                        SET_DICT(xdEntityStp, A_XdEntity_IdxSegmentDictId, idxSegIter->second.segDictId);
                        SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, segIter->second.dbDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Database, segIter->second.dbSqlName.c_str());
                    }
                    else if (IS_NULLFLD(xdEntityStp, A_XdEntity_SegmentDictId) == TRUE &&
                             EV_TargetCfgFile->segSectionMap.empty() == false)
                    {
                        ret = RET_DBA_ERR_NODATA;
                        this->printMsg(ret, "The attribute xd_entity.segment_dict_id must be filled");
                    }

                    if (segIter != EV_TargetCfgFile->segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, segIter->second.dbDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Database, segIter->second.dbSqlName.c_str());
                    }
                    else
                    {
                        map<string, CFG_DB_SECTION>::iterator dbIter;

                        if ((dbIter = EV_TargetCfgFile->dbSectionMap.find(cfgObjSectionStp->dbFct)) != EV_TargetCfgFile->dbSectionMap.end())
                        {
                            SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, dbIter->second.dbDictId);
                            SET_SYSNAME(xdEntityStp, A_XdEntity_Database, dbIter->second.dbSqlName.c_str());
                        }
                    }
                }

                if (this->targetTableEn != TargetTable_Precomp &&
                    IS_NULLFLD(xdEntityStp, A_XdEntity_Segment) == FALSE)
                {
                    this->m_segNameStr = GET_SYSNAME(xdEntityStp, A_XdEntity_Segment);
                }
                else if (this->targetTableEn == TargetTable_Precomp &&
                         IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSegment) == FALSE)
                {
                    this->m_segNameStr = GET_SYSNAME(xdEntityStp, A_XdEntity_PrecompSegment);
                }
            }
        }

        DICT_ENTITY_STP sourceDictEntityStp = this->getDictEntityStp(true);

        if (sourceDictEntityStp != nullptr)
        {
            if (EV_SourceCfgFile != nullptr && EV_SourceRdbmsVendor != Sqlite)
            {
                CFG_OBJECT_SECTION *cfgObjSectionStp = EV_SourceCfgFile->getCfgObjectSectonStp(sourceDictEntityStp);

                if (cfgObjSectionStp != nullptr)
                {
                    map<string, CFG_DB_SECTION>::iterator dbIter;

                    if ((dbIter = EV_SourceCfgFile->dbSectionMap.find(cfgObjSectionStp->dbFct)) != EV_SourceCfgFile->dbSectionMap.end())
                    {
                        sourceDictEntityStp->databaseName = dbIter->second.dbSqlName;
                        sourceDictEntityStp->custDbName = dbIter->second.dbSqlName;
                    }
                }
            }

            for (auto it = this->getDictEntityStp()->attr.begin(); it != this->getDictEntityStp()->attr.end(); ++it)
            {
                if ((*it)->dbMandatoryFlg == TRUE &&
                    (*it)->precompFlg     == FALSE &&
                    (*it)->dfltVal.empty() &&
                    ((*it)->primFlg == FALSE || this->getDictEntityStp()->pkRuleEn != PkRule_Identity))
                {
                    if (sourceDictEntityStp->sortedAttr.find((*it)->sqlName) == sourceDictEntityStp->sortedAttr.end())
                    {
                        string keyStr = SYS_Stringer(this->getDictEntityStp()->mdSqlName, ".", (*it)->sqlName);
                        DdlGenCfgTemplateKey cfgKey(CfgTemplate_Upgrade,
                                                    1,
                                                    DdlObj_Sql,
                                                    keyStr);

                        auto upgradeTemplate = this->ddlGenContextPtr->getUpgradeFileHelper().getCfgTemplate(cfgKey);

                        if (upgradeTemplate != nullptr &&
                            upgradeTemplate->onNullValueStr.empty() == false &&
                            sourceDictEntityStp->sortedAttr.find(upgradeTemplate->onNullValueStr) != sourceDictEntityStp->sortedAttr.end())
                        {
                            (*it)->dfltVal = SYS_Stringer("{", upgradeTemplate->onNullValueStr, "}");
                        }
                        else
                        {
                            (*it)->dbMandatoryFlg = FALSE;
                        }
                    }
                }
            }
        }
    }
    else if (this->ddlGenContextPtr->m_forceTbSeg.empty() == false)
    {
        if (this->ddlGenContextPtr->m_forceTbSegSqlName.empty() ||
            this->ddlGenContextPtr->m_forceTbDbSqlName.empty())
        {
            this->ddlGenContextPtr->fillForcedSegment();
        }
        this->m_segNameStr = this->ddlGenContextPtr->m_forceTbSegSqlName;
        this->ddlGenContextPtr->setDefDdlDestDbName(this->ddlGenContextPtr->m_forceTbDbSqlName);
    }
    else if (this->getDictEntityStp()->entNatEn != EntityNat_TempTable && this->ddlGenEntityPtr != NULL)
    {
        if (EV_GenDdlContext.bSqlFileOnly)
        {
            this->m_segNameStr = "$SEGMENT";
        }
        else if (this->targetTableEn != TargetTable_Precomp &&
                 IS_NULLFLD(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_Segment) == FALSE)
        {
            this->m_segNameStr = GET_SYSNAME(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_Segment);
        }
        else if (this->targetTableEn == TargetTable_Precomp &&
                 IS_NULLFLD(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PrecompSegment) == FALSE)
        {
            this->m_segNameStr = GET_SYSNAME(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PrecompSegment);
        }
    }

    this->setName();

    /* PMSTA-48744 - LJE - 220411 */
    bool bForceDrop = false;
    if (this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None &&
        this->getDictEntityStp()->bIsInitEntity &&
        this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
    {
        bForceDrop = true;
        bUpdate = false;
    }

    if (bUpdate && this->ddlGenEntityPtr != nullptr)
    {
        RET_CODE       loadSysRetCode = this->ddlGenEntityPtr->loadExdEntityFromSysInfo(this->realSqlName);
        DBA_DYNFLD_STP sysXdEntityStp = this->ddlGenEntityPtr->getSysXdEntityStp(this->realSqlName);

        if (sysXdEntityStp == nullptr)
        {
            this->printMsg(RET_DBA_INFO_NODATA, "Table doesn't exists in the database");

            if (this->targetTableEn != TargetTable_UserDefinedFields ||
                this->ddlGenEntityPtr->getSysXdAttribStp(TargetTable_UserDefinedFields, DdlGen::getUdIdSqlName()) == nullptr)
            {
                bUpdate = false;
            }
        }
        else if (this->targetTableEn == TargetTable_UserDefinedFields &&
                 GET_FLAG(sysXdEntityStp, A_XdEntity_CustAuthFlg) == FALSE)
        {
            bUpdate = false;
        }
        /* PMSTA-37366 - LJE - 200204 */
        else if (this->targetTableEn == TargetTable_Precomp &&
                 GET_FLAG(sysXdEntityStp, A_XdEntity_PrecompFlg) == FALSE)
        {
            bUpdate = false;
        }
        /* Drop the view if the view is migrate to a table */
        else if (this->targetTableEn == TargetTable_Main &&
                 loadSysRetCode == RET_SUCCEED &&
                 static_cast<DB_RULE_ENUM>(GET_ENUM(sysXdEntityStp, A_XdEntity_DbRuleEn)) == DbRule_TableBasedOnView)
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->realSqlName.empty() ? this->getDdlObjSqlName() : this->realSqlName, DdlObj_View);

            this->cmdType = DDlCmdType_Drop;
            this->flush();

            /* Refresh system info */
            (void)this->ddlGenEntityPtr->loadExdEntityFromSysInfo(this->realSqlName, true);
            bUpdate = false;
        }
    }

    if (this->bForceDropOnly)
    {
        msg = "Dropping table";

        if ((ret = this->drop()) == RET_SUCCEED)
        {
            msg += " successful";
        }
        else
        {
            msg += " failed";
        }
        this->printMsg(ret, msg);
        return ret;
    }
    else if (bUpdate)
    {
        if (this->bForceTruncate)
        {
            this->bodySqlBlock << this->getCmdTruncateTable(this->getDictEntityStp(), true, false);
            this->cmdType = DDlCmdType_DbProcess;
            msg = "Truncate table";

            if ((ret = this->flush()) == RET_SUCCEED)
            {
                msg += " successful";
            }
            else
            {
                msg += " failed";
            }
            this->printMsg(ret, msg);
        }

        ret = this->update();

        if (ret != RET_DBA_INFO_EXIST)
        {
            if ((ret = this->createConstraints()) != RET_SUCCEED)
            {
                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    this->printMsg(ret, "Creation of constraints skipped");
                }
                else
                {
                    this->printMsg(ret, "Creation of constraints failed");
                }
            }
            else
            {
                this->printMsg(ret, "Creation of constraints successful");
            }

            /* Refresh system info */
            (void)this->ddlGenEntityPtr->loadExdEntityFromSysInfo(this->realSqlName, true);

            ret = this->fillTable();

            /* PMSTA-59436 - LJE - 241002 : Remove primary key if exists before creating indexes */
            if (this->isPKToDo() == false)
            {
                DdlGenFK ddlGenFK(this->getObjectEn(), *this->ddlGenContextPtr, this->ddlGenEntityPtr, this->fileHelper, this->targetTableEn);
                ret = ddlGenFK.createPk();
            }

            return ret;
        }
    }

    msg = "Create table " + this->getDdlObjFullSqlName();

    this->bCreate   = true;
    this->bNewTable = true;

    this->printMsg(RET_SRV_INFO_RUNNING, msg);

    /* No drop for xd_ entities and some other entities */
    if (bForceDrop ||
         (this->m_bForceDrop &&
          this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate &&
          (this->ddlGenContextPtr->bGenFromDbi == false ||
          (this->isDropTableOnBootStrap() &&
           (strncmp(this->getDictEntityStp()->mdSqlName, "xd_", 3) != 0 ||
            strcmp(this->getDictEntityStp()->mdSqlName, "xd_partition") == 0 ||
            strcmp(this->getDictEntityStp()->mdSqlName, "xd_partition_index") == 0) &&
           strcmp(this->getDictEntityStp()->mdSqlName, "script_definition") != 0 &&
           strcmp(this->getDictEntityStp()->mdSqlName, "dict_language") != 0 &&
           strcmp(this->getDictEntityStp()->mdSqlName, "dict_function") != 0 &&
           strcmp(this->getDictEntityStp()->mdSqlName, "dict_segment") != 0 &&
           strcmp(this->getDictEntityStp()->mdSqlName, "dict_user") != 0 &&
           strcmp(this->getDictEntityStp()->mdSqlName, "dict_database") != 0))))
    {
        this->bTableDropped = true;
        string dropMsg = "Dropping table";

        if ((ret = this->drop()) == RET_SUCCEED)
        {
            this->ddlGenEntityPtr->m_statisticsMap[this->targetTableEn].m_targetTotRows = 0;
            dropMsg += " successful";
        }
        else
        {
            dropMsg += " failed";
        }
        this->printMsg(ret, dropMsg);
    }
    else if ((this->m_bForceDrop || this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None) &&
             this->isIfExistsClause(DdlObj_Table) == false)
    {
        this->bCheckIfExists = true;
    }

    if ((ret = this->create()) != RET_SUCCEED)
    {
        msg += " failed";
        this->printMsg(ret, msg);
        return ret;
    }

    if ((ret = this->grant()) != RET_SUCCEED)
    {
        msg += " failed";
        this->printMsg(ret, msg);
        return ret;
    }

    if (this->getDictEntityStp()->entNatEn == EntityNat_TempTable)
    {
        if (this->getDictEntityStp()->entDictId != 4550 &&  /* PMSTA-36919 - LJE - 191206 - Don't drop app_context temporary table */
            this->getDictEntityStp()->entDictId != 4551 &&  /* PMSTA-37366 - LJE - 200212 - Don't drop batch_output temporary table */
            DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Session &&
            (ret = this->drop()) != RET_SUCCEED)
        {
            msg += " failed";
            this->printMsg(ret, msg);
            return ret;
        }
    }
    /* Refresh system info */
    (void)this->ddlGenEntityPtr->loadExdEntityFromSysInfo(this->realSqlName, true);

    if ((ret = this->fillUdFieldsTable(false)) != RET_SUCCEED)
    {
        msg += " failed";
        this->printMsg(ret, msg);
        return ret;
    }

    ret = this->fillTable();

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        msg += " failed";
        this->printMsg(ret, msg);
        return ret;
    }

    this->ddlGenContextPtr->resetContext(string());

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        msg += " successful";
    }
    else
    {
        msg += " failed";
    }
    this->printMsg(ret, msg);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::getCreateCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141016
**
*************************************************************************/
string DdlGenTable::getCreateCmd(bool bOneLine)
{
    if (this->m_bForceTempTable)
    {
        this->setDdlObjEn(DdlObj_TempTable);
    }

    bool bSaveSimulation                = this->ddlGenContextPtr->bSimulation;
    bool bSaveSendInDb                  = this->ddlGenContextPtr->bSendInDb;
    this->ddlGenContextPtr->bSimulation = false;

    this->setName();

    this->clearIndent();

    if (bOneLine)
    {
        this->bCheckIfExists = false;
    }
    this->bNoIndentReset              = true;
    this->ddlGenContextPtr->bSendInDb = false;
    this->bCreate                     = true;
    this->bNewTable                   = true;

    this->create();

    string createCmd = this->ddlGenStream.str();

    if (bOneLine)
    {
        std::replace(createCmd.begin(), createCmd.end(), '\n', ' ');

        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
        {
            createCmd += "; grant all on " + this->getDbDdlObjSqlName() + " to triplea_owner";
        }
    }

    this->ddlGenContextPtr->bSimulation = bSaveSimulation;
    this->ddlGenContextPtr->bSendInDb = bSaveSendInDb;
    return createCmd;
}

/************************************************************************
**
**  Function    :   DdlGenTable::getDeleteCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150520
**
*************************************************************************/
string DdlGenTable::getDeleteCmd()
{
    string createCmd;

    bool bSaveSimulation = this->ddlGenContextPtr->bSimulation;
    bool bSaveSendInDb = this->ddlGenContextPtr->bSendInDb;
    this->ddlGenContextPtr->bSimulation = false;

    this->setName();

    this->clearIndent();

    this->bNoIndentReset = true;
    this->ddlGenContextPtr->bSendInDb = false;
    this->bCreate = true;
    this->bNewTable = true;

    createCmd = this->getDeleteRequest(this->getEntitySqlName(), false) + this->endOfCmd() + "\n";
    createCmd += this->getCleanStatRequest(this->getEntitySqlName());

    this->ddlGenContextPtr->bSimulation = bSaveSimulation;
    this->ddlGenContextPtr->bSendInDb = bSaveSendInDb;
    return createCmd;
}

/************************************************************************
**
**  Function    :   DdlGenTable::getTruncateCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150520
**
*************************************************************************/
string DdlGenTable::getTruncateCmd()
{
    string createCmd;

    if (this->ddlGenContextPtr->m_rdbmsEn == Sqlite)
    {
        createCmd = DdlGenDbi::getTruncateRequest(this->getEntitySqlName());
    }
    else
    {
        bool bSaveSimulation = this->ddlGenContextPtr->bSimulation;
        bool bSaveSendInDb = this->ddlGenContextPtr->bSendInDb;
        this->ddlGenContextPtr->bSimulation = false;

        this->setName();

        this->clearIndent();

        this->bNoIndentReset = true;
        this->ddlGenContextPtr->bSendInDb = false;
        this->bCreate = true;
        this->bNewTable = true;

        string truncProcName = this->scriptDdlGen->buildScript("trunc_#CURR_ENTITY_SQLNAME");
        trim(truncProcName);

        vector<string> emptyVector;
        createCmd = this->getCmdExecSProc(string(), truncProcName, string(), string(), emptyVector, emptyVector, nullptr);
        createCmd += this->getCleanStatRequest(this->getEntitySqlName());

        this->ddlGenContextPtr->bSimulation = bSaveSimulation;
        this->ddlGenContextPtr->bSendInDb = bSaveSendInDb;
    }
    return createCmd;
}

/************************************************************************
**
**  Function    :   DdlGenTable::update()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTable::update()
{
    RET_CODE ret = RET_SUCCEED;
    string   msg;

   msg = "Alter table " + this->getDdlObjFullSqlName();

    this->bCreate = false;
    this->bOptim = false;

    if ((ret = DdlGen::build()) != RET_SUCCEED)
    {
        msg += " failed";
        this->printMsg(RET_SRV_INFO_RUNNING, msg);
        return ret;
    }

    this->printMsg(RET_SRV_INFO_RUNNING, msg);

    /* PMSTA-34200 - LJE - 190114 - Remove primary key of the shadow entities */
    /* PMSTA-37366 - LJE - 200805 - Also for x_ tables */
    if (this->getDictEntityStp()->dbRuleEn == DbRule_ShadowTable ||
        this->targetTableEn == TargetTable_Precomp)
    {
        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                        DdlObj_PrimaryKey,
                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                        this->getEntitySqlName(),
                                        std::string(),
                                        std::string());

        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        auto primaryKey = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getDdlObjDef(searchDdlObjDefKey);

        if (primaryKey != nullptr)
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey);
            this->cmdType = DDlCmdType_Drop;
            ret = this->flush();
        }
    }

    if (this->bForceUpgrade == false)
    {
        ret = this->alter();
    }
    else
    {
        ret = RET_DBA_INFO_NODATA;
    }

    if (ret != RET_DBA_INFO_EXIST)
    {
        if (ret == RET_DBA_INFO_NODATA)
        {
            this->bOptim = true;
            ret = this->alterByIntoExistingTable();
        }

        if (ret != RET_SUCCEED)
        {
            msg += " failed";
            this->printMsg(ret, msg);
            return ret;
        }

        if ((ret = this->fillMultiEntityInfo()) != RET_SUCCEED)
        {
            msg += " failed";
            this->printMsg(ret, msg);
            return ret;
        }

        this->printMsg(ret, msg);
    }

    this->fileHelper = this->fileHelperTable;

    return ret;
}
/************************************************************************
**
**  Function    :   DdlGenTable::printHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - EFE - 130208
**
*************************************************************************/
RET_CODE DdlGenTable::printHeader()
{
    RET_CODE ret = RET_SUCCEED;

    return ret;
}
/************************************************************************
**
**  Function    :   DdlGenTable::printBody()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - EFE - 130208
**
*************************************************************************/
RET_CODE DdlGenTable::printBody()
{
    RET_CODE     ret = RET_SUCCEED;
    stringstream createTableStream;
    string       checkExistsStr;

    bool   bInString = this->bCheckIfExists && this->getDdlModif(string()).empty() == false;

    this->bCreate = true;
    createTableStream << this->getCmdCreate(this->getTargetDBName(),
                                            this->getEntitySqlName(),
                                            this->getDdlObjSqlName(),
                                            this->getDdlObjEn());
    ret = this->getAllAttrib(bInString);

    createTableStream << this->getCreateTable();

    if (this->bCheckIfExists)
    {
        checkExistsStr = this->getCmdSelObjInDb(this->getTargetDBName(),
                                                this->getEntitySqlName(),
                                                this->getDdlObjSqlName(),
                                                this->getDdlObjEn());
    }

    if (this->ddlGenEntityPtr != nullptr)
    {
        createTableStream
            << this->getCmdCreatePhysicalProperties(this->m_segNameStr, this->ddlGenEntityPtr->getXdEntityStp(), nullptr, *this->ddlGenEntityPtr, bInString);
    }

    if (this->asSelectClause.str().empty() == false)
    {
        createTableStream << this->asSelectClause.str();
    }

    if (checkExistsStr.empty())
    {
        this->bodySqlBlock << createTableStream.str();

        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            this->bodySqlBlock << this->endOfCmd();
        }
    }
    else if (checkExistsStr.find("select") != string::npos)
    {
        stringstream elseStream;

        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            this->setIndent(1);

            vector<string> emptyVector;

            elseStream
                << this->getIndent() << this->getCmdExecSProc(string(), "drop_all_constr_by_nm", "'" + this->getEntitySqlName() + "'", string(), emptyVector, emptyVector, nullptr)
                << this->newLine() << this->getCmdExecSProc(string(), "drop_all_idx_by_nm", "'" + this->getEntitySqlName() + "', null", string(), emptyVector, emptyVector, nullptr);

            if (this->isDropTableOnBootStrap() == false &&
                (strncmp(this->getDictEntityStp()->mdSqlName, "xd_", 3) != 0 ||
                 strcmp(this->getDictEntityStp()->mdSqlName, "xd_partition") == 0 ||
                 strcmp(this->getDictEntityStp()->mdSqlName, "xd_partition_index") == 0) &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "script_definition") != 0 &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "dict_language") != 0 &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "dict_function") != 0 &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "dict_segment") != 0 &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "dict_user") != 0 &&
                 strcmp(this->getDictEntityStp()->mdSqlName, "dict_database") != 0)
            {
                elseStream
                    << this->newLine() << this->getCmdTruncateTable(this->getDictEntityStp(), true, true);
            }

            this->setIndent(-1);
        }

        this->bodySqlBlock << this->getCmdIfExsists(checkExistsStr,
                                                    "\t" + this->getDdlModif(createTableStream.str()),
                                                    elseStream.str(),
                                                    true);
    }
    else
    {
        this->bodySqlBlock << this->getCmdIfThen(checkExistsStr, this->getIndent() + this->getDdlModif(createTableStream.str()), true);
    }

    if (this->ddlGenContextPtr->bGenFromDbi && this->bTableDropped == false)
    {
        this->cmdType = DDlCmdType_Create;
        this->flush();

        for (auto it = this->newAttribVector.begin(); it != this->newAttribVector.end(); ++it)
        {
            stringstream alterColumnStream;
            string       ifNotExistsClause = this->getIfExistsClause(DdlObj_Column, true);

            alterColumnStream << "alter table " + this->getDdlObjFullSqlName() + " add " << ifNotExistsClause << it->m_alterCmdStr;

            if (ifNotExistsClause.empty())
            {
                checkExistsStr = this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(),
                                                        this->getEntitySqlName(),
                                                        it->m_colSqlNameStr,
                                                        DdlObj_Column);

                this->bodySqlBlock << this->getCmdIfExsists(checkExistsStr,
                                                            "\t" + this->getDdlModif(alterColumnStream.str()),
                                                            string(),
                                                            true);
            }
            else
            {
                this->bodySqlBlock << alterColumnStream.str() << this->endOfCmd();
            }

            this->cmdType = DDlCmdType_Create;
            this->flush();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTable::printFooter()
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::fillIndexToDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-39990 - LJE - 201221
**
*************************************************************************/
void DdlGenTable::fillIndexToDrop(const std::string &columnSqlName, bool bOnlyFctBased)
{
    /* Search if the attribute is part of a function based index */
    auto &sysXdIndexVector = this->ddlGenEntityPtr->getSysXdIndexVector();
    for (auto &xdIndexStp : sysXdIndexVector)
    {
        bool           bFunctionIdx = (bOnlyFctBased == false) || (this->ddlGenContextPtr->m_rdbmsEn == MSSql);
        bool           bAttribInIdx = false;

        if (this->targetTableEn == TargetTable_Main &&
            strstr(GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName), "upper") != nullptr)
        {
            bFunctionIdx = true;
            bAttribInIdx = true;
        }

        for (auto idxAttribIt = this->ddlGenEntityPtr->getSysXdIndexAttribByRankMap(xdIndexStp).begin();
             idxAttribIt != this->ddlGenEntityPtr->getSysXdIndexAttribByRankMap(xdIndexStp).end() && (bFunctionIdx == false || bAttribInIdx == false);
             ++idxAttribIt)
        {
            DBA_DYNFLD_STP xdIndexAttribStp = idxAttribIt->second;
            if (IS_NULLFLD(xdIndexAttribStp, A_XdIndexAttrib_ColumnExpression) == FALSE)
            {
                string colExpr = lower(GET_STRING(xdIndexAttribStp, A_XdIndexAttrib_ColumnExpression));
                if (DdlGen::find_word(colExpr, columnSqlName, 0, std::string::npos, " \t\n().,\"") != string::npos)
                {
                    bAttribInIdx = true;
                }
                bFunctionIdx = true;
            }
            else if (strcasecmp(columnSqlName.c_str(), GET_SYSNAME(xdIndexAttribStp, A_XdIndexAttrib_XdAttribSqlName)) == 0)
            {
                bAttribInIdx = true;
            }

            if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_SortRuleEn) == SortRule_Descending) /* PMSTA-38801 - JJN - 200202*/
            {
                /* should consider descending sort as function based */
                bFunctionIdx = true;
            }
        }

        if ((bFunctionIdx || this->ddlGenContextPtr->m_rdbmsEn == MSSql) && bAttribInIdx)
        {
            auto dictAttribStp = this->getDictEntityStp()->getDictAttribBySqlName(columnSqlName);

            string dbSqlName;
            if (IS_NULLFLD(xdIndexStp, A_XdIndex_SegmentDictId))
            {
                switch (GET_A_XdIndex_IdxFctEn(xdIndexStp))
                {
                    case XdIndexIdxFctEn::ExtendedFieldsIndex:
                    case XdIndexIdxFctEn::PrimaryKeyPrecomp:
                        dbSqlName = this->getDictEntityStp()->precompDbName;
                        break;

                    default:
                        dbSqlName = this->getDictEntityStp()->databaseName;

                }
            }
            else
            {
                for (auto& it : this->ddlGenContextPtr->getCfgFileHelper().segSectionMap)
                {
                    if (it.second.segDictId == GET_DICT(xdIndexStp, A_XdIndex_SegmentDictId))
                    {
                        dbSqlName = it.second.dbSqlName;
                        break;
                    }
                }
            }

            string tbSqlName;
            if (dictAttribStp->custFlg == TRUE)
            {
                if (this->targetTableEn != TargetTable_UserDefinedFields)
                {
                    continue;
                }

                tbSqlName = dictAttribStp->dictEntityStp->custSqlName;
            }
            else if (dbSqlName == dictAttribStp->dictEntityStp->precompDbName)
            {
                if (this->targetTableEn != TargetTable_Precomp)
                {
                    continue;
                }

                tbSqlName = dictAttribStp->dictEntityStp->precompSqlName;
            }
            else
            {
                if (this->targetTableEn != TargetTable_Main)
                {
                    continue;
                }

                tbSqlName = dictAttribStp->dictEntityStp->dbSqlName;
            }

            if (GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey &&
                (this->isAutoIndexOnPK() || this->isIndexDefinedOnPK()))
            {
                this->m_bPrimaryKey = true;
            }

            if (GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKey || this->isAutoIndexOnPK() == false)
            {
                this->m_indexToDropSet.insert(DdlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                                        DdlObj_Index,
                                                        dbSqlName,
                                                        dictAttribStp->dictEntityStp->mdSqlName,
                                                        tbSqlName,
                                                        GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName)));
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenTable::dropIndexToDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-39990 - LJE - 201221
**
*************************************************************************/
RET_CODE DdlGenTable::dropIndexToDrop()
{
    RET_CODE ret    = RET_SUCCEED;
    RET_CODE gblRet = RET_SUCCEED;

    if (this->m_bPrimaryKey)
    {
        std::map<DdlObjDefKey, DdlObjDef>  primaryKeyDefMap;

        this->getAllDdlObjListFromDb(primaryKeyDefMap,
                                     this->ddlGenContextPtr->getDdlDestDbName(),
                                     this->getEntitySqlName(),
                                     this->getEntitySqlName(),
                                     DdlObj_PrimaryKey);

        auto primaryKeyIt = primaryKeyDefMap.find(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn, 
                                                               DdlObj_PrimaryKey, 
                                                               this->ddlGenContextPtr->getDdlDestDbName(), 
                                                               this->getEntitySqlName(),
                                                               this->getEntitySqlName(),
                                                               this->getEntitySqlName()));

        if (primaryKeyIt != primaryKeyDefMap.end())
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), 
                                                   this->getEntitySqlName(), 
                                                   this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn),
                                                   DdlObj_PrimaryKey);
            this->cmdType = DDlCmdType_Drop;
            ret = this->flush("Drop primary key");
        }
    }

    if (this->m_indexToDropSet.empty() == false)
    {
        for (auto &idxIt : this->m_indexToDropSet)
        {
            this->bodySqlBlock << this->getCmdDrop(idxIt.getDbDbName(), idxIt.getTableSqlName(), idxIt.getDbObjName(), DdlObj_Index);

            this->cmdType = DDlCmdType_Drop;
            ret = this->flush();
            if (ret != RET_SUCCEED)
            {
                gblRet = ret;
            }
        }
        this->m_indexToDropSet.clear();
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTable::dropViewToDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221018
**
*************************************************************************/
RET_CODE DdlGenTable::dropViewToDrop()
{
    RET_CODE ret = RET_SUCCEED;
    RET_CODE gblRet = RET_SUCCEED;

    std::map<std::string, std::set<std::string>> depViewMap;

    for (auto colIt = this->alterAttribVector.begin(); colIt != this->alterAttribVector.end(); ++colIt)
    {
        this->getDependsViewMap(this->ddlGenContextPtr->getDdlDestDbName(), this->getDdlObjSqlName(), colIt->m_colSqlNameStr, depViewMap);
    }

    if (depViewMap.empty() == false)
    {
        for (auto dbIt = depViewMap.begin(); dbIt != depViewMap.end(); ++dbIt)
        {
            for (auto vwIt = dbIt->second.begin(); vwIt != dbIt->second.end(); ++vwIt)
            {
                this->bodySqlBlock << this->getCmdDrop(dbIt->first, string(), *vwIt, DdlObj_View);

                this->cmdType = DDlCmdType_Drop;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }
        }
    }
    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTable::dropConstraintToDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-51581 - LJE - 230117
**
*************************************************************************/
RET_CODE DdlGenTable::dropConstraintToDrop()
{
    RET_CODE ret = RET_SUCCEED;
    RET_CODE gblRet = RET_SUCCEED;

    std::set<std::string> dropConstrSet;

    for (auto colIt = this->dropAttribVector.begin(); colIt != this->dropAttribVector.end(); ++colIt)
    {
        this->getDropConstraintSet(this->ddlGenContextPtr->getDdlDestDbName(), this->getDdlObjSqlName(), colIt->m_colSqlNameStr, dropConstrSet);
    }

    if (dropConstrSet.empty() == false)
    {
        for (auto dropIt = dropConstrSet.begin(); dropIt != dropConstrSet.end(); ++dropIt)
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getDdlObjSqlName(), *dropIt, DdlObj_Constraint);

            this->cmdType = DDlCmdType_Drop;
            ret = this->flush();
            if (ret != RET_SUCCEED)
            {
                gblRet = ret;



            }
        }
    }
    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTable::checkAttribToPhysicallyDelete()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130311
**
*************************************************************************/
RET_CODE DdlGenTable::checkAttribToPhysicallyDelete()
{
    RET_CODE        ret = RET_SUCCEED;

    for (auto it = this->ddlGenEntityPtr->xdAttribToPhysicalDeleteSet.begin(); it != this->ddlGenEntityPtr->xdAttribToPhysicalDeleteSet.end(); ++it)
    {
        DBA_DYNFLD_STP xdAttribStp = (*it);

        if (this->targetTableEn == TargetTable_Main &&
            (GET_ENUM(xdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
             GET_FLAG(xdAttribStp, A_XdAttrib_PrecompFlg) == TRUE) &&
            GET_A_XdAttrib_FeatureEn(xdAttribStp) == XdEntityFeatureFeatureEn::None)
        {
            continue;
        }

        if (this->targetTableEn == TargetTable_UserDefinedFields &&
            GET_ENUM(xdAttribStp, A_XdAttrib_CustomFlg) == Custom_No &&
            GET_ENUM(xdAttribStp, A_XdAttrib_CalcEn) != DictAttr_PhysicalPartition) /* PMSTA-29748 - LJE - 180109 */
        {
            continue;
        }

        if (this->targetTableEn == TargetTable_Precomp &&
            (GET_FLAG(xdAttribStp, A_XdAttrib_PrecompFlg) == FALSE ||
             GET_FLAG(xdAttribStp, A_XdAttrib_MultiLangFlg) == TRUE))
        {
            continue;
        }

        if (DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(xdAttribStp, A_XdAttrib_CalcEn)) == false)
        {
            continue;
        }

        string colSqlName = GET_SYSNAME(xdAttribStp, A_XdAttrib_SqlName);

        if (this->ddlGenEntityPtr->getSysXdAttribStp(this->targetTableEn, colSqlName) == nullptr)
        {
            continue;
        }

        this->dropAttribVector.push_back(colSqlName);

        this->fillIndexToDrop(colSqlName, false); /* PMSTA-39990 - LJE - 201221 */
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::getAllAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTable::getAllAttrib(bool             bInString)
{
    RET_CODE              ret = RET_SUCCEED;
    vector<stringstream>  locStreamVector;
    string                quoteStr(bInString?"'":"");

    DdlGenEntity     *targetDdlGenEntityPtr = this->ddlGenEntityPtr;
    int               identityIncrement     = 1;
    int               identityCache         = 1000;
    DBA_DYNFLD_STP    xdEntityStp           = nullptr;
    DBA_DYNFLD_STP    sysXdEntityStp        = nullptr;
    bool              bToModifyIdentity     = false;

    this->m_indexToDropSet.clear();

    /* PMSTA-48744 - LJE - 220408 */
    DICT_ENTITY_STP   localDictEntityStp = this->getDictEntityStp();

    if (this->ddlGenEntityPtr != nullptr &&
        (xdEntityStp = this->ddlGenEntityPtr->getXdEntityStp()) != nullptr &&
        IS_NULLFLD(xdEntityStp, A_XdEntity_SqlName))
    {
        xdEntityStp = nullptr;
    }

    /* PMSTA-28928 - LJE - 180205 */
    if ((targetDdlGenEntityPtr == nullptr || (xdEntityStp != nullptr &&
                                              strcmp(localDictEntityStp->mdSqlName, GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) != 0)) &&
        this->ddlGenContextPtr != nullptr &&
        this->ddlGenContextPtr->m_bLightContext == false)
    {
        targetDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(localDictEntityStp->mdSqlName, this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr, true);
    }

    if (targetDdlGenEntityPtr != nullptr &&
        this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild)
    {
        xdEntityStp       = targetDdlGenEntityPtr->getXdEntityStp();
        if (this->bTableDropped == false)
        {
            sysXdEntityStp = targetDdlGenEntityPtr->getSysXdEntityStp(this->realSqlName);
        }

        identityCache     = this->ddlGenContextPtr->identityCacheSize;
        if (IS_NULLFLD(xdEntityStp, A_XdEntity_IdentityIncrement) == FALSE &&
            GET_INT(xdEntityStp, A_XdEntity_IdentityIncrement) > 0)
        {
            identityIncrement = GET_INT(xdEntityStp, A_XdEntity_IdentityIncrement);
        }
    }

    this->attribPrintedNbr = 0;

    this->newAttribVector.clear();
    this->alterAttribVector.clear();
    this->alterDbMandatoryAttribVector.clear();
    this->alterDbDefaultAttribVector.clear();

    std::vector<DdlGenUpgrade> newAttribAtEndVector;

    if (this->bCreate == false && sysXdEntityStp != nullptr && xdEntityStp != nullptr)
    {
        if (this->isAddIdentityAllowed() == false &&
            localDictEntityStp->pkRuleEn == PkRule_Identity &&
            GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity)
        {
            if (GET_ENUM(sysXdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity &&
                this->isModifyIdentityAllowed() &&
                ((int)GET_DICT(sysXdEntityStp, A_XdEntity_PrecompDatabaseDictId) != identityCache || GET_INT(sysXdEntityStp, A_XdEntity_IdentityIncrement) != identityIncrement))
            {
                bToModifyIdentity = true;
            }
            else if (GET_ENUM(sysXdEntityStp, A_XdEntity_PkRuleEn) != PkRule_Identity)
            {
                this->bNewIdentity = true;

                if (this->bOptim)
                {
                    this->bForceUpgrade = true;
                }
                else
                {
                    return RET_DBA_INFO_NODATA;
                }
            }
        }

        if (localDictEntityStp->pkRuleEn != PkRule_Identity &&
            GET_ENUM(sysXdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity)
        {
            bToModifyIdentity = true;
        }
    }

    for (auto& dictAttribStp : localDictEntityStp->attr)
    {
        string          sqlName          = dictAttribStp->sqlName;
        bool            bDropIdentity    = false,
                        bModifyDataType  = false,
                        bModifyMandatory = false,
                        bModifyDefault   = false,
                        bModifyIdentity  = false;
        stringstream    locAddAttribStream;


        if (dictAttribStp->xdStatusEn == XdStatus_PhysicallyDeleted ||
            (dictAttribStp->xdStatusEn == XdStatus_Deleted && this->bCreate) || /* PMSTA-24913 - LJE - 161111 */
            dictAttribStp->isPhysicalAttribute() == false ||
            dictAttribStp->logicalFlg == TRUE)
        {
            continue;
        }

        if (this->getOptimisticLockingRule(dictAttribStp) == OptimisticLocking_RowScn)
        {
            continue;
        }
        else if (this->getOptimisticLockingRule(dictAttribStp) == OptimisticLocking_RowVersion)
        {
            sqlName = this->getOptimisticLockingSqlName(localDictEntityStp);
        }
        else if (this->m_bForceTempTable && sqlName == "user")
        {
            sqlName = "user_c";
        }

        /* PMSTA-14452 - LJE - 121105 */
        if (this->targetTableEn == TargetTable_Main &&
            ((localDictEntityStp->dbRuleEn != DbRule_PartialSpecialization && dictAttribStp->custFlg == TRUE) ||
              dictAttribStp->precompFlg == TRUE)) /* PMSTA-32145 - LJE - 180720 */
        {
            continue;
        }

        if (this->targetTableEn      == TargetTable_UserDefinedFields &&
            dictAttribStp->custFlg   == FALSE &&
            dictAttribStp->calcEn    != DictAttr_PhysicalPartition &&           /* PMSTA-29748 - LJE - 180109 */
            (dictAttribStp->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement || this->getDictEntityStp()->custAuthFlg == FALSE))
        {
            continue;
        }

        if (this->targetTableEn       == TargetTable_Precomp &&
            dictAttribStp->precompFlg == FALSE &&
            (dictAttribStp->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement || this->getDictEntityStp()->usePrecompFlg == FALSE))
        {
            continue;
        }

        DBA_DYNFLD_STP  xdAttribStp              = this->ddlGenEntityPtr != nullptr ? this->ddlGenEntityPtr->getXdAttribStp(dictAttribStp) : nullptr;
        DBA_DYNFLD_STP  sysXdAttribStp           = this->bCreate == false && this->ddlGenEntityPtr ? this->ddlGenEntityPtr->getSysXdAttribStp(this->targetTableEn, sqlName) : nullptr;
        string          defaultValueStr          = this->m_bForceTempTable ? "" : dictAttribStp->dfltVal;
        bool            bNewAttrib               = this->bCreate == false && sysXdAttribStp ? false : true;
        DdlGenUpgrade  *ddlGenNewPtr             = nullptr;
        DdlGenUpgrade  *ddlGenAlterPtr           = nullptr;
        DdlGenUpgrade  *ddlGenDefaultPtr         = nullptr;
        DdlGenUpgrade  *ddlGenMandatoryPtr       = nullptr;

        string          copyAttribute;

        /* PMSTA-36919 - LJE - 191001 */
        if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
            localDictEntityStp->dbRuleEn != DbRule_Template &&
            localDictEntityStp->entNatEn != EntityNat_TempTable &&
            this->m_bForceTempTable == false &&
            (this->targetTableEn != TargetTable_Main || this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None) &&
            (this->targetTableEn != TargetTable_Precomp || this->ddlGenEntityPtr->bMultiEntityOnPrecomp == false) &&
            ((this->targetTableEn == TargetTable_UserDefinedFields && this->ddlGenEntityPtr->bMultiEntityOnCustom == false) ||
             (this->targetTableEn != TargetTable_UserDefinedFields && (xdAttribStp == nullptr ||
                                                                       (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert &&
                                                                        (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) != XdAction_None || GET_ENUM(xdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_Inserted))))))
        {
            if (sysXdAttribStp != nullptr)
            {
                this->dropAttribVector.push_back(sqlName);

                this->fillIndexToDrop(sqlName, true);
            }
            continue;
        }

        if (dictAttribStp->dfltVal[0] == '{')
        {
            copyAttribute = dictAttribStp->dfltVal;
            copyAttribute.erase(0, 1);
            copyAttribute.erase(copyAttribute.length() - 1, 1);

            defaultValueStr.clear();
        }

        /* PMSTA-26108 - LJE - 170908 */
        if (defaultValueStr.empty() == false)
        {
            if (GET_CTYPE(dictAttribStp->dataTpProgN) == CharPtrCType ||
                     GET_CTYPE(dictAttribStp->dataTpProgN) == TextPtrCType ||
                     GET_CTYPE(dictAttribStp->dataTpProgN) == UniCharPtrCType ||
                     GET_CTYPE(dictAttribStp->dataTpProgN) == UniTextPtrCType)
            {
                defaultValueStr = "'" + defaultValueStr + "'";
            }
        }
        else if (GET_CTYPE(dictAttribStp->dataTpProgN) == DateTimeStCType &&
                 bNewAttrib &&
                 dictAttribStp->dbMandatoryFlg == TRUE &&
                 this->bCreate == false)
        {
            defaultValueStr = "'31-dec-9999'";
        }

        unsigned int maxDbLenN = dictAttribStp->maxDbLenN;

        if (this->getDictEntityStp()->entNatEn != EntityNat_TempTable &&
            this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild &&
            dictAttribStp->precompFlg == FALSE &&  /* PMSTA-60360 - KKM - 03102024 - precomputed fields should always have maximum database length as equivalent data type length */
            this->getDictEntityStp()->entNatEn != EntityNat_PersistedFmt &&
            this->getDictEntityStp()->entNatEn != EntityNat_SearchFmt &&
            this->getDictEntityStp()->entNatEn != EntityNat_ReportFmt)  /* PMSTA-60824 - Deepthi - 15102024 - Format table columns should always have maximum database length as equivalent data type length */
        {
            /* PMSTA-47414 - LJE - 220119 */
            switch (this->ddlGenContextPtr->getMaxDbLenRule())
            {
                case DdlGenContext::MaxDbLenCreationRule::AlwaysMaxDbLen:
                case DdlGenContext::MaxDbLenCreationRule::RemoveUserDataType:
                    break;

                case DdlGenContext::MaxDbLenCreationRule::AlwaysDataType:
                    maxDbLenN = 0;
                    break;

                case DdlGenContext::MaxDbLenCreationRule::DataTypeForCreate:
                    if (bNewAttrib || this->bCreate)
                    {
                        maxDbLenN = 0;
                    }
                    break;
            }
        }
        else
        {
            maxDbLenN = 0;
        }

        if (sysXdAttribStp != nullptr)
        {
            /* Check the data-type and mandatory flag */
            if (xdAttribStp == nullptr ||
                GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert ||
                (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
                 GET_ENUM(xdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted))
            {
                string     xdDataTypeC, sysDataTypeC;

                xdDataTypeC = DBA_GetAttribEquivDataType(dictAttribStp->dataTpProgN, this->ddlGenContextPtr->m_rdbmsEn, maxDbLenN);  /* PMSTA-38801 - JJN - 200202 */

                /* PMSTA-34373 - LJE - 190218 */
                if (dictAttribStp->primFlg == FALSE || localDictEntityStp->pkRuleEn != PkRule_Identity)
                {
                    if (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_CName) == FALSE)
                    {
                        sysDataTypeC = GET_SYSNAME(sysXdAttribStp, A_XdAttrib_CName);
                    }
                    else if (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_DataTpDictId) == FALSE)
                    {
                        sysDataTypeC = DBA_GetAttribEquivDataType(DATATYPE_DICT_TO_ENUM(GET_DICT(sysXdAttribStp, A_XdAttrib_DataTpDictId)), this->ddlGenContextPtr->m_rdbmsEn, maxDbLenN);  /* PMSTA-38801 - JJN - 200202 */
                    }
                    else
                    {
                        SYS_BreakOnDebug();
                    }

                    /* PMSTA-47414 - LJE - 190219 - j_name_c may contains the user defined data-type */
                    if (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_JName) == FALSE &&
                        this->ddlGenContextPtr->getMaxDbLenRule() == DdlGenContext::MaxDbLenCreationRule::RemoveUserDataType)
                    {
                        bModifyDataType = true;
                    }

                    if (strcasecmp(xdDataTypeC.c_str(), sysDataTypeC.c_str()) != 0 &&
                        (dictAttribStp->dataTpProgN != TextType && dictAttribStp->dataTpProgN != UniTextType && dictAttribStp->dataTpProgN != BlobType && sqlName.compare("owner") != 0)) /* Unsupported migration to native data-type */
                    {
                        bModifyDataType = true;
                    }
                }

                if (dictAttribStp->dbMandatoryFlg != GET_FLAG(sysXdAttribStp, A_XdAttrib_DbMandatoryFlg) &&
                    dictAttribStp->dataTpProgN != TimeStampType &&  /* PMSTA-37374 - LJE - 201118 */
                    (dictAttribStp->custFlg == FALSE ||     /* PMSTA-14452 - LJE - 130301 - Backward compatibility with modif_ud_field.sh */ 
                     sqlName == DdlGen::getUdIdSqlName()))  /* PMSTA-52689 - LJE - 230411 - But not for ud_id */
                {
                    bModifyMandatory = true;
                }

                if ((localDictEntityStp->pkRuleEn == PkRule_NoIdentity || dictAttribStp->primFlg == FALSE))
                {
                    string sysDefaultValueStr = (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_Default) == FALSE ? GET_NAME(sysXdAttribStp, A_XdAttrib_Default) : "");
                    trim(sysDefaultValueStr);

                    if (strcasecmp(sysDefaultValueStr.c_str(), "null") == 0)
                    {
                        sysDefaultValueStr.clear();
                    }

                    if (bToModifyIdentity && dictAttribStp->primFlg == TRUE)
                    {
                        bToModifyIdentity = false;
                        bDropIdentity = true;
                        bModifyIdentity = true;
                    }
                    else if (sysDefaultValueStr != defaultValueStr)
                    {
                        bModifyDefault = true;
                    }
                }
                /* PMSTA-28928 - LJE - 180206 */
                else if (dictAttribStp->primFlg == TRUE && bToModifyIdentity)
                {
                    bToModifyIdentity = false;
                    bModifyIdentity = true;
                }
            }


            if (this->bCreate == false &&
                GET_INT(sysXdAttribStp, A_XdAttrib_Prog) != dictAttribStp->progN &&
                (localDictEntityStp->entNatEn == EntityNat_TempTable ||
                 localDictEntityStp->entNatEn == EntityNat_SearchFmt ||
                 localDictEntityStp->entNatEn == EntityNat_PersistedFmt ||
                 localDictEntityStp->entNatEn == EntityNat_ReportFmt))
            {
                this->bToDrop = true;
                bNewAttrib    = true;
            }
        }

        if (this->bCreate    == false &&
            this->bOptim     == false &&
            bModifyDataType  == false &&
            bModifyMandatory == false &&
            bModifyDefault   == false &&                         /* PMSTA-26108 - LJE - 170815 */
            bModifyIdentity  == false &&
            bNewAttrib       == false &&
            dictAttribStp->xdStatusEn != XdStatus_Untreated && /* PMSTA-13664 - LJE - 120217 */
            dictAttribStp->xdStatusEn != XdStatus_Failed)      /* PMSTA-14452 - LJE - 121107 */
        {
            continue;
        }

        if (this->bCreate                == false &&
            this->bToTruncate            == false &&
            localDictEntityStp->dbRuleEn == DbRule_VolatileTable)
        {
            this->bToTruncate = true;
        }

        stringstream locStream;

        if (bModifyDataType || bModifyIdentity || this->bOptim)
        {
            if (dictAttribStp->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement || bNewAttrib == false)
            {
                this->alterAttribVector.push_back(sqlName);
                ddlGenAlterPtr = &this->alterAttribVector.back();
            }
            else
            {
                newAttribAtEndVector.push_back(sqlName);
                ddlGenAlterPtr = &newAttribAtEndVector.back();
            }
        }
        else if (bNewAttrib)
        {
            if (dictAttribStp->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
            {
                this->newAttribVector.push_back(sqlName);
                ddlGenNewPtr = &this->newAttribVector.back();
            }
            else
            {
                newAttribAtEndVector.push_back(sqlName);
                ddlGenNewPtr = &newAttribAtEndVector.back();
            }

            ddlGenNewPtr->m_bNewAttrib = true;
        }

        if (bModifyMandatory)
        {
            this->alterDbMandatoryAttribVector.push_back(sqlName);
            ddlGenMandatoryPtr = &this->alterDbMandatoryAttribVector.back();
            ddlGenMandatoryPtr->m_bNewAttrib = bNewAttrib;
        }

        /* PMSTA-26250 - LJE - 170327 */
        if (this->bCreate                                    == false &&
            localDictEntityStp->pkRuleEn                     != PkRule_Identity &&
            sysXdEntityStp                                   != nullptr &&
            GET_FLAG(sysXdEntityStp, A_XdEntity_IdentityFlg) == TRUE &&
            dictAttribStp->primFlg                           == TRUE)
        {
            bDropIdentity = true;
        }

        if (defaultValueStr.empty() == false &&
            (GET_CTYPE(dictAttribStp->dataTpProgN) == CharPtrCType ||
            GET_CTYPE(dictAttribStp->dataTpProgN) == TextPtrCType ||
            GET_CTYPE(dictAttribStp->dataTpProgN) == UniCharPtrCType ||
            GET_CTYPE(dictAttribStp->dataTpProgN) == UniTextPtrCType ||
            GET_CTYPE(dictAttribStp->dataTpProgN) == DateTimeStCType))
        {
            defaultValueStr = quoteStr + defaultValueStr + quoteStr;
        }

        if (this->bCreate == false && this->bOptim == true)
        {
            if (copyAttribute.empty() == false)
            {
                defaultValueStr = copyAttribute;
            }

            if (bNewAttrib == false)
            {
                if (bModifyDataType)
                {
                    locStream << this->convert(dictAttribStp->dataTpProgN, sqlName, (dictAttribStp->dbMandatoryFlg == TRUE));
                }
                else if (bModifyMandatory &&
                         dictAttribStp->dbMandatoryFlg == TRUE)
                {
                    if (defaultValueStr.empty() == false)
                    {
                        locStream << this->convert(dictAttribStp->dataTpProgN, "isnull(" + sqlName + ", " + defaultValueStr + ")", (dictAttribStp->dbMandatoryFlg == TRUE));
                    }
                    else
                    {
                        locStream << this->convert(dictAttribStp->dataTpProgN, sqlName, true);
                    }
                }
                else
                {
                    if (this->targetTableEn == TargetTable_UserDefinedFields && dictAttribStp->custFlg == FALSE)
                    {
                        this->bJoinMainTable = true;
                        locStream << "E.";
                    }
                    locStream << sqlName;
                }

                if (this->bOptim && 
                    defaultValueStr.empty() == false && 
                    ddlGenDefaultPtr != nullptr)
                {
                    if (this->isModifyDefaultByReplace())
                    {
                        ddlGenDefaultPtr->m_alterCmdStr = "replace default " + sqlName + " " + defaultValueStr;
                    }
                    else
                    {
                        ddlGenDefaultPtr->m_alterCmdStr = this->getCmdModifyColumn() + sqlName + this->getCmdModifyDefault(bNewAttrib)  + defaultValueStr;
                    }
                }
            }
            else
            {
                if (defaultValueStr.empty())
                {
                    locStream << "NULL";
                }
                else
                {
                    locStream << defaultValueStr;
                }
            }
        }
        else
        {
            if (this->isDescAllInAlterTable() || (bModifyDataType == false && bModifyMandatory == false))
            {
                /* If identity column to modify, use the "insert to existing table" method (Sybase only) */
                if (bDropIdentity &&
                    (this->ddlGenContextPtr->m_rdbmsEn == Sybase || this->ddlGenContextPtr->m_rdbmsEn == MSSql))
                {
                    this->removeIdentitySqlName = sqlName;
                    return RET_DBA_INFO_NODATA;
                }

                if (localDictEntityStp->pkRuleEn == PkRule_Identity && /* PMSTA-21031 - EFE - 20150828 */
                    dictAttribStp->primFlg == TRUE &&
                    this->asSelectClause.str().empty() &&
                    this->m_bForceTempTable == false)
                {
                    if (bModifyIdentity)
                    {
                        locAddAttribStream << " " << this->getCmdIdentity(true, 0, identityIncrement, this->getDictEntityStp(true));
                    }
                    else if (bModifyDataType == false && bModifyMandatory == false)
                    {
                        ID_T startValue = 1;
                        if (this->bNewIdentity == false)
                        {
                            startValue = this->getIdentityStartValue(this->getDictEntityStp(true), 
                                                                     (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None ? 
                                                                      this->ddlGenEntityPtr : nullptr), 
                                                                     false);
                        }

                        locAddAttribStream << " ";
                        locAddAttribStream << this->getCmdIdentity(false,
                                                                   startValue,
                                                                   identityIncrement,
                                                                   this->getDictEntityStp(true));
                    }
                }
            }

            bool bNullable    = dictAttribStp->dbMandatoryFlg == FALSE || this->m_bForceTempTable;
            bool bPartialSpec = (bCreate == false &&
                                 bNewAttrib &&
                                 localDictEntityStp->entNatEn == EntityNat_DerivedEntity &&
                                 localDictEntityStp->dbRuleEn == DbRule_PartialSpecialization);

            if (bPartialSpec)
            {
                if (ddlGenMandatoryPtr == nullptr)
                {
                    this->alterDbMandatoryAttribVector.push_back(sqlName);
                    ddlGenMandatoryPtr               = &this->alterDbMandatoryAttribVector.back();
                    ddlGenMandatoryPtr->m_bNewAttrib = bNewAttrib;
                    ddlGenMandatoryPtr->m_bCustom    = (dictAttribStp->custFlg == TRUE);
                }
                ddlGenMandatoryPtr->m_upgradeCmdStr = "from_linked";

                bNullable        = true;
                bModifyMandatory = (dictAttribStp->dbMandatoryFlg == TRUE);
            }
            else if (bCreate == false && (bNewAttrib || bModifyMandatory))
            {
                string upgradeCmdStr;

                string keyStr = localDictEntityStp->mdSqlName;
                keyStr += "." + sqlName;
                DdlGenCfgTemplateKey cfgKey(CfgTemplate_Upgrade,
                                            1,
                                            DdlObj_Sql,
                                            keyStr);

                auto upgradeTemplate = this->ddlGenContextPtr->getUpgradeFileHelper().getCfgTemplate(cfgKey);

                if (bNewAttrib &&
                    upgradeTemplate != nullptr &&
                    upgradeTemplate->alterStr.empty() == false)
                {
                    bNewAttrib = false;
                    ddlGenNewPtr->m_upgradeCmdStr = this->scriptDdlGen->buildScript(upgradeTemplate->alterStr, DdlObj_Migration);
                    locStream << ddlGenNewPtr->m_upgradeCmdStr;
                }
                else if (bNewAttrib || (bModifyMandatory && dictAttribStp->dbMandatoryFlg == TRUE))
                {
                    if (upgradeTemplate != nullptr)
                    {
                        stringstream upgStream;
                        upgStream
                            << "\t#NO_SECURED" << endl
                            << "\t#NO_MULTI_ENTITY" << endl;

                        if (upgradeTemplate->bodyStr.empty() == false)
                        {
                            upgStream
                                << upgradeTemplate->bodyStr;
                        }
                        else if (upgradeTemplate->onNullValueStr.empty() == false)
                        {
                            upgStream << "#UPDATE " << localDictEntityStp->mdSqlName << " null" <<
                                endl << dictAttribStp->sqlName << " = " << upgradeTemplate->onNullValueStr <<
                                endl << "#WHERE" <<
                                endl << dictAttribStp->sqlName << " is null" <<
                                endl << "#END";
                        }

                        upgradeCmdStr = this->scriptDdlGen->buildScript(upgStream.str(), DdlObj_Sql);
                    }

                    if (upgradeCmdStr.empty())
                    {
                        if (copyAttribute.empty() == false)
                        {
                            upgradeCmdStr = "update " + this->getEntityFullSqlName() + " set " + dictAttribStp->sqlName + " = " + copyAttribute + " where " + dictAttribStp->sqlName + " is null";
                        }
                        else if (defaultValueStr.empty() == false && bNewAttrib == false)
                        {
                            upgradeCmdStr = "update " + this->getEntityFullSqlName() + " set " + dictAttribStp->sqlName + " = " + defaultValueStr + " where " + dictAttribStp->sqlName + " is null";
                        }
                    }

                    if (upgradeCmdStr.empty() == false)
                    {
                        if (ddlGenMandatoryPtr == nullptr)
                        {
                            this->alterDbMandatoryAttribVector.push_back(sqlName);
                            ddlGenMandatoryPtr = &this->alterDbMandatoryAttribVector.back();
                            ddlGenMandatoryPtr->m_bNewAttrib = bNewAttrib;
                        }
                        ddlGenMandatoryPtr->m_upgradeCmdStr = upgradeCmdStr;
                    }
                    else if (dictAttribStp->dbMandatoryFlg == TRUE &&
                             defaultValueStr.empty() &&
                             (localDictEntityStp->pkRuleEn != PkRule_Identity || dictAttribStp->primFlg == FALSE) &&
                             this->bToDrop == false)
                    {
                        if (localDictEntityStp->entNatEn == EntityNat_TempTable ||
                            localDictEntityStp->entNatEn == EntityNat_SearchFmt ||
                            localDictEntityStp->entNatEn == EntityNat_PersistedFmt)
                        {
                            this->bToDrop = true;
                        }
                        else if (dictAttribStp->custFlg == FALSE)
                        {
                            ID_T countRecord;
                            this->getCountRecord(localDictEntityStp, string(), this->realSqlName, countRecord, false);

                            if (countRecord)
                            {
                                stringstream msg;
                                msg << "ALTER TABLE '" << this->getEntitySqlName() << "' can failed. Valid default clause or migration request is required in order to add non-NULL column or to modify to non-NULL '" << sqlName << "'.";

                                this->printMsg(RET_DBA_ERR_INVDATA, msg.str());
                            }
                        }
                    }

                    if (bNewAttrib && 
                        ddlGenMandatoryPtr != nullptr && 
                        dictAttribStp->dbMandatoryFlg == TRUE)
                    {
                        bModifyMandatory = true;
                        bNullable        = true;
                    }
                }
            }

            /* PMSTA-26108 - LJE - 170811 */
            if (bModifyDefault || bNewAttrib || (bModifyMandatory && dictAttribStp->dbMandatoryFlg == TRUE))
            {
                if (this->ddlGenContextPtr->m_rdbmsEn == MSSql &&
                    bModifyMandatory && 
                    dictAttribStp->dbMandatoryFlg == TRUE)
                {
                    this->fillIndexToDrop(dictAttribStp->sqlName, false);
                }

                if ((bNewAttrib && defaultValueStr.empty() == false) || bModifyDefault)
                {
                    stringstream    locDefaultStream;

                    locDefaultStream << this->getCmdModifyDefault(bNewAttrib) << (defaultValueStr.empty() ? string("null") : defaultValueStr);

                    if (bNewAttrib ||
                        (this->isModifyDefaultByReplace() == false && this->isDescAllInAlterTable() == true && this->isOneRequestByAlter() == false))
                    {
                        locAddAttribStream << locDefaultStream.str();

                        if (bNewAttrib == false && ddlGenAlterPtr == nullptr)
                        {
                            this->alterAttribVector.push_back(sqlName);
                            ddlGenAlterPtr = &this->alterAttribVector.back();
                        }
                    }
                    else
                    {
                        if (ddlGenDefaultPtr == nullptr)
                        {
                            this->alterDbDefaultAttribVector.push_back(sqlName);
                            ddlGenDefaultPtr = &this->alterDbDefaultAttribVector.back();
                        }

                        if (ddlGenDefaultPtr != nullptr)
                        {
                            if (this->ddlGenContextPtr->m_rdbmsEn == MSSql && bModifyDefault)
                            {
                                string defConstName = this->getDefaultConstrName(this->ddlGenContextPtr->getDdlDestDbName(), localDictEntityStp->mdSqlName, sqlName);
                                if (defConstName.empty() == false)
                                {
                                    ddlGenDefaultPtr->m_alterCmdStr = " drop constraint " + defConstName + " \n alter table " + this->getEntityFullSqlName();
                                }
                                ddlGenDefaultPtr->m_alterCmdStr += " add" + locDefaultStream.str() + " for " + sqlName;
                            }
                            else
                            {
                                if (this->isModifyDefaultByReplace())
                                {
                                    ddlGenDefaultPtr->m_alterCmdStr = " replace ";
                                }
                                else
                                {
                                    ddlGenDefaultPtr->m_alterCmdStr = this->getCmdModifyColumn();
                                }


                                ddlGenDefaultPtr->m_alterCmdStr += sqlName + locDefaultStream.str();
                            }
                        }
                    }
                }
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == Oracle && bDropIdentity)
            {
                this->removeIdentitySqlName = sqlName;
            }

            if (bModifyDataType && 
                this->ddlGenContextPtr->m_bIsInstallFromScratch == false)
            {
                 this->fillIndexToDrop(dictAttribStp->sqlName, true); /* PMSTA-39990 - LJE - 201221 */
            }

            string nullStr = this->isDescAllInAlterTable() || bNewAttrib ? this->getCmdNullable(bNullable) : string();

            if (nullStr.empty() && dictAttribStp->dbMandatoryFlg == FALSE && bModifyMandatory)
            {
                nullStr = this->getCmdNullable(true);
            }

            /* PMSTA-58084 - LJE - 240729 */
            if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::MemoryOptimzed &&
                IS_STRING_TYPE(dictAttribStp->dataTpProgN) == TRUE)
            {
                locAddAttribStream << " COLLATE Latin1_General_100_CI_AS_SC";
            }

            if (this->bCreate == false &&
                (bNewAttrib || bModifyMandatory || bModifyDataType || (bModifyDefault && this->isModifyDefaultByReplace() == false)))
            {
                if (bNewAttrib)
                {
                    /* PMSTA-32145 - LJE - 180730 */
                    if (xdAttribStp != nullptr)
                    {
                        this->ddlGenEntityPtr->newXdAttribMapMap[targetTableEn].insert(make_pair(sqlName, xdAttribStp));
                    }
                }
                else
                {
                    locStream << this->getCmdModifyColumn();
                }

                if (bNewAttrib || this->isOneRequestByAlter() == false)
                {
                    locStream << sqlName << " " << (bNewAttrib ? "" : this->getCmdModifyDataType())
                        << this->getDataTypeSqlName(dictAttribStp->dataTpProgN, true, maxDbLenN)
                        << locAddAttribStream.str() << nullStr;
                }
                else
                {
                    if (bModifyDataType)
                    {
                        locStream << sqlName << this->getCmdModifyDataType() << " " 
                            << this->getDataTypeSqlName(dictAttribStp->dataTpProgN, true, maxDbLenN);
                    }
                    else if (bModifyMandatory)
                    {
                        locStream << sqlName << this->getCmdNullable(bNullable, true);
                    }
                }
            }
            else if (this->bCreate == true)
            {
                locStream << sqlName << STRING_FillPatern(sqlName, 30, ' ');
                if (this->asSelectClause.str().empty())
                {
                    locStream << "\t"
                        << this->getDataTypeSqlName(dictAttribStp->dataTpProgN, true, maxDbLenN) 
                        << locAddAttribStream.str() << nullStr;  /* PMSTA-38801 - JJN - 200202 */
                }
            }
        }

        if (locStream.str().empty() == false)
        {
            if (ddlGenNewPtr != nullptr)
            {
                if (ddlGenNewPtr->m_upgradeCmdStr.empty())
                {
                    ddlGenNewPtr->m_alterCmdStr = locStream.str();

                    if (ddlGenMandatoryPtr != nullptr && bModifyMandatory)
                    {
                        ddlGenMandatoryPtr->m_alterCmdStr = this->getCmdModifyColumn() + sqlName + " " +
                            this->getDataTypeSqlName(dictAttribStp->dataTpProgN, true, dictAttribStp->maxDbLenN);

                        if (this->isOneRequestByAlter() == false)
                        {
                            ddlGenMandatoryPtr->m_alterCmdStr += this->getCmdNullable(dictAttribStp->dbMandatoryFlg == FALSE);  /* PMSTA-38801 - JJN - 200202 */
                        }
                    }
                }
            }
            else if (ddlGenMandatoryPtr != nullptr)
            {
                ddlGenMandatoryPtr->m_alterCmdStr = locStream.str();

                if (ddlGenAlterPtr && this->bOptim == false)
                {
                    this->alterAttribVector.pop_back();
                }
            }
            else if (ddlGenAlterPtr != nullptr)
            {
                ddlGenAlterPtr->m_alterCmdStr = locStream.str();
            }
            this->attribPrintedNbr++;
        }
        else
        {
            if (ddlGenNewPtr != nullptr)
            {
                this->newAttribVector.pop_back();
            }
            else if (ddlGenMandatoryPtr != nullptr)
            {
                this->alterDbMandatoryAttribVector.pop_back();
            }
            else if (ddlGenAlterPtr != nullptr)
            {
                this->alterAttribVector.pop_back();
            }
        }
    }

    for (auto it = newAttribAtEndVector.begin(); it != newAttribAtEndVector.end(); ++it)
    {
        if (this->bOptim)
        {
            this->alterAttribVector.push_back(*it);
        }
        else
        {
            this->newAttribVector.push_back(*it);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTable::createConstraints()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTable::createConstraints()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    auto dictEntityStp = this->getDictEntityStp();

    if (dictEntityStp->entNatEn == EntityNat_TempTable ||
        dictEntityStp->entNatEn == EntityNat_ReportFmt ||
        this->getDdlGenContextPtr()->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate ||
        this->ddlGenContextPtr->m_rdbmsEn == Sqlite)
    {
        return ret;
    }
    else if (this->ddlGenContextPtr->bGenFromDbi)
    {
        return RET_GEN_INFO_NOACTION;
    }

    set<DdlObjDef>                allConstrDefSet;
    map<DdlObjDefKey, DdlObjDef>  allDbConstrDefMap;

    if (this->ddlGenContextPtr->bGenFromDbi == false)
    {
        this->getAllDdlObjListFromDb(allDbConstrDefMap,
                                     this->ddlGenContextPtr->getDdlDestDbName(),
                                     this->getDdlObjSqlName(),
                                     this->getDdlObjSqlName(),
                                     DdlObj_Constraint);
    }

    this->m_ddlObjEn = DdlObj_Constraint;
    this->cmdType  = DDlCmdType_Create;

    this->clear();

    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel == 6)
    {
        DBA_DYNFLD_STP admArgStp = this->m_mp.allocDynst(FILEINFO, Adm_Arg);

        SET_SYSNAME(admArgStp, Adm_Arg_Sysname, this->getEntitySqlName().c_str());
        SET_CODE(admArgStp, Adm_Arg_Code, "constraint");

        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

        /* Drop all constraints of the current table */
        DBA_Notif2(XdEntity,
                   UNUSED,
                   Adm_Arg,
                   admArgStp,
                   DBA_SET_CONN | DBA_NO_CLOSE,
                   ddlGenConnGuard.getDbiConn());
    }

    for (auto& dictAttribStp : dictEntityStp->attr)
    {
        /* PMSTA-14452 - LJE - 121105 */
        if (this->targetTableEn == TargetTable_Main &&
            (dictAttribStp->custFlg == TRUE || dictAttribStp->precompFlg == TRUE))
            continue;

        if (this->targetTableEn == TargetTable_UserDefinedFields &&
            dictAttribStp->custFlg == FALSE &&
            dictAttribStp->calcEn != DictAttr_PhysicalPartition)        /* PMSTA-29748 - LJE - 180109 */
            continue;

        if (this->targetTableEn == TargetTable_Precomp &&
            dictAttribStp->precompFlg == FALSE)
            continue;

        if (dictAttribStp->isPhysicalAttribute() == false ||
            dictAttribStp->permValMap.empty())
        {
            continue;
        }

        stringstream constrStream;

        bool bFirst = true;
        if (dictAttribStp->dataTpProgN == EnumType ||
            dictAttribStp->dataTpProgN == FlagType ||
            dictAttribStp->dataTpProgN == EnumMaskType)
        {
            string constName;

            constName.append("_");
            constName.append(dictAttribStp->sqlName);
            if (constName.substr(constName.length() - 2, 2).compare("_e") == 0 ||
                constName.substr(constName.length() - 2, 2).compare("_f") == 0)
            {
                constName.erase(constName.length() - 2, 2);
            }
            else if (constName.substr(constName.length() - 3, 3).compare("_em") == 0)
            {
                constName.erase(constName.length() - 3, 3);
            }

            constName.append("_chk");
            constName = dictEntityStp->mdSqlName + constName;

            if (constName.length() > this->getMaxDDLObjLength() ||
                allConstrDefSet.find(DdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                               DdlObj_Constraint, 
                                               this->ddlGenContextPtr->getDdlDestDbName(), 
                                               dictEntityStp->mdSqlName,
                                               this->getDdlObjSqlName(), 
                                               constName)) != allConstrDefSet.end())
            {
                stringstream constStream;
                constStream << "e" << dictEntityStp->entDictId << "_a" << dictAttribStp->attrDictId << "_chk";
                constName = constStream.str();
            }

            string constrForCheckStr;

            if ((dictAttribStp->dataTpProgN == EnumType ||
                dictAttribStp->dataTpProgN == FlagType))
            {

                if (ret == RET_SUCCEED)
                {
                    stringstream checkStream;

                    constrStream << this->getCmdCreate(this->getTargetDBName(),
                                                       this->getEntitySqlName(),
                                                       constName,
                                                       DdlObj_Constraint)
                        << " check("; 

                    /* PMSTA-18119 - LJE - 140513 */
                    if (dictAttribStp->permAuthEn != PermAuth_No ||
                        ((this->getObjectEn() == DictPermVal || this->getObjectEn() == XdPermVal) && strcmp(dictAttribStp->sqlName, "perm_val_nat_e") == 0))
                    {
                        switch (this->ddlGenContextPtr->m_rdbmsEn)
                        {
                            case MSSql:
                                checkStream << "[" << dictAttribStp->sqlName << "]>=(0) AND [" << dictAttribStp->sqlName << "]<=(255)";
                                break;

                            default:
                                checkStream << dictAttribStp->sqlName << " between 0 and 255";
                        }
                    }
                    else
                    {
                        switch (this->ddlGenContextPtr->m_rdbmsEn)
                        {
                            case MSSql:
                                break;

                            default:
                                checkStream << dictAttribStp->sqlName << " in (";
                        }

                        for (auto permValIt = dictAttribStp->permValMap.begin(); permValIt != dictAttribStp->permValMap.end(); ++permValIt)
                        {
                            if (bFirst)
                            {
                                bFirst = false;
                            }
                            else
                            {
                                switch (this->ddlGenContextPtr->m_rdbmsEn)
                                {
                                    case MSSql:
                                        checkStream << " OR ";
                                        break;

                                    default:
                                        checkStream << ", ";

                                }
                            }

                            switch (this->ddlGenContextPtr->m_rdbmsEn)
                            {
                                case MSSql:
                                    checkStream << SYS_Stringer("[", dictAttribStp->sqlName, "]=(", (int)permValIt->second.permVal, ")");
                                    break;

                                default:
                                    checkStream << (int)permValIt->second.permVal;
                            }
                        }

                        switch (this->ddlGenContextPtr->m_rdbmsEn)
                        {
                            case MSSql:
                                break;

                            default:
                                checkStream << ")";
                        }
                    }

                    if (constrForCheckStr.empty())
                    {
                        constrForCheckStr = checkStream.str();
                    }

                    constrStream << checkStream.str();
                    constrStream << ")" << this->getCmdEndDDLObj() << endl;
                }
            }

            if (this->ddlGenContextPtr->bGenFromDbi)
            {
                this->cmdType = DDlCmdType_Drop;
                this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), constName, DdlObj_Constraint),
                                                            "\t" + this->getDdlModif(this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), constName, DdlObj_Constraint)),
                                                            string());
                (void)this->flush();

                this->bodySqlBlock << constrStream.str();
                this->cmdType = DDlCmdType_Create;
                ret = this->flush();

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
            else if (constrStream.str().empty() == false)
            {
                auto constrDbIt = allDbConstrDefMap.find(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                                      DdlObj_Constraint, 
                                                                      this->ddlGenContextPtr->getDdlDestDbName(),
                                                                      this->getEntitySqlName(),
                                                                      this->getDdlObjSqlName(), 
                                                                      constName));

                allConstrDefSet.insert(DdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                                 DdlObj_Constraint,
                                                 this->ddlGenContextPtr->getDdlDestDbName(), 
                                                 this->getEntitySqlName(),
                                                 this->getDdlObjSqlName(), 
                                                 constName));

                string dbConstrStr;

                if (constrDbIt != allDbConstrDefMap.end())
                {
                    if (constrDbIt->second.m_searchCondition.empty())
                    {
                        stringstream dbConstrStream;
                        string savedDdlObjSqlName = this->getDdlObjSqlName();
                        this->setDdlObjSqlName(constName);
                        this->getDdlObjFromDb(dbConstrStream, DdlObj_Constraint);
                        this->setDdlObjSqlName(savedDdlObjSqlName);

                        dbConstrStr = dbConstrStream.str();
                    }
                    else
                    {
                        dbConstrStr = constrDbIt->second.m_searchCondition;
                    }

                    if (constrForCheckStr.empty() == false)
                    {
                        trim(dbConstrStr);
                        trim(constrForCheckStr);
                        if (constrForCheckStr[constrForCheckStr.length() - 1] == ';')
                        {
                            constrForCheckStr.erase(constrForCheckStr.length() - 1);
                        }

                        if (dbConstrStr[0] == '(')
                        {
                            dbConstrStr = dbConstrStr.substr(1, dbConstrStr.length() - 2);
                        }
                    }
                }

                if (dbConstrStr.empty() || dbConstrStr.compare(constrForCheckStr) != 0)
                {
                    if (constrDbIt != allDbConstrDefMap.end())
                    {
                        this->cmdType = DDlCmdType_Drop;
                        this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), constName, DdlObj_Constraint);
                        ret = this->flush();
                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            gblRet = ret;
                        }
                    }

                    this->bodySqlBlock << constrStream.str();
                    this->cmdType   = DDlCmdType_Create;
                    ret = this->flush();
                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        this->printMsg(ret, "Add constraint '" + constName + "' failed");
                        gblRet = ret;
                    }
                }
                else if (constrDbIt != allDbConstrDefMap.end() &&
                         constrDbIt->second.m_bValidated == false)
                {
                    /* Enable the primary key of the current entity */
                    this->cmdType = DDlCmdType_DbProcess;
                    this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), constName, DdlObj_Constraint, false);
                    ret = this->flush("Enable primary key");
                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        gblRet = ret;
                    }
                }
            }
        }
    }

    if (this->ddlGenContextPtr->bGenFromDbi == false) /* PMSTA-26108 - LJE - 170811 */
    {
        /* Drop obsolete constraints */
        for (auto it = allDbConstrDefMap.begin(); it != allDbConstrDefMap.end(); ++it)
        {
            if (allConstrDefSet.find(it->second) == allConstrDefSet.end())
            {
                this->cmdType = DDlCmdType_Drop;
                this->bodySqlBlock << this->getCmdDrop(this->getTargetDBName(), this->getEntitySqlName(), it->second.getDbObjName(), DdlObj_Constraint);
                ret = this->flush();
                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }
    }

    this->m_ddlObjEn = DdlObj_Table;

    return gblRet;
}

/*************************************************************************
**   END  ddlgentable.cpp                                        Odyssey **
*************************************************************************/


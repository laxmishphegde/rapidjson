/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB04_H
#define FINLIB04_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib04.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINLIB04_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN int      FIN_SearchInstrInMktSegt(PTR, ID_T, ID_T, DBA_DYNFLD_STP, ID_T, FLAG_T,
					                    SCPT_CLASSIFSTACK_STP, int , int* , /* REF3678 - RAK - 990817 - Add hierHead ptr */
										int, DBA_DYNFLD_STP *); /* REF8834 - CHU - 031119 */ /* REF9715 - CHU - 041124 */

EXTERN ID_T	FIN_SearchInstrInGrid(PTR, ID_T, ID_T, DBA_DYNFLD_STP, ID_T, FLAG_T,
				      SCPT_CLASSIFSTACK_STP, DATETIME_STP, FLAG_T, int, FLAG_T, /* PMSTA08737 - LJE - 091223 */
					  DBA_DYNFLD_STP *, int, int*,FLAG_T * = NULL, DBA_DYNFLD_STP = NULLDYNST, FLAG_T = FALSE);	/* REF3678 - RAK - 990817 - Add hierHead ptr */ /* REF7420 - LJE - 020523 */

EXTERN RET_CODE FIN_Classify(DICT_T, ID_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PTR, DBA_HIER_HEAD_STP,
                             DATETIME_STP, DBA_DYNFLD_STP, FLAG_T, FLAG_T,int, int*, FLAG_T* = NULL, DBA_DYNFLD_STP = NULLDYNST, FLAG_T = FALSE),
                FIN_CrtYield(ID_T, DBA_DYNFLD_STP, DATETIME_T,
                             FIN_CRTYIELD_STP, NUMBER_T*, DBA_HIER_HEAD_STP),	/* REF1384 */
                FIN_IsInList(DBA_HIER_HEAD_STP, ID_T, DBA_DYNFLD_STP, OBJECT_ENUM, ID_T,
                             DBA_DYNFLD_STP *, int *, FLAG_T, DATETIME_STP, FLAG_T *, DBA_DYNFLD_STP aPtfStp = NULLDYNST),
		FIN_InstrChrono(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* DVP172 */
		FIN_InstrChronoArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T,
                             DBA_DYNFLD_STP, ENUM_T, ID_T, MISSINGDATA_METHOD_ENUM, ID_T, ID_T, FLAG_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF7061 - TEB - 030123 */ /* REF10598 - LJE - 041008 */
		FIN_InstrPriceArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T,
				    DBA_DYNFLD_STP, ID_T, ID_T, DBA_DYNFLD_STP,
                                    DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
		FIN_InstrPriceArray2(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T,
				    DBA_DYNFLD_STP, ID_T, MISSINGDATA_METHOD_ENUM, ID_T, DBA_DYNFLD_STP, /* REF7061 - TEB - 030127 */
                                    DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T),  /* PMSTA - 32764 - SILPA - 181010 */
        FIN_ExchRateArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T,
				  ID_T, MISSINGDATA_METHOD_ENUM, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* REF7061 - TEB - 030127 */
		FIN_PtfChronoArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T, DBA_DYNFLD_STP,
				    ENUM_T, ID_T, MISSINGDATA_METHOD_ENUM, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF7061 - TEB - 030123 */
		FIN_ComplChronoArray(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),  /* PMSTA06646 - LJE - 080612 */
		FIN_ListChronoArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T, DBA_DYNFLD_STP, /* REF7292 - LJE - 020130 */
				    ENUM_T, ID_T, MISSINGDATA_METHOD_ENUM, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF7061 - TEB - 030123 */
		FIN_ThirdChronoArray(DATETIME_T, TINYINT_T, ENUM_T, int, ID_T,
				    ENUM_T, ID_T, MISSINGDATA_METHOD_ENUM, DBA_DYNFLD_STP), /* REF7061 - TEB - 030123 */
		FIN_Stat(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
                FIN_Regr(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),
                FIN_CalcArrayDiff(DBA_DYNFLD_STP, DBA_DYNFLD_STP *),
                FIN_CalcArrayLogn(DBA_DYNFLD_STP, DBA_DYNFLD_STP *),
                FIN_CompInstrChrono(DBA_DYNFLD_STP),
				FIN_CompComplChrono(DBA_DYNFLD_STP), /* PMSTA-18426 - CHU - 141028 */
                FIN_Dura(DBA_DYNFLD_STP,FLAG_T,DBA_DYNFLD_STP,DBA_DYNFLD_STP,PTR,DBA_DYNFLD_STP), /* REF9082 - TEB - 030528 */
                FIN_MDura(DBA_DYNFLD_STP,FLAG_T,DBA_DYNFLD_STP,DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,DBA_DYNFLD_STP),/* REF9082 - TEB - 030528 */
                FIN_Conv(DBA_DYNFLD_STP,FLAG_T,DBA_DYNFLD_STP,DBA_DYNFLD_STP,PTR,DBA_DYNFLD_STP), /* REF9082 - TEB - 030530 */
                FIN_OptSens(DBA_DYNFLD_STP ,FLAG_T,DBA_DYNFLD_STP, DBA_DYNFLD_STP,PTR,double*),   /* REF9082 - TEB - 030610 */
				FIN_EstVol(DBA_DYNFLD_STP , DBA_DYNFLD_STP ,PTR, double*),						  /* REF10531 - TEB - 040806 */
                FIN_CalcStat(double*, int, DBA_DYNFLD_STP); /* REF8705 - LJE - 030120 */

/* REF7395 - CSY - 020620 */
EXTERN FLAG_T   FIN_IsTotaliser(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP);

EXTERN  DBA_DYNFLD_STP  FIN_SetInstrInStratHier(PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
												DBA_DYNFLD_STP, DBA_DYNFLD_STP, ID_T*,
												SCPT_CLASSIFSTACK_STP, int, int*, int); /* REF8834 - CHU - 031119 */


EXTERN FLAG_T FIN_IsInListCompoAtDate(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T, DICT_T,
									  DBA_DYNFLD_STP, int, DATETIME_T*,
									  DBA_DYNFLD_STP**, int*, int, int); /* REF7318 - LJE - 020122 */

/* REF8831 - LJE - 030219 */
EXTERN RET_CODE FIN_GetClassifCompo(ID_T, ID_T, DBA_DYNFLD_STP*, int*);

#endif /* FINLIB04_H */

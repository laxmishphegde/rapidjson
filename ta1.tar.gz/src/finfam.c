/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINFAM_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "hier.h"
#include "finfam.h"

#if 0
#include "tls.h"
#include "dba.h"
#include "syslib.h"
#include "fin.h"
#include "scpt.h"
#include "scptyl.h"
#include "scelib.h"
#endif

/************************************************************************
**      External entry points
**
**  FIN_FamilyIsLeaf()	        Check if an element is a leaf or not.
**  FIN_GetFamilyRoot()			Return the root of the family.
**  FIN_GetFamilyElt()			Get an element of the Family.
**  FIN_CreateFamily()			Create a family.
**  FIN_SelChildren()			Select all the children for an element
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC int FIN_CmpEltId(const void *, const void *, const void *);

STATIC RET_CODE FIN_AddFamilyRec(DBA_DYNST_ENUM, int, int, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *),
                FIN_CreateEltTab(DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP **),
                FIN_UpdateEltTabExtension(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int),
                FIN_FindRecord(DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, int, ID_T, DBA_DYNFLD_STP *),
                FIN_SelChildrenInternal(DBA_DYNFLD_STP, int, DBA_DYNFLD_STP **, int *, int);

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    : FIN_FamilyIsLeaf()
**
**  Description : Check if an element is a leaf in the family.
**                A leaf, is an element without child. 
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                eltId           Id of the element to check.
**                hierHead        Pointer on hierarchy header. 
**                isLeafFlg       Result of the function.
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
EXTERN RET_CODE FIN_FamilyIsLeaf(DBA_DYNST_ENUM    dynSt, 
			  				     int               parentFldIdx,
							     int               idFldIdx, 
							     ID_T              eltId, 
								 DBA_HIER_HEAD_STP hierHead,
							     FLAG_T            *isLeafFlg)
{
	DBA_DYNFLD_STP    eltRec;

	(*isLeafFlg) = FALSE;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE ||
		isLeafFlg == NULLDYNSTPTR)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	(*isLeafFlg) = FALSE;

	if (FIN_CreateFamily(dynSt, parentFldIdx, idFldIdx, hierHead) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (FIN_GetFamilyElt(dynSt, parentFldIdx, idFldIdx, eltId, hierHead, &eltRec) == RET_SUCCEED)
	{
		if (IS_NULLFLD(eltRec, A_FamilyElt_ChildrenExt) == TRUE)
			(*isLeafFlg) = TRUE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_GetFamilyRoot()
**
**  Description : Return the root of a family.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                hierHead        Pointer on hierarchy header. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
EXTERN RET_CODE FIN_GetFamilyRoot(DBA_DYNST_ENUM    dynSt, 
			  				      int               parentFldIdx,
							      int               idFldIdx, 
								  ID_T              eltId,
								  DBA_DYNFLD_STP    *rootRec,
								  DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP    eltRec, parentElt, *familyDefTab=NULLDYNSTPTR;
	int               familyDefNbr=0, i;
	FLAG_T            error = FALSE;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE ||
		rootRec == NULLDYNSTPTR)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	(*rootRec) = NULLDYNST;

	if (FIN_CreateFamily(dynSt, parentFldIdx, idFldIdx, hierHead) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (eltId != 0)
	{
		FIN_GetFamilyElt(dynSt, parentFldIdx, idFldIdx, eltId, hierHead, &eltRec);
		parentElt=eltRec;

		while (parentElt != NULL && IS_NULLFLD(parentElt, A_FamilyElt_ParentExt) == FALSE && error == FALSE)
		{
		    parentElt = *(GET_EXTENSION_PTR(parentElt, A_FamilyElt_ParentExt));

			/* if the first element is found, their is a loop, it's an error stop searching */
			if (parentElt == eltRec)
				error = TRUE;
		}

		if (error == FALSE)
		{
			(*rootRec) = parentElt;
		}
	}
	else
	{
		if (DBA_ExtractHierEltRec(hierHead, A_FamilyDef, FALSE, NULLFCT, NULLFCT,
								  &familyDefNbr, &familyDefTab) != RET_SUCCEED)
		{
			return(RET_DBA_ERR_HIER);
		}

		for (i=0; i < familyDefNbr && (*rootRec) == NULLDYNST; i++)
		{
			if (GET_INT(familyDefTab[i], A_FamilyDef_DynSt) == dynSt && /* PMSTA-18696 - DDV - 141001 - DynStEnum is not ENUM_T !!! change A_FamilyDef_DynSt to INT_T */
				GET_INT(familyDefTab[i], A_FamilyDef_ParentFldIdx) == parentFldIdx &&
				GET_INT(familyDefTab[i], A_FamilyDef_IdFldIdx) == idFldIdx)
			{
				if (IS_NULLFLD(familyDefTab[i], A_FamilyDef_RootExt) == FALSE)
				{
					(*rootRec) = *(GET_EXTENSION_PTR(familyDefTab[i], A_FamilyDef_RootExt));
				}
			}
		}

	}

	FREE(familyDefTab);
	if ((*rootRec) == NULLDYNST)
	{
		return(RET_GEN_ERR_INVARG);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_GetFamilyElt()
**
**  Description : Return an element of a Family.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                eltId           Id of the element to check.
**                hierHead        Pointer on hierarchy header. 
**                eltRec          result of the functio. Pointer on family element. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
EXTERN RET_CODE FIN_GetFamilyElt(DBA_DYNST_ENUM    dynSt, 
			  				     int               parentFldIdx,
							     int               idFldIdx, 
							     ID_T              eltId, 
								 DBA_HIER_HEAD_STP hierHead,
								 DBA_DYNFLD_STP    *eltRec)
{
	DBA_DYNFLD_ST     	eltIdDynSt;
	int                 i, eltNbr;
	DBA_DYNFLD_STP      *eltTab, familyRec=NULLDYNST;

	if (eltRec == NULL)
		return(RET_GEN_ERR_INVARG);

	(*eltRec) = NULLDYNST;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

    memset(&eltIdDynSt, 0 ,sizeof(eltIdDynSt));
	if (eltId != 0)
		SET_ID((&eltIdDynSt), 0, eltId);

	if (DBA_ExtractHierEltRecByIndexKey(hierHead, 
			 		                    A_FamilyElt, 
							            A_FamilyElt_EltId,
	                                    eltIdDynSt,
			 		                    FALSE, /* copyRecFlag */
			 		                    NULLFCT, NULLDYNST, NULLFCT, FALSE, 
			 		                    &eltNbr, 
			 		                    &eltTab) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	for (i=0; i < eltNbr && (*eltRec) == NULLDYNST; i++)
	{
		if (IS_NULLFLD(eltTab[i], A_FamilyElt_FamilyExt) == FALSE)
		{
			familyRec = *(GET_EXTENSION_PTR(eltTab[i], A_FamilyElt_FamilyExt));
			if (familyRec != NULLDYNST &&
				GET_INT(familyRec, A_FamilyDef_DynSt) == dynSt && /* PMSTA-18696 - DDV - 141001 - DynStEnum is not ENUM_T !!! change A_FamilyDef_DynSt to INT_T */
				GET_INT(familyRec, A_FamilyDef_ParentFldIdx) == parentFldIdx &&
				GET_INT(familyRec, A_FamilyDef_IdFldIdx) == idFldIdx)
			{
				(*eltRec) = eltTab[i];
			}
		}
	}

	FREE(eltTab);
	if ((*eltRec) == NULLDYNST)
	{
		return(RET_GEN_ERR_INVARG);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_GetFamilyParentRec()
**
**  Description : Return an parent record of a Family.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                eltId           Id of the element to check.
**                hierHead        Pointer on hierarchy header. 
**                eltRec          result of the functio. Pointer on family element. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA14212 - DDV - 120530
**
*************************************************************************/
EXTERN RET_CODE FIN_GetFamilyParentRec(DBA_DYNST_ENUM    dynSt, 
			  						   int               parentFldIdx,
							           int               idFldIdx, 
							           ID_T              eltId, 
								       DBA_HIER_HEAD_STP hierHead,
								       DBA_DYNFLD_STP    *parentRec)
{
	DBA_DYNFLD_STP      eltRec;
	DBA_DYNFLD_STP      parentEltRec;

	if (parentRec == NULL)
		return(RET_GEN_ERR_INVARG);

	(*parentRec) = NULLDYNST;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (FIN_CreateFamily(dynSt, parentFldIdx, idFldIdx, hierHead) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (eltId != 0)
	{
		FIN_GetFamilyElt(dynSt, parentFldIdx, idFldIdx, eltId, hierHead, &eltRec);

		if (IS_NULLFLD(eltRec, A_FamilyElt_ParentExt) == FALSE &&
			(parentEltRec = *(GET_EXTENSION_PTR(eltRec, A_FamilyElt_ParentExt))) != NULLDYNST &&
			IS_NULLFLD(parentEltRec, A_FamilyElt_EltExt) == FALSE
			)
		{
		    *parentRec = *(GET_EXTENSION_PTR(parentEltRec, A_FamilyElt_EltExt));
		}
	}
	else
	{
		return(RET_GEN_ERR_INVARG);
	}

	if ((*parentRec) == NULLDYNST)
	{
		return(RET_GEN_ERR_INVARG);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_AddFamilyRec()
**
**  Description : Create a Family definition record and add it into hierarchy.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                hierHead        Pointer on hierarchy header. 
**                familyRec       Result of the function
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
STATIC RET_CODE FIN_AddFamilyRec(DBA_DYNST_ENUM    dynSt, 
			  				     int               parentFldIdx,
							     int               idFldIdx, 
								 DBA_HIER_HEAD_STP hierHead,
								 DBA_DYNFLD_STP    *familyRec)
{
	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE ||
		familyRec == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	/* create New FamilyDef record */
	if (((*familyRec) = ALLOC_DYNST(A_FamilyDef)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	SET_INT((*familyRec), A_FamilyDef_DynSt, dynSt); /* PMSTA-18696 - DDV - 141001 - DynStEnum is not ENUM_T !!! change A_FamilyDef_DynSt to INT_T */
	SET_INT((*familyRec), A_FamilyDef_ParentFldIdx, parentFldIdx);
	SET_INT((*familyRec), A_FamilyDef_IdFldIdx, idFldIdx);

	if (DBA_AddHierRecord(hierHead, (*familyRec), A_FamilyDef, TRUE, HierAddRec_NoLnk) != RET_SUCCEED)
	{
		FREE_DYNST((*familyRec), A_FamilyDef);
		return(RET_DBA_ERR_HIER);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_CreateEltTab()
**
**  Description : Create all element record for the family
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                recTab          Array of all the family's records order by parent_id
**                recNbr          Number of records
**                hierHead        Pointer on hierarchy header. 
**                eltTab          Returned pointer on element array
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
STATIC RET_CODE FIN_CreateEltTab(DBA_DYNST_ENUM    dynSt, 
			  				     DBA_DYNFLD_STP    familyRec,
			  				     DBA_DYNFLD_STP    *recTab,
							     int               recNbr, 
								 DBA_HIER_HEAD_STP hierHead,
			  				     DBA_DYNFLD_STP    **eltTab)
{
	int				i=0,j=0;
	DBA_DYNFLD_STP  *extensionPtr=NULLDYNST;
	INT_T           idFldIdx=0;
	INT_T           parentFldIdx=0;

	idFldIdx=GET_INT(familyRec, A_FamilyDef_IdFldIdx);
	parentFldIdx=GET_INT(familyRec, A_FamilyDef_ParentFldIdx);

	if (((*eltTab) = (DBA_DYNFLD_STP *) CALLOC(recNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	for (i=0; i < recNbr; i++)
	{
		if (((*eltTab)[i] = ALLOC_DYNST(A_FamilyElt)) == NULLDYNST)
		{
			for (j=0; j<i; j++) 
				FREE_DYNST((*eltTab)[j], A_FamilyElt);
			FREE((*eltTab));
	
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			return(RET_MEM_ERR_ALLOC);
		}

		SET_ID((*eltTab)[i], A_FamilyElt_FamilyId, GET_ID(familyRec, A_FamilyDef_Id));
        extensionPtr = (DBA_DYNFLD_STP*) CALLOC(1,  sizeof(DBA_DYNFLD_STP));
        extensionPtr[0] = familyRec;
		SET_EXTENSION ((*eltTab)[i], A_FamilyElt_FamilyExt, extensionPtr, A_FamilyDef, 1);

		SET_ID((*eltTab)[i], A_FamilyElt_EltId, GET_ID(recTab[i], idFldIdx));
        extensionPtr = (DBA_DYNFLD_STP*) CALLOC(1,  sizeof(DBA_DYNFLD_STP));
        extensionPtr[0] = recTab[i];
		SET_EXTENSION ((*eltTab)[i], A_FamilyElt_EltExt, extensionPtr, dynSt, 1);

		SET_ID((*eltTab)[i], A_FamilyElt_ParentId, GET_ID(recTab[i], parentFldIdx));
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_FindRecord()
**
**  Description : Find a record into an array
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                recTab          Array of all the records
**                recNbr          Number of records
**                idFldIdx        Index of the id field into the structure
**                id              Id to find
**                eltPos          Result of the function (posito
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080408
**
*************************************************************************/
STATIC RET_CODE FIN_FindRecord(DBA_DYNST_ENUM    dynSt, 
			  				   DBA_DYNFLD_STP    *recTab,
							   int               recNbr, 
							   int               idFldIdx, 
			  				   ID_T              id,
							   DBA_DYNFLD_STP    *recordPtr)
{
	int				pos=0, step=0;

	if (dynSt == NullDynSt ||
		idFldIdx == NO_VALUE ||
		recordPtr == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	(*recordPtr)=NULLDYNST;

	if (idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	pos = recNbr/2;
    step = (int) ceil((double) recNbr/4.0);

	while (step != 0)
	{
		if (pos < 0)
			pos=0;

		if (pos >= recNbr)
			pos=recNbr-1;

		if (CMP_ID(GET_ID(recTab[pos], idFldIdx), id) > 0)
		{
			pos -= step;
		}
		else if (CMP_ID(GET_ID(recTab[pos], idFldIdx), id) < 0)
		{
			pos += step;
		}
		else
		{
			(*recordPtr)=recTab[pos];
			return(RET_SUCCEED);
		}

		if (step == 1)
			step=0;
		else
		    step = (int) ceil((double) step/2.0);
	}

	if (pos < 0)
		pos = 0;

	if (pos >= recNbr)
		pos = recNbr-1;

	if (CMP_ID(GET_ID(recTab[pos], idFldIdx), id) > 0 && pos >0)
	{
		pos--;
	}

	if (CMP_ID(GET_ID(recTab[pos], idFldIdx), id) < 0 && pos < (recNbr-1))
	{
		pos++;
	}

	if (CMP_ID(GET_ID(recTab[pos], idFldIdx), id) != 0)
	{
		return(RET_DBA_INFO_NODATA);
	}

	(*recordPtr)=recTab[pos];
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_UpdateEltTabExtension()
**
**  Description : Update element record to set children and parent extensions
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                familyRec       Pointer on family definition record
**                eltTab          Returned pointer on element array
**                eltNbr          Number of records
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
STATIC RET_CODE FIN_UpdateEltTabExtension(DBA_DYNFLD_STP    familyRec,
			  				              DBA_DYNFLD_STP    *eltTab,
							              int               eltNbr)
{
	int				i=0, j=0, firstChild=0, rootNb=0,
	                childrenNbr=0;
	DBA_DYNFLD_STP  *extensionPtr=NULLDYNSTPTR, parentEltRec=NULLDYNST;
	DBA_DYNFLD_STP  *eltTabById=NULLDYNSTPTR;
	DBA_DYNFLD_STP  rootElt=NULLDYNST;
	ID_T            prevParentId=0;
	INT_T           eltIdIdx;

	/* copy element array to sort it by id */
	eltTabById = (DBA_DYNFLD_STP*) CALLOC(eltNbr,  sizeof(DBA_DYNFLD_STP));
	for (i=0; i < eltNbr; i++)
		eltTabById[i]=eltTab[i];

	eltIdIdx = A_FamilyElt_EltId;
	/* sort records by id */
	if (eltNbr > 1)
		TLS_Sort2((char *) eltTabById, eltNbr, sizeof(DBA_DYNFLD_STP),
			      FIN_CmpEltId, (PTR **) NULL, SortRtnTp_None, (PTR *) &eltIdIdx);

	firstChild=0;
	prevParentId = GET_ID(eltTab[0], A_FamilyElt_ParentId);
	childrenNbr=0;

	if (prevParentId!= 0)
	{
		FIN_FindRecord(A_FamilyElt, eltTabById, eltNbr, A_FamilyElt_EltId, prevParentId, &parentEltRec);
	}
	else
		parentEltRec=NULLDYNST;

	for (i=0; i < eltNbr; i++)
	{
		if (GET_ID(eltTab[i], A_FamilyElt_ParentId) != prevParentId)
		{
			if (parentEltRec != NULLDYNST)
			{
				/* find parent and set child array */
				extensionPtr = (DBA_DYNFLD_STP*) CALLOC(childrenNbr,  sizeof(DBA_DYNFLD_STP));
				for (j=0; j < childrenNbr; j++)
					extensionPtr[j] = eltTab[firstChild+j];
				SET_EXTENSION(parentEltRec, A_FamilyElt_ChildrenExt, extensionPtr, A_FamilyElt, childrenNbr);
			}

			firstChild=i;
			prevParentId = GET_ID(eltTab[i], A_FamilyElt_ParentId);
			childrenNbr=0;

			if (prevParentId!= 0)
			{
				FIN_FindRecord(A_FamilyElt, eltTabById, eltNbr, A_FamilyElt_EltId, prevParentId, &parentEltRec);
			}
			else
				parentEltRec=NULLDYNST;
		}

		childrenNbr++;

		/* link to parent */
		if (parentEltRec != NULLDYNST)
		{
			extensionPtr = (DBA_DYNFLD_STP*) CALLOC(1,  sizeof(DBA_DYNFLD_STP));
			extensionPtr[0] = parentEltRec;
			SET_EXTENSION(eltTab[i], A_FamilyElt_ParentExt, extensionPtr, A_FamilyElt, 1);
		}
		else
		{
			rootNb++;
			rootElt = eltTab[i];
		}
	}

	if (parentEltRec != NULLDYNST)
	{
		/* find parent and set child array */
		extensionPtr = (DBA_DYNFLD_STP*) CALLOC(childrenNbr,  sizeof(DBA_DYNFLD_STP));
		for (j=0; j < childrenNbr; j++)
			extensionPtr[j] = eltTab[firstChild+j];
		SET_EXTENSION(parentEltRec, A_FamilyElt_ChildrenExt, extensionPtr, A_FamilyElt, childrenNbr);
	}

	SET_INT(familyRec, A_FamilyDef_RootNb, rootNb);
	if (rootNb == 1)
	{
        extensionPtr = (DBA_DYNFLD_STP*) CALLOC(1,  sizeof(DBA_DYNFLD_STP));
        extensionPtr[0] = rootElt;
		SET_EXTENSION(familyRec, A_FamilyDef_RootExt, extensionPtr, A_FamilyElt, 1);
	}

	FREE(eltTabById);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_CreateFamily()
**
**  Description : Create a new Family structure.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                hierHead        Pointer on hierarchy header. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 080407
**
*************************************************************************/
EXTERN RET_CODE FIN_CreateFamily(DBA_DYNST_ENUM    dynSt, 
			  				     int               parentFldIdx,
							     int               idFldIdx, 
								 DBA_HIER_HEAD_STP hierHead)
{
	int				familyDefNbr=0;
	int				i=0, recNbr=0;
	DBA_DYNFLD_STP  familyRec=NULLDYNST;
	DBA_DYNFLD_STP  *familyDefTab=NULLDYNST, *eltTab=NULLDYNST, *recTab=NULLDYNST;
	FLAG_T          foundFlg=FALSE;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (DBA_ExtractHierEltRec(hierHead, A_FamilyDef, FALSE, NULLFCT, NULLFCT,
	                          &familyDefNbr, &familyDefTab) != RET_SUCCEED)
	{
		return(RET_DBA_ERR_HIER);
	}

	for (i=0; i < familyDefNbr && foundFlg != TRUE; i++)
	{
		if (GET_INT(familyDefTab[i], A_FamilyDef_DynSt) == dynSt && /* PMSTA-18696 - DDV - 141001 - DynStEnum is not ENUM_T !!! change A_FamilyDef_DynSt to INT_T */
            GET_INT(familyDefTab[i], A_FamilyDef_ParentFldIdx) == parentFldIdx &&
            GET_INT(familyDefTab[i], A_FamilyDef_IdFldIdx) == idFldIdx)
		{
			foundFlg=TRUE;
		}
	}

	FREE(familyDefTab);

	/* Family allready exist, nothing to do */
	if (foundFlg == TRUE)
	{
		return(RET_SUCCEED);
	}

  
	if (DBA_ExtractHierEltRec(hierHead, dynSt, FALSE, NULLFCT, NULLFCT,   /* PMSTA-13295 - JPP - 20120207 */
	                          &recNbr, &recTab) != RET_SUCCEED)
	{
		return(RET_DBA_ERR_HIER);
	}

	/* no record, nothing to do */
	if (recNbr == 0)
	{
		return(RET_SUCCEED);
	}

	/* sort records by parent id and create all element */
	if (recNbr > 1)
		TLS_Sort2((char *) recTab, recNbr, sizeof(DBA_DYNFLD_STP),
			      FIN_CmpEltId, (PTR **) NULL, SortRtnTp_None, (PTR *) &parentFldIdx);

	if (FIN_AddFamilyRec(dynSt, parentFldIdx, idFldIdx, hierHead, &familyRec) != RET_SUCCEED)
	{
		FREE(recTab);
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Creation of new family definition failed");
		return(RET_GEN_ERR_PERSONAL);
	}

	if (FIN_CreateEltTab(dynSt, familyRec, recTab, recNbr, hierHead,&eltTab) != RET_SUCCEED)
	{
		FREE(recTab);
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Creation of new family element array failed");
		return(RET_GEN_ERR_PERSONAL);
	}

	if (FIN_UpdateEltTabExtension(familyRec, eltTab, recNbr) != RET_SUCCEED)
	{
		FREE(recTab);
		DBA_FreeDynStTab(eltTab, recNbr, A_FamilyElt);
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Update family elements failed");
		return(RET_GEN_ERR_PERSONAL);
	}

	FREE(recTab);

	/* add all new element in hierarchy */
	if (DBA_AddHierRecordList(hierHead, eltTab, recNbr, A_FamilyElt, TRUE) != RET_SUCCEED)
	{
		DBA_FreeDynStTab(eltTab, recNbr, A_FamilyElt);
		return(RET_DBA_ERR_HIER);
	}

	FREE(eltTab);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpEltId()
**
**  Description :   Sort element by given id
**
**  Arguments   :   ptr1         pointer on dynamic structure 
**                  ptr2         pointer on dynamic structure 
**                  parentFldIdx index of the parent field in the structure 
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA05911 - DDV - 080407
**  Modif       : 
*************************************************************************/
STATIC int FIN_CmpEltId(const void *ptr1, const void *ptr2, const void *fldIdxParam)
{
    DBA_DYNFLD_STP elt1, elt2;
	INT_T          fldIdx;

	elt1         = (DBA_DYNFLD_STP) (*((DBA_DYNFLD_STP *) (ptr1)));
	elt2         = (DBA_DYNFLD_STP) (*((DBA_DYNFLD_STP *) (ptr2)));
	fldIdx = (INT_T) (*((INT_T *) (fldIdxParam)));

	return(CMP_DYNFLD(elt1, elt2, fldIdx, fldIdx, IdType));
}

/************************************************************************
**
**  Function    : FIN_SelChildren()
**
**  Description : Return all the children of an element.
**
**  Arguments   : dynSt			  Dynamic structure of the family.
**                parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                maxLevel        Maximum number of level to go down. (0 means all level)
**                childrenArray   Result of the function
**                childrenNbr     Number of children returned
**                hierHead        Pointer on hierarchy header. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 0804010
**
*************************************************************************/
EXTERN RET_CODE FIN_SelChildren(DBA_DYNST_ENUM    dynSt, 
			  				    int               parentFldIdx,
							    int               idFldIdx, 
								ID_T              eltId,
								int               maxLevel,
								DBA_DYNFLD_STP    **childrenTab,
								int               *childrenNbr,
								DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP    eltRec;

	if (hierHead == NULL ||
		dynSt == NullDynSt ||
		parentFldIdx == NO_VALUE ||
		idFldIdx == NO_VALUE ||
		eltId == 0 ||
		childrenTab == NULLDYNSTPTR ||
		childrenNbr == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (parentFldIdx >= GET_FLD_NBR(dynSt) ||
	    idFldIdx >= GET_FLD_NBR(dynSt))
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (maxLevel < 0)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (FIN_CreateFamily(dynSt, parentFldIdx, idFldIdx, hierHead) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	if (FIN_GetFamilyElt(dynSt, parentFldIdx, idFldIdx, eltId, hierHead, &eltRec) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	(*childrenTab) = NULLDYNSTPTR;
	(*childrenNbr) = 0;

	if (FIN_SelChildrenInternal(eltRec, maxLevel, childrenTab, childrenNbr, 0) != RET_SUCCEED)
	{
		return(RET_GEN_ERR_INVARG);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_SelChildrenInternal()
**
**  Description : Return all the children of an element Internal function for recursivity.
**
**  Arguments   : parentFldIdx    Index of the parent field in the structure.
**                idFldIdx        Index of the id field in the structure.
**                maxLevel        Maximum number of level to go down.
**                childrenArray   Result of the function
**                childrenNbr     Number of children returned
**                hierHead        Pointer on hierarchy header. 
**
**  Return      : a RET_CODE
**
**  Creation    : PMSTA05911 - DDV - 0804010
**
*************************************************************************/
STATIC RET_CODE FIN_SelChildrenInternal(DBA_DYNFLD_STP    eltRec,
										int               maxLevel,
								        DBA_DYNFLD_STP    **childrenTab,
								        int               *childrenNbr,
										int               level)
{
	DBA_DYNFLD_STP    *recTab;
	int               recNbr=0, i;

	if (IS_NULLFLD(eltRec, A_FamilyElt_ChildrenExt) == FALSE)
	{
		recTab=GET_EXTENSION_PTR(eltRec, A_FamilyElt_ChildrenExt);
		recNbr=GET_EXTENSION_NBR(eltRec, A_FamilyElt_ChildrenExt);

		for (i=0; i < recNbr; i++)
		{
			if ((*childrenNbr) % 100 == 0)
			{
				(*childrenTab) = (DBA_DYNFLD_STP*) REALLOC((*childrenTab), ((*childrenNbr) + 100) * sizeof(DBA_DYNFLD_STP));
				if ((*childrenTab) == NULLDYNSTPTR)
				{
					(*childrenNbr) = 0;
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					return(RET_MEM_ERR_ALLOC);
				}

			}

			if (IS_NULLFLD(recTab[i], A_FamilyElt_EltExt) == FALSE &&
			    *(GET_EXTENSION_PTR(recTab[i], A_FamilyElt_EltExt)) != NULLDYNST)
			{
				(*childrenTab)[(*childrenNbr)]=*(GET_EXTENSION_PTR(recTab[i], A_FamilyElt_EltExt));
				(*childrenNbr)++;
			}
		}

		level++;

		if (maxLevel == 0 ||
			level < maxLevel)
		{
			for (i=0; i < recNbr; i++)
			{
				if (FIN_SelChildrenInternal(recTab[i], maxLevel, childrenTab, childrenNbr, level) != RET_SUCCEED)
				{
					return(RET_GEN_ERR_INVARG);
				}
			}
		}
	}
	return(RET_SUCCEED);
}

/************************************************************************
      END  finfam.c                                                 OAMS
*************************************************************************/

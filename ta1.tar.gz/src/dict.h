/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DICT_H
#define DICT_H

#include <list>

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#ifndef SYSLIB_H    /* PMSTA-13729 - 040412 - PMO */
#include "syslib.h"
#endif

class DbiConnectionHelper;

#define FIRST_UDT_ENTITY 5000 /* PMSTA-13109 - LJE - 111202 */
#define MAX_UDT_ENTITY 9999 /* PMSTA-19180 - LJE - 150127 */

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/
/* PMSTA-13109 - LJE - 111128 */
typedef enum
{
    EntityNat_All,           /*  0 */
    EntityNat_System,        /*  1 */
    EntityNat_Standard,      /*  2 */
    EntityNat_Packaging,     /*  3 */
    EntityNat_CustomDS,      /*  4 */
    EntityNat_Custom,        /*  5 */
    EntityNat_Technical,     /*  6 */
    EntityNat_PersistedFmt,  /*  7 */ /* PMSTA13876 - DDV - 130808 */
    EntityNat_SearchFmt,     /*  8 */ /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
    EntityNat_TempTable,     /*  9 */ /* ORACLE - LJE - 141013 - Temporary table */
    EntityNat_Questionnaire, /* 10 */ /* PMSTA19243 - DDV - 150326 */
    EntityNat_Tsl,           /* 11 */
    EntityNat_ReportFmt,     /* 12 */ /* PMSTA-22072 - LJE - 160108 */
    EntityNat_DerivedEntity, /* 13 */ /* PMSTA-26250 - LJE - 170323 */
    EntityNat_ModelBank,     /* 14 */ /* PMSTA-27352 - LJE - 170606 */

    EntityNat_Virtual,
    EntityNat_Internal
} DBA_ENTITY_NAT_ENUM;

typedef enum {
    DynType_Null = 0,
    DynType_All,
    DynType_Short,
    DynType_Other,
    DynType_AllDb,
    DynType_UdOnly,
    DynType_MeSpecOnly,         /* PMSTA-33420 - LJE - 181015 */
    DynType_UdMeSpecOnly,       /* PMSTA-33420 - LJE - 181015 */

    /* Not in meta-dictionary */

    DynType_NotMD,
    DynType_FieldList, /* PMSTA01389 - DDV - 070307 */
    DynType_AdmArg,    /* PMSTA-13122 - LJE - 120420 */
    DynType_PrecompOnly,
    DynType_ShortAllDb,   /* PMSTA-29879 - LJE - 180704 - Short attributes with all other physical attributes */
    DynType_AllDbWithUd,        /* PMSTA-36158 - LJE - 190627 */
    DynType_Full,               /* PMSTA-nuodb - LJE - 190528 */
    DynType_FullDb,             /* PMSTA-49178 - LJE - 220908 */
    DynType_Unknown,
    DynType_Tech                /* PMSTA-34344 - LJE - 200925 */
} DBA_DYNTYPE_ENUM;

/* table dict_attribute, field calculated_e */
typedef enum
{
    DictAttr_Physical,   /* In database    in procedure,    dbFlg = TRUE  */
    DictAttr_Calculated, /* No in database in procedure,    dbFlg = TRUE  */
    DictAttr_Virtual,    /* No in database no in procedure, dbFlg = FALSE */
    DictAttr_Denorm,     /* Updated only by database        dbFlg = TRUE  */
    DictAttr_PhysSpecUpd, /* In database    in procedure,    updated by special stored procedure dbFlg = TRUE */
    DictAttr_LastModifManagment, /* In database, updated by trigger on each modification (last_modif_date, last_user_is, ...) */
    DictAttr_CreationManagment, /* In database, updated by trigger on the creation (creation_date, user_id, ...) */

    DictAttr_ExternalSeqNo = 10, /* PMSTA-20887 - LJE - 150903 */
    DictAttr_PhysicalPartition,   /* PMSTA-24007 - LJE - 170718 */

    /* PMSTA-14452 - LJE - 130205 - Not in meta-dictionary */
    DictAttr_NoMD
} DICTATTR_ENUM;

/*  FPL-REF10603-041229 */
typedef enum
{
    DictNullCopy_NotSetToNull ,         /*  don't set to null while copying                             */
    DictNullCopy_SetToNull ,            /*  set to null but don't run DV                                */
    DictNullCopy_SetToNullAndDV,        /*  set to null and execute DV                                  */
    DictNullCopy_HardCoded,             /*  Hard coded value                                            */  /*  HFI-PMSTA-41842-200916  */
    DictNullCopy_One_SetToNull ,        /*  set to null but don't run DV when copying one record        */  /*  HFI-PMSTA-41842-200916  */
    DictNullCopy_One_SetToNullAndDV,    /*  set to null and execute DV when copying one record          */  /*  HFI-PMSTA-41842-200916  */
    DictNullCopy_One_HardCoded,         /*  Hard coded value when copying one record                    */  /*  HFI-PMSTA-41842-200916  */

    DictNullCopy_Last               /* INSERT BEFORE                    */
} DICT_NULLCOPY_ENUM;

/*  FIH-REF10967-050204 */
typedef enum
{
    DictAttrCopyNat_Copy,		/* 0 */
    DictAttrCopyNat_NoCopy,		/* 1 */
    DictAttrCopyNat_Denied,	    /* 2 */

    DictAttrCopyNat_Last        /* INSERT BEFORE                    */
} DICT_ATTRCOPY_ENUM;

/*< PMSTA07964 - LJE - 090325 */
typedef enum {
    EvalDataType_AllStruct,
    EvalDataType_ShortStruct,
    EvalDataType_BusinessKey,
    EvalDataType_UserDefined
} EVAL_DATA_TYPE_ENUM;

typedef enum {
        AssignType_Undefine=-1,
        AssignType_SetOnly,
        AssignType_Locked
} ASSIGN_TYPE_ENUM;

typedef enum {
        UseType_Unused=-1,
        UseType_Used,
        UseType_ForeignKey
} USE_TYPE_ENUM;

typedef enum
{
    ProcAccess_None,
    ProcAccess_Full,
    ProcAccess_PrimaryKey,
    ProcAccess_BusinessKey,
    ProcAccess_ParentKey,   /* PMSTA-13109 - LJE - 111117 */
    ProcAccess_ListKey,
    ProcAccess_CustomKey,
    ProcAccess_Unique,      /* PMSTA-26250 - LJE - 170412 */
    ProcAccess_ChangeSet,   /* PMSTA-26250 - DDV - 170515 */
    ProcAccess_NatureKey,   /* PMSTA-26108 - LJE - 170811 */
    ProcAccess_All,         /* PMSTA-32145 - LJE - 180721 */
    ProcAccess_Short,        /* PMSTA-32145 - LJE - 180721 */
    ProcAccess_UdField,       /* PMSTA-26554 - LJE - 181116 */
    ProcAccess_AllDb        /* PMSTA-46954 - LJE - 211112 */
} DBA_PROC_ACCESS_ENUM;

typedef enum
{
    IdxFunction_None,
    IdxFunction_PrimaryKey,
    IdxFunction_BusinessKey,
    IdxFunction_PrimaryKeyUDF,
    IdxFunction_CustomKey,
    IdxFunction_PrecompIdx,       /* PMSTA-17216 - LJE - 131210 */
    IdxFunction_ReportIdx,
    IdxFunction_UserDefinedFields, /* PMSTA-27179 - LJE - 170525 */
    IdxFunction_PrimaryKeyPrecomp,  /* PMSTA-37366 - LJE - 200205 */
    IdxFunction_FromTemplate        /* PMSTA-45413 - LJE - 211213 */
} DBA_IDX_FUNCTION_ENUM;

typedef enum
{
    Custom_No,
    Custom_Yes,
    Custom_New
} DBA_CUSTOM_ENUM;

typedef enum
{
    Automatic_Table=0,
    Automatic_SProc,
    Automatic_Trigger,
    Automatic_Index,
    Automatic_ViewFullAllSecured,       /* "All" structure with ud_ fields and ext_ fields with secure access, with auth flag */
    Automatic_ViewFullAll,              /* "All" structure with ud_ fields and ext_ fields without secure access*/
    Automatic_ViewLightAll,             /* "All" structure without any linked tables without secure access */
    Automatic_ViewShortSecured,         /* "Short" structure with secure access */
    Automatic_ViewShort,                /* "Short" structure without secure access */
    Automatic_ViewFullAll4ForeignKey,   /* "All" structure with ud_ fields and ext_ fields with secure access, without auth flags */
    Automatic_MetaDictionary,
    Automatic_Short,
    Automatic_ShowInGUIMenu,
    Automatic_OppositeBehavior          /* PMSTA-18593 - LJE - 150512 */

} DBA_AUTOMATIC_MASK;

typedef enum
{
    PermAuth_No,
    PermAuth_Add,
    PermAtuh_Overwrite
} DBA_PERMAUTH_ENUM;
/* PMSTA07964 - LJE - 090325 >*/

/* PMSTA-18096 - LJE - 140623 */
typedef enum
{
    ExecuteAs_None,
    ExecuteAs_Owner,
    ExecuteAs_Caller,
    ExecuteAs_Private,  /* No grant is done */
    ExecuteAs_LoginManager,
    ExecuteAs_WmTech
} DBA_EXECUTE_AS_ENUM;

typedef enum
{
    RefDelRule_None,
    RefDelRule_Restrict,
    RefDelRule_SetNULL,
    RefDelRule_CascadeDelete,
    RefDelRule_Inherited,         /* Inherited from the logical attribute, raise error if not logical attribute is define */
    RefDelRule_NoAction
} REF_DELETE_RULE_ENUM;

typedef enum
{
    RefSecuRule_Inherited,
    RefSecuRule_FullySecured,
    RefSecuRule_PkAllowed,
    RefSecuRule_PkBkallowed,
    RefSecuRule_NoSecured
} REF_SECURITY_RULE_ENUM;

typedef enum
{
    RefChkRule_None,
    RefChkRule_Checked,
    RefChkRule_CheckedZeroAllowed,
    RefChkRule_NotChecked,
    RefChkRule_Inherit           /* Inherit from the logical attribute, raise error if not logical attribute is define */
} REF_CHECK_RULE_ENUM;

typedef enum
{
    Aggegation_None,
    Aggegation_Composition,
    Aggegation_Aggregation,
    Aggegation_Extension
} AGGEGATION_ENUM;

typedef enum
{
    Multiplicity_None,
    Multiplicity_OneToOne,
    Multiplicity_OneToMany,
    Multiplicity_ZeroToOne,
    Multiplicity_ZeroToMany,
    Multiplicity_ManyToMany,
    Multiplicity_ManyToOne,
    Multiplicity_ManyToZero
} MULTIPLICITY_ENUM;

typedef enum
{
    NullAction = 0,
    Get,
    Select,
    MultiSelect,
    Load,
    Insert,
    Update,
    Delete,
    Check,
    Notif,
    Copy,
    InsUpd,		/* DVP276 */
    SelMetaDict,	/* REF3537 - 99/07/20 - GRD */
    RegisterRpc,     /* REF9936 - TEB - 040216 */
    Purge,           /* PMSTA15008-JPP-20120920 */
    Truncate,        /* PMSTA15008-JPP-20120920 */
    AllStdProcs,     /* PMSTA-14086 - LJE - 121009 */
    Special,         /* PMSTA-16729 - LJE - 140205 */
    OptiDef,         /* PMSTA-18426 - DDV - 141126 */
    Custom,
    Trigger          /* PMSTA-49178 - LJE - 220921 */

} DBA_ACTION_ENUM;

typedef enum
{
    TargetTable_Undefined = 0,
    TargetTable_Main,
    TargetTable_UserDefinedFields,
    TargetTable_Precomp,
    TargetTable_Temp,
    TargetTable_View,                /* PMSTA-31849 - LJE - 180716 */
    TargetTable_LocalBusinessEntity,
    TargetTable_TechView,             /* PMSTA-36158 - LJE - 190613 */
    TargetTable_SecuView              /* PMSTA-36919 - LJE - 191209 */
} TARGET_TABLE_ENUM;

/* PMSTA-28698 - LJE - 180710 */
enum class SubFeature
{
    None,
    UpdateRight,
    DeleteRight,
    RightReason,
    UpdateSecuRight,
    DeleteSecuRight,
    MeRecordLocation,
    Tech,
    TechCField,
    TechInternal
};

typedef enum {
    DictFctAuth_None,	    /* Access is refused                                    */
    DictFctAuth_NoLicense,	/* Access is denied : Not enough licenses left          */
    DictFctAuth_Ok,		    /* Access is allowed                                    */
    DictFctAuth_Master 		/* Access is refused because of logging in master env   */  /*  HFI-PMSTA-41458-200814  */
} DICT_FCTAUTH_ENUM;

/*  Licensee key                                */  /*  HFI-PMSTA-35838-190515  */
typedef enum
{
    DictLicenseKey_None,
    DictLicenseKey_CoreNumber,
    DictLicenseKey_ProductivityNumber,
    DictLicenseKey_AttributionLevel,
    DictLicenseKey_RiskNumber,
    DictLicenseKey_AccountingNumber,
    DictLicenseKey_FundNumber,
    DictLicenseKey_CorporateActionsNumber,
    DictLicenseKey_AdvancedAnalyticsLevel,
    DictLicenseKey_CompositeManagementNumber,
    DictLicenseKey_ExcelReportNumber,
    DictLicenseKey_ReturnAnalysisLevel,
    DictLicenseKey_AdvancedConstraintManagementNumber,
    DictLicenseKey_OrderManagementNumber,
    DictLicenseKey_CompoundOrderLevel,
    DictLicenseKey_RiskComplianceLevel,
    DictLicenseKey_QuestionnaireLevel,
    DictLicenseKey_FinancialPlanningLevel,
    DictLicenseKey_DataFrameworkLevel,
    DictLicenseKey_CRMLevel,

    DictLicenseKey_Last
} DICT_LICENSEKEY_ENUM;



/************************************************************************
** structures used to load the meta-dictionary
*************************************************************************/
typedef class DictAttribClass DICT_ATTRIB_ST, *DICT_ATTRIB_STP;
typedef class DictEntityClass DICT_ENTITY_ST, *DICT_ENTITY_STP;
typedef class DictCriterClass DICT_CRITER_ST, *DICT_CRITER_STP; /* PMSTA-11505 - LJE - 110315 */
typedef class DictPermValClass DICT_PERM_VAL_ST, *DICT_PERM_VAL_STP;

typedef struct DBA_DYNFLD DBA_DYNFLD_ST, *DBA_DYNFLD_STP;
typedef struct DBA_DYNDEF DBA_DYNDEF_ST, *DBA_DYNDEF_STP;
typedef struct DBA_CFIELDDEF DBA_CFIELDDEF_ST, *DBA_CFIELDDEF_STP;

typedef struct DBA_PROC_STRUCT DBA_PROC_ST, *DBA_PROC_STP;

extern DICT_ENTITY_STP  DBA_GetDictEntitySt(OBJECT_ENUM),
                        DBA_GetDictEntityStSafe(OBJECT_ENUM),
                        DBA_GetDictEntityByDictId(DICT_T),       /* PMSTA-26108 - LJE - 170918 */
                        DBA_GetDictEntityByDictIdSafe(DICT_T),
                        DBA_GetDictEntityByXdDictId(ID_T),              /*  HFI-PMSTA-46106-210913  */
                        DBA_GetEntityBySqlName(const std::string &, bool bAll = false, bool bSource = false);    /* PMSTA-31849 - LJE - 180716 */

class MultiEntityHelper
{
public:
        // Constructor
    MultiEntityHelper(DictEntityClass *dictEntityStp);
    MultiEntityHelper(MULTI_ENTITY_CATEGORY_ENUM multiEntityCategEn);
    MultiEntityHelper(const MultiEntityHelper&) = delete;

    // Destructor
    virtual ~MultiEntityHelper();

    // Methods
    MultiEntityHelper &operator=(const MultiEntityHelper&) = delete;

    static bool isMultiEntityCateg(MULTI_ENTITY_CATEGORY_ENUM chkMultiEntityCategEn);

    void set(MULTI_ENTITY_CATEGORY_ENUM multiEntityCategEn);
    void setDerivedCategory(const MultiEntityHelper &multiEntityCateg, bool);
    MULTI_ENTITY_CATEGORY_ENUM get() const;

    MULTI_ENTITY_CATEGORY_ENUM getDerivedCategory() const;

    bool isUseMeViewAsTable() const;

    bool isInsUpdOnLocalBe() const;
    bool isForceOnConnectedBusinessEntity() const;

    bool isMultiEntityCateg() const;

    bool isOnlyInMaster() const;
    bool isMasterVisibility() const;
    bool isBusinessEntityIsolated() const;
    bool isBusinessEntityDependents() const;
    bool isMultiEntityVisibility() const;

    bool isPartialSpecialzed() const;
    bool isOptionalLocalization() const;
    bool isFullOptionalLocalization() const;  /* PMSTA-38290 - HLA - 200204 */

    bool isCheckBeOnParent() const;
    bool isAddCheckOnCurrentBe() const;
    bool isCheckInTrigger() const;

    bool isDeniedInMaster() const;
    bool isAllowedOnlyInMaster() const;
    bool isCheckOnCurrentBe() const;
    bool isCheckIfNotExtistOnMaster() const;

    bool isDervidedCategory() const;
    bool isUniqueKeyAlered() const;
    bool isOwnerBusinessEntity() const;
    bool isOwnerBusinessEntityMandatory() const;

protected:
    // Members
    MULTI_ENTITY_CATEGORY_ENUM  m_multiEntityCategEn;
    DictEntityClass            *m_dictEntityStp;
};

/************************************************************************
** functions used to load the meta-dictionary
*************************************************************************/

/*  FIH-REF10983-050210 Moved from fmtlib01.h   */
/* permitted value */
typedef class PermitedValuesClass PERMITED_VALUES_ST, *PERMITED_VALUES_STP;

class PermitedValuesClass :public AAAObject
{
public:
    PermitedValuesClass():AAAObject(),
        pdictPermVal(nullptr),
        dictidLang(0),
        value(0),
        rank(0),
        permValRank(0),
        defSelFlg(FALSE),
        m_label(),
        m_name(),
        m_uniLabel()
    {
    }

    PermitedValuesClass(const PermitedValuesClass& ref):
        PermitedValuesClass()
    {
        *this = ref;
    }

    // Destructor
    virtual ~PermitedValuesClass()
    {
    }

    // Methods
    PermitedValuesClass &operator=(const PermitedValuesClass& ref)
    {
        this->pdictPermVal  = ref.pdictPermVal;
        this->dictidLang    = ref.dictidLang;
        this->value         = ref.value;
        this->rank          = ref.rank;
        this->permValRank   = ref.permValRank;
        this->defSelFlg     = ref.defSelFlg;
        this->m_label       = ref.m_label;
        this->m_name        = ref.m_name;
        this->m_uniLabel    = ref.m_uniLabel;

        return *this;
    }

    DICT_PERM_VAL_STP       pdictPermVal;
    DICT_T                  dictidLang;
    ID_T		            value;	        /* unsigned char for real permval, otherwise (DICT_T or ID_T) long  */  /*  FPL-PMSTA08801-091008 longID from long  */
    SMALLINT_T	            rank;	        /* For order */
    SMALLINT_T	            permValRank;
    FLAG_T                  defSelFlg;      /* Define if the enum (id) is selected by default values (filter) */ /* PMSTA-15655 - LJE - 130124 */

    char                    *getLabel ();
    char                    *getName ();
    UChar                   *getUniLabel ();
    void                    setLabel(char *pszLabel);
    void                    setName(char *pszName);
    void                    setUniLabel(UChar *pszUniLabel);

private:
    std::string             m_label;
    std::string             m_name;
    UnicodeString           m_uniLabel;
};

class DictPermValClass
{
public:
    DictPermValClass():
        dictId(0),
        entDictId(0),
        attDictId(0),
        permVal(0),
        rank(0),
        refEntityDictId(0),
        permValRuleEn(PermValRule_Standard),
        dbRuleEn(PermValDbRule_Allowed),
        xdStatusEn(XdStatus_Untreated)
    {
    }

    DictPermValClass(const DictPermValClass& ref):
        DictPermValClass()
    {
        *this = ref;
    }

    // Destructor
    virtual ~DictPermValClass()
    {
    }

    // Methods
    DictPermValClass &operator=(const DictPermValClass& ref)
    {
        this->dictId          = ref.dictId;          /*  HFI-PMSTA-29272-171127  Missing assignment */
        this->entDictId       = ref.entDictId;
        this->attDictId       = ref.attDictId;
        this->permVal         = ref.permVal;
        this->rank            = ref.rank;
        this->refEntityDictId = ref.refEntityDictId;
        this->permValRuleEn   = ref.permValRuleEn;
        this->dbRuleEn        = ref.dbRuleEn;
        this->xdStatusEn      = ref.xdStatusEn;
        this->nameStr         = ref.nameStr;
        this->labelStr        = ref.labelStr;
        this->uniLabelStr     = ref.uniLabelStr;

        return *this;
    }

    DICT_T                 dictId;          /*  DEV5502 - CSA - 13022001            */
    DICT_T                 entDictId;       /* entity identifier                    */
    DICT_T                 attDictId;       /* unique attrib id. determined by dvp  */
    ENUM_T                 permVal;         /* permitted value itself (numeric)     */
    std::string            nameStr;         /* permitted value name                 */
    std::string            labelStr;        /* label in user language               */
    UnicodeString          uniLabelStr;     /* unicode label in user language      */
    SMALLINT_T             rank;            /* display order of permitted value     */
    DICT_T                 refEntityDictId; /* PMSTA-11505 - LJE - 110615 */

    /* PMSTA-13122 - LJE - 120523 */
    PERM_VAL_RULE_ENUM     permValRuleEn;
    PERM_VAL_DB_RULE_ENUM  dbRuleEn;       /* PMSTA-27352 - LJE - 170606 */
    XD_STATUS_ENUM         xdStatusEn;
};


/************************************************************************
**      STRUCTURES USED FOR DYNAMIC STRUCTURES UTILISATION
*************************************************************************/
typedef struct {
    char              *ptr;                  /* pointer on string */
} DBA_STRFLDDATA_ST, *DBA_STRFLDDATA_STP;

typedef struct {    /* PCL - REF9303 - 030724 */
    UChar           *ptr;                  /* pointer on string */
} DBA_USTRFLDDATA_ST, *DBA_USTRFLDDATA_STP;

typedef struct {
    int             extNbr;          /* extension dynamic struct number */   /*  FIH-REF10187-040407 Change short into unsigned short */
    DBA_DYNST_ENUM  dynStTp;         /* DBA_DYNST_ENUM  */
} DBA_EXTENSION_ST, *DBA_EXTENSION_STP;

typedef struct {
    int             eltNbr;          /* elements number in the allocated array */
    int             eltSz;           /* size of one element stored in array    */
} DBA_ARRAY_ST, *DBA_ARRAY_STP;

typedef struct {                             /* Ref.: DVP005 */
    char           *notNullFlgTab;
    DBA_DYNFLD_STP dataTab; /* REF7296 - LJE - 020502 */
} DBA_ARRAY_DATA_ST, *DBA_ARRAY_DATA_STP;

typedef struct  {                           /* Ref.: DVP005 */
    unsigned short     dataNbr1;
    unsigned short     dataNbr2;
} DBA_MULTIARRAY_ST, *DBA_MULTIARRAY_STP;

typedef union {                         /* possible types for the data */
    double              dbleValue;
    int                 intValue;
    short               shortValue;
    DBA_STRFLDDATA_ST   strData;
    DBA_USTRFLDDATA_ST  ustrData;        /* PCL - REF9303 - 030724 */
    unsigned char       ucharValue;
    unsigned int        uintValue;
    unsigned short      ushortValue;
    DATETIME64_ST       datetime64St;
    SYB_SRV_DATETIM_ST  sybSrvDatetimeSt;
    DATE_ST             dateView;       /* structure for date visualization */
    ID_T                longlongValue;  /* DLA - REF9089 - 030508 */ /* PMSTA08801 - DDV - 091126 */
    TIMESTAMP_T         timeStampValue; /* REF11780 - 100406 - PMO */
    BINARY_T            binaryValue;    /* DLA - PMSTA05995 - 080410 */
    void *              ptr;             /* DLA - REF9089 - 030512 */

    /* Array management */   /* PMSTA-Memory - LJE - 181203 */
    PTR                 arrayPtr;        /* ptr on (double, struct, int ...) array */
    DBA_ARRAY_ST        arrayInfo;

    DBA_ARRAY_DATA_STP  multiArrayDataPtr;
    DBA_MULTIARRAY_ST   multiArrayInfo;

    DBA_DYNFLD_STP     *extPtr;         /* ptr on dynamic struct ptr array */
    DBA_EXTENSION_ST    extInfo;
} DBA_DYNFLDDATA_UN, *DBA_DYNFLDDATA_UNP;

typedef struct DBA_DYNSTDEF {
    DATATYPE_ENUM       dataType;         /* datatype (DATATY_ENUM in unidef.h              */
    unsigned char       dbFlg;            /* TRUE if info is in database,                   */
    unsigned char       mdFlg;            /* TRUE if info is in meta-dictionary             */
                                          /* FALSE elsewhere                                */
    bool                bMain;            /* true if info is in main table                  */
    bool                bCustom;          /* true if info is in user defined fields table   */
    bool                bPrecomp;         /* true if info is in precomputed table           */
    bool                bMEPartial;       /* true if info is in MESI partial specialized    */
    FIELD_IDX_T         asciiField;       /* ASCII field position for variable field like denom */ /* REF9303 - LJE - 030903 */
    FIELD_IDX_T         infoField;        /* Info field position for variable field like array, extension, ... */ /* PMSTA-Memory - LJE - 181203 */
    SubFeature          subFeatureEn;     /* PMSTA-15655 - LJE - 130130 */
    FIELD_IDX_T         anonymizeItem;    /* Field used for anonymize */ /* PCC-17009 - LJE - 130318 */
    char               *anonymizeSubst;   /* Subsitute value for anonymize */ /* PCC-17009 - LJE - 130318 */
    SYSNAME_T           sqlName;
    DBA_DYNST_ENUM      defLinkDynStEn;   /* PMSTA-34344 - LJE - 200923 */
    DBA_CFIELDDEF_STP   cFieldDefStp;
    DICT_ATTRIB_STP     dictAttribStp;    /* PMSTA-29879 - LJE - 180710 */

    bool isTech()
    {
        if (this->subFeatureEn == SubFeature::Tech ||
            this->subFeatureEn == SubFeature::TechInternal)
        {
            return true;
        }
        return false;
    }
} DBA_DYNSTDEF_ST, *DBA_DYNSTDEF_STP;

/*  FIH-REF4029-991109  Fields counters are now short and no more unsigned char */
typedef struct DBA_DYNST
{
    FIELD_IDX_T         fldNbr;            /* total fields number in structure                             */
    FIELD_IDX_T         noMDFldNbr;        /* internal fields number in structure                          */
    FIELD_IDX_T         custFldNbr;        /* customer fields number                                       */
    FIELD_IDX_T         precompFldNbr;     /* precomp fields number                                        */ 
    FIELD_IDX_T         logicalFldNbr;     /* logical fields number                                        */ /* PMSTA-42814 - LJE - 210922 */
    FIELD_IDX_T         techFldNbr;        /* technical fields number                                      */ /* PMSTA-15655 - LJE - 130130 */
    FIELD_IDX_T         fixFldNbr;         /* fix fields number                                            */ /* PMSTA-15655 - LJE - 130130 */

    FIELD_IDX_T         firstTechFldPos;   /* technical fields number                                      */ /* PMSTA-15655 - LJE - 130130 */

    OBJECT_ENUM         entity;	           /* entity object                                                */
    DICT_ENTITY_STP     dictEntityStp;     /* dict_entity structure                                        */
    OBJECT_ENUM         custEntityObj;     /* customer fields entity object                                */
    OBJECT_ENUM         precompEntityObj;  /* precomputed fields entity object                             */ /* PMSTA-11505 - LJE - 110622 */
    DBA_DYNSTDEF_STP    dynStDefPtr;       /* pointer on field's def structure                             */
    FIELD_IDX_T         nbEntry;           /* Number of entries in the array of dynStDefPtr  REF8014 - PMO */
    DBA_DYNDEF_STP      dynDefPtr;         /* Pointer on table of definition (SV_DynStDefStTab)            */ /* PMSTA-13122 - LJE - 120419 */
    FIELD_IDX_T         codifIdIdx;        /* codifId position in dynamic structure                        */ /* REF9303 - LJE - 030912 */
    int                 allocCpt;          /* How many allocation */  /* REF9789 - LJE - 040102 */
    DBA_DYNTYPE_ENUM    dynTypeEnum;       /* dynamic structure type enum (all, short, ...)                */ /* REF9743 - LJE - 040202 */
    FIELD_IDX_T         authUpdFlgIdx;     /* FPL-REF10401-040630 index of the auth update flag            */
    FIELD_IDX_T         authDelFlgIdx;     /* FPL-REF10401-040630 index of the auth delete flag            */
    FIELD_IDX_T         authReasonIdx;     /* index of the auth reason enum                                */   /* PMSTA-29879 - LJE - 180710 */
    FIELD_IDX_T         authUpdSecuIdx;    /* index of attribute update_secu_right_f                       */   /* HFI-PMSTA-32148-181003   */
    FIELD_IDX_T         authDelSecuIdx;    /* index of attribute delete_secu_right_f                       */   /* PMSTA-26554 - LJE - 181116 */
    FIELD_IDX_T         meRecLocFldIdx;    /* index of attribute me_record_location_e                      */   /* HFI-PMSTA-32148-181023   */
    FIELD_IDX_T         internalFldIdx;    /* index of the attribute for internal used                     */   /* PMSTA-37366 - LJE - 191209 */
    FIELD_IDX_T         foreignKeyFldIdx;  /* index of the attribute for foreign keys links used           */   /* PMSTA-46681 - LJE - 220825 */
    INT_T               maxLenWithTextFld;    /* PMSTA07121 - DDV - 090304 - Maximum memory size for this structure, this value is set by function DBA_InitObjectAndDynSt */
    INT_T               maxLenWithoutTextFld; /* PMSTA07121 - DDV - 090304 - Maximum memory size for this structure, this value is set by function DBA_InitObjectAndDynSt */
    FIELD_IDX_T         hierEltIdxFldIdx;        /* PMSTA-26250 - DDV - 170331 */
    FIELD_IDX_T         changeSetOldRecExtFldIdx; /* PMSTA-26250 - DDV - 170331 */
    FIELD_IDX_T         changeSetNewRecExtFldIdx; /* PMSTA-26250 - DDV - 170331 */

    DBA_DYNST_ENUM      newVerDynStEn;

    void init(OBJECT_ENUM);

} DBA_DYNST_ST, *DBA_DYNST_STP;

typedef struct DBA_CFIELDDEF
{
    const char*      sqlName;
    FLAG_T           dbFlg;
    FIELD_IDX_T      *fieldPosPtr;
    DATATYPE_ENUM    dataTypeEnum;
    FLAG_T           metaDictFlg;

    /* PMSTA08736 - LJE - 100120 - for check purpose, not to assign in definition */
    FLAG_T           treatedFlg;
    SubFeature       subFeatureEn;       /* PMSTA-46259 - LJE - 211007 */
    FLAG_T           techFlg;       /* PMSTA-43741 - LJE - 210406 */
    bool             bRealCField;   /* PMSTA-53383 - LJE - 240109 */

} DBA_CFIELDDEF_ST, *DBA_CFIELDDEF_STP;

/* PMSTA-24007 - LJE - 161216 */
typedef struct DBA_DYNDEF_DEF
{
    OBJECT_ENUM*      objPosPtr;
    DBA_DYNST_ENUM*   dynStPosPtr;
    const char*       dynStName;
    DBA_DYNTYPE_ENUM  dynTypeEnum;
    DBA_CFIELDDEF_STP cFieldMdTab;
    DBA_CFIELDDEF_STP cFieldManTab;
} DBA_DYNDEF_DEF_ST, *DBA_DYNDEF_DEF_STP;

typedef struct DBA_DYNDEF
{
    OBJECT_ENUM       objPos;
    DBA_DYNST_ENUM    dynStPos;
    const char*       dynStName;
    DBA_DYNTYPE_ENUM  dynTypeEnum;
    DBA_CFIELDDEF_STP cFieldTab;

    FLAG_T            initOk;
} DBA_DYNDEF_ST, *DBA_DYNDEF_STP;

typedef struct {
    const char*            objName;
    OBJECT_ENUM*           objPosPtr;
    int                    objCst;
    const char*            sqlName;
    struct DBA_PROC_STRUCT *procDefStp;
    FLAG_T                 initOk;
} DBA_OBJDEF_ST, *DBA_OBJDEF_STP;

typedef struct {
    DBA_DYNST_ENUM admin;
    DBA_DYNST_ENUM edit;
    int            objectCst;           /* Constant value of object <> objectEnum */ /* REF8844 - LJE - 030416 */
    DBA_OBJDEF_STP objDefTabPtr;        /* Pointer in table of definition (SV_ObjDefStTab) */ /* PMSTA-13122 - LJE - 120418 */
    FLAG_T         objAllocateFlg;      /* REF9789 - LJE - 031230 : For virtual object */
    DBA_DYNDEF_STP adminDynDefTabPtr;   /* Pointer in table of definition (SV_DynDefStTab) */ /* PMSTA-13122 - LJE - 120418 */
    DBA_DYNDEF_STP editDynDefTabPtr;    /* Pointer in table of definition (SV_DynDefStTab) */ /* PMSTA-13122 - LJE - 120418 */

    DBA_DYNDEF_DEF_STP allDynDefStp;
    DBA_DYNDEF_DEF_STP shortDynDefStp;
} DBA_GUIDYNST_ST, *DBA_GUIDYNST_STP;

/*  FIH-REF4029-991109  Group notNullFlag, ndf and refFlg into flgMask                  */
struct DBA_DYNFLD
{
    unsigned char   flgMask;    /*  bit 0 = not null flag                               */
    /*  FALSE if data is a null value, TRUE otherwise       */
    /*  bit 1 = not default flag                            */
    /*  FALSE if data is a default value, TRUE otherwise    */
    /*  bit 2 = reference flag                              */
    /*  TRUE if data is a reference value, FALSE otherwise  */
    /*  5 others=reserved                                   */
    unsigned char   dataType;   /*  Hold an DATATYPE_ENUM value                         */
    short           index;
    DBA_DYNST_ENUM  dynStEnum;  /* REF9303 - LJE - 030904 */
    // short           shortIndex;

    DBA_DYNFLDDATA_UN data;         /* data which depending on type */


    std::string      disp();

    /* PMSTA-45413 - LJE - 210802 */
    inline DBA_DYNST_ENUM   getDynStEn() const
    {
        return static_cast<DBA_DYNST_ENUM>(this->dynStEnum);
    }

    OBJECT_ENUM      getObjectEn() const;
    int              getObjectCst() const;
    DBA_DYNTYPE_ENUM getDynTypeEn() const;
    DICT_ENTITY_STP  getDictEntityStp() const;
    DICT_ATTRIB_STP  getDictAttribStp() const;
    inline DATATYPE_ENUM    getDataType() const
    {
        return static_cast<DATATYPE_ENUM>(this->dataType);
    }

    FIELD_IDX_T      getIdIdx() const;

    bool             isAllDynSt() const;
    bool             isShortDynSt() const;

    inline DATATYPE_ENUM   getDataTypeEn() const
    {
        return static_cast<DATATYPE_ENUM>(this->dataType);
    }
};

class DictAttribClass :public AAAObject
{
public:

    DictAttribClass();

    DictAttribClass(const DictAttribClass& ref)
        : DictAttribClass()
    {
        *this = ref;
    }

    // Destructor
    virtual ~DictAttribClass()
    {
        this->FREE_daLabels();
    }

    // Methods
    DictAttribClass &operator=(const DictAttribClass& ref)
    {
        this->attrDictId               = ref.attrDictId;
        this->entDictId                = ref.entDictId;
        this->dataTpProgN              = ref.dataTpProgN;
        this->refEntDictId             = ref.refEntDictId;
        this->parAttrDictId            = ref.parAttrDictId;
        this->progN                    = ref.progN;
        this->dbProgN                  = ref.dbProgN;
        this->progPkN                  = ref.progPkN;
        this->isNullProgPkN            = ref.isNullProgPkN;
        this->dispRank                 = ref.dispRank;
        this->primFlg                  = ref.primFlg;
        this->mandatoryFlg             = ref.mandatoryFlg;
        this->dbMandatoryFlg           = ref.dbMandatoryFlg;
        this->busKeyFlg                = ref.busKeyFlg;
        this->logicalFlg               = ref.logicalFlg;
        this->setBySpecProcFlg         = ref.setBySpecProcFlg;
        this->custFlg                  = ref.custFlg;
        this->precompFlg               = ref.precompFlg;
        this->calcEn                   = ref.calcEn;
        this->permAuthEn               = ref.permAuthEn;
        this->editionEn                = ref.editionEn;
        this->editionMask              = ref.editionMask;
        this->qSearchMask              = ref.qSearchMask;
        this->searchMask               = ref.searchMask;
        this->subTypeMask              = ref.subTypeMask;
        this->parAttrEntDictId         = ref.parAttrEntDictId;
        this->parAttrProgN             = ref.parAttrProgN;
        this->parAttrPtr               = ref.parAttrPtr;
        this->shortIdx                 = ref.shortIdx;
        this->isNullShortIdx           = ref.isNullShortIdx;
        this->securityLevelEn          = ref.securityLevelEn;
        this->widgetEn                 = ref.widgetEn;
        this->maxDbLenN                = ref.maxDbLenN;
        this->defaultDisplayLenN       = ref.defaultDisplayLenN;
        this->orgAttrNbr               = ref.orgAttrNbr;
        this->orgAttrTab               = ref.orgAttrTab;
        this->useAttrNbr               = ref.useAttrNbr;
        this->useAttrTab               = ref.useAttrTab;
        this->pdbadynLinkedObj         = ref.pdbadynLinkedObj;
        this->enSetNullWhileCopying    = ref.enSetNullWhileCopying;
        this->iDimIndex                = ref.iDimIndex;
        this->iObjIndex                = ref.iObjIndex;
        this->enDefListObject          = ref.enDefListObject;
        this->tascViewEn               = ref.tascViewEn;
        this->enumValueEn              = ref.enumValueEn;
        this->refEntityAttributeDictId = ref.refEntityAttributeDictId;
        this->fkPresentationEn         = ref.fkPresentationEn;
        this->denomLanguageDictId      = ref.denomLanguageDictId;
        this->verticalSearchFlg        = ref.verticalSearchFlg;
        this->verticalPatternFlg       = ref.verticalPatternFlg;
        this->multiLanguageFlg         = ref.multiLanguageFlg;
        this->xdStatusEn               = ref.xdStatusEn;
        this->virtualAttrFlg           = ref.virtualAttrFlg;
        this->refDeleteRuleEn          = ref.refDeleteRuleEn;
        this->refSecurityRuleEn        = ref.refSecurityRuleEn;
        this->refCheckRuleEn           = ref.refCheckRuleEn;
        this->objModifStatEn           = ref.objModifStatEn;
        this->progBkN                  = ref.progBkN;
        this->isNullProgBkN            = ref.isNullProgBkN;
        this->exportEn                 = ref.exportEn;
        this->featureEn                = ref.featureEn;
        this->subFeatureEn             = ref.subFeatureEn;
        this->modelBankEn              = ref.modelBankEn;
        this->meSpecialisationEn       = ref.meSpecialisationEn;
        this->linkedAttrDictId         = ref.linkedAttrDictId;
        this->linkedAttrDictStp        = ref.linkedAttrDictStp;
        this->linkAttrDictTab          = ref.linkAttrDictTab;
        this->dictEntityStp            = ref.dictEntityStp;
        this->allDictCriteriaStp       = ref.allDictCriteriaStp;
        this->logicalFkFlg             = ref.logicalFkFlg;
        this->copyRightEn              = ref.copyRightEn;
        this->outboxPublishEn          = ref.outboxPublishEn;

        for (auto it = ref.permValMap.begin(); it != ref.permValMap.end(); ++it)
        {
            this->permValMap.insert(std::make_pair(it->first, it->second));
        }

        strcpy(this->name, ref.name);
        strcpy(this->keyCharC, ref.keyCharC);
        this->dfltVal =  ref.dfltVal;
        strcpy(this->sqlName, ref.sqlName);
        strcpy(this->objectAttribute, ref.objectAttribute);
        strcpy(this->entityAttribute, ref.entityAttribute);
        strcpy(this->enumAttribute, ref.enumAttribute);

        strcpy(this->objectAttribute, ref.objectAttribute);
        strcpy(this->entityAttribute, ref.entityAttribute);
        strcpy(this->enumAttribute, ref.enumAttribute);

        this->SET_daUniLabel(ref.GET_daUniLabel());
        this->SET_daLabel(ref.GET_daLabel());

        return *this;
    }

    DictPermValClass &getDictPermValByRank(SMALLINT_T rank)
    {
        return this->permValMap[rank];
    }

    // Members
    DICT_T              attrDictId;         /* attribute identifier                */
    NAME_T              name;               /* conceptual name                     */
	char                *daLabel;           /* label in user language              *//* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */ /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    UChar               *daUniLabel;        /* unicode label in user language      *//* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */ /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    DICT_T              entDictId;          /* entity identifier                   */
    DATATYPE_ENUM       dataTpProgN;        /* datatype identifier                 */
    DICT_T              refEntDictId;       /* parent entity (for foreign key)     */
    DICT_T              parAttrDictId;      /* parent attr (for permitted value)   */
    SYSNAME_T           sqlName;            /* physical name                       */
    INT_T               progN;              /* unique identifier determined by dvp */ /* REF8844 - LJE - 030327 */
    INT_T               dbProgN;            /* progN set in database, the progN can be changed in the meta dict load */ /* PMSTA-13109 - LJE - 111123 */
    SMALLINT_T          progPkN;            /* index on Get_Arg structure          */
    bool                isNullProgPkN;
    SMALLINT_T          dispRank;           /* display order                       */
    FLAG_T              primFlg;            /* attribute is a primary key          */
    FLAG_T              mandatoryFlg;       /* attribute is allowed to be null     */
    FLAG_T              dbMandatoryFlg;     /* attr is allowed to be null in db    */
    std::string         dfltVal;            /* default when attribute isn't filled */
    FLAG_T              busKeyFlg;          /* attribute is an business key        */
    FLAG_T              logicalFlg;         /* logical attribute added for Sql     */
    FLAG_T              setBySpecProcFlg;   /* TRUE if the standard insert/update procedures
                                               don't touch the attribute value in database */ /* PMSTA-11505 - LJE - 110516 */
    FLAG_T              custFlg;            /* customized field                    */
    FLAG_T              precompFlg;         /* TSL extension field                 */ /* PMSTA-11505 - LJE - 110315 */
    DICTATTR_ENUM       calcEn;             /* calculated, virtual or attribute    */
    DBA_PERMAUTH_ENUM   permAuthEn;         /* permitted values adding is allowed  */
    DICTATTRIBEDIT_ENUM editionEn;          /* edition flag                        */ /* DVP039 - RAK - 960508 */ /* ROI - 970421 */
    MASK_T              editionMask;        /* edition Mask                        */   /*  HFI-PMSTA-38117-200109  */
    MASK_T              qSearchMask;        /* in which subtype an attribute is    */
                                            /* usable in quick search screen       */
    MASK_T              searchMask;         /* in which subtype an attribute is    */
                                            /* usable in simple search screen      */
    MASK_T              subTypeMask;        /* to which subtype an attribute is    */
                                            /* attached. (edition screen)          */

    std::map<SMALLINT_T, DictPermValClass> permValMap;            /* permitted values list               */ /* PMSTA-26108 - LJE - 170918 */

    DICT_T              parAttrEntDictId;   /* parent attribute entity           */
    int                 parAttrProgN;       /* parent attribute progN              */
    DICT_ATTRIB_STP     parAttrPtr;
    FIELD_IDX_T         shortIdx;           /* index in short structure            */
    bool                isNullShortIdx;     /* REF8844 - LJE - 030305 : -1 if the attribute isn't in short struct */
    ENUM_T	            securityLevelEn;
    NAME_T 	            keyCharC;
    DICTATTRIBWGT_ENUM  widgetEn;		    /* usable for date-time widget         */ /* MRA - 000119 - RFE4115 -- DLA - REF7264 - 020508*/
    unsigned int        maxDbLenN;			/* DLA - PMSTA09887 - 101104 */ /* PMSTA-34373 - LJE - 190213 */
    unsigned int        defaultDisplayLenN; /* DLA - PMSTA09887 - 101104 */ /* PMSTA-34373 - LJE - 190213 */
    int                 orgAttrNbr;         /* REF9764 - LJE - 040109 */
    DICT_ATTRIB_STP    *orgAttrTab;         /* REF9764 - LJE - 040109 */
    int                 useAttrNbr;         /* REF9764 - LJE - 040109 */
    DICT_ATTRIB_STP    *useAttrTab;         /* REF9764 - LJE - 040109 */
    DBA_DYNFLD_STP      pdbadynLinkedObj;   /*  Linked dynamic structure            */  /*  FIH-REF9790-040219  */
    DICT_NULLCOPY_ENUM  enSetNullWhileCopying;  /*  FPL-REF10305-040908 */  /*  FPL-REF10603-041229 */

    int                 iDimIndex;          /*  Index of linked dimension attribute */  /*  FIH-REF11457-051005 */
    int                 iObjIndex;          /*  Index of linked object attribute    */  /*  FIH-REF11457-051005 */
    OBJECT_ENUM         enDefListObject;    /*  Default list entity                 */  /*  FIH-REF11457-051005 */

    ENUM_T              tascViewEn;                /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    SYSNAME_T           objectAttribute;           /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    SYSNAME_T           entityAttribute;           /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    SYSNAME_T           enumAttribute;             /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    ENUM_T              enumValueEn;               /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    DICT_T              refEntityAttributeDictId;  /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    ENUM_T              fkPresentationEn;          /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    DICT_T              denomLanguageDictId;       /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              verticalSearchFlg;         /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              verticalPatternFlg;        /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              multiLanguageFlg;          /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */

    /* PMSTA-13109 - LJE - 111214 */
    XD_STATUS_ENUM      xdStatusEn;
    FLAG_T              virtualAttrFlg;

    REF_DELETE_RULE_ENUM    refDeleteRuleEn;
    REF_SECURITY_RULE_ENUM  refSecurityRuleEn;
    REF_CHECK_RULE_ENUM     refCheckRuleEn;

    LAST_MODIF_ENUM         objModifStatEn;

    /* PMSTA-21717 - LJE - 160119 */
    SMALLINT_T              progBkN;
    bool                    isNullProgBkN;
    EXPORT_ENUM             exportEn;
    /* PMSTA-23385 - LJE - 160711 */
    XdEntityFeatureFeatureEn featureEn;
    SubFeature              subFeatureEn;       /* PMSTA-28698 - LJE - 180710 - Sub feature, managed manually DictEntityClass::init() */
    MODEL_BANK_ENUM         modelBankEn;        /* PMSTA-27352 - LJE - 170606 */

    ME_SPECIALISATION_ENUM  meSpecialisationEn; /* PMSTA-26108 - LJE - 170830 */

    OUTBOX_PUBLISH_ENUM     outboxPublishEn;    /*PMSTA-45305 -Lalby- 210611*/

    /* PMSTA-13122 - LJE - 120523 */
    ID_T                linkedAttrDictId;
    DICT_ATTRIB_STP     linkedAttrDictStp;

    /* PMSTA-18593 - LJE - 151221 */
    std::vector<DICT_ATTRIB_STP> linkAttrDictTab;

    DICT_ENTITY_STP     dictEntityStp;
    DICT_ENTITY_STP     refDictEntityStp;

    DICT_CRITER_STP     allDictCriteriaStp;        /* PMSTA-55668 - LJE - 240312 */

    FLAG_T              logicalFkFlg;              /* OCS-43062 - LJE - 130909 - Attribute uses to manage the logical foreign key */

    /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    size_t              daLabelLen;
    size_t              daUniLabelLen;

    DICT_ATTRCOPY_ENUM  copyRightEn;    /*  Can an attribute be copyable ?              */  /*  HFI-PMSTA-39490-200411  */

    static bool         isPhysicalCalcEn(DICTATTR_ENUM calcEn); /* PMSTA-29879 - LJE - 180705 */
    bool                isPhysicalAttribute();                  /* PMSTA-29879 - LJE - 180705 */
    bool                isSpecialAttribute();                  /* PMSTA-46259 - LJE - 211004 */
    bool                isPhysicalUDAttribute();                /* PMSTA-36158 - LJE - 190627 */

    bool                isCompostion();
    bool                isInAll();
    bool                isInShort();

    MemoryPool          m_mp;

    void SET_daLabel(const char *strIn)
    {
        size_t strInLen = 1;

        if (strIn)
        {
            strInLen += strlen(strIn);
        }

        if (strInLen > daLabelLen || daLabel == NULL)
        {
            daLabel = static_cast<char *> (REALLOC(daLabel, strInLen * sizeof(char)));
            daLabelLen = strInLen;
        }

        if (strIn)
        {
            strcpy(daLabel, strIn);
        }
        else
        {
            daLabel[0] = 0;
        }
    }

    const char *GET_daLabel(void) const        /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (daLabel==NULL)
            return EMPTY_STR;
        else
            return daLabel;
    }

    void SET_daUniLabel(const UChar *strIn)
    {
        size_t strInLen = 1;

        if (strIn)
        {
            strInLen += u_strlen(strIn);
        }

        if (strInLen > daUniLabelLen || daUniLabel == NULL)
        {
            daUniLabel = static_cast<UChar *> (REALLOC(daUniLabel, strInLen * sizeof(UChar)));
            daUniLabelLen=strInLen;
        }

        if (strIn)
        {
            u_strcpy(daUniLabel, strIn);
        }
        else
        {
            daUniLabel[0] = 0;
        }
    }

    const UChar *GET_daUniLabel(void) const      /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (daUniLabel==NULL)
            return EMPTY_USTR;
        else
            return daUniLabel;
    }

    void FREE_daLabels()
    {
        FREE(daLabel);
        FREE(daUniLabel);
    }

    bool isTech()
    {
        if (this->subFeatureEn == SubFeature::Tech ||
            this->subFeatureEn == SubFeature::TechInternal)
        {
            return true;
        }
        return false;
    }
    bool isCOnly()
    {
        if (this->subFeatureEn == SubFeature::TechCField)
        {
            return true;
        }
        return false;
    }
};


class DictCriterClass : public AAAObject
{
public:

    DictCriterClass():
        dictId(0),
        entDictId(0),
        attrDictId(0),
        dynNatEn(DynType_Null),
        attrEntDictId(0),
        progN(0),
        shortProgN(0),
        dcLabel(nullptr),
        dcUniLabel(nullptr),
        sortRank(0),
        sortRule(SortRule_Ascending),
        fkIndex(0),
        isNullFkIndex(true),
        index(0),
        isNullIndex(true),
        parent1ProgN(255),
        isNullParent1ProgN(true),
        parentCriteria1Stp(nullptr),
        parent2ProgN(255),
        isNullParent2ProgN(true),
        parentCriteria2Stp(nullptr),
        attrPtr(nullptr),
        attrEntObj(NullEntity),
        outputFlg(FALSE),
        entAttrPtr(nullptr),
        toPrintFlg(TRUE),
        bFromDb(true),
        bLoopTest(false),
        dcLabelLen(0),
        dcUniLabelLen(0)
    {
        this->sqlName[0]        = 0;
        this->name[0]           = 0;
        this->joinSqlName[0]    = 0;
        this->parent1SqlName[0] = 0;
        this->parent2SqlName[0] = 0;
        this->labelAttribDictId = ZERO_ID;                 /* PMSTA-36158 - LJE - 190627 */
    }

    DictCriterClass(const DictCriterClass &ref):
        DictCriterClass()
    {
        *this = ref;
    }

    // Destructor
    virtual ~DictCriterClass()
    {
        this->FREE_dcLabels();
    }

    // Methods
    DictCriterClass &operator=(const DictCriterClass &ref)
    {
        this->dictId             = ref.dictId;
        this->entDictId          = ref.entDictId;
        this->attrDictId         = ref.attrDictId;
        this->dynNatEn           = ref.dynNatEn;
        this->attrEntDictId      = ref.attrEntDictId;
        this->progN              = ref.progN;
        this->shortProgN         = ref.shortProgN;
        this->sortRank           = ref.sortRank;
        this->sortRule           = ref.sortRule;
        this->fkIndex            = ref.fkIndex;
        this->isNullFkIndex      = ref.isNullFkIndex;
        this->index              = ref.index;
        this->isNullIndex        = ref.isNullIndex;
        this->parent1ProgN       = ref.parent1ProgN;
        this->isNullParent1ProgN = ref.isNullParent1ProgN;
        this->parentCriteria1Stp = ref.parentCriteria1Stp;
        this->parent2ProgN       = ref.parent2ProgN;
        this->isNullParent2ProgN = ref.isNullParent2ProgN;
        this->parentCriteria2Stp = ref.parentCriteria2Stp;
        this->attrPtr            = ref.attrPtr;
        this->attrEntObj         = ref.attrEntObj;
        this->outputFlg          = ref.outputFlg;
        this->entAttrPtr         = ref.entAttrPtr;
        this->toPrintFlg         = ref.toPrintFlg;
        this->bLoopTest          = ref.bLoopTest;
        this->bFromDb            = ref.bFromDb;

        strcpy(this->parent1SqlName, ref.parent1SqlName);
        strcpy(this->parent2SqlName, ref.parent2SqlName);

        strcpy(this->sqlName, ref.sqlName);
        strcpy(this->name, ref.name);
        strcpy(this->joinSqlName, ref.joinSqlName);

        this->SET_dcUniLabel(ref.GET_dcUniLabel());
        this->SET_dcLabel(ref.GET_dcLabel());

        this->labelAttribDictId = ref.labelAttribDictId;      /* PMSTA-36158 - LJE - 190627 */

        return *this;
    }


    DICT_T           dictId;                /* criteria identifier       */

    DICT_T           entDictId;             /* criteria entity identifier       */
    DICT_T           attrDictId;            /* attribute identifier             */

    DBA_DYNTYPE_ENUM dynNatEn;              /* Nature of the dynamic structure that the dict criteria explains */ /* PMSTA-11505 - LJE - 110325 */
    SYSNAME_T        sqlName;               /* sql name uses by the view or proc generator */ /* PMSTA-11505 - LJE - 110316 */

    DICT_T           attrEntDictId;         /* attribute entity identifier      */
    FIELD_IDX_T      progN;                 /* criteria progN */ /* PMSTA-11505 - LJE - 110624 */
    FIELD_IDX_T      shortProgN;            /* (index for short) */
    NAME_T           name;                  /* criteria name                    */ /* REF9303 - LJE - 030915 */
	char            *dcLabel;                 /* criteria label                   *//* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */  /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    UChar           *dcUniLabel;              /* unicode label in user language   *//* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */  /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    TINYINT_T        sortRank;              /* sorting rank                     */
    SORTRULE_ENUM    sortRule;              /* sorting rule                     */
    TINYINT_T        fkIndex;               /* fk index                         */	/* DVP338 */ /* PMSTA-11505 - LJE - 110624 */
    bool             isNullFkIndex;         /* fk index Null field              */ /* PMSTA-14452 - LJE - 130213 */
    FIELD_IDX_T      index;                 /* index                            */ /* PMSTA-11505 - LJE - 110315 */
    bool             isNullIndex;           /* index Null Field                 */ /* PMSTA-11505 - LJE - 110315 */
    SYSNAME_T        parent1SqlName;
    FIELD_IDX_T      parent1ProgN;          /* 1st parent criteria index (1st fk) */ /* PMSTA-11505 - LJE - 110316 */
    bool             isNullParent1ProgN;    /* 1st parent criteria index (1st fk) */ /* PMSTA-11505 - LJE - 110316 */
    DICT_CRITER_STP  parentCriteria1Stp;
    SYSNAME_T        parent2SqlName;
    FIELD_IDX_T      parent2ProgN;          /* 2nd parent criteria index (2nd fk) */ /* PMSTA-11505 - LJE - 110316 */
    bool             isNullParent2ProgN;    /* 2nd parent criteria index (2nd fk) */ /* PMSTA-11505 - LJE - 110316 */
    DICT_CRITER_STP  parentCriteria2Stp;

    std::vector< DictCriterClass *> bkDictCriteriaVector;

    /* Not in database */
    DICT_ATTRIB_STP  attrPtr;               /* pointer on attribute (attrDictId.sqlname_c)            */

    OBJECT_ENUM      attrEntObj;            /* object of the entity of the attribute */ /* PMSTA-11505 - LJE - 110316 */
    SYSNAME_T        joinSqlName;           /* Join name uses by the view or proc generator */ /* PMSTA-11505 - LJE - 110316 */

    FLAG_T           outputFlg;             /* True if the field is returned from the stored proc */ /* PMSTA-11505 - LJE - 110509 */

    DICT_ATTRIB_STP  entAttrPtr;            /* pointer on attribute of the current entity (entDictId.attr[sqlname_c])  */

    FLAG_T           toPrintFlg;            /* True if the field is returned from the stored proc */ /* PMSTA-11505 - LJE - 110509 */
    bool             bFromDb;

    bool             bLoopTest;              /* To avoid infinity loop */

    /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    size_t          dcLabelLen;
    size_t          dcUniLabelLen;

    DICT_T          labelAttribDictId;          /* PMSTA-36158 - LJE - 190627 */

    void SET_dcLabel(const char *strIn)
    {
        size_t strInLen = 1;

        if (strIn)
		{
            strInLen += strlen(strIn);
		}

        if (strInLen > dcLabelLen || dcLabel == NULL)
        {
            dcLabel = static_cast<char *> (REALLOC(dcLabel, strInLen * sizeof(char)));
            dcLabelLen = strInLen;
        }

        if (strIn)
        {
            strcpy(dcLabel, strIn);
        }
        else
        {
            dcLabel[0] = 0;
        }
    }

    const char *GET_dcLabel(void) const        /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (dcLabel==NULL)
            return EMPTY_STR;
        else
            return dcLabel;
    }

    void SET_dcUniLabel(const UChar *strIn)
    {
        size_t strInLen = 1;

        if (strIn)
		{
            strInLen += u_strlen(strIn);
		}

        if (strInLen > dcUniLabelLen || dcUniLabel == NULL)
        {
            dcUniLabel = static_cast<UChar *> (REALLOC(dcUniLabel, strInLen * sizeof(UChar)));
            dcUniLabelLen = strInLen;
        }

        if (strIn)
        {
            u_strcpy(dcUniLabel, strIn);
        }
        else
        {
            dcUniLabel[0] = 0;
        }
    }

    const UChar *GET_dcUniLabel(void) const     /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (dcUniLabel==NULL)
            return EMPTY_USTR;
        else
            return dcUniLabel;
    }

    void FREE_dcLabels()
    {
            FREE(dcLabel);
            FREE(dcUniLabel);
    }
};

/* REF9764 - LJE - 040112 */
typedef struct
{
    DICT_T          entDictId;
    OBJECT_ENUM     objectEn;

} DICT_ENTREF_ST, *DICT_ENTREF_STP;

class DictEntityConstrKey
{
public:
    DictEntityConstrKey(DICT_T entityDictId, DICT_T refEntityDictId, DICT_T refAttribDictId):
        m_entityDictId(entityDictId),
        m_refEntityDictId(refEntityDictId),
        m_refAttribDictId(refAttribDictId)
    {

    }

    DictEntityConstrKey(const DictEntityConstrKey &ref)
        : DictEntityConstrKey(ref.m_entityDictId, ref.m_refEntityDictId, ref.m_refAttribDictId)
    {
    }

    virtual ~DictEntityConstrKey()
    {

    }

    // Methods
    bool operator<(const DictEntityConstrKey &ref) const
    {
        if (ref.m_entityDictId < this->m_entityDictId)
            return true;

        if (ref.m_entityDictId > this->m_entityDictId)
            return false;

        if (ref.m_refEntityDictId < this->m_refEntityDictId)
            return true;

        if (ref.m_refEntityDictId > this->m_refEntityDictId)
            return false;

        if (ref.m_refAttribDictId < this->m_refAttribDictId)
            return true;

        return false;
    }

    bool operator==(const DictEntityConstrKey &ref) const
    {
        return this->m_refEntityDictId == ref.m_refEntityDictId &&
            this->m_refAttribDictId == ref.m_refAttribDictId &&
            this->m_entityDictId == ref.m_entityDictId;
    }

    DictEntityConstrKey &operator=(const DictEntityConstrKey &ref)
    {
        this->m_entityDictId    = ref.m_entityDictId;
        this->m_refEntityDictId = ref.m_refEntityDictId;
        this->m_refAttribDictId = ref.m_refAttribDictId;
        return *this;
    }

    // Members
    DICT_T                      m_entityDictId;
    DICT_T                      m_refEntityDictId;
    DICT_T                      m_refAttribDictId;
};


class DictEntityConstrClass
{
public:
    DictEntityConstrClass():
        refEntityDictId(0),
        refAttribDictId(0),
        entityDictId(0),
        refDeleteRuleEn(RefDelRule_None),
        refCheckRuleEn(RefChkRule_None),
        aggregationEn(Aggegation_None),
        multiplicityEn(Multiplicity_None),
        refDictEntityStp(nullptr),
        refDictAttribStp(nullptr)
    {

    }
    DictEntityConstrClass(const DictEntityConstrClass &ref)
        :DictEntityConstrClass()
    {
        *this = ref;
    }


    virtual ~DictEntityConstrClass()
    {

    }

    // Methods
    DictEntityConstrClass &operator=(const DictEntityConstrClass &ref)
    {
        this->refEntitySqlName = ref.refEntitySqlName;
        this->refAttribSqlName = ref.refAttribSqlName;
        this->entitySqlName    = ref.entitySqlName;
        this->refEntityDictId  = ref.refEntityDictId;
        this->refAttribDictId  = ref.refAttribDictId;
        this->entityDictId     = ref.entityDictId;
        this->refDeleteRuleEn  = ref.refDeleteRuleEn;
        this->refCheckRuleEn   = ref.refCheckRuleEn;
        this->aggregationEn    = ref.aggregationEn;
        this->multiplicityEn   = ref.multiplicityEn;
        this->refDictEntityStp = ref.refDictEntityStp;
        this->refDictAttribStp = ref.refDictAttribStp;

        return *this;
    }

    // Members
    std::string                 refEntitySqlName;
    std::string                 refAttribSqlName;
    std::string                 entitySqlName;

    DICT_T                      refEntityDictId;
    DICT_T                      refAttribDictId;

    DICT_T                      entityDictId;

    REF_DELETE_RULE_ENUM        refDeleteRuleEn;
    REF_CHECK_RULE_ENUM         refCheckRuleEn;

    AGGEGATION_ENUM             aggregationEn;
    MULTIPLICITY_ENUM           multiplicityEn;

    DICT_ENTITY_STP             refDictEntityStp;
    DICT_ATTRIB_STP             refDictAttribStp;
};

class DictEntityClass :public AAAObject
{
public:
    // Constructors
    DictEntityClass();
    DictEntityClass(const DictEntityClass &ref);

    // Destructor
    virtual ~DictEntityClass();

    // Methods
    DictEntityClass &operator=(const DictEntityClass &ref);
    DictAttribClass &addDictAttrib(const DICT_T dictId, const FIELD_IDX_T idx, const std::string &sqlname);
    DictAttribClass &addVirtualAttrib(const DICT_T dictId, const FIELD_IDX_T idx, const std::string &sqlname);
    DictAttribClass *getDictAttribByIdx(FIELD_IDX_T idx);
    DictAttribClass *getDictAttribByDictId(DICT_T dictId);
    DictAttribClass *getDictAttribByShortIdx(FIELD_IDX_T shortIdx);
    DictAttribClass *getDictAttribBySqlName(const std::string &sqlname);
    DictCriterClass *addDictCriteria(DBA_DYNTYPE_ENUM critDynTypeEn, FIELD_IDX_T critProgN);
    DictCriterClass *getDictCriteria(DBA_DYNTYPE_ENUM critDynTypeEn, FIELD_IDX_T critProgN);

    void             setDbSqlName(const char *);

    void             addDictEntityConstr(DICT_ATTRIB_STP dictAttribStp, DICT_ENTITY_STP refDictEntityStp, DICT_ATTRIB_STP refAttribStp); /* PMSTA-26108 - LJE - 171031 */

    bool             isPrimaryKey(std::string attribSqlName);
    bool             isBusinessKey(std::string attribSqlName);

    bool             isMultiBusinessEntityManagement();

    bool             isPhysicalEntity(TARGET_TABLE_ENUM targetTableEn);
    bool             isMetaDict();

    bool             isId() const;
    FIELD_IDX_T      getIdIdx(DBA_DYNTYPE_ENUM) const;
    ID_T             getId(const DBA_DYNFLD_STP) const;
    void             setId(DBA_DYNFLD_STP, ID_T);

    bool             isCode() const;
    const char      *getCode(DBA_DYNFLD_STP) const;
    bool             isUserScriptAuthorized();

    OBJECT_ENUM      getParentObjectEn(const DBA_DYNFLD_STP) const;

    void             finish();
    void             init(bool);

    void             setDictEntitySqlNames();

    bool             isPkToDo(TARGET_TABLE_ENUM);

    // Members
    DICT_T          entDictId;          /* unique identifier determined by dvp          */
    std::string     nameStr;               /* conceptual name                              */
    std::string     labelStr;              /* label in user language                       */
    UnicodeString   uniLabelStr;           /* unicode label in user language               */

    SYSNAME_T       mdSqlName;          /* meta-dictionary name                         */
    SYSNAME_T       dbSqlName;          /* database physical name                       */
    SYSNAME_T       custSqlName;        /* physical ud table name                       */ /* REF10392 - LJE - 040624 */
    SYSNAME_T       precompSqlName;     /* physical ext table name with database access */ /* PMSTA-11505 - LJE - 110315 */

    std::string     databaseName;       /* database name                                */
    SYSNAME_T       segName;            /* segment name                                 */ /* PMSTA-13109 - LJE - 111116 */
    std::string     custDbName;         /* ud table database name                       */ /* PMSTA-11505 - LJE - 110315 */
    SYSNAME_T       precompDbName;      /* TSL extension database name                  */ /* PMSTA-11505 - LJE - 110315 */

    FLAG_T          refAuthFlg;         /* may be referenced by a custom field          */
    FLAG_T          custAuthFlg;        /* custom fields may be added                   */
    FLAG_T          mainFlg;            /* principal entity or not                      */
    TYPINGNAT_ENUM  tpNatEn;            /* 0 -> no typing associated,
                                        ** 1 -> parent type only
                                        ** 2 -> parent type or subtype                  */
    FLAG_T          entDictIdFlg;       /* contains one attribute referring to
                                        ** dict_entity                                  */
    FLAG_T          synonFlg;           /* may be referenced by a codification          */
    FLAG_T          listFlg;            /* may be referenced by a set                   */
    FLAG_T          qSearchFlg;         /* entity have one attribute with a
                                        ** significant quick search mask                 */
    FLAG_T          logicalFlg;         /* logical entity or not                        */
    ENUM_T          interf;             /* interface enum                               */
    FIELD_IDX_T     natIndex;           /* nature index                                 */     /* DVP338 */
    bool            isNullNatIndex;     /* nature index Null Info, true if is null */
    FIELD_IDX_T     parIndex;           /* parent index                                 */     /* DVP338 */
    bool            isNullParIndex;     /* parent index Null Info, true if is null */

    FLAG_T          precompFlg;         /* TLS precomputed flag */      /* PMSTA-11505 - LJE - 110315 */
    FLAG_T          usePrecompFlg;      /* TLS uses precomputed flag */ /* PMSTA-11505 - LJE - 110315 */
    ID_T            precompStdFormatId; /* TLS standard format */       /* PMSTA-11505 - LJE - 110315 */
    ID_T            precompUsrFormatId; /* TLS user format */           /* PMSTA-11505 - LJE - 110315 */

    DATETIME_T      lastModifDate;      /* Last structure modification date */ /* PMSTA-11505 - LJE - 110315 */
    SMALLINT_T      precompRankN;       /* */                                 /* PMSTA-11505 - LJE - 110315 */
    SYSNAME_T       shortSqlname;       /* Short sqlname */                   /* PMSTA-11505 - LJE - 110315 */
    SYSNAME_T       aliasSqlname;       /* Default alias uses */              /* PMSTA-11505 - LJE - 110315 */

    INT_T           custNbr;            /* custom attribute number                      */
    INT_T           precompNbr;         /* precomp. (ext) attribute number              */ /* PMSTA-11505 - LJE - 110615 */
    int             primKeyNbr;         /* primary key number, find by reading          */
    /* primary_key_f from attributes                */
    DICT_ATTRIB_STP *primKeyTab;                                                           /* PMSTA-13122 - LJE - 120614 */
    int             visKeyNbr;          /* visual key number, find by reading           */
    /* business_key_f from attributes               */
    int             visUnKeyIdx;        /* unique business key index                    */

    FIELD_IDX_T     firstCustPos;
    FIELD_IDX_T     firstPrecompPos;
    FIELD_IDX_T     firstLogicalPos;
    FIELD_IDX_T     firstCOnlyPos;
    FIELD_IDX_T     firstInternalPos;

    std::map<DICT_T,      DictAttribClass*>  attribMap;   /* list of attributes by dict_id                */ /* PMSTA-26108 - LJE - 170918 */
    std::vector<DictAttribClass*>            attr;        /* list of attributes by prog number            */
    std::vector<DictAttribClass*>            buildAttr;   /* list of build attributes by prog number            */
    std::map<std::string, DictAttribClass*>  sortedAttr;  /* list of attributes by sqlname                */

    std::map<FIELD_IDX_T, DictCriterClass*>  criterMap;                    /* some criteria to introduce                   */
    std::map<FIELD_IDX_T, DictCriterClass*>  shortDictCriteriaMap;         /* list of criteria                             */ /* PMSTA-26108 - LJE - 170918 */
    std::map<FIELD_IDX_T, DictCriterClass*>  allDictCriteriaMap;           /* list of criteria                             */ /* PMSTA-26108 - LJE - 170918 */
    std::map<FIELD_IDX_T, DictCriterClass*>  shortAllDbDictCriteriaMap;    /* list of criteria                             */ /* PMSTA-29879 - LJE - 180704 */

    std::vector<DictAttribClass*>            logicalTab;         /* Logical attributes                           */  /* PMSTA-26108 - LJE - 170926 */

    FLAG_T          useScreenFlg;       /* use screen or not                            */
    FLAG_T          inputCtrlFlg;       /* has a logical input control attrib - DVP587  */
    FLAG_T          notepadFlg;         /* has a logical notepad attribute              */
    DICT_ATTRCOPY_ENUM  copyRightEn;    /*  Is a logical entity copyable                */  /*  FIH-REF10967-050204 */
    bool            bDictScreenRights;  /* has the rights to define a  DictScreen       */  /*  HFI-PMSTA-51777-2022-01-06  */

    INFO_T          pszSelectString;    /*  Last used string by find in select window   */  /*  FIH-REF5967-010522  transform CODE_T into INFO_T    */
    int             iSelectStringIndex; /*  Index in attributes list                    */
    short           enSelectMode;       /*  Current selection mode                      */  /*  FIH-REF10391-041126 */
    ID_T            enSelectNature;     /*  Last selected nature                        */  /*  FPL-PMSTA08801-091119 long to ID_T  */
    DICT_T          dictSelectFunction; /*  Last selected function                      */
    DBA_DYNFLD_STP  pdbadynSearch,      /*  Quick Search select data                    */  /* MRA - REF4333.2 - 020729 */
                    pdbadynSelectList,  /*  Short structure of last selection list      */  /*  FIH-REF10391-041126 */
                    pdbadynQSearch;     /*  Short structure of last qSearch   list      */  /*  FPL-REF10391-041210 */
    ID_T            idSelectList;       /*  Id of the last selected list                */  /*  FIH-REF10391-041126 */
    char            *pszList;           /*  Last list search                            */  /*  FIH-REF10391-041126 *//*    FPL-REF10391-041203 */

    FLAG_T          fullSearchFlg;      /* FIH-REF7207-011120  full search activates    */
    DBA_DYNST_ENUM  enLinkedDbaDynSt;   /*  Linked dynamic structure                    */  /*  FIH-REF9790-040219  */
    ID_T            idLinkedObject;     /*  Linked Object                               */  /*  FIH-REF9790-040223  */  /*  FPL-PMSTA08801-091008 longID from DICT_T    */

    FLAG_T          entMDFlg;           /* REF10342 - LJE - 040618 */
    FLAG_T          entDefInCFlg;       /* REF8844 - LJE - 030417 */
    FLAG_T          virtualEntFlg;      /* REF9789 - LJE - 031231 */
    FLAG_T          virtualAttrFlg;     /* REF9789 - LJE - 040105 */
    FLAG_T          validEntFlg;        /* REF9789 - LJE - 040102 : TRUE if entity is valid and can be used */
    FIELD_IDX_T     srcEntDictIdIdx;    /* REF9764 - LJE - 040112 */
    int             orgEntityNbr;       /* REF9764 - LJE - 040112 */
    DICT_ENTREF_STP orgEntityTab;       /* REF9764 - LJE - 040112 */
    int             useEntityNbr;       /* REF9764 - LJE - 040112 */
    DICT_ENTREF_STP useEntityTab;       /* REF9764 - LJE - 040112 */
    FLAG_T          invertSortFlag;     /*  FPL-REF11029-050310 sorting upward/downward the col */
    short           sortMenuId;        /*  FPL-REF11029-050310 witch col to be sorted           */
    int             iNbLinkedDimObj;   /*  FPL-REF11563-051209 if there are dim/obj linked for the entity  */

    /* PMSTA-11505 - LJE - 110315 */
    /* New information to add in dict_entity... */
    FLAG_T          dictLabelFlg;       /* Define if exists informations in dict_label  */
    /* PMSTA-13109 - LJE - 111214 */
    DBA_ENTITY_NAT_ENUM  entNatEn;
    XD_STATUS_ENUM       xdStatusEn;
    bool                 bIsInitEntity;

    /* PMSTA-13122 - LJE - 120523 */
    ENTITY_SECURITY_LEVEL_ENUM  securityLevelEn;
    MASK_T           automaticMask;
    ID_T             adminFctDictId;

    /* PMSTA-14452 - LJE - 130118 */
    PK_RULE_ENUM     pkRuleEn;

    /* PMSTA-23385 - LJE - 160706 */
    FEATURE_AUTH_ENUM          auditAuthEn;            /* Audit authorisation management                */
    FEATURE_AUTH_ENUM          activeAuthEn;           /* Active flag authorisation management          */
    FEATURE_AUTH_ENUM          updFctAuthEn;           /* Update function authorisation management      */
    FEATURE_AUTH_ENUM          externalSeqAuthEn;      /* External sequencing authorisation management  */

    LOAD_DICT_RULE_ENUM        loadDictRuleEn;
    DML_MODIF_TRACK_ENUM       dmlModifTrackEn;

    FEATURE_AUTH_ENUM          partAuthEn;            /* Partitioning authorisation */ /* PMSTA-24563 - LJE - 160921 */
    FEATURE_AUTH_ENUM          dlmAuthEn;             /* Data life management authorisation */ /* PMSTA-24563 - LJE - 160921 */

    MultiEntityHelper          multiEntityCateg;            /* PMSTA-29879 - LJE - 180712 */
    ME_SPECIALISATION_ENUM     meSpecialisationEn; /* PMSTA-32145 - LJE - 180719 */

    /* PMSTA-18593 - LJE - 150202 */
    DELETE_RULE_ENUM    deleteRuleEn;
    LAST_MODIF_ENUM     objModifStatEn;
    LAST_MODIF_ENUM     tableModifStatEn;
    LAST_MODIF_ENUM     lastModifEn;

    /* PMSTA-21717 - LJE - 160119 */
    DB_RULE_ENUM    dbRuleEn;
    ID_T            linkedEntityDictId;
    DICT_ENTITY_STP linkedEntityStp;        /* PMSTA-26250 - LJE - 170405 */

    std::map<DICT_T, DICT_ENTITY_STP> linkEntitiesMap;      /* PMSTA-29885 - LJE - 180123 */
    std::map<DICT_T, DICT_ENTITY_STP> physicalEntitiesMap;  /* PMSTA-37374 - LJE - 201214 */

    ID_T            physicalEntityDictId;
    DICT_ENTITY_STP physicalEntityStp;      /* PMSTA-26250 - LJE - 170405 */

    DICT_ENTITY_STP pkEntityStp;            /* PMSTA-26250 - LJE - 170405 */
    DICT_ENTITY_STP shadowEntityStp;        /* PMSTA-26250 - LJE - 170405 */
    DICT_ENTITY_STP beEntityStp;            /* PMSTA-32145 - LJE - 180718 */


    /* PMSTA-13122 - LJE - 120516 - Set by the function DictEntityClass::init() */
    OBJECT_ENUM		 objectEn;

    DICT_ATTRIB_STP *bkAttr;
    int              bkAttrNbr;

    int              dbPKNbr;        /* primary key number, find by reading          */
    DICT_ATTRIB_STP *dbPKTab;        /* prog_pk_n from attributes                    */
    int              dbBKNbr;        /* business key number, find by reading         */
    DICT_ATTRIB_STP *dbBKTab;        /* prog_bk_n from attributes                    */

    int              udPKNbr;        /* user defined fields primary key array  */
    DICT_ATTRIB_STP *udPKTab;

    DICT_ATTRIB_STP  parentAttrStp; /* PMSTA-26250 - LJE - 170331 */

    DICT_ATTRIB_STP  optimisticLockingAttrStp;
    DICT_ATTRIB_STP  externalSeqNoAttrStp;      /* PMSTA-23385 - LJE - 160712 */
    DICT_ATTRIB_STP  rightToRunAttrStp;         /* PMSTA-23385 - LJE - 160712 */
    DICT_ATTRIB_STP  activeAttrStp;             /* PMSTA-23385 - LJE - 160712 */

    DICT_ATTRIB_STP  ownerBusinessEntAttrStp;     /* PMSTA-26108 - LJE - 170818 */
    DICT_ATTRIB_STP  udOwnerBusinessEntAttrStp;   /* PMSTA-26108 - LJE - 170818 */
    DICT_ATTRIB_STP  extOwnerBusinessEntAttrStp;  /* PMSTA-26108 - LJE - 170818 */
    /* PMSTA-26108 - LJE - 171127 */
    bool             bMultiEntityOnPrecomp;
    bool             bMultiEntityOnCustom;

    FLAG_T           multiEntUKFlg;  /* OCS-43062 - LJE - 130909 - The entity are has unique key (pk or bk)
                                        the both attributes entity_dict_id and object_id */

    /* PMSTA-14086 - LJE - 121005 - Optional set by the method DllGen::GetXdEntityId */
    ID_T             xdEntityId;

    FEATURE_AUTH_ENUM changeSetAuthEn; /* PMSTA-26250 - LJE - 170330 */

    DICT_LICENSEKEY_ENUM    licenseKeyEn;               /*  License that authorised or not the entity   HFI-PMSTA-35838-190515  */
    DICT_FCTAUTH_ENUM       licenseAccessStatusEn;      /*  Access status based on license              HFI-PMSTA-35838-190515  */

    std::map<DictEntityConstrKey, DictEntityConstrClass> dictEntityConstrMap;
    std::map<DictAttribClass*, DictEntityClass*>         dictEntityRefMap;

    MemoryPool              m_mp;
    /*  Pacakge Management: or complete table or record one by one are saved in package     */  /*  HFI-PMSTA-41842-200916  */
    enum class IsPackageEn
    {
        No                           = 0            /*  Not in package      */
    ,   Record                       = 1            /*  Record one by one   */
    ,   Table                        = 2            /*  Complete table      */
    };
    IsPackageEn     enIsPackage;

    std::map<std::string, DBA_DYNFLD_STP>                  xdIndexMap;
    std::map<DBA_DYNFLD_STP, std::vector<DBA_DYNFLD_STP>>  xdIndexAttribMap;

    /*  entity security access for super user only  */  /*  HFI-PMSTA-54127-2024-02-06  */
    bool                    bSecuredBySuperUser;
};

class DdlSelectElt
{
public:
    // Constructors
    DdlSelectElt();
    DdlSelectElt(const DdlSelectElt&);

    // Destructor
    virtual ~DdlSelectElt();

    DdlSelectElt& operator=(const DdlSelectElt& toCopy);

    std::string       sqlName;
    std::string       mdSqlName;
    std::string       varName;
    std::string       colAlias;
    std::string       tblAlias;
    DATATYPE_ENUM     datatype;
    std::string       value;
    bool              bOutput;
    bool              bMandatory;
    bool              bPrintDefValIfNull;
    std::string       defaultValueStr;
    bool              bShadowAttrib;
    bool              bPrimaryKey;

    DICT_ATTRIB_STP   attribStp;
};

/* PMSTA-nuodb - LJE - 190417 */
class DictSprocReturnsClass
{
public:
    // Constructors
    DictSprocReturnsClass(const std::string &returnsSqlName,
                          const std::list<DdlSelectElt> &selectList,
                          size_t pos,
                          DBA_DYNTYPE_ENUM outputDynNatEn,
                          DBA_DYNST_ENUM   dynStEn)
        : m_returnsSqlName(returnsSqlName)
        , m_selectList(selectList)
        , m_pos(pos)
        , m_outputDynNatEn(outputDynNatEn)
        , m_dynStEn(dynStEn)
    {
    }
    DictSprocReturnsClass(const DictSprocReturnsClass &refElt)
        : DictSprocReturnsClass(refElt.m_returnsSqlName, refElt.m_selectList, refElt.m_pos, refElt.m_outputDynNatEn, refElt.m_dynStEn)
    {
        this->m_selectListStr = refElt.m_selectListStr;
    }

    // Destructor
    virtual ~DictSprocReturnsClass()
    {
    }

    DictSprocReturnsClass& operator=(const DictSprocReturnsClass& toCopy)
    {
        this->m_returnsSqlName = toCopy.m_returnsSqlName;
        this->m_selectList     = toCopy.m_selectList;
        this->m_pos            = toCopy.m_pos;
        this->m_selectListStr  = toCopy.m_selectListStr;
        this->m_outputDynNatEn = toCopy.m_outputDynNatEn;
        this->m_dynStEn        = toCopy.m_dynStEn;
        return *this;
    }

    std::string geReturnsSqlName()
    {
        if (this->m_pos == 0)
        {
            return this->m_returnsSqlName;  /* Administrative output, like messages */
        }
        return SYS_Stringer(this->m_returnsSqlName, "_", this->m_pos);
    }

    std::string             m_returnsSqlName;
    size_t                  m_pos;
    std::list<DdlSelectElt> m_selectList;
    std::string             m_selectListStr;

    DBA_DYNTYPE_ENUM        m_outputDynNatEn;
    DBA_DYNST_ENUM          m_dynStEn;
};


class DictSprocParamClass
{

public:
    DictSprocParamClass(const std::string& sqlName, DATATYPE_ENUM dataTypeEn)
        : attrDictId(0)
        , attrStp(nullptr)
        , pkAttrFlg(FALSE)
        , codifFlg(FALSE)
        , m_sqlName(sqlName)
        , rank(0)
        , inputFlg(FALSE)
        , outputFlg(FALSE)
        , defaultValueC(std::string())
        , deletedFlg(FALSE)
        , m_dataTypeName(std::string())
        , m_dataTypeEn(NullDataType)
    {
        this->setDataType(dataTypeEn);
    }

    DictSprocParamClass(DICT_ATTRIB_STP dictAttribStp)
        : DictSprocParamClass(dictAttribStp->sqlName, dictAttribStp->dataTpProgN)
    {
        this->attrStp = dictAttribStp;
        this->attrDictId = this->attrStp->attrDictId;
    }

    DictSprocParamClass()
        : DictSprocParamClass(std::string(), NullDataType)
    {}


    DictSprocParamClass(const DictSprocParamClass &toCopy)
    {
        *this = toCopy;
    }

    virtual ~DictSprocParamClass()
    {
    }

    DictSprocParamClass& operator=(const DictSprocParamClass &toCopy)
    {
        this->attrDictId     = toCopy.attrDictId;
        this->attrStp        = toCopy.attrStp;
        this->pkAttrFlg      = toCopy.pkAttrFlg;
        this->codifFlg       = toCopy.codifFlg;
        this->m_sqlName      = toCopy.m_sqlName;
        this->rank           = toCopy.rank;
        this->inputFlg       = toCopy.inputFlg;
        this->outputFlg      = toCopy.outputFlg;
        this->defaultValueC  = toCopy.defaultValueC;
        this->deletedFlg     = toCopy.deletedFlg;
        this->m_dataTypeName = toCopy.m_dataTypeName;
        this->m_dataTypeEn   = toCopy.m_dataTypeEn;

        return *this;
    }

    bool operator>(const DictSprocParamClass &ref) const
    {
        return this->m_sqlName > ref.m_sqlName;
    }
    bool operator<(const DictSprocParamClass &ref) const
    {
        return this->m_sqlName < ref.m_sqlName;
    }

    bool operator==(const DictSprocParamClass &ref) const
    {
        return ref.m_sqlName == this->m_sqlName;
    }

    void setDataType(const std::string&);
    void setDataType(DICT_T);
    void setDataType(DATATYPE_ENUM);
    std::string getDataTypeStr();
    DICT_T getDataTypeDictId();
    DATATYPE_ENUM getDataTypeEn();

    DICT_T          attrDictId;
    DICT_ATTRIB_STP attrStp;

    FLAG_T          pkAttrFlg; /* PMSTA-14452 - LJE - 121105 */
    FLAG_T          codifFlg;

    std::string     m_sqlName;
    SMALLINT_T      rank;

    FLAG_T          inputFlg;
    FLAG_T          outputFlg;

    std::string     defaultValueC;

    FLAG_T          deletedFlg;

protected:

    std::string     m_dataTypeName;
    DATATYPE_ENUM   m_dataTypeEn;
};

class DictSprocClass
{
public:
    DictSprocClass(OBJECT_ENUM  paramObjectEn)
        : procActionEn(NullAction)
        , procAccessEn(ProcAccess_None)
        , inputObjectEn(NullEntity)
        , outputDynTypeEn(DynType_Null)
        , outputObjectEn(NullEntity)
        , synonymFlg(FALSE)
        , translateFlg(FALSE)
        , role(UNUSED)
        , bStdProc(false)
        , executeAsEn(ExecuteAs_None)
        , functionFlg(FALSE)
        , bDeterministic(false)
        , retDataType(NullDataType)
        , priority(0)
        , bOnEachDatabase(false)
        , bWithRecomplie(false)       /* PMSTA-38987 - LJE - 200214 */
        , dmlAccess(Synchronous)
        , objectEn(paramObjectEn)
        , dictEntityStp(nullptr)

    {
        this->setObjectEn(this->objectEn);
    }

    DictSprocClass()
        : DictSprocClass(NullEntity)
    {
    }

    DictSprocClass(const DictSprocClass &toCopy)
        : DictSprocClass()
    {
        *this = toCopy;
    }

    virtual ~DictSprocClass()
    {

    }

    DictSprocClass& operator=(const DictSprocClass &toCopy)
    {
        this->sqlName                  = toCopy.sqlName;
        this->dbName                   = toCopy.dbName;
        this->objectEn                 = toCopy.objectEn;
        this->dictEntityStp            = toCopy.dictEntityStp;
        this->procActionEn             = toCopy.procActionEn;
        this->procAccessEn             = toCopy.procAccessEn;
        this->inputObjectEn            = toCopy.inputObjectEn;
        this->outputDynTypeEn          = toCopy.outputDynTypeEn;
        this->outputObjectEn           = toCopy.outputObjectEn;
        this->synonymFlg               = toCopy.synonymFlg;
        this->translateFlg             = toCopy.translateFlg;
        this->role                     = toCopy.role;
        this->m_paramProcAttribVector  = toCopy.m_paramProcAttribVector;
        this->m_dictSprocReturnsVector = toCopy.m_dictSprocReturnsVector;
        this->bStdProc                 = toCopy.bStdProc;
        this->executeAsEn              = toCopy.executeAsEn;
        this->functionFlg              = toCopy.functionFlg;
        this->bDeterministic           = toCopy.bDeterministic;
        this->retDataType              = toCopy.retDataType;
        this->priority                 = toCopy.priority;
		this->bOnEachDatabase          = toCopy.bOnEachDatabase;
		this->bWithRecomplie           = toCopy.bWithRecomplie; /* PMSTA-38987 - LJE - 200214 */
        this->dmlAccess                = toCopy.dmlAccess;
        this->m_storedProcAccessVector = toCopy.m_storedProcAccessVector;

        return *this;
    }

    bool operator>(const DictSprocClass &ref) const
    {
        return ref.sqlName > this->sqlName;
    }
    bool operator<(const DictSprocClass &ref) const
    {
        return ref.sqlName < this->sqlName;
    }

    bool operator==(const DictSprocClass &ref) const
    {
        return ref.sqlName == this->sqlName;
    }

    void reset()
    {
        this->sqlName         = std::string();
        this->dbName          = std::string();
        this->objectEn        = NullEntity;
        this->dictEntityStp   = nullptr;
        this->procActionEn    = NullAction;
        this->procAccessEn    = ProcAccess_None;
        this->inputObjectEn   = NullEntity;
        this->outputDynTypeEn = DynType_Null;
        this->outputObjectEn  = NullEntity;
        this->synonymFlg      = FALSE;
        this->translateFlg    = FALSE;
        this->role            = UNUSED;
        this->bStdProc        = false;
        this->executeAsEn     = ExecuteAs_None;
        this->functionFlg     = FALSE;
        this->bDeterministic  = false;
        this->retDataType     = NullDataType;
        this->priority        = 0;
		this->bOnEachDatabase = false;
		this->bWithRecomplie  = false;  /* PMSTA-38987 - LJE - 200214 */
        this->dmlAccess       = Synchronous;

        this->m_paramProcAttribVector.clear();
        this->m_dictSprocReturnsVector.clear();
        this->m_storedProcAccessVector.clear();
    }

    void                  setObjectEn(OBJECT_ENUM newObjEn)
    {
        this->objectEn      = newObjEn;
        this->dictEntityStp = DBA_GetDictEntitySt(this->objectEn);
    }

    OBJECT_ENUM           getObjectEn() const
    {
        return this->objectEn;
    }

    DICT_ENTITY_STP       getDictEntityStp() const
    {
        return this->dictEntityStp;
    }

    static std::string          getDynTypeStr(DBA_DYNTYPE_ENUM dynTypeEn);
    static DBA_ACTION_ENUM      getProcAction(const std::string& action);
    static DBA_PROC_ACCESS_ENUM getProcAccess(const std::string& procAccess);
    static std::string          getDmlAccessStr(DBA_CONNECT_TYPE_ENUM dmlAccessEn);
    static std::string          getBatchRowNumName();

    std::string            getOutputDynTypeStr();
    std::string            getInputDynTypeStr();
    std::string            getProcAccessStr();
    std::string            getProcActionStr();

    std::string            getSprocStdBeginStr();

    static bool            isRdbmsBatchAllowed(DBA_RDBMS_ENUM);
    static bool            isRoleBatchAllowed(int);
    static bool            isActionBatchAllowed(DBA_ACTION_ENUM);
    bool                   isBatchAllowed(DBA_RDBMS_ENUM);

    std::string           sqlName;
    std::string           dbName;               /* PMSTA-26250 - LJE - 170407 */

    DBA_ACTION_ENUM		  procActionEn;
    DBA_PROC_ACCESS_ENUM  procAccessEn;
    OBJECT_ENUM           inputObjectEn;
    DBA_DYNTYPE_ENUM      outputDynTypeEn;
    OBJECT_ENUM           outputObjectEn;

    FLAG_T                synonymFlg;
    FLAG_T                translateFlg;

    int                   role;                 /* PMSTA-14452 - LJE - 121102 */

    std::vector<DictSprocParamClass>    m_paramProcAttribVector;
    std::vector<DictSprocReturnsClass>  m_dictSprocReturnsVector;   /* PMSTA-nuodb - LJE - 190417 */

    bool                  bStdProc;

    DBA_EXECUTE_AS_ENUM   executeAsEn;
    FLAG_T                functionFlg;
    bool                  bDeterministic;
    DATATYPE_ENUM         retDataType;

    char                  priority;
	bool                  bOnEachDatabase;
	bool                  bWithRecomplie;

    DBA_CONNECT_TYPE_ENUM dmlAccess;

    std::vector<DBA_PROC_STP> m_storedProcAccessVector;

protected:
     OBJECT_ENUM           objectEn;
     DICT_ENTITY_STP       dictEntityStp;
};

typedef struct
{
    DICT_T          dictId;
    CODE_T          code;
    NAME_T          name;
    INFO_T          denom;
    SYSNAME_T       sqlName;
    CODE_T          thousSep;
    CODE_T          decimSep;
    CODE_T          dateFmt;
    FLAG_T          tslMultilingualFlg;
    STRING1000_T    label;
    UNI_STRING1000_T uniLabel;
} DICT_LANG_ST, *DICT_LANG_STP;

typedef struct
{
    DICT_T          dictId;
    NAME_T          name;
    STRING1000_T    label;    /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    UNI_STRING1000_T uniLabel; /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    SYSNAME_T       sqlName;
    NAME_T          equivType;
    NAME_T          equivTypeSyb;
    NAME_T          equivTypeOra;
    NAME_T          equivTypeNuoDB;
    NAME_T          equivTypeMsSql;
    NAME_T          equivTypePgs;
    SMALLINT_T      progN;    /* REF11704 - TEB - 060505 - Change to correct type*/ /* DLA - REF9089 - 030509 */
    FLAG_T          custAuthFlg;
    SMALLINT_T      defMaxDbLenN;               /* PMSTA-34373 - LJE - 190219 */
    SMALLINT_T      defDefaultDisplayLenN;      /* PMSTA-34373 - LJE - 190219 */
} DICT_DATATP_ST, *DICT_DATATP_STP;

typedef enum {
    DictFctDom_None,
    DictFctDom_Dom,
    DictFctDom_EDom,
    DictFctDom_ADom,		/* DVP463 */
    DictFctDom_OpSearch		/* MDE  3.50  - 991210 - REF2467 */
} DICT_FCTDOM_ENUM;

typedef enum
{
    DictFctMod_Core,
    DictFctMod_Productivity,
    DictFctMod_Attribution,
    DictFctMod_Risk,
    DictFctMod_CorporateActions, /* DRI - 20000322 - REF4306 */
    DictFctMod_AdvancedAnalytics,
    DictFctMod_CompositeManagement,
    DictFctMod_ExcelReport,
    DictFctMod_ReturnAnalysis,
    DictFctMod_AdvancedConstraintManagement,
    DictFctMod_OrderManagement,

    DictFctMod_Last             /* INSERT BEFORE                    */
} DICT_FCTMOD_ENUM;

/*  FIH-REF6116-010618  Module Pack */
typedef enum
{
    DictFctModPack_No = -1,
    DictFctModPack_Core,
    DictFctModPack_PerformanceAttribution,
    DictFctModPack_CompositeManagement
} DICT_FCTMOD_TOP_ENUM;


typedef struct
{
    DICT_T				  dictId;
    NAME_T			      name;			/* SQL042 - 960403 - RAK */
	STRING1000_T	      label;          /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    UNI_STRING1000_T      uniLabel;       /* unicode label in user language      *//* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    SYSNAME_T			  procName;
    DICT_T				  parFctDictId;
    DICT_T                entDictId;              /* MODIB BD - RAK - 020506 */
    DICT_T                orderEntryFctDictId;    /* MODIB BD - RAK - 020506 */
    ENUM_T				  natEn;
    ID_T                  typeId,         /* DLA - REF9089 - 030512 */    /*  FPL-PMSTA08801-091008 longID from DICT_T    */
                          subtypeId;
    DICT_T				  refFctDictId;	/* SQL042 - 960403 - RAK */
    SYSNAME_T			  helpNode;		/* SQL042 - 960403 - RAK */
    INFO_T   			  iconName;		/* ROI - 961108 - DVP245 */
    SMALLINT_T			  rank;			/* RAK - 970203 - DVP338 */
    ID_T				  funcSecuProfId;	/* ROI - 961115 - DVP245 */
    DICT_T				  entityDictId;	/* ROI - 961108 - DVP245 */
    ENUM_T				  minOpStatus;	/* ROI - 961108 - DVP245 */
    ENUM_T				  maxOpStatus;	/* ROI - 961108 - DVP245 */
    ENUM_T				  securityLevel;	/* ROI - 961108 - DVP245 */
    FLAG_T				  createFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				  updateFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				  deleteFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				  riskViewFlag;	/* ROI - 961108 - DVP245 */
    FLAG_T				  realTimeFlag;	/* ROI - 961108 - DVP245 */
    FLAG_T				  viewFlag;		/*  FIH-REF6135-010702  */
    FLAG_T				  visibleFlag;    /*  FIH-REF6135-010702  */
    DICT_LICENSEKEY_ENUM  licenseKeyEn;               /*  Licence that authorised or not the function HFI-PMSTA-35838-190515  */
    DICT_FCTAUTH_ENUM	  accesStatus;	/* ROI - 961111 - DVP245 */

    /* Added field for C purpose only */
    short				idx;			/* Manage multiple admin. lines in SV_DictFctTab */
    DICT_FCTMOD_ENUM	module;			/* ROI - 961108 - DVP245 */
    PTR					iconPtr;		/* ROI - 961112 - DVP245 */
    DICT_FCTDOM_ENUM	domEn;			/* ROI - 961108 - DVP245 */
    FLAG_T				finaFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				fmtFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				docFlag;		/* ROI - 961108 - DVP245 */
    FLAG_T				finFlag;		/* ROI - 961108 - DVP245 */
    short				fmtTabIdx;		/* ROI - 961108 - DVP245 */
    short				docTabIdx;		/* ROI - 961108 - DVP245 */
    short				finTabIdx;		/* ROI - 961108 - DVP245 */
    short				guiMenuId;		/* ROI - 961114 - DVP245 */
    short				childNb;		/* ROI - 961114 - DVP245 */

    short				opSecuRank;		/* FIH - 980616 - REF1504 */

    FLAG_T              maximizeFlg;    /*  FIH-REF7207-011120  Maximize screen flag                */
    short               oriX,           /*  FIH-REF7207-011120  Origin abcissis                     */
                        oriY,           /*  FIH-REF7207-011120  Origin ordonate                     */
                        extX,           /*  FIH-REF7207-011120  Extension abcissis                  */
                        extY;           /*  FIH-REF7207-011120  Extension ordonate                  */
    FLAG_T              bViewDomain;    /*  FPL-REF7542-020605 view domain in function screen       */
    FLAG_T              bViewToolsBar;  /*  FPL-REF7542-020605 view tools bar in function screen    */
    FLAG_T              bViewAdminBut;  /*  FPL-REF10712-041022 view administration button in function screen   */
    FLAG_T              fullSearchFlg;  /*  MRA - 040123 - REF9789 to seperate the casse of function with entity fullSearchFlag     */
    FLAG_T              flagQuickSearch;/*  FIH-REF9867-020406  Separte the possibility to perform QS and full serach flag value    */

} DICT_FCT_ST, *DICT_FCT_STP;

/* ROI - 961108 - DVP245 */
typedef enum {
    DictFctInfo_DictId,
    DictFctInfo_Name,
    DictFctInfo_Label,
    DictFctInfo_UniLabel, /* REF9303 - LJE - 030912 */
    DictFctInfo_ProcName,
    DictFctInfo_ParDictId,
    DictFctInfo_Nature,
    DictFctInfo_RefDictId,
    DictFctInfo_HelpNode,
    DictFctInfo_IconName,
    DictFctInfo_EntityDictId,
    DictFctInfo_MinOpStatus,
    DictFctInfo_MaxOpStatus,
    DictFctInfo_SecurityLevel,
    DictFctInfo_CreateFlag,
    DictFctInfo_UpdateFlag,
    DictFctInfo_DeleteFlag,
    DictFctInfo_RiskViewFlag,
    DictFctInfo_RealTimeFlag,

    /* Added field for C purpose only */
    DictFctInfo_Stp,
    DictFctInfo_StpByIdx,
    DictFctInfo_AccesStatus,
    DictFctInfo_FinaFlag,
    DictFctInfo_DomEnum,
    DictFctInfo_FmtFlag,
    DictFctInfo_DocFlag,
    DictFctInfo_FinFlag,
    DictFctInfo_FmtTabIdx,
    DictFctInfo_DocTabIdx,
    DictFctInfo_FinTabIdx
} DICT_FCT_INFO_ENUM;


#define	FIRSTUSERDICTFCT	100
#define	BASEGUIID		10000
#define	ADDGUIID		100




/*********************************
***  DEV5502 - CSA - 05122000  ***
*********************************/
struct  DICT_LABEL_ST
{
	DICT_T		    object_dict_id;
	char           *dlLabel;               /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */   /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    UChar          *dlUniLabel;            /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */   /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */

    /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
    size_t          dlLabelLen;
    size_t          dlUniLabelLen;

    void SET_dlLabel(const char *strIn)
    {
        size_t   strInLen = 1;

        if (strIn)
        {
            strInLen += strlen(strIn);
        }

        if (strInLen > dlLabelLen || dlLabel == NULL)
        {
            dlLabel = static_cast<char *> (REALLOC(dlLabel, strInLen * sizeof(char)));
            dlLabelLen = strInLen;
        }

        if (strIn)
        {
            strcpy(dlLabel, strIn);
        }
        else
        {
            dlLabel[0] = 0;
        }

    }

    const char *GET_dlLabel(void)           /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (dlLabel==NULL)
            return EMPTY_STR;
        else
            return dlLabel;
    }

    void SET_dlUniLabel(const UChar *strIn)
    {
        size_t strInLen = 1;

        if (strIn)
        {
            strInLen += u_strlen(strIn);
        }

        if (strInLen > dlUniLabelLen || dlUniLabel == NULL)
        {
            dlUniLabel = static_cast<UChar *> (REALLOC(dlUniLabel, strInLen * sizeof(UChar)));
            dlUniLabelLen = strInLen;
        }

        if (strIn)
        {
            u_strcpy(dlUniLabel, strIn);
        }
        else
        {
            dlUniLabel[0] = 0;
        }
    }

    const UChar *GET_dlUniLabel(void)       /*  HFI-PMSTA-22540-160218  Intoduce GET function to avoid direct access to label   */
    {
        if (dlUniLabel==NULL)
            return EMPTY_USTR;
        else
            return dlUniLabel;
    }

    void FREE_dlLabels()
    {
            FREE(dlLabel);
            FREE(dlUniLabel);
    }
};


struct  DICT_LABEL_ENTITY_IDX_ST
{
    DICT_T		            entity_dict_id;
    struct  DICT_LABEL_ST	*labels;
    int                     labelsNumber;
};


struct  DICT_LABEL_LANG_ST
{
    DICT_T				                language_dict_id;
    struct  DICT_LABEL_ENTITY_IDX_ST	*entities;
    int                                 entitiesNumber;
};


/*< PMSTA07964 - LJE - 090325 */
typedef struct DEF_DATA_ENTITY  DEF_DATA_ENTITY_ST,  *DEF_DATA_ENTITY_STP;
typedef struct EVAL_DATA_ENTITY EVAL_DATA_ENTITY_ST, *EVAL_DATA_ENTITY_STP;
typedef struct EVAL_DATA_FLD    EVAL_DATA_FLD_ST,    *EVAL_DATA_FLD_STP;

typedef struct {

    const char          *dataStr;
    int				     dataPos;
    int				     dataSize;

    SYSNAME_T            sqlName;

    USE_TYPE_ENUM        useTypeEn;

    ASSIGN_TYPE_ENUM     assignTypeEn;

    DEF_DATA_ENTITY_STP  fkDefDataEntityStp;

    FLAG_T               forcedFlg;

} DEF_DATA_FLD_ST, *DEF_DATA_FLD_STP;

struct DEF_DATA_ENTITY {

    const char          *defString;

    DEF_DATA_FLD_STP     defDataFldStTab;
    int				     defDataFldNbr;
    int				     defDataFldAllocSize; /* DDV - 210219 - PMSTA - 36104 */

};

struct EVAL_DATA_FLD
{
    DEF_DATA_FLD_STP      defDataFldStp;

    DICT_ATTRIB_STP       attribStp;
    int                   fixedSize;
    char                 *fullSqlName;

    char			     *valueStr;
    int                   size;

    FLAG_T                hideFieldFlg;

    FLAG_T                synonymFlg;
    DBA_DYNFLD_STP        codifStp;
    FLAG_T                denomFlg;

    FLAG_T                fkFlg;
    int                   fkProgN;
    EVAL_DATA_ENTITY_STP  fkEvalDataEntityStp;

    int                   fkPermValDynStpNbr;
    DBA_DYNFLD_STP       *fkPermValDynStpTab;

    EVAL_DATA_ENTITY_STP  parentEvalDataEntityStp;
};

struct EVAL_DATA_ENTITY
{
    DEF_DATA_ENTITY_STP   defDataEntityStp;

    DICT_ENTITY_STP       entityStp;

    OBJECT_ENUM           objEn;

    EVAL_DATA_TYPE_ENUM   evalDataTypeEn;

    DBA_DYNFLD_STP	      dataStp;

    int                   msgNbr;
    DBA_DYNFLD_STP       *msgTab;

    EVAL_DATA_FLD_STP     evalDataFldStTab;
    int                   evalDataFldNbr;

    EVAL_DATA_FLD_STP     parentEvalDataFldStp;
};

typedef struct CONTEXT_ENTITY
{
    DBA_DYNFLD_STP        inputEntityStp;

    ID_T                  userId;
    ID_T                  languageDictId;

    int                   codifStpNbr;
    DBA_DYNFLD_STP       *codifStpTab;

} CONTEXT_ENTITY_ST,  *CONTEXT_ENTITY_STP;

/* PMSTA07964 - LJE - 090325 >*/

class AaaMetaDict
{
public:
    AaaMetaDict(const AaaMetaDict &) = delete;
    AaaMetaDict &operator=(const AaaMetaDict &) = delete;

    static void                                   load();
    static AaaMetaDict                           &getMetaDict();
    static void                                   close();

    static std::vector<DICT_ENTITY_STP>          &getDictEntityVector();
    static OBJECT_ENUM                            getDictEntitySize();
    static DICT_ENTITY_STP                        getNewDictEntityStp(OBJECT_ENUM objectEn);

    static void                                   allocObjProcLstPtr(size_t);
    static void                                   reallocObjProcLstPtr(size_t);
    static void                                   setObjProcLstStp(OBJECT_ENUM, DBA_PROC_STP);
    static void                                   setObjProcLstStp(OBJECT_ENUM, size_t);
    static DBA_PROC_STP                           getObjProcLstStp(OBJECT_ENUM);

    static std::map<std::string, DBA_DYNFLD_STP> &getDictUserMap();

    static std::map<std::string, DBA_DYNST_ENUM> &getDynStByNameMap();

    static MemoryPool                            &getMemoryPool();
    static Lock                                  &getLock();

protected:

    AaaMetaDict();
    virtual     ~AaaMetaDict();
};

/************************************************************************
**      BEGIN External definitions attached to : dbadict.c
*************************************************************************/
/* REF7264 - RAK - 020326 */
extern short	        EV_DictFctNb;
extern short            EV_DictFctWithFmtNb;
extern short	        EV_DictFctWithDocNb;
extern short	        EV_DictFctWithFinNb;
extern short	        EV_DictFctMainWithFinNb;

/* PMSTA07964 - LJE - 090309 */
extern std::vector<DICT_FCT_ST>    EV_DictFctTab;       /* PMSTA-nuodb - LJE - 190507 */

extern DICT_FCT_STP*   EV_DictFctWithFmtTab;
extern DICT_FCT_STP*   EV_DictFctWithDocTab;
/*DICT_FCT_STP* EV_DictFctWithFinTab;*/     /*  FIH-REF5578-010115  No more used    */
extern DICT_FCT_STP*   EV_DictFctMainWithFinTab;   /*  FIH_REF5578-010115  */
extern DICT_FCT_STP**  EV_DictFctSubWithFinTab;    /*  FIH_REF5578-010115  */
extern DICT_T          EV_ServerLanguageID;        /*  DEV5502 - CSA - 25012001    */ /* DLA - REF9089 - 030512 */
extern FLAG_T          EV_DictInitFlg;             /*  PMSTA-22549 - CHU - 160601 */

extern FLAG_T	DBA_CheckDictFctAdmAuth(OBJECT_ENUM);           /*  FIH-REF10209-040429 Suppress DICT_T as first parameter  */
extern RET_CODE	DBA_CheckOpAdmAuth(DICT_T, short, OPNAT_ENUM, OBJECT_ENUM, ID_T, ID_T, ENUM_T, FLAG_T*, FLAG_T*, FLAG_T*, int*, PTR);
extern RET_CODE DBA_CheckOpNatAuth(DICT_T, FLAG_T,FLAG_T,OPSTAT_ENUM,int*,PTR);
extern RET_CODE	DBA_GetDictFctByProcName(char*,DICT_T*);
extern RET_CODE	DBA_GetDictFctStpByProcName (char*, DICT_FCT_STP*);     /*  FIH-PMSTA-16457-130617  */
extern RET_CODE DBA_DictFctCheckAuth();
extern RET_CODE	DBA_GetDictAttribIdxByDictId(OBJECT_ENUM, DICT_T, short*);
extern DICT_ATTRIB_STP DBA_GetDictAttribByDictId(OBJECT_ENUM object, DICT_T dictId);
extern FIELD_IDX_T	DBA_GetDictAttribShortIdxByIdx(OBJECT_ENUM, FIELD_IDX_T);
extern RET_CODE	DBA_GetDictFctAdmAuth(DICT_T, OBJECT_ENUM, DICT_FCT_INFO_ENUM, PTR);
extern RET_CODE DBA_GetDictFctAdmAuthByUser(DICT_T, OBJECT_ENUM, DICT_FCT_STP*);        /*  FPL-REF11314-060512 */
extern short	DBA_GetPermValMaxLabelLen(OBJECT_ENUM, int);
extern short	DBA_GetUniPermValMaxLabelLen(OBJECT_ENUM, int); /* REF9303 - LJE - 030912 */

extern std::vector<DICT_LANG_ST> &DBA_GetDictLangTab();
extern std::vector<DICT_DATATP_ST> &DBA_GetDictDataTpTab();

extern	RET_CODE	DICT_GetAttribInfo(OBJECT_ENUM, FIELD_IDX_T, DICT_T, const char*, FIELD_IDX_T, PTR);    /* REF8728 - YST - 030213 */
extern	FLAG_T		DICT_EntityHasDefValue(OBJECT_ENUM);
extern	RET_CODE	DICT_EntityNatCommonFields(OBJECT_ENUM, ENUM_T, ENUM_T, FLAG_T**);

extern RET_CODE DBA_CheckOpEntAuth(DICT_T, FLAG_T*,FLAG_T*,short,OPNAT_ENUM,OBJECT_ENUM,int*,DICT_T**,int,PERMITED_VALUES_STP);             /*  FIH-REF10983-050215 */
extern RET_CODE DBA_CheckOpEntTypeAuth(DICT_T, FLAG_T*,FLAG_T*,short,OPNAT_ENUM,OBJECT_ENUM,ID_T,int*,ID_T**,int,PERMITED_VALUES_STP);  /*  FIH-REF10983-050215 */    /*  FPL-PMSTA08801-091008 longID from DICT_T    */
extern RET_CODE DBA_CheckNumberOfDictFct (DICT_T,DICT_T,OBJECT_ENUM,ID_T,ID_T,short*,ID_T**);   /*  FPL-PMSTA08801-091008 longID from DICT_T    */
extern RET_CODE DBA_CheckCreateOperation(DICT_T,FLAG_T*,FLAG_T*,int,PERMITED_VALUES_STP);                                                   /*  FIH-REF10983-050215 */
extern RET_CODE DBA_CheckCreateEntity(DICT_T,OBJECT_ENUM,FLAG_T*,FLAG_T*);  /*  FPL-REF10234-040507 */


extern RET_CODE	DBA_ConvertAllDynstToShort(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *);
extern void DBA_GetObjectEnumBySqlName(const char *sqlName,OBJECT_ENUM *object);
extern RET_CODE DBA_LoadUserDataProfInfo();    /* 3.51 REF5562 SKE 010222 */
extern RET_CODE DBA_GetAllFK(OBJECT_ENUM, OBJECT_ENUM, FLAG_T, int **, int *); /* REF7560 - DDV - 020606 */

/*  DEV5502 - CSA - 05022001    */
extern RET_CODE DICT_GetLabel(DICT_T, DICT_T, DICT_T, const char **, DbiConnectionHelper &);
extern RET_CODE DICT_GetUniLabel(DICT_T, DICT_T, DICT_T, const UChar **, DbiConnectionHelper &); /* REF9303 - LJE - 030911 */

/* FPL-REF7420-020729 */  /* REF9789 - LJE - 031231 : Move here */
extern FLAG_T  DBA_CheckLogicalAttribEditMask(OBJECT_ENUM , OBJECT_ENUM , ENUM_T );


/* REF9789 - LJE - 031231 */
extern RET_CODE DICT_CreateVirtualEntity(OBJECT_ENUM*, const NAME_T, const SYSNAME_T, const SYSNAME_T, DBA_DYNFLD_STP, bool = false, DbiConnection* = nullptr, bool = false), /* PMSTA-13109 - LJE - 111117 */ /* PMSTA-18593 - LJE - 160122 *//* DLA - PMSTA-28997 - 171102 */
                DICT_AllocateVirtualEntity (int), /* REF11818 - LJE - 060524 */
                DICT_AddFieldToVirtualEntity(OBJECT_ENUM, FIELD_IDX_T*, const NAME_T, const SYSNAME_T, DATATYPE_ENUM, DICT_T, FLAG_T, FLAG_T, DICT_ATTRIB_STP, DBA_DYNFLD_STP, DICT_T newAttribDictId = 0),    /*  FPL-08113-PMSTA07398 add DBA_DYNFLD_STP parameter   */   /*  FPL-PMSTA08801-091119 OBJECT_ENUM to DICT_T */
                DICT_GetSrcEntityDictId(DBA_DYNFLD_STP, DICT_T *),
                DICT_ConvertEntity(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNFLD_STP, OBJECT_ENUM, bool),
                DICT_GetVirtualEntity (OBJECT_ENUM*,ID_T,DBA_DYNST_ENUM),
                DICT_GetLinkedVirtualAttribute(OBJECT_ENUM,ID_T,int,DICT_ATTRIB_STP*);

extern void     DBA_UpdDictCriteria(OBJECT_ENUM objectEn, bool bLightLoad); /* PMSTA-13109 - LJE - 111116 */
extern void     DBA_UpdCrossLinkAttr(OBJECT_ENUM objectEn = NullEntity);    /* PMSTA-18593 - LJE - 151221 */
extern RET_CODE DBA_GenerateAllAttrib(OBJECT_ENUM objectEn = NullEntity);   /* PMSTA-28698 - LJE - 180516 */
extern DICT_ATTRIB_STP DBA_GetLinkAttribStp(DICT_ATTRIB_STP refAttribStp);  /* PMSTA-18593 - LJE - 151221 */


extern RET_CODE DBA_EnumAdd(DICT_ATTRIB_STP, double, double, double*, double*);     /*  FPL-REF10174-050304 */
extern FIELD_IDX_T  DICT_ConvertProgN(DBA_DYNST_ENUM, DBA_DYNST_ENUM, FIELD_IDX_T); /* FPL-REF10103-040402 */

extern int		DICT_GetVirtualProgN(OBJECT_ENUM, OBJECT_ENUM, FIELD_IDX_T); /* REF9764 - CHU/LJE - 040115 */

extern void     DICT_FreeVirtualEntity(OBJECT_ENUM);
extern void     DICT_ActivateVirtualAttributes(OBJECT_ENUM);                        /*  DDV-PMSTA6772-080619    */


extern RET_CODE DBA_GetDictFctTab(std::vector<DICT_FCT_ST>*&);                       /* PMSTA-nuodb - LJE - 190507 */

extern int           DBA_CmpAttribTab(const void *, const void *);
extern DATATYPE_ENUM DICT_GetAttribDataType(OBJECT_ENUM entityRef, int fieldPos);

/*  Permited Values table management : move from structute to class */                          /*  HFI-PMSTA-49174-220513  */
extern RET_CODE DBA_CopyPermValTab (PERMITED_VALUES_STP *, int *, PERMITED_VALUES_STP, int);
extern RET_CODE DBA_ExtOrRedPermValTab (PERMITED_VALUES_STP *, int *, int, int);
extern RET_CODE DBA_ShiftOnePermValTab (PERMITED_VALUES_STP *, int , int , int);

extern int DBA_GetPckRightsFromEnvVar (void);

/************************************************************************
**      BEGIN External definitions attached to : dbadictlib.c
*************************************************************************/
extern DICT_ENTITY_ST &DICT_AddNewDictEntity(DICT_T entDictId, OBJECT_ENUM objectEn, const std::string &sqlName, const std::string &dbSqlName, bool bSourceEnv = false); /* PMSTA-26108 - LJE - 170919 */
extern std::vector<DICT_ENTITY_STP> &DICT_GetDictEntityVector();
extern std::string DBA_GetAttribEquivDataType(DATATYPE_ENUM dataTpProgN, DBA_RDBMS_ENUM rdbmsEn, unsigned int maxDbLenN=0);  /* PMSTA-38801 - JJN - 200202 */
extern char*         DBA_GetDataTypeEquivType(DATATYPE_ENUM, DBA_RDBMS_ENUM);             /* PMSTA-11505 - LJE - 110322 */ /* PMSTA-nuodb - LJE - 190603 */
extern DATATYPE_ENUM DBA_GetDatatypeEnumByCode(const char *);
extern DATATYPE_ENUM DBA_GetDatatypeEnumByEquivType(const char *);
extern DATATYPE_ENUM DBA_GetDataTypeFromEquivType(DBA_RDBMS_ENUM rdbmsVendor, const std::string &nativType, int precision, int scale); /* PMSTA-23226 - LJE - 160526 */
extern size_t       DBA_GetDataTypeAlignSize(DATATYPE_ENUM dataType, size_t nameLen, size_t maxLen, bool bGeneric, char *szAlignPos); /* PMSTA-23226 - LJE - 160526 */

extern const char     *DBA_GetDictEntityLabel(OBJECT_ENUM, FLAG_T);
extern int             DBA_GetDictFctRows();
extern DICT_FCT_STP    DBA_GetDictFctStp(int);
extern DICT_DATATP_STP DBA_GetDictDataTpStp(int);

extern RET_CODE        DBA_ManageDictEntityConstr(OBJECT_ENUM); /* PMSTA-26108 - LJE - 170916 */

extern void            DBA_MoveDictEntityToSource();

/************************************************************************
**      BEGIN External definitions attached to : dbaloaddict.c
*************************************************************************/

/************************************************************************
**      BEGIN External definitions attached to : dbadict2.c
*************************************************************************/

extern RET_CODE  DICT_ExportRecord(CONTEXT_ENTITY_STP,
                                   DBA_DYNFLD_STP,
                                   const char*,
                                   char **,
                                   EVAL_DATA_ENTITY_STP*,
                                   DEF_DATA_ENTITY_STP*,
                                   int *,
                                   FLAG_T,
                                   EVAL_DATA_TYPE_ENUM);
extern RET_CODE  DICT_ImportRecord(const char *,
                                   const char *,
                                   DBA_DYNFLD_STP *,
                                   EVAL_DATA_TYPE_ENUM,
                                   EVAL_DATA_ENTITY_STP*,
                                   DEF_DATA_ENTITY_STP*,
                                   int *);

extern RET_CODE  DICT_FreeEvalDataEntity(EVAL_DATA_ENTITY_STP*);
extern RET_CODE  DICT_FreeDefDataEntity(DEF_DATA_ENTITY_STP*);

extern RET_CODE  DICT_GetScptFlgFromEvalDataEntity(EVAL_DATA_ENTITY_STP, FLAG_T**);
extern RET_CODE  DICT_FillFkEvalDataEntityFromFilter(EVAL_DATA_ENTITY_STP, PTR);
extern RET_CODE  DICT_BuildDefStringFromEvalDataEntity(EVAL_DATA_ENTITY_STP, const char *, char **);
extern RET_CODE  DICT_GetAllMessageFromEvalDataEntity(EVAL_DATA_ENTITY_STP, int*, DBA_DYNFLD_STP**);
extern RET_CODE  DICT_CreateOutputMsgFromEvalDataFld(EVAL_DATA_FLD_STP, MSGNAT_ENUM, SMALLINT_T, const char*);
extern const char* DICT_GetFieldFormat (DATATYPE_ENUM);

/************************************************************************
**      BEGIN External definitions attached to : dictfile.c
*************************************************************************/

extern RET_CODE DBA_MDLoadFile(char *,unsigned char **),
                DBA_MDCheckDate(unsigned char *),
                DBA_MDReadSize(unsigned char *, int *, int *, int *,
                   int *, int *, int *),
                DBA_MDReadBlock(unsigned char *,
                DICT_LANG_STP,
                DICT_DATATP_STP),
                DBA_MDOpenWriteFile(char *, FILEDES*),
                DBA_MDWriteFile(DICT_LANG_STP, DICT_DATATP_STP,
                                int, int, FILEDES),
                DBA_GetMDFileName(char *);

extern void DBA_MDCloseWriteFile(char*, FILEDES);
#endif					/* ifndef DICT_H */
/************************************************************************
**      END        dict.h                                     UNICIBLE
*************************************************************************/

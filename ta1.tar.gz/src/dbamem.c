/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAMEM_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define MEMORY_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "msg.h"
#include "sig.h"
#include "fmtlib01.h"
#include "serv.h"
#include "syslib.h"         /* PMO - Rename our sys.h to syslib.h and use it */
#include "date.h"
#include "scptyl.h"
#include "tls.h"
#include "eservice.h"
#include "conprovider.h"
#include "conexcept.h"
#include "conlocprovider.h"
#include "password.h"
#include "dbiconnection.h"

#include "dbacurr.hpp"
#include "icu4aaadate.h"
#include "gui.h"
#include "guigen.h"

#include "dbabusec.h"  /* PMSTA-45362 - SRIDHARA - 110621 */

/******************************************************************************
**      External entry points
**
**  DBA_GetMemory()          Get information in specified optimisation array
**  DBA_FreeOpti()           Free allocated memory for optimised data
**  DBA_InitOptiPtr()        Initialize EV_OptiPtr on table SV_OptiTab
**  DBA_InitConnectNoToHier  Initialize thread connexion number in hier ptr
**  DBA_ReadOpti()           Search in memory element which match to input arg
**  DBA_SetMemory()          Set information in specified array optimisation
**  DBA_UpdOptiTab()         Set to NULL opti which use modified object
**  DBA_WriteOpti()          Write in array new element
**  DBA_LoadingTabInMemory() Stock in memory database tables
**  DBA_FlushOptimisation()  Flush global optimisation buffers
**  DBA_CopyDynByHierarchy   DBA_Copy call from given hierarchy.
**  DBA_GetShDynByHierarchy  DBA_Get call from given hierarchy.
**  DBA_IsEntityWatched()    Given the entity, verify if the table is watched.
**  DBA_IsEntityUpdated()    Check if the given entity has been updated.
**
*******************************************************************************/
extern int EV_AAAInstallLevel;
extern FLAG_T   SV_IsSubdApplFlg;   /* PMSTA-22549 - CHU - 160606 */
extern bool EV_isOnline;                /* PMSTA-30522 - DLA - 180320 */

static FLAG_T *  EV_IsSubdApplFlg = &SV_IsSubdApplFlg;  /* PMSTA-22549 - CHU - 160606 */

extern CODE_T  EV_DbTimeZoneCd;

/******************************************************************************
**      Local functions
**
**  DBA_InitOptiArgInfo() Init default information on optimisation
**  DBA_UpdDfltDispFlg()  Update default display flag for entities with codif
**  DBA_AddOptiPurgeTime()   Add a DateTime entry in purge statistics
**  DBA_VerifDictEntityModif() Check whether dict_entity table was modified since previous call of DBA_VerifOptiTab
**
*******************************************************************************/

/******************************************************************************
**      Static definitions & data
*******************************************************************************/

#ifdef NTWIN
#include <crtdbg.h>
#endif

#define Opti_AccessNbr         0         /* field in structure stored in memory */
#define Opti_TimeStamp         1         /* field in structure stored in memory */
#define Opti_MainDlmEMax       2         /* Main dlm_e maximum stored in memory */
#define Opti_AddDlmEMax        4         /* Add. dlm_e maximum stored in memory */
#define Opti_DataProfileId     5         /* data_profile stored in memory. It allow storage of secure data in global cache. */
#define Opti_BusinessEntityId  6         /* business entity stored in memory. It allow using same cache for several business entities. */
#define Opti_FirstIn           7         /* Offset for the first intput field  */

#define ACCESSNBMAX 0xFFFFFFFF   /* DDV - 990226 - unsigned long maximum number
used to be sure that counter is not set to 0 when adding 1 */

static DBA_DYNFLD_STP   SV_OldApplUserRecord = nullptr; /* dynamic structure A_ApplUser */

TIMER_ST EV_GuiCheckOptiTimer;

unsigned int EV_SucLocSeek = 0;
unsigned int EV_SucGloSeek = 0;
unsigned int EV_UnsucLocSeek = 0;
unsigned int EV_UnsucGloSeek = 0;
unsigned int EV_LocWrite = 0;
unsigned int EV_GloWrite = 0;

#define DEF_GUICHK_DELTA 15
unsigned    int     EV_GuiCheckOptiDelta = DEF_GUICHK_DELTA;

GUI_OPTI_STATUS_ENUM        EV_GuiCheckOptiStatus = NextNoCheck_GuiOptiStatus;

int        connfailed[256];

#define SRVYIELD_MAX_DELAY 0.1
#define SRVYIELD_MIN_DELAY 0.002

static DBA_DYNFLD_STP	SV_ServConnectRecord = nullptr; /* REF11767 - CHU - 060404 */

SYSNAME_T * SV_EntityTab = nullptr;   /* DLA - REF8880 - 031024 */
int         SV_EntityTabNb = 0; /* DLA - REF8880 - 031024 */

static DBA_DYNFLD_STP *SV_CodifInfo;
static int            SV_CodifNbr;
static EXITREASON_ENUM  SV_ExitReason; /* PMSTA-23726 - DDV - 160624 */

DBA_DYNFLD_STP       SV_DbTimezoneStp = nullptr;  /* PMSTA-37919 - Kramadevi - 29012020 */

/******************************************************************************
**      ARRAY USED FOR DATA OPTIMISATION
*******************************************************************************/

/* Object list for optimisation */
static OBJECT_ENUM *SV_OptiObj_A_BalPosTp[] = { &BalPosTp, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Curr_ById[] = { &Curr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Curr_ByCid[] = { &Curr, &Synon, &Codif, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Codif[] = { &Codif, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Depo_ById[] = { &Depo, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_ExchRate_Best[] = { &ExchRate, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Grid[] = { &Grid, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Geo_ById[] = { &Geo, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_IncEvt_ByIIdDt[] = { &IncEvt, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Instr[] = { &Instr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Instr_Codif_Synon[] = { &Instr, &Codif, &Synon, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_InstrChrono_ByIdDt[] = { &InstrChrono, &InstrPrice, &IssueEvt, &Rating, &RatingAttr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_InstrPrice_BestById[] = { &InstrPrice, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_MktSegt[] = { &MktSegt, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_MktSegt_List_Grid_Classif[] = { &MktSegt, &List, &ListBuildHistory, &Grid, &Classif, &NullEntity }; /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_S_MktSegt_Grid[] = { &MktSegt, &Grid, &NullEntity };		/* REF11767 - CHU - 060328 */
static OBJECT_ENUM *SV_OptiObj_A_MktSegt_Grid[] = { &MktSegt, &Grid, &NullEntity };		/* PMSTA-11309 - LJE - 110128 */
static OBJECT_ENUM *SV_OptiObj_MktSegt_Grid2[] = { &MktSegt, &Grid, &NullEntity };		/* REF11767 - CHU - 060328 */
static OBJECT_ENUM *SV_OptiObj_MktSegt_MkStruct[] = { &MktSegt, &MktStruct, &NullEntity };	/* REF11767 - CHU - 060328 */
static OBJECT_ENUM *SV_OptiObj_A_Ptf_ById[] = { &Ptf, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Ptf_Codif_Synon[] = { &Ptf, &Codif, &Synon, &AccPer, &NullEntity };    /* REF2631 - 980907 - DED */
static OBJECT_ENUM *SV_OptiObj_A_Third_ById[] = { &Third, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Tp_ByCId[] = { &Tp, &Synon, &Codif, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Rating[] = { &Rating, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_RatingAttr[] = { &RatingAttr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_S_Classif_ByCd[] = { &Classif, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_List_ById[] = { &List, &ListBuildHistory, &NullEntity }; /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_Fct_Classif[] = { &Classif, &List, &ListBuildHistory, &NullEntity }; /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_UnitInter[] = { &Instr, &InstrChrono, &IncEvt, &InterCond, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_InstrFlow[] = { &Instr, &IncEvt, &IssueEvt, &TermEvt, &ExchEvt, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_ApplUser[] = { &ApplUser, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Lid_ByClid[] = { &ListBuildHistoryCompo, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_ScriptDef[] = { &ScriptDef, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_ScriptLibrary[] = { &ScriptDef, &ScriptLibrary, &NullEntity }; /* REF11296 - LJE - 060620 */
static OBJECT_ENUM *SV_OptiObj_Sect[] = { &Sect, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_SectAttr[] = { &SectAttr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Strat[] = { &Strat, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_TermEvt[] = { &TermEvt, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Regr[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_A_Stat[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_MeanCapReturn[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_RiskRatio[] = { &NullEntity }; /* REF8799 - LJE - 030129 */
static OBJECT_ENUM *SV_OptiObj_StandardPerf[] = { &NullEntity }; /* REF8799 - LJE - 030131 */
static OBJECT_ENUM *SV_OptiObj_Array[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_ClassifAPE[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_InstrInGrid[] = { &NullEntity }; /* REF11193 - LJE - 051201 */
static OBJECT_ENUM *SV_OptiObj_InterCond[] = { &InterCond, &NullEntity };                 /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_InstrCompo[] = { &InstrCompo, &NullEntity };                 /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_IssueEvt[] = { &IssueEvt, &NullEntity };                 /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_PayInstruct[] = { &PayInstruct, &Tp, &Curr, &Instr, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_ExchEvt[] = { &ExchEvt, &NullEntity };                 /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_FundWgt[] = { &FundWgt, &NullEntity };                 /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_ClassifCompo[] = { &Classif, &ClassifCompo, &NullEntity };       /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_FmtElt[] = { &ScriptDef, &Fmt, &FmtElt, &FmtProfCompo, &Denom, &NullEntity }; /* REF9529 - LJE - 031008 */
static OBJECT_ENUM *SV_OptiObj_A_Denom[] = { &Denom, &NullEntity };                       /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_A_ApplMsgTxt[] = { &ApplMsgTxt, &NullEntity };                  /* DVP256  - 961118 - PEC */
static OBJECT_ENUM *SV_OptiObj_Synon[] = { &Synon, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_GetApplParam[] = { &ApplParam, &NullEntity };                               /* SME REF7404 */
static OBJECT_ENUM *SV_OptiObj_GetMatchOp[] = { &NullEntity };                               /* DVP282  - 961127 - GRD */
static OBJECT_ENUM *SV_OptiObj_A_ValRule_ById[] = { &ValRule, &NullEntity };                     /* DVP344  - 970404 - XDI */
static OBJECT_ENUM *SV_OptiObj_A_ValRuleHist_ByIdDt[] = { &ValRuleHist, &NullEntity };                 /* DVP344  - 970404 - XDI */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ValRuleElt_ByHid[] = { &ValRuleElt, &NullEntity };                  /* DVP344  - 970404 - XDI */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ExchRate_ByCidDt[] = { &ExchRate, &NullEntity };                    /* DVP344  - 970404 - XDI */
static OBJECT_ENUM *SV_OptiObj_Sel_A_InstrPrice_By_IidDt[] = { &InstrPrice, &NullEntity };                  /* DVP344  - 970404 - XDI */
static OBJECT_ENUM *SV_OptiObj_S_ValRule_ByCd[] = { &ValRule, &NullEntity };                     /* DVP426  - 970410 - XDI */
static OBJECT_ENUM *SV_OptiObj_S_Tp_ByCId[] = { &Tp, &Synon, &NullEntity };                   /* DVP525  - 970630 - PEC */
static OBJECT_ENUM *SV_OptiObj_A_ScriptDef[] = { &ScriptDef, &DictScreen, &NullEntity };       /* DVP525  - 970630 - PEC */
static OBJECT_ENUM *SV_OptiObj_ScreenProfCompo[] = { &ScreenProfCompo, &DictScreen, &Tp, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_S_AccPeriod[] = { &AccPer, &AccPlan, &NullEntity };             /* DVP525  - 970630 - PEC */
static OBJECT_ENUM *SV_OptiObj_S_DataSecuProf[] = { &DataSecuProf, &NullEntity };                /* DVP525  - 970630 - PEC */
static OBJECT_ENUM *SV_OptiObj_Get_A_PortfolioInstrPrice_Bydt[] = { &PortfolioInstrPrice, &NullEntity }; /* PMSTA-32157 - SILPA - 180905 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_PortfolioInstrPrice_Bydt[] = { &PortfolioInstrPrice, &NullEntity }; /* PMSTA-32764 - SILPA - 181010 */
/* Only local optimization. None of the following tables
has to be watched.
StratLink, Strat, MktSegt, Grid, UserDataProf, List, ListCompo, Ptf, ApplUser.
*/

static OBJECT_ENUM *SV_OptiObj_StratLink_Fct[] = { &NullEntity };                /* DVP529  - 970701 - GRD */
static OBJECT_ENUM *SV_OptiObj_Exd_Instr_RCurrDflt[] = { &Instr, &NullEntity };  /* DVP548+ - 970805 - GRD */
static OBJECT_ENUM *SV_OptiObj_A_PortPosSet_ById[] = { &PtfPosSet, &NullEntity };  /* DVP526  - 970630 - GRD */
static OBJECT_ENUM *SV_OptiObj_Mgr[] = { &Mgr, &NullEntity };  /* DVP502  - 970612 - XCP */
static OBJECT_ENUM *SV_OptiObj_Get_A_DictLang_ById[] = { &DictLang, &NullEntity };  /* DVP566  - 970819 - GRD */
static OBJECT_ENUM* SV_OptiObj_Get_S_DictLang_ById[] = { &DictLang, &NullEntity };  /* PMSTA-46681 - LJE - 220705 */
static OBJECT_ENUM *SV_OptiObj_Get_A_ExchFormat_ByCId[] = { &ExchFmt, &NullEntity };  /* DVP567  - 970819 - GRD */
static OBJECT_ENUM *SV_OptiObj_Get_A_Calendar_ById[] = { &Calendar, &NullEntity };  /* DVP574  - 970826 - GRD */
static OBJECT_ENUM *SV_OptiObj_Sel_S_CalendarConv_ByCId[] = { &CalendarConv, &NullEntity };  /* DVP574  - 970826 - GRD */
static OBJECT_ENUM *SV_OptiObj_Sel_S_CalendarDate_ByCId[] = { &CalendarDate, &NullEntity };  /* DVP574  - 970826 - GRD */
static OBJECT_ENUM *SV_OptiObj_Sel_A_CalendarConv_ByCIdNat[] = { &CalendarConv, &NullEntity };  /* DVP574  - 970828 - GRD */
static OBJECT_ENUM *SV_OptiObj_Get_A_PtfSynth_ByDim[] = { &PtfSynth, &NullEntity };  /* REF826  - 971210 - XDI */
static OBJECT_ENUM *SV_OptiObj_Sel_A_FTRate_ByTCidDt[] = { &FTConv, &FTRateHist, &FTRate, &NullEntity };  /* REF1219 - 980202 - GRD */
static OBJECT_ENUM *SV_OptiObj_Sel_A_PortPosSet_ByPtfId[] = { &PtfPosSet, &NullEntity };  /* REF1190 - 980224 - XDI */
static OBJECT_ENUM *SV_OptiObj_Get_A_FtConvention_ById[] = { &FTConv, &NullEntity };  /* REF2363 - 980615 - GRD */
static OBJECT_ENUM *SV_OptiObj_Get_A_DictFct_ById[] = { &DictFct, &NullEntity };  /* REF2414 - 980622 - OCE */
static OBJECT_ENUM *SV_OptiObj_Get_S_List_ById[] = { &List, &ListBuildHistory, &NullEntity };  /* REF2414 - 980623 - OCE */ /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_Get_LastNotepad_ByDIdOIdDt[] = { &Notepad, &NullEntity };  /* REF2414 - 980626 - OCE */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ScriptDef_ById[] = { &ScriptDef, &NullEntity };  /* REF2414 - 980626 - OCE */
static OBJECT_ENUM *SV_OptiObj_Get_S_Calendar_ByCd[] = { &Calendar, &NullEntity };  /* REF2414 - 980629 - OCE */
static OBJECT_ENUM *SV_OptiObj_Sel_S_CalendarDat_ByNat[] = { &CalendarDate, &NullEntity };  /* REF2414 - 980629 - OCE */
static OBJECT_ENUM *SV_OptiObj_Get_A_FtConvention_ByCd[] = { &FTConv, &NullEntity };       /* REF2414 - 980629 - OCE */
static OBJECT_ENUM *SV_OptiObj_Get_A_Fund_ValElem_ByPid[] = { &FundVal, &FundValElt, &AccPlan, &NullEntity };/* REF2414 - 980629 - OCE */
static OBJECT_ENUM *SV_OptiObj_AA_DF_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &NullEntity };/* REF1055 - 981215 - RAK/AKO */
static OBJECT_ENUM *SV_OptiObj_AA_YTM_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030507 */
static OBJECT_ENUM *SV_OptiObj_AA_DURA_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030602 */
static OBJECT_ENUM *SV_OptiObj_AA_CONV_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030602 */
static OBJECT_ENUM *SV_OptiObj_AA_OPT_PRICE_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030604 */
static OBJECT_ENUM *SV_OptiObj_AA_OPT_SENS_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030610 */
static OBJECT_ENUM *SV_OptiObj_AA_OPT_IMPVOL_Keyword[] = { &Instr, &InterCond, &IncEvt, &ExchEvt, &InstrPrice, &Calendar, &IssueEvt, &InstrChrono, &NullEntity }; /* REF9082 - TEB - 030613 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ScriptDef_ByEnt[] = { &DictScreen, &ScriptDef, &DictAttr, &NullEntity };/* REF3279 - AKO - 990204 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Tp_ByCid[] = { &Tp, &Synon, &Codif, &NullEntity };       /* DDV - 990422 */
static OBJECT_ENUM *SV_OptiObj_Get_S_DictLang_ByCdCid[] = { &DictLang, &Synon, &Codif, &NullEntity }; /* DDV - 990422 */
static OBJECT_ENUM *SV_OptiObj_Sel_All_Subscription_By_Mod[] = { &Subscription, &NullEntity };           /* REF4204 - 000207 - GRD */
static OBJECT_ENUM *SV_OptiObj_AA_Zrates[] = { &InstrPrice, &Instr, &NullEntity };      /* REF4471 - RAK - 000228 */
static OBJECT_ENUM *SV_OptiObj_Sel_DictPanel_BySid[] = { &ScriptDef, &ApplUser, &Denom, &DictPanel, &DictAttr, &NullEntity }; /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Sel_InstrCompo_ByPIdDt[] = { &InstrCompo, &NullEntity };             /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Get_IdList_ByOIdDt[] = { &List, &ListBuildHistory, &ListBuildHistoryCompo, &NullEntity };        /* REF3916 - DDV - 000414 */ /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_Get_ListCompo_ById[] = { &NullEntity };                           /* REF11193 - LJE - 051201 */
static OBJECT_ENUM *SV_OptiObj_Get_IdListHist_ByLId[] = { &List, &ListBuildHistory, &ListBuildHistoryCompo, &NullEntity };        /* REF3916 - DDV - 000414 */ /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_Get_A_FuncSecuProf_ById[] = { &FctSecuProf, &NullEntity };            /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Calendar_ByCd[] = { &Calendar, &NullEntity };               /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Get_A_EventSched[] = { &EventSched, &NullEntity };             /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Get_ExdInstr_OptExo[] = { &Instr, &NullEntity };                  /* REF3916 - DDV - 000414 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Report_ById[] = { &Report, &NullEntity };                 /* REF3916 - RAK - 000510 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_List_ByDidNat[] = { &List, &ListBuildHistory, &/*UserDataProf, REF6180 - DDV - 010717 */ NullEntity };     /* DDV - REF4846 - 000524 */ /* DDV - 171204 - List depend of list_build_history as last_contruction_d is store in list_build_history table */
static OBJECT_ENUM *SV_OptiObj_Get_S_Geo_ByCid[] = { &Codif, &Synon, &Geo, &NullEntity };      /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Mgr_ByCid[] = { &Codif, &Synon, &Mgr, &NullEntity };      /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Mgr_ByCdCid[] = { &Codif, &Synon, &Mgr, &NullEntity };      /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Get_S_ApplRule_ByCd[] = { &ApplRule, &NullEntity };               /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Third_ByCid[] = { &Codif, &Synon, &Third, &NullEntity };    /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Get_A_ApplRule_ById[] = { &ApplRule, &NullEntity };               /* DDV - REF4846 - 000524 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_SubsCodifCompo_BySid[] = { &Subscription, &SubscriptionCodifCompo, &NullEntity }; /* REF4204 - 000616 - GRD */
static OBJECT_ENUM *SV_OptiObj_Get_A_Map_ById[] = { &Map, &NullEntity };                    /* REF4204 - 000620 - GRD */
static OBJECT_ENUM *SV_OptiObj_Get_A_Report_ById[] = { &Report, &NullEntity };                 /* REF4980 - 000720 - DDV */
static OBJECT_ENUM *SV_OptiObj_Get_S_Third_ByCdCid[] = { &Codif, &Synon, &Third, &NullEntity };    /* SME - REF5298 - 001011 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Domain_ById[] = { &Domain, &NullEntity };      /* MDE - REF5443 - 001122 */
static OBJECT_ENUM *SV_OptiObj_DynamicSql[] = { &NullEntity };                              /* REF5506 - 010122 - SME */
static OBJECT_ENUM *SV_OptiObj_SEL_EXTPOS[] = { &NullEntity };                              /* REF11524 - LJE - 051208 */
static OBJECT_ENUM *SV_OptiObj_GetExtOp[] = { &NullEntity };                              /* REF11524 - LJE - 051208 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_StratElt_ByHid[] = { &StratElt, &Instr, &StratHist, &Synon, &NullEntity }; /* REF5358 - 010328 - DDV - Actaully StratElt and StratHist not watched => only local Opti */
static OBJECT_ENUM *SV_OptiObj_Get_S_Strat_ByCd[] = { &Strat, /*UserDataProf, REF6180 - DDV - 010717 */ &Grid, &MktSegt, &NullEntity }; /* REF5358 - 010328 - DDV */
static OBJECT_ENUM *SV_OptiObj_Sel_A_MktStruct_ByRefGrid[] = { &MktStruct, &NullEntity }; /* REF7395 - YST - 021104 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_Subscription_ByMod[] = { &Subscription, &NullEntity }; /* DLA - REF8880 - 030313 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Fmt_ById[] = { &Fmt, &NullEntity };                                  /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_A_MktStruct_ById[] = { &MktStruct, &NullEntity };                            /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_A_PSPPositionData_ById[] = { &PSPPositionData, &NullEntity };                      /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_S_DataSecuProf_ByCd[] = { &DataSecuProf, &NullEntity };                         /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_A_DataSecuProf_ById[] = { &DataSecuProf, &NullEntity };                         /* PMSTA-9742 - PCL - 100429 */
static OBJECT_ENUM *SV_OptiObj_Get_S_DictEntity_ByDid[] = { &DictEntity, &NullEntity };                           /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_S_DictFct_ByDid[] = { &DictFct, &NullEntity };                              /* REF9342 - DDV - 031021 */
static OBJECT_ENUM* SV_OptiObj_Get_S_DictFct_ByNm[] = { &DictFct, &NullEntity };                               /* PMSTA-46681 - LJE - 230912 */
static OBJECT_ENUM* SV_OptiObj_Get_S_DictFct_ByPnm[] = { &DictFct, &NullEntity };                              /* PMSTA-46681 - LJE - 230912 */
static OBJECT_ENUM* SV_OptiObj_Get_S_DictAttr_ByBk[] = { &DictAttr, &NullEntity };                             /* PMSTA-46681 - LJE - 230912 */
static OBJECT_ENUM *SV_OptiObj_Get_S_DictLang_ByCid[] = { &DictLang, &Synon, &Codif, &NullEntity };          /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Fmt_ByCd[] = { &Fmt, &ApplUser, &DictLabel, &DictFct, &NullEntity }; /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_Fmt_ByTslPrecJobCd[] = { &TslPrecJob, &TslPrecJobElement, &TslPrecJobElementCompo, &NullEntity };   /* PMSTA-37366 - LJE - 200309 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_InstrChrono_ByDtNat[] = { &InstrChrono, &NullEntity };                         /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_StratHist_BySidDt[] = { &Strat, &StratHist, &NullEntity };                    /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Get_A_StratHist_BySidDt[] = { &Strat, &StratHist, &NullEntity };                    /* PMSTA07963 - LJE - 090618 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_PerfAnalysisParam[] = { &PerfAnalysisParam, &NullEntity };                    /* REF9342 - DDV - 031021 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_MktSSubSet_ByRefG[] = { &MktSSubSet, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Get_A_Operation_ById[] = { &NullEntity };										/* REF11194 - RAK - 060515 - only local optimisation */
static OBJECT_ENUM *SV_OptiObj_SelExtOp[] = { &NullEntity };										/* REF11589 - DDV - 060622 - only local optimisation */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ComplChronoByIdDim[] = { &NullEntity };										/* only local optimisation */ /* PMSTA06646 - LJE - 080613 */
static OBJECT_ENUM *SV_Opti_Get_A_TascJob_ByJref[] = { &NullEntity };										/* only local optimisation */ /* PMSTA08246 - LJE - 090616 */
static OBJECT_ENUM *SV_OptiObj_DataProfCompo_ByBk[] = { &DataProfCompo, &NullEntity };	                    /* PMSTA09740 - DDV - 100531 - New optimisation */
static OBJECT_ENUM *SV_OptiObj_GetExtOpById[] = { &NullEntity };                                        /* PMSTA10383 - DDV - 100810 - New local optimisation get_all_ext_operation_by_id */
static OBJECT_ENUM *SV_OptiObj_ScriptDef_Action[] = { &ScriptDef, &NullEntity };                            /* FPL-PMSTA10714-110202    */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ScriptDef_ByObjNat[] = { &ScriptDef, &NullEntity };	                        /* PMSTA-15655 - LJE - 130128 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_SearchProfCompo_BySPFE[] = { &SearchProfCompo, &SearchProf, &SearchCrit, &NullEntity };	/* PMSTA-15655 - LJE - 130128 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_SearchCritCompo_BySCId[] = { &SearchCritCompo, &Tp, &NullEntity };	            /* PMSTA-15655 - LJE - 130128 */
static OBJECT_ENUM *SV_OptiObj_Get_A_StratElt_ById[] = { &StratElt, &NullEntity };                             /* PMSTA15739 - DDV - 130227 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Ptf_ByCdCId[] = { &Ptf, &NullEntity };                                  /* PMSTA15739 - DDV - 130227 */
static OBJECT_ENUM *SV_OptiObj_Get_S_SearchProf_ById[] = { &SearchProf, &NullEntity };                           /* PMSTA15739 - DDV - 130227 */
static OBJECT_ENUM *SV_OptiObj_Get_S_BusEntity_ByCid[] = { &BusEntity, &NullEntity };                            /* PMSTA17593 - DDV - 140212 */
static OBJECT_ENUM *SV_OptiObj_Get_S_Portfolio_ByUid[] = { &Ptf, &NullEntity };									/* PMSTA-17978 - SHR - 140508*/
static OBJECT_ENUM *SV_OptiObj_Get_New_InstrRiskOrig_ByBk[] = { &NullEntity };                                        /* PMSTA-18096 - LJE - 140623 */
static OBJECT_ENUM *SV_OptiObj_Codif_ById[] = { &Codif, &NullEntity };                                 /*  HFI-PMSTA-18889-141028  */
static OBJECT_ENUM *SV_OptiObj_DictEntity_BySn[] = { &DictEntity, &NullEntity };                            /*  HFI-PMSTA-18889-141028  */
static OBJECT_ENUM *SV_OptiObj_A_DictDatatype_ByDid[] = { &DictDataTp, &NullEntity };                           /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM* SV_OptiObj_S_DictDatatype_ByDid[] = { &DictDataTp, &NullEntity };                           /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM *SV_OptiObj_S_DictDatatype_BySn[] = { &DictDataTp, &NullEntity };                           /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM *SV_OptiObj_S_RiskRule_ByBk[] = { &RiskRule, &NullEntity };                             /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM* SV_OptiObj_A_RiskRuleCompo_ByBk[] = { &RiskRuleCompo, &NullEntity };                        /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM* SV_OptiObj_A_RiskRuleCompo_ByPk[] = { &RiskRuleCompo, &NullEntity };                        /* PMSTA-50865 - FME - 2022-10-20 */
static OBJECT_ENUM *SV_OptiObj_A_RiskValueElt_BestByEntObj[] = { &RiskValueElt, &NullEntity };                         /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM *SV_OptiObj_A_StratElt_RiskByCcShid[] = { &StratHist, &StratElt, &NullEntity };                 /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM *SV_OptiObj_A_RiskValueEltCompo_ByBk[] = { &RiskValueEltCompo, &NullEntity };                    /* PMSTA-18426 - DDV - 141126 */
static OBJECT_ENUM *SV_OptiObj_Get_A_CompChrono_Objective[] = { &ComplianceChrono, &NullEntity };						/* PMSTA-19235 - SHR - 150108 */
static OBJECT_ENUM *SV_OptiObj_Get_APAOptimLevel[] = { &ScriptDef, &NullEntity };                              /* PMSTA-19118 - LJE - 0141201 */
static OBJECT_ENUM *SV_OptiObj_Sel_E_DictFct_ByUid[] = { &ApplUser, &DictLabel, &DictFct, &FctSecuProfCompo, &NullEntity };										/* PMSTA-17794 - SHR - 150304 */
static OBJECT_ENUM *SV_OptiObj_Get_A_PtfChronoByIdDim[] = { &PtfChrono, &NullEntity };							/* PMSTA-21111 - DDV - 050909 */
static OBJECT_ENUM *SV_OptiObj_Get_A_ThirdChronoByIdDim[] = { &ThirdChrono, &NullEntity };							/* PMSTA-21111 - DDV - 050909 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ScriptDef_AddByAttr[] = { &ScriptDef, &NullEntity };                            /* PMSTA-21147 - DDV - 151120 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_ScriptDef_AddFilter[] = { &ScriptDef, &NullEntity };                            /* PMSTA-21147 - DDV - 151120 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Addr_ByTid[] = { &Addr, &NullEntity };                                   /* PMSTA-22956 - DDV - 160623 - New optimisation */
static OBJECT_ENUM *SV_OptiObj_Get_A_XdEntity_ById[] = { &XdEntity, &NullEntity };                                  /* PMSTA-25371 - LJE - 161227 */
static OBJECT_ENUM *SV_OptiObj_Get_A_XdEntity_BySqlName[] = { &XdEntity, &NullEntity };                             /* PMSTA-25371 - LJE - 161227 */
static OBJECT_ENUM *SV_OptiObj_Get_S_XdEntity_BySqlName[] = { &XdEntity, &NullEntity };                             /* PMSTA-25371 - LJE - 161227 */
static OBJECT_ENUM *SV_OptiObj_Get_A_BusEntity_ByPk[] = { &BusEntity, &NullEntity };                                /* PMSTA-26003 - 170125 - DDV */
static OBJECT_ENUM *SV_OptiObj_Sel_Valid_A_ChangeSet[] = { &ChangeSet, &NullEntity };                               /* PMSTA-26250 - DDV - 170516 */
static OBJECT_ENUM *SV_OptiObj_Sel_EntityByFeatureAuth[] = { &XdEntity, &NullEntity };                              /* PMSTA-26250 - DDV - 170601 */
static OBJECT_ENUM *SV_OptiObj_Get_A_DataDependency_ByPk[] = { &DataDependency, &NullEntity };                      /* PMSTA-29808 - DDV - 180226 */
static OBJECT_ENUM *SV_OptiObj_Sel_DictDepends[] = { &NullEntity };                                                 /* PMSTA-28698 - LJE - 180706 */
static OBJECT_ENUM *SV_OptiObj_Get_A_EService_ByBk[] = { &ExtService,  &NullEntity };                               /*  HFI-PMSTA-35960-190604  */
static OBJECT_ENUM *SV_OptiObj_Get_A_ExtOp_ById[] = { &EOp,  &NullEntity };                                         /*  HFI-PMSTA-36664-190723  */
static OBJECT_ENUM *SV_OptiObj_Get_A_ModelConstrElt_ById[] = { &ModelConstrElt,  &NullEntity };                     /*  HFI-PMSTA-36664-190723  */
static OBJECT_ENUM *SV_OptiObj_Sel_A_CaseLink_ByPId[] = { &CaseLink,  &NullEntity };                                /*  HFI-PMSTA-36664-190723  */
static OBJECT_ENUM *SV_OptiObj_Get_A_ApplUserPreference_eff[] = { &ApplUserPreference,  &NullEntity };              /*  PMSTA-37919 - Kramadevi - 29012020 */
static OBJECT_ENUM *SV_OptiObj_Get_A_Subscription_ByCd[] = { &Subscription, &NullEntity };                          /*  PMSTA-37919 - Kramadevi - 29012020 */
static OBJECT_ENUM *SV_OptiObj_Sel_A_DocIndexParam_ByBk[] = { &DocIndexParam, &NullEntity };                        /*  HFI-PMSTA-36415-210323  */
static OBJECT_ENUM *SV_OptiObj_Sel_A_PerfTimingRule[] = { &PerfTimingRule,  &NullEntity };                                /*  PMSTA-47582 - JBC - 220318 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_Pos_ByPidIidDt[] = { &Pos, &NullEntity };                                      /* PMSTA-47748 - JBC - 210120 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_Pos_ByPidDt[] = { &Pos, &NullEntity };                                         /* PMSTA-47748 - JBC - 210120 */
static OBJECT_ENUM *SV_OptiObj_Sel_S_SrvRunningPoolCompo_ByNm[] = { &ServRunning, &ServConnect, &ServPool, &NullEntity }; /* PMSTA-39659 - ankita - 05082020 */
static OBJECT_ENUM *SV_OptiObj_GetLockInfo_ByPidIidDt[] = { &ModelConstrElt , &NullEntity };                        /* PMSTA-45670 - AIS - 220908 */
static OBJECT_ENUM *SV_OptiObj_SqlBiObjective[] = { &BiObjectiveElt, &BiThresholdElt, &InstrBiValue, &PortBiValue, &ThirdBiValue, &StratBiValue, &NullEntity }; /* PMSTA-50418 - DDV - 220913 */
static OBJECT_ENUM *SV_Opti_A_BusIndicatorElt_ByBk[] = { &BusIndicatorElt, &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM *SV_Opti_A_InstrBiValue_ByDt[]    = { &InstrBiValue,    &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM *SV_Opti_A_PortBiValue_ByDt[]     = { &PortBiValue,     &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM *SV_Opti_A_StratBiValue_ByDt[]    = { &StratBiValue,    &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM *SV_Opti_A_ThirdBiValue_ByDt[]    = { &ThirdBiValue,    &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM* SV_Opti_S_BusIndicator_ByBk[] = { &BusIndicator,    &NullEntity }; /* PMSTA-50418 - DDV - 220928 */
static OBJECT_ENUM *SV_OptiObj_Get_All_Dict_Database_ByPk[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Get_All_Dict_Segment_ByBk[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Sel_All_XdIndex_ByPid[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Sel_All_XdIndexAttrib_ByPid[] = { &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Sel_All_Format_Elem_ForTsl[] = { &FmtElt, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Sel_Sh_Tsl_Prec_job_Elt_Compo[] = { &TslPrecJob, &TslPrecJobElement, &TslPrecJobElementCompo, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Get_A_CaseTemplDef_ByBk[] = { &CaseMsgTemplateDef, &NullEntity }; /* PMSTA-38367 - MSS - 191219*/
static OBJECT_ENUM *SV_OptiObj_Get_S_Depo_ByCdCid[] = { &Depo, &NullEntity }; /* PMSTA-38367 - MSS - 191219*/
static OBJECT_ENUM *SV_OptiObj_Sel_Ptf_Id_ByLid[] = { &Ptf, &NullEntity };
static OBJECT_ENUM *SV_OptiObj_Get_BusEntitybycd_cid[] = { &BusEntity, &NullEntity };                               /* PMSTA-51053 - AAKASH - 13072023 */
static OBJECT_ENUM* SV_OptiObj_Get_S_QuestHisto_By_Pk[] = { &QuestHisto, &NullEntity };                             /* PMSTA-51053 - AAKASH - 13072023 */
static OBJECT_ENUM* SV_OptiObj_Get_A_PackageEntity_By_Pk[] = { &PackageEntity, &NullEntity };                       /*  HFI-PMSTA-54142-2023-08-10  */
static OBJECT_ENUM* SV_OptiObj_Opti_Sel_All_PerfCalcDefProfCompo_ByPId[] = { &PerfCalcDefProfileCompo, &NullEntity };        /* PMSTA-54529 - DDV - 231009 */
static OBJECT_ENUM* SV_OptiObj_Opti_Get_S_AnswerPermValDef_ByQidPval[] = { &AnswerPermValDef, &NullEntity };        /*  HFI-PMSTA-55441-2024-01-26  */
static OBJECT_ENUM* SV_OptiObj_Opti_Sel_Sh_QuestEltDef_ById[] = { &QuestEltDef, &NullEntity };                      /*  HFI-PMSTA-55441-2024-01-26  */
static OBJECT_ENUM* SV_OptiObj_Chk_Ptf_Hier_By_Id[] = { &Ptf, &NullEntity };                                        /* PMSTA-48867-Satya */
static OBJECT_ENUM* SV_OptiObj_Get_Ptf_InceptDt[] = { &Ptf, &PerfComputationPeriod, &PortLinkHistory, &NullEntity };                                            /* WEALTH-6158 - JBC - 20240330 */
static OBJECT_ENUM* SV_OptiObj_Get_Third_InceptDt[] = { &Ptf, &PerfComputationPeriod, &PortLinkHistory, &PtfThirdCompo, &NullEntity };                          /* WEALTH-6158 - JBC - 20240330 */
static OBJECT_ENUM* SV_OptiObj_Get_HistList_InceptDt[] = { &Ptf, &PerfComputationPeriod, &PortLinkHistory, &ListBuildHistory, &PtfThirdCompo, &NullEntity };    /* WEALTH-6158 - JBC - 20240330 */
static OBJECT_ENUM* SV_OptiObj_GetDomainInceptDt[] = { &Ptf, &PerfComputationPeriod, &PortLinkHistory, &NullEntity };                                              /* WEALTH-6158 - JBC - 20240330 */
static OBJECT_ENUM* SV_OptiObj_Opti_Sel_Sh_QuestEltDef_ForQuestSCore[] = { &QuestEltDef, &NullEntity };             /*  HFI-WEALTH-7558-2024-05-03  */
static OBJECT_ENUM* SV_OptiObj_Get_S_FtConvention_ByCd[] = { &FTConv, &NullEntity };                                /* PMSTA-56959 - SSA - 20240828*/
static OBJECT_ENUM* SV_OptiObj_A_RiskValueEltCompo_ByPk[] = { &RiskValueEltCompo, &NullEntity };                    /*PMSTA-64803- VPR - 20250202 */
static OBJECT_ENUM *SV_OptiObj_A_ConstrTemplateById[] = { &ConstrTemplate, &NullEntity };                           /*  SRS-PMSTA-59290-2024-09-12  */

/*----------------------------------------------------------------------*/
/* dataPtr         NULL, init by DBA_WriteOpti()                        */
/* inputArgNbr     0, init by InitOptiArgInfo()                         */
/* outputFldNbr    0, init by InitOptiArgInfo()                         */
/* strArgFlg       FALSE, init by InitOptiArgInfo()                     */
/* currentReadNbr  current read access number, update by DBA_ReadOpti() */
/* eltNbr          0, update by DBA_WriteOpti()                         */
/* allocNbr        0, allocated size update by DBA_WriteOpti()          */
/* allocBloc       size to allocate each time bloc is full              */
/* maxAllocNbr     maximum size from optimisation array                 */
/* locAllocBloc    local allocation size use by SERV_InitDfltOptiLst()  */
/* locMaxAllocNbr  local maximum size from optimisation array use by    */
/*                 SERV_InitDfltOptiLst()                               */
/* procPtr         NULL, init by InitOptiArgInfo()                      */
/* objLstPtr       object list for optimisation                         */
/* objLst          NULL, init by InitOptiArgInfo()                      */
/* optiEnum        map to opti enum for integrity check                 */ /* PMSTA-53274 - JBC 230525 */
/* int cacheHint;                                       success number  */
/* int nbCall;                                           number of call */
/* int *index;                                         pointer on index */
/* int *free;                       pointer in a list of record to free */
/* unsigned long maxFfree;                    nb Max of record in *free */
/* unsigned long currentFree;                    current index in *free */
/*----------------------------------------------------------------------*/

static DBA_OPTI_ST SV_OptiTab[] = {
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 50, 50, 50, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_A_BalPosTp_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_A_BalPosTp_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_A_BalPosTp_ByUk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA06845 - LJE - 080625 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_S_BalPosTp_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_S_BalPosTp_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_A_Curr_ById, NULL, Opti_A_Curr_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_A_Curr_ById, NULL, Opti_A_Curr_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_A_Curr_ByCid, NULL, Opti_S_Curr_ByCdCid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 500, 50, 500, NULL, SV_OptiObj_A_Curr_ByCid, NULL, Opti_S_Curr_ByCid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_A_Depo_ById, NULL, Opti_A_Depo_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 80, 800, 40, 400, NULL, SV_OptiObj_A_ExchRate_Best, NULL, Opti_A_ExchRate_Best, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_A_Geo_ById, NULL, Opti_A_Geo_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 2000, 20, 1000, NULL, SV_OptiObj_A_IncEvt_ByIIdDt, NULL, Opti_A_IncEvt_ByIIdDt, 0, 0, NULL, NULL, 0, 0 }, /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_A_Instr, NULL, Opti_A_Instr_ById, 0, 0, NULL, NULL, 0, 0 },    /*  */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 100, 1000, NULL, SV_OptiObj_A_Instr, NULL, Opti_A_Instr_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 100, 1000, NULL, SV_OptiObj_Instr_Codif_Synon, NULL, Opti_S_Instr_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 100, 1000, NULL, SV_OptiObj_Instr_Codif_Synon, NULL, Opti_S_Instr_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 40, 80, 40, 80, NULL, SV_OptiObj_A_Instr, NULL, Opti_Exd_Instr_ByRCurr, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_A_InstrChrono_ByIdDt, NULL, Opti_A_InstrChrono_ByIdDt, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1500, NULL, SV_OptiObj_A_Ptf_ById, NULL, Opti_A_Ptf_ById, 0, 0, NULL, NULL, 0, 0 }, /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1500, NULL, SV_OptiObj_Ptf_Codif_Synon, NULL, Opti_S_Ptf_ByCdCid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1500, NULL, SV_OptiObj_Ptf_Codif_Synon, NULL, Opti_S_Ptf_ByCid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_A_Third_ById, NULL, Opti_A_Third_ById, 0, 0, NULL, NULL, 0, 0 }, /* DLA - PMSTA-12092 - increase size 110531 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_A_Tp_ByCId, NULL, Opti_A_Tp_ByCId, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_A_Tp_ByCId, NULL, Opti_A_Tp_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA15739 - DDV - 130226 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_A_Tp_ByCId, NULL, Opti_S_Tp_ByCdCid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_S_Classif_ByCd, NULL, Opti_S_Classif_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_A_List_ById, NULL, Opti_A_List_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF9264 - LJE - 031029 */ /* REF9028 - DDV - 040227 - increase size */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 10, 5, 10, NULL, SV_OptiObj_A_ApplUser, NULL, Opti_A_ApplUser_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 10, 5, 10, NULL, SV_OptiObj_A_ApplUser, NULL, Opti_A_ApplUser_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 10, 5, 10, NULL, SV_OptiObj_A_ApplUser, NULL, Opti_S_ApplUser_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 10, 5, 10, NULL, SV_OptiObj_A_ApplUser, NULL, Opti_S_ApplUser_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_Lid_ByClid, NULL, Opti_Lid_ByClid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_S_Classif_ByCd, NULL, Opti_A_Classif_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_S_Classif_ByCd, NULL, Opti_S_Classif_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Grid, NULL, Opti_A_Grid_ById, 0, 0, NULL, NULL, 0, 0 },             /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Grid, NULL, Opti_A_Grid_ByMsId, 0, 0, NULL, NULL, 0, 0 },           /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Grid, NULL, Opti_S_Grid_ByCd, 0, 0, NULL, NULL, 0, 0 },             /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_MktSegt, NULL, Opti_A_MktSeg_ById, 0, 0, NULL, NULL, 0, 0 },      /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_MktSegt, NULL, Opti_S_MktSeg_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ /* BUG345 - RAK - 970417 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 200, 100, 200, NULL, SV_OptiObj_MktSegt_List_Grid_Classif, NULL, Opti_S_MktSeg_ByLid, 0, 0, NULL, NULL, 0, 0 }, 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 200, NULL, SV_OptiObj_S_MktSegt_Grid, NULL, Opti_Sel_S_MktSeg_ByGid, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 200, NULL, SV_OptiObj_A_MktSegt_Grid, NULL, Opti_Sel_A_MktSeg_ByGid, 0, 0, NULL, NULL, 0, 0}, /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 200, NULL, SV_OptiObj_MktSegt_Grid2, NULL, Opti_Sel_MktSeg_ByGid2, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */  /* REF11767 - CHU - 060328 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 200, NULL, SV_OptiObj_MktSegt_MkStruct, NULL, Opti_Sel_MktSeg_ByMSid, 0, 0, NULL, NULL, 0, 0 },  /* DVP201 */ /* REF11767 - CHU - 060328 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Strat, NULL, Opti_A_Strategy_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 200, 100, 200, NULL, SV_OptiObj_Sect, NULL, Opti_A_Sector_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 200, 100, 200, NULL, SV_OptiObj_Rating, NULL, Opti_A_Rating_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ 
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 10000, 200, 10000, NULL, SV_OptiObj_RatingAttr, NULL, Opti_L_RatingAttrib_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */  /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 5000, 200, 5000, NULL, SV_OptiObj_SectAttr, NULL, Opti_A_SectorAttrib_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */ /* PMSTA08391 - LJE - 090720 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_TermEvt, NULL, Opti_A_TermEvent_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_A_List_ById, NULL, Opti_S_List_ByCdDid, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_Codif, NULL, Opti_A_DictEntity_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_ScriptDef, NULL, Opti_A_ScriptDef_List, 0, 0, NULL, NULL, 0, 0 }, /* DVP201 */                   /*  HFI-PMSTA-18889-141028  Change configuration    */
    /*{NULLDYNST, 0, 0, FALSE, RWOpti_A_ScriptLibDef_ByBk,     0, 0, 0,  100,  500,  100,  500, NULL, SV_OptiObj_ScriptLibrary,0,0,NULL,NULL,0,0, Opti_A_ScriptLibDef_ByBk},      FPL-PMSTA02466-100301   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1500, 100, 1500, NULL, SV_OptiObj_Codif, NULL, Opti_A_DictLabel_ByPermVal, 0, 0, NULL, NULL, 0, 0}, /* DVP201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 100, 1000, NULL, SV_OptiObj_Fct_Classif, NULL, Opti_Fct_Classif, 0, 0, NULL, NULL, 0, 0}, /* PMSTA08736 - LJE - 100129 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_UnitInter, NULL, Opti_UnitInter, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_InstrFlow, NULL, Opti_InstrFlow, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 20, 10, 20, NULL, SV_OptiObj_A_Regr, NULL, Opti_A_Regr, 0, 0, NULL, NULL, 0, 0 }, /* DVP005 960321 RAK */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 20, 10, 20, NULL, SV_OptiObj_A_Stat, NULL, Opti_A_Stat, 0, 0, NULL, NULL, 0, 0 }, /* DVP005 960321 RAK */
    /*{NULLDYNST, 0, 0, FALSE, RWOptiFct_MeanCap,              0, 0, 0,   10,   40,   10,   40, NULL, SV_OptiObj_MeanCapReturn,0,0,NULL,NULL,0,0, Opti_MeanCap},  FPL-PMSTA02466-100301   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 40, 10, 40, NULL, SV_OptiObj_MeanCapReturn, NULL, Opti_Return, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 40, 10, 40, NULL, SV_OptiObj_RiskRatio, NULL, Opti_RiskRatio, 0, 0, NULL, NULL, 0, 0 }, /* REF8799 - LJE - 030128 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 40, 10, 40, NULL, SV_OptiObj_StandardPerf, NULL, Opti_StandardPerf, 0, 0, NULL, NULL, 0, 0 }, /* REF8799 - LJE - 030131 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_Array, NULL, Opti_Array, 0, 0, NULL, NULL, 0, 0 }, /* DVP005 960321 RAK */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_ClassifAPE, NULL, Opti_ClassifAPE, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 5000, NULL, SV_OptiObj_InstrInGrid, NULL, Opti_InstrInGrid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 500, 20, 500, NULL, SV_OptiObj_GetApplParam, NULL, Opti_GetApplParam, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA13498 - DDV - 120118 - Size 40 -> 500 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_InterCond, NULL, Opti_Sel_A_InterCond_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_InterCond, NULL, Opti_Sel_A_InterCond_ByDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_InstrCompo, NULL, Opti_Sel_A_InstrCompo_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_IssueEvt, NULL, Opti_Sel_A_IssueEvt_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_PayInstruct, NULL, Opti_Sel_S_PayInstruct_ByPid, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_ExchEvt, NULL, Opti_Sel_A_ExchEvt_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_OptiObj_A_IncEvt_ByIIdDt, NULL, Opti_Sel_A_IncEvt_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_FundWgt, NULL, Opti_A_FundWgt_ByIId, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_ClassifCompo, NULL, Opti_Sel_ClassifCompo_ByCfId, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */ /* REF2414 - OCE - 062498 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_FmtElt, NULL, Opti_Sel_SumFmtElt_ByFid, 0, 0, NULL, NULL, 0, 0 }, /*  DVP256 961118 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 40, 20, 40, NULL, SV_OptiObj_GetMatchOp, NULL, Opti_GetMatchOp, 0, 0, NULL, NULL, 0, 0 }, /* DVP282 961127 GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 2, 4, 2, 4, NULL, SV_OptiObj_A_BalPosTp, NULL, Opti_Sel_A_BalPosTp, 0, 0, NULL, NULL, 0, 0 }, /* DVP312 961231 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_OptiObj_A_Denom, NULL, Opti_A_Denom_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_A_Geo_ById, NULL, Opti_A_Geo_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_A_ApplMsgTxt, NULL, Opti_A_ApplMsgTxt_ByCdNt, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 10000, 200, 10000, NULL, SV_OptiObj_Synon, NULL, Opti_A_Synon_ById, 0, 0, NULL, NULL, 0, 0 }, /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 50, 200, NULL, SV_OptiObj_A_ValRule_ById, NULL, Opti_A_ValRule_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP344 970404 XDI */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 50, 200, NULL, SV_OptiObj_A_ValRuleHist_ByIdDt, NULL, Opti_A_ValRuleHist_ByIdDt, 0, 0, NULL, NULL, 0, 0 }, /* DVP344 970404 XDI */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 20, 200, NULL, SV_OptiObj_Sel_A_ValRuleElt_ByHid, NULL, Opti_Sel_A_ValRuleElt_ByHid, 0, 0, NULL, NULL, 0, 0 }, /* DVP344 970404 XDI */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 5000, 100, 10000, NULL, SV_OptiObj_Sel_A_ExchRate_ByCidDt, NULL, Opti_Sel_A_ExchRate_ByCidDt, 0, 0, NULL, NULL, 0, 0 }, /* DVP344 970404 XDI */ /* REF11410 - LJE - 051206 - increase size */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 5000, 100, 10000, NULL, SV_OptiObj_Sel_A_InstrPrice_By_IidDt, NULL, Opti_Sel_A_InstrPrice_By_IidDt, 0, 0, NULL, NULL, 0, 0 }, /* DVP344 970404 XDI */ /* REF11410 - LJE - 051206 - increase size */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 50, 200, NULL, SV_OptiObj_S_ValRule_ByCd, NULL, Opti_S_ValRule_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* DVP426 - XDI - 970410 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 100, 50, 100, NULL, SV_OptiObj_Mgr, NULL, Opti_A_Mgr_ById, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 100, 50, 100, NULL, SV_OptiObj_Mgr, NULL, Opti_A_Mgr_ByCd, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 300, 100, 300, NULL, SV_OptiObj_S_Tp_ByCId, NULL, Opti_Sel_S_Tp_ByDidCid, 0, 0, NULL, NULL, 0, 0 }, /* DVP525 970630 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 300, 100, 300, NULL, SV_OptiObj_S_Tp_ByCId, NULL, Opti_Sel_S_Tp_ByDidOperNat, 0, 0, NULL, NULL, 0, 0 }, /* DVP525 970630 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 300, 100, 300, NULL, SV_OptiObj_A_ScriptDef, NULL, Opti_Sel_A_ScriptDef_ByEntFlg, 0, 0, NULL, NULL, 0, 0 }, /* DVP525 970630 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 300, 100, 300, NULL, SV_OptiObj_ScreenProfCompo, NULL, Opti_Sel_S_ScreenProfCompo_BySpid, 0, 0, NULL, NULL, 0, 0 }, /* DVP525 970630 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_S_AccPeriod, NULL, Opti_S_AccPeriod_ById, 0, 0, NULL, NULL, 0, 0}, /* DVP525 970630 PEC */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_S_DataSecuProf, NULL, Opti_S_DataSecuProf_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP525 970630 PEC */ /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 400, 100, 400, NULL, SV_OptiObj_A_PortPosSet_ById, NULL, Opti_A_PortPosSet_ById, 0, 0, NULL, NULL, 0, 0 },  /* DVP526  - GRD - 970630 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 400, NULL, SV_OptiObj_StratLink_Fct, NULL, Opti_StratLink_Fct, 0, 0, NULL, NULL, 0, 0 },      /* DVP529  - GRD - 970630 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 40, 80, 40, 80, NULL, SV_OptiObj_Exd_Instr_RCurrDflt, NULL, Opti_Exd_Instr_RCurrDflt, 0, 0, NULL, NULL, 0, 0 }, /* DVP548+ - GRD - 970805 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 50, 50, 50, NULL, SV_OptiObj_Get_A_DictLang_ById, NULL, Opti_Get_A_DictLang_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP566 - 970819 - GRD */ /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 50, 50, 50, NULL, SV_OptiObj_Get_S_DictLang_ById, NULL, Opti_Get_S_DictLang_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-46681 - LJE - 220705 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_A_ExchFormat_ByCId, NULL, Opti_Get_A_ExchFormat_ByCId, 0, 0, NULL, NULL, 0, 0 }, /* DVP567 - 970819 - GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_A_Calendar_ById, NULL, Opti_Get_A_Calendar_ById, 0, 0, NULL, NULL, 0, 0 }, /* DVP574 - 970826 - GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_S_CalendarConv_ByCId, NULL, Opti_Sel_S_CalendarConv_ByCId, 0, 0, NULL, NULL, 0, 0 }, /* DVP574 - 970826 - GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_S_CalendarDate_ByCId, NULL, Opti_Sel_S_CalendarDate_ByCId, 0, 0, NULL, NULL, 0, 0 }, /* DVP574 - 970826 - GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_A_CalendarConv_ByCIdNat, NULL, Opti_Sel_A_CalendarConv_ByCIdNat, 0, 0, NULL, NULL, 0, 0 }, /* DVP574 - 970826 - GRD */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 500, NULL, SV_OptiObj_Get_A_PtfSynth_ByDim, NULL, Opti_Get_A_PtfSynth_ByDim, 0, 0, NULL, NULL, 0, 0 }, /* REF826 - XDI - 971210 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Sel_A_FTRate_ByTCidDt, NULL, Opti_Sel_A_FTRate_ByTCidDt, 0, 0, NULL, NULL, 0, 0 }, /* REF1219 - GRD - 980202 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 1, 1, 1, 1, NULL, SV_OptiObj_A_Curr_ById, NULL, Opti_Sel_A_Curr_ByConvD, 0, 0, NULL, NULL, 0, 0 }, /* REF1177 - RAK - 980210 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_A_PortPosSet_ByPtfId, NULL, Opti_Sel_A_PortPosSet_ByPtfId, 0, 0, NULL, NULL, 0, 0 }, /* REF1190 - XDI - 980242 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Get_A_FtConvention_ById, NULL, Opti_Get_All_Ft_Convention_By_Id, 0, 0, NULL, NULL, 0, 0 }, /* REF2363 - GRD - 980615 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 50, 5, 50, NULL, SV_OptiObj_Get_A_DictFct_ById, NULL, Opti_Get_A_DictFct_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980622 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_List_ById, NULL, Opti_Get_S_List_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980623 */ /* REF9028 - DDV - 040227 - increase size */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 100, 10, 20, NULL, SV_OptiObj_Get_LastNotepad_ByDIdOIdDt, NULL, Opti_Get_LastNotepad_ByDIdOIdDt, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980626 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_Sel_A_ScriptDef_ById, NULL, Opti_Sel_A_ScriptDef_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980626 */ /*  HFI-PMSTA-18889-141028  Change configuration    */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 50, 5, 50, NULL, SV_OptiObj_Get_S_Calendar_ByCd, NULL, Opti_Get_S_Calendar_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980629 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 50, 5, 50, NULL, SV_OptiObj_Sel_S_CalendarDat_ByNat, NULL, Opti_Sel_S_CalendarDat_ByNat, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980629 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 50, 5, 50, NULL, SV_OptiObj_Get_A_FtConvention_ByCd, NULL, Opti_Get_A_FtConvention_ByCd, 0, 0, NULL, NULL, 0, 0}, /* REF2414 - OCE - 980629 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 20, 5, 20, NULL, SV_OptiObj_Get_A_Fund_ValElem_ByPid, NULL, Opti_Get_A_Fund_ValElem_ByPid, 0, 0, NULL, NULL, 0, 0 }, /* REF2414 - OCE - 980629 */
    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_DF_Bond, 0, 0, NULL, NULL, 0, 0 }, /* REF1055 - AKO - 981216 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_DF_Fut, 0, 0, NULL, NULL, 0, 0 }, /* REF1055 - AKO - 981216 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_CC_Fut, 0, 0, NULL, NULL, 0, 0 }, /* REF1055 - AKO - 981216 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_BS_Opt, 0, 0, NULL, NULL, 0, 0 }, /* REF1055 - AKO - 981216 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_CRR_Opt, 0, 0, NULL, NULL, 0, 0 }, /* REF1055 - AKO - 981216 */
    /*{NULLDYNST, 0, 0, FALSE, RWOpti_AA_BS_Swapt,     0, 0, 0,   50,  200,   50,  200, NULL, SV_OptiObj_AA_DF_Keyword,0,0,NULL,NULL,0,0, Opti_AA_BS_Swapt},  FPL-PMSTA02466-100301   */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_CONV_Bond, 0, 0, NULL, NULL, 0, 0 }, /* REF5049 - AKO - 000804 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DF_Keyword, NULL, Opti_AA_DF_Flow, 0, 0, NULL, NULL, 0, 0 }, /* REF6004 - AKO - 020121 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 2, 10, 2, 10, NULL, SV_OptiObj_Sel_A_ScriptDef_ByEnt, NULL, Opti_Sel_A_ScriptDef_ByEnt, 0, 0, NULL, NULL, 0, 0 }, /* REF3279 - AKO - 990204 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_Tp_ByCid, NULL, Opti_Get_S_Tp_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* DDV - 990422 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Get_S_DictLang_ByCdCid, NULL, Opti_Get_S_DictLang_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* DDV - 990422 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_Tp_ByCid, NULL, Opti_Sel_S_Tp_ByDidTidCid, 0, 0, NULL, NULL, 0, 0 }, /* REF3958 - SSO - 991019 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 100, 50, 100, NULL, SV_OptiObj_Sel_All_Subscription_By_Mod, NULL, Opti_Sel_All_Subscription_By_Mod, 0, 0, NULL, NULL, 0, 0 }, /* REF4204 - GRD - 000207 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_Zrates, NULL, Opti_AA_Zrates, 0, 0, NULL, NULL, 0, 0 }, /* REF4471 - RAK - 000228 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Sel_DictPanel_BySid, NULL, Opti_Sel_DictPanel_BySid, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 0, 0, NULL, SV_OptiObj_Sel_InstrCompo_ByPIdDt, NULL, Opti_Sel_InstrCompo_ByPIdDt, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */ /* No local Opti, stored in Hierachy */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 300, NULL, SV_OptiObj_Get_IdList_ByOIdDt, NULL, Opti_Get_IdList_ByOIdDt, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 300, NULL, SV_OptiObj_Get_ListCompo_ById, NULL, Opti_Get_ListCompo_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF11193 - LJE - 051201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 300, NULL, SV_OptiObj_Get_IdListHist_ByLId, NULL, Opti_Get_IdListHist_ByLId, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_A_FuncSecuProf_ById, NULL, Opti_Get_A_FuncSecuProf_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Get_A_Calendar_ByCd, NULL, Opti_Get_A_Calendar_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 10, 200, NULL, SV_OptiObj_Get_A_EventSched, NULL, Opti_Get_A_EventSched, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */ /* REF7099 - LJE - 011127 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_ExdInstr_OptExo, NULL, Opti_Get_ExdInstr_OptExo, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - DDV - 000414 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_Report_ById, NULL, Opti_Get_S_Report_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF3916 - RAK - 000510 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Sel_S_List_ByDidNat, NULL, Opti_Sel_S_List_ByDidNat, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_Geo_ByCid, NULL, Opti_Get_S_Geo_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_Mgr_ByCid, NULL, Opti_Get_S_Mgr_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_Mgr_ByCdCid, NULL, Opti_Get_S_Mgr_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_ApplRule_ByCd, NULL, Opti_Get_S_ApplRule_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 200, 10, 200, NULL, SV_OptiObj_Get_S_Third_ByCid, NULL, Opti_Get_S_Third_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Get_A_ApplRule_ById, NULL, Opti_Get_A_ApplRule_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF4846 - DDV - 000524 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_Sel_S_SubsCodifCompo_BySid, NULL, Opti_Sel_S_SubsCodifCompo_BySid, 0, 0, NULL, NULL, 0, 0 }, /* REF4204 - GRD - 000616 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Get_A_Map_ById, NULL, Opti_Get_A_Map_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF4204 - GRD - 000620 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Get_A_Report_ById, NULL, Opti_Get_A_Report_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF4980 - DDV - 000720 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Get_S_Third_ByCdCid, NULL, Opti_Get_S_Third_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* REF5298 - SME - 001011 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 1, 10, 20, 200, NULL, SV_OptiObj_Get_A_Domain_ById, NULL, Opti_Get_A_Domain_ById, 0, 0, NULL, NULL, 0, 0 },  /* MDE - REF5443 - 001122 */ /*  FPL-PMSTA02466-100301 replace 20, 200 with 0 to be only local   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_DynamicSql, NULL, Opti_DynamicSql, 0, 0, NULL, NULL, 0, 0 },/* SME - REF5506 - 010122 */ /* REF7440 - LJE - 020321 */ /*  HFI-PMSTA-18889-141028  Change configuration    */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 1000, NULL, SV_OptiObj_SEL_EXTPOS, NULL, Opti_SEL_EXTPOS, 0, 0, NULL, NULL, 0, 0 }, /* REF11524 - LJE - 051208 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 50, 500, NULL, SV_OptiObj_GetExtOp, NULL, Opti_GetExtOp, 0, 0, NULL, NULL, 0, 0 }, /* REF11524 - LJE - 051208 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 10, 100, NULL, SV_OptiObj_Sel_A_StratElt_ByHid, NULL, Opti_Sel_A_StratElt_ByHid, 0, 0, NULL, NULL, 0, 0 }, /* REF5358 - CSY - 010328 */ /* REF5358 - 010328 - DDV - Actually StratElt and StratHist not watched => only local Opti */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_S_Strat_ByCd, NULL, Opti_Get_S_Strat_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF5358 - CSY - 010328 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_Sel_A_MktStruct_ByRefGrid, NULL, Opti_Sel_A_MktStruct_ByRefGrid, 0, 0, NULL, NULL, 0, 0 }, /* REF7395 - YST - 021104 */
    /*{NULLDYNST, 0, 0, FALSE, RWOpti_Sel_A_Subscription_ByMod, 0, 0, 0,   10,  100,  10,  100,  NULL, SV_OptiObj_Sel_A_Subscription_ByMod, 0,0,NULL,NULL,0,0, SV_OptiObj_Sel_A_Subscription_ByMod},   DLA - REF8880 - 030313  FPL-PMSTA02466-100301   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_YTM_Keyword, NULL, Opti_AA_YTM, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_DURA_Keyword, NULL, Opti_AA_DURA, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_CONV_Keyword, NULL, Opti_AA_CONV, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_OPT_PRICE_Keyword, NULL, Opti_AA_OPT_PRICE, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_OPT_SENS_Keyword, NULL, Opti_AA_OPT_SENS, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_AA_OPT_IMPVOL_Keyword, NULL, Opti_AA_OPT_IMPVOL, 0, 0, NULL, NULL, 0, 0 }, /* REF9082 - TEB - 030507 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_A_Fmt_ById, NULL, Opti_Get_A_Fmt_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_A_MktStruct_ById, NULL, Opti_Get_A_MktStruct_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_A_PSPPositionData_ById, NULL, Opti_Get_A_PSPPositionData_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_Get_S_DataSecuProf_ByCd, NULL, Opti_Get_S_DataSecuProf_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */ /* DLA - PMSTA09584 - 110211 increase size*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 10000, 500, 5000, NULL, SV_OptiObj_Get_A_DataSecuProf_ById, NULL, Opti_Get_A_DataSecuProf_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-9742 - PCL - 100429 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_DictEntity_ByDid, NULL, Opti_Get_S_DictEntity_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_DictFct_ByDid, NULL, Opti_Get_S_DictFct_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_DictFct_ByNm, NULL, Opti_Get_S_DictFct_ByNm, 0, 0, NULL, NULL, 0, 0 },  /* PMSTA-46681 - LJE - 230912 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_DictFct_ByPnm, NULL, Opti_Get_S_DictFct_ByPnm, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-46681 - LJE - 230912 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_DictAttr_ByBk, NULL, Opti_Get_S_DictAttr_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-46681 - LJE - 230912 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Get_S_DictLang_ByCid, NULL, Opti_Get_S_DictLang_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Get_S_Fmt_ByCd, NULL, Opti_Get_S_Fmt_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_S_Fmt_ByTslPrecJobCd, NULL, Opti_Sel_S_Fmt_ByTslPrecJobCd, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-37366 - LJE - 200309 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 100, 1000, NULL, SV_OptiObj_Sel_A_InstrChrono_ByDtNat, NULL, Opti_Sel_A_InstrChrono_ByDtNat, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */ /* PMSTA05491 - LJE - 080130 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Sel_A_StratHist_BySidDt, NULL, Opti_Sel_A_StratHist_BySidDt, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 10, 5, 10, NULL, SV_OptiObj_Get_A_StratHist_BySidDt, NULL, Opti_Get_A_StratHist_BySidDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA07963 - LJE - 090618 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 2, 2, 2, 2, NULL, SV_OptiObj_Sel_A_PerfAnalysisParam, NULL, Opti_Sel_A_PerfAnalysisParam, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_A_MktSSubSet_ByRefG, NULL, Opti_Sel_A_MktSSubSet_ByRefG, 0, 0, NULL, NULL, 0, 0 }, /* REF9342 - DDV - 031021 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 500, 2000, NULL, SV_OptiObj_Get_A_Operation_ById, NULL, Opti_Get_A_Operation_ById, 0, 0, NULL, NULL, 0, 0 }, /* REF11194 - RAK - 060515 - Only local optimisation */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 50, 500, NULL, SV_OptiObj_SelExtOp, NULL, Opti_SelExtOp, 0, 0, NULL, NULL, 0, 0 }, /* REF11589 - DDV - 060622 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 20, 100, NULL, SV_OptiObj_Sel_A_ComplChronoByIdDim, NULL, Opti_Sel_A_ComplChronoByIdDim, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA06646 - LJE - 080613 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 1, 1, NULL, SV_Opti_Get_A_TascJob_ByJref, NULL, Opti_Get_A_TascJob_ByJref, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA08246 - LJE - 090616 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 1000, NULL, SV_OptiObj_DataProfCompo_ByBk, NULL, Opti_A_DataProfCompo_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA09740 - DDV - 100531 - New optimisation */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_ScriptDef_Action, NULL, Opti_A_ScriptDef_Action, 0, 0, NULL, NULL, 0, 0 }, /* FPL-PMSTA10714-110202    */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 0, 0, NULL, SV_OptiObj_Sel_A_ScriptDef_ByObjNat, NULL, Opti_Sel_A_ScriptDef_ByObjNat, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-15655 - LJE - 130128 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 0, 0, NULL, SV_OptiObj_Sel_A_SearchProfCompo_BySPFE, NULL, Opti_Sel_A_SearchProfCompo_BySPFE, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-15655 - LJE - 130128 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 0, 0, NULL, SV_OptiObj_Sel_S_SearchCritCompo_BySCId, NULL, Opti_Sel_S_SearchCritCompo_BySCId, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-15655 - LJE - 130128 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 1000, 50, 500, NULL, SV_OptiObj_Get_A_StratElt_ById, NULL, Opti_Get_A_StratElt_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA15739 - DDV - 130227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 50, 1000, NULL, SV_OptiObj_Get_A_Ptf_ByCdCId, NULL, Opti_Get_A_Ptf_ByCdCId, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA15739 - DDV - 130227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_S_SearchProf_ById, NULL, Opti_Get_S_SearchProf_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA15739 - DDV - 130227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 500, 50, 500, NULL, SV_OptiObj_Get_S_BusEntity_ByCid, NULL, Opti_Get_S_BusEntity_ByCid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA17593 - DDV - 140212 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_Get_S_Portfolio_ByUid, NULL, Opti_Get_S_portfolio_ByUid, 0, 0, NULL, NULL, 0, 0}, /* PMSTA-17978 - SHR - 140508*/
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 2000, 200, 2000, NULL, SV_OptiObj_Get_New_InstrRiskOrig_ByBk, NULL, Opti_Get_New_InstrRiskOrig_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18096 - LJE - 140623 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Codif_ById, NULL, Opti_A_Codif_ById, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-18889-141028 */\
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_DictEntity_BySn, NULL, Opti_A_DictEntity_BySn, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-18889-141028 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 100, 100, 100, NULL, SV_OptiObj_A_DictDatatype_ByDid, NULL, Opti_A_DictDatatype_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 100, 100, 100, NULL, SV_OptiObj_S_DictDatatype_ByDid, NULL, Opti_S_DictDatatype_ByDid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 100, 10, 100, NULL, SV_OptiObj_S_DictDatatype_BySn, NULL, Opti_S_DictDatatype_BySn, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 500, 50, 500, NULL, SV_OptiObj_S_RiskRule_ByBk, NULL, Opti_S_RiskRule_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_A_RiskRuleCompo_ByBk, NULL, Opti_A_RiskRuleCompo_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_A_RiskRuleCompo_ByPk, NULL, Opti_A_RiskRuleCompo_ByPk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50865 - FME - 2022-10-20 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 500, 50, 500, NULL, SV_OptiObj_A_RiskValueElt_BestByEntObj, NULL, Opti_A_RiskValueElt_BestByEntObj, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_OptiObj_A_RiskValueEltCompo_ByBk, NULL, Opti_A_RiskValueEltCompo_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_A_StratElt_RiskByCcShid, NULL, Opti_A_StratElt_RiskByCcShid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-18426 - DDV - 141126 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 500, NULL, SV_OptiObj_Get_A_CompChrono_Objective, NULL, Opti_Get_A_CompChrono_Objective, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-19235 - SHR - 150108 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 4, 4, 4, 4, NULL, SV_OptiObj_Get_APAOptimLevel, NULL, Opti_Get_APAOptimLevel, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-19118 - LJE - 0141201 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 200, 50, 200, NULL, SV_OptiObj_Sel_E_DictFct_ByUid, NULL, Opti_Sel_E_DictFct_ByUid, 0, 0, NULL, NULL, 0, 0}, /* PMSTA-17794 - SHR - 150304 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Get_A_PtfChronoByIdDim, NULL, Opti_Get_A_PtfChronoByIdDim, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-21278 - SHR - 141106 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 2000, 100, 2000, NULL, SV_OptiObj_Get_A_ThirdChronoByIdDim, NULL, Opti_Get_A_ThirdChronoByIdDim, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-21278 - SHR - 141106 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 200, 5000, 100, 2000, NULL, SV_OptiObj_Sel_A_ScriptDef_AddByAttr, NULL, Opti_Sel_A_ScriptDef_AddByAttr, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-21147 - DDV - 151120 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 50, 200, NULL, SV_OptiObj_Sel_A_ScriptDef_AddFilter, NULL, Opti_Sel_A_ScriptDef_AddFilter, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-21147 - DDV - 151120 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 200, 2000, NULL, SV_OptiObj_Get_A_Addr_ByTid, NULL, Opti_Get_A_Addr_ByTid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-22956 - DDV - 160623 - New optimisation */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 20, 200, NULL, SV_OptiObj_Get_A_XdEntity_ById, NULL, Opti_Get_A_XdEntity_ById, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-25371 - LJE - 161227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 20, 200, NULL, SV_OptiObj_Get_A_XdEntity_BySqlName, NULL, Opti_Get_A_XdEntity_BySqlName, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-25371 - LJE - 161227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 20, 200, NULL, SV_OptiObj_Get_S_XdEntity_BySqlName, NULL, Opti_Get_S_XdEntity_BySqlName, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-25371 - LJE - 161227 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10,  50, NULL, SV_OptiObj_Get_A_BusEntity_ByPk, NULL, Opti_Get_A_BusEntity_ByPk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-26003 - DDV - 170125 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Sel_Valid_A_ChangeSet, NULL, Opti_Sel_Valid_A_ChangeSet, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-26250 - DDV - 170516 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Sel_EntityByFeatureAuth, NULL, Opti_Sel_EntityByFeatureAuth, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-26250 - DDV - 170601 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_A_DataDependency_ByPk, NULL, Opti_Get_A_DataDependency_ByPk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-29808 - DDV - 180226 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Sel_DictDepends, NULL, Opti_Sel_DictDepends, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-28698 - LJE - 180706 */
	{ NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Get_A_PortfolioInstrPrice_Bydt, NULL, Opti_A_Ptf_Instr_Price_Bydt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-32157 - SILPA - 180905 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 10, 50, 10, 50, NULL, SV_OptiObj_Sel_A_PortfolioInstrPrice_Bydt, NULL, Opti_Sel_A_Ptf_Instr_Price_Bydt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-32764  - SILPA - 181010 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 500, 50, 500, NULL, SV_OptiObj_Get_A_EService_ByBk, NULL, Opti_Get_A_EService_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-35960-190604 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 100, 1000, NULL, SV_OptiObj_Get_A_ExtOp_ById, NULL, Opti_A_ExtOp_ById, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-36664-190723   */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_Get_A_ModelConstrElt_ById, NULL, Opti_A_ModelConstrElt_ById, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-36664-190723   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 1000, 10000, NULL, SV_OptiObj_Sel_A_CaseLink_ByPId, NULL, Opti_Sel_A_CaseLink_ByPId, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-36664-190723   */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 20, 100, NULL, SV_OptiObj_Get_A_ApplUserPreference_eff, NULL, Opti_A_ApplUserPreference_eff, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-37919 - Kramadevi - 29012020  */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Get_A_Subscription_ByCd, NULL, Opti_A_Subscription_ByCd, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-37919 - Kramadevi - 29012020  */
	{ NULLDYNST, 0, 0, FALSE, 0, 0, 0, 5, 100, 5, 100, NULL, SV_OptiObj_Sel_S_SrvRunningPoolCompo_ByNm, NULL, Opti_S_SrvRunningPoolCompo_ByNm, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-39659 ankita - 05082020 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 100, 20, 100, NULL, SV_OptiObj_Sel_A_DocIndexParam_ByBk, NULL, Opti_A_DocIndexParam_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* HFI-PMSTA-36415-210323   */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Sel_A_PerfTimingRule, NULL, Opti_Sel_A_PerfTimingRule, 0, 0, NULL, NULL, 0, 0 },  /* PMSTA-47582 JBC - 220318 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 200, 2000, NULL, SV_OptiObj_Sel_S_Pos_ByPidIidDt, NULL, Opti_Sel_Sh_Pos_By_Pid_Iid_Dt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-47748 - JBC - 210120  */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 0, 200, 2000, NULL, SV_OptiObj_Sel_S_Pos_ByPidDt, NULL, Opti_Sel_Sh_Pos_By_Pid_Dt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-47748 - JBC - 210120  */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 1000, 100, 1000, NULL, SV_OptiObj_GetLockInfo_ByPidIidDt, NULL, Opti_GetLockInfo_ByPidIidDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-45670 - AIS - 220908 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0,   0,    0, 100, 1000, NULL, SV_OptiObj_SqlBiObjective, NULL, Opti_SqlBiObjective, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220913 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0,  10,  100,  10, 100, NULL, SV_Opti_A_BusIndicatorElt_ByBk, NULL, Opti_A_BusIndicatorElt_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_Opti_A_InstrBiValue_ByDt, NULL, Opti_A_InstrBiValue_ByDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_Opti_A_PortBiValue_ByDt, NULL, Opti_A_PortBiValue_ByDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_Opti_A_StratBiValue_ByDt, NULL, Opti_A_StratBiValue_ByDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_Opti_A_ThirdBiValue_ByDt, NULL, Opti_A_ThirdBiValue_ByDt, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0,  50,  500,  50, 500, NULL, SV_Opti_S_BusIndicator_ByBk, NULL, Opti_S_BusIndicator_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-50418 - DDV - 220928 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 4, 4, 4, 4, NULL, SV_OptiObj_Get_All_Dict_Database_ByPk, NULL, Opti_Get_All_Dict_Database_ByPk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025 */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 4, 4, 4, 4, NULL, SV_OptiObj_Get_All_Dict_Segment_ByBk, NULL, Opti_Get_All_Dict_Segment_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025  */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 4, 4, 4, 4, NULL, SV_OptiObj_Sel_All_XdIndex_ByPid, NULL, Opti_Sel_All_XdIndex_ByPid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025  */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 4, 4, 4, 4, NULL, SV_OptiObj_Sel_All_XdIndexAttrib_ByPid, NULL, Opti_Sel_All_XdIndexAttrib_ByPid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025  */    
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_Sel_All_Format_Elem_ForTsl, NULL, Opti_Sel_All_Format_Elem_ForTsl, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025 */     
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 50, 300, 50, 300, NULL, SV_OptiObj_Sel_Sh_Tsl_Prec_job_Elt_Compo, NULL, Opti_Sel_Sh_Tsl_Prec_job_Elt_Compo, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-49177 - LJE - 221025 */
	{ NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 500, 100, 500, NULL, SV_OptiObj_Get_A_CaseTemplDef_ByBk,NULL,Opti_Get_A_CaseTemplDef_ByBk, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-38367 - MSS - 191219 */
	{ NULLDYNST, 0, 0, FALSE, 0, 0, 0, 100, 200, 100, 200, NULL, SV_OptiObj_Get_S_Depo_ByCdCid,NULL,Opti_Get_S_Depo_ByCdCid, 0, 0, NULL, NULL, 0, 0 }, /* PMSTA-38367 - MSS - 191219 */
	{ NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 1000, 50, 0, NULL, SV_OptiObj_Sel_Ptf_Id_ByLid,NULL,Opti_Sel_Portfolio_Id_ByLid, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 0, 1000, 50, 0, NULL, SV_OptiObj_Chk_Ptf_Hier_By_Id,NULL,Opti_Chk_Ptf_Hier_By_Id, 0, 0, NULL, NULL, 0, 0 },/*PMSTA-48867-Satya*/
	
    /* Opti_Get_BusEntityBy_Cdcid - PMSTA-51053 - AAKASH - 13072023 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_BusEntitybycd_cid,NULL,Opti_Get_BusEntityBy_Cdcid, 0, 0, NULL, NULL, 0, 0 },

    /* Opti_Get_S_QuestHisto_By_Pk - PMSTA-51053 - AAKASH - 13072023 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_S_QuestHisto_By_Pk,NULL,Opti_Get_S_QuestHisto_By_Pk, 0, 0, NULL, NULL, 0, 0 },

    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_A_PackageEntity_By_Pk,NULL,Opti_Get_A_PackageEntity_By_Pk, 0, 0, NULL, NULL, 0, 0 },

    /* Opti_Sel_All_PerfCalcDefProfCompo_ByPId - PMSTA-54529 - DDV - 231009 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Opti_Sel_All_PerfCalcDefProfCompo_ByPId,NULL,Opti_Sel_All_PerfCalcDefProfCompo_ByPId, 0, 0, NULL, NULL, 0, 0 },

    /*  Opti_Get_S_AnswerPermValDef_ByQidPval      HFI-PMSTA-55441-2024-01-26  */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Opti_Get_S_AnswerPermValDef_ByQidPval,NULL,Opti_Get_S_AnswerPermValDef_ByQidPval, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Opti_Sel_Sh_QuestEltDef_ById,NULL,Opti_Sel_Sh_QuestEltDef_ById, 0, 0, NULL, NULL, 0, 0 },
    /* WEALTH-6158 - JBC - 20240330 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_Ptf_InceptDt,NULL,Opti_Get_Ptf_InceptDt, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_Third_InceptDt,NULL,Opti_Get_Third_InceptDt, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_HistList_InceptDt,NULL,Opti_Get_HistList_InceptDt, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0,  0,   0, 20, 200, NULL, SV_OptiObj_GetDomainInceptDt,NULL,Opti_GetDomainInceptDt, 0, 0, NULL, NULL, 0, 0 },
    /*  Opti_Sel_Sh_QuestEltDef_ForQuestSCore       HFI-WEALTH-7558-2024-05-03  */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Opti_Sel_Sh_QuestEltDef_ForQuestSCore,NULL,Opti_Sel_Sh_QuestEltDef_ForQuestSCore, 0, 0, NULL, NULL, 0, 0 },
    /*Opti_Get_S_FtConvention_ByCd -  PMSTA-56959 - SSA - 20240828 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_Get_S_FtConvention_ByCd,NULL, Opti_Get_S_FtConvention_ByCd, 0, 0, NULL, NULL, 0, 0 },
        /* Opti_A_RiskValueEltCompo_ByPk PMSTA-64803- VPR - 20250202 */
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 500, 5000, 500, 5000, NULL, SV_OptiObj_A_RiskValueEltCompo_ByBk, NULL, Opti_A_RiskValueEltCompo_ByPk, 0, 0, NULL, NULL, 0, 0 },
    { NULLDYNST, 0, 0, FALSE, 0, 0, 0, 20, 200, 20, 200, NULL, SV_OptiObj_A_ConstrTemplateById, NULL, Opti_A_ConstrTemplateById, 0, 0, NULL, NULL, 0, 0 },
};

int EV_NewOptiListSize;
static DBA_DYNFLD_STP *SV_TabModifStatPtr = nullptr;
static int             SV_TabModifStatNbr = 0;

STATIC void     DBA_UpdDfltDispFlg(void);
STATIC RET_CODE DBA_InitOptiArgInfo(DBA_PROC_STP, DBA_OPTIMODE_ENUM, DBA_OPTI_STP);
int DBA_SearchElmtInIndexOpti(DBA_OPTI_STP, DBA_PROC_STP, DBA_DYNFLD_STP, int *, FLAG_T);
int DBA_CmpProcInputArg(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int, DBA_PROC_STP);
int DBA_CmpAllInputArg(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_OPTI_STP, DBA_PROC_STP, FLAG_T); /* PMSTA-36451 - DDV - 190708 - Add new parameter */
RET_CODE DBA_GetAFreeCellInOpti(DBA_OPTI_STP, int *);
void DBA_VerifDictEntityModif(DBA_DYNFLD_STP, DBA_DYNFLD_STP);

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
*
*   Function           : DBA_DisableLocalCache()
*
*   Description        : Disable the local cache of the given cache optimization
*
*   Arguments          : optiEn Optimization to disable
*
*   Return             : true  if ok
*                        false if problem
*
*   Modif.             : PMSTA-11733 - 150411 - PMO : Purge order function does not work on block orders and it cannot be started from the GUI any more
* Opti_Local
*************************************************************************/
bool DBA_DisableLocalCache(const DBA_OPTI_ENUM optiEn)
{
    bool            ret = false;

    if (SYS_IsSrvMode())
    {
        DBA_OPTI_STP    optiBase;
        if ((optiBase = SYS_GetThreadDataCtxServer()->getOptiPtr()) != nullptr)     /* DLA - PMSTA-26864 - 170405 */
        { /* Ok */
            DBA_OPTI_STP optiPtr = optiBase + optiEn;

            optiPtr->allocBloc = 0;
            optiPtr->maxAllocNbr = 0;
            ret = true;
        }
    }

    return ret;
}

/************************************************************************
*
*   Function           : DBA_VerifDictEntityModif()
*
*   Description        : Compares modification dates and times of dict_entity tables
*                        between the startup of the server, and this call to DBA_VerifOptiTab
*                        If it turns out dict_entity has been modified since the startup
*                        of the server, log an error message and shutdown the financial server.
*
*   Arguments          : oldDictEntityModifPtr: dict_entity table modif info at server startup
*                        newDictEntityModifPtr: current dict_entity table modif info
*
*   Return             : nothing
*
*   Creation Date      : PMSTA-12661 - RPO - 110916
*                        PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
void DBA_VerifDictEntityModif(DBA_DYNFLD_STP oldDictEntityModifPtr, DBA_DYNFLD_STP newDictEntityModifPtr)
{
    static int msgDisplay = 0;

    int stopServer = 0;   /* stopServer is a flag to remember whether we have to stop the server */

    if (newDictEntityModifPtr == nullptr) /* if dict_entity wasn't in current table_modif_stat, OK */
        return;

    /* we know dict_entity is in current table_modif_stat */
    if (oldDictEntityModifPtr == nullptr) /* if dict_entity wasn't in table_modif_stat at server startup, means table was updated */
        stopServer = 1;
    else /* if it was, check the modif times between server startup and current table_modif_stat data */
    {
        const int cmp = DATETIME_CMP(GET_DATETIME(newDictEntityModifPtr, A_TabModifStat_LastModifDate),
            GET_DATETIME(oldDictEntityModifPtr, A_TabModifStat_LastModifDate));
        if (cmp > 0 ||
            (cmp == 0 && CMP_DYNFLD(oldDictEntityModifPtr, newDictEntityModifPtr, A_TabModifStat_LastModifDateMs, A_TabModifStat_LastModifDateMs, IntType) < 0))
            stopServer = 1;
    }

    if (stopServer > 0 && msgDisplay == 0)
    {
        if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "dict_entity has changed since server startup - financial server must be restarted after operating on the meta dictionary");
            MSG_LogMesg(RET_DBA_ERR_MD_DICT_ENTITY_CHANGED, 0, FILEINFO); /* PMSTA-47004 - FME - 20211116 */

            /* Avoid to lose my work */
            if (nullptr != SYS_GetEnv("AAANOEXITONDICTENTITYCHANGE"))
            {
                msgDisplay++;
                return;
            }
            SERV_StopFinServer(TRUE);
        }

        if (TRUE == SYS_IsGuiMode())                        /* PMSTA-20089 - 120515 - PMO */
        {
            MSG_DispMesg(RET_DBA_ERR_MD_DICT_ENTITY_CHANGED, 0, "dict_entity has changed since server startup"); /* PMSTA-47004 - FME - 20211116 */
            /* Avoid to lose my work */
            if (nullptr!= SYS_GetEnv("AAANOEXITONDICTENTITYCHANGE"))
            {
                msgDisplay++;
                return;
            }

            SYS_Shutdown(EXIT_SUCCESS);    /* DLA - PMSTA-26546 - 170314 */
        }
    }
}

/************************************************************************
*
*   Function        : DBA_ForceVerifOptiTab
*
*   Description     : Force the verification of opti table
*
*   Arguments       : DbiConnectionHelper *dbiConnHelperParam    : Connection
*
*   Return          : TRUE if success, FALSE elsewhere
*
*   Modif.          : HFI-PMSTA-39502-200407
*
*************************************************************************/
int DBA_ForceVerifOptiTab (DbiConnectionHelper * dbiConnHelperParam)
{
    EV_GuiCheckOptiStatus = NextNoCheck_GuiOptiStatus;
    EV_GuiCheckOptiDelta = 0;
    return DBA_VerifOptiTab(dbiConnHelperParam);
}


/************************************************************************
*
*   Function           : DBA_VerifOptiTab()
*
*   Description        : Verify modification table statistic which contains
*                        last modification date for optimised table.
*                        Compare global table (SV_TabModifStatPtr) and loaded table.
*                        The two tables have same lines number in same order.
*
*   Arguments          : nothing
*
*   Return             : TRUE if success, FALSE elsewhere
*
*   Modif.      :   ROI - 981202 - REF2644
*                   PMSTA-12661 - RPO - 110913 - check if dict_entity table has been modified since server startup
*                   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                   PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
int DBA_VerifOptiTab(DbiConnectionHelper * dbiConnHelperParam)
{
    OBJECT_ENUM    modifEnt;
    DBA_DYNFLD_STP *newTabModifStatPtr = nullptr;
    int            i, j, newTabModifStatNbr, cmp;
    DBA_DYNFLD_STP oldDictEntityModifPtr = nullptr, newDictEntityModifPtr = nullptr; /* PMSTA-12661 - RPO - 110913 - will hold dict_entity modif info */
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal,SqlServer, ROLE_ADMIN);

    if (SYS_IsGuiMode())
    {
        static      char    firstFlg = 1;
        unsigned    int     delta;
        CODE_T              sessionCd;
        MemoryPool          mp;

        /* Gestion du status d'optimisation */
        switch (EV_GuiCheckOptiStatus) {
        case Check_GuiOptiStatus:
            break;
        case NoCheck_GuiOptiStatus:
            return TRUE;
            break;
        case NextNoCheck_GuiOptiStatus:
            EV_GuiCheckOptiStatus = NoCheck_GuiOptiStatus;
            break;
        }

        DBA_UpdOptiTab(EV_OptiPtr, Domain);		/* REF5781 - DDV + MRA - 010409 */
        delta = EV_GuiCheckOptiDelta;

        if (EV_GuiCheckOptiDelta != DEF_GUICHK_DELTA)
            EV_GuiCheckOptiDelta = DEF_GUICHK_DELTA;

        if (firstFlg == 1)
            firstFlg = 0;
        else
        {
            DATE_StopTimer(&EV_GuiCheckOptiTimer, TIMER_MASK_ALL);

            if (EV_GuiCheckOptiTimer.cumul.tv_sec < (long)delta)
            {
                DATE_StartTimer(&EV_GuiCheckOptiTimer, TIMER_MASK_ALL);
                return(TRUE);
            }
        }

        DATE_ResetTimer(&EV_GuiCheckOptiTimer, TIMER_MASK_ALL);
        DATE_StartTimer(&EV_GuiCheckOptiTimer, TIMER_MASK_ALL);

        /* PMSTA-23726 - DDV - 160624 - check if session is always valid */
        DBA_GetApplSessionCode(&sessionCd);
        if (sessionCd[0] != END_OF_STRING)
        {
            DBA_DYNFLD_STP applSessionStp = nullptr;
            RET_CODE       ret;

            ret = DBA_GetRecordByCd(ApplSession,
                                    sessionCd, 
                                    A_ApplSession, 
                                    &applSessionStp, 
                                    mp,
                                    dbiConnHelperParam != nullptr ? dbiConnHelperParam : &dbiConnHelper);

            if (ret == RET_DBA_ERR_NODATA)
            {
                DBA_SetExitReason(ExitReason_InvalidSession);
                OIT_PostForceExitRecal(nullptr);
                return(TRUE);
            }
        }
    }

    if (DBA_Select2(TabModifStat, UNUSED, NullDynSt, nullptr,
        A_TabModifStat, &newTabModifStatPtr,
        UNUSED, &newTabModifStatNbr,  dbiConnHelperParam != nullptr ? *dbiConnHelperParam : dbiConnHelper) == RET_SUCCEED)
    {
        LockGuard lock(ServLockForOptiPtr, true, FILEINFO);                                           /* PMSTA-20089 - 041015 - PMO */

        if (false == lock.isOk())                                                               /* PMSTA-20089 - 041015 - PMO */
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SERV_GetOptiPtr FAILED");
            return FALSE;
        }

        /* We are on first RPC call, copy loaded statistic */
        /* table in server global table                    */
        /* ?? ou load au d?marrage du serveur (+ logique)  */
        if (SV_TabModifStatNbr == 0)
        {
            SV_TabModifStatPtr = newTabModifStatPtr;
            SV_TabModifStatNbr = newTabModifStatNbr;

            if (TRUE == SYS_IsGuiMode())                        /* PMSTA-20089 - 120515 - PMO */
            {

                for (i = 0; i<SV_TabModifStatNbr; i++)
                {
                    switch (GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId))
                    {
                    case 1:
                        DATETIME_T      dateTime1;
                        memset(&dateTime1, 0, sizeof(DATETIME_T));

                        DBA_GetDbDate(&dateTime1);
                        DATETIME_T dateTime2 = GET_DATETIME(SV_TabModifStatPtr[i], A_TabModifStat_LastModifDate);

                        if (DATETIME_CMP(dateTime1, dateTime2) < 0)
                        {
                            MSG_DispMesg(RET_CATEG_GEN, UNUSED, "Due to administration reasons, System is not available"); /* PMSTA-17133 - 051113 - PMO / FPL-REF5959-020827 if database stoped with "stop_all_gui", we display a message */
                            SYS_Shutdown(EXIT_SUCCESS);    /* DLA - PMSTA-26546 - 170314 */
                        }
                        break;
                    }
                }
            }
            return(TRUE);
        }
        else
        {
            if (SV_TabModifStatNbr == newTabModifStatNbr)
            {
                /* Search if one optimised table has been modified */
                for (i = 0; i<SV_TabModifStatNbr; i++)
                {
                    if (GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId) ==
                        GET_DICT(newTabModifStatPtr[i], A_TabModifStat_DictId))
                    {

                        DBA_GetObjectEnum(GET_DICT(SV_TabModifStatPtr[i], /* PMSTA-12661 - RPO - 110913 - taking this out of */
                            A_TabModifStat_DictId),         /* PMSTA-12661 - RPO - 110913 - ifdef SERV_PROCESS */
                            &modifEnt);                     /* PMSTA-12661 - RPO - 110913 - as we now need it in all cases*/

                        /* PMSTA-12661 - RPO - 110929 - if on dict_entity modif info, we can compare modif times straight away */
                        if (modifEnt == DictEntity)
                            DBA_VerifDictEntityModif(SV_TabModifStatPtr[i], newTabModifStatPtr[i]);

                        if (SYS_IsSrvMode())
                        {
                            /* REF11845 - DDV - 060621 - Flush of DV and IC optimization based on date stored in Thread must be changed when general optimisation tools exist */
                            if (modifEnt == ScriptDef ||
                                modifEnt == ApplUser ||
                                modifEnt == ScreenProfCompo)
                            {
                                DATETIME_T     threadLastPurgeDate;

                                SERV_GetLastPurgeDate(&threadLastPurgeDate);

                                cmp = DATETIME_CMP(threadLastPurgeDate, GET_DATETIME(newTabModifStatPtr[i], A_TabModifStat_LastModifDate));

                                if (cmp < 0)
                                {
                                    SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */
                                    SCPT_FreeScriptIC(NullEntity); /* PMSTA06772 - 080619 - DDV */
                                    SERV_SetLastPurgeDate(GET_DATETIME(newTabModifStatPtr[i], A_TabModifStat_LastModifDate));
                                }
                            }
                        }

                        cmp = DATETIME_CMP(GET_DATETIME(SV_TabModifStatPtr[i],
                            A_TabModifStat_LastModifDate),
                            GET_DATETIME(newTabModifStatPtr[i],
                            A_TabModifStat_LastModifDate));

                        if (cmp != 0 ||
                            (cmp == 0 && CMP_DYNFLD(SV_TabModifStatPtr[i], newTabModifStatPtr[i], A_TabModifStat_LastModifDateMs, A_TabModifStat_LastModifDateMs, IntType) < 0)) /* PMSTA10087 - DDV - 100729 - Returns milliseconds from table_modif_stat */
                        {

                            /* REFxxx 98/02/23 */
                            switch ((int)GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId))    /* DLA - PMSTA08801 - 101027 */
                            {
                            case 1: /* Force GUI to exit */
                                if (SYS_IsGuiMode())
                                {
                                    OIT_PostForceExitRecal(nullptr);
                                    break;
                                }
                            case 2: /* DLA - REF7264 - 020131 dummy value to get rid of warning*/
                            default:
                                switch (GET_OBJECT_CST(modifEnt))
                                {
                                case BoottimeCst: /* Force GUI to exit */ /* PMSTA-16365 - 090514 */
                                    if (SYS_IsGuiMode())
                                        OIT_PostForceExitRecal(nullptr);
                                    else if (SYS_IsSrvMode())
                                        SERV_StopFinServer(FALSE);
                                    break;

                                default:
                                    DBA_UpdOptiTab(EV_OptiPtr, modifEnt);
                                    break;
                                }
                                break;
                            }

                            /* ?? Lock */
                            COPY_DYNST(SV_TabModifStatPtr[i],
                                newTabModifStatPtr[i],
                                A_TabModifStat);
                        }
                    }
                    else
                    {
                        /* DDV - 990423 - Entity list is different, purge all entity */
                        for (j = i; j<SV_TabModifStatNbr; j++)
                        {
                            /* Convert dict id to object enum and */
                            /* update affected optimisation       */
                            DBA_GetObjectEnum(GET_DICT(SV_TabModifStatPtr[j],
                                A_TabModifStat_DictId),
                                &modifEnt);
                            DBA_UpdOptiTab(EV_OptiPtr, modifEnt);

                            if (modifEnt == DictEntity)
                            {
                                oldDictEntityModifPtr = SV_TabModifStatPtr[j];
                            }

                            /* PMSTA-12661 - RPO - 110913 - making this check to avoid calling */
                            /* DBA_GetObjectEnum even after dict_entity's been found (we know it */
                            /* will appear only once, as it's the primary key of table_modif_stat) */
                            if (newDictEntityModifPtr == nullptr)
                            {
                                DBA_GetObjectEnum(GET_DICT(newTabModifStatPtr[j],
                                    A_TabModifStat_DictId),
                                    &modifEnt);
                                if (modifEnt == DictEntity)
                                    newDictEntityModifPtr = newTabModifStatPtr[j];
                            }
                        }

                        /* PMSTA-12661 - RPO - 110913 - check if dict_entity was modified */
                        DBA_VerifDictEntityModif(oldDictEntityModifPtr, newDictEntityModifPtr);

                        /* DDV - 990423 - Free old Tab and use the new one */
                        DBA_FreeDynStTab(SV_TabModifStatPtr,
                            SV_TabModifStatNbr,
                            A_TabModifStat);

                        SV_TabModifStatPtr = newTabModifStatPtr;
                        SV_TabModifStatNbr = newTabModifStatNbr;
                        return(TRUE);
                        /* Old code - DDV - 990423 */
                    }
                }

                for (i = 0; i<newTabModifStatNbr; i++)
                    FREE_DYNST(newTabModifStatPtr[i], A_TabModifStat);

                FREE(newTabModifStatPtr);

                return(TRUE);
            }
            else
            {
                /* DDV - 990423 - Entity list is different, purge all entity */
                for (j = 0; j<SV_TabModifStatNbr; j++)
                {
                    /* Convert dict id to object enum and */
                    /* update affected optimisation       */
                    DBA_GetObjectEnum(GET_DICT(SV_TabModifStatPtr[j], A_TabModifStat_DictId), &modifEnt);
                    DBA_UpdOptiTab(EV_OptiPtr, modifEnt);

                    if (modifEnt == DictEntity)
                    {
                        oldDictEntityModifPtr = SV_TabModifStatPtr[j];
                    }
                }

                /* PMSTA-12661 - RPO - 110913 - also loop through new table modif stat, to find current dict_entity modif info */
                for (j = 0; j<newTabModifStatNbr; j++)
                {
                    /* Convert dict id to object enum */
                    DBA_GetObjectEnum(GET_DICT(newTabModifStatPtr[j], A_TabModifStat_DictId), &modifEnt);

                    if (modifEnt == DictEntity)
                    {
                        newDictEntityModifPtr = newTabModifStatPtr[j];
                        break; /* PMSTA-12661 - RPO - 110913 - once it's been found we can exit the loop */
                    }
                }

                /* PMSTA-12661 - RPO - 110913 - check if dict_entity was modified */
                DBA_VerifDictEntityModif(oldDictEntityModifPtr, newDictEntityModifPtr);

                /* DDV - 990423 - Free old Tab and use the new one */
                DBA_FreeDynStTab(SV_TabModifStatPtr,
                    SV_TabModifStatNbr,
                    A_TabModifStat);

                SV_TabModifStatPtr = newTabModifStatPtr;
                SV_TabModifStatNbr = newTabModifStatNbr;

                return(TRUE);
            }
        }
    }

    return(TRUE); /* lint - RAK - 960711 */
}

/************************************************************************
*   Function             : DBA_SelectOptiCompo()
*
*   Description          : Load Opti Compo for current opti profile
*
*   Arguments            : None
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : REF11767 - CHU - 060403
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_SelectOptiCompo(ID_T optiProfId, DBA_DYNFLD_STP **optiCompoTab, int *optiCompoNbr, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE		retCd = RET_SUCCEED;
    DBA_DYNFLD_STP	admArgIn;

    *optiCompoNbr = 0;

    if ((admArgIn = ALLOC_DYNST(Adm_Arg)) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (optiProfId > (ID_T)0)
    {
        SET_ID(admArgIn, Adm_Arg_Id, optiProfId);

        if ((retCd = DBA_Select2(OptiProfCompo, UNUSED, Adm_Arg, admArgIn, A_OptiProfCompo, optiCompoTab,
            UNUSED, optiCompoNbr, dbiConnHelper)) != RET_SUCCEED)
        {
            FREE_DYNST(admArgIn, Adm_Arg);
            return(retCd);
        }
    }
    FREE_DYNST(admArgIn, Adm_Arg);
    return(retCd);
}

/************************************************************************
*   Function             : DBA_InitOptiTab()
*
*   Description          : Load Opti Compo and Init Opti Tab
*
*   Arguments            : None
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA-20269 - DDV - 150427
*
*   Last Modif           : PMSTA-53404 - AAKASH - 15-06-2023 : Avoid the Optimization of the stored proc with Opti Index as OptiForbidden.
*
*************************************************************************/
RET_CODE DBA_InitOptiTab(DbiConnectionHelper &dbiConnHelper)
{

    DBA_DYNFLD_STP	*optiCompoTab = nullptr;
    DBA_DYNFLD_STP  sOptiProc = nullptr;
    CODE_T          newOptiProc;
    OBJECT_ENUM		entObj;
    int             procIdx, optiCompoNbr = 0;
    int             i, j = 0, nb = 0;
    FLAG_T          useShadowTableFlg;
    DICT_ENTITY_STP dictEntityStp = nullptr;

    DBA_DYNFLD_STP	sServConnect = nullptr;
    std::string		serverName;
    RET_CODE	    ret;

    /* retrieve current server record */
    if (!SYS_IsUnitTest() && SYS_IsSrvMode()){
        if (SV_ServConnectRecord == nullptr)
        {
            if ((SV_ServConnectRecord = ALLOC_DYNST(A_ServConnect)) == nullptr)
            {
                return(RET_MEM_ERR_ALLOC);
            }

            if ((sServConnect = ALLOC_DYNST(S_ServConnect)) == nullptr)
            {
                FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
                return(RET_MEM_ERR_ALLOC);
            }

            GEN_GetApplInfo(ApplServerName, serverName);
            SET_SYSNAME(sServConnect, S_ServConnect_ServerName, serverName.c_str());  /* DLA - PMSTA09880 - 100715 */

            if (dbiConnHelper.dbaGet(ServConnect,UNUSED, sServConnect, &SV_ServConnectRecord) != RET_SUCCEED) /* PMSTA-34200 - LJE - 190111 */
            {
                FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
                FREE_DYNST(sServConnect, S_ServConnect);
                MSG_RETURN(RET_DBA_ERR_NODATA);
            }
            FREE_DYNST(sServConnect, S_ServConnect);

            if (IS_NULLFLD(SV_ServConnectRecord, A_ServConnect_OptiProfileId) == FALSE)
            {
                if ((ret = DBA_SelectOptiCompo(GET_ID(SV_ServConnectRecord, A_ServConnect_OptiProfileId),
                    &optiCompoTab, &optiCompoNbr, dbiConnHelper)) != RET_SUCCEED)
                {
                    return(ret);
                }
            }
        }
    }

    EV_NewOptiListSize = static_cast<int>(Opti_Number);
    int newMaxOptiListSize = EV_NewOptiListSize + optiCompoNbr;

    if ((EV_OptiPtr = (DBA_OPTI_ST *)CALLOC(newMaxOptiListSize, sizeof(DBA_OPTI_ST))) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i = 0; i < EV_NewOptiListSize; i++)
    {
        /* PMSTA-53274 integrity management */
        const int optiEnumIdx = static_cast<int>(SV_OptiTab[i].optiEnum);
        if(optiEnumIdx < 0 || optiEnumIdx >= Opti_Number)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("OptiTab[",i,"] has invalid DBA_OPTI_ENUM index [",optiEnumIdx,"]").c_str());
            SYS_BreakOnDebug();
            return RET_DBA_ERR_OPTI;
        }       

        if(EV_OptiPtr[optiEnumIdx].objLstPtr != nullptr && SV_OptiTab[i].objLstPtr != nullptr)
        {   
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("OptiTab[",i,"] has duplicated DBA_OPTI_ENUM index [",optiEnumIdx,"]").c_str());
            SYS_BreakOnDebug();
            return RET_DBA_ERR_OPTI;
        }

        EV_OptiPtr[optiEnumIdx].dataPtr                = SV_OptiTab[i].dataPtr;
        EV_OptiPtr[optiEnumIdx].inputArgNbr            = SV_OptiTab[i].inputArgNbr;
        EV_OptiPtr[optiEnumIdx].outputFldNbr           = SV_OptiTab[i].outputFldNbr;
        EV_OptiPtr[optiEnumIdx].strArgFlg              = SV_OptiTab[i].strArgFlg;
        EV_OptiPtr[optiEnumIdx].currentReadNbr         = SV_OptiTab[i].currentReadNbr;
        EV_OptiPtr[optiEnumIdx].eltNbr                 = SV_OptiTab[i].eltNbr;
        EV_OptiPtr[optiEnumIdx].allocNbr               = SV_OptiTab[i].allocNbr;
        EV_OptiPtr[optiEnumIdx].allocBloc              = SV_OptiTab[i].allocBloc;
        EV_OptiPtr[optiEnumIdx].maxAllocNbr            = SV_OptiTab[i].maxAllocNbr;
        EV_OptiPtr[optiEnumIdx].locAllocBloc           = SV_OptiTab[i].locAllocBloc;
        EV_OptiPtr[optiEnumIdx].locMaxAllocNbr         = SV_OptiTab[i].locMaxAllocNbr;
        EV_OptiPtr[optiEnumIdx].procPtr                = SV_OptiTab[i].procPtr;
        EV_OptiPtr[optiEnumIdx].objLstPtr              = SV_OptiTab[i].objLstPtr;
        EV_OptiPtr[optiEnumIdx].optiEnum               = SV_OptiTab[i].optiEnum;
        EV_OptiPtr[optiEnumIdx].useShadowTableFlg      = FALSE;
        EV_OptiPtr[optiEnumIdx].checkDlmeMaxFlg        = FALSE;              /* PMSTA-26108 - DDV - 171004 */
        EV_OptiPtr[optiEnumIdx].checkDataProfileFlg    = FALSE;          /* PMSTA-26108 - DDV - 171004 */
        EV_OptiPtr[optiEnumIdx].checkBusinessEntityFlg = FALSE;       /* PMSTA-26108 - DDV - 171004 */

        /* PMSTA-20269 - DDV  -150427 */
        useShadowTableFlg = FALSE;
        if (SV_OptiTab[i].objLstPtr != nullptr)
        {
            nb = 0;

            while (*(SV_OptiTab[i].objLstPtr[nb]) != NullEntity)
                nb++;

            nb++;
            if ((EV_OptiPtr[optiEnumIdx].objLst = (OBJECT_ENUM *)CALLOC(nb, sizeof(OBJECT_ENUM))) != nullptr)
            {
                for (j = 0; j < nb; j++)
                {
                    EV_OptiPtr[optiEnumIdx].objLst[j] = *(SV_OptiTab[i].objLstPtr[j]);

                    if ((dictEntityStp = DBA_GetDictEntitySt(EV_OptiPtr[optiEnumIdx].objLst[j])) != nullptr &&
                         dictEntityStp->changeSetAuthEn == FeatureAuth_Enable)
                    {
                        useShadowTableFlg = TRUE;
                    }
                    DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(EV_OptiPtr[optiEnumIdx].objLst[j]);
                    if (dictEntityPtr != nullptr)
                    {
                        /* PMSTA-24030 - DDV - 161220 - If data life cycle management is active on this entity, update checkDlmeMaxFlg. Later it may be based on dict_sproc content */
                        if (dictEntityPtr->dlmAuthEn == FeatureAuth_Enable)
                            EV_OptiPtr[optiEnumIdx].checkDlmeMaxFlg = TRUE;

                        /* PMSTA-24030 - DDV - 161220 - If entity is secured, add check on data_profile. Later it may be based on dict_sproc content */
                        if (dictEntityPtr->securityLevelEn != EntSecuLevel_NoSecured)
                            EV_OptiPtr[optiEnumIdx].checkDataProfileFlg = TRUE;

                        /* PMSTA-26108 - 170929 - DDV */
                        if (dictEntityPtr->isMultiBusinessEntityManagement())
                            EV_OptiPtr[optiEnumIdx].checkBusinessEntityFlg = TRUE;
                    }
                }
            }
        }

        /* PMSTA_26250 - DDV - 170627 - Disable cache on Dynamci Sql when a change_set is active */
        if (i == Opti_DynamicSql)
            EV_OptiPtr[optiEnumIdx].useShadowTableFlg = TRUE;
        else
            EV_OptiPtr[optiEnumIdx].useShadowTableFlg = useShadowTableFlg;

        EV_OptiPtr[optiEnumIdx].globalLock = SYS_CreateRWLock(FILEINFO);
    }

    /* PMSTA-53274 integrity management */
    for (i = 0; i < EV_NewOptiListSize; i++)
    {        
        if(EV_OptiPtr[i].objLst == nullptr)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("OptiTab[",i,"] has missing definition for DBA_OPTI_ENUM index [",i,"]").c_str());
            SYS_BreakOnDebug();
            return RET_DBA_ERR_OPTI;
        }  
    }

    int newOptiCompoNbr = 0;
    int tabIdx = i;

    for (int compoIdx = 0; compoIdx < optiCompoNbr; compoIdx++)
    {
        strcpy(newOptiProc, GET_CODE(optiCompoTab[compoIdx], A_OptiProfCompo_ProcSqlName));
        for (OBJECT_ENUM objIdx = 0; objIdx <= LASTOBJECT; objIdx++)
        {
            DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(objIdx);

            if (objProcLstStp != nullptr)
            {
                for (procIdx = 0; objProcLstStp[procIdx].action != NullAction; procIdx++)
                {
                    if (strcmp(objProcLstStp[procIdx].procName, newOptiProc) == 0)
                    {
                        if (objProcLstStp[procIdx].optiIdx == NullOpti)  /* DLA - PMSTA-27514 - 170619 */
                        {                        // add the new details from opti_prof_compo
                            objProcLstStp[procIdx].optiIdx = (DBA_OPTI_ENUM)i;//Opti_Sel_S_CalendarDate_ByCId;//new name of optimization

                            objProcLstStp[procIdx].optiIdx = (DBA_OPTI_ENUM)(tabIdx + newOptiCompoNbr);//Opti_Sel_S_CalendarDate_ByCId;//new name of optimization

                            EV_OptiPtr[tabIdx + newOptiCompoNbr].dataPtr        = nullptr;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].inputArgNbr    = 0;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].outputFldNbr   = 0;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].strArgFlg      = FALSE;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].currentReadNbr = 0;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].eltNbr         = 0;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].allocNbr       = 0;
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].allocBloc      = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalAlloc);
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].maxAllocNbr    = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalMaxAlloc);
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].locAllocBloc   = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalAlloc);
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].locMaxAllocNbr = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalMaxAlloc);
                            EV_OptiPtr[tabIdx + newOptiCompoNbr].procPtr        = nullptr; 
                           
                            if ((sOptiProc = ALLOC_DYNST(S_OptiProc)) == nullptr)
                            {
                                DBA_FreeDynStTab(optiCompoTab, optiCompoNbr, A_OptiProfCompo);
                                FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
                                MSG_RETURN(RET_MEM_ERR_ALLOC);
                            }
                            //get the entity name from opti_proc
                            SET_STRING(sOptiProc, S_OptiProc_SqlName, newOptiProc);

                            if (DBA_Get2(OptiProc, UNUSED, S_OptiProc,
                                sOptiProc, S_OptiProc, &sOptiProc,
                                UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                            {
                                DBA_FreeDynStTab(optiCompoTab, optiCompoNbr, A_OptiProfCompo);
                                FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
                                FREE_DYNST(sOptiProc, S_OptiProc);
                                return(RET_DBA_ERR_NODATA);
                            }
                            DBA_GetObjectEnum(GET_DICT(sOptiProc, S_OptiProc_EntityDictId), &entObj);
                            FREE_DYNST(sOptiProc, S_OptiProc);

                            if ((EV_OptiPtr[tabIdx + newOptiCompoNbr].objLst = (OBJECT_ENUM *)CALLOC(2, sizeof(OBJECT_ENUM))) != nullptr)
                            {
                                EV_OptiPtr[tabIdx + newOptiCompoNbr].objLst[0] = entObj;
                                EV_OptiPtr[tabIdx + newOptiCompoNbr].objLst[1] = NullEntity;
                                if ((dictEntityStp = DBA_GetDictEntitySt(entObj)) != nullptr &&
                                    dictEntityStp->changeSetAuthEn == FeatureAuth_Enable)
                                {
                                    EV_OptiPtr[tabIdx + newOptiCompoNbr].useShadowTableFlg = TRUE;
                                }
                                else
                                {
                                    EV_OptiPtr[tabIdx + newOptiCompoNbr].useShadowTableFlg = FALSE;
                                }
                                DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(EV_OptiPtr[i].objLst[0]);
                                if (dictEntityPtr != nullptr)
                                {
                                    /* PMSTA-24030 - DDV - 161220 - If data life cycle management is active on this entity, update checkDlmeMaxFlg. Later it may be based on dict_sproc content */
                                    if (dictEntityPtr->dlmAuthEn == FeatureAuth_Enable)
                                        EV_OptiPtr[i].checkDlmeMaxFlg = TRUE;

                                    /* PMSTA-24030 - DDV - 161220 - If entity is secured, add check on data_profile. Later it may be based on dict_sproc content */
                                    if (dictEntityPtr->securityLevelEn != EntSecuLevel_NoSecured)
                                        EV_OptiPtr[i].checkDataProfileFlg = TRUE;

                                    /* PMSTA-26108 - 170929 - DDV */
                                    if (dictEntityPtr->isMultiBusinessEntityManagement())
                                        EV_OptiPtr[i].checkBusinessEntityFlg = TRUE;
                                }
                            }

                            EV_OptiPtr[tabIdx + newOptiCompoNbr].globalLock = SYS_CreateRWLock(FILEINFO);
                            newOptiCompoNbr++;
                        }
                        else    /* DLA - PMSTA-27514 - 170619 */
                        {
                            EV_OptiPtr[objProcLstStp[procIdx].optiIdx].allocBloc = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalAlloc);
                            EV_OptiPtr[objProcLstStp[procIdx].optiIdx].maxAllocNbr = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalMaxAlloc);
                            EV_OptiPtr[objProcLstStp[procIdx].optiIdx].locAllocBloc = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalAlloc);
                            EV_OptiPtr[objProcLstStp[procIdx].optiIdx].locMaxAllocNbr = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalMaxAlloc);
                        }
                    }
                }
            }
        }
    }

	/* PMSTA-53404 - AAKASH - 15-06-2023 : Loop on EV_OptiPtr to change all lines with OptiForbidden to set them with NullOpti. */
    for (OBJECT_ENUM objIdx = 0; objIdx <= LASTOBJECT; objIdx++)
    {
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(objIdx);
        if (objProcLstStp != nullptr)
        {
            for (procIdx = 0; objProcLstStp[procIdx].action != NullAction; procIdx++)
            {
                if (objProcLstStp[procIdx].optiIdx == OptiForbidden)
                {
                    objProcLstStp[procIdx].optiIdx = NullOpti;
                }
            }
        }
    }

    EV_NewOptiListSize += newOptiCompoNbr;
    DBA_FreeDynStTab(optiCompoTab, optiCompoNbr, A_OptiProfCompo);
    FREE_DYNST(SV_ServConnectRecord, A_ServConnect);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_InitOptiArgInfo()
**
**  Description :   Init default information on optimisation
**
**  Arguments   :   procPtr    optimised procedure pointer
**                  optiMode   optimisation mode, used for locking
**              - Opti_Local  optimisation structure is local
**              - Opti_Global optimisation structure is global
**                  optiPtr    pointer on optimisation structure to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Last Modif  : 18.11.96 - PEC - Ref.: DVP255
**                02.01.97 - PEC - Ref.: DVP312
**                PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**
*************************************************************************/
STATIC RET_CODE DBA_InitOptiArgInfo(DBA_PROC_STP      procPtr,
    DBA_OPTIMODE_ENUM optiMode,
    DBA_OPTI_STP      optiPtr)
{
    DBA_PROCPARAM_STP procParam;
    char              strArgFlg = FALSE;
    int               inputArgNbr = 0;
    procParam = procPtr->procParamDefPtr;

    /* DDV - 990721 - REF3447 */
    if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        if (optiMode == Opti_Global &&
            (procPtr->optiIdx == Opti_A_ApplUser_ById ||
             procPtr->optiIdx == Opti_A_ApplUser_ByCd ||
             procPtr->optiIdx == Opti_S_ApplUser_ById ||
             procPtr->optiIdx == Opti_S_ApplUser_ByCd))
        {
            optiPtr->allocBloc = 0;
            optiPtr->maxAllocNbr = 0;
        }

        /* PMSTA12765 - DDV - 1109272 - If dependence exists on secured entity, then invalid  global cache (set maxAllocBloc to 0) */
        if (optiMode == Opti_Global && optiPtr->maxAllocNbr != 0 && FALSE)
        {
            int i = 0;
            while (optiPtr->objLst[i] != NullEntity)
            {
                DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(optiPtr->objLst[i]);
                if (dictEntityPtr != nullptr && dictEntityPtr->securityLevelEn != EntSecuLevel_NoSecured)
                {

                    optiPtr->allocBloc = 0;
                    optiPtr->maxAllocNbr = 0;

                    return(RET_SUCCEED);
                }
                i++;
            }
        }
    }


    /* Count input arguments number, and init input string flag */
    /* DVP312 */
    if (procParam != nullptr)
    {
        while (procParam[inputArgNbr].paramName[0] != END_OF_STRING)
        {
            /* Test if, at least, one argument is a string field */
            if (IS_STRINGFLD(*(procPtr->inputDynStPtr), *(procParam[inputArgNbr].fldNbrPtr)) == TRUE ||
                IS_USTRINGFLD(*(procPtr->inputDynStPtr), *(procParam[inputArgNbr].fldNbrPtr)) == TRUE) /* REF8844 - LJE - 030410 */
                strArgFlg = TRUE;

            /* Update argument number */
            ++inputArgNbr;
        }
    }
    /* DVP312 */

    /* Update optimisation informations */
    if (procPtr->action == Select) /* DVP255 */
    {
        optiPtr->outputFldNbr = GET_FLD_NBR(Select_Res_Tab);
        optiPtr->outputDynSt = Select_Res_Tab; /* REF8844 - LJE - 030408 */
    }
    else
    {
        optiPtr->outputFldNbr = GET_FLD_NBR(*(procPtr->outputDynStPtr));
        optiPtr->outputDynSt = *(procPtr->outputDynStPtr); /* REF8844 - LJE - 030408 */
    }

    optiPtr->inputArgNbr = inputArgNbr;
    optiPtr->strArgFlg = strArgFlg;
    optiPtr->procPtr = procPtr;

    return(RET_SUCCEED);
}

/************************************************************************
*
*   Function      : DBA_ReadOpti()
*
*   Description   : Search in array element which correspond to input
*                   arguments.
*                   Always use the begin address because it can be
*                   modified by an memory update (for global access).
*
*   Arguments     : procPtr    optimised procedure pointer
*                   optiMode   optimisation mode
*                   in server mode :
*               - Opti_Local       search in local only
*               - Opti_Global      search in global only
*               - Opti_LocalGlobal search in local and then in global by
*                                      call DBA_ReadOpti() itself with
*                                      Opti_GlobalLocal mode
*               - Opti_GlobalLocal search in global after an unsuccessed
*                                      local search
*                   inPtr      pointer on dynamic structure which contains
*                              input arguments
*                   outPtr     pointer on dynamic structure to fill, or NULL
*                   outPtrPtr  pointer on dynamic structure pointer, updated
*                              only with local pointer (used by DBA_GetMemory())
*                   posIndexLocal: position to insert in index if data is not in the local cache
*                   posIndexGlobal: position to insert in index if data is not in the global cache
*
*   Return        : RET_SUCCEED             if found
*                   RET_DBA_INFO_NODATAOPTI if nothing found in memory
*                   RET_DBA_INFO_NODATA     if found that data don't exist
*                   error code              if problem
*
*   Creation Date : 28.12.94 - RAK
*   Last Modif.   : 07.06.95 - PEC - added service thread handling
*                                  by a call to SERV_GetOptiPtr
*                 : 10.07.95 - RAK - new argument outPtrPtr
*                 : 27.07.95 - PEN - Bug ... bad returned data
*                 : 19.11.96 - PEC - Ref.: DVP255
*                 : 31.12.96 - PEC - Ref.: DVP314
*                 : ROI - 981202 - REF2644
*                 : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*                   PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
RET_CODE DBA_ReadOpti(DBA_PROC_STP      procPtr,
    DBA_OPTIMODE_ENUM optiMode,
    DBA_DYNFLD_STP    inPtr,
    DBA_DYNFLD_STP    outPtr,
    DBA_DYNFLD_STP *  outPtrPtr,
    int *             posIndexLocal,
    int *                   posIndexGlobal,
    DbiConnectionHelper *   dbiConnHelper)
{
    DBA_PROC_STP               proc = procPtr;
    DBA_PROCPARAM_STP          procParam = nullptr;
    DBA_OPTI_STP               optiPtr = nullptr;
    int                        firstOut, firstIn;
    unsigned int              nb;
    RET_CODE                   ret = RET_DBA_INFO_NODATAOPTI;
    DBA_DYNFLD_STP eltFound = nullptr;
    int recFound;

    /* PMSTA-23385 - LJE - 160711 */
    if (EV_OptiPtr == nullptr)
        return (RET_DBA_INFO_NODATAOPTI);

    if (TRUE == SYS_IsGuiMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        DBA_VerifOptiTab(dbiConnHelper);
    }

    if (SYS_IsSrvMode())
    {
        if (!SERV_StartedServer())
            return (RET_DBA_INFO_NODATAOPTI);
    }

    /***** BEGIN ------ PEN GRD checkFlg process *****/
    if (proc == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_WriteOpti", "procParam");
        return(RET_GEN_ERR_INVARG);
    }
    /***** END   ------ PEN GRD checkFlg process *****/

    procParam = proc->procParamDefPtr;

    /**** DVP314 ****/
    if (procParam == nullptr && proc->action != Select)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_ReadOpti", "procParam");
        return(RET_GEN_ERR_INVARG);
    }

    if (SYS_IsSrvMode())
    {
        if (optiMode == Opti_Local || optiMode == Opti_LocalGlobal)
        {
            /* Get the pointer on optimized data */
            if (SERV_GetOptiPtr(procPtr, &optiPtr) != TRUE)
            {
                return(RET_DBA_ERR_OPTI);
            }
        }
        else
        {
            optiPtr = EV_OptiPtr + (proc->optiIdx);
        }
    }
    else
    {
        optiPtr = EV_OptiPtr + (proc->optiIdx);
    }

    {
        LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, (FALSE == SYS_IsSrvMode()) || (optiMode != Opti_Local && optiMode != Opti_LocalGlobal), FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

        /* PMSTA-262520 - Disable optimisation when proc use shdow table and a change_set is active */
        if (optiPtr->useShadowTableFlg == TRUE && DBA_GetApplSessionChangeSetId() != 0)
        {
            return (RET_DBA_INFO_NODATAOPTI);
        }

        if (optiPtr->nbCall < ACCESSNBMAX) /* to be sure that nb is not set to 0 */
            optiPtr->nbCall++;

        /* Nothing in memory */
        if (optiPtr->dataPtr == nullptr)
        {
#ifdef AAATIMER
            EV_UnsucLocSeek++;
#endif
            /* Search in global after an unsuccessed local search. */
            if (optiMode == Opti_LocalGlobal)
            {
                /* BUG205 GRD/PEN (13/11/1996) */
                if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
                {
                    ret = DBA_ReadOpti(proc, Opti_GlobalLocal, inPtr, outPtr, outPtrPtr, posIndexLocal, posIndexGlobal);
                }
                else
                {
                    ret = RET_DBA_INFO_NODATAOPTI;
                }

                return(ret);
            }
            else
            {
#ifdef AAATIMER
                EV_UnsucGloSeek++;
#endif
                return(RET_DBA_INFO_NODATAOPTI);
            }
        }

        /* ------------------------------------------------------------------ */
        /* In stored array 1 record =                                         */
        /*    1 for access number +                                           */
        /*    1 for time stamp +                                              */
        /*    1 for main dlm_e max +                                          */
        /*    1 for add. dlm_e max +                                          */
        /*    1 for check data_profile flag +                                 */
        /*    x (stored in optimisation) for input argument +                 */
        /*    x (stored in optimisation) for output field number              */
        /*                                                                    */
        /* We must always use the begin address because it can be             */
        /* modified by an memory update (for global access). So we use        */
        /* optiPtr->dataPtr + idx for read the access number                  */
        /* optiPtr->dataPtr + idx + firstIn + argPos for read one input field */
        /* optiPtr->dataPtr + idx + firstOut + x for read x output field      */
        /* ------------------------------------------------------------------ */
        firstIn = Opti_FirstIn;
        firstOut = firstIn + optiPtr->inputArgNbr;
        int fldNbr = firstOut + optiPtr->outputFldNbr;

        optiPtr->currentReadNbr++;

        if ((optiPtr->inputArgNbr > 0) && (inPtr != nullptr))
        {
            if (optiMode == Opti_GlobalLocal || optiMode == Opti_Global)
            {
                recFound = DBA_SearchElmtInIndexOpti(optiPtr, proc, inPtr, posIndexGlobal, FALSE);
            }
            else
            {
                recFound = DBA_SearchElmtInIndexOpti(optiPtr, proc, inPtr, posIndexLocal, FALSE);
            }
        }
        else if (optiPtr->eltNbr > 0)
        {
            recFound = 0;           /* first element */
        }
        else
        {
            recFound = -1;

        }

        if (recFound >= 0)
        {
            eltFound = optiPtr->dataPtr + (recFound * fldNbr);

            if (outPtrPtr != nullptr)
            {
                *outPtrPtr = eltFound + firstOut;
            }

#ifdef AAATIMER
            if (optiMode == Opti_GlobalLocal || optiMode == Opti_Global)
                EV_SucGloSeek++;
            else
                EV_SucLocSeek++;
#endif

            /* Read Opti_AccessNbr */
            nb = GET_UINT(eltFound, Opti_AccessNbr);

            /* In local mode, it can be 0 if element didn't */
            /* exist in database when searching and was     */
            /* stored like NULL.                            */
            if (nb == 0)
            {
                ret = RET_DBA_INFO_NODATA;

                if (optiMode == Opti_GlobalLocal && outPtr != nullptr)
                {
                    DATE_START_TIMER(11, TIMER_MASK_SQLC);
                    DBA_WriteOpti(proc, Opti_Local, inPtr, nullptr, FALSE, *posIndexLocal, *posIndexGlobal);
                    DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
                }

                SET_UINT(eltFound, Opti_TimeStamp, optiPtr->nbCall);
            }
            else
            {
                ret = RET_SUCCEED;
                if (outPtr != nullptr)
                {
                    /* Update Opti_AccessNbr */
                    if (nb < ACCESSNBMAX) /* to be sure that nb is not set to 0 */
                        nb += 1;
                    SET_UINT(eltFound, Opti_AccessNbr, nb);
                    SET_UINT(eltFound, Opti_TimeStamp, optiPtr->nbCall);

                    /**** BEGIN DVP255 ***/
                    if (proc->action == Select)
                    {
                        DBA_DYNFLD_STP outOptiStruct = nullptr;
                        DBA_DYNFLD_STP *optiData = nullptr;
                        DBA_DYNST_ENUM dataTp;
                        int            dataNbr = 0;

                        outOptiStruct = eltFound + firstOut;

                        optiData = GET_EXTENSION_PTR(outOptiStruct, Select_Res_Tab_DataTab);
                        dataTp = GET_EXTENSION_TP(outOptiStruct, Select_Res_Tab_DataTab);
                        dataNbr = GET_EXTENSION_NBR(outOptiStruct, Select_Res_Tab_DataTab);

                        SET_EXTENSION(outPtr,
                            Select_Res_Tab_DataTab,
                            optiData,
                            dataTp,
                            dataNbr);

                    }
                    else
                    {
                        if (COPY_DYNST_DISDOMTRACE(outPtr, eltFound + firstOut, *(proc->outputDynStPtr)) == FALSE)  /* PMSTA-23209 - DDV - 160622 */
                        {
                            ret = RET_DBA_ERR_OPTI;
                        }
                    }
                    if ((ret == RET_SUCCEED) && (optiMode == Opti_GlobalLocal))
                    {
                        DATE_START_TIMER(11, TIMER_MASK_SQLC);
                        DBA_WriteOpti(proc, Opti_Local, inPtr, outPtr, FALSE, *posIndexLocal, *posIndexGlobal);
                        DATE_STOP_TIMER(11, TIMER_MASK_SQLC);
                    }
                }
            }
            optiPtr->cacheHint++;
            optiPtr->cacheHit++; /* REF11767 - CHU - 060403 */
        }
        else
        {
            optiPtr->cacheMiss++; /* REF11767 - CHU - 060403 */

#ifdef AAATIMER
            if (optiMode == Opti_GlobalLocal || optiMode == Opti_Global)
                EV_UnsucGloSeek++;

            if (optiMode == Opti_Local)
                EV_UnsucLocSeek++;
#endif
        }

        (optiPtr->currentReadNbr)--;

    }

    /* Search in global after an unsuccessed local search. */
    /* In case of error no search.                         */
    /* BUG205 GRD/PEN (13/11/1996) */
    if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        if (eltFound == nullptr && optiMode == Opti_LocalGlobal)
        {
            ret = DBA_ReadOpti(proc, Opti_GlobalLocal, inPtr, outPtr, nullptr, posIndexLocal, posIndexGlobal);
        }
    }

    return(ret);
}

/************************************************************************
*
*   Function      : DBA_WriteOpti()
*
*   Description   : Write in array new element.
*
*   Arguments     : procPtr    optimised procedure pointer
*                   optiMode   optimisation mode
*                   in server mode :
*               - Opti_Local       write in local only
*               - Opti_Global      write in global only
*               - Opti_LocalGlobal write in local and then global (used ??)
*               - Opti_GlobalLocal write in global and then in local by
*                                      calling DBA_WriteOpti() itself with
*                                      mode Opti_Local.
*                   inPtr      pointer on dynamic structure which contains
*                              input arguments for copy
*                   resultPtr  pointer on output dynamic structure for copy
*                              it can be NULL if we want stored that informa-
*                              tion don't exist.
*           checkFlg   (PEN GRD 11/11/96) If record already exists in cache
*               then re-write
*                   posIndexLocal: >= 0 , position to insert the pointer in local index
*                                  = -1 not specified
*                   posIndexGLobal: >= 0 , position to insert the pointer in global index
*                                  = -1 not specified
*
*   Return        : RET_SUCCEED or error code
*
*   Creation Date : 28.12.94 - RAK
*
*   Last Modif.   : 07.06.95 - PEC - added service thread handling
*                                  by a call to SERV_GetOptiPtr
*                   05.11.96 - PEC - Ref.: DVP236
*                   19.11.96 - PEC - Ref.: DVP255
*                   31.12.96 - PEC - Ref.: DVP314
*                   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*                   PMSTA-20089 - 041015 - PMO : Once unified, remove the usage of CORBA conditional code
*
*************************************************************************/
RET_CODE DBA_WriteOpti(DBA_PROC_STP      procPtr,
    DBA_OPTIMODE_ENUM optiMode,
    DBA_DYNFLD_STP    inPtr,
    DBA_DYNFLD_STP    resultPtr,
    FLAG_T            checkFlg,
    int               posIndexLocal,
    int               posIndexGlobal)
{
    DBA_PROC_STP               proc = nullptr;
    DBA_PROCPARAM_STP          procParam = nullptr;
    DBA_OPTI_STP               optiPtr = nullptr;
    int                        fldNbr, firstOutFld, firstInFld, argPos;
    DBA_DYNFLD_STP             dataPtr = nullptr;
    int positionInIndex = -1;
    RET_CODE                   ret;
    DBA_DYNFLD_STP dynStp;
    int recNo;
    int i;

    /*  HFI-PMSTA-22222-160122  GUI crash because of log message in DBA_CompleteMetaDict    */
    /* PMSTA-23385 - LJE - 160711 */
    if (EV_OptiPtr == nullptr)
        return (RET_DBA_INFO_NODATAOPTI);

    static FLAG_T          firstTimeFlg = TRUE;
    static DBA_PROC_STP    localProcPtrTab[2];  /* [0]  INP=S_Instr  OUT=S_Instr get_sh_instrument_by_cd_cid */
    /* [1]  INP=S_Ptf    OUT=S_Ptf   get_sh_portfolio_by_cd_cid  */

    if (SYS_IsSrvMode())
    {
        if (!SERV_StartedServer())
            return RET_SUCCEED; /* DDV - 151007 - If server is not started or if it generator return RET_SUCCEED instead of NULL */
    }
    /***** EN MODE "BATCH" : NE PAS OPTIMISER LES get_... QUI RETOURNENT NULL - DLA - REF8880 - 030319 - ok, mais pas sur les entit?s non impact?es */

    if (SYS_IsBatchMode() == TRUE && resultPtr == nullptr && SV_EntityTabNb > 0)
    {
        int j;
        OBJECT_ENUM obj;
        const char * sqlname_c;

        DBA_GetObjectEnumByDynSt(*(procPtr->outputDynStPtr), &obj);
        sqlname_c = DBA_GetDictEntitySqlName(obj);

        for (j = 0; j<SV_EntityTabNb; j++)
        {
            if (obj == NullEntity || strcmp(SV_EntityTab[j], sqlname_c) == 0)
                return(RET_SUCCEED);
        }
    }

    /***** OPTI (pen) 15/11/96 *****/
    if (firstTimeFlg == TRUE)
    {
        DBA_DYNFLD_STP  sInstrSt = ALLOC_DYNST(S_Instr);
        DBA_DYNFLD_STP  sPtfSt = ALLOC_DYNST(S_Ptf);
        const char *    pszTest = "Test"; /* REF7264 - PMO */
        ID_T            id = 1;

        firstTimeFlg = FALSE;

        /***** get_sh_instrument_by_cd_cid *****/
        SET_CODE(sInstrSt, S_Instr_Cd, pszTest);
        SET_ID(sInstrSt, S_Instr_CodifId, id);
        localProcPtrTab[0] = DBA_GetStoredProcs(Get, Instr, UNUSED, S_Instr, sInstrSt, S_Instr);
        FREE_DYNST(sInstrSt, S_Instr);

        /***** get_sh_portfolio_by_cd_cid *****/
        SET_CODE(sPtfSt, S_Ptf_Cd, pszTest);
        SET_ID(sPtfSt, S_Ptf_CodifId, id);
        localProcPtrTab[1] = DBA_GetStoredProcs(Get, Ptf, UNUSED, S_Ptf, sPtfSt, S_Ptf);
        FREE_DYNST(sPtfSt, S_Ptf);
    }

    /***** BEGIN ------ PEN GRD checkFlg process *****/
    if ((proc = (DBA_PROC_STP)procPtr) == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_WriteOpti", "procParam");
        return(RET_GEN_ERR_INVARG);
    }
    /***** END   ------ PEN GRD checkFlg process *****/

    procParam = proc->procParamDefPtr;

    /**** DVP314 ****/
    if (procParam == nullptr && proc->action != Select)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_WriteOpti", "procParam");
        return(RET_GEN_ERR_INVARG);
    }

    /***** OPTI (pen) 15/11/96 *****/
    /* PMSTA-17249 - DDV - 140205 - As we don't know if it is the code or the synonym that has been returned, optimisation is valid only when codif_id is null */
    if (proc == localProcPtrTab[0] && resultPtr != nullptr && IS_NULLFLD(inPtr, S_Instr_CodifId) == TRUE)
    {
        DBA_PROC_STP    localProc = nullptr;
        DBA_DYNFLD_STP  admArgSt = ALLOC_DYNST(Adm_Arg);

        SET_ID(admArgSt, Adm_Arg_Id, GET_ID(resultPtr, S_Instr_Id));
        SET_ID(admArgSt, Adm_Arg_CodifId, GET_ID(resultPtr, S_Instr_CodifId)); /* DLA - REF8668 - 030108 */
        localProc = DBA_GetStoredProcs(Get, Instr, UNUSED, Adm_Arg, admArgSt, S_Instr);

        if (localProc != nullptr && admArgSt != nullptr && resultPtr != nullptr)
            DBA_WriteOpti(localProc,
            (optiMode == Opti_Local || optiMode == Opti_LocalGlobal) ? Opti_Local : Opti_Global,
            admArgSt,
            resultPtr,
            TRUE, -1, -1);
        FREE_DYNST(admArgSt, Adm_Arg);
    }
    else
        /* PMSTA-17249 - DDV - 140205 - As we don't know if it is the code or the synonym that has been returned, optimisation is valid only when codif_id is null */
        if (proc == localProcPtrTab[1] && resultPtr != nullptr && IS_NULLFLD(inPtr, S_Ptf_CodifId) == TRUE)
        {
            DBA_PROC_STP    localProc = nullptr;
            DBA_DYNFLD_STP  admArgSt = ALLOC_DYNST(Adm_Arg);

            SET_ID(admArgSt, Adm_Arg_Id, GET_ID(resultPtr, S_Ptf_Id));
            SET_ID(admArgSt, Adm_Arg_CodifId, GET_ID(resultPtr, S_Ptf_CodifId)); /* DLA - REF8668 - 030108 */
            localProc = DBA_GetStoredProcs(Get, Ptf, UNUSED, Adm_Arg, admArgSt, S_Ptf);

            if (localProc != nullptr && admArgSt != nullptr && resultPtr != nullptr)
                DBA_WriteOpti(localProc,
                (optiMode == Opti_Local || optiMode == Opti_LocalGlobal) ? Opti_Local : Opti_Global,
                admArgSt,
                resultPtr,
                TRUE, -1, -1);

            FREE_DYNST(admArgSt, Adm_Arg);
        }

    if (SYS_IsSrvMode())
    {
        DBA_DYNFLD_STP checkPtr = nullptr;
        RET_CODE checkRet;

        if (optiMode == Opti_Local || optiMode == Opti_LocalGlobal)
        {
            /* Get the  pointer on optimized data */
            if (SERV_GetOptiPtr(procPtr, &optiPtr) != TRUE)
            {
                return(RET_DBA_ERR_OPTI);
            }

            /***** BEGIN ------ PEN GRD checkFlg process *****/
            if (checkFlg == TRUE)
            {
                checkRet = DBA_ReadOpti(proc, Opti_Local, inPtr, nullptr, &checkPtr, &posIndexLocal, &posIndexGlobal);

                switch (checkRet)
                {
                case RET_SUCCEED:
                case RET_DBA_INFO_NODATA:
                    if (checkPtr != nullptr)
                    {
                        DBA_DYNFLD_STP idxPtr = nullptr;

                        /***** FREE CURRENT REC IN CACHE *****/
                        DBA_FreeDynSt(checkPtr, *(proc->outputDynStPtr));

                        /***** BUG366 BEGIN PEN 970507 *****/
                        memset(checkPtr, 0, (GET_FLD_NBR(*(proc->outputDynStPtr)) * sizeof(DBA_DYNFLD_ST)));
                        /***** BUG366 END   PEN 970507 *****/

                        if (resultPtr != nullptr)
                        {
                            COPY_DYNST_DISDOMTRACE(checkPtr, resultPtr, *(proc->outputDynStPtr));  /* PMSTA-23209 - DDV - 160622 */
                        }

                        idxPtr = checkPtr - (optiPtr->inputArgNbr + Opti_FirstIn);
                        SET_UINT(idxPtr, Opti_AccessNbr, 1);
                        SET_UINT(idxPtr, Opti_TimeStamp, optiPtr->nbCall);
                        return(RET_SUCCEED);
                    }
                    break;

                case RET_DBA_INFO_NODATAOPTI:
                default:
                    break;
                }
            }
            /***** END   ------ PEN GRD checkFlg process *****/
        }
        else
        {
            optiPtr = EV_OptiPtr + (proc->optiIdx);

            /***** BEGIN ------ PEN GRD checkFlg process *****/

            if (checkFlg == TRUE)
            {
                checkRet = DBA_ReadOpti(proc, Opti_Global, inPtr, nullptr, &checkPtr,
                    &posIndexLocal, &posIndexGlobal);

                switch (checkRet)
                {
                case RET_SUCCEED:
                case RET_DBA_INFO_NODATA:
                    if (checkPtr != nullptr)
                    {
                        {
                            /* DLA - PMSTA00222 - 060831 */
                            LockGuard lock(optiPtr->globalLock, LockGuard::Access::write, (optiMode == Opti_Global || optiMode == Opti_GlobalLocal), FILEINFO);
                            /***** FREE CURRENT REC IN CACHE *****/
                            DBA_FreeDynSt(checkPtr, *(proc->outputDynStPtr));

                            /***** BUG366 BEGIN PEN 970507 *****/
                            memset(checkPtr, 0, (GET_FLD_NBR(*(proc->outputDynStPtr)) * sizeof(DBA_DYNFLD_ST)));
                            /***** BUG366 END   PEN 970507 *****/

                            if (resultPtr != nullptr)
                            {
                                COPY_DYNST_DISDOMTRACE(checkPtr, resultPtr, *(proc->outputDynStPtr));  /* PMSTA-23209 - DDV - 160622 */
                            }

                            DBA_DYNFLD_STP idxPtr = checkPtr - (optiPtr->inputArgNbr + Opti_FirstIn);
                            SET_UINT(idxPtr, Opti_AccessNbr, 1);
                            SET_UINT(idxPtr, Opti_TimeStamp, optiPtr->nbCall);

                        }

                        if (optiMode == Opti_GlobalLocal)
                        {
                            DBA_WriteOpti(procPtr, Opti_Local, inPtr, resultPtr, checkFlg, posIndexLocal, posIndexGlobal);
                        }

                        return(RET_SUCCEED);
                    }
                    break;

                case RET_DBA_INFO_NODATAOPTI:
                default:
                    break;
                }
            }
            /***** END   ------ PEN GRD checkFlg process *****/
        }
    }
    else
    {
        optiPtr = EV_OptiPtr + (proc->optiIdx);
    }

    {
        LockGuard lock(optiPtr->globalLock, LockGuard::Access::write, (FALSE == SYS_IsSrvMode()) || ((optiPtr->allocBloc > 0) && (optiMode == Opti_Global || optiMode == Opti_GlobalLocal)), FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

        /* PMSTA-262520 - Disable optimisation when proc use shdow table and a change_set is active */
        if (optiPtr->useShadowTableFlg == TRUE && DBA_GetApplSessionChangeSetId() != 0)
        {
            return (RET_SUCCEED);
        }

        /* BEGIN DVP531 - PEC - 970701 */
        if (optiPtr->allocBloc > 0)
        {
            /* If nothing in memory, allocation and information initialisation */
            if (optiPtr->dataPtr == nullptr)
            {
                /* Update argument informations */                               /****** DVP531 ******/
                if (optiMode == Opti_Global || optiMode == Opti_GlobalLocal)
                {
                    if ((ret = DBA_InitOptiArgInfo(proc, Opti_Global, optiPtr)) != RET_SUCCEED)
                    {
                        return(ret);
                    }

                    /* DDV - 990721 - REF3447 */

                    if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
                    {
                        if (optiPtr->allocBloc == 0)
                        {
                            lock.unlock(); /* REF7264 - PMO */
                            /* Init local memory too */
                            if (optiMode == Opti_GlobalLocal)
                            {
                                return(DBA_WriteOpti(proc, Opti_Local, inPtr, resultPtr, checkFlg, posIndexLocal, posIndexGlobal));
                            }
                            else
                            {
                                return(ret); /* REF3857 - 990730 - DDV */
                            }
                        }
                    }
                }
                else
                {
                    /* In local mode, search if information exist in global */
                    if (EV_OptiPtr[proc->optiIdx].outputFldNbr == 0)
                    {
                        if ((ret = DBA_InitOptiArgInfo(proc, Opti_Local, optiPtr)) != RET_SUCCEED)
                        {
                            return(ret);
                        }
                    }
                    else
                    {
                        /* copy global informations */
                        optiPtr->inputArgNbr = EV_OptiPtr[proc->optiIdx].inputArgNbr;
                        optiPtr->strArgFlg = EV_OptiPtr[proc->optiIdx].strArgFlg;
                        optiPtr->outputFldNbr = EV_OptiPtr[proc->optiIdx].outputFldNbr;
                        optiPtr->procPtr = EV_OptiPtr[proc->optiIdx].procPtr;
                    }
                }

                fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

                /* REF7264 - PMO */
                if ((optiPtr->dataPtr = (DBA_DYNFLD_STP)CALLOC(optiPtr->allocBloc, fldNbr * sizeof(DBA_DYNFLD_ST))) == nullptr)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                /* REF7264 - PMO */
                if ((optiPtr->optiIndex = (int*)CALLOC(optiPtr->allocBloc, sizeof(int))) == nullptr)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                optiPtr->allocNbr = optiPtr->allocBloc;
                recNo = 0;
                positionInIndex = 0;
            }
            else
            {

                fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

                /* REF5506 SME 11/12/2000 */
                /* find position to insert  in index */

                if (optiMode == Opti_Global || optiMode == Opti_GlobalLocal)
                {
                    positionInIndex = posIndexGlobal;
                }
                else
                {
                    positionInIndex = posIndexLocal;
                }

                /* PMSTA08106 - DDV - 090422 - If position is out of array, set it in the last cell */
                if (positionInIndex >= (int)optiPtr->eltNbr)
                    positionInIndex = (int)optiPtr->eltNbr - 1;

                if ((optiPtr->inputArgNbr > 0) && (inPtr != nullptr))
                {
                    if ((positionInIndex >= 0) && (positionInIndex < (int)optiPtr->eltNbr))
                    {
                        if (positionInIndex < (int)optiPtr->eltNbr)
                        {
                            /* collapse the fields */

                            /* REF7264 - PMO */
                            DBA_DYNFLD_STP inPtr2 = (DBA_DYNFLD_STP)CALLOC(optiPtr->inputArgNbr, sizeof(DBA_DYNFLD_ST));
                            for (i = 0; i < optiPtr->inputArgNbr; i++)
                            {
                                memcpy(inPtr2 + i, inPtr + *(proc->procParamDefPtr[i].fldNbrPtr), sizeof(DBA_DYNFLD_ST));
                                inPtr2[i].dynStEnum = (short)NullDynSt; /* PMSTA-2026108 - DDV - 171002 */
                            }

                            dynStp = optiPtr->dataPtr + (optiPtr->optiIndex[positionInIndex] * fldNbr);
                            int cmp = DBA_CmpAllInputArg(inPtr2, dynStp, optiPtr, proc, FALSE);  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
                            if (cmp == 0)
                            {
                                /* data already optimised */
                                FREE(inPtr2);
                                return RET_SUCCEED;
                            }
                            if (cmp > 0)
                            {
                                while ((++positionInIndex < (int)optiPtr->eltNbr) &&
                                    ((cmp = DBA_CmpAllInputArg(inPtr2,
                                    optiPtr->dataPtr + (optiPtr->optiIndex[positionInIndex] * fldNbr),
                                    optiPtr, proc, FALSE)) > 0));  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
                                if (cmp == 0)
                                {
                                    /* data already optimised */
                                    FREE(inPtr2);
                                    return RET_SUCCEED;
                                }
                            }
                            else
                            {
                                while ((--positionInIndex >= 0) &&
                                    ((cmp = DBA_CmpAllInputArg(inPtr2, optiPtr->dataPtr + (optiPtr->optiIndex[positionInIndex] * fldNbr),
                                    optiPtr, proc, FALSE)) < 0));  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
                                positionInIndex++;
                                if (cmp == 0)
                                {
                                    /* data already optimised */
                                    FREE(inPtr2);
                                    return RET_SUCCEED;
                                }
                            }
                            FREE(inPtr2);
                        }
                    }
                    else if (positionInIndex < 0)
                    {
                        /* search position to insert in index */
                        int found;

                        found = DBA_SearchElmtInIndexOpti(optiPtr,
                            proc,
                            inPtr,
                            &positionInIndex,
                            FALSE);

                        if (found >= 0)
                        {
                            return RET_SUCCEED;
                        }
                    }
                }
                else
                {
                    positionInIndex = 0;
                }

                /* Verify if allocated memory is suffisant */
                if (optiPtr->eltNbr == optiPtr->allocNbr)
                {
                    /* test maximum */
                    if ((optiPtr->allocNbr + optiPtr->allocBloc) > optiPtr->maxAllocNbr)
                    {
                        /* the cache is full */
                        int oldPosIndex;

                        ret = DBA_GetAFreeCellInOpti(optiPtr, &recNo);

                        if (ret != RET_SUCCEED)
                        {
                            return ret;
                        }

                        if (DBA_SearchElmtInIndexOpti(optiPtr, proc,
                            optiPtr->dataPtr + (recNo * fldNbr),  /* PMSTA-36451 - DDV - 190708 - Give all input information, not only arguments */
                            &oldPosIndex,
                            TRUE) < 0)
                        {
                            return ret;
                        }
                        optiPtr->eltNbr--;
                        if (oldPosIndex < positionInIndex)
                            positionInIndex--;
                        if (oldPosIndex < (int)(optiPtr->eltNbr))
                        {
                            memmove(optiPtr->optiIndex + oldPosIndex,
                                optiPtr->optiIndex + oldPosIndex + 1,
                                (optiPtr->eltNbr - oldPosIndex) * sizeof(int));
                        }
                        dynStp = optiPtr->dataPtr + (recNo * fldNbr) + Opti_FirstIn + optiPtr->inputArgNbr;
                        if (proc->action == Select)
                        {
                            int            eltNbr = 0, j;
                            DBA_DYNST_ENUM out; /* REF7264 - PMO */
                            DBA_DYNFLD_STP *dataTab = nullptr;

                            eltNbr = GET_EXTENSION_NBR(dynStp, Select_Res_Tab_DataTab);
                            dataTab = GET_EXTENSION_PTR(dynStp, Select_Res_Tab_DataTab);
                            out = GET_EXTENSION_TP(dynStp, Select_Res_Tab_DataTab);

                            for (j = 0; j < eltNbr; j++)
                            {
                                FREE_DYNST(dataTab[j], out);
                            }
                            DBA_FreeDynSt(dynStp, Select_Res_Tab);
                        }
                        else
                        {
                            DBA_FreeDynSt(dynStp, *(proc->outputDynStPtr));
                            memset(dynStp, 0, (GET_FLD_NBR(*(proc->outputDynStPtr)) * sizeof(DBA_DYNFLD_ST)));
                        }
                    }
                    else
                    {
                        optiPtr->allocNbr += optiPtr->allocBloc;

                        /* REF7264 - PMO */
                        if ((optiPtr->dataPtr = (DBA_DYNFLD_STP)REALLOC(optiPtr->dataPtr,
                            fldNbr * sizeof(DBA_DYNFLD_ST) *
                            optiPtr->allocNbr)) == nullptr)
                        {
                            MSG_RETURN(RET_MEM_ERR_REALLOC);
                        }

                        memset((char *)(optiPtr->dataPtr) +
                            ((optiPtr->eltNbr) *
                                fldNbr * sizeof(DBA_DYNFLD_ST)),
                            0, (fldNbr * sizeof(DBA_DYNFLD_ST) *
                                optiPtr->allocBloc));


                        /* REF7264 - PMO */
                        if ((optiPtr->optiIndex = (int*)REALLOC(optiPtr->optiIndex, sizeof(int) * optiPtr->allocNbr)) == nullptr)
                        {
                            MSG_RETURN(RET_MEM_ERR_REALLOC);
                        }
                        recNo = optiPtr->eltNbr;
                    }
                }
                else
                {
                    recNo = optiPtr->eltNbr;
                }
            }

            /* Point on next element from the data array */
            firstInFld = Opti_FirstIn;
            firstOutFld = firstInFld + optiPtr->inputArgNbr;
            fldNbr = firstOutFld + optiPtr->outputFldNbr;



            dataPtr = GET_DYNFLDSTP(optiPtr->dataPtr, recNo, fldNbr);

            /* first field is acces number  */
            /* In local mode, init it to 0 if search and not found in database */
            /* For two modes, init it to 1 when found for the first time and   */
            /* copy in memory                                                  */
            if (resultPtr == nullptr)
            {
                SET_UINT(dataPtr, Opti_AccessNbr, 0);
            }
            else
            {
                SET_UINT(dataPtr, Opti_AccessNbr, 1);
            }

            SET_UINT(dataPtr, Opti_TimeStamp, optiPtr->nbCall);

            if (optiPtr->checkDlmeMaxFlg == TRUE)
            {
                DLM_ENUM       mainDlmEMax;
                DLM_ENUM       addDlmEMax;

                mainDlmEMax = DBA_GetConnProviderSessionProperties().getMainDlmEnMax();
                SET_ENUM(dataPtr, Opti_MainDlmEMax, mainDlmEMax);

                addDlmEMax = DBA_GetConnProviderSessionProperties().getAddDlmEnMax();
                SET_ENUM(dataPtr, Opti_AddDlmEMax, addDlmEMax);
            }

            /* DLA - PMSTA-29594 - 171214 */
            DBA_DYNFLD_STP aApplSessionStp = SYS_GetThreadApplSessionStp();
            if (aApplSessionStp)
            {
                if (optiPtr->checkDataProfileFlg == TRUE)
                {
                    SET_ID(dataPtr, Opti_DataProfileId, GET_ID(aApplSessionStp, A_ApplSession_DataProfileId));
                }

                if (optiPtr->checkBusinessEntityFlg == TRUE)
                {

                    SET_ID(dataPtr, Opti_BusinessEntityId, GET_ID(aApplSessionStp, A_ApplSession_ConnectedBusEntityId));
                }
            }

            /* copy input arguments */
            argPos = 0;
            while (argPos < optiPtr->inputArgNbr)
            {
                if (IS_STRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE) /* REF8844 - LJE - 030410 */
                {
                    if (IS_NULLFLD(inPtr, *(procParam[argPos].fldNbrPtr)) == TRUE)
                    {
                        SET_NULL_STRING((&dataPtr[firstInFld]), argPos); /* REF8844 - LJE - 030326 */
                    }
                    else
                    {
                        SET_STRING((&dataPtr[firstInFld]), argPos, GET_STRING(inPtr, *(procParam[argPos].fldNbrPtr)));
                    }
                }
                else
                    if (IS_USTRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                    {
                        if (IS_NULLFLD(inPtr, *(procParam[argPos].fldNbrPtr)) == TRUE)
                        {
                            SET_NULL_USTRING((&dataPtr[firstInFld]), argPos);
                        }
                        else
                        {
                            SET_USTRING((&dataPtr[firstInFld]), argPos, GET_USTRING(inPtr, *(procParam[argPos].fldNbrPtr)));
                        }
                    }
                    else
                    {
                        memcpy(&dataPtr[firstInFld + argPos],
                            &inPtr[*(procParam[argPos].fldNbrPtr)],
                            sizeof(DBA_DYNFLD_ST));
                        dataPtr[firstInFld + argPos].dynStEnum = (short)NullDynSt; /* PMSTA-2026108 - DDV - 171002 */

                    }
                ++argPos;
            }

            /* copy output fields, leave it to null if search and not found */
            /* in database */
            if (resultPtr != nullptr)
            {
                /**** BEGIN DVP255 *****/
                if (proc->action == Select)
                {
                    DBA_DYNFLD_STP *optiDataTab = nullptr;
                    DBA_DYNFLD_STP *dataTab = nullptr;
                    DBA_DYNFLD_STP outputData = nullptr;
                    int            k, eltNbr;
                    DBA_DYNST_ENUM outputDynSt; /* REF7264 - PMO */

                    outputDynSt = GET_EXTENSION_TP(resultPtr, Select_Res_Tab_DataTab);
                    eltNbr = GET_EXTENSION_NBR(resultPtr, Select_Res_Tab_DataTab);
                    outputData = dataPtr + firstOutFld;

                    /* PMSTA-Memory - LJE - 181204 */
                    for (k = 0; k < optiPtr->outputFldNbr; k++)
                    {
                        outputData[k].dynStEnum = Select_Res_Tab;
                    }

                    if (eltNbr == 0)
                    {
                        SET_EXTENSION(outputData,
                            Select_Res_Tab_DataTab,
                            dataTab,
                            outputDynSt,
                            0);
                    }
                    else
                    {
                        /* REF7264 - PMO */
                        optiDataTab = (DBA_DYNFLD_STP *)CALLOC(eltNbr, sizeof(DBA_DYNFLD_STP));
                        dataTab = GET_EXTENSION_PTR(resultPtr, Select_Res_Tab_DataTab);

                        for (k = 0; k < eltNbr; k++)
                        {
                            optiDataTab[k] = ALLOC_DYNST(outputDynSt);
                            COPY_DYNST_DISDOMTRACE(optiDataTab[k], dataTab[k], outputDynSt);  /* PMSTA-23209 - DDV - 160622 */
                        }

                        SET_EXTENSION(outputData, Select_Res_Tab_DataTab, optiDataTab, outputDynSt, eltNbr);
                    }
                }
                else  /**** END DVP255 *****/
                {
                    if (COPY_DYNST_DISDOMTRACE(dataPtr + firstOutFld, resultPtr, *(proc->outputDynStPtr)) == FALSE) /* PMSTA-23209 - DDV - 160622 */
                    {
                        return(RET_DBA_ERR_OPTI);
                    }
                }
            }


            /* insert in index */
            if (positionInIndex < (int)optiPtr->eltNbr)
            {
                memmove(optiPtr->optiIndex + positionInIndex + 1, optiPtr->optiIndex + positionInIndex,
                    (optiPtr->eltNbr - positionInIndex) * sizeof(int));
            }

            optiPtr->optiIndex[positionInIndex] = recNo;

            (optiPtr->eltNbr)++;

#ifdef AAATIMER
            if (optiMode == Opti_Local || optiMode == Opti_LocalGlobal)
                EV_LocWrite++;
            else
                EV_GloWrite++;
#endif
        }
        /* END   DVP531 - PEC - 970701 */
    }

    /* BUG205 GRD/PEN (13/11/1996) */

    if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        /* Init local memory too */
        if (optiMode == Opti_GlobalLocal)
        {
            return(DBA_WriteOpti(proc, Opti_Local, inPtr, resultPtr, checkFlg, posIndexLocal, posIndexGlobal));
        }
    }

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_LoadingTabInMemory()
**
**  Description :   Stock in memory database tables if specified in
**                  structures listed in SV_ObjProcLstPtrTab.
**
**                  - table Codif (SV_CodifInfo + SV_CodifNbr)
**                     update default display flag for entities which
**                     have codifications.
**
**  Arguments   :   none
**
**  Return      :   RET_SUCCEED or error code
**
**	Modif.		:	MRA - 010119 - REF5435
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**
*************************************************************************/
RET_CODE DBA_LoadingTabInMemory(void)
{
    DICT_T userLangDictId = 0;    /* DLA - PMSTA08801 - 100708 */

    /* PMSTA-14452 - LJE - 130109 - If on install mode, don't load codif. */
    if (EV_AAAInstallLevel)
        return(RET_SUCCEED);

    {
        DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);

        /***** Codification *****/
        SV_CodifNbr = 0;

    RET_CODE retCode = connHelper.dbaSelect(Codif, UNUSED, nullptr, A_Codif, &SV_CodifInfo, &SV_CodifNbr);

        if (retCode != RET_SUCCEED)
        {
            MSG_RETURN(RET_DBA_ERR_OPTI);
        }

        if (TRUE == SYS_IsGuiMode())                        /* PMSTA-20089 - 120515 - PMO */
        {
            GEN_GetUserInfo(UserLanguage, &userLangDictId);	/* MRA - 010119 - REF5435       */
            EV_ServerLanguageID = (ID_T)0;                 /*  DEV5502 - CSA - 25012001    */
        }
        else
        {
            GEN_GetUserInfo(UserLanguage, &EV_ServerLanguageID);	/*  DEV5502 - CSA - 25012001    */
        }

        /* Fill cache of messages from DB */
        FMT_InitMsgCache(userLangDictId, connHelper);
    }

    /* update A_Codif_DfltDspFlg depending on table appl_param */
    DBA_UpdDfltDispFlg();

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_UpdateApplParam()
**
**  Description :   DVP372
**              :   Update appl_param using SV_CodifInfo.
**
**  Arguments   :   none
**
**  Return      :   nothing
**
**  Creation Date : 04.03.97 - GRD
**
*************************************************************************/
void DBA_UpdateApplParam(void)
{
    DBA_DYNFLD_STP  aApplParam;
    DBA_DYNFLD_STP  sApplParam;
    ID_T            dfltCurrCodif, dfltGeoCodif, dfltInstrCodif,
        dfltSectCodif, dfltPtfCodif, /* dfltRtngCodif, */ /* REF2322 - 980804 - OCE */
        dfltThirdCodif, dfltMgrCodif, dfltTpCodif,
        dfltDepoCodif,
        dfltBusEntityCodif,         /*  HFI-PMSTA-17655-140218  */
        userId, id;
    int             currFlg, geoFlg, instrFlg, sectFlg,
        rtngFlg, ptfFlg, thirdFlg, mgrFlg,
        tpFlg, depoFlg,
        busEntFlg,                  /*  HFI-PMSTA-17655-140218  */
        i = 0, retCode,
        currFlgChanged, geoFlgChanged, instrFlgChanged,
        sectFlgChanged, rtngFlgChanged, ptfFlgChanged,
        thirdFlgChanged, mgrFlgChanged, tpFlgChanged,
        depoFlgChanged,
        busEntityFlgChanged;        /*  HFI-PMSTA-17655-140218  */
    DICT_T          currDictId, geoDictId, instrDictId, sectDictId,
        rtngDictId, ptfDictId, thirdDictId, mgrDictId,
        tpDictId, depoDictId,
        busEntityDictId;            /*  HFI-PMSTA-17655-140218  */
    const char *    pszApplName;    /* REF7264 - PMO */

    /* Flag is TRUE if entity identifier was found, FALSE elsewhere */
    currFlg = DBA_GetDictId(Curr, &currDictId);
    depoFlg = DBA_GetDictId(Depo, &depoDictId);
    geoFlg = DBA_GetDictId(Geo, &geoDictId);
    instrFlg = DBA_GetDictId(Instr, &instrDictId);
    mgrFlg = DBA_GetDictId(Mgr, &mgrDictId);
    ptfFlg = DBA_GetDictId(Ptf, &ptfDictId);
    rtngFlg = DBA_GetDictId(Rating, &rtngDictId);
    sectFlg = DBA_GetDictId(Sect, &sectDictId);
    thirdFlg = DBA_GetDictId(Third, &thirdDictId);
    tpFlg = DBA_GetDictId(Tp, &tpDictId);
    busEntFlg = DBA_GetDictId(BusEntity, &busEntityDictId);    /*  HFI-PMSTA-17655-140218  */

    /* Get default value in table appl_param. */
    GEN_GetApplInfo(ApplCurrencyCodif, &dfltCurrCodif);
    GEN_GetApplInfo(ApplDepoCodif, &dfltDepoCodif);
    GEN_GetApplInfo(ApplGeographicCodif, &dfltGeoCodif);
    GEN_GetApplInfo(ApplInstrumentCodif, &dfltInstrCodif);
    GEN_GetApplInfo(ApplManagerCodif, &dfltMgrCodif);
    GEN_GetApplInfo(ApplPortfolioCodif, &dfltPtfCodif);
    /*GEN_GetApplInfo(ApplRatingCodif,     &dfltRtngCodif);*/ /* REF2322 - 980804 - OCE */
    GEN_GetApplInfo(ApplSectorCodif, &dfltSectCodif);
    GEN_GetApplInfo(ApplThirdPartyCodif, &dfltThirdCodif);
    GEN_GetApplInfo(ApplTypeCodif, &dfltTpCodif);
    GEN_GetApplInfo(ApplBusEntityCodif, &dfltBusEntityCodif);  /*  HFI-PMSTA-17655-140218  */

    currFlgChanged = geoFlgChanged = instrFlgChanged = FALSE;
    sectFlgChanged = rtngFlgChanged = ptfFlgChanged = FALSE;
    thirdFlgChanged = tpFlgChanged = mgrFlgChanged = FALSE;
    depoFlgChanged = FALSE;
    busEntityFlgChanged = FALSE;                                /*  HFI-PMSTA-17655-140218  */

    /* Read table codification */
    for (i = 0; i<SV_CodifNbr; i++)
    {
        if (currFlg == TRUE)
        {
            /* currency default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == currDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltCurrCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    currFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (depoFlg == TRUE)
        {
            /* geographical area default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == depoDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltDepoCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    depoFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (geoFlg == TRUE)
        {
            /* geographical area default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == geoDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltGeoCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    geoFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (instrFlg == TRUE)
        {
            /* instrument default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == instrDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltInstrCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    instrFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (mgrFlg == TRUE)
        {
            /* portfolio default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == mgrDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltMgrCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    mgrFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (ptfFlg == TRUE)
        {
            /* portfolio default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == ptfDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltPtfCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    ptfFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (sectFlg == TRUE)
        {
            /* sector default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == sectDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltSectCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    sectFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (thirdFlg == TRUE)
        {
            /* third default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == thirdDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltThirdCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    thirdFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (tpFlg == TRUE)
        {
            /* third default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == tpDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltTpCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    tpFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }

        if (busEntFlg == TRUE)      /*  HFI-PMSTA-17655-140218  */
        {
            /* third default display codification */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == busEntityDictId) &&
                (GET_ID(SV_CodifInfo[i], A_Codif_Id) == dfltBusEntityCodif))
            {
                /* default display found */
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) != TRUE)
                {
                    busEntityFlgChanged = TRUE; /* Codification has changed. */
                }
                continue;
            }
        }
    }

    /* If one of those codif has changed, update appl_param. */
    if ((currFlgChanged == TRUE) || (depoFlgChanged == TRUE) ||
        (geoFlgChanged == TRUE) || (instrFlgChanged == TRUE) ||
        (mgrFlgChanged == TRUE) || (ptfFlgChanged == TRUE) ||
        (rtngFlgChanged == TRUE) || (sectFlgChanged == TRUE) ||
        (thirdFlgChanged == TRUE) || (tpFlgChanged == TRUE) ||
        (busEntityFlgChanged == TRUE))                              /*  HFI-PMSTA-17655-140218  */
    {
        aApplParam = ALLOC_DYNST(A_ApplParam);
        sApplParam = ALLOC_DYNST(S_ApplParam);

        GEN_GetUserInfo(UserId, &userId);

        /* Read table codification */
        for (i = 0; i<SV_CodifNbr; i++)
        {
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == currDictId) && (currFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "CURRENCY_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplCurrencyCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == depoDictId) && (depoFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "DEPOSIT_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplDepoCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == geoDictId) && (geoFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "GEOGRAPHIC_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplGeographicCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == instrDictId) && (instrFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "INSTRUMENT_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplInstrumentCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == mgrDictId) && (mgrFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "MANAGER_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplManagerCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == ptfDictId) && (ptfFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "PORTFOLIO_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplPortfolioCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == rtngDictId) && (rtngFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "RATING_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == sectDictId) && (sectFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "SECTOR_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplSectorCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == thirdDictId) && (thirdFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "THIRD_PARTY_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplThirdPartyCodif, &id);
                    }
                }

                continue;
            }

            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == tpDictId) && (tpFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "TYPE_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName); /* DLA - PMSTA09887 - 101115 */

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    /*  FIH-REF3294-990304  */
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplTypeCodif, &id);
                    }
                }

                continue;
            }

            /*  HFI-PMSTA-17655-140218  */
            if ((GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == busEntityDictId) && (busEntityFlgChanged == TRUE))
            {
                if (GET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg) == TRUE)
                {
                    pszApplName = "BUSINESS_ENTITY_CODIF";
                    SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName);

                    DBA_Get2(ApplParam, UNUSED,
                        S_ApplParam, sApplParam,
                        A_ApplParam, &aApplParam,
                        UNUSED, UNUSED, UNUSED);

                    SET_ID(aApplParam, A_ApplParam_UserId, userId);
                    SET_INFO(aApplParam, A_ApplParam_Value, GET_CODE(SV_CodifInfo[i], A_Codif_Cd));

                    retCode = DBA_InsUpd(ApplParam, UNUSED,
                        A_ApplParam, aApplParam,
                        UNUSED, UNUSED, UNUSED);
                    if (retCode == RET_SUCCEED)
                    {
                        id = GET_ID(SV_CodifInfo[i], A_Codif_Id);
                        GEN_SetApplInfo(ApplBusEntityCodif, &id);
                    }
                }

                continue;
            }
        }

        FREE_DYNST(aApplParam, A_ApplParam);
        FREE_DYNST(sApplParam, S_ApplParam);
    }
}

/************************************************************************
**
**  Function    :   DBA_FlushOptimisation()
**
**  Description :   flush global optimisation buffers and reset
**                  optimisation mamagment informations
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
void DBA_FlushOptimisation(OBJECT_ENUM objectEn)
{
    if (EV_OptiPtr != nullptr)
    {
        for (unsigned n = 0; n < Opti_Number; n++)
        {
            LockGuard lock(EV_OptiPtr[n].globalLock, LockGuard::Access::write, true, FILEINFO);   /* DLA - PMSTA-26864 - 170404 */
            if (EV_OptiPtr[n].outputFldNbr != 0)
            {
                /* PMSTA-34344 - LJE - 200930 */
                if (objectEn != NullEntity)
                {
                    int objLstPos = 0;
                    while (*EV_OptiPtr[n].objLstPtr[objLstPos] != NullEntity &&
                           *EV_OptiPtr[n].objLstPtr[objLstPos] != objectEn)
                    {
                        objLstPos++;
                    }
                    if (*EV_OptiPtr[n].objLstPtr[objLstPos] == NullEntity)
                    {
                        continue;
                    }
                }

                DBA_FreeOpti(&EV_OptiPtr[n]);

                EV_OptiPtr[n].inputArgNbr = 0;
                EV_OptiPtr[n].outputFldNbr = 0;
                EV_OptiPtr[n].strArgFlg = FALSE;
                EV_OptiPtr[n].eltNbr = 0;
                EV_OptiPtr[n].allocNbr = 0;
                EV_OptiPtr[n].nbCall = 0;
                EV_OptiPtr[n].cacheHint = 0;
                EV_OptiPtr[n].currentFree = 0;
                EV_OptiPtr[n].maxFfree = 0;
                EV_OptiPtr[n].nbPurgeRecord = 0;

                EV_OptiPtr[n].cacheHit = 0;		/* REF11767 - CHU - 060329 */
                EV_OptiPtr[n].cacheMiss = 0;		/* REF11767 - CHU - 060329 */
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_UpdDfltDispFlg()
**
**  Description :   Update default display flag for entities which
**                  have codifications.
**                   - currency          (OBJECT_ENUM Curr)
**                   - geographical area (OBJECT_ENUM Geo)
**                   - instrument        (OBJECT_ENUM Instr)
**                   - sector            (OBJECT_ENUM Sect)
**                   - rating            (OBJECT_ENUM Rating)
**                   - language          (OBJECT_ENUM Lang)
**                   - portfolio         (OBJECT_ENUM Ptf)
**                   - third_party       (OBJECT_ENUM Third)
**                   - Manager           (OBJECT_ENUM Mgr)
**                   - Deposit           (OBJECT_ENUM Depo)
**                   - Type              (OBJECT_ENUM Tp)
**
**                  Metadictionary was reading before.
**
**  Arguments   :   none
**
**  Return      :   none
**
**  Modif       :   PMSTA-11580-HFI-110310  Manage DictLang
**
*************************************************************************/
STATIC void DBA_UpdDfltDispFlg()
{
    ID_T    dfltDspCodif;
    int     currFlg, geoFlg, instrFlg, sectFlg, rtngFlg,
        ptfFlg, thirdFlg, mgrFlg, tpFlg, depoFlg, langFlg, i,
        busEntFlg;                                              /*  HFI-PMSTA-17655-140218  */
    DICT_T  currDictId, geoDictId, instrDictId, sectDictId, rtngDictId,
        ptfDictId, thirdDictId, mgrDictId, depoDictId, tpDictId, langDictId,
        busEntityDictId;                                        /*  HFI-PMSTA-17655-140218  */

    /* *Flg will be TRUE if entity identifier was found, FALSE elsewhere */
    currFlg = DBA_GetDictId(Curr, &currDictId);
    geoFlg = DBA_GetDictId(Geo, &geoDictId);
    instrFlg = DBA_GetDictId(Instr, &instrDictId);
    sectFlg = DBA_GetDictId(Sect, &sectDictId);
    rtngFlg = DBA_GetDictId(Rating, &rtngDictId);
    ptfFlg = DBA_GetDictId(Ptf, &ptfDictId);
    thirdFlg = DBA_GetDictId(Third, &thirdDictId);
    mgrFlg = DBA_GetDictId(Mgr, &mgrDictId);
    depoFlg = DBA_GetDictId(Depo, &depoDictId);
    tpFlg = DBA_GetDictId(Tp, &tpDictId);
    langFlg = DBA_GetDictId(DictLang, &langDictId);       /*  PMSTA-11580-HFI-110310  */
    busEntFlg = DBA_GetDictId(BusEntity, &busEntityDictId);     /*  HFI-PMSTA-17655-140218  */

    /* Read table codification */
    for (i = 0; i<SV_CodifNbr; i++)
    {
        /* currency default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == currDictId)
        {
            if (currFlg == TRUE)
            {
                GEN_GetApplInfo(ApplCurrencyCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    currFlg = FALSE;
                }
            }
            continue;
        }

        /* geographical area default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == geoDictId)
        {
            if (geoFlg == TRUE)
            {
                GEN_GetApplInfo(ApplGeographicCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    geoFlg = FALSE;
                }
            }
            continue;
        }

        /* instrument default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == instrDictId)
        {
            if (instrFlg == TRUE)
            {
                GEN_GetApplInfo(ApplInstrumentCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    instrFlg = FALSE;
                }
            }
            continue;
        }

        /* sector default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == sectDictId)
        {
            if (sectFlg == TRUE)
            {
                GEN_GetApplInfo(ApplSectorCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    sectFlg = FALSE;
                }
            }
            continue;
        }

        /* portfolio default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == ptfDictId)
        {
            if (ptfFlg == TRUE)
            {
                GEN_GetApplInfo(ApplPortfolioCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    ptfFlg = FALSE;
                }
            }
            continue;
        }

        /* third default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == thirdDictId)
        {
            if (thirdFlg == TRUE)
            {
                GEN_GetApplInfo(ApplThirdPartyCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    thirdFlg = FALSE;
                }
            }
            continue;
        }

        /* Manager default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == mgrDictId)
        {
            if (mgrFlg == TRUE)
            {
                GEN_GetApplInfo(ApplManagerCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    mgrFlg = FALSE;
                }
            }
            continue;
        }

        /* Deposit default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == depoDictId)
        {
            if (depoFlg == TRUE)
            {
                GEN_GetApplInfo(ApplDepoCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    depoFlg = FALSE;
                }
            }
            continue;
        }

        /*  Deposit default display codification    */  /*  HFI-PMSTA-17655-140218  */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == busEntityDictId)
        {
            if (depoFlg == TRUE)
            {
                GEN_GetApplInfo(ApplBusEntityCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    depoFlg = FALSE;
                }
            }
            continue;
        }

        /* Type default display codification */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == tpDictId)
        {
            if (tpFlg == TRUE)
            {
                GEN_GetApplInfo(ApplTypeCodif, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    tpFlg = FALSE;
                }
            }
            continue;
        }

        /* Type default display codification */     /*  PMSTA-11580-HFI-110310  */
        if (GET_DICT(SV_CodifInfo[i], A_Codif_SynEntityDictId) == langDictId)
        {
            if (tpFlg == TRUE)
            {
                GEN_GetApplInfo(ApplDictLanguageCodifId, &dfltDspCodif);
                if (dfltDspCodif == GET_ID(SV_CodifInfo[i], A_Codif_Id))
                {
                    /* default display found */
                    SET_FLAG(SV_CodifInfo[i], A_Codif_DfltDspFlg, TRUE);
                    tpFlg = FALSE;
                }
            }
            continue;
        }
    }
    return;
}

/************************************************************************
*
*   Function           : DBA_SetNullOpti()
*
*   Description        : Set to NULL optimization informations
*
*   Arguments          : optiPtr pointer on optimization structure array to modify
*
*   Return             : TRUE    if success
*
*  Creation Date       : 28.12.94 - RAK
*  Last Modif          :
*************************************************************************/
int DBA_SetNullOpti(DBA_OPTI_STP optiPtr)
{
    if (optiPtr == nullptr)
        return TRUE;

    for (int idx = 0; idx < EV_NewOptiListSize; idx++)
    {
        if (optiPtr[idx].outputFldNbr != 0)
        {
            DBA_FreeOpti(&optiPtr[idx]);
        }
    }
    return(TRUE);
}

/************************************************************************
*
*  Function          : DBA_FreeOpti()
*
*  Description       : Free allocated memory for optimised data
*
*  Arguments         : optiPtr : pointer on optimisation
*
*  Return            : RET_SUCCEED or error code
*
*  Last Modification : 08.01.97 - PEC - Ref.: DVP255
*
*************************************************************************/
RET_CODE DBA_FreeOpti(DBA_OPTI_STP optiPtr)
{
    int                   i, j, argPos, fldNbr;
    DBA_DYNFLD_STP        dataPtr;
    DBA_PROCPARAM_STP     procParam;
    DBA_PROC_STP          proc;

    proc = (DBA_PROC_STP)optiPtr->procPtr;
    procParam = proc->procParamDefPtr;

    if (optiPtr->inputArgNbr > 0 && /* REF1532 - DDV - 980421 */
        procParam == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_FreeOpti", "procParam");
        return(RET_GEN_ERR_INVARG);
    }

    fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

    for (i = 0; i<(int)optiPtr->eltNbr; i++)
    {
        /* dataPtr contains access number,time stamp, input and output args */
        dataPtr = GET_DYNFLDSTP(optiPtr->dataPtr, i, fldNbr);

        /* input arguments */
        if (optiPtr->strArgFlg == TRUE)
        {
            argPos = 0;
            while (argPos < optiPtr->inputArgNbr)
            {
                if (IS_STRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                {
                    FREE_STRFLD(dataPtr[Opti_FirstIn + argPos]);
                }
                else if (IS_USTRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                {
                    FREE_USTRFLD(dataPtr[Opti_FirstIn + argPos]);
                }
                ++argPos;
            }
        }

        /* output structure (2 = access number + time stamp)  */
        dataPtr = dataPtr + (Opti_FirstIn + optiPtr->inputArgNbr);

        /* free only strings, not origin pointer (1 alloc) */
        /**** BEGIN DVP255 ****/
        if (proc->action == Select)
        {
            int              eltNbr = GET_EXTENSION_NBR(dataPtr, Select_Res_Tab_DataTab);
            DBA_DYNST_ENUM  eltType = GET_EXTENSION_TP(dataPtr, Select_Res_Tab_DataTab);
            DBA_DYNFLD_STP *dataTab = GET_EXTENSION_PTR(dataPtr, Select_Res_Tab_DataTab);

            for (j = 0; j<eltNbr; j++)
            {
                FREE_DYNST(dataTab[j], eltType);
            }

            FREE(dataTab);
        }
        else  /**** BEGIN DVP255 ****/
        {
            FREE_DYNST_STR(dataPtr, *(proc->outputDynStPtr));
        }
    }

    FREE(optiPtr->dataPtr);
    FREE(optiPtr->optiFree);
    FREE(optiPtr->optiIndex);

    /* reset information */
    optiPtr->inputArgNbr = 0;
    optiPtr->outputFldNbr = 0;
    optiPtr->strArgFlg = FALSE;
    optiPtr->eltNbr = 0;
    optiPtr->allocNbr = 0;
    optiPtr->nbCall = 0;
    optiPtr->cacheHint = 0;
    optiPtr->currentFree = 0;
    optiPtr->maxFfree = 0;
    optiPtr->nbPurgeRecord = 0;
    optiPtr->cacheHit = 0;		/* REF11767 - CHU - 060329 */
    optiPtr->cacheMiss = 0;		/* REF11767 - CHU - 060329 */

    /* REF11767 - CHU - 060330 */
    DBA_AddOptiPurgeTime(optiPtr);

    return(RET_SUCCEED);
}
/************************************************************************
**
** Function    : DBA_UpdOptiTabForDynamicSql
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : sme (Monday January 22 2001)
**
** Last modif. : REF7264 - 020327 - PMO : Compilation errors and warnings with C++ compiler
**               PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**
************************************************************************/
void DBA_UpdOptiTabForDynamicSql(DBA_OPTI_STP optiPtr, OBJECT_ENUM object)
{
    /* PMSTA-26108 - LJE - 170912 */
    if (optiPtr == nullptr)
    {
        return;
    }

    char objectStr[50];

    optiPtr = optiPtr + Opti_DynamicSql;

    if (optiPtr->dataPtr == nullptr)    /*  Code moved after initialisation */  /*  HFI-PMSTA-51122-2022-11-11  */
    {
        return;
    }
    sprintf(objectStr, " " szFormatObj " ", object);

    LockGuard lock(optiPtr->globalLock, LockGuard::Access::write, true, FILEINFO);    /* PMSTA-20088 - 041015 - PMO */

    DBA_DYNFLD_STP headData = optiPtr->dataPtr;
    DBA_DYNFLD_STP headSql = headData + Opti_FirstIn;

    for (unsigned int i = 0; i < optiPtr->eltNbr; i++)
    {
        char * objectTablelistId = GET_STRING(headSql, Dynamic_Sql_Table);

        if (strstr(objectTablelistId, objectStr))
        {
            /* REF9896 - LJE - 040202 */
            SET_UINT(headData, Opti_AccessNbr, 0);
            SET_UINT(headData, Opti_TimeStamp, 0);
            SET_FLAG_FALSE(headSql, Dynamic_Sql_Valid);

            DBA_DYNFLD_STP dynStp = headSql + optiPtr->inputArgNbr;

            int                 eltNbr = GET_EXTENSION_NBR(dynStp, Select_Res_Tab_DataTab);
            DBA_DYNFLD_STP *    dataTab = GET_EXTENSION_PTR(dynStp, Select_Res_Tab_DataTab);
            DBA_DYNST_ENUM      out = GET_EXTENSION_TP(dynStp, Select_Res_Tab_DataTab);

            for (int j = 0; j<eltNbr; j++)
            {
                FREE_DYNST(dataTab[j], out);
            }
            DBA_FreeDynSt(dynStp, Select_Res_Tab);
        }

        /* REF9896 - LJE - 040202 */
        headData = headSql + optiPtr->inputArgNbr + optiPtr->outputFldNbr;
        headSql = headData + Opti_FirstIn;
    }
}

/************************************************************************
*   Function             : DBA_SetSrvOpti()
*
*   Description          : Apply custom optimization for current server
*
*   Arguments            : None
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : REF11767 - CHU - 060403
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_SetSrvOpti(DBA_OPTI_SETMODE_ENUM setMode)
{
    RET_CODE		retCd = RET_SUCCEED;
    DBA_DYNFLD_STP	sServConnect = nullptr;
    std::string     serverName;

    DBA_DYNFLD_STP	*optiCompoTab;
    DBA_PROC_STP	*optiProcTab = nullptr,
        procPtr = nullptr;
    int				optiCompoNbr = 0,
        procNbr = 0,
        compoIdx = 0,
        procIdx = 0,
        storedIdx = 0,
        currPos = 0;

    OBJECT_ENUM		oldObj = -1;
    DBA_OPTI_ENUM	optiIdx;

    FLAG_T			duplicateOptiFlg = FALSE;
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);


    /* retrieve current server record */
    if (SV_ServConnectRecord == nullptr)
    {
        if ((SV_ServConnectRecord = ALLOC_DYNST(A_ServConnect)) == nullptr)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        if ((sServConnect = ALLOC_DYNST(S_ServConnect)) == nullptr)
        {
            FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
            return(RET_MEM_ERR_ALLOC);
        }

        GEN_GetApplInfo(ApplServerName, serverName);
        SET_SYSNAME(sServConnect, S_ServConnect_ServerName, serverName.c_str());  /* DLA - PMSTA09880 - 100715 */

        if (dbiConnHelper.dbaGet(ServConnect, UNUSED, sServConnect, &SV_ServConnectRecord) != RET_SUCCEED)
        {
            FREE_DYNST(SV_ServConnectRecord, A_ServConnect);
            FREE_DYNST(sServConnect, S_ServConnect);
            MSG_RETURN(RET_DBA_ERR_NODATA);
        }
        FREE_DYNST(sServConnect, S_ServConnect);
    }

    /* if current server has an optimization profile, load its composition */
    if (nullptr != SV_ServConnectRecord &&
        FALSE == IS_NULLFLD(SV_ServConnectRecord, A_ServConnect_OptiProfileId))
    {
        if ((retCd = DBA_SelectOptiCompo(GET_ID(SV_ServConnectRecord, A_ServConnect_OptiProfileId),
            &optiCompoTab, &optiCompoNbr, dbiConnHelper)) != RET_SUCCEED)
        {
            return(retCd);
        }

        /* construct a list of all SqlServer optimized procs */
        if ((optiProcTab = (DBA_PROC_STP *)CALLOC(Opti_Number, sizeof(DBA_PROC_STP))) == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (OBJECT_ENUM objIdx = 0; objIdx <= LASTOBJECT; objIdx++)
        {
            DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(objIdx);

            if (objProcLstStp != nullptr)
            {
                for (procIdx = 0; objProcLstStp[procIdx].action != NullAction; procIdx++)
                {
                    if (objProcLstStp[procIdx].optiIdx == NullOpti ||
                        objProcLstStp[procIdx].server != SqlServer)
                        continue;

                    optiIdx = objProcLstStp[procIdx].optiIdx;

                    /* discard duplicates */
                    duplicateOptiFlg = FALSE;
                    for (storedIdx = currPos; optiProcTab[storedIdx] != nullptr; storedIdx++)
                    {
                        if (optiProcTab[storedIdx]->optiIdx == optiIdx &&
                            strcmp(optiProcTab[storedIdx]->procName, objProcLstStp[procIdx].procName) == 0)
                        {
                            duplicateOptiFlg = TRUE;
                            break;
                        }
                    }

                    if (FALSE == duplicateOptiFlg)
                    {
                        optiProcTab[procNbr++] = &(objProcLstStp[procIdx]);
                    }
                }
                if (objIdx != oldObj)
                {
                    oldObj = objIdx;
                    if (procNbr > 0)
                        currPos = procNbr;
                    else
                        currPos = 0;
                }
            }
        }

        /* set opti data for current server procedures */
        for (compoIdx = 0; compoIdx < optiCompoNbr; compoIdx++)
        {
            for (procIdx = 0; procIdx < procNbr; procIdx++)
            {
                procPtr = optiProcTab[procIdx];
                if (procPtr != nullptr &&
                    strcmp(procPtr->procName, GET_CODE(optiCompoTab[compoIdx], A_OptiProfCompo_ProcSqlName)) == 0)
                {
                    optiIdx = procPtr->optiIdx;

                    /* PMSTA14183 - DDV - 120514 - Allow global cache size update, but only in set mode */
                    LockGuard lock(EV_OptiPtr[optiIdx].globalLock, LockGuard::Access::write, true, FILEINFO);   /* DLA - PMSTA-26864 - 170404 */
                    if (setMode == Opti_SetMode_Set)
                    {
                        if (FALSE == IS_NULLFLD(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalAlloc))
                        {
                            EV_OptiPtr[optiIdx].allocBloc = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalAlloc);
                        } /* else keep default */

                        if (FALSE == IS_NULLFLD(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalMaxAlloc))
                        {
                            EV_OptiPtr[optiIdx].maxAllocNbr = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_GlobalMaxAlloc);
                        } /* else keep default */
                    }

                    if (FALSE == IS_NULLFLD(optiCompoTab[compoIdx], A_OptiProfCompo_LocalAlloc))
                    {
                        EV_OptiPtr[optiIdx].locAllocBloc = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalAlloc);
                    } /* else keep default */

                    if (FALSE == IS_NULLFLD(optiCompoTab[compoIdx], A_OptiProfCompo_LocalMaxAlloc))
                    {
                        EV_OptiPtr[optiIdx].locMaxAllocNbr = (unsigned long)GET_INT(optiCompoTab[compoIdx], A_OptiProfCompo_LocalMaxAlloc);
                    } /* else keep default */
                }
            }
        }
        FREE(optiCompoTab);
        FREE(optiProcTab);
    }
    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_UpdOptiTab()
**
**  Description :   Search optimisations which use modified object
**                  for set all these to NULL.
**
**  Arguments   :   optiPtr pointer on optimisation array
**                  object      object which was modified
**
**  Return      :   none
**
**  Modif.      :   ROI - 981229 - REF2644
**
**  Last modif. :   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**
*************************************************************************/
void DBA_UpdOptiTab(DBA_OPTI_STP optiPtr, OBJECT_ENUM object)
{
    int     idx;
    int     i;
    char    flg;

    /* REF11767 - CHU - 060518 */
    if (TRUE == SYS_IsSrvMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        if (object == OptiProfCompo)
        {
            /* Reload Opti Compo */
            if (DBA_SetSrvOpti(Opti_SetMode_Upd) == RET_SUCCEED)
                DBA_UpdOptiTabForDynamicSql(optiPtr, object);
            return;
        }
    }

    if (!SYS_IsSrvMode() && !SYS_IsDdlGenMode()) /* REF11845 - DDV - 060621 - For server, purge is managed in function DBA_VerifOptiTab to purge all threads */
    {
        /* REF2644 - DDV - 981027 - Tempory flush of DV and IC optimisation, must be changed when general optimisation tools exist */
        if (object == ScriptDef ||
            object == ApplUser ||
            object == ScreenProfCompo)
        {
            /* REF7264 - PMO */
            SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */
            SCPT_FreeScriptIC(NullEntity); /* PMSTA06772 - 080619 - DDV */
        }
    }

    /* REF7264 - PMO */
    for (idx = 0; idx < (DBA_OPTI_ENUM)EV_NewOptiListSize; idx++)
    {
        /* When optimisation is filled,                */
        /* (outputFldNbr is init by first DBA_Write()) */
        /* test if optimisation must be set to NULL    */
        if (optiPtr[idx].outputFldNbr != 0)
        {
            /* Read object list for current optimisation */
            i = 0;
            flg = FALSE;
            while (optiPtr[idx].objLst[i] != NullEntity && flg == FALSE)
            {
                if (optiPtr[idx].objLst[i] == object)
                    flg = TRUE;
                i++;
            }

            /* Set to NULL optimisation */
            if (flg == TRUE)
            {
                LockGuard lock(optiPtr[idx].globalLock, LockGuard::Access::write, true, FILEINFO);    /* PMSTA-20088 - 041015 - PMO */

                DBA_FreeOpti(&optiPtr[idx]);

                optiPtr[idx].inputArgNbr = 0;
                optiPtr[idx].outputFldNbr = 0;
                optiPtr[idx].strArgFlg = FALSE;
                optiPtr[idx].eltNbr = 0;
                optiPtr[idx].allocNbr = 0;
                optiPtr[idx].nbCall = 0;
                optiPtr[idx].cacheHint = 0;
                optiPtr[idx].currentFree = 0;
                optiPtr[idx].maxFfree = 0;
                optiPtr[idx].nbPurgeRecord = 0;

                /* < REF11767 - CHU - 060329 */
                optiPtr[idx].cacheHit = 0;
                optiPtr[idx].cacheMiss = 0;
                /* > REF11767 - CHU - 060329 */
            }
        }
    }

    DBA_UpdOptiTabForDynamicSql(optiPtr, object);
}

/************************************************************************
*   Function             : DBA_GetMemory()
*
*   Description          : Get information in specified optimisation array
*
*   Arguments            : object     : request corresponding object
*                          role       : role of the request
*                          inputSt    : input dynamic struct. format
*                          inputData  : pointer on the input dynamic structure
*                          outputSt   : output dynamic structure format
*                          outputData : pointer on the output dyn. struct. array
*                          outputPtr  : pointer on dyn. struct. pointer or NULL
*                          optiMode   : - Opti_Local search in local only
*                                   - Opti_LocalGlobal search in local and
*                                         then in global
*
*   Return               : RET_SUCCEED             if ok
*                          RET_DBA_INFO_NODATAOPTI if optimisation isn't set
*                                                  for procedure.
*                          error code              if problem
*
*   Modification  : 10.07.95 - RAK - new argument outPtrPtr
*                   13/12/95 - RAK  use without OPTIMISATION env variable
*
*************************************************************************/
RET_CODE DBA_GetMemory(OBJECT_ENUM       object,
    int               role,
    DBA_DYNST_ENUM    inputSt,
    DBA_DYNFLD_STP    inputData,
    DBA_DYNST_ENUM    outputSt,
    DBA_DYNFLD_STP    outputData,
    DBA_DYNFLD_STP    *outputPtr,
    DBA_OPTIMODE_ENUM optiMode)
{
    DBA_PROC_STP    procedure = nullptr;
    RET_CODE        ret;
    int posIndexLocal = -1, posIndexGlobal = -1;

    /*  DVP211 20/09/96 pen  MEGA OPTIMISATION FONCTIONS FINANCIAIRES */
    if (SERVER_MODE() != TRUE)
        return(RET_DBA_INFO_NODATAOPTI);

    /* Test ouput data argument validity */
    if (outputData == nullptr && outputPtr == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GetMemory", "output");
        return(RET_GEN_ERR_INVARG);
    }

    /* Retrieve a procedure in the object procedures list */
    procedure = DBA_GetStoredProcs(Get, object, role, inputSt, inputData, outputSt);

    /* If no procedure was found */
    if (procedure == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GetMemory", "procedure");
        return(RET_GEN_ERR_INVARG);
    }

    /* Procedure is optimised and we are in server mode */
    if (SERVER_MODE() == TRUE && procedure->optiIdx != NullOpti)
    {
        /* Search if element is stored in local and then in global */
        DATE_START_TIMER(10, TIMER_MASK_SQLC);
        ret = DBA_ReadOpti(procedure, optiMode, inputData, outputData, outputPtr, &posIndexLocal, &posIndexGlobal);
        DATE_STOP_TIMER(10, TIMER_MASK_SQLC);

        return(ret);
    }
    else
    {
        return(RET_DBA_INFO_NODATAOPTI);
    }
}

/************************************************************************
*   Function             : DBA_SelectMemory()
*
*   Description          : Select information in specified optimisation array
*
*   Arguments            : object     : request corresponding object
*                          role       : role of the request
*                          inputSt    : input dynamic struct. format
*                          inputData  : pointer on the input dynamic structure
*                          outputSt   : output dynamic structure format
*                          outputData : pointer on the output dyn. struct. array
*                          outputPtr  : pointer on dyn. struct. pointer or NULL
*                          optiMode   : - Opti_Local search in local only
*                                   - Opti_LocalGlobal search in local and
*                                         then in global
*
*   Return               : RET_SUCCEED             if ok
*                          RET_DBA_INFO_NODATAOPTI if optimisation isn't set
*                                                  for procedure.
*                          error code              if problem
*
*   Modification  : 24/02/98 - XDI - Creation for currency modify of portfolio position set
*           REF3130 - 980111 - SSO : corrected impact of REF1036 - RAK - 981104
*           REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
RET_CODE DBA_SelectMemory(OBJECT_ENUM       object,
    int               role,
    DBA_DYNST_ENUM    inputSt,
    DBA_DYNFLD_STP    inputData,
    DBA_DYNST_ENUM    outputSt,
    DBA_DYNFLD_STP    **outputData,
    DBA_DYNFLD_STP    **outputPtr,
    int               *resultRows,
    DBA_OPTIMODE_ENUM optiMode)
{
    DBA_PROC_STP    procedure = nullptr;
    RET_CODE        ret;
    int posIndexLocal = -1, posIndexGlobal = -1;
    DBA_DYNST_ENUM  outputDynSt;    /* REF7264 - PMO */

    /* Test ouput data argument validity */
    if (outputData == nullptr && outputPtr == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_SelectMemory", "output");
        return(RET_GEN_ERR_INVARG);
    }

    /* Retrieve a procedure in the object procedures list */
    procedure = DBA_GetStoredProcs(Select, object, role, inputSt, inputData, outputSt);

    /* If no procedure was found */
    if (procedure == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_SelectMemory", "procedure");
        return(RET_GEN_ERR_INVARG);
    }

    /* Procedure is optimised and we are in server mode */
    if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE) /* PMSTA-55407 - DDV - 240123 - Check if optimisation is active */
    {
        DBA_DYNFLD_STP *resultData = nullptr;
        DBA_DYNFLD_STP *tempData = nullptr;
        DBA_DYNFLD_STP selectResTab = nullptr;
        int            j, eltNbr = 0;

        /* Search if element is stored in local and then in global */
        DATE_START_TIMER(10, TIMER_MASK_SQLC);

        selectResTab = ALLOC_DYNST(Select_Res_Tab);

        ret = DBA_ReadOpti(procedure,
            Opti_LocalGlobal,
            inputData,
            selectResTab,
            nullptr,
            &posIndexLocal, &posIndexGlobal);

        if (ret == RET_SUCCEED)
        {
            eltNbr = GET_EXTENSION_NBR(selectResTab, Select_Res_Tab_DataTab);
            resultData = GET_EXTENSION_PTR(selectResTab, Select_Res_Tab_DataTab);
            outputDynSt = GET_EXTENSION_TP(selectResTab, Select_Res_Tab_DataTab);
            if (outputData != nullptr)
            {

                if (eltNbr != 0)
                {
                    /* Allocate an array REF7264 - PMO */
                    tempData = (DBA_DYNFLD_STP *)CALLOC(eltNbr, sizeof(DBA_DYNFLD_STP));

                    /* Store the structure in the array */
                    for (j = 0; j<eltNbr; j++)
                    {
                        tempData[j] = ALLOC_DYNST(outputDynSt);

                        COPY_DYNST(tempData[j], resultData[j], outputDynSt);
                    }

                    *outputData = tempData;
                }
            }
            else
            {
                if (eltNbr != 0)
                {
                    *outputPtr = resultData;
                }
            }

            if (resultRows != UNUSED)
                *resultRows = eltNbr;

            /* REF3130 - SSO - 980111: DBA_ReadOpti fill the Select_Res_Tab_DataTab extension,
            which mustn't been freed by FREE_DYNST : see also REF1036 - RAK - 981104 in dbalib02.c */
            /* EXTENSION is used like a "bidouille" -> */
            /* FREE_DYNST don't have to free extPtr    */
            SET_NULL_EXTENSION(selectResTab, Select_Res_Tab_DataTab);
        }

        /*ret = DBA_ReadOpti(procedure, optiMode, inputData, outputData, outputPtr);*/
        DATE_STOP_TIMER(10, TIMER_MASK_SQLC);
        FREE_DYNST(selectResTab, Select_Res_Tab);

        return(ret);
    }
    else
    {
        return(RET_DBA_INFO_NODATAOPTI);
    }
}

/************************************************************************
*   Function             : DBA_SetMemory()
*
*   Description          : Set information in specified array optimisation
*
*   Arguments            : object     : request corresponding object
*                          role       : role of the request
*                          inputSt    : input dynamic structure format
*                          inputData  : pointer on the input dynamic structure
*                          outputSt   : output dynamic structure format
*                          outputData : pointer on the output dyn. struct. array
*                          optiMode   : - Opti_Local write in local only
*                                   - Opti_GlobalLocal write in global and
*                                         then in local
*
*   Return               : RET_SUCCEED if ok
*                          error code  if problem
*
*   Modification  : 13/12/95 - RAK  use without OPTIMISATION env variable
*
*************************************************************************/
RET_CODE DBA_SetMemory(OBJECT_ENUM       object,
    int               role,
    DBA_DYNST_ENUM    inputSt,
    DBA_DYNFLD_STP    inputData,
    DBA_DYNST_ENUM    outputSt,
    DBA_DYNFLD_STP    outputData,
    DBA_OPTIMODE_ENUM optiMode)
{
    DBA_PROC_STP    procedure = nullptr;
    RET_CODE        ret;
    int posIndexLocal = -1, posIndexGlobal = -1;

    /*  DVP211 20/09/96 pen  MEGA OPTIMISATION FONCTIONS FINANCIAIRES */
    if (SERVER_MODE() != TRUE)
        return(RET_DBA_INFO_NODATAOPTI);

    /* Retrieve a procedure in the object procedures list */
    procedure = DBA_GetStoredProcs(Get, object, role, inputSt, inputData, outputSt);

    /* If no procedure was found */
    if (procedure == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_SetMemory", "procedure");
        return(RET_GEN_ERR_INVARG);
    }

    /* Procedure is optimised and we are in server mode */
    if (SERVER_MODE() == TRUE && procedure->optiIdx != NullOpti)
    {
        DATE_START_TIMER(11, TIMER_MASK_SQLC);
        ret = DBA_WriteOpti(procedure, optiMode, inputData, outputData, FALSE, posIndexLocal, posIndexGlobal);
        DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

        return(ret);
    }
    else
        return(RET_DBA_INFO_NODATAOPTI);
}

/************************************************************************
*   Function             : DBA_SelectSetMemory()
*
*   Description          : Set information in specified array optimisation
*
*   Arguments            : object     : request corresponding object
*                          role       : role of the request
*                          inputSt    : input dynamic structure format
*                          inputData  : pointer on the input dynamic structure
*                          outputSt   : output dynamic structure format
*                          outputData : pointer on the output dyn. struct. array
*                          optiMode   : - Opti_Local write in local only
*                                   - Opti_GlobalLocal write in global and
*                                         then in local
*
*   Return               : RET_SUCCEED if ok
*                          error code  if problem
*
*   Modification  : 13/12/95 - RAK  use without OPTIMISATION env variable
*
*************************************************************************/
RET_CODE DBA_SelectSetMemory(OBJECT_ENUM       object,
    int               role,
    DBA_DYNST_ENUM    inputSt,
    DBA_DYNFLD_STP    inputData,
    DBA_DYNST_ENUM    outputSt,
    DBA_DYNFLD_STP    outputData,
    DBA_OPTIMODE_ENUM optiMode)
{
    DBA_PROC_STP    procedure = nullptr;
    RET_CODE        ret;
    int posIndexLocal = -1, posIndexGlobal = -1;

    /* Retrieve a procedure in the object procedures list */
    procedure = DBA_GetStoredProcs(Select, object, role, inputSt, inputData, outputSt);

    /* If no procedure was found */
    if (procedure == nullptr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_SetMemory", "procedure");
        return(RET_GEN_ERR_INVARG);
    }

    /* Procedure is optimised and we are in server mode */
    if (procedure->optiIdx != NullOpti)
    {
        DATE_START_TIMER(11, TIMER_MASK_SQLC);
        ret = DBA_WriteOpti(procedure, optiMode, inputData, outputData, FALSE, posIndexLocal, posIndexGlobal);
        DATE_STOP_TIMER(11, TIMER_MASK_SQLC);

        return(ret);
    }
    else
        return(RET_DBA_INFO_NODATAOPTI);
}


/************************************************************************
*   Function             : DBA_DelUserInfo()
*
*   Description          : Delete User informations.
*
*                          - GUI PROCESS    : delete record pointed by SV_ApplUserRecord.
*
*                          - SERVER PROCESS : does nothing
*
*   Return               : None
*
*   Creation Date        : 19.09.96 - PEC - Ref.: DVP208
*
*   Last Modif           : PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
void DBA_DelUserInfo(PTR infoPtr)
{
    if (TRUE == SYS_IsGuiMode())                        /* PMSTA-20089 - 120515 - PMO */
    {
        ENTITY_INFO_STP infoSt = static_cast<ENTITY_INFO_STP>(infoPtr);
        DBA_DYNFLD_STP  applUserStp = SYS_GetThreadApplUser(false);

        /* Only if current user is modifying his own record or changing password or changing password */
        if (applUserStp != nullptr &&
            (infoPtr == nullptr || /* PMSTA-26894 - CHU - 170404 */
            CMP_ID(GET_ID(applUserStp, A_ApplUser_Id), GET_ID(infoSt->oldDbaDyn, A_ApplUser_Id)) == 0)
            )
        {
            FREE_DYNST(SV_OldApplUserRecord, A_ApplUser);

            SV_OldApplUserRecord = ALLOC_DYNST(A_ApplUser);
            COPY_DYNST(SV_OldApplUserRecord, applUserStp, A_ApplUser);
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_SetDecimSep
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Cr?ation    :   ROI - 000309 - REF3793
**
*************************************************************************/
void DBA_SetDecimSep(char* decimSep)
{
    if (TRUE == SYS_IsGuiMode() && SYS_GetThreadApplUser(false) != nullptr && decimSep != nullptr)     /* PMSTA-20089 - 120515 - PMO */
    {
        SET_NAME(SYS_GetThreadApplUser(false), A_ApplUser_LangDecimSep, decimSep);
    }
}

/************************************************************************
*   Function        :   DBA_LockIfServer()
*
*   Creation Date   :   REF4333.3 - PCL - 020512
*
*   Last modif.     :   REF11791-EFE-060531 : add 2 new parameters , in debug purpose :
*                       file and line from which the function is called.
*                       PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
int DBA_LockIfServer(DBA_SERV_LOCK_ENUM dbaLockEnum, const char *file, const int line)
{
    if (TRUE == SYS_IsSrvMode() && SERVER_IS_INIT() == TRUE)                        /* PMSTA-20089 - 120515 - PMO */
    {
        SERV_LOCK_ENUM lock;

        switch (dbaLockEnum)
        {
        case DbaServLock_CreateVirtualEntity:
            lock = ServLock_CreateVirtualEntity;
            break;

        default:
            lock = ServLockNullLock;
            break;
        }

        int lockStatus;
        return SYS_Lock(lock, WAIT, true, &lockStatus, file, line); /* PMSTA-15748 - 300113 - PMO */
    }

    return TRUE;
}

/************************************************************************
*   Function        :   DBA_UnlockIfServer()
*
*   Creation Date   :   REF4333.3 - PCL - 020512
*
*                       REF11791-EFE-060531 : add 2 new parameters , in debug purpose :
*                       file and line from which the function is called.
*                       PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
int DBA_UnlockIfServer(DBA_SERV_LOCK_ENUM dbaLockEnum, const char * file, const int line)
{
    if (TRUE == SYS_IsSrvMode() && SERVER_IS_INIT() == TRUE)                        /* PMSTA-20089 - 120515 - PMO */
    {
        SERV_LOCK_ENUM lock;

        switch (dbaLockEnum)
        {
        case DbaServLock_CreateVirtualEntity:
            lock = ServLock_CreateVirtualEntity;
            break;

        default:
            lock = ServLockNullLock;
            break;
        }

        return SYS_Unlock(lock, FILEINFO);
    }

    return TRUE;
}

/************************************************************************
*   Function        :   DBA_InitConnectNoToHier()
*
*   Description     :
*
*   Functions call  :   hierHead  pointer on hierarchy
*
*   Return      :
*
*   Creation Date   :   REF2580 - SSO - 980727
*
*************************************************************************/
void DBA_InitConnectNoToHier(PTR hierHead)
{
    /* REF2580 - SSO - 980727 stock connexion # for optim */
    ((DBA_HIER_HEAD_STP)hierHead)->threadConnNbrPlusOne = -1; ///* DLA - PMSTA-20089 - 160525 */SERV_GetThreadConnNbr() + 1;  to check if it's possible to put the pointer
}

/************************************************************************
*   Function        :   DBA_GetDomainPtr()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   DBA_DYNFLD_STP
*
*   Creation Date   :   PEC - 960424
**  Modif.          :   ROI - 980316 - REF1077
**  Modif.          :   REF2580 - SSO - 980727
**
*************************************************************************/
DBA_DYNFLD_STP DBA_GetDomainPtr(int threadConnNbr)
{
    DBA_DYNFLD_STP domainPtr = nullptr;

    if (SYS_IsSrvMode())
    {
        if (!SERV_StartedServer())
            return(nullptr);

        domainPtr = SERV_GetThreadDomain();
    }

    if (SYS_IsGuiMode())
        domainPtr = GUI_DomainCurGet();

    return(domainPtr);
}

/************************************************************************
*   Function        :   DBA_ReflectDomainUsage()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :
*
*   Creation Date   :    PMSTA13244 - DDV - 120120 - Trace DynFld usage
*
*   Modif.          :    PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*************************************************************************/
EXTERN void DBA_ReflectDomainUsage(DBA_DYNFLD_STP domainPtr)
{
    if (SYS_IsSrvMode())
    {
        int             i = 0, j = 0, fieldNbr = 0;
        DBA_DYNFLD_STP **domainLinkTabPtr;
        DBA_DYNFLD_STP src, dest;
        int            *domainLinkAllocNbr;
        int            *domainLinkNbr;

        SERV_GetCurThreadDomainLinkInfo(&domainLinkTabPtr, &domainLinkAllocNbr, &domainLinkNbr);

        if (domainLinkTabPtr != nullptr && (*domainLinkTabPtr) != nullptr &&
            domainLinkNbr != nullptr)                           /* PMSTA-17133 - 051113 - PMO */
        {
            for (i = 0; i < (*domainLinkNbr); i++)
            {
                /* src FREE_DYNST, then remove the link */
                if ((*domainLinkTabPtr)[2 * i] == domainPtr)
                {
                    (*domainLinkTabPtr)[2 * i] = nullptr;
                    (*domainLinkTabPtr)[2 * i + 1] = nullptr;
                }

                /* dest FREE_DYNST, then reflect GET and SET information */
                if ((*domainLinkTabPtr)[2 * i + 1] == domainPtr)
                {
                    src = (*domainLinkTabPtr)[2 * i];
                    dest = (*domainLinkTabPtr)[2 * i + 1];

                    if (src != nullptr && dest != nullptr)
                    {
                        fieldNbr = GET_FLD_NBR(A_Domain);

                        for (j = 0; j < fieldNbr; j++)
                        {
                            if (IS_GETFLD(dest, j) == TRUE)
                            {
                                SET_GETFLG_T(src, j);
                            }

                            if (IS_SETFLD(dest, j) == TRUE)
                            {
                                SET_SETFLG_T(src, j);
                            }
                        }
                    }

                    (*domainLinkTabPtr)[2 * i] = nullptr;
                    (*domainLinkTabPtr)[2 * i + 1] = nullptr;
                }
            }
        }
    }

    return;
}

/************************************************************************
*   Function        :   DBA_TraceDomainCopy()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :
*
*   Creation Date   :  PMSTA13244 - DDV - 120120 - Trace DynFld usage
**  Modif.          :
**
*************************************************************************/
EXTERN void DBA_TraceDomainCopy(DBA_DYNFLD_STP src,
    DBA_DYNFLD_STP dest)
{
    if (SYS_IsSrvMode())
    {
        DBA_DYNFLD_STP **domainLinkTabPtr = nullptr;
        int            *domainLinkAllocNbr = nullptr;
        int            *domainLinkNbr = nullptr;
        int            i = 0;
        DBA_DYNFLD_STP parentSrc = src;

        SERV_GetCurThreadDomainLinkInfo(&domainLinkTabPtr, &domainLinkAllocNbr, &domainLinkNbr);

        if (domainLinkTabPtr != nullptr &&
            domainLinkAllocNbr != nullptr &&
            domainLinkNbr != nullptr)
        {

            for (i = 0; i < (*domainLinkNbr); i++)
            {
                if ((*domainLinkTabPtr)[2 * i + 1] == src)
                    parentSrc = (*domainLinkTabPtr)[2 * i];
            }

            for (i = 0; i < (*domainLinkNbr); i++)
            {
                if ((*domainLinkTabPtr)[2 * i] == parentSrc && (*domainLinkTabPtr)[2 * i + 1] == dest)
                    return;
            }

            /* id no (more) space realloc array */
            if ((*domainLinkNbr) == (*domainLinkAllocNbr))
            {
                (*domainLinkAllocNbr) += 10;
                if (((*domainLinkTabPtr) = (DBA_DYNFLD_STP *)REALLOC((*domainLinkTabPtr), 2 * (*domainLinkAllocNbr) * sizeof(DBA_DYNFLD_STP))) == nullptr)
                {
                    return;
                }
            }

            (*domainLinkTabPtr)[2 * (*domainLinkNbr)] = parentSrc;
            (*domainLinkTabPtr)[2 * (*domainLinkNbr) + 1] = dest;
            (*domainLinkNbr)++;

        }
    }

    return;
}

/************************************************************************
**
**  Function        :   DBA_IsGuiMultiThreading
**
**  Description     :   if we are in gui mode and processing a thread,
**                      return TRUE, else FALSE
**
**  Arguments       :   none
**
**  Creation        :   FPL-PMSTA09858-100525
**
*************************************************************************/
FLAG_T  DBA_IsGuiMultiThreading()
{
    return GUI_IsGuiMultiThreading();
}

/************************************************************************
*   Function        :   DBA_GetTascCounter()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   uint64_t
*
*  Creation date     : PMSTA09716 - DDV - 100506
*  Modif.          :
*
*************************************************************************/
EXTERN uint64_t DBA_GetTascCounter()
{
    static uint64_t seqNo = 0;

    if (SYS_IsSrvMode())
        return(SERV_GetTascCounter());
    else
        return(++seqNo);
}

/************************************************************************
*   Function        :   DBA_GetClassifStackHeadPtr()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   DBA_CLASSIFSTACKHEAD_STP
*
*   Creation Date   :   DDV - REF5495 - 001204
*   Modif.          :
*
*************************************************************************/
DBA_CLASSIFSTACKHEAD_STP DBA_GetClassifStackHeadPtr()
{
    DBA_CLASSIFSTACKHEAD_STP classifStackHeadPtr = nullptr;

    if (SYS_IsSrvMode())
        classifStackHeadPtr = SERV_GetCurThreadClassifStackHead();

    return(classifStackHeadPtr);
}

/************************************************************************
*   Function        :   DBA_FreeClassifStack()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   RET_CODE
*
*   Creation Date   :   DDV - REF5495 - 001204
*   Modif.          :
*
*************************************************************************/
RET_CODE DBA_FreeClassifStack(DBA_CLASSIFSTACKHEAD_STP classifStackHeadPtrParam)
{
    DBA_CLASSIFSTACKHEAD_STP classifStackHeadPtr = classifStackHeadPtrParam;
    int i = 0;

    if (classifStackHeadPtr == nullptr &&
        (classifStackHeadPtr = DBA_GetClassifStackHeadPtr()) == nullptr)
        return(RET_SUCCEED);

    for (i = 0; i<classifStackHeadPtr->classifNbr; i++)
    {
        if (classifStackHeadPtr->classifTab[i].eClassifCompoPtrTab)
        {
            DBA_FreeDynStTab(classifStackHeadPtr->classifTab[i].eClassifCompoPtrTab, classifStackHeadPtr->classifTab[i].totalListNb, E_ClassifCompo);
        }
        classifStackHeadPtr->classifTab[i].totalListNb = 0;
        classifStackHeadPtr->classifTab[i].classifId = (ID_T)0;
    }

    FREE(classifStackHeadPtr->classifTab); /* PMSTA-41519 - DDV - 200824 */
    classifStackHeadPtr->classifNbr = 0;

    return(RET_SUCCEED);
}

/************************************************************************
*   Function        :   DBA_AddClassifToStack()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   RET_CODE
*
*   Creation Date   :   DDV - REF5495 - 001204
*   Modif.          :
*
*************************************************************************/
RET_CODE DBA_AddClassifToStack(DBA_CLASSIFSTACKHEAD_STP classifStackHeadPtrParam,
    DBA_DYNFLD_STP           *eClassifCompoPtrTab,
    int                      eClassifCompoNbr,
    ID_T                     classifId)
{
    DBA_CLASSIFSTACKHEAD_STP classifStackHeadPtr = classifStackHeadPtrParam;
    DBA_CLASSIFSTACK_STP     newClassif;

    if (classifStackHeadPtr == nullptr &&
        (classifStackHeadPtr = DBA_GetClassifStackHeadPtr()) == nullptr)
        return(RET_DBA_ERR_OPTI);

    if (classifStackHeadPtr->classifNbr == classifStackHeadPtr->allocNbr)
    {
        classifStackHeadPtr->allocNbr += 32;

        if ((classifStackHeadPtr->classifTab = (DBA_CLASSIFSTACK_STP)
            REALLOC(classifStackHeadPtr->classifTab,
            classifStackHeadPtr->allocNbr * sizeof(DBA_CLASSIFSTACK_ST))) == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_REALLOC);
        }
    }

    newClassif = &(classifStackHeadPtr->classifTab[classifStackHeadPtr->classifNbr]);
    newClassif->eClassifCompoPtrTab = eClassifCompoPtrTab;
    newClassif->totalListNb = eClassifCompoNbr;
    newClassif->classifId = classifId;
    classifStackHeadPtr->classifNbr++;

    return(RET_SUCCEED);
}

/************************************************************************
*   Function        :   DBA_GetListOptiPtr()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   DBA_LISTOPTIHEAD_STP
*
*   Creation Date   :   DDV - REF5495 - 001206
*   Modif.          :
*
*************************************************************************/
DBA_LISTOPTIHEAD_STP DBA_GetListOptiHeadPtr()
{
    DBA_LISTOPTIHEAD_STP listOptiHeadPtr = nullptr;

    if (SYS_IsSrvMode())
        listOptiHeadPtr = SERV_GetCurThreadListOptiHead();

    return(listOptiHeadPtr);
}


/************************************************************************
*   Function        :   DBA_FreeListOpti()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   RET_CODE
*
*   Creation Date   :   DDV - REF5495 - 001206
*   Modif.          :
*
*************************************************************************/
RET_CODE DBA_FreeListOpti(DBA_LISTOPTIHEAD_STP listOptiHeadPtrParam)
{
    int i = 0, j = 0;
    DBA_LISTOPTIHEAD_STP listOptiHeadPtr = listOptiHeadPtrParam;
    SCPT_ARG_STP    scriptTree = nullptr;

    if (listOptiHeadPtr == nullptr &&
        (listOptiHeadPtr = DBA_GetListOptiHeadPtr()) == nullptr)
        return(RET_SUCCEED);

    for (i = 0; i<listOptiHeadPtr->listNbr; i++)
    {
        if ((scriptTree = (SCPT_ARG_STP)listOptiHeadPtr->listTab[i].scriptTree) != nullptr)
        {
            /* Free script and stack */
            FREE(scriptTree->evalStack);

            if (scriptTree->stack != nullptr)
            {
                for (j = 0; j < scriptTree->stack->count; j++)
                {
                    FREE(scriptTree->stack->stack[j]);
                }

                FREE(scriptTree->stack->stack);
                FREE(scriptTree->stack);
            }
            FREE(scriptTree->context);
            FREE(scriptTree->script);
            FREE(scriptTree);
        }
        listOptiHeadPtr->listTab[i].listId = (ID_T)0;
    }

    FREE(listOptiHeadPtr->listTab); /* PMSTA-41519 - DDV - 200824 */
    listOptiHeadPtr->listNbr = 0;

    return(RET_SUCCEED);
}

/************************************************************************
*   Function        :   DBA_AddListToListOpti()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   RET_CODE
*
*   Creation Date   :   DDV - REF5495 - 001206
*   Modif.          :
*
*************************************************************************/
RET_CODE DBA_AddListToListOpti(DBA_LISTOPTIHEAD_STP listOptiHeadPtrParam,
    ID_T                 listId,
    PTR                  scriptTree)
{
    DBA_LISTOPTIHEAD_STP listOptiHeadPtr = listOptiHeadPtrParam;
    DBA_LISTOPTI_STP newList;

    if (listOptiHeadPtr == nullptr &&
        (listOptiHeadPtr = DBA_GetListOptiHeadPtr()) == nullptr)
        return(RET_DBA_ERR_OPTI);

    if (listOptiHeadPtr->listNbr == listOptiHeadPtr->allocNbr)
    {
        listOptiHeadPtr->allocNbr += 32;

        if ((listOptiHeadPtr->listTab = (DBA_LISTOPTI_STP)
            REALLOC(listOptiHeadPtr->listTab,
            listOptiHeadPtr->allocNbr * sizeof(DBA_LISTOPTI_ST))) == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_REALLOC);
        }
    }

    newList = &(listOptiHeadPtr->listTab[listOptiHeadPtr->listNbr]);
    newList->listId = listId;
    newList->scriptTree = scriptTree;
    listOptiHeadPtr->listNbr++;

    return(RET_SUCCEED);
}

/************************************************************************
*   Function        :   DBA_AddListToListOpti()
*
*   Description     :
*
*   Functions call  :
*
*   Return          :   RET_CODE
*
*   Creation Date   :   DDV - REF5495 - 001206
*   Modif.          :
*
*************************************************************************/
RET_CODE DBA_SearchListInListOpti(DBA_LISTOPTIHEAD_STP listOptiHeadPtrParam,
    ID_T                 listId,
    PTR                  *scriptTree)
{
    DBA_LISTOPTIHEAD_STP listOptiHeadPtr = listOptiHeadPtrParam;
    int i = 0;

    *scriptTree = nullptr;

    if (listOptiHeadPtr == nullptr &&
        (listOptiHeadPtr = DBA_GetListOptiHeadPtr()) == nullptr)
        return(RET_SUCCEED);

    for (i = 0; i<listOptiHeadPtr->listNbr; i++)
    {
        if (listOptiHeadPtr->listTab[i].listId == listId)
        {
            *scriptTree = listOptiHeadPtr->listTab[i].scriptTree;
            return(RET_SUCCEED);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_LoadServerInfos()
*
*   Description          : set Event sched records linked to current server to "failed"
*
*   Functions call       :
*
*   Return               : a DBA_DYNFLD_STP pointer
*
*   Creation Date        : 11.06.96 - PEC - Ref.: DVP137
*   Last Modif           :
*************************************************************************/
RET_CODE DBA_LoadServerInfos(ID_T serverId)
{
    if (SYS_IsSrvMode())
    {
        DBA_DYNFLD_STP ioId = nullptr;
        int connectNo = DBA_CONN_NOT_FOUND;

        if (serverId == 0 && /* REF11767 - LJE - 060412 */
            SERV_GetServerInfo(A_ServConnect_Id, &serverId) != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Cannot get server_connect record");
            return(DBI_FAIL);
        }

        ioId = ALLOC_DYNST(Io_Id);

        SET_ID(ioId, Io_Id_Id, serverId);

        connectNo = DBA_GetConnection(SqlServer, ROLE_ADMIN);

        DBA_Notif(EventSched, UNUSED, Io_Id, ioId, &connectNo, DBA_SET_CONN);

        FREE_DYNST(ioId, Io_Id);
    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_ConfigureNewPool
*
*   Description          : Configure a new connection pool
*
*   Arguments            :  Connection description
*                           User password
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - 171116 - DDV
*   Last Modification    :
*
*************************************************************************/
static void DBA_ConfigureNewPool(const AAAConnectionDescription connectionDescription,
                                 const PasswordEncrypted& userPassword)
{
    int                    maxSqlConn = 0;
    int                    connTimeout = 0;
    int                    connAging = 0;
    int                    minConnect = 0;
    AAADisconnectionPolicy discPolicy = AAADisconnectionPolicy::DisconnectAtDelete;

    GEN_GetApplInfo(ApplSqlSync, &maxSqlConn);
    GEN_GetApplInfo(ApplConnPoolUnusedTimeout, &connTimeout);
    GEN_GetApplInfo(ApplConnPoolAgedTimeout, &connAging);
    GEN_GetApplInfo(ApplConnPoolMinSize, &minConnect);

    if (connectionDescription.getRole() == ROLE_USER)
    {
        if (connTimeout > 0)
        {
            discPolicy = AAADisconnectionPolicy::DisconnectAtUnusedConnTimeout;
        }
    }
    else if (connectionDescription.getRole() != ROLE_INIT && SYS_IsSrvMode()) /* PMSTA-28916 - LJE - 171218 */
    {
        discPolicy = AAADisconnectionPolicy::DisconnectAtRelease;
        minConnect = 0;
    }

    AAAAgingPolicy agingPolicy = connAging > 0 ? AAAAgingPolicy::Aging : AAAAgingPolicy::NoAging;

    const AAAConnectionPolicies poolPolicies = AAAConnectionPolicies(
        AAAConnectionPolicy::ConnectAtCreate,
        discPolicy,
        connTimeout,
        agingPolicy,
        connAging);
    
    const AAAConnectionPoolConfiguration poolConfig = AAAConnectionPoolConfiguration(
        connectionDescription,
        maxSqlConn,
        minConnect,
        userPassword,
        poolPolicies);

    AAALocalConnectionProvider::get().configure(poolConfig);
}

/************************************************************************
*   Function             : DBA_ValidateDatabaseCredential()
*
*   Description          : Validate the credential against the current database
*
* 
*   Creation Date        : PMSTA-49139 - FME - 2022-06-03
*
*************************************************************************/
RET_CODE DBA_ValidateDatabaseCredential(const char* userName, const  PasswordEncrypted& userPassword)
{
    RET_CODE ret = RET_DBA_ERR_CANNOTCONNECT;
    if (userName == nullptr)
    {
        ret =  RET_DBA_ERR_ARGNOMATCH;
        return ret;
    }
    std::string _userName(userName);

    AAAConnectionProvider& conProvider = AAAConnectionProvider::getConnectionProviderInstance();

    bool valid = conProvider.validateDatabaseCredential(_userName,userPassword);

    if (valid) 
    {
       ret = RET_SUCCEED;
    }
 
    return ret;
}


/************************************************************************
*   Function             : DBA_OpenConnForUser()
*
*   Description          : Choose a Free or UnmountedConn connection, open the
*                          connection with the given user and password and return
*                          the connection pointer
*
*   Arguments            : user         : the user login
*                          password     : the user password
*                          dbiConn      : DbiConnection pointer
*                          paramRole    : Connection role
*
*
*   Return               : RET_SUCCEED               : if ok
*                          RET_DBA_ERR_CONNOTFOUND   : if no free connection found
*                          RET_DBA_ERR_CANNOTCONNECT : if connection cannot be established
*
*   Creation Date        : 12.06.96 - PEC     - Ref.: DVP096
*   Last Modification    : 13.11.96 - PEC     - Ref.: DVP249
*                          14.07.97 - GRD/PEN - Ref.: BUG432
*                          27.09.99 - GRD     - Ref.: REF3847.
*                          27.10.05 - DLA     - REF11420
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-18429 - 210714 - PMO : Server is blocked, deadlock on mutex
*                          PMSTA-26108 - 171116 - DDV : Manage new role ROLE_USERCHECK. When this role is use, pool for ROLE_USER is also create.
*                          PMSTA-29708 - DLA - 20180507 : If the User has changed his password, the users' pools are modified accordingly
*                          PMSTA-49139 - LJE/FME - 20220617 : Password is not always checked in http RPC calls (remove role ROLE_USERCHECK)
*
*************************************************************************/
RET_CODE DBA_OpenConnForUser(const char *user, const  PasswordEncrypted& userPassword, DbiConnection** paramDbiConn, AAAConnectionRole paramRole)
{
    RET_CODE       ret = RET_SUCCEED;
    std::string    sqlServerNameString;
    std::string    userString(user);

//    AAATracer::AAAScopedSpan OpenConn(AAATelemetry::GetTracer(AAATracer::Trace::HttpServerDetailed).startNewSpan("OpenConnForUser"));


    GEN_GetApplInfo(ApplSqlServerName, sqlServerNameString);

    AAAConnectionDescription cdParamRole(SqlServer, sqlServerNameString, paramRole);
    cdParamRole.setUser(userString);

    MemoryPool mp;
    AAAObject *lockConnectCliServ = new LockGuard(ServLockConnectCliServ, true, FILEINFO);
    mp.ownerObject(lockConnectCliServ);

    if (AAAConnectionProvider::getConnectionProviderInstance().hasPool(cdParamRole))
    {
        bool isCredentialValid = false;

        try
        {
            const bool credentialIdentical = AAAConnectionProvider::getConnectionProviderInstance().isCredentialIdentical(cdParamRole, userPassword);

            if (credentialIdentical == false)
            {
                mp.freeObject(lockConnectCliServ);

                if (RET_SUCCEED == DBA_ValidateDatabaseCredential(user, userPassword))
                {
                    isCredentialValid = true;

                    lockConnectCliServ = new LockGuard(ServLockConnectCliServ, true, FILEINFO);
                    mp.ownerObject(lockConnectCliServ);

                    AAAConnectionProvider::getConnectionProviderInstance().updatePassword(cdParamRole, userPassword);
                }
            }
            else
            {
                isCredentialValid = true;
            }

            if (isCredentialValid && paramDbiConn != nullptr)
            {
                mp.freeObject(lockConnectCliServ);

                *paramDbiConn = DBA_GetDbiConnection(cdParamRole);
                if (*paramDbiConn == nullptr)
                {
                    isCredentialValid = false;
                }
            }
        }
        catch (AAAPoolUsageException e)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_OpenConnForUser: Login error on last connection");
            ret = RET_DBA_ERR_CANNOTCONNECT;
        }

        if (isCredentialValid == false)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_OpenConnForUser: Login error");
            ret = RET_DBA_ERR_CANNOTCONNECT;
        }
    }
    else
    {
        DBA_ConfigureNewPool(cdParamRole, userPassword);

        try
        {

            /* Install session properties not done when using the global provider; so workaround to fix PMSTA-49525  PMSTA-49139 */
            AAAConnectionKind connectionKind = paramRole == ROLE_DBSO ? AAAConnectionKind::StandardConnection : AAAConnectionKind::UseGlobalProvider;

            DbiConnection *dbiConn = DBA_GetDbiConnection(cdParamRole, connectionKind);
            if (dbiConn == nullptr)
            {
                AAALocalConnectionProvider::get().unconfigure(cdParamRole);
                ret = RET_DBA_ERR_CANNOTCONNECT;
            }
            else
            {
                if (EV_AAAInstallLevel == 0 && paramRole != ROLE_DBSO)    /* DLA - PMSTA-30238 - 180215 */
                {
                    /* DLA - PMSTA-28051 - 170810 */
                    AAAConnectionDescription cdFinUser(FinServer, std::string(), paramRole);
                    cdFinUser.setUser(userString);

                    /* a pool already exists ? */
                    if (AAAConnectionProvider::getConnectionProviderInstance().hasPool(cdFinUser))
                    {
                        /* not normal, check why we forget to remove it */
                        assert(28051 == 0);
                    }
                    else
                    {
                        AAALocalConnectionProvider::get().configure(AAAConnectionPoolConfiguration(cdFinUser, 500, 0, userPassword,
                                                                                                   AAAConnectionPolicies(AAAConnectionPolicy::ConnectAtCreate, AAADisconnectionPolicy::DisconnectAtDelete, 0, AAAAgingPolicy::NoAging, 0)));
                    }
                }

                if (paramDbiConn != nullptr)
                {
                    *paramDbiConn = dbiConn;
                }

                ret = RET_SUCCEED;
            }
        }
        catch (AAAPoolUsageException& e)
        {
            AAALocalConnectionProvider::get().unconfigure(cdParamRole);
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, e.what());
            ret = RET_DBA_ERR_CANNOTCONNECT;
        }
    }
    return(ret);
}

/************************************************************************
*
*   Function          : SetServerUserToOnGuard constructor
*
*   Description       : Set Server User to On on current thread
*
*   Arguments         :
*
*   Return            :
*
*   Creation date     : PMSTA-29656 - DDV - 180110
*   Last modification :
*
*************************************************************************/
SetServerUserToOnGuard::SetServerUserToOnGuard()
{
    DBA_SetServerUserToOn();
}

/************************************************************************
*
*   Function          : SetServerUserToOnGuard destructor
*
*   Description       : Set Server User to Off on current thread when object is destroy
*
*   Arguments         :
*
*   Return            :
*
*   Creation date     : PMSTA-29656 - DDV - 180110
*   Last modification :
*
*************************************************************************/
SetServerUserToOnGuard::~SetServerUserToOnGuard()
{
    DBA_SetServerUserToOff();
}

void DBA_SetServerUserToOn()
{
    return SYS_SetThreadUseServerUser(true);
}

void DBA_SetServerUserToOff()
{
    return SYS_SetThreadUseServerUser(false);
}

void DBA_SetProxyUserToOn()
{
    return SYS_SetThreadUseProxyUser(true);
}

void DBA_SetProxyUserToOff()
{
    return SYS_SetThreadUseProxyUser(false);
}

/************************************************************************
*
*   Function          : CMP_OptiElementByAccess()
*
*   Description       : Function used by qsort() to sort
*                       optimized elements by access number
*
*   Arguments         : stp1  : Pointer on first element to compare
*                       stp2  : Pointer on second element to compare
*
*   Return            :
*
*   Creation date     : sme REF5506
*   Last modification : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
STATIC int CMP_OptiElementByAccess(const void *stp1, const void *stp2, const void *optiArgPtr)
{
    DBA_DYNFLD_STP st1, st2;
    int fldNbr;

    /* REF7264 - PMO */
    const int * i1 = (const int*)stp1;
    const int * i2 = (const int*)stp2;
    DBA_OPTI_STP optiPtr = (DBA_OPTI_STP)optiArgPtr;

    fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;
    st1 = optiPtr->dataPtr + ((*i1) * fldNbr);
    st2 = optiPtr->dataPtr + ((*i2) * fldNbr);


    if (GET_UINT(st1, Opti_TimeStamp) > GET_UINT(st2, Opti_TimeStamp))
        return(1);

    if (GET_UINT(st1, Opti_TimeStamp) < GET_UINT(st2, Opti_TimeStamp))
        return(-1);

    if (GET_UINT(st1, Opti_AccessNbr) > GET_UINT(st2, Opti_AccessNbr))
        return(1);

    if (GET_UINT(st1, Opti_AccessNbr) < GET_UINT(st2, Opti_AccessNbr))
        return(-1);

    return(0);
}

void disp_opti(DBA_OPTI_ENUM optiIdx, DBA_OPTIMODE_ENUM optiMode, int options)
{
    int                        fldNbr, i, k;
    DBA_PROC_STP               proc;
    DBA_PROCPARAM_STP          procParam;
    DBA_DYNFLD_STP             dataPtr;
    DBA_OPTI_STP               optiPtr;
    char                       dataStr[255], buffer[400], inputBuf[2000];

    switch (optiMode)
    {
    case Opti_Local:
    {
        if (SYS_IsSrvMode())
        {
            optiPtr = SYS_GetThreadDataCtxServer()->getOptiPtr() + (optiIdx);  /* DLA - PMSTA*** - 170330 */
        }
        else
        {
            optiPtr = EV_OptiPtr + (optiIdx);
        }

        LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, FALSE == SYS_IsSrvMode(), FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

        proc = (DBA_PROC_STP)optiPtr->procPtr;
        printf("\nProcedure \"%s\"\n", proc->procName != nullptr ? proc->procName : " ");

        if (optiPtr->dataPtr == nullptr)
        {
            printf("\nNo Data\n");
            return;
        }

        dataPtr = optiPtr->dataPtr;
        procParam = proc->procParamDefPtr;
        fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

        for (i = 0; i < (int)optiPtr->eltNbr; i++)
        {
            inputBuf[0] = END_OF_STRING;

            for (k = 0; k < optiPtr->inputArgNbr; k++)
            {
                DBI_FldToDbDataStr(dataStr, sizeof(dataStr),
                    dataPtr,
                    1 + k,
                    GET_FLD_TYPE(*(proc->inputDynStPtr),
                    *(procParam[k].fldNbrPtr)), nullptr, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                sprintf(buffer, "%s=%s,", procParam[k].paramName, dataStr);
                strcat(inputBuf, buffer);
            }

            printf("\nAccess : %4d, %s  ", GET_UINT(dataPtr, Opti_AccessNbr),
                inputBuf);

            dataPtr += fldNbr;
        }

        printf("\nElement number : %4d\n", optiPtr->eltNbr);

        break;
    }
    case Opti_Global:
    {
        optiPtr = EV_OptiPtr + (optiIdx);
        LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, true, FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

        proc = (DBA_PROC_STP)optiPtr->procPtr;
        printf("\nProcedure \"%s\"\n", proc->procName != nullptr ? proc->procName : " ");

        if (optiPtr->dataPtr == nullptr)
        {
            printf("\nNo Data\n");
            return;
        }

        dataPtr = optiPtr->dataPtr;
        procParam = proc->procParamDefPtr;
        fldNbr = 1 + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

        for (i = 0; i < (int)optiPtr->eltNbr; i++)
        {
            inputBuf[0] = END_OF_STRING;

            for (k = 0; k < optiPtr->inputArgNbr; k++)
            {
                DBI_FldToDbDataStr(dataStr, sizeof(dataStr),
                    dataPtr,
                    1 + k, /* REF8844 - LJE - 030324 */
                    GET_FLD_TYPE(*(proc->inputDynStPtr),
                    *(procParam[k].fldNbrPtr)), nullptr, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                sprintf(buffer, "%s=%s,", procParam[k].paramName, dataStr);
                strcat(inputBuf, buffer);
            }

            printf("\nAccess : %4d, %s  ", GET_UINT(dataPtr, Opti_AccessNbr),
                inputBuf);

            dataPtr += fldNbr;
        }

        printf("\nElement number : %4d\n", optiPtr->eltNbr);

        break;
    }
    case Opti_LocalGlobal:
        {

        if (SYS_IsSrvMode())
        {
            optiPtr = SYS_GetThreadDataCtxServer()->getOptiPtr() + (optiIdx);   /* DLA - PMSTA*** - 170330 */
        }
        else
        {
            optiPtr = EV_OptiPtr + (optiIdx);
        }

        LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, FALSE == SYS_IsSrvMode(), FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

        proc = (DBA_PROC_STP)optiPtr->procPtr;
        printf("\nProcedure \"%s\"\n", proc->procName);

        dataPtr = optiPtr->dataPtr;
        procParam = proc->procParamDefPtr;
        fldNbr = 1 + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

        printf("\nData in LOCAL optimisation\n");

        for (i = 0; i < (int)optiPtr->eltNbr; i++)
        {
            inputBuf[0] = END_OF_STRING;

            for (k = 0; k < optiPtr->inputArgNbr; k++)
            {
                DBI_FldToDbDataStr(dataStr, sizeof(dataStr),
                    dataPtr,
                    1 + k, /* REF8844 - LJE - 030324 */
                    GET_FLD_TYPE(*(proc->inputDynStPtr),
                    *(procParam[k].fldNbrPtr)), nullptr, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                sprintf(buffer, "%s=%s,", procParam[k].paramName, dataStr);
                strcat(inputBuf, buffer);
            }

            printf("\nAccess : %4d, %s  ", GET_UINT(dataPtr, Opti_AccessNbr),
                inputBuf);

            dataPtr += fldNbr;
        }

        if (optiPtr->dataPtr == nullptr)
        {
            printf("\nNo Data\n");
            return;
        }
        else
            printf("\nElement number : %4d\n", optiPtr->eltNbr);

        if (SYS_IsSrvMode())
        {
            optiPtr = EV_OptiPtr + (optiIdx);

            if (optiPtr->dataPtr == nullptr)
            {
                printf("\nNo Data\n");
                return;
            }

            dataPtr = optiPtr->dataPtr;
            proc = (DBA_PROC_STP)optiPtr->procPtr;
            procParam = proc->procParamDefPtr;
            fldNbr = 1 + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

            printf("\nData in GLOBAL optimisation\n");

            for (i = 0; i < (int)optiPtr->eltNbr; i++)
            {
                inputBuf[0] = END_OF_STRING;

                for (k = 0; k<optiPtr->inputArgNbr; k++)
                {
                    DBI_FldToDbDataStr(dataStr, sizeof(dataStr),
                        dataPtr,
                        1 + k, /* REF8844 - LJE - 030324 */
                        GET_FLD_TYPE(*(proc->inputDynStPtr),
                        *(procParam[k].fldNbrPtr)), nullptr, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    sprintf(buffer, "%s=%s,", procParam[k].paramName, dataStr);
                    strcat(inputBuf, buffer);
                }

                printf("\nAccess : %4d, %s  ", GET_UINT(dataPtr, Opti_AccessNbr),
                    inputBuf);

                dataPtr += fldNbr;
            }

            printf("\nElement number : %4d\n", optiPtr->eltNbr);

        }

        break;
    }
    }

}


/************************************************************************
**
**  Function    :   DBA_CopyDynByHierarchy
**
**  Description :   DBA_Copy call from given hierarchy.
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation    :   ROI - 970628 - DVP200
**  Modif       :   HFI-PMSTA-52524-2023-03-17  provide connection helper to avoid dead lock
**
*************************************************************************/
RET_CODE DBA_CopyDynByHierarchy(OBJECT_ENUM entity,
                                DBA_DYNFLD_STP admArg,
                                DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE retCode = RET_GEN_ERR_INVARG;

    if (SYS_IsGuiMode())
    {
        return GUI_DbaCopyFromHier(entity, admArg, dbiConnHelper);
    }
    return retCode;
}

/************************************************************************
**
**  Function    :   DBA_GetShDynByHierarchy
**
**  Description :   DBA_Get call from given hierarchy.
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Cr?ation    :   ROI - 970130 - DVP200
**
*************************************************************************/
RET_CODE DBA_GetShDynByHierarchy (  OBJECT_ENUM entity,
                                    DBA_DYNFLD_STP admArg,
                                    DBA_DYNFLD_STP* shortPtr,
                                    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE retCode = RET_GEN_ERR_INVARG;

    if (SYS_IsGuiMode())
    {
        return GUI_DbaGetFromHier(entity,
            admArg,
            shortPtr,
            &dbiConnHelper.getId(),
            dbiConnHelper.dbaGetOptions()
        );
    }

    return retCode;
}

/************************************************************************
*
*   Function          : DBA_HandleExportedRecord()
*
*   Description       : Function called by SCPT_EvalCstList which solve
*                       each column script and send these columns to client
*                       program.
*
*   Arguments         : objectEnum : an OBJECT_ENUM member (Curr, Instr, ...)
*                       record     : the current record in the list
*                       connectNo  : a connection number used to solve the list
*
*   Return            : RET_SUCCEED     : if ok
*
*   Creation date     : 28.04.97 - PEC - Ref.: DVP437
*   Last modification : 98.10.20 - OCE - REF1317
*
*************************************************************************/
RET_CODE DBA_HandleExportedRecord(OBJECT_ENUM        objectEnum,
                                  DBA_DYNFLD_STP     record,
                                  int                counter,
                                  char              *errBuffer,
                                  bool               isExpOutbox,
                                  DbiConnection     *dbiConn)
{

    if (SYS_IsSrvMode())
    {
        if(SYS_IsStateShutdownRequested())
        {   /* PMSTA-54362 - JBC - 30112023 */
            return RET_SYS_ERR_SIGINT;
        }
        RET_CODE retStatus = RET_SUCCEED;
        char * maxCountStr = nullptr;
        static FLAG_T maxCountInitFlg = FALSE; /* static flag to avoid repeated heavy calls to SYS_Getenv() */
        int sSize = 0;
        int i;
        int maxCount = 100;
        DICT_ENTITY_STP     entityStp = nullptr;       

        if (maxCountInitFlg == FALSE)
        {
            if ((maxCountStr = SYS_GetEnv("AAAEXPORTDATAPURGERECNBR")) != nullptr) {
                sSize = (short)strlen(maxCountStr);
                for (i = 0; (i < sSize) && (maxCountStr[i] >= '0') && (maxCountStr[i] <= '9'); i++);
                if (i == sSize)
                    (void)sscanf(maxCountStr, "%d", &maxCount);
                if (maxCount <= 0)
                    maxCount = 100; /* Defaulting Max Count to 100 */
            }
            maxCountInitFlg = TRUE;
        }

        /* PMSTA-20515 - DDV - 150618 - Compute DV on Virtual fields, on questionnaire only to avoid bad performance impact on precomp. */
        if ((entityStp = DBA_GetDictEntitySt(objectEnum)) != nullptr &&
            entityStp->entNatEn == EntityNat_Questionnaire)
        {
            SCPT_ComputeDVOnVirtual(objectEnum, record);
        }

        if (isExpOutbox && dbiConn != nullptr)
        {
            FLAG_T flagActivateDES = FALSE;
            GEN_GetApplInfo(ApplDesFlag, &flagActivateDES);

            OutboxEventModeEn applOutboxEventModeEn = OutboxEventModeEn::None;
            GEN_GetApplInfo(ApplOutboxEventModeEnum, &applOutboxEventModeEn);

            std::set<SubscriptionNatEn> subsNatEnSet;

            if (flagActivateDES == TRUE)
            {
                subsNatEnSet.insert(SubscriptionNatEn::Outbox);
            }
            if (applOutboxEventModeEn == OutboxEventModeEn::Subscription)
            {
                subsNatEnSet.insert(SubscriptionNatEn::OutboxEvent);
            }

            for (auto &subsNatEn : subsNatEnSet)
            {
                MemoryPool mp;
                DBA_DYNFLD_STP inputData = mp.allocDynst(FILEINFO, A_Subscription);
                DBA_DYNFLD_STP* aSubscrTab = NULLDYNSTPTR;
                int aSubscrNb = 0;
                DICT_T entityDictId;
                DBA_GetDictId(objectEnum, &entityDictId);

                SET_DICT(inputData, A_Subscription_EntityDictId, entityDictId);
                SET_A_Subscription_ActionEn(inputData, SubscriptionActionEn::AllDBAccess);
                SET_A_Subscription_ModuleEn(inputData, SubscriptionModuleEn::All);
                SET_A_Subscription_NatEn(inputData, subsNatEn);

                /* get outbox subs - optimized */
                retStatus = DBA_Select2(Subscription,
                                        UNUSED,
                                        A_Subscription,
                                        inputData,
                                        A_Subscription,
                                        &aSubscrTab,
                                        UNUSED,
                                        UNUSED,
                                        &aSubscrNb,
                                        UNUSED,
                                        UNUSED);

                mp.ownerDynStpTab(aSubscrTab, aSubscrNb);
                if (retStatus == RET_SUCCEED && aSubscrNb > 0)
                {
                    SERV_GetCurrConnStructPtr()->exportGenCtx.subsNbr++;
                    retStatus = DBA_LogSubscriptionEvents(objectEnum,
                                                          SUBSCRIPTION_ACTION_ENUM::Subscription_Action_Insert,
                                                          GET_DYNSTENUM(record),
                                                          record,
                                                          NULLDYNST,
                                                          *dbiConn,
                                                          aSubscrTab,
                                                          aSubscrNb);
                }
                else if (applOutboxEventModeEn != OutboxEventModeEn::Entity)
                {
                    retStatus = RET_DBA_ERR_NODATA;
                    MSG_LogSrvMesg(UNUSED, UNUSED, SYS_Stringer("No valid Outbox Subscription found for Entity ", DBA_GetDictEntitySqlName(objectEnum)).c_str());
                }
            }

            if (applOutboxEventModeEn == OutboxEventModeEn::Entity)
            {
                dbiConn->getOutboxManager().addRecord(record, Insert, applOutboxEventModeEn);
            }
        }
        else
        {
            retStatus = SERV_SendExportedDataToClient(record, errBuffer);        /* REF1317 - OCE - 981020 */
        }

        if (counter % maxCount)
        {
            DBA_PurgeTmpHierEltRecords(nullptr);
        }

        return retStatus;
    }
    else
    {
        return(RET_SUCCEED);
    }
}

/************************************************************************
*   Function             : DBA_SendSubscriptionOutbox()
*
*   Description          : Send Subscription buffer for outbox
*   Arguments            : 
*
*   Return               : RET_CODE
*
*   Creation Date        : PMSTA-52258 - JBC - 230308
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBA_SendSubscriptionOutbox(DbiConnection & dbiConn, bool forceSend)
{
    RET_CODE ret = RET_SUCCEED;
    if(dbiConn.getConnStructPtr()->subscriptionElem.accessNbr > 0)
    {
        static int commitSz = 0;
        if(commitSz <= 0)
        {
            GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);
        }

        if (forceSend || dbiConn.getConnStructPtr()->subscriptionElem.accessNbr > commitSz)
        {
            if ((ret = DBA_SendSubscriptionMulti(dbiConn.getConnStructPtr()->subscriptionElem.accessNbr,
                                                 dbiConn, 
                                                 DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR)) == RET_SUCCEED)
            {
                SERV_GetCurrConnStructPtr()->exportGenCtx.rowsNbr += dbiConn.getConnStructPtr()->subscriptionElem.accessNbr;
            }
            DBA_FreeSubscriptionBlock(dbiConn);
        }
    }
    return ret;
}

/* REF1317 - OCE - 981020 */
/* Begin                  */
/************************************************************************
*
*   Function          : DBA_GetUpdStatus()
*
*   Description       : Function called by SCPT_EvalCstList which gets
*                       the updstatus sgin and value from the export context
*                       stored into the connectio structure
*
*   Arguments         : connectNo  : a connection number
*           updStatus_sign  : updstatus sign
*           updStatus_val   : updstatus val
*
*   Return            : RET_SUCCEED     : if ok
*
*   Creation date     : 98/10/20 - OCE - Ref.: REF1317
*   Last modification :
*
*************************************************************************/
RET_CODE DBA_GetUpdStatus(ENUM_T *  updStatus_sign,
    INT_T  *  updStatus_val)
{
    return SERV_GetUpdStatusFromExpCtx(updStatus_sign, updStatus_val);
}
/* End                    */
/* REF1317 - OCE - 981020 */

/************************************************************************
*   Function      : DBA_IsEntityWatched()
*
*   Description   : Check if the given entity id is being watched,
*                   by the buffer cache.
*
*   Arguments     : entity Id     : request corresponding object
*
*   Return        : TRUE  if in cache.
*                   FALSE if not in cache.
*
*   Creation      : 16/05/97 - GRD DVP461.
*   Modification  :
*
*************************************************************************/
RET_CODE DBA_IsEntityWatched (OBJECT_ENUM entityId)
{
    DICT_T      modifStatDictId = 0;
    OBJECT_ENUM modifEnt;


    /* Search if one optimised table has been modified */
    for (int i = 0; i < SV_TabModifStatNbr; i++)
    {
        modifStatDictId = GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId);
        DBA_GetObjectEnum(GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId), &modifEnt);

        /* Found it?. */
        if (entityId == modifEnt)
        {
            return (TRUE);
        }
    }

    /* Not found. */
    return (FALSE);
}

/************************************************************************
*   Function      : DBA_IsEntityUpdated()
*
*   Description   : Check if the given entity id has been updated
*                   in the buffer cache.
*
*   Arguments     : entity Id     : request corresponding object
*
*   Return        : TRUE  if in updated.
*                   FALSE if not.
*
*   Creation      : 16/05/97 - GRD DVP461.
*
*   Modification  : PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
*
*************************************************************************/
RET_CODE DBA_IsEntityUpdated(OBJECT_ENUM entityId, DATETIME_T dateTime)
{
    OBJECT_ENUM modifEnt;
    DATETIME_T  databaseDate;
    HOUR_T      h, h2;
    MINUTE_T    m, m2;
    SECOND_T    s, s2;
    long        daysDiff = 0;


    /*
    * Return TRUE depending on 2 conditions:
    *  - Modif stat has been updated more recently than the given entity.
    *  - At least 1 day has passed since the last recalculation.
    */

    TIME_Get(dateTime.time, &h, &m, &s);

    DBA_GetDbDate(&databaseDate);

    LockGuard lock(ServLockForOptiPtr, true, FILEINFO);                                           /* PMSTA-20088 - 041015 - PMO */

    if (false == lock.isOk())                                                               /* PMSTA-20088 - 041015 - PMO */
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SERV_GetOptiPtr FAILED");
        return FALSE;
    }

    /* Search if one optimised table has been modified */
    for (int i = 0; i < SV_TabModifStatNbr; i++)
    {
        DBA_GetObjectEnum(GET_DICT(SV_TabModifStatPtr[i], A_TabModifStat_DictId), &modifEnt);

        /* Found it?. */
        if (entityId == (int)modifEnt)
        {
            /*
            * Is the last recalculation date older than a day?.
            */

			DATE_DaysBetween(databaseDate.date, dateTime.date, AccrRule_None, &daysDiff, 0); /* PMSTA-22396  - SRIDHARA ? 160430 */

            /* 0 means no difference. */
            if (daysDiff != 0)
            {
                return (TRUE);
            }

            /*
            * Is the last modif stat date newer than the last recalculation date.
            */

            DATETIME_T dateTime2 = GET_DATETIME(SV_TabModifStatPtr[i], A_TabModifStat_LastModifDate);

            if (DATE_Cmp(dateTime2.date, dateTime.date) > 0)
            {
                return (TRUE);
            }

            TIME_Get(dateTime2.time, &h2, &m2, &s2);

            /*
            * Is the last modif stat date the same than the last recalculation date.
            */

            if (DATE_Cmp(dateTime2.date, dateTime.date) == 0)
            {
                if (h2 > h)
                {
                    return (TRUE);
                }

                if (h2 == h)
                {
                    if (m2 > m)
                    {
                        return (TRUE);
                    }

                    if (m2 == m)
                    {
                        if (s2 > s)
                        {
                            return (TRUE);
                        }
                    }
                }

            }
        }
    }

    return (FALSE);
}

/************************************************************************
*   Function      : DBA_FinSelStratLnkById()
*
*   Description   : Call SERV_FinSelStratLnkById.
*
*   Arguments     :
*
*   Return        :
*
*   Creation      : 28/05/97 - GRD DVP486.
*
*   Modification  :
*
*************************************************************************/
RET_CODE DBA_FinSelStratLnkById(DBA_DYNFLD_STP searchLink,
    DBA_DYNFLD_STP **outputData,
    int            *rows)
{
    return SERV_FinSelStratLnkById(searchLink, outputData, rows);
}

/************************************************************************
*   Function      : DBA_SelStratLnkFct()
*
*   Description   : Call DBA_SelStratLnkById.
*
*   Arguments     :
*
*   Return        :
*
*   Creation      : 01/07/97 - GRD DVP529.
*
*   Modification  :
*
*************************************************************************/
RET_CODE DBA_SelStratLnkFct(OBJECT_ENUM,
                            DBA_DYNFLD_STP       searchLnkSt,
                            DBA_DYNFLD_STP       **stratLnkData,
                            int                  *dataRows,
                            DbiConnectionHelper& dbiConnHelper)
{
    return DBA_SelStratLnkById(searchLnkSt, stratLnkData, dataRows, dbiConnHelper);
}

/************************************************************************
*
*   Function          : DBA_GetHierOptiPtr()
*
*   Description       : Returns a pointer to a hierarchy stored after a
*                       load pos. (optimization purposes).
*
*   Arguments         :
*
*   Return            : DBA_HIER_HEAD_STP : if ok.
*
*   Creation date     : 970820 - GRD - Ref.: DVP563
*   Last modification :
*
*************************************************************************/
PTR DBA_GetHierOptiPtr(void)
{
    if (SYS_IsSrvMode() && SERV_StartedServer())
    {
        SERV_CONNECT_INFO_STP currInfo = SERV_GetCurrConnStructPtr();

        /*
        * BEWARE: Spawned threads do not own connections.
        */

        if (currInfo == nullptr)
            return(nullptr);
        else
            return((PTR)currInfo->hierarchyOptiPtr);
    }
    else
    {
        return(nullptr);
    }
}

/************************************************************************
*
*   Function          : DBA_FreeHierOptiPtr()
*
*   Description       : Free the pointer to a hierarchy.
*
*   Arguments         : DBA_HIER_HEAD_STP.
*
*   Return            : RET_SUCCEED.
*
*   Creation date     : 970820 - GRD - Ref.: DVP563
*   Last modification :
*
*************************************************************************/
RET_CODE DBA_FreeHierOptiPtr(PTR hierPtr)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP currInfo = SERV_GetCurrConnStructPtr();
        DBA_HIER_HEAD_STP   hierarchyOptiPtr = (DBA_HIER_HEAD_STP)hierPtr;

        /*
        * BEWARE: Spawned threads do not own connections.
        */

        if (currInfo == nullptr)
            return(RET_SUCCEED);

        if (currInfo->hierarchyOptiPtr == hierarchyOptiPtr)
            currInfo->hierarchyOptiPtr = nullptr;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*
*   Function          : DBA_SetHierOptiPtr()
*
*   Description       : Set the pointer to a hierarchy.
*                       (optimization purposes).
*
*   Arguments         : DBA_HIER_HEAD_STP.
*
*   Return            : RET_SUCCEED.
*                       RET_SRV_LIB_ERR_GENERAL.
*
*   Creation date     : 970820 - GRD - Ref.: DVP563
*   Last modification : 970820 - GRD - Ref.: BUG465
*                       970829 - GRD - Ref.: BUG476
*************************************************************************/
RET_CODE DBA_SetHierOptiPtr(PTR hierPtr)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP currInfo = SERV_GetCurrConnStructPtr();
        DBA_HIER_HEAD_STP   hierarchyOptiPtr = (DBA_HIER_HEAD_STP)hierPtr;

        /*
        * BEWARE: Spawned threads do not own connections.
        */

        if (currInfo == nullptr)
            return(RET_SUCCEED);

        if (currInfo->hierarchyOptiPtr != nullptr)
        {
            if (currInfo->hierarchyOptiPtr != hierarchyOptiPtr)
            {
                currInfo->hierarchyOptiPtr = nullptr;
            }

            return(RET_SUCCEED);
        }

        currInfo->hierarchyOptiPtr = hierarchyOptiPtr;
    }

    return(RET_SUCCEED);
}


/************************************************************************
*
*   Function            :   DBA_GetEvalEntityFlag()
*
*   Description         :   Returns a flag to know if we are in an
*                           eval_entity process
*
*   Arguments           :
*
*   Return              :   FLAG_T
*
*   Creation            :   FPL-PMSTA09698-100604
*
*************************************************************************/
FLAG_T  DBA_GetEvalEntityFlag(void)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP currInfo = SERV_GetCurrConnStructPtr();

        /*
        * BEWARE: Spawned threads do not own connections.
        */

        if (currInfo == nullptr)
            return(FALSE);
        else
            return currInfo->bIsEvalEntityMode;
    }
    else
    {
        return(FALSE);
    }
}

/************************************************************************
*
*   Function            :   DBA_SetEvalEntityFlag()
*
*   Description         :   Set a flag to know if we are in an
*                           eval_entity process
*
*   Arguments           :   FLAG_T
*
*   Return              :   RET_SUCCEED.
*
*   Creation            :   FPL-PMSTA09698-100604
*
*************************************************************************/
RET_CODE    DBA_SetEvalEntityFlag(FLAG_T bIsEvalEntityMode)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP currInfo = SERV_GetCurrConnStructPtr();

        /*
        * BEWARE: Spawned threads do not own connections.
        */

        if (currInfo == nullptr)
            return(RET_SUCCEED);

        currInfo->bIsEvalEntityMode = bIsEvalEntityMode;
    }

    return(RET_SUCCEED);
}


/************************************************************************
*
*   Function           : DBA_OptiGetUsedSize()
*
*   Description        : Evaluate memory used by optimised table for one procedure.
*
*   Arguments          : procPtr  pointer on optimised procedure
*                        optimode Global or Local
*                        detailed if 0 only bloc size if 1 bloc size and all record size
*                        total    Total memory used
*                        file     log file
*
*   Return             : nothing
*
*  Creation Date       : DDV - 990409
*
*  Last modif.         : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*                        PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*************************************************************************/
void DBA_OptiGetUsedSizeByProc(DBA_PROC_STP procPtr, DBA_OPTIMODE_ENUM optiMode, int detailed, LONGINT_T *total, FILE *file)
{
    DBA_PROCPARAM_STP    procParam;
    DBA_OPTI_STP         optiPtr = nullptr;
    DBA_PROC_STP         proc = procPtr;
    size_t               inRecSz = 0;                  /* PMSTA-17133 - 051113 - PMO */
    size_t               outRecSz = 0;                  /* PMSTA-17133 - 051113 - PMO */
    size_t               recSz = 0;                  /* PMSTA-17133 - 051113 - PMO */
    size_t               multiArrayTheoSz;                       /* PMSTA-17133 - 051113 - PMO */
    size_t               strTheoSz;                              /* PMSTA-17133 - 051113 - PMO */
    size_t               arrayTheoSz;                            /* PMSTA-17133 - 051113 - PMO */
    short                extEltNbr = 0, multDim1 = 0, multDim2 = 0;
    int          k, l, outArgNb, inArgNbr, fieldNbr = 0, pos = 0, argPos = 0;
    DBA_DYNST_ENUM           outputDynSt;
    DBA_DYNFLD_STP           *optiDataTab = nullptr;
    DBA_DYNFLD_STP           optiData = nullptr;
    int                      dataNbr = 0;

    *total = 0;

    if (optiMode == Opti_Local)
    {
        if (SYS_IsSrvMode())
        {
            if (SERV_GetOptiPtr(procPtr, &optiPtr) != TRUE)
                optiPtr = nullptr;
        }
    }
    else if (optiMode == Opti_Global)
        optiPtr = EV_OptiPtr + (proc->optiIdx);

    if (optiPtr == nullptr)
    {
        if (file)
            fprintf(file, "\n  Nothing in Local Buffer");
        return;
    }

    LockGuard lock(optiPtr->globalLock, LockGuard::Access::read, FALSE == SYS_IsSrvMode(), FILEINFO);   /* DLA - PMSTA-26864 - 170404 */

    if (optiPtr->dataPtr == nullptr)
    {
        if (optiMode == Opti_Local)
        {
            if (file)
                fprintf(file, "\n  Nothing in Local Buffer");
            return;
        }
        else if (optiMode == Opti_Global)
        {
            if (file)
                fprintf(file, "\n  Nothing in Global Buffer");
            return;
        }
    }

    procParam = (DBA_PROCPARAM_STP)proc->procParamDefPtr;

    fieldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

    inArgNbr = optiPtr->inputArgNbr;
    /*dataPtr = optiPtr->dataPtr;*/

    /* Get input argument number and
    theoric size for strings and arrays */
    for (l = 0; l < (int)(optiPtr->eltNbr); l++)
    {
        strTheoSz = arrayTheoSz = multiArrayTheoSz = 0;
        multDim1 = multDim2 = 0;
        recSz = inRecSz = outRecSz = 0;               /* PMSTA15907 - DDV - 130206 - Wrong size reported by opti_stat */

        /* dataPtr contains access number, input and output args */
        /*dataPtr = GET_DYNFLDSTP(optiPtr->dataPtr, l, fieldNbr);*/

        for (argPos = 0; argPos < inArgNbr; argPos++)
        {
            pos = (l * fieldNbr) + Opti_FirstIn + argPos;

            if (IS_NULLFLD(optiPtr->dataPtr, pos) == FALSE)
            {
                if (IS_STRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                {
                    strTheoSz += SYS_StrLen(optiPtr->dataPtr[pos].data.strData.ptr);
                }
                else
                    if (IS_USTRINGFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                    {
                        strTheoSz += 2 * u_strlen(optiPtr->dataPtr[pos].data.ustrData.ptr);
                    }

                if (IS_ARRAYFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                {
                    auto eltNbr = GET_ARRAY_ELTNBR(optiPtr->dataPtr, pos);
                    auto eltSiz = GET_ARRAY_ELTSZ(optiPtr->dataPtr, pos);
                    arrayTheoSz += eltNbr * eltSiz;
                }

                if (IS_MULTIARRAYFLD(*(proc->inputDynStPtr), *(procParam[argPos].fldNbrPtr)) == TRUE)
                {
                    multDim1 = GET_MULTIARRAY_DIM1(optiPtr->dataPtr, pos);
                    multDim2 = GET_MULTIARRAY_DIM2(optiPtr->dataPtr, pos);;
                    multiArrayTheoSz += sizeof(double) * (multDim1 * multDim2);
                }
            }
        }

        inRecSz = optiPtr->inputArgNbr * sizeof(DBA_DYNFLD_ST);
        inRecSz += strTheoSz;
        inRecSz += arrayTheoSz;
        inRecSz += multiArrayTheoSz;

        strTheoSz = arrayTheoSz = multiArrayTheoSz = 0;
        multDim1 = multDim2 = extEltNbr = 0;

        /* output structure (1 = access number)  */
        /*dataPtr = dataPtr + (1 + optiPtr->inputArgNbr);*/
        optiData = &(optiPtr->dataPtr[(l * fieldNbr) + Opti_FirstIn + optiPtr->inputArgNbr]);
        if (proc->action == Get)
        {
            optiDataTab = nullptr;
            dataNbr     = 1;
            outputDynSt = *(proc->outputDynStPtr);
            outArgNb    = GET_FLD_NBR(outputDynSt);
        }
        else if (proc->action == Select  &&
            IS_NULLFLD(optiData, Select_Res_Tab_DataTab) == FALSE)
        {

            optiDataTab = GET_EXTENSION_PTR(optiData, Select_Res_Tab_DataTab);
            dataNbr     = GET_EXTENSION_NBR(optiData, Select_Res_Tab_DataTab);
            outputDynSt = GET_EXTENSION_TP(optiData, Select_Res_Tab_DataTab);   /* REF7264 - PMO */
            outArgNb    = GET_FLD_NBR(outputDynSt);
        }
        else
        {
            optiDataTab = nullptr;
            optiData    = nullptr;
            dataNbr     = 0;
            outArgNb    = 0;
            outputDynSt = NullDynSt;
        }

        for (k = 0; k<dataNbr; k++)
        {
            if (optiDataTab != nullptr)
                optiData = optiDataTab[k];

            for (argPos = 0; argPos < outArgNb; argPos++)
            {
                if (IS_NULLFLD(optiData, argPos) == FALSE)
                {
                    if (IS_STRINGFLD(outputDynSt, argPos) == TRUE)
                    {
                        strTheoSz += SYS_StrLen(optiData[argPos].data.strData.ptr);
                    }
                    else
                        if (IS_USTRINGFLD(outputDynSt, argPos) == TRUE)
                        {
                            strTheoSz += 2 * u_strlen(optiData[argPos].data.ustrData.ptr);
                        }


                    if (IS_ARRAYFLD(outputDynSt, argPos) == TRUE)
                    {
                        auto eltNbr = GET_ARRAY_ELTNBR(optiData, argPos);
                        auto eltSiz = GET_ARRAY_ELTSZ(optiData, argPos);
                        arrayTheoSz += eltNbr * eltSiz;
                    }

                    if (IS_MULTIARRAYFLD(outputDynSt, argPos) == TRUE)
                    {
                        multDim1 = GET_MULTIARRAY_DIM1(optiData, argPos);
                        multDim2 = GET_MULTIARRAY_DIM2(optiData, argPos);
                        multiArrayTheoSz += sizeof(double) * (multDim1 * multDim2);
                    }
                }
                outRecSz += sizeof(DBA_DYNFLD_ST);
            }
        }

        if (optiDataTab != nullptr)
            outRecSz = GET_FLD_NBR(Select_Res_Tab) * sizeof(DBA_DYNFLD_ST);
        outRecSz += strTheoSz;
        outRecSz += arrayTheoSz;
        outRecSz += multiArrayTheoSz;

        recSz = inRecSz + outRecSz + sizeof(DBA_DYNFLD_ST);

        if (detailed == 1 && file)
        {
            if (proc->action == Get)
            {
                fprintf(file, "\n   record size : input " szFormatSizeof "\t output " szFormatSizeof, inRecSz, outRecSz);                             /* PMSTA-17133 - 051113 - PMO */
            }
            else
            {
                fprintf(file, "\n   records size : input " szFormatSizeof "\t output " szFormatSizeof " (%d records)", inRecSz, outRecSz, dataNbr);   /* PMSTA-17133 - 051113 - PMO */
            }
        }

        /*totLoc += (recSz * optiPtr->locMaxAllocNbr);*/
        (*total) += (LONGINT_T)recSz;
    }

    /* Add index size */

    if (optiPtr->optiIndex)
    {
        *total += (LONGINT_T)(optiPtr->eltNbr * sizeof(int));
    }

    if (optiMode == Opti_Local)
    {
        if (file)
            fprintf(file, "\n  Local memory size : " szSimpleFormatLongInt"\t (%d records used and %d allocated)",
            *total, optiPtr->eltNbr, optiPtr->allocNbr);
    }
    else if (optiMode == Opti_Global)
    {
        if (file)
            fprintf(file, "\n  Global memory size : " szSimpleFormatLongInt"\t (%d records used and %d allocated)",
            *total, optiPtr->eltNbr, optiPtr->allocNbr);
    }
}


/************************************************************************
*
*   Function           : DBA_GetCurrThread()
*
*   Description        : Return a string containing the current thread address.
*
*   Arguments          : none.
*
*   Return             : A string.
*
*  Creation Date       : GRD - 991013 - REF3847.
*
*************************************************************************/
const void * DBA_GetCurrThread(void)
{
    return SYS_GetTlsThread();
}


/************************************************************************
**
** Function    : DBA_CmpProcInputArg
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : sme (Thursday December 07 2000) REF5506
**
************************************************************************/
int DBA_CmpProcInputArg(DBA_DYNFLD_STP inputArg, DBA_DYNFLD_STP inputArgCache, int inputArgNbr, DBA_PROC_STP   proc)
{
    int cmp=0;

    for (int i = 0 ; i < inputArgNbr; i++)
    {
        if ((cmp = CMP_DYNFLD(inputArg, inputArgCache, i, i, GET_FLD_TYPE(*(proc->inputDynStPtr), *(proc->procParamDefPtr[i].fldNbrPtr))))!= 0)
            return(cmp);
    }
    return(cmp);
}

/************************************************************************
**
** Function    : DBA_CmpAllInputArg
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-24030 - DDV - 161220 - add check on max dlm_e (main and add.) and data_profile
**             : PMSTA-36451 - DDV - 190708 - Manage case when all arguments are given from cache
**
************************************************************************/
int DBA_CmpAllInputArg(DBA_DYNFLD_STP inputArg,
                       DBA_DYNFLD_STP optiRecPtr,
                       DBA_OPTI_STP   optiPtr,
                       DBA_PROC_STP   proc,
                       FLAG_T         inputArgFromCache)  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
{
    int            cmp = 0;

    if (inputArgFromCache == TRUE)
    {
        if ((cmp = DBA_CmpProcInputArg(inputArg + Opti_FirstIn, optiRecPtr + Opti_FirstIn, optiPtr->inputArgNbr, proc)) != 0)
            return(cmp);
    }
    else
    {
        if ((cmp = DBA_CmpProcInputArg(inputArg, optiRecPtr + Opti_FirstIn, optiPtr->inputArgNbr, proc)) != 0)
            return(cmp);
    }


    if (optiPtr->checkDlmeMaxFlg == TRUE)
    {
        if (inputArgFromCache == TRUE)
        {
            if ((cmp = CMP_DYNFLD(inputArg, optiRecPtr, Opti_MainDlmEMax, Opti_MainDlmEMax, EnumType)) != 0)
                return(cmp);

            if ((cmp = CMP_DYNFLD(inputArg, optiRecPtr, Opti_AddDlmEMax, Opti_AddDlmEMax, EnumType)) != 0)
                return(cmp);
        }
        else
        {
            DLM_ENUM mainDlmEMax = DBA_GetConnProviderSessionProperties().getMainDlmEnMax();

            if ((cmp = CMP_ENUM(static_cast<ENUM_T>(mainDlmEMax), GET_ENUM(optiRecPtr, Opti_MainDlmEMax))) != 0)
                return(cmp);

            DLM_ENUM addDlmEMax = DBA_GetConnProviderSessionProperties().getAddDlmEnMax();

            if ((cmp = CMP_ENUM(static_cast<ENUM_T>(addDlmEMax), GET_ENUM(optiRecPtr, Opti_AddDlmEMax))) != 0)
                return(cmp);
        }

    }

    if (optiPtr->checkDataProfileFlg == TRUE)
    {
        if (inputArgFromCache == TRUE)
        {
            if ((cmp = CMP_DYNFLD(inputArg, optiRecPtr, Opti_DataProfileId, Opti_DataProfileId, IdType)) != 0)
                return(cmp);
        }
        else
        {
            DBA_DYNFLD_STP aApplUserTmp = SYS_GetThreadApplUser(true);

            if (aApplUserTmp != nullptr && IS_NULLFLD(aApplUserTmp, A_ApplUser_DataProfileId) == FALSE)
            {
                if ((cmp = CMP_ID(GET_ID(aApplUserTmp, A_ApplUser_DataProfileId), GET_ID(optiRecPtr, Opti_DataProfileId))) != 0)
                    return(cmp);
            }
            else
            {
                return(1);
            }
        }
    }

    if (optiPtr->checkBusinessEntityFlg == TRUE)
    {
        if (inputArgFromCache == TRUE)
        {
            if ((cmp = CMP_DYNFLD(inputArg, optiRecPtr, Opti_BusinessEntityId, Opti_BusinessEntityId, IdType)) != 0)
                return(cmp);
        }
        else
        {
            DBA_DYNFLD_STP aApplSessionStp = SYS_GetThreadApplSessionStp();

            if (aApplSessionStp &&
                (cmp = CMP_ID(GET_ID(aApplSessionStp, A_ApplSession_ConnectedBusEntityId), GET_ID(optiRecPtr, Opti_BusinessEntityId))) != 0)
            {
                return(cmp);
            }
        }
    }

    return(cmp);
}


/************************************************************************
**
** Function    : DBA_SearchElmtInIndexOpti
**
** Description : Search element in sorted table.
**
** Arguments   : ptrTab : table pointer (index)
nbElmt: element number in table pointer
proc: optimised proc.
inputArg: input arguments
inputArgNbr: nmuber of arguments in input
**               positionElmtToInsert: position in sorted table for insert element if
**                                        key not found.
** Return      : int : record number on element found by the key
**                     -1 if not found
**
** Creation    : sme (Wednesday December 06 2000) REF5506
**
************************************************************************/
int DBA_SearchElmtInIndexOpti(DBA_OPTI_STP optiPtr,
    DBA_PROC_STP   proc,
    DBA_DYNFLD_STP inputArg,
    int *positionElmtToInsert,
    FLAG_T inputArgFromCache)
{
    int idx1, idx2, idx;
    int ret = 1;
    DBA_DYNFLD_STP dynStp;
    int fldNbr;

    if (optiPtr->eltNbr == 0)
    {
        if (positionElmtToInsert)
            *positionElmtToInsert = 0;
        return -1;
    }

    if (inputArgFromCache == FALSE)
    {
        DBA_DYNFLD_STP inPtr;

        /* collapse the fields */

        inPtr = (DBA_DYNFLD_STP)CALLOC(optiPtr->inputArgNbr, sizeof(DBA_DYNFLD_ST)); /* REF7264 - PMO */
        for (idx = 0; idx < optiPtr->inputArgNbr; idx++)
        {
            memcpy(inPtr + idx, inputArg + *(proc->procParamDefPtr[idx].fldNbrPtr), sizeof(DBA_DYNFLD_ST)); /* REF8844 - LJE - 030410 */
            inPtr[idx].dynStEnum = (short) NullDynSt; /* PMSTA-2026108 - DDV - 171002 */
        }
        inputArg = inPtr;
    }

    fldNbr = Opti_FirstIn + optiPtr->inputArgNbr + optiPtr->outputFldNbr;

    idx1 = 0; idx2 = optiPtr->eltNbr - 1;
    while ((idx = (idx2 - idx1) / 2) != 0)
    {
        idx += idx1;
        dynStp = optiPtr->dataPtr + (optiPtr->optiIndex[idx] * fldNbr);
        ret = DBA_CmpAllInputArg(inputArg, dynStp, optiPtr, proc, inputArgFromCache);  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
        if (ret == 0)
        {
            break;
        }
        if (ret < 0)
        {
            idx2 = idx;
        }
        else
        {
            idx1 = idx;
        }

    }

    if (ret)
    {
        dynStp = optiPtr->dataPtr + (optiPtr->optiIndex[idx1] * fldNbr);
        ret = DBA_CmpAllInputArg(inputArg, dynStp, optiPtr, proc, inputArgFromCache);  /* PMSTA-36451 - DDV - 190708 - Add new parameter */
        if (ret == 0)
            idx = idx1;
        else if (ret < 0)
            idx = idx1;
        else
        {
            dynStp = optiPtr->dataPtr + (optiPtr->optiIndex[idx2] * fldNbr);
            ret = DBA_CmpAllInputArg(inputArg, dynStp, optiPtr, proc, inputArgFromCache); /* PMSTA-36451 - DDV - 190708 - Add new parameter */
            if (ret == 0)
                idx = idx2;
            else if (ret < 0)
                idx = idx2;
            else
                idx = idx2 + 1;
        }
    }

    if (inputArgFromCache == FALSE)
        FREE(inputArg);

    if (ret == 0)
    {
        /* found */

        if (positionElmtToInsert)
            *positionElmtToInsert = idx;
        return (optiPtr->optiIndex[idx]);
    }

    if (positionElmtToInsert)
        *positionElmtToInsert = idx;
    return -1;
}

/************************************************************************
**
** Function    : DBA_GetAFreeCellInOpti
**
** Description : search the record in opti (the less used)
**
** Arguments   :
**
** Return      :
**
** Creation    : sme (Monday December 18 2000) REF5506
** Last modif. : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
************************************************************************/
RET_CODE DBA_GetAFreeCellInOpti(DBA_OPTI_STP optiPtr, int *freeCell)
{
    int *tab;
    unsigned int max;

    if (optiPtr->currentFree >= optiPtr->maxFfree)
    {
        tab = (int *)CALLOC(optiPtr->eltNbr, sizeof(int)); /* REF7264 - PMO */

        if (tab == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        memcpy(tab, optiPtr->optiIndex, optiPtr->eltNbr * sizeof(int));

        TLS_Sort2((char *)tab,
            optiPtr->eltNbr,
            sizeof(int),
            CMP_OptiElementByAccess,
            nullptr,
            SortRtnTp_None,
            (PTR*)optiPtr); /* DLA - REF7264 - 020131 */

        /* take the 20% firsts records */

        max = optiPtr->eltNbr / 5;

        /* DDV - 070521 - Crash when eltNbr is too small, because max = 0 */
        if (max == 0)
            max = 1;

        if (optiPtr->maxFfree != max)
        {
            FREE(optiPtr->optiFree);
            optiPtr->optiFree = (int *)CALLOC(max, sizeof(int)); /* REF7264 - PMO */
            optiPtr->maxFfree = max;
        }
        memcpy(optiPtr->optiFree, tab, sizeof(int) * max);
        optiPtr->currentFree = 0;

        FREE(tab);
    }

    *freeCell = optiPtr->optiFree[optiPtr->currentFree++];
    optiPtr->nbPurgeRecord++;

    return RET_SUCCEED;
}


/************************************************************************
**      Functions
*************************************************************************/


/************************************************************************
*   Function             : DBA_GetApplSessionCode()
*
*   Description : Retrieve ApplSession information
*
*   Arguments : applSessionCd : appl_session code
*               connInfoPtr   : connection pointer
*
*   Return : RET_SUCCEED : if ok
*
*   Creation : PMSTA - 22549 - CHU - 160511
*
*   Last Modif :
*
*************************************************************************/
void DBA_GetApplSessionCode(CODE_T *applSessionCode, AAAConnectionRole role, SessionProperties *sessionPropertiesPtr)
{
    const std::string  localApplSessionCode = (sessionPropertiesPtr ? sessionPropertiesPtr->getApplSessionCd() : DBA_GetConnProviderSessionProperties(role).getApplSessionCd());

    (*applSessionCode)[0] = 0;

    if (localApplSessionCode.empty() == false)
    {
        strcpy(*applSessionCode, localApplSessionCode.c_str());
    }
    else
    {
        if (SYS_IsSrvMode() == TRUE && role == ROLE_ADMIN)
        {
            DBA_DYNFLD_STP applSessionStp = SYS_GetAdminApplSessionStp();

            if (applSessionStp)
            {
                strcpy(*applSessionCode, GET_CODE(applSessionStp, A_ApplSession_Cd));
            }
        }
        else
        {
            std::string currApplSession = SYS_GetThreadApplSessionCd();

            if (currApplSession.empty())
            {
                (*applSessionCode)[0] = END_OF_STRING;
            }
            else
            {
                strcpy(*applSessionCode, currApplSession.c_str());
            }
        }

        if ((*applSessionCode)[0])
        {
            DBA_GetConnProviderSessionProperties(role).setApplSessionCd(*applSessionCode);
        }
    }
}


/************************************************************************
*   Function             : DBA_GetApplSessionChangeSetId()
*
*   Description          : Get Object update session id in appl_session record.
*
*   Arguments            :
*
*   Return               : changeSetId or 0 if it's null
*
*   Creation             : PMSTA-26250 - DDV - 170411
*
*   Last Modif           :
*
*************************************************************************/
ID_T DBA_GetApplSessionChangeSetId()
{
    DBA_DYNFLD_STP	   applSessionStp = DBA_GetConnProviderSessionProperties().getApplSessionStp();
    ID_T               changeSetId = ZERO_ID;

    if (applSessionStp)
    {
        changeSetId = GET_ID(applSessionStp, A_ApplSession_ChangeSetId);
    }

    return(changeSetId);
}

/************************************************************************
**  Function    :   DBA_DelApplSessionByCd
**
**  Description :   Delete given ApplSession
**
**  Arguments   :   pdbadynShortApplSession : appl session short structure
**                  dbiConnHelper           : dbi connection helper
**
**  Return      :   RET_SUCCEED : if ok
**
**  Creation    :   HFI-PMSTA-47796-220125
**
*************************************************************************/
RET_CODE DBA_DelApplSessionByCd(OBJECT_ENUM,
                                DBA_DYNST_ENUM,
                                DBA_DYNFLD_STP          pdbadynShortApplSession,
                                DbiConnectionHelper&    dbiConnHelper)
{
    return DBA_DelApplSession ( dbiConnHelper,
                                GET_CODE(pdbadynShortApplSession, S_ApplSession_Cd),
                                AppSessionInvalidationNat_Forced_by_admin);
}

/************************************************************************
*   Function             : DBA_DelApplSession
*
*   Description : Delete current ApplSession
*
*   Arguments : applSessionCd : appl_session code
*
*   Return : RET_SUCCEED : if ok
*
*   Creation : PMSTA - 22549 - CHU - 160602
*
*   Last Modif : DLA - PMSTA-24672 - 160905
*                PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
RET_CODE DBA_DelApplSession(DbiConnectionHelper& connHelper, const char *applSessionCode, APPLSESSION_INVALIDATION_NATURE_ENUM invalidationNatEn)
{
    if (applSessionCode[0] == END_OF_STRING)
    {
        return RET_SUCCEED;
    }

    DBA_DYNFLD_STP sApplSessionHistoSt = ALLOC_DYNST(S_ApplSessionHisto);

    if (nullptr == sApplSessionHistoSt)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_CODE(sApplSessionHistoSt, S_ApplSessionHisto_Cd, applSessionCode);
    SET_ENUM(sApplSessionHistoSt, S_ApplSessionHisto_InvalidationReasonEn, (ENUM_T)invalidationNatEn);

    const RET_CODE ret = connHelper.dbaDelete(ApplSession, DBA_ROLE_MANAGE_APPL_SESSION, sApplSessionHistoSt);    /* PMSTA-30415 - 090318 - PMO / DLA - PMSTA-24672 - 160905 */

    FREE_DYNST(sApplSessionHistoSt, S_ApplSessionHisto);                                    /* PMSTA-30415 - 090318 - PMO */

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_DeleteApplSessionOnExit()
**
**  Description :   Delete current Session upon application exit
**
**  Arguments   :   none
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_INFO_NOACTION
**
** Creation     :   PMSTA-22549 - CHU - 160603
**
*************************************************************************/
void DBA_DeleteApplSessionOnExit(APPLSESSION_INVALIDATION_NATURE_ENUM invalidationNatEn, DbiConnection* dbiConn)
{
    DbiConnectionHelper* dbiConnHelper = nullptr;

    dbiConnHelper = dbiConn == nullptr ?  new DbiConnectionHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_ADMIN) : new DbiConnectionHelper(dbiConn, false); /* DLA - PMSTA-24672 - 160905 */

    /* PMSTA-26108 - LJE - 171210 */
    if (dbiConn)
    {
        std::string str;
        GEN_GetApplInfo(ApplSqlDbName, str);

        dbiConnHelper->getConnection()->getTargetSessionProperties().setDbName(str);
        dbiConnHelper->getConnection()->getTargetSessionProperties().setSetConnUser();
    }

    /* PMSTA-26108 - LJE - 170825 */
    auto &applSessionMap = SYS_GetThreadApplSessionMap();
    for (auto it = applSessionMap.begin(); it != applSessionMap.end(); it++)
    {
        DBA_DelApplSession(*dbiConnHelper, GET_CODE(it->second, A_ApplSession_Cd), invalidationNatEn);
    }
    applSessionMap.clear();

    delete(dbiConnHelper);
}

/************************************************************************
**
**  Function    :   DBA_DeleteAllApplSessionByUser()
**
**  Description :   Delete all application Sessions for connected
**
**  Arguments   :   none
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_INFO_NOACTION
**
** Creation     :   PMSTA-34344 - LJE - 210223
**
*************************************************************************/
void DBA_DeleteAllApplSessionByUser(APPLSESSION_INVALIDATION_NATURE_ENUM  invalidationNatEn,
                                    DbiConnection*                        dbiConn, 
                                    const std::string                    &user)
{
    MemoryPool          mp;
    DbiConnectionHelper dbiConnHelper(dbiConn);
    DBA_DYNFLD_STP      applSessionHistoStp = mp.allocDynst(FILEINFO, S_ApplSessionHisto);

    SET_SYSNAME(applSessionHistoStp, S_ApplSessionHisto_ApplSessionHistoUser, user.c_str());
    SET_ENUM(applSessionHistoStp, S_ApplSessionHisto_InvalidationReasonEn, invalidationNatEn);

    dbiConnHelper.dbaDelete(ApplSession, UNUSED, applSessionHistoStp);

}

/************************************************************************
**
**  Function    :   DBA_CheckApplSessionValidity()
**
**  Description :   Check is the session is valid
**
**  Arguments   :   Session code
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_INFO_NOACTION
**
** Creation     :   PMSTA-30522 - DLA - 180327
**
*************************************************************************/
APPLSESSION_INVALIDATION_NATURE_ENUM DBA_CheckApplSessionValidity(DBA_DYNFLD_STP aApplSessionStp)
{
    APPLSESSION_INVALIDATION_NATURE_ENUM retEnum = APPLSESSION_INVALIDATION_NATURE_ENUM::AppSessionInvalidationNat_NotApplicable;

    if (EV_AAAInstallLevel == 0 && SYS_GetProgramState() == ProgramState::Running)
    {
        DbiConnectionHelper                  dbiConnectionHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
        MemoryPool                           mp;
        DBA_DYNFLD_STP                       sApplSession = mp.allocDynst(FILEINFO, S_ApplSession);

        SET_CODE(sApplSession, S_ApplSession_Cd, GET_CODE(aApplSessionStp, A_ApplSession_Cd));
        RET_CODE ret = dbiConnectionHelper.dbaGet(ApplSession, UNUSED, sApplSession, &sApplSession);

        if (ret != RET_SUCCEED &&
            ret != RET_DBA_ERR_CONNOTFOUND &&
            ret != RET_DBA_ERR_CONNLOST)
        {
            DBA_DYNFLD_STP      sApplSessionHisto = mp.allocDynst(FILEINFO, S_ApplSessionHisto);
            DBA_DYNFLD_STP      aApplSessionHisto = mp.allocDynst(FILEINFO, A_ApplSessionHisto);

            if (sApplSessionHisto != nullptr && aApplSessionHisto != nullptr)
            {
                SET_CODE(sApplSessionHisto, S_ApplSessionHisto_Cd, GET_CODE(aApplSessionStp, A_ApplSession_Cd));
                if (dbiConnectionHelper.dbaGet(ApplSessionHisto, UNUSED, sApplSessionHisto, &aApplSessionHisto) == RET_SUCCEED)
                {
                    retEnum = (APPLSESSION_INVALIDATION_NATURE_ENUM)GET_ENUM(aApplSessionHisto, A_ApplSessionHisto_InvalidationReasonEn);
                }

                /* The session has been deleted without reason -> exit*/
                if (retEnum == APPLSESSION_INVALIDATION_NATURE_ENUM::AppSessionInvalidationNat_NotApplicable)
                {
                    retEnum = APPLSESSION_INVALIDATION_NATURE_ENUM::AppSessionInvalidationNat_NotFound;
                }
            }
        }
    }
    return retEnum;
}

/************************************************************************
**
**  Function    :   DBA_GetChannelCd()
**
**  Description :   Get the channel of current Client
**
**  Arguments   :   none
**
**  Return      :
**
** Creation     :   PMSTA-22549 - CHU - 160518
**
** Last modif.  : PMSTA-32327 - 260718 - PMO : Improve error management in the fusion process regarding connection error
**
*************************************************************************/
void DBA_GetChannelCd(CODE_T channelCd)
{
    /* see appl_channel definitions in \triplea_home\install\data\appl_channel.imp */

    if (SYS_IsGuiMode() == TRUE)
    {
        strcpy(channelCd, "GUI");
    }
    else if (SYS_IsBatchMode() == TRUE)
    {
        if (*EV_IsSubdApplFlg == TRUE)
        {
            strcpy(channelCd, "Subscription");
        }
        else if (EV_isOnline == true)   /* PMSTA-30522 - DLA - 180320 */
        {
            strcpy(channelCd, "ONLINE");
        }
        else
        {
            strcpy(channelCd, "IMPORT");
        }
    }
    else if (SYS_IsSrvMode() == TRUE ||
             SYS_IsDdlGenMode() == TRUE)    /* PMSTA-28698 - LJE - 180515 */
    {
        strcpy(channelCd, "Background-Core");
    }
    else if (SYS_IsSqlMode() == TRUE)
    {
        strcpy(channelCd, "SQL");
    }
    else if (SYS_IsUnitTest() == TRUE)
    {
        strcpy(channelCd, "IMPORT");
    }

    else
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unknown Channel");
        channelCd[0] = END_OF_STRING;       /* PMSTA-32327 - 260718 - PMO */
    }
}


/************************************************************************
*   Function             : DBA_SetWUIUserSessionInfo()
*
*   Description          : Set User Session information
*
*   Arguments            : sessionPtr    : pointer on appl_session
*                          userPtr       : pointer on appl_user
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation             : PMSTA-22549 - CHU - 160511
*
*   Last Modif           : PMSTA-32327 - 260718 - PMO : Improve error management in the fusion process regarding connection error
*
*************************************************************************/
RET_CODE DBA_SetUserSessionInfo(DbiConnectionHelper &dbiConnHelper, DBA_DYNFLD_STP aApplSessionStp)
{
    RET_CODE       ret     = RET_SUCCEED;
    DBA_DYNFLD_STP userPtr = SYS_GetThreadApplUser(dbiConnHelper, true);

    if (nullptr != aApplSessionStp && nullptr != userPtr)
    {
        if (SYS_IsGuiMode())
        {
            /* PMSTA-23716 - CHU - 160621 */
            /* if old user record exists, this means that a change has been made on the current user */
            if (SV_OldApplUserRecord != nullptr)
            {
                /* check if session has to be 'regenerated' */
                if (CMP_ID(GET_ID(userPtr, A_ApplUser_FuncSecuProfId), GET_ID(SV_OldApplUserRecord, A_ApplUser_FuncSecuProfId)) != 0 ||
                    CMP_ID(GET_ID(userPtr, A_ApplUser_ReportProfileId), GET_ID(SV_OldApplUserRecord, A_ApplUser_ReportProfileId)) != 0 ||
                    CMP_ID(GET_ID(userPtr, A_ApplUser_ScreenProfileId), GET_ID(SV_OldApplUserRecord, A_ApplUser_ScreenProfileId)) != 0 ||
                    CMP_ID(GET_ID(userPtr, A_ApplUser_QuickSearchProfId), GET_ID(SV_OldApplUserRecord, A_ApplUser_QuickSearchProfId)) != 0)
                {
                    MemoryPool mp;
                    DBA_DYNFLD_STP sApplSessionSt = mp.allocDynst(FILEINFO, S_ApplSession);
                    /*refresh session data */
                    SET_CODE(sApplSessionSt, S_ApplSession_ApplSessionChannel, "GUI");
                    ret = dbiConnHelper.dbaUpdate(ApplSession, UNUSED, sApplSessionSt);
                    SET_NULL_CODE(sApplSessionSt, S_ApplSession_ApplSessionChannel);
                }
                FREE_DYNST(SV_OldApplUserRecord, A_ApplUser);
            }
        }

        /* Override appl_user's information in DBA_GetUserInfo. */
        COPY_DYNFLD(aApplSessionStp, A_ApplSession, A_ApplSession_OldFctSecuProfId,
                    userPtr, A_ApplUser, A_ApplUser_FuncSecuProfId);      /* Saved in order to know if fct secu prof should be reloaded */

        COPY_DYNFLD(userPtr, A_ApplUser, A_ApplUser_FuncSecuProfId,
                    aApplSessionStp, A_ApplSession, A_ApplSession_FuncSecuProfId);

        COPY_DYNFLD(userPtr, A_ApplUser, A_ApplUser_ReportProfileId,
                    aApplSessionStp, A_ApplSession, A_ApplSession_ReportProfileId);

        COPY_DYNFLD(userPtr, A_ApplUser, A_ApplUser_ScreenProfileId,
                    aApplSessionStp, A_ApplSession, A_ApplSession_ScreenProfileId);

        COPY_DYNFLD(userPtr, A_ApplUser, A_ApplUser_QuickSearchProfId,
                    aApplSessionStp, A_ApplSession, A_ApplSession_SearchProfileId);

        ret = DBA_UpdApplSessionLastAccessDate(dbiConnHelper, aApplSessionStp); /* PMSTA-23914 - CHU - 160706 */ /* DLA - PMSTA-26724 - 170410 */ /* PMSTA-nuodb - LJE - 190722 */

    }
    else
    {
        if (nullptr == userPtr)                 /* PMSTA-32327 - 260718 - PMO */
        { // Error
            ret = RET_DBA_ERR_SETPARAM;
        }
    }

    return ret;
}


/************************************************************************
*   Function             : DBA_GetSessionTimeOut()
*
*   Description          : Get Session TimeOut
*
*   Arguments            : sessionPtr    : pointer on appl_session
*                          userPtr       : pointer on appl_user
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation             : PMSTA-23914 - CHU - 160706
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_GetSessionTimeOut(CODE_T applSessionCode, unsigned long *sessionTimeOut)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP          sApplSessionSt = nullptr, aApplSessionPtr = nullptr;

    if (applSessionCode != nullptr && applSessionCode[0] != END_OF_STRING)
    {
        if (((sApplSessionSt) = ALLOC_DYNST(S_ApplSession)) == nullptr)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        if (((aApplSessionPtr) = ALLOC_DYNST(A_ApplSession)) == nullptr)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        SET_CODE(sApplSessionSt, S_ApplSession_Cd, applSessionCode);

        if ((ret = DBA_Get2(ApplSession, UNUSED, S_ApplSession, sApplSessionSt,
            A_ApplSession, &aApplSessionPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            FREE_DYNST(sApplSessionSt, S_ApplSession);
            return(RET_SRV_GEN_ERR_INVARG);
        }

        *sessionTimeOut = (long)GET_NUMBER(aApplSessionPtr, A_ApplSession_TimeoutSec);

        FREE_DYNST(sApplSessionSt, S_ApplSession);
        FREE_DYNST(aApplSessionPtr, A_ApplSession);
    }

    return (ret);
}

/*************************************************************************
*   Function    : DBA_UpdApplSessionLastAccessDate()
*
*   Description : Reset Session last access date
*
*   Arguments   : sessionCd pointer on appl_session
*
*   Return      : nothing
*
*   Creation    : PMSTA-23914 - CHU - 160705
*
*   Last Modif  :
*
*************************************************************************/
RET_CODE DBA_UpdApplSessionLastAccessDate(DbiConnectionHelper &dbiConnHelper, DBA_DYNFLD_STP applSessionStp)
{
    RET_CODE retCode = RET_SUCCEED;

    if (applSessionStp)
    {
        retCode = dbiConnHelper.dbaUpdate(ApplSession, DBA_ROLE_UPD_APPL_SESSION_ACCESS, applSessionStp);
    }

    return(retCode);
}

/************************************************************************
*   Function             : DBA_GetUserInfo()
*
*   Description          : Get User informations. This function has 2 modes :
*
*                          - GUI PROCESS    : read record pointed by SV_ApplUserRecord.
*                                             if SV_ApplUserRecord is NULL, call DBA_Get.
*
*                          - SERVER PROCESS : Get User code from current
*                                             connection/thread and call DBA_Get to
*                                             retrieve Appl_User record.
*
*
*   Arguments            : fldNbr            : dynamic field number
*                          fldDataType       : target to copy field information
*
*   Functions call       :
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_GEN_ERR_INVARG      : if input argument problem
*                          RET_MEM_ERR_ALLOC       : if memory allocation failed
*                          RET_DBA_ERR_NODATA      : if no record was found
*
*   Creation Date        : REF11476 - TEB - 051006
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_GetUserInfo(int fldNbr, PTR data)
{
    return(DBA_GetUserInfo2(fldNbr, data, FALSE));
}

/************************************************************************
*   Function             : DBA_GetUserInfo2()
*
*   Description          : Get User informations. This function has 2 modes :
*
*                          - GUI PROCESS    : read record pointed by SV_ApplUserRecord.
*                                             if SV_ApplUserRecord is NULL, call DBA_Get.
*
*                          - SERVER PROCESS : Get User code from current
*                                             connection/thread and call DBA_Get to
*                                             retrieve Appl_User record.
*
*
*   Arguments            : fldNbr            : dynamic field number
*                          fldDataType       : target to copy field information
*						   wuiUserFlg		 : if TRUE, use WUI user set on connection
*						   pConnectNo		 : Connection pointer
*
*   Functions call       :
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_GEN_ERR_INVARG      : if input argument problem
*                          RET_MEM_ERR_ALLOC       : if memory allocation failed
*                          RET_DBA_ERR_NODATA      : if no record was found
*
*   Creation Date        : 16.10.95 - PEC
*   Last Modif           : 01.02.96 - PEC - Modified bug. Before modification, data
*                                           was a double variable. Now data is of the
*                                           same datatype that the fldNbr in the
*                                           dynamic structure.
*                          26.09.96 - PEC - Ref.: BUG140
*                          03.02.97 - PEC - Ref.: BUG124
*                          03.02.97 - RAK - Ref.: DVP338
*                          13.02.97 - PEC - Ref.: BUG291
*                          14.02.97 - ROI - Ref.: BUG291
*                          07.09.98 - SME - REF2631
*                          08.12.00 - DLA - REF5435
*                          REF2600 - TEB - 021230
*                          REF8952 - DDV - 030919 - flndNbr can be -1, in this case, all the record is returned.
*						   REF11476 - TEB - 051006 - Rename the function to DBA_GetUserInfo2() and add wuiUserFlg
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                          PMSTA-26108 - LJE - 171123 : Remove #ifdef
*
*************************************************************************/
RET_CODE DBA_GetUserInfo2(int fldNbr, PTR data, FLAG_T wuiUserFlg)
{
    if (EV_DictInitFlg == FALSE)
    {
        return(RET_DBA_ERR_NODATA);
    }

    /* Check input arguments */
    if (fldNbr < 0 || fldNbr >(int)GET_FLD_NBR(A_ApplUser) || data == nullptr)
    {
        /* REF8952 - DDV - Now NO_VALUE is valid (it return the record) */
        if (fldNbr != NO_VALUE)
            MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP aApplUserTmp = SYS_GetThreadApplUser(wuiUserFlg == TRUE);

    if (aApplUserTmp == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /**** BEGIN BUG124 ****/
    if (fldNbr == A_ApplUser_UserPassword)
    {
        SYSNAME_T userPasswd;
        AUTO_PASSWORD_CLEAR(userPasswd, sizeof(userPasswd));        /* PMSTA-18094 - 130514 - PMO */

        PasswordClear passwordClear = SYS_GetThreadPassword().getClearPassword();
        passwordClear.copyPassword(userPasswd, sizeof(userPasswd));

        SET_INFO(aApplUserTmp, A_ApplUser_UserPassword, userPasswd);     /* REF2600 - TEB - 021230 */
    }

    /* REF8952 - DDV - Now NO_VALUE is valid (it return the record) */
    if (fldNbr != NO_VALUE)
    {
        /**** BEGIN BUG291 ****/
        if (aApplUserTmp == nullptr || IS_NULLFLD(aApplUserTmp, fldNbr))          /* REF2600 - TEB - 021230 */
        {
            return(RET_DBA_INFO_NODATA);
        }
        /**** END   BUG291 ****/

        if (IS_STRINGFLD(A_ApplUser, fldNbr))
        {
            strcpy((char *)data, GET_STRING(aApplUserTmp, fldNbr)); /* REF2600 - TEB - 021230 */
        }
        else
            if (IS_USTRINGFLD(A_ApplUser, fldNbr))
            {
                u_strcpy((UChar *)data, GET_USTRING(aApplUserTmp, fldNbr)); /* REF2600 - TEB - 021230 */
            }
            else
            {
                switch (GET_FLD_TYPE(A_ApplUser, fldNbr))
                {
                case DateType:
                case TimeType:
                    *((unsigned int *)data) = aApplUserTmp[fldNbr].data.uintValue;         /* REF2600 - TEB - 021230 */
                    break;
                case DatetimeType:
                    *((DATETIME_STP)data) = aApplUserTmp[fldNbr].data.datetime64St.dateTime();  /* PMSTA-MICROSEC - LJE - 210113 */
                    break;
                case DictType:
                case IdType:
                    *((ID_T *)data) = aApplUserTmp[fldNbr].data.longlongValue; /* DLA - PMSTA08801 - 091223 */
                    break;
                case IntType:
                case MaskType:
                    *((int *)data) = aApplUserTmp[fldNbr].data.intValue; /* REF2600 - TEB - 021230 */
                    break;
                case EnumMaskType:		/* PMSTA13460 - TGU - 120420 */
                case LongintType:
                    *((ENUMMASK_T *)data) = aApplUserTmp[fldNbr].data.longlongValue;
                    break;
                case EnumType:
                case FlagType:
                case MethodType:
                case TinyintType:
                    *((unsigned char *)data) = aApplUserTmp[fldNbr].data.ucharValue;  /* REF2600 - TEB - 021230 */
                    break;

                case ExchangeType:
                case NumberType:
                case PercentType:
                case AmountType:
                case LongamountType:                        /* DVP041 - 960429 - DED */
		case PriceType:
                    *((double *)data) = aApplUserTmp[fldNbr].data.dbleValue; /* REF2600 - TEB - 021230 */
                    break;
                case PeriodType:
                case SmallintType:
                    *((short *)data) = aApplUserTmp[fldNbr].data.shortValue; /* REF2600 - TEB - 021230 */
                    break;
                case YearType:
                    *((unsigned short *)data) = aApplUserTmp[fldNbr].data.ushortValue; /* REF2600 - TEB - 021230 */
                    break;

                default:
                    break;
                }
            }
    }
    else if (data != aApplUserTmp)
    {
        COPY_DYNST((DBA_DYNFLD_STP)data, aApplUserTmp, NullDynSt); /* REF8952 - DDV - Now NO_VALUE is valid (it return the record) */
    }

    return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   DBA_GetDictFctTabByUserId
**
**  Description :   return a dict fct array
**
**  Arguments   :   pfctTab         :   dict fct
**                  piNbRows        :   number of rows
**                  bIsAllocated    :   if TRUE, you need to do a FREE of
**                                      pfctTab
**
**  Return      :   RET_CODE
**
**  Cr?ation    :   FPL-REF11314-060512
**
*************************************************************************/
RET_CODE    DBA_GetDictFctTabByUserId(ID_T userId, std::vector<DICT_FCT_ST> *&pfctTab)
{
    RET_CODE                retCode = RET_SUCCEED;

    /*  test for security   */
    if (userId <= 0)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTabByUserId(level -2) returns RET_GEN_ERR_INVARG as userId == %1", IdType, userId); /* PMSTA-32214 - CHU - 180726  */
        return RET_GEN_ERR_INVARG;
    }

    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();
        if (connInfoPtr != nullptr)
        {
            retCode = DBI_LoadDictFctByUserId(userId, connInfoPtr->userFctTab);

            pfctTab = &connInfoPtr->userFctTab;
        }
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTabByUserId(level -2) returns nothing as SERV_GetCurrConnStructPtr() returned NULL"); /* PMSTA-32214 - CHU - 180726  */
    }

    return retCode;
}

/************************************************************************
*   Function             : DBA_GetCurrCodifInfoTab()
*
*   Description          : Get the current codification info table.
*						   It can be the global variable or the table
*						   defined in the connection.
*
*   Arguments            :
*
*   Creation Date        : PCC13654 - LJE - 090701
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_GetCurrCodifInfoTab(DBA_DYNFLD_STP **codifInfoTabPtr, int *codifNbrPtr)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();

        if (connInfoPtr->codifInfoTab == nullptr ||
            connInfoPtr->codifInfoNbr == 0)
        {
            (*codifInfoTabPtr) = SV_CodifInfo;
            (*codifNbrPtr) = SV_CodifNbr;
        }
        else
        {
            (*codifInfoTabPtr) = connInfoPtr->codifInfoTab;
            (*codifNbrPtr) = connInfoPtr->codifInfoNbr;
        }
    }
    else
    {
        (*codifInfoTabPtr) = SV_CodifInfo;
        (*codifNbrPtr) = SV_CodifNbr;
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBA_SetCodifInfoTabAsCurr()
*
*   Description          : Copy the global codifications to current
*                          and reset to internal codif.
*
*   Arguments            :
*
*   Creation Date        : PCC13654 - LJE - 090701
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_SetCodifInfoTabAsCurr()
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();

        if (connInfoPtr->codifInfoTab != nullptr &&
            connInfoPtr->codifInfoNbr != 0)
        {
            DBA_FreeDynStTab(connInfoPtr->codifInfoTab, connInfoPtr->codifInfoNbr, A_Codif);
        }

        connInfoPtr->codifInfoTab = (DBA_DYNFLD_STP*)CALLOC(SV_CodifNbr, sizeof(DBA_DYNFLD_STP));
        connInfoPtr->codifInfoNbr = SV_CodifNbr;

        for (int i = 0, j = 0; i < SV_CodifNbr; i++)
        {
            connInfoPtr->codifInfoTab[j] = ALLOC_DYNST(A_Codif);
            COPY_DYNST(connInfoPtr->codifInfoTab[j], SV_CodifInfo[i], A_Codif);

            if (GET_FLAG(connInfoPtr->codifInfoTab[j], A_Codif_InternalCodifFlg) == TRUE)
            {
                SET_FLAG_TRUE(connInfoPtr->codifInfoTab[j], A_Codif_DfltDspFlg);
            }
            else
            {
                SET_FLAG_FALSE(connInfoPtr->codifInfoTab[j], A_Codif_DfltDspFlg);
            }
            j++;
        }
    }

    return RET_SUCCEED;
}


/************************************************************************
*   Function             : DBA_AddOptiPurgeTime()
*
*   Description          : Add an DateTime entry for purge statistics
*
*   Arguments            : None
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : REF11767 - CHU - 060403
*
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_AddOptiPurgeTime(DBA_OPTI_STP optiPtr)
{
    if (optiPtr->purgeTimeTab == nullptr)
    {
        optiPtr->purgeTimeNbr = 0;
        optiPtr->purgeTimeTab = (DATETIME_T *)CALLOC(10, sizeof(DATETIME_T));
    }
    else if (optiPtr->purgeTimeNbr % 10 == 0)
    {
        optiPtr->purgeTimeTab = (DATETIME_T *)REALLOC(optiPtr->purgeTimeTab, (optiPtr->purgeTimeNbr + 10) * sizeof(DATETIME_T)); /* REF11767 - LJE - 060425 */
    }

    if (optiPtr->purgeTimeTab == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    DATE_CurrentDateTime(&(optiPtr->purgeTimeTab[optiPtr->purgeTimeNbr]));
    optiPtr->purgeTimeNbr++;

    return(RET_SUCCEED);
}

/************************************************************************
**
** Function    : SERV_TraceStatisticOpti
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    :
** Last modif. :
**
************************************************************************/
RET_CODE SERV_TraceStatisticOpti()
{
    if (SYS_IsSrvMode())
    {

        int nbCall, nbHint, hintPercent, i, max, cpt, curr, purgeRecord;
        LONGINT_T memoryUsed;
        SHORTINFO_T tab, tab1;
        CODE_T action;
        DBA_PROC_STP proc;
        DBA_OPTI_STP         optiPtr = nullptr;
        STRING1000_T buffer;
        DBA_OPTI_STP    optiBase = nullptr;

        sprintf(buffer, "%-80s %-120s %-80s %-11s %-16s %-17s %-25s %-11s %-14s %-19s", "Proc Name", "Action", "Output Dynst", "Call Number", "Cache Hit Number", "Cache Hit Percent", "Cache Purge Record Number", "Max Number", "Current Number", "Memory Used (in KB)");
        MSG_LogSrvMesg(UNUSED, UNUSED, "LocalOptiStat: %1", String1000Type, buffer);
        buffer[0] = END_OF_STRING;

        sprintf(buffer, "-------------------------------------------------------------------------------- ------------------------------------------------------------------------------------------------------------------------ -------------------------------------------------------------------------------- ----------- ---------------- ----------------- ------------------------- ----------- -------------- -------------------");
        MSG_LogSrvMesg(UNUSED, UNUSED, "LocalOptiStat: %1", String1000Type, buffer);
        buffer[0] = END_OF_STRING;

        /* Get the optimization base pointer */
        if ((optiBase = SYS_GetThreadDataCtxServer()->getOptiPtr()) == nullptr)     /* DLA - PMSTA-26864 - 170405 */
        {
            return(RET_DBA_ERR_OPTI);
        }

        for (i = 0, cpt = 0; i < EV_NewOptiListSize; i++)
        {
            if ((optiPtr = optiBase + i) != nullptr)
            {
                if ((proc = (DBA_PROC_STP)optiPtr->procPtr) != nullptr)
                {

                    cpt++;
                    if (*(proc->outputDynStPtr) >= 0)
                    {
                        strcpy(tab, DBA_GetDynStCName(*(proc->outputDynStPtr))); /* REF8844 - LJE - 030425 */
                    }
                    else
                    {
                        sprintf(tab, "idx=%d", i);
                    }
                    if (proc->server == SqlServer)
                    {
                        strcpy(tab1, proc->procName);
                    }
                    else
                    {
                        sprintf(tab1, "Internal Proc");
                    }

                    if (proc->action == Select)
                    {
                        strcpy(action, "Select");
                    }
                    else if (proc->action == Get)
                    {
                        strcpy(action, "Get");
                    }
                    else
                    {
                        strcpy(action, "None");
                    }

                    nbCall = optiPtr->nbCall;
                    nbHint = optiPtr->cacheHint;
                    max = optiPtr->maxAllocNbr;
                    curr = optiPtr->eltNbr;
                    if (nbCall > 0)
                        hintPercent = (nbHint * 100) / nbCall;
                    else
                        hintPercent = 0;

                    purgeRecord = optiPtr->nbPurgeRecord;
                    /* calc size */

                    memoryUsed = 0;

                    DBA_OptiGetUsedSizeByProc(proc, Opti_Local, 0, &memoryUsed, nullptr);

                    memoryUsed = memoryUsed / 1024;

                    /*                                                              "Proc Name","Action","Output Dynst","Call Number","Cache Hit Number","Cache Hit Percent","Cache Purge Record Number","Max Number","Current Number","Memory Used (in KB)"*/
                    sprintf(buffer, "%-80s %-120s %-80s %-11d %-16d %-17d %-25d %-11d %-14d %-19" szFormatLongInt, tab1, action, tab, nbCall, nbHint, hintPercent, purgeRecord, max, curr, memoryUsed);
                    MSG_LogSrvMesg(UNUSED, UNUSED, "LocalOptiStat: %1", String1000Type, buffer);
                    buffer[0] = END_OF_STRING;
                }
            }
        }
    }

    return(RET_SUCCEED);
}




/************************************************************************
**
** Function    : DBA_SetFmtEltInfo
**
** Description : to set fmtEltInfo in server connect structure SERV_CONNECT_INFO_STP
**
** Arguments   :
**
** Return      :  true or false
**
** Creation    : PMSTA-17979 - TGU - 151001
** Last modif. :
**
************************************************************************/
bool DBA_SetFmtEltInfo(const char * info)
{
    bool ret = false;

    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();
        if (connInfoPtr != nullptr)
        {
            connInfoPtr->fmtEltInfo = info;
            ret = true;
        }
    }

    return ret;
}



/************************************************************************
**
** Function    : DBA_GetFmtEltInfo
**
** Description : to get fmtEltInfo in server connect structure SERV_CONNECT_INFO_STP
**
** Arguments   :
**
** Return      : true or false
**
** Creation    : PMSTA-17979 - TGU - 151001
** Last modif. :
**
*************************************************************************/
bool DBA_GetFmtEltInfo(char * info)
{
    bool ret = false;

    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();
        if (connInfoPtr != nullptr)
        {
            strncpy(info, connInfoPtr->fmtEltInfo.c_str(), connInfoPtr->fmtEltInfo.length());
            ret = true;
        }
    }

    return ret;
}

/************************************************************************
**
** Function    :
**
** Description : It set external service optimisation header pointer in server connect structure SERV_CONNECT_INFO_STP
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-22496 - DDV 160616
** Last modif. :
**
************************************************************************/
RET_CODE DBA_SetESRVOptiHeadPtr(PTR eSRVOptiHearderPtr)
{
    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();
        if (connInfoPtr == nullptr)
            return(RET_DBA_ERR_OPTI);

        if (connInfoPtr->eSRVOptiHeadPtr != nullptr)
        {
            ESRV_FreeOpti();        /* free it */
        }

        connInfoPtr->eSRVOptiHeadPtr = eSRVOptiHearderPtr;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    :
**
** Description : It get external service optimisation header pointer in server connect structure SERV_CONNECT_INFO_STP
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-22496 - DDV 160616
** Last modif. :
**
************************************************************************/
PTR DBA_GetESRVOptiHeadPtr()
{
    PTR optiHeaderPtr = nullptr;

    if (SYS_IsSrvMode())
    {
        SERV_CONNECT_INFO_STP connInfoPtr = SERV_GetCurrConnStructPtr();
        if (connInfoPtr != nullptr)
        {
            optiHeaderPtr = connInfoPtr->eSRVOptiHeadPtr;
        }
    }

    return(optiHeaderPtr);
}

/************************************************************************
**
** Function    :
**
** Description : Set exit reason value
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-23726 - DDV - 160624
** Last modif. :
**
************************************************************************/
void DBA_SetExitReason(EXITREASON_ENUM exitReason)
{
    SV_ExitReason = exitReason;
}


/************************************************************************
**
** Function    :
**
** Description : Get exit reason valuer
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-23726 - DDV - 160624
** Last modif. :
**
************************************************************************/
EXITREASON_ENUM DBA_GetExitReason()
{
    return(SV_ExitReason);
}

/************************************************************************
*   Function             : DBA_CheckTimeZoneTrace
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :  PMSTA-31792 - DDV - 180430
*   Last Modif           :
*
*************************************************************************/
void DBA_CheckTimeZoneTrace(char *envVar)
{
    int                    tzCheckLevel = atoi(envVar);
    DbiConnectionHelper  dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
    TZ_OFFSET_T          icuRawUTCOffset = 0, icuDstOffset = 0;

    if (tzCheckLevel >= 1)
    {
        DBA_DYNFLD_STP        *sTimeZoneTab;
        int                    timeZoneNbr = 0;
        char                  *icuFileDir = nullptr;


        printf("\n*******************************************************\n");
        printf("**************   Start Time Zone Check   **************\n");

        printf("*** ICU_TIMEZONE_FILES_DIR : ");

        if ((icuFileDir  = SYS_GetEnv("ICU_TIMEZONE_FILES_DIR")) != nullptr)
            printf("%s   ***\n", icuFileDir);
        else
            printf("                       ***\n");


        printf("*******************************************************\n");

        if (dbiConnHelper.dbaSelect(Timezone, UNUSED, nullptr, S_Timezone, &sTimeZoneTab, &timeZoneNbr) == RET_SUCCEED)
        {
            for (int i=0; i<timeZoneNbr; i++)
            {
                if (ICU4AAA_GetTodayTzOffset(GET_CODE(sTimeZoneTab[i], S_Timezone_Cd), &icuRawUTCOffset, &icuDstOffset) == RET_SUCCEED)
                {
                    if (GET_TZOFFSET(sTimeZoneTab[i], S_Timezone_UtcOffset) != icuRawUTCOffset &&
                        GET_TZOFFSET(sTimeZoneTab[i], S_Timezone_UtcOffset) != (icuRawUTCOffset + icuDstOffset))
                    {
                        printf("ERROR: Time Zone Offset %s, UTC offset mismatch. TAP: %d, ICU %d (%d DST)\n", GET_CODE(sTimeZoneTab[i], S_Timezone_Cd), GET_TZOFFSET(sTimeZoneTab[i], S_Timezone_UtcOffset), icuRawUTCOffset, icuDstOffset);
                    }
                    else
                    {
                        if (tzCheckLevel >= 2)
                            printf("Time Zone %s is correct. TAP: %d, ICU %d (%d DST)\n", GET_CODE(sTimeZoneTab[i], S_Timezone_Cd), GET_TZOFFSET(sTimeZoneTab[i], S_Timezone_UtcOffset), icuRawUTCOffset, icuDstOffset);
                    }
                }
                else
                {
                    printf("ERROR: Time Zone %s is not define in ICU Library\n", GET_CODE(sTimeZoneTab[i], S_Timezone_Cd));
                }
            }

            if (tzCheckLevel == 3)
            {
                ICU4AAA_DispMissingICUTZ(sTimeZoneTab, timeZoneNbr);
            }

            DBA_FreeDynStTab(sTimeZoneTab, timeZoneNbr, S_Timezone);
        }
    }
}

/************************************************************************
*   Function             : DBA_LoadAndCheckDbTimeZone
*
*   Description          : Load database timezone and check that its UTC-offest is correct
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :  PMSTA-30817 - DDV - 180430
*   Last Modif           :
*
*************************************************************************/
void DBA_LoadAndCheckDbTimeZone(bool dispTzDataVersionFlg)
{
    if (EV_AAAInstallLevel != 0)
        return;

    CODE_T               dbTimeZoneCd = "", defTimezoneCd = "";
    MemoryPool           memPool;
    TZ_OFFSET_T          taUTCOffset = 0, icuRawUTCOffset = 0, icuDstOffset = 0, icuUTCOffset = 0, dbUTCOffset = 0;
    FLAG_T               taTimeZoneFoundFlg=FALSE, icuTimeZoneFoundFlg=FALSE, useEtcDefaultTzFlg = FALSE;
    DbiConnectionHelper  dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
	char                *envVar = (char *)nullptr;

    if (dispTzDataVersionFlg) /* PMSTA-43454 - DDV - 210128 */
    {
        const char          *icuDataVersion = ICU4AAA_GetTZDataVersion();

        if (icuDataVersion != NULL)
        {
            /* PMSTA-nuodb - LJE - 190723 */
            if (SYS_IsSrvMode())
            {
                printf("%s\n-", Console::ColorizeOk("ok").c_str());
            }
            else
            {
                printf("REM");
            }
            printf(" ICU Time Zone Data Version : %s \n", icuDataVersion); /* PMSTA-31993 - DDV - 180628 */
        }
    }

    /* PMSTA-37919 - Kramadevi - 29012020 */
    SV_DbTimezoneStp = ALLOC_DYNST(A_Timezone);
    if (dbiConnHelper.dbaGet(Timezone, DBA_ROLE_LOAD_DBTIMEZONE, nullptr, &SV_DbTimezoneStp) == RET_SUCCEED)
    {
        taUTCOffset = GET_TZOFFSET(SV_DbTimezoneStp, A_Timezone_UtcOffset);
        strcpy(dbTimeZoneCd, GET_CODE(SV_DbTimezoneStp, A_Timezone_Cd));
        taTimeZoneFoundFlg = TRUE;

        /* Load timezone offset from ICU library */
        if (ICU4AAA_GetTodayTzOffset(dbTimeZoneCd, &icuRawUTCOffset, &icuDstOffset) == RET_SUCCEED)
        {
            icuTimeZoneFoundFlg = TRUE;
            icuUTCOffset = icuRawUTCOffset + icuDstOffset;

            if (taUTCOffset != icuUTCOffset && taUTCOffset != icuRawUTCOffset)
            {
                /* TA tz offset not matching ICU tz offset */
                MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 2, FILEINFO, taUTCOffset, icuUTCOffset);
            }
        }
        else
        {
            useEtcDefaultTzFlg = TRUE;
            /* Msg time zone not define in ICU library */
            MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 1, FILEINFO, dbTimeZoneCd);
        }
    }
    else
    {
        useEtcDefaultTzFlg = TRUE;
        /* No time zone flagged as database time zone in timezone table */
        MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 0, FILEINFO);
    }

    /* /* PMSTA-43454 - DDV - 210120 - On Nuodb, time zone must be set on connection to have the correct db UTC Offset */
    if (EV_RdbmsVendor == Nuodb)
    {
        strcpy(EV_DbTimeZoneCd, dbTimeZoneCd);
    }

    /* load database UTC Offset */
    if (DBA_GetDbUTCOffset(dbiConnHelper, &dbUTCOffset) == RET_SUCCEED)
    {
         TZ_OFFSET_T         offsetModulo;

         offsetModulo = dbUTCOffset % 5;

        /* PMSTA-31792 - DDV - 180626 - One minute difference can occure on sybase, adjust it to be a multiple of five */
        if (offsetModulo ==  1)
        {
            dbUTCOffset--;
        }
        else if (offsetModulo ==  4)
        {
            dbUTCOffset++;
        }

        if (icuTimeZoneFoundFlg == TRUE)
        {
            if (dbUTCOffset != icuUTCOffset)
            {
                /* database UTC offset not matching ICU UTC offset */
                MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 3, FILEINFO, dbUTCOffset, icuUTCOffset);
                useEtcDefaultTzFlg = TRUE;
            }
        }

        if (useEtcDefaultTzFlg == TRUE)
        {
            const int      m = abs(dbUTCOffset) % 60;
            const int      h = (abs(dbUTCOffset)-m) / 60;

            /* Use default ETC time zone UTC offset define in TA table (Etc/GMT?HH:MM) */
            sprintf(defTimezoneCd, "Etc/GMT%s%d", dbUTCOffset > 0 ? "-":"+", h); /* sign are inversed (for Etc/GMT+2 UTC offset is UTC-02:00) */

            /* Load timezone offset from ICU library */
            if (ICU4AAA_GetTodayTzOffset(defTimezoneCd, &icuRawUTCOffset, &icuDstOffset) == RET_SUCCEED)
            {
                icuTimeZoneFoundFlg = TRUE;
                icuUTCOffset = icuRawUTCOffset + icuDstOffset;

                if (dbUTCOffset != icuUTCOffset)
                {
                    /* database UTC offset not matching ICU UTC offset */
                    MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 3, FILEINFO, dbUTCOffset, icuUTCOffset);
                    return;
                }

                MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 5, FILEINFO, defTimezoneCd);
            }
            else
            {
                /* Msg time zone not define in ICU library */
                MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 1, FILEINFO, defTimezoneCd);
                return;
            }
        }
        else
        {
            strcpy(defTimezoneCd, dbTimeZoneCd);
        }
        strcpy(EV_DbTimeZoneCd, defTimezoneCd);
    }
    else
    {
        /* Error while getting database UTC offest */
        MSG_SendMesg(RET_DBA_ERR_TIMEZONE, 4, FILEINFO);
        return;
    }

    ICU4AAA_InitUTCAndDbSVTimeZone(EV_DbTimeZoneCd); /* PMSTA-43454 - DDV - 210128 */

    if ((envVar = SYS_GetEnv("AAATIMEZONECHECK")) != nullptr && SERVER_MODE() == TRUE)
    {
        DBA_CheckTimeZoneTrace(envVar);
    }
}
/************************************************************************
**      END          dbamem.c
*************************************************************************/

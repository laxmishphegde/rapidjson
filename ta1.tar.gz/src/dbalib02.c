/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALIB02_C

/************************************************************************
*	Local Functions
*
* DBA_CheckConstList              :
* DBA_SelectByListId              :
* DBA_SqlExec                     : Send a character string representing a SQL Dynamic request.
* DBA_Fetch                       : Fetch the Sybase result fields (result set).
* DBA_LoadOper                    : Load of an operation buy, sell, ...
* DBA_LoadPanels                  : Load DictPanel and create a hierarchy.
* DBA_LoadFormats                 : Load format, format_element, script definition and create all hierarchies.
* DBA_LoadSearchFormat            : Load format, format_element, script definition and create all hierarchies.
* DBA_FreeDynStTab                : Free a DBA_DYNFLD_STP array and all allocated dynamic structures.
* DBA_GetDomainFctResults         :
* DBA_GetFinFctResults            : Retrieve format element information, data description and data rows returned by Open Server
*                                   after a call to Financial Function (Valorisation, ...).
* DBA_FreeFinFctResults           : Free all allocated dynamic structures used to retrieve data (after a call to
*                                   DBA_GetFinFctResults) .
*                                   returned by Open Server.
* DBA_ReadFinFctResults           : Retrieve format element information, data description and data rows returned by Open Server
*                                   after a call to Financial Function (Valorisation, ...).
* DBA_GetScptDef                  :
* DBA_SetScptDef                  :
* DBA_InsScptDef                  : Called by DBA_Insert2 when using the DBA_ROLE_INSERT_SCRIPT role in case of script definition
*                                   insertion.
* DBA_GetRecordIdByCd             :
* DBA_GetRecordCdById             :
* DBA_HandleAutocreateStack       : Handle records stored in the AUTOCREATE stack.
* DBA_FilterMsgInfos2             : Filter the messages stack associated to a connection after a call to a server.
* DBA_BeginTransaction            : Send a "begin tran" command to the server and retrieve returned status.
* DBA_EndTransaction              : Send a "commit tran" or "rollback tran" command to the server according to the given status.
* DBA_GetNewDocIndex              : Get a new document index according to system parameter the server according to the given status.
* DBA_GetApplMsgText              : Get a appl_msg_text record corresponding to a GUI code in a given language and a given nature
*                                   (System, Report, User, ...).
* DBA_GetRecordByCd               :
* DBA_SelectSumFmtElt             :
* DBA_GetScriptDef                :
* DBA_SendExportRequest           : Function which sends a request ("sel_export_data") to a Financial Server and retrieves a
*                                   description of each column datatype to export.
* DBA_GetExportedData             : Function which retrieves an row of data (one or many columns) according to informations
*                                   stored in a connection structure and exportation context and fills fields given as arguments.
* DBA_FreeDataInExportCtx         : Function which frees allocated arrays and structure in exportation context and, if
*                                   endConnFlg = TRUE, fills allocated objects in connection structure.
* DBA_GetShortByCd                :
* DBA_GetAllByTechKey             :
*
* DBA_FillDataType				  : Fill the value of data type
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#ifdef NTWIN
#pragma warning (push)
#endif


#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "dbafmt.h"
#include "proc.h"
#include "date.h"
#include "cmp.h"
#include "os.h"
#include "dbi.h"
#include "tls.h"
#include "hier.h"
#include "ddlgenfromfile.h"
#include "scpt.h"

#ifdef NTWIN
#pragma warning (pop)
#endif


using namespace std; /* PMSTA-20159 - TEB - 150624 */


/************************************************************************
**      Functions Description
**
** Ex	DBA_LoadPanels		Load DictPanel and create an hierarchy.
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

extern FLAG_T       EV_IsSubscriptionActive;    /* REF4204 */
extern char         EV_SetProcParametersFlg;
extern TIMER_STP    EV_ExtractFileTimerPtr;     /* REF7264 - PMO */
extern FLAG_T       EV_DisplayMLFmtElt;     /* PMSTA13065 - DDV - 111130 */
extern int          EV_AAAInstallLevel;     /* PMSTA-nuodb - LJE - 190724 */

#define ITER_NBR_FOR_DEADLOCK       4    /* Ref.: DVP251 */

static size_t DBA_Empty(void){return 0;}                                                    /* PMSTA-16443 - 230713 - PMO */
bool   (*DBA_WarningMessageBox)(const char *);                                       /* PMSTA-16443 - 230713 - PMO */
size_t (*DBA_GetDataSegmentSize)(void)           = DBA_Empty;                        /* PMSTA-16443 - 230713 - PMO */

STATIC int FIN_FilterDfltCashInstrByCurr(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);	/* PMSTA00485 - RAK - 061122 */

/************************************************************************
*
*  Function          : DBA_SetScriptDynStConfig()
*
*  Description       : Initialize common script definition 'like' dynamic structure
*                      based on the main entity for database/structure accesses
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-28970 - CHU - 171215
*
*  Last modification :
*
************************************************************************/
RET_CODE DBA_SetScriptDynStConfig(OBJECT_ENUM mainDynStEn, DBA_SCRIPT_DYN_STP st_scptStCfg)
{
    RET_CODE ret = RET_SUCCEED;

    st_scptStCfg->mainEntity = mainDynStEn;

    if (st_scptStCfg->mainEntity == TradConstr                ||
        st_scptStCfg->mainEntity == TradingConstraintScript   ||
        st_scptStCfg->mainEntity == A_TradingConstraintScript ||
        st_scptStCfg->mainEntity == S_TradingConstraintScript)
    {
        /* DB access part */
        st_scptStCfg->dbAccessEntity = TradingConstraintScript;
        st_scptStCfg->all_inputStEn  = A_TradingConstraintScript;
        st_scptStCfg->sho_inputStEn  = S_TradingConstraintScript;
        st_scptStCfg->all_outputStEn = A_TradingConstraintScript;
        st_scptStCfg->sho_outputStEn = S_TradingConstraintScript;

        /* ALL attributes */
        st_scptStCfg->A_ScriptSt_Id                 = A_TradingConstraintScript_Id;
        st_scptStCfg->A_ScriptSt_AttrDictId         = A_TradingConstraintScript_AttribDictId;
        st_scptStCfg->A_ScriptSt_ObjId              = A_TradingConstraintScript_ObjId;
        st_scptStCfg->A_ScriptSt_NatEn              = A_TradingConstraintScript_NatEn;
        st_scptStCfg->A_ScriptSt_Rank               = A_TradingConstraintScript_Rank;
        st_scptStCfg->A_ScriptSt_Def                = A_TradingConstraintScript_Definition;
        st_scptStCfg->A_ScriptSt_DimEntityDictId    = A_TradingConstraintScript_DimEntityDictId;
        st_scptStCfg->A_ScriptSt_ScriptEntRefDictId = A_TradingConstraintScript_ScriptEntRefDictId;
        st_scptStCfg->A_ScriptSt_ActionEn           = A_TradingConstraintScript_ActionEn;

        /* SHORT attributes */
        st_scptStCfg->S_ScriptSt_Id                 = S_TradingConstraintScript_Id;
        st_scptStCfg->S_ScriptSt_AttrDictId         = S_TradingConstraintScript_AttribDictId;
        st_scptStCfg->S_ScriptSt_ObjId              = S_TradingConstraintScript_ObjId;
        st_scptStCfg->S_ScriptSt_NatEn              = S_TradingConstraintScript_NatEn;
        st_scptStCfg->S_ScriptSt_Rank               = S_TradingConstraintScript_Rank;
        st_scptStCfg->S_ScriptSt_ActionEn           = S_TradingConstraintScript_ActionEn;
    }
    else if (st_scptStCfg->mainEntity == StratElt                ||
             st_scptStCfg->mainEntity == HoldingConstraintScript ||
             st_scptStCfg->mainEntity == A_HoldingConstraintScript ||
             st_scptStCfg->mainEntity == S_HoldingConstraintScript)
    {
        /* DB access part */
        st_scptStCfg->dbAccessEntity = HoldingConstraintScript;
        st_scptStCfg->all_inputStEn =  A_HoldingConstraintScript;
        st_scptStCfg->sho_inputStEn  = S_HoldingConstraintScript;
        st_scptStCfg->all_outputStEn = A_HoldingConstraintScript;
        st_scptStCfg->sho_outputStEn = S_HoldingConstraintScript;

        /* ALL attributes */
        st_scptStCfg->A_ScriptSt_Id                 = A_HoldingConstraintScript_Id;
        st_scptStCfg->A_ScriptSt_AttrDictId         = A_HoldingConstraintScript_AttribDictId;
        st_scptStCfg->A_ScriptSt_ObjId              = A_HoldingConstraintScript_ObjId;
        st_scptStCfg->A_ScriptSt_NatEn              = A_HoldingConstraintScript_NatEn;
        st_scptStCfg->A_ScriptSt_Rank               = A_HoldingConstraintScript_Rank;
        st_scptStCfg->A_ScriptSt_Def                = A_HoldingConstraintScript_Definition;
        st_scptStCfg->A_ScriptSt_DimEntityDictId    = A_HoldingConstraintScript_DimEntityDictId;
        st_scptStCfg->A_ScriptSt_ScriptEntRefDictId = A_HoldingConstraintScript_ScriptEntRefDictId;
        st_scptStCfg->A_ScriptSt_ActionEn           = A_HoldingConstraintScript_ActionEn;

        /* SHORT attributes */
        st_scptStCfg->S_ScriptSt_Id                 = S_HoldingConstraintScript_Id;
        st_scptStCfg->S_ScriptSt_AttrDictId         = S_HoldingConstraintScript_AttribDictId;
        st_scptStCfg->S_ScriptSt_ObjId              = S_HoldingConstraintScript_ObjId;
        st_scptStCfg->S_ScriptSt_NatEn              = S_HoldingConstraintScript_NatEn;
        st_scptStCfg->S_ScriptSt_Rank               = S_HoldingConstraintScript_Rank;
        st_scptStCfg->S_ScriptSt_ActionEn           = S_HoldingConstraintScript_ActionEn;
    }
    else
    {
        /* DB access part */
        st_scptStCfg->dbAccessEntity = ScriptDef;
        st_scptStCfg->all_inputStEn = A_ScriptDef;
        st_scptStCfg->sho_inputStEn = S_ScriptDef;
        st_scptStCfg->all_outputStEn = A_ScriptDef;
        st_scptStCfg->sho_outputStEn = S_ScriptDef;

        /* ALL attributes */
        st_scptStCfg->A_ScriptSt_Id = A_ScriptDef_Id;
        st_scptStCfg->A_ScriptSt_AttrDictId = A_ScriptDef_AttrDictId;
        st_scptStCfg->A_ScriptSt_ObjId = A_ScriptDef_ObjId;
        st_scptStCfg->A_ScriptSt_NatEn = A_ScriptDef_NatEn;
        st_scptStCfg->A_ScriptSt_Rank = A_ScriptDef_Rank;
        st_scptStCfg->A_ScriptSt_Def = A_ScriptDef_Def;
        st_scptStCfg->A_ScriptSt_DimEntityDictId = A_ScriptDef_DimEntityDictId;
        st_scptStCfg->A_ScriptSt_ScriptEntRefDictId = A_ScriptDef_ScriptEntRefDictId;
        st_scptStCfg->A_ScriptSt_ActionEn = A_ScriptDef_ActionEn;

        /* SHORT attributes */
        st_scptStCfg->S_ScriptSt_Id = S_ScriptDef_Id;
        st_scptStCfg->S_ScriptSt_AttrDictId = S_ScriptDef_AttrDictId;
        st_scptStCfg->S_ScriptSt_ObjId = S_ScriptDef_ObjId;
        st_scptStCfg->S_ScriptSt_NatEn = S_ScriptDef_NatEn;
        st_scptStCfg->S_ScriptSt_Rank = S_ScriptDef_Rank;
        st_scptStCfg->S_ScriptSt_ActionEn = S_ScriptDef_ActionEn;
    }

    /* what about : ?
    FIELD_IDX_T		A_TradingConstraintScript_ChangeSetId;
    FIELD_IDX_T		A_TradingConstraintScript_ChangeSetPromotionId;
    FIELD_IDX_T		A_TradingConstraintScript_ShActionEn;

    FIELD_IDX_T		A_HoldingConstraintScript_ChangeSetId;
    FIELD_IDX_T		A_HoldingConstraintScript_ChangeSetPromotionId;
    FIELD_IDX_T		A_HoldingConstraintScript_ShActionEn;
    */

    return(ret);
}

/************************************************************************
*
*  Function          : DBA_SetWarningMessageBox()
*
*  Description       : Define the GUI function that display a box
*                      asking to continue or cancel the processing
*
*  WARNING           : Designed for the GUI only
*
*  Arguments         : fnWarningMessageBox  Function to call
*
*  Return            : Void
*
*  Creation date     : PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
*
*  Last modification :
*
*************************************************************************/
void DBA_SetWarningMessageBox(bool (*fnWarningMessageBox)(const char *))
{
	DBA_WarningMessageBox = fnWarningMessageBox;
}


/************************************************************************
*
*  Function          : DBA_SetGetDataSegmentSize()
*
*  Description       : Define the GUI function that return
*                      the size of the data segment
*
*  WARNING           : Designed for the GUI only
*
*  Arguments         : fnGetDataSegmentSize  Function to call
*
*  Return            : Void
*
*  Creation date     : PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
*
*  Last modification :
*
*************************************************************************/
void DBA_SetGetDataSegmentSize(size_t (*fnGetDataSegmentSize)(void))
{
	DBA_GetDataSegmentSize = fnGetDataSegmentSize;
}


/************************************************************************
*
*  Function          : DBA_GetDynStMaxLen()
*
*  Description       :
*
*  WARNING           :
*
*  Arguments         :
*
*  Return            : integer.
*
*  Creation date     : Unknown.
*  Last modification :
*
*************************************************************************/
int DBA_GetDynStMaxLen(DBA_DYNST_ENUM dynSt)
{
	int i, maxLen=0, fldNbr;

	fldNbr = GET_FLD_NBR(dynSt);

	for (i=0 ; i<fldNbr ; i++)
		maxLen += GET_FLD_MAXLEN(dynSt, i);

	return(maxLen);
}

/************************************************************************
*
*  Function          : DBA_CheckConstList()
*
*  Description       :
*
*  WARNING           :
*
*  Arguments         : listId  : a list identifier
*                      aList   : pointer on a dynamic structure A_List
*                      status  : pointer on a result status
*
*  Return            : RET_SUCCEED
*
*  Creation date     : 07.10.95 - PEN
*  Last modification : DVP071 PEN (HIER LIST)
*
*************************************************************************/
RET_CODE DBA_CheckConstList(ID_T listId, DBA_DYNFLD_STP aList, DBI_INT *status)
{
    FLAG_T     freeFlg = FALSE;
    DATETIME_T lastDateTime, dbDateTime;
    PERIOD_T   period;
    long       diff;

    if(aList == NULL)
    {
        aList  = ALLOC_DYNST(A_List);
        SET_ID(aList, A_List_Id, listId);
        DBA_Get2(List, UNUSED, A_List, aList, A_List, &aList, UNUSED, UNUSED, UNUSED);
        freeFlg = TRUE;
    }

	if (GET_FLAG(aList, A_List_ActiveFlg) == FALSE)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "Build List Composition: list %1 not built because of Inactiveness", CodeType, GET_CODE(aList, A_List_Cd));
		return(RET_SUCCEED);
	}

    if ((LISTNAT_ENUM)GET_ENUM(aList, A_List_NatEn) != ListNat_Constr &&
        (LISTNAT_ENUM)GET_ENUM(aList, A_List_NatEn) != ListNat_Search &&
        (LISTNAT_ENUM)GET_ENUM(aList, A_List_NatEn) != ListNat_Hierarch)
    {
        if (status)
            *status = CHK_LIST_NOT_CONST;
        if(freeFlg == TRUE)
            FREE_DYNST(aList,A_List);
        return(RET_SUCCEED);
    }

    if(IS_NULLFLD(aList, A_List_ValidPeriod) == TRUE ||
       DBA_GetApplSessionChangeSetId() != 0)         /* PMSTA_26250 - DDV - 170411 - Avoid list_compo usage and storage when an OUS is active */
    {
        if (status)
        {
            if((LISTNAT_ENUM) GET_ENUM(aList, A_List_NatEn) == ListNat_Hierarch)
                *status = CHK_LIST_HIER_NON_PERIODIC;
            else
                *status = CHK_LIST_NON_PERIODIC;
        }
        if(freeFlg == TRUE)
        FREE_DYNST(aList,A_List);
        return(RET_SUCCEED);
    }

    if (IS_NULLFLD(aList, A_List_LastConstructDate) == TRUE)
    {
        if (status)
        {
            if((LISTNAT_ENUM) GET_ENUM(aList, A_List_NatEn) == ListNat_Hierarch)
                *status = CHK_LIST_HIER_MUST_BE_BUILT;
            else
                *status = CHK_LIST_MUST_BE_BUILT;
        }
        if(freeFlg == TRUE)
        FREE_DYNST(aList,A_List);
        return(RET_SUCCEED);
    }

    DBA_GetDbDate(&dbDateTime); /* PMSTA-42605 - DDV - 210215 - Use DBA_GetDbDate instead of DATE_CurrentDate to avoid time zone effect */
    period = GET_PERIOD(aList, A_List_ValidPeriod);
    lastDateTime = GET_DATETIME(aList, A_List_LastConstructDate);
    DATE_DaysBetween(lastDateTime.date, dbDateTime.date, AccrRule_Actual_Actual, &diff, 0); /* PMSTA-22396  - SRIDHARA � 160430 */

    if(diff >= period)
    {
        if (status)
        {
            if((LISTNAT_ENUM) GET_ENUM(aList, A_List_NatEn) == ListNat_Hierarch)
                *status = CHK_LIST_HIER_MUST_BE_BUILT;
            else
                *status = CHK_LIST_MUST_BE_BUILT;
        }
        if(freeFlg == TRUE)
            FREE_DYNST(aList,A_List);
        return(RET_SUCCEED);
    }
    else
    {
        if (status)
            *status = CHK_LIST_ALREADY_BUILT;
    }

    if(freeFlg == TRUE)
        FREE_DYNST(aList,A_List);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_DynSqlStrPrep()
*
*   Description          : Prepare a sql string representing a SQL Dynamic
*                          request to be DBI compatible
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Creation Date        : PMSTA-20159 - TEB - 150624
*
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_DynSqlStrPrep(string & sqlExecString, DBA_RDBMS_ENUM rdbmsEn, std::set<OBJECT_ENUM> *objectEnumSetPtr)
{
    /* PMSTA-20159 - LJE - 151110 */
    if  (sqlExecString.find("#") != string::npos)
    {
        DdlGenContext   ddlGenContext(rdbmsEn, true);
        DdlGenFromFile *scriptDdlGenPtr = new DdlGenFromFile(ddlGenContext);
        scriptDdlGenPtr->setAvoidSecurity(true);

        if (rdbmsEn != QtHttp)
        {
            DdlGenDbi::convertSqlBlock(sqlExecString, scriptDdlGenPtr);
        }
        else if (objectEnumSetPtr != nullptr)
        {
            string tmpSqlExecString(sqlExecString);
            DdlGenDbi::convertSqlBlock(tmpSqlExecString, scriptDdlGenPtr);
        }

        if (objectEnumSetPtr != nullptr)
        {
            auto &dependsEntityMa = scriptDdlGenPtr->getDdlGenContextPtr()->m_dependsEntityMap;
            for (auto it = dependsEntityMa.begin(); it != dependsEntityMa.end(); ++it)
            {
                objectEnumSetPtr->insert(it->second->objectEn);
            }
        }

        delete scriptDdlGenPtr;
    }

	return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBA_SqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request.
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*                          forcedConnectNo : a connection number
*                          option          : DBA_SET_CONN or UNUSED
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Creation Date        : Oct.  95 - PEN
*   Last Modification    : 11.09.96 - PEC - Ref.: DVP178
*                          18.09.96 - PEC - Ref.: DVP178+
*                          16.10.96 - PEC - Ref.: DVP178+ -> Deadlock handling : waitfor delay 00:00:0x
*                          17.10.96 - PEC - Ref.: BUG186
*                          REF5010 - SSO - 000828 : code moved in DBA_SqlExecSt
*************************************************************************/
RET_CODE DBA_SqlExec(const char *sqlBuff, int forcedConnectNo, int option) /* DLA - REF8728 */
{
    DBI_INT        status = -1;
	RET_CODE	   ret = RET_SUCCEED;
	DbiConnection* dbiConn = nullptr;

	if ((option & DBA_SET_CONN) != DBA_SET_CONN)
	{
		if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
		{
			return(RET_DBA_ERR_CONNOTFOUND);  /* added REF5010 - SSO - 000828 */
		}
	}
	else
	{
		if ((dbiConn = DBA_GetDbiConnFromConnectNo(forcedConnectNo)) == nullptr){
			return(RET_DBA_ERR_CONNOTFOUND);
		}
	}

	ret = (dbiConn->sqlExecSt(sqlBuff, &status));

	if ((option & DBA_SET_CONN) != DBA_SET_CONN)
	{
		DBA_EndConnection(&dbiConn, ret == RET_SRV_LIB_ERR_DEADLOCK);
	}

	return ret;
}

/************************************************************************
*   Function             : DBA_SqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request.
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*                          forcedConnectNo : a connection number
*                          option          : DBA_SET_CONN or UNUSED
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Creation Date        : Oct.  95 - PEN
*   Last Modification    : 11.09.96 - PEC - Ref.: DVP178
*                          18.09.96 - PEC - Ref.: DVP178+
*                          16.10.96 - PEC - Ref.: DVP178+ -> Deadlock handling : waitfor delay 00:00:0x
*                          17.10.96 - PEC - Ref.: BUG186
*                          REF5010 - SSO - 000828 : code moved in DBA_SqlExecSt
*                          PMSTA-18593 - LJE - 151130
*************************************************************************/
RET_CODE DBA_SqlExec(const char *sqlBuff, DbiConnection& dbiConn, bool bMultiCmd)
{
    DBI_INT  status = -1;
    string   bufferString;

    if (bMultiCmd)
    {
        bufferString = "#EXEC_BEGIN\n" + string(sqlBuff) + "\n#EXEC_END";
    }
    else
    {
        bufferString = sqlBuff;
    }

	return(dbiConn.sqlExecSt(bufferString.c_str(), &status));
}


/************************************************************************
*   Function             : DBA_ManagedSqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request. Bind status
*
*   Arguments            : sqlExecSt         : the dynamic SQL request
*                          ConnectNo       : pointer on a connection number (to be used if DBA_SET_CONN set)
*                          option          : DBA_SET_CONN or UNUSED
*                          status          : pointer on status to be binded
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Creation Date        : REF5010 - SSO - 000828 code moved from DBA_SqlExec
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_ManagedSqlExec(AAASQL_CONTEXT_STP context, int* status) /* DLA - REF8728 */
{
    return DBI_ManagedSqlExec(context, status);
}


/************************************************************************
*   Function               : DBA_Fetch()
*
*   Description            : Fetch the Sybase result fields (result set)
*
*   Arguments              : connectNo : a connection number in the conn. list
*                            dynSt     : the structure format
*                            destData  : the destination data structure
*
*   Return                 : RET_SUCCEED            : if ok
*                            RET_DBA_ERR_ARGNOMATCH : if argument problem
*                            RET_GEN_ERR_NOACTION   : if action is impossible
*                            RET_GEN_ERR_DBPROBLEM  : if connection/DB problem
*                            RET_DBA_INFO_NODATA    : if no more data to read
*
*   Creation date          : Aug. 94 - PEC
*   Last modification date : 29.8.95 - PEC - Added RET_CODE
*************************************************************************/
RET_CODE DBA_Fetch(DbiConnection& dbiConn, DBA_DYNST_ENUM dynSt, DBA_DYNFLD_STP destData)
{
	DBA_DYNFLD_STP bindStPtr=NULL;
	int            result;

    if (dbiConn.m_bindDynStEn == dynSt)
    {
        bindStPtr = dbiConn.m_bindDynStp;
    }

	if (bindStPtr == NULL)
		MSG_RETURN(RET_GEN_ERR_INVARG);

	if ((result = dbiConn.fetch()) == RET_SUCCEED)    /* REF7264 - PMO */
	{
		/* Update the  NULL flag for each field of the result struct */
		DBI_CopyNullFlagsAndLengthDynSt(dbiConn, bindStPtr, dynSt);
		COPY_DYNST(destData, bindStPtr, dynSt);
	}

    return(result);
}

/************************************************************************
*
*   Function	:   DBA_LoadPanels
*
*   Description	:   Load DictPanel and create an hierarchy.
*
*   Arguments	:   screenDictId
*                   hierHeadPtr
*
*   Return	:   RET_CODE
*
*   Cr�ation    :   ROI - 970120 - DVP200
*					MDE - 991122   Ref3678 change Multiselect in Select
*   Modif           FIH-REF5412-010220
*                   REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                   FIH-REF11425-051025     : Add input parameter
*
*************************************************************************/
RET_CODE DBA_LoadPanels (DICT_T screenDictId, DBA_HIER_HEAD_STP *hierHeadPtrPtr, DICTPANELNAT_ENUM enNature)
{
	DBA_DYNFLD_STP  *data,
					getArgSt;
	ID_T            userId;
	int             rows,
					i;
	DBA_DYNST_ENUM  outputSt;           /* REF7264 - PMO */
	RET_CODE        ret;
	DBA_DYNFLD_STP  *dataNew;           /*  FIH-REF5412-010220  New data table                  */
	int             iNbEqualPanel,      /*  FIH-REF5412-010220  Number of identical panel       */
					iCurrent;           /*  FIH-REF5412-010220  Indexin new table               */
	char            *psz1,              /*  FIH-REF5412-010220  String definition in panel1     */
					*psz2,              /*  FIH-REF5412-010220  String definition in panel2     */
					*psz;               /*  FIH-REF5412-010220  String definition               */
	DBA_DYNFLD_STP  *dynScptDefTab ;    /*  FPL-REF10671-041103 Script definition for availability field    */
	int             iNbScptDef ;        /*  FPL-REF10671-041103 number of Script def for availability field */
	DICT_T          entityDictId;       /*  FPL-REF10671-041103                                             */
	int             iCpt;               /*  FPL-REF10671-041103                                             */
	DBA_HIER_HEAD_STP * hierHeadPtr = (DBA_HIER_HEAD_STP *) hierHeadPtrPtr;   /* REF7264 - PMO */

	/* Check input arguments */
	if (screenDictId <= 0)
	{
	  MSG_SendMesg(RET_GEN_ERR_INVARG,
				   1,
				   FILEINFO,
				   "DBA_LoadPanels",
				   "Invalid Screen DictId"
				  );
		  return RET_GEN_ERR_INVARG;
	}

	/* Check allocation */
	if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
	  MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* Init local arguments */
	*hierHeadPtr = NULL;     /* REF7264 - PMO */
	data = NULL;
	outputSt = A_DictPanel;				/* MDE Ref3678 outputStLst --> outputSt */
	userId = 0;
	rows = 0;
	SET_ID(getArgSt, Get_Arg_Id, screenDictId);
	if (enNature != DictPanelNat_Unused)            /*  FIH-REF11425-051025 */
		SET_ENUM(getArgSt, Get_Arg_NatEn, enNature);

	/*** Load A_DictPanel ***/
	ret = DBA_Select2(DictPanel,		/* MDE Ref3678 */
					   UNUSED,
					   Get_Arg,
					   getArgSt,
					   outputSt,		/* MDE Ref3678 */
					   &data,
					   UNUSED,
					   UNUSED,
					   &rows,
					   UNUSED,
					   NULL				/* MDE Ref3678 */
					  );

	FREE_DYNST(getArgSt, Get_Arg);

	if ((ret == RET_SUCCEED) && (rows > 0))
	{
		/*  FIH-REF5412-010220  Script problem : must not be limit to 256 char  */
		iNbEqualPanel = 0;
		for (i = 0; i < rows - 1; i++)
		{
			if ((IS_NULLFLD(data[i],A_DictPanel_DictId) == FALSE) &&
				(IS_NULLFLD(data[i+1],A_DictPanel_DictId) == FALSE) &&
				(GET_ID(data[i],A_DictPanel_DictId) == GET_ID(data[i+1],A_DictPanel_DictId)))
				iNbEqualPanel++;
		}
		if (iNbEqualPanel != 0)
		{
			dataNew = (DBA_DYNFLD_STP*) CALLOC(rows - iNbEqualPanel, sizeof(DBA_DYNFLD_STP));; /* REF8844 - LJE - 030424 */
			iCurrent = 0;
			for (i = 0; i < rows; i++)
			{
				if ((i == 0) ||
					((IS_NULLFLD(data[i-1],A_DictPanel_DictId) == TRUE) ||
					 (IS_NULLFLD(data[i],A_DictPanel_DictId) == TRUE) ||
					 (GET_ID(data[i-1],A_DictPanel_DictId) != GET_ID(data[i],A_DictPanel_DictId))))
				{
					if (i != 0)
						iCurrent++;
					dataNew[iCurrent] = ALLOC_DYNST(A_DictPanel);
					COPY_DYNST(dataNew[iCurrent],data[i],A_DictPanel);
				}
				else
				{
					if ((IS_NULLFLD(data[i],A_DictPanel_PanelScriptDef) == FALSE) &&
						((psz2 = GET_STRING(data[i],A_DictPanel_PanelScriptDef)) != NULL))
					{
						if ((IS_NULLFLD(dataNew[iCurrent],A_DictPanel_PanelScriptDef) == FALSE) &&
							((psz1 = GET_STRING(dataNew[iCurrent],A_DictPanel_PanelScriptDef)) != NULL))
						{
							psz = (char *) CALLOC(SYS_StrLen(psz1) + SYS_StrLen(psz2) + 1, sizeof(char)); /* REF7264 - PMO */
							strcat(psz,psz1);
						}
						else
							psz = (char *) CALLOC(SYS_StrLen(psz2) + 1, sizeof(char));   /* REF7264 - PMO */
						strcat(psz,psz2);
						SET_NULL_STRING(dataNew[iCurrent],A_DictPanel_PanelScriptDef);
						SET_STRING(dataNew[iCurrent],A_DictPanel_PanelScriptDef,psz);
						FREE(psz);
					}
				}
			}
			DBA_FreeDynStTab(data,rows,A_DictPanel);
			rows -= iNbEqualPanel;
			data = dataNew;
		}


		/*** Get the availability from scriptDef to set A_DictPanel_AvailabilityDef FPL-REF10671-041103 ***/

		if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		/* Init local arguments */
		dynScptDefTab   = NULL ;
		iNbScptDef      = 0 ;
		DBA_GetDictId(DictScreen, &entityDictId);

		SET_DICT ( getArgSt, Get_Arg_EntDictId, entityDictId );
		SET_ID   ( getArgSt, Get_Arg_ObjId,     screenDictId );
		SET_ENUM ( getArgSt, Get_Arg_Enum1,     ScriptDef_Availability );

		/* Load A_ScriptDef */
		ret = DBA_Select2 ( ScriptDef
						  , DBA_ROLE_SCPT_OBJECT_AND_NATURE
						  , Get_Arg
						  , getArgSt
						  , A_ScriptDef
						  , &dynScptDefTab
						  , UNUSED
						  , UNUSED
						  , &iNbScptDef
						  , UNUSED
						  , NULL
						  );

		FREE_DYNST(getArgSt, Get_Arg);

		if ((ret == RET_SUCCEED) && (iNbScptDef > 0))
		{
			for (iCpt = 0 ; iCpt < rows ; iCpt++)       /*  loop on data            */
			{
				for (i = 0 ; i < iNbScptDef ; i++)      /*  loop on dynScptDefTab   */
				{
					if (GET_ID (data[iCpt], A_DictPanel_DictId) == GET_ID(dynScptDefTab[i],A_ScriptDef_ObjId))
					{
						if ((IS_NULLFLD(dynScptDefTab[i], A_ScriptDef_Def) == FALSE) &&
							((psz2 = GET_STRING(dynScptDefTab[i], A_ScriptDef_Def)) != NULL))
						{
							if ((IS_NULLFLD(data[iCpt], A_DictPanel_AvailabilityDef) == FALSE) &&
								((psz1 = GET_STRING(data[iCpt], A_DictPanel_AvailabilityDef)) != NULL))
							{
								psz = (char *) CALLOC(SYS_StrLen(psz1) + SYS_StrLen(psz2) + 1, sizeof(char));
								strcat(psz,psz1);
							}
							else
								psz = (char *) CALLOC(SYS_StrLen(psz2) + 1, sizeof(char));
							strcat(psz,psz2);
							SET_NULL_STRING(data[iCpt], A_DictPanel_AvailabilityDef);
							SET_STRING(data[iCpt], A_DictPanel_AvailabilityDef, psz);
							FREE(psz);
						}
					}
				}
			}
		}
		for (i=0; i < iNbScptDef; i++)
			FREE_DYNST(dynScptDefTab[i], A_ScriptDef);
		FREE(dynScptDefTab);




		/*** Create hierarchy hieader ***/
		*hierHeadPtr = DBA_CreateHier();  /* REF5239 - RAK - 001025 / REF7264 - PMO */
		if (*hierHeadPtr != NULL)
		{
			if (enNature == DictPanelNat_Unused)                /*  FIH-REF11425-051025 */
			{
				/*** Set used link A_DictPanel_A_ParPanel_Ext ***/
				ret = DBA_SetHierLnkUsed(*hierHeadPtr,A_DictPanel,A_DictPanel_A_ParPanel_Ext);

				if (ret == RET_SUCCEED)
				{
					/*** Set used link A_DictPanel_A_ChildPanel_Ext ***/
					ret = DBA_SetHierLnkUsed(*hierHeadPtr,A_DictPanel,A_DictPanel_A_ChildPanel_Ext);
				}
			}

			if (ret == RET_SUCCEED)
				/* Use hierarchy definition Hier_Fmt */
				ret = DBA_AddHierRecordList(*hierHeadPtr,
											data,
											rows,
											outputSt,			/* MDE Ref3678 */
											TRUE
											);

			if ((ret == RET_SUCCEED) &&
				(enNature == DictPanelNat_Unused))              /*  FIH-REF11425-051025 */
			{
				/*** Create hierarchy links ***/
				ret = DBA_MakeLinks(*hierHeadPtr);
			}
		}
	}

	if (ret != RET_SUCCEED)
	{
		for (i=0; i < rows; i++)
			FREE_DYNST(data[i], outputSt);			/* MDE Ref3678 */
	}
	FREE(data);		/* BUG452 - 970827 - XMT: allways free data */

	return ret;
}


/************************************************************************
**
**  Function    :   DBA_LoadFormats
**
**  Description :   Load format, format_element, script definition
**                         and create all hierarchies :
**
**  Arguments   :   fctId
**					fmtId
**					langDictId
**					role
**					fmtCode
**					hierHeadPtrPtr
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   PEC - 941212
**  Modif.		:   ROI - 970623 - DVP512
**  Modif.		:   ROI - 990218 - REF3339
**  Modif.		:	ROI - 990329 - REF3418
**  Modif.		:	ROI - 990629 - REF3729
**  Modif.      :   FIH-REF11317-050915     Add 4th bloc
**
*************************************************************************/
RET_CODE DBA_LoadFormats(DICT_T fctId, ID_T fmtId, DICT_T langDictId, int role, char* fmtCode, PTR* hierHeadPtrPtr)
{
	ID_T                    userId = (ID_T) 0;
	DBA_DYNFLD_STP          admArg = NULL;
	DBA_DYNFLD_STP          *data[4]={NULL,  NULL, NULL, NULL};
	DBA_DYNST_ENUM          stEnum;
	int                     rows[4]={0,0,0,0},
							i, j, k;
	const DBA_DYNST_ENUM    *outputStLst[] = {&E_Fmt, &A_FmtElt, &A_ScriptDef, &A_ScriptDef};       /* REF8844 - LJE - 030415 */    /*  FIH-REF11317-050915 Add 4th bloc    */
	DICT_T                  attrDictId,
							scriptDefAttrDictId = 0;
	ID_T                    idFmt;                                                                  /*  FIH-REF11317-050916 */
	RET_CODE                retCode = RET_SUCCEED;
    FIELD_IDX_T             firstScript = 0,
							secondScript = 0;
	DBA_HIER_HEAD_STP       *hierHeadPtr = (DBA_HIER_HEAD_STP *) hierHeadPtrPtr;                    /* REF7264 - PMO */
	char                    *pszScript,                                                             /*  FIH-REF11317-050916 */
							*pszCellFmtScript;                                                      /*  FIH-REF11317-050916 */
	SYSNAME_T               sqlname;
	int                     pos;
    GenerateFmteltScopeEn   enGenerateScope = GenerateFmteltScopeEn::FormatProfile;                /*  HFI-PMSTA-38117-200304  */

	/* Test given arguments */
	if (hierHeadPtr != NULL)
	{
		/* Init local variables */
		userId= (ID_T) 0;
		admArg = NULL;
		stEnum = NullDynSt;
		*hierHeadPtr = NULL;  /* REF7264 - PMO */
		retCode = RET_SUCCEED;
		attrDictId = 0;
		pszScript = (char*) CALLOC(GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC , sizeof(char));          /* PMSTA-33077 - DLA - 181011 */
		pszCellFmtScript = (char*) CALLOC(GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC , sizeof(char));   /* PMSTA-33077 - DLA - 181011 */

		/* Test allocation */
		if ((fctId != 0) || (fmtId != 0) || (fmtCode != NULL))
		{
			stEnum = Adm_Arg;
			admArg = ALLOC_DYNST(stEnum);
			if (admArg == NULL)
			{
				retCode = RET_MEM_ERR_ALLOC;
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			}
			else
			{
				GEN_GetUserInfo(UserId, &userId);
				if (userId != 0)
					SET_ID(admArg, Adm_Arg_UserId, userId);     /* DLA - REF9089 - 030512 */
				if (fctId != 0)
					SET_DICT(admArg, Adm_Arg_FctDictId, fctId);
				if (fmtId != 0)
                {
					SET_ID(admArg, Adm_Arg_Id, fmtId);          /* DLA - REF9089 - 030512 */
                    enGenerateScope = GenerateFmteltScopeEn::OneFormat;
                }
				if (fmtCode != NULL)                            /* REF3729 */
					SET_CODE(admArg, Adm_Arg_Code, fmtCode);

				/* REF3339 - RAK - 990219 */
				/* Use CodifId because we won't add a new field to Adm_Arg */
				if (langDictId != 0)
					SET_DICT(admArg, Adm_Arg_CodifId, langDictId);
			}
		}

        /*  Check if format element list has to be generated        */      /*  HFI-PMSTA-38117-200304  */
        DBA_GenerateFormatElement ( enGenerateScope,                /*  OneFormat or ProfileFormats     */
                                    fmtId,
                                    userId,
                                    UNUSED,
                                    fctId,
                                    FALSE,
                                    GenerateFmteltCheckApplParamEn::Yes);

		/* Load 4 tables */
		if (retCode == RET_SUCCEED)
			retCode = DBA_MultiSelect2 (Fmt,
										role,                   /* REF3729 */
										stEnum,
										admArg,
										outputStLst,
										data,
										UNUSED,
										UNUSED,
										rows,
										UNUSED,
										UNUSED
									   );

        /*  Free input multi select parameter                   */
		if (admArg != NULL)
			FREE_DYNST(admArg, stEnum);

		/* Concat all script definitions for each format element */
		if ((retCode == RET_SUCCEED) && (rows[0] > 0)  && (rows[1] > 0))	/* REF3418 */
		{
			/* Concat A_FmtElt_CellFmt & A_FmtElt_ScriptDef for same FmtElt */
			j = 0;
			if (rows[2] > 0)
			{
				/* Init some variables */
				scriptDefAttrDictId = 0;
				DICT_GetAttribInfo (FmtElt,
									-1,
									0,						/* attrDictId */
									"script_definition",	/* sqlName */
									A_DictAttr_DictId,
									&scriptDefAttrDictId
								   );
			}

			for (i=0; i < rows[1] && j < rows[2]; i++)
			{

				/* PMSTA13065 - DDV - 111130 - If AAADISPLAYMLFMTELT is set, copy display column from main element to children element to display them */
				if (EV_DisplayMLFmtElt == TRUE &&
					GET_ENUM(data[1][i], A_FmtElt_TslMultilingualEn) == TslMultilingual_MultilingualChild &&
					IS_NULLFLD(data[1][i], A_FmtElt_DispColumn) == TRUE)
				{
					strcpy(sqlname, GET_SYSNAME(data[1][i], A_FmtElt_SqlName));
					pos=SYS_StrLen(sqlname);
					while (pos >0 && sqlname[pos] != '_')
						pos--;

					if (pos>0)
					{
						sqlname[pos] = END_OF_STRING;
						for(k=0; k<rows[1]; k++)
						{
							if (GET_ID(data[1][k], A_FmtElt_FmtId) == GET_ID(data[1][i], A_FmtElt_FmtId) &&
								strcmp(GET_SYSNAME(data[1][k], A_FmtElt_SqlName), sqlname) == 0)
							{
								SET_SMALLINT(data[1][i], A_FmtElt_DispColumn, GET_SMALLINT(data[1][k], A_FmtElt_DispColumn));
								break;
							}
						}
					}
				}

				/* Choose first and second attribute */
				attrDictId = GET_DICT(data[2][j], A_ScriptDef_AttrDictId);
				if (attrDictId == scriptDefAttrDictId)
				{
					firstScript = A_FmtElt_ScriptDef;
					secondScript = A_FmtElt_CellFmt;
				}
				else
				{
					firstScript = A_FmtElt_CellFmt;
					secondScript = A_FmtElt_ScriptDef;
				}

				/* Concat A_FmtElt_ScriptDef */
				k = 0;
				pszScript[0] = END_OF_STRING;
				while ((j < rows[2]) &&
					   (attrDictId == GET_DICT(data[2][j], A_ScriptDef_AttrDictId)) &&
					   (GET_ID(data[1][i], A_FmtElt_Id) == GET_ID(data[2][j], A_ScriptDef_ObjId)) &&
					   (k < SCPTDEF_MAX_REC))
				{
					strcat(pszScript, GET_STRING(data[2][j], A_ScriptDef_Def));
					attrDictId = GET_DICT(data[2][j], A_ScriptDef_AttrDictId);
					j++;
					k++;
				}

				/* Fill format_element script definition attribute */
				if (pszScript[0] != END_OF_STRING)
					SET_NOTE(data[1][i], firstScript, pszScript);

				/* Concat A_FmtElt_CellFmt */
				k = 0;
				pszScript[0] = END_OF_STRING;
				while ((j < rows[2]) &&
					   (GET_ID(data[1][i], A_FmtElt_Id) == GET_ID(data[2][j], A_ScriptDef_ObjId)) &&
					   (k < SCPTDEF_MAX_REC))
				{
					strcat(pszScript, GET_STRING(data[2][j], A_ScriptDef_Def));
					j++;
					k++;
				}

				/* Fill format_element cell format attribute */
				if (pszScript[0] != END_OF_STRING)
					SET_NOTE(data[1][i], secondScript, pszScript);
			}

			/* Create hierarchy hieader */
			*hierHeadPtr = DBA_CreateHier();    /* REF5239 - RAK - 001025 */
			if (*hierHeadPtr == NULL) /* REF7264 - PMO */
			{
				retCode = RET_MEM_ERR_ALLOC;
				MSG_SendMesg(retCode, 0, FILEINFO);
			}

			/* Set link to used */
			if (retCode == RET_SUCCEED)
			{
				retCode = DBA_SetHierLnkUsed(*hierHeadPtr, E_Fmt, E_Fmt_A_FmtElt_Ext);
				if (retCode == RET_SUCCEED)
				{
					retCode = DBA_SetHierLnkUsed(*hierHeadPtr, E_Fmt, E_Fmt_E_ChildFmt_Ext);

					/* Use hierarchy definition Hier_Fmt */
					if (retCode == RET_SUCCEED)
					{
						for (i=0; (i < 2)  && (retCode == RET_SUCCEED); i++)
							retCode = DBA_AddHierRecordList(*hierHeadPtr,
															data[i],
															rows[i],
															*(outputStLst[i]), /* REF7264 - PMO */
															TRUE
														   );
						/*** Create hierarchy links ***/
						if (retCode == RET_SUCCEED)
							retCode = DBA_MakeLinks(*hierHeadPtr);
					}
				}
			}

			/*  Add Row Format Definition to A_FmtElt_CellFmt               */  /*  FIH-REF11317-050915 */
			if (rows[3] > 0)
			{
				for (i = 0; i < rows[3]; i++)
				{
					idFmt = GET_DICT(data[3][i], A_ScriptDef_ObjId);
					k = 0;
					j = i;
					pszScript[0] = END_OF_STRING;
					while ((j < rows[3]) &&
						   (idFmt == GET_DICT(data[3][j], A_ScriptDef_ObjId)) &&
						   (k < SCPTDEF_MAX_REC))
					{
						strcat(pszScript, GET_STRING(data[3][j], A_ScriptDef_Def));
						j++;
						k++;
						i = j -1;
					}

					/* Fill format_element cell format attribute */
					if (pszScript[0] != END_OF_STRING)
					{
						for (j = 0;(j < rows[1]) &&
								   (idFmt != GET_DICT(data[1][j], A_FmtElt_FmtId)); j++);
						if (j < rows[1])
						{
							while ((j < rows[1]) &&         /*  FPL-080605-PMSTA06648   */
								   (idFmt == GET_DICT(data[1][j], A_FmtElt_FmtId)))
							{
								if (IS_NULLFLD(data[1][j], A_FmtElt_CellFmt) == FALSE)
								{
									sprintf(pszCellFmtScript,"%s;%s",pszScript,GET_STRING(data[1][j], A_FmtElt_CellFmt));
									SET_NOTE(data[1][j], A_FmtElt_CellFmt, pszCellFmtScript);
								}
								else
								{
									SET_NOTE(data[1][j], A_FmtElt_CellFmt, pszScript);
								}
								j++;
							}
						}
					}
				}
			}
		}
		/*  Free memory allocated for string                */  /*  FIH-REF11317-050916 */
		FREE(pszCellFmtScript);
		FREE(pszScript);
	}

	if (retCode != RET_SUCCEED)
		DBA_MultiFree(data, outputStLst, rows, 4);
	else
	{
		/* Free A_ScriptDef_Def which is not kept in hierarchy */
		DBA_FreeDynStTab(data[2], rows[2], *(outputStLst[2]));  /* REF8844 - LJE - 030415 */
		DBA_FreeDynStTab(data[3], rows[3], *(outputStLst[3]));  /*  FIH-REF11317-050916 */
		FREE(data[0]);
		FREE(data[1]);
	}

	return retCode;
}


/************************************************************************
*   Function             : DBA_LoadSearchFormat()
*
*   Description          : Load format, format_element, script definition
*                          and create all hierarchies :
*
*   Arguments            : fmtStp           a short format structure pointer
*                          hierHeadPtrPtr   pointer on hierarchy header
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : DVP219 - 960106 - RAK
*   Last modif.          : REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_LoadSearchFormat(DBA_DYNFLD_STP fmtStp, PTR *hierHeadPtrPtr)
{
	DBA_DYNFLD_STP 	*data[3]={NULL,
					  NULL,
					  NULL},
			getArgSt=NULL;
	ID_T		userId=(ID_T)0;
	int            	rows[3]={0,0,0},
				i, j, k;
	const DBA_DYNST_ENUM *outputStLst[] = {&E_Fmt, &A_FmtElt, &A_ScriptDef}; /* REF8844 - LJE - 030415 */
	char           	scptBuf[sizeof(NOTE_T) * SCPTDEF_MAX_REC];              /* PMSTA-33077 - DLA - 181011 */
	RET_CODE	ret;
	DBA_HIER_HEAD_STP * hierHeadPtr = (DBA_HIER_HEAD_STP *) hierHeadPtrPtr;    /* REF7264 - PMO */

	*hierHeadPtr = NULL; /* REF7264 - PMO */

	/*** input arguments ***/
	if (IS_NULLFLD(fmtStp, S_Fmt_Id) == TRUE)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_LoadSearchFormat", "format id");
				return(RET_GEN_ERR_INVARG);
	}

	if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

		GEN_GetUserInfo(UserId, &userId);
		SET_ID(getArgSt, Get_Arg_Id,     GET_ID(fmtStp, S_Fmt_Id));
		SET_ID(getArgSt, Get_Arg_UserId, userId);

	/*** Load 3 tables ***/
	if ((ret = DBA_MultiSelect2(Fmt, UNUSED, Get_Arg, getArgSt, outputStLst, data,
								UNUSED, UNUSED, rows, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		return(ret);
	}

	FREE_DYNST(getArgSt, Get_Arg);

	/* Concat all script definitions for each format element */
	j=0;
	for (i=0; i<rows[1] && j<rows[2]; i++)
	{
		/* Concat definitions for the same format element */
		k=0;
		scptBuf[0] = END_OF_STRING;
		while (j < rows[2] &&
			GET_ID(data[1][i], A_FmtElt_Id) == GET_ID(data[2][j], A_ScriptDef_ObjId) &&
			k < SCPTDEF_MAX_REC)
			{
					strcat(scptBuf, GET_STRING(data[2][j], A_ScriptDef_Def));
			j++;
			k++;
		}

		/* Fill format_element script definition attribute */
				SET_NOTE(data[1][i], A_FmtElt_ScriptDef, scptBuf);
	}

	/*** Create hierarchy hieader ***/
	if ((*hierHeadPtr = DBA_CreateHier()) == NULL)  /* REF5239 - RAK - 001025 / REF7264 - PMO */
	{
		return(RET_DBA_ERR_HIER);
	}

	/*** Set link to used ***/
	if (DBA_SetHierLnkUsed(*hierHeadPtr, E_Fmt, E_Fmt_A_FmtElt_Ext) != RET_SUCCEED)
	{
		return(RET_DBA_ERR_HIER);
	}

	/*** Distribute procedure output into hierarchy ***/
	/* Use hierarchy definition Hier_Fmt */
	for (i=0; i<2; i++)
	{
		if ((ret = DBA_AddHierRecordList(*hierHeadPtr, data[i], rows[i],
						 *(outputStLst[i]), TRUE)) != RET_SUCCEED) /* REF7264 - PMO */
		{
			for (j=0; j<3; j++)
			{
				for(k=0; k<rows[j]; k++)
					FREE_DYNST(data[j][k], *(outputStLst[j]));
				FREE(data[j]);
			}
			return(ret);
		}
	}

	/*** Create hierarchy links ***/
	if ((ret = DBA_MakeLinks(*hierHeadPtr)) != RET_SUCCEED)
	{
		for (j=0; j<3; j++)
		{
			for(k=0; k<rows[j]; k++)
				FREE_DYNST(data[j][k], *(outputStLst[j]));
			FREE(data[j]);
		}
		return(ret);
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_FreeDynStTab()
*
*   Description          : Free a DBA_DYNFLD_STP array and all allocated
*                          dynamic structures.
*
*   Arguments            : table     : pointer on a dynamic structure array
*                          rowNbr    : the dynamic structure number
*                          dynSt     : the dynamic struct. format
*
*
*   Functions call       : DBA_Free
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*
*   Creation Date        : Nov.  94 - PEC
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_FreeDynStTab(DBA_DYNFLD_STP *table, int rowNbr, DBA_DYNST_ENUM dynSt)
{
    if (table == nullptr)
    {
        return(RET_DBA_ERR_ARGNOMATCH);
    }

    if (dynSt == NullDynSt && table != nullptr)
    {
        dynSt = table[0]->getDynStEn();
    }

    for (int i = 0; i < rowNbr; i++)
	{
        FREE_DYNST(table[i], dynSt);
	}

	FREE(table);

	return(RET_SUCCEED);
}


/************************************************************************
*   Function             : DBA_FreeDynStVector()
*
*   Description          : Free a DBA_DYNFLD_STP vector and all allocated
*                          dynamic structures.
*
*   Arguments            : vector     : refernce to a vector of dynamic structures
*                          dynSt     : the dynamic struct. format
*
*   Functions call       : DBA_Free
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA-43233 - JBC - 210124
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_FreeDynStVector(std::vector<DBA_DYNFLD_STP> & vector, DBA_DYNST_ENUM dynSt)
{
	if(vector.empty() == false)
	{
		for(auto it = vector.begin(); it != vector.end(); ++it)
		{
			if ((*it) != NULL)
				FREE_DYNST((*it), dynSt);
		}

	    vector.clear();
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetDomainFctResults()
*
*   Description          :
*
*   Arguments            : dataStruct : pointer addres on a DBA_DATARESULT_ST
*                                       structure (NOT ALLOCATED).
*                          fDomainSt  : pointer on a A_Domain dynamic structure
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if problem with input argument
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure found
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                          RET_DBA_ERR_SETPARAM     : if problem while setting param.
*                          RET_DBA_ERR_DBPROBLEM    : if conn./DB problem
*                          RET_DBA_ERR_DISCONNECTED : if connection is dead
*                 RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT : if no formats for fin. function
*                          RET_MEM_ERR_ALLOC        : if memory allocation failed
*                          RET_GEN_INFO_NODATA      : if no rows returned by server
*                          RET_DBA_ERR_DIALOG       : if dialog problem with server
*
*   Creation date        :
*   Last Modif. Date     : 29.8.95 - PEC - Added RET_CODE
*************************************************************************/
RET_CODE DBA_GetDomainFctResults(DBA_DATARESULT_STP *dataStruct,
								 DBA_DYNFLD_STP     fDomainSt)
{
	/****************************************************
	DBA_PROC_STP       procedure=NULL;
	int                retCode, resultType, status, connectNo;
	ID_T               userId;
	OBJECT_ENUM        obj;
	****************************************************/

	DBA_GetFinFctResults(dataStruct, fDomainSt, NULL);          /*  FIH-REF9764-040128  Add last parameter NULL */

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetFinFctResults()
*
*   Description          : Retrieve format element information, data descrip-
*                          tion and data rows returned by Open Server after a
*                          call to Financial Function (Valorisation, ...).
*
*   Arguments            : dataStruct : pointer addres on a DBA_DATARESULT_ST
*                                       structure (NOT ALLOCATED).
*                          fDomainSt  : pointer on a A_Domain dynamic structure
*
*   Functions call       :
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if problem with input argument
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure found
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                          RET_DBA_ERR_SETPARAM     : if problem while setting param.
*                          RET_DBA_ERR_DBPROBLEM    : if conn./DB problem
*                          RET_DBA_ERR_DISCONNECTED : if connection is dead
*                 RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT : if no formats for fin. function
*                          RET_MEM_ERR_ALLOC        : if memory allocation failed
*                          RET_GEN_INFO_NODATA      : if no rows returned by server
*                          RET_DBA_ERR_DIALOG       : if dialog problem with server
*
*   Creation date        : Dec. 94 - PEC
*   Last Modif. Date     : 29.8.95 - PEC - Added RET_CODE.
*                          19.7.99 - GRD - REF3537.
*	                       ROI - 000511 - REF2467
*                          MRA - 010308 - REF5737
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          FIH-REF9764-040128  Add ptrHierCollection
*                          REF9764 - TEB - 040203 : Unmatched execution
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                          PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
RET_CODE DBA_GetFinFctResults  (DBA_DATARESULT_STP  *dataStruct,
								DBA_DYNFLD_STP      fDomainSt,
								PTR                 ptrHierCollection)
{
    RET_CODE            retCode;
    DBI_INT             resultType, status;
    int                 i, opRowCount;
	DICT_T              fctEnum;    /*  FPL-PMSTA08801-100714 DICT_FCT_ENUM */
	ID_T                userId;
	RET_CODE            ret;
	DBA_DATARESULT_STP  dataResStp;
	DBA_DATASET_STP     setStp;
	RET_CODE            retCodeGui  = RET_SUCCEED ; /*  FPL-PMSTA07412-090330   */
    CODE_T              applSessionCd;

	if (!fDomainSt)
		MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);

	/* Get User Id information */
	GEN_GetUserInfo(UserId, &userId);

	/* Save User Id in A_Domain structure to send to Open Server */
	SET_ID(fDomainSt, A_Domain_UsrId, userId);

    DBA_GetApplSessionCode(&applSessionCd); /* PMSTA-22549 - DDV - 160616 */
    SET_CODE(fDomainSt, A_Domain_ApplSessionCd, applSessionCd); /* PMSTA-22549 - DDV - 160616 */

	OBJECT_ENUM obj = FinAnalysis;

	SET_ENUM(fDomainSt, A_Domain_OutputTpEn, ClientModuleOutput);
	SET_FLAG(fDomainSt, A_Domain_NonEnumInstrFlg, 0);

	if (SYS_GetEnv("AAAREF7386TEST") != NULL)
	{
		TIMER_ST timer;
		DBA_DYNFLD_STP record = ALLOC_DYNST(Arg_Test);

		DATE_ResetTimer(&timer, TIMER_MASK_GEN);
		DATE_StartTimer(&timer, TIMER_MASK_GEN);

		for (int n = 0; n < 128; n++)
			DBA_Notif(
				Domain, DBA_ROLE_COLLECT,
					A_Domain, fDomainSt, UNUSED, UNUSED);

		DATE_StopTimer(&timer, TIMER_MASK_GEN);

		SET_SYSNAME(record, Arg_Test_Sysname, "dump");

		DBA_Notif(
			Test, DBA_ROLE_CALL_WITH_COLLECTION,
				Arg_Test, record, UNUSED, UNUSED);

		FREE_DYNST(record, Arg_Test);
	}

	DBA_PROC_STP procedure = DBA_GetStoredProcs(SelMetaDict, obj, UNUSED, A_Domain, fDomainSt, NullDynSt);

	if (procedure == NULL)
	{
		char    objString[40];
        const char    *sqlName = DBA_GetDictEntitySqlName(obj);

		if (sqlName != NULL)
		{
			strcpy(objString, sqlName);
		}
		else
		{
			sprintf(objString, "unknown(" szFormatObj ")",obj);/* REF2697 - SSO - 000510 */
		}
		MSG_LogMesg(RET_DBA_ERR_PROCNOTFOUND, 3, FILEINFO, "FinFctResults", objString, "domain", "none");/* REF2697 - SSO - 000510 */
		return(RET_DBA_ERR_PROCNOTFOUND);
	}

	/* Get a free connection */
    DbiConnectionHelper	dbiConnHelper(procedure->server);
	if (false == dbiConnHelper.isValidAndInit())
	{
        bool brokenConnection = true;                                                                   /* PMSTA-25644 - 141216 - PMO */

        /* PMSTA-25644 - 141216 - PMO */
        AAAConnectionType connectionType = dbiConnHelper.getDescription().getType();
        if (FinServer == procedure->server && NullServer == connectionType)
        {
            dbiConnHelper.reopen();

            brokenConnection = false == dbiConnHelper.isValidAndInit();
        }

        if (true == brokenConnection)
        {
		    MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
		    return RET_DBA_ERR_CONNOTFOUND;
        }
	}

	if (SYS_GetEnv("AAAREF7386TEST2") != NULL)
	{
		DBA_DYNFLD_STP record = ALLOC_DYNST(Arg_Test);
		DBA_DYNFLD_STP ESEPtr  = ALLOC_DYNST(ExtStratElt);
		ID_T			instrId = 184691, currId=26;

		SET_SYSNAME(record, Arg_Test_Sysname, "fin_analysis");

		procedure =  DBA_GetStoredProcs(Notif, Test, DBA_ROLE_CALL_WITH_COLLECTION, Arg_Test, record, NullDynSt);

		/* Important to set this nature to sended ExtStratElt for allocate order */
		SET_ENUM(ESEPtr, ExtStratElt_NatEn, ExtStratEltNat_AllocOrder);

		SET_ID(ESEPtr, ExtStratElt_InstrId, instrId);
		SET_NUMBER(ESEPtr, ExtStratElt_OrderQty, 1200);
		SET_ID(ESEPtr, ExtStratElt_CrtQuoteCurrId, currId);
		SET_PRICE(ESEPtr, ExtStratElt_CrtQuote, 2000);
		SET_PRICE(ESEPtr, ExtStratElt_CrtPrice, 2000);

        DBA_Notif(Domain, DBA_ROLE_COLLECT, A_Domain, fDomainSt, *dbiConnHelper.getConnection(), DBA_SET_CONN | DBA_NO_CLOSE);

        DBA_Notif(EStratElt, DBA_ROLE_COLLECT, ExtStratElt, ESEPtr, *dbiConnHelper.getConnection(), DBA_SET_CONN | DBA_NO_CLOSE);


		SET_SYSNAME(record, Arg_Test_Sysname, "fin_analysis");

        if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), Arg_Test, record, procedure) != RET_SUCCEED)
		{
			MSG_RETURN(RET_DBA_ERR_SETPARAM);
		}
	}
	else   /* Dead code removed PMSTA-17133 - 051113 - PMO */
	{
		/* REF9764 - TEB - 040203 - Begin */
		/* Case of Search Matching Order */
		/* Collect unmatched excutions, then call SYB_RpcFinAnalysisWithCollection */
		if (IS_NULLFLD(fDomainSt, A_Domain_FctDictId) == FALSE)
		{
			fctEnum = GET_DICT(fDomainSt, A_Domain_FctDictId);  /*  FPL-PMSTA08801-100714 cast  */
			DBA_GetDictFctInfo(fctEnum, DictFctInfo_ParDictId, &fctEnum);
		}
		else
		{
			fctEnum = NullDictFct;
		}

		if ((fctEnum == DictFct_SearchMatchingOrder))
		{
			DBA_DYNFLD_STP record   = ALLOC_DYNST(Arg_Test);
			DBA_DYNFLD_STP *umexTab = NULL;
			int  umexNbr=0, umexCnt=0;
			char copyRecFlg;

			SET_SYSNAME(record, Arg_Test_Sysname, "fin_analysis");

			procedure =  DBA_GetStoredProcs(Notif, Test, DBA_ROLE_CALL_WITH_COLLECTION, Arg_Test, record, NullDynSt);

            DBA_Notif(Domain, DBA_ROLE_COLLECT, A_Domain, fDomainSt, *dbiConnHelper.getConnection(), DBA_SET_CONN | DBA_NO_CLOSE);

            DBA_HIER_HEAD_STP phierCollection = (DBA_HIER_HEAD_STP) ptrHierCollection;  	        /*  FIH-REF9764-040128  */

			/* Get the selected unmatched execution records */
			copyRecFlg = FALSE;
			if ((ret = DBA_ExtractHierEltRec(phierCollection,
												A_UnMatchedExecution,
												copyRecFlg,
												NULL,
												NULL,
												&umexNbr,
												&umexTab)) != RET_SUCCEED)
			{
				return(ret);
			}

			/* Send them to the server by RPC */
			for (umexCnt=0; umexCnt<umexNbr; umexCnt++)
			{
				DBA_Notif(UnMatchedExecution,
							DBA_ROLE_COLLECT,
							A_UnMatchedExecution,
							umexTab[umexCnt],
                            *dbiConnHelper.getConnection(),
							DBA_SET_CONN|DBA_NO_CLOSE);
			}

			SET_SYSNAME(record, Arg_Test_Sysname, "fin_analysis");

            if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), Arg_Test, record, procedure) != RET_SUCCEED)
			{
				MSG_RETURN(RET_DBA_ERR_SETPARAM);
			}
		}
		else /* REF9764 - TEB - 040203 - End */
		{
			/* Set domain parameters */
            if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), A_Domain, fDomainSt, procedure) != RET_SUCCEED)
			{
				MSG_RETURN(RET_DBA_ERR_SETPARAM);
			}
		}
	}

	/* Send the request to a financial server */
    if ((retCode = dbiConnHelper.getConnection()->sendRequest(&resultType)) != RET_SUCCEED) /* DLA - PMSTA-25721 - 161216 */
	{
		if (retCode == RET_DBA_ERR_CANNOTCONNECT)
		{
			/* REF3955 - SSO - 991222  DBA_CONN_PROBLEM mean RET_DBA_INFO_DISCONNECTED -> explicit message */
			SYSNAME_T    servername = "Unknown";
			/*  FPL-PMSTA08052-090318 don't display message "connection with server XXX lost    */
			if (SYS_GetEnv("AAACONNECTWARNMSG") != NULL)
			{
                if (dbiConnHelper.getConnection()->getSpecification().getServerName().empty() == false) /* REF3955 - SSO - 991222 */
				{
                    MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
                    MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
				}
				else
				{
					MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, (char*) &servername);
					MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, (char*) &servername);
				}
			}

			if (dbiConnHelper.isValidAndInit() == false)
			{
				/* DBA_SqlExec("waitfor delay \"0:00:03\"", UNUSED, UNUSED); */ /* PMSTA-20159 - TEB - 150624  */
				SYS_MilliSleep(3000); /* PMSTA-20159 - TEB - 150624  */

                if (!dbiConnHelper.isValidAndInit())
				{
					MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
					return(RET_DBA_ERR_CONNOTFOUND);
				}
			}

			/* REF3955 - SSO - 000111 added test */
            if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), A_Domain, fDomainSt, procedure) != RET_SUCCEED)
			{
                dbiConnHelper.setOnError(true);
				MSG_RETURN(RET_DBA_ERR_SETPARAM);
			}

            retCode = dbiConnHelper.getConnection()->sendRequest(&resultType);

			if (retCode != RET_SUCCEED)
			{
                dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
                dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

				/* REF3955 - SSO - 991222 */
                if (dbiConnHelper.getConnection()->isConnected() == false)
				{
                    if (dbiConnHelper.getConnection()->getSpecification().getServerName().empty() == false) /* REF3955 - SSO - 991222 */
					{
                        MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
                        MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
					}
					else
					{
						MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, (char*) &servername);
						MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, (char*) &servername);
					}
				}
                dbiConnHelper.setOnError(true);
				return(RET_DBA_ERR_DIALOG);
			}
		}
		else
		{
            dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
            dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
			MSG_DispMesg(RET_DBA_ERR_DBPROBLEM, NULL, NULL);
			return(RET_DBA_ERR_DBPROBLEM);
		}
	}

    int finalResult = RET_SUCCEED;

	if (resultType != DBI_ROW_RESULT)
	{
        dbiConnHelper.getConnection()->processAllResults(&status);
        dbiConnHelper.getConnection()->filterMsgInfos(&finalResult);

		if (finalResult == RET_SUCCEED)
			finalResult = RET_SRV_LIB_ERR_GENERAL;
	}

	if (finalResult != RET_SUCCEED)
	{
		/*  FPL-PMSTA09858-100525 don't dislpay message here, if we are in a thread of the gui  */
		if (DBA_IsGuiMultiThreading() == TRUE)
		{
			switch(finalResult)
			{
				case RET_SRV_LIB_ERR_COMMAND_ABORTED:
				case RET_SRV_LIB_ERR_PARAMNOTSUPPLIED:
				case RET_SRV_INFO_DUPLICATE_FCTRESID:
				case RET_FIN_ERR_CODE_USED:
				case RET_FIN_ERR_COMP_SYNTH_FAIL:
				case RET_FIN_ERR_NO_STRAT_LNK:
				case RET_FIN_ERR_MISS_SYNTH:
				case RET_FIN_ERR_ONLINE_REFUSED:
				case RET_FIN_ERR_MISS_PERFDATA:
				case RET_FIN_ERR_SECURITY_ISSUE: /* PMSTA11898-CHU-110524 */

				case RET_SRV_INFO_RUNNING:
				case RET_SRV_INFO_DELETE_SUCCEED:

				case RET_SRV_INFO_NO_POSITIONS:
				case RET_SRV_INFO_POS_LOADING_FAILED:

					return finalResult ;
					break ;

				case RET_SRV_INFO_CLOSING_SUCCEED:
				case RET_SRV_INFO_DONE:
					return(RET_SUCCEED);
					break ;
			}
		}
		else
		{
			switch(finalResult)
			{
				case RET_SRV_INFO_NO_POSITIONS:
					MSG_DispMesg(RET_SRV_INFO_NO_POSITIONS, NULL, NULL);
					return (RET_GEN_INFO_NODATA);

				case RET_SRV_INFO_POS_LOADING_FAILED:
					MSG_DispMesg(RET_SRV_INFO_POS_LOADING_FAILED, NULL, NULL,
                        NameType, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
					return (RET_GEN_INFO_NODATA);

				case RET_SRV_INFO_CLOSING_SUCCEED:
					return(RET_SUCCEED);

				case RET_SRV_INFO_RUNNING:
				case RET_SRV_INFO_DELETE_SUCCEED:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(RET_SUCCEED);

				case RET_SRV_LIB_ERR_COMMAND_ABORTED:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				case RET_SRV_LIB_ERR_PARAMNOTSUPPLIED:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				case RET_SRV_INFO_DUPLICATE_FCTRESID:
					MSG_DispMesg(finalResult, NULL, NULL,
								 CodeType, GET_CODE(fDomainSt, A_Domain_FctResultCd));
					return(finalResult);

				case RET_SRV_INFO_DONE:
					return(RET_SUCCEED);

				/* REF2394 - SSO - 980812 */
				case RET_FIN_ERR_CODE_USED:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* REF4489 - SSO - 000315 */
				case RET_FIN_ERR_COMP_SYNTH_FAIL:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* REF4564 - SSO - 990419 */
				case RET_FIN_ERR_NO_STRAT_LNK:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* REF4729 - SSO - 000802 */
				case RET_FIN_ERR_MISS_SYNTH:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* REF4729 - SSO - 000802 */
				case RET_FIN_ERR_ONLINE_REFUSED:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* REF9923 - CHU - 040225 */
				case RET_FIN_ERR_MISS_PERFDATA:
					MSG_DispMesg(finalResult, NULL, NULL);
					return(finalResult);

				/* PMSTA11898-CHU-110524 */
				case RET_FIN_ERR_SECURITY_ISSUE:
					{
						CODE_T         userCd;

						*userCd = END_OF_STRING;
						if ((ret = DBA_GetUserInfo(A_ApplUser_Cd, (PTR)&userCd)) == RET_SUCCEED)
						{
							MSG_DispMesg(finalResult, NULL, NULL,
										CodeType, userCd,
										CodeType, GET_CODE(fDomainSt, A_Domain_FctResultCd));
						}
					}
					return(finalResult);
			}
		}
		MSG_DispMesg(RET_DBA_ERR_DIALOG, UNUSED, UNUSED);
        dbiConnHelper.getConnection()->setValidConnection(false);

		return(RET_DBA_ERR_DIALOG);
	}

    dbiConnHelper.getConnection()->filterMsgInfos(&finalResult);

	/*  FPL-PMSTA07412-090330   */
	if (finalResult == RET_FIN_INFO_OBSOLETE_CNSTR)
	{
		MSG_DispMesg(RET_FIN_INFO_OBSOLETE_CNSTR, NULL, NULL);
		retCodeGui = RET_FIN_INFO_OBSOLETE_CNSTR ;
	}
	/* READ DATA */
    ret = DBA_ReadFinFctResults(*dbiConnHelper.getConnection(), dataStruct);

	/********************************************************************/
	/* Cas particulier d'OrderList en attendant que le code soit retourn� par le serveur */
	/* ROI - 000511 - REF2467 */
	if (IS_NULLFLD(fDomainSt, A_Domain_FctDictId) == FALSE)
	{
		fctEnum = GET_DICT(fDomainSt, A_Domain_FctDictId);  /* REF7264 - PMO */ /*  FPL-PMSTA08801-100714 cast  */
		DBA_GetDictFctInfo(fctEnum, DictFctInfo_ParDictId, &fctEnum);
	}
	else fctEnum = NullDictFct;
	if ((fctEnum == DictFct_OrderList) &&
		(dataStruct != NULL) &&
		(*dataStruct != NULL)
	   )
	{
		dataResStp = *dataStruct;

		/* Recherche du bloc d'extOp */
		i = 0;
		setStp = NULL;
		while ((i < dataResStp->dataSetNb) && (setStp == NULL))
		{
			if (dataResStp->dataSetStTab[i].entity == EOp)
				setStp = &(dataResStp->dataSetStTab[i]);
			else
				i++;
		}
		opRowCount = 0;
		GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);
		if ((setStp != NULL) && (setStp->rowNb >= opRowCount))
			ret = RET_FIN_ERR_MAX_ROW;
	}

	switch(ret)
	{
	case RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT:
	case RET_DBA_ERR_DIALOG:
	case RET_DBA_ERR_SYBBIND:
	case RET_MEM_ERR_ALLOC:
	case RET_FIN_ERR_MAX_ROW :                      /* MRA - 010308 - REF5737 */
    case RET_FIN_ERR_INCOMPLETE_RESULT:             /*  HFI-PMSTA-38708-200205  */
        if (dbiConnHelper.getConnection()->isConnected() == false)
		{
			SYSNAME_T    servername = "Unknown";
			/* MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO); */ /* REF3955 - SSO - 991222 */

            if (dbiConnHelper.getConnection()->getSpecification().getServerName().empty() == false) /* REF3955 - SSO - 991222 */
			{
                MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
                MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, dbiConnHelper.getConnection()->getSpecification().getServerName().c_str());
			}
			else
			{
				MSG_LogMesg(RET_DBA_ERR_CONNLOST, 0, FILEINFO, (char*) &servername);
				MSG_DispMesg(RET_DBA_ERR_CONNLOST, NULL, NULL, NameType, (char*) &servername);
			}
			return(RET_DBA_ERR_DISCONNECTED);
		}

        dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

		MSG_DispMesg(ret, NULL, NULL);

		if (ret == RET_FIN_ERR_MAX_ROW)            /* MRA - 010308 - REF5737 */
			return(RET_SUCCEED);
		else
			return(RET_DBA_ERR_DIALOG);

	case RET_GEN_INFO_NODATA :

        dbiConnHelper.getConnection()->processAllResults(&status);
	    MSG_DispMesg(RET_GEN_INFO_NODATA, NULL, NULL);

		return(RET_GEN_INFO_NODATA);
	}

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		EV_SetProcParametersFlg = FALSE;
	}

    /*  Additional initialisation of complete data                      */  /*  HFI-PMSTA-41134-200721  */
    if (((retCode == RET_SUCCEED) || (retCode == RET_FIN_INFO_OBSOLETE_CNSTR)) &&
        (dataStruct != nullptr))
    {
		dataResStp = *dataStruct;
        for (int iSet = 0; iSet < dataResStp->dataSetNb; iSet++)
        {
            /*  The complete data is returned by the server             */
            if (dataResStp->dataSetStTab[iSet].addedEntityFlg == TRUE)
            {
                /*  Init data according to meta dictionary structure    */
                DBA_DYNST_ENUM enDbaDynst = GET_EDITGUIST(dataResStp->dataSetStTab[iSet].entity);
                for (int sRow = 0; sRow < dataResStp->dataSetStTab[iSet].rowNb; sRow++)
                {
                    DBA_DYNFLD_STP  pdbadyn = &dataResStp->dataSetStTab[iSet].data[dataResStp->dataSetStTab[iSet].colNb * sRow];
                    DICT_DynStDatatypeSet(pdbadyn, enDbaDynst);
                }
                /*  Init data according to format information           */
                for (FIELD_IDX_T iCol = GET_FLD_NBR(enDbaDynst); iCol < dataResStp->dataSetStTab[iSet].colNb; iCol++)
                {
    				DBA_DYNFLD_STP  dataDef = &dataResStp->dataSetStTab[iSet].dataDef[GET_FLD_NBR(DataDef)*iCol];
                    unsigned char   dataType = static_cast<unsigned char>(GET_INT(dataDef, DataDef_Datatype));
                    for (int sRow = 0; sRow < dataResStp->dataSetStTab[iSet].rowNb; sRow++)
                    {
                        DBA_DYNFLD_STP  pdbadyn = &dataResStp->dataSetStTab[iSet].data[(dataResStp->dataSetStTab[iSet].colNb * sRow) + iCol];
                        pdbadyn->dynStEnum = enDbaDynst;
                        pdbadyn->dataType = dataType;
                        pdbadyn->index = static_cast<short>(iCol);
                    }
                }
            }
        }
    }

	return(retCodeGui); /*  FPL-PMSTA07412-090330 replace RET_SUCCEED. Now it's possible to have a result with specific code RET_FIN_INFO_OBSOLETE_CNSTR    */
}

/************************************************************************
*   Function             : DBA_CallRpcMergeSession
*
*   Description          : Call RPC Merge Session
*
*   Arguments            : sessionMgt  : pointer on a SessionMgt dynamic structure
*
*   Functions call       :
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if problem with input argument
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure found
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                          RET_DBA_ERR_SETPARAM     : if problem while setting param.
*                          RET_DBA_ERR_DBPROBLEM    : if conn./DB problem
*                          RET_DBA_ERR_DISCONNECTED : if connection is dead
*                 RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT : if no formats for fin. function
*                          RET_MEM_ERR_ALLOC        : if memory allocation failed
*                          RET_GEN_INFO_NODATA      : if no rows returned by server
*                          RET_DBA_ERR_DIALOG       : if dialog problem with server
*
*   Creation date        : HFI-PMSTA-18895-141113
*
*************************************************************************/
RET_CODE DBA_CallRpcMergeSession (DBA_DYNFLD_STP sessionMgt)
{
    DBI_INT             resultType, status = 0;
    DBA_PROC_STP        procedure=NULL;
    RET_CODE            retCodeGui  = RET_SUCCEED, retCode = RET_SUCCEED, finalResult;
    OBJECT_ENUM         obj;
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, FinServer);

    /*  Security test                                                   */
    if (sessionMgt == NULL)
        MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);

    /*  init variable                                                   */
    obj = FctResult;

    /*  Get procedure                                                   */
	procedure =  DBA_GetStoredProcs(Select, FctResult, DBA_ROLE_MERGE_ORDER_SESSION, SessionMgt, sessionMgt, NullDynSt);

    if (procedure == NULL)
    {
        char    objString[40];
        const char    *sqlName = DBA_GetDictEntitySqlName(obj);

        if (sqlName != NULL)
        {
            strcpy(objString, sqlName);
        }
        else
        {
            sprintf(objString, "unknown(" szFormatObj ")",obj);
        }


        MSG_LogMesg(RET_DBA_ERR_PROCNOTFOUND, 3, FILEINFO, "MergeSession", objString, "function_result", "none");
        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    finalResult = RET_SUCCEED;

    /* Get a free connection */
    if (!dbiConnHelper.isValidAndInit())
    {
        MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    /* Set domain parameters */
    if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), SessionMgt, sessionMgt, procedure) != RET_SUCCEED)
    {
	    MSG_RETURN(RET_DBA_ERR_SETPARAM);
    }

    /* Send the request to a financial server */
    if ((retCode = dbiConnHelper.getConnection()->sendRequest(&resultType)) != RET_SUCCEED)
    {
        dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        dbiConnHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        MSG_DispMesg(RET_DBA_ERR_DBPROBLEM, NULL, NULL);
        return(retCode);
    }

    if (resultType != DBI_ROW_RESULT)
    {
        dbiConnHelper.getConnection()->processAllResults(&status);
        dbiConnHelper.getConnection()->filterMsgInfos(&finalResult);
        if (finalResult == RET_SUCCEED)
            finalResult = RET_SRV_LIB_ERR_GENERAL;
    }

    dbiConnHelper.getConnection()->processAllResults(&status);
    dbiConnHelper.getConnection()->filterMsgInfos(&finalResult);

    if (finalResult != RET_SUCCEED)
    {
        return(finalResult);
    }

    if (EV_ExtractFile && EV_SetProcParametersFlg)
    {
        DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        EV_SetProcParametersFlg = FALSE;
    }

    return(retCodeGui);
}


/************************************************************************
*   Function             : DBA_FreeFinFctResults()
*
*   Description          : Free all allocated dynamic structures used to
*                          retrieve data (after a call to DBA_GetFinFctResults)
*                          returned by Open Server.
*
*                          Warning : Free all allocated string for CharPtrCType
*                                    fields, but doesn't free CharPtrCType fields
*                                    which are permitted values (corresponding to
*                                    enum fields values) string pointing on the
*                                    dict_perm_val table in the Meta-Dictionary
*                                    loaded in memory
*
*
*   Arguments            : dataRes : pointer on a DBA_DATARESULT_ST
*                           flagDeleteDataOnly  if TRUE delete only data
*
*   Functions call       :
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if problem with input argument
*
*   Creation date        : Oct.  94 - PEC
*   Last Modif. Date     : 29.08.95 - PEC - Added RET_CODE
*                          04.02.00 - GRD - REF4204.
*************************************************************************/
RET_CODE DBA_FreeFinFctResults(DBA_DATARESULT_STP *dataResPtr, FLAG_T flagDeleteDataOnly)
{
	DBA_DYNFLD_STP     data=NULL, dataDef=NULL;
	DBA_DATARESULT_STP dataRes=NULL;
	int                i = 0, j = 0, setNb = 0;

	if (*dataResPtr == NULL)
		return(RET_DBA_ERR_ARGNOMATCH);
	else
		dataRes = *dataResPtr;

	for (setNb=0 ; setNb < dataRes->dataSetNb ; setNb++)
	{
		for (i=0 ; i<dataRes->dataSetStTab[setNb].rowNb &&
			 dataRes->dataSetStTab[setNb].tabPtrFlag == FALSE ; i++)
		{
			data =
			&dataRes->dataSetStTab[setNb].data[dataRes->dataSetStTab[setNb].colNb * i];

			for (j=0 ; j <dataRes->dataSetStTab[setNb].colNb ; j++)
			{
				dataDef =
				&dataRes->dataSetStTab[setNb].dataDef[GET_FLD_NBR(DataDef)*j];

				if ((GET_CTYPE(GET_INT(dataDef, DataDef_Datatype)) == CharPtrCType) ||
					(GET_CTYPE(GET_INT(dataDef, DataDef_Datatype)) == TextPtrCType))	/* REF4204 */
				{
					FREE_STRFLD(data[j]);
				}
			}
		}

		if (flagDeleteDataOnly == FALSE)    /*  FIH-REF7768-020926  */
			FREE((*dataResPtr)->dataSetStTab[setNb].dataDef);
		FREE((*dataResPtr)->dataSetStTab[setNb].data);
	}

	if (flagDeleteDataOnly == FALSE)        /*  FIH-REF7768-020926  */
	{
		FREE((*dataResPtr)->dataSetStTab);
		/*  FIH-REF7587-020524  */
		if ((*dataResPtr)->fmtEltDef != NULL)
		{
			for (i = 0; i < (*dataResPtr)->fmtEltNb; i++)
				DBA_FreeDynSt(&(*dataResPtr)->fmtEltDef[i * GET_FLD_NBR(FmtEltDef)],FmtEltDef);
			FREE((*dataResPtr)->fmtEltDef);
		}
		FREE(*dataResPtr);
	}
	return(RET_SUCCEED);
}


/******************************************************************************************
*   Function             : DBA_ReadFinFctResults()
*
*   Description          : Retrieve format element information, data descrip-
*                          tion and data rows returned by Open Server after a
*                          call to Financial Function (Valorisation, ...).
*
*   Description of retrieved data :
*
*''First block'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
*
*                  int             int              int
*           --------------------------------------------------
*           | Nb of Fmt Elt | Nb of Data Set | Fct Result Id |
*           --------------------------------------------------
*
*''Second block : format elements''''''''''''''''''''''''''''''''''''''''''''''
*
*           --------------------------------------------------------
*    x      | Format Id | Fmt Elt Rank | Data Set Idx | Column Idx |   --> dyn. struct FmtEltDef
*  rows     --------------------------------------------------------
*           |    ...    |      ...     |     ...      |     ...    |
*           --------------------------------------------------------
*
*''First block of first data set'''''''''''''''''''''''''''''''''''''''''''''''
*
*           -----------------------
*           | Column Nb | Rows Nb |
*           -----------------------
*
*''Second block of first data set : columns description''''''''''''''''''''''''
*
*           --------------------------------------------------------------------------------
*           | Column Nb | Data type | Ref. Key Idx | Ref. Key Nb | Ref. Key Entity dict_id | --> dyn. struct DataDef
*           --------------------------------------------------------------------------------
*           |    ...    |     ...   |      ...     |      ...    |           ...           |
*           --------------------------------------------------------------------------------
*
*''Third block of first data set : data''''''''''''''''''''''''''''''''''''''''
*
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*
*''First block of second data set if any'''''''''''''''''''''''''''''''''''''''
*
*   cf "First block of first data set"
*
*   ....
*   ....
*   ....
*   ....
*   ....
*
****************************************************************************************************************
*
*   Arguments            : connectNo  : a connection number in the connection list
*                          dataStruct : pointer addres on a DBA_DATARESULT_ST
*                                       structure (NOT ALLOCATED).
*
*
*   Return               : RET_SUCCEED                       : if ok
*                          RET_GEN_INFO_NODATA               : if no available data
*                          RET_DBA_ERR_DIALOG                : if disconnection or problem while
*                                                              reading data set
*                          RET_MEM_ERR_ALLOC                 : if memory allocation failed
*                          RET_DBA_ERR_SYBBIND               : if problem while binding data
*                          RET_ERR_DBA_NO_FORMAT_FOR_FIN_FCT : if no formats found for financial function
*
*   Creation Date        : Oct.  94 - PEC
*   Last Modification    : 29.05.96 - PEC - Ref.: DVP056+.
*                          16.10.96 - PEC - Ref.: DVP172 - Portage NT (cf #ifdef NT).
*                        : ROI - 970312 - DVP375
*                          27.05.98 - GRD - Ref.: REF2165. Allow 64Ko size scripts.
*                          04.02.00 - GRD - Ref.: REF4204.
*                          15.01.01 - GRD - Ref.: REF4336.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-15145 - 171012 - PMO : NQA : display of technical messages in GUI error log when running Order List
*                          PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*******************************************************************************************/
RET_CODE DBA_ReadFinFctResults(DbiConnection& dbiConn, DBA_DATARESULT_STP *dataStruct)
{
    return DBI_ReadFinFctResults(dbiConn, dataStruct);
}

/************************************************************************
*   Function               : DBA_GetRecordIdByCd()
*
*   Description            :
*
*
*   Arguments              : object       : the request corresponding object
*                            inputCd      : the record code
*                            recordId     : the record Id
*                            allocConn    : the connection Id
*                            options      : the connection options
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 11.09.95 - PEC
*   Last modification date :
*************************************************************************/
RET_CODE DBA_GetRecordIdByCd(OBJECT_ENUM    object,
							 CODE_T         inputCd,
							 ID_T           *recordId,
							 DBA_DYNST_ENUM outputSt,
                             int            *allocConn,
                             int            options)
{
	DBA_DYNFLD_STP inputData=NULL;
	DBA_DYNFLD_STP outputData=NULL;
	RET_CODE       ret;

	if (inputCd == NULL || recordId == NULL)
		return(RET_DBA_ERR_ARGNOMATCH);

	if (outputSt == NullDynSt)
		outputSt = GET_ADMINGUIST(object);

	if ((inputData = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)
		return(RET_MEM_ERR_ALLOC);

	if ((outputData = ALLOC_DYNST(outputSt)) == NULL)
	{
		FREE_DYNST(inputData, GET_ADMINGUIST(object));
		return(RET_MEM_ERR_ALLOC);
	}

	SET_CODE(inputData, 1, inputCd);

	ret = DBA_Get2(object, UNUSED, GET_ADMINGUIST(object), inputData, outputSt, &outputData, options, allocConn, UNUSED);

	switch(ret)
	{
	case RET_SUCCEED:
		ret = RET_SUCCEED;
		*recordId = GET_ID(outputData, 0);
		break;

	case RET_DBA_INFO_NODATA:
	/* REF9108 - YST - 030703 */
	case RET_DBA_INFO_NODATAWITHOPTI:
		ret = RET_DBA_ERR_NODATA;
		break;

	default:
		ret = RET_GEN_ERR_NOACTION;
		break;
	}

	FREE_DYNST(inputData, GET_ADMINGUIST(object));
	FREE_DYNST(outputData, outputSt);

	return(ret);
}

/************************************************************************
*   Function               : DBA_UpdateCdByIdInDynSt()
*
*   Description            :
*
*
*   Arguments              :
*
*   Return                 : RET_SUCCEED              : if ok
*
*
*   Creation date          : REF11349 - RAK - 050804
*
*************************************************************************/
RET_CODE	DBA_UpdateCdByIdInDynSt(DBA_DYNFLD_STP recPtr,
									OBJECT_ENUM	   objEn,
									int            idFld,
									int            cdFld,
									PTR	           hierHeadPtr)
{
	RET_CODE		ret=RET_SUCCEED;
	CODE_T			codeStr;

	ret = DBA_GetRecordCdById(objEn,
							  GET_ID(recPtr, idFld),
							  codeStr, hierHeadPtr);

	SET_CODE(recPtr, cdFld, codeStr);

	return(ret);
}

/************************************************************************
*   Function               : DBA_GetRecordCdById()
*
*   Description            :
*
*
*   Arguments              : object       : the request corresponding object
*                            inputId      : the record Id
*                            recordCd     : the record Cd
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 14.09.95 - PEC
*   Last modification date : 27.07.99 - RAK - hierHead and DBA_GetHierOptiPtr()
*                            REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_GetRecordCdById(OBJECT_ENUM    object,
							 ID_T           inputId,
							 CODE_T         recordCd,
							 PTR	        hierHeadPtr) /* REF3678 */
{
	DBA_DYNFLD_STP	    inputData=NULL;
	DBA_DYNFLD_STP	    outputData=NULL;
	DBA_HIER_HEAD_STP   hierHead=NULL;          /* REF7264 - PMO */
	DBA_DYNST_ENUM	    recDynStType;
	RET_CODE            ret;

	/* REF3678 - Use received hierarchy or "optimised" hierarchy */
	if (hierHeadPtr == NULL)
	{
		hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
	}
	else
		hierHead = (DBA_HIER_HEAD_STP) hierHeadPtr; /* REF7264 - PMO */

	if (hierHead != NULL)
	{
		/* Verify if record dynst type exist in hierarchy and in that case search record by id */
		recDynStType = GET_EDITGUIST(object);

		if (DBA_GetRecPtrFromHierById(hierHead, inputId,
							  recDynStType, &outputData) == RET_SUCCEED &&
		outputData != NULL)
		{
		strcpy((char *)recordCd, GET_CODE(outputData, 1));
		return(RET_SUCCEED);
		}
	}

	if (inputId == 0 || recordCd == NULL)
		return(RET_DBA_ERR_ARGNOMATCH);

	if ((inputData = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)
		return(RET_MEM_ERR_ALLOC);

	if ((outputData = ALLOC_DYNST(GET_EDITGUIST(object))) == NULL)
		return(RET_MEM_ERR_ALLOC);

	SET_ID(inputData, 0, inputId);

	ret = DBA_Get2(object, UNUSED, GET_ADMINGUIST(object), inputData,
				  GET_EDITGUIST(object), &outputData, UNUSED, UNUSED, UNUSED);

	switch(ret)
	{
	case RET_SUCCEED:
		ret = RET_SUCCEED;
		strcpy((char *)recordCd, GET_CODE(outputData, 1));
		break;

	case RET_DBA_INFO_NODATA:
	/* REF9108 - YST - 030703 */
	case RET_DBA_INFO_NODATAWITHOPTI:
		ret = RET_DBA_ERR_NODATA;
		break;

	default:
		ret = RET_GEN_ERR_NOACTION;
		break;
	}

	FREE_DYNST(inputData, GET_ADMINGUIST(object));
	FREE_DYNST(outputData, GET_EDITGUIST(object));

	return(ret);
}

/************************************************************************
*   Function             : DBA_BeginTransaction()
*
*   Description          : Send a "begin tran" command to the server and retrieve
*                          returned status
*
*   Arguments            : connectNo    : a connection number
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*   Creation date        : 28.12.95 - PEC
*   Last modification    : 17.10.96 - PEC - Ref.: BUG186
*                          REF5010 - SSO - 000828
*************************************************************************/
RET_CODE DBA_BeginTransaction(int connectNo)
{
	int ret = RET_SUCCEED;
	DbiConnection* dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);
	if (dbiConn == nullptr)
    {
		ret = RET_DBA_ERR_CONNOTFOUND;
	}
	else
    {
		ret = dbiConn->beginTransaction();
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_CreateWorkOnCloseConnection()
**
**  Description :   Allocate memory to store all informations to launch a fusion
**
**  Arguments   :   None
**
**  Return      :   Memory allocated
**                  NULL if not enough memory
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not alway in the same transaction
**
**  Last modif. :
**
*************************************************************************/
DBA_WORK_ON_CLOSE_CONNECTION_STP DBA_CreateWorkOnCloseConnection(void)
{
	return (DBA_WORK_ON_CLOSE_CONNECTION_STP) CALLOC(1, sizeof(DBA_WORK_ON_CLOSE_CONNECTION_ST));
}



/************************************************************************
**
**  Function    :   DBA_FreeWorkOnCloseConnection()
**
**  Description :   Allocate memory to store all informations to launch a fusion
**
**  Arguments   :   None
**
**  Return      :   Memory allocated
**                  NULL if not enough memory
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not alway in the same transaction
**
**  Last modif. :
**
*************************************************************************/
void DBA_FreeWorkOnCloseConnection(DBA_WORK_ON_CLOSE_CONNECTION_STP pWorkOnCloseConnection)
{
	FREE(pWorkOnCloseConnection);
}


/************************************************************************
**
**  Function    :   DBA_AddWorkOnCloseConnection()
**
**  Description :   Add a work to be done after the close of the transaction
**
**  Arguments   :   None
**
**  Return      :   TRUE  if ok
**                  FALSE if not enough memory
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not alway in the same transaction
**
**  Last modif. :
**
*************************************************************************/
FLAG_T DBA_AddWorkOnCloseConnection(DbiConnection& dbiConn, DBA_WORK_ON_CLOSE_CONNECTION_STP pWorkOnCloseConnection)
{
    dbiConn.m_workOnCloseConnectionVector.push_back(*pWorkOnCloseConnection);
	return TRUE;
}



/************************************************************************
*   Function             : DBA_EndTransaction()
*
*   Description          : Send a "commit tran" or "rollback tran" command to
*                          the server according to the given status.
*
*   WARNING              : if status is different from TRUE or FALSE or if given
*                          connection number is invalid, no command
*                          is sent to the server to close the transaction and the
*                          tables concerned by the transaction stays locked.
*
*   Arguments            : connectNo    : a connection number
*                          status       : TRUE or FALSE
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input argument problem
*
*   Creation date        : 28.12.95 - PEC
*   Last modification    : 17.10.96 - PEC - Ref.: BUG186
*                          EF5010 - SSO - 000828
*                          REF9538 - 031507 - PMO : Update of a record and udfields
*                                                   is not alway in the same transaction
*************************************************************************/
RET_CODE DBA_EndTransaction(int connectNo, const FLAG_T status) {
	int ret;
	DbiConnection *dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);
	if (dbiConn == nullptr) {
		return RET_DBA_ERR_CONNOTFOUND;
	}
	else {
		ret = dbiConn->endTransaction(status);
	}
	return ret;
}

/************************************************************************
*   Function             : DBA_GetNewDocIndex()
*
*   Description          : Get a new document index according to system parameter
*                          the server according to the given status.
*
*   Arguments            : entDictId	: entity
*                          entityId     : entitys id
*                          refDate      : reference date
*                          nature       : 1 (for field OpCode) or 2 (field AcctCode)
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_MEM_ERR_ALLOC        : if memory allocation failed
*                          RET_GEN_INFO_NOACTION    : if nothing to do
*                          RET_GEN_INFO_NODATA      : if no data founded
*
*   Creation date        : 08.01.96 - PEC
*   Last modification    : REF4229 - SSO - 000105 added connectNo
*                          REF10603 - TEB - 041129 : Add entity
*						   PMSTA-28686 - Silpakal - 190227 - removed the system Parameters for indexing,
*															 Added new entity doc_index_param to manage
*
*************************************************************************/
RET_CODE DBA_GetNewDocIndex(DICT_T entDictId, ID_T entityId,  DATETIME_T refDate, int nature, DBA_DYNFLD_STP docIndexSt)
{
	DBA_DYNFLD_STP  getArg=NULL;

	if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
		return (RET_MEM_ERR_ALLOC);

	SET_ID(getArg,       Get_Arg_EntDictId,	entDictId);		/* REF10603 - TEB - 041129 */
	SET_ID(getArg,       Get_Arg_Id,        entityId);		/* REF10603 - TEB - 041129 */
	SET_DATETIME(getArg, Get_Arg_DateTime,  refDate);
	SET_ENUM(getArg,     Get_Arg_NatEn,     (ENUM_T)nature);

    /* PMSTA-49291 - DDV - 220914 - Use local connection with transaction to avoid duplicate */ 
    DbiConnection			*localDbiConn;

    if ((localDbiConn = DBA_GetDbiConnection(SqlServer)) != nullptr)
    {
        localDbiConn->beginTransaction();
    }

	if (DBA_Get2(DocIndex, UNUSED, Get_Arg, getArg, A_DocIndex, &docIndexSt, DBA_SET_CONN | DBA_NO_CLOSE, *localDbiConn, UNUSED) != RET_SUCCEED)
	{
		FREE_DYNST(getArg, Get_Arg);
		return(RET_GEN_INFO_NODATA);
	}

    if (localDbiConn != nullptr)
    {
        localDbiConn->endTransaction(TRUE);
        DBA_EndConnection(&localDbiConn);
    }
    
    FREE_DYNST(getArg, Get_Arg);

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetNewDocIndexCodeFlag()
*
*   Description          : Get generation flag value for nature
*
*   Arguments            : nature       : 1 (for field OpCode) or 2 (field AcctCode)
*
*   Return               : RET_SUCCEED              : if no problem was detected
*						   RET_GEN_INFO_NODATA      : if no data founded
*
*
*   Creation date        : 27.02.19  - Silpakal - PMSTA-28686
*
*************************************************************************/
RET_CODE DBA_GetNewDocIndexCodeFlag(ENUM_T		 nature,
									FLAG_T		&genFlg)
{
	DBA_DYNFLD_STP	docIndexParamSt = NULL;
	int ret = RET_SUCCEED;
	genFlg = TRUE;

	MemoryPool mp;
	docIndexParamSt = mp.allocDynst(FILEINFO, A_DocIndexParam);

	SET_ENUM(docIndexParamSt, A_DocIndexParam_NatEn, nature);

	ret = DBA_Get2(DocIndexParam, UNUSED, A_DocIndexParam, docIndexParamSt,
		A_DocIndexParam, &docIndexParamSt, UNUSED, UNUSED, UNUSED);

	if (ret != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(DocIndexParam));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_UNAME(docIndexParamSt, A_DocIndexParam_Name));
		return(RET_DBA_ERR_NODATA);
	}

	genFlg = GET_FLAG(docIndexParamSt, A_DocIndexParam_GenerationFlg);

	return ret;
}

/************************************************************************
*   Function             : DBA_GetApplMsgText()
*
*   Description          : Get a appl_msg_text record corresponding to a GUI code in
*                          a given language and a given nature (System, Report, User, ...)
*
*   Arguments            : guiCode       : a alphanumeric GUI code
*                          langDictId    : a language dict_id
*                          msgNat        : the nature of the message
*                          applMsgTextSt : the output structure
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_MEM_ERR_ALLOC        : if memory allocation failed
*                          RET_GEN_INFO_NODATA      : if no data founded
*
*   Creation date        : 22.04.96 - PEC - Ref.: DVP031
*   Last modification    : 27.06.96 - PEC - New handling of RET_CODE
*************************************************************************/
RET_CODE DBA_GetApplMsgText(const CODE_T   guiCode,
							DICT_T         langDictId,
							APPLMSG_ENUM   msgNat,
							DBA_DYNFLD_STP applMsgTextSt)
{
	DBA_DYNFLD_STP applMsg=NULL;
	RET_CODE       retCode;

	/* Try to get the message text from the database */
	if ((applMsg = ALLOC_DYNST(ApplMsg_Arg)) == NULL)
		return(RET_MEM_ERR_ALLOC);

	SET_CODE(applMsg, ApplMsg_Arg_Cd,         guiCode);
	SET_ENUM(applMsg, ApplMsg_Arg_NatEn,      (ENUM_T)msgNat);
	SET_DICT(applMsg, ApplMsg_Arg_LangDictId, langDictId);

	retCode = DBA_Get2(ApplMsgTxt, UNUSED, ApplMsg_Arg, applMsg, A_ApplMsgTxt, &applMsgTextSt, UNUSED, UNUSED, UNUSED);

	switch (retCode)
	{
	case RET_SUCCEED:
		break;

	case RET_DBA_ERR_PROCNOTFOUND:
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "A problem occurred with a stored procedure");
		break;

	case RET_DBA_INFO_NODATA:
	/* REF9108 - YST - 030703 */
	case RET_DBA_INFO_NODATAWITHOPTI:
		{
		char *buffer;
		char *buffNat;					    /* REF2697 - SSO - 000510 */
		DBA_DYNFLD_STP aDictLang=NULL, sDictLang = NULL;  /* REF2697 - SSO - 000510 */
		RET_CODE       ret;					    /* REF2697 - SSO - 000510 */

		/* REF5138 - DDV - Larger buffer and add CALLOC to avoid stack growth */
		if ((buffer = (char *) CALLOC(384, sizeof(char))) == NULL)  /* REF7264 - PMO */
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* REF5138 - DDV - Larger buffer and add CALLOC to avoid stack growth */
		if ((buffNat = (char *) CALLOC(64, sizeof(char))) == NULL)  /* REF7264 - PMO */
		{
			FREE(buffer);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* REF2697 - SSO - 000510 BEGIN  (rewrote with more detailled info) */
		if ((sDictLang = ALLOC_DYNST(S_DictLang)) == NULL)
		{
			FREE(buffer);
			FREE(buffNat);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((aDictLang = ALLOC_DYNST(A_DictLang)) == NULL)
		{
			FREE(buffer);
			FREE(buffNat);
			FREE_DYNST(sDictLang, S_DictLang);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* REF5138 - DDV - 000822 - Display language from input parameter, not user language */
		/* GEN_GetUserInfo(UserLanguage, &langDictId); */
		SET_DICT(sDictLang, S_DictLang_Id, langDictId);

		if ((ret = DBA_Get2(DictLang, UNUSED, S_DictLang, sDictLang,
					A_DictLang, &aDictLang, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
		{
			SET_CODE(aDictLang, A_DictLang_Cd,"Unknown");
		}

		switch (msgNat)
		{
			case ApplMsgNat_None:		strcpy(buffNat,"None");break;
			case ApplMsgNat_System:		strcpy(buffNat,"System Message");break;
			case ApplMsgNat_UserDef:		strcpy(buffNat,"User Message");break;
			case ApplMsgNat_Report:		strcpy(buffNat,"System Report Label");break;
			case ApplMsgNat_UserReport:		strcpy(buffNat,"User Report Label");break;
			case ApplMsgNat_MultiLingualLabel:	strcpy(buffNat,"MultiLingual Label");break;
			default:				strcpy(buffNat,"Unkown");break;
		}

        if (EV_AAAInstallLevel < 2) /* PMSTA-nuodb - LJE - 190724 - Remove messages during installation */
        {
            sprintf(buffer, "Message %s in appropriate language (%s) or appropriate nature (%s)" /* REF2697 - SSO - 000510 */
                    " not found in database", guiCode, GET_CODE(aDictLang, A_DictLang_Cd), buffNat);
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
        }

        FREE_DYNST(sDictLang, S_DictLang);
        FREE_DYNST(aDictLang, A_DictLang);
		FREE(buffer);
		FREE(buffNat);
		break;
		}
	default:
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "A problem occurred while retrieving message text");
		break;
	}

	FREE_DYNST(applMsg, ApplMsg_Arg);

	return(retCode);
}

/************************************************************************
*   Function               : DBA_GetRecordByCd()
*
*   Description            :
*
*
*   Arguments              : object       : the request corresponding object
*                            inputCd      : the record code
*                            recordId     : the record Id
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 11.09.95 - PEC
*   Last modification date :
*************************************************************************/
RET_CODE DBA_GetRecordByCd(OBJECT_ENUM          object,
						   CODE_T               inputCd,
						   DBA_DYNST_ENUM       outputSt,
						   DBA_DYNFLD_STP      *outDynStp,
						   MemoryPool           &mp,
                           DbiConnectionHelper *connHelper)
{
    if (inputCd == nullptr)
    {
        return(RET_DBA_ERR_ARGNOMATCH);
    }

    if (outputSt == NullDynSt)
    {
        outputSt = GET_ADMINGUIST(object);
    }

	auto dictEntityStp = DBA_GetDictEntitySt(object);

	if (dictEntityStp == nullptr ||
		dictEntityStp->bkAttr == nullptr ||
		IS_STRING_TYPE(dictEntityStp->bkAttr[0]->dataTpProgN) == FALSE)
	{
		return(RET_DBA_ERR_ARGNOMATCH);
	}

	auto           inputData  = mp.allocDynst(FILEINFO, GET_ADMINGUIST(object));
	auto           outputData = mp.allocDynst(FILEINFO, outputSt);
	RET_CODE       ret        = RET_DBA_ERR_CONNOTFOUND;

    SET_CODE(inputData, dictEntityStp->bkAttr[0]->shortIdx, inputCd);

    if (connHelper == nullptr)
    {
        ret = DBA_Get2(object, UNUSED, GET_ADMINGUIST(object), inputData, outputSt, &outputData, UNUSED, UNUSED, UNUSED);
    }
    else if (connHelper->isValidAndInit())
    {
		auto ddlGenDbaAccessPtr = connHelper->getConnection()->getDdlGenDbaAccessPtr();
		if (ddlGenDbaAccessPtr != nullptr)
		{
			ret = ddlGenDbaAccessPtr->dbaGet(object, UNUSED, inputData, outputData);
		}
		else
		{
			ret = connHelper->dbaGet(object, UNUSED, inputData, &outputData);
		}
    }
    switch (ret)
    {
        case RET_SUCCEED:
            ret = RET_SUCCEED;
            break;

        case RET_DBA_INFO_NODATA:
            /* REF9108 - YST - 030703 */
        case RET_DBA_INFO_NODATAWITHOPTI:
            ret = RET_DBA_ERR_NODATA;
            break;

        default:
            ret = RET_GEN_ERR_NOACTION;
            break;
    }

    if ((outDynStp != nullptr) && (ret == RET_SUCCEED)) /* PMSTA-32138 CMILOS 030818 */
    {
        *outDynStp = outputData;
    }

	mp.freeDynStp(inputData);

    return(ret);
}

/************************************************************************
*   Function               : DBA_GetRecordById()
*
*   Description            :
*
*
*   Arguments              : object       : the request corresponding object
*                            inputCd      : the record code
*                            recordId     : the record Id
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : PMSTA09740 - DDV - 100526
*   Last modification date :
*************************************************************************/
RET_CODE DBA_GetRecordById(OBJECT_ENUM          object,
						   ID_T                 inputId,
						   DBA_DYNST_ENUM       outputSt,
						   DBA_DYNFLD_STP       *outDynStp,
						   MemoryPool           &mp,
                           DbiConnectionHelper  *connHelper)
{
	RET_CODE       ret = RET_SUCCEED;

	if (inputId <= 0)
		return(RET_DBA_ERR_ARGNOMATCH);

	if (outputSt == NullDynSt)
		outputSt = GET_ADMINGUIST(object);

	auto           inputData = mp.allocDynst(FILEINFO, GET_ADMINGUIST(object));
	auto           outputData = mp.allocDynst(FILEINFO, outputSt);

	SET_ID(inputData, 0, inputId);

    if (connHelper == nullptr)
    {
        ret = DBA_Get2(object, UNUSED, GET_ADMINGUIST(object), inputData, outputSt, &outputData, UNUSED, UNUSED, UNUSED);
    }
    else
    {
		auto ddlGenDbaAccessPtr = connHelper->getConnection()->getDdlGenDbaAccessPtr();
		if (ddlGenDbaAccessPtr != nullptr)
		{
			ret = ddlGenDbaAccessPtr->dbaGet(object, UNUSED, inputData, outputData);
		}
		else
		{
			ret = connHelper->dbaGet(object, UNUSED, inputData, &outputData);
		}
    }

	switch(ret)
	{
	case RET_SUCCEED:
		ret = RET_SUCCEED;
		break;

	case RET_DBA_INFO_NODATA:
	/* REF9108 - YST - 030703 */
	case RET_DBA_INFO_NODATAWITHOPTI:
		ret = RET_DBA_ERR_NODATA;
		break;

	default:
		ret = RET_GEN_ERR_NOACTION;
		break;
	}

	if ((outDynStp != UNUSED) && (ret == RET_SUCCEED)) /* PMSTA-32138 CMILOS 030818 */
	{
		*outDynStp = outputData;
	}

	mp.freeDynStp(inputData);

	return(ret);
}

/************************************************************************
*   Function               : DBA_GetScriptLibDefByCodeSqlName()
*
*   Description            : Return script library definition by scipt
*                            library code and sqlname_c
*
*
*   Arguments              :
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : REF11296 - LJE - 060620
*   Last modification date :
*************************************************************************/
RET_CODE DBA_GetScriptLibDefByCodeSqlName(OBJECT_ENUM		   ,
										  DBA_DYNFLD_STP	   sScriptLibSt,
										  DBA_DYNFLD_STP	  *aScriptDefStp,
										  DbiConnectionHelper& dbiConnHelper)
{
	DICT_ATTRIB_STP  attribSt;

	if (DBA_SearchAttribSqlName(ScriptLibrary, "script_definition", &attribSt) != RET_SUCCEED ||
		dbiConnHelper.dbaGet(ScriptLibrary,	UNUSED, sScriptLibSt, &sScriptLibSt) != RET_SUCCEED )
	{
		return RET_DBA_ERR_ARGNOMATCH;
	}

	SET_DICT((*aScriptDefStp), A_ScriptDef_AttrDictId, attribSt->attrDictId);
	SET_ID((*aScriptDefStp), A_ScriptDef_ObjId, GET_ID(sScriptLibSt, S_ScriptLibrary_Id));
	SET_ENUM((*aScriptDefStp),A_ScriptDef_NatEn, 0);

	if (dbiConnHelper.dbaGet(ScriptDef,	UNUSED, (*aScriptDefStp), aScriptDefStp) != RET_SUCCEED )
	{
		SET_NULL_STRING((*aScriptDefStp), A_ScriptDef_Def);
	}

	return (RET_SUCCEED);
}

/************************************************************************
*   Function               : DBA_SelectSumFmtElt()
*
*   Description            :
*
*
*   Arguments              :
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          :
*   Last modification date :
*************************************************************************/
RET_CODE DBA_SelectSumFmtElt(OBJECT_ENUM, 
                             DBA_DYNFLD_STP		  inputData,
							 DBA_DYNFLD_STP		**outputData,
							 int			     *rowsNbr,
							 DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP  *sumFmtEltTab=NULL;
	DBA_DYNFLD_STP  *dataTab[2]={NULL, NULL}; /* REF4026 - SSO - 991008 */
	int             rowTab[2] = {0,0};   /* REF3947 - SSO - 990902 */
	int		lastIdx, i, j, k, fmtEltNb, pos;
	char            *scptBuf;
	ID_T		fmtEltId;
	const DBA_DYNST_ENUM *outputStLst[] = { &Sum_FmtElt, &A_ScriptDef };
	FLAG_T               filterOk;        /* REF9337 - LJE - 031002 */
	SYSNAME_T        sqlname;

	/************** inputData *******************
	Get_Arg_Id                @format_profile_id
	Get_Arg_FctDictId         @function_dict_id
	Get_Arg_AttribDictId      @attribute_dict_id
	*********************************************/

	scptBuf = (char *)CALLOC(GET_MAXDATALEN(NoteType),SCPTDEF_MAX_REC);     /* PMSTA-33077 - DLA - 181011 */

	if(dbiConnHelper.dbaMultiSelect(FmtElt, UNUSED, inputData,	outputStLst, dataTab, rowTab) != RET_SUCCEED)
	{
		FREE(scptBuf);
		return(0);
	}

	sumFmtEltTab = dataTab[0];
	fmtEltNb     = rowTab[0];

	lastIdx = 0;
	for(i=0 ; i<fmtEltNb ; i++)
	{

		/* REF10437 - LJE - 060328 : In not unicode case, change unicode data type to not unicode data type */
		if (ICU4AAA_SQLServerUTF8==0)
		{
			/* PMSTA12586 - DDV - 111006 - Replace switch by a call to convertion function to treat all unicode datatype */
			DATATYPE_ENUM fmtEltDataType = DATATYPE_DICT_TO_ENUM(GET_DICT(sumFmtEltTab[i], Sum_FmtElt_DataTpDictId));
			DATATYPE_ENUM newDataType = DBA_ConvUniDataTypeToDataType(fmtEltDataType);

			SET_DICT(sumFmtEltTab[i], Sum_FmtElt_DataTpDictId, DATATYPE_ENUM_TO_DICT(newDataType));
		}

		/* PMSTA11612 - DDV - 110609 - TSL multilingual format processing */
		fmtEltId = 0;
		if (GET_ENUM(sumFmtEltTab[i], Sum_FmtElt_TlsMultilingualEn) == TslMultilingual_MultilingualChild)
		{
			strcpy(sqlname, GET_SYSNAME(sumFmtEltTab[i], Sum_FmtElt_SqlName));
			pos=SYS_StrLen(sqlname);
			while (pos >0 && sqlname[pos] != '_')
				pos--;

			if (pos>0)
			{
				sqlname[pos] = END_OF_STRING;
				for(k=0 ; fmtEltId == 0 && k<fmtEltNb ; k++)
				{
					if (GET_ID(sumFmtEltTab[k], Sum_FmtElt_FmtId) == GET_ID(sumFmtEltTab[i], Sum_FmtElt_FmtId) &&
						strcmp(GET_SYSNAME(sumFmtEltTab[k], Sum_FmtElt_SqlName), sqlname) == 0)
					{
						fmtEltId = GET_ID(sumFmtEltTab[k], Sum_FmtElt_Id);
					}
				}
			}
		}

		if (fmtEltId == 0)
		{
			fmtEltId = GET_ID(sumFmtEltTab[i], Sum_FmtElt_Id);
		}

		/***** PRESUME THE SAME "ORDER BY" for data[0] (fmt_elt) & data[1] (script) *****/
		for (j=0 ; j<rowTab[1] && GET_ID(dataTab[1][j],A_ScriptDef_ObjId)!=fmtEltId ; j++);

		/***** IF DEFINITION FOUND FOR CURRENT FORMAT_ELEMENT *****/
		if(j<rowTab[1])
		{
		int     cpt=0;

		scptBuf[0] = END_OF_STRING;

		/***** CONCAT ALL DEFINITION RECORDS FOR THIS FMT_ELT *****/
		while ( j<rowTab[1] && GET_ID(dataTab[1][j],A_ScriptDef_ObjId) == fmtEltId)
		{
			if(cpt<SCPTDEF_MAX_REC)
			{
			strcat(scptBuf, GET_STRING(dataTab[1][j], A_ScriptDef_Def));
			}

		    cpt++;          /*  HFI-PMSTA-20056-150226  move after the if else the block nb SCPTDEF_MAX_REC-1 is not taken in account     */              /*  HFI-PMSTA-20056-150226  Add the '=' else the block nb SCPTDEF_MAX_REC-1 is not taken in account   */
			j++;
		}
		SET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition, scptBuf);

		lastIdx = j;
		}
	}

	/* REF9337 - LJE - 031002 : Remove bad filter */
	lastIdx = 0;
	for(i=0 ; i<fmtEltNb ; i++)
	{
		filterOk = FALSE;
		fmtEltId = GET_ID(sumFmtEltTab[i], Sum_FmtElt_FmtId);
		for (lastIdx=i; lastIdx<fmtEltNb && GET_ID(sumFmtEltTab[lastIdx], Sum_FmtElt_FmtId)==fmtEltId; lastIdx++)
		{
			if ((filterOk==TRUE)                                                  ||
				(IS_NULLFLD(sumFmtEltTab[lastIdx], Sum_FmtElt_FmtFilter) == TRUE) ||
				(IS_NULLFLD(sumFmtEltTab[lastIdx], Sum_FmtElt_SqlName) == FALSE &&
					 strcmp(GET_STRING(sumFmtEltTab[lastIdx], Sum_FmtElt_FmtFilter),
								GET_STRING(sumFmtEltTab[lastIdx], Sum_FmtElt_SqlName)) == 0))
			{
				filterOk=TRUE;
			}
		}

		if (filterOk == FALSE)
		{
			for (j=i; j<lastIdx; j++)
			{
				SET_NULL_STRING(sumFmtEltTab[j], Sum_FmtElt_FmtFilter);
			}
		}

		i = lastIdx-1;
	}

	DBA_FreeDynStTab(dataTab[1], rowTab[1], A_ScriptDef);

	*rowsNbr    = rowTab[0];

	if(rowTab[0] != 0)
		*outputData = sumFmtEltTab;
	else
		*outputData = NULL;

	FREE(scptBuf);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_GetScriptDef
**
**  Description :   It is a get. It returns one script definition record.
**                  The returned script is the concatation of the scripts of all the records (with the same BK)
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   
**
*************************************************************************/
RET_CODE DBA_GetScriptDef(OBJECT_ENUM,
                          DBA_DYNFLD_STP       inputData,
                          DBA_DYNFLD_STP* outputData,
                          DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP  *outputDataTab = NULL;
	int	             rowNb = 0;
	
	dbiConnHelper.resetFromDbaAccess();
    dbiConnHelper.dbaSelect(ScriptDef, UNUSED, inputData, A_ScriptDef, &outputDataTab, &rowNb);

    if (rowNb > 0)
    {
        char *scptBuf = (char*)CALLOC((GET_MAXDATALEN(NoteType) * rowNb) + 1, sizeof(char));
        scptBuf[0] = END_OF_STRING;

        for (int i = 0; i < rowNb; i++)
        {
            strcat(scptBuf, GET_STRING(outputDataTab[i], A_ScriptDef_Def));
        }

        /* PMSTA-45027 - LJE - 210527 */
        CONVERT_DYNST(*outputData, A_ScriptDef, outputDataTab[0], A_ScriptDef);
        SET_NULL_SMALLINT((*outputData), A_ScriptDef_Rank);

        SET_STRING((*outputData), A_ScriptDef_Def, scptBuf);

        FREE(scptBuf);
    }
    DBA_FreeDynStTab(outputDataTab, rowNb, A_ScriptDef);

	return(rowNb > 0 ? RET_SUCCEED : RET_DBA_INFO_NO_MORE_DATA);
}

/************************************************************************
**
**  Function    :   DBA_GetHCParamDef()
**
**  Description :   Returns the script definition for a Holding_Constraint linked
**                  to a constraint attribute parameter
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-30575 - CHU - 180319
**
*************************************************************************/
RET_CODE DBA_GetHCParamDef(OBJECT_ENUM          ,
                           DBA_DYNFLD_STP       inputData,
                           DBA_DYNFLD_STP       *outputData,
                           DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP  *outputDataTab = NULL;
	int	rowNb = 0, i=0;
	char	*scptBuf;

	if (dbiConnHelper.dbaSelect(HoldingConstraintScript, UNUSED, inputData, A_HoldingConstraintScript, &outputDataTab, &rowNb) == FALSE)
	{

	}

	scptBuf = (char*) CALLOC(GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC, sizeof(char)); /* PMSTA-33077 - DLA - 181011 */
	scptBuf[0] = END_OF_STRING;

	for(i=0 ; i<rowNb ; i++)
	   { strcat(scptBuf, GET_STRING(outputDataTab[i], A_HoldingConstraintScript_Definition)); }

	SET_STRING((*outputData) , A_HoldingConstraintScript_Definition, scptBuf);

	DBA_FreeDynStTab(outputDataTab, rowNb, A_HoldingConstraintScript);
	FREE(scptBuf);

	return(rowNb > 0 ? RET_SUCCEED : RET_DBA_INFO_NO_MORE_DATA);
}

/************************************************************************
**
**  Function    :   DBA_GetTCParamDef()
**
**  Description :   Returns the script definition for a Trading_Constraint linked
**                  to a constraint attribute parameter
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-30575 - CHU - 180319
**
*************************************************************************/
RET_CODE DBA_GetTCParamDef(OBJECT_ENUM          ,
                           DBA_DYNFLD_STP       inputData,
                           DBA_DYNFLD_STP       *outputData,
                           DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP  *outputDataTab = NULL;
	int	rowNb = 0, i=0;
	char	*scptBuf;

	if (dbiConnHelper.dbaSelect(TradingConstraintScript, UNUSED, inputData, A_TradingConstraintScript, &outputDataTab, &rowNb) == FALSE)
	{

	}

	scptBuf = (char*) CALLOC(GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC, sizeof(char)); /* PMSTA-33077 - DLA - 181011 */
	scptBuf[0] = END_OF_STRING;

	for(i=0 ; i<rowNb ; i++)
	   { strcat(scptBuf, GET_STRING(outputDataTab[i], A_TradingConstraintScript_Definition)); }

	SET_STRING((*outputData) , A_TradingConstraintScript_Definition, scptBuf);

	DBA_FreeDynStTab(outputDataTab, rowNb, A_TradingConstraintScript);
	FREE(scptBuf);

	return(rowNb > 0 ? RET_SUCCEED : RET_DBA_INFO_NO_MORE_DATA);
}

/************************************************************************
*   Function               : DBA_SendExportRequest()
*
*   Description            : Function which send a request ("sel_export_data")
*                            on a Financial Server and retrieve a description of
*                            each column datatype to export.
*                            Fill exportation context if necessary (Column number,
*                            datatypes, ...)
*
*   Arguments              : exportReq : an exportation context
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_SETPARAM     : if error while setting proc. param.
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 22.04.97 - PEC - Ref.: DVP437.
*   Last modification date : 04.02.00 - GRD - Ref.: REF4204.
*                            REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_SendExportRequest(DBA_EXPORT_STP exportReq)
{
    DBA_DYNFLD_STP       exportCtx = NULL;
    DBA_DYNFLD_STP       bindSt = NULL;
    DBA_DYNFLD_STP       expFmtElt = NULL;
    DBI_INT              resultType;
    DBI_INT              status;
    int                  i;
    int                  colNbr = 0;
    DBA_PROC_STP         rpc = NULL;
    RET_CODE             retCode, finalResult;
    char                 buffer[sizeof(TEXT_T) + 10];   /* PMSTA-33077 - DLA - 181011 */
    DICT_T               entityDictId;
    short               *bindFlags;
    auto                exportMode = static_cast<ExportCtxModeEn>(exportReq->exportMode);

    if (exportReq == NULL)
        return(RET_DBA_ERR_ARGNOMATCH);

    exportCtx = ALLOC_DYNST(ExportCtx_Arg);

    SET_ENUM(exportCtx, ExportCtx_Arg_Updstatus_sign, exportReq->updstatus_sign); 	/* REF1317 - OCE - 981017 */
    SET_INT(exportCtx, ExportCtx_Arg_Updstatus_val, exportReq->updstatus_val); 	/* REF1317 - OCE - 981017 */

    if (exportReq->entity != NullEntity)
    {
        DBA_GetDictId(exportReq->entity, &entityDictId);
        SET_DICT(exportCtx, ExportCtx_Arg_EntDictId, entityDictId);
    }
    else
    {
        FREE_DYNST(exportCtx, ExportCtx_Arg);
        return(RET_DBA_ERR_ARGNOMATCH);
    }

    if(exportMode != ExportCtxModeEn::ExportCtxMode_Outbox)
    {
        if (exportReq->maxRowsNbr > 0)
        {
            SET_INT(exportCtx, ExportCtx_Arg_MaxRowsNbr, exportReq->maxRowsNbr);
        }
		/* PMSTA-43166 Set the format filter flag if any format is provided. Ensures that format is used to compute output */
		if (exportReq->expformatfilter == TRUE)
		{
			SET_FLAG(exportCtx, ExportCtx_Arg_UseFmtFilterFlg, TRUE);
		}
        /* A format id OR a definition list must be provided in default mode */
        if (exportReq->fmtId > 0)
        {
            SET_ID(exportCtx, ExportCtx_Arg_FmtId, exportReq->fmtId);
        }
        else
        {
            if (exportReq->nbCol <= 0)
            {
                FREE_DYNST(exportCtx, ExportCtx_Arg);
                return(RET_DBA_ERR_ARGNOMATCH);
            }

            for (i = 0, colNbr = ExportCtx_Arg_TypeAndScptCol1; i < exportReq->nbCol; i++, colNbr++)
            {
                sprintf(buffer, "%-3" szFormatId, GET_DICT(exportReq->colDescrTab[i], Export_FmtElt_DataTpDictId)); /* DLA - PMSTA08801 - 100209 */
                strcat(buffer, GET_NOTE(exportReq->colDescrTab[i], Export_FmtElt_Def));
                SET_NOTE(exportCtx, colNbr, buffer); /* DLA - REF9575 - 031022 */
            }

            SET_INT(exportCtx, ExportCtx_Arg_ColNbr, exportReq->nbCol);
        }
    }

    if (exportReq->listId > 0)
    {
        SET_ID(exportCtx, ExportCtx_Arg_ListId, exportReq->listId);
    }
    else
    {
        if (exportReq->scriptCondition == NULL)
        {
            FREE_DYNST(exportCtx, ExportCtx_Arg);
            return(RET_DBA_ERR_ARGNOMATCH);
        }


        SET_TEXT(exportCtx, ExportCtx_Arg_ListScript, exportReq->scriptCondition); /* REF4204 */ /* DLA - REF9485 - 030923 */
    }
        
    SET_ENUM(exportCtx,ExportCtx_Arg_ExportModeEn,exportReq->exportMode); /* PMSTA-52258 - JBC - 230308 */

    rpc = DBA_GetStoredProcs(Select, FinAnalysis, UNUSED, ExportCtx_Arg, exportCtx, NullDynSt);

    if ((exportReq->dbiConn = DBA_GetDbiConnection(rpc->server)) == nullptr) /* DLA - PMSTA-24753 190915 */
    {
        MSG_LogMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        FREE_DYNST(exportCtx, ExportCtx_Arg);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (DBI_SetProcParameters(*exportReq->dbiConn, ExportCtx_Arg, exportCtx, rpc) != RET_SUCCEED)
    {
        MSG_LogMesg(RET_DBA_ERR_SETPARAM, 1, FILEINFO);
        FREE_DYNST(exportCtx, ExportCtx_Arg);
        return(RET_DBA_ERR_SETPARAM);
    }

    if ((retCode = exportReq->dbiConn->sendRequest(&resultType)) != RET_SUCCEED)
    {
        if (retCode == RET_DBA_ERR_CANNOTCONNECT)
        {
            DBA_EndConnection(&exportReq->dbiConn, TRUE);
            if ((exportReq->dbiConn = DBA_GetDbiConnection(rpc->server)) == nullptr) /* DLA - PMSTA-24753 190915 */
            {
                FREE_DYNST(exportCtx, ExportCtx_Arg);
                MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
                return(RET_DBA_ERR_CONNOTFOUND);
            }

            /* REF3955 - SSO - 000111 added test */
            if (DBI_SetProcParameters(*exportReq->dbiConn, ExportCtx_Arg, exportCtx, rpc) != RET_SUCCEED)
            {
                MSG_LogMesg(RET_DBA_ERR_SETPARAM, 1, FILEINFO);
                FREE_DYNST(exportCtx, ExportCtx_Arg);
                DBA_EndConnection(&exportReq->dbiConn);
                return(RET_DBA_ERR_SETPARAM);
            }

            retCode = exportReq->dbiConn->sendRequest(&resultType);

            if (retCode != RET_SUCCEED)
            {
                exportReq->dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
                exportReq->dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
                FREE_DYNST(exportCtx, ExportCtx_Arg);
                DBA_EndConnection(&exportReq->dbiConn, TRUE);
                MSG_LogMesg(RET_DBA_ERR_DIALOG, 1, FILEINFO);
                return(RET_DBA_ERR_DIALOG);
            }
        }
        else
        {
            exportReq->dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
            exportReq->dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
            DBA_EndConnection(&exportReq->dbiConn, TRUE);
            MSG_DispMesg(RET_DBA_ERR_DBPROBLEM, NULL, NULL);
            FREE_DYNST(exportCtx, ExportCtx_Arg);
            return(RET_DBA_ERR_DBPROBLEM);
        }
    }

    if (resultType != DBI_ROW_RESULT)
    {
        exportReq->dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
        exportReq->dbiConn->filterMsgInfos(&finalResult);

        DBA_EndConnection(&exportReq->dbiConn);

        if (RET_GET_LEVEL(finalResult) == RET_LEV_ERROR)
        {
            switch (finalResult)
            {
                case RET_SRV_LIB_ERR_COMMAND_ABORTED:
                    MSG_DispMesg(finalResult, NULL, NULL);
                    return(finalResult);

                case RET_SRV_LIB_ERR_PARAMNOTSUPPLIED:
                    MSG_DispMesg(finalResult, NULL, NULL);
                    return(finalResult);
            }
        }

        MSG_DispMesg(RET_DBA_ERR_DIALOG, UNUSED, UNUSED);
        FREE_DYNST(exportCtx, ExportCtx_Arg);

        return(finalResult);
    }

    /* If a format is provided, must retrieve columns description (datatype, display_format, justification, ...) */
    if (exportReq->fmtId > 0)
    {
        expFmtElt = ALLOC_DYNST(Export_FmtElt);
        exportReq->colDescrTab = (DBA_DYNFLD_STP*)CALLOC(255, sizeof(DBA_DYNFLD_STP)); /* REF7264 - PMO */
        exportReq->dbiConn->bindRecvDynSt(Export_FmtElt, expFmtElt);

        /* Read the datatypes */
        colNbr = 0;

        while (exportReq->dbiConn->fetch() == RET_SUCCEED) /* PMSTA-23385 - LJE - 160630 */
        {
            DBI_CopyNullFlagsAndLengthDynSt(*exportReq->dbiConn, expFmtElt, Export_FmtElt);
            exportReq->colDescrTab[colNbr] = ALLOC_DYNST(Export_FmtElt);
            COPY_DYNST(exportReq->colDescrTab[colNbr], expFmtElt, Export_FmtElt);
            colNbr++;
        }

        FREE_DYNST(expFmtElt, Export_FmtElt);
        DBA_FreeNullFlagsAndLength(*exportReq->dbiConn);

        exportReq->nbCol = colNbr;

        if (exportReq->dbiConn->getNextResultSet() != RET_SUCCEED)
        {
            DBA_EndConnection(&exportReq->dbiConn, TRUE);
            FREE_DYNST(exportCtx, ExportCtx_Arg);
            return(RET_DBA_ERR_DIALOG);
        }
    }
    else
        colNbr = exportReq->nbCol;

    exportReq->dbiConn->m_bindNullFlags   = (DBI_SMALLINT *)CALLOC(colNbr + 1, sizeof(DBI_SMALLINT)); 	     /*REF1317 - OCE - 981023 / REF7264 - PMO */
    exportReq->dbiConn->m_bindFieldLength = (DBI_INT *)CALLOC(colNbr + 1, sizeof(DBI_INT)); 		     /*REF1317 - OCE - 981023 / REF7264 - PMO */
    bindFlags                             = exportReq->dbiConn->m_bindFlags = (DBI_SMALLINT *)CALLOC(colNbr + 1, sizeof(DBI_SMALLINT)); /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    exportReq->dbiConn->m_bindDynStp      = ALLOC_DYNST_WITHOUTDEF(colNbr + 1);
    exportReq->dbiConn->m_bindDynStEn     = NullDynSt;
    bindSt                                = exportReq->dbiConn->m_bindDynStp;

    /*REF1317 - OCE - 981023 */
    /* The first returned column is an error msg */
    size_t allocSize = GET_MAXDATALEN(InfoType);
    bindSt[0].dataType = InfoType;
    ALLOC_STRFLD(bindSt[0], allocSize);
    exportReq->dbiConn->colBind(1,
                                InfoType,
                                string(),
                                (PTR)bindSt[0].data.strData.ptr,
                                allocSize,
                                &(exportReq->dbiConn->m_bindFieldLength[0]),
                                &(exportReq->dbiConn->m_bindNullFlags[0]),
								false,
								nullptr,
								nullptr);
    bindFlags[0] = 1; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    /*REF1317 - OCE - 981023 */

    /* Prepare the read of columns of data - bind each column */
    for (i = 1; i <= colNbr; i++)		/*REF1317 - OCE - 981023 */
    {
        string colName = (IS_NULLFLD(exportReq->colDescrTab[i - 1], Export_FmtElt_Sqlname) == FALSE ? GET_SYSNAME(exportReq->colDescrTab[i - 1], Export_FmtElt_Sqlname) : string());
        DATATYPE_ENUM        fieldType = (DATATYPE_ENUM)GET_DICT(exportReq->colDescrTab[i - 1], Export_FmtElt_DataTpDictId);	/*REF1317 - OCE - 981023 / REF7264 - PMO */
        bindSt[i].dataType = static_cast<unsigned char>(fieldType);

        bindFlags[i] = 1; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        if ((GET_CTYPE(fieldType) == CharPtrCType) || (GET_CTYPE(fieldType) == TextPtrCType))	/* REF4204 */
        {
            allocSize = GET_MAXDATALEN(fieldType);
            ALLOC_STRFLD(bindSt[i], allocSize);
            exportReq->dbiConn->colBind(i + 1,
                                        fieldType,
                                        colName,
                                        (PTR)bindSt[i].data.strData.ptr,
                                        allocSize,
                                        &exportReq->dbiConn->m_bindFieldLength[i],
                                        &exportReq->dbiConn->m_bindNullFlags[i],
										false,
										nullptr,
										nullptr);
        }
        else
            if (GET_CTYPE(fieldType) == UniCharPtrCType)
            {
                allocSize = GET_MAXLEN(fieldType);
                ALLOC_USTRFLD(bindSt[i], allocSize);
                exportReq->dbiConn->colBind(i + 1,
                                            fieldType,
                                            colName,
                                            (PTR)bindSt[i].data.ustrData.ptr,
                                            allocSize,
                                            &exportReq->dbiConn->m_bindFieldLength[i],
                                            &exportReq->dbiConn->m_bindNullFlags[i],
											false,
											nullptr,
											nullptr);
            }
            else
            {
                if (fieldType == ExtensionType ||
                    fieldType == ChainedTypeType)   /* PMSTA-34537 - LJE - 190129 */
                {
                    exportReq->dbiConn->colBind(i + 1,
                                                AmountType,
                                                colName,
                                                (PTR)&bindSt[i].data.dbleValue,
                                                0,
                                                &exportReq->dbiConn->m_bindFieldLength[i],
                                                &exportReq->dbiConn->m_bindNullFlags[i],
												false,
												nullptr,
												nullptr);
                }
                else
                {
                    if (fieldType == DateType || fieldType == DatetimeType)
                        exportReq->dbiConn->colBind(i + 1,
                                                    exportReq->dbiConn->getDescription().getModel() == QtHttp ? DatetimeType : NumberType,  /* DLA - PMSTA-25152 - 161031 */
                                                    colName,
                                                    (PTR)&bindSt[i].data.datetime64St,
                                                    0,
                                                    &exportReq->dbiConn->m_bindFieldLength[i],
                                                    &exportReq->dbiConn->m_bindNullFlags[i],
													false,
													nullptr,
													nullptr);
                    else
                        exportReq->dbiConn->colBind(i + 1,
                                                    fieldType,
                                                    colName,
                                                    (PTR)&bindSt[i].data.dbleValue,
                                                    0,
                                                    &exportReq->dbiConn->m_bindFieldLength[i],
                                                    &exportReq->dbiConn->m_bindNullFlags[i],
													false,
													nullptr,
													nullptr);
                }
            }
    }

    FREE_DYNST(exportCtx, ExportCtx_Arg);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function               : DBA_GetExportedData()
*
*   Description            : Function which retrieve an row of data (one or many
*                            columns) according to informations stored in
*                            connection structure and exportation context and fill
*                            fields given as arguments.
*
*   Arguments              : exportReq  : an exportation context previously used by
*                                         DBA_SendExportRequest().
*                            dataFields : fields to fill
*
*   Return                 : RET_SUCCEED           : if ok
*                            RET_DBA_INFO_NODATA   : if no more data to read
*                            RET_DBA_ERR_DBPROBLEM : if problem while reading data
*
*   Creation date          : 22.04.97 - PEC - Ref.: DVP437.
*   Last modification date : 04.02.00 - GRD - Ref.: REF4204.
*                            REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_GetExportedData(DBA_EXPORT_STP exportReq, DBA_DYNFLD_STP dataFields)
{
	int            j, colNbr, result;
	DATATYPE_ENUM  fieldType;
    DBI_SMALLINT   *nullData;
	DBI_INT        *fieldLength;
    DBI_SMALLINT   *bindFlags;
	DBA_DYNFLD_STP bindFld=NULL;
	DbiConnection  *dbiConn = nullptr;

	if (exportReq == NULL || dataFields == NULL)
		return(RET_DBA_ERR_ARGNOMATCH);

	if (exportReq->dbiConn == nullptr)
		return(RET_DBA_ERR_ARGNOMATCH);

	if (exportReq->nbCol <= 0)
		return(RET_SUCCEED);

	dbiConn		= exportReq->dbiConn;
	colNbr      = exportReq->nbCol;
	nullData    = dbiConn->m_bindNullFlags;
	fieldLength = dbiConn->m_bindFieldLength;
	bindFlags	= dbiConn->m_bindFlags; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
	bindFld		= dbiConn->m_bindDynStp;

	if (nullData == NULL || fieldLength == NULL || bindFld == NULL || bindFlags == NULL)
		return (RET_DBA_ERR_ARGNOMATCH);

    result = dbiConn->fetch();/* PMSTA-23385 - LJE - 160630 */

	if (result == RET_SUCCEED)
    {
		{
			DBA_DYNFLD_STP pointer = dbiConn->m_bindDynStp;

			DBI_CopyNullFlagsAndLength(*dbiConn, pointer, 0, InfoType); /* REF1317 - OCE - 981023 */

			for (j = 1; j < colNbr + 1; j++)
			{
				fieldType =
					(DATATYPE_ENUM)GET_DICT(
						exportReq->colDescrTab[j-1], Export_FmtElt_DataTpDictId); /* REF7264 - PMO */

				DBI_CopyNullFlagsAndLength(*dbiConn, pointer, j, fieldType); /* REF1317 - OCE - 981023 */
			}
		}


		fieldType = InfoType;
		if (nullData[0] == -1) /* -1 means that the received data is NULL */
		{
			SET_NULL_STRING(dataFields, 0);
		}
		else
		{
			SET_STRING(dataFields,0, GET_STRING(bindFld, 0));
		}

		for (j=1 ; j<colNbr+1 ; j++)		/* REF1317 - OCE - 981023 */
		{
			fieldType = (DATATYPE_ENUM) GET_DICT(exportReq->colDescrTab[j-1], Export_FmtElt_DataTpDictId); /* REF7264 - PMO */

			switch (GET_CTYPE(fieldType))
			{
			case DoubleCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_DOUBLE(dataFields, j);
				}
				else
				{
					SET_DOUBLE(dataFields,j, GET_DOUBLE(bindFld, j));
				}
				break;

			case IntCType :
			case UIntCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_INT(dataFields, j);
				}
				else
				{
					SET_INT(dataFields, j, GET_INT(bindFld, j));
				}
				break;

			case LongLongCType :   /* DLA - PMSTA08801 - 101026 */

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_LONGLONG(dataFields, j);
				}
				else
				{
					SET_LONGLONG(dataFields, j, GET_LONGLONG(bindFld, j));
				}
				break;

			case ShortCType :
			case UShortCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_SHORT(dataFields, j);
				}
				else
				{
					SET_SHORT(dataFields, j, GET_SHORT(bindFld, j));
				}
				break;

			case UCharCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_UCHAR(dataFields, j);
				}
				else
				{
					SET_UCHAR(dataFields, j, GET_UCHAR(bindFld, j));
				}
				break;

			case DateTimeStCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_DATETIMEST(dataFields, j);
				}
				else
				{
					SET_DATETIME(dataFields, j, GET_DATETIME(bindFld, j))
				}
				break ;

			case CharPtrCType :
			case TextPtrCType :			/* REF4204 */

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_STRING(dataFields, j);
				}
				else
				{
					SET_STRING(dataFields,j, GET_STRING(bindFld, j));
				}
				break;

			case UniCharPtrCType :

				if (nullData[j] == -1) /* -1 means that the received data is NULL */
				{
					SET_NULL_USTRING(dataFields, j);
				}
				else
				{
					SET_USTRING(dataFields,j, GET_USTRING(bindFld, j));
				}

			}
		}
	}

    return(result);
}

/************************************************************************
*   Function               : DBA_FreeDataInExportCtx()
*
*   Description            : Function which free allocated arrays and structure
*                            in exportation context and, if endConnFlg = TRUE, fill
*                            allocated objects in connection structure.
*
*   Arguments              : exportReq  : an exportation context
*                            encConnFlg : TRUE, connection is freed, FALSE, nothing made
*                                         about connection structure
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with input arg.
*
*   Creation date          : 22.04.97 - PEC - Ref.: DVP437
*   Last modification date : 21.10.97 - XPE - Ref.: BUG664
*                            Change IS_NULLFLD(DBA_GetConnStructPtr(connectNo)->dynStp, 0)
*                            by     IS_NULLFLD(DBA_GetConnStructPtr(connectNo)->dynStp, i)
*
*                            and    GET_STRING(DBA_GetConnStructPtr(connectNo)->dynStp, 0)
*                            by     GET_STRING(DBA_GetConnStructPtr(connectNo)->dynStp, i)
*                            04.02.00 - GRD - Ref.: REF4204.
*************************************************************************/
RET_CODE DBA_FreeDataInExportCtx(DBA_EXPORT_STP exportReq, FLAG_T endConnFlg)
{
    DBI_INT         status;
    int             i, colNbr;
	DbiConnection  *dbiConn = nullptr;

	if (exportReq == NULL)
	{
		return(RET_DBA_ERR_ARGNOMATCH);
	}

	if (endConnFlg == TRUE)
	{
		dbiConn   = exportReq->dbiConn;
		colNbr    = exportReq->nbCol;

		if (dbiConn != nullptr)
		{
			FREE(dbiConn->m_bindNullFlags);
			FREE(dbiConn->m_bindFieldLength);
			FREE(dbiConn->m_bindFlags); /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */

			if (dbiConn->m_bindDynStp != NULL)
			{
                FREE_STRFLD(dbiConn->m_bindDynStp[0]);

                for (i = 0; i < colNbr; i++)
                {
                    if ((GET_CTYPE(GET_DICT(exportReq->colDescrTab[i], Export_FmtElt_DataTpDictId)) == CharPtrCType) ||
                        (GET_CTYPE(GET_DICT(exportReq->colDescrTab[i], Export_FmtElt_DataTpDictId)) == TextPtrCType))
                    {
                        FREE_STRFLD(dbiConn->m_bindDynStp[i + 1]);
                    }
                    else if (GET_CTYPE(GET_DICT(exportReq->colDescrTab[i], Export_FmtElt_DataTpDictId)) == UniCharPtrCType ||
                             GET_CTYPE(GET_DICT(exportReq->colDescrTab[i], Export_FmtElt_DataTpDictId)) == UniTextPtrCType)
                    {
                        FREE_USTRFLD(dbiConn->m_bindDynStp[i + 1]);
                    }
                }

				FREE(dbiConn->m_bindDynStp);
			}

            dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
			DBA_EndConnection(&dbiConn);

			exportReq->dbiConn = nullptr;
		}
	}

	if (exportReq->colDescrTab != NULL)
	{
		DBA_FreeDynStTab(exportReq->colDescrTab, exportReq->nbCol, Export_FmtElt);
	}

	return (RET_SUCCEED);
}

/************************************************************************
*   Function               : DBA_GetShortByCd()
*
*   Description            : Given a code.
*
*   Arguments              : object       : the request corresponding object
*                            inputCd      : the record code
*                            recordId     : the record Id
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 14.11.97 - GRD - Ref.: REF550.
*   Last modification date :
*************************************************************************/
RET_CODE DBA_GetShortByCd(OBJECT_ENUM          object,
                          DBA_DYNFLD_STP       refRec,
                          DBA_DYNFLD_STP       *outputData,
                          DbiConnection&       dbiConn,
                          DBA_ERRMSG_INFOS_STP )
{
	DBA_DYNFLD_STP  inputData = NULL;
	DBA_PROC_STP	procedure = NULL;
	RET_CODE	ret = RET_SUCCEED;
	int		i = 0;

	DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp == NULL)
	{
		return(RET_DBA_ERR_ARGNOMATCH);
	}

	if ((inputData = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	/* Copy only business key records. */
	/* PMSTA03013 - DDV - 070711 - Changes to access structures with correct dynst */
    /* PMSTA-26108 - LJE - 170926 */
    for (i = 0; i < dictEntityStp->bkAttrNbr; i++)
    {
        DBA_CopyDynFld(inputData, GET_ADMINGUIST(object), dictEntityStp->bkAttr[i]->shortIdx,
                       refRec, GET_EDITGUIST(object), dictEntityStp->bkAttr[i]->progN);
    }

	/* Retrieve a procedure in the object procedures list */
	procedure = DBA_GetStoredProcs(Get, object, UNUSED, GET_ADMINGUIST(object), inputData, GET_ADMINGUIST(object));

	/* If no procedure found */
	if (procedure == NULL)
	{
		FREE_DYNST(inputData, GET_ADMINGUIST(object));
		return(RET_DBA_ERR_PROCNOTFOUND);
	}

	if ((*outputData = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)
	{
		FREE_DYNST(inputData, GET_ADMINGUIST(object));
		return(RET_MEM_ERR_ALLOC);
	}

	ret = DBA_Get2(object,
			   UNUSED,
			   GET_ADMINGUIST(object),
			   inputData,
			   GET_ADMINGUIST(object),
			   outputData,
			   DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_MAIN_LEVEL,
			   dbiConn);

	FREE_DYNST(inputData, GET_ADMINGUIST(object));

	return(ret);
}

/************************************************************************
*   Function               : DBA_GetAllByTechKey()
*
*   Description            : Given an id.
*
*   Arguments              : object       : the request corresponding object
*                            inputCd      : the record code
*                            recordId     : the record Id
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_NODATA       : if no corresponding rec. found
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : 16.03.98 - GRD - Ref.: REF1054.
*   Last modification date : 22.04.98 - GRD - Ref.: REF1847.
*************************************************************************/
RET_CODE DBA_GetAllByTechKey(OBJECT_ENUM          object,
							 DBA_DYNFLD_STP       inputData,
							 DBA_DYNFLD_STP       *outputData)
{
	DBA_PROC_STP	procedure = NULL;
	RET_CODE		ret = RET_SUCCEED;
	DbiConnection	*dbiConn = nullptr;

	/* Retrieve a procedure in the object procedures list */
	procedure = DBA_GetStoredProcs(Get, object, UNUSED, GET_ADMINGUIST(object), inputData, GET_EDITGUIST(object));

	/* If no procedure found */
	if (procedure == NULL)
	{
		return(RET_DBA_ERR_PROCNOTFOUND);
	}

	if ((*outputData = ALLOC_DYNST(GET_EDITGUIST(object))) == NULL)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
	{
			FREE_DYNST(*outputData,GET_EDITGUIST(object)); /* REF5976 - DDV - 010423 */
		return(RET_SUCCEED);
	}

	ret = DBA_Get2(object,
			   UNUSED,
			   GET_ADMINGUIST(object),
			   inputData,
			   GET_EDITGUIST(object),
			   outputData,
			   DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_MAIN_LEVEL,
			   *dbiConn);

	DBA_EndConnection(&dbiConn);	/* REF1847 */

	if (ret != RET_SUCCEED)
		FREE_DYNST(*outputData, GET_EDITGUIST(object)); /* REF5976 - DDV - 010423 */

	return(ret);
}

/************************************************************************
*
*   Function      :   FIN_FilterDfltCashInstrByCurr()
*
*   Description   :   Filter default cash account for received currency identifier
*
*   Arguments     :
*
*   Return        :   TRUE or FALSE
*
*   Creation	  :   PMSTA00485 - RAK - 061122
*
*************************************************************************/
STATIC int FIN_FilterDfltCashInstrByCurr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM , DBA_DYNFLD_STP getData)
{
	if (GET_ID(dynSt, A_Instr_RefCurrId) == GET_ID(getData, Get_Arg_RefCurrId) &&
		GET_ENUM(dynSt, A_Instr_NatEn) == InstrNat_CashAcct &&
		GET_FLAG(dynSt, A_Instr_DefaultFlg) == TRUE)
		return TRUE;
	else
		return FALSE;
}

/************************************************************************
*
*  Function     : DBA_GetDfltCashInstrByCurr()
*
*  Description  : Get cash instrument according to received currency (in getData)
*
*  Arguments    : hierHeadParam	pointer on hierarchy
*				  getData		Get_Arg dynamic structure with
*								Get_Arg_RefCurrId -> searched currency
*				  addInHier		Flag to indicate if new portfolio must be add in hierachy
*				  allocFlg		Flag to determine if the return portfolio was allocated or not
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF2467 - DDV - 991215
*
*************************************************************************/
EXTERN RET_CODE DBA_GetDfltCashInstrByCurr(PTR					hierHeadParam,
										   DBA_DYNFLD_STP		getData,
										   FLAG_T               addInHierFlg,
										   FLAG_T               *allocFlg,
										   DBA_DYNFLD_STP       *cashInstrPtr)
{
	DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)NULL;
	DBA_DYNFLD_STP		*cashInstrTab=NULLDYNSTPTR;
	int					cashInstrNbr=0;
	RET_CODE			ret=RET_SUCCEED;
	FLAG_T              freeFlag=FALSE;

	if (getData == NULLDYNST)
	{
		MSG_RETURN(RET_GEN_ERR_INVARG);
	}

	if (cashInstrPtr == NULL || allocFlg == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	*cashInstrPtr = NULL;

	if (hierHeadParam !=  NULL)
			hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
			hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

	/* First verify in hierachy (often the cash account will be loaded with position's instruments) */
	if (hierHead != (DBA_HIER_HEAD_STP) NULL)
	{
		SET_FLAG(getData, Get_Arg_Flag, TRUE)
		if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_Instr,
												   A_Instr_DefaultFlg,
												   getData[Get_Arg_Flag], FALSE,
												   FIN_FilterDfltCashInstrByCurr,
												   getData, NULLFCT, FALSE,
												   &cashInstrNbr, &cashInstrTab)) == RET_SUCCEED)

		{
			if (cashInstrNbr >= 1)
			{
				*allocFlg = FALSE;
				*cashInstrPtr = cashInstrTab[0];
				FREE(cashInstrTab);
				return(RET_SUCCEED);
			}
		}
	}

	*allocFlg = TRUE;
	if ((*cashInstrPtr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* Necessary to perform a get in database */
	/* (because it's a special test with currency) */
	SET_ENUM(getData, Get_Arg_NatEn, InstrNat_CashAcct);
	if (DBA_Get2(Instr, UNUSED, Get_Arg, getData, A_Instr, cashInstrPtr,
				 UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		DBA_DYNFLD_STP	currPtr=NULLDYNST;

		/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
		if (DBA_GetCurrById(GET_ID(getData, Get_Arg_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 10, FILEINFO, GET_CODE(currPtr, A_Curr_Cd));}
		else
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 11, FILEINFO, GET_ID(getData, Get_Arg_RefCurrId));}

		if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
		FREE_DYNST((*cashInstrPtr), A_Instr);
		return(RET_DBA_ERR_NODATA);
	}

	/* add cash instrument in hierarchy */
	if (hierHead != NULL && addInHierFlg == TRUE)
	{
		if (DBA_AddHierRecord(hierHead, *cashInstrPtr, A_Instr, TRUE,
                              HierAddRec_ForceInsert) == RET_SUCCEED)
		{
			*allocFlg = FALSE;
		}
	}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function     : DBA_GetPtfById()
*
*  Description  : Get portfolio in hierarchy, if not found call database.
*
*  Arguments    : ptfId           Id of portfolio to load
*                 addPtfInHier    Flag to indicate if new portfolio must be add in hierachy
*	          allocFlg        Flag to determine if the return portfolio was allocated or not
*		  ptfPtr          Pointer to portfolio to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF3913 - RAK - 990826
*
*************************************************************************/
EXTERN RET_CODE DBA_GetPtfById(ID_T                 ptfId,
							   FLAG_T               addPtfInHierFlg,
							   FLAG_T               *allocFlg,
							   DBA_DYNFLD_STP       *ptfPtr,
							   PTR                  hierHeadParam,
							   int                  getOptions,
							   int                  *allocConn)
{
	DBA_DYNFLD_STP	  getPtf=NULL;
	DBA_HIER_HEAD_STP hierHead;

	if (ptfPtr == NULL || allocFlg == NULL || ptfId == ZERO_ID)
	{
				return(RET_GEN_ERR_INVARG);
	}

	*allocFlg = FALSE;	/* Moved after test */

	*ptfPtr = NULL;

	if (hierHeadParam !=  NULL)
			hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
			hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();


	if (hierHead != NULL)
	{
			if (DBA_GetRecPtrFromHierById(hierHead, ptfId, A_Ptf, ptfPtr) == RET_SUCCEED &&
				*ptfPtr != NULL)
					return(RET_SUCCEED);
	}

	if ((getPtf=ALLOC_DYNST(S_Ptf))==NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (((*ptfPtr) = ALLOC_DYNST(A_Ptf))==NULL)
	{
		FREE_DYNST(getPtf, S_Ptf);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
		*allocFlg = TRUE;

	SET_ID(getPtf,S_Ptf_Id, ptfId);
	if (DBA_Get2(Ptf, UNUSED, S_Ptf, getPtf, A_Ptf, ptfPtr, getOptions, allocConn) != TRUE)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Ptf));
		FREE_DYNST((*ptfPtr), A_Ptf);
				*allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			 entSqlName, GET_ID(getPtf, S_Ptf_Id));
		FREE_DYNST(getPtf, S_Ptf);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getPtf, S_Ptf);

		if (addPtfInHierFlg == TRUE &&
			hierHead != NULL)
		{
				if (DBA_AddHierRecord(hierHead,
						  *ptfPtr, A_Ptf, TRUE,
							  HierAddRec_ForceInsert) == RET_SUCCEED)
				*allocFlg = FALSE;
		}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function     : DBA_GetThirdById()
*
*  Description  : Get third party in hierarchy, if not found call database.
*
*  Arguments    : thirdId           Id of third party to load
*                 addThirdInHier    Flag to indicate if new third party must be add in hierachy
*	              allocFlg        Flag to determine if the return third party was allocated or not
*		          thirdPtr        Pointer to third party to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : PMSTA06916 - LJE - 081105
*
*************************************************************************/
EXTERN RET_CODE DBA_GetThirdById(ID_T                 thirdId,
								 FLAG_T               addThirdInHierFlg,
								 FLAG_T               *allocFlg,
								 DBA_DYNFLD_STP       *thirdPtr,
								 PTR                  hierHeadParam,
								 int                  getOptions,
								 int                  *allocConn,
								 DBA_ERRMSG_INFOS_STP )
{
	DBA_DYNFLD_STP	  getThird=NULL;
	DBA_HIER_HEAD_STP hierHead;

	if (thirdPtr == NULL || allocFlg == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	*allocFlg = FALSE;	/* Moved after test */

	*thirdPtr = NULL;

	if (hierHeadParam !=  NULL)
	   hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
	   hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();


	if (hierHead != NULL)
	{
		if (DBA_GetRecPtrFromHierById(hierHead, thirdId, A_Third, thirdPtr) == RET_SUCCEED &&
			*thirdPtr != NULL)
				return(RET_SUCCEED);
	}

	if ((getThird=ALLOC_DYNST(S_Third))==NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (((*thirdPtr) = ALLOC_DYNST(A_Third))==NULL)
	{
		FREE_DYNST(getThird, S_Third);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
		*allocFlg = TRUE;

	SET_ID(getThird,S_Third_Id, thirdId);
	if (DBA_Get2(Third, UNUSED, S_Third, getThird, A_Third, thirdPtr, getOptions, allocConn) != TRUE)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Third));
		FREE_DYNST((*thirdPtr), A_Third);
		*allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			 entSqlName, GET_ID(getThird, S_Third_Id));
		FREE_DYNST(getThird, S_Third);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getThird, S_Third);

		if (addThirdInHierFlg == TRUE &&
			hierHead != NULL)
		{
			if (DBA_AddHierRecord(hierHead,
					  *thirdPtr, A_Third, TRUE,
						  HierAddRec_ForceInsert) == RET_SUCCEED)
			*allocFlg = FALSE;
		}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function     : DBA_GetListById()
*
*  Description  : Get list in hierarchy, if not found call database.
*
*  Arguments    : listId          Id of list to load
*                 addPtfInHier    Flag to indicate if new portfolio must be add in hierachy
*	              allocFlg        Flag to determine if the return portfolio was allocated or not
*		          listPtr         Pointer to portfolio to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF10176 - LJE - 041125
*
*************************************************************************/
EXTERN RET_CODE DBA_GetListById(ID_T                 listId,
								FLAG_T               addListInHierFlg,
								FLAG_T               *allocFlg,
								DBA_DYNFLD_STP       *listPtr,
								PTR                  hierHeadParam,
								int                  getOptions,
								int                  *allocConn,
								DBA_ERRMSG_INFOS_STP )
{
	DBA_DYNFLD_STP	  getList=NULL;
	DBA_HIER_HEAD_STP hierHead;

	*allocFlg = FALSE;

	if (listPtr == NULL || allocFlg == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	*listPtr = NULL;

	if (hierHeadParam !=  NULL)
		hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
		hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();


	if (hierHead != NULL)
	{
		if (DBA_GetRecPtrFromHierById(hierHead, listId, A_List, listPtr) == RET_SUCCEED &&
				*listPtr != NULL)
			return(RET_SUCCEED);
	}

	if ((getList=ALLOC_DYNST(S_List))==NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (((*listPtr) = ALLOC_DYNST(A_List))==NULL)
	{
		FREE_DYNST(getList, S_List);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
		*allocFlg = TRUE;

	SET_ID(getList,S_List_Id, listId);
	if (DBA_Get2(List, UNUSED, S_List, getList, A_List, listPtr,
				 getOptions, allocConn) != TRUE)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(List));
		FREE_DYNST((*listPtr), A_List);
		*allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		entSqlName, GET_ID(getList, S_List_Id));
		FREE_DYNST(getList, S_List);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getList, S_List);

	if (addListInHierFlg == TRUE &&
		hierHead != NULL)
	{
		if (DBA_AddHierRecord(hierHead,
							  *listPtr, A_List, TRUE,
							  HierAddRec_ForceInsert) == RET_SUCCEED)
		*allocFlg = FALSE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function     : DBA_GetStratById()
*
*  Description  : Get strategy in hierarchy, if not found call database.
*
*  Arguments    : stratId         Id of strategy to load
*                 addStratInHier  Flag to indicate if new strategy must be add in hierachy
*	              allocFlg        Flag to determine if the return strategy was allocated or not
*		          stratPtr        Pointer to strategy to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF9340 - DDV - 030821
*
*************************************************************************/
EXTERN RET_CODE DBA_GetStratById(ID_T                 stratId,
								 FLAG_T               addStratInHierFlg,
								 FLAG_T               *allocFlg,
								 DBA_DYNFLD_STP       *stratPtr,
								 PTR                  hierHeadParam,
								 int                  getOptions,
								 int                  *allocConn)
{
	DBA_DYNFLD_STP	  getStrat=NULL;
	DBA_HIER_HEAD_STP hierHead;

	*allocFlg = FALSE;

	if (stratPtr == NULL || allocFlg == NULL)
	{
				return(RET_GEN_ERR_INVARG);
	}

	*stratPtr = NULL;

	if (hierHeadParam !=  NULL)
			hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
			hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();


	if (hierHead != NULL)
	{
			if (DBA_GetRecPtrFromHierById(hierHead, stratId, A_Strat, stratPtr) == RET_SUCCEED &&
				*stratPtr != NULL)
					return(RET_SUCCEED);
	}

	if ((getStrat=ALLOC_DYNST(S_Strat))==NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (((*stratPtr) = ALLOC_DYNST(A_Strat))==NULL)
	{
		FREE_DYNST(getStrat, S_Strat);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
		*allocFlg = TRUE;

	SET_ID(getStrat,S_Strat_Id, stratId);
	if (DBA_Get2(Strat, UNUSED, S_Strat, getStrat, A_Strat, stratPtr, getOptions, allocConn) != TRUE)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Strat));
		FREE_DYNST((*stratPtr), A_Strat);
				*allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			 entSqlName, GET_ID(getStrat, S_Strat_Id));
		FREE_DYNST(getStrat, S_Strat);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getStrat, S_Strat);

		if (addStratInHierFlg == TRUE &&
			hierHead != NULL)
		{
				if (DBA_AddHierRecord(hierHead,
						  *stratPtr, A_Strat, TRUE,
							  HierAddRec_ForceInsert) == RET_SUCCEED)
				*allocFlg = FALSE;
		}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetGridById()
*
*   Description          : Get a grid by Id in a hierarchy or in database
*
*   Arguments            :
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : REF7420 - LJE - 020523
*   Last Modif           : REF7395 - CSY - 020621: EXTERN
*	Last Modif			 : REF7420 - RAK - 021031 - FIN_GetGridById() -> DBA_GetGridById()
*
*************************************************************************/
RET_CODE DBA_GetGridById(ID_T                   gridId,
						 FLAG_T                 addGridInHierFlg,
						 FLAG_T                 *aGridStAllocFlgPtr,
						 DBA_DYNFLD_STP         *aGridStp,
						 PTR                    hierHeadParam,
						 int                    selOptions,
						 int*                   connectNo,
						 DBA_ERRMSG_INFOS_STP   )
{
	DBA_DYNFLD_STP		sGridSt = NULL;
	DBA_HIER_HEAD_STP	hierHead=NULL;

	if (aGridStp == NULL || aGridStAllocFlgPtr == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	*aGridStAllocFlgPtr = FALSE;

	*aGridStp = NULL;

	if (hierHeadParam != NULL)
		hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
		hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

	/* First verify in hierarchy */
	if (hierHead != NULL)
	{
		if (DBA_GetRecPtrFromHierById(hierHead,
									  gridId,
									  A_Grid,
									  aGridStp) == RET_SUCCEED && *aGridStp != NULL)
		{
			return(RET_SUCCEED);
		}
	}

	/* No hierarchy or not found in hierarchy */
	if ((sGridSt = ALLOC_DYNST(S_Grid)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	if (((*aGridStp) = ALLOC_DYNST(A_Grid)) == NULL)
	{
		FREE_DYNST(sGridSt, S_Grid);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	*aGridStAllocFlgPtr = TRUE;

	/* Get GRID record */
	SET_ID(sGridSt, S_Grid_Id, gridId);
	if (DBA_Get2(Grid,
				 UNUSED,
				 S_Grid,
				 sGridSt,
				 A_Grid,
				 aGridStp,
				 selOptions,
				 connectNo) != RET_SUCCEED)
	{
		FREE_DYNST((*aGridStp), A_Grid);
		*aGridStAllocFlgPtr = FALSE;
		FREE_DYNST(sGridSt, S_Grid);
		return(RET_GEN_INFO_NODATA);
	}

	FREE_DYNST(sGridSt, S_Grid);

	/* add in hierarchy if asked and possible */
	if (addGridInHierFlg == TRUE &&
		hierHead != NULL)
	{
			if (DBA_AddHierRecord(hierHead,
								  *aGridStp, A_Grid, TRUE,
								  HierAddRec_ForceInsert) == RET_SUCCEED)
				*aGridStAllocFlgPtr = FALSE;
	}

	return(RET_SUCCEED);
}


/************************************************************************
*
*  Function     : DBA_GetPtfSysCurrIdById()
*
*  Description  : Get portfolio system currency. Verify in hierarchy (A_Ptf),
**                if not found call database for a S_Ptf (importation optimisation 3777).
*
*  Arguments    : ptfId           Id of portfolio to search system currency
*                 hierHeadParam   Hierarchy pointer (can be NULL, rpc hierarchy will be used if exist)
*                 sysCurrId       pointer on system currency identifier
*
*  Return       : RET_SUCCEED or error code, sysCurrId will be
*                 set to 0 if field in ptf structure is NULL (but RET_SUCCEED)
*
*  Creation     : REF4332 - RAK - 000209
*
*************************************************************************/
RET_CODE DBA_GetPtfSysCurrIdById(ID_T ptfId,
                                 PTR  hierHeadParam,
                                 ID_T* sysCurrId,
								 DbiConnection* dbiConnPtr)
{
	DBA_DYNFLD_STP	  admArgPtr=NULL, ptfPtr=NULL;
	DBA_HIER_HEAD_STP hierHead;
	FLAG_T            found=FALSE;
	RET_CODE          ret=RET_SUCCEED;

	*sysCurrId = 0;

	/* Verify in hierarchy if all portfolio structure exist */
	if (hierHeadParam !=  NULL)
		hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
		hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

	if (hierHead != NULL)
	{
		if (DBA_GetRecPtrFromHierById(hierHead, ptfId, A_Ptf,
									  &ptfPtr) == RET_SUCCEED &&
			ptfPtr != NULL)
		{
			if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
				*sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
			found = TRUE;
		}
	}

	/* In case of no hierarchy is found, or error      */
	/* or portfolio isn't found, get S_Ptf in database */
	if (found == FALSE)
	{
		if ((admArgPtr=ALLOC_DYNST(Adm_Arg))==NULL)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		if ((ptfPtr=ALLOC_DYNST(S_Ptf))==NULL)
		{
			FREE_DYNST(admArgPtr, Adm_Arg);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(admArgPtr, Adm_Arg_Id, ptfId);

		DbiConnectionHelper dbiConnHelper(dbiConnPtr);

	    ret = dbiConnHelper.dbaGet(Ptf, UNUSED, admArgPtr, &ptfPtr);

		if (ret != RET_SUCCEED)
		{
			if (ret != RET_SRV_LIB_ERR_DEADLOCK) /* REF4001 - SSO - 991008 */
			{
				MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
							 "Portfolio", ptfId);
				ret = RET_DBA_ERR_NODATA;
			}
			else
			{
				MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, "DBA_GetPtfSysCurrIdById");
				ret = RET_SRV_LIB_ERR_DEADLOCK;
			}

			FREE_DYNST(ptfPtr, S_Ptf);
			FREE_DYNST(admArgPtr, Adm_Arg);
			return(ret);
		}

		if (IS_NULLFLD(ptfPtr, S_Ptf_SysCurrId) == FALSE)
		{
			*sysCurrId = GET_ID(ptfPtr, S_Ptf_SysCurrId);
		}

		/* Free memory allocation */
		FREE_DYNST(ptfPtr, S_Ptf);
		FREE_DYNST(admArgPtr, Adm_Arg);
	}

	return(ret);
}



/************************************************************************
**
**  Function    :   DBA_FillDataType
**
**  Description :   Fill Data Type
**
**  Arguments   :   DBA_DATASET_STP	setStp
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   MRA - 000303 - REF4481
**
*************************************************************************/
void DBA_FillDataType(DBA_DATASET_STP setStp)
{

	int					i, j;
	DBA_DYNFLD_STP		dynStp, dataDef;

	for(i=0; i< setStp->rowNb; i++)
	{
		dynStp = &(setStp->data[i*setStp->colNb]);
		for(j=0; j< setStp->colNb; j++)
		{
			dataDef = &(setStp->dataDef[j*GET_FLD_NBR(DataDef)]);
			dynStp[j].dataType = (unsigned char) GET_INT(dataDef, DataDef_Datatype);
		}
	}

}

/************************************************************************
*
*   Function           : DBA_CheckIfListHistorised()
*
*   Description        : Check is a list is historised.
*
*   Arguments          : list id
*
*   Return             : TRUE or FALSE
*
*  Creation Date       : REF4306 - DDV - 000328
*
*************************************************************************/
FLAG_T DBA_CheckIfListHistorised(ID_T                    listId,
                                 int                     selOptions,
                                 int*                    connectNo)

{
	DBA_DYNFLD_STP 	ioIdRec = NULL;
	DBA_DYNFLD_STP 	askListCompo = NULL;

	if (listId <= 0)
		return(FALSE);

	if ((ioIdRec = ALLOC_DYNST(Io_Id)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(FALSE);
	}

	if ((askListCompo = ALLOC_DYNST(S_ListCompo)) == NULL)
	{
		FREE_DYNST(ioIdRec, Io_Id);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(FALSE);
	}

	SET_ID(askListCompo, S_ListCompo_Id, listId);

	if (DBA_Get2(ListCompo,
				 UNUSED,
				 S_ListCompo,
				 askListCompo,
				 Io_Id,
				 &ioIdRec,
				 selOptions,
				 connectNo) == RET_SUCCEED)
	{
		FREE_DYNST(askListCompo, S_ListCompo);
		FREE_DYNST(ioIdRec, Io_Id);
		return(TRUE);
	}

	FREE_DYNST(askListCompo, S_ListCompo);
	FREE_DYNST(ioIdRec, Io_Id);
	return(FALSE);
}

/************************************************************************
*
*   Function           : DBA_LoadSubscriptions()
*
*   Description        : .
*
*   Arguments          :
*
*   Return             :
*
*  Creation Date       : REF4204 - GRD - 000608
*
*************************************************************************/
RET_CODE DBA_LoadSubscriptions(OBJECT_ENUM, 
                               DBA_DYNFLD_STP          inputData,
							   DBA_DYNFLD_STP          **outputData,
							   int                     *rowsNbr,
                               DbiConnectionHelper&    dbiConnHelper)
{
	RET_CODE        retCode = RET_SUCCEED;

	*rowsNbr = 0;
	*outputData = NULL;

	/* Is the subscription active? */
	if (EV_IsSubscriptionActive == FALSE)
	{
		return(RET_SUCCEED);
	}

	/* Is there any subscription for this entity. */
	dbiConnHelper.setFromDbaAccess();
    retCode = dbiConnHelper.dbaSelect(Subscription,
                                      UNUSED,
                                      inputData,
                                      A_Subscription,
                                      outputData,
                                      rowsNbr);
	dbiConnHelper.resetFromDbaAccess();

	return(retCode);
}

/************************************************************************
*
*  Function     : DBA_GetPPSById()
*
*  Description  : Get PPS in hierarchy, if not found call database.
*
*  Arguments    : ppsId           Id of PPS to load
*                 addPpsInHier    Flag to indicate if new pps must be add in hierachy
*	              allocFlg        Flag to determine if the return pps was allocated or not
*		          ppsPtr          Pointer to PPS to load
*                 hierHeadParam   Hierarchy pointer
*
*  Return       : RET_SUCCEED or error code
*
*  Creation     : REF4347 - DED - 001124
*
*************************************************************************/
EXTERN RET_CODE DBA_GetPPSById(ID_T                 ppsId,
							   FLAG_T               addPpsInHierFlg,
							   FLAG_T               *allocFlg,
							   DBA_DYNFLD_STP       *ppsPtr,
							   PTR                  hierHeadParam,
							   int                  getOptions,
							   int                  *allocConn)
{
	DBA_DYNFLD_STP	  getPps=NULL;
	DBA_HIER_HEAD_STP hierHead;

	*allocFlg = FALSE;

	/* Check arguments */
	if (ppsPtr == NULL || allocFlg == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	*ppsPtr = NULL;

	/* Search in hierarchy if possible */
	if (hierHeadParam !=  NULL)
		hierHead = (DBA_HIER_HEAD_STP) hierHeadParam;
	else
		hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();
	if (hierHead != NULL)
	{
		if (DBA_GetRecPtrFromHierById(hierHead, ppsId, A_PtfPosSet, ppsPtr) == RET_SUCCEED &&
			*ppsPtr != NULL)
		{
			return(RET_SUCCEED);
		}
	}

	/* Get record from database */
	if ((getPps=ALLOC_DYNST(S_PtfPosSet))==NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (((*ppsPtr) = ALLOC_DYNST(A_PtfPosSet))==NULL)
	{
		FREE_DYNST(getPps, S_PtfPosSet);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	*allocFlg = TRUE;

	SET_ID(getPps,S_PtfPosSet_Id, ppsId);
	if (DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, getPps, A_PtfPosSet, ppsPtr,
				 getOptions, allocConn) != TRUE)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfPosSet));
		FREE_DYNST((*ppsPtr), A_PtfPosSet);
		*allocFlg = FALSE;
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(getPps, S_PtfPosSet_Id));
		FREE_DYNST(getPps, S_PtfPosSet);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getPps, S_PtfPosSet);

	/* Add in hierarchy if needed */
	if (addPpsInHierFlg == TRUE &&
		hierHead != NULL)
	{
		if (DBA_AddHierRecord(hierHead,
							  *ppsPtr, A_PtfPosSet, TRUE,
							  HierAddRec_ForceInsert) == RET_SUCCEED)
		{
			*allocFlg = FALSE;
		}
	}

	return(RET_SUCCEED);
}

/************************************************************************
*
*   Function           : DBA_GetConstrTemplate
*
*   Description        : Get one constraint template from database
*
*   Arguments          : id                   : Technical identifiant
*                        aConstrTemplateStPtr : the pointer on the constraint template output dyn. struct. array
*                        role                 : the role of the request
*                        getOptions           : can be DBA_SET_CONN, DBA_NO_CLOSE
*                        allocConn            : 1. pointer which will contain the connectNo
*                                               used for the request if getOptions is DBA_NO_CLOSE.
*                                               2. pointer which contain a connection number
*                                               if getOptions is DBA_SET_CONN.
*                        msgStructPtr         : pointer on a structure which will contain
*                                               received messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*  Creation Date       : REF7289 - LJE - 020219
*
*************************************************************************/
RET_CODE DBA_GetConstrTemplate(ID_T					id,
							  DBA_DYNFLD_STP       *aConstrTemplateStPtr,
							  int                  role,
							  int                  getOptions,
							  int                  *allocConn,
							  DBA_ERRMSG_INFOS_STP )
{

	RET_CODE ret=RET_GEN_INFO_NODATA;
	DBA_DYNFLD_STP sConstrTemplateSt=NULL;

	if(id<=0 || aConstrTemplateStPtr == NULL)
		return ret;

	(*aConstrTemplateStPtr) = ALLOC_DYNST(A_ConstrTemplate);
	sConstrTemplateSt       = ALLOC_DYNST(S_ConstrTemplate);

	SET_ID(sConstrTemplateSt, S_ConstrTemplate_Id, id);

	if((ret=DBA_Get2(ConstrTemplate,
					  role,
					  S_ConstrTemplate,
					  sConstrTemplateSt,
					  A_ConstrTemplate,
					  aConstrTemplateStPtr,
					  getOptions,
					  allocConn))!= RET_SUCCEED)
	{
		FREE_DYNST(*aConstrTemplateStPtr, A_ConstrTemplate);
	}

	FREE_DYNST(sConstrTemplateSt, S_ConstrTemplate);

	return ret;
}

/************************************************************************
*
*   Function           : DBA_SelectConstrTemplateElt
*
*   Description        : Select constraint template element from database
*
*   Arguments          : constrTemplateId : Constraint template id
*                        templateEltStTab : the pointer on the output dyn. struct.
*                                           array pointer of constraint template element
*                        constrTemplateNb : the returned row number, if specified
*                        role             : the role of the request
*                        SelOptions       : indicate many info about the request (ALLOC, FETCH, ...).
*                        maxRows          : pointer which contain the desirated (if any) or result rows number.
*                        allocConn        : the connection number allocated
*                        msgStructPtr     : message structure pointer
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*  Creation Date       : REF7289 - LJE - 020219
*
*************************************************************************/
RET_CODE DBA_SelectConstrTemplateElt(ID_T                     constrTemplateId,
									 DBA_DYNFLD_STP         **templateEltStTab,
									 int                     *constrTemplateNb,
									 int                      role,
									 int                      selOptions,
									 int                      maxRows,
									 int                     *allocConn,
									 DBA_ERRMSG_INFOS_STP     )
{

	RET_CODE ret=RET_GEN_INFO_NODATA;
	DBA_DYNFLD_STP sTemplateEltSt=NULL;

	if(constrTemplateId<=0 || templateEltStTab == NULL)
		return ret;

	sTemplateEltSt = ALLOC_DYNST(S_TemplateElt);

	SET_ID(sTemplateEltSt, S_TemplateElt_ConstrTemplateId, constrTemplateId);
	SET_ENUM(sTemplateEltSt, S_TemplateElt_ParamNatEn, TemplateEltParamNat_All);

	if((ret=DBA_Select2(TemplateElt,
						role,
						S_TemplateElt,
						sTemplateEltSt,
						A_TemplateElt,
						templateEltStTab,
						selOptions,
						maxRows,
						constrTemplateNb,
						allocConn)) != RET_SUCCEED)
	{
		FREE(*templateEltStTab);
	}

	FREE_DYNST(sTemplateEltSt, S_TemplateElt);

	return ret;
}

/************************************************************************
*
*   Function           : DBA_GetConstrTemplateAll
*
*   Description        : Get all info of contraint template from database
*
*   Arguments          : constrTemplateId     : Constraint template id
*                        constrTemplateSt     : Constraint template structur
*                        constrTemplateScpt   : Constraint template script definition
*                        constrTemplateEltTab : All template elements array
*                        constrTemplateNb     : Template elements number
*                        maxRows              : Pointer which contain the desirated (if any)
*                                               or result rows number.
*                        allocConn            : The connection number allocated
*                        msgStructPtr         : Message structure pointer
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Return             : RET_SUCCEED
*
*  Creation Date       : REF7289 - LJE - 020219
*
*************************************************************************/
RET_CODE DBA_GetConstrTemplateAll(ID_T                     constrTemplateId,
								  DBA_DYNFLD_STP          *constrTemplateSt,
								  DBA_DYNFLD_STP          *constrTemplateScpt,
								  DBA_DYNFLD_STP         **constrTemplateEltTab,
								  int                     *constrTemplateNb,
								  int                      maxRows,
								  int                     *allocConn,
								  DBA_ERRMSG_INFOS_STP     )
{

	DICT_ATTRIB_STP attribSt;
	RET_CODE       ret=RET_GEN_INFO_NODATA;

	/* Test parameter and get the constraint template structur */
	if( constrTemplateId     <= 0    ||
		constrTemplateSt     == NULL ||
		constrTemplateScpt   == NULL ||
		constrTemplateEltTab == NULL ||
		constrTemplateNb     == NULL ||
		(ret=DBA_GetConstrTemplate(constrTemplateId, constrTemplateSt, UNUSED, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		return ret;
	}

	/***** SELECT SCRIPT BUFFERS FOR THE CONSTRAINT DEFINITION *****/
	if (*constrTemplateScpt == NULL)
	{
		*constrTemplateScpt = ALLOC_DYNST(A_ScriptDef);

		DBA_SearchAttribSqlName(ConstrTemplate, "script_def", &attribSt);

		SET_DICT((*constrTemplateScpt), A_ScriptDef_AttrDictId, attribSt->attrDictId);
		SET_ID((*constrTemplateScpt), A_ScriptDef_ObjId, constrTemplateId);
		SET_ENUM((*constrTemplateScpt),A_ScriptDef_NatEn, 0);

		/* Get constraint template script definition */
		if ((ret=DBA_Get2(ScriptDef,
						  UNUSED,
						  A_ScriptDef,
						  (*constrTemplateScpt),
						  A_ScriptDef,
						  constrTemplateScpt,
						  UNUSED,
						  allocConn)) != RET_SUCCEED )
		{
			FREE_DYNST(*constrTemplateSt, A_ConstrTemplate);
			FREE_DYNST(*constrTemplateScpt, A_ScriptDef);
			return ret;
		}

	}

	/* Select all template elements of current constraint template */
	if ((ret=DBA_SelectConstrTemplateElt(constrTemplateId,
										 constrTemplateEltTab,
										 constrTemplateNb,
										 UNUSED,
										 UNUSED,
										 maxRows,
										 allocConn)) != RET_SUCCEED)
	{
		FREE_DYNST(*constrTemplateSt, A_ConstrTemplate);
		FREE_DYNST(*constrTemplateScpt, A_ScriptDef);
		return ret;
	}

	return ret;
}

/************************************************************************
*
*   Function           : DBA_GetConstrInfo
*
*   Description        : Get contraint parameter from database
*
*   Arguments          :
*                        maxRows       : pointer which contain the desirated (if any)
*                                        or result rows number.
*                        allocConn     : the connection number allocated
*                        msgStructPtr  : message structure pointer
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Return             : RET_SUCCEED
*
*  Creation Date       : REF7289 - LJE - 020221
*
*************************************************************************/
RET_CODE DBA_GetConstrInfo(DICT_T                   dimConstrDictId,
						   ID_T                     id,
						   ID_T                    *constrTemplateIdPtr,
						   DBA_DYNFLD_STP         **constrParamTab,
						   int                     *constrParamNb,
						   int                      maxRows,
						   int                     *allocConn,
						   DBA_ERRMSG_INFOS_STP     )
{

	RET_CODE       ret=RET_GEN_INFO_NODATA;
	DBA_DYNFLD_STP constrParamSt=NULL, sConstrSt, aConstrSt;
	DBA_DYNST_ENUM sDynEnum, aDynEnum;
	int            idFld, templateIdFld;
	OBJECT_ENUM    constrObject=NullEntity;


	if(id                <= 0 ||
	   dimConstrDictId   <= 0 ||
	   constrParamTab    == NULL ||
	   constrParamNb     == NULL ||
	   DBA_GetObjectEnum(dimConstrDictId, &constrObject) == FALSE)
		return ret;


	/* REF8844 - LJE - 030415 */
	if (constrObject == StratElt )
	{
		sDynEnum      = S_StratElt;
		aDynEnum      = A_StratElt;
		idFld         = S_StratElt_Id;
		templateIdFld = A_StratElt_ConstrTemplate;
	}
	else if (constrObject == TradConstr )
	{
		sDynEnum      = S_TradConstr;
		aDynEnum      = A_TradConstr;
		idFld         = S_TradConstr_Id;
		templateIdFld = A_TradConstr_ConstraintTemplateId;
	}
	else
	{
		return ret;
	}

	aConstrSt = ALLOC_DYNST(aDynEnum);
	sConstrSt = ALLOC_DYNST(sDynEnum);

	SET_ID(sConstrSt, idFld, id);

	/* Get current constraint (StratElt or TradConstr) structur from database */
	if((ret=DBA_Get2(constrObject,
					 UNUSED,
					 sDynEnum,
					 sConstrSt,
					 aDynEnum,
					 &aConstrSt,
					 UNUSED,
                     allocConn)) != RET_SUCCEED)
	{
		FREE_DYNST(aConstrSt, aDynEnum);
        FREE_DYNST(sConstrSt, sDynEnum);
		return RET_GEN_INFO_NODATA;		/* PMSTA-47925 - KKC - 220221 */
	}

	FREE_DYNST(sConstrSt, sDynEnum);

	/* If constraint template id is NULL, nothing to do */
	if(IS_NULLFLD(aConstrSt, templateIdFld) == TRUE)
	{
		FREE_DYNST(aConstrSt, aDynEnum);
		return RET_GEN_INFO_NOACTION;
	}

	constrParamSt = ALLOC_DYNST(A_ConstraintParameter);

	SET_DICT(constrParamSt, A_ConstraintParameter_DimConstraintDictId, dimConstrDictId);
	SET_ID(constrParamSt, A_ConstraintParameter_ConstrObjId, id);


	/* Select all constraint parameters of current constraint from database */
	if((ret=DBA_Select2(ConstraintParameter,
						UNUSED,
						A_ConstraintParameter,
						constrParamSt,
						A_ConstraintParameter,
						constrParamTab,
						UNUSED,
						maxRows,
						constrParamNb,
						allocConn)) != RET_SUCCEED)
	{
		FREE(*constrParamTab);
		FREE_DYNST(constrParamSt, A_ConstraintParameter);

		return ret;
	}

	if (constrTemplateIdPtr != NULL)
		*constrTemplateIdPtr = GET_ID(aConstrSt, templateIdFld);

    FREE_DYNST(aConstrSt, aDynEnum);
	FREE_DYNST(constrParamSt, A_ConstraintParameter);

	return ret;
}

/************************************************************************
*
*   Function           : DBA_GetObjDefValScptDefByAttr
*
*   Description        : Load script defintion of nature SCRIPTDEF_ObjDefVal for one attribute
*
*   Arguments          : Attribute for which defintion must be loaded
*
*   Return             : the script defintion
*
*  Creation Date       : PMSTA-28705 - DDV - 180219
*
*************************************************************************/
RET_CODE DBA_GetObjDefValScptDefByAttr(OBJECT_ENUM objectEnum,
                                       SYSNAME_T   sqlname,
                                       ID_T        recId,
                                       char        **scptDef)
{
    DICT_ATTRIB_STP     attribSt=NULL;
    DBA_DYNFLD_STP		aScptDefStp = NULLDYNST;
    char                *scptDefPtr=NULL;

    if (scptDef == NULL)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		                "DBA_GetObjDefValScptDefByAttr", "scptDef is mandatory");
	    return(RET_GEN_ERR_INVARG);
    }

    *scptDef = NULL;

	if ((aScptDefStp = ALLOC_DYNST(A_ScriptDef)) != NULLDYNST)
    {
		DBA_SearchAttribSqlName(objectEnum, sqlname, &attribSt);

        if (attribSt != NULL)
        {
            DbiConnectionHelper dbiConnHelper;

		    SET_DICT(aScptDefStp, A_ScriptDef_AttrDictId, attribSt->attrDictId);
		    SET_ID(aScptDefStp, A_ScriptDef_ObjId, recId);
		    SET_ENUM(aScptDefStp, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

    		if (dbiConnHelper.dbaGet(ScriptDef, UNUSED, aScptDefStp, &aScptDefStp) == RET_SUCCEED)
	    	{
                if ((scptDefPtr = GET_STRING(aScptDefStp, A_ScriptDef_Def)) != NULL &&
                     strlen(scptDefPtr) > 0)
                {
                    if ((*scptDef = (char *) CALLOC(strlen(scptDefPtr) + 1, sizeof(char))) != NULL)
                    {
                        strcat(*scptDef, scptDefPtr);
                		FREE_DYNST(aScptDefStp, A_ScriptDef);
                        return(RET_SUCCEED);
                    }
                }
            }
		}
		FREE_DYNST(aScptDefStp, A_ScriptDef);
    }
    return(RET_GEN_INFO_NODATA);
}


/************************************************************************
*
*   Function           : DBA_UpdateServerPoolCompo
*
*   Description        : update the server pool compo cache if the same configured fin server pool is modified
*
*   Arguments          : serverId
*
*   Return             :
*
*  Creation Date       :
*
*************************************************************************/
void DBA_UpdateServerPoolCompo(ID_T serverId)
{
	DBA_DYNFLD_STP shSrvConnectStp = NULL, srvConnectStp = NULL;
	DbiConnectionHelper dbiConnHelper;
	std::string poolName;
	MemoryPool mp;

	/*   Financial Server Pool */
	if ((srvConnectStp = mp.allocDynst(FILEINFO, A_ServConnect)) != NULL &&
		(shSrvConnectStp = mp.allocDynst(FILEINFO, S_ServConnect)) != NULL)
	{
		SET_ID(shSrvConnectStp, S_ServConnect_Id, serverId);
		if (dbiConnHelper.dbaGet(ServConnect, UNUSED, shSrvConnectStp, &srvConnectStp) == RET_SUCCEED)
		{
			poolName = GET_SYSNAME(srvConnectStp, A_ServConnect_ServerName);

			/* Get a free connection */
			DbiConnectionHelper	newConnHelper(FinServer);

			newConnHelper.updateServerPoolCfg(poolName);
		}
	}
}

/************************************************************************
**   END  dbalib02.c                                                   **

*************************************************************************/

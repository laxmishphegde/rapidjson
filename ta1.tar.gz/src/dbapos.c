/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAPOS_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include	    "unidef.h"     /* Mandatory */
#include	       "gen.h"
#include	       "dba.h"
#include	       "fin.h"
#include	      "date.h"
#include	       "cmp.h"
#include	       "tls.h"
#include	      "hier.h"
#include	      "scpt.h"
#include	    "scptyl.h"
#include	       "ope.h"
#include	    "finsrv.h"
#include	      "serv.h"
#include	    "scelib.h"
#include	   "dbaexec.h"
#include	  "srvperfa.h"
#include       "dbaperf.h" /* REF9125 - MCA - 030902 */
#include "dbiconnection.h"
#include "ddlgen.h"
#include "dbisqlexecbyblock.h" 		/* PMSTA-20159 - TEB - 151110 */
#include "dbaperfa.h"
#include "taxlotprocess.h"          /* PMSTA-34116 - 220219 - vkumar */

/************************************************************************
**      External entry points
**
** DBA_GenericInstr() 		    Create derivated instr depending on received instr (mm, swap, ...).
** DBA_LoadPos()                Load positions hierarchy.
** DBA_UpdExtPosFld() 		    Update loaded extended position.
** DBA_UpdPosValFld() 		    Transform Ref_* fields to current reference currency.
** DBA_UpdFwdTermInfo() 	    Read term event at specified date and update instr fields.
** DBA_SelectLastPtfSynth()     Select last portfolio synthetics.
** DBA_SelectLastPerfData()     Select last portfolio performance data.
** DBA_SelectPtfIdByDomain()    Select ptf identifiers depending on domain informations.
** DBA_LoadPosHierLnkAndUpd()	Make hierarchy links and update ExtPos records
** DBA_SelectIncomeOperForValo()Select income operation for given portfolio(s)/instrument(s)
** DBA_LoadPosHierCreate()		Create a hierDefNbr hierarchy and distribute loaded data.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_CheckGenericForward() 		Check if position forward instrument is already created.
** DBA_FctLnkFirst() 			    Set or unset "first" links depending on links state struct
** DBA_FctLnkInitState() 		    According to function, update links state structure
** DBA_FctLnkOthers() 			    Set "others" links depending on links state structure.
** DBA_FilterGenericInstr() 		Filter generic instrument (use identifier value)
** DBA_GenericFwdMMSwap() 	        Create deriv. instr. depending on received forward and mm
** DBA_LoadPosPtfInstrDimension()	Init some table according to ptf and instr. dimension.
** DBA_LoadDomOpTable()	            Init #dom_oper table for operation search
** DBA_LoadPosDropTempTables()		Send a Drop request to the server. Drop temporary tables.
** DBA_ReturnEliminate()            Eliminate useless positions for return
** DBA_LoadVectorIdForUMEX()        Init #vector_id table for unmatched executions search load.
** DBA_LoadUMEX()
*************************************************************************/

/******************************************************************************
** HOW MODIFY LOADPOS PROCESS :
** ----------------------------
**
** NEW LINK FOR A FUNCTION :
** - set link flag to TRUE in DBA_FctLnkInitState()
**
** NEW LINK :
** - add a flag in structure DBA_FCTLNK_ST
** - add a DBA_SetHierLnkUsed() call in DBA_FctLnkFirst() if link is used by one
**   other link or used by DBA_UpdExtPosFld() function, elsewhere in DBA_FctLnkOthers().
**   Eg : ExtPos_Main_ExtPos_Ext use ExtPos_A_Instr_Ext and ExtPos_A_Instr_Ext is
**        set and unset by DBA_FctLnkFirst()
**   (add new link in hierdef.c, dbadyn.c descdyn.h)
**
** NEW FUNCTION :
** - add a case in DBA_FctLnkInitState() for links definition and in DBA_LoadPos() for select.
**
*******************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

extern int EV_NoPMSTA6500;         /* PMSTA06500 - DDV - 080425 */

/* --------------------------------------------------------------------------- */
/* links state structure (one flag for each possible link)                     */
/* is initialized by DBA_FctLnkInitState() (TRUE - link is set and done)       */
/* and used by DBA_FctLnkFirst() and DBA_FctLnkOthers() for set and make links */
/* --------------------------------------------------------------------------- */
typedef struct {
	char A_AccPlanElt_A_FundValElt;
	char A_Instr_Cond_A_Instr;
	char A_Ptf_HierPtf;
	char ExtOp_A_Instr;
	char ExtOp_A_Ptf;
	char ExtOp_Flow;    /* REF2669 - 980817 - DDV */
	char Flow_ExtOp;    /* REF2669 - 980817 - DDV */
	char Flow_A_Instr;  /* REF2669 - 980817 - DDV */
	char ExtPos_A_AccPlanElt;
	char ExtPos_A_Instr;
	char ExtPos_A_Ptf;
	char ExtPos_AccrInter_ExtPos;
	char ExtPos_Acct2_ExtPos;
	char ExtPos_Acct3_ExtPos;
	char ExtPos_Acct_ExtPos;
	char ExtPos_AdjustSec_ExtPos;
	char ExtPos_Adjust_ExtPos;
	char ExtPos_Attach_ExtPos;
	char ExtPos_BVAdjLoss_ExtPos;
	char ExtPos_BVAdjProfit_ExtPos;
	char ExtPos_BalPos_ExtPos;
	char ExtPos_ChildPtf;
	char ExtPos_Close_A_Op;
	char ExtPos_CntPty_ExtPos;
	char ExtPos_Instr_ExtPos;
	char ExtPos_Locking_ExtPos;
	char ExtPos_Main_ExtPos;
	char ExtPos_Open_A_Op;
	char ExtPos_PosVal;
	char ExtPos_PtfPosSet;
	char ExtPos_ToBalPos_ExtPos;
	char ExtPos_ToInstr_ExtPos;
    char A_PtfFreq_A_Ptf;       /* REF4306 - CSY - 000221 */
    char A_InstrFreq_A_Instr;   /* REF4306 - CSY - 000221 */
    char A_CurrFreq_A_Curr;     /* REF4306 - CSY - 000221 */
    char A_ThirdFreq_A_Third;   /* REF4306 - CSY - 000221 */
    char A_Ptf_A_ChildrenPtf;   /* REF4306 - CSY - 000321 */
	char A_Ptf_A_HierChildrenPtf;   /* PMSTA02013 - RAK - 071112 */
	char A_ComplianceChronoFreq_A_Compl;   /* PMSTA-22458 - cashwini - 160502 */
    char PosVal_ExtPos;         /* REF5442 - DDV - 010205 */
	char sortFlg;			    /* Sort before make "others" links  */
	char updPosValFlg;		    /* Call function DBA_UpdPosValFld() */
	char makeLnkFlg;		    /* Call DBA_MakeLinks() after DBA_FctLnkFirst() or */
					            /* DBA_FctLnkOthers()                              */
    char A_PerfAttrib_Global;   /* REF7758 - LJE - 020927 */
    char A_PerfAttrib_Bench;    /* REF7758 - LJE - 021030 */
    char A_PerfAttrib_Parent;   /* REF7758 - LJE - 021030 */
    char A_ExtRetAnalysis_Global;/* REF7758 - LJE - 020927 */
    char A_ExtRetAnalysis_Parent;/* REF7758 - LJE - 020927 */
    char A_ExtRetAnalysis_Bench; /* REF7758 - LJE - 021030 */
    char A_StandardPerf_Bench; /* REF7758 - LJE - 021030 */
	char A_Instr_Parent;         /*PMSTA-32106 -NRAO 180904*/
	char A_Instr_Child;          /*PMSTA-32106 -NRAO 180904*/
	char A_TaxLot_A_TaxLotInitial_Ext;   /* PMSTA-34116 - 220219 - vkumar */

} DBA_FCTLNK_ST, *DBA_FCTLNK_STP; /* REF182 - RAK - 970915 */

STATIC int 	DBA_FilterGenericInstr(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
		    DBA_FilterPosGenericInstr(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 *//*REF2950 - SSO - 981029 */
            DBA_FilterPosNoInstrExt(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse),
            DBA_CmpExtPosInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2),
            FIN_CmpExtOpByOpId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
            FIN_CmpExecByOrderId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);


STATIC void DBA_FctLnkInitState(DBA_DYNFLD_STP, DBA_FCTLNK_STP);

STATIC RET_CODE DBA_CheckGenericForward(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*),
                DBA_FctLnkFirst(DBA_HIER_HEAD_STP, DBA_FCTLNK_STP, char, DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* REF182 - RAK - 970915 */
                DBA_FctLnkOthers(DBA_HIER_HEAD_STP, DBA_FCTLNK_STP),
                DBA_UpdBalPosForGenInstr(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, PTR), /*REF2950 - SSO - 981029 */
                /* DBA_PriceValidity(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int), */ /* PMSTA-34990 - CHU - 190325 : Made extern */
                DBA_LoadDomOperTable(DBA_DYNFLD_STP, DbiConnection&), /* REF2467 - DDV - 991224 */
                DBA_ValoEliminate(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, const DBA_DYNST_ENUM**, int, DBA_HIER_HEAD_STP),
                DBA_UpdExtPosNatPerfo(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,DBA_DYNFLD_STP,DATETIME_T,DATETIME_T,DBA_FCTLNK_STP),        /* REF5285 - DDV - 010221 */
                DBA_CheckExtPosInstr(DBA_HIER_HEAD_STP),
                DBA_UpdExtPosNatAccHist(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_FCTLNK_STP); /* REF5285 - DDV - 010221 */

STATIC DBA_DYNFLD_STP DBA_GenericFwdMMSwap(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T);

/* REF4611 - RAK - 000504 */
STATIC int 	DBA_FilterValoPositions(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
			DBA_FilterOpHistPositions(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */

STATIC RET_CODE DBA_LoadVectorIdForUMEX(DBA_DYNFLD_STP,int);        /* REF9764 - TEB - 040107 */
STATIC RET_CODE DBA_LoadVectorIdForCaseInquiry(DBA_DYNFLD_STP,DbiConnection&); /* PMSTA07121 - DDV - 090311 */
STATIC RET_CODE DBA_LoadUMEX(DBA_HIER_HEAD_STP *, DBA_DYNFLD_STP, DbiConnection&);           /* REF9764 - TEB - 040107 */

/* < REF9764 - CHU - 040116 */
STATIC RET_CODE	DBA_LoadExtTransactionInHierForSMatchO(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *,
													   int, DBA_DYNFLD_STP *, int),
				DBA_LoadVectorIdWithMatchingOrders(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int *);
/* REF9764 - CHU - 040116 > */
STATIC RET_CODE	DBA_LoadRecordsForSMatchO(DBA_HIER_HEAD_STP	,DBA_DYNFLD_STP **,int *,
                                          DBA_DYNFLD_STP **,int*,int*); /* REF9764 - TEB - 040122 */

STATIC RET_CODE DBA_VirtualInstr(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP); /* PMSTA-18096 - LJE - 140620 */


/************************************************************************
**
**  Function    :   DBA_CheckGenericForward()
**
**  Description :   Check if position forward instrument is already created
**
**  Arguments   :   hierHeadPtr hierarchy header pointer
**                  pos         pointer on position
**                  genInstr    generic instrument pointer to update
**
**  Return      :   RET_SUCCEED if forward must be create,
**		            RET_DBA_INFO_EXIST if forward already exist
**		            or error code
**
*************************************************************************/
STATIC RET_CODE DBA_CheckGenericForward(DBA_HIER_HEAD_STP hierHead,
				                        DBA_DYNFLD_STP    pos,
				                        DBA_DYNFLD_STP    *genInstrPtr)
{
	RET_CODE         ret;
	DBA_DYNFLD_STP   *extractRec=(DBA_DYNFLD_STP*)NULL;
	char             extractOk;
	int              i, recNbr;
	DATETIME_T       begDate, endDate;


	DBA_DYNFLD_STP   instrPtr = NULLDYNST;

	/* PMSTA-51476 - DDV - 221216 - For instrument having SubNat_FXFwd_TwoLegsAgainsPtfCurr, new instrument will be created in function FIN_CreateFXSplitLegs */
	if (GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext) != NULL &&
		((instrPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext))) != NULLDYNST) &&
		GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr &&
        GET_FLAG(instrPtr, A_Instr_GenericFlg) == FALSE)
	{
		return(RET_DBA_INFO_EXIST);
	}

	extractOk = FALSE;

	if ((ret = DBA_ExtractHierEltRec(hierHead, A_Instr,
		                            FALSE, DBA_FilterGenericInstr, NULL,
				                    &recNbr, &extractRec)) == RET_SUCCEED)
	{
	    begDate = GET_DATETIME(pos, ExtPos_BegDate);
   	    endDate = GET_DATETIME(pos, ExtPos_ExpirDate);

	    extractOk = TRUE;
	    for (i=0; i<recNbr && ret == RET_SUCCEED; i++)
	    {
		    if (GET_ID(extractRec[i], A_Instr_ParentInstrId) ==
		        GET_ID(pos, ExtPos_InstrId) &&
		        GET_DATE(extractRec[i], A_Instr_BeginDate) == begDate.date &&
	    	    GET_DATE(extractRec[i], A_Instr_EndDate) == endDate.date &&
		        CMP_PRICE(GET_PRICE(extractRec[i], A_Instr_RedempPrice), GET_PRICE(pos, ExtPos_Price)) == 0 &&
		        CMP_PRICE(GET_PRICE(extractRec[i], A_Instr_RedempQuote), GET_PRICE(pos, ExtPos_Quote)) == 0) /* REF7475 - YST - 020516 */
	        {
			    *genInstrPtr = extractRec[i];
			    ret = RET_DBA_INFO_EXIST;
	        }
	    }
	}

	/* Only array pointer, copy flag is FALSE  */
	if (extractOk == TRUE)
		FREE(extractRec);

	return(ret);   /* RET_SUCCEED, RET_DBA_INFO_EXIST or error code */
}


/************************************************************************
**
**  Function    :   DBA_CreateCashLegInstr()
**
**  Description :   Create forward instrument for cash leg
**
**  Arguments   :   hierHeadPtr hierarchy header pointer
**                  pos         pointer on position
**
**  Return      :   RET_SUCCEED if forward must be create,
**		            RET_DBA_INFO_EXIST if forward already exist
**		            or error code
**
*************************************************************************/
RET_CODE DBA_CreateCashLegInstr(DBA_HIER_HEAD_STP  hierHead,
                                DBA_DYNFLD_STP     domainPtr,
                                DBA_DYNFLD_STP     cashInstr,
                                DBA_DYNFLD_STP     mainInstr,
                                DBA_DYNFLD_STP    *genInstrPtr) 
{
    RET_CODE         ret = RET_DBA_INFO_EXIST;
    DBA_DYNFLD_STP   newInstr=NULL, *eltTab=NULL, instrRiskOrigStp;
    ID_T             instrId;
    DICT_FCT_ENUM    fct, initFct;
    int              eltNbr, i;
	FIELD_IDX_T		 mainInstrIdFld = 0; /* PMSTA-18477 - CHU - 140814 */

    fct = (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId);
    initFct = (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_InitialFctDictId);

	/* < PMSTA-18477 - CHU - 140814 */
	if (GET_ID(mainInstr, A_Instr_Id) > (ID_T)0)
	{
		mainInstrIdFld = A_Instr_Id;
	}
	else
	{
		mainInstrIdFld = A_Instr_ParentInstrId;
	}
	/* > PMSTA-18477 - CHU - 140814 */

    ret = DBA_ExtractHierEltRecByIndexKey(hierHead,
                                          A_InstrRiskOrig,
                                          A_InstrRiskOrig_RiskOriginInstrId,
                                          mainInstr[mainInstrIdFld],/* PMSTA-18477 - CHU - 140814 */
                                          FALSE,
                                          NULL,
                                          NULL,
                                          NULL,
                                          FALSE,
                                          &eltNbr,
                                          &eltTab);

    if (ret == RET_SUCCEED && eltNbr > 0)
    {
        for (i = 0; i < eltNbr; i++)
        {
            if (CMP_DYNFLD(eltTab[i], cashInstr, A_InstrRiskOrig_InstrId, A_Instr_Id, IdType) == 0)
            {
                ret = DBA_GetRecPtrFromHierById(hierHead,
                                                GET_ID(eltTab[i], A_InstrRiskOrig_Id),
                                                A_Instr,
                                                &newInstr);
                break;
            }
        }
    }

    FREE(eltTab);

    if (ret != RET_SUCCEED || newInstr == NULL || IS_NULLFLD(newInstr, A_Instr_Id) == TRUE)
    {
        if ((newInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        if (fct == DictFct_OnLineMktValuePL ||
            (fct == DictFct_Return && GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_Instrument) ||
			(fct == DictFct_Return && (PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_OnLineMktValPL))
        {
            if ((ret = DBA_AddHierRecord(hierHead, newInstr, A_Instr, FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
            {
                FREE_DYNST(newInstr, A_Instr);
                return(ret);
            }
            instrId = ID_T_MAX - GET_ID(newInstr, A_Instr_Id);

            DBA_DelAndFreeHierEltRec(hierHead, A_Instr, newInstr);
            if ((newInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            DBA_DYNFLD_STP riskOrigStp;
            if ((riskOrigStp = ALLOC_DYNST(A_InstrRiskOrig)) == NULLDYNST)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
            SET_ID(riskOrigStp, A_InstrRiskOrig_InstrId, GET_ID(cashInstr, A_Instr_Id));
            SET_ID(riskOrigStp, A_InstrRiskOrig_RiskOriginInstrId, GET_ID(mainInstr, mainInstrIdFld)); /* PMSTA-18477 - CHU - 140814 */

            if ((ret = DBA_Get2(InstrRiskOrig, UNUSED, A_InstrRiskOrig, riskOrigStp, A_InstrRiskOrig, &riskOrigStp, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                FREE_DYNST(riskOrigStp, A_InstrRiskOrig);
                return(ret);
            }

            instrId = GET_ID(riskOrigStp, A_InstrRiskOrig_Id);

            FREE_DYNST(riskOrigStp, A_InstrRiskOrig);
        }

        COPY_DYNST(newInstr, cashInstr, A_Instr);
        SET_ID(newInstr, A_Instr_RiskOrigInstrId, GET_ID(mainInstr, mainInstrIdFld)); /* PMSTA-18477 - CHU - 140814 */
        SET_ID(newInstr, A_Instr_ParentInstrId, GET_ID(cashInstr, A_Instr_Id));
        SET_ID(newInstr, A_Instr_Id, instrId);

        if ((ret = DBA_AddHierRecord(hierHead, newInstr, A_Instr, FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
        {
            FREE_DYNST(newInstr, A_Instr);
            return(ret);
        }

        if ((instrRiskOrigStp = ALLOC_DYNST(A_InstrRiskOrig)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        SET_ID(instrRiskOrigStp, A_InstrRiskOrig_RiskOriginInstrId, GET_ID(mainInstr, mainInstrIdFld));/* PMSTA-18477 - CHU - 140814 */
        SET_ID(instrRiskOrigStp, A_InstrRiskOrig_InstrId, GET_ID(cashInstr, A_Instr_Id));
        SET_ID(instrRiskOrigStp, A_InstrRiskOrig_Id, instrId);

        if ((ret = DBA_AddHierRecord(hierHead, instrRiskOrigStp, A_InstrRiskOrig, FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
        {
            FREE_DYNST(newInstr, A_Instr);
            return(ret);
        }
    }

	/* PMSTA-51476 - DDV - 230124 - Set extension to optimize access */
	if (GET_ID(mainInstr, A_Instr_Id) < 0)
	{
		SET_ID(newInstr, A_Instr_RiskOrigGenInstrId, GET_ID(mainInstr, A_Instr_Id));

		DBA_DYNFLD_STP      mainInstrExt = NULLDYNST;

		if (IS_NULLFLD(newInstr, A_Instr_RiskOrigGenInstr_Ext) == TRUE ||
			GET_EXTENSION_PTR(newInstr, A_Instr_RiskOrigGenInstr_Ext) == NULL ||
			(mainInstrExt = *GET_EXTENSION_PTR(newInstr, A_Instr_RiskOrigGenInstr_Ext)) == NULLDYNST ||
			mainInstrExt != mainInstr)
		{
			DBA_ForceLink(hierHead, A_Instr, A_Instr_RiskOrigGenInstr_Ext, newInstr, mainInstr);
		}
	}

	*genInstrPtr = newInstr;
    return(RET_DBA_INFO_EXIST);
}

/************************************************************************
**  Function             : DBA_LoadPosInitBeforeMultiSelect()
**
**  Description          : Initialize some stuff before MultiSelect for LoadPos
**
**  Arguments            : domainPtr      domain arguments pointer
**                         argHierHeadPtr hierarchy pointer
**                         connectNo      pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF10744 - CHU - 041111
**
**  Modif.		         :
**
*************************************************************************/
STATIC RET_CODE DBA_LoadPosInitBeforeMultiSelect(DBA_DYNFLD_STP	domainPtr,
                                                 DBA_HIER_HEAD_STP *hierHeadPtr,
                                                 DbiConnection& dbiConn,
                                                 FLAG_T			*fromDateModif,
                                                 DATETIME_T		*domTmpFromDate,
                                                 FLAG_T			*tillDateModif,
                                                 DATETIME_T		*domTmpTillDate)
{
    RET_CODE ret = RET_SUCCEED; /* PMSTA-26142 CMILOS 211019 */
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

	switch (GET_ID(domainPtr, A_Domain_FctDictId))
	{
	case DictFct_Journal:
		{
			int            checkDays = 0;
			DATETIME_T     tmpDate;

			/* Select Operations, positions, portfolios and instruments */

			/* BEGIN - DVP063 - 960521 - XDI */
			/* Compute loading dates */
			/* if from_d == reference_d => load from */
			/* (from_d - EVENT_CHECK_DAYS) to till_d */
			/* else load from from_d to reference_d  */
			if (GET_DATE(domainPtr, A_Domain_InterpFromDate) ==
					GET_DATE(domainPtr, A_Domain_CalcRefDate))
			{
				*fromDateModif = TRUE;
				GEN_GetApplInfo(ApplEvtGenCheckDays, &checkDays);
				*domTmpFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
				tmpDate.date = DATE_Move((*domTmpFromDate).date, (-1) * CAST_INT(checkDays), Day);
				tmpDate.time = 0;		/* BUG452 - 970807 - XMT */
				SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

			}

			/*REF4145 - CSY - 991124 : for a journal, the load is always untill the ref date (even if from_d == ref_d) */
			if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_Journal)
			{
				*tillDateModif = TRUE;
				*domTmpTillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
				tmpDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
				SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);
			}
			/* END - DVP063 - 960521 - XDI */
		}
		break;

	case DictFct_PerformanceAnalysis:
		{
			/* Load all data define by domain, define risk free and benchmark to use.
			   Load all this additional data */

      /* WEALTH-5157 - Lalby - 08032024 - MergeTWRDetail*/
      /* MergeTWRDetail - other than Intermediate (From Parent/None) force to process almost same as Intermediate way .
         Except ext_ret , perfattrib creations and loading of the positions . 
         Load hierarchy-from parent/none behaviour is achieved by refering the - A_Domain_OrigLoadHierFlg */

      SET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg, GET_ENUM(domainPtr, A_Domain_LoadHierFlg));
      if (static_cast<PTFCONSRULE_ENUM> GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
          (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_None ||
           GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_FromParent))
      {
          SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
      }

            if ((ret = DBA_LoadInitialDataForPAA(hierHeadPtr, domainPtr, dbiConn)) != RET_SUCCEED) /* PMSTA-26142 CMILOS 211019 */
                break;

			if(GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TSLDimPort) /* PMSTA12427-CHU-110725 */
			{
				/* Fill #dom_psp temporary table */
				DBA_LoadDomPspTable(hierHeadPtr, domainPtr, dbiConnHelper);
			}
		}
		break;

	case DictFct_CaseInquiry:			/* PMSTA07121 - DDV - 090311 */
	{
		DATETIME_T      tmpDate;

        if ((ret = DBA_LoadVectorIdForCaseInquiry(domainPtr, dbiConn)) != RET_SUCCEED) /* PMSTA-26142 CMILOS 211019 */
            break;

		/* From and Till date are not mandatory from domain, */
		/* but they must be define for load procedure sel_exd_position */
		tmpDate.date = MAGIC_END_DATE;
		tmpDate.time = 0;

		if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
			SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

		if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == TRUE)
			SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);

	}
	break;

	default:
		break;
	}

    return ret; /* PMSTA-26142 CMILOS 211019 */
}

/************************************************************************
**  Function             : DBA_CallMultiSelectForLoadPos()
**
**  Description          : Call MultiSelect2 for LoadPos function (generic)
**
**  Arguments            : role	        the role of the request
**                         domainPtr    domain arguments pointer
**                         outputStLst  pointer on the output dynamic struct. format list
**                         data         pointer on output dynamic structures array pointer
**                         rows         pointer on result rows number for each dynStType
**                         connectNo    pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF10744 - CHU - 041111
**
**  Modif.		         : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
RET_CODE DBA_CallMultiSelectForLoadPos(int					role,
											  DBA_DYNFLD_STP		domainPtr,
											  const DBA_DYNST_ENUM	**outputStLst,
											  DBA_DYNFLD_STP		**data,
											  int					*rows,
											  DbiConnection&        dbiConn)
{
	RET_CODE		ret			= RET_SUCCEED;
	DBA_DYNST_ENUM	curDynStEn	= NullDynSt;
	DBA_DYNFLD_STP	currDomain	= NULL;

	if (GET_ID(domainPtr, A_Domain_FctDictId)!=DictFct_PerformanceAnalysis)
	{
		curDynStEn = A_Domain;
		currDomain = domainPtr;
	}

	if (DBA_MultiSelect2(FinAnalysis,
						 role,
                         curDynStEn,
						 currDomain,
					     outputStLst,
						 data,
		        	     DBA_SET_CONN | DBA_NO_CLOSE,
						 UNUSED,
                         rows,
						 (int*)&dbiConn.getId(),
						 UNUSED) != RET_SUCCEED)
	{
		/* REF3668 - SSO - 990903 : if server, see if the client conn. is dead? */
		if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
		{
			DBA_LoadPosDropTempTables(dbiConn,(DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			/* PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
			/*DBA_EndConnection(*connectNo);*/
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
			return(RET_DBA_ERR_DISCONNECTED);
		}

		/**** BEGIN DVP178+ ****/
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(FinAnalysis,
                                    role,
                                    curDynStEn,
						    	    currDomain,
                                    outputStLst,
                                    data,
		                	    	DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
									(int*)&dbiConn.getId(),
                                    UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,"DBA_MultiSelect failed again");
			/* PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
			/*DBA_EndConnection(*connectNo);*/
			return(ret);
		}
		/**** END   DVP178+ ****/
	}
	return(ret);
}

/************************************************************************
**  Function             : DBA_CallMultiSelectForLoadPos2()
**
**  Description          : Call MultiSelect2 for LoadPos function (generic)
**
**  Arguments            : role	        the role of the request
**                         domainPtr    domain arguments pointer
**                         outputStLst  pointer on the output dynamic struct. format list
**                         data         pointer on output dynamic structures array pointer
**                         rows         pointer on result rows number for each dynStType
**                         connectNo    pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF10744 - CHU - 041111
**
**  Modif.		         : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
RET_CODE DBA_CallMultiSelectForLoadPos2(DBA_DYNFLD_STP		domainPtr,
    const DBA_DYNST_ENUM	**outputStLst,
    DBA_DYNFLD_STP		**data,
    int					*rows,
    DbiConnection&        dbiConn)
{
    RET_CODE		ret = RET_SUCCEED;
    DBA_DYNST_ENUM	curDynStEn = NullDynSt;
    DBA_DYNFLD_STP	currDomain = NULL;
    int				role = UNUSED;

    curDynStEn = A_Domain;
    currDomain = domainPtr;

    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
        case DictFct_SynthAdmin:
            role = DBA_ROLE_PTFSYNTH_ALL;
            break;

        case DictFct_BenchStorage:
            if (GET_FLAG(domainPtr, A_Domain_DfltFlg) == TRUE)
            {
                role = DBA_ROLE_MULTISELECT_INSTR;
            }
            else
            {
                role = static_cast<int>(GET_ID(domainPtr, A_Domain_FctDictId));
            }
            break;

        default:
            role = static_cast<int>(GET_ID(domainPtr, A_Domain_FctDictId));
            break;
    }

    if (DBA_MultiSelect2(FinAnalysis,
                         role,
                         curDynStEn,
                         currDomain,
                         outputStLst,
                         data,
                         DBA_SET_CONN | DBA_NO_CLOSE,
                         UNUSED,
                         rows,
                         (int*)&dbiConn.getId(),
                         UNUSED) != RET_SUCCEED)
    {
        /* REF3668 - SSO - 990903 : if server, see if the client conn. is dead? */
        if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            /* PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
            /* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
            /*DBA_EndConnection(*connectNo);*/
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
            return(RET_DBA_ERR_DISCONNECTED);
        }

        /**** BEGIN DVP178+ ****/
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

        if ((ret = DBA_MultiSelect2(FinAnalysis,
                                    role,
                                    curDynStEn,
                                    currDomain,
                                    outputStLst,
                                    data,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
                                    (int*)&dbiConn.getId(),
                                    UNUSED)) != RET_SUCCEED)
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
            /* PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
            /* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
            /*DBA_EndConnection(*connectNo);*/
            return(ret);
        }
        /**** END   DVP178+ ****/
    }
    return(ret);
}

/************************************************************************
**  Function             : DBA_CheckDataBeforeLoadingHier()
**
**  Description          : Handle and check some data from MultiSelect before
**                         loading them into hierarchy
**
**  Arguments            : domainPtr      domain arguments pointer
**                         argHierHeadPtr hierarchy pointer
**                         connectNo      pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF10744 - CHU - 041111
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE DBA_CheckDataBeforeLoadingHier(DBA_DYNFLD_STP			domainPtr,
										 DBA_HIER_HEAD_STP		*hierHeadPtr,
										 const DBA_DYNST_ENUM	**outputStLst,
										 int					*outputMatch,
										 int					outputBlkNb,
										 DBA_DYNFLD_STP			**data,
										 int					*rows,
										 DbiConnection&         dbiConn,
										 FLAG_T					fromDateModif,
										 DATETIME_T				domTmpFromDate,
										 FLAG_T					tillDateModif,
										 DATETIME_T				domTmpTillDate,
										 int 					*selPspNbr,
										 DBA_DYNFLD_STP			**selPspTab)
{
	RET_CODE		ret		= RET_SUCCEED;
	DBA_DYNFLD_STP	recPtr	= NULLDYNST;
	int				i;

	switch (GET_ID(domainPtr, A_Domain_FctDictId))
	{
	case DictFct_CheckStratValo:
		{
			/* REF3678 - RAK - 990812 */
			/* Verify that instrument (+ interCond and InstrPrice) aren't already in hierarchy ... */
			/* in that case, FREE loaded record in array, hierarchy tool accept a "gruy�re" array */
			if ((*hierHeadPtr) != (DBA_HIER_HEAD_STP) NULL)
			{
				DBA_HIER_HEAD_STP   subHier=NULL;

				if ((ret = DBA_VerifInstrInHier(*hierHeadPtr,
												&(data[5]), &(rows[5]),   /* A_Instr */
/* PMSTA07845-CHU-090208 do not remove for CheckStrat*/ NULL, NULL,       /* A_InstrChrono */
/* PMSTA07845-CHU-090208 do not remove for CheckStrat*/ NULL, NULL,       /* A_InstrPrice */
/* PMSTA07845-CHU-090208 do not remove for CheckStrat*/ NULL, NULL        /* A_InterCond */
												/* &(data[6]), &(rows[6]), */  /* A_InstrChrono */
												/* &(data[7]), &(rows[7]), */  /* A_InstrPrice */
												/* &(data[8]), &(rows[8])  */) /* A_InterCond */
												) != RET_SUCCEED)
				{
					return(ret);
				}

				if ((ret = DBA_VerifPtfInHier(*hierHeadPtr,
											  &(data[4]), &(rows[4]), /* A_Ptf */
											  NULL, NULL              /* A_PtfPosSet */
											  )) != RET_SUCCEED)
				{
					return(ret);
				}

				subHier = DBA_CreateSubHier(*hierHeadPtr);  /* REF5239 - RAK - 001025 */
				if (subHier != NULL)
				{
					/* Add records in sub-hierarchy (only A_Instr and A_InterCond) */
					if ((ret = DBA_AddHierRecordList(subHier, data[5], rows[5],
													 *(outputStLst[5]), TRUE)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					if ((ret = DBA_AddHierRecordList(subHier, data[8], rows[8],
													 *(outputStLst[8]), TRUE)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					/* Make link A_Instr -> A_InterCond */
					if ((ret = DBA_SetHierLnkUsed(subHier, A_Instr,
												  A_Instr_Cond_A_Instr_Ext)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					if ((ret = DBA_MakeSpecRecLinks(subHier, A_Instr,
													A_Instr_Cond_A_Instr_Ext)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					if ((ret = DBA_SetHierLnkUnused(subHier, A_Instr,
													A_Instr_Cond_A_Instr_Ext)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					/* Integrate in main hierarchy */
					if ((ret = DBA_IntegrateSubHier(subHier, *hierHeadPtr)) != RET_SUCCEED)
					{
						DBA_FreeHier(subHier);
						return(ret);
					}

					DBA_FreeHier(subHier);

					/* Add other records */
					rows[5] = 0;   /* A_Instr */
					rows[8] = 0;   /* A_InterCond */
				}
			}
		}
		break;

	case DictFct_Return:
		{
			int	ptfIdx=5;				/* REF3489 - RAK - 990324 */

			/* REF3489 - In case of load of position in return function,   */
			/*           portfolio(s) could be already load                */
			/*           (same hierarchy is used for synthetics load),     */
			/*           so don't add a second time the current portfolio. */
			if (hierHeadPtr != NULL && *hierHeadPtr != NULL)
			{
            /*PMSTA-53952-Performance IPS -Lalby - 07112023*/
            /* All portfolio allready in Hierarchy must be removed from returned block */
            if (data[ptfIdx] != NULL && (ret = DBA_VerifPtfInHier((*hierHeadPtr),
                &(data[ptfIdx]), &(rows[ptfIdx]), /* A_Ptf */
                NULL, NULL              /* A_PtfPosSet */
                )) != RET_SUCCEED)
            {
                 return(ret);
            }
			}
		}
		break;

	case DictFct_CurrencyModify:
		{
			DBA_DYNFLD_STP	chkArgSt = NULLDYNST;
			int				checkStatus = 0;

			/* REF10390 - RAK - 040706 - Use new proc chk_execution_for_cur_modif */
			/* return 0 if ther is no execution                                   */
			/*        1 if there are accounted executions                         */
			/*       -1 if there is no accounted execution                        */
			if ((chkArgSt = ALLOC_DYNST(Chk_Arg)) == NULLDYNST)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				return(RET_MEM_ERR_ALLOC);
			}

			if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
			{
				COPY_DYNFLD(chkArgSt,  Chk_Arg,  Chk_Arg_Id, domainPtr, A_Domain, A_Domain_PtfObjId);
				COPY_DYNFLD(chkArgSt,  Chk_Arg,  Chk_Arg_EntDictId, domainPtr, A_Domain, A_Domain_DimPtfDictId);
			}
			else
			{
				COPY_DYNFLD(chkArgSt,  Chk_Arg,  Chk_Arg_Id, domainPtr, A_Domain, A_Domain_InstrObjId);
				COPY_DYNFLD(chkArgSt,  Chk_Arg,  Chk_Arg_EntDictId, domainPtr, A_Domain, A_Domain_DimInstrDictId);
			}

            SET_INT(chkArgSt,Chk_Arg_ReturnStatus,checkStatus);

			if ((ret = DBA_Check(ExecutionEnt, UNUSED, Chk_Arg, chkArgSt,
							 DBA_SET_CONN|DBA_NO_CLOSE,
							 (int*)&dbiConn.getId(), UNUSED)) != RET_SUCCEED)
			{
				FREE_DYNST(chkArgSt, Chk_Arg);
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_LoadPos() for Currency Modify : notify failed on executions");
				return(ret);
			}
            checkStatus = GET_INT(chkArgSt, Chk_Arg_ReturnStatus); /* PMSTA-46404 - DDV - 211004 */
			FREE_DYNST(chkArgSt, Chk_Arg);

			/* REF10390 - RAK - 040706 - use notifStatus */
			/* (instead of rows[1] and rows[2] which won't be returned anymore)*/
			/* REF7560 - DDV - 020816 - if execution or global execution fee exist
			   stop all. Modify currency is not allowed */
			/* if (rows[1] > 0 || rows [2] > 0) */
			if (checkStatus == -1)
			{
				if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
				{
					/* search portfolio */
					for (i=0; i<rows[6] && recPtr == NULLDYNST; i++)
					{
						if (GET_ID(data[6][i], A_Ptf_Id) == GET_ID(domainPtr, A_Domain_PtfObjId))
							recPtr = data[6][i];
					}
					if (recPtr != NULLDYNST)
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 11, FILEINFO, GET_CODE(recPtr, A_Ptf_Cd));
					else
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 11, FILEINFO, SYS_Stringer("(Ptf Id = ",GET_ID(domainPtr, A_Domain_PtfObjId),")").c_str());
				}
				else if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
				{
					/* search instrument */
					for (i=0; i<rows[7] && recPtr == NULLDYNST; i++)
					{
						if (GET_ID(data[7][i], A_Instr_Id) == GET_ID(domainPtr, A_Domain_InstrObjId))
							recPtr = data[7][i];
					}
					if (recPtr != NULLDYNST)
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 10, FILEINFO, GET_CODE(recPtr, A_Instr_Cd));
					else
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 10, FILEINFO, SYS_Stringer("(Instr Id = ",GET_ID(domainPtr, A_Domain_InstrObjId),")").c_str());
				}

				for (i=0; i<outputBlkNb; i++)
				{
					DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i])); /* REF8844 - LJE - 030423 */
				}
				return(RET_FIN_ERR_POSITIONS);
			}
			/* Send message but continue treatment */
			if (checkStatus == 1)
			{
				if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
				{
					/* search portfolio */
					for (i=0; i<rows[6] && recPtr == NULLDYNST; i++)
					{
						if (GET_ID(data[6][i], A_Ptf_Id) == GET_ID(domainPtr, A_Domain_PtfObjId))
							recPtr = data[6][i];
					}
					if (recPtr != NULLDYNST)
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 13, FILEINFO, GET_CODE(recPtr, A_Ptf_Cd));
					else
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 13, FILEINFO, SYS_Stringer("(Ptf Id = ",GET_ID(domainPtr, A_Domain_PtfObjId),")").c_str());
				}
				else if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
				{
					/* search instrument */
					for (i=0; i<rows[7] && recPtr == NULLDYNST; i++)
					{
						if (GET_ID(data[7][i], A_Instr_Id) == GET_ID(domainPtr, A_Domain_InstrObjId))
							recPtr = data[7][i];
					}
					if (recPtr != NULLDYNST)
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 12, FILEINFO, GET_CODE(recPtr, A_Instr_Cd));
					else
						MSG_SendMesg(RET_FIN_ERR_POSITIONS, 12, FILEINFO, SYS_Stringer("(Instr Id = ",GET_ID(domainPtr, A_Domain_InstrObjId),")").c_str());
				}
			}
		}
		break;

	case DictFct_BenchStorage:
		if (GET_FLAG(domainPtr, A_Domain_DfltFlg) == TRUE)
		{
			/* REF9340 - DDV - 030925 - Don't load  PSP for Online, they will be added in hierarchy later */
			if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)
			{
				if ((ret= DBA_SelectPSP(domainPtr, (int*)&dbiConn.getId(), selPspTab, selPspNbr)) != RET_SUCCEED)
				{
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_SelectPSP failed ... ");
					return(ret);
				}
			}
		}
		else
		{
			/* Suppress instruments because they are already added in hierarchy by minimal load */
			/* 1 = index of A_Instr in rows and data, see outputStLst */
			/* hierarchy is received in argHierHead and won't be created */
			for (i=0; i<rows[1]; i++)
			{ FREE_DYNST(data[1][i], A_Instr);}
			FREE(data[1]);
			rows[1] = 0;
		}
		break;

	case DictFct_Journal:
		{
			/* BEGIN - DVP063 - 960521 - XDI */
			if (fromDateModif == TRUE)
			{
				SET_DATETIME(domainPtr, A_Domain_InterpFromDate, domTmpFromDate);
			}
			/* else */
			if (tillDateModif == TRUE) /* REF4145 - CSY - 991124 */
			{
				SET_DATETIME(domainPtr, A_Domain_InterpTillDate, domTmpTillDate);
			}
			/* END - DVP063 - 960521 - XDI */
		}
		break;

		/* <PMSTA02901-EFE-070727*/
	case DictFct_Valo:
		{
			if ((ret = DBA_ValoEliminate(domainPtr, data, rows, outputStLst, outputBlkNb,
							*hierHeadPtr))   != RET_SUCCEED)
			{
				return(ret);
			}

		}
		break;
		/* >PMSTA02901-EFE-070727*/

	default:
		break;
	}
	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_ArrangeDataAfterLoadingHier()
**
**  Description          : Handle some data after their loading in hierarchy
**
**  Arguments            : domainPtr      domain arguments pointer
**                         argHierHeadPtr hierarchy pointer
**                         connectNo      pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF10744 - CHU - 041111
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE DBA_ArrangeDataAfterLoadingHier(DBA_DYNFLD_STP		domainPtr,
										 DBA_HIER_HEAD_STP	*hierHeadPtr,
										 DBA_DYNFLD_STP		*listPtf,
										 int				listPtfNbr,
										 DBA_DYNFLD_STP		**data,
										 int				*rows,
										 DbiConnection&     dbiConn,
										 int 				selPspNbr,
										 DBA_DYNFLD_STP		*selPspTab)
{
	RET_CODE ret = RET_SUCCEED;

	switch (GET_DICT(domainPtr, A_Domain_FctDictId))
	{
	case DictFct_SynthAdmin:
		{
			/* REF2992 - load exchange rates and add them in hierarchy ... */
			if ((COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_View &&
				 SYS_GetEnv("AAANOLOADEXCH") != NULL)
			{
				if ((ret = DBA_SelectExchRateForPtfSynth(domainPtr, listPtf, listPtfNbr,
					FALSE, dbiConn, *hierHeadPtr)) != RET_SUCCEED)
				{
					/* Drop temporary tables and close connection */    /*BUG202-961112-DED*/
					DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					/* PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
					/* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
					/* DBA_EndConnection(*connectNo); */
					return(ret);
				}
			}

            DBA_MergePerfCompPeriods(*hierHeadPtr,domainPtr,nullptr,0); /* data can be null */

			/* Drop temporary tables and close connection */    /*BUG202-961112-DED*/
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			/* PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer. */
			/*DBA_EndConnection(*connectNo);*/      
			DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
			DATE_START_TIMER(4, TIMER_MASK_SQLC);
		}
		break;

	case DictFct_PerformanceAnalysis:
		{
            if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PerformanceAnalysis)
            {
			    /* REF9340 - DDV - 031007 */
			    DBA_RemoveUnusedPSPFromHier(*hierHeadPtr);

			    /* REF7758 - DDV - 021104 - Compute all needed online data */
			    if ((ret= FIN_CompleteDataForAllRecords(domainPtr, *hierHeadPtr)) != RET_SUCCEED)
			    { return(ret); }
            }
		}
		break;

	case DictFct_BenchStorage:
		if (GET_FLAG(domainPtr, A_Domain_DfltFlg) == TRUE)
		{
			/* REF9340 - DDV - 030925 - Don't load  PSP for Online, they will be added in hierarchy later */
			if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)
			{
				if ((ret = DBA_FilterPSP(domainPtr, /* c'est le domain tout simplement */
										 *hierHeadPtr,
										 data[0],  /* instrument array */
										 rows[0],
										 Instr,
					   					 selPspTab,
										 selPspNbr)) != RET_SUCCEED)
				{
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_FilterPSP failed ... ");
					return(ret);
				}
			}
		}
		break;

	default:
		break;
	}
	return(ret);
}

/************************************************************************
*   Function             : DBA_UpdateInterCondFlg()
*
*   Description          : If interest conditions have been loaded
*                          it update A_Instr_IntercondFlagInHier for all intruments
*
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF10696 - DDV - 041206
*
*   Last Modification    : PMSTA01512-CHU-070508 : Special treatment for FundShares
*************************************************************************/
void DBA_UpdateInterCondFlg(const DBA_DYNST_ENUM** outputStLst,
	                               int                    outputBlkNb,
				                   DBA_DYNFLD_STP         **data,
				                   int                    *rows)
{
	int i,j, interCondFlg = FALSE;

	for(i=0; i<outputBlkNb && interCondFlg == FALSE; i++)
	{
		if (*(outputStLst[i]) == A_InterCond)
			interCondFlg = TRUE;
	}

	if (interCondFlg == TRUE)
	{
		for(i=0; i<outputBlkNb; i++)
		{
			if (*(outputStLst[i]) == A_Instr)
			{
				for (j=0; j<rows[i]; j++)
				{
					/* PMSTA01512-CHU-070508 : IC Are not loaded for FundShares anymore ! */
					if ((INSTRNAT_ENUM) GET_ENUM(data[i][j], A_Instr_NatEn) != InstrNat_FundShare)
						SET_FLAG(data[i][j], A_Instr_InterCondInHerFlg, TRUE);
				}
			}

		}
	}
}


/************************************************************************
*   Function             : DBA_RemoveTechnicalPosition()
*
*   Description          : Remove technical positions for Positions History financial function
*
*   Arguments            :
*
*   Return               : None
*
*   Creation Date        : PMSTA-23908 - 040716 - PMO : Market Value is different in Valuation and Position History when dealing with derivative transactions
*
*   Last Modification    :
*
*************************************************************************/
STATIC void DBA_RemoveTechnicalPosition(const DBA_DYNFLD_STP    domainPtr,
                                        const DBA_DYNST_ENUM ** outputStLst,
                                        const int               outputBlkNb,
                                        DBA_DYNFLD_STP **       data,
                                        const int *             rows)
{
    if(GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Perfo)     /* Positions History */
    {
		for(int i=0; i<outputBlkNb; i++)
		{
            if (*(outputStLst[i]) == ExtPos)
            {
				for (int j=0; j<rows[i]; j++)
				{
                    if (TRUE == DBA_IsTechnicalPosition(data[i][j]))
                    { /* Remove the position */

                        FREE_DYNST(data[i][j], ExtPos);
                        data[i][j] = NULL;
                    }
                }
            }
        }
    }
}


/************************************************************************
*   Function             : DBA_FilterAdjustmentAccountPosition()
*
*   Description          : Remove adjustment account positions for some financial functions
*
*   Arguments            :
*
*   Return               : None
*
*   Creation Date        : PMSTA-5595 - 190808 - PMO
*
*   Last Modification    :
*************************************************************************/
void DBA_TreatAdjustmentAccountPosition(const DBA_DYNFLD_STP    domainPtr,
                                               const DBA_DYNST_ENUM ** outputStLst,
                                               const int               outputBlkNb,
                                               DBA_DYNFLD_STP **       data,
                                               const int *             rows)
{
    if(GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_OpList ||
       GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo)
    {
		for(int i=0; i<outputBlkNb; i++)
		{
            if (*(outputStLst[i]) == ExtPos)
            {
				for (int j=0; j<rows[i]; j++)
				{
                    if (TRUE == DBA_CheckPositionToRemove(domainPtr, data[i][j]))   /* Function renamed PMSTA-6924 - 280109 - PMO */
                    { /* Remove the position */

                        FREE_DYNST(data[i][j], ExtPos);
                        data[i][j] = NULL;
                    }
                }
            }
        }
    }
    else
    {
        /* Remove technical positions for Positions History financial function / PMSTA-23908 - 040716 - PMO */
        DBA_RemoveTechnicalPosition(domainPtr, outputStLst, outputBlkNb, data, rows);
    }
}


/************************************************************************
*   Function             : DBA_CopyOperationRemoveTargetPortfolioTransferPosition()
*
*   Description          : For "Copy Operation", a "target" position of a portfolio transfer must not generate an operation
*
*   Arguments            :
*
*   Return               : None
*
*   Creation Date        : PMSTA-21783 - 111215 - PMO : Copy operation on portfolio with portfolio transfer operation is failed
*
*   Last Modification    :
*************************************************************************/
void DBA_CopyOperationRemoveTargetPortfolioTransferPosition(const DBA_DYNFLD_STP    domainPtr,
                                                                   const DBA_DYNST_ENUM ** outputStLst,
                                                                   const int               outputBlkNb,
                                                                   DBA_DYNFLD_STP **       data,
                                                                   const int *             rows)
{
    /* Only for "Copy Operation" */
    if(DictFct_CopyOperation == GET_ID(domainPtr, A_Domain_FctDictId))
    {
        const ID_T ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
        /*
         * Browse positions
         */
		for(int i = 0; i<outputBlkNb; i++)
		{
            if (*(outputStLst[i]) == ExtPos)
            {
				for (int j = 0; j < rows[i]; j++)
				{
                    /*
                     * Filter portfolio transfer operartion "target" position
                     */
                    DBA_DYNFLD_STP  pos                =  data[i][j];
                    const bool      portfolioTransfert =  PosPrimary_Primary == (POSPRIMARY_ENUM)GET_ENUM(pos, ExtPos_PrimaryEn)
                                                       && OpNat_PtfTransf    == (OPNAT_ENUM)     GET_ENUM(pos, ExtPos_OpenOpNatEn);

                    if ( true == portfolioTransfert
                       && (  0                  != CMP_ID(ptfId,    GET_ID(  pos, ExtPos_PtfId))
                          || PosNat_ToInstrPos  == (POSNAT_ENUM)    GET_ENUM(pos, ExtPos_PosNatEn)
                          || PosNat_ToBpPos     == (POSNAT_ENUM)    GET_ENUM(pos, ExtPos_PosNatEn)
                          )
                       )
                    { /* Remove the position */
                       FREE_DYNST(data[i][j], ExtPos);
                    }
                }
            }
        }
    }
}


/************************************************************************
*   Function             : DBA_PropagateFusionE()
*
*   Description          : fusion_e is now managed by the C code
*
*   Arguments            :
*
*   Return               : None
*
*   Creation Date        : PMSTA-34515 - 310119 - PMO : Regression - UTP scope: PBA_PMSTA_8174 TaAutomator test case failed : incorrect positions generated
*
*   Last Modification    : PMSTA-34589 - 130219 - PMO : Regression - TaAutomator MFE_SP_CURRENCY_MODIF_PORT test case failed
*
*************************************************************************/
void DBA_PropagateFusionE(const DBA_DYNFLD_STP    domainPtr,
                                 const DBA_DYNST_ENUM ** outputStLst,
                                 const int               outputBlkNb,
                                 DBA_DYNFLD_STP **       data,
                                 const int *             rows)
{
    std::map<std::string, DBA_DYNFLD_STP> mapCodeOperation; // Keep ext_order code for finding duplicate operation code

    const bool modifyCurrency = DictFct_CurrencyModify == GET_ID(domainPtr, A_Domain_FctDictId);    /* PMSTA-34589 - 130219 - PMO */

    /*
     * Browse ext_order and keep interesting operation code
     */
    for (int i = 0; i < outputBlkNb; i++)
    {
        if (*(outputStLst[i]) == ExtOp)
        {
            for (int j = 0; j < rows[i]; j++)
            {
                DBA_DYNFLD_STP extOp = data[i][j];

                if (true == modifyCurrency)
                { // Modify currency needs to know the exact state of operation and position
                    if (OpFusion_ToDelete != (OPFUSION_ENUM)GET_ENUM(extOp, ExtOp_FusionEn))
                    {
                        mapCodeOperation.insert(std::make_pair(GET_CODE(extOp, ExtOp_Cd), extOp));
                    }
                }
                else
                { // Financial function "ignore" newly operations until they are treated by the fusion. Operation list show both states
                    if (OpFusion_Treated == (OPFUSION_ENUM)GET_ENUM(extOp, ExtOp_FusionEn))
                    {
                        mapCodeOperation.insert(std::make_pair(GET_CODE(extOp, ExtOp_Cd), extOp));
                    }
                }
            }
        }
    }

    if (false == mapCodeOperation.empty())
    {
        const bool operationList = DictFct_OpList == GET_ID(domainPtr, A_Domain_FctDictId);

        /*
         * Browse positions and operations
         */
        for (int i = 0; i < outputBlkNb; i++)
        {
            if (*(outputStLst[i]) == ExtPos)
            {
                for (int j = 0; j < rows[i]; j++)
                {
                    DBA_DYNFLD_STP pos = data[i][j];

                    if (   nullptr            !=  pos
                        && PosPrimary_Primary == (POSPRIMARY_ENUM)GET_ENUM(pos, ExtPos_PrimaryEn)
                        && PosNat_MainPos     == (POSNAT_ENUM)    GET_ENUM(pos, ExtPos_PosNatEn)
                        )
                    {
                        auto it = mapCodeOperation.find(GET_CODE(pos, ExtPos_OpenOpCd));

                        if (it != mapCodeOperation.end())
                        { // Found
                            const ID_T operationId = GET_ID(pos, ExtPos_OpenOpId);

                            /*
                             * Positions or operation having this operation ID have to be removed or defined with fusion_e=2 to avoid duplicate data
                             */
                            for (int i2 = 0; i2 < outputBlkNb; i2++)
                            {
                                if (*(outputStLst[i2]) == ExtPos)
                                {
                                    for (int j2 = 0; j2 < rows[i2]; j2++)
                                    {
                                        DBA_DYNFLD_STP pos2 = data[i2][j2];

                                        if (nullptr != pos2 && operationId == GET_ID(pos2, ExtPos_OpenOpId))
                                        { // Position processing
                                            if (true == operationList)
                                            { // Show as deleted
                                                SET_ENUM(pos2, ExtPos_Fus, OpFusion_ToDelete);
                                            }
                                            else
                                            { // Remove the position
                                                FREE_DYNST(data[i2][j2], ExtPos);
                                            }
                                        }
                                    }
                                }

                                if (*(outputStLst[i2]) == A_Op)
                                {
                                    for (int j2 = 0; j2 < rows[i2]; j2++)
                                    {
                                        DBA_DYNFLD_STP operation = data[i2][j2];

                                        if (nullptr != operation && operationId == GET_ID(operation, A_Op_Id))
                                        { // Position processing
                                            if (true == operationList)
                                            { // Show as deleted
                                                SET_ENUM(operation, A_Op_Fus, OpFusion_ToDelete);
                                            }
                                            else
                                            { // Remove the position
                                                FREE_DYNST(data[i2][j2], A_Op);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


/************************************************************************
*   Function             : DBA_LoadPos()
*
*   Description          : Load positions hierarchy
*
*                          - FOR FINANCIAL FUNCTION :
*
*                          Send requests to the server to retrieve positions,
*                          portfolio(s) and financial instrument(s) used by
*                          financial functions to calculate many results, start
*                          positions valorisations, etc...
*
*                          REM : positions, portfolios and financial
* 	                         instruments are loading according to a domain
*                                specifications (portfolio and financial
*                                instrument dimensions, status, dates, specific
*                                currency, consolidation rule, etc...)
*
*
*   Arguments            : inputSt     : input dynamic structure format
*                          inputData   : pointer on the input dynamic structure
*                          hierHeadPtr : pointer on hierarchy header pointer
* 			               listPtf     : pointer on a list of portfolio id's
* 			               listPtfNbr  : number of portfolio's in list
*                          listInstr     : pointer on a list of instrument id's
* 			               listInstrNbr  : number of instrument's in list
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : Oct.  94 - PEC
*   Last Modification    : 12.08.05 - PEC/DED - Added Strategy handling case
*			   06.03.96 - DED - Add new function "Currency Modif"
*                          17.04.96 - RAK - Function create hierarchy (and allocate header pointer)
*                                     if pointer is NULL, else use the received header pointer.
*			   DVP029  - 960510 - DED : Add new extensions on ExtPos
*			   BUG113  - 960830 - RAK : Make Main and Acct links
*			   DVP178+ - 960918 - PEC : Deadlock handling
*			   BUG202  - 961112 - DED : Drop and close connection after multiselect
*			   DVP249  - 961112 - PEC : DVP249
*			   DVP288  - 961205 - DED : Change Fus_Arg structure
*			   DVP261  - 961209 - RAK : Create #tmp_port
*			   DVP288  - 961211 - DED : Fusion -> only 2 blocks of data instead of 3
*			   DVP332  - 970123 - DED : Valo + Return : add new block 'pos_val'
*			   DVP445  - 970429 - RAK : Fusion : load instruments = new block
*			   DVP460  - 970515 - RAK : receive instruments list
*			   DVP474  - 970612 - XMT : Add extensions ToBalPos and ToInstr for PtfTransf
*			   DVP545  - 970721 - DED : Add function Copy Operations
*              DVP563  - 970821 - DED : Add new block 'A_InterCond' to all multiselect
*              BUG467  - 970822 - DED : RET_CODE for return of function
*			   DVP568  - 970827 - DED : Implement hierarchy portfolio
*			   REF875  - 971113 - DED : Correct doubles in hierarchy if fusion
*              REF1459 - 980318 - GRD : 2 new parameters for OPE_SetExtPosBookVal.
*              REF3489 - 990324 - RAK : Change load for DictFct_Return.
*              REF4145 - 991123 - CSY: load untill calc_ref_date for journal
*              REF4306 - 000221 - CSY: DisplayChrono
*              REF5246 - 001024 - CSY: eliminate some postions for return (futures,...)
*              REF9125 - 030902 - MCA: add load for PSP only for benchmarkStorage - instrument
*              REF9764 - 040107 - TEB
*              REF10744- 041108 - CHU : complete function rewrite
*                          Function completely rewritten and cut into generic subfunctions
*                          some explanation on actual main parts in LoadPos which are used
*                          considering current value of A_Domain_FctDictId :
*                          1. Initialize a bunch of flags
*                          2. Prepare input/output parameters for MultiSelect Call (loadPosParamDef)
*                          3. DBA_LoadPosInitBeforeMultiSelect() : treatments BEFORE MultiSelect
*                          4. DBA_CallMultiSelectForLoadPos()    : generic MultiSelect2()
*                          5. DBA_CheckDataBeforeLoadingHier()   : treatments BEFORE loading data into hierarchy
*                          6. DBA_LoadPosHierCreate()            : load Data into hierarchy
*                          7. DBA_ArrangeDataAfterLoadingHier()  : handle and arrange data after hierarchy loading
*                          8. DBA_SplitExtOpBlock()              : split blocks of ExtOps if necessary
*                          9. DBA_LoadPosHierLnkAndUpd()         : make links and update ExtPos records
*                         10. Treat other A_Domain_FctDictId not concerned by previous function calls
*                         11. Some global ending treatments and exit
*              PMSTA-5595 - 190808 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
*              PMSTA08429 - 280709 - PMO : Journal : In a Cash Portfolio, final stock becomes wrong when there is an order
*              PMSTA-21617 - 101115 - PMO : Order List - Wrong and probably useless call on portfolio security
*              PMSTA-21783 - 111215 - PMO : Copy operation on portfolio with portfolio transfer operation is failed
*              PMSTA-34515 - 310119 - PMO : Regression - UTP scope: PBA_PMSTA_8174 TaAutomator test case failed : incorrect positions generated
*
*************************************************************************/

/* PMSTA-36208 - DDV - 190808 - Temporary for test and validation */
typedef enum {
    LoadPosMode_OldMultiSelectOldLoadPos = 0,      /* 0 - old multiselect, old DBA_LoadPos structure */
    LoadPosMode_NewMultiSelectOldLoadPos,          /* 1 - New multiselect, old DBA_LoadPos structure */
 /*   LoadPosMode_NewMultiSelectNewLoadPos, */         /* 2 - New multiselect, new  DBA_LoadPos structure */
    LoadPosMode_Last
} LOADPOS_MODE_ENUM;

RET_CODE DBA_LoadPos(DBA_DYNFLD_STP  domainPtr,
					 DBA_HIER_HEAD_STP *argHierHeadPtr,
					 DBA_DYNFLD_STP *listPtf,
					 int             listPtfNbr,
					 DBA_DYNFLD_STP *listInstr,
					 int             listInstrNbr)
{
    RET_CODE			      ret = RET_SUCCEED;
    static LOADPOS_MODE_ENUM  SV_LoadPosMode = LoadPosMode_NewMultiSelectOldLoadPos; /* As sel_exd_position_by_domain has been removed, only new mode can be used.
                                                                                        To test old behaviour, uncomment the proc and initilised this variable with value LoadPosMode_Last */

    if (SV_LoadPosMode == LoadPosMode_Last)
    {
        char *envVar = SYS_GetEnv("AAALOADPOSMODE");
        int   varValue = 0;

        if (envVar != NULL && envVar[0] != END_OF_STRING)
        {
            varValue = atoi(envVar);

            /* if value is not valide use default (0 => LoadPosMode_NewMultiSelectOldLoadPos) */
            if (varValue >= LoadPosMode_Last)
            {
                SV_LoadPosMode = LoadPosMode_NewMultiSelectOldLoadPos;
            }
            else
            {
                SV_LoadPosMode = (LOADPOS_MODE_ENUM)varValue;
            }
        }
        else
        {
            /* Always use new mode, keep old mode for test in case of strange behaviour */
            SV_LoadPosMode = LoadPosMode_NewMultiSelectOldLoadPos;
        }
    }

    switch(SV_LoadPosMode)
    {
        case LoadPosMode_OldMultiSelectOldLoadPos:
	        ret = DBA_LoadPosOld(domainPtr, argHierHeadPtr, listPtf, listPtfNbr, listInstr, listInstrNbr);
            break;

        case LoadPosMode_NewMultiSelectOldLoadPos:
            ret = DBA_LoadPos2(domainPtr, argHierHeadPtr, listPtf, listPtfNbr, listInstr, listInstrNbr);
            break;

#if 0 /* PMSTA-36208 - DDV - 190829 - POC */
		case LoadPosMode_NewMultiSelectNewLoadPos:
            ret = DBA_LoadPosNew(domainPtr, argHierHeadPtr, listPtf, listPtfNbr, listInstr, listInstrNbr);
            break;
#endif
    }

    return(ret);
}

/************************************************************************
*   Function             : DBA_LoadPosOld()
*
*   Description          : Load positions hierarchy
*
*                          - FOR FINANCIAL FUNCTION :
*
*                          Send requests to the server to retrieve positions,
*                          portfolio(s) and financial instrument(s) used by
*                          financial functions to calculate many results, start
*                          positions valorisations, etc...
*
*                          REM : positions, portfolios and financial
* 	                         instruments are loading according to a domain
*                                specifications (portfolio and financial
*                                instrument dimensions, status, dates, specific
*                                currency, consolidation rule, etc...)
*
*
*   Arguments            : inputSt     : input dynamic structure format
*                          inputData   : pointer on the input dynamic structure
*                          hierHeadPtr : pointer on hierarchy header pointer
* 			               listPtf     : pointer on a list of portfolio id's
* 			               listPtfNbr  : number of portfolio's in list
*                          listInstr     : pointer on a list of instrument id's
* 			               listInstrNbr  : number of instrument's in list
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : Oct.  94 - PEC
*   Last Modification    : 12.08.05 - PEC/DED - Added Strategy handling case
*			   06.03.96 - DED - Add new function "Currency Modif"
*                          17.04.96 - RAK - Function create hierarchy (and allocate header pointer)
*                                     if pointer is NULL, else use the received header pointer.
*			   DVP029  - 960510 - DED : Add new extensions on ExtPos
*			   BUG113  - 960830 - RAK : Make Main and Acct links
*			   DVP178+ - 960918 - PEC : Deadlock handling
*			   BUG202  - 961112 - DED : Drop and close connection after multiselect
*			   DVP249  - 961112 - PEC : DVP249
*			   DVP288  - 961205 - DED : Change Fus_Arg structure
*			   DVP261  - 961209 - RAK : Create #tmp_port
*			   DVP288  - 961211 - DED : Fusion -> only 2 blocks of data instead of 3
*			   DVP332  - 970123 - DED : Valo + Return : add new block 'pos_val'
*			   DVP445  - 970429 - RAK : Fusion : load instruments = new block
*			   DVP460  - 970515 - RAK : receive instruments list
*			   DVP474  - 970612 - XMT : Add extensions ToBalPos and ToInstr for PtfTransf
*			   DVP545  - 970721 - DED : Add function Copy Operations
*              DVP563  - 970821 - DED : Add new block 'A_InterCond' to all multiselect
*              BUG467  - 970822 - DED : RET_CODE for return of function
*			   DVP568  - 970827 - DED : Implement hierarchy portfolio
*			   REF875  - 971113 - DED : Correct doubles in hierarchy if fusion
*              REF1459 - 980318 - GRD : 2 new parameters for OPE_SetExtPosBookVal.
*              REF3489 - 990324 - RAK : Change load for DictFct_Return.
*              REF4145 - 991123 - CSY: load untill calc_ref_date for journal
*              REF4306 - 000221 - CSY: DisplayChrono
*              REF5246 - 001024 - CSY: eliminate some postions for return (futures,...)
*              REF9125 - 030902 - MCA: add load for PSP only for benchmarkStorage - instrument
*              REF9764 - 040107 - TEB
*              REF10744- 041108 - CHU : complete function rewrite
*                          Function completely rewritten and cut into generic subfunctions
*                          some explanation on actual main parts in LoadPos which are used
*                          considering current value of A_Domain_FctDictId :
*                          1. Initialize a bunch of flags
*                          2. Prepare input/output parameters for MultiSelect Call (loadPosParamDef)
*                          3. DBA_LoadPosInitBeforeMultiSelect() : treatments BEFORE MultiSelect
*                          4. DBA_CallMultiSelectForLoadPos()    : generic MultiSelect2()
*                          5. DBA_CheckDataBeforeLoadingHier()   : treatments BEFORE loading data into hierarchy
*                          6. DBA_LoadPosHierCreate()            : load Data into hierarchy
*                          7. DBA_ArrangeDataAfterLoadingHier()  : handle and arrange data after hierarchy loading
*                          8. DBA_SplitExtOpBlock()              : split blocks of ExtOps if necessary
*                          9. DBA_LoadPosHierLnkAndUpd()         : make links and update ExtPos records
*                         10. Treat other A_Domain_FctDictId not concerned by previous function calls
*                         11. Some global ending treatments and exit
*              PMSTA-5595 - 190808 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
*              PMSTA08429 - 280709 - PMO : Journal : In a Cash Portfolio, final stock becomes wrong when there is an order
*              PMSTA-21617 - 101115 - PMO : Order List - Wrong and probably useless call on portfolio security
*              PMSTA-21783 - 111215 - PMO : Copy operation on portfolio with portfolio transfer operation is failed
*              PMSTA-34515 - 310119 - PMO : Regression - UTP scope: PBA_PMSTA_8174 TaAutomator test case failed : incorrect positions generated
*
*************************************************************************/
RET_CODE DBA_LoadPosOld(DBA_DYNFLD_STP  domainPtr,
                        DBA_HIER_HEAD_STP *hierHeadPtr,
                        DBA_DYNFLD_STP *listPtf,
                        int             listPtfNbr,
                        DBA_DYNFLD_STP *listInstr,
                        int             listInstrNbr)
{
    int 				i;
    RET_CODE			ret = RET_SUCCEED;

    int 				selPspNbr = 0;
    DBA_DYNFLD_STP		*selPspTab = NULLDYNSTPTR;

    DICT_T				initialDimPtfDict = NullEntity;

    DATETIME_T			domTmpFromDate;
    DATETIME_T			domTmpTillDate;
    FLAG_T				fromDateModif = FALSE;
    FLAG_T				tillDateModif = FALSE;

    /* Multiselect input/output structures */
    DBA_LOADPOSPARAM_STP loadPosParamDef = (DBA_LOADPOSPARAM_STP)NULL;
    const DBA_DYNST_ENUM **outputStLst = (const DBA_DYNST_ENUM **)NULL;
    int                  *outputMatch = (int *)NULL;
    int                  outputBlkNb = 0;
    DBA_DYNFLD_STP       **data = (DBA_DYNFLD_STP **)NULL;
    int                  *rows = (int *)NULL;

    /* ROLE is only different for DictFct_SynthAdmin (UNUSED in other cases) */
    int					role = UNUSED;

    DbiConnection*      dbiConn = nullptr;

    /* Init flags default values */
    FLAG_T	insertExtOpFlg = FALSE; /* for use in DBA_LoadPosHierCreate() */
    FLAG_T	insertOpFlg = FALSE; /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	insertPosFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	insertBalPosFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	keepOnlyPosMatchingPtfDimFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	keepOnlyPosMatchingInstrDimFlg = FALSE; /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	addResultInHierFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	checkInstrFlg = TRUE;  /* for use in DBA_LoadPosHierLnkAndUpd() */
    FLAG_T	loadOrderFromSessionFlg = FALSE; /* PMSTA09451 - DDV - 100303 */
    FLAG_T	loadExternalPosFromSessionFlg = FALSE; /* PMSTA11101-CHU-110201 */
    FLAG_T	loadTaxLotFlg = FALSE; /* PMSTA-28086 - CHU - 170912 */

    /* conditional function calls or actions */
    FLAG_T	createLoadPosHierarchyFlg = FALSE;
    FLAG_T	dropTempTablesFlg = FALSE;
    FLAG_T	splitExtOpBlockFlg = FALSE;
    FLAG_T	hierLinkAndUpdateFlg = FALSE;
    FLAG_T	multiStructInitFlg = FALSE;

    domTmpFromDate.date = (DATE_T)0;
    domTmpFromDate.time = (TIME_T)0;
    domTmpTillDate.date = (DATE_T)0;
    domTmpTillDate.time = (TIME_T)0;

    TAX_LOT_ACCOUNTING    taxLotAccounting = TAX_LOT_ACCOUNTING::NoTaxLot;                        /* PMSTA-34116 - 220219 - vkumar */
    GEN_GetApplInfo(ApplTaxLotAccountingEn, &taxLotAccounting);

    /* Check arguments */
    if (listPtfNbr != 0 && listPtf == NULLDYNSTPTR)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 0, FILEINFO);
        return(RET_GEN_ERR_INVARG);
    }

    MSG_StartFctTimerPmon("DBA_LoadPos"); /* PCC11124 - LJE - 090127 */

    /* Check current Function dict Id in domain */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
        /* DBA_LoadPos() will only work for following functions : */
    case DictFct_Valo:
    case DictFct_OpHist:
    case DictFct_OpList:
	case DictFct_CheckStratValo:
		loadTaxLotFlg = (static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_None);                  /* PMSTA-34116 - 220219 - vkumar */
	case DictFct_Perfo:
	case DictFct_Journal:
	case DictFct_Archive:
    case DictFct_FundValo:
    case DictFct_Return: /* REF10899 - LJE - 050127 */
		splitExtOpBlockFlg = TRUE;
		/* no break */
	case DictFct_MultiValo:
	case DictFct_CurrencyModify:
	case DictFct_CopyOperation:
	case DictFct_OrderList:
	case DictFct_SynthAdmin:
	case DictFct_DisplayChrono:
	case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
	case DictFct_CompositeMgr:
	case DictFct_PtfStorage:
	case DictFct_BenchStorage:
	case DictFct_PerformanceAnalysis:
	case DictFct_UnmatchedExecutionList:
	case DictFct_SearchMatchingOrder:
	case DictFct_OrderGrouping:		        /* REF11764 - RAK - 060330 */
    case DictFct_OrderNetting:              /* PMSTA-37908 - adarshn - 05032020 */
	case DictFct_UpdateField:		        /*  HFI-PMSTA-35324-190328  */
	case DictFct_UpdateData:		        /*  HFI-PMSTA-35324-190328  */
	case DictFct_CaseInquiry:		        /* PMSTA07121 - DDV - 090310 */
    case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
    case DictFct_InstrRecommLevelStorage :  /* PMSTA-28705 - DDV - 180208 */
    case DictFct_CurrChangeReq:               /* PMSTA-39723 - LIK 10042020 */
	case DictFct_PtfTransfFees:				/* PMSTA-39717 - KNI - 15062020 */
    case DictFct_HierarchyGrouping:			/* PMSTA-40208 - sanand - 24092020 */
		break;

    default:
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadPos: Invalid function dict id");
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(RET_GEN_ERR_PERSONAL);
    }

    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(DBA_CONN_NOT_FOUND);
    }

    /* Update in database portfolio and instrument dimension */
    if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, *dbiConn, listPtf, listPtfNbr,
        listInstr, listInstrNbr, &initialDimPtfDict, hierHeadPtr)) != RET_SUCCEED)
    {
        DBA_EndConnection(&dbiConn);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(ret);
    }

    /* PMSTA12467 - DDV - 110808 - Connection leak correction*/
    if ((GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort || GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_NoCompute) &&    /*  FPL-PMSTA11939-110526   */
        GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PreTradeCheckStrat &&
        GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PerformanceAnalysis) /* PMSTA12427-CHU-110722 */
    {
        DBA_EndConnection(&dbiConn);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(ret);
    }

    /* consider special cases for some flags */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    case DictFct_CheckStratValo:
        loadOrderFromSessionFlg = TRUE; /* PMSTA09451 - DDV - 100303 */
        loadExternalPosFromSessionFlg = TRUE; /* PMSTA11101-CHU-110201 */
        insertBalPosFlg = FALSE;
        keepOnlyPosMatchingInstrDimFlg = TRUE;
        break;

    case DictFct_FundValo:
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = FALSE;
        break;

    case DictFct_Journal:   /* PMSTA08429 - 280709 - PMO */
        loadOrderFromSessionFlg = TRUE; /* PMSTA09451 - DDV - 100303 */
        loadExternalPosFromSessionFlg = TRUE; /* PMSTA11101-CHU-110201 */
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = TRUE;
        break;

    case DictFct_OpList:    /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
    case DictFct_Perfo:     /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
    case DictFct_OpHist:    /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = TRUE;
        break;

    case DictFct_Archive:
        insertOpFlg = TRUE;
        break;

    case DictFct_MultiValo:
    case DictFct_CopyOperation:
    case DictFct_SynthAdmin:
    case DictFct_DisplayChrono:
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    case DictFct_PerformanceAnalysis:
        insertExtOpFlg = TRUE;
    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
        checkInstrFlg = FALSE;
        break;


    case DictFct_BenchStorage:
        if (IS_NULLFLD(domainPtr, A_Domain_DfltFlg) == TRUE ||
            GET_FLAG(domainPtr, A_Domain_DfltFlg) == FALSE)
        {
            insertExtOpFlg = TRUE;
        }
        break;

    case DictFct_CurrencyModify:
        insertExtOpFlg = TRUE;
        break;

    default: /* all flags already initialized by default */
        break;

    }

    /* ************************************************ *
     * <BEGIN> MULTISELECT INPUT PARAMETERS DESCRIPTION *
     * ************************************************ */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&PosVal,			PosVal},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_TaxLot,		    A_TaxLot},          /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotInitial,  A_TaxLotInitial},   /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotPicking,  A_TaxLotPicking},   /* PMSTA-36008 - 230519 - vkumar */
                    {&ExtTaxLot,        ExtTaxLot },        /* PMSTA-31342 - SANAND � 180528 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;

    }
    break;

    case DictFct_MultiValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CheckStratValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrChrono,	A_InstrChrono},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_TaxLot,         A_TaxLot},                        /* PMSTA-34116 - 220219 - vkumar */
                    {&A_TaxLotInitial,  A_TaxLotInitial},                 /* PMSTA-34116 - 220219 - vkumar */
                    {&A_TaxLotPicking,  A_TaxLotPicking},                /* PMSTA-34295 - 220219 - SANAND / PMSTA-36008 - 230519 - vkumar */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Return:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&PosVal,			PosVal},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Perfo:
    case DictFct_FundValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Journal:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InterCond,		A_InterCond},
                    {&A_StandInstruct,	A_StandInstruct},
                    {&A_PlanDefinition, A_PlanDefinition},              /* PMSTA-21287 - CAS - 101015 */
                    {&A_PlanObjectiveHisto, A_PlanObjectiveHisto},      /* PMSTA-21287 - CAS - 101015 */
                    {&A_PlanInvestParamHisto, A_PlanInvestParamHisto},  /* PMSTA-21287 - CAS - 101015 */
                    {&A_FreeDepositHisto, A_FreeDepositHisto},          /* PMSTA-21287 - CAS - 101015 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_OpHist:
    case DictFct_OpList:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_TaxLot,		    A_TaxLot},          /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotInitial,  A_TaxLotInitial},   /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotPicking,  A_TaxLotPicking},   /* PMSTA-36008 - 230519 - vkumar */
                    {&ExtTaxLot,        ExtTaxLot },        /* PMSTA-31342 - SANAND � 180528 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CurrencyModify:
    case DictFct_CopyOperation:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Archive:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_SynthAdmin:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_PtfSynth,		 A_PtfSynth},
                    {&A_Ptf,			 A_Ptf},
                    {&A_PerfStorageParam,A_PerfStorageParam},
                    {&A_Instr,			 A_Instr},
                    {&S_PerfComputationPeriod, S_PerfComputationPeriod},
                    {&NullDynSt,		 NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
        role = DBA_ROLE_PTFSYNTH_ALL;
    }
    break;

    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
    {/* <PMSTA-22458 - cashwini - 160502 */
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
            { &A_Ptf, A_Ptf },
            { &A_Strat, A_Strat },
            { &A_Curr, A_Curr },
            { &A_ExchRate, A_ExchRate },
            { &A_Third, A_Third },
            { &A_ListCompo, A_ListCompo },
            { &A_ComplianceChrono, A_ComplianceChrono },
            { &NullDynSt, NullDynSt }
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;/* PMSTA-22458 - cashwini - 160502 > */

    case DictFct_DisplayChrono:
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_Curr,			A_Curr},
                    {&A_ExchRate,		A_ExchRate},
                    {&A_Third,			A_Third},
                    {&A_ListCompo,		A_ListCompo},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_BenchStorage:
    {
        if (GET_FLAG(domainPtr, A_Domain_DfltFlg) == TRUE)
        {
            static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Instr,			 A_Instr},
                    {&NullDynSt,		 NullDynSt}
            };
            loadPosParamDef = SV_LoadPosParamDef;
            role = DBA_ROLE_MULTISELECT_INSTR;
        }
        else
        {
            static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_Curr,			A_Curr},
                    {&A_ExchRate,		A_ExchRate},
                    {&A_Third,			A_Third},
                    {&A_ListCompo,		A_ListCompo},
                    {&NullDynSt,		NullDynSt}
            };
            loadPosParamDef = SV_LoadPosParamDef;
        }
    }
    break;

    case DictFct_PerformanceAnalysis:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_PerfAttrib,		A_PerfAttrib},
                    {&A_StandardPerf,	A_StandardPerf},
                    {&A_ExtRetAnalysis,	A_ExtRetAnalysis},
                    {&A_Instr,			A_Instr},
                    {&A_Grid,			A_Grid},
                    {&A_MktSSubSet,		A_MktSSubSet},
                    {&A_MktStruct,		A_MktStruct},
                    {&S_MktSegt,		S_MktSegt},
                    {&A_PerfEffectLink, A_PerfEffectLink},
                    {&A_PerfEffectDef,  A_PerfEffectDef},
                    {&A_EventSched,		A_EventSched},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CaseInquiry:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_CaseManagement,	A_CaseManagement},
                    {&A_CaseLink,      	A_CaseLink},
                    {&A_FctResult,		A_FctResult},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}

        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_DispChangeSet:          /* PMSTA-26250 - DDV - 170321 */
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_ChangeSet,           A_ChangeSet},
                    {&A_ChangeSetCompo,      A_ChangeSetCompo},
                    {&A_ChangeSetParticipant,A_ChangeSetParticipant},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_InstrRecommLevelStorage:  /* PMSTA-28705 - DDV - 180208 */
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_IrlInstrumentRule,      A_IrlInstrumentRule},
                    {&A_IrlInstrumentRuleCompo, A_IrlInstrumentRuleCompo},
                    {&A_IrlPortfolioRule,       A_IrlPortfolioRule},
                    {&A_IrlPortfolioRuleCompo,  A_IrlPortfolioRuleCompo},
                    {&A_IrlApplUserRule,        A_IrlApplUserRule},
                    {&A_IrlApplUserRuleCompo,   A_IrlApplUserRuleCompo},
                    {&NullDynSt,		    NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    default:
        break;
    } /* <END> MULTISELECT INPUT PARAMETERS DESCRIPTION */

    /* ************************************************** *
     * PROCESS SOME TREATMENTS BEFORE CALLING MULTISELECT *
     * ************************************************** */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CaseInquiry ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal)
    {
        /* PMSTA-26142 CMILOS 211019 */
        if ((ret = DBA_LoadPosInitBeforeMultiSelect(domainPtr, hierHeadPtr, *dbiConn,
                                                    &fromDateModif, &domTmpFromDate,
                                                    &tillDateModif, &domTmpTillDate)) != RET_SUCCEED)
        {
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            return ret;
        }

        /* PMSTA12427-CHU-110725 */
        if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis &&
            GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort)
        {
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            return(RET_SUCCEED);
        }
    }

    /* ********************************************* *
     * <BEGIN> ALLOCATE MULTISELECT INPUT STRUCTURES *
     * ********************************************* */
    if (loadPosParamDef != (DBA_LOADPOSPARAM_STP)NULL)
    {
        while ((*(loadPosParamDef[outputBlkNb].outputStLst) != NullDynSt) &&
            (loadPosParamDef[outputBlkNb].outputMatch != NullDynSt))
        {
            outputBlkNb++;
        }

        if (outputBlkNb > 0)
        {
            if ((outputStLst = (const DBA_DYNST_ENUM **)CALLOC(outputBlkNb, sizeof(const DBA_DYNST_ENUM *))) == NULL)
            {
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((outputMatch = (int *)CALLOC(outputBlkNb, sizeof(int))) == NULL)
            {
                FREE(outputStLst);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((data = (DBA_DYNFLD_STP **)CALLOC(outputBlkNb, sizeof(DBA_DYNFLD_STP *))) == NULL)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((rows = (int *)CALLOC(outputBlkNb, sizeof(int))) == NULL)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            for (i = 0; i < outputBlkNb; i++)
            {
                outputStLst[i] = loadPosParamDef[i].outputStLst;
                outputMatch[i] = (int)loadPosParamDef[i].outputMatch;
                data[i] = NULLDYNSTPTR;
                rows[i] = 0;
            }
        }
        else
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadPos: Initialization failed");
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(RET_GEN_ERR_PERSONAL);
        }
        multiStructInitFlg = TRUE;

    } /* <END> ALLOCATE MULTISELECT INPUT STRUCTURES */

    /* ********************************************** *
     * CALL MULTISELECT FOR VARIOUS FUNCTIONS *
     * ********************************************** */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    case DictFct_MultiValo:
    case DictFct_CheckStratValo:
    case DictFct_Return:
    case DictFct_Perfo:
    case DictFct_Journal:
    case DictFct_OpHist:
    case DictFct_OpList:
    case DictFct_CurrencyModify:
    case DictFct_CopyOperation:
    case DictFct_Archive:
    case DictFct_FundValo:
    case DictFct_DisplayChrono:
    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    case DictFct_BenchStorage:
    case DictFct_PerformanceAnalysis:
    case DictFct_CaseInquiry:               /* PMSTA07121 - DDV - 090312 */
    case DictFct_DispChangeSet:            /* PMSTA-26250 - DDV - 170321 */
    case DictFct_InstrRecommLevelStorage:  /* PMSTA-28705 - DDV - 180208 */
        dropTempTablesFlg = TRUE;
    case DictFct_SynthAdmin:
    {
        createLoadPosHierarchyFlg = TRUE;
        hierLinkAndUpdateFlg = TRUE;

        DATE_START_TIMER(2, TIMER_MASK_SQLC);

        if ((ret = DBA_CallMultiSelectForLoadPos(role,
            domainPtr,
            outputStLst,
            data,
            rows,
            *dbiConn)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }
    break;

    default:
        break;
    } /* <END> CALL MULTISELECT FOR VARIOUS FUNCTIONS */

    /* ***************************************************************************** *
     * <BEGIN> EXECUTE SOME INTERMEDIATE TREATMENTS BEFORE LOADING DATA IN HIERARCHY *
     * ***************************************************************************** */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CurrencyModify ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_BenchStorage ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo)
    {
        if ((ret = DBA_CheckDataBeforeLoadingHier(domainPtr, hierHeadPtr,
            outputStLst, outputMatch, outputBlkNb,
            data, rows, *dbiConn,
            fromDateModif, domTmpFromDate,
            tillDateModif, domTmpTillDate,
            &selPspNbr, &selPspTab)) != RET_SUCCEED)
        {
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* ****************************************************************** *
     * PMSTA-5595 - 190808 - PMO                                          *
     * Account positions mustn't be displayed in the valuation and        *
     * operation list. Technical positions too                            *
     * PMSTA-23908 - 040716 - PMO                                         *
     * Technical positions are removed for Positions History              *
     * ****************************************************************** */
    DBA_TreatAdjustmentAccountPosition(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* PMSTA-21783 - 111215 - PMO
     * For "Copy Operation", a "target" position of a portfolio transfer must not generate an operation
     */
    DBA_CopyOperationRemoveTargetPortfolioTransferPosition(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* fusion_e is now managed by the C code PMSTA-34515 - 310119 - PMO */
    DBA_PropagateFusionE(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* ********************************************** *
     * Create a hierarchy and distribute loaded data  *
     * ********************************************** */
    if (createLoadPosHierarchyFlg == TRUE)
    {
        /* REF10696 - DDV - 041206 */
        DBA_UpdateInterCondFlg(outputStLst, outputBlkNb, data, rows);

        if ((ret = DBA_LoadPosHierCreate(A_Domain,
            domainPtr,
            hierHeadPtr,
            outputBlkNb,
            data,
            rows,
            outputStLst,
            insertExtOpFlg,
            loadTaxLotFlg      /* PMSTA-28086 - CHU - 170919 */
        )) != RET_SUCCEED)
        {
            if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
            {
                /* Drop temporary tables and close connection */    /*BUG202-961112-DED*/
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
            }
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }

            /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* PMSTA-34116 - 220219 - vkumar - map tax lot initial ID */
    if (TRUE == loadTaxLotFlg &&
        static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_PTCCOnlySimulation &&                    /* PMSTA-34295 - 300319 - vkumar */
        TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)
    {
        /* to map negative tax lot initial IDs to corresponding tax lot */
        ret = mapTaxLotInitialId(*hierHeadPtr, domainPtr);
    }

    /* ******************************************************* *
     * <BEGIN> HANDLE OR ARRANGE AFTER THEIR LOAD IN HIERARCHY *
     * ******************************************************* */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_BenchStorage)
    {
        if ((ret = DBA_ArrangeDataAfterLoadingHier(domainPtr, hierHeadPtr,
            listPtf, listPtfNbr,
            data, rows, *dbiConn,
            selPspNbr, selPspTab)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }

            /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* *************************************************************** *
     * PMSTA09451 - DDV - 100303                                       *
     * Load session's orders and store them into hierachy.             *
     * They will be splitted by the process used for collected orders. *
     * *************************************************************** */

    if (loadOrderFromSessionFlg == TRUE)
    {
        if (GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_IncludeOrders &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_LoadSessionOrder(domainPtr, *hierHeadPtr, (int*)&dbiConn->getId())) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }

                /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
            SET_ENUM(domainPtr, A_Domain_CompDataEn, CompData_OnLine);
        }
    }

    /* ********************************************************************************** *
     * PMSTA11101-CHU-110201                                                              *
     * Load External Positions (Investments with status == EXTERNAL_POS_STATUS parameter) *
     * and store them into hierachy.                                                      *
     * They will be split by the process used for collected orders.                       *
     * ********************************************************************************** */
    if (loadExternalPosFromSessionFlg == TRUE)
    {
        if (GET_FLAG(domainPtr, A_Domain_IncludeExternalPosFlg) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_LoadSessionExternalPos(domainPtr, *hierHeadPtr, (int*)&dbiConn->getId(),
                TRUE, NULL, NULL)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }

                /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }
    }

    /* Clean temporary tables */
    if (dropTempTablesFlg == TRUE)
    {
        /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
        /* DBA_EndConnection(connectNo);  PMSTA12888 - DDV - 111006 */
        DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
        DATE_START_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ****************************************** *
     * Split and filter all orders and executions *
     * ****************************************** */
    if (splitExtOpBlockFlg == TRUE)
    {
        /* PMSTA00954 - RAK - 070214 - In case of collected ExtOp split them */
        FLAG_T	collectedExtOpFlg = FALSE;

        if ((ret = DBA_HierEltGetCollectedFlg(*hierHeadPtr, ExtOp, &collectedExtOpFlg)) == RET_SUCCEED &&
            collectedExtOpFlg == TRUE &&
            (GET_ID(domainPtr, A_Domain_InitialFctDictId) != DictFct_CheckHoldingConstraints /* && PMSTA03528-CHU-070822 not needed for Check Holding Constraints
             (GET_ID(domainPtr, A_Domain_InitialFctDictId) != DictFct_PreTradeCheckStrat ||	/-* [PG-POC] *-/
              GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)*/))				/* [PG-POC] */
        {
            if ((ret = DBA_SplitCollectedExtOp(domainPtr, *hierHeadPtr,
                /*insertOpFlg must be*/TRUE, insertPosFlg, insertBalPosFlg, /* PMSTA03528-CHU-070822 */
                keepOnlyPosMatchingPtfDimFlg,
                keepOnlyPosMatchingInstrDimFlg,
                listPtf, listPtfNbr)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }

        if (loadExternalPosFromSessionFlg == TRUE &&
            GET_FLAG(domainPtr, A_Domain_IncludeExternalPosFlg) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_SplitExternalPos(domainPtr, *hierHeadPtr,
                /*insertOpFlg must be*/TRUE, insertPosFlg, insertBalPosFlg, /* PMSTA03528-CHU-070822 */
                keepOnlyPosMatchingPtfDimFlg,
                keepOnlyPosMatchingInstrDimFlg,
                listPtf, listPtfNbr)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }

        if ((ret = DBA_SplitExtOpBlock(A_Domain, domainPtr, *hierHeadPtr,
            outputBlkNb, data, rows, outputStLst,
            insertOpFlg, insertPosFlg, insertBalPosFlg,
            keepOnlyPosMatchingPtfDimFlg,
            keepOnlyPosMatchingInstrDimFlg,
            addResultInHierFlg,
            (DBA_DYNFLD_STP **)NULL, NULL,
            (DBA_DYNFLD_STP **)NULL, NULL, listPtf, listPtfNbr, NULL, true)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* PMSTA13795 DDV - 120423 - Compute new cost value and keep only needed position after logical fusion */ /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */
    if (GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_OnLineMktValPL &&
        (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Valo ||
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OpHist)
        )
    {
        ret = DBA_UpdateCostPrice(*hierHeadPtr, domainPtr);

        if (ret != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
        DATE_STOP_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ****************************************************************** *
     * Set and make links used by function and update some position infos *
     * ****************************************************************** */
    if (hierLinkAndUpdateFlg == TRUE)
    {
        if ((ret = DBA_LoadPosHierLnkAndUpd(*hierHeadPtr, domainPtr, checkInstrFlg)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
        DATE_STOP_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ******************************* *
     * <BEGIN> PROCESS OTHER FUNCTIONS *
     * ******************************* */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_OrderList:			/* DVP2467 - 991216 - DDV */
    case DictFct_OrderGrouping:	/* REF11764 - RAK - 060330 */
    case DictFct_UpdateField:	    /*  HFI-PMSTA-35324-190328  */
    case DictFct_UpdateData:	    /*  HFI-PMSTA-35324-190328  */
    case DictFct_HierarchyGrouping:			/* PMSTA-40208 - sanand - 24092020 */
    {
        int            opByBatchNbr = 0, opRowCount = 0;
        int            remainOpNbr = 0, extOpNbr = 0;
        DATETIME_T      tmpDate;
        const bool      noDropForOrderListInTslMode = DictFct_OrderList == GET_ID(domainPtr, A_Domain_FctDictId) &&                    /* PMSTA-21617 - 101115 - PMO */
            TRUE == GET_FLAG(domainPtr, A_Domain_TSLPtfDimModifiedFlg);

        /* PMSTA08002 - DDV - 090428 - Apply security on dom_port before calling DBA_LoadOrders */
        if (IS_NULLFLD(domainPtr, A_Domain_DataProfId) == FALSE &&
            GET_ID(domainPtr, A_Domain_DataProfId) > 0 &&
            false == noDropForOrderListInTslMode)                           /* PMSTA-21617 - 101115 - PMO */
        {
            char           *buffer = NULL;

            if ((buffer = (char *)CALLOC(sizeof(char), 2048)) == NULL)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
			
			/*PMSTA-38118 - Function Order List is slow when used via OData . The below delete is not been called for the GUI/WUI and executes in ODATA call.
            This is been avoided for Order List only as the selected records constains DSP Checks and no record will be present to delete .*/
            if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_OrderList) {
				sprintf(buffer, "delete from #dom_port \n"
					"where id not in " /* PMSTA-20159 - TEB - 150624 */
					"( select p.id from %s p, %s dpc "  /* PMSTA-32753 - DLA - 180903 */
					"where (p.data_secu_prof_id = dpc.data_secu_prof_id"
					"    or p.data_secu_prof2_id = dpc.data_secu_prof_id)" /* PMSTA-14607 - LJE - 120713 */
					"  and dpc.data_profile_id = %" szFormatId" )",
					SCPT_GetViewName(Ptf, false).c_str(), /* PMSTA-26250  -DDV - 170523 */  /* PMSTA-32753 - DLA - 180903 */
					SCPT_GetViewName(DataProfCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
					GET_ID(domainPtr, A_Domain_DataProfId)); /* DLA - PMSTA08801 - 100209 */
				DBA_SqlExec(buffer, *dbiConn);
			}
            FREE(buffer);
        }

        /* REF5493 - DDV - 010216 - Put back null value in from or till date if needed */
        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

        /* Create and fill #dom_oper temporary table and creat tmp_oper (use by load proc) */
        DBA_LoadDomOperTable(domainPtr, *dbiConn);

        /* REF7560 - DDV - 020603 - Load and filter all operations from table ext_order */
        DBA_LoadOrders(hierHeadPtr, domainPtr, TRUE, *dbiConn);

        /* REF7560 - DDV - 020603 - Check number of ExtOp allready created */
        DBA_HierGetRecNbr((*hierHeadPtr), ExtOp, NULLFCT, &extOpNbr, /*TRUE*/FALSE); /* REF10530 - TEB - 060815 */ /* REF7264 - LJE - 020131 */

        /* REF5493 - DDV - 010216 - From and Till date are not mandatory from domain, */
        /* but they must be define for load procedure sel_exd_position */
        tmpDate.date = MAGIC_END_DATE;
        tmpDate.time = 0;

        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);

        /* Select Operations, positions, portfolios */
        /* and instruments by batch until #dom_oper is empty or */
        /* number of extop is bigger as ApplOpSearchRetRowCount */
        GEN_GetApplInfo(ApplOpSearchNbOpByBatch, &opByBatchNbr);
        GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);
        remainOpNbr = opByBatchNbr;

        while (remainOpNbr > 0 && extOpNbr < opRowCount)
        {

            if ((ret = DBA_LoadOperByBatch(hierHeadPtr, domainPtr,
                TRUE, /* filter ExtOp */
                &remainOpNbr, &extOpNbr, *dbiConn)) != RET_SUCCEED)
            {
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER) != RET_SUCCEED)
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }
        /* Drop temporary tables and close connection */        /* BUG202 - 961112 - DED */
        if (DBA_CreateTempTables(*dbiConn, DOM_OPER & TMP_OPER) != RET_SUCCEED)
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
    }
    break;

    /* REF9764 - TEB - 030107 */
    case DictFct_UnmatchedExecutionList:
    {
        DATETIME_T      tmpDate;

        /* Put back null value in from or till date if needed */
        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

        /* Create, fill and filter #vector_id temporary table */
        DBA_LoadVectorIdForUMEX(domainPtr, dbiConn->getId());

        /* REF9764 - TEB - 040405 - From and Till date are not mandatory from domain, */
        /* but they must be define for load procedure sel_exd_position */
        tmpDate.date = MAGIC_END_DATE;
        tmpDate.time = 0;

        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);

        /* Select un put in hierarchy the Unmatched Executions */
        if ((ret = DBA_LoadUMEX(hierHeadPtr, domainPtr, *dbiConn)) != RET_SUCCEED)
        {
            if (DBA_CreateTempTables(*dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);

            /* PMSTA-17695 - LJE - 140314 */
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }

        /* Drop temporary tables and close connection */
        if (DBA_CreateTempTables(*dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
    }
    break;

    /* REF9764 - CHU - 030113 */
    case DictFct_SearchMatchingOrder:
    default:
        break;
    }
    /* <END> PROCESS OTHER FUNCTIONS */

    DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */

    if (*hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
    {
        if ((ret = DBA_SetHierOptiPtr(*hierHeadPtr)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* RAK - REFBCV - 980916 - Book value don't exist in ptf synthetics ... */
    /* REF4307 - SSO - 000308 added DictFct_Return */
    if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_SynthAdmin
        && GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_Return)
    {
        if ((ret = OPE_SetExtPosBookVal(*hierHeadPtr, 0, NULL)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* Restore original portfolio dimension if different */
    if (initialDimPtfDict != NullEntity && initialDimPtfDict != GET_DICT(domainPtr, A_Domain_DimPtfDictId))
    {
        SET_DICT(domainPtr, A_Domain_DimPtfDictId, initialDimPtfDict);
    }

    if (multiStructInitFlg == TRUE)
    {
        FREE(outputStLst);
        FREE(outputMatch);
        FREE(data);
        FREE(rows);
    }
    MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_LoadPos2()
*
*   Description          : Load positions hierarchy
*
*                          - FOR FINANCIAL FUNCTION :
*
*                          Send requests to the server to retrieve positions,
*                          portfolio(s) and financial instrument(s) used by
*                          financial functions to calculate many results, start
*                          positions valorisations, etc...
*
*                          REM : positions, portfolios and financial
* 	                         instruments are loading according to a domain
*                                specifications (portfolio and financial
*                                instrument dimensions, status, dates, specific
*                                currency, consolidation rule, etc...)
*
*
*   Arguments            : inputSt     : input dynamic structure format
*                          inputData   : pointer on the input dynamic structure
*                          hierHeadPtr : pointer on hierarchy header pointer
* 			               listPtf     : pointer on a list of portfolio id's
* 			               listPtfNbr  : number of portfolio's in list
*                          listInstr     : pointer on a list of instrument id's
* 			               listInstrNbr  : number of instrument's in list
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : Oct.  94 - PEC
*   Last Modification    : 12.08.05 - PEC/DED - Added Strategy handling case
*			   06.03.96 - DED - Add new function "Currency Modif"
*                          17.04.96 - RAK - Function create hierarchy (and allocate header pointer)
*                                     if pointer is NULL, else use the received header pointer.
*			   DVP029  - 960510 - DED : Add new extensions on ExtPos
*			   BUG113  - 960830 - RAK : Make Main and Acct links
*			   DVP178+ - 960918 - PEC : Deadlock handling
*			   BUG202  - 961112 - DED : Drop and close connection after multiselect
*			   DVP249  - 961112 - PEC : DVP249
*			   DVP288  - 961205 - DED : Change Fus_Arg structure
*			   DVP261  - 961209 - RAK : Create #tmp_port
*			   DVP288  - 961211 - DED : Fusion -> only 2 blocks of data instead of 3
*			   DVP332  - 970123 - DED : Valo + Return : add new block 'pos_val'
*			   DVP445  - 970429 - RAK : Fusion : load instruments = new block
*			   DVP460  - 970515 - RAK : receive instruments list
*			   DVP474  - 970612 - XMT : Add extensions ToBalPos and ToInstr for PtfTransf
*			   DVP545  - 970721 - DED : Add function Copy Operations
*              DVP563  - 970821 - DED : Add new block 'A_InterCond' to all multiselect
*              BUG467  - 970822 - DED : RET_CODE for return of function
*			   DVP568  - 970827 - DED : Implement hierarchy portfolio
*			   REF875  - 971113 - DED : Correct doubles in hierarchy if fusion
*              REF1459 - 980318 - GRD : 2 new parameters for OPE_SetExtPosBookVal.
*              REF3489 - 990324 - RAK : Change load for DictFct_Return.
*              REF4145 - 991123 - CSY: load untill calc_ref_date for journal
*              REF4306 - 000221 - CSY: DisplayChrono
*              REF5246 - 001024 - CSY: eliminate some postions for return (futures,...)
*              REF9125 - 030902 - MCA: add load for PSP only for benchmarkStorage - instrument
*              REF9764 - 040107 - TEB
*              REF10744- 041108 - CHU : complete function rewrite
*                          Function completely rewritten and cut into generic subfunctions
*                          some explanation on actual main parts in LoadPos which are used
*                          considering current value of A_Domain_FctDictId :
*                          1. Initialize a bunch of flags
*                          2. Prepare input/output parameters for MultiSelect Call (loadPosParamDef)
*                          3. DBA_LoadPosInitBeforeMultiSelect() : treatments BEFORE MultiSelect
*                          4. DBA_CallMultiSelectForLoadPos()    : generic MultiSelect2()
*                          5. DBA_CheckDataBeforeLoadingHier()   : treatments BEFORE loading data into hierarchy
*                          6. DBA_LoadPosHierCreate()            : load Data into hierarchy
*                          7. DBA_ArrangeDataAfterLoadingHier()  : handle and arrange data after hierarchy loading
*                          8. DBA_SplitExtOpBlock()              : split blocks of ExtOps if necessary
*                          9. DBA_LoadPosHierLnkAndUpd()         : make links and update ExtPos records
*                         10. Treat other A_Domain_FctDictId not concerned by previous function calls
*                         11. Some global ending treatments and exit
*              PMSTA-5595 - 190808 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
*              PMSTA08429 - 280709 - PMO : Journal : In a Cash Portfolio, final stock becomes wrong when there is an order
*              PMSTA-21617 - 101115 - PMO : Order List - Wrong and probably useless call on portfolio security
*              PMSTA-21783 - 111215 - PMO : Copy operation on portfolio with portfolio transfer operation is failed
*              PMSTA-34515 - 310119 - PMO : Regression - UTP scope: PBA_PMSTA_8174 TaAutomator test case failed : incorrect positions generated
*
*************************************************************************/
RET_CODE DBA_LoadPos2(DBA_DYNFLD_STP  domainPtr,
    DBA_HIER_HEAD_STP *hierHeadPtr,
    DBA_DYNFLD_STP *listPtf,
    int             listPtfNbr,
    DBA_DYNFLD_STP *listInstr,
    int             listInstrNbr)
{
    int 				i;
    RET_CODE			ret = RET_SUCCEED;
    //DBA_HIER_HEAD_STP	*hierHeadPtr = (DBA_HIER_HEAD_STP *)argHierHeadPtr;

    int 				selPspNbr = 0;
    DBA_DYNFLD_STP		*selPspTab = NULLDYNSTPTR;

    DICT_T				initialDimPtfDict = NullEntity;

    DATETIME_T			domTmpFromDate;
    DATETIME_T			domTmpTillDate;
    FLAG_T				fromDateModif = FALSE;
    FLAG_T				tillDateModif = FALSE;
    int                         rowCountThreshold = 0;
    FLAG_T                      setMessage = FALSE;

    /* Multiselect input/output structures */
    DBA_LOADPOSPARAM_STP loadPosParamDef = (DBA_LOADPOSPARAM_STP)NULL;
    const DBA_DYNST_ENUM **outputStLst = (const DBA_DYNST_ENUM **)NULL;
    int                  *outputMatch = (int *)NULL;
    int                  outputBlkNb = 0;
    DBA_DYNFLD_STP       **data = (DBA_DYNFLD_STP **)NULL;
    int                  *rows = (int *)NULL;

    /* ROLE is only different for DictFct_SynthAdmin (UNUSED in other cases) */
    int					role = UNUSED;

    DbiConnection*      dbiConn = nullptr;

    /* Init flags default values */
    FLAG_T	insertExtOpFlg = FALSE; /* for use in DBA_LoadPosHierCreate() */
    FLAG_T	insertOpFlg = FALSE; /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	insertPosFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	insertBalPosFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	keepOnlyPosMatchingPtfDimFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	keepOnlyPosMatchingInstrDimFlg = FALSE; /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	addResultInHierFlg = TRUE;  /* for use in DBA_SplitExtOpBlock() */
    FLAG_T	checkInstrFlg = TRUE;  /* for use in DBA_LoadPosHierLnkAndUpd() */
    FLAG_T	loadOrderFromSessionFlg = FALSE; /* PMSTA09451 - DDV - 100303 */
    FLAG_T	loadExternalPosFromSessionFlg = FALSE; /* PMSTA11101-CHU-110201 */
    FLAG_T	loadTaxLotFlg = FALSE; /* PMSTA-28086 - CHU - 170912 */

    /* conditional function calls or actions */
    FLAG_T	createLoadPosHierarchyFlg = FALSE;
    FLAG_T	dropTempTablesFlg = FALSE;
    FLAG_T	splitExtOpBlockFlg = FALSE;
    FLAG_T	hierLinkAndUpdateFlg = FALSE;
    FLAG_T	multiStructInitFlg = FALSE;

    domTmpFromDate.date = (DATE_T)0;
    domTmpFromDate.time = (TIME_T)0;
    domTmpTillDate.date = (DATE_T)0;
    domTmpTillDate.time = (TIME_T)0;

    TAX_LOT_ACCOUNTING    taxLotAccounting = TAX_LOT_ACCOUNTING::NoTaxLot;                        /* PMSTA-34116 - 220219 - vkumar */
    GEN_GetApplInfo(ApplTaxLotAccountingEn, &taxLotAccounting);

    /* Check arguments */
    if (listPtfNbr != 0 && listPtf == NULLDYNSTPTR)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 0, FILEINFO);
        return(RET_GEN_ERR_INVARG);
    }

    if(SYS_IsStateShutdownRequested())
    {   /* PMSTA-54362 -JBC - 231130 */
        return RET_SYS_ERR_SIGINT;
    }

    MSG_StartFctTimerPmon("DBA_LoadPos"); /* PCC11124 - LJE - 090127 */

    /* Check current Function dict Id in domain */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
        /* DBA_LoadPos() will only work for following functions : */
    case DictFct_Valo:
    case DictFct_OpHist:
    case DictFct_OpList:
    case DictFct_CheckStratValo:
    case DictFct_ForexHedging:
        loadTaxLotFlg = (static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_None);                  /* PMSTA-34116 - 220219 - vkumar */
    case DictFct_Perfo:
    case DictFct_Journal:
    case DictFct_Archive:
    case DictFct_FundValo:
    case DictFct_Return: /* REF10899 - LJE - 050127 */
        splitExtOpBlockFlg = TRUE;
        /* no break */
    case DictFct_MultiValo:
    case DictFct_CurrencyModify:
    case DictFct_CopyOperation:
    case DictFct_OrderList:
    case DictFct_SynthAdmin:
    case DictFct_DisplayChrono:
    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    case DictFct_BenchStorage:
    case DictFct_PerformanceAnalysis:
    case DictFct_UnmatchedExecutionList:
    case DictFct_SearchMatchingOrder:
    case DictFct_OrderGrouping:		        /* REF11764 - RAK - 060330 */
    case DictFct_OrderNetting:              /* PMSTA-41312 - adarshn - 05082020 */
    case DictFct_UpdateField:		        /*  HFI-PMSTA-35324-190328  */
    case DictFct_UpdateData:		        /*  HFI-PMSTA-35324-190328  */
    case DictFct_CaseInquiry:		        /* PMSTA07121 - DDV - 090310 */
    case DictFct_DispChangeSet:            /* PMSTA-26250 - DDV - 170321 */
    case DictFct_InstrRecommLevelStorage:  /* PMSTA-28705 - DDV - 180208 */
    case DictFct_HierarchyGrouping:			/* PMSTA-40208 - sanand - 24092020 */
        break;

    default:
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadPos: Invalid function dict id");
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(RET_GEN_ERR_PERSONAL);
    }

    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(DBA_CONN_NOT_FOUND);
    }

    /* Update in database portfolio and instrument dimension */
    if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, *dbiConn, listPtf, listPtfNbr,
        listInstr, listInstrNbr, &initialDimPtfDict, hierHeadPtr)) != RET_SUCCEED)
    {
        DBA_EndConnection(&dbiConn);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(ret);
    }

    /* PMSTA12467 - DDV - 110808 - Connection leak correction*/
    if ((GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort || GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_NoCompute ) &&
        GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PreTradeCheckStrat &&
        GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PerformanceAnalysis) /* PMSTA12427-CHU-110722 */
    {
        DBA_EndConnection(&dbiConn);
        MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
        return(ret);
    }

    /* consider special cases for some flags */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    case DictFct_CheckStratValo:
    case DictFct_ForexHedging:
        loadOrderFromSessionFlg = TRUE; /* PMSTA09451 - DDV - 100303 */
        loadExternalPosFromSessionFlg = TRUE; /* PMSTA11101-CHU-110201 */
        insertBalPosFlg = FALSE;
        keepOnlyPosMatchingInstrDimFlg = TRUE;
        break;

    case DictFct_FundValo:
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = FALSE;
        break;

    case DictFct_Journal:   /* PMSTA08429 - 280709 - PMO */
        loadOrderFromSessionFlg = TRUE; /* PMSTA09451 - DDV - 100303 */
        loadExternalPosFromSessionFlg = TRUE; /* PMSTA11101-CHU-110201 */
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = TRUE;
        break;

    case DictFct_OpList:    /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
    case DictFct_Perfo:     /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
    case DictFct_OpHist:    /* PMSTA08429 - 280709 - PMO / REF11233 - DDV - 050829 - Remove REF10899 modification */
        insertOpFlg = TRUE;
        keepOnlyPosMatchingPtfDimFlg = TRUE;
        break;

    case DictFct_Archive:
    case DictFct_Return:        /* PMSTA-47578 - DDV - 220323 */
        insertOpFlg = TRUE;
        break;

    case DictFct_MultiValo:
    case DictFct_CopyOperation:
    case DictFct_SynthAdmin:
    case DictFct_DisplayChrono:
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    case DictFct_PerformanceAnalysis:
        insertExtOpFlg = TRUE;
    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
        checkInstrFlg = FALSE;
        break;


    case DictFct_BenchStorage:
        if (IS_NULLFLD(domainPtr, A_Domain_DfltFlg) == TRUE ||
            GET_FLAG(domainPtr, A_Domain_DfltFlg) == FALSE)
        {
            insertExtOpFlg = TRUE;
        }
        break;

    case DictFct_CurrencyModify:
        insertExtOpFlg = TRUE;
        break;

    default: /* all flags already initialized by default */
        break;

    }

    /* ************************************************ *
     * <BEGIN> MULTISELECT INPUT PARAMETERS DESCRIPTION *
     * ************************************************ */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&PosVal,			PosVal},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_TaxLot,		    A_TaxLot},          /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotInitial,  A_TaxLotInitial},   /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotPicking,  A_TaxLotPicking},   /* PMSTA-36008 - 230519 - vkumar */
                    {&ExtTaxLot,        ExtTaxLot },        /* PMSTA-31342 - SANAND � 180528 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;

    }
    break;
    case DictFct_ForexHedging:
    {
        /* some f them are not needed. remove later*/
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
					{&A_PayInstruct,	A_PayInstruct},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&PosVal,			PosVal},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_TaxLot,		    A_TaxLot},          
                    {&A_TaxLotInitial,  A_TaxLotInitial},   
                    {&A_TaxLotPicking,  A_TaxLotPicking},   
                    {&ExtTaxLot,        ExtTaxLot },       
                    {&A_HedgingRules, A_HedgingRules},
                    {&NullDynSt,		NullDynSt} 
        };
        loadPosParamDef = SV_LoadPosParamDef;

    }
    break;

    case DictFct_MultiValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CheckStratValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrChrono,	A_InstrChrono},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_TaxLot,         A_TaxLot},                        /* PMSTA-34116 - 220219 - vkumar */
                    {&A_TaxLotInitial,  A_TaxLotInitial},                 /* PMSTA-34116 - 220219 - vkumar */
                    {&A_TaxLotPicking,  A_TaxLotPicking},                /* PMSTA-34295 - 220219 - SANAND / PMSTA-36008 - 230519 - vkumar */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Return:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&PosVal,			PosVal},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&A_Op,		        A_Op},                          /* PMSTA-40491 - vkumar - 030920 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Perfo:
    case DictFct_FundValo:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_InterCond,		A_InterCond},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Journal:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InterCond,		A_InterCond},
                    {&A_StandInstruct,	A_StandInstruct},
                    {&A_PlanDefinition, A_PlanDefinition},              /* PMSTA-21287 - CAS - 101015 */
                    {&A_PlanObjectiveHisto, A_PlanObjectiveHisto},      /* PMSTA-21287 - CAS - 101015 */
                    {&A_PlanInvestParamHisto, A_PlanInvestParamHisto},  /* PMSTA-21287 - CAS - 101015 */
                    {&A_FreeDepositHisto, A_FreeDepositHisto},          /* PMSTA-21287 - CAS - 101015 */
                    {&S_StratLnk,        S_StratLnk},
                    {&A_StratElt,        A_StratElt},
                    {&A_Instr,			A_Instr},
                    {&A_StratHist,     A_StratHist},
                    {&A_Strat,         A_Strat},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_OpHist:
    case DictFct_OpList:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_TaxLot,		    A_TaxLot},          /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotInitial,  A_TaxLotInitial},   /* PMSTA-28086 - CHU - 170912 */
                    {&A_TaxLotPicking,  A_TaxLotPicking},   /* PMSTA-36008 - 230519 - vkumar */
                    {&ExtTaxLot,        ExtTaxLot },        /* PMSTA-31342 - SANAND � 180528 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CurrencyModify:
    case DictFct_CopyOperation:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&ExtOp,			ExtOp},
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_Archive:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Op,				A_Op},
                    {&ExtPos,			ExtPos},
                    {&ExtPos,			ExtPos},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_SynthAdmin:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_PtfSynth,		 A_PtfSynth},
                    {&A_Ptf,			 A_Ptf},
                    {&A_PerfStorageParam,A_PerfStorageParam},
                    {&A_Instr,			 A_Instr},
                    {&S_PerfComputationPeriod, S_PerfComputationPeriod},  /* PMSTA-50467 - JBC - 221112 */
                    {&NullDynSt,		 NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
        role = DBA_ROLE_PTFSYNTH_ALL;
    }
    break;

    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
    {/* <PMSTA-22458 - cashwini - 160502 */
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
            { &A_Ptf, A_Ptf },
            { &A_Strat, A_Strat },
            { &A_Curr, A_Curr },
            { &A_ExchRate, A_ExchRate },
            { &A_Third, A_Third },
            { &A_ListCompo, A_ListCompo },
            { &A_ComplianceChrono, A_ComplianceChrono },
            { &NullDynSt, NullDynSt }
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;/* PMSTA-22458 - cashwini - 160502 > */

    case DictFct_DisplayChrono:
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_Curr,			A_Curr},
                    {&A_ExchRate,		A_ExchRate},
                    {&A_Third,			A_Third},
                    {&A_ListCompo,		A_ListCompo},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_BenchStorage:
    {
        if (GET_FLAG(domainPtr, A_Domain_DfltFlg) == TRUE)
        {
            static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Instr,			 A_Instr},
                    {&NullDynSt,		 NullDynSt}
            };
            loadPosParamDef = SV_LoadPosParamDef;
            role = DBA_ROLE_MULTISELECT_INSTR;
        }
        else
        {
            static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&A_InstrPrice,		A_InstrPrice},
                    {&A_Curr,			A_Curr},
                    {&A_ExchRate,		A_ExchRate},
                    {&A_Third,			A_Third},
                    {&A_ListCompo,		A_ListCompo},
                    {&NullDynSt,		NullDynSt}
            };
            loadPosParamDef = SV_LoadPosParamDef;
        }
    }
    break;

    case DictFct_PerformanceAnalysis:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_PerfAttrib,		A_PerfAttrib},
                    {&A_StandardPerf,	A_StandardPerf},
                    {&A_ExtRetAnalysis,	A_ExtRetAnalysis},
                    {&A_Instr,			A_Instr},
                    {&A_Grid,			A_Grid},
                    {&A_MktSSubSet,		A_MktSSubSet},
                    {&A_MktStruct,		A_MktStruct},
                    {&S_MktSegt,		S_MktSegt},
                    {&A_PerfEffectLink, A_PerfEffectLink},
                    {&A_PerfEffectDef,  A_PerfEffectDef},
                    {&A_EventSched,		A_EventSched},
                    {&A_PerfCalcResult,		A_PerfCalcResult},/*PMSTA-53328 - SENTHIL - 140823*/
                    {&A_StoragePortfolioCompo,		A_StoragePortfolioCompo},   /*PMSTA-48232 - Vishnu - 02022023 */
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_CaseInquiry:
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_CaseManagement,	A_CaseManagement},
                    {&A_CaseLink,      	A_CaseLink},
                    {&A_FctResult,		A_FctResult},
                    {&A_Ptf,			A_Ptf},
                    {&A_Instr,			A_Instr},
                    {&NullDynSt,		NullDynSt}

        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_DispChangeSet:          /* PMSTA-26250 - DDV - 170321 */
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_ChangeSet,           A_ChangeSet},
                    {&A_ChangeSetCompo,      A_ChangeSetCompo},
                    {&A_ChangeSetParticipant,A_ChangeSetParticipant},
                    {&NullDynSt,		NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;

    case DictFct_InstrRecommLevelStorage:  /* PMSTA-28705 - DDV - 180208 */
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                    {&A_IrlInstrumentRule,      A_IrlInstrumentRule},
                    {&A_IrlInstrumentRuleCompo, A_IrlInstrumentRuleCompo},
                    {&A_IrlPortfolioRule,       A_IrlPortfolioRule},
                    {&A_IrlPortfolioRuleCompo,  A_IrlPortfolioRuleCompo},
                    {&A_IrlApplUserRule,        A_IrlApplUserRule},
                    {&A_IrlApplUserRuleCompo,   A_IrlApplUserRuleCompo},
                    {&NullDynSt,		    NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }
    break;
    case DictFct_CurrChangeReq:     /* PMSTA-39723 - LIK 10042020 */
    {
        static DBA_LOADPOSPARAM_ST SV_LoadPosParamDef[] = {
                        {&A_CurrencyChangeRequest,      A_CurrencyChangeRequest},
                        {&NullDynSt,		    NullDynSt}
        };
        loadPosParamDef = SV_LoadPosParamDef;
    }

    default:
        break;
    } /* <END> MULTISELECT INPUT PARAMETERS DESCRIPTION */

    /* ************************************************** *
     * PROCESS SOME TREATMENTS BEFORE CALLING MULTISELECT *
     * ************************************************** */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CaseInquiry ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal)
    {
        /* PMSTA-26142 CMILOS 211019 */
        if ((ret = DBA_LoadPosInitBeforeMultiSelect(domainPtr, hierHeadPtr, *dbiConn,
                                                    &fromDateModif, &domTmpFromDate,
                                                    &tillDateModif, &domTmpTillDate)) != RET_SUCCEED)
        {
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            return ret;
        }

        /* PMSTA12427-CHU-110725 */
        if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis &&
            GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort)
        {
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            return(RET_SUCCEED);
        }
    }

    /* ********************************************* *
     * <BEGIN> ALLOCATE MULTISELECT INPUT STRUCTURES *
     * ********************************************* */
    if (loadPosParamDef != (DBA_LOADPOSPARAM_STP)NULL)
    {
        while ((*(loadPosParamDef[outputBlkNb].outputStLst) != NullDynSt) &&
            (loadPosParamDef[outputBlkNb].outputMatch != NullDynSt))
        {
            outputBlkNb++;
        }

        if (outputBlkNb > 0)
        {
            if ((outputStLst = (const DBA_DYNST_ENUM **)CALLOC(outputBlkNb, sizeof(const DBA_DYNST_ENUM *))) == NULL)
            {
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((outputMatch = (int *)CALLOC(outputBlkNb, sizeof(int))) == NULL)
            {
                FREE(outputStLst);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((data = (DBA_DYNFLD_STP **)CALLOC(outputBlkNb, sizeof(DBA_DYNFLD_STP *))) == NULL)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            if ((rows = (int *)CALLOC(outputBlkNb, sizeof(int))) == NULL)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(RET_MEM_ERR_ALLOC);
            }

            for (i = 0; i < outputBlkNb; i++)
            {
                outputStLst[i] = loadPosParamDef[i].outputStLst;
                outputMatch[i] = (int)loadPosParamDef[i].outputMatch;
                data[i] = NULLDYNSTPTR;
                rows[i] = 0;
            }
        }
        else
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadPos: Initialization failed");
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(RET_GEN_ERR_PERSONAL);
        }
        multiStructInitFlg = TRUE;

    } /* <END> ALLOCATE MULTISELECT INPUT STRUCTURES */

    /* ********************************************** *
     * CALL MULTISELECT FOR VARIOUS FUNCTIONS *
     * ********************************************** */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_Valo:
    case DictFct_MultiValo:
    case DictFct_CheckStratValo:
    case DictFct_Return:
    case DictFct_Perfo:
    case DictFct_Journal:
    case DictFct_OpHist:
    case DictFct_OpList:
    case DictFct_CurrencyModify:
    case DictFct_CopyOperation:
    case DictFct_Archive:
    case DictFct_FundValo:
    case DictFct_DisplayChrono:
    case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
    case DictFct_CompositeMgr:
    case DictFct_PtfStorage:
    case DictFct_BenchStorage:
    case DictFct_PerformanceAnalysis:
    case DictFct_CaseInquiry:               /* PMSTA07121 - DDV - 090312 */
    case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
    case DictFct_InstrRecommLevelStorage :  /* PMSTA-28705 - DDV - 180208 */
    case DictFct_ForexHedging:
		dropTempTablesFlg = TRUE;
	case DictFct_SynthAdmin:
    case DictFct_CurrChangeReq:         /* PMSTA-39723 - LIK 10042020 */
	{
		createLoadPosHierarchyFlg = TRUE;
		hierLinkAndUpdateFlg = TRUE;

        DATE_START_TIMER(2, TIMER_MASK_SQLC);

        if ((ret = DBA_CallMultiSelectForLoadPos2(domainPtr,
                                                  outputStLst,
                                                  data,
                                                  rows,
                                                  *dbiConn)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }
    break;

    default:
        break;
    } /* <END> CALL MULTISELECT FOR VARIOUS FUNCTIONS */

    /* ***************************************************************************** *
     * <BEGIN> EXECUTE SOME INTERMEDIATE TREATMENTS BEFORE LOADING DATA IN HIERARCHY *
     * ***************************************************************************** */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CurrencyModify ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_BenchStorage ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_ForexHedging)
    {
        if ((ret = DBA_CheckDataBeforeLoadingHier(domainPtr, hierHeadPtr,
            outputStLst, outputMatch, outputBlkNb,
            data, rows, *dbiConn,
            fromDateModif, domTmpFromDate,
            tillDateModif, domTmpTillDate,
            &selPspNbr, &selPspTab)) != RET_SUCCEED)
        {
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* ****************************************************************** *
     * PMSTA-5595 - 190808 - PMO                                          *
     * Account positions mustn't be displayed in the valuation and        *
     * operation list. Technical positions too                            *
     * PMSTA-23908 - 040716 - PMO                                         *
     * Technical positions are removed for Positions History              *
     * ****************************************************************** */
    DBA_TreatAdjustmentAccountPosition(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* PMSTA-21783 - 111215 - PMO
     * For "Copy Operation", a "target" position of a portfolio transfer must not generate an operation
     */
    DBA_CopyOperationRemoveTargetPortfolioTransferPosition(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* fusion_e is now managed by the C code PMSTA-34515 - 310119 - PMO */
    DBA_PropagateFusionE(domainPtr, outputStLst, outputBlkNb, data, rows);

    /* ********************************************** *
     * Create a hierarchy and distribute loaded data  *
     * ********************************************** */
    if (createLoadPosHierarchyFlg == TRUE)
    {
        /* REF10696 - DDV - 041206 */
        DBA_UpdateInterCondFlg(outputStLst, outputBlkNb, data, rows);

        if ((ret = DBA_LoadPosHierCreate(A_Domain,
            domainPtr,
            hierHeadPtr,
            outputBlkNb,
            data,
            rows,
            outputStLst,
            insertExtOpFlg,
            loadTaxLotFlg      /* PMSTA-28086 - CHU - 170919 */
        )) != RET_SUCCEED)
        {
            if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
            {
                /* Drop temporary tables and close connection */    /*BUG202-961112-DED*/
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
            }
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }

            /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* PMSTA-34116 - 220219 - vkumar - map tax lot initial ID */
    if (TRUE == loadTaxLotFlg &&
        static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_PTCCOnlySimulation &&                    /* PMSTA-34295 - 300319 - vkumar */
        TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)
    {
        /* to map negative tax lot initial IDs to corresponding tax lot */
        ret = mapTaxLotInitialId(*hierHeadPtr, domainPtr);
    }

    /* ******************************************************* *
     * <BEGIN> HANDLE OR ARRANGE AFTER THEIR LOAD IN HIERARCHY *
     * ******************************************************* */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_BenchStorage)
    {
        if ((ret = DBA_ArrangeDataAfterLoadingHier(domainPtr, hierHeadPtr,
            listPtf, listPtfNbr,
            data, rows, *dbiConn,
            selPspNbr, selPspTab)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }

            /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* *************************************************************** *
     * PMSTA09451 - DDV - 100303                                       *
     * Load session's orders and store them into hierachy.             *
     * They will be splitted by the process used for collected orders. *
     * *************************************************************** */

    if (loadOrderFromSessionFlg == TRUE)
    {
        if (GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_IncludeOrders &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_LoadSessionOrder(domainPtr, *hierHeadPtr, (int*)&dbiConn->getId())) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }

                /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
            SET_ENUM(domainPtr, A_Domain_CompDataEn, CompData_OnLine);
        }
    }

    /* ********************************************************************************** *
     * PMSTA11101-CHU-110201                                                              *
     * Load External Positions (Investments with status == EXTERNAL_POS_STATUS parameter) *
     * and store them into hierachy.                                                      *
     * They will be split by the process used for collected orders.                       *
     * ********************************************************************************** */
    if (loadExternalPosFromSessionFlg == TRUE)
    {
        if (GET_FLAG(domainPtr, A_Domain_IncludeExternalPosFlg) == TRUE &&
            static_cast<DomainCashRealignMethodEn>GET_ENUM(domainPtr, A_Domain_CashRealignMethodEn)
                != DomainCashRealignMethodEn::Redemption &&
            static_cast<DomainCashRealignMethodEn>GET_ENUM(domainPtr, A_Domain_CashRealignMethodEn) 
                != DomainCashRealignMethodEn::NetOfAllAssets &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_LoadSessionExternalPos(domainPtr, *hierHeadPtr, (int*)&dbiConn->getId(),
                TRUE, NULL, NULL)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }

                /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }
    }

    /* Clean temporary tables */
    if (dropTempTablesFlg == TRUE)
    {
        /* Drop temporary tables and close connection */	/* BUG202 - 961112 - DED */
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
        /* DBA_EndConnection(connectNo);  PMSTA12888 - DDV - 111006 */
        DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
        DATE_START_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ****************************************** *
     * Split and filter all orders and executions *
     * ****************************************** */
    if (splitExtOpBlockFlg == TRUE)
    {
        /* PMSTA00954 - RAK - 070214 - In case of collected ExtOp split them */
        FLAG_T	collectedExtOpFlg = FALSE;

        if ((ret = DBA_HierEltGetCollectedFlg(*hierHeadPtr, ExtOp, &collectedExtOpFlg)) == RET_SUCCEED &&
            collectedExtOpFlg == TRUE &&
            (GET_ID(domainPtr, A_Domain_InitialFctDictId) != DictFct_CheckHoldingConstraints /* && PMSTA03528-CHU-070822 not needed for Check Holding Constraints
             (GET_ID(domainPtr, A_Domain_InitialFctDictId) != DictFct_PreTradeCheckStrat ||	/-* [PG-POC] *-/
              GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)*/))				/* [PG-POC] */
        {
            if ((ret = DBA_SplitCollectedExtOp(domainPtr, *hierHeadPtr,
                /*insertOpFlg must be*/TRUE, insertPosFlg, insertBalPosFlg, /* PMSTA03528-CHU-070822 */
                keepOnlyPosMatchingPtfDimFlg,
                keepOnlyPosMatchingInstrDimFlg,
                listPtf, listPtfNbr)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }

        if (loadExternalPosFromSessionFlg == TRUE &&
            GET_FLAG(domainPtr, A_Domain_IncludeExternalPosFlg) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            if ((ret = DBA_SplitExternalPos(domainPtr, *hierHeadPtr,
                /*insertOpFlg must be*/TRUE, insertPosFlg, insertBalPosFlg, /* PMSTA03528-CHU-070822 */
                keepOnlyPosMatchingPtfDimFlg,
                keepOnlyPosMatchingInstrDimFlg,
                listPtf, listPtfNbr)) != RET_SUCCEED)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }

        if ((ret = DBA_SplitExtOpBlock(A_Domain, domainPtr, *hierHeadPtr,
            outputBlkNb, data, rows, outputStLst,
            insertOpFlg, insertPosFlg, insertBalPosFlg,
            keepOnlyPosMatchingPtfDimFlg,
            keepOnlyPosMatchingInstrDimFlg,
            addResultInHierFlg,
            (DBA_DYNFLD_STP **)NULL, NULL,
            (DBA_DYNFLD_STP **)NULL, NULL, listPtf, listPtfNbr, NULL, true)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

    /* PMSTA13795 DDV - 120423 - Compute new cost value and keep only needed position after logical fusion */ /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */
    /* WEALTH-5194 - Deepthi -20240718 - For Reprocess PL method, in case of domain ccy not equal to Porfolio ccy,
                                         ref ccy updation and then logical fusion should be triggered */
    if ((GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_OnLineMktValPL
        || GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL) &&
        (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Valo ||
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OpHist)
        )
    {
        ret = DBA_UpdateCostPrice(*hierHeadPtr, domainPtr);

        if (ret != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
        DATE_STOP_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ****************************************************************** *
     * Set and make links used by function and update some position infos *
     * ****************************************************************** */
    if (hierLinkAndUpdateFlg == TRUE)
    {
        if ((ret = DBA_LoadPosHierLnkAndUpd(*hierHeadPtr, domainPtr, checkInstrFlg)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
        DATE_STOP_TIMER(4, TIMER_MASK_SQLC);
    }

    /* ******************************* *
     * <BEGIN> PROCESS OTHER FUNCTIONS *
     * ******************************* */
    switch (GET_ID(domainPtr, A_Domain_FctDictId))
    {
    case DictFct_OrderList:			/* DVP2467 - 991216 - DDV */
    case DictFct_OrderGrouping:	/* REF11764 - RAK - 060330 */
    case DictFct_UpdateField:	    /*  HFI-PMSTA-35324-190328  */
    case DictFct_UpdateData:	    /*  HFI-PMSTA-35324-190328  */
    case DictFct_HierarchyGrouping:	/* PMSTA-40208 - sanand - 24092020 */
    {
        int            opByBatchNbr = 0, opRowCount = 0;
        int            remainOpNbr = 0, extOpNbr = 0;
        DATETIME_T      tmpDate;
        const bool      noDropForOrderListInTslMode = DictFct_OrderList == GET_ID(domainPtr, A_Domain_FctDictId) &&                    /* PMSTA-21617 - 101115 - PMO */
            TRUE == GET_FLAG(domainPtr, A_Domain_TSLPtfDimModifiedFlg);

        /* PMSTA08002 - DDV - 090428 - Apply security on dom_port before calling DBA_LoadOrders */
        if (IS_NULLFLD(domainPtr, A_Domain_DataProfId) == FALSE &&
            GET_ID(domainPtr, A_Domain_DataProfId) > 0 &&
            false == noDropForOrderListInTslMode)                           /* PMSTA-21617 - 101115 - PMO */
        {
            char           *buffer = NULL;

            if ((buffer = (char *)CALLOC(sizeof(char), 2048)) == NULL)
            {
                if (multiStructInitFlg == TRUE)
                {
                    FREE(outputStLst);
                    FREE(outputMatch);
                    FREE(data);
                    FREE(rows);
                }
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
			
			/*PMSTA-38118 - Function Order List is slow when used via OData . The below delete is not been called for the GUI/WUI and executes in ODATA call.
            This is been avoided for Order List only as the selected records constains DSP Checks and no record will be present to delete .*/
            if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_OrderList) {
				sprintf(buffer, "delete from #dom_port \n"
					"where id not in " /* PMSTA-20159 - TEB - 150624 */
					"( select p.id from %s p, %s dpc "  /* PMSTA-32753 - DLA - 180903 */
					"where (p.data_secu_prof_id = dpc.data_secu_prof_id"
					"    or p.data_secu_prof2_id = dpc.data_secu_prof_id)" /* PMSTA-14607 - LJE - 120713 */
					"  and dpc.data_profile_id = %" szFormatId" )",
					SCPT_GetViewName(Ptf, false).c_str(), /* PMSTA-26250  -DDV - 170523 */  /* PMSTA-32753 - DLA - 180903 */
					SCPT_GetViewName(DataProfCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
					GET_ID(domainPtr, A_Domain_DataProfId)); /* DLA - PMSTA08801 - 100209 */
				DBA_SqlExec(buffer, *dbiConn);
			}
            FREE(buffer);
        }

        /* REF5493 - DDV - 010216 - Put back null value in from or till date if needed */
        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

			/* Create and fill #dom_oper temporary table and creat tmp_oper (use by load proc) */
			DBA_LoadDomOperTable(domainPtr, *dbiConn);

        /* REF7560 - DDV - 020603 - Load and filter all operations from table ext_order */
        DBA_LoadOrders(hierHeadPtr, domainPtr, TRUE, *dbiConn);

        /* REF7560 - DDV - 020603 - Check number of ExtOp allready created */
        DBA_HierGetRecNbr((*hierHeadPtr), ExtOp, NULLFCT, &extOpNbr, /*TRUE*/FALSE); /* REF10530 - TEB - 060815 */ /* REF7264 - LJE - 020131 */

        /* REF5493 - DDV - 010216 - From and Till date are not mandatory from domain, */
        /* but they must be define for load procedure sel_exd_position */
        tmpDate.date = MAGIC_END_DATE;
        tmpDate.time = 0;

        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);

        /* Select Operations, positions, portfolios */
        /* and instruments by batch until #dom_oper is empty or */
        /* number of extop is bigger as ApplOpSearchRetRowCount */
        GEN_GetApplInfo(ApplOpSearchNbOpByBatch, &opByBatchNbr);
        GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);
        remainOpNbr = opByBatchNbr;
	
	rowCountThreshold = (INT_T)((0.9) * opRowCount);
        while (remainOpNbr > 0 && extOpNbr < opRowCount)
        {
	    if (extOpNbr >= rowCountThreshold)
               setMessage = TRUE;
            if ((ret = DBA_LoadOperByBatch(hierHeadPtr, domainPtr,
                TRUE, /* filter ExtOp */
                &remainOpNbr, &extOpNbr, *dbiConn)) != RET_SUCCEED)
            {
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER) != RET_SUCCEED)
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
                return(ret);
            }
        }
	/* PMSTA-64896 LEK 290125 - serverlog message to inform that the search results are more than 90% of value set in OP_SEARCH_RET_ROW_COUNT application parameter  */
        if (setMessage == TRUE)
        {
            DICT_FCT_STP    dictFctInfo;
            DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);
            MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : Op Search results more than 90% of the value set in OP_SEARCH_RET_ROW_COUNT(Value : %2) ",
                NameType, dictFctInfo->name,
                IntType, opRowCount);

        }
        /* Drop temporary tables and close connection */        /* BUG202 - 961112 - DED */
        if (DBA_CreateTempTables(*dbiConn, DOM_OPER & TMP_OPER) != RET_SUCCEED)
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
    }
    break;

    /* REF9764 - TEB - 030107 */
    case DictFct_UnmatchedExecutionList:
    {
        DATETIME_T      tmpDate;

        /* Put back null value in from or till date if needed */
        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

        tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
        if (tmpDate.date == MAGIC_END_DATE)
            SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

        /* Create, fill and filter #vector_id temporary table */
        DBA_LoadVectorIdForUMEX(domainPtr, dbiConn->getId());

        /* REF9764 - TEB - 040405 - From and Till date are not mandatory from domain, */
        /* but they must be define for load procedure sel_exd_position */
        tmpDate.date = MAGIC_END_DATE;
        tmpDate.time = 0;

        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);

        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == TRUE)
            SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tmpDate);

        /* Select un put in hierarchy the Unmatched Executions */
        if ((ret = DBA_LoadUMEX(hierHeadPtr, domainPtr, *dbiConn)) != RET_SUCCEED)
        {
            if (DBA_CreateTempTables(*dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            DBA_EndConnection(&dbiConn);

            /* PMSTA-17695 - LJE - 140314 */
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }

        /* Drop temporary tables and close connection */
        if (DBA_CreateTempTables(*dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
    }
    break;

    /* REF9764 - CHU - 030113 */
    case DictFct_SearchMatchingOrder:
    default:
        break;
    }
    /* <END> PROCESS OTHER FUNCTIONS */

    DBA_EndConnection(&dbiConn); /* PMSTA12888 - DDV - 111006 */

    if (*hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
    {
        if ((ret = DBA_SetHierOptiPtr(*hierHeadPtr)) != RET_SUCCEED)
        {
            if (multiStructInitFlg == TRUE)
            {
                FREE(outputStLst);
                FREE(outputMatch);
                FREE(data);
                FREE(rows);
            }
            MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
            return(ret);
        }
    }

	/* RAK - REFBCV - 980916 - Book value don't exist in ptf synthetics ... */
	/* REF4307 - SSO - 000308 added DictFct_Return */
    /* PMSTA-37908 - adarshn - Book value don't exist in Order Netting */
	if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_SynthAdmin
		&& GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_Return
        && GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_OrderNetting)
	{
		if ((ret = OPE_SetExtPosBookVal(*hierHeadPtr, 0, NULL)) != RET_SUCCEED)
		{
			if (multiStructInitFlg == TRUE)
			{
				FREE(outputStLst);
				FREE(outputMatch);
				FREE(data);
				FREE(rows);
			}
			MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
			return(ret);
		}
	}

    /* Restore original portfolio dimension if different */
    if (initialDimPtfDict != NullEntity && initialDimPtfDict != GET_DICT(domainPtr, A_Domain_DimPtfDictId))
    {
        SET_DICT(domainPtr, A_Domain_DimPtfDictId, initialDimPtfDict);
    }

    if (multiStructInitFlg == TRUE)
    {
        FREE(outputStLst);
        FREE(outputMatch);
        FREE(data);
        FREE(rows);
    }
    MSG_StopAllFctTimerPmon(); /* PCC11124 - LJE - 090127 */
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_LoadPosForSynthAdmin()
*
*   Description          : Load positions hierarchy
*
*                          Send requests to the server to retrieve positions,
*                          portfolio(s) and financial instrument(s) used by
*                          synthetic calculation.
*
*                          A verification on portfolio last synthetic date is done,
*                          if it have change, the hierarchy isn't update and
*                          computation will be restart with domain initial dates.
*                          new portfolio information are copied in portfolio (hier updated)
*
*                          REM : positions, portfolios and financial
* 	                             instruments are loading according to a domain
*                                specifications (portfolio and financial
*                                instrument dimensions, status, dates, specific
*                                currency, consolidation rule, etc...)
*
*   Arguments            : inputData     : pointer on the input dynamic structure
*                          ptfPtr        : pointer on portfolio (for verification and update)
*                          hierHeadPtr   : pointer on hierarchy header pointer
* 			               listPtf       : pointer on a list of portfolio id's
* 			               listPtfNbr    : number of portfolio's in list
*                          listInstr     : pointer on a list of instrument id's
* 			               listInstrNbr  : number of instrument's in list
*
*
*   Return               : RET_SUCCEED, RET_DBA_ERR_SYNTHRECALC or error code
*
*   Creation Date        : REF5245 - REF5260 - RAK - 001012
*
*   Last Modification    : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
RET_CODE DBA_LoadPosForSynthAdmin(DBA_DYNST_ENUM  inputSt,
                                  DBA_DYNFLD_STP  inputData,
                                  DBA_DYNFLD_STP  ptfPtr,
                                  DBA_HIER_HEAD_STP *hierHeadPtr,
                                  DBA_DYNFLD_STP *listPtf,
                                  int             listPtfNbr,
                                  DBA_DYNFLD_STP *listInstr,
                                  int             listInstrNbr)
{
	RET_CODE	    ret;
    DICT_T	        initialDimPtfDict=0;
	DbiConnection*  dbiConn = nullptr;
    const DBA_DYNST_ENUM *outputStLst[] =   {&ExtOp, /* REF8844 - LJE - 030416 */
							                 &ExtOp,
							                 &ExtOp,
							                 &ExtPos, 		    /* REF2992 - suppress A_Op */
							                 &ExtPos,
							                 &A_Ptf,			    /* REF3489 - ! ptfIdx value */
							                 &A_Instr,
							                 &PosVal, 		    /* DVP332 - 970123 - DED */
							                 &A_InstrPrice,       /* DVP344 - 970218 - XDI */
							                 &A_InterCond,       /* DVP563 - 970821 - DED */
                                             &A_Op};

    int             i, j, outputBlkNb = 11;				    /* REF2992 - suppress A_Op */
	DBA_DYNFLD_STP  *data[11]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR,
				              NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR }; /* REF4026 - SSO - 991008 */
	int             rows[11]= {0,0,0,0,0,0,0,0,0,0,0};	        /* REF3947 - SSO - 990902 */
	int             ptfIdx=5;				            /* REF3489 - RAK - 990324 */


	/* Get a free connection in the connection list */
	if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

	/* Update in database portfolio and instrument dimension */
	if ((ret = DBA_LoadPosPtfInstrDimension(inputData,
                                            *dbiConn,
							                listPtf,
                                            listPtfNbr,
							                listInstr,
                                            listInstrNbr,
							                &initialDimPtfDict)) != RET_SUCCEED)
    {
		DBA_EndConnection(&dbiConn);
		return(ret);
    }

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

	if (DBA_MultiSelect2(FinAnalysis,
                         static_cast<int>(GET_DICT(inputData, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                         A_Domain,
                         inputData,
					     outputStLst,
                         data,
					     DBA_SET_CONN | DBA_NO_CLOSE,
					     UNUSED,
                         rows,
						 (int*)&dbiConn->getId(),
                         UNUSED) != RET_SUCCEED)
	{
		/* REF3668 - SSO - 990903 : if server, see if the client conn. is dead? */
		if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
		{
		    DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(inputData, A_Domain_FctDictId));
		    DBA_EndConnection(&dbiConn);
		    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
		    return(RET_DBA_ERR_DISCONNECTED);
		}

		/**** BEGIN DVP178+ ****/
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(FinAnalysis,
                                    static_cast<int>(GET_DICT(inputData, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                                    A_Domain,
						    	    inputData,
                                    outputStLst,
                                    data,
		                	    	DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
									(int*)&dbiConn->getId(),
                                    UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(inputData, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
			DBA_EndConnection(&dbiConn);
			return(ret);
		}
		/**** END   DVP178+ ****/
	}

	/* Drop temporary tables and close connection */        /* BUG202 - 961112 - DED */
    DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(inputData, A_Domain_FctDictId));
    DBA_EndConnection(&dbiConn);

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
	DATE_START_TIMER(4, TIMER_MASK_SQLC);

	if (ptfPtr != NULL) /* PMSTA06916 - LJE - 081009 */
	{
		/* ------------------------------------------------------- */
		/* Verify new last synthetic date - REF5260 - RAK - 001012 */
		/* ------------------------------------------------------- */
		if (data[ptfIdx] != NULLDYNSTPTR && data[ptfIdx][0] != NULLDYNST)
		{
			/* PMSTA02013 - RAK - 071112 : If hierarchy mode, find the parent portfolio */
			int ptfPos=0;
			if (GET_ENUM(inputData, A_Domain_LoadHierFlg) > LoadHierPtf_None)
			{
				while (ptfPos<rows[ptfIdx] && GET_ID(data[ptfIdx][ptfPos], A_Ptf_Id) != GET_ID(ptfPtr, A_Ptf_Id))
				{
					ptfPos++;
				}
				if (ptfPos>=rows[ptfIdx])
				{
					ptfPos=0;
				}
			}
			/* if last synthetic date aren't same, don't fill hierarchy */
			/* and restard computation with updated portfolio           */
			/* rem : data[ptfIdx][ptfPos] = new ptf                     */
			if (DATETIME_CMP(GET_DATETIME(data[ptfIdx][0], A_Ptf_SynthLastFinalDate),
							 GET_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate)) != 0)
			{
        		/* PMSTA02013 - RAK - 071112 : use ptfPos */
				/* Update portfolio */
				SET_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate,
					GET_DATETIME(data[ptfIdx][ptfPos], A_Ptf_SynthLastFinalDate));

				SET_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate,
					GET_DATETIME(data[ptfIdx][ptfPos], A_Ptf_SynthRecalcDate));

				/* Suppress loaded data */
				for (i=0; i<outputBlkNb; i++)
				{
					for (j=0; j<rows[i]; j++)
					{
						FREE_DYNST(data[i][j], *(outputStLst[i])); /* REF8844 - LJE - 030423 */
					}
					FREE(data[i]);
				}

				/* Restore original portfolio dimension if different */
				if (initialDimPtfDict != GET_DICT(inputData, A_Domain_DimPtfDictId))
				{
					SET_DICT(inputData, A_Domain_DimPtfDictId, initialDimPtfDict);
				}

				return(RET_DBA_ERR_SYNTHRECALC);
			}
			else
			{
				/* Suppress new portfolio from selection (it is already in hierarchy) and compute */
				FREE_DYNST(data[ptfIdx][0], A_Ptf);
				FREE(data[ptfIdx]);
				rows[ptfIdx] = 0;
			}
		}
	}

    /* WEALTH-4556 - DDV - 240220 - Avoid duplicate portfolio in hierarchy */
    if ((ret = DBA_VerifPtfInHier(*hierHeadPtr,
                                  &(data[ptfIdx]), &(rows[ptfIdx]), /* A_Ptf */
                                  NULL, NULL                        /* A_PtfPosSet */
                                 )) != RET_SUCCEED)
    {
        return(ret);
    }

    /* ---------------------------------------------- */
	/* Create a  hierarchy and distribute loaded data */
	/* ---------------------------------------------- */
	if ((ret = DBA_LoadPosHierCreate(inputSt,
                                     inputData,
                                     hierHeadPtr,
                                     outputBlkNb,
					                 data,
                                     rows,
                                     outputStLst,
                                     FALSE,
                                     FALSE      /* PMSTA-28086 - CHU - 170919 */
                                     )) != RET_SUCCEED)
    {
		return(ret);
    }

    /* ------------------------------------------------------------------- */
    /* Split and filter all orders and executions - REF7560 - DDV - 020724 */
    /* ------------------------------------------------------------------- */
    if ((ret = DBA_SplitExtOpBlock(inputSt,
                                   inputData,
                                   *hierHeadPtr,
                                   outputBlkNb,
                                   data,
                                   rows,
                                   outputStLst,
                                   FALSE, TRUE, TRUE, TRUE, FALSE, TRUE,
                                                   (DBA_DYNFLD_STP **) NULL, NULL,
                                                   (DBA_DYNFLD_STP **) NULL, NULL, listPtf, listPtfNbr, NULL, true)) != RET_SUCCEED)
    {
        return(ret);
    }

	/* ------------------------------------------------------------------ */
	/* Set and make links used by function and update some position infos */
	/* ------------------------------------------------------------------ */
	if ((ret = DBA_LoadPosHierLnkAndUpd(*hierHeadPtr, inputData, TRUE)) != RET_SUCCEED) /* REF7264 - DDV - 020325 - Compil C++ */
    {
		return(ret);
    }

    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

    if (*hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
	{
		ret = DBA_SetHierOptiPtr(*hierHeadPtr);
		if (ret != RET_SUCCEED)
			return(ret);
	}

	/* Restore original portfolio dimension if different */
	if (initialDimPtfDict != GET_DICT(inputData, A_Domain_DimPtfDictId))
	{
		SET_DICT(inputData, A_Domain_DimPtfDictId, initialDimPtfDict);
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SelectLastPtfSynth()
**
**  Description :   Select last portfolio synthetics
**
**  Arguments   :   hierHeadPtr	  pointer on synthetics hierarchy header
**  		    ptfId	  portfolio identifier
**  		    onlyOnePtfFlg TRUE if only one ptf synthetics are in hierarchy
**  		    initialDate
**  		    finalDate
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   REF2992 - RAK - 981230
**
*************************************************************************/
RET_CODE DBA_SelectLastPtfSynth(DBA_DYNFLD_STP	domainPtr,
				                DBA_DYNFLD_STP	*ptfDynTab,
				                int		ptfDynNbr,
				                DBA_DYNFLD_STP	**synthTab,
				                int 		*synthNbr)
{
	RET_CODE	ret=RET_SUCCEED;
	DbiConnection * dbiConn = nullptr;
	DICT_T		initialDimPtfDict=0;

	*synthNbr = 0;
	*synthTab = NULLDYNSTPTR;

	/* Get a free connection in the connection list */
	if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

	if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, *dbiConn,
						ptfDynTab, ptfDynNbr, NULLDYNSTPTR, 0,
						&initialDimPtfDict)) != RET_SUCCEED)
	{
		DBA_EndConnection(&dbiConn);
		return(ret);
	}

	ret = DBA_Select2(PtfSynth, UNUSED, A_Domain, domainPtr, A_PtfSynth, synthTab,
		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, synthNbr, (int*)&dbiConn->getId(), UNUSED);

	DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));

	DBA_EndConnection(&dbiConn);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpStdPerfPtfDate()
**
**  Description :   StandardPerf sorted by ObjId and Final date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_StandardPerf
**                  ptr2   pointer on dynamic structure type A_StandardPerf
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF8874 - YST - 030527
**
*************************************************************************/
STATIC int FIN_CmpStdPerfPtfDate(DBA_DYNFLD_STP *ptr1,
								 DBA_DYNFLD_STP *ptr2)
{
    int ret;

	if((ret = CMP_ID(GET_ID((*ptr1), A_StandardPerf_ObjId),
					 GET_ID((*ptr2), A_StandardPerf_ObjId))) == 0)
	{
		/* Descending dates (most recent first) */
		return(DATETIME_CMP(GET_DATETIME((*ptr2), A_StandardPerf_FinalDate),
							GET_DATETIME((*ptr1), A_StandardPerf_FinalDate)));
	}

	return(ret);

}

/************************************************************************
**
**  Function    :   DBA_SelectLastPerfData()
**
**  Description :   Select last performance data
**
**  Arguments   :   hierHeadPtr	  pointer on synthetics hierarchy header
**                  ptfDynTab	  array of portfolio identifiers
**                  ptfDynNbr      number of portfolios in the array
**                  synthTab      array of synthetic data (to be created - output)
**                  synthNbr      number of synthetic data in the array (to be created - output)
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   REF9923 - CHU - 040216
**
*************************************************************************/
RET_CODE DBA_SelectLastPerfData(DBA_DYNFLD_STP	domainPtr,
				                DBA_DYNFLD_STP	*ptfDynTab,
				                int				ptfDynNbr,
				                DBA_DYNFLD_STP	**synthTab,
				                int				*synthNbr)
{
	RET_CODE		ret=RET_SUCCEED;
	DICT_T			initialDimPtfDict=0;
	DBA_DYNFLD_STP	*standardPerfTab;
	int				standardPerfNbr = 0, i;
	ID_T			lastId = -1;
	*synthNbr = 0;
	*synthTab = NULLDYNSTPTR;

	standardPerfNbr = 0;
	standardPerfTab = NULLDYNSTPTR;

    DbiConnectionHelper dbiConnHelper;

	if (dbiConnHelper.isValidAndInit() == false)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

    DbiConnection *dbiConn = dbiConnHelper.getConnection();

	if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, *dbiConn, ptfDynTab, ptfDynNbr,
											NULLDYNSTPTR, 0, &initialDimPtfDict)) != RET_SUCCEED)
	{
		return(ret);
	}

	ret = DBA_Select2(StandardPerf, UNUSED, A_Domain, domainPtr, A_StandardPerf, &standardPerfTab,
		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, &standardPerfNbr, (int*)&dbiConn->getId(), UNUSED);

	if (standardPerfNbr >= ptfDynNbr)
	{
		/* Sort data on PtfId/Date */
		TLS_Sort((char *)standardPerfTab, standardPerfNbr, sizeof(DBA_DYNFLD_STP),
				(TLS_CMPFCT*)FIN_CmpStdPerfPtfDate, (PTR **)NULL, SortRtnTp_None);

		/* convert A_StandardPerf into A_PtfSynth */
		if (((*synthTab) = (DBA_DYNFLD_STP *)CALLOC(ptfDynNbr, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP *)NULL)
		{
			DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			DBA_FreeDynStTab(standardPerfTab, standardPerfNbr, A_StandardPerf);
			return(RET_MEM_ERR_ALLOC);
		}

		for (i=0; i < standardPerfNbr; i++)
		{
			if (lastId != GET_ID(standardPerfTab[i], A_StandardPerf_ObjId))
			{
				if (((*synthTab)[(*synthNbr)] = ALLOC_DYNST(A_PtfSynth)) == NULLDYNST)
				{
					DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					DBA_FreeDynStTab((*synthTab), (*synthNbr), A_PtfSynth);
					*synthTab = NULLDYNSTPTR;
					if (standardPerfNbr > 0)
						DBA_FreeDynStTab(standardPerfTab, standardPerfNbr, A_StandardPerf);
					return(RET_MEM_ERR_ALLOC);
				}

                DBA_SetDfltEntityFld(PtfSynth,  A_PtfSynth, (*synthTab)[(*synthNbr)]);

				SET_ID((*synthTab)[(*synthNbr)], A_PtfSynth_PtfId,
					GET_ID(standardPerfTab[i], A_StandardPerf_ObjId));

				SET_ID((*synthTab)[(*synthNbr)], A_PtfSynth_CurrId,
					GET_ID(standardPerfTab[i], A_StandardPerf_CurrId));

				SET_NUMBER((*synthTab)[(*synthNbr)], A_PtfSynth_FinalMktVal,
					GET_NUMBER(standardPerfTab[i], A_StandardPerf_FinalMktVal));

				lastId = GET_ID(standardPerfTab[i], A_StandardPerf_ObjId);
				(*synthNbr)++;
			}
		}

		if ((*synthNbr) != ptfDynNbr)
		{
			/* problem, not enough data */
			if ((*synthNbr) > 0)
				DBA_FreeDynStTab((*synthTab), (*synthNbr), A_PtfSynth);

			*synthTab = NULLDYNSTPTR;
			*synthNbr = 0;
		}
		DBA_FreeDynStTab(standardPerfTab, standardPerfNbr, A_StandardPerf);

	}

	DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SelectExchRateForPtfSynth()
**
**  Description :   Select exchange rates and add them in hierarchy.
**
**  Arguments   :   domainPtr	   domain structure pointer
**                  ptfDynTab	   portfolios identifier
**                  ptfDynNbr	   portfolios identifier number
**		            tempTablesFlg  TRUE if temporary tables must be treated, FALSE elsewhere
**		            connectNoPtr   connection nbr pointer (or NULL)
**			        tempTablesFlg  couldn't be FALSE if connectNoPtr isn't received
**		            hierHead	   hierarchy header pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   REF2992 - RAK - 990112
**  Modif.		:   REF3701 - RAK - 990519
**
*************************************************************************/
RET_CODE DBA_SelectExchRateForPtfSynth(DBA_DYNFLD_STP	 domainPtr,
				                       DBA_DYNFLD_STP	*ptfDynTab,
				                       int		         ptfDynNbr,
				                       char	             tempTablesFlg,
				                       DbiConnection&    dbiConn,
				                       DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE			ret=RET_SUCCEED;
	DBA_DYNFLD_STP		*exchRateTab=NULLDYNSTPTR;
	int 				exchRateNbr=0;
	DICT_T				initialDimPtfDict=0;
	FLAG_T				inverseFlg=FALSE;

    if(SYS_IsStateShutdownRequested())
    {   /* PMSTA-54362 -JBC - 231130 */
        return RET_SYS_ERR_SIGINT;
    }

	if (hierHead == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_SelectExchRateForPtfSynth",
			     "no hierarchy pointer");
		return(RET_GEN_ERR_INVARG);
	}

	if (tempTablesFlg == TRUE)
	{
		if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, dbiConn,
			ptfDynTab, ptfDynNbr, NULLDYNSTPTR, 0,
			&initialDimPtfDict)) != RET_SUCCEED)
		{
			return(ret);
		}
	}
	ret = DBA_Select2(ExchRate, UNUSED, A_Domain, domainPtr, A_ExchRate, &exchRateTab,
			  DBA_SET_CONN|DBA_NO_CLOSE, UNUSED, &exchRateNbr, (int*)&dbiConn.getId(), UNUSED);

	/* REF3701 - Do this inversion only one time !                  */
	/* It is possible to store the exchange rates in the database   */
	/* inversely relative to the present method. Required for EURO. */
	GEN_GetApplInfo(ApplExchInverseFlag, &inverseFlg);
	if (inverseFlg == TRUE)
		FIN_InverseExchRate(exchRateTab, exchRateNbr);

	if (tempTablesFlg == TRUE)
		DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));

	if (ret == RET_SUCCEED && exchRateNbr > 0 )
	{
		ret = DBA_AddHierRecordList(hierHead, exchRateTab, exchRateNbr, A_ExchRate, TRUE);
	}

	FREE(exchRateTab);

	return(ret);
}

/*******************************************************************************
**
**  Function    :  DBA_SelPtfByDomain()
**
**  Description :  Select ptf identifiers depending on domain informations
**
**  Arguments   :  domainPtr	pointer on domain structure
**		           ptfTabPtr	pointer on array of Io_Id records
**		           ptfNbrPtr	pointer on number of records in ptfTabPtr
**
**  Return      :  RET_SUCCEED or error code
**
**  Creation    :  REF3637 - RAK - 000308
**
**  Modif          REF5010 - SSO - 000828
**  Modif       :  REF5245 - RAK - 001114 - Return ptfTab and change name to DBA_SelPtfByDomain()
*******************************************************************************/
EXTERN RET_CODE DBA_SelPtfByDomain(DBA_DYNFLD_STP domainPtr,
								   DBA_DYNFLD_STP **ptfTabPtr,
								   int *ptfNbrPtr,
								   DBA_HIER_HEAD_STP hierHead)	/* REF9125 - RAK - 030916 */
{
	RET_CODE			ret=RET_SUCCEED;

    DbiConnectionHelper  dbiConnHelper;

    LOADHIERPTF_ENUM    saveLoadHierEn = (LOADHIERPTF_ENUM)GET_ENUM(domainPtr, A_Domain_LoadHierFlg);
    RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn = ReturnInParentPtfRule_Children;

    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        returnInParPtfRuleEn = ReturnInParentPtfRule_Parent;
    }
    else
    {
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);
    }

    if ((ret = DBA_FillDomPortByDomain(domainPtr, true, false, dbiConnHelper)) != RET_SUCCEED)
    {
        return(ret);
    }

#if 0
    if (dbiConnHelper.isValidAndInit() == false)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(RET_DBA_ERR_CONNOTFOUND);
	}

    LOADHIERPTF_ENUM    saveLoadHierEn = (LOADHIERPTF_ENUM)GET_ENUM(domainPtr, A_Domain_LoadHierFlg);
    RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn = ReturnInParentPtfRule_Children;

    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        returnInParPtfRuleEn = ReturnInParentPtfRule_Parent;
    }
    else
    {
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);
    }

    /* Retrieve Domain Portfolio Dimension */
	if (GET_DICT(domainPtr, A_Domain_DimPtfDictId) == 0)
		dimObject = NullEntity;
	else
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject);

	/* Error if load_hier_flg and 'all' portfolio */		/* REF399 - 971020 - DED */
	if (dimObject == NullEntity && GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
	{
		if ((GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderEntry ||
			GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_SessionsMonitoring) &&	/* PMSTA-30900 - RAK - 180514 */
			GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full) /* Uniquement pour le bottom-up approach */
		{
			MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
						 "Portfolio dimension 'All Portfolios' and 'Load Hierarchy' not allowed !");
		}
    }

    DATE_START_TIMER(2, TIMER_MASK_SQLC);
    /* REF9125 - RAK - 030916 - add DOM_STRAT */
    ret = DBA_CreateTempTables(*dbiConnHelper.getConnection() , DOM_STRAT | DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID);

	if (ret != RET_SUCCEED)
	{
	    /* SME REF2137 */
/*	    DBA_FilterMsgInfos2(connectNo, &ret,NULL); REF5010 - SSO - 000828 */
	    return ret;
	}
	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	/* If PORTFOLIO DIMENSION is a list */
	if (dimObject == List)
	{
		DBA_DYNFLD_STP aList = ALLOC_DYNST(A_List);

		/* Verify memory allocation */
		if (aList == NULL)
		{
            DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
			return(RET_MEM_ERR_ALLOC);
		}

        listId = GET_ID(domainPtr, A_Domain_PtfObjId);
        SET_ID(aList, A_List_Id, listId);

		/* Get the list record */
        if ((ret = DBA_Get2(List, UNUSED, A_List, aList, A_List, &aList,
                            UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
		{
			FREE_DYNST(aList, A_List);
            DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
			return(ret);
		}

		/* If the portfolio list is a constraint list, search list or hierarchic list */
		if ((nature = (LISTNAT_ENUM) GET_ENUM(aList, A_List_NatEn)) == ListNat_Constr ||
		     nature == ListNat_Search || nature == ListNat_Hierarch)
		{
	        if ((listEntDictId = GET_DICT(aList, A_List_EntityDictId)) == 0)
    		    listObject = NullEntity;
	        else
                DBA_GetObjectEnum(listEntDictId, &listObject);

			/* Insert portfolioes Ids from the Constraint List into #dom_port_synth */
            DBA_CheckConstList(listId, aList, &status);

            switch(status)
            {
                case CHK_LIST_NOT_CONST :
                    /***** NOTHING TO DO *****/
                    break;

                case CHK_LIST_NON_PERIODIC :
				case CHK_LIST_HIER_NON_PERIODIC : /* REF7397 - LJE - 020228 - Add */
                case CHK_LIST_MUST_BE_BUILT :       /* REF7397 - LJE - 020228 - Add */
                case CHK_LIST_HIER_MUST_BE_BUILT : /* REF125 - XDI - 971218 - Add */
                {
                    SetServerUserToOnGuard setServerUserToOn;          /* PMSTA-29656 - DDV - 180110 - This class set ServerUser to On and automatically set to Off when leaving the function */ /* PMSTA-33980 - LJE - 181206 */

                    /***** BUILD ENUM LIST FROM CONSTRAINT SCRIPT *****/
                    ret = SCPT_EvalCstList(CSTLIST_REBUILD_LIST_COMPO,
                                           listId,
                                           NULLSTR,
                                           listObject,
                                           0,
                                           NULLDYNST,
                                           dbiConnHelper.getConnection()->getId(),
                                           (FLAG_T*)NULL,
                                           (DBA_DYNFLD_STP**)NULL,
                                           (int *)NULL,
                                           (DATETIME_STP)NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */

                    /* REF3962 - SSO - 990910 */
                    if (ret != RET_SUCCEED)
                    {
                        FREE_DYNST(aList, A_List);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
                            MSG_LogMesg(
                                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                                "DBA_CreateTempTables failed");
                        return(ret);
                    }

                    /* NO BREAK because of insert is necessary ... */
                }

                case CHK_LIST_ALREADY_BUILT :

                    /***** BUILD dom_port FROM  list_compo & portfolio *****/
                    if ((buffer = (char *)CALLOC(1,2048)) == NULL) /* REF7264 - LJE - 020131 */
                    {
                        FREE_DYNST(aList, A_List);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			                MSG_LogMesg(
                                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					                "DBA_CreateTempTables failed");
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "  /* PMSTA-20159 - TEB - 150624 */ /*REF10722-BRO-060922*/
							"select lc.object_id, 0, null, 0 " /* MIGR R4.00 STEP6 - LJE - 020816 */
                            "from %s p, %s lc " /* PMSTA-32753 - DLA - 180903 */
                            "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is null and #MAIN_DLM_CHECK(p, portfolio) ", /* DLA - PMSTA08801 - 100209 */ /* PMSTA-24026 - DDV - 161122 */
                            SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                            SCPT_GetViewName(ListCompo, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                            listId);

	                 dbRet = DBA_SqlExec(buffer, *dbiConnHelper.getConnection());

                    FREE(buffer);
                    break;
            }
	    }

        FREE_DYNST(aList, A_List);
    }
    else if (dimObject == QuickSearch) /* REF4611 - RAK - 000501 - Quick search in Domain */
    {
		DBA_DYNFLD_STP      tascJobSt=NULL; /* PMSTA08246 - LJE - 090624 */
        DICT_T  entDictId;
        DBA_GetDictId(Ptf, &entDictId);

		/* PMSTA08246 - LJE - 090615 */
		if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef)   == TRUE  &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
		{
			if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL  &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED  && /* PMSTA-34200 - LJE - 190111 */
				tascJobSt != NULL                &&
				IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
			{
                DBA_DYNFLD_STP argument =  ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id)); /* PMSTA-11505 - LJE - 110713 */
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

					SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

				    if ((ret = DBA_Notif2(TascJob,
									    UNUSED,
									    Arg_Test,
									    argument,
									    DBA_SET_CONN|DBA_NO_CLOSE,
										dbiConnHelper,
									    UNUSED)) != RET_SUCCEED)
				    {
            			FREE_DYNST(argument, Arg_Test);
					    FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
   						    MSG_LogMesg(
							    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
								    "DBA_CreateTempTables failed");
					    return(ret);
				    }
                }
			}

			FREE_DYNST(tascJobSt, A_TascJob);
		}
		else
		{
			/* Insert portfolioes Ids from the Quick Search List into #dom_port */
			if ((ret = SERV_ListMgm(ListMgmFct_LoadPos,
									entDictId,
									0,
									GET_STRING(domainPtr, A_Domain_PtfListDef),
                                    *dbiConnHelper.getConnection(),
									nullptr)) != RET_SUCCEED)
			{
				/* REF3751 - SSO - 990623 more ret code tests */
                DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   					MSG_LogMesg(
						RET_GEN_ERR_PERSONAL, 1, FILEINFO,
							"DBA_CreateTempTables failed");
				return(ret);
			}
		}
    }
	else if (dimObject == DomainPtfCompo && domainPtr != NULL) /* PMSTA-36175 - PM Profile Phase1 changes - Kramadevi - 02072019*/
	{
        DBA_DYNFLD_STP      tascJobSt = NULL;

        if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TSLDimPort &&
            IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
        {
            if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED &&
                tascJobSt != NULL &&
                IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
            {
                DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));
                    SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

                    if ((ret = DBA_Notif2(TascJob,
                                          UNUSED,
                                          Arg_Test,
                                          argument,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConnHelper,
                                          UNUSED)) != RET_SUCCEED)
                    {
                        FREE_DYNST(argument, Arg_Test);
                        FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                        return(ret);
                    }
                    FREE_DYNST(argument, Arg_Test);
                }
            }
            FREE_DYNST(tascJobSt, A_TascJob);
        }
        else
        {
            if ((buffer = (char *)CALLOC(1, 2048)) != NULL)
            {
                sprintf(buffer, "delete from #dom_port ");
                ret = DBA_SqlExec(buffer, *dbiConnHelper.getConnection());

                if (ret == RET_SUCCEED)
                {
                    sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "
                            "select dpc.portfolio_id, 0, null, 0 "
                            "from %s dpc, %s p "
                            "where dpc.function_result_id=%" szFormatId" and p.id = dpc.portfolio_id ",
                            SCPT_GetViewName(DomainPtfCompo, false).c_str(),
                            SCPT_GetViewName(Ptf, false).c_str(),
                            GET_ID(domainPtr, A_Domain_FctResultId));

                    sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                    if (DBA_SqlExec(buffer, *dbiConnHelper.getConnection()) != RET_SUCCEED)
                    {
                        FREE(buffer);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                        return(ret);
                    }
                }
                FREE(buffer);
            }
        }
	}
#endif 

    /* Call select (s�curis� par l'init !) */
    /* REF5245 - RAK - 001114 */
    ret = DBA_Select2(Ptf,
                      UNUSED,
                      A_Domain,domainPtr,
                      A_Ptf, ptfTabPtr,
                      UNUSED, ptfNbrPtr, dbiConnHelper);

	/* REF9125 - RAK - 030916 */ /* REF9340 - DDV - 030925 - Don't load  PSP for Online, they will be added in hierarchy later */
	if (ret == RET_SUCCEED && hierHead != (DBA_HIER_HEAD_STP) NULL &&
	    (((DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage &&
          (COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine) ||
		 ((DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_SynthAdmin &&
           (COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_CompHistory)))
	{
		int	selPspNbr=0, selEventSchedNbr=0, recNbr;
		DBA_DYNFLD_STP	*selPspTab=NULLDYNSTPTR, *selEventSchedTab=NULLDYNSTPTR;
        FLAG_T           loadPSPAndEventSchedFlg=TRUE;
        DBA_DYNFLD_STP  *recTab=NULLDYNSTPTR;

        /* REF9055 - LJE - 031010 : Test if compute is from event scheduler's analyse */
        if ((COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplOld ||
            (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplaceExisting || /* PMSTA-26435 - LJE - 170316 */
            (COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplaceNonPermanent)
        {
          	if ((ret = DBA_ExtractHierEltRec(hierHead, A_EventSched, FALSE,
                                             NULLFCT, NULLFCT,
                                             &recNbr, &recTab)) == RET_SUCCEED &&
                 recNbr > 0)
            {
                FREE(recTab);
                loadPSPAndEventSchedFlg = FALSE;
            }

        }

        if (loadPSPAndEventSchedFlg) /* REF9055 - LJE - 031010 */
        {
            ret = DBA_SelectPSP(domainPtr, &dbiConnHelper.getConnection()->getId(), &selPspTab, &selPspNbr);

		    if (ret == RET_SUCCEED && selPspNbr > 0)
		    {
				/* filter PSP and add "survivor" in hier */
			    ret = DBA_FilterPSP(domainPtr,
								    hierHead,
								    *ptfTabPtr,
								    *ptfNbrPtr,
								    Ptf,
					   			    selPspTab,
								    selPspNbr);
		    }
			else
			{
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_SelectPSP no PSP selected ... ");
			}

		    /* select event scheduler with nature EventSchedNat_PerfData */
		    /* on ptf and psp (use #dom_port), and add them in hierarchy */
		    /* they will be read in FIN_GetPeriodPerfAttrib() */
		    if (ret == RET_SUCCEED)
		    {
			    ret = DBA_Select2(EventSched, UNUSED,
					              NullDynSt, NULLDYNST,
					              A_EventSched,
					              &selEventSchedTab,
					              UNUSED,
					              &selEventSchedNbr,
                                  dbiConnHelper);

			    if (ret == RET_SUCCEED && selEventSchedNbr > 0)
			    {
				    ret = DBA_AddHierRecordList(hierHead, selEventSchedTab, selEventSchedNbr, A_EventSched, TRUE);

				    if (ret != RET_SUCCEED)
				    {
					    DBA_FreeDynStTab(selEventSchedTab, selEventSchedNbr, A_EventSched);
				    }
				    else
					    FREE(selEventSchedTab);
			    }
		    }

            if (returnInParPtfRuleEn != ReturnInParentPtfRule_Children &&
                GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage &&
                GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_FromParent &&
                GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy)
            {
                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_FromParent);

                DBA_FreeDynStTab((*ptfTabPtr), (*ptfNbrPtr), A_Ptf);
                (*ptfNbrPtr) = 0;
                (*ptfTabPtr) = NULL;

                ret = DBA_Select2(Ptf, UNUSED, A_Domain, domainPtr,
                                  A_Ptf, ptfTabPtr,
								  UNUSED, ptfNbrPtr, dbiConnHelper);

                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, saveLoadHierEn);
            }
        }
	}

	/* PMSTA-16590 - CHU - 140505 */
	if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort &&
		(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat ||
		 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
		 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder)
		)
	{
        ret = DBA_TransferDomPortToTSL(&hierHead, domainPtr, dbiConnHelper);
	}

    /* PMSTA-50467 - JBC - 221112 perf_computation_period */
    if (hierHead != nullptr && 
        ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Return     ||
          GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
		  GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage))
		)
	{
        DBA_DYNFLD_STP	* sCompPeriodTab=NULLDYNSTPTR;
        int	sCompPeriodNb = 0;
        MemoryPool mp;
        DBA_DYNFLD_STP selArg = mp.allocDynst(FILEINFO,Sel_Arg);
        SET_DATETIME(selArg,Sel_Arg_FromDate,GET_DATETIME(domainPtr,A_Domain_InterpFromDate));
        SET_DATETIME(selArg,Sel_Arg_TillDate,GET_DATETIME(domainPtr,A_Domain_InterpTillDate));
        SET_FLAG_FALSE(selArg,Sel_Arg_Flag1);

		/* WEALTH-6600 - JBC - 20240429 */
		/* due to sproc dependency issues in extended_pos, perf_storage_param sel_sh_perf_comp_period_by_dp is in port_synth object */
        if((ret = dbiConnHelper.dbaSelect(PtfSynth,UNUSED,selArg,S_PerfComputationPeriod,&sCompPeriodTab,&sCompPeriodNb)) == RET_SUCCEED
            && sCompPeriodNb > 0)
        {
            if((ret = DBA_AddHierRecordList(hierHead, sCompPeriodTab, sCompPeriodNb, S_PerfComputationPeriod, TRUE)) != RET_SUCCEED)
			{
				DBA_FreeDynStTab(sCompPeriodTab, sCompPeriodNb, S_PerfComputationPeriod);
			}
            else
            {
                FREE(sCompPeriodTab);
            }
        }
        DBA_MergePerfCompPeriods(hierHead,domainPtr,(*ptfTabPtr),(*ptfNbrPtr));
	}

    /* Remove temporary table and stop connection */
    DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
    if ((ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT)) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   		MSG_LogMesg(
            RET_GEN_ERR_PERSONAL, 1, FILEINFO,
				"DBA_CreateTempTables failed");

    return(ret);
}

/************************************************************************
**  Function             : DBA_LoadPosHierLnkAndUpd()
**
**  Description          : Make hierarchy links and update ExtPos records
**			   according to current function
**
**  Arguments            : hierHeadPtr	hierarchy header pointer
**			   domainPtr    domain structure pointer
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		 : REF182 - RAK - 960915 (decomposed from DBA_LoadPos())
**  Modif            : REF7560 - DDV - 020620 - Add a parameter to indicate if Instrument block must be check
**
*************************************************************************/
RET_CODE DBA_LoadPosHierLnkAndUpd(DBA_HIER_HEAD_STP hierHeadPtr,
                                  DBA_DYNFLD_STP    domainPtr, /* REF7264 - LJE - 020131 */
                                  FLAG_T            checkInstrFlg) /* REF7560 - DDV - 020620 */
{
	RET_CODE	retCd=RET_SUCCEED;
	DBA_FCTLNK_ST	fctLnkSt;		/* links state structure */

	/* ---------------------------------------------------- */
	/* Initialize links state depending on current function */
	/* ---------------------------------------------------- */
	DBA_FctLnkInitState(domainPtr, &fctLnkSt);

	/* ------------------------------------------------------------------------------ */
	/* Make some links (they are necessary for DBA_UpdExtPosFld() function)           */
	/* - ExtPos_A_Instr_Ext for ALL functions                                         */
	/* - A_Ptf_HierPtf_Ext and ExtPos_A_Ptf_Ext for some fct in case of ptf hierarchy */
	/* ------------------------------------------------------------------------------ */
	if ((retCd = DBA_FctLnkFirst(hierHeadPtr, &fctLnkSt, TRUE, NULLDYNST, NULLDYNST)) != RET_SUCCEED)
		return(retCd);

	/* Make "first" links only                                    */
	/* makeLnkFlg is set to TRUE if at least on link is necessary */
	if (fctLnkSt.makeLnkFlg == TRUE)
	{
		if ((retCd = DBA_MakeLinks(hierHeadPtr)) != RET_SUCCEED)
			return(retCd);
	}

    if (checkInstrFlg == TRUE && fctLnkSt.ExtPos_A_Instr == TRUE)
        DBA_CheckExtPosInstr(hierHeadPtr);

	/* REF6971 - LJE - 020207 : Position filtering */
	DBA_RemoveExtPosDomainFilter(hierHeadPtr, domainPtr, (DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_FctDictId)); /* REF7264 - DDV - 020325 - Compil C++ */

	/* -------------------------------------------------------------------------- */
	/* Update extended position fields depending on current function              */
	/* - create generic instruments                                               */
	/* - update some flags and natures and position nature (flow, initial, final) */
	/* - in case of portfolio hierarchy, change linked portfolio                  */
	/* -------------------------------------------------------------------------- */
	if ((retCd = DBA_UpdExtPosFld(hierHeadPtr, domainPtr, &fctLnkSt)) != RET_SUCCEED)
			return(retCd);

	/* ----------------------------------------------------------------------- */
	/* Make others links (main, accounting, ...) depending on current function */
	/* ----------------------------------------------------------------------- */
	/* set to unused the "first" links, they are already done */
	if ((retCd = DBA_FctLnkFirst(hierHeadPtr, &fctLnkSt, FALSE, NULLDYNST, NULLDYNST)) != RET_SUCCEED)
		return(retCd);

	if ((retCd = DBA_FctLnkOthers(hierHeadPtr, &fctLnkSt)) != RET_SUCCEED)
		return(retCd);

	/* makeLnkFlg is set to TRUE if at least on link is necessary */
	if (fctLnkSt.makeLnkFlg == TRUE)
	{
		/* Make links */
		if ((retCd = DBA_MakeLinks(hierHeadPtr)) != RET_SUCCEED)
			return(retCd);

	}

	/* Reset the "first" links, they are already done */
	if ((retCd = DBA_FctLnkFirst(hierHeadPtr, &fctLnkSt, TRUE, NULLDYNST, NULLDYNST)) != RET_SUCCEED)
		return(retCd);


	/* ----------------------------------------------- */
	/* Update Pos_Val Ref_* fields for domain currency */
	/* ----------------------------------------------- */
	if (fctLnkSt.updPosValFlg == TRUE)
	{
		/* REF171 - this was done before links are made */
		if ((retCd = DBA_UpdPosValFld(hierHeadPtr, domainPtr)) != RET_SUCCEED)
			return(retCd);
	}

	/* REF2950 - SSO - 981029 */
	if ((retCd = DBA_UpdBalPosForGenInstr(hierHeadPtr, domainPtr, &fctLnkSt)) != RET_SUCCEED)
	    return(retCd);

	return(RET_SUCCEED);
}

/************************************************************************
**  Function             :  DBA_LoadPosHierCreate()
**
**  Description          :  Create a hierDefNbr hierarchy and distribute loaded data.
**
**  Arguments            :  hierHeadPtr	pointer on hierarchy header pointer
**			                hierDefNbr   hierarchy definition number
**			                outputMatch  pointer on hierarchy element array
**                          outputBlkNb  number of hierarchy element
**                          data		pointer on record array to insert
**                          rows         record number on array
**                          outputStLst  record dynamic structure type
**                          insertExtOpFlg define if ExtOp must be inserted or not
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  REF182 - RAK - 960915 (decomposed from DBA_LoadPos())
**			                REF3985 - SSO - 990927 added	inputSt + inputData. Handle prices special filling
**
**  Modif.               :  REF5239 - RAK - 001024 - suppress hierDefNbr from arg list
**                          REF7560 - DDV - 020613 - Add new parameter insertExtOpFlg
**                          PMSTA-10070 - LJE - 110210 - now extern
**
*************************************************************************/
RET_CODE DBA_LoadPosHierCreate(DBA_DYNST_ENUM       inputSt,
		                       DBA_DYNFLD_STP       inputData,
		                       DBA_HIER_HEAD_STP   *hierHeadPtr,
		                       int                  outputBlkNb,
		                       DBA_DYNFLD_STP       **data,
		                       int                  *rows,
		                       const DBA_DYNST_ENUM **outputStLst,
                               FLAG_T               insertExtOpFlg,
                               FLAG_T               loadTaxLotFlg) /* PMSTA-28086 - CHU - 170919 */
{
	int		i, j;
	RET_CODE	ret=RET_SUCCEED;

	/* If necessary, create hierarchy */
	/* DVP023 - 960417 - RAK */
	if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
	{
		if ((*hierHeadPtr = DBA_CreateHier())==NULL)    /* REF5239 - RAK - 001025 */
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			            "DBA_LoadPosHierCreate: Cannot create hierarchy");
			ret = RET_DBA_ERR_MD;
		}
	}

	/* Distribute loaded data (if creation is ok) */
	for (i=0; i<outputBlkNb && ret == RET_SUCCEED; i++)
	{
		/* REF3985 - SSO - 990927 */

		if (inputSt == A_Domain)
        {
		    if (*(outputStLst[i]) == A_InstrPrice)
		    {
		        ret = DBA_PriceValidity(inputData, data[i], rows[i]);
		    }

		    /* PMSTA05878 - DDV - update end_d and end validity date */
		    /* PMSTA08584 - DDV - the function has been modifed to remove invalid flows for journal and event generation */
            if (*(outputStLst[i]) == A_InterCond)
		    {
			    DBA_UpdInterCondEndDate(data[i], rows[i], inputData);
		    }
        }

		if (ret == RET_SUCCEED && outputStLst[i] != NULL && *(outputStLst[i]) > InvalidDynSt && *(outputStLst[i]) < LASTDYNST)
		{
            if ((*(outputStLst[i]) == ExtOp && insertExtOpFlg == FALSE) /* REF7560 - DDV - 020613 - insert ExtOp only if parameter is TRUE */
                || ((*(outputStLst[i]) == A_TaxLotInitial || *(outputStLst[i]) == A_TaxLot) && loadTaxLotFlg == FALSE)
                )
            {
                continue;
            }

			ret = DBA_AddHierRecordList((*hierHeadPtr), data[i], rows[i], *(outputStLst[i]), TRUE);
		}
	}

    for (j = 0; j < outputBlkNb; j++)
    {
        if (*(outputStLst[j]) == ExtOp)
        {
            if (insertExtOpFlg == TRUE) /* REF7560 - DDV - 020613 - free ExtOp array only if inserted in Hier */
                FREE(data[j]);
        }
        else if ((*(outputStLst[j]) == A_TaxLotInitial || *(outputStLst[j]) == A_TaxLot) && loadTaxLotFlg == FALSE)
        {   /* PMSTA-55531 - JBC - 20241030 */
            DBA_FreeDynStTab(data[j],rows[j],*(outputStLst[j]));
        }
        else
        {
            FREE(data[j]);
        }
    }

	return(ret);
}



/************************************************************************
**  Function             : DBA_TransferDomPortToTSL()
**
**  Description          : Read dom_port into pseudo TSL table
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : FPL-PMSTA11939-1105026
**
*************************************************************************/
RET_CODE    DBA_TransferDomPortToTSL(DBA_HIER_HEAD_STP   *hierHeadPtr,
                                     DBA_DYNFLD_STP       domainPtr,
                                     DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE	        ret = RET_SUCCEED;

    /* PMSTA13245 - DDV - 111205 - Add error message in the log */
    if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_TransferDomPortToTSL",
            "A_Domain_JobReference");
        return RET_GEN_ERR_INVARG;
    }

    /* PMSTA13245 - DDV - 111205 - Add error message in the log */
    if (IS_NULLFLD(domainPtr, A_Domain_DataProfId) == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_TransferDomPortToTSL",
            "A_Domain_DataProfId");
        return RET_GEN_ERR_INVARG;
    }

    ret = DBA_Notif2(TascJob
        , UNUSED
        , A_Domain
        , domainPtr
        , DBA_SET_CONN | DBA_NO_CLOSE
        , dbiConnHelper
        , UNUSED);

    return ret;
}

/************************************************************************
**  Function             : DBA_LoadPosPtfInstrDimension()
**
**  Description          : Init some table according to portfolio and instrument dimension
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : REF182 - RAK - 960915 (decomposed from DBA_LoadPos())
**			               REF3748 - DED - 990611
**				           WARNING: from now, if listPtf is supplied, and A_Domain_DimInstrDictId
**				           is not NULL, listInstr MUST be also supplied!
**                         REF5010 - SSO - 000828
**                         REF3690 - DED - 001101 : add test on fct_dict_id
**                         REF3926 - DED - 001103 : add test for all mandatory fields of A_Domain
**
*************************************************************************/
RET_CODE DBA_LoadPosPtfInstrDimension(DBA_DYNFLD_STP domainPtr,
				                             DbiConnection& dbiConn,
		                                     DBA_DYNFLD_STP *listPtf, /* SEE ABOVE WARNING */
		                                     int            listPtfNbr,
		                                     DBA_DYNFLD_STP *listInstr,
		                                     int            listInstrNbr,
				                             DICT_T	        *initialDimPtfDict,
                                             DBA_HIER_HEAD_STP * hierHeadPtr)
{
	DBA_DYNFLD_STP	        admArg=NULLDYNST, sList=NULLDYNST;
	OBJECT_ENUM	            dimObject, object, listObject;
	LISTNAT_ENUM	        nature;
	DICT_T	       	        dictId;
	RET_CODE	            ret;
	FLAG_T		            initRequestFlg = TRUE;	/* REF3141 - SSO - 980118  notif to do or not */
	FLAG_T		            ptfListHistoFlg = FALSE;   /* REF4306 - DDV - 000323 */
	DICT_T                  listEntDictId=0,entDictId;
    SERV_LISTMGMFCT_ENUM    listMgmFct = ListMgmFct_LoadPos;
    DbiConnectionHelper     dbiConnHelper(&dbiConn, false);

	/***** SET OBJECT_ENUM TO FinAnalysis ***** (PEN) *****/
	object = FinAnalysis;

    /* Add tests on all mandatory fields of A_Domain. Else we will get error message "procedure not found" in DBA_Notif
       and DBA_MultiSelect. Following fields must be supplied :
        - min status (should be filled by Default Values MD)
        - max status (should be filled by Default Values MD)
        - zero qty flag (should be filled by Default Values MD)
        - from date
        - function dict id
    */  /* REF3690 - 001101 - DED */    /* REF3926 - 001103 - DED */
    if (IS_NULLFLD(domainPtr, A_Domain_FctDictId) == TRUE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_LoadPosPtfInstrDimension()", "Function dict Id");
        return(RET_FIN_ERR_INVDATA);
    }

	DATE_START_TIMER(2, TIMER_MASK_SQLC);

    ret = DBA_CreateTempTables(dbiConn, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID | DOM_STRAT | DOM_THIRD_CURR); /*REF9125 MCA 030903*/ /* PMSTA06916 - LJE - 081113 */

	if (ret != RET_SUCCEED)
	{
		return ret;
	}
	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

    /* PMSTA-28705 - DDV - 180302 */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_InstrRecommLevelStorage)
	{
       DATE_START_TIMER(2, TIMER_MASK_SQLC);
       if ((ret = DBA_Notif(object,
                             UNUSED,
                             A_Domain,
                             domainPtr,
                             dbiConn,
                             DBA_SET_CONN | DBA_NO_CLOSE)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif() failed");
			return(ret);
		}

		DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

		return(RET_SUCCEED);
	}

    if (IS_NULLFLD(domainPtr, A_Domain_MinStatEn) == TRUE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_LoadPosPtfInstrDimension()", "Minimum status");
    	return(RET_FIN_ERR_INVDATA);
    }
    if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == TRUE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_LoadPosPtfInstrDimension()", "Maximum status");
    	return(RET_FIN_ERR_INVDATA);
    }
    if (IS_NULLFLD(domainPtr, A_Domain_ZeroQtyFlg) == TRUE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_LoadPosPtfInstrDimension()", "Zero quantity flag");
    	return(RET_FIN_ERR_INVDATA);
    }
    if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == TRUE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_LoadPosPtfInstrDimension()", "From date");
        return(RET_FIN_ERR_INVDATA);
    }

	/* REF2992 - RAK - 990112 */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
	    GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return)
	{
		DATE_START_TIMER(2, TIMER_MASK_SQLC);

		ret = DBA_CreateTempTables(dbiConn, PORT_SYNTH); /* DLA - PMSTA-11512 - 110322 */
		if (ret != RET_SUCCEED)
		{
			return ret;
		}

		DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	}

    /* REF9613 - LJE - 031103 */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis)
    {
        /* No position loaded in #dom_position the change mode fir SERV_ListMgm function */
        listMgmFct = ListMgmFct_LoadEvtGenInstr;
    }

    /* REF7758 - LJE - 020919 */
    if ((GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
         GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_DispChangeSet) &&  /* PMSTA-26250 - DDV - 170508 */
        IS_NULLFLD(domainPtr, A_Domain_DimEntityDictId) == FALSE &&
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimEntityDictId), &dimObject) == TRUE)
    {
        /* The dimension is in dim_entity_dict_id, the entity in dim_port_dict_id
           and the object in port_object_id */
        if (dimObject == One)
        {
            if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject) != TRUE)
	        {
		        DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
		        return(RET_GEN_ERR_INVARG);
            }
        }
        /* REF10976 - LJE - 050207 */
        else if (dimObject == QuickSearch)
        {
            listEntDictId = GET_DICT(domainPtr, A_Domain_DimPtfDictId);
        }


    }
	/* Retrieve Domain Portfolio Dimension */
	else if (GET_DICT(domainPtr, A_Domain_DimPtfDictId) == 0)
    {
		dimObject = NullEntity;
    }
	else if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject) != TRUE)
	{
		DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
		return(RET_GEN_ERR_INVARG);
    }

    /* REF4306 - Create temp table and set portfolio dimension and object_id for load */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_DisplayChrono ||
		GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_DisplayComplianceChrono || /* PMSTA-18759 - CHU - 150401 */
	    GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CompositeMgr ||
        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_BenchStorage || /* REF7423 - RAK - 020403 */
        (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage &&
		 GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged && /* REF7423 - MCA - 0209010 */
		 dimObject == List))
	{
        if ((ret=DBA_CreateTempTables(dbiConn, DOM_THIRD_CURR)) != RET_SUCCEED)
            return(ret);
        if ((ret=DBA_CreateTempTables(dbiConn, DOM_LISTCOMPO)) != RET_SUCCEED)
            return(ret);

        /* for DisplayChrono function, if the object_id is stored into instr_objectId,
           copy it into port_object_id to reuse standard code for portfolio list */
		if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_PtfStorage)
		{
   		COPY_DYNFLD(domainPtr, A_Domain, A_Domain_PtfObjId,
                    domainPtr, A_Domain, A_Domain_InstrObjId);

   		COPY_DYNFLD(domainPtr, A_Domain, A_Domain_PtfListDef,
                    domainPtr, A_Domain, A_Domain_InstrListDef);
		}
        if (dimObject == QuickSearch)
            listEntDictId = GET_DICT(domainPtr, A_Domain_DimInstrDictId);

        /* if hist_list_f is TRUE and list is historised then nothing to load into temporary tables */
       	if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE)
            ptfListHistoFlg = DBA_CheckIfListHistorised(GET_DICT(domainPtr, A_Domain_PtfObjId), UNUSED, UNUSED);

        /* No position loaded in #dom_position the change mode fir SERV_ListMgm function */
        listMgmFct = ListMgmFct_LoadEvtGenInstr;
    }

    if((GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis
        || GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return		/* PMSTA-50467 - JBC - 221112 */
        || GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin
        || GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage
        || GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo)        
        && dimObject == List)
    {
        /* if load_dim_port_hist_f is TRUE and list is historised then nothing to load into temporary tables */
       	if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE)
            ptfListHistoFlg = DBA_CheckIfListHistorised(GET_DICT(domainPtr, A_Domain_PtfObjId), UNUSED, UNUSED);
    }


	/* Error if load_hier_flg and 'all' portfolio */		/* REF399 - 971020 - DED */
	if (dimObject == NullEntity &&
		GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
		listPtfNbr == 0)
	{
		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full) /* Uniquement pour le bottom-up approach */
		{
			MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Portfolio dimension 'All Portfolios' and 'Load Hierarchy' not allowed !");
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			return(RET_GEN_ERR_PERSONAL);
		}
	}

	/* If PORTFOLIO DIMENSION is a list and no portfolio list available */
    /* REF4306 - DDV - 000323 - If a historised list must be loaded, nothing to do */
	if (dimObject == List && listPtfNbr == 0 && ptfListHistoFlg == FALSE)
	{
		admArg = ALLOC_DYNST(Adm_Arg);
		sList = ALLOC_DYNST(S_List);

		/* Verify memory allocation */
		if (admArg == NULL || sList == NULL)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(RET_GEN_ERR_INVARG);
		}

		COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, domainPtr, A_Domain, A_Domain_PtfObjId);

		/* Get the list record */
		if ((ret = DBA_Get2(List,
                            UNUSED,
                            Adm_Arg,
                            admArg,
				            S_List,
                            &sList,
                            UNUSED,
                            UNUSED,
                            UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(ret);
		}

		/* If the portfolio list is a constraint list, search list or hierarchic list */
		if ((nature = (LISTNAT_ENUM) GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
		     nature == ListNat_Search ||
             nature == ListNat_Hierarch)
		{
            /* Done before to treat all cases for DisplayChrono */
	        /* DICT_T      entDictId;

			DBA_GetDictId(Ptf, &entDictId);*/

	        if ((listEntDictId = GET_DICT(sList, S_List_EntityDictId)) == 0)
    		    listObject = NullEntity;
	        else
                DBA_GetObjectEnum(listEntDictId, &listObject);

			/* Insert portfolios Ids from the Constraint List into #dom_port */
            if ((ret = SERV_ListMgm(listMgmFct,
                                    listEntDictId,
                                    GET_ID(sList, S_List_Id),
                                    NULL,
                                    dbiConn,
                                    nullptr)) != RET_SUCCEED)
			{
			    /* REF3751 - SSO - 990623 more ret code tests */
			    DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			    FREE_DYNST(admArg, Adm_Arg);
			    FREE_DYNST(sList, S_List);
			    return(ret);
			}

			/* PMSTA06500 - DDV - 080425 - Avoid calling twice the procedure which expand the Ptf hierarchy */
			if (EV_NoPMSTA6500 == 1)
			{
	            /* REF4306 - DDV - 000229 - Process hierarchy_f and PPS, only if entity of list is portfolio */
				if (listObject == Ptf)
				{
					/* Call procedure to expand #dom_port with hierarchy child portfolios */
					/* Only if load_hierarchy_f from domina is TRUE - XDI */
					if (domainPtr != NULLDYNST &&
						GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
					{
						if ((ret = DBA_Notif2(object,
                                   			DBA_ROLE_HIERPTF,
                                   			A_Domain,       /* NullDynSt, *//* SKE 010223 */
                                   			domainPtr,      /* NULLDYNST, *//* SKE 010223 */
                                   			DBA_SET_CONN|DBA_NO_CLOSE,
											dbiConnHelper,
                                   			UNUSED)) != RET_SUCCEED)
						{
							/* REF3749 - SSO - 990706 */
							DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
							FREE_DYNST(admArg, Adm_Arg);
							FREE_DYNST(sList, S_List);
							MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
							return(ret);
						}
					}

					/* DVP479 - 970521 - PEC - Call a proc. to fill field port_pos_set_id in #dom_port table */
		  			if ((ret = DBA_Notif2(object,
						   DBA_ROLE_SCPT_DEF_CONTROL,
						   A_Domain,
						   domainPtr,
						   DBA_SET_CONN|DBA_NO_CLOSE,
                           dbiConnHelper,
						   UNUSED)) != RET_SUCCEED)
					{
						/* REF3749 - SSO - 990706 */
						DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
						FREE_DYNST(admArg, Adm_Arg);
						FREE_DYNST(sList, S_List);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
						return(ret);
					}
					/* DVP479 - 970521 - PEC */

		/* REF3748 - 990611 - DED : deactivated for dynamic list
					initRequestFlg = FALSE;* REF3141 - SSO - 980118*
		*/
				}
			}
		}

		FREE_DYNST(admArg, Adm_Arg);
		FREE_DYNST(sList, S_List);
	}
	else if (listPtf != NULLDYNSTPTR && listPtfNbr != 0)
	{
		/* Insert portfolioes Ids from given portfolio list into dom_port */
		if ((ret = SERV_InsDomTable("#dom_port", listPtf, listPtfNbr, dbiConn.getId())) != RET_SUCCEED)
		{
		    /* REF3751 - SSO - 990702 more ret code tests */
		    DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
		    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SERV_InsDomTable() failed");
		    return(ret);
		}

		/* PMSTA06500 - DDV - 080425 - Avoid calling twice the procedure which expand the Ptf hierarchy */
		if (EV_NoPMSTA6500 == 1)
		{
			/* Call procedure to expand #dom_port with hierarchy child portfolioes */
			if ((ret = DBA_Notif2(object,
							   DBA_ROLE_HIERPTF,
							   A_Domain,       /* NullDynSt, *//* SKE 010223 */
							   domainPtr,      /* NULLDYNST, *//* SKE 010223 */
							   DBA_SET_CONN|DBA_NO_CLOSE,
                               dbiConnHelper,
							   UNUSED)) != RET_SUCCEED)
			{
				/* REF3749 - SSO - 990706 */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
				return(ret);
			}

			/* DVP479 - 970521 - PEC - Call a proc. to fill field port_pos_set_id in #dom_port table */
			if ((ret = DBA_Notif2(object,
				   DBA_ROLE_SCPT_DEF_CONTROL,
				   A_Domain,
				   domainPtr,
				   DBA_SET_CONN|DBA_NO_CLOSE,
                   dbiConnHelper,
				   UNUSED)) != RET_SUCCEED)
			{
				/* REF3749 - SSO - 990706 */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
				return(ret);
			}
			/* DVP479 - 970521 - PEC */
		}

		/* Free memory allocation */
		/* DBA_FreeDynStTab(listPtf, listPtfNbr, Io_Id); */ 	/* DVP460 */

		initRequestFlg = FALSE;  /* REF3141 - SSO - 980118*/
	}
    else if (dimObject == QuickSearch) /* REF0014 - DDV - 000330 - Quick search in Domain */
    {
        if (listEntDictId == 0)
            DBA_GetDictId(Ptf, &entDictId);
        else
            entDictId = listEntDictId;

		/* PMSTA08246 - LJE - 090615 */
		if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef)   == TRUE  &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
		{
            DBA_DYNFLD_STP tascJobSt = ALLOC_DYNST(A_TascJob);
			if (tascJobSt != NULL  &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED && /* PMSTA-34200 - LJE - 190111 */
				tascJobSt != NULL                &&
				IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
			{
                DBA_DYNFLD_STP argument =  ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id)); /* PMSTA-11505 - LJE - 110713 */
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

					SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

				    if ((ret = DBA_Notif2(TascJob,
									    UNUSED,
									    Arg_Test,
									    argument,
									    DBA_SET_CONN|DBA_NO_CLOSE,
                                        dbiConnHelper,
									    UNUSED)) != RET_SUCCEED)
				    {
            			FREE_DYNST(argument, Arg_Test);
					    FREE_DYNST(tascJobSt, A_TascJob);
						DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					    return(ret);
				    }

        			FREE_DYNST(argument, Arg_Test);
                }

			}

			FREE_DYNST(tascJobSt, A_TascJob);
		}
		else
		{
			/* Insert portfolioes Ids from the Quick Search List into #dom_port */
			if ((ret = SERV_ListMgm(listMgmFct,
									entDictId,
									0,
									GET_STRING(domainPtr, A_Domain_PtfListDef),
									dbiConn,
                                    nullptr)) != RET_SUCCEED)
			{
				/* REF3751 - SSO - 990623 more ret code tests */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				return(ret);
			}
		}

		/* PMSTA06500 - DDV - 080425 - Avoid calling twice the procedure which expand the Ptf hierarchy */
		if (EV_NoPMSTA6500 == 1)
		{
			/* Call procedure to expand #dom_port with hierarchy child portfolios */
			/* Only if load_hierarchy_f from domina is TRUE - XDI */
			if (domainPtr != NULLDYNST &&
				GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
			{
				if ((ret = DBA_Notif2(object,
									  DBA_ROLE_HIERPTF,
									  A_Domain,       /* NullDynSt, *//* SKE 010223 */
									  domainPtr,      /* NULLDYNST, *//* SKE 010223 */
									  DBA_SET_CONN|DBA_NO_CLOSE,
                                      dbiConnHelper,
									  UNUSED)) != RET_SUCCEED)
				{
					/* REF3749 - SSO - 990706 */
					DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
					return(ret);
				}
			}

			/* DVP479 - 970521 - PEC - Call a proc. to fill field port_pos_set_id in #dom_port table */
			if ((ret = DBA_Notif2(object,
								  DBA_ROLE_SCPT_DEF_CONTROL,
								  A_Domain,
								  domainPtr,
								  DBA_SET_CONN|DBA_NO_CLOSE,
                                  dbiConnHelper,
								  UNUSED)) != RET_SUCCEED)
			{
				/* REF3749 - SSO - 990706 */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
				return(ret);
			}
		}
    }
    else if (dimObject == DomainPtfCompo && domainPtr != NULL) /* PMSTA-36175 - PM Profile Phase1 changes - Kramadevi - 02072019*/
	{
	    char	               buffer[1024];
        DBA_DYNFLD_STP      tascJobSt = NULL;

        if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
        {
            if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED &&
                tascJobSt != NULL &&
                IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
            {
                DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));
                    SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

                    if ((ret = DBA_Notif2(TascJob,
                                          UNUSED,
                                          Arg_Test,
                                          argument,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConnHelper,
                                          UNUSED)) != RET_SUCCEED)
                    {
                        FREE_DYNST(argument, Arg_Test);
                        FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                        return(ret);
                    }
                    FREE_DYNST(argument, Arg_Test);
                }
            }
            FREE_DYNST(tascJobSt, A_TascJob);
        }
        else
        {
            sprintf(buffer, "delete from #dom_port ");
            ret = DBA_SqlExec(buffer, dbiConn.getId(), DBA_SET_CONN);

            if (ret == RET_SUCCEED)
            {
                sprintf(buffer,
                        "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "
                        "select dpc.portfolio_id, 0, null, 0 "
                        "from %s dpc, %s p "
                        "where dpc.function_result_id=%" szFormatId" and p.id = dpc.portfolio_id ",
                        SCPT_GetViewName(DomainPtfCompo, false).c_str(),
                        SCPT_GetViewName(Ptf, false).c_str(),
                        GET_ID(domainPtr, A_Domain_FctResultId));

                sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                if ((ret = DBA_SqlExec(buffer, dbiConn.getId(), DBA_SET_CONN)) != RET_SUCCEED)
                {

                    DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                    if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                    return(ret);
                }
            }
        }
	}
    /* PMSTA-36876 - Kramadevi - 16102019: Portfolio Dimension is Third Party, third_compo_e is LegalPerson*/
    else if (dimObject == Third && domainPtr != NULL && GET_ENUM(domainPtr, A_Domain_ThirdCompoEn) == PtfThirdCompo_LegalPerson)
    {
        admArg = ALLOC_DYNST(Adm_Arg);

        if (admArg == NULLDYNST)
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            return(RET_GEN_ERR_INVARG);
        }
        COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, domainPtr, A_Domain, A_Domain_PtfObjId);
        COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_NatEn, domainPtr, A_Domain, A_Domain_OwnershipRuleEn);

        if ((ret = DBA_Notif(object,
                             UNUSED,
                             Adm_Arg,
                             admArg,
                             dbiConn,
                             DBA_SET_CONN | DBA_NO_CLOSE)) != RET_SUCCEED)
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif() failed");
            FREE_DYNST(admArg, Adm_Arg);
            return(ret);
        }
        FREE_DYNST(admArg, Adm_Arg);
        initRequestFlg = FALSE;
    }
	/* Send an Init request to fill dom_position and dom_instr table if
		- no list of portfolio's available
		- dimension instrument <> 'ALL'
		- function <> CurrencyModify
		- function <> Copy Operations
	*/
	if (/*listPtf == NULLDYNSTPTR ||*/ /* DVP460 */
	    (initRequestFlg == TRUE) && /* REF3141 - SSO - 980118 : do not the insert in #dom_port if it is already done above */
	    (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE ||
	     (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_CurrencyModify &&
	      GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_CopyOperation)))	/* DVP545 - 970722 - DED */
	{
        DATE_START_TIMER(2, TIMER_MASK_SQLC);

		if ((ret = DBA_Notif(object,
                             UNUSED,
                             A_Domain,
                             domainPtr,
                             dbiConn,
                             DBA_SET_CONN | DBA_NO_CLOSE)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif() failed");
			return(ret);
		}

		DATE_STOP_TIMER(2, TIMER_MASK_SQLC);
	}
	else
	{
		/* PMSTA06500 - DDV - 080425 - Here is the new place to call the procedure which expand the Ptf hierarchy */
		/* For other cases the call is done in the init_exd_position_by_domain procedure */
		if (EV_NoPMSTA6500 == 0)
		{
			/* Call procedure to expand #dom_port with hierarchy child portfolios */
			/* Only if load_hierarchy_f from domina is TRUE - XDI */
            /*WEALTH-9420 - Lalby - 20062024 - Avoid dom_port enrty for intermediate (already exists) , causing position double issue */
            if (((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg) == LoadHierPtf_IntermediateHierarchy ) ? 
                (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == FALSE &&  GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == FALSE ) 
                : TRUE) &&
                (initRequestFlg == TRUE ||
				(domainPtr != NULLDYNST &&
				 GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)))
			{
				if ((ret = DBA_Notif2(object,
									  DBA_ROLE_HIERPTF,
									  A_Domain,       /* NullDynSt, *//* SKE 010223 */
									  domainPtr,      /* NULLDYNST, *//* SKE 010223 */
									  DBA_SET_CONN|DBA_NO_CLOSE,
                                      dbiConnHelper,
									  UNUSED)) != RET_SUCCEED)
				{
					/* REF3749 - SSO - 990706 */
					DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
					return(ret);
				}
			}

			/* DVP479 - 970521 - PEC - Call a proc. to fill field port_pos_set_id in #dom_port table */
			if ((ret = DBA_Notif2(object,
								  DBA_ROLE_SCPT_DEF_CONTROL,
								  A_Domain,
								  domainPtr,
								  DBA_SET_CONN|DBA_NO_CLOSE,
                                  dbiConnHelper,
								  UNUSED)) != RET_SUCCEED)
			{
				/* REF3749 - SSO - 990706 */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
				return(ret);
			}
		}
	}

	/*  FPL-PMSTA11939-1105013  */
	if (GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PreTradeCheckStrat &&
		GET_DICT(domainPtr, A_Domain_InitialFctDictId) != DictFct_PreTradeCheckStrat  &&
		GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_PerformanceAnalysis )
    {

        if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort)
        {
            if ((ret = DBA_TransferDomPortToTSL(hierHeadPtr, domainPtr, dbiConnHelper)) == RET_SUCCEED)
            {
                DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            }
            return(ret);
        }

        if (GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_NoCompute)
        {
            if ((ret = DBA_LoadInstrPtfStratCurrThird(hierHeadPtr, domainPtr, dbiConnHelper, DBA_ROLE_NO_COMP_DATA)) == RET_SUCCEED)
            {
                DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
            }
            return(ret);
        }
    }
    

    /* REF4306 - DDV - 000229 - Don't treat instrument dimension for DisplayChrono Fct,
       all entity (Curr, Port, Instr, Third) are treated by portfolio case */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_DisplayChrono ||
		GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_DisplayComplianceChrono || /* PMSTA-18759 - CHU - 150401 */
	    GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CompositeMgr || /* REF7423 - RAK - 020403 */
        (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage &&
		 GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged && /* REF7423 - MCA - 0209010 */
		 dimObject == List))
    {
      	*initialDimPtfDict = GET_DICT(domainPtr, A_Domain_DimPtfDictId);
	    return(RET_SUCCEED);
    }

	/* Handle the Domain INSTRUMENT DIMENSION */
	if (GET_DICT(domainPtr, A_Domain_DimInstrDictId) == 0)
    {
		dimObject = NullEntity;
    }
	else if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &dimObject) != TRUE)
	{
		DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
		return(RET_GEN_ERR_INVARG);
	}

	SET_FLAG(domainPtr, A_Domain_NonEnumInstrFlg, 0);

	/* Switch INSTRUMENT DIMENSION */
	switch (GET_OBJECT_CST(dimObject)) /* REF8844 - LJE - 030416 */
	{
	case ListCst:  /* INSTRUMENT DIMENSION is a list of instruments */

		if (listInstr==NULLDYNSTPTR || listInstrNbr == 0)	/* DVP460 - RAK - 970516 */
		{
			admArg = ALLOC_DYNST(Adm_Arg);
			sList = ALLOC_DYNST(S_List);

			/* Verify memory allocation */
			if (admArg == NULL || sList == NULL)
			{
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				FREE_DYNST(admArg, Adm_Arg);
				FREE_DYNST(sList, S_List);
				return(RET_GEN_ERR_INVARG);
            }

			COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, domainPtr, A_Domain, A_Domain_InstrObjId);
			if ((ret = DBA_Get2(List, UNUSED, Adm_Arg, admArg,
				     	    S_List, &sList, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
			{
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
				FREE_DYNST(admArg, Adm_Arg);
				FREE_DYNST(sList, S_List);
				return(ret);
			}

			/* If the list is constraint, search or hierarchic */
			if ((nature = (LISTNAT_ENUM) GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
                            nature == ListNat_Search || nature == ListNat_Hierarch)
			{
				DICT_T      instrEntDictId;

				DBA_GetDictId(Instr, &instrEntDictId);

				/* Insert instrument Ids from the List into #dom_instr */
				/* REF125 - XDI - 971217 - when event generation for instruemnt only, */
                /* no position load. Remark: Event generation use load from Journal */
                if ((GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_Valo)		||	/* REF851  - OCE - 981110 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_OpHist)		||	/* REF851  - OCE - 981110 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_Perfo)		||	/* REF2416 - OCE - 981130 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_FundValo)		||	/* REF2416 - OCE - 981201 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_OpList)		||	/* REF2416 - OCE - 981201 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_OrderList)		||	/* REF2416 - OCE - 981202 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_Return)		||	/* REF2416 - OCE - 981207 */
                    (GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_CaseInquiry) ||	/* PMSTA07121 - DDV - 090319 */
					(GET_DICT(domainPtr,A_Domain_FctDictId)	== DictFct_Journal) )			/* REF2416 - OCE - 981127 */
				{
                    if ((ret = SERV_ListMgm(ListMgmFct_LoadEvtGenInstr,
                                            instrEntDictId,
                                            GET_ID(sList, S_List_Id),
                                            NULL,
                                            dbiConn,
                                            nullptr)) != RET_SUCCEED)
					{
					    /* REF3751 - SSO - 990623 more ret code tests */
					    DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					    FREE_DYNST(admArg, Adm_Arg);
					    FREE_DYNST(sList, S_List);
					    return(ret);
					}
				}
				else
				{
                    if ((ret = SERV_ListMgm(ListMgmFct_LoadPos,
                                            instrEntDictId,
                                            GET_ID(sList, S_List_Id),
                                            NULL,
                                            dbiConn,
                                            nullptr)) != RET_SUCCEED)
					{
					    /* REF3751 - SSO - 990623 more ret code tests */
					    DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
					    FREE_DYNST(admArg, Adm_Arg);
					    FREE_DYNST(sList, S_List);
					    return(ret);
					}
				}

				SET_FLAG(domainPtr,A_Domain_NonEnumInstrFlg, TRUE);
			}

			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
		}
		else
		{
			/* Insert instruments Ids from given instrument list into dom_instr */
			if ((ret = SERV_InsDomTable("#dom_instr", listInstr, listInstrNbr, dbiConn.getId())) != RET_SUCCEED)
			{
			    /* REF3751 - SSO - 990623 more ret code tests */
			    DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			    return(ret);
			}
		}
		break;

    case QuickSearchCst: /* REF0014 - DDV - 000330 - Quick search in Domain */
        DBA_GetDictId(Instr, &entDictId);

        /* Insert portfolioes Ids from the Quick Search List into #dom_port */
        if ((ret = SERV_ListMgm(listMgmFct,
                                entDictId,
                                0,
                                GET_STRING(domainPtr, A_Domain_InstrListDef),
                                dbiConn,
                                nullptr)) != RET_SUCCEED)
        {
            /* REF3751 - SSO - 990623 more ret code tests */
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
            return(ret);
        }
        break;
	}

	/* Save original portfolio dimension */
	*initialDimPtfDict = GET_DICT(domainPtr, A_Domain_DimPtfDictId);

	/* If dimension portfolio = 'ALL' and table 'dom_port' has been filled by Dynamic SQL,
	the stored procedure 'sel_exd_position_by_domain' must take into account the table
	'dom_port'.  Normally in the case of 'All' portfolio's, this table is ignored.
	(cfr. treatment financial function CheckStrat).  So we change the dimension into a 'list' */
	if ((listPtf != NULLDYNSTPTR) && (listPtfNbr != 0) &&
	    (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE))
	{
		/* Set portfolio dimension to 'List' */
		DBA_GetDictId(List, &dictId);
		SET_DICT(domainPtr, A_Domain_DimPtfDictId, dictId);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadDomOperTable()
**
**  Description          : Init #dom_op table for operation search load
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF2467 - DDV - 991224
**
**                         REF5010 - SSO - 000828
*************************************************************************/
STATIC RET_CODE DBA_LoadDomOperTable(DBA_DYNFLD_STP domainPtr,
                                     DbiConnection& dbiConn)
{
    DBI_INT               status = 0;
    char                 *from = NULL, *where = NULL, *buffer=NULL;
    char                 *scptDefOpStr = NULL;
	char                 dateBuf[DATETIME_SQL_STRING_SIZE]; /* PMSTA-20159 - TEB - 151117 */
    /*FLAG_T               indexUsedFlg = FALSE; REF5493 - DDV - 010104 */
	RET_CODE             ret=RET_SUCCEED;
    SYSNAME_T            dateNameStr;
    OPSTAT_ENUM               accountingStatus;
    OPSEARCH_FCTRESULT_ENUM   opSearchFctResultMethod=OpSearch_DontUseDomainFctResult;

    GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);
    GEN_GetApplInfo(ApplOpSearchFctResultMethod, &opSearchFctResultMethod);

	/* Create temporary worktables #dom_oper and #tmp_oper */
    if ((ret = DBA_CreateTempTables(dbiConn, DOM_OPER | TMP_OPER)) != RET_SUCCEED)
        return(ret);

    scptDefOpStr = GET_TEXT(domainPtr, A_Domain_OpSearch);

    /* fill and use #tmp_oper only if search based on operation table is not possible */
    /* REF5493 - DDV - 010104 if ((IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE ||
        IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId)   == FALSE ||
        IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE ||
        IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE)) */
    /* REF7560 - DDV 020603 - code extract in a new function (FIN_OpSeachUseOnlyInOpTable) */
    if (FIN_OpSearchUseOnlyOpTable(domainPtr) == FALSE)
    {
    	/* Create temporary worktable '#obj_id' */
        if ((ret = DBA_CreateTempTables(dbiConn, OBJ_ID)) != RET_SUCCEED)
            return(ret);

        /* alloc and fill strings for dynamic sql (from and where part) */
        if ((from = (char *)CALLOC(512, sizeof (char))) == NULL) /* REF7264 - LJE - 020131 */
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        if ((where = (char *)CALLOC(512, sizeof (char))) == NULL) /* REF7264 - LJE - 020131 */
        {
            FREE(from);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        /* always use #dom_port for security reason and for ThirdParty entity */
        sprintf(from, "#dom_port dp");
        sprintf(where, "e.portfolio_id = dp.id \n");

        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE)
        {

            dateBuf[0] = END_OF_STRING;
			/* PMSTA-20159 - TEB - 150624 */
			DATETIME_T datetimeSt = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);

			if (DATETIME_ToDbStr(dateBuf, datetimeSt.date, datetimeSt.time))
			{
				sprintf(where + strlen(where), " and e.begin_d >= %s \n", dateBuf);
			}
        }

        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE)
        {
            dateBuf[0] = END_OF_STRING;
			/* PMSTA-20159 - TEB - 150624 */
			DATETIME_T datetimeSt = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

			if (DATETIME_ToDbStr(dateBuf, datetimeSt.date, datetimeSt.time))
			{
				sprintf(where + strlen(where), " and e.begin_d <= %s \n", dateBuf);
			}
        }

        if (IS_NULLFLD(domainPtr, A_Domain_MinStatEn) == FALSE)
        {
            sprintf(where + strlen(where), " and e.status_e >= %d \n", GET_ENUM(domainPtr, A_Domain_MinStatEn));
        }

        if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == FALSE)
        {
            sprintf(where + strlen(where), " and e.status_e <= %d \n", GET_ENUM(domainPtr, A_Domain_MaxStatEn));
        }

		/* PMSTA_31671 - RAK - Treat PlanDefinition */
		if (IS_NULLFLD(domainPtr, A_Domain_PlanDefinitionId) == FALSE)
		{
			sprintf(where + strlen(where), "and exists(select 1 from %s s inner join %s p on s.plan_definition_id = p.id \n  ",SCPT_GetViewName(StandInstruct, false).c_str(),SCPT_GetViewName(PlanDefinition, false).c_str());
			sprintf(where + strlen(where), "           where  p.id = %" szFormatId "  and e.stand_instruct_id = s.id) \n", GET_ID(domainPtr, A_Domain_PlanDefinitionId));
		}

        /* generate dynamic sql to fill #tmp_oper using position and balance position tables */
        if ((buffer = (char *)CALLOC(4096, sizeof (char))) == NULL) /* REF7264 - LJE - 020131 */
        {
            FREE(from);
            FREE(where);
           	/* Truncate temporary worktable '#obj_id' */
            if (DBA_CreateTempTables(dbiConn, OBJ_ID) != RET_SUCCEED)
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        /* REF7506 - DDV - 020531 - First get id of all order matching status, dates and #dom_port
           instrument dimension will be treated later in a new functio called by DBA_LoadPos */
        /* PMSTA-20159 - TEB - 150624 */


        sprintf(buffer + strlen(buffer), "insert into #obj_id (id) \n");

        sprintf(buffer + strlen(buffer), "select e.id \n");   /* PMSTA-61914 - JBC - 20241203 - remove useless distinct due to id is unique */
        sprintf(buffer + strlen(buffer), "from %s, %s e \n", from, SCPT_GetViewName(ExtOrder, false).c_str()); /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */

        sprintf(buffer + strlen(buffer), "where %s ", where);

        /* PMSTA-20506 - DDV - 150610 -  Add FctResult criteria if allowed and limit search on ext_order table */
        if (opSearchFctResultMethod == OpSearch_UseDomainFctResult && IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
        {
            sprintf(buffer + strlen(buffer), " and function_result_id= %" szFormatId " ", GET_ID(domainPtr, A_Domain_FctResultId));
        }
        else if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == FALSE &&         /* Add union on positin / balance pos only if max_status >= ACCOUNTING_STATUS */
                 GET_ENUM(domainPtr, A_Domain_MaxStatEn) >= accountingStatus)
        {
            /* Add union on position / balance pos only if max_status >= ACCOUNTIG_STATUS */
	        sprintf(buffer + strlen(buffer), "union \n");

	        if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
	        {
	            sprintf(from + strlen(from), ", #dom_instr di");
	            sprintf(where + strlen(where), " and e.instr_id = di.id \n");
	        }

	        sprintf(where + strlen(where), " and e.port_pos_set_id = 0 \n and e.primary_e = 1\n");

	        sprintf(buffer + strlen(buffer), "select e.open_oper_id \n");	 /* PMSTA-61914 - JBC - 20241203 - remove useless distinct due UNION */
	        sprintf(buffer + strlen(buffer), "from %s, %s e \n", from, SCPT_GetViewName(Pos, false).c_str()); /* PMSTA-26250  -DDV - 170523 */  /* PMSTA-32753 - DLA - 180903 */

	        sprintf(buffer + strlen(buffer), "where %s ", where);

	        sprintf(buffer + strlen(buffer), "union \n");

	        sprintf(buffer + strlen(buffer), "select e.open_oper_id \n");		/* PMSTA-61914 - JBC - 20241203 - remove useless distinct due UNION */
	        sprintf(buffer + strlen(buffer), "from %s, %s e \n", from, SCPT_GetViewName(BalPos, false).c_str()); /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */

			sprintf(buffer + strlen(buffer), "where %s ", where);
        }

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = dbiConn.getSqlTrace();
            sqlTrace.m_procedure = "DynSql.LoadDomOperTable";
        }

		/* REF3751 - SSO - 990623 connectNoIn replaced by connectNo */
        ret = dbiConn.sqlExecSt(buffer, &status);

		if (ret != RET_SUCCEED)
		{
            FREE(from);
            FREE(where);
            FREE(buffer);
           	/* Truncate temporary worktable '#obj_id' */
            if (DBA_CreateTempTables(dbiConn, OBJ_ID) != RET_SUCCEED)
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
/*		    DBA_FilterMsgInfos2(connectNo, &ret,NULL); REF5010 - SSO - 000828 */
		    return(ret);
		}

        FREE(buffer);   /* REF8723 - TEB - 040220 - Memory leak */
        FREE(from);     /* REF8723 - TEB - 040220 - Memory leak */
        FREE(where);    /* REF8723 - TEB - 040220 - Memory leak */

        /* fill #dom_oper using dynamic script on operation and #obj_id */
        /* if no script definition use "1=1" definition to call SCPT_EvalCstList */
        scptDefOpStr = GET_TEXT(domainPtr, A_Domain_OpSearch);
        if (scptDefOpStr == NULL || scptDefOpStr[0] == END_OF_STRING)
        {
            /* fill #dom_oper using dynamic script on operation and #obj_id */
            if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_OPER_WITH_OBJID,
                                        0,
                                        "1 = 1",
                                        Op,
                                        0,
                                        NULLDYNST,
                                        dbiConn.getId(),
                                        (FLAG_T*) NULL,
                                        (DBA_DYNFLD_STP**) NULL,
                                        (int *)NULL,
                                        (DATETIME_STP)NULL,
                                        0,
                                        0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                        ) != RET_SUCCEED)
                return(ret);
        }
        else
        {
            /* fill #dom_oper using dynamic script on operation and #obj_id */
            if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_OPER_WITH_OBJID,
                                        0,
                                        scptDefOpStr,
                                        Op,
                                        0,
                                        NULLDYNST,
                                        dbiConn.getId(),
                                        (FLAG_T*) NULL,
                                        (DBA_DYNFLD_STP**) NULL,
                                        (int *)NULL,
                                        (DATETIME_STP)NULL,
                                        0,
                                        0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                        ) != RET_SUCCEED)
                return(ret);
        }

       	/* Truncate temporary worktable '#obj_id' */
        if ((ret = DBA_CreateTempTables(dbiConn, OBJ_ID)) != RET_SUCCEED)
   			MSG_LogMesg(
                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_CreateTempTables failed");
    }
    else
    {
        /* REF5493 - DDV - 010104 - check removed
        if no script defintion return a error ,
        if (scptDefOpStr == NULL || scptDefOpStr[0] == END_OF_STRING)
            return(RET_GEN_ERR_INVARG);
        */

        if ((where = (char *)CALLOC(1024, sizeof (char))) == NULL) /* REF7264 - LJE - 020131 */
        {
            /* FREE(from); */  /* REF8723 - TEB - 040220 - Memory leak */
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        /* DDV - 000117 - Modify script to add min/max status management */
        if (IS_NULLFLD(domainPtr, A_Domain_MinStatEn) == FALSE)
        {
            sprintf(where + strlen(where), "status_e >= %d AND \n", GET_ENUM(domainPtr, A_Domain_MinStatEn));
        }

        if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == FALSE)
        {
            sprintf(where + strlen(where), "status_e <= %d AND \n", GET_ENUM(domainPtr, A_Domain_MaxStatEn));
        }

        /* REF5493 - DDV - 010104 - Get sqlname of date according to fusion_date_rule parameter */
        dateNameStr[0] = END_OF_STRING;
        switch (GET_ENUM(domainPtr, A_Domain_FusDateRuleEn))
        {
            case FusDateRule_OpDate:
                strcat(dateNameStr, "operation_d");
                break;
            case FusDateRule_AcctDate:
                strcat(dateNameStr, "account_d");
                break;
            case FusDateRule_ValDate:
                strcat(dateNameStr, "value_d");
                break;
            default:
                strcat(dateNameStr, "operation_d");
                break;
        }


        /* DLA - PMSTA-25863 - 170112 */
        DATE_FORMAT_ST	     dateFormat;
        /* date fromat initialisation */
        dateFormat.ordre = Dmy;
        strcpy(dateFormat.yearSep, "/");
        strcpy(dateFormat.monthSep, "/");
        strcpy(dateFormat.daySep, "/");
        dateFormat.yearFormat = 1;
        dateFormat.monthFormat = 0;

        /* REF5493 - DDV - 010104 - Add test on from_d */
        if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE)
        {
            dateBuf[0] = END_OF_STRING;

            /* REF5493 - DDV - 010109 */
            if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr, A_Domain_InterpFromDate), &dateFormat) == TRUE)    /* DLA - PMSTA-25863 - 170112 */
            {  /* PMSTA-20159 - TEB - 150624 */
                sprintf(where + strlen(where), "%s >= \"%s\" AND \n", dateNameStr, dateBuf);	/* DLA - PMSTA-25863 - 170112 */
            }
        }

        /* REF5493 - DDV - 010104 - Add test on till_d */
        if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE)
        {
            dateBuf[0] = END_OF_STRING;

            /* REF5493 - DDV - 010109 */
            if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr, A_Domain_InterpTillDate), &dateFormat) == TRUE)  /* DLA - PMSTA-25863 - 170112 */
            { /* PMSTA-20159 - TEB - 150624 */
                sprintf(where + strlen(where), "%s <= \"%s\" AND \n", dateNameStr, dateBuf); /* DLA - PMSTA-25863 - 170112 */
            }
        }

        /* REF5493 - DDV - 010104 */
        if (scptDefOpStr == NULL || scptDefOpStr[0] == END_OF_STRING)
            strcat(where, "1 = 1");
        else
            strcat(where, scptDefOpStr);

        /* fill #dom_oper using dynamic script on operation and status value */
        if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_OPER_WITH_OPER,
                                    0,
                                    where,
                                    Op,
                                    0,
                                    NULLDYNST,
                                    dbiConn.getId(),
                                    (FLAG_T*) NULL,
                                    (DBA_DYNFLD_STP**) NULL,
                                    (int *)NULL,
                                    (DATETIME_STP)NULL,
                                    0,
                                    0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                    ) != RET_SUCCEED)
        {
            FREE(where);    /* REF8723 - TEB - 040220 - Memory leak */
            return(ret);
        }

        FREE(where);    /* REF8723 - TEB - 040220 - Memory leak */
    }
	return(ret);
}

/************************************************************************
**  Function             : DBA_FctLnkInitState()
**
**  Description          : According to function, update links state structure
**
**  Arguments            : domainPtr	 domain structure pointer
**                         fctLnkStp     links state structure (will be updated)
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : REF182 - 960915 - RAK
**  Creation 		     : REF215 - 970918 - RAK
**
*************************************************************************/
STATIC void DBA_FctLnkInitState(DBA_DYNFLD_STP domainPtr,
		                        DBA_FCTLNK_STP fctLnkStp)
{
	/* Init all links to FALSE */
	memset(fctLnkStp, 0, sizeof(DBA_FCTLNK_ST));

	switch ((DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_FctDictId))
	{
	case DictFct_CheckStratValo :
        /* REF3678 - RAK - 000222 - Do this link in sub-hierarchy ! */
		/*fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;*/		/* DVP563 - 970821 - DED */
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;		/* REF182 - 970916 - RAK */

		if (((DOMTAXLOT_ENUM)GET_ENUM(domainPtr, A_Domain_TaxLotEn) > DomTaxLotEn_None))               /* PMSTA-34116 - 220219 - vkumar */
		{
			fctLnkStp->A_TaxLot_A_TaxLotInitial_Ext = TRUE;
		}
		break;

	case DictFct_CopyOperation :
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;		/* DVP024 - 960329 - RAK */
		fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;		/* DVP009 - 960319 - RAK */
		fctLnkStp->ExtPos_Locking_ExtPos 	= TRUE;		/* REF1364 - 980309 - GRD */
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_CurrencyModify :
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;		/* DVP024 - 960329 - RAK */
		fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;		/* DVP009 - 960319 - RAK */
		fctLnkStp->ExtPos_Locking_ExtPos 	= TRUE;		/* REF1364 - 980309 - GRD */
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_FundValo :
		fctLnkStp->A_AccPlanElt_A_FundValElt 	= TRUE;
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/*  DVP563 - 970812 - DED */
		fctLnkStp->ExtPos_A_AccPlanElt 		= TRUE;
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;*/		/* DVP474 - 970612 - XMT */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;*/		/* DVP474 - 970612 - XMT */
		fctLnkStp->sortFlg			= TRUE;
		break;

    case DictFct_Journal :
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/* DVP563 - 970812 - DED */
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		/* fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE; REF4080 - 000419 - DDV */
		/* fctLnkStp->ExtPos_Acct2_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP029 - 960510 - DED */
		/* fctLnkStp->ExtPos_Acct3_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		/* fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP024 - 960329 - RAK */
		fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;
		/* fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP029 - 960510 - DED */
		/* fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP397 - 970429 - RAK */
		/* fctLnkStp->ExtPos_BVAdjProfit_ExtPos	= TRUE; REF4080 - 000419 - DDV */ /* DVP397 - 970429 - RAK */
		/* fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE; REF4080 - 000419 - DDV */
		/* fctLnkStp->ExtPos_Close_A_Op 	= TRUE; REF4080 - 000419 - DDV */
		/* fctLnkStp->ExtPos_Instr_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP009- 960319 - RAK */
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		/* fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP474 - 970612 - XMT */
		/* fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE; REF4080 - 000419 - DDV */ /* DVP474 - 970612 - XMT */
		fctLnkStp->ExtOp_Flow                   = TRUE;         /* REF2669 - 980817 - DDV */
		fctLnkStp->ExtOp_A_Instr                = TRUE;         /* REF3740 - 990720 - AKO */
		/* fctLnkStp->Flow_ExtOp                   = TRUE; this link can't be use for journal - DDV - 990806 */         /* REF2669 - 980817 - DDV */
		fctLnkStp->Flow_A_Instr                 = TRUE;         /* REF2669 - 980817 - DDV */
		fctLnkStp->A_Instr_Parent               = TRUE;         /*PMSTA-32106 -NRAO 180904*/
		fctLnkStp->A_Instr_Child                = TRUE;         /*PMSTA-32106 -NRAO 180904*/

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_MultiValo :
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/* DVP563 - 970812 - DED */
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;		/* REF182 - 970916 - RAK */
		break;

	case DictFct_OpHist :
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;*/		/* DVP024 - 960329 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;*/		/* DVP009 - 970319 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToBalPos_ExtPos	= TRUE;*/		/* DVP474 - 970612 - XMT */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;*/		/* DVP474 - 970612 - XMT */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}
        /* PMSTA-28086 - 170219 - sanand */
        if (((DOMTAXLOT_ENUM)GET_ENUM(domainPtr, A_Domain_TaxLotEn) > DomTaxLotEn_None))
        {
            fctLnkStp->A_TaxLot_A_TaxLotInitial_Ext = TRUE;
        }
		fctLnkStp->sortFlg			= TRUE;
		break;
	case DictFct_Archive:
	    fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;		/* DVP024 - 960329 - RAK */
		fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;		/* DVP009 - 960319 - RAK */
		fctLnkStp->ExtPos_Locking_ExtPos 	= TRUE;		/* REF1364 - 980309 - GRD */
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->sortFlg			= TRUE;
		break;
	case DictFct_OpList :
		fctLnkStp->ExtPos_A_Instr		= TRUE;
		fctLnkStp->ExtPos_A_Ptf			= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos		= TRUE;
		fctLnkStp->ExtPos_BalPos_ExtPos		= TRUE;
		fctLnkStp->ExtPos_Close_A_Op		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op		= TRUE;
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AccrInter_ExtPos	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct2_ExtPos		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct3_ExtPos		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AdjustSec_ExtPos	= TRUE;*/		/* DVP024 - 960329 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Adjust_ExtPos		= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Attach_ExtPos		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjLoss_ExtPos	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjProfit_ExtPos	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_CntPty_ExtPos		= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Instr_ExtPos		= TRUE;*/		/* DVP009 - 970319 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToBalPos_ExtPos	= TRUE;*/		/* DVP474 - 970612 - XMT */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToInstr_ExtPos	= TRUE;*/		/* DVP474 - 970612 - XMT */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}
        /* PMSTA-28086 - 170219 - sanand */
        if (((DOMTAXLOT_ENUM)GET_ENUM(domainPtr, A_Domain_TaxLotEn) > DomTaxLotEn_None))
        {
            fctLnkStp->A_TaxLot_A_TaxLotInitial_Ext = TRUE;
        }
		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_OrderList :
	case DictFct_OrderGrouping :		/* REF11764 - RAK - 060330 */
	case DictFct_UpdateField :	        /*  HFI-PMSTA-35324-190328  */
	case DictFct_UpdateData :	        /*  HFI-PMSTA-35324-190328  */
    case DictFct_HierarchyGrouping:			/* PMSTA-40208 - sanand - 24092020 */
		fctLnkStp->ExtOp_A_Instr 		= TRUE;
		fctLnkStp->ExtOp_A_Ptf 			= TRUE;
		fctLnkStp->ExtPos_A_Instr		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;		/* DVP024 - 960329 - RAK */
		fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;		/* DVP029 - 960510 - DED */
		fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;		/* DVP397 - 970429 - RAK */
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;		/* DVP009 - 970319 - RAK */
		fctLnkStp->ExtPos_Locking_ExtPos 	= TRUE;		/* REF1364 - 980309 - GRD */
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */
		fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;		/* DVP474 - 970612 - XMT */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_Perfo :
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/* DVP563 - 970821 - DED */
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_BalPos_ExtPos 	= TRUE;
		fctLnkStp->ExtPos_Close_A_Op 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Open_A_Op 		= TRUE;
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AccrInter_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct2_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Acct3_ExtPos 		= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE;*/		/* DVP024 - 960329 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Adjust_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Attach_ExtPos 	= TRUE;*/		/* DVP029 - 960510 - DED */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjLoss_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_BVAdjProfit_ExtPos 	= TRUE;*/		/* DVP397 - 970429 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_CntPty_ExtPos 	= TRUE;*/
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Instr_ExtPos 		= TRUE;*/		/* DVP009 - 970319 - RAK */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToBalPos_ExtPos 	= TRUE;*/		/* DVP474 - 970612 - XMT */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_ToInstr_ExtPos 	= TRUE;*/		/* DVP474 - 970612 - XMT */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;
		break;

	case DictFct_Return :
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/* DVP563 - 970821 - DED */
		fctLnkStp->ExtPos_A_Instr 		    = TRUE;
		fctLnkStp->ExtPos_A_Ptf 	    	= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_AdjustSec_ExtPos 	= TRUE; /* REF3814 - SSO - 990714: MUST BE DONE !!! */


		/* REF3256 - SSO - 990208: doesn't work, too early here  fctLnkStp->ExtPos_PosVal 		= TRUE;	*/	/* DVP332 - 970123 - DED */
		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
			fctLnkStp->A_Ptf_A_HierChildrenPtf = TRUE;  /* PMSTA02013 - RAK - 071112 */
		}

		fctLnkStp->sortFlg			= TRUE;
		fctLnkStp->updPosValFlg		= TRUE;
		break;

    /* REF3637 - RAK - 000308 */
    case DictFct_SynthAdmin :
        if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->A_Ptf_A_HierChildrenPtf = TRUE;  /* PMSTA02013 - RAK - 071112 */
		}
        break;

	case DictFct_Valo :
    case DictFct_ForexHedging:
		fctLnkStp->A_Instr_Cond_A_Instr 	= TRUE;		/* DVP563 - 970821 - DED */
		fctLnkStp->ExtPos_A_Instr 		= TRUE;
		fctLnkStp->ExtPos_A_Ptf 		= TRUE;
		fctLnkStp->ExtPos_Acct_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_Main_ExtPos 		= TRUE;
		fctLnkStp->ExtPos_PosVal 		= TRUE;		/* DVP332 - 970123 - DED */
		fctLnkStp->PosVal_ExtPos 		= TRUE; /* REF5442 - DDV - 010205 */
		/* REF3101 - DDV - 990222 fctLnkStp->ExtPos_Locking_ExtPos 	= TRUE;*/		/* DVP454 - 970505 - PEC */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)	/* REF069 - 970915 - RAK */
		{
			fctLnkStp->A_Ptf_HierPtf 	= TRUE;
			fctLnkStp->ExtPos_ChildPtf 	= TRUE;
		}

		fctLnkStp->sortFlg			= TRUE;		/* REF182 - 970916 - RAK */
		fctLnkStp->updPosValFlg			= TRUE;

        /* PMSTA-28086 - 170219 - sanand */
        if (((DOMTAXLOT_ENUM)GET_ENUM(domainPtr, A_Domain_TaxLotEn) > DomTaxLotEn_None))
        {
            fctLnkStp->A_TaxLot_A_TaxLotInitial_Ext = TRUE;
        }

        break;

	case DictFct_DisplayChrono: /* REF4306 - CSY - 000221 */
	case DictFct_CompositeMgr:  /* REF4306 - DDV - 000323 */
		fctLnkStp->A_PtfFreq_A_Ptf = TRUE;
		fctLnkStp->A_InstrFreq_A_Instr = TRUE;
		fctLnkStp->A_CurrFreq_A_Curr = TRUE;
		fctLnkStp->A_ThirdFreq_A_Third = TRUE;

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
		{
			fctLnkStp->A_Ptf_HierPtf = TRUE;
			fctLnkStp->ExtPos_ChildPtf = TRUE;
			fctLnkStp->A_Ptf_A_ChildrenPtf = TRUE; /* REF4306 - CSY - 000321 */
		}

		break;

	case DictFct_DisplayComplianceChrono: /* PMSTA-18759 - CHU - 150401 */
		fctLnkStp->A_PtfFreq_A_Ptf = TRUE;
		fctLnkStp->A_InstrFreq_A_Instr = TRUE;
		fctLnkStp->A_CurrFreq_A_Curr = TRUE;
		fctLnkStp->A_ThirdFreq_A_Third = TRUE;
		fctLnkStp->A_ComplianceChronoFreq_A_Compl = TRUE; /* PMSTA-22458 - cashwini - 160502 */

		if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
		{
			fctLnkStp->A_Ptf_HierPtf = TRUE;
			fctLnkStp->ExtPos_ChildPtf = TRUE;
			fctLnkStp->A_Ptf_A_ChildrenPtf = TRUE; /* REF4306 - CSY - 000321 */
		}

		break;

    case DictFct_PerformanceAnalysis: /* REF7758 - LJE - 020927 */
        /* REF10276 - LJE - 041116 : Make in finperfa1
        fctLnkStp->A_PerfAttrib_Global       = TRUE;
        fctLnkStp->A_PerfAttrib_Bench        = TRUE;
        fctLnkStp->A_PerfAttrib_Parent       = TRUE;
        fctLnkStp->A_StandardPerf_Bench      = TRUE;
        fctLnkStp->A_ExtRetAnalysis_Global   = TRUE;
        fctLnkStp->A_ExtRetAnalysis_Bench    = TRUE;
        fctLnkStp->A_ExtRetAnalysis_Parent   = TRUE;
        */
        break;

    case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
    case DictFct_InstrRecommLevelStorage :  /* PMSTA-28705 - DDV - 180208 */
        break;
	}
}

/************************************************************************
**  Function             : DBA_FctLnkFirst()
**
**  Description          : Set or unset "first" links depending on links state structure
**			               This links must be set (and make) before others, because they are used
**     			           by DBA_UpdExtPosFld() and others links (ExtPos_Main_ExtPos_Ext, ...)
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         fctLnkStp     links state structure
**			               setFlg	     TRUE (set link), FALSE (unset link)
**                         srcExtPos     original position    (BUG515 - XDI - 970930)
**                         srcExtPos     duplicate position   (BUG515 - XDI - 970930)
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : REF182 - RAK - 960915
**  Modif    		     : BUG515 - XDI - 970930
**
*************************************************************************/
STATIC RET_CODE DBA_FctLnkFirst(DBA_HIER_HEAD_STP hierHeadPtr, /* REF7264 - LJE - 020131 */
			                    DBA_FCTLNK_STP fctLnkStp,
				                char           setFlg,
                                DBA_DYNFLD_STP srcExtPos,  /* BUG515 - XDI - 970930 */
                                DBA_DYNFLD_STP destExtPos) /* BUG515 - XDI - 970930 */
{
	RET_CODE	    retCd;
    DBA_DYNFLD_STP  tmpPtr;

	fctLnkStp->makeLnkFlg = FALSE;

	if (fctLnkStp->ExtPos_A_Instr == TRUE)
	{
        /* BUG515 - XDI - 970930 - Make link on duplicate position */
	    if (srcExtPos != NULLDYNST || destExtPos != NULLDYNST)
        {
	        if (srcExtPos != NULLDYNST && destExtPos != NULLDYNST && hierHeadPtr != NULL &&
                    GET_EXTENSION_PTR(srcExtPos, ExtPos_A_Instr_Ext) != NULL &&
	            (tmpPtr = *(GET_EXTENSION_PTR(srcExtPos, ExtPos_A_Instr_Ext))) != NULLDYNST)
            {
                    DBA_ForceLink(hierHeadPtr, ExtPos,
                                  ExtPos_A_Instr_Ext, destExtPos, tmpPtr);
            }
        }
        else
        {
	        if (setFlg == TRUE)
	        {
	            if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
	  		                            ExtPos_A_Instr_Ext)) != RET_SUCCEED)
		            return(retCd);

	            fctLnkStp->makeLnkFlg = TRUE;
	        }
	        else
	        {
		        if ((retCd = DBA_SetHierLnkUnused(hierHeadPtr, ExtPos,
			                       ExtPos_A_Instr_Ext)) != RET_SUCCEED)
			        return(retCd);
	        }
	    }
	}

	if (fctLnkStp->ExtPos_A_Ptf == TRUE)
	{
        /* BUG515 - XDI - 970930 - Make link on duplicate position */
	    if (srcExtPos != NULLDYNST || destExtPos != NULLDYNST)
        {
	        if (srcExtPos != NULLDYNST && destExtPos != NULLDYNST && hierHeadPtr != NULL &&
                    GET_EXTENSION_PTR(srcExtPos, ExtPos_A_Ptf_Ext) != NULL &&
	            (tmpPtr = *(GET_EXTENSION_PTR(srcExtPos, ExtPos_A_Ptf_Ext))) != NULLDYNST)
            {
                    DBA_ForceLink(hierHeadPtr, ExtPos,
                                  ExtPos_A_Ptf_Ext, destExtPos, tmpPtr);
            }
        }
        else
        {
	        if (setFlg == TRUE)
	        {
		        if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                       ExtPos_A_Ptf_Ext)) != RET_SUCCEED)
			        return(retCd);

		        fctLnkStp->makeLnkFlg = TRUE;
	        }
	        else
	        {
		        if ((retCd = DBA_SetHierLnkUnused(hierHeadPtr, ExtPos,
			                       ExtPos_A_Ptf_Ext)) != RET_SUCCEED)
			        return(retCd);
	        }
	    }
	}

	if (fctLnkStp->A_Ptf_HierPtf == TRUE)
	{
	    if (setFlg == TRUE)
	    {
		    if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Ptf,
				                        A_Ptf_HierPtf_Ext)) != RET_SUCCEED)
			    return(retCd);

		    fctLnkStp->makeLnkFlg = TRUE;
	    }
	    else
	    {
		    if ((retCd = DBA_SetHierLnkUnused(hierHeadPtr, A_Ptf,
										  A_Ptf_HierPtf_Ext)) != RET_SUCCEED)
			    return(retCd);
	    }
	}

	if (fctLnkStp->ExtPos_PtfPosSet == TRUE)
	{
        /* BUG515 - XDI - 970930 - Make link on duplicate position */
	    if (srcExtPos != NULLDYNST || destExtPos != NULLDYNST)
        {
	        if (srcExtPos != NULLDYNST && destExtPos != NULLDYNST && hierHeadPtr != NULL &&
                    GET_EXTENSION_PTR(srcExtPos, ExtPos_PtfPosSet_Ext) != NULL &&
	            (tmpPtr = *(GET_EXTENSION_PTR(srcExtPos, ExtPos_PtfPosSet_Ext))) != NULLDYNST)
            {
                    DBA_ForceLink(hierHeadPtr, ExtPos,
                                  ExtPos_PtfPosSet_Ext, destExtPos, tmpPtr);
            }
        }
        else
        {
	        if (setFlg == TRUE)
	        {
		        if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                                    ExtPos_PtfPosSet_Ext)) != RET_SUCCEED)
			        return(retCd);
		        fctLnkStp->makeLnkFlg = TRUE;
	        }
	        else
	        {
		        if ((retCd = DBA_SetHierLnkUnused(hierHeadPtr, ExtPos,
			                                      ExtPos_PtfPosSet_Ext)) != RET_SUCCEED)
			        return(retCd);
	        }
	    }
	}

	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_FctLnkOthers()
**
**  Description          : Set "others" links depending on links state structure
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         fctLnkStp     links state structure
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : REF182 - RAK - 960915
**
*************************************************************************/
STATIC RET_CODE DBA_FctLnkOthers(DBA_HIER_HEAD_STP hierHeadPtr, /* REF7264 - LJE - 020131 */
			                     DBA_FCTLNK_STP fctLnkStp)
{
	RET_CODE	retCd;

	fctLnkStp->makeLnkFlg = FALSE;

	if (fctLnkStp->A_AccPlanElt_A_FundValElt == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_AccPlanElt,
					                    A_AccPlanElt_A_FundValElt_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    if (fctLnkStp->A_Ptf_HierPtf == TRUE)   /* CSY - 000322 - was missing */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Ptf,
			                            A_Ptf_HierPtf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->A_Instr_Cond_A_Instr == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Instr,
					                    A_Instr_Cond_A_Instr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtOp_A_Instr == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtOp,
			                            ExtOp_A_Instr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtOp_A_Ptf == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtOp,
			                            ExtOp_A_Ptf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_A_AccPlanElt == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_A_AccPlanElt_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_AccrInter_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_AccrInter_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Acct2_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Acct2_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Acct3_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Acct3_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Acct_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Acct_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_AdjustSec_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_AdjustSec_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Adjust_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Adjust_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Attach_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Attach_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_BVAdjLoss_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_BVAdjLoss_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_BVAdjProfit_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_BVAdjProfit_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_BalPos_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_BalPos_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_ChildPtf == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_ChildPtf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Close_A_Op == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Close_A_Op_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_CntPty_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_CntPty_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Instr_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Instr_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Locking_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Locking_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Main_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Main_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_Open_A_Op == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_Open_A_Op_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_PosVal == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_PosVal_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_ToBalPos_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_ToBalPos_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtPos_ToInstr_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtPos,
			                            ExtPos_ToInstr_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->ExtOp_Flow == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, ExtOp,
			                            ExtOp_A_Flow_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->Flow_ExtOp == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, Flow,
			                            Flow_ExtOp_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->Flow_A_Instr == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, Flow,
			                            Flow_A_Instr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    if (fctLnkStp->A_PtfFreq_A_Ptf == TRUE) /* REF4306 - CSY - 000323 */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PtfFreq,
			                            A_PtfFreq_A_Ptf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    if (fctLnkStp->A_InstrFreq_A_Instr == TRUE) /* REF4306 - CSY - 000323 */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_InstrFreq,
			                            A_InstrFreq_A_Instr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	if (fctLnkStp->A_ComplianceChronoFreq_A_Compl == TRUE) /* PMSTA-22458 - cashwini - 160502 */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ComplianceChronoFreq,
			A_ComplianceChronoFreq_A_Compl_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    if (fctLnkStp->A_CurrFreq_A_Curr == TRUE) /* REF4306 - CSY - 000323 */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_CurrFreq,
			                            A_CurrFreq_A_Curr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    if (fctLnkStp->A_ThirdFreq_A_Third == TRUE) /* REF4306 - CSY - 000323 */
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ThirdFreq,
			                            A_ThirdFreq_A_Third_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF4306 - CSY - 000323 */
    if (fctLnkStp->A_Ptf_A_ChildrenPtf == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Ptf,
			                            A_Ptf_ChildrenPtf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	/* PMSTA02013- LJE - 071112 */
    if (fctLnkStp->A_Ptf_A_HierChildrenPtf == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Ptf,
			                            A_Ptf_HierChildrenPtf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}
    /* REF5442 - DDV - 010205 */
	if (fctLnkStp->PosVal_ExtPos == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, PosVal,
			                            PosVal_ExtPos_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF7758 - LJE - 021030 */
	if (fctLnkStp->A_StandardPerf_Bench == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_StandardPerf,
			                            A_StandardPerf_Bench_Ext)) != RET_SUCCEED)
			return(retCd);
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_StandardPerf,
			                            A_StandardPerf_RiskFree_Ext)) != RET_SUCCEED)
			return(retCd);
        fctLnkStp->makeLnkFlg = TRUE;
    }

    /* REF7758 - LJE - 020927 */
	if (fctLnkStp->A_PerfAttrib_Global == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_GlobalPerfAttrib_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF7758 - LJE - 020927 */
	if (fctLnkStp->A_PerfAttrib_Parent == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_Parent_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF7758 - LJE - 021030 */
	if (fctLnkStp->A_PerfAttrib_Bench == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_Bench1PerfAttrib_Ext)) != RET_SUCCEED)
			return(retCd);
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_Bench2PerfAttrib_Ext)) != RET_SUCCEED)
			return(retCd);
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_Bench3PerfAttrib_Ext)) != RET_SUCCEED)
			return(retCd);
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_PerfAttrib,
			                            A_PerfAttrib_RiskFreeStdPerf_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF7758 - LJE - 020927 */
	if (fctLnkStp->A_ExtRetAnalysis_Global == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ExtRetAnalysis,
			                            A_ExtRetAnalysis_GblExtRetAnalysis_Ext)) != RET_SUCCEED)
			return(retCd);
		/* PMSTA07393 - LJE - 081204 */
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ExtRetAnalysis,
			                            A_ExtRetAnalysis_Previous_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* REF7758 - LJE - 021030 */
	if (fctLnkStp->A_ExtRetAnalysis_Bench == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ExtRetAnalysis,
			                            A_ExtRetAnalysis_Bench_Ext)) != RET_SUCCEED)
			return(retCd);
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ExtRetAnalysis,
			                            A_ExtRetAnalysis_RiskFree_Ext)) != RET_SUCCEED)
			return(retCd);
        fctLnkStp->makeLnkFlg = TRUE;
    }

    /* REF7758 - LJE - 021030 */
	if (fctLnkStp->A_ExtRetAnalysis_Parent == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_ExtRetAnalysis,
			                            A_ExtRetAnalysis_Parent_Ext)) != RET_SUCCEED)
			return(retCd);
        fctLnkStp->makeLnkFlg = TRUE;
    }

	/*PMSTA-32106 -NRAO 180904*/
	if (fctLnkStp->A_Instr_Parent == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Instr,
			A_Instr_ParentInstr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

	/*PMSTA-32106 -NRAO 180904*/
	if (fctLnkStp->A_Instr_Child == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_Instr,
			A_Instr_ChildInstr_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    /* PMSTA-34116 - 220219 - vkumar */
	if (fctLnkStp->A_TaxLot_A_TaxLotInitial_Ext == TRUE)
	{
		if ((retCd = DBA_SetHierLnkUsed(hierHeadPtr, A_TaxLot,
                                        A_TaxLot_A_TaxLotInitial_Ext)) != RET_SUCCEED)
			return(retCd);
		fctLnkStp->makeLnkFlg = TRUE;
	}

    return(RET_SUCCEED);

}

/************************************************************************
**
**  Function    :   DBA_FilterGenericInstr()
**
**  Description :   Filter generic instrument (use identifier value)
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC int DBA_FilterGenericInstr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (GET_ID(dynSt, A_Instr_Id) > 0)
	    return(FALSE);
    else
	    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_FilterPosGenericInstr()
**
**  Description :   Filter pos with generic instrument (use identifier value) and bal pos
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**  Created		    REF2950 - SSO - 981029
**
*************************************************************************/
STATIC int DBA_FilterPosGenericInstr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	DBA_DYNFLD_STP genInstr=(DBA_DYNFLD_STP)NULLDYNST;
	DBA_DYNFLD_STP	*balPosTab = NULLDYNSTPTR;

	if (GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) == NULL ||
		(genInstr = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext))) == NULLDYNST)
	{
	    return(FALSE);
	}

	if (GET_ID(genInstr, A_Instr_Id) > 0)
	    return(FALSE);

	balPosTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(dynSt, ExtPos_BalPos_ExtPos_Ext);
	if (balPosTab == NULLDYNSTPTR)
	    return(FALSE);
	else
	    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_GenericFwdMMSwap()
**
**  Description :   Create derivated instrument depending on received
**                  generic instrument. (forward, money market, swap, forex swap)
**
**  Arguments   :   hierHeadPtr hierarchy header pointer
**                  pos         pointer on position
**                  genInstr    generic instrument pointer
**
**  Warning     :   This function create a new instrument pointer which will
**                  be deallocated by hierarchy tools.
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   BUG043 - RAK - 960627
**                  BUG053 - RAK - 960709
**                  DVP181 - RAK - 960826
**                  DVP440 - RAK - 970428
**                  BUG376 - RAK - 970603
**                  DVP510 - XDI - 970626
**                  DVP510+- GRD - 970710
**                  REF1210 - RAK - 980128
**                  REF4503 - RAK - 000323
**                  REF7251 - YST - 020501
**                  REF7782 - YST - 020904
**                  PMSTA-32547 - 130818 - PMO : Fixes some division by zero
**
*************************************************************************/
STATIC DBA_DYNFLD_STP DBA_GenericFwdMMSwap(DBA_HIER_HEAD_STP posHierHead, /* REF7264 - LJE - 020201 */
                                           DBA_DYNFLD_STP pos,
				                           DBA_DYNFLD_STP genInstr,
					                       DATETIME_T     fromDate)
{
	DATETIME_T        tmpDate;
	NUMBER_T          unitAccrInter;
	PRICE_T           redempQuote;
	RET_CODE          ret;
	DBA_DYNFLD_STP    newInstr=NULLDYNST;

	if ((newInstr = ALLOC_DYNST(A_Instr)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(NULLDYNST);
	}

	COPY_DYNST(newInstr, genInstr, A_Instr);

	/* Keep last parent instrument, if generic */
	/* instrument was already treated          */
	if (GET_ID(newInstr, A_Instr_Id) > 0)
	    SET_ID(newInstr, A_Instr_ParentInstrId, GET_ID(newInstr, A_Instr_Id));

	/* Update forward fields */
	if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Forward ||
	    GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_FRA)		/* DVP440 - RAK - 970428 */
	{
		ret =  DBA_UpdFwdTermInfo(newInstr, pos, fromDate);

    	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
		    RET_GET_CATEG(ret) == RET_CATEG_MEM)
		{
			FREE_DYNST(newInstr, A_Instr);
			return(NULLDYNST);
		}
	}

	/* Update money market fields */
	if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_MoneyMkt ||
	    GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Discount)
	{
		/* BUG053 - Modify only begin date for non generic - RAK - 960709 */
		if (GET_FLAG(genInstr, A_Instr_GenericFlg) == TRUE)
		{
		    /* REF883 - Update redemption price and quote in */
		    /*          case of they aren't already updated. */
		    if (IS_NULLFLD(newInstr, A_Instr_RedempPrice) == TRUE)
		    { SET_PRICE(newInstr,  A_Instr_RedempPrice,   1.0); }

		    if (IS_NULLFLD(newInstr, A_Instr_RedempQuote) == TRUE)
	        { SET_NUMBER(newInstr,  A_Instr_RedempQuote,   100.0); }

	  	    /* DVP125 - RAK - 960618 */
		    /* BUG376 - RAK - 970603 */
		    if (IS_NULLFLD(pos, ExtPos_Rate) == FALSE)
		    {
                /* REF7251 - YST - 020501 - copy ExtPos_Rate only if no IRC table is defined */
                if ((INTERCD_ENUM)GET_ENUM(newInstr, A_Instr_InterestCdEn) == InterCd_Instr)
                {
			        /* REF3705 - SSO - 990604 : for SubNat_AvrgRate, if ExtPos_Rate is filled,
                       it overwrites A_Instr_AddMarginP instead of A_Instr_InterestRateP */
			        if ((SUBNAT_ENUM)GET_ENUM(genInstr, A_Instr_SubNatEn) == SubNat_AvrgRate ||
                        IS_NULLFLD(newInstr, A_Instr_FloatInstrId) != TRUE)
			        {
			            SET_PERCENT(newInstr, A_Instr_AddMarginP, GET_PERCENT(pos, ExtPos_Rate));
			        }
			        else
			        {
			            SET_PERCENT(newInstr, A_Instr_InterestRateP, GET_PERCENT(pos, ExtPos_Rate));
			            /*SET_ENUM(newInstr,  A_Instr_InterestCdEn,  (ENUM_T) InterCd_Instr);*//* REF7251 - YST - 020501 */
			        }
                }
                /* REF7251 - YST - 020501 - waiting for response from analyst */
                /* else
                {
                   ret = DBA_UpdInterCondGenerInstr(fromDate, newInstr, (PTR)posHierHead, GET_PERCENT(pos, ExtPos_Rate));
                }*/
		    }

		    /* BUG043 - RAK - 960627 */
		    unitAccrInter = FIN_DIV(GET_AMOUNT(pos, ExtPos_AccrAmt), GET_NUMBER(pos, ExtPos_Qty));  /* PMSTA-32547 - 130818 - PMO */
		    SET_NUMBER(newInstr,  A_Instr_UnitAccrInter, unitAccrInter);

	    	/* New end date */
		    if (IS_NULLFLD(pos, ExtPos_ExpirDate) == TRUE)
		    {
			    FLAG_T      usedInstrEndDateFlg = FALSE; /* REF2888 - DDV - 981007 */

		 	    /* REF2888 - DDV - 981007 */
			    GEN_GetApplInfo(ApplJournalGenInstrEndDateFlg, &usedInstrEndDateFlg);

		 	    /* REF2888 - DDV - 981007 */
			    if (usedInstrEndDateFlg == TRUE)
			    {
			        /* REF3749 - SSO - 990705 */
			        if (IS_NULLFLD(genInstr, A_Instr_EndDate) == FALSE)
			        {
				        COPY_DYNFLD(newInstr, A_Instr, A_Instr_EndDate,
			            	        genInstr, A_Instr, A_Instr_EndDate);
			        }
			        else
			        {
				        SET_DATE(newInstr, A_Instr_EndDate, MAGIC_END_DATE);
				        MSG_LogMesg(RET_GEN_ERR_INVARG, 4, FILEINFO,
					                "DBA_GenericFwdMMSwap: instrument end date is missing",
						            GET_CODE(genInstr, A_Instr_Cd));
			        }
			    }
			    else
    			    SET_DATE(newInstr, A_Instr_EndDate, MAGIC_END_DATE); /* RAK BUG208 */
		    }
		    else
		    {
	    		tmpDate = GET_DATETIME(pos, ExtPos_ExpirDate);
	    		SET_DATE(newInstr, A_Instr_EndDate, tmpDate.date);
		    }

		    /* REF1210 - Update instrument begin date only for generic money market */
	    	if (IS_NULLFLD(pos, ExtPos_ValDate) == TRUE)
			    tmpDate = GET_DATETIME(pos, ExtPos_BegDate);
	    	else
			    tmpDate = GET_DATETIME(pos, ExtPos_ValDate);

	    	SET_DATE(newInstr, A_Instr_BeginDate, tmpDate.date);
		}
		/* REF1210 - Ensure that non-generic money market have begin date */
		else if (IS_NULLFLD(newInstr, A_Instr_BeginDate) == TRUE)
		{
	    	if (IS_NULLFLD(pos, ExtPos_ValDate) == TRUE)
			    tmpDate = GET_DATETIME(pos, ExtPos_BegDate);
	    	else
			    tmpDate = GET_DATETIME(pos, ExtPos_ValDate);

	    	SET_DATE(newInstr, A_Instr_BeginDate, tmpDate.date);
		}
	}
	else if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_ForexSwaps) /* DVP510 - XDI - 970624 */
	{
		if (GET_FLAG(genInstr, A_Instr_GenericFlg) == TRUE)
		{
			COPY_DYNFLD(newInstr, A_Instr, A_Instr_BeginDate,
			            pos, ExtPos, ExtPos_ValDate);

			/* REF3749 - SSO - 990705 */
			if (IS_NULLFLD(pos, ExtPos_ExpirDate) == FALSE)
			{
			    COPY_DYNFLD(newInstr, A_Instr, A_Instr_EndDate,
					        pos, ExtPos, ExtPos_ExpirDate);
			}
			else
			{
			    SET_DATE(newInstr, A_Instr_EndDate, MAGIC_END_DATE);
			    MSG_LogMesg(RET_GEN_ERR_INVARG, 4, FILEINFO,
					        "DBA_GenericFwdMMSwap: instrument end date is missing",
					        GET_CODE(genInstr, A_Instr_Cd));
			}
		}

		redempQuote = GET_PRICE(pos, ExtPos_SpotQuote) +		/* REF053 */
			          GET_PRICE(pos, ExtPos_Price);
		if (CMP_NUMBER(redempQuote, 0.0) == 0)
			redempQuote = 1.0;

		if (GET_ID(pos, ExtPos_InstrCurrId) == GET_ID(pos, ExtPos_PosCurrId))
		{
			redempQuote = 1.0/redempQuote;
		}

		SET_NUMBER(newInstr, A_Instr_RedempQuote, CAST_NUMBER(redempQuote)); /* REF3288 - SSO - 990205 */
	}
	else if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Swap)       /* DVP510-XDI-970624 */
	{
		if (GET_FLAG(genInstr, A_Instr_GenericFlg) == TRUE)
		{
            /* REF4772 - RAK - 000706 */
			/* COPY_DYNFLD(newInstr, A_Instr, A_Instr_BeginDate, */	   /* DVP510+-GRD-970710 */
			/*            pos, ExtPos, ExtPos_OpDate); */

            COPY_DYNFLD(newInstr, A_Instr, A_Instr_BeginDate,
			            pos, ExtPos, ExtPos_ValDate);

			COPY_DYNFLD(newInstr, A_Instr, A_Instr_DatedDate,
				        pos, ExtPos, ExtPos_ValDate);
			/* REF3749 - SSO - 990705 */
			if (IS_NULLFLD(pos, ExtPos_ExpirDate) == FALSE)
			{
			    COPY_DYNFLD(newInstr, A_Instr, A_Instr_EndDate,
					        pos, ExtPos, ExtPos_ExpirDate);
			}
			else
			{
                /* REF4503 - RAK - 000323 - So end date will be the SCE computed end date */
                DATETIME_T  begDate, endDate;
                begDate.date = GET_DATE(newInstr, A_Instr_BeginDate);

                if (SCE_CldrAddPeriod(posHierHead, newInstr,
                                      ScePeriod_TenorFreq,
                                      begDate, &endDate) != RET_SUCCEED)
                {
			        SET_DATE(newInstr, A_Instr_EndDate, MAGIC_END_DATE);
			        /* not an error here */
			        MSG_LogMesg(RET_GEN_ERR_INVARG, 4, FILEINFO,
					            "(INFORMATION) DBA_GenericFwdMMSwap: instrument end date is set to imaginary 31/12/9999",
					            GET_CODE(genInstr, A_Instr_Cd));
                }
                else
                {
                    SET_DATE(newInstr, A_Instr_EndDate, endDate.date);
                }
			}

		    /* REF6027 - RAK - 010515 */
            	    /* REF1485 - Update paid interest rate - Generic only - RAK - 000414 */
		    /*    COPY_DYNFLD(newInstr, A_Instr, A_Instr_PaidInterestRateP,
		                    pos, ExtPos, ExtPos_Quote);
		    */
		    if (((SUBNAT_ENUM)GET_ENUM(genInstr, A_Instr_SubNatEn) == SubNat_FixFloatStdSwap ||
                (SUBNAT_ENUM)GET_ENUM(genInstr, A_Instr_SubNatEn) == SubNat_FixFltSwapHedgFix) && /* REF7782 - YST - 020904 */
		        IS_NULLFLD(genInstr, A_Instr_FloatInstrId) == FALSE)
		    {
            	        /* REF1485 - Update paid interest rate - Generic only - RAK - 000414 */
		        COPY_DYNFLD(newInstr, A_Instr, A_Instr_PaidInterestRateP,
		                    pos, ExtPos, ExtPos_Quote);
		    }
		    else
		    {
		        COPY_DYNFLD(newInstr, A_Instr, A_Instr_InterestRateP,
		                    pos, ExtPos, ExtPos_Quote);
		    }
            /* REF7251 - YST - 020501 - copy ExtPos_Rate to additive margin */
            if (IS_NULLFLD(pos, ExtPos_Rate) != TRUE &&
                (INTERCD_ENUM)GET_ENUM(newInstr, A_Instr_InterestCdEn) == InterCd_Instr)
            {
			    SET_PERCENT(newInstr, A_Instr_AddMarginP, GET_PERCENT(pos, ExtPos_Rate));
            }
		}

		SET_NUMBER(newInstr, A_Instr_RedempQuote, 		/* REF053 */
		    GET_PRICE(pos, ExtPos_SpotQuote));

		/* REF1485 - Update A_Instr_CompoQuantity with spote quote */
		COPY_DYNFLD(newInstr, A_Instr, A_Instr_CompoQuantity,
		            pos, ExtPos, ExtPos_SpotQuote);
	}

	/* For create a new instrument identifier */
	/* Now newInstr will be deallocated by hierarchy tools */
	SET_NULL_ID(newInstr, A_Instr_Id);

	return(newInstr);
}

/************************************************************************
**
**  Function    :   DBA_VirtualInstr()
**
**  Description :   Create virtual instrument for the cash account depending on received
**                  instrument. (forward , forexswap, swap and money market)
**
**  Arguments   :   hierHead        hierarchy header pointer
**                  pos             pointer on position
**                  posTab          Sorted array of position. pos is not necessarily in posTab.
**                  idxPosTab       index in posTab of the current treated position
**
**
**  Warning     :   This function create a new instrument pointer which will
**                  be deallocated by hierarchy tools.
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   PMSTA-18096 - LJE - 140620
**
*************************************************************************/
STATIC RET_CODE DBA_VirtualInstr(DBA_HIER_HEAD_STP hierHead,
                                 DBA_DYNFLD_STP    domainPtr,
                                 DBA_DYNFLD_STP    extPos)
{
    RET_CODE            ret = RET_GEN_INFO_NOACTION;
    DBA_DYNFLD_STP      genInstr = NULLDYNST, newInstr = NULLDYNST, mainExtPos, mainInstr;
    MASK_T              riskCashLegRuleMask;
    FLAG_T			    futAccFlg, fwdAccFlg, termAccFlg;

    GEN_GetApplInfo(ApplRiskCashLegRuleMask, &riskCashLegRuleMask);

    if (riskCashLegRuleMask == 0)
        return ret;


	FIN_GetAccFlag(domainPtr,
                   extPos,
                   &futAccFlg,
                   &fwdAccFlg,
                   &termAccFlg);

    /* Generate new instrument for cash leg */
    if (GET_BIT(riskCashLegRuleMask, FWD_CASH_LEG) == TRUE &&
        (fwdAccFlg == FALSE || GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE) &&
        GET_FLAG(extPos, ExtPos_MainFlg) == FALSE &&
        (IS_NULLFLD(extPos, ExtPos_BalPosTpId) == FALSE ||
         GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
         (GET_ENUM(extPos, ExtPos_RefNatEn) == PosRefNat_FwdClose && GET_ENUM(extPos, ExtPos_PosNatEn) == PosNat_AdjPos)))
    {
        if (GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext) == NULL ||
            (genInstr = *(GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext))) == NULLDYNST)
            return(RET_SUCCEED);
            
		/* PMSTA-51476 - DDV - 221216- For instrument having SubNat_FXFwd_TwoLegsAgainsPtfCurr has sub nature, 
		                               virtual instuments are managed in function FIN_CreateFXSplitLegs */ 
		if (GET_ENUM(genInstr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
		{
            return(RET_SUCCEED);
    	}

        if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_CashAcct &&
            GET_EXTENSION_PTR(extPos, ExtPos_Main_ExtPos_Ext) != NULL &&
            (mainExtPos = *(GET_EXTENSION_PTR(extPos, ExtPos_Main_ExtPos_Ext))) != NULL &&
            GET_EXTENSION_PTR(mainExtPos, ExtPos_A_Instr_Ext) != NULL &&
            (mainInstr = *(GET_EXTENSION_PTR(mainExtPos, ExtPos_A_Instr_Ext))) != NULL &&
            GET_ENUM(mainInstr, A_Instr_NatEn) == InstrNat_Forward)
        {
            ret = DBA_CreateCashLegInstr(hierHead, domainPtr, genInstr, mainInstr, &newInstr);
        }

        if ((ret == RET_SUCCEED || ret == RET_DBA_INFO_EXIST) && newInstr != NULL)
            return(DBA_ForceLink(hierHead, ExtPos, ExtPos_A_Instr_Ext, extPos, newInstr));
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_GenericInstr()
**
**  Description :   Create derivated instrument depending on received
**                  generic instrument. (forward , forexswap, swap and money market)
**
**  Arguments   :   hierHead        hierarchy header pointer
**                  pos             pointer on position
**                  posTab          Sorted array of position. pos is not necessarily in posTab.
**                  idxPosTab       index in posTab of the current treated position
**
**
**  Warning     :   This function create a new instrument pointer which will
**                  be deallocated by hierarchy tools.
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP125 - RAK - 960618
**                  BUG053 - RAK - 960709
**                  DVP440 - RAK - 970428
**		            REF2950 - SSO - 981029
**                  PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**                  PMSTA-10895 - 141210 - PMO : Money Markets do not merge when portfolio fusion rule is FIFO, but in valuation domain WMP
*************************************************************************/
RET_CODE DBA_GenericInstr(DBA_HIER_HEAD_STP hierHead,
                          DBA_DYNFLD_STP    pos,
                          DBA_DYNFLD_STP*   posTab,         /* PMSTA05966 - 090525 - PMO */
                          const int         idxPosTab,      /* PMSTA05966 - 090525 - PMO */
			              DATETIME_T        fromDate)
{
	RET_CODE            ret=RET_GEN_INFO_NOACTION;
    DBA_DYNFLD_STP      genInstr = NULLDYNST, newInstr = NULLDYNST;
	DBA_DYNFLD_STP      *instrTab=NULLDYNSTPTR;
    int                 instrNbr=0, i;
    FLAG_T              insertHierFlg=TRUE;
    GENINSTRRULE_ENUM   genInstrRule = GenInstrRule_MergeAll;

    GEN_GetApplInfo(ApplGenericInstrRule, &genInstrRule);

	/* For all money market instrument and forward instrument */
	/* If no link on instrument, do nothing */
	/* DVP172 */
	if (GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext) == NULL ||
	    (genInstr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext))) == NULLDYNST)
		return(RET_SUCCEED);

	/* REF2950 - SSO - 981029 for bal pos (secondairy), dot not duplicate instrument: they need to be linked to the instr
	    of their corresponding position ... */
	if  ((GET_FLAG(pos, ExtPos_MainFlg) != TRUE) && (IS_NULLFLD(pos, ExtPos_BalPosTpId) == FALSE))
	    return(RET_SUCCEED);

	/* DVP125 - Read generic flag - RAK - 960618 */
	/* BUG053 - Modify begin date for non generic - RAK - 960709 */
	if ((GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_MoneyMkt &&
         (IS_NULLFLD(genInstr, A_Instr_BeginDate) == TRUE || GET_FLAG(genInstr, A_Instr_GenericFlg) == TRUE)) ||   /* PMSTA-10895 - 141210 - PMO */
	    GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_ForexSwaps || /* DVP510 - XDI - 970624 */
		GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Swap)       /* DVP510 - XDI - 970624 */
	   /* GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Discount) */ /* PMSTA-28069 - SRIDHARA - 170817 */
	{
	    ret = RET_SUCCEED;
	}

	/* Check if forward instrument is already "created" */
	/* return is RET_DBA_INFO_EXIST and newInstr point on structure */
	if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Forward ||
	    GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_FRA)		/* DVP440 - RAK - 970428 */
	{
	    ret = DBA_CheckGenericForward(hierHead, pos, &newInstr);
    	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		    return(ret);
	}

    /* forward isn't already treated */
	if (ret == RET_SUCCEED)
	{
        /*
         * PMSTA05966 - 090525 - PMO
         * For order money market, try to find an already created instrument if the refnat is used
         */
		/* PMSTA-10153 - RAK - 100622 - verify for the Forward too */
        if(((GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_MoneyMkt && genInstrRule == GenInstrRule_MergeAll) ||
			GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_Forward) &&
           CMP_ID(GET_ID(pos, ExtPos_InstrId), 0) > 0              &&
           GET_ENUM(pos, ExtPos_RefNatEn)  != PosRefNat_None
           )
         {
            DBA_DYNFLD_STP  genInstr2;          /* Instrument of the position to check  */
            ID_T            parentId;           /* Instrument ID to check               */
            FLAG_T		    matchingSrcCdFlg;   /* Value of the system parameter        */

            (void)GEN_GetApplInfo(ApplMatchSourceCdFlag, &matchingSrcCdFlg);

            for (int idx = idxPosTab; idx >= 0; idx--)
            {
                /* PMSTA13123 - DDV - 111103 - Check that extention pointer is not null before getting its content */
                if (GET_EXTENSION_PTR(posTab[idx], ExtPos_A_Instr_Ext) != NULL &&
                    (genInstr2 = *(GET_EXTENSION_PTR(posTab[idx], ExtPos_A_Instr_Ext))) != NULL)
                {
                    parentId = GET_ID(genInstr2, A_Instr_ParentInstrId);

                    if (CMP_ID(GET_ID(pos, ExtPos_InstrId), parentId) == 0 &&
                        (  GET_ENUM(pos, ExtPos_RefNatEn) == PosRefNat_Open
                        || DBA_CheckMatchingCode(matchingSrcCdFlg, GET_CODE(pos, ExtPos_RefOpCd), posTab[idx]) == TRUE
                        ))
                    {
						/* PMSTA-10153 - RAK - 100622 - We found the generic instrument : */
						/* stop for MoneyMkt, prefer Primary for Forward.               */
						if (GET_ENUM(genInstr, A_Instr_NatEn) == InstrNat_MoneyMkt)
						{
							newInstr = genInstr2;
							break;
						}
						else
						{
							if (newInstr!= NULLDYNST || GET_ENUM(posTab[idx], ExtPos_PrimaryEn) == PosPrimary_Primary)
								newInstr = genInstr2;

							/* Prefer the primary */
							if (GET_ENUM(posTab[idx], ExtPos_PrimaryEn) == PosPrimary_Primary)
								break;
						}
                    }

                    if (CMP_ID(GET_ID(pos, ExtPos_InstrId), parentId) > 0 &&
                        CMP_ID(parentId, 0) > 0)
                    { /* Optimization, no chance to found :-(. Stop to search */
                        break;
                    }
                }
            }
			/* PMSTA-10153 - RAK - 100622 - We found the generic instrument, stop */
			if (newInstr != NULLDYNST)
			{
				/* PMSTA08353 - RAK - 090623 */
				/* for PMSTA05966 update link to existing instrument and exit */
				return(DBA_ForceLink(hierHead, ExtPos,
		                                     ExtPos_A_Instr_Ext, pos, newInstr));
			}
        }

        if ((newInstr = DBA_GenericFwdMMSwap(hierHead, pos, /* REF7264 - DDV - 020325 - Compil C++ */
				                             genInstr, fromDate)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

        /* REF10175 - 041011 - DDV - If the same generic instrument allready exist, reuse it based on system parameter value */
        if (genInstrRule == GenInstrRule_MergeAll)
        {
	        if ((ret = DBA_ExtractHierEltRec(hierHead, A_Instr,
		                                    FALSE, DBA_FilterGenericInstr, NULL,
				                            &instrNbr, &instrTab)) == RET_SUCCEED)
	        {
	            for (i=0; i<instrNbr && insertHierFlg==TRUE; i++)
	            {
		            if (CMP_DYNFLD(instrTab[i], newInstr, A_Instr_ParentInstrId, A_Instr_ParentInstrId, IdType) ==0)
                    {
                        SET_ID(newInstr, A_Instr_Id, GET_ID(instrTab[i],A_Instr_Id));

                        if (CMP_DYNST(instrTab[i], newInstr, A_Instr, FALSE, FALSE) == 0)   /*  FPL-REF10596-041020 add parameter metaFldFlg */
                        {
                            FREE_DYNST(newInstr, A_Instr);
                            newInstr=instrTab[i];
                            insertHierFlg=FALSE;
                        }
                    }
	            }
	        }

			FREE(instrTab);		/* PURIFY - RAK - 060814 */
        }

        if (insertHierFlg == TRUE)
        {
            SET_NULL_ID(newInstr, A_Instr_Id);
	        if ((ret = DBA_AddHierRecord(hierHead, newInstr, A_Instr,
			                             FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
	        {
			    FREE_DYNST(newInstr, A_Instr);
			    return(ret);
	        }
	    }
	}

	/* Update link between position and instrument */
	if (ret == RET_SUCCEED || (ret == RET_DBA_INFO_EXIST && newInstr != NULLDYNST))
	    return(DBA_ForceLink(hierHead, ExtPos,
		                     ExtPos_A_Instr_Ext, pos, newInstr));
	else
	    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_UpdExtPosFld()
**
**  Description          : Update loaded extended position, some flags and
**                         nature (stock or flow) and extended position date.
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         fctLnkPtr     links state structure ( BUG515 - XDI - 970930 )
**
**  Return               : RET_SUCCEED or error code
**
**  Modif.		         : BUG118 - RAK - 960903
**  Modif.		         : DVP342 - PEC - 970218
**  Modif.		         : DVP568 - RAK - 970911
**  Modif.		         : REF069 - RAK - 970915
**  Modif.		         : REF417 - RAK - 980107
**  Modif.		         : REF2723 - RAK - 980903
**  Modif.               : REF5295 - DDV - 010221
**  Modif                : REF5035 - CSY - 020220: fwdAccFlg, futAccFlg, termAccFlg are set to FALSE in
**                                                 a context of return or synth admin.
**  Modif.              REF7265 - YST - 020529
**	Modif                : REF9418 - CHU - 031007 code report from 4.00.3B030903 about load_hierarchy
**                         PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**                         PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**                         PMSTA08594 - 140909 - PMO : Unexplained difference running operation list : different number of extended_pos retrieved
**                         PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*************************************************************************/
RET_CODE DBA_UpdExtPosFld(DBA_HIER_HEAD_STP hierHead,
		                  DBA_DYNFLD_STP    domainPtr,
			              PTR               fctLnkPtr) /* BUG515 - XDI - 970930 */
{
	int                 rows, checkDays;
	DBA_DYNFLD_STP      *extrPos=(DBA_DYNFLD_STP*)NULL,
		                newExtPos=(DBA_DYNFLD_STP)NULL,
			            instrPtr=(DBA_DYNFLD_STP)NULL,
			            ptfPtr=NULLDYNST, parPtfPtr=NULLDYNST;
	RET_CODE            ret;
	DATETIME_T          fromDate, tillDate, refDate, extPosDate;
	DICT_FCT_ENUM       fct;
	FLAG_T              noInitial=FALSE, fwdAccFlg, futAccFlg, termAccFlg,
						childInPtfCodeFlg,	/* REF9418B030903 - CSY - 030828 */
                        nullEndDate, used, createInitial, createFinal;
	FLAG_T              updRiskFlg;
	DBA_FCTLNK_STP	    fctLnkStp = (DBA_FCTLNK_STP) fctLnkPtr;
	DICT_FCT_ENUM       fctPosNat;
	ACCVALDATERULE_ENUM valRuleDateMethod;
	DBA_DYNFLD_STP      ptfListPtr=NULLDYNST; /* REF9418 - CHU - 031007 */
	ID_T				perfExpoListId;
	FLAG_T				isInListFlg;

	fct = fctPosNat = (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId);

	/* PMSTA-10111 - RAK - 110211 - treat PERF_EXPOSURE_LIST          */
	/* could be a problem in case of a mix of risk/no risk PSP but as */
	/* the info is already used juste below we have to init flag here */
	if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE &&
	    (fct == DictFct_Return || fct == DictFct_OnLineMktValuePL || fct == DictFct_SynthAdmin))
	{
		GEN_GetApplInfo(ApplPerfExposureList, &perfExpoListId);
		if (perfExpoListId > 0)
		{
			DBA_DYNFLD_STP	*instrTab=NULL;
			int				instrNbr=0;

			if ((ret = DBA_ExtractHierEltRec(hierHead, A_Instr, FALSE, NULLFCT, NULLFCT,
					 &instrNbr, &instrTab)) == RET_SUCCEED && instrNbr > 0)
			{
				for (int i=0; i<instrNbr; i++)
				{
					if (GET_ENUM(instrTab[i], A_Instr_NatEn) == InstrNat_Future ||
						GET_ENUM(instrTab[i], A_Instr_NatEn) == InstrNat_Forward)
					{
						isInListFlg = FALSE;

						if ((ret = FIN_IsInList(hierHead,
									GET_ID(instrTab[i], A_Instr_Id),
									instrTab[i],
									Instr,
									perfExpoListId,
									NULL,	/* will be loaded */
									NULL,
									FALSE,
									NULL,
									&isInListFlg)) == RET_SUCCEED)
						{
							/* update instrument flag */
							if(isInListFlg == FALSE)
							{
								/* By default exposure is done */
								SET_FLAG(instrTab[i], A_Instr_NoPerfExpoFlg, TRUE);
							}
						}
					}
				}
			}
			FREE(instrTab);
		}

	}

    /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
    /* TO DO */
    /* NOT IN ALL CASES */
    /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
    /* we have to update the MainLnk for positions elsewhere test on cash pos of fut/fwd won't work */
    DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Main_ExtPos_Ext);
    DBA_MakeSpecRecLinks(hierHead, ExtPos, ExtPos_Main_ExtPos_Ext);
    DBA_SetHierLnkUnused(hierHead, ExtPos, ExtPos_Main_ExtPos_Ext);

    if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos,
			                         FALSE, NULL, FIN_CmpPosInstrIdRefNat, &rows, &extrPos)) != RET_SUCCEED)    /* PMSTA05966 - 090525 - PMO */
	{
		return(ret);
	}

	/* BEGIN - DVP063 - 960521 - XDI */
	noInitial = FALSE;
	fromDate  = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	refDate   = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);

	if (fct == DictFct_Journal && (DATETIME_CMP(fromDate, refDate) == 0))
	{
		noInitial = TRUE;
		GEN_GetApplInfo(ApplEvtGenCheckDays, &checkDays);
		fromDate.date = DATE_Move(fromDate.date, (-1) * CAST_INT(checkDays), Day);
	}
	/* END - DVP063 - 960521 - XDI */

	tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	/* PMSTA-13140 - LJE - 120319 */
	FIN_GetAccFlag(domainPtr,
     			   NULL,
				   &futAccFlg,
				   &fwdAccFlg,
				   &termAccFlg);

	GEN_GetApplInfo(ApplChildInPtfCode,  &childInPtfCodeFlg);  /* REF9418 - CHU - 031007 */

	/* PMSTA-11875 - RAK - 110517 */
	if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedHierarchical)
		childInPtfCodeFlg = FALSE;

    /* WEALTH-2089 - DDV - 231102 */
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        childInPtfCodeFlg = TRUE;
    }

    GEN_GetApplInfo(ApplAccValDateRule, &valRuleDateMethod);
	for (int i=0; i<rows; i++)
	{
        SET_FLAG(extrPos[i], ExtPos_IsProcessed, FALSE);
        /* Check if a dervived margin call position in operation list must be removed. PMSTA08594 - 140909 - PMO */
        if (DBA_CheckMarginCallPositionToRemove(domainPtr, extrPos[i]) == TRUE)
        {
            DBA_DelHierEltRec(hierHead, ExtPos, extrPos[i]);
            continue;
        }

		/* PMSTA-13140 - LJE - 120319 */
		FIN_GetAccFlag(domainPtr,
	     			   extrPos[i],
					   &futAccFlg,
					   &fwdAccFlg,
					   &termAccFlg);

	   /* REF069 - RAK - 970915 */
	   if (fctLnkStp != (DBA_FCTLNK_STP) NULL &&
	       fctLnkStp->A_Ptf_HierPtf   == TRUE &&
	       fctLnkStp->ExtPos_ChildPtf == TRUE)
	   {
		   parPtfPtr = NULL; /* REF9418B030903 - CSY - 030828: report code from hot fix 4.00.1B030730 */

		    /* Find portfolio parent and modify ExtPos_PtfId and link */
		    if (GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Ptf_Ext) != NULL &&
	                (ptfPtr = *(GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Ptf_Ext))) != NULLDYNST)
            {
                if (GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext) != NULL)
		            parPtfPtr = *(GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext));


				/* REF9418B030903 - CSY - 030828: report code from hot fix 4.00.1B030730 */
				if (childInPtfCodeFlg == FALSE  ||
					(GET_DICT(domainPtr, A_Domain_FctDictId) ==  (DICT_FCT_ENUM)DictFct_ReconcStrat||
					 GET_DICT(domainPtr, A_Domain_FctDictId) == (DICT_FCT_ENUM)DictFct_AllocateOrder ||
					 GET_DICT(domainPtr, A_Domain_FctDictId) == (DICT_FCT_ENUM)DictFct_OrderAllocation ||
					 GET_DICT(domainPtr, A_Domain_FctDictId) == (DICT_FCT_ENUM)DictFct_CheckStratValo) ||
					 (GET_DICT(domainPtr, A_Domain_FctDictId) == (DICT_FCT_ENUM)DictFct_Valo &&                                /*PMSTA-27834 - NRAO - 170720*/
					 GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_AllocateOrder))
				{
					/* PMSTA-11788 - RAK - 110427 - exception for the new mode DetailedChildren in CheckStrat : children keep their pos anyway */
					if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) != (DICT_FCT_ENUM)DictFct_CheckStrat ||
						(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_CheckStrat &&
					    (PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren))
					{
						/* REF9297.4001B030715b - DDV - if parent portfolio not found in Hier, load it from Db */
						if (parPtfPtr == NULLDYNST && GET_ID(ptfPtr, A_Ptf_HierPortId) >0)
	   					{
							FLAG_T allocFlg=FALSE;

                            /* PMSTA12465 - DDV - 110822 - Store portfolio in hierarchy only if it match Domain dimensions, we assume that portfolio allready in hierarchy match domain */
							DBA_GetPtfById(GET_ID(ptfPtr, A_Ptf_HierPortId), FALSE, &allocFlg, &parPtfPtr, hierHead, UNUSED, UNUSED);

                            /* PMSTA12465 - DDV - 110822 - If the porfolio has not been found in hierarchy, check if it match domain dimensions */
							if (parPtfPtr != NULLDYNST && allocFlg == TRUE)
	   						{
							    if (DBA_CheckPtfDim(domainPtr, hierHead,
											    GET_ID(parPtfPtr, A_Ptf_Id),
											    parPtfPtr, &ptfListPtr, FALSE,
											    (DATETIME_STP) NULL, NULLDYNSTPTR, 0) == TRUE)
	   							{
                                    DBA_AddHierRecord(hierHead, parPtfPtr, A_Ptf, FALSE, HierAddRec_ForceInsert);

									if ((ret = DBA_ForceLink(hierHead, A_Ptf,
										             A_Ptf_HierPtf_Ext, ptfPtr, parPtfPtr))!=RET_SUCCEED)
									return(ret);
								}
                                else
                                {
                                    FREE_DYNST(parPtfPtr, A_Ptf);
                                }
							}
						}

						if(parPtfPtr != NULLDYNST)
						{
							SET_ID(extrPos[i], ExtPos_PtfId, GET_ID(parPtfPtr, A_Ptf_Id));

							if ((ret = DBA_ForceLink(hierHead, ExtPos,
												 ExtPos_A_Ptf_Ext, extrPos[i], parPtfPtr))!=RET_SUCCEED)
								return(ret);

							/* PMSTA-11788 - RAK - 110427 */
							if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_MergedHierarchical)
							{
								/* Update ExtPos_ChildPtfId (link will be done with others links) */
								SET_ID(extrPos[i], ExtPos_ChildPtfId, GET_ID(ptfPtr, A_Ptf_Id));
							}
						}
					}
				}
			}
        }
       /* ExtPos_PrimaryEn get changed later by some function, so copy value to ExtPos_DBPrimaryEn
          which isn't changed and contains therefore same value as in database - REF7265 - YST - 020529 */
       SET_ENUM(extrPos[i], ExtPos_DBPrimaryEn, GET_ENUM(extrPos[i], ExtPos_PrimaryEn));

	   /*** Create temporary record for generic instrument ***/
	   if (fct != DictFct_OpHist &&
	       fct != DictFct_OpList &&
	       fct != DictFct_CopyOperation &&			/* DVP545 */
           fct != DictFct_CurrencyModify &&			/* DVP009 - DED - 070396 */
	       fct != DictFct_OrderList &&				/* DVP342 - PEC - 130297 */
		   fct != DictFct_OrderGrouping &&			/* REF11764 - RAK - 060330 */
           fct != DictFct_HierarchyGrouping &&		/* PMSTA-40208 - sanand - 24092020 */
		   fct != DictFct_UpdateField &&			/*  HFI-PMSTA-35324-190328  */
		   fct != DictFct_UpdateData &&			    /*  HFI-PMSTA-35324-190328  */
	       fct != DictFct_Archive)					/* REF2467 - DDV - 991216 */
	   {
	   	    ret = DBA_GenericInstr(hierHead, extrPos[i], extrPos, i, fromDate);    /* PMSTA05966 - 090525 - PMO */

	   	    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	   	    {
			    FREE(extrPos); /* Only array pointer */
			    return(ret);
	   	    }
	   }

       /* PMSTA-18096 - LJE - 140620 */
       /*** Create record for cash account of forward instrument ***/
       if (fct == DictFct_CheckStratValo ||
           (fct == DictFct_Return && GET_ENUM(domainPtr, A_Domain_PLMethodEn) != PLMethod_OnLineMktValPL && GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_Global) ||
           fct == DictFct_OnLineMktValuePL)
       {
           ret = DBA_VirtualInstr(hierHead, domainPtr, extrPos[i]);

           if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
           {
               FREE(extrPos); /* Only array pointer */
               return(ret);
           }
       }

       /*** Update flags and natures ***/
	   SET_FLAG(extrPos[i],    ExtPos_ForecastFlg,   FALSE);
	   SET_PERCENT(extrPos[i], ExtPos_Proba,         100);
	   SET_ENUM(extrPos[i],    ExtPos_PosDateRuleEn, PosDateRule_BaseValue);

	   updRiskFlg = FALSE;



	   if (fct == DictFct_Valo   ||
	       fct == DictFct_CheckStratValo || /* DVP049 - RAK - 960507 */
	       fct == DictFct_Return ||
	       fct == DictFct_Perfo  ||
           fct == DictFct_FundValo ||		/* REF3082 - 981127 - KRT */
           fct == DictFct_OnLineMktValuePL)	/* PMSTA-10439 - RAK - 100824 */
	   {
		    if (GET_FLAG(extrPos[i], ExtPos_MainFlg) == FALSE)
		    {
				if (fwdAccFlg == TRUE &&
                    (GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
                     GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FwdClose))
			    {
					instrPtr = NULLDYNST;
					if (GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Instr_Ext) != NULL)
					{
						instrPtr = *(GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Instr_Ext));
					}
					/* PMSTA-51476 - DDV - 221216- Keep both legs for instrument having SubNat_FXFwd_TwoLegsAgainsPtfCurr has sub nature */
					if (instrPtr == NULLDYNSTPTR || GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FXFwd_TwoLegsAgainsPtfCurr)
					{
						updRiskFlg = TRUE;	/* std case : 1 leg */
					}
				}

		        if (futAccFlg == TRUE &&
					(GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FutOpen     ||
					 GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FutClose    ||
					 GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FutFifo     ||
					 GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FutWMP      || /* PMSTA-4559 - 011107 - PMO */
                     GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FutContract || /* PMSTA-17898 - 160414 - PMO */
                     GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FRAOpen     || /* DVP440 */
					 GET_ENUM(extrPos[i], ExtPos_RefNatEn) == PosRefNat_FRAClose    ))
				{
					updRiskFlg = TRUE;	/* std case */
				}

		        if (termAccFlg == TRUE &&
		        (GET_ENUM(extrPos[i], ExtPos_RefNatEn)==PosRefNat_TermOpen ||
		         GET_ENUM(extrPos[i], ExtPos_RefNatEn)==PosRefNat_TermClose))
			        updRiskFlg = TRUE;
		    }
	   }

	   if (updRiskFlg == TRUE)
	   {
	    	SET_FLAG(extrPos[i], ExtPos_AcctFlg,   FALSE);
		    SET_ENUM(extrPos[i], ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	   }
	   else
	   {
   	  	    SET_FLAG(extrPos[i], ExtPos_AcctFlg,   TRUE);
	   	    SET_ENUM(extrPos[i], ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	   }

        /* PMSTA08174 - DDV - 090504 - Change null end date with MAGIC_END_DATE */
        if (IS_NULLFLD(extrPos[i], ExtPos_EndDate) == TRUE)
            SET_DATE(extrPos[i], ExtPos_EndDate, MAGIC_END_DATE);


	   /*** Update position nature (flow, stock) ***/
	   switch (fct)
	   {
	   case DictFct_Valo :
       case DictFct_ForexHedging:
			/* PMSTA13795 DDV - 120423 */
			if ((PLMETHOD_ENUM) GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_OnLineMktValPL)
            {
				if ((DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_BegDate), fromDate) <= 0) &&
					((IS_NULLFLD(extrPos[i], ExtPos_EndDate) == TRUE) ||
					 (DATETIME_CMP(fromDate, GET_DATETIME(extrPos[i], ExtPos_EndDate)) <  0)))
				{
					SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
					SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
			        SET_ENUM(extrPos[i], ExtPos_PrimaryEn, PosPrimary_Primary);
				}
			}
            /* WEALTH-5194 - Deepthi -20240718 - For Reprocess PL method, in case of domain ccy not equal to Porfolio ccy,
                                         ref ccy updation and then logical fusion should be triggered */
            else if ((PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL)
            {
                if ((DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_BegDate), fromDate) <= 0) &&
                    ((IS_NULLFLD(extrPos[i], ExtPos_EndDate) == TRUE) ||
                        (DATETIME_CMP(fromDate, GET_DATETIME(extrPos[i], ExtPos_EndDate)) < 0)))
                {
                    SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
                    SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
                    SET_ENUM(extrPos[i], ExtPos_PrimaryEn, PosPrimary_Primary);
                }
            }
            else
            {
		        SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
		        SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
            }
		    break;

	   case DictFct_FundValo :       /* DVP034 - 960515 - XDI */
       case DictFct_CheckStratValo : /* DVP049 - RAK - 960507 */
		    SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
		    SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
		    break;
	   case DictFct_Archive:
	        SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_Flow);
	        break;
	   case DictFct_CurrencyModify :				/* DVP009 - DED - 070396 */
		    SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_Flow);
		    SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, GET_DATETIME(extrPos[i], ExtPos_BegDate));
	        break;

	   case DictFct_OrderList :					/* DVP342+ - PEC - 180297 */
	   case DictFct_OrderGrouping :				/* REF11764 - RAK - 060330 */
	   case DictFct_UpdateField :				/*  HFI-PMSTA-35324-190328  */
	   case DictFct_UpdateData :				/*  HFI-PMSTA-35324-190328  */
       case DictFct_HierarchyGrouping:			/* PMSTA-40208 - sanand - 24092020 */
		    SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_Flow);
		    SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, GET_DATETIME(extrPos[i], ExtPos_BegDate));
		    break;

	   case DictFct_Journal :

            /* BEGIN - DVP063 - 960521 - XDI */
            used = FALSE;
            createInitial = FALSE;
            createFinal = FALSE;

            nullEndDate = (FLAG_T) (IS_NULLFLD(extrPos[i], ExtPos_EndDate) == TRUE);
		    /* DVP172 */
		    instrPtr = NULLDYNST;

            if (GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Instr_Ext) != NULL &&
		        ((instrPtr = *(GET_EXTENSION_PTR(extrPos[i], ExtPos_A_Instr_Ext))) != NULLDYNST) &&
                GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct &&
	            GET_ENUM(extrPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
            {
                extPosDate = GET_DATETIME(extrPos[i], ExtPos_ValDate);
            }
            else
            {
                extPosDate = GET_DATETIME(extrPos[i], ExtPos_BegDate);
            }

            /* Flow position */
            if (DATETIME_CMP(extPosDate, fromDate) >  0 &&
	            GET_ENUM(extrPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
            {
                used = TRUE;
                SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_Flow);
                SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, extPosDate);

                /* if value date is bigger as from date, and position closed */
                /* a initial position must be create */
                if (DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_EndDate), fromDate) <= 0)
                {
                    createInitial = TRUE;
                }

                /* if value date is bigger as ref date, and position closed at ref date */
                /* or value date is smaller as ref date and beg date is bigger, */
                /* a final position must be create */
                if ((DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_EndDate), refDate) <= 0 &&
                     DATETIME_CMP(extPosDate, refDate) > 0) ||
                    (DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_BegDate), refDate) > 0 &&
                     DATETIME_CMP(extPosDate, refDate) <= 0))
                {
                    createFinal = TRUE;
                }
            }
            else
            {
                /* if value date is smaller as from date, and begin date bigger */
                /* a initial position must be create */
                if (DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_BegDate), fromDate) > 0 &&
	            GET_ENUM(extrPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
                {
                    createInitial = TRUE;
                }

            }

            /* Flow position */
            /* generate flow for close position with value date in future */ /* BUG550 - XDI - 970804 */
            if (used == FALSE &&
                DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_ValDate), fromDate) >  0 &&
	            GET_ENUM(extrPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
            {
                used = TRUE;
                SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_Flow);
                COPY_DYNFLD(extrPos[i], ExtPos, ExtPos_ExtPosDate,
                            extrPos[i], ExtPos, ExtPos_BegDate);
                /*COPY_DYNFLD(extrPos[i], ExtPos, ExtPos_ExtPosDate,*/
                            /*extrPos[i], ExtPos, ExtPos_ValDate);*/

                /* if value date is bigger as from date, and position closed */
                /* a initial position must be create */
                if (DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_EndDate), fromDate) <= 0)
                {
                    createInitial = TRUE;
                }

            }

            /* Initial position */
            if (noInitial == FALSE)
            {
                if (createInitial ||
                    ((DATETIME_CMP(extPosDate, fromDate) <= 0) &&
                    ((nullEndDate == TRUE) ||
                     (DATETIME_CMP(fromDate, GET_DATETIME(extrPos[i], ExtPos_EndDate)) <  0))))
                {
                    if (used == FALSE)
                    {
                        used = TRUE;
                        /* Initial stock */
                        SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
                        SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
			            SET_ENUM(extrPos[i], ExtPos_PrimaryEn, PosPrimary_Primary); /* BUG549 - XDI - 970804 */

                        /* if position is closed at from date, invers sign of quantity and amounts */
                        if (createInitial == TRUE &&
                            DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_EndDate), fromDate) <= 0)
                        {
                            DBA_InverseSign(extrPos[i]);
                        }

                        if (createInitial == TRUE)
                            SET_DATETIME(extrPos[i], ExtPos_BegDate, fromDate);
                    }
                    else
                    {
                        /* Create a new position */
                        if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULL)
                        {
                            FREE(extrPos);
                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                        }

                        COPY_DYNST(newExtPos, extrPos[i], ExtPos);

                        SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_InitStock);
                        SET_DATETIME(newExtPos, ExtPos_ExtPosDate, fromDate);
			            SET_ENUM(newExtPos, ExtPos_PrimaryEn, PosPrimary_Primary); /* BUG549 - XDI - 970804 */

                        /* if position is closed at from date, invers sign of quantity and amounts */
                        if (createInitial == TRUE &&
                            DATETIME_CMP(GET_DATETIME(newExtPos, ExtPos_EndDate), fromDate) <= 0)
                        {
                            DBA_InverseSign(newExtPos);
                        }

                        if (createInitial == TRUE)
                            SET_DATETIME(newExtPos, ExtPos_BegDate, fromDate);

                        /* HierAddRec_NoLnk : Don't try to set links, they */
                        /* are set after hierarchy sort by DBA_MakeLinks() */
                        SET_NULL_ID(newExtPos, ExtPos_Id);
                        if ((ret = DBA_AddHierRecord(hierHead,
                                                     newExtPos, ExtPos, FALSE,
                                                     HierAddRec_NoLnk)) != RET_SUCCEED)
                        {
                            FREE_DYNST(newExtPos, ExtPos);
                            FREE(extrPos);
                            return(ret);
                        }

                        /* BUG515 - XDI - 970930 */
	                    if ((ret = DBA_FctLnkFirst(hierHead, fctLnkStp, FALSE, /* REF7264 - DDV - 020325 - Compil C++ */
                                                   extrPos[i], newExtPos)) != RET_SUCCEED)
                        {
                            FREE(extrPos);
                            return(ret);
                        }
                    }
                }
            }

            /* final position */
            if (createFinal ||
                ((DATETIME_CMP(extPosDate, refDate) <= 0) &&
                 ((nullEndDate == TRUE) ||
                  (DATETIME_CMP(refDate, GET_DATETIME(extrPos[i], ExtPos_EndDate)) <  0))))
            {
                if (used == FALSE)
                {
                    used = TRUE;
                    SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_FinalStock);
                    SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, refDate);
			        SET_ENUM(extrPos[i], ExtPos_PrimaryEn, PosPrimary_Primary); /* BUG549 - XDI - 970804 */

                    /* if position is closed at ref date, invers sign of quantity and amounts */
                    if (createFinal == TRUE &&
                        DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_EndDate), refDate) <= 0)
                    {
                        DBA_InverseSign(extrPos[i]);
                    }

                    if (createFinal == TRUE)
                        SET_DATETIME(extrPos[i], ExtPos_BegDate, fromDate);
                }
                else
                {
                    /* Create a new position */
                    if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULL)
                    {
                        FREE(extrPos);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    COPY_DYNST(newExtPos, extrPos[i], ExtPos);
                    SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_FinalStock);
                    SET_DATETIME(newExtPos, ExtPos_ExtPosDate, refDate);
			        SET_ENUM(newExtPos, ExtPos_PrimaryEn, PosPrimary_Primary); /* BUG549 - XDI - 970804 */

                    /* if position is closed at ref date, invers sign of quantity and amounts */
                    if (createFinal == TRUE &&
                        DATETIME_CMP(GET_DATETIME(newExtPos, ExtPos_EndDate), refDate) <= 0)
                    {
                        DBA_InverseSign(newExtPos);
                    }

                    if (createFinal == TRUE)
                        SET_DATETIME(newExtPos, ExtPos_BegDate, fromDate);

                    /* HierAddRec_NoLnk : Don't try to set links, they */
                    /* are set after hierarchy sort by DBA_MakeLinks() */
                    SET_NULL_ID(newExtPos, ExtPos_Id);
                    if ((ret = DBA_AddHierRecord(hierHead,
                                                 newExtPos, ExtPos, FALSE,
                                                 HierAddRec_NoLnk)) != RET_SUCCEED)
                    {
                        FREE_DYNST(newExtPos, ExtPos);
                        FREE(extrPos);
                        return(ret);
                    }

                    /* BUG515 - XDI - 970930 */
	                if ((ret = DBA_FctLnkFirst(hierHead, fctLnkStp, FALSE,  /* REF7264 - DDV - 020325 - Compil C++ */
                                               extrPos[i], newExtPos)) != RET_SUCCEED)
                    {
                        FREE(extrPos);
                        return(ret);
                    }
                }
            }

            if (used == FALSE)
            {
                DBA_DelHierEltRec(hierHead, ExtPos, extrPos[i]); /* REF7264 - DDV - 020325 - Compil C++ */
            }
            break;
            /* END - DVP063 - 960521 - XDI */

	   case DictFct_Perfo :
	   case DictFct_OpHist :
	   case DictFct_OpList :
	   case DictFct_CopyOperation : /* DVP545 */
            /* REF5295 - DDV - 010221 */
            if ((ret = DBA_UpdExtPosNatPerfo(hierHead, extrPos[i], domainPtr,
                                                fromDate, tillDate, fctLnkStp)) != RET_SUCCEED)
            {
                FREE(extrPos);
                return(ret);
            }
		    break;

	   case DictFct_Return :
		   /* < REF9383 - CHU - 030813 (DVP COSBA) */
			switch ((PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn))
			{
			case PLMethod_OnLineMktValPL :
			case PLMethod_ReprocessPL:
				if ((DATETIME_CMP(GET_DATETIME(extrPos[i], ExtPos_BegDate), fromDate) <= 0) &&
					((IS_NULLFLD(extrPos[i], ExtPos_EndDate) == TRUE) ||
					 (DATETIME_CMP(fromDate, GET_DATETIME(extrPos[i], ExtPos_EndDate)) <  0)))
				{
					SET_DATETIME(extrPos[i], ExtPos_ExtPosDate, fromDate);
					SET_ENUM(extrPos[i], ExtPos_NatEn, ExtPosNat_InitStock);
			        SET_ENUM(extrPos[i], ExtPos_PrimaryEn, PosPrimary_Primary);
				}
			}
			/* No break */
			/* REF9383 - CHU - 030813 > */
	   case DictFct_MultiValo :
		    /* ExtPos_ExtPosDate and ExtPos_NatEn  */
		    /* treated later in financial function */
		    break;

       /* PMSTA-10439 - RAK - 100824 - OK, continue */
	   case DictFct_OnLineMktValuePL :
		    break;
	   default :
		    FREE(extrPos);
		    MSG_RETURN(RET_GEN_ERR_INVARG);
	   }

	}

	if (ptfListPtr != NULLDYNST)	/* REF9418 - CHU - 031007 */
        FREE_DYNST(ptfListPtr, A_List);

	FREE(extrPos);
	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_UpdBalPosForGenInstr()
**
**  Description          : Update loaded bal pos for position relative to generic instrument
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         fctLnkPtr     links state structure
**
**  Return               : RET_SUCCEED or error code
**  Created		 : REF2950 - SSO - 981029
**  Modification	 : REF3542 - AKO - 990412
**			 : REF3740 - AKO - 990720
**			 : REF3740 - AKO - 990722
**
*************************************************************************/
STATIC RET_CODE DBA_UpdBalPosForGenInstr(DBA_HIER_HEAD_STP hierHead, /* REF7264 - LJE - 020201 */
		                                 DBA_DYNFLD_STP domainPtr,
			                             PTR            fctLnkPtr)
{
	DBA_DYNFLD_STP      *extrPos=(DBA_DYNFLD_STP*)NULL,
		                pos=(DBA_DYNFLD_STP)NULL,
			            genInstr=(DBA_DYNFLD_STP)NULL;
	DBA_DYNFLD_STP	    *balPosTab = NULLDYNSTPTR;
	int		            balPosNbr=0, i=0, j=0, rows;
	RET_CODE            ret;


	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos,
			                         FALSE, DBA_FilterPosGenericInstr,
                                     NULL, &rows, &extrPos)) != RET_SUCCEED)
	{
	    return(ret);
	}

	for (i=0; i<rows; i++)
	{
	    pos = extrPos[i];

	    genInstr = NULLDYNST;
	    if (GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext) == NULL ||
		    (genInstr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext))) == NULLDYNST)
	    {
	        continue;
	    }

	    /* REF2950 - SSO - 981029 : update links of associated bal pos
		    NOTE: the links are done at this point, their init have been moved in lnkFirst...*/
	    balPosTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(pos, ExtPos_BalPos_ExtPos_Ext);
	    balPosNbr = (int)GET_EXTENSION_NBR(pos, ExtPos_BalPos_ExtPos_Ext);

	    if (balPosTab == NULLDYNSTPTR)
		continue; /* no associated bal pos */

	    for (j=0 ; j<balPosNbr ; j++)
	    {
		    /* REF3841 - SSO - 990803 */
		    if (GET_ID(genInstr, A_Instr_Id) != GET_ID(balPosTab[j], ExtPos_InstrId))
		        continue;

		    if ( (ret = DBA_ForceLink(hierHead, ExtPos,
			                          ExtPos_A_Instr_Ext, balPosTab[j], genInstr)) != RET_SUCCEED)
		    {
			    FREE(extrPos); /* only array pointer copyFlg is false */ /* REF3542 - AKO - 990412 */
			    return(ret);
		    }
	    }
	} /* loop on positions */

	FREE(extrPos); /* only array pointer copyFlg is false */ /* REF3542 - AKO - 990412 */
	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_UpdFwdTermInfo()
**
**  Description          : Read term event at specified date and update
**                         instrument fields
**
**  Arguments            : instrPtr  instrument structure pointer
**                         pos       position pointer on NULLDYNST
**                         fromDate  date
**
**  Return               : RET_SUCCEED, RET_DBA_INFO_NODATA or error code
**
**  Modif  		         : BUG103 - RAK - 960821
**  Modif  		         : REF3030 - RAK - 981118
**
*************************************************************************/
RET_CODE DBA_UpdFwdTermInfo(DBA_DYNFLD_STP instrPtr,
                            DBA_DYNFLD_STP pos,
			                DATETIME_T     fromDate)
{
	RET_CODE       ret;
	DBA_DYNFLD_STP termEvt=NULLDYNST;
	DATETIME_T     tmpDate, tmpBegDate;
	PRICE_T        price=0.0, quote=0.0;

	memset(&tmpBegDate, 0, sizeof(DATETIME_T));
	memset(&tmpDate, 0, sizeof(DATETIME_T));

    /* Get event information */
	if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((ret = DBA_GetTermEvt(instrPtr, fromDate.date, termEvt)) != RET_SUCCEED)
    {
		SET_NULL_ID(instrPtr,     A_Instr_UnderlyInstrId);
		SET_NULL_ID(instrPtr,     A_Instr_ExerCurrId);
		SET_FLAG(instrPtr,        A_Instr_PhysicalFlg, FALSE);
		SET_ENUM(instrPtr,        A_Instr_OptionClassEn, OptClass_None);
		SET_ENUM(instrPtr,        A_Instr_OptStyleEn, OptStyle_None);
		SET_NULL_DATE(instrPtr,   A_Instr_BeginDate);
		SET_DATE(instrPtr,        A_Instr_EndDate, MAGIC_END_DATE); /* RAK BUG208 */
    	SET_NULL_PRICE(instrPtr, A_Instr_RedempPrice);
    	SET_NULL_NUMBER(instrPtr, A_Instr_RedempQuote);

		ret = RET_DBA_INFO_NODATA;
	}
	else
	{
		SET_ID(instrPtr,   A_Instr_UnderlyInstrId, GET_ID(termEvt, A_TermEvt_UnderlyInstrId));
		SET_ID(instrPtr,   A_Instr_ExerCurrId,   GET_ID(termEvt, A_TermEvt_CurrId));
		SET_FLAG(instrPtr, A_Instr_PhysicalFlg,  GET_FLAG(termEvt, A_TermEvt_PhysicalFlg));
		SET_ENUM(instrPtr, A_Instr_OptionClassEn,   GET_ENUM(termEvt, A_TermEvt_OptionClassEn));
		SET_ENUM(instrPtr, A_Instr_OptStyleEn,   GET_ENUM(termEvt, A_TermEvt_OptStyleEn));

		if (GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE)
		{
		    if (pos != NULLDYNST)
		    {
    		    /* New begin date */
			    /* BUG103 */
    		    if (IS_NULLFLD(pos, ExtPos_OpDate) == TRUE)
			        tmpBegDate = GET_DATETIME(pos, ExtPos_BegDate);
    		    else
			        tmpBegDate = GET_DATETIME(pos, ExtPos_OpDate);

    		    /* New end date */
			    if (IS_NULLFLD(pos, ExtPos_ExpirDate) == TRUE)
			    {
			        /* DVP440 */
			        if (/* GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FRA && REF3030 */
				        IS_NULLFLD(pos, ExtPos_ValDate) == FALSE)
			        {
				        tmpDate = GET_DATETIME(pos, ExtPos_ValDate);
		    	                price = GET_PRICE(pos, ExtPos_Price);
		    	                quote = GET_PRICE(pos, ExtPos_Quote);
				        ret = RET_SUCCEED;
			        }
			        else
			        {
	  		            ret = RET_DBA_ERR_INVDATA;
                                    MSG_SendMesg(ret, 1,FILEINFO, "DBA_UpdFwdTermInfo",
			                         GET_CODE(instrPtr, A_Instr_Cd), "expiration date");
			        }
			    }
			    else
			    {
    	  	    	tmpDate = GET_DATETIME(pos, ExtPos_ExpirDate);
		    	    price = GET_PRICE(pos, ExtPos_Price);
		    	    quote = GET_PRICE(pos, ExtPos_Quote);
			        ret = RET_SUCCEED;
			    }
		    }
		    else
		    {
			    ret = RET_GEN_ERR_INVARG;
	    		MSG_SendMesg(ret, 1, FILEINFO, "DBA_UpdFwdTermInfo",
				         "position pointer");
		    }
		}
		else
		{
		    if (IS_NULLFLD(termEvt, A_TermEvt_BeginDate) == TRUE ||
			IS_NULLFLD(termEvt, A_TermEvt_EndDate) == TRUE ||
			IS_NULLFLD(termEvt, A_TermEvt_ExerPrice) == TRUE ||
			IS_NULLFLD(termEvt, A_TermEvt_ExerQuote) == TRUE)
		    {
			    ret = RET_DBA_ERR_INVDATA;
                MSG_SendMesg(ret, 1,FILEINFO, "DBA_UpdFwdTermInfo",
			                GET_CODE(instrPtr, A_Instr_Cd),
			                "event informations");
		    }
		    else
		    {
		    	tmpBegDate.date = GET_DATE(termEvt, A_TermEvt_BeginDate);
		    	tmpDate.date = GET_DATE(termEvt, A_TermEvt_EndDate);
		    	price = GET_PRICE(termEvt, A_TermEvt_ExerPrice);
		    	quote = GET_PRICE(termEvt, A_TermEvt_ExerQuote);
		    	ret = RET_SUCCEED;
		    }
		}

		if (ret == RET_SUCCEED)
		{
    		SET_DATE(instrPtr,   A_Instr_BeginDate, tmpBegDate.date);
    		SET_DATE(instrPtr,   A_Instr_EndDate, tmpDate.date);
		    SET_PRICE(instrPtr, A_Instr_RedempPrice, price);
		    SET_PRICE(instrPtr, A_Instr_RedempQuote, quote);
		}
	}

	FREE_DYNST(termEvt, A_TermEvt);

	return(ret);
}

/************************************************************************
**  Function             : DBA_UpdPosValFld()
**
**  Description          : Transform Ref_* fields to current reference currency.
**			               PosVal inserted by function FIN_InsertPosVal() have ptf
**			               currency for Ref_* fields.
**
**  Warning		         : Links ExtPos_PosVal_Ext and ExtPos_A_Ptf_Ext must be done
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**
**  Return               : RET_SUCCEED or error code
**
**  Modif.		         : REF171 - RAK - 970915
**  Modif.		         : REF2313 - RAK - 980910
**
*************************************************************************/
RET_CODE DBA_UpdPosValFld(DBA_HIER_HEAD_STP posHierHead,
		                  DBA_DYNFLD_STP    domainPtr)
{
	int               posNbr, i, posValNbr=0;
	DBA_DYNFLD_STP    *extractPos=(DBA_DYNFLD_STP*)NULL,
	                  posValPtr=NULLDYNST, ptfPtr=NULLDYNST;
	AMOUNT_T          tmpVal;
	ID_T              refCurrId, ptfCurrId;
	DATETIME_T        date;
	char              copyRecFlg;
	RET_CODE          ret;
	FIN_EXCHARG_ST    exchArgSt;			/* REF2313 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */

	/* REF6220 - LJE - 020305 : Dont process this function is default currency flag is true */
	if (domainPtr != NULL &&
		GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE)
	{
		return RET_SUCCEED;
	}

	/* REF171, verify first if there is some posVal */
	if ((ret = DBA_HierGetRecNbr(posHierHead, PosVal,
				                 NULLFCT, &posValNbr, FALSE)) != RET_SUCCEED)
		return(ret);

	if (posValNbr == 0)
		return(RET_SUCCEED);

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
				                     copyRecFlg, NULLFCT, NULLFCT,
				                     &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret);

	if (posNbr == 0)
		return(RET_SUCCEED);

    refCurrId = GET_ID(domainPtr, A_Domain_CurrId);

	for (i=0; i<posNbr; i++)
	{
		/* DVP172 */
		posValPtr = NULLDYNST;
		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
		    (posValPtr=*(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext)))!=NULLDYNST)
		{
           	/* If necessary, convert net value, mkt value and accrued   */
			/* interest in current reference currency.                  */
			/* (stored in portfolio currency by fct FIN_InsertPosVal()) */
			/* DVP172 */
			ptfPtr = NULLDYNST;
			if(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext) != NULL)
				ptfPtr=*(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext));

            ptfCurrId = GET_ID(ptfPtr, A_Ptf_CurrId);

           	if (refCurrId != ptfCurrId)
           	{
				date = GET_DATETIME(posValPtr, PosVal_Date);

				/* REF2313 - Use new arguments structure */
				exchArgSt.srcAmt =  GET_AMOUNT(posValPtr, PosVal_RefMktValAmt);
                FIN_ExchAmt(date, ptfCurrId, refCurrId,
					        0, NULLDYNST, extractPos[i], &exchArgSt,
                            (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, tmpVal);

				exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt);
                FIN_ExchAmt(date, ptfCurrId, refCurrId,
				            0, NULLDYNST, extractPos[i], &exchArgSt,
					        (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt, tmpVal);

				exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(date, ptfCurrId, refCurrId,
					        0, NULLDYNST, extractPos[i], &exchArgSt,
                            (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefNetAmt, tmpVal);
           	}
		}
	}

	FREE(extractPos);  /* Only array pointer */
	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_ExtExecCalcQtyAndWeightMeanQuote()
**
**  Description          : Compute executed quantity and weigthed mean quote
**
**  Arguments            : extOp and extExecution arrays
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF5760 - DDV - 020604
**
**  Modif.		         : REF9764 - CHU - 040113
**
*************************************************************************/
RET_CODE DBA_ExtExecCalcQtyAndWeightMeanQuote(DBA_DYNFLD_STP	*extOpTab,
											  int				extOpNbr,
											  DBA_DYNFLD_STP	*extExecutionTab,
											  int				extExecutionNbr)
{
    ID_T		opId;
    NUMBER_T	qty;
    PRICE_T     weightMeanQuote;
	int			i, j;

    if (extExecutionNbr > 1)
    {
        TLS_Sort((char *)(extExecutionTab),
                  extExecutionNbr,
                  sizeof(DBA_DYNFLD_STP),
                  (TLS_CMPFCT*)FIN_CmpExecByOrderId,
                  (PTR **) NULL,
                  (SORT_RTN_TP_ENUM)SortRtnTp_None );
    }

    /* Compute executed quantity and weigthed mean quote */
    for(i=0, j=0; i<extOpNbr; i++)
    {

        opId = DBA_GetOpIdFromExtOp(extOpTab[i]);

        while (j<extExecutionNbr &&
               GET_ID(extExecutionTab[j], A_ExtExecution_ExtOrderId) < opId)
            j++;

        if (j<extExecutionNbr && GET_ID(extExecutionTab[j], A_ExtExecution_ExtOrderId) == opId)
        {
            qty= 0;
            weightMeanQuote = 0;

            while (j<extExecutionNbr &&
                   GET_ID(extExecutionTab[j], A_ExtExecution_ExtOrderId) == opId)
            {
                qty   += GET_NUMBER(extExecutionTab[j], A_ExtExecution_Quantity);
                weightMeanQuote += GET_NUMBER(extExecutionTab[j], A_ExtExecution_Quantity) *
                         GET_PRICE(extExecutionTab[j], A_ExtExecution_Quote);
                j++;
            }

            if(qty != 0)
            {
                weightMeanQuote /= qty;
            }
            else
            {
                weightMeanQuote = 0.0; 
            }

            SET_NUMBER(extOpTab[i], ExtOp_ExecQty, qty);
            SET_PRICE(extOpTab[i], ExtOp_WeightMeanQuote, weightMeanQuote);
        }
    }
	return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadExtExecutions()
**
**  Description          : Load all extended executions
**                         (execution and global execution fee)
**                         for all orders (ExtOp) stored in hierarchy
**
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         connectNo     pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF5760 - DDV - 020604
**  Modif.		         :
**
*************************************************************************/
RET_CODE DBA_LoadExtExecutions(DBA_HIER_HEAD_STP hierHead,
                               DBA_DYNFLD_STP    domainPtr,
                               int               *connectNo)
{
  	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
    int             extOpNbr = 0, extExecutionNbr=0, i;
	DBA_DYNFLD_STP  *extExecutionTab = NULLDYNSTPTR;
    char            *buffer=NULL;
    RET_CODE        ret=RET_SUCCEED;
    ID_T            opId;
	DbiSqlExecByBlock sqlExec(100);		/* PMSTA-20159 - TEB - 151110 */

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

    /* REF7560 - DDV - 020605 - Fill temporary table #vector_id with id of all orders in hierarchy */
    DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, NULLFCT, FIN_CmpExtOpByOpId,
                          &extOpNbr, &extOpTab);

    if (extOpNbr == 0)
           return(RET_SUCCEED);

    if ((buffer = (char *)CALLOC(512, sizeof (char))) == NULL) 		/* PMSTA-20159 - TEB - 151110 */
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		FREE(extOpTab); /* 041223 - CHU - Purify */
        return(RET_MEM_ERR_ALLOC);
    }

    /* create temp table #vector_id */
    if ((ret = DBA_CreateTempTables(connectNo, TCT_VECTOR_ID)) != RET_SUCCEED)
    {
        FREE(buffer);
		FREE(extOpTab); /* 041223 - CHU - Purify */
        return(ret);
    }

    for (i=0; i < extOpNbr; i++)
    {
        if((opId = DBA_GetOpIdFromExtOp(extOpTab[i])) > (ID_T) 0)
        { /* PMSTA-20159 - TEB - 150624 */
            sprintf(buffer, "insert into #vector_id (id,entity_dict_id) values(%" szFormatId", null)\n", opId); /* DLA - PMSTA08801 - 100209 */  /* PMSTA-25656 - TEB - 161215 */

			sqlExec.addSql(buffer);		/* PMSTA-20159 - TEB - 151110 */
        }
    }

	FREE(buffer);

    /* PMSTA-20159 - TEB - 151110 */
	if ((ret = sqlExec.execSqlExecByBloc((*connectNo))) != RET_SUCCEED)
    {
        if (DBA_CreateTempTables(connectNo, TCT_VECTOR_ID) != RET_SUCCEED)
   			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,  "DBA_CreateTempTables failed");

		FREE(extOpTab); /* 041223 - CHU - Purify */
        return(ret);
    }

    if (DBA_Select2(ExtExecutionEnt, UNUSED, NullDynSt, NULLDYNST,
                    A_ExtExecution, &extExecutionTab,
                    DBA_SET_CONN|DBA_NO_CLOSE, UNUSED,
                    &extExecutionNbr, connectNo, UNUSED) != RET_SUCCEED)
    {
        if (DBA_CreateTempTables(
                connectNo, TCT_VECTOR_ID) != RET_SUCCEED)
   			MSG_LogMesg(
                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_CreateTempTables failed");
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2 , FILEINFO, "extended execution");
		FREE(extOpTab); /* 041223 - CHU - Purify */
		return(RET_DBA_ERR_NODATA);
    }

    if ((ret = DBA_CreateTempTables(
            connectNo, TCT_VECTOR_ID)) != RET_SUCCEED)
    {
   		MSG_LogMesg(
            RET_GEN_ERR_PERSONAL, 1, FILEINFO,
				"DBA_CreateTempTables failed");
		FREE(extOpTab); /* 041223 - CHU - Purify */
        return ret;
    }

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	DATE_START_TIMER(4, TIMER_MASK_SQLC);

	/* REF9764 - CHU - 040113 : Replaced existing code with this function */
	/* Compute executed quantity and weigthed mean quote */
	DBA_ExtExecCalcQtyAndWeightMeanQuote(extOpTab, extOpNbr, extExecutionTab, extExecutionNbr);

    /* insert all extended execution in hierarchy */
 	DBA_AddHierRecordList(hierHead, extExecutionTab, extExecutionNbr, A_ExtExecution, FALSE);
    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

	FREE(extOpTab); /* 041223 - CHU - Purify */
    FREE(extExecutionTab);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpExtOpById()
**
**  Description :   Extended operation are sorted by ExtOp_DbId/ExtOp_OpId
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtOp
**                  ptr2   pointer on dynamic structure type ExtOp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7560 - DDV - 020814
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_CmpExtOpByOpId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(DBA_GetOpIdFromExtOp(*ptr1) , DBA_GetOpIdFromExtOp(*ptr2))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_CmpExecByOrderId()
**
**  Description :   Extended operation are sorted by A_ExtExecution_ExtOrderId
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtOp
**                  ptr2   pointer on dynamic structure type ExtOp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7560 - DDV - 020814
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_CmpExecByOrderId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_ExtExecution_ExtOrderId) , GET_ID((*ptr2), A_ExtExecution_ExtOrderId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**  Function             : DBA_LoadOrders()
**
**  Description          : Load all operations from table ext_order
**                         and store them into Hierarchy (ExtOp).
**
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         extOpNbr      return the total number of Extop in hierachy
**                         connectNo     pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF5760 - DDV - 020604
**
**  Modif.		         : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
RET_CODE DBA_LoadOrders(DBA_HIER_HEAD_STP *hierHeadPtr,
                        DBA_DYNFLD_STP domainPtr,
                        FLAG_T         filterFlg,
                        DbiConnection& dbiConn)
{
    const DBA_DYNST_ENUM *outputStLst[] =  {&ExtOp,  /* REF8844 - LJE - 030416 */
                                            &A_Ptf,
                                            &A_Instr,
	                                        &A_ExtExecution};
    int            outputBlkNb = 4; /* PMSTA60189 - 26092024 - HLA - Performance improvement for pending orders */
    DBA_DYNFLD_STP *data[4]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR }; /* REF4026 - SSO - 991008 */
    int             rows[4] = {0,0,0,0}; 		/* REF3947 - SSO - 990902 */
    RET_CODE        ret=RET_SUCCEED;

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

    if (DBA_MultiSelect2(ExtOrder, UNUSED, NullDynSt, NULLDYNST,
                         outputStLst, data,
                         DBA_SET_CONN | DBA_NO_CLOSE,
						 UNUSED, rows, (int*)&dbiConn.getId(), UNUSED) != RET_SUCCEED)
    {
        /* REF3668 - SSO - 990903 : if server, see if the client conn. is dead? */
        if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
        {
            DBA_LoadPosDropTempTables(dbiConn,  (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
            /*PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
            return(RET_DBA_ERR_DISCONNECTED);
        }

		/**** BEGIN DVP178+ ****/
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(ExtOrder, UNUSED, NullDynSt, NULLDYNST,
                         outputStLst, data,
                         DBA_SET_CONN | DBA_NO_CLOSE,
						 UNUSED, rows, (int*)&dbiConn.getId(), UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
			/*PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/
			return(ret);
		}
		/**** END   DVP178+ ****/
	}

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	DATE_START_TIMER(4, TIMER_MASK_SQLC);

    /* --------------------------------------------------------- */
	/* Create (if needed) a hierarchy and distribute loaded data */
	/* --------------------------------------------------------- */
	if ((ret = DBA_LoadPosHierCreate(A_Domain, domainPtr, hierHeadPtr,
				   	                 outputBlkNb,
					                 data, rows, outputStLst,
                                     TRUE,
                                     FALSE      /* PMSTA-28086 - CHU - 170919 */
                                     )) != RET_SUCCEED)
		return(ret);

	if (*hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
	{
		ret = DBA_SetHierOptiPtr(*hierHeadPtr);
		if (ret != RET_SUCCEED)
			return(ret);
	}

    /* ------------------------------------------------------------------ */
	/* Set and make links used by function and update some position infos */
	/* ------------------------------------------------------------------ */
	if ((ret = DBA_LoadPosHierLnkAndUpd((*hierHeadPtr), domainPtr, FALSE)) != RET_SUCCEED) /* REF7264 - DDV - 020325 - Compil C++ */
		return(ret);

    /* Call first phase to filtre extOp (if needed) */
    if (filterFlg == TRUE)
		if ((ret = FIN_AnalysisOpSearchPhaseOrder(domainPtr, (*hierHeadPtr), (int*)&dbiConn.getId())) != RET_SUCCEED)
		    return(ret);

    DBA_FreeHierEltRecord((*hierHeadPtr), A_ExtExecution); /* PMSTA60189 - 26092024 - HLA - Performance improvement for pending orders */
    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadOperByBatch()
**
**  Description          : Load a batch for operation search.
**                         Create ExtOp and filter it if filterFlg id TRUE.
**                         Store resulting ExtOp into Hierarchy.
**
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         filterFlg     Extop must be filtered using Extop Script in domain
**                         nbOp          return the number of Op loaded
**                         extOpNbr      return the total number of Extop in hierachy
**                         connectNo     pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF2467 - DDV - 000120
**
**  Modif.		         : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
RET_CODE DBA_LoadOperByBatch(DBA_HIER_HEAD_STP *hierHeadPtr,
                             DBA_DYNFLD_STP domainPtr,
                             FLAG_T         filterFlg,
                             int            *remainOpNbr,
                             int            *extOpNbr,
                             DbiConnection& dbiConn)
{
    const DBA_DYNST_ENUM *outputStLst[] =  {&A_Op,  /* REF8844 - LJE - 030416 */
                                            &ExtPos,
                                            &ExtPos,
                                            &A_Ptf,
                                            &A_Instr,
                                            &Io_Id};
    int            outputBlkNb = 6;
    DBA_DYNFLD_STP *data[6]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR,
                             NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR }; /* REF4026 - SSO - 991008 */
    int             rows[6] = {0,0,0,0,0,0}; 		/* REF3947 - SSO - 990902 */
    RET_CODE        ret=RET_SUCCEED;
    FLAG_T          firstBlockFlg = FALSE;

    if(SYS_IsStateShutdownRequested())
    {   /* PMSTA-54362 -JBC - 231130 */
        return RET_SYS_ERR_SIGINT;
    }

    if (*hierHeadPtr == NULL)
        firstBlockFlg = TRUE;

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

    if (DBA_MultiSelect2(FinAnalysis,
                         static_cast<int>(GET_DICT(domainPtr, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                         A_Domain, domainPtr,
                         outputStLst, data,
                         DBA_SET_CONN | DBA_NO_CLOSE,
						 UNUSED, rows, (int*)&dbiConn.getId(), UNUSED) != RET_SUCCEED)
    {
        /* REF3668 - SSO - 990903 : if server, see if the client conn. is dead? */
        if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
            /*PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
            return(RET_DBA_ERR_DISCONNECTED);
        }

		/**** BEGIN DVP178+ ****/
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(FinAnalysis,
                                    static_cast<int>(GET_DICT(domainPtr, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                                    A_Domain, domainPtr,
                                    outputStLst, data,
		                	    	DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, rows,
									(int*)&dbiConn.getId(), UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn,
					                  (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
			/*PMSTA-13649 - TGU - 120221 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/
			return(ret);
		}
		/**** END   DVP178+ ****/
	}

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	DATE_START_TIMER(4, TIMER_MASK_SQLC);

    if (rows[5] == 1)
        (*remainOpNbr) = (int)GET_ID(data[5][0], Io_Id_Id); /* DLA - REF9089 - 030508 */
    else
        (*remainOpNbr) = 0;

    /* REF11589 - DDV - 060622 */
	DBA_FreeDynStTab(data[5],rows[5], Io_Id);
    data[5]=NULL;
    rows[5]=0;

    /* All intrument allready in Hierarchy must be removed from returned block */
    if ((*hierHeadPtr) != (DBA_HIER_HEAD_STP) NULL)
	    if ((ret = DBA_VerifInstrInHier(*hierHeadPtr,
		    					        &(data[4]), &(rows[4]), /* A_Instr */
			    				        NULL, NULL,             /* A_InstrChrono */
				    			        NULL, NULL,             /* A_InstrPrice */
					    		        NULL, NULL              /* A_InterCond */
						    	        )) != RET_SUCCEED)
			return(ret);

    /* All portfolio allready in Hierarchy must be removed from returned block */
    if ((*hierHeadPtr) != (DBA_HIER_HEAD_STP) NULL)
        if ((ret = DBA_VerifPtfInHier((*hierHeadPtr),  /* REF7264 - LJE - 020131 */
                                      &(data[3]), &(rows[3]), /* A_Ptf */
                                      NULL, NULL              /* A_PtfPosSet */
                                      )) != RET_SUCCEED)
        return(ret);

    /* --------------------------------------------------------- */
	/* Create (if needed) a hierarchy and distribute loaded data */
	/* --------------------------------------------------------- */
	if ((ret = DBA_LoadPosHierCreate(A_Domain, domainPtr, hierHeadPtr,
				   	                 outputBlkNb,
					                 data, rows, outputStLst,
                                     TRUE,
                                     FALSE      /* PMSTA-28086 - CHU - 170919 */
                                     )) != RET_SUCCEED)
		return(ret);

	if (firstBlockFlg == TRUE && *hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
	{
		ret = DBA_SetHierOptiPtr(*hierHeadPtr);
		if (ret != RET_SUCCEED)
			return(ret);
	}

    /* ------------------------------------------------------------------ */
	/* Set and make links used by function and update some position infos */
	/* ------------------------------------------------------------------ */
	if ((ret = DBA_LoadPosHierLnkAndUpd((*hierHeadPtr), domainPtr, FALSE)) != RET_SUCCEED) /* REF7264 - DDV - 020325 - Compil C++ */
		return(ret);

    if ((ret = OPE_SetExtPosBookVal((*hierHeadPtr), 0, NULL)) != RET_SUCCEED)
   		return(ret);

    /* Call first phase (Create ExtOp and filtre it) */
    if ((ret = FIN_AnalysisOpSearchPhase1(domainPtr, (*hierHeadPtr), filterFlg, *remainOpNbr)) != RET_SUCCEED)
		return(ret);

    /* Free same hierarchy blocks (Op/ExtPos) */
    DBA_FreeHierEltRecord((*hierHeadPtr), A_Op); /* REF7264 - LJE - 020131 */
    DBA_FreeHierEltRecord((*hierHeadPtr), ExtPos); /* REF7264 - LJE - 020131 */

    /* Check number of ExtOp allready created */
    DBA_HierGetRecNbr((*hierHeadPtr), ExtOp, NULLFCT, extOpNbr, FALSE /* TRUE */); /* REF10530 - TEB - 060815 */ /* REF7264 - LJE - 020131 */

    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_LoadExtOp_InitFilteredDim()
*
*   Description          :
*
*
*   Arguments   :          domainPtr         : a pointer on a domain
*                          stratHierHead     : a pointer on a strategy header
*                          getArg            : a pointer on a get arguments
*
*   Return               : RET_SUCCEED or error ocde
*
*   Creation date        : PMSTA-30891 - RAK - 180503
*************************************************************************/
RET_CODE DBA_LoadExtOp_InitFilteredDim(DBA_DYNFLD_STP	   domainPtr,
									   DbiConnection&	   dbiConn,
									   DBA_HIER_HEAD_STP   stratHierHead,
									   DBA_DYNFLD_STP      getDomainPtr,
									   OBJECT_ENUM         dimObject)
{
	DBA_DYNFLD_STP	admArg = NULLDYNST, sList = NULLDYNST;
	LISTNAT_ENUM	nature;
	DICT_T			listEntDictId=0, entDictId;
	OBJECT_ENUM		listObject;
	RET_CODE		ret = RET_SUCCEED;

	/* No position loaded in #dom_position the change mode fir SERV_ListMgm function */
	SERV_LISTMGMFCT_ENUM listMgmFct = ListMgmFct_LoadEvtGenInstr;


	/* create table */
	ret = DBA_CreateTempTables(dbiConn, DOM_POSITION_INSTR_PORT);

	if (ret != RET_SUCCEED)
		return ret;

	/* init */
	/* PORTFOLIO DIMENSION */
	if (dimObject == List)
	{
		admArg = ALLOC_DYNST(Adm_Arg);
		sList = ALLOC_DYNST(S_List);

		/* Verify memory allocation */
		if (admArg == NULL || sList == NULL)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(RET_GEN_ERR_INVARG);
		}

		COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, domainPtr, A_Domain, A_Domain_PtfObjId);

		/* Get the list record */
		if ((ret = DBA_Get2(List, UNUSED, Adm_Arg, admArg, S_List, &sList, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn, UNUSED)) != RET_SUCCEED)
		{
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(ret);
		}

		listEntDictId = GET_DICT(sList, S_List_EntityDictId);

		/* If the portfolio list is a constraint list, search list or hierarchic list */
		if ((nature = (LISTNAT_ENUM) GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
			 nature == ListNat_Search || nature == ListNat_Hierarch)
		{
			if ((listEntDictId = GET_DICT(sList, S_List_EntityDictId)) == 0)
				listObject = NullEntity;
			else
				DBA_GetObjectEnum(listEntDictId, &listObject);

			/* Insert portfolioes Ids from the Constraint List into #dom_port */
			if ((ret = SERV_ListMgm(listMgmFct,
                                    listEntDictId,
                                    GET_ID(sList, S_List_Id),
				                    NULL,
                                    dbiConn,
                                    nullptr)) != RET_SUCCEED)
			{
				/* REF3751 - SSO - 990623 more ret code tests */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
				FREE_DYNST(admArg, Adm_Arg);
				FREE_DYNST(sList, S_List);
				return(ret);
			}

			/* REF4306 - DDV - 000229 - Process hierarchy_f and PPS, only if entity of list is portfolio */
			if (listObject == Ptf)
			{
				/* Call procedure to expand #dom_port with hierarchy child portfolios */
				if (domainPtr != NULLDYNST &&
					GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
				{
					if ((ret = DBA_Notif2(FinAnalysis, DBA_ROLE_HIERPTF,
						A_Domain, domainPtr,
						DBA_SET_CONN | DBA_NO_CLOSE,
						dbiConn, UNUSED)) != RET_SUCCEED)
					{
						/* REF3749 - SSO - 990706 */
						DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
						FREE_DYNST(admArg, Adm_Arg);
						FREE_DYNST(sList, S_List);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
						return(ret);
					}
				}
			}
		}
		FREE_DYNST(admArg, Adm_Arg);
		FREE_DYNST(sList, S_List);
	}
	else if (dimObject == QuickSearch) /* REF0014 - DDV - 000330 - Quick search in Domain */
	{
		DBA_GetDictId(Ptf, &entDictId);

		/* Insert portfolioes Ids from the Quick Search List into #dom_port */
		if ((ret = SERV_ListMgm(listMgmFct,
								entDictId, 0,
								GET_STRING(domainPtr, A_Domain_PtfListDef),
								dbiConn,
                                nullptr)) != RET_SUCCEED)
		{
			/* REF3751 - SSO - 990623 more ret code tests */
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			return(ret);
		}

		/* Call procedure to expand #dom_port with hierarchy child portfolios */
		/* Only if load_hierarchy_f from domina is TRUE - XDI */
		if (domainPtr != NULLDYNST &&
			GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
		{
			if ((ret = DBA_Notif2(FinAnalysis,
				DBA_ROLE_HIERPTF,
				A_Domain,       /* NullDynSt, *//* SKE 010223 */
				domainPtr,      /* NULLDYNST, *//* SKE 010223 */
				DBA_SET_CONN | DBA_NO_CLOSE,
				dbiConn,
				UNUSED)) != RET_SUCCEED)
			{
				/* REF3749 - SSO - 990706 */
				DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
				return(ret);
			}
		}
	}

	/* INSTRUMENT DIMENSION */
	/* Handle the Domain INSTRUMENT DIMENSION */
	if (GET_DICT(domainPtr, A_Domain_DimInstrDictId) == 0)
	{
		dimObject = NullEntity;
	}
	else if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &dimObject) != TRUE)
	{
		DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
		return(RET_GEN_ERR_INVARG);
	}

	SET_FLAG(domainPtr, A_Domain_NonEnumInstrFlg, 0);

	/* Switch INSTRUMENT DIMENSION */
	switch (GET_OBJECT_CST(dimObject)) /* REF8844 - LJE - 030416 */
	{
	case ListCst:  /* INSTRUMENT DIMENSION is a list of instruments */

		admArg = ALLOC_DYNST(Adm_Arg);
		sList = ALLOC_DYNST(S_List);

		/* Verify memory allocation */
		if (admArg == NULL || sList == NULL)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(RET_GEN_ERR_INVARG);
		}

		COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, domainPtr, A_Domain, A_Domain_InstrObjId);
		if ((ret = DBA_Get2(List, UNUSED, Adm_Arg, admArg, S_List, &sList, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn, UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			FREE_DYNST(admArg, Adm_Arg);
			FREE_DYNST(sList, S_List);
			return(ret);
		}

		/* If the list is constraint, search or hierarchic */
		if ((nature = (LISTNAT_ENUM)GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
			 nature == ListNat_Search || nature == ListNat_Hierarch)
		{
				DICT_T      instrEntDictId;
				DBA_GetDictId(Instr, &instrEntDictId);

				/* Insert instrument Ids from the Constraint List into #dom_instr */
				if ((ret = SERV_ListMgm(listMgmFct,
                                        instrEntDictId,
                                        GET_ID(sList, S_List_Id),
					                    NULL,
                                        dbiConn,
                                        nullptr)) != RET_SUCCEED)
				{
					/* REF3751 - SSO - 990623 more ret code tests */
					DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
					FREE_DYNST(admArg, Adm_Arg);
					FREE_DYNST(sList, S_List);
					return(ret);
				}

				SET_FLAG(domainPtr, A_Domain_NonEnumInstrFlg, TRUE);
		}

		FREE_DYNST(admArg, Adm_Arg);
		FREE_DYNST(sList, S_List);
		break;

	case QuickSearchCst: /* REF0014 - DDV - 000330 - Quick search in Domain */
		DBA_GetDictId(Instr, &entDictId);

		/* Insert portfolioes Ids from the Quick Search List into #dom_port */
		if ((ret = SERV_ListMgm(listMgmFct,
                                entDictId,
                                0,
			                    GET_STRING(domainPtr, A_Domain_InstrListDef),
								dbiConn,
                                nullptr)) != RET_SUCCEED)
		{
			/* REF3751 - SSO - 990623 more ret code tests */
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			return(ret);
		}
		break;
	}

	/* Send an Init request to fill dom_position and dom_instr table */
	/*temporary if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)	*/
	if ((ret = DBA_Notif2(EOp, DBA_ROLE_FCT_RESULT,
						  A_Domain, domainPtr, DBA_SET_CONN | DBA_NO_CLOSE,
						  dbiConn, UNUSED)) != RET_SUCCEED)
	{
		DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif() failed");
		return(ret);
	}

	/* Call procedure to expand #dom_port with hierarchy child portfolios */
	/* Only if load_hierarchy_f from domina is TRUE - XDI */
	if (domainPtr != NULLDYNST && GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
	{
		if ((ret = DBA_Notif2(FinAnalysis, DBA_ROLE_HIERPTF,
			                  A_Domain, domainPtr,
			                  DBA_SET_CONN | DBA_NO_CLOSE,
			                  dbiConn, UNUSED)) != RET_SUCCEED)
		{
			/* REF3749 - SSO - 990706 */
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_Notif2() failed");
			return(ret);
		}
	}

	/* and perform a full select with filtered table in calling function  */
	SET_FLAG(getDomainPtr, S_Domain_InitDimFlg, TRUE);	/* Use this flag for @init_dim_f" */
	return(RET_SUCCEED);
}


/************************************************************************
**  Function             :  DBA_ValoEliminate()
**
**  Description          :  Eliminates useless positions for valuation.
**
**  Arguments            :  hierHeadPtr	pointer on hierarchy header pointer
**			                hierDefNbr   hierarchy definition number
**			                outputMatch  pointer on hierarchy element array
**                          outputBlkNb  number of hierarchy element
**                          data		pointer on record array to insert
**                          rows         record number on array
**                          outputStLst  record dynamic structure type
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  PMSTA02901 - EFE - 070731 :
**                                     -> based on DBA_ReturnEliminate
*************************************************************************/
STATIC RET_CODE DBA_ValoEliminate(    DBA_DYNFLD_STP		 domainPtr,
									  DBA_DYNFLD_STP       **data,
				                      int                  *rows,
				                      const DBA_DYNST_ENUM **outputStLst,
                                      int                  blockNbr,
                                      DBA_HIER_HEAD_STP    hierHead)
{
    RET_CODE		ret=RET_SUCCEED;
    int				i=0, j=0;

	/* REF9413 - RAK - 030828 - si vraiment on l'a pas re�u ... on fait comme avant */
	if (domainPtr == NULL)
	{
		domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
	}

    for (i=0; i<blockNbr; i++)
    {
        if (*(outputStLst[i]) == ExtPos && rows[i] > 0)
        {
            for (j=0; j<rows[i]; j++)
            {
                if ( (POSNAT_ENUM) GET_ENUM(data[i][j], ExtPos_PosNatEn) == PosNat_AdjExchPreCostPrice ||
					 (POSNAT_ENUM) GET_ENUM(data[i][j], ExtPos_PosNatEn) == PosNat_AdjExchPreMktPrice  ||
					 (POSNAT_ENUM) GET_ENUM(data[i][j], ExtPos_PosNatEn) == PosNat_AdjExchCostPrice    ||
					 (POSNAT_ENUM) GET_ENUM(data[i][j], ExtPos_PosNatEn) == PosNat_AdjExchMktPrice
                   )
                {
                    FREE_DYNST(data[i][j], *(outputStLst[i]));
                }
            }
        }
    }

    return(ret);
}






/************************************************************************
**  Function             : DBA_UpdExtPosNatPerfo()
**
**  Description          : Update loaded extended position
**                         nature (stock or flow) and extended position date.
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         fctLnkPtr     links state structure ( BUG515 - XDI - 970930 )
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF5295 - DDV - 010221
**  Modif.               :
**
*************************************************************************/
STATIC RET_CODE DBA_UpdExtPosNatPerfo(DBA_HIER_HEAD_STP hierHead,
                                      DBA_DYNFLD_STP    extrPos,
                                      DBA_DYNFLD_STP    domainPtr,
                                      DATETIME_T        fromDate,
                                      DATETIME_T        tillDate,
                                      DBA_FCTLNK_STP    fctLnkStp)
{
    DBA_DYNFLD_STP    newExtPos=(DBA_DYNFLD_STP)NULL;
    RET_CODE          ret=RET_SUCCEED;
    DICT_FCT_ENUM     fct = (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId);

    if ((fct == DictFct_Perfo || fct == DictFct_CopyOperation) ||
        ((fct == DictFct_OpHist || fct == DictFct_OpList ) &&
		 GET_FLAG(domainPtr, A_Domain_LoadPosFlg) == TRUE))		/* REF417 */
	{
		if (DATETIME_CMP(GET_DATETIME(extrPos, ExtPos_BegDate),
		                 fromDate) <= 0)
		{
			if (DATETIME_CMP(GET_DATETIME(extrPos, ExtPos_EndDate), tillDate) > 0 ||
			    IS_NULLFLD(extrPos, ExtPos_EndDate) == TRUE)
			{
			   /* Create a new position (stock) */
			   if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULL)
			   {
				    FREE(extrPos);
				    MSG_RETURN(RET_MEM_ERR_ALLOC);
			   }
			   COPY_DYNST(newExtPos, extrPos, ExtPos);
			   SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_FinalStock);
			   SET_DATETIME(newExtPos, ExtPos_ExtPosDate, tillDate);

			   /* REF2723 */
               if (fct == DictFct_Perfo || fct == DictFct_OpHist) /* REF7120 - DDV - 020104 */
			   { SET_ENUM(newExtPos, ExtPos_PrimaryEn, (ENUM_T) PosPrimary_Primary); }

			   /* HierAddRec_NoLnk : Don't try to set links, they */
			   /* are set after hierarchy sort by DBA_MakeLinks() */

			   SET_NULL_ID(newExtPos, ExtPos_Id);
			   if ((ret = DBA_AddHierRecord(hierHead,
					                        newExtPos, ExtPos, FALSE,
					                        HierAddRec_NoLnk)) != RET_SUCCEED)
			   {
				    FREE_DYNST(newExtPos, ExtPos);
				    FREE(extrPos);
				    return(ret);
			   }

               /* BUG515 - XDI - 970930 */
	           if ((ret = DBA_FctLnkFirst(hierHead, fctLnkStp, FALSE, /* REF7264 - DDV - 020325 - Compil C++ */
                                              extrPos, newExtPos)) != RET_SUCCEED)
               {
                   FREE(extrPos);
                   return(ret);
               }
			}

			SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_InitStock);
			/* REF2723 */
			   if (fct == DictFct_Perfo || fct == DictFct_OpHist) /* REF7120 - DDV - 020104 */
			{ SET_ENUM(extrPos, ExtPos_PrimaryEn, (ENUM_T) PosPrimary_Primary); }
			SET_DATETIME(extrPos, ExtPos_ExtPosDate, fromDate);
		}

        else
		{
			/* Special case, dupliquate position (1 stock,1 flow) */
			if (GET_ENUM(extrPos, ExtPos_PrimaryEn) != PosPrimary_Derived)
			{
			   /* The current position is a flow */
			   SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_Flow);
			   SET_DATETIME(extrPos, ExtPos_ExtPosDate,
			       GET_DATETIME(extrPos, ExtPos_BegDate));

			   /* PMSTA-53235 - SENTHIL - 15072023 */
			   if (fct == DictFct_Perfo && GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL)
			   {
				   SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_InitStock);
				   SET_DATETIME(extrPos, ExtPos_ExtPosDate, tillDate);
			   }
               /* WEALTH-5194 - Deepthi -20240718 */
               if (fct == DictFct_OpHist && GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL)
               {
                    if ((DATETIME_CMP(GET_DATETIME(extrPos, ExtPos_BegDate), fromDate) <= 0) &&
                            ((IS_NULLFLD(extrPos, ExtPos_EndDate) == TRUE) ||
                            (DATETIME_CMP(fromDate, GET_DATETIME(extrPos, ExtPos_EndDate)) < 0)))
                                {
                                    SET_DATETIME(extrPos, ExtPos_ExtPosDate, fromDate); /* WEALTH-11492 - Deepthi - 20240708 */
                                    SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_InitStock);
                                    SET_ENUM(extrPos, ExtPos_PrimaryEn, PosPrimary_Primary);
                                }
               }

			   if ((GET_ENUM(domainPtr, A_Domain_PLMethodEn) != PLMethod_ReprocessPL || fct != DictFct_Perfo) && (IS_NULLFLD(extrPos, ExtPos_EndDate) == TRUE ||
			       DATETIME_CMP(GET_DATETIME(extrPos, ExtPos_EndDate), tillDate) > 0))
			   {
			   	    /* Create a new position (stock) */
			            if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULL)
				    {
					    FREE(extrPos);
					    MSG_RETURN(RET_MEM_ERR_ALLOC);
				    }

                        COPY_DYNST(newExtPos, extrPos, ExtPos);
			        SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_FinalStock);

                    /* REF2723 */
    			   if (fct == DictFct_Perfo || fct == DictFct_OpHist) /* REF7120 - DDV - 020104 */
				    { SET_ENUM(newExtPos, ExtPos_PrimaryEn,
						           (ENUM_T) PosPrimary_Primary); }

			        SET_DATETIME(newExtPos, ExtPos_ExtPosDate,  tillDate);

			   	    /* HierAddRec_NoLnk : Don't try to set */
				    /* links, they are set after hierarchy */
				    /* sort by DBA_MakeLinks()             */

			   	    SET_NULL_ID(newExtPos, ExtPos_Id);
			   	    if ((ret = DBA_AddHierRecord(hierHead,
					                             newExtPos, ExtPos, FALSE,
					                             HierAddRec_NoLnk)) !=RET_SUCCEED)
				    {
					    FREE_DYNST(newExtPos, ExtPos);
					    FREE(extrPos);
					    return(ret);
				    }

                    /* BUG515 - XDI - 970930 */
	                if ((ret = DBA_FctLnkFirst(hierHead, fctLnkStp, FALSE, /* REF7264 - DDV - 020325 - Compil C++ */
                                               extrPos, newExtPos)) != RET_SUCCEED)
			   	    {
					    FREE(extrPos);
					    return(ret);
			   	    }
			   }
			}
			else
			{
		       SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_FinalStock);
			   SET_DATETIME(extrPos, ExtPos_ExtPosDate, tillDate);
			   /* REF2723 */
			   if (fct == DictFct_Perfo || fct == DictFct_OpHist) /* REF7120 - DDV - 020104 */
			   { SET_ENUM(extrPos, ExtPos_PrimaryEn, (ENUM_T) PosPrimary_Primary); }
			}
		}
	}
	else
	{
		SET_ENUM(extrPos, ExtPos_NatEn, ExtPosNat_Flow);
	}

    return(RET_SUCCEED);

}

/************************************************************************
**  Function             : DBA_CheckExtPosInstr()
**
**  Description          : Check that all ExtPos have a link on instrument.
**                         If no link, load intrument from database and make link
**
**  Arguments            : hierHead	hierarchy header pointer
**
**  Return               : RET_SUCCEED or error code
**
**  Creation 		     : REF7560 - DDV - 020620
**
*************************************************************************/
STATIC RET_CODE DBA_CheckExtPosInstr(DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP      *extPosTab = NULLDYNSTPTR,
			            instrPtr = NULLDYNST;
	int		            extPosNbr, i;
    ID_T                lastInstrId = UNUSED;
    FLAG_T              allocFlg;
	RET_CODE            ret;


	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos, FALSE,
                                     DBA_FilterPosNoInstrExt, DBA_CmpExtPosInstr,
                                     &extPosNbr, &extPosTab)) != RET_SUCCEED)
	{
	    return(ret);
	}

	for (i=0; i<extPosNbr; i++)
	{
        /* REF8028 - DDV - 021007 */
        if (GET_ID(extPosTab[i], ExtPos_InstrId) != 0)
        {
            if (lastInstrId != GET_ID(extPosTab[i], ExtPos_InstrId))
            {
                /* load instrument from database and insert it into hierarchy */
                lastInstrId = GET_ID(extPosTab[i], ExtPos_InstrId);
                DBA_GetInstrById(lastInstrId, TRUE, &allocFlg, &instrPtr,
                                 hierHead, UNUSED, UNUSED);
            }

            DBA_ForceLink(hierHead, ExtPos,
		                  ExtPos_A_Instr_Ext, extPosTab[i], instrPtr);
        }
    }

    FREE(extPosTab); /* PMSTA10872 - DDV - 110124 - Purify */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_FilterPosNoInstrExt()
**
**  Description :   Filter pos without instrument entension
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**  Created		    REF7560 - DDV - 020620
**
*************************************************************************/
STATIC int DBA_FilterPosNoInstrExt(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) == NULL ||
		*(GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext)) == NULLDYNST)
	{
	    return(TRUE);
	}

    return(FALSE);
}
/************************************************************************
**
**  Function    :   DBA_CmpExtPosInstr()
**
**  Description :   ExtPos are sorted by instrument
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DBA_CmpExtPosInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	if (*ptr1 == NULL && *ptr2 == NULL) /* BUG329 - XDI - 970409 */
		return(0);
	else if (*ptr1 == NULL)
		return(1);
	else if (*ptr2 == NULL)
		return(-1);

	return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId) , GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   DBA_InitExtOpForUnspecQty()
**
**  Description :   Initializes ExtOp for OrderAllocation && QtyAllocNat_UnspecifiedQty
**
**  Arguments   :   argHierHeadPtr	hierarchy pointer
**					domainPtr		domain pointer
**                  extOpPtr        current extOp to init
**                  parExtOpPtr     parent extOp
**                  matchSrcCdFlg   Appl param for ExtOp code matching
**
**  Return      :   RET_SUCCEED or error
**
**  Created		    REF8376 - CHU - 040603
**
**  Modifs      :   REF10408 - CHU - 040705 Added call to OPE_BlockOrderHeritageWithFctScript()
**
*************************************************************************/
RET_CODE DBA_InitExtOpForUnspecQty(DBA_HIER_HEAD_STP *hierHeadPtr,
								   DBA_DYNFLD_STP	domainPtr,
								   DBA_DYNFLD_STP	*extOpPtr,
								   DBA_DYNFLD_STP	parExtOpPtr,
								   FLAG_T			matchSrcCdFlg)
{
	//DBA_HIER_HEAD_STP	*hierHeadPtr=(DBA_HIER_HEAD_STP *)argHierHeadPtr;
	ID_T				dimInstrDictId, domInstrId=-1;
	OBJECT_ENUM			objectEnum;
	CODE_T				opCode;
	FLAG_T				*scptFlagTab = NULL;
	int					childExtOpNbr = 0, i;
	DBA_DYNFLD_STP		*childExtOpTab = NULL;
	RET_CODE			ret;
	OPNAT_ENUM			opNatEn;

	/* If extop already exist for this portfolio, don't create another one */
	if (GET_EXTENSION_PTR(parExtOpPtr, ExtOp_ChildExtOp_Ext) != NULL)
	{
		childExtOpNbr = GET_EXTENSION_NBR(parExtOpPtr, ExtOp_ChildExtOp_Ext);
		childExtOpTab = GET_EXTENSION_PTR(parExtOpPtr, ExtOp_ChildExtOp_Ext);
		for (i=0 ; i<childExtOpNbr ; i++)
		{
			if (CMP_ID(GET_ID(childExtOpTab[i], ExtOp_PtfId),
				       GET_ID(domainPtr, A_Domain_PtfObjId)) == 0)
			{
				DBA_DYNFLD_STP ptfPtr;

				if (DBA_GetRecPtrFromHierById((*hierHeadPtr), GET_ID(domainPtr, A_Domain_PtfObjId), A_Ptf,
											  &ptfPtr) == RET_SUCCEED && ptfPtr != NULLDYNST)
				{
					MSG_LogSrvMesg(UNUSED, UNUSED, "Order Allocation (Unspecified Quantity): An order already exists for portfolio %1 (skipping)",
				                CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
				}
				return(RET_SUCCEED);
			}
		}
	}

	if (((*extOpPtr) = ALLOC_DYNST(ExtOp)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((scptFlagTab = (FLAG_T*) CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == (FLAG_T*)NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	memset(scptFlagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));

	/* REF11266 - CHU - 050623 : use parent operation Buy/Sell nature */
	if ((parExtOpPtr != NULL) && (IS_NULLFLD(parExtOpPtr, ExtOp_NatureEn) == FALSE))
	{
		opNatEn = (OPNAT_ENUM)GET_ENUM(parExtOpPtr, ExtOp_NatureEn);
	}
	else
	{
		if(GET_ENUM(domainPtr, A_Domain_OrderNatEn) == OpNat_Sell)
			opNatEn = OpNat_Sell;
		else
			opNatEn = OpNat_Buy;
	}

	/*  Add new child order with order allocation or create child order */
	if (parExtOpPtr != NULL)
	{
		/* REF10408 - CHU - 040705 */
		ret = OPE_BlockOrderHeritageWithFctScript(domainPtr, (*hierHeadPtr),
												  scptFlagTab,
												  0.0, opNatEn,
												  GET_ID(domainPtr, A_Domain_PtfObjId),
												  parExtOpPtr, (*extOpPtr), FALSE);
	}

	SET_ENUM((*extOpPtr), ExtOp_NatureEn, opNatEn);
	scptFlagTab[ExtOp_NatureEn] = TRUE;

	switch(opNatEn)
	{
	case OpNat_Sell :
			if (IS_NULLFLD(domainPtr, A_Domain_SellOrderRuleId) == FALSE)
			{
				SET_ID((*extOpPtr), ExtOp_RuleId, GET_ID(domainPtr, A_Domain_SellOrderRuleId));
				scptFlagTab[ExtOp_RuleId] = TRUE;
			}
			break;
	case OpNat_Buy  :
			if (IS_NULLFLD(domainPtr, A_Domain_BuyOrderRuleId) == FALSE)
			{
				SET_ID((*extOpPtr), ExtOp_RuleId, GET_ID(domainPtr, A_Domain_BuyOrderRuleId));
				scptFlagTab[ExtOp_RuleId] = TRUE;
			}
			break;
	}

	DBA_SetDfltEntityFld(EOp, ExtOp, (*extOpPtr));

	SET_NULL_CODE((*extOpPtr), ExtOp_Cd);
    /* scptFlagTab[ExtOp_Cd] = TRUE; */
    scptFlagTab[ExtOp_Cd] = DBA_GetOrderCodeInSessionSysParam(); /* PMSTA-25183 - CHU - 161108 */

	dimInstrDictId = GET_DICT(domainPtr, A_Domain_DimInstrDictId);
	if (DBA_GetObjectEnum(dimInstrDictId, &objectEnum) != TRUE)
	{
		MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
        return(RET_DBA_ERR_MD);
	}
	if ((objectEnum == Instr) && (IS_NULLFLD(domainPtr, A_Domain_InstrObjId)==FALSE))
	{
		domInstrId = GET_ID(domainPtr, A_Domain_InstrObjId);
	}

	if (domInstrId > 0)
	{
		SET_ID((*extOpPtr), ExtOp_InstrId, domInstrId);
		scptFlagTab[ExtOp_InstrId] = TRUE;
	}
	else
	{
		SET_ID((*extOpPtr), ExtOp_InstrId, GET_ID(parExtOpPtr, ExtOp_InstrId));
		scptFlagTab[ExtOp_InstrId] = TRUE;
	}

	SET_ID((*extOpPtr), ExtOp_PtfId, GET_ID(domainPtr, A_Domain_PtfObjId));
	scptFlagTab[ExtOp_PtfId] = TRUE;

    if (IS_NULLFLD(domainPtr, A_Domain_OrderStatusEn) == FALSE)
    {
	    SET_ENUM((*extOpPtr), ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
	    scptFlagTab[ExtOp_StatusEn] = TRUE;
    }

	SET_DATETIME((*extOpPtr), ExtOp_AcctDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
	scptFlagTab[ExtOp_AcctDate] = TRUE;

	SET_DATETIME((*extOpPtr), ExtOp_OpDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
	scptFlagTab[ExtOp_OpDate] = TRUE;

	SET_ENUM((*extOpPtr), ExtOp_ParOpNatEn, ParOpNat_ChildOrder);
	scptFlagTab[ExtOp_ParOpNatEn] = TRUE;

    SET_ENUM((*extOpPtr), ExtOp_CheckParentEn, (ENUM_T) CheckParent_Disable);
    scptFlagTab[ExtOp_CheckParentEn] = TRUE;

	SET_FLAG((*extOpPtr), ExtOp_ConfirmedFlg, TRUE);
	scptFlagTab[ExtOp_ConfirmedFlg] = TRUE;

	opCode[0]=END_OF_STRING;
	if(matchSrcCdFlg == TRUE && IS_NULLFLD(parExtOpPtr, ExtOp_SrcCd) == FALSE)
		strcpy(opCode, GET_CODE(parExtOpPtr, ExtOp_SrcCd));
	else if (IS_NULLFLD(parExtOpPtr, ExtOp_Cd) == FALSE)
				strcpy(opCode, GET_CODE(parExtOpPtr, ExtOp_Cd));
	SET_CODE((*extOpPtr), ExtOp_ParOpCd, opCode);
	scptFlagTab[ExtOp_ParOpCd] = TRUE;

    /* < PMSTA-24542 - CHU - 170306 */
    if (GET_DICT(domainPtr, A_Domain_FctDictId) == (ENUM_T)DictFct_OrderAllocation &&
        GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == (ENUM_T)DomSessionNat_OrderAllocation)
    {
        SET_ID((*extOpPtr), ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(parExtOpPtr));
    }
    else /* > PMSTA-24542 - CHU - 170306 */
    {
		SET_ID((*extOpPtr), ExtOp_ParentExtOpId, GET_ID(parExtOpPtr, ExtOp_Id));
    }
	scptFlagTab[ExtOp_ParentExtOpId] = TRUE;

	SET_NUMBER((*extOpPtr), ExtOp_Qty, 0.0);
	scptFlagTab[ExtOp_Qty] = TRUE;

	SET_ID((*extOpPtr), ExtOp_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));
	scptFlagTab[ExtOp_FctResultId] = TRUE;

    if (SCPT_ComputeScreenDVCreate( EOp,
                                    GET_DICT(domainPtr, A_Domain_InitialFctDictId),
                                    scptFlagTab,
                                    NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                    (*extOpPtr),
                                    NULL,
                                    domainPtr,
                                    FALSE,  /* partial because of some fiels are forced */
                                    TRUE,   /* GUI mode because of we want to use GUI dflt */
                                    -1,
                                    (int *)NULL,
                                    NULL,
                                    (*hierHeadPtr),
                                    0,
                                    NULL,
                                    NULL) != 0)
    {
        FREE_DYNST((*extOpPtr), ExtOp);
        ret = RET_GEN_ERR_INVARG;
	    MSG_SendMesg(ret, 1, FILEINFO, "FIN_ReconcExtOpCreate", "SCPT_ComputeScreenDV()");
        return(ret);
    }
	SET_ENUM((*extOpPtr), ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ComputeEffectChildQty()
**
**  Description :   Load child orders and compute parent effective child Qty
**
**  Arguments   :   argHierHeadPtr	hierarchy pointer
**					domainPtr		domain pointer
**                  extOpNbr        parent ExtOp number
**                  extOpTab        parent ExtOp array
**
**  Return      :   RET_SUCCEED or error
**
**  Created		    REF10295 + REF8376 - CHU - 040610
**
**  Modifs      :
**
*************************************************************************/
RET_CODE DBA_ComputeEffectChildQty(DBA_HIER_HEAD_STP *hierHeadPtr,
								   DBA_DYNFLD_STP	domainPtr,
								   int				extOpNbr,
								   DBA_DYNFLD_STP	*extOpTab)
{
	//DBA_HIER_HEAD_STP	*hierHeadPtr=(DBA_HIER_HEAD_STP *)argHierHeadPtr;
	char				*buffer = NULL;
	FLAG_T				matchSrcCdFlg = FALSE;
	CODE_T				opCode;
	int					childExtOpNbr = 0, i, j;
	DBA_DYNFLD_STP		*childExtOpTab = NULL;
	NUMBER_T			effectiveChildQty = 0.0;
	RET_CODE			ret = RET_SUCCEED;
	DbiConnection*  dbiConn = nullptr;


	/* REF10295 - CHU - 040528 : Get a free connection */
	if((extOpNbr > 0) && (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) != LoadGlobalOrder_NoFamily))
	{
		if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
		{
			MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
			return(DBA_CONN_NOT_FOUND);
		}
	}

	for (i = 0; i < extOpNbr; i++)
	{
		if (GET_ENUM(extOpTab[i], ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder)
		{
			/* Get all child extOp's based on ExtOp_ParOpCd */
			if ((buffer = (char *)CALLOC(10240, sizeof (char))) == NULL)
			{
				DBA_EndConnection(&dbiConn);
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				return(RET_MEM_ERR_ALLOC);
			}

			/* create all needed temporary tables */
			if ((ret = DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER)) != RET_SUCCEED)
			{
				DBA_EndConnection(&dbiConn);
				return(ret);
			}

			buffer[0] = END_OF_STRING;
			GEN_GetApplInfo(ApplMatchSourceCdFlag, &matchSrcCdFlg);

			/* Fill #tmp_oper with all parent code (or source_code), seq_n and status of parent operations */
			opCode[0]=END_OF_STRING;
			if(matchSrcCdFlg == TRUE && IS_NULLFLD(extOpTab[i], ExtOp_SrcCd) == FALSE)
			{
				strcpy(opCode, GET_CODE(extOpTab[i], ExtOp_SrcCd));
			}
			else if (IS_NULLFLD(extOpTab[i], ExtOp_Cd) == FALSE)
				{
					strcpy(opCode, GET_CODE(extOpTab[i], ExtOp_Cd));
				}

			if (opCode[0] != END_OF_STRING)
			{
				if (IS_NULLFLD(extOpTab[i], ExtOp_SequenceNo) == TRUE)
					sprintf(buffer+strlen(buffer), "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',null,%d,%d)\n",  /* PMSTA-20159 - TEB - 150624 */  /* PMSTA-25656 - TEB - 161215 */
							opCode,
							GET_ENUM(extOpTab[i], ExtOp_StatusEn),
							GET_ENUM(extOpTab[i], ExtOp_FusionEn));
				else
					sprintf(buffer+strlen(buffer), "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',%f,%d,%d)\n",  /* PMSTA-20159 - TEB - 150624 */ /* PMSTA-25656 - TEB - 161215 */
							opCode,
							GET_NUMBER(extOpTab[i], ExtOp_SequenceNo),
							GET_ENUM(extOpTab[i], ExtOp_StatusEn),
							GET_ENUM(extOpTab[i], ExtOp_FusionEn));

				if ((ret = DBA_SqlExec(buffer, *dbiConn)) != RET_SUCCEED)
				{
					FREE(buffer);
					if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
					DBA_EndConnection(&dbiConn);
					return(ret);
				}
				buffer[0] = END_OF_STRING;
			}

			/* Call notif to fill #dom_oper with children id using #tmp_oper */
			if ((ret = DBA_Notif2(Op,
								  DBA_ROLE_INIT_CHILDREN,
								  NullDynSt,
								  NULLDYNST,
								  DBA_SET_CONN|DBA_NO_CLOSE,
								  (int*)&dbiConn->getId(),
								  UNUSED)) != RET_SUCCEED)
			{
				FREE(buffer);
				if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
				DBA_EndConnection(&dbiConn);
				return(ret);
			}
			if ((ret = DBA_CreateTempTables(*dbiConn, TMP_OPER)) != RET_SUCCEED)
			{
   				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");

				FREE(buffer);
				DBA_EndConnection(&dbiConn);
				return(ret);
			}

			/* remove from #dom_oper operation that is already loaded in hierarchy */
			sprintf(buffer+strlen(buffer),
						"delete from #dom_oper where id = (%" szFormatId")", /* DLA - PMSTA08801 - 100209 */
						DBA_GetOpIdFromExtOp(extOpTab[i]));

			if ((ret = DBA_SqlExec(buffer, *dbiConn)) != RET_SUCCEED)
			{
				FREE(buffer);
				if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
				DBA_EndConnection(&dbiConn);
				return(ret);
			}
			FREE(buffer);

			/* Select Operations, positions, portfolios */
			/* and instruments by batch until #dom_oper is empty or */
			/* number of extop is bigger as ApplOpSearchRetRowCount */

			/* Load and filter all operations from table ext_order */
			DBA_LoadOrders(hierHeadPtr, domainPtr, FALSE, *dbiConn);

			/*
			remainOpNbr = opByBatchNbr;
			while (remainOpNbr >0 && extOpNbrTwo < opRowCount)
			{
				if ((ret = DBA_LoadOperByBatch(argHierHeadPtr,
											   domainPtr,
											   FALSE, /-* DON'T filter ExtOp *-/
											   &remainOpNbr,
											   &extOpNbrTwo,
											   &connectNo)) != RET_SUCCEED)
				{
					if (DBA_CreateTempTables(&connectNo, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
					DBA_EndConnection(connectNo);
					return(ret);
				}

			}
			*/

			/* Truncate temporary tables and free connection */
			if ((ret = DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER)) != RET_SUCCEED)
			{
   				MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
				DBA_EndConnection(&dbiConn);
				return(ret);
			}
			DBA_EndConnection(&dbiConn);

			DBA_SetHierLnkUsed((*hierHeadPtr), ExtOp, ExtOp_ChildExtOp_Ext);
			DBA_MakeSpecRecLinks((*hierHeadPtr),  ExtOp, ExtOp_ChildExtOp_Ext);

			DBA_SetHierLnkUsed((*hierHeadPtr), ExtOp, ExtOp_ParExtOp_Ext);
			DBA_MakeSpecRecLinks((*hierHeadPtr),  ExtOp, ExtOp_ParExtOp_Ext);

			if (GET_EXTENSION_PTR(extOpTab[i], ExtOp_ChildExtOp_Ext) != NULL)
			{
				childExtOpNbr = GET_EXTENSION_NBR(extOpTab[i], ExtOp_ChildExtOp_Ext);
				childExtOpTab = GET_EXTENSION_PTR(extOpTab[i], ExtOp_ChildExtOp_Ext);
			}

			if (childExtOpNbr > 0)
			{
				effectiveChildQty = 0;
				for (j=0 ; j<childExtOpNbr ; j++)
				{
					if (GET_ENUM(childExtOpTab[j], ExtOp_ExecOpNatEn) > ExecNat_Partial)
						continue;

                    /* PMSTA-25573 - CHU - 170505 */
                    if (DBA_IsRejectedOrder(childExtOpTab[j]) == TRUE)
                        continue;

					effectiveChildQty += GET_NUMBER(childExtOpTab[j], ExtOp_Qty);
				}
				/* Init parent effective child quantity */
				SET_NUMBER(extOpTab[i], ExtOp_EffectChildQty, CAST_NUMBER(effectiveChildQty));

			} /* end if (childExtOpNbr > 0) */
		} /* end if (GET_ENUM(extOpTab[i], ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder) */
	} /* end for (i = 0; i < extOpNbr; i++) */
	return (ret);
}

/************************************************************************
**
**  Function    :   DBA_SelectExtOpForUnspecQty()
**
**  Description :   Retrieve portfolios in List and create one ExtOp/ptf
**                  for OrderAllocation && QtyAllocNat_UnspecifiedQty
**					and set Load Type to LoadTp_UnspecQty (skip Computation)
**
**  Arguments   :   argHierHeadPtr	hierarchy pointer
**					domainPtr		domain pointer
**
**  Return      :   RET_SUCCEED or error
**
**  Created		    REF8376 - CHU - 040603
**
*************************************************************************/
RET_CODE DBA_SelectExtOpForUnspecQty(DBA_HIER_HEAD_STP *hierHeadPtr,
									 DBA_DYNFLD_STP	domainPtr)
{
	ID_T				dimPtfDictId, domPtfId;
	DBA_DYNFLD_STP		getArg=NULLDYNST;
	OBJECT_ENUM			objectEnum;
	DICT_T				dictId;
	DBA_DYNFLD_STP		aPtf=NULL;
	DBA_DYNFLD_STP		*extOpTab=NULL, *ptfIoIdTab=NULL;
	DBA_DYNFLD_STP		*parExtOpTab=NULL;
	RET_CODE			ret=RET_SUCCEED;
	int					extOpNbr=0, parExtOpNbr=0, ptfIoIdNbr=0, i, j, k=0;

    FLAG_T				matchSrcCdFlg = FALSE;

	if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(getArg, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));
    if ((ret = DBA_Select2(	EOp, UNUSED, Get_Arg, getArg,
							ExtOp, &parExtOpTab, UNUSED, UNUSED, &parExtOpNbr,
							UNUSED)) != RET_SUCCEED)
	{
		FREE_DYNST(getArg, Get_Arg);
		return(ret);
	}
	FREE_DYNST(getArg, Get_Arg);

	if(parExtOpNbr > 0)
	{
		GEN_GetApplInfo(ApplMatchSourceCdFlag, &matchSrcCdFlg);
		dimPtfDictId = GET_DICT(domainPtr, A_Domain_DimPtfDictId);
		domPtfId     = GET_ID(domainPtr, A_Domain_PtfObjId);

		if (DBA_GetObjectEnum(dimPtfDictId, &objectEnum) != TRUE)
		{
			MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
            return(RET_DBA_ERR_MD);
		}

		if (objectEnum == List)
		{
			if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
			{
				if (((*hierHeadPtr) = DBA_CreateHier())==NULL)
				{
                    return(RET_MEM_ERR_ALLOC);
				}
			}
			if ((ret = DBA_AddHierRecordList((*hierHeadPtr),
											parExtOpTab,
											parExtOpNbr,
											ExtOp,
											FALSE)) != RET_SUCCEED)
			{
				DBA_FreeDynStTab(parExtOpTab, parExtOpNbr, ExtOp);
				return(ret);
			}

			/* REF10295 - CHU - 040528 : Compute Effective Child Quantity */
			if (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) != LoadGlobalOrder_NoFamily)
			{
				ret = DBA_ComputeEffectChildQty(hierHeadPtr, domainPtr,
												parExtOpNbr, parExtOpTab);
			}

			for (i = 0; i < parExtOpNbr; i++)
			{
				if (GET_ENUM(parExtOpTab[i], ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder)
				{
					if ((ret = DBA_SelectPtfIdByDomain(domainPtr, &ptfIoIdTab, &ptfIoIdNbr)) != RET_SUCCEED)
					{
						return(ret);
	  				}

					if (ptfIoIdNbr > 0)
					{
						if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
						{
							if (((*hierHeadPtr) = DBA_CreateHier())==NULL)
							{
								for(i=0; i<ptfIoIdNbr; i++)
									FREE_DYNST(ptfIoIdTab[i], Io_Id);
								FREE(ptfIoIdTab);
                                return(RET_MEM_ERR_ALLOC);
							}
						}

                        if (GET_DICT(domainPtr, A_Domain_FctDictId) == (ENUM_T)DictFct_OrderAllocation &&
                            GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == (ENUM_T)DomSessionNat_OrderAllocation)
                        {
                            extOpTab = (DBA_DYNFLD_STP *)CALLOC(ptfIoIdNbr + 1, sizeof(DBA_DYNFLD_STP));
                        }
                        else
                        {
                            extOpTab = (DBA_DYNFLD_STP *)CALLOC(ptfIoIdNbr, sizeof(DBA_DYNFLD_STP));
                        }

                        if (extOpTab == (DBA_DYNFLD_STP *)NULL)
						{
							for(i=0; i<ptfIoIdNbr; i++)
								FREE_DYNST(ptfIoIdTab[i], Io_Id);
							FREE(ptfIoIdTab);
							FREE_DYNST(aPtf, A_Ptf);
							return(RET_MEM_ERR_ALLOC);
						}

						DBA_GetDictId(Ptf, &dictId);
						SET_DICT(domainPtr, A_Domain_DimPtfDictId, dictId);
						for (j=0; j < ptfIoIdNbr; j++)
						{
							FLAG_T allocFlg;

							if((ret = DBA_GetPtfById(GET_ID(ptfIoIdTab[j], Io_Id_Id), TRUE,
								&allocFlg, &aPtf, (*hierHeadPtr), UNUSED, UNUSED)) != RET_SUCCEED)
							{
								return(ret);
							}
							SET_ID(domainPtr, A_Domain_PtfObjId, GET_ID(aPtf, A_Ptf_Id));
							if ((ret = DBA_InitExtOpForUnspecQty(hierHeadPtr, domainPtr,
															&(extOpTab[extOpNbr]), parExtOpTab[i],
															matchSrcCdFlg)) == RET_SUCCEED)
							{
								if (extOpTab[extOpNbr] != NULL)
									extOpNbr++;
							}

							if (allocFlg == TRUE)
								FREE(aPtf);
						}

						/* Restore Domain values */
						SET_DICT(domainPtr, A_Domain_DimPtfDictId, dimPtfDictId);
						SET_ID(domainPtr, A_Domain_PtfObjId, domPtfId);
						if(extOpNbr > 0)
						{
							if ((ret = DBA_AddHierRecordList((*hierHeadPtr), extOpTab, extOpNbr, ExtOp,
															FALSE)) != RET_SUCCEED)
							{
								DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
								return(ret);
							}
						}
					}
				}
			}

            /* < PMSTA-24542 - CHU - 170117 */
            if (GET_DICT(domainPtr, A_Domain_FctDictId) == (ENUM_T)DictFct_OrderAllocation &&
                GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == (ENUM_T)DomSessionNat_OrderAllocation)
            {
                DbiConnectionHelper     dbiConnHelper; /* PMSTA-26888 - CHU 170629 */

                /* < PMSTA-24542 - CHU - 170309 */
                DBA_SetHierLnkUsed((*hierHeadPtr), ExtOp, ExtOp_ChildExtOp_Ext);
                DBA_MakeSpecRecLinks((*hierHeadPtr), ExtOp, ExtOp_ChildExtOp_Ext);

                DBA_SetHierLnkUsed((*hierHeadPtr), ExtOp, ExtOp_ParExtOp_Ext);
                DBA_MakeSpecRecLinks((*hierHeadPtr), ExtOp, ExtOp_ParExtOp_Ext);

                if (ret == RET_SUCCEED)
                {
                    /* Insert Children */
                    for (i = 0; i < extOpNbr; i++)
                    {
                        SET_ENUM(extOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
                        SET_ENUM(extOpTab[i], ExtOp_CheckParentEn, CheckParent_Disable);
                    }

                    /* Update parent(s) */
                    for (i = extOpNbr, k = 0; i < (extOpNbr + parExtOpNbr) && k < parExtOpNbr; i++)
                    {
                        SET_ENUM(parExtOpTab[k], ExtOp_DbStatusEn, ExtOpDbStatus_ToUpdate);
                        SET_ENUM(parExtOpTab[k], ExtOp_ParOpNatEn, ParOpNat_BlockOrder);
                        SET_ENUM(parExtOpTab[k], ExtOp_CheckParentEn, CheckParent_Disable);
                        SET_FLAG(parExtOpTab[k], ExtOp_NoCheckImpactFlg, TRUE);
                        SET_FLAG(parExtOpTab[k], ExtOp_NoCheckSynthAdminFlg, TRUE);
                        extOpTab[i] = parExtOpTab[k++];
                    }
                    extOpNbr += parExtOpNbr;

                    ret = DBA_FamilyOrder(Action_SaveDraft,
                                          (DBA_DYNFLD_STP*)extOpTab,
                                          extOpNbr,
                                          0,
                                          NULLDYNST,
                                          (PTR)NULL,
                                          DBA_NO_ERROR,
                                          dbiConnHelper, /* PMSTA-26888 - CHU 170629 */
                                          GET_DICT(domainPtr, A_Domain_FctDictId),
                                          domainPtr,
                                          NULLDYNSTPTR, 0,
                                          NULLDYNSTPTR,
                                          (PTR)NULL, /* PMSTA-28596 - CHU - 171012 */
                                          false);    /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
                    /* > PMSTA-24542 - CHU - 170309 */
			    }
		    }
            if (extOpNbr > 0)
            {
                FREE(extOpTab);
			}
            /* > PMSTA-24542 - CHU - 170117 */
		}
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SelectExtOpForAllocMan()
**
**  Description :   Retrieve ExtOp for OrderAllocation && QtyAllocNat_Manual
**					and set Load Type to LoadTp_AllocMan (skip Computation)
**
**  Arguments   :   argHierHeadPtr	hierarchy pointer
**					domainPtr		domain pointer
**
**  Return      :   RET_SUCCEED or error
**
**  Created		    REF8509 - CHU - 021121
**
**  Modifs      :   REF10295 - CHU - 040528 : init ExtOp_EffectChildQty
**
*************************************************************************/
RET_CODE DBA_SelectExtOpForAllocMan(DBA_HIER_HEAD_STP *hierHeadPtr,
									DBA_DYNFLD_STP	domainPtr)
{
	DBA_DYNFLD_STP		getArg=NULLDYNST;
	DBA_DYNFLD_STP		*extOpTab=NULLDYNSTPTR;
	RET_CODE			ret=RET_SUCCEED;
	int					extOpNbr=0;
	//DBA_HIER_HEAD_STP	*hierHeadPtr=(DBA_HIER_HEAD_STP *)argHierHeadPtr;

	if ((getArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(getArg, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));
    if ((ret = DBA_Select2(	EOp, UNUSED, Get_Arg, getArg,
							ExtOp, &extOpTab, UNUSED, UNUSED, &extOpNbr,
							UNUSED)) != RET_SUCCEED)
	{
		FREE_DYNST(getArg, Get_Arg);
		return(ret);
	}
	FREE_DYNST(getArg, Get_Arg);

	if(extOpNbr > 0)
	{
		if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
		{
			if (((*hierHeadPtr) = DBA_CreateHier())==NULL)
			{
                return(RET_MEM_ERR_ALLOC);
			}
		}
		if ((ret = DBA_AddHierRecordList((*hierHeadPtr),
										extOpTab,
										extOpNbr,
										ExtOp,
										FALSE)) != RET_SUCCEED)
		{
			DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
			return(ret);
		}

		/* REF10295 - CHU - 040528 : Compute Effective Child Quantity */
		if (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) != LoadGlobalOrder_NoFamily)
		{
			ret = DBA_ComputeEffectChildQty(hierHeadPtr, domainPtr,
												extOpNbr, extOpTab);
		}
	}

	return(ret);
}

/************************************************************************
**  Function             : DBA_LoadVectorIdForUMEX()
**
**  Description          : Init #vector_id table for unmatched executions
**                         search load
**
**  Arguments            : domainPtr    Domain pointer
**                         connectNo    Connection number
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF9764 - TEB - 040107
**
**  Modif.		         : REF10233 - TEB - 040513
**                         REF10234 - TEB - 040525
**
*************************************************************************/
STATIC RET_CODE DBA_LoadVectorIdForUMEX(DBA_DYNFLD_STP domainPtr,
				                        int	           connectNo)
{
    char                 *where = NULL;
    char                 *scptDefUMEXStr = NULL;
	char                 dateBuf[DATE_SQL_STRING_SIZE]; /* PMSTA-20159 - TEB - 151117 */

	RET_CODE             ret=RET_SUCCEED;
	SYSNAME_T			 dateNameStr; /* REF10234 - TEB - 040525 */

    DATE_FORMAT_ST       dateFormat;    /* PMSTA-36219 - Prajin - 191796 */


/* date fromat initialisation */
    dateFormat.ordre = Dmy;
    strcpy(dateFormat.yearSep, "/");
    strcpy(dateFormat.monthSep, "/");
    strcpy(dateFormat.daySep, "/");
    dateFormat.yearFormat = 1;
    dateFormat.monthFormat = 0;


	/* Create temporary worktable #vector_id */
    if ((ret = DBA_CreateTempTables(&connectNo, TCT_VECTOR_ID)) != RET_SUCCEED)
        return(ret);

    /* Get the script definition for the unmatched execution criteria */
    scptDefUMEXStr = GET_TEXT(domainPtr, A_Domain_UnmatchedExecSearch);

    /* Build the where clause */
    if ((where = (char *)CALLOC(1024, sizeof (char))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Modify script to add min/max status management */
    if (IS_NULLFLD(domainPtr, A_Domain_MinStatEn) == FALSE)
    {
        sprintf(where + strlen(where), "status_e >= %d AND \n", GET_ENUM(domainPtr, A_Domain_MinStatEn));
    }

    if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == FALSE)
    {
        sprintf(where + strlen(where), "status_e <= %d AND \n", GET_ENUM(domainPtr, A_Domain_MaxStatEn));
    }


	/* REF10234 - TEB - 040525 */
	/* Use the date defined in A_Domain_FusDateRuleEn for selection */
    dateNameStr[0] = END_OF_STRING;
    switch (GET_ENUM(domainPtr, A_Domain_FusDateRuleEn))
    {
        case FusDateRule_OpDate:
            strcat(dateNameStr, "operation_d");
            break;
        case FusDateRule_AcctDate:
            strcat(dateNameStr, "account_d");
            break;
        case FusDateRule_ValDate:
            strcat(dateNameStr, "value_d");
            break;
        default:
            strcat(dateNameStr, "operation_d");
            break;
    }


    /* Modify script to add test on from_d */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE)
    {
        dateBuf[0] = END_OF_STRING;

	    if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr, A_Domain_InterpFromDate), &dateFormat) == TRUE)
        { /* PMSTA-20159 - TEB - 150624 */
            sprintf(where + strlen(where), "%s >= \"%s\" AND \n", dateNameStr, dateBuf); /* REF10234 - TEB - 040525 */
        }
    }

    /* Modify script to add test on till_d */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE)
    {
		DATE_T tillDate;

        dateBuf[0] = END_OF_STRING;

	    /* REF10233 - TEB - 040513
		 * Add one day at the till date from the domain, and modify the request from <= to <
		 * because user can set a time in the execution_d from unmatched_execution with the GUI
		 */
		tillDate = GET_DATE(domainPtr, A_Domain_InterpTillDate);

	    if (DATE_FormatToStr(dateBuf, DATE_Move(tillDate, 1, Day), &dateFormat) == TRUE)
        { /* PMSTA-20159 - TEB - 150624 */
            sprintf(where + strlen(where), "%s < \"%s\" AND \n", dateNameStr, dateBuf); /* REF10234 - TEB - 040525 */
        }
    }

    /* If no where clause, create a fictive one */
    if (scptDefUMEXStr == NULL || scptDefUMEXStr[0] == END_OF_STRING)
        strcat(where, "1 = 1");
    else
        strcat(where, scptDefUMEXStr);

    /* fill #vector_id using dynamic script on unmatched execution and status value */
    if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_UMEX,
                                0,
                                where,
                                UnMatchedExecution,
                                0,
                                NULLDYNST,
                                connectNo,
                                (FLAG_T*) NULL,
                                (DBA_DYNFLD_STP**) NULL,
                                (int *)NULL,
                                (DATETIME_STP)NULL,
                                0,
                                0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                ) != RET_SUCCEED)
    {
        FREE(where);    /* REF9764 - TEB - 040204 */
        return(ret);
    }

    FREE(where);        /* REF9764 - TEB - 040204 */
	return(ret);
}

/************************************************************************
**  Function             : DBA_LoadVectorIdForCaseInquiry()
**
**  Description          : Init #vector_id table for case inquiry
**                         search load
**
**  Arguments            : domainPtr    Domain pointer
**                         connectNo    Connection number
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA07121 - DDV - 090316
**
**  Modif.		         :
**
**
*************************************************************************/
STATIC RET_CODE DBA_LoadVectorIdForCaseInquiry(DBA_DYNFLD_STP domainPtr, DbiConnection& dbiConn )
{
    char                 *scptDefStr = NULL;
	char                 dateBuf[DATETIME_SQL_STRING_SIZE]; /* PMSTA-20159 - TEB - 151117 */
	RET_CODE             ret=RET_SUCCEED;
    OBJECT_ENUM			 dimObject;
    char                 *where = NULL;
    DATE_FORMAT_ST	     dateFormat;
    FLAG_T               allocScptDefFlg = FALSE;
    DATE_T               tmpDate;

    /* date fromat initialisation */
    dateFormat.ordre = Dmy;
    strcpy(dateFormat.yearSep,  "/");
    strcpy(dateFormat.monthSep, "/");
    strcpy(dateFormat.daySep,   "/");
    dateFormat.yearFormat = 1;
    dateFormat.monthFormat = 0;

    /* Retrieve Domain Portfolio Dimension */
	if (GET_DICT(domainPtr, A_Domain_DimPtfDictId) == 0)
		dimObject = NullEntity;
	else
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject);


	/* Create temporary worktable #vector_id */
    if ((ret = DBA_CreateTempTables(dbiConn, TCT_VECTOR_ID)) != RET_SUCCEED)
        return(ret);

    /* if a dataprofile is given, apply security on dom_port and dom_instr */
	if (IS_NULLFLD(domainPtr, A_Domain_DataProfId) == FALSE)
    {
		if ((ret = DBA_Notif2(Ptf, DBA_ROLE_DATA_DECURITY, A_Domain, domainPtr,
						      DBA_SET_CONN|DBA_NO_CLOSE,
							  (int*)&dbiConn.getId(), UNUSED)) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
				"Notify failed on #dom_port in function DBA_LoadVectorIdForCaseInquiry()");
			return(ret);
		}

		if ((ret = DBA_Notif2(Instr, DBA_ROLE_DATA_DECURITY, A_Domain, domainPtr,
						      DBA_SET_CONN|DBA_NO_CLOSE,
							  (int*)&dbiConn.getId(), UNUSED)) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
				"Notify failed on #dom_instr in function DBA_LoadVectorIdForCaseInquiry()");
			return(ret);
		}
    }

    if ((where = (char *)CALLOC(10240, sizeof (char))) == NULL) /* REF7264 - LJE - 020131 */
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Retrieve Domain Function Result Dimension */
	if (IS_NULLFLD(domainPtr, A_Domain_DimFctResultDictId) == TRUE)
		dimObject = NullEntity;
	else
    {
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimFctResultDictId), &dimObject);

        if (dimObject == QuickSearch)
        {
            /* Get the script definition for function results */
            if (IS_NULLFLD(domainPtr, A_Domain_FctResultListDef) == FALSE)
                scptDefStr = GET_TEXT(domainPtr, A_Domain_FctResultListDef);
            else
                scptDefStr = "1=1";
        }
        else if (dimObject == FctResult)
        {
            if (GET_ID(domainPtr, A_Domain_FctResultId) > 0)
            {
                if ((scptDefStr = (char *)CALLOC(1024, sizeof (char))) == NULL)
                {
                    FREE(where);
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                    return(RET_MEM_ERR_ALLOC);
                }
                allocScptDefFlg = TRUE;

                sprintf(scptDefStr, " id = %" szFormatId, GET_ID(domainPtr, A_Domain_FctResultId)); /* DLA - PMSTA08801 - 100209 */
            }
            else
                scptDefStr = "1=1";
        }

        /* insert into vector_id all function resuls matching the criterias */
        if (scptDefStr != NULL && scptDefStr[0] != END_OF_STRING)
        {
			if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_VI_FCTRESULT,
                                        0,
                                        scptDefStr,
                                        FctResult,
                                        0,
                                        NULLDYNST,
										dbiConn.getId(),
                                        (FLAG_T*) NULL,
                                        (DBA_DYNFLD_STP**) NULL,
                                        (int *)NULL,
                                        (DATETIME_STP)NULL,
                                        0,
                                        0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                        ) != RET_SUCCEED)
            {
                if (allocScptDefFlg == TRUE) FREE(scptDefStr);
                FREE(where);
                return(ret);
            }
        }
        if (allocScptDefFlg == TRUE) FREE(scptDefStr);
    }

    /* Get the script definition for the case management */
    if (IS_NULLFLD(domainPtr, A_Domain_CaseMgtSearch) == FALSE)
    {
        scptDefStr = GET_TEXT(domainPtr, A_Domain_CaseMgtSearch);
        if (scptDefStr != NULL && scptDefStr[0] != END_OF_STRING)
        {
            sprintf(where + strlen(where), "%s \n", scptDefStr);
        }
    }

    /* add criteria for from date */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE && GET_DATE(domainPtr, A_Domain_InterpFromDate) != MAGIC_END_DATE)
    {
        dateBuf[0] = END_OF_STRING;
        if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr,A_Domain_InterpFromDate), &dateFormat) == TRUE)
        {
            if (strlen(where) > 0)
                sprintf(where + strlen(where), " AND ");
            sprintf(where + strlen(where), " creation_d >= \"%s\" \n", dateBuf);
        }
    }

    /* add criteria for till date */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE && GET_DATE(domainPtr, A_Domain_InterpTillDate) != MAGIC_END_DATE)
    {
        tmpDate = DATE_Move(GET_DATE(domainPtr,A_Domain_InterpTillDate), 1, Day);

        dateBuf[0] = END_OF_STRING;
		if (DATE_FormatToStr(dateBuf, tmpDate, &dateFormat) == TRUE)
		{
            if (strlen(where) > 0)
                sprintf(where + strlen(where), " AND ");
			sprintf(where + strlen(where), " creation_d < \"%s\" \n", dateBuf);
        }
    }

	/* PMSTA-18405 - 140917 - add criteria for if where clause is empty */
    if (strlen(where) == 0)
    {
		strcat(where, "1=1");  /* PMSTA-18405 - 140917 */
    }

    /* insert into vector_id the case management matching all criterias */
    if ((ret = SCPT_EvalCstList(CSTLIST_BUILD_VI_CASEMANAGEMENT,
                                0,
                                where,
                                CaseManagement,
                                0,
                                NULLDYNST,
								dbiConn.getId(),
                                (FLAG_T*) NULL,
                                (DBA_DYNFLD_STP**) NULL,
                                (int *)NULL,
                                (DATETIME_STP)NULL,
                                0,
                                0) /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                                ) != RET_SUCCEED)
    {
        FREE(where);
        return(ret);
    }

    FREE(where);
	return(ret);
}

/************************************************************************
**  Function             : DBA_LoadUMEX()
**
**  Description          : Load unmatched execution records from #vector_id,
**                         also for portfolio and instrument.
**                         Store resulting A_UnMatchedExecution into Hierarchy,
**                         also for portfolio and instrument.
**
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         connectNo     pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF9764 - TEB - 040107
**
**  Modif.		         : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
STATIC RET_CODE DBA_LoadUMEX(DBA_HIER_HEAD_STP *hierHeadPtr,
                             DBA_DYNFLD_STP domainPtr,
                             DbiConnection& dbiConn)
{
    const DBA_DYNST_ENUM *outputStLst[] =  {&A_UnMatchedExecution,
                                            &A_Ptf,
                                            &A_Instr};
    int            outputBlkNb = 3;
    DBA_DYNFLD_STP *data[3]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
    int            rows[3] = {0,0,0};
    RET_CODE       ret=RET_SUCCEED;
    FLAG_T         firstBlockFlg = FALSE;

	/* Memory initialisation */
	memset(data, 0, outputBlkNb * sizeof(DBA_DYNFLD_STP));

    if (*hierHeadPtr == NULL)
        firstBlockFlg = TRUE;

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

    if (DBA_MultiSelect2(FinAnalysis,
                         static_cast<int>(GET_DICT(domainPtr, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                         A_Domain,
                         domainPtr,
                         outputStLst,
                         data,
                         DBA_SET_CONN | DBA_NO_CLOSE,
                         UNUSED,
                         rows,
						 (int*)&dbiConn.getId(),
                         UNUSED) != RET_SUCCEED)
    {
        /* If server, check if the client conn. is dead */
        if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
        {
            DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
            /*PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
				/*DBA_EndConnection(*connectNo);*/

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
            return(RET_DBA_ERR_DISCONNECTED);
        }

		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(FinAnalysis,
                                    static_cast<int>(GET_DICT(domainPtr, A_Domain_FctDictId)), /* PMSTA_36208 - DDV - 190819 */
                                    A_Domain,
                                    domainPtr,
                                    outputStLst,
                                    data,
		                	    	DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
									(int*)&dbiConn.getId(),
                                    UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
			/*PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/
			return(ret);
		}

	}

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	DATE_START_TIMER(4, TIMER_MASK_SQLC);

    /* All intrument allready in Hierarchy must be removed from returned block */
    if ((*hierHeadPtr) != (DBA_HIER_HEAD_STP) NULL)
	    if ((ret = DBA_VerifInstrInHier(*hierHeadPtr,
		    					        &(data[2]), &(rows[2]), /* A_Instr */
			    				        NULL, NULL,             /* A_InstrChrono */
				    			        NULL, NULL,             /* A_InstrPrice */
					    		        NULL, NULL              /* A_InterCond */
						    	        )) != RET_SUCCEED)
			return(ret);

    /* All portfolio allready in Hierarchy must be removed from returned block */
    if ((*hierHeadPtr) != (DBA_HIER_HEAD_STP) NULL)
        if ((ret = DBA_VerifPtfInHier((*hierHeadPtr),
                                      &(data[1]), &(rows[1]), /* A_Ptf */
                                      NULL, NULL              /* A_PtfPosSet */
                                      )) != RET_SUCCEED)
        return(ret);

    /* --------------------------------------------------------- */
	/* Create (if needed) a hierarchy and distribute loaded data */
	/* --------------------------------------------------------- */
	if ((ret = DBA_LoadPosHierCreate(A_Domain,
                                     domainPtr,
                                     hierHeadPtr,
                                     outputBlkNb,
					                 data,
                                     rows,
                                     outputStLst,
                                     FALSE,
                                     FALSE      /* PMSTA-28086 - CHU - 170919 */
                                     )) != RET_SUCCEED) /* Don't have ExtPos */
		return(ret);

	if (firstBlockFlg == TRUE && *hierHeadPtr != (DBA_HIER_HEAD_STP)NULL)
	{
		ret = DBA_SetHierOptiPtr(*hierHeadPtr);
		if (ret != RET_SUCCEED)
			return(ret);
	}

    /* ------------------------------------------------------------------ */
	/* Set and make links used by function                                */
	/* ------------------------------------------------------------------ */
	if ((ret = DBA_SetHierLnkUsed(*hierHeadPtr,
                                  A_UnMatchedExecution,
	  		                      A_UnMatchedExecution_A_Ptf_Ext)) != RET_SUCCEED)
		return(ret);

	if ((ret = DBA_SetHierLnkUsed(*hierHeadPtr,
                                  A_UnMatchedExecution,
	  		                      A_UnMatchedExecution_A_Instr_Ext)) != RET_SUCCEED)
		return(ret);


	if ((ret = DBA_MakeLinks(*hierHeadPtr)) != RET_SUCCEED)
		return(ret);


    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadVectorIdWithMatchingOrders()
**
**  Description          : Init #vector_id table for unmatched executions
**                         search load
**
**  Arguments            : domainPtr    Domain pointer
**                         connectNo    Connection number
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF9764 - CHU - 040114
**
**  Modif.		         : REF9764 - TEB - 040122
**
*************************************************************************/
STATIC RET_CODE DBA_LoadVectorIdWithMatchingOrders(DBA_DYNFLD_STP domainPtr,
												   DBA_DYNFLD_STP unmatchedExec,
												   int			  *connectNo)
{
    char			*where			= NULL;
    char			*scptDefOrderStr= NULL;
	char			dateBuf[DATETIME_SQL_STRING_SIZE]; /* PMSTA-20159 - TEB - 151117 */
    SYSNAME_T       dateNameStr;

    DICT_ENTITY_STP		dictEntity = NULL;

	RET_CODE		ret		= RET_SUCCEED;

	/* Create temporary worktable #vector_id */
    if ((ret = DBA_CreateTempTables(connectNo, TCT_VECTOR_ID)) != RET_SUCCEED)
        return(ret);

    /* Get the script definition for the orders criteria */
    scptDefOrderStr = GET_TEXT(domainPtr, A_Domain_ExtOpSearch);

    /* Build the where clause */
    if ((where = (char *)CALLOC(10240, sizeof (char))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Modify script to add min/max status management */
    if (IS_NULLFLD(domainPtr, A_Domain_MinStatEn) == FALSE)
    {
        sprintf(where + strlen(where), "%d <= &status_e AND \n", GET_ENUM(domainPtr, A_Domain_MinStatEn));
    }

    if (IS_NULLFLD(domainPtr, A_Domain_MaxStatEn) == FALSE)
    {
        sprintf(where + strlen(where), "%d >= &status_e AND \n", GET_ENUM(domainPtr, A_Domain_MaxStatEn));
    }


    dateNameStr[0] = END_OF_STRING;
    switch (GET_ENUM(domainPtr, A_Domain_FusDateRuleEn))
    {
        case FusDateRule_OpDate:
            strcat(dateNameStr, "operation_d");
            break;
        case FusDateRule_AcctDate:
            strcat(dateNameStr, "account_d");
            break;
        case FusDateRule_ValDate:
            strcat(dateNameStr, "value_d");
            break;
        default:
            strcat(dateNameStr, "operation_d");
            break;
    }

    /* DLA - PMSTA-25863 - 170112 */
    DATE_FORMAT_ST	     dateFormat;
    dateFormat.ordre = Dmy;
    strcpy(dateFormat.yearSep, "/");
    strcpy(dateFormat.monthSep, "/");
    strcpy(dateFormat.daySep, "/");
    dateFormat.yearFormat = 1;
    dateFormat.monthFormat = 0;

    /* Modify script to add test on from_d */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE)
    {
        dateBuf[0] = END_OF_STRING;

        if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr, A_Domain_InterpFromDate), &dateFormat) == TRUE) /* DLA - PMSTA-25863 - 170112 */
        {/* PMSTA-20159 - TEB - 150624 */
            sprintf(where + strlen(where), "\"%s\" <= &%s AND \n", dateBuf, dateNameStr); /* DLA - PMSTA-25863 - 170112 */
        }
    }

    /* Modify script to add test on till_d */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE)
    {
        dateBuf[0] = END_OF_STRING;

        if (DATE_FormatToStr(dateBuf, GET_DATE(domainPtr, A_Domain_InterpTillDate), &dateFormat) == TRUE)  /* DLA - PMSTA-25863 - 170112 */
        {/* PMSTA-20159 - TEB - 150624 */
            sprintf(where + strlen(where), "\"%s\" >= &%s AND \n", dateBuf, dateNameStr);   /* DLA - PMSTA-25863 - 170112 */
        }
    }

    /* If no where clause, create a fictive one */
    if (scptDefOrderStr == NULL || scptDefOrderStr[0] == END_OF_STRING)
        strcat(where, "1 = 1");
    else
        strcat(where, scptDefOrderStr);

    dictEntity = DBA_GetDictEntitySt(EOp);

    /* fill #vector_id using dynamic script on unmatched execution and status value */
    if ((ret = SCPT_EvalFilterScript(where,                     /* scriptDef */
                                     NULL,                      /* gblGenContext */ /* REF11144 - LJE - 050608 */
                                     UnMatchedExecution,        /* recObject */
                                     unmatchedExec,             /* inputRec */
                                     dictEntity->entDictId,     /* outputEntDictId */
                                     FALSE,                     /* returnShortFlg */
                                     NULL,                      /* argHierHead */
                                     NULL,                      /* outputTab */
                                     NULL,                      /* outputNbr */
                                     *connectNo,                /* connectNo */
                                     0,                         /* colIdxParam */
                                     NULL,                      /* dataDefTabParam */
                                     NULL,                      /* dataFldTabParam */
                                     NULL,                      /* sumFmtEltTabParam */
                                     CSTLIST_BUILD_DOM_SMATCHO, /* command */
                                     FALSE,                     /* returnRowFlag */
                                     0)                         /* rowcount : get in ApplMaxDbReadRecNbr */ /* REF9904 - LJE - 040206 */
                                     ) != RET_SUCCEED)
    {
        FREE(where);    /* REF9764 - TEB - 040204 */
        return(ret);
    }

    FREE(where);        /* REF9764 - TEB - 040204 */
	return(ret);
}

/*******************************************************************************
**
**  Function    :  DBA_LoadExtTransactionInHier
**
**  Description :  Convert retrieved unmatched search results into ExtTransactions
**                 and put everything into hierarchy
**
**  Arguments   :  hierHead       hierarchy pointer
**                 unmatchedExec  current unmatched execution structure
**                 orderTab       extOrder array
**                 orderNbr       extOrder number
**                 execTab        extExecution array
**                 execNbr        extExecution number
**
**  Return      :  RET_SUCCEED if ok
**
**  Creation    :  REF9764 - CHU - 040113
**
**  Last modif. :  REF9764 - TEB - 040122
**
*******************************************************************************/
STATIC RET_CODE DBA_LoadExtTransactionInHierForSMatchO(DBA_HIER_HEAD_STP	hierHead,
													   DBA_DYNFLD_STP		unmatchedExec,
													   DBA_DYNFLD_STP		*orderTab,
													   int					orderNbr,
													   DBA_DYNFLD_STP		*execTab,
													   int					execNbr)
{
    DBA_DYNFLD_STP	extTrans          = NULLDYNST;
    DBA_DYNFLD_STP  childExecPtr      = NULLDYNST;
    DBA_DYNFLD_STP  childGlExecFeePtr = NULLDYNST;
	ID_T			umexHierId, orderHierId;
	RET_CODE		ret = RET_SUCCEED;
	FLAG_T			createExtTrans = FALSE;
	int				i, j;
    IMPORTMODENAT_ENUM impMode;             /* REF9764 - TEB - 040226 */

	/* Alloc space for one ExtTransaction structure */
	if ((extTrans = ALLOC_DYNST(A_ExtTransaction)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
        return(RET_MEM_ERR_ALLOC);
    }

	/* Alloc space for one A_Execution */
	if ((childExecPtr = ALLOC_DYNST(A_Execution)) == NULLDYNST)
	{
        FREE_DYNST(extTrans,     A_ExtTransaction);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
		return(RET_MEM_ERR_ALLOC);
	}

	/* Alloc space for one A_GlExecFee */
	if ((childGlExecFeePtr = ALLOC_DYNST(A_GlExecFee)) == NULLDYNST)
	{
        FREE_DYNST(extTrans,     A_ExtTransaction);
        FREE_DYNST(childExecPtr, A_Execution);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
		return(RET_MEM_ERR_ALLOC);
	}

	/* Convert current UnmatchedExecution into one ExtTransaction */
	if ((ret = DICT_ConvertEntity(extTrans, ExtTransaction,
								  unmatchedExec, UnMatchedExecution, false)) != RET_SUCCEED)
	{
		FREE_DYNST(extTrans,          A_ExtTransaction);
        FREE_DYNST(childExecPtr,      A_Execution);
        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
		return(ret);
	}

    /* REF9764 - TEB - 040226 */
    impMode = (IMPORTMODENAT_ENUM) GET_ENUM(extTrans, A_ExtTransaction_ImportMode);

	/* Insert this record into hierarchy */
	if ((ret = DBA_AddHierRecord(hierHead, extTrans, A_ExtTransaction, FALSE,
								 HierAddRec_NoLnk)) != RET_SUCCEED)
	{
		FREE_DYNST(extTrans,          A_ExtTransaction);
        FREE_DYNST(childExecPtr,      A_Execution);
        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
		return(ret);
	}

	/* Save Umex Parent Id for later use */
	umexHierId = GET_ID(extTrans, A_ExtTransaction_Id);
    /* Also import mode enum */ /* REF9764 - TEB - 040226 */
    impMode = (IMPORTMODENAT_ENUM) GET_ENUM(extTrans, A_ExtTransaction_ImportMode);

	if (orderNbr > 1)
	{
		TLS_Sort((char *)(orderTab), orderNbr, sizeof(DBA_DYNFLD_STP),
				 (TLS_CMPFCT*)FIN_CmpExtOpByOpId, (PTR **) NULL, (SORT_RTN_TP_ENUM)SortRtnTp_None );
    }
	/* Compute executed quantity and weigthed mean quote */
	DBA_ExtExecCalcQtyAndWeightMeanQuote(orderTab, orderNbr, execTab, execNbr);

	/* insert all extOrders in hierarchy */
	if ((ret =	DBA_AddHierRecordList(hierHead, orderTab, orderNbr, ExtOp, FALSE)) != RET_SUCCEED)
	{
		FREE_DYNST(extTrans,          A_ExtTransaction);
        FREE_DYNST(childExecPtr,      A_Execution);
        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
		return(ret);
	}

	/* insert all extended execution in hierarchy */
	if ((ret = DBA_AddHierRecordList(hierHead, execTab, execNbr, A_ExtExecution, FALSE)) != RET_SUCCEED)
	{
		FREE_DYNST(extTrans,          A_ExtTransaction);
        FREE_DYNST(childExecPtr,      A_Execution);
        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
		return(ret);
	}

	for (i=0; i < orderNbr; i++)
	{

		/* Alloc space for one ExtTransaction structure */
		if ((extTrans = ALLOC_DYNST(A_ExtTransaction)) == NULLDYNST)
		{
            FREE_DYNST(childExecPtr,      A_Execution);
            FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
			return(RET_MEM_ERR_ALLOC);
		}
		/* Convert current extOrder into one ExtTransaction */
		if ((ret = DICT_ConvertEntity(extTrans, ExtTransaction, orderTab[i], EOp, false)) != RET_SUCCEED)
		{
		    FREE_DYNST(extTrans,          A_ExtTransaction);
            FREE_DYNST(childExecPtr,      A_Execution);
            FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
			return(ret);
		}
		/* Set Parent Id of extOrder Transaction with unmatched Execution Hierarchy Id */
		SET_ID(extTrans, A_ExtTransaction_ParentExtTransId, umexHierId);
        /* REF9764 - TEB - 040226 */
        SET_ENUM(extTrans, A_ExtTransaction_ImportMode, impMode);


		/* Add this extOrder extTransaction into hierarchy */
		if ((ret = DBA_AddHierRecord(hierHead, extTrans, A_ExtTransaction, FALSE,
									 HierAddRec_NoLnk)) != RET_SUCCEED)
		{
		    FREE_DYNST(extTrans,          A_ExtTransaction);
            FREE_DYNST(childExecPtr,      A_Execution);
            FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
			return(ret);
		}

		/* Save order Parent Id for later use */
		orderHierId = GET_ID(extTrans, A_ExtTransaction_Id);

		for (j=0; j < execNbr; j++)
		{
			/* search for associated executions */
			if(CMP_ID(DBA_GetOpIdFromExtOp(orderTab[i]), GET_ID(execTab[j], A_ExtExecution_ExtOrderId)) == 0)
			{
				if(IS_NULLFLD(execTab[j], A_ExtExecution_ExecutionId) == FALSE)
				{
				    if ((extTrans = ALLOC_DYNST(A_ExtTransaction)) == NULLDYNST)
				    {
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
					    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
					    return(RET_MEM_ERR_ALLOC);
				    }

                    /* Reset dynamic structure */
                    SET_NULL_DYNST(childExecPtr, A_Execution);

					/* Convert current ExtExecution into one Execution */
					if ((ret = DICT_ConvertEntity(childExecPtr, ExecutionEnt,
												  execTab[j],   ExtExecutionEnt, false)) != RET_SUCCEED)
					{
		                FREE_DYNST(extTrans,          A_ExtTransaction);
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
						return(ret);
					}
					/* Convert current Execution into one ExtTransaction */
					if ((ret = DICT_ConvertEntity(extTrans,     ExtTransaction,
												  childExecPtr, ExecutionEnt, false)) != RET_SUCCEED)
					{
		                FREE_DYNST(extTrans,          A_ExtTransaction);
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
						return(ret);
					}
					createExtTrans = TRUE;
				}
				else if(IS_NULLFLD(execTab[j], A_ExtExecution_GlobalExecutionFeeId) == FALSE)
				{
				    if ((extTrans = ALLOC_DYNST(A_ExtTransaction)) == NULLDYNST)
				    {
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
					    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtTransaction");
					    return(RET_MEM_ERR_ALLOC);
				    }

                    /* Reset dynamic structure */
                    SET_NULL_DYNST(childGlExecFeePtr, A_GlExecFee);

					/* Convert current ExtExecution into one GlExecFee */
					if ((ret = DICT_ConvertEntity(childGlExecFeePtr, GlExecFeeEnt,
												  execTab[j],        ExtExecutionEnt, false)) != RET_SUCCEED)
					{
		                FREE_DYNST(extTrans,          A_ExtTransaction);
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
						return(ret);
					}
					/* Convert current Execution into one ExtTransaction */
					if ((ret = DICT_ConvertEntity(extTrans,          ExtTransaction,
												  childGlExecFeePtr, GlExecFeeEnt, false)) != RET_SUCCEED)
					{
		                FREE_DYNST(extTrans,          A_ExtTransaction);
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
						return(ret);
					}
					createExtTrans = TRUE;
				}
				if (createExtTrans == TRUE)
				{
					/* Set Parent Id of GlobalFee/Execution Transaction
					 * with extOrder Transaction Hierarchy Id
					 */
					SET_ID(extTrans, A_ExtTransaction_ParentExtTransId, orderHierId);
                    /* REF9764 - TEB - 040226 */
                    SET_ENUM(extTrans, A_ExtTransaction_ImportMode, impMode);


					/* Add this GlobalFee/Execution extTransaction into hierarchy */
					if ((ret = DBA_AddHierRecord(hierHead, extTrans, A_ExtTransaction, FALSE,
												 HierAddRec_NoLnk)) != RET_SUCCEED)
					{
		                FREE_DYNST(extTrans,          A_ExtTransaction);
                        FREE_DYNST(childExecPtr,      A_Execution);
                        FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
						return(ret);
					}
					/* Reset flag for next processing */
					createExtTrans = FALSE;
				}
			}
		}
	}

    FREE_DYNST(childExecPtr,      A_Execution);
    FREE_DYNST(childGlExecFeePtr, A_GlExecFee);
	return(RET_SUCCEED);
}


/************************************************************************
**  Function             : DBA_LoadRecordsForSMatchO()
**
**  Description          : Load ext_order, ext_execution, instrument
**                         and ptf for orders set in #vector_id
**
**  Arguments            : hierHead       hierarchy pointer
**                         orderTab       extOrder array
**                         orderNbr       extOrder number
**                         execTab        extExecution array
**                         execNbr        extExecution number
**                         connectNo      Connection number
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF9764 - TEB - 040122
**
**  Modif.		         :
**
*************************************************************************/
STATIC RET_CODE DBA_LoadRecordsForSMatchO(DBA_HIER_HEAD_STP	hierHead,
                                          DBA_DYNFLD_STP    **orderTab,
                                          int				*orderNbr,
                                          DBA_DYNFLD_STP	**execTab,
                                          int				*execNbr,
                                          DbiConnection&   dbiConn)
{
    const DBA_DYNST_ENUM *outputStLst[] =  {&ExtOp,
                                            &A_ExtExecution,
                                            &A_Ptf,
                                            &A_Instr};
    int            outputBlkNb = 4;
    DBA_DYNFLD_STP *data[4]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
    int            rows[4] = {0,0,0,0};
    RET_CODE       ret=RET_SUCCEED;
    FLAG_T         firstBlockFlg = FALSE;

	/* Memory initialisation */
	memset(data, 0, outputBlkNb * sizeof(DBA_DYNFLD_STP));

    if (hierHead == NULL)
        firstBlockFlg = TRUE;

    DATE_START_TIMER(2, TIMER_MASK_SQLC);

    if ((ret = DBA_MultiSelect2( EOp,
                                 UNUSED,
                                 NullDynSt,
                                 NULLDYNST,
                                 outputStLst,
                                 data,
                                 DBA_SET_CONN | DBA_NO_CLOSE,
                                 UNUSED,
                                 rows,
								 (int*)&dbiConn.getId(),
                                 UNUSED)) != RET_SUCCEED)
    {
        /* If server, check if the client conn. is dead */
        if (SERVER_MODE() == TRUE && true == SYS_GetThreadClientConnectIODead())        /* PMSTA-19735 - 020415 - PMO */
        {
            DBA_LoadPosDropTempTables(dbiConn, DictFct_SearchMatchingOrder);
            /*PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Client connection death has been detected");
            return(RET_DBA_ERR_DISCONNECTED);
        }

		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(EOp,
                                    UNUSED,
                                    NullDynSt,
                                    NULLDYNST,
                                    outputStLst,
                                    data,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
									(int*)&dbiConn.getId(),
                                    UNUSED)) != RET_SUCCEED)
		{
			DBA_LoadPosDropTempTables(dbiConn, DictFct_SearchMatchingOrder);
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed again");
			/*PMSTA-13649 - TGU - 120222 - Multiple end connection!*/
			/* connection life suppose to be taken care by calling function, which is providing the connection pointer */
			/*DBA_EndConnection(*connectNo);*/
			return(ret);
		}

	}

	DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	DATE_START_TIMER(4, TIMER_MASK_SQLC);

    /* All portfolio allready in Hierarchy must be removed from returned block */
    if (hierHead != (DBA_HIER_HEAD_STP) NULL)
        if ((ret = DBA_VerifPtfInHier(hierHead,
                                      &(data[2]),
                                      &(rows[2]),
                                      NULL,
                                      NULL)) != RET_SUCCEED)
        {
            FREE(data[0]);
            FREE(data[1]);
            FREE(data[2]);
            FREE(data[3]);
            return(ret);
        }

    /* Put portfolio in hierarchy */
    if ( (ret=DBA_AddHierRecordList(hierHead, data[2], rows[2], *(outputStLst[2]), TRUE))!=RET_SUCCEED)
    {
        FREE(data[0]);
        FREE(data[1]);
        FREE(data[2]);
        FREE(data[3]);
        return(ret);
    }

    /* Free portofolios */
    FREE(data[2]);

    /* All intrument allready in Hierarchy must be removed from returned block */
    if (hierHead != (DBA_HIER_HEAD_STP) NULL)
	    if ((ret = DBA_VerifInstrInHier(hierHead,
		    					        &(data[3]),
                                        &(rows[3]),
			    				        NULL, NULL,
				    			        NULL, NULL,
					    		        NULL, NULL)) != RET_SUCCEED)
        {
            FREE(data[0]);
            FREE(data[1]);
            FREE(data[3]);
			return(ret);
        }

    /* Put instrument in hierarchy */
    if ( (ret=DBA_AddHierRecordList(hierHead, data[3], rows[3], *(outputStLst[3]), TRUE))!=RET_SUCCEED)
    {
        FREE(data[0]);
        FREE(data[1]);
        FREE(data[3]);
        return(ret);
    }

    /* Free instruments */
    FREE(data[3]);

    DATE_STOP_TIMER(4, TIMER_MASK_SQLC);

    /* Set the array of orders end executions */
    *orderTab =  data[0];
    *orderNbr =  rows[0];
    *execTab  =  data[1];
    *execNbr  =  rows[1];

    return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadExtTransForSMatchO()
**
**  Description          : Load unmatched execution records from #vector_id,
**                         also for portfolio and instrument.
**                         Load all matching Orders and execution
**                         and transform all into extended Transaction
**                         Store everything into Hierarchy and make links
**
**
**  Arguments            : hierHeadPtr   hierarchy header pointer
**                         domainPtr     domain arguments pointer
**                         connectNo     pointer on the connection number to use
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		     : REF9764 - CHU - 040114
**
**  Modif.		         :
**
*************************************************************************/
RET_CODE DBA_LoadExtTransForSMatchO(DBA_HIER_HEAD_STP hierHead,
									DBA_DYNFLD_STP	  domainPtr,
									DbiConnection&    dbiConn)
{
	DBA_DYNFLD_STP		*umexTab	= (DBA_DYNFLD_STP*)NULL,
						*orderTab	= (DBA_DYNFLD_STP*)NULL,
						*execTab	= (DBA_DYNFLD_STP*)NULL,
                        outUmex     = (DBA_DYNFLD_STP) NULL;
	RET_CODE			ret = RET_SUCCEED;
	int					i, umexNbr, orderNbr, execNbr;

    /* Allocation of outUmex */
	if ((outUmex = ALLOC_DYNST(S_UnMatchedExecution)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	/* Extract all UMEX from Hier */
	if ((ret = DBA_ExtractHierEltRec(hierHead,
                                     A_UnMatchedExecution,
		                             FALSE,
                                     NULLFCT,
                                     NULL,
				                     &umexNbr,
                                     &umexTab)) == RET_SUCCEED)
	{
		for (i=0; i < umexNbr; i++)
		{
            /* REF9764 - TEB - 040225
             * Test if the unmatched execution exists in DB
             * If yes : treat him normaly
             * If no  : suppress him from hierarchy and ignore him
             */
		    if (DBA_Get2(UnMatchedExecution,
                         UNUSED,
                         A_UnMatchedExecution,
                         umexTab[i],
				         S_UnMatchedExecution,
                         &outUmex,
                         DBA_SET_CONN|DBA_NO_CLOSE,
						 (int*)&dbiConn.getId(),
                         UNUSED) == RET_SUCCEED)
		    {
			    /* Get all orders and executions for this unmatched execution */
                /* First load #vector_id with matching order id */
			    if ((ret = DBA_LoadVectorIdWithMatchingOrders(domainPtr,
                                                              umexTab[i],
															  (int*)&dbiConn.getId())) == RET_SUCCEED)
			    {
				    /* Secondly load ext_order, ext_execution, instruments, ptfs for
                     * all the order id that are in #vector_id
                     * instruments and ptf are put in hierarchy */
                    if ((ret = DBA_LoadRecordsForSMatchO(hierHead,
                                                         &orderTab,
                                                         &orderNbr,
                                                         &execTab,
                                                         &execNbr,
                                                         dbiConn)) == RET_SUCCEED)
                    {
				        /* convert them into extTrans and put them in Hierarchy */
				        ret= DBA_LoadExtTransactionInHierForSMatchO(hierHead,
                                                                    umexTab[i],
                                                                    orderTab,
                                                                    orderNbr,
                                                                    execTab,
                                                                    execNbr);
                        FREE(execTab);
                        FREE(orderTab);
                    }
			    }

                /* Log msg */
                if (ret != RET_SUCCEED)
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                "Search Matching Order : Error in load data for umex id : ",
                                GET_ID(umexTab[i],A_UnMatchedExecution_Id));
                }
            }
            else
            {
                /* The Umex doesn't exist in DB, suppress him from hierarchy */
				if (DBA_DelAndFreeHierEltRec(hierHead,
                                             A_UnMatchedExecution,
                                             umexTab[i]) != RET_SUCCEED)
				{
					MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
						         "Search Matching Order : Unable to remove from hierarchy umex id :",
                                 GET_ID(umexTab[i],A_UnMatchedExecution_Id));
				}
            }
		}

        FREE(umexTab);
	}

    /* Free of outUmex */
    FREE_DYNST(outUmex, S_UnMatchedExecution);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfInstrValDate()
**
**  Description :   Op sorted by Instr and Value date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Op
**                  ptr2   pointer on dynamic structure type A_Op
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   PMSTA00485 - CHU - 061011
**
*************************************************************************/
STATIC int FIN_CmpOpInstrValDate(DBA_DYNFLD_STP *ptr1,
									DBA_DYNFLD_STP *ptr2)
{
    int ret;

	if((ret = CMP_ID(GET_ID((*ptr1), A_Op_InstrId),
					 GET_ID((*ptr2), A_Op_InstrId))) == 0)
	{
		/* Ascending dates (older first) */
		return(DATETIME_CMP(GET_DATETIME((*ptr1), A_Op_ValDate),
							GET_DATETIME((*ptr2), A_Op_ValDate)));
	}
	return(ret);

}

/************************************************************************
**
**  Function    :   DBA_SelectIncomeOperForValo()
**
**  Description :   Select income operation for given portfolio(s)/instrument(s)
**
**  Arguments   :   domainPtr	  domain pointer
**                  ptfTab	      array of portfolio identifiers
**                  ptfNbr        number of portfolios in the array
**                  instrTab      array of instrument identifiers
**                  instrNbr      number of instruments in the array
**                  incOpTab      array of income operations (output)
**                  incOpNbr      number of income operations in the array (output)
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - CHU - 061011
**
*************************************************************************/
RET_CODE DBA_SelectIncomeOperForValo(DBA_DYNFLD_STP	domainPtr,
									 DBA_DYNFLD_STP	*ptfTab,
									 int			ptfNbr,
									 DBA_DYNFLD_STP	*instrTab,
									 int			instrNbr,
									 DBA_DYNFLD_STP	**incOpTab,
									 int			*incOpNbr)
{
	RET_CODE		ret=RET_SUCCEED;
	DICT_T			initialDimPtfDict=0;
	DbiConnection*  dbiConn = nullptr;

	*incOpNbr = 0;
	*incOpTab = NULLDYNSTPTR;

	/* Get a free connection in the connection list */
	if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

	if ((ret = DBA_LoadPosPtfInstrDimension(domainPtr, *dbiConn, ptfTab, ptfNbr,
											instrTab, instrNbr, &initialDimPtfDict)) != RET_SUCCEED)
	{
		DBA_EndConnection(&dbiConn);
		return(ret);
	}

	ret = DBA_Select2(Op, DBA_ROLE_SEL_INCOME_FOR_VALO, A_Domain, domainPtr, A_Op, incOpTab,
		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, incOpNbr, (int*)&dbiConn->getId(), UNUSED);

	if (ret == RET_SUCCEED && (*incOpNbr) > 1)
	{
		TLS_Sort((char *)(*incOpTab), *incOpNbr, sizeof(DBA_DYNFLD_STP),
				(TLS_CMPFCT*)FIN_CmpOpInstrValDate, (PTR **)NULL, SortRtnTp_None);
	}

	DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
	DBA_EndConnection(&dbiConn);
	return(ret);
}


/************************************************************************
**
**  Function    :   DBA_LoadSessionOrder()
**
**  Description :   Load all order linked to a session into hierarchy
**                  The store proc use #dom_port and #dom_instr they must
**                  be filled correctly.
**
**  Arguments   :   domainPtr    Domain of the financial function
**                  hierHead     pointer on hierarchy structure
**
**  Return      :   RET_CODE
**
**
**
**  Creation    :   PMSTA09451 - DDV - 100304
**  Modif       :
*************************************************************************/
RET_CODE DBA_LoadSessionOrder(DBA_DYNFLD_STP    domainPtr,
                                     DBA_HIER_HEAD_STP hierHead,
                                     int               *connectNo)
{
    const DBA_DYNST_ENUM *outputStLst[] = {&ExtOp, &A_Ptf, &A_Instr};
	DBA_DYNFLD_STP  *data[3]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
	int             rows[3] = {0,0,0}, i=0;
    RET_CODE        ret=RET_SUCCEED;

	if (hierHead == (DBA_HIER_HEAD_STP) NULL)
        return(RET_GEN_ERR_INVARG);

    if (DBA_MultiSelect2(EOp,
                         DBA_ROLE_ORDER_SESSION,
                         A_Domain,
                         domainPtr,
					     outputStLst,
                         data,
		        	     DBA_SET_CONN|DBA_NO_CLOSE,
					     UNUSED,
                         rows,
                         connectNo,
                         UNUSED) != RET_SUCCEED)
	{

		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(EOp,
                                    DBA_ROLE_ORDER_SESSION,
                                    A_Domain,
                                    domainPtr,
                                    outputStLst,
                                    data,
                                    DBA_SET_CONN|DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
                                    connectNo,
                                    UNUSED)) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_MultiSelect failed again");
			return(ret);
		}
	}

    if (rows[0] > 0)
    {
        for (i=0; i<rows[0]; i++)
        {
			if (DBA_AddHierCollectedRecord(hierHead, data[0][i], ExtOp,
										   TRUE,	/* db record */
										   0,		/* no supplementary fields */
										   HierAddRec_NoLnk) != RET_SUCCEED)
		    {
                for (;i<rows[0]; i++)
                    FREE_DYNST(data[0][i], ExtOp);

                FREE(data[0]);
                DBA_FreeDynStTab(data[1], rows[1], A_Ptf);
                DBA_FreeDynStTab(data[2], rows[2], A_Instr);
			    return(ret);
		    }
        }

#if 0
		if ((ret = DBA_AddHierRecordList(hierHead, data[0], rows[0],
										 *(outputStLst[0]), TRUE)) != RET_SUCCEED)
		{
            DBA_FreeDynStTab(data[0], rows[0], ExtOp);
            DBA_FreeDynStTab(data[1], rows[1], A_Ptf);
            DBA_FreeDynStTab(data[2], rows[2], A_Instr);
			return(ret);
		}
#endif
    }

	if ((ret = DBA_VerifPtfInHier(hierHead,
								  &(data[1]), &(rows[1]), /* A_Ptf */
								  NULL, NULL              /* A_PtfPosSet */
								  )) != RET_SUCCEED)
	{
        FREE(data[0]);
        DBA_FreeDynStTab(data[1], rows[1], A_Ptf);
        DBA_FreeDynStTab(data[2], rows[2], A_Instr);
		return(ret);
	}

    if (rows[1] > 0)
    {
		if ((ret = DBA_AddHierRecordList(hierHead, data[1], rows[1],
										 *(outputStLst[1]), TRUE)) != RET_SUCCEED)
		{
            FREE(data[0]);
            DBA_FreeDynStTab(data[1], rows[1], A_Ptf);
            DBA_FreeDynStTab(data[2], rows[2], A_Instr);
			return(ret);
		}
    }


	if ((ret = DBA_VerifInstrInHier(hierHead,
									&(data[2]), &(rows[2]),   /* A_Instr */
                                    NULL, NULL,               /* A_InstrChrono */
                                    NULL, NULL,               /* A_InstrPrice */
                                    NULL, NULL                /* A_InterCond */
                                   )) != RET_SUCCEED)
	{
        FREE(data[0]);
        FREE(data[1]);
        DBA_FreeDynStTab(data[2], rows[2], A_Instr);
		return(ret);
	}

    if (rows[2] > 0)
    {
		if ((ret = DBA_AddHierRecordList(hierHead, data[2], rows[2],
										 *(outputStLst[2]), TRUE)) != RET_SUCCEED)
		{
            FREE(data[0]);
            FREE(data[1]);
            DBA_FreeDynStTab(data[2], rows[2], A_Instr);
			return(ret);
		}
    }

    FREE(data[0]);
    FREE(data[1]);
    FREE(data[2]);

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_FilterValoPositions()
**
**  Description :   Filter all position not open at till date
**                  Reproduce where clause used in stored procedure sel_exd_pos_for_valo_by_def_d
**
**                  select ... from position  po,
**                             where ((po.begin_d <= @begin_d and po.end_d > @begin_d )
**                                    or
**                                    (po.begin_d <= @begin_d and po.end_d = @begin_d and primary_e = 1 and open_oper_nat_e = 7
**                                     and main_f = 0 and pos_nat_e = 6 and adjustment_nat_e in (1, 2)
**                                    )
**                                   )
**
**
**                  return TRUE  -> record must be deleted
**                         FALSE -> record musn't be deleted
**
**  Arguments   :   posPtr     dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            domainPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA13795 - DDV - 120423
**
*************************************************************************/
STATIC int DBA_FilterValoPositions(DBA_DYNFLD_STP posPtr,
			                       DBA_DYNST_ENUM dynStTp,
                                   DBA_DYNFLD_STP domainPtr)
{

	/* PMSTA13795 - DDV - 120604 - remove balance positions, valuation don't load them */
	if (IS_NULLFLD(posPtr, ExtPos_BalPosTpId) == FALSE)
        return(TRUE);

	/* PMSTA15092 - DDV - 121004 - If needed, remove zero positions (po.quantity_n == 0 and po.accr_amount_m == 0) */
	if (GET_FLAG(domainPtr, A_Domain_ZeroQtyFlg) == FALSE &&
		(GET_NUMBER(posPtr, ExtPos_Qty ) == 0.0 && GET_AMOUNT(posPtr, ExtPos_AccrAmt) == 0.0))
        return(TRUE);

	if (((DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0)  &&
         (DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_EndDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) > 0)
        ) ||
        ((DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0)  &&
         (DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_EndDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) == 0)  &&
         (GET_ENUM(posPtr, ExtPos_PrimaryEn) == PosPrimary_Primary) &&
         (GET_ENUM(posPtr, ExtPos_OpenOpNatEn) == OpNat_Adjust) &&
         (GET_FLAG(posPtr, ExtPos_MainFlg) == FALSE) &&
         (GET_ENUM(posPtr, ExtPos_PosNatEn) == PosNat_MainAcctPos) &&
         ((GET_ENUM(posPtr, ExtPos_AdjustNatEn) == OpAdjustNat_GrossAmt) || (GET_ENUM(posPtr, ExtPos_AdjustNatEn) == OpAdjustNat_Pl))
        )
       )
        return(FALSE);
    else
        return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_FilterOpHistPositions()
**
**  Description :   Filter all position not open at from or till date
**                  Reproduce where clause used in stored procedure sel_exd_pos_for_hist_by_def_d
**
**                  select ... from position  po,
**                  where
**                  ...
**                  and ((po.begin_d <= @begin_d
**                        and po.end_d > @begin_d)
**                       or
**                       (po.primary_e > 0
**                        and po.begin_d > @begin_d and po.begin_d <= @end_d)
**                       or
**                       (po.primary_e = 0
**                        and po.begin_d <= @end_d
**                        and po.end_d > @end_d))
**
**                  from balance_pos bp, $TT_DOM_PORT dp
**                  where
**                  ...
**                  and ((po.begin_d <= @begin_d
**                        and po.end_d > @begin_d)
**                       or
**                       (po.primary_e > 0
**                        and po.begin_d > @begin_d
**                        and po.begin_d <= @end_d)
**                       or
**                       (po.primary_e = 0
**                        and po.begin_d <= @end_d
**                        and po.end_d > @end_d))
**
**                  return TRUE  -> record must be deleted
**                         FALSE -> record musn't be deleted
**
**  Arguments   :   posPtr     dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            domainPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA14174 - DDV - 120522
**
**  Last modif. :   PMSTA-15769 - 140113 - PMO : Reversed and Reversal main positions are not returned in Operation History with P&L Restart
**
*************************************************************************/
STATIC int DBA_FilterOpHistPositions(DBA_DYNFLD_STP posPtr,
			                         DBA_DYNST_ENUM dynStTp,
                                     DBA_DYNFLD_STP domainPtr)
{
	/* PMSTA15092 - DDV - 121004 - If needed, remove zero positions (po.quantity_n == 0 and po.accr_amount_m == 0) */
	if (GET_FLAG(domainPtr, A_Domain_ZeroQtyFlg) == FALSE &&
        DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0  &&    /* PMSTA-15769 - 140113 - PMO */
		(GET_NUMBER(posPtr, ExtPos_Qty ) == 0.0 && GET_AMOUNT(posPtr, ExtPos_AccrAmt) == 0.0))
        return(TRUE);

    if ((DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0  &&
         DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_EndDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) > 0
		) ||
        (GET_ENUM(posPtr, ExtPos_PrimaryEn) > PosPrimary_Derived &&
		 DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) > 0  &&
         DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) <= 0
		) ||
        (GET_ENUM(posPtr, ExtPos_PrimaryEn) == PosPrimary_Derived &&
		 DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_BegDate),GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) <= 0  &&
         DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_EndDate),GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) > 0
		)
       )
        return(FALSE);
    else
        return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_UpdateCostPrice()
**
**  Description :
**
**  Arguments   :   hierHeadPtr hierarchy header pointer
**                  domainPtr   pointer on domain
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   PMSTA13795 - DDV - 120423
**
*************************************************************************/
RET_CODE DBA_UpdateCostPrice(DBA_HIER_HEAD_STP hierHead,
				                    DBA_DYNFLD_STP    domainPtr)
{
	RET_CODE          ret=RET_SUCCEED;
	DBA_DYNFLD_STP    ptfPtr=NULLDYNST;
    PTFFUSRULE_ENUM   fusRuleEn;
    LOGICIDRULE_ENUM  posLogicalEn;
    FLAG_T            allocFlg=FALSE;
    OBJECT_ENUM       dimPtfEn=NullDynSt;
	DICT_T savedFctDictId=0;

    /* FIN_ComputeOnLineMktValPL function */
    fusRuleEn=(PTFFUSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusRuleEn);
    posLogicalEn=(LOGICIDRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PosLogicEn);

	if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
	{
		DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
		if (dimPtfEn == Ptf)
		{
            DBA_GetPtfById(GET_ID(domainPtr, A_Domain_PtfObjId), FALSE, &allocFlg, &ptfPtr, hierHead , UNUSED, UNUSED);

            if (ptfPtr != NULL)
            {
                if (GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL
                    && GET_ID(ptfPtr, A_Ptf_CurrId) == GET_ID(domainPtr, A_Domain_CurrId))
                {
                    SET_ENUM(domainPtr, A_Domain_PLMethodEn, PLMethod_Standard);
                    return(ret);
                }

                fusRuleEn = (PTFFUSRULE_ENUM)GET_ENUM(ptfPtr, A_Ptf_FusionRuleEn);
                posLogicalEn= (LOGICIDRULE_ENUM)GET_ENUM(ptfPtr, A_Ptf_PosLogicalEn);
            }
		}
	}

    if (GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_Standard)
    {
        return(ret);
    }

	/* PMSTA14174 - DDV - 120523 - To avoid multiple generation of initial/flow/final position, change function dict id to Valo to preare position for valuation */
	savedFctDictId = GET_DICT(domainPtr, A_Domain_FctDictId);
	SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_Valo);
	if ((ret = DBA_LoadPosHierLnkAndUpd(hierHead, domainPtr, TRUE)) != RET_SUCCEED)
	{
        if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
		return(ret);
	}

	/* PMSTA14174 - DDV - 120523 - Change function dict id to saved one */
	SET_DICT(domainPtr, A_Domain_FctDictId, savedFctDictId);

	ret = FIN_ComputeOnLineMktValPL(domainPtr, ptfPtr, hierHead, fusRuleEn, posLogicalEn); /* PMSTA13640 - DDV - 120207 */

    /* Set back from date to do valuation */
    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, GET_DATETIME(domainPtr, A_Domain_InitialFromDate)); /* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */

    /* Set back initial zero_pos_f - PMSTA15092 - DDV - 121040 */
    SET_FLAG(domainPtr, A_Domain_ZeroQtyFlg, GET_FLAG(domainPtr, A_Domain_SaveZeroQtyFlg));

    /* remove all PosVal */
	if (ret == RET_SUCCEED)
    {
        ret = DBA_DelAndFreeHierElt(hierHead, PosVal);
    }

    /* keep only position open at valuation date (domain till date) */
	if (ret == RET_SUCCEED)
    {
		switch(GET_DICT(domainPtr, A_Domain_FctDictId))
		{
			case DictFct_Valo:
				ret = DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtPos, DBA_FilterValoPositions, domainPtr, NULL);
				break;

			/* PMSTA14174 - DDV - 120522 - P&L restart on Operation History */
			case DictFct_OpHist:
				ret = DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtPos, DBA_FilterOpHistPositions, domainPtr, NULL);
				break;
		}
    }

    if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadTascJobInputTables()
**
**  Description :   Load all TSL's data for one tasc_job_table input table.
**
**  Arguments   :   tascJobTable    pointer an A_TascJobTable
**                  hierHead        hierarchy header
**
**  Return      :   RET_SUCCEED or error
**
**  Created		:   PMSTA13876 - DDV - 130815
**
*************************************************************************/
STATIC RET_CODE DBA_LoadOneTascJobInputTable(DBA_DYNFLD_STP    tascJobTable,
                                             DBA_HIER_HEAD_STP hierHead,
                                             DbiConnection&    dbiConn)
{
    RET_CODE              ret=RET_SUCCEED, msgResult;
    DBA_DYNFLD_STP        *dataTab=NULLDYNSTPTR, bindSt=NULLDYNST;
    int                   dataNbr=0;
    DBA_DYNFLD_STP        fmtPtr, tascJobPtr;
    DBA_DYNFLD_STP        admArg, sFmtElt;
    DICT_ENTITY_STP       entityInfo;
	DBA_DYNST_ENUM        dynSt=NullDynSt;
    char                  *sqlBuff=NULL;
    OBJECT_ENUM           objectEnum = NullEntity;
    SYSNAME_T             searchKeyFieldStr;

    memset (searchKeyFieldStr, '\0', sizeof(SYSNAME_T));

    /* create query and send command to database */
    if (GET_EXTENSION_PTR(tascJobTable, A_TascJobTable_Fmt_Ext) != NULL &&
        (fmtPtr = *(GET_EXTENSION_PTR(tascJobTable, A_TascJobTable_Fmt_Ext))) != NULLDYNST &&
        GET_EXTENSION_PTR(tascJobTable, A_TascJobTable_TascJob_Ext) != NULL &&
        (tascJobPtr = *(GET_EXTENSION_PTR(tascJobTable, A_TascJobTable_TascJob_Ext))) != NULLDYNST)
    {
        SYSNAME_T       tempTableName;
        memset (tempTableName, '\0', sizeof(SYSNAME_T));

        DBA_GetObjectEnum(GET_DICT(tascJobPtr, A_TascJob_EntityDictId), &objectEnum);

        switch(GET_OBJECT_CST(objectEnum))
        {
            case PtfCst:
                strcpy(tempTableName, "#dom_port");
                break;
            case InstrCst:
                strcpy(tempTableName, "#dom_instr");
                break;
            case StratCst:
                strcpy(tempTableName, "#dom_strat");
            case ThirdCst:
                strcpy(tempTableName, "#dom_third");
                break;
            case CurrCst:
                strcpy(tempTableName, "#dom_curr");
                break;
            default:
                return(RET_GEN_ERR_INVARG);
        }

        /* search the sqlname_c of search key's format element */
    	if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
	    {
		    return(RET_MEM_ERR_ALLOC);
	    }

        /* search the sqlname_c of search key's format element */
    	if ((sFmtElt = ALLOC_DYNST(S_FmtElt)) == NULL)
	    {
            FREE_DYNST(admArg, Adm_Arg);
		    return(RET_MEM_ERR_ALLOC);
	    }

        SET_ENUM(admArg, Adm_Arg_EntDictId, GET_DICT(tascJobPtr, A_TascJob_EntityDictId));
        SET_ID(admArg, Adm_Arg_Id, GET_ID(fmtPtr, A_Fmt_Id));

	    if ((ret = DBA_Get2(FmtElt,
						    UNUSED,
						    Adm_Arg,
						    admArg,
						    S_FmtElt,
						    &sFmtElt,
						    DBA_SET_CONN|DBA_NO_CLOSE,
                            dbiConn,
						    UNUSED)) != RET_SUCCEED)
	    {
            FREE_DYNST(admArg, Adm_Arg);
            FREE_DYNST(sFmtElt, S_FmtElt);
		    return(ret);
	    }

        strcpy(searchKeyFieldStr, GET_SYSNAME(sFmtElt, S_FmtElt_SqlName));

        FREE_DYNST(admArg, Adm_Arg);
        FREE_DYNST(sFmtElt, S_FmtElt);

        if ((sqlBuff = (char *) CALLOC(2048, sizeof(char))) == NULL)
        {
            return(RET_MEM_ERR_ALLOC);
        }

		/* PMSTA-20159 - TEB - 150624 */
        std::string fullTableName = DdlGenDbi::getTableFullDbName(GET_CODE(tascJobTable, A_TascJobTable_DatabaseName),
                                                                  "",
                                                                  GET_CODE(tascJobTable, A_TascJobTable_TableName),
                                                                  EV_RdbmsVendor);

        sprintf(sqlBuff, "select pf.* from %s pf, %s tt where tt.id = pf.%s", /* PMSTA-20159 - TEB - 150624 */
				fullTableName.c_str(),  /* PMSTA-20159 - TEB - 150624 */
                tempTableName,
                searchKeyFieldStr);

        ret = dbiConn.sendCommand(sqlBuff);
        DBA_FilterMsgInfos(dbiConn, &msgResult);

        if (ret != RET_SUCCEED)
        {
            FREE(sqlBuff);
            return(ret);
        }

        /* allocate record and bind it */
	    entityInfo = DBA_GetEntityBySqlName(GET_CODE(tascJobTable, A_TascJobTable_FmtCd));

	    dynSt = GET_EDITGUIST(entityInfo->objectEn);

	    if((bindSt = ALLOC_DYNST(dynSt) ) == NULLDYNST)
        {
            FREE(sqlBuff);
            return(RET_MEM_ERR_ALLOC);
        }

        if (dbiConn.bindRecvDynSqlEntity(objectEnum, dynSt, bindSt) != RET_SUCCEED)
        {
            FREE(sqlBuff);
            FREE_DYNST(bindSt, dynSt);
            return(RET_DBA_ERR_SYBBIND);
        }

        /* read all records and store them into hierarchy */
        if ((ret = dbiConn.readObjectData(dynSt,
                                          bindSt,
                                          &dataNbr,
                                          &dataTab)) != RET_SUCCEED)
        {
            dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
            dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

            FREE(sqlBuff);
            FREE_DYNST(bindSt, dynSt);
            return(ret);
        }

        ret = DBA_AddHierRecordList(hierHead, dataTab, dataNbr, dynSt, TRUE);
        FREE(sqlBuff);
        FREE_DYNST(bindSt, dynSt);
        FREE(dataTab);
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadTascJobData()
**
**  Description :   Load all TSL's data define in tasc_job_table as input table
**
**  Arguments   :   argHierHeadPtr	hierarchy pointer
**					domainPtr		domain pointer
**
**  Return      :   RET_SUCCEED or error
**
**  Created		:   PMSTA13876 - DDV - 130815
**
*************************************************************************/
RET_CODE DBA_LoadTascJobData(DBA_HIER_HEAD_STP *argHierHeadPtr, DBA_DYNFLD_STP domainPtr, FLAG_T *calculationFlg)
{
	RET_CODE            ret=RET_SUCCEED;
	DBA_HIER_HEAD_STP	hierHead = NULL;
	DBA_DYNFLD_STP      tascJobSt = NULLDYNST;
	DBA_DYNFLD_STP      sTascJobTableSt = NULLDYNST;
	DBA_DYNFLD_STP      *aTascJobTableTab = NULLDYNSTPTR;
	int                 aTascJobTableNbr = 0, i;
	DBA_DYNFLD_STP      argument = NULLDYNST;
	DBA_DYNFLD_STP      sFmtSt = NULLDYNST, aFmtSt = NULLDYNST;
	DBA_DYNFLD_STP      *persistedJobTableTab = NULLDYNSTPTR;
    int                 persistedJobTableNbr = 0;

	MSG_StartFctTimerPmon("DBA_LoadPos");
	DbiConnection *dbiConn = DBA_GetDbiConnection();
	/* Get a free connection in the connection list */
	if (dbiConn == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

	/* If needed, create hierarchy */
	if ((*argHierHeadPtr) == NULL)
	{
		if ((*argHierHeadPtr = DBA_CreateHier())==NULL)    /* REF5239 - RAK - 001025 */
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			            "DBA_LoadTascJobData: Cannot create hierarchy");
			DBA_EndConnection(&dbiConn);
			return(RET_DBA_ERR_MD);
		}
	}

	hierHead = *argHierHeadPtr;

	/* Load TascJob record and store it into hierarchy */
	if ((tascJobSt = ALLOC_DYNST(A_TascJob)) == NULL)
	{
		DBA_EndConnection(&dbiConn);
		return(RET_MEM_ERR_ALLOC);
	}
	if ((ret = DBA_Get2(TascJob,
						UNUSED,
						A_Domain,
						domainPtr,
						A_TascJob,
						&tascJobSt,
						DBA_SET_CONN|DBA_NO_CLOSE,
						(int*)&dbiConn->getId(),
						UNUSED)) != RET_SUCCEED)
	{
		FREE_DYNST(tascJobSt, A_TascJob);
        DBA_EndConnection(&dbiConn);
		return(ret);
	}

	DBA_AddHierRecord(hierHead, tascJobSt, A_TascJob, TRUE, HierAddRec_ForceInsert);

	/* Load all TascJobTable for current job and store them into hierarchy */
	if((sTascJobTableSt = ALLOC_DYNST(S_TascJobTable)) == NULL)
	{
		DBA_EndConnection(&dbiConn);
		return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(sTascJobTableSt, S_TascJobTable_JobId, (ID_T)atof(GET_NAME(domainPtr, A_Domain_JobReference)));

	if ((ret = DBA_Select2(TascJobTable,
                           UNUSED,
                           S_TascJobTable,
                           sTascJobTableSt,
                           A_TascJobTable,
                           &aTascJobTableTab,
                           DBA_SET_CONN|DBA_NO_CLOSE,
                           UNUSED,
                           &aTascJobTableNbr,
						   (int*)&dbiConn->getId(),
                           UNUSED)) != RET_SUCCEED )
	{
		FREE_DYNST(sTascJobTableSt, S_TascJobTable);
		MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "TascJobTable select failed");
        DBA_EndConnection(&dbiConn);
		return(ret);
	}

	FREE_DYNST(sTascJobTableSt, S_TascJobTable);

    DBA_AddHierRecordList(hierHead, aTascJobTableTab, aTascJobTableNbr, A_TascJobTable, TRUE);

    DBA_SetHierLnkUsed(hierHead, A_TascJobTable, A_TascJobTable_TascJob_Ext);
    if ((ret = DBA_MakeSpecRecLinks(hierHead,
                                    A_TascJobTable,
                                    A_TascJobTable_TascJob_Ext)) != RET_SUCCEED)
    {
        DBA_EndConnection(&dbiConn);
        return(ret);
    }

    /* If tasc_job_portfolio table has been given, check if persisted data must be loaded */
    if (IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE &&
        aTascJobTableNbr > 0)
    {
        if ((persistedJobTableTab = (DBA_DYNFLD_STP *) CALLOC(aTascJobTableNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            FREE(aTascJobTableTab);
            DBA_EndConnection(&dbiConn);
            return(RET_MEM_ERR_ALLOC);
        }

        if((sFmtSt = ALLOC_DYNST(S_Fmt)) == NULL)
	    {
            FREE(aTascJobTableTab);
            FREE(persistedJobTableTab);
            DBA_EndConnection(&dbiConn);
		    return(RET_MEM_ERR_ALLOC);
	    }

        for (i=0; i < aTascJobTableNbr; i++)
        {
		    SET_CODE(sFmtSt, S_Fmt_Cd, GET_CODE(aTascJobTableTab[i], A_TascJobTable_FmtCd));

            if((aFmtSt = ALLOC_DYNST(A_Fmt)) == NULL)
	        {
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
        	    FREE_DYNST(sFmtSt, S_Fmt);
                DBA_EndConnection(&dbiConn);
		        return(RET_MEM_ERR_ALLOC);
	        }

		    if (DBA_Get2(Fmt, UNUSED, S_Fmt, sFmtSt, A_Fmt, &aFmtSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		    {
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
        	    FREE_DYNST(sFmtSt, S_Fmt);
                DBA_EndConnection(&dbiConn);
			    return(RET_DBA_ERR_INVALID_FORMAT);
		    }

            if (GET_ENUM(aFmtSt, A_Fmt_NatEn) == FmtNat_Persisted)
		    {
                persistedJobTableTab[persistedJobTableNbr] = aTascJobTableTab[i];
                persistedJobTableNbr++;
		    }

            if (DBA_AddHierRecord(hierHead, aFmtSt, A_Fmt, TRUE, HierAddRec_ForceInsert) != RET_SUCCEED)
            {
        	    FREE_DYNST(aFmtSt, A_Fmt);
            }
	    }

	    FREE_DYNST(sFmtSt, S_Fmt);

        if (persistedJobTableNbr >0)
        {
            /* Make links from A_TascJobTable to A_Fmt */
            DBA_SetHierLnkUsed(hierHead, A_TascJobTable, A_TascJobTable_Fmt_Ext);
            if ((ret = DBA_MakeSpecRecLinks(hierHead,
                                            A_TascJobTable,
                                            A_TascJobTable_Fmt_Ext)) != RET_SUCCEED)
	        {
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
                DBA_EndConnection(&dbiConn);
                return(ret);
	        }

	        if ((ret = DBA_CreateTempTables(*dbiConn, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID | DOM_STRAT | DOM_THIRD_CURR)) != RET_SUCCEED)
	        {
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
                DBA_EndConnection(&dbiConn);
		        return(ret);
	        }

	        /* create and fill temporary tables like #dom_port or #dom_instr */
	        if ((argument =  ALLOC_DYNST(Arg_Test)) == NULLDYNST)
	        {
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
                DBA_EndConnection(&dbiConn);
		        return(RET_MEM_ERR_ALLOC);
	        }

            SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));

            if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

	        SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_LoadPF);

            if ((ret = DBA_Notif2(TascJob,
					            UNUSED,
					            Arg_Test,
					            argument,
					            DBA_SET_CONN|DBA_NO_CLOSE,
								*dbiConn,
					            UNUSED)) != RET_SUCCEED)
            {
		        FREE_DYNST(argument, Arg_Test);
                FREE(aTascJobTableTab);
                FREE(persistedJobTableTab);
	            DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId));
	            DBA_EndConnection(&dbiConn);
	            return(ret);
            }

	        FREE_DYNST(argument, Arg_Test);

            /* Load all data linked to persisted format */
   	        for (i=0; i<persistedJobTableNbr; i++)
	        {
				DBA_LoadOneTascJobInputTable(persistedJobTableTab[i], hierHead, *dbiConn);
            }
        }
        FREE(persistedJobTableTab);
    }
    FREE(aTascJobTableTab);

    DBA_EndConnection(&dbiConn);
	return(ret);
}

/************************************************************************
**   END  dbapos.c                                             ODYSSEY **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINEXCH_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "ope.h"        /* REF4249 - SSO - 000926 */
#include "conv.h"       /* REF4249 - SSO - 000926 */

/************************************************************************
**      External entry points
**
**  FIN_EuroExchRate() 					Get exchange rate between two currencies with EURO treatment.
**  FIN_ExchAmt()						Convert an amount to underlying currency.
**  FIN_ExchAmtEuro() 					Convert an amount to underlying currency verifyin EURO.
**  FIN_ExchRateFmt()					Format an exchange rate according to market standards.
**  FIN_GetExchRate() 					Get exchange between two currencies, using optional parameters.
**  FIN_InverseExchRate() 				It is possible to store the exchange rates in the database.
**  FIN_IsExchRateValid()				Check if exchange rate is valid for a valuation rule.
**  FIN_MergeExchRate()					Merge to exchange rate.
**  FIN_SelDfltExchRate()				Search the exchange rate using definiton from appl_param.
**  FIN_SelectExchRate()				Select all exchange rate for a currency.
**	FIN_GetExchValRuleIdInDomPPSPtf()	Get exchange valuation rule identifier in domain, pps or portfolio
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**  FIN_CurrEuroConvInfo()	Verify if currency is in euro and return euro conversion info.
**  FIN_CurrEuroExchRate() 	Get currency exchange rate(s) with EURO treatment.
**  FIN_EuroCrossExchRate()	Get exchange rate agains cross , verify if cross is 'in'.
**  FIN_InCurrFixedExchRate() 	Use euro exchange stored in curr. or select euro exchange.
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
typedef struct {
	DATETIME_T	euroDate;
	EXCHANGE_T	euroExch;
} FIN_CURREURO_ST, *FIN_CURREURO_STP;

/* REF4184 SME */

STATIC RET_CODE FIN_CurrEuroConvInfo(ID_T, FIN_CURREURO_STP),		/* REF1177 */
		        FIN_CurrEuroExchRate(ID_T, ID_T, ID_T, DATETIME_T, DATETIME_T,
				                    FIN_EXCHARG_STP, FIN_EXCHTABARG_STP, FIN_EXCHOUT_STP),
		        FIN_InCurrFixedExchRate(ID_T, ID_T, FIN_CURREURO_STP, char, FIN_EXCHARG_STP,
			                        FIN_EXCHTABARG_STP, FIN_EXCHOUT_STP),
		        FIN_EuroCrossExchRate(ID_T, ID_T, DATETIME_T, char, FIN_EXCHARG_STP,
				                    FIN_EXCHTABARG_STP, FIN_EXCHOUT_STP);

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    :   FIN_EuroExchRate()
**
**  Description :   Get exchange rate between two currencies with EURO treatment.
**
**  Arguments   :   srcCurrId       source currency id
**                  trgtCurrId      target currency id
**                  euroDate        euro conversion date
**                  refDatetime     valuation date
**                  exchArgStp      default rate arguments (type, market, provider and flags)
**		            exchTabArgStp   input rates arrays
**                  exchOutStp      output rates and arrays
**
**  Return      :   RET_SUCCEED or error code, exchOutStp is filled.
**
**  Creation    :   REF1177 - RAK - 980130
**  Modif.      :   REF2978 - RAK - 981109
**
*************************************************************************/
RET_CODE FIN_EuroExchRate(ID_T                srcCurrId,
			              ID_T                trgtCurrId,
			              ID_T                *crossCurrId,
			              DATETIME_T          euroDate,
			              DATETIME_T          refDateTime,
			              FIN_EXCHARG_STP     exchArgStp,
			              FIN_EXCHTABARG_STP  exchTabArgStp,
			              FIN_EXCHOUT_STP     exchOutStp)
{
	int		        svNbr=0;
	char		    useInExchFlg=FALSE;
	DBA_DYNFLD_STP  *svExchTab=NULL;
	DATETIME_T	    exchDate;
	ID_T		    euroCurrId, currId = (ID_T) 0;
	FIN_CURREURO_ST	currEuroInfo;
	RET_CODE	    ret=RET_SUCCEED;

	memset(&currEuroInfo, 0, sizeof(FIN_CURREURO_ST));
	memset(&exchDate,     0, sizeof(DATETIME_T));

	GEN_GetApplInfo(ApplEuroCurrId, &euroCurrId);

	/* -------------------------- */
	/* Cross currency is now euro */
	/* -------------------------- */
	if (*crossCurrId == euroCurrId)
	{
/* REF5607 - RAK - 010123 */
#if 0
        if (refDateTime.date < euroDate.date)	/* REFXXXX */
		{
		    if (srcCurrId == euroCurrId || trgtCurrId == euroCurrId)
		    {
		        if (srcCurrId == euroCurrId)
		        {
			        if ((ret = FIN_CurrEuroConvInfo(trgtCurrId, &currEuroInfo)) != RET_SUCCEED)
				        return(ret);
		        }

		        if (trgtCurrId == euroCurrId)
		        {
			        if ((ret = FIN_CurrEuroConvInfo(srcCurrId, &currEuroInfo)) != RET_SUCCEED)
				        return(ret);
		        }
			}

		    /* 'in' currency, use fixed rate between this currency and euro */
		    if (currEuroInfo.euroDate.date != 0)
			{
				exchDate.date = euroDate.date;
				useInExchFlg = TRUE;
			}
			else
			{
				exchDate.date = refDateTime.date;
				GEN_GetApplInfo(ApplOldExchUnderCurrId, crossCurrId);
				useInExchFlg = FALSE;
			}

			if (srcCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Src;
			    if (useInExchFlg == FALSE)
			    {
			        svNbr     = exchTabArgStp->exchRateNbrSrcIn;
			        svExchTab = exchTabArgStp->exchRateTabSrcIn;
			        exchTabArgStp->exchRateNbrSrcIn = 0;
			        exchTabArgStp->exchRateTabSrcIn = NULL;
			    }

			    /* REFXXX */
			    ret = FIN_CurrEuroExchRate(srcCurrId, *crossCurrId, euroCurrId,
						                    exchDate, euroDate, exchArgStp,
						                    exchTabArgStp, exchOutStp);

			    if (useInExchFlg == FALSE)
			    {
			        exchTabArgStp->exchRateNbrSrcIn = svNbr;
			        exchTabArgStp->exchRateTabSrcIn = svExchTab;
			    }
			}

	        if (ret != RET_SUCCEED)
		        return(ret);

			if (trgtCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Dest;
			    if (useInExchFlg == FALSE)
			    {
			        svNbr     = exchTabArgStp->exchRateNbrDestIn;
			        svExchTab = exchTabArgStp->exchRateTabDestIn;
			        exchTabArgStp->exchRateNbrDestIn = 0;
			        exchTabArgStp->exchRateTabDestIn = NULL;
			    }

			    /* REFXXX */
			    ret = FIN_CurrEuroExchRate(trgtCurrId, *crossCurrId, euroCurrId,
						       exchDate, euroDate, exchArgStp,
						       exchTabArgStp, exchOutStp);

			    if (useInExchFlg == FALSE)
			    {
			        exchTabArgStp->exchRateNbrDestIn = svNbr;
			        exchTabArgStp->exchRateTabDestIn = svExchTab;
			    }
			}
		}
#endif
        /* ------------------------------------------------------------------- */
		/* USD/BEF, USD/CHF, ... before euro date, use old underlying currency */
		/* ------------------------------------------------------------------- */
        ID_T                oldExchUnderCurrId=0;
        FIN_CURREURO_ST     oldUnderCurrInfo;
        DATE_T              testEuroDate;

        memset(&oldUnderCurrInfo, 0, sizeof(FIN_CURREURO_ST));

        GEN_GetApplInfo(ApplOldExchUnderCurrId, &oldExchUnderCurrId);

        if (oldExchUnderCurrId > 0)
        {
            if ((ret = FIN_CurrEuroConvInfo(oldExchUnderCurrId, &oldUnderCurrInfo)) == RET_SUCCEED &&
                 oldUnderCurrInfo.euroDate.date != 0)
			    testEuroDate = oldUnderCurrInfo.euroDate.date;
            else
                testEuroDate = euroDate.date;
        }
        else
            testEuroDate = euroDate.date;

        if (refDateTime.date < testEuroDate)	/* REFXXXX */
		{
            if (refDateTime.date < euroDate.date &&
                (srcCurrId == euroCurrId || trgtCurrId == euroCurrId))
		    {
                exchDate.date = euroDate.date;
				useInExchFlg = TRUE;
			}
            else
            {
                exchDate.date = refDateTime.date;
				GEN_GetApplInfo(ApplOldExchUnderCurrId, crossCurrId);
				useInExchFlg = FALSE;
            }

            if (srcCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Src;
			    if (useInExchFlg == FALSE)
			    {
			        svNbr     = exchTabArgStp->exchRateNbrSrcIn;
			        svExchTab = exchTabArgStp->exchRateTabSrcIn;
			        exchTabArgStp->exchRateNbrSrcIn = 0;
			        exchTabArgStp->exchRateTabSrcIn = NULL;
			    }

			    /* REFXXX */
			    ret = FIN_CurrEuroExchRate(srcCurrId, *crossCurrId, euroCurrId,
						                    exchDate, euroDate, exchArgStp,
						                    exchTabArgStp, exchOutStp);

			    if (useInExchFlg == FALSE)
			    {
			        exchTabArgStp->exchRateNbrSrcIn = svNbr;
			        exchTabArgStp->exchRateTabSrcIn = svExchTab;
			    }
			}

	        if (ret != RET_SUCCEED)
		        return(ret);

			if (trgtCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Dest;
			    if (useInExchFlg == FALSE)
			    {
			        svNbr     = exchTabArgStp->exchRateNbrDestIn;
			        svExchTab = exchTabArgStp->exchRateTabDestIn;
			        exchTabArgStp->exchRateNbrDestIn = 0;
			        exchTabArgStp->exchRateTabDestIn = NULL;
			    }

			    /* REFXXX */
			    ret = FIN_CurrEuroExchRate(trgtCurrId, *crossCurrId, euroCurrId,
						       exchDate, euroDate, exchArgStp,
						       exchTabArgStp, exchOutStp);

			    if (useInExchFlg == FALSE)
			    {
			        exchTabArgStp->exchRateNbrDestIn = svNbr;
			        exchTabArgStp->exchRateTabDestIn = svExchTab;
			    }
			}
        }
		/* -------------------------------------------------------- */
		/* USD/EURO, BEF/EURO, ... and USD/BEF after euro date, ... */
		/* -------------------------------------------------------- */
		else
		{
			if (srcCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Src;
			    ret = FIN_CurrEuroExchRate(srcCurrId, *crossCurrId, euroCurrId,
						       refDateTime, euroDate, exchArgStp,
						       exchTabArgStp, exchOutStp);
			}

			if (ret != RET_SUCCEED)
		        	return(ret);

			if (trgtCurrId != *crossCurrId)
			{
			    exchOutStp->srcDestEn = SrcDest_Dest;
			    ret = FIN_CurrEuroExchRate(trgtCurrId, *crossCurrId, euroCurrId,
						       refDateTime, euroDate, exchArgStp,
						       exchTabArgStp, exchOutStp);
			}
		}
	}
	/* -------------------------- */
	/* Cross currency is not euro */
	/* -------------------------- */
	else
	{
		/* If one of the currency is EURO and other is a converted 'in' currency, */
		/* search exchange at fixed date                                          */
		if (srcCurrId == euroCurrId || trgtCurrId == euroCurrId)
		{
		    if (srcCurrId == euroCurrId)
		    {
			    if ((ret = FIN_CurrEuroConvInfo(trgtCurrId, &currEuroInfo)) != RET_SUCCEED)
				    return(ret);

			    exchOutStp->srcDestEn = SrcDest_Dest;
			    currId                = trgtCurrId;
		    }

		    if (trgtCurrId == euroCurrId)
		    {
			    if ((ret = FIN_CurrEuroConvInfo(srcCurrId, &currEuroInfo)) != RET_SUCCEED)
				    return(ret);

			    exchOutStp->srcDestEn = SrcDest_Src;
			    currId                = srcCurrId;
		    }

		    /* 'in' currency, use fixed rate between this currency and euro */
	    	if (currEuroInfo.euroDate.date != 0 && 	/* REF2978 */
		        (euroDate.date == currEuroInfo.euroDate.date ||
		         (currEuroInfo.euroDate.date > euroDate.date &&
		          refDateTime.date >= currEuroInfo.euroDate.date)))
		    {
			    *crossCurrId = euroCurrId;
			    if (refDateTime.date < euroDate.date)
				    refDateTime.date = euroDate.date;

			    ret = FIN_CurrEuroExchRate(currId, *crossCurrId, euroCurrId,
					                        refDateTime, euroDate, exchArgStp,
						                    exchTabArgStp, exchOutStp);
			    return(ret);	/* Fixed rate is returned and cross currency is forced to EURO. */
		    }

			/* REF3176 - RAK - 990330 - For out currency too, */
			/* so both exchange will be take at the same date.  */
			if (refDateTime.date < euroDate.date)
				refDateTime.date = euroDate.date;
		}

		/* Other cases (in/out, out/EURO, ...) */
		if (srcCurrId != *crossCurrId)
		{
			exchOutStp->srcDestEn = SrcDest_Src;
			ret = FIN_CurrEuroExchRate(srcCurrId, *crossCurrId, euroCurrId,
					                    refDateTime, euroDate, exchArgStp,
						                exchTabArgStp, exchOutStp);
		}

		if (ret != RET_SUCCEED)
			return(ret);

		if (trgtCurrId != *crossCurrId)
		{
			exchOutStp->srcDestEn = SrcDest_Dest;
			ret = FIN_CurrEuroExchRate(trgtCurrId, *crossCurrId, euroCurrId,
					                    refDateTime, euroDate, exchArgStp,
						                exchTabArgStp, exchOutStp);
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ExchAmt()
**
**  Description :   Convert an amount to underlying currency.
**
**  Arguments   :   exchDate      exchange date
**                  srcCurrId     source currency identifier
**                  trgtCurrId    target currency identifier
**                  valRuleId     id of valuation rule to use
**                  valRulePtr    pointer on valuation rule
**		            exchArgStp
**                    tpId        type identifier (optional)
**                    marketId    market identifier (optional)
**                    directFlg   direct exchange flag
**                    exchRetMet  exchange rate retrieval method
**                    srcAmt      amount in currency to convert into underlying
**                                currency
**                  frcdExch      pointer on forced exchange rate pointer
**                                can be NULL
**                  exchAmtPtr    pointer on exchange amount
**                  exchPtr       pointer on exchange rate used, can be NULL
**
**  Return      :   RET_SUCCEED        exchAmtPtr is exchanged amout and
**                                     exchPtr    is used exchange rate
**                  RET_GEN_ERR_INVARG exchAmtPtr is received amount
**                  RET_MEM_ERR_ALLOC  exchPtr    is 1
**                  RET_DBA_ERR_
**
**  Modif.	:   REF2313 - RAK - 980608
**  Modif.	:   REF2580 - SSO - 980727
**
*************************************************************************/
RET_CODE FIN_ExchAmt(DATETIME_T      exchDate,
		             ID_T            srcCurrId,
		             ID_T            trgtCurrId,
		             ID_T            valRuleId,		    /* REF2313 */
		             DBA_DYNFLD_STP  inputValRulePtr,	/* REF2313 */
					 DBA_DYNFLD_STP  posPtr,			/* PMSTA01649 - TGU - 070405 */
		             FIN_EXCHARG_STP exchArgStp,	    /* REF2313 */
		             EXCHANGE_T      *frcdExch,
		             AMOUNT_T        *exchAmtPtr,
		             EXCHANGE_T      *exchPtr)
{
	EXCHANGE_T 	    exch;
	DATETIME_T	    euroDate;
	FLAG_T		    euroCrossCurrFlg;
	FIN_CURREURO_ST	srcEuroInfo, trgtEuroInfo;
	ID_T		    euroCurrId;
	char		    triangulation;
	RET_CODE   	    ret;

	memset(&euroDate, 0, sizeof(DATETIME_T));

	/* Init to default values */
	*exchAmtPtr = exchArgStp->srcAmt;
	if (exchPtr != NULL) *exchPtr = 1.0;

	/* REF2313 - RAK - 980615 */
	/* EURO_CONV_DATE is different from NULL and is lower or equal to the system date. */
	/* EURO_CROSS_CURRENCY_FLAG is TRUE                                                */
	/* source and target currencies are both 'in' currencies.                          */
	/* date of the conversion is posterior to the EURO_CONV_DATE                       */
	triangulation = FALSE;
	if (DBA_GetEuroConversionDate(&euroDate.date, DBA_GetConnectNoFromExchArg(exchArgStp)) == TRUE && /* REF2580 - SSO - 980727 */
	    exchDate.date >= euroDate.date &&
	    srcCurrId != trgtCurrId)
	{
		GEN_GetApplInfo(ApplEuroCrossCurrFlg, &euroCrossCurrFlg);
		if (euroCrossCurrFlg == TRUE)
		{
			/* Get currency euro conversion date. */
			if ((ret = FIN_CurrEuroConvInfo(srcCurrId, &srcEuroInfo)) != RET_SUCCEED)
				return(ret);

			if ((ret = FIN_CurrEuroConvInfo(trgtCurrId, &trgtEuroInfo))!=RET_SUCCEED)
				return(ret);

			/* Two "in" currencies, use euro amount */
			if ((srcEuroInfo.euroDate.date != 0 &&
		         srcEuroInfo.euroDate.date <= exchDate.date) &&
			    (trgtEuroInfo.euroDate.date != 0 &&
 			     trgtEuroInfo.euroDate.date <= exchDate.date))
				triangulation = TRUE;
			else
			{
			    /* One currency is "in", the other is EURO, force */
			    /* FIN_GetExchRate() call. (ignore frctExch)      */
			    GEN_GetApplInfo(ApplEuroCurrId, &euroCurrId);
			    if ((srcCurrId == euroCurrId &&
				    (trgtEuroInfo.euroDate.date != 0 &&
			         trgtEuroInfo.euroDate.date <= exchDate.date)) ||
				    (trgtCurrId == euroCurrId &&
				    (srcEuroInfo.euroDate.date != 0 &&
        			 srcEuroInfo.euroDate.date <= exchDate.date)))
	    			frcdExch = NULL;
			}
		}
	}

	if (triangulation == TRUE)
	{
		RNDUNIT_ENUM 	unit;
		RNDRULE_ENUM 	rule;
		EXCHANGE_T	    srcExch=1.0;
		AMOUNT_T	    euroAmt;

		GEN_GetApplInfo(ApplEuroCurrId, &euroCurrId);

		/* Conversion of the amount into the EURO currency     */
		/* using the source currency/euro fixed exchange rate. */
		ret = FIN_GetExchRate(exchDate, srcCurrId, euroCurrId,
				              valRuleId, inputValRulePtr, posPtr, exchArgStp,
				              &srcExch);		/* PMSTA01649 - TGU - 070406 */

		euroAmt = exchArgStp->srcAmt * srcExch;

		/* Rounding of the resulting EURO amount using the values of the          */
		/* EURO_CROSS_ROUND_RULE and the EURO_CROSS_ROUND_UNIT system parameters. */
		GEN_GetApplInfo(ApplEuroCrossRndRuleEn, &rule);
		GEN_GetApplInfo(ApplEuroCrossRndUnitEn, &unit);
		euroAmt = TLS_RoundEnum(euroAmt, unit, rule);

		/* Conversion of the resulting EURO amount into the target currency */
		/* using the EURO/target currency fixed exchange rate               */
		ret = FIN_GetExchRate(exchDate, euroCurrId, trgtCurrId,
				              valRuleId, inputValRulePtr, posPtr, exchArgStp,
				              &exch);		/* PMSTA01649 - TGU - 070406 */

		*exchAmtPtr = euroAmt * exch;

		/* Rounding of the resulting target amount using the rounding */
		/* rule and the rounding unit of the target currency.         */
	    *exchAmtPtr = CAST_AMOUNT((*exchAmtPtr), trgtCurrId);

	    /* Keep used exchange rate */	/* ?? */
	    if (exchPtr != NULL)
		{
		    if (CMP_AMOUNT((exchArgStp->srcAmt), 0.0, srcCurrId) != 0)
			    *exchPtr = (*exchAmtPtr) / (exchArgStp->srcAmt);
		    else
		        *exchPtr = srcExch * exch;
		}
	}
	else
	{
	    if (frcdExch != NULL)
	    {
		    /* Use forced exchange rate */
		    exch = *frcdExch;
	    }
	    else
	    { 	/* Search exchange rate */
		    ret = FIN_GetExchRate(exchDate, srcCurrId, trgtCurrId,
				                  valRuleId, inputValRulePtr, posPtr, exchArgStp,
				                  &exch);		/* REF2313 */	/* PMSTA01649 - TGU - 070406 */

    		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			    return(ret);

	    }

	    /* Keep used exchange rate */
	    if (exchPtr != NULL) *exchPtr = exch;

	    /* Rounding amount in target currency */
	    *exchAmtPtr = (exchArgStp->srcAmt) * exch;
	    *exchAmtPtr = CAST_AMOUNT(*exchAmtPtr, trgtCurrId);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ExchAmtEuro()
**
**  Description :   Convert an amount to underlying currency verifyin EURO.
**
**  Arguments   :   exchDate      exchange date
**                  srcCurrId     source currency identifier
**                  trgtCurrId    target currency identifier
**                  valRuleId     id of valuation rule to use
**                  valRulePtr    pointer on valuation rule
**		            exchArgStp
**                    tpId        type identifier (optional)
**                    marketId    market identifier (optional)
**                    directFlg   direct exchange flag
**                    exchRetMet  exchange rate retrieval method
**                    srcAmt      amount in currency to convert into underlying
**                                currency
**                  frcdExch      pointer on forced exchange rate pointer
**                                can be NULL
**                  exchAmtPtr    pointer on exchange amount
**                  exchPtr       pointer on exchange rate used, can be NULL
**
**  Return      :   RET_SUCCEED        exchAmtPtr is exchanged amout and
**                                     exchPtr    is used exchange rate
**                  RET_GEN_ERR_INVARG exchAmtPtr is received amount
**                  RET_MEM_ERR_ALLOC  exchPtr    is 1
**                  RET_DBA_ERR_
**
**  Creation	:   REF1747 - RAK - 980422
**  Modif.  	:   REF2313 - RAK - 980610
**  Modif.  	:   REF2610 - RAK - 980810
**
*************************************************************************/
RET_CODE FIN_ExchAmtEuro(DATETIME_T      exchDate,
			             ID_T            refCurrId,
		                 ID_T            srcCurrId,
		                 ID_T            trgtCurrId,
		                 ID_T            valRuleId,		    /* REF2313 */
		                 DBA_DYNFLD_STP  inputValRulePtr,	/* REF2313 */
			             FIN_EXCHARG_STP exchArgStp,		/* REF2312 */
		                 DBA_DYNFLD_STP  posPtr,
		                 EXCHANGE_T      *frcdExch,
		                 AMOUNT_T        *exchAmtPtr,
		                 EXCHANGE_T      *exchPtr)
{
	RET_CODE	    ret;
	DATETIME_T	    euroDate;
	ID_T		    euroCurrId, currId;
	DBA_DYNFLD_STP	ptfPtr=NULL;
	EXCHANGE_T	    currExch=0.0, crossExch=0.0;
	char		    crossPtfFlg;
	FIN_CURREURO_ST	crossEuroInfo;

	if (GET_EXTENSION_PTR(posPtr, ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_A_Ptf_Ext))) == NULL)
	{
		/* ?? consolidation ?? */
	    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO,
                     "FIN_ExchAmtEuro", ExtPos_A_Ptf_Ext);
		return(RET_DBA_ERR_HIER);
	}

	memset(&euroDate, 0, sizeof(DATETIME_T));
	GEN_GetApplInfo(ApplEuroCurrId, &euroCurrId);

	/* If EURO is done and reference and portfolio currencies are EURO */
	/* and valorisation date is before euro conversion date            */
	/* and portfolio is converted in euro (OldCurrId and CurrConvDate are set) */
	/* -> use old portfolio currency  to get exchange                  */
	/* REF2610 - For others portfolio, use portfolio currency to get   */
	/*           cross exchange, except for 'in' currencies.           */
	/* REF2610 - Old code
	if (DBA_GetEuroConversionDate(&euroDate.date,
				      DBA_GetConnectNoFromExchArg(exchArgStp)) == TRUE &&
	    refCurrId == euroCurrId &&
	    (srcCurrId == euroCurrId || trgtCurrId == euroCurrId) &&
	    DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_ExtPosDate), euroDate) < 0 &&
	    GET_ID(ptfPtr, A_Ptf_CurrId) == euroCurrId &&
	    IS_NULLFLD(ptfPtr, A_Ptf_OldCurrId) == FALSE &&
	    IS_NULLFLD(ptfPtr, A_Ptf_CurrConvDate) == FALSE) */

	crossPtfFlg = FALSE;
	if (DBA_GetEuroConversionDate(&euroDate.date,
				                  DBA_GetConnectNoFromExchArg(exchArgStp)) == TRUE &&
	    refCurrId == euroCurrId &&
	    (srcCurrId == euroCurrId || trgtCurrId == euroCurrId) &&
	    DATETIME_CMP(exchDate, euroDate) < 0)
	{
		if (srcCurrId == euroCurrId)
			 ret = FIN_CurrEuroConvInfo(trgtCurrId, &crossEuroInfo);
		else
			 ret = FIN_CurrEuroConvInfo(srcCurrId, &crossEuroInfo);

		if (ret != RET_SUCCEED)
			return(ret);

		/* "out" currency */
		if (crossEuroInfo.euroDate.date == 0 ||
		    crossEuroInfo.euroDate.date > exchDate.date)
			 crossPtfFlg = TRUE;
	}

	if (crossPtfFlg == TRUE)
	{
		ID_T crossCurrId;

		if (srcCurrId == euroCurrId)
			currId = trgtCurrId;
		else
			currId = srcCurrId;

		if (IS_NULLFLD(ptfPtr, A_Ptf_OldCurrId) == TRUE)
			crossCurrId = GET_ID(ptfPtr, A_Ptf_CurrId);
		else
			crossCurrId = GET_ID(ptfPtr, A_Ptf_OldCurrId);

		ret = FIN_GetExchRate(exchDate, currId, crossCurrId,
				              valRuleId, inputValRulePtr, posPtr, exchArgStp,
				              &currExch);	/* REF2313 */ /* PMSTA01649 - TGU - 070330 */

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			return(ret);

		ret = FIN_GetExchRate(exchDate, crossCurrId, euroCurrId,
				              valRuleId, inputValRulePtr, posPtr, exchArgStp,
				              &crossExch);	/* REF2313 */ /* PMSTA01649 - TGU - 070330 */

    	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			return(ret);

		/* Compute exchange rate between currency and EURO */
		currExch *= crossExch;

		if (srcCurrId == euroCurrId && CMP_EXCHANGE(currExch, 0.0) != 0)	/* ?? */
			currExch = 1.0/currExch;

		/* Call function with forced calculated exchange rate */
		ret =  FIN_ExchAmt(exchDate, srcCurrId, trgtCurrId,
                           valRuleId, inputValRulePtr, posPtr, exchArgStp,
                           &currExch, exchAmtPtr, exchPtr);	/* PMSTA01649 - TGU - 070405 */
	}
	else
	{
		/* Normal case */
		ret =  FIN_ExchAmt(exchDate, srcCurrId, trgtCurrId,
			               valRuleId, inputValRulePtr, posPtr, exchArgStp,
				           frcdExch, exchAmtPtr, exchPtr);	/* PMSTA01649 - TGU - 070405 */
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ExchRateFmt()
**
**  Description :   Format an exchange rate according to market standards.
**                  Use table Exchange rate format which indicates how one
**                  currrency is quoted against another and whether there
**                  is a conversion factor.
**
**  Arguments   :   currId        currency identifier
**                  underCurrId   underlying currency identifier
**                  exch          exchange rate to format
**                  fmtExchPtr    pointer on formated exchange rate
**
**  Return      :   RET_SUCCEED        fmtExchPtr is formated exchange
**                  RET_GEN_ERR_INVARG fmtExchPtr is received exchange
**                  RET_MEM_ERR_ALLOC
**                  RET_DBA_ERR_
**
*************************************************************************/
RET_CODE FIN_ExchRateFmt(ID_T       currId,
		                 ID_T       underCurrId,
		                 EXCHANGE_T exch,
		                 EXCHANGE_T *fmtExchPtr)
{
	DBA_DYNFLD_STP askFmt=NULL, exchFmt=NULL;

	*fmtExchPtr = exch;

	/* If same currencies, don't access database */
	if (currId == underCurrId)
		return(RET_SUCCEED); /* ?? */

	/* Read database informations */
	if ((askFmt = ALLOC_DYNST(S_ExchFmt)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((exchFmt = ALLOC_DYNST(A_ExchFmt)) == NULL)
	{
		FREE_DYNST(askFmt, S_ExchFmt);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(askFmt, S_ExchFmt_CurrId, currId);             /* mandatory */
	SET_ID(askFmt, S_ExchFmt_UnderCurrId, underCurrId);   /* mandatory */
	if (DBA_Get2(ExchFmt,UNUSED,S_ExchFmt,askFmt,A_ExchFmt,&exchFmt,
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		FREE_DYNST(askFmt, S_ExchFmt);
		FREE_DYNST(exchFmt, A_ExchFmt);
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ExchFmt));
	    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, entSqlName);
   		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(askFmt, S_ExchFmt);

	/* quantity in currency one is multiplied by factor when quoted  */
	/* against currency two. If the currencies are quoted in the op- */
	/* posite direction, first inverse direction and multiply after. */
	if (IS_NULLFLD(exchFmt, A_ExchFmt_Mult) == FALSE)
	{
		if (GET_FLAG(exchFmt, A_ExchFmt_InverseFlg) == TRUE)
			*fmtExchPtr = (1 / exch) * GET_NUMBER(exchFmt, A_ExchFmt_Mult);
		else
			*fmtExchPtr = exch * GET_NUMBER(exchFmt,A_ExchFmt_Mult);
	}

	FREE_DYNST(exchFmt, A_ExchFmt);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_GetExchRate()
**
**  Description :   Get exchange between two currencies, using optional
**                  parameters (type and market) and direct exchange rate
**                  flag.
**
**  Arguments   :   refDateTime   exchange date
**                  srcCurrId     source currency identifier
**                  trgtCurrId    target currency identifier
**                  valRuleId     id of valuation rule to use
**                  valRulePtr    pointer on valuation rule
**                  exchArgStp    exchange arguments (type, market, provider, flags, amount)
**                  exchPtr       pointer on exchange
**
**
**  Return      :   RET_SUCCEED         exchPtr is exchange between currencies
**                  RET_FIN_INFO_NOEXCH exchPtr is parameter exchange
**                  error code          exchPtr is parameter exchange
**
**  Modif.	:   REF2313 - RAK - 980609
**              REF9303 - 030915 - PMO : Implementation of Unicode
**
*************************************************************************/
RET_CODE FIN_GetExchRate(DATETIME_T      refDateTime,
		                 ID_T            srcCurrId,
		                 ID_T            trgtCurrId,
		                 ID_T            valRuleId,
						 DBA_DYNFLD_STP  inputValRulePtr,
						 DBA_DYNFLD_STP  posPtr,			/* PMSTA01649 - TGU - 070329 */
			             FIN_EXCHARG_STP exchArgStp,		/* REF2313 */
		                 EXCHANGE_T      *exch)
{
	DBA_DYNFLD_STP exchPtr=NULL;
	RET_CODE       ret;

	if ((exchPtr = ALLOC_DYNST(A_ExchRate)) == NULL)
	   	MSG_RETURN(RET_MEM_ERR_ALLOC);

	ret = DBA_GetExchRate(refDateTime, srcCurrId, trgtCurrId,
                          valRuleId, inputValRulePtr, posPtr, 0,    /* coefNatEn */ 	/* PMSTA01694 - TGU - 070406 */
			              (PTR) exchArgStp,				    /* REF2313 */
                          NULL, 0, NULL, 0, exchPtr, FALSE);

	*exch = GET_EXCHANGE(exchPtr, A_ExchRate_ExchRate);

	FREE_DYNST(exchPtr, A_ExchRate);

    /* REF4249 - SSO - 000926 error message */
    if (ret == RET_FIN_INFO_NOPRICE || ret == RET_FIN_INFO_NOEXCH)
    {
	    CODE_T	    currSrc, currTrgt;
        char        dateFmt[30], buf[30];
	    RET_CODE    ret2;  /* 000210 */

        if (srcCurrId != 0 && trgtCurrId != 0)
        {
            if ((ret2 = OPE_GetExchRateCodes(srcCurrId,
                                            trgtCurrId,
                                            &currSrc,
                                            &currTrgt)) != RET_SUCCEED)
            {
                sprintf((char*)&currSrc,"id %" szFormatId, srcCurrId);   /* DLA - PMSTA08801 - 100209 */
                sprintf((char*)&currTrgt,"id %" szFormatId, trgtCurrId); /* DLA - PMSTA08801 - 100209 */
            }
        }
        else
        {
            sprintf((char*)&currSrc,"id %" szFormatId, srcCurrId);   /* DLA - PMSTA08801 - 100209 */
            sprintf((char*)&currTrgt,"id %" szFormatId, trgtCurrId); /* DLA - PMSTA08801 - 100209 */
        }

        CONV_GetDfltDateFmt(DatetimeType, dateFmt, NULL);
        CONV_DataToStr(buf, sizeof(buf), DatetimeType, dateFmt, GET_DATETIME64(refDateTime), FALSE, TextConversion_None);  /* REF9303 - 030915 - PMO */

        MSG_SendMesg(RET_FIN_ERR_MISSING_EXCHRATE, 0, FILEINFO, buf, &currSrc, &currTrgt);
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_IsExchRateValid()
**
**  Description :   Check if exchange rate is valid for a valuation rule
**
**  Arguments   :   exchRatePtr   exchange rate structure pointer
**                  vatRuleEltPtr valuation rule element structure pointer
**
**  Return      :   TRUE if the exchange rate is valid and FALSE if not
**
**  Modif       :   DVP344 - XDI - 970307
**
*************************************************************************/
RET_CODE FIN_IsExchRateValid(DBA_DYNFLD_STP exchRatePtr,
		                     DBA_DYNFLD_STP valRuleEltPtr)
{
	DBA_DYNFLD_STP sTpPtr=NULL, aTpPtr=NULL;

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_TypeId) == TRUE)
	{
        if (GET_ID(valRuleEltPtr, A_ValRuleElt_TypeId) != 0)
        {
	        if ((sTpPtr = ALLOC_DYNST(S_Tp)) == NULL)
	            MSG_RETURN(RET_MEM_ERR_ALLOC);

	        if ((aTpPtr = ALLOC_DYNST(A_Tp)) == NULL)
	        {
	            FREE_DYNST(sTpPtr, S_Tp);
	            MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        SET_ID(sTpPtr, S_Tp_Id, GET_ID(valRuleEltPtr, A_ValRuleElt_TypeId));

	        if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr,
	                    UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	        {
	            SYSNAME_T entSqlName;
	            strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
	            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
	                        entSqlName, GET_ID(sTpPtr, S_Tp_Id));
	            FREE_DYNST(sTpPtr, S_Tp);
	            FREE_DYNST(aTpPtr, A_Tp);
	            return(RET_DBA_ERR_NODATA);
	        }
	        FREE_DYNST(sTpPtr, S_Tp);

            if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE && GET_SMALLINT(aTpPtr, A_Tp_Rank) == 0)
            {
	            FREE_DYNST(aTpPtr, A_Tp);
                return(FALSE);
            }
	        FREE_DYNST(aTpPtr, A_Tp);
	    }
	}
	else if (GET_ID(exchRatePtr, A_ExchRate_TpId) !=
	         GET_ID(valRuleEltPtr, A_ValRuleElt_TypeId))
		return(FALSE);

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_MktThirdId) == FALSE &&
	    GET_ID(exchRatePtr, A_ExchRate_MktThirdId) !=
	    GET_ID(valRuleEltPtr, A_ValRuleElt_MktThirdId))
		return(FALSE);

	if (IS_NULLFLD(valRuleEltPtr, A_ValRuleElt_ProviderThirdId) == FALSE &&
	    GET_ID(exchRatePtr, A_ExchRate_ThirdId) !=
	    GET_ID(valRuleEltPtr, A_ValRuleElt_ProviderThirdId))
		return(FALSE);

    /* Treat the business entity rule */ /* PMSTA-32140 CMILOS 081018 */
    if (GEN_IsMultiEntity())
    {
        /* set the owner_business_entity_id field index */
        FIELD_IDX_T     busEntityFldIdx = INVALID_FLD;
        DICT_ENTITY_STP exchRate = DBA_GetDictEntitySt(ExchRate);
        if (exchRate != nullptr && exchRate->ownerBusinessEntAttrStp != nullptr)
            busEntityFldIdx = exchRate->ownerBusinessEntAttrStp->progN;

        switch (GET_ENUM(valRuleEltPtr, A_ValRuleElt_BusEntityRuleEn))
        {
            case BusEntityRule_ConnectedBE:
                if (busEntityFldIdx != INVALID_FLD)
                {
                    if (GET_ID(exchRatePtr, busEntityFldIdx) != SYS_GetThreadCurrBusinessEntityId())
                        return(FALSE);
                }
                break;
            case BusEntityRule_Master:
                if (busEntityFldIdx != INVALID_FLD)
                {
                    if (GET_ID(exchRatePtr, busEntityFldIdx) != EV_MasterBusinessEntityId)
                        return(FALSE);
                }
                break;
            case BusEntityRule_Any:
                break;
            default:
                break;
        }
    }

	return(TRUE);
}

/************************************************************************
**
**  Function    :   FIN_SelDfltExchRate() old FIN_DefaultExchRate()
**
**  Description :   Search default exchange rate or select valid exchange rates.
**                  exchOutStp->defaultFlg is TRUE : search default.
**                  exchOutStp->srcDestEn is SrcDest_Src : update source array or rate.
**                  exchOutStp->srcDestEn is SrcDest_Dest : update destination array or rate.
**
**  Arguments   :   srcCurrId      source currency identifier
**                  destCurrId     destination currency identifier
**                  refDatetime    valuation date
**                  fixedDateFlg   TRUE : select rates on received date only
**                  exchArgStp     default rate arguments (type, market, provider and flags)
**		            exchTabArgStp  input rates arrays
**                  exchOutStp     output rates and arrays
**
**  Return      :   RET_SUCCEED or error code, exchOutStp is filled.
**
**  Modif       :   DVP344 - XDI - 970217
**  Modif       :   REF964 - RAK - 971203
**  Modif       :   REF1177 - RAK - 980202
**  Modif       :   REF2313 - RAK - 980609
**  Modif.      :   REF5248 - RAK - 001005
**
*************************************************************************/
RET_CODE FIN_SelDfltExchRate(ID_T                srcCurrId,
		                     ID_T                destCurrId,
			                 DATETIME_T          refDateTime,
			                 char                fixedDateFlg,	/* REF1177 */
			                 FIN_EXCHARG_STP     exchArgStp,	/* REF2313 */
			                 FIN_EXCHTABARG_STP  exchTabArgStp,
			                 FIN_EXCHOUT_STP     exchOutStp)
{
	DBA_DYNFLD_STP  *exchRateTab=NULL;
	DBA_DYNFLD_STP  *exchRateTabCpy=NULL;
	DBA_DYNFLD_STP  *exchRateTabCpySave=NULL;	
	DBA_DYNFLD_STP  exchPtr=NULL;
	DBA_DYNFLD_STP  *exchRateTabInput=NULL;
	int	            exchRateNbr = 0, i, attribute=NO_VALUE, priority, rankMin=9999;
	int	            *rankTab;
	char	        freeTabPtr=FALSE;
	FLAG_T	        datePriorityFlg, nextPriority, allocTab, keepRankZero=FALSE;
	int	            nbOk, nbOkSave, firstExchRate, exchRateNbrInput;
	NAME_T	        exchRateSelOrder;
	RET_CODE        ret=RET_SUCCEED;
    FIELD_IDX_T     busEntityFldIdx = INVALID_FLD; /* PMSTA-32142 CMILOS 130918 */
    ID_T            busEntityId = ZERO_ID;
    MemoryPool      mp;


	if (exchOutStp->srcDestEn == SrcDest_Src)		/* REF1177 */
	{
		exchRateTabInput = exchTabArgStp->exchRateTabSrcIn;
		exchRateNbrInput = exchTabArgStp->exchRateNbrSrcIn;
		exchPtr = exchOutStp->exchRateSrc;
	}
	else
	{
		exchRateTabInput = exchTabArgStp->exchRateTabDestIn;
		exchRateNbrInput = exchTabArgStp->exchRateNbrDestIn;
		exchPtr = exchOutStp->exchRateDest;
	}

	if (srcCurrId == destCurrId)
	{
		SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);
		return(ret);
	}

    /* GEN_GetApplInfo(ApplMissingExchRate, exch); */
	/* extract all exchange rate for source currency */
	if (exchRateTabInput == NULL)
	{
	    ret = FIN_SelectExchRate(srcCurrId, destCurrId, refDateTime, fixedDateFlg,
			             &exchRateTab, &exchRateNbr, TRUE, exchArgStp, &allocTab);
        freeTabPtr = TRUE;
    }
	else
	{
	    exchRateNbr = exchRateNbrInput;
	    exchRateTab = exchRateTabInput;
        allocTab = FALSE;
	}

	if (exchRateNbr == 0)
	    return(RET_FIN_INFO_NOPRICE);

	/* REF1177 - Depending on new defaultFlg, search default rate or return selected list */
	if (exchOutStp->defaultFlg == FALSE)
	{
		if (exchOutStp->srcDestEn == SrcDest_Src)
		{
		    exchOutStp->exchRateTabSrc = exchRateTab;
		    exchOutStp->exchRateNbrSrc = exchRateNbr;
		    exchOutStp->allocTabSrc    = allocTab;
	    }
		else
		{
		    exchOutStp->exchRateTabDest = exchRateTab;
		    exchOutStp->exchRateNbrDest = exchRateNbr;
		    exchOutStp->allocTabDest    = allocTab;
		}
		return(ret);
	}

    if(allocTab == TRUE)
    {
        mp.ownerDynStpTab(exchRateTab,exchRateNbr);
    }
    else if(freeTabPtr == TRUE)
    {
        mp.ownerPtr(exchRateTab);
    }

	if ((exchRateTabCpy=(DBA_DYNFLD_STP *) mp.calloc(exchRateNbr,
                                                  sizeof(DBA_DYNFLD_STP)))==NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	memcpy(exchRateTabCpy, exchRateTab, exchRateNbr * sizeof(DBA_DYNFLD_STP));
	nbOk = exchRateNbr;

	/* REF964 - Suppress exchange more recent that reference date */
	if (allocTab == FALSE)
	{
		i = 0;
		while ((i < exchRateNbr) &&	/* REF4099 - SSO - 990930 */
			   (DATETIME_CMP(refDateTime,
				             GET_DATETIME(exchRateTabCpy[i], A_ExchRate_ExchDate)) < 0))
		{
			nbOk--;
			exchRateTabCpy[i] = NULL;
			i++;
		}
	}

	/* search rank for all exchange rate and stock it into array */
    DBA_DYNFLD_STP  sTpPtr = mp.allocDynst(FILEINFO,S_Tp);
    DBA_DYNFLD_STP  aTpPtr = mp.allocDynst(FILEINFO,A_Tp);

	if ((rankTab=(int *) mp.calloc(exchRateNbr, sizeof(int)))== NULL)
    {
	    return(RET_DBA_ERR_NODATA);
    }

    if (exchArgStp->tpId != 0)
    {
	    SET_ID(sTpPtr, S_Tp_Id, exchArgStp->tpId);

	    if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr,
	                UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	    {
	        SYSNAME_T entSqlName;
	        strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
	        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
	                    entSqlName, GET_ID(sTpPtr, S_Tp_Id));
	        return(RET_DBA_ERR_NODATA);
	    }

	    if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE && GET_SMALLINT(aTpPtr, A_Tp_Rank) == 0)
                keepRankZero = TRUE;
	}

	for (i=0; i<exchRateNbr; i++)
	{
	    if ((exchRateTabCpy[i] != NULL) &&
		    (IS_NULLFLD(exchRateTabCpy[i], A_ExchRate_TpId) == FALSE))
	    {
	        SET_ID(sTpPtr, S_Tp_Id, GET_ID(exchRateTabCpy[i], A_ExchRate_TpId));

	        if (DBA_Get2(Tp, UNUSED, S_Tp, sTpPtr, A_Tp, &aTpPtr,
	                    UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	        {
	            SYSNAME_T entSqlName;
	            strcpy(entSqlName, DBA_GetDictEntitySqlName(Tp));
	            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
	                        entSqlName, GET_ID(sTpPtr, S_Tp_Id));
	            return(RET_DBA_ERR_NODATA);
	        }

	        if (IS_NULLFLD(aTpPtr, A_Tp_Rank) == FALSE)
	            rankTab[i] = GET_SMALLINT(aTpPtr, A_Tp_Rank);
	        else
		    rankTab[i] = 999;

	        /* for default analysis remove exchange rate with rank = 0 */
	        if (rankTab[i] == 0 && keepRankZero == FALSE)
	        {
	            nbOk--;
	            exchRateTabCpy[i] = NULL;
	        }
	        else if (rankTab[i] < rankMin)
		    rankMin = rankTab[i];
	    }
	    else
	    {
		rankTab[i] = 999;
	        if (rankTab[i] < rankMin)
		    rankMin = rankTab[i];
	    }
	}
    
	DBA_DYNFLD_STP  valRuleElt = mp.allocDynst(FILEINFO,A_ValRuleElt);

    /* Check whether the multi entity feature was configured; suppress exchange rates when BE mandatory flag is TRUE */ /* PMSTA-32142 CMILOS 130918 */
    if (GEN_IsMultiEntity())
    {
        /* set the owner_business_entity_id field index */
        DICT_ENTITY_STP exchRate = DBA_GetDictEntitySt(ExchRate);
        if (exchRate != nullptr && exchRate->ownerBusinessEntAttrStp != nullptr)
            busEntityFldIdx = exchRate->ownerBusinessEntAttrStp->progN;
    }

    /* if one or many mandatory field, supress all exchange rate which doesn't match */
	if (exchArgStp->tpMandFlg == TRUE ||
	    exchArgStp->provMandFlg == TRUE ||
	    exchArgStp->mktMandFlg == TRUE ||
        exchArgStp->busEntityFlg == TRUE) /* PMSTA-32140 CMILOS 081018 */
	{
	    if (exchArgStp->tpMandFlg == TRUE)
        	SET_ID(valRuleElt, A_ValRuleElt_TypeId, exchArgStp->tpId);

	    if (exchArgStp->mktMandFlg == TRUE)
        	SET_ID(valRuleElt, A_ValRuleElt_MktThirdId, exchArgStp->marketId);

	    if (exchArgStp->provMandFlg == TRUE)
        	SET_ID(valRuleElt, A_ValRuleElt_ProviderThirdId, exchArgStp->providerId);

        if (exchArgStp->busEntityFlg == TRUE) /* PMSTA-32140 CMILOS 081018 */
        {
            SET_ENUM(valRuleElt, A_ValRuleElt_BusEntityRuleEn, exchArgStp->busEntityRule);
        }
        else
        {
            SET_ENUM(valRuleElt, A_ValRuleElt_BusEntityRuleEn, BusEntityRule_Any);
        }

        SET_NULL_ID(valRuleElt, A_ValRuleElt_CurrId);
        SET_ENUM(valRuleElt, A_ValRuleElt_PriceCurrRuleEn, 0);
        SET_ENUM(valRuleElt, A_ValRuleElt_PriceMktRuleEn, 0);
        SET_ENUM(valRuleElt, A_ValRuleElt_PriceProviderRuleEn, 0);
        SET_ENUM(valRuleElt, A_ValRuleElt_PriceCurrRuleEn, 0);

	    for (i=0; i<exchRateNbr; i++)
	    {
		    if (exchRateTabCpy[i] != NULL)
		    {
		        if (FIN_IsExchRateValid(exchRateTabCpy[i], valRuleElt) == FALSE)
		        {
			        nbOk--;
			        exchRateTabCpy[i] = NULL;
		        }
		    }
	    }
	}

	/* read PRICE_DATE_PRIORITY_FLAG parametre */
	GEN_GetApplInfo(ApplExchRateDatePriorityFlag, &datePriorityFlg);

	/* keep only more recent exchange rate if date priority is TRUE */
	if (datePriorityFlg == TRUE && nbOk > 1)
	{
	    firstExchRate = -1;
        for (i=0; i<exchRateNbr && nbOk > 1; i++)
	    {
		    if (firstExchRate == -1 && exchRateTabCpy[i] != NULL)
		    {
		        firstExchRate = i;
            }
		    else if (exchRateTabCpy[i] != NULL &&
	                 CMP_DYNFLD(exchRateTabCpy[firstExchRate], exchRateTabCpy[i],
	                            A_ExchRate_ExchDate, A_ExchRate_ExchDate, DatetimeType) != 0)
	        {
	            nbOk--;
	            exchRateTabCpy[i] = NULL;
	        }
	    }
	}

	if (nbOk == 0)
	{
	    return(RET_FIN_INFO_NOEXCH);
	}

	/* only one exchange rate, return it */
	if (nbOk == 1)
	{
	    for (i=0; i<exchRateNbr; i++)
	    {
		    if (exchRateTabCpy[i] != NULL)
		    {
	            /* SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,
		                 GET_EXCHANGE(exchRateTabCpy[i], A_ExchRate_ExchRate)); REF5384 - DDV - 020412 - Copy all the structure */
	            COPY_DYNST(exchPtr, exchRateTabCpy[i], A_ExchRate);

		        return(ret);
		    }
	    }
	}

	/* search the best one */
	if ((exchRateTabCpySave=(DBA_DYNFLD_STP *) mp.calloc(exchRateNbr,
                                                      sizeof(DBA_DYNFLD_STP)))== NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	memcpy(exchRateTabCpySave, exchRateTabCpy, exchRateNbr * sizeof(DBA_DYNFLD_STP));
	nbOkSave = nbOk;

	/* Load Currency */

    /* REF5248 - RAK - 001005 */
    /* Suppress DBA_Get2(Curr) and FREE_DYNST for srcCurrPtr */
	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    DBA_DYNFLD_STP srcCurrPtr;
    FLAG_T         freeFlag = FALSE;
    if (DBA_GetCurrById(srcCurrId, &srcCurrPtr, &freeFlag) != RET_SUCCEED)
	{
	    SYSNAME_T entSqlName;
	    strcpy(entSqlName, DBA_GetDictEntitySqlName(Curr));
	    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
	                 entSqlName, srcCurrId);
	    return(RET_DBA_ERR_NODATA);
	}

    if(freeFlag == TRUE)
    {
        mp.ownerDynStp(srcCurrPtr);
    }

	GEN_GetApplInfo(ApplExchRateSelOrder, exchRateSelOrder);

	/* for (priority = 0; priority < 4 && nbOk > 1; priority++)*/
    for (priority = 0; exchRateSelOrder[priority] != ' ' && exchRateSelOrder[priority] != END_OF_STRING && nbOk > 1; priority++)
	{
	    nextPriority = FALSE;
	    switch (exchRateSelOrder[priority])
	    {
	        case 'M':
	        case 'm':
		        /* Priority is Market */
		        if (exchArgStp->marketId != 0)
		            attribute = A_ExchRate_MktThirdId;
		        else
		            attribute = A_Curr_MktThirdId+100;
		        break;
	        case 'T':
	        case 't':
		        /* Priority is Type */
		        if (exchArgStp->marketId != 0)
		            attribute = A_ExchRate_TpId;
		        else
		            attribute = A_ExchRate_CurrId; /* used to search lowest rank not currency */
		        break;
	        case 'P':
	        case 'p':
		        /* Priority is Provider */
		        if (exchArgStp->providerId != 0)
		            attribute = A_ExchRate_ThirdId;
		        else
		            attribute = A_Curr_ProvThirdId+100;
		        break;

            case 'B':  /* Priority is Business Entity */
            case 'b':
                /* Check whether the multi entity feature was configured */ /* PMSTA-32142 CMILOS 130918 */
                if (GEN_IsMultiEntity())
                {
                    switch (exchArgStp->busEntityRule)
                    {
                    case BusEntityRule_ConnectedBE:
                        attribute = busEntityFldIdx;
                        busEntityId = SYS_GetThreadCurrBusinessEntityId();
                        break;

                    case BusEntityRule_Master:
                        attribute = busEntityFldIdx;
                        busEntityId = EV_MasterBusinessEntityId;
                        break;

                    case  BusEntityRule_Any:
                    default:
                        nextPriority = TRUE; /* do nothing */
                        break;
                    }
                }
                else
                    nextPriority = TRUE; /* do nothing when ME is not configured */
                break;

	        default:
	    		nextPriority = TRUE;
		    break;
	    }

 	    while(nextPriority == FALSE)
	    {
            /* REF8844 - LJE - 030410 : switch -> if */
		    if (attribute==A_ExchRate_TpId)
            {
	            for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL &&
				        GET_ID(exchRateTabCpy[i], A_ExchRate_TpId) != rankTab[i])
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
		        attribute = A_ExchRate_CurrId;
            }
            else if (attribute==A_ExchRate_CurrId) /* Just use this attribute to seach the lowest rank */
            {
			    /* don't compare with currency */
			    for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL && rankTab[i] > rankMin)
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
			    if (nbOk > 0)
	    		    nextPriority = TRUE;
			    else
			        rankMin++;
            }
            else if (attribute==A_ExchRate_ThirdId)
            {
	    	    for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL &&
				        GET_ID(exchRateTabCpy[i], A_ExchRate_ThirdId) != exchArgStp->providerId)
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
		        attribute = A_Curr_ProvThirdId+100;
			}
            else if (attribute==A_ExchRate_MktThirdId)
            {
	    	    for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL &&
				        GET_ID(exchRateTabCpy[i], A_ExchRate_MktThirdId) != exchArgStp->marketId)
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
		        attribute = A_Curr_MktThirdId+100;
            }
            else if (attribute == busEntityFldIdx) /* PMSTA-32142 CMILOS 130918 */
            {
                if (busEntityFldIdx != INVALID_FLD)
                {
                    for (i = 0; i < exchRateNbr && nbOk > 0; i++)
                    {
                        if (exchRateTabCpy[i] != NULLDYNST &&
                            CMP_ID(GET_ID(exchRateTabCpy[i], busEntityFldIdx), busEntityId) != 0)
                        {
                            nbOk--;
                            exchRateTabCpy[i] = NULLDYNST;
                        }
                    }
                }
                nextPriority = TRUE;
            }
            else if (attribute==A_Curr_ProvThirdId+100)
            {
	    	    for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL &&
			            CMP_DYNFLD(exchRateTabCpy[i], srcCurrPtr,
				                   A_ExchRate_ThirdId, A_Curr_ProvThirdId, IdType) != 0)
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
	    		nextPriority = TRUE;
			}
            else if (attribute==A_Curr_MktThirdId+100)
            {
	    	    for (i=0; i<exchRateNbr && nbOk > 0; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL &&
			            CMP_DYNFLD(exchRateTabCpy[i], srcCurrPtr,
				                    A_ExchRate_MktThirdId, A_Curr_MktThirdId, IdType) != 0)
			        {
			            nbOk--;
			            exchRateTabCpy[i] = NULL;
			        }
	    	    }
	    		nextPriority = TRUE;
		    }

		    if (nbOk == 1)
		    {
	    	    for (i=0; i<exchRateNbr; i++)
	    	    {
			        if (exchRateTabCpy[i] != NULL)
			        {
    	                /* SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,
	                        GET_EXCHANGE(exchRateTabCpy[i], A_ExchRate_ExchRate)); REF5384 - DDV - 020412 - Copy all the structure */
	                    COPY_DYNST(exchPtr, exchRateTabCpy[i], A_ExchRate);
		    	        return(ret);
			        }
	    	    }
	    	}
		    else if (nbOk == 0)
		    {
		        nbOk = nbOkSave;
		        memcpy(exchRateTabCpy, exchRateTabCpySave, exchRateNbr * sizeof(DBA_DYNFLD_STP));
		    }
		    else if (nbOk != nbOkSave)
		    {
		        nbOkSave = nbOk;
		        memcpy(exchRateTabCpySave, exchRateTabCpy, exchRateNbr * sizeof(DBA_DYNFLD_STP));
		    }
	    }
	}

	for (i=0; i<exchRateNbr; i++)
	{
	    if (exchRateTabCpy[i] != NULL)
	    {
	        /*SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,
		             GET_EXCHANGE(exchRateTabCpy[i], A_ExchRate_ExchRate));REF5384 - DDV - 020412 - Copy all the structure */
	        COPY_DYNST(exchPtr, exchRateTabCpy[i], A_ExchRate);
	        return(ret);
	    }
	}

	return(RET_FIN_INFO_NOEXCH);
}

/************************************************************************
**
**  Function    :   FIN_InverseExchRate()
**
**  Description :   It is possible to store the exchange rates in the database
**		            inversely relative to the present method.
**		            This is required to be able to store the fixed exchange
**		            rates of 'in' currencies relative to the EURO on the 01/01/1999,
**		            as well as exchange rates of the 'out' currencies as they will be
**		            provided by the market from the 01/01/1999.
**
**  Arguments   :   exchRateTab	  exchange rate array pointer
**		            exchRateNbr   exchange rate number
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF1266 - RAK - 980210
**  Modif.      :   REF3533 - RAK - 990428
**
*************************************************************************/
RET_CODE FIN_InverseExchRate(DBA_DYNFLD_STP *exchRateTab, int exchRateNbr)
{
	int		i;
	ID_T		oldCurrId;
	char 		oldInverseFlg=FALSE, inverseAllFlg=FALSE;
	EXCHANGE_T	exch;
	DATETIME_T 	euroDate;

	/* -------------------------------------------------------------------------- */
	/* If EURO conversion date is NULL       : all the exchange will be inversed. */
	/* Elsewhere if old inverse flag is TRUE : all the rate will be inversed      */
	/* but if old inverse flag is FALSE      : don't inverse rate before EURO     */
	/* -------------------------------------------------------------------------- */
	memset(&euroDate, 0, sizeof(DATETIME_T));
	GEN_GetApplInfo(ApplEuroExchConvDate, &euroDate.date);

	if (euroDate.date == MAGIC_END_DATE)
		inverseAllFlg = TRUE;
	else
	{
		/* REF3533 - RAK - Don't test old inverse flag if there */
		/*                 isn't an old underlying currency     */
		if (SYS_GetEnv("AAAINVERSECORR") != NULL)
		{
		    GEN_GetApplInfo(ApplOldExchInverseFlag, &oldInverseFlg);
		    if (oldInverseFlg == TRUE)
			    inverseAllFlg = TRUE;
		}
		else	/* REF3533 - RAK - new code (and correct) */
		{
		    GEN_GetApplInfo(ApplOldExchUnderCurrId, &oldCurrId);
		    if (oldCurrId != 0)
		    {
		        GEN_GetApplInfo(ApplOldExchInverseFlag, &oldInverseFlg);
		        if (oldInverseFlg == TRUE)
			        inverseAllFlg = TRUE;
		    }
		    else
			inverseAllFlg = TRUE;
		}
	}

	for (i=0; i<exchRateNbr; i++)
	{
		/* Not inverse rate before EURO */
		if (inverseAllFlg == FALSE && 		/* REFXXX - Inverse on euro date too */
		    DATETIME_CMP(GET_DATETIME(exchRateTab[i], A_ExchRate_ExchDate), euroDate) < 0)
			continue;

		/* Inverse all rate or only rate after EURO conversion date. */
		if (CMP_EXCHANGE(GET_EXCHANGE(exchRateTab[i], A_ExchRate_ExchRate), 0.0) != 0)
		{
			exch = 1.0 / GET_EXCHANGE(exchRateTab[i], A_ExchRate_ExchRate);
			SET_EXCHANGE(exchRateTab[i], A_ExchRate_ExchRate, exch);
		}
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_MergeExchRate()
**
**  Description :   Merge to exchange rate
**
**  Arguments   :   exchRateSrc   source exchange rate
**                  exchRateDest  destination exchange rate
**                  exchRate      result exchange rate
**
**  Return      :   exchange rate
**
**  Modif       :   DVP344 - XDI - 970313
**
*************************************************************************/
RET_CODE FIN_MergeExchRate(DBA_DYNFLD_STP exchRateSrc,
                           DBA_DYNFLD_STP exchRateDest,
		                   DBA_DYNFLD_STP exchRate)
{
	SET_ID(exchRate, A_ExchRate_CurrId,
	       GET_ID(exchRateSrc, A_ExchRate_CurrId));

	SET_ID(exchRate, A_ExchRate_UnderCurrId,
	       GET_ID(exchRateDest, A_ExchRate_CurrId));

	if (CMP_DYNFLD(exchRateSrc, exchRateDest,
	               A_ExchRate_TpId, A_ExchRate_TpId, IdType) == 0 &&
	    IS_NULLFLD(exchRateSrc, A_ExchRate_TpId) == FALSE)
	{SET_ID(exchRate, A_ExchRate_TpId,
		 GET_ID(exchRateSrc, A_ExchRate_TpId));}
	else
	{SET_NULL_ID(exchRate, A_ExchRate_TpId);}

	if (CMP_DYNFLD(exchRateSrc, exchRateDest,
	               A_ExchRate_ThirdId, A_ExchRate_ThirdId, IdType) == 0 &&
	    IS_NULLFLD(exchRateSrc, A_ExchRate_ThirdId) == FALSE)
	{SET_ID(exchRate, A_ExchRate_ThirdId,
		 GET_ID(exchRateSrc, A_ExchRate_ThirdId));}
	else
	{SET_NULL_ID(exchRate, A_ExchRate_ThirdId);}

	if (CMP_DYNFLD(exchRateSrc, exchRateDest,
	               A_ExchRate_MktThirdId, A_ExchRate_MktThirdId, IdType) == 0 &&
	    IS_NULLFLD(exchRateSrc, A_ExchRate_MktThirdId) == FALSE)
	{SET_ID(exchRate, A_ExchRate_MktThirdId,
		 GET_ID(exchRateSrc, A_ExchRate_MktThirdId));}
	else
	{SET_NULL_ID(exchRate, A_ExchRate_MktThirdId);}

	if (CMP_DYNFLD(exchRateSrc, exchRateDest,
	               A_ExchRate_ExchDate, A_ExchRate_ExchDate, DatetimeType) < 0)
	{SET_DATETIME(exchRate, A_ExchRate_ExchDate,
		 GET_DATETIME(exchRateSrc, A_ExchRate_ExchDate));}
	else
    {SET_DATETIME(exchRate, A_ExchRate_ExchDate,
         GET_DATETIME(exchRateDest, A_ExchRate_ExchDate));}

	if (GET_EXCHANGE(exchRateDest, A_ExchRate_ExchRate) != 0)
	{SET_EXCHANGE(exchRate, A_ExchRate_ExchRate,
		 GET_EXCHANGE(exchRateSrc, A_ExchRate_ExchRate) /
		 GET_EXCHANGE(exchRateDest, A_ExchRate_ExchRate));}
	else
		SET_EXCHANGE(exchRate, A_ExchRate_ExchRate, 0.0);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CurrEuroExchRate()
**
**  Description :   Get currency exchange rate(s) with EURO treatment.
**
**  Arguments   :   currId         source currency id
**                  crossCurrId    destination currency id
**		            euroCurrId     euro currency id
**                  refDateTime    valuation date
**                  euroDate       euro conversion date
**                  exchArgStp     default rate arguments (type, market, provider and flags)
**		            exchTabArgStp  input rates arrays
**                  exchOutStp     output rates and arrays
**
**  Return      :   RET_SUCCEED or error code, currency exchange rate is filled.
**
**  Creation    :   REF1177 - RAK - 980202
**  Modif.      :   REFXXXX - RAK - 980430
**
*************************************************************************/
STATIC RET_CODE FIN_CurrEuroExchRate(ID_T                currId,
				                     ID_T                crossCurrId,
				                     ID_T                euroCurrId,
				                     DATETIME_T          refDateTime,
				                     DATETIME_T          euroDate,
				                     FIN_EXCHARG_STP     exchArgStp,
			  	                     FIN_EXCHTABARG_STP  exchTabArgStp,
			                         FIN_EXCHOUT_STP     exchOutStp)
{
	DBA_DYNFLD_STP 	*svSrcExchTab=NULL, *svDestExchTab=NULL;
	int            	svSrcNbr=0, svDestNbr=0, i, exchRateNbr=0;
	char		    fixedDateFlg;
       	            DBA_DYNFLD_STP	exchRatePtr=NULL, *exchRateTab=NULL;
	DATETIME_T	    selDate;
	FIN_CURREURO_ST	currEuroInfo;
	RET_CODE	    ret=RET_SUCCEED;

	memset(&currEuroInfo, 0, sizeof(FIN_CURREURO_ST));

	if (crossCurrId == euroCurrId)
	{
	    /* Get currency euro conversion date. It's set to 0 for "out" currency. */
	    if ((ret = FIN_CurrEuroConvInfo(currId, &currEuroInfo)) != RET_SUCCEED)
			return(ret);

	    /* 'in' currency at euro date -> use fixed rate */
	    /* For 'in' currency after euro date, valo date */
	    /* need to be at or after 'in' currency date    */
	    if (currEuroInfo.euroDate.date != 0 &&
		    (euroDate.date == currEuroInfo.euroDate.date ||
		    (currEuroInfo.euroDate.date > euroDate.date &&
		    refDateTime.date >= currEuroInfo.euroDate.date)))
	    {
			ret = FIN_InCurrFixedExchRate(currId, crossCurrId, &currEuroInfo,
						      TRUE, exchArgStp,
						      exchTabArgStp, exchOutStp);
	    }
	    else
	    {
			ret = FIN_SelDfltExchRate(currId, crossCurrId, refDateTime,
						  FALSE, exchArgStp,
						  exchTabArgStp, exchOutStp);
	    }
	}
	else
	{
	    /* Get currency euro conversion date. It's set to 0 for "out" curr. */
	    if ((ret = FIN_CurrEuroConvInfo(currId, &currEuroInfo)) != RET_SUCCEED)
		    return(ret);

	    /* After euro conversion date, for "in" currency get fixed rate */
	    /* between currency and euro and rate(s) between euro and cross */
	    /* currency to determine "in" currency rate.                    */
	    if (currEuroInfo.euroDate.date != 0 &&
		    refDateTime.date >= currEuroInfo.euroDate.date)
	    {
		    EXCHANGE_T	rate=0.0, currRate=0.0;
		    char		svDefaultFlg;

		    /* Cannot used because of currencies are modified */
		    svSrcNbr     = exchTabArgStp->exchRateNbrSrcIn;
		    svSrcExchTab = exchTabArgStp->exchRateTabSrcIn;
		    exchTabArgStp->exchRateNbrSrcIn = 0;
		    exchTabArgStp->exchRateTabSrcIn = NULL;

		    svDestNbr     = exchTabArgStp->exchRateNbrDestIn;
		    svDestExchTab = exchTabArgStp->exchRateTabDestIn;
		    exchTabArgStp->exchRateNbrDestIn = 0;
		    exchTabArgStp->exchRateTabDestIn = NULL;

		    /* Get fixed rate between "in" currency and euro, */
		    /* apply default to get only one fixed rate       */
		    if (exchOutStp->defaultFlg == FALSE)
		    {
		        if ((exchRatePtr = ALLOC_DYNST(A_ExchRate)) == NULL)
				    MSG_RETURN(RET_MEM_ERR_ALLOC);

		        if (exchOutStp->srcDestEn == SrcDest_Src)
			    exchOutStp->exchRateSrc = exchRatePtr;
		        else
			    exchOutStp->exchRateDest = exchRatePtr;
		    }
		    else
		    {
		        if (exchOutStp->srcDestEn == SrcDest_Src)
			    exchRatePtr = exchOutStp->exchRateSrc;
		        else
			    exchRatePtr = exchOutStp->exchRateDest;
		    }

		    svDefaultFlg = exchOutStp->defaultFlg;
		    exchOutStp->defaultFlg = TRUE;
		    /* REF1310 - RAK - 980219 */
		    ret = FIN_InCurrFixedExchRate(currId, euroCurrId, &currEuroInfo, TRUE,
					          exchArgStp, exchTabArgStp, exchOutStp);
		    exchOutStp->defaultFlg = svDefaultFlg;

		    if (ret == RET_SUCCEED)
		    {
		        /* fixed rate between "in" currency and euro */
		        rate = GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate);

		        /* Get rate(s) between euro and cross currency */
		        /* REFXXX - Verify if cross currency is in currency */
		        ret = FIN_EuroCrossExchRate(euroCurrId, crossCurrId, refDateTime, FALSE,
					            exchArgStp, exchTabArgStp, exchOutStp);
		    }
		    else
			    ret = RET_FIN_INFO_NOEXCH;

            /* REF5297 - RAK - 001011 */
		    /* if (exchOutStp->defaultFlg == FALSE)
		    { FREE_DYNST(exchRatePtr, A_ExchRate); } */

		    exchTabArgStp->exchRateNbrSrcIn = svSrcNbr;
		    exchTabArgStp->exchRateTabSrcIn = svSrcExchTab;
		    exchTabArgStp->exchRateNbrDestIn = svDestNbr;
		    exchTabArgStp->exchRateTabDestIn = svDestExchTab;

		    if (ret == RET_SUCCEED)
		    {
			    /* Compute rate between "in" currency and cross */
			    /* rate = IN/EURO                               */
			    /* exchRatePtr or exchRateTab = EURO/CROSS      */
			    if (exchOutStp->defaultFlg == TRUE)
			    {
			        /* only one choosen rate */
			        currRate = rate * GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate);
			        SET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate, currRate);
			        SET_ID(exchRatePtr, A_ExchRate_CurrId,         currId);
			        SET_ID(exchRatePtr, A_ExchRate_UnderCurrId,    crossCurrId);
			    }
			    else					/* rate(s) list */
			    {
			        if (exchOutStp->srcDestEn == SrcDest_Src)
			        {
				        exchRateTab = exchOutStp->exchRateTabSrc;
				        exchRateNbr = exchOutStp->exchRateNbrSrc;
			        }
			        else
			        {
				        exchRateTab = exchOutStp->exchRateTabDest;
				        exchRateNbr = exchOutStp->exchRateNbrDest;
			        }

			        for (i=0; i<exchRateNbr; i++)
			        {
				        currRate = rate * GET_EXCHANGE(exchRateTab[i],
							               A_ExchRate_ExchRate);
				        SET_EXCHANGE(exchRateTab[i], A_ExchRate_ExchRate, currRate);
			                SET_ID(exchRateTab[i], A_ExchRate_CurrId,         currId);
			                SET_ID(exchRateTab[i], A_ExchRate_UnderCurrId,    crossCurrId);
			        }
			    }
		    }
	    }
	    else if (currId == euroCurrId)
	    {
		    svSrcNbr     = exchTabArgStp->exchRateNbrSrcIn;
		    svSrcExchTab = exchTabArgStp->exchRateTabSrcIn;
		    exchTabArgStp->exchRateNbrSrcIn = 0;
		    exchTabArgStp->exchRateTabSrcIn = NULL;

		    svDestNbr     = exchTabArgStp->exchRateNbrDestIn;
		    svDestExchTab = exchTabArgStp->exchRateTabDestIn;
		    exchTabArgStp->exchRateNbrDestIn = 0;
		    exchTabArgStp->exchRateTabDestIn = NULL;

		    /* If asked date is before euro date, use euro date, */
		    /* after this date search current rate               */
	        if (refDateTime.date < euroDate.date)
		    {
			    selDate      = euroDate;
			    fixedDateFlg = TRUE;
		    }
		    else
		    {
			    selDate      = refDateTime;
			    fixedDateFlg = FALSE;
		    }

		    /* get rate between euro and cross curr at euro conversion date. */
		    /* REFXXX - Verify if cross currency is in currency */
		    ret = FIN_EuroCrossExchRate(currId, crossCurrId, selDate, fixedDateFlg,
					        exchArgStp, exchTabArgStp, exchOutStp);

		    exchTabArgStp->exchRateNbrSrcIn = svSrcNbr;
		    exchTabArgStp->exchRateTabSrcIn = svSrcExchTab;
		    exchTabArgStp->exchRateNbrDestIn = svDestNbr;
		    exchTabArgStp->exchRateTabDestIn = svDestExchTab;
	    }
	    else
	    {
		    /* normal case ("out", before euro conversion date, ... */
		    ret = FIN_SelDfltExchRate(currId, crossCurrId, refDateTime, FALSE,
				              exchArgStp, exchTabArgStp, exchOutStp);
	    }
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_EuroCrossExchRate()
**
**  Description :   Get exchange rate agains cross currency,
**	  	    verify if cross is an 'in' currency.
**
**  Arguments   :   currId         source currency id
**                  crossCurrId    destination currency id
**                  refDateTime    valuation date
**                  fixedDateFlg
**                  exchArgStp     default rate arguments (type, market, provider and flags)
**		    exchTabArgStp  input rates arrays
**                  exchOutStp     output rates and arrays
**
**  Return      :   RET_SUCCEED or error code, currency exchange rate is filled.
**
**  Creation    :   REFXXXX - RAK - 980506
**  Modif.	:   REF3533 - RAK - 990428
**  Modif.	:   REF3671 - RAK - 990510
**  Modif.	:   REF3922 - RAK - 990913
**
*************************************************************************/
STATIC RET_CODE FIN_EuroCrossExchRate(ID_T                  euroCurrId,
				                        ID_T                crossCurrId,
				                        DATETIME_T	        refDateTime,
				                        char                fixedDateFlg,
				                        FIN_EXCHARG_STP     exchArgStp,
			  	                        FIN_EXCHTABARG_STP  exchTabArgStp,
			                            FIN_EXCHOUT_STP     exchOutStp)
{
	RET_CODE	    ret=RET_SUCCEED;
	DBA_DYNFLD_STP	exchRatePtr=NULL;
	EXCHANGE_T	    exch=0.0;
	/* FLAG_T		inverseFlg; DDV- 991004 */
	FIN_CURREURO_ST	crossEuroInfo;

	/* Get currency euro conversion date. It's set to 0 for "out" currency. */
	if ((ret = FIN_CurrEuroConvInfo(crossCurrId, &crossEuroInfo)) != RET_SUCCEED)
		return(ret);

	/* "out" currency : search normal rate. */
	/* "in" currency : search fixed rate.   */
	if (crossEuroInfo.euroDate.date == 0 ||
	    crossEuroInfo.euroDate.date > refDateTime.date)
	{
		ret = FIN_SelDfltExchRate(euroCurrId, crossCurrId, refDateTime,
					  fixedDateFlg, exchArgStp,
					  exchTabArgStp, exchOutStp);
		/* REFXXXX - RAK - 980506 */
		if (exchOutStp->srcDestEn == SrcDest_Src)
			exchRatePtr = exchOutStp->exchRateSrc;
		else
			exchRatePtr = exchOutStp->exchRateDest;

		/* REEF3922 - Finaly correct the bug une fois pour toute ... */
		/* REF3671 - don't correct the bug ... */
		/* REF3533 - RAK - Don't do inverse(inverse(db.exchange), but  */
		/*           only inverse(db.exchange) in FIN_SelDfltExchRate()*/
		/*
		if (SYS_GetEnv("AAAINVERSECORR") != NULL)
		{
		    GEN_GetApplInfo(ApplExchInverseFlag, &inverseFlg);
		    if (inverseFlg == TRUE)
		    {
			if (CMP_EXCHANGE(GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate), 0.0) != 0)
		        {
		       	    exch = 1.0 / GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate);
		            SET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate, exch);
			}
		    }
		}
		*/
	}
	/* "in" currency : search rate at currency euro conversion date */
	else
	{
		/* Inverse because of fixed rate is in 'in' currency */
		ret = FIN_InCurrFixedExchRate(crossCurrId, euroCurrId, &crossEuroInfo,
					      TRUE, exchArgStp, exchTabArgStp, exchOutStp);
		if (exchOutStp->srcDestEn == SrcDest_Src)
			exchRatePtr = exchOutStp->exchRateSrc;
		else
			exchRatePtr = exchOutStp->exchRateDest;

		if (CMP_EXCHANGE(GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate), 0.0) != 0)
		{
		    exch = 1.0 / GET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate);
		    SET_EXCHANGE(exchRatePtr, A_ExchRate_ExchRate, exch);
		}

		SET_ID(exchRatePtr, A_ExchRate_CurrId,         euroCurrId);
		SET_ID(exchRatePtr, A_ExchRate_UnderCurrId,    crossCurrId);
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InCurrFixedExchRate()
**
**  Description :   Use euro exchange rate stored in currency table or
**		    select euro exchange rate.
**
**  Arguments   :   srcCurrId       source currency identifier
**                  destCurrId      destination currency identifier
**                  currEuroInfoStp in currency information
**                  fixedDateFlg    TRUE : select rates on received date only
**                  exchArgStp      default rate arguments (type, market, provider and flags)
**		    exchTabArgStp   input rates arrays
**                  exchOutStp      output rates and arrays
**
**  Return      :   RET_SUCCEED or error code, exchOutStp is filled.
**
**  Creation    :   REF1310 - RAK - 980219
**  Last modif. :   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
STATIC RET_CODE FIN_InCurrFixedExchRate(ID_T                srcCurrId,
		                                ID_T                destCurrId,
			                            FIN_CURREURO_STP    currEuroInfoStp,
			                            char                fixedDateFlg,
			                            FIN_EXCHARG_STP     exchArgStp,
			                            FIN_EXCHTABARG_STP  exchTabArgStp,
			                            FIN_EXCHOUT_STP     exchOutStp)
{
	RET_CODE	    ret=RET_SUCCEED;
	DBA_DYNFLD_STP	exchPtr=NULL, *exchRateTab=NULL;

	if (CMP_EXCHANGE(currEuroInfoStp->euroExch, 0.0) == 0)
	{
		ret = FIN_SelDfltExchRate(srcCurrId, destCurrId, currEuroInfoStp->euroDate,
					  fixedDateFlg, exchArgStp, exchTabArgStp, exchOutStp);
	}
	else
	{
		if (exchOutStp->defaultFlg == FALSE)
		{
    		if ((exchRateTab = (DBA_DYNFLD_STP*) CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULL) /* REF7264 - PMO */
				MSG_RETURN(RET_MEM_ERR_ALLOC);

		    if ((exchRateTab[0] = ALLOC_DYNST(A_ExchRate)) == NULL)
			{
				FREE(exchRateTab);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

	        SET_EXCHANGE(exchRateTab[0], A_ExchRate_ExchRate,
						 currEuroInfoStp->euroExch);

			if (exchOutStp->srcDestEn == SrcDest_Src)
			{
		    	exchOutStp->exchRateTabSrc = exchRateTab;
		    	exchOutStp->exchRateNbrSrc = 1;
		    	exchOutStp->allocTabSrc    = TRUE;
	    	}
			else
			{
		    	exchOutStp->exchRateTabDest = exchRateTab;
		    	exchOutStp->exchRateNbrDest = 1;
		    	exchOutStp->allocTabDest    = TRUE;
			}
		}
		else
		{
			if (exchOutStp->srcDestEn == SrcDest_Src)
				exchPtr = exchOutStp->exchRateSrc;
			else
				exchPtr = exchOutStp->exchRateDest;

	        SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, currEuroInfoStp->euroExch);
		}
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CurrEuroConvInfo()
**
**  Description :   Verify if received currency is in euro,
**                  in this case return his euro conversion date.
**                  For others currencies, date will be set to 0.
**		            Return other informations like exchange too.
**
**  Arguments   :   currId		    currency identifier
**                  euroConvInfoStp pointer on euro conversion informations.
**
**  Return      :   RET_SUCCEED or error code, euroConvInfoStp is filled
**
**  Creation    :   REF1177 - RAK - 980130
**  Modif       :   REF2418 - DDV - 980624 - Replace DBA_Select2 with DBA_Get2
**  Modif.      :   REF5248 - RAK - 001005
**
*************************************************************************/
STATIC RET_CODE FIN_CurrEuroConvInfo(ID_T             srcCurrId,
			                         FIN_CURREURO_STP euroConvInfoStp)
{
	DBA_DYNFLD_STP  currPtr=NULL;
	RET_CODE        ret;
    FLAG_T          freeFlag=FALSE;

	DATE_START_TIMER(19, TIMER_MASK_XCP);
	memset(euroConvInfoStp, 0, sizeof(FIN_CURREURO_ST));

    /* REF5248 - RAK - 001005 */
    /* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */
	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    if ((ret = DBA_GetCurrById(srcCurrId, &currPtr, &freeFlag)) != RET_SUCCEED)
	{
		DATE_STOP_TIMER(19, TIMER_MASK_XCP);
		return(ret);
	}

	if (IS_NULLFLD(currPtr, A_Curr_EuroConvDate) == FALSE)
	{
	    euroConvInfoStp->euroDate = GET_DATETIME(currPtr, A_Curr_EuroConvDate);

	    /* REF1310 - Remember fixed exchange stored in currency table */
	    /* It will be 0.0 if it isn't filled.                         */
	    if (IS_NULLFLD(currPtr, A_Curr_EuroExchRate) == FALSE &&
		    GET_EXCHANGE(currPtr, A_Curr_EuroExchRate) != 0)
	    	euroConvInfoStp->euroExch =
				 1.0/GET_EXCHANGE(currPtr, A_Curr_EuroExchRate);
	}

    if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}

	DATE_STOP_TIMER(19, TIMER_MASK_XCP);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SelectExchRate()
**
**  Description :   Select all exchange rate for a currency.
**
**  Arguments   :   srcCurrId     Source Currency id
**                  crossCurrId   Destination Currency id
**                  refDatetime   Valuation date
**                  fixedDateFlg  TRUE : select rates on received date only
**                  exchRateTab	  array of exchange rate
**                  exchRateNbr	  number of element in array
**		    distinctFlg   flag for select
**
**  Return      :   exchange rate array
**
**  Modif       :   DVP344 - XDI - 970306
**  Modif       :   REF1177 - RAK - 980202
**  Modif       :   REF1266 - RAK - 980210
**  Modif.	    :   REF2580 - SSO - 980727
**  Modif.	    :   REF2992 - RAK - 981221
**  Modif.	    :   REF3672 - RAK - 990511
**  Modif.	    :   REF3701 - RAK - 990519
**  Modif.      :   REF7475 - PMO/YST - 020516
**
*************************************************************************/
RET_CODE FIN_SelectExchRate(ID_T              srcCurrId,
			                ID_T              crossCurrId,
		                    DATETIME_T        refDateTime,
			                char              fixedDateFlg,	/* REF1177 */
		                    DBA_DYNFLD_STP    **exchRateTab,
		                    int               *exchRateNbr,
		                    FLAG_T            distinctFlg,
			                FIN_EXCHARG_STP   exchArgStp,	/* REF2580 */
			                FLAG_T            *freeExchTabPtr)
{
	DBA_DYNFLD_STP  	selArgPtr=NULL, *allExchRateTab=NULL;
	DBA_DYNFLD_STP  	domainPtr=NULL;
	DBA_DYNFLD_STP  	*exchRateTabTmp=NULL;
	DBA_DYNFLD_ST     	exchCurrId;
	RET_CODE        	ret=RET_SUCCEED;
	int			        validity, i, firstExchRate, nb, allExchRateNbr, valNbr=0;
	char			    selFromDb, olderExistFlg;
	DATETIME_T		    minDateTime, maxDateTime, tmpDateTime, refDateTimeValidity;
	FLAG_T		        distinctFlgTmp, inverseFlg;
	DBA_HIER_HEAD_STP	hierHeadPtr=NULL;

    /* REF7264 - RAK - 020307 */
    memset(&exchCurrId, 0, sizeof(DBA_DYNFLD_ST));

	minDateTime.date = 0;
	minDateTime.time = 0;
	maxDateTime.date = 0;
	maxDateTime.time = 0;
	refDateTimeValidity.date = 0;
	refDateTimeValidity.time = 0;

	*exchRateTab=NULL;		/* REF1177 */
	*exchRateNbr=0;
	*freeExchTabPtr=FALSE;

	/* Compute begin date */
	GEN_GetApplInfo(ApplExchRatePeriodValidity, &validity);
	refDateTimeValidity.date = DATE_Move(refDateTime.date, (-1) * validity, Day);

	distinctFlgTmp = distinctFlg;

	if (fixedDateFlg == TRUE)		/* REF1177 - Load only rate at fixed date */
	{
		minDateTime.date = refDateTime.date;
		maxDateTime.date = refDateTime.date;
	}
	else
	{
		/* REF2580 - SSO - 980727 */
	    if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromExchArg(exchArgStp))) != NULL &&
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
	    {
		    tmpDateTime = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	        minDateTime.date = DATE_Move(tmpDateTime.date, (-1) * validity, Day);
		    maxDateTime = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
		    distinctFlgTmp = FALSE;
	    }
	    else
	    {
		    minDateTime.date = refDateTimeValidity.date;
		    maxDateTime.date = refDateTime.date;
	    }
	}

	/* Load from database */
	if ((selArgPtr = ALLOC_DYNST(Sel_Arg)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(selArgPtr, Sel_Arg_Id1, srcCurrId);
	SET_ID(selArgPtr, Sel_Arg_Id2, crossCurrId);
	SET_DATETIME(selArgPtr, Sel_Arg_FromDate, minDateTime);
	SET_DATETIME(selArgPtr, Sel_Arg_TillDate, maxDateTime);
	SET_FLAG(selArgPtr, Sel_Arg_DistinctFlg, distinctFlgTmp);

	/* REF3621 - RAK - 990714 - Don't use this beautiful improvment ... */
	if (SYS_GetEnv("AAANOLOADEXCH") != NULL)
	{
	    SET_ID((&exchCurrId), 0, srcCurrId);
	    hierHeadPtr = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

	    if (hierHeadPtr == NULL)
	    {
		    selFromDb = TRUE;
	    }
	    else /* if ((ret = DBA_GetHierEltPosByDynSt(hierHeadPtr, A_ExchRate,
						                        &exchRateEltPos)) == RET_SUCCEED) * PMSTA-13295 - JPP - 20120207 */
	    {
		    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHeadPtr,
						                A_ExchRate,        /* PMSTA-13295 - JPP - 20120207 */
							            A_ExchRate_CurrId, /* REF3621 - RAK - 990713 */
						                exchCurrId,
						                FALSE,
						                NULLFCT,
						                NULL,
						                NULLFCT,
							            FALSE,
							            &allExchRateNbr,
							            &allExchRateTab)) != RET_SUCCEED)
		    {
			    selFromDb = TRUE;
		    }
		    else if (allExchRateNbr == 0)
		    {
			    FREE(allExchRateTab);
			    selFromDb = TRUE;
		    }
		    else
		    {
			    selFromDb = FALSE;

			    /* Search first asked underlying */
			    i=0;
			    while (i<allExchRateNbr &&
			           GET_ID(allExchRateTab[i], A_ExchRate_UnderCurrId) != crossCurrId)
				    i++;

			    /* Search first valid exchange */
			    while (i<allExchRateNbr &&
		                   GET_ID(allExchRateTab[i], A_ExchRate_UnderCurrId) == crossCurrId &&
		                   DATETIME_CMP(GET_DATETIME(allExchRateTab[i], A_ExchRate_ExchDate),
				                refDateTime) > 0)
		       	    i++;

			    firstExchRate = i;

			    /* Analyse existing exchange :                                    */
			    /* - If one ore more in valid_period -> return it                 */
			    /* - If one price older as valid_period return a empty array.     */
			    /*   (currencies exch are loaded but there isn't a valid)         */
			    /* - Else select in database. (currencies exch aren't loaded ...) */

			    olderExistFlg = FALSE;
			    valNbr        = 0;
			    while (i<allExchRateNbr && olderExistFlg == FALSE &&
		                   GET_ID(allExchRateTab[i], A_ExchRate_UnderCurrId) == crossCurrId)
			    {
			        if (DATETIME_CMP(GET_DATETIME(allExchRateTab[i], A_ExchRate_ExchDate),
					         minDateTime) >= 0)
				        valNbr++;
			        else
				        olderExistFlg = TRUE;
			        i++;
		        }

			    if (valNbr > 0)
			    {
			        *exchRateNbr = valNbr;

			        /* Alloc temporary exchange rate table */
			        if ((exchRateTabTmp = (DBA_DYNFLD_STP*)
				             CALLOC(valNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
			        {
					    FREE(allExchRateTab);
					    MSG_RETURN(RET_MEM_ERR_ALLOC);
			        }

			        for (i=0; i<valNbr; i++)
					    exchRateTabTmp[i] = allExchRateTab[firstExchRate+i];
			    }
			    else if (olderExistFlg == TRUE)
			    {
			        *exchRateNbr =    0;
			        exchRateTabTmp = NULL;
			    }
			    else
			    {
			        selFromDb = TRUE;
		    	}
			    FREE(allExchRateTab);
		    }
	    }
        /* PMSTA-13295 - JPP - 20120207 *
	    else
	    {
		    selFromDb = TRUE;
	    }
        */
	}
	else
	{
	    selFromDb = TRUE;
	}


	if (selFromDb == TRUE)
	{
		if ((DBA_Select2(ExchRate, UNUSED, Sel_Arg, selArgPtr,
                             A_ExchRate, &exchRateTabTmp, UNUSED, UNUSED,
                             exchRateNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	    {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(ExchRate));
			/* REF3672 - RAK - Sel_Arg -> Sel_Arg_Id1 c'est mieux */
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
	             		entSqlName, GET_ID(selArgPtr, Sel_Arg_Id1));
			FREE_DYNST(selArgPtr, Sel_Arg);
			return(RET_DBA_ERR_NODATA);
	    }
	    *freeExchTabPtr = TRUE;

		/* REF3701 - Only for database exchange, hierarchy exchange are inversed on load. */
		/* REF1266 - It is possible to store the exchange rates in the database */
		/* inversely relative to the present method. Required for EURO.        */
		GEN_GetApplInfo(ApplExchInverseFlag, &inverseFlg);
		if (inverseFlg == TRUE)
			FIN_InverseExchRate(exchRateTabTmp, *exchRateNbr);
	}

	FREE_DYNST(selArgPtr, Sel_Arg);

	if (domainPtr != NULL &&
        GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
	{
        /* remove exchange rate more recent as end date */
        /*lint --e{661} - REF7475 - PMO - 020516 */
		for (i=0; i<*exchRateNbr &&
             DATETIME_CMP(GET_DATETIME(exchRateTabTmp[i], A_ExchRate_ExchDate),
                          refDateTime) > 0; i++);

        /*lint --e(661) - REF7475 - PMO - 020516*/
		if (i == *exchRateNbr)
		{
			if (*freeExchTabPtr == TRUE)
			{ DBA_FreeDynStTab(exchRateTabTmp, *exchRateNbr, A_ExchRate); }
			else
			{ FREE(exchRateTabTmp); }
			*exchRateTab = NULL;
			*exchRateNbr = 0;
			return(RET_SUCCEED);
		}

		firstExchRate = i;

		nb=0;

        /* remove exchange rate older as begin date */
        /*lint --e{796} - REF7475 - PMO - 020516 */
		for (i=firstExchRate; i<*exchRateNbr &&
             DATETIME_CMP(GET_DATETIME(exchRateTabTmp[i], A_ExchRate_ExchDate),
                          refDateTimeValidity) >= 0; i++);

		nb = i-firstExchRate;         /*lint !e796 - REF7475 - PMO - 020516 */

		if (nb == 0)
		{
			if (*freeExchTabPtr == TRUE)
			{ DBA_FreeDynStTab(exchRateTabTmp, *exchRateNbr, A_ExchRate); }
			else
			{ FREE(exchRateTabTmp); }
			*exchRateTab = NULL;
			*exchRateNbr = 0;
			*freeExchTabPtr = FALSE;
			return(RET_SUCCEED);
		}

	    if ((*exchRateTab=(DBA_DYNFLD_STP *) CALLOC(nb, sizeof(DBA_DYNFLD_STP)))== NULL)
		{
			if (*freeExchTabPtr == TRUE)
            { DBA_FreeDynStTab(exchRateTabTmp, *exchRateNbr, A_ExchRate); }
			else
			{ FREE(exchRateTabTmp); }
			*exchRateTab = NULL;
			*exchRateNbr = 0;
			*freeExchTabPtr = FALSE;
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		for (i=0; i<*exchRateNbr; i++)
		{
			if (i < firstExchRate || i >= firstExchRate+nb)
			{FREE_DYNST(exchRateTabTmp[i], A_ExchRate);}
			else
			{(*exchRateTab)[i-firstExchRate] = exchRateTabTmp[i];}
		}

        FREE(exchRateTabTmp);
		*exchRateNbr = nb;

	}
	else
		*exchRateTab = exchRateTabTmp;

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_GetExchValRuleIdInDomPPSPtf()
**
**  Description :   Get exchange valuation rule identifier in domain, pps or portfolio.
**                            Could return 0.
**
**  Arguments   :   domainPtr            pointer on domain
**                  extPosPtr        pointer on extended position (could be NULLDYNST)
**                  hierHead         hierarchy header pointer
**                  valRuleId         pointer on valuation rule identifier
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation   :   PMSTA01651 - DDV - 070309
**
*************************************************************************/

EXTERN RET_CODE    FIN_GetExchValRuleIdInDomPPSPtf(DBA_DYNFLD_STP      domainPtr,
												   DBA_DYNFLD_STP      extPosPtr,
												   DBA_HIER_HEAD_STP   hierHead,
												   ID_T                *valRuleId)
{

    RET_CODE     ret=RET_SUCCEED;
    DBA_DYNFLD_STP  sPtfPosSet=NULLDYNST, ptfPosSetPtr=NULLDYNST;
    DBA_DYNFLD_STP  ptfPtr=NULLDYNST;
    FLAG_T             allocFlg=FALSE;

    *valRuleId = 0; /* REF9759 - DDV - 040202 - initialisation */

    /* Get domain valuation rule */
    if (IS_NULLFLD(domainPtr, A_Domain_ExchValRuleId) == FALSE)
	{
		*valRuleId = GET_ID(domainPtr, A_Domain_ExchValRuleId);
	}

    /* if no valuatrion rule in domain look for it in PPS */
    if (*valRuleId <= 0 && extPosPtr != NULLDYNST)
    {
		if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == FALSE &&
            GET_ID(extPosPtr, ExtPos_PtfPosSetId) != 0)
        {
			if ((sPtfPosSet = ALLOC_DYNST(S_PtfPosSet)) == NULLDYNST)
            {
				MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            if ((ptfPosSetPtr = ALLOC_DYNST(A_PtfPosSet)) == NULLDYNST)
			{
				FREE_DYNST(sPtfPosSet, S_PtfPosSet);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
			}
			COPY_DYNFLD(sPtfPosSet, S_PtfPosSet, S_PtfPosSet_Id,
                             extPosPtr, ExtPos, ExtPos_PtfPosSetId);
            if (DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, sPtfPosSet,
                              A_PtfPosSet, &ptfPosSetPtr,
                              UNUSED, UNUSED) != TRUE)
			{
				FREE_DYNST(sPtfPosSet, S_PtfPosSet);
                FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
                return(RET_DBA_ERR_NODATA);
			}
			*valRuleId = GET_ID(ptfPosSetPtr, A_PtfPosSet_ExchValRuleId);
			FREE_DYNST(sPtfPosSet, S_PtfPosSet);
            FREE_DYNST(ptfPosSetPtr, A_PtfPosSet);
        }
	}

    /* if no valuatrion rule in domain look for it in Portfolio */
    if (*valRuleId <= 0 && extPosPtr != NULLDYNST)
    {
		if (GET_EXTENSION_PTR(extPosPtr, ExtPos_A_Ptf_Ext) != NULL)
		{
			ptfPtr = *(GET_EXTENSION_PTR(extPosPtr,ExtPos_A_Ptf_Ext));
			*valRuleId = GET_ID(ptfPtr, A_Ptf_ExchValRuleId);
		}
		else if (GET_ID(extPosPtr,ExtPos_PtfId) > 0)
		{
			if (DBA_GetPtfById(GET_ID(extPosPtr, ExtPos_PtfId), FALSE, &allocFlg,
                                     &ptfPtr, hierHead, UNUSED,UNUSED) != RET_SUCCEED)
			{
				return(RET_DBA_ERR_NODATA);
			}
            *valRuleId = GET_ID(ptfPtr, A_Ptf_ExchValRuleId);

            if (allocFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
		}
    }
    return(ret);
}


/************************************************************************
**      END  finexch.c                                          UNICIBLE
*************************************************************************/

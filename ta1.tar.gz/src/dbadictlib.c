/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBADICTLIB_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include <limits.h>

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"

#include "fmtlib01.h"   /* For GUI structures and for the FAMOUS function */
#include "ope.h"
#include "ddlgen.h"


#include "dbiconnection.h"
#include "dbacurr.hpp"

#include <set>

using namespace std;

/************************************************************************
**      External entry points
**
**
**
*************************************************************************/
extern int EV_AAAInstallLevel;
extern bool EV_LogFSPSecuCheck; /* PMSTA-32214 - CHU - 180731 */

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/

short	        EV_DictFctNb;
short           EV_DictFctWithFmtNb;
short	        EV_DictFctWithDocNb;
short	        EV_DictFctWithFinNb;
short	        EV_DictFctMainWithFinNb;
DICT_FCT_STP*   EV_DictFctWithFmtTab;
DICT_FCT_STP*   EV_DictFctWithDocTab;
DICT_T          EV_ServerLanguageID;

std::vector<DICT_FCT_ST>    EV_DictFctTab;

/************************************************************************
**      Static definitions & data
*************************************************************************/
static char  SV_UnknownPermValue[]    = "Unknown";
static UChar SV_UnknownUniPermValue[8] = {'U', 'n', 'k', 'n', 'o', 'w', 'n', 0}; /* REF9303 - LJE - 030912 */

/*************
** Macros for datatype table SV_DictDataTpTab
** d = DATATYPE_ENUM
**************/
#define	DICTDATATP_DICTID(d)         (SV_DictDataTpTab[d].dictId)
#define	DICTDATATP_LABEL(d)          (SV_DictDataTpTab[d].label)
#define	DICTDATATP_UNILABEL(d)       (SV_DictDataTpTab[d].uniLabel) /* REF9303 - LJE - 030912 */
#define	DICTDATATP_SQLNAME(d)        (SV_DictDataTpTab[d].sqlName)
#define	DICTDATATP_PROGN(d)          (SV_DictDataTpTab[d].progN)
#define	DICTDATATP_DATATYPE(d)       (static_cast<DATATYPE_ENUM>(SV_DictDataTpTab[d].progN))
#define	DICTDATATP_EQUIVTYPE(d)      (SV_DictDataTpTab[d].equivType)
/* PMSTA-nuodb - LJE - 190412 */
#define	DICTDATATP_EQUIVTYPESYB(d)   (SV_DictDataTpTab[d].equivTypeSyb)
#define	DICTDATATP_EQUIVTYPEORA(d)   (SV_DictDataTpTab[d].equivTypeOra)
#define	DICTDATATP_EQUIVTYPENUODB(d) (SV_DictDataTpTab[d].equivTypeNuoDB)
#define	DICTDATATP_EQUIVTYPEMSS(d)   (SV_DictDataTpTab[d].equivTypeMsSql)
#define	DICTDATATP_EQUIVTYPEPGS(d)   (SV_DictDataTpTab[d].equivTypePgs)

/*************
** Macros for function table EV_DictFctTab
** f = function dict id
**************/
#define DICTFCT_DICTID(f)        (EV_DictFctTab[f].dictId)
/* #define DICTFCT_LABEL(f)         (EV_DictFctTab[f].label) */
/* #define DICTFCT_UNILABEL(f)      (EV_DictFctTab[f].uniLabel) *//* REF9303 - LJE - 030912 */
#define DICTFCT_NAME(f)          (EV_DictFctTab[f].name)
/* #define DICTFCT_NAT(f)           (EV_DictFctTab[f].natEn)        */
/* #define DICTFCT_PARFCTDICTID(f)  (EV_DictFctTab[f].parFctDictId) */
#define DICTFCT_PROCNAME(f)      (EV_DictFctTab[f].procName)        /*  HFI-PMSTA-16351-130701  reactivate macro    */

/*************
** Macros for function table SV_DictLangTab
** l = language dict id
**************/
#define DICTLANG_CODE(l)      (SV_DictLangTab[l].code)
#define DICTLANG_DATEFMT(l)   (SV_DictLangTab[l].dateFmt)
#define DICTLANG_DECIMSEP(l)  (SV_DictLangTab[l].decimSep)
#define DICTLANG_DICTID(l)    (SV_DictLangTab[l].dictId)
#define DICTLANG_LABEL(l)     (SV_DictLangTab[l].label)
#define DICTLANG_UNILABEL(l)  (SV_DictLangTab[l].uniLabel) /* REF9303 - LJE - 030912 */
#define DICTLANG_NAME(l)      (SV_DictLangTab[l].name)
#define DICTLANG_SQLNAME(l)   (SV_DictLangTab[l].sqlName)
#define DICTLANG_THOUSSEP(l)  (SV_DictLangTab[l].thousSep)

/**** INTERNAL STRUCTURES ****/

class AaaMetaDictImpl:public AaaMetaDict
{
public:
    AaaMetaDictImpl()
    {
    };

    virtual ~AaaMetaDictImpl()
    {
        for (auto it = this->m_dictUserMap.begin(); it != this->m_dictUserMap.end(); ++it)
        {
            FREE_DYNST(it->second, GET_DYNSTENUM(it->second));
        }
    };

    AaaMetaDictImpl(const AaaMetaDictImpl &) = delete;
    AaaMetaDictImpl &operator=(const AaaMetaDictImpl &) = delete;

protected:
    friend class AaaMetaDict;

    static void load()
    {
        if (m_aaaMetaDictImplPtr == nullptr)
        {
            m_aaaMetaDictImplPtr = new AaaMetaDictImpl();
        }
    }

    static AaaMetaDictImpl &getMetaDict()
    {
        return *m_aaaMetaDictImplPtr;
    }

    static void close()
    {
        CurrenciesMap::close();
        delete m_aaaMetaDictImplPtr;
        m_aaaMetaDictImplPtr = nullptr;
    }

    OBJECT_ENUM getDictEntitySize()
    {
        return static_cast<OBJECT_ENUM>(this->m_objDictEntityVector.size());
    };

    DICT_ENTITY_STP getNewDictEntityStp(OBJECT_ENUM objectEn)
    {
        DICT_ENTITY_STP dictEntityStp = new DictEntityClass();

        this->m_mp.ownerObject(dictEntityStp);

        if (this->getDictEntitySize() > objectEn)
        {
            auto it = this->m_objDictEntityVector[static_cast<unsigned int>(objectEn)];
            this->m_mp.removeObject(it);
            delete it;
            this->m_objDictEntityVector[static_cast<unsigned int>(objectEn)] = dictEntityStp;
        }
        else
        {
            assert(this->getDictEntitySize() == objectEn);
            this->m_objDictEntityVector.push_back(dictEntityStp);
        }

        return dictEntityStp;
    };

    std::vector<DICT_ENTITY_STP> &getDictEntityVector()
    {
        return this->m_objDictEntityVector;
    }

    void allocObjProcLstPtr(size_t size)
    {
        this->m_objProcLstPtr.clear();
        this->m_objProcLstPtr.reserve(size);
        this->m_objProcLstPtr.resize(size);
    }

    void reallocObjProcLstPtr(size_t size)
    {
        size_t oldSize = this->m_objProcLstPtr.size();
        this->m_objProcLstPtr.reserve(size);

        for (size_t i = oldSize; i < size; i++)
        {
            this->m_objProcLstPtr.push_back((DBA_PROC_STP)this->m_mp.calloc(1, sizeof(DBA_PROC_ST)));

            this->m_objProcLstPtr.back()[0].server          = SqlServer;
            this->m_objProcLstPtr.back()[0].connection      = Synchronous;
            this->m_objProcLstPtr.back()[0].action          = NullAction;
            this->m_objProcLstPtr.back()[0].subObj          = UNUSED;
            this->m_objProcLstPtr.back()[0].inputDynStPtr   = &NullDynSt;
            this->m_objProcLstPtr.back()[0].outputDynStPtr  = &NullDynSt;
            this->m_objProcLstPtr.back()[0].priority        = UNUSED;
            this->m_objProcLstPtr.back()[0].procName        = "";
            this->m_objProcLstPtr.back()[0].procParamDefPtr = UNUSED;
            this->m_objProcLstPtr.back()[0].optiIdx         = NullOpti;
        }
    }

    void setObjProcLstStp(OBJECT_ENUM objectEn, DBA_PROC_STP procStp)
    {
        if (this->m_objProcLstPtr.size() > static_cast<size_t>(objectEn))
        {
            this->m_objProcLstPtr[static_cast<size_t>(objectEn)] = procStp;
        }
    }

    void setObjProcLstStp(OBJECT_ENUM objectEn, size_t size)
    {
        if (this->m_objProcLstPtr.size() > static_cast<size_t>(objectEn))
        {
            this->m_objProcLstPtr[static_cast<size_t>(objectEn)] = (DBA_PROC_STP)this->m_mp.calloc(size, sizeof(DBA_PROC_ST));
        }
    }

    DBA_PROC_STP  getObjProcLstStp(OBJECT_ENUM objectEn)
    {
        if (this->m_objProcLstPtr.size() > static_cast<size_t>(objectEn))
        {
            return this->m_objProcLstPtr[static_cast<size_t>(objectEn)];
        }
        return nullptr;
    }

    std::map<std::string, DBA_DYNFLD_STP> &getDictUserMap()
    {
        return this->m_dictUserMap;
    }

    std::map<std::string, DBA_DYNST_ENUM> &getDynStByNameMap()
    {
        return this->m_dynStByNameMap;
    }

    MemoryPool   &getMemoryPool()
    {
        return this->m_mp;
    }

    Lock   &getLock()
    {
        return this->m_lock;
    }

    MemoryPool                            m_mp;
    Lock                                  m_lock;
    std::vector<DICT_ENTITY_STP>          m_objDictEntityVector;    /* Own the dict_entity structures */
    std::vector<DBA_PROC_STP>             m_objProcLstPtr;
    std::map<string, DBA_DYNFLD_STP>      m_dictUserMap;
    std::map<std::string, DBA_DYNST_ENUM> m_dynStByNameMap;

    private:
        static AaaMetaDictImpl          *m_aaaMetaDictImplPtr;
};

AaaMetaDictImpl *AaaMetaDictImpl::m_aaaMetaDictImplPtr = nullptr;

AaaMetaDict::AaaMetaDict()
{
}

AaaMetaDict::~AaaMetaDict()
{
}

void AaaMetaDict::load()
{
    return AaaMetaDictImpl::load();
}

AaaMetaDict &AaaMetaDict::getMetaDict()
{
    return AaaMetaDictImpl::getMetaDict();
}

void AaaMetaDict::close()
{
    return AaaMetaDictImpl::close();
}

std::vector<DICT_ENTITY_STP> &AaaMetaDict::getDictEntityVector()
{
    return AaaMetaDictImpl::getMetaDict().getDictEntityVector();
}

OBJECT_ENUM AaaMetaDict::getDictEntitySize()
{
    return AaaMetaDictImpl::getMetaDict().getDictEntitySize();
}

DICT_ENTITY_STP AaaMetaDict::getNewDictEntityStp(OBJECT_ENUM objectEn)
{
    return AaaMetaDictImpl::getMetaDict().getNewDictEntityStp(objectEn);
}

void AaaMetaDict::allocObjProcLstPtr(size_t size)
{
    AaaMetaDictImpl::getMetaDict().allocObjProcLstPtr(size);
}

void AaaMetaDict::reallocObjProcLstPtr(size_t size)
{
    AaaMetaDictImpl::getMetaDict().reallocObjProcLstPtr(size);
}

void AaaMetaDict::setObjProcLstStp(OBJECT_ENUM objectEn, DBA_PROC_STP procStp)
{
    AaaMetaDictImpl::getMetaDict().setObjProcLstStp(objectEn, procStp);
}

void AaaMetaDict::setObjProcLstStp(OBJECT_ENUM objectEn, size_t size)
{
    AaaMetaDictImpl::getMetaDict().setObjProcLstStp(objectEn, size);
}

DBA_PROC_STP AaaMetaDict::getObjProcLstStp(OBJECT_ENUM objectEn)
{
    return AaaMetaDictImpl::getMetaDict().getObjProcLstStp(objectEn);
}

std::map<std::string, DBA_DYNFLD_STP> &AaaMetaDict::getDictUserMap()
{
    return AaaMetaDictImpl::getMetaDict().getDictUserMap();
}

std::map<std::string, DBA_DYNST_ENUM> &AaaMetaDict::getDynStByNameMap()
{
    return AaaMetaDictImpl::getMetaDict().getDynStByNameMap();
}

MemoryPool &AaaMetaDict::getMemoryPool()
{
    return AaaMetaDictImpl::getMetaDict().getMemoryPool();
}

Lock &AaaMetaDict::getLock()
{
    return AaaMetaDictImpl::getMetaDict().getLock();
}

static std::vector<DICT_LANG_ST>               SV_DictLangTab;
static std::vector<DICT_DATATP_ST>             SV_DictDataTpTab;

static std::map<DICT_T, DICT_ENTITY_STP>       SV_DictDictEntityMap;
static std::map<std::string, DICT_ENTITY_STP>  SV_MdSqlNameDictDictEntityMap;
static std::map<std::string, DICT_ENTITY_STP>  SV_DbSqlNameDictDictEntityMap;
static std::map<DICT_T, OBJECT_ENUM>           SV_DictToObjMap;

static std::map<DICT_T, DICT_ATTRIB_STP>       SV_DictDictAttribMap;

static std::map<std::string, DICT_ENTITY_STP>  SV_SrcMdSqlNameDictDictEntityMap;

STATIC RET_CODE DBA_SetDfltEntityFld2(OBJECT_ENUM objEn, DBA_DYNST_ENUM dynSt, DBA_DYNFLD_STP stPtr, bool skipDbFld); /* PMSTA-42198 - DDV - 201028 */

/************************************************************************
**      Functions
*************************************************************************/

void DBA_DYNST::init(OBJECT_ENUM objEn)
{
    this->entity                   = objEn;
    this->custEntityObj            = objEn;
    this->codifIdIdx               = Null_Dynfld;
    this->authUpdFlgIdx            = Null_Dynfld;
    this->authDelFlgIdx            = Null_Dynfld;
    this->authReasonIdx            = Null_Dynfld;
    this->authUpdSecuIdx           = Null_Dynfld;
    this->authDelSecuIdx           = Null_Dynfld;
    this->meRecLocFldIdx           = Null_Dynfld;
    this->internalFldIdx           = Null_Dynfld;
    this->foreignKeyFldIdx         = Null_Dynfld;
    this->custFldNbr               = 0;
    this->precompFldNbr            = 0;
    this->logicalFldNbr            = 0;
    this->firstTechFldPos          = 0;
    this->dictEntityStp            = nullptr;
    this->maxLenWithTextFld        = Null_Dynfld;
    this->maxLenWithoutTextFld     = Null_Dynfld;
    this->hierEltIdxFldIdx         = Null_Dynfld;
    this->changeSetOldRecExtFldIdx = Null_Dynfld;
    this->changeSetNewRecExtFldIdx = Null_Dynfld;
    this->newVerDynStEn            = NullDynSt;
    this->fldNbr                   = 0;
    this->noMDFldNbr               = 0;
    this->techFldNbr               = 0;
    this->fixFldNbr                = 0;
    this->precompEntityObj         = NullEntity;
    this->nbEntry                  = 0;
    this->dynStDefPtr              = NULL;
    this->allocCpt                 = 0;
};


/************************************************************************
*
*  Function          : DictSprocParamClass
*
*  Description       :
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-49178 - LJE - 220926
*  Last modification :
*
*************************************************************************/

void DictSprocParamClass::setDataType(const std::string& dataTypeStr)
{
    this->m_dataTypeName = dataTypeStr;
    this->m_dataTypeEn = DBA_GetDatatypeEnumByCode(this->m_dataTypeName.c_str());
}
void DictSprocParamClass::setDataType(DICT_T dataTypeDictId)
{
    this->m_dataTypeEn = DATATYPE_DICT_TO_ENUM(dataTypeDictId);
}
void DictSprocParamClass::setDataType(DATATYPE_ENUM dataTypeDictEn)
{
    this->m_dataTypeEn = dataTypeDictEn;
    this->m_dataTypeName = DBA_GetDataTypeSQLNameC(dataTypeDictEn);
}

std::string DictSprocParamClass::getDataTypeStr()
{
    return this->m_dataTypeName;
}
DICT_T DictSprocParamClass::getDataTypeDictId()
{
    return DATATYPE_ENUM_TO_DICT(this->m_dataTypeEn);
}

DATATYPE_ENUM DictSprocParamClass::getDataTypeEn()
{
    return this->m_dataTypeEn;
}

/************************************************************************
*
*  Function          : DICT_IsValidEntity()
*
*  Description       :
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-26108 - LJE - 170911
*  Last modification :
*
*************************************************************************/
bool DICT_IsValidEntity(OBJECT_ENUM objectEn)
{
    if (objectEn <= LASTENTITYOBJECT &&
        objectEn != NullEntity &&
        objectEn < AaaMetaDict::getDictEntitySize())
    {
        return true;
    }

    return false;
}

/************************************************************************
*
*  Function          : DICT_AddNewDictEntity()
*
*  Description       :
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-26108 - LJE - 170911
*  Last modification :
*
*************************************************************************/
DICT_ENTITY_ST &DICT_AddNewDictEntity(DICT_T entDictId, OBJECT_ENUM objectEn, const std::string &mdSqlName, const std::string &dbSqlName, bool bSourceEnv)
{
    DICT_ENTITY_STP dictEntityStp = AaaMetaDict::getNewDictEntityStp(objectEn);

    dictEntityStp->entDictId = entDictId;
    dictEntityStp->objectEn  = objectEn;
    strcpy(dictEntityStp->mdSqlName, mdSqlName.c_str());
    strcpy(dictEntityStp->dbSqlName, dbSqlName.c_str());

    SV_DictDictEntityMap.insert(make_pair(entDictId, dictEntityStp));

    if (entDictId != 0)
    {
        SV_DictToObjMap.insert(make_pair(entDictId, objectEn));
    }
    else
    {
        SV_DictToObjMap.insert(make_pair(entDictId, NullEntity));
    }

    if (LASTENTITYOBJECT < objectEn)
    {
        LASTENTITYOBJECT = objectEn;
    }

    if (bSourceEnv == false)
    {
        if (mdSqlName.empty() == false)
        {
            SV_MdSqlNameDictDictEntityMap.insert(make_pair(mdSqlName, dictEntityStp));
        }
        if (dbSqlName.empty() == false)
        {
            SV_DbSqlNameDictDictEntityMap.insert(make_pair(upper(dbSqlName), dictEntityStp));
        }
    }
    else
    {
        SV_SrcMdSqlNameDictDictEntityMap.insert(make_pair(mdSqlName, dictEntityStp));
    }

    return *dictEntityStp;
}

/************************************************************************
*
*  Function          : DBA_MoveDictEntityToSource()
*
*  Description       :
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-37374 - LJE - 210414
*  Last modification :
*
*************************************************************************/
void DBA_MoveDictEntityToSource()
{
    SV_SrcMdSqlNameDictDictEntityMap = SV_MdSqlNameDictDictEntityMap;

    for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
    {
        (*it)->finish();
    }

    AaaMetaDict::getDictEntityVector().clear();
    SV_DictDictEntityMap.clear();
    SV_MdSqlNameDictDictEntityMap.clear();
    SV_DbSqlNameDictDictEntityMap.clear();
    SV_DictToObjMap.clear();
    SV_DictDictAttribMap.clear();
    LASTENTITYOBJECT = 0;

    DICT_AddNewDictEntity(0, InvalidEntity, "invalid_entity", "invalid_entity");
}

/************************************************************************
*
*  Function          : DICT_GetDictEntityVector()
*
*  Description       :
*
*  Arguments         :
*
*  Return            :
*
*  Creation date     : PMSTA-26108 - LJE - 170911
*  Last modification :
*
*************************************************************************/
std::vector<DICT_ENTITY_STP> &DICT_GetDictEntityVector()
{
    return AaaMetaDict::getDictEntityVector();
}


/************************************************************************
**  Function             : DBA_GetVshEntityInfo()
**
**  Description          : Get label for received entity (entityRef given)
**
**  Arguments            : vshEntity pointer on structure to fill.
**                         output : label
**
**  Return               : RET_SUCCEED or error code
**
**  Modif.               :  ROI - 000413 - REF4497
**                          PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
**
*************************************************************************/
RET_CODE DBA_GetVshEntityInfo(VSH_ENTITY_INFO_STP vshEntity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(vshEntity->entityRef);

    if (dictEntityStp)
    {
        strcpy(vshEntity->label, dictEntityStp->labelStr.c_str());

        u_strcpy(vshEntity->uniLabel, dictEntityStp->uniLabelStr.getTerminatedBuffer());        /* PMSTA-34279 - 211218 - PMO */
        strcpy(vshEntity->sqlName, dictEntityStp->mdSqlName);
        return(RET_SUCCEED);
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GetVshEntityInfo", "entityRef");
        return(RET_GEN_ERR_INVARG);
    }
}

/************************************************************************
*
*  Function          : DBA_GetDictLangTab()
*
*  Description       : Get language number
*
*  Arguments         :
*
*  Return            : language number
*
*  Creation date     : PMSTA-nuodb - LJE - 190508
*  Last modification :
*
*************************************************************************/
std::vector<DICT_LANG_ST> &DBA_GetDictLangTab()
{
    return(SV_DictLangTab);
}

/************************************************************************
**  Function             : DBA_GetDictLangStruct()
**
**  Description          : Fill language dynamic structure depending on
**                         received language identifier.
**
**  Arguments            : langDictId  language identifier
**                         dictLang    pointer on language dynamic structure
**
**  Return               : RET_SUCCEED or error code
**
**  Modif		 : DVP338 - RAK - 970203
**
*************************************************************************/
RET_CODE DBA_GetDictLangStruct(DICT_T langDictId, DBA_DYNFLD_STP dictLang)
{
    size_t      i;
    RET_CODE ret;

    if (SV_DictLangTab.size() == 0)
    {
        return(RET_GEN_INFO_NODATA);
    }

    if (dictLang == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                     "DBA_GetDictLangStruct", "structure pointer");
        return(RET_GEN_ERR_INVARG);
    }

    /* Search record with received language dict id */
    for (i = 0, ret = RET_DBA_ERR_MD;
         i < SV_DictLangTab.size() && ret == RET_DBA_ERR_MD; i++)
    {
        if (DICTLANG_DICTID(i) == langDictId)
        {
            SET_DICT(dictLang, A_DictLang_Id, DICTLANG_DICTID(i));
            SET_CODE(dictLang, A_DictLang_Cd, DICTLANG_CODE(i));
            SET_NAME(dictLang, A_DictLang_Name, DICTLANG_NAME(i)); /* DLA - PMSTA09887 - 101116 */
            if (ICU4AAA_SQLServerUTF8)
            {
                SET_UINFO(dictLang, A_DictLang_Denom, DICTLANG_UNILABEL(i)); /* REF9303 - LJE - 030904 */
            }
            else
            {
                SET_INFO(dictLang, A_DictLang_Denom, DICTLANG_LABEL(i)); /* REF9303 - LJE - 030904 */
            }

            SET_SYSNAME(dictLang, A_DictLang_SqlName, DICTLANG_SQLNAME(i));
            SET_NAME(dictLang, A_DictLang_ThousSep, DICTLANG_THOUSSEP(i));	/* DVP338 */
            SET_NAME(dictLang, A_DictLang_DecimSep, DICTLANG_DECIMSEP(i));	/* DVP338 */
            SET_NAME(dictLang, A_DictLang_DateFmt, DICTLANG_DATEFMT(i));	/* DVP338 */
            ret = RET_SUCCEED;
        }
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        MSG_SendMesg(ret, 0, FILEINFO);

    return(ret);
}


/************************************************************************
**  Function             : DBA_GetDictDataTypeInfo()
**
**  Description          : Get datatype list
**
**  Arguments            : pentinfo structure which will be filled.
**
**  Warning !!           : parent function must deallocate the pointer
**
**  Return               : RET_SUCCEED or error code
**
**	Modif.		         :  HFI-PMSTA-16351-130522
**
*************************************************************************/
RET_CODE DBA_GetDictDataTypeInfo (ENTITIES_INFO_STP pentinfo)
{
    int i;

    /* Update entities informations */
    pentinfo->entityNb = static_cast<int>(SV_DictDataTpTab.size());

    if ((pentinfo->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(pentinfo->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
    {
        pentinfo->entityNb = 0;
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i = 0; i < pentinfo->entityNb; i++)
    {
        pentinfo->entityTab[i].id = DICTDATATP_DICTID(i);
        strcpy(pentinfo->entityTab[i].sqlName, DICTDATATP_SQLNAME(i));
        strcpy(pentinfo->entityTab[i].label, DICTDATATP_LABEL(i));
        u_strcpy(pentinfo->entityTab[i].uniLabel, DICTDATATP_UNILABEL(i));
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_GetDictLangInfo()
**
**  Description          : Get language list
**
**  Arguments            : langInfoPtr  structure which will be filled.
**
**  Warning !!           : parent function must deallocate the pointer
**
**  Return               : RET_SUCCEED or error code
**
**	Modif.		:	ROI - 000413 - REF4497
**
*************************************************************************/
RET_CODE DBA_GetDictLangInfo(ENTITIES_INFO_STP langInfoPtr)
{
    int i;

    /* Update entities informations */
    langInfoPtr->entityNb = static_cast<int>(SV_DictLangTab.size());

    if ((langInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
        CALLOC(langInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
    {
            langInfoPtr->entityNb = 0;
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<langInfoPtr->entityNb; i++)
    {
        langInfoPtr->entityTab[i].id = DICTLANG_DICTID(i);
        strcpy(langInfoPtr->entityTab[i].sqlName, DICTLANG_CODE(i));	/* ROI - 000413 - REF4497 */
        strcpy(langInfoPtr->entityTab[i].label, DICTLANG_LABEL(i));
        u_strcpy(langInfoPtr->entityTab[i].uniLabel, DICTLANG_UNILABEL(i)); /* REF9303 - LJE - 030912 */
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CheckDictFctAdmAuth
**
**  Description :   Get administration authorization for given entity.
**
**  Arguments   :   DICT_FCT_ENUM fctEn,
**		    OBJECT_ENUM entity
**
**  Return      :   FLAG_T
**
**  Cr�ation	:   XFH-REF207-971003
**  Modif       :   FIH-REF10209-040429 Do not used anymore the given function
**
*************************************************************************/
FLAG_T	DBA_CheckDictFctAdmAuth (OBJECT_ENUM entity)
{
    DICT_FCT_STP    fctStp;
    DICT_T          entityDictId;
    FLAG_T          found;
    size_t          i;
    DICT_T          fctEn;


    /* FPL-REF10253-040504 centralize code in fct DBA_GetAdmDictFct */
    DBA_GetAdmDictFct(entity, &entity, &fctEn); /*  FPL-PMSTA12499-110818 remove cast on DICT_FCT_ENUM* */

    /* Init local variables */
    DBA_GetDictId(entity, &entityDictId);
    found = FALSE;

    /* Loop looking for given function */
    for (i = 0; (i < EV_DictFctTab.size()) && (found == FALSE); i++)
    {
      /* Init loop variable */
      fctStp = &(EV_DictFctTab[i]);

      /* Check if current function correspond */
      if ((fctStp->dictId == fctEn) &&
          (fctStp->entityDictId == entityDictId)
         )
        found = TRUE;
    }

    return found;
}

/************************************************************************
**  Function             : DBA_GetCustFldNbr()
**
**  Description          : Return customer field number for the received
**                         entity, read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : customer field number for the entity
**
*************************************************************************/
INT_T DBA_GetCustFldNbr(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        return dictEntityStp->custNbr;
    }

    return(0);
}

/************************************************************************
**  Function             : DBA_GetFirstCustFld()
**
**  Description          : Return customer field number for the received
**                         entity, read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : customer field number for the entity
**
*************************************************************************/
INT_T DBA_GetFirstCustFld(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp != nullptr)
    {
        return dictEntityStp->firstCustPos;
    }

    return(0);
}

/************************************************************************
**  Function             : DBA_GetPrecompFldNbr()
**
**  Description          : Return precomputed field number for the received
**                         entity, read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : customer field number for the entity
**
*************************************************************************/
INT_T DBA_GetPrecompFldNbr(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        return dictEntityStp->precompNbr;
    }

    return(0);
}

/************************************************************************
**  Function             : DBA_GetMainFlag()
**
**  Description          : Return main flag for the received entity,
**                         read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : main flag
**
*************************************************************************/
FLAG_T DBA_GetMainFlag(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        return dictEntityStp->mainFlg;
    }

    return(FALSE);
}

/************************************************************************
**  Function             : DBA_GetPkRuleEn()
**
**  Description          : Return primary key rule for the received entity,
**                         read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : main flag
**
*************************************************************************/
PK_RULE_ENUM DBA_GetPkRuleEn(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        return dictEntityStp->pkRuleEn;
    }

    return(PkRule_Undefined);
}

/************************************************************************
**  Function             : DBA_GetPrimaryAttrib()
**
**  Description          : Return primary attribute
**                         entity, read the meta-dictionary.
**
**  Arguments            : entity    OBJECT_ENUM member
**                         attribNbr pointer on attribute(s) number
**                         attribPtr pointer on attribute(s) data
**
**  Return               : RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetPrimaryAttrib(OBJECT_ENUM       entity,
                              int*              attribNbr,
                              DICT_ATTRIB_STP** attribPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp != nullptr)
    {
        if (attribNbr != nullptr)
        {
            (*attribNbr) = dictEntityStp->primKeyNbr;
        }

        if (attribPtr != nullptr)
        {
            (*attribPtr) = dictEntityStp->primKeyTab;
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_GetTypingNat()
**
**  Description          : Return typing nature the received entity,
**                         read the meta-dictionary.
**
**  Arguments            : entity : an OBJECT_ENUM member
**
**  Return               : typing nature for the entity
**
*************************************************************************/
TYPINGNAT_ENUM DBA_GetTypingNat(OBJECT_ENUM entity)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        return dictEntityStp->tpNatEn;
    }

    return(NoTyping);
}

/************************************************************************
**
**  Function    :   DICT_GetAttribDataType()
**
**  Description :   number of attribute of the entity
**
**  Argument    :   entityRef   entity reference
**
**  Return      :   number of attribute of the entity
**
**  Creation    :   PMSTA07964 - LJE - 090306
**
*************************************************************************/
DATATYPE_ENUM DICT_GetAttribDataType(OBJECT_ENUM entityRef, int fieldPos)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, fieldPos);

    if (dictAttribStp)
        return dictAttribStp->dataTpProgN;
    else
        return NullDataType;
}

/************************************************************************
**  Function             : DBA_GetBusinessAttrib()
**
**  Description          : Return business attribute
**                         entity, read the meta-dictionary.
**
**  Arguments            : entity    OBJECT_ENUM member
**                         attribNbr pointer on attribute(s) number
**                         attribPtr pointer on attribute(s) data
**
**  Return               : RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetBusinessAttrib(OBJECT_ENUM entity,
                               int *attribNbr,
                               DICT_ATTRIB_STP  **attribPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    if (dictEntityStp)
    {
        (*attribNbr) = dictEntityStp->bkAttrNbr;
        (*attribPtr) = dictEntityStp->bkAttr;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_GetAttribEquivDataType()
**
**  Description          : Return EquivTypeSqlnameC for a given DATATYPE_ENUM,
**                         based on max_db_len_n the attribute
**
**  Arguments            : type : DATATYPE_ENUM member, unsigned int maxDbLenN
**
**  Return               : string - EquivType if success, NULL elsewhere
**
**  Creation             : PMSTA-38801 - JJN - 200202
**  Modification         : PMSTA-37366 - LJE - 200402
**
*************************************************************************/
string DBA_GetAttribEquivDataType(DATATYPE_ENUM dataTpProgN, DBA_RDBMS_ENUM rdbmsEn, unsigned int maxDbLenN)
{
    string equivTp = DBA_GetDataTypeEquivType(dataTpProgN, rdbmsEn);

    if ((IS_STRING_TYPE(dataTpProgN) == TRUE ||
         IS_USTRING_TYPE(dataTpProgN) == TRUE))
    {
        if ((rdbmsEn == MSSql ||
             (rdbmsEn == Sybase && ICU4AAA_SQLServerUTF8 == 1)) &&
            IS_STRING_TYPE(dataTpProgN) == TRUE &&
            dataTpProgN != SysnameType &&
            dataTpProgN != LongSysnameType &&
            (rdbmsEn == MSSql || dataTpProgN != String1000Type) &&
            dataTpProgN != String2000Type &&
            dataTpProgN != String3000Type &&
            dataTpProgN != String4000Type)
        {
            auto pos = equivTp.find("(");
            std::string  lenValueStr = equivTp.substr(pos + 1, equivTp.find(")") - pos - 1);

            if (lenValueStr.find_first_of("0123456789") == std::string::npos)
            {
                return equivTp;
            }

            unsigned int maxDataTpLenN = stoi(lenValueStr);
            unsigned int newDataTpLenN = maxDataTpLenN * AL32FACTOR;

            if (maxDbLenN != 0)
            {
                maxDbLenN *= AL32FACTOR;
            }

            if (maxDbLenN > DdlGenDbi::stringLiteralMaxValue(rdbmsEn))
            {
                maxDbLenN = DdlGenDbi::stringLiteralMaxValue(rdbmsEn);
            }
            if (newDataTpLenN > DdlGenDbi::stringLiteralMaxValue(rdbmsEn))
            {
                newDataTpLenN = DdlGenDbi::stringLiteralMaxValue(rdbmsEn);
            }

            equivTp.replace(equivTp.find(to_string(maxDataTpLenN)), to_string(maxDataTpLenN).length(), to_string(newDataTpLenN));
        }

        if (maxDbLenN != 0)
        {
            auto pos = equivTp.find("(");
            std::string  lenValueStr = equivTp.substr(pos + 1, equivTp.find(")") - pos - 1);
            unsigned int maxDataTpLenN = stoi(lenValueStr);

            if (maxDbLenN < maxDataTpLenN)
            {
                equivTp.replace(equivTp.find(to_string(maxDataTpLenN)), to_string(maxDataTpLenN).length(), to_string(maxDbLenN));
            }
        }
    }

    return equivTp;
}

/************************************************************************
**  Function             : DBA_GetDataTypeEquivType()
**
**  Description          : Return EquivType for a given DATATYPE_ENUM
**
**  Arguments            : type : DATATYPE_ENUM member
**
**  Return               : pointer to EquivType if success, NULL elsewhere
**
**  Creation             : PMSTA-11505 - LJE - 110322
**
*************************************************************************/
char *DBA_GetDataTypeEquivType(DATATYPE_ENUM type, DBA_RDBMS_ENUM rdbmsEn)
{
    /* PMSTA-37366 - LJE - 200402 */
    switch (rdbmsEn)
    {
        case DBA_RDBMS_ENUM::Sybase:
            return DICTDATATP_EQUIVTYPESYB(DBA_ConvUniDataTypeToDataType(type));
            break;

        case DBA_RDBMS_ENUM::Oracle:
            return DICTDATATP_EQUIVTYPEORA(DBA_ConvUniDataTypeToDataType(type));
            break;

        case DBA_RDBMS_ENUM::Nuodb:
            return DICTDATATP_EQUIVTYPENUODB(DBA_ConvUniDataTypeToDataType(type));
            break;

        case DBA_RDBMS_ENUM::MSSql:
            return DICTDATATP_EQUIVTYPEMSS(DBA_ConvUniDataTypeToDataType(type));
            break;

        case DBA_RDBMS_ENUM::PostgreSQL:
            return DICTDATATP_EQUIVTYPEPGS(DBA_ConvUniDataTypeToDataType(type));
            break;

        case DBA_RDBMS_ENUM::QtHttp:
        case DBA_RDBMS_ENUM::UnknownRdbms:
        default:
            return DICTDATATP_EQUIVTYPE(DBA_ConvUniDataTypeToDataType(type));
    }
}

/************************************************************************
**  Function             : DBA_GetDataTypeAlignSize()
**
**  Description          : Return size of alignment for a given DATATYPE_ENUM
**
**  Arguments            : type : DATATYPE_ENUM member
**
**  Return               :
**
**  Creation             : PMSTA-23226 - LJE - 160526
**
*************************************************************************/
size_t DBA_GetDataTypeAlignSize(DATATYPE_ENUM dataType, size_t nameLen, size_t maxLen, bool bGeneric, char *szAlignPos)
{
    size_t alignNbr;
    switch (dataType)
    {
        case IdType:
            if (bGeneric)
            {
                alignNbr = 20;
            }
            else
            {
                alignNbr = 17;
            }
            break;

        case IntType:
            alignNbr = 17;
            break;

        case MaskType:
            alignNbr = 11;
            break;

        case TinyintType:
            alignNbr = 3;
            break;

        case NumberType:
            if (bGeneric)
            {
                alignNbr = 27;
            }
            else
            {
                alignNbr = 24;
            }
            break;

        case DatetimeType:
            alignNbr = 31;
            break;

        default:
            alignNbr = maxLen;
    }

    if (alignNbr < nameLen)
    {
        alignNbr = nameLen;
    }

    if (GET_CTYPE(dataType) == CharPtrCType ||
        GET_CTYPE(dataType) == TextPtrCType ||
        GET_CTYPE(dataType) == UniCharPtrCType ||
        GET_CTYPE(dataType) == UniTextPtrCType)
    {
        szAlignPos[0] = 0;
    }
    else
    {
        strcpy(szAlignPos, "-");
    }

    if (alignNbr > 255)
    {
        alignNbr = 255;
    }

    return alignNbr;
}

/************************************************************************
**  Function             : DBA_GetDataTypeFromEquivType()
**
**  Description          : Return DATATYPE_ENUM for a given EquivType (Oracle or Sybase)
**
**  Arguments            :
**
**  Return               : DATATYPE_ENUM member
**
**  Creation             : PMSTA-23226 - LJE - 160526
**
*************************************************************************/
DATATYPE_ENUM DBA_GetDataTypeFromEquivType(DBA_RDBMS_ENUM rdbmsVendor, const string &nativType, int precision, int scale)
{
    DATATYPE_ENUM dataType = NullDataType;

    if (nativType.empty())
    {
        return dataType;
    }

    string        searchDataType = nativType;

    if (precision > 0)
    {
        searchDataType += "(" + SYS_ToString(precision);

        if (scale >= 0)
        {
            searchDataType += "," + SYS_ToString(scale);
        }
        else if (rdbmsVendor == Oracle)
        {
            searchDataType += " char";
        }


        searchDataType += ")";
    }


    for (size_t i = 0; i < SV_DictDataTpTab.size(); i++)
    {
        char *toCheck;

        switch (rdbmsVendor)
        {
            case Sybase:
                toCheck = SV_DictDataTpTab[i].equivTypeSyb;
                break;

            case Oracle:
                toCheck = SV_DictDataTpTab[i].equivTypeOra;
                break;

            case Nuodb:
                toCheck = SV_DictDataTpTab[i].equivTypeNuoDB;
                break;

            case MSSql:
                toCheck = SV_DictDataTpTab[i].equivTypeMsSql;
                break;

            case PostgreSQL:
                toCheck = SV_DictDataTpTab[i].equivTypePgs;
                break;

            default:
                toCheck = nullptr;
        }

        if (toCheck != nullptr && searchDataType.compare(toCheck) == 0)
        {
            dataType = (DATATYPE_ENUM)SV_DictDataTpTab[i].progN;
        }
    }

    if (dataType == NullDataType && scale < 0 && nativType != "number")
    {
        if (precision <= 1000)
            dataType = String1000Type;
        else if (precision == 2000)
            dataType = String2000Type;
        else if (precision == 3000)
            dataType = String3000Type;
        else if (precision == 4000)
            dataType = String4000Type;
        else if (precision == 7000)
            dataType = String7000Type;
        else if (precision == 15000)
            dataType = String15000Type;
        else
            dataType = TextType;
    }

    return dataType;
}

/************************************************************************
**  Function             : DBA_GetDataTypeSQLNameC()
**
**  Description          : Return SQLNameC for a given DATATYPE_ENUM
**
**  Arguments            : type : DATATYPE_ENUM member
**
**  Return               : pointer to SQLNameC if success, NULL elsewhere
*************************************************************************/
const char *DBA_GetDataTypeSQLNameC(DATATYPE_ENUM type)
{
    if (type != NullDataType && static_cast<size_t>(type) < SV_DictDataTpTab.size())
    {
        return DICTDATATP_SQLNAME(DBA_ConvUniDataTypeToDataType(type));
    }
    
    if (type == SysRefCursorType)
    {
        return("SYS_REFCURSOR");
    }
    if (type == RecordType)
    {
        return("record");
    }
    if (type == TriggerType)
    {
        return("trigger");
    }
    if (type == ChainedTypeType)
    {
        return("ChainedTypeType");
    }
    if (type == ExtensionType)
    {
        return("ExtensionType");
    }

    return ("NullDataType");
}

/************************************************************************
**  Function             : DBA_GetBusiIndex()
**
**  Description          : Return prog_n for unique visual key
**
**  Arguments            : object : OBJECT_ENUM member
**
**  Return               : prog_n or -1
*************************************************************************/
int DBA_GetBusiIndex(OBJECT_ENUM object)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp)
    {
        int idx;

        idx = dictEntityStp->visUnKeyIdx;

        if (idx < 0)
            return(-1);
        else
            return(dictEntityStp->attr[idx]->progN);
    }

    return(-1);
}

/************************************************************************
**  Function             : DBA_GetShortBusiIndex()
**
**  Description          : Return short index for unique visual key
**
**  Arguments            : object : OBJECT_ENUM member
**
**  Return               : short index or -1
*************************************************************************/
int DBA_GetBusiShortIndex(OBJECT_ENUM object)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp)
    {
        int idx;

        idx = dictEntityStp->visUnKeyIdx;

        if (idx < 0)
            return(-1);
        else
            return(dictEntityStp->attr[idx]->shortIdx);
    }

    return(-1);
}

/************************************************************************
**  Function             : DBA_GetDictTechKey()
**
**  Description          : Return technical key for received entity
**                         object (data type, entity, language, function) and
**                         business identifier.
**
**  Arguments            : object : OBJECT_ENUM member
**                         busKey : element business identifier
**
**  Return               : technical identifier or -1
*************************************************************************/
DICT_T DBA_GetDictTechKey(OBJECT_ENUM object, char *busKey)
{
    size_t i;

    if (object == DictEntity)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(busKey);

        if (dictEntityStp)
        {
            return dictEntityStp->entDictId;
        }

        return(-1);
    }

    if (object == DictDataTp)
    {
        for (i=0; i<SV_DictDataTpTab.size(); i++)
        if (!strcmp(busKey, DICTDATATP_SQLNAME(i)))
            return(DICTDATATP_DICTID(i));

        return(-1);
    }

    if (object == DictLang)
    {
        for (i=0; i<SV_DictLangTab.size(); i++)
        if (!strcmp(busKey, DICTLANG_CODE(i)))
            return(DICTLANG_DICTID(i));

        return(-1);
    }

    if (object == DictFct)
    {
        for (i=0; i<EV_DictFctTab.size(); i++)
        if (!strcmp(busKey, DICTFCT_PROCNAME(i)))       /*  HFI-PMSTA-16351-130701  replace DICTFCT_NAME by DICTFCT_PROCNAME    */
            return(DICTFCT_DICTID(i));

        return(-1);
    }

    return(-1);
}

/************************************************************************
**  Function             : DBA_GetDictEntityUdSqlName()
**
**  Description          : Get entity sql name
**                         TODO: model that in the meta-dictionary
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return
**
**                       : REF - LJE - 040624
*************************************************************************/
const char *DBA_GetDictEntityUdSqlName(OBJECT_ENUM object)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp &&
        dictEntityStp->custAuthFlg == TRUE)
    {
        return dictEntityStp->custSqlName;
    }

    return(nullptr);
}


/************************************************************************
**
**  Function    :   DBA_GetDictAttribIdxByDictId
**
**  Description :   Return the attribute index depending on received
**                  attribute dict id.
**
**  Arguments   :   OBJECT_ENUM object, DICT_T dictId, short* idxPtr
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   ROI - 970212 - DVP200
**
*************************************************************************/
RET_CODE	DBA_GetDictAttribIdxByDictId(OBJECT_ENUM object,
                                         DICT_T dictId,
                                         short* idxPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr)
    {
        auto it = dictEntityStp->attribMap.find(dictId);

        if (it != dictEntityStp->attribMap.end())
        {
            *idxPtr = (short)it->second->progN;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_GetDictAttribByDictId
**
**  Description :   Return the attribute depending on received
**                  attribute dict id.
**
**  Arguments   :   OBJECT_ENUM object, DICT_T dictId
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA-26108 - LJE - 170926
**
*************************************************************************/
DICT_ATTRIB_STP DBA_GetDictAttribByDictId(OBJECT_ENUM object, DICT_T dictId)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr)
    {
        auto it = dictEntityStp->attribMap.find(dictId);

        if (it != dictEntityStp->attribMap.end())
        {
            return it->second;
        }
    }
    return nullptr;
}

/************************************************************************
**  Function             : DBA_GetAttributeById()
**
**  Description          : return pointer to attribute structure from
**			   attribute dict_id
**
**  Arguments            : dictId : attribute dict_id
**
**  Return               : PTR on attribSt
*************************************************************************/
DICT_ATTRIB_STP DBA_GetAttributeById(DICT_T dictId)
{
    auto it = SV_DictDictAttribMap.find(dictId);

    if (it != SV_DictDictAttribMap.end())
    {
        return it->second;
    }

    return nullptr;
}

/************************************************************************
**  Function             : DBA_GetDictAttribSt()
**
**  Description          : Return the attribute
**
**  Arguments            : object : OBJECT_ENUM member
**                         cpt    : field number
**
**  Return               : PTR on attribSt
*************************************************************************/
DICT_ATTRIB_STP DBA_GetDictAttribSt(OBJECT_ENUM object, FIELD_IDX_T cpt)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr &&
        cpt >= 0 &&
        cpt < (int)dictEntityStp->attr.size())
    {
        return dictEntityStp->attr[cpt];
    }

    return(nullptr);
}

/************************************************************************
**  Function             : DBA_GetDictAttribStByShortIdx()
**
**  Description          : Return the attribute depending on received
**                         short index
**
**  Arguments            : object : OBJECT_ENUM member
**                         idx    : short index
**
**  Return               : PTR on attribSt
*************************************************************************/
DICT_ATTRIB_STP DBA_GetDictAttribStByShortIdx(OBJECT_ENUM object, FIELD_IDX_T idx)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr)
    {
        for (auto & dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp->shortIdx == idx)
            {
                return dictAttribStp;
            }
        }
    }

    return(NULL);
}

/************************************************************************
**
**  Function    :   DBA_GetDictAttribShortIdxByIdx
**
**  Description :   Return index in S_ from given index in A_
**
**  Arguments   :   OBJECT_ENUM object, short idx
**
**  Return      :   short
**
**  Cr�ation    :   ROI - 970124 - DVP200
**
*************************************************************************/
FIELD_IDX_T DBA_GetDictAttribShortIdxByIdx(OBJECT_ENUM object, FIELD_IDX_T idx)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(object, idx);

    if (dictAttribStp != nullptr)
    {
        return dictAttribStp->shortIdx;
    }
    else
    {
        return -1;
    }
}

/************************************************************************
**  Function             : DBA_GetDictAttribCalcEn()
**
**  Description          : Return calcEn for the attribute
**
**  Arguments            : object : OBJECT_ENUM member
**                         cpt    : field number
**
**  Return               : string or NULL
*************************************************************************/
DICTATTR_ENUM DBA_GetDictAttribCalcEn(OBJECT_ENUM object, int cpt)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(object, cpt);

    if (dictAttribStp != nullptr)
    {
        return dictAttribStp->calcEn;
    }
    else
    {
        return DictAttr_Physical;
    }
}

/************************************************************************
**  Function             : DBA_GetDictAttribSqlName()
**
**  Description          : Return sqlname for the attribute
**
**  Arguments            : object : OBJECT_ENUM member
**                         cpt    : field number
**
**  Return               : string or NULL
*************************************************************************/
const char *DBA_GetDictAttribSqlName(OBJECT_ENUM object, int cpt)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(object, cpt);

    if (dictAttribStp != nullptr)
    {
        return dictAttribStp->sqlName;
    }
    else
    {
        return nullptr;
    }
}

/************************************************************************
*
*  Function          : DBA_GetDictDataTpTab()
*
*  Description       : Get language number
*
*  Arguments         :
*
*  Return            : language number
*
*  Creation date     : PMSTA-nuodb - LJE - 190508
*  Last modification :
*
*************************************************************************/
std::vector<DICT_DATATP_ST> &DBA_GetDictDataTpTab()
{
    return(SV_DictDataTpTab);
}

/************************************************************************
**  Function             : DBA_GetDatatypeEnumByCode()
**
**  Description          : Return datatype enum from the code
**
**  Arguments            : dtCode : code to find
**
**  Return               : string or NULL
*************************************************************************/
DATATYPE_ENUM DBA_GetDatatypeEnumByCode(const char *dtCode)
{
    if(dtCode == NULL || *dtCode == END_OF_STRING)
        return(NullDataType);

    for (size_t i = 0; i<SV_DictDataTpTab.size(); i++)
    {
        if (strcmp(DICTDATATP_SQLNAME(i), dtCode) == 0)
        {
            return(DICTDATATP_DATATYPE(i));
        }
    }

    /* PMSTA-49178 - LJE - 220921 */
    if (strcmp(dtCode, "trigger") == 0)
    {
        return TriggerType;
    }

    if (strcmp(dtCode, "record") == 0)
    {
        return RecordType;
    }

    return(NullDataType);
}

/************************************************************************
**  Function             : DBA_GetDatatypeEnumByEquivType()
**
**  Description          : Return datatype enum from the code
**
**  Arguments            : dtCode : code to find
**
**  Return               : string or NULL
*************************************************************************/
DATATYPE_ENUM DBA_GetDatatypeEnumByEquivType(const char *dtCode)
{
    if (dtCode == NULL || *dtCode == END_OF_STRING)
        return(NullDataType);

    for (size_t i = 0; i<SV_DictDataTpTab.size(); i++)
    {
        if (strcmp(DICTDATATP_EQUIVTYPE(i), dtCode) == 0)
            return((DATATYPE_ENUM)i);
    }

    return(NullDataType);
}

/************************************************************************
**  Function             : DBA_GetDictBusinessKey()
**
**  Description          : Return business key (sqlname or code or name) for
**                         received entity object (data type, entity,
**                         language, function) and technical identifier.
**
**  Arguments            : object : OBJECT_ENUM member
**                         dictId : element technical identifier
**
**  Return               : string or NULL
*************************************************************************/
const char *DBA_GetDictBusinessKey(OBJECT_ENUM object, DICT_T dictId)
{
    if (object == DictEntity)
    {
        auto it = SV_DictDictEntityMap.find(dictId);

        if (it != SV_DictDictEntityMap.end())
        {
            return it->second->mdSqlName;
        }

        return(NULL);
    }

    if (object == DictDataTp)
    {
        if (dictId <= static_cast<int>(SV_DictDataTpTab.size()))    /*  FPL-PMSTA03125-070710   Transform < into <= */
        return(DICTDATATP_SQLNAME(static_cast<int>((dictId-1))));
        else
        return(NULL);
    }

    if (object == DictLang)
    {
        if (dictId <= static_cast<int>(SV_DictLangTab.size()))      /*  FIH-REF7647-020618  Transform < into <= */
        return(DICTLANG_CODE(static_cast<int>((dictId-1))));
        else
        return(NULL);
    }

    if (object == DictFct)
    {
        /*  FPL-PMSTA03125-070710   Search for the line, because dictId have not following id (user function begin at 100   */
        size_t iCpt = 0;
        for (; (iCpt < EV_DictFctTab.size()) && (dictId != DICTFCT_DICTID(iCpt)) ; iCpt++);
        if (iCpt < EV_DictFctTab.size())          /*  FPL-PMSTA03125-070710   dictId-1 -> iCpt */
            return(DICTFCT_PROCNAME((iCpt)));   /*  FPL-PMSTA03125-070710   dictId-1 -> iCpt */ /*  HFI-PMSTA-16351-130701  replace DICTFCT_NAME by DICTFCT_PROCNAME    */
        else
            return(NULL);
    }

    return(NULL);
}

/************************************************************************
**  Function             : DBA_GetDictId()
**
**  Description          : Return the entity identifier depending on
**                         received object enum.
**
**  Arguments            : objEn     : entity object enum
**                         dictIdPtr : pointer on an DICT_T for dictId
**
**  Return               : TRUE if success,
**                         FALSE elsewhere.
*************************************************************************/
int DBA_GetDictId(OBJECT_ENUM objEn, DICT_T *dictIdPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);

    *dictIdPtr = 0;
    if (dictEntityStp)
    {
        *dictIdPtr = dictEntityStp->entDictId;
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**  Function             : DBA_GetObjectEnumByDynSt()
**
**  Description          : Return the object enum depending on
**                         received dynst_enum
**
**  Arguments            : dynStEnum : DBA_DYNST_ENUM value
**                         objEnPtr : pointer on an OBJECT_ENUM for object enum
**
**  Return               : TRUE if success,
**                         FALSE elsewhere.
**
**  Creation             : DDV - 981109
**  Last modif.          : REF9789 - LJE - 040102
**
*************************************************************************/
int DBA_GetObjectEnumByDynSt(DBA_DYNST_ENUM dynStEnum, OBJECT_ENUM *objEnPtr)
{
    if (objEnPtr == NULL)
        return(FALSE);

    (*objEnPtr) = GET_OBJ_DYNST(dynStEnum);

    return(TRUE);
}

/************************************************************************
**  Function             : DBA_GetObjectEnum()
**
**  Description          : Return the object enum depending on
**                         received entity identifier.
**
**  Arguments            : dictId   : entity identifier
**                         objEnPtr : pointer on an OBJECT_ENUM for object enum
**
**  Return               : TRUE if success,
**                         FALSE elsewhere.
*************************************************************************/
int DBA_GetObjectEnum(DICT_T dictId, OBJECT_ENUM *objEnPtr)
{
    if (objEnPtr == NULL)
        return(FALSE);

    auto it = SV_DictToObjMap.find(dictId);

    (*objEnPtr) = NullEntity;
    if (it != SV_DictToObjMap.end())
    {
        (*objEnPtr) = it->second;
    }

    return(TRUE);
}

/************************************************************************
**  Function             : DBA_GetObjectEnum()
**
**  Description          : Return the object enum depending on
**                         received entity identifier.
**
**  Arguments            : dictId   : entity identifier
**                         
**
**  Return               : objEn   : an OBJECT_ENUM for entity_dict_id
**                         
*************************************************************************/
OBJECT_ENUM DBA_GetObjectEnum(DICT_T dictId)
{
    OBJECT_ENUM objectEn = NullEntity;

    if (DBA_GetObjectEnum(dictId, &objectEn) == TRUE)
    {
        return(objectEn);
    }

    return (InvalidEntity);
}


/************************************************************************
**  Function             : DBA_GetDictEntitySt
**
**  Description          : Get the entitySt
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return               : PTR on entitySt
*************************************************************************/
DICT_ENTITY_STP DBA_GetDictEntitySt(OBJECT_ENUM object)
{
    if (object > 0 &&
        object < AaaMetaDict::getDictEntitySize())
    {
        return AaaMetaDict::getDictEntityVector()[static_cast<unsigned int>(object)];
    }

    return(nullptr);
}

/************************************************************************
**  Function             : DBA_GetDictEntityStSafe
**
**  Description          : Get the entitySt
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return               : PTR on entitySt
*************************************************************************/
DICT_ENTITY_STP DBA_GetDictEntityStSafe(OBJECT_ENUM object)
{
    static DICT_ENTITY_ST emtpyDictEntity;

    auto dictEntityStp = DBA_GetDictEntitySt(object);
    if (dictEntityStp == nullptr)
    {
        dictEntityStp = &emtpyDictEntity;
    }

    return(dictEntityStp);
}

/************************************************************************
**  Function             :  DBA_GetGlobalChangeSetAuth
**
**  Description          :  Check if the feature Change Set is authorised at least for one entity
**
**  Arguments            :  None
**
**  Return               :  FeatureAuth_Enable if enable
**                          FeatureAuth_Disable else
**
**  Creation             :  HFI-PMSTA-27694-180723
**
*************************************************************************/
FEATURE_AUTH_ENUM DBA_GetGlobalChangeSetAuth (void)
{
    for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
    {
        if ((*it)->changeSetAuthEn == FeatureAuth_Enable)
        {
            return FeatureAuth_Enable;
        }
    }

    return FeatureAuth_Disable;
}

/************************************************************************
**  Function             :  DBA_GetGlobalMultiEntityCategoryAuth
**
**  Description          :  Check if the multi-entity category is set at least for one entity
**
**  Arguments            :  None
**
**  Return               :  FeatureAuth_Enable if enable
**                          FeatureAuth_Disable else
**
**  Creation             :  PMSTA-34445 - LJE - 190313
**
*************************************************************************/
FEATURE_AUTH_ENUM DBA_GetGlobalMultiEntityCategoryAuth(void)
{
    FEATURE_AUTH_ENUM featureAuthEn = FeatureAuth_Forbidden;

    for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
    {
        if ((*it)->multiEntityCateg.isDervidedCategory())
        {
            return FeatureAuth_Enable;
        }
        if (featureAuthEn == FeatureAuth_Forbidden && (*it)->multiEntityCateg.isMultiEntityCateg())
        {
            featureAuthEn = FeatureAuth_Disable;
        }
    }

    return featureAuthEn;
}

/************************************************************************
**  Function             : DBA_GetDictEntityByDictId
**
**  Description          : Get the entitySt
**
**  Arguments            : dictId   : entity identifier
**
**  Return               : PTR on entitySt
*************************************************************************/
DICT_ENTITY_STP DBA_GetDictEntityByDictId(DICT_T dictId)
{
    auto it = SV_DictDictEntityMap.find(dictId);

    if (it != SV_DictDictEntityMap.end())
    {
        return it->second;
    }
    else
    {
        return(nullptr);
    }
}


/************************************************************************
**  Function             : DBA_GetDictEntityByDictIdSafe
**
**  Description          : Get the entitySt
**
**  Arguments            : dictId   : entity identifier
**
**  Return               : PTR on entitySt
*************************************************************************/
DICT_ENTITY_STP DBA_GetDictEntityByDictIdSafe(DICT_T dictId)
{
    static DICT_ENTITY_ST emtpyDictEntity;

    auto it = SV_DictDictEntityMap.find(dictId);

    if (it != SV_DictDictEntityMap.end())
    {
        return it->second;
    }
    else
    {
        return(&emtpyDictEntity);
    }
}

/************************************************************************
**
**  Function            : DBA_GetDictEntityByXdDictId
**
**  Description         : Get the DICT_ENTITY_STP corresponding to the given id of a xd_entity
**
**  Arguments           : ID_T  xdEntityId  : xd entity identifier
**
**  Return              : DICT_ENTITY_STP
**
**  Creation            : HFI-PMSTA-46106-210913
**
*************************************************************************/
DICT_ENTITY_STP DBA_GetDictEntityByXdDictId (ID_T xdEntityId)
{
    for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = *it;
        if (dictEntityStp->xdEntityId == xdEntityId)
        {
            return dictEntityStp;
        }
    }
    return nullptr;
}

/************************************************************************
**  Function             : DBA_GetDictEntitySqlName()
**
**  Description          : Get entity sql name
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return               :
*************************************************************************/
const char *DBA_GetDictEntitySqlName(OBJECT_ENUM object)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp)
    {
        return dictEntityStp->mdSqlName;
    }
    else
        return(NULL);
}

/************************************************************************
**  Function             : DBA_GetDictEntityLabel()
**
**  Description          : Get entity sql name
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return               :
*************************************************************************/
const char *DBA_GetDictEntityLabel(OBJECT_ENUM object, FLAG_T sqlnameFlg)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp)
    {
        if (sqlnameFlg == TRUE)
        {
            return dictEntityStp->mdSqlName;
        }

        return dictEntityStp->labelStr.c_str();
    }
    else
        return(NULL);
}

/************************************************************************
**
**  Function        : DBA_GetDictEntityDispBusiFlag
**
**  Description     : Get entity sql name
**
**  Arguments       : object 	: OBJECT_ENUM member
**
**  Return          : FLAG_T
**
**  Creation        : FIH-REF10766-041116
**
*************************************************************************/
FLAG_T  DBA_GetDictEntityDispBusiFlag (OBJECT_ENUM object)
{
    FLAG_T  flagDispFkWithBusiness;

    if ((object == CorporateAction) ||
        (object == TradingPlace) ||
        (object == ModelConstr))
        flagDispFkWithBusiness = TRUE;
    else
        flagDispFkWithBusiness = FALSE;

    return flagDispFkWithBusiness;
}

/************************************************************************
**
**  Function    :   DBA_GetEntityBySqlName()
**
**  Description :   return pointer to entity depending on received
**                  sql name
**
**  Argument    :   name
**
**  Return      :   pointer to entity on success, NULL elsewhere
**
*************************************************************************/
DICT_ENTITY_STP DBA_GetEntityBySqlName(const std::string &sqlName, bool bAll, bool bSource)
{
    if (sqlName.empty() == false)
    {
        if (bSource && SV_SrcMdSqlNameDictDictEntityMap.empty() == false)
        {
            auto it = SV_SrcMdSqlNameDictDictEntityMap.find(sqlName);

            if (it != SV_SrcMdSqlNameDictDictEntityMap.end())
            {
                return it->second;
            }
        }
        else
        {
            auto it = SV_MdSqlNameDictDictEntityMap.find(sqlName);

            if (it != SV_MdSqlNameDictDictEntityMap.end())
            {
                if (it->second->entNatEn != EntityNat_All || bAll)
                {
                    return it->second;
                }
                return(nullptr);
            }

            it = SV_DbSqlNameDictDictEntityMap.find(upper(sqlName));

            if (it != SV_DbSqlNameDictDictEntityMap.end())
            {
                if (it->second->entNatEn != EntityNat_All || bAll)
                {
                    return it->second;
                }
                return(nullptr);
            }
        }

        if (sqlName[0] == '#')
        {
            return DBA_GetEntityBySqlName(sqlName.substr(1), bAll, bSource);
        }
        if (sqlName.find("tt_") == 0)
        {
            return DBA_GetEntityBySqlName(sqlName.substr(3), bAll, bSource);
        }
    }
    return(nullptr);
}

/************************************************************************
**
**  Function    :   DBA_GetAttributeBySqlNameInAttrTab()
**
**  Description :   return pointer to attribute depending on received
**                  attribute tab and sql name
**
**  Argument    :   sqlName
**
**  Return      :   pointer to attribute on success, NULL elsewhere
**
**  Creation    :   PMSTA06772 - DDV - 080619
**
*************************************************************************/
STATIC DICT_ATTRIB_STP DBA_GetAttributeBySqlNameInAttrTab(std::vector<DictAttribClass*> &attribute, const char *sqlName, FLAG_T forceNameFlg = FALSE)
{
    if (sqlName)
    {
        for (auto & dictAttribStp : attribute)
        {
            if (strcmp(dictAttribStp->sqlName, sqlName) == 0)
            {
                return dictAttribStp;
            }
        }

        if (forceNameFlg == TRUE)
        {
            return NULL;
        }

        /*** Check Keyword Without _id ***/
        string keyword(sqlName);
        keyword += "_id";

        for (auto& dictAttribStp : attribute)
        {
            if (keyword.compare(dictAttribStp->sqlName) == 0)
                return dictAttribStp;
        }

        /*** Check Keyword Without _dict_id ***/

        keyword = sqlName;
        keyword += "_dict_id";

        for (auto& dictAttribStp : attribute)
        {
            if (keyword.compare(dictAttribStp->sqlName) == 0)
                return dictAttribStp;
        }
    }
    return NULL;
}

/************************************************************************
**
**  Function    :   DBA_GetAttributeBySqlName()
**
**  Description :   return pointer to attribute depending on received
**                  entity and sql name
**
**  Argument    :   sqlName
**
**  Return      :   pointer to attribute on success, NULL elsewhere
**
*************************************************************************/
DICT_ATTRIB_STP DBA_GetAttributeBySqlName(OBJECT_ENUM object, const char *sqlName, FLAG_T forceNameFlg)
{
    if (sqlName != nullptr)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

        if (dictEntityStp != nullptr)
        {
            /* PCC13654 - LJE - 090701 */
            if (dictEntityStp->sortedAttr.empty())
            {
                return(DBA_GetAttributeBySqlNameInAttrTab(dictEntityStp->attr, sqlName, forceNameFlg));
            }
            else
            {
                string sqlNameStr(sqlName);

                auto it = dictEntityStp->sortedAttr.find(sqlNameStr);

                if (forceNameFlg == FALSE)
                {
                    if (it == dictEntityStp->sortedAttr.end())
                    {
                        it = dictEntityStp->sortedAttr.find(sqlNameStr + "_dict_id");
                    }

                    if (it == dictEntityStp->sortedAttr.end())
                    {
                        it = dictEntityStp->sortedAttr.find(sqlNameStr + "_id");
                    }
                }

                if (it != dictEntityStp->sortedAttr.end())
                {
                    return it->second;
                }
            }
        }
    }
    return NULL;
}

/************************************************************************
**  Function             : DBA_ManageJoinDictCriteria()
**
**  Description          : Manage joins on dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-11505 - LJE - 110316
**
*************************************************************************/
STATIC void DBA_ManageJoinDictCriteria(DICT_ENTITY_STP dictEntityStp, std::map<INT_T, DictCriterClass*> &dictCriteriaMap)
{
    DICT_T          entityDictId = 0;
    DBA_GetDictId(DictEntity, &entityDictId);

    for (auto criterIt = dictCriteriaMap.begin(); criterIt != dictCriteriaMap.end(); ++criterIt)
    {
        auto criterStp = criterIt->second;

        /* Don't show short attribute with index < 0 */
        if (criterStp->index < 0)
        {
            criterStp->toPrintFlg = FALSE;
        }

        if (criterStp->isNullParent2ProgN == false || criterStp->isNullParent1ProgN == false)
        {
            if (criterStp->isNullParent1ProgN == false)
            {
                if (criterStp->parent1ProgN >= (SMALLINT_T)dictCriteriaMap.size())
                {
                    dictEntityStp->xdStatusEn = XdStatus_Failed;
                    continue;
                }
            }
            if (criterStp->isNullParent2ProgN == false)
            {
                if (criterStp->parent2ProgN >= (SMALLINT_T)dictCriteriaMap.size())
                {
                    dictEntityStp->xdStatusEn = XdStatus_Failed;
                    continue;
                }

                auto parent2DictCriteriaStp = dictCriteriaMap[criterStp->parent2ProgN];
                strcpy(criterStp->parent2SqlName, parent2DictCriteriaStp->sqlName);
                criterStp->parentCriteria2Stp = parent2DictCriteriaStp;
            }

            if (criterStp->isNullParent1ProgN == false)
            {
                DICT_CRITER_STP parentDictCriteriaStp = dictCriteriaMap[criterStp->parent1ProgN];
                if (parentDictCriteriaStp != nullptr)
                {
                    strcpy(criterStp->parent1SqlName, parentDictCriteriaStp->sqlName);
                    criterStp->parentCriteria1Stp = parentDictCriteriaStp;
                }

                if (criterStp->isNullParent2ProgN == false)
                {
                    DICT_CRITER_STP parent2DictCriteriaStp = dictCriteriaMap[criterStp->parent2ProgN];
                    if (parent2DictCriteriaStp != nullptr)
                    {
                        strcpy(criterStp->parent2SqlName, parent2DictCriteriaStp->sqlName);
                        criterStp->parentCriteria2Stp = parent2DictCriteriaStp;
                    }
                }

                auto parentCriterStp = criterStp->parentCriteria1Stp;
                if (parentCriterStp != nullptr)
                {
                    if (criterStp->attrEntObj == DataProfCompo &&
                        parentCriterStp->entDictId == parentCriterStp->attrEntDictId)
                    {
                        sprintf(criterStp->joinSqlName, "up.");
                    }
                    else if (criterStp->isNullParent2ProgN == false &&
                             parentCriterStp->attrPtr != NULL &&
                             parentCriterStp->attrPtr->refEntDictId == entityDictId)
                    {
                        sprintf(criterStp->joinSqlName, "J%03d%04d.", criterStp->parent2ProgN, (int)criterStp->attrEntDictId);
                    }
                    else
                    {
                        sprintf(criterStp->joinSqlName, "J%03d%03d.", criterStp->parent2ProgN, criterStp->parent1ProgN);
                    }
                }
            }
        }

        if (criterStp->attrPtr == NULL ||
            criterStp->attrPtr->attrDictId != criterStp->attrDictId ||
            criterStp->attrPtr->entDictId != criterStp->attrEntDictId)
        {
            if (EV_AAAInstallLevel < 5 && SYS_IsSqlMode() == FALSE)
            {
                char            msg[255];
                sprintf(msg,
                        "Unknown Meta-Dict attribute %s (entity %s) assign in dict_criteria",
                        criterStp->sqlName,
                        dictEntityStp->mdSqlName);

                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
            }
        }
        /* OCS-43062 - LJE - 130911 */
        else if (criterStp->dynNatEn == DynType_All && 
                 criterStp->entAttrPtr != nullptr)
        {
            criterStp->entAttrPtr->allDictCriteriaStp = criterStp;
        }
    }
}

/************************************************************************
**  Function             : DBA_UpdCrossLinkAttr()
**
**  Description          : Set link info for all attribute which have a linked attribute
**
**  Arguments            : none
**
**  Return               : none
**
**  Creation             : PMSTA-18593 - LJE - 151221
**
*************************************************************************/
void DBA_UpdCrossLinkAttr(OBJECT_ENUM objectEn)
{
    for (auto &dictEntityStp : AaaMetaDict::getDictEntityVector())
    {
        if (objectEn == NullEntity || objectEn == dictEntityStp->objectEn)
        {
            if (dictEntityStp->xdStatusEn == XdStatus_Deleted)
            {
                continue;
            }

            dictEntityStp->init(objectEn == NullEntity);

            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                dictAttribStp->dictEntityStp = dictEntityStp;

                if (dictAttribStp->linkedAttrDictStp != NULL)
                {
                    dictAttribStp->linkedAttrDictStp->linkAttrDictTab.clear();
                }
            }
        }
    }

    for (auto &dictEntityStp : AaaMetaDict::getDictEntityVector())
    {
        if (objectEn == NullEntity || objectEn == dictEntityStp->objectEn)
        {
            if (dictEntityStp->xdStatusEn == XdStatus_Deleted)
            {
                continue;
            }

            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if (dictAttribStp->linkedAttrDictStp != NULL)
                {
                    DICT_ATTRIB_STP linkedAttrDictStp = dictAttribStp->linkedAttrDictStp;

                    linkedAttrDictStp->linkAttrDictTab.push_back(dictAttribStp);
                }
            }
        }
    }

    for (auto &dictEntityStp : AaaMetaDict::getDictEntityVector())
    {
        if (objectEn == NullEntity || objectEn == dictEntityStp->objectEn)
        {
            DBA_ManageDictEntityConstr(dictEntityStp->objectEn);
        }
    }

}

/************************************************************************
**  Function             : DBA_GetLinkAttribStp()
**
**  Description          :
**
**  Arguments            : none
**
**  Return               : none
**
**  Creation             : PMSTA-18593 - LJE - 151221
**
*************************************************************************/
DICT_ATTRIB_STP DBA_GetLinkAttribStp(DICT_ATTRIB_STP refAttribStp)
{
    DICT_ATTRIB_STP linkedAttribStp = NULL;

    if (refAttribStp != NULL &&
        (linkedAttribStp = refAttribStp->linkedAttrDictStp) == NULL)
    {
        /* PMSTA-26250 - LJE - 170324 */
        if (refAttribStp->dictEntityStp->entNatEn == EntityNat_DerivedEntity)
        {
            OBJECT_ENUM     derivedObjEn;
            DBA_GetObjectEnum(refAttribStp->dictEntityStp->linkedEntityDictId, &derivedObjEn);
            refAttribStp = DBA_GetAttributeBySqlName(derivedObjEn, refAttribStp->sqlName);
        }

        for (size_t i = 0; i < refAttribStp->linkAttrDictTab.size(); i++)
        {
            if (refAttribStp->linkAttrDictTab[i]->linkedAttrDictStp == refAttribStp)
            {
                linkedAttribStp = refAttribStp->linkAttrDictTab[i];
                break;
            }
        }
    }

    return linkedAttribStp;
}

/************************************************************************
**
**  Function        : DBA_SetAttribOnDictCriteria
**
**  Description     :
**
**  Arguments       :
**
**  Return          : None
**
**  Creation		: PMSTA-11505 - LJE - 110331
**
************************************************************************/
STATIC void DBA_SetAttribOnDictCriteria(DICT_ENTITY_STP dictEntityStp, std::map<INT_T, DictCriterClass*> &dictCriteriaMap)
{
    for (auto criterIt = dictCriteriaMap.begin(); criterIt != dictCriteriaMap.end(); ++criterIt)
    {
        DICT_CRITER_STP criterStp = criterIt->second;

        if (criterStp->attrPtr == nullptr)
        {
            criterStp->attrPtr = DBA_GetAttributeById(criterStp->attrDictId);
        }

        if (criterStp->attrPtr != nullptr)
        {
            if (criterStp->joinSqlName[0] == 0)
            {
                if (criterStp->attrPtr->custFlg == TRUE)
                {
                    strcpy(criterStp->joinSqlName, "ud.");
                }
                else if (criterStp->attrPtr->precompFlg == TRUE)
                {
                    strcpy(criterStp->joinSqlName, "x.");
                }
            }

            if (criterStp->entAttrPtr == nullptr &&
                criterStp->attrPtr != nullptr &&
                criterStp->attrDictId == criterStp->attrPtr->attrDictId &&
                criterStp->entDictId == criterStp->attrPtr->entDictId &&
                strcmp(criterStp->sqlName, criterStp->attrPtr->sqlName) == 0)  /* PMSTA-29879 - LJE - 180705 */
            {
                criterStp->entAttrPtr = criterStp->attrPtr;
            }

            criterStp->attrEntObj = criterStp->attrPtr->dictEntityStp->objectEn;
        }
        else if (SYS_IsSqlMode() == FALSE)
        {
            char msg[255];
            sprintf(msg,
                    "Unknown Meta-Dict attribute %s (entity %s) assign in dict_criteria",
                    criterStp->sqlName,
                    dictEntityStp->mdSqlName);

            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
        }

        if (criterStp->entAttrPtr == nullptr)
        {
            criterStp->entAttrPtr = DBA_GetAttributeBySqlName(dictEntityStp->objectEn, criterStp->sqlName, TRUE);
        }
    }
}

/************************************************************************
**  Function             : DBA_UpdDictCriteria()
**
**  Description          : Manage dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-11505 - LJE - 110316
**
*************************************************************************/
void DBA_UpdDictCriteria(OBJECT_ENUM objectEn, bool bLightLoad)
{
    DICT_T newDictId = -1;

    for (auto dictEntityIt = AaaMetaDict::getDictEntityVector().begin(); dictEntityIt != AaaMetaDict::getDictEntityVector().end(); ++dictEntityIt)
    {
        DICT_ENTITY_STP dictEntityStp = (*dictEntityIt);

        if (objectEn == NullEntity || objectEn == dictEntityStp->objectEn)
        {
            /* PMSTA-13109 - LJE - 111117 - Get the short from the attributes */
            if (dictEntityStp->shortDictCriteriaMap.size() == 0 &&
                dictEntityStp->entNatEn != EntityNat_TempTable &&
                dictEntityStp->entNatEn != EntityNat_DerivedEntity)
            {
                FIELD_IDX_T                        index = 0;
                FIELD_IDX_T                        shortIndex = -1;
                map< FIELD_IDX_T, DICT_ATTRIB_STP> shortAttribMap;

                for (auto& dictAttribStp : dictEntityStp->attr)
                {
                    if (dictAttribStp->logicalFlg == FALSE &&
                        dictAttribStp->calcEn     != DictAttr_Virtual &&
                        dictAttribStp->custFlg    == FALSE &&
                        dictAttribStp->precompFlg == FALSE &&
                        (bLightLoad               == false || dictAttribStp->isNullShortIdx == false)) /* PMSTA-31095 - LJE - 180427 */
                    {
                        if (dictAttribStp->isNullShortIdx == true)
                        {
                            dictAttribStp->shortIdx = ++shortIndex;
                            dictAttribStp->isNullShortIdx = false;
                        }
                        else
                        {
                            shortIndex = dictAttribStp->shortIdx;
                        }
                        shortAttribMap.insert(make_pair(shortIndex, dictAttribStp));
                    }
                }

                shortIndex = 0;
                for (auto attribIt = shortAttribMap.begin(); attribIt != shortAttribMap.end(); ++attribIt, ++shortIndex)
                {
                    DICT_ATTRIB_STP dictAttribStp = attribIt->second;
                    DICT_CRITER_STP criteriaStp = dictEntityStp->addDictCriteria(DynType_Short, shortIndex);

                    criteriaStp->dictId = newDictId--;
                    criteriaStp->entDictId = dictAttribStp->entDictId;
                    criteriaStp->dynNatEn = DynType_Short;

                    criteriaStp->attrEntDictId = dictAttribStp->entDictId;
                    criteriaStp->entAttrPtr = dictAttribStp;
                    criteriaStp->attrEntObj = dictEntityStp->objectEn;

                    criteriaStp->attrDictId = dictAttribStp->attrDictId;
                    criteriaStp->attrPtr = dictAttribStp;
                    criteriaStp->fkIndex = 0;
                    criteriaStp->isNullFkIndex = true; /* PMSTA-14452 - LJE - 130213 */
                    if (dictAttribStp->busKeyFlg == FALSE)
                    {
                        criteriaStp->index = 0;
                        criteriaStp->isNullIndex = true;
                    }
                    else
                    {
                        criteriaStp->index = index++;
                        criteriaStp->isNullIndex = false;

                        criteriaStp->fkIndex = static_cast<TINYINT_T>(dictAttribStp->progN);
                        criteriaStp->isNullFkIndex = false; /* PMSTA-14452 - LJE - 130213 */
                    }
                    criteriaStp->parent1ProgN       = 0;
                    criteriaStp->isNullParent1ProgN = true;
                    criteriaStp->parent2ProgN       = 0;
                    criteriaStp->isNullParent2ProgN = true;
                    criteriaStp->progN              = shortIndex;
                    criteriaStp->sortRank           = 0;
                    criteriaStp->sortRule           = SortRule_Descending;
                    criteriaStp->joinSqlName[0]     = 0;
                    criteriaStp->toPrintFlg         = TRUE;

                    criteriaStp->SET_dcLabel(dictAttribStp->GET_daLabel());/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                    strcpy(criteriaStp->name, dictAttribStp->name);
                    strcpy(criteriaStp->sqlName, dictAttribStp->sqlName);
                    criteriaStp->SET_dcUniLabel(dictAttribStp->GET_daUniLabel());/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                }
            }

            FIELD_IDX_T criterPos = 0;
            map<string, DictCriterClass*> dictCriterBySqlNameMap;
            for (auto it = dictEntityStp->allDictCriteriaMap.begin(); it != dictEntityStp->allDictCriteriaMap.end(); ++it)
            {
                if (it->second->bFromDb)
                {
                    dictCriterBySqlNameMap[it->second->sqlName] = it->second;
                }
            }
            dictEntityStp->allDictCriteriaMap.clear();

            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if (dictAttribStp != nullptr &&
                    dictAttribStp->logicalFlg == FALSE &&
                    dictAttribStp->attrDictId > 0)
                {
                    auto dictCriterFromDb = dictCriterBySqlNameMap.find(dictAttribStp->sqlName);
                    if (dictCriterFromDb != dictCriterBySqlNameMap.end())
                    {
                        auto& criteriaStp  = dictEntityStp->allDictCriteriaMap[criterPos];
                        criteriaStp        = dictCriterFromDb->second;
                        criteriaStp->progN = criterPos;
                    }
                    else
                    {
                        auto criteriaStp = dictEntityStp->addDictCriteria(DynType_All, criterPos);

                        criteriaStp->dictId             = newDictId--;
                        criteriaStp->entDictId          = dictAttribStp->entDictId;
                        criteriaStp->attrEntDictId      = dictAttribStp->entDictId;
                        criteriaStp->attrDictId         = dictAttribStp->attrDictId;
                        criteriaStp->attrEntObj         = dictEntityStp->objectEn;
                        criteriaStp->attrPtr            = dictAttribStp; /* PMSTA-13122 - LJE - 120420 */
                        criteriaStp->entAttrPtr         = dictAttribStp; /* PMSTA-13122 - LJE - 120420 */
                        criteriaStp->fkIndex            = 0;
                        criteriaStp->isNullFkIndex      = true;
                        criteriaStp->index              = 0;
                        criteriaStp->isNullIndex        = true;
                        criteriaStp->parent1ProgN       = 0;
                        criteriaStp->isNullParent1ProgN = true;
                        criteriaStp->parent2ProgN       = 0;
                        criteriaStp->isNullParent2ProgN = true;
                        criteriaStp->sortRank           = 0;
                        criteriaStp->sortRule           = SortRule_Descending;
                        criteriaStp->joinSqlName[0]     = 0;
                        criteriaStp->toPrintFlg         = TRUE;
                        criteriaStp->bFromDb            = false;

                        criteriaStp->SET_dcLabel(dictAttribStp->GET_daLabel());/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                        strcpy(criteriaStp->name, dictAttribStp->name);
                        strcpy(criteriaStp->sqlName, dictAttribStp->sqlName);
                        criteriaStp->SET_dcUniLabel(dictAttribStp->GET_daUniLabel());/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                    }
                    criterPos++;
                }
            }

            DBA_SetAttribOnDictCriteria(dictEntityStp, dictEntityStp->allDictCriteriaMap);
            DBA_ManageJoinDictCriteria(dictEntityStp, dictEntityStp->allDictCriteriaMap);
            DBA_SetAttribOnDictCriteria(dictEntityStp, dictEntityStp->shortDictCriteriaMap);
            DBA_ManageJoinDictCriteria(dictEntityStp, dictEntityStp->shortDictCriteriaMap);

            /* PMSTA-29879 - LJE - 180704 */
            map<string, DictCriterClass*> criterBySqlNameMap;

            dictEntityStp->shortAllDbDictCriteriaMap.clear();
            criterPos = 0;
            for (auto criterIt = dictEntityStp->allDictCriteriaMap.begin(); criterIt != dictEntityStp->allDictCriteriaMap.end(); ++criterIt)
            {
                if (criterIt->second->entAttrPtr != nullptr &&
                    criterIt->second->entAttrPtr->isPhysicalAttribute() == true)
                {
                    auto shortAllDbDictCriteriaStp = new DictCriterClass(*criterIt->second);
                    dictEntityStp->m_mp.ownerObject(shortAllDbDictCriteriaStp);
                    dictEntityStp->shortAllDbDictCriteriaMap.insert(make_pair(criterPos++, shortAllDbDictCriteriaStp));
                }
            }
            for (auto criterIt = dictEntityStp->shortDictCriteriaMap.begin(); criterIt != dictEntityStp->shortDictCriteriaMap.end(); ++criterIt)
            {
                if (criterIt->second->entAttrPtr == nullptr ||
                    criterIt->second->entAttrPtr->isPhysicalAttribute() == false)
                {
                    auto shortAllDbDictCriteriaStp = new DictCriterClass(*criterIt->second);
                    dictEntityStp->m_mp.ownerObject(shortAllDbDictCriteriaStp);
                    dictEntityStp->shortAllDbDictCriteriaMap.insert(make_pair(criterPos++, shortAllDbDictCriteriaStp));
                }
            }
            for (auto criterIt = dictEntityStp->shortAllDbDictCriteriaMap.begin(); criterIt != dictEntityStp->shortAllDbDictCriteriaMap.end(); ++criterIt)
            {
                criterIt->second->progN = criterIt->first;
                criterBySqlNameMap.insert(make_pair(criterIt->second->sqlName, criterIt->second));
            }

            for (auto criterIt = dictEntityStp->shortAllDbDictCriteriaMap.begin(); criterIt != dictEntityStp->shortAllDbDictCriteriaMap.end(); ++criterIt)
            {
                if (criterIt->second->dynNatEn == DynType_Short)
                {
                    if (criterIt->second->isNullParent1ProgN == false)
                    {
                        auto parentCriter = criterBySqlNameMap.find(criterIt->second->parent1SqlName);
                        if (parentCriter != criterBySqlNameMap.end())
                        {
                            criterIt->second->parentCriteria1Stp = parentCriter->second;
                            criterIt->second->parent1ProgN = parentCriter->second->progN;
                        }
                        else if (EV_AAAInstallLevel == 0 || dictEntityStp->bIsInitEntity == true)
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                    if (criterIt->second->isNullParent2ProgN == false)
                    {
                        auto parentCriter = criterBySqlNameMap.find(criterIt->second->parent2SqlName);
                        if (parentCriter != criterBySqlNameMap.end())
                        {
                            criterIt->second->parentCriteria2Stp = parentCriter->second;
                            criterIt->second->parent2ProgN = parentCriter->second->progN;
                        }
                        else if (EV_AAAInstallLevel == 0 || dictEntityStp->bIsInitEntity == true)
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                }
                criterIt->second->dynNatEn = DynType_ShortAllDb;
            }
        }
    }
}

/************************************************************************
**
**  Function    : DICT_GetLinkedVirtualAttribute
**
**  Description : Create virtual attribute in meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
RET_CODE DICT_GetLinkedVirtualAttribute (OBJECT_ENUM enObject, ID_T idLinkedObject, int iFieldIndex, DICT_ATTRIB_STP *pdictattrptr)
{
    RET_CODE    retCode = RET_SUCCEED;

    if (pdictattrptr != NULL)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(enObject);

        *pdictattrptr = NULL;
        if (dictEntityStp != nullptr)
        {
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if ((dictAttribStp->pdbadynLinkedObj != NULL) &&
                    (IS_NULLFLD(dictAttribStp->pdbadynLinkedObj, iFieldIndex) == FALSE) &&
                    (GET_ID(dictAttribStp->pdbadynLinkedObj, iFieldIndex) == idLinkedObject))
                {
                    *pdictattrptr = dictAttribStp;
                    break;
                }
            }
        }
    }

    if (pdictattrptr == nullptr || *pdictattrptr == nullptr)
        retCode = RET_GEN_ERR_INVARG;

    return retCode;     /*  FPL-081113-PMSTA03798 RET_SUCCEED -> retCode    */
}


/************************************************************************
**
**  Function    : DICT_GetVirtualEntity
**
**  Description : Create virtual entity in meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
RET_CODE DICT_GetVirtualEntity(OBJECT_ENUM *penObject, ID_T idLinkedObject, DBA_DYNST_ENUM enLinkedDbaDynSt)
{
    if (penObject)
    {
        for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
        {
            if ((*it)->enLinkedDbaDynSt == enLinkedDbaDynSt &&
                (*it)->idLinkedObject == idLinkedObject)
            {
                (*penObject) = (*it)->objectEn;
                return RET_SUCCEED;
            }
        }
    }
    return RET_GEN_ERR_INVARG;
}


/************************************************************************
**
**  Function    : DICT_AllocateVirtualEntity
**
**  Description : Allocate virtual entity in meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**                 REF11474 - LJE - 060524
**
*************************************************************************/
RET_CODE DICT_AllocateVirtualEntity (int nbrVirtualEntity)
{
    int          i;
    OBJECT_ENUM *objEnumTab=(OBJECT_ENUM*)CALLOC(nbrVirtualEntity, sizeof(OBJECT_ENUM));

    for (i=0; i<nbrVirtualEntity; i++)
    {
        DICT_CreateVirtualEntity(&(objEnumTab[i]), "", "", nullptr, nullptr); /* PMSTA-13109 - LJE - 111117 */
    }

    for (i=0; i<nbrVirtualEntity; i++)
    {
        DICT_FreeVirtualEntity(objEnumTab[i]);
    }

    FREE(objEnumTab);

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    : DICT_GetNewEntDictId
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
*************************************************************************/
DICT_T DICT_GetNewEntDictId(DbiConnection* dbiConnPtr)
{

    static set<DICT_T> entDictIdSet;
    static DICT_T newDictId = FIRST_UDT_ENTITY;

    bool bContinue = true;

    if (entDictIdSet.size() == 0)
    {
        DBA_DYNFLD_STP shXdEntityStp;
        int shXdEntityNbr = -1;
        DBA_DYNFLD_STP *shXdEntityTab = NULL;


        shXdEntityStp = ALLOC_DYNST(S_XdEntity);

        SET_ENUM(shXdEntityStp, S_XdEntity_NatEn, EntityNat_All);

        DbiConnectionHelper dbiConnHelper(dbiConnPtr);

        if (DBA_Select2(XdEntity,
            UNUSED,
            S_XdEntity,
            shXdEntityStp,
            S_XdEntity,
            &shXdEntityTab,
            UNUSED,
            &shXdEntityNbr,
            dbiConnHelper) != RET_SUCCEED)
        {
            shXdEntityNbr = 0;
        }

        FREE_DYNST(shXdEntityStp, S_XdEntity);

        for (int i = 0; i < shXdEntityNbr; i++)
        {
            entDictIdSet.insert(GET_DICT(shXdEntityTab[i], S_XdEntity_EntityDictId));
        }

        DBA_FreeDynStTab(shXdEntityTab, shXdEntityNbr, S_XdEntity); /* PMSTA-41519 - DDV - 200824 */

        for (auto it = AaaMetaDict::getDictEntityVector().begin(); it != AaaMetaDict::getDictEntityVector().end(); ++it)
        {
            entDictIdSet.insert((*it)->entDictId);
        }
    }

    do
    {
        if (entDictIdSet.find(newDictId) != entDictIdSet.end())
        {
            newDictId++;
        }
        else
        {
            entDictIdSet.insert(newDictId);
            bContinue = false;
        }
    } while (bContinue && newDictId <= MAX_UDT_ENTITY);

    return newDictId;
}

/************************************************************************
**
**  Function    : DICT_CreateVirtualEntity
**
**  Description : Create virtual entity in meta-dictionary
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
**  Last modif. :  PMSTA-14419 - 080612 - PMO : Dispatcher stop the data dependency's thread
**
*************************************************************************/
RET_CODE DICT_CreateVirtualEntity(OBJECT_ENUM     *objectEnPtr, 
                                  const NAME_T     name, 
                                  const SYSNAME_T  sqlName, 
                                  const SYSNAME_T  dbSqlName, 
                                  DBA_DYNFLD_STP   xdEntityStp,
                                  bool             bTemplateMdSqlName, 
                                  DbiConnection*   dbiConnPtr, 
                                  bool             bSourceEnv)
{
    RET_CODE        ret=RET_SUCCEED;
    DICT_T          entDictId = 0;

    if (objectEnPtr != NULL && xdEntityStp == NULL)
    {
        (*objectEnPtr) = NullEntity;
    }

    /* PMSTA06772 - DDV - 080619 - Lock moved to include Virtual object creation in the section */
    if (DBA_LockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO) == FALSE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ServLock_CreateVirtualEntity FAILED");
        return (RET_GEN_ERR_INVARG);
    }

    if (objectEnPtr == NULL ||
        DBA_CreateVirtualObject(objectEnPtr) != RET_SUCCEED ||
        (*objectEnPtr) > LASTOBJECT ||
        ((*objectEnPtr) < LASTLOGENTITYOBJECT && xdEntityStp == NULL))
    {
        DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);
        return(RET_GEN_ERR_INVARG);
    }

    /* PMSTA-13109 - LJE - 111117 */
    if (xdEntityStp != NULL)
    {
        if (IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) == FALSE)
        {
            entDictId = GET_DICT(xdEntityStp, A_XdEntity_EntityDictId);
        }
        else if (IS_NULLFLD(xdEntityStp, A_XdEntity_DictEntityValue) == FALSE &&
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_CustomDS &&
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Custom &&
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ModelBank &&   /* PMSTA-27352 - LJE - 170606 */
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_PersistedFmt &&
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt && /* PMSTA-22072 - LJE - 160108 */
                 GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_SearchFmt && /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
                 (GET_INT(xdEntityStp, A_XdEntity_DictEntityValue) < FIRST_UDT_ENTITY || GET_INT(xdEntityStp, A_XdEntity_DictEntityValue) > MAX_UDT_ENTITY))
        {
            entDictId = (DICT_T)GET_INT(xdEntityStp, A_XdEntity_DictEntityValue);
        }
        else
        {
            entDictId = DICT_GetNewEntDictId(dbiConnPtr);
        }

        /* PMSTA-13122 - LJE - 120603 */
        if ((GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_CustomDS ||
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Custom ||
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ModelBank ||     /* PMSTA-27352 - LJE - 170606 */
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_PersistedFmt ||
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_SearchFmt ||     /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt ||     /* PMSTA-22072 - LJE - 160108 */
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Questionnaire) &&    /* PMSTA-19243 - DDV - 150331 - Add new questionnaire nature */
            (*objectEnPtr) > LASTUDTOBJECT)
        {
            LASTUDTOBJECT = (*objectEnPtr);
        }
    }
    else
    {
        DICT_T          max;
        auto it = SV_DictDictEntityMap.end();
        it--;
        max = it->first;
        entDictId = ++max;     /* With LJE Help PMSTA-14419 - 080612 - PMO */
    }

    /* DLA - PMSTA-28997 - 171102 */
    std::string mdSqlName;
    if (bTemplateMdSqlName)
    {
        mdSqlName = SYS_Stringer(sqlName, (*objectEnPtr));
    }
    else
    {
        mdSqlName = sqlName;
    }

    DICT_ENTITY_ST &dictEntitySt = DICT_AddNewDictEntity(entDictId, (*objectEnPtr), mdSqlName, (dbSqlName ? dbSqlName : mdSqlName), bSourceEnv);


    if (xdEntityStp != nullptr)
    {
        /* PMSTA-16528 - DDV - 140702 - Copy entity nature from xd_entity in new virtual entity */
        dictEntitySt.entNatEn = (DBA_ENTITY_NAT_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_NatEn);
    }
    else
    {
        dictEntitySt.entNatEn = EntityNat_Virtual;
    }

    /* Fill info */
    dictEntitySt.nameStr            = name;
    dictEntitySt.labelStr           = name;
    dictEntitySt.refAuthFlg         = FALSE;
    dictEntitySt.custAuthFlg        = FALSE;
    dictEntitySt.mainFlg            = TRUE;
    dictEntitySt.tpNatEn            = NoTyping;
    dictEntitySt.entDictIdFlg       = FALSE;
    dictEntitySt.synonFlg           = FALSE;
    dictEntitySt.listFlg            = FALSE;
    dictEntitySt.qSearchFlg         = FALSE;
    dictEntitySt.logicalFlg         = FALSE;
    dictEntitySt.interf             = 1;
    dictEntitySt.auditAuthEn        = FeatureAuth_Forbidden;
    dictEntitySt.natIndex           = 255;
    dictEntitySt.isNullNatIndex     = true;
    dictEntitySt.parIndex           = 255;
    dictEntitySt.isNullParIndex     = true;
    dictEntitySt.activeAuthEn       = FeatureAuth_Forbidden;
    dictEntitySt.custNbr            = 0;
    dictEntitySt.precompNbr         = 0; /* PMSTA-11505 - LJE - 110615 */
    dictEntitySt.primKeyNbr         = 0;
    dictEntitySt.primKeyTab         = NULL; /* PMSTA-13122 - LJE - 120614 */
    dictEntitySt.visKeyNbr          = 0;
    dictEntitySt.visUnKeyIdx        = 0;
    dictEntitySt.useScreenFlg       = FALSE;
    dictEntitySt.inputCtrlFlg       = FALSE;
    dictEntitySt.notepadFlg         = FALSE;
    dictEntitySt.pszSelectString[0] = 0;
    dictEntitySt.iSelectStringIndex = 0;
    dictEntitySt.enSelectMode       = 0;
    dictEntitySt.enSelectNature     = 0;
    dictEntitySt.dictSelectFunction = 0;
    dictEntitySt.fullSearchFlg      = FALSE;
    dictEntitySt.pdbadynSearch      = NULL;
    dictEntitySt.entDefInCFlg       = FALSE;
    dictEntitySt.virtualEntFlg      = TRUE;
    dictEntitySt.virtualAttrFlg     = TRUE;
    dictEntitySt.validEntFlg        = TRUE;
    dictEntitySt.enLinkedDbaDynSt   = InvalidDynSt;
    dictEntitySt.idLinkedObject     = 0;
    /* PMSTA-13109 - LJE - 111212 */
    dictEntitySt.shortSqlname[0]    = 0;
    dictEntitySt.aliasSqlname[0]    = 0;
    /* PMSTA-13122 - LJE - 120516 */
    dictEntitySt.bkAttr             = NULL;
    dictEntitySt.bkAttrNbr          = 0;
    dictEntitySt.multiEntUKFlg      = FALSE; /* OCS-43062 - LJE - 130909 */

    DBA_OBJDEF_STP objDefStp = DBA_GetObjDefBySqlName(dictEntitySt.mdSqlName);
    if (objDefStp)
    {
        DBA_DYNDEF_DEF_STP allDynDefStp = DBA_GetDynStDefBySqlName(dictEntitySt.mdSqlName, DynType_All);
        if (allDynDefStp && *(allDynDefStp->dynStPosPtr) != GET_EDITGUIST(dictEntitySt.objectEn))
        {
            *(allDynDefStp->dynStPosPtr) = GET_EDITGUIST(dictEntitySt.objectEn);
        }

        DBA_DYNDEF_DEF_STP shortDynDefStp = DBA_GetDynStDefBySqlName(dictEntitySt.mdSqlName, DynType_Short);
        if (shortDynDefStp && *(shortDynDefStp->dynStPosPtr) != GET_ADMINGUIST(dictEntitySt.objectEn))
        {
            *(shortDynDefStp->dynStPosPtr) = GET_ADMINGUIST(dictEntitySt.objectEn);
        }

        if ((*objDefStp->objPosPtr) != dictEntitySt.objectEn)
        {
            (*objDefStp->objPosPtr) = dictEntitySt.objectEn;
        }
    }

    DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);

    return (ret);

}

/************************************************************************
**
**  Function    : DICT_FreeVirtualEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
void DICT_FreeVirtualEntity(OBJECT_ENUM objectEn)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    if (dictEntityStp)
    {
        /* PMSTA-13109 - LJE - 111212 */
        if (dictEntityStp->virtualEntFlg == FALSE)
        {
            /* Nothing to do */
            return;
        }

        /* PMSTA06772 - DDV - 080619 - Lock moved to include Virtual object free in the section */
        if (DBA_LockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO) == FALSE)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ServLock_CreateVirtualEntity FAILED");
            return;
        }

        DBA_FreeVirtualObject(objectEn);

        /*  FIH-REF9790-040219  */
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            /*  FIH-REF9790-040219  */
            if (dictEntityStp->enLinkedDbaDynSt > InvalidDynSt)
            {
                if (dictAttribStp->pdbadynLinkedObj != NULL)
                    FREE_DYNST(dictAttribStp->pdbadynLinkedObj, dictEntityStp->enLinkedDbaDynSt);
            }
            dictAttribStp->FREE_daLabels(); /* PMSTA-22506 - DDV - 160426 */
        }


        dictEntityStp->validEntFlg = FALSE;

        dictEntityStp->attribMap.clear();
        dictEntityStp->attr.clear();
        dictEntityStp->buildAttr.clear();

        /* PMSTA-14452 - LJE - 130304 - Memory leak */
        FREE(dictEntityStp->bkAttr);
        dictEntityStp->bkAttrNbr = 0;
        FREE(dictEntityStp->primKeyTab);
        dictEntityStp->primKeyNbr = 0;

        SV_DictDictEntityMap.erase(dictEntityStp->entDictId);
        SV_MdSqlNameDictDictEntityMap.erase(dictEntityStp->mdSqlName);
        SV_DbSqlNameDictDictEntityMap.erase(upper(dictEntityStp->dbSqlName));
        SV_DictToObjMap.erase(dictEntityStp->entDictId);

        DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);
    }
    return;
}

/************************************************************************
**
**  Function    : DICT_ActivateVirtualAttributes
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                DDV-PMSTA6772-080619
**
*************************************************************************/
void DICT_ActivateVirtualAttributes(OBJECT_ENUM objectEn)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    if (dictEntityStp != nullptr)
    {
        if (DBA_LockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO) == FALSE)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ServLock_CreateVirtualEntity FAILED");
            return;
        }

        dictEntityStp->attr.clear();

        INT_T i = 0;
        for (auto it = dictEntityStp->buildAttr.begin(); it != dictEntityStp->buildAttr.end(); ++it, ++i)
        {
            if ((*it)->progN != i)
            {
                SYS_BreakOnDebug();
            }
            dictEntityStp->attr.push_back(*it);
        }
        dictEntityStp->buildAttr.clear();

        dictEntityStp->init(true);

        DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);
    }

    return;
}

/************************************************************************
**
**  Function    :   DBA_GetAttributeBySqlNameInBuildTab()
**
**  Description :   return pointer to attribute depending on received
**                  entity and sql name (using buildAttrNbr).
**
**  Argument    :   name
**
**  Return      :   pointer to attribute on success, NULL elsewhere
**
**  Creation    :   PMSTA06772 - DDV - 080619
**
**
*************************************************************************/
STATIC DICT_ATTRIB_STP DBA_GetAttributeBySqlNameInBuildTab(OBJECT_ENUM object, const char *sqlName, FLAG_T forceNameFlg = FALSE)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr)
    {
        return(DBA_GetAttributeBySqlNameInAttrTab(dictEntityStp->buildAttr, sqlName, forceNameFlg));
    }
    return nullptr;
}

/************************************************************************
**
**  Function    : DICT_AddFieldToVirtualEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
**  Modif       :   FPL-081113-PMSTA03798 add parameter pdbadynLinkedObj
**                                          (could be NULL)
**
*************************************************************************/
RET_CODE  DICT_AddFieldToVirtualEntity (OBJECT_ENUM         objectEn,
                                        FIELD_IDX_T         *progNPtr,
                                        const NAME_T		name,	/* DLA - PMSTA09887 - 101116 */
                                        const SYSNAME_T     sqlName,
                                        DATATYPE_ENUM       dataType,
                                        DICT_T              refEntDictId,   /*  FPL-PMSTA08801-091119 OBJECT_ENUM to DICT_T */
                                        FLAG_T              logicalFlg,
                                        FLAG_T              precompFlg,
                                        DICT_ATTRIB_STP     dictattrOrigin,
                                        DBA_DYNFLD_STP		pdbadynLinkedObj,
                                        DICT_T              newAttribDictId)
{

    RET_CODE        ret=RET_SUCCEED;

    auto dictEntityStp = DBA_GetDictEntitySt(objectEn);
    if (dictEntityStp == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /* PMSTA06772 - DDV - 080619 - Use a new function based on buildAttrNbr counter to check if attribute already exist */
    DICT_ATTRIB_STP existsAttribStp = nullptr;
    if ((existsAttribStp = DBA_GetAttributeBySqlNameInBuildTab(objectEn, sqlName, TRUE)) == NULL)
    {
        FIELD_IDX_T newAttrib = static_cast<FIELD_IDX_T>(dictEntityStp->buildAttr.size());
        FIELD_IDX_T     progN = 0;

        if (logicalFlg == FALSE)
        {
            DBA_AddFieldToVirtualObject(objectEn, &progN, dataType, TRUE, precompFlg, sqlName);
        }
        else
        {
            progN = SHRT_MAX - 1;
        }

        DICT_T attribDictId = newAttribDictId > 0 ? newAttribDictId : (dictEntityStp->entDictId * 1000) + newAttrib + 1;
        DictAttribClass &dictAttribSt = dictEntityStp->addVirtualAttrib(attribDictId, newAttrib, sqlName ? sqlName : string());
        existsAttribStp = &dictAttribSt;
        existsAttribStp->attrDictId = attribDictId;

        if (name != NULL)
        {
            strcpy(existsAttribStp->name,  name);
            existsAttribStp->SET_daLabel(name);/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
        }
        else
        {
            existsAttribStp->SET_daLabel(EMPTY_STR);/* PMSTA-22278 - 160216 - LJE - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
        }

        existsAttribStp->SET_daUniLabel(EMPTY_USTR);/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
        existsAttribStp->entDictId        = dictEntityStp->entDictId;
        existsAttribStp->dataTpProgN      = dataType;
        if ((dataType == IdType) ||
            (dataType == DictType))
            existsAttribStp->refEntDictId = refEntDictId;
        else
            existsAttribStp->refEntDictId = 0;
        existsAttribStp->parAttrDictId    = 0;
        existsAttribStp->progN            = newAttrib; /* PMSTA-13664 - LJE - 120220 */
        existsAttribStp->dbProgN          = newAttrib; /* PMSTA-13664 - LJE - 111212 */
        existsAttribStp->progPkN          = 0;
        existsAttribStp->isNullProgPkN    = true;
        existsAttribStp->dispRank         = (short)(newAttrib + 1);
        existsAttribStp->primFlg          = FALSE;
        existsAttribStp->mandatoryFlg     = FALSE;
        existsAttribStp->dbMandatoryFlg   = FALSE;
        existsAttribStp->dfltVal.clear();
        existsAttribStp->busKeyFlg        = FALSE;
        existsAttribStp->progBkN          = 0;
        existsAttribStp->isNullProgBkN    = true;
        existsAttribStp->logicalFlg       = logicalFlg;
        existsAttribStp->custFlg          = FALSE;
        existsAttribStp->calcEn           = DictAttr_Virtual;
        existsAttribStp->permAuthEn       = PermAuth_No;
        existsAttribStp->editionEn        = DictAttrib_EditInsUpdFilter;
        existsAttribStp->qSearchMask      = 0;
        existsAttribStp->searchMask       = 0;
        existsAttribStp->subTypeMask      = 1;  /* MRA - 040212 - REF9789 */
        existsAttribStp->editionMask      = 1;  /*  HFI-PMSTA-38117-200109  */
        existsAttribStp->parAttrEntDictId = 0;
        existsAttribStp->parAttrProgN     = 0;
        existsAttribStp->parAttrPtr       = NULL;       /*  FIH-PMSTA6734-080606    */
        existsAttribStp->shortIdx         = 0;
        existsAttribStp->isNullShortIdx   = true;
        existsAttribStp->securityLevelEn  = 0;
        existsAttribStp->keyCharC[0]      = 0;
        existsAttribStp->widgetEn         = DictAttrib_WgtTypeDefault;
        existsAttribStp->orgAttrNbr       = 0;          /*  FIH-PMSTA6734-080606    */
        existsAttribStp->orgAttrTab       = NULL;       /*  FIH-PMSTA6734-080606    */
        existsAttribStp->useAttrNbr       = 0;          /*  FIH-PMSTA6734-080606    */
        existsAttribStp->useAttrTab       = NULL;       /*  FIH-PMSTA6734-080606    */
        existsAttribStp->pdbadynLinkedObj = pdbadynLinkedObj;   /*  FPL-081113-PMSTA07398 NULL->pdbadynLinkedObj    */
        existsAttribStp->enSetNullWhileCopying = DictNullCopy_NotSetToNull;     /*  FIH-PMSTA6734-080606    */
        existsAttribStp->iDimIndex        = -1;         /*  FIH-PMSTA6734-080606    */
        existsAttribStp->iObjIndex        = -1;         /*  FIH-PMSTA6734-080606    */
        existsAttribStp->enDefListObject  = NullEntity; /*  FIH-PMSTA6734-080606    */
        existsAttribStp->virtualAttrFlg   = TRUE;       /* PMSTA-13109 - LJE - 111215 - To identify virtual attributes */

        /*  FIH-REF9790-*/
        if ((dictattrOrigin != NULL) &&
            (dictattrOrigin->permValMap.size() > 0))
        {
            existsAttribStp->permValMap = dictattrOrigin->permValMap;
        }
    }

    if (progNPtr != NULL)
    {
        (*progNPtr) = existsAttribStp->progN; /* PMSTA-13109 - LJE - 111216 */
    }

    return(ret);
}

/************************************************************************
*   Function             : DBA_CmpAttribPk()
*
*   Description          : Sort a list of pointers on attribute by prog_pk_n
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
int DBA_CmpAttribPk(const void *ptr1, const void *ptr2)
{
    const DICT_ATTRIB_STP *dictPtr1 = (const DICT_ATTRIB_STP*)ptr1;
    const DICT_ATTRIB_STP *dictPtr2 = (const DICT_ATTRIB_STP*)ptr2;

    DICT_ATTRIB_STP dictattr1 = *dictPtr1;
    DICT_ATTRIB_STP dictattr2 = *dictPtr2;

    return (dictattr1->progPkN > dictattr2->progPkN ? 1 : dictattr1->progPkN < dictattr2->progPkN ? -1 : 0);
}

/************************************************************************
*   Function             : DBA_CmpAttribBk()
*
*   Description          : Sort a list of pointers on attribute by prog_bk_n
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
int DBA_CmpAttribBk(const void *ptr1, const void *ptr2)
{
    const DICT_ATTRIB_STP *dictPtr1 = (const DICT_ATTRIB_STP*)ptr1;
    const DICT_ATTRIB_STP *dictPtr2 = (const DICT_ATTRIB_STP*)ptr2;

    DICT_ATTRIB_STP dictattr1 = *dictPtr1;
    DICT_ATTRIB_STP dictattr2 = *dictPtr2;

    return (dictattr1->progBkN > dictattr2->progBkN ? 1 : dictattr1->progBkN < dictattr2->progBkN ? -1 : 0);
}

/************************************************************************
**
**  Function    :   DBA_ManageDictEntityConstr
**
**  Description :   Set denormalized information on dict_entity,
**                  call this function after each modification
**                  of dict_entity or dict_attribute modification
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170916
**
**  Modif.		:
**
*************************************************************************/
RET_CODE DBA_ManageDictEntityConstr(OBJECT_ENUM objectEn)
{
    const DICT_ENTITY_STP dictEntityStp(DBA_GetDictEntitySt(objectEn));

    if (dictEntityStp == nullptr ||
        dictEntityStp->entNatEn == EntityNat_TempTable)
    {
        return RET_GEN_ERR_INVARG;
    }

    for (auto& dictAttribStp : dictEntityStp->attr)
    {
        if (dictAttribStp == nullptr)
        {
            continue;
        }

        DICT_ENTITY_STP constrDictEntityStp = nullptr;
        DICT_ENTITY_STP refDictEntityStp    = nullptr;
        DICT_ATTRIB_STP refAttribStp        = nullptr;

        if (dictAttribStp->refEntDictId != 0)
        {
            OBJECT_ENUM objEn;
            DBA_GetObjectEnum(dictAttribStp->refEntDictId, &objEn);
            dictAttribStp->refDictEntityStp = DBA_GetDictEntitySt(objEn);
        }
        else
        {
            dictAttribStp->refDictEntityStp = nullptr;
        }

        if (dictAttribStp->refDictEntityStp != nullptr)
        {
            /* PMSTA-26108 - LJE - 170916 - Constraints management for multi-entity */
            if (dictAttribStp->refEntDictId != 0 && dictAttribStp->isPhysicalAttribute())
            {
                constrDictEntityStp = dictAttribStp->refDictEntityStp;
                refDictEntityStp    = dictEntityStp;
                refAttribStp        = dictAttribStp;
            }
            else if ((dictAttribStp->logicalFlg == TRUE || (dictAttribStp->calcEn == DictAttr_Denorm && dictAttribStp->refDeleteRuleEn != RefDelRule_None)) &&
                     dictAttribStp->refEntDictId != 0 &&
                     dictAttribStp->linkedAttrDictId)
            {
                constrDictEntityStp = dictEntityStp;
                refDictEntityStp    = dictAttribStp->refDictEntityStp;
                refAttribStp        = dictAttribStp->linkedAttrDictStp;
            }

            if (refAttribStp != nullptr && constrDictEntityStp != nullptr)
            {
                constrDictEntityStp->addDictEntityConstr(dictAttribStp, refDictEntityStp, refAttribStp);
            }

            if (dictAttribStp->isPhysicalAttribute() && constrDictEntityStp != dictEntityStp)
            {
                dictEntityStp->dictEntityRefMap.insert(make_pair(dictAttribStp, dictAttribStp->refDictEntityStp));
            }

            if (dictAttribStp->logicalFlg == TRUE)
            {
                dictAttribStp->refDictEntityStp->dictEntityRefMap.insert(make_pair(dictAttribStp, dictEntityStp));
            }
        }
    }

    if (dictEntityStp->shadowEntityStp != nullptr &&
        (dictEntityStp->shadowEntityStp->xdStatusEn == XdStatus_Inserted ||
         dictEntityStp->shadowEntityStp->xdStatusEn == XdStatus_Untreated))
    {
        DICT_ATTRIB_STP dictAttribStp = nullptr;
        DICT_ATTRIB_STP refAttribStp = nullptr;

        if (dictEntityStp->primKeyNbr > 0)
        {
            dictAttribStp = dictEntityStp->primKeyTab[dictEntityStp->primKeyNbr - 1];
            refAttribStp = dictEntityStp->shadowEntityStp->primKeyTab[dictEntityStp->shadowEntityStp->primKeyNbr - 1];
        }
        else if (dictEntityStp->bkAttrNbr > 0)
        {
            dictAttribStp = dictEntityStp->bkAttr[dictEntityStp->bkAttrNbr - 1];
            refAttribStp = dictEntityStp->shadowEntityStp->bkAttr[dictEntityStp->shadowEntityStp->bkAttrNbr - 1];
        }

        if (dictAttribStp != nullptr)
        {
            dictEntityStp->addDictEntityConstr(dictAttribStp, dictEntityStp->shadowEntityStp, refAttribStp);
        }
    }

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   MultiEntityHelper::MultiEntityHelper()
**
**  Description :
**
**  Argument    :   none
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
MultiEntityHelper::MultiEntityHelper(DictEntityClass *dictEntityStp)
    : m_multiEntityCategEn(MultiEntityCategory_None)
    , m_dictEntityStp(dictEntityStp)
{
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::MultiEntityHelper()
**
**  Description :
**
**  Argument    :   none
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
MultiEntityHelper::MultiEntityHelper(MULTI_ENTITY_CATEGORY_ENUM multiEntityCategEn)
    : m_multiEntityCategEn(multiEntityCategEn)
    , m_dictEntityStp(nullptr)
{
}


/************************************************************************
**
**  Function    :   MultiEntityHelper::~MultiEntityHelper()
**
**  Description :
**
**  Argument    :   none
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
MultiEntityHelper::~MultiEntityHelper()
{
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isMultiEntityCateg()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171110
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isMultiEntityCateg(MULTI_ENTITY_CATEGORY_ENUM chkMultiEntityCategEn)
{
    switch (chkMultiEntityCategEn)
    {
        case MultiEntityCategory_None:
        case MultiEntityCategory_TechnicalInfrastructure:
        case MultiEntityCategory_NoAccessibilityConstraint:
        case MultiEntityCategory_MasterOnly:
        case MultiEntityCategory_DerivedMasterOnly:
            return false;
            break;

        case MultiEntityCategory_BusinessEntityOnly:
        case MultiEntityCategory_OptionalLocalization:
        case MultiEntityCategory_OptionalSpecialisation:
        case MultiEntityCategory_DerivedBusinessEntityOnly:
        case MultiEntityCategory_DerivedOptionalLocalization:
            /* PMSTA-30152 - LJE - 180509 */
        case MultiEntityCategory_AllBusinessEntityOnly:
        case MultiEntityCategory_MasterOnlyPrecOnBEOnly:
        case MultiEntityCategory_DerivedAllBusinessEntityOnly:
        case MultiEntityCategory_FullOptionalLocalization:
            return true;
            break;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::getDerivedCategory()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-38088 - LJE - 191211
**
**  Modif.		:
**
*************************************************************************/
MULTI_ENTITY_CATEGORY_ENUM MultiEntityHelper::getDerivedCategory() const
{
    if (this->get() == MultiEntityCategory_BusinessEntityOnly ||
        this->get() == MultiEntityCategory_DerivedBusinessEntityOnly)
    {
        return MultiEntityCategory_DerivedBusinessEntityOnly;
    }
    else if (this->get() == MultiEntityCategory_OptionalLocalization ||
             this->get() == MultiEntityCategory_OptionalSpecialisation ||
             this->get() == MultiEntityCategory_DerivedOptionalLocalization)
    {
        return MultiEntityCategory_DerivedOptionalLocalization;
    }
    else if (this->get() == MultiEntityCategory_MasterOnly ||
             this->get() == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||
             this->get() == MultiEntityCategory_DerivedMasterOnly)
    {
        return MultiEntityCategory_DerivedMasterOnly;
    }

    return this->get();
}

#include "callstack.h"

/************************************************************************
**
**  Function    :   MultiEntityHelper::set()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171110
**
**  Modif.		:
**
*************************************************************************/
void MultiEntityHelper::set(MULTI_ENTITY_CATEGORY_ENUM multiEntityCategEn)
{
    this->m_multiEntityCategEn = multiEntityCategEn;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::setDerivedCategory()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-38088 - LJE - 191211
**
**  Modif.		:
**
*************************************************************************/
void MultiEntityHelper::setDerivedCategory(const MultiEntityHelper &multiEntityCateg, bool bRestricOnBE)
{
    MULTI_ENTITY_CATEGORY_ENUM newMultiEntityCategEn = multiEntityCateg.getDerivedCategory();

    if (newMultiEntityCategEn == MultiEntityCategory_None ||
        newMultiEntityCategEn == MultiEntityCategory_TechnicalInfrastructure ||
        newMultiEntityCategEn == this->m_multiEntityCategEn)
    {
        return;
    }

    if (this->m_dictEntityStp != nullptr)
    {
        cout << endl << "######B " << this->m_dictEntityStp->mdSqlName << " " << (int)multiEntityCateg.get() << " (" << (int)newMultiEntityCategEn << ") "
            << (multiEntityCateg.m_dictEntityStp != nullptr ? multiEntityCateg.m_dictEntityStp->mdSqlName : "N/A") << " " << (int)multiEntityCateg.get() << " restrict=" << (int)bRestricOnBE;
    }

    if (bRestricOnBE && multiEntityCateg.isBusinessEntityIsolated() && this->isBusinessEntityDependents())
    {
        this->set(newMultiEntityCategEn);
    }
    else if (this->get() != MultiEntityCategory_DerivedOptionalLocalization)
    {
        if (bRestricOnBE == false &&
            newMultiEntityCategEn != MultiEntityCategory_DerivedMasterOnly &&
            newMultiEntityCategEn != MultiEntityCategory_NoAccessibilityConstraint &&
            newMultiEntityCategEn != MultiEntityCategory_TechnicalInfrastructure)
        {
            this->set(MultiEntityCategory_DerivedOptionalLocalization);
        }
        else if (this->m_multiEntityCategEn == MultiEntityCategory_None)
        {
            this->set(newMultiEntityCategEn);
        }
        else if (multiEntityCateg.isDervidedCategory() && this->isDervidedCategory())
        {
            if (bRestricOnBE && (multiEntityCateg.isBusinessEntityIsolated() || this->isBusinessEntityIsolated()))
            {
                this->set(MultiEntityCategory_DerivedBusinessEntityOnly);
            }
            else
            {
                this->set(MultiEntityCategory_DerivedOptionalLocalization);
            }
        }
        else
        {
            this->set(newMultiEntityCategEn);
        }
    }

    if (this->m_dictEntityStp != nullptr)
    {
        cout << endl << "######A " << this->m_dictEntityStp->mdSqlName << " " << (int)multiEntityCateg.get() << " (" << (int)newMultiEntityCategEn << ") "
            << (multiEntityCateg.m_dictEntityStp != nullptr ? multiEntityCateg.m_dictEntityStp->mdSqlName : "N/A") << " " << (int)multiEntityCateg.get() << " restrict=" << (int)bRestricOnBE;
    }
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::get()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171110
**
**  Modif.		:
**
*************************************************************************/
MULTI_ENTITY_CATEGORY_ENUM MultiEntityHelper::get() const
{
    return this->m_multiEntityCategEn;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::useMeViewAsTable()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-32145 - LJE - 180717
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isUseMeViewAsTable() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation ||
        this->isPartialSpecialzed())
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isInsUpdOnLocalBe()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-32145 - LJE - 180717
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isInsUpdOnLocalBe() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isForceOnConnectedBusinessEntity()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-32145 - LJE - 180717
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isForceOnConnectedBusinessEntity() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isMultiEntityCateg()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171110
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isMultiEntityCateg() const
{
    if (this->isPartialSpecialzed())
    {
        return true;
    }
    return MultiEntityHelper::isMultiEntityCateg(this->m_multiEntityCategEn);
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isOnlyInMaster()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isOnlyInMaster() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_MasterOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedMasterOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_MasterOnlyPrecOnBEOnly)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isMasterVisibility()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isMasterVisibility() const
{
    if (this->isOnlyInMaster() ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isBusinessEntityIsolated()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isBusinessEntityIsolated() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_BusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_AllBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedAllBusinessEntityOnly)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isBusinessEntityDependents()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isBusinessEntityDependents() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isMultiEntityVisibility()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isMultiEntityVisibility() const
{
    if (this->isPartialSpecialzed())
    {
        return false;
    }

    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||        /* PMSTA-38290 - HLA - 200204 */
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_MasterOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedMasterOnly)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isPartialSpecialzed()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isPartialSpecialzed() const
{
    if (this->m_dictEntityStp != nullptr && 
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization &&
        this->m_dictEntityStp->meSpecialisationEn == MeSpecialisation_Applied)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isOptionalLocalization()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isOptionalLocalization() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isFullOptionalLocalization()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-38290 - HLA - 200204
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isFullOptionalLocalization() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isCheckBeOnParent()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isCheckBeOnParent() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isAddCheckOnCurrentBe()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isAddCheckOnCurrentBe() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_AllBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedAllBusinessEntityOnly)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isCheckInTrigger()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isCheckInTrigger() const
{
    if (this->m_multiEntityCategEn != MultiEntityCategory_None &&
        this->m_multiEntityCategEn != MultiEntityCategory_TechnicalInfrastructure &&
        this->m_multiEntityCategEn != MultiEntityCategory_NoAccessibilityConstraint)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isDeniedInMaster()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isDeniedInMaster() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_BusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isAllowedOnlyInMaster()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isAllowedOnlyInMaster() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_MasterOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||       /* PMSTA-30152 - LJE - 180509 */
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedMasterOnly)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isCheckOnCurrentBe()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isCheckOnCurrentBe() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation ||
        this->m_multiEntityCategEn == MultiEntityCategory_AllBusinessEntityOnly ||           /* PMSTA-30152 - LJE - 180509 */
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedAllBusinessEntityOnly)      /* PMSTA-30152 - LJE - 180509 */
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isCheckIfNotExtistOnMaster()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isCheckIfNotExtistOnMaster() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isDervidedCategory()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isDervidedCategory() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_DerivedMasterOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedAllBusinessEntityOnly)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isUniqueKeyAlered()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isUniqueKeyAlered() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_BusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_AllBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation ||
		this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly )    /* PMSTA-41025 - AIS - 200715 */
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isOwnerBusinessEntity()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isOwnerBusinessEntity() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_BusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedBusinessEntityOnly ||
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalLocalization ||
        this->m_multiEntityCategEn == MultiEntityCategory_AllBusinessEntityOnly ||            /* PMSTA-30152 - LJE - 180509 */
        this->m_multiEntityCategEn == MultiEntityCategory_DerivedAllBusinessEntityOnly ||     /* PMSTA-30152 - LJE - 180509 */
        this->m_multiEntityCategEn == MultiEntityCategory_OptionalSpecialisation)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   MultiEntityHelper::isOwnerBusinessEntityMandatory()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180712
**
**  Modif.		:
**
*************************************************************************/
bool MultiEntityHelper::isOwnerBusinessEntityMandatory() const
{
    if (this->m_multiEntityCategEn == MultiEntityCategory_FullOptionalLocalization ||
        this->isOwnerBusinessEntity() == false)
    {
        return false;
    }
    return true;
}
/************************************************************************
**
**  Function    :   DictAttribClass::DictAttribClass()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-29879 - LJE - 180705
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass::DictAttribClass()
    : attrDictId(0)
    , daLabel(nullptr)
    , daUniLabel(nullptr)
    , entDictId(0)
    , dataTpProgN(NullDataType)
    , refEntDictId(0)
    , parAttrDictId(0)
    , progN(0)
    , dbProgN(0)
    , progPkN(0)
    , isNullProgPkN(true)
    , dispRank(0)
    , primFlg(FALSE)
    , mandatoryFlg(FALSE)
    , dbMandatoryFlg(FALSE)
    , busKeyFlg(FALSE)
    , logicalFlg(FALSE)
    , setBySpecProcFlg(FALSE)
    , custFlg(FALSE)
    , precompFlg(FALSE)
    , calcEn(DictAttr_Physical)
    , permAuthEn(PermAuth_No)
    , editionEn(DictAttrib_EditNoEdit)
    , qSearchMask(0)
    , searchMask(0)
    , subTypeMask(0)
    , editionMask(0)
    , parAttrEntDictId(0)
    , parAttrProgN(255)
    , parAttrPtr(nullptr)
    , shortIdx(255)
    , isNullShortIdx(true)
    , securityLevelEn(0)
    , widgetEn(DictAttrib_WgtTypeDefault)
    , maxDbLenN(0)
    , defaultDisplayLenN(0)
    , orgAttrNbr(0)
    , orgAttrTab(nullptr)
    , useAttrNbr(0)
    , useAttrTab(nullptr)
    , pdbadynLinkedObj(nullptr)
    , enSetNullWhileCopying(DictNullCopy_NotSetToNull)
    , iDimIndex(0)
    , iObjIndex(0)
    , enDefListObject(NullEntity)
    , tascViewEn(0)
    , enumValueEn(0)
    , refEntityAttributeDictId(0)
    , fkPresentationEn(0)
    , denomLanguageDictId(0)
    , verticalSearchFlg(FALSE)
    , verticalPatternFlg(FALSE)
    , multiLanguageFlg(FALSE)
    , xdStatusEn(XdStatus_Untreated)
    , virtualAttrFlg(FALSE)
    , refDeleteRuleEn(RefDelRule_None)
    , refSecurityRuleEn(RefSecuRule_Inherited)
    , refCheckRuleEn(RefChkRule_None)
    , objModifStatEn(LastModif_NoTracking)
    , progBkN(0)
    , isNullProgBkN(true)
    , exportEn(Export_Exported)
    , featureEn(XdEntityFeatureFeatureEn::None)
    , subFeatureEn(SubFeature::None)
    , modelBankEn(ModelBank_None)
    , meSpecialisationEn(MeSpecialisation_NotApplicable)
    , linkedAttrDictId(0)
    , linkedAttrDictStp(nullptr)
    , dictEntityStp(nullptr)
    , refDictEntityStp(nullptr)
    , allDictCriteriaStp(nullptr)
    , logicalFkFlg(FALSE)
    , daLabelLen(0)
    , daUniLabelLen(0)
    , copyRightEn(DictAttrCopyNat_Copy)
    , outboxPublishEn(OutboxPublish_None)
{
    this->name[0]            = 0;
    this->keyCharC[0]        = 0;
    this->sqlName[0]         = 0;
    this->objectAttribute[0] = 0;
    this->entityAttribute[0] = 0;
    this->enumAttribute[0]   = 0;
}


/************************************************************************
**
**  Function    :   DictAttribClass::isPhysicalCalcEn
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Cr�ation	:   PMSTA-29879 - LJE - 180705
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isPhysicalCalcEn(DICTATTR_ENUM calcEn)
{
    if (calcEn == DictAttr_Physical ||
        calcEn == DictAttr_PhysSpecUpd ||
        calcEn == DictAttr_CreationManagment ||
        calcEn == DictAttr_LastModifManagment ||
        calcEn == DictAttr_ExternalSeqNo ||
        calcEn == DictAttr_PhysicalPartition) /* PMSTA-24007 - LJE - 170718 */
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isPhysicalAttribute()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-29879 - LJE - 180705
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isPhysicalAttribute()
{
    if (this->logicalFlg == FALSE &&
        this->isPhysicalCalcEn(this->calcEn) == true)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isSpecialAttribute()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-46259 - LJE - 211004
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isSpecialAttribute()
{
    if (this->calcEn == DictAttr_PhysSpecUpd ||
        this->calcEn == DictAttr_CreationManagment ||
        this->calcEn == DictAttr_LastModifManagment)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isPhysicalUDAttribute()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-36158 - LJE - 190627
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isPhysicalUDAttribute()
{
    if (this->logicalFlg == FALSE &&
        this->isPhysicalCalcEn(this->calcEn) == true &&
        this->custFlg == TRUE)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isInAll()
**
**  Description :
**
**  Return      :   bool
**
**  Creation	:   PMSTA-45413 - LJE - 210803
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isInAll()
{
    if (this->logicalFlg == FALSE)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isInShort()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-45413 - LJE - 210803
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isInShort()
{
    if (this->logicalFlg == FALSE && this->isNullShortIdx == false)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictAttribClass::isCompostion()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-46681 - LJE - 211217
**
**  Modif.		:
**
*************************************************************************/
bool DictAttribClass::isCompostion()
{
    if (this->logicalFlg == TRUE)
    {
        if (this->refDeleteRuleEn == RefDelRule_CascadeDelete ||
            (this->refDeleteRuleEn == RefDelRule_Inherited &&
             this->linkedAttrDictStp != nullptr &&
             this->linkedAttrDictStp->refDeleteRuleEn == RefDelRule_CascadeDelete))
        {
            return true;
        }

        if (this->refDeleteRuleEn == RefDelRule_Restrict &&
            (this->refDictEntityStp == nullptr ||
             (this->refDictEntityStp->entNatEn != EntityNat_System && this->refDictEntityStp->mainFlg == 0)))
        {
            return true;
        }

        /* Workaround to fix the meta-dictionary lack... */
        if (this->linkedAttrDictStp != nullptr &&
            this->linkedAttrDictStp->refEntDictId == this->entDictId &&
            this->linkedAttrDictStp->dbMandatoryFlg == TRUE)
        {
            return true;
        }

        if (this->refEntDictId == DenomCst ||
            (this->refEntDictId == ScriptDefCst &&
             strcmp(this->sqlName, "script_control") != 0))
        {
            return true;
        }
    }

    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::DictEntityClass()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictEntityClass::DictEntityClass()
    : entDictId(0)
    , refAuthFlg(FALSE)
    , custAuthFlg(FALSE)
    , mainFlg(FALSE)
    , tpNatEn(NoTyping)
    , entDictIdFlg(FALSE)
    , synonFlg(FALSE)
    , listFlg(FALSE)
    , qSearchFlg(FALSE)
    , logicalFlg(FALSE)
    , interf(0)
    , natIndex(255)
    , isNullNatIndex(true)
    , parIndex(255)
    , isNullParIndex(true)
    , precompFlg(FALSE)
    , usePrecompFlg(FALSE)
    , precompStdFormatId(0)
    , precompUsrFormatId(0)
    , precompRankN(0)
    , custNbr(0)
    , precompNbr(0)
    , primKeyNbr(0)
    , primKeyTab(nullptr)
    , visKeyNbr(0)
    , visUnKeyIdx(0)
    , firstCustPos(0)
    , firstPrecompPos(0)
    , firstLogicalPos(0)
    , firstCOnlyPos(0)
    , firstInternalPos(0)
    , useScreenFlg(FALSE)
    , inputCtrlFlg(FALSE)
    , notepadFlg(FALSE)
    , copyRightEn(DictAttrCopyNat_Copy)
    , bDictScreenRights(false)
    , iSelectStringIndex(0)
    , enSelectMode(0)
    , enSelectNature(0)
    , dictSelectFunction(0)
    , pdbadynSearch(nullptr)
    , pdbadynSelectList(nullptr)
    , pdbadynQSearch(nullptr)
    , idSelectList(0)
    , pszList(nullptr)
    , fullSearchFlg(FALSE)
    , enLinkedDbaDynSt(NullDynSt)
    , idLinkedObject(0)
    , entMDFlg(FALSE)
    , entDefInCFlg(FALSE)
    , virtualEntFlg(FALSE)
    , virtualAttrFlg(FALSE)
    , validEntFlg(FALSE)
    , srcEntDictIdIdx(0)
    , orgEntityNbr(0)
    , orgEntityTab(nullptr)
    , useEntityNbr(0)
    , useEntityTab(nullptr)
    , invertSortFlag(FALSE)
    , sortMenuId(0)
    , iNbLinkedDimObj(0)
    , dictLabelFlg(FALSE)
    , entNatEn(EntityNat_All)
    , xdStatusEn(XdStatus_Untreated)
    , bIsInitEntity(false)
    , securityLevelEn(EntSecuLevel_NoSecured)
    , automaticMask(0)
    , adminFctDictId(0)
    , pkRuleEn(PkRule_Undefined)
    , auditAuthEn(FeatureAuth_Forbidden)
    , activeAuthEn(FeatureAuth_Forbidden)
    , updFctAuthEn(FeatureAuth_Forbidden)
    , externalSeqAuthEn(FeatureAuth_Forbidden)
    , loadDictRuleEn(LoadDictRule_Standard)
    , dmlModifTrackEn(dmlModifTrack_None)
    , partAuthEn(FeatureAuth_Forbidden)
    , dlmAuthEn(FeatureAuth_Forbidden)
    , multiEntityCateg(this)
    , meSpecialisationEn(MeSpecialisation_NotApplicable)
    , deleteRuleEn(DeleteRule_Physical)
    , objModifStatEn(LastModif_NoTracking)
    , tableModifStatEn(LastModif_NoTracking)
    , lastModifEn(LastModif_NoTracking)
    , dbRuleEn(DbRule_Standard)
    , linkedEntityDictId()
    , linkedEntityStp(nullptr)
    , physicalEntityDictId(0)
    , physicalEntityStp(nullptr)
    , pkEntityStp(nullptr)
    , shadowEntityStp(nullptr)
    , beEntityStp(nullptr)       /* PMSTA-32145 - LJE - 180718 */
    , objectEn(NullEntity)
    , bkAttr(nullptr)
    , bkAttrNbr(0)
    , dbPKNbr(0)
    , dbPKTab(nullptr)
    , dbBKNbr(0)
    , dbBKTab(nullptr)
    , udPKNbr(0)
    , udPKTab(nullptr)
    , parentAttrStp(nullptr)
    , optimisticLockingAttrStp(nullptr)
    , externalSeqNoAttrStp(nullptr)
    , rightToRunAttrStp(nullptr)
    , activeAttrStp(nullptr)
    , ownerBusinessEntAttrStp(nullptr)
    , udOwnerBusinessEntAttrStp(nullptr)
    , extOwnerBusinessEntAttrStp(nullptr)
    , bMultiEntityOnPrecomp(false)
    , bMultiEntityOnCustom(false)
    , multiEntUKFlg(FALSE)
    , xdEntityId(0)
    , changeSetAuthEn(FeatureAuth_Forbidden)
    , licenseKeyEn(DictLicenseKey_None)          /*  HFI-PMSTA-35838-190515  */
    , licenseAccessStatusEn(DictFctAuth_Ok)      /*  HFI-PMSTA-35838-190515  */
    , enIsPackage(IsPackageEn::No)
    , bSecuredBySuperUser(false)
{
    this->mdSqlName[0]       = 0;
    this->dbSqlName[0]       = 0;
    this->custSqlName[0]     = 0;
    this->precompSqlName[0]  = 0;
    this->segName[0]         = 0;
    this->precompDbName[0]   = 0;
    this->shortSqlname[0]    = 0;
    this->aliasSqlname[0]    = 0;
    this->pszSelectString[0] = 0;

    lastModifDate.date = 0;
    lastModifDate.time = 0;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictEntityClass::DictEntityClass(const DictEntityClass &ref)
    :DictEntityClass()
{
    *this = ref;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictEntityClass::~DictEntityClass()
{
    this->dictEntityConstrMap.clear();

    FREE(this->bkAttr);
    this->bkAttrNbr = 0;

    FREE(this->primKeyTab);
    this->primKeyNbr = 0;

    FREE(this->dbPKTab);
    this->dbPKNbr = 0;

    FREE(this->dbBKTab);
    this->dbBKNbr = 0;

    FREE(this->udPKTab);
    this->udPKNbr = 0;

    /* PMSTA-45092 - LJE - 210506 */
    if (this->entDictId != 0)
    {
        SV_DictDictEntityMap.erase(this->entDictId);
        SV_DictToObjMap.erase(this->entDictId);
    }
    if (this->mdSqlName[0] != 0)
    {
        SV_MdSqlNameDictDictEntityMap.erase(this->mdSqlName);
    }
    if (this->dbSqlName[0] != 0)
    {
        SV_DbSqlNameDictDictEntityMap.erase(upper(this->dbSqlName));
    }
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictEntityClass &DictEntityClass::operator=(const DictEntityClass &ref)
{
    this->entDictId             = ref.entDictId;
    this->refAuthFlg            = ref.refAuthFlg;
    this->custAuthFlg           = ref.custAuthFlg;
    this->mainFlg               = ref.mainFlg;
    this->tpNatEn               = ref.tpNatEn;
    this->entDictIdFlg          = ref.entDictIdFlg;
    this->synonFlg              = ref.synonFlg;
    this->listFlg               = ref.listFlg;
    this->qSearchFlg            = ref.qSearchFlg;
    this->logicalFlg            = ref.logicalFlg;
    this->interf                = ref.interf;
    this->natIndex              = ref.natIndex;
    this->isNullNatIndex        = ref.isNullNatIndex;
    this->parIndex              = ref.parIndex;
    this->isNullParIndex        = ref.isNullParIndex;
    this->precompFlg            = ref.precompFlg;
    this->usePrecompFlg         = ref.usePrecompFlg;
    this->precompStdFormatId    = ref.precompStdFormatId;
    this->precompUsrFormatId    = ref.precompUsrFormatId;
    this->precompRankN          = ref.precompRankN;
    this->custNbr               = ref.custNbr;
    this->precompNbr            = ref.precompNbr;
    this->primKeyNbr            = ref.primKeyNbr;
    this->primKeyTab            = ref.primKeyTab;
    this->visKeyNbr             = ref.visKeyNbr;
    this->visUnKeyIdx           = ref.visUnKeyIdx;
    this->useScreenFlg          = ref.useScreenFlg;
    this->inputCtrlFlg          = ref.inputCtrlFlg;
    this->notepadFlg            = ref.notepadFlg;
    this->copyRightEn           = ref.copyRightEn;
    this->iSelectStringIndex    = ref.iSelectStringIndex;
    this->enSelectMode          = ref.enSelectMode;
    this->enSelectNature        = ref.enSelectNature;
    this->dictSelectFunction    = ref.dictSelectFunction;
    this->idSelectList          = ref.idSelectList;
    this->pszList               = ref.pszList;
    this->fullSearchFlg         = ref.fullSearchFlg;
    this->idLinkedObject        = ref.idLinkedObject;
    this->entMDFlg              = ref.entMDFlg;
    this->entDefInCFlg          = ref.entDefInCFlg;
    this->virtualEntFlg         = ref.virtualEntFlg;
    this->virtualAttrFlg        = ref.virtualAttrFlg;
    this->validEntFlg           = ref.validEntFlg;
    this->srcEntDictIdIdx       = ref.srcEntDictIdIdx;
    this->orgEntityNbr          = ref.orgEntityNbr;
    this->orgEntityTab          = ref.orgEntityTab;
    this->useEntityNbr          = ref.useEntityNbr;
    this->useEntityTab          = ref.useEntityTab;
    this->invertSortFlag        = ref.invertSortFlag;
    this->sortMenuId            = ref.sortMenuId;
    this->iNbLinkedDimObj       = ref.iNbLinkedDimObj;
    this->dictLabelFlg          = ref.dictLabelFlg;
    this->entNatEn              = ref.entNatEn;
    this->xdStatusEn            = ref.xdStatusEn;
    this->bIsInitEntity         = ref.bIsInitEntity;
    this->securityLevelEn       = ref.securityLevelEn;
    this->automaticMask         = ref.automaticMask;
    this->adminFctDictId        = ref.adminFctDictId;
    this->pkRuleEn              = ref.pkRuleEn;
    this->auditAuthEn           = ref.auditAuthEn;
    this->activeAuthEn          = ref.activeAuthEn;
    this->updFctAuthEn          = ref.updFctAuthEn;
    this->externalSeqAuthEn     = ref.externalSeqAuthEn;
    this->loadDictRuleEn        = ref.loadDictRuleEn;
    this->dmlModifTrackEn       = ref.dmlModifTrackEn;
    this->partAuthEn            = ref.partAuthEn;
    this->dlmAuthEn             = ref.dlmAuthEn;
    this->multiEntityCateg.set(ref.multiEntityCateg.get());
    this->meSpecialisationEn    = ref.meSpecialisationEn;
    this->deleteRuleEn          = ref.deleteRuleEn;
    this->objModifStatEn        = ref.objModifStatEn;
    this->tableModifStatEn      = ref.tableModifStatEn;
    this->lastModifEn           = ref.lastModifEn;
    this->dbRuleEn              = ref.dbRuleEn;
    this->linkedEntityDictId    = ref.linkedEntityDictId;
    this->linkedEntityStp       = ref.linkedEntityStp;
    this->linkEntitiesMap       = ref.linkEntitiesMap; /* PMSTA-29885 - LJE - 180123 */
    this->physicalEntitiesMap   = ref.physicalEntitiesMap; /* PMSTA-37374 - LJE - 201214 */
    this->physicalEntityDictId  = ref.physicalEntityDictId;
    this->physicalEntityStp     = ref.physicalEntityStp;
    this->pkEntityStp           = ref.pkEntityStp;
    this->shadowEntityStp       = ref.shadowEntityStp;
    this->beEntityStp           = ref.beEntityStp;
    this->objectEn              = ref.objectEn;
    this->bkAttr                = ref.bkAttr;
    this->bkAttrNbr             = ref.bkAttrNbr;
    this->multiEntUKFlg         = ref.multiEntUKFlg;
    this->xdEntityId            = ref.xdEntityId;
    this->changeSetAuthEn       = ref.changeSetAuthEn;
    this->lastModifDate         = ref.lastModifDate;
    this->nameStr               = ref.nameStr;
    this->labelStr              = ref.labelStr;
    this->uniLabelStr           = ref.uniLabelStr;
    this->licenseKeyEn          = ref.licenseKeyEn;
    this->licenseAccessStatusEn = ref.licenseAccessStatusEn;

    strcpy(this->mdSqlName, ref.mdSqlName);
    strcpy(this->dbSqlName, ref.dbSqlName);
    strcpy(this->custSqlName, ref.custSqlName);
    strcpy(this->precompSqlName, ref.precompSqlName);
    this->databaseName = ref.databaseName;
    strcpy(this->segName, ref.segName);
    this->custDbName   = ref.custDbName;
    strcpy(this->precompDbName, ref.precompDbName);
    strcpy(this->shortSqlname, ref.shortSqlname);
    strcpy(this->aliasSqlname, ref.aliasSqlname);
    strcpy(this->pszSelectString, ref.pszSelectString);

    this->init(true);

    return *this;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass &DictEntityClass::addDictAttrib(const DICT_T dictId, const FIELD_IDX_T idx, const std::string &sqlname)
{
    DictAttribClass *dictAttribStp = new DictAttribClass();
    this->m_mp.ownerObject(dictAttribStp);
    
    if (this->attribMap.insert(make_pair(dictId, dictAttribStp)).second == false)
    {
        assert(0 && SYS_Stringer("Duplicate attribute_dict_id :", dictId, ", ", dictAttribStp->sqlName).c_str());
    }
    
    strcpy(dictAttribStp->sqlName, sqlname.c_str());

    dictAttribStp->entDictId     = this->entDictId;
    dictAttribStp->attrDictId    = dictId;
    dictAttribStp->dictEntityStp = this;

    if (idx >= 0)
    {
        dictAttribStp->progN = idx;
        assert(dictAttribStp->progN == static_cast<INT_T>(this->buildAttr.size()));
        this->buildAttr.push_back(dictAttribStp);
    }

    if (sqlname.empty() == false)
    {
        this->sortedAttr.insert(std::make_pair(sqlname, dictAttribStp));
    }

    if (this->virtualEntFlg == FALSE)
    {
#ifdef AAACHECKMD
        assert(dictAttribStp->attrDictId > 1000);
        auto it = SV_DictDictAttribMap.find(dictAttribStp->attrDictId);
        assert(it == SV_DictDictAttribMap.end());
#endif

        SV_DictDictAttribMap.insert(make_pair(dictAttribStp->attrDictId, dictAttribStp));
    }
    return *dictAttribStp;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :   Adding Virtual Attributes to SV_DictDictAttribMap
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-55842 - Suparna - 20240509
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass& DictEntityClass::addVirtualAttrib(const DICT_T dictId, const FIELD_IDX_T idx, const std::string& sqlname)
{
    DictAttribClass* virtualAttribSt = new DictAttribClass();
    this->m_mp.ownerObject(virtualAttribSt);
    
    if (this->attribMap.insert(make_pair(dictId, virtualAttribSt)).second == false)
    {
        assert(0 && "Duplicate attribute_dict_id");
    }
    
    strcpy(virtualAttribSt->sqlName, sqlname.c_str());
    
    virtualAttribSt->entDictId = this->entDictId;
    virtualAttribSt->attrDictId = dictId;
    virtualAttribSt->dictEntityStp = this;
    
    if (idx >= 0)
    {
        virtualAttribSt->progN = idx;
        assert(virtualAttribSt->progN == static_cast<INT_T>(this->buildAttr.size()));
        this->buildAttr.push_back(virtualAttribSt);
    }
    
    if (sqlname.empty() == false)
    {
        this->sortedAttr.insert(std::make_pair(sqlname, virtualAttribSt));
    }
    
    auto it = SV_DictDictAttribMap.find(virtualAttribSt->attrDictId);
    if (it != SV_DictDictAttribMap.end())
    {
        SV_DictDictAttribMap.erase(virtualAttribSt->attrDictId);
    
    }
    SV_DictDictAttribMap.insert(make_pair(virtualAttribSt->attrDictId, virtualAttribSt));;
    return *virtualAttribSt;
}
/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass *DictEntityClass::getDictAttribByIdx(FIELD_IDX_T idx)
{
    if (idx >= 0 &&
        idx < static_cast<FIELD_IDX_T>(this->attr.size()))
    {
        return this->attr[idx];
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass *DictEntityClass::getDictAttribByDictId(DICT_T dictId)
{
    auto it = this->attribMap.find(dictId);
    if (it != this->attribMap.end())
    {
        return it->second;
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass *DictEntityClass::getDictAttribByShortIdx(FIELD_IDX_T shortIdx)
{
    for (auto &it : this->attr)
    {
        if (it->isNullShortIdx == false && it->shortIdx == shortIdx)
        {
            return it;
        }
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictAttribClass *DictEntityClass::getDictAttribBySqlName(const std::string &sqlname)
{
    auto it = this->sortedAttr.find(sqlname);
    if (it != this->sortedAttr.end())
    {
        return it->second;
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   PermitedValuesClass::getLabel
**
**  Description :   Get label from permited value
**
**  Argument    :   none
**
**  Return      :   char*
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
char *PermitedValuesClass::getLabel ()
{
    if (this->m_label.empty() == false)
    {
        return (char*) this->m_label.c_str();
    }
    else if (this->pdictPermVal != nullptr)
    {
        if (dictidLang > 0)
        {
            const char			*theLabel = NULL;
            DbiConnectionHelper dbiConnHelper;
            RET_CODE            retCode = DICT_GetLabel(dictidLang, 1105, this->pdictPermVal->dictId, &theLabel, dbiConnHelper);
            if (retCode == RET_SUCCEED)
            {
                return (char*) theLabel;
            }
            else if ((retCode == RET_GEN_INFO_NOACTION) &&
                     (this->pdictPermVal->labelStr.empty() == false))
            {
                return (char*) this->pdictPermVal->labelStr.c_str();
            }
        }
        else if (this->pdictPermVal->labelStr.empty() == false)
        {
            return (char*) this->pdictPermVal->labelStr.c_str();
        }
    }
    return nullptr;
}


/************************************************************************
**
**  Function    :   PermitedValuesClass::getName
**
**  Description :   Get Name from permited value
**
**  Argument    :   none
**
**  Return      :   char*
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
char *PermitedValuesClass::getName ()
{
    if (this->m_name.empty() == false)
    {
        return (char*) this->m_name.c_str();
    }
    else if ((this->pdictPermVal != nullptr) &&
             (this->pdictPermVal->nameStr.empty() == false))
    {
        return (char*) this->pdictPermVal->nameStr.c_str();
    }
    return nullptr;
}


/************************************************************************
**
**  Function    :   PermitedValuesClass::setLabel
**
**  Description :   Set label for permited value
**
**  Argument    :   char *pszLabel
**
**  Return      :   void
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
void PermitedValuesClass::setLabel (char *pszLabel)
{
    if ((pszLabel != nullptr) &&
        (pszLabel[0] != END_OF_STRING))
    {
        this->m_label.assign(pszLabel);
    }
}


/************************************************************************
**
**  Function    :   PermitedValuesClass::setUniLabel
**
**  Description :   Set label for permited value
**
**  Argument    :   char *pszLabel
**
**  Return      :   void
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
void PermitedValuesClass::setUniLabel (UChar *pszuniLabel)
{
    if (pszuniLabel != nullptr)
    {
        this->m_uniLabel = pszuniLabel;
    }
}


/************************************************************************
**
**  Function    :   PermitedValuesClass::getUniLabel
**
**  Description :   Set uni label for permited value
**
**  Argument    :   none
**
**  Return      :   char*
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
UChar *PermitedValuesClass::getUniLabel ()
{
    if ((this->m_uniLabel != nullptr) &&
        (this->m_uniLabel.isEmpty() == false))
    {
        return (UChar*) this->m_uniLabel.getTerminatedBuffer();
    }
    else if (this->pdictPermVal != nullptr)
    {
        if (dictidLang > 0)
        {
            const UChar			*theUniLabel = NULL;
            DbiConnectionHelper dbiConnHelper;
            RET_CODE            retCode = DICT_GetUniLabel(dictidLang, 1105, this->pdictPermVal->dictId, &theUniLabel, dbiConnHelper);
            if (retCode == RET_SUCCEED)
            {
                return (UChar*) theUniLabel;
            }
            else if ((retCode == RET_GEN_INFO_NOACTION) &&
                     (this->pdictPermVal->uniLabelStr.isEmpty() == false))
            {
                return (UChar*) this->pdictPermVal->uniLabelStr.getTerminatedBuffer();
            }
        }
        else if (this->pdictPermVal->uniLabelStr.isEmpty() == false)
        {
            return (UChar*) this->pdictPermVal->uniLabelStr.getTerminatedBuffer();
        }
    }
    return nullptr;
}


/************************************************************************
**
**  Function    :   PermitedValuesClass::setName
**
**  Description :   Set name for permited value
**
**  Argument    :   char *pszLabel
**
**  Return      :   void
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
void PermitedValuesClass::setName (char *pszName)
{
    if ((pszName != nullptr) &&
        (pszName[0] != END_OF_STRING))
    {
        this->m_name.assign(pszName);
    }
}


/************************************************************************
**
**  Function    :   DictEntityClass::
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictCriterClass *DictEntityClass::addDictCriteria(DBA_DYNTYPE_ENUM critDynTypeEn, FIELD_IDX_T critProgN)
{
    DictCriterClass* &dictCriteriaStp = (critDynTypeEn == DynType_All ? 
                                         this->allDictCriteriaMap[critProgN] : 
                                         this->shortDictCriteriaMap[critProgN]);

    if (dictCriteriaStp == nullptr)
    {
        dictCriteriaStp = new DictCriterClass();
        this->m_mp.ownerObject(dictCriteriaStp);
    }

    dictCriteriaStp->entDictId = this->entDictId;
    dictCriteriaStp->dynNatEn  = critDynTypeEn;
    dictCriteriaStp->progN     = critProgN;
    return dictCriteriaStp;
}

/************************************************************************
**
**  Function    :   DictEntityClass::getDictCriteria
**
**  Description :   Set denormalized information on dict_entity,
**                  call this function after each modification
**                  of dict_entity or dict_attribute modification
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
DictCriterClass *DictEntityClass::getDictCriteria(DBA_DYNTYPE_ENUM critDynTypeEn, FIELD_IDX_T critProgN)
{
    DICT_CRITER_STP dictCriteriaStp = nullptr;

    if (critDynTypeEn == DynType_All)
    {
        auto it = this->allDictCriteriaMap.find(critProgN);
        if (it != this->allDictCriteriaMap.end())
        {
            dictCriteriaStp = it->second;
        }
    }
    else
    {
        auto it = this->shortDictCriteriaMap.find(critProgN);
        if (it != this->shortDictCriteriaMap.end())
        {
            dictCriteriaStp = it->second;
        }
    }

    return dictCriteriaStp;
}

/************************************************************************
**
**  Function    :   DictEntityClass::setDbSqlName
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation	:   PMSTA-58084 - LJE - 240729
**
**  Modif.		:
**
*************************************************************************/
void DictEntityClass::setDbSqlName(const char *newDbSqlName)
{
    if (newDbSqlName != nullptr &&
        strcmp(newDbSqlName, this->dbSqlName) != 0)
    {
        if (this->dbSqlName[0] != 0)
        {
            SV_DbSqlNameDictDictEntityMap.erase(this->dbSqlName);
        }

        SYS_Bzero(this->dbSqlName, SYSNAME_T_LEN + 1);
        strncpy(this->dbSqlName, newDbSqlName, SYSNAME_T_LEN);
        SV_DbSqlNameDictDictEntityMap[newDbSqlName] = this;
    }
}

/************************************************************************
**
**  Function    :   DictEntityClass::addDictEntityConstr
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation	:   PMSTA-26108 - LJE - 171031
**
**  Modif.		:
**
*************************************************************************/
void DictEntityClass::addDictEntityConstr(DICT_ATTRIB_STP dictAttribStp, DICT_ENTITY_STP refDictEntityStp, DICT_ATTRIB_STP refAttribStp)
{
    const DictEntityConstrKey dictEntityConstrKey(this->entDictId, refDictEntityStp->entDictId, refAttribStp->attrDictId);

    auto constrIt = this->dictEntityConstrMap.find(dictEntityConstrKey);

    if (constrIt == this->dictEntityConstrMap.end())
    {
        constrIt = this->dictEntityConstrMap.insert(make_pair(dictEntityConstrKey, DictEntityConstrClass())).first;
    }

    DictEntityConstrClass &dictEntityConstr = constrIt->second;
    if (dictEntityConstr.refDictAttribStp == nullptr ||
        dictEntityConstr.refDeleteRuleEn  == RefDelRule_Inherited)
    {
        dictEntityConstr.entityDictId     = this->entDictId;
        dictEntityConstr.entitySqlName    = this->dbSqlName;
        dictEntityConstr.refEntityDictId  = refDictEntityStp->entDictId;
        dictEntityConstr.refDictEntityStp = refDictEntityStp;
        dictEntityConstr.refEntitySqlName = refDictEntityStp->dbSqlName;
        dictEntityConstr.refDictAttribStp = refAttribStp;
        dictEntityConstr.refAttribDictId  = refAttribStp->attrDictId;
        dictEntityConstr.refAttribSqlName = refAttribStp->sqlName;
        dictEntityConstr.refCheckRuleEn   = dictAttribStp->refCheckRuleEn;
        dictEntityConstr.refDeleteRuleEn  = dictAttribStp->refDeleteRuleEn;

        if (dictAttribStp->logicalFlg == TRUE || dictAttribStp->calcEn == DictAttr_Denorm)
        {
            int              uniqueAttribNbr = 0;
            if (refAttribStp->busKeyFlg == TRUE)
            {
                uniqueAttribNbr = refDictEntityStp->bkAttrNbr;
            }
            else if (refAttribStp->primFlg == TRUE)
            {
                uniqueAttribNbr = refDictEntityStp->primKeyNbr;
            }

            if (uniqueAttribNbr)
            {
                DICT_ATTRIB_STP checkAttribStp = refAttribStp;
                while (checkAttribStp)
                {
                    if (checkAttribStp->busKeyFlg == refAttribStp->busKeyFlg &&
                        checkAttribStp->primFlg == refAttribStp->primFlg)
                    {
                        uniqueAttribNbr--;
                    }

                    checkAttribStp = checkAttribStp->linkedAttrDictStp;
                }
            }
            else
            {
                uniqueAttribNbr = 1;
            }

            if (uniqueAttribNbr == 0)
            {
                if (dictAttribStp->dbMandatoryFlg == TRUE)
                {
                    dictEntityConstr.multiplicityEn = Multiplicity_OneToOne;
                }
                else
                {
                    dictEntityConstr.multiplicityEn = Multiplicity_ZeroToOne;
                }
            }
            else
            {
                if (dictAttribStp->dbMandatoryFlg == TRUE)
                {
                    dictEntityConstr.multiplicityEn = Multiplicity_OneToMany;
                }
                else
                {
                    dictEntityConstr.multiplicityEn = Multiplicity_ZeroToMany;
                }
            }
        }
        else if (refAttribStp->dbMandatoryFlg == TRUE)
        {
            dictEntityConstr.multiplicityEn = Multiplicity_OneToMany;
        }
        else
        {
            dictEntityConstr.multiplicityEn = Multiplicity_ZeroToMany;
        }

        if (dictEntityConstr.refCheckRuleEn == RefChkRule_Inherit)
        {
            for (size_t i = 0; i < refAttribStp->linkAttrDictTab.size(); ++i)
            {
                if (refAttribStp->linkAttrDictTab[i]->refCheckRuleEn == RefChkRule_Checked)
                {
                    dictEntityConstr.refCheckRuleEn = RefChkRule_Checked;
                    break;
                }
            }
        }

        if (dictEntityConstr.multiplicityEn != Multiplicity_ZeroToOne &&
            dictEntityConstr.multiplicityEn != Multiplicity_OneToOne)
        {
            if (dictEntityConstr.refDeleteRuleEn == RefDelRule_CascadeDelete ||
                refAttribStp->dbMandatoryFlg == TRUE)
            {
                dictEntityConstr.aggregationEn = Aggegation_Composition;
            }
            else
            {
                dictEntityConstr.aggregationEn = Aggegation_Aggregation;
            }
        }

        /* Hard coded part, should be removed... */
        if (refDictEntityStp->objectEn == ExtOrder)
        {
            DICT_ENTITY_STP linkDictentityStp = DBA_GetEntityBySqlName("ext_order_bck");
            if (linkDictentityStp)
            {
                this->addDictEntityConstr(dictAttribStp, linkDictentityStp, refAttribStp);
            }
        }
        else if (refDictEntityStp->objectEn == EOp ||
                 refDictEntityStp->objectEn == GlExecFeeEnt)
        {
            DICT_ENTITY_STP linkDictentityStp = DBA_GetEntityBySqlName("ext_transaction");
            if (linkDictentityStp)
            {
                this->addDictEntityConstr(dictAttribStp, linkDictentityStp, refAttribStp);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DictEntityClass::bIsPrimaryKey()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171103
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isPrimaryKey(std::string attribSqlName)
{
    for (int i = 0; i < this->primKeyNbr; i++)
    {
        if (attribSqlName.compare(this->primKeyTab[i]->sqlName) == 0)
        {
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::bIsBusinessKey()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171103
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isBusinessKey(std::string attribSqlName)
{
    for (int i = 0; i < this->bkAttrNbr; i++)
    {
        if (attribSqlName.compare(this->bkAttr[i]->sqlName) == 0)
        {
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::isPhysicalEntity()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-28698 - LJE - 180502
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isPhysicalEntity(TARGET_TABLE_ENUM targetTableEn)
{
    if (this->logicalFlg == FALSE &&
        this->dbRuleEn != DbRule_NotInDatabase &&
        this->dbRuleEn != DbRule_Template &&           /* PMSTA-28698 - LJE - 180501 */
        (this->dbRuleEn != DbRule_NotMainTable || targetTableEn == TargetTable_UserDefinedFields) &&
        (this->dbRuleEn != DbRule_OnlyMainTable || targetTableEn != TargetTable_UserDefinedFields))
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::isMetaDict()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-28698 - LJE - 180502
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isMetaDict()
{
    if (this == nullptr ||
        this->entNatEn == EntityNat_All ||
        this->entNatEn == EntityNat_Internal ||
        this->entNatEn == EntityNat_Virtual)
    {
        return false;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DictEntityClass::isUserScriptAuthorized()
**
**  Description :   indicate if user script (DV, filter and IC) are authotized for the entity
**
**  Argument    :   none
**
**  Return      : 0 if bootstrap entity or dict_function
**                1 else
**
**  Creation	:   HFI-PMSTA-48894-220421
**  Modif.		:   
**
*************************************************************************/
bool DictEntityClass::isUserScriptAuthorized()
{
    if (((this->bIsInitEntity == true) ||
        (this->objectEn == DictFct)) &&
        (SYS_GetEnv("AAATESTMDENTSCRIPTWITHUSERSCRIPT") == NULLSTR))
    {
        return false;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DictEntityClass::isId()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-45027 - LJE - 210608
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isId() const
{
    if (this->pkRuleEn == PkRule_Identity ||
        this->pkRuleEn == PkRule_ExternalPk)
    {
        return true;
    }
    else if (this->primKeyNbr == 1 &&
        (this->primKeyTab[0]->dataTpProgN == IdType ||
         this->primKeyTab[0]->dataTpProgN == DictType))
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::getIdIdx()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   char *
**
**  Creation	:   PMSTA-45413 - LJE - 210618
**
**  Modif.		:
**
*************************************************************************/
FIELD_IDX_T DictEntityClass::getIdIdx(DBA_DYNTYPE_ENUM dynStEn) const
{
    if (this->isId())
    {
        switch (dynStEn)
        {
            case DynType_All:
                return this->primKeyTab[0]->progN;

            case DynType_Short:
                return this->primKeyTab[0]->shortIdx;

            default:
                break;
        }
    }
    return Null_Dynfld;
}

/************************************************************************
**
**  Function    :   DictEntityClass::getId()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   char *
**
**  Creation	:   PMSTA-45413 - LJE - 210618
**
**  Modif.		:
**
*************************************************************************/
ID_T DictEntityClass::getId(const DBA_DYNFLD_STP recordStp) const
{
    if (recordStp->getObjectEn() == this->objectEn)
    {
        auto idIdx = getIdIdx(recordStp->getDynTypeEn());
        if (idIdx != Null_Dynfld && IS_NOTNULL(recordStp, idIdx))
        {
            return GET_ID(recordStp, idIdx);
        }
    }
    return 0;
}

/************************************************************************
**
**  Function    :   DictEntityClass::setId()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   char *
**
**  Creation	:   PMSTA-45413 - LJE - 210618
**
**  Modif.		:
**
*************************************************************************/
void DictEntityClass::setId(DBA_DYNFLD_STP recordStp, ID_T newId)
{
    if (recordStp->getObjectEn() == this->objectEn)
    {
        auto idIdx = getIdIdx(recordStp->getDynTypeEn());
        if (idIdx != Null_Dynfld)
        {
            SET_ID(recordStp, idIdx, newId);
        }
    }
}

/************************************************************************
**
**  Function    :   DictEntityClass::isCode()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-45413 - LJE - 210618
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isCode() const
{
    if (this->bkAttrNbr == 1 &&
        GET_CTYPE(this->bkAttr[0]->dataTpProgN) == CharPtrCType)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DictEntityClass::getCode()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   char *
**
**  Creation	:   PMSTA-45413 - LJE - 210618
**
**  Modif.		:
**
*************************************************************************/
const char *DictEntityClass::getCode(DBA_DYNFLD_STP recordStp) const
{
    if (this->isCode() && recordStp->getObjectEn() == this->objectEn)
    {
        if (recordStp->isAllDynSt())
        {
            return GET_SYSNAME(recordStp, this->bkAttr[0]->progN);
        }
        if (recordStp->isShortDynSt())
        {
            return GET_SYSNAME(recordStp, this->bkAttr[0]->shortIdx);
        }
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DictEntityClass::getParentObjectEn()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-55668 - LJE - 240313
**
**  Modif.		:
**
*************************************************************************/
OBJECT_ENUM DictEntityClass::getParentObjectEn(const DBA_DYNFLD_STP recordStp) const
{
    OBJECT_ENUM     subObjectEn = NullEntity;

    if (this->bkAttrNbr > 1 &&
        this->dbBKTab[0]->refDictEntityStp != nullptr &&
        this->dbBKTab[0]->refDictEntityStp->objectEn == DictEntity &&
        this->dbBKTab[1]->linkedAttrDictStp == this->dbBKTab[0])
    {
        subObjectEn = DBA_GetObjectEnum(GET_DICT(recordStp, this->dbBKTab[0]->progN));
    }

    return subObjectEn;
}

/************************************************************************
**
**  Function    :   DictEntityClass::isMultiBusinessEntityManagement()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   bool
**
**  Creation	:   PMSTA-26108 - LJE - 171110
**
**  Modif.		:
**
*************************************************************************/
bool DictEntityClass::isMultiBusinessEntityManagement()
{
    return this->multiEntityCateg.isMultiEntityCateg();
}

/************************************************************************
**
**  Function    :   DictEntityClass::finish()
**
**  Description :
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-37374 - LJE - 210414
**
**  Modif.		:
**
*************************************************************************/
void DictEntityClass::finish()
{
    bool bHaveLogAttrib = false;

    /* REF9789 - LJE - 040102 */
    this->validEntFlg = TRUE;
    /* REF10342 - LJE - 040618 */
    this->entMDFlg = TRUE;

    /* Manage use screen flag DVP580-XFH-970902 */
    this->useScreenFlg = TRUE;

    /* No visual key */
    this->visUnKeyIdx = -1;

    FIELD_IDX_T localProgN = 0;
    for (auto& dictAttribStp : this->buildAttr)
    {
        /* PMSTA-26108 - LJE - 171127 */
        if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
        {
            if (dictAttribStp->custFlg == TRUE)
            {
                this->custNbr--;
                dictAttribStp->custFlg = FALSE;
                this->bMultiEntityOnCustom = true;
            }

            if (dictAttribStp->precompFlg == TRUE)
            {
                this->precompNbr--;
                dictAttribStp->precompFlg = FALSE;
                this->bMultiEntityOnPrecomp = true;
            }
        }

        dictAttribStp->virtualAttrFlg = FALSE; /* PMSTA-13109 - LJE - 111215 */

        if (dictAttribStp->primFlg == TRUE)
        {
            ++this->primKeyNbr;
        }
        /* PMSTA-18593 - LJE - 151027 */
        else if (dictAttribStp->isNullProgPkN == false && EV_AAAInstallLevel == 0)
        {
            dictAttribStp->progPkN = 0;
            dictAttribStp->isNullProgPkN = true;
        }


        if (dictAttribStp->busKeyFlg == TRUE &&
            dictAttribStp->logicalFlg == FALSE)
        {
            ++this->visKeyNbr;

            if (this->visKeyNbr == 1)
            {
                /* Init unique visual key index */
                this->visUnKeyIdx = dictAttribStp->progN;
            }
            else
            {
                /* Several visual key */
                this->visUnKeyIdx = -1;
            }
        }

        if (dictAttribStp->logicalFlg == TRUE)
        {
            bHaveLogAttrib = true;

            /* Setup inputCtrlFlg - DVP587 */
            if (strcmp(dictAttribStp->sqlName, "script_control") == 0)
            {
                this->inputCtrlFlg = TRUE;
            }

            /* Setup notepadFlg - DVP587 */
            if (strcmp(dictAttribStp->sqlName, "notepad") == 0)
            {
                this->notepadFlg = TRUE;
            }
        }
        else
        {
            dictAttribStp->progN = localProgN++;

            assert(dictAttribStp->progN == static_cast<INT_T>(this->attr.size()));
            this->attr.push_back(dictAttribStp);
        }

        /* PMSTA-11505 - LJE - 110408 */
        if (strstr(this->mdSqlName, "dict_") != NULL)
            this->dictLabelFlg = TRUE;
        else
            this->dictLabelFlg = FALSE;

        /* PMSTA-11505 - LJE - 110616 */
        if (dictAttribStp->precompFlg == TRUE)
        {
            if (this->usePrecompFlg == FALSE)
            {
                dictAttribStp->calcEn = DictAttr_Virtual;
            }
            dictAttribStp->mandatoryFlg = FALSE;
            dictAttribStp->editionEn = DictAttrib_EditNoEdit;
        }

        /* PMSTA-11505 - LJE - 110705 - Multi language flag are considered as virtual */
        if (dictAttribStp->multiLanguageFlg == TRUE)
        {
            dictAttribStp->calcEn = DictAttr_Virtual;
            dictAttribStp->mandatoryFlg = FALSE;
            dictAttribStp->editionEn = DictAttrib_EditNoEdit;
            dictAttribStp->dispRank = 0;
            dictAttribStp->subTypeMask = 0;
        }

        /* PMSTA-13109 - LJE - 111214 */
        dictAttribStp->logicalFkFlg = FALSE; /* OCS-43062 - LJE - 130909 */

        /* PMSTA-11505 - LJE - 110516 */
        if (dictAttribStp->isPhysicalAttribute() &&
            dictAttribStp->calcEn != DictAttr_Physical)
        {
            if (dictAttribStp->calcEn != DictAttr_ExternalSeqNo && /* PMSTA-20887 - LJE - 150903 */
                dictAttribStp->calcEn != DictAttr_PhysicalPartition)  /* PMSTA-24007 - LJE - 170726 */
            {
                dictAttribStp->setBySpecProcFlg = TRUE;
            }
        }
        else
        {
            dictAttribStp->setBySpecProcFlg = FALSE;
        }
    }

    if (bHaveLogAttrib)
    {
        for (auto& dictAttribStp : this->buildAttr)
        {
            if (dictAttribStp->logicalFlg == TRUE)
            {
                dictAttribStp->progN = localProgN++;

                assert(dictAttribStp->progN == static_cast<INT_T>(this->attr.size()));
                this->attr.push_back(dictAttribStp);
            }
        }
    }

    this->buildAttr.clear();
    this->init(false);
}

/************************************************************************
**
**  Function    :   DictEntityClass::init()
**
**  Description :   Set denormalized information on dict_entity,
**                  call this function after each modification
**                  of dict_entity or dict_attribute modification
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA-26108 - LJE - 170930
**
**  Modif.		:
**
*************************************************************************/
void DictEntityClass::init(bool bFull)
{
    int              pkAttrNbr = 0, fullPkAttrNbr = 0, fullBkAttrNbr = 0;
    OBJECT_ENUM      tmpObjEn;

    /* Reset current values */
    this->parentAttrStp              = NULL;
    this->optimisticLockingAttrStp   = NULL;
    this->externalSeqNoAttrStp       = NULL;
    this->rightToRunAttrStp          = NULL;
    this->activeAttrStp              = NULL;
    this->ownerBusinessEntAttrStp    = NULL;
    this->udOwnerBusinessEntAttrStp  = NULL;
    this->extOwnerBusinessEntAttrStp = NULL;
    this->multiEntUKFlg              = FALSE;
    this->precompSqlName[0]          = 0;
    this->custSqlName[0]             = 0;
    this->physicalEntityStp          = NULL;
    this->linkedEntityStp            = NULL;
    this->pkEntityStp                = NULL;
    this->meSpecialisationEn         = MeSpecialisation_NotApplicable;
    this->custNbr                    = 0;
    this->precompNbr                 = 0;
    this->firstCustPos               = 0;
    this->firstPrecompPos            = 0;
    this->firstLogicalPos            = 0;
    this->firstCOnlyPos              = 0;
    this->firstInternalPos           = 0;

    FREE(this->bkAttr);
    this->bkAttrNbr  = 0;

    FREE(this->primKeyTab);
    this->primKeyNbr = 0;

    FREE(this->dbPKTab);
    this->dbPKNbr    = 0;

    FREE(this->dbBKTab);
    this->dbBKNbr    = 0;

    FREE(this->udPKTab);
    this->udPKNbr = 0;

    this->logicalTab.clear();
    this->sortedAttr.clear();

    if (bFull)
    {
        this->dictEntityConstrMap.clear();
        this->dictEntityRefMap.clear();
    }

    if (this->loadDictRuleEn == LoadDictRule_BootStrap) /* PMSTA-26108 - LJE - 170821 */
    {
        this->bIsInitEntity = true;
    }
    else
    {
        this->bIsInitEntity = false;
    }

    for (auto it = this->attribMap.begin(); it != this->attribMap.end(); ++it)
    {
        this->sortedAttr.insert(make_pair(it->second->sqlName, it->second));
    }

    for (auto& dictAttribStp : this->attr)
    {
        if (dictAttribStp != nullptr)
        {
            if (dictAttribStp->primFlg == TRUE)
            {
                pkAttrNbr++;
            }
            if (dictAttribStp->busKeyFlg == TRUE)
            {
                this->bkAttrNbr++;
            }
            if (dictAttribStp->isNullProgPkN == false)
            {
                fullPkAttrNbr++;
            }
            if (dictAttribStp->isNullProgBkN == false)
            {
                fullBkAttrNbr++;
            }
            if (dictAttribStp->custFlg == TRUE && this->udPKNbr == 0 && DdlGen::getUdIdSqlName().compare(dictAttribStp->sqlName) == 0)
            {
                this->udPKNbr++;
            }
            if (dictAttribStp->custFlg == TRUE)
            {
                if (dictAttribStp->logicalFlg == FALSE)
                {
                    /* PMSTA-46259 - LJE - 211007 */
                    if (this->firstCustPos == 0)
                    {
                        this->firstCustPos = dictAttribStp->progN;
                    }

                    this->custNbr++;
                }
                else
                {
                    dictAttribStp->custFlg = FALSE;
                }
            }
            if (dictAttribStp->precompFlg == TRUE)
            {
                /* PMSTA-46259 - LJE - 211007 */
                if (this->firstPrecompPos == 0)
                {
                    this->firstPrecompPos = dictAttribStp->progN;
                }
                this->precompNbr++;
            }
        }
    }

    if (pkAttrNbr > 0)
    {
        if ((this->primKeyTab = (DICT_ATTRIB_STP*)
             CALLOC(pkAttrNbr, sizeof(DICT_ATTRIB_STP))) == NULL)
        {
            return;
        }
    }

    if (this->bkAttrNbr > 0)
    {
        if ((this->bkAttr = (DICT_ATTRIB_STP*)
            CALLOC(this->bkAttrNbr, sizeof(DICT_ATTRIB_STP))) == NULL)
        {
            return;
        }
    }

    if (fullPkAttrNbr > 0)
    {
        if ((this->dbPKTab = (DICT_ATTRIB_STP*)
            CALLOC(fullPkAttrNbr, sizeof(DICT_ATTRIB_STP))) == NULL)
        {
            return;
        }
    }

    if (fullBkAttrNbr > 0)
    {
        if ((this->dbBKTab = (DICT_ATTRIB_STP*)
            CALLOC(fullBkAttrNbr, sizeof(DICT_ATTRIB_STP))) == NULL)
        {
            return;
        }
    }

    if (this->udPKNbr > 0)
    {
        if ((this->udPKTab = (DICT_ATTRIB_STP*)
             CALLOC(this->udPKNbr, sizeof(DICT_ATTRIB_STP))) == NULL)
        {
            return;
        }
        this->udPKNbr = 0;
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->linkedEntityDictId > 0)
    {
        DBA_GetObjectEnum(this->linkedEntityDictId, &tmpObjEn);

        if (tmpObjEn != NullEntity)
        {
            this->linkedEntityStp = DBA_GetDictEntitySt(tmpObjEn);
            this->linkedEntityStp->linkEntitiesMap.insert(make_pair(this->entDictId, this)); /* PMSTA-29885 - LJE - 180123 */
        }
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->physicalEntityDictId > 0)
    {
        DBA_GetObjectEnum(this->physicalEntityDictId, &tmpObjEn);
        if (tmpObjEn != NullEntity)
        {
            this->physicalEntityStp = DBA_GetDictEntitySt(tmpObjEn);
            this->physicalEntityStp->physicalEntitiesMap.insert(make_pair(this->entDictId, this)); /* PMSTA-37374 - LJE - 201214 */
        }
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->pkRuleEn == PkRule_ExternalPk)
    {
        string sqlName;
        if (this->dbRuleEn == DbRule_ShadowTable &&
            this->linkedEntityStp)
        {
            sqlName = this->linkedEntityStp->mdSqlName;
        }
        else
        {
            sqlName = this->mdSqlName;
            if (this->dbRuleEn == DbRule_ShadowTable)
            {
                sqlName = sqlName.substr(0, sqlName.length() - 3);
            }
        }
        sqlName += "_pk";

        this->pkEntityStp = DBA_GetEntityBySqlName(sqlName);
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->dbRuleEn == DbRule_ShadowTable &&
        this->linkedEntityStp != nullptr)
    {
        this->linkedEntityStp->shadowEntityStp = this;
        this->changeSetAuthEn = FeatureAuth_Enable;
        if (this->linkedEntityStp->pkEntityStp != nullptr &&
            (this->linkedEntityStp->entNatEn != EntityNat_DerivedEntity || this->linkedEntityStp->dbRuleEn == DbRule_ShadowTable))
        {
            /*PMSTA-56937 - VPR - 240712*/
            this->linkedEntityStp->changeSetAuthEn = FeatureAuth_Enable;
        }
    }

    /* PMSTA-32145 - LJE - 180718 */
    if (this->dbRuleEn == DbRule_PartialSpecialization &&
        this->linkedEntityStp != nullptr)
    {
        this->linkedEntityStp->beEntityStp = this;
        this->changeSetAuthEn = this->linkedEntityStp->changeSetAuthEn;
    }

    this->bkAttrNbr = 0;
    for (auto& dictAttribStp : this->attr)
    {
        if (dictAttribStp != nullptr)
        {
            dictAttribStp->linkedAttrDictStp = NULL;
            dictAttribStp->refDictEntityStp  = NULL;

            if (dictAttribStp->primFlg == TRUE)
            {
                this->primKeyTab[this->primKeyNbr] = dictAttribStp;
                this->primKeyNbr++;
            }
            if (dictAttribStp->busKeyFlg == TRUE)
            {
                this->bkAttr[this->bkAttrNbr] = dictAttribStp;
                this->bkAttrNbr++;
            }
            if (dictAttribStp->isNullProgPkN == false)
            {
                this->dbPKTab[this->dbPKNbr] = dictAttribStp;
                this->dbPKNbr++;
            }
            if (dictAttribStp->isNullProgBkN == false)
            {
                this->dbBKTab[this->dbBKNbr] = dictAttribStp;
                this->dbBKNbr++;
            }

            /* PMSTA-32145 - LJE - 180720 */
            if (dictAttribStp->custFlg == TRUE && this->udPKNbr == 0 && DdlGen::getUdIdSqlName().compare(dictAttribStp->sqlName) == 0)
            {
                this->udPKTab[this->udPKNbr] = dictAttribStp;
                this->udPKNbr++;
            }

            if (dictAttribStp->linkedAttrDictId != 0)
            {
                auto lnkAttribIt = this->attribMap.find(dictAttribStp->linkedAttrDictId);
                if (lnkAttribIt != this->attribMap.end())
                {
                    dictAttribStp->linkedAttrDictStp = lnkAttribIt->second;
                }
                else
                {
                    dictAttribStp->linkedAttrDictStp = DBA_GetAttributeById(dictAttribStp->linkedAttrDictId);
                }
            }

            if (dictAttribStp->logicalFlg == TRUE)
            {
                /* PMSTA-46259 - LJE - 211007 */
                if (this->firstLogicalPos == 0)
                {
                    this->firstLogicalPos = dictAttribStp->progN;
                }
                this->logicalTab.push_back(dictAttribStp);
            }

            if (dictAttribStp->calcEn == DictAttr_NoMD)
            {
                if (dictAttribStp->subFeatureEn == SubFeature::TechInternal)
                {
                    if (this->firstInternalPos == 0)
                    {
                        this->firstInternalPos = dictAttribStp->progN;
                    }
                }
                else
                {
                    if (this->firstCOnlyPos == 0)
                    {
                        this->firstCOnlyPos = dictAttribStp->progN;
                    }
                }
            }


            /* PMSTA-26250 - LJE - 170331 */
            if (this->isNullParIndex == false && dictAttribStp->progN == this->parIndex)
            {
                this->parentAttrStp = dictAttribStp;
            }

            /* PMSTA-23385 - LJE - 160712 */
            if (DdlGenDbi::getOptimisticLockingRule(dictAttribStp, EV_RdbmsVendor) != OptimisticLocking_None &&
                this->optimisticLockingAttrStp == nullptr)
            {
                this->optimisticLockingAttrStp = dictAttribStp;
            }

            if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::ExternalSequencing &&
                this->externalSeqNoAttrStp == nullptr)
            {
                this->externalSeqNoAttrStp = dictAttribStp;
            }
            else if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::UpdateFunction &&
                this->rightToRunAttrStp == nullptr)
            {
                this->rightToRunAttrStp = dictAttribStp;
            }
            else if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::AccessRightManagement)
            {
                if (strcmp(dictAttribStp->sqlName, "update_right_f") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::UpdateRight;
                }
                else if (strcmp(dictAttribStp->sqlName, "delete_right_f") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::DeleteRight;
                }
                else if (strcmp(dictAttribStp->sqlName, "right_reason_e") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::RightReason;
                }
                else if (strcmp(dictAttribStp->sqlName, "update_secu_right_f") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::UpdateSecuRight;
                }
                else if (strcmp(dictAttribStp->sqlName, "delete_secu_right_f") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::DeleteSecuRight;
                }
                else
                {
                    stringstream msg;
                    msg << "Unsupported AccessRightManagement feature attribute " << this->mdSqlName << "." << dictAttribStp->sqlName;
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
                }
            }
            else if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
            {
                if (strcmp(dictAttribStp->sqlName, "me_record_location_e") == 0)
                {
                    dictAttribStp->subFeatureEn = SubFeature::MeRecordLocation;
                }
            }

            if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::Active &&
                this->activeAttrStp == nullptr)
            {
                this->activeAttrStp = dictAttribStp;
            }

            /* PMSTA-26108 - LJE - 170818 */
            if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                this->isMultiBusinessEntityManagement() &&
                dictAttribStp->subFeatureEn == SubFeature::None)
            {
                if (this->ownerBusinessEntAttrStp == nullptr)
                {
                    this->ownerBusinessEntAttrStp = dictAttribStp;
                }

                if (this->bMultiEntityOnCustom &&
                    this->udOwnerBusinessEntAttrStp == nullptr)
                {
                    this->udOwnerBusinessEntAttrStp = dictAttribStp;
                }

                if (this->bMultiEntityOnPrecomp &&
                    this->extOwnerBusinessEntAttrStp == nullptr)
                {
                    this->extOwnerBusinessEntAttrStp = dictAttribStp;
                }
            }

            /* PMSTA-32145 - LJE - 180719 */
            if (dictAttribStp->meSpecialisationEn > this->meSpecialisationEn)
            {
                this->meSpecialisationEn = dictAttribStp->meSpecialisationEn;
            }

        }
        else
        {
            SYS_BreakOnDebug();
        }
    }

    if (this->firstCOnlyPos == 0)
    {
        this->firstCOnlyPos = this->firstLogicalPos;
    }
    if (this->firstPrecompPos == 0)
    {
        this->firstPrecompPos = this->firstCOnlyPos;
    }
    if (this->firstCustPos == 0)
    {
        this->firstCustPos = this->firstPrecompPos;
    }
    if (this->firstInternalPos == 0)
    {
        this->firstInternalPos = CAST_INT(this->attr.size());
    }

    if (this->primKeyNbr > 1)
    {
        if (TLS_Sort((char*)this->primKeyTab, (unsigned)this->primKeyNbr, sizeof(DICT_ATTRIB_STP*),
            (TLS_CMPFCT *)DBA_CmpAttribPk, NULL, SortRtnTp_None) == FALSE)
        {
            return;
        }
    }

    if (this->dbPKNbr > 1)
    {
        if (TLS_Sort((char*)this->dbPKTab, (unsigned)this->dbPKNbr, sizeof(DICT_ATTRIB_STP*),
            (TLS_CMPFCT *)DBA_CmpAttribPk, NULL, SortRtnTp_None) == FALSE)
        {
            return;
        }
    }

    if (this->bkAttrNbr > 1)
    {
        if (TLS_Sort((char*)this->bkAttr, (unsigned)this->bkAttrNbr, sizeof(DICT_ATTRIB_STP*),
            (TLS_CMPFCT *)DBA_CmpAttribBk, NULL, SortRtnTp_None) == FALSE)
        {
            return;
        }
    }

    if (this->dbBKNbr > 1)
    {
        if (TLS_Sort((char*)this->dbBKTab, (unsigned)this->dbBKNbr, sizeof(DICT_ATTRIB_STP*),
            (TLS_CMPFCT *)DBA_CmpAttribBk, NULL, SortRtnTp_None) == FALSE)
        {
            return;
        }
    }

    /* OCS-43062 - LJE - 130909 - Entity manage by entity_dict_id/object_id as unique key */
    if (this->isNullParIndex == false)
    {
        if ((size_t) this->parIndex < this->attr.size())
        {
            DICT_ATTRIB_STP parAttrStp = this->attr[this->parIndex];
            if (parAttrStp &&
                parAttrStp->linkedAttrDictStp != NULL &&
                ((this->bkAttrNbr == 2 &&
                  parAttrStp->busKeyFlg == TRUE &&
                  parAttrStp->linkedAttrDictStp->busKeyFlg == TRUE) ||
                  (this->primKeyNbr == 2 &&
                   parAttrStp->primFlg == TRUE &&
                   parAttrStp->linkedAttrDictStp->primFlg == TRUE)))
            {
                this->multiEntUKFlg = TRUE;
            }
        }
        else
        {
            string msg;
            SYS_StringFormat(msg, "Wrong parent attribute index (%d) for entity %s", this->parIndex, this->mdSqlName);
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());

            this->isNullParIndex = true;
            this->parIndex       = 255;
        }
    }

    if (this->isNullNatIndex == false)
    {
        if (this->natIndex >= (int) this->attr.size())
        {
            string msg;
            SYS_StringFormat(msg, "Wrong nature attribute index (%d) for entity %s", this->natIndex, this->mdSqlName);
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());

            this->isNullNatIndex = true;
            this->natIndex       = 255;
        }
    }

    DBA_SetAttribOnDictCriteria(this, this->allDictCriteriaMap);
    DBA_SetAttribOnDictCriteria(this, this->shortDictCriteriaMap);

    if (this->shortDictCriteriaMap.size())
    {
        this->criterMap.clear(); /* PMSTA-14452 - LJE - 130304 */

        for (auto criterIt = this->shortDictCriteriaMap.begin(); criterIt != this->shortDictCriteriaMap.end(); ++criterIt)
        {
            DICT_CRITER_STP criterStp = criterIt->second;

            if (criterStp && criterStp->isNullIndex != true && criterStp->index >= 0)  /* DLA for LJE - PMSTA-30099 - 180201 */
            {
                this->criterMap.insert(make_pair(criterStp->index, criterStp));
            }
        }
    }

    this->setDictEntitySqlNames();
}

/************************************************************************
**  Function             : DictEntityClass::setDictEntitySqlNames()
**
**  Description          : Get entity sql name
**                         TODO: model that in the meta-dictionary
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return
**
**                       : PMSTA-18593 - LJE - 150926
*************************************************************************/
void DictEntityClass::setDictEntitySqlNames()
{
    if (this->custAuthFlg == TRUE)
    {
        if (this->custSqlName[0] == 0)
        {
            SYS_Bzero(this->custSqlName, sizeof(SYSNAME_T));
            strcpy(this->custSqlName, "ud_");

            if ((this->dbRuleEn == DbRule_OnlyMainTable || this->dbRuleEn == DbRule_NotInDatabase || this->logicalFlg == TRUE) &&
                (this->linkedEntityStp != nullptr || this->physicalEntityStp != nullptr))
            {
                if (this->physicalEntityStp != nullptr)
                {
                    strncat(this->custSqlName, this->physicalEntityStp->mdSqlName, sizeof(SYSNAME_T) - 4);
                }
                else
                {
                    strncat(this->custSqlName, this->linkedEntityStp->mdSqlName, sizeof(SYSNAME_T) - 4);
                }
            }
            else if (this->dbRuleEn == DbRule_NotMainTable && this->physicalEntityStp != nullptr)
            {
                strncat(this->custSqlName, this->physicalEntityStp->mdSqlName, sizeof(SYSNAME_T) - 4);
            }
            else
            {
                strncat(this->custSqlName, this->mdSqlName, sizeof(SYSNAME_T) - 4);
            }
        }
    }
    else if (this->dbRuleEn == DbRule_PartialSpecialization &&
             this->linkedEntityStp &&
             this->linkedEntityStp->custAuthFlg == TRUE)
    {
        strcpy(this->custSqlName, this->dbSqlName);
    }

    /* PMSTA-18593 - LJE - 150926 */
    if (this->usePrecompFlg == TRUE)
    {
        if (this->precompSqlName[0] == 0)
        {
            strcpy(this->precompSqlName, "x_");

            /* PMSTA-26250 - LJE - 170327 */
            if (this->dbRuleEn == DbRule_ShadowTable)
            {
                string entMdSqlName = this->mdSqlName;
                entMdSqlName.erase(entMdSqlName.length() - 3);

                strncat(this->precompSqlName, entMdSqlName.c_str(), sizeof(SYSNAME_T) - 3);
            }
            else
            {
                strncat(this->precompSqlName, this->mdSqlName, sizeof(SYSNAME_T) - 3);
            }
        }
        this->precompSqlName[sizeof(SYSNAME_T) - 1] = 0;
    }
}

/************************************************************************
**  Function             : DictEntityClass::isPkToDo()
**
**  Description          :
**
**  Arguments            :
**
**  Return
**
**                       : PMSTA-37374 - LJE - 210416
*************************************************************************/
bool DictEntityClass::isPkToDo(TARGET_TABLE_ENUM   targetTableEn)
{
    return ((this->entNatEn == EntityNat_SearchFmt ||
             this->entNatEn == EntityNat_TempTable ||
             this->entNatEn == EntityNat_ReportFmt ||
             this->dbRuleEn == DbRule_ShadowTable ||
             targetTableEn == TargetTable_Precomp) == false);
}

/************************************************************************
**
**  Function    :  DdlGen::getDynTypeStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26250 - LJE - 170330
**
*************************************************************************/
string DictSprocClass::getDynTypeStr(DBA_DYNTYPE_ENUM dynTypeEn)
{
    string dynType;

    switch (dynTypeEn)
    {
        case DynType_Null:
            return "null";

        case DynType_All:
            return "all";

        case DynType_Short:
            return "short";

        case DynType_Other:
            return "other";

        case DynType_FieldList:
            return "field_list";

        case DynType_AdmArg:
            return "adm_arg";

        case DynType_AllDb:
            return "all_db";

        case DynType_MeSpecOnly:
            return "me_spec_only";

        case DynType_UdOnly:
            return "ud_only";

        case DynType_PrecompOnly:
            return "precomp_only";

        case DynType_UdMeSpecOnly:
            return "ud_me_spec_only";

        case DynType_AllDbWithUd:
            return "all_db_with_ud";

        case DynType_Full:
            return "full";

        case DynType_FullDb:
            return "full_db";

            /* PMSTA-49487 - LJE - 220609 */
        case DynType_ShortAllDb:
            return "short_all_db";

        case DynType_Unknown:
        default:
            return "unknown";
    }
}


/************************************************************************
**
**  Function    :  DictSprocClass::getProcAccess()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DBA_PROC_ACCESS_ENUM DictSprocClass::getProcAccess(const string& procAccess)
{
    DBA_PROC_ACCESS_ENUM procAccessEn;

    if (procAccess.compare("full") == 0)
    {
        procAccessEn = ProcAccess_Full;
    }
    else if (procAccess.compare("pk") == 0)
    {
        procAccessEn = ProcAccess_PrimaryKey;
    }
    else if (procAccess.compare("bk") == 0)
    {
        procAccessEn = ProcAccess_BusinessKey;
    }
    else if (procAccess.compare("unique") == 0)
    {
        procAccessEn = ProcAccess_Unique;
    }
    /* PMSTA-13109 - LJE - 111223 */
    else if (procAccess.compare("parent") == 0)
    {
        procAccessEn = ProcAccess_ParentKey;
    }
    /* PMSTA-26108 - LJE - 170811 */
    else if (procAccess.compare("nature") == 0)
    {
        procAccessEn = ProcAccess_NatureKey;
    }
    else if (procAccess.compare("ud_only") == 0)
    {
        procAccessEn = ProcAccess_UdField;
    }
    else if (procAccess.compare("all") == 0)
    {
        procAccessEn = ProcAccess_All;
    }
    /* PMSTA-46954 - LJE - 211112 */
    else if (procAccess.compare("all_db") == 0)
    {
        procAccessEn = ProcAccess_AllDb;
    }
    else if (procAccess.compare("short") == 0)
    {
        procAccessEn = ProcAccess_Short;
    }
    else
    {
        procAccessEn = ProcAccess_None;
    }
    return procAccessEn;
}

/************************************************************************
**
**  Function    :   DictSprocClass::getDmlAccessStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-34200 - LJE - 190111
**
**  Last modif. :
**
*************************************************************************/
std::string DictSprocClass::getDmlAccessStr(DBA_CONNECT_TYPE_ENUM dmlAccessEn)
{
    switch (dmlAccessEn)
    {
        case Asynchronous:
            return "Asynchronous";
            break;

        case Synchronous:
            return "Synchronous";
            break;

        case ReadOnly:
            return "ReadOnly";
            break;

        case WriteTempTable:
            return "WriteTempTable";
            break;

        case WriteTable:
            return "WriteTable";
            break;

        default:
            return "Unknown";
    }
}

/************************************************************************
**
**  Function    :   DictSprocClass::getBatchRowNumName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-37366 - LJE - 191209
**
**  Last modif. :
**
*************************************************************************/
std::string DictSprocClass::getBatchRowNumName()
{
    return "_batch_row_num";
}

/************************************************************************
**
**  Function    :  DictSprocClass::getOutputDynTypeStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26554 - LJE - 181119
**
*************************************************************************/
string DictSprocClass::getOutputDynTypeStr()
{
    return this->getDynTypeStr(this->outputDynTypeEn);
}

/************************************************************************
**
**  Function    :  DictSprocClass::getInputDynTypeStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26554 - LJE - 181119
**
*************************************************************************/
string DictSprocClass::getInputDynTypeStr()
{
    return this->getDynTypeStr(DynType_All);
}

/************************************************************************
**
**  Function    :  DictSprocClass::getProcAccessStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26250 - LJE - 170330
**
*************************************************************************/
string DictSprocClass::getProcAccessStr()
{
    string dynType;

    switch (this->procAccessEn)
    {
        case ProcAccess_Full:
            return "full";

        case ProcAccess_PrimaryKey:
            return "pk";

        case ProcAccess_BusinessKey:
            return "bk";

        case ProcAccess_Unique:
            return "unique";

        case ProcAccess_ParentKey:
            return "parent";

        case ProcAccess_NatureKey:
            return "nature";

        case ProcAccess_UdField:
            return "ud_only";

        case ProcAccess_None:
        case ProcAccess_ListKey:
        case ProcAccess_CustomKey:
        default:
            return "unknown";
    }
}

/************************************************************************
**
**  Function    :  DictSprocClass::getProcAction()
**
**  Description :
**CAL
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DBA_ACTION_ENUM DictSprocClass::getProcAction(const string& action)
{
    DBA_ACTION_ENUM procActionEn;
    if (action.compare("ins") == 0)
    {
        procActionEn = Insert;
    }
    else if (action.compare("insupd") == 0)
    {
        procActionEn = InsUpd;
    }
    else if (action.compare("upd") == 0)
    {
        procActionEn = Update;
    }
    else if (action.compare("get") == 0)
    {
        procActionEn = Get;
    }
    else if (action.compare("sel") == 0)
    {
        procActionEn = Select;
    }
    else if (action.compare("multi_select") == 0)
    {
        procActionEn = MultiSelect;
    }
    else if (action.compare("del") == 0)
    {
        procActionEn = Delete;
    }
    else if (action.compare("chk") == 0)
    {
        procActionEn = Check;
    }
    else if (action.compare("cpy") == 0)
    {
        procActionEn = Copy;
    }
    else if (action.compare("truncate") == 0)
    {
        procActionEn = Truncate;
    }
    else
    {
        procActionEn = NullAction;
    }

    return procActionEn;
}


/************************************************************************
**
**  Function    :  DictSprocClass::getProcActionStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26554 - LJE - 181119
**
*************************************************************************/
string DictSprocClass::getProcActionStr()
{
    string dynType;

    switch (this->procActionEn)
    {
        case Get:
            return "get";

        case Select:
            return "sel";

        case MultiSelect:
            return "multi_select";

        case Insert:
            return "ins";

        case Update:
            return "upd";

        case Delete:
            return "del";

        case Check:
            return "chk";

        case Copy:
            return "cpy";

        case InsUpd:
            return "insupd";

        case Notif:
        case Load:
        case SelMetaDict:
        case RegisterRpc:
        case Purge:
        case Truncate:
        case AllStdProcs:
        case Special:
        case OptiDef:
        case Custom:
        case Trigger:
        case NullAction:
        default:
            return "null";
    }
}

/************************************************************************
**
**  Function    : DictSprocClass::getSprocStdBeginStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26554 - LJE - 181119
**
*************************************************************************/
string DictSprocClass::getSprocStdBeginStr()
{
    return "#SPROC_STD_BEGIN " + this->getProcActionStr() + " " + this->getInputDynTypeStr() + " " + this->getOutputDynTypeStr() + "  " +
        (this->role == DBA_ROLE_UPD_UD_FIELDS ? "ud_only" : this->getProcAccessStr()) + " " + this->sqlName;
}

/************************************************************************
**
**  Function    : DictSprocClass::isRdbmsBatchAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-37366 - LJE - 200406
**
*************************************************************************/
bool DictSprocClass::isRdbmsBatchAllowed(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Nuodb:
            return true;
    }

    return false;
}

/************************************************************************
**
**  Function    : DictSprocClass::isRoleBatchAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-37366 - LJE - 200406
**
*************************************************************************/
bool DictSprocClass::isRoleBatchAllowed(int role)
{
    switch (role)
    {
        case DBA_ROLE_MANAGE_APPL_SESSION:
        case DBA_ROLE_SET_APPL_SESSION:
        case DBA_ROLE_UPD_APPL_SESSION_ACCESS:
        case DBA_ROLE_UPD_CHANGE_SET_APPL_SESSION:
        case DBA_ROLE_UPD_ACTIVE_F:
        case DBA_ROLE_UPD_VALIDITY_D:
        case DBA_ROLE_EXTERNAL_USE:
        case DBA_ROLE_LOGIN_DB:
            return false;
    }

    return true;
}

/************************************************************************
**
**  Function    : DictSprocClass::isActionBatchAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-37366 - LJE - 200406
**
*************************************************************************/
bool DictSprocClass::isActionBatchAllowed(DBA_ACTION_ENUM actionEn)
{
    switch (actionEn)
    {
        case Insert:
        case Update:
        case InsUpd:
        case Delete:
            return true;
    }

    return false;

}


/************************************************************************
**
**  Function    : DictSprocClass::isBatchAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-37366 - LJE - 191209
**
*************************************************************************/
bool DictSprocClass::isBatchAllowed(DBA_RDBMS_ENUM rdbmsEn)
{
    if (DictSprocClass::isRdbmsBatchAllowed(rdbmsEn) &&
        DictSprocClass::isActionBatchAllowed(this->procActionEn))
    {
        if (this->m_storedProcAccessVector.empty())
        {
            return true;
        }

        for (auto it = this->m_storedProcAccessVector.begin(); it != this->m_storedProcAccessVector.end(); ++it)
        {
            if (*(*it)->inputDynStPtr != NullDynSt &&
                DictSprocClass::isRoleBatchAllowed((*it)->subObj))
            {
                return true;
            }
        }
    }
    return false;
}

/************************************************************************
**
**  Function    : DICT_GetSrcEntityDictId
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040112
**
*************************************************************************/
RET_CODE DICT_GetSrcEntityDictId(DBA_DYNFLD_STP dynSt, DICT_T *dictIdPtr)
{
    OBJECT_ENUM objEn;

    if (dictIdPtr == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    (*dictIdPtr) = 0;
    objEn = GET_OBJ_DYNST(GET_DYNSTENUM(dynSt));

    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);

    if (dictEntityStp)
    {
        if (dictEntityStp->srcEntDictIdIdx > 0)
        {
            (*dictIdPtr) = GET_DICT(dynSt, dictEntityStp->srcEntDictIdIdx);
        }
    }

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DICT_GetMidEntityForConvert
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9764 - LJE - 040212
**
*************************************************************************/
STATIC RET_CODE DICT_GetMidEntityForConvert(OBJECT_ENUM dstObjEn, OBJECT_ENUM srcObjEn, OBJECT_ENUM *midObjEnPtr)
{
    int i, j;

    (*midObjEnPtr) = NullEntity;

    DICT_ENTITY_STP srcDictEntityStp = DBA_GetDictEntitySt(srcObjEn);
    DICT_ENTITY_STP dstDictEntityStp = DBA_GetDictEntitySt(dstObjEn);

    for (i = 0; i < dstDictEntityStp->orgEntityNbr &&
         dstDictEntityStp->orgEntityTab[i].objectEn != srcObjEn; i++);

         if (i < dstDictEntityStp->orgEntityNbr)
         {
             (*midObjEnPtr) = dstObjEn;
         }
         else
         {
             /* Search the direct link in first */ /* - LJE - 040210 */
             for (i = 0; i < srcDictEntityStp->orgEntityNbr &&
                  srcDictEntityStp->orgEntityTab[i].objectEn != dstObjEn; i++);

                  if (i < srcDictEntityStp->orgEntityNbr)
                  {
                      (*midObjEnPtr) = srcObjEn;
                  }

             if ((*midObjEnPtr) == NullEntity)
             {
                 for (i = 0; i < dstDictEntityStp->useEntityNbr; i++)
                 {
                     (*midObjEnPtr) = dstDictEntityStp->useEntityTab[i].objectEn;

                     DICT_ENTITY_STP midDictEntityStp = DBA_GetDictEntitySt((*midObjEnPtr));

                     for (j = 0; j < midDictEntityStp->orgEntityNbr &&
                          midDictEntityStp->orgEntityTab[j].objectEn != srcObjEn; j++)
                     {
                     }

                     if (j < midDictEntityStp->orgEntityNbr)
                     {
                         break;
                     }
                     else
                     {
                         (*midObjEnPtr) = NullEntity;
                     }
                 }
             }
         }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DICT_GetConvertFieldIdx
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9764 - LJE - 040212
**
*************************************************************************/
STATIC RET_CODE DICT_GetConvertFieldIdx(OBJECT_ENUM      dstObjEn,
                                        DICT_T           dstEntDictId,
                                        DBA_DYNTYPE_ENUM dstDynTypeEn,
                                        OBJECT_ENUM      srcObjEn,
                                        DICT_T           srcEntDictId,
                                        DBA_DYNTYPE_ENUM srcDynTypeEn,
                                        OBJECT_ENUM      midObjEn,
                                        DICT_ATTRIB_STP  midAttribStp,
                                        FIELD_IDX_T     *srcAttrPosPtr,
                                        FIELD_IDX_T     *dstAttrPosPtr)
{
    int i;

    (*srcAttrPosPtr) = -1;
    (*dstAttrPosPtr) = -1;

    if (midAttribStp->orgAttrNbr > 0)
    {
        if (midObjEn != srcObjEn)
        {
            for (i=0;
                 i<midAttribStp->orgAttrNbr &&
                 midAttribStp->orgAttrTab[i]->entDictId != srcEntDictId;
                 i++);

            if (i < midAttribStp->orgAttrNbr)
            {
                if (srcDynTypeEn == DynType_All)
                {
                    (*srcAttrPosPtr) = midAttribStp->orgAttrTab[i]->progN;
                }
                else if (srcDynTypeEn == DynType_Short &&
                         midAttribStp->orgAttrTab[i]->isNullShortIdx == false)
                {
                    (*srcAttrPosPtr) = midAttribStp->orgAttrTab[i]->shortIdx;
                }
                else
                {
                    (*srcAttrPosPtr) = Null_Dynfld;
                }
            }
        }
        else
        {
            (*srcAttrPosPtr) = midAttribStp->progN;
        }

        if (midObjEn != dstObjEn)
        {
            for (i=0;
                 i<midAttribStp->orgAttrNbr &&
                 midAttribStp->orgAttrTab[i]->entDictId != dstEntDictId;
                 i++);

            if (i < midAttribStp->orgAttrNbr)
            {
                if (dstDynTypeEn == DynType_All)
                {
                    (*dstAttrPosPtr) = midAttribStp->orgAttrTab[i]->progN;
                }
                else if (dstDynTypeEn == DynType_Short &&
                         midAttribStp->orgAttrTab[i]->isNullShortIdx == false)

                {
                    (*dstAttrPosPtr) = midAttribStp->orgAttrTab[i]->shortIdx;
                }
                else
                {
                    (*dstAttrPosPtr) = Null_Dynfld;
                }
            }
        }
        else
        {
            (*dstAttrPosPtr) = midAttribStp->progN;
        }
    }

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DICT_ConvertEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040112
**
*************************************************************************/
RET_CODE DICT_ConvertEntity(DBA_DYNFLD_STP dstDynSt, 
                            OBJECT_ENUM    dstObjEn,
                            DBA_DYNFLD_STP srcDynSt, 
                            OBJECT_ENUM    srcObjEn,
                            bool           bWithSetFld)
{
    OBJECT_ENUM      midObjEn;
    FIELD_IDX_T      srcAttrPos,   dstAttrPos;
    DICT_T           srcEntDictId, dstEntDictId;
    DBA_DYNTYPE_ENUM dstDynTypeEn, srcDynTypeEn;

    if (srcObjEn != GET_OBJ_DYNST(GET_DYNSTENUM(srcDynSt)) ||
        dstObjEn != GET_OBJ_DYNST(GET_DYNSTENUM(dstDynSt)))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    midObjEn     = NullEntity;

    DBA_GetDictId(srcObjEn, &srcEntDictId);
    DBA_GetDictId(dstObjEn, &dstEntDictId);

    dstDynTypeEn = GET_DYNST_TYPE(GET_DYNSTENUM(dstDynSt));
    srcDynTypeEn = GET_DYNST_TYPE(GET_DYNSTENUM(srcDynSt));

    /* REF9764 - LJE - 040212 */
    DICT_GetMidEntityForConvert(dstObjEn, srcObjEn, &midObjEn);

    if (midObjEn != NullEntity)
    {
        DICT_ENTITY_STP dstDictEntityStp = DBA_GetDictEntitySt(dstObjEn);
        DICT_ENTITY_STP midDictEntityStp = DBA_GetDictEntitySt(midObjEn);
        for (auto & midAttribStp : midDictEntityStp->attr)
        {
            DICT_GetConvertFieldIdx(dstObjEn,
                                    dstEntDictId,
                                    dstDynTypeEn,
                                    srcObjEn,
                                    srcEntDictId,
                                    srcDynTypeEn,
                                    midObjEn,
                                    midAttribStp,
                                    &srcAttrPos,
                                    &dstAttrPos);

            if (srcAttrPos >= 0 && dstAttrPos >= 0)
            {
                COPY_DYNFLD(dstDynSt, GET_DYNSTENUM(dstDynSt), dstAttrPos,
                            srcDynSt, GET_DYNSTENUM(srcDynSt), srcAttrPos);

                /* PMSTA-46681 - LJE - 231109 */
                if (bWithSetFld && IS_SETFLD(srcDynSt, srcAttrPos) == TRUE)
                {
                    SET_SETFLG_T(dstDynSt, dstAttrPos);
                }
                else
                {
                    SET_SETFLG_F(dstDynSt, dstAttrPos);
                }

            }
        }

        if (dstDictEntityStp->srcEntDictIdIdx > 0)
        {
            SET_DICT(dstDynSt, dstDictEntityStp->srcEntDictIdIdx, srcEntDictId);
        }
    }
    else
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    return (RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DICT_GetVirtualProgN
**
**  Description :
**
**  Argument    :   virtualObj
**                  originObj
**                  field
**
**  Return      :   Field posistion in virtualObj based on field in originObj
**                  or Null_Dynfld on error
**
*************************************************************************/
int DICT_GetVirtualProgN(OBJECT_ENUM virtualObj, OBJECT_ENUM originObj, FIELD_IDX_T field)
{
    int				i;
    DICT_ATTRIB_STP	attribStp = NULL;
    DICT_T			originEntityDictId;
    DICT_T			virtualEntityDictId;        /*  FIH-REF9764-040226  */

    if (((attribStp = (DICT_ATTRIB_STP)DBA_GetDictAttribSt(originObj, field)) == NULL) ||
        (DBA_GetDictId(originObj, &originEntityDictId) != RET_SUCCEED) ||
        (DBA_GetDictId(virtualObj, &virtualEntityDictId) != RET_SUCCEED))
    {
        return (Null_Dynfld);
    }

    for (i=0; i < attribStp->useAttrNbr; i++)
    {
        if (attribStp->useAttrTab[i]->entDictId == virtualEntityDictId)     /*  FIH-REF9764-040226  Replace originEntityDictId by virtualEntityDictId   */
            return(attribStp->useAttrTab[i]->progN);
    }

    return (Null_Dynfld);
}

/************************************************************************
**
**  Function    :   DBA_ConvertDynSt
**
**  Description :   Convert one dynamic structure to one another
**
**  Arguments   :   destination structure (DBA_DYNFLD_STP)
**                  destination dynamic structure definition enum (DBA_DYNST_ENUM)
**                  source structure (DBA_DYNFLD_STP)
**                  source dynamic structure definition enum (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF9743 - LJE - 040202
**  Modif.		:
**
**
*************************************************************************/
RET_CODE	DBA_ConvertDynSt(DBA_DYNFLD_STP     dstDynStp,
                             DBA_DYNST_ENUM     dstDynStEn,
                             DBA_DYNFLD_STP     srcDynStp,
                             DBA_DYNST_ENUM     srcDynStEn,
                             bool               bWithSetFld)
{
    OBJECT_ENUM      dstObjEn,      srcObjEn;
    DBA_DYNTYPE_ENUM dstDynTypeEn,  srcDynTypeEn;
    DICT_ENTITY_STP  dstDictEntity, srcDictEntity;

    /* Test */
    if (dstDynStp == NULL ||
        srcDynStp == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    dstObjEn = GET_OBJ_DYNST(GET_DYNSTENUM(dstDynStp));
    srcObjEn = GET_OBJ_DYNST(GET_DYNSTENUM(srcDynStp));

    /* Valid arguments */
    if (srcDynStEn != GET_DYNSTENUM(srcDynStp) ||
        dstDynStEn != GET_DYNSTENUM(dstDynStp))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    dstDynTypeEn = GET_DYNST_TYPE(dstDynStEn);
    srcDynTypeEn = GET_DYNST_TYPE(srcDynStEn);

    /* Cannot convert structures other than all and shorts */
    if ((dstDynTypeEn != DynType_All && dstDynTypeEn != DynType_Short) ||
        (srcDynTypeEn != DynType_All && srcDynTypeEn != DynType_Short))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    if ((dstDictEntity = DBA_GetDictEntitySt(dstObjEn)) == NULL ||
        (srcDictEntity = DBA_GetDictEntitySt(srcObjEn)) == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /* Same dynStEnum */
    if (dstDynStEn == srcDynStEn)
    {
        /* Simple DYNS_COPY */
        DBA_CopyDynStruct(dstDynStp, srcDynStp, dstDynStEn, TRUE, TRUE, TRUE, FALSE, bWithSetFld);
    }
    /* Same object, but dynStEnum are different */
    else if (dstObjEn == srcObjEn)
    {
        /* Convert Short to All */
        if (dstDynTypeEn == DynType_All)
        {
            if (srcDynTypeEn == DynType_Short)
            {
                /* Copy necessary DynFld */
                for (auto& dictAttribStp : dstDictEntity->attr)
                {
                    if (dictAttribStp->shortIdx >= 0 &&
                        dictAttribStp->isNullShortIdx == false)
                    {
                        COPY_DYNFLD(dstDynStp,
                                    dstDynStEn,
                                    dictAttribStp->progN,
                                    srcDynStp,
                                    srcDynStEn,
                                    dictAttribStp->shortIdx);

                        /* PMSTA-46681 - LJE - 231109 */
                        if (bWithSetFld && IS_SETFLD(srcDynStp, dictAttribStp->shortIdx) == TRUE)
                        {
                            SET_SETFLG_T(dstDynStp, dictAttribStp->progN);
                        }
                        else
                        {
                            SET_SETFLG_F(dstDynStp, dictAttribStp->progN);
                        }
                    }
                }
            }
            else
            {
                /* Copy necessary DynFld */
                /* PMSTA-46681 - LJE - 240220 - Manage the case of new dynamic structure */
                for (auto& dictAttribStp : dstDictEntity->attr)
                {
                    auto srcCFieldStp = DBA_GetCFielBySqlName(srcDynStEn, dictAttribStp->sqlName, nullptr);
                    if (srcCFieldStp != nullptr)
                    {
                        COPY_DYNFLD(dstDynStp,
                                    dstDynStEn,
                                    dictAttribStp->progN,
                                    srcDynStp,
                                    srcDynStEn,
                                    (*srcCFieldStp->fieldPosPtr));

                        /* PMSTA-46681 - LJE - 231109 */
                        if (bWithSetFld && IS_SETFLD(srcDynStp, (*srcCFieldStp->fieldPosPtr)) == TRUE)
                        {
                            SET_SETFLG_T(dstDynStp, dictAttribStp->progN);
                        }
                        else
                        {
                            SET_SETFLG_F(dstDynStp, dictAttribStp->progN);
                        }

                    }
                }
            }
        }
        /* Convert All to Short */
        else
        {
            /* Copy necessary DynFld */
            for (auto & dictAttribStp : srcDictEntity->attr)
            {
                if (dictAttribStp->shortIdx >= 0 &&
                    dictAttribStp->isNullShortIdx == false)
                {
                     COPY_DYNFLD(dstDynStp,
                                 dstDynStEn,
                                 dictAttribStp->shortIdx,
                                 srcDynStp,
                                 srcDynStEn,
                                 dictAttribStp->progN);

                     /* PMSTA-46681 - LJE - 231109 */
                     if (bWithSetFld && IS_SETFLD(srcDynStp, dictAttribStp->progN) == TRUE)
                     {
                         SET_SETFLG_T(dstDynStp, dictAttribStp->shortIdx);
                     }
                     else
                     {
                         SET_SETFLG_F(dstDynStp, dictAttribStp->shortIdx);
                     }

                }
            }
        }
    }
    /* Two different structures */
    else
    {
        return DICT_ConvertEntity(dstDynStp, 
                                  dstObjEn,
                                  srcDynStp, 
                                  srcObjEn,
                                  bWithSetFld);
    }

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ConvertDynSt
**
**  Description :   Convert one dynamic structure to one another
**
**  Arguments   :   destination structure (DBA_DYNFLD_STP)
**                  destination dynamic structure definition enum (DBA_DYNST_ENUM)
**                  source structure (DBA_DYNFLD_STP)
**                  source dynamic structure definition enum (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF9743 - LJE - 040202
**  Modif.		:
**
**
*************************************************************************/
RET_CODE	DBA_ConvertDynSt(DBA_DYNFLD_STP     dstDynStp,
                             DBA_DYNFLD_STP     srcDynStp,
                             bool               bWithSetFld)
{
    if (dstDynStp == NULL ||
        srcDynStp == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    return DBA_ConvertDynSt(dstDynStp, dstDynStp->getDynStEn(), srcDynStp, srcDynStp->getDynStEn(), bWithSetFld);
}


/************************************************************************
**
**  Function    :   DICT_ConvertProgN
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   FPL-REF10103-040402
**
*************************************************************************/
FIELD_IDX_T DICT_ConvertProgN ( DBA_DYNST_ENUM  dstDynStEn
                              , DBA_DYNST_ENUM  srcDynStEn
                              , FIELD_IDX_T     srcFldIdx
                              )
{
    OBJECT_ENUM         midObjEn        ,
                        srcObjEn        ,
                        dstObjEn        ;
    FIELD_IDX_T         srcAttrPos      ,
                        dstAttrPos      ,
                        dstFldIdx       ;
    DICT_T              srcEntDictId    ,
                        dstEntDictId    ;
    DBA_DYNTYPE_ENUM    dstDynTypeEn    ,
                        srcDynTypeEn    ;


    srcObjEn    = GET_OBJ_DYNST(srcDynStEn) ;
    dstObjEn    = GET_OBJ_DYNST(dstDynStEn) ;

    midObjEn    = NullEntity ;
    dstFldIdx   = Null_Dynfld ;


    DBA_GetDictId(srcObjEn, &srcEntDictId);
    DBA_GetDictId(dstObjEn, &dstEntDictId);

    dstDynTypeEn = GET_DYNST_TYPE(dstDynStEn);
    srcDynTypeEn = GET_DYNST_TYPE(srcDynStEn);

    DICT_GetMidEntityForConvert(dstObjEn, srcObjEn, &midObjEn);

    if (midObjEn != NullEntity)
    {
        DICT_ENTITY_STP midDictEntityStp = DBA_GetDictEntitySt(midObjEn);

        for (auto & midAttribStp : midDictEntityStp->attr)
        {
            DICT_GetConvertFieldIdx(dstObjEn,
                                    dstEntDictId,
                                    dstDynTypeEn,
                                    srcObjEn,
                                    srcEntDictId,
                                    srcDynTypeEn,
                                    midObjEn,
                                    midAttribStp,
                                    &srcAttrPos,
                                    &dstAttrPos);

            if (srcAttrPos == srcFldIdx)
            {
                dstFldIdx = dstAttrPos ;
            }
        }
    }
    else
    {
        return Null_Dynfld ;
    }

    return dstFldIdx;
}



/************************************************************************
**
**  Function    :   DBA_ConvertAttributeDictId
**
**  Description :   Convert an attribute dictid to another
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   FPL-REF10232-040430
**
*************************************************************************/
DICT_T  DBA_ConvertAttributeDictId  ( DBA_DYNST_ENUM    dstDynStEn
                                    , DBA_DYNST_ENUM    srcDynStEn
                                    , DICT_T            srcDictid
                                    )
{
    OBJECT_ENUM         dstObjEn,
                        srcObjEn;
    DICT_T              dstDictid = 0;
    FIELD_IDX_T         sAttrIndex;

    srcObjEn = GET_OBJ_DYNST(srcDynStEn);
    dstObjEn = GET_OBJ_DYNST(dstDynStEn);

    if ((DICT_GetAttribInfo(srcObjEn,-1,srcDictid,NULL,A_DictAttr_Prog,&sAttrIndex) == RET_SUCCEED) &&
        ((sAttrIndex = DBA_ConvertFldIdx(dstDynStEn, srcDynStEn, sAttrIndex)) > Null_Dynfld))
        DICT_GetAttribInfo(dstObjEn,sAttrIndex,-1,NULL,A_DictAttr_DictId,&dstDictid);

    return dstDictid;
}



/************************************************************************
**
**  Function    :   DBA_ConvertFldIdx
**
**  Description :   Convert a field Index of a dynamic structure to an other
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   FPL-REF10103-040402
**  Modif.		:
**
**
*************************************************************************/
FIELD_IDX_T DBA_ConvertFldIdx ( DBA_DYNST_ENUM  dstDynStEn
                              , DBA_DYNST_ENUM  srcDynStEn
                              , FIELD_IDX_T     srcFldIdx
                              )
{
    OBJECT_ENUM         dstObjEn        ,
                        srcObjEn        ;
    DBA_DYNTYPE_ENUM    dstDynTypeEn    ,
                        srcDynTypeEn    ;
    DICT_ENTITY_STP     dstDictEntity   ,
                        srcDictEntity   ;
    FIELD_IDX_T         dstFldIdx       ;


    /* Test for security*/
    if ((dstDynStEn <= InvalidEntityCst) ||
        (srcDynStEn <= InvalidEntityCst))
    {
        return Null_Dynfld ;
    }

    dstFldIdx = Null_Dynfld ;

    dstObjEn = GET_OBJ_DYNST(dstDynStEn);
    srcObjEn = GET_OBJ_DYNST(srcDynStEn);


    dstDynTypeEn = GET_DYNST_TYPE(dstDynStEn);
    srcDynTypeEn = GET_DYNST_TYPE(srcDynStEn);

    /* Cannot convert structures other than all and shorts */
    if ((dstDynTypeEn != DynType_All && dstDynTypeEn != DynType_Short) ||
        (srcDynTypeEn != DynType_All && srcDynTypeEn != DynType_Short))
    {
        return Null_Dynfld ;
    }

    if ((dstDictEntity = DBA_GetDictEntitySt(dstObjEn)) == NULL ||
        (srcDictEntity = DBA_GetDictEntitySt(srcObjEn)) == NULL)
    {
        return Null_Dynfld ;
    }


    /*** Same dynStEnum ***/
    if (dstDynStEn == srcDynStEn)
    {
        /* Simple copy */
        dstFldIdx = srcFldIdx ;
    }
    /* Same object, but dynStEnum are differents */
    else if (dstObjEn == srcObjEn)
    {
        /*** Convert Short to All ***/
        if (dstDynTypeEn == DynType_All)
        {
            /* search the field corresponding */
            for (auto & dictAttribStp : dstDictEntity->attr)
            {
                if ((dictAttribStp->shortIdx >= 0) &&
                    (dictAttribStp->isNullShortIdx == false))
                {
                    /* we have found the field */
                    if (srcFldIdx == dictAttribStp->shortIdx)
                    {
                        dstFldIdx = dictAttribStp->progN;
                    }
                }
            }
        }
        /*** Convert All to Short ***/
        else
        {
            /* search the field corresponding */
            for (auto &dictAttribStp : srcDictEntity->attr)
            {
                if (dictAttribStp->shortIdx >= 0 &&
                    dictAttribStp->isNullShortIdx == false)
                {
                    /* we have found the field */
                    if (srcFldIdx == dictAttribStp->progN)
                    {
                        dstFldIdx = dictAttribStp->shortIdx;
                    }
                }
            }
        }
    }
    /*** Two different structures ***/
    else
    {
        dstFldIdx = DICT_ConvertProgN ( dstDynStEn, srcDynStEn, srcFldIdx);
    }

    return dstFldIdx;
}


/************************************************************************
**
**  Function    :   DBA_ConvertOneFlagInFlagTab
**
**  Description :   Convert one flags tab from dynamic structure to one another
**
**  Arguments   :   destination structure (DBA_DYNFLD_STP)
**                  destination dynamic structure definition enum (DBA_DYNST_ENUM)
**                  source structure (DBA_DYNFLD_STP)
**                  source dynamic structure definition enum (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF9764 - LJE - 040212
**  Modif.		:
**
**
*************************************************************************/
void   DBA_ConvertOneFlagInFlagTab (PTR     dstFlagTab,
                                    int     dstAttrPos,
                                    PTR     srcFlagTab,
                                    int     srcAttrPos,
                                    PTR     ptrData)
{
    ((FLAG_T*) dstFlagTab)[dstAttrPos] = ((FLAG_T*) srcFlagTab)[srcAttrPos];
}


/************************************************************************
**
**  Function    :   DBA_ConvertFlagsTab
**
**  Description :   Convert one flags tab from dynamic structure to one another
**
**  Arguments   :   destination structure (DBA_DYNFLD_STP)
**                  destination dynamic structure definition enum (DBA_DYNST_ENUM)
**                  source structure (DBA_DYNFLD_STP)
**                  source dynamic structure definition enum (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF9764 - LJE - 040212
**  Modif.		:
**
**
*************************************************************************/
RET_CODE	DBA_ConvertFlagsTab(FLAG_T *dstFlagTab, DBA_DYNST_ENUM dstDynStEn,
                                FLAG_T *srcFlagTab, DBA_DYNST_ENUM srcDynStEn)
{
    return DBA_ConvertStructTab(dstFlagTab,
                                dstDynStEn,
                                srcFlagTab,
                                srcDynStEn,
                                NULL,
                                DBA_ConvertOneFlagInFlagTab);

}


/************************************************************************
**
**  Function    :   DBA_ConvertStructTab
**
**  Description :   Convert one flags tab from dynamic structure to one another
**
**  Arguments   :   destination structure (DBA_DYNFLD_STP)
**                  destination dynamic structure definition enum (DBA_DYNST_ENUM)
**                  source structure (DBA_DYNFLD_STP)
**                  source dynamic structure definition enum (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF9764 - LJE - 040212
**  Modif.		:
**
**
*************************************************************************/
RET_CODE  DBA_ConvertStructTab (PTR             ptrDest,
                                DBA_DYNST_ENUM  dstDynStEn,
                                PTR             ptrSrc,
                                DBA_DYNST_ENUM  srcDynStEn,
                                PTR             ptrData,
                                void            (*pfctConvert)(PTR,int,PTR,int,PTR))
{
    OBJECT_ENUM      midObjEn, dstObjEn, srcObjEn;
    FIELD_IDX_T      srcAttrPos,   dstAttrPos;
    DICT_T           srcEntDictId, dstEntDictId;
    DBA_DYNTYPE_ENUM dstDynTypeEn, srcDynTypeEn;

    /*  Security test                                                   */
    if ((pfctConvert == NULL) ||
        (ptrDest == NULL) ||
        (ptrSrc == NULL))
        return RET_GEN_ERR_INVARG;

    srcObjEn = GET_OBJ_DYNST(srcDynStEn);
    dstObjEn = GET_OBJ_DYNST(dstDynStEn);

    DBA_GetDictId(srcObjEn, &srcEntDictId);
    DBA_GetDictId(dstObjEn, &dstEntDictId);

    dstDynTypeEn = GET_DYNST_TYPE(dstDynStEn);
    srcDynTypeEn = GET_DYNST_TYPE(srcDynStEn);

    /* REF9764 - LJE - 040212 */
    DICT_GetMidEntityForConvert(dstObjEn, srcObjEn, &midObjEn);

    if (midObjEn != NullEntity)
    {
        DICT_ENTITY_STP midDictEntityStp = DBA_GetDictEntitySt(midObjEn);
        for (auto & midAttribStp : midDictEntityStp->attr)
        {
            DICT_GetConvertFieldIdx(dstObjEn,
                                    dstEntDictId,
                                    dstDynTypeEn,
                                    srcObjEn,
                                    srcEntDictId,
                                    srcDynTypeEn,
                                    midObjEn,
                                    midAttribStp,
                                    &srcAttrPos,
                                    &dstAttrPos);

            /*  Conversion                                              */
            if (srcAttrPos >= 0 && dstAttrPos >= 0)
                pfctConvert(ptrDest,dstAttrPos,ptrSrc,srcAttrPos,ptrData);
        }
    }
    else
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_SearchEntityBySqlName()
**
**  Description          : Return pointer on entity info depending on
**                         received sql name
**
**  Arguments            : name          name to compare
**                         dictEntStPtr  entity info pointer to fill
**
**  Return               : RET_SUCCEED or error code
*************************************************************************/
RET_CODE DBA_SearchEntityBySqlName(const char *name, DICT_ENTITY_STP *dictEntStPtr)
{
    DICT_ENTITY_STP searchDictEntStPtr = DBA_GetEntityBySqlName(name);

    if (searchDictEntStPtr)
    {
        (*dictEntStPtr) = searchDictEntStPtr;
        return RET_SUCCEED;
    }

    return RET_DBA_ERR_MD;
}

/************************************************************************
**  Function             : DBA_GetLinkedAttrib()
**
**  Description          : Get the linked attribute use for entity/object management
**
**  Arguments            : entityRef     entity object enum
**                         dictAttrStPtr attribute info pointer to fill
**
**  Return               : RET_SUCCEED or error code
*************************************************************************/
RET_CODE DBA_GetLinkedAttrib(OBJECT_ENUM      entityRef,
                             DICT_ATTRIB_STP *dictAttrStPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entityRef);

    if (dictEntityStp != nullptr)
    {
        DICT_T entityDictId;
        DBA_GetDictId(DictEntity, &entityDictId);

        for (auto it = dictEntityStp->attribMap.begin(); it != dictEntityStp->attribMap.end(); it++)
        {
            if (it->second->linkedAttrDictStp != NULL &&
                it->second->linkedAttrDictStp->refEntDictId == entityDictId)
            {
                *dictAttrStPtr = it->second->linkedAttrDictStp;
                return RET_SUCCEED;
            }
        }
    }

    return RET_DBA_INFO_NODATA;
}


/************************************************************************
**  Function             : DBA_SearchAttribSqlName()
**
**  Description          : Return pointer on attribute info depending on
**                         received sql name
**
**  Arguments            : entityRef     entity object enum
**                         name          name to compare
**                         dictAttrStPtr attribute info pointer to return
**
**  Return               : RET_SUCCEED or error code
*************************************************************************/
RET_CODE DBA_SearchAttribSqlName(OBJECT_ENUM      entityRef,
                                 const char      *name, /* DLA - REF8728 */
                                 DICT_ATTRIB_STP *dictAttrStPtr)
{

    DICT_ATTRIB_STP dictAttribStp = DBA_GetAttributeBySqlName(entityRef, name, FALSE);

    if (dictAttribStp)
    {
        *dictAttrStPtr = dictAttribStp;
        return RET_SUCCEED;
    }

    return RET_DBA_INFO_NODATA;
}

/************************************************************************
*   Function             : DBA_GetAttribFieldIdx()
*
*   Description          : Get attribute field index and entity depending
*                          on received criteria entity and field index
*
*   Arguments            : critEntityRef :  criteria entity object enum
*                          critIdx       :  criteria field index
*                          entRefPtr     :  pointer on attribute entity
*                          attrIdxPtr    :  pointer on attribute field index
*
*   Return               : RET_SUCCEED or error code
*
*   Modif                : Replace criterMap by shortDictCriteriaMap  HFI-PMSTA-32148-181012

*
*************************************************************************/
RET_CODE DBA_GetAttribFieldIdx(OBJECT_ENUM critEntityRef, int critProgN,
                   OBJECT_ENUM *entRefPtr, int *attrIdxPtr)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(critEntityRef);

    if (dictEntityStp != nullptr)
    {
        for (auto critIt = dictEntityStp->shortDictCriteriaMap.begin(); critIt != dictEntityStp->shortDictCriteriaMap.end(); critIt++)
        {
            DICT_CRITER_STP dictCritStp = critIt->second;
            if (dictCritStp->progN == critProgN)
            {
                /* Get attribute index */
                *attrIdxPtr = dictCritStp->attrPtr->progN;

                /* Get attribute entity object enum, criteria */
                /* can have attribute on another entity       */
                DICT_T entDictId = dictCritStp->attrPtr->entDictId;
                DBA_GetObjectEnum(entDictId, entRefPtr);

                return(RET_SUCCEED);
            }
        }
    }

    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                 "DBA_GetAttribFieldIdx", "critEntityRef");
    return(RET_GEN_ERR_INVARG);
}

/************************************************************************
*   Function             : DBA_GetDictPermValSt()
*
*   Description          : Get permitted value for an enum field (the enum
*                          value is "enumValue" argument)
*
*   Arguments            : entityRef  :  entity object enum
*                          field      :  field which have permitted values
*                          enumValue  :  permitted value number
*
*   Return               :
*
*************************************************************************/
DICT_PERM_VAL_STP DBA_GetDictPermValSt(OBJECT_ENUM entityRef, int field, int enumValue)
{
    if (field >= 0)
    {
        DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

        if (dictAttribStp != nullptr)
        {
            for (auto it = dictAttribStp->permValMap.begin(); it != dictAttribStp->permValMap.end(); it++)
            {
                if (it->second.permVal == enumValue)
                {
                    return &(it->second);
                }
            }
        }
    }
    return (nullptr);
}

/************************************************************************
*   Function             : DBA_GetDictPermValByName()
*
*   Description          : Get permitted value for an enum field (the enum
*                          value is "enumValue" argument)
*
*   Arguments            : entityRef  :  entity object enum
*                          field      :  field which have permitted values
*                          enumValue  :  permitted value number
*
*   Return               :
*
*************************************************************************/
DICT_PERM_VAL_STP DBA_GetDictPermValByName(OBJECT_ENUM entityRef, int field, const char* nameValue)
{
    if (nameValue != nullptr)
    {
        auto dictAttribStp = DBA_GetDictAttribSt(entityRef, field);
        if (dictAttribStp != nullptr)
        {
            for (auto& it : dictAttribStp->permValMap)
            {
                if (it.second.nameStr.compare(nameValue) == 0)
                {
                    return &(it.second);
                }
            }
        }
    }
    return (nullptr);
}

/************************************************************************
*   Function             : DBA_GetPermValPtr()
*
*   Description          : Get permitted value for an enum field (the enum
*                          value is "enumValue" argument)
*
*   Arguments            : entityRef  :  entity object enum
*                          field      :  field which have permitted values
*                          enumValue  :  permitted value number
*
*   Return               : TRUE if success,
*                          FALSE elsewhere.
*************************************************************************/
const char *DBA_GetPermValPtr(OBJECT_ENUM entityRef, int field, int enumValue)
{
    auto dictPermValStp = DBA_GetDictPermValSt(entityRef, field, enumValue);

    if (dictPermValStp != nullptr)
    {
        return dictPermValStp->labelStr.c_str();
    }

    return(SV_UnknownPermValue);
}

/************************************************************************
*   Function             : DBA_GetUniPermValPtr()
*
*   Description          : Get permitted value for an enum field (the enum
*                          value is "enumValue" argument)
*
*   Arguments            : entityRef  :  entity object enum
*                          field      :  field which have permitted values
*                          enumValue  :  permitted value number
*
*   Return               :
*
*   Last modif.          : PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
*
*************************************************************************/
const UChar *DBA_GetUniPermValPtr(OBJECT_ENUM entityRef, int field, int enumValue)
{
    DICT_PERM_VAL_STP dictPermValStp = DBA_GetDictPermValSt(entityRef, field, enumValue);

    if (dictPermValStp)
    {
        return dictPermValStp->uniLabelStr.getTerminatedBuffer();               /* PMSTA-34279 - 211218 - PMO */
    }

    return(SV_UnknownUniPermValue);
}

/************************************************************************
*   Function             : DBA_CheckPermVal()
*
*   Description          : Check permitted value for an enum field (the enum
*                          value is "enumValue" argument) / if no permitted value for the field return TRUE (no restriction)
*
*   Arguments            : entityRef  :  entity object enum
*                          field      :  field which have permitted values
*                          enumValue  :  permitted value number
*
*   Return               : TRUE if exists or no restriction
*                          FALSE elsewhere.
*************************************************************************/
FLAG_T DBA_CheckPermVal(OBJECT_ENUM entityRef, int field, int enumValue)
{
    DICT_PERM_VAL_STP dictPermValStp = DBA_GetDictPermValSt(entityRef, field, enumValue);

    if (dictPermValStp != nullptr)
    {
        return TRUE;
    }


    /* PMSTA-13109 - LJE - 111205 */
    if (entityRef == XdPermVal && enumValue < 256)
    {
        return TRUE;
    }

    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

    if (dictAttribStp && dictAttribStp->permValMap.size() == 0)
    {
        return TRUE;
    }

    /* PMSTA-11505 - LJE - 110707 - Send message in the log file */
    DICT_ENTITY_STP dictEntity=DBA_GetDictEntitySt(entityRef);
    if (dictEntity != NULL &&
        field < (int)dictEntity->attr.size())
    {
        MSG_SendMesg ( RET_GUI_ERR_INVALID_PERMVAL
                        , 0
                        , FILEINFO
                        , (ID_T)enumValue
                        , dictEntity->attr[field]->sqlName
                        , dictEntity->mdSqlName
                        );
    }
    return(FALSE);
}


/************************************************************************
*
*  Function          : DBA_GetPermValName
*
*  Description       :
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*                      permVal    : the permitted value string
*
*  Return            : a string
*
*  Creation date     :
*  Last modification :
*
*************************************************************************/
const char *DBA_GetPermValName(OBJECT_ENUM entityRef, int field, int enumValue)
{
    DICT_PERM_VAL_STP dictPermValStp = DBA_GetDictPermValSt(entityRef, field, enumValue);

    if (dictPermValStp != nullptr)
    {
        return dictPermValStp->nameStr.c_str();
    }

    return(SV_UnknownPermValue);
}

/************************************************************************
*
*  Function          : DBA_GetPermValEnum
*
*  Description       :
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*                      permVal    : the permitted value string
*
*  Return            : an enum member
*
*  Creation date     : 21.11.95 - PEC
*  Last modification :
*
*************************************************************************/
int DBA_GetPermValEnum(OBJECT_ENUM entityRef, int field, const char* permVal)
{
    auto dictPermValStp = DBA_GetDictPermValByName(entityRef, field, permVal);

    if (dictPermValStp != nullptr)
    {
        return dictPermValStp->permVal;
    }

    return(-1);
}

/************************************************************************
*
*  Function          : DBA_GetPermValNumber
*
*  Description       :
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*
*  Return            : number of permitted values
*
*  Creation date     : FIH - 980420 - REF1587
*
*************************************************************************/
int	DBA_GetPermValNumber(OBJECT_ENUM entityRef, int field)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

    if (dictAttribStp != nullptr)
    {
        return CAST_INT(dictAttribStp->permValMap.size());
    }

    return 0;
}

/************************************************************************
*
*  Function          : DBA_GetPermValMax()
*
*  Description       : Return the maximum permitted value for given field
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*
*  Return            : maximum permitted value, -1 in case of bad arguments
*
*  Creation date     : DVP166 - 961003 - DED
*  Last modification : REF068 - 980827 - RAK
*                      REF5561 - 010105 - SME
*
*************************************************************************/
int DBA_GetPermValMax(OBJECT_ENUM entityRef, int field)
{
    if ((entityRef == Op) && (field == A_Op_StatEn))
        return 255;

    return DBA_GetPermValNumber(entityRef, field);
}

/************************************************************************
*
*  Function          : DBA_GetPermValMaxLabelLen
*
*  Description       : Return the max permitted value label length for given field.
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*
*  Return            : maximum permitted value label length
*
*  Cr�ation	:	ROI - 961210 - DVP303
*
*************************************************************************/
short DBA_GetPermValMaxLabelLen(OBJECT_ENUM entityRef, int field)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

    if (dictAttribStp != nullptr)
    {
        short	 maxLen, len;

        maxLen = -1;
        for (auto it = dictAttribStp->permValMap.begin(); it != dictAttribStp->permValMap.end(); it++)
        {
            len = (short)it->second.labelStr.length();
            if (len > maxLen) maxLen = len;
        }

        return maxLen;
    }

    return -1;
}

/************************************************************************
*
*  Function          : DBA_GetUniPermValMaxLabelLen
*
*  Description       : Return the max permitted value label length for given field.
*
*  Arguments         : entityRef  : the entity object
*                      field      : the field number
*
*  Return            : maximum permitted value label length
*
*  Cr�ation	:	 REF9303 - LJE - 030912
*
*************************************************************************/
short DBA_GetUniPermValMaxLabelLen(OBJECT_ENUM entityRef, int field)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

    if (dictAttribStp != nullptr)
    {
        short	maxLen, len;

        maxLen = -1;
        for (auto it = dictAttribStp->permValMap.begin(); it != dictAttribStp->permValMap.end(); it++)
        {
            len = (short)it->second.uniLabelStr.length();
            if (len > maxLen) maxLen = len;
        }

        return maxLen;
    }

    return -1;
}

/************************************************************************
**  Function             : DBA_SetDfltEntityFld()
**
**  Description          : Read meta-dictionary for each dynamic structure
**                         field and update default value if exist.
**
**  Arguments            : objEn     entity identifier
**                         dynSt     dynamic structure definition enum
**                         stPtr     dynamic structure pointer
**
**  Return               : RET_SUCCEED
**
**  Last modification    : REF8844 - LJE - 031119
**
*************************************************************************/
RET_CODE DBA_SetDfltEntityFld(OBJECT_ENUM objEn, DBA_DYNST_ENUM dynSt, DBA_DYNFLD_STP stPtr)
{
    return(DBA_SetDfltEntityFld2(objEn, dynSt, stPtr, false));
}

/************************************************************************
**  Function             : DBA_SetDfltEntityFld()
**
**  Description          : Read meta-dictionary for each dynamic structure
**                         field and update default value if exist.
**
**  Arguments            : stPtr     dynamic structure pointer
**
**  Return               : RET_SUCCEED
**
**  Last modification    : PMSTA-46681 - LJE - 230309
**
*************************************************************************/
RET_CODE DBA_SetDfltEntityFld(DBA_DYNFLD_STP stPtr)
{
    if (stPtr != nullptr)
    {
        return(DBA_SetDfltEntityFld(stPtr->getObjectEn(), stPtr->getDynStEn(), stPtr));
    }
    return RET_DBA_ERR_INVDATA;
}

/************************************************************************
**  Function             : DBA_SetDfltEntityNotDbFld()
**
**  Description          : Read meta-dictionary for each dynamic structure
**                         field and update default value if exist.
**                         Do it only for fields not returned by database.
**
**  Arguments            : objEn     entity identifier
**                         dynSt     dynamic structure definition enum
**                         stPtr     dynamic structure pointer
**
**  Return               : RET_SUCCEED
**
**  Last modification    : PMSTA-42198 - DDV - 201028
**
*************************************************************************/
RET_CODE DBA_SetDfltEntityNotDbFld(OBJECT_ENUM objEn, DBA_DYNST_ENUM dynSt, DBA_DYNFLD_STP stPtr)
{
    return(DBA_SetDfltEntityFld2(objEn, dynSt, stPtr, true));
}

/************************************************************************
**  Function             : DBA_SetDfltEntityFld2()
**
**  Description          : Read meta-dictionary for each dynamic structure
**                         field and update default value if exist.
**
**  Arguments            : objEn     entity identifier
**                         dynSt     dynamic structure definition enum
**                         stPtr     dynamic structure pointer
**                         skipDbFld skip field returns from database
**
**  Return               : RET_SUCCEED
**
**  Last modification    :
**
*************************************************************************/
STATIC RET_CODE DBA_SetDfltEntityFld2(OBJECT_ENUM objEn, DBA_DYNST_ENUM dynSt, DBA_DYNFLD_STP stPtr, bool skipDbFld)
{
    int j;
    DICT_T fctDictId=NullDictFct;

    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);

    if (dictEntityStp != nullptr)
    {
        /* DLA  - PMSTA-29853 - 180129 */
        if (dictEntityStp->isMultiBusinessEntityManagement() &&
            dictEntityStp->ownerBusinessEntAttrStp != nullptr)
        {
            int idx = 0;
            if (dynSt == GET_EDITGUIST(objEn))
            {
                idx = dictEntityStp->ownerBusinessEntAttrStp->progN;
            }
            else if (dynSt == GET_ADMINGUIST(objEn) &&
                     dictEntityStp->ownerBusinessEntAttrStp->isNullShortIdx == false)
            {
                idx = dictEntityStp->ownerBusinessEntAttrStp->shortIdx;
            }
            else
            {
                idx = GET_FLD_NBR(dynSt);
            }

            if (idx < GET_FLD_NBR(dynSt) &&
                IS_NULLFLD(stPtr, idx) == TRUE)
            {
                SET_ID(stPtr, idx, SYS_GetThreadCurrBusinessEntityId());
            }
        }

        /* REF8844 - LJE - 031119 */
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dynSt == GET_EDITGUIST(objEn))
            {
                j = dictAttribStp->progN;
            }
            else if (dynSt == GET_ADMINGUIST(objEn) &&
                     dictAttribStp->isNullShortIdx == false)
            {
                j = dictAttribStp->shortIdx;
            }
            else
            {
                j = GET_FLD_NBR(dynSt);
            }

            if (j < GET_FLD_NBR(dynSt) && IS_NULLFLD(stPtr, j) == TRUE)
            {
                auto isSet = IS_SETFLD(stPtr, j);
                auto isGet = IS_GETFLD(stPtr, j);

                /* PMSTA-42198 - DDV - 201028 - If needed, skip db fields */
                if (skipDbFld && IS_DBFLD(dynSt, j) == TRUE)
                {
                    continue;
                }

                if (dictAttribStp->dfltVal.empty() == false)
                {
                    /* PMSTA-10070 - LJE - 100922 */
                    if (objEn == Domain && dynSt == A_Domain)
                    {
                        if (fctDictId == NullDictFct)
                            DBA_GetDictFctInfo((DICT_FCT_ENUM)(signed)GET_ID(stPtr, A_Domain_FctDictId),
                            DictFctInfo_ParDictId, &fctDictId);

                        if (j == A_Domain_DynWeightFlg &&
                            (fctDictId == DictFct_BenchStorage ||
                            fctDictId == DictFct_PerformanceAnalysis ||
                            fctDictId == DictFct_PtfStorage))
                        {
                            SET_FLAG_TRUE(stPtr, j);
                        }
                        else
                        {
                            DBA_StrToData(dictAttribStp->dfltVal.c_str(), stPtr, j);
                        }
                    }
                    else if (dictAttribStp->dataTpProgN != IdType &&
                             dictAttribStp->dataTpProgN != DictType &&
                             dictAttribStp->dfltVal[0] != '{') /* PMSTA-16296 - LJE - 130603 - To support code in the meta-dict default values */
                    {
                        DBA_StrToData(dictAttribStp->dfltVal.c_str(), stPtr, j);
                    }
                    else if (dictAttribStp->dfltVal[0] != '0' ||
                             dictAttribStp->dfltVal.size() > 1)
                    {
                        /* PMSTA-16296 - LJE - 130603 - To support code in the meta-dict default values */
                        const ID_T recordId = ATOLL(dictAttribStp->dfltVal.c_str());
                        if (recordId> 0)
                        {
                            SET_ID(stPtr, j, recordId); /* PMSTA-17490 - DDV - 140130 */
                        }
                    }
                }

                if (IS_FLAGFLD(dynSt, j) == TRUE)
                {
                    SET_NOTNULLFLG_T(stPtr, j);
                }

                if (isSet == FALSE)
                {
                    SET_SETFLG_F(stPtr, j);
                }
                if (isGet == FALSE)
                {
                    SET_GETFLG_F(stPtr, j);
                }
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_FillPermValTab()
*
*   Description          : Construct permitted values list for a field
*
*   Arguments            : entityRef  : entity object enum
*                          field      : field which have permitted values
*                          permValTab : pointer on array pointer to fill
*                          permValNb  : permitted value number
*                          langDictId :
*
*   Return               : RET_SUCCEED, RET_GEN_INFO_NODATA  or error code
*
*   Modif.               : MRA - 001123 - REF5435
*
*   Last modif.          : PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
*
*************************************************************************/
RET_CODE DBA_FillPermValTab(OBJECT_ENUM  entityRef,
                            int          field,
                            PTR          permValTab,
                            int          *permValNb,
                            DICT_T       langDictId)
{
    PERMITED_VALUES_STP *permValTabPtr = (PERMITED_VALUES_STP*)permValTab;
    DbiConnectionHelper dbiConnHelper;

    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entityRef, field);

    if (dictAttribStp != nullptr)
    {

        *permValNb = (int)dictAttribStp->permValMap.size();

        if (*permValNb != 0)
        {
            if (*permValTabPtr != nullptr)
            {
                delete [] *permValTabPtr;
            }
            *permValTabPtr = new PermitedValuesClass[*permValNb];
            if (*permValTabPtr == nullptr)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            int i = 0;
            for (auto it = dictAttribStp->permValMap.begin(); it != dictAttribStp->permValMap.end() && i < *permValNb; ++it, i++)
            {
                (*permValTabPtr)[i].value = it->second.permVal;
                (*permValTabPtr)[i].rank = it->second.rank;
                (*permValTabPtr)[i].permValRank = it->second.rank;
                (*permValTabPtr)[i].pdictPermVal = &(it->second);
                if (langDictId != EV_ServerLanguageID)      /*  see test done in DICT_GetLabel  */
                {
                    (*permValTabPtr)[i].dictidLang = langDictId;
                }
                else
                {
                    (*permValTabPtr)[i].dictidLang = 0;
                }
            }
       /* permittedDefIndex ?? */
            return(RET_SUCCEED);
        }
        else
        {
            *permValTabPtr = NULL;
            return(RET_GEN_INFO_NODATA);
        }
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                     "DBA_FillPermValTab", "entityRef");
        return(RET_GEN_ERR_INVARG);
    }
}

/************************************************************************
**
**  Function        : DBA_GetGuiMainEntFlag
**
**  Description     : Get GUI Main Entity Flag
**
**  Arguments       : OBJECT_ENUM   entityRef
**
**  Return          : FLAG_T        flagMainEnt
**
**  Modif           : FIH-REF74741-020705
**                    EFE REF10575 040831 : inconcistency in meta dict
**                                          with field dict_entity.maind_f
**
*************************************************************************/
FLAG_T  DBA_GetGuiMainEntFlag(OBJECT_ENUM entityRef)
{
    FLAG_T      flagMainEnt = FALSE;            /*  Main entity flag            */

    /*  Default setting from database                                   */
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entityRef);

    if (dictEntityStp != nullptr)
    {
        flagMainEnt = dictEntityStp->mainFlg;


        /*  Manage Exceptions   (code report from FMT_GetDictEntityInfo)    */
        /* REF8844 - LJE - 030415 */
        if (entityRef == Addr ||
            entityRef == AccPlanElt || /* REF1570 */
            entityRef == AccPer || /* REF1570 */
            entityRef == AccPerParam || /* REF1570 */
            entityRef == CalendarConv || /* DVP496 - 970819 - DED */
            entityRef == CalendarDate ||
            entityRef == DataProfCompo || /* MRA - 010213 - REF5562 */
            entityRef == DictAttr || /*  HFI-MIGR-020529 */
            entityRef == DictCriter || /*  HFI-MIGR-020529 */
            entityRef == DictPermVal || /*  HFI-MIGR-020529 */
            entityRef == FmtElt ||
            entityRef == FmtProfCompo ||
            entityRef == FTRateHist ||
            entityRef == FTRate ||
            entityRef == Guarantee ||
            entityRef == MktSegt ||
            entityRef == MktStruct || /*  HFI-MIGR-020529 */
            entityRef == MktSSubSet || /*  HFI-REF7420-020712  */
            entityRef == PtfPosSet ||
            entityRef == PtfThirdCompo || /*  HFI-MIGR-020529 */
            entityRef == ReportParam ||
            entityRef == StratCompo || /*  HFI-MIGR-020529 */
            entityRef == StratHist ||
            entityRef == StratElt ||
            entityRef == TemplateElt || /*  HFI-MIGR-020529 */
            entityRef == TradingPlace || /*REF7296-BRO-020304*/
            entityRef == TradingCurrency || /*REF7296-BRO-020304*/
            entityRef == ValRuleHist ||
            entityRef == ValRuleElt ||
            entityRef == ModelConstrElt ||
            entityRef == SubscriptionCodifCompo || /* DLA - REF8863 - 030307 */
            entityRef == ListCompo ||
            entityRef == PerfStorageParam || /*  FIH-REF9125-030827  */
            entityRef == SearchCritCompo || /*  FIH-REF9764-031224  */
            entityRef == SearchProfCompo || /*  FIH-REF9764-031224  */
            entityRef == QuickSearch || /* <REF10575-EFE-040831 */
            entityRef == One ||
            entityRef == Empty ||
            entityRef == EStratLnk ||
            entityRef == EStratElt ||
            entityRef == StratEltDetail ||
            entityRef == BalPosRule ||
            entityRef == AdminMgr ||
            entityRef == CommMgr ||
            entityRef == FundVal ||
            entityRef == FundValElt ||
            entityRef == PtfFreq ||
            entityRef == EvtExcl ||
            entityRef == InstrFlow ||
            entityRef == InstrFreq ||
            entityRef == DataDesc ||
            entityRef == DataDisp ||
            entityRef == Pos ||
            entityRef == BalPos ||
            entityRef == Op ||
            entityRef == PVal ||
            entityRef == Domain ||
            entityRef == RequestCode ||   /*  FIH-REF100604-040922    */
            entityRef == CorporateAction ||   /*  REF10603-EFE-041019 */
            entityRef == CorpActionDetail ||   /*  REF10603-EFE-041019 */
            entityRef == Doc ||   /* >REF10575-EFE-040831 */
            entityRef == InstrDeposit ||   /*REF11718-BRO-060301*/
            entityRef == OptiProfCompo ||   /* REF11767 - LJE - 060419 */
            entityRef == Communication ||	/*REF11810-BRO-060616*/
            entityRef == AccProfileCompo ||   /* PMSTA00488-EFE-061113*/
            entityRef == StandInstruct ||   /*PMSTA07952-BRO-090305*/
            entityRef == AttributeComment ||   /*  HFI-PMSTA-13537-120119  */
            entityRef == PermValComment ||   /*  HFI-PMSTA-13537-120119  */
            entityRef == CaseLink ||   /*PMSTA07952-BRO-090305*/
            entityRef == CaseMsgTemplateDef
            )
        {
            flagMainEnt = FALSE;
        }
        else if (entityRef == EventSched ||
                 entityRef == UnMatchedGlExecFee || /*  FPL-REF10136-040406 */
                 entityRef == Archive || /*  FIH-REF9557-031014  */
                 entityRef == ApplParam || /*  REF10575 EFE 040831 */
                 entityRef == ClientConnect || /*  REF10575 EFE 040831 */
                 entityRef == Log || /*  REF10575 EFE 040831 */
                 entityRef == ReportGen) /*  REF10575 EFE 040831 */
        {
            flagMainEnt = TRUE;
        }
        /* PMSTA-13109 - LJE - 111115 - If parent, not main! */
        else if (flagMainEnt == TRUE && dictEntityStp->isNullParIndex == false)
        {
            flagMainEnt = FALSE;
        }

        /* FPL-REF9776-031210 cleaning #ifdef REF8863 */
    }
    return flagMainEnt;
}


/************************************************************************
**
**  Function        :   DBA_GetGuiInterfaceFlag
**
**  Description     :   Get GUI Main Entity Flag
**
**  Arguments       :   OBJECT_ENUM   entityRef
**
**  Return          :   FLAG_T        flagMainEnt
**
**  Creation        :   FPL-REF6149-050530
**
*************************************************************************/
FLAG_T  DBA_GetGuiInterfaceFlag (OBJECT_ENUM entityRef)
{
    FLAG_T      flagInterface = FALSE;            /*  interface_e flag          */

    /*  Default setting from database                                   */
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entityRef);

    if (dictEntityStp != nullptr)
    {
        flagInterface = dictEntityStp->interf;

        if (SYS_IsGuiMode())
        {
            /*  Manage Exceptions       */
            if (entityRef == DictLang ||
                entityRef == Event ||
                entityRef == LoginHist ||
                entityRef == ServConnect)
            {
                flagInterface = TRUE;
            }
        }
    }

    return flagInterface ;
}


/************************************************************************
**
**  Function        : DBA_GetEntityMainMenuFlag
**
**  Description     : return if entity can be set as an icon on the toolsbar of the gui
**
**  Arguments       : OBJECT_ENUM   entityRef
**
**  Return          : FLAG_T
**
**  Creation        : FPL-REF8446-021114
**
*************************************************************************/
FLAG_T  DBA_GetEntityMainMenuFlag   (DICT_T ent)
{
    FLAG_T      bReturn;
    OBJECT_ENUM objectEn;

    DBA_GetObjectEnum(ent, &objectEn);
    /* initialisation */
    bReturn = FALSE ;

    /* REF8844 - LJE - 030415 */
    if (objectEn == ExecutionEnt ||
        objectEn == GlExecFeeEnt ||
        objectEn == Op ||
        objectEn == Curr ||
        objectEn == Geo ||
        objectEn == Sect ||
        objectEn == Rating ||
        objectEn == Tp ||
        objectEn == BalPos ||
        objectEn == Depo ||
        objectEn == Mgr ||
        objectEn == ValRule ||
        objectEn == PerfAnalysisParam ||
        objectEn == FTConv ||
        objectEn == Calendar ||
        objectEn == Ptf ||
        objectEn == Instr ||
        objectEn == Third ||
        objectEn == CurrChrono ||
        objectEn == ListChrono ||
        objectEn == ThirdChrono ||
        objectEn == PtfChrono ||
        objectEn == InstrChrono ||
        objectEn == CompInstrChrono ||
        objectEn == InstrPrice ||
        objectEn == ExchRate ||
        objectEn == UnMatchedExecution ||   /* FPL-REF10013-040316 */
        objectEn == UnMatchedGlExecFee ||   /* FPL-REF10136-040406 */
        objectEn == Folder ||           /* FPL-REF8755-030127 */
        objectEn == StratLnk ||         /* FPL-REF8755-030127 */
        objectEn == XdEntity ||         /* PMSTA-13109 - LJE - 111109 */
        objectEn == PackageInstallation ||
        objectEn == PackageDefinition)
    {
        bReturn = TRUE ;
    }
    else
    {
        bReturn = FALSE ;
    }

    return bReturn;
}

/************************************************************************
**  Function        : DBA_FillFunctionList
**
**  Description     : Return the list of authorized function and sub-function
**
**  Arguments       : DICT_FCT_ENUM     enParFct
**                    PTR               entStpPtr
**                    PTR               fctInfoTabPtr
**                    PTR               iNbFunctionPtr
**                    FUNCTIONLIST_ENUM enListType      : All, child or parent
**
**  Return          : RET_SUCCEED
**
**  Creation        : FIH - 000223 - REF4281
**  Modif.			: ROI - 000413 - REF4497
**  Modif.          : FPL-REF11288-060413   Add FLAG_T
**
*************************************************************************/
RET_CODE DBA_FillFunctionList   ( DICT_FCT_ENUM         enParFct
                                , PTR                   entStpPtr
                                , PTR                   fctInfoTabPtr
                                , PTR                   iNbFunctionPtr
                                , FUNCTIONLIST_ENUM     enListType
                                , FLAG_T                flagInFuncSecuProf      /*  FPL-REF11288-060413 */
                                )
{
    DICT_FCT_STP        fctStp,
                        *fctTab;
    int                 iNbFunction;
    ENTITIES_INFO_STP   entStp;
    DICT_T              dictParFct;

    /*  first test                      */
    if (((entStp = (ENTITIES_INFO_STP) entStpPtr) == NULL) &&
        ((fctInfoTabPtr == NULL) ||
         (iNbFunctionPtr == NULL)))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /*  Alloc permitted values table    */
    if ((fctTab = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(),sizeof(DICT_FCT_STP))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    iNbFunction = 0;

    /*  Alloc permitted values table    */
    for (size_t i = 0; i < EV_DictFctTab.size(); i++)
    {
        /*  Init loop variable  */
        fctStp = &(EV_DictFctTab[i]);

        /*  FPL-REF11288-060413 test security on the function if flag is true   */
        if (((flagInFuncSecuProf == TRUE) &&
             (fctStp->accesStatus == DictFctAuth_Ok)
            ) ||
            (flagInFuncSecuProf == FALSE))
        {
            if (enListType != FctList_GrandChild)
            {
                if ((dictParFct = fctStp->parFctDictId) >= DictFct_LastFromMetadictionary)	/* REF11686 - TEB - 060206 */
                {
                    size_t s = 0;
                    for (;(s < EV_DictFctTab.size()) && (EV_DictFctTab[s].dictId != fctStp->parFctDictId); s++);
                    if (s < EV_DictFctTab.size())
                        dictParFct = EV_DictFctTab[s].parFctDictId;
                }
            }
            else
                dictParFct = fctStp->parFctDictId;

            /*  Check fctEn  */
            if ((fctStp->dictId != DictFct_InitiateOrder) &&            /*  FIH-REF7323-020530      Particular case : generic function is never used    */
                (fctStp->dictId != DictFct_UpdateData) &&               /*  FIH-REF11457-051006     Particular case : generic function is never used    */
                (fctStp->dictId != DictFct_InitiateCompoundOrder) &&    /*  HFI-PMSTA-19105-141122  Particular case : generic function is never used    */
                ((((enListType == FctList_Child) ||
                   (enListType == FctList_GrandChild)) &&
                  (fctStp->parFctDictId >= DictFct_LastFromMetadictionary) &&		/* REF11686 - TEB - 060206 */
                  (dictParFct == enParFct)) ||
                 ((enListType == FctList_All) &&
                  ((fctStp->dictId == enParFct) ||
                   (dictParFct == enParFct))) ||
                 ((enListType == FctList_Parent) &&
                  (fctStp->parFctDictId < DictFct_LastFromMetadictionary) &&		/* REF11686 - TEB - 060206 */
                  ((fctStp->dictId == enParFct) ||
                   (dictParFct == enParFct)))))
            {
                int s = 0;
                for (;(s < iNbFunction) && (fctTab[s]->dictId != fctStp->dictId); s++);
                if (s == iNbFunction)
                {
                    fctTab[iNbFunction] = fctStp;
                    iNbFunction++;
                }
            }
        }
    }
    if (iNbFunction != 0)
    {
        if (entStpPtr != NULL)
        {
            entStp->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(iNbFunction,sizeof(VSH_ENTITY_INFO_ST));
            entStp->entityNb = iNbFunction;
            for (int i = 0; i < iNbFunction; i++)
            {
                entStp->entityTab[i].entityRef = (OBJECT_ENUM)(signed)fctTab[i]->dictId; /* REF7264 - LJE - 020205 */
                entStp->entityTab[i].id = fctTab[i]->dictId;
                strcpy(entStp->entityTab[i].sqlName, fctTab[i]->procName);	/* ROI - 000413 - REF4497 */
                strcpy(entStp->entityTab[i].label, fctTab[i]->label);
                u_strcpy(entStp->entityTab[i].uniLabel, fctTab[i]->uniLabel); /* REF9303 - LJE - 030912 */
            }
            FREE(fctTab);
        }
        else
        {
            fctTab = (DICT_FCT_STP*) REALLOC(fctTab,iNbFunction*sizeof(DICT_FCT_STP));
            *((DICT_FCT_STP **) fctInfoTabPtr) = fctTab;
            *((int *) iNbFunctionPtr) = iNbFunction;

            /*  Sort function menu by rank                  */  /*  HFI-PMSTA-37848-191112  */
            if (iNbFunction > 1)
                TLS_Sort((char *)(fctTab), iNbFunction, sizeof(DICT_FCT_STP), (TLS_CMPFCT *) DBA_CmpFunctionRank, NULL, SortRtnTp_None);
        }
    }
    else
    {
        FREE(fctTab);
        if (entStpPtr != NULL)
        {
            entStp->entityTab = NULL;
            entStp->entityNb = 0;
        }
        else
        {
            *((DICT_FCT_STP **) fctInfoTabPtr) = NULL;
            *((int *) iNbFunctionPtr) = 0;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**  Function        :   DBA_FillFunctionListAdminRight
**
**  Description     :   Return the list of authorised function and sub-function
**                      for adminstration right
**
**  Arguments       :
**
**  Return          :   RET_SUCCEED
**
**  Creation        :   FPL-REF11313-050801
**
*************************************************************************/
RET_CODE    DBA_FillFunctionListAdminRight ( PTR        entStpPtr)
{
    DICT_FCT_STP        fctStp ;
    DICT_FCT_STP        *fctTab ;
    int                 iNbFunction ;
    ENTITIES_INFO_STP   entStp ;

    if ((entStp = (ENTITIES_INFO_STP) entStpPtr) == NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /*  Alloc permitted values table    */
    if ((fctTab = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(),sizeof(DICT_FCT_STP))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    iNbFunction = 0;

    /*  Alloc permitted values table    */
    for (size_t i = 0; i < EV_DictFctTab.size(); i++)
    {
        fctStp = &(EV_DictFctTab[i]) ;
        if (((fctStp->finaFlag == TRUE) ||
             (fctStp->parFctDictId == DictFct_Admin)) &&    /*  FPL-PMSTA10714-101103   */
            (fctStp->entityDictId <= 0))                    /*  HFI-PMSTA-12110-110606  Function must appear only once  */
        {
            fctTab[iNbFunction] = fctStp;
            iNbFunction++;
        }
    }


    if (iNbFunction != 0)
    {
        if (entStp != NULL)
        {
            entStp->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(iNbFunction, sizeof(VSH_ENTITY_INFO_ST));
            entStp->entityNb = iNbFunction;
            for (int i = 0; i < iNbFunction; i++)
            {
                entStp->entityTab[i].entityRef = (OBJECT_ENUM)(signed)fctTab[i]->dictId;
                entStp->entityTab[i].id = fctTab[i]->dictId;
                strcpy(entStp->entityTab[i].sqlName, fctTab[i]->procName);
                strcpy(entStp->entityTab[i].label, fctTab[i]->label);
                u_strcpy(entStp->entityTab[i].uniLabel, fctTab[i]->uniLabel);
            }
            FREE(fctTab);

            /*  HFI-PMSTA-12110-110606  Sort function by Label  */
            TLS_Sort((char*) entStp->entityTab,
                     entStp->entityNb,
                     sizeof(VSH_ENTITY_INFO_ST),
                     (TLS_CMPFCT *) DBA_CmpEntList,
                     NULL,
                     SortRtnTp_None
                    );
        }
    }
    else
    {
        FREE(fctTab);
        if (entStp != NULL)
        {
            entStp->entityTab = NULL;
            entStp->entityNb = 0;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
*
*  Function          : DBA_GetDictFctRows
*
*  Description       :
*
*  Arguments         :
*
*
*  Return            :
*
*  Cr�ation	:	 PMSTA07964 - LJE - 090309
*
*************************************************************************/
int DBA_GetDictFctRows()
{
    return static_cast<int>(EV_DictFctTab.size());
}

/************************************************************************
**  Function             : DBA_GetDictFctStp
**
**  Description          : Get the entitySt
**
**  Arguments            :
**
**  Return               : PTR on fctSt
*************************************************************************/
DICT_FCT_STP DBA_GetDictFctStp(int fctIdx)
{
    if (fctIdx >= 0 && fctIdx < static_cast<int>(EV_DictFctTab.size()))
        return &(EV_DictFctTab[fctIdx]);
    else
        return(NULL);
}

/************************************************************************
**  Function             : DBA_GetDictDataTpStp
**
**  Description          : Get the entitySt
**
**  Arguments            :
**
**  Return               : PTR on fctSt
*************************************************************************/
DICT_DATATP_STP DBA_GetDictDataTpStp(int dataTpIdx)
{
    if (dataTpIdx >= 0 && dataTpIdx < static_cast<int>(SV_DictDataTpTab.size()))
        return &(SV_DictDataTpTab[dataTpIdx]);
    else
        return(NULL);
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctByProcName
**
**  Description :   Return function from procname
**
**  Arguments   :   char*       procName
**                  DICT_T*     fctDictIdPtr
**
**  Return      :   RET_CODE
**
**  Creation    :   FIH-REF4748-000511
**
*************************************************************************/
RET_CODE	DBA_GetDictFctByProcName (char *procName, DICT_T *fctDictIdPtr)
{
    /* Test given argument */
    if ((procName == NULL) ||
        (fctDictIdPtr == NULL))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /* PMSTA-nuodb - LJE - 190507 */
    std::vector<DICT_FCT_ST> *fctDictTab = nullptr;

    /* Check given fct */
    DBA_GetDictFctTab(fctDictTab);

    for (auto fctStp = fctDictTab->begin(); fctStp != fctDictTab->end(); ++fctStp)
    {
        if (strcmp(fctStp->procName, procName) == 0)
        {
            *fctDictIdPtr = fctStp->dictId;
            return RET_SUCCEED;
        }
    }
    *fctDictIdPtr = 0;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctStpByProcName
**
**  Description :   Return function structure from procname
**
**  Arguments   :   char*           procName
**                  DICT_FCT_STP*   pdictfct
**
**  Return      :   RET_CODE
**
**  Creation    :   FIH-PMSTA-16457-130617
**
*************************************************************************/
RET_CODE	DBA_GetDictFctStpByProcName (char *procName, DICT_FCT_STP *pdictfctptr)
{
    /* Test given argument */
    if ((procName == NULL) ||
        (pdictfctptr == NULL))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /* PMSTA-nuodb - LJE - 190507 */
    std::vector<DICT_FCT_ST> *fctDictTab = nullptr;

    /* Check given fct */
    DBA_GetDictFctTab(fctDictTab);

    for (auto fctIt = fctDictTab->begin(); fctIt != fctDictTab->end(); ++fctIt)
    {
        DICT_FCT_ST &fctSt = (*fctIt);

        if (strcmp(fctSt.procName, procName) == 0)
        {
            *pdictfctptr = &fctSt;
            return RET_SUCCEED;
        }
    }
    *pdictfctptr = nullptr;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctInfo
**
**  Description :   Return info on given function.
**
**  Arguments   :   DICT_FCT_ENUM fct, DICT_FCT_INFO_ENUM infoEn, PTR dataPtr
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   ROI - 960402 - DVP022
**  Modif.      :   ROI - 961111 - DVP245
**  Modif.      :   ROI - 961211 - DVP245
**  Modif.      :   FIH-REF7264-020314  Use DICT_T instead of DICT_FCT_ENUM
**
*************************************************************************/
RET_CODE	DBA_GetDictFctInfo (DICT_T dictidFct, short infoEn, PTR dataPtr)
{
    DICT_FCT_STP	fctStp;
    size_t			index;

    /* Test given argument */
    if (dataPtr == NULL)
      MSG_RETURN(RET_GEN_ERR_INVARG);

    /* Check given dictidFct */
    if (infoEn == DictFctInfo_StpByIdx)
      index = (short) dictidFct;
    else if ((dictidFct > DictFct_0) && (dictidFct <= LASTDICTFCT))
      index = (short)(dictidFct -1);
    else
    {
      index = LASTDICTFCT;
      while ((index < EV_DictFctTab.size()) &&
             (dictidFct != EV_DictFctTab[index].dictId)
            ) index++;
      if (index >= EV_DictFctTab.size())
        return(RET_GEN_ERR_INVARG); /*MSG_RETURN(RET_GEN_ERR_INVARG);*/
    }

    /* Init local variable */
    fctStp = &(EV_DictFctTab[index]);

    /* Manage info */
    switch(infoEn)
    {
      case DictFctInfo_DictId :
        *((DICT_T*) dataPtr) = fctStp->dictId;
        break;
      case DictFctInfo_Name :
        *((char**) dataPtr) = (char*) &(fctStp->name);
        break;
      case DictFctInfo_Label :
        *((char**) dataPtr) = (char*) &(fctStp->label);
        break;
      case DictFctInfo_UniLabel : /* REF9303 - LJE - 030912 */
        *((char**) dataPtr) = (char*) &(fctStp->uniLabel);
        break;
      case DictFctInfo_ProcName :
        *((char**) dataPtr) = (char*) &(fctStp->procName);
        break;
      case DictFctInfo_ParDictId :
        *((DICT_T*) dataPtr) = fctStp->parFctDictId;
        break;
      case DictFctInfo_Nature :
        *((ENUM_T*) dataPtr) = fctStp->natEn;
        break;
      case DictFctInfo_RefDictId :
        *((DICT_T*) dataPtr) = fctStp->refFctDictId;
        break;
      case DictFctInfo_HelpNode :
        *((char**) dataPtr) = (char*) &(fctStp->helpNode);
        break;
      case DictFctInfo_IconName :
        *((char**) dataPtr) = (char*) &(fctStp->iconName);
        break;
      case DictFctInfo_EntityDictId :
        *((DICT_T*) dataPtr) = fctStp->entityDictId;
        break;
      case DictFctInfo_MinOpStatus :
        *((ENUM_T*) dataPtr) = fctStp->minOpStatus;
        break;
      case DictFctInfo_MaxOpStatus :
        *((ENUM_T*) dataPtr) = fctStp->maxOpStatus;
        break;
      case DictFctInfo_SecurityLevel :
        *((ENUM_T*) dataPtr) = fctStp->securityLevel;
        break;
      case DictFctInfo_CreateFlag :
        *((FLAG_T*) dataPtr) = fctStp->createFlag;
        break;
      case DictFctInfo_UpdateFlag :
        *((FLAG_T*) dataPtr) = fctStp->updateFlag;
        break;
      case DictFctInfo_DeleteFlag :
        *((FLAG_T*) dataPtr) = fctStp->deleteFlag;
        break;
      case DictFctInfo_RiskViewFlag :
        *((FLAG_T*) dataPtr) = fctStp->riskViewFlag;
        break;
      case DictFctInfo_RealTimeFlag :
        *((FLAG_T*) dataPtr) = fctStp->realTimeFlag;
        break;
      case DictFctInfo_Stp :
      case DictFctInfo_StpByIdx :
        *((DICT_FCT_STP*) dataPtr) = fctStp;
        break;
      case DictFctInfo_AccesStatus :
        *((DICT_FCTAUTH_ENUM*) dataPtr) = fctStp->accesStatus;
        break;
      case DictFctInfo_FinaFlag :
        *((FLAG_T*) dataPtr) = fctStp->finaFlag;
        break;
      case DictFctInfo_DomEnum :
        *((DICT_FCTDOM_ENUM*) dataPtr) = fctStp->domEn;
        break;
      case DictFctInfo_FmtFlag :
        *((FLAG_T*) dataPtr) = fctStp->fmtFlag;
        break;
      case DictFctInfo_DocFlag :
        *((FLAG_T*) dataPtr) = fctStp->docFlag;
        break;
      case DictFctInfo_FinFlag :
        *((FLAG_T*) dataPtr) = fctStp->finFlag;
        break;
      case DictFctInfo_FmtTabIdx :
        *((SMALLINT_T*) dataPtr) = fctStp->fmtTabIdx;
        break;
      case DictFctInfo_DocTabIdx :
        *((SMALLINT_T*) dataPtr) = fctStp->docTabIdx;
        break;
      case DictFctInfo_FinTabIdx :
        *((SMALLINT_T*) dataPtr) = fctStp->finTabIdx;
        break;
      default :
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_CheckNumberOfDictFct
**
**  Description :   Check current given operation status authorization.
**
**  Argument    :   DICT_FCT_ENUM   dictFctEn   : Function  id
**		            DICT_T          entDictId   : Entity id
**		            DICT_T          typeId,     : Type id
**		            DICT_T          subtypeId   : SubType id
**		            short*          psCounter   : Pointer to number of authorised id
**                  DICT_T**        psDictIdTab : Table of authorised type id
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980616 - REF1504
**  Modif       :   FPL-PMSTA08801-091008 longID typeId, subTypeId, psDictIdTab from DICT_T
**
*************************************************************************/
RET_CODE DBA_CheckNumberOfDictFct (DICT_T dictFctEn, DICT_T entDictId, OBJECT_ENUM checkRef, ID_T typeId, ID_T subtypeId, short *psCounter, ID_T **psDictIdTab)
{
    short               s;
    DICT_FCT_STP        fctStp  = NULL;
    ID_T                *dictTab = NULL;                /*  FPL-PMSTA08801-091008 longID from DICT_T    */
    DICT_T              opDictId;                       /*  FIH-REF5168-000822  */

    /*  Security test   */
    if (psCounter == NULL)
        return RET_GEN_ERR_INVARG;

    /*  Init variables  */
    *psCounter = 0;
    DBA_GetDictId(Op, &opDictId);

    /*  Find fct functions line    */
    for (size_t i = 0; i < EV_DictFctTab.size(); i++)
    {
        fctStp = &(EV_DictFctTab[i]);
        if ((fctStp->dictId == dictFctEn) &&
            ((fctStp->entityDictId == entDictId) ||
             ((checkRef == NullEntity) &&               /*  FIH-REF5512-001211  */
              (fctStp->entityDictId == opDictId))))     /*  FIH-REF5168-000822  */
        {
            if (typeId == 0)
                (*psCounter)++;
            else if (fctStp->dictId != 0)
            {
                if (typeId == -1)
                {
                    if (dictTab == NULL)
                    {
                        if ((dictTab = (ID_T*) CALLOC(EV_DictFctTab.size(), sizeof(ID_T))) == NULL)   /*  FPL-PMSTA08801-091008 longID from DICT_T    */
                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    for (s = 0; (s < *psCounter) && (dictTab[s] != fctStp->typeId); s++);
                    if (s >= *psCounter)
                    {
                        dictTab[*psCounter] = fctStp->typeId;
                        (*psCounter)++;
                    }
                }
                else if ((typeId == fctStp->typeId) &&
                         (fctStp->subtypeId != 0))
                {
                    if (dictTab == NULL)
                    {
                        if ((dictTab = (ID_T*) CALLOC(EV_DictFctTab.size(), sizeof(ID_T))) == NULL)
                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    for (s = 0; (s < *psCounter) && (dictTab[s] != fctStp->subtypeId); s++);
                    if (s >= *psCounter)
                    {
                        dictTab[*psCounter] = fctStp->subtypeId;
                        (*psCounter)++;
                    }
                }
            }
        }
    }
    *psDictIdTab = dictTab;
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DICT_TestDynfld
**
**  Description :   Test and trace bad access for GET and SET access to DBA_DYNFLD_STP
**
**  Argument    :   DBA_DYNFLD_STP dynStp, int fldIdx
**
**  Return      :   none
**
**  Creation	:   REF8844 - LJE - 030828
**  Modif       :   PMSTA-14596 - 050712 - PMO : Triple'a Server crash - core dump
**  Modif       :   HFI-PMSTA-52805-2023-04-14 : Wrong message displayed in case of short structure
**
*************************************************************************/
void    DICT_TestDynfld(DBA_DYNFLD_STP dynStp, int fldIdx, unsigned char accessDataType)
{
    char	    buffer[512];
    DICT_T	    dictId = 0;
    OBJECT_ENUM object=NullEntity;
    int			fldNbr = 0;
    DBA_DYNST_ENUM dynStEnum = dynStp[0].dynStEnum;

    if (dynStEnum > InvalidDynSt) /* PMSTA-20235 - CHU - 150521 */  /* PMSTA-37366 - LJE - 200120 */
    {
         fldNbr = GET_FLD_NBR(dynStEnum);     /* PMSTA-14596 - 050712 - PMO */
    }

    /* PMSTA-14596 - 050712 - PMO */
    if (SYS_IsGuiMode() == FALSE && (fldNbr > 0 && (fldIdx < 0 || fldIdx >= fldNbr))) /* PMSTA-23385 - LJE - 160715 - On some cases in GUI, it's correct... */
    { /* Error, out of bounds */
        object = (OBJECT_ENUM) GET_OBJ_DYNST(dynStEnum);

        (void)DBA_GetDictId(object, &dictId);
        if (NullEntity != object)
        {
            const char *entSqlName = DBA_GetDictEntitySqlName(object);
            snprintf(buffer,
                    sizeof(buffer),
                    "Out of bounds DYNFLD Access (%s,dictId:%" szFormatId",[%d] for [0..%d])",
                    entSqlName,
                    dictId,
                    fldIdx,
                    fldNbr
                    );

            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
            SYS_BreakOnDebug();

            /* No more checks since we are out of bound */
            return;
        }
    }

    /*              +---------------------+
    |\/\/\/|        | Fix this Bug Please |
    |      |        +---------------------+
    |      |       /
    | (o)(o)      /
    o      _)    /
    | ,_ _|   </
    |    /
    /____\
    /      \
    */

    /* REF9125 - LJE - 030818 */
    if (AaaMetaDict::getDictEntitySize() > 0 &&
        (dynStEnum > NullDynSt) &&
        (dynStEnum < LASTDYNST) &&
        (dynStp[fldIdx].index >= 0) &&
        (dynStp[fldIdx].index < fldNbr) &&
        (dynStp[fldIdx].dataType != NullDataType) &&
        (dynStp[fldIdx].dataType != accessDataType) &&
        /* Test non init dynst */
        (dynStEnum != InvalidDynSt)
       )
    {
        if (GET_CTYPE(dynStp[fldIdx].dataType) != GET_CTYPE(accessDataType))
        {
            object = (OBJECT_ENUM) GET_OBJ_DYNST(dynStEnum); /* REF9303 - LJE - 030904 */
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);
            if (dictEntityStp != nullptr)
            {
                const char  *attrSqlName = " ";
                DBA_GetDictId(object, &dictId);
                if (dynStEnum == GET_EDITGUIST(object))
                {
                    attrSqlName = DBA_GetDictAttribSqlName(object, dynStp[fldIdx].index);
                }
                else
                {
                    DICT_CRITER_STP  dictCriteriaStp = dictEntityStp->getDictCriteria(DynType_Short, dynStp[fldIdx].index);
                    if (dictCriteriaStp != nullptr)
                    {
                        attrSqlName = dictCriteriaStp->sqlName;
                    }
                    else
                    {
                        DBA_CFIELDDEF_STP cFieldPtr = DBA_GetCFieldDef(dynStEnum, dynStp[fldIdx].index, NULL);
                        if (cFieldPtr != nullptr)
                        {
                            attrSqlName = cFieldPtr->sqlName;
                        }
                    }
                }
                sprintf(buffer,
                        "Wrong DYNFLD Access (%s,%s,%" szFormatId",%d) -> def datatype %s / access %s ", /* DLA - PMSTA08801 - 100209 */
                        dictEntityStp->mdSqlName,
                        attrSqlName,
                        dictId,
                        dynStp[fldIdx].index,
                        DBA_GetDataTypeSQLNameC((DATATYPE_ENUM)dynStp[fldIdx].dataType),
                        DBA_GetDataTypeSQLNameC((DATATYPE_ENUM)accessDataType));

                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                SYS_BreakOnDebug();
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DICT_TestDynSt
**
**  Description :   Test and trace bad access for ALLOC_DYNST to DBA_DYNFLD_STP
**
**  Argument    :   DBA_DYNFLD_STP dynStp, int fldIdx
**
**  Return      :   none
**
**  Cr�ation	:   REF8712 - LJE - 031017
**
*************************************************************************/
void    DICT_TestDynSt(DBA_DYNFLD_STP dynStp, DBA_DYNST_ENUM dynStEn)
{
    /* REF9125 - LJE - 030818 */
    if (AaaMetaDict::getDictEntitySize() > 0 &&
        (dynStp != NULL) &&
        (dynStp[0].dynStEnum > NullEntity) &&
        (dynStp[0].dynStEnum != dynStEn) &&
        (dynStp[0].dynStEnum < LASTDYNST) &&
        /* Test non init dynst */
        (dynStp[0].dynStEnum != InvalidDynSt) &&
        (EV_DynStPtr[dynStp[0].dynStEnum].newVerDynStEn != dynStEn))
    {
        const char *entSqlName;
        char	    buffer[512];
        DICT_T	    dictId = 0;
        OBJECT_ENUM object = NullEntity;

        object = (OBJECT_ENUM)GET_OBJ_DYNST(dynStp[0].dynStEnum);

        DBA_GetDictId(object, &dictId);
        entSqlName = DBA_GetDictEntitySqlName(object);
        sprintf(buffer,
                "Wrong DYNFLD Access (%s) -> dynamic struct %s / access %s ",
                entSqlName,
                DYN_V2N(dynStp[0].dynStEnum),
                DYN_V2N(dynStEn));

        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
        SYS_BreakOnDebug();
    }
}

/************************************************************************
**
**  Function    :   DICT_GetDynfld
**
**  Description :   Set getFlg and GET field value
**
**  Argument    :   DBA_DYNFLD_STP dynStp, int fldIdx
**
**  Return      :   none
**
**  Cr�ation	:   PMSTA13244 - DDV - 120120 - Trace DynFld usage
**
**  Last modif. :
**
*************************************************************************/
void * DICT_GetDynfld(DBA_DYNFLD_STP dynStp, int fldIdx, unsigned char accessDataType, FLAG_T noImpactFlg)
{

#ifdef AAATRACEDYNFLD
    DICT_TestDynfld(dynStp, fldIdx, accessDataType);
#endif

    if (noImpactFlg == FALSE)
        SET_GETFLG_T(dynStp, fldIdx);

    switch (GET_CTYPE(accessDataType))
    {
    case DoubleCType:
        return &(dynStp[fldIdx].data.dbleValue);

    case CharPtrCType:
        return &(dynStp[fldIdx].data.strData.ptr);

    case IntCType:
        return &(dynStp[fldIdx].data.intValue);

    case UIntCType:
        return &(dynStp[fldIdx].data.uintValue);

    case ShortCType:
        return &(dynStp[fldIdx].data.shortValue);

    case UCharCType:
        return &(dynStp[fldIdx].data.ucharValue);

    case UShortCType:
        return &(dynStp[fldIdx].data.ushortValue);

    case DateTimeStCType:
        return &(dynStp[fldIdx].data.datetime64St);

    case ExtPtrCType:
        return &(dynStp[fldIdx].data.extPtr);

    case ArrayPtrCType:
        return &(dynStp[fldIdx].data.arrayPtr);

    case MultiArrayPtrCType:
        return &(dynStp[fldIdx].data.multiArrayDataPtr);

    case TextPtrCType:
        return &(dynStp[fldIdx].data.strData.ptr);

    case PtrCType:
        return &(dynStp[fldIdx].data.ptr);

    case UniCharPtrCType:
        return &(dynStp[fldIdx].data.ustrData.ptr);

    case UniTextPtrCType:
        return &(dynStp[fldIdx].data.ustrData.ptr);

    case LongLongCType:  /* PMSTA08801 - DDV - 091126 */
        return &(dynStp[fldIdx].data.longlongValue); /* PMSTA08801 - DDV - 091126 */

    case TimeStampCType: /* REF11780 - 100406 - PMO */
        return &(dynStp[fldIdx].data.timeStampValue);

    default :
        return &(dynStp[fldIdx].data.intValue);
    }

}
/************************************************************************
**
**  Function    :   DICT_IsNullFld
**
**  Description :   Get NULL Fld value
**
**  Argument    :   DBA_DYNFLD_STP dynStp, int fldIdx
**
**  Return      :   none
**
**  Cr�ation	:   PMSTA13244 - DDV - 120120 - Trace DynFld usage
**
**  Last modif. :   PMSTA17155-CHU-131108 : test validity of dynStp pointer
**
*************************************************************************/
bool DICT_IsNullFld(DBA_DYNFLD_STP dynStp, int fldIdx)
{
    if (dynStp != NULLDYNST) /* PMSTA17155-CHU-131108 */
    {
#ifdef AAATRACEDYNFLD
        if (GET_DYNSTENUM(dynStp) != NullDynSt &&
            GET_DYNSTENUM(dynStp) != InvalidDynSt &&
            GET_DYNSTENUM(dynStp) != DataDef &&
            GET_FLD_NBR(GET_DYNSTENUM(dynStp)) <= fldIdx)
        {
            SYS_BreakOnDebug();
        }
#endif
        SET_GETFLG_T(dynStp, fldIdx);
        return(_IS_NULLFLD(dynStp,fldIdx));
    }

    SYS_BreakOnDebug(); /* PMSTA17155-CHU-131108 */
    return(true);		/* PMSTA17155-CHU-131108 */
}


/************************************************************************
**
**  Function    :   DICT_GetAttribInfo
**
**  Description :   Get information on attribute.
**
**  Argument    :   OBJECT_ENUM entity,		May be NullEntity
**		    short fldIdx,		May be -1 (No index)
**		    DICT_T attrDictId,		May be 0 or -1 (No dictId)
**		    char* sqlName,		May be null (No sqlName)
**		    short infoEnum,		A_DictAttr ...
**		    PTR data			Returned value.
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 970213 - DVP345
**  Modif.	:   ROI - 970505 - DVP345
**	Modif.	:	MRA - 000119 - REF4115
**          :   PMSTA-26108 - LJE - 170930 - Rewriting
**
*************************************************************************/
RET_CODE	DICT_GetAttribInfo(OBJECT_ENUM entity,
                               FIELD_IDX_T fldIdx,
                               DICT_T      attrDictId,
                               const char* sqlName,     /* REF8728 - YST - 030213 */
                               FIELD_IDX_T infoEnum,
                               PTR         data)
{
    DICT_ATTRIB_STP attribStp = nullptr;

    /* Test given variables */
    if ((infoEnum < 0) || (infoEnum > GET_FIX_NBR(A_DictAttr)))
        return RET_GEN_ERR_INVARG;

    if (attrDictId > 0)
    {
        attribStp = DBA_GetAttributeById(attrDictId);

        /* PMSTA-30728 - LJE - 180424 */
        if (attribStp != nullptr &&
            entity > 0 &&
            (attribStp->dictEntityStp == nullptr || entity != attribStp->dictEntityStp->objectEn))
        {
            attribStp = nullptr;
        }
    }
    else if (entity != NullEntity)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);
        if (dictEntityStp)
        {
            if (fldIdx != -1)
            {
                attribStp = dictEntityStp->getDictAttribByIdx(fldIdx);
            }
            else if (sqlName && sqlName[0])
            {
                attribStp = dictEntityStp->getDictAttribBySqlName(sqlName);
            }
        }
    }

    /* Returned data */
    if (attribStp)
    {
        if (data)
        {
            if (infoEnum == GET_FIX_NBR(A_DictAttr)) /* REF8844 - LJE - 030403 */
            {
                *((DICT_ATTRIB_STP*)data) = attribStp;
            }
            else
            {
                /* REF8844 - LJE - 030410 : switch -> if */
                if (infoEnum == A_DictAttr_DictId)
                {
                    *((DICT_T*)data) = attribStp->attrDictId;
                }
                else if (infoEnum == A_DictAttr_Name)
                {
                    strcpy(*((NAME_T*)data), attribStp->name);
                }
                else if (infoEnum == A_DictAttr_EntityDictId)
                {
                    *((DICT_T*)data) = attribStp->entDictId;
                }
                else if (infoEnum == A_DictAttr_DataTpDictId)
                {
                    *((DATATYPE_ENUM*)data) = attribStp->dataTpProgN;
                }
                else if (infoEnum == A_DictAttr_RefEntityDictId)
                {
                    *((DICT_T*)data) = attribStp->refEntDictId;
                }
                else if (infoEnum == A_DictAttr_SqlName)
                {
                    strcpy(*((SYSNAME_T*)data), attribStp->sqlName);
                }
                else if (infoEnum == A_DictAttr_Prog)
                {
                    *((INT_T*)data) = attribStp->progN; /* REF8844 - LJE - 030327 */
                }
                else if (infoEnum == A_DictAttr_ProgPk)
                {
                    *((SMALLINT_T*)data) = attribStp->progPkN;
                }
                else if (infoEnum == A_DictAttr_DispRank)
                {
                    *((SMALLINT_T*)data) = attribStp->dispRank;
                }
                else if (infoEnum == A_DictAttr_PrimaryFlg)
                {
                    *((FLAG_T*)data) = attribStp->primFlg;
                }
                else if (infoEnum == A_DictAttr_MandatoryFlg)
                {
                    *((FLAG_T*)data) = attribStp->mandatoryFlg;
                }
                else if (infoEnum == A_DictAttr_DbMandatoryFlg)
                {
                    *((FLAG_T*)data) = attribStp->dbMandatoryFlg;
                }
                else if (infoEnum == A_DictAttr_Default)
                {
                    strcpy(*((NAME_T*)data), attribStp->dfltVal.c_str());
                }
                else if (infoEnum == A_DictAttr_BusKeyFlg)
                {
                    *((FLAG_T*)data) = attribStp->busKeyFlg;
                }
                else if (infoEnum == A_DictAttr_LogicalFlg)
                {
                    *((FLAG_T*)data) = attribStp->logicalFlg;
                }
                else if (infoEnum == A_DictAttr_CustomFlg)
                {
                    *((FLAG_T*)data) = attribStp->custFlg;
                }
                else if (infoEnum == A_DictAttr_CalcEn)
                {
                    *((DICTATTR_ENUM*)data) = attribStp->calcEn;
                }
                else if (infoEnum == A_DictAttr_PermAuthFlg)
                {
                    *((DBA_PERMAUTH_ENUM*)data) = attribStp->permAuthEn;
                }
                else if (infoEnum == A_DictAttr_EditEn)
                {
                    *((DICTATTRIBEDIT_ENUM*)data) = attribStp->editionEn;
                }
                else if (infoEnum == A_DictAttr_QuickSearchMask)
                {
                    *((MASK_T*)data) = attribStp->qSearchMask;
                }
                else if (infoEnum == A_DictAttr_SearchMask)
                {
                    *((MASK_T*)data) = attribStp->searchMask;
                }
                else if (infoEnum == A_DictAttr_ShortIdx)
                {
                    *((SMALLINT_T*)data) = (SMALLINT_T)attribStp->shortIdx;
                }
                else if (infoEnum == A_DictAttr_WidgetEn)
                {
                    *((DICTATTRIBWGT_ENUM*)data) = attribStp->widgetEn;
                }
                else if (infoEnum == A_DictAttr_MaxDbLen)          /*  FPL-PMSTA09887-101223   */
                {
                    *((SMALLINT_T*)data) = (SMALLINT_T)attribStp->maxDbLenN;
                }
                else if (infoEnum == A_DictAttr_DefaultDispLen) /*  FPL-PMSTA09887-101223   */
                {
                    *((SMALLINT_T*)data) = (SMALLINT_T)attribStp->defaultDisplayLenN;
                }
            }
        }
    }
    else
        return RET_DBA_INFO_NODATA;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DICT_EntityNatCommonFields()
**
**  Description :   Fill a flags array for received entity.
**                  Field flag is TRUE if the field is present for the two received nature.
**
**  Argument    :   entityRef   entity reference
**		    nature1	first nature
**		    nature2	second nature
**                  flagTabPtr  pointer on flags array (allocated and filled)
**
**  Return      :   RET_CODE
**
**  Creation	:   RAK - 971031 - REF112
**
*************************************************************************/
RET_CODE DICT_EntityNatCommonFields(OBJECT_ENUM    entityRef,
                    ENUM_T         nature1,
                    ENUM_T         nature2,
                    FLAG_T         **flagTabPtr)
{
    DICT_ENTITY_STP     dictEntityStp = DBA_GetDictEntitySt(entityRef);
    if (dictEntityStp)
    {
        int fldNbr = (int)dictEntityStp->attr.size();

        if (flagTabPtr == NULL)
            MSG_RETURN(RET_GEN_ERR_INVARG);

        *flagTabPtr = NULL;

        if (((*flagTabPtr) = (FLAG_T*)CALLOC(fldNbr, sizeof(FLAG_T))) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp != nullptr)
            {
                int fld = dictAttribStp->progN;

                if (CHECK_BITMASK(dictAttribStp->subTypeMask, nature1) == TRUE &&
                    CHECK_BITMASK(dictAttribStp->subTypeMask, nature2) == TRUE)
                    (*flagTabPtr)[fld] = TRUE;
                else
                    (*flagTabPtr)[fld] = FALSE;
            }
        }
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ConvertAllDynstToShort
**
**  Description :   Convert a A_xxx to S_xxx
**
**  Arguments   :   OBJECT_ENUM entity, DBA_DYNFLD_STP all, DBA_DYNFLD_STP *sh
**
**  Return      :   RET_CODE
**
**  Creation	:   DRI - 991202 - REF4011
**  Modif.		:   GRD - 000321 - REF4204.
**                  REF9743 - LJE - 040202
**
*************************************************************************/
RET_CODE	DBA_ConvertAllDynstToShort(OBJECT_ENUM entity, DBA_DYNFLD_STP all, DBA_DYNFLD_STP *sh)
{
    DICT_ENTITY_STP dictEntityStp;
    DBA_DYNST_ENUM	shortStr = A_AccPer /* 0 */;

    /* Test for security */
    if ((all == NULL) ||
        (entity == NullEntity)
       )
       return RET_GEN_ERR_INVARG;

    shortStr = GET_ADMINGUIST(entity);
    *sh = ALLOC_DYNST(shortStr);
    dictEntityStp = DBA_GetDictEntitySt(entity);

    /* Copy necessary DynFld */
    for (auto& dictAttribStp : dictEntityStp->attr)
    {
        if (dictAttribStp->shortIdx >= 0 &&
            dictAttribStp->isNullShortIdx == false)
        {
             COPY_DYNFLD(*sh, shortStr,
                         dictAttribStp->shortIdx,
                         all, GET_EDITGUIST(entity),
                         dictAttribStp->progN);
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_GetObjectEnumBySqlName
**
** Description : search object enum by sql name
**
**
** Arguments   : sqlName: name to search
**               object: var for stock the result
**
** Return      :  void
**
** Creation    : sme (Friday February 18 2000)
**
************************************************************************/
void DBA_GetObjectEnumBySqlName(const char *sqlName, OBJECT_ENUM *object)
{
    if ((sqlName != NULL) && (object != NULL))
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(sqlName);

        if (dictEntityStp)
        {
            *object = dictEntityStp->objectEn;
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctTab
**
**  Description :   return a dict fct array
**
**  Arguments   :   pfctTab         :   dict fct
**                  piNbRows        :   number of rows
**                  bIsAllocated    :   if TRUE, you need to do a FREE of
**                                      pfctTab
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   FPL-REF11314-060512
**  Modif       :   FIH-REF11314-060718     Simple use of DBA_GetUserInfo2
**
*************************************************************************/
RET_CODE    DBA_GetDictFctTab(std::vector<DICT_FCT_ST> *&fctTab)
{
    ID_T                    idApplUser ;
    RET_CODE                retCode ;

    /*  if server mode with a filled user, get dictFct with user_id */
    if ((SYS_IsSrvMode() == TRUE) &&
        (DBA_GetUserInfo2(A_ApplUser_Id, &idApplUser, TRUE) == RET_SUCCEED))
    {
        retCode = DBA_GetDictFctTabByUserId(idApplUser, fctTab);
        if (retCode == RET_SUCCEED)
        {
            if (true == EV_LogFSPSecuCheck)
            {
                if (fctTab->size() > 0)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) DBA_GetDictFctTabByUserId() successfully retrieved %1 functions in FSP %2 for user_id = %3", IntType, static_cast<int>(fctTab->size()), IdType, (*fctTab)[0].funcSecuProfId, IdType, idApplUser); /* PMSTA-32214 - CHU - 180726  */
                }
                else
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) DBA_GetDictFctTabByUserId() 'successfully' retrieved 0 functions for user_id = %1", IdType, idApplUser); /* PMSTA-32214 - CHU - 180726  */
                }
            }
        }
        /*  FPL-REF11314-060608  copied from function DBA_UpdFctTab */
        int iCpt = 0;
        for (auto fctStp = fctTab->begin(); fctStp != fctTab->end(); ++fctStp)
        {
#ifdef PMSTA35838               /*  This infomation is now returned by the procedure    */
            /*  Update accesStatus */
            if ((fctStp->funcSecuProfId > 0) &&
                (fctStp->viewFlag == TRUE) &&
                (fctStp->visibleFlag == TRUE))
            {
                fctStp->accesStatus = DictFctAuth_Ok;
            }
#endif
            if (true == EV_LogFSPSecuCheck)
            {
                switch (fctStp->accesStatus)
                {
                case DictFctAuth_None:
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) (FSP id=%1) retrieved accessStatus to 'DictFctAuth_None' for function %2 at row %3", IdType, fctStp->funcSecuProfId, SysnameType, fctStp->procName, IntType, iCpt); /* PMSTA-32214 - CHU - 180726  */
                    break;
                case DictFctAuth_Master:
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) (FSP id=%1) retrieved accessStatus to 'DictFctAuth_Master' for function %2 at row %3", IdType, fctStp->funcSecuProfId, SysnameType, fctStp->procName, IntType, iCpt); /*  HFI-PMSTA-41458-200814  */
                    break;
                case DictFctAuth_NoLicense:
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) (FSP id=%1) retrieved accessStatus to 'DictFctAuth_NoLicense' for function %2 at row %3", IdType, fctStp->funcSecuProfId, SysnameType, fctStp->procName, IntType, iCpt); /* PMSTA-32214 - CHU - 180726  */
                    break;
                case DictFctAuth_Ok:
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) (FSP id=%1) has set accessStatus to 'DictFctAuth_Ok' for function %2 at row %3", IdType, fctStp->funcSecuProfId, SysnameType, fctStp->procName, IntType, iCpt); /* PMSTA-32214 - CHU - 180726  */
                    break;
                default:
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) (FSP id=%1) retrieved accessStatus as 'undefined' for function %2 at row %3", IdType, fctStp->funcSecuProfId, SysnameType, fctStp->procName, IntType, iCpt); /* PMSTA-32214 - CHU - 180726  */
                    break;
                }
                MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) fctStp->viewFlag == %1 and fctStp->visibleFlag == %2", IntType, (int)fctStp->viewFlag, IntType, (int)fctStp->visibleFlag); /* PMSTA-32214 - CHU - 180726  */
            }
        }
        if (retCode != RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) call to DBA_GetDictFctTabByUserId() returned retCode==%1", IntType, retCode); /* PMSTA-32214 - CHU - 180726  */
        }
        iCpt++;
        return retCode ;
    }
    else
    {
        if (true == EV_LogFSPSecuCheck)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_GetDictFctTab(level -1) is setting default EV_DictFctTab and EV_DictFctTab.size()"); /* PMSTA-32214 - CHU - 180726  */
        }
        fctTab = &EV_DictFctTab;
    }

    return RET_SUCCEED ;
}

/************************************************************************
**
**  Function    :   DBA_GetUseScreenFlag
**
**  Description :   Return use screen flag for the received entity
**                  in the meta-dictionary.
**
**  Arguments   :   entity : an OBJECT_ENUM member
**
**  Return      :   use screen flag for the entity
**
**  Creation    :   XFH - DVP580 - 970902
**  Modif.      :   ROI - 971223 - REF1033
**
*************************************************************************/
FLAG_T DBA_GetUseScreenFlag(OBJECT_ENUM entity)
{
    OPNAT_ENUM  opNature;

    OPE_DictEnumToOperNat(entity, &opNature);
    if (opNature != OpNat_None)
        entity = Op;

    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);
    if (dictEntityStp)
    {
        return  dictEntityStp->useScreenFlg;
    }

    return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_SetUseScreenFlag
**
**  Description :   Set use screen flag for the received entity
**                  in the meta-dictionary.
**
**  Arguments   :   entity : an OBJECT_ENUM member
**              :   useScreenFlg : The new value of use screen flag
**
**  Return      :   None
**
**  Creation    :   XFH - DVP580 - 970902
**  Modif.      :   ROI - 971223 - REF1033
**
*************************************************************************/
void DBA_SetUseScreenFlag(OBJECT_ENUM entity, FLAG_T useScreenFlg)
{
    OPNAT_ENUM  opNature;

    OPE_DictEnumToOperNat(entity, &opNature);
    if (opNature != OpNat_None)
        entity = Op;

    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);
    if (dictEntityStp)
    {
        dictEntityStp->useScreenFlg = useScreenFlg;
    }
}

/************************************************************************
**  Function             : DBA_SetFldDictInfo()
**
**  Description          : Update received structure (database flag and
**                         datatype) for customer fields.
**
**  Arguments            : dynSt      struct to fill (DBA_DYNSTDEF_STP)
**                         entity     entity enum    (OBJECT_ENUM)
**                         custFld    field nbr      (in meta-dictionary)
**
**  Return               : None
*************************************************************************/
void DBA_SetFldDictInfo(DBA_DYNSTDEF_STP dynSt, OBJECT_ENUM entity, int custFld)
{
    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(entity, custFld);

    if (dictAttribStp)
    {
        if ((dictAttribStp->custFlg == TRUE ||
            dictAttribStp->precompFlg == TRUE) && /* PMSTA-11505 - LJE - 110617 */
            dictAttribStp->calcEn == DictAttr_Virtual)
            dynSt->dbFlg = FALSE;
        else
            dynSt->dbFlg = TRUE;

        strcpy(dynSt->sqlName, dictAttribStp->sqlName);
        dynSt->dataType = dictAttribStp->dataTpProgN;
    }

    return;
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctAdmAuth
**
**  Description :   Get administration authorization for given entity.
**
**  Arguments   :   DICT_FCT_ENUM fctEn,
**		    OBJECT_ENUM entity,
**		    DICT_FCT_INFO_ENUM infoEn,
**		    PTR dataPtr
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 961125 - DVP260
**
*************************************************************************/
RET_CODE	DBA_GetDictFctAdmAuth(DICT_T fctEn, OBJECT_ENUM entity, DICT_FCT_INFO_ENUM infoEn, PTR dataPtr)
{
    DICT_FCT_STP		fctStp;
    DICT_T			entityDictId;
    FLAG_T			found;
    short			i;

    /* Test given argument */
    if (dataPtr == NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /* Get default administration status */
    DBA_GetDictFctInfo(fctEn, (short)infoEn, dataPtr);

    /* Init local variables */
    DBA_GetDictId(entity, &entityDictId);
    found = FALSE;
    i = 0;

    /* Loop looking for given function */
    while ((i < DBA_GetDictFctRows()) && (found == FALSE))
    {
      /* Init loop variable */
      fctStp = &(EV_DictFctTab[i++]);

        /* Check if current function correspond */
        if ((fctStp->dictId == fctEn) &&
            (fctStp->entityDictId == entityDictId))
        {
            found = TRUE;
            switch(infoEn)
            {
                case DictFctInfo_Stp :
                    *((DICT_FCT_STP*) dataPtr) = fctStp;
                    break;
                case DictFctInfo_AccesStatus :
                    *((DICT_FCTAUTH_ENUM*) dataPtr) = fctStp->accesStatus;
                    break;
                case DictFctInfo_CreateFlag :
                    *((FLAG_T*) dataPtr) = fctStp->createFlag;
                    break;
                case DictFctInfo_UpdateFlag :
                    *((FLAG_T*) dataPtr) = fctStp->updateFlag;
                    break;
                case DictFctInfo_DeleteFlag :
                    *((FLAG_T*) dataPtr) = fctStp->deleteFlag;
                    break;
                case DictFctInfo_RealTimeFlag :         /*  FIH-REF9764-040302  */
                    *((FLAG_T*) dataPtr) = fctStp->realTimeFlag;
                    break;
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CopyPermValTab
**
**  Description :   Copy a permitted value table
**
**  Arguments   :   PERMITED_VALUES_STP *permvaltabptrDest  : new permitted value table
**                  int                 *piNbSizeDest       : size of the new of permitted value
**                  PERMITED_VALUES_STP permvaltabOri       : original permitted value table
**                  int                 iNbSizeOri          : original number of permitted value
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
RET_CODE DBA_CopyPermValTab (PERMITED_VALUES_STP *permvaltabptrDest, int *piNbSizeDest, PERMITED_VALUES_STP permvaltabOri, int iNbSize)
{
    if ((permvaltabptrDest == nullptr) ||
        (piNbSizeDest == nullptr))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    PERMITED_VALUES_STP permvaltabDest = nullptr;
    if (iNbSize != 0)
    {
        permvaltabDest = new PermitedValuesClass [iNbSize];
        if (permvaltabDest == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        for (int i = 0; i < iNbSize; i++)
        {
            permvaltabDest[i] = permvaltabOri[i];
        }
    }
    if (*permvaltabptrDest != nullptr)
    {
        delete [] *permvaltabptrDest;
    }
    *permvaltabptrDest = permvaltabDest;
    *piNbSizeDest = iNbSize;

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_ExtOrRedPermValTab
**
**  Description :   Extend or reduce a permitted value table
**
**  Arguments   :   PERMITED_VALUES_STP *permvaltabptr  : permitted value table
**                  int                 *piNbOldSize    : Current size of the permitted value table
**                  int                 iChangeSize     : Change size of permitted value ... maybe negative
**                  int                 iPosChange      : Position where to change
**
**  Return      :   None
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
RET_CODE DBA_ExtOrRedPermValTab (PERMITED_VALUES_STP *permvaltabptr, int *piNbOldSize, int iChangeSize, int iPosChange)
{
    if ((permvaltabptr == nullptr) ||
        (piNbOldSize == nullptr) ||
        (iChangeSize == 0) &&
        (*piNbOldSize + iChangeSize > 0))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    int                 iSize = *piNbOldSize + iChangeSize;
    PERMITED_VALUES_STP permvaltabNew = new PermitedValuesClass [iSize];
    if (permvaltabNew == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if (*piNbOldSize != 0)
    {
        PERMITED_VALUES_STP permvaltabOri = *permvaltabptr;
        if (iChangeSize > 0)
        {
            for (int i = 0; i < iPosChange && i < iSize; i++)
            {
                permvaltabNew[i] = permvaltabOri[i];
            }
            for (int i = iPosChange + iChangeSize; i < iSize; i++)
            {
                permvaltabNew[i] = permvaltabOri[i - iChangeSize];
            }
        }
        else
        {
            for (int i = 0; i < iPosChange && i < iSize; i++)
            {
                permvaltabNew[i] = permvaltabOri[i];
            }
            for (int i = iPosChange; i < iSize; i++)
            {
                permvaltabNew[i] = permvaltabOri[i - iChangeSize];
            }
        }
    }
    if (*permvaltabptr != nullptr)
    {
        delete [] *permvaltabptr;
    }
    *permvaltabptr = permvaltabNew;
    *piNbOldSize = iSize;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_ShiftOnePermValTab
**
**  Description :   Shift a record from a position to another in a permitted value table
**
**  Arguments   :   PERMITED_VALUES_STP *permvaltabptr  : permitted value table
**                  int                 iSize           : Size of the permitted value table
**                  int                 iOldPos         : Current position of permitted value to move
**                  int                 iNewPos         : New position
**
**  Return      :   None
**
**  Creation    :   HFI-PMSTA-49174-220513
**
*************************************************************************/
RET_CODE DBA_ShiftOnePermValTab (PERMITED_VALUES_STP *permvaltabptr, int iSize, int iOldPos, int iNewPos)
{
    if ((permvaltabptr == nullptr) ||
        (*permvaltabptr == nullptr) ||
        (iSize == 0) ||
        (iOldPos == iNewPos) ||
        (iOldPos >= iSize) ||
        (iNewPos >= iSize))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    PERMITED_VALUES_STP permvaltabNew = new PermitedValuesClass [iSize];
    if (permvaltabNew == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    PERMITED_VALUES_STP permvaltabOri = *permvaltabptr;
    if (iNewPos < iOldPos)
    {
        for (int i = 0; i < iNewPos && i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i];
        }
        if (iNewPos < iSize)
        {
            permvaltabNew[iNewPos] = permvaltabOri[iOldPos];
        }
        for (int i = iNewPos + 1; i <= iOldPos && i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i - 1];
        }
        for (int i = iOldPos + 1; i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i];
        }
    }
    else
    {
        for (int i = 0; i < iOldPos && i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i];
        }
        for (int i = iOldPos; i < iNewPos && i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i + 1];
        }
        if (iNewPos < iSize)
        {
            permvaltabNew[iNewPos] = permvaltabOri[iOldPos];
        }
        for (int i = iNewPos + 1; i < iSize; i++)
        {
            permvaltabNew[i] = permvaltabOri[i];
        }
    }
    delete [] *permvaltabptr;
    *permvaltabptr = permvaltabNew;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_GetPckRightsFromEnvVar
**
**  Description :   Check that the user has the rights to edit packaging
**
**  Arguments   :   None
**
**  Return      :   int     PckRights
**
**  Modif.      :   HFI-PMSTA-13647-120203
**              :   HFI-PMSTA-54142-2023-08-10  Move from fmtlib01.c
**
*************************************************************************/
int DBA_GetPckRightsFromEnvVar (void)
{
    int         iRegistryRightMask;     /*  registry right mask             */
    char* pszVarName;            /*  Registry variable               */

    iRegistryRightMask = 0;
    if ((pszVarName = SYS_GetEnv("AAAOAMSDVPALLRIGHT")) != NULLSTR)
    {
        iRegistryRightMask = GUI_RIGHT_ALL | GUI_RIGHT_EDIT_PACK | GUI_RIGHT_EDIT_REP_FORMAT;
    }
    else
    {
        if (((pszVarName = SYS_GetEnv("AAAEDITPACK")) != NULLSTR) &&
            (strcmp(pszVarName, "TRUE") == 0))
        {
            iRegistryRightMask = GUI_RIGHT_EDIT_PACK | GUI_RIGHT_EDIT_REP_FORMAT;
        }
        else if (((pszVarName = SYS_GetEnv("AAAEDITREPFORMAT")) != NULLSTR) &&
            (strcmp(pszVarName, "TRUE") == 0))
        {
            iRegistryRightMask = GUI_RIGHT_EDIT_REP_FORMAT;
        }
    }
    /*  Manage PCK_PRN data                 */  /*  HFI-PMSTA-13647-120203  */
    if (((pszVarName = SYS_GetEnv("AAA_EDITRIGHTS_PCK_PRM")) != NULLSTR) &&
        (strcmp(pszVarName, "TRUE") == 0))
    {
        iRegistryRightMask |= GUI_RIGHT_EDIT_PACK_PRM;
    }
    /*  FPL-REF8612-030106 for the T_* */
    if (((pszVarName = SYS_GetEnv("AAAEDITTEST")) != NULLSTR) &&
        (strcmp(pszVarName, "TRUE") == 0))
    {
        iRegistryRightMask |= GUI_RIGHT_EDIT_TEST_DATA;
    }

    return iRegistryRightMask;
}


/************************************************************************
 **   END  dbadictlib.c
 *************************************************************************/


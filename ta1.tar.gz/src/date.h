/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DATE_H
#define DATE_H

#include <time.h>
#include <set>

#ifndef TIMER_H
#include "timer.h"
#endif

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#define DATE_NEXT     1
#define DATE_SAME     0
#define DATE_PREVIOUS (-1)

#define BAD_DATE      0L
#define BAD_DAY       0L
#define BAD_DATE_DIFF 0L  /* ?? */
#define BAD_DATE_PART 0L  /* ?? */
#define BAD_TIME      0L

#define DATETIME_SQL_STRING_SIZE	60	/* PMSTA-20159 - TEB - 151117 */
#define DATE_SQL_STRING_SIZE		40	/* PMSTA-20159 - TEB - 151117 */

/***************************************************************
** Macro LEAP_YEAR
** If year isn't divided by 4                    -> it isn't a leap year (FALSE)
** If it is divided by 4, but not by 100         -> it is a leap year    (TRUE)
** If it is divided by 4, by 100 but not by 400  -> it isn't a leap year (FALSE)
** If it is divided by 4, by 100 and by 400 too  -> it is a leap year    (TRUE)
** (x % y, operator % return 0 if x is divided by y)
**
****************************************************************/
#define LEAP_YEAR(Y) ((((int)(Y)%4)?FALSE:((int)(Y)%100)?TRUE:((int)(Y)%400)?FALSE:TRUE))

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/
typedef long DATE_DNUM_T;          /* Date number  */

typedef enum {
	Sunday = 1,
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saturday
} DATE_WEEKDAY_ENUM;

typedef enum {
	Day,
	Week,
	/* Fortnight, */
	Month,
	Quarter,
	Semester,
	Year,
	Decade,
	Century,
    Hour,           /* PMSTA-30817 - DDV - 180502 */
    Minute,         /* PMSTA-30817 - DDV - 180502 */
    Second          /* PMSTA-30817 - DDV - 180502 */
} DATE_UNIT_ENUM;

typedef enum {
	DayInWeek,                  /* 1 to 7 */
	DayInMonth,                 /* 1 to 31 */
	DayInQuarter,               /* 1 to 92 */
	DayInSemester,              /* 1 to 183 */
	DayInYear,                  /* 1 to 366 */
	DayInDecade,                /* 1 to 3653 */
	DayInCentury,
	DayInAll,
	WeekInYear,                 /* 1 to 53 */
	WeekInAll,
	MonthInQuarter,             /* 1 to 3 */
	MonthInSemester,            /* 1 to 6 */
	MonthInYear,                /* 1 to 12 */
	MonthInAll,
	QuarterInYear,              /* 1 to 4 */
	SemesterInYear,             /* 1 or 2 */
	YearInDecade,               /* 1 to 10 */
	YearInCentury,              /* 1 to 100 */
	YearInAll,
	DecadeInCentury,            /* 1 to 10 */
	DecadeInAll,
	CenturyInAll
} DATE_PART_ENUM;

typedef enum {
	SameDayIn,
	BeginOf,
	EndOf,
	MiddleOf,
	ThirdWednesdayIn,
	ThirdFridayIn,
	LastOpenDayBefore,
	NextOpenDaySince
} DATE_POSI_ENUM;

typedef enum {
	Ymd,                    /* "94.02.25", "19940225", "94/2/25", etc */
	Dmy,                    /* "25feb94", "25/02/1994", etc */
	Mdy,                    /* "Feb 25, 1994", etc */
	Iso                     /* "19940225" or "940225" */
} DATE_ORDRE_ENUM;

typedef enum
{
    DateStyle_None = -1,
    DateStyle_MmmDdYyyy12 = 0, /* mmm dd yyyy hh:nnAM (or PM) */
    DateStyle_MmDdYyyy = 1,    /* mm/dd/yyyy */
    DateStyle_DdMmYyyy = 3,    /* dd/mm/yyyy */
    DateStyle_YyyyDdMm24 = 13,  /* yyyy-dd-mm hh:nn:ss.ssssss */
    DateStyle_MmYyyyDd24 = 14,
    DateStyle_DdYyyyMm24 = 15,
    DateStyle_YyyyMmDd24 = 40,  /* yyyy-mm-dd hh:nn:ss.ssssss */
    DateStyle_Iso = 50,         /* YYYY-MM-DDThh:mm:ss[.mmm]TZD */
    DateStyle_IsoCompact,       /* YYYYMMDDThhmmss */

    DateStyle_MmmDdYyyy12b = 100,   /* mmm dd yyyy hh:nnAM (or PM) */
    DateStyle_MmDdYy = 101,         /* mm/dd/yyyy */
    DateStyle_DdMmYy = 103,         /* dd/mm/yyyy */
    DateStyle_DdMmYyyyDash = 105,   /* dd-mm-yyyy */
    DateStyle_DdMonYyyy = 106,      /* dd mon yyyy */
    DateStyle_YyyyMmDd = 111,       /* yyyy/mm/dd  */
    DateStyle_YyMmDd24 = 140        /* yy-mm-dd hh:nn:ss.ssssss */

} DATE_STYLE_ENUM;

typedef enum
{
    TimeStyle_None,
    TimeStyle_24,
    TimeStyle_12
} TIME_STYLE_ENUM;

typedef struct {
	long num;
	long denom;
} DATE_PERIOD_ST, *DATE_PERIOD_STP;

typedef enum {
	Days360,
	Days365,
	DaysActual,
	AnnualisedPeriod
} DATE_DAYSINYEAR_ENUM;

typedef struct {
	DATE_ORDRE_ENUM ordre;
	char yearSep[4],
	     monthSep[4],
	     daySep[4],
	     yearFormat,            /* 0 = short (94),   1 = long (1994   */
	     monthFormat;           /* 0 = numeric (02), 1 = short (feb), */
} DATE_FORMAT_ST, *DATE_FORMAT_STP; /* 2 = long (february)                */

/* DVP005 : New enum (96/03/20) RAK */
typedef enum {
	DateSqlFreq_Day=1,
	DateSqlFreq_Month,
	DateSqlFreq_Year
} DATE_SQLFREQ_ENUM;

typedef char DATE_MONTH_NAME[12][2][20];
typedef char DATE_WEEK_DAY_NAME[7][2][20];

extern  int SERV_SetAllFusionStatusCluster(const EVENTSCHEDSTATUS_ENUM);


/*******************************************************************************
**     Classes
*******************************************************************************/
class DatePeriod
{
public:

	DatePeriod();
	DatePeriod(const DATETIME_T & beginDate, const DATETIME_T & endDate);
	DatePeriod(const DATE_T & beginDate, const DATE_T & endDate);
	~DatePeriod() {};
	
	bool operator< (const DatePeriod &) const;	
	bool operator== (const DatePeriod &) const;
	void operator= (const DatePeriod &);
	//void operator= (const DatePeriod &);
	void setBegin(const DATETIME_T & beginDate);
	void setEnd(const DATETIME_T & endDate);	
	void setBegin(const DATE_T & beginDate);
	void setEnd(const DATE_T & endDate);	
	void set(const DATETIME_T & beginDate, const DATETIME_T & endDate);   
	void set(const DATE_T & beginDate, const DATE_T & endDate);   
	inline DATETIME_T getBegin() const { return m_begin; }
    inline DATETIME_T getEnd() const { return m_end; }      
	int cmpBegin(const DATETIME_T &) const;
	int cmpEnd(const DATETIME_T &) const;	    
	int cmpBegin(const DATE_T &) const;
	int cmpEnd(const DATE_T &) const;
	int cmpPeriod(const DatePeriod &) const;
	bool isValid() const;
	bool isOverlap(const DatePeriod&) const; /* PMSTA-55400 - DDV - 250220 */
	void mergePeriod(const DatePeriod&);     /* PMSTA-55400 - DDV - 250220 */

private:
	DATETIME_T	m_begin;
	DATETIME_T	m_end;

};

class DatePeriodVec
{
    public:
	    DatePeriodVec() {};
	    ~DatePeriodVec() {};
        size_t size() const;
	    void clear();
		bool empty() const;
	    void push_back(const DatePeriod &);
	    void push_back(const DATETIME_T & beginDate, const DATETIME_T & endDate);	
	    size_t count(const DatePeriod &) const;
	    DatePeriod & operator[](size_t n);
	    bool isValid() const;

    private:
	    std::vector<DatePeriod> m_datePeriodVec;
};


class DatePeriodSet
{
    public:
	    DatePeriodSet() {};
	    ~DatePeriodSet() {};
        size_t size() const;
	    void clear();
		bool empty() const;
	    void insert(const DatePeriod &);
	    void insert(const DATETIME_T & beginDate, const DATETIME_T & endDate);
		void erase(const DatePeriod&);             /* PMSTA-55400 - DDV - 250220 */
		size_t count(const DatePeriod &) const;
		std::set<DatePeriod>::const_iterator begin() const { return m_datePeriodSet.begin(); }
	    std::set<DatePeriod>::const_iterator end() const { return m_datePeriodSet.end(); }
	    bool isValid() const;
	    void copyToVector(DatePeriodVec &) const;
		void mergePeriods();                       /* PMSTA-55400 - DDV - 250220 */

    private:
	    std::set<DatePeriod> m_datePeriodSet;
};

/************************************************************************
**      External definitions attached to : datelib.c
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DATELIB_C
#define	EXTERN
#else
#define EXTERN extern
#endif

extern DATE_T   DATE_Put(YEAR_T, MONTH_T, DAY_T),
		        DATE_Move(DATE_T, int, DATE_UNIT_ENUM, FLAG_T forceMonthEnd=TRUE),
		        DATE_FormatToDate(const char *, DATE_FORMAT_STP),
		        DATE_MoveDay(DATE_T, int, DATE_WEEKDAY_ENUM),
		        DATE_CurrentDate(void),
		        DATE_MovePosi(DATE_T, DATE_POSI_ENUM, DATE_UNIT_ENUM);
extern char     *DATE_MonthName(char *, DATE_T, int),
		        *DATE_WeekDayName(char *, DATE_T, int),
		        DATE_WhichWeekDay(DATE_T date),
		        *DATE_GetStrTime(char *);
extern YEAR_T   DATE_GetYear(DATE_T date);
extern void     DATE_Get(DATE_T, YEAR_T *, MONTH_T *, DAY_T *),
                DATE_FillDayMonthName(void),
		        DATE_CurrentDateTime(DATETIME_T *,bool withMicroSecond=false),
				DATE_DaysBetween(DATE_T, DATE_T, ACCRRULE_ENUM, long *, ID_T), /* PMSTA-22396  - SRIDHARA - 160430 � new argument calendarId */
                DATE_BusinessDaysBetween(DATE_T, DATE_T, ID_T, long *), /* PMSTA-34288 - CHU - 190128 */
		        TIME_Get(TIME_T, HOUR_T *, MINUTE_T *, SECOND_T *, MICROSECOND_T * = nullptr);
extern int      DATE_Check(YEAR_T, MONTH_T, DAY_T),
                DATE_IsMagicEnd(YEAR_T, MONTH_T, DAY_T),
                DATE_IsDbBegin(YEAR_T, MONTH_T, DAY_T),
                DATE_IsLastInMonth(DATE_T),
		        DATE_FormatToStr(char *, DATE_T, DATE_FORMAT_STP),
				DATE_ToDbStr(char *, DATE_T),   /* PMSTA-20159 - TEB - 150624 */
				DATETIME_ToDbStr(char *, DATE_T, TIME_T), /* PMSTA-20159 - TEB - 150624 */
		        DATE_DaysInYear(DATE_T, DATE_T, DATE_DAYSINYEAR_ENUM, PERIOD_T, long *),
		        DATE_AccrMaxDaysInYear(DATE_T, DATE_T, ACCRRULE_ENUM, PERIOD_T, long*),	/* BUG472 */
				DATE_AccrPeriod(DATE_T, DATE_T, ACCRRULE_ENUM, PERIOD_T, DATE_PERIOD_STP, ID_T), /* PMSTA-22396  - SRIDHARA - 160430 � new argument calendarId */
		        DATE_VerifyEndMonth(DATE_T *, DAY_T, char),
                DATE_MoveEndPrevMonth(DATETIME_T, DATETIME_T *), /* REF7395 - YST -020607 */
                TIME_Check(HOUR_T, MINUTE_T, SECOND_T),
	            DATE_AccrMaxDaysInYear2(DATE_T, DATE_T, ACCRRULE_ENUM, PERIOD_T, long*); /* PMSTA-35314-RAK-190408*/;

extern bool     DATE_Between(const DATE_T & date1, const DATE_T & date2, const DATE_T & date3),
                DATE_IsSameCalenderUnit(const DATETIME_T,const DATETIME_T, DATE_UNIT_ENUM);  /* PMSTA-49587 - AIS - 220822 */
extern int      DATE_Cmp(DATE_T, DATE_T); /* PMSTA-15974 - LJE - 130528 */
extern long     DATE_Part(DATE_T, DATE_PART_ENUM);
extern DAY_T    DATE_DaysInMonth(MONTH_T, YEAR_T);
extern TIME_T   TIME_CurrentTime(void),
		        TIME_Put(HOUR_T, MINUTE_T, SECOND_T, MICROSECOND_T = 0);

extern char     *DATE_DateConv(DATE_T); /* REF7758 - LJE - 021003 */
extern char *   P(DATE_T);
extern char *   P(DATE_T *);
extern char *   P(DATETIME_T *);
extern char *   P(DATETIME_T &);

extern char     *TIME_TimeConv(TIME_T);
extern char *   P(TIME_T);
extern char *   P(TIME_T *);

extern char     *DATE_DateConvToddmmyyyy(DATE_T , char *); /*REF9751-EFE-050125*/

extern RET_CODE	DATE_CrystalDates(DATETIME_T, DATETIME_T, TINYINT_T, FREQUNIT_ENUM, char,
                                    DATETIME_T**, int*, char*, DATETIME_T*, /* DPV232 - DVP261 */
                                    DATE_POSI_ENUM,	/* REF5358 - CSY - 010131 */
                                    FLAG_T *, FLAG_T*),	    /* REF7244 - YST - 020430 */
                DATE_EndOfPeriodFlg(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, char*, DATETIME_T*), /* REF1402 */
                DATE_SqlFreq(FREQUNIT_ENUM, TINYINT_T, DATE_SQLFREQ_ENUM*, TINYINT_T*);
extern double   DATE_Diff(DATE_T, DATE_T, DATE_UNIT_ENUM, ACCRRULE_ENUM, ID_T);	 /* PMSTA-22396  - SRIDHARA - 160430 � new argument calendarId */

extern TIME_T   TIME_Add(TIME_T, long, long*);
extern long     TIME_Diff(TIME_T, TIME_T);
extern DATE_UNIT_ENUM DATE_FreqUnit2DateUnit(FREQUNIT_ENUM);
extern FLAG_T	DATE_CheckLeapPeriod(DATE_T, DATE_T);		  /* REF11277 - TEB - 050719 */

extern DATETIME_T DATE_GetMaxDatetime( const DATETIME_T , const  DATETIME_T ), /* PMSTA02926-EFE-070703*/
                  DATETIME_Put(YEAR_T, MONTH_T, DAY_T);

extern RET_CODE DATE_LastRegularDate(DATETIME_T, TINYINT_T, FREQUNIT_ENUM, DATETIME_T*);	/* PMSTA06820 - RAK - 090820 */

extern int      DATETIME_ToSqlStr(std::string &name, DATETIME_T dateTime, DATE_STYLE_ENUM style, TIME_STYLE_ENUM timeStyle);

extern std::string  to_stringSql(const DATE_T);
extern std::string DATE_ToYyyyMmDdStr(const DATE_T);
extern DATE_T DATE_YyyyMmDdStrToDate(std::string &);


extern RET_CODE DATE_DatetimeMove(DATETIME_T *, int, DATE_UNIT_ENUM, FLAG_T forceMonthEnd=TRUE); /* PMSTA-30817 - DDV - 180502 */

extern RET_CODE DATETIME_FormatToDateTime(const char *, DATETIME_T &, DATE_FORMAT_STP);

#endif         /*  #ifndef DATE_H */
/************************************************************************
*       END           date.h
*************************************************************************/

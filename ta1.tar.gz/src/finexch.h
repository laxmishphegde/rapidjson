/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINEXCH_H
#define FINEXCH_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finexch.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINEXCH_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE	    FIN_ExchRateFmt(ID_T, ID_T, EXCHANGE_T, EXCHANGE_T *),
		    FIN_ExchAmt(DATETIME_T, ID_T, ID_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, FIN_EXCHARG_STP,	/* PMSTA01649 - TGU - 070405 */
				EXCHANGE_T*, AMOUNT_T*, EXCHANGE_T*),
		    FIN_ExchAmtEuro(DATETIME_T, ID_T, ID_T, ID_T, ID_T, DBA_DYNFLD_STP, 
				    FIN_EXCHARG_STP, DBA_DYNFLD_STP, EXCHANGE_T*, 
				    AMOUNT_T*, EXCHANGE_T*),
		    FIN_GetExchRate(DATETIME_T, ID_T, ID_T, ID_T, DBA_DYNFLD_STP, 
				    DBA_DYNFLD_STP, FIN_EXCHARG_STP, EXCHANGE_T*),			/* PMSTA01649 - TGU - 070405 */
        	    FIN_SelectExchRate(ID_T, ID_T, DATETIME_T, char, DBA_DYNFLD_STP**, int*, FLAG_T, FIN_EXCHARG_STP, FLAG_T*), /* REF2580 */
		    FIN_SelDfltExchRate(ID_T, ID_T, DATETIME_T, char, FIN_EXCHARG_STP,
					FIN_EXCHTABARG_STP, FIN_EXCHOUT_STP),
		    FIN_EuroExchRate(ID_T, ID_T, ID_T*, DATETIME_T, DATETIME_T, 
				     FIN_EXCHARG_STP, FIN_EXCHTABARG_STP,
				     FIN_EXCHOUT_STP),	/* REF1177 */
		    FIN_IsExchRateValid(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		    FIN_InverseExchRate(DBA_DYNFLD_STP*, int),	/* REF1266 */
		    FIN_MergeExchRate(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		    FIN_GetExchValRuleIdInDomPPSPtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T *);	/* PMSTA01649 - TGU - 070410 */

#endif /* FINEXCH_H */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINSRV02_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "serv.h"
#include "ope.h"
#include "scptyl.h"
#include "fus.h"
#include "fmtorder.h"		/* REF11764 - RAK - 060404 */
#include "casemgt.h"        /* PMSTA-30897 - CHU - 180503 */
#include "dbaexec.h"
#include "dbiconnection.h"
#include "dbisqlexecbyblock.h" 	/* PMSTA-20159 - TEB - 151110 */
#include  "taxlotprocess.h"     /* PMSTA-28086 - SANAND -170319 */

/*  -------------------------------------------------------------------------------------------- **
**  ACCOUNTING HISTORY FUNCTIONS
**  ----------------------------
**  FIN_AnalysisAccHist() 	    Call performance fct and generate new ExtPos for each PosVal
**  FIN_AnalysisAccPerClosing() Close an accounting period
**
**  -------------------------------------------------------------------------------------------- **
**  DISPLAY CHRONO FUNCTIONS
**  -------------------------------------------------------------------------------------------- **
**  FIN_AnalysisDisplayChrono() Build chronological datas from ListCompo
**
**  -------------------------------------------------------------------------------------------- **
**  OP HISTORY FUNCTIONS
**  --------------------
**  FIN_AnalysisOpHist() 	    Make an operation history on a position set
**
**  -------------------------------------------------------------------------------------------- **
**  OP LIST FUNCTIONS
**  -----------------
**  FIN_AnalysisOpList() 	    Make an operation list on a position set
**
**  -------------------------------------------------------------------------------------------- **
**  OP SEARCH FUNCTIONS
**  -------------------
**  FIN_AnalysisOpSearchPhase1() Retrieve a hierarchy (ExtPos hierarchy),
**                               read ExtPos from hierarchy and construct/create
**                               ExtOp, filter it and store result in hierarchy.
**                               this function is directly called from DBA_LoadPos
**  FIN_AnalysisOpSearchPhase2() Read ExtOp and manage Parent-Child operations to load
**  -------------------------------------------------------------------------------------------- **
**  ORDER LIST FUNCTIONS
**  --------------------
**  FIN_AnalysisOrderList()     Retrieve a hierarchy (ExtPos hierarchy)
**
**  -------------------------------------------------------------------------------------------- **
**  PERFORMANCE FUNCTIONS
**  ---------------------
**  FIN_AnalysisPerfo() 	    Compute performance on a position set
**
**  -------------------------------------------------------------------------------------------- **
**  VALORISATION FUNCTIONS
**  ----------------------
**  FIN_AnalysisFundValo() 	Compute valuation for fund
**  FIN_AnalysisValo() 		Make a valuation on a position set
**
**  FIN_MultiPeriod() 		Determine stock pos on crystallised dates (initial, interm, final)
**  FIN_PosExtValo() 		Allocate and add valorisation extension to received pos
**  FIN_PosNetVal()		    Compute pos value at received ref date depending on domain infos
**  FIN_SetMktValToPos() 	Copy instr net value and accr interest in position
**  FIN_SetPriceToPos() 	Set instrument price fields in position structure
**  FIN_ValoProcess() 		Compute pos value at position date depending on domain info
**
**  -------------------------------------------------------------------------------------------- **
**  TOOLS FUNCTIONS
**  ---------------
**  FIN_CheckLogicalFusion() Read domain parameter and decide to perform logical fusion or not
**  FIN_UpdPosRefAmt() 		 Ensure that ref curr gross and net amounts are in the ref currency
**  FIN_UpdPosSysAmt() 		 Ensure that system curr gross and net amounts are in the ref curr.
**  FIN_UpdPosFields()       Modify ExtPos fields
**
**  COMPARISONS FUNCTIONS
**  ---------------------
**  FIN_CmpCashPos() 		Position table is sorted by instr nature : cash are last
**  FIN_CmpCheckLogicalFusion() Position table is sorted by instrument identifier
**  FIN_CmpValoPos() 		Position table is sorted by pos date, instr id, curr id and term id
**  FIN_CmpListCompoByDescDate ListCompo table is sorted by valid date descending order.
**
**  FILTERS FUNCTIONS
**  -----------------
**  FIN_FilterBPNoPrice()   Verify that extpos is a BP with NULL quote (and NOT null price)
**  FIN_FilterChildOrder()  Verify that an ExtOp is a child order
**  FIN_FilterInitStock() 	Extract initial stock position and balance position
**  FIN_FilterFinalStock() 	Extract final stock position and balance position
**  FIN_FilterPStock()		Extract stock position
**  FIN_FilterNotChildOrder() Verify that order is not a child order
**  -------------------------------------------------------------------------------------------- **
**
**  UNMATCHED EXECUTIONS FUNCTIONS
**  ------------------------------
**  FIN_AnalysisSMatchO()   Retrieve matching orders for a given set of unmatched executions
**  -------------------------------------------------------------------------------------------- */

/************************************************************************
**      Static definitions & data
*************************************************************************/

STATIC FLAG_T   FIN_SetMktValToPos(DATETIME_T, ID_T, DBA_DYNFLD_STP, FIN_MKTVAL_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_ChechIfValRuleUseExtPos(ID_T, DBA_DYNFLD_STP);

STATIC int      FIN_CmpValoPos(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                FIN_CmpListCompoByDescDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *), /* REF4306 - CSY - 000207 */
				FIN_CmpPortFreqByIdAndAscDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *), /* REF7318 - LJE - 020122 */
                FIN_FilterParentOrder(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* DVP342 */ /* REF7264 - LJE - 020131 */
                FIN_FilterChildOrder(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
                FIN_FilterBPNoQuote(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
				FIN_FilterSingleListCompo (DBA_DYNFLD_STP , DBA_DYNST_ENUM , DBA_DYNFLD_STP ),
				FIN_FilterSingleInstr(DBA_DYNFLD_STP , DBA_DYNST_ENUM , DBA_DYNFLD_STP ),
                FIN_CmpExtOpByOpIdFusion(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2), /* REF7560 - DDV - 020605 */
                FIN_CmpExtPosAcct(const void *, const void *, const void *),           /* PMSTA04141 - DDV - 071003 */ /* PMSTA04136 - BSA - 071023 : Code Reporting of PMSTA04141 in 4.30.2 */
                FIN_FilterNotChildOrder(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF8723 - TEB - 040218 */
				FIN_FilterTopHierPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);    /* WEALTH-10005 - Deepthi - 20240627 */


STATIC RET_CODE FIN_MultiPeriod(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
		        FIN_UpdPosFields(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF7264 - LJE - 020124 */
                FIN_InsExtOpInHierWithFilter(DBA_DYNFLD_STP *, int, char *, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T), /* REF7560 - DDV - 020604 */
                FIN_RemoveDuplicateExtOp(DBA_HIER_HEAD_STP), /* REF7560 - DDV - 020605 */
				FIN_GetFmtFilter(DBA_DYNFLD_STP, OBJECT_ENUM,	char **, FLAG_T *), /* REF10530 - TEB - 050818 */
                FIN_UpdPosRefAmounts(DBA_DYNFLD_STP, DBA_DYNFLD_STP, ID_T, ID_T, FLAG_T, char *), /*PMSTA-32606 - NRAO - 300818*/
                FIN_SetPosRefAmounts(DBA_DYNFLD_STP, DBA_DYNFLD_STP, FIELD_IDX_T, ID_T, ID_T, FLAG_T, char *); /*PMSTA-32606 - NRAO - 300818*/

STATIC RET_CODE FIN_IncomesNewCashPos(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP*, int);	/* PMSTA00485 - RAK - 061024 */
STATIC RET_CODE FIN_CreateReceivablePos(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC int		FIN_CmpFlowInstrDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);						/* PMSTA00485 - RAK - 061030 */
STATIC int		FIN_CmpExtPosPtfInstr(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);						/* PMSTA00485 - RAK - 061030 */
STATIC RET_CODE FIN_IncomesNewCashPosQty(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, double*,
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos); /* PMSTA00485 - RAK - 061121 */
STATIC RET_CODE FIN_IncomesNewCashPosTab(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, int, std::map<std::pair<ID_T, ID_T>, std::map<DATE_T, double>> &);
STATIC int		FIN_FilterRiskOrigOnFXFwdWithTwoLegsAgainsPtfCurr(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-48144 - DDV - 220608 */


extern bool EV_TracePerf; /*PMSTA-48195 - lalby - enable trace log*/
/************************************************************************
**      External entry points
**
*************************************************************************/
extern RET_CODE DBA_TabulaRasa(ID_T, CASEMANAGEMENTNAT_ENUM, int*); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE FIN_SaveCaseManagement(DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP *, int , int *); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE FIN_CleanHierAfterCheckAndPublish(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE FIN_VerifyBlockSession(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T, DBA_DYNFLD_STP*, int, EXTOP_ACTION_ENUM, FLAG_T*, int*); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE FIN_VerifyBlockSessionNonCMC(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP*, int, EXTOP_ACTION_ENUM, FLAG_T*, int*); /* PMSTA-30897 - CHU - 180503 */
extern RET_CODE	FIN_CheckStratValoDomain(DBA_DYNFLD_STP, FLAG_T, FLAG_T, DBA_DYNFLD_STP*); /* PMSTA-30894 - CHU - 180711 */
extern bool     FIN_IsCAExchangeEventFlow(FLOWSUBNAT_ENUM subNat); /* PMSTA-36248 - SGO - 290819 */


/************************************************************************
*
*   Function      :   FIN_FilterFlowsForCA()
*
*   Description   :   Return only flows for corporate action events
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA-36248 - SGO - 290819 - Maintain Portfolio Value
*************************************************************************/
int FIN_FilterFlowsForCA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM, DBA_DYNFLD_STP crtPtfSt)
{
	FLOWSUBNAT_ENUM flowSubNat = static_cast<FLOWSUBNAT_ENUM>(GET_FLAG(dynSt, Flow_SubNatEn));
	if (FIN_IsCAExchangeEventFlow(flowSubNat))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int FIN_FilterPosByInstrId(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM, DBA_DYNFLD_STP flow)
{
	PosLog pos(dynSt);
	if (GET_ID(dynSt, ExtPos_InstrId) == GET_ID(flow, Flow_InstrId) &&
		GET_ENUM(dynSt, ExtPos_PosNatEn) != PosNat_ReceivablePos)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/************************************************************************
**
**  Function    :   FIN_AnalysisAccHist()
**
**  Description :   Call performance fct and generate new ExtPos for each PosVal
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE FIN_AnalysisAccHist(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE          ret;

	/* Call performance function */
	if ((ret = FIN_AnalysisPerfo(domainPtr, hierHead)) != RET_SUCCEED)
		return(ret);

	/* create new ExtPos for each PosVal accrued value and net value */
	ret = FIN_GenAccrNetValuePos(hierHead);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfId()
**
**  Description :   Compare the list portfoli_id with ComplianceChrono
**                     portfolio
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_ComplianceChrono_PtfId
**                  ptr2   pointer on dynamic structure type A_ListCompo_ObjId
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation date     : PMSTA-23652 - cashwini - 160704
**  Last modification :
**
*************************************************************************/
STATIC int FIN_CmpPtfId(DBA_DYNFLD_STP dynSt,
	DBA_DYNST_ENUM dynStTp,
	DBA_DYNFLD_STP extractPtr)
{
	if (CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_PtfId, A_ListCompo_ObjId, IdType) == 0)
		return TRUE;
	else
		return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_CmpChronoValidDate()
**
**  Description :   Compare Chrono validity date
**
**  Arguments   :   ComplianceChronoVal1 and ComplianceChronoVal2 for comparison
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Creation date     : PMSTA-23652 - cashwini - 160704
**  Last modification :
**
*************************************************************************/
STATIC int DBA_CmpChronoValidDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return (DATETIME_CMP(GET_DATETIME((*ptr1), A_ComplianceChrono_ValidDate),
		GET_DATETIME((*ptr2), A_ComplianceChrono_ValidDate)));
}

/************************************************************************
**
**  Function          : DBA_FilterNatureComplChrono1()  filter function
**
**
**  Description       : This function filters records by nature
**
**  Arguments         : dynSt        :      current record (A_ComplianceChrono)
**                      dynStTp      :      current record type
**                      extractPtr   :      input argument containing search criteria
**
**  Return            : TRUE/FALSE
**
**  Creation date     : PMSTA-23652 - cashwini - 160704
**  Last modification :
**
*************************************************************************/
STATIC int DBA_FilterNatureComplChrono1(DBA_DYNFLD_STP dynSt,
	DBA_DYNST_ENUM dynStTp,
	DBA_DYNFLD_STP extractPtr)
{
	if ((GET_ENUM(dynSt, A_ComplianceChrono_CompNatEn) == 1) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_PtfId, A_ComplianceChrono_PtfId, IdType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_StratId, A_ComplianceChrono_StratId, IdType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_ThirdPartyId, A_ComplianceChrono_ThirdPartyId, IdType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_SubNatTypeId, A_ComplianceChrono_SubNatTypeId, IdType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_NatEn, A_ComplianceChrono_NatEn, EnumType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_ConfidenceLevel, A_ComplianceChrono_ConfidenceLevel, NumberType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_TimeHorizon, A_ComplianceChrono_TimeHorizon, TinyintType) == 0) &&
		(CMP_DYNFLD(dynSt, extractPtr, A_ComplianceChrono_TimeHorizonUnitEn, A_ComplianceChrono_TimeHorizonUnitEn, EnumType) == 0))
		return TRUE;
	else
		return FALSE;
}

/************************************************************************
**
**  Function    :   FIN_AnalysisAccPerClosing()
**
**  Description :   close a accounting Period. (DVP0018)
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE FIN_AnalysisAccPerClosing(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP      sAccPerSt=NULLDYNST, aAccPerSt=NULLDYNST,
	                    sPtfSt=NULLDYNST, aPtfSt=NULLDYNST,
	                    aDocIndexSt=NULLDYNST, *ptfTab=NULLDYNSTPTR;
	/*ID_T              ptfId;*/
	int	                ptfNb=0, i=0;       /* REF195 - XDI - 980108 */
	DATE_T              date;
	DATETIME_T          endDateTime;
	RET_CODE            ret;

	/* Call accounting history function */
	if ((ret = FIN_AnalysisAccHist(domainPtr, hierHead)) != RET_SUCCEED)
		return(ret);

	if ((ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE, NULL, NULL,
					                 &ptfNb, &ptfTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* insert PosVal in database for all portfolio */ /* REF195 - XDI - 980108 */
	for (i=0; i<ptfNb; i++)
	{
		FIN_InsertPosVal(GET_ID(ptfTab[i], A_Ptf_Id),
		                 hierHead,
		                 GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
		                 ExtPosNat_FinalStock);
	}

	/* Update closing date and final closing flag in accounting period */
	if ((sAccPerSt = ALLOC_DYNST(S_AccPer)) == NULLDYNST)
   		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((aAccPerSt = ALLOC_DYNST(A_AccPer)) == NULLDYNST)
	{
		FREE(ptfTab); /* REF195 - XDI - 980108 */
		FREE_DYNST(sAccPerSt, S_AccPer);
   		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(sAccPerSt, S_AccPer_Id, GET_ID(domainPtr,A_Domain_AccPeriodId));

	if (DBA_Get2(AccPer, UNUSED, S_AccPer, sAccPerSt, A_AccPer, &aAccPerSt,
	             UNUSED, UNUSED, UNUSED) != TRUE)
	{
		FREE(ptfTab); /* REF195 - XDI - 980108 */
		FREE_DYNST(sAccPerSt, S_AccPer);
		FREE_DYNST(aAccPerSt, A_AccPer);
   		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(sAccPerSt, S_AccPer);

	date = DATE_CurrentDate();
	SET_DATE(aAccPerSt, A_AccPer_ClosingDate, date);

	endDateTime.time = 0;
	endDateTime.date = GET_DATE(aAccPerSt, A_AccPer_EndDate);

	switch(GET_ENUM(domainPtr, A_Domain_ClosingNatEn))
	{
	    case ClosingNat_Initial:
		/* reset accounting code index */
		if ((aDocIndexSt = ALLOC_DYNST(A_DocIndex)) == NULLDYNST)
		{
			FREE(ptfTab); /* REF195 - XDI - 980108 */
			FREE_DYNST(aAccPerSt, A_AccPer);
   			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* assume that next accounting period begin one day after */
		/* end of current accounting period */
		endDateTime.date = DATE_Move(endDateTime.date, 1, Day);

		SET_DATETIME(aDocIndexSt, A_DocIndex_RefDate, endDateTime);
		SET_ENUM(aDocIndexSt,     A_DocIndex_NatEn,   DocIndexNat_AccountingCd);
		SET_INT(aDocIndexSt,      A_DocIndex_Index,   0);

		/* insert new document indes for all portfolio */ /* REF195 - XDI - 980108 */
		for (i=0; i<ptfNb; i++)
		{
			COPY_DYNFLD(aDocIndexSt, A_DocIndex, A_DocIndex_PtfId,
			ptfTab[i], A_Ptf, A_Ptf_Id);
            ret = DBA_Insert2(DocIndex, UNUSED, A_DocIndex, aDocIndexSt, UNUSED,
                              UNUSED);

            /* if RET_SUCCEED or record allready exist continue */ /* REF2790 */
            if (ret != RET_SUCCEED && ret != RET_SRV_LIB_ERR_DUPLICATEKEY)
            {
                FREE(ptfTab); /* REF195 - XDI - 980108 */
                FREE_DYNST(aAccPerSt, A_AccPer);
                FREE_DYNST(aDocIndexSt, A_DocIndex);
                return(RET_DBA_ERR_DBPROBLEM);
            }
		}

		FREE_DYNST(aDocIndexSt, A_DocIndex);
		break;

	    case ClosingNat_Intermediate:
		break;   /* nothing special to do */

	    case ClosingNat_Final:
		SET_FLAG(aAccPerSt, A_AccPer_FinalClosingFlg, TRUE);

		/* update last exercise date in portfolio */
		if ((sPtfSt = ALLOC_DYNST(S_Ptf)) == NULLDYNST)
		{
			FREE(ptfTab); /* REF195 - XDI - 980108 */
			FREE_DYNST(aAccPerSt, A_AccPer);
   			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((aPtfSt = ALLOC_DYNST(A_Ptf)) == NULLDYNST)
		{
			FREE(ptfTab); /* REF195 - XDI - 980108 */
			FREE_DYNST(aAccPerSt, A_AccPer);
			FREE_DYNST(sPtfSt, S_Ptf);
   			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* update last exercise date for all portfolio */ /* REF195 - XDI - 980108 */
		for (i=0; i<ptfNb; i++)
		{
			COPY_DYNFLD(sPtfSt, S_Ptf, S_Ptf_Id, ptfTab[i], A_Ptf, A_Ptf_Id);
			if (DBA_Get2(Ptf, UNUSED, S_Ptf, sPtfSt, A_Ptf, &aPtfSt,
			             UNUSED, UNUSED, UNUSED) != TRUE)
			{
				FREE(ptfTab); /* REF195 - XDI - 980108 */
				FREE_DYNST(aAccPerSt, A_AccPer);
				FREE_DYNST(sPtfSt, S_Ptf);
				FREE_DYNST(aPtfSt, A_Ptf);
   				return(RET_DBA_ERR_NODATA);
			}

			SET_DATETIME(aPtfSt, A_Ptf_LastExerciceDate, endDateTime);

       		if (DBA_Update2(Ptf, UNUSED, A_Ptf, aPtfSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
			{
				FREE(ptfTab); /* REF195 - XDI - 980108 */
				FREE_DYNST(aAccPerSt, A_AccPer);
				FREE_DYNST(sPtfSt, S_Ptf);
				FREE_DYNST(aPtfSt, A_Ptf);
	       	    return(RET_DBA_ERR_DBPROBLEM);
			}
		}

		FREE_DYNST(sPtfSt, S_Ptf);
		FREE_DYNST(aPtfSt, A_Ptf);
		break;
	}

    if (DBA_Update2(AccPer, UNUSED, A_AccPer, aAccPerSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		FREE(ptfTab); /* REF195 - XDI - 980108 */
		FREE_DYNST(aAccPerSt, A_AccPer);
        return(RET_DBA_ERR_DBPROBLEM);
	}

	FREE(ptfTab); /* REF195 - XDI - 980108 */
	FREE_DYNST(aAccPerSt, A_AccPer);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DATE_CrystalDateOutRange()
**
**  Description :   Compute the date before and after the range of crystal date
**
**  Arguments   :   begCrystalDate      : The begin date of crystal dates
**					tillCrystalDate     : The till date of crystal dates
**					freq                : frequency
**					freqUnit            : frequency unit
**					posiEn              :
**					*crystalDateBefore  : The "before" output date
**                  *crystalDateAfter   : The "after" output date
**
**  Return      :   RET_SUCCEED or error code
**
**  Create      :   REF7318 - LJE - 020122
**
*************************************************************************/
RET_CODE DATE_CrystalDateOutRange(DATETIME_T     begCrystalDate,
								  TINYINT_T      freq,
								  FREQUNIT_ENUM  freqUnit,
								  int            crystalDateNb,
								  DATE_POSI_ENUM posiEn,
								  DATETIME_T     *crystalDateBefore,
								  DATETIME_T     *crystalDateAfter)
{
	DATE_UNIT_ENUM dateUnit=Year;

	switch (freqUnit)
	{
	case FreqUnit_Day:
		dateUnit = Day;
		break;

	case FreqUnit_BusDay:
		dateUnit = Day;
		break;

	case FreqUnit_Week:
		dateUnit = Week;
		break;

	case FreqUnit_Month:
		dateUnit = Month;
		break;

	case FreqUnit_Quarter:
		dateUnit = Quarter;
		break;

	case FreqUnit_Semester:
		dateUnit = Semester;
		break;

	case FreqUnit_Year:
		dateUnit = Year;
		break;
	}

	crystalDateBefore->date = DATE_Move(begCrystalDate.date, (int) freq * -1, dateUnit);
	crystalDateBefore->time = 0;
	crystalDateAfter->date  = DATE_Move(begCrystalDate.date, (int) freq * crystalDateNb, dateUnit);
	crystalDateAfter->time  = 0;

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AnalysisDisplayChrono()
**
**  Description :   Compute chronological datas for entities or list of entities
**                  (entities: portfolio, instrument, currency, third party)
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF4306 - CSY - 000207.
**  Modification:   REF5353 - CSY - 010207: when from=till, force freqUnit to Day
**  Modification:   REF8692 - YST - 030113/030124
**  Modification:   REF8749.4001 - YST - 030127
**  Modification:   REF8765 - YST - 030129
**  Modification:   REF9125 - MCA - 030926 add psp parameter
**                  PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
*************************************************************************/
RET_CODE FIN_AnalysisDisplayChrono(DBA_DYNFLD_STP	 domainPtr,
								   DBA_HIER_HEAD_STP hierHead,
								   DBA_DYNFLD_STP	 pspPtr)
{

	RET_CODE		ret;
    DBA_DYNFLD_STP	*extractListCompoTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP	*extractTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP	*childrenPtfTab = NULLDYNSTPTR;
    DATETIME_T		fromDate, tillDate, *crystalDates = nullptr;
	TINYINT_T		freq;
	FREQUNIT_ENUM	freqUnit;
	FLAG_T			existFlg = FALSE;
    int				listCompoNbr;
    int				crystalNbr;
    int				i=0;
    int				j=0;
    int				k=0;
    int				f;
    int				first = 0;
	int				last  = 0; /* REF7318 - LJE - 020122 */
    int				byFreqAllocSz = 0;
    int				extractNbr = 0;
    int				byFreqNbr = 0;
    int				byFreqNbr1 = 0;
    int				srcIdFld = 0;
    int				destIdFld = 0,destPSPId=0;
    int				destInitDateFld = 0, destFreqDateFld = 0; /* destFinalFld = -1; */   /* REF8749.4001 - YST - 030124 */
    int				destLinkFld = 0;
    int				ptfNbr = 0;
    int				tmpCrystalNbr = 0, freqIdx = 0; /* REF8765 - YST - 030129 */
	int				firstCrystDate=0;
    HIER_FLTFCT     *filterFct = NULLFCT;           /* REF8765 - YST - 030129 */
    OBJECT_ENUM     dimPtfObjectEnum;               /* List, Ptf, Instr, Curr, Third */
    DBA_DYNST_ENUM  outDynStEnum = NullDynSt;
    DBA_DYNST_ENUM  srcDynStEnum = NullDynSt;       /* A_Ptf, A_Instr, A_Curr, A_Third */

    DBA_DYNFLD_STP	aXFreq = NULLDYNST;
    DBA_DYNFLD_STP  *byFreqTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  *ptfTab = NULLDYNSTPTR;
    DBA_DYNFLD_ST   ptfIdDynSt;
    DBA_DYNFLD_STP  aPtfSt = NULLDYNST;

	/* REF7318 - LJE - 020122 */
	PTFFREQSTATUS_ENUM ptfFreqStatus = PtfFreqStatus_Null;
	int               crystalPos=0;
	ID_T              oldId = 0, currId = 0;
	FLAG_T            oldNullFlg = TRUE, currNullFlg = TRUE;
	FLAG_T            before, after, beforeOk;
	int               (*funcSort)(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *) = NULL;
	DATETIME_T        crystalDateBefore, crystalDateAfter;
	DBA_DYNFLD_STP    *listCompoBeforePtr = NULLDYNSTPTR,
		              *listCompoAfterPtr = NULLDYNSTPTR;
	int               listCompoBeforeNbr=0, listCompoAfterNbr=0;
	DICT_T			  fctDictId = 0;

	memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST)); /* REF7264 - LJE - 020128 */

    fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	/* REF7318 - LJE - 020122 */
	crystalDateBefore = fromDate;
	crystalDateAfter  = tillDate;

	/*** FREQUENCY ***/
	/* Read frequency in domain  */
    freqUnit = (FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq1UnitEn);

    /* REF5353 - CSY - 010207 */
    if (DATETIME_CMP(fromDate, tillDate) == 0 && freqUnit >= FreqUnit_Month)
        freqUnit = FreqUnit_Day; /* because tests are done on
            end of month in DATE_CrystalDates function for frequncies >= FreqUnit_Month */

    if (IS_NULLFLD(domainPtr, A_Domain_Freq1) == FALSE)
	{
        freq     = GET_TINYINT(domainPtr, A_Domain_Freq1);
        if (freq == 0)
            freq = 1;
	}
    else
    {
        freq = 1;
    }

	/*** DATES CRYSTALLISATION ***/
	/* Determines according to begin and end date, the  */
	/* dates upon which the positions need to be valued */
	ret = DATE_CrystalDates(fromDate, tillDate, freq, freqUnit, FALSE,
				            &crystalDates, &crystalNbr, NULL, NULL, (DATE_POSI_ENUM)EndOf, /* REF5358 - CSY - 010131: new arg EndOf */
                            nullptr, nullptr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		/* FREE(extractPos);*/
        FREE(crystalDates);
		return(ret);
	}

	fctDictId=GET_DICT(domainPtr, A_Domain_FctDictId); /*ref 7422 mca*/ /* DLA - REF9089 - 030512 */
	if 	(fctDictId == DictFct_BenchStorage)
	{
        /* extract ListCompos for a single instrument using sort by descending dates */
		if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
													 A_ListCompo,
													 FALSE,
													 FIN_FilterSingleListCompo,
													 domainPtr ,
													 FIN_CmpListCompoByDescDate,
													 &listCompoNbr,
													 &extractListCompoTab)) != RET_SUCCEED)
		{
			FREE(extractListCompoTab);
			FREE(crystalDates);
			return(ret);
		}
	}
	else
	{
        /* extract ListCompos using sort by descending dates */
		if ((ret = DBA_ExtractHierEltRec(hierHead, A_ListCompo, FALSE,
										 NULLFCT, FIN_CmpListCompoByDescDate,
										 &listCompoNbr,  &extractListCompoTab)) != RET_SUCCEED)
		{
			FREE(extractListCompoTab);
			FREE(crystalDates);
			return(ret);
		}
	}
    /* last param set to TRUE for optimisation */
    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId),&dimPtfObjectEnum); /* DLA - REF9089 - 030512 */
    if (dimPtfObjectEnum == List ||
        dimPtfObjectEnum == QuickSearch ||
        dimPtfObjectEnum == NullEntity)
    {
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId),&dimPtfObjectEnum); /* DLA - REF9089 - 030512 */
        if (listCompoNbr > 0)
        {
            srcDynStEnum = A_ListCompo;
            srcIdFld = A_ListCompo_ObjId;
        }
    }

    switch (GET_OBJECT_CST(dimPtfObjectEnum)) /* REF8844 - LJE - 030416 */
    {
        case PtfCst:
            if (listCompoNbr == 0)
            {
                srcDynStEnum = A_Ptf;
                srcIdFld   = A_Ptf_Id;
            }
            destIdFld    = A_PtfFreq_PtfId;
            destInitDateFld = A_PtfFreq_InitialDate;    /*destDateFld = A_PtfFreq_InitialDate;*/            /* REF8749.4001 - YST - 030127 */
            destFreqDateFld = A_PtfFreq_FreqDate;       /*destFinalFld = A_PtfFreq_FreqDate; REF7423 MCA */ /* REF8749.4001 - YST - 030127 */
            outDynStEnum = A_PtfFreq;
            destLinkFld  = A_PtfFreq_A_Ptf_Ext;
			funcSort     = FIN_CmpPortFreqByIdAndAscDate; /* REF7318 - LJE - 020122 */
            break;

        case InstrCst:
            if (listCompoNbr == 0)
            {
                srcDynStEnum = A_Instr;
                srcIdFld   = A_Instr_Id;
            }
            destIdFld    = A_InstrFreq_InstrId;
			destPSPId    = A_InstrFreq_PSPId;				;
            destInitDateFld  = A_InstrFreq_InitialDate; /* destFinalFld = A_InstrFreq_FinalDate; */ /* REF8749.4001 - YST - 030124 */
            destFreqDateFld  = A_InstrFreq_FreqDate;    /* destDateFld = A_InstrFreq_FreqDate; */   /* REF8749.4001 - YST - 030124 */
            outDynStEnum = A_InstrFreq;
            destLinkFld  = A_InstrFreq_A_Instr_Ext;
            break;

        case CurrCst:
            if (listCompoNbr == 0)
            {
                srcDynStEnum = A_Curr;
                srcIdFld   = A_Curr_Id;
            }
            destIdFld    = A_CurrFreq_CurrId;
            destFreqDateFld /*destDateFld*/ = A_CurrFreq_FreqDate;  /* REF8749.4001 - YST - 030124 */
            outDynStEnum = A_CurrFreq;
            destLinkFld  = A_CurrFreq_A_Curr_Ext;
            break;

        case ThirdCst:
            if (listCompoNbr == 0)
            {
                srcDynStEnum = A_Third;
                srcIdFld   = A_Third_Id;
            }
            destIdFld    = A_ThirdFreq_ThirdId;
            destFreqDateFld /*destDateFld*/ = A_ThirdFreq_FreqDate; /* REF8749.4001 - YST - 030124 */
            outDynStEnum = A_ThirdFreq;
            destLinkFld  = A_ThirdFreq_A_Third_Ext;
            break;
    }

    /* if extractNbr > 0, will find the number of A_ListCompo in hierarchy. Otherwise, will
    find the number of A_Ptf (or A_Instr, A_Curr, A_Third) in hierarchy */
    /* REF8765 - YST - 030129 - code reeng., open question: do we have listCompo for Bench Storage? */
	if 	(fctDictId == DictFct_BenchStorage)
	{
        if (srcDynStEnum == A_Instr)
            filterFct = FIN_FilterSingleInstr;
        else
            filterFct = FIN_FilterSingleListCompo;

        ret = DBA_HierGetRecNbrWithFilterSt(hierHead, srcDynStEnum, filterFct, domainPtr, &extractNbr, TRUE);
	}
	else
	{
	    ret = DBA_HierGetRecNbr(hierHead, srcDynStEnum, NULLFCT, &extractNbr, TRUE);
	}

    if (ret != RET_SUCCEED)
    {
        FREE(crystalDates);
	    return(ret);
    }

    /* REF8765 - YST - 030129 - compute temporary crystalNbr and freqIdx */
    tmpCrystalNbr = crystalNbr;
	/* REF9582 - RAK - 031105 - PtfStorage on merged list work like Composite Manager */
    if (/* fctDictId == DictFct_PtfStorage ||*/ fctDictId == DictFct_BenchStorage)
    {
        tmpCrystalNbr--;
        freqIdx = 1;
    }

    byFreqAllocSz = extractNbr * tmpCrystalNbr /*crystalNbr*/; /* maximum possible nbr of XX_Freq */ /* REF8765 - YST - 030129 */

    if (byFreqAllocSz == 0)
    {   FREE(crystalDates);
        return(RET_SUCCEED); /* ? */
    }

    /* Allocate pointer array */
	if ((byFreqTab = (DBA_DYNFLD_STP *)
		       CALLOC(byFreqAllocSz, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	{
        FREE(crystalDates);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if (listCompoNbr > 0)
    {

		/* REF7318 - LJE - 020122 : BEGIN */
		if(funcSort != NULL)
		{
			/* Compute the dates before and after the range of crystal date */
			DATE_CrystalDateOutRange(crystalDates[0],
									 freq,
									 freqUnit,
									 crystalNbr,
									 EndOf,
									 &crystalDateBefore,
									 &crystalDateAfter);

			while(i < listCompoNbr && /* REF4306 - CSY - 000315 */
                (DATETIME_CMP(GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
                    crystalDateAfter) > 0))
                i++;

			last = i;
		}

        /* advance in periods from the last one to the first one */
		/* REF9582 - RAK - 031105 */
		if (fctDictId == DictFct_PtfStorage)
			firstCrystDate = 1;
		else
			firstCrystDate = 0;

        for(f = (tmpCrystalNbr/*crystalNbr*/-1); f>=/*0*/firstCrystDate; f--)     /* REF8765 - YST - 030129 */
        {
            while(i < listCompoNbr && /* REF4306 - CSY - 000315 */
                (DATETIME_CMP(GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
                    crystalDates[f]) > 0))
                i++;
            first = i;
            byFreqNbr1 = byFreqNbr;

            while(i < listCompoNbr &&
                DATETIME_CMP(
                    GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
                    GET_DATETIME(extractListCompoTab[first], A_ListCompo_ValidDt)) == 0)
            {

				/* REF7318 - LJE - 020122 : If it is an input "empty list", it should be checked that it is
				 * the only input on this date.
				 */
				if ( IS_NULLFLD(extractListCompoTab[i], A_ListCompo_ObjId) == TRUE
				  && ( i != first
				    || ( i+1 < listCompoNbr
				      && DATETIME_CMP(
					        GET_DATETIME(extractListCompoTab[i+1], A_ListCompo_ValidDt),
                            GET_DATETIME(extractListCompoTab[first], A_ListCompo_ValidDt)) == 0))
				   )
				{
					i++;
					continue;
				}


                if (byFreqNbr == byFreqAllocSz)
                {
                    byFreqAllocSz += 10;
                    if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
                           (byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
                    {
                        FREE(crystalDates);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                }



                /* build the A_Ptf_Freq for children portfolio
                if load_hierarchy_flag has been set to true */
                if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
                    dimPtfObjectEnum == Ptf)
                {

                    /* check if a A_PtfFreq with same Ptf id already exists */
                    existFlg = FALSE;
                    for (k = byFreqNbr1; k < byFreqNbr; k++)
                    {
                        if (CMP_DYNFLD(
                                extractListCompoTab[i],
                                byFreqTab[k],
                                srcIdFld,
                                A_PtfFreq_PtfId,
                                IdType) == 0)
                        {
                            existFlg = TRUE;
                            break;
                        }
                    }

                    if(existFlg == FALSE)
                    {
                        /* check memory and realloc if necessary */
                        if (byFreqNbr == byFreqAllocSz)
                        {
                            byFreqAllocSz += 10;
                            if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
                                   (byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
                            {
                                FREE(crystalDates);
                                MSG_RETURN(RET_MEM_ERR_ALLOC);
                            }
                        }

                        /* create A_xx_freq and put it in the array byFreqTab */
                        aXFreq = ALLOC_DYNST(outDynStEnum);
                        COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
                                    extractListCompoTab[i], A_ListCompo, srcIdFld);

						/* REF8765 - YST - 030129 */
						/* REF9582 - RAK - 031105 - initial date is date just before */
                        if (fctDictId == DictFct_PtfStorage)
                            SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f-1]);

						/* REF9582 - RAK - 031105 - freqIdx is now 0 for ptf storage on merged list like composite manager */
                        SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f+freqIdx]); /* REF8749.4001 - YST - 030124 */

						byFreqTab[byFreqNbr] = aXFreq;
                        byFreqNbr++;

                        /* set the index key */
                        SET_ID((&ptfIdDynSt), 0, GET_ID(extractListCompoTab[i], A_ListCompo_ObjId));
                        /* extract from hierarchy the portfolio which id is the current list compo object_id */
                        if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_Ptf, A_Ptf_Id,
                                                                   ptfIdDynSt, FALSE, NULL, NULLDYNST, NULL, FALSE,
                                                                   &ptfNbr, &ptfTab)) != RET_SUCCEED)
	                    {
                            FREE(ptfTab);
                            FREE(byFreqTab);
                            FREE(crystalDates);
		                    return(ret);
	                    }

                        if (ptfNbr > 0)
                        {
                            aPtfSt = ptfTab[0];

                            /* is it a father portfolio ? */
                            childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(
                                                                    aPtfSt, A_Ptf_ChildrenPtf_Ext);
                            if (childrenPtfTab !=  NULLDYNSTPTR)
                            {
                                /* create a A_PtfFreq for each child */
                                for (j = 0; j<GET_EXTENSION_NBR(aPtfSt, A_Ptf_ChildrenPtf_Ext); j++)
                                {
                                    /* reset to FALSE  before checking each child */
                                    existFlg = FALSE;

                                    /* check if a A_PtfFreq with same Ptf id as the child already exists */
                                    for (k = byFreqNbr1; k < byFreqNbr; k++)
                                    {
                                        if (CMP_DYNFLD(
                                                childrenPtfTab[j],
                                                byFreqTab[k],
                                                A_Ptf_Id,
                                                A_PtfFreq_PtfId,
                                                IdType) == 0)
                                        {
                                            existFlg = TRUE;
                                            break;
                                        }
                                    }

                                    /* if doesn't exist, create a new A_PtfFreq from
                                       the A_Ptf child portfolio and put it in the array */
                                    if (existFlg == FALSE)
                                    {
                                        /* check memory and realloc if necessary */
                                        if (byFreqNbr == byFreqAllocSz)
                                        {
                                            byFreqAllocSz += 10;
                                            if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
                                                   (byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
                                            {
                                                FREE(crystalDates);
                                                MSG_RETURN(RET_MEM_ERR_ALLOC);
                                            }
                                        }

                                        /* create the XFreq */
                                        aXFreq = ALLOC_DYNST(outDynStEnum);
                                        COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
                                            childrenPtfTab[j], A_Ptf, A_Ptf_Id);

                                        /* REF8765 - YST - 030129 */
										/* REF9582 - RAK - 031105 - initial date is date just before */
                                        if (fctDictId == DictFct_PtfStorage)
                                            SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f-1]);

										/* REF9582 - RAK - 031105 - freqIdx is now 0 for ptf storage on merged list like composite manager */
                                        SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f+freqIdx]); /* REF8749.4001 - YST - 030124 */

                                        byFreqTab[byFreqNbr] = aXFreq;
                                        byFreqNbr++;
                                    }
                                }
                            }
                        }

                        FREE(ptfTab);
                    }
                }
                else
                {
                    /* create A_xx_freq and put it in the array byFreqTab */
                    aXFreq = ALLOC_DYNST(outDynStEnum);
                    COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
                        extractListCompoTab[i], A_ListCompo, srcIdFld);

					/* REF8756 - YST - 030325 - reeng. */
					/* REF9582 - RAK - 031105 - initial date is date just before */
                    if (/* fctDictId == DictFct_PtfStorage ||*/ fctDictId == DictFct_BenchStorage)
                        SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f]);

					if (fctDictId == DictFct_PtfStorage)
                        SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f-1]);

					/* REF9582 - RAK - 031105 - freqIdx is now 0 for ptf storage on merged list like composite manager */
					SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f+freqIdx]); /* REF8749.4001 - YST - 030124 */

					/* REF10741 - RAK - 041104 - PSPId only used for BenchStorage function */
					if (fctDictId == DictFct_BenchStorage)
					{
						if (pspPtr != NULL) /* REF9171 - LJE - 030930 */
						{
							SET_ID(aXFreq, destPSPId, GET_ID(pspPtr, A_PerfStorageParam_Id)); /*REF9125 MCA  0030904*/
						}
						else
						{
							SET_NULL_ID(aXFreq, destPSPId);
						}
					}

                    byFreqTab[byFreqNbr] = aXFreq;
                    byFreqNbr++;
                }

                i++;
            }

            i = first;
        }
    }
    else    /* listCompoNbr == 0 */
    {
        /* the multiselect doesn't put ListCompo with NULL validity date in hierarchy,
        so when HistListFlg is set to FALSE, ListCompos with validity date null are retrieved from
        DB by multiselect and corresponding entities (A_Ptf, A_Instr, A_ Curr, A_Third)are
        created in hierarchy but not the A_ListCompo.
        That's why listCompoNbr == 0 when HistListFlg = FALSE */
        /* REF8765 - YST - 030129 - code reeng. */
		if 	(fctDictId == DictFct_BenchStorage)
		{
			/* extract the A_X, (X = Instr) */
			if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
														 srcDynStEnum,
														 FALSE,
														 filterFct,
														 domainPtr,
														 NULLFCT,
														 &extractNbr,
														 &extractTab)) != RET_SUCCEED)

			{
				FREE(crystalDates);
				FREE(extractTab);
				FREE(byFreqTab);
				return(ret);
			}
        }
        else
        {
            /* extract the A_X, (X = Ptf, Instr, Curr, Third) */
            if ((ret = DBA_ExtractHierEltRec(hierHead, srcDynStEnum, FALSE,
	                        NULLFCT, NULLFCT, &extractNbr,  &extractTab)) != RET_SUCCEED)
            {
	            FREE(crystalDates);
	            FREE(extractTab);
	            FREE(byFreqTab);
	            return(ret);
            }
        }

		/* advance in periods from the last one to the first one */
		/* REF10741 - RAK - 041110 */
		if (fctDictId == DictFct_PtfStorage)
			firstCrystDate = 1;
		else
			firstCrystDate = 0;

        for (f = (tmpCrystalNbr/*crystalNbr*/-1); f>=/*0*/firstCrystDate; f--)     /* REF8765 - YST - 030129 */
        {
	        /* for each extracted A_X, build a A_XFreq and put it  A_X, (X = Ptf, Instr, Curr, Third)
	        in the array byFreqTab */
	        for (i=0; i<extractNbr; i++)
	        {
		        aXFreq = ALLOC_DYNST(outDynStEnum);
		        COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
					        extractTab[i], srcDynStEnum, srcIdFld);

				/* REF8756 - YST - 030129 - reeng. */
				/* REF10741 - RAK - 041110 - initial date is date just before */
                if (/* fctDictId == DictFct_PtfStorage ||*/ fctDictId == DictFct_BenchStorage)
					SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f]);

				if (fctDictId == DictFct_PtfStorage)
					SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f-1]);

				/* REF10741 - RAK - 041110 - freqIdx is now 0 for ptf storage on merged list like composite manager */
				SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f+freqIdx]); /* REF8749.4001 - YST - 030124 */

				/* REF10741 - RAK - 041104 - PSPId only used for BenchStorage function */
				if (fctDictId == DictFct_BenchStorage)
				{
					if (pspPtr != NULL)  /* REF9171 - LJE - 030930 */
					{
						SET_ID(aXFreq, destPSPId, GET_ID(pspPtr, A_PerfStorageParam_Id)); /*REF9125 MCA  0030904*/
					}
					else
					{
						SET_NULL_ID(aXFreq, destPSPId);
					}
				}

				byFreqTab[byFreqNbr] = aXFreq;
		        byFreqNbr++;
            }
        }
    }

    FREE(extractTab);

	/* REF7318 - LJE - 020506 : Init default statut freq */
	if ( dimPtfObjectEnum == Ptf )
	{
		for(i=0; i<byFreqNbr; i++)
		{
			SET_ENUM(byFreqTab[i], A_PtfFreq_PtfStatus, PtfFreqStatus_Remaining);
		}
	}

    DBA_AddHierRecordList(hierHead, byFreqTab, byFreqNbr,
                              outDynStEnum, FALSE);

    /* set links used */
    ret = DBA_SetHierLnkUsed(hierHead,
                        outDynStEnum,
                        destLinkFld);

    if (ret != RET_SUCCEED)
    {
        FREE(byFreqTab);
        FREE(crystalDates);
        return(ret);
    }

    /* make links */
    DBA_MakeLinks(hierHead);

    FREE(byFreqTab);

	/* REF7318 - LJE - 020122 : BEGIN */
	if(funcSort != NULL && listCompoNbr > 0)
	{

		/* Extract the frequency */
		if ((ret = DBA_ExtractHierEltRec(hierHead, outDynStEnum, FALSE,
										 NULLFCT, funcSort,
										 &byFreqNbr,  &byFreqTab)) != RET_SUCCEED)
		{
  		    FREE(byFreqTab);
			FREE(crystalDates);
			return(ret);
		}

		/* If the date of the first list compo is before the first crystal date, all ptf are present before the start */
		if (DATETIME_CMP(GET_DATETIME(extractListCompoTab[0], A_ListCompo_ValidDt), crystalDateBefore) > 0)
		{
			beforeOk = FALSE;
		}
		else
		{
			beforeOk = TRUE;
		}

		oldId      = 0;
		oldNullFlg = FALSE;

		for(i=0; i<byFreqNbr; i++)
		{
			currId      = GET_ID(byFreqTab[i],destIdFld);
			currNullFlg = (FLAG_T)IS_NULLFLD(byFreqTab[i],destIdFld);

			if(oldId != currId || oldNullFlg != currNullFlg )
			{
				/* Search the postition in crystal date */
				crystalPos = 0;
			}

			/* Search the postition in crystal date */
			for(; crystalPos < crystalNbr
			   && DATETIME_CMP(GET_DATETIME(byFreqTab[i],destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos])!=0 /* REF8749.4001 - YST - 030124 */
				; crystalPos++);

			/* Search if this object is present before the current crystal date */
			if ( ( ( oldId != currId || oldNullFlg != currNullFlg )		    /* Test before the first element */
				&& crystalPos == firstCrystDate /* REF9582 - RAK - 031106 */
			    && ( beforeOk == TRUE ||
				     FIN_IsInListCompoAtDate(domainPtr,
											 hierHead,
											 GET_ID(domainPtr, A_Domain_InstrObjId),
											 GET_DICT(domainPtr, A_Domain_DimInstrDictId),
											 byFreqTab[i],
											 destIdFld,
											 &crystalDateBefore,
											 &listCompoBeforePtr,
											 &listCompoBeforeNbr,
											 NO_VALUE,
											 UNUSED) == TRUE) )
			  || ( oldId == currId          /* Test with the previous element */
			    && oldNullFlg == currNullFlg
			    && DATETIME_CMP(GET_DATETIME(byFreqTab[i-1],destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos-1])==0)) /* REF8749.4001 - YST - 030124 */
				before = TRUE;
			else
				before = FALSE;

			/* Search if this object is present after the current crystal date */
			if( ( ( i+1 >= byFreqNbr
				 || currId != GET_ID(byFreqTab[i+1],destIdFld) ) /* Test after the last element */
			   && (DATETIME_CMP(GET_DATETIME(byFreqTab[i],destFreqDateFld /*destFinalFld*/), crystalDates[crystalNbr-1])==0) /* REF8749.4001 - YST - 030124 */
			   && (FIN_IsInListCompoAtDate(domainPtr,
				                           hierHead,
										   GET_ID(domainPtr, A_Domain_InstrObjId),
										   GET_DICT(domainPtr, A_Domain_DimInstrDictId),
										   byFreqTab[i],
										   destIdFld,
										   &crystalDateAfter,
										   &listCompoAfterPtr,
										   &listCompoAfterNbr,
										   NO_VALUE,
										   UNUSED) == TRUE))
			  ||( i+1 < byFreqNbr           /* Test with the next element */
			   && currId == GET_ID(byFreqTab[i+1],destIdFld)
			   && DATETIME_CMP(GET_DATETIME(byFreqTab[i+1],destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos+1])==0)) /* REF8749.4001 - YST - 030124 */
				after = TRUE;
			else
				after = FALSE;

			if(before == TRUE)
				if(after==TRUE)
					ptfFreqStatus = PtfFreqStatus_Remaining;
				else
					ptfFreqStatus = PtfFreqStatus_Exiting;
			else
				if(after==TRUE)
					ptfFreqStatus = PtfFreqStatus_Entering;
				else
					ptfFreqStatus = PtfFreqStatus_Transiting;


			SET_ENUM(byFreqTab[i], A_PtfFreq_PtfStatus, ptfFreqStatus);

			DBA_UpdHierEltRec(hierHead, outDynStEnum, byFreqTab[i]);

			oldId = currId;
			oldNullFlg = currNullFlg;
		}

		if (beforeOk == FALSE)
		    DBA_FreeDynStTab(listCompoBeforePtr, listCompoBeforeNbr, S_ListCompo);

	    DBA_FreeDynStTab(listCompoAfterPtr, listCompoAfterNbr, S_ListCompo);

	}
	/* REF7318 - LJE - 020122 : END */


	FREE(extractListCompoTab); /* REF7318 - LJE - 020122 : Move here */
    FREE(crystalDates);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AnalysisDisplayComplianceChrono()
**
**  Description :   Compute compliance chronological datas for portfolios or list of portfolios
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA18759 - CHU - 150401
**
*************************************************************************/
RET_CODE FIN_AnalysisDisplayComplianceChrono(DBA_DYNFLD_STP	   domainPtr,
											 DBA_HIER_HEAD_STP hierHead,
											 DBA_DYNFLD_STP	   pspPtr)
{

	/*  < PMSTA-22458 - cashwini - 160502 */
	RET_CODE		ret;
	DBA_DYNFLD_STP	*extractListCompoTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP	*extractListCompChronoTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP	*extractListCompChronoTab1 = NULLDYNSTPTR;
	DBA_DYNFLD_STP	*extractTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP	*childrenPtfTab = NULLDYNSTPTR;
	DATETIME_T		fromDate, tillDate, *crystalDates = nullptr;
	TINYINT_T		freq = 0;
	FREQUNIT_ENUM	freqUnit;
	FLAG_T			existFlg = FALSE;
	int				listCompoNbr = 0, listCompChronoNbr = 0, listCompChronoNbr1 = 0, listCompChronoNbr2 = 0;
	int				crystalNbr;
	int				i = 0;
	int				j = 0;
	int				k = 0;
	int				f = 0;
	int             s = 0, y = 0, t1 = 0, t2 = 0;
	int				first = 0;
	int				last = 0;
	int				byFreqAllocSz = 0;
	int				extractNbr = 0;
	int				byFreqNbr = 0;
	int				byFreqNbr1 = 0;
	DBA_DYNST_ENUM  srcHierElt_2do = 0;
	int				srcIdFld = 0, srcIdFld1 = 0, srcIdFld2 = 0, srcIdFld3 = 0, srcIdFld4 = 0, srcIdFld5 = 0;
	int				srcIdFld6 = 0, srcIdFld7 = 0, srcIdFld8 = 0, srcIdFld9 = 0, srcIdFld10 = 0, srcIdFld11 = 0, srcIdFld12 = 0;
	int				destIdFld = 0, destIdFld1 = 0, destIdFld2 = 0, destIdFld3 = 0, destIdFld4 = 0, destIdFld5 = 0;
	int				destIdFld6 = 0, destIdFld7 = 0, destIdFld8 = 0, destIdFld9 = 0, destIdFld10 = 0, destIdFld11 = 0, destIdFld12 = 0;
	int				destInitDateFld = 0, destFreqDateFld = 0;
	int				destLinkFld = 0;
	int				ptfNbr = 0;
	int				tmpCrystalNbr = 0, freqIdx = 0;
	int				firstCrystDate = 0;
	OBJECT_ENUM     dimPtfObjectEnum;
	DBA_DYNST_ENUM  outDynStEnum = NullDynSt;
	DBA_DYNST_ENUM  srcDynStEnum = NullDynSt;

	DBA_DYNFLD_STP	aXFreq = NULLDYNST;
	DBA_DYNFLD_STP  *byFreqTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP  *ptfTab = NULLDYNSTPTR;
	DBA_DYNFLD_ST   ptfIdDynSt;
	DBA_DYNFLD_STP  aPtfSt = NULLDYNST;
	DBA_DYNFLD_STP  noChronoPtr = NULLDYNST;

	PTFFREQSTATUS_ENUM ptfFreqStatus = PtfFreqStatus_Null;
	int               crystalPos = 0;
	ID_T              oldId = 0, currId = 0;
	FLAG_T            oldNullFlg = TRUE, currNullFlg = TRUE;
	FLAG_T            before, after, beforeOk;
	int(*funcSort)(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *) = NULL;
	DATETIME_T        crystalDateBefore, crystalDateAfter;
	DBA_DYNFLD_STP    *listCompoBeforePtr = NULLDYNSTPTR,
		*listCompoAfterPtr = NULLDYNSTPTR;
	DBA_DYNFLD_STP  *complChronoTab = NULLDYNSTPTR;
	int             complChronoNbr = 0, complChronoNbr1 = 0, complChronoNbr2 = 0;
	int               listCompoBeforeNbr = 0, listCompoAfterNbr = 0;
	DICT_T			  fctDictId = 0;

	memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST));

	fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	crystalDateBefore = fromDate;
	crystalDateAfter = tillDate;

	/*** FREQUENCY ***/
	/* Read frequency in domain  */
	freqUnit = (FREQUNIT_ENUM)GET_ENUM(domainPtr, A_Domain_Freq1UnitEn);

	if (DATETIME_CMP(fromDate, tillDate) == 0 && freqUnit >= FreqUnit_Month)
		freqUnit = FreqUnit_Day; /* because tests are done on
								 end of month in DATE_CrystalDates function for frequncies >= FreqUnit_Month */

	if (IS_NULLFLD(domainPtr, A_Domain_Freq1) == FALSE)
	{
		freq = GET_TINYINT(domainPtr, A_Domain_Freq1);
		if (freq == 0)
			freq = 1;
	}
	else
	{
		freq = 1;
	}

	/*** DATES CRYSTALLISATION ***/
	/* Determines according to begin and end date, the  */
	/* dates upon which the positions need to be valued */
	ret = DATE_CrystalDates(fromDate, tillDate, freq, freqUnit, FALSE,
		&crystalDates, &crystalNbr, NULL, NULL, (DATE_POSI_ENUM)EndOf, /* REF5358 - CSY - 010131: new arg EndOf */
		nullptr, nullptr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		FREE(crystalDates);
		return(ret);
	}

	fctDictId = GET_DICT(domainPtr, A_Domain_FctDictId);
	if (fctDictId == DictFct_DisplayComplianceChrono)
	{		/* extract ListCompos using sort by descending dates */
		if ((ret = DBA_ExtractHierEltRec(hierHead, A_ListCompo, FALSE,
			NULLFCT, FIN_CmpListCompoByDescDate,
			&listCompoNbr, &extractListCompoTab)) != RET_SUCCEED)
		{
			FREE(extractListCompoTab);
			FREE(crystalDates);
			return(ret);
		}
	}
	/* last param set to TRUE for optimisation */
	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfObjectEnum); /* DLA - REF9089 - 030512 */
	if (dimPtfObjectEnum == List ||
		dimPtfObjectEnum == QuickSearch ||
		dimPtfObjectEnum == NullEntity)
	{
		DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &dimPtfObjectEnum); /* DLA - REF9089 - 030512 */
		if (listCompoNbr > 0)
		{
			srcHierElt_2do = A_ListCompo;
			srcIdFld = A_ListCompo_ObjId;
		}
	}

	switch (GET_OBJECT_CST(dimPtfObjectEnum))
	{
	case PtfCst:
	case StratCst:
		if (listCompoNbr == 0)
		{
			srcHierElt_2do = A_ComplianceChrono;
			srcIdFld = A_ComplianceChrono_PtfId;
			srcIdFld1 = A_ComplianceChrono_StratId;
			srcIdFld2 = A_ComplianceChrono_NatEn;
			srcIdFld3 = A_ComplianceChrono_CompNatEn;
			srcIdFld4 = A_ComplianceChrono_SubNatTypeId;
			srcIdFld5 = A_ComplianceChrono_ThirdPartyId;
			srcIdFld6 = A_ComplianceChrono_Val;
			srcIdFld7 = A_ComplianceChrono_CurrId;
			srcIdFld8 = A_ComplianceChrono_Comment;
			srcIdFld9 = A_ComplianceChrono_CriticalnessEn;
			srcIdFld10 = A_ComplianceChrono_ConfidenceLevel;
			srcIdFld11 = A_ComplianceChrono_TimeHorizon;
			srcIdFld12 = A_ComplianceChrono_TimeHorizonUnitEn;

		}
		destIdFld = A_ComplianceChronoFreq_PtfId;
		destIdFld1 = A_ComplianceChronoFreq_StratId;
		destIdFld2 = A_ComplianceChronoFreq_NatEn;
		destIdFld3 = A_ComplianceChronoFreq_CompNatEn;
		destIdFld4 = A_ComplianceChronoFreq_SubNatTypeId;
		destIdFld5 = A_ComplianceChronoFreq_ThirdPartyId;
		destIdFld6 = A_ComplianceChronoFreq_Val;
		destIdFld7 = A_ComplianceChronoFreq_CurrId;
		destIdFld8 = A_ComplianceChronoFreq_Comment;
		destIdFld9 = A_ComplianceChronoFreq_CriticalnessEn;
		destIdFld10 = A_ComplianceChronoFreq_ConfidenceLevel;
		destIdFld11 = A_ComplianceChronoFreq_TimeHorizon;
		destIdFld12 = A_ComplianceChronoFreq_TimeHorizonUnitEn;

		destFreqDateFld = A_ComplianceChronoFreq_FreqDate;

		outDynStEnum = A_ComplianceChronoFreq;
		srcDynStEnum = A_ComplianceChrono;
		destLinkFld = A_ComplianceChronoFreq_A_Compl_Ext;
		break;
	}

	/* if extractNbr > 0, will find the number of A_ListCompo in hierarchy. Otherwise, will
	find the number of A_Ptf (or A_Instr, A_Curr, A_Third) in hierarchy */
	/* REF8765 - YST - 030129 - code reeng., open question: do we have listCompo for Bench Storage? */

	ret = DBA_HierGetRecNbr(hierHead, srcHierElt_2do, NULLFCT, &extractNbr, TRUE);

	if (ret != RET_SUCCEED)
	{
		FREE(crystalDates);
		return(ret);
	}

	/* compute temporary crystalNbr and freqIdx */
	tmpCrystalNbr = crystalNbr;

	byFreqAllocSz = extractNbr * tmpCrystalNbr /*crystalNbr*/; /* maximum possible nbr of XX_Freq */

	if (byFreqAllocSz == 0)
	{
		FREE(crystalDates);
		if (extractNbr == 0)
		{
			if ((noChronoPtr = ALLOC_DYNST(A_ComplianceChronoFreq)) == NULLDYNST)
			{
				return(RET_MEM_ERR_ALLOC);
			}

			DBA_AddHierRecord(hierHead
				, noChronoPtr
				, A_ComplianceChronoFreq
				, FALSE
				, HierAddRec_NoLnk);
		}
		return(RET_SUCCEED);
	}

	/* Allocate pointer array */
	if ((byFreqTab = (DBA_DYNFLD_STP *)
		CALLOC(byFreqAllocSz, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	{
		FREE(crystalDates);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if (listCompoNbr > 0)
	{

		if (funcSort != NULL)
		{
			/* Compute the dates before and after the range of crystal date */
			DATE_CrystalDateOutRange(crystalDates[0],
				freq,
				freqUnit,
				crystalNbr,
				EndOf,
				&crystalDateBefore,
				&crystalDateAfter);

			while (i < listCompoNbr &&
				(DATETIME_CMP(GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
				crystalDateAfter) > 0))
				i++;

			last = i;
		}

		for (f = (tmpCrystalNbr/*crystalNbr*/ - 1); f >=/*0*/firstCrystDate; f--)
		{
			while (i < listCompoNbr &&
				(DATETIME_CMP(GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
				crystalDates[f]) > 0))
				i++;
			first = i;
			byFreqNbr1 = byFreqNbr;

			while (i < listCompoNbr &&
				DATETIME_CMP(
				GET_DATETIME(extractListCompoTab[i], A_ListCompo_ValidDt),
				GET_DATETIME(extractListCompoTab[first], A_ListCompo_ValidDt)) == 0)
			{

				/* If it is an input "empty list", it should be checked that it is
				* the only input on this date.
				*/
				if (IS_NULLFLD(extractListCompoTab[i], A_ListCompo_ObjId) == TRUE
					&& (i != first
					|| (i + 1 < listCompoNbr
					&& DATETIME_CMP(
					GET_DATETIME(extractListCompoTab[i + 1], A_ListCompo_ValidDt),
					GET_DATETIME(extractListCompoTab[first], A_ListCompo_ValidDt)) == 0))
					)
				{
					i++;
					continue;
				}


				if (byFreqNbr == byFreqAllocSz)
				{
					byFreqAllocSz += 10;
					if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
						(byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
					{
						FREE(crystalDates);
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}
				}



				/* build the A_Ptf_Freq for children portfolio
				if load_hierarchy_flag has been set to true */
				if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
					dimPtfObjectEnum == Ptf)
				{

					/* check if a A_PtfFreq with same Ptf id already exists */
					existFlg = FALSE;
					for (k = byFreqNbr1; k < byFreqNbr; k++)
					{
						if (CMP_DYNFLD(
							extractListCompoTab[i],
							byFreqTab[k],
							srcIdFld,
							A_PtfFreq_PtfId,
							IdType) == 0)
						{
							existFlg = TRUE;
							break;
						}
					}

					if (existFlg == FALSE)
					{
						/* check memory and realloc if necessary */
						if (byFreqNbr == byFreqAllocSz)
						{
							byFreqAllocSz += 10;
							if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
								(byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
							{
								FREE(crystalDates);
								MSG_RETURN(RET_MEM_ERR_ALLOC);
							}
						}

						/* create A_xx_freq and put it in the array byFreqTab */
						aXFreq = ALLOC_DYNST(outDynStEnum);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
							extractListCompoTab[i], A_ListCompo, srcIdFld);

						/* initial date is date just before */
						if (fctDictId == DictFct_PtfStorage)
							SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f - 1]);

						SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f + freqIdx]);

						byFreqTab[byFreqNbr] = aXFreq;
						byFreqNbr++;

						/* set the index key */
						SET_ID((&ptfIdDynSt), 0, GET_ID(extractListCompoTab[i], A_ListCompo_ObjId));
						/* extract from hierarchy the portfolio which id is the current list compo object_id */
						if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_Ptf, A_Ptf_Id,
							ptfIdDynSt, FALSE, NULL, NULLDYNST, NULL, FALSE,
							&ptfNbr, &ptfTab)) != RET_SUCCEED)
						{
							FREE(ptfTab);
							FREE(byFreqTab);
							FREE(crystalDates);
							return(ret);
						}

						if (ptfNbr > 0)
						{
							aPtfSt = ptfTab[0];

							childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(
								aPtfSt, A_Ptf_ChildrenPtf_Ext);
							if (childrenPtfTab != NULLDYNSTPTR)
							{
								/* create a A_PtfFreq for each child */
								for (j = 0; j<GET_EXTENSION_NBR(aPtfSt, A_Ptf_ChildrenPtf_Ext); j++)
								{
									/* reset to FALSE  before checking each child */
									existFlg = FALSE;

									/* check if a A_PtfFreq with same Ptf id as the child already exists */
									for (k = byFreqNbr1; k < byFreqNbr; k++)
									{
										if (CMP_DYNFLD(
											childrenPtfTab[j],
											byFreqTab[k],
											A_Ptf_Id,
											A_PtfFreq_PtfId,
											IdType) == 0)
										{
											existFlg = TRUE;
											break;
										}
									}

									/* if doesn't exist, create a new A_PtfFreq from
									the A_Ptf child portfolio and put it in the array */
									if (existFlg == FALSE)
									{
										/* check memory and realloc if necessary */
										if (byFreqNbr == byFreqAllocSz)
										{
											byFreqAllocSz += 10;
											if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
												(byFreqAllocSz*sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
											{
												FREE(crystalDates);
												MSG_RETURN(RET_MEM_ERR_ALLOC);
											}
										}

										/* create the XFreq */
										aXFreq = ALLOC_DYNST(outDynStEnum);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
											childrenPtfTab[j], A_Ptf, A_Ptf_Id);

										if (fctDictId == DictFct_PtfStorage)
											SET_DATETIME(aXFreq, destInitDateFld, crystalDates[f - 1]);

										/* freqIdx is now 0 for ptf storage on merged list like composite manager */
										SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f + freqIdx]);

										byFreqTab[byFreqNbr] = aXFreq;
										byFreqNbr++;
									}
								}
							}
						}

						FREE(ptfTab);
					}
				}
				else
				{
					/* create A_xx_freq and put it in the array byFreqTab */
					aXFreq = ALLOC_DYNST(outDynStEnum);

					if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
						A_ComplianceChrono,
						FALSE,
						FIN_CmpPtfId,
						extractListCompoTab[i],
						NULL,
						&listCompChronoNbr1,
						&extractListCompChronoTab1)) != RET_SUCCEED)
					{
						FREE(ptfTab);
						FREE(byFreqTab);
						return(ret);
					}

					if (listCompChronoNbr1 > 0)
					{
						if ((byFreqTab = (DBA_DYNFLD_STP*)REALLOC(byFreqTab,
							(8000 * sizeof(DBA_DYNFLD_STP*)))) == (DBA_DYNFLD_STP*)NULL)
						{
							FREE(crystalDates);
							//	MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

						for (int z1 = 0; z1 < listCompChronoNbr1; z1++)
						{
							if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
								A_ComplianceChrono,
								FALSE,
								DBA_FilterNatureComplChrono1,
								extractListCompChronoTab1[z1],
								DBA_CmpChronoValidDate,
								&listCompChronoNbr,
								&extractListCompChronoTab)) != RET_SUCCEED)
							{
								FREE(crystalDates);
								FREE(extractTab);
								FREE(byFreqTab);
								return(ret);
							}
							listCompChronoNbr2 = listCompChronoNbr * tmpCrystalNbr;

							complChronoNbr2 = listCompChronoNbr;
							for (int s1 = 0; s1 < listCompChronoNbr; s1++)
							{
								if (DATETIME_CMP(
									GET_DATETIME(extractListCompChronoTab[s1], A_ComplianceChrono_ValidDate),
									crystalDates[f + freqIdx]) > 0)
								{
									complChronoNbr2--;

								}
							}

							if (complChronoNbr2 > 0)
							{
								for (int s2 = 0; s2 < complChronoNbr2; s2++)
								{
									if (DATETIME_CMP(
										GET_DATETIME(extractListCompChronoTab[s2], A_ComplianceChrono_ValidDate),
										crystalDates[f + freqIdx]) <= 0)
									{
										aXFreq = ALLOC_DYNST(outDynStEnum);
										srcIdFld = A_ComplianceChrono_PtfId;
										srcIdFld1 = A_ComplianceChrono_StratId;
										srcIdFld2 = A_ComplianceChrono_NatEn;
										srcIdFld3 = A_ComplianceChrono_CompNatEn;
										srcIdFld4 = A_ComplianceChrono_SubNatTypeId;
										srcIdFld5 = A_ComplianceChrono_ThirdPartyId;
										srcIdFld6 = A_ComplianceChrono_Val;
										srcIdFld7 = A_ComplianceChrono_CurrId;
										srcIdFld8 = A_ComplianceChrono_Comment;
										srcIdFld9 = A_ComplianceChrono_CriticalnessEn;
										srcIdFld10 = A_ComplianceChrono_ConfidenceLevel;
										srcIdFld11 = A_ComplianceChrono_TimeHorizon;
										srcIdFld12 = A_ComplianceChrono_TimeHorizonUnitEn;
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld1,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld1);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld2,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld2);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld3,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld3);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld4,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld4);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld5,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld5);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld6,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld6);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld7,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld7);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld8,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld8);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld9,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld9);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld10,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld10);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld11,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld11);
										COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld12,
											extractListCompChronoTab[complChronoNbr2 - 1], srcDynStEnum, srcIdFld12);
									}
								}
								SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f + freqIdx]);
								byFreqTab[byFreqNbr] = aXFreq;
								byFreqNbr++;
							}
						}
					}
					else
					{

						srcIdFld = A_ListCompo_ObjId;
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
							extractListCompoTab[i], A_ListCompo, srcIdFld);
						SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f + freqIdx]);

						byFreqTab[byFreqNbr] = aXFreq;
						byFreqNbr++;

					}
				}

				i++;
			}

			i = first;
		}
	}
	else    /* listCompoNbr == 0 */
	{
		/* the multiselect doesn't put ListCompo with NULL validity date in hierarchy,
		so when HistListFlg is set to FALSE, ListCompos with validity date null are retrieved from
		DB by multiselect and corresponding entities (A_Ptf, A_Instr, A_ Curr, A_Third)are
		created in hierarchy but not the A_ListCompo.
		That's why listCompoNbr == 0 when HistListFlg = FALSE */
		/* REF8765 - YST - 030129 - code reeng. */
		/* extract the A_X, (X = Ptf, Instr, Curr, Third) */
			if ((ret = DBA_ExtractHierEltRec(hierHead, srcHierElt_2do, FALSE,
				NULLFCT, NULLFCT, &extractNbr, &extractTab)) != RET_SUCCEED)
			{
				FREE(crystalDates);
				FREE(extractTab);
				FREE(byFreqTab);
				return(ret);
			}


		for (f = (tmpCrystalNbr/*crystalNbr*/ - 1); f >=/*0*/firstCrystDate; f--)
		{
			/* for each extracted A_X, build a A_XFreq and put it  A_X, (X = Ptf, Instr, Curr, Third)
			in the array byFreqTab */

			for (i = 0; i < extractNbr; i++)
			{
				if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
					A_ComplianceChrono,
					FALSE,
					DBA_FilterNatureComplChrono1,
					extractTab[i],
					DBA_CmpChronoValidDate,
					&complChronoNbr1,
					&complChronoTab)) != RET_SUCCEED)
				{
					FREE(complChronoTab);
					FREE(crystalDates);
					FREE(extractTab);
					FREE(byFreqTab);
					return(ret);
				}

				complChronoNbr = complChronoNbr1;
				for (s = 0; s < complChronoNbr1; s++)
				{
					if (DATETIME_CMP(
						GET_DATETIME(complChronoTab[s], A_ComplianceChrono_ValidDate),
						crystalDates[f + freqIdx]) > 0)
					{
						complChronoNbr--;

					}
				}

				if (complChronoNbr > 0)
				{
					if (DATETIME_CMP(
						GET_DATETIME(complChronoTab[y], A_ComplianceChrono_ValidDate),
						crystalDates[f + freqIdx]) <= 0)
					{
						aXFreq = ALLOC_DYNST(outDynStEnum);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld1,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld1);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld2,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld2);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld3,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld3);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld4,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld4);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld5,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld5);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld6,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld6);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld7,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld7);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld8,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld8);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld9,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld9);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld10,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld10);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld11,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld11);
						COPY_DYNFLD(aXFreq, outDynStEnum, destIdFld12,
							complChronoTab[complChronoNbr - 1], srcDynStEnum, srcIdFld12);
					}
					SET_DATETIME(aXFreq, destFreqDateFld /*destFinalFld*/, crystalDates[f + freqIdx]);
					byFreqTab[byFreqNbr] = aXFreq;
					byFreqNbr++;
				}
			}
		}
	}

	FREE(extractTab);
	FREE(complChronoTab);

	DBA_AddHierRecordList(hierHead, byFreqTab, byFreqNbr, outDynStEnum, FALSE);

	for (t1 = 1; t1 < byFreqNbr; t1++)
	{
		for (t2 = t1; t2 < byFreqNbr; t2++)
		{

			if (IS_NULLFLD(byFreqTab[t1 - 1], A_ComplianceChronoFreq_Val) == FALSE)
			{
				if ((CMP_DYNFLD(byFreqTab[t1 - 1], byFreqTab[t2], A_ComplianceChronoFreq_Val,
					A_ComplianceChronoFreq_Val, LongamountType) == 0) && (CMP_DYNFLD(byFreqTab[t1 - 1], byFreqTab[t2], A_ComplianceChronoFreq_FreqDate,
					A_ComplianceChronoFreq_FreqDate, DatetimeType) == 0) && (CMP_DYNFLD(byFreqTab[t1 - 1], byFreqTab[t2], A_ComplianceChronoFreq_NatEn,
					A_ComplianceChronoFreq_NatEn, EnumType) == 0) && (CMP_DYNFLD(byFreqTab[t1 - 1], byFreqTab[t2], A_ComplianceChronoFreq_StratId,
					A_ComplianceChronoFreq_StratId, IdType) == 0))
					DBA_DelAndFreeHierEltRec(hierHead, outDynStEnum, byFreqTab[t1 - 1]);
			}
		}
	}

	/* set links used */
	ret = DBA_SetHierLnkUsed(hierHead,
        outDynStEnum,
		destLinkFld);

	if (ret != RET_SUCCEED)
	{
		FREE(byFreqTab);
		FREE(crystalDates);
		return(ret);
	}

	/* make links */
	DBA_MakeLinks(hierHead);

	FREE(byFreqTab);

	if (funcSort != NULL && listCompoNbr > 0)
	{

		/* Extract the frequency */
		if ((ret = DBA_ExtractHierEltRec(hierHead, outDynStEnum, FALSE,
			NULLFCT, funcSort,
			&byFreqNbr, &byFreqTab)) != RET_SUCCEED)
		{
			FREE(byFreqTab);
			FREE(crystalDates);
			return(ret);
		}

		/* If the date of the first list compo is before the first crystal date, all ptf are present before the start */
		if (DATETIME_CMP(GET_DATETIME(extractListCompoTab[0], A_ListCompo_ValidDt), crystalDateBefore) > 0)
		{
			beforeOk = FALSE;
		}
		else
		{
			beforeOk = TRUE;
		}

		oldId = 0;
		oldNullFlg = FALSE;

		for (i = 0; i<byFreqNbr; i++)
		{
			currId = GET_ID(byFreqTab[i], destIdFld);
			currNullFlg = (FLAG_T)IS_NULLFLD(byFreqTab[i], destIdFld);

			if (oldId != currId || oldNullFlg != currNullFlg)
			{
				/* Search the postition in crystal date */
				crystalPos = 0;
			}

			/* Search the postition in crystal date */
			for (; crystalPos < crystalNbr
				&& DATETIME_CMP(GET_DATETIME(byFreqTab[i], destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos]) != 0
				; crystalPos++);

			/* Search if this object is present before the current crystal date */
			if (((oldId != currId || oldNullFlg != currNullFlg)		    /* Test before the first element */
				&& crystalPos == firstCrystDate
				&& (beforeOk == TRUE ||
				FIN_IsInListCompoAtDate(domainPtr,
				hierHead,
				GET_ID(domainPtr, A_Domain_InstrObjId),
				GET_DICT(domainPtr, A_Domain_DimInstrDictId),
				byFreqTab[i],
				destIdFld,
				&crystalDateBefore,
				&listCompoBeforePtr,
				&listCompoBeforeNbr,
				NO_VALUE,
				UNUSED) == TRUE))
				|| (oldId == currId          /* Test with the previous element */
				&& oldNullFlg == currNullFlg
				&& DATETIME_CMP(GET_DATETIME(byFreqTab[i - 1], destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos - 1]) == 0))
				before = TRUE;
			else
				before = FALSE;

			/* Search if this object is present after the current crystal date */
			if (((i + 1 >= byFreqNbr
				|| currId != GET_ID(byFreqTab[i + 1], destIdFld)) /* Test after the last element */
				&& (DATETIME_CMP(GET_DATETIME(byFreqTab[i], destFreqDateFld /*destFinalFld*/), crystalDates[crystalNbr - 1]) == 0)
				&& (FIN_IsInListCompoAtDate(domainPtr,
				hierHead,
				GET_ID(domainPtr, A_Domain_InstrObjId),
				GET_DICT(domainPtr, A_Domain_DimInstrDictId),
				byFreqTab[i],
				destIdFld,
				&crystalDateAfter,
				&listCompoAfterPtr,
				&listCompoAfterNbr,
				NO_VALUE,
				UNUSED) == TRUE))
				|| (i + 1 < byFreqNbr           /* Test with the next element */
				&& currId == GET_ID(byFreqTab[i + 1], destIdFld)
				&& DATETIME_CMP(GET_DATETIME(byFreqTab[i + 1], destFreqDateFld /*destFinalFld*/), crystalDates[crystalPos + 1]) == 0))
				after = TRUE;
			else
				after = FALSE;

			if (before == TRUE)
				if (after == TRUE)
					ptfFreqStatus = PtfFreqStatus_Remaining;
				else
					ptfFreqStatus = PtfFreqStatus_Exiting;
			else
				if (after == TRUE)
					ptfFreqStatus = PtfFreqStatus_Entering;
				else
					ptfFreqStatus = PtfFreqStatus_Transiting;


			SET_ENUM(byFreqTab[i], A_PtfFreq_PtfStatus, ptfFreqStatus);

			DBA_UpdHierEltRec(hierHead, outDynStEnum, byFreqTab[i]);

			oldId = currId;
			oldNullFlg = currNullFlg;
		}

		if (beforeOk == FALSE)
			DBA_FreeDynStTab(listCompoBeforePtr, listCompoBeforeNbr, S_ListCompo);

		DBA_FreeDynStTab(listCompoAfterPtr, listCompoAfterNbr, S_ListCompo);

	}

	FREE(extractListCompoTab);
	FREE(crystalDates);
	return(RET_SUCCEED);
	/* PMSTA-22458 - cashwini - 160502 > */
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfFreqByIdAndAscDate()
**
**  Description :   Portfolio table is sort by id and ascending date,
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a positive value if first element < second element
**                  a null value     if first element = second element
**                  a negative value if first element > second element
**
**  Creation    :   REF7318 - LJE - 020122
**  Modification:
**
*************************************************************************/
STATIC int FIN_CmpPortFreqByIdAndAscDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	int ret = 0;

	if(GET_ID((*ptr1), A_PtfFreq_PtfId) == GET_ID((*ptr2), A_PtfFreq_PtfId))
	{
		ret = DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfFreq_FreqDate),
			               GET_DATETIME((*ptr2), A_PtfFreq_FreqDate));
	}
	else if(GET_ID((*ptr1), A_PtfFreq_PtfId) > GET_ID((*ptr2), A_PtfFreq_PtfId))
		ret = 1;
	else
		ret = -1;


	return(ret);
}
/************************************************************************
**
**  Function    :   FIN_AnalysisFundValo()
**
**  Description :   Compute valuation for fund.
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE FIN_AnalysisFundValo(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE          ret=RET_SUCCEED;

	/* Call performance function */
	if ((ret = FIN_AnalysisValo(domainPtr, hierHead)) != RET_SUCCEED)
		return(ret);

	/* create new ExtPos for each PosVal accrued value and net value */
	ret = FIN_GenAccrNetValuePos(hierHead);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_AnalysisOpHist()
**
**  Description :   Make an operation history on a position set
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	:   REF1211 - RAK - 980210
**		    REF2580 - SSO - 980727
**		    REF3178 - SSO - 990106
**          REF7264 - 020325 - PMO : Compilation errors and warnings with C++ compiler
**          PMSTA-11645 - 170311 - PMO : Positions with sub position natures cannot be merged even when requested via a domain parameter
*************************************************************************/
RET_CODE FIN_AnalysisOpHist(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
	DBA_DYNFLD_STP     *extractPos=(DBA_DYNFLD_STP*) NULL;
	LOGICIDRULE_ENUM   logicIdRule;
	int                posNbr;
	char               copyRecFlg;
	RET_CODE           ret;
	ID_T		       ptfId=UNUSED; /* REF3178 - SSO - 990106 */
	OBJECT_ENUM        dimPtfEn;	/* REF3178 - SSO - 990106 */
	MemoryPool	       mp;

    /* PMSTA - 28572 - SANAND - 180319 */
    if ((ret = FIN_TaxLotValo(domainPtr, posHierHead)) != RET_SUCCEED)
    {
        return ret;
    }

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
					                 copyRecFlg, NULLFCT, FIN_CmpCheckLogicFus, /* REF1211 */
					                 &posNbr, &extractPos)) != RET_SUCCEED)
	{
		FREE(extractPos);
		return(ret);
	}

	mp.ownerPtr(extractPos);

	if (posNbr == 0)
		return(RET_SUCCEED);

		/* Check if it is necessary to perform the fusion process. Take care of the positions order / PMSTA-11645 - 170311 - PMO */
    const RET_CODE retCheckLogicalFusion = FIN_CheckLogicalFusion(domainPtr, posHierHead, posNbr, extractPos, &logicIdRule);

	/* Convert ref. gross and net amounts in received ref. currency */
	if ((ret = FIN_UpdPosRefAmt(extractPos, posNbr, GET_ID(domainPtr, A_Domain_CurrId),
		                        (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId),
				                posHierHead, domainPtr)) != RET_SUCCEED) /* REF2580 - SSO - 980727 */ /* REF6220 - LJE - 020306 */
	{
		return(ret);
	}

	/* convert sys amounts if necessary */
	if ((ret = FIN_UpdPosSysAmt(domainPtr, extractPos, posNbr)) != RET_SUCCEED) /* REF3178 - SSO - 990106 */
	{
		return(ret);
	}

	/* Check if it is necessary to perform the fusion process */
	if (retCheckLogicalFusion == RET_SUCCEED)   /* PMSTA-11645 - 170311 - PMO */
	{
	    /* REF3178 - SSO - 990106 : if single ptf, give its if to the fusion */
	    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
	    {
		    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
		    if (dimPtfEn == Ptf)
		    {
		        ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
		    }
	    }

		/*<PMSTA7419-EFE-090313*/
		DBA_DYNFLD_STP ptfPtr = NULL;
		FLAG_T         allocFlg=FALSE;

        if ( ptfId > 0 && ( ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr,
			                                     posHierHead , UNUSED, UNUSED) ) != RET_SUCCEED )
		{
		 	return(ret);
		}
        /*>PMSTA7419-EFE-090313*/
		if(allocFlg == TRUE) mp.ownerDynStp(ptfPtr);

	    DATE_START_TIMER(9, TIMER_MASK_SQLC);

		/* Perform a logical fusion (with no impact on database) */
		/* on a set of positions given as input. (first initial  */
		/* stock then final stock) At end of fusion, build an    */
		/* output set of positions containing only the positions */
		/* still opened.                                         */
		if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
			posHierHead, (HIER_FLTFCT*)FIN_FilterInitStock, NULLFCT,  /* REF7264 - LJE - 020128 / REF7264 - PMO */
			(PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn),
			logicIdRule,
			GET_FLAG(domainPtr, A_Domain_ClosPosFlg), ptfId, ptfPtr)) != RET_SUCCEED) /* PMSTA7419-EFE-090313*/
		{
			DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
			return(ret);
		}

	   if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
	                                posHierHead, (HIER_FLTFCT *) FIN_FilterFinalStock, NULLFCT, /* REF7264 - LJE - 020128 / REF7264 - PMO */
			                        (PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn),
			                        logicIdRule,
					                GET_FLAG(domainPtr,A_Domain_ClosPosFlg), ptfId,ptfPtr)) != RET_SUCCEED) /* PMSTA7419-EFE-090313*/
	   {
		    DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
		    return(ret);
	   }

	   DATE_STOP_TIMER(9, TIMER_MASK_SQLC);

	   /* Keep only the positions still opened
	    comment by sme optim
	   if ((ret = DBA_SuppressHierEltRec(hierHead, ExtPos,
				             FIN_FilterCloseStock)) != RET_SUCCEED)
	   {
		return(ret);
	   }*/
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AnalysisOpList()
**
**  Description :   Make an operation list on a position set
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   DVP416 - RAK - 970403
**		    REF2580 - SSO - 980727
**
*************************************************************************/
RET_CODE FIN_AnalysisOpList(DBA_DYNFLD_STP domainPtr, PTR hierHead)
{
	/*
	DBA_DYNFLD_STP     *extractPos=(DBA_DYNFLD_STP*) NULL;
	int                posNbr=0; */
	RET_CODE           ret=RET_SUCCEED;

	/* DVP416 - RAK - 970403 */
	/* if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
					 FALSE, NULLFCT, NULLFCT,
					 &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret); */

	/* Convert ref. gross and net amounts in received ref. currency */
	/* DVP416 -  Don't update amounts */
	/* ret = FIN_UpdPosRefAmt(extractPos, posNbr, GET_ID(domainPtr, A_Domain_CurrId),
			       (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId), hierHead);
	FREE(extractPos); */

    /* PMSTA-28573 - SANAND - 180319 */
    if ((ret = FIN_TaxLotValo(domainPtr, (DBA_HIER_HEAD_ST *)hierHead)) != RET_SUCCEED)
    {
        return ret;
    }

	/* REF2779 - SSO - 000203 */
	ret = FIN_UpdPosFields(domainPtr, (DBA_HIER_HEAD_ST *)hierHead); /* REF7264 - LJE - 020128 */

	return(ret);
}

/************************************************************************
*
*  Function    : FIN_InsExtOpInHierWithFilter()
*
*  Description : This function filter ExtOp with the sript and all Extop matching
*                are inserted in hierarchy. (code moved from function FIN_AnalysisOpSearchPhase1)
*
*  Arguments   : extOpTab  : pointer on extended operation array
*                extOpNbr  : number of extended operation
*                scptDefStr: script definition on extended operation used to filter (used only if filterFlg == TRUE)
*                domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*                filterFlg : Define if extOp must be filter
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF7560 - DDV - 020603
*  Last modif. :
*
*************************************************************************/
STATIC RET_CODE FIN_InsExtOpInHierWithFilter(DBA_DYNFLD_STP    *extOpTab,
                                             int               extOpNbr,
                                             char              *scptDefStr,
                                             DBA_DYNFLD_STP    domainPtr,
                                             DBA_HIER_HEAD_STP hierHead,
                                             FLAG_T            filterFlg)
{
	DBA_DYNFLD_STP  *tmpExtOpTab=NULLDYNSTPTR;
	int             i, tmpExtOpNbr=0;
    SCPT_ARG_STP    genContext=(SCPT_ARG_STP)NULL;
    DBA_DYNFLD_ST   scptResult;
    int             opRowCount = 0, extOpNbrInHier = 0;
    FLAG_T          extOpScriptFlg = FALSE;

    SYS_Bzero(&scptResult, sizeof(DBA_DYNFLD_ST));

    GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);

    /* Check number of ExtOp allready created */
    DBA_HierGetRecNbr(hierHead, ExtOp, NULLFCT, &extOpNbrInHier, FALSE /* TRUE */); /* REF10530 - TEB - 060815 */

	/* Check arguments */
	if (hierHead == (PTR)NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_InsExtOpInHierWithFilter", "hierHead");
		return(RET_GEN_ERR_INVARG);
	}

	if (extOpNbr == 0)
		return(RET_SUCCEED);

    if (filterFlg == TRUE && scptDefStr != NULL && scptDefStr[0] != END_OF_STRING)
        extOpScriptFlg = TRUE;

    if (extOpScriptFlg == TRUE)
    {
        /* Generate Tree for extended operation script */
        if (SCPT_GenerateScptTree(scptDefStr,
                                  EOp,
                                  InternalSMode,
                                  FlagType,
                                  &genContext) != RET_SUCCEED)
    	{
            MSG_RETURN(RET_SCPT_ERR_SYNTAX);
    	}
	}

	tmpExtOpTab = (DBA_DYNFLD_STP *)CALLOC(extOpNbr, sizeof(DBA_DYNFLD_STP));

    /* filter all ExtOp, using script on extended operation */
	for (i=0 ; i<extOpNbr ; i++)
	{
		if (extOpTab[i] != NULLDYNST)
        {
            /* don't insert more ExtOp as OP_SEARCH_RET_ROW_COUNT */
            if (extOpNbrInHier + tmpExtOpNbr < opRowCount)
            {
                if (extOpScriptFlg == TRUE)
                {
                    if (SCPT_ExecScptTree(genContext,
                                          domainPtr,
                                          hierHead,
                                          extOpTab[i],
                                          FlagType,
                                          &scptResult, NULLDYNST) == RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
                    {
                        if (GET_FLAG((&scptResult), 0) == TRUE)
                            tmpExtOpTab[tmpExtOpNbr++] = extOpTab[i];
						else
							FREE_DYNST(extOpTab[i], ExtOp); /* PMSTA04733 - DDV - If filter return FALSE, free the record */
                    }
                    else
                        FREE_DYNST(extOpTab[i], ExtOp);
                }
                else
                    tmpExtOpTab[tmpExtOpNbr++] = extOpTab[i];
            }
        }
	}

    if (extOpScriptFlg == TRUE)
        SCPT_FreeScptTree(genContext);

 	DBA_AddHierRecordList(hierHead, tmpExtOpTab, tmpExtOpNbr, ExtOp, FALSE);
	FREE(tmpExtOpTab);

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_OpSeachUseOnlyInOpTable()
*
*  Description : Analyse Domain argument and system parameter to
*                to decide if search can be done only on operation table
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*
*  Return      : TRUE or FALSE
*
*  Creation D. : REF7560 - DDV - 020603
*  Last modif. :
*
*************************************************************************/
FLAG_T FIN_OpSearchUseOnlyOpTable(DBA_DYNFLD_STP domainPtr)
{
    OPSEARCH_METHOD_ENUM opSearchMethod; /* REF5493 - DDV - 010104 */
    FLAG_T               searchOnlyInOpTableFlg = FALSE;
    OPSEARCH_FCTRESULT_ENUM   opSearchFctResultMethod = OpSearch_DontUseDomainFctResult;

    /* REF5493 - DDV - 010104 - Optimise search to use more often table operation */
    GEN_GetApplInfo(ApplOpSearchMethod, &opSearchMethod);

    /* PMSTA-20506 - DDV - 150610 */
    GEN_GetApplInfo(ApplOpSearchFctResultMethod, &opSearchFctResultMethod);

    /* REF5493 - DDV - 010104 - Check if opSearchMethod, ptfdim and Instrdim authorised search based on operation */
    switch(opSearchMethod)
    {
        case OpSearchMethod_NoOpti:
            if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == TRUE &&
                IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE)
                searchOnlyInOpTableFlg = TRUE;
            break;
        case OpSearchMethod_PtfOpti:
            if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId))
                searchOnlyInOpTableFlg = TRUE;
            break;
        case OpSearchMethod_InstrOpti:
            if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE)
                searchOnlyInOpTableFlg = TRUE;
            break;
        case OpSearchMethod_PtfInstrOpti:
            searchOnlyInOpTableFlg = TRUE;
            break;
    }

    /* REF5493 - DDV - 010104 - Check if fusiondate rule, from_d and till_d authorised search based on operation */
    if (searchOnlyInOpTableFlg == TRUE)
    {
        if (GET_ENUM(domainPtr, A_Domain_FusDateRuleEn) == FusDateRule_None &&
            (IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE ||
             IS_NULLFLD(domainPtr, A_Domain_InterpTillDate) == FALSE))
            searchOnlyInOpTableFlg = FALSE;
    }

    /* PMSTA-20506 - DDV - 150610 - if function_result_id from domain is used, avoid operation view usage. */
    if (opSearchFctResultMethod == OpSearch_UseDomainFctResult && IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
    {
        searchOnlyInOpTableFlg = FALSE;
    }

    return(searchOnlyInOpTableFlg);

}

/************************************************************************
**
**  Function    :   FIN_CmpExtOpByIdFusion()
**
**  Description :   Extended operation aer sorted by ExtOp_Id and ExtOp_FusionEn
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtOp
**                  ptr2   pointer on dynamic structure type ExtOp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7560 - DDV - 020603
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_CmpExtOpByOpIdFusion(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    if (GET_ID((*ptr1), ExtOp_OpId) ==
	    GET_ID((*ptr2), ExtOp_OpId))
        return(GET_ENUM((*ptr1), ExtOp_FusionEn) - GET_ENUM((*ptr2), ExtOp_FusionEn));
    else
        return(CMP_ID(GET_ID((*ptr1), ExtOp_OpId) , GET_ID((*ptr2), ExtOp_OpId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
*
*  Function    : FIN_RemoveDuplicateExtOp()
*
*  Description : Remove all ExtOp duplicated in hierarchy
*
*  Arguments   : hierHead  : hierarchy pointer
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF7560 - DDV - 020603
*  Last modif. :
*
*************************************************************************/
STATIC RET_CODE FIN_RemoveDuplicateExtOp(DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
	int             extOpNbr=0, i;

    /* extract all extended operation from hierarchy sorted by id and fusion_e */
    DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE,
                          NULLFCT, FIN_CmpExtOpByOpIdFusion,
                          &extOpNbr, &extOpTab);

    for (i=1; i< extOpNbr;i++)
    {
        /* NULL values are placed at the end */
        if (IS_NULLFLD(extOpTab[i], ExtOp_OpId) == TRUE)
        {
            FREE(extOpTab); /* REF11589 - DDV - 060623 */
	        return(RET_SUCCEED);
        }

        /* The same operation id can be found in two cases :                                     */
        /*  1 - One operation untreated (from ext_order) and one to delete from operation        */
        /*      => keep both, it is a update not already fused                                   */
        /*  2 - One operation untreated (from ext_order) and one treated from operation          */
        /*      => keep only treated operation, fusion as update operation table during the load */

        if(CMP_DYNFLD(extOpTab[i-1], extOpTab[i], ExtOp_OpId, ExtOp_OpId, IdType) == 0 &&
           GET_ENUM(extOpTab[i], ExtOp_FusionEn) == OpFusion_Treated)
            DBA_DelAndFreeHierEltRec(hierHead, ExtOp, extOpTab[i-1]);
    }
	FREE(extOpTab); /* 041216 - CHU - Purify */

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_AnalysisOpSearchPhaseOrder()
*
*  Description : New phase added during developement of ext_order table.
*                This function filter all orders (loaded by DBA:LoadOrdrers function)
*                Two filters are applied :
*                   - the first one is the script definition of domain
*                   - the second one is the instrument dimension
*                     which is not allready treated
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*                connectNo : Number of the connection to use (used for load of extended execution)
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF7560 - DDV - 020603
*
*  Last modif. : REF8723 - TEB - 040219
*				 REF10530 - TEB - 060814
*
*************************************************************************/
RET_CODE FIN_AnalysisOpSearchPhaseOrder(DBA_DYNFLD_STP    domainPtr,
                                        DBA_HIER_HEAD_STP hierHead,
                                        int               *connectNo)
{
	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  listPtr=NULLDYNST;
	int             i, j, tmpExtOpNbr=0, extOpNbr=0, instrFKNbr = 0;
    int             opRowCount = 0, *instrFKTab=(int *) NULL;
	DICT_FCT_STP    dictFctInfo;
    FLAG_T          keepItFlg = FALSE;
	RET_CODE        ret;
	char            *filterScript = NULL;	/* REF10530 - TEB - 060814 */
	FLAG_T			freeFlg = FALSE;		/* REF10530 - TEB - 060814 */
	MemoryPool		mp;

    GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);

    /* DDV - 000330 - Write a message in server.log to show progress */
    /* REF8723 - TEB - 040219 */
    if ( IS_NULLFLD(domainPtr, A_Domain_InitialFctDictId) == FALSE &&
         DictFct_PurgeOrder ==(DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_InitialFctDictId) )
    {
        DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);
    }
    else
    {
	    DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo); /* REF7264 - LJE - 020128 */
    }

    MSG_LogSrvMesg(UNUSED, UNUSED,
				   "%1 : Loading all records from ext_order table",
				   NameType,   dictFctInfo->name);

	/* REF10530 - TEB - 060814 */
	/* Analyse the formats to get filters on operation from the formats */
    if ( GET_ENUM(domainPtr, A_Domain_OutputTpEn)!= TableOutput)
    {
		ret = FIN_GetFmtFilter(domainPtr, EOp, &filterScript, &freeFlg);

	    if (freeFlg == TRUE)
	    {
		    mp.ownerPtr(filterScript);
	    }

		if (IS_NULLFLD(domainPtr, A_Domain_ExtOpSearch) == FALSE &&
			filterScript != NULL)
		{
			filterScript = (char *)mp.realloc(filterScript,
				(strlen(filterScript) + strlen(GET_TEXT(domainPtr, A_Domain_ExtOpSearch))+12)*sizeof(char));

			strcat(filterScript," AND (");
			strcat(filterScript,GET_TEXT(domainPtr, A_Domain_ExtOpSearch));
			strcat(filterScript,")");
		}
		else if (IS_NULLFLD(domainPtr, A_Domain_ExtOpSearch) == FALSE &&
				 filterScript == NULL)
		{
			filterScript = GET_TEXT(domainPtr, A_Domain_ExtOpSearch);
		}
	}
	else
	{
		filterScript = GET_TEXT(domainPtr, A_Domain_ExtOpSearch);
	}

    tmpExtOpNbr = DBA_GetHierEltWithScptFilter(hierHead,
		  								       ExtOp,
										       NULL,
    										   NULL,
	    									   filterScript /* GET_TEXT(domainPtr, A_Domain_ExtOpSearch) */, /* REF10530 - TEB - 060814 */
		    			                       domainPtr,
			    							   TRUE,
				    						   &extOpNbr,
					    					   &extOpTab);

	mp.ownerPtr(extOpTab);	

    /* if no extended operation matching script definition, return RET_SUCCEED */
    if (tmpExtOpNbr == 0)
	{
        return(RET_SUCCEED);
	}
    /* In case of detail search, filter extended operation
       according to instrument dimension (for all instrument dimension except for all instrument) */
    if (FIN_OpSearchUseOnlyOpTable(domainPtr) == FALSE &&
        IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
    {
        DBA_GetAllFK(EOp, Instr, FALSE, &instrFKTab, &instrFKNbr);

		mp.ownerPtr(instrFKTab);

        if (instrFKTab != (int *) NULL && instrFKNbr > 0)
        {
            for(i=0; i < extOpNbr; i++)
            {
                if(extOpTab[i] != NULLDYNST)
                {
                    keepItFlg = FALSE;
                    for(j=0; j < instrFKNbr && keepItFlg == FALSE; j++)
                    {
                        if (IS_NULLFLD(extOpTab[i], instrFKTab[j]) == FALSE)
                        {
                            keepItFlg = DBA_CheckInstrDim(domainPtr, hierHead,
                                                          GET_ID(extOpTab[i], instrFKTab[j]),
                                                          NULLDYNST, &listPtr, connectNo, FALSE, (DATETIME_STP)NULL, FALSE);
                        }
                    }

                    if (keepItFlg == FALSE)
                    {
                        DBA_DelAndFreeHierEltRec(hierHead, ExtOp, extOpTab[i]);
                        tmpExtOpNbr--;
                    }
                }
            }
        }
    }

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_AnalysisOpSearchPhase1()
*
*  Description : Retrieve a hierarchy (ExtPos hierarchy), read Extended
*                Positions from hierarchy and construct/create Extended
*                Operations, filter it and store result in hierarchy.
*                this function is directly called from DBA_LoadPos.
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*                filterFlg : flag to indicate is ExtOp filter must be apply
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF2467 - DDV - 991217
*  Last modif. : REF7264 - 020325 - PMO : Compilation errors and warnings with C++ compiler
*                REF8723 - TEB - 040219
*				 REF10530 - TEB - 050818
*
*************************************************************************/
RET_CODE FIN_AnalysisOpSearchPhase1(DBA_DYNFLD_STP    domainPtr,
                                    DBA_HIER_HEAD_STP hierHead,
                                    FLAG_T            filterFlg,
                                    int               remainOpNbr)
{
	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
	int             extOpNbr=0;
	RET_CODE        ret;
    int             opRowCount = 0, extOpNbrInHier = 0;
	DICT_FCT_STP    dictFctInfo;
	char            *filterScript = NULL;	/* REF10530 - TEB - 050818 */
	FLAG_T			freeFlg = FALSE;		/* REF10530 - TEB - 050818 */

    GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);

    /* Check number of ExtOp allready created */
    DBA_HierGetRecNbr(hierHead, ExtOp, NULLFCT, &extOpNbrInHier, FALSE /* TRUE */); /* REF10530 - TEB - 060815 */

    /* DDV - 000330 - Write a message in server.log to show progress */
    /* REF8723 - TEB - 040219 */
    if ( IS_NULLFLD(domainPtr, A_Domain_InitialFctDictId) == FALSE &&
         DictFct_PurgeOrder ==(DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_InitialFctDictId) )
    {
        DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);
    }
    else
    {
	    DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo); /* REF7264 - LJE - 020128 */
    }

    /* REF7560 - DDV - 020619 - Use more explicite message in server.log file */
    if (filterFlg == TRUE)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
					      "%1 : Loading a new batch (%2 operations matching, still %3 to check)",
						    NameType,   dictFctInfo->name,
						    IntType, extOpNbrInHier,
						    IntType, remainOpNbr);
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
					      "%1 : Loading a new batch (%2 operations matching, still %3 to load)",
						    NameType,   dictFctInfo->name,
						    IntType, extOpNbrInHier,
						    IntType, remainOpNbr);
    }

	/* Check arguments */
	if (hierHead == (PTR)NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_AnalysisOrderList", "hierHead");
		return(RET_GEN_ERR_INVARG);
	}

	ret = OPE_CreateExtOpfromExtPos(hierHead, &extOpTab, &extOpNbr, NULL, NULL);    /* REF7264 - PMO */

	if (ret != RET_SUCCEED)
	{
		if (extOpNbr > 0)
			return(RET_GEN_ERR_NOACTION);
		/* PMSTA03263-CHU-070720 : Continue process even without positions */  /* PMSTA03149 - BER - 070919 - Code Report From TA4.20.4 to TA4.30.2 */
		if (ret == RET_FIN_ERR_POSITIONS)
			return(RET_SUCCEED);
	}

	/* REF10530 - TEB - 050818 */
	/* Analyse the formats to get filters on operation from the formats */
    if ( GET_ENUM(domainPtr, A_Domain_OutputTpEn)!= TableOutput)
    {
		ret = FIN_GetFmtFilter(domainPtr, EOp, &filterScript, &freeFlg);

		if (filterFlg == TRUE)
		{
			if (IS_NULLFLD(domainPtr, A_Domain_ExtOpSearch) == FALSE &&
				filterScript != NULL)
			{
				filterScript = (char *)REALLOC(filterScript,
					(strlen(filterScript) + strlen(GET_TEXT(domainPtr, A_Domain_ExtOpSearch))+12)*sizeof(char));

				strcat(filterScript," AND (");
				strcat(filterScript,GET_TEXT(domainPtr, A_Domain_ExtOpSearch));
				strcat(filterScript,")");
			}
			else if (IS_NULLFLD(domainPtr, A_Domain_ExtOpSearch) == FALSE &&
					 filterScript == NULL)
			{
				filterScript = GET_TEXT(domainPtr, A_Domain_ExtOpSearch);
			}
		}
	}
	else
	{
		filterScript = GET_TEXT(domainPtr, A_Domain_ExtOpSearch);
	}

	if (ret == RET_SUCCEED)
		ret = FIN_InsExtOpInHierWithFilter(extOpTab, extOpNbr,
										   filterScript, /* GET_TEXT(domainPtr, A_Domain_ExtOpSearch),*/ /* REF10530 - TEB - 050818 */
										   domainPtr, hierHead, filterFlg);
	/* REF10530 - TEB - 050818 */
	if (freeFlg == TRUE)
	{
		FREE(filterScript);
	}

	FREE(extOpTab);

	return(ret);
}

/************************************************************************
*
*  Function    : FIN_ExecuteOrderGrouping()
*
*  Description : Performs received format (in domain) on loaded ExtOp,
*				 executes order grouping and save computed ExtOp in database
*
*  Arguments   : domainPtr      : pointer on a domain dynamic structure
*                hierHead       : hierarchy pointer
*				 initialFctDict	: initial function dict id (OrderGrouping or sub-function)
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : PMSTA15221-CHU-121219
*   Modif       :   HFI-PMSTA-49593-220817  Use memory pool
*
*************************************************************************/
RET_CODE FIN_ExecuteOrderGrouping(DBA_DYNFLD_STP	domainArg,
								  DBA_HIER_HEAD_STP	hierHead,
								  DICT_T			initialFctDict,
								  DICT_FCT_STP		dictFctInfo,
								  DBA_DYNFLD_STP	*caseMgtTab,
								  int				caseMgtNbr,
								  EXTOP_ACTION_ENUM	actionEn,
                                  bool              splitSessionFlag) /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
{
	RET_CODE				ret=RET_SUCCEED;
	DICT_FCT_STP			OLDictFctInfo=NULL;
	DICT_T					OLDictFct;       /*  Function associated to the domain format (order list fct or sub-function) */
	DBA_DYNFLD_STP			*EOTab=NULLDYNSTPTR, *sumFmtEltTab=NULLDYNSTPTR, *newEOTab=NULLDYNSTPTR, aFmtSt=NULLDYNST;
	int						i, j, newEONbr=0, EONbr=0, fmtEltNbr=0, dataSetNbr=0, fmtEltNbOut=0, EOFldNbr=0;
	SCPT_FMTDATADEF_STP		fmtDataDefStp = (SCPT_FMTDATADEF_STP)NULL;
	SCPT_DATASET_ST			dataSet[10];
	DICT_ATTRIB_STP   		attribSt;
	ID_T					langDictId;
	ORDER_GROUPING_MODE_ENUM OrderGroupingModeEn = OrderGroupingMode_None;
	ID_T					fctResultId = (ID_T)0;
	DICT_FCT_STP			pdictfct = NULL;
    bool                    bIsManageSessionFct = false; /* PMSTA-31804 - CHU - 180621 */
    MemoryPool              mp;                             /*  HFI-PMSTA-49593-220817  */

    /* PMSTA-31804 - CHU - 180621 : let's group these f* orders for Summertime if FIN_ManageSession() was called :) */
    if (DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_DICT(domainArg, A_Domain_FctDictId), DictFctInfo_Stp, &pdictfct) == RET_SUCCEED &&
        pdictfct != NULL &&
        pdictfct->parFctDictId == DictFct_ManageSession)
    {
        bIsManageSessionFct = true;
    }

	if (false == bIsManageSessionFct &&
        IS_NULLFLD(domainArg, A_Domain_FmtId) == FALSE)
	{
		OrderGroupingModeEn = OrderGroupingMode_FinFct;
		pdictfct = dictFctInfo;
	}
	else if (IS_NULLFLD(domainArg, A_Domain_OrderGroupingFctDictId) == FALSE)
	{
		OrderGroupingModeEn = OrderGroupingMode_OrderAndProd;

		if (DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_DICT(domainArg, A_Domain_OrderGroupingFctDictId), DictFctInfo_Stp, &pdictfct) != RET_SUCCEED ||
			pdictfct == NULL ||
			pdictfct->parFctDictId != DictFct_OrderGrouping)
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ExecuteOrderGrouping", "A_Domain_OrderGroupingFctDictId");
			ret = RET_GEN_ERR_INVARG;
			return (ret);
		}
		EOFldNbr = GET_FLD_NBR(ExtOp);
		fctResultId = GET_ID(domainArg, A_Domain_FctResultId);

        if (true == bIsManageSessionFct) /* PMSTA-31804 - CHU - 180621 : extract orders from hierarchy */
        {
            if ((ret = DBA_ExtractHierEltRec(hierHead,
                                                ExtOp,
                                                FALSE,
                                                NULLFCT,
                                                NULLFCT,
                                                &EONbr,
                                                &EOTab)) == RET_SUCCEED && EONbr > 0)
            {
                /* PMSTA08783 - RAK - 091020 */
                /* so won't be NULL (not inserted by the hierarchy tools) and script will work */
                /* but it's not a clean solution : on cache seulement la merde au chat :):):):)*/
                /* see attached doc in JIRA for the Tech Analysis of a deeper cleaner solution */
                for (i = 0; i < EONbr; i++)
                {
                    if (IS_NULLFLD(EOTab[i], ExtOp_Id) == TRUE &&
                        IS_NULLFLD(EOTab[i], ExtOp_OpId) == FALSE)
                    {
                        SET_ID(EOTab[i], ExtOp_Id, GET_ID(EOTab[i], ExtOp_OpId));
                    }
                }
            }
        }
        else
        {
            /* < OCS-49265 - CHU - 170215 */
            if (initialFctDict              == DictFct_OrderGrouping &&
                dictFctInfo->dictId         == DictFct_OrderGrouping &&
                dictFctInfo->parFctDictId   == DictFct_OrderGrouping)
            {
                DBA_DYNFLD_STP      getDomainPtr = NULLDYNST;
                SCPT_CLASSIFSTACK_STP classifStack = NULL;

                const DBA_DYNST_ENUM *outputStLst[] = { &ExtOp, /* REF8844 - LJE - 030417 */
                                                        //&A_ConstraintBreach,	/* kept in SP but not exist anymore in database */
                                                        &A_CaseManagement,
                                                        &ExtStratLnk,
                                                        &ExtStratElt,
                                                        &A_Ptf,				/* PMSTA10463-PRS-110222 */
                                                        &A_ApplComment,		/* PMSTA11318-CHU-110202 */
                                                        &A_RiskESElt,			/* PMSTA-18426 - CHU - 141203 */
                                                        &A_RiskESEltCompo,      /* PMSTA-18426 - CHU - 141203 */
                                                        &A_LombardCheck,		/* PMSTA-21462 - CHU - 151013 */
                                                        &A_DomainPtfCompo,   	/* PMSTA-21529 - CHU - 151021 */
                									    &A_TaxLot,              /* PMSTA-34295 - sanand - 060319 */
										                &A_TaxLotInitial };     /* PMSTA-34295 - sanand - 060319 */

                int					outputBlkNb = sizeof(outputStLst) / sizeof(outputStLst[0]);  /* PMSTA-34295 - sanand - 060319 */
                DBA_DYNFLD_STP		*data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };	/* PMSTA11318-CHU-110202 */  /* PMSTA-34295 - sanand - 060319 */
                int					k, rows[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };	/* PMSTA11318-CHU-110202 */  /* PMSTA-34295 - sanand - 060319 */
                ret                           = RET_SUCCEED;

			    /* PMSTA-30891 - RAK - 180430 - Use S_Domain and keep empty instrument and portfolio dimensions */
                /* load data from function result */
			    if ((getDomainPtr = ALLOC_DYNST(S_Domain)) == NULL)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Domain");
                    return(RET_MEM_ERR_ALLOC);
                }
			    SET_ID(getDomainPtr,   S_Domain_FctResultId, GET_ID(domainArg, A_Domain_FctResultId));
			    SET_FLAG(getDomainPtr, S_Domain_ExtStratEltNatAllocFlg, FALSE);	/* Load portfolio(s) ext strategy elt */
			    SET_FLAG(getDomainPtr, GET_FLD_AUTH_UPD(S_Domain), FALSE);			    /* PMSTA-30891 - RAK - 180504 - use this flag for @init_dim_f" */
				SET_FLAG(getDomainPtr, S_Domain_InitDimFlg, FALSE);		/* PMSTA-44684 - JPR - 210418 - Group ordering is not working with Rebalancing asynchronously */

			    if ((ret = DBA_MultiSelect2(EOp, DBA_ROLE_FCT_RESULT, S_Domain, getDomainPtr,
                    outputStLst, data,
                    UNUSED, UNUSED,
                    rows,
                    UNUSED)) != RET_SUCCEED) /* PMSTA11898-CHU-110524 */
                {
                    if (ret == RET_FIN_ERR_SECURITY_ISSUE)
                    {
                        CODE_T		userCd;

                        *userCd = END_OF_STRING;
                        if (DBA_GetUserInfo(A_ApplUser_Cd, (PTR)&userCd) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_FIN_ERR_SECURITY_ISSUE, 1, FILEINFO,
                                userCd,
                                GET_CODE(domainArg, A_Domain_FctResultCd));
                        }
					    FREE_DYNST(getDomainPtr, S_Domain);
                        return(ret); /* convert to display a message on GUI side */
                    }
                    FREE(classifStack); /* 041216 - CHU - Purify */
				    FREE_DYNST(getDomainPtr, S_Domain);
                    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                }

			    FREE_DYNST(getDomainPtr, S_Domain);

                /* Store in hierarchy */
                for (i = 0; i<outputBlkNb; i++)
                {
                    /* REF9823 - CHU - 040202 : ExtStratLnk already loaded by DBA_SelCheckStratData() */
                    /* PMSTA-9723 - RAK - 100506 - clean code - CB aren't loaded */
                    /* (they don't exist anymore in database) replaced by Cases  */
                    if (*(outputStLst[i]) == ExtOp)
                    {
                        /* PMSTA08783 - RAK - 091020 */
                        /* so won't be NULL (not inserted by the hierarchy tools) and script will work */
                        /* but it's not a clean solution : on cache seulement la merde au chat :):):):)*/
                        /* see attached doc in JIRA for the Tech Analysis of a deeper cleaner solution */
                        for (k = 0; k<rows[i]; k++)
                        {
                            SET_ID(data[i][k], ExtOp_Id, GET_ID(data[i][k], ExtOp_OpId));
                        }
                        DBA_AddHierRecordList(hierHead, data[i], rows[i], *(outputStLst[i]), TRUE);
                        FREE(data[i]);
                    }
                    else
                    {
                        /* 041216 - CHU - Purify */
                        DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i]));
                    }
                }

                if ((ret = DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ParExtOp_Ext)) != RET_SUCCEED ||
                    (ret = DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ChildExtOp_Ext)) != RET_SUCCEED )
                {
                    return(ret);
                }

                if (DBA_MakeAllRecLinks(hierHead, ExtOp) != RET_SUCCEED)
                {
                    return(ret);
                }

                actionEn = Action_SaveDraft;
            }
            /* > OCS-49265 - CHU - 170215 */
        }
	}
	/*
	else
	{
		Bye bye... ?
	}
	*/

	if (OrderGroupingModeEn == OrderGroupingMode_FinFct)
	{
		memset(dataSet, 0, 10*sizeof(SCPT_DATASET_ST));

		/* Select FmtElt */
        DBA_DYNFLD_STP  getArgSt = mp.allocDynst(FILEINFO, Get_Arg);
	    if (getArgSt == nullptr)
	    {
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
			return(RET_MEM_ERR_ALLOC);
		}

		SET_ID(getArgSt, Get_Arg_Id, GET_ID(domainArg, A_Domain_FmtId));

		/***** SEARCH attribute_dict_id for format_element.script_definition field *****/
		if (DBA_SearchAttribSqlName( FmtElt, "script_definition", &attribSt) != RET_SUCCEED)
		{
			return(ret);
		}
		SET_ID(getArgSt, Get_Arg_AttribDictId, attribSt->attrDictId);


		if (GET_ID(domainArg, A_Domain_LangDictId) == 0)
		{
			DBA_GetUserInfo2(A_ApplUser_LangDictId, &langDictId, TRUE); /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
		}
		else
		{
			langDictId = GET_ID(domainArg, A_Domain_LangDictId);
		}

		SET_ID(getArgSt, Get_Arg_LangDictId, langDictId);

		if (DBA_Select2(FmtElt,
						UNUSED,
						Get_Arg,
						getArgSt,
						Sum_FmtElt,
						&sumFmtEltTab,
						UNUSED,
						UNUSED,
						&fmtEltNbr,
						UNUSED,
						UNUSED ) != RET_SUCCEED)
		{
			return(ret);
		}

		if (SCPT_FmtEltAnalyse(&sumFmtEltTab, fmtEltNbr,
							   (FIN_FCT_OUTPUT_ENUM)GET_ENUM(domainArg, A_Domain_OutputTpEn),
							   dataSet, &dataSetNbr,
							   &fmtEltNbOut, SERV_IsGuiConnect(), FALSE) == FALSE)    /* DLA - REF04685 - 080117 */
		{
			return(RET_SCPT_ERR_FCT_FAILED);
		}
        mp.ownerDynStpTab(sumFmtEltTab, fmtEltNbOut);

		fmtDataDefStp = static_cast<SCPT_FMTDATADEF_STP>(mp.calloc(FILEINFO, 1, sizeof(SCPT_FMTDATADEF_ST)));
		if (fmtDataDefStp == nullptr)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "SCPT_FMTDATADEF_ST");
			return(RET_MEM_ERR_ALLOC);
		}
		fmtDataDefStp->dataDefTab   = dataSet[0].dataDefTab;
		fmtDataDefStp->sumFmtEltTab = sumFmtEltTab;
		fmtDataDefStp->fmtId        = GET_ID(domainArg, A_Domain_FmtId);
		fmtDataDefStp->nbCol        = dataSet[0].colNb;
		fmtDataDefStp->colIdx       = dataSet[0].colNb-1;
		fmtDataDefStp->dataSetIndex = 0;

		for (i=0; i < fmtDataDefStp->nbCol; i++)
		{
			fmtDataDefStp->dataDefTab[i].fmtId=fmtDataDefStp->fmtId;
		}

		/* Get Fmt and init fmtDataDefSt with it */
        DBA_DYNFLD_STP  sFmtSt = mp.allocDynst(FILEINFO, S_Fmt);
		if (sFmtSt == nullptr)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Fmt");
			return(RET_MEM_ERR_ALLOC);
		}

        aFmtSt = mp.allocDynst(FILEINFO, A_Fmt);
		if (aFmtSt  == nullptr)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Fmt");
			return(RET_MEM_ERR_ALLOC);
		}

		SET_ID(sFmtSt, S_Fmt_Id, GET_ID(domainArg, A_Domain_FmtId));

		if (DBA_Get2(Fmt, UNUSED, S_Fmt, sFmtSt, A_Fmt, &aFmtSt,
					 UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
		{
			fmtDataDefStp->aFormat = aFmtSt;
		}
		else
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
           				 "FIN_AnalysisOrderGrouping", "format in domain not valid");

			return(RET_GEN_ERR_INVARG);
		}
	}

    if (false == bIsManageSessionFct) /* PMSTA-31804 - CHU - 180621 : orders were already extracted from hierarchy */
    {
        ret = DBA_ExtractHierEltRec(hierHead,
									ExtOp,
									FALSE,
									NULLFCT,
									NULLFCT,
									&EONbr,
									&EOTab);
    }
    else
    {
        if (EONbr > 0)
        {
            DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ParExtOp_Ext);
            DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ChildExtOp_Ext);
            DBA_MakeAllRecLinks(hierHead, ExtOp);
        }
    }

	if (ret == RET_SUCCEED && EONbr > 0)
	{
		if (OrderGroupingModeEn == OrderGroupingMode_FinFct)
		{
			/* Create record with supplementary fields */
			EOFldNbr = GET_FLD_NBR(ExtOp) + fmtEltNbr;

			if ((newEOTab = (DBA_DYNFLD_STP*) CALLOC(EONbr, sizeof(DBA_DYNFLD_STP))) == NULL)
			{
				FREE(EOTab);

				for(i=0 ; i<dataSetNbr ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			for (i=0; i<EONbr; i++)
			{
				newEOTab[i] = ALLOC_DYNST_SUPPLFLD(ExtOp, EOFldNbr);
				if (newEOTab[i] == NULLDYNST)
				{
					FREE(EOTab);
					for (j=0; j<i; j++)
					{ FREE_DYNST_SUPPLFLD(newEOTab[j], EOFldNbr);}
					FREE(newEOTab);
					FREE(EOTab);

					for(i=0 ; i<dataSetNbr ; i++)
					{
						if(dataSet[i].scriptFilter != NULL)
							FREE(dataSet[i].scriptFilter);
						if(dataSet[i].colTypesTab != NULL)
							FREE(dataSet[i].colTypesTab);
						if(dataSet[i].dataDefTab != NULL)
							FREE(dataSet[i].dataDefTab);
					}
					ret = RET_MEM_ERR_ALLOC;
					MSG_SendMesg(ret, 2, FILEINFO, "%s with supplementary fld", ExtOp);

					return(ret);
				}

				COPY_DYNST(newEOTab[i], EOTab[i], ExtOp);

				if ((ret = DBA_DelAndFreeHierEltRec(hierHead, ExtOp, EOTab[i])) != RET_SUCCEED)
				{
					FREE(EOTab);
					for (j=0; j<=i; j++)
					{ FREE_DYNST_SUPPLFLD(newEOTab[j], EOFldNbr);}
					FREE(newEOTab);
					FREE(EOTab);

					for(i=0 ; i<dataSetNbr ; i++)
					{
						if(dataSet[i].scriptFilter != NULL)
							FREE(dataSet[i].scriptFilter);
						if(dataSet[i].colTypesTab != NULL)
							FREE(dataSet[i].colTypesTab);
						if(dataSet[i].dataDefTab != NULL)
							FREE(dataSet[i].dataDefTab);
					}
					return(ret);
				}
			}

			FREE(EOTab);

			if ((ret = DBA_AddHierRecordSupplFldList(hierHead, newEOTab, EONbr, ExtOp, EOFldNbr, FALSE)) != RET_SUCCEED)
			{
				for (j=0; j<EONbr; j++)
				{
					FREE_DYNST_SUPPLFLD(newEOTab[j], EOFldNbr);
				}
				FREE(newEOTab);

				for(i=0 ; i<dataSetNbr ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				return(ret);
			}

			FREE(newEOTab);


			if ((ret = DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ParExtOp_Ext)) != RET_SUCCEED ||
				(ret = DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ChildExtOp_Ext)) != RET_SUCCEED)
			{
				for(i=0 ; i<dataSetNbr ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				return(ret);
			}

			if (DBA_MakeAllRecLinks(hierHead, ExtOp) != RET_SUCCEED)
			{
				for(i=0 ; i<dataSetNbr ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				return(ret);
			}

			ret = DBA_ExtractHierEltRecSupplFld(hierHead, ExtOp,
											 FALSE, NULLFCT, NULLFCT, NULLFCT,
											 &EONbr, &EOTab);
		}

		if (ret == RET_SUCCEED && EONbr > 0)
		{
			if (OrderGroupingModeEn == OrderGroupingMode_FinFct)
			{
				/* Send received function informations (dictFctInfo -> order grouping or sub-function) */
				/* Get the informations of the function associated to the domain format (order list fct or sub-function) -> OLDictFctInfo*/
				if (FMT_GetFormatFunction(domainArg, &OLDictFct) == RET_SUCCEED &&
					DBA_GetDictFctInfo(OLDictFct, DictFctInfo_Stp, &OLDictFctInfo) != RET_SUCCEED)
				{
					ret = RET_GEN_ERR_INVARG;	/* fmt or function(s) */
				}
			}
			else if (OrderGroupingModeEn == OrderGroupingMode_OrderAndProd)
			{
				OLDictFctInfo = dictFctInfo;
			}
			else
			{
				ret = RET_GEN_ERR_INVARG;
			}

			if (ret == RET_SUCCEED)
			{
				/* EOTab will contain the modified/created EOp */
				ret =  FMT_ExecOrderGrouping(pdictfct, OLDictFctInfo, domainArg, hierHead,
										 EOFldNbr,
										 fmtDataDefStp,
										 NULL, &EOTab, &EONbr,
										 FALSE,		/* rights not computed */
										 NULL, NULL,
										 FALSE);	/* don't keep checked status */

                FREE(EOTab); /* PMSTA-31804 - CHU - 180621 : memory leak */

                /*  HFI-PMSTA-27588-170803  All orders MUST ne saved not only the one modified by the order grouping fct    */
                ret = DBA_ExtractHierEltRec(hierHead,
                                            ExtOp,
                                            FALSE,
                                            NULLFCT,
                                            NULLFCT,
                                            &EONbr,
                                            &EOTab);
			}
		}

		/* An EO could be NULL, but FamilyOrder isn't able to treat it correctly (and crash) */
		newEONbr=0;
		if (EONbr > 0)
		{
			if ((newEOTab = (DBA_DYNFLD_STP*) CALLOC(EONbr, sizeof(DBA_DYNFLD_STP))) == NULL)
			{
				FREE(EOTab);

				if (OrderGroupingModeEn == OrderGroupingMode_FinFct)
				{
					for(i=0 ; i<dataSetNbr ; i++)
					{
						if(dataSet[i].scriptFilter != NULL)
							FREE(dataSet[i].scriptFilter);
						if(dataSet[i].colTypesTab != NULL)
							FREE(dataSet[i].colTypesTab);
						if(dataSet[i].dataDefTab != NULL)
							FREE(dataSet[i].dataDefTab);
					}
				}

				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			for (i=0, newEONbr=0; i<EONbr; i++)
			{
				if (EOTab[i] != NULLDYNST)
				{
					newEOTab[newEONbr] = EOTab[i];
					if (OrderGroupingModeEn == OrderGroupingMode_OrderAndProd)
					{
                        if (IS_NULLFLD(newEOTab[newEONbr], ExtOp_FctResultId) == TRUE)  /* OCS-49265 - CHU - 170215 */
							SET_ID(newEOTab[newEONbr], ExtOp_FctResultId, fctResultId);

                        if (!OPE_OrderIsBlock(newEOTab[newEONbr]) &&
                            !(initialFctDict              == DictFct_OrderGrouping &&
                              dictFctInfo->dictId         == DictFct_OrderGrouping &&
                              dictFctInfo->parFctDictId   == DictFct_OrderGrouping))
                        {
	                        /*  Already saved orders could not have the db status insert    */      /*  HFI-PMSTA-27588-170727  */
	                        /*  Else these orders will not be saved by DbaFamilyOrder       */
	                        if (IS_EXTOP_DATABASE_ID_PRESENT(newEOTab[newEONbr]) == TRUE)
	                        {
	    						SET_ENUM(newEOTab[newEONbr], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToUpdate);
	                        }
	                        else
	                        {
	    						SET_ENUM(newEOTab[newEONbr], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
	                        }
                        }

						if ((EVTGEN_ENUM)GET_ENUM(domainArg, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
						{
                            /*  Already saved orders could not have the db status insert    */      /*  HFI-PMSTA-27588-170727  */
                            /*  Else these orders will not be saved by DbaFamilyOrder       */
                            if (IS_EXTOP_DATABASE_ID_PRESENT(newEOTab[newEONbr]) == TRUE)
                            {
	    						SET_ENUM(newEOTab[newEONbr], ExtOp_DbStatusEn, ExtOpDbStatus_ToUpdate);
                            }
                            else
                            {
	    						SET_ENUM(newEOTab[newEONbr], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
                            }
						}
					}
					newEONbr++;
				}
			}
		}

		FREE(EOTab);

		/* Save in database */
		if (ret == RET_SUCCEED && newEONbr > 0)
		{
            DbiConnectionHelper  dbiConnHelper; /* PMSTA-26888 - CHU 170629 */

			ret = DBA_FamilyOrder(actionEn,
								(DBA_DYNFLD_STP*) newEOTab,
								newEONbr,0,
								NULL, (PTR) NULL,
                                DBA_NO_ERROR,
                                dbiConnHelper, /* PMSTA-26888 - CHU 170629 */
								GET_DICT(domainArg, A_Domain_FctDictId),
								domainArg,
								caseMgtTab, caseMgtNbr,	/* CaseManagement */ /* PMSTA07121-CHU-081030 */
								NULLDYNSTPTR,		/* PMSTA09118-CHU-100121 - draft FctRes */
                                (PTR)NULL,          /* PMSTA-28596 - CHU - 171012 */
                                splitSessionFlag);  /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
			FREE(newEOTab);
		}
	}

	if (OrderGroupingModeEn == OrderGroupingMode_FinFct)
	{
		for(i=0 ; i<dataSetNbr ; i++)
		{
			if(dataSet[i].scriptFilter != NULL)
				FREE(dataSet[i].scriptFilter);
			if(dataSet[i].colTypesTab != NULL)
				FREE(dataSet[i].colTypesTab);
			if(dataSet[i].dataDefTab != NULL)
				FREE(dataSet[i].dataDefTab);
		}
	}
	return(ret);
}

/************************************************************************
*
*  Function    : FIN_ExecuteOrderSwitching()
*
*  Description : Performs received format (in domain) on loaded ExtOp,
*				 executes order switching and save computed ExtOp in database
*
*  Arguments   : domainPtr      : pointer on a domain dynamic structure
*                hierHead       : hierarchy pointer
*				 initialFctDict	: initial function dict id (OrderSwitching or sub-function)
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation	   : PMSTA-37086 - Silpakal - 190905 - Fund Switch
*
*************************************************************************/
RET_CODE FIN_ExecuteOrderSwitching(DBA_DYNFLD_STP		    domainArg,
                                   DBA_HIER_HEAD_STP		hierHead,
                                   DICT_T					initialFctDict,
                                   DICT_FCT_STP		    	dictFctInfo,
                                   DBA_DYNFLD_STP			*caseMgtTab,
                                   int						caseMgtNbr,
                                   EXTOP_ACTION_ENUM		actionEn,
                                   bool					    splitSessionFlag
)
{
    RET_CODE				    ret = RET_SUCCEED;
    DICT_FCT_STP		    	oLDictFctInfo = NULL;
    DBA_DYNFLD_STP			    *eoTab = NULLDYNSTPTR;
    int						    eoNbr = 0, eoFldNbr = 0, i = 0;
    DICT_FCT_STP			    pdictfct = NULL;
    ORDER_SWITCHING_MODE_ENUM   OrderSwitchingModeEn = ORDER_SWITCHING_MODE_ENUM::OrderSwitchingMode_None;
    DICT_T                      fctResultId = 0;
    DBA_ERRMSG_HEADER_ST        msgStructHead;  /* PMSTA-37203 - Silpakal - 190924 */

    MemoryPool mp;

    if (IS_NULLFLD(domainArg, A_Domain_OrderSwitchingFctDictId) == FALSE)
    {
        OrderSwitchingModeEn = ORDER_SWITCHING_MODE_ENUM::OrderSwitchingMode_OrderAndProd;

        if (DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_DICT(domainArg, A_Domain_OrderSwitchingFctDictId), DictFctInfo_Stp, &pdictfct) != RET_SUCCEED ||
            pdictfct == NULL ||
            pdictfct->parFctDictId != DictFct_OrderSwitching)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ExecuteOrderSwitching", "A_Domain_OrderSwitchingFctDictId");
            ret = RET_GEN_ERR_INVARG;
            return (ret);
        }
        eoFldNbr = GET_FLD_NBR(ExtOp);
        fctResultId = GET_ID(domainArg, A_Domain_FctResultId);

    }
    /* Extract the records from hierarchy*/
    ret = DBA_ExtractHierEltRec(hierHead,
                                ExtOp,
                                FALSE,
                                NULLFCT,
                                NULLFCT,
                                &eoNbr,
                                &eoTab);

    if (ret == RET_SUCCEED && eoNbr > 0)
    {
        if (OrderSwitchingModeEn == ORDER_SWITCHING_MODE_ENUM::OrderSwitchingMode_OrderAndProd)
        {
            oLDictFctInfo = dictFctInfo;
        }
        else
        {
            ret = RET_GEN_ERR_INVARG;
        }

        /* EOTab will contain the modified/created EOp */
        ret = FMT_ExecOrderSwitching(pdictfct,
                                     oLDictFctInfo,
                                     domainArg,
                                     hierHead,
                                     eoFldNbr,
                                     &eoTab,
                                     &eoNbr,
                                     FALSE);

        FREE(eoTab);
    }

    if (ret == RET_SUCCEED)
    {
        ret = DBA_ExtractHierEltRec(hierHead,
                                    ExtOp,
                                    FALSE,
                                    NULLFCT,
                                    NULLFCT,
                                    &eoNbr,
                                    &eoTab);
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, 0, "FIN_ExecuteOrderSwitching : No switch orders present in the hierarchy");
        return ret;
    }

    /*  All orders must be saved along with the one modified by order switching function    */
    if (ret == RET_SUCCEED && eoNbr > 0)
    {
        for (i = 0; i < eoNbr; i++)
        {
            if (eoTab[i] != NULLDYNST)
            {
                if (OrderSwitchingModeEn == ORDER_SWITCHING_MODE_ENUM::OrderSwitchingMode_OrderAndProd)
                {
                    if (IS_NULLFLD(eoTab[i], ExtOp_FctResultId) == TRUE)
                        SET_ID(eoTab[i], ExtOp_FctResultId, fctResultId);

                    if (!(initialFctDict == DictFct_OrderSwitching &&
                        dictFctInfo->dictId == DictFct_OrderSwitching &&
                        dictFctInfo->parFctDictId == DictFct_OrderSwitching))
                    {
                        /* Modify db status for the generated ExtOp, else these orders will not be saved in by DbaFamilyOrder  */
                        if (IS_EXTOP_DATABASE_ID_PRESENT(eoTab[i]) == TRUE)
                        {
                            SET_ENUM(eoTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToUpdate);
                        }
                        else
                        {
                            SET_ENUM(eoTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
                        }
                    }

                    if ((EVTGEN_ENUM)GET_ENUM(domainArg, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
                    {
                        /* Modify db status for the generated ExtOp, else these orders will not be saved in by DbaFamilyOrder */
                        if (IS_EXTOP_DATABASE_ID_PRESENT(eoTab[i]) == TRUE)
                        {
                            SET_ENUM(eoTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToUpdate);
                        }
                        else
                        {
                            SET_ENUM(eoTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
                        }
                    }
                }
            }
        }
    }

    /* PMSTA-37203 - Silpakal - 190924 */
    /* Save created switch orders in the database */
    if (ret == RET_SUCCEED && eoNbr > 0)
    {
        DbiConnectionHelper  dbiConnHelper;

        ret = DBA_FamilyOrder(actionEn,
                             (DBA_DYNFLD_STP*)eoTab,
                             eoNbr, 0,
                             NULL, (PTR)NULL,
                             DBA_NO_ERROR,
                             dbiConnHelper,
                             GET_DICT(domainArg, A_Domain_FctDictId),
                             domainArg,
                             caseMgtTab,
                             caseMgtNbr,
                             NULLDYNSTPTR,
                             (PTR)NULL,
                             splitSessionFlag
                            );
    }
    FREE(eoTab);

    return(ret);
}
/************************************************************************
*
*  Function    : FIN_AnalysisUpdateField()
*
*  Description : Performs received format (in domain) on loaded ExtOp,
*				 executes update field and save computed ExtOp in database
*
*  Arguments   : domainPtr      : pointer on a domain dynamic structure
*                hierHead       : hierarchy pointer
*				 initialFctDict	: initial function dict id (OrderGrouping or sub-function)
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : HFI-PMSTA-35324-190328
*
*************************************************************************/
RET_CODE  FIN_AnalysisUpdateField ( DBA_DYNFLD_STP       domainArg,
                                    DBA_HIER_HEAD_STP    hierHead,
                                    DICT_T               initialFctDict,
                                    DICT_FCT_STP         dictFctInfo)
{
    DBA_DYNFLD_STP          *pdbadyntab = NULL;
    int                     iNbData = 0;
    RET_CODE                retCode = RET_SUCCEED;

    /*  test input parameters                                           */
    if ((hierHead == NULL) ||
        (dictFctInfo == NULL))
    {
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_AnalysisUpdateField", "A_Domain_OrderGroupingFctDictId");
			return RET_GEN_ERR_INVARG;
    }

    /*  Extract data table from hierarchy                               */
    if (((retCode = DBA_ExtractHierEltRec(hierHead, ExtOp,FALSE,NULL,NULL,&iNbData,&pdbadyntab)) != RET_SUCCEED) ||
        (pdbadyntab == NULL) &&
        (iNbData < 1))
        return retCode;

    /*  Apply script on orders                                          */
    if (retCode == RET_SUCCEED)
    {
        retCode = FMT_ExecScripFct(dictFctInfo,
                                   EOp,
                                   pdbadyntab,
                                   NULL,
                                   NULL,
                                   iNbData,
                                   NULL,
                                   hierHead,
                                   TRUE,            /* PMSTA-37308 - AIS - 190924 */
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL);
    }

    /*  Save orders in databse                                          */
	if (retCode == RET_SUCCEED && iNbData > 0)
	{
        DbiConnectionHelper  dbiConnHelper; /* PMSTA-26888 - CHU 170629 */

		retCode = DBA_FamilyOrder ( Action_SaveOp,
                                    pdbadyntab,                                 /*  table of orders                         */
                                    iNbData,                                    /*  Number of orders to save                */
                                    0,                                          /*  Number of column: 0 = real data         */
                                    NULL,                                       /*  GUI function                            */
                                    NULL,                                       /*  input parameter for GUI function        */
                                    DBA_NO_ERROR,                               /*  Options                                 */
                                    dbiConnHelper,                              /*  Connection                              */
                                    GET_DICT(domainArg, A_Domain_FctDictId),    /*  Run function: normally order list       */
                                    domainArg,                                  /*  Given domain                            */
                                    NULL,                                       /*  Case table: no management of case       */
                                    0,	                                        /*  Number of caes: no management of case   */
                                    NULLDYNSTPTR,		                        /*  Draft Function result                   */
                                    hierHead,                                   /*  Given Hiearchy                          */
                                    FALSE);                                     /*  Session splitting management            */
	}
    FREE(pdbadyntab);

    return RET_SUCCEED;
}


/************************************************************************
*
*  Function    : FIN_AnalysisOrderGrouping()
*
*  Description : Performs received format (in domain) on loaded ExtOp,
*				 executes order grouping and save computed ExtOp in database
*
*  Arguments   : domainPtr      : pointer on a domain dynamic structure
*                hierHead       : hierarchy pointer
*				 initialFctDict	: initial function dict id (OrderGrouping or sub-function)
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF11764 - RAK - 060404
*
*  Modif       : PMSTA15221-CHU-121214 : embedded coded in new function for use in O&P
*
*************************************************************************/
RET_CODE FIN_AnalysisOrderGrouping(DBA_DYNFLD_STP		domainArg,
                                   DBA_HIER_HEAD_STP	hierHead,
								   DICT_T				initialFctDict,
								   DICT_FCT_STP			dictFctInfo)
{
	return (FIN_ExecuteOrderGrouping(domainArg, hierHead,
									 initialFctDict, dictFctInfo,
									 NULLDYNSTPTR, 0,
									 Action_SaveOp,
                                     false)); /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
}

/************************************************************************
*
*  Function    : FIN_AnalysisInitiateOrder()
*
*  Description : Performs received format (in domain) on loaded ExtPos,
*				 executes initiate order and save computed ExtOp in database
*
*  Arguments   : domainPtr      : pointer on a domain dynamic structure
*                hierHead       : hierarchy pointer
*				 initialFctDict	: initial function dict id ()
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation    : DLA - PMSTA08645
*   Modif       :   HFI-PMSTA-49593-220817  Use memory pool
*
*************************************************************************/
RET_CODE FIN_AnalysisInitiateOrder(DBA_DYNFLD_STP        domainArg,
								   DBA_HIER_HEAD_STP     hierHead,
								   DICT_T				 initialFctDict,
								   DICT_FCT_STP          dictFctInfo,
                                   FLAG_T                useFormatFilter)
{
	RET_CODE				ret=RET_SUCCEED;
	DBA_DYNFLD_STP			*recTab=NULLDYNSTPTR, *sumFmtEltTab=NULLDYNSTPTR, *newRecTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP          *tabRes=NULLDYNSTPTR, aFmtSt=NULLDYNST, *recTabFiltered=NULLDYNSTPTR;
	int						i=0, j=0, recNbr=0, fmtEltNbr=0, dataSetNbr=0, fmtEltNbOut=0, recFldNbr=0,iNb=0;
	int                     filterColIdx=-1;
    SCPT_FMTDATADEF_ST		fmtDataDefSt;
	SCPT_DATASET_ST			dataSet[10];
	DICT_ATTRIB_STP			attribSt;
	ID_T					langDictId;
    DBA_DYNST_ENUM          dynStEnum=NullEntityCst;
    OBJECT_ENUM             object;
    CODE_T                  filterCode;
    MemoryPool              mp;                     /*  HFI-PMSTA-49593-220817  */

	memset(dataSet, 0, 10*sizeof(SCPT_DATASET_ST));
    memset(filterCode,0,sizeof(CODE_T));

	if(SYS_IsStateShutdownRequested())
    {   /* PMSTA-54362 - JBC - 30112023 */
        return RET_SYS_ERR_SIGINT;
    }

  	if (IS_NULLFLD(domainArg, A_Domain_FmtId) == TRUE)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
               		 "FIN_AnalysisInitiateOrder", "no format in domain");
    	return(RET_GEN_ERR_INVARG);
	}

	/* Get Fmt and init fmtDataDefSt with it */
    DBA_DYNFLD_STP  sFmtSt = mp.allocDynst(FILEINFO, S_Fmt);
	if (sFmtSt == nullptr)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Fmt");
        return(RET_MEM_ERR_ALLOC);
	}

    aFmtSt = mp.allocDynst(FILEINFO, A_Fmt);
	if (aFmtSt == nullptr)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Fmt");
        return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(sFmtSt, Get_Arg_Id, GET_ID(domainArg, A_Domain_FmtId));

	if (DBA_Get2(Fmt, UNUSED, S_Fmt, sFmtSt, A_Fmt, &aFmtSt,
                 UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
    {
		fmtDataDefSt.aFormat = aFmtSt;
	}
	else
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
               		 "FIN_AnalysisInitiateOrder", "format in domain not valid");

    	return(RET_GEN_ERR_INVARG);
	}

	/* Select FmtElt */
    DBA_DYNFLD_STP  getArgSt = mp.allocDynst(FILEINFO, Get_Arg);
	if (getArgSt == nullptr)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
        return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(getArgSt, Get_Arg_Id, GET_ID(domainArg, A_Domain_FmtId));

	/***** SEARCH attribute_dict_id for format_element.script_definition field *****/
    if (DBA_SearchAttribSqlName( FmtElt, "script_definition", &attribSt) != RET_SUCCEED)
    {
		return(ret);
    }
    SET_ID(getArgSt, Get_Arg_AttribDictId, attribSt->attrDictId);


	if (GET_ID(domainArg, A_Domain_LangDictId) == 0)
	{
		DBA_GetUserInfo2(A_ApplUser_LangDictId, &langDictId, TRUE); /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
	}
	else
	{
		langDictId = GET_ID(domainArg, A_Domain_LangDictId);
	}

	SET_ID(getArgSt, Get_Arg_LangDictId, langDictId);

	if (DBA_Select2(FmtElt,
                    UNUSED,
                    Get_Arg,
                    getArgSt,
                    Sum_FmtElt,
                    &sumFmtEltTab,
                    UNUSED,
                    UNUSED,
                    &fmtEltNbr,
                    UNUSED,
                    UNUSED ) != RET_SUCCEED)
    {
		return(ret);
	}

	if (SCPT_FmtEltAnalyse(&sumFmtEltTab,
                           fmtEltNbr,
						   (FIN_FCT_OUTPUT_ENUM)GET_ENUM(domainArg, A_Domain_OutputTpEn),
						   dataSet,
                           &dataSetNbr,
						   &fmtEltNbOut,
                           SERV_IsGuiConnect(),
                           TRUE) == FALSE)
    {
		return(RET_SCPT_ERR_FCT_FAILED);
	}
    mp.ownerDynStpTab(sumFmtEltTab, fmtEltNbOut);

	fmtDataDefSt.dataDefTab   = dataSet[0].dataDefTab;
	fmtDataDefSt.sumFmtEltTab = sumFmtEltTab;
	fmtDataDefSt.fmtId        = GET_ID(domainArg, A_Domain_FmtId);
	fmtDataDefSt.nbCol        = dataSet[0].colNb;
    fmtDataDefSt.colIdx       = dataSet[0].colNb-1;
	fmtDataDefSt.dataSetIndex = 0;

	/* DDV - the format must be set to make reference working when evaluating ExtOp DV */
	for (i=0; i < fmtDataDefSt.nbCol; i++)
	{
			fmtDataDefSt.dataDefTab[i].fmtId=fmtDataDefSt.fmtId;
	}

    /*Find filter fmtElt if provided */
    if (useFormatFilter == TRUE && GET_CODE(aFmtSt, A_Fmt_Filter) != NULL )
    {
        strcpy(filterCode, GET_CODE(aFmtSt, A_Fmt_Filter));
        for (i=0; i<fmtEltNbr;i++)
        {
   			if (strcmp( GET_SYSNAME(sumFmtEltTab[i], Sum_FmtElt_SqlName) , filterCode) == 0)
			{
                filterColIdx = GET_INT(sumFmtEltTab[i],Sum_FmtElt_ColNb) -1;
				break;
			}
        }
    }

    DBA_GetObjectEnum(GET_DICT(aFmtSt, A_Fmt_EntityDictId), &object);
    dynStEnum = GET_EDITGUIST(object);

	if ((ret = DBA_ExtractHierEltRec(hierHead,
									dynStEnum,  /* PMSTA-13295 - JPP - 20120207 */
									FALSE,
									NULLFCT,
									NULLFCT,
									&recNbr,
									&recTab)) == RET_SUCCEED && recNbr > 0)
	{
		/* Create record with supplementary fields */
		recFldNbr = fmtDataDefSt.nbCol;

		if ((newRecTab = (DBA_DYNFLD_STP*) CALLOC(recNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
		{
			FREE(recTab);

			for(i=0 ; i<dataSetNbr ; i++)
			{
				if(dataSet[i].scriptFilter != NULL)
					FREE(dataSet[i].scriptFilter);
				if(dataSet[i].colTypesTab != NULL)
					FREE(dataSet[i].colTypesTab);
				if(dataSet[i].dataDefTab != NULL)
					FREE(dataSet[i].dataDefTab);
			}
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		for (i=0; i<recNbr; i++)
		{
			newRecTab[i] = ALLOC_DYNST_SUPPLFLD(dynStEnum, recFldNbr);
			if (newRecTab[i] == NULLDYNST)
			{
				FREE(recTab);
				for (j=0; j<i; j++)
				{ FREE_DYNST_SUPPLFLD(newRecTab[j], recFldNbr);}
				FREE(newRecTab);
				FREE(recTab);

				for(i=0 ; i<dataSetNbr ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				ret = RET_MEM_ERR_ALLOC;
				MSG_SendMesg(ret, 2, FILEINFO, "%s with supplementary fld", dynStEnum);

				return(ret);
			}

			COPY_DYNST(newRecTab[i], recTab[i], dynStEnum);
		}

        /*  Replace calls to DBA_DelAndFreeHierEltRec by one unique call to DBA_FreeHierEltRecord   */  /*  HFI-PMSTA-48805-220411  */
		if ((ret = DBA_FreeHierEltRecord(hierHead, dynStEnum)) != RET_SUCCEED)
		{
			for (j=0; j<=i; j++)
			{ FREE_DYNST_SUPPLFLD(newRecTab[j], recFldNbr);}
			FREE(newRecTab);
			FREE(recTab);

			for(i=0 ; i<dataSetNbr ; i++)
			{
				if(dataSet[i].scriptFilter != NULL)
					FREE(dataSet[i].scriptFilter);
				if(dataSet[i].colTypesTab != NULL)
					FREE(dataSet[i].colTypesTab);
				if(dataSet[i].dataDefTab != NULL)
					FREE(dataSet[i].dataDefTab);
			}
			return(ret);
		}
		FREE(recTab);

		if ((ret = DBA_AddHierRecordSupplFldList(hierHead, newRecTab, recNbr, dynStEnum, recFldNbr, FALSE)) != RET_SUCCEED)
		{
			for (j=0; j<recNbr; j++)
			{
				FREE_DYNST_SUPPLFLD(newRecTab[j], recFldNbr);
			}
			FREE(newRecTab);

			for(i=0 ; i<dataSetNbr ; i++)
			{
				if(dataSet[i].scriptFilter != NULL)
					FREE(dataSet[i].scriptFilter);
				if(dataSet[i].colTypesTab != NULL)
					FREE(dataSet[i].colTypesTab);
				if(dataSet[i].dataDefTab != NULL)
					FREE(dataSet[i].dataDefTab);
			}
			return(ret);
		}

        FREE(newRecTab);

		if ((ret = DBA_ExtractHierEltRecSupplFld(hierHead, dynStEnum,  /* PMSTA-13295 - JPP - 20120207 */
									     FALSE, NULLFCT, NULLFCT, NULLFCT,
									     &recNbr, &recTab)) == RET_SUCCEED && recNbr > 0)
		{
            int idx=0;

            ret   =  SCPT_ComputeSupplFmtDataDefField ( dynStEnum,
                                                        recTab,
                                                        recNbr,
                                                        &fmtDataDefSt, 
                                                        hierHead); /* PMSTA-43644 - DDV - 210217 - Add hierarchy for TOT_ function */

            /* Format Filtering */
            if (useFormatFilter == TRUE && filterColIdx >= 0)
            {
                if ((recTabFiltered = (DBA_DYNFLD_STP*) CALLOC(recNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
                {
			        FREE(recTab);

			        for(i=0 ; i<dataSetNbr ; i++)
			        {
				        if(dataSet[i].scriptFilter != NULL)
					        FREE(dataSet[i].scriptFilter);
				        if(dataSet[i].colTypesTab != NULL)
					        FREE(dataSet[i].colTypesTab);
				        if(dataSet[i].dataDefTab != NULL)
					        FREE(dataSet[i].dataDefTab);
			        }
			        MSG_RETURN(RET_MEM_ERR_ALLOC);

                }

                for(i=0; i < recNbr; i++)
                {
                    if(IS_NULLFLD(recTab[i],filterColIdx) == FALSE  &&
                       GET_FLAG(recTab[i],filterColIdx) > 0)
                    {
                        recTabFiltered[idx] = recTab[i];
                        idx++;
                    }
                }

                FREE(recTab);

                recTab = recTabFiltered;
                recNbr = idx;
            }

            ret   =  FMT_ExecInitiateOrder (dictFctInfo,
											hierHead,
											recFldNbr,
											&fmtDataDefSt,
											recTab,
											recNbr,
											object,
											NULL,
											&tabRes,
											&iNb,
    										1);
		}
	}
	FREE(recTab);


    if (ret == RET_SUCCEED && iNb > 0)
        ret = DBA_AddHierRecordList(hierHead,
                                    tabRes,
                                    iNb,
                                    ExtOp,
                                    FALSE);


	/* Save in database if automatic mode*/
	if (ret == RET_SUCCEED && iNb > 0 && GET_ENUM(domainArg, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
	{
		DBA_ACCESS_STP ExtOpAccessPtr;
        OPSTAT_ENUM    accountingStatus;
        FLAG_T         launchFusion=FALSE;
        int            nbAccess=0, connectNo=DBA_CONN_NOT_FOUND;
		i = 0;

        GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

		if ((ExtOpAccessPtr = (DBA_ACCESS_STP)CALLOC(iNb, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			FREE(ExtOpAccessPtr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		for ( i=0;i<iNb;i++)
		{
            if ( tabRes[i] != NULL && GET_FLAG(tabRes[i], ExtOp_ConfirmedFlg) == TRUE )
            {
                ExtOpAccessPtr[nbAccess].action = Insert;
                ExtOpAccessPtr[nbAccess].role   = UNUSED;
                ExtOpAccessPtr[nbAccess].object = EOp;
                ExtOpAccessPtr[nbAccess].entity = ExtOp;
                ExtOpAccessPtr[nbAccess].data   = tabRes[i];
                nbAccess++;

                if (GET_ENUM(tabRes[i], ExtOp_StatusEn) >= accountingStatus)
                    launchFusion = TRUE;

            }
		}

        if ( nbAccess > 0 )
        {
            DbaMultiAccessHelper       multiAccessHelper(ExtOpAccessPtr, nbAccess);
            
            ret = multiAccessHelper.callMultiAccess(nbAccess, UNUSED, UNUSED, true);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                multiAccessHelper.sendAllMultiAccessMsg();
            }

            if (launchFusion == TRUE)
			{
                if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
                {
                    MSG_LogMesg( RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					                                 "Unable to launch fusion in FIN_AnalysisInitiateOrder");
                }
				else
                {
					if(DBA_FusionRequestAllPtfNewOp(DBA_SET_CONN|DBA_NO_CLOSE, connectNo) != RET_SUCCEED)
                    {
                        MSG_LogMesg( RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					                 "Unable to launch fusion in FIN_AnalysisInitiateOrder");
                    }
                }
                DBA_EndConnection(connectNo);
			}
        }

		FREE(newRecTab);
		FREE(ExtOpAccessPtr);
	}


	for(i=0 ; i<dataSetNbr ; i++)
	{
		if(dataSet[i].scriptFilter != NULL)
			FREE(dataSet[i].scriptFilter);
		if(dataSet[i].colTypesTab != NULL)
			FREE(dataSet[i].colTypesTab);
		if(dataSet[i].dataDefTab != NULL)
			FREE(dataSet[i].dataDefTab);
	}

    if (tabRes != nullptr)      /*  HFI-PMSTA-49596-220817  */
    {
        FREE(tabRes);
    }

	return(ret);
}


/************************************************************************
*
*  Function    : FIN_AnalysisOpSearchPhase2()
*
*  Description : Retrieve a hierarchy (ExtPos hierarchy), read Extended
*                operation and manage Parent-Child operations to load
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF2467 - DDV - 000118
*  Last modif. : PMSTA01421 -BER - 070402
*
*************************************************************************/
RET_CODE FIN_AnalysisOpSearchPhase2(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP  *parentExtOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  *childExtOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
    CODE_T          opCode;
	int             i, j, parentExtOpNbr, childExtOpNbr=0;
    int             opByBatchNbr = 0, opRowCount = 0;
    int             remainOpNbr = 0, extOpNbr = 0;
	DbiConnection*	dbiConn;
	NUMBER_T        qty;
    FLAG_T          loadChildFlg = FALSE, loadParentFlg = FALSE, matchSrcCdFlg = FALSE;
	RET_CODE        ret=RET_SUCCEED;
	char            *buffer = NULL,
					*bufferDel = NULL;		/* PMSTA-20159 - TEB - 151110 */
    DATETIME_T      tmpDate;
	int             recNbLimit = 50;
	int             curBlocRecNb = 0;
	DbiSqlExecByBlock sqlExec(50);			/* PMSTA-20159 - TEB - 151110 */

	/* Check arguments */
	if (hierHead == (PTR)NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_AnalysisOrderList", "hierHead");
		return(RET_GEN_ERR_INVARG);
	}

    GEN_GetApplInfo(ApplOpSearchNbOpByBatch, &opByBatchNbr);
    GEN_GetApplInfo(ApplOpSearchRetRowCount, &opRowCount);

    /* REF7560 - DDV - Remove duplicate ExtOp (accounted operation loaded from ext_order (untreated) and operation) */
    FIN_RemoveDuplicateExtOp(hierHead);

    /* Check number of ExtOp allready created */
    DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, NULLFCT, NULLFCT,
                          &extOpNbr, &extOpTab);

    DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, FIN_FilterParentOrder, NULLFCT,
                          &parentExtOpNbr, &parentExtOpTab);

    DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, FIN_FilterChildOrder, NULLFCT,
                          &childExtOpNbr, &childExtOpTab);

    if (parentExtOpNbr > 0 &&
        (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) == LoadGlobalOrder_Child ||
         GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) == LoadGlobalOrder_ParentAndChild))
        loadChildFlg = TRUE;

    if (childExtOpNbr > 0  &&
        (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) == LoadGlobalOrder_Parent ||
         GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) == LoadGlobalOrder_ParentAndChild))
        loadParentFlg = TRUE;

    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
    {
        FREE(childExtOpTab);
        FREE(parentExtOpTab);
        FREE(extOpTab);
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

    /* Get all parents and childs if needed (only if number of extop is not bigger as opRowCount) */
    if (extOpNbr < opRowCount &&
        (loadParentFlg == TRUE ||
         loadChildFlg == TRUE))
    {
		/* PMSTA-20159 - TEB - 151110 */
        if ((buffer = (char *)CALLOC(512, sizeof (char))) == NULL) /* REF7264 - LJE - 020128 */
        {
            FREE(childExtOpTab);
            FREE(parentExtOpTab);
            FREE(extOpTab);
            DBA_EndConnection(&dbiConn);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return(RET_MEM_ERR_ALLOC);
        }

        /* create all needed temporary tables */
        if ((ret = DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER)) != RET_SUCCEED)
        {
            FREE(buffer);
            FREE(childExtOpTab);
            FREE(parentExtOpTab);
            FREE(extOpTab);
			DBA_EndConnection(&dbiConn);
            return(ret);
        }

        /* get all parents */
        if (loadParentFlg == TRUE)
        {
            buffer[0] = END_OF_STRING;

            /* Fill #tmp_oper with all parent_oper_code, seq_n and status of child operations */
			for (i = 0; i < childExtOpNbr; i++)
			{
				/*  PMSTA01421 - BER - 070402 */

				/*  PMSTA01421 is Sun OS SUNW Compiler specific issue. The SUNW Compiler is trying a read a string
					even though a NULL is sent to the sprintf() format string through "%s" and hence, crashing.This
					conflict has to be removed, to check
					"if (IS_NULLFLD(childExtOpTab[i],ExtOp_ParOpCd ) == FALSE)"  */

				if (IS_NULLFLD(childExtOpTab[i], ExtOp_ParOpCd) == FALSE)
				{
					/* PMSTA-20159 - TEB - 151110 */
					if (IS_NULLFLD(childExtOpTab[i], ExtOp_SequenceNo) == TRUE)
						sprintf(buffer, "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',null,%d,%d)\n", /* PMSTA-20159 - TEB - 150624 */  /* PMSTA-25656 - TEB - 161215 */
						GET_CODE(childExtOpTab[i], ExtOp_ParOpCd),
						GET_ENUM(childExtOpTab[i], ExtOp_StatusEn),
						GET_ENUM(childExtOpTab[i], ExtOp_FusionEn));
					else
						sprintf(buffer, "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',%f,%d,%d)\n", /* PMSTA-20159 - TEB - 150624 */ /* PMSTA-25656 - TEB - 161215 */
						GET_CODE(childExtOpTab[i], ExtOp_ParOpCd),
						GET_NUMBER(childExtOpTab[i], ExtOp_SequenceNo),
						GET_ENUM(childExtOpTab[i], ExtOp_StatusEn),
						GET_ENUM(childExtOpTab[i], ExtOp_FusionEn));

					sqlExec.addSql(buffer);		/* PMSTA-20159 - TEB - 151110 */
				}
			}

			if ((ret = sqlExec.execSqlExecByBloc(dbiConn)) != RET_SUCCEED)	/* PMSTA-20159 - TEB - 151110 */
            {
                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
				if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");	/* PMSTA-20159 - TEB - 151110 */
				DBA_EndConnection(&dbiConn);
                return(ret);
            }

            /* Call notif to fill #dom_oper with parent id using #tmp_oper */
            if ((ret = DBA_Notif2(Op,
                                  DBA_ROLE_INIT_PARENT,
                                  NullDynSt,
                                  NULLDYNST,
                                  DBA_SET_CONN|DBA_NO_CLOSE,
								  (int*)&dbiConn->getId(),
                                  UNUSED)) != RET_SUCCEED)
            {
                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(
                        RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					        "DBA_CreateTempTables failed");
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
            if ((ret = DBA_CreateTempTables(*dbiConn, TMP_OPER)) != RET_SUCCEED)
            {
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");

                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
        }

        /* get all childs */
        if (loadChildFlg == TRUE)
        {
            buffer[0] = END_OF_STRING;
            GEN_GetApplInfo(ApplMatchSourceCdFlag, &matchSrcCdFlg);

            /* Fill #tmp_oper with all parent code (or source_code), seq_n and status of parent operations */
            for (i=0; i < parentExtOpNbr; i++)
            {
                opCode[0]=END_OF_STRING;
                if(matchSrcCdFlg == TRUE &&
                   IS_NULLFLD(parentExtOpTab[i], ExtOp_SrcCd) == FALSE)
                    strcpy(opCode, GET_CODE(parentExtOpTab[i], ExtOp_SrcCd));
                else if (IS_NULLFLD(parentExtOpTab[i], ExtOp_Cd) == FALSE)
                    strcpy(opCode, GET_CODE(parentExtOpTab[i], ExtOp_Cd));

                if (opCode[0] != END_OF_STRING)
                {	/* PMSTA-20159 - TEB - 151110 */
                    if (IS_NULLFLD(parentExtOpTab[i], ExtOp_SequenceNo) == TRUE)
                        sprintf(buffer, "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',null,%d,%d)\n", /* PMSTA-20159 - TEB - 150624 */ /* PMSTA-25656 - TEB - 161215 */
                                opCode,
                                GET_ENUM(parentExtOpTab[i], ExtOp_StatusEn),
                                GET_ENUM(parentExtOpTab[i], ExtOp_FusionEn));
                    else
                        sprintf(buffer, "insert into #tmp_oper (id,code,sequence_no_n,status_e,fusion_e) values(null,\'%s\',%f,%d,%d)\n", /* PMSTA-20159 - TEB - 150624 */ /* PMSTA-25656 - TEB - 161215 */
                                opCode,
                                GET_NUMBER(parentExtOpTab[i], ExtOp_SequenceNo),
                                GET_ENUM(parentExtOpTab[i], ExtOp_StatusEn),
                                GET_ENUM(parentExtOpTab[i], ExtOp_FusionEn));

					sqlExec.addSql(buffer);		/* PMSTA-20159 - TEB - 151110 */
                }
            }

            if ((ret = sqlExec.execSqlExecByBloc(dbiConn)) != RET_SUCCEED)	/* PMSTA-20159 - TEB - 151110 */
            {
                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                DBA_EndConnection(&dbiConn);
                return(ret);
            }

            buffer[0] = END_OF_STRING;


            /* Call notif to fill #dom_oper with children id using #tmp_oper */
            if ((ret = DBA_Notif2(Op,
                                  DBA_ROLE_INIT_CHILDREN,
                                  NullDynSt,
                                  NULLDYNST,
                                  DBA_SET_CONN|DBA_NO_CLOSE,
								  (int*)&dbiConn->getId(),
                                  UNUSED)) != RET_SUCCEED)
            {
                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(
                        RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					        "DBA_CreateTempTables failed");
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
            if ((ret = DBA_CreateTempTables(*dbiConn, TMP_OPER)) != RET_SUCCEED)
            {
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");

                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
        }

        buffer[0] = END_OF_STRING;
		curBlocRecNb = 0;

		/* PMSTA-20159 - TEB - 151110 */
		if ((bufferDel = (char *)CALLOC(2048, sizeof (char))) == NULL) /* REF7264 - LJE - 020128 */
		{
			FREE(buffer);
			FREE(childExtOpTab);
			FREE(parentExtOpTab);
			FREE(extOpTab);
			DBA_EndConnection(&dbiConn);
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			return(RET_MEM_ERR_ALLOC);
		}
		bufferDel[0] = END_OF_STRING;

		/* remove from #dom_oper all operations allready loaded in hierarchy */
        for (i=0; i < extOpNbr; i++)
        {
            if((curBlocRecNb%recNbLimit) == 0)
            {
				sprintf(bufferDel + strlen(bufferDel), "delete from #dom_oper where id in (");		/* PMSTA-20159 - TEB - 151110 */
            }

			sprintf(bufferDel + strlen(bufferDel), "%" szFormatId, DBA_GetOpIdFromExtOp(extOpTab[i])), /* PMSTA-20159 - TEB - 151110 */ /* DLA - PMSTA08801 - 100209 */

            curBlocRecNb++;

            if((curBlocRecNb%recNbLimit) == 0)
            {
				sprintf(bufferDel + strlen(bufferDel), ")");					/* PMSTA-20159 - TEB - 151110 */
				if ((ret = DBA_SqlExec(bufferDel, *dbiConn)) != RET_SUCCEED)	/* PMSTA-20159 - TEB - 151110 */
                {
					FREE(bufferDel);	/* PMSTA-20159 - TEB - 151110 */
                    FREE(buffer);
                    FREE(childExtOpTab);
                    FREE(parentExtOpTab);
                    FREE(extOpTab);
                    if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                    DBA_EndConnection(&dbiConn);
                    return(ret);
                }
				bufferDel[0] = END_OF_STRING;
            }
            else if ((i+1) < extOpNbr)
				sprintf(bufferDel + strlen(bufferDel), ",");
        }

        if((curBlocRecNb%recNbLimit) != 0)
        {
			sprintf(bufferDel + strlen(bufferDel), ")");
			if ((ret = DBA_SqlExec(bufferDel, *dbiConn)) != RET_SUCCEED)
            {
				FREE(bufferDel);
                FREE(buffer);
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
			bufferDel[0] = END_OF_STRING;
        }

		FREE(bufferDel);
		FREE(buffer);

        /* Select Operations, positions, portfolios */
        /* and instruments by batch until #dom_oper is empty or */
        /* number of extop is bigger as ApplOpSearchRetRowCount */

        /* REF7560 - DDV - 020603 - Load abd filter all operations from table ext_order */
        DBA_LoadOrders(&hierHead, domainPtr, FALSE, *dbiConn);

        remainOpNbr = opByBatchNbr;

        while (remainOpNbr >0 && extOpNbr < opRowCount)
        {
            if ((ret = DBA_LoadOperByBatch(&hierHead, /* REF7264 - LJE - 020128 */
                                           domainPtr,
                                           FALSE, /* DON'T filter ExtOp */
                                           &remainOpNbr,
                                           &extOpNbr,
										   *dbiConn)) != RET_SUCCEED)
            {
                FREE(childExtOpTab);
                FREE(parentExtOpTab);
                FREE(extOpTab);
                if (DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER) != RET_SUCCEED)
   			        MSG_LogMesg(
                        RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					        "DBA_CreateTempTables failed");
                DBA_EndConnection(&dbiConn);
                return(ret);
            }

        }

        /* Truncate temporary tables and free connection */
        if ((ret = DBA_CreateTempTables(*dbiConn, DOM_OPER | TMP_OPER)) != RET_SUCCEED)
        {
   			MSG_LogMesg(
                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_CreateTempTables failed");
            FREE(childExtOpTab);
            FREE(parentExtOpTab);
            FREE(extOpTab);
            DBA_EndConnection(&dbiConn);
            return(ret);
        }
    }

    FREE(childExtOpTab);
    FREE(parentExtOpTab);
    FREE(extOpTab);


    /* REF7560 - DDV - 020617 - Load extended execution (execution and execution fees for all orders matching */
    if (GET_FLAG(domainPtr, A_Domain_ExecDetailsFlg) == TRUE)
		DBA_LoadExtExecutions(hierHead, domainPtr, (int*)&dbiConn->getId());

    DBA_EndConnection(&dbiConn);

    /* REF5493 - DDV - 010208 - Put back null value in from or till date if needed */
    tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    if (tmpDate.date == MAGIC_END_DATE)
        SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

    tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
    if (tmpDate.date == MAGIC_END_DATE)
        SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

    /* make links on instrument and portfolio */
	DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_A_Instr_Ext);
	DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_A_Ptf_Ext);

	/* Extract all parent orders and fill the field "effective_qty" with the sum
	   of each child quantity, but only if LoadGlobalOrderEn is not NoFamily */
    if (GET_ENUM(domainPtr, A_Domain_LoadGlobOrderEn) != LoadGlobalOrder_NoFamily)
    {
	    DBA_SetHierLnkUsed(hierHead,    ExtOp, ExtOp_ChildExtOp_Ext);
	    DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_ChildExtOp_Ext);

        DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, FIN_FilterParentOrder, NULLFCT,
	                          &parentExtOpNbr, &parentExtOpTab);

	    for (i=0 ; i<parentExtOpNbr ; i++)
    	{
            if (GET_ENUM(parentExtOpTab[i], ExtOp_ExecOpNatEn) > ExecNat_Partial)
            {
                qty = GET_NUMBER(parentExtOpTab[i], ExtOp_Qty);
                SET_NUMBER(parentExtOpTab[i], ExtOp_EffectChildQty, qty);
                continue;
            }

		    childExtOpTab = GET_EXTENSION_PTR(parentExtOpTab[i], ExtOp_ChildExtOp_Ext);
		    qty = 0;

		    for (j=0 ; j<GET_EXTENSION_NBR(parentExtOpTab[i], ExtOp_ChildExtOp_Ext) ; j++)
		    {
                if (GET_ENUM(childExtOpTab[j], ExtOp_ExecOpNatEn) > ExecNat_Partial)
                    continue;

                /* PMSTA-25573 - CHU - 170505 */
                if (DBA_IsRejectedOrder(childExtOpTab[j]) == TRUE)
                    continue;

                qty += GET_NUMBER(childExtOpTab[j], ExtOp_Qty);
            }

            SET_NUMBER(parentExtOpTab[i], ExtOp_EffectChildQty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	    }
    	FREE(parentExtOpTab);
    }

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_AnalysisOrderList()
*
*  Description : Retrieve a hierarchy (ExtPos hierarchy), read Extended
*                Positions from hierarchy and construct/create Extended
*                Operations and store created Operations in hierarchy.
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : DVP342 - 970210 - PEC - Order management
*  Last modif. :   REF7264 - 020325 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
RET_CODE FIN_AnalysisOrderList(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP  *extOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  *tmpExtOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  *parentExtOpTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  *childTab=NULLDYNSTPTR;
	int             j, i, parentExtOpNbr, tmpExtOpNbr=0, extOpNbr=0;
	RET_CODE        ret;
	NUMBER_T        qty;

	/* Check arguments */
	if (hierHead == (PTR)NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                     "FIN_AnalysisOrderList", "hierHead");
		return(RET_GEN_ERR_INVARG);
	}

	ret = OPE_CreateExtOpfromExtPos(hierHead, &extOpTab, &extOpNbr, NULL, NULL);    /* REF7264 - PMO */

	if (ret != RET_SUCCEED)
	{
		if (extOpNbr > 0)
			return(RET_GEN_ERR_NOACTION);
	}

	if (extOpNbr == 0)
		return(RET_SUCCEED);

	tmpExtOpTab = (DBA_DYNFLD_STP *)CALLOC(extOpNbr, sizeof(DBA_DYNFLD_STP));

	for (i=0 ; i<extOpNbr ; i++)
	{
		if (extOpTab[i] != NULLDYNST)
			tmpExtOpTab[tmpExtOpNbr++] = extOpTab[i];
	}

	DBA_AddHierRecordList(hierHead, tmpExtOpTab, tmpExtOpNbr, ExtOp, FALSE);
	FREE(tmpExtOpTab);
	FREE(extOpTab);

	DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_A_Instr_Ext);
	DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_A_Ptf_Ext);

	DBA_SetHierLnkUsed(hierHead,    ExtOp, ExtOp_ChildExtOp_Ext);
	DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_ChildExtOp_Ext);

	/* Extract all parent orders and fill the field "effective_qty" with the sum
	   of each child quantity */
	DBA_ExtractHierEltRec(hierHead, ExtOp, FALSE, FIN_FilterParentOrder, NULLFCT,
	                      &parentExtOpNbr, &parentExtOpTab);

	for (i=0 ; i<parentExtOpNbr ; i++)
	{
		if (GET_ENUM(parentExtOpTab[i], ExtOp_ExecOpNatEn) > ExecNat_Partial)
        {
            qty = GET_NUMBER(parentExtOpTab[i], ExtOp_Qty);
			SET_NUMBER(parentExtOpTab[i], ExtOp_EffectChildQty, qty);
            continue;
        }

		childTab = GET_EXTENSION_PTR(parentExtOpTab[i], ExtOp_ChildExtOp_Ext);
		qty = 0;

		for (j=0 ; j<GET_EXTENSION_NBR(parentExtOpTab[i], ExtOp_ChildExtOp_Ext) ; j++)
		{
			if (GET_ENUM(childTab[j], ExtOp_ExecOpNatEn) > ExecNat_Partial)
				continue;

			qty += GET_NUMBER(childTab[j], ExtOp_Qty);
		}

		SET_NUMBER(parentExtOpTab[i], ExtOp_EffectChildQty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	}

	FREE(parentExtOpTab);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AnalysisPerfo()
**
**  Description :   Compute performance on a position set
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   REF1211 - RAK - 980210
**		            REF2580 - SSO - 980727
**		            REF3178 - SSO - 990106
**                  REF7264 - 020325 - PMO : Compilation errors and warnings with C++ compiler
**                  PMSTA7419 - EFE - 090313 : added a pointer on ptf for logical fusion
**                  PMSTA-11645 - 170311 - PMO : Positions with sub position natures cannot be merged even when requested via a domain parameter
*************************************************************************/
RET_CODE FIN_AnalysisPerfo(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
	DBA_DYNFLD_STP      *extractPos=(DBA_DYNFLD_STP*) NULL;
	LOGICIDRULE_ENUM    logicIdRule;
	int                 posNbr, i, fusionInitial=0, fusionFinal=0;
	char                copyRecFlg;
	RET_CODE            ret;
	ID_T		        ptfId=UNUSED;   /* REF3178 - SSO - 990106 */
	OBJECT_ENUM         dimPtfEn;	    /* REF3178 - SSO - 990106 */
	MemoryPool			mp;

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
					                 copyRecFlg, NULLFCT, FIN_CmpCheckLogicFus, /* REF1211 */
					                 &posNbr, &extractPos)) != RET_SUCCEED)
	{
		FREE(extractPos);
		return(ret);
	}

	mp.ownerPtr(extractPos);

	if (posNbr == 0)
		return(RET_SUCCEED);

    /* Check if it is necessary to perform the fusion process. Take care of the positions order / PMSTA-11645 - 170311 - PMO */
    const RET_CODE retCheckLogicalFusion = FIN_CheckLogicalFusion(domainPtr, posHierHead, posNbr, extractPos, &logicIdRule);

	/* Convert ref. gross and net amounts in received ref. currency */
	if ((ret = FIN_UpdPosRefAmt(extractPos, posNbr, GET_ID(domainPtr, A_Domain_CurrId),
		                        (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId),
				                posHierHead, domainPtr)) != RET_SUCCEED)	/* REF2580 - SSO - 980727  */ /* REF6220 - LJE - 020306 */
	{
		return(ret);
	}

	/* convert sys amounts if necessary */
	if ((ret = FIN_UpdPosSysAmt(domainPtr, extractPos, posNbr)) != RET_SUCCEED) /* REF3178 - SSO - 990106 */
	{
		return(ret);
	}

	/* Check if it is necessary to perform the fusion process / PMSTA-11645 - 170311 - PMO */
	if (retCheckLogicalFusion == RET_SUCCEED)
	{
	    /* BUG071 - XDI - 960725 check if initila or final stock for fusion */
	    for (i=0; i < posNbr ; i++)
	    {
		    if (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_InitStock)
			    fusionInitial++;

            if (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_FinalStock)
			    fusionFinal++;
	    }

	    /* REF3178 - SSO - 990106 : if single ptf, give its if to the fusion */
	    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
	    {
		    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
		    if (dimPtfEn == Ptf)
		    {
		        ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
		    }
	    }

		/*<PMSTA7419-EFE-090313*/
		DBA_DYNFLD_STP ptfPtr = NULL;
		FLAG_T         allocFlg=FALSE;

        if ( ptfId > 0 && ( ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr,
			                                     posHierHead , UNUSED, UNUSED) ) != RET_SUCCEED )
		{
		 	return(ret);
		}
        /*>PMSTA7419-EFE-090313*/
		if(allocFlg == TRUE) mp.ownerDynStp(ptfPtr);

		if (fusionInitial > 1)
		{
			DATE_START_TIMER(9, TIMER_MASK_SQLC);

			/* PMSTA-53235 - SENTHIL - 15072023 */
			if (PLMethod_ReprocessPL == (PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn))
			{
				SET_FLAG(domainPtr, A_Domain_ClosPosFlg, TRUE);

				/* Perform a logical fusion (with no impact on database) */
				/* on a set of positions given as input. (all loaded     */
				/* position) At end of fusion, build an output set of    */
				/* positions containing only the positions still opened. */
				if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
					posHierHead,
					NULLFCT,
					NULLFCT,
					(PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn), /* REF7264 - LJE - 020124 */
					logicIdRule,
					GET_FLAG(domainPtr, A_Domain_ClosPosFlg),
					ptfId, ptfPtr)) != RET_SUCCEED)
				{
					DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
					return(ret);
				}
			}
			else
			{
				/* Perform a logical fusion (with no impact on database) */
				/* on a set of positions given as input. (first initial  */
				/* stock then final stock) At end of fusion, build an    */
				/* output set of positions containing only the positions */
				/* still opened.                                         */
				if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
					posHierHead, (HIER_FLTFCT *)FIN_FilterInitStock, NULLFCT,   /* REF7264 - PMO */
					(PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn), /* REF7264 - LJE - 020124 */
					logicIdRule,
					GET_FLAG(domainPtr, A_Domain_ClosPosFlg),
					ptfId, ptfPtr)) != RET_SUCCEED) /* PMSTA7419-EFE-090313*/
				{
					DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
					return(ret);
				}
			}
			DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
		}

	    if (fusionFinal > 1)
	    {
	        DATE_START_TIMER(9, TIMER_MASK_SQLC);

	        if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
	                                   posHierHead, (HIER_FLTFCT *) FIN_FilterFinalStock, NULLFCT,  /* REF7264 - PMO */
	                                   (PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn), /* REF7264 - LJE - 020124 */
		                               logicIdRule,
					                   GET_FLAG(domainPtr,A_Domain_ClosPosFlg),
                                       ptfId, ptfPtr)) != RET_SUCCEED) /* PMSTA7419-EFE-090313*/
	        {
		        DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
		        return(ret);
	        }

	        DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
	    }

	    /* Keep only the positions still opened
	      comment by sme optim
	    if ((ret = DBA_SuppressHierEltRec(posHierHead, ExtPos,
				             FIN_FilterCloseStock)) != RET_SUCCEED)
	    {
		    return(ret);
		}*/
	}

	/*** Valorise stock positions on position date ***/
	return(FIN_ValoProcess(domainPtr, posHierHead, FIN_FilterPStock));
}

/************************************************************************
 **
 **  Function    :   FIN_IsCashPosForAccrInter()
 **
 **  Description :   Filter for cash positions that have status greater than
 **                  ACCR_INT_MIN_STATUS
 **                  return TRUE  -> it's a cash position with status >= ACCR_INT_MIN_STATUS
 **                         FALSE -> not a cash position or status is < ACCR_INT_MIN_STATUS
 **
 **  Arguments   :   dynSt      dynamic structure pointer
 **
 **  Creation    :   PMSTA-32772 - DDV - 180906
 **  Modification:
 *************************************************************************/
 STATIC int FIN_IsCashPosForAccrInter(DBA_DYNFLD_STP    dynSt,
                                      OPSTAT_ENUM       accrIntMinStatus)
{
	DBA_DYNFLD_STP  instrPtr = NULLDYNST;

	/* Return TRUE for cash positions linked to a portfolio*/
	if (GET_ENUM(dynSt, ExtPos_StatEn) >= accrIntMinStatus &&
		GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) != NULL &&
		(instrPtr = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext))) != NULLDYNST &&
		(INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct &&
		IS_NULLFLD(instrPtr, A_Instr_PtfId) == FALSE)
	{
		return(TRUE);
	}
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CashPosOrdered()
**
**  Description :   Ext Pos ordered by Instrument id, ext_pos_d, status and amount
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA-27729 - Smitha - 180115
**
*************************************************************************/
STATIC int FIN_CashPosOrdered(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	int cmp = 0;

	/* Order by instrument id */
	if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_InstrId, ExtPos_InstrId, IdType)) != 0)
		return(cmp);

	if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_ExtPosDate, ExtPos_ExtPosDate, DateType)) != 0)
		return(cmp);

	/*in case instrument id is same order by status descending */
	if ((cmp = CMP_DYNFLD((*ptr2), (*ptr1), ExtPos_StatEn, ExtPos_StatEn, EnumType)) != 0)
		return(cmp);

	/* order by amount descending */
	return(CMP_AMOUNT(GET_AMOUNT((*ptr2), ExtPos_SysNetAmt), GET_AMOUNT((*ptr1), ExtPos_SysNetAmt), GET_ID((*ptr1), ExtPos_RefCurrId)));

}
/************************************************************************
**
**  Function    :   FIN_UpdAccrIntrFlag()
**
**  Description :   This function updates the value of
**                  ExtPos_AccrIntChronoFlg to true for cash positions
**                  linked to a portfolio. If ExtPos_AccrIntChronoFlg
**                  is set to true , the accrued interest from interest
**                  chrono of the instrument is displayed.
**
**  Arguments   :   domainPtr     domain structure pointer, not currently used
**                  posHierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**  Creation    :   PMSTA-27729 - Smitha - 180115
**  Modification:   PMSTA-30160 - AiswaryaM - 180601
*************************************************************************/
RET_CODE FIN_UpdAccrIntrFlag(DBA_DYNFLD_STP *extPosTab,
	                          int             extPosNbr)
{
	int                 i = 0, cashPosNbr = 0;
	DBA_DYNFLD_STP      *cashPosTab = NULLDYNSTPTR;
	ID_T                instrId = ZERO_ID;
    DATE_T              date = 0;
	RET_CODE            ret = RET_SUCCEED;
    OPSTAT_ENUM         accrIntMinStatus = OpStat_None;


    GEN_GetApplInfo(ApplAccrIntMinStatus, &accrIntMinStatus);

    if (accrIntMinStatus <= OpStat_Cancelled)
    {
        /* if ACCR_INT_MIN_STATUS is not set,take the status from ACCOUNTING STATUS  */
        GEN_GetApplInfo(ApplAccountingStatus, &accrIntMinStatus);
    }

	MemoryPool mp;
	DBA_DYNFLD_STP admArgIn = mp.allocDynst(FILEINFO, Adm_Arg);
    SET_ENUM(admArgIn, Adm_Arg_StatusEn, accrIntMinStatus);

    cashPosTab = (DBA_DYNFLD_STP *) mp.calloc(extPosNbr, sizeof(DBA_DYNFLD_STP));

	/* Keep only cash position with status greater than appl parameter: ACCR_INT_MIN_STATUS */
    for (i=0; i < extPosNbr; i++)
    {
        if (FIN_IsCashPosForAccrInter(extPosTab[i], accrIntMinStatus) == TRUE)
	{
            cashPosTab[cashPosNbr++] = extPosTab[i];
        }
	}

	/* Sort cash positions by instrument id, extpos date, status and amount */
    if (cashPosNbr > 1)
    {
		TLS_Sort((char *) cashPosTab, cashPosNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT *)FIN_CashPosOrdered, (PTR **) NULL, SortRtnTp_None);
    }

	/* Loop through the ordered positions and mark the
	ExtPos_AccrIntChronoFlg to TRUE for the first position in each
	instrument */
	for (i = 0; i < cashPosNbr; i++)
	{
		if (CMP_ID(GET_ID(cashPosTab[i], ExtPos_InstrId), instrId) != 0 ||
            CMP_ID(GET_DATE(cashPosTab[i], ExtPos_ExtPosDate), date) != 0)
		{
			SET_FLAG(cashPosTab[i], ExtPos_AccrIntChronoFlg, TRUE);
			instrId = GET_ID(cashPosTab[i], ExtPos_InstrId);
			date = GET_DATE(cashPosTab[i], ExtPos_ExtPosDate);
		}
        else
		{
			SET_FLAG(cashPosTab[i], ExtPos_AccrIntChronoFlg, FALSE);
		}
	}

	return (ret);
}

/************************************************************************
**
**  Function    :   FIN_TaxLotValo()
**
**  Description :   Function to simulate the valuation of Tax Lot data
**
**
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Created	    :   PMSTA - 28571 - SANAND - 180319
**
**  Modif.	    :
**
*************************************************************************/
RET_CODE FIN_TaxLotValo(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE              ret = RET_SUCCEED;
    DBA_DYNFLD_STP        *extractPtf = (DBA_DYNFLD_STP*)NULL;
    int                   ptfNbr, i;
    char                  copyRecFlg;
	MemoryPool		      mp;

    FLAG_T                processTaxLotFlg = (static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_None);
    TAX_LOT_ACCOUNTING    taxLotAccounting = TAX_LOT_ACCOUNTING::NoTaxLot;
    GEN_GetApplInfo(ApplTaxLotAccountingEn, &taxLotAccounting);

    if (TRUE == processTaxLotFlg && TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)
    {
	    copyRecFlg = FALSE;
	    if ((ret = DBA_ExtractHierEltRec(hierHead,
                                         A_Ptf,
                                         copyRecFlg,
                                         NULLFCT,
                                         NULLFCT,
                                         &ptfNbr,
                                         &extractPtf)) != RET_SUCCEED)
        {
            return(ret);
        }

		mp.ownerPtr(extractPtf);

	    if (ptfNbr == 0)
        {
            return(RET_SUCCEED);
        }

        /* create a ptf tab for processing */
        DBA_DYNFLD_STP * ptfTab = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, ptfNbr, sizeof(DBA_DYNFLD_STP)));
        for (i = 0; i < ptfNbr; i++)
        {
            ptfTab[i] = mp.allocDynst(FILEINFO, Io_Id);
            SET_ID(ptfTab[i], Io_Id_Id, GET_ID(extractPtf[i] , A_Ptf_Id ));
        }

        TaxLotApplInfo taxLotApplInfo(GET_DATE(domainPtr, A_Domain_InterpFromDate));                                         /* PMSTA-35234 - 270319 - vkumar */
        TaxLotOrderProcess taxLotProcess(domainPtr, hierHead, ptfTab, ptfNbr, taxLotApplInfo);

        /*PMSTA-42207 - Portfolio tax lots*/
        if (taxLotApplInfo.sleeveManageInBO() == FALSE && LoadHierPtf_Full != GET_ENUM(domainPtr, A_Domain_LoadHierFlg))
        {
            if ((ret = taxLotProcess.fetchAdditionalExtOrders()) != RET_SUCCEED)
            {
                return ret;
            }
        }

        if ((ret = taxLotProcess.fetchTaxLotConfig()) != RET_SUCCEED)
        {
            return ret;
        }
        if ((ret = taxLotProcess.orderSimulationTaxLot()) != RET_SUCCEED)
        {
            return ret;
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   FIN_AnalysisValo()
**
**  Description :   This function has three major tasks :
**                  ensure that the portfolio position gross and net
**                  amounts are in the reference currency
**                  determine whether the fusion process should be called
**                  and if so, set various identifiers to neutral value.
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   REF1211 - RAK - 980210
**  Modif	        REF2580 - SSO - 980727
**		            REF3178 - SSO - 990106
**                  PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**                  PMSTA-11645 - 170311 - PMO : Positions with sub position natures cannot be merged even when requested via a domain parameter
*************************************************************************/
RET_CODE FIN_AnalysisValo(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
	DBA_DYNFLD_STP      *extractPos=(DBA_DYNFLD_STP*)NULL;
	LOGICIDRULE_ENUM    logicIdRule;
	int                 posNbr,i;
	char                copyRecFlg;
	RET_CODE            ret;
	ID_T		        ptfId=UNUSED; /* REF3178 - SSO - 990106 */
	OBJECT_ENUM         dimPtfEn;	/* REF3178 - SSO - 990106 */
    GENINSTRRULE_ENUM   genInstrRule = GenInstrRule_MergeAll;
    GEN_GetApplInfo(ApplGenericInstrRule, &genInstrRule);
	MemoryPool		mp;

	
    GEN_GetApplInfo(ApplGenericInstrRule, &genInstrRule);	

	/* PMSTA-51476 - DDV - 221220 - Create instrument in memory for instrument having SubNat_FXFwd_TwoLegsAgainsPtfCurr as sub_nat_e */
    ret = FIN_CreateFXSplitLegs(domainPtr, posHierHead);
	
    /* PMSTA - 28086 - SANAND - 180319 */
    if( GET_DICT(domainPtr, A_Domain_FctDictId) == (DICT_FCT_ENUM)DictFct_Valo )
    {
        if ( (ret = FIN_TaxLotValo(domainPtr, posHierHead) ) != RET_SUCCEED)
        {
            return ret;
        }
    }

    /* For HC valo, update sleeve cash account related details*/
    if (LoadHierPtf_LoadSleeve == GET_ENUM(domainPtr, A_Domain_LoadHierFlg))
    {
        DBA_DYNFLD_STP* tab = nullptr;
        int tabNbr = 0;
        if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, NULLFCT, NULLFCT, &tabNbr, &tab)) != RET_SUCCEED)
        {
			FREE(tab);
            return(ret);
        }

        mp.ownerPtr(tab);

        DBA_DYNFLD_STP ptf = NULLDYNST;
        bool makeLinkAgain = false;
        for (int idx = 0; idx < tabNbr; ++idx)
        {
            if (GET_EXTENSION_NBR(tab[idx], ExtPos_A_Instr_Ext) == 1)
            {
                DBA_DYNFLD_STP* instrPtr = GET_EXTENSION_PTR(tab[idx], ExtPos_A_Instr_Ext);
                if (instrPtr != nullptr)
                {
                    if (!IS_NULLFLD((*instrPtr), A_Instr_ParentInstrId) && InstrNat_CashAcct == GET_ENUM((*instrPtr), A_Instr_NatEn) && !IS_NULLFLD((*instrPtr), A_Instr_PtfId))
                    {
                        DBA_GetRecPtrFromHierById(posHierHead, GET_ID((*instrPtr), A_Instr_PtfId), A_Ptf, &ptf);
                        if (ptf != NULLDYNST && PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptf, A_Ptf_NatEn)))
                        {
                            /* Here , we have an instrument (cash account) with parent instr id, a ptf linked and the ptf is sleeve. */
                            SET_ID((tab[idx]), ExtPos_InstrId, (GET_ID((*instrPtr), A_Instr_ParentInstrId)));
                            makeLinkAgain = true;
                        }
                    }
                }
            }
        }
        if (makeLinkAgain)
        {
            DBA_MakeSpecRecLinks(posHierHead, ExtPos, ExtPos_A_Instr_Ext);
        }
    }

	/* Extract all loaded positions */
	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead,
                                     ExtPos,
                                     copyRecFlg,
                                     NULLFCT,
                                     FIN_CmpCheckLogicFus, /* REF1211 */
                                     &posNbr,
                                     &extractPos)) != RET_SUCCEED)
    {
		FREE(extractPos);
        return(ret);
    }

	mp.ownerPtr(extractPos);

	if (posNbr == 0)
    {
        return(RET_SUCCEED);
    }

	/* PMSTA-53131 - SENTHIL - 040823 */
	bool isMergeReprocess = FALSE;

	if ((static_cast<PTFCONSRULE_ENUM>
		GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged) && (PLMethod_ReprocessPL == static_cast<PLMETHOD_ENUM>GET_ENUM(domainPtr, A_Domain_PLMethodEn)))
	{
		isMergeReprocess = TRUE;
	}

    /* Check if it is necessary to perform the fusion process. Take care of the positions order / PMSTA-11645 - 170311 - PMO */
	const RET_CODE retCheckLogicalFusion = FIN_CheckLogicalFusion(domainPtr, posHierHead, posNbr, extractPos, &logicIdRule, isMergeReprocess);

	/* Convert ref. gross and net amounts in received ref. currency */
	if ((ret = FIN_UpdPosRefAmt(extractPos,
                                posNbr,
                                GET_ID(domainPtr, A_Domain_CurrId),
		                        (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId),
                                posHierHead, domainPtr)) != RET_SUCCEED) /* REF2580 - SSO - 980727 */ /* REF6220 - LJE - 020306 */
	{
		return(ret);
	}

	/* convert sys amounts if necessary */
	if ((ret = FIN_UpdPosSysAmt(domainPtr, extractPos, posNbr)) != RET_SUCCEED) /* REF3178 - SSO - 990106 */
	{
		return(ret);
	}

    /* PMSTA00485 - DDV - 2CHECK called here for test purpose but is it the right place ? */
    if ((ret = FIN_ManageFutureCashFlows(domainPtr, posHierHead)) != RET_SUCCEED)
    {
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_AnalysisValo() : Cash flows management failed");
    }

	/* PMSTA05219 - RAK - 080812 */
	/* Create a sub-function for the part of zero pos verification and call it after the fusion ! */

	/* PMSTA12459-CHU-110816 : remember what happened above and do no Logical Fusion on generated orders in CheckStratValo */
	ret = retCheckLogicalFusion;

    /* PMSTA-11645 - 170311 - PMO */
	if (RET_GET_LEVEL(retCheckLogicalFusion) == RET_LEV_ERROR)   /* Stop in case of error */
	{
		return(ret);
	}
	else if (ret == RET_SUCCEED)
	{
		/* REF3178 - SSO - 990106 : if single ptf, give its if to the fusion */
		if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
		{
		    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
		    if (dimPtfEn == Ptf)
		    {
			    ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
		    }
		}


		/*<PMSTA7419-EFE-090313*/
 		DBA_DYNFLD_STP ptfPtr = NULL;
		FLAG_T         allocFlg=FALSE;

        if ( ptfId > 0 && ( ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr,
			                                     posHierHead , UNUSED, UNUSED) ) != RET_SUCCEED )
		{
		 	return(ret);
		}
        /*>PMSTA7419-EFE-090313*/
		if(allocFlg == TRUE) mp.ownerDynStp(ptfPtr);

		DATE_START_TIMER(9, TIMER_MASK_SQLC);

		if (PLMethod_ReprocessPL == (PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn))
			SET_FLAG(domainPtr, A_Domain_ClosPosFlg, TRUE);

	   	/* Perform a logical fusion (with no impact on database) */
	   	/* on a set of positions given as input. (all loaded     */
		/* position) At end of fusion, build an output set of    */
		/* positions containing only the positions still opened. */
		if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr,A_Domain_InterpFromDate),
			                         posHierHead,
                                     NULLFCT,
                                     NULLFCT,
					                 (PTFFUSRULE_ENUM)GET_ENUM(domainPtr,A_Domain_FusRuleEn), /* REF7264 - LJE - 020124 */
					                 logicIdRule,
					                 GET_FLAG(domainPtr,A_Domain_ClosPosFlg),
                                     ptfId, ptfPtr )) != RET_SUCCEED)
		{
		    DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
			return(ret);
		}

		DATE_STOP_TIMER(9, TIMER_MASK_SQLC);

		/* Keep only the positions still opened comment by SME optim
if ((ret = DBA_SuppressHierEltRec(posHierHead, ExtPos,
							  FIN_FilterCloseStock)) != RET_SUCCEED)
	return(ret);
}*/

		/* PMSTA-53131 - SENTHIL - 040823 */

		if ((static_cast<PTFCONSRULE_ENUM>
			GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged) && (PLMethod_ReprocessPL == static_cast<PLMETHOD_ENUM>GET_ENUM(domainPtr, A_Domain_PLMethodEn)))
		{
			/* Extract all loaded positions */
			extractPos = nullptr;
			posNbr  = 0;
			copyRecFlg = FALSE;
			if ((ret = DBA_ExtractHierEltRec(posHierHead,
				ExtPos,
				copyRecFlg,
				NULLFCT,
				FIN_CmpCheckLogicFus,
				&posNbr,
				&extractPos)) != RET_SUCCEED)
			{
				FREE(extractPos);
				return(ret);
			}

			mp.ownerPtr(extractPos);

			if (posNbr == 0)
			{
				return(RET_SUCCEED);
			}


			const RET_CODE retCheckLogicalFusion1 = FIN_CheckLogicalFusion(domainPtr, posHierHead, posNbr, extractPos, &logicIdRule);

			ret = retCheckLogicalFusion1;

			if (RET_GET_LEVEL(retCheckLogicalFusion1) == RET_LEV_ERROR)   /* Stop in case of error */
			{
				return(ret);
			}

			DATE_START_TIMER(9, TIMER_MASK_SQLC);

			if (PLMethod_ReprocessPL == static_cast<PLMETHOD_ENUM>GET_ENUM(domainPtr, A_Domain_PLMethodEn))
				SET_FLAG(domainPtr, A_Domain_ClosPosFlg, TRUE);

			/* Perform a logical fusion (with no impact on database) */
			/* on a set of positions given as input. (all loaded     */
			/* position) At end of fusion, build an output set of    */
			/* positions containing only the positions still opened. */
			if ((ret = FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
				posHierHead,
				NULLFCT,
				NULLFCT,
				(PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn),
				logicIdRule,
				GET_FLAG(domainPtr, A_Domain_ClosPosFlg),
				ptfId, ptfPtr)) != RET_SUCCEED)
			{
				DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
				return(ret);
			}

			DATE_STOP_TIMER(9, TIMER_MASK_SQLC);
		}
	}

	/* PMSTA05219 - RAK - 080812 */
	/* Create a sub-function for the part of zero pos verification and call it after the fusion ! */
	if ((ret = DBA_CheckPositions(domainPtr, posHierHead)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_AnalysisValo() : Check positions (Zero Qty Flag) failed");
	}

	/* REF10175 - DDV - 041011 - Merge of generic MM */
    if (genInstrRule == GenInstrRule_MergeAll && GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo)
    {
		extractPos = nullptr;
		posNbr = 0;
		if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
										 FALSE, NULL, FIN_CmpPosInstrIdRefNat, &posNbr, &extractPos)) != RET_SUCCEED)   /* PMSTA05966 - 090525 - PMO */
		{
			FREE(extractPos);
			return(ret);
		}

		mp.ownerPtr(extractPos);

		for (i=0; i<posNbr;i++)
		{
	   		ret = DBA_GenericInstr(posHierHead, extractPos[i], extractPos, i,
                                   GET_DATETIME(domainPtr, A_Domain_InterpFromDate)); /* PMSTA05966 - 090525 - PMO */

	   		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	   		{
				return(ret);
	   		}
		}
    }

	/*** Determine stock positions on crystallised dates */
	if ((DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_MultiValo)
	{
		if ((ret = FIN_MultiPeriod(domainPtr, posHierHead)) != RET_SUCCEED)
        {
            return(ret);
        }
	}

	return(FIN_ValoProcess(domainPtr, posHierHead, FIN_FilterPStock));
}

/************************************************************************
**
**  Function    :   FIN_CheckLogicalFusion()
**
**  Description :   Read domain parameter and decide if logical fusion
**                  must be perform or not.
**                  If fusion will be performed,
**                    - if portfolio consolidation rule requires consolidation,
**                      suppress the portfolio dimension.
**                    - if status consolidation requires consolidation, set the
**                      extended position status to a neutral value.
**                    - if term consolidation requires consolidation, set the
**                      status to a neutral value.
**
**  Arguments   :   domainPtr     domain structure pointer
**                  hierHead      hierarchy header
**                  posNbr        position number
**                  posTab        position array pointer
**                  fusLogicEn    pointer on fusion logical id rule to update
**                                for send to FIN_LogicalFusion().
**
**  Return      :   RET_SUCCEED           Fusion necessary
**                  RET_GEN_INFO_NOACTION Fusion unnecessary
**                  error code
**
**  Modif	    :   DVP339 - RAK - 970212
**  Modif	    :   REF069 - RAK - 970917
**  Modif	    :   REF1211 - RAK - 980209
**  Modif	    :   REF2511 - SSO - 980717
**  Modif	    :   REF2644 - RAK - 990125
**  Modif	    :   REF2738 - RAK - 990222
**	Modif       :   PMSTA-32158 - SILPA - 180905
**
*************************************************************************/
RET_CODE FIN_CheckLogicalFusion(DBA_DYNFLD_STP    domainPtr,
			                    DBA_HIER_HEAD_STP posHierHead,
			                    int               posNbr,
			                    DBA_DYNFLD_STP   *posTab,
				                LOGICIDRULE_ENUM *fusLogicEn,
								bool			  isMergeReprocess)
{
	DBA_DYNFLD_STP    ptfPtr=NULLDYNST;
	OBJECT_ENUM       dimPtfEn;
	LOGICIDRULE_ENUM  ptfLogicEn, domLogicEn;
	OPSTAT_ENUM       accStat;
	char              fusionOk=FALSE, ptfConsFlg=FALSE, subPosFlg=FALSE;
	ID_T		      firstInstrId=0;
	int               i, j, firstIdx, lastIdx;
	ENUM_T		      subPosNatEn=0, subPosNat2En=0, subPosNat3En=0;
	RET_CODE          ret;
	MERGESTATUSRULE_ENUM mergeStatusRuleEn; /* REF11421 - CHU - 050914 */

	/* REF2738 - Init to default value, in case of fct stop  */
	/*           without domain and portfolio field reading. */
	GEN_GetApplInfo(ApplPosLogicalIdRule, fusLogicEn);

	/* REF11421 - CHU - 050914 : Get value for use with domain merge status flag */
	GEN_GetApplInfo(ApplMergeStatusRule, &mergeStatusRuleEn);

	/* PMSTA-65946 - Deepthi - 20250213 */
	GEN_GetApplInfo(ApplAccountingStatus, &accStat);

	/* PMSTA-11875 - RAK - 110517 */
	/* Use logical fusion to merge children portfolios position in parent portfolio */
	if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedHierarchical)
		fusionOk = TRUE;

	/* ---------------------------------------------- */
	/* DVP339 - No fusion for strategy reconciliation */
	/* ---------------------------------------------- */
	if ((GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo &&
	     GET_ENUM(domainPtr, A_Domain_StratCheckReconcEn) == Strat_Reconc) ||
	     GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) /* REF3371 - RAK - 991230 */
		return(RET_GEN_INFO_NOACTION);

	/* ------------------------------------------------------- */
	/* Mutual fund splitting rule indicates fund splitting and */
	/* ------------------------------------------------------- */
	/* subsequent consolidation, so perform fusion process     */
	if ((FUNDSPLITRULE_ENUM)
	    GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn) == FundSplitRule_ConsSplit)
		fusionOk = TRUE;

	/* REF10429 - 040111 - DDV - Fusion WMP */
	if (GET_ENUM(domainPtr, A_Domain_FusRuleEn) == PtfFusRule_WMP)
	{
	    for (i=0; i<posNbr && fusionOk == FALSE; i++)
	    {
		    if (GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL &&
		        (ptfPtr = *(GET_EXTENSION_PTR(posTab[0], ExtPos_A_Ptf_Ext))) != NULLDYNST &&
				GET_ENUM(ptfPtr, A_Ptf_FusionRuleEn) != PtfFusRule_WMP)
			{
			    fusionOk   = TRUE;
			}
		}
	}

    /* ------------------------------------------------------------------------- */
	/* For return function, ptf consolidation is performed on ptf synthetic      */
	/* data so don't consolidate positions.                                      */
	/* For other functions, verify the ptf consolidation rule and ptf dimension  */
	/* If domain references multiple portfolios and portfolio consolidation rule */
	/* is "merged", perform logical fusion process.                              */
	/* ------------------------------------------------------------------------- */
	if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
		DBA_GetObjectEnum(GET_DICT(domainPtr,A_Domain_DimPtfDictId), &dimPtfEn);
	else
		dimPtfEn = NullEntity;

	if (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_Return)
	{
	    if (dimPtfEn==NullEntity ||
            dimPtfEn==List       || /* list dimension */
            dimPtfEn==Third      ||
            dimPtfEn==QuickSearch) /* REF5482 - DDV - 001130 */
	    {
			/* PMSTA-53131 - SENTHIL - 040823 */
		    if ((PTFCONSRULE_ENUM)
		        GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged && isMergeReprocess==FALSE)
		    {
			    ptfConsFlg = TRUE;
			    fusionOk   = TRUE;
		    }
	    }
	    else 							/* portfolio dimension */
	    {
		    /* REF069 - Portfolio hierarchy -> portfolio list */
		    if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
		        (PTFCONSRULE_ENUM)
		        GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged)
		    {
			    ptfConsFlg = TRUE;
			    fusionOk   = TRUE;
		    }
	    }
	}

	/* --------------------------------------------------------------------- */
	/* REF1211 - Verify domain flag fusion sub-nature.                       */
	/* If status consolidation flag is TRUE, verify position status          */
	/* If portfolio consolidation flag is TRUE, suppress portfolio dimension */
	/* --------------------------------------------------------------------- */
	if (ptfConsFlg == TRUE ||
	    GET_FLAG(domainPtr, A_Domain_FusSubNatFlg) == TRUE ||
	    GET_FLAG(domainPtr, A_Domain_StatusFusFlg) == TRUE)
	{
	    for (i=0, firstIdx=lastIdx=0; i<posNbr; i++)
	    {
		    /* ----------------------------------------------------- */
		    /* Test that among initial or final stocks position,     */
		    /* there are position with same instrument but different */
		    /* sub_pos_nat or sub_pos_nat2 or sub_pos_nat3.          */
		    /* ----------------------------------------------------- */
		    if (GET_FLAG(domainPtr, A_Domain_FusSubNatFlg) == TRUE && i >= lastIdx)
		    {
		        if (i > 0 && GET_ID(posTab[i], ExtPos_InstrId) !=
				    GET_ID(posTab[i-1], ExtPos_InstrId))
			        firstIdx = i;

		        if (firstIdx == i)		/* Init 3 sub position nature and flag */
		        {
			        /* REF2511 - SSO - 980717 - corrected GET_ENUM/GET_ID mismatch */
			        subPosNatEn  = GET_ENUM(posTab[i], ExtPos_SubPosNatEn);
			        subPosNat2En = GET_ENUM(posTab[i], ExtPos_SubPosNat2En);
			        subPosNat3En = GET_ENUM(posTab[i], ExtPos_SubPosNat3En);
			        firstInstrId = GET_ID(posTab[i], ExtPos_InstrId);
			        subPosFlg = FALSE;
		        }
		        else 			/* Compare 3 sub position nature */
		        {
			        if ((IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == TRUE &&
                        (GET_ENUM(posTab[i], ExtPos_NatEn) == ExtPosNat_InitStock ||
			             GET_ENUM(posTab[i], ExtPos_NatEn) == ExtPosNat_FinalStock)) &&
			            (GET_ENUM(posTab[i], ExtPos_SubPosNatEn) != subPosNatEn ||
			             GET_ENUM(posTab[i], ExtPos_SubPosNat2En) != subPosNat2En ||
			             GET_ENUM(posTab[i], ExtPos_SubPosNat3En) != subPosNat3En))
			        {
			            subPosFlg = TRUE;
			            fusionOk = TRUE;
			        }

			        if (subPosFlg == TRUE)
			        {
			            for (j=firstIdx;
				             j<posNbr &&
                             GET_ID(posTab[j], ExtPos_InstrId) == firstInstrId; j++)
			            {
				            /* Update only initial and final positions */
				            if (IS_NULLFLD(posTab[j], ExtPos_BalPosTpId) == TRUE &&
				                (GET_ENUM(posTab[j], ExtPos_NatEn) == ExtPosNat_InitStock ||
				                 GET_ENUM(posTab[j], ExtPos_NatEn) == ExtPosNat_FinalStock))
				            {
				                SET_ENUM(posTab[j], ExtPos_SubPosNat3En,
							                        (ENUM_T) PosSubPosNat_None);
				                SET_ENUM(posTab[j], ExtPos_SubPosNat2En,
							                        (ENUM_T) PosSubPosNat_None);
				                SET_ENUM(posTab[j], ExtPos_SubPosNatEn,
							                        (ENUM_T) PosSubPosNat_None);
				            }
			            }
			            lastIdx = j;	/* Don't test other instrument positions */
			        }
		        }
		    }

		    /* ------------------------------------------------------- */
		    /* If status consolidation is required, set to accounting  */
		    /* status all position with status < accounting status and */
		    /* call logical fusion.                                    */
		    /* ------------------------------------------------------- */
		    if (GET_FLAG(domainPtr, A_Domain_StatusFusFlg) == TRUE &&
		        (GET_ENUM(posTab[i], ExtPos_StatEn) < accStat ||
				/* REF11421 - CHU - 050914 (CSC19202 DEXIA) Merge also above Accounted */
				(mergeStatusRuleEn == MergeStatusRule_BelowAndAboveAcct &&
		         GET_ENUM(posTab[i], ExtPos_StatEn) > accStat)))
		    {
				if (static_cast<PRICECALCRULE_ENUM>GET_ENUM(posTab[i], ExtPos_PriceCalcRuleEn) != PriceCalcRule_PortfolioSpecificPrice) /* PMSTA - 32158 - SILPA - 180905 */
				{
					fusionOk = TRUE;
					SET_ENUM(posTab[i], ExtPos_StatEn, accStat);
					SET_FLAG(posTab[i], ExtPos_AcctFlg, TRUE);
				}
		    }

		    /* ------------------------------------------------------- */
		    /* If portfolio consolidation rule requires consolidation, */
		    /* set the portfolio id and the portfolio position set id  */
		    /* to a neutral value.                                     */
		    /* ------------------------------------------------------- */
		    if (ptfConsFlg == TRUE && GET_ENUM(posTab[i], ExtPos_NatEn) != ExtPosNat_Flow)
		    {
			    SET_NULL_ID(posTab[i], ExtPos_PtfPosSetId);
			    SET_NULL_ID(posTab[i], ExtPos_PtfId);
			    SET_NULL_ID(posTab[i], ExtPos_ChildPtfId);		/* REF069 */

			    if ((ret = DBA_SuppressLink(posHierHead, ExtPos,
			                                ExtPos_A_Ptf_Ext,
						                    posTab[i])) != RET_SUCCEED)
				    return(ret);
		    }
	    }
	}

	/* Verify position logical identifier (domain, ptf, system) */
	domLogicEn = (LOGICIDRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PosLogicEn);
	if (domLogicEn == LogicIdRule_Dflt)
	{
	    if (dimPtfEn == Ptf)
	    {
		    /* In case of logical fusion, use portfolio position logic id */
		    if (GET_EXTENSION_PTR(posTab[0], ExtPos_A_Ptf_Ext) != NULL &&
		        (ptfPtr = *(GET_EXTENSION_PTR(posTab[0], ExtPos_A_Ptf_Ext))) != NULLDYNST)
		    {
		        *fusLogicEn = (LOGICIDRULE_ENUM) GET_ENUM(ptfPtr, A_Ptf_PosLogicalEn);

		        /* REF2738 - If portfolio fusion rule is default, use system fusion rule */
				if (*fusLogicEn == LogicIdRule_Dflt)
				{
					GEN_GetApplInfo(ApplPosLogicalIdRule, fusLogicEn);
				}
				/* PMSTA-65946 - Deepthi - 20250213 */
				if (GET_ENUM(posTab[0], ExtPos_StatEn) == accStat)	/* PMSTA-50785 - KOR - 21112022 */ 
					fusionOk = TRUE;
		    }
		    else
		    {
		        GEN_GetApplInfo(ApplPosLogicalIdRule, fusLogicEn); /* REF10175 - DDV - 041216 - Use system parameter, no more message in log */
		    }
	    }
	    else
	    {
		    /* In case of logical fusion, use system position logic id */
		    GEN_GetApplInfo(ApplPosLogicalIdRule, fusLogicEn);

			/* PMSTA-65946 - Deepthi - 20250213 */
			if (GET_ENUM(posTab[0], ExtPos_StatEn) == accStat)	/* PMSTA-50785 - KOR - 21112022 */
				fusionOk = TRUE;
	    }
	}
	else
	{
	    if (dimPtfEn == Ptf)
	    {
		    if (GET_EXTENSION_PTR(posTab[0], ExtPos_A_Ptf_Ext) != NULL &&
		        (ptfPtr = *(GET_EXTENSION_PTR(posTab[0], ExtPos_A_Ptf_Ext))) != NULLDYNST)
		        ptfLogicEn = (LOGICIDRULE_ENUM) GET_ENUM(ptfPtr, A_Ptf_PosLogicalEn);
		    else
		    {
    		    ptfLogicEn = LogicIdRule_Dflt; /* REF10175 - DDV - 041216 - Use system parameter, no more message in log */
		    }

		    /* REF2738 - If ptf fusion rule is default, use system fusion rule */
		    if (ptfLogicEn == LogicIdRule_Dflt)
			    GEN_GetApplInfo(ApplPosLogicalIdRule, &ptfLogicEn);

		    if (ptfLogicEn != domLogicEn)
		    {
			    /* Execute logical fusion with domain pos logic id */
			    fusionOk = TRUE;
			    *fusLogicEn = domLogicEn;
		    }
		    else
		    {
			    /* In case of logical fusion, use ptf pos logic id */
			    *fusLogicEn = ptfLogicEn;

				/* PMSTA-65946 - Deepthi - 20250213 */
				if (GET_ENUM(posTab[0], ExtPos_StatEn) == accStat)	/* PMSTA-50785 - KOR - 21112022 */
					fusionOk = TRUE;
		    }
	    }
	    else
	    {
		    /* Execute logical fusion with domain pos logic id */
		    fusionOk = TRUE;
            	    /* PMSTA-36264 - MSS - 190624 - cash positions should not be merged for pos_logical_e for third party */
		    /* PMSTA-41391 - SRIDHARA - 08112020 : @MSS : Then exclude only Third Party dimension */

			/* PMSTA-65946 - Deepthi - 20250213 */
			if (dimPtfEn != Third && GET_ENUM(posTab[0], ExtPos_StatEn) == accStat)	/* PMSTA-50785 - KOR - 21112022 */
			{
				fusionOk = TRUE;
			}

		    *fusLogicEn = domLogicEn;
	    }
	}

	if (fusionOk == TRUE)
	    return(RET_SUCCEED);
	else
	    return(RET_GEN_INFO_NOACTION);
}

/************************************************************************
**  Function             : FIN_MultiPeriod()
**
**  Description          : Determine stock positions on crystallised dates
**                         initial, intermediate (depend on frequency) and final
**                         Read extended positions in received hierarchy, create
**                         new stock positions and remove unecessary original
**                         extended positions.
**
**  Arguments            : domainPtr    domain pointer
**                         posHierHead  hierarchy pointer
**
**  Return               : RET_SUCCEED or error code
**
**  Last modif.          : PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
*************************************************************************/
STATIC RET_CODE FIN_MultiPeriod(DBA_DYNFLD_STP    domainPtr,
				                DBA_HIER_HEAD_STP posHierHead)
{
	DBA_DYNFLD_STP *extractPos=(DBA_DYNFLD_STP*)NULL, newExtPos=NULLDYNST,
		       instrPtr=NULLDYNST;
	int            i, k, rows, crystalNbr;
	DATETIME_T     fromDate, tillDate, *crystalDates, nextCrystal;
	TINYINT_T      freq;
	FREQUNIT_ENUM  freqUnit;
	RET_CODE       ret;

	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, NULL, FIN_CmpPosInstrIdRefNat,
					                 &rows, &extractPos)) != RET_SUCCEED)   /* PMSTA05966 - 090525 - PMO */
	{
		return(ret);
	}

	fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	/*** FREQUENCY ***/
	/* Read frequency in domain or in portfolio ?? */
	if (IS_NULLFLD(domainPtr, A_Domain_Freq1) == FALSE)
	{
		freq     = GET_TINYINT(domainPtr, A_Domain_Freq1);
		freqUnit = (FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq1UnitEn);
	}
	else
	{
		/* ptf, multi ptf ?? */
	    freq     = GET_TINYINT(domainPtr, A_Domain_Freq1);
		freqUnit = (FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq1UnitEn);
	}

	/* by default, monthly frequency */
	if (freqUnit == FreqUnit_None)
		freqUnit = FreqUnit_Month;
	if (freq == 0)
		freq = 1;

	/*** DATES CRYSTALLISATION ***/
	/* Determines according to begin and end date, the  */
	/* dates upon which the positions need to be valued */
	ret = DATE_CrystalDates(fromDate, tillDate, freq, freqUnit, FALSE,
				            &crystalDates, &crystalNbr, NULL, NULL, (DATE_POSI_ENUM)EndOf, /* REF5358 - CSY - 010131: new arg EndOf */
                            nullptr, nullptr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		FREE(extractPos);
		return(ret);
	}

	/*** CREATE STOCK POSITIONS (initial, intermediate and final) ***/
	for (k=0; k<crystalNbr; k++)
	{
	    for (i=0; i<rows; i++)
	    {
		    /* ?? already made in DBA_UpdExtPosFld()
	   	    SET_FLAG(extractPos[i],    ExtPos_ForecastFlg, FALSE);
	   	    SET_FLAG(extractPos[i],    ExtPos_AcctFlg,     TRUE);
	   	    SET_ENUM(extractPos[i],    ExtPos_RiskNatEn,   ExtPosRisk_NoRisk);
	   	    SET_PERCENT(extractPos[i], ExtPos_Proba,       100); */

		    /* Current position is a stock position on current date */
		    if (DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_BegDate),
			                 crystalDates[k]) <= 0 &&
	            DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_EndDate),
			                 crystalDates[k]) > 0)
		    {
		        /* Create a new position (stock on current date) */
		        if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULLDYNST)
		        {
			        FREE(extractPos);
	    		    FREE(crystalDates);
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

		        COPY_DYNST(newExtPos, extractPos[i], ExtPos);

		        if (DATETIME_CMP(crystalDates[k], fromDate) == 0)
		        {
			        SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_InitStock);
		        }
		        else
		        {
		  	        if (DATETIME_CMP(crystalDates[k], tillDate) == 0)
			        {   SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_FinalStock); }
			        else
			        {   SET_ENUM(newExtPos, ExtPos_NatEn, ExtPosNat_IntermStock); }
		        }

		        SET_DATETIME(newExtPos, ExtPos_ExtPosDate, crystalDates[k]);

		        SET_NULL_ID(newExtPos, ExtPos_Id);
		        if ((ret = DBA_AddHierRecord(posHierHead, newExtPos,
						                     ExtPos, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
		        {
			        FREE_DYNST(newExtPos, ExtPos);
			        FREE(extractPos);
	    		    FREE(crystalDates);
			        return(ret);
		        }

		        /* Force link on instrument for generic treatment */
		        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) == NULL ||
		            (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],
					                                ExtPos_A_Instr_Ext))) == NULLDYNST)
		        {
			        FREE(extractPos);
	    		    FREE(crystalDates);
	    		    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO,
				                 "FIN_MultiPeriod", ExtPos_A_Instr_Ext);
			        return(RET_DBA_ERR_HIER);
		        }

		        if ((ret = DBA_ForceLink(posHierHead, ExtPos, ExtPos_A_Instr_Ext,
				                         newExtPos, instrPtr)) != RET_SUCCEED)
		        {
			        FREE(extractPos);
	    		    FREE(crystalDates);
			        return(ret);
		        }

		        ret = DBA_GenericInstr(posHierHead, newExtPos, extractPos, i,
					                   GET_DATETIME(newExtPos, ExtPos_ExtPosDate));         /* PMSTA05966 - 090525 - PMO */

		        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		        {
			        FREE(extractPos);
	    		    FREE(crystalDates);
			        return(ret);
		        }
		    }

	 	    /* On last positions reading */
		    if (k == crystalNbr-1)
		    {
		        if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_MultiValo)
		        {
			        /* Remove all initial positions */
	    		    DBA_DelHierEltRec(posHierHead, ExtPos, extractPos[i]);
		        }
		        else
		        {
			        /* Save flows and remove others */
			        if (DATETIME_CMP(fromDate, GET_DATETIME(extractPos[i], ExtPos_BegDate)) < 0 &&
	                    GET_ENUM(extractPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
			        {
			            /* Init flow on next crystallised date */
			            SET_ENUM(extractPos[i], ExtPos_NatEn, ExtPosNat_Flow);

			            FIN_GetNextCrystalDate(GET_DATETIME(extractPos[i], ExtPos_BegDate),
				                   crystalDates, crystalNbr, &nextCrystal);

			            SET_DATETIME(extractPos[i], ExtPos_ExtPosDate, nextCrystal);
			        }
			        else
			            DBA_DelHierEltRec(posHierHead, ExtPos, extractPos[i]);
		        }
		    } /* last positions reading */
	    } /* original positions reading */
	}

	ret = DBA_MakeLinks(posHierHead);

	FREE(extractPos);
	FREE(crystalDates);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfCurrentList
**  Description :   filter Extpos having same listseqno
**  Argument    :
**  Return      :
**  Creation    :   PMSTA-48195 -Performance IPS Level -Lalby-180722
**  Last modif. :
**
*************************************************************************
STATIC int FIN_FilterPtfCurrentList(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp,
    DBA_DYNFLD_STP ptfPtr)
{
    DBA_DYNFLD_STP extPtf;
    if ((GET_EXTENSION_PTR(dynSt, ExtPos_A_Ptf_Ext)) != NULL &&
        ((extPtf = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Ptf_Ext))) != NULLDYNST))
    {
        if (GET_SMALLINT(extPtf, A_Ptf_ListSeqNo) == GET_SMALLINT(ptfPtr, A_Ptf_ListSeqNo)&&
            GET_ID(extPtf, A_Ptf_Id) ==GET_ID(ptfPtr, A_Ptf_Id))
        {
            return (FIN_FilterInitStockNoBP(dynSt, dynStTp, NULL));
        }
    }
 
    return(FALSE);
}

/***********************************************************************
**
**  Function    :   FIN_ValoProcess()
**
**  Description :   Compute positions value at position date depending
**                  on quotation retrieval method and instrument data.
**
**  Arguments   :   domainPtr       pointer on domain
**                  posHierHead     hierarchy pointer
**                  valoProcFilter filter for position to evaluate
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   DVP197 - RAK - 960903
**  Modif.	    :   BUG118 - RAK - 960912
**  Modif.	    :   BUG135 - RAK - 960924
**  Modif.	    :   BUG175 - RAK - 961010
**  Modif.	    :   REF524 - RAK - 971013
**  Modif.	    :   REF1365 - RAK - 980312
**  Modif.      :   REF1457 - DDV - 980324 - Script evaluation for AI
**  Modif.      :   REF1511 - RAK - 980407 -
**  Modif.      :   REF2614 - RAK - 980819
**  Modif.      :   REF3030 - RAK - 981119
**  Modif.      :   REF2561 - RAK - 990108
**  Modif.      :   REF7265 - YST - 020409
**                  PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
*************************************************************************/
RET_CODE FIN_ValoProcess(DBA_DYNFLD_STP    domainPtr,
			             DBA_HIER_HEAD_STP posHierHead,
		                 HIER_FLTFCT       *valoProcFilter)
{
	DBA_DYNFLD_STP    prPtr=NULLDYNST, ptfPtr=NULLDYNST, instrPtr=NULLDYNST,
			          extValo=NULLDYNST, posValPtr=NULLDYNST,
	                  *extractPos=(DBA_DYNFLD_STP*)NULL,
                      scriptDefPtr=NULLDYNST; /* REF1457 - DDV - 980324 */
	FIN_DOMAIN_ARG_ST domainArg;
	ID_T              oldInstrId, oldCurrId,
	                  oldTermTpId, oldQuoteValRuleId=0, newQuoteValRuleId=0,
	                  oldExchValRuleId=0, newExchValRuleId=0; /* PMSTA14443 - DDV - 120709 */
	DATETIME_T        oldPosDate;
	NUMBER_T          tot;
	int               i, posNbr=0, newPosValNbr;
	char              copyRecFlg;
	RET_CODE          ret;
	OPLOCKNAT_ENUM	  opLockNatEn;
    FIN_AIARG_ST      accrInterArg;
    DICT_ATTRIB_STP    dictAttrSt;
    SCPT_ARG_STP      genContext = (SCPT_ARG_STP) NULL;
    FLAG_T            computePosPriceFlg = TRUE;
    int               valRuleDepChk = NO_VALUE, exchRuleDepChk = NO_VALUE;
    DBA_DYNFLD_STP  *newExtTab=NULLDYNSTPTR; /* REF5442 - DDV - 010205 */
    HIER_FLTFCT       *mktValFilter=NULLFCT;

	ID_T              refCurrDomain=0;
	/*PMSTA-48867-Satya*/
	DBA_DYNFLD_ST   ptfIdDynSt;
	FLAG_T          hierConstrUsed = 0;
	FLAG_T          stratNetAmtFlg = FALSE;
	GEN_GetApplInfo(ApplHierConstraintUsed, &hierConstrUsed);

	/* REF3030 */
	FIN_PRICEARG_ST	  priceArgSt;
	memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
	memset(&oldPosDate, 0, sizeof(DATETIME_T));

	/* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    refCurrDomain = GET_ID(domainPtr, A_Domain_CurrId);
	}

    if(EV_TracePerf)  /*PMSTA-48195 */
    {
        DBA_DYNFLD_STP ptf = NULLDYNST;
        FLAG_T allocFlg = FALSE;
        std::string dateStr = DATE_ToYyyyMmDdStr(GET_DATE(domainPtr, A_Domain_InterpFromDate));
        DBA_GetPtfById(GET_ID(domainPtr, A_Domain_PtfObjId), FALSE, &allocFlg, &ptf, posHierHead, UNUSED, UNUSED);
        if (ptf != NULLDYNST)
        {
            MSG_LogSrvMesg(UNUSED, 0, "Valo for portfolio %1, date=%2", CodeType, GET_CODE(ptf, A_Ptf_Cd),
                String1000Type, dateStr.c_str());
			if(allocFlg == TRUE) FREE_DYNST(ptf,A_Ptf);
        }
    }

	/*** READ EACH EXTENDED POSITION TO VALUATE ***/
    /* in case of IPS- performance , hierarchy having positions of the same list/hierarchy */
	/* Extract positions order by date, instr_id, curr_id and term_tp_id */
	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, copyRecFlg,
		                             valoProcFilter, FIN_CmpValoPos,
					                 &posNbr, &extractPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* REF2561 - Do nothing in case of 0 position - ExtractHierEltRec is moved upper */
	if (posNbr == 0)
		return(RET_SUCCEED);

    /* PMSTA-32772 - DDV - 180904 - Code move from function FIN_AnalysisValo to this one to be execute each time a valo is done */
	/* update the flag required for populating the accrued interest
       chrono for cash positions : PMSTA-27729 - Smitha - 180115*/
	if ((ret = FIN_UpdAccrIntrFlag(extractPos, posNbr)) != RET_SUCCEED)
	{
		return(ret);
	}

    if ((prPtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

    accrInterArg.scptAIStp = (PTR)NULL;
    accrInterArg.fullCoupFlg = FALSE;
    accrInterArg.fusDateRule = FusDateRule_None;
    accrInterArg.calcAccrInterFlg = FALSE;
    accrInterArg.txdInterFlg = FALSE;
    accrInterArg.accrInterMethod = AccrInterMethod_Default;    /* REF7265 - YST - 020409 */
    accrInterArg.accrValFromDate.date = 0;                     /* REF7265 - YST - 020409 */
    accrInterArg.accrValFromDate.time = 0;                     /* REF7265 - YST - 020409 */

    if ((scriptDefPtr = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
    {
		FREE(extractPos);	/* REF2561 */
		FREE_DYNST(prPtr, A_InstrPrice);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    {
        DBA_SearchAttribSqlName(PVal, "accr_int_m", &dictAttrSt);
        SET_DICT(scriptDefPtr, A_ScriptDef_AttrDictId, dictAttrSt->attrDictId);

        DbiConnectionHelper dbiConnHelper;
        if (dbiConnHelper.isValidAndInit() == false)
        {
            return RET_DBA_ERR_CONNOTFOUND;
        }

        /* Try user default value */
        SET_ENUM(scriptDefPtr, A_ScriptDef_NatEn, ScriptDef_UserGuiDefVal);
        if (DBA_GetScptDef(scriptDefPtr, *dbiConnHelper.getConnection()) != RET_SUCCEED)
        {
            FREE(extractPos);	/* REF2561 */
            FREE_DYNST(scriptDefPtr, A_ScriptDef);
            FREE_DYNST(prPtr, A_InstrPrice);
            return(RET_SUCCEED);
        }

        if (GET_NOTE(scriptDefPtr, A_ScriptDef_Def) != NULL &&
            strncmp(GET_NOTE(scriptDefPtr, A_ScriptDef_Def), "{NOTUSED", 8) != 0)
        {
            /* Generate an evaluation tree */
            if ((SCPT_GenerateScptTree((char *)GET_NOTE(scriptDefPtr, A_ScriptDef_Def),
                                       PVal, InternalSMode, NumberType, &genContext)) == RET_SUCCEED)
            {
                accrInterArg.scptAIStp = (PTR)genContext;
            }
        }

        if (accrInterArg.scptAIStp == (PTR)NULL)
        {
            /* Try system default value */
            SET_ENUM(scriptDefPtr, A_ScriptDef_NatEn, ScriptDef_SysGuiDefVal);

            if (DBA_GetScptDef(scriptDefPtr, *dbiConnHelper.getConnection()) != RET_SUCCEED)
            {
                FREE(extractPos);	/* REF2561 */
                FREE_DYNST(scriptDefPtr, A_ScriptDef);
                FREE_DYNST(prPtr, A_InstrPrice);
                return(RET_SUCCEED);
            }

            /* No script found, take the first element in list. */
            if (GET_NOTE(scriptDefPtr, A_ScriptDef_Def) != NULL &&
                strncmp(GET_NOTE(scriptDefPtr, A_ScriptDef_Def), "{NOTUSED", 8) != 0)
            {
                /* Generate an evaluation tree */
                if ((SCPT_GenerateScptTree((char *)GET_NOTE(scriptDefPtr, A_ScriptDef_Def),
                                           PVal,
                                           InternalSMode,
                                           NumberType,
                                           &genContext)) == RET_SUCCEED)
                {
                    accrInterArg.scptAIStp = (PTR)genContext;
                }
            }
        }
    }

	FREE_DYNST(scriptDefPtr, A_ScriptDef);

	/*** SET VALORISATION EXTENSION FOR EACH EXTRACTED POSITION ***/
	if ((ret = DBA_SetHierLnkUsed(posHierHead, ExtPos, ExtPos_PosVal_Ext)) != RET_SUCCEED)
	{
        if (accrInterArg.scptAIStp != NULL)
            SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
		FREE_DYNST(prPtr, A_InstrPrice);
		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
		return(ret);
	}

	/* BUG135 */
	if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE ||
	    GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn) != FundSplitRule_None)
	{
		if ((ret = DBA_SetHierLnkUsed(posHierHead, ExtPos,
					   ExtPos_RiskOrigin_ExtPos_Ext)) != RET_SUCCEED)
		{
            if (accrInterArg.scptAIStp != NULL)
                SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
			FREE_DYNST(prPtr, A_InstrPrice);
			FREE(extractPos);  /* Only array pointer */
			return(ret);
		}

		if ((ret = DBA_SetHierLnkUsed(posHierHead, ExtPos,
					   ExtPos_RiskPar_A_Instr_Ext)) != RET_SUCCEED)
		{
            if (accrInterArg.scptAIStp != NULL)
                SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
			FREE_DYNST(prPtr, A_InstrPrice);
			FREE(extractPos);  /* Only array pointer */
			return(ret);
		}
	}

	if (GET_FLAG(domainPtr, A_Domain_DfltFusDateRuleFlg) == TRUE &&
	    GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)!=PtfConsRule_Merged)
		domainArg.fusDatePtfFlg = TRUE;
	else
		domainArg.fusDatePtfFlg = FALSE;

	/* BUG175 - option risk treatment */
	if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == FALSE)
	{
	    domainArg.optDeltaRule = OptDelta_None;
	}
	else
	{
	    domainArg.optDeltaRule = (OPTDELTARULE_ENUM) GET_ENUM(domainPtr, A_Domain_OptRiskRuleEn);
	}

    /* REF5576 - SSO - 010111 A_Domain_DfltFusDateRuleFlg->A_Domain_FusDateRuleEn */
	domainArg.domFusDateRule = (FUSDATERULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusDateRuleEn);
	domainArg.fromDateTime   = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);

	/* Force first instrument price calculation */
	oldInstrId  = 0;
	oldCurrId   = 0;
	oldTermTpId = 0;

    /* REF3909 - 990819 - DDV - Determine the number od PosVal which will be created
       and prealloc recInfoTab to avoid multiple reallocation */
    newPosValNbr=posNbr;
    for (i=0; i<posNbr; i++)
    {
        /* (DVP018) if PosVal exist (load from database) don't value position */
        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
            *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext)) != NULLDYNST)
            newPosValNbr--;
    }

        /* Prealloc dataTab in hierarchy for better performance */
        DBA_PreAllocRecInfoTab(posHierHead, PosVal, newPosValNbr);

	    for (i=0; i<posNbr; i++)
	    {
			FIN_UpdDomainRefCurr(domainPtr, extractPos[i]); /* REF6220 - LJE - 020319 */
			domainArg.refCurrId = GET_ID(domainPtr, A_Domain_CurrId);

			/* PMSTA-53235 - SENTHIL - 15072023 */
			if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Perfo && GET_ENUM(domainPtr, A_Domain_PLMethodEn) == PLMethod_ReprocessPL)
			{
				if (IS_NULLFLD(extractPos[i], ExtPos_BalPosTpId) == TRUE && GET_FLAG(extractPos[i], ExtPos_AcctFlg) == TRUE)
					SET_ENUM(extractPos[i], ExtPos_NatEn, ExtPosNat_FinalStock);
			}

            /* (DVP018) if PosVal exist (load from database) don't value position */
	        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
	            (posValPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext))) != NULLDYNST)
	        {
                COPY_DYNFLD(extractPos[i], ExtPos, ExtPos_PosValId, posValPtr, PosVal, PosVal_Id);

                /* REF5442 - DDV - 010205 */
                if ((newExtTab = (DBA_DYNFLD_STP*)
                    CALLOC(sizeof(DBA_DYNFLD_STP), 1)) == NULLDYNSTPTR)
                    MSG_RETURN(RET_MEM_ERR_ALLOC);

                newExtTab[0] = extractPos[i];
                SET_HIER_EXTENSION(posValPtr, PosVal_ExtPos_Ext, newExtTab, ExtPos, 1);
                COPY_DYNFLD(posValPtr, PosVal, PosVal_ExtPosId, extractPos[i], ExtPos, ExtPos_Id);

		        continue;
	        }

	        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
	    	    instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));

	        /*** ADD VALORISATION EXTENSION ***/
	        if ((ret = FIN_PosExtValo(posHierHead, extractPos[i]))!=RET_SUCCEED)
	        {
                if (accrInterArg.scptAIStp != NULL)
                	SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
		        FREE_DYNST(prPtr, A_InstrPrice);
		        FREE(extractPos);  /* Only array pointer */
		        return(ret);
	        }

	        /* DVP187 - Create a blank valorisation instead of nothing */
	        /* Don't value Debt instruments (in case of fund splitting) */
	        if (GET_FLAG(domainPtr, A_Domain_DebtFlg) == FALSE &&
		        (INSTRNAT_ENUM)GET_ENUM(instrPtr,A_Instr_NatEn)==InstrNat_Debt)
		        continue;

	        /* REF1511 - Don't valorise position with qty 0 with return fct. */
	        if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Return &&
		    CMP_NUMBER(GET_NUMBER(extractPos[i], ExtPos_Qty), 0.0) == 0 &&
		    CMP_AMOUNT(GET_AMOUNT(extractPos[i], ExtPos_AccrAmt), 0.0, GET_ID(extractPos[i], ExtPos_PosCurrId)) == 0 && /* REF2614 */ /* REF4012 - 000310 - DED */
            GET_FLAG(extractPos[i], ExtPos_AccrIntChronoFlg) == FALSE) /* PMSTA-33393 - 261018 - MSS - compute zero position if the _AccrIntChronoFlg flag is set*/
		        continue;

	        /* DVP197- Create a blank valorisation for locking/unlocking position */
	        /* REF1365 - Add new locking natures */
	        opLockNatEn = (OPLOCKNAT_ENUM) GET_ENUM(extractPos[i], ExtPos_LockNatEn);
	        if (opLockNatEn==OpLockNat_LockingPos || opLockNatEn==OpLockNat_UnlockingPos ||
		        opLockNatEn==OpLockNat_RepoLocking || opLockNatEn==OpLockNat_RepoUnlocking ||
		        opLockNatEn==OpLockNat_SellBuyBackLocking || opLockNatEn==OpLockNat_SellBuyBackUnlocking || /* REF2444 - 980717 - DDV */
	            opLockNatEn==OpLockNat_RemereLocking || opLockNatEn==OpLockNat_RemereUnlocking ||
		        opLockNatEn==OpLockNat_RevRepoLocking || opLockNatEn==OpLockNat_RevRepoUnlocking ||
		        opLockNatEn==OpLockNat_BuySellBackLocking || opLockNatEn==OpLockNat_BuySellBackUnlocking) /* REF2444 - 980717 - DDV */
		        continue;

	        ret = RET_SUCCEED;

            FIN_GetValRuleIdInDomPPSPtf(domainPtr, extractPos[i], posHierHead, &newQuoteValRuleId);

            if (oldQuoteValRuleId != newQuoteValRuleId)
                valRuleDepChk = NO_VALUE;

	        /*** OBTAINS POSITION PRICE ***/
	        /* Position table is sort by date, instr_id, curr_id and */
	        /* term_tp_id so if 4 criters are same, keep last price  */
	        if (oldTermTpId != GET_ID(extractPos[i], ExtPos_TermTpId) ||
		        oldCurrId   != GET_ID(extractPos[i], ExtPos_PosCurrId) ||
		        oldInstrId  != GET_ID(extractPos[i], ExtPos_InstrId) ||
	            (DATETIME_CMP(oldPosDate, GET_DATETIME(extractPos[i], ExtPos_ExtPosDate)) != 0) ||
				PriceCalcRule_PortfolioSpecificPrice == static_cast<PRICECALCRULE_ENUM>GET_ENUM(extractPos[i], ExtPos_PriceCalcRuleEn)) /* PMSTA-32158 - SILPA - 180905 */
	        {
                computePosPriceFlg = TRUE;
	        }
	        else
            {
                /* REF4478 - DDV - 000411 - Quote valuation rule gestion.
                   If the quote valuation rule is the same and
                   no dependences with the postion, don't call FIN_PosPrice */
                if (oldQuoteValRuleId == newQuoteValRuleId)
                {
                    if (valRuleDepChk == NO_VALUE)
                    {
                        valRuleDepChk = FIN_ChechIfValRuleUseExtPos(newQuoteValRuleId, domainPtr);
                        computePosPriceFlg = (FLAG_T) valRuleDepChk;
                    }
                    else
                        computePosPriceFlg = (FLAG_T) valRuleDepChk;
                }
                else
                    computePosPriceFlg = TRUE;
            }

            oldQuoteValRuleId = newQuoteValRuleId;

			/* PMSTA14443 - DDV - 120709 - Do the same treament for exchange valuation rule than for price valuation rule */
			FIN_GetExchValRuleIdInDomPPSPtf(domainPtr, extractPos[i], posHierHead, &newExchValRuleId);

            if (oldExchValRuleId != newExchValRuleId)
                exchRuleDepChk = NO_VALUE;

	        if (computePosPriceFlg == FALSE)
			{
                if (oldExchValRuleId == newExchValRuleId)
                {
                    if (exchRuleDepChk == NO_VALUE)
                    {
                        exchRuleDepChk = FIN_ChechIfValRuleUseExtPos(newExchValRuleId, domainPtr);
                        computePosPriceFlg = (FLAG_T) exchRuleDepChk;
                    }
                    else
                        computePosPriceFlg = (FLAG_T) exchRuleDepChk;
                }
                else
                    computePosPriceFlg = TRUE;
            }

            oldExchValRuleId = newExchValRuleId;

            if (computePosPriceFlg == TRUE)
	        {
		        oldTermTpId = GET_ID(extractPos[i], ExtPos_TermTpId);
		        oldCurrId   = GET_ID(extractPos[i], ExtPos_PosCurrId);
		        oldInstrId  = GET_ID(extractPos[i], ExtPos_InstrId);
		        oldPosDate  = GET_DATETIME(extractPos[i], ExtPos_ExtPosDate);

		        ret = FIN_PosPrice(extractPos[i], instrPtr,
		                           GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
			                       &priceArgSt, prPtr, domainPtr,
                                   posHierHead);	/* REF3030 */
	        }

            /* Copy price in position, last price if new position        */
	        /* parameters are same than last, calculated price elsewhere */
	        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
	        {
	   	        if (FIN_SetPriceToPos(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
			                          domainArg.refCurrId, extractPos[i],
                                      prPtr, posHierHead) == TRUE) /* REF2580 - SSO - 980727 */
		        {
	                /*** COMPUTE POSITION NET VALUE ***/
		            ret = FIN_PosNetVal(posHierHead, &domainArg, extractPos[i], domainPtr, &accrInterArg);

		            if (ret == RET_SUCCEED)
		            {
			            /* -------------------------------- */
			            /* DVP079 - OLD CODE - RAK - 960531 */
			            /*** PORTFOLIO NET VALUE ***/
		                /* if ((ptfPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Ptf_Ext))) != NULLDYNST)
		                {
			                if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
				                (extValo = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext))) != NULLDYNST)
			                {
			            */
				        /* ----------------------------------------------- */
			            /* BEGIN DVP023 (Productivity)          960503 RAK */
		   		        /* tot = GET_NUMBER(ptfPtr,  A_Ptf_NetValM) +       */
			      	    /*       GET_NUMBER(extValo, PosVal_RefMktValAmt); */
				        /* SET_NUMBER(ptfPtr, A_Ptf_NetValM, tot);          */
		   		        /* tot = GET_NUMBER(ptfPtr,  A_Ptf_MktValM) +
			      	         GET_NUMBER(extValo, PosVal_RefMktValAmt);
				        SET_NUMBER(ptfPtr, A_Ptf_MktValM, tot);
		   		        tot = GET_NUMBER(ptfPtr,  A_Ptf_NetValM) +
			      	         GET_NUMBER(extValo, PosVal_RefNetAmt);
				        SET_NUMBER(ptfPtr, A_Ptf_NetValM, tot);          */
			            /* END DVP023                          960503 RAK  */
				        /* ----------------------------------------------- */
			            /*
			            }
			         }
			*/
			/* DVP079 - OLD CODE - RAK - 960531 */
			/* -------------------------------- */

	    	/*** FUND SPLITTING ***/
			domainArg.fundRiskEn = FinFundRisk_None;

			if (GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn) != FundSplitRule_None)
			{
			    if (GET_SMALLINT(domainPtr, A_Domain_FundSplitLevel) != FUNDSPLIT_MAXLEVEL)
			    {
				/* REF524 - Call FIN_FundSplittingTreat() */
	    			ret = FIN_FundSplittingTreat(domainPtr, &domainArg, &accrInterArg,
							     posHierHead, extractPos[i]);

	    			if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
				    RET_GET_CATEG(ret) == RET_CATEG_MEM)
	    			{
                		    if (accrInterArg.scptAIStp != NULL)
                			    SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
				    FREE_DYNST(prPtr, A_InstrPrice);
				    FREE(extractPos);
				    return(ret);
	    			}
			    }
			    else
			    {
				/* REF3455 - SSO - 990325: message if max level reached */
				MSG_LogMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, "FIN_ValoProcess: Fund Splitting max. level reached!");
			    }
			}

		        /*** RISK EXPOSURE ***/
		   	if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE &&
			    domainArg.fundRiskEn == FinFundRisk_None)
		        {
			    domainArg.riskDecompoLevel = 0;
			    ret = FIN_RiskAnalysis(posHierHead, domainPtr, &domainArg,
						   &accrInterArg, extractPos[i]);

    			    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
	                        RET_GET_CATEG(ret) == RET_CATEG_MEM)
    			    {
                		if (accrInterArg.scptAIStp != NULL)
                			SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);
			    	FREE_DYNST(prPtr, A_InstrPrice);
			    	FREE(extractPos);
			    	return(ret);
    			    }
		        }

			/* for next position */
			domainArg.fundRiskEn = FinFundRisk_None;
		   }
		}      /* FIN_SetPriceToPos() return */
	    }      /* price founded */
	}

        if (accrInterArg.scptAIStp != NULL)
        	SCPT_FreeScptTree((SCPT_ARG_STP) accrInterArg.scptAIStp);

	if (GET_FLAG(domainPtr, A_Domain_DebtFlg) == TRUE)
        {
		FIN_ComputeDebtScript(domainPtr, posHierHead, valoProcFilter);
		FIN_ComputeDebtSimpleScript(domainPtr, posHierHead, valoProcFilter); /* REF2338 - DDV - 981029 */
        }

	/* BUG118 - Make only added risk position link */
	/* if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE)
	{
	    DBA_MakeSpecRecLinks(posHierHead, ExtPos, ExtPos_Main_ExtPos_Ext);
	} */

	FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
	FREE_DYNST(prPtr, A_InstrPrice);

    /* PMSTA-11327 - LJE - 110204 - Delete only "risk view" data */
    /* PMSTA-10111 - RAK - 110404 - elsewhere suppress flow on cash */
	/* for the FWD in case of risk computation (I verify for future and no change) */
	/* if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE)
		ret = FIN_DelNoAcctNoRiskExtPosFromHier(posHierHead);	 PMSTA-8736 - RAK - 100205 */

    /* PMSTA17014 - DDV - 130103 - For some functions (perfo and others), only final positions must be extract to compute market value */
    if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Perfo ||
        GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_MultiValo ||
        GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PLRestart)
    {
        mktValFilter = FIN_FilterFinalStock;
    }

	/* --------------------------- */
	/* BEGIN DVP079 - RAK - 960531 */
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, mktValFilter, NULLFCT,
					                 &posNbr, &extractPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	/*PMSTA-48867-Satya*/
	
	if (hierConstrUsed == 1) 
	{
		if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
			GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder ||
			GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation)
		{
			stratNetAmtFlg = FALSE;
		}
		else
		{
			GEN_GetApplInfo(ApplStratNetAmtFlag, &stratNetAmtFlg);
		}
	}

	for (i=0; i<posNbr; i++)
	{
        /* PMSTA-24861 - DDV - 160923 - Skip technical positions */
        if (DBA_IsTechnicalPosition(extractPos[i]) == true)
            continue;

	    if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Ptf_Ext) != NULL &&
	        (ptfPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Ptf_Ext))) != NULLDYNST)
	    {
		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
		    (extValo = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext))) != NULLDYNST)
	 	{
            if ((GET_FLAG(ptfPtr, A_Ptf_singleMPNoTargetWgtFlg) == TRUE) &&
                IS_NULLFLD(extractPos[i], ExtPos_ChildPtfId) == TRUE &&
                IS_NULLFLD(extractPos[i], ExtPos_CashPortfolioId) == TRUE)
            {
                /*if single mp no target weight then dont consider parent postions*/
                continue;
            }

            if ((GET_FLAG(ptfPtr,A_Ptf_singleMPNoTargetWgtFlg) == TRUE) &&
                IS_NULLFLD(extractPos[i], ExtPos_CashPortfolioId) == FALSE && //if single MP target weight and parent postion then ignore
                GET_FLAG(extractPos[i], ExtPos_MainFlg) == TRUE && 
                POSNAT_ENUM::PosNat_MainAcctPos == static_cast<POSNAT_ENUM>GET_ENUM(extractPos[i], ExtPos_PosNatEn))
            {
                /*if single mp no-target weight and the postion is for parent account we should ignore.*/
                continue;
            }

	            if (GET_ENUM(extractPos[i], ExtPos_RiskNatEn) == ExtPosRisk_FinRisk)
	            {
			tot = GET_NUMBER(ptfPtr,  A_Ptf_RiskNetValM) +
			      GET_NUMBER(extValo, PosVal_RefNetAmt);
			SET_NUMBER(ptfPtr, A_Ptf_RiskNetValM, CAST_NUMBER(tot)); /* REF3288 - SSO - 990205 */

			tot = GET_NUMBER(ptfPtr,  A_Ptf_RiskMktValM) +
			      GET_NUMBER(extValo, PosVal_RefMktValAmt);
			SET_NUMBER(ptfPtr, A_Ptf_RiskMktValM, CAST_NUMBER(tot)); /* REF3288 - SSO - 990205 */
	            }

	            if (GET_FLAG(extractPos[i], ExtPos_AcctFlg) == TRUE)
	            {
			tot = GET_NUMBER(ptfPtr,  A_Ptf_NetValM) +
			      GET_NUMBER(extValo, PosVal_RefNetAmt);
			SET_NUMBER(ptfPtr, A_Ptf_NetValM, tot);

			tot = GET_NUMBER(ptfPtr,  A_Ptf_MktValM) +
			      GET_NUMBER(extValo, PosVal_RefMktValAmt);
			SET_NUMBER(ptfPtr, A_Ptf_MktValM, CAST_NUMBER(tot)); /* REF3288 - SSO - 990205 */
	            }
	        }
	    }

		/*PMSTA-48867-Satya*/
		if (hierConstrUsed == 1)
		{
			if (GET_EXTENSION_PTR(extractPos[i], ExtPos_ChildPtf_Ext) != NULL)
				ptfPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_ChildPtf_Ext));
			else
			{                
	            DBA_DYNFLD_STP  *ptfTab = NULLDYNSTPTR;
	            int				ptfNbr = 0;

				memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST));
				SET_ID((&ptfIdDynSt), 0, GET_ID(extractPos[i], ExtPos_PtfId));
				if ((ret = DBA_ExtractHierEltRecByIndexKey(posHierHead, A_Ptf, A_Ptf_Id,
					ptfIdDynSt, FALSE, NULL, NULLDYNST, NULL, FALSE,
					&ptfNbr, &ptfTab)) == RET_SUCCEED)
				{
					if (ptfNbr > 0)
						ptfPtr = ptfTab[0];
				}
                FREE(ptfTab);
			}

			if (ptfPtr != NULLDYNST)
			{
				if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
					(extValo = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext))) != NULLDYNST)
				{
					if ((GET_FLAG(ptfPtr, A_Ptf_singleMPNoTargetWgtFlg) == TRUE) &&
						IS_NULLFLD(extractPos[i], ExtPos_ChildPtfId) == TRUE &&
						IS_NULLFLD(extractPos[i], ExtPos_CashPortfolioId) == TRUE)
					{
						/*if single mp no target weight then dont consider parent postions*/
						continue;
					}

					if ((GET_FLAG(ptfPtr, A_Ptf_singleMPNoTargetWgtFlg) == TRUE) &&
						IS_NULLFLD(extractPos[i], ExtPos_CashPortfolioId) == FALSE && //if single MP target weight and parent postion then ignore
						GET_FLAG(extractPos[i], ExtPos_MainFlg) == TRUE &&
						POSNAT_ENUM::PosNat_MainAcctPos == static_cast<POSNAT_ENUM>GET_ENUM(extractPos[i], ExtPos_PosNatEn))
					{
						/*if single mp no-target weight and the postion is for parent account we should ignore.*/
						continue;
					}

					if (GET_FLAG(extractPos[i], ExtPos_AcctFlg) == TRUE)
					{
						if (stratNetAmtFlg == FALSE)
						{
							tot = GET_NUMBER(ptfPtr, A_Ptf_SelfMktValM) +
								GET_NUMBER(extValo, PosVal_RefMktValAmt);
							SET_NUMBER(ptfPtr, A_Ptf_SelfMktValM, CAST_NUMBER(tot));
						}
						else
						{
							tot = GET_NUMBER(ptfPtr, A_Ptf_SelfMktValM) +
								GET_NUMBER(extValo, PosVal_RefNetAmt);
							SET_NUMBER(ptfPtr, A_Ptf_SelfMktValM, tot);
						}
					}
				}
			}
		}
	}

	FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
	/* END DVP079 - RAK - 960531 */
	/* ------------------------- */

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    SET_ID(domainPtr, A_Domain_CurrId, refCurrDomain);
	}

    /* REF10236 - LJE - 040615 */
    if (EV_TraceFinFctFile != NULL && EV_TraceFinFct > 2 && posHierHead != NULL)
    {
        DBA_HierDump(posHierHead, NullDynSt, TRUE, EV_TraceFinFctFile);
    }

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_PosExtValo()
**
**  Description :   Allocate and add valorisation extension to received pos.
**
**  Arguments   :   poshierHead    extended position hierarchy header
**                  pos            position pointer
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE FIN_PosExtValo(DBA_HIER_HEAD_STP posHierHead,
                        DBA_DYNFLD_STP    pos)
{
	DBA_DYNFLD_STP posVal=NULLDYNST;
    DBA_DYNFLD_STP  *newExtTab=NULLDYNSTPTR;
	RET_CODE       ret;

	if ((posVal = ALLOC_DYNST(PosVal)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((ret = DBA_AddHierRecord(posHierHead, posVal, PosVal,
				                 FALSE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
		return(ret);

	/* Create link between position and valorisation */
    /* To it manualy for performamnece issue - DDV - REF5001 - 000715 */
	/*ret = DBA_ForceLink(posHierHead, ExtPos, ExtPos_PosVal_Ext, pos, posVal);
	return(ret);*/
	/*PMSTA-52427 BSV 190723*/
	/* In case of Risk position, linkage is already present.So checking and allocating the extension 
	to avoid memory leak of previously allocated linkage */
	DBA_DYNFLD_STP      valo = NULLDYNST;
	if (GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext) == NULL ||
		(valo = *(GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext))) == NULLDYNST)
	{
		if ((newExtTab = (DBA_DYNFLD_STP*)
			CALLOC(sizeof(DBA_DYNFLD_STP), 1)) == NULLDYNSTPTR)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		newExtTab[0] = posVal;

		SET_HIER_EXTENSION(pos, ExtPos_PosVal_Ext, newExtTab, PosVal, 1);
		COPY_DYNFLD(pos, ExtPos, ExtPos_PosValId, posVal, PosVal, PosVal_Id);
	}
    /* REF5442 - DDV - 010116 */
    if ((newExtTab = (DBA_DYNFLD_STP*)
                   CALLOC(sizeof(DBA_DYNFLD_STP), 1)) == NULLDYNSTPTR)
      MSG_RETURN(RET_MEM_ERR_ALLOC);

    newExtTab[0] = pos;

    SET_HIER_EXTENSION(posVal, PosVal_ExtPos_Ext, newExtTab, ExtPos, 1);

    COPY_DYNFLD(posVal, PosVal, PosVal_ExtPosId, pos, ExtPos, ExtPos_Id);

    return(RET_SUCCEED);

}

/************************************************************************
**
**  Function    :   FIN_PosGetDateRuleExchDate()
**
**  Description :   Get exchange date according to fusion date rule
** 		            (portfolio position set, portfolio or parameter)
**
**  Arguments   :   posPtr           position pointer
**                  sPtfPosSetPtr
**                  ptfPosSetPtr
**		            fusDateRulePtr   pointer on fusion date rule used
**		            exchDatePtr      pointer on exchange date tu use
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF2610 - RAK - 980824
**
**  Modification :  PMSTA05045 - LJE - 080104 : Put this function in extern
**
*************************************************************************/
RET_CODE FIN_PosGetDateRuleExchDate(DBA_DYNFLD_STP   posPtr,
 				                    DBA_DYNFLD_STP   *sPtfPosSetPtr,
				                    DBA_DYNFLD_STP   *ptfPosSetPtr,
				                    FUSDATERULE_ENUM *fusDateRulePtr,
				                    DATETIME_T       *exchDatePtr)
{
	DBA_DYNFLD_STP		ptfPtr=NULLDYNST;

	*exchDatePtr = GET_DATETIME(posPtr, ExtPos_OpDate);

	if (IS_NULLFLD(posPtr, ExtPos_PtfPosSetId) == FALSE &&
	    GET_ID(posPtr, ExtPos_PtfPosSetId) != 0)
	{
		if ((*sPtfPosSetPtr) == NULLDYNST)
		{
		    if (((*sPtfPosSetPtr) = ALLOC_DYNST(S_PtfPosSet)) == NULLDYNST)
		    {
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }
		}

		if ((*ptfPosSetPtr) == NULLDYNST)
		{
		    if (((*ptfPosSetPtr) = ALLOC_DYNST(A_PtfPosSet)) == NULLDYNST)
		    {
			FREE_DYNST((*sPtfPosSetPtr), S_PtfPosSet);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }
		}

		SET_ID((*sPtfPosSetPtr), S_PtfPosSet_Id,
		    GET_ID(posPtr, ExtPos_PtfPosSetId));

	 	if (DBA_Get2(PtfPosSet, UNUSED, S_PtfPosSet, (*sPtfPosSetPtr),
		             A_PtfPosSet, ptfPosSetPtr,
		             UNUSED, UNUSED, UNUSED) != TRUE)
		{
			FREE_DYNST((*sPtfPosSetPtr), S_PtfPosSet);
			FREE_DYNST((*ptfPosSetPtr), A_PtfPosSet);
			return(RET_DBA_ERR_NODATA);
		}

		*fusDateRulePtr = (FUSDATERULE_ENUM)
			          GET_ENUM((*ptfPosSetPtr), A_PtfPosSet_FusDateRuleEn);

	}
	else if ( (IS_NULLFLD(posPtr, ExtPos_A_Ptf_Ext)== FALSE) /* REF3255- SSO - 990203 */
		&& GET_EXTENSION_PTR(posPtr, ExtPos_A_Ptf_Ext) != NULL  /* REF3870 - RAK - 990803 */
		&& (ptfPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_A_Ptf_Ext))) != NULLDYNST)
	{
		*fusDateRulePtr = (FUSDATERULE_ENUM)
				  GET_ENUM(ptfPtr, A_Ptf_FusionDateRuleEn);
	}
	else
	{
		GEN_GetApplInfo(ApplFusDateRule, fusDateRulePtr);
	}

	switch ((*fusDateRulePtr))
	{
       	case FusDateRule_OpDate :
		*exchDatePtr = GET_DATETIME(posPtr, ExtPos_OpDate);
		break;

	case FusDateRule_AcctDate :
       		*exchDatePtr = GET_DATETIME(posPtr, ExtPos_AcctDate);
               	break;

	case FusDateRule_ValDate :
       		*exchDatePtr = GET_DATETIME(posPtr, ExtPos_ValDate);
		break;

	case FusDateRule_None :
       		*exchDatePtr = GET_DATETIME(posPtr, ExtPos_OpDate);
               	break;
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_PosNetVal()
**
**  Description :   Compute position value at receive reference date depending
**                  on quotation retrieval method and instrument data.
**
**  Arguments   :   posHierHead    extended position hierarchy header
**                  domainArgPtr   pointer on some domain informations
**                  pos            position pointer
**                  domainPtr      pointer on domain structure (can be NULL)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	:   BUG360 - RAK - 970501
**  Modif.	:   REF1457 - RAK - 980324
**  Modif.	:   REF2580 - SSO - 980727
**  Modif.	:   REF3501 - RAK - 990326
**  Modif.  :   REF10256 - TEB - 040615
**
*************************************************************************/
RET_CODE FIN_PosNetVal(DBA_HIER_HEAD_STP  posHierHead,
		               FIN_DOMAIN_ARG_STP domainArgPtr,
                       DBA_DYNFLD_STP     pos,
			           DBA_DYNFLD_STP     domainPtr,
			           FIN_AIARG_STP      aiArgPtr)
{
	DBA_DYNFLD_STP    ptfPtr=NULLDYNST, instrPtr=NULLDYNST;
	FIN_MKTVAL_ST     mktVal;
	DATETIME_T        accrDate;
	RET_CODE          ret;
	ACCACCRINTERDATERULE_ENUM accAIDateRule;        /* BUG360 - RAK - 970501 */
	DATE_T            fusionSwitchDate;				/* REF10256 - TEB - 040615 */
	/* Warning at compil - CSA - 05/04/2001
    FUSDATERULE_ENUM  sysFusDateRule;*/

	aiArgPtr->txdInterFlg = FALSE;			/* REF1457 - Update argument struct. */


    /* REF5576 - SSO - 010129: ALWAYS LOOK IN CHRONO IF ANY ! */
	aiArgPtr->calcAccrInterFlg = FALSE;

#ifdef NOT_USED
*    /* If calcAccrInterFlg is FALSE, search first in chrono */
*	if (aiArgPtr->fusDateRule == FusDateRule_None)
*		aiArgPtr->calcAccrInterFlg = FALSE;
*	else
*	{
*		GEN_GetApplInfo(ApplFusDateRule, &sysFusDateRule); /* REF1149 - c.f RAK */
*
*		if ((sysFusDateRule == FusDateRule_ValDate &&
*		     aiArgPtr->fusDateRule == FusDateRule_ValDate) ||
*		    (sysFusDateRule != FusDateRule_ValDate &&
*		     aiArgPtr->fusDateRule != FusDateRule_ValDate))
*			aiArgPtr->calcAccrInterFlg = FALSE;
*		else
*			aiArgPtr->calcAccrInterFlg = TRUE;
*	}
#endif

	if (GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext) != NULL)
		instrPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext));

	/* REF3501 - RAK - 990326 */
	/*
	if (domainPtr != NULLDYNST && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Debt &&
            GET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg) == TRUE)
		aiArgPtr->fullCoupFlg = TRUE;
	else
		GEN_GetApplInfo(FullCouponFlag, &(aiArgPtr->fullCoupFlg));
	*/
	if (GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T) InstrNat_Debt)
	{
		/* In case of Journal call FundValo, A_Domain_DebtFullCouponFlg is forced to TRUE */
		/* elsewhere A_Domain_DebtFullCouponFlg contains FullCouponDebtFlag value. */
		if (domainPtr != NULLDYNST)
		    aiArgPtr->fullCoupFlg = GET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg);
		else
		    GEN_GetApplInfo(FullCouponDebtFlag, &(aiArgPtr->fullCoupFlg));
	}
	else
		GEN_GetApplInfo(FullCouponFlag, &(aiArgPtr->fullCoupFlg));

	/* BUG360 - RAK - 970501 */
	GEN_GetApplInfo(ApplAccAccrInterDateRule, &accAIDateRule);

	if ( (accAIDateRule == AccAccrInterDateRule_BegDate &&
		(INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
		/* REF3705 - SSO - 990604 : for Avrge Rate instr, force use of from date
		    because elsewhere if valuedate is after from date we add one day AI
		    although value date is not reached... */
	    || (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate) )
	{
	    accrDate = GET_DATETIME(pos, ExtPos_ExtPosDate);
	}
	else
	{
	    if (DATETIME_CMP(GET_DATETIME(pos, ExtPos_ExtPosDate),
			     GET_DATETIME(pos, ExtPos_ValDate)) >= 0)
		accrDate = GET_DATETIME(pos, ExtPos_ExtPosDate);
	    else
		accrDate = GET_DATETIME(pos, ExtPos_ValDate);
	}

	/* REF10256 - TEB - 040615 - Move the code here to have the accrDate */
	if (domainArgPtr->fusDatePtfFlg == TRUE &&
            GET_EXTENSION_PTR(pos, ExtPos_A_Ptf_Ext) != NULL &&
            (ptfPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Ptf_Ext))) != NULLDYNST)
	{
		/* REF10256 - TEB - 040615 - Make the switch if necessary */
		if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == TRUE &&
			DATE_Cmp(accrDate.date, fusionSwitchDate) < 0)
		{
			aiArgPtr->fusDateRule = (FUSDATERULE_ENUM)GET_ENUM(ptfPtr, A_Ptf_OldFusionDateRuleEn);
		}
		else
		{
			aiArgPtr->fusDateRule = (FUSDATERULE_ENUM)GET_ENUM(ptfPtr, A_Ptf_FusionDateRuleEn); /* REF7264 - LJE - 020124 */
		}
	}
	else
		aiArgPtr->fusDateRule = domainArgPtr->domFusDateRule;

	/* REF1457 - new argument structure */
	if ((ret = FIN_MktVal(pos, instrPtr, GET_DATETIME(pos, ExtPos_ExtPosDate), accrDate,
			      aiArgPtr, &mktVal, posHierHead)) == RET_SUCCEED)
	{
		FIN_SetMktValToPos(GET_DATETIME(pos, ExtPos_ExtPosDate),
				   domainArgPtr->refCurrId, pos, &mktVal,
				   posHierHead, instrPtr); /* REF2580 - SSO - 980727 */
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SetMktValToPos()
**
**  Description :   Copy instrument net value and accrued interest fields
**                  in position structure.
**
**  Arguments   :   fromDateTime from date
**                  refCurrId    reference currency identifier
**                  pPtr         position pointer
**                  mktValPtr    net value pointer
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Modif       :   BUG200 - RAK - 961112
**  Modif.	:   REF2313 - RAK - 980910
**  Modif.	:   REF2580 - SSO - 980727
**  Modif.	:   REF2610 - RAK - 980807
**		        REF3561 - SSO - 990415
**              REF7419 - YST - 020313  - market value for swap
**              REF7782 - YST - 020904
**
*************************************************************************/
STATIC FLAG_T FIN_SetMktValToPos(DATETIME_T     fromDateTime,
                                 ID_T           refCurrId,
			                     DBA_DYNFLD_STP pPtr,
		                         FIN_MKTVAL_STP mktVPtr,
				                 DBA_HIER_HEAD_STP  posHierHead,/* REF2580 - SSO - 980727 */
                                 DBA_DYNFLD_STP    inputInstrPtr) /* REF7419 - YST - 020313 */
{
	DBA_DYNFLD_STP extValo=NULLDYNST, instrPtr=NULLDYNST;
	ID_T           posCurrId, instrCurrId, euroCurrId, incEvtCurrId; /* REF3561 - SSO - 990415 */
	AMOUNT_T       mktValAmt, tmpVal;
	EXCHANGE_T     tmpExch = 1.0;   /* PMSTA-49740 - ankita - 08072022 */
	FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
    FLAG_T          allocOk;
    INSTRNAT_ENUM  instrNatEn = InstrNat_None;
    SUBNAT_ENUM    instrSubNatEn = SubNat_None;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

        if (GET_EXTENSION_PTR(pPtr, ExtPos_PosVal_Ext) != NULL &&
            (extValo = *(GET_EXTENSION_PTR(pPtr, ExtPos_PosVal_Ext))) != NULLDYNST)
	{
        /* REF7419 - YST - 020313 */
        if (inputInstrPtr == NULLDYNST)
	    {
	        if (DBA_GetInstrById(GET_ID(pPtr, ExtPos_InstrId), FALSE, &allocOk,
                    &instrPtr, posHierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
   			    return(FALSE);
		    }
	    }
	    else
	    {
            instrPtr = inputInstrPtr;
		    allocOk = FALSE;
	    }

	   posCurrId   = GET_ID(pPtr, ExtPos_PosCurrId);
	   instrCurrId = GET_ID(pPtr, ExtPos_InstrCurrId);
	   incEvtCurrId = GET_ID(pPtr, ExtPos_IncEvtCurrId);

	   /* -------------------------- */
	   /*** POSITION INFORMATIONS ***/
	   /* -------------------------- */
	   /* DVP018 - Set new field (PosVal_PosId and PosVal_Date) */
	   SET_DATETIME(extValo, PosVal_Date, GET_DATETIME(pPtr, ExtPos_ExtPosDate));
	   SET_ID(extValo, PosVal_PosId,      GET_ID(pPtr, ExtPos_PosObjId));

	   /* --------------------------------- */
	   /*** ACCRUED INTEREST INFORMATIONS ***/
	   /* --------------------------------- */
	   SET_AMOUNT(extValo,   PosVal_AccrInter,   mktVPtr->accrInter); /* PCC07464 - 080221 - DDV - Set accr amount into PosVal */
	   SET_ID(extValo,       PosVal_AccrInterCurrId, mktVPtr->accrInterCurrId);
	   SET_SMALLINT(extValo, PosVal_AccrInterNumPeriod,
		                 (SMALLINT_T) mktVPtr->accrInterPeriod.num);
	   SET_SMALLINT(extValo, PosVal_AccrInterDenomPeriod,
		                 (SMALLINT_T) mktVPtr->accrInterPeriod.denom);

	   /* BUG200 - exchange rate between AI currency and reference currency */
	   if (mktVPtr->accrInterCurrId != 0)
	   {
	       FIN_GetExchRate(fromDateTime, mktVPtr->accrInterCurrId, refCurrId,
			       (ID_T)0, NULLDYNST, pPtr, &exchArgSt, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
	       SET_EXCHANGE(extValo, PosVal_AccrInterExchRate, tmpExch);
	   }

	   /* ----------------------------- */
	   /*** POSITION CURRENCY AMOUNTS ***/
	   /* ----------------------------- */
	   /* BUG200 - mktValAmt, netAmt, accrInterRefCurr are in position currency */
	   SET_AMOUNT(extValo,   PosVal_PosMktValAmt,      mktVPtr->mktValAmt);
	   SET_AMOUNT(extValo,   PosVal_PosNetAmt,         mktVPtr->netAmt);
	   SET_AMOUNT(extValo, PosVal_PosAccrInterAmt, mktVPtr->accrInterRefCurr);

	   /* REF7419 - YST - 020313 - if standard swap : market value = net value */
	   instrNatEn = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);
	   instrSubNatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);

	   /* PMSTA-48782 - ankita - 16052022 */
	   AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
	   GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

	   tmpExch = 1;

	   /* ------------------------------ */
	   /*** REFERENCE CURRENCY AMOUNTS ***/
	   /* ------------------------------ */
	   /* BUG200 - Convert position currency amounts to reference currency */
		if (refCurrId != posCurrId)
		{
			/* REF1747 - Call new function wich verify EURO */	/* REF2313 */
			exchArgSt.srcAmt = GET_AMOUNT(extValo, PosVal_PosNetAmt);
			FIN_ExchAmtEuro(fromDateTime, refCurrId, posCurrId, refCurrId,
				0, NULLDYNST, &exchArgSt, pPtr, NULL, &tmpVal, &tmpExch);
			SET_AMOUNT(extValo, PosVal_RefNetAmt, tmpVal);

			SET_EXCHANGE(extValo, PosVal_PosExchRate, tmpExch);	/* BUG200 - posExchRate */

			exchArgSt.srcAmt = GET_AMOUNT(extValo, PosVal_PosAccrInterAmt);
			FIN_ExchAmtEuro(fromDateTime, refCurrId, posCurrId, refCurrId,
				0, NULLDYNST, &exchArgSt,
				pPtr, NULL, &tmpVal, (EXCHANGE_T*)NULL);
			SET_AMOUNT(extValo, PosVal_RefAccrInterAmt, tmpVal);			

			if ((InstrNat_Swap == instrNatEn &&
				(SubNat_FixFloatStdSwap == instrSubNatEn || SubNat_FixFltSwapHedgFix == instrSubNatEn || /* REF7782 - YST - 020904 */
					SubNat_FixFixStdSwap == instrSubNatEn || SubNat_FltFltStdSwap == instrSubNatEn)) ||
					(InstrNat_Bond == instrNatEn &&
				(SubNat_RecSwapFixedLeg == instrSubNatEn || SubNat_RecSwapFloatLeg == instrSubNatEn ||
					SubNat_PaidSwapFixedLeg == instrSubNatEn || SubNat_PaidSwapFloatLeg == instrSubNatEn)))
			{
				SET_AMOUNT(extValo, PosVal_RefMktValAmt, GET_AMOUNT(extValo, PosVal_RefNetAmt));
			}
			/* else mktValAmt = netAmt + accrInterAmt */
			else if (InstrNat_Debt == instrNatEn) /* REF11679 - TGU - 060217 */
			{
				mktValAmt = (GET_AMOUNT(extValo, PosVal_PosNetAmt) * tmpExch) + GET_AMOUNT(extValo, PosVal_RefAccrInterAmt);
				SET_AMOUNT(extValo, PosVal_RefMktValAmt, mktValAmt);
			}
			else
			{
				mktValAmt = GET_AMOUNT(extValo, PosVal_RefNetAmt) + GET_AMOUNT(extValo, PosVal_RefAccrInterAmt);
				SET_AMOUNT(extValo, PosVal_RefMktValAmt, mktValAmt);
			}
		}		
	   else
	   {
		SET_AMOUNT(extValo, PosVal_RefNetAmt,
		    GET_AMOUNT(extValo, PosVal_PosNetAmt));

		SET_AMOUNT(extValo, PosVal_RefAccrInterAmt,
	            GET_AMOUNT(extValo, PosVal_PosAccrInterAmt));

		SET_AMOUNT(extValo, PosVal_RefMktValAmt,
		    GET_AMOUNT(extValo, PosVal_PosMktValAmt));

		SET_EXCHANGE(extValo, PosVal_PosExchRate, 1.0);		/* BUG200 - posExchRate */
	   }

	   /* ------------------------------- */
	   /*** INSTRUMENT CURRENCY AMOUNTS ***/
	   /* ------------------------------- */
	   /* BUG200 - Convert position currency amounts to instrument currency */
	   if (instrCurrId != posCurrId)
   	   {
		/* REF2313 */
		exchArgSt.srcAmt = GET_AMOUNT(extValo, PosVal_PosNetAmt);
		FIN_ExchAmt(fromDateTime, posCurrId, instrCurrId,
			    0, NULLDYNST, pPtr, &exchArgSt,
			    (EXCHANGE_T*)NULL, &tmpVal, &tmpExch);	/* REF2817 */ /* REF3561 - SSO - 990415 */	/* PMSTA01649 - TGU - 070405 */
		SET_AMOUNT(extValo, PosVal_InstrNetAmt, tmpVal);

		/* REF2817 - InstrExchRate is rate between instrument and reference currency */
		/* SET_EXCHANGE(extValo, PosVal_InstrExchRate, tmpExch); */	/* REF2610 */

		/* REF3561 - SSO - 990415
		*	if (instrCurrId != refCurrId)
		*	{
		*	    exchArgSt.srcAmt = GET_AMOUNT(extValo, PosVal_InstrNetAmt);
		*	    FIN_ExchAmt(fromDateTime, instrCurrId, refCurrId,
		*			0, NULLDYNST, &exchArgSt,
		*			(EXCHANGE_T*)NULL, &tmpVal, &tmpExch);
		*	}
		*/
		GEN_GetApplInfo(ApplEuroCurrId, &euroCurrId);
		if ( (CMP_EXCHANGE(tmpExch, 0.0) != 0) &&
		     ((instrCurrId != refCurrId)
		      || ((instrCurrId == refCurrId) && (instrCurrId == euroCurrId))) )
		{
		    tmpExch = CAST_EXCHANGE(GET_EXCHANGE(extValo, PosVal_PosExchRate) / tmpExch);
		}
		else
		    tmpExch = 1.0;

		SET_EXCHANGE(extValo, PosVal_InstrExchRate, tmpExch);

		exchArgSt.srcAmt = GET_AMOUNT(extValo, PosVal_PosAccrInterAmt);
		FIN_ExchAmt(fromDateTime, posCurrId, instrCurrId,
			    0, NULLDYNST, pPtr, &exchArgSt,
			    (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
		SET_AMOUNT(extValo, PosVal_InstrAccrInterAmt, tmpVal);

		/* mktValAmt = netAmt + accrInterAmt */
		mktValAmt = GET_AMOUNT(extValo, PosVal_InstrNetAmt) +
			    GET_AMOUNT(extValo, PosVal_InstrAccrInterAmt);
		SET_AMOUNT(extValo, PosVal_InstrMktValAmt, mktValAmt);
	   }
	   else
	   {
		SET_AMOUNT(extValo, PosVal_InstrNetAmt,
		    GET_AMOUNT(extValo, PosVal_PosNetAmt));

		SET_AMOUNT(extValo, PosVal_InstrAccrInterAmt,
		    GET_AMOUNT(extValo, PosVal_PosAccrInterAmt));

		SET_AMOUNT(extValo, PosVal_InstrMktValAmt,
		    GET_AMOUNT(extValo, PosVal_PosMktValAmt));

		SET_EXCHANGE(extValo, PosVal_InstrExchRate,
		    GET_EXCHANGE(extValo, PosVal_PosExchRate));	/* REF2610 */
	   }

	   /* REF2610 - Modify price exchange rate if possible */
	   if (GET_ID(extValo, PosVal_PriceCurrId) == posCurrId)
	   {
		SET_EXCHANGE(extValo, PosVal_PriceExchRate,
		    GET_EXCHANGE(extValo, PosVal_PosExchRate));
	   }
	   else if (GET_ID(extValo, PosVal_PriceCurrId) == instrCurrId)
	   {
		SET_EXCHANGE(extValo, PosVal_PriceExchRate,
		    GET_EXCHANGE(extValo, PosVal_InstrExchRate));
	   }

	   tmpExch = 1;

	   /* WEALTH-4688 - DDV - 240229 - Do it only when incEvtCurrId is define */
	   if (incEvtCurrId != 0 && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock)
	   {
		   SET_AMOUNT(extValo, PosVal_AccrInter, mktVPtr->accrInter);	   
		   
		   if (incEvtCurrId != instrCurrId)
		   {
			   exchArgSt.srcAmt = mktVPtr->accrInter;
			   FIN_ExchAmt(fromDateTime, incEvtCurrId, instrCurrId, 0, NULLDYNST, pPtr, &exchArgSt,
				   (EXCHANGE_T*)NULL, &tmpVal, &tmpExch);
		   }
		   SET_AMOUNT(extValo, PosVal_InstrAccrInterAmt, mktVPtr->accrInter*tmpExch);
		   tmpExch = 1;

		   if (posCurrId != incEvtCurrId)
		   {
			   exchArgSt.srcAmt = mktVPtr->accrInter;
			   FIN_ExchAmt(fromDateTime, incEvtCurrId, posCurrId, 0, NULLDYNST, pPtr, &exchArgSt,
				   (EXCHANGE_T*)NULL, &tmpVal, &tmpExch);
		   }
		   SET_AMOUNT(extValo, PosVal_PosAccrInterAmt, mktVPtr->accrInter*tmpExch);
		   tmpExch = 1;

		   if (refCurrId != incEvtCurrId)
		   {
			   exchArgSt.srcAmt = mktVPtr->accrInter;
			   FIN_ExchAmt(fromDateTime, incEvtCurrId, refCurrId, 0, NULLDYNST, pPtr, &exchArgSt,
				   (EXCHANGE_T*)NULL, &tmpVal, &tmpExch);
		   }

		   SET_AMOUNT(extValo, PosVal_RefAccrInterAmt, mktVPtr->accrInter*tmpExch);
		   mktValAmt = GET_AMOUNT(extValo, PosVal_RefNetAmt) + GET_AMOUNT(extValo, PosVal_RefAccrInterAmt);
		   SET_AMOUNT(extValo, PosVal_RefMktValAmt, mktValAmt);

		   /* mktValAmt = netAmt + accrInterAmt */
		   mktValAmt = GET_AMOUNT(extValo, PosVal_InstrNetAmt) + GET_AMOUNT(extValo, PosVal_InstrAccrInterAmt);
		   SET_AMOUNT(extValo, PosVal_InstrMktValAmt, mktValAmt);
	   }


       /* REF7419 - YST - 020313 */
       if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}

       return(TRUE);
	}
	else
	   return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_SetPriceToPos()
**
**  Description :   Set instrument price fields in position structure.
**                  CurrId, TpId, ThirdId, QuoteDate, TermTpId, Quote,
**                  Price, PriceCalcEn.
**
**  Arguments   :   fromDateTime   from date
**                  refCurrId      reference currency
**                  pPtr           position pointer
**                  prPtr          price pointer
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Modif.	 :  REF2313 - RAK - 980910
**  Modif.	:   REF2580 - SSO - 980727
**  Modif.  :   REF7925 - TEB - 050419
**  Modif.  :   REF7925 - TEB - 060712
**
*************************************************************************/
FLAG_T FIN_SetPriceToPos(DATETIME_T         fromDateTime,
                         ID_T               refCurrId,
		                 DBA_DYNFLD_STP     pPtr,
		                 DBA_DYNFLD_STP     prPtr,
				         DBA_HIER_HEAD_STP  posHierHead) /* REF2580 - SSO - 980727 */
{
	DBA_DYNFLD_STP extValo=NULLDYNST;
	EXCHANGE_T     exch;
	FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

        if (GET_EXTENSION_PTR(pPtr, ExtPos_PosVal_Ext) != NULL &&
            (extValo = *(GET_EXTENSION_PTR(pPtr, ExtPos_PosVal_Ext))) != NULLDYNST)
	{
        if (IS_NULLFLD(prPtr, A_InstrPrice_CurrId))
        {
            SET_NULL_ID(extValo, PosVal_PriceCurrId);
        }
	    else
        {
            DBA_DYNFLD_STP       instrPtr;

            /* PMSTA-52092 - DDV - 230208 - Fix wrong rounding, instr_price.currency_id is used to have prices on both legs.
                                            Bug both prices are on instrument currency */
            if (GET_EXTENSION_PTR(pPtr, ExtPos_A_Instr_Ext) != NULL &&
                (instrPtr = *GET_EXTENSION_PTR(pPtr, ExtPos_A_Instr_Ext)) != NULLDYNST &&
                GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
            {
                SET_ID(extValo, PosVal_PriceCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
            }
            else
            {
                SET_ID(extValo, PosVal_PriceCurrId, GET_ID(prPtr, A_InstrPrice_CurrId));
            }
        }

	   if (IS_NULLFLD(prPtr, A_InstrPrice_TpId))
	   { SET_NULL_ID(extValo, PosVal_PriceTpId); }
	   else
	   { SET_ID(extValo, PosVal_PriceTpId, GET_ID(prPtr, A_InstrPrice_TpId)); }

	   if (IS_NULLFLD(prPtr, A_InstrPrice_ThirdId))
	   { SET_NULL_ID(extValo, PosVal_PriceThirdId); }
	   else
	   { SET_ID(extValo, PosVal_PriceThirdId, GET_ID(prPtr, A_InstrPrice_ThirdId)); }

	   if (IS_NULLFLD(prPtr, A_InstrPrice_TermTpId))
	   { SET_NULL_ID(extValo, PosVal_TermTpId); }
	   else
	   { SET_ID(extValo, PosVal_TermTpId, GET_ID(prPtr, A_InstrPrice_TermTpId)); }

	   SET_DATETIME(extValo, PosVal_QuoteDate, GET_DATETIME(prPtr, A_InstrPrice_QuoteDate));

	   /* REF7925 - TEB - 050419 */
	   /* Only set Price and Quote if price is not null */
	   /*
	   if (IS_NULLFLD(prPtr, A_InstrPrice_Price) == FALSE)
	   {
		   SET_PRICE(extValo, PosVal_Quote,       GET_PRICE(prPtr, A_InstrPrice_Quote));
		   SET_PRICE(extValo, PosVal_Price,       GET_PRICE(prPtr, A_InstrPrice_Price));
	   }
	   */
	   /* REF7925 - TEB - 060712 */
	   COPY_DYNFLD(extValo, PosVal, PosVal_Quote, prPtr, A_InstrPrice, A_InstrPrice_Quote);
	   COPY_DYNFLD(extValo, PosVal, PosVal_Price, prPtr, A_InstrPrice, A_InstrPrice_Price);


	   SET_NUMBER(extValo, PosVal_ActuRate,    GET_NUMBER(prPtr, A_InstrPrice_ActuRate));

	   SET_ENUM(extValo, PosVal_PriceCalcRuleEn,
	       GET_ENUM(prPtr, A_InstrPrice_PriceCalcRuleEn));

	   if (IS_NULLFLD(prPtr, A_InstrPrice_FwdSpotPrice) == FALSE)
	   {
		SET_PRICE(extValo, PosVal_SpotPrice,
		    GET_PRICE(prPtr, A_InstrPrice_FwdSpotPrice));

		/* to modify with call PriceToQuote ?? */
		SET_PRICE(extValo, PosVal_SpotQuote,
		    GET_PRICE(prPtr, A_InstrPrice_FwdSpotPrice));
	   }

	   /**** STORE REFERENCE DATE EXCHANGE RATES ****/
	   FIN_GetExchRate(fromDateTime, GET_ID(extValo, PosVal_PriceCurrId), refCurrId,
			   (ID_T)0, NULLDYNST, pPtr, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	   SET_EXCHANGE(extValo, PosVal_PriceExchRate, exch);

       /* REF5416 - RAK - 010215 */
       if (IS_NULLFLD(prPtr, A_InstrPrice_DiscFac) == FALSE)
       {
           SET_NUMBER(extValo, PosVal_DiscFac,
                GET_NUMBER(prPtr, A_InstrPrice_DiscFac));
       }

	   return(TRUE);
	}
	else
	   return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_UpdPosRefAmt()
**
**  Description :   Ensure that reference currency gross and net amounts
**                  (initialised to portfolio currency) are in the
**                  received reference currency.
**                  Modify it using instrument, position or system currency
**                  and amounts if possible or get exchange rate.
**
**  Arguments   :   posTab    position array pointer
**                  posNbr    position number
**                  refCurrId reference currency identifier
**		            dictFctEn function enum
**                  domainSt  the domain. Can be NULL
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   BUG038 - RAK - 960613
**                  BUG090 - RAK - 960808
**                  BUG119 - RAK - 960930
**                  DVP468 - XDI - 970516
**  Modif.	:   REF2313 - RAK - 980910
**  Modif.	:   REF2472 - RAK - 980702
**  Modif.	:   REF2580 - SSO - 980727
**  Modif.	:   REF2610 - RAK - 980811
**  Modif.	:   REF2919 - RAK - 990113
**		    REF4053 - SSO - 991207: fixing of 2919 for euro
**		    REF2779 - SSO - 000203: copy of price to quote for BP
**
*************************************************************************/
RET_CODE FIN_UpdPosRefAmt(DBA_DYNFLD_STP    *posTab,
			              int               posNbr,
			              ID_T              refCurrId,
			              DICT_FCT_ENUM     dictFctEn,
			              DBA_HIER_HEAD_STP posHierHead, /* REF2580 - SSO - 980727 */
						  DBA_DYNFLD_STP    domainSt )   /* REF6220 - LJE - 020305 */
{
	DATETIME_T         exchDate;
	ID_T               sysCurrId;
	AMOUNT_T           amt;
	EXCHANGE_T         exch;
	char               refCurrOk;
	int                i, ptfNbr;
	DBA_DYNFLD_STP	   ptfPtr = NULLDYNST, * hierPtf = NULL;
	DBA_DYNFLD_STP 	   sPtfPosSet=NULLDYNST, ptfPosSetPtr=NULLDYNST;
	DBA_DYNFLD_STP 	   instrPtr=NULLDYNST;	/* REF2779 - SSO - 000203 */
	FUSDATERULE_ENUM   fusDateRuleEn;
	RET_CODE	       ret;
    FIN_EXCHARG_ST     exchArgSt;			/* REF2313 */
	ID_T		       euroCurrId;		/* REF2919 */
	DATE_T		       euroDate;
	FLAG_T		       noCopyForEuro, isHierPtf = FALSE, allocFlg = FALSE; /* REF4053 - SSO - 991207 */
	PRICE_T	       quote, price; /* REF2779 - SSO - 000203 */
	PRICECALCRULE_ENUM priceCalcRuleEn; /* REF2779 - SSO - 000427 */ /* REF7264 - LJE - 020124 */
    ID_T               capPBalPosTypeId;   /* REF5352 - DED - 001031 */
    ID_T               curPBalPosTypeId;   /* REF5352 - DED - 001031 */
    ID_T               capLBalPosTypeId;   /* REF5352 - DED - 001031 */
    ID_T               curLBalPosTypeId;   /* REF5352 - DED - 001031 */
    FLAG_T             isRealisedPlFLg=FALSE; /* REF5352 - DED - 001031 */
    ID_T               saveRefCurrId=refCurrId; /* REF6220 - LJE - 020808 */
	OBJECT_ENUM        dimPtfEn = NullEntity;

	/* WEALTH-10005 - Deepthi - 20240627 */
	if (domainSt != nullptr && IS_NULLFLD(domainSt, A_Domain_DimPtfDictId) == FALSE)
		DBA_GetObjectEnum(GET_DICT(domainSt, A_Domain_DimPtfDictId), &dimPtfEn);

    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */

	/* REF8969 - CHU - 030409
	 ********************************************************************
	 * Moved on top : Code must be executed before exiting the function *
	 ********************************************************************
	 */
	/* BUG119 - RAK - 960930 */
	if (dictFctEn == DictFct_Valo ||
	dictFctEn == DictFct_FundValo ||
	dictFctEn == DictFct_CheckStratValo ||
	dictFctEn == DictFct_ForexHedging
	/* || PMSTA-11053 - RAK - 101206 - grave erreur !?!?
	dictFctEn == DictFct_Return*/)	/* PMSTA-9378 - RAK - 100311 */
	{
		for (i=0; i<posNbr; i++)
		{
			SET_ENUM(posTab[i], ExtPos_PrimaryEn, PosPrimary_Primary);
		}
	}

	/* REF6220 - LJE - 020305 */
	if (domainSt != nullptr &&
		GET_FLAG(domainSt, A_Domain_DefCurrFlg) == TRUE &&
        GET_ENUM(domainSt, A_Domain_PpsLoadEn)  == Domain_PpsLoadEn_NoPps &&
		GET_ENUM(domainSt, A_Domain_LoadHierFlg) == LoadHierPtf_None)  /* WEALTH-10005 - Deepthi - 20240627 */
	{
		return RET_SUCCEED;
	}

	if (domainSt != nullptr &&
		GET_FLAG(domainSt, A_Domain_DefCurrFlg) == FALSE &&
        GET_ENUM(domainSt, A_Domain_PpsLoadEn)  == Domain_PpsLoadEn_LoadPps )
	{
		return RET_SUCCEED;
	}


	/* REF2580 - SSO - 980727 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	/* REF2919 - Update euroCurrId to EURO currency if we are after euro date */
	GEN_GetApplInfo(ApplEuroCurrId,&euroCurrId);
	if (DBA_GetEuroConversionDate(&euroDate, DBA_GetConnectNoFromExchArg(&exchArgSt)) == FALSE)
		euroCurrId = 0;

    /* REF5352 - DED - 001031 */
    GEN_GetApplInfo(ApplCapPBpTypeId, &capPBalPosTypeId);
    GEN_GetApplInfo(ApplCapLBpTypeId, &capLBalPosTypeId);
    GEN_GetApplInfo(ApplCurPBpTypeId, &curPBalPosTypeId);
    GEN_GetApplInfo(ApplCurLBpTypeId, &curLBalPosTypeId);

    /* PMSTA04136 - BSA - 071023 : Code Reporting of PMSTA04141 in 4.30.2 */
    /* PMSTA04141 - DDV - 071003 - sort positions to treat account at the end */
    TLS_Sort2((char *) posTab, posNbr, sizeof(DBA_DYNFLD_STP),
	FIN_CmpExtPosAcct, (PTR **) NULL, SortRtnTp_None, (PTR *) &refCurrId);

	/* WEALTH-10005 - Deepthi - 20240627 */
	if (dimPtfEn == Ptf &&
		domainSt != nullptr && GET_FLAG(domainSt, A_Domain_DefCurrFlg) == TRUE &&
		(PTFCONSRULE_ENUM)GET_ENUM(domainSt, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedHierarchical &&
		((GET_ENUM(domainSt, A_Domain_LoadHierFlg) == LoadHierPtf_FromParent &&
			DBA_GetPtfById(GET_ID(domainSt, A_Domain_PtfObjId), FALSE,
				&allocFlg, &ptfPtr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED &&
			ptfPtr != NULLDYNST && IS_NULLFLD(ptfPtr, A_Ptf_CurrId) == FALSE) ||
		(GET_ENUM(domainSt, A_Domain_LoadHierFlg) == LoadHierPtf_Full &&
			(DBA_ExtractHierEltRec(posHierHead, A_Ptf, FALSE, FIN_FilterTopHierPtf, NULLFCT,
				&ptfNbr, &hierPtf)) == RET_SUCCEED &&
			hierPtf != NULL &&
			IS_NULLFLD(*hierPtf, A_Ptf_CurrId) == FALSE))
		)
	{
		isHierPtf = TRUE;
		saveRefCurrId = (hierPtf != NULL) ? GET_ID(*hierPtf, A_Ptf_CurrId) : GET_ID(ptfPtr, A_Ptf_CurrId);
	}

	for (i=0; i<posNbr; i++)
	{
		/* REF6220 - LJE - 020808 : Get the ptf currency if PPS and default currency */ /* WEALTH-10005 - Deepthi - 20240627 */
		if (isHierPtf == FALSE &&
			domainSt != nullptr && GET_FLAG(domainSt, A_Domain_DefCurrFlg) == TRUE         &&
            GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL  &&
			(ptfPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext))) != NULLDYNST
			)
		{
			if (dimPtfEn == List &&
				(PTFCONSRULE_ENUM)GET_ENUM(domainSt, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedHierarchical)
			{
				while (GET_ID(ptfPtr, A_Ptf_HierPortId) != NULL
					&& GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext) != NULL &&
					(ptfPtr = *(GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext))) != NULLDYNST)
				{
					/*Do Nothing */
				}
			}
			refCurrId = (IS_NULLFLD(ptfPtr, A_Ptf_CurrId) == FALSE) ? GET_ID(ptfPtr, A_Ptf_CurrId) : saveRefCurrId;
        }
        else
        {
            refCurrId = saveRefCurrId;
        }

        if (refCurrId != GET_ID(posTab[i], ExtPos_RefCurrId))
        {
            refCurrOk = FALSE;

            /* REF5352 - DED - 001031 */
            isRealisedPlFLg=FALSE;
            if (IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == FALSE &&
                (GET_ID(posTab[i], ExtPos_BalPosTpId) == curLBalPosTypeId ||
                 GET_ID(posTab[i], ExtPos_BalPosTpId) == curPBalPosTypeId ||
                 GET_ID(posTab[i], ExtPos_BalPosTpId) == capLBalPosTypeId ||
                 GET_ID(posTab[i], ExtPos_BalPosTpId) == capPBalPosTypeId))
            {
                isRealisedPlFLg=TRUE;
            }

			/* REF4053 - SSO - 991207 call moved here because exchDate needed for euro */
			if ((ret = FIN_PosGetDateRuleExchDate(posTab[i],
								  &sPtfPosSet, &ptfPosSetPtr,
								  &fusDateRuleEn,
								  &exchDate)) != RET_SUCCEED)
				return(ret);
			noCopyForEuro = (FLAG_T)((refCurrId == euroCurrId) && (exchDate.date < euroDate)); /* REF4053 - SSO - 991207 */
			/* NB: if noCopyForEuro equals TRUE, we must prevent copying (if FALSE, okaayyyyee */

			/*** If possible, use instrument amounts ***/
			if (refCurrId == GET_ID(posTab[i], ExtPos_InstrCurrId) &&
				(GET_ID(posTab[i], ExtPos_InstrCurrId) != euroCurrId	/* REF2919 */
				 || noCopyForEuro == FALSE))  				/* REF4053 - SSO - 991207 */
			{
				refCurrOk = TRUE;
				SET_AMOUNT(posTab[i], ExtPos_RefGrossAmt,
						   GET_AMOUNT(posTab[i], ExtPos_InstrGrossAmt));
				SET_AMOUNT(posTab[i], ExtPos_RefNetAmt,
					GET_AMOUNT(posTab[i], ExtPos_InstrNetAmt));
				SET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt, 			/* DVP468 - XDI - 970620 */
					GET_AMOUNT(posTab[i], ExtPos_BookInstrNetAmt)); 	/* REF4219 - 000228 - DED */
			}

			/*** If possible, use position amounts ***/
			if (refCurrOk == FALSE &&
				isRealisedPlFLg == FALSE &&                             /* REF5352 - DED - 001031 */
				refCurrId == GET_ID(posTab[i],ExtPos_PosCurrId) &&
				(GET_ID(posTab[i],ExtPos_PosCurrId) != euroCurrId 		/* REF2919 */
				 || noCopyForEuro == FALSE))			        /* REF4053 - SSO - 991207 */
			{
				refCurrOk = TRUE;
				SET_AMOUNT(posTab[i], ExtPos_RefGrossAmt,
						   GET_AMOUNT(posTab[i], ExtPos_PosGrossAmt));
				SET_AMOUNT(posTab[i], ExtPos_RefNetAmt,
						   GET_AMOUNT(posTab[i], ExtPos_PosNetAmt));
				SET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt,       		/* DVP468 - XDI - 970620 */
						   GET_AMOUNT(posTab[i], ExtPos_BookPosNetAmt));/* REF4219 - 000228 - DED */
			}

			/*** If possible, use system amounts ***/

			/* REF2472 - If portfolio system currency is already modified, */
			/* but parameter system currency isn't modified.               */
			if (GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL &&
					((ptfPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext)))!= NULLDYNST &&
				 IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE))
				sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
			else
				GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);

            /* PMSTA04136 - BSA - 071023 : Code Reporting of PMSTA04141 in 4.30.2 */
            /* PMSTA04141 - DDV - 071002 - Try to use account currency to convert reference amount */
		    /* Portfolio currency is now account currency */
            /*PMSTA-32606 - NRAO - 300818 Refactorize repeated calls to update ref amounts */
            if (refCurrOk == FALSE)
            {
                FIN_UpdPosRefAmounts(posTab[i], posTab[i], refCurrId, euroCurrId, noCopyForEuro, &refCurrOk);

                DBA_DYNFLD_STP mainPos;

				if (refCurrOk == FALSE)
			    {
                    if (refCurrId == sysCurrId)	/* REF4053 - SSO - 991207: suppressed  REF2919 && sysCurrId != euroCurrId */
                    {
                        refCurrOk = TRUE;
                        SET_AMOUNT(posTab[i], ExtPos_RefGrossAmt,
                            GET_AMOUNT(posTab[i], ExtPos_SysGrossAmt));

                        SET_AMOUNT(posTab[i], ExtPos_RefNetAmt,
                            GET_AMOUNT(posTab[i], ExtPos_SysNetAmt));
                        SET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt,       	/* DVP468 - XDI - 970620 */
                            GET_AMOUNT(posTab[i], ExtPos_BookSysNetAmt));	/* REF4219 - 000228 - DED */
                    }
                }

                /*Search main position ccy to convert ref amounts*/
                if (refCurrOk == FALSE &&
                    GET_EXTENSION_PTR(posTab[i], ExtPos_Main_ExtPos_Ext) != NULL &&
                    (mainPos = *(GET_EXTENSION_PTR(posTab[i], ExtPos_Main_ExtPos_Ext))) != NULLDYNST)
                {
                    if (refCurrId == GET_ID(mainPos, ExtPos_InstrCurrId) &&
                        (CMP_DYNFLD(posTab[i], mainPos,
                        ExtPos_RefCurrId, ExtPos_RefCurrId, IdType) == 0) &&
                        GET_EXCHANGE(mainPos, ExtPos_InstrExchRate) != ZERO_EXCHANGE &&
                        (CMP_ID(GET_ID(mainPos, ExtPos_InstrCurrId), euroCurrId) != 0
                        || noCopyForEuro == FALSE))
                    {
                        refCurrOk = TRUE;

                        SET_AMOUNT(posTab[i], ExtPos_RefGrossAmt,
                            CAST_AMOUNT(GET_AMOUNT(posTab[i], ExtPos_RefGrossAmt) /
                            GET_EXCHANGE(mainPos, ExtPos_InstrExchRate),
                            refCurrId));
                        SET_AMOUNT(posTab[i], ExtPos_RefNetAmt,
                            CAST_AMOUNT(GET_AMOUNT(posTab[i], ExtPos_RefNetAmt) /
                            GET_EXCHANGE(mainPos, ExtPos_InstrExchRate),
                            refCurrId));
                        SET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt,
                            CAST_AMOUNT(GET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt) /
                            GET_EXCHANGE(mainPos, ExtPos_InstrExchRate),
                            refCurrId));

                    }

                    /*Search main position's acct, acct2, acct3 ccy to convert ref amounts*/
                    if (refCurrOk == FALSE)
                    {
                        FIN_UpdPosRefAmounts(posTab[i], mainPos, refCurrId, euroCurrId, noCopyForEuro, &refCurrOk);
                    }

                }
            }

			/* If necessary, convert system amounts in */
			/* reference currency                      */
			if (refCurrOk == FALSE)
			{
					/* REF2610 - Search exch. date */
					/* BUG038 - RAK - 960613 */
					/* exchDate = GET_DATETIME(posTab[i], ExtPos_BegDate); */
				/*  REF4053 - SSO - 991207 moved upper ...
				*   if ((ret = FIN_PosGetDateRuleExchDate(posTab[i],
				*					  &sPtfPosSet, &ptfPosSetPtr,
				*					  &fusDateRuleEn,
				*					  &exchDate)) != RET_SUCCEED)
				*	return(ret);
				*/

				/* REF2313 */
				exchArgSt.srcAmt = GET_AMOUNT(posTab[i], ExtPos_RefGrossAmt);
				FIN_ExchAmtEuro(exchDate, GET_ID(posTab[i], ExtPos_RefCurrId),
						GET_ID(posTab[i], ExtPos_RefCurrId),
							refCurrId, 0, NULLDYNST, &exchArgSt, posTab[i],
										(EXCHANGE_T*)NULL, &amt, (EXCHANGE_T*)NULL);
				SET_AMOUNT(posTab[i], ExtPos_RefGrossAmt, amt);

	 			exchArgSt.srcAmt = GET_AMOUNT(posTab[i], ExtPos_RefNetAmt);
				FIN_ExchAmtEuro(exchDate, GET_ID(posTab[i], ExtPos_RefCurrId),
						GET_ID(posTab[i], ExtPos_RefCurrId),
						refCurrId, 0, NULLDYNST, &exchArgSt, posTab[i],
								(EXCHANGE_T*)NULL, &amt, (EXCHANGE_T*)NULL);
				SET_AMOUNT(posTab[i], ExtPos_RefNetAmt, amt);

				/* DVP468 - XDI - 970620 */
				exchArgSt.srcAmt = GET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt);
				FIN_ExchAmtEuro(exchDate, GET_ID(posTab[i], ExtPos_RefCurrId),
						GET_ID(posTab[i], ExtPos_RefCurrId),
						refCurrId, 0, NULLDYNST, &exchArgSt, posTab[i],
							(EXCHANGE_T*)NULL, &amt, (EXCHANGE_T*)NULL);
				SET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt, amt);      /* DVP468 - XDI - 970620 */
			}

            /*PMSTA-33155 - NRAO -181002 -Exch rate updates moved to a seperate loop below*/

	    }

        /* REF2779 - SSO - 000203 */
	    if ( (dictFctEn == DictFct_OpHist || dictFctEn ==  DictFct_OpList)
		&& (IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == FALSE
			&& IS_NULLFLD(posTab[i], ExtPos_Quote) == TRUE
			&& IS_NULLFLD(posTab[i], ExtPos_Price) == FALSE) )
	    {
			/* fill the quote */
			/* REF2779 - SSO - 000418: use ExtPos_PriceCalcRuleEn  instead of A_Instr_PriceCalcRuleEn */

			if (GET_EXTENSION_PTR(posTab[i], ExtPos_A_Instr_Ext) != NULL &&
				(instrPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Instr_Ext))) != NULLDYNST)
			{
				/* REF2779 - SSO - 000418: use ExtPos_PriceCalcRuleEn  instead of A_Instr_PriceCalcRuleEn */
				/* REF2779 - SSO - 000427: if primary, use A_Instr_PriceCalcRuleEn */
				priceCalcRuleEn = (PRICECALCRULE_ENUM)GET_ENUM(posTab[i], ExtPos_PriceCalcRuleEn); /* REF7264 - LJE - 020124 */
				if (priceCalcRuleEn == PriceCalcRule_None && GET_ENUM(posTab[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
				{
				priceCalcRuleEn = (PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn); /* REF7264 - LJE - 020124 */
				}
				price = GET_PRICE(posTab[i], ExtPos_Price);
				if (CMP_PRICE(price, 0.0) < 0) /* REF2779 - SSO - 000427 */
				{
				price = -1.0 * price;
				}

				if (FIN_PriceToQuote(priceCalcRuleEn,
						 GET_ID(instrPtr, A_Instr_Id), instrPtr,
						 GET_DATETIME(posTab[i], ExtPos_BegDate), NULL,
						 price, &quote,
						 posHierHead) == RET_SUCCEED)
				{
				if (CMP_PRICE(price, 0.0) < 0)	/* REF2779 - SSO - 000427 */
				{
					quote = -1.0 * quote;
				}
				SET_PRICE(posTab[i], ExtPos_Quote, quote);
				}
			}
	    }
	}

    /*PMSTA-33155 - NRAO -181002 -A new loop to update the exch rates*/
    for (i = 0; i < posNbr; i++)
    {
		/* REF6220 - LJE - 020808 : Get the ptf currency if PPS and default currency */ /* WEALTH-10005 - Deepthi - 20240627 */
		if (isHierPtf == FALSE &&
            domainSt != nullptr && GET_FLAG(domainSt, A_Domain_DefCurrFlg) == TRUE         &&
            GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL &&
			(ptfPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext))) != NULLDYNST
			)
		{
			if (dimPtfEn == List &&
				(PTFCONSRULE_ENUM)GET_ENUM(domainSt, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedHierarchical)
			{
				while (GET_ID(ptfPtr, A_Ptf_HierPortId) != NULL
					&& GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext) != NULL &&
					(ptfPtr = *(GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierPtf_Ext))) != NULLDYNST)
				{
					/*Do Nothing */
				}
			}
			refCurrId = (IS_NULLFLD(ptfPtr, A_Ptf_CurrId) == FALSE) ? GET_ID(ptfPtr, A_Ptf_CurrId) : saveRefCurrId;
        }
        else
        {
            refCurrId = saveRefCurrId;
        }
		/* WEALTH-5194 - Deepthi - 20240715 - 
		Populating ptfPtr in case its not assigned above */
		if (ptfPtr == nullptr && GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL)
		{
			ptfPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext));
		}
		if (domainSt != nullptr && (PLMETHOD_ENUM)GET_ENUM(domainSt, A_Domain_PLMethodEn) == PLMethod_ReprocessPL && ptfPtr != NULLDYNST && GET_ID(ptfPtr, A_Ptf_CurrId) != GET_ID(domainSt, A_Domain_CurrId))
		{
			refCurrId = GET_ID(domainSt, A_Domain_CurrId);
		}

        if (refCurrId != GET_ID(posTab[i], ExtPos_RefCurrId))
        {
            isRealisedPlFLg = FALSE;
            if (IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == FALSE &&
                (GET_ID(posTab[i], ExtPos_BalPosTpId) == curLBalPosTypeId ||
                GET_ID(posTab[i], ExtPos_BalPosTpId) == curPBalPosTypeId ||
                GET_ID(posTab[i], ExtPos_BalPosTpId) == capLBalPosTypeId ||
                GET_ID(posTab[i], ExtPos_BalPosTpId) == capPBalPosTypeId))
            {
                isRealisedPlFLg = TRUE;
            }

            /* REF2472 - If portfolio system currency is already modified, */
            /* but parameter system currency isn't modified.               */
            if (GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext) != NULL &&
                ((ptfPtr = *(GET_EXTENSION_PTR(posTab[i], ExtPos_A_Ptf_Ext))) != NULLDYNST &&
                IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE))
                sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
            else
                GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);

            SET_ID(posTab[i], ExtPos_RefCurrId, refCurrId);

            /*** Store instrument historical exchange rate ***/
            /* --------------------- */
            /* BUG090 - RAK - 960808 */
            /* if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_RefNetAmt), refCurrId) != 0) */
            if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_InstrNetAmt),
                GET_ID(posTab[i], ExtPos_InstrCurrId)) != 0)
            {
                exch = GET_AMOUNT(posTab[i], ExtPos_RefNetAmt) /
                    GET_AMOUNT(posTab[i], ExtPos_InstrNetAmt);
                SET_EXCHANGE(posTab[i], ExtPos_InstrExchRate, exch);
            }
            else
                SET_EXCHANGE(posTab[i], ExtPos_InstrExchRate, 0.0);

            /*** Store position historical exchange rate ***/
            /* --------------------- */
            /* BUG090 - RAK - 960808 */
            /* if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_RefNetAmt), refCurrId) != 0) */
            if (isRealisedPlFLg == FALSE)							  /* REF5352 - DED - 001031 */
            {
                /* Recompute pos_exchange_rate for all records except realised P&L (is filled with info from Buy) */
                if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_PosNetAmt), GET_ID(posTab[i], ExtPos_PosCurrId)) != 0)
                {
                    exch = GET_AMOUNT(posTab[i], ExtPos_RefNetAmt) /
                        GET_AMOUNT(posTab[i], ExtPos_PosNetAmt);
                    SET_EXCHANGE(posTab[i], ExtPos_PosExchRate, exch);
                }
                else
                {
                    SET_EXCHANGE(posTab[i], ExtPos_PosExchRate, 0.0);
                }
            }

            /*** Store system historical exchange rate ***/
            /* --------------------- */
            /* BUG090 - RAK - 960808 */
            /* if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_RefNetAmt), refCurrId) != 0) */
            if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_SysNetAmt),
                sysCurrId) != 0)
            {
                exch = GET_AMOUNT(posTab[i], ExtPos_RefNetAmt) /
                    GET_AMOUNT(posTab[i], ExtPos_SysNetAmt);
                SET_EXCHANGE(posTab[i], ExtPos_SysExchRate, exch);
            }
            else
                SET_EXCHANGE(posTab[i], ExtPos_SysExchRate, 0.0);

            /* DVP468 - XDI - 970620 */
            if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_BookInstrNetAmt),
                GET_ID(posTab[i], ExtPos_InstrCurrId)) != 0)
            {
                exch = GET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt) /
                    GET_AMOUNT(posTab[i], ExtPos_BookInstrNetAmt);
                SET_EXCHANGE(posTab[i], ExtPos_BookInstrExchRate, exch);
            }
            else
                SET_EXCHANGE(posTab[i], ExtPos_BookInstrExchRate, 0.0);

            /* DVP468 - XDI - 970620 */
            if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_BookPosNetAmt),
                GET_ID(posTab[i], ExtPos_PosCurrId)) != 0)
            {
                exch = GET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt) /
                    GET_AMOUNT(posTab[i], ExtPos_BookPosNetAmt);
                SET_EXCHANGE(posTab[i], ExtPos_BookPosExchRate, exch);
            }
            else
                SET_EXCHANGE(posTab[i], ExtPos_BookPosExchRate, 0.0);

            /* DVP468 - XDI - 970620 */
            if (CMP_AMOUNT(0, GET_AMOUNT(posTab[i], ExtPos_BookSysNetAmt),
                refCurrId) != 0)
            {
                exch = GET_AMOUNT(posTab[i], ExtPos_BookRefNetAmt) /
                    GET_AMOUNT(posTab[i], ExtPos_BookSysNetAmt);
                SET_EXCHANGE(posTab[i], ExtPos_BookSysExchRate, exch);
            }
            else
                SET_EXCHANGE(posTab[i], ExtPos_BookSysExchRate, 0.0);

        }
    }

	if (sPtfPosSet != NULLDYNST) { FREE_DYNST(sPtfPosSet, S_PtfPosSet); }
	if (ptfPosSetPtr != NULLDYNST) { FREE_DYNST(ptfPosSetPtr, A_PtfPosSet); }

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_UpdPosFields()
**
**  Description :   modify extpos fields
**
**  Arguments   :   domainPtr
**                  hierHead	(must be HierElt type)
**
**  Return      :   RET_SUCCEED or error code
**
**		    REF2779 - SSO - 000203: copy of price to quote for BP
**
*************************************************************************/
STATIC RET_CODE FIN_UpdPosFields(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
	DBA_DYNFLD_STP     *extractPos=(DBA_DYNFLD_STP*)NULL, instrPtr=NULLDYNST;
	int                i, posNbr=0;
	DICT_FCT_ENUM	   dictFctEn;
	PRICE_T	           quote, price;
	RET_CODE	   ret;
	PRICECALCRULE_ENUM priceCalcRuleEn; /* REF2779 - SSO - 000427 */ /* REF7264 - LJE - 020124 */

	/* update of ExtPos_Quote done only for some functions */
	/* NB: for optimisation, for functions != DictFct_OpList, update is done in FIN_UpdPosRefAmt */
	dictFctEn = (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId); /* REF7264 - LJE - 020124 */
	if (dictFctEn != DictFct_OpHist && dictFctEn !=  DictFct_OpList)
	{
	    return(RET_SUCCEED);
	}

	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
					                 FALSE, FIN_FilterBPNoQuote, NULLFCT,
					                 &posNbr, &extractPos)) != RET_SUCCEED)
	{
	    return(ret);
	}

	for (i=0; i<posNbr; i++)
	{
	    if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
		(instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext))) != NULLDYNST)
	    {
		/* REF2779 - SSO - 000418: use ExtPos_PriceCalcRuleEn  instead of A_Instr_PriceCalcRuleEn */
		/* REF2779 - SSO - 000427: if primary, use A_Instr_PriceCalcRuleEn */
		priceCalcRuleEn = (PRICECALCRULE_ENUM)GET_ENUM(extractPos[i], ExtPos_PriceCalcRuleEn); /* REF7264 - LJE - 020124 */
		if (priceCalcRuleEn == PriceCalcRule_None && GET_ENUM(extractPos[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
		{
		    priceCalcRuleEn = (PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn); /* REF7264 - LJE - 020124 */
		}
		price = GET_PRICE(extractPos[i], ExtPos_Price);
		if (CMP_PRICE(price, 0.0) < 0)	/* REF2779 - SSO - 000427 */
		{
		    price = -1.0 * price;
		}

		if (FIN_PriceToQuote(priceCalcRuleEn,
				     GET_ID(instrPtr, A_Instr_Id), instrPtr,
				     GET_DATETIME(extractPos[i], ExtPos_BegDate), NULL,
				     price, &quote,
				     posHierHead) == RET_SUCCEED)
		{
		    if (CMP_PRICE(price, 0.0) < 0) /* REF2779 - SSO - 000427 */
		    {
			quote = -1.0 * quote;
		    }
		    SET_PRICE(extractPos[i], ExtPos_Quote, quote);
		}
	    }
	}

	FREE(extractPos);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_UpdPosSysAmt()
**
**  Description :   This function ensure that the position sys gross and net
**                  amounts are in the right sys currency
**                  If a single ptf: the amounts are kept even if <> appl param
**
**  Arguments   :   domainPtr     domain structure pointer
**                  extractPos    position array pointer
**                  posNbr    position number
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	:   REF3178 - SSO - 990106
**
*************************************************************************/
RET_CODE FIN_UpdPosSysAmt(DBA_DYNFLD_STP domainPtr,
			              DBA_DYNFLD_STP *extractPos,
			              int            posNbr)
{
	OBJECT_ENUM       dimPtfEn;
	ID_T              sysCurrId;
	DBA_DYNFLD_STP	  ptfPtr=NULLDYNST;
	DBA_DYNFLD_STP 	  sPtfPosSet=NULLDYNST, ptfPosSetPtr=NULLDYNST;
	FUSDATERULE_ENUM  fusDateRuleEn;
        FIN_EXCHARG_ST    exchArgSt;
	DATETIME_T        exchDate;
	AMOUNT_T          amt;
	int		  i;
	RET_CODE          ret;
	EXCHANGE_T        exch;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
	    DBA_GetObjectEnum(GET_DICT(domainPtr,A_Domain_DimPtfDictId), &dimPtfEn);
	else
	    dimPtfEn = NullEntity;

	if (dimPtfEn==NullEntity || dimPtfEn==List || dimPtfEn==Third) /* list dimension (nothing to do if single ptf) */
	{
	    GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);

	    /* treat all positions */
	    for (i=0; i<posNbr; i++)
	    {
		    if ( (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext) != NULL)
	            && ((ptfPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext)))!= NULLDYNST)
		        && (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
		        && (GET_ID(ptfPtr, A_Ptf_SysCurrId) != sysCurrId) )
		    {
		        /* the ptf sys curr id is different, need to convert sys amounts */
		        if ((ret = FIN_PosGetDateRuleExchDate(extractPos[i],
				                          &sPtfPosSet, &ptfPosSetPtr,
				                          &fusDateRuleEn,
							              &exchDate)) != RET_SUCCEED)
		        {
			        if (sPtfPosSet != NULLDYNST) { FREE_DYNST(sPtfPosSet, S_PtfPosSet); }
			        if (ptfPosSetPtr != NULLDYNST) { FREE_DYNST(ptfPosSetPtr, A_PtfPosSet); }
			        return(ret);
		        }

		        exchArgSt.srcAmt = GET_AMOUNT(extractPos[i], ExtPos_SysGrossAmt);
		        /* NB: return code not tested, like all other calls to FIN_ExchAmtEuro... */
		        FIN_ExchAmtEuro(exchDate, GET_ID(ptfPtr, ExtPos_RefCurrId),
				                GET_ID(ptfPtr, A_Ptf_SysCurrId),
			                    sysCurrId, 0, NULLDYNST, &exchArgSt, extractPos[i],
                                (EXCHANGE_T*)NULL, &amt, (EXCHANGE_T*)NULL);

		        SET_AMOUNT(extractPos[i], ExtPos_SysGrossAmt, amt);

		        exchArgSt.srcAmt = GET_AMOUNT(extractPos[i], ExtPos_SysNetAmt);
		        FIN_ExchAmtEuro(exchDate, GET_ID(ptfPtr, ExtPos_RefCurrId),
				                GET_ID(ptfPtr, A_Ptf_SysCurrId),
			                    sysCurrId, 0, NULLDYNST, &exchArgSt, extractPos[i],
                                (EXCHANGE_T*)NULL, &amt, (EXCHANGE_T*)NULL);

		        SET_AMOUNT(extractPos[i], ExtPos_SysNetAmt, amt);

		        /* like in FIN_UpdPosRefAmt, all exch rate are relative to curr of the domain */
		        if (CMP_AMOUNT(0, GET_AMOUNT(extractPos[i], ExtPos_SysNetAmt), sysCurrId) != 0)
		        {
			        exch = CAST_EXCHANGE(GET_AMOUNT(extractPos[i], ExtPos_RefNetAmt) /
				                         GET_AMOUNT(extractPos[i], ExtPos_SysNetAmt));
			        SET_EXCHANGE(extractPos[i], ExtPos_SysExchRate, exch);
		        }
		    }
	    } /* loop on positions */

	    if (sPtfPosSet != NULLDYNST) { FREE_DYNST(sPtfPosSet, S_PtfPosSet); }
	    if (ptfPosSetPtr != NULLDYNST) { FREE_DYNST(ptfPosSetPtr, A_PtfPosSet); }
	}

	return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   FIN_CmpCheckLogicFus()
**
**  Description :   Position table is sort by instr identifier
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation	:   REF1211 - RAK - 980210
**
*************************************************************************/
int FIN_CmpCheckLogicFus(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	char	stock1=FALSE, stock2=FALSE;

	if (GET_ID((*ptr1), ExtPos_InstrId) < GET_ID((*ptr2), ExtPos_InstrId))
		return(-1);
	else if (GET_ID((*ptr1), ExtPos_InstrId) > GET_ID((*ptr2), ExtPos_InstrId))
		return(1);
	else
	{
		/* Initial and final positions (balPosTpId = NULL) are first */
		if (IS_NULLFLD((*ptr1), ExtPos_BalPosTpId) == TRUE &&
	            (GET_ENUM((*ptr1), ExtPos_NatEn)==(ENUM_T)ExtPosNat_InitStock ||
		     GET_ENUM((*ptr1), ExtPos_NatEn)==(ENUM_T)ExtPosNat_FinalStock))
			stock1 = TRUE;

		if (IS_NULLFLD((*ptr2), ExtPos_BalPosTpId) == TRUE &&
	            (GET_ENUM((*ptr2), ExtPos_NatEn)==(ENUM_T)ExtPosNat_InitStock ||
		     GET_ENUM((*ptr2), ExtPos_NatEn)==(ENUM_T)ExtPosNat_FinalStock))
			stock2 = TRUE;

		if (stock1 == stock2)
			return(0);
		else if (stock1 == TRUE && stock2 == FALSE)
			return(-1);
		else
			return(1);
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpValoPos()
**
**  Description :   Position table is sort by position date,
**					      instrument identifier,
**					      currency identifier and
**					      term type id.
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Modif.      :   REF5306 - RAK - 010212 - Cash account of Fwd at the end
**
*************************************************************************/
STATIC int FIN_CmpValoPos(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Position date */
	if (DATETIME_CMP(GET_DATETIME((*ptr1), ExtPos_ExtPosDate),
			 GET_DATETIME((*ptr2), ExtPos_ExtPosDate)) == 0)
	{
	    /* Instrument identifier */
	    if (GET_ID((*ptr1), ExtPos_InstrId) ==
		    GET_ID((*ptr2), ExtPos_InstrId))
	    {
		    /* Currency identifier */
		    if (GET_ID((*ptr1), ExtPos_PosCurrId) ==
		        GET_ID((*ptr2), ExtPos_PosCurrId))
		    {
		        /* Term code */
		        if (GET_ENUM((*ptr1), ExtPos_FusRuleEn) ==
		            GET_ENUM((*ptr2), ExtPos_FusRuleEn))
		        {
			        return(0);
		        }
		        else
		        {
		   	        /* Term code aren't same */
			        return(GET_ENUM((*ptr1), ExtPos_FusRuleEn) -
			                GET_ENUM((*ptr2), ExtPos_FusRuleEn));
		        }
		    }
		    else
		    {
		        /* Currency identifier aren't same */
		        return(CMP_ID(GET_ID((*ptr1), ExtPos_PosCurrId) ,
		               GET_ID((*ptr2), ExtPos_PosCurrId))); /* DLA - REF9089 - 030508 */
		    }
	    }
	    else
	    {
		    /* Instrument identifier aren't same */
            /* REF5306 - RAK - 010212 - Cash account of Fwd at the end */
            if (GET_ENUM((*ptr1), ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
	            GET_ENUM((*ptr1), ExtPos_RefNatEn) == PosRefNat_FwdClose)
            {
                DBA_DYNFLD_STP  instrPtr=NULLDYNST;

                if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL)
        		    instrPtr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext));

                if (instrPtr != NULLDYNST &&
                    GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
                    return(1);
                else
                    return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId) ,
		                   GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
            }
            else if (GET_ENUM((*ptr2), ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
	                 GET_ENUM((*ptr2), ExtPos_RefNatEn) == PosRefNat_FwdClose)
            {
                DBA_DYNFLD_STP  instrPtr=NULLDYNST;

                if (GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext) != NULL)
        		    instrPtr = *(GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext));

                if (instrPtr != NULLDYNST &&
                    GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
                    return(-1);
                else
                    return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId) ,
		                   GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
            }
			/* WEALTH-9577 - DDV - 240617 - Cash account of Fut at the begining */
			else if (GET_ENUM((*ptr1), ExtPos_RefNatEn) == PosRefNat_FutOpen ||
				     GET_ENUM((*ptr1), ExtPos_RefNatEn) == PosRefNat_FutClose)
			{
				DBA_DYNFLD_STP  instrPtr = NULLDYNST;

				if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL)
					instrPtr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext));

				if (instrPtr != NULLDYNST &&
					GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
					return(-1);
				else
					return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId),
						   GET_ID((*ptr2), ExtPos_InstrId))); 
			}
			else if (GET_ENUM((*ptr2), ExtPos_RefNatEn) == PosRefNat_FutOpen ||
				     GET_ENUM((*ptr2), ExtPos_RefNatEn) == PosRefNat_FutClose)
			{
				DBA_DYNFLD_STP  instrPtr = NULLDYNST;

				if (GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext) != NULL)
					instrPtr = *(GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext));

				if (instrPtr != NULLDYNST &&
					GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
					return(1);
				else
					return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId),
						GET_ID((*ptr2), ExtPos_InstrId))); 
			}
			else
		        return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId) ,
		               GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
	    }
	}
	else
	{
		/* Position date aren't same */
		return(DATETIME_CMP(GET_DATETIME((*ptr1), ExtPos_ExtPosDate),
			         GET_DATETIME((*ptr2), ExtPos_ExtPosDate)));
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpListCompoByDescDate()
**
**  Description :   ListCompo table is sort by descending date,
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a positive value if first element < second element
**                  a null value     if first element = second element
**                  a negative value if first element > second element
**
**  Creation    :   REF4306 - CSY - 000207
**  Modification:
**
*************************************************************************/
STATIC int FIN_CmpListCompoByDescDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(DATETIME_CMP(GET_DATETIME((*ptr2), A_ListCompo_ValidDt),
			         GET_DATETIME((*ptr1), A_ListCompo_ValidDt)));
}
/************************************************************************
**
**  Function    :   FIN_FilterSingleInstr()
**
**  Description :   Select the current instrument in the domain
**
**  Arguments   :   ptr1		 pointer on dynamic structure
**                  ptr2		 pointer on dynamic structure
*                   dynStTp      dynamic structure type
**
**  Return      :   TRUE or FALSE
*
**  Creation    :   REF7422 - MCA - 040417
**  Modification:
**
*************************************************************************/
STATIC int FIN_FilterSingleInstr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP domainPtr)
{
   	if (GET_ID(dynSt,A_Instr_Id) == GET_ID(domainPtr,A_Domain_InstrObjId))
 	    return(TRUE);
	else
		return(FALSE);
}
/************************************************************************
**
**  Function    :   FIN_FilterSingleListCompo()
**
**  Description :   Select the current ListCompo in the domain
**
**  Arguments   :   ptr1		 pointer on dynamic structure
**                  ptr2		 pointer on dynamic structure
*                   dynStTp		 dynamic structure type
**
**  Return      :   TRUE or FALSE
*
**  Creation    :   REF7422 - MCA - 040417
**  Modification:
**
*************************************************************************/
STATIC int FIN_FilterSingleListCompo(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP domainPtr)
{
   	if (GET_ID(dynSt,A_ListCompo_ObjId) == GET_ID(domainPtr,A_Domain_InstrObjId))
 	    return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*  Function    : FIN_FilterBPNoPrice()
*
*  Description : Verify that extpos is a BP with NULL quote (and NOT null price) , return TRUE ; FALSE elsewhere.
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation D. : REF2779 - SSO - 000203
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterBPNoQuote(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	if (	(IS_NULLFLD(dynSt, ExtPos_BalPosTpId) == FALSE)
	    &&  (IS_NULLFLD(dynSt, ExtPos_Quote) == TRUE)
	    &&  (IS_NULLFLD(dynSt, ExtPos_Price) == FALSE))  /* will get quote from price */
	{
	    return(TRUE);
	}
	else
	{
    	    return(FALSE);
	}
}

/************************************************************************
**
**  Function    :   FIN_FilterMainFlow()
**
**  Description :   Keep only main flow position and balance position
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   DVP166 - 970106 - DED
**  Last modif. :   REF1320 - 980223 - GRD.
**
*************************************************************************/
int FIN_FilterMainFlow(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if ((GET_FLAG(dynSt, ExtPos_MainFlg) == TRUE ||
	 GET_ENUM(dynSt, ExtPos_PosNatEn) == PosNat_MainPos) &&
	(GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_Flow) &&
	(GET_ENUM(dynSt, ExtPos_PrimaryEn) == PosPrimary_Primary) &&
	((GET_ENUM(dynSt, ExtPos_OpenOpNatEn) == OpNat_BookAdjust || /* GRD. DVP166 97.04.28. */
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) == OpNat_Transf ||
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) == OpNat_BpTransf) ||
	 (GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BookAdjust &&
	  GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_Transf &&
	  GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BpTransf &&
	  GET_ID(dynSt, ExtPos_PtfPosSetId) == (ID_T)0)))
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterMainFlowNoPPS()
**
**  Description :   Keep only main flow position and balance position
**                  and no operation from port pos set
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   BUG380  - XDI - 970528
**  Last modif. :   REF1320 - 980223 - GRD.
**                  REF46   - 980513 - GRD.
*************************************************************************/
int FIN_FilterMainFlowNoPPS(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if ((GET_FLAG(dynSt, ExtPos_MainFlg) == TRUE ||
	 GET_ENUM(dynSt, ExtPos_PosNatEn) == PosNat_MainPos) &&
	(GET_ENUM(dynSt, ExtPos_PrimaryEn) == PosPrimary_Primary) &&
	(GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_Flow) &&
	 GET_ID(dynSt, ExtPos_PtfPosSetId) == (ID_T)0 &&
	(GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BookAdjust &&
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_Transf &&
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BpTransf))
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterMainFlowPPSwithTransfer()
**
**  Description :   Keep only main flow position and balance position
**                  and no operation from port pos set
**		    Copy also transfer and Bp transfer operations into PPS
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   REF4359 - 000511 - DED
**  Last modif. :

*************************************************************************/
int FIN_FilterMainFlowPPSwithTransfer(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if ((GET_FLAG(dynSt, ExtPos_MainFlg) == TRUE || GET_ENUM(dynSt, ExtPos_PosNatEn) == PosNat_MainPos) &&
	(GET_ENUM(dynSt, ExtPos_PrimaryEn) == PosPrimary_Primary) &&
	(GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_Flow) &&
	(GET_ID(dynSt, ExtPos_PtfPosSetId) == (ID_T)0) &&
	(GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BookAdjust))

/* has to be copied into PPS
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_Transf &&
	 GET_ENUM(dynSt, ExtPos_OpenOpNatEn) != OpNat_BpTransf))
*/
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterStock()
**
**  Description :   Keep only stock position and balance position
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int FIN_FilterStock(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_InitStock ||
	GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_IntermStock ||
	GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_FinalStock)
	    return(TRUE);
    else
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterInitStock()
**
**  Description :   Extract initial stock position and balance position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int FIN_FilterInitStock(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_InitStock)
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterInitStock()
**
**  Description :   Extract initial stock position and balance position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int FIN_FilterInitStockNoBP(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{

    if ((GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_InitStock) &&
		(IS_NULLFLD(dynSt, ExtPos_BalPosTpId) == TRUE))
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterFinalStock()
**
**  Description :   Extract final stock position and balance position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int FIN_FilterFinalStock(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_FinalStock)
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPStock()
**
**  Description :   Extract stock position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int FIN_FilterPStock(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (IS_NULLFLD(dynSt, ExtPos_BalPosTpId) == TRUE &&
	(GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_InitStock ||
         GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_FinalStock ||
	 GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_IntermStock))
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPStockExcludeZeroPos()
**
**  Description :   Extract stock position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-61292 - DDV - 241205
**
*************************************************************************/
int FIN_FilterPStockExcludeZeroPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	if (FIN_FilterPStock(dynSt, dynStTp, notUse) == TRUE)
	{
		DBA_DYNFLD_STP mainInstr = NULLDYNST;

		if (GET_ENUM(dynSt, ExtPos_LockNatEn) != OpLockNat_RevRepoLocking &&
			GET_ENUM(dynSt, ExtPos_LockNatEn) != OpLockNat_BuySellBackLocking &&
			GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) != NULL &&
			(mainInstr = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext))) != NULL &&
			GET_FLAG(mainInstr, A_Instr_AccrIntInstrChronoFlg) == FALSE &&
			CMP_NUMBER(GET_NUMBER(dynSt, ExtPos_Qty), 0.0) == 0 &&
			CMP_AMOUNT(GET_AMOUNT(dynSt, ExtPos_AccrAmt), 0.0, GET_ID(dynSt, ExtPos_PosCurrId)) == 0 &&
			CMP_AMOUNT(GET_AMOUNT(dynSt, ExtPos_PosNetAmt), 0.0, GET_ID(dynSt, ExtPos_PosCurrId)) == 0 &&
			CMP_AMOUNT(GET_AMOUNT(dynSt, ExtPos_RefNetAmt), 0.0, GET_ID(dynSt, ExtPos_RefCurrId)) == 0)
		{
			return(FALSE);
		}
		else
		{
			return(TRUE);
		}
	}
	else
	{
		return(FALSE);
	}
}

/************************************************************************
*
*  Function    : FIN_FilterParentOrder()
*
*  Description : Verify that an extended operation is a parent order and in
*                this case, return TRUE ; FALSE elsewhere.
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation D. : DVP342 - 970219 - PEC - Order management
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterParentOrder(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	if (GET_ENUM(dynSt, ExtOp_ParOpNatEn) == ParOpNat_BlockOrder ||
        GET_ENUM(dynSt, ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder ||
		GET_ENUM(dynSt, ExtOp_ParOpNatEn) == ParOpNat_CombinedOrder) /* PMSTA06760 - DDV - 080701 */
		return(TRUE);

	return(FALSE);
}

/************************************************************************
*
*  Function    : FIN_ChechIfValRuleUseExtPos()
*
*  Description : Check if the quaote valuation rule use informations
*                of extended position. Return TRUE or FALSE
*
*  Arguments   : domainPtr pointer on domain
*
*  Return      : TRUE or FALSE
*
*  Creation D. : REF4478 - DDV - 000411
*  Last modif. :
*
*************************************************************************/
STATIC FLAG_T FIN_ChechIfValRuleUseExtPos(ID_T           valRuleId,
                                          DBA_DYNFLD_STP domainPtr)
{
	DBA_DYNFLD_STP valRulePtr=NULLDYNST;
	DBA_DYNFLD_STP valRuleHistPtr=NULLDYNST;
	DBA_DYNFLD_STP *valRuleEltTab=NULLDYNSTPTR;
	int	       valRuleEltNbr = 0;
	int	       i = 0;
	FLAG_T         allocValRuleOk=FALSE;
	OBJECT_ENUM    entity;

    if (valRuleId == 0)
        return(FALSE);

    if (FIN_LoadValRuleAndHist(valRuleId,
                               GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
                               NULL,
                               &allocValRuleOk,
                               &valRulePtr,
                               &valRuleHistPtr) != RET_SUCCEED)
	{
		return(TRUE);
	}

    DBA_GetObjectEnum(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId),&entity);

    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}

    if (entity == EPos)
    {
        FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        return(TRUE);
    }

	if (FIN_LoadValRuleElt(valRuleHistPtr,
                           &valRuleEltNbr,
                           &valRuleEltTab) != RET_SUCCEED)
	{
        FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
		return(TRUE);
	}
    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);

    for (i = 0; i<valRuleEltNbr; i++)
    {
        if (GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == EvalRule_ValuedUsingScpt ||
            GET_ENUM(valRuleEltTab[i], A_ValRuleElt_EvalRuleEn) == EvalRule_Linear)
        {
            DBA_GetObjectEnum(GET_DICT(valRuleEltTab[i], A_ValRuleElt_ScriptEntityDictId), &entity);
            if (entity == EPos)
            {
                DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
                return(TRUE);
            }
        }

    }

    DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);

	return(FALSE);
}

/************************************************************************
*
*  Function    : FIN_GetFmtFilter()
*
*  Description : This function will reture the format filter of
*                the entity coressponding to entityInputEn
*
*  Arguments   : aDomain		: pointer on a domain dynamic structure
*                entityInputEn  : entity of Fmt for wich we want de filter
*                scriptFilter	: returned filter
*                allocFlg       : True if scriptFilter has benn allocated
*
*  Return      : RET_SUCCEED	: if ok
*
*  Creation D. : REF10530 - TEB - 050818
*   Modif       :   HFI-PMSTA-49593-220817  Use memory pool for sumFmtEltTab
*
*************************************************************************/
RET_CODE FIN_GetFmtFilter(DBA_DYNFLD_STP aDomain, OBJECT_ENUM	entityInputEn, char **scriptFilter, FLAG_T *allocFlg)
{
	RET_CODE			ret=RET_SUCCEED;
	DICT_ATTRIB_STP		attribSt;
	DBA_DYNFLD_STP		*sumFmtEltTab=NULLDYNSTPTR;
	SCPT_DATASET_ST     dataSet[10];
	FMTNAT_ENUM			authFmtNatTab[50];
	ID_T				fmtId, usrId, fctResultId, dataSetId, langDictId;
	DICT_T              fctDictId;
	FIN_FCT_OUTPUT_ENUM	outputTpEn;
	OBJECT_ENUM			entityEn;
	int					i, j, idx, fmtEltNbOut = 0, fmtEltNb = 0, totalSetNb;
    DBA_DYNFLD_STP     *aTascJobTableTab=NULL;
    int                 aTascJobTableNbr;
	ENUM_T              tascJobAccessE;
    MemoryPool          mp;                         /*  HFI-PMSTA-49593-220817  */

	/* INITIALISATION */
	if (aDomain != NULLDYNSTPTR)
	{
		outputTpEn  = (FIN_FCT_OUTPUT_ENUM)GET_ENUM(aDomain, A_Domain_OutputTpEn);

		/* PMSTA04773 - DDV - 071114 - Use the Dict function given to the RPC */
		if (IS_NULLFLD(aDomain, A_Domain_RpcFctDictId) == FALSE)
			fctDictId   = (DICT_T)GET_DICT(aDomain, A_Domain_RpcFctDictId);
		else
		    fctDictId   = (DICT_T)GET_DICT(aDomain, A_Domain_FctDictId);
		fmtId       = (ID_T)GET_ID(aDomain,   A_Domain_FmtId);
		usrId       = (ID_T)GET_ID(aDomain,   A_Domain_UsrId);
		fctResultId = (ID_T)GET_ID(aDomain,   A_Domain_FctResultId);
		dataSetId   = (ID_T)GET_ID(aDomain,   A_Domain_DataSetId);
		langDictId  = (ID_T)GET_ID(aDomain,   A_Domain_LangDictId);
	}
	else
	{
		return(RET_GEN_ERR_INVARG);
	}

    memset(dataSet, 0, 10*sizeof(SCPT_DATASET_ST));
	*allocFlg = FALSE;


    /***** MAKE AUTHORISED_FORMAT_NATURE LIST *****/
    authFmtNatTab[0] = FmtNat_DetList;
    authFmtNatTab[1] = FmtNat_SummList;
    authFmtNatTab[2] = FmtNat_Graphic;
    authFmtNatTab[3] = FmtNat_Matrix;
    authFmtNatTab[4] = FmtNat_Report;
    authFmtNatTab[5] = FmtNat_Table;
    authFmtNatTab[6] = FmtNat_Domain;
    authFmtNatTab[7] = FmtNat_ListDyn;
    authFmtNatTab[8] = FmtNat_Persisted;
    authFmtNatTab[9] = FmtNat_SearchData; /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
    authFmtNatTab[10] = FmtNat_NO_VALUE;

	/* PMSTA08249 - LJE - 090604 */
	if (outputTpEn == TASCTableOutput)
	{
		SERV_SelectFmtForTASCOutput(aDomain,
									&aTascJobTableTab,
									&aTascJobTableNbr,
									&tascJobAccessE,
									&sumFmtEltTab,
									&fmtEltNb,
									langDictId);

		DBA_FreeDynStTab(aTascJobTableTab, aTascJobTableNbr, A_TascJobTable); /* PMSTA14453 - DDV - 120712 - Purify */
	}
	else
	{
		/***** INPUT STRUCT ALLOCATION & INITIALISATION *****/
        DBA_DYNFLD_STP getArgSt = mp.allocDynst(FILEINFO, Get_Arg);

		if (outputTpEn == ClientModuleOutput &&
			fmtId == (ID_T)0)
		{
			DBA_DYNFLD_STP applUser  = mp.allocDynst(FILEINFO, A_ApplUser);
			DBA_DYNFLD_STP sApplUser = mp.allocDynst(FILEINFO, S_ApplUser);

			SET_ID(sApplUser, A_ApplUser_Id, usrId);
			DBA_Get2(ApplUser, UNUSED, S_ApplUser, sApplUser, A_ApplUser, &applUser, UNUSED, UNUSED, UNUSED);

			/***** GET THE USER'S FORMAT_PROFILE_ID *****/
			SET_ID(getArgSt, Get_Arg_Id, GET_ID(applUser, A_ApplUser_FmtProfileId ));

			/***** GET THE DOMAIN FUNCTION_DICT_ID *****/
			SET_ID(getArgSt, Get_Arg_FctDictId, fctDictId);
		}
		else
		{
			/***** FOR REPORTS : GET FORMAT_ID *****/
			SET_ID(getArgSt, Get_Arg_Id, fmtId);
		}

		/***** SEARCH attribute_dict_id for format_element.script_definition field *****/
		if ((ret=DBA_SearchAttribSqlName( FmtElt, "script_definition", &attribSt)) != RET_SUCCEED)
		{
			return(ret);
		}

		SET_ID(getArgSt, Get_Arg_AttribDictId, attribSt->attrDictId);

		if (langDictId == 0)
		{
			DBA_GetUserInfo2(A_ApplUser_LangDictId, &langDictId, TRUE); /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
		}

		SET_ID(getArgSt, Get_Arg_LangDictId, langDictId);

		if (DBA_Select2(FmtElt,
						UNUSED,
						Get_Arg,
						getArgSt,
						Sum_FmtElt,
						&sumFmtEltTab,
						UNUSED,
						UNUSED,
						&fmtEltNb,
						UNUSED,
						UNUSED ) != RET_SUCCEED )
		{
			return(RET_DBA_ERR_NODATA);
		}
	}

    /***** DELETE NON-DESIRED FORMAT (by format_nature) *****/
	/* !!!! JUST KEEP FORMAT FOR ENTITY ext_operation !!!!! */
    for(i=0 ; i<fmtEltNb ; i++)
    {
		DBA_GetObjectEnum(GET_DICT(sumFmtEltTab[i], Sum_FmtElt_FmtEntDictId),&entityEn);

		if (entityEn == entityInputEn)
		{
			for(j=0 ; authFmtNatTab[j] != FmtNat_NO_VALUE ; j++)
				if(GET_ENUM(sumFmtEltTab[i],Sum_FmtElt_FmtNatEn) == authFmtNatTab[j])
					break;

			if(authFmtNatTab[j] == FmtNat_NO_VALUE)
			{
				FREE_DYNST(sumFmtEltTab[i], Sum_FmtElt);

				for( idx=i ; idx<(fmtEltNb-1) ; idx++)
				{
					sumFmtEltTab[idx] = sumFmtEltTab[idx +1];
				}
				fmtEltNb--;
				i--;
			}
		}
		else
		{
            FREE_DYNST(sumFmtEltTab[i], Sum_FmtElt);

            for( idx=i ; idx<(fmtEltNb-1) ; idx++)
            {
                sumFmtEltTab[idx] = sumFmtEltTab[idx +1];
            }
            fmtEltNb--;
            i--;
        }
    }

    /***** CHECK IF NO FORMAT_ELEMENT ... *****/
    if(fmtEltNb <=0)
    {
		FREE(sumFmtEltTab);
		return(RET_SUCCEED);
    }

    /***** FORMAT ELEMENT ANALYSE *****/
    if((ret=SCPT_FmtEltAnalyse(&sumFmtEltTab, fmtEltNb, outputTpEn, dataSet, &totalSetNb, &fmtEltNbOut, SERV_IsGuiConnect(), FALSE)) == FALSE)         /*  FIH-REF11443-050923 Add call to SERV_IsGuiConnect   */ /* DLA - REF04685 - 080117 */
    {

		DBA_FreeDynStTab(sumFmtEltTab, fmtEltNb, Sum_FmtElt);
		for(i=0 ; i<totalSetNb ; i++)
		{
			if(dataSet[i].scriptFilter != NULL)
				FREE(dataSet[i].scriptFilter);
			if(dataSet[i].colTypesTab != NULL)
				FREE(dataSet[i].colTypesTab);
			if(dataSet[i].dataDefTab != NULL)
				FREE(dataSet[i].dataDefTab);
		}
        return(ret);
    }
    mp.ownerDynStpTab(sumFmtEltTab, fmtEltNbOut);

	if (totalSetNb == 1)
	{
		DBA_GetObjectEnum(dataSet[0].entityDictId, &entityEn);

		if (entityEn == entityInputEn &&
			dataSet[0].scriptFilter != NULL &&
			dataSet[0].scriptFilter[0] != END_OF_STRING)
		{
			if ((*scriptFilter = (char *)CALLOC((strlen(dataSet[0].scriptFilter)+3), sizeof(char)))==NULL)
			{
				for(i=0 ; i<totalSetNb ; i++)
				{
					if(dataSet[i].scriptFilter != NULL)
						FREE(dataSet[i].scriptFilter);
					if(dataSet[i].colTypesTab != NULL)
						FREE(dataSet[i].colTypesTab);
					if(dataSet[i].dataDefTab != NULL)
						FREE(dataSet[i].dataDefTab);
				}
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				return(RET_MEM_ERR_ALLOC);
			}
			memset(*scriptFilter, 0, (strlen(dataSet[0].scriptFilter)+1)*sizeof(char));

			sprintf(*scriptFilter,"(%s)", dataSet[0].scriptFilter);
			*allocFlg = TRUE;
		}
		else
		{
			*scriptFilter = NULL;
		}
	}

	for(i=0 ; i<totalSetNb ; i++)
	{
		if(dataSet[i].scriptFilter != NULL)
			FREE(dataSet[i].scriptFilter);
		if(dataSet[i].colTypesTab != NULL)
			FREE(dataSet[i].colTypesTab);
		if(dataSet[i].dataDefTab != NULL)
			FREE(dataSet[i].dataDefTab);
	}

	return(RET_SUCCEED);
}


/************************************************************************
*
*  Function    : FIN_AnalysisSMatchO()
*
*  Description : Search and retrieve matching orders for a given set
*                of unmatched executions
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF9764 - TEB - 040122
*
*  Last modif. :
*
*************************************************************************/
RET_CODE FIN_AnalysisSMatchO(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
    DATETIME_T      tmpDate;
	RET_CODE		ret = RET_SUCCEED;

	DbiConnection*  dbiConn = nullptr;

	if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
		return(RET_DBA_ERR_CONNOTFOUND);
	}
	/* Put back null value in from or till date if needed */
    tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    if (tmpDate.date == MAGIC_END_DATE)
        SET_NULL_DATETIME(domainPtr, A_Domain_InterpFromDate);

    tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
    if (tmpDate.date == MAGIC_END_DATE)
        SET_NULL_DATETIME(domainPtr, A_Domain_InterpTillDate);

    /* Select and put in hierarchy the extended Transactions (with Executions and Orders) */
    if ((ret=DBA_LoadExtTransForSMatchO(hierHead, domainPtr, *dbiConn)) != RET_SUCCEED)
    {
        if (DBA_CreateTempTables( *dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
   			MSG_LogMesg( RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");

        DBA_EndConnection(&dbiConn);

        MSG_LogMesg( RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_LoadExtTransForSMatchO failed");
        return(ret);
    }

	/* Drop temporary tables and close connection */
    if (DBA_CreateTempTables( *dbiConn, TCT_VECTOR_ID) != RET_SUCCEED)
   		MSG_LogMesg( RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");

    DBA_EndConnection(&dbiConn);

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_FilterNotChildOrder()
*
*  Description : Verify that an extended operation is not a child order and in
*                this case, return TRUE ; FALSE elsewhere.
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation D. : REF8723 - TEB - 040218
*
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterNotChildOrder(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (GET_ENUM(dynSt, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder ||
		GET_ENUM(dynSt, ExtOp_ParOpNatEn) == ParOpNat_ChildCombinedOrder) /* PMSTA06760 - DDV - 080701 */
		return(FALSE);

	return(TRUE);
}

/************************************************************************
*
*  Function    : FIN_FilterChildOrder()
*
*  Description : Verify that an extended operation is a child order and in
*                this case, return TRUE ; FALSE elsewhere.
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation D. : REF10184 - TEB - 040408
*
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterChildOrder(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{

	if (FIN_FilterNotChildOrder(dynSt, dynStTp, notUse) == TRUE)
		return(FALSE);

	return(TRUE);
}

/************************************************************************
*
*  Function    : FIN_AnalysisPurgeOrder()
*
*  Description : Purge the order for a given domain
*
*  Arguments   : domainPtr : pointer on a domain dynamic structure
*                hierHead  : hierarchy pointer
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF8723 - TEB - 040218
*
*  Last modif. : REF8723 - TEB - 040302
*                REF10184 - TEB - 040408
*                PMSTA-11733 - 150411 - PMO : Purge order function does not work on block orders and it cannot be started from the GUI any more
*************************************************************************/
RET_CODE FIN_AnalysisPurgeOrder(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP	*notChildExtOpTab = NULLDYNSTPTR,
                    *childExtOpTab    = NULLDYNSTPTR,
                    *cpyChildExtOpTab = NULLDYNSTPTR, /* REF8723 - TEB - 040302 */
                    *cpyExtExecTab    = NULLDYNSTPTR; /* REF8723 - TEB - 040302 */
    int             notChildExtOpNbr  = 0,
                    extExecNbr        = 0,  /* REF8723 - TEB - 040302 */
                    childExtOpNbr     = 0,  /* REF8723 - TEB - 040302 */
                    i,j;
    FLAG_T          purgeChildFlg;
	RET_CODE		ret = RET_SUCCEED;
    DICT_T          initialFctDict;


    /* First load like for order list */
    /* Set dict function id to order_list */
    initialFctDict = GET_DICT(domainPtr, A_Domain_FctDictId);
    SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_OrderList);

    ret = FIN_AnalysisOpSearchPhase2(domainPtr, hierHead);

    /* Restore initial dict function id */
    SET_DICT(domainPtr, A_Domain_FctDictId, initialFctDict);

    /* Make the links between ext_order (ExtOp) and ext_execution in hier */
    if (ret == RET_SUCCEED)
    {
	    ret = DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_ExtExecution_Ext);

        if (ret == RET_SUCCEED)
        {
	        ret = DBA_MakeSpecRecLinks(hierHead, ExtOp, ExtOp_ExtExecution_Ext);
        }
    }

    /* Make the links between ext_order (ExtOp) child and parent in hier */
    if (ret == RET_SUCCEED)
    {
	    ret =  DBA_SetHierLnkUsed(hierHead,    ExtOp, ExtOp_ParExtOp_Ext);

        if (ret == RET_SUCCEED)
        {
	        ret = DBA_MakeSpecRecLinks(hierHead,  ExtOp, ExtOp_ParExtOp_Ext);
        }
    }


    /* PMSTA-11733 - 150411 - PMO
     * Disable the local cache to avoid timestamp problem while deleting childs orders
     * (that implies an update of the parent for each childs deleted)
     */
    (void)DBA_DisableLocalCache (Opti_SelExtOp);

    if (ret == RET_SUCCEED)
    {
        /* Extract all not childs ext_orders (EXtPos) from Hier */
        DBA_ExtractHierEltRec(hierHead,
                              ExtOp,
                              FALSE,
                              FIN_FilterNotChildOrder,
                              NULLFCT,
	                          &notChildExtOpNbr,
                              &notChildExtOpTab);

        /* For each ext_order that is not a child */
	    for (i=0; i<notChildExtOpNbr; i++)
    	{
            purgeChildFlg = TRUE;

            /* Get all child ext_orders (ExtPos) associated in hier */
		    childExtOpTab = GET_EXTENSION_PTR(notChildExtOpTab[i], ExtOp_ChildExtOp_Ext);

            if ((childExtOpNbr= GET_EXTENSION_NBR(notChildExtOpTab[i], ExtOp_ChildExtOp_Ext))>0)
            {
                /* REF8723 - TEB - 040302 */
                /* Make copy of extension, because of DBA_DelAndFreeHierEltRec */
                if ((cpyChildExtOpTab = (DBA_DYNFLD_STP*) CALLOC(childExtOpNbr, sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                {
                    memcpy(cpyChildExtOpTab,
                           childExtOpTab,
                           (childExtOpNbr * sizeof(DBA_DYNFLD_STP)));
                }
                else
                {
                    FREE(notChildExtOpTab);
                    return(RET_MEM_ERR_ALLOC);
                }

                /* For each possible child make purge */
		        for (j=0; j<childExtOpNbr; j++)
		        {
                    /* REF8723 - TEB - 040302 */
                    /* Make copy of extension, because of DBA_DelAndFreeHierEltRec */
                    if ((extExecNbr = GET_EXTENSION_NBR(cpyChildExtOpTab[j], ExtOp_ExtExecution_Ext))>0) /* REF10184 - TEB - 040408 */
                    {
                        if ((cpyExtExecTab = (DBA_DYNFLD_STP*) CALLOC(extExecNbr, sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                        {
                            memcpy(cpyExtExecTab,
                                   GET_EXTENSION_PTR(cpyChildExtOpTab[j], ExtOp_ExtExecution_Ext), /* REF10184 - TEB - 040408 */
                                   (extExecNbr * sizeof(DBA_DYNFLD_STP)));
                        }
                        else
                        {
                            FREE(cpyChildExtOpTab);
                            FREE(notChildExtOpTab);
                            return(RET_MEM_ERR_ALLOC);
                        }
                    }

                    if ( OPE_PurgeOneOrderAndExecutions(hierHead,
										                domainPtr,
										                cpyChildExtOpTab[j],            /* REF8723 - TEB - 040302 */
										                cpyExtExecTab,                  /* REF8723 - TEB - 040302 */
										                extExecNbr,
                                                        false) != RET_SUCCEED )    /* REF8723 - TEB - 040302 / PMSTA-11733 - 150411 - PMO */
                    {
                        purgeChildFlg = FALSE;
                    }

                    if (extExecNbr>0)
                        FREE(cpyExtExecTab);    /* REF8723 - TEB - 040302 */
                }

                FREE(cpyChildExtOpTab); /* REF8723 - TEB - 040302 */
            }

            /* Don't purge parent ext_order (ExtPos) if one of the
             * purge from a child had a problem
             */
            if (purgeChildFlg == TRUE)
            {
                /* REF8723 - TEB - 040302 */
                /* Make copy of extension, because of DBA_DelAndFreeHierEltRec */
                if ((extExecNbr = GET_EXTENSION_NBR(notChildExtOpTab[i], ExtOp_ExtExecution_Ext))>0)
                {
                    if ((cpyExtExecTab = (DBA_DYNFLD_STP*) CALLOC(extExecNbr, sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                    {
                        memcpy(cpyExtExecTab,
                               GET_EXTENSION_PTR(notChildExtOpTab[i], ExtOp_ExtExecution_Ext),
                               (extExecNbr * sizeof(DBA_DYNFLD_STP)));
                    }
                    else
                    {
                        FREE(notChildExtOpTab);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }

                OPE_PurgeOneOrderAndExecutions(hierHead,
										       domainPtr,
										       notChildExtOpTab[i],
										       cpyExtExecTab,       /* REF8723 - TEB - 040302 */
										       extExecNbr,
                                               true);               /* REF8723 - TEB - 040302 / PMSTA-11733 - 150411 - PMO */

                if (extExecNbr>0)
                    FREE(cpyExtExecTab);    /* REF8723 - TEB - 040302 */
            }
	    }
        /* Free of array */
    	FREE(notChildExtOpTab);

        /* REF10184 - TEB - 040408 */
        /*
         * Treat all the child ext_orders (EXtPos) that are remaining in Hier
         * and which don't have the parent in Hier (these one are treated above)
         */

        DBA_ExtractHierEltRec(hierHead,
                              ExtOp,
                              FALSE,
                              FIN_FilterChildOrder,
                              NULLFCT,
	                          &childExtOpNbr,
                              &childExtOpTab);

        /* For each ext_order */
	    for (i=0; i<childExtOpNbr; i++)
    	{
            /* If the parent is not in Hier, try to purge the order */
            if ((notChildExtOpNbr= GET_EXTENSION_NBR(childExtOpTab[i], ExtOp_ParExtOp_Ext)) == 0)
            {
                /* Make copy of extension, because of DBA_DelAndFreeHierEltRec */
                if ((extExecNbr = GET_EXTENSION_NBR(childExtOpTab[i], ExtOp_ExtExecution_Ext))>0)
                {
                    if ((cpyExtExecTab = (DBA_DYNFLD_STP*) CALLOC(extExecNbr, sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                    {
                        memcpy(cpyExtExecTab,
                               GET_EXTENSION_PTR(childExtOpTab[i], ExtOp_ExtExecution_Ext),
                               (extExecNbr * sizeof(DBA_DYNFLD_STP)));
                    }
                    else
                    {
                        FREE(childExtOpTab);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }

                OPE_PurgeOneOrderAndExecutions(hierHead,
										       domainPtr,
										       childExtOpTab[i],
										       cpyExtExecTab,
										       extExecNbr,
                                               true);               /* PMSTA-11733 - 150411 - PMO */
                /* Free of array */
                if (extExecNbr>0)
                    FREE(cpyExtExecTab);
            }
        }

        /* Free of array */
    	FREE(childExtOpTab);
    }

	return(ret);
}

/************************************************************************
*
*  Function    : FIN_FilterIncomeFlows()
*
*  Description : Verify that flows are of nature income
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : PMSTA00485 - CHU - 061013
*
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterIncomeFlows(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (GET_ENUM(dynSt, Flow_NatEn) == FlowNat_Inc)
		return(TRUE);

	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_LoadIncomesForValo()
**
**  Description :   Load dividend operations
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - CHU - 061012
**
*************************************************************************/
RET_CODE FIN_LoadIncomesForValo(DBA_DYNFLD_STP		domainPtr,
								DBA_HIER_HEAD_STP	hierHead,
								DBA_DYNFLD_STP		**incOpTab,
								int					*incOpNbr)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	tmpDomainPtr;
	DATETIME_T      minExDate, maxPayDate, tmpDate;
	FLAG_T			instrLoadedFlg = FALSE;
	DICT_T			listDictId;
	DBA_DYNFLD_STP	*ptfTab   = NULL,
					*instrTab = NULL,
					*flowTab  = NULL;
	int				ptfNbr    = 0,
					instrNbr  = 0,
					flowNbr   = 0;
	int				i, j, applIncomePaymentRange = 0;

	/* Retrieve system parameter for payment date setting */
	GEN_GetApplInfo(ApplIncomePaymentRange, &applIncomePaymentRange);

	if (applIncomePaymentRange < 0)
		applIncomePaymentRange = -applIncomePaymentRange;

	/* Get portfolios needed for the income selection */
	if ((ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE, NULLFCT, NULLFCT,
					                 &ptfNbr, &ptfTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	if (ptfNbr == 0)
		return(ret);

	/* Get instrument flows needed for instrument selection and date computation */
	if ((ret = DBA_ExtractHierEltRec(hierHead, Flow, FALSE, FIN_FilterIncomeFlows, NULLFCT,
                                     &flowNbr, &flowTab)) != RET_SUCCEED)
	{
		FREE(ptfTab);
		return(ret);
	}

	if (flowNbr == 0)
	{
		FREE(ptfTab);
		return(ret);
	}

	DBA_GetDictId(List, &listDictId);
	if ((instrTab = (DBA_DYNFLD_STP *)CALLOC(flowNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* Determine min/max dates */

	/* initialize minimum ex date and max pay date */
	tmpDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);

	maxPayDate.date = tmpDate.date;
	maxPayDate.time = 0;

	minExDate.date = DATE_Move(tmpDate.date, -1 , Day);
	minExDate.time = 0;

	for (i = 0; i < flowNbr; i++)
	{
		/* fill instrument array */
		if (TRUE == IS_NULLFLD(flowTab[i], Flow_InstrId) ||
			GET_ID(flowTab[i], Flow_InstrId) < 0)
		{
			continue;
		}

		if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(flowTab[i], Flow_InstrId), A_Instr,
									  &(instrTab[instrNbr])) == RET_SUCCEED &&
									  instrTab[instrNbr] != NULLDYNST)
		{
			for (j=0; j < instrNbr && instrLoadedFlg == FALSE; j++)
			{
				if (CMP_ID(GET_ID(flowTab[i], Flow_InstrId),
						   GET_ID(instrTab[j], A_Instr_Id))==0)
				{
					instrLoadedFlg = TRUE;
				}
			}

			if (instrLoadedFlg == FALSE)
				instrNbr++;
			else
				instrLoadedFlg = FALSE;

			/* look for earliest ex date */
			if (FALSE == IS_NULLFLD(flowTab[i],Flow_ExDate))
			{
				tmpDate = GET_DATETIME(flowTab[i],Flow_ExDate);
				if (DATE_Cmp(tmpDate.date, minExDate.date) < 0)
					minExDate = tmpDate;
			}

			/* look for latest pay date */
			if (FALSE == IS_NULLFLD(flowTab[i], Flow_OptimalValDate))
			{
				tmpDate = GET_DATETIME(flowTab[i], Flow_OptimalValDate);
				if (DATE_Cmp(tmpDate.date, maxPayDate.date) > 0)
					maxPayDate = tmpDate;
			}
			else
			if (FALSE == IS_NULLFLD(flowTab[i], Flow_OptimalDate))
			{
				tmpDate = GET_DATETIME(flowTab[i], Flow_OptimalDate);
				if (DATE_Cmp(tmpDate.date, maxPayDate.date) > 0)
					maxPayDate = tmpDate;
			}
		}
	}

	/* Apply range to max date */
	maxPayDate.date = DATE_Move(maxPayDate.date, applIncomePaymentRange, Day);

	if (instrNbr > 0)
	{
		/* Create temporary domain for income selection */
		if ((tmpDomainPtr = ALLOC_DYNST(A_Domain)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		COPY_DYNST(tmpDomainPtr, domainPtr, A_Domain);

		/* remove portfolio references : use provided list */
		SET_NULL_DICT(tmpDomainPtr, A_Domain_DimPtfDictId);
		SET_NULL_ID(  tmpDomainPtr, A_Domain_PtfObjId);
		SET_ENUM(     tmpDomainPtr, A_Domain_LoadHierFlg, LoadHierPtf_None);

		/* remove instrument references : use provided list */
		SET_NULL_ID(  tmpDomainPtr, A_Domain_InstrObjId);
        SET_DICT(     tmpDomainPtr, A_Domain_DimInstrDictId, listDictId);

		/* Remove merge */
		SET_ENUM(     tmpDomainPtr, A_Domain_PtfConsRuleEn,  PtfConsRule_Detailed);

		/* Use computed dates */
		SET_DATETIME( tmpDomainPtr, A_Domain_InterpFromDate, minExDate);
		SET_DATETIME( tmpDomainPtr, A_Domain_InterpTillDate, maxPayDate);

		ret = DBA_SelectIncomeOperForValo(tmpDomainPtr,
										  ptfTab,   ptfNbr,
										  instrTab, instrNbr,
										  incOpTab, incOpNbr);
		FREE_DYNST(tmpDomainPtr, A_Domain);
	}

	FREE(ptfTab);
	FREE(instrTab);
	FREE(flowTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ManageIncomesForValo()
**
**  Description :   Manage cash from dividends
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - CHU - 061013
**
*************************************************************************/
RET_CODE FIN_ManageIncomesForValo(DBA_DYNFLD_STP	domainPtr,
								  DBA_HIER_HEAD_STP	hierHead)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	*incOpTab = NULL;
	int				incOpNbr  = 0;

	/* Prepare data */
	/* PMSTA00485 - DDV - 061017 */
    if ((ret = FIN_GenerateIncomeFlows(domainPtr, hierHead)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageIncomesForValo() : Failed to generate income flows");
		return(ret);
	}


	if ((ret = FIN_LoadIncomesForValo(domainPtr, hierHead, &incOpTab, &incOpNbr)) !=RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageIncomesForValo() : Loading of income operations failed");
		return(ret);
	}

	/* Manage cash */
	/* PMSTA00485 - RAK - 061024 */
	if ((ret = FIN_IncomesNewCashPos(domainPtr, hierHead, incOpTab, incOpNbr)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageIncomesForValo() : Creation of cash positions failed");
		return(ret);
	}

	/* PMSTA-36248 - SGO - 290819 */
	if ((ret = FIN_GenerateVoluntaryCAFlows(domainPtr, hierHead)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageIncomesForValo() : Failed to generate voluntary CA flows");
		return(ret);
	}
	if ((ret = FIN_CreateReceivablePos(domainPtr, hierHead)) != RET_SUCCEED)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageIncomesForValo() : Failed to create receivable position");
		return(ret);
	}

	if(incOpNbr > 0)  DBA_FreeDynStTab(incOpTab,incOpNbr,A_Op);
	return(ret);
}

/*****************************************************************************************************
**
**  Function    :   FIN_ExchangeNewPosQty
**
**  Description :   Compute the quantity for cash position.
**                  This function load qantity from previous day of ex-date and
**                  compute the quantity.
**					Code based on FIN_IncomesNewCashPosQty()
**
**  Arguments   :   hierHead   hierarchy header pointer
**
**
**  Return      :   a RET_CODE
**
**  Creation    :  PMSTA-37447 - 091019 - vkumar
**
**  Modif.      :
**
*********************************************************************************************************/
STATIC RET_CODE FIN_ExchangeNewPosQty(DBA_DYNFLD_STP    domainPtr,
                                        DBA_DYNFLD_STP    stock,
                                        DBA_DYNFLD_STP    instrPtr,
                                        DBA_DYNFLD_STP    flowPtr,
                                        double            *qty,
                                        AMOUNT_T          *posAmt,
                                        AMOUNT_T          *posNetAmt)
{
    DATETIME_T          tmpDate;
    DBA_DYNFLD_STP      getArgSt = NULLDYNST, *posTabPrevDay = NULLDYNSTPTR;
    int                 posNbrPrevDay = 0, i;
    ID_T				instrId;
    RET_CODE            ret = RET_SUCCEED;

    *qty = 0.0;

    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (GET_ID(instrPtr, A_Instr_Id) > 0)
    {
        instrId = GET_ID(instrPtr, A_Instr_Id);
    }
    else
    {
        instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
    }

    SET_ID(getArgSt, Get_Arg_InstrId, instrId);

    tmpDate.time = 0;
    tmpDate.date = DATE_Move(GET_DATE(flowPtr, Flow_BegPayDate), -1, Day);
    SET_DATETIME(getArgSt, Get_Arg_DateTime, tmpDate);
    SET_ID(getArgSt, Get_Arg_PtfId, GET_ID(stock, ExtPos_PtfId));
    SET_ID(getArgSt, Get_Arg_PtfPosSetId, GET_ID(domainPtr, A_Domain_PortPosSetId));
    SET_ENUM(getArgSt, Get_Arg_Enum1, GET_ENUM(domainPtr, A_Domain_MinStatEn));
    SET_ENUM(getArgSt, Get_Arg_Enum2, GET_ENUM(domainPtr, A_Domain_MaxStatEn));

    /* REF10793 - DDV - 041202 - use a new proc to load all positions (Primary, Derived and secondary) */
    if ((ret = DBA_Select2(Pos, DBA_ROLE_LOAD_SH_POS, Get_Arg, getArgSt, S_Pos, &posTabPrevDay,
        UNUSED, UNUSED, &posNbrPrevDay, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_ExchangeNewPosQty",
            GET_CODE(instrPtr, A_Instr_Cd), "Positions");
        FREE_DYNST(getArgSt, Get_Arg);
        return(ret);
    }

    FREE_DYNST(getArgSt, Get_Arg);

    /* compute the sum of positions */
    for (i = 0; i < posNbrPrevDay; i++)
    {
        (*qty) += GET_NUMBER(posTabPrevDay[i], S_Pos_Qty);
        (*posAmt) += GET_AMOUNT(posTabPrevDay[i], S_Pos_PosGrossAmt);
        (*posNetAmt) += GET_AMOUNT(posTabPrevDay[i], S_Pos_PosNetAmt);
    }

    if(posNbrPrevDay > 0) { DBA_FreeDynStTab(posTabPrevDay,posNbrPrevDay,S_Pos); }
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateReceivablePos()
**
**  Description :   Create positions for receivable
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-36248 - SGO - 29082019 - Maintain Portfolio Value
**
*************************************************************************/
STATIC RET_CODE FIN_CreateReceivablePos(DBA_DYNFLD_STP		domainPtr,
	DBA_HIER_HEAD_STP    hierHead)
{
	DBA_DYNFLD_STP	 *flowTab = NULLDYNSTPTR , *extPosTab = NULLDYNSTPTR,
		             newReceivablePosStp = NULLDYNST;
	int				 flowNbr = 0, extPosNbr = 0;
	RET_CODE		 ret = RET_SUCCEED;

	NUMBER_T refQty = ZERO_NUMBER, newQty = ZERO_NUMBER,
		     receivableQtyRatio = ZERO_NUMBER, receivableQty = ZERO_NUMBER, posQty = ZERO_NUMBER,
		     newQuote = ZERO_PRICE, newPrice = ZERO_PRICE, newOldGross = ZERO_AMOUNT, newOldNetAmt = ZERO_AMOUNT,
			 newOldPrice = ZERO_NUMBER;

	if ((ret = DBA_ExtractHierEltRec(hierHead, Flow, FALSE,
		                             FIN_FilterFlowsForCA, FIN_CmpFlowInstrDate,
		                             &flowNbr, &flowTab)) != RET_SUCCEED)
	{
		FREE(extPosTab);
		return(ret);
	}

	for (int flowIndex = 0; flowIndex < flowNbr; ++flowIndex)
	{
		if ((ret = DBA_HierEltRecExtract(hierHead, ExtPos, FALSE,
			                             FIN_FilterPosByInstrId,
			                             flowTab[flowIndex], FIN_CmpExtPosPtfInstr,
			                             FALSE, FALSE,
			                             &extPosNbr, &extPosTab)) != RET_SUCCEED)
		{
			return(ret);
		}
		if (extPosNbr > 0)
		{
			/* Create an ExtPos (this will be receivable) on instrument which has a flow */
			if ((newReceivablePosStp = ALLOC_DYNST(ExtPos)) == NULLDYNST)
			{
				FREE(extPosTab);
				FREE(flowTab);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			COPY_DYNST(newReceivablePosStp, extPosTab[0], ExtPos);

			/* Reset extensions from origin position) */
			SET_NULL_ID(newReceivablePosStp, ExtPos_Id);
			SET_NULL_ID(newReceivablePosStp, ExtPos_PosObjId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_BalPosTpId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_AcctExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_AdjustExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_PosValId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_LogicalId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_AccrInterExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_CntPtyExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_InstrExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_AdjustSecExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_Acct2ExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_Acct3ExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_BVAdjProfitExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_BVAdjLossExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_LockingExtPosId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_ExecutionId);
			SET_NULL_ID(newReceivablePosStp, ExtPos_GlobalExecutionFeeId);

			COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_OpDate, flowTab[flowIndex], Flow, Flow_BegPayDate);
			COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_BegDate, flowTab[flowIndex], Flow, Flow_BegPayDate);
			COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_ValDate, flowTab[flowIndex], Flow, Flow_BegPayDate);
			COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_AcctDate, flowTab[flowIndex], Flow, Flow_BegPayDate);
			COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_EndDate, flowTab[flowIndex], Flow, Flow_EndPayDate);

			refQty = GET_NUMBER(flowTab[flowIndex], Flow_RefQty);
			newQty = GET_NUMBER(flowTab[flowIndex], Flow_QtyUnit);

            DBA_DYNFLD_STP instrPtr = DBA_SearchHierRecById(hierHead, A_Instr, A_Instr_Id,
                                                       GET_ID(flowTab[flowIndex], Flow_InstrId));        /* PMSTA - 37447 - 091019 - vkumar */
            NUMBER_T       tmpQty         = ZERO_NUMBER;
            AMOUNT_T       tmpPosGrossAmt = ZERO_AMOUNT;
            AMOUNT_T       tmpPosNetAmt   = ZERO_AMOUNT;
            /* Get quantity of instrument in portfolio (at ex-date minus 1 day) */
            if ((ret = FIN_ExchangeNewPosQty(domainPtr, extPosTab[0],
                instrPtr, flowTab[flowIndex], &tmpQty, &tmpPosGrossAmt, &tmpPosNetAmt)) != RET_SUCCEED)
            {
                FREE(extPosTab);
                FREE(flowTab);
                FREE_DYNST(newReceivablePosStp, ExtPos);
                return(ret);
            }
			FLAG_T allocOk = FALSE;
			AMOUNT_T newPosGrossAmt = ZERO_AMOUNT;
			AMOUNT_T newPosNetAmt   = ZERO_AMOUNT;
			const NUMBER_T divisor  = 100.0;
			DBA_DYNFLD_STP newInstrPtr = nullptr;
			PosLog recPos(newReceivablePosStp);
			PosLog oldRecPos(extPosTab[0]);
			/* set quantity according to the exchange event type */
			switch (GET_ENUM(flowTab[flowIndex], Flow_SubNatEn))
			{
			case FlowSubNat_Bonus:
			case FlowSubNat_SplitExch:
				receivableQtyRatio = FUS_DIV(newQty, refQty);
				receivableQty      = tmpQty * receivableQtyRatio;                                        /* PMSTA - 37447 - 091019 - vkumar */
				break;
			case FlowSubNat_Demerger:
				receivableQtyRatio = FUS_DIV(newQty, refQty);
				receivableQty = tmpQty * receivableQtyRatio;
				newQuote = GET_PRICE(flowTab[flowIndex], Flow_Quote);
				newPosGrossAmt = FUS_DIV(tmpPosGrossAmt * newQuote, divisor);
				newPosNetAmt   = FUS_DIV(tmpPosNetAmt * newQuote, divisor);
				SET_AMOUNT(newReceivablePosStp, ExtPos_PosNetAmt, newPosNetAmt);
				SET_AMOUNT(newReceivablePosStp, ExtPos_PosGrossAmt, newPosGrossAmt);
				SET_AMOUNT(newReceivablePosStp, ExtPos_RefNetAmt, newPosNetAmt);
				SET_AMOUNT(newReceivablePosStp, ExtPos_RefGrossAmt, newPosGrossAmt);
				SET_AMOUNT(newReceivablePosStp, ExtPos_Bp1PosAmt, ZERO_AMOUNT);

				/* PMSTA - 37284 - 200317 - VIG  Change done to reflect 
				Gross Amount Change for instrument after demerger is executed */
				newOldGross = tmpPosGrossAmt - newPosGrossAmt;
				newOldNetAmt = tmpPosNetAmt - newPosNetAmt;
				posQty = GET_NUMBER(extPosTab[0], ExtPos_Qty);   /* PMSTA- 37284 - 110520 - grace */
				newOldPrice = FUS_DIV(newOldGross, posQty);       /*Cost price change for Parent instrument after demerger event */
				SET_NUMBER(extPosTab[0], ExtPos_Quote, newOldPrice);
				SET_NUMBER(extPosTab[0], ExtPos_Price, newOldPrice);
				SET_AMOUNT(extPosTab[0], ExtPos_PosNetAmt, newOldNetAmt);
				SET_AMOUNT(extPosTab[0], ExtPos_PosGrossAmt, newOldGross);
				SET_AMOUNT(extPosTab[0], ExtPos_RefNetAmt, newOldNetAmt);
				SET_AMOUNT(extPosTab[0], ExtPos_RefGrossAmt, newOldGross);
				
				recPos.computeFromReference(KindAmounts::Instrument, KindAmounts::System);

				oldRecPos.computeFromReference(KindAmounts::Instrument, KindAmounts::System);

     			newQuote = FUS_DIV(newPosGrossAmt, receivableQty);
				newPrice = newQuote;
				SET_PRICE(newReceivablePosStp, ExtPos_Quote, newQuote);
				SET_PRICE(newReceivablePosStp, ExtPos_Price, newPrice);
				COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_InstrId, flowTab[flowIndex], Flow, Flow_NewInstrId);

				/* add the new instrument to the heirarchy so that links are created correctly */
				if ((ret = DBA_GetInstrById(GET_ID(flowTab[flowIndex], Flow_NewInstrId), TRUE, &allocOk, &newInstrPtr,
					hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
				{
					MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", Flow_NewInstrId);
					if (allocOk == TRUE && newInstrPtr != nullptr) FREE_DYNST(newInstrPtr, A_Instr);
					return(RET_DBA_ERR_NODATA);
				}
				break;
			case FlowSubNat_Consolidation:
				receivableQtyRatio = refQty - newQty;
				receivableQty      = -(tmpQty * receivableQtyRatio);                                     /* PMSTA - 37447 - 091019 - vkumar */
				receivableQty      = FUS_DIV(receivableQty, refQty);
				break;
			case FlowSubNat_UpfrontPayment:
			case FlowSubNat_DeferredSecurityCredit:
			case FlowSubNat_DeferredSecurityDebit:
			case FlowSubNat_DeferredCashCredit:
			case FlowSubNat_DeferredCashDebit:
				receivableQty = GET_NUMBER(flowTab[flowIndex], Flow_RefQty);
				COPY_DYNFLD(newReceivablePosStp, ExtPos, ExtPos_LinkedInstrId,
					flowTab[flowIndex], Flow, Flow_LinkedInstrId);                       /* PMSTA - 42330 - CHANDRU - 23102020*/
				break;
			}

			/* Quote, price and amounts for the receivalbe pos */
			SET_NUMBER(newReceivablePosStp, ExtPos_Qty, receivableQty);

			if (GET_ENUM(flowTab[flowIndex], Flow_SubNatEn) != FlowSubNat_Demerger)
			{
				SET_PRICE(newReceivablePosStp, ExtPos_Quote, ZERO_PRICE);
				SET_PRICE(newReceivablePosStp, ExtPos_Price, ZERO_PRICE);
				PosLog receivablePos(newReceivablePosStp);
				receivablePos.computeReferenceFromQtyPrice(ZERO_NUMBER, receivablePos.getPrice(), receivablePos.getPosExchRate());
				receivablePos.computeFromReference(KindAmounts::Instrument, KindAmounts::Position, KindAmounts::System);
			}

			SET_ENUM(newReceivablePosStp, ExtPos_PrimaryEn, PosPrimary_Primary);
			SET_ENUM(newReceivablePosStp, ExtPos_PosNatEn, PosNat_ReceivablePos);
			SET_FLAG_FALSE(newReceivablePosStp, ExtPos_MainFlg);
			SET_ENUM(newReceivablePosStp, ExtPos_Fus, OpFusion_Untreated);

			if ((ret = DBA_AddHierRecord(hierHead, newReceivablePosStp, ExtPos,
				FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
			{
				FREE(extPosTab);
				FREE(flowTab);
				FREE_DYNST(newReceivablePosStp, ExtPos);
				return(ret);
			}
		}
	}
	return ret;
}
/************************************************************************
**
**  Function    :   FIN_IncomesNewCashPos()
**
**  Description :   Create cash positions for dividends
**
**  Arguments   :   domainPtr		domain pointer
**                  argHierHead		hierarchy pointer
**					incOpTab		income op table
**					incOpNbr		income op number
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - RAK - 061024
**
**  Last modif. :   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
STATIC RET_CODE FIN_IncomesNewCashPos(DBA_DYNFLD_STP		domainPtr,
									  DBA_HIER_HEAD_STP		hierHead,
									  DBA_DYNFLD_STP		*incOpTab,
									  int					incOpNbr)
{
	DBA_DYNFLD_STP	 *flowTab=NULLDYNSTPTR, *extPosTab=NULLDYNSTPTR, cashInstr=NULLDYNST,
					 newCashPosStp=NULLDYNST, newBalPosStp=NULLDYNST, getData=NULLDYNST,
					 newRevCashPosStp=NULLDYNST, newRevBalPosStp=NULLDYNST,
					 ptfPtr=NULLDYNST, instrPtr=NULLDYNST, listPtr=NULLDYNST;
	ID_T			 sysCurrId = 0, instrId, oldInstrId, oldPtfId;
	NUMBER_T		 qty=0.0;
	EXCHANGE_T		 exch=0.0;
	DATETIME_T		 exDate, begDate, endDate, maxOpDate;
	AMOUNT_T		 amt=0.0, exchAmt=0.0;
	RET_CODE		 ret = RET_SUCCEED;
	int				 i, j, k, flowNbr=0, extPosNbr=0, applIncomePaymentRange=0;
	FLAG_T			 allocPtfFlg=FALSE, freeInstrFlg=FALSE,
					 createCashFlowFlg=FALSE, returnProcessFlg=FALSE, createReverseForReturn=FALSE;
	ID_T			 applDfltIncBpTpId=ZERO_ID;                         /* PMSTA-17133 - 051113 - PMO */
	FUSDATERULE_ENUM fusionDateRule = FusDateRule_None;
	DATE_T			 fusionSwitchDate;
	DATETIME_T		 domFromDate, domTillDate;
	FIELD_IDX_T		 defaultFusionOpDate=A_Op_ValDate;
    CASHFLOWMGT_ENUM cashFlowMgt=CashFlowMgt_None;

	domFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	domTillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	/* Retrieve system parameter for payment date setting */
	GEN_GetApplInfo(ApplIncomePaymentRange, &applIncomePaymentRange);
	/* Get default Income Balance Position Type Id */
	GEN_GetApplInfo(ApplDfltIncBpTpId, &applDfltIncBpTpId);

	FIN_EXCHARG_ST  exchArgSt;
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	memset(&exDate, 0, sizeof(DATETIME_T));
	memset(&begDate, 0, sizeof(DATETIME_T));
	memset(&endDate, 0, sizeof(DATETIME_T));
	memset(&maxOpDate, 0, sizeof(DATETIME_T));

	if ((getData = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
	{
   		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos, FALSE,
									 NULLFCT, FIN_CmpExtPosPtfInstr,
									 &extPosNbr,  &extPosTab)) != RET_SUCCEED)
	{
		FREE_DYNST(getData, Get_Arg);
		return(ret);
	}

	if ((ret = DBA_ExtractHierEltRec(hierHead, Flow, FALSE,
									 NULLFCT, FIN_CmpFlowInstrDate,
									 &flowNbr,  &flowTab)) != RET_SUCCEED)
	{
		FREE_DYNST(getData, Get_Arg);
		FREE(extPosTab);
		return(ret);
	}    

	/* Creation and update of an index on default flag (for extract of default cash account) */
    DBA_NewHierIndex(hierHead, A_Instr, A_Instr_DefaultFlg, NULLFCT, TRUE);

	/* Check if special treatment must be done for return related functions */
	returnProcessFlg = (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return     ||
						GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
						GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage);

    /* PMSTA-47748 - JBC - 22014 reduce number of queries but still use opticache */    
    bool isRunOneTime = false;
    std::map<std::pair<ID_T,ID_T>,std::map<DATE_T,double>> ptfInstrDateQty; // <ptfId,instrId>,<flow date, sumqty>

	/* For each position */
	oldPtfId   = -1;
	oldInstrId = -1;
	j=0; k=0;
	/* PMSTA-48782 - ankita - 16052022 */
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);
	cashFlowMgt = DBA_GetCashFlowMgtEnum(domainPtr, ptfPtr);

	for (i=0; i<extPosNbr; i++)
	{
		/* 1. ---------------------------------------- */
		/* skip already treated position               */
		/* (in fact treat 1 pos by ptf and instrument) */
		instrId = (GET_EXTENSION_PTR(extPosTab[i] , ExtPos_A_Instr_Ext) != NULL &&
			(instrPtr = *(GET_EXTENSION_PTR(extPosTab[i], ExtPos_A_Instr_Ext)))!= NULLDYNST) 
	        ? GET_ID(instrPtr, A_Instr_Id) > 0 ? GET_ID(instrPtr, A_Instr_Id) : GET_ID(instrPtr, A_Instr_ParentInstrId)
            : GET_ID(extPosTab[i] , ExtPos_InstrId);

		if (oldPtfId == GET_ID(extPosTab[i], ExtPos_PtfId) &&
			oldInstrId == instrId && !(applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&
			((cashFlowMgt == CashFlowMgt_Stocks || cashFlowMgt == CashFlowMgt_All) && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock)))
		{
			continue;
        }

		if (oldPtfId == GET_ID(extPosTab[i], ExtPos_PtfId) &&
			oldInstrId == instrId && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&
			((cashFlowMgt == CashFlowMgt_Stocks || cashFlowMgt == CashFlowMgt_All) && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock))
		{
			j = 0;
		}

		/* 2. --------------------------------------------- */
		/* Get system currency (in ptf or system parameter) */
		if (GET_EXTENSION_PTR(extPosTab[i] , ExtPos_A_Ptf_Ext) != NULL &&
			(ptfPtr = *(GET_EXTENSION_PTR(extPosTab[i], ExtPos_A_Ptf_Ext)))!= NULLDYNST)
		{
			if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
			{ sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);}
		}
		else	/* no extension : Use hierarchy or get A_Ptf in db */
		{
			if (IS_NULLFLD(extPosTab[i], ExtPos_PtfId) == FALSE)
			{
				allocPtfFlg = FALSE;
				if ((ret = DBA_GetPtfById(GET_ID(extPosTab[i], ExtPos_PtfId), FALSE, &allocPtfFlg,
										  &ptfPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
				{
					FREE_DYNST(getData, Get_Arg);
					FREE(extPosTab);
					return (ret);
				}

				if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
				{ sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId); }

				if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
			}
		}

        /* DLA - PMSTA04851 - 080314 */        
        if ((cashFlowMgt == CashFlowMgt_All)
            ||
            (cashFlowMgt == CashFlowMgt_Stocks && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock)
            ||
            (cashFlowMgt == CashFlowMgt_FundShares && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare))

        {
		    /* For each portfolio, restart the analyse of flow and incomes */
		    /* and get portfolio fusion date rule and set default operation date field */
		    if (oldPtfId != GET_ID(extPosTab[i], ExtPos_PtfId))
		    {
			    /* reset counters */
			    j = k = 0;

                /* Get fusion date rule */
                if (GET_ENUM(ptfPtr, A_Ptf_FusionDateRuleEn) == (ENUM_T)FusDateRule_None)
                {
				    /* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
				    if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
					    fusionSwitchDate == MAGIC_END_DATE )
				    {
					    GEN_GetApplInfo(ApplFusDateRule, &fusionDateRule);
				    }
				    else
				    {
					    if (DATE_Cmp(domTillDate.date, fusionSwitchDate) < 0)
					    {
						    GEN_GetApplInfo(ApplOldFusionDateRule, &fusionDateRule);
					    }
					    else
					    {
						    GEN_GetApplInfo(ApplFusDateRule, &fusionDateRule);
					    }
				    }
                    GEN_GetApplInfo(ApplFusDateRule, &fusionDateRule);
                }
                else
                {
                    fusionDateRule = (FUSDATERULE_ENUM) GET_ENUM(ptfPtr, A_Ptf_FusionDateRuleEn);
                }

			    switch(fusionDateRule)
			    {
			    case FusDateRule_OpDate :
					    defaultFusionOpDate = A_Op_OpDate;
					    break;

			    case FusDateRule_AcctDate :
					    defaultFusionOpDate = A_Op_AcctDate;
					    break;

			    case FusDateRule_ValDate :
					    defaultFusionOpDate = A_Op_ValDate;
					    break;

			    default :
					    break;
			    }
		    }

		    oldInstrId = instrId;
		    oldPtfId   = GET_ID(extPosTab[i], ExtPos_PtfId);

		    if (sysCurrId == 0)
		    { GEN_GetApplInfo(ApplSysCurrId, &sysCurrId); }

		    /* 3. ------------------- */
		    /* Generate cash position */

		    /* Search generated Flow for current instrument */
			/* PMSTA-36248 - SGO - 290819 - don't create cash pos for CA exchange event */
		    while (j < flowNbr && GET_ID(extPosTab[i], ExtPos_InstrId) >= GET_ID(flowTab[j], Flow_InstrId))
		    {
				if (!FIN_IsCAExchangeEventFlow(static_cast<FLOWSUBNAT_ENUM>(GET_FLAG((flowTab)[j], Flow_SubNatEn))))
				{
					exDate.date = GET_DATE(flowTab[j], Flow_OptimalDate);
					maxOpDate.date = GET_DATE(flowTab[j], Flow_OptimalValDate);
					maxOpDate.date = DATE_Move(maxOpDate.date, applIncomePaymentRange, Day);

					if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && 
						(cashFlowMgt == CashFlowMgt_Stocks || cashFlowMgt == CashFlowMgt_All)
							&& GET_ENUM(extPosTab[i], ExtPos_NatEn) == InstrNat_CashAcct)
							continue;

					/* For each possible income */
					if (GET_ID(extPosTab[i], ExtPos_InstrId) == GET_ID(flowTab[j], Flow_InstrId))
					{
						/* Search paid income for current instrument */
						createCashFlowFlg = TRUE;
						createReverseForReturn = FALSE;
						memset(&endDate, 0, sizeof(DATETIME_T));
						k = 0; /* PMSTA14083 - DDV - 120423 - Reset k to check all income operation for all flows */

						while (k < incOpNbr &&
							GET_ID(extPosTab[i], ExtPos_InstrId) >= GET_ID(incOpTab[k], A_Op_InstrId) &&
							createCashFlowFlg == TRUE)
						{
							/* For each paid income for the instrument verify that it is not paid at valorisation date */
							if (GET_ID(extPosTab[i], ExtPos_InstrId) == GET_ID(incOpTab[k], A_Op_InstrId) &&
								GET_ID(extPosTab[i], ExtPos_PtfId) == GET_ID(incOpTab[k], A_Op_PtfId))
							{
								if (returnProcessFlg == FALSE)
								{
									if (DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
										GET_DATETIME(incOpTab[k], defaultFusionOpDate)) >= 0)
									{
										createCashFlowFlg = FALSE;
									}
								}
								else /* Return */
								{
									/* did we found an income Op related to this Event ? */
									if (DATETIME_CMP(exDate, GET_DATETIME(incOpTab[k], defaultFusionOpDate)) <= 0
										&&
										DATETIME_CMP(maxOpDate, GET_DATETIME(incOpTab[k], defaultFusionOpDate)) >= 0)
									{
										/* Is there a gap between Event and income operation ? */
										if (DATETIME_CMP(exDate, GET_DATETIME(incOpTab[k], defaultFusionOpDate)) == 0)
											createCashFlowFlg = FALSE;
										else
										{
											/* endDate will be the date of the income */
											endDate = GET_DATETIME(incOpTab[k], defaultFusionOpDate);
											createReverseForReturn = TRUE;
										}
									}
								}
							}
							k++;
						}

						/* Create cash position */
						if (createCashFlowFlg == TRUE)
						{
							/* Search currency instrument with reference currency */
							SET_ID(getData, Get_Arg_RefCurrId, GET_ID(flowTab[j], Flow_AmtCurrId));

							if ((ret = DBA_GetDfltCashInstrByCurr(hierHead, getData, TRUE, &freeInstrFlg, &cashInstr)) != RET_SUCCEED)
							{
								if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); } /* perhaps allocated and filled by DBA_CheckInstrDim() */
								if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
								FREE_DYNST(getData, Get_Arg);
								FREE(extPosTab);
								FREE(flowTab);
								return(ret);
							}

							/* Verify that cash is in domain instrument dimension */
							if (DBA_CheckInstrDim(domainPtr, hierHead, GET_ID(cashInstr, A_Instr_Id), cashInstr,
								&listPtr, NULL, FALSE, (DATETIME_STP)NULL, FALSE) == TRUE)
							{
                                /* PMSTA-47748 - JBC - 22014 
                                 *  optimized cache usage */
                                if(flowNbr > 1)
                                {
                                    if(isRunOneTime == false)
                                    {                                        
                                        if((ret = FIN_IncomesNewCashPosTab(domainPtr,extPosTab, extPosNbr,flowTab, flowNbr, ptfInstrDateQty)) != RET_SUCCEED)
                                        {                                        
                                            MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_IncomesNewCashPosTab",GET_CODE(instrPtr, A_Instr_Cd), "Positions");

                                            if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); } /* perhaps allocated and filled by DBA_CheckInstrDim() */
									        FREE_DYNST(newBalPosStp, ExtPos);
									        if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
									        FREE_DYNST(getData, Get_Arg);
									        FREE(extPosTab);
									        FREE(flowTab);
									        return(ret);
                                        }
                                        isRunOneTime = true;
                                    }
                                    /* get qty */
                                    DATETIME_T tmpDate;
                                    tmpDate.time = 0;
                                    tmpDate.date = DATE_Move(GET_DATE(flowTab[j], Flow_OptimalDate), -1, Day);
                                    ID_T keyPtfId = GET_ID(extPosTab[i], ExtPos_PtfId);
                                    ID_T keyInstrId = GET_ID(instrPtr, A_Instr_Id) > 0 ? GET_ID(instrPtr, A_Instr_Id) : GET_ID(instrPtr, A_Instr_ParentInstrId);
                                    std::pair<ID_T,ID_T> ptfInstrKey = std::make_pair(keyPtfId,keyInstrId);
                                    qty = ptfInstrDateQty[ptfInstrKey][tmpDate.date];

                                }
                                else
                                {
								    /* Get quantity of instrument in portfolio (at ex-date minus 1 day) */
								    if ((ret = FIN_IncomesNewCashPosQty(hierHead, domainPtr, extPosTab[i],
										instrPtr, flowTab[j], &qty, applIncludeDivAccrualPos)) != RET_SUCCEED)
								    {
									    if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); } /* perhaps allocated and filled by DBA_CheckInstrDim() */
									    FREE_DYNST(newBalPosStp, ExtPos);
									    if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
									    FREE_DYNST(getData, Get_Arg);
									    FREE(extPosTab);
									    FREE(flowTab);
									    return(ret);
								    }
                                }

								/* Compute amount and qty for cash account */
								amt = qty * GET_PRICE(flowTab[j], Flow_Quote);
								qty = CAST_NUMBER(amt);

								/* PMSTA-48782 - ankita - 16052022 */
								if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos
									&& (cashFlowMgt == CashFlowMgt_Stocks || cashFlowMgt == CashFlowMgt_All))
								{
									SET_ID(extPosTab[i], ExtPos_IncEvtCurrId, GET_ID(cashInstr, A_Instr_RefCurrId));
									SET_AMOUNT(extPosTab[i], ExtPos_AccrAmt, amt);
									SET_DATETIME(extPosTab[i], ExtPos_IncEvtBegDate, exDate);
									if (endDate.date == 0)
									{
										endDate.date = GET_DATE(flowTab[j], Flow_OptimalValDate);
										endDate.date = DATE_Move(endDate.date, applIncomePaymentRange + 1, Day);
									}
									SET_DATETIME(extPosTab[i], ExtPos_IncEvtEndDate, endDate);
								}
								else
								{
                                    /* Add an ExtPos on cash */
								    if ((newCashPosStp = ALLOC_DYNST(ExtPos)) == NULLDYNST)
								    {
									    if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); } /* perhaps allocated and filled by DBA_CheckInstrDim() */
									    FREE_DYNST(getData, Get_Arg);
									    FREE(extPosTab);
									    FREE(flowTab);
									    MSG_RETURN(RET_MEM_ERR_ALLOC);
								    }
									/* Copy all fields ... */
									COPY_DYNST(newCashPosStp, extPosTab[i], ExtPos);

									/* Suppress extension identifier (copied from origin position) */
									SET_NULL_ID(newCashPosStp, ExtPos_Id);
									SET_NULL_ID(newCashPosStp, ExtPos_BalPosTpId);
									SET_NULL_ID(newCashPosStp, ExtPos_AcctExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_AdjustExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_PosValId);
									SET_NULL_ID(newCashPosStp, ExtPos_LogicalId);
									SET_NULL_ID(newCashPosStp, ExtPos_AccrInterExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_CntPtyExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_InstrExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_AdjustSecExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_Acct2ExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_Acct3ExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_BVAdjProfitExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_BVAdjLossExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_LockingExtPosId);
									SET_NULL_ID(newCashPosStp, ExtPos_ExecutionId);
									SET_NULL_ID(newCashPosStp, ExtPos_GlobalExecutionFeeId);

									SET_ENUM(newCashPosStp, ExtPos_OpenOpNatEn, OpNat_Income);         /* WEALTH-4688 - DDV - 240229 - Set open oper nat as income */
									SET_ID(newCashPosStp, ExtPos_InstrId, GET_ID(cashInstr, A_Instr_Id));
									SET_ID(newCashPosStp, ExtPos_InstrCurrId, GET_ID(cashInstr, A_Instr_RefCurrId));
									SET_ID(newCashPosStp, ExtPos_PosCurrId, GET_ID(cashInstr, A_Instr_RefCurrId));
									SET_NULL_ID(newCashPosStp, ExtPos_IncEvtCurrId);

									SET_NULL_AMOUNT(newCashPosStp, ExtPos_AccrAmt);
									SET_AMOUNT(newCashPosStp, ExtPos_InstrGrossAmt, amt);
									SET_AMOUNT(newCashPosStp, ExtPos_InstrNetAmt, amt);
									SET_AMOUNT(newCashPosStp, ExtPos_PosGrossAmt, amt);
									SET_AMOUNT(newCashPosStp, ExtPos_PosNetAmt, amt);
									SET_NUMBER(newCashPosStp, ExtPos_Qty, qty);

									SET_ID(newCashPosStp, ExtPos_MainExtPosId, GET_ID(extPosTab[i], ExtPos_Id));
									SET_ID(newCashPosStp, ExtPos_InitExtPosId, GET_ID(extPosTab[i], ExtPos_Id));

									SET_ID(newCashPosStp, ExtPos_FlowId, GET_ID(flowTab[j], Flow_Id));

									SET_FLAG(newCashPosStp, ExtPos_MainFlg, FALSE);
									SET_FLAG(newCashPosStp, ExtPos_AcctFlg, TRUE);
									SET_ENUM(newCashPosStp, ExtPos_PosNatEn, PosNat_MainAcctPos);

									SET_DATETIME(newCashPosStp, ExtPos_BegDate, exDate);
									SET_DATETIME(newCashPosStp, ExtPos_OpDate, exDate);
									SET_DATETIME(newCashPosStp, ExtPos_AcctDate, exDate);

									/* end date is the date of the income (if exist) or the value date + range */
									if (endDate.date == 0)
									{
										endDate.date = GET_DATE(flowTab[j], Flow_OptimalValDate);
										endDate.date = DATE_Move(endDate.date, applIncomePaymentRange + 1, Day); /* PMSTA14084 - DDV - 120423 - Add one day to allow the position to be open at end_d */
									}
									SET_DATETIME(newCashPosStp, ExtPos_ValDate, GET_DATETIME(flowTab[j], Flow_OptimalDate));
									SET_DATETIME(newCashPosStp, ExtPos_EndDate, endDate);

									/* Not needed anymore (was for return) */
									/* SET_ENUM(newCashPosStp, ExtPos_NatEn, ExtPosNat_Flow); */

									SET_PRICE(newCashPosStp, ExtPos_Price, 1.0);
									SET_PRICE(newCashPosStp, ExtPos_Quote, 1.0);


									/* In reference currency */
									if (GET_ID(newCashPosStp, ExtPos_RefCurrId) == GET_ID(newCashPosStp, ExtPos_PosCurrId))
									{
										SET_AMOUNT(newCashPosStp, ExtPos_RefGrossAmt, GET_AMOUNT(newCashPosStp, ExtPos_PosGrossAmt));
										SET_AMOUNT(newCashPosStp, ExtPos_RefNetAmt, GET_AMOUNT(newCashPosStp, ExtPos_PosNetAmt));
										SET_EXCHANGE(newCashPosStp, ExtPos_PosExchRate, 1.0);
										SET_EXCHANGE(newCashPosStp, ExtPos_InstrExchRate, 1.0);
									}
									else
									{
										exchArgSt.srcAmt = GET_AMOUNT(newCashPosStp, ExtPos_PosNetAmt);
										FIN_ExchAmt(GET_DATETIME(newCashPosStp, ExtPos_BegDate),
											GET_ID(newCashPosStp, ExtPos_PosCurrId),
											GET_ID(newCashPosStp, ExtPos_RefCurrId),
											0, NULLDYNST, newCashPosStp, &exchArgSt,
											(EXCHANGE_T*)NULL, &exchAmt, &exch);		/* PMSTA01649 - TGU - 070405 */
										SET_AMOUNT(newCashPosStp, ExtPos_RefGrossAmt, exchAmt);
										SET_AMOUNT(newCashPosStp, ExtPos_RefNetAmt, exchAmt);
										SET_EXCHANGE(newCashPosStp, ExtPos_PosExchRate, exch);
										SET_EXCHANGE(newCashPosStp, ExtPos_InstrExchRate, exch);
									}

									/* In system currency */
									if (sysCurrId != GET_ID(newCashPosStp, ExtPos_RefCurrId))
									{
										if (sysCurrId != GET_ID(newCashPosStp, ExtPos_PosCurrId))
										{
											/* REF2313 */
											exchArgSt.srcAmt = GET_AMOUNT(newCashPosStp, ExtPos_RefNetAmt);
											FIN_ExchAmt(GET_DATETIME(newCashPosStp, ExtPos_BegDate),
												GET_ID(newCashPosStp, ExtPos_RefCurrId), sysCurrId,
												0, NULLDYNST, newCashPosStp, &exchArgSt,
												(EXCHANGE_T*)NULL, &exchAmt, &exch);	/* PMSTA01649 - TGU - 070405 */
											SET_EXCHANGE(newCashPosStp, ExtPos_SysExchRate, (1 / exch));
										}
										else
										{
											exchAmt = GET_AMOUNT(newCashPosStp, ExtPos_PosNetAmt);
											SET_EXCHANGE(newCashPosStp, ExtPos_SysExchRate,
												GET_EXCHANGE(newCashPosStp, ExtPos_PosExchRate));
										}
									}
									else
									{
										exchAmt = GET_AMOUNT(newCashPosStp, ExtPos_RefNetAmt);
										SET_EXCHANGE(newCashPosStp, ExtPos_SysExchRate, 1.0);
									}

									SET_AMOUNT(newCashPosStp, ExtPos_SysGrossAmt, exchAmt);
									SET_AMOUNT(newCashPosStp, ExtPos_SysNetAmt, exchAmt);

									SET_NULL_PRICE(newCashPosStp, ExtPos_BookPrice);
									SET_NULL_PRICE(newCashPosStp, ExtPos_BookQuote);
									SET_NULL_EXCHANGE(newCashPosStp, ExtPos_BookPosExchRate);
									SET_NULL_EXCHANGE(newCashPosStp, ExtPos_BookInstrExchRate);
									SET_NULL_EXCHANGE(newCashPosStp, ExtPos_BookSysExchRate);
									SET_NULL_AMOUNT(newCashPosStp, ExtPos_BookPosNetAmt);
									SET_NULL_AMOUNT(newCashPosStp, ExtPos_BookInstrNetAmt);
									SET_NULL_AMOUNT(newCashPosStp, ExtPos_BookRefNetAmt);
									SET_NULL_AMOUNT(newCashPosStp, ExtPos_BookSysNetAmt);

									SET_NULL_PRICE(newCashPosStp, ExtPos_SpotPrice);
									SET_NULL_PRICE(newCashPosStp, ExtPos_SpotQuote);

									SET_NULL_NUMBER(newCashPosStp, ExtPos_Rate);
									SET_NULL_AMOUNT(newCashPosStp, ExtPos_SupplAmt);

									SET_AMOUNT(newCashPosStp, ExtPos_Bp1PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp2PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp3PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp4PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp5PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp6PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp7PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp8PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp9PosAmt, 0.0);
									SET_AMOUNT(newCashPosStp, ExtPos_Bp10PosAmt, 0.0);

									if ((ret = DBA_AddHierRecord(hierHead, newCashPosStp, ExtPos,
										FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
									{
										if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); } /* perhaps allocated and filled by DBA_CheckInstrDim() */
										if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
										FREE_DYNST(getData, Get_Arg);
										FREE(extPosTab);
										FREE(flowTab);
										FREE_DYNST(newCashPosStp, ExtPos);
										return(ret);
									}

									/* PMSTA-13795 - DDV - 120430 - To avoid usage of wrong PosVal, set position_id with ExtPos's id just set by hierarchy. And remove PosVal's extension.*/
									SET_ID(newCashPosStp, ExtPos_PosObjId, GET_ID(newCashPosStp, ExtPos_Id));
									SET_NULL_EXTENSION(newCashPosStp, ExtPos_PosVal_Ext);

									if (returnProcessFlg == TRUE)
									{
										/* Add an ExtPos with Balance Position Type */
										if ((newBalPosStp = ALLOC_DYNST(ExtPos)) == NULLDYNST)
										{
											if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
											FREE_DYNST(getData, Get_Arg);
											FREE(extPosTab);
											FREE(flowTab);
											MSG_RETURN(RET_MEM_ERR_ALLOC);
										}

										/* Copy all fields... */
										COPY_DYNST(newBalPosStp, newCashPosStp, ExtPos);
										SET_NULL_ID(newBalPosStp, ExtPos_Id);

										/* Adjust specific position fields */
										SET_ID(newBalPosStp, ExtPos_InstrId, GET_ID(flowTab[j], Flow_InstrId));

										SET_ID(newBalPosStp, ExtPos_BalPosTpId, applDfltIncBpTpId);

										SET_NULL_ID(newBalPosStp, ExtPos_CloseOpId);
										SET_NULL_ID(newBalPosStp, ExtPos_MainExtPosId);
										SET_ID(newBalPosStp, ExtPos_AcctExtPosId, GET_ID(newCashPosStp, ExtPos_Id));
										SET_NULL_CODE(newBalPosStp, ExtPos_CloseOpCd);
										SET_FLAG(newBalPosStp, ExtPos_MainFlg, TRUE);
										SET_ENUM(newBalPosStp, ExtPos_PosNatEn, PosNat_MainPos);

										SET_PRICE(newBalPosStp, ExtPos_Price, GET_PRICE(flowTab[j], Flow_Quote));
										SET_NUMBER(newBalPosStp, ExtPos_Qty,
                                            GET_NUMBER(newCashPosStp, ExtPos_Qty) / GET_PRICE(flowTab[j], Flow_Quote));

										SET_NULL_PRICE(newBalPosStp, ExtPos_Quote);

										SET_PRICE(newBalPosStp, ExtPos_Price, GET_PRICE(newBalPosStp, ExtPos_Price) * -1.0);

										/* Reverse amounts */
										SET_AMOUNT(newBalPosStp, ExtPos_PosGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_PosGrossAmt) * -1.0);
										SET_AMOUNT(newBalPosStp, ExtPos_PosNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_PosNetAmt) * -1.0);

										SET_AMOUNT(newBalPosStp, ExtPos_InstrGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_InstrGrossAmt) * -1.0);
										SET_AMOUNT(newBalPosStp, ExtPos_InstrNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_InstrNetAmt) * -1.0);

										SET_AMOUNT(newBalPosStp, ExtPos_RefGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_RefGrossAmt) * -1.0);
										SET_AMOUNT(newBalPosStp, ExtPos_RefNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_RefNetAmt) * -1.0);

										SET_AMOUNT(newBalPosStp, ExtPos_SysGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_SysGrossAmt) * -1.0);
										SET_AMOUNT(newBalPosStp, ExtPos_SysNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_SysNetAmt) * -1.0);

										if ((ret = DBA_AddHierRecord(hierHead, newBalPosStp, ExtPos,
											FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
										{
											if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
											if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
											FREE_DYNST(getData, Get_Arg);
											FREE(extPosTab);
											FREE(flowTab);
											FREE_DYNST(newBalPosStp, ExtPos);
											return(ret);
										}

										if (createReverseForReturn == TRUE) /* means we found the income operation*/
										{
											/* Add a reverse ExtPos on cash */
											if ((newRevCashPosStp = ALLOC_DYNST(ExtPos)) == NULLDYNST)
											{
												if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
												FREE_DYNST(getData, Get_Arg);
												FREE(extPosTab);
												FREE(flowTab);
												MSG_RETURN(RET_MEM_ERR_ALLOC);
											}

											/* Make a copy of new Cash Position */
											COPY_DYNST(newRevCashPosStp, newCashPosStp, ExtPos);

											SET_NULL_ID(newRevCashPosStp, ExtPos_Id);

											/* Reverse quantity */
											SET_NUMBER(newRevCashPosStp, ExtPos_Qty, GET_NUMBER(newCashPosStp, ExtPos_Qty) * -1.0);

											/* Reverse amounts */
											SET_AMOUNT(newRevCashPosStp, ExtPos_PosGrossAmt, GET_AMOUNT(newCashPosStp, ExtPos_PosGrossAmt) * -1.0);
											SET_AMOUNT(newRevCashPosStp, ExtPos_PosNetAmt, GET_AMOUNT(newCashPosStp, ExtPos_PosNetAmt) * -1.0);

											SET_AMOUNT(newRevCashPosStp, ExtPos_InstrGrossAmt, GET_AMOUNT(newCashPosStp, ExtPos_InstrGrossAmt) * -1.0);
											SET_AMOUNT(newRevCashPosStp, ExtPos_InstrNetAmt, GET_AMOUNT(newCashPosStp, ExtPos_InstrNetAmt) * -1.0);

											SET_AMOUNT(newRevCashPosStp, ExtPos_RefGrossAmt, GET_AMOUNT(newCashPosStp, ExtPos_RefGrossAmt) * -1.0);
											SET_AMOUNT(newRevCashPosStp, ExtPos_RefNetAmt, GET_AMOUNT(newCashPosStp, ExtPos_RefNetAmt) * -1.0);

											SET_AMOUNT(newRevCashPosStp, ExtPos_SysGrossAmt, GET_AMOUNT(newCashPosStp, ExtPos_SysGrossAmt) * -1.0);
											SET_AMOUNT(newRevCashPosStp, ExtPos_SysNetAmt, GET_AMOUNT(newCashPosStp, ExtPos_SysNetAmt) * -1.0);

											begDate = GET_DATETIME(newCashPosStp, ExtPos_EndDate);
											SET_DATETIME(newRevCashPosStp, ExtPos_BegDate, begDate);
											SET_DATETIME(newRevCashPosStp, ExtPos_OpDate, begDate);
											SET_DATETIME(newRevCashPosStp, ExtPos_AcctDate, begDate);
											SET_DATETIME(newRevCashPosStp, ExtPos_ValDate, begDate);
											SET_DATETIME(newRevCashPosStp, ExtPos_EndDate, begDate);

											if ((ret = DBA_AddHierRecord(hierHead, newRevCashPosStp, ExtPos,
												FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
											{
												if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
												if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
												FREE_DYNST(getData, Get_Arg);
												FREE(extPosTab);
												FREE(flowTab);
												FREE_DYNST(newRevCashPosStp, ExtPos);
												return(ret);
											}

											/* Add an ExtPos with Balance Position Type */
											if ((newRevBalPosStp = ALLOC_DYNST(ExtPos)) == NULLDYNST)
											{
												if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
												FREE_DYNST(getData, Get_Arg);
												FREE(extPosTab);
												FREE(flowTab);
												FREE_DYNST(newRevCashPosStp, ExtPos);
												MSG_RETURN(RET_MEM_ERR_ALLOC);
											}

											/* Make a copy of new Balance Position */
											COPY_DYNST(newRevBalPosStp, newBalPosStp, ExtPos);

											SET_NULL_ID(newRevBalPosStp, ExtPos_Id);

											/* Reverse Price */
											SET_PRICE(newRevBalPosStp, ExtPos_Price, GET_PRICE(newBalPosStp, ExtPos_Price) * -1.0);

											/* Reverse amounts */
											SET_AMOUNT(newRevBalPosStp, ExtPos_PosGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_PosGrossAmt) * -1.0);
											SET_AMOUNT(newRevBalPosStp, ExtPos_PosNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_PosNetAmt) * -1.0);

											SET_AMOUNT(newRevBalPosStp, ExtPos_InstrGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_InstrGrossAmt) * -1.0);
											SET_AMOUNT(newRevBalPosStp, ExtPos_InstrNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_InstrNetAmt) * -1.0);

											SET_AMOUNT(newRevBalPosStp, ExtPos_RefGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_RefGrossAmt) * -1.0);
											SET_AMOUNT(newRevBalPosStp, ExtPos_RefNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_RefNetAmt) * -1.0);

											SET_AMOUNT(newRevBalPosStp, ExtPos_SysGrossAmt, GET_AMOUNT(newBalPosStp, ExtPos_SysGrossAmt) * -1.0);
											SET_AMOUNT(newRevBalPosStp, ExtPos_SysNetAmt, GET_AMOUNT(newBalPosStp, ExtPos_SysNetAmt) * -1.0);

											SET_DATETIME(newRevBalPosStp, ExtPos_BegDate, begDate);
											SET_DATETIME(newRevBalPosStp, ExtPos_OpDate, begDate);
											SET_DATETIME(newRevBalPosStp, ExtPos_AcctDate, begDate);
											SET_DATETIME(newRevBalPosStp, ExtPos_ValDate, begDate);
											SET_DATETIME(newRevBalPosStp, ExtPos_EndDate, begDate);

											if ((ret = DBA_AddHierRecord(hierHead, newRevBalPosStp, ExtPos,
												FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
											{
												if (listPtr != NULL) { FREE_DYNST(listPtr, A_List); }
												if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
												FREE_DYNST(getData, Get_Arg);
												FREE(extPosTab);
												FREE(flowTab);
												FREE_DYNST(newRevBalPosStp, ExtPos);
												return(ret);
											}

											/*  Not sure (not done for newCashPosStp)... :-S
											SET_ID(newRevCashPosStp, ExtPos_MainExtPosId, GET_ID(newRevBalPosStp, ExtPos_Id));
											*/
											SET_ID(newRevBalPosStp, ExtPos_AcctExtPosId, GET_ID(newRevCashPosStp, ExtPos_Id));

										}
									}
								}
							}
							if (freeInstrFlg == TRUE) { FREE_DYNST(cashInstr, A_Instr); }
						}
					}
				}
			    j++;
		    }
        }
	}

	if (listPtr != NULL) { FREE_DYNST(listPtr, A_List);} /* perhaps allocated and filled by DBA_CheckInstrDim() */
	FREE_DYNST(getData, Get_Arg);
	FREE(extPosTab);
	FREE(flowTab);
	return(ret);
}


/*****************************************************************************************************
**
**  Function    :   FIN_IncomesNewCashPosQty
**
**  Description :   Compute the quantity for cash position.
**                  This function load qantity from previous day of ex-date and
**                  compute the quantity.
**					Code based on FIN_ComputeIncomeQty()
**
**  Arguments   :   hierHead   hierarchy header pointer
**
**
**  Return      :   a RET_CODE
**
**  Creation    :   PMSTA00485 - RAK - 061121
**
**  Modif.      :
**
*********************************************************************************************************/
STATIC RET_CODE FIN_IncomesNewCashPosQty(DBA_HIER_HEAD_STP hierHead,
										 DBA_DYNFLD_STP    domainPtr,
										 DBA_DYNFLD_STP    stock,
										 DBA_DYNFLD_STP    instrPtr,
										 DBA_DYNFLD_STP    flowPtr,
										 double            *qty,
                                         AppIncDivAccrualPos applIncludeDivAccrualPos)
{
    DATETIME_T          tmpDate;
    MemoryPool          mp;
    DBA_DYNFLD_STP      getArgSt = mp.allocDynst(FILEINFO,Get_Arg);
    DBA_DYNFLD_STP *    posTabPrevDay=NULLDYNSTPTR;
    int                 posNbrPrevDay = 0, i;
	ID_T				instrId = GET_ID(instrPtr, A_Instr_Id) > 0 ? GET_ID(instrPtr, A_Instr_Id) : GET_ID(instrPtr, A_Instr_ParentInstrId);
    RET_CODE            ret=RET_SUCCEED;
    
    *qty = 0.0;

    SET_ID(getArgSt, Get_Arg_InstrId, instrId);

    tmpDate.time = 0;
    tmpDate.date = DATE_Move(GET_DATE(flowPtr, Flow_OptimalDate), -1, Day);
    SET_DATETIME(getArgSt, Get_Arg_DateTime,      tmpDate);
    SET_ID(getArgSt,       Get_Arg_PtfId,         GET_ID(stock, ExtPos_PtfId));
    SET_ID(getArgSt,       Get_Arg_PtfPosSetId,   GET_ID(domainPtr, A_Domain_PortPosSetId));
    SET_ENUM(getArgSt,     Get_Arg_Enum1,         GET_ENUM(domainPtr, A_Domain_MinStatEn));
    SET_ENUM(getArgSt,     Get_Arg_Enum2,         GET_ENUM(domainPtr, A_Domain_MaxStatEn));

    /* REF10793 - DDV - 041202 - use a new proc to load all positions (Primary, Derived and secondary) */
	if ((ret = DBA_Select2(Pos, DBA_ROLE_LOAD_SH_POS, Get_Arg, getArgSt, S_Pos, &posTabPrevDay,
                           UNUSED, UNUSED, &posNbrPrevDay, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_IncomesNewCashPosQty",
                GET_CODE(instrPtr, A_Instr_Cd), "Positions");
        FREE_DYNST(getArgSt, Get_Arg);
		return(ret);
    }

    /* compute the sum of positions */
    for (i=0; i<posNbrPrevDay; i++)
    {
		if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock
			&& CMP_DYNFLD(posTabPrevDay[i], stock, S_Pos_OpenOpCd, ExtPos_OpenOpCd, CodeType) == 0)
		{
			(*qty) = GET_NUMBER(posTabPrevDay[i], S_Pos_Qty);
			break;
		}
		(*qty) += GET_NUMBER(posTabPrevDay[i], S_Pos_Qty);
	}

	if(posNbrPrevDay > 0) { DBA_FreeDynStTab(posTabPrevDay,posNbrPrevDay,S_Pos); }
	return(ret);
}

/*****************************************************************************************************
**
**  Function    :   FIN_IncomesNewCashPosTab
**
**  Description :   Bulk collect fuction for position data to be used to calc Income New Cash Qty
**                  Built to improve performance, to many calls to sel_sh_pos_by_pid_iid_dt
**                  Created new proc sel_sh_pos_by_pid_dt
**
**  Arguments   :   
**
**  Return      :   a RET_CODE
**
**  Creation    :  
**
**  Modif.      :
**
*********************************************************************************************************/
STATIC RET_CODE FIN_IncomesNewCashPosTab(DBA_DYNFLD_STP domainPtr,DBA_DYNFLD_STP * extPosTab, int extPosNbr, DBA_DYNFLD_STP * flowTab, int flowNbr, 
    std::map<std::pair<ID_T,ID_T>,std::map<DATE_T,double>> & ptfInstrDateQty)   // <ptfId,instrId>,<flow date, sumqty>
{    
    RET_CODE                                ret = RET_SUCCEED;    
    DBA_DYNFLD_STP *                        sPosPrevDayTab = nullptr;
    int                                     sPosPrevDayNb =  0;    
    DATETIME_T minDate;
    DATETIME_T maxDate;    
    minDate.date =   MAGIC_END_DATE;
    minDate.time = 0;
    maxDate.date = 0;
    maxDate.time = 0;   
    std::set<ID_T>             ptfSet;
    bool flowDatesDone = false;
    ptfInstrDateQty.clear(); // will be empty
     /* get all ptf ids*/
    for (int i=0; i<extPosNbr; i++)
	{
        ID_T ptfId = GET_ID(extPosTab[i], ExtPos_PtfId);
        if(ptfSet.count(ptfId) == 0)
        {
            ptfSet.insert(ptfId);
        }
        // flow is ordered by instr/date
        for (int j=0; j<flowNbr; j++)
	    {    
            ID_T instrId = GET_ID(flowTab[j],Flow_InstrId);
            std::pair<ID_T, ID_T> ptfInstrKey = std::make_pair(ptfId,instrId);
            DATETIME_T tmpDate;
            tmpDate.time = 0;
            tmpDate.date =  DATE_Move(GET_DATE(flowTab[j], Flow_OptimalDate),-1,Day);
            // track all flow dates
            ptfInstrDateQty[ptfInstrKey][tmpDate.date] = 0.0;

            if(flowDatesDone == false)
            {
                 if(DATETIME_CMP(tmpDate,minDate) < 0) { minDate = tmpDate; }
                 if(DATETIME_CMP(tmpDate,maxDate) > 0) { maxDate = tmpDate; }
            }
        }
        // only check on first loop
        flowDatesDone = true;
    }
    
    MemoryPool      mp;
    DBA_DYNFLD_STP  getArg = mp.allocDynst(FILEINFO,Get_Arg);    
    ID_T            ppsId = IS_NULLFLD(domainPtr, A_Domain_PortPosSetId) ? ZERO_ID : GET_ID(domainPtr, A_Domain_PortPosSetId);

    /* sel sh pos for each portfolio  - all instruments in date range */
    for(auto it = ptfSet.begin(); it != ptfSet.end();++it)
    {                        
        SET_ID(getArg, Get_Arg_PtfId, *it);
        SET_ID(getArg, Get_Arg_PtfPosSetId, ppsId);
        SET_NULL_ID(getArg, Get_Arg_InstrId);
        SET_DATETIME(getArg, Get_Arg_DateTime, minDate);
        SET_DATETIME(getArg, Get_Arg_DateTime2, maxDate);
        SET_ENUM(getArg, Get_Arg_Enum1, GET_ENUM(domainPtr, A_Domain_MinStatEn));
        SET_ENUM(getArg, Get_Arg_Enum2, GET_ENUM(domainPtr, A_Domain_MaxStatEn));
    
	    if ((ret = DBA_Select2(Pos, DBA_ROLE_LOAD_SH_POS, Get_Arg, getArg, 
                    S_Pos, &sPosPrevDayTab, UNUSED, UNUSED, &sPosPrevDayNb, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            DBA_FreeDynStTab(sPosPrevDayTab,sPosPrevDayNb,S_Pos);
		    return(ret);
        }
        // sum quantities for ptf/instr/date
        if(sPosPrevDayNb > 0)
        {
            for(int i=0;i<sPosPrevDayNb;i++)
            {               
                ID_T instrId = GET_ID(sPosPrevDayTab[i],S_Pos_InstrId);
                std::pair<ID_T, ID_T> ptfInstrKey = std::make_pair(*it,instrId);
                std::map<DATE_T,double> & dateSumQty = ptfInstrDateQty[ptfInstrKey];
                for(auto it2 = dateSumQty.begin();it2 != dateSumQty.end();++it2)
                {
                    DATETIME_T tmpDate;
                    tmpDate.time = 0;
                    tmpDate.date = it2->first;
                    if(DATETIME_CMP(GET_DATETIME(sPosPrevDayTab[i],S_Pos_BegDate),tmpDate) <= 0
                        && DATETIME_CMP(GET_DATETIME(sPosPrevDayTab[i],S_Pos_EndDate),tmpDate) > 0)
                    {
                        it2->second +=  GET_NUMBER(sPosPrevDayTab[i], S_Pos_Qty);
                    }
                }
            }            
        }
        DBA_FreeDynStTab(sPosPrevDayTab,sPosPrevDayNb,S_Pos);
    }
	return(ret);
}
/************************************************************************
**
**  Function    :   FIN_CmpExtPosPtfInstr()
**
**  Description :   Sort flow by instrument
**
**  Arguments   :   domainPtr		domain pointer
**                  argHierHead		hierarchy pointer
**					incOpTab		income op table
**					incOpNbr		income op number
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - RAK - 061030
**
*************************************************************************/
STATIC int FIN_CmpExtPosPtfInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	if (CMP_ID(GET_ID((*ptr1), ExtPos_PtfId),
			   GET_ID((*ptr2), ExtPos_PtfId)) == 0)
	{
		DBA_DYNFLD_STP	instr1Ptr=NULLDYNST, instr2Ptr=NULLDYNST;
		ID_T			instr1Id, instr2Id;

		if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL &&
			(instr1Ptr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext)))!= NULLDYNST)
		{
			if (GET_ID(instr1Ptr, A_Instr_Id) > 0)
			{instr1Id = GET_ID(instr1Ptr, A_Instr_Id);}
			else
			{instr1Id = GET_ID(instr1Ptr, A_Instr_ParentInstrId);}
		}
		else
			instr1Id = GET_ID((*ptr1), ExtPos_InstrId);

		if (GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext) != NULL &&
			(instr2Ptr = *(GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext)))!= NULLDYNST)
		{
			if (GET_ID(instr2Ptr, A_Instr_Id) > 0)
			{instr2Id = GET_ID(instr2Ptr, A_Instr_Id);}
			else
			{instr2Id = GET_ID(instr2Ptr, A_Instr_ParentInstrId);}
		}
		else
			instr2Id = GET_ID((*ptr2), ExtPos_InstrId);

		return (CMP_ID(instr1Id, instr2Id));
	}
	else
	{
		return (CMP_ID(GET_ID((*ptr1), ExtPos_PtfId),
					   GET_ID((*ptr2), ExtPos_PtfId)));
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpFlowInstrDate()
**
**  Description :   Sort flow by instrument, date
**
**  Arguments   :   domainPtr		domain pointer
**                  argHierHead		hierarchy pointer
**					incOpTab		income op table
**					incOpNbr		income op number
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - RAK - 061030
**
*************************************************************************/
STATIC int FIN_CmpFlowInstrDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

	if (CMP_ID(GET_ID((*ptr1), Flow_InstrId) , GET_ID((*ptr2), Flow_InstrId)) == 0)
	{
		return(DATETIME_CMP(GET_DATETIME((*ptr1), Flow_BegPayDate),
		                    GET_DATETIME((*ptr2), Flow_BegPayDate)));
	}
	else
	{
		return (CMP_ID(GET_ID((*ptr1), Flow_InstrId) ,
			           GET_ID((*ptr2), Flow_InstrId)));
	}
}


/************************************************************************
**
**  Function    :   FIN_ManageFutureCashFlows()
**
**  Description :   Manage future cash flows
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - CHU - 061013 (Manage Incomes only for the time being)
**
**  Modif.      :   PMSTA-36248 - SGO - 29082019 - Maintain Portfolio Value
**
*************************************************************************/
RET_CODE FIN_ManageFutureCashFlows(DBA_DYNFLD_STP	 domainPtr,
								   DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE			ret      = RET_SUCCEED;

	if ((GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo		 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_MultiValo	 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return	 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo)
		 &&
         (DBA_GetCashFlowMgtEnum(domainPtr,NULL) != CashFlowMgt_None || /* DLA - PMSTA04851 - 080318 */
		  GET_FLAG(domainPtr, A_Domain_ZeroQtyFlg) == TRUE) ||			/* DLA - PMSTA04851 - 080409 (GET_ENUM -> GET_FLAG) */
		  GET_FLAG(domainPtr, A_Domain_LoadReceivFlg) == TRUE)          /* PMSTA - 42330 - CHANDRU - 23102020*/
	{
		/* Manage cash from incomes */
		if ((ret = FIN_ManageIncomesForValo(domainPtr, hierHead)) != RET_SUCCEED)
		{
			MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_ManageFutureCashFlows() : income management failed");
			return(ret);
		}

		/* Manage cash from other origins - for future use */
		/*ret = FIN_ManageWhateverForValo(domainPtr, hierHead); */

		/* PMSTA05219 - 080812 - RAK */
		/* Move the call to  DBA_CheckQuantity() into a new DBA_CheckPositions() */
		/* and call it after the FIN_ManageFutureCashFlows() */
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpExtPosAcct()
**
**  Description :   Sort extended position to have account position at the end
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA04141 - DDV - 071003
**  Modif       :
*************************************************************************/
STATIC int FIN_CmpExtPosAcct(const void *ptr1, const void *ptr2, const void *inputRefCurrIdPtr)
{
    DBA_DYNFLD_STP pos1, pos2;
	ID_T           refCurrId;

	pos1 = (DBA_DYNFLD_STP) (*((DBA_DYNFLD_STP *) (ptr1)));
	pos2 = (DBA_DYNFLD_STP) (*((DBA_DYNFLD_STP *) (ptr2)));
	refCurrId = (ID_T) (*((ID_T *) (inputRefCurrIdPtr)));

	if (GET_ENUM(pos1, ExtPos_PosNatEn) == PosNat_MainAcctPos ||
	    GET_ENUM(pos1, ExtPos_PosNatEn) == PosNat_Acct2Pos ||
	    GET_ENUM(pos1, ExtPos_PosNatEn) == PosNat_Acct3Pos)
	{
		if (GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_MainAcctPos ||
		    GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_Acct2Pos ||
			GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_Acct3Pos)
		{
			if (GET_ID(pos1, ExtPos_InstrCurrId) == refCurrId)
			{
				if (GET_ID(pos2, ExtPos_InstrCurrId) == refCurrId)
				{
					return(0);
				}
				else
				{
					return(1);
				}
			}

			if (GET_ID(pos2, ExtPos_InstrCurrId) == refCurrId)
			{
				return(-1);
			}
			else
			{
				return(0);
			}
		}
		else
		{
			return(1);
		}
	}
	else
	{
		if (GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_MainAcctPos ||
		    GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_Acct2Pos ||
			GET_ENUM(pos2, ExtPos_PosNatEn) == PosNat_Acct3Pos)
		{
			return(-1);
		}
		else
		{
			return(0);
		}
	}
}

/************************************************************************
**
**  Function    :   FIN_ManageSession()
**
**  Description :   Verify IC + Split + Group + Publish current order session
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30897 - CHU - 180503
**
*************************************************************************/
RET_CODE FIN_ManageSession(DBA_DYNFLD_STP    domainPtr,
                           DBA_HIER_HEAD_STP stratHierHead)
{
    DBA_DYNFLD_STP          getDomainPtr    = NULL;
    RET_CODE                ret             = RET_SUCCEED;
    RET_CODE                specialRetCode  = RET_SUCCEED;
    DBA_DYNFLD_STP			draftFctResPtr  = NULL;
    EXTOP_ACTION_ENUM		actionEn        = Action_SaveOp;
    int                     j = 0;
    DBA_DYNFLD_STP          *caseMgtTab   = NULL, *caseMgtICTab   = NULL, *extOpTab = NULL;
    int                     caseMgtNbr    = 0, caseMgtICNbr    = 0, extOpNbr = 0;
   	FLAG_T					blockCriticalnessFlg=FALSE;
	int						sumBlockingCaseNbr=0;
    EVTGEN_ENUM				defEvtGenEn = EvtGen_EventOp;
    EVTGEN_ENUM             savedEvtGenNatEn = (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn);
    SESSION_EXCEPTION_HANDLING_ENUM applSessionExceptionHandling;
    DbiConnectionHelper     dbiConnHelper;
    DICT_FCT_STP            dictFctInfo;
    DICT_T                  fctDictId; /* PMSTA-31795 - CHU - 180614 */
    bool                    splitSessionFlag = false;
    bool                    errorOccuredFlag = false;
    bool                    groupOrdersFlag  = false;

    int                     outputBlkNb     = 10 ;
    const DBA_DYNST_ENUM    *outputStLst[]  = { &ExtOp,
                                                //&A_ConstraintBreach,
                                                &A_CaseManagement,
                                                &ExtStratLnk,
                                                &ExtStratElt,
                                                &A_Ptf,				    /* PMSTA10463-PRS-110222 */
											    &A_ApplComment,		    /* PMSTA11318-CHU-110202 */
											    &A_RiskESElt,		    /* PMSTA-18426 - CHU - 141203 */
											    &A_RiskESEltCompo,	    /* PMSTA-18426 - CHU - 141203 */
											    &A_LombardCheck,	    /* PMSTA-21462 - CHU - 151013 */
											    &A_DomainPtfCompo,      /* PMSTA-21529 - CHU - 151021 */
												&A_TaxLot,              /* PMSTA-34295 - sanand - 060319 */
												&A_TaxLotInitial };     /* PMSTA-34295 - sanand - 060319 */

    DBA_DYNFLD_STP          *data[]         = { NULLDYNSTPTR,
                                                NULLDYNSTPTR,
                                                NULLDYNSTPTR,
                                                NULLDYNSTPTR,
                                                NULLDYNSTPTR,
                                                NULLDYNSTPTR,
												NULLDYNSTPTR,	/* PMSTA-18426 - CHU - 141203 */
												NULLDYNSTPTR,	/* PMSTA-18426 - CHU - 141203 */
												NULLDYNSTPTR,	/* PMSTA-21462 - CHU - 151013 */
												NULLDYNSTPTR,	/* PMSTA-21529 - CHU - 151021 */
												NULLDYNSTPTR,   /* PMSTA-34295 - sanand - 060319 */
												NULLDYNSTPTR }; /* PMSTA-34295 - sanand - 060319 */


    int                     rows[]          = { 0,0,0,0,0,0,0,0,0,0,0,0 }; /* PMSTA-34295 - sanand - 060319 */

	int			connectNo = NO_VALUE;
	int			selOptions = DBA_SET_CONN | DBA_NO_CLOSE;

    if (dbiConnHelper.isValidAndInit() == false) /* PMSTA-26888 - CHU - 170629 */
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }
	
	connectNo = dbiConnHelper.getId();

    /* < PMSTA-31795 - CHU - 180614 : ensure input function_dict_id is kept while updating or creating new domains */
    fctDictId       = (DICT_T)GET_DICT(domainPtr, A_Domain_FctDictId);

    if (IS_NULLFLD(domainPtr, A_Domain_RpcFctDictId) == FALSE)
    {
        SET_DICT(domainPtr, A_Domain_FctDictId,        (DICT_T)GET_DICT(domainPtr, A_Domain_RpcFctDictId));
    }
    /* > PMSTA-31795 - CHU - 180614 */

    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);

	/* PMSTA-45624 - JPR - 210922 - Rebalancing (especially PCK_GL_BATCH_SESSIONMANAGEMENT) is taking time at TAP end */
	DBA_SetTascJobPtfDim(domainPtr, &connectNo);

	if (GET_FLAG(domainPtr, A_Domain_TSLPtfDimModifiedFlg) == TRUE)
	{
		DICT_T          entDictId;
		DBA_DYNFLD_STP  tascJobSt = NULL; /* PMSTA08246 - LJE - 090624 */
		DBA_GetDictId(Ptf, &entDictId);

		if ((ret = DBA_CreateTempTables(&connectNo, DOM_POSITION_INSTR_PORT)) != RET_SUCCEED)
		{
			return(ret);
		}

		/* PMSTA08246 - LJE - 090615 */
		if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef) == TRUE &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
		{
			if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL)
			{
				if (DBA_Get2(TascJob,
					UNUSED,
					A_Domain,
					domainPtr,
					A_TascJob,
					&tascJobSt,
					selOptions,
					&connectNo,
					UNUSED) == RET_SUCCEED &&
					tascJobSt != NULL &&
					IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
				{
					DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

					if (argument != NULL)
					{
						SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
						if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
							SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

						SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

						if ((ret = DBA_Notif2(TascJob,
							UNUSED,
							Arg_Test,
							argument,
							selOptions,
							&connectNo,
							UNUSED)) != RET_SUCCEED)
						{
							FREE_DYNST(argument, Arg_Test);
							FREE_DYNST(tascJobSt, A_TascJob);
							DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
							return(ret);
						}

						FREE_DYNST(argument, Arg_Test);
					}
				}
				FREE_DYNST(tascJobSt, A_TascJob);
			}
		}
	}

    /***    Load Session    ***/
	/* PMSTA-30891 - RAK - 180430 - Use S_Domain and keep empty instrument and portfolio dimensions */
	if ((getDomainPtr = ALLOC_DYNST(S_Domain)) != NULL)
	{
        GEN_GetApplInfo(ApplSessionExceptionHandling, &applSessionExceptionHandling);
        if (applSessionExceptionHandling >= SessionExceptionHandling_Last)
	    {
		    applSessionExceptionHandling = SessionExceptionHandling_UniqueSession;
	    }

		SET_ID(getDomainPtr, S_Domain_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));

		if (GET_FLAG(domainPtr, A_Domain_TSLPtfDimModifiedFlg) == FALSE)
		{
			SET_FLAG(getDomainPtr, S_Domain_ExtStratEltNatAllocFlg, FALSE);	/* Load portfolio(s) ext strategy elt */
			SET_FLAG(getDomainPtr, S_Domain_InitDimFlg, FALSE);			    /* PMSTA-30891 - RAK - 180504 - use this flag for @init_dim_f" */
		}
		
		DBA_RestorePtfDim(domainPtr);

        if ((ret = DBA_MultiSelect2(EOp,
                                    DBA_ROLE_FCT_RESULT,
                                    S_Domain,
                                    getDomainPtr,
                                    outputStLst,
                                    data,
									selOptions, UNUSED,
                                    rows,
									&connectNo)) == RET_SUCCEED)
        {
            splitSessionFlag = (((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckAndPublish &&
			                    applSessionExceptionHandling == SessionExceptionHandling_SplitSession)
                                ||
                                (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish
                                || (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish);

            groupOrdersFlag = (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_ManageSession && /* PMSTA-31795 - CHU - 180614 */
                                IS_NULLFLD(domainPtr, A_Domain_OrderGroupingFctDictId) == FALSE &&
                                GET_ENUM(domainPtr, A_Domain_GenGlobalOrderEn) == (ENUM_T)DomGenGlobalOrder_Yes &&
                                IS_NULLFLD(domainPtr, A_Domain_BookPtfId) == FALSE);

            /* Load initial domain to check if initial FctDict is Rebalancing ! */
            /* if yes --> isRebalancingfct = true; */

            /* Store in hierarchy */
            for (int i = 0; i < outputBlkNb; i++)
            {
                if (*(outputStLst[i]) == ExtOp)
                {
                    /* PMSTA08783 - RAK - 091020 */
                    /* so won't be NULL (not inserted by the hierarchy tools) and script will work */
                    /* but it's not a clean solution : on cache seulement la merde au chat :):):):)*/
                    /* see attached doc in JIRA for the Tech Analysis of a deeper cleaner solution */
                    for (j = 0; j < rows[i]; j++)
                    {
                        SET_ID(data[i][j], ExtOp_Id, GET_ID(data[i][j], ExtOp_OpId));
                        if (IS_NULLFLD(data[i][j], ExtOp_InSessionFlg) == TRUE || GET_FLAG(data[i][j], ExtOp_InSessionFlg) == FALSE) /* PMSTA-24244 - CHU - 161101 */
                        {
                            SET_FLAG_TRUE(data[i][j], ExtOp_InSessionFlg);
                        }
                    }
                }
                DBA_AddHierRecordList(stratHierHead, data[i], rows[i], *(outputStLst[i]), TRUE);
                FREE(data[i]);
            }

            DBA_NewHierIndex(stratHierHead, ExtStratElt, ExtStratElt_ExtStratLnkId, NULLFCT, TRUE);
            DBA_NewHierIndex(stratHierHead, ExtStratLnk, ExtStratLnk_Id, NULLFCT, TRUE);
            DBA_SetHierLnkUsed(stratHierHead, ExtStratLnk, ExtStratLnk_ExtStratElt_Ext);
            DBA_SetHierLnkUsed(stratHierHead, ExtStratElt, ExtStratElt_LnkPar_ExtStratElt_Ext);
            DBA_SetHierLnkUsed(stratHierHead, ExtStratElt, ExtStratElt_OrdPar_ExtStratElt_Ext);
            DBA_SetHierLnkUsed(stratHierHead, ExtOp, ExtOp_ParExtOp_Ext);
            DBA_SetHierLnkUsed(stratHierHead, ExtOp, ExtOp_ChildExtOp_Ext);

            DBA_MakeAllRecLinks(stratHierHead, ExtOp);
            DBA_MakeLinks(stratHierHead);

            ret = DBA_ExtractHierEltRec(stratHierHead,
                                        ExtOp,
                                        FALSE, NULLFCT, NULLFCT,
                                        &extOpNbr, &extOpTab);

            /***    Execute Input control to get messages   ***/
            if ((ret = FIN_GenerateCasesOnMessages(stratHierHead,
                                                   extOpTab, extOpNbr,
                                                   domainPtr,
                                                   &caseMgtICTab, &caseMgtICNbr,
                                                   NULL)) == RET_SUCCEED)
            {
                /* Work in transaction */
                dbiConnHelper.beginTransaction();
                /***    Delete case management with nature input control    ***/
                if ((ret = DBA_TabulaRasa(GET_ID(domainPtr, A_Domain_FctResultId),
                                            CaseManagementNat_InputCtrl,
                                            &connectNo)) == RET_SUCCEED)
                {
                    if ((ret = FIN_SaveCaseManagement(&caseMgtICTab, &caseMgtICNbr,
                                                      extOpTab, extOpNbr,
                                                      &connectNo)) == RET_SUCCEED)
                    {
                        dbiConnHelper.endTransaction(true); /*  commit  */
                        /* DBA_AddHierRecordList(stratHierHead, caseMgtICTab, caseMgtICNbr, A_CaseManagement, TRUE); */ /* PMSTA-31673 - CHU - 180606 : already done by FIN_GenerateCasesOnMessages() */
                    }
                    else
                    {
                        FREE(caseMgtICTab);
                        dbiConnHelper.endTransaction(false); /* Rollback */
                        errorOccuredFlag = true;
                    }
                }
                else
                {
                    FREE(caseMgtICTab);
                    dbiConnHelper.endTransaction(false); /* Rollback */
                    errorOccuredFlag = true;
                }
            }
            else
            {
                FREE(caseMgtICTab);
                errorOccuredFlag = true;
            }

		    /* Generate draft session with rejected orders - extOpTab and caseMgtTab may be updated */
		    if (false == errorOccuredFlag && splitSessionFlag == true)
		    {
                ret = DBA_ExtractHierEltRec(stratHierHead, A_CaseManagement,
                                            FALSE, NULLFCT, NULLFCT,
                                            &caseMgtNbr, &caseMgtTab);

                dbiConnHelper.beginTransaction();


			    if ((ret=DBA_NewSplitSession(&extOpTab, &extOpNbr,
										     DBA_NO_ERROR,
										     domainPtr,
										     &caseMgtTab, &caseMgtNbr,
										     &draftFctResPtr,
                                             &connectNo,
                                             (PTR)stratHierHead)) != RET_SUCCEED)
			    {
				    /* PMSTA-14006-CHU-120402 : Special retcode to keep session in Checked status */
				    if (ret == RET_DBA_ERR_KRANOTFOUND)
				    {
					    specialRetCode = RET_DBA_ERR_KRANOTFOUND;
                        SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_Failed);
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [Session Splitting] No new session created for all portfolios (%2)",
                                       NameType, dictFctInfo->name, IntType, extOpNbr);
						/* PMSTA-31765 CHU - 180613 - no technical error, close transaction */
                        ret = RET_SUCCEED;
                        dbiConnHelper.endTransaction(true); /* Commit */
				    }
				    else
				    {
                        dbiConnHelper.endTransaction(false); /* Rollback */
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [Session Splitting] Error occurred (%2)",
                                   NameType, dictFctInfo->name, IntType, extOpNbr);
				    }
                    errorOccuredFlag = true;
			    }
                else
                {
                    FIN_CleanHierAfterCheckAndPublish(domainPtr, stratHierHead);
                    dbiConnHelper.endTransaction(true); /* Commit */
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [Session Splitting] Saved operations for all portfolios (%2)",
                                   NameType, dictFctInfo->name, IntType, extOpNbr);
                }
		    }

            if (false == errorOccuredFlag && true == groupOrdersFlag)
            {
                DBA_ExtractHierEltRec(stratHierHead, A_CaseManagement,
                                      FALSE, NULLFCT, NULLFCT,
                                      &caseMgtNbr, &caseMgtTab);

                DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);

                if ((ret = FIN_ExecuteOrderGrouping(domainPtr, stratHierHead,
                                                    GET_DICT(domainPtr, A_Domain_OrderGroupingFctDictId), /* PMSTA-31804 - CHU - 180618 */
                                                    dictFctInfo,
                                                    caseMgtTab, caseMgtNbr,
                                                    actionEn /* Action_SaveDraft */, /* PMSTA-31804 - CHU - 180618 */
                                                    splitSessionFlag)) == RET_SUCCEED && extOpNbr > 0) /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
                {
                    DBA_SetHierLnkUsed(stratHierHead, ExtOp, ExtOp_ChildExtOp_Ext);
                    DBA_SetHierLnkUsed(stratHierHead, ExtOp, ExtOp_ParExtOp_Ext);

                    DBA_MakeSpecRecLinks(stratHierHead, ExtOp, ExtOp_ChildExtOp_Ext);
                    DBA_MakeSpecRecLinks(stratHierHead, ExtOp, ExtOp_ParExtOp_Ext);
                }

                if (ret == RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [OrderGrouping] Saved operations for all portfolios (%2)",
                        NameType, dictFctInfo->name, IntType, extOpNbr);

                    /* < PMSTA-31804 - CHU - 180618 */
                    if (actionEn == Action_SaveOp)
                    {
                        if ((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) != EvtGen_CheckCaseSplitAndPublish)
                        {
                            SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_Final);
                        }
                    }
                    else
                    {
                        SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_CheckedSession);
                    }
                    SET_ENUM(domainPtr, A_Domain_EvtGenNatEn, savedEvtGenNatEn);
                    DBA_Update2(Domain, UNUSED, A_Domain, domainPtr, UNUSED, UNUSED, UNUSED);

                    if (false == splitSessionFlag)
                    {
                        DBA_UpdatePtfLastRebalancingInfo(domainPtr, stratHierHead, dbiConnHelper);
                    }
                    /* > PMSTA-31804 - CHU - 180618 */
                }
                else
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [OrderGrouping] Problem while saving operations for all portfolios (%2)",
                        NameType, dictFctInfo->name, IntType, extOpNbr);
                    errorOccuredFlag = true;
                }
            }

            if (false == errorOccuredFlag &&
                false == groupOrdersFlag &&
                extOpNbr != 0) /* PMSTA-31780 - CHU - 18-06-13 If OrderGrouping was executed, no need to recall DBA_FamilyOrder()*/
            {
                DBA_HierRebuildAllIndex(stratHierHead, ExtOp);

                blockCriticalnessFlg = FALSE;
                sumBlockingCaseNbr = 0;

                if (false == splitSessionFlag)
                {
                    FREE(caseMgtTab);
                    DBA_ExtractHierEltRec(stratHierHead, A_CaseManagement,
                                          FALSE, NULLFCT, NULLFCT,
                                          &caseMgtNbr, &caseMgtTab);

                    if (caseMgtNbr > 0)
                    {
                        ret = FIN_VerifyBlockSession(domainPtr, stratHierHead, TRUE, caseMgtTab, caseMgtNbr,
                                                     actionEn, &blockCriticalnessFlg, &sumBlockingCaseNbr);
                    }

                    DBA_ExtractHierEltRec(stratHierHead, ExtOp,
                                          FALSE, NULLFCT, NULLFCT,
                                          &extOpNbr, &extOpTab);

                    if (extOpNbr > 0)
                    {
                        ret = FIN_VerifyBlockSessionNonCMC(domainPtr, stratHierHead, extOpTab, extOpNbr,
                                                           actionEn, &blockCriticalnessFlg, &sumBlockingCaseNbr);
                    }
                }
                SET_INT(domainPtr, A_Domain_CaseToClarify, sumBlockingCaseNbr);

                /*
                if (true == splitSessionFlag ||
                    (FALSE == blockCriticalnessFlg && FALSE == GET_FLAG(domainPtr, A_Domain_SessionInErrorFlg)))
                {
                */
                    if (TRUE == blockCriticalnessFlg || TRUE == GET_FLAG(domainPtr, A_Domain_SessionInErrorFlg))
                        actionEn = Action_SaveDraft;

                    ret = DBA_FamilyOrder(actionEn,
                                          extOpTab, extOpNbr,
                                          0, NULL, NULL,
                                          DBA_NO_ERROR, dbiConnHelper,
                                          GET_DICT(domainPtr, A_Domain_FctDictId),
                                          domainPtr,
                                          caseMgtTab, caseMgtNbr,
                                          NULLDYNSTPTR,
                                          (PTR)stratHierHead,
                                          splitSessionFlag);

                    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);
                    if ((ret == RET_SUCCEED) && (dbiConnHelper.emptyMsg()))
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [Publish] Saved operations for all portfolios (%2)",
                            NameType, dictFctInfo->name, IntType, extOpNbr);
                    }
                    else
                    {
                        SET_ENUM(domainPtr, A_Domain_EvtGenNatEn, defEvtGenEn); /* Do not set session status to Final */

                        /* PMSTA-14006-CHU-120402 : all portfolios have cases, session should stay in Checked status */
                        if (ret == RET_DBA_ERR_KRANOTFOUND)
                        {
                            /* PMSTA-30897 - CHU - 180504 : may not occur if splitting was not done above */
                            SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_Failed);
                            ret = RET_SUCCEED;
                        }
                        else
                        {
                            errorOccuredFlag = true;
                            MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : [Publish] Errors while saving operations for all portfolios",
                                NameType, dictFctInfo->name);

                            dbiConnHelper.sendAllMsgFromMA();
                        }
                    }

                    if (false == errorOccuredFlag)
                    {
                        if (actionEn == Action_SaveOp)
                        {
                            if ((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) != EvtGen_CheckCaseSplitAndPublish)
                            {
                                SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_Final);
                            }
                        }
                        else
                        {
                            SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_CheckedSession);
                        }
                        SET_ENUM(domainPtr, A_Domain_EvtGenNatEn, savedEvtGenNatEn);
                        DBA_Update2(Domain, UNUSED, A_Domain, domainPtr, UNUSED, UNUSED, UNUSED);

                        /* > PMSTA-31804 - CHU - 180618 */
                        if (false == splitSessionFlag)
                        {
                            DBA_UpdatePtfLastRebalancingInfo(domainPtr, stratHierHead, dbiConnHelper);
                        }
                        /* > PMSTA-31804 - CHU - 180618 */
                    }
              /* } */
            }
        }
        FREE(extOpTab);
        FREE_DYNST(getDomainPtr, S_Domain);
    }
    else
    {
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
	}

    /* < PMSTA-31795 - CHU - 180614 : reset fctdictid's ? */
    /* not sure :)
    if (IS_NULLFLD(domainPtr, A_Domain_RpcFctDictId) == FALSE)
    {
        SET_DICT(domainPtr, A_Domain_FctDictId,        fctDictId);
    }
    */
    /* > PMSTA-31795 - CHU - 180614 */


    /* PMSTA-31765 CHU - 180613 - no technical error
    if (true == errorOccuredFlag)
        ret = RET_GEN_ERR_INVARG;
    */

    return (ret);
}

/************************************************************************
**
**  Function    :   getRidOfThisInstrument()
**
**  Description :   Check Instrument nature to know if it can be sold
**
**  Arguments   :   instrPtr       instrument structure pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30894 - CHU - 180712
**
*************************************************************************/
STATIC bool getRidOfThisInstrument(DBA_DYNFLD_STP instrPtr)
{
    INSTRNAT_ENUM   instrNatEn = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);

    switch (instrNatEn)
    {
    case InstrNat_CashAcct:
        return false;

    default:
    /*
    case InstrNat_Stock:
    case InstrNat_Bond:
    case InstrNat_FundShare:
    case InstrNat_Option:
    case InstrNat_MoneyMkt:
    case InstrNat_Future:
    case InstrNat_Forward:
    case InstrNat_Idx:
    case InstrNat_Rate:
    case InstrNat_Swap:
    case InstrNat_Discount:
    case InstrNat_Commodities:
    case InstrNat_YieldCurve:
    case InstrNat_Deliverables:
    case InstrNat_Debt:
    case InstrNat_Other:
    case InstrNat_CumOption:
    case InstrNat_ConvertBond:
    case InstrNat_FRA:
    case InstrNat_ForexSwaps:
    case InstrNat_ExoticOptions:
    case InstrNat_SwapOptions:
    case InstrNat_MortBackSecu:
    case InstrNat_FlowInstr:
    case InstrNat_NotionalInstr:
    */
        return true;
    }
}

/************************************************************************
*
*   Function      :   FIN_FilterExtPosCrtPtf()
*
*   Description   :   Return only extended position of current ptf
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   19.03.97 - RAK - Ref.: DVP339
*************************************************************************/
int FIN_FilterExtPosCrtPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP crtPtfSt) /* REF7264 - LJE - 020205 */
{
	if (CMP_ID(GET_ID(dynSt, ExtPos_PtfId), GET_ID(crtPtfSt, 0)) == 0)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterExtPosBPType()
*
*   Description   :   Return only extended position with BalPos Type Id
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA00542-CHU-070122
*************************************************************************/
int FIN_FilterExtPosBPType(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
	if (IS_NULLFLD(dynSt, ExtPos_BalPosTpId) == FALSE)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_InvalidateStrategies()
**
**  Description :   Invalidate Strategy objectes and Update last_rebalancing_d & last_rebalancing_status attributes of portfolios
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30897 - CHU - 180504
**
*************************************************************************/
RET_CODE DBA_InvalidateStrategies(DBA_DYNFLD_STP    ptfPtr)
{
    RET_CODE ret = RET_SUCCEED;
	DBA_DYNFLD_STP		admArgPtr   = NULLDYNST;
    DbiConnectionHelper dbiConnHelper;

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (dbiConnHelper.isInTransaction() == false)
    {
        dbiConnHelper.beginTransaction();
    }

    if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) != NULL)
    {
        SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(ptfPtr, A_Ptf_Id));
        if ((ret = DBA_Update2(StratLnk,
                                UNUSED,
                                Adm_Arg,
                                admArgPtr,
                                DBA_SET_CONN | DBA_NO_CLOSE,
                                &dbiConnHelper.getId())) != RET_SUCCEED)
        {
            dbiConnHelper.endTransaction(false); /* Rollback */
        }

        dbiConnHelper.endTransaction(true); /* Commit */
    }
    FREE_DYNST(admArgPtr, Adm_Arg);

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateExtOpForPayout()
**
**  Description :   Create Payout Order
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-32694 - CHU - 180905
**
*************************************************************************/
DBA_DYNFLD_STP FIN_CreateExtOpForPayout(DBA_DYNFLD_STP      ptfPtr,
                                        OPNAT_ENUM          extOpNature,
                                        DBA_DYNFLD_STP      extPosPtr,
                                        DBA_HIER_HEAD_STP   hierHead,
                                        DBA_DYNFLD_STP      domainPtr,
                                        DBA_DYNFLD_STP      ptfPayOutPtr)
{
    RET_CODE                        ret;
    ID_T		                    instrId;
	DBA_DYNFLD_STP                  instrPtr, extOpPtr = NULL, initExtOpPtr;
    FLAG_T                          allocFlg, *pflag, *pflag2;

    instrId = GET_ID(extPosPtr, ExtPos_InstrId);

    if (instrId < (ID_T)0)
    {
        return(extOpPtr);
    }

    if ((ret = DBA_GetInstrById(instrId, TRUE, &allocFlg, &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        return(extOpPtr);
    }

    pflag2 = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
    extOpPtr = OPE_ExtPosToExtOp(extOpNature, extPosPtr, pflag2, instrId, true);
    FREE(pflag2);

    pflag = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
    memset(pflag, 0, GET_FLD_NBR(ExtOp) * sizeof(FLAG_T));

    pflag[ExtOp_NatureEn] = TRUE;

    SET_ID(extOpPtr, ExtOp_PtfId, GET_ID(ptfPtr, A_Ptf_Id));
    pflag[ExtOp_PtfId] = TRUE;

    /* For partial withdrawal, the cash account should be provided by DV, let's hope... */
    if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutPtr, A_WithdrawalRequest_NatEn) != WithdrawalRequestNaEn_PartialWithdrawal)
    {
        SET_ID(extOpPtr, ExtOp_InstrId, instrId);
        pflag[ExtOp_InstrId] = TRUE;
    }

	SET_NULL_DATETIME(extOpPtr, ExtOp_BeginDate);
	SET_NULL_CODE(extOpPtr, ExtOp_Cd);
	SET_NULL_DATETIME(extOpPtr, ExtOp_EndDate);
	SET_NULL_DATETIME(extOpPtr, ExtOp_LastModifDate);
	SET_NULL_DATETIME(extOpPtr, ExtOp_AudModifDate);
	SET_NULL_DATETIME(extOpPtr, ExtOp_ValueDate);

    SET_ENUM(extOpPtr, ExtOp_CheckStratEn, CheckStrat_None);
    pflag[ExtOp_CheckStratEn] = TRUE;

    /*PMSTA-36476-NRAO-Allow DVs to evaluate*/
    /*SET_DATETIME(extOpPtr, ExtOp_AcctDate,
        GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
    pflag[ExtOp_AcctDate] = TRUE;

    SET_DATETIME(extOpPtr, ExtOp_OpDate,
        GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
    pflag[ExtOp_OpDate] = TRUE; */

    SET_FLAG(extOpPtr, ExtOp_ConfirmedFlg, TRUE);
    pflag[ExtOp_ConfirmedFlg] = TRUE;

    SET_ID(extOpPtr, ExtOp_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));
    pflag[ExtOp_FctResultId] = TRUE;

    if (IS_NULLFLD(extOpPtr, ExtOp_InSessionFlg) == TRUE ||
        GET_FLAG(extOpPtr, ExtOp_InSessionFlg) == FALSE)
    {
        SET_FLAG_TRUE(extOpPtr, ExtOp_InSessionFlg);
    }

    SET_ENUM(extOpPtr, ExtOp_OrderInclusionEn, OrderInclusionEn_Included);
    pflag[ExtOp_OrderInclusionEn] = TRUE;

    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
    pflag[ExtOp_DbStatusEn] = TRUE;

    SET_ENUM(extOpPtr, ExtOp_CheckParentEn, CheckParent_Disable);
    pflag[ExtOp_CheckParentEn] = TRUE;

    if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutPtr, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_PartialWithdrawal)
    {
        SET_NUMBER(extOpPtr, ExtOp_Qty, (NUMBER_T)GET_AMOUNT(ptfPayOutPtr, A_WithdrawalRequest_WithdrawalAmount));
    }
    pflag[ExtOp_Qty] = TRUE; /* PMSTA-33048 - CHU - 180925 */

    if (extOpNature == OpNat_Withdr)
    {
        COPY_DYNFLD(extOpPtr, ExtOp, ExtOp_CounterpartAccount, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_CounterpartAccount);
        pflag[ExtOp_CounterpartAccount] = TRUE;

        COPY_DYNFLD(extOpPtr, ExtOp, ExtOp_CounterpartCurrencyId, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_CounterpartCcyId);
        pflag[ExtOp_CounterpartCurrencyId] = TRUE;

        /* PMSTA-39702 - Op curr should be cash acct curr when there are
		more than one cash acct */
		if (NULLDYNSTPTR != instrPtr)
		{
			SET_ID(extOpPtr, ExtOp_OpCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
			pflag[ExtOp_OpCurrId] = TRUE;
		}
    }

    /* < PMSTA-34596 - CHU - 190410 */
    if (extOpNature == OpNat_PtfTransf)
    {
        COPY_DYNFLD(extOpPtr, ExtOp, ExtOp_AdjPtfId, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_CounterpartPtfId);
        pflag[ExtOp_OpCurrId] = TRUE;
    }
    /* > PMSTA-34596 - CHU - 190410 */

    SET_ENUM(extOpPtr, ExtOp_ParOpNatEn, ParOpNat_None);
    pflag[ExtOp_ParOpNatEn] = TRUE;

    /*  Already filled fields must not be changed */
    /*
    for (int k = 0; k < GET_FLD_NBR(ExtOp); k++)
    {
        if (IS_NULLFLD(extOpPtr, k) == FALSE)
        {
            pflag[k] = EvalAttr_All;
        }
    }
    */

    SCPT_ComputeScreenDV(EOp,
                         (DICT_T)GET_DICT(domainPtr, A_Domain_InitialFctDictId),
                         pflag,
                         NULL,
                         extOpPtr,
                         NULL,
                         domainPtr,
                         NULLDYNST,
                         TRUE,             /*  Evaluate all data  */
                         TRUE,              /*  No filter evaluation                    */
                         EvalType_DefValAndFilter,
                         0,
                         (int*) NULL,
                         NULL,
                         hierHead,
                         0,
                         DictScreen,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         TRUE,
                         0);

    if (IS_NULLFLD(extOpPtr, ExtOp_OrderNatEn) == TRUE)
    {
        SET_ENUM(extOpPtr, ExtOp_OrderNatEn, OpOrderNat_Mkt);
    }

    if (IS_NULLFLD(extOpPtr, ExtOp_StatusEn) == TRUE) /* Default here is OrderInitStatusMethod_UseDefVal */
    {
        if (IS_NULLFLD(domainPtr, A_Domain_OrderStatusEn) == FALSE)
        {
            SET_ENUM(extOpPtr, ExtOp_StatusEn, GET_ENUM(domainPtr, A_Domain_OrderStatusEn));
        }
    }

    /*PMSTA-36239 -NRAO -16062019*/
    if ((extOpNature == OpNat_PtfTransf) &&
        ((IS_NULLFLD(extOpPtr, ExtOp_AdjNatEn) == TRUE) || static_cast<OPADJUSTNAT_ENUM>GET_ENUM(extOpPtr, ExtOp_AdjNatEn) == OpAdjustNat_None))
    {
        SET_ENUM(extOpPtr, ExtOp_AdjNatEn, OpAdjustNat_MarketPrice);
    }

    /* Initialize NULL attributes with meta-dictionary defaults */
    if ((initExtOpPtr = ALLOC_DYNST(ExtOp)) != NULL)
    {
        SET_ENUM(initExtOpPtr, ExtOp_NatureEn, extOpNature);
        DBA_SetDfltEntityFld(EOp, ExtOp, initExtOpPtr);
        for (int k = 0; k < GET_FLD_NBR(ExtOp); k++)
        {
            if (IS_NULLFLD(initExtOpPtr, k) == FALSE &&
                IS_NULLFLD(extOpPtr, k) == TRUE)
            {
                COPY_DYNFLD(extOpPtr, ExtOp, k, initExtOpPtr, ExtOp, k);
            }
        }
        FREE_DYNST(initExtOpPtr, ExtOp)
    }

    FREE(pflag);
    return(extOpPtr);
}

/************************************************************************
**
**  Function    :   FIN_SelPtfPayoutRequest()
**
**  Description :   Manage Payout Orders (Sell or Withdrawal)
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30894 - CHU - 180711
**
*************************************************************************/
RET_CODE FIN_SelPtfPayoutRequest(DBA_DYNFLD_STP     domainPtr,
                                 DBA_HIER_HEAD_STP  hierHead,
                                 DBA_DYNFLD_STP     ptfPtr,
                                 DBA_DYNFLD_STP     **ptfPayOutTab,
                                 int                *ptfPayOutNbr)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      inPayoutRequestPtr;
    MemoryPool          mp;

    /* Get withdrawal_request record for current portfolio */
    if ((inPayoutRequestPtr =  ALLOC_DYNST(A_WithdrawalRequest)) == NULL)
    {
        ret = RET_MEM_ERR_ALLOC;
        return(ret);
    }

    SET_ID(inPayoutRequestPtr,       A_WithdrawalRequest_PtfId,               GET_ID(ptfPtr, A_Ptf_Id));
    SET_ID(inPayoutRequestPtr,       A_WithdrawalRequest_WithdrawalSessionId, GET_ID(domainPtr, A_Domain_FctResultId));

    ret = DBA_Select2(WithdrawalRequest, DBA_ROLE_MGMT_PAYOUT,
                           A_WithdrawalRequest, inPayoutRequestPtr,
                           A_WithdrawalRequest, ptfPayOutTab,
                           UNUSED, UNUSED,
                           ptfPayOutNbr,
                           UNUSED);
    if (*ptfPayOutNbr == 0)
    {
        ret = RET_SUCCEED;
    }

    FREE_DYNST(inPayoutRequestPtr, A_WithdrawalRequest);
    return (ret);
}

#if 0
RET_CODE FIN_InsertFakeWithdrRequest(DBA_DYNFLD_STP                    aFakeWR,
                                      WITHDRAWAL_REQUEST_NATURE_ENUM    fakeNature,
                                      DBA_DYNFLD_STP                    domainPtr,
                                      DBA_DYNFLD_STP                    ptfPtr,
                                      AMOUNT_T                          fakeAmount)
{
    DBA_ERRMSG_INFOS_ST msgStruct;
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      aCurr = NULL;
    FLAG_T              freeFlag = TRUE;

    SET_ID(aFakeWR, A_WithdrawalRequest_PtfId, GET_ID(ptfPtr, A_Ptf_Id));
    SET_ENUM(aFakeWR, A_WithdrawalRequest_NatEn, fakeNature);
    SET_DATETIME(aFakeWR, A_WithdrawalRequest_BeginDate,  GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
    SET_ID(aFakeWR, A_WithdrawalRequest_WithdrawalSessionId, GET_ID(domainPtr, A_Domain_FctResultId));
    SET_ENUM(aFakeWR, A_WithdrawalRequest_StatusEn, WithdrawalRequestStatusEn_PendingWaitingCashTransfer);
    SET_ENUM(aFakeWR, A_WithdrawalRequest_FailureReasonEn, WithdrawalRequestFailureReasonEn_None);

    ret = DBA_GetCurrById((ID_T)1, &aCurr, &freeFlag);

    if (fakeNature == WithdrawalRequestNaEn_PartialWithdrawal)
    {
        SET_AMOUNT(aFakeWR, A_WithdrawalRequest_WithdrawalAmount, fakeAmount);
        SET_ID(aFakeWR, A_WithdrawalRequest_WithdrawalCurrId, GET_ID(aCurr, A_Curr_Id));
    }
    else
    {
        SET_NULL_NOTE(aFakeWR, A_WithdrawalRequest_CounterpartAccount);
    }

    if (TRUE == freeFlag)
    {
        FREE_DYNST(aCurr, A_Curr);
    }


    ret = DBA_Insert2(WithdrawalRequest, UNUSED,
                      A_WithdrawalRequest, aFakeWR,
                      UNUSED, UNUSED, &msgStruct);
    return(ret);
}
#endif


/************************************************************************
**
**  Function    :   FIN_CreateInvestExtOp()
**
**  Description :   Create Payout Order
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-45637 Autocash Vishnu 23122020
**
*************************************************************************/
DBA_DYNFLD_STP *  FIN_CreateInvestExtOp(DBA_DYNFLD_STP      ptfPtr,
                                OPNAT_ENUM          extOpNature,
                                DBA_HIER_HEAD_STP   hierHead,
                                DBA_DYNFLD_STP      domainPtr,
                                DBA_DYNFLD_STP      ptfPayOutPtr,
                                DBA_DYNFLD_STP   *   mainExtOpTab,
                                int              *   mainExtOpNbr)
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP extOp = NULL,newWithDrOp=NULL;
    MemoryPool mp;

    if (ptfPayOutPtr == NULL)
        return NULL;

    DbiConnection*	dbiConn;
    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        return(NULL);
    }

    DbiConnectionHelper dbiConnHelper(dbiConn, false);


    DBA_DYNFLD_STP inExtOp= mp.allocDynst(FILEINFO, ExtOp);

    if (inExtOp == NULL )
    {
        return(NULL);
    }

    DBA_DYNFLD_STP           *extorderTab = NULLDYNSTPTR;
    int extorderNbr = 0;


    COPY_DYNFLD(inExtOp, ExtOp, ExtOp_PtfId, ptfPtr, A_Ptf, A_Ptf_Id);
    COPY_DYNFLD(inExtOp, ExtOp, ExtOp_CashPlanId, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_PlanDefinitionId);
    COPY_DYNFLD(inExtOp, ExtOp, ExtOp_OpDate, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_BeginDate);

    /*Get the ext_order for the withdrwal order created in external postion status for the cash plan*/
    ret = dbiConnHelper.dbaSelect(ExtOrder, UNUSED , inExtOp, ExtOp,&extorderTab, &extorderNbr);

    mp.ownerDynStpTab(extorderTab, extorderNbr);        /* PMSTA-49815 - KKM - 18082022 */

    if (ret != RET_SUCCEED || 0 == extorderNbr )
        return NULL;

    
    FLAG_T *pflag;

    pflag = (FLAG_T *)mp.calloc(GET_FLD_NBR(ExtOp), sizeof(FLAG_T));


    ID_T instrId = GET_ID(extorderTab[0], ExtOp_InstrId);

    if (NULL == (extOp = ALLOC_DYNST(ExtOp)))
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
        return NULL;
    }

    if (NULL == (newWithDrOp = ALLOC_DYNST(ExtOp)))
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
        return NULL;
    }

    OPSTAT_ENUM     accountingStatus;

    if (PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptfPtr, A_Ptf_NatEn)))
    {
        GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);
    }
    else
    {
        GEN_GetApplInfo(ApplOrderStatus, &accountingStatus);
    }


    /*Create the new withdrwal opertaion*/
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_PtfId, extorderTab[0], ExtOp, ExtOp_PtfId);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_NatureEn, extorderTab[0], ExtOp, ExtOp_NatureEn);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_InstrId, extorderTab[0], ExtOp, ExtOp_InstrId);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_AcctId, extorderTab[0], ExtOp, ExtOp_AcctId);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_CounterpartCurrencyId, extorderTab[0], ExtOp, ExtOp_CounterpartCurrencyId);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_OpCurrId, extorderTab[0], ExtOp, ExtOp_OpCurrId);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_Qty, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_WithdrawalAmount);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_CheckStratEn, extorderTab[0], ExtOp, ExtOp_CheckStratEn);
    COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_CounterpartAccount, extorderTab[0], ExtOp, ExtOp_CounterpartAccount);


    SET_ENUM(newWithDrOp, ExtOp_CheckStratEn, CheckStrat_None);
    pflag[ExtOp_CheckStratEn] = TRUE;

    SET_FLAG(newWithDrOp, ExtOp_ConfirmedFlg, TRUE);
    pflag[ExtOp_ConfirmedFlg] = TRUE;

    SET_ID(newWithDrOp, ExtOp_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));
    pflag[ExtOp_FctResultId] = TRUE;

    SET_ENUM(newWithDrOp, ExtOp_OrderInclusionEn, OrderInclusionEn_Included);
    pflag[ExtOp_OrderInclusionEn] = TRUE;

    SET_ENUM(newWithDrOp, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
    pflag[ExtOp_DbStatusEn] = TRUE;

    SET_ENUM(newWithDrOp, ExtOp_CheckParentEn, CheckParent_Disable);
    pflag[ExtOp_CheckParentEn] = TRUE;

    pflag[ExtOp_Qty] = TRUE;

    SET_ENUM(newWithDrOp, ExtOp_ParOpNatEn, ParOpNat_None);
    pflag[ExtOp_ParOpNatEn] = TRUE;

    pflag[ExtOp_CashPlanId] = TRUE;

    pflag[ExtOp_NatureEn] = TRUE;
    pflag[ExtOp_PtfId] = TRUE;
    pflag[ExtOp_InstrId] = TRUE;
    pflag[ExtOp_StatusEn] = TRUE;
    pflag[ExtOp_CashPtfId] = TRUE;
    pflag[ExtOp_AcctId] = TRUE;
    pflag[ExtOp_Qty] = TRUE;
    pflag[ExtOp_ExtStratEltId] = TRUE;

    pflag[ExtOp_InstrId] = TRUE;

    if (PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptfPtr, A_Ptf_NatEn)))
    {
        /*Dont set for cash plan id for non sleeve portfoli orders order will not be created as accounted and will effect final order status
          check calling of DBA_createWithDrReqForCashPlan ---> dbalib03.c*/
        COPY_DYNFLD(newWithDrOp, ExtOp, ExtOp_CashPlanId, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_PlanDefinitionId);
    }

    SET_ENUM(newWithDrOp, ExtOp_StatusEn, accountingStatus);

    SCPT_ComputeScreenDV(EOp,
        (DICT_T)GET_DICT(domainPtr, A_Domain_InitialFctDictId),
        pflag,
        NULL,
        newWithDrOp,
        NULL,
        domainPtr,
        NULLDYNST,
        TRUE,             /*  Evaluate all data  */
        TRUE,              /*  No filter evaluation                    */
        EvalType_DefValAndFilter,
        0,
        (int*)NULL,
        NULL,
        hierHead,
        0,
        DictScreen,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NullEntity,
        FALSE,
        TRUE,
        0);

    /*start invest operation*/
    if (PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptfPtr, A_Ptf_NatEn)))
    {
        SET_ID(extOp, ExtOp_InstrId, instrId);
        SET_ID(extOp, ExtOp_AcctId, instrId);

        if (IS_NULLFLD(ptfPayOutPtr, A_WithdrawalRequest_CounterpartAccount) == FALSE)
        {
            char *uString = NULL;
            int iSizeBuffer = 0;

            iSizeBuffer = 2 * u_strlen(GET_USTRING(ptfPayOutPtr, A_WithdrawalRequest_CounterpartAccount)) + 1;
            uString = (char*)CALLOC(iSizeBuffer, sizeof(char));


            ICU4AAA_ConvertToASCII(GET_UNOTE(ptfPayOutPtr, A_WithdrawalRequest_CounterpartAccount), -1, uString, iSizeBuffer, NULL);

            ID_T              instrIdOp = ZERO_ID;

            DBA_GetRecordIdByCd(Instr, uString, &instrIdOp, NullDynSt, NULL, UNUSED);

            if (instrIdOp > ZERO_AMOUNT)
            {
                SET_ID(extOp,ExtOp_InstrId, instrIdOp);
                SET_ID(extOp,ExtOp_AcctId, instrIdOp);
            }
        }


        COPY_DYNFLD(extOp, ExtOp, ExtOp_CashPlanId, ptfPayOutPtr, A_WithdrawalRequest, A_WithdrawalRequest_PlanDefinitionId);

        COPY_DYNFLD(extOp, ExtOp, ExtOp_PtfId, ptfPtr, A_Ptf, A_Ptf_ParentPortId);
        SET_ENUM(extOp, ExtOp_NatureEn, OpNat_Invest);


        SET_ENUM(extOp, ExtOp_StatusEn, accountingStatus);

        pflag[ExtOp_CashPtfId] = TRUE;
        pflag[ExtOp_InstrId] = TRUE;



        NUMBER_T  orderQty = 0.0, oddLotQty = 0.0;
        DBA_DYNFLD_STP	 instrPtr = NULL;
        FLAG_T allocFlg = TRUE;

        if ((ret = DBA_GetInstrById(instrId,
            TRUE, &allocFlg, &instrPtr, hierHead,
            UNUSED, UNUSED)) != RET_SUCCEED)
        {
            DBA_EndConnection(&dbiConn);
            FREE(extOp);
            return(NULL);
        }

        oddLotQty = GET_NUMBER(instrPtr, A_Instr_OddLotQty);
        AMOUNT_T orderAmt = GET_AMOUNT(ptfPayOutPtr, A_WithdrawalRequest_WithdrawalAmount );

        orderAmt = TLS_Round(orderAmt, oddLotQty, (RNDRULE_ENUM)GET_ENUM(domainPtr, A_Domain_RoundingMethodEn));
        orderQty = orderAmt; //to do


        if (CMP_AMOUNT(orderAmt, 0.0, GET_ID(instrPtr,A_Instr_RefCurrId) ) <= 0)
        {
            DBA_EndConnection(&dbiConn);
            FREE(extOp);
            return NULL;
        }


        SET_NUMBER(extOp, ExtOp_Qty, orderQty);
        SET_FLAG(extOp, ExtStratElt_AcctFlg, TRUE);

        pflag[ExtOp_NatureEn] = TRUE;
        pflag[ExtOp_PtfId] = TRUE;
        pflag[ExtOp_InstrId] = TRUE;
        pflag[ExtOp_StatusEn] = TRUE;
        pflag[ExtOp_CashPtfId] = TRUE;
        pflag[ExtOp_AcctId] = TRUE;
        pflag[ExtOp_Qty] = TRUE;
        pflag[ExtOp_ExtStratEltId] = TRUE;

        SET_ENUM(extOp, ExtOp_CheckStratEn, CheckStrat_None);
        pflag[ExtOp_CheckStratEn] = TRUE;

        SET_FLAG(extOp, ExtOp_ConfirmedFlg, TRUE);
        pflag[ExtOp_ConfirmedFlg] = TRUE;

        SET_ID(extOp, ExtOp_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));
        pflag[ExtOp_FctResultId] = TRUE;

        SET_ENUM(extOp, ExtOp_OrderInclusionEn, OrderInclusionEn_Included);
        pflag[ExtOp_OrderInclusionEn] = TRUE;

        SET_ENUM(extOp, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
        pflag[ExtOp_DbStatusEn] = TRUE;

        SET_ENUM(extOp, ExtOp_CheckParentEn, CheckParent_Disable);
        pflag[ExtOp_CheckParentEn] = TRUE;

        pflag[ExtOp_Qty] = TRUE;

        SET_ENUM(extOp, ExtOp_ParOpNatEn, ParOpNat_None);
        pflag[ExtOp_ParOpNatEn] = TRUE;

        pflag[ExtOp_CashPlanId] = TRUE;

        SCPT_ComputeScreenDV(EOp,
            (DICT_T)GET_DICT(domainPtr, A_Domain_InitialFctDictId),
            pflag,
            NULL,
            extOp,
            NULL,
            domainPtr,
            NULLDYNST,
            TRUE,             /*  Evaluate all data  */
            TRUE,              /*  No filter evaluation                    */
            EvalType_DefValAndFilter,
            0,
            (int*)NULL,
            NULL,
            hierHead,
            0,
            DictScreen,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NullEntity,
            FALSE,
            TRUE,
            0);

    }

    int extOpNbr = 1;

    if (PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptfPtr, A_Ptf_NatEn)))
        extOpNbr = 2;

    if ((mainExtOpTab = (DBA_DYNFLD_STP *)CALLOC(extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Unable to allocate memory for ext_operation record(s) for portfolio %2",
            NameType, "",
            CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
        return(NULL);
    }
    
    mainExtOpTab[*mainExtOpNbr] = newWithDrOp;
    *mainExtOpNbr = *mainExtOpNbr + 1;

    if (PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptfPtr, A_Ptf_NatEn)))
    {
        mainExtOpTab[*mainExtOpNbr] = extOp;
        *mainExtOpNbr = *mainExtOpNbr + 1;
    }

    return mainExtOpTab;
}


/************************************************************************
**
**  Function    :   FIN_ManagePayoutGenerateOrders()
**
**  Description :   Manage Payout Orders (Sell or Withdrawal)
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30894 - CHU - 180711
**  Modification:   PMSTA-36239 -NRAO -16062019
*************************************************************************/
RET_CODE FIN_ManagePayoutGenerateOrders(DBA_DYNFLD_STP      domainPtr,
                                        DBA_HIER_HEAD_STP   hierHead)
{
    RET_CODE                ret = RET_SUCCEED;
	ID_T		            instrId;
	DBA_DYNFLD_STP		    instrPtr = nullptr, *ptfPayOutTab = nullptr, ptfPayOutStp = nullptr;
	int					    extOpNbr = 0, posNbr = 0, ptfNbr = 0, i = 0, j = 0;
    FLAG_T                  allocFlg;
    DBA_DYNFLD_STP          *extOpTab = nullptr, *extPosTab = nullptr, *ptfTab = nullptr, tranferPtf = nullptr; /* PMSTA-34596 - CHU - 190410 */
    DBA_DYNFLD_ST           ptfIdDynSt;
    int                     delNbr, ptfPayOutNbr = 0;
	DbiConnectionHelper     dbiConnHelper;
    FLAG_T                  FullAssetLiquidationFlg = FALSE;
    DICT_FCT_STP            dictFctInfo;
    bool                    errorOccurred = false;
    MemoryPool              mp; /* PMSTA-34596 - CHU - 190410 */
    DBA_DYNST_ENUM          withDrawalReqDynstEn = A_WithdrawalRequest;

    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);

	/* PMSTA00542-CHU-070122 : Delete positions with BP Type Id's */
	if ((ret = DBA_DelHierEltRecWithFilter(hierHead, ExtPos,
                                           FIN_FilterExtPosBPType, NULL,
                                           &delNbr))!= RET_SUCCEED)
	{
        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while accessing data in memory for all portfolios",
                        NameType, dictFctInfo->name);
        return(ret);
	}

    DBA_MakeAllRecLinks(hierHead, ExtPos);      /* PMSTA-39941 - DDV - 200429 - Fix sanitizer error that may conduct to crash */
	DBA_FreeDeletedHierEltRecord(hierHead, ExtPos, FALSE);

    /* Extract all ptf */
   	if ((ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE,
                                     NULL, NULL,
                                     &ptfNbr, &ptfTab)) != RET_SUCCEED)
    {
		FREE(ptfTab);
        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while retrieving data from memory for all portfolios",
                       NameType, dictFctInfo->name);
        return(ret);
    }

	mp.ownerPtr(ptfTab);

    if (ptfNbr > 1) /* Not needed when only one portfolio */
    {
        /* because of the undel ptf by ptf */
        DBA_HierAllIndexNoUpdate(hierHead, ExtPos);
    }

    for (i = 0; i < ptfNbr; i++)
    {
        OPNAT_ENUM     opNatureEn = OpNat_None;  /* PMSTA-37051 - Silpakalab -190903*/
        if ((ret = FIN_SelPtfPayoutRequest(domainPtr, hierHead, ptfTab[i], &ptfPayOutTab, &ptfPayOutNbr)) != RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while retrieving withdrawal request record for portfolio %2",
                           NameType, dictFctInfo->name,
                           CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
            return(ret);
        }

        if ((ptfPayOutStp = mp.allocDynst(FILEINFO, A_WithdrawalRequest)) == nullptr)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        if (ptfPayOutNbr == 0) /* Full asset Liquidation, as no request could be missing at this stage */
        {
            bool found = false;

            DBA_DYNFLD_STP admArgIn = mp.allocDynst(FILEINFO,Adm_Arg);
            SET_ID(admArgIn, Adm_Arg_Id, GET_ID(ptfTab[i], A_Ptf_Id));
            if ((ret = DBA_Select2(WithdrawalRequest, UNUSED,
                                   Adm_Arg, admArgIn,
                                   S_WithdrawalRequest, &ptfPayOutTab,
                                   UNUSED, UNUSED,
                                   &ptfPayOutNbr,
                                   UNUSED, UNUSED)) != RET_SUCCEED)
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while retrieving withdrawal requests for portfolio %2",
                               NameType, dictFctInfo->name,
                               CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                return(ret);
            }

            for (auto k = 0; k < ptfPayOutNbr; k++)
            {
                DBA_Get2(WithdrawalRequest, UNUSED, S_WithdrawalRequest, ptfPayOutTab[k], A_WithdrawalRequest, &ptfPayOutStp,
                         UNUSED, NULL, UNUSED);
               if (ptfPayOutStp != NULLDYNST &&
                   CMP_ID(GET_ID(ptfPayOutStp, A_WithdrawalRequest_SessionId), GET_ID(domainPtr, A_Domain_FctResultId) == 0) &&
                   IS_NULLFLD(ptfPayOutStp, A_WithdrawalRequest_WithdrawalSessionId) == TRUE)
               {
                   found = true;
                   break;
               }
            }

            withDrawalReqDynstEn = S_WithdrawalRequest;
            if (found == false)
            {
                continue;
            }

            FullAssetLiquidationFlg = TRUE;
        }
        else
        {
            COPY_DYNST(ptfPayOutStp, ptfPayOutTab[0], withDrawalReqDynstEn);
        }

        if (ptfNbr > 1) /* Not needed when only one portfolio */
        {
            if ((ret = DBA_DelHierElt(hierHead, ExtPos)) != RET_SUCCEED)
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while accessing data in memory for all portfolios",
                    NameType, dictFctInfo->name);
                return(ret);
            }
        }

        memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST));
        SET_ID((&ptfIdDynSt), 0, GET_ID(ptfTab[i], A_Ptf_Id));

        if (ptfNbr > 1) /* Not needed when only one portfolio */
        {
            if ((ret = DBA_UndelHierEltRecWithFilter(hierHead, ExtPos,
                FIN_FilterExtPosCrtPtf, &ptfIdDynSt)) != RET_SUCCEED)
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while accessing data in memory for all portfolios",
                    NameType, dictFctInfo->name);
                return(ret);
            }
        }

        /*
        Extract all positions
        */
        ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
            ExtPos,
                                                 FALSE,
                                                 FIN_FilterExtPosCrtPtf,
                                                 &ptfIdDynSt,
                                                 NULLFCT,
                                                 &posNbr,
                                                 &extPosTab);

		mp.ownerPtr(extPosTab);
			
	    if( ret == RET_SUCCEED && posNbr > 0)
        {
            int cashPositionNbr = 0;
            int instrPositionNbr = 0;

            for (j = 0; j < posNbr; j++)
            {
                instrId = GET_ID(extPosTab[j], ExtPos_InstrId);
                if (instrId > (ID_T)0) /* PMSTA-33023 - CHU - 181005 */
                {
                    if ((ret = DBA_GetInstrById(instrId, TRUE, &allocFlg, &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem retrieving instrument from position of portfolio %2",
                            NameType, dictFctInfo->name,
                            CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                        errorOccurred = true;
                    }
                    else
                    {
                        if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
                        {
                            cashPositionNbr++;
                        }
                        else
                        {
                            instrPositionNbr++;
                        }
                    }
                }
            }

            if (errorOccurred == true)
            {
                continue; /* go to next portfolio */
            }

			/* PMSTA-33023 - CHU - 181005 */
            if ((((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsSale) || /* PMSTA-34596 - CHU - 190408  */
                ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsTransfer)) && /*PMSTA-36142 -ramadevi -20190610*/
                instrPositionNbr > 0)
            {
                FullAssetLiquidationFlg = TRUE;
            }

            /* < PMSTA-34596 - CHU - 190410 */
            if (((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_PartialWithdrawal) && cashPositionNbr > 0)
            {
                opNatureEn = OpNat_Withdr;
            }

            if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsTransfer &&
                instrPositionNbr > 0 &&
                ((GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_StatusEn) == WithdrawalRequestStatusEn_PendingWaitFundSwitching) ||
                (GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_StatusEn) == WithdrawalRequestStatusEn_Initiated))) /*PMSTA-36142 -ramadevi -20190610*/
            {
                if (TRUE == IS_NULLFLD(ptfPayOutStp, A_WithdrawalRequest_CounterpartPtf))
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Fund Transfer Order generation - No counterpart portfolio provided for Assets transfer from portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                    errorOccurred = true;
                    continue; /* go to next portfolio */
                }

                DBA_DYNFLD_STP   inputSt = NULLDYNST;
                allocFlg = TRUE;

                if ((tranferPtf = mp.allocDynst(FILEINFO, A_Ptf)) == nullptr)
                {
                    return(RET_MEM_ERR_ALLOC);
                }

                if ((inputSt = mp.allocDynst(FILEINFO, S_Ptf)) == nullptr)
                {
                    return(RET_MEM_ERR_ALLOC);
                }

                /* Get Portfolio record */
                SET_CODE(inputSt, S_Ptf_Cd, GET_CODE(ptfPayOutStp, A_WithdrawalRequest_CounterpartPtf));
                if (DBA_Get2(Ptf, UNUSED, S_Ptf, inputSt, A_Ptf, &tranferPtf,
                             UNUSED, NULL, UNUSED) != RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Counterpart portfolio %2 not found for Assets transfer from portfolio %3",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(inputSt, S_Ptf_Cd),
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                    errorOccurred = true;
                    continue; /* go to next portfolio */
                }
                SET_ID(ptfPayOutStp, A_WithdrawalRequest_CounterpartPtfId, GET_ID(tranferPtf, A_Ptf_Id));
                opNatureEn = OpNat_PtfTransf;
            }
            /* > PMSTA-34596 - CHU - 190410 */

            if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsTransfer &&
                opNatureEn == OpNat_Sell)
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Withdrawal Request nature %2 mismatch with operation nature %3 for portfolio %4",
                               NameType, dictFctInfo->name,
                               EnumType, GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn),
                               EnumType, opNatureEn,
                               CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                errorOccurred = true;
                continue; /* go to next portfolio */
            }

            if (((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsSale) || /* PMSTA-34596 - CHU - 190408  */
                ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsTransfer))  /*PMSTA-36142 -ramadevi -20190610*/
            {
                if (FullAssetLiquidationFlg == TRUE)
                {
                    /* Sell all portfolio positions */
                    if (instrPositionNbr > 0)
                    {
                        if ((extOpTab = (DBA_DYNFLD_STP *)CALLOC(posNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
                        {
                            MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Full Liquidation - Unable to allocate memory for ext_operation record(s) for portfolio %2",
                                NameType, dictFctInfo->name,
                                CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                            return(RET_MEM_ERR_ALLOC);
                        }

						/* PMSTA-37051 - Silpakalab -190903*/
						if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsSale)
						{
							opNatureEn = OpNat_Sell;
						}

                        for (j = 0; j < posNbr; j++)
                        {
                            instrId = GET_ID(extPosTab[j], ExtPos_InstrId);
                            if ((ret = DBA_GetInstrById(instrId, TRUE, &allocFlg, &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                            {
                                return(ret);
                            }

                            if (true == getRidOfThisInstrument(instrPtr))
                            {
                                DBA_DYNFLD_STP testExtOp = FIN_CreateExtOpForPayout(ptfTab[i], /* OpNat_Sell or OpNat_PtfTransf */ opNatureEn, extPosTab[j], hierHead, domainPtr, ptfPayOutStp);

                                if (testExtOp != NULLDYNST)
                                {
                                    extOpTab[extOpNbr] = testExtOp;
                                    extOpNbr++;
                                }
                            }
                        }
                    }
                    else
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - No position to Liquidate for portfolio %2",
                            NameType, dictFctInfo->name,
                            CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                    }
                }
                else /* Create Withdrawals for all Cash Positions */
                {
                    if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsSale || /* PMSTA-34596 - CHU - 190408  */
                        ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidationAssetsTransfer))
                    {
                        if (instrPositionNbr > 0)
                        {
                            MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - %2 position(s) on instruments still remain for portfolio %3, unable to generate all withdrawals",
                                NameType, dictFctInfo->name,
                                IntType, instrPositionNbr,
                                CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                            errorOccurred = true;
                        }
                        else
                        {
                            if (cashPositionNbr > 0) /* Only Cash remaining --> create withdrawal(s) */
                            {
                                opNatureEn = OpNat_Withdr;
                                if ((extOpTab = (DBA_DYNFLD_STP *)CALLOC(posNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
                                {
                                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Full Liquidation - Unable to allocate memory for ext_operation record(s) for portfolio %2",
                                        NameType, dictFctInfo->name,
                                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                for (j = 0; j < posNbr; j++)
                                {
                                    DBA_DYNFLD_STP testExtOp = FIN_CreateExtOpForPayout(ptfTab[i], /* OpNat_Withdr */ opNatureEn, extPosTab[j], hierHead, domainPtr, ptfPayOutStp);

                                    if (testExtOp != NULLDYNST)
                                    {
                                        extOpTab[extOpNbr] = testExtOp;
                                        extOpNbr++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_PartialWithdrawal) 
            {
                if (cashPositionNbr > 0) /* Only Cash remaining --> create partial withdrawal */
                {
                    DBA_DYNFLD_STP  candidateExtOp = NULL;
                    AMOUNT_T        globalCurrAmount = 0.0;

                    if (IS_NULLFLD(ptfPayOutStp, A_WithdrawalRequest_WithdrawalCurrId) == TRUE)
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Withdrawal Request currency is not initialized for portfolio %2!",
                            NameType, dictFctInfo->name,
                            CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                        errorOccurred = true;
                    }

                    if (IS_NULLFLD(ptfPayOutStp, A_WithdrawalRequest_WithdrawalAmount) == TRUE)
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Withdrawal Request amount is not initialized for portfolio %2!",
                            NameType, dictFctInfo->name,
                            CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                        errorOccurred = true;
                    }

                    if (errorOccurred == false) /* PMSTA-33023 - CHU - 181005 */
                    {
                        for (j = 0; j < posNbr; j++)
                        {
                            instrId = GET_ID(extPosTab[j], ExtPos_InstrId);
                            if ((ret = DBA_GetInstrById(instrId, TRUE, &allocFlg, &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                            {
                                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem retrieving instrument from position of portfolio %2",
                                    NameType, dictFctInfo->name,
                                    CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                                errorOccurred = true;
                            }

                            if (errorOccurred == false) /* PMSTA-33023 - CHU - 181005 */
                            {
                                if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_CashAcct)
                                {
                                    continue;
                                }

                                if (CMP_ID(GET_ID(extPosTab[j], ExtPos_InstrCurrId), GET_ID(ptfPayOutStp, A_WithdrawalRequest_WithdrawalCurrId)) == 0)
                                {
                                    if (candidateExtOp == NULL) /* grab the first matching position for later order generation */
                                    {
                                        candidateExtOp = extPosTab[j];
                                    }
                                    globalCurrAmount += (AMOUNT_T)GET_NUMBER(extPosTab[j], ExtPos_Qty);
                                }
                            }
                        }
                    }

                    if (errorOccurred == false)
                    {
                        /* check position quantity against withdrawal_amount_m  */
                        if (CMP_AMOUNT(globalCurrAmount,
                            GET_AMOUNT(ptfPayOutStp, A_WithdrawalRequest_WithdrawalAmount),
                            GET_ID(ptfPayOutStp, A_WithdrawalRequest_WithdrawalCurrId)) >= 0.0)
                        {
                            if ((extOpTab = (DBA_DYNFLD_STP *)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULL)
                            {
                                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Unable to allocate memory for ext_operation record(s) for portfolio %2",
                                    NameType, dictFctInfo->name,
                                    CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                                return(RET_MEM_ERR_ALLOC);
                            }

                            DBA_DYNFLD_STP testExtOp = FIN_CreateExtOpForPayout(ptfTab[i], /* OpNat_Withdr */ opNatureEn, candidateExtOp, hierHead, domainPtr, ptfPayOutStp);

                            if (testExtOp != NULLDYNST)
                            {
                                extOpTab[extOpNbr] = testExtOp;
                                extOpNbr = 1;
                            }
                        }
                        else
                        {
                            SET_ENUM(ptfPayOutStp, A_WithdrawalRequest_StatusEn, WithdrawalRequestStatusEn_Failed);
                            SET_ENUM(ptfPayOutStp, A_WithdrawalRequest_FailureReasonEn, WithdrawalRequestFailureReasonEn_NotEnoughCash);

                            /* not enough cash ! */
                            MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Not enough cash to create Withdrawal order for portfolio %2 (Needed: %3 / Available: %4)",
                                NameType, dictFctInfo->name,
                                CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd),
                                AmountType, GET_AMOUNT(ptfPayOutStp, A_WithdrawalRequest_WithdrawalAmount),
                                AmountType, globalCurrAmount);

                            if (DBA_Update2(WithdrawalRequest, UNUSED, A_WithdrawalRequest, ptfPayOutStp, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                            {
                                MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Unable to update status of Withdrawal Request record for portfolio %2",
                                    NameType, dictFctInfo->name,
                                    CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                            }
                        }
                    }
                }
            }
            else if ((WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_PartialWithdrawalCashMgmtPlan)
            {
                /*for cash plan tactical investment*/
                /*Get cash Balance*/
                AMOUNT_T cashAvb = ZERO_AMOUNT;

                FIN_GetCashBalance(hierHead, ptfTab[i], &cashAvb);


                /*if enough cash then create invest operation in the parent*/
                if (CMP_AMOUNT(cashAvb,GET_AMOUNT(ptfPayOutStp,A_WithdrawalRequest_WithdrawalAmount),GET_ID(ptfPayOutStp, A_WithdrawalRequest_WithdrawalCurrId)) <= 0)
                {
                    /*if avilable amount is less than withdrwal amount then withdraw avilable amount*/
                    SET_AMOUNT(ptfPayOutStp, A_WithdrawalRequest_WithdrawalAmount, cashAvb);
                }
                    opNatureEn = OpNat_Invest;

                    extOpTab = FIN_CreateInvestExtOp(ptfTab[i], /* OpNat_Sell or OpNat_PtfTransf */ opNatureEn, hierHead, domainPtr, ptfPayOutStp, extOpTab, &extOpNbr);

                
            }

            if (extOpNbr > 0 && errorOccurred == false)
            {
                DBA_AddHierRecordList(hierHead, extOpTab, extOpNbr, ExtOp, TRUE);

                if ((ret = DBA_FamilyOrder(Action_SaveDraft,
                    (DBA_DYNFLD_STP*)extOpTab,
                    extOpNbr,
                    0,
                    NULLDYNST,
                    (PTR)NULL,
                    DBA_NO_ERROR,
                    dbiConnHelper,
                    GET_DICT(domainPtr, A_Domain_FctDictId),
                    domainPtr,
                    NULLDYNSTPTR, 0,
                    NULLDYNSTPTR,
                    (PTR)NULL,
                    false)) != RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while saving operations for portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                    errorOccurred = true;
                }
                FREE(extOpTab);
                extOpNbr = 0;
            }

#ifdef PMSTA34596
            if (errorOccurred == false &&
                FullAssetLiquidationFlg == TRUE &&
                (WITHDRAWAL_REQUEST_NATURE_ENUM)GET_ENUM(ptfPayOutStp, A_WithdrawalRequest_NatEn) == WithdrawalRequestNaEn_FullLiquidation)
            {
                /*
                5.	if all went well:
                a.	set the end date to system date -1 day to invalidate following links:
                i.	All active Investment Profile
                ii.	All active Trading and Modelling Constraints
                */
                if ((ret = DBA_InvalidateStrategies(ptfTab[i])) != RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Order generation - Problem while invalidating strategies for portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                    return(ret);
                }
            }
#endif

			/* < PMSTA-33023 - CHU - 181005 */
            if (errorOccurred == true)
            {
                SET_ENUM(ptfPayOutStp, A_WithdrawalRequest_StatusEn, WithdrawalRequestStatusEn_Failed);
                if (DBA_Update2(WithdrawalRequest, UNUSED, A_WithdrawalRequest, ptfPayOutStp, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Unable to update status of Withdrawal Request record for portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                }
                else
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Manage Payout - Error occurred - Status of Withdrawal Request set to Failed for portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                }
            }
			/* > PMSTA-33023 - CHU - 181005 */

#ifdef PMSTA33023
            if (errorOccurred == false &&
                FullAssetLiquidationFlg == FALSE)
            {
                SET_ENUM(ptfPayOutStp, A_WithdrawalRequest_StatusEn, WithdrawalRequestStatusEn_PendingWaitingCashTransfer);
                if (DBA_Update2(WithdrawalRequest, UNUSED, A_WithdrawalRequest, ptfPayOutStp, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "%1: Partial Withdrawal - Unable to update status of Withdrawal Request record for portfolio %2",
                        NameType, dictFctInfo->name,
                        CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
                }
            }
#endif
        }
        DBA_FreeDynStTab(ptfPayOutTab, ptfPayOutNbr, withDrawalReqDynstEn);
    }

    if (ptfNbr > 1) /* Not needed when only one portfolio */
    {
        DBA_HierRebuildAllIndex(hierHead, ExtPos);
    }

    if (errorOccurred == false)
    {
        SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_CheckedSession);
    }
    else
    {
        SET_ENUM(domainPtr, A_Domain_FctResultStatEn, FctResultStatus_Draft);
    }
    DBA_RestorePtfDim(domainPtr); /* PMSTA09899-CHU-100521 */
    DBA_Update2(Domain, UNUSED, A_Domain, domainPtr, UNUSED, UNUSED, UNUSED);
    DBA_SetTascJobPtfDim(domainPtr, NULL); /* PMSTA09899-CHU-100521 */ /* OCS-49362 - TEB - 170508 */

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ManagePayout()
**
**  Description :   Valuate portfolio and sell every position
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30894 - CHU - 180711
**
*************************************************************************/
RET_CODE FIN_ManagePayout(DBA_DYNFLD_STP    domainPtr,
                          DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_DYNFLD_STP          fctResStp = NULLDYNST;
    DBA_DYNFLD_STP          tmpDomainPtr = NULLDYNSTPTR;

    /*
    1.	Create an order session for the portfolio given in input, if no session is provided by the caller.
    */
    if ((ret = FIN_ComputeNewFctResult(domainPtr, &fctResStp)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "Manage Payout", "Unable to retrieve or create session");
        FREE_DYNST(fctResStp, A_FctResult);
        return(ret);
    }
    FREE_DYNST(fctResStp, A_FctResult);

    /*
    2.	Execute a Valuation on the portfolio to gather all positions (based on settings provided in the input domain).
    */
	if ((ret = FIN_CheckStratValoDomain(domainPtr, FALSE, FALSE, &tmpDomainPtr)) == RET_SUCCEED)
    {
        if ((ret = DBA_LoadPos(tmpDomainPtr, &hierHead, NULL, 0, NULLDYNSTPTR, 0)) == RET_SUCCEED)
        {
            ret = FIN_AnalysisValo(tmpDomainPtr, hierHead);
            FIN_DelTechnicalPosFromHier(hierHead);
        }
	}
    FREE_DYNST(tmpDomainPtr, A_Domain);

    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "Manage Payout", "Portfolio valuation failed");
        return(ret);
    }

    /*
    Full
    3.	Loop on each position (and sum positions on same instruments) to generate sell operations on every position (except cash account or cash assimilated instruments).
    */
    if ((ret = FIN_ManagePayoutGenerateOrders(domainPtr, hierHead)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "Manage Payout", "Problem occurred while generating orders");
        return(ret);
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_SetPosRefAmounts()
**
**  Description :   Set reference amounts
**
**  Arguments   :   posPtr    - Pointer on postTab
**                  mainPos   - Pointer on Main Position
**                  acctFldIdx:
**                            - ExtPos_Acct_ExtPos_Ext
**                            - ExtPos_Acct2_ExtPos_Ext
**						      - ExtPos_Acct3_ExtPos_Ext
**                  refCurrId - Domain currency
**                  euroCurrId
**                  noCopyForEuro
**                  refCurrOk
**
**  Return      :   RET_SUCCEED
**
*************************************************************************/
STATIC RET_CODE FIN_SetPosRefAmounts(DBA_DYNFLD_STP posPtr,
                                     DBA_DYNFLD_STP checkPos,
                                     FIELD_IDX_T acctFldIdx,
                                     ID_T refCurrId,
                                     ID_T euroCurrId,
                                     FLAG_T noCopyForEuro,
                                     char *refCurrOk)
{
    DBA_DYNFLD_STP acctPosPtr;

    if (*refCurrOk == FALSE &&
        (GET_EXTENSION_PTR(checkPos, acctFldIdx) != NULL &&
        (acctPosPtr = *(GET_EXTENSION_PTR(checkPos, acctFldIdx))) != NULLDYNST) &&
        refCurrId == GET_ID(acctPosPtr, ExtPos_InstrCurrId) &&
        (CMP_DYNFLD(posPtr, acctPosPtr,
        ExtPos_RefCurrId, ExtPos_RefCurrId, IdType) == 0) &&
        GET_EXCHANGE(acctPosPtr, ExtPos_InstrExchRate) != ZERO_EXCHANGE &&
        (CMP_ID(GET_ID(acctPosPtr, ExtPos_InstrCurrId), euroCurrId) != 0
        || noCopyForEuro == FALSE))

    {
        *refCurrOk = TRUE;

        SET_AMOUNT(posPtr, ExtPos_RefGrossAmt,
            CAST_AMOUNT(GET_AMOUNT(posPtr, ExtPos_RefGrossAmt) /
            GET_EXCHANGE(acctPosPtr, ExtPos_InstrExchRate),
            refCurrId));
        SET_AMOUNT(posPtr, ExtPos_RefNetAmt,
            CAST_AMOUNT(GET_AMOUNT(posPtr, ExtPos_RefNetAmt) /
            GET_EXCHANGE(acctPosPtr, ExtPos_InstrExchRate),
            refCurrId));
        SET_AMOUNT(posPtr, ExtPos_BookRefNetAmt,
            CAST_AMOUNT(GET_AMOUNT(posPtr, ExtPos_BookRefNetAmt) /
            GET_EXCHANGE(acctPosPtr, ExtPos_InstrExchRate),
            refCurrId));
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_UpdPosRefAmounts()
**
**  Description :   Call FIN_SetPosRefAmounts to set reference amounts
**
**  Arguments   :   posPtr    - Pointer on postTab
**                  mainPos   - Pointer on Main Position
**                  acctFldIdx:
**                            - ExtPos_Acct_ExtPos_Ext
**                            - ExtPos_Acct2_ExtPos_Ext
**						      - ExtPos_Acct3_ExtPos_Ext
**                  refCurrId - Domain currency
**                  euroCurrId
**                  noCopyForEuro
**                  refCurrOk
**
**  Return      :   RET_SUCCEED
**
*************************************************************************/

STATIC RET_CODE FIN_UpdPosRefAmounts(DBA_DYNFLD_STP posPtr,
                                     DBA_DYNFLD_STP checkPos,
                                     ID_T refCurrId,
                                     ID_T euroCurrId,
                                     FLAG_T noCopyForEuro,
                                     char *refCurrOk)
{

    FIN_SetPosRefAmounts(posPtr, checkPos, ExtPos_Acct_ExtPos_Ext, refCurrId, euroCurrId, noCopyForEuro, refCurrOk);

    FIN_SetPosRefAmounts(posPtr, checkPos, ExtPos_Acct2_ExtPos_Ext, refCurrId, euroCurrId, noCopyForEuro, refCurrOk);

    FIN_SetPosRefAmounts(posPtr, checkPos, ExtPos_Acct3_ExtPos_Ext, refCurrId, euroCurrId, noCopyForEuro, refCurrOk);

    return (RET_SUCCEED);

}

/************************************************************************
**
**  Function    :   FIN_IsOverlayInterRebalOrderPos()
**
**  Description :   To check if a position belongs to an order created
**                     as part of Overlay Inter processing
**
**  Arguments   :   stratHierHeadPtr    - hierarchy
**                  domainPtr           - Domain
**                  extPos              - Ext Position
**
**  Return      :   true or false
**
**  Created     :   PMSTA-40892 - vkumar - 150720
**
*************************************************************************/
STATIC bool FIN_IsOverlayInterRebalOrderPos(DBA_HIER_HEAD_STP     stratHierHead,
                                            DBA_DYNFLD_STP        domainPtr,
                                            const DBA_DYNFLD_STP  extPos)
{
    bool                isInterRebalPos = false;
    REBAL_METHOD_ENUM   rebalMethodEn   = static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn);

    if (REBAL_METHOD_ENUM::Intra == rebalMethodEn &&
        GET_ID(extPos, ExtPos_Id) < 0 &&
        TRUE == IS_NULLFLD(extPos, ExtPos_PosObjId) &&
        ((OpNat_Sell == static_cast<OPNAT_ENUM>GET_ENUM(extPos, ExtPos_OpenOpNatEn) &&
          (PosNat_MainPos == static_cast<POSNAT_ENUM>GET_ENUM(extPos, ExtPos_PosNatEn) ||
           PosNat_MainAcctPos == static_cast<POSNAT_ENUM>GET_ENUM(extPos, ExtPos_PosNatEn)) &&
          FALSE == IS_NULLFLD(extPos, ExtPos_CashPortfolioId)) ||
         (OpNat_PtfTransf == static_cast<OPNAT_ENUM>GET_ENUM(extPos, ExtPos_OpenOpNatEn))))
    {
        /* checking if ESE already created for Inter Rebal generated orders */
        isInterRebalPos = true;
    }

    return isInterRebalPos;
}

/************************************************************************
**
**  Function    :   FIN_DraftOrderValo()
**
**  Description :   Trigger logical fusion for draft order and
**                      copy relevant positions to hierarchy
**
**  Arguments   :   stratHierHeadPtr    - hierarchy
**                  domainPtr   - Domain
**
**
**  Return      :   RET_SUCCEED
**
**  Created     :   PMSTA-36202 - 200619 - vkumar
**
*************************************************************************/
RET_CODE FIN_DraftOrderValo(PTR              stratHierHeadPtr,
    DBA_DYNFLD_STP   domainPtr,
    DBA_DYNFLD_STP   ptfPtr)
{
    RET_CODE            ret           = RET_SUCCEED;
    DBA_HIER_HEAD_STP   stratHierHead = static_cast<DBA_HIER_HEAD_STP>(stratHierHeadPtr);
    DATETIME_T          startDate     = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    ID_T                ptfId         = UNUSED;
    OBJECT_ENUM         dimPtfEn;
    MemoryPool          mp;
    DBA_DYNFLD_STP      origDomainPtr = DBA_GetDomainPtr(-1);

    /* Startdate must always be given */
    if (startDate.date == BAD_DATE)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
    {
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
        if (dimPtfEn == Ptf)
        {
            ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
        }
    }

    FLAG_T         allocFlg = FALSE;

    if (ptfId > 0 && (ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr, stratHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        return(ret);
    }

    FusionContext       ctx;
    LOGICIDRULE_ENUM    logicIdRule;
    FIN_STRAT_ENUM      stratReconEn = static_cast<FIN_STRAT_ENUM>GET_ENUM(domainPtr, A_Domain_StratCheckReconcEn);
    FLAG_T				statusFusFlgBK = GET_ENUM(domainPtr, A_Domain_StatusFusFlg); /* PMSTA-38413 - 010120 - SPB */
    DBA_DYNFLD_STP     *extractPos = nullptr;
    int                 posNbr = 0;

    if ((ret = DBA_ExtractHierEltRec(stratHierHead,
        ExtPos,
        FALSE,
        NULLFCT,
        FIN_CmpCheckLogicFus,
        &posNbr,
        &extractPos)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* Check if hierarchy contains positions */
    if (posNbr == 0)
        return (RET_SUCCEED);

    /* FIN_CheckLogicalFusion called to populate logicIdRule to avoid duplication of code.
       ret_code not checked as Logical fusion for draft order to be done irrespective of
       fusion parameters set in domain.
       To be optimized/corrected in due time to populate logicIdRule */
    SET_ENUM(domainPtr, A_Domain_StratCheckReconcEn, Strat_Check);
    /* PMSTA-38413 - 010120 - SPB : Set the status_fus_f attribute in Domain to treat all positions as accounted for fusion */
    SET_ENUM(domainPtr, A_Domain_StatusFusFlg, TRUE);
    FIN_CheckLogicalFusion(domainPtr, stratHierHead, posNbr, extractPos, &logicIdRule);
    SET_ENUM(domainPtr, A_Domain_StratCheckReconcEn, stratReconEn);
    /* PMSTA-38413 - 010120 - SPB : Reset, as we have remapped the status for all the positions which is good for fusion */
    SET_ENUM(domainPtr, A_Domain_StatusFusFlg, statusFusFlgBK);

    FREE(extractPos);


    /* PMSTA-38413 - 010120 - SPB : 'posCloseFlag' is set to TRUE for Draft order fusion workflow.
       This will make sure the positions created for closing Instrument in adjustment exchange draft order case.
       Eg, say, you are exchanging all the quantity(100) of A instrument with B instrument. Here, two positons of quantity
       -100 and 100 will have to fuse to close the position.
    */
    FLAG_T posCloseFlag = TRUE;

    ret = _FIN_LogicalFusion(ctx,
        startDate,
        stratHierHeadPtr,
        NULLFCT,
        static_cast<PTFFUSRULE_ENUM>(GET_ENUM(domainPtr, A_Domain_FusRuleEn)),
        logicIdRule,
        posCloseFlag,
        ptfId, ptfPtr);

    if (RET_SUCCEED != ret)
    {
        return ret;
    }

    DBA_DYNFLD_STP * positionArray = nullptr;
    DBA_DYNFLD_STP * beginArray = nullptr;
    DBA_DYNFLD_STP * endArray = nullptr;
    int positionNbr = 0;
    ret = DBA_ExtractHierEltRec(stratHierHead, ExtPos, FALSE, NULL, NULL, &positionNbr, &positionArray);

    if (positionArray != nullptr)
    {
        mp.owner(positionArray);
        beginArray = positionArray;
        endArray = positionArray + positionNbr;
    }


    /* delete all positions and copy only draft order impact positions */
    DBA_MarkHierEltRecLogicDel((DBA_HIER_HEAD_STP)stratHierHead, ExtPos);

    int             opNbr = 0;
    DBA_DYNFLD_STP *opTab = NULL;

    /* extract draft orders */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierHead, ExtOp, FALSE,
        NULLFCT, NULL, NULL, &opNbr, &opTab)) != RET_SUCCEED)
    {
        return ret;
    }

    mp.owner(opTab);

    for (int i = 0; i < ctx.posLogTypesNb; i++)
    {
        for (int j = 0; j < ctx.posLogTypesTab[i].posNb; j++)
        {
            DBA_DYNFLD_STP currPos        = ctx.posLogTypesTab[i].posTab[j];
            int            opIdx          = 0;
            bool           matchingPos    = false;

            for (; opIdx < opNbr; opIdx++)
            {
				matchingPos = (0 == CMP_ID(GET_ID(currPos, ExtPos_OpenOpId), GET_ID(opTab[opIdx], ExtOp_Id)) && TRUE == IS_NULLFLD(currPos, ExtPos_BalPosTpId));
				if (matchingPos)
				{
					break;
				}
            }

            if (!matchingPos)
            {
                if (DbStatus_ToUpdate != GET_ENUM(currPos, ExtPos_DbStatus) &&
                    GET_ID(currPos, ExtPos_PosObjId) < ZERO_ID)
                {
                    /* free the position only if it's not in hierarchy */
                    if (endArray == std::find(beginArray, endArray, currPos))
                    {
                        FREE_DYNST(currPos, ExtPos);
                    }
                }
            }
            else
            {
                /* PMSTA-40892 - vkumar - 150720 */
                /* Incase of InterIntra rebalancing method, skip the positions generated by
                   Inter rebalancing part as ESE is already created for them */
                   /*PMSTA-50836 - SATYA - Added DictFct_PreTradeCheckStrat condition*/
                if (GET_DICT(origDomainPtr, A_Domain_FctDictId) != DictFct_PreTradeCheckStrat &&
                    true == FIN_IsOverlayInterRebalOrderPos(stratHierHead, domainPtr, currPos))
                {
                    if (DbStatus_ToUpdate != GET_ENUM(currPos, ExtPos_DbStatus) &&
                        GET_ID(currPos, ExtPos_PosObjId) < ZERO_ID)
                    {
                        /* free the position only if it's not in hierarchy */
                        if (endArray == std::find(beginArray, endArray, currPos))
                        {
                            FREE_DYNST(currPos, ExtPos);
                        }
                    }

                    continue;
                }

                PosLog currPosLog(currPos);

                /* identify draft order impact */
                const bool draftOrderPos = (((currPosLog.isAdjustmentPL()
                    || currPosLog.isAdjustmentProportional()
                    || currPosLog.isAdjustmentExchWithCashDist()
                    || currPosLog.isAdjustmentConversion())                       /* P&L/Proportional/Exchange with Cash Dist/Conversion adjustment */
                    && currPosLog.isSecondary()
                    && currPosLog.orEq(PosNat_MainPos, PosNat_AdjPos))
                    || ((currPosLog.isAdjustmentExchange()                                   /* Exchange adjustment */
                        || currPosLog.isAdjustmentExchangeWithFees())
                        && currPosLog.isPrimary()
                        && currPosLog.orEq(PosNat_MainPos, PosNat_AdjExchMktPrice))
                    || ((currPosLog.isAdjustmentGrossAmt()
                        || currPosLog.isAdjustmentCostPrice())                        /* Gross/CostPrice adjustment */
                        && currPosLog.isPrimary()
                        && currPosLog.orEq(PosNat_MainPos, PosNat_AdjPos))
                    || (currPosLog.isAdjustment()                                           /* Adjustment cash impact */
                        && currPosLog.isPrimaryOrSecondary()
                        && currPosLog.orEq(PosNat_MainAcctPos)
                        && !currPosLog.isZeroQty())
                    || ((!currPosLog.isAdjustment()) && (currPosLog.isPrimary())));         /* Non-adjustment operations */

                if (true == draftOrderPos)
                {
                    SET_ENUM(currPos, ExtPos_StatEn, GET_ENUM(opTab[opIdx], ExtOp_StatusEn));
                    if (DbStatus_ToUpdate == GET_ENUM(currPos, ExtPos_DbStatus))
                    {
                        DBA_UndelHierEltRec(stratHierHead, ExtPos, currPos);
                    }
                    else
                    {
                        SET_NULL_ID(currPos, ExtPos_Id);
                        if ((ret = DBA_AddHierRecord(stratHierHead, currPos, ExtPos, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
                        {
                            (void)MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                            return ret;
                        }
                    }
                }
                else
                {
                    if (DbStatus_ToUpdate != GET_ENUM(currPos, ExtPos_DbStatus) &&
                        GET_ID(currPos, ExtPos_PosObjId) < ZERO_ID)
                    {
                        /* free the position only if it's not in hierarchy */
                        if (endArray == std::find(beginArray, endArray, currPos))
                        {
                            FREE_DYNST(currPos, ExtPos);
                        }
                    }
                }
            }
        }
    }

    ret = DBA_HierRebuildAllIndex(stratHierHead, ExtPos);
    if (RET_SUCCEED != ret)
    {
        (void)MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return ret;
    }

    ret = DBA_MakeAllRecLinks(stratHierHead, ExtPos);
    if (RET_SUCCEED != ret)
    {
        (void)MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
    }


    return ret;
}

/************************************************************************
**
**  Function    :   FIN_GetFXFwdWithTwoLegsPosNat()
**
**  Description :   Get PosNat for position or balance position with SubNat_FXFwd_TwoLegsAgainsPtfCurr
**
**  Arguments   :   dynSt      dynamic structure pointer
**
**  Return      :   PosNat_None or PosNat_MainAcctPos or PosNat_Acct2Pos
**
**  Creation D. :   PMSTA-51476 - DDV - 230124
**
*************************************************************************/
POSNAT_ENUM FIN_GetFXFwdWithTwoLegsPosNat(DBA_DYNFLD_STP pos)
{
	if ((IS_NULLFLD(pos, ExtPos_BalPosTpId) == TRUE && GET_FLAG(pos, ExtPos_MainFlg) == TRUE) ||
		(IS_NULLFLD(pos, ExtPos_BalPosTpId) == FALSE && GET_ENUM(pos, ExtPos_PosNatEn) == PosNat_MainAcctPos))
	{
		return(PosNat_MainAcctPos);
	}
	else if ((IS_NULLFLD(pos, ExtPos_BalPosTpId) == TRUE && GET_FLAG(pos, ExtPos_MainFlg) == FALSE) ||
		     (IS_NULLFLD(pos, ExtPos_BalPosTpId) == FALSE && GET_ENUM(pos, ExtPos_PosNatEn) == PosNat_Acct2Pos))
	{
		return(PosNat_Acct2Pos);
	}

	return(PosNat_None);
}

/************************************************************************
**
**  Function    :   FIN_FilterFXFwdWithTwoLegsAgainsPtfCurr()
**
**  Description :   Keep all positions, balance position having instrument
**                  with SubNat_FXFwd_TwoLegsAgainsPtfCurr.
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :
**
*************************************************************************/
STATIC int FIN_FilterFXFwdWithTwoLegsAgainsPtfCurr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* PMSTA- 44218 - Savitha - 30052021 */
{
    DBA_DYNFLD_STP       instrPtr;

    if (GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) != NULL &&
        (instrPtr = *GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext)) != NULLDYNST &&
        GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
    {
        return(TRUE);
    }

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpPosByInstrPosNat()
**
**  Description :   Sort position, balance position by instrument and PosNat
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. : 	PMSTA-51476 - DDV - 230124
**
*************************************************************************/
STATIC int FIN_CmpPosByInstrPosNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, ExtPos_InstrId, ExtPos_InstrId, IdType)) != 0)
    {
        return(cmp);
    }

    return(FIN_GetFXFwdWithTwoLegsPosNat(*ptr1) - FIN_GetFXFwdWithTwoLegsPosNat(*ptr2));
}


/************************************************************************
**
**  Function    :   FIN_FilterRiskOrigOnFXFwdWithTwoLegsAgainsPtfCurr()
**
**  Description :   Check if position have risk origin on SubNat_FXFwd_TwoLegsAgainsPtfCurr
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   DDV - PMSTA-48144 - 230123
**
*************************************************************************/
STATIC int FIN_FilterRiskOrigOnFXFwdWithTwoLegsAgainsPtfCurr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
    DBA_DYNFLD_STP          instrStp = NULLDYNST, forwardInstrStp = NULLDYNST;
    FLAG_T                  allocOk = FALSE;
    MemoryPool              mp;

    if (GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) != NULL)
    {
        instrStp = *GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext);
    }

    if (IS_NULLFLD(instrStp, A_Instr_RiskOrigGenInstrId) == FALSE)
    {
        if (IS_NULLFLD(instrStp, A_Instr_RiskOrigGenInstr_Ext) == TRUE ||
            GET_EXTENSION_PTR(instrStp, A_Instr_RiskOrigGenInstr_Ext) == NULL ||
            (forwardInstrStp = *GET_EXTENSION_PTR(instrStp, A_Instr_RiskOrigGenInstr_Ext)) == NULLDYNST ||
            CMP_DYNFLD(forwardInstrStp, instrStp, A_Instr_Id, A_Instr_RiskOrigGenInstrId, IdType) != 0)
        {
            if (DBA_GetInstrById(GET_ID(instrStp, A_Instr_RiskOrigGenInstrId), TRUE, &allocOk,
                                 &forwardInstrStp, NULL, UNUSED, UNUSED) == RET_SUCCEED)
            {
                if (allocOk == TRUE)
                {
                    mp.owner(forwardInstrStp);
                    SYS_BreakOnDebug(); /* this must never happend */
                }
            }
        }
    }

    if (forwardInstrStp != NULLDYNST && GET_ENUM(forwardInstrStp, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
    {
        return(TRUE);
    }

    return(FALSE);
}

/************************************************************************
*
*  Function    : DBA_FilterExtPosId()
*
*  Description : return only extop  with id 
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : WEALTH-1645 Vishnu 2023-09-15
*
*  Last modif. :
*
*************************************************************************/
STATIC int DBA_FilterExtPosId(DBA_DYNFLD_STP extOp, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP opPtr)
{

	if (CMP_DYNFLD(extOp, opPtr, ExtOp_OpId, S_Op_Id, IdType) == 0)
	{
		return TRUE;
	}

	return FALSE;
}

/************************************************************************
**
**  Function    :   FIN_CreateFXSplitLegs()
**
**  Description :   Update position for instrument with new subnature SubNat_FXFwd_TwoLegsAgainsPtfCurr
**
**  Arguments   :   posHierHead   position hierarchy header pointer
**
**
**  Return      :   ret code
**
**  Creation D. :   PMSTA-51476 - DDV - 221214
**
*************************************************************************/
RET_CODE FIN_CreateFXSplitLegs(DBA_DYNFLD_STP domainPtr,
	                           DBA_HIER_HEAD_STP posHierHead)
{
    DBA_DYNFLD_STP          *extractPos = (DBA_DYNFLD_STP*)NULL;
    int                     posNbr, i;
    RET_CODE                ret = RET_SUCCEED;
    MemoryPool              mp;
	DBA_DYNFLD_STP          sOpStp = mp.allocDynst(FILEINFO, S_Op);
	DBA_DYNFLD_STP          aOpStp = mp.allocDynst(FILEINFO, A_Op);
	FLAG_T                  allocOk = FALSE;
	DBA_DYNFLD_STP          underlyInstr = NULLDYNST;
	DbiConnectionHelper     connHelper;

	DBA_SetHierLnkUsed(posHierHead, A_Instr, A_Instr_UnderlyInstr_Ext);
	DBA_SetHierLnkUsed(posHierHead, A_Instr, A_Instr_RiskOrigGenInstr_Ext);

    if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, FIN_FilterFXFwdWithTwoLegsAgainsPtfCurr, FIN_CmpPosByInstrPosNat, &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return (ret);
    }
    mp.owner(extractPos);

    for (i = 0; i < posNbr; i++)
    {
		if (FIN_GetFXFwdWithTwoLegsPosNat(extractPos[i]) == PosNat_None)
		{
			continue;
		}

		DBA_DYNFLD_STP          forwardInstrStp = NULLDYNST;

		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
			forwardInstrStp = *GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext);
		}

		/* PMSTA-51476 - DDV - 221214- For main leg, keep original underlying instrument */
		/*                             For account leg, get second cash account to use it as new underlying instrument */
		if (FIN_GetFXFwdWithTwoLegsPosNat(extractPos[i]) == PosNat_MainAcctPos)
		{
			if (IS_NULLFLD(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == TRUE ||
				GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == NULL ||
				(underlyInstr = *GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext)) == NULLDYNST ||
				 CMP_DYNFLD(underlyInstr, forwardInstrStp, A_Instr_Id, A_Instr_UnderlyInstrId, IdType) != 0)
			{
				if (DBA_GetInstrById(GET_ID(forwardInstrStp, A_Instr_UnderlyInstrId), TRUE, &allocOk,
					&underlyInstr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)
				{
					DBA_ForceLink(posHierHead, A_Instr, A_Instr_UnderlyInstr_Ext, forwardInstrStp, underlyInstr);

					if (allocOk == TRUE)
					{
						mp.owner(underlyInstr);
						SYS_BreakOnDebug(); /* this must never happend */
					}
				}
			}
		}
		else
		{
			/* Load operation to have cash account of second leg */
			allocOk = FALSE;

			SET_ID(sOpStp, S_Op_Id, GET_ID(extractPos[i], ExtPos_OpenOpId));
			bool validOp = false;

			if (GET_ID(extractPos[i], ExtPos_OpenOpId) > 0)
			{
				if ((connHelper.dbaGet(Op, UNUSED, sOpStp, &aOpStp)) == RET_SUCCEED)
				{
					validOp = true;
				}
			}
			else
			{
				/*Since draft order get the operation from hier */
				DBA_DYNFLD_STP* cExtOpTab = NULLDYNSTPTR;
				int cExtOpNbr = 0;

				if (DBA_ExtractHierEltRecWithFilterSt(posHierHead,
					ExtOp,
					FALSE,
					DBA_FilterExtPosId,
					sOpStp,
					NULLFCT,
					&cExtOpNbr,
					&cExtOpTab) == RET_SUCCEED &&
					cExtOpNbr > 0)
				{
					/*Copy the operation details */
					COPY_DYNFLD(aOpStp, A_Op, A_Op_RefNatEn, cExtOpTab[0], ExtOp, ExtOp_RefNatEn);
					COPY_DYNFLD(aOpStp, A_Op, A_Op_AccInstrId, cExtOpTab[0], ExtOp, ExtOp_AcctId);
					COPY_DYNFLD(aOpStp, A_Op, A_Op_Acc2InstrId, cExtOpTab[0], ExtOp, ExtOp_Acct2CurrId);
					COPY_DYNFLD(aOpStp, A_Op, A_Op_Acc3InstrId, cExtOpTab[0], ExtOp, ExtOp_Acct3CurrId);
					validOp = true;
				}
				FREE(cExtOpTab);
			}

			if(validOp)
			{
				if (GET_ENUM(aOpStp, A_Op_RefNatEn) == PosRefNat_FwdOpen)
				{
					if (IS_NULLFLD(aOpStp, A_Op_AccInstrId) == FALSE)
					{
						if (IS_NULLFLD(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == TRUE ||
							GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == NULL ||
							(underlyInstr = *GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext)) == NULLDYNST ||
							CMP_DYNFLD(underlyInstr, aOpStp, A_Instr_Id, A_Op_AccInstrId, IdType) != 0)
						{
							if (DBA_GetInstrById(GET_ID(aOpStp, A_Op_AccInstrId), TRUE, &allocOk,
								                 &underlyInstr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)
							{
								if (allocOk == TRUE)
								{
									mp.owner(underlyInstr);
									SYS_BreakOnDebug(); /* this must never happend */
								}
							}
						}
					}
				}
				else if (GET_ENUM(aOpStp, A_Op_RefNatEn) == PosRefNat_FwdClose)
				{
					if (IS_NULLFLD(aOpStp, A_Op_Acc2InstrId) == FALSE)
					{
						if (IS_NULLFLD(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == TRUE ||
							GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == NULL ||
							(underlyInstr = *GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext)) == NULLDYNST ||
							CMP_DYNFLD(underlyInstr, aOpStp, A_Instr_Id, A_Op_Acc2InstrId, IdType) != 0)
						{
							if (DBA_GetInstrById(GET_ID(aOpStp, A_Op_Acc2InstrId), TRUE, &allocOk,
								                 &underlyInstr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)
							{
								if (allocOk == TRUE)
								{
									mp.owner(underlyInstr);
									SYS_BreakOnDebug(); /* this must never happend */
								}
							}
						}
					}
				}
			}
		}

		/* PMSTA-51476 - DDV - 221214- For both forward legs, created a new instrument having ExtPos_PosCurrId as reference currency
									   and update fi fields (Gross, Net, Curr, ExchRateNet) */
		DBA_DYNFLD_STP          newInstrStp = mp.allocDynst(FILEINFO, A_Instr);

		if (underlyInstr != NULLDYNST && newInstrStp != NULLDYNST)
		{
			COPY_DYNST(newInstrStp, forwardInstrStp, A_Instr);
			SET_NULL_ID(newInstrStp, A_Instr_Id);

			COPY_DYNFLD(newInstrStp, A_Instr, A_Instr_ParentInstrId, forwardInstrStp, A_Instr, A_Instr_Id);
			COPY_DYNFLD(newInstrStp, A_Instr, A_Instr_RefCurrId, extractPos[i], ExtPos, ExtPos_PosCurrId);

			COPY_DYNFLD(newInstrStp, A_Instr, A_Instr_UnderlyInstrId, underlyInstr, A_Instr, A_Instr_Id);

			DBA_ForceLink(posHierHead, A_Instr, A_Instr_UnderlyInstr_Ext, newInstrStp, underlyInstr);

			COPY_DYNFLD(extractPos[i], ExtPos, ExtPos_InstrCurrId, newInstrStp, A_Instr, A_Instr_RefCurrId);
			COPY_DYNFLD(extractPos[i], ExtPos, ExtPos_InstrGrossAmt, extractPos[i], ExtPos, ExtPos_PosGrossAmt);
			COPY_DYNFLD(extractPos[i], ExtPos, ExtPos_InstrNetAmt, extractPos[i], ExtPos, ExtPos_PosNetAmt);
			SET_EXCHANGE(extractPos[i], ExtPos_InstrExchRate, 1.0);

			if (DBA_AddHierRecord(posHierHead, newInstrStp, A_Instr, FALSE, HierAddRec_NoLnk) == RET_SUCCEED)
			{
				mp.remove(newInstrStp);

				bool bSameInstr = false;

				do
				{
					bSameInstr = false;

					SET_ID(extractPos[i], ExtPos_InstrId, GET_ID(newInstrStp, A_Instr_Id));

					if ((ret = DBA_ForceLink(posHierHead, ExtPos, ExtPos_A_Instr_Ext, extractPos[i], newInstrStp)) != RET_SUCCEED)
					{
						FREE(extractPos);
						return ret;
					}

					if (i < (posNbr-1) && CMP_DYNFLD(extractPos[i+1], forwardInstrStp, ExtPos_InstrId, A_Instr_Id, IdType) == 0 &&
						FIN_GetFXFwdWithTwoLegsPosNat(extractPos[i]) == FIN_GetFXFwdWithTwoLegsPosNat(extractPos[i + 1]))
					{
						bSameInstr = true;
						i++;
					}

				} while (bSameInstr);
			}
		}
    }

	return ret;
}

/************************************************************************
**
**  Function    :   FIN_CreateForwardRiskOrigin()
**
**  Description :   Create risk origine instrument for position having 
**                  instrument with SubNat_FXFwd_TwoLegsAgainsPtfCurr
**					
**					
**
**  Arguments   :   DBA_HIER_HEAD_STP   position hierarchy header pointer
**
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   PMSTA-48144 - 220608 - DDV
**
*************************************************************************/
RET_CODE FIN_CreateForwardRiskOrigin(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
    DBA_DYNFLD_STP      *extractPos = (DBA_DYNFLD_STP*)NULL;
    int                 posNbr, i;
    RET_CODE            ret = RET_SUCCEED;
    FLAG_T              allocOk;
    DBA_DYNFLD_STP      underlyInstr = NULL;
    MemoryPool          mp;

	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, FIN_FilterFXFwdWithTwoLegsAgainsPtfCurr, FIN_CmpPosByInstrPosNat, &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return (ret);
    }
    mp.owner(extractPos);

    for (i = 0; i < posNbr; i++)
    {
		if (FIN_GetFXFwdWithTwoLegsPosNat(extractPos[i]) == PosNat_None)
		{
			continue;
		}

		DBA_DYNFLD_STP          forwardInstrStp = NULLDYNST;

		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
			forwardInstrStp = *GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext);
		}

		if (IS_NULLFLD(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == TRUE ||
			GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext) == NULL ||
			(underlyInstr = *GET_EXTENSION_PTR(forwardInstrStp, A_Instr_UnderlyInstr_Ext)) == NULLDYNST ||
			CMP_DYNFLD(underlyInstr, forwardInstrStp, A_Instr_Id, A_Instr_UnderlyInstrId, IdType) != 0)
		{
			if (DBA_GetInstrById(GET_ID(forwardInstrStp, A_Instr_UnderlyInstrId), TRUE, &allocOk,
			                     &underlyInstr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)

			{
				if (allocOk == TRUE)
				{
					mp.owner(underlyInstr);
					SYS_BreakOnDebug(); /* this must never happend */
				}
			}

			DBA_ForceLink(posHierHead, A_Instr, A_Instr_UnderlyInstr_Ext, forwardInstrStp, underlyInstr);
		}

		if (underlyInstr != NULLDYNST)
		{
			DBA_DYNFLD_STP          newInstrStp = NULLDYNST;

			DBA_CreateCashLegInstr(posHierHead, domainPtr, underlyInstr, forwardInstrStp, &newInstrStp);

			if (newInstrStp != NULLDYNST)
			{
				bool bSameInstr = false;

				do
				{
					bSameInstr = false;

					SET_ID(extractPos[i], ExtPos_InstrId, GET_ID(newInstrStp, A_Instr_Id));
					DBA_ForceLink(posHierHead, ExtPos, ExtPos_A_Instr_Ext, extractPos[i], newInstrStp);

					if (i < (posNbr - 1) && CMP_DYNFLD(extractPos[i], extractPos[i + 1], ExtPos_InstrId, ExtPos_InstrId, IdType) == 0)
					{
						bSameInstr = true;
						i++;
					}

				} while (bSameInstr);
			}
		}
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_ResetRiskOriginToForward()
**
**  Description :   Reset position on risk origine instrument to be back
**                  on initial instrument (generic one). It is done for
**                  instrument with SubNat_FXFwd_TwoLegsAgainsPtfCurr
**
**
**  Arguments   :   DBA_HIER_HEAD_STP   position hierarchy header pointer
**
**
**  Return      :   TRUE or FALSE
**
**  Creation D. :   PMSTA-48144 - 220608 - DDV
**
*************************************************************************/
RET_CODE FIN_ResetRiskOriginToForward(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
    DBA_DYNFLD_STP      *extractPos = (DBA_DYNFLD_STP*)NULL, riskOriInstrStp = NULLDYNST, forwardInstrStp = NULLDYNST;
    int                 posNbr, i;
    FLAG_T              allocOk;
    RET_CODE            ret = RET_SUCCEED;
    MemoryPool          mp;

    if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, FIN_FilterRiskOrigOnFXFwdWithTwoLegsAgainsPtfCurr, NULLFCT, &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return (ret);
    }
    mp.owner(extractPos);

    for (i = 0; i < posNbr; i++)
    {
        if (extractPos[i] != NULLDYNST && GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
			(riskOriInstrStp = *GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext)) != NULLDYNST)
		{
			forwardInstrStp = NULLDYNST;

			if (IS_NULLFLD(riskOriInstrStp, A_Instr_RiskOrigGenInstrId) == FALSE)
			{

				if (IS_NULLFLD(riskOriInstrStp, A_Instr_RiskOrigGenInstr_Ext) == TRUE ||
					GET_EXTENSION_PTR(riskOriInstrStp, A_Instr_RiskOrigGenInstr_Ext) == NULL ||
					(forwardInstrStp = *GET_EXTENSION_PTR(riskOriInstrStp, A_Instr_RiskOrigGenInstr_Ext)) == NULLDYNST ||
					CMP_DYNFLD(forwardInstrStp, riskOriInstrStp, A_Instr_Id, A_Instr_RiskOrigGenInstrId, IdType) != 0)
				{
					if (DBA_GetInstrById(GET_ID(riskOriInstrStp, A_Instr_RiskOrigGenInstrId), TRUE, &allocOk,
						                 &forwardInstrStp, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)
					{
						DBA_ForceLink(posHierHead, A_Instr, A_Instr_RiskOrigGenInstr_Ext, riskOriInstrStp, forwardInstrStp);

						if (allocOk == TRUE)
						{
							mp.owner(forwardInstrStp);
							SYS_BreakOnDebug(); /* this must never happend */
						}
					}
				}
			}

			if (forwardInstrStp != NULLDYNST)
			{
				SET_ID(extractPos[i], ExtPos_InstrId, GET_ID(forwardInstrStp, A_Instr_Id));
				DBA_ForceLink(posHierHead, ExtPos, ExtPos_A_Instr_Ext, extractPos[i], forwardInstrStp);
			}
		}
    }








    return ret;
}
/************************************************************************
**
**Function     :   FIN_FilterTopHierPtf()
**
** Description :   Select the Head Parent
**
** Arguments   :   ptr1		 pointer on dynamic structure
**				   ptr2		 pointer on dynamic structure
*                  dynStTp		 dynamic structure type
**
** Return	   :   TRUE or FALSE
*
** Creation    :   WEALTH-10005 - Deepthi - 20240627
** Modification :
**
	*************************************************************************/
	STATIC int FIN_FilterTopHierPtf(DBA_DYNFLD_STP ptfdynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	return (IS_NULLFLD(ptfdynSt, A_Ptf_ParentPortId) == TRUE) ? TRUE : FALSE;
}
/************************************************************************

/************************************************************************
**      END  finsrv02.c                                          UNICIBLE
*************************************************************************/

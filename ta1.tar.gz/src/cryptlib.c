/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define CRYPTLIB_C

/***********************
***  includes files  ***
***********************/
#define STRING_H
#include "unidef.h"         /* Mandatory */
#include "syslib.h"         /* PMO - Rename our sys.h to syslib.h and use it */
#include "dba.h"
#include "crypt.h"

#include "crypto.h"
#include "crypto-buffer.h"
#include "crypto-string.h"

EXTERN  void  _CRYPT_HashMD5(char *input, char **pOutput)
{
    char *output = *pOutput;

    if  (input == NULL)
        return;

    output = (char *) REALLOC(output, 33 * sizeof(char));

    if  (output == NULL)
    {
        MSG_SendMesg(
            RET_MEM_ERR_ALLOC, 0, FILEINFO);

        return;
    }
    

    try
    {
        CryptoProvider* provider = CryptoManager::getInstance().getProvider(CryptoManager::OpenSSL);

        CryptoBuffer*digest = NULL;

		provider->Hash(
			HashAlgo::MD5, input, digest);

        char *scan = output;

        for (size_t n = 0; n < digest->size(); n++)
        {
            unsigned char c = (unsigned char)digest->buffer()[n];
            unsigned char v;

            v =  (c >> 4) & 0x0f;
            *scan++ = v >= 10 ? v - 10 + 'a': v + '0';
            v =  (c >> 0) & 0x0f;
            *scan++ = v >= 10 ? v - 10 + 'a': v + '0';
        }

        delete digest;

        delete provider;
    }
    catch (CryptoException exception)
    {
        MSG_SendMesg(
            RET_GEN_ERR_PERSONAL, 0, FILEINFO, exception.what());
    }

    output[32] = END_OF_STRING;

    *pOutput = output;
}

EXTERN  void  _CRYPT_HashSHA256(char *input, char **pOutput)
{
    char *output = *pOutput;

    if  (input == NULL)
        return;

    output = (char *) REALLOC(output, 65 * sizeof(char));

    if  (output == NULL)
    {
        MSG_SendMesg(
            RET_MEM_ERR_ALLOC, 0, FILEINFO);

        return;
    }
    

    try
    {
        CryptoProvider* provider = CryptoManager::getInstance().getProvider(CryptoManager::OpenSSL);

        CryptoBuffer*digest = NULL;

		provider->Hash(
			HashAlgo::SHA256, input, digest);

        char *scan = output;

        for (size_t n = 0; n < digest->size(); n++)
        {
            unsigned char c = (unsigned char)digest->buffer()[n];
            unsigned char v;

            v =  (c >> 4) & 0x0f;
            *scan++ = v >= 10 ? v - 10 + 'a': v + '0';
            v =  (c >> 0) & 0x0f;
            *scan++ = v >= 10 ? v - 10 + 'a': v + '0';
        }

        delete digest;

        delete provider;
    }
    catch (CryptoException exception)
    {
        MSG_SendMesg(
            RET_GEN_ERR_PERSONAL, 0, FILEINFO, exception.what());
    }

    output[64] = END_OF_STRING;

    *pOutput = output;
}

EXTERN void _CRYPT_HashMD5Salted(char *input, char *salt, char **pOutput)
{
    const size_t  size = strlen(input) + strlen (salt) + 2;
    char *saltedInput = (char*) CALLOC(size , sizeof(char*));

    if (NULL != saltedInput)
    {
        snprintf(saltedInput, size, "%s:%s" , input, salt);

        _CRYPT_HashMD5(saltedInput, pOutput);
        
        DBA_PasswordClear(
            saltedInput, strlen(saltedInput));

        FREE(saltedInput);
    }
}

EXTERN void _CRYPT_HashSHA256Salted(char *input, char *salt, char **pOutput)
{
    const size_t  size = strlen(input) + strlen (salt) + 2;
    char *saltedInput = (char*) CALLOC(size , sizeof(char*));

    if (NULL != saltedInput)
    {
        snprintf(saltedInput, size, "%s:%s" , input, salt);

        _CRYPT_HashSHA256(saltedInput, pOutput);
        
        DBA_PasswordClear(
            saltedInput, strlen(saltedInput));

        FREE(saltedInput);
    }
}

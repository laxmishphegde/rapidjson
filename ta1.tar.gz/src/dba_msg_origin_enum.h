/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBA_MSG_ORIGIN_ENUM_H
#define DBA_MSG_ORIGIN_ENUM_H
typedef enum {
	NullHandler=-1,	
	ServerHandler,
	ClientHandler 
} DBA_MSG_ORIGIN_ENUM;
#endif	 /* ifndef DBA_MSG_ORIGIN_ENUM_H */

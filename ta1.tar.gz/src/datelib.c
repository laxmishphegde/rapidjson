/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DATELIB_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define TIME_H
#define STDLIB_H
#define STRING_H

#include "unidef.h"     /* Mandatory */
#include "date.h"
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#include "dba.h"
#include "scelib.h"

using namespace std;

extern DBA_RDBMS_ENUM EV_RdbmsDdlGen;

/************************************************************************
**      Static definitions & data
*************************************************************************/
static DATE_MONTH_NAME		SV_monthNameTb;
static DATE_WEEK_DAY_NAME	SV_weekDayTb;

/***************************************************************
** Macros DAYSBEFOREMONTH*
** Arguments : M is the month number in the year (ex: 2),
**             Y is the year (ex: 1994),
**             LY is 1 if the year is a leap year otherwise 0.
** DAYSBEFOREMONTHY  returns the number of days in the year Y
**                   before the month M.
** DAYSBEFOREMONTHLY returns the number of days in a year (leap year or not)
**                   before the month M.
**
****************************************************************/
#define DAYSBEFOREMONTHLY(M,LY) ((long)(M)<=2 ? ((long)M-1)*31 : ((long)M*489)/16-32+((long)LY))
#define DAYSBEFOREMONTHY(M,Y) DAYSBEFOREMONTHLY(M, (LEAP_YEAR(Y)==TRUE)?1:0)

/***************************************************************
** Macros DAYSINMONTH*
** Arguments: M is the month number in the year (ex: 2),
**            Y is the year (ex: 1994),
**            LY is 1 if the year is a leap year otherwise 0.
** February have 28 days on non leap year, 29 on leap year.
** April, June, September and November have 30 days.
** Other months have 31 days.
** DAYSINMONTHY  returns the number of days in the month M of the year Y.
** DAYSINMONTHLY returns the number of days in the month M of a
**               year (leap year or not).
**
***************************************************************/
#define DAYSINMONTHLY(M,LY) ((long)((M)==2 ? 28 + (long)(LY) : 30 + ((((long)(M)*9)/8)%2)))
#define DAYSINMONTHY(M,Y) ((DAY_T)(DAYSINMONTHLY(M, (LEAP_YEAR(Y)==TRUE)?1:0)))

/***************************************************************
** Macro DATE_CMP
** Compare two received dates, the number returned doesn't
** correspond to the difference in days between two dates.
***************************************************************/
#define DATE_CMP(D1,D2)	(D1 - D2)

/***************************************************************
** Origin date used for functions DATE_DateToDnum() and DATE_DnumToDate().
** Must be 1 plus a multiple of 400
***************************************************************/
#define DNUM0YEAR 1601
#define DNUM0MONTH   1
#define DNUM0DAY     1
#define DNUM0DATE    DATE_PUT(DNUM0YEAR, DNUM0MONTH, DNUM0DAY)

/***************************************************************
** Definitions of number of days in normal periods.
** The "leap" periods contain 1 day more or less.
***************************************************************/
#define DAYSIN400YEAR 146097L    /* = 400 * 365 + 100 - 4 + 1 */
#define DAYSIN100YEAR  36524L    /* = 100 * 365 + 25 - 1 = DAYSIN400YEAR / 4 */
#define DAYSIN4YEAR     1461L    /* = 4 * 365 + 1 = DAYSIN100YEAR / 25 + 1 */
#define DAYSIN1YEAR      365L

/************************************************************************
**      Functions
*************************************************************************/

/* Internal functions prototype */

STATIC YEAR_T	   DATE_TreatYearFormat(const char *, DATE_FORMAT_STP, int *);
STATIC MONTH_T	   DATE_TreatMonthFormat(const char *, DATE_FORMAT_STP, int *),
	           DATE_MonthNbr(char *, int);
STATIC DAY_T	   DATE_TreatDayFormat(const char *, DATE_FORMAT_STP, int *);
STATIC DATE_DNUM_T DATE_DateToDnum(DATE_T);
STATIC DATE_T      DATE_DnumToDate(DATE_DNUM_T);
STATIC std::string DATE_ORDRE_ENUM_TAB[] = { "Ymd", "Dmy", "Mdy", "Iso" };

char *DATE_GetStrTime(char *strTime)
{
	DATETIME_T dt;
	HOUR_T h; MINUTE_T m; SECOND_T s;
	DATE_CurrentDateTime(&dt);
	TIME_Get(dt.time, &h, &m, &s);
	sprintf(strTime,"%02d:%02d:%02d",h,m,s);
	return(strTime);	/* DVP172 */
}


/***************************************************************
** Number definitions and macros used for write a date in format
** year  (1-9999) in bytes 1-2
** month (1-12)   in byte 3
** day   (1-31)   in byte 4
****************************************************************/
/* date 11 1111 1111 1111 1111 1 1111 */
#define DATE_WRITE_D 0x7FFFE0L     /* day 11 1111 1111 1111 1111 0 0000 */
#define DATE_WRITE_M 0x7FFE1FL     /* month 11 1111 1111 1111 0000 1 1111 */
#define DATE_WRITE_Y 0x0001FFL     /* year 00 0000 0000 0000 1111 1 1111 */
#define DATE_READ_D  0x00001FL     /* day 00 0000 0000 0000 0000 1 1111 */
#define DATE_READ_M  0x0001E0L     /* month 00 0000 0000 0000 1111 0 0000 */
#define DATE_READ_Y  0x7FFE00L     /* year 11 1111 1111 1111 0000 0 0000 */

/* Write day, month, year into date number */
#define DATE_PUT_D(A,D) (((A) & DATE_WRITE_D) | (D))      /* Write day       */
#define DATE_PUT_M(A,M) (((A) & DATE_WRITE_M) | ((M)<<5)) /* Write month     */
#define DATE_PUT_Y(A,Y) (((A) & DATE_WRITE_Y) | ((Y)<<9))/* Write year      */
#define DATE_PUT(Y,M,D) ((D) + ((M)<<5) + ((Y)<<9))      /* Write full date */

/* Extract day, month, year */
#define DATE_GET_D(D) ((DAY_T)((D) & DATE_READ_D))        /* Extract day     */
#define DATE_GET_M(D) ((MONTH_T)(((D) & DATE_READ_M)>>5)) /* Extract month   */
#define DATE_GET_Y(D) ((YEAR_T)(((D) & DATE_READ_Y)>>9)) /* Extract year    */


/***************************************************************
**	Number definitions and macros used for write a time in format
**	second (1-59) in bytes 1-2
**	minute (1-59) in byte 3
**	hour   (1-24) in byte 4
**
**  Modif.	:
****************************************************************/
#define TIME_WRITE_MS 0x1FFFF00000L  /* microsecond 1 1111 11 1111 11 1111 0000 0000 0000 0000 0000 */
#define TIME_WRITE_S  0x1FFC0FFFFFL  /* second 1 1111 11 1111 00 0000 1111 1111 1111 1111 1111 */
#define TIME_WRITE_M  0x1F03FFFFFFL  /* minute 1 1111 00 0000 11 1111 1111 1111 1111 1111 1111 */
#define TIME_WRITE_H  0x00FFFFFFFFL  /* hour 0 0000 11 1111 11 1111 1111 1111 1111 1111 1111 */
#define TIME_READ_MS  0x00000FFFFFL  /* microsecond 0 0000 00 0000 00 0000 1111 1111 1111 1111 1111 */
#define TIME_READ_S   0x0003F00000L  /* second 0 0000 00 0000 11 1111 0000 0000 0000 0000 0000 */
#define TIME_READ_M   0x00FC000000L  /* minute 0 0000 11 1111 00 0000 0000 0000 0000 0000 0000 */
#define TIME_READ_H   0x1F00000000L  /* hour 1 1111 00 0000 00 0000 0000 0000 0000 0000 0000 */

/* Write hour, minute, second into time number */
#define TIME_PUT_MS(T,MS) (((T) & TIME_WRITE_MS) | (MS))   /* Write microsecond   */
#define TIME_PUT_S(T,S) (((T) & TIME_WRITE_S) | (static_cast<TIME_T>(S)<<20))    /* Write second        */
#define TIME_PUT_M(T,M) (((T) & TIME_WRITE_M) | (static_cast<TIME_T>(M)<<26))    /* Write minute        */
#define TIME_PUT_H(T,H) (((T) & TIME_WRITE_H) | (static_cast<TIME_T>(H)<<32))    /* Write hour          */

/* Extract hour, minute, second */
#define TIME_GET_MS(T) (static_cast<MICROSECOND_T>((T) & TIME_READ_MS))  /* Extract microsecond   */
#define TIME_GET_S(T) (static_cast<SECOND_T>(((T) & TIME_READ_S)>>20))         /* Extract second   */
#define TIME_GET_M(T) (static_cast<MINUTE_T>(((T) & TIME_READ_M)>>26))    /* Extract minute */
#define TIME_GET_H(T) (static_cast<HOUR_T>(((T) & TIME_READ_H)>>32))     /* Extract hour  */



/*******************************************************************************
**     Class Definitions
*******************************************************************************/
DatePeriod::DatePeriod()
{
	m_begin = { SYB_BEGIN_DATE, 0};
	m_end = { MAGIC_END_DATE, 0};
}

DatePeriod::DatePeriod(const DATETIME_T & beginDate, const DATETIME_T & endDate)
{
	DatePeriod();
	set(beginDate,endDate);
}

DatePeriod::DatePeriod(const DATE_T & beginDate, const DATE_T & endDate)
{
	DatePeriod();
	set(beginDate,endDate);
}


bool DatePeriod::operator< (const DatePeriod & rhs) const
{
	return this->cmpBegin(rhs.m_begin) < 0
		|| (this->cmpBegin(rhs.m_begin) == 0 && this->cmpEnd(rhs.m_end) < 0);
}

bool DatePeriod::operator== (const DatePeriod & datePeriod) const
{
    return this->m_begin == datePeriod.m_begin && this->m_end == datePeriod.m_end;
}

void DatePeriod::operator= (const DatePeriod & datePeriod)
{
    this->m_begin = datePeriod.m_begin;
	this->m_end = datePeriod.m_end;
}

void DatePeriod::setBegin(const DATETIME_T & beginDate)
{	
	if (0 != beginDate.date) 
    {
        m_begin = beginDate;
    }
}

void DatePeriod::setEnd(const DATETIME_T & endDate)
{
	if (0 != endDate.date) 
    {
        m_end = endDate; 
    }
}

void DatePeriod::setBegin(const DATE_T & beginDate)
{	
	if (0 != beginDate) 
    {
        m_begin.date = beginDate;
		m_begin.time = 0;
    }
}

void DatePeriod::setEnd(const DATE_T & endDate)
{
	if (0 != endDate) 
    {
        m_end.date = endDate;
		m_end.time = 0;
    }
}

void DatePeriod::set(const DATETIME_T & beginDate, const DATETIME_T & endDate)
{
	setBegin(beginDate);
	setEnd(endDate);
}

void DatePeriod::set(const DATE_T & beginDate, const DATE_T & endDate)
{
	setBegin(beginDate);
	setEnd(endDate);
}

int DatePeriod::cmpBegin(const DATETIME_T & rhs) const
{
    return DATETIME_CMP(m_begin,rhs);
}

int DatePeriod::cmpEnd(const DATETIME_T & rhs) const
{
     return DATETIME_CMP(m_end,rhs);
}

// Does not compare time
int DatePeriod::cmpBegin(const DATE_T & rhs) const
{
	return DATE_CMP(m_begin.date,rhs);
}
// Does not compare time
int DatePeriod::cmpEnd(const DATE_T & rhs) const
{
     return DATE_CMP(m_end.date,rhs);
}


int DatePeriod::cmpPeriod(const DatePeriod & rhs) const
{
    int cmp = this->cmpBegin(rhs.m_begin);

    if (0 == cmp)
    {
        return this->cmpEnd(rhs.m_end);
    }

    return cmp;
}

bool DatePeriod::isValid() const
{
    return DATETIME_CMP(m_begin, m_end) < 0;
}

/* PMSTA-55400 - DDV - 250220 - Check if overlap exist for 2 periods */
bool DatePeriod::isOverlap(const DatePeriod& period) const
{
	return((this->cmpBegin(period.m_begin) >= 0 && this->cmpBegin(period.m_end) <= 0) ||
           (this->cmpEnd(period.m_begin)   >= 0 && this->cmpEnd(period.m_end)   <= 0) ||
           (period.cmpBegin(this->m_begin) >= 0 && period.cmpBegin(this->m_end) <= 0) ||
		   (period.cmpEnd(this->m_begin)   >= 0 && period.cmpEnd(this->m_end)   <= 0));
}

/* PMSTA-55400 - DDV - 250220 - Merge period given as parameter to with this period */
void DatePeriod::mergePeriod(const DatePeriod& period)
{
	if (period.m_begin.date < this->m_begin.date)
	{
		this->m_begin.date = period.m_begin.date;

	}

	if (period.m_end.date > this->m_end.date)
	{
		this->m_end.date = period.m_end.date;

	}
}

size_t DatePeriodVec::size() const
{
	return m_datePeriodVec.size();
}

void DatePeriodVec::clear()
{
	m_datePeriodVec.clear();
}

bool DatePeriodVec::empty() const
{
	return m_datePeriodVec.empty();
}

/************************************************************************
** Ranges must be inserted in order of begin date from hierarchy
*************************************************************************/
void DatePeriodVec::push_back(const DatePeriod & datePeriod)
{
	    m_datePeriodVec.push_back(datePeriod);
}

/************************************************************************
** Ranges must be inserted in order of begin date from hierarchy
*************************************************************************/
void DatePeriodVec::push_back(const DATETIME_T & begDate, const DATETIME_T & endDate)
{
	const DatePeriod datePeriod(begDate,endDate);
	m_datePeriodVec.push_back(datePeriod);
}


size_t DatePeriodVec::count(const DatePeriod & datePeriod) const
{
    for(size_t i=0;i<m_datePeriodVec.size();i++)
    {
        if(m_datePeriodVec[i] == datePeriod)
			return 1;
    }
	return 0;
}


DatePeriod& DatePeriodVec::operator[](size_t n)
{
    return m_datePeriodVec[n];
}

bool DatePeriodVec::isValid() const
{	// Each range must be valid and not overlap, and be in correct order
	for(size_t i=0;i<m_datePeriodVec.size();i++)
	{
	    if(m_datePeriodVec[i].isValid() == false
	        || (i > 0 && m_datePeriodVec[i].cmpBegin(m_datePeriodVec[i-1].getEnd()) < 0))
		{
			return false;
		}
	}    
	return true;
}


size_t DatePeriodSet::size() const
{
	return m_datePeriodSet.size();
}

void DatePeriodSet::clear()
{
	m_datePeriodSet.clear();
}

bool DatePeriodSet::empty() const
{
	return m_datePeriodSet.empty();
}

/************************************************************************
** Ranges must be inserted in order of begin date from hierarchy
*************************************************************************/
void DatePeriodSet::insert(const DatePeriod & datePeriod)
{
	    m_datePeriodSet.insert(datePeriod);
}

/* PMSTA-55400 - DDV - 250220 */
void DatePeriodSet::erase(const DatePeriod& datePeriod)
{
	m_datePeriodSet.erase(datePeriod);
}

/************************************************************************
** Ranges must be inserted in order of begin date from hierarchy
*************************************************************************/
void DatePeriodSet::insert(const DATETIME_T & begDate, const DATETIME_T & endDate)
{
	const DatePeriod datePeriod(begDate,endDate);	
	m_datePeriodSet.insert(datePeriod);
}

size_t DatePeriodSet::count(const DatePeriod & datePeriod) const
{
    return m_datePeriodSet.count(datePeriod);
}

bool DatePeriodSet::isValid() const
{	// Each range must be valid and not overlap, and be in correct order
	int i=0;
	DatePeriod lastPeriod;
	for(auto it = m_datePeriodSet.begin(); it != m_datePeriodSet.end();++it)
	{
	    if(it->isValid() == false
	        || (i > 0 && it->cmpBegin(lastPeriod.getEnd()) < 0))
		{
			return false;
		}		
		i++;		
		lastPeriod = *it;
	}    
	return true;
}

void DatePeriodSet::copyToVector(DatePeriodVec & datePeriodVector) const
{
    for(auto it = m_datePeriodSet.begin(); it != m_datePeriodSet.end();++it)
    {
        datePeriodVector.push_back(*it);
    }
}

/* PMSTA-55400 - DDV - 250220 - Merge all possible periods for this period set */
void DatePeriodSet::mergePeriods()
{
	if (this->size() > 1)
	{
		DatePeriod previousPeriod = *(this->m_datePeriodSet.begin());
		auto       it = this->m_datePeriodSet.begin();

		++it;
		for (;it != this->m_datePeriodSet.end(); ++it)
		{
			if (previousPeriod.isOverlap(*it))
			{
				m_datePeriodSet.erase(previousPeriod);
				previousPeriod.mergePeriod(*it);
				m_datePeriodSet.erase(*it);
				m_datePeriodSet.insert(previousPeriod);
				it = m_datePeriodSet.find(previousPeriod);
			}

			previousPeriod = *it;
		}
	}
}

/************************************************************************
**
**  Function    :   DATE_Put()
**
**  Description :   Create a date number (depending on the received
**                  year, month and day) and return it.
**
**  Arguments   :   yyyy     Year
**                  mm       Month
**                  dd       Day
**
**  Return      :   Number which represent date.
**                  BAD_DATE if wrong date.
**
*************************************************************************/
DATE_T DATE_Put(YEAR_T yyyy, MONTH_T mm, DAY_T dd)
{
	DATE_T date;

	if (DATE_Check(yyyy, mm, dd) == TRUE)
		date = DATE_PUT(yyyy, mm, dd);
	else
		date = BAD_DATE;

	return(date);
}

/************************************************************************
**
**  Function    :   DATETIME_Put()
**
**  Description :   Create a datetime number (depending on the received
**                  year, month and day) and return it.
**
**  Arguments   :   yyyy     Year
**                  mm       Month
**                  dd       Day
**
**  Return      :   Number which represent date.
**                  BAD_DATE if wrong date. Time is zero
**
*************************************************************************/
DATETIME_T DATETIME_Put(YEAR_T yyyy, MONTH_T mm, DAY_T dd)
{
	DATETIME_T datetime;
    datetime.time = 0;
    datetime.date = DATE_Put(yyyy,mm,dd);
	return(datetime);
}

/************************************************************************
**
**  Function    :   DATE_Get()
**
**  Description :   Read the received date number and update year, month
**                  and day. If year, month or day is null, doesn't return
**                  the value.
**                  ex : DATE_Get(date, NULL, NULL, &day)
**                       -> modify only the day value.
**
**  Arguments   :   date   Date number
**                  yyyy   Pointer on year or NULL
**                  mm     Pointer on month or NULL
**                  dd     Pointer on day or NULL
**
**  Return      :   none
**
*************************************************************************/
void DATE_Get(DATE_T date, YEAR_T *yyyy, MONTH_T *mm, DAY_T *dd)
{
	if (dd != NULL) *dd = DATE_GET_D(date);
	if (mm != NULL) *mm = DATE_GET_M(date);
	if (yyyy != NULL) *yyyy = DATE_GET_Y(date);
}

/************************************************************************
**
**  Function    :   DATE_GetYear()
**
**  Description :   
**
**  Arguments   :   date:   Date number
**
**  Return      :   Year
**
*************************************************************************/
YEAR_T DATE_GetYear(DATE_T date)
{
    return DATE_GET_Y(date);
}

/************************************************************************
**
**  Function    :   DATE_Check()
**
**  Description :   Control if a date is valid.
**
**  Arguments   :   yyyy   Year
**                  mm     Month
**                  dd     Day
**
**  Return      :   TRUE if date is valid, FALSE elsewhere.
**
*************************************************************************/
int DATE_Check(YEAR_T yyyy, MONTH_T mm, DAY_T dd)
{
	/* Year mustn't have 5 positions, first date 1.1.1 */
	if (yyyy > 9999 || yyyy == 0)
		return(FALSE);

	/* Max month is 12 */
	if (mm > 12 || mm == 0)
		return(FALSE);

	/* February have 28 days on non leap year, 29 on leap year. */
	/* April, June, September and November have 30 days.        */
	/* Other months have 31 days.                               */
	if (dd > DAYSINMONTHY(mm, yyyy) || dd == 0)
		return(FALSE);

	return(TRUE);
}

/************************************************************************
**
**  Function    :   DATE_IsMagicEnd()
**
**  Description :   Control if a date is magic date (31/12/9999).
**
**  Arguments   :   yyyy   Year
**                  mm     Month
**                  dd     Day
**
**  Return      :   TRUE if date is magic date, FALSE elsewhere.
**
*************************************************************************/
int DATE_IsMagicEnd(YEAR_T yy, MONTH_T mm, DAY_T dd)
{
	if (yy == MAGIC_END_YEAR &&
	    mm == MAGIC_END_MONTH &&
	    dd == MAGIC_END_DAY)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DATE_Move()
**
**  Description :   Move from a date to another one that it returned.
**
**  Arguments   :   date   Start date
**                  shift  Previous, same, next, 2, 3, 4, ...
**                  unit   day, week, month, quarter, semester, year,
**                         decade, century. (DATE_UNIT_ENUM values)
**
**  Return      :   New date
**                  BAD_DATE if error.
**
**  Modif	:   REFXXX - RAK - 971230
**
*************************************************************************/
DATE_T DATE_Move(DATE_T date, int shift, DATE_UNIT_ENUM unit, FLAG_T forceMonthEnd)
{
	int         x;
	YEAR_T      y;
	MONTH_T     m;
	DAY_T       d, nd, ed;
	DATE_T      newD;
	DATE_DNUM_T dateNum;

	newD = date;                      /* Init new date at received date */

	if (shift == 0)
		return(newD);

	switch (unit)
	{
	/* day */
	case Day :
		dateNum = DATE_DateToDnum(newD);
		dateNum += shift;
		newD = DATE_DnumToDate(dateNum);
		break;

	/* week */
	case Week :
		dateNum = DATE_DateToDnum(newD);
		dateNum += (shift * 7);          /* 1 week is 7 days */
		newD = DATE_DnumToDate(dateNum);
		break;

	/* semester, quarter, month treated together (no break) */
	case Semester :
		shift *=2;                       /* 1 semester = 2 quarters */
	case Quarter :
		shift *=3;                       /* 1 quarter = 3 months */
	case Month :
		m = DATE_GET_M(newD);            /* Get month and year */
		y = DATE_GET_Y(newD);
		d = DATE_GET_D(newD);
		ed = DAYSINMONTHY(m,y);

		x = 12 * y + (m-1) + shift;
		y = (YEAR_T) (x/12);
		m = (MONTH_T) ((x%12)+1);

		if ((ed == d) && (forceMonthEnd == TRUE)) d = DAYSINMONTHY(m,y);	/* REFXXX */  /*NRAO - PMSTA-28601 -171201 */

		nd = DAYSINMONTHY(m,y);
		if (d > nd) d = nd;

		newD = DATE_PUT(y, m, d);
		break;

	/* century, decade, year treated together (no break) */
	case Century :
		shift *=10;                      /* 1 century = 10 decades */
	case Decade :
		shift *=10;                      /* 1 decade = 10 years */
	case Year :
		y = DATE_GET_Y(newD);            /* Get year */
		m = DATE_GET_M(newD);            /* Get month */
		d = DATE_GET_D(newD);            /* Get day */
		ed = DAYSINMONTHY(m,y);

		y = (YEAR_T) (y + shift);

		if (ed == d) d = DAYSINMONTHY(m,y);	/* PMSTA16961 - DDV - 130103 - Also adjust end of month for leap year */

		nd = DAYSINMONTHY(m,y);		/* REFXXX */
		if (d > nd) d = nd;

		newD = DATE_PUT_Y(newD, y);
		newD = DATE_PUT_D(newD, d);

		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_Move", "unit");
		newD = BAD_DATE;
		break;
	}
	return(newD);
}

/************************************************************************
**
**  Function    :   DATE_DatetimeMove()
**
**  Description :   Move a datetime.
**
**  Arguments   :   datetime Start date
**                  shift    Previous, same, next, 2, 3, 4, ...
**                  unit     day, week, month, quarter, semester, year,
**                           decade, century, hour, minute, second. (DATE_UNIT_ENUM values)
**
**  Return      :   New date
**                  BAD_DATE if error.
**
**  Creation    :  PMSTA-30817 - DDV - 180502
**  Modif	    :
**
*************************************************************************/
RET_CODE DATE_DatetimeMove(DATETIME_T *datetime, int shift, DATE_UNIT_ENUM unit, FLAG_T forceMonthEnd)
{
	DATE_T      newD;
	TIME_T      newT;
    long        diffDays=0;

	newD = datetime->date;                      /* Init new date at received date */
	newT = datetime->time;                      /* Init new date at received date */

	if (shift == 0)
		return(RET_SUCCEED);

	switch (unit)
	{
	case Day :
	case Week :
	case Semester :
	case Quarter :
	case Month :
	case Century :
	case Decade :
	case Year :
		newD = DATE_Move(datetime->date, shift, unit, forceMonthEnd);
		break;

	case Hour :
        shift *= 3600;
	case Minute :
        shift *= 60;
	case Second :

        newT = TIME_Add(datetime->time, shift, &diffDays);

        if (diffDays != 0)
		    newD = DATE_Move(datetime->date, diffDays, Day);

		break;
	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_Move", "unit");
		newD = BAD_DATE;
		break;
	}

    datetime->date = newD;
    datetime->time = newT;

	return(RET_SUCCEED);
}

/************************************************************************
**
**
**  Function    :   DATE_MoveDay()
**
**  Description :   Move from a date to another one that it returned.
**
**  Arguments   :   origin   date
**                  shift    next, previous, 2, 3, ...
**                  dayWeek  1=Sunday,   2=Monday, 3=Tuesday, 4=Wednesday,
**                           5=Thursday, 6=Friday, 7=Saturday)
**
**  Return      :   New date
**
*************************************************************************/
DATE_T DATE_MoveDay(DATE_T origin, int shift, DATE_WEEKDAY_ENUM dayWeek)
{
	char        currentDay;
	DATE_T      newD;
	DATE_DNUM_T dateNum;

	currentDay = DATE_WhichWeekDay(origin);        /* 0 (Sun) to 6 (Sat) */

	dateNum = DATE_DateToDnum(origin);

	/* dayWeek - 1   = values 0 to 6                          */
	/* - currentDay  = skip in week for move to the asked day */
	/* + shift * 7   = week number to skip                    */
	dateNum += (long) ((dayWeek - 1 - currentDay) + (shift*7));

	newD = DATE_DnumToDate(dateNum);

	return(newD);
}

/************************************************************************
**
**
**  Function    :   DATE_MovePosi()
**
**  Description :   Move from a date to another one that it returned.
**
**  Arguments   :   origin   date
**                  posi     sameDayIn, beginOf, endOf, middleOf, ...
**                           (DATE_POSI_ENUM values)
**                  unit     day, week, month, quarter, semester, year,
**                           decade, century. (DATE_UNIT_ENUM values)
**
**  Return      :   New date
**                  BAD_DATE if error
**
**		    REF2714 - SSO - 980922
*************************************************************************/
DATE_T DATE_MovePosi(DATE_T origin, DATE_POSI_ENUM posi, DATE_UNIT_ENUM unit)
{
	DATE_T  newD;
	DAY_T   day;
	MONTH_T month;
	YEAR_T  year;
	long    pos;

	newD = origin;                 /* Init new date at received date */

	switch (posi)
	{
	case SameDayIn :
		/* no move */
		break;

	case BeginOf :
	case ThirdWednesdayIn :
	case ThirdFridayIn :
		switch (unit)
		{
		case Day :
			/* no move */
			break;

		case Week :
			if (posi == BeginOf)
				newD = DATE_MoveDay(origin, 0, Sunday);
			break;

		case Month :
			newD = DATE_PUT_D(newD, 1);
			break;

		case Quarter :
			pos = DATE_Part(origin, QuarterInYear);
			/* 1 quarter = month 1, 2 quarter = month 4, */
			/* 3 quarter = month 7, 4 quarter = month 10 */
			switch (pos)
			{
			case 1 :
				newD = DATE_PUT_M(newD, 1);
				break;
			case 2 :
				newD = DATE_PUT_M(newD, 4);
				break;
			case 3 :
				newD = DATE_PUT_M(newD, 7);
				break;
			case 4 :
				newD = DATE_PUT_M(newD, 10);
				break;
			}
			newD = DATE_PUT_D(newD, 1);
			break;

		case Semester :
			pos = DATE_Part(origin, SemesterInYear);
			/* 1 semester = month 1, 2 semester = month 7 */ /* PMSTA07503 - DDV - 090518 - First month of second semester is 7 NOT 6 !!! */
			month = (MONTH_T) (((pos-1)*6)+1);
			newD = DATE_PUT_M(newD, month);
			newD = DATE_PUT_D(newD, 1);
			break;

		case Year :
			newD = DATE_PUT_M(newD, 1);
			newD = DATE_PUT_D(newD, 1);
			break;

		case Decade :
			pos = DATE_Part(origin, YearInDecade);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year - pos + 1);
			newD = DATE_PUT(year, 1, 1);
			break;

		case Century :
			pos = DATE_Part(origin, YearInCentury);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year - pos + 1);
			newD = DATE_PUT(year, 1, 1);
			break;

		default :
			MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			             "DATE_MovePosi", "unit");
			newD = BAD_DATE;
			break;
		}

		if (newD != BAD_DATE && unit != Week && unit != Day)
		{
			if (posi == ThirdWednesdayIn)
				newD = DATE_MoveDay(newD, 3, Wednesday);

			else if (posi == ThirdFridayIn)
				newD = DATE_MoveDay(newD, 3, Friday);
		}
		break;

	case EndOf :
		switch (unit)
		{
		case Day :
			/* no move */
			break;

		case Week :
			newD = DATE_MoveDay(origin, 0, Saturday);
			break;

		case Month :
			DATE_Get(origin, &year, &month, NULL);
			day = DATE_DaysInMonth(month, year);
			newD = DATE_PUT_D(newD, day);
			break;

		case Quarter :
			pos = DATE_Part(origin, QuarterInYear);
			/* 1 quarter = month 3, 2 quarter = month 6, */
			/* 3 quarter = month 9, 4 quarter = month 12 */
			/* pos value = 1 to 4 and (1*3) = 3          */
			month = (MONTH_T) (pos * 3);
			newD = DATE_PUT_M(newD, month);
			DATE_Get(origin, &year, NULL, NULL);
			day = DATE_DaysInMonth(month, year);
			newD = DATE_PUT_D(newD, day);
			break;

		case Semester :
			pos = DATE_Part(origin, SemesterInYear);
			/* 1 semester = month 6, 2 quarter = month 12, */
			/* pos value = 1 to 2 and (1*6) = 6            */
			month = (MONTH_T) (pos * 6);
			newD = DATE_PUT_M(newD, month);
			DATE_Get(origin, &year, NULL, NULL);
			day = DATE_DaysInMonth(month, year);
			newD = DATE_PUT_D(newD, day);
			break;

		case Year :
			newD = DATE_PUT_M(newD, 12);
			newD = DATE_PUT_D(newD, 31);
			break;

		case Decade :
			pos = DATE_Part(origin, YearInDecade);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year + 10 - pos);
			newD = DATE_PUT(year, 12, 31);
			break;

		case Century :
			pos = DATE_Part(origin, YearInCentury);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year + 100 - pos);
			newD = DATE_PUT(year, 12, 31);
			break;

		default :
			MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			             "DATE_MovePosi", "unit");
			newD = BAD_DATE;
			break;
		}
		break;

	case MiddleOf :
		switch (unit)
		{
		case Day :
			/* no move */
			break;

		case Week :
			newD = DATE_MoveDay(origin, 0, Wednesday);
			break;

		case Month :
			newD = DATE_PUT_D(newD, 15);
			break;

		case Quarter :
			pos = DATE_Part(origin, QuarterInYear);
			/* 1 quarter = 15.2, 2 quarter = 15.5, */
			/* 3 quarter = 15.8, 4 quarter = 15.11 */
			/* pos = 1 to 4 and (1*3)-1 = 2        */
			month = (MONTH_T) ((pos * 3) - 1);
			newD = DATE_PUT_M(newD, month);
			newD = DATE_PUT_D(newD, 15);
			break;

		case Semester :
			pos = DATE_Part(origin, SemesterInYear);
			/* 1 semester = 31.3, */
			/* 2 semester =  30.9 */
			if (pos == 1)
			{
				newD = DATE_PUT_M(newD, 3);
				newD = DATE_PUT_D(newD, 31);
			}
			else
			{
				newD = DATE_PUT_M(newD, 9);
				newD = DATE_PUT_D(newD, 30);
			}
			break;

		case Year :
			newD = DATE_PUT_M(newD, 7); /* REF2714 - SSO - 980922 */
			newD = DATE_PUT_D(newD, 1);
			break;

		case Decade :
			pos = DATE_Part(origin, YearInDecade);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year - pos + 1 + 5);/* REF2714 - SSO - 980922 */
			newD = DATE_PUT(year, 7, 1);
			break;

		case Century :
			pos = DATE_Part(origin, YearInCentury);
			DATE_Get(origin, &year, NULL, NULL);
			year = (YEAR_T)(year - pos + 1 + 50);/* REF2714 - SSO - 980922 */
			newD = DATE_PUT(year, 7, 1);
			break;

		default :
			MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			             "DATE_MovePosi", "unit");
			newD = BAD_DATE;
			break;
		}
		break;

	case LastOpenDayBefore :
		switch (unit)
		{
		case Day :
			break;
		case Week :
			break;
		case Month :
			break;
		case Quarter :
			break;
		case Semester :
			break;
		case Year :
			break;
		case Decade :
			break;
		case Century :
			break;
		default :
			MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			             "DATE_MovePosi", "unit");
			newD = BAD_DATE;
			break;
		}
		break;

	case NextOpenDaySince :
		switch (unit)
		{
		case Day :
			break;
		case Week :
			break;
		case Month :
			break;
		case Quarter :
			break;
		case Semester :
			break;
		case Year :
			break;
		case Decade :
			break;
		case Century :
			break;
		default :
			MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			             "DATE_MovePosi", "unit");
			newD = BAD_DATE;
			break;
		}
		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
		             "DATE_MovePosi", "posi");
		newD = BAD_DATE;
		break;
	}

	return(newD);
}

/************************************************************************
**
**  Function    :   DATE_Cmp()
**
**  Description :   Compare two received dates in DATE_T representation.
**                  The number returned doesn't correspond to the
**                  difference in days between two dates.
**                  It's faster than DATE_Diff().
**
**  Arguments   :   date1
**                  date2
**
**  Return      :   a negative value if first date < second date
**                  a null value     if first date = second date
**                  a positive value if first date > second date
**
*************************************************************************/
int DATE_Cmp(DATE_T date1, DATE_T date2)
{
	return ((date1<date2)?-1:(date1>date2)?1:0);
}

/************************************************************************
**
**  Function    :   DATE_AccrPeriod()
**
**  Description :   Return the number of days between two dates according
**                  to an accrual_period_rule (ACCRRULE_ENUM).
**
**  Arguments   :   fromDate
**                  tillDate
**                  rule        ACCRRULE_ENUM
**                  payFreq     coupon payment frequence (in month unit)
**                  numDenomPtr structure pointer which will be filled
**                  calendarId        calendar id used to generate holiday structure
**
**  Return      :   TRUE if success, FALSE elsewhere
**  Last modif. :   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**  Modification:   REF9085 - YST - 030611
**
*************************************************************************/
int DATE_AccrPeriod(DATE_T fromDate, DATE_T tillDate,
		      ACCRRULE_ENUM rule, PERIOD_T payFreq,
			  DATE_PERIOD_STP periodPtr, ID_T calendarId)
{
	int                     ret = TRUE;
	DATE_DAYSINYEAR_ENUM    daysInYear = Days360;  /* REF7264 - PMO */

	periodPtr->num = periodPtr->denom = 0L;

    /* new accrual rules (defined by SCecon) */ /* REF9085 - YST - 030611 */
    if (SCE_CheckAccrRule(rule) == TRUE)
    {
        if (SCE_AccrPeriod(fromDate, tillDate, rule, periodPtr, calendarId) != RET_SUCCEED)  /* PMSTA-22396  - SRIDHARA � 160430 */
            ret = FALSE;
    }
    /* old accrual rules */
    else
    {
	    if (rule == AccrRule_None)
	    {
		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			         "DATE_AccrPeriod", "accrual rule"); */
		    rule = AccrRule_30E_360;
	    }

		DATE_DaysBetween(fromDate, tillDate, rule, &(periodPtr->num), calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */

	    switch(rule)
	    {
	    case AccrRule_30_360 :
	    case AccrRule_30_360_FebAdj :
	    case AccrRule_30_360_Def :
	    case AccrRule_30_360_US :
	    case AccrRule_Actual_360 :
	    case AccrRule_30E_360 :
	    case AccrRule_Actual_1_360 :
	    case AccrRule_30_360_1 :			/* DVP484 - RAK - 970526 */
		    daysInYear = Days360;
		    break;

	    case AccrRule_Actual_365 :
	    case AccrRule_365_365 :
	    case AccrRule_Actual_1_365 :
	    case AccrRule_30E_365 :
	    case AccrRule_30_365_US :
		    daysInYear = Days365;
		    break;

	    case AccrRule_Actual_Actual :
	    case AccrRule_Actual_1_Actual :
	    case AccrRule_30E_Actual :
	    case AccrRule_30_Actual_US :
		    daysInYear = DaysActual;
		    break;

	    case AccrRule_Actual_Actual_US :
		    daysInYear = AnnualisedPeriod;
		    break;

	    default :
		    ret = FALSE;
		    break;
	    }

	    if (ret != FALSE)
		    ret = DATE_DaysInYear(fromDate, tillDate, daysInYear,
				          payFreq, &(periodPtr->denom));
    }
	return(ret);
}

/************************************************************************
**
**  Function    :   DATE_AccrMaxDaysInYear()
**
**  Description :   Return the maximum days in year according
**                  to an accrual_period_rule (ACCRRULE_ENUM).
**
**  Arguments   :   fromDate
**                  tillDate
**                  rule          ACCRRULE_ENUM
**                  payFreq       coupon payment frequence (in month unit)
**                  maxDaysInYear pointer which will be filled
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Modif	:   BUG472 - RAK - 970827
**
*************************************************************************/
int DATE_AccrMaxDaysInYear(DATE_T          fromDate,
		           DATE_T          tillDate,
		           ACCRRULE_ENUM   rule,
		           PERIOD_T        payFreq,
		           long            *maxDaysInYear)
{
	int	ret=TRUE;

	switch (rule)
	{
	case AccrRule_30_360 :
	case AccrRule_30_360_FebAdj :
	case AccrRule_30_360_Def :
	case AccrRule_30_360_US :
	case AccrRule_30_360_1 :
	case AccrRule_30_365_US :
	case AccrRule_30_Actual_US :
	case AccrRule_30E_360 :
	case AccrRule_30E_365 :
	case AccrRule_30E_Actual :
		*maxDaysInYear = 360;
		break;

	case AccrRule_365_365 :
		*maxDaysInYear = 365;
		break;

	case AccrRule_Actual_360 :
	case AccrRule_Actual_1_360 :
	case AccrRule_Actual_365 :
	case AccrRule_Actual_1_365 :
	case AccrRule_Actual_Actual :
	case AccrRule_Actual_1_Actual :
	case AccrRule_Actual_Actual_US :
		DATE_DaysInYear(fromDate, tillDate, DaysActual, payFreq, maxDaysInYear);
		break;
	default :
		ret = FALSE;
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   DATE_AccrMaxDaysInYear2()
**
**  Description :   Return the maximum days in year according
**                  to an accrual_period_rule (ACCRRULE_ENUM).
**
**  Arguments   :   fromDate
**                  tillDate
**                  rule          ACCRRULE_ENUM
**                  payFreq       coupon payment frequence (in month unit)
**                  maxDaysInYear pointer which will be filled
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Modif	:       REF7256 - TEB - 030414
**
*************************************************************************/
int DATE_AccrMaxDaysInYear2(DATE_T          fromDate,
		                   DATE_T          tillDate,
		                   ACCRRULE_ENUM   rule,
		                   PERIOD_T        payFreq,
		                   long            *maxDaysInYear)
{
	int	ret=TRUE;

	switch (rule)
	{
	case AccrRule_30_360 :
	case AccrRule_30_360_FebAdj :
	case AccrRule_30_360_Def :
	case AccrRule_30_360_US :
	case AccrRule_30_360_1 :
	case AccrRule_30E_360 :
	case AccrRule_Actual_360 :
	case AccrRule_Actual_1_360 :
		*maxDaysInYear = 360;
		break;

	case AccrRule_30_365_US :
	case AccrRule_30E_365 :
    case AccrRule_365_365 :
	case AccrRule_Actual_365 :
	case AccrRule_Actual_1_365 :
		*maxDaysInYear = 365;
		break;

	case AccrRule_30_Actual_US :
	case AccrRule_30E_Actual :
    case AccrRule_Actual_Actual :
	case AccrRule_Actual_1_Actual :
	case AccrRule_Actual_Actual_US :
		DATE_DaysInYear(fromDate, tillDate, DaysActual, payFreq, maxDaysInYear);
		break;

		/* PMSTA-22396  - SRIDHARA � 160430 */
	case AccrRule_SceBus252:
		*maxDaysInYear = 252;
		break;

	default :
		ret = FALSE;
    }

	return(ret);
}


/************************************************************************
**
**  Function    :   DATE_DaysInYear()
**
**  Description :   Return the number of days in year depending on method.
**
**  Arguments   :   ref       reference date
**                  method    DATE_DAYSINYEAR_ENUM
**                  freqMonth in month
**                  days
**
**  Return      :   TRUE if success, FALSE elsewhere
**
*************************************************************************/
int DATE_DaysInYear(DATE_T ref1, DATE_T ref2, DATE_DAYSINYEAR_ENUM method,
		    PERIOD_T freqMonth, long *days)
{
	int ret;
	DATE_T ref;

	*days = 0L;

	switch (method)
	{
	case Days360 :
		*days = 360L;
		ret = TRUE;
		break;

	case Days365 :
		*days = DAYSIN1YEAR;
		ret = TRUE;
		break;

	case DaysActual :
	{
		/* 366 if leap year, 365 elsewhere. If two */
		/* years are different, compute a yield.   */
		YEAR_T y, y1, y2;
		long    leapYear=0;

		y1 = DATE_GET_Y(ref1);
		y2 = DATE_GET_Y(ref2);
		if (y1 != y2)
		{
			/* compute leap year number between two years */
			for(y=y1; y<=y2; y++)
			{
				if (LEAP_YEAR(y)==TRUE)
					leapYear +=1;
			}

			/* 365 + 1 day per leap year / years difference */
			*days = (long) ((DAYSIN1YEAR * (long) (y2-y1) + leapYear) /
					(long) (y2-y1));
		}
		else
			*days = (DAYSIN1YEAR+((LEAP_YEAR(y1)==TRUE)?1:0));
		ret = TRUE;
		break;
	}

	case AnnualisedPeriod  :
		ref = DATE_Move(ref1, freqMonth, Month);
		DATE_DaysBetween(ref1, ref, AccrRule_Actual_Actual, days, 0); /* PMSTA-22396  - SRIDHARA � 160430 */

		if (freqMonth != 0)
			*days *= (12 / freqMonth);

		ret = TRUE;
		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_DaysInYear", "method");
		ret = FALSE;
		break;
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   DATE_DaysBetween()
**
**  Description :   Return the number of days between two received dates.
**                  Calls SCecon function for new accrual rules.
**
**  Arguments   :   date1
**                  date2
**                  accrBasis  Calculation methode (ie : 30 days/month, realy)
**                  days       pointer on days value
**                  calendarId calendar id used to generate holiday structure
**
**  Return      :   days value is updated
**
**  Modification:   REF9085 - YST - 030512
**
*************************************************************************/
void DATE_DaysBetween(DATE_T fromDate, DATE_T tillDate,
	              ACCRRULE_ENUM accrBasis, long *days, ID_T calendarId)
{
    RET_CODE    retCd = RET_SUCCEED;
	YEAR_T      y1, y2;
	MONTH_T     m1, m2;
	DAY_T       d1, d2;

    /* new accrual rules (defined by SCecon) */ /* REF9085 - YST - 030512 */
    if (SCE_CheckAccrRule(accrBasis) == TRUE)
    {
		retCd = SCE_CldrDaysBetweenDates(fromDate, tillDate, accrBasis, days, calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */
    }
    /* old accrual rules */
    else
    {
        if (accrBasis == AccrRule_None)
	    {
		    /* MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_DaysBetween", "accrual rule"); */
		    accrBasis = AccrRule_30E_360;
	    }

	    *days = 0L;   /* Init at 0 days number, important for ActualOn365 */

        DATE_Get(fromDate, &y1, &m1, &d1);
	    DATE_Get(tillDate, &y2, &m2, &d2);

	    switch (accrBasis)
	    {
	    /* ActualPlus1On365 method  = Actual method + 1 days,     */
	    /* so init days at 1 and do Actual method case (no break) */
	    case AccrRule_Actual_1_365 :
	    case AccrRule_Actual_1_Actual :
	    case AccrRule_Actual_1_360 :
		    *days = 1L;

	    /* ActualOn365 method = exact days number in year (leap year control) */
	    case AccrRule_Actual_365 :
	    case AccrRule_Actual_Actual :
	    case AccrRule_Actual_360 :
	    case AccrRule_Actual_Actual_US :
		    if (y1 == y2 && m1 == m2)
			    /* Difference between 2 days, (same month and year) */
			    *days += (long) (d2 - d1);
		    else
                            /* Convert 2 dates in days passed from DNUM0DATE */
			    *days += DATE_DateToDnum(tillDate) -
				        DATE_DateToDnum(fromDate);
		    break;

	    /* Each months have 30 days, 31st is assumed to be the 30th. */
	    case AccrRule_30_360 :   /* deleted ?? */
	    case AccrRule_30E_360 :
	    case AccrRule_30E_365 :
	    case AccrRule_30E_Actual :
	    case AccrRule_30_360_1 :
		    d1 = (DAY_T)((d1==31)?30:d1);
		    d2 = (DAY_T)((d2==31)?30:d2);
		    *days = (d2-d1) + (30L * (m2-m1)) + (360L * (y2-y1));

		    /* REF1477 - Treated in FIN_UnitAccrInter fct */
		    /* if (accrBasis ==  AccrRule_30_360_1)
			    (*days)+=1; */
		    break;

	    /* Each months have 30 days,                      */
	    /* the 31st is assumed to be the 30th             */
	    /* last day of february is considered as the 30th */
	    case AccrRule_30_360_FebAdj :
		    /* 28.02, 29.02, 30, 31 can be last month day */
		    if (DAYSINMONTHY(m1, y1) == d1)
			    d1 = 30;
		    if (DAYSINMONTHY(m2, y2) == d2)
			    d2 = 30;
		    *days = (d2-d1) + (30L * (m2-m1)) + (360L * (y2-y1));
		    break;

	    /* Each month have 30 days. */
	    /* The 31st is assumed to be the 1st of the following month. */
	    case AccrRule_30_360_Def :
		    if (d1 == 31)
		    {
			    d1 = 1;
			    if (m1 == 12)
			    {
				    m1 = 1;
				    y1+=1;
			    }
			    else
				    m1+=1;
		    }

		    if (d2 == 31)
		    {
			    d2 = 1;
			    if (m2 == 12)
			    {
				    m2 = 1;
				    y2+=1;
			    }
			    else
				    m2+=1;
		    }
		    *days = (d2-d1) + (30L * (m2-m1)) + (360L * (y2-y1));
		    break;

	    /* Each month have 30 days.                            */
	    /* If period start on a 31st change to 30th            */
	    /* If period ends on a 31st and starts on 30th or 31st */
	    /* change end to 30th, otherwise leave at 31st.        */
	    case AccrRule_30_360_US :
	    case AccrRule_30_Actual_US :
	    case AccrRule_30_365_US :
		    d1 = (DAY_T)((d1>30)?30:d1);      /* d1 = 30 if d1=31 */

		    if (d2==31 && d1==30)    /* d2 = 30 if d2=31 and d1=30(or 31) */
			    d2 = 30;
		    *days = (d2-d1) + (30L * (m2-m1)) + (360L * (y2-y1));
		    break;

	    /* February have ever 28 days, other months are treated normally */
	    case AccrRule_365_365 :
		    if (m1 == 2 && d1 > 28) d1 = 28;  /* No leap year */
		    if (m2 == 2 && d2 > 28) d2 = 28;

		    if (y1 == y2 && m1 == m2)
		    {
			    /* Difference between 2 days, (same month and year) */
			    *days = (long) (d2 - d1);
		    }
		    else
		    {
			    /* No leap year */
			    *days = ((y2-y1) * 365) +
				     ((DAYSBEFOREMONTHLY(m2,FALSE) + d2) -
				      (DAYSBEFOREMONTHLY(m1, FALSE) + d1));
		    }
		    break;
	    }
    }

	return;
}

/************************************************************************
**
**  Function    :   DATE_BusinessDaysBetween()
**
**  Description :   Return the number of business days between two received dates.
**
**  Arguments   :   date1
**                  date2
**                  days       pointer on days value
**                  calendarId calendar id used to generate holiday structure
**
**  Return      :   days value is updated
**
**  Creation    :   PMSTA-34288 - CHU - 190128
**
*************************************************************************/
void DATE_BusinessDaysBetween(DATE_T fromDate,
                              DATE_T tillDate,
                              ID_T   calendarId,
                              long   *nbBusinessDays)
{
    SCE_ARG_ST      sceHoliDate, sceBusiDate;

    DATE_T          *busiDateTab = nullptr, *holiDateTab = nullptr;
    DATETIME_ST     begHoliDate, endHoliDate, firstDate, secDate;
    YEAR_T		    begYear = 0, endYear = 0;
    bool            inverseFlg = false;
    int             busiDateTabNbr = 0, holiDateTabNbr = 0;

    *nbBusinessDays = 0l;

    if (fromDate == MAGIC_END_DATE ||
        tillDate == MAGIC_END_DATE ||
        DATE_Cmp(fromDate, tillDate) == 0)
    {
        return;
    }

    MemoryPool      mp;
    DBA_DYNFLD_STP  sCalendar = mp.allocDynst(FILEINFO, S_Calendar);
    DBA_DYNFLD_STP  aCalendar = mp.allocDynst(FILEINFO, A_Calendar);

    SET_ID(sCalendar, S_Calendar_Id, calendarId);


    /* Load the given calendar. */
    if (DBA_Get2(Calendar, UNUSED,
                 S_Calendar, sCalendar,
                 A_Calendar, &aCalendar,
                 UNUSED, nullptr, nullptr) != RET_SUCCEED)
    {
        return;
    }

    /* 1 January from the first year and 31 December from the second year */
    begHoliDate.time = 0;
    endHoliDate.time = 0;
    begHoliDate.date = fromDate;
    endHoliDate.date = tillDate;

    if (DATETIME_CMP(begHoliDate, endHoliDate) > 0)
    {
        DATE_Get(endHoliDate.date, &begYear, nullptr, nullptr);
        DATE_Get(begHoliDate.date, &endYear, nullptr, nullptr);
    }
    else
    {
        DATE_Get(begHoliDate.date, &begYear, nullptr, nullptr);
        DATE_Get(endHoliDate.date, &endYear, nullptr, nullptr);
    }

    begHoliDate.date = DATE_Put(begYear, (MONTH_T)1, (DAY_T)1);
    endHoliDate.date = DATE_Put(endYear, (MONTH_T)12, (DAY_T)31);

    DBA_DYNFLD_STP holiRule = mp.allocDynst(FILEINFO, HolidaysRule);

    SET_DATETIME(holiRule, HolidaysRule_StartDate, begHoliDate);
    SET_DATETIME(holiRule, HolidaysRule_EndDate, endHoliDate);
    SET_ID(holiRule, HolidaysRule_CalendarId, calendarId);
    SET_ENUM(holiRule, HolidaysRule_NatureEn, (ENUM_T)CalConvNat_Holiday);
    SET_ENUM(holiRule, HolidaysRule_GenericEn, (ENUM_T)CalConvGen_True);
    SET_INT(holiRule, HolidaysRule_AddDays, 0);
    SET_INT(holiRule, HolidaysRule_Weekend, 0);

    /* Generates non week-end holidays */
    if (SCE_CldrGenrDates(holiRule, &sceHoliDate) != RET_SUCCEED)
    {
        return;
    }

    /* Search the number of business days between 2 dates */
    DBA_DYNFLD_STP outCalendar = mp.allocDynst(FILEINFO, CalendarOut);
    switch ((CALBUSDATERULE_ENUM)GET_ENUM(aCalendar, A_Calendar_BusinessDateRuleEn))
    {
    case CalBusDateRule_Default:

        firstDate.time = 0;
        secDate.time = 0;

        /*
        if (DATE_Cmp(fromDate, tillDate) > 0)
        {
            firstDate.date = tillDate;
            secDate.date = fromDate;
            inverseFlg = TRUE;
        }
        else
        {
        */
            firstDate.date = fromDate;
            secDate.date = tillDate;
        /*}*/

        SET_DATETIME(holiRule, HolidaysRule_StartDate, firstDate);
        SET_DATETIME(holiRule, HolidaysRule_EndDate, secDate);

        if (SCE_CldrDiffBusinessDays(holiRule, &sceHoliDate, outCalendar) != RET_SUCCEED)
        {
            SCE_ArgFree(&sceHoliDate);
            return;
        }
        /* Store the number in the output */
        *nbBusinessDays = (long)GET_INT(outCalendar, CalendarOut_Int);
        break;

    case CalBusDateRule_SpecBusiness:		/* REF892 - RAK - 971118 */

        /* Selection of occurences having the 'business' nature. */
        SET_DATETIME(holiRule, HolidaysRule_StartDate, begHoliDate);
        SET_DATETIME(holiRule, HolidaysRule_EndDate, endHoliDate);
        SET_ID(holiRule, HolidaysRule_CalendarId, calendarId);
        SET_ENUM(holiRule, HolidaysRule_NatureEn, (ENUM_T)CalConvNat_Business);
        SET_ENUM(holiRule, HolidaysRule_GenericEn, (ENUM_T)CalConvGen_True);
        SET_INT(holiRule, HolidaysRule_AddDays, 0);
        SET_INT(holiRule, HolidaysRule_Weekend, 0);

        if (SCE_CldrGenrDates(holiRule, &sceBusiDate) != RET_SUCCEED)
        {
            SCE_ArgFree(&sceHoliDate);
            return;
        }

        /* Convert the returned dates to DATE_T format. */  /* REF8947 - YST - 030407 - add new arg. */
        if (SCE_CldrConvToDate(&sceBusiDate, GET_CODE(aCalendar, A_Calendar_Cd), FALSE, &busiDateTab, &busiDateTabNbr) != RET_SUCCEED)
        {
            SCE_ArgFree(&sceHoliDate);
            SCE_ArgFree(&sceBusiDate);
            return;
        }

        /* Convert the returned dates to DATE_T format. */  /* REF8947 - YST - 030407 - add new arg. */
        if (SCE_CldrConvToDate(&sceHoliDate, GET_CODE(aCalendar, A_Calendar_Cd), TRUE, &holiDateTab, &holiDateTabNbr) != RET_SUCCEED)
        {
            SCE_ArgFree(&sceHoliDate);
            SCE_ArgFree(&sceBusiDate);
            FREE(busiDateTab);
            return;
        }

        firstDate.time = 0;
        secDate.time = 0;

        if (DATE_Cmp(fromDate, tillDate) > 0)
        {
            firstDate.date = tillDate;
            secDate.date = fromDate;
            inverseFlg = true;
        }
        else
        {
            firstDate.date = fromDate;
            secDate.date = tillDate;
        }

        long diffDays     = 0l;
        bool firstDateFlg = false;

        for (int i = 0; i < busiDateTabNbr; i++)
        {
            bool foundInHoli = false;

            /* Eliminate business dates that are also holidays */
            for (int j = 0; j < holiDateTabNbr && foundInHoli == false; j++)
            {
                if (DATE_Cmp(busiDateTab[i], holiDateTab[j]) == 0)
                    foundInHoli = true;
            }

            if (foundInHoli == true)
                continue;

            /* Count business day between two dates */
            if (firstDateFlg == true)
                ++diffDays;

            /* Begin to count */
            if (DATE_Cmp(busiDateTab[i], firstDate.date) >= 0)
                firstDateFlg = true;

            /* Stop */
            if (DATE_Cmp(busiDateTab[i], secDate.date) >= 0)
            {
                break;
            }
        }

        /* Inverse in case of first date is after second date */
        if (diffDays != 0 && inverseFlg == true)
            diffDays = -diffDays;

        /* Store the number in the output */
        *nbBusinessDays = diffDays;

        /* Free allocated memory. */
        SCE_ArgFree(&sceBusiDate);
        FREE(busiDateTab);
        FREE(holiDateTab);
        break;
    }

    /* Free allocated memory. */
    SCE_ArgFree(&sceHoliDate);
}


/************************************************************************
**
**  Function    :   DATE_Between()
**
**  Description :   Check if date1 <= date2 <= date3
**
**  Argument    :   date1
**                  date2
**                  date3
**
**  Return      :   true    yes
**                  false   no
**
**  Creation    :   PMSTA-35210 - 270319 - PMO : Final Valuation Date and Quote
**
**  Modification:
**
*************************************************************************/
bool DATE_Between(const DATE_T & date1, const DATE_T & date2, const DATE_T & date3)
{
    return DATE_Cmp(date1, date2) < 1 && DATE_Cmp(date2, date3) < 1;
}


/************************************************************************
**
**  Function    :   DATE_Diff()
**
**  Description :   Compute the difference between two dates in
**                  specified unit.
**
**  Arguments   :   date1
**                  date2
**                  unit       Unit (ie : days, month, semester, year ..)
**                             in which difference is expressed
**                             ! Week  :   7 days (yes)
**                               Month :  30 days
**                               Year  : 365 days
**
**                  accrBasis  Calculation methode (ie : 30 days/month, realy)
**                             used to determine the difference between the
**                             two received dates.
**                  calendarId calendar id used to generate holiday structure
**
**  Return      :   Difference between two dates, in days by dflt
**
**  Modif	    :   REF7256 - TEB - 030414
**  Modification:   REF9085 - YST - 030611
**
*************************************************************************/
double DATE_Diff(DATE_T date1, DATE_T date2, DATE_UNIT_ENUM unit,
	         ACCRRULE_ENUM accrBasis, ID_T calendarId)
{
	long   daysDiff, maxDaysInYear=0; /* REF7256 - TEB - 030414 */
	double diff;
	YEAR_T y1, y2;
	MONTH_T m1, m2;
	DAY_T d1, d2;

	const double busFactor = 252.0 / 365.0;     /* PMSTA-22396  - SRIDHARA � 160430 */

    /* new accrual rules (defined by SCecon) */ /* REF9085 - YST - 030610 */
    if (SCE_CheckAccrRule(accrBasis) == TRUE)
    {
		if (SCE_CldrDateDiff(date1, date2, unit, accrBasis, &diff, calendarId) != RET_SUCCEED)  /* PMSTA-22396  - SRIDHARA � 160430 */
        {diff = 0.0;}
    }
    /* old accrual rules */
    else
    {
	    if (accrBasis == AccrRule_None ||
            unit == Month ||              /* PMSTA08770 - DDV - 091102 - For units Month Quarter and semester, */
            unit == Quarter ||            /* computation is done for month with 30 days, then change the accrual rule */
            unit == Semester)
	    {
		    accrBasis = AccrRule_30E_360;
	    }

	    /* Compute difference in days depending on accrual rule */
		DATE_DaysBetween(date1, date2, accrBasis, &daysDiff, calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */

	    switch (unit)
	    {
	    case Day :
		    diff = (double) daysDiff;
		    break;

	    /* 1 week = 7 days */
	    case Week :
			if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / (7.0 * busFactor);
			}
			else
			{
				diff = daysDiff / 7.0;
			}
		    break;

	    case Month :
			/* PMSTA06040 - LJE - 080429 : Manage only when end of periods... */
			if (DATE_IsLastInMonth(date1) == TRUE &&
				DATE_IsLastInMonth(date2) == TRUE)
			{
				/* PMSTA06040 - LJE - 080320 : Change month diff computing
				 * Use 12 * DiffYear + DiffMonthInYear
				 * And if no complet month, remove one month
				 * Ex.
				 *		21/01/2005, 30/05/2006 = 12 + 4 = 16
				 *      30/01/2005, 21/05/2006 = 12 + 4 - 1 = 15
				 *      30/01/2005, 28/02/2006 = 12 + 1 = 13 (28/02 is end of month)
				 */
				DATE_Get(date1, &y1, &m1, &d1);
				DATE_Get(date2, &y2, &m2, &d2);

				diff = (y2-y1) * 12;
				diff += m2-m1;
			}
			else
			{
				/* PMSTA-22396  - SRIDHARA � 160430 */
				if (accrBasis == AccrRule_SceBus252)
				{
					diff = daysDiff / (30.0 * busFactor);
				}
				else
				{
					diff = daysDiff / 30.0;
				}
				diff = daysDiff / 30.0;
			}
		    break;

	    /* 1 quarter = �90 days */
	    case Quarter :
			if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / (90.0 * busFactor);
			}
			else
			{
				diff = daysDiff / 90.0;
			}
		    break;

	    /* 1 semester = �180 days */
	    case Semester :
			if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / (180.0 * busFactor);
			}
			else
			{
				diff = daysDiff / 180.0;
			}
		    break;

	    /* 1 year = �360 days */
	    case Year :
            /* REF7256 - TEB - 030414 */
			if (DATE_AccrMaxDaysInYear2(date1, date2, accrBasis, FreqUnit_None, &maxDaysInYear) == FALSE)
			{
				if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
				{
					maxDaysInYear = 252;
				}
				else
				{
					maxDaysInYear = 365;
				}
			}
            /* diff = daysDiff / 365.0; */ /* REF7256 - TEB - 030414 */
			if (accrBasis == AccrRule_SceBus252)   /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / ((double)maxDaysInYear * busFactor);
			}
			else
			{
				diff = daysDiff / (double)maxDaysInYear;
			}
		    break;

	    /* 10 years = �3600 days */
	    case Decade :
            /* REF7256 - TEB - 030414 */
			if (DATE_AccrMaxDaysInYear2(date1, date2, accrBasis, FreqUnit_None, &maxDaysInYear) == FALSE)
			{
				if (accrBasis == AccrRule_SceBus252)  /* PMSTA-22396  - SRIDHARA � 160430 */
				{
					maxDaysInYear = 252;
				}
				else
				{
					maxDaysInYear = 365;
				}
			}
		    /* diff = daysDiff / 3650.0; *//* REF7256 - TEB - 030414 */
			if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / (double)(10.0 * maxDaysInYear * busFactor);
			}
			else
			{
				diff = daysDiff / (double)(10.0 * maxDaysInYear); /* REF9954 - TEB - 040224 */
			}
		    break;

	    /* 100 years = �36000 days */
	    case Century :
            /* REF7256 - TEB - 030414 */
			if (DATE_AccrMaxDaysInYear2(date1, date2, accrBasis, FreqUnit_None, &maxDaysInYear) == FALSE)
			{
				if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
				{
					maxDaysInYear = 252;
				}
				else
				{
					maxDaysInYear = 365;
				}
			}
		    /* diff = daysDiff / 36500.0; */ /* REF7256 - TEB - 030414 */
			if (accrBasis == AccrRule_SceBus252) /* PMSTA-22396  - SRIDHARA � 160430 */
			{
				diff = daysDiff / (double)(100.0 * maxDaysInYear * busFactor);
			}
			else
			{
				diff = daysDiff / (double)(100.0 * maxDaysInYear); /* REF9954 - TEB - 040224 */
			}
		    break;

	    default :
		    MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			         "DATE_Diff", "unit");
		    diff = 0.0; /* ?? daysDiff */
		    break;
	    }
    }

	return(diff);
}

/************************************************************************
**
**  Function    :   DATE_MonthName()
**
**  Description :   Returned the month name from the received date.
**
**  Arguments   :   name     pointer for the returned value
**                  date
**                  type     short or long (Feb, February, Jan, January)
**                            0        1
**
**  Return      :   Month name (correspond to first parameter)
**
*************************************************************************/
char *DATE_MonthName(char *name, DATE_T date, int type)
{
	const MONTH_T m = DATE_GET_M(date);

	if (type > 1 || type < 0)          /* Only 0 or 1 are valid values */
		type = 0;

	/* Language treated at table monthNameTb initialization */
	strcpy(name, SV_monthNameTb[m-1][type]);

	return(name);
}

/************************************************************************
**
**  Function    :   DATE_MonthNbr()
**
**  Description :   Determine the month number (1 to 12)
**
**  Arguments   :   month name
**                  type  (short or long)
**
**  Return      :   1 to 12 (jan to dec), FALSE if error
**
*************************************************************************/
STATIC MONTH_T DATE_MonthNbr(char * month, int type)
{
	MONTH_T m=0;

	if (type > 1 || type < 0)    /* Only 0 or 1 are valid values */
		type = 0;

	while (m < 12)
	{
		/* SV_monthNameTb filled depending on the language */
		if (!strcasecmp(SV_monthNameTb[m][type], month))
			return (MONTH_T) (m+1);
		++m;
	}

	MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
		     "DATE_MonthNbr", "month");
	return(FALSE);
}

/************************************************************************
**
**  Function    :   DATE_WeekDayName()
**
**  Description :   Returned the day name from the received date.
**
**  Arguments   :   name     pointer for the returned value
**                  date
**                  type     short or long (Mon, Monday, Sat, Saturday)
**
**  Return      :   Week day name (correspond to first parameter)
**
*************************************************************************/
char *DATE_WeekDayName(char *name, DATE_T date, int type)
{
	int dayNbr;

	dayNbr = (int) DATE_WhichWeekDay(date);

	if (type > 1 || type < 0)   /* Only 0 or 1 are valid values */
		type = 0;

	/* Language treated at table weekDayTb initialization */
	strcpy(name, SV_weekDayTb[dayNbr][type]);

	return(name);
}

/************************************************************************
**
**  Function    :   DATE_FormatToStr()
**
**  Description :   Format the received date depending on the specified
**                  format.
**
**  Arguments   :   name    :pointer for the returned value
**                  date    :date
**                  format  :format structure, order, date and month format, ...
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Last modif. :   PMSTA-24412 - 120816 - PMO : InitMsgCash generate memcpy overlap
**
*************************************************************************/
int DATE_FormatToStr(char *name, DATE_T date, DATE_FORMAT_STP format)
{
	int     yLength;
	YEAR_T  y;
	MONTH_T m;
	DAY_T   d;
	char    month[25];

	DATE_Get(date, &y, &m, &d);
	*name = END_OF_STRING;

	/* Year format (1994 or 94) */
	if (format->yearFormat == 0)
	{
		y = (YEAR_T)((int)y%100);       /* short version */
		yLength = 2;
	}
	else
		yLength = 4;                    /* long version */

	/* Month format (1, jan, january) */
	switch(format->monthFormat)
	{
	case 0 :                                /* numeric version */
		sprintf(month, "%02d", m);
		break;
	case 1 :                                /* short version */
		DATE_MonthName(month, date, 0);     /* PMSTA-24412 - 120816 - PMO */
		break;
	case 2 :                                /* long version */
		DATE_MonthName(month, date, 1);     /* PMSTA-24412 - 120816 - PMO */
		break;
	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_FormatToStr", "month format");
		return(FALSE);
	}

	switch (format->ordre)
	{
	/* "94.02.25", "19940225", "94/02/25", etc */
	case Ymd :
		sprintf(name, "%0*d%s%s%s%02d",
			       yLength, y, format->yearSep, month,
			       format->monthSep, d);
		break;

	/* "25feb94", "25/02/1994", etc */
	case Dmy :
		sprintf(name, "%02d%s%s%s%0*d", d, format->daySep, month,
					        format->monthSep, yLength, y);
		break;

	/* "Feb 25, 1994", etc */
	case Mdy :
        if (format->monthFormat == 0)
        {
            sprintf(name, "%s%s%02d%s%0*d", month, format->monthSep, d,
                    format->daySep, yLength, y);
        }
        else /* PMSTA-23226 - LJE - 160527 - Same behavior than isql */
        {
            sprintf(name, "%s%s%2d%s%0*d", month, format->monthSep, d,
                    format->daySep, yLength, y);
        }
		break;

	/* "19940225" or "940225" */
	case Iso :
		sprintf(name, "%0*d%s%s%s%02d", yLength, y, format->monthSep, month, format->daySep, d);
		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_DaysBetween", "order format");
		return(FALSE);
	}
	return(TRUE);
}

/************************************************************************
**
**  Function    :   DATE_ToDbStr()
**
**  Description :   Format the received date depending on the current DB
**                  format. The resulting string is with quotes !!
**
**  Arguments   :   name     pointer for the returned value (at least 38 char)
**                  date     date
**
**  Return      :   TRUE if success, FALSE elsewhere
**  Creation    :   PMSTA-20159 - TEB - 150624
*************************************************************************/
int DATE_ToDbStr(char *name, DATE_T date)
{
	int     ret;
	DATE_FORMAT_ST format;
	char    preStr[32];
	char    postStr[32];
	char    dateStr[32];

	switch (EV_RdbmsDdlGen)
	{
	case Sybase:
		/* Format is "dd/mm/yyyy" */
		format.ordre = Dmy;                     /* PMSTA-34402 - LJE - 190130 */
		format.yearFormat = 1; /* 4 digits */
		strcpy(format.yearSep, "/");
		strcpy(format.monthSep, "/");
		strcpy(format.daySep, "/");
		format.monthFormat = 0; /* numeric */
		strcpy(preStr, "\'");				/* PMSTA-20159 - TEB - 151117 */
		strcpy(postStr, "\'");				/* PMSTA-20159 - TEB - 151117 */
		break;
	case Oracle:
		/* Format is TO_DATE('01-DEC-2015','DD-MON-YYYY') */
		format.ordre = Dmy;
		format.yearFormat = 1; /* 4 digits */
		strcpy(format.yearSep, "-");
		strcpy(format.monthSep, "-");
		strcpy(format.daySep, "-");
		format.monthFormat = 1;
		strcpy(preStr, "TO_DATE(\'");				/* PMSTA-20159 - TEB - 151117 */
		strcpy(postStr, "\',\'DD-MON-YYYY\')");		/* PMSTA-20159 - TEB - 151117 */
		break;
    case Nuodb:
        /* Format is "mm/dd/yyyy" */
        format.ordre = Mdy;
        format.yearFormat = 1; /* 4 digits */
        strcpy(format.yearSep, "/");
        strcpy(format.monthSep, "/");
        strcpy(format.daySep, "/");
        format.monthFormat = 0; /* numeric */
        strcpy(preStr, "\'");	
        strcpy(postStr, "\'");	
        break;
    case MSSql:
        /* Format is "dd/mm/yyyy" */
        format.ordre = Dmy;                     /* PMSTA-40978 - PRAJIN - 201009 */
        format.yearFormat = 1; /* 4 digits */
        strcpy(format.yearSep, "/");
        strcpy(format.monthSep, "/");
        strcpy(format.daySep, "/");
        format.monthFormat = 0; /* numeric */
        strcpy(preStr, "\'");				/* PMSTA-20159 - TEB - 151117 */
        strcpy(postStr, "\'");				/* PMSTA-20159 - TEB - 151117 */
        break;
    case PostgreSQL:
        /* Format is "yyyy/mm/dd" */
        format.ordre = Ymd;
        format.yearFormat = 1; /* 4 digits */
        strcpy(format.yearSep, "/");
        strcpy(format.monthSep, "/");
        strcpy(format.daySep, "/");
        format.monthFormat = 0; /* numeric */
        strcpy(preStr, "\'");
        strcpy(postStr, "\'");
        break;
    }

	/* PMSTA-20159 - TEB - 151117 */
	if ((ret = DATE_FormatToStr(dateStr, date, &format)) == TRUE)
	{
		sprintf(name, "%s%s%s", preStr, dateStr, postStr);
	}
	return(ret);

}

/************************************************************************
**
**  Function    :   DATETIME_ToDbStr()
**
**  Description :   Format the received date time depending on the current DB
**                  format. The resulting string is with quotes !!
**
**  Arguments   :   name     pointer for the returned value (at least 57 char)
**                  date     date
**                  time     time
**
**  Return      :   TRUE if success, FALSE elsewhere
**  Creation    :   PMSTA-20159 - TEB - 150624
*************************************************************************/
int DATETIME_ToDbStr(char *name, DATE_T date, TIME_T time)
{
    int     ret;
    HOUR_T	 hour;
    MINUTE_T minute;
    SECOND_T second;
    char    preStr[32];
    char    postStr[32];
    char    dateStr[32];

    string  dateTimeSep(" ");
    DATE_FORMAT_ST format;

    TIME_Get(time, &hour, &minute, &second);

    switch (EV_RdbmsDdlGen)
    {
        case Sybase:
            /* Format is 'dd/mm/yyyy hh:mi:ss' */
            format.ordre       = Dmy;                 /* PMSTA-34402 - LJE - 190130 */
            format.yearFormat  = 1; /* 4 digits */
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            strcpy(preStr, "\'");
            strcpy(postStr, "\'");
            break;

        case Oracle:
            /* Format is TO_DATE('01-DEC-2015 10:11:12','DD-MON-YYYY HH24:MI:SS') */
            format.ordre       = Dmy;
            format.yearFormat  = 1; /* 4 digits */
            strcpy(format.yearSep, "-");
            strcpy(format.monthSep, "-");
            strcpy(format.daySep, "-");
            format.monthFormat = 1;
            strcpy(preStr, "TO_DATE(\'");
            strcpy(postStr, "\',\'DD-MON-YYYY HH24:MI:SS\')");
            break;

        case Nuodb:
            /* Format is 'dd/mm/yyyy hh:mi:ss' */
            format.ordre       = Ymd;                 /* PMSTA-34402 - LJE - 190130 */
            format.yearFormat  = 1; /* 4 digits */
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            strcpy(preStr, "\'");
            strcpy(postStr, "\'");
            break;

        case MSSql:
            /* Format is 'dd/mm/yyyy hh:mi:ss' */
            format.ordre = Dmy;                 /* PMSTA-40978 - PRAJIN - 201009 */
            format.yearFormat = 1; /* 4 digits */
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            strcpy(preStr, "\'");
            strcpy(postStr, "\'");
            break;

        case QtHttp:
		case Sqlite:
			format.ordre       = Iso;
            format.yearFormat = 1; /* 4 digits */
            strcpy(format.yearSep, "-");
            strcpy(format.monthSep, "-");
            strcpy(format.daySep, "-");
            format.monthFormat = 0; /* numeric */
            strcpy(preStr, "");
            strcpy(postStr, "");
            dateTimeSep = "T";
            break;

        case PostgreSQL:
            /* Format is 'yyyy/mm/dd hh:mi:ss' */
            format.ordre = Ymd;                 /* PMSTA-34402 - LJE - 190130 */
            format.yearFormat = 1; /* 4 digits */
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            strcpy(preStr, "\'");
            strcpy(postStr, "\'");
            break;
    }

    if ((ret = DATE_FormatToStr(dateStr, date, &format)) == TRUE)
    {
        sprintf(name, "%s%s%s%02d:%02d:%02d%s", preStr, dateStr, dateTimeSep.c_str(), hour, minute, second, postStr);
    }
    return(ret);
}
/************************************************************************
*   Function             : to_stringSql()
*
*   Description          : Format a date for using into a SQL statement
*
*   Arguments            : date Date to convert
*
*   Global var. modified : None
*
*   Return               : Date formated
*
*   Last modif.          :
*
*************************************************************************/
std::string to_stringSql(const DATE_T date)
{
    char strDate[DATE_SQL_STRING_SIZE];     /* PMSTA-20159 - TEB - 151117 */
    DATE_ToDbStr(strDate, date);            /* PMSTA-20159 - TEB - 151110 */

    return strDate;
}



/************************************************************************
*   Function             : DATE_ToYyyyMmDdInt
*
*   Description          : Format a date as a yyyymmdd string for std containers
*                           and auto-sorting 
*                           20121210
*                           20140405
*                           20150228
*
*   Arguments            : date Date to convert
*
*   Return               : yyymmdd string
*
*   Last modif.          :
*
*************************************************************************/
std::string DATE_ToYyyyMmDdStr(const DATE_T date)
{
      DATE_FORMAT_ST	     dateFormat;
    /* date fromat initialisation */
    dateFormat.ordre = Ymd;
    strcpy(dateFormat.yearSep,  "");
    strcpy(dateFormat.monthSep, "");
    strcpy(dateFormat.daySep,   "");
    dateFormat.yearFormat = 1;
    dateFormat.monthFormat = 0;
    char str[20];
    DATE_FormatToStr(str,date,&dateFormat);
    std::string resultStr = str;

    return resultStr;
}


/************************************************************************
*   Function             : DATE_ToYyyyMmDdInt
*
*   Description          : Format a date as a yyyymmdd string for std containers
*                           and auto-sorting 
*                           20121210
*                           20140405
*                           20150228
*
*   Arguments            : date Date to convert
*
*   Return               : yyymmdd string
*
*   Last modif.          :
*
*************************************************************************/
DATE_T DATE_YyyyMmDdStrToDate(std::string & yyyymmddStr)
{   
    DATE_T date = BAD_DATE;

    if(yyyymmddStr.length() == 8)
    {
        YEAR_T y = (YEAR_T)atoi(yyyymmddStr.substr(0,4).c_str());
        MONTH_T m = (MONTH_T)atoi(yyyymmddStr.substr(4,2).c_str());
        DAY_T d = (DAY_T)atoi(yyyymmddStr.substr(6,2).c_str());
        date = DATE_Put(y,m,d);
    }
    return date;
}

/************************************************************************
**
**  Function    :   DATE_ToSqlStr()
**
**  Description :   Format the received date to SQL tool
**
**  Arguments   :   name     string
**                  date     date
**
**  Return      :   TRUE if success, FALSE elsewhere
**
**  Creation    :   PMSTA-23226 - LJE - 160526
**
*************************************************************************/
int DATETIME_ToSqlStr(string &name, DATETIME_T dateTime, DATE_STYLE_ENUM dateStyle, TIME_STYLE_ENUM timeStyle)
{
    int             ret;
    DATE_FORMAT_ST  format;
    char            dateStr[32];
    string          dataTimeSep(" ");

    if (dateStyle == DateStyle_MmmDdYyyy12b)
    {
        dateStyle = DateStyle_MmmDdYyyy12;
    }

    if (dateStyle > 100)
    {
        /* Without century */
        dateStyle = (DATE_STYLE_ENUM)(dateStyle - 100);
        format.yearFormat = 0; /* 2 digits */
    }
    else
    {
        /* With century */
        format.yearFormat = 1; /* 4 digits */
    }

    switch (dateStyle)
    {
        case DateStyle_MmDdYyyy:
            /* Format is "mm/dd/yyyy" */
            format.ordre = Mdy;
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            break;
        case DateStyle_DdMmYyyy:
            /* Format is "dd/mm/yyyy" */
            format.ordre = Dmy;
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.monthFormat = 0; /* numeric */
            break;
        case DateStyle_YyyyMmDd24:
            /* Format is "yyyy-mm-dd" */
            format.ordre = Ymd;
            strcpy(format.yearSep, "-");
            strcpy(format.monthSep, "-");
            strcpy(format.daySep, "-");
            format.monthFormat = 0; /* numeric */
            break;
        case DateStyle_Iso:
            /* Format is "yyyy-mm-dd" */
            format.ordre = Iso;
            strcpy(format.yearSep, "-");
            strcpy(format.monthSep, "-");
            strcpy(format.daySep, "-");
            format.monthFormat = 0; /* numeric */
            dataTimeSep = "T";
            break;
        case DateStyle_IsoCompact:
            /* Format is "yyyymmdd" */
            format.ordre = Iso;
            strcpy(format.yearSep, "");
            strcpy(format.monthSep, "");
            strcpy(format.daySep, "");
            format.monthFormat = 0; /* numeric */
            dataTimeSep = "T";
            break;
        case DateStyle_MmmDdYyyy12:
        default:
            /* Format is "mmm dd yyyy hh:nnAM (or PM)" */
            format.ordre = Mdy;
            strcpy(format.yearSep, " ");
            strcpy(format.monthSep, " ");
            strcpy(format.daySep, " ");
            format.monthFormat = 1; /* Alpha */
            timeStyle = TimeStyle_12;
            break;
    }

    if ((ret = DATE_FormatToStr(dateStr, dateTime.date, &format)) == TRUE)
    {
        if (format.monthFormat == 1)
        {
            dateStr[0] = (char)toupper(dateStr[0]);
        }
        name = dateStr;
    }

    if (timeStyle != TimeStyle_None)
    {
        char     strTime[30];
        HOUR_T   h;
        MINUTE_T min;
        SECOND_T s;

        TIME_Get(dateTime.time, &h, &min, &s);

        switch (timeStyle)
        {
            case TimeStyle_12:
            {
                bool bAm = true;

                if (h == 0)
                {
                    h = 12;
                }
                else if (h == 12)
                {
                    bAm = false;
                }
                else if (h > 12)
                {
                    bAm = false;
                    h -= 12;
                }
                if (dateStyle == DateStyle_IsoCompact)
                {
                    sprintf(strTime, "%s%2d%02d%s", dataTimeSep.c_str(), h, min, bAm ? "AM" : "PM"); 
                }
                else
                {
                    sprintf(strTime, "%s%2d:%02d%s", dataTimeSep.c_str(), h, min, bAm ? "AM" : "PM");
                }
            }
            break;

            case TimeStyle_24:
            default:
                if (dateStyle == DateStyle_IsoCompact)
                {
                    sprintf(strTime, "%s%02d%02d%02d", dataTimeSep.c_str(), h, min, s);
                }
                else
                {
                    sprintf(strTime, "%s%02d:%02d:%02d", dataTimeSep.c_str(), h, min, s);
                }
                break;
        }

        name += strTime;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DATE_FormatToDate()
**
**  Description :   Compute date depending on the specified format.
**
**  Arguments   :   name     date string
**                  format   format structure, ordre, date and month format, ...
**
**  Return      :   Date, BAD_DATE if error
**
*************************************************************************/
DATE_T DATE_FormatToDate(const char *name, DATE_FORMAT_STP format)
{
	DATE_T  date;
	int     yLength, mLength, dLength, i, ry, rm, rd;
	YEAR_T  y;
	MONTH_T m;
	DAY_T   d;

	switch (format->ordre)
	{
	/* "94.02.25", "19940225", "94/02/25", etc ... */
	case Ymd :
		/* Year (length 2 or 4) */
		y = DATE_TreatYearFormat(name, format, &yLength);

		/* move at begin of month */
		i = yLength;

		/* Month (string or numeric) */
		m = DATE_TreatMonthFormat(name+i, format, &mLength);

		/* move at begin of day */
		i += mLength;

		/* Day */
		d = DATE_TreatDayFormat(name+i, format, &dLength);
		break;

	/* "25feb94", "25/02/1994", etc ... */
	case Dmy :
		/* Day */
		d = DATE_TreatDayFormat(name, format, &dLength);

		/* move at begin of month */
		i = dLength;

		/* Month (string or numeric) */
		m = DATE_TreatMonthFormat(name+i, format, &mLength);

		/* move at begin of year */
		i += mLength;

		/* Year (length 2 or 4) */
		y = DATE_TreatYearFormat(name+i, format, &yLength);
		break;

	/* "feb 25, 1994", etc ... */
	case Mdy :
		/* Month (string or numeric) */
		m = DATE_TreatMonthFormat(name, format, &mLength);

		/* move at begin of day */
		i = mLength;

		/* Day */
		d = DATE_TreatDayFormat(name+i, format, &dLength);

		/* move at begin of year */
		i += dLength;

		/* Year (length 2 or 4) */
		y = DATE_TreatYearFormat(name+i, format, &yLength);
		break;

	/* "19940225" or "940225" */
	case Iso :
		if (format->yearFormat == 1)     /* long version */
			(void)sscanf(name, "%4d-%2d-%2d", &ry, &rm, &rd);
		else
		{                                /* short version */
            (void)sscanf(name, "%2d-%2d-%2d", &ry, &rm, &rd);
			if (ry>=50 && ry<100) ry+=1900;
			else if (ry<50) ry+=2000;
		}
		y = (YEAR_T) ry;
		m = (MONTH_T) rm;
		d = (DAY_T) rd;
		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_FormatToDate", "order format");
		return(BAD_DATE);
	}
    if (m > 12 || m == 0 || d == 0) /* DLA - PMSTA-27995 - 170810 */
    {
        return(BAD_DATE);
    }
	date = DATE_PUT(y, m, d);
	return(date);
}

/************************************************************************
**
**  Function    :   DATETIME_FormatToDateTime()
**
**  Description :   Compute date time depending on the specified format.
**
**  Arguments   :   name     : date string
**                  format   : format structure, order, date and month format, ...
**
**  Return      :   
**
*************************************************************************/
RET_CODE DATETIME_FormatToDateTime(const char *dateStr, DATETIME_T &dateTimeSt, DATE_FORMAT_STP formatStp)
{
    int     yLength, mLength, dLength, i;
    YEAR_T        y = 0;
    MONTH_T       m = 0;
    DAY_T         d = 0;
    HOUR_T        h = 0;
    MINUTE_T      min = 0;
    SECOND_T      sec = 0;

    dateTimeSt.date = 0;
    dateTimeSt.time = 0;

    switch (formatStp->ordre)
    {
        /* "94.02.25", "19940225", "94/02/25", etc ... */
        case Ymd:
            /* Year (length 2 or 4) */
            y = DATE_TreatYearFormat(dateStr, formatStp, &yLength);

            /* move at begin of month */
            i = yLength;

            /* Month (string or numeric) */
            m = DATE_TreatMonthFormat(dateStr + i, formatStp, &mLength);

            /* move at begin of day */
            i += mLength;

            /* Day */
            d = DATE_TreatDayFormat(dateStr + i, formatStp, &dLength);

            i += dLength;
            break;

            /* "25feb94", "25/02/1994", etc ... */
        case Dmy:
            /* Day */
            d = DATE_TreatDayFormat(dateStr, formatStp, &dLength);

            /* move at begin of month */
            i = dLength;

            /* Month (string or numeric) */
            m = DATE_TreatMonthFormat(dateStr + i, formatStp, &mLength);

            /* move at begin of year */
            i += mLength;

            /* Year (length 2 or 4) */
            y = DATE_TreatYearFormat(dateStr + i, formatStp, &yLength);

            i += yLength;
            break;

            /* "feb 25, 1994", etc ... */
        case Mdy:
            /* Month (string or numeric) */
            m = DATE_TreatMonthFormat(dateStr, formatStp, &mLength);

            /* move at begin of day */
            i = mLength;

            /* Day */
            d = DATE_TreatDayFormat(dateStr + i, formatStp, &dLength);

            /* move at begin of year */
            i += dLength;

            /* Year (length 2 or 4) */
            y = DATE_TreatYearFormat(dateStr + i, formatStp, &yLength);

            i += yLength;
            break;

            /* "1994-02-25T00:00:00.000" or "940225" */
        case Iso:
        {
            int ry = 0, rm = 0, rd = 0, rh = 0, rmin = 0, rs = 0;
            if (formatStp->yearFormat == 1)     /* long version */
            {
                if (strstr(dateStr, "-") != nullptr)
                {
                    (void)sscanf(dateStr, "%4d-%2d-%2dT%2d:%2d:%2d", &ry, &rm, &rd, &rh, &rmin, &rs);
                }
                else
                {
                    (void)sscanf(dateStr, "%4d%2d%2dT%2d:%2d:%2d", &ry, &rm, &rd, &rh, &rmin, &rs);
                }
            }
            else
            {                                /* short version */
                (void)sscanf(dateStr, "%2d%2d%2dT%2d:%2d:%2d", &ry, &rm, &rd, &rh, &rmin, &rs);
                if (ry >= 50 && ry < 100)
                {
                    ry += 1900;
                }
                else if (ry < 50)
                {
                    ry += 2000;
                }
            }
            y = (YEAR_T)ry;
            m = (MONTH_T)rm;
            d = (DAY_T)rd;
            h = (HOUR_T)rh;
            min = (MINUTE_T)rmin;
            sec = (SECOND_T)rs;
            break;
        }

        default:
            MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO, "DATETIME_FormatToDateTime", "order format");
            return(RET_DBA_ERR_INVALID_FORMAT);
    }

    if (y == 0 || m > 12 || m == 0 || d == 0) /* DLA - PMSTA-27995 - 170810 */
    {
        return(RET_DBA_ERR_INVALID_FORMAT);
    }
    dateTimeSt.date = DATE_Put(y, m, d);
    dateTimeSt.time = TIME_Put(h, min, sec);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DATE_TreatYearFormat()
**
**  Description :   Convert in int value the year depending on year
**                  format and update length used by year in date string.
**
**  Arguments   :   year    string year
**                  format  structure for date format
**                  yLength pointer for year length + year separator
**
**  Return      :   year
**
*************************************************************************/
STATIC YEAR_T DATE_TreatYearFormat(const char *year, DATE_FORMAT_STP format,
				   int *yLength)
{
	char   tempo[5];
	int    i;
	YEAR_T y;

	/* Year format (1994 or 94) */
	if (format->yearFormat == 0)
		*yLength = 2;                    /* short version */
	else
		*yLength = 4;                    /* long version */

	for (i=0; i<*yLength; i++)
		tempo[i] = year[i];
	tempo[i] = END_OF_STRING;

	/* 94 -> 1994 ?? */
	y = (YEAR_T) atoi(tempo);

	*yLength += SYS_StrLen(format->yearSep);
	return(y);
}

/************************************************************************
**
**  Function    :   DATE_TreatMonthFormat()
**
**  Description :   Convert in int value the month depending on month
**                  format and update length used by month in date string.
**
**  Arguments   :   month   string month
**                  format  structure for date format
**                  mLength pointer for month length + month separator
**
**  Return      :   month
**
*************************************************************************/
STATIC MONTH_T DATE_TreatMonthFormat(const char *month, DATE_FORMAT_STP format,
				     int *mLength)
{
	char    tempo[25];
	int     i;
	MONTH_T m;

	if (format->monthFormat == 0)
	{
		i = *mLength = 0;
		/* PMSTA-34167 - TEB - 181214 */
		/* Max 2 digits or until a non month characters is found */
		while (month[i] != format->monthSep[0] &&
			isdigit(month[i]) &&
			month[i] != END_OF_STRING
			&& i < 2)
			tempo[(*mLength)++] = month[i++];
		tempo[*mLength] = END_OF_STRING;

		m = (MONTH_T)atoi(tempo);
	}
	else
	{
		i = *mLength = 0;
		/* Until a non month characters is found */
		while (month[i] != format->monthSep[0] &&
		       !strchr("0123", month[i]) && month[i] != END_OF_STRING)
			tempo[(*mLength)++] = month[i++];
		tempo[*mLength] = END_OF_STRING;

		/* value 0 or 1 for type (second argument) */
		m = DATE_MonthNbr(tempo, (format->monthFormat)-1);
	}

	*mLength += SYS_StrLen(format->monthSep);
	return(m);
}

/************************************************************************
**
**  Function    :   DATE_TreatDayFormat()
**
**  Description :   Convert in int value the day and update length used
**                  by day in date string.
**
**  Arguments   :   day     string day
**                  format  structure for date format
**                  dLength pointer for day length + day separator
**
**  Return      :   day
**
*************************************************************************/
STATIC DAY_T DATE_TreatDayFormat(const char *day, DATE_FORMAT_STP format,
				 int *dLength)
{
	char tempo[3];
	DAY_T d;

	tempo[0] = day[0];
	tempo[1] = day[1];
	tempo[2] = END_OF_STRING;
	d = (DAY_T) atoi(tempo);

	*dLength = 2 + SYS_StrLen(format->daySep);
	return(d);
}

/************************************************************************
**
**  Function    :   DATE_IsLastInMonth()
**
**  Description :   Determine if a day is the last day in month.
**
**  Arguments   :   date
**
**  Return      :   TRUE if received date is last day in month,
**                  FALSE elsewhere.
**
*************************************************************************/
int DATE_IsLastInMonth(DATE_T date)
{
	int     last;
	YEAR_T  y;
	MONTH_T m;
	DAY_T   d;

	DATE_Get(date, &y, &m, &d);

	last = (int) DAYSINMONTHY(m, y);

	if (last == d)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DATE_Part()
**
**  Description :   Extract a part from a date switch the part type specified.
**
**  Arguments   :   date
**                  choice
**
**  Return      :   part, BAD_DATE_PART if error
**
*************************************************************************/
long DATE_Part(DATE_T date, DATE_PART_ENUM choice)
{
	long     part;
	int      x;
	YEAR_T   y;
	MONTH_T  m;
	DATE_T   date0;

	switch (choice)
	{
	/* 1 to 7   (1=Sunday,   2=Monday, 3=Tuesday, 4=Wednesday, */
        /*           5=Thursday, 6=Friday, 7=Saturday)             */
	case DayInWeek :
		part = (long) DATE_WhichWeekDay(date) + 1L;
		break;

	/* 1 to 31 */
	case DayInMonth :
		part = (long) DATE_GET_D(date);
		break;

	/* 1 to 92 */
	case DayInQuarter :
		m = DATE_GET_M(date);
		y = DATE_GET_Y(date);

		/* Day in year */
		part = (long) DAYSBEFOREMONTHY(m, y);
		part += (long) DATE_GET_D(date);

		/* Quarter in year (0 to 3) */
		x = ((long) (DATE_GET_M(date)) -1) / 3;

		/* If 2,3 or 4 quarter, remove days */
		if (x)
		{
			/* second quarter - remove first quarter days */
			part -= ((LEAP_YEAR(y)==TRUE) ? 91L : 90L);

			/* third quarter - remove too second quarter days */
			if (x >= 2) part -= 91L;

			/* fourth quarter - remove too third quarter days */
			if (x == 3) part -=  92L;
		}
		break;

	/* 1 to 183 */
	case DayInSemester :
		m = DATE_GET_M(date);
		y = DATE_GET_Y(date);

		/* Day in year */
		part = (long) DAYSBEFOREMONTHY(m, y);
		part += (long) DATE_GET_D(date);

		/* Semester in year (0 or 1) */
		x = ((long)(m) -1) / 6;

		/* If 2 semester, remove days in first semester */
		if (x) part -= ((LEAP_YEAR(y)==TRUE) ? 182L : 181L);
		break;

	/* 1 to 366 */
	case DayInYear :
		part = (long) DAYSBEFOREMONTHY(DATE_GET_M(date),
					       DATE_GET_Y(date));
		part += (long) DATE_GET_D(date);
		break;

	/* 1 to 3653 */
	case DayInDecade :
		y = DATE_GET_Y(date);

		/* year in decade (0-9) */
		x = (int) (y) %10;

		/* 1 January, decade 0 */
		date0 = DATE_PUT(y-x, 1, 1);

		/* Begin at 1 (but 1990.1.1 - 1990.1.1 = 0) */
		DATE_DaysBetween(date0, date, AccrRule_Actual_Actual, &part, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
		part +=1L;
		break;

	case DayInCentury :
		y = DATE_GET_Y(date);

		/* year in century (0-99) */
		x = (int) (y) %100;

		/* 1 January, century 0 */
		date0 = DATE_PUT(y-x, 1, 1);

		/* Begin at 1 (but 1990.1.1 - 1990.1.1 = 0) */
		DATE_DaysBetween(date0, date, AccrRule_Actual_Actual, &part, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
		part += 1L;
		break;

	case DayInAll :
		part = 0L;
		break;

	 /* 1 to 53 */
	case WeekInYear :
		/* Day in year / 7 */
		x = DAYSBEFOREMONTHY(DATE_GET_M(date), DATE_GET_Y(date));
		x += DATE_GET_D(date);
		part = (long) (x/7)+1;
		break;

	case WeekInAll :
		part = 0L;
		break;

	/* 1 to 3 */
	case MonthInQuarter :
		/* Month-1 = value 0 to 11 */
		part = (((long) (DATE_GET_M(date)) -1L) %3L) +1L;
		break;

	/* 1 to 6 */
	case MonthInSemester :
		/* Month-1 = value 0 to 11 */
		part = (((long) (DATE_GET_M(date)) -1) %6) +1L;
		break;

	/* 1 to 12 */
	case MonthInYear :
		part = (long) DATE_GET_M(date);
		break;

	case MonthInAll :
		part = 0L;
		break;

	/* 1 to 4 */
	case QuarterInYear :
		/* Month-1 = value 0 to 11             */
                /* (0 to 2)  / 3 -> 0 = first quarter  */
                /* (3 to 5)  / 3 -> 1 = second quarter */
		/* (6 to 8)  / 3 -> 2 = third quarter  */
                /* (9 to 11) / 3 -> 3 = fourth quarter */
		part = (((long) (DATE_GET_M(date)) -1) /3) +1L;
		break;

	/* 1 or 2 */
	case SemesterInYear :
		/* Month-1 = value 0 to 11              */
                /* (0 to 5)  / 6 -> 0 = first semester  */
		/* (6 to 11) / 6 -> 1 = second semester */
		part = (((long) (DATE_GET_M(date)) -1) /6) +1L;
		break;

	/* 1 to 10 */
	case YearInDecade :
		part = (long) (DATE_GET_Y(date)%10)+1;
		break;

	/* 1 to 100 */
	case YearInCentury :
		part = (long) (DATE_GET_Y(date)%100);
		break;

	case YearInAll :
		part = 0L;
		break;

	/* 1 to 10 */
	case DecadeInCentury :
		/* Year in century / 10 */
		part = ((long) (DATE_GET_Y(date)) %100 /10) +1L;
		break;

	case DecadeInAll :
		part = 0L;
		break;

	case CenturyInAll :
		part = 0L;
		break;

	default :
		MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO,
			     "DATE_Part", "part choice");
		part = BAD_DATE_PART;
		break;
	}
	return(part);
}

/************************************************************************
**
**  Function    :   DATE_DateToDnum()
**
**  Description :   Convert a date to a dnum.
**                  (days number between DNUM0DATE and received date)
**
**  Return      :   dnum
**
*************************************************************************/
STATIC DATE_DNUM_T DATE_DateToDnum(DATE_T date)
{
	int         y, n;
	DATE_DNUM_T dnum;
	int         year;

	year= (int) DATE_GET_Y(date);

	/* Computing dnum for years */
	dnum= 0L;
	y= year - DNUM0YEAR;

        /* Period is 400 year long */
	n= y / 400;
	dnum+= n * DAYSIN400YEAR;
	y-= n * 400;

        /* Period is 100 year long */
	n= y / 100;
	dnum+= n * DAYSIN100YEAR;
	y-= n * 100;

        /* Period is 4 year long */
	n= y / 4;
	dnum+= n * DAYSIN4YEAR;
	y-= n * 4;

        /* Period is 1 year long */
	n= y;
	dnum+= n * DAYSIN1YEAR;
	y-= n;

	/* Adding months and days to dnum */
	dnum+= DAYSBEFOREMONTHY(DATE_GET_M(date), year)
	       + (long) DATE_GET_D(date) - DNUM0DAY;

	return dnum;
}

/************************************************************************
**
**  Function    :   DATE_DNumToDate()
**
**  Description :   Converts a dnum to a date.
**                  (dnum is days number between DNUM0DATE and received date)
**
**  Arguments   :   dnum
**
**  Return      :   date in DATE_T format
**
*************************************************************************/
STATIC DATE_T DATE_DnumToDate(DATE_DNUM_T dnum)
{
	int     leapyear, daysbeforemonth, day, n, /* number of periods */
	        year, month;

	/* Computation of year:                                          */
	/* Periods are 400 years, 100 years, 4 years and finally 1 year. */
	/* For each period,                                              */
	/* each time year is incremented, dnum is decremented.           */
	year= DNUM0YEAR;          /* Year when dnum is 0 */

				  /* Period is 400 year long               */
	n= dnum / DAYSIN400YEAR;  /* number of periods                     */
	year+= n * 400;           /* add 400 years times number of periods */
	dnum%= DAYSIN400YEAR;     /* days left in current period           */

				  /* Period is 100 year long                 */
	n= dnum / DAYSIN100YEAR;  /* number of periods                       */
	if (n == 4) n= 3;         /* because the last period has 1 extra day */
	year+= n * 100;           /* add 100 years times number of periods   */
	dnum-= n * DAYSIN100YEAR; /* days left in current period             */

				  /* Period is 4 year long               */
	n= dnum / DAYSIN4YEAR;    /* number of periods                   */
	year+= n * 4;             /* add 4 years times number of periods */
	dnum%= DAYSIN4YEAR;       /* days left in current period         */

				  /* Period is 1 year long                    */
	n= dnum / DAYSIN1YEAR;    /* number of periods                        */
	if (n == 4) n= 3;         /* because last period may have 1 extra day */
	year+= n;                 /* add 1 year times number of periods       */
	dnum-= n * DAYSIN1YEAR;   /* days left in current period              */

	/* Now                                                 */
	/* year is the right year and                          */
	/* dnum is the number of the day in this year minus 1. */
	/* January 1st is number 0.                            */

	/* Computation of month and day                           */
	/* 1. Guest the month number by the formula day/30.       */
	/*    This guest is quite accurate                        */
	/*    but it is wrong for the last days of some months.   */
	/*    In those cases, it gives the next month.            */
	/* 2. Check if the guess is in the right month.           */
	/* 3. If in the wrong month, shift to the previous month. */

	day = dnum + 1;           /* the day number in the year  */

	leapyear = ((LEAP_YEAR(year)==TRUE)?1:0);
	month = day / 30 + 1;     /* guess */
	daysbeforemonth = DAYSBEFOREMONTHLY(month, leapyear);
	if (day > daysbeforemonth)/* guess is right */
		day-= daysbeforemonth;
	else                      /* guess is wrong, go to the previous month */
	{
		month--;
		day-= DAYSBEFOREMONTHLY(month, leapyear);
	}

	return DATE_PUT(year, month, day);
}

/************************************************************************
**
**  Function    :   DATE_WhichWeekDay()
**
**  Description :   Determine which week day is a date.
**                  Use DNUM0DATE as reference.
**
**  Arguments   :   date
**
**  Return      :   0 (Sunday),   1 (Monday), 2 (Tuesday), 3 (Wednesday),
**                  4 (Thursday), 5 (Friday), 6 (Saturday)
**
*************************************************************************/
char DATE_WhichWeekDay(DATE_T date)
{
	DATE_DNUM_T  dnum;
	char         day;

	dnum = DATE_DateToDnum(date);   /* Thursday 24.3.1994 = 143622 */
	day = (char)((dnum + 1L) % 7L); /* 143622 % 7 = 3, Thursday is 4 */

	return (day);
}

/************************************************************************
**
**  Function    :   DATE_DaysInMonth()
**
**  Description :   return the number of days in the month m of year y
**
**  Arguments   :   month and year
**
**  Return      :   number of days
**
*************************************************************************/
DAY_T DATE_DaysInMonth(MONTH_T m, YEAR_T y)
{
	return((DAY_T) DAYSINMONTHY(m,y));
}

/************************************************************************
**
**  Function    :   DATE_VerifyEndMonth()
**
**  Description :   Verify if a day number was corrupted by a short month
**                  When day number is upper than 28 (shortest end of month)
**                  put day number at end of month if saved day number
**                  was an end of month, put on saved day number if date was
**                  perhaps corrupted.
**
**  Arguments   :   datePtr         pointer on date to verify
**                  saveDay         old day
**                  endMonthFlg     TRUE if old day is an end of month
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
int DATE_VerifyEndMonth(DATE_T *datePtr, DAY_T saveDay, char endMonthFlg)
{
	YEAR_T  y;
	MONTH_T m;
	DAY_T   d, max;

	if (saveDay >= 28)
	{
		DATE_Get(*datePtr, &y, &m, &d);
		max = DATE_DaysInMonth(m, y);

		/* Put on end of month */
		if (endMonthFlg == TRUE)
		{
			if ((*datePtr = DATE_Put(y, m, max)) == BAD_DATE)
			{
				MSG_SendMesg(RET_GEN_ERR_INVALIDATE, 0, FILEINFO);
				return(FALSE);
			}
		}
		/* A short month have corrupt day number, */
		/* set saved day number                   */
		/* else if (d != saveDay && max > d && max >= saveDay) test that d is biggest than max as no sense PMSTA6761 - DDV - 080812 */
		else if (d != saveDay && max >= saveDay)
		{
			if ((*datePtr = DATE_Put(y, m, saveDay)) == BAD_DATE)
			{
				MSG_SendMesg(RET_GEN_ERR_INVALIDATE, 0, FILEINFO);
				return(FALSE);
			}
		}
	}
	return(TRUE);
}

/************************************************************************
**
**  Function    :   DATE_CurrentDate()
**
**  Description :   return current date.
**
**  Arguments   :   none
**
**  Return      :   date
**
*************************************************************************/
DATE_T DATE_CurrentDate(void)
{
	DATE_T today;
	YEAR_T y;
	MONTH_T mo;
	DAY_T d;
	HOUR_T h;
	MINUTE_T mi;
	SECOND_T s;

	SYS_CurrentTime(&y, &mo, &d, &h, &mi, &s);

	/* SYS_CurrentTime return years since 1900 .. */
	/* so 100 for year 2000 */
	y += 1900;
	today = DATE_Put(y, mo, d);

	return(today);
}

/************************************************************************
**
**  Function    :   DATE_CurrentDate()
**
**  Description :   return current date and time.
**
**  Arguments   :   pointer on date and time structure
**
**  Return      :   nothing
**
*************************************************************************/
void DATE_CurrentDateTime(DATETIME_T *dateTime, bool withMicroSecond)
{
	YEAR_T y;
	MONTH_T mo;
	DAY_T d;
	HOUR_T h;
	MINUTE_T mi;
	SECOND_T s;
    MICROSECOND_T ms;

    if (withMicroSecond)
    {
        SYS_CurrentTimeUs(&y, &mo, &d, &h, &mi, &s, &ms);
    }
    else
    {
        SYS_CurrentTime(&y, &mo, &d, &h, &mi, &s);
        ms = 0;
    }

	/* SYS_CurrentTime return years since 1900 .. */
	/* so 100 for year 2000 */
	y += 1900;
	dateTime->date = DATE_Put(y, mo, d);

	dateTime->time = TIME_Put(h, mi, s, ms);

	return;
}

/***************************************************************
/************************************************************************
**
**  Function    :   TIME_CurrentTime()
**
**  Description :   return current time.
**
**  Arguments   :   none
**
**  Return      :   Number which represent time.
**                  BAD_TIME if wrong time.
**
*************************************************************************/
TIME_T TIME_CurrentTime(void)
{
	TIME_T time=BAD_TIME;
	YEAR_T y;
	MONTH_T mo;
	DAY_T d;
	HOUR_T h;
	MINUTE_T mi;
	SECOND_T s;

	SYS_CurrentTime(&y, &mo, &d, &h, &mi, &s);

	time = TIME_Put(h, mi, s);

	return(time);
}

/************************************************************************
**
**  Function    :   TIME_Put()
**
**  Description :   Create a time number (depending on the received
**                  hour, minute and second) and return it.
**
**  Arguments   :   h     Hour
**                  m     Minute
**                  s     Second
**
**  Return      :   Number which represent time.
**                  BAD_TIME if wrong time.
**
*************************************************************************/
TIME_T TIME_Put(HOUR_T h, MINUTE_T m, SECOND_T s, MICROSECOND_T us)
{
    TIME_T time = 0;
    if (TIME_Check(h, m, s) == TRUE)
    {
        time = TIME_PUT_H(0, h) + TIME_PUT_M(0, m) + TIME_PUT_S(0, s) + TIME_PUT_MS(0, us);
    }
    else
    {
        time = BAD_TIME;
    }
	return(time);
}

/************************************************************************
**
**  Function    :   TIME_Get()
**
**  Description :   Read the received time number and update hour, minute
**                  and second. If hour, minute or second is null,
*                   doesn't return the value.
**                  ex : TIME_Get(time, &hour, NULL, NULL)
**                       -> modify only the hour value.
**
**  Arguments   :   time  Time
**                  h     Pointer on hour or NULL
**                  m     Pointer on minute or NULL
**                  s     Pointer on second or NULL
**
**  Return      :   none
**
*************************************************************************/
void TIME_Get(TIME_T time, HOUR_T *h, MINUTE_T *m, SECOND_T *s, MICROSECOND_T *us)
{
    if (us != nullptr)
    {
        *us = TIME_GET_MS(time);
    }
    if (s != NULL)
    {
        *s = TIME_GET_S(time);
    }
    if (m != NULL)
    {
        *m = TIME_GET_M(time);
    }
    if (h != NULL)
    {
        *h = TIME_GET_H(time);
    }
}

/************************************************************************
**
**  Function    :   TIME_Check()
**
**  Description :   Control if a time is valid.
**
**  Arguments   :   h   Hour
**                  m   Minute
**                  s   Second
**
**  Return      :   TRUE if time is valid, FALSE elsewhere.
**
*************************************************************************/
int TIME_Check(HOUR_T h, MINUTE_T m, SECOND_T s)
{
	if (h > 23) return(FALSE);

	if (m > 59) return(FALSE);

	if (s > 59) return(FALSE);

	return(TRUE);
}

/************************************************************************
**
**  Function    :   TIME_Diff()
**
**  Description :   Compute the number of second between two times (time1-time2)
**
**  Arguments   :   time1
**                  time2
**
**  Return      :   number of second between two times
**
**  REF4521 - RAK - 000414
**
*************************************************************************/
long TIME_Diff(TIME_T time1,
               TIME_T time2)
{
    HOUR_T      time1H, time2H;
    MINUTE_T    time1M, time2M;
    SECOND_T    time1S, time2S;
    long        diff;

    TIME_Get(time1, &time1H, &time1M, &time1S);
    TIME_Get(time2, &time2H, &time2M, &time2S);

    diff = ((time1H-time2H) * 3600) +
           ((time1M-time2M) * 60) +
           (time1S-time2S);

    return(diff);
}

/************************************************************************
**
**  Function    :   TIME_Add()
**
**  Description :   Add received second to received time
**
**  Arguments   :   time1
**                  time2
**
**  Return      :   number of second between two times
**
**  REF4521 - RAK - 000414
**
*************************************************************************/
TIME_T TIME_Add(TIME_T time, long diff, long *diffDays)
{
    HOUR_T      timeH;
    MINUTE_T    timeM;
    SECOND_T    timeS;
    MICROSECOND_T timeMS;
    long        timeDiff;

    TIME_Get(time, &timeH, &timeM, &timeS, &timeMS);

    timeDiff = timeH*3600 + timeM*60 + timeS;
    timeDiff += diff;

    /* 86400 = 24 hours */
    if (timeDiff < 0)
    {
        *diffDays = timeDiff/86400;
        (*diffDays)--;                  /* add one day to be positiv */
        timeDiff += (*diffDays * -86400);
    }
    else if (timeDiff > 86400)
    {
        *diffDays = timeDiff/86400;
        timeDiff -= (*diffDays * 86400);
    }

    timeH = (HOUR_T)(timeDiff/3600);
    timeDiff = timeDiff - (timeH*3600);

    timeM = (MINUTE_T)(timeDiff/60);
    timeDiff = timeDiff - (timeM*60);

    timeS = (SECOND_T) timeDiff;

    return(TIME_Put(timeH, timeM, timeS, timeMS));
}

/************************************************************************
**
**  Function    :   DATE_CrystalDates()
**
**  Description :   Determine according to the input begin and end date,
**                  the dates upon which the positions need to be valued.
**                  Notice that a monthly frequency means that computation
**                  is done on the begin date, then at the end of the begin
**                  date month (if different), then at every month end prior
**                  to the till date, then at the till date.
**
**  Arguments   :   begDate         begin date
**                  tillDate        till date
**                  freq            frequency number
**                  freqUnit        frequency unit
**		    synthAdminFlg   If begin date isn't an end of period, set end of period before.
**				    If end date isn't an end of period, set end of period before.
**
**                  crystalDatesPtr crystallised dates pointer to update
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   DVP232 - RAK - 961115
**  Modif	:   DVP261 - RAK - 961127
**  Modif	:   DVP479 - RAK - 970522
**  Modif	:   REF1465 - RAK - 980323
**  Modif	:   REF1402 - RAK - 981007
**  Modif	:   REF5358 - CSY - 010131: new argument posiEn
**  Modif	:   REF7244 - YST - 020430: new argument endDateIsPtfFreqFlg
**  Modif	:   PMSTA-55400 - DDV - 250304: new argument beginDateIsPtfFreqFlg
**
*************************************************************************/
RET_CODE DATE_CrystalDates(DATETIME_T       begDate,
		                   DATETIME_T       tillDate,
		                   TINYINT_T        freq,
		                   FREQUNIT_ENUM    freqUnit,
		                   char		        synthAdminFlg,
		                   DATETIME_T       **crystalDatesPtr,
		                   int              *crystalNbrPtr,
		                   char		        *endPeriodFlgPtr,
		                   DATETIME_T	    *endPeriodDatePtr,
                           DATE_POSI_ENUM   posiEn,    /* REF5358 - CSY - 010131 */
                           FLAG_T           *beginDateIsPtfFreqFlg,  /* REF7244 - YST - 020430 */
	                       FLAG_T           *endDateIsPtfFreqFlg)
{
	int            crystalSz=10, crystalNbr=0;
	DATE_T         endBegMonth;
	DATETIME_T     wrkDate;
	DATE_UNIT_ENUM dateUnit=Year;
	DAY_T          saveD;
	char           endMonth, end;

	if (begDate.date == BAD_DATE)
	{
   		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DATE_CrystalDates", "begin date");
		return(RET_GEN_ERR_INVARG);
	}

	/* if (DATETIME_CMP(begDate, tillDate) > 0)
	{
   		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DATE_CrystalDates", "begin and till date");
		return(RET_GEN_ERR_INVARG);
	} */


	(*crystalDatesPtr) = (DATETIME_T*) CALLOC(crystalSz, sizeof(DATETIME_T));

	if ((*crystalDatesPtr) == nullptr)
	{
		*crystalNbrPtr = 0;
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	switch (freqUnit)
	{
	case FreqUnit_Day:
		dateUnit = Day;
		break;

	case FreqUnit_BusDay:
		dateUnit = Day;
		break;

	case FreqUnit_Week:
		dateUnit = Week;
		break;

	case FreqUnit_Month:
    case FreqUnit_MonthGlobalTWR:   /* REF8877 - YST - 030312 */
    case FreqUnit_MonthTWR:         /* REF8877 - YST - 030312 */
		dateUnit = Month;
		break;

	case FreqUnit_Quarter:
		dateUnit = Quarter;
		break;

	case FreqUnit_Semester:
		dateUnit = Semester;
		break;

	case FreqUnit_Year:
		dateUnit = Year;
		break;
	}

	/* DVP479 - RAK - 970522 */
	if (endPeriodFlgPtr != NULL)
	{
	    *endPeriodFlgPtr = TRUE;

	    if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
	    	freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year ||
			freqUnit == FreqUnit_MonthGlobalTWR || freqUnit == FreqUnit_MonthTWR)	/* REF9693 - RAK - 040302 - Treat TWR like Month */
	    {
			wrkDate.time = 0;
			wrkDate.date = DATE_MovePosi(tillDate.date, posiEn, dateUnit); /* REF5358 - CSY - 010131 */
			if (tillDate.date != wrkDate.date)
			{
				*endPeriodFlgPtr = FALSE;
				if (endPeriodDatePtr != nullptr)
		    		*endPeriodDatePtr= wrkDate;
			}
	    }
	}

	/* Init working date, which will varying frequency by frequency */
	wrkDate = begDate;

	/* For montly frequency, computation is done on begin date, */
	/* then at the end of the input date month, then at every   */
	/* month end, then at till date                             */
	if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
	    freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year ||
		freqUnit == FreqUnit_MonthGlobalTWR || freqUnit == FreqUnit_MonthTWR)	/* REF9693 - RAK - 040302 - Treat TWR like Month */
	{
		endBegMonth = DATE_MovePosi(begDate.date, posiEn, dateUnit); /* REF5358 - CSY - 010131 */

		/* Date isn't an end of month */
		if (endBegMonth != begDate.date)
		{
			/* DVP261 - first date is end of period before from date */
			if (synthAdminFlg == TRUE)
			{
			    wrkDate.date = DATE_Move(endBegMonth, (int) freq * -1, dateUnit);
			    wrkDate.date = DATE_MovePosi(wrkDate.date, posiEn, dateUnit); /* REF5358 - CSY - 010131 */
			    (*crystalDatesPtr)[crystalNbr++] = wrkDate;
			}
			else	/* REF1402 */
			{
			     /* First crystallised date is begin date */
			     (*crystalDatesPtr)[crystalNbr++] = begDate;
			}

			wrkDate.date = endBegMonth;
			wrkDate.time = 0;
		}
	}

	/* Every frequency date is crystallised */
	/* First can be begin date or end of the input date month. */
	endMonth = (char) DATE_IsLastInMonth(wrkDate.date);
	DATE_Get(wrkDate.date, (YEAR_T *) NULL, (MONTH_T *) NULL, &saveD);
	end = FALSE;

	/* PMSTA-55400 - DDV - 250304 */
	if (beginDateIsPtfFreqFlg != nullptr)
	{
		*beginDateIsPtfFreqFlg = FALSE;
	}

	if (endDateIsPtfFreqFlg != nullptr)
	{
		*endDateIsPtfFreqFlg = FALSE;
	}

	bool bFirstDateMove = true;

	while (end == FALSE)
	{
	    if (crystalNbr+1 > crystalSz)
	    {
		    crystalSz += crystalSz;
		    (*crystalDatesPtr) = (DATETIME_T*) REALLOC((*crystalDatesPtr),
               	                                                crystalSz * sizeof(DATETIME_T));

		    if ((*crystalDatesPtr) == nullptr)
		    {
		        FREE(*crystalDatesPtr);
		        *crystalNbrPtr = 0;
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }
	    }

	    /* Last crystallised date is till date */	/* DVP479 */
	    if (wrkDate.date >= tillDate.date)
	    {
            /* REF7244 - YST - 020430 */
            /* When call from FIN_StoreBenchmarkDates(): mask of PA_DATETIME_ST must be set for tillDate=wrkDate */
			if (wrkDate.date == tillDate.date && endDateIsPtfFreqFlg != nullptr) 	/* PMSTA-55400 - DDV - 250304 */
			{
				*endDateIsPtfFreqFlg = TRUE;
			}

		    wrkDate.date = tillDate.date;
		    end = TRUE;
	    }

	    (*crystalDatesPtr)[crystalNbr++] = wrkDate;

	    wrkDate.date = DATE_Move(wrkDate.date, (int) freq, dateUnit);

	    /* Short month can corrupt day number */
	    if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
	        freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year||
			freqUnit == FreqUnit_MonthGlobalTWR || freqUnit == FreqUnit_MonthTWR)	/* REF9693 - RAK - 040302 - Treat TWR like Month */
		{
			DATE_VerifyEndMonth(&wrkDate.date, saveD, endMonth);
		}

		/* PMSTA-55400 - DDV - 250304 - Set beginDateIsPtfFreqFlg */
		if (bFirstDateMove && beginDateIsPtfFreqFlg != nullptr)
		{
			DATE_T prevFreqDate = DATE_Move(wrkDate.date, (int)(freq * (-1)), dateUnit);

			/* Short month can corrupt day number */
			if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
				freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year ||
				freqUnit == FreqUnit_MonthGlobalTWR || freqUnit == FreqUnit_MonthTWR)	/* REF9693 - RAK - 040302 - Treat TWR like Month */
			{
				DATE_VerifyEndMonth(&prevFreqDate, saveD, endMonth);
			}

			if (prevFreqDate == begDate.date)
			{
				*beginDateIsPtfFreqFlg = TRUE;
			}
			bFirstDateMove = false;
		}
	}

	*crystalNbrPtr = crystalNbr;

	/* REF1465 - Don't work without crystalisation date */
	if (*crystalNbrPtr == 0)
		return(RET_GEN_ERR_INVALIDATE);
	else
		return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DATE_EndOfPeriodFlg()
**
**  Description :   Determine according to the input begin and end date,
**                  the dates upon which the positions need to be valued.
**                  Notice that a monthly frequency means that computation
**                  is done on the begin date, then at the end of the begin
**                  date month (if different), then at every month end prior
**                  to the till date, then at the till date.
**
**  Arguments   :   tillDate         till date
**                  freq             frequency number
**                  freqUnit         frequency unit
**		    endPeriodFlgPtr  pointer on end period flag (updated)
**		    endPeriodDatePtr pointer on end period date (updated)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF1402 - RAK - 981207
**
*************************************************************************/
RET_CODE DATE_EndOfPeriodFlg(DATETIME_T    tillDate,
			     TINYINT_T     freq,
			     FREQUNIT_ENUM freqUnit,
			     char          *endPeriodFlgPtr,
			     DATETIME_T	   *endPeriodDatePtr)
{
	DATE_UNIT_ENUM 	dateUnit=Year;
	DATETIME_T	wrkDate;

	switch (freqUnit)
	{
	case FreqUnit_Day:
		dateUnit = Day;
		break;

	case FreqUnit_BusDay:
		dateUnit = Day;
		break;

	case FreqUnit_Week:
		dateUnit = Week;
		break;

	case FreqUnit_Month:
		dateUnit = Month;
		break;

	case FreqUnit_Quarter:
		dateUnit = Quarter;
		break;

	case FreqUnit_Semester:
		dateUnit = Semester;
		break;

	case FreqUnit_Year:
		dateUnit = Year;
		break;
	}

	*endPeriodFlgPtr = TRUE;

	if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
	    freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year)
	{
		wrkDate.time = 0;
		wrkDate.date = DATE_MovePosi(tillDate.date, EndOf, dateUnit);
		if (tillDate.date != wrkDate.date)
		{
		    *endPeriodFlgPtr  = FALSE;
		    *endPeriodDatePtr = wrkDate;
		}
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DATE_LastRegularDate()
**
**  Description :   Compute the last regular date (before received date)
**					according to received frequency.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   PMSTA06820 - RAK - 090820
**
*************************************************************************/
RET_CODE DATE_LastRegularDate(DATETIME_T    date,
							  TINYINT_T     freq,
							  FREQUNIT_ENUM freqUnit,
							  DATETIME_T	*lastRegularDate)
{
	DATE_UNIT_ENUM 	dateUnit=Year;
	DATETIME_T	wrkDate;

	*lastRegularDate = date;

	switch (freqUnit)
	{
	case FreqUnit_Day:
		dateUnit = Day;
		break;

	case FreqUnit_BusDay:
		dateUnit = Day;
		break;

	case FreqUnit_Week:
		dateUnit = Week;
		break;

	case FreqUnit_Month:
		dateUnit = Month;
		break;

	case FreqUnit_Quarter:
		dateUnit = Quarter;
		break;

	case FreqUnit_Semester:
		dateUnit = Semester;
		break;

	case FreqUnit_Year:
		dateUnit = Year;
		break;
	}

	if (freqUnit == FreqUnit_Month || freqUnit == FreqUnit_Quarter ||
	    freqUnit == FreqUnit_Semester || freqUnit == FreqUnit_Year)
	{
		wrkDate.time = 0;
		wrkDate.date = DATE_Move(date.date, -(freq), dateUnit);

		(*lastRegularDate).time = 0;
		(*lastRegularDate).date = DATE_MovePosi(wrkDate.date, EndOf, dateUnit);
	}

	return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   DATE_SqlFreq()
**
**  Description :   Convert frequency in valid SQL frequency
**
**  Arguments   :   freqUnit    received frequency unit
**                  freq        received frequency
**                  freqUnitPtr output frequency unit (daily, monthly, yearly)
**                  freqPtr     output frequency  (modified for coherence)
**
**  Return      :   RET_SUCCEED or error code (freqUnitPtr and freqPtr updated)
**
** DVP005 : New function (96/03/13) RAK
**
*************************************************************************/
RET_CODE DATE_SqlFreq(FREQUNIT_ENUM     freqUnit,
		      TINYINT_T         freq,
		      DATE_SQLFREQ_ENUM *sqlFreqPtr,
		      TINYINT_T         *freqPtr)
{
	RET_CODE ret;

	switch (freqUnit)
	{
	case FreqUnit_Day :
		*sqlFreqPtr = DateSqlFreq_Day;
		*freqPtr    = freq;
		ret = RET_SUCCEED;
		break;

	case FreqUnit_Week :
		*sqlFreqPtr = DateSqlFreq_Day;
		*freqPtr    = (TINYINT_T) (freq * 7);
		ret = RET_SUCCEED;
		break;

	case FreqUnit_Month :
		*sqlFreqPtr = DateSqlFreq_Month;
		*freqPtr    = freq;
		ret = RET_SUCCEED;
		break;

	case FreqUnit_Quarter :
		*sqlFreqPtr = DateSqlFreq_Month;
		*freqPtr    = (TINYINT_T)(freq * 3);
		ret = RET_SUCCEED;
		break;

	case FreqUnit_Semester :
		*sqlFreqPtr = DateSqlFreq_Month;
		*freqPtr    = (TINYINT_T)(freq * 6);
		ret = RET_SUCCEED;
		break;

	case FreqUnit_Year :
		*sqlFreqPtr = DateSqlFreq_Year;
		*freqPtr    = freq;
		ret = RET_SUCCEED;
		break;

	default :
   		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DATE_SqlFreq", "frequency unit");
		ret = RET_GEN_ERR_INVARG;
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   DATE_IsDbBegin
**
**  Description :   Control if a date is inferior to the database earliest
**		    begin date (eg. Sybase 01/01/1753)
**
**  Arguments   :   yyyy   Year
**                  mm     Month
**                  dd     Day
**
**  Return      :   TRUE if date is inferior, FALSE elsewhere.
**
*************************************************************************/
int DATE_IsDbBegin(YEAR_T yy, MONTH_T mm, DAY_T dd)
{
	if ((yy != 0 && mm != 0 && dd != 0) &&
	    (DATE_Cmp(DATE_Put(yy, mm, dd),
		      DATE_Put(SYB_BEGIN_YEAR, SYB_BEGIN_MONTH, SYB_BEGIN_DAY)) < 0))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DATE_MoveEndPrevMonth()
**
**  Description :   If dateTime1 is an end of month, output is the same date.
**                  Else move date dateTime1 to the end of previous month.
**
**  Arguments   :   input
**                      dateTime1
**
**                  output
**                      dateTime2
**
**  Return      :   TRUE    if dateTime1 is an end of month
**                  FALSE   else
**
**	Creation    :   REF7395 - YST - 020607
**
*************************************************************************/
int DATE_MoveEndPrevMonth(DATETIME_T dateTime1, DATETIME_T *dateTime2)
{
    int   ret;

    *dateTime2 = dateTime1;

    /* if not end of month, move to the begin of month and then shift -1 day */
    if ((ret = DATE_IsLastInMonth(dateTime1.date)) != TRUE)
    {
        (*dateTime2).date = DATE_Move(DATE_MovePosi(dateTime1.date, BeginOf, Month), -1, Day);
    }
    return(ret);
}


/* Temporary */
void DATE_FillDayMonthName()
{
	strcpy(SV_monthNameTb[0][0], "jan");
	strcpy(SV_monthNameTb[1][0], "feb");
	strcpy(SV_monthNameTb[2][0], "mar");
	strcpy(SV_monthNameTb[3][0], "apr");
	strcpy(SV_monthNameTb[4][0], "may");
	strcpy(SV_monthNameTb[5][0], "jun");
	strcpy(SV_monthNameTb[6][0], "jul");
	strcpy(SV_monthNameTb[7][0], "aug");
	strcpy(SV_monthNameTb[8][0], "sep");
	strcpy(SV_monthNameTb[9][0], "oct");
	strcpy(SV_monthNameTb[10][0], "nov");
	strcpy(SV_monthNameTb[11][0], "dec");

	strcpy(SV_weekDayTb[0][0], "sun");
	strcpy(SV_weekDayTb[1][0], "mon");
	strcpy(SV_weekDayTb[2][0], "tue");
	strcpy(SV_weekDayTb[3][0], "wed");
	strcpy(SV_weekDayTb[4][0], "thu");
	strcpy(SV_weekDayTb[5][0], "fri");
	strcpy(SV_weekDayTb[6][0], "sat");

	strcpy(SV_monthNameTb[0][1], "january");
	strcpy(SV_monthNameTb[1][1], "february");
	strcpy(SV_monthNameTb[2][1], "march");
	strcpy(SV_monthNameTb[3][1], "april");
	strcpy(SV_monthNameTb[4][1], "may");
	strcpy(SV_monthNameTb[5][1], "june");
	strcpy(SV_monthNameTb[6][1], "july");
	strcpy(SV_monthNameTb[7][1], "august");
	strcpy(SV_monthNameTb[8][1], "september");
	strcpy(SV_monthNameTb[9][1], "october");
	strcpy(SV_monthNameTb[10][1], "november");
	strcpy(SV_monthNameTb[11][1], "december");

	strcpy(SV_weekDayTb[0][1], "sunday");
	strcpy(SV_weekDayTb[1][1], "monday");
	strcpy(SV_weekDayTb[2][1], "tuesday");
	strcpy(SV_weekDayTb[3][1], "wednesday");
	strcpy(SV_weekDayTb[4][1], "thursday");
	strcpy(SV_weekDayTb[5][1], "friday");
	strcpy(SV_weekDayTb[6][1], "saturday");
}

char *DATE_DateConv(DATE_T date)
{
	YEAR_T   y;
	MONTH_T  m;
	DAY_T    d;
    static char dateStr[50]; /* REF7758 - LJE - 021003 */

	DATE_Get(date, &y, &m, &d);

	sprintf(dateStr, "Y %4d M %02d D %02d", y, m, d);

    return (dateStr);
}

char *P(DATE_T date)
{
    return DATE_DateConv(date);
}

char *P(DATE_T * date)
{
    return DATE_DateConv(*date);
}

char *P(DATETIME_T &date)
{
    return P(&date);
}

char *P(DATETIME_T * date)
{
    static char dateTimeStr[100];
    
    sprintf(dateTimeStr, "%s %s", DATE_DateConv(date->date), TIME_TimeConv(date->time));

    return dateTimeStr;
}

char *TIME_TimeConv(TIME_T time)
{
    HOUR_T        h = 0;
    MINUTE_T      m = 0;
    SECOND_T      s = 0;
    MICROSECOND_T ms = 0;

    static char timeStr[50];

    TIME_Get(time, &h, &m, &s, &ms);

    sprintf(timeStr, "%02d:%02d:%02d.%06d", h, m, s, ms);

    return (timeStr);
}

char *P(TIME_T time)
{
    return TIME_TimeConv(time);
}

char *P(TIME_T *time)
{
    return TIME_TimeConv(*time);
}

/************************************************************************
**
**  Function    :   DATE_DateConvToddmmyyyy()
**
**  Description :   convert a DATE_T structure to dd/mm/yyyy
**
**  Arguments   :
**
**  Return      :
**
**	Creation    :   REF9751-EFE-050125
**
*************************************************************************/
char *DATE_DateConvToddmmyyyy(DATE_T date, char * dateStr)
{
	YEAR_T   y;
	MONTH_T  m;
	DAY_T    d;

	DATE_Get(date, &y, &m, &d);

	sprintf(dateStr, "%02d/%02d/%04d", d, m, y);

    return (dateStr);
}




/************************************************************************
**
**  Function    :   DATE_FreqUnit2DateUnit()
**
**  Description :   Convert a value of FREQUNIT_ENUM to a value of DATE_UNIT_ENUM
**
**  Arguments   :   freqEn : Value of FREQUNIT_ENUM to convert
**
**  Return      :   the corresponding value in DATE_UNIT_ENUM
**
**	Creation    :   REF9340 - DDV - 030821
**
*************************************************************************/
EXTERN DATE_UNIT_ENUM DATE_FreqUnit2DateUnit(FREQUNIT_ENUM freqEn)
{
	DATE_UNIT_ENUM    dateUnit=Year;

	    switch (freqEn)
	    {
	    case FreqUnit_Day:
		    dateUnit = Day;
		    break;

	    case FreqUnit_BusDay:
		    dateUnit = Day;
		    break;

	    case FreqUnit_Week:
		    dateUnit = Week;
		    break;

	    case FreqUnit_Month:
		    dateUnit = Month;
		    break;

		/* PMSTA08990 - LJE - 091118 */
	    case FreqUnit_MonthGlobalTWR:
		    dateUnit = Month;
		    break;

	    /* PMSTA08990 - LJE - 091118 */
	    case FreqUnit_MonthTWR:
		    dateUnit = Month;
		    break;

	    case FreqUnit_Quarter:
		    dateUnit = Quarter;
		    break;

	    case FreqUnit_Semester:
		    dateUnit = Semester;
		    break;

	    case FreqUnit_Year:
		    dateUnit = Year;
		    break;
	    }
    return(dateUnit);
}

/************************************************************************
**
**  Function    :   DATE_CheckLeapPeriod()
**
**  Description :   Return True if 29 february exists between from and till date,
**                  else return False.
**
**  Arguments   :   fromDate
**                  tillDate
**
**  Return      :   TRUE
**                  FALSE
**
**  Creation    :	REF11277 - TEB - 050719
**
*************************************************************************/
FLAG_T DATE_CheckLeapPeriod(DATE_T fromDate, DATE_T tillDate)
{
	DATE_T dateTmp;
	int    yearCount=0;

	if (DATE_Cmp(fromDate, tillDate) > 0 )
	{
		return(FALSE);
	}

	/* Just to be sur, normaly leap year occurs a least every 9 years */
	while (yearCount < 10)
	{
		if (DATE_Check((YEAR_T)(DATE_GET_Y(fromDate)+yearCount), 2, 29) == TRUE)
		{
			dateTmp = DATE_Put((YEAR_T)(DATE_GET_Y(fromDate)+yearCount), 2, 29);
			if (DATE_Cmp(dateTmp,  tillDate) <= 0 &&
				DATE_Cmp(fromDate, dateTmp)  <= 0)
			{
				return(TRUE);
			}
			else if (DATE_Cmp(dateTmp,  tillDate) > 0)
			{
				return(FALSE);
			}
		}

		yearCount++;
	}

	return(FALSE);
}
/************************************************************************
**
**  Function    :   DATE_GetMaxDatetime()
**
**  Description :   returns the max date betweens 2 .
**
**
**  Arguments   :   date1
**                  date2
**
**  Return      :   dateMax
**
**
**  Creation    :	PMSTA02926 - 070703 - EFE
**
*************************************************************************/
DATETIME_T DATE_GetMaxDatetime( const DATETIME_T date1, const  DATETIME_T date2 )
{

DATETIME_T retDate;

        if ( date1.date > date2.date )
        {
            retDate = date1;
        }
        else if ( date1.date < date2.date )
        {
            retDate = date2;
        }
        else if ( date1.time > date2.time )
        {
            retDate = date1;
        }
        else
        {
            retDate = date2;
        }


        return retDate;
}

/************************************************************************
**
**
**  Function    :   DATE_IsSameCalenderUnit()
**
**  Description :   Checks if two dates given are in the same calender
**                  unit given as input.
**  Arguments   :   date1,
**                  date2,
**                  Unit (day/month/quarter/semster/year/..)
**
**  Return      :   TRUE if both the given dates are in same calender unit.
**                  FALSE if both the given dates are in different 
**                  calender unit
**                  
**
**	Creation    :	PMSTA-49587 - AIS - 220822
*************************************************************************/
bool DATE_IsSameCalenderUnit(DATETIME_T date1, DATETIME_T date2, DATE_UNIT_ENUM unit)
{
    bool ret = false;
    int shift = 1;

    if (date1.date != BAD_DATE && date2.date != BAD_DATE)
    {
        switch (unit)
        {

        case Day:
            if ( date1.date == date2.date )
            {
                ret = true;
            }
            break;

        case Week:
            if(DATE_GET_Y(date1.date)              ==   DATE_GET_Y(date2.date)&&
               DATE_Part(date1.date, WeekInYear)   ==   DATE_Part(date2.date, WeekInYear) )
            {
                ret = true;
            }
            break;

        case Month:
            if ( DATE_GET_Y(date1.date) == DATE_GET_Y(date2.date) &&
                 DATE_GET_M(date1.date) == DATE_GET_M(date2.date) )
            {
                ret = true;
            }
            break;

        case Quarter:
            if ( DATE_GET_Y(date1.date)                 ==    DATE_GET_Y(date2.date) &&
                 DATE_Part(date1.date, QuarterInYear)   ==    DATE_Part(date2.date, QuarterInYear) 
               )
            {
                ret = true;
            }
            break;

        case Semester:
            if (  DATE_GET_Y(date1.date)                  ==   DATE_GET_Y(date2.date) &&
                  DATE_Part(date1.date, SemesterInYear)   ==   DATE_Part(date2.date, SemesterInYear)
               )
            {
                ret = true;
            }
            break;

        case Year:
            if ( DATE_GET_Y(date1.date) == DATE_GET_Y(date2.date) )
            {
                ret = true;
            }
            break;

        case Century:
            shift = 10;

        case Decade:
            shift *= 10;
            if ( DATE_GET_Y(date1.date) - 
                (DATE_GET_Y(date1.date) % shift) == DATE_GET_Y(date2.date) -
                                                     (DATE_GET_Y(date2.date) % shift) 
               )
            {
               ret = true;
            }
            break;

            case Second:
            if (date1.date == date2.date && date1.time == date2.time)
            {
                 ret = true;
            }
            break;

        case Minute:
             if ( date1.date             ==  date2.date &&
                  TIME_GET_M(date1.date) ==  TIME_GET_M(date2.date) &&
                  TIME_GET_H(date1.date) ==  TIME_GET_H(date2.date))
             {
                 ret = true;
             }
             break;

        case Hour:
             if (date1.date             ==  date2.date &&
                 TIME_GET_H(date1.date) ==  TIME_GET_H(date2.date))
             {
                 ret = true;
             }
             break;

        default:
             ret = false;
        }
    }
return ret;
}

/************************************************************************
**      END  datelib.c                                           UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINRISK_H
#define FINRISK_H

/************************************************************************
**      BEGIN : Global definitions attached to finrisk.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINRISK_C
#define	EXTERN
#else
#define EXTERN extern
#endif

extern  RET_CODE    FIN_FundSplittingTreat(DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				                           DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),		/* REF524 */
                    FIN_RiskAnalysis(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP, 
                                     DBA_DYNFLD_STP),
					FIN_GetFutFwdUnderlyInfo(DBA_DYNFLD_STP, DATETIME_T, ID_T*, char*, NUMBER_T*),
					
					FIN_TreatCompoRisk(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
					DBA_DYNFLD_STP, DBA_DYNFLD_STP, char, DBA_DYNFLD_STP,
					RISK_QTY_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM, DBA_DYNFLD_STP*),
					FIN_RiskSonPriceAmt(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP,
					DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, FIN_PRICEARG_STP,
					RISK_ANALYSIS_ENUM, PRICE_T*, RISK_QTY_STP, char),
					FIN_RiskPosLink(DBA_DYNFLD_STP, DBA_DYNFLD_STP, ID_T),
					FIN_AddValoRiskPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
					DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, char, DBA_DYNFLD_STP,
					FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM, FIN_OPTINFO_STP,
					NUMBER_T*, DBA_DYNFLD_STP, RISK_QTY_STP),
					FIN_AddValoRiskOptCashPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP, FIN_OPTINFO_STP),
					FIN_UpdRiskPosHier(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,char),
					FIN_PosRiskAnalysis(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
										DBA_DYNFLD_STP, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										RISK_QTY_STP, /* DVP189 */ RISK_ANALYSIS_ENUM, char); /* PMSTA-34140 - RAK - 190121 */

extern DBA_DYNFLD_STP FIN_CreateRiskAmt(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DATETIME_T, ID_T);
                
#endif /* FINRISK_H */



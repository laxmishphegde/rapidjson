/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FININSTR_H
#define FININSTR_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to fininstr.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FININSTR_C
#define	EXTERN
#else
#define EXTERN extern
#endif

/* PMSTA-34752 - RAK - 190221 */
typedef enum {
	StnSpecific_None,
	StnSpecific_Treatment,
	StnSpecific_FXTarkoOption
} STNSPECTREATMENT_ENUM;

EXTERN RET_CODE
FIN_ComputeVolatility(DBA_DYNFLD_STP, DATETIME_T, DBA_HIER_HEAD_STP, NUMBER_T*), /* REF6940 */
FIN_GetHierInstr(PTR, ID_T, char*, DBA_DYNFLD_STP*),	/* DVP455 */
FIN_IsOptConvertBondFlg(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T*),          /* REF5049 */
FIN_IsFutOptionFlg(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T*),               /* REF5300 */
FIN_CreateDiscountInstr(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DATE_T, DATE_T,
	DBA_HIER_HEAD_STP), /* REF1055 - AKO - 991104 */
	FIN_GenericInstrCompo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
		DBA_DYNFLD_STP**, int*, STNSPECTREATMENT_ENUM),
	FIN_SplitInstrument(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
		DBA_DYNFLD_STP*, DBA_DYNFLD_STP*, FLAG_T*, NUMBER_T*),
	FIN_SearchInstrLegInHier(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
		DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
	FIN_SetOrderLegs(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
		DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
	FIN_SwapLegInstr(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DATETIME_T,
		DBA_DYNFLD_STP**, int*, FLAG_T*),
	FIN_ComputeQtyForInstrCompo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
		DBA_DYNFLD_STP, DBA_DYNFLD_STP,
		INSTRCATEGORY_ENUM, NUMBER_T, DBA_DYNFLD_STP, int, NUMBER_T*),
	FIN_ChangeInstrLegNatEn(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
	FIN_SelectUnderlyingCompo(DBA_HIER_HEAD_STP, DATETIME_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*), /* PMSTA-32502 - RAK - 180924 */
	FIN_CreateInstrFromTemplate(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),                   /* PMSTA-34378 - DDV - 190131 */
	FIN_LoadStructuredProduct(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);                                     /* PMSTA-35040 - DDV - 190313 */



EXTERN RET_CODE FIN_InstrRecommLevelStorageCompute(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
EXTERN LEGNAT_ENUM  FIN_InstrGetNatureLeg(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
EXTERN INSTRCATEGORY_ENUM   FIN_InstrCategory(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);


extern NUMBER_T FIN_ACDCLifeTime(DBA_DYNFLD_STP, DATE_T, DBA_DYNFLD_STP);
extern FLAG_T FIN_STNKnockOutExpired(DATE_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP),
			  FIN_STNKnockInStarted(DATE_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

EXTERN FLAG_T FIN_CreateInstrInMaster(DBA_DYNFLD_STP);

/*
* Check of the STN instrument nature and sub nature
* All must be STN StandAlone
*/

class InstrumentNature
{
public:
	static bool isEquityLinkedNotes(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_EquityLinkedNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isBondsLinkedNotes(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_BondsLinkedNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

    static bool isBondsCreditLinkedNotes(const DBA_DYNFLD_STP instrPtr)
    {
        return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_CreditLinkedNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
    }

	static bool isCapProtectNotes(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_CapProtectNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isCapProtectNotesWCoupon(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_CapProtectNotesWCoupon, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isAirBagCertificates(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_AirbagCertificates, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isBonusNotes(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_BonusNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);  /* PMSTA-32116 - 200818 - PMO */
	}

	static bool isDiscountCertificates(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_DiscountCertificates, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isMemoryCoupons(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_MemoryCouponNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isTwinWinCertificates(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_Bond, SubNat_TwinWinCertificates, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isMiniFuturesTurbo(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_ExoticOptions, SubNat_MiniFuturesTurbo, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isReverseConvertibleCLN(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_ConvertBond, SubNat_ReverseConvNotesCredit, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isReverseConvertibleBLN(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_ConvertBond, SubNat_ReverseConvNotesBonds, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isReverseConvertibleELN(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_ConvertBond, SubNat_ReverseConvNotesEquity, INSTR_CLASS_ENUM::StructuredProduct_StandAlone);
	}

	static bool isReverseConvertible(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNatureClass(instrPtr, InstrNat_ConvertBond, SubNat_ReverseConvNotes, INSTR_CLASS_ENUM::StructuredProduct_StandAlone); /* PMSTA-34870 - Silpakal - 190225 */
	}

	/* PMSTA-34140 - Risk STN Option based */
	static bool isAccumulator(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNature(instrPtr, InstrNat_ExoticOptions, SubNat_Accumulator);
	}

	/* PMSTA-34140 - Risk STN Option based */
	static bool isDecumulator(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNature(instrPtr, InstrNat_ExoticOptions, SubNat_Decumulator);
	}

	/* PMSTA-34140 - Risk STN Option based */
	static bool isParticipatingForward(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNature(instrPtr, InstrNat_ExoticOptions, SubNat_ParticipatingForward);
	}

	/* PMSTA-34140 - Risk STN Option based */
	static bool isTargetKnockOutForward(const DBA_DYNFLD_STP instrPtr)
	{
		return isInstrumentNatureSubNature(instrPtr, InstrNat_ExoticOptions, SubNat_TargetKnockOutForward);
	}

    static  bool isDualCurrencyInvestMoneyMarket(const DBA_DYNFLD_STP instrPtr)
    {
        return isInstrumentNatureSubNature(instrPtr, InstrNat_MoneyMkt, SubNat_DualCurrencyInvest);
    }

    static  bool isTripleCurrencyInvestMoneyMarket(const DBA_DYNFLD_STP instrPtr)
    {
        return isInstrumentNatureSubNature(instrPtr, InstrNat_MoneyMkt, SubNat_TripleCurrencyInvest);
    }


	static  bool isStructuredNotes(const DBA_DYNFLD_STP instrPtr)
	{
		if (InstrumentNature::isEquityLinkedNotes(instrPtr) ||
			InstrumentNature::isBondsLinkedNotes(instrPtr) ||
			InstrumentNature::isCapProtectNotes(instrPtr) ||
			InstrumentNature::isCapProtectNotesWCoupon(instrPtr) ||
			InstrumentNature::isAirBagCertificates(instrPtr) ||
			InstrumentNature::isBonusNotes(instrPtr) ||
			InstrumentNature::isDiscountCertificates(instrPtr) ||
			InstrumentNature::isMemoryCoupons(instrPtr) ||
			InstrumentNature::isTwinWinCertificates(instrPtr) ||
			InstrumentNature::isMiniFuturesTurbo(instrPtr) ||
			InstrumentNature::isReverseConvertibleCLN(instrPtr) ||
			InstrumentNature::isReverseConvertibleBLN(instrPtr) ||
			InstrumentNature::isReverseConvertibleELN(instrPtr) ||
			InstrumentNature::isReverseConvertible(instrPtr) ||
			InstrumentNature::isTargetKnockOutForward(instrPtr) ||	/* PMSTA-34140 - Risk STN Option based */
			InstrumentNature::isParticipatingForward(instrPtr) ||
			InstrumentNature::isAccumulator(instrPtr) ||
			InstrumentNature::isDecumulator(instrPtr) ||
			InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
			InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
			return true;
		else
			return false;
    }

    static  bool isDerivedFromStructuredNotesTemplate(const DBA_DYNFLD_STP instrPtr) /* PMSTA-34377 - DDV - 190220 - Is created from a template with usage_nature_e = 2 (KD-1026A) */
    {
        if (InstrumentNature::isCapProtectNotes(instrPtr) ||
            InstrumentNature::isAirBagCertificates(instrPtr) ||
            InstrumentNature::isBonusNotes(instrPtr) ||
            InstrumentNature::isDiscountCertificates(instrPtr) ||
            InstrumentNature::isMemoryCoupons(instrPtr) ||
            InstrumentNature::isTwinWinCertificates(instrPtr) ||
            InstrumentNature::isMiniFuturesTurbo(instrPtr) ||
            InstrumentNature::isReverseConvertibleCLN(instrPtr) ||
            InstrumentNature::isReverseConvertibleBLN(instrPtr) ||
            InstrumentNature::isReverseConvertibleELN(instrPtr) ||
            InstrumentNature::isCapProtectNotesWCoupon(instrPtr)     /* PMSTA-38005 - Silpakal - 191126*/
            )
            return true;
        else
            return false;
    }

    static  bool isDerivedFromOTCDerivativeTemplate(const DBA_DYNFLD_STP instrPtr) /* PMSTA-34685 - DDV - 190220 - Is created from a template with usage_nature_e in (3,5) (KD-1026B)  */
    {
        if (InstrumentNature::isInstrumentNature(instrPtr, InstrNat_Option) ||
            InstrumentNature::isInstrumentNature(instrPtr, InstrNat_Future) ||
            InstrumentNature::isInstrumentNature(instrPtr, InstrNat_Forward) ||
            InstrumentNature::isInstrumentNature(instrPtr, InstrNat_ExoticOptions))
            return true;
        else
            return false;
    }

    static  bool isDerivedFromStructuredProductTemplate(const DBA_DYNFLD_STP instrPtr) /* PMSTA-34686 - DDV - 190220 - Is created from a template with usage_nature_e = 4 (KD-1026C) */
    {
        if (InstrumentNature::isTargetKnockOutForward(instrPtr) ||
            InstrumentNature::isParticipatingForward(instrPtr) ||
            InstrumentNature::isAccumulator(instrPtr) ||
            InstrumentNature::isDecumulator(instrPtr) ||
            InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
            InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            return true;
        else
            return false;
    }

    // Used by the journal to trigger a STN computation of ~ quantity, quote -> price
    static bool isJournalSTNCompuation(const DBA_DYNFLD_STP instrPtr)               /* PMSTA-35020 - 080319 - PMO */
    {
        return  InstrumentNature::isCapProtectNotes(instrPtr)
             || InstrumentNature::isCapProtectNotesWCoupon(instrPtr)
             || InstrumentNature::isEquityLinkedNotes(instrPtr)
             || InstrumentNature::isBondsLinkedNotes(instrPtr)
             || InstrumentNature::isBondsCreditLinkedNotes(instrPtr)
             || InstrumentNature::isReverseConvertibleELN(instrPtr)
             || InstrumentNature::isReverseConvertibleBLN(instrPtr)                 /* PMSTA-35019 - 110319 - PMO */
             || InstrumentNature::isReverseConvertibleCLN(instrPtr)                 /* PMSTA-35019 - 110319 - PMO */
             || InstrumentNature::isReverseConvertible(instrPtr)                    /* PMSTA-35019 - 110319 - PMO */
             || InstrumentNature::isMemoryCoupons(instrPtr)
             || InstrumentNature::isDiscountCertificates(instrPtr)
             || InstrumentNature::isBonusNotes(instrPtr)
             || InstrumentNature::isTwinWinCertificates(instrPtr)
             || InstrumentNature::isAirBagCertificates(instrPtr);
    }


    private:
	static bool isInstrumentNatureSubNatureClass(const DBA_DYNFLD_STP instrPtr, const INSTRNAT_ENUM & instrNat, const SUBNAT_ENUM & instrSubNat, const INSTR_CLASS_ENUM & instrClass)
	{
		const INSTR_CLASS_ENUM	instrClass2 = static_cast<INSTR_CLASS_ENUM> (GET_ENUM(instrPtr, A_Instr_InstrumentClassEn));

		return isInstrumentNature(instrPtr, instrNat) && isInstrumentSubNature(instrPtr, instrSubNat) && instrClass == instrClass2;
	}

    static bool isInstrumentNatureSubNature(const DBA_DYNFLD_STP instrPtr, const INSTRNAT_ENUM & instrNat, const SUBNAT_ENUM & instrSubNat)
    {
        return isInstrumentNature(instrPtr, instrNat) && isInstrumentSubNature(instrPtr, instrSubNat);
    }

    static bool isInstrumentNature(const DBA_DYNFLD_STP instrPtr, const INSTRNAT_ENUM & instrNat)
    {
        const INSTRNAT_ENUM		instrNat2 = static_cast<INSTRNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_NatEn));

        return instrNat == instrNat2;
    }

    static bool isInstrumentSubNature(const DBA_DYNFLD_STP instrPtr, const SUBNAT_ENUM & instrSubNat)
	{
		const SUBNAT_ENUM		instrSubNat2 = static_cast<SUBNAT_ENUM>  (GET_ENUM(instrPtr, A_Instr_SubNatEn));

		return instrSubNat == instrSubNat2;
	}
};


/* PMSTA-32116 - 200818 - PMO
 *
 * Structured Product - Instrument Financial computation
 */
class InstrumentSTNComputationInput
{
public:
    InstrumentSTNComputationInput(DBA_HIER_HEAD_STP hierHead,
                                  DBA_DYNFLD_STP    stock,
                                  DBA_DYNFLD_STP    instr,
                                  DATETIME_T &      refDateTime) : m_hierHead    (hierHead)
                                                                 , m_stock       (stock)
                                                                 , m_instr       (instr)
                                                                 , m_refDateTime (refDateTime)
    {
    }

    DBA_HIER_HEAD_STP getHierHead() const
    {
        return m_hierHead;
    }

    DBA_DYNFLD_STP getStock() const
    {
        return m_stock;
    }

    DBA_DYNFLD_STP getInstr() const
    {
        return m_instr;
    }

    DATETIME_T getRefDateTime() const
    {
        return m_refDateTime;
    }


private:
    // Input data
    DBA_HIER_HEAD_STP   m_hierHead;
    DBA_DYNFLD_STP      m_stock;
    DBA_DYNFLD_STP      m_instr;
    DATETIME_T          m_refDateTime;
};


class InstrumentSTNComputationResult
{
public:
    InstrumentSTNComputationResult() : m_qty              (ZERO_NUMBER)
                                     , m_quote            (1.0)
                                     , m_price            (ZERO_NUMBER)
                                     , m_exercisePrice    (ZERO_NUMBER)
                                     , m_initialPrice     (ZERO_NUMBER)
                                     , m_barrier          (ZERO_NUMBER)
                                     , m_delta            (ZERO_NUMBER)
                                     , m_worstInstrId     (ZERO_ID)
    {
    }

	InstrumentSTNComputationResult(const InstrumentSTNComputationResult & src)
	{
		set(src);
	}

	InstrumentSTNComputationResult & operator=(const InstrumentSTNComputationResult & src)
	{
		set(src);

		return *this;
	}

    NUMBER_T getQty() const
    {
        return m_qty;
    }

    void setQty(const NUMBER_T & qty)
    {
        m_qty = qty;
    }

    PRICE_T getQuote() const
    {
        return m_quote;
    }

    void setQuote(const PRICE_T & quote)
    {
        m_quote = quote;
    }

    PRICE_T getPrice() const
    {
        return m_price;
    }

    void setPrice(const PRICE_T & price)
    {
        m_price = price;
    }

    PRICE_T getExercisePrice() const
    {
        return m_exercisePrice;
    }

    void setExercisePrice(const PRICE_T & exercisePrice)
    {
        m_exercisePrice = exercisePrice;
    }

    PRICE_T getInitialPrice() const
    {
        return m_initialPrice;
    }

    void setInitialPrice(const NUMBER_T & initialPrice)
    {
        m_initialPrice = initialPrice;
    }

    NUMBER_T getBarrier() const                                 /* PMSTA-35023 - 110319 - PMO */
    {
        return m_barrier;
    }

    void setBarrier(const NUMBER_T & barrier)                   /* PMSTA-35023 - 110319 - PMO */
    {
        m_barrier = barrier;
    }

    NUMBER_T getDelta() const                                   /* PMSTA-35021 - 260319 - PMO */
    {
        return m_delta;
    }

    void setDelta(const NUMBER_T & delta)                       /* PMSTA-35021 - 260319 - PMO */
    {
        m_delta = delta;
    }

    std::vector<ID_T> & getWorstInstrId()
    {
        return m_worstInstrId;
    }

    void setWorstInstrId(const std::vector<ID_T> & id)
    {
        m_worstInstrId = id;
    }

private:
	void set(const InstrumentSTNComputationResult & src)
	{
		m_qty			= src.m_qty;
		m_quote			= src.m_quote;
		m_price			= src.m_price;
		m_exercisePrice = src.m_exercisePrice;
		m_initialPrice	= src.m_initialPrice;
        m_barrier       = src.m_barrier;
        m_delta         = src.m_delta;
        m_worstInstrId	= src.m_worstInstrId;
	}

    NUMBER_T			m_qty;
    PRICE_T			    m_quote;
    PRICE_T			    m_price;
    PRICE_T			    m_exercisePrice;
    PRICE_T			    m_initialPrice;
    NUMBER_T			m_barrier;          /* PMSTA-35023 - 110319 - PMO */
    NUMBER_T			m_delta;            /* PMSTA-35021 - 260319 - PMO */
	std::vector<ID_T>	m_worstInstrId;
};


class InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationBase(const InstrumentSTNComputationInput  &  input,
                                 InstrumentSTNComputationResult &        result) : m_input  (input)
                                                                                 , m_result (result)
    {
    }

    InstrumentSTNComputationBase            (const InstrumentSTNComputationBase &) = delete;
    InstrumentSTNComputationBase & operator=(const InstrumentSTNComputationBase &) = delete;

    NUMBER_T instrNumberValueOr(const FIELD_IDX_T & field, const NUMBER_T defValue) const
    {
        return TRUE == IS_NULLFLD(m_input.getInstr(), field) ? defValue : GET_NUMBER(m_input.getInstr(), field);
    }

    static NUMBER_T deltaPercent(const PRICE_T initialQuote, const PRICE_T exerciseQuote)
    {
        return FIN_DIV(initialQuote - exerciseQuote, exerciseQuote);
    }

    // Computation when the instrument has not knocked out
    RET_CODE computeNotKnockedOut(const bool);

    // Computation when the instrument has knocked out
    RET_CODE computeKnockedOut(const bool);

    // Return the minimal value between value1 and the instrument field if the field is not null
    NUMBER_T instrNumberMinIfValue(const FIELD_IDX_T & field, NUMBER_T value1) const;

protected:
    const InstrumentSTNComputationInput  &  m_input;    // Input data
    InstrumentSTNComputationResult &        m_result;   // Output data
};


class InstrumentSTNComputationCPNAverageBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationCPNAverageBasket(const InstrumentSTNComputationInput  &  input,
                                             InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationCPNAverageBasket            (const InstrumentSTNComputationCPNAverageBasket &) = delete;
    InstrumentSTNComputationCPNAverageBasket & operator=(const InstrumentSTNComputationCPNAverageBasket &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationCPNSingleInstrument : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationCPNSingleInstrument(const InstrumentSTNComputationInput  &  input,
                                                InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationCPNSingleInstrument            (const InstrumentSTNComputationCPNSingleInstrument &) = delete;
    InstrumentSTNComputationCPNSingleInstrument & operator=(const InstrumentSTNComputationCPNSingleInstrument &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationCPNWorstOfBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationCPNWorstOfBasket(const InstrumentSTNComputationInput  &  input,
                                             InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationCPNWorstOfBasket            (const InstrumentSTNComputationCPNWorstOfBasket &) = delete;
    InstrumentSTNComputationCPNWorstOfBasket & operator=(const InstrumentSTNComputationCPNWorstOfBasket &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationRCNMCSingleAverageWorstOf : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationRCNMCSingleAverageWorstOf(const InstrumentSTNComputationInput  &  input,
                                                      InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationRCNMCSingleAverageWorstOf(const InstrumentSTNComputationRCNMCSingleAverageWorstOf &) = delete;
    InstrumentSTNComputationRCNMCSingleAverageWorstOf & operator=(const InstrumentSTNComputationRCNMCSingleAverageWorstOf &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationDCSingle : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationDCSingle(const InstrumentSTNComputationInput  &  input,
                                     InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationDCSingle            (const InstrumentSTNComputationDCSingle &) = delete;
    InstrumentSTNComputationDCSingle & operator=(const InstrumentSTNComputationDCSingle &) = delete;

    RET_CODE compute();
};


/* PMSTA-34774 - 070319 - PMO */
class InstrumentSTNComputationDCAverageBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationDCAverageBasket(const InstrumentSTNComputationInput  &  input,
                                            InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationDCAverageBasket(const InstrumentSTNComputationDCAverageBasket &) = delete;
    InstrumentSTNComputationDCAverageBasket & operator=(const InstrumentSTNComputationDCAverageBasket &) = delete;

    RET_CODE compute();
};


/* PMSTA-34774 - 070319 - PMO */
class InstrumentSTNComputationDCWorstOfBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationDCWorstOfBasket(const InstrumentSTNComputationInput  &  input,
                                            InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationDCWorstOfBasket(const InstrumentSTNComputationDCWorstOfBasket &) = delete;
    InstrumentSTNComputationDCWorstOfBasket & operator=(const InstrumentSTNComputationDCWorstOfBasket &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationBNSingle : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationBNSingle(const InstrumentSTNComputationInput  &  input,
                                     InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationBNSingle            (const InstrumentSTNComputationBNSingle &) = delete;
    InstrumentSTNComputationBNSingle & operator=(const InstrumentSTNComputationBNSingle &) = delete;

    RET_CODE compute();
};


/* PMSTA-34774 - 070319 - PMO */
class InstrumentSTNComputationBNAverageBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationBNAverageBasket(const InstrumentSTNComputationInput  &  input,
                                            InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationBNAverageBasket(const InstrumentSTNComputationBNAverageBasket &) = delete;
    InstrumentSTNComputationBNAverageBasket & operator=(const InstrumentSTNComputationBNAverageBasket &) = delete;

    RET_CODE compute();
};


/* PMSTA-34774 - 070319 - PMO */
class InstrumentSTNComputationBNWorstOfBasket : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationBNWorstOfBasket(const InstrumentSTNComputationInput  &  input,
                                            InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationBNWorstOfBasket(const InstrumentSTNComputationBNWorstOfBasket &) = delete;
    InstrumentSTNComputationBNWorstOfBasket & operator=(const InstrumentSTNComputationBNWorstOfBasket &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationTWCSingleAverageWorstOf : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationTWCSingleAverageWorstOf(const InstrumentSTNComputationInput  &  input,
                                                    InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationTWCSingleAverageWorstOf(const InstrumentSTNComputationTWCSingleAverageWorstOf &) = delete;
    InstrumentSTNComputationTWCSingleAverageWorstOf & operator=(const InstrumentSTNComputationTWCSingleAverageWorstOf &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputationABSingleAverageWorstOf : public InstrumentSTNComputationBase
{
public:
    InstrumentSTNComputationABSingleAverageWorstOf(const InstrumentSTNComputationInput  &  input,
                                                   InstrumentSTNComputationResult &        result) : InstrumentSTNComputationBase(input, result)
    {
    }

    InstrumentSTNComputationABSingleAverageWorstOf(const InstrumentSTNComputationABSingleAverageWorstOf &) = delete;
    InstrumentSTNComputationABSingleAverageWorstOf & operator=(const InstrumentSTNComputationABSingleAverageWorstOf &) = delete;

    RET_CODE compute();
};


class InstrumentSTNComputation
{
public:
    InstrumentSTNComputation(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T &);
    InstrumentSTNComputation(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T &);
    ~InstrumentSTNComputation();

    InstrumentSTNComputation            (const InstrumentSTNComputation &) = delete;
    InstrumentSTNComputation & operator=(const InstrumentSTNComputation &) = delete;

    RET_CODE    computeJournal();
    RET_CODE    computeInstrumentPriceUnderlyingCategory();

	InstrumentSTNComputationResult & getInstrumentSTNComputationResult()
	{
		return m_result;
	}


    NUMBER_T getQty()
    {
        return m_result.getQty();
    }

    PRICE_T getQuote()
    {
        return m_result.getQuote();
    }

    PRICE_T getPrice()
    {
        return m_result.getPrice();
    }

    std::vector<ID_T> & getWorstInstrId()
    {
        return m_result.getWorstInstrId();
    }



private:
    InstrumentSTNComputationInput   m_input;    // Input data
    InstrumentSTNComputationResult  m_result;   // Output data
};

RET_CODE FIN_ComputeInstrumentPriceUnderlyingCategory(const InstrumentSTNComputationInput  &  input,
	                                                        InstrumentSTNComputationResult &  result);

bool FIN_InstrumentSTNIsWorstFlg(ID_T instrId,  InstrumentSTNComputationResult &  result);

RET_CODE FIN_WorstInstrumentsFromSTN(DBA_DYNFLD_STP**, int*, InstrumentSTNComputationResult & , int*); /*PMSTA-35265 - Silpakala - 190626*/

#endif /* FININSTR_H */

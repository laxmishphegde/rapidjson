/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef CONV_H
#define CONV_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#define DATE_FMT "YYYY-MM-DD"
#define TIME_FMT "HH:II:SS"
#define MICROSECS_FMT "DDDDD"
#define DFLT_MICROSECS "00000"
#define ZERO_OFFSET_IND "Z"
#define SPACE_CHAR_SEP ' '
#define SPACE_STR_SEP " "
#define TIME_SEP ":"
#define FRACTIONAL_SEP "."
#define DATETIME_CHAR_SEP 'T'
#define DATETIME_STR_SEP "T"
#define TIME_SEP_CHECK "DDTHH"
#define HOUR_SEP_CHECK ":HH"

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : convlib.c
*************************************************************************/
extern  int      CONV_GetDecPartLen(char *);
extern	char     *CONV_DataToStr(char *, const size_t, DATATYPE_ENUM, const char *, PTR, FLAG_T, TEXT_CONVERSION_TYPE_ENUM,
                                const char *dispTimeZoneCd = nullptr, const char dateTimeEscapeChar=END_OF_STRING); /* REF5635 */ /* DLA - REF8728 */
extern  PTR      CONV_StrToData(const char *, DATATYPE_ENUM, const char *, PTR, FLAG_T), /* REF5635 */ /* DLA - REF8728 */
                 CONV_StrToDataEx(const char *, DATATYPE_ENUM, const char *, PTR, FLAG_T, char, DICTATTRIBWGT_ENUM );    /* PMSTA-31062 - DLA - 180430 */
extern  void     CONV_InitConvFmtPtr(void);
extern  void     CONV_InitDefaultMaxPrecision(void);  /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
extern  RET_CODE CONV_GetThousSep(char *),
                 CONV_GetDfltDateFmt(DATATYPE_ENUM, char *, char *),
                 CONV_GetDecimSep(char *),
		 CONV_HexaStringToShort(char *, unsigned short *),	/* DVP404. */
		 CONV_ShortToHexaString(char *, unsigned short);	/* DVP404. */

extern RET_CODE CONV_GetDayName (int , FLAG_T, char*);
extern RET_CODE CONV_GetMonthName (int , FLAG_T , char*);
extern int CONV_Int64toInt(int64_t); /* DLA - REF9089 - 030516 */
extern int CONV_DoubleToNumericString(double, int, int, char *, int *count = NULL); /* PCL - PMSTA-24626-20170717 */
extern std::string CONV_DoubleToNumericString(double, int, int);
extern void CONV_GetMaxNumericAsString(int, int, bool, char *, int *count = NULL);
extern bool CONV_StringToTzOffsetType(const std::string &tzOffsetStr, int * value);
extern std::string CONV_TzOffsetTypeToString(const int value, const std::string & pMask);
extern void CONV_TADatetimeMaskToICU(const char *, char**, FLAG_T *, FLAG_T *, const char); /* PMSTA-30817 - DDV - 180427 */

#endif	                               /* ifndef CONV_H */
/************************************************************************
**      END       conv.h                                          UNICIBLE
*************************************************************************/

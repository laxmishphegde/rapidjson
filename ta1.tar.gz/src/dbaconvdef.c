/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBACONVDEF_C
#define DBACONVDEF_C

/************************************************************************
**      External variable
**
*************************************************************************/

/************************************************************************
**      STRUCTURE DATATYPE DEFINITION
*************************************************************************/

/* REF7560 - DDV - New conversion definition */
EXECCONVDEF_ST EV_DynSt_Execution_ToExtOp [] =
{
    {&ExtOp_DbId                       ,&Null_Dynfld                         ,&ExtOp_DbId                          },  
    {&ExtOp_NatureEn                   ,&Null_Dynfld                         ,&ExtOp_NatureEn                      },  
    {&ExtOp_OpId                       ,&A_Execution_ExtOrderId              ,&Null_Dynfld                         },  
    {&ExtOp_FctResultId                ,&Null_Dynfld                         ,&ExtOp_FctResultId                   },  
    {&ExtOp_Cd                         ,&Null_Dynfld                         ,&ExtOp_Cd                            },  
    {&ExtOp_FusionEn                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_InputUserId                ,&Null_Dynfld                         ,&ExtOp_InputUserId                   },  
    {&ExtOp_TpId                       ,&A_Execution_TypeId                  ,&Null_Dynfld                         },  
    {&ExtOp_SubTpId                    ,&A_Execution_SubtypeId               ,&Null_Dynfld                         },  
    {&ExtOp_MktThirdId                 ,&A_Execution_MarketThirdId           ,&Null_Dynfld                         },  
    {&ExtOp_IntermThirdId              ,&A_Execution_IntermedThirdId         ,&Null_Dynfld                         },  
    {&ExtOp_MgrId                      ,&Null_Dynfld                         ,&ExtOp_MgrId                         },  
    {&ExtOp_RuleId                     ,&Null_Dynfld                         ,&ExtOp_RuleId                        },  
    {&ExtOp_ValRuleEltId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SrcCd                      ,&Null_Dynfld                         ,&ExtOp_SrcCd                         },  
    {&ExtOp_SubPosNatEn                ,&Null_Dynfld                         ,&ExtOp_SubPosNatEn                   },  
    {&ExtOp_SubPosNat2En               ,&Null_Dynfld                         ,&ExtOp_SubPosNat2En                  },  
    {&ExtOp_SubPosNat3En               ,&Null_Dynfld                         ,&ExtOp_SubPosNat3En                  },  
    {&ExtOp_AdjSubPosNatEn             ,&Null_Dynfld                         ,&ExtOp_AdjSubPosNatEn                },  
    {&ExtOp_AdjSubPosNat2En            ,&Null_Dynfld                         ,&ExtOp_AdjSubPosNat2En               },  
    {&ExtOp_AdjSubPosNat3En            ,&Null_Dynfld                         ,&ExtOp_AdjSubPosNat3En               },  
    {&ExtOp_LockSubPosNatEn            ,&Null_Dynfld                         ,&ExtOp_LockSubPosNatEn               },  
    {&ExtOp_LockSubPosNat2En           ,&Null_Dynfld                         ,&ExtOp_LockSubPosNat2En              },  
    {&ExtOp_LockSubPosNat3En           ,&Null_Dynfld                         ,&ExtOp_LockSubPosNat3En              },  
    {&ExtOp_LimitQuote                 ,&Null_Dynfld                         ,&ExtOp_LimitQuote                    },  
    {&ExtOp_LimitPrice                 ,&Null_Dynfld                         ,&ExtOp_LimitPrice                    },  
    {&ExtOp_StopQuote                  ,&Null_Dynfld                         ,&ExtOp_StopQuote                     },  
    {&ExtOp_StopPrice                  ,&Null_Dynfld                         ,&ExtOp_StopPrice                     },  
    {&ExtOp_OrderPriceNatEn            ,&Null_Dynfld                         ,&ExtOp_OrderPriceNatEn               },  
    {&ExtOp_OrderValidNatEn            ,&Null_Dynfld                         ,&ExtOp_OrderValidNatEn               },  
    {&ExtOp_MinOrderQty                ,&Null_Dynfld                         ,&ExtOp_MinOrderQty                   },  
    {&ExtOp_ValoSeqNo                  ,&Null_Dynfld                         ,&ExtOp_ValoSeqNo                     },  
    {&ExtOp_ParOpCd                    ,&Null_Dynfld                         ,&ExtOp_ParOpCd                       },  
    {&ExtOp_ParOpNatEn                 ,&Null_Dynfld                         ,&ExtOp_ParOpNatEn                    },  
    {&ExtOp_CheckParentEn              ,&Null_Dynfld                         ,&ExtOp_CheckParentEn                 },  
    {&ExtOp_CheckStratEn               ,&A_Execution_CheckStratEn            ,&Null_Dynfld                         },  
    {&ExtOp_OrderNatEn                 ,&Null_Dynfld                         ,&ExtOp_OrderNatEn                    },  
    {&ExtOp_BeginDate                  ,&A_Execution_BeginDate               ,&Null_Dynfld                         },  
    {&ExtOp_EndDate                    ,&Null_Dynfld                         ,&ExtOp_EndDate                       },  
    {&ExtOp_AcctDate                   ,&A_Execution_AccountDate             ,&Null_Dynfld                         },  
    {&ExtOp_OpDate                     ,&A_Execution_OperationDate           ,&Null_Dynfld                         },  
    {&ExtOp_ValuationDate              ,&Null_Dynfld                         ,&ExtOp_ValuationDate                 },  
    {&ExtOp_OrderLimitDate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ValueDate                  ,&A_Execution_ValueDate               ,&Null_Dynfld                         },  
    {&ExtOp_RefOpCd                    ,&Null_Dynfld                         ,&ExtOp_RefOpCd                       },  
    {&ExtOp_RefNatEn                   ,&Null_Dynfld                         ,&ExtOp_RefNatEn                      },  
    {&ExtOp_StatusEn                   ,&A_Execution_StatusEn                ,&Null_Dynfld                         },  
    {&ExtOp_SequenceNo                 ,&A_Execution_SequenceNo              ,&Null_Dynfld                         },  
    {&ExtOp_AcctCd                     ,&Null_Dynfld                         ,&ExtOp_AcctCd                        },  
    {&ExtOp_OpenOpCd                   ,&Null_Dynfld                         ,&ExtOp_OpenOpCd                      },  
    {&ExtOp_PtfId                      ,&Null_Dynfld                         ,&ExtOp_PtfId                         },  
    {&ExtOp_PortPosSetId               ,&Null_Dynfld                         ,&ExtOp_PortPosSetId                  },  
    {&ExtOp_AdjPtfId                   ,&Null_Dynfld                         ,&ExtOp_AdjPtfId                      },  
    {&ExtOp_CashPtfId                  ,&A_Execution_CashPortfolioId         ,&Null_Dynfld                         },  
    {&ExtOp_InstrId                    ,&Null_Dynfld                         ,&ExtOp_InstrId                       },  
    {&ExtOp_ToInstrId                  ,&Null_Dynfld                         ,&ExtOp_ToInstrId                     },  
    {&ExtOp_BalPosTpId                 ,&Null_Dynfld                         ,&ExtOp_BalPosTpId                    },  
    {&ExtOp_FromBpTpId                 ,&Null_Dynfld                         ,&ExtOp_FromBpTpId                    },  
    {&ExtOp_ToBpTpId                   ,&Null_Dynfld                         ,&ExtOp_ToBpTpId                      },  
    {&ExtOp_AcctId                     ,&A_Execution_AccountId               ,&Null_Dynfld                         },  
    {&ExtOp_Acct2Id                    ,&A_Execution_Account2Id              ,&Null_Dynfld                         },  
    {&ExtOp_Acct3Id                    ,&A_Execution_Account3Id              ,&Null_Dynfld                         },  
    {&ExtOp_LockInstrId                ,&Null_Dynfld                         ,&ExtOp_LockInstrId                   },  
    {&ExtOp_DepoId                     ,&A_Execution_DepositId               ,&Null_Dynfld                         },  
    {&ExtOp_LockDepoId                 ,&Null_Dynfld                         ,&ExtOp_LockDepoId                    },  
    {&ExtOp_AdjInstrId                 ,&Null_Dynfld                         ,&ExtOp_AdjInstrId                    },  
    {&ExtOp_AdjDepoId                  ,&Null_Dynfld                         ,&ExtOp_AdjDepoId                     },  
    {&ExtOp_AdjBpTpId                  ,&Null_Dynfld                         ,&ExtOp_AdjBpTpId                     },  
    {&ExtOp_OpCurrId                   ,&Null_Dynfld                         ,&ExtOp_OpCurrId                      },  
    {&ExtOp_InstrCurrId                ,&Null_Dynfld                         ,&ExtOp_InstrCurrId                   },  
    {&ExtOp_ToInstrCurrId              ,&Null_Dynfld                         ,&ExtOp_ToInstrCurrId                 },  
    {&ExtOp_PtfCurrId                  ,&Null_Dynfld                         ,&ExtOp_PtfCurrId                     },  
    {&ExtOp_AcctCurrId                 ,&A_Execution_AccCurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Acct2CurrId                ,&A_Execution_Acc2CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_Acct3CurrId                ,&A_Execution_Acc3CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_TradeCurrId                ,&A_Execution_TradeCurrencyId         ,&Null_Dynfld                         },  
    {&ExtOp_AdjInstrCurrId             ,&Null_Dynfld                         ,&ExtOp_AdjInstrCurrId                },  
    {&ExtOp_AdjPosCurrId               ,&Null_Dynfld                         ,&ExtOp_AdjPosCurrId                  },  
    {&ExtOp_AdjPortCurrId              ,&Null_Dynfld                         ,&ExtOp_AdjPortCurrId                 },  
    {&ExtOp_CashPtfCurrId              ,&A_Execution_CashPfCurrId            ,&Null_Dynfld                         },  
    {&ExtOp_LockOpCurrId               ,&Null_Dynfld                         ,&ExtOp_LockOpCurrId                  },  
    {&ExtOp_LockFiCurrId               ,&Null_Dynfld                         ,&ExtOp_LockFiCurrId                  },  
    {&ExtOp_CntPtyThirdId              ,&A_Execution_CounterpartyThirdId     ,&Null_Dynfld                         },  
    {&ExtOp_TermTpId                   ,&A_Execution_TermTypeId              ,&Null_Dynfld                         },  
    {&ExtOp_LockTpId                   ,&Null_Dynfld                         ,&ExtOp_LockTpId                      },  
    {&ExtOp_AccrIntrBpTpId             ,&A_Execution_AccrBpTypeId            ,&ExtOp_AccrIntrBpTpId                },  
    {&ExtOp_ExtStratEltId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CloseOperId                ,&Null_Dynfld                         ,&ExtOp_CloseOperId                   },  
    {&ExtOp_CloseOperCd                ,&Null_Dynfld                         ,&ExtOp_CloseOperCd                   },  
    {&ExtOp_ParentExtOpId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExtOrderId                 ,&A_Execution_ExtOrderId              ,&Null_Dynfld                         },  
    {&ExtOp_ExecSetCriteria            ,&A_Execution_ExecutionSetCriteria    ,&Null_Dynfld                         },  
    {&ExtOp_AdjNatEn                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpId                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpCd                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpNatEn                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpStatEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_RevOpCd                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_RevOpNatEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockOpCd                   ,&Null_Dynfld                         ,&ExtOp_LockOpCd                      },  
    {&ExtOp_LockNatEn                  ,&Null_Dynfld                         ,&ExtOp_LockNatEn                     },  
    {&ExtOp_EvtCd                      ,&Null_Dynfld                         ,&ExtOp_EvtCd                         },  
    {&ExtOp_EvtNbr                     ,&Null_Dynfld                         ,&ExtOp_EvtNbr                        },  
    {&ExtOp_ExCouponFlg                ,&Null_Dynfld                         ,&ExtOp_ExCouponFlg                   },  
    {&ExtOp_FusRuleEn                  ,&Null_Dynfld                         ,&ExtOp_FusRuleEn                     },  
    {&ExtOp_LockLimitDate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExpirDate                  ,&Null_Dynfld                         ,&ExtOp_ExpirDate                     },  
    {&ExtOp_Remark                     ,&A_Execution_Remark                  ,&Null_Dynfld                         },  
    {&ExtOp_OpExchRate                 ,&A_Execution_OpExchRate              ,&Null_Dynfld                         },  
    {&ExtOp_InstrExchRate              ,&A_Execution_FiExchRate              ,&Null_Dynfld                         },  
    {&ExtOp_SysExchRate                ,&A_Execution_SysExchRate             ,&Null_Dynfld                         },  
    {&ExtOp_AcctExchRate               ,&A_Execution_AccExchRate             ,&Null_Dynfld                         },  
    {&ExtOp_Acct2ExchRate              ,&A_Execution_Acc2ExchRate            ,&Null_Dynfld                         },  
    {&ExtOp_Acct3ExchRate              ,&A_Execution_Acc3ExchRate            ,&Null_Dynfld                         },  
    {&ExtOp_TradeExchRate              ,&A_Execution_TradeExchRate           ,&Null_Dynfld                         },  
    {&ExtOp_CashPtfExchRate            ,&A_Execution_CashPfExchRate          ,&Null_Dynfld                         },  
    {&ExtOp_AdjInstrExchRate           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPosExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPtfExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistInstrExchRate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistSysExchRate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookInstrExchRate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookSysExchRate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockFiExchRate             ,&Null_Dynfld                         ,&ExtOp_LockFiExchRate                },  
    {&ExtOp_AdjQty                     ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Qty                        ,&A_Execution_Quantity                ,&Null_Dynfld                         },  
    {&ExtOp_LockQty                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Price                      ,&A_Execution_Price                   ,&Null_Dynfld                         },  
    {&ExtOp_SpotPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockDirtyPrice             ,&Null_Dynfld                         ,&ExtOp_LockDirtyPrice                },  
    {&ExtOp_LockCleanPrice             ,&Null_Dynfld                         ,&ExtOp_LockCleanPrice                },  
    {&ExtOp_PriceCalcRuleEn            ,&A_Execution_PriceCalcRuleEn         ,&Null_Dynfld                         },  
    {&ExtOp_Quote                      ,&A_Execution_Quote                   ,&Null_Dynfld                         },  
    {&ExtOp_SpotQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockDirtyQuote             ,&Null_Dynfld                         ,&ExtOp_LockDirtyQuote                },  
    {&ExtOp_LockCleanQuote             ,&Null_Dynfld                         ,&ExtOp_LockCleanQuote                },  
    {&ExtOp_Rate                       ,&A_Execution_Rate                    ,&Null_Dynfld                         },  
    {&ExtOp_LockPriceMargin            ,&Null_Dynfld                         ,&ExtOp_LockPriceMargin               },  
    {&ExtOp_SupplAmt                   ,&A_Execution_SupplAmt                ,&Null_Dynfld                         },  
    {&ExtOp_OpGrossAmt                 ,&A_Execution_OpGrossAmt              ,&Null_Dynfld                         },  
    {&ExtOp_AccrIntrAmt                ,&A_Execution_AccrAmt                 ,&Null_Dynfld                         },  
    {&ExtOp_OpNetAmt                   ,&A_Execution_OpNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_InstrNetAmt                ,&A_Execution_FiNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_PtfNetAmt                  ,&A_Execution_PfNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_SysNetAmt                  ,&A_Execution_SysNetAmt               ,&Null_Dynfld                         },  
    {&ExtOp_AdjPosNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPtfNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AcctNetAmt                 ,&A_Execution_AccNetAmt               ,&Null_Dynfld                         },  
    {&ExtOp_Acct2NetAmt                ,&A_Execution_Acc2NetAmt              ,&Null_Dynfld                         },  
    {&ExtOp_Acct3NetAmt                ,&A_Execution_Acc3NetAmt              ,&Null_Dynfld                         },  
    {&ExtOp_HistOpNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistInstrNetAmt            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistPtfNetAmt              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistSysNetAmt              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookOpNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookInstrNetAmt            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookPtfNetAmt              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookSysNetAmt              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Bp1TpId                    ,&A_Execution_Bp1TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp1CurrId                  ,&A_Execution_Bp1CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp1Amt                     ,&A_Execution_Bp1Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp2TpId                    ,&A_Execution_Bp2TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp2CurrId                  ,&A_Execution_Bp2CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp2Amt                     ,&A_Execution_Bp2Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp3TpId                    ,&A_Execution_Bp3TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp3CurrId                  ,&A_Execution_Bp3CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp3Amt                     ,&A_Execution_Bp3Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp4TpId                    ,&A_Execution_Bp4TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp4CurrId                  ,&A_Execution_Bp4CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp4Amt                     ,&A_Execution_Bp4Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp5TpId                    ,&A_Execution_Bp5TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp5CurrId                  ,&A_Execution_Bp5CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp5Amt                     ,&A_Execution_Bp5Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp6TpId                    ,&A_Execution_Bp6TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp6CurrId                  ,&A_Execution_Bp6CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp6Amt                     ,&A_Execution_Bp6Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp7TpId                    ,&A_Execution_Bp7TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp7CurrId                  ,&A_Execution_Bp7CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp7Amt                     ,&A_Execution_Bp7Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp8TpId                    ,&A_Execution_Bp8TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp8CurrId                  ,&A_Execution_Bp8CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp8Amt                     ,&A_Execution_Bp8Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp9TpId                    ,&A_Execution_Bp9TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp9CurrId                  ,&A_Execution_Bp9CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp9Amt                     ,&A_Execution_Bp9Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp10TpId                   ,&A_Execution_Bp10TypeId              ,&Null_Dynfld                         },  
    {&ExtOp_Bp10CurrId                 ,&A_Execution_Bp10CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_Bp10Amt                    ,&A_Execution_Bp10Amt                 ,&Null_Dynfld                         },  
    {&ExtOp_ConfirmedFlg               ,&Null_Dynfld                         ,&ExtOp_ConfirmedFlg                  },  
    {&ExtOp_DbStatusEn                 ,&Null_Dynfld                         ,&ExtOp_DbStatusEn                    },  
    {&ExtOp_AudUserName                ,&Null_Dynfld                         ,&ExtOp_AudUserName                   },  
    {&ExtOp_AudModifDate               ,&Null_Dynfld                         ,&ExtOp_AudModifDate                  },  
    {&ExtOp_AudAction                  ,&Null_Dynfld                         ,&ExtOp_AudAction                     },  
    {&ExtOp_LastUserId                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LastModifDate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CreationTime               ,&Null_Dynfld                         ,&ExtOp_CreationTime                  },  
    {&ExtOp_OrderCd                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecutedFlg                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_OpActionEn                 ,&Null_Dynfld                         ,&ExtOp_OpActionEn                    },  
    {&ExtOp_NoPositionFlg              ,&Null_Dynfld                         ,&ExtOp_NoPositionFlg                 },  
    {&ExtOp_OrderGroupingCd            ,&Null_Dynfld                         ,&ExtOp_OrderGroupingCd               },  
    {&ExtOp_OrderModeTypeId            ,&Null_Dynfld                         ,&ExtOp_OrderModeTypeId               },  /*<REF11810-BRO-060615              */
    {&ExtOp_TraderMgrId                ,&Null_Dynfld                         ,&ExtOp_TraderMgrId                   },  
    {&ExtOp_AutoRenewalEn              ,&Null_Dynfld                         ,&ExtOp_AutoRenewalEn                 },  
    {&ExtOp_RenewalTreatmtEn           ,&Null_Dynfld                         ,&ExtOp_RenewalTreatmtEn              },  
    {&ExtOp_RenewalEndValDate          ,&Null_Dynfld                         ,&ExtOp_RenewalEndValDate             },  
    {&ExtOp_RenewalLength              ,&Null_Dynfld                         ,&ExtOp_RenewalLength                 },  
    {&ExtOp_RenewalLengthUnitEn        ,&Null_Dynfld                         ,&ExtOp_RenewalLengthUnitEn           },  
    {&ExtOp_ClientInitEn               ,&Null_Dynfld                         ,&ExtOp_ClientInitEn                  },  
    {&ExtOp_ContractNumber             ,&Null_Dynfld                         ,&ExtOp_ContractNumber                },  
    {&ExtOp_TransactionNatEn           ,&Null_Dynfld                         ,&ExtOp_TransactionNatEn              },  /* >REF11810-BRO-060615              */
    {&ExtOp_RenewalIntRate             ,&Null_Dynfld                         ,&ExtOp_RenewalIntRate                },  /*REF11810-BRO-060628*/
    {&ExtOp_RenewalAmount              ,&Null_Dynfld                         ,&ExtOp_RenewalAmount                 },  /*REF11810-BRO-060628*/
    {&ExtOp_TargetNatureEn             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TargetNumber               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TargetAmount               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_MarketSegmentId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FactSheetEn                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastQuoteDate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastQuoteNumber            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastPriceNumber            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommunicationDate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommunicationTypeId        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommPartyTypeId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark1                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark2                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark3                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TransmissionDate           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TransmissionTypeId         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_OrderTypeId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_MMInterestAmount           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarketRate               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxClientRate               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxRateDirection            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_InterestMarketRate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_DebitToSysCurrRate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CreditToSysCurrRate        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ContractLengthNumber       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ContractLengthUnitEn       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginNumber             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginPrct               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginAmount             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TimeStamp                  ,&Null_Dynfld                         ,&ExtOp_TimeStamp                     },  /* REF11780 - 100406 - PMO */
    {&ExtOp_DerivativeOrdEn            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_FxFarLegAmount             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_FxSpotQuote                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_FxQuote                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_OrderFeeEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_OrderFeePrct               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_MaxOrderQty                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_STPOrderEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_UnpaidPrct                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_ExecutionId                ,&A_Execution_Id                      ,&Null_Dynfld                         },  
    {&ExtOp_GlExecFeeId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_GroupingCriteria           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_EffectChildQty             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_FlowId                     ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_InitExtPosId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecQty                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_WeightMeanQuote            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SelectedFlg                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*REF11457-EFE-051018*/
    {&ExtOp_InSessionFlg               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_DraftOrderId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Summary                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxSpotLegAmount            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_EventStatusId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_EventActionEn              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderMasterEltId   ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveEltId    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderCode          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveNbr      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundImpactRule         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_TimeStampNew               ,&Null_Dynfld                         ,&ExtOp_TimeStampNew                  },  /* REF11780 - 100406 - PMO */
    {&ExtOp_A_Flow_Ext                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_A_Ptf_Ext                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_A_Instr_Ext                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Id                         ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExtOp_Ext                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ChildExtOp_Ext             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ParExtOp_Ext               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SysCurrId                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_PPSCurrId                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CopiedPtfId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_NoCheckImpactFlg           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ParentId                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_NoCheckSynthAdminFlg       ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AutoIndex                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_EditBackupPtr              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ExtExecution_Ext           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* DLA - REF9764 - 040220 */
    {&ExtOp_ChildPtfId                 ,&Null_Dynfld                         ,&ExtOp_ChildPtfId                    },  /* PMSTA04637-CHU-080514 */
    {&ExtOp_CompoundOrderMasterElt_Ext ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveElt_Ext  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundScreenDictId       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundSlaveCode          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_DisplayCondition           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21336 - TGU - 151013 */    
    {&ExtOp_OrderType                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21336 - TGU - 151013 */
    {&ExtOp_CommonRef                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-20886 - DDV - 151028 */
    {&ExtOp_StandInstructIdx           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21265 - DDV - 151103 */
    {&ExtOp_FlowIdx                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21265 - DDV - 151103 */
    {&ExtOp_OrderSeqRankNbr            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-41770 -Vishnu- 15092020*/
    {&ExtOp_OrderInclusionEn           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_OrderRejectionDate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_OrderRejectionComment      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_AcquisitionDate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_CorporateActionNatEn       ,&Null_Dynfld                         ,&ExtOp_CorporateActionNatEn          },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_TaxLotSourceCd             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_StandInstructId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28684 - CHU - 171024 */
	{&ExtOp_BankFeePrct                ,&Null_Dynfld                         ,&ExtOp_BankFeePrct                   },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_BankFeeAmount              ,&Null_Dynfld                         ,&ExtOp_BankFeeAmount                 },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_BankFeeCurrId              ,&Null_Dynfld                         ,&ExtOp_BankFeeCurrId                 },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_PaymentOption              ,&Null_Dynfld                         ,&ExtOp_PaymentOption                 },  /* PMSTA-30658 - AiswaryaM -20180503 */
	{&ExtOp_BidTypeEn                  ,&Null_Dynfld                         ,&ExtOp_BidTypeEn                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid1Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid1Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid1Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid1Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid2Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid2Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid2Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid2Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid3Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid3Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid3Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid3Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
    {&ExtOp_CounterpartAccount         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-32693 - SME - 20180827 */    
	{&ExtOp_CounterpartCurrencyId      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-32693 - SME - 20180827 */
	{&ExtOp_OpFusionRuleEn             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
    {&ExtOp_GlobalPosFlg               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
    {&ExtOp_AdjPosGrossAmt             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
	{&ExtOp_OtcOrderEn                 ,&Null_Dynfld                         ,&Null_Dynfld						   },  /* PMSTA-34309 - RAK - 190130 */
	{&ExtOp_DefaultFusRuleEn           ,&Null_Dynfld                         ,&Null_Dynfld						   },  /* PMSTA-34309 - RAK - 190130 */
    {&ExtOp_CoolCancelEndDate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-34333 - Silpakal - 190201*/
    {&ExtOp_FusionPrioEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-32288 - JBC  - 190214 */
    {&ExtOp_ExcludeFromBlockFlg        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -32251 - Smitha - 180810 */
    {&ExtOp_ExternalBankBic            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_ExternalBankName           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_ExternalBankAcctOwnrName   ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_HedgeTradeEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35985 - Kramadevi - 230519 */
    {&ExtOp_FixingDate                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -36034 - KNI - 190603 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr1     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr2     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr3     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr4     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef1                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef2                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef3                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef4                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
	{&ExtOp_ExternalTradeFlg           ,&Null_Dynfld                         ,&ExtOp_ExternalTradeFlg              },  /* PMSTA-36524 - Grace      - 03072019 */
	{&ExtOp_SwitchingCriteria          ,&Null_Dynfld                         ,&Null_Dynfld						   },  /* PMSTA-37058 - Silpakal - 190903*/
	{&ExtOp_OrderCheckEn			   ,&Null_Dynfld                         ,&ExtOp_OrderCheckEn },  /* LIK */
	{&ExtOp_OriginalQty				   ,&Null_Dynfld                         ,&ExtOp_OriginalQty				   },  /* PMSTA-37908 - adarshn		- 19112019 */
	{&ExtOp_OrderNettingEn             ,&Null_Dynfld                         ,&ExtOp_OrderNettingEn				   },  /* PMSTA-37908 - adarshn		- 19112019 */
    {&ExtOp_NettingCriteria            ,&Null_Dynfld                         ,&ExtOp_NettingCriteria               },  /* PMSTA-37908 - adarshn	    - 24012020 */
    {&ExtOp_PaymentDate                ,&Null_Dynfld                         ,&ExtOp_PaymentDate                   },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_PaymentStatusEn            ,&Null_Dynfld                         ,&ExtOp_PaymentStatusEn               },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_SettlementDate             ,&Null_Dynfld                         ,&ExtOp_SettlementDate                },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_SettleStatusEn             ,&Null_Dynfld                         ,&ExtOp_SettleStatusEn                },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_CommissionCdEn             ,&Null_Dynfld                         ,&ExtOp_CommissionCdEn                },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ChargeCdEn                 ,&Null_Dynfld                         ,&ExtOp_ChargeCdEn                    },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_OriginalAmount             ,&Null_Dynfld                         ,&ExtOp_OriginalAmount                },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_CounterpartOrgAmount       ,&Null_Dynfld                         ,&ExtOp_CounterpartOrgAmount          },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ExternalFeeM               ,&Null_Dynfld                         ,&ExtOp_ExternalFeeM                  },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_TotalChargesM              ,&Null_Dynfld                         ,&ExtOp_TotalChargesM                 },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_CounterpartAmount          ,&Null_Dynfld                         ,&ExtOp_CounterpartAmount             },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_OpLinkageCd                ,&Null_Dynfld                         ,&ExtOp_OpLinkageCd                   },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ChargedCustomerName        ,&Null_Dynfld                         ,&ExtOp_ChargedCustomerName           },  /* PMSTA-38796 - cha - 03022020 */
    {&ExtOp_BoPtfId                    ,&Null_Dynfld                         ,&ExtOp_BoPtfId                       },  /* PMSTA-38454 - srinivas   - 17022020 */  
	{&ExtOp_BoAccountId                ,&Null_Dynfld                         ,&ExtOp_BoAccountId                   },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_OpSplitRuleEn              ,&Null_Dynfld                         ,&ExtOp_OpSplitRuleEn                 },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_AdjBoPtfId                 ,&Null_Dynfld                         ,&ExtOp_AdjBoPtfId                    },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_CoaExDate                  ,&Null_Dynfld                         ,&ExtOp_CoaExDate                     },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_BoCashAcctId               ,&Null_Dynfld                         ,&ExtOp_BoCashAcctId                  },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_BoCashPtfId                ,&Null_Dynfld                         ,&ExtOp_BoCashPtfId                   },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_SplitParentOperId          ,&Null_Dynfld                         ,&ExtOp_SplitParentOperId             },  /* PMSTA-38454 - srinivas   - 17022020 */
    { &ExtOp_OriginalNetAmount          ,&Null_Dynfld                         ,&ExtOp_OriginalNetAmount },  /* PMSTA-39927 - siva - 04292020 */
    { &ExtOp_SplitParOpCd               ,&Null_Dynfld                         ,&ExtOp_SplitParOpCd          },  /* PMSTA-LIK */
	{&ExtOp_RuleApplicabilityEn	       ,&Null_Dynfld                         ,&ExtOp_RuleApplicabilityEn		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingQty	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingQty			   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingOrgQty	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingOrgQty		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_RoundingOrgQty			   ,&Null_Dynfld                         ,&ExtOp_RoundingOrgQty				   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingFlg	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingFlg			   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingRuleId	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingRuleId		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
    {&ExtOp_HierOperNatEn              ,&Null_Dynfld                         ,&ExtOp_HierOperNatEn                 },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_HierOperationCd            ,&Null_Dynfld                         ,&ExtOp_HierOperationCd               },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_ParentHierExtOpId          ,&Null_Dynfld                         ,&ExtOp_ParentHierExtOpId             },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_HierGroupingCriteria       ,&Null_Dynfld                         ,&ExtOp_HierGroupingCriteria          },  /* PMSTA-40208 - sanand	   - 24092020 */
    {&ExtOp_CashPlanId                 ,&Null_Dynfld                         ,&ExtOp_CashPlanId                    },  /*PMSTA-42402 Autocash Vishnu 16112020*/
    {&ExtOp_OrdQtyPreFullRedemp        ,&Null_Dynfld                         ,&ExtOp_OrdQtyPreFullRedemp           },  /* PMSTA-43100 - sanand - 29122020 */
    {&ExtOp_CumulativeAmt              ,&Null_Dynfld                         ,&ExtOp_CumulativeAmt                 },  /* PMSTA-43100 - sanand - 29122020 */
	{&ExtOp_NotionalInstrId            ,&Null_Dynfld                         ,&ExtOp_NotionalInstrId               },  /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
	{&ExtOp_InvestLimitEn              ,&Null_Dynfld                         ,&ExtOp_InvestLimitEn                 },  /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
    {&ExtOp_AdjRefNatEn                ,&Null_Dynfld                         ,&ExtOp_AdjRefNatEn                   },  /* PMSTA-49729 - Deepthi - 220711 */
    {&ExtOp_AdjRefOperCd               ,&Null_Dynfld                         ,&ExtOp_AdjRefOperCd                  },  /* PMSTA-49729 - Deepthi - 220711 */
	{&ExtOp_SetOfFeesId                ,&Null_Dynfld                         ,&ExtOp_SetOfFeesId				   },  /* PMSTA-51324 - Lekshmi - 221128 */
	{&ExtOp_SetOfProductFeesId         ,&Null_Dynfld                         ,&ExtOp_SetOfProductFeesId			   },  /* PMSTA-51324 - Lekshmi - 221128 */
	{&ExtOp_BoRoutingBusEntityId       ,&Null_Dynfld                         ,&ExtOp_BoRoutingBusEntityId		   },  /* PMSTA-52619 - Sathees - 230327 */
    {&ExtOp_OrderSubTypeId             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* WEALTH-157 - Deepthi - 20230404 */
    {&ExtOp_ApplSessionCd              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* WEALTH-3007 - JPR - 20231031 */
    {&ExtOp_SetOfOtherFeesId           ,&Null_Dynfld                         ,&ExtOp_SetOfOtherFeesId              },  /* WEALTH-5030 - CHANDRU - 05022024 */
    {&ExtOp_TraderThirdId              ,&Null_Dynfld                         ,&ExtOp_TraderThirdId                 },  /* WEALTH-5053 - CHANDRU - 07022024 */
    {&ExtOp_NetSettleAmount            ,&Null_Dynfld                         ,&ExtOp_NetSettleAmount               },  /* WEALTH-9095 - SENTHIL - 20240529 */
    {&ExtOp_ParAdjExtOp_Ext            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA - 54624 - SRS - 240118 */
    {&ExtOp_PremiumCurrencyId          ,&Null_Dynfld                         ,&ExtOp_PremiumCurrencyId },  /* WEALTH-8559 - Senthil - 20240607 */
    {&ExtOp_PremiumAmount              ,&Null_Dynfld                         ,&ExtOp_PremiumAmount },  /* WEALTH-8559 - Senthil - 20240607 */
    {&Null_Dynfld                      ,&Null_Dynfld                         ,&Null_Dynfld                         }   /* PMSTA-22876 - DDV - 160408 */
};

const size_t sizeDynSt_Execution_ToExtOp = (sizeof(EV_DynSt_Execution_ToExtOp) / sizeof(EV_DynSt_Execution_ToExtOp[0]))-1;   /* PMSTA-19123 - 081214 - PMO */

/*  Error !!!
 *  The number of entries into the array of Extop SV_CFieldDef_ExtOp must be the same than into the array SV_DynSt_Execution_ToExtOp
 *  If not crash may occurs
 */
AAASTATIC_ASSERT(sizeDynSt_Execution_ToExtOp == sizeFieldDef_ExtOp); 



/* Change A_Execution_LastUserId and A_Execution_LastModifDate to Null_Dynfld REF7560 - PMO - 020822 */
/* REF7560 - DDV - New conversion definition */
EXECCONVDEF_ST EV_DynSt_GlExecFee_ToExtOp [] =
{
    {&ExtOp_DbId                       ,&Null_Dynfld                         ,&ExtOp_DbId                          },  
    {&ExtOp_NatureEn                   ,&Null_Dynfld                         ,&ExtOp_NatureEn                      },  
    {&ExtOp_OpId                       ,&A_GlExecFee_ExtOrderId              ,&Null_Dynfld                         },  
    {&ExtOp_FctResultId                ,&Null_Dynfld                         ,&ExtOp_FctResultId                   },  
    {&ExtOp_Cd                         ,&Null_Dynfld                         ,&ExtOp_Cd                            },  
    {&ExtOp_FusionEn                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_InputUserId                ,&Null_Dynfld                         ,&ExtOp_InputUserId                   },  
    {&ExtOp_TpId                       ,&A_GlExecFee_TypeId                  ,&Null_Dynfld                         },  
    {&ExtOp_SubTpId                    ,&A_GlExecFee_SubtypeId               ,&Null_Dynfld                         },  
    {&ExtOp_MktThirdId                 ,&Null_Dynfld                         ,&ExtOp_MktThirdId                    },  
    {&ExtOp_IntermThirdId              ,&Null_Dynfld                         ,&ExtOp_IntermThirdId                 },  
    {&ExtOp_MgrId                      ,&Null_Dynfld                         ,&ExtOp_MgrId                         },  
    {&ExtOp_RuleId                     ,&Null_Dynfld                         ,&ExtOp_RuleId                        },  
    {&ExtOp_ValRuleEltId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SrcCd                      ,&Null_Dynfld                         ,&ExtOp_SrcCd                         },  
    {&ExtOp_SubPosNatEn                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SubPosNat2En               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SubPosNat3En               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjSubPosNatEn             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjSubPosNat2En            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjSubPosNat3En            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockSubPosNatEn            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockSubPosNat2En           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockSubPosNat3En           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LimitQuote                 ,&Null_Dynfld                         ,&ExtOp_LimitQuote                    },  
    {&ExtOp_LimitPrice                 ,&Null_Dynfld                         ,&ExtOp_LimitPrice                    },  
    {&ExtOp_StopQuote                  ,&Null_Dynfld                         ,&ExtOp_StopQuote                     },  
    {&ExtOp_StopPrice                  ,&Null_Dynfld                         ,&ExtOp_StopPrice                     },  
    {&ExtOp_OrderPriceNatEn            ,&Null_Dynfld                         ,&ExtOp_OrderPriceNatEn               },  
    {&ExtOp_OrderValidNatEn            ,&Null_Dynfld                         ,&ExtOp_OrderValidNatEn               },  
    {&ExtOp_MinOrderQty                ,&Null_Dynfld                         ,&ExtOp_MinOrderQty                   },  
    {&ExtOp_ValoSeqNo                  ,&Null_Dynfld                         ,&ExtOp_ValoSeqNo                     },  
    {&ExtOp_ParOpCd                    ,&Null_Dynfld                         ,&ExtOp_ParOpCd                       },  
    {&ExtOp_ParOpNatEn                 ,&Null_Dynfld                         ,&ExtOp_ParOpNatEn                    },  
    {&ExtOp_CheckParentEn              ,&Null_Dynfld                         ,&ExtOp_CheckParentEn                 },  
    {&ExtOp_CheckStratEn               ,&Null_Dynfld                         ,&ExtOp_CheckStratEn                  },  
    {&ExtOp_OrderNatEn                 ,&Null_Dynfld                         ,&ExtOp_OrderNatEn                    },  
    {&ExtOp_BeginDate                  ,&A_GlExecFee_BeginDate               ,&Null_Dynfld                         },  /* DLA - REF9764 - 040304 */
    {&ExtOp_EndDate                    ,&Null_Dynfld                         ,&ExtOp_EndDate                       },  
    {&ExtOp_AcctDate                   ,&A_GlExecFee_AccountDate             ,&Null_Dynfld                         },  
    {&ExtOp_OpDate                     ,&A_GlExecFee_OperationDate           ,&Null_Dynfld                         },  
    {&ExtOp_ValuationDate              ,&Null_Dynfld                         ,&ExtOp_ValuationDate                 },  
    {&ExtOp_OrderLimitDate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ValueDate                  ,&A_GlExecFee_ValueDate               ,&Null_Dynfld                         },  
    {&ExtOp_RefOpCd                    ,&Null_Dynfld                         ,&ExtOp_RefOpCd                       },  
    {&ExtOp_RefNatEn                   ,&Null_Dynfld                         ,&ExtOp_RefNatEn                      },  
    {&ExtOp_StatusEn                   ,&A_GlExecFee_StatusEn                ,&Null_Dynfld                         },  
    {&ExtOp_SequenceNo                 ,&Null_Dynfld                         ,&ExtOp_SequenceNo                    },  
    {&ExtOp_AcctCd                     ,&Null_Dynfld                         ,&ExtOp_AcctCd                        },  
    {&ExtOp_OpenOpCd                   ,&Null_Dynfld                         ,&ExtOp_OpenOpCd                      },  
    {&ExtOp_PtfId                      ,&Null_Dynfld                         ,&ExtOp_PtfId                         },  
    {&ExtOp_PortPosSetId               ,&Null_Dynfld                         ,&ExtOp_PortPosSetId                  },  
    {&ExtOp_AdjPtfId                   ,&Null_Dynfld                         ,&ExtOp_AdjPtfId                      },  
    {&ExtOp_CashPtfId                  ,&A_GlExecFee_CashPortfolioId         ,&Null_Dynfld                         },  
    {&ExtOp_InstrId                    ,&Null_Dynfld                         ,&ExtOp_InstrId                       },  
    {&ExtOp_ToInstrId                  ,&Null_Dynfld                         ,&ExtOp_ToInstrId                     },  
    {&ExtOp_BalPosTpId                 ,&A_GlExecFee_BpTypeId                ,&Null_Dynfld                         },  
    {&ExtOp_FromBpTpId                 ,&Null_Dynfld                         ,&ExtOp_FromBpTpId                    },  
    {&ExtOp_ToBpTpId                   ,&Null_Dynfld                         ,&ExtOp_ToBpTpId                      },  
    {&ExtOp_AcctId                     ,&A_GlExecFee_AccountId               ,&Null_Dynfld                         },  
    {&ExtOp_Acct2Id                    ,&A_GlExecFee_Account2Id              ,&Null_Dynfld                         },  
    {&ExtOp_Acct3Id                    ,&A_GlExecFee_Account3Id              ,&Null_Dynfld                         },  
    {&ExtOp_LockInstrId                ,&Null_Dynfld                         ,&ExtOp_LockInstrId                   },  
    {&ExtOp_DepoId                     ,&A_Execution_DepositId               ,&Null_Dynfld                         },  
    {&ExtOp_LockDepoId                 ,&Null_Dynfld                         ,&ExtOp_LockDepoId                    },  
    {&ExtOp_AdjInstrId                 ,&Null_Dynfld                         ,&ExtOp_AdjInstrId                    },  
    {&ExtOp_AdjDepoId                  ,&Null_Dynfld                         ,&ExtOp_AdjDepoId                     },  
    {&ExtOp_AdjBpTpId                  ,&Null_Dynfld                         ,&ExtOp_AdjBpTpId                     },  
    {&ExtOp_OpCurrId                   ,&Null_Dynfld                         ,&ExtOp_OpCurrId                      },  
    {&ExtOp_InstrCurrId                ,&Null_Dynfld                         ,&ExtOp_InstrCurrId                   },  
    {&ExtOp_ToInstrCurrId              ,&Null_Dynfld                         ,&ExtOp_ToInstrCurrId                 },  
    {&ExtOp_PtfCurrId                  ,&Null_Dynfld                         ,&ExtOp_PtfCurrId                     },  
    {&ExtOp_AcctCurrId                 ,&A_GlExecFee_AccCurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Acct2CurrId                ,&A_GlExecFee_Acc2CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_Acct3CurrId                ,&A_GlExecFee_Acc3CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_TradeCurrId                ,&A_GlExecFee_TradeCurrencyId         ,&Null_Dynfld                         },  
    {&ExtOp_AdjInstrCurrId             ,&Null_Dynfld                         ,&ExtOp_AdjInstrCurrId                },  /*A_GlExecFee_AccountedFlg*/
    {&ExtOp_AdjPosCurrId               ,&Null_Dynfld                         ,&ExtOp_AdjPosCurrId                  },  
    {&ExtOp_AdjPortCurrId              ,&Null_Dynfld                         ,&ExtOp_AdjPortCurrId                 },  
    {&ExtOp_CashPtfCurrId              ,&A_GlExecFee_CashPfCurrId            ,&Null_Dynfld                         },  
    {&ExtOp_LockOpCurrId               ,&Null_Dynfld                         ,&ExtOp_LockOpCurrId                  },  
    {&ExtOp_LockFiCurrId               ,&Null_Dynfld                         ,&ExtOp_LockFiCurrId                  },  
    {&ExtOp_CntPtyThirdId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_TermTpId                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockTpId                   ,&Null_Dynfld                         ,&ExtOp_LockTpId                      },  
    {&ExtOp_AccrIntrBpTpId             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExtStratEltId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CloseOperId                ,&Null_Dynfld                         ,&ExtOp_CloseOperId                   },  
    {&ExtOp_CloseOperCd                ,&Null_Dynfld                         ,&ExtOp_CloseOperCd                   },  
    {&ExtOp_ParentExtOpId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExtOrderId                 ,&A_GlExecFee_ExtOrderId              ,&Null_Dynfld                         },  
    {&ExtOp_ExecSetCriteria            ,&A_GlExecFee_ExecutionSetCriteria    ,&Null_Dynfld                         },  
    {&ExtOp_AdjNatEn                   ,&Null_Dynfld                         ,&ExtOp_AdjNatEn                      },  
    {&ExtOp_ExecOpId                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpCd                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpNatEn                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecOpStatEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_RevOpCd                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_RevOpNatEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockOpCd                   ,&Null_Dynfld                         ,&ExtOp_LockOpCd                      },  
    {&ExtOp_LockNatEn                  ,&Null_Dynfld                         ,&ExtOp_LockNatEn                     },  
    {&ExtOp_EvtCd                      ,&Null_Dynfld                         ,&ExtOp_EvtCd                         },  
    {&ExtOp_EvtNbr                     ,&Null_Dynfld                         ,&ExtOp_EvtNbr                        },  
    {&ExtOp_ExCouponFlg                ,&Null_Dynfld                         ,&ExtOp_ExCouponFlg                   },  
    {&ExtOp_FusRuleEn                  ,&Null_Dynfld                         ,&ExtOp_FusRuleEn                     },  
    {&ExtOp_LockLimitDate              ,&Null_Dynfld                         ,&ExtOp_LockLimitDate                 },  
    {&ExtOp_ExpirDate                  ,&Null_Dynfld                         ,&ExtOp_ExpirDate                     },  
    {&ExtOp_Remark                     ,&A_GlExecFee_Remark                  ,&Null_Dynfld                         },  
    {&ExtOp_OpExchRate                 ,&A_GlExecFee_OpExchRate              ,&Null_Dynfld                         },  
    {&ExtOp_InstrExchRate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SysExchRate                ,&A_GlExecFee_SysExchRate             ,&Null_Dynfld                         },  
    {&ExtOp_AcctExchRate               ,&A_GlExecFee_AccExchRate             ,&Null_Dynfld                         },  
    {&ExtOp_Acct2ExchRate              ,&A_GlExecFee_Acc2ExchRate            ,&Null_Dynfld                         },  
    {&ExtOp_Acct3ExchRate              ,&A_GlExecFee_Acc3ExchRate            ,&Null_Dynfld                         },  
    {&ExtOp_TradeExchRate              ,&A_GlExecFee_TradeExchRate           ,&Null_Dynfld                         },  
    {&ExtOp_CashPtfExchRate            ,&A_GlExecFee_CashPfExchRate          ,&Null_Dynfld                         },  
    {&ExtOp_AdjInstrExchRate           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPosExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPtfExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistInstrExchRate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistSysExchRate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookInstrExchRate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookSysExchRate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockOpExchRate             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockFiExchRate             ,&Null_Dynfld                         ,&ExtOp_LockFiExchRate                },  
    {&ExtOp_AdjQty                     ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Qty                        ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockQty                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Price                      ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SpotPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookPrice                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockDirtyPrice             ,&Null_Dynfld                         ,&ExtOp_LockDirtyPrice                },  
    {&ExtOp_LockCleanPrice             ,&Null_Dynfld                         ,&ExtOp_LockCleanPrice                },  
    {&ExtOp_PriceCalcRuleEn            ,&Null_Dynfld                         ,&ExtOp_PriceCalcRuleEn               },  
    {&ExtOp_Quote                      ,&Null_Dynfld                         ,&ExtOp_Quote                         },  
    {&ExtOp_SpotQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_HistQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_BookQuote                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LockDirtyQuote             ,&Null_Dynfld                         ,&ExtOp_LockDirtyQuote                },  
    {&ExtOp_LockCleanQuote             ,&Null_Dynfld                         ,&ExtOp_LockCleanQuote                },  
    {&ExtOp_Rate                       ,&Null_Dynfld                         ,&ExtOp_Rate                          },  
    {&ExtOp_LockPriceMargin            ,&Null_Dynfld                         ,&ExtOp_LockPriceMargin               },  
    {&ExtOp_SupplAmt                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_OpGrossAmt                 ,&A_GlExecFee_OpNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_AccrIntrAmt                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_OpNetAmt                   ,&A_GlExecFee_OpNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_InstrNetAmt                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_PtfNetAmt                  ,&A_GlExecFee_PfNetAmt                ,&Null_Dynfld                         },  
    {&ExtOp_SysNetAmt                  ,&A_GlExecFee_SysNetAmt               ,&Null_Dynfld                         },  
    {&ExtOp_AdjPosNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AdjPtfNetAmt               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AcctNetAmt                 ,&A_GlExecFee_AccNetAmt               ,&Null_Dynfld                         },  
    {&ExtOp_Acct2NetAmt                ,&A_GlExecFee_Acc2NetAmt              ,&Null_Dynfld                         },  
    {&ExtOp_Acct3NetAmt                ,&A_GlExecFee_Acc3NetAmt              ,&Null_Dynfld                         },  
    {&ExtOp_HistOpNetAmt               ,&Null_Dynfld                         ,&ExtOp_HistOpNetAmt                  },  
    {&ExtOp_HistInstrNetAmt            ,&Null_Dynfld                         ,&ExtOp_HistInstrNetAmt               },  
    {&ExtOp_HistPtfNetAmt              ,&Null_Dynfld                         ,&ExtOp_HistPtfNetAmt                 },  
    {&ExtOp_HistSysNetAmt              ,&Null_Dynfld                         ,&ExtOp_HistSysNetAmt                 },  
    {&ExtOp_BookOpNetAmt               ,&Null_Dynfld                         ,&ExtOp_BookOpNetAmt                  },  
    {&ExtOp_BookInstrNetAmt            ,&Null_Dynfld                         ,&ExtOp_BookInstrNetAmt               },  
    {&ExtOp_BookPtfNetAmt              ,&Null_Dynfld                         ,&ExtOp_BookPtfNetAmt                 },  
    {&ExtOp_BookSysNetAmt              ,&Null_Dynfld                         ,&ExtOp_BookSysNetAmt                 },  
    {&ExtOp_Bp1TpId                    ,&A_GlExecFee_Bp1TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp1CurrId                  ,&A_GlExecFee_Bp1CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp1Amt                     ,&A_GlExecFee_Bp1Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp2TpId                    ,&A_GlExecFee_Bp2TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp2CurrId                  ,&A_GlExecFee_Bp2CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp2Amt                     ,&A_GlExecFee_Bp2Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp3TpId                    ,&A_GlExecFee_Bp3TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp3CurrId                  ,&A_GlExecFee_Bp3CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp3Amt                     ,&A_GlExecFee_Bp3Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp4TpId                    ,&A_GlExecFee_Bp4TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp4CurrId                  ,&A_GlExecFee_Bp4CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp4Amt                     ,&A_GlExecFee_Bp4Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp5TpId                    ,&A_GlExecFee_Bp5TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp5CurrId                  ,&A_GlExecFee_Bp5CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp5Amt                     ,&A_GlExecFee_Bp5Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp6TpId                    ,&A_GlExecFee_Bp6TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp6CurrId                  ,&A_GlExecFee_Bp6CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp6Amt                     ,&A_GlExecFee_Bp6Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp7TpId                    ,&A_GlExecFee_Bp7TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp7CurrId                  ,&A_GlExecFee_Bp7CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp7Amt                     ,&A_GlExecFee_Bp7Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp8TpId                    ,&A_GlExecFee_Bp8TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp8CurrId                  ,&A_GlExecFee_Bp8CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp8Amt                     ,&A_GlExecFee_Bp8Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp9TpId                    ,&A_GlExecFee_Bp9TypeId               ,&Null_Dynfld                         },  
    {&ExtOp_Bp9CurrId                  ,&A_GlExecFee_Bp9CurrencyId           ,&Null_Dynfld                         },  
    {&ExtOp_Bp9Amt                     ,&A_GlExecFee_Bp9Amt                  ,&Null_Dynfld                         },  
    {&ExtOp_Bp10TpId                   ,&A_GlExecFee_Bp10TypeId              ,&Null_Dynfld                         },  
    {&ExtOp_Bp10CurrId                 ,&A_GlExecFee_Bp10CurrencyId          ,&Null_Dynfld                         },  
    {&ExtOp_Bp10Amt                    ,&A_GlExecFee_Bp10Amt                 ,&Null_Dynfld                         },  
    {&ExtOp_ConfirmedFlg               ,&Null_Dynfld                         ,&ExtOp_ConfirmedFlg                  },  
    {&ExtOp_DbStatusEn                 ,&Null_Dynfld                         ,&ExtOp_DbStatusEn                    },  
    {&ExtOp_AudUserName                ,&Null_Dynfld                         ,&ExtOp_AudUserName                   },  
    {&ExtOp_AudModifDate               ,&Null_Dynfld                         ,&ExtOp_AudModifDate                  },  
    {&ExtOp_AudAction                  ,&Null_Dynfld                         ,&ExtOp_AudAction                     },  
    {&ExtOp_LastUserId                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_LastModifDate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CreationTime               ,&Null_Dynfld                         ,&ExtOp_CreationTime                  },  
    {&ExtOp_OrderCd                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecutedFlg                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_OpActionEn                 ,&Null_Dynfld                         ,&ExtOp_OpActionEn                    },  
    {&ExtOp_NoPositionFlg              ,&Null_Dynfld                         ,&ExtOp_NoPositionFlg                 },  
    {&ExtOp_OrderGroupingCd            ,&Null_Dynfld                         ,&ExtOp_OrderGroupingCd               },  
    {&ExtOp_OrderModeTypeId            ,&Null_Dynfld                         ,&ExtOp_OrderModeTypeId               },  /* <REF11810-BRO-060615              */
    {&ExtOp_TraderMgrId                ,&Null_Dynfld                         ,&ExtOp_TraderMgrId                   },  
    {&ExtOp_AutoRenewalEn              ,&Null_Dynfld                         ,&ExtOp_AutoRenewalEn                 },  
    {&ExtOp_RenewalTreatmtEn           ,&Null_Dynfld                         ,&ExtOp_RenewalTreatmtEn              },  
    {&ExtOp_RenewalEndValDate          ,&Null_Dynfld                         ,&ExtOp_RenewalEndValDate             },  
    {&ExtOp_RenewalLength              ,&Null_Dynfld                         ,&ExtOp_RenewalLength                 },  
    {&ExtOp_RenewalLengthUnitEn        ,&Null_Dynfld                         ,&ExtOp_RenewalLengthUnitEn           },  
    {&ExtOp_ClientInitEn               ,&Null_Dynfld                         ,&ExtOp_ClientInitEn                  },  
    {&ExtOp_ContractNumber             ,&Null_Dynfld                         ,&ExtOp_ContractNumber                },  
    {&ExtOp_TransactionNatEn           ,&Null_Dynfld                         ,&ExtOp_TransactionNatEn              },  /* >REF11810-BRO-060615              */
    {&ExtOp_RenewalIntRate             ,&Null_Dynfld                         ,&ExtOp_RenewalIntRate                },  /*REF11810-BRO-060628*/
    {&ExtOp_RenewalAmount              ,&Null_Dynfld                         ,&ExtOp_RenewalAmount                 },  /*REF11810-BRO-060628*/
    {&ExtOp_TargetNatureEn             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TargetNumber               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TargetAmount               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_MarketSegmentId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FactSheetEn                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastQuoteDate              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastQuoteNumber            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_LastPriceNumber            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommunicationDate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommunicationTypeId        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CommPartyTypeId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark1                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark2                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Remark3                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TransmissionDate           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TransmissionTypeId         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_OrderTypeId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_MMInterestAmount           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarketRate               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxClientRate               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxRateDirection            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_InterestMarketRate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_DebitToSysCurrRate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_CreditToSysCurrRate        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ContractLengthNumber       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ContractLengthUnitEn       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginNumber             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginPrct               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxMarginAmount             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_TimeStamp                  ,&Null_Dynfld                         ,&ExtOp_TimeStamp                     },  /* REF11780 - 100406 - PMO */
    {&ExtOp_DerivativeOrdEn            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_FxFarLegAmount             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_FxSpotQuote                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_FxQuote                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_OrderFeeEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_OrderFeePrct               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_MaxOrderQty                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_STPOrderEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_UnpaidPrct                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_ExecutionId                ,&A_GlExecFee_Id                      ,&Null_Dynfld                         },  
    {&ExtOp_GlExecFeeId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_GroupingCriteria           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_EffectChildQty             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_FlowId                     ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_InitExtPosId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExecQty                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_WeightMeanQuote            ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SelectedFlg                ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*REF11457-EFE-051018*/
    {&ExtOp_InSessionFlg               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_DraftOrderId               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_Summary                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_FxSpotLegAmount            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */    
    {&ExtOp_EventStatusId              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_EventActionEn              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderMasterEltId   ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveEltId    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderCode          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveNbr      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundImpactRule         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_TimeStampNew               ,&Null_Dynfld                         ,&ExtOp_TimeStampNew                  },  /* REF11780 - 100406 - PMO */
    {&ExtOp_A_Flow_Ext                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_A_Ptf_Ext                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_A_Instr_Ext                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_Id                         ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ExtOp_Ext                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ChildExtOp_Ext             ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ParExtOp_Ext               ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_SysCurrId                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_PPSCurrId                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_CopiedPtfId                ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_NoCheckImpactFlg           ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_ParentId                   ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_NoCheckSynthAdminFlg       ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_AutoIndex                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  
    {&ExtOp_EditBackupPtr              ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-13316 - 301111 - PMO */
    {&ExtOp_ExtExecution_Ext           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* DLA - REF9764 - 040220 */
    {&ExtOp_ChildPtfId                 ,&Null_Dynfld                         ,&ExtOp_ChildPtfId                    },  /* PMSTA04637-CHU-080514 */
    {&ExtOp_CompoundOrderMasterElt_Ext ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundOrderSlaveElt_Ext  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundScreenDictId       ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_CompoundSlaveCode          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-19123 - 081214 - PMO */
    {&ExtOp_DisplayCondition           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21336 - TGU - 151013 */
    {&ExtOp_OrderType                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21336 - TGU - 151013 */    
    {&ExtOp_CommonRef                  ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-20886 - DDV - 151028 */
    {&ExtOp_StandInstructIdx           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21265 - DDV - 151103 */
    {&ExtOp_FlowIdx                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-21265 - DDV - 151103 */
    {&ExtOp_OrderSeqRankNbr            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-41770 -Vishnu- 15092020*/
    {&ExtOp_OrderInclusionEn           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_OrderRejectionDate         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_OrderRejectionComment      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-25576 - CHU - 170403 */
    {&ExtOp_AcquisitionDate            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_CorporateActionNatEn       ,&Null_Dynfld                         ,&ExtOp_CorporateActionNatEn          },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_TaxLotSourceCd             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28286 - CHU - 170905 */
    {&ExtOp_StandInstructId            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-28684 - CHU - 171024 */
	{&ExtOp_BankFeePrct                ,&Null_Dynfld                         ,&ExtOp_BankFeePrct                   },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_BankFeeAmount              ,&Null_Dynfld                         ,&ExtOp_BankFeeAmount                 },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_BankFeeCurrId              ,&Null_Dynfld                         ,&ExtOp_BankFeeCurrId                 },  /* PMSTA-31134 - AiswaryaM - 20180504*/
	{&ExtOp_PaymentOption              ,&Null_Dynfld                         ,&ExtOp_PaymentOption                 },  /* PMSTA-30658 - AiswaryaM -20180503 */
	{&ExtOp_BidTypeEn                  ,&Null_Dynfld                         ,&ExtOp_BidTypeEn                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid1Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid1Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid1Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid1Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid2Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid2Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid2Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid2Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid3Qty                    ,&Null_Dynfld                         ,&ExtOp_Bid3Qty                       },  /* PMSTA-31709 - AiswaryaM - 20180604*/
	{&ExtOp_Bid3Quote                  ,&Null_Dynfld                         ,&ExtOp_Bid3Quote                     },  /* PMSTA-31709 - AiswaryaM - 20180604*/
    {&ExtOp_CounterpartAccount         ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-32693 - SME - 20180827 */
    {&ExtOp_CounterpartCurrencyId      ,&Null_Dynfld                         ,&Null_Dynfld                         },  /*PMSTA-32693 - SME - 20180827 */
	{&ExtOp_OpFusionRuleEn             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
	{&ExtOp_GlobalPosFlg               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
	{&ExtOp_AdjPosGrossAmt             ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-29531 - JBC - 171210 */
	{&ExtOp_OtcOrderEn                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-34309 - RAK - 190130 */
	{&ExtOp_DefaultFusRuleEn           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-34309 - RAK - 190130 */
    {&ExtOp_CoolCancelEndDate          ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-34333 - Silpakal - 190201*/
    {&ExtOp_FusionPrioEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-32288 - JBC  - 190214 */
    {&ExtOp_ExcludeFromBlockFlg        ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -32251 - Smitha - 180810 */
    {&ExtOp_ExternalBankBic            ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_ExternalBankName           ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_ExternalBankAcctOwnrName   ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35577 - Kramadevi - 260419 */
    {&ExtOp_HedgeTradeEn               ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -35985 - Kramadevi - 230519 */
    {&ExtOp_FixingDate                 ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA -36034 - KNI - 190603 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr1     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr2     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr3     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_ExtrnlBnkAcctOwnrAddr4     ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef1                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef2                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef3                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
    {&ExtOp_PayRef4                    ,&Null_Dynfld                         ,&Null_Dynfld                         },  /* PMSTA-36651 - Kramadevi  - 19072019 */
	{&ExtOp_ExternalTradeFlg           ,&Null_Dynfld                         ,&ExtOp_ExternalTradeFlg              },  /* PMSTA-36524 - Grace      - 03072019 */
	{&ExtOp_SwitchingCriteria          ,&Null_Dynfld                         ,&Null_Dynfld						   },  /* PMSTA-37058 - Silpakal - 190903*/
	{&ExtOp_OrderCheckEn			   ,&Null_Dynfld                         ,&ExtOp_OrderCheckEn },  /* LIK */	
	{&ExtOp_OriginalQty				   ,&Null_Dynfld                         ,&ExtOp_OriginalQty				   },  /* PMSTA-37908 - adarshn	   - 19112019 */
	{&ExtOp_OrderNettingEn             ,&Null_Dynfld                         ,&ExtOp_OrderNettingEn				   },  /* PMSTA-37908 - adarshn	   - 19112019 */
    {&ExtOp_NettingCriteria            ,&Null_Dynfld                         ,&ExtOp_NettingCriteria               },  /* PMSTA-37908 - adarshn	    - 24012020 */
    {&ExtOp_PaymentDate                ,&Null_Dynfld                         ,&ExtOp_PaymentDate                   },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_PaymentStatusEn            ,&Null_Dynfld                         ,&ExtOp_PaymentStatusEn               },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_SettlementDate             ,&Null_Dynfld                         ,&ExtOp_SettlementDate                },  /* PMSTA-38730 - Silpakal - 200204 */
    {&ExtOp_SettleStatusEn             ,&Null_Dynfld                         ,&ExtOp_SettleStatusEn                },  /* PMSTA-38730 - Silpakal - 200204 */
	{&ExtOp_CommissionCdEn             ,&Null_Dynfld                         ,&ExtOp_CommissionCdEn                },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ChargeCdEn                 ,&Null_Dynfld                         ,&ExtOp_ChargeCdEn                    },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_OriginalAmount             ,&Null_Dynfld                         ,&ExtOp_OriginalAmount                },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_CounterpartOrgAmount       ,&Null_Dynfld                         ,&ExtOp_CounterpartOrgAmount          },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ExternalFeeM               ,&Null_Dynfld                         ,&ExtOp_ExternalFeeM                  },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_TotalChargesM              ,&Null_Dynfld                         ,&ExtOp_TotalChargesM                 },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_CounterpartAmount          ,&Null_Dynfld                         ,&ExtOp_CounterpartAmount             },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_OpLinkageCd                ,&Null_Dynfld                         ,&ExtOp_OpLinkageCd                   },  /* PMSTA-38796 - cha - 03022020 */
	{&ExtOp_ChargedCustomerName        ,&Null_Dynfld                         ,&ExtOp_ChargedCustomerName           },  /* PMSTA-38796 - cha - 03022020 */
    {&ExtOp_BoPtfId                    ,&Null_Dynfld                         ,&ExtOp_BoPtfId                       },  /* PMSTA-38454 - srinivas   - 17022020 */  
	{&ExtOp_BoAccountId                ,&Null_Dynfld                         ,&ExtOp_BoAccountId                   },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_OpSplitRuleEn              ,&Null_Dynfld                         ,&ExtOp_OpSplitRuleEn                 },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_AdjBoPtfId                 ,&Null_Dynfld                         ,&ExtOp_AdjBoPtfId                    },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_CoaExDate                  ,&Null_Dynfld                         ,&ExtOp_CoaExDate                     },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_BoCashAcctId               ,&Null_Dynfld                         ,&ExtOp_BoCashAcctId                  },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_BoCashPtfId                ,&Null_Dynfld                         ,&ExtOp_BoCashPtfId                   },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_SplitParentOperId          ,&Null_Dynfld                         ,&ExtOp_SplitParentOperId             },  /* PMSTA-38454 - srinivas   - 17022020 */
	{&ExtOp_OriginalNetAmount          ,&Null_Dynfld                         ,&ExtOp_OriginalNetAmount             },  /* PMSTA-39927 - Siva - 04292020 */
    { &ExtOp_SplitParOpCd          ,&Null_Dynfld                         ,&ExtOp_SplitParOpCd },  /* PMSTA- LIK  */
	{&ExtOp_RuleApplicabilityEn	       ,&Null_Dynfld                         ,&ExtOp_RuleApplicabilityEn		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingQty	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingQty			   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingOrgQty	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingOrgQty		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_RoundingOrgQty			   ,&Null_Dynfld                         ,&ExtOp_RoundingOrgQty				   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingFlg	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingFlg			   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
	{&ExtOp_SmartRoundingRuleId	       ,&Null_Dynfld                         ,&ExtOp_SmartRoundingRuleId		   }, /* PMSTA-40493-badhri-08252020: smart rounding rule */
    {&ExtOp_HierOperNatEn              ,&Null_Dynfld                         ,&ExtOp_HierOperNatEn                 },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_HierOperationCd            ,&Null_Dynfld                         ,&ExtOp_HierOperationCd               },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_ParentHierExtOpId          ,&Null_Dynfld                         ,&ExtOp_ParentHierExtOpId             },  /* PMSTA-40208 - adarshn	   - 28082020 */
    {&ExtOp_HierGroupingCriteria       ,&Null_Dynfld                         ,&ExtOp_HierGroupingCriteria          },  /* PMSTA-40208 - sanand	   - 24092020 */
    {&ExtOp_CashPlanId                 ,&Null_Dynfld                         ,&ExtOp_CashPlanId                    },  /*PMSTA-42402 Autocash Vishnu 16112020*/
    {&ExtOp_OrdQtyPreFullRedemp        ,&Null_Dynfld                         ,&ExtOp_OrdQtyPreFullRedemp           },  /* PMSTA-43100 - sanand - 29122020 */
    {&ExtOp_CumulativeAmt              ,&Null_Dynfld                         ,&ExtOp_CumulativeAmt                 },  /* PMSTA-43100 - sanand - 29122020 */
	{&ExtOp_NotionalInstrId            ,&Null_Dynfld                         ,&ExtOp_NotionalInstrId               },  /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
	{&ExtOp_InvestLimitEn              ,&Null_Dynfld                         ,&ExtOp_InvestLimitEn                 },  /*PMSTA-45637 AutoplansMP CHANDRU-09072021*/
    {&ExtOp_AdjRefNatEn                ,&Null_Dynfld                         ,&ExtOp_AdjRefNatEn                   }, /* PMSTA-49729 - Deepthi - 220711 */
    {&ExtOp_AdjRefOperCd               ,&Null_Dynfld                         ,&ExtOp_AdjRefOperCd				   }, /* PMSTA-49729 - Deepthi - 220711 */
	{&ExtOp_SetOfFeesId                ,&Null_Dynfld                         ,&ExtOp_SetOfFeesId			       }, /* PMSTA-51324 - Lekshmi - 221128 */
	{&ExtOp_SetOfProductFeesId         ,&Null_Dynfld                         ,&ExtOp_SetOfProductFeesId			   }, /* PMSTA-51324 - Lekshmi - 221128 */
	{&ExtOp_BoRoutingBusEntityId       ,&Null_Dynfld                         ,&ExtOp_BoRoutingBusEntityId		   }, /* PMSTA-52619 - Sathees - 230327 */
    {&ExtOp_OrderSubTypeId             ,&Null_Dynfld                         ,&Null_Dynfld                         }, /* WEALTH-157 - Deepthi - 20230404 */
    {&ExtOp_ApplSessionCd              ,&Null_Dynfld                         ,&Null_Dynfld                         }, /* WEALTH-3007 - JPR - 20231031 */
    {&ExtOp_SetOfOtherFeesId           ,&Null_Dynfld                         ,&ExtOp_SetOfOtherFeesId              }, /* WEALTH-5030 - CHANDRU - 05022024 */
    {&ExtOp_TraderThirdId              ,&Null_Dynfld                         ,&ExtOp_TraderThirdId                 }, /* WEALTH-5053 - CHANDRU - 07022024 */
    {&ExtOp_NetSettleAmount            ,&Null_Dynfld                         ,&ExtOp_NetSettleAmount               }, /* WEALTH-9095 - SENTHIL - 20240529 */
    {&ExtOp_ParAdjExtOp_Ext            ,&Null_Dynfld                         ,&Null_Dynfld                         },
    {&ExtOp_PremiumCurrencyId         ,&Null_Dynfld                         ,&ExtOp_PremiumCurrencyId }, /* WEALTH-8559 - Senthil - 20240607 */
    {&ExtOp_PremiumAmount             ,&Null_Dynfld                         ,&ExtOp_PremiumAmount }, /* WEALTH-8559 - Senthil - 20240607 */
    {&Null_Dynfld                      ,&Null_Dynfld                         ,&Null_Dynfld                         }   /* PMSTA-22876 - DDV - 160408 */
};


const size_t sizeDynSt_GlExecFee_ToExtOp = (sizeof(EV_DynSt_GlExecFee_ToExtOp) / sizeof(EV_DynSt_GlExecFee_ToExtOp[0]))-1;   /* PMSTA-19123 - 081214 - PMO */

/*  Error !!!
 *  The number of entries into the array of Extop SV_CFieldDef_ExtOp must be the same than into the array SV_DynSt_GlExecFee_ToExtOp
 *  If not crash may occurs
 */
AAASTATIC_ASSERT(sizeDynSt_GlExecFee_ToExtOp == sizeFieldDef_ExtOp);


#endif


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAOP_C

/************************************************************************
**      Include files
*************************************************************************/
#include <ctype.h>
#include <assert.h>

#define STDIO_H
#define STRING_H
#define MATH_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "conv.h"
#include "dba.h"
#include "ope.h"
#include "date.h"
#include "cmp.h"
#include "str.h"

#include "fus.h" /* REF10567-EFE-041104 */

#ifndef HIER_H
#include "hier.h"
#endif

#include "scptyl.h"
#include "fin.h"
#include "dft.h"
#include "dbiconnection.h"
#include "conlocprovider.h"


/************************************************************************
**      External entry points
**
** DBA_InsOperationById() 	            Insert an operation buy, sell, ... into the database.
** DBA_UpdOperationById() 	            Update an operation buy, sell, ...
** DBA_InsExtOpById() 		            Insert an extended operation into the database.
** DBA_UpdExtOpById() 		            Update an extended operation into the database.
** DBA_ExtPosToPos() 		            Convert an extended position into a position.
** DBA_ExtPosToBalPos() 	            Convert an extended position into a balance position.
** DBA_InverseSign() 		            Inverse the sign of the quantity and amounts.
** DBA_DelExtOpById() 		            Delete of an extended operation from the database.
** DBA_LoadExtOp() 		                Load of an array of Extended Operations records.
** DBA_FusionRequestAllPtfNewOp()       Function which launches a manual fusion of type.
** DBA_InsExtOpByIdAndFuse()	        Insert an extended operation into the database and launch fusion
** DBA_UpdExtOpByIdAndFuse()	        Update an extended operation into the database and launch fusion
** DBA_DelExtOpByIdAndFuse()	        Delete of an extended operation from the database and launch fusion
** DBA_ClosingSecurity()	            Checks if insert/update/delete of operation in closing period
** DBA_PerformInsUpdDelExtOp()          Description : perform delete, insert or update of ExtOp
** DBA_DefFusDateRuleForOpAcctValue()   Set the missing date of operation date, accounting date, valuation date
** DBA_DefFusDateRuleForOpAcctValueInsUpdOp()   Set the missing date of operation date, accounting date, valuation date
**
*************************************************************************/



/************************************************************************
**      Local functions
**
** DBA_AutomaticFusionRequest()             Notify the fusion server to launch a fusion process.
** DBA_BeginDateEndDateExtOpProcessing()    Set the begin and end date with the reference date
** DBA_ConvertExtOp2S_Op()                  Convert an ExtOp to sOp
** DBA_DropTempDomOper()	                Drops temporary table '#dom_oper'
** DBA_InsertEventScheduler()               Insert an event in event_scheduler
** DBA_DeleteEventScheduler()               Delete an event in event_scheduler
** DBA_LoadPtf()                            Load all informations for a portfolio
** DBA_CommonInsUpdExtOpBy()                Common code of DBA_InsExtOpById and DBA_UpdExtOpById
** DBA_GetExecWithId                        Get the existing execution / global exec fee with his Id
** DBA_DelRecById                           Delete the record (umex /execution / global exec fee)
** DBA_ComputeEventSchedDateWithPPS()		Modify dateMin according to eventSchedNatEn, ...
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE DBA_DropTempDomOper(DbiConnection & );
STATIC RET_CODE DBA_AutomaticFusionRequest(DbiConnection &, struct AutomaticFusionStock *);
STATIC RET_CODE DBA_InsExtOpById(DBA_DYNFLD_STP,
                                 DbiConnection &,
                                 FLAG_T,
                                 struct AutomaticFusionStock *);
STATIC RET_CODE DBA_UpdExtOpById(DBA_DYNFLD_STP,
                                 DbiConnection &,
                                 struct AutomaticFusionStock *);
STATIC RET_CODE DBA_DelExtOpById(DBA_DYNFLD_STP,
                                 DbiConnection &,
                                 struct AutomaticFusionStock *);
STATIC void DBA_GetFusDateExtOp(DATETIME_T *,
                                const FUSDATERULE_ENUM,
                                const DBA_DYNFLD_STP);
STATIC void DBA_GetFusDateExecution(DATETIME_T *,
                                    const FUSDATERULE_ENUM,
                                    const DBA_DYNFLD_STP);
STATIC RET_CODE DBA_CommonInsUpdExtOpBy(const char *,
                                        DBA_DYNFLD_STP,
                                        FLAG_T *,
                                        DBA_DYNFLD_STP *,
                                        DBA_DYNFLD_STP * *,
                                        int *,
                                        FUSDATERULE_ENUM *,
                                        ENUM_T *,
                                        DbiConnection&); /* REF9350 - TEB - 030806 */
STATIC RET_CODE DBA_CommonExtOpByIdAndFuse(DBA_DYNFLD_STP,
                                           DbiConnection &,
                                           FLAG_T,
                                           RET_CODE (* functionToCall1)(DBA_DYNFLD_STP, DbiConnection& , struct AutomaticFusionStock *),
                                           RET_CODE (* functionToCall2)(DBA_DYNFLD_STP, DbiConnection&, FLAG_T, struct AutomaticFusionStock *));

STATIC RET_CODE DBA_GetExecWithId(DBA_DYNFLD_STP *, OBJECT_ENUM, FLAG_T, FLAG_T *, DbiConnection &);   /* REF9764 - TEB - 040210 */ /* PMSTA-nuodb - LJE - 190611 */
STATIC RET_CODE DBA_DelRecById(ID_T, OBJECT_ENUM, DBA_DYNST_ENUM, int, DbiConnection &);          /* REF9764 - TEB - 040210 */      /* PMSTA-nuodb - LJE - 190611 */
STATIC void DBA_ComputeEventSchedDateWithPPS(DBA_DYNFLD_STP *,
                                             const int,
                                             const DBA_DYNFLD_STP,
                                             const DBA_DYNFLD_STP,
                                             const DBA_DYNFLD_STP,
                                             const EVENTSCHEDNAT_ENUM,
                                             DATETIME_T *);  /* REF9883 - RAK - 040303 */


STATIC FLAG_T DBA_PtfHasChanged( const DBA_DYNFLD_STP, const DBA_DYNFLD_STP );                  /*REF11159-EFE-050503*/
STATIC FLAG_T DBA_ExecutionHasChanged( const DBA_DYNFLD_STP, const DBA_DYNFLD_STP );            /*REF11159-EFE-050511*/


/*
 *  Check if P1 <= P2 <= P3
 *  Argument: P1 min
 *            P2 current
 *            P3 max
 *  TRUE if yes
 *  FALSE if no
 */
template<typename T>
bool BETWEEN_EQ(T P1, T P2, T P3) { return P1 <= P2 && P2 <= P3; }


/************************************************************************
**      FONCTIONS
************************************************************************/


/************************************************************************
**
**  Function    :   DBA_ExtOpUpdateTimeStamp()
**
**  Description :   Update the time stamp into the C structure.
**                  This is used after a commit to update the time stamp
**
**  Arguments   :   extOpSt Structure to update the time stamp
**
**  Return      :   None
**
**  Creation    :   REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**
**  Last modif. :
**
*************************************************************************/
void DBA_ExtOpUpdateTimeStamp(DBA_DYNFLD_STP extOpSt)
{
    if (IS_NULLFLD(extOpSt, ExtOp_TimeStampNew) == false)
    {
        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStampNew);
    }

    COPY_DYNFLD(extOpSt, ExtOp, ExtOp_LastModifDate, extOpSt, ExtOp, ExtOp_AudModifDate);
}


/************************************************************************
**
**  Function    :   DBA_CreateDataDesynchronizedFusion()
**
**  Description :   Allocate memory to store all informations to launch desynchronized fusion
**
**  Arguments   :   None
**
**  Return      :   Memory allocated
**                  NULL if not enough memory
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
**  Last modif. :
**
*************************************************************************/
STATIC struct AutomaticFusionStock  * DBA_CreateDataDesynchronizedFusion(void)
{
    return static_cast<struct AutomaticFusionStock *>(CALLOC(1, sizeof(struct AutomaticFusionStock)));
}


/************************************************************************
**
**  Function    :   DBA_FreeDataDesynchronizedFusion()
**
**  Description :   Free memory to store all informations to launch desynchronized fusion
**
**  Arguments   :   Pointer to a block allocated by DBA_CreateDataDesynchronizedFusion
**
**  Return      :   None
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
**  Last modif. :
**
*************************************************************************/
STATIC void DBA_FreeDataDesynchronizedFusion(struct AutomaticFusionStock * pAutomaticFusionStock)
{
    FREE(pAutomaticFusionStock);
}


/************************************************************************
**
**  Function    :   DBA_LaunchFusion()
**
**  Description :   Launch a fusion
**
**  Arguments   :   pData       Pointer to the data to use
**                  connectNo   connection number
**
**  Return      :   None
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
**  Last modif. :   PMSTA-23094 - 190416 - PMO : Financial server crash on DBA_AutomaticFusionRequest when getting connection
**
*************************************************************************/
STATIC void DBA_LaunchFusion(void * pData, DbiConnection &dbiConn)
{
    struct AutomaticFusionStock * pAutomaticFusionStock =  static_cast<struct AutomaticFusionStock *>(pData);       /* PMSTA-23094 - 190416 - PMO */

    /* PMSTA-23094 - 190416 - PMO */
    if (pAutomaticFusionStock->ptfToFuseTab != NULL)
    {
        (void)DBA_AutomaticFusionRequest(dbiConn, pAutomaticFusionStock);
    }
}


/************************************************************************
**
**  Function    :   DBA_LaunchFusionFree()
**
**  Description :   Free the memory ptfToFuseTab into the structure AutomaticFusionStock
**
**  Arguments   :   pData   Pointer to the data to free
**                          Pointer must be of type struct AutomaticFusionStock *
**
**  Return      :   None
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
**  Last modif. :
**
*************************************************************************/
STATIC void DBA_LaunchFusionFree(void * pData)
{
    struct AutomaticFusionStock * pAutomaticFusionStock = static_cast<struct AutomaticFusionStock *>(pData);

    /* Free memory allocations */
    FREE(pAutomaticFusionStock->ptfToFuseTab);
}

/************************************************************************
**
**  Function    :   DBA_StockPortfolioToFuse()
**
**  Description :   Insert a portfolio id in a tab
**
**  Arguments   :   ID_T id portoflio
**
**  Return      :   RET_MEM_ERR_REALLOC
**                  RET_SUCCEED
**
**  Creation    :   SME REF437 980611
**  Last modif. :   REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE DBA_StockPortfolioToFuse(ID_T id, struct AutomaticFusionStock * autoFusStock)
{
    for (int i = 0; i < autoFusStock->nbPtfToFuse; i++)
    {
        if (autoFusStock->ptfToFuseTab[i] == id)
        {
            return RET_SUCCEED;
        }
    }

    /* id not found  */

    if (autoFusStock->nbPtfToFuse >= autoFusStock->nbPtfToFuseMax)
    {
        autoFusStock->nbPtfToFuseMax += 10;
        if (NULL == (autoFusStock->ptfToFuseTab = static_cast<ID_T *>(REALLOC(autoFusStock->ptfToFuseTab, autoFusStock->nbPtfToFuseMax * sizeof(ID_T)))))   /* REF7264 - PMO */
        {
            MSG_SendMesg(RET_MEM_ERR_REALLOC, 1, FILEINFO, autoFusStock->ptfToFuseTab, autoFusStock->nbPtfToFuseMax * sizeof(ID_T));
            return(RET_MEM_ERR_REALLOC);
        }
    }
    autoFusStock->ptfToFuseTab[autoFusStock->nbPtfToFuse++] = id;

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_DefFusDateRuleForOpAcctValueInsUpdOp()
**
**  Description :   Set the missing date of operation date, accounting date,
**                  valuation date according to the fusion date rule
**                  The reference date come from the fusion date rule
**
**  Arguments   :   dynFldPtf           Pointer to the portfolio
**                  extOpSt	            Pointer to the structure what contain at least the fusion date rule
**
**  Return      :   TRUE  if ok
**		            FALSE Possible reasons is fusionDateRuleE with invalid value
**                        or fusionDateRuleE is correct bat the reference date is missing
**                        (fusionDateRuleE = FusDateRule_OpDat bat the operation date is missing)
**
**  Creation    :   REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**
**  Last modif. :   REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**                  REF10256 - 060713 -EFE : send a msg to the log if the FUSION_SWITCH_DATE parameter is NULL or set to MAGIC_END_DATE
**                  PMSTA-19067 - 250315 - PMO : When creating an order without date the function, DBA_DefFusDateRuleForOpAcctValueInsUpdOp do not write any error message and it is not possible to save the order
**
*************************************************************************/
STATIC RET_CODE DBA_DefFusDateRuleForOpAcctValueInsUpdOp(const DBA_DYNFLD_STP   dynFldPtf,
                                                         DBA_DYNFLD_STP         extOpSt,
                                                         DbiConnection         &dbiConn)
{
    DATE_T      fusionSwitchDate;                           /* Value of the system parameter    */
    RET_CODE    ret                = RET_GEN_ERR_INVARG;    /* Return value                     */

    /* Obtain the system parameter */
    (void)GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate);

    /* System parameter defined */
    if (0 != DATE_Cmp(fusionSwitchDate, MAGIC_END_DATE))
    { /* Yes */

        FUSDATERULE_ENUM fusionDateRule;
        FUSDATERULE_ENUM oldFusionDateRule;
        DATETIME_T       beginDateTimeOldFusionDateRule;    /* Calculated with old fusion date          */
        DATETIME_T       beginDateTimeFusionDateRule;       /* Calculated with fusion date rule         */

        /* Obtain the old fusion date rule and the old way to obtain the fusion date rule */
        (void)GEN_GetApplInfo(ApplOldFusionDateRule, &oldFusionDateRule);
        fusionDateRule = DBA_GetOldFusDateRule(dynFldPtf,
                                               S_Ptf_FusionDateRuleEn,
                                               NULL,
                                               0);

        /* Obtain the date */
        DBA_GetFusDateExtOp(&beginDateTimeFusionDateRule,    fusionDateRule,    extOpSt);
        DBA_GetFusDateExtOp(&beginDateTimeOldFusionDateRule, oldFusionDateRule, extOpSt);

        /* All interessant date are present */
        if (beginDateTimeFusionDateRule.date    != BAD_DATE &&
            beginDateTimeOldFusionDateRule.date != BAD_DATE)
        { /* All interessant date are present */

            /* Obtain the old fusion date rule with the standard way */
            fusionDateRule = DBA_GetFusDateRule(dynFldPtf,
                                                S_Ptf_FusionDateRuleEn,
                                                S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                                NULL,
                                                0,
                                                extOpSt,
                                                ExtOp);

            if (FusDateRule_UseSwitchDate == fusionDateRule)
            { /* Special case */
                (void)DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, FusDateRule_OpDate);
                ret = DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, FusDateRule_ValDate);
            }
            else
            { /* Standard case */
                ret = DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, fusionDateRule);
            }
        }
        else
        { /* One or two interessant date is/are missing */

            /* The date of the fusion date rule is present and greater than or equal to the fusion switch date */
            if (beginDateTimeFusionDateRule.date != BAD_DATE &&
                DATE_Cmp(beginDateTimeFusionDateRule.date, fusionSwitchDate) >= 0)
            { /* Yes */
                ret = DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, fusionDateRule);
            }
            else
            {
                /* The date of the old fusion date rule is present and less than or equal to the fusion switch date */
                if (beginDateTimeOldFusionDateRule.date != BAD_DATE &&
                    DATE_Cmp(beginDateTimeOldFusionDateRule.date, fusionSwitchDate) <= 0)
                { /* Yes */
                    ret = DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, oldFusionDateRule);
                }
            }

            if (RET_SUCCEED != ret)
            { /* Error / PMSTA-19067 - 250315 - PMO */
                FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, NULL, "Operation dates cannot be NULL"));
            }
        }

    }
    else /*REF10256-EFE-060713*/
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYSTEM PARAMETER FUSION_SWITCH_DATE must not be NULL");
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_DefFusDateRuleForOpAcctValue()
**
**  Description :   Set the missing date of operation date, accounting date,
**                  valuation date according to the fusion date rule
**                  The reference date come from the fusion date rule
**
**  Arguments   :   refDatePtr          The fusion reference date. Can be NULL
**                  extOpSt	            Pointer to the structure what contain dates
**                  fusionDateRuleE     Valid fusion date rule is FusDateRule_OpDate
**                                                                FusDateRule_AcctDate
**                                                                FusDateRule_ValDate
**
**  Return      :   RET_SUCCEED         if ok
**		            RET_GEN_ERR_INVARG  if error. refDatePtr is set with zero
**                        Possible reasons is fusionDateRuleE with invalid value
**                        or fusionDateRuleE is correct bat the reference date is missing
**                        (fusionDateRuleE = FusDateRule_OpDat bat the operation date is missing)
**
**  Creation    :   REF7854 - 020925 - PMO : Not possible to insert operation if the value date not set
**  Last modif. :   REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**                  REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**                  PMSTA-19067 - 250315 - PMO : When creating an order without date the function, DBA_DefFusDateRuleForOpAcctValueInsUpdOp do not write any error message and it is not possible to save the order
**
*************************************************************************/
RET_CODE DBA_DefFusDateRuleForOpAcctValue(DATETIME_T *              refDatePtr,
                                          DBA_DYNFLD_STP            extOpSt,
                                          const FUSDATERULE_ENUM    fusionDateRuleE)
{

    RET_CODE    ret     = RET_GEN_ERR_INVARG;   /* Return value     * PMSTA-19067 - 250315 - PMO */
    DATETIME_T  beginD;                         /* Begin date used  */

    /*
     *  Initialization
     */
    memset(&beginD, 0, sizeof(DATETIME_T));


    if (fusionDateRuleE == FusDateRule_OpDate &&
        GET_DATE(extOpSt, ExtOp_OpDate) != ZERO_DATE)
    {
        beginD = GET_DATETIME(extOpSt, ExtOp_OpDate);

        if (GET_DATE(extOpSt, ExtOp_AcctDate) == ZERO_DATE)
        {
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctDate, extOpSt, ExtOp, ExtOp_OpDate);
        }

        if (GET_DATE(extOpSt, ExtOp_ValueDate) == ZERO_DATE)
        {
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_ValueDate, extOpSt, ExtOp, ExtOp_OpDate);
        }

        ret = RET_SUCCEED;
    }
    else
    {
        if (fusionDateRuleE == FusDateRule_AcctDate &&
            GET_DATE(extOpSt, ExtOp_AcctDate) != ZERO_DATE)
        {
            beginD = GET_DATETIME(extOpSt, ExtOp_AcctDate);

            if (GET_DATE(extOpSt, ExtOp_OpDate) == ZERO_DATE)
            {
                COPY_DYNFLD(extOpSt, ExtOp, ExtOp_OpDate, extOpSt, ExtOp, ExtOp_AcctDate);
            }

            if (GET_DATE(extOpSt, ExtOp_ValueDate) == ZERO_DATE)
            {
                COPY_DYNFLD(extOpSt, ExtOp, ExtOp_ValueDate, extOpSt, ExtOp, ExtOp_AcctDate);
            }

            ret = RET_SUCCEED;
        }
        else
        {
            if (fusionDateRuleE == FusDateRule_ValDate &&
                GET_DATE(extOpSt, ExtOp_ValueDate) != ZERO_DATE)
            {
                beginD = GET_DATETIME(extOpSt, ExtOp_ValueDate);

                if (GET_DATE(extOpSt, ExtOp_OpDate) == ZERO_DATE)
                {
                    COPY_DYNFLD(extOpSt, ExtOp, ExtOp_OpDate, extOpSt, ExtOp, ExtOp_ValueDate);
                }

                if (GET_DATE(extOpSt, ExtOp_AcctDate) == ZERO_DATE)
                {
                    COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctDate, extOpSt, ExtOp, ExtOp_ValueDate);
                }

                ret = RET_SUCCEED;
            }
            else
            {
                /* REF10785 - 041129 - PMO */
                if (fusionDateRuleE == FusDateRule_UseSwitchDate)
                {
                    DBA_GetFusDateExtOp(&beginD, fusionDateRuleE, extOpSt);

                    if (GET_DATE(extOpSt, ExtOp_OpDate) == ZERO_DATE)
                    {
                        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_OpDate, extOpSt, ExtOp, ExtOp_ValueDate);
                    }

                    if (GET_DATE(extOpSt, ExtOp_AcctDate) == ZERO_DATE)
                    {
                        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctDate, extOpSt, ExtOp, ExtOp_ValueDate);
                    }

                    if (GET_DATE(extOpSt, ExtOp_ValueDate) == ZERO_DATE)
                    {
                        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_ValueDate, extOpSt, ExtOp, ExtOp_AcctDate);
                    }

                    ret = RET_SUCCEED;
                }
            }
        }
    }

    /* Copy the date */
    if (refDatePtr != NULL)
    { /* Yes */

        /* Have correct value */
        if (ret == RET_SUCCEED)
        { /* Yes */
            *refDatePtr = beginD;
        }
        else
        { /* No */
            memset(refDatePtr, 0, sizeof(DATETIME_T));
        }
    }

    return ret;
}

STATIC RET_CODE deleteSleeveChildOrder(SleeveHead& head)
{
    head.type = SleeveOpType::Deleted;
    SleeveProcessor sleeveProcessor;
    return sleeveProcessor.createRevDelSleeveOp(head);
}
STATIC RET_CODE createChildSleeveOrder(SleeveHead& head)
{
    RET_CODE ret = RET_SUCCEED;
  
    SleeveProcessor sleeveProcessor;
    ret = sleeveProcessor.createRevDelSleeveOp(head);

    if (RET_SUCCEED != ret) {
        MSG_SendMesg(FILEINFO, "setValues: creatRevDelSleeveOp.");
        return ret;
    }

    FLAG_T			*scptFlagTab = NULL;
    if ((scptFlagTab = (FLAG_T*)
        CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
    {
        MSG_SendMesg(FILEINFO, "setValues: scptFlagTab allocation failed. NULL.");
        return RET_GEN_ERR_NOACTION;
    }
    else
    {
        FIELD_IDX_T bpFlds[] = { ExtOp_Bp1Amt, ExtOp_Bp2Amt , ExtOp_Bp3Amt , ExtOp_Bp4Amt , ExtOp_Bp5Amt , ExtOp_Bp6Amt , ExtOp_Bp7Amt, ExtOp_Bp8Amt , ExtOp_Bp9Amt ,ExtOp_Bp10Amt };

        for (int i = 0; i < GET_FLD_NBR(ExtOp); ++i)
        {
            scptFlagTab[i] = FALSE;
        }
        scptFlagTab[ExtOp_Qty] = TRUE;
        scptFlagTab[ExtOp_Price] = TRUE;
        scptFlagTab[ExtOp_Quote] = TRUE;
        scptFlagTab[ExtOp_OpSplitRuleEn] = TRUE;
        scptFlagTab[ExtOp_OpDate] = TRUE;
        scptFlagTab[ExtOp_AcctDate] = TRUE;
        scptFlagTab[ExtOp_ValueDate] = TRUE;
        scptFlagTab[ExtOp_SplitParentOperId] = TRUE;
        scptFlagTab[ExtOp_SplitParOpCd] = TRUE;

        SET_NUMBER(head.m_extOrder, ExtOp_Qty, ZERO_NUMBER);
        SET_NUMBER(head.m_extOrder, ExtOp_AdjQty, ZERO_NUMBER);
        std::vector<AMOUNT_T> backupBp;
        for (int i = 0; i < (sizeof(bpFlds) / sizeof(bpFlds[0])); ++i)
        {
            scptFlagTab[bpFlds[i]] = TRUE;
            backupBp.push_back(GET_AMOUNT(head.m_extOrder, (bpFlds[i])));
            SET_AMOUNT(head.m_extOrder, (bpFlds[i]), ZERO_AMOUNT);
        }
        if (0 != SCPT_ComputeDV(EOp, scptFlagTab, head.m_extOrder, TRUE, FALSE, NULL))
        {
            SET_NUMBER(head.m_extOrder, ExtOp_Qty, head.m_extQty);
            SET_NUMBER(head.m_extOrder, ExtOp_Qty, head.m_extAdjQty);
            for (int i = 0; i < (sizeof(bpFlds) / sizeof(bpFlds[0])); ++i)
            {
                SET_AMOUNT(head.m_extOrder, (bpFlds[i]), (backupBp[i]));
            }
            ret = RET_GEN_ERR_NOACTION;
        }
    }
    FREE(scptFlagTab);

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_InsOperationById()
**
**  Description :   Insert an operation buy, sell, ... into the database
**                  This function converts first the operation into an
**                  'extended' operation, which is inserted into the database.
**                  It can only be called by dbaproc.c and assures people
**                  can still insert an operation Buy, sell, etc.
**
**  Arguments   :   object	 the request corresponding object
**                  inputSt      the input dynamic structure format
**                  inputData    the pointer on the input dynamic structure
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                  received messages informations.
**
**  Return      :   RET_SUCCEED 	if ok
**                  RET_GEN_ERR_INVARG	error in arguments
**                  RET_DBA_ERR_MD	error in meta-dictionary
**                  RET_MEM_ERR_ALLOC	error in memory allocation
**                  RET_DBA_ERR_NODATA  error in retrieving or constructing data
**
**  Creation    :   DVP029 - 170496 - DED
**  Modif.      :   ROI - 970407 - DVP417
**                  GRD - 000509 - REF4714.
**                  REF7560 - 020826 - PMO : Order Management Entity light project: database infrastructure
**                  HFI-PMSTA-46035-210908  : Replace ExtOp_TimeStampNew by ExtOp_TimeStamp. ExtOp_TimeStamp is now already modified by the procedure.
**
*************************************************************************/
RET_CODE DBA_InsOperationById(OBJECT_ENUM object,
                              DBA_DYNST_ENUM inputSt,
                              DBA_DYNFLD_STP inputData,
                              DbiConnectionHelper& dbiConnHelper)
{
    OPNAT_ENUM      operNat = OpNat_None;
    RET_CODE        ret;
    DBA_DYNFLD_STP  extOpSt = NULL;
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();


#if defined (AAATIMER)
    TIMER_ST       timerSt;
#endif
    FLAG_T         localTranFlg = FALSE;

    /* Timer Management */
    DATE_RESET_TIMER(&timerSt, TIMER_MASK_OPE);
    DATE_START_TIMER(&timerSt, TIMER_MASK_OPE);

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsOperationById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get corresponding OPNAT_ENUM for object operation record */
    ret = OPE_DictEnumToOperNat(object, &operNat);

    if (ret != RET_SUCCEED || operNat == OpNat_None)
    {
        MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
        return(RET_DBA_ERR_MD);
    }

    /* Memory allocation for extended operation record */
    if ((extOpSt = ALLOC_DYNST(ExtOp)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
        return(RET_MEM_ERR_ALLOC);
    }

    /* Transform the operation record into an 'extended' operation record */
    ret = OPE_OpToExtOp(inputData, operNat, extOpSt, FALSE);         /*  FPL-REF9215-030811  Add last parameter  */

    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
        FREE_DYNST(extOpSt, ExtOp);
        return(RET_DBA_ERR_NODATA);
    }

    /* Insert extended operation into the database */
    SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsert);    /* DVP417 / REF7560 - PMO */

    if ((dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        (GET_ENUM(extOpSt, ExtOp_ParOpNatEn) != ParOpNat_None && GET_ENUM(extOpSt, ExtOp_ParOpNatEn) != ParOpNat_NoGrouping)) /* PMSTA-18601 - DDV - 141212 - Fix No grouping mode */
    {
        DBA_ACCESS_ST        multiAccessSt;
        DBA_ERRMSG_HEADER_ST msgStructHead;

        /* insertion block order in block mode */
        multiAccessSt.data   = extOpSt;
        multiAccessSt.action = Insert;
        multiAccessSt.role   = UNUSED;
        multiAccessSt.object = EOp;
        multiAccessSt.entity = ExtOp;

        /*
         * As we want to use DBA_NO_ERROR, we have to open a transaction before calling the MultiAccess.
         * REF4714.
         */
        if (dbiConn.isInTransaction() == false) /* DLA - REF5695 - 011030 -> <= a la place de == */
        {
            ret = dbiConn.beginTransaction();

            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(extOpSt, ExtOp);
                return ret;
            }

            localTranFlg = TRUE;
        }

        ret = DBA_HandleOperTabByBlock(dbiConn, &multiAccessSt, 0, 0, 1, DBA_NO_ERROR | DBA_SET_CONN | DBA_NO_CLOSE);

        if (ret != RET_SUCCEED)
        {
            if (localTranFlg == TRUE)
            {
                dbiConn.endTransaction(FALSE);        /* Rollback. */
            }
        }
        else
        {
            if (localTranFlg == TRUE)
            {
                dbiConn.endTransaction(TRUE);             /* Commit. */
            }
        }
    }
    else
    {
        ret = dbiConnHelper.dbaInsert(EOp, UNUSED, extOpSt);
    }

    if (ret != RET_SUCCEED)
    {
        /* Free memory allocation for extended operation */
        FREE_DYNST(extOpSt, ExtOp);
        return(ret);
    }

    /* REF423 SME */
    /* Update Operation and Accounting code */


    /* REF8844 - LJE - 030415 */
    if (object == BuyOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, BuyOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, BuyOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, BuyOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, BuyOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, BuyOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, BuyOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, BuyOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);          /* PMSTA4849-EFE080109 */

        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, BuyOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == SellOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, SellOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, SellOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, SellOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, SellOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, SellOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, SellOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, SellOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);         /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, SellOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == IncOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, IncOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, IncOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, IncOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, IncOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, IncOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, IncOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, IncOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);          /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, IncOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == InvestOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, InvestOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, InvestOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, InvestOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, InvestOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, InvestOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, InvestOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, InvestOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);           /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, InvestOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == WithdrOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, WithdrOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, WithdrOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, WithdrOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, WithdrOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, WithdrOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, WithdrOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, WithdrOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);           /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, WithdrOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == FtOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, FtOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, FtOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, FtOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, FtOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, FtOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, FtOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, FtOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);           /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, FtOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == AdjustOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, AdjustOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, AdjustOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, AdjustOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, AdjustOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, AdjustOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, AdjustOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, AdjustOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);           /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, AdjustOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == ShareIssOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, ShareIssOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, ShareIssOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);         /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, ShareIssOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == ShareRedmOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, ShareRedmOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);        /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, ShareRedmOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == TransfOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, TransfOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, TransfOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, TransfOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, TransfOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, TransfOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, TransfOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, TransfOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);           /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, TransfOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == BpTransfOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, BpTransfOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, BpTransfOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);         /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, BpTransfOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == LockOpEnt)
    {

        COPY_DYNFLD(inputData, inputSt, LockOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, LockOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, LockOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, LockOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, LockOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, LockOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, LockOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);         /* PMSTA4849-EFE080109 */


        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, LockOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == BookAdjOpEnt )
    {

        COPY_DYNFLD(inputData, inputSt, BookAdjOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, BookAdjOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);          /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, BookAdjOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == PtfTransfOpEnt )
    {

        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, PtfTransfOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);        /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, PtfTransfOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }
    else if (object == InitOpEnt )
    {

        COPY_DYNFLD(inputData, inputSt, InitOp_Cd, extOpSt, ExtOp, ExtOp_Cd);
        COPY_DYNFLD(inputData, inputSt, InitOp_SrcCd, extOpSt, ExtOp, ExtOp_SrcCd);
        COPY_DYNFLD(inputData, inputSt, InitOp_AcctCd, extOpSt, ExtOp, ExtOp_AcctCd);
        COPY_DYNFLD(inputData, inputSt, InitOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
        COPY_DYNFLD(inputData, inputSt, InitOp_LastModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);
        COPY_DYNFLD(inputData, inputSt, InitOp_AutoIndex, extOpSt, ExtOp, ExtOp_AutoIndex); /* REF6915 */
        COPY_DYNFLD(inputData, inputSt, InitOp_TimeStamp, extOpSt, ExtOp, ExtOp_TimeStamp);         /* PMSTA4849-EFE080109 */
        /* If Block Mode isn't activated */
		if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy database Id */
            COPY_DYNFLD(inputData, inputSt, InitOp_ExtOpDbId, extOpSt, ExtOp, ExtOp_DbId);
        }

    }

    /* Free memory allocation for extended operation */
    FREE_DYNST(extOpSt, ExtOp);
    /* DVP291 */

    /* Timer Management */
    DATE_STOP_TIMER(&timerSt, TIMER_MASK_OPE);
    DATE_DISPLAY_TIMER(&timerSt, TIMER_MASK_OPE, "Total timer insert Buy, Sell, ...");

    return(RET_SUCCEED);
}

/************************************************************************
**
** Function     :   DBA_SetOperationCode
**
** Description  :   Define a new operation code (business key)
**
** Arguments    :   extOpSt             extOp where to modify the business key
**                  autoCodeGenFlag     Value of generation_f for Op Code from doc_index_param
**                  autoAccCodeGenFlag  Value of generation_f for Acc Code from doc_index_param
**                  connectNo           connection number
**                  codeOp              return code operation for an insert (not mandatory)
**                  msgStructPtr        message
**
** Return       :   RET_SUCCEED         if success
**                  RET_MEM_ERR_ALLOC   if not enough memory
**                  RET_DBA_ERR_NODATA  Error when computing default value
**
** Creation     :   PMO REF7560 - 020530 : Order Management Entity light project: database infrastructure.
**
** Last Modif   :   REF9333 - TEB - 030825 : Bad coding
**
************************************************************************/
STATIC RET_CODE DBA_SetOperationCode(DBA_DYNFLD_STP extOpSt,
                                     FLAG_T autoCodeGenFlag,
                                     FLAG_T autoAccCodeGenFlag,
                                     DbiConnection &dbiConn,
                                     CODE_T codeOp)
{
    OBJECT_ENUM     entity;
    DBA_DYNST_ENUM  stEnum;
    FLAG_T          opCodeFlg     = FALSE;
    FLAG_T          opAcctCodeFlg = FALSE;  /* REF3839 - SSO - 990723 */
    RET_CODE        retCode       = RET_SUCCEED;
    FLAG_T *        opFlagTab     = NULL;
    OPNAT_ENUM      opNat         = static_cast<OPNAT_ENUM>(GET_ENUM(extOpSt, ExtOp_NatureEn)); /* REF7264 - PMO */

    OPE_OperNatToDictEnum(opNat, &stEnum, &entity);

    DBA_DYNFLD_STP op = ALLOC_DYNST(stEnum);
    if (op == NULL)
    { /* Error */
        retCode = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(retCode, 0, FILEINFO, retCode);
    }
    else
    { /* Ok */

        if ((opFlagTab = static_cast<FLAG_T *>(CALLOC(GET_FLD_NBR(stEnum), sizeof(FLAG_T)))) == NULL)
        { /* Error */
            retCode = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(retCode, 0, FILEINFO, retCode);
        }
    }

    if (retCode == RET_SUCCEED)
    {

        for (int opFlagTabIdx = 0; opFlagTabIdx < GET_FLD_NBR(stEnum); opFlagTabIdx++)
        {
            opFlagTab[opFlagTabIdx] = TRUE;
        }

        /* REF3839 - SSO - 990723 do not overwrite non-null codes! */
        if ((IS_NULLFLD(extOpSt, ExtOp_Cd) == false) || (autoCodeGenFlag == FALSE))
        {
            opCodeFlg = TRUE;
        }

        if ((IS_NULLFLD(extOpSt, ExtOp_AcctCd) == false) || (autoAccCodeGenFlag == FALSE))
        {
            opAcctCodeFlg = TRUE;
        }

        /* set flag by opNat */
        /* REF8844 - LJE - 030415 */
        if (entity == BuyOpEnt)
        {

            opFlagTab[BuyOp_Cd] = opCodeFlg;
            opFlagTab[BuyOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == SellOpEnt)
        {

            opFlagTab[SellOp_Cd] = opCodeFlg;
            opFlagTab[SellOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == IncOpEnt)
        {

            opFlagTab[IncOp_Cd] = opCodeFlg;
            opFlagTab[IncOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == InvestOpEnt)
        {

            opFlagTab[InvestOp_Cd] = opCodeFlg;
            opFlagTab[InvestOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == WithdrOpEnt)
        {

            opFlagTab[WithdrOp_Cd] = opCodeFlg;
            opFlagTab[WithdrOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == FtOpEnt)
        {

            opFlagTab[FtOp_Cd] = opCodeFlg;
            opFlagTab[FtOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == AdjustOpEnt)
        {

            opFlagTab[AdjustOp_Cd] = opCodeFlg;
            opFlagTab[AdjustOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == ShareIssOpEnt)
        {

            opFlagTab[ShareIssOp_Cd] = opCodeFlg;
            opFlagTab[ShareIssOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == ShareRedmOpEnt)
        {

            opFlagTab[ShareRedmOp_Cd] = opCodeFlg;
            opFlagTab[ShareRedmOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == TransfOpEnt)
        {

            opFlagTab[TransfOp_Cd] = opCodeFlg;
            opFlagTab[TransfOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == BpTransfOpEnt)
        {

            opFlagTab[BpTransfOp_Cd] = opCodeFlg;
            opFlagTab[BpTransfOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == LockOpEnt)
        {

            opFlagTab[LockOp_Cd] = opCodeFlg;
            opFlagTab[LockOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == BookAdjOpEnt )
        {

            opFlagTab[BookAdjOp_Cd] = opCodeFlg;
            opFlagTab[BookAdjOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == PtfTransfOpEnt )
        {

            opFlagTab[PtfTransfOp_Cd] = opCodeFlg;
            opFlagTab[PtfTransfOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == InitOpEnt)
        {

            opFlagTab[InitOp_Cd] = opCodeFlg;
            opFlagTab[InitOp_AcctCd] = opAcctCodeFlg;

        }
        else if (entity == CombinedOpEnt) /* PMSTA06760 - DDV - 080702 */
        {

            opFlagTab[CombinedOp_Cd] = opCodeFlg;
            opFlagTab[CombinedOp_AcctCd] = opAcctCodeFlg;

        }

        /* Convert a extended operation structure to a operation / REF2807, added connection info. */
        OPE_ExtOpToOp(extOpSt, op, nullptr, FALSE);            /*  FPL-REF9215-030811  */

        dbiConn.getConnStructPtr()->noDeleteMessageInfo = 1;

        if ((SYS_IsGuiMode() == TRUE) ||
            (DBA_GetEvalEntityFlag() == TRUE))                  /*  FPL-PMSTA09698-100604   */
        {
            if (SCPT_ComputeScreenDV(entity,
                                     DictFct_0,
                                     opFlagTab,
                                     NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                     op,
                                     NULL,
                                     NULL,
                                     NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                     TRUE,
                                     TRUE,
                                     EvalType_DefValAndFilter,  /* FPL-REF9507-030930 */
                                     -1,
                                     &dbiConn.getId(),
                                     NULL,
                                     NULL,
                                     ZERO_ID,
                                     DictScreen,                /*  FIH-REF9789-040209  */
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NullEntity,
                                     FALSE,
                                     FALSE,
                                     0) != 0)   /*  FPL-REF9215-030811  Flag Impact */
            {                                       /* Error */
                dbiConn.getConnStructPtr()->noDeleteMessageInfo = 0;
                retCode = RET_DBA_ERR_NODATA;
                MSG_SendMesg(retCode, 0, FILEINFO, retCode);
            }
        }
        else
        {
            /* REF2982 - DDV - 990317 - mode must be TRUE not FALSE (eval all) */
            /* REF4229 - SSO - 000919 added connectNo parameter */
            if (SCPT_ComputeDV(entity, opFlagTab, op, TRUE, static_cast<FLAG_T>(SYS_IsGuiMode()), &dbiConn.getId()) < 0)
            {
                dbiConn.getConnStructPtr()->noDeleteMessageInfo = 0;
                retCode = RET_DBA_ERR_NODATA;
                MSG_SendMesg(retCode, 0, FILEINFO, retCode);
            }
        }

    } /* End if */

    if (retCode == RET_SUCCEED)
    {
        /* SME REF7124 */
        /* Verify if exist error messages in connection */
        dbiConn.getConnStructPtr()->noDeleteMessageInfo = 0;
        dbiConn.filterMsgInfos(&retCode);
    }

    if (retCode == RET_SUCCEED)
    {
        /* success copy default values in ExtOp */
        /* REF8844 - LJE - 030415 */
        if (entity == BuyOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, BuyOp, BuyOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, BuyOp, BuyOp_AcctCd);

        }
        else if (entity == SellOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, SellOp, SellOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, SellOp, SellOp_AcctCd);

        }
        else if (entity == IncOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, IncOp, IncOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, IncOp, IncOp_AcctCd);

        }
        else if (entity == InvestOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, InvestOp, InvestOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, InvestOp, InvestOp_AcctCd);

        }
        else if (entity == WithdrOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, WithdrOp, WithdrOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, WithdrOp, WithdrOp_AcctCd);

        }
        else if (entity == FtOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, FtOp, FtOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, FtOp, FtOp_AcctCd);

        }
        else if (entity == AdjustOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, AdjustOp, AdjustOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, AdjustOp, AdjustOp_AcctCd);

        }
        else if (entity == ShareIssOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, ShareIssOp, ShareIssOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, ShareIssOp, ShareIssOp_AcctCd);

        }
        else if (entity == ShareRedmOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, ShareRedmOp, ShareRedmOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, ShareRedmOp, ShareRedmOp_AcctCd);

        }
        else if (entity == TransfOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, TransfOp, TransfOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, TransfOp, TransfOp_AcctCd);

        }
        else if (entity == BpTransfOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, BpTransfOp, BpTransfOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, BpTransfOp, BpTransfOp_AcctCd);

        }
        else if (entity == LockOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, LockOp, LockOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, LockOp, LockOp_AcctCd);

        }
        else if (entity == BookAdjOpEnt )
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, BookAdjOp, BookAdjOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, BookAdjOp, BookAdjOp_AcctCd);

        }
        else if (entity == PtfTransfOpEnt )
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, PtfTransfOp, PtfTransfOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, PtfTransfOp, PtfTransfOp_AcctCd);

        }
        else if (entity == InitOpEnt)
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, InitOp, InitOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, InitOp, InitOp_AcctCd);
        }
        else if (entity == CombinedOpEnt) /* PMSTA06760 - DDV - 080702 */
        {

            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Cd, op, CombinedOp, CombinedOp_Cd);
            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AcctCd, op, CombinedOp, CombinedOp_AcctCd);
        }

        /* REF6915 */
        unsigned char uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
        if (opCodeFlg == FALSE)
        {
            SET_UCHAR_BIT(uCharBit, AUTOINDEXCODE, TRUE);
        }
        else
        {
            SET_UCHAR_BIT(uCharBit, AUTOINDEXCODE, FALSE);
        }
        SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit ); /* REF9333 - TEB - 030825 */

        uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
        if (opAcctCodeFlg == FALSE)
        {
            SET_UCHAR_BIT(uCharBit, AUTOINDEXACCODE, TRUE);
        }
        else
        {
            SET_UCHAR_BIT(uCharBit, AUTOINDEXACCODE, FALSE);
        }
        SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit ); /* REF9333 - TEB - 030825 */

        if (codeOp != NULL)
        {
            nstrcpy(codeOp, sizeof(CODE_T), GET_CODE(extOpSt, ExtOp_Cd));
        }

    } /* End if */

    /*
     *  Free memory allocated
     */
    FREE(opFlagTab);
    FREE_DYNST(op, stEnum);

    return retCode;
}


/************************************************************************
**
** Function    : DBA_BlockModeNewStep
**
** Description : In block mode, make an allocation for a new step if need
**
** Arguments   : connectNo          connection number
**
** Return      : RET_SUCCEED        ok
**               RET_MEM_ERR_ALLOC  memory allocation error
**
** Creation    : PMO REF7560- 020530 : Order Management Entity light project: database infrastructure.
**
** Last Modif  :
************************************************************************/
static RET_CODE DBA_BlockModeNewStep(DbiConnection &dbiConn)
{
    RET_CODE    ret    = RET_SUCCEED;
    int         curRec = dbiConn.getConnStructPtr()->blockModeExt.curRec;

    /* Assign another step for treatment */
    dbiConn.getConnStructPtr()->blockModeExt.curRecStep++;
    dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepNbr++;

    /* If end of step array is reached */
    if (dbiConn.getConnStructPtr()->blockModeExt.curRecStep >=
        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepDataSize)                              /* DVP342 */
    {
        int oldSize = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepDataSize;  /* DDV - REF3123 - 981209 */

        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepDataSize += DBA_ALLOC_STEPBLOC;

        DBA_OPER_STEP_STP operStepTmpStp = static_cast<DBA_OPER_STEP_STP>(REALLOC(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData,
                                                                                  dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepDataSize * sizeof(DBA_OPER_STEP_ST)));
        /* Test if allocation successful */
        if (NULL != operStepTmpStp)
        { /* Yes */
          /* Update the pointer (if realloc as changed the area) */
            dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData = operStepTmpStp;

            /* DDV - REF3123 - 981209 */
            memset(&(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec]).stepData[oldSize], 0,
                   DBA_ALLOC_STEPBLOC * sizeof(DBA_OPER_STEP_ST));
        }
        else
        { /* No */
          /* Allocation error */
            ret = RET_MEM_ERR_ALLOC;
        }

    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_MultiAccessDelNotepad()
**
**  Description :   Delete a notepad in multi-access mode.
**                  The growth of the multi-access is managed
**
**  Arguments   :   sNotepad    Arguments used to delete the notepad
**                  connectNo   Connection number
**
**  Return      :
**          RET_SUCCEED              if ok
**          RET_MEM_ERR_ALLOC        error in memory allocations
**
**  Creation    :  REF7560 - 020918 - PMO : Order Management Entity light project: database infrastructure
**
**  Last modif. :
**
*************************************************************************/
static RET_CODE DBA_MultiAccessDelNotepad(const DBA_DYNFLD_STP sNotepad, DbiConnection &dbiConn)
{
    /* Growth the area if need */
    RET_CODE ret = DBA_BlockModeNewStep(dbiConn);

    if (ret == RET_SUCCEED)
    {
        DBA_ACCESS_STP  delOp;
        const int       curRec  = dbiConn.getConnStructPtr()->blockModeExt.curRec;
        const int       curStep = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

        delOp               = & dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].delOp;
        delOp->action       = Delete;
        delOp->role         = DBA_ROLE_DEL_NOTEPAD_BY_OBJECT;
        delOp->object       = Notepad;
        delOp->entity       = S_Notepad;
        delOp->data         = sNotepad;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_MultiAccessDelCommunication()
**
**  Description :   Delete all related communications in multi-access mode.
**                  The growth of the multi-access is managed
**
**  Arguments   :   adm_Arg     Arguments used to delete all related communication
**                  connectNo   Connection number
**
**  Return      :   RET_SUCCEED              if ok
**                  RET_MEM_ERR_ALLOC        error in memory allocations
**
**  Creation    :   PMSTA-16340 - 191213 - PMO : Communication records in the communication entity are not deleted after the related operation is deleted
**
**  Last modif. :
**
*************************************************************************/
static RET_CODE DBA_MultiAccessDelCommunication(const DBA_DYNFLD_STP adm_Arg, DbiConnection &dbiConn)
{
    RET_CODE ret; /* Return value */

    if (NULL != adm_Arg)
    {
        /* Growth the area if need */
        ret = DBA_BlockModeNewStep(dbiConn);

        if (ret == RET_SUCCEED)
        {
            DBA_ACCESS_STP  delOp;
            const int       curRec  = dbiConn.getConnStructPtr()->blockModeExt.curRec;
            const int       curStep = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

            delOp               = &dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].delOp;
            delOp->action       = Delete;
            delOp->role         = DBA_ROLE_FUSION;
            delOp->object       = Communication;
            delOp->entity       = Adm_Arg;
            delOp->data         = adm_Arg;
        }
    }
    else
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_BlockModeInsUpdDelExtOp
**
** Description : In block mode, perform update of ExtOp in extOrder.
**               The audit is treated
**
** Arguments   : extopSt            extended operation to insert or update
**               inAuditData
**               localEventFlg      No action if FALSE
**               localAuditFlg
**		         connectNo          connection number
**		         newStep            alloc a new step in block mode
**               action             action to perform: Delete or Update
**
**
** Return      : RET_SUCCEED        ok
**               RET_MEM_ERR_ALLOC  memory allocation error
**
** Creation    : PMO REF7560- 020530 : Order Management Entity light project: database infrastructure.
**
**
** Last Modif  : EFE-LN11213-050527 : delete in ext_order in  block mode
**
************************************************************************/
static RET_CODE DBA_BlockModeInsUpdDelExtOp(const DBA_DYNFLD_STP extOpSt,
                                            DBA_DYNFLD_STP inAuditData,
                                            FLAG_T localEventFlg,
                                            FLAG_T localAuditFlg,
                                            DbiConnection &dbiConn,
                                            FLAG_T newStep,
                                            DBA_ACTION_ENUM action,
                                            DBA_ACTION_ENUM logicalAction) /* DLA - REF11355 - 050817 */

{
    assert(action == Update || action == Delete || action == Insert);

    RET_CODE    ret    = RET_SUCCEED;
    int         curRec = dbiConn.getConnStructPtr()->blockModeExt.curRec;
    int         curStep = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

    if (newStep == TRUE || 
        (action != Delete && ((DBA_ACCESS_STP)&dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].insOp)->data != nullptr)) /* PMSTA-54274 - JBC - 230831 */
    {
        ret = DBA_BlockModeNewStep(dbiConn);
    }

    if (ret == RET_SUCCEED)
    {
        curStep = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

        if (action == Delete)
        {

            DBA_ACCESS_STP delOp    = & dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].delOp;
            delOp->action           = Delete;
            delOp->object           = ExtOrder;
            delOp->entity           = Adm_Arg;
            ret                     = DBA_ConvertExtOp2Adm_Arg(&(delOp->data), extOpSt, ExtOp_DbId); /*REF11213-EFE-050527*/
        }
        else
        {

            DBA_ACCESS_STP insOp    = & dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].insOp;
            insOp->action           = action;
            insOp->object           = ExtOrder;
            insOp->entity           = ExtOp;
            insOp->data             = ALLOC_DYNST(ExtOp);                   /* DLA - REF7560 - 020710 */
            COPY_DYNST( insOp->data, extOpSt, ExtOp );                      /* DLA - REF7560 - 020710 */
        }

        /* Subscription */
        if (localEventFlg == TRUE)
        {

            DBA_ACCESS_STP auditOp = & dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].auditOp;
            auditOp->action        = logicalAction; /* DLA - REF11355 - 050817 */
            auditOp->role          = DBA_ROLE_SUBSCRIPTION;
            auditOp->object        = EOp;
            auditOp->entity        = ExtOp;

            if (localAuditFlg == TRUE)
            {

                auditOp->data = ALLOC_DYNST(ExtOp);                 /* DLA - REF8392 - 021108 */

                COPY_DYNST(auditOp->data, inAuditData, ExtOp);      /* DLA - REF7560 - 020806 */

                if (logicalAction == Update)                        /* DLA - REF11375 - 050823 */
                {
                    auditOp->newData = ALLOC_DYNST(ExtOp);          /* REF5644 - GRD - 010202 */
                    COPY_DYNST(auditOp->newData, extOpSt, ExtOp);   /* REF5644 - GRD - 010202 */
                }

                inAuditData = NULL;
            }
            else
            {
                auditOp->data = ALLOC_DYNST(ExtOp);
                COPY_DYNST(auditOp->data, extOpSt, ExtOp);
            }
        }
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_InsertEventScheduler
**
** Description : Insert an event in event scheduler
**               Two modes of insertion as supported: standard and block mode
**
** Arguments   : extOpStPtr         extOp used for extracting some datas
**               oldExtOpStPtr      Old extOp used for extracting some datas. Can be NULL
**               refDatePtr         reference date
**		         connectNo          connection number
**		         msgStructPtr       message
**               fusionScopeFlg     Fusion scope TRUE=ALL FALSE=NEW
**               accountingStatus   Level of the current accounting status
**
** Return      : RET_CODE
**               RET_DBA_ERR_INVDATA
**               RET_MEM_ERR_ALLOC
**               codeOp
**
** Creation    : REF7560 - 020530 - PMO :   Order Management Entity light project: database infrastructure.
**
** Last Modif  : REF8625 - 030113 - PMO :   Problem with copy operation (memory leak)
**               REF9208 - 030923 - PMO :   When you modify the cash account of an existing operation,
**                                          the old operation is not treated by the fusion engine
**               FPL-REF9069-030929     :   When you modify an operation (example the portfolio)after automatic
**                                          fusion the operation still exist in the valuation
**               REF9301 - 040219 - PMO :   this message appear sometimes after update field on child and block order:
**                                          The row (id=1234567) into the table ext_order has been modified by
**                                          someone/something else in the meantime
**               REF9978 - 041007 - EFE :   Event Scheduler is not updated when performing Fusion New
**                                          code report from PMO
**              REF10544 - 041007 -EFE :    Bad line in event scheduler where modifying the ptf in
**                                          an accounted and fusionned operation
**                                          code report from EFE
**               PMSTA-525 - 101006 - PMO : CLONE -Fusion problem on hierarchical structure model
**                                          (cash positions are not always loaded and treated)
**               PMSTA-9113 - 231209 - PMO : Missing launch of a "fusion all" on the target portfolio of a portfolio transfer operation updated from Accounted to Unaccounted
**               PMSTA-14364 - 230813 - PMO : Update SQL procedure required by the insert of fusion event when insert/update/delete operation
**               PMSTA-30373 - 280218 - PMO : Updating several time an accounting complex operation raise a timestamp error
**               PMSTA-32291 - 130818 - PMO : Review fusion_e management everywhere
**
************************************************************************/
STATIC RET_CODE DBA_InsertEventScheduler(const DBA_DYNFLD_STP           extOpStPtr,
                                         const DBA_DYNFLD_STP           oldExtOpStPtr,
                                         const DATETIME_T *             refDatePtr,
                                         const DBA_ACTION_ENUM          action,
                                         DbiConnection                  &dbiConn,
                                         struct AutomaticFusionStock *  autoFusStock,
                                         const int                      fusionScopeFlg,
                                         const OPSTAT_ENUM              accountingStatus                     /* PMSTA-525 - 041006 - PMO */
                                        )
{
    RET_CODE       ret              = RET_SUCCEED;          /* Return value                             */

    /* PMSTA-44492 - JBC - 210331 */
    static int newAaaOpFusOptiMode = -1;
    int dbaInsertRole = UNUSED;
    bool isImportOptiMode = false;

    if(newAaaOpFusOptiMode < 0)
    {
        newAaaOpFusOptiMode = 0;
        GEN_GetApplInfo(ApplAaaOpFusOptiEnum, &newAaaOpFusOptiMode);
    }

    if(static_cast<AaaOpFusOptiMode>(newAaaOpFusOptiMode) == AaaOpFusOptiMode::ImportOptiMode)
    {   /* event_scheduler population will be fusion all with insupd funcitonality in ins_event_sched_init_by_id */
        dbaInsertRole = DBA_ROLE_INIT_LOAD;
        isImportOptiMode = true;
    }


    DBA_DYNFLD_STP inputFusStat;                            /* Argument for input of event scheduler    */
    DBA_DYNFLD_STP inputFusStat2;                           /* Argument for input of event scheduler    */
    DICT_T         ptfDictId        = 0;                    /* Portfolio entity identifier              */   /* DLA - REF9089 - 030512 */
    bool           oldCashFlag      = false;                /* Flag if a cash portfolio is present      */
    bool           ptfCashChangeFlg = false;                /* If the portfolio cash as changed REF9208 - 030923 - PMO */
    char *         privateSrv       = NULL;                 /* DLA - PMSTA07062 - 080825 */

    /* PMSTA-9113 - 231209 - PMO
     * Test if
     * - Previous record is accounted
     * - Current  record is not accounted
     * - Previous record is a portfolio transfer
     */
    const bool bUpdPtfTransToUnAcc = NULL != oldExtOpStPtr
                                   && static_cast<OPSTAT_ENUM> (GET_ENUM(oldExtOpStPtr,  ExtOp_StatusEn)) >= accountingStatus
                                   && static_cast<OPSTAT_ENUM> (GET_ENUM(extOpStPtr,     ExtOp_StatusEn)) <  accountingStatus
                                   && static_cast<OPNAT_ENUM>  (GET_ENUM(oldExtOpStPtr,  ExtOp_NatureEn)) == OpNat_PtfTransf;

    /* Flag if a case of portfolio is present / REF9208 - 030923 - PMO */
    const bool cashFlag = TRUE == OPE_IsCashDone(extOpStPtr, dbiConn);

    if (NULL != oldExtOpStPtr)
    {
        /* Portfolio cash as changed REF9208 - 030923 - PMO */
        ptfCashChangeFlg = GET_ID(extOpStPtr, ExtOp_CashPtfId) != GET_ID(oldExtOpStPtr, ExtOp_CashPtfId);
        oldCashFlag      = TRUE == OPE_IsCashDone(oldExtOpStPtr, dbiConn);
    }

    if (action == Insert || action == Update)
    {
        if (IS_NULLFLD(extOpStPtr, ExtOp_InstrId) == false)
        {
            const bool testInstrument = nullptr != oldExtOpStPtr && 0 != CMP_ID(GET_ID(extOpStPtr, ExtOp_InstrId), GET_ID(oldExtOpStPtr, ExtOp_InstrId));   /* PMSTA-30373 - 280218 - PMO */

            if (true == testInstrument)
            {
                FLAG_T         allocOk = FALSE;
                DBA_DYNFLD_STP instrPtr;

                /* REF3913 - 990819 - DDV  */
                if (DBA_GetInstrById(GET_ID(extOpStPtr, ExtOp_InstrId), FALSE, &allocOk,
                                     &instrPtr, NULL, DBA_SET_CONN | DBA_NO_CLOSE,
                                     &dbiConn.getId()) != RET_SUCCEED)
                {
                    SYSNAME_T entSqlName;
                    strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, GET_ID(extOpStPtr, ExtOp_InstrId));
                    ret = FALSE;
                }

                if (ret == RET_SUCCEED && allocOk == TRUE)
                {
                    FREE_DYNST(instrPtr, A_Instr);
                }
            }
        }
    }

    /* Allocation of memory */
    if ((inputFusStat = ALLOC_DYNST(A_EventSched)) == NULL)
    { /* Error */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
        ret = RET_MEM_ERR_ALLOC;
    }

    if (ret == RET_SUCCEED)
    {
        DBA_SetDfltEntityFld(EventSched,  A_EventSched, inputFusStat); /* PMSTA-32292 - DLA - 180921 */

        /* Obtain the portfolio entity identifier */
        ret = DBA_GetDictId(Ptf, &ptfDictId) == TRUE ? RET_SUCCEED : RET_DBA_INFO_NODATA;
    }

    if((privateSrv=SYS_GetEnv("AAA_PRIVATE_SERVER_FOR_FUSION")) != NULL) /* For GUI users for 1 server */ /* DLA - PMSTA07062 - 080825 */
    {
        DBA_DYNFLD_STP sServerConnect = ALLOC_DYNST(S_ServConnect);
        DBA_DYNFLD_STP aServerConnect = ALLOC_DYNST(A_ServConnect);

        SET_CODE(sServerConnect, S_ServConnect_ServerName, privateSrv);
        ret = DBA_Get2 (ServConnect, UNUSED, S_ServConnect, sServerConnect,
                        A_ServConnect, &aServerConnect, UNUSED, nullptr, nullptr);

        SET_ID(inputFusStat, A_EventSched_ServerId,GET_ID(aServerConnect, A_ServConnect_Id));

        FREE_DYNST(sServerConnect, S_ServConnect);
        FREE_DYNST(aServerConnect, A_ServConnect);
    }
    else
    {
        DICT_ATTRIB_STP opAtt = DBA_GetAttributeBySqlName(ApplUser, "ud_default_fusion_server"); /* DLA - PMSTA07062 - 080821 */
        if (opAtt != NULL) /* DLA - PMSTA07062 - 080821 */
        {
            DBA_DYNFLD_STP sApplUserSt = ALLOC_DYNST(S_ApplUser);
            DBA_DYNFLD_STP aApplUserSt = ALLOC_DYNST(A_ApplUser);
            DBA_DYNFLD_STP sServerConnect = ALLOC_DYNST(S_ServConnect);
            DBA_DYNFLD_STP aServerConnect = ALLOC_DYNST(A_ServConnect);

            SET_SYSNAME(sApplUserSt, S_ApplUser_Cd, dbiConn.getDescription().getUser().c_str()); /* PMSTA-nuodb - LJE - 190411 */

            ret = DBA_Get2(ApplUser, UNUSED, S_ApplUser, sApplUserSt, A_ApplUser, &aApplUserSt, UNUSED, nullptr, nullptr);

            if (!IS_NULLFLD(aApplUserSt,opAtt->progN))
            {
                SET_STRING_MAXLEN(sServerConnect, S_ServConnect_ServerName, GET_CODE(aApplUserSt, opAtt->progN), GET_MAXCHARLEN(GET_FLD_DTP(sServerConnect, S_ServConnect_ServerName)));
                ret = DBA_Get2 (ServConnect, UNUSED, S_ServConnect, sServerConnect,
                                A_ServConnect, &aServerConnect, UNUSED, nullptr, nullptr);

                SET_ID(inputFusStat, A_EventSched_ServerId,GET_ID(aServerConnect, A_ServConnect_Id));
            }
            FREE_DYNST(sServerConnect, S_ServConnect);
            FREE_DYNST(aServerConnect, A_ServConnect);
            FREE_DYNST(sApplUserSt, S_ApplUser);
            FREE_DYNST(aApplUserSt, A_ApplUser);
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* Set fusion_stat fields */
        SET_DICT(inputFusStat, A_EventSched_EntityDictId, ptfDictId);                               /* REF8844 - LJE - 030327 */
        COPY_DYNFLD(inputFusStat, A_EventSched, A_EventSched_ObjId,     extOpStPtr, ExtOp, ExtOp_PtfId);
        SET_ID(inputFusStat, A_EventSched_OperId, OPE_GetOpIdFromExtOpPriorityOperation(extOpStPtr)); /* REF9978 - 041007 - EFE */

        DATETIME_T dbDate;
        DBA_GetDbDateOnServer(&dbDate,dbiConn);        
        SET_DATETIME(inputFusStat,  A_EventSched_CreationDate, dbDate);

        /*<REF10544-EFE 041007*/
        if ( IS_NULLFLD(extOpStPtr, ExtOp_AudModifDate) == false)
        {
            COPY_DYNFLD(inputFusStat, A_EventSched, A_EventSched_EventDate,    extOpStPtr, ExtOp, ExtOp_AudModifDate);  /* REF9301 - 040219 - PMO */
        }
        else
        {            
            SET_DATETIME(inputFusStat,  A_EventSched_EventDate,    *refDatePtr);
        }
        /*>REF10544-EFE 041007*/

        if (Delete == action)                                                               /* PMSTA-32291 - 130818 - PMO */
        {
            SET_ENUM(inputFusStat, A_EventSched_FusionEn, OpFusion_ToDelete);
        }
        else
        {
            SET_ENUM(inputFusStat, A_EventSched_FusionEn, OpFusion_Untreated);
        }

        SET_DATETIME(inputFusStat,  A_EventSched_FromDate,      *refDatePtr);
        SET_ENUM(inputFusStat,      A_EventSched_NatEn,         EventSchedNat_Fusion);
        SET_FLAG(inputFusStat,      A_EventSched_FusionScopeFlg,   fusionScopeFlg);            /* FPL-REF9069-030929 FALSE->fusionScopeFlg */
        SET_ENUM(inputFusStat,      A_EventSched_StatusEn,  EVENTSCHEDSTATUS_ENUM::EventSchedSts_Waiting);

        /* PMSTA-32288 - JBC  - 190214 */
        if(GEN_UseDispatcher() == false)
        {
            auto fusionPrioEn = static_cast<ENUM_T>(SYS_IsGuiMode() || IS_NULLFLD(extOpStPtr,ExtOp_FusionPrioEn) ? EventSchedFusPrio_Automatic : GET_ENUM(extOpStPtr,ExtOp_FusionPrioEn));
            SET_ENUM(inputFusStat, A_EventSched_FusionPrioEn,  fusionPrioEn); 
        }
        COPY_DYNFLD(inputFusStat,   A_EventSched, A_EventSched_ExtOrderTimestamp, extOpStPtr, ExtOp, ExtOp_TimeStampNew);   /* PMSTA-14364 - 230813 - PMO */

        /* Block mode processing ? */
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        { /* Yes */
            
            const int       curRec          = dbiConn.getConnStructPtr()->blockModeExt.curRec;
            const int       curStep         = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
            DBA_ACCESS_STP  extDataTab      = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab;
            int             extDataTabSize  = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize;
            int             extDataNbr      = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr;

            if (extDataTabSize == 0 || extDataNbr % extDataTabSize == 0)
            {
                extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                                          (size_t) extDataTabSize, (size_t) 10);     /* REF7264 - PMO */
                /* REF7560 - PMO Prevent memory leak and incorrect use of REALLOC */
                extDataTabSize += 10;
                dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
            }

            extDataTab[extDataNbr].action = Insert;
            extDataTab[extDataNbr].role   = dbaInsertRole;
            extDataTab[extDataNbr].object = EventSched;
            extDataTab[extDataNbr].entity = A_EventSched;
            extDataTab[extDataNbr].data   = inputFusStat;
            extDataNbr++;
            /* SME REF2894 */
            /* BEGIN DVP489 - 970604 - XMT : add one line for the cash portfolio, if needed */
            if (cashFlag == true && ret == RET_SUCCEED && isImportOptiMode == false) /* REF7560 - PMO */
            {
                /* Insert 1 fusion_stat record for fusion process */
                if ((inputFusStat2 = ALLOC_DYNST(A_EventSched)) == NULL)
                { /* Error */
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
                    FREE_DYNST(inputFusStat, A_EventSched);
                    ret = RET_MEM_ERR_ALLOC; /* REF7560 - PMO */
                }
                else
                { /* Ok */

                    COPY_DYNST(inputFusStat2, inputFusStat, A_EventSched);
                    SET_ID(inputFusStat2, A_EventSched_ObjId, GET_ID(extOpStPtr, ExtOp_CashPtfId));

                    if(GEN_UseDispatcher() == false)
                    {   /* set nature to linked */
                        SET_ENUM(inputFusStat2, A_EventSched_NatEn,  EventSchedNat_FusionCashPortfolio);
                        SET_ID(inputFusStat2, A_EventSched_ParentEventSchedId, GET_ID(inputFusStat,A_EventSched_Id));               
                    }

                    /* PMSTA-525 - 101006 - PMO */
                    switch (action)
                    {
                        case Update:
                            if (static_cast<OPSTAT_ENUM>(GET_ENUM(oldExtOpStPtr, ExtOp_StatusEn)) >= accountingStatus)
                            {
                                SET_FLAG(inputFusStat2, A_EventSched_FusionScopeFlg, TRUE);
                            }
                            break;

                        case Delete:
                            SET_FLAG(inputFusStat2, A_EventSched_FusionScopeFlg, TRUE);
                            break;

                        case Insert:
                        default:
                            break;
                    }

                    if (extDataNbr % extDataTabSize == 0)
                    {
                        extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                                                  (size_t) extDataTabSize, (size_t) 10);/* REF7264 - PMO */

                        extDataTabSize += 10;
                        /* REF7560 - PMO Prevent memory leak and incorrect use of REALLOC */
                        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
                    }

                    extDataTab[extDataNbr].action = Insert;
                    extDataTab[extDataNbr].role   = dbaInsertRole;
                    extDataTab[extDataNbr].object = EventSched;
                    extDataTab[extDataNbr].entity = A_EventSched;
                    extDataTab[extDataNbr].data   = inputFusStat2;
                    extDataNbr++;
                }
            }
            /* END DVP489 - 970604 - XMT */

            /* REF9208 - 030923 - PMO */
            if (ret == RET_SUCCEED && ptfCashChangeFlg == true && oldCashFlag == true && isImportOptiMode == false)
            {
                /* Insert 1 fusion_stat record for fusion process */
                if ((inputFusStat2 = ALLOC_DYNST(A_EventSched)) == NULL)
                { /* Error */
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
                    FREE_DYNST(inputFusStat, A_EventSched);
                    ret = RET_MEM_ERR_ALLOC; /* REF7560 - PMO */
                }
                else
                { /* Ok */

                    COPY_DYNST(inputFusStat2, inputFusStat, A_EventSched);
                    SET_ID(inputFusStat2, A_EventSched_ObjId, GET_ID(oldExtOpStPtr, ExtOp_CashPtfId));
                    SET_FLAG(inputFusStat2, A_EventSched_FusionScopeFlg, TRUE);

                    if(GEN_UseDispatcher() == false)
                    {   /* set nature to linked */
                        SET_ENUM(inputFusStat2, A_EventSched_NatEn,  EventSchedNat_FusionCashPortfolio);
                        SET_ID(inputFusStat2, A_EventSched_ParentEventSchedId, GET_ID(inputFusStat,A_EventSched_Id));
                    }

                    if (extDataNbr % extDataTabSize == 0)
                    {
                        extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                                                  (size_t) extDataTabSize, (size_t) 10);  /* REF7264 - PMO */

                        extDataTabSize += 10;
                        /* REF7560 - PMO Prevent memory leak and incorrect use of REALLOC */
                        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
                    }

                    extDataTab[extDataNbr].action = Insert;
                    extDataTab[extDataNbr].role   = dbaInsertRole;
                    extDataTab[extDataNbr].object = EventSched;
                    extDataTab[extDataNbr].entity = A_EventSched;
                    extDataTab[extDataNbr].data   = inputFusStat2;
                    extDataNbr++;
                }
            }

            if (ret == RET_SUCCEED && true == bUpdPtfTransToUnAcc)
            {
                /* PMSTA-9113 - 231209 - PMO
                 * We need to launch a fusion on the target portfolio
                 */
                /* Insert 1 fusion_stat record for fusion process */
                if ((inputFusStat2 = ALLOC_DYNST(A_EventSched)) == NULL)
                { /* Error */
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
                    FREE_DYNST(inputFusStat, A_EventSched);
                    ret = RET_MEM_ERR_ALLOC;
                }
                else
                { /* Ok */
                    COPY_DYNST(inputFusStat2, inputFusStat, A_EventSched);
                    SET_ID(inputFusStat2, A_EventSched_ObjId, GET_ID(oldExtOpStPtr, ExtOp_AdjPtfId));
                    SET_FLAG(inputFusStat2, A_EventSched_FusionScopeFlg, TRUE);

                    if(GEN_UseDispatcher() == false)
                    {   /* set nature to linked */
                        SET_ENUM(inputFusStat2, A_EventSched_NatEn,  EventSchedNat_FusionLinked);
                        SET_ID(inputFusStat2, A_EventSched_ParentEventSchedId, GET_ID(inputFusStat,A_EventSched_Id));
                    }

                    if (extDataNbr % extDataTabSize == 0)
                    {
                        extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                                  (size_t) extDataTabSize, (size_t) 10);

                        extDataTabSize += 10;
                        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
                    }

                    extDataTab[extDataNbr].action = Insert;
                    extDataTab[extDataNbr].role   = dbaInsertRole;
                    extDataTab[extDataNbr].object = EventSched;
                    extDataTab[extDataNbr].entity = A_EventSched;
                    extDataTab[extDataNbr].data   = inputFusStat2;
                    extDataNbr++;
                }
            }

            /* REF7560 - PMO */
            if (ret == RET_SUCCEED)
            {
                dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize = extDataTabSize;
                dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr     = extDataNbr;
            }

            /* No need to free inputFusStat (already freed or allocation transfered in block mode). REF8625 - 030113 - PMO */
            inputFusStat = NULL;

        }
        else
        { /* No */
          /* Insert record */
            ret = DBA_Insert2(EventSched,
                              dbaInsertRole,
                              A_EventSched,
                              inputFusStat,
                              DBA_SET_CONN | DBA_NO_CLOSE,
                              dbiConn);

            /* BEGIN DVP489 - 970604 - XMT : add one line for the cash portfolio, if needed */
            if (ret == RET_SUCCEED && cashFlag == true && isImportOptiMode == false)
            {   /* get parent  request */
                ID_T parentEventSchedId = GET_ID(inputFusStat,A_EventSched_Id);

                COPY_DYNFLD(inputFusStat, A_EventSched, A_EventSched_ObjId, extOpStPtr, ExtOp, ExtOp_CashPtfId);

                if(GEN_UseDispatcher() == false)
                {   /* set nature to linked */
                    SET_ENUM(inputFusStat, A_EventSched_NatEn,  EventSchedNat_FusionCashPortfolio);
                    SET_ID(inputFusStat, A_EventSched_ParentEventSchedId, parentEventSchedId);
                }
                /* PMSTA-525 - 101006 - PMO */
                switch (action)
                {
                    case Update:
                        if (static_cast<OPSTAT_ENUM> (GET_ENUM(oldExtOpStPtr, ExtOp_StatusEn)) >= accountingStatus)
                        {
                            SET_FLAG(inputFusStat, A_EventSched_FusionScopeFlg, TRUE);
                        }
                        break;

                    case Delete:
                        SET_FLAG(inputFusStat, A_EventSched_FusionScopeFlg, TRUE);
                        break;

                    case Insert:
                    default:
                        break;
                }

                ret = DBA_Insert2(EventSched,
                                  dbaInsertRole,
                                  A_EventSched,
                                  inputFusStat,
                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                  dbiConn);
            }   /* End if */

            /* REF9208 - 030923 - PMO */
            if (ret == RET_SUCCEED && ptfCashChangeFlg == true && oldCashFlag == true && isImportOptiMode == false)
            {
                /* get parent request */
                ID_T parentEventSchedId = GET_ID(inputFusStat,A_EventSched_Id);

                /* Set the id of the old portfolio cash. Old portfolio need a fusion all */
                COPY_DYNFLD(inputFusStat, A_EventSched, A_EventSched_ObjId, oldExtOpStPtr, ExtOp, ExtOp_CashPtfId);
                SET_FLAG(inputFusStat,    A_EventSched_FusionScopeFlg, TRUE);

                if(GEN_UseDispatcher() == false)
                {   /* set nature to linked */
                    SET_ENUM(inputFusStat, A_EventSched_NatEn,  EventSchedNat_FusionCashPortfolio);
                    SET_ID(inputFusStat, A_EventSched_ParentEventSchedId, parentEventSchedId);
                }

                ret = DBA_Insert2(EventSched,
                                  dbaInsertRole,
                                  A_EventSched,
                                  inputFusStat,
                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                  dbiConn);
            }   /* End if */

            if (ret == RET_SUCCEED && true == bUpdPtfTransToUnAcc)
            {
                /* PMSTA-9113 - 231209 - PMO We need to launch a fusion on the target portfolio */
                /* get parent id */
                ID_T parentEventSchedId = GET_ID(inputFusStat,A_EventSched_Id);
                /* Set the id of the old target portfolio. Old portfolio need a fusion all */
                COPY_DYNFLD(inputFusStat, A_EventSched, A_EventSched_ObjId, oldExtOpStPtr, ExtOp, ExtOp_AdjPtfId);
                SET_FLAG(inputFusStat,    A_EventSched_FusionScopeFlg, TRUE);

                 if(GEN_UseDispatcher() == false)
                {    /* set nature to linked */
                     SET_ENUM(inputFusStat, A_EventSched_NatEn,  EventSchedNat_FusionLinked);
                     SET_ID(inputFusStat, A_EventSched_ParentEventSchedId, parentEventSchedId);
                }
                /* Insert record */
                ret = DBA_Insert2(EventSched,
                                  dbaInsertRole,
                                  A_EventSched,
                                  inputFusStat,
                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                  dbiConn);
            }

        }   /* End if */

    }   /* End if */

    if (ret == RET_SUCCEED)
    {
        DBA_StockPortfolioToFuse(GET_ID(extOpStPtr, ExtOp_PtfId), autoFusStock);
        if (cashFlag == true)
        {
            DBA_StockPortfolioToFuse(GET_ID(extOpStPtr, ExtOp_CashPtfId), autoFusStock);
        }

        /* REF9208 - 030923 - PMO */
        if (ptfCashChangeFlg == true && oldCashFlag == true)
        {
            DBA_StockPortfolioToFuse(GET_ID(oldExtOpStPtr, ExtOp_CashPtfId), autoFusStock);
        }

        /* PMSTA-9113 - 231209 - PMO */
        if (true == bUpdPtfTransToUnAcc)
        {
            DBA_StockPortfolioToFuse(GET_ID(oldExtOpStPtr, ExtOp_AdjPtfId), autoFusStock);
        }
    }

    /* Memory Leak  REF8625 - 030113 - PMO */
    if (NULL != inputFusStat)
    {
        FREE_DYNST(inputFusStat, A_EventSched);
    }


    return ret;
}


/************************************************************************
**
** Function    : DBA_DeleteEventScheduler
**
** Description : Delete  events in event scheduler according to the following key:
**                   Entity_dict_id
**                   Object_id
**                   Nature_e
**
**
** Arguments   : operation_id
**		         connectNo      connection number
**		         msgStructPtr   message
**
** Return      : RET_CODE
**               RET_DBA_ERR_INVDATA
**               RET_MEM_ERR_ALLOC
**
** Creation    : REF10567 - 040907 - EFE : Better management of event_scheduler
**
************************************************************************/
STATIC RET_CODE DBA_DeleteEventScheduler(const DBA_DYNFLD_STP extOpStPtr, DbiConnection &dbiConn)
{
    DICT_T          ptfEntDictId  = 0;
    const ID_T      operation_id  = OPE_GetOpIdFromExtOpPriorityOperation(extOpStPtr);
    DBA_DYNFLD_STP  eventSchedPtr = ALLOC_DYNST(S_EventSched);
    RET_CODE        ret           = RET_SUCCEED;

    if (nullptr == eventSchedPtr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    DBA_GetDictId(Ptf, &ptfEntDictId);
    SET_ID(eventSchedPtr, S_EventSched_OperId, operation_id             );
    SET_FLAG(eventSchedPtr, S_EventSched_FusionScopeFlg, FALSE           ); /* on ne supprime que les fusion_new */
    SET_ENUM(eventSchedPtr, S_EventSched_NatEn,  EventSchedNat_Fusion );


    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    { /* Yes */
        const int       curRec         = dbiConn.getConnStructPtr()->blockModeExt.curRec;
        const int       curStep        = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
        DBA_ACCESS_STP  extDataTab     = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab;
        int             extDataTabSize = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize;
        int             extDataNbr     = dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr;

        if (extDataTabSize == 0 || extDataNbr % extDataTabSize == 0)
        {
            extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                      (size_t) extDataTabSize, (size_t) 10);

            extDataTabSize += 10;
            dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
        }

        extDataTab[extDataNbr].action = Delete;
        extDataTab[extDataNbr].role   = DBA_ROLE_DELETE_BY_OP;      /*  FPL-PMSTA09385-100223 replace UNUSED    */
        extDataTab[extDataNbr].object = EventSched;
        extDataTab[extDataNbr].entity = S_EventSched;
        extDataTab[extDataNbr].data   = eventSchedPtr;
        extDataNbr++;

        /* DLA - PMSTA09304 - 100205 */
        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize = extDataTabSize;
        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr     = extDataNbr;
        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab     = extDataTab;

    }
    else
    {                                                           /*...no */
        ret = DBA_Delete2( EventSched, DBA_ROLE_DELETE_BY_OP,   /*REF10603-EFE-041103*/
                          S_EventSched, eventSchedPtr,
                          DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR,
                          dbiConn, nullptr);
        if (NULL != eventSchedPtr)
        {
            FREE_DYNST(eventSchedPtr, S_EventSched);
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DBA_ConvertExtOp2S_Op()
**
**  Description :  Convert an ExtOp to sOp
**                 - Allocate memory for dynFldsOp if needed (if NULL)
**                 - Copy the id field
**
**  Arguments   :  dynFldsOp    Pointer to the short operation
**                              If the pointer is null the memory is allocated
**                 dynFldExtPos Pointer to the source of extPos
**                 extOp_Id     Can be ExtOp_DbId or ExtOp_OpId
**
**  Return      :  RET_SUCCEED              if ok
**                 RET_MEM_ERR_ALLOC        error in memory allocations
**
**  Creation    :  REF7560 - 020712 - PMO : Order Management Entity light project: database infrastructure
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_ConvertExtOp2S_Op(DBA_DYNFLD_STP *     dynFldsOp,
                               const DBA_DYNFLD_STP dynFldExtOp,
                               const int extOp_Id)
{
    RET_CODE ret = RET_SUCCEED;

    /* Need to allocate memory ? */
    if (NULL == *dynFldsOp)
    { /* Yes */

        /* Allocate memory */
        if ((*dynFldsOp = ALLOC_DYNST(S_Op)) == NULL)
        { /* Error */
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "S_Op");
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* Set key */
        COPY_DYNFLD(*dynFldsOp, S_Op, S_Op_Id, dynFldExtOp, ExtOp, extOp_Id);

    }

    return ret;
}




/************************************************************************
**
**  Function    :  DBA_ConvertExtOp2Adm_Arg()
**
**  Description :  Convert an ExtOp to Adm_Arg
**                 - Allocate memory for dynFlds if need (if NULL)
**                 - Copy the id field
**                 - Copy the timestamp field
**
**  Arguments   :  admArgStp    Pointer to the Adm_Arg
**                              If the pointer is null the memory is allocated
**                 dynFldExtPos Pointer to the source of extPos
**                 extOp_Id     Can be ExtOp_DbId or ExtOp_OpId
**
**  Return      :  RET_SUCCEED              if ok
**                 RET_MEM_ERR_ALLOC        error in memory allocations
**
**  Creation    :  REF7560 - 020712 - PMO : Order Management Entity light project: database infrastructure
**
**  Last modif. :  REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**
*************************************************************************/
RET_CODE DBA_ConvertExtOp2Adm_Arg(DBA_DYNFLD_STP *     admArgStp,
                                  const DBA_DYNFLD_STP dynFldExtOp,
                                  const int extOp_Id)
{
    RET_CODE ret = RET_SUCCEED;

    /* Need to allocate memory ? */
    if (NULL == *admArgStp)
    { /* Yes */

        /* Allocate memory */
        if ((*admArgStp = ALLOC_DYNST(Adm_Arg)) == NULL)
        { /* Error */
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "Adm_Arg");
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* Set key */
        COPY_DYNFLD(*admArgStp, Adm_Arg, Adm_Arg_Id,        dynFldExtOp, ExtOp, extOp_Id);
        COPY_DYNFLD(*admArgStp, Adm_Arg, Adm_Arg_TimeStamp, dynFldExtOp, ExtOp, ExtOp_TimeStamp);
    }

    return ret;
}




/************************************************************************
**
** Function    : DBA_BeginDateEndDateExtOpProcessing
**
**
** Description : - Set the begin date with the reference date
**               - Set the default end date according to this rule
**                 - if Total execution no change in the end date
**                 - if no Total execution default is MAGIC_END_DATE
**                 - if end date remained NULL it's set to MAGIC_END_DATE
**
** Arguments   : extOpStPtr         Pointer to the structure where to set date
**               refDate            Reference date. Usually the fusion date rule
**               action             Must be Insert, Update or Delete
**               accountingStatus   Level of the current accounting status
**
** Return      : None
**
** Creation    : REF7560 - 020530 - PMO : Order Management Entity light project: database infrastructure. Huge modifications
**
** Last Modif  : REF8625 - TEB - 030822 : Problem with copy operation for end date
**               REF8772 - TEB - 030822 : Execution insert mode not working well
**               REF8896 - TEB - 030822 : Single operation with order_limit_d<>
**                                        and with status >= ACCOUNTING_STATUS loses
**                                        its position after the order_limit_d
**
************************************************************************/
STATIC void DBA_BeginDateEndDateExtOpProcessing(DBA_DYNFLD_STP extOpStPtr,
                                                const DATETIME_T refDate,
                                                const DBA_ACTION_ENUM action,
                                                const OPSTAT_ENUM accountingStatus)
{

    assert(action == Update || action == Delete || action == Insert);

    /* Set the begin date with the date defined by fus date rule */
    SET_DATETIME(extOpStPtr, ExtOp_BeginDate, refDate);

    /* Processing of the end date depends of the nature of execution */
    switch (static_cast<EXECNAT_ENUM>(GET_ENUM(extOpStPtr, ExtOp_ExecOpNatEn)))
    {
        case ExecNat_TotalExec:
        case ExecNat_PartExec:
        case ExecNat_TotalExecutedfromTotalExecution:
        case ExecNat_TotalExecutedfromPartExecution:
        case ExecNat_PartExecutedfromTotalExecution:
        case ExecNat_PartExecutedfromPartExecution:
            /* No code */
            break;

        case ExecNat_None:
        case ExecNat_Total:
        case ExecNat_Partial:
        case ExecNat_PartUpdMode:
        case ExecNat_TotalUpdMode:
            if (true == IS_NULLFLD(extOpStPtr, ExtOp_OrderLimitDate))
            { /* No order limit date */

                switch (action)
                {

                    case Update:
                    case Delete:
                    case Insert:
                        /* Set the end date with the magic date (31/12/9999) */
                        SET_DATE(extOpStPtr, ExtOp_EndDate, MAGIC_END_DATE);
                        break;

                    default:
                        /* Not possible case */
                        assert(2 == 3);
                        break;

                } /* End switch */

            }
            else
            { /* Order limit date exist */

                /* Test if accounting status / REF8896 - TEB - 030822  */
                if (static_cast<OPSTAT_ENUM> (GET_ENUM(extOpStPtr, ExtOp_StatusEn)) >= accountingStatus)
                { /* Yes */
                  /* Set the end date with the magic date (31/12/9999) */
                    SET_DATE(extOpStPtr, ExtOp_EndDate, MAGIC_END_DATE);
                }
                else
                { /* No */
                    DATETIME_T orderDate;

                    /* Obtain the order date limit and add 1 day */
                    orderDate = GET_DATETIME(extOpStPtr, ExtOp_OrderLimitDate);
                    SET_DATE(extOpStPtr, ExtOp_EndDate, DATE_Move(orderDate.date, 1, Day));
                }   /* End if */

            }       /* End if */
            break;
    } /* End switch */

    /* Test if endDate is null REF8625 - TEB - 030822 */
    if (IS_NULLFLD(extOpStPtr, ExtOp_EndDate) == true)
    { /* Yes */

        /* endDate is mandatory for the database */

        /* Set the end date with the magic date (31/12/9999) */
        SET_DATE(extOpStPtr, ExtOp_EndDate, MAGIC_END_DATE);
    }

}


/************************************************************************
**
** Function    : DBA_IntExistInString
**
** Description : Test if a number exist in a string what can contain some
**               positive numbers without sign
**               Unknown character is ignored
**               The separator is ;
**               1 exist in "12"    -> FALSE
**               1 exist in "1;2;3" -> TRUE
**
** Arguments   : number     Number to search
**               stringPtr  String what contain numbers separated
**
** Return      : TRUE   The number exist in the string
**               FALSE  The number don't exist in the string
**
** Creation    : REF7560 - 020530 - PMO : Order Management Entity light project: database infrastructure.
**
** Last Modif  :
**
************************************************************************/
STATIC FLAG_T DBA_IntExistInString(const int number, const char * stringPtr)
{
    char     numberStr[32];     /* Number to test       */
    numberStr[0] = 0;

    FLAG_T      ret         = FALSE;
    unsigned    numberIdx   = 0;

    /* Browse the string */
    while (*stringPtr != 0)
    {
        /* Test if number. -1 is for the zero of end string */
        if (0 != isdigit(static_cast<char unsigned>(*stringPtr)) && numberIdx < (sizeof(numberStr) - 1) )
        { /* Number */
          /* Copy the character number */
            numberStr[numberIdx++] = *stringPtr;
        }
        else
        { /* Not a number. Or too big */

            /* Test if it's the delimiter */
            if (static_cast<char unsigned>(*stringPtr) == ';')
            { /* Yes */

                /* Set the end character */
                numberStr[numberIdx] = 0;
                numberIdx = 0;

                /* Same number */
                if (atoi(numberStr) == number)
                { /* Yes */

                    /* Return value */
                    ret = TRUE;

                    /* Stop the loop */
                    break;
                }
            }
            else
            { /* No */
              /* Character ignored */
            }
        } /* End if */

        /* Next character */
        stringPtr++;

    } /* End while */

    /* Test if one or last number */
    if (numberIdx > 0)
    { /* Yes */
      /* Set the end character */
        numberStr[numberIdx] = 0;

        /* Same number */
        if (atoi(numberStr) == number)
        { /* Yes */

            /* Return value */
            ret = TRUE;
        }
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_CheckExtOrder
**
** Description : Check the extOp
**               Convert the extOp in positions and operation
**
** Arguments   : extopSt        extended operation to check
**               sPtf           portfolio link to operation
**		         msgStructPtr   message to be filled
**
** Return      : RET_CODE
**               others
**
** Creation    : REF7560 - 020530 - PMO : Order Management Entity light project: database infrastructure. Huge modifications
**
** Last Modif  :
************************************************************************/
STATIC RET_CODE DBA_CheckExtOrder(DBA_DYNFLD_STP        extOpSt,
                                  DBA_DYNFLD_STP        sPtf,
                                  DBA_DYNFLD_STP *      ppsTab,
                                  int                   ppsNb,
                                  DbiConnection        &dbiConn,
                                  bool *                fusionAll)
{
    RET_CODE            ret;                        /* Return value                                     */
    FLAG_T              cashFlag        = FALSE;    /* If a cash has been done for a given operation    */
    DBA_DYNFLD_STP      operOutputPtr   = NULL;     /* Operation                                        */
    DBA_DYNFLD_STP *    extPosOutputTab = NULL;     /* Array of extpos                                  */
    int                 extPosOutputNb  = 0;        /* Number of entry in extPosOutputTab               */

    /* PMSTA-25573 - CHU - 170505 */
    if (DBA_IsRejectedOrder(extOpSt) == TRUE)
    {
        return RET_SUCCEED;
    }

    /* Convert extended operation into 1 operation record and n extended positions records */
    ret = OPE_ExtOpToOpExtPos(extOpSt,
                              GET_OPNAT(extOpSt, ExtOp_NatureEn),
                              ZERO_ID,
                              FusDateRule_None,
                              S_Ptf,
                              sPtf,
                              TRUE, /* genPPSExtpos */
                              ppsTab,
                              ppsNb,
                              NullDynSt,
                              NULL,
                              &operOutputPtr,
                              &extPosOutputTab,
                              &extPosOutputNb,
                              dbiConn.getId(),
                              DBA_SET_CONN | DBA_NO_CLOSE,
                              &cashFlag,
                              FALSE);  /* PMSTA13471 - DDV - 120131 */

	if (RET_SUCCEED == ret && NULL != extPosOutputTab)
	{
		/* Test if a fusion all is needed */
		for (int extPosOutputIdx = 0; extPosOutputIdx < extPosOutputNb; ++extPosOutputIdx) {

			if (true == (*fusionAll = FUS_IsFusionAllNeeded(extPosOutputTab[extPosOutputIdx]))) {
				/* Yes , Stop the search */
				break;
			}
		}

		(void)DBA_FreeDynStTab(extPosOutputTab, extPosOutputNb, ExtPos);
	}

	/* Free allocated memory */
	FREE_DYNST(operOutputPtr, A_Op);

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_MultiAccessUpdateExecution()
**
**  Description :   Update execution in multi-access mode.
**                  The growth of the multi-access is managed
**
**  Arguments   :   aExecution    Arguments used to delete the notepad
**                  connectNo   Connection number
**
**  Return      :
**          RET_SUCCEED              if ok
**          RET_MEM_ERR_ALLOC        error in memory allocations
**
**  Creation    :  REF7560 - 020918 - PMO : Order Management Entity light project: database infrastructure
**
**  Last modif. :  REF10507 - 040802 - PMO : You get a fusion failed after having deleted/updated an accounted operation
**
*************************************************************************/
static RET_CODE DBA_MultiAccessUpdateExecution(const DBA_DYNFLD_STP aExecution, DbiConnection &dbiConn)
{
    RET_CODE       ret; /* Return value */
    DBA_ACCESS_STP updateOp;
    int            curRec;
    int            curStep;

    /* Growth the area if need */
    ret = DBA_BlockModeNewStep(dbiConn);

    if (ret == RET_SUCCEED)
    {
        curRec  = dbiConn.getConnStructPtr()->blockModeExt.curRec;
        curStep = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

        updateOp               = & dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].insOp;
        updateOp->action       = Update;
        updateOp->role         = DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS;
        updateOp->object       = ExecutionEnt;
        updateOp->entity       = A_Execution;   /* REF10507 - 040802 - PMO */
        updateOp->data         = aExecution;    /* REF10507 - 040802 - PMO */
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_NeedToOpenTransaction
**
** Description : Open a transaction if need.
**               The transaction is opened only if they are no transaction open
**               and the block mode is not actived
**
** Arguments   : transactionOpen    Flag is set to TRUE if a transaction is opened
**               dbiConn            Connection
**
** Return      : RET_CODE
**
** Creation    : REF8116 - 021023 - PMO : Regression on accounting operations :  the ext_order_id is lost
**
** Last Modif  : PMSTA-32291 - 130818 - PMO : Review fusion_e management everywhere
**
************************************************************************/
static RET_CODE DBA_NeedToOpenTransaction(bool & transactionOpen, DbiConnection &dbiConn)
{
    RET_CODE ret    = RET_SUCCEED;
    transactionOpen = false;

    /* Block mode disable and no transaction is opened */
    if (dbiConn.getConnStructPtr()->blockMode == FALSE && dbiConn.isInTransaction() == false)
    { /* Block mode disable and no transaction is opened */

        /* Open transaction */
        ret = dbiConn.beginTransaction();

        if (ret == RET_SUCCEED) /* PMSTA-32291 - 130818 - PMO */
        { /* Ok */
            transactionOpen = true;
        }
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_UpdateIfNeedExecution
**
** Description : Update attached execution if need
**
** Arguments   : action         Action to perform: Delete or Update
**               extopSt        Extended operation to Delete or Update
**               oldExtOpSt     != NULL if action == Update
**               localTranFlg   Pointer to the flag if a transaction as been opened.
**                              If NULL, no attempt to open a transaction
**               connectNo      Connection number
**		         msgStructPtr   Message
**
** Return      :
**
** Creation    : REF8116 - 021023 - PMO : Regression on accounting operations :  the ext_order_id is lost
**               REF11344 - 050808 - EFE  add a parameter : accountef_f : it is now updated in all cases
**                                       ( put to FALSE when ins/upd/del an operation via the gui or import , and
**                                         put to TRUE when the operation is fusionned )
**
** Last Modif  :
**
************************************************************************/
STATIC RET_CODE DBA_UpdateIfNeedExecution( const DBA_DYNFLD_STP     extOpSt,
                                           const int                accountedFlg, /*REF11344-EFE-060105*/
                                           bool &                   localTranFlg,
                                           DbiConnection           &dbiConn)
{
    RET_CODE ret                = RET_SUCCEED;  /* Return value of this function */
    FLAG_T   updateExecutionFlg;                /* Need to update execution      */


    /*<REF11344-EFE-060105*/
    if (IS_NULLFLD(extOpSt, ExtOp_ExtOrderId) == false)
    { /* Update only if a id is present */
        updateExecutionFlg = TRUE;
    }
    else
    { /* Id missing, don't update */
        updateExecutionFlg = FALSE;
    }
    /*>REF11344-EFE-060105*/

    /* Need to update execution */
    if (updateExecutionFlg == TRUE)
    {                               /* Yes */

        DBA_DYNFLD_STP aExecution;  /* Fields for updating execution */

        /* Memory allocation for extended operation record */
        if ((aExecution = ALLOC_DYNST(A_Execution)) == NULL)
        { /* Error */
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "A_Execution");
        }
        else
        { /* Ok */
          /* Copy fields for the update */
            COPY_DYNFLD(aExecution, A_Execution, A_Execution_ExtOrderId,           extOpSt, ExtOp, ExtOp_ExtOrderId);
            COPY_DYNFLD(aExecution, A_Execution, A_Execution_ExecutionSetCriteria, extOpSt, ExtOp, ExtOp_ExecSetCriteria);
            SET_FLAG(aExecution, A_Execution_AccountedFlg, accountedFlg ); /* REF11344-EFE-050808 */

            /* Open a transaction if need */
            ret = DBA_NeedToOpenTransaction(localTranFlg, dbiConn);
        }

        if (ret == RET_SUCCEED)
        {
            /* Block mode processing ? */
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            { /* Yes */
              /* Update execution */
                ret = DBA_MultiAccessUpdateExecution(aExecution, dbiConn);

                if (ret == RET_SUCCEED)
                { /* Ok */
                  /* Prevent double free */
                    aExecution = NULL;
                }
            }
            else
            { /* No */
              /* Update execution */
                ret = DBA_Update2(ExecutionEnt,
                                  DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS,
                                  A_Execution,
                                  aExecution,
                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                  dbiConn);
            }
        }

        if (aExecution != NULL)
        {
            FREE_DYNST(aExecution, A_Execution);
        }

    }

    return ret;
}

enum class ExtOrderAction
{
    Init,   // Initialization
    Insert, // Insert in ext order
    Update, // Update in ext order
    Delete
};


/************************************************************************
**
** Function    : DBA_PerformInsUpdDelExtOp
**
** Description : perform delete, insert or update of ExtOp
**               1 - Check Closing Security
**               2 - Delete:
**                    delete operation
**                   or
**                   Insert:
**                    Transform ExtOp to Op and position(s).
**                    Generate operation code
**                    Retrieve operation id (no in block mode)
**                   Update : update operation
**
**               4 - Synthetic admin
**               3 - Audit
**
**               For update action, the field ExtOp_AudModifDate must contain the
**               value of the field ExtOp_LastModifDate
**
** Arguments   : action         action to perform: Delete  or Insert or Update
**               extopSt        extended operation to insert or delete or update
**               oldExtOpSt     != NULL if action == Update
**               sPtf           portfolio link to operation
**               sPtfPosSet     pps
**               nbPps          number of pps in portfolio:
**		         connectNo      connection number
**		         newStep        alloc a new step in block mode
**               codeOp         return code operation for an insert (not mandatory)
**		         msgStructPtr   message
**               autoFusStock
**
** Return      : RET_CODE
**               RET_DBA_ERR_INVDATA
**               RET_MEM_ERR_ALLOC
**               codeOp
**
** Creation    : sme (Wednesday December 08 1999)
**
** Last Modif  : GRD - 000322 - Ref.: REF4204: Subscription.
**               GRD - 010202 - Ref.: REF5644.
**               GRD - 010323 - Ref.: REF5844.
**               GRD - 010409 - Ref.: REF5037.
**               REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**               REF7560 - 020530 - PMO : Order Management Entity light project: database infrastructure. Huge modifications
**               REF7395 & REF7594 - YST - 020624
**               REF8116 - 021023 - PMO : Regression on accounting operations :  the ext_order_id is lost
**               REF8426 - 021112 - PMO : Wrong message is called
**               REF8625 - 030113 - PMO : Problem with copy operation
**               REF9167 - 030603 - PMO : Audit trail difference between 3.50 and R4
**               REF9033 - TEB - 030815 : GUI race condition not handled correctly
**               REF9333 - TEB - 030825 : bad coding
**               FPL-REF9069-030929     : When you modify an operation (example the portfolio)after automatic
**                                        fusion the operation still exist in the valuation
**               FPL-REF8803-030929     : It's possible to modify the same order from two op-list view
**               REF8996 - TEB - 031001 : Modifying the status from "accounted" to "order" doesn't generate an event
**                                        in Event_sched for synth_admin or perf_attrib
**               REF9449 - TEB - 031006 : When updating an order from status under to ACCOUNTING status
**                                        to status over, executions disappear
**               REF9050 - 031002 - PMO : Insert/Update unbalanced orders
**               REF9705 - 031127 - PMO : Modify Business Key (MBK) does not work anymore as before
**               REF9499 - 031216 - PMO : Probleme de delete et de creation d'operations non fusionnees
**               REF9870 - 040201 - PMO : When modifying operation after using Archive the quantity changes
**               REF9423 - 040216 - PMO : Race condition when deleting ext_order
**               REF9301 - 040219 - PMO : this message appear sometimes after update field on child and block order:
**                                        The row (id=1234567) into the table ext_order has been modified by
**                                        someone/something else in the meantime
**               REF10517 - 040805 - EFE  duplicate key on ext_order when modifying an accounted
**                                        operation not fusionned yet
**               REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**               REF10469 - 040721 - PMO : Impossible to save a session generated by Reconcile Strategy if you have Constraint Breach records (problem with DBA_FamilyOrder)
**               REF10181 - 041122 - PMO : Bizard reverse code generated when you specified it in the import file
**               REF10421 - 041125 - EFE : timeStamp management take care that the time stamp of extOp is newer
**                                         than the one from oldExtOp when not null, if it is not the case ,
**                                         we temporary change the extOrderAction for case 21 to ExtOrderAction::Insert
**               REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**               REF10826 - 041210 - EFE  :Add a new update case when doing a double update on ACC op,
**                                         without fusion between the 2, descending the status first , then putting it as ACC.
**               REF11344 - 050808 - EFE  add call to DBA_UpdateIfNeedExecution in all cases
**                                        because the management of the flag accounted_f ( execution ) is done here
**                                        and no longer in ui_ext_order_trg
**               PMSTA4367 - 071022 - BSA :Error when updating an operation
**               PMSTA-7310 - 020309 - PMO : Unrecoverable Error in TripleA import trying to update the code of ext_operation
**               PMSTA-8306 - 100111 - PMO : Avoid the fusion to load data two times
**               PMSTA-16340 - 191213 - PMO : Communication records in the communication entity are not deleted after the related operation is deleted
**               PMSTA-21938 - 160216 - PMO : TTI Handle Sequencing - TAP Impact
**               PMSTA-27222 - 080517 - PMO : Fusion process is failing during every day batch
**               PMSTA-32291 - 130818 - PMO : Review fusion_e management everywhere
**               PMSTA-34656 - 060219 - PMO : The delete of an updated accounted operation untreated by the fusion is badly treated
**               PMSTA-34674 - 070219 - PMO : The second delete or update of an updated accounted operation untreated by the fusion is badly treated
**
************************************************************************/
RET_CODE _DBA_PerformInsUpdDelExtOp(const DBA_ACTION_ENUM           action,
                                    DBA_DYNFLD_STP                  extOpSt,
                                    DBA_DYNFLD_STP                  oldExtOpSt,
                                    DBA_DYNFLD_STP                  sPtf,
                                    DBA_DYNFLD_STP *                ppsTab,
                                    int                             ppsNb,
                                    DbiConnection                  &dbiConn,
                                    const FLAG_T                    newStep,
                                    CODE_T                          codeOp,
                                    struct AutomaticFusionStock *   autoFusStock)
{
    DATETIME_T              refDate;
    RET_CODE                ret                 = RET_SUCCEED;/* Return value of this function */
    RET_CODE                retCode             = RET_SUCCEED;
    FUSDATERULE_ENUM        fusionDateRule      = FusDateRule_None;
    OPSTAT_ENUM             syntheticMaxStatus  = OpStat_None;
    OPSTAT_ENUM             syntheticMinStatus  = OpStat_None;
    OPSTAT_ENUM             perfMaxStatus       = OpStat_None;              /* REF9883 - RAK - 040211 */
    OPSTAT_ENUM             perfMinStatus       = OpStat_None;              /* REF9883 - RAK - 040211 */
    OPSTAT_ENUM             perfDefMaxStatus    = OpStat_None;              /* REF9883 - RAK - 040211 */
    OPSTAT_ENUM             perfDefMinStatus    = OpStat_None;              /* REF9883 - RAK - 040211 */
    DBA_DYNFLD_STP *        outSubscriptionTab  = NULL;                     /* REF4204 */
    DBA_DYNFLD_STP          inSubscriptionSt    = NULL;                     /* REF4204 */
    DBA_DYNFLD_STP          inAuditData         = NULL;                     /* REF4204 */
    int                     outSubscriptionNbr  = 0;                        /* REF4204 */
    FLAG_T                  localEventFlg       = FALSE;                    /* REF4204 */
    FLAG_T                  localAuditFlg       = FALSE;                    /* REF4204 */
    PERFDATA_FREEZRULE_ENUM perfDataFreezRule = PerfDataFreezRule_Standard; /* REF7594 - YST - 020624 */
    DBA_DYNFLD_ST           saveLastUserId;                                 /* Save and restore of the last user Id DLA  -  REF9270 - 030701 */
    ID_T                    lastUserId          = ZERO_ID;                  /* DLA  -  REF9270 - 030701 */
    FLAG_T                  badTimeStampFlg     = FALSE;                    /* REF10421-EFE-041125 */
    bool                    fusionAll           = false;                    /* PMSTA-8306 - 100111 - PMO */
    ExtOpLog                extOp(extOpSt);
    ExtOpLog                oldExtOp(oldExtOpSt);

    /* Integrity testing */
    assert(action == Update || action == Delete || action == Insert);

    /*
     * Initialization
     */
    memset(&refDate, 0, sizeof(refDate));
    memset(&saveLastUserId, 0, sizeof(saveLastUserId));
    OPSTAT_ENUM accountingStatus   = OpStat_None;                   /* Level of the current accounting status */
    FLAG_T      autoCodeGenFlag    = TRUE; /*PMSTA-28686 - Silpakal - 190227*/
    FLAG_T      autoAccCodeGenFlag = TRUE; /*PMSTA-28686 - Silpakal - 190227*/

    /*
     *  Save changed value
     */
    DBA_DYNFLD_ST saveOperationId = extOpSt[ExtOp_OpId];    /* Save and restore of the operation_id REF7560 PMO */

    /*
     *  Field cleanup
     */
    /* Test if negative operation_id */
    if (GET_ID(extOpSt, ExtOp_OpId) < 0)
    { /* Yes */
      /* Set the field to NULL */
        SET_NULL_ID(extOpSt, ExtOp_OpId);
    }

    /* REF10469 - 040721 - PMO */
    /* Set the field to NULL */
    SET_NULL_ID(extOpSt, ExtOp_DraftOrderId);

	/* PMSTA-13786 - TGU - 120414 - Lets have DB Date */
	/* PMSTA-14045 - TGU - 120606 -(Code report PMSTA-14014) removed the DBA_GetDbDate .. not necessary here */

    /* REF10256 - 040608- PMO */
    /* Common code for Insert and Update */
    switch (action)
    {
        case Update:
        case Insert:
            /* If error. Insert or Update fails */
            ret = DBA_DefFusDateRuleForOpAcctValueInsUpdOp(sPtf, extOpSt, dbiConn);
            break;    /* BSA - REF11693 - 060202 */

        case Delete:
            /* fall through */
        default:
            ret = RET_SUCCEED;
            break;

    } /* End switch */
    if (ret == RET_SUCCEED)
    {
        /* Load fusion date rule */
        fusionDateRule = DBA_GetFusDateRule(sPtf,
                                            S_Ptf_FusionDateRuleEn,
                                            S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                            NULL,
                                            0,
                                            extOpSt,
                                            ExtOp);

        /*
         * Subscription.
         */

        if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, (DBA_GetDictEntityStSafe(EOp))->entDictId);
        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, static_cast<ENUM_T>((action == Insert) ? Subscription_Action_Insert :
                                                                                (action == Update) ? Subscription_Action_Update :
                                                                                                     Subscription_Action_Delete));

        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

        DBA_Select2(Subscription,
                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                    A_Subscription,
                    inSubscriptionSt,
                    A_Subscription,
                    &outSubscriptionTab,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    UNUSED,
                    &outSubscriptionNbr,
                    dbiConn);

        FREE_DYNST(inSubscriptionSt, A_Subscription);

        /* REF7560 - PMO */
        if (outSubscriptionNbr > 0)
        {
            localEventFlg = TRUE;

            /*
             * In the case no audit has been requested, we should behave the same way
             * if a 'Delete' action is being requested for 'event'.
             * GRD - 010323 - REF5844.
             */
            if (action == Delete || action == Update)   /* REF5844 REF7560 - PMO */
            {
                DBA_PROC_STP currModifProcLstStp = nullptr;
                bool isCurrModif = false;
                if (action == Update 
                    && SYS_GetRpcName().empty() == false
                    && (currModifProcLstStp = AaaMetaDict::getObjProcLstStp(CurrModif)) != nullptr)
                {   
                    for (int idx = 0; currModifProcLstStp[idx].action != NullAction; idx++)
                    {
                        if(SYS_GetRpcName() == currModifProcLstStp[idx].procName)
                        {
                            isCurrModif = true;
                            break;
                        }
                    }
                }

				if (isCurrModif)
				{
					DBA_DYNFLD_STP      newExtOpStp;
					if ((newExtOpStp = ALLOC_DYNST(ExtOp)) == NULL)
					{
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}
					COPY_DYNST(newExtOpStp, oldExtOpSt, ExtOp);
					dbiConn.getConnStructPtr()->subscriptionElem.auditRecSt = ExtOp;
					dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp = newExtOpStp;
					newExtOpStp = NULL;
				}
				else if ((retCode = DBA_GetOldDataForAudit(EOp, ExtOp, extOpSt, dbiConn, FALSE)) != RET_SUCCEED)
                {
                    (void)DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                    MSG_RETURN(retCode);
                }

                inAuditData   = dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp;
                dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp = NULL;

                localAuditFlg = TRUE;
            }
        }

        /* Check security on closing periods */         /* REF2631 - 980902 - DED */
        DBA_GetFusDateExtOp(&refDate, fusionDateRule, extOpSt);

        {
            FLAG_T superUserFlag = FALSE;

            DBA_GetUserInfo(A_ApplUser_SuperuserFlg, static_cast<PTR> (&superUserFlag));
            (void)GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);           /* REF3846 */

            if (GET_ENUM(extOpSt, ExtOp_NatureEn) != OpNat_Combined) /* PMSTA06760 - DDV - 080702 */
            {
                DBA_ERRMSG_INFOS_ST msgStructSt(FILEINFO);
                if ((ret = DBA_ClosingSecurity(sPtf, superUserFlag, FALSE, refDate, &msgStructSt)) != RET_SUCCEED)
                {
                    /* PMSTA-nuodb - LJE - 190607 */
                    if (msgStructSt.retCode != RET_SUCCEED)
                    {
                        dbiConn.m_msgStructHeaderSt.msgStructTab.push_back(msgStructSt);
                    }
                    (void)DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                    return(ret);
                }
            }
        }

        saveLastUserId = extOpSt[ExtOp_LastUserId];

        /* DLA - PMSTA00577 - 060928 */
        if (DBA_GetUserInfo2(A_ApplUser_Id, &lastUserId, TRUE) != RET_SUCCEED )
        {
            DBA_GetUserInfo(A_ApplUser_Id, &lastUserId);
        }
        SET_ID(extOpSt, ExtOp_LastUserId, lastUserId);


        /* FPL-REF8803-030929 Code moved (only for insert and delete) */


        /* Common code for Insert and Delete */
        switch (action)
        {
            case Update:
                /* Get database system date for an unique date if not supplied */
                /* PMSTA-14045 - TGU - 120606 -(Code report PMSTA-14014)  update the last_modif_d here */
                DATETIME_T databaseDate;
                ret = DBA_GetDbDate(&databaseDate);
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }
                if (IS_NULLFLD(extOpSt, ExtOp_AudModifDate) == true)
                {
                    /* PMSTA-13786 - TGU - 120414 - using "databaseDate" in other part of functin as well */
                    SET_DATETIME(extOpSt, ExtOp_AudModifDate, databaseDate);
                }
                SET_DATETIME(extOpSt, ExtOp_LastModifDate, databaseDate);

                break;

            case Delete:
            case Insert:                    /* DLA-PMSTA02021-070403 - code removed*/
            default:
                break;
        } /* End switch */

		/*PMSTA-28686 - Silpakal - 190227*/
		DBA_GetNewDocIndexCodeFlag(static_cast<ENUM_T>(DocIndexNat_OperationCd), autoCodeGenFlag);
		DBA_GetNewDocIndexCodeFlag(static_cast<ENUM_T>(DocIndexNat_AccountingCd), autoAccCodeGenFlag);

        /* Set the begin date with the date defined by fus date rule and end date / REF8896 - TEB - 030822 */
        DBA_BeginDateEndDateExtOpProcessing(extOpSt, refDate, action, accountingStatus);

        /* Common code for Insert and Update */
        switch (action)
        {
            case Update:
            case Insert:
                {
                    ID_T   sysCurrencyId = ZERO_ID;         /* System currency              */
                    NOTE_T applNoOpenPositionStatusesStr;   /* String with status cancelled */

                    applNoOpenPositionStatusesStr[0] = 0;

                    /*
                     *  Set the flag ExtOp_NoPositionFlg
                     */
                    (void)GEN_GetApplInfo(ApplNoOpenPositionStatuses, applNoOpenPositionStatusesStr );

                    /* Check if Op_StatusEn match with a number in the string */
                    if (DBA_IntExistInString(static_cast<int>(GET_ENUM(extOpSt, ExtOp_StatusEn)), applNoOpenPositionStatusesStr) == TRUE)
                    { /* Number found */
                        SET_FLAG(extOpSt, ExtOp_NoPositionFlg, TRUE);
                    }
                    else
                    { /* Number not found */
                        SET_FLAG(extOpSt, ExtOp_NoPositionFlg, FALSE);
                    }


                    /*
                     *  Set the Order Code to NULL if Id of extOrder is null
                     */
                    if (IS_NULLFLD(extOpSt, ExtOp_ExtOrderId) == true)
                    {
                        SET_NULL_CODE(extOpSt, ExtOp_OrderCd);
                    }

                    /*  Hard coded values */
                    SET_ENUM(extOpSt, ExtOp_DbStatusEn, ExtOpDbStatus_UpToDate);

                    /* If error. Insert or Update fails REF7854 - PMO */
                    (void)DBA_DefFusDateRuleForOpAcctValue(NULL, extOpSt, fusionDateRule);

                    /*
                     *  Don't authorize a ExtOrderId without an accounting status
                     */
                    if (IS_NULLFLD(extOpSt, ExtOp_ExtOrderId) == false &&
                        static_cast<OPSTAT_ENUM> (GET_ENUM(extOpSt, ExtOp_StatusEn)) < accountingStatus)
                    {
                        FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "EXECUTION_ACCT_OPER", nullptr));

                        ret = RET_GEN_ERR_INVARG;
                    }

                    /* Don't allow to update an operation marked for delete to avoid to have the same operation code in 2 portfolios. PMSTA-27222 - 280417 - PMO */
                    if (nullptr != oldExtOpSt && OpFusion_ToDelete == static_cast<OPFUSION_ENUM>(GET_ENUM(oldExtOpSt, ExtOp_FusionEn)))
                    {
                        FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, nullptr, "Deleted operation cannot be updated"));
                        ret = RET_GEN_ERR_INVARG;
                    }

                    if (ret == RET_SUCCEED)
                    {
                        /* Check the extOrder */
                        ret = DBA_CheckExtOrder(extOpSt, sPtf, ppsTab, ppsNb, dbiConn, &fusionAll); /* PMSTA-8306 - 100111 - PMO */
                    }

                    /* REF9050 - 031002 - PMO */
                    switch (static_cast<OPNAT_ENUM> (GET_ENUM(extOpSt, ExtOp_NatureEn)))
                    {
                        case OpNat_Buy:
                        case OpNat_Sell:
                        case OpNat_Income:
                        case OpNat_Adjust:
                            if (ret == RET_SUCCEED)
                            {
                                ret = OPE_SetSysCurrencyId(extOpSt, &sysCurrencyId);
                            }

                            if (ret == RET_SUCCEED)
                            {
                                AMOUNT_T bp10Amount;    /* Computed bp10 */

                                /*
                                 * change the signs of the amounts and quantity
                                 */
                                switch (static_cast<OPNAT_ENUM>(GET_ENUM(extOpSt, ExtOp_NatureEn)))
                                {
                                    case OpNat_Sell:
                                        OPE_ExtOpChangeSignAmountQuantity(extOpSt);
                                        break;

                                    case OpNat_Income:
                                        if (GET_NUMBER(extOpSt, ExtOp_Qty) != ZERO_NUMBER)
                                        {
                                            SET_PRICE(extOpSt, ExtOp_Price, GET_AMOUNT(extOpSt, ExtOp_Price) * (-1.0));
                                        }
                                        break;

                                    default:
                                        break;
                                }

                                /* Compute the bp10 for unbalanced order */
                                ret = OPE_ExtOpComputeBp10(extOpSt,
                                                           sysCurrencyId,
                                                           GET_CODE(sPtf, S_Ptf_Cd),
                                                           NULL,
                                                           &bp10Amount,
                                                           dbiConn);
                                /* Test if ok and we have a value */
                                if (ret == RET_SUCCEED && 0 != CMP_AMOUNT(0.0, bp10Amount, GET_ID(extOpSt, ExtOp_OpCurrId))) /* BSA - REF11402 - 060327 */
                                {                                                                           /* Yes */
                                    ID_T bpTpId;                                                            /* BpType ID */

                                    ret = OPE_SetBalPosTpRank(10, &bpTpId);

                                    if (ret == RET_SUCCEED)
                                    {
                                        SET_AMOUNT(extOpSt, ExtOp_Bp10Amt, bp10Amount);
                                        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_Bp10CurrId, extOpSt, ExtOp, ExtOp_OpCurrId);
                                        SET_ID(extOpSt, ExtOp_Bp10TpId, bpTpId);
                                    }

                                }

                                /*
                                 * change the signs of the amounts and quantity
                                 */
                                switch (static_cast<OPNAT_ENUM>(GET_ENUM(extOpSt, ExtOp_NatureEn)))
                                {
                                    case OpNat_Sell:
                                        OPE_ExtOpChangeSignAmountQuantity(extOpSt);
                                        break;

                                    case OpNat_Income:
                                        if (GET_NUMBER(extOpSt, ExtOp_Qty) != ZERO_NUMBER)
                                        {
                                            SET_PRICE(extOpSt, ExtOp_Price, GET_AMOUNT(extOpSt, ExtOp_Price) * (-1.0));
                                        }
                                        break;

                                    default:
                                        break;
                                }
                            }
                            break;

                        default:
                            break;
                    }   /* End switch */
                }       /* End case */
                break;

            default:
                /* No code */
                break;

        }   /* End switch */

    }       /* End if */

    /*
     *  Integrity testing. For an update an id must be present
     */
    if (ret    == RET_SUCCEED                   &&
        action == Update                        &&
        IS_NULLFLD(extOpSt, ExtOp_DbId) == true &&
        IS_NULLFLD(extOpSt, ExtOp_OpId) == true)
    {
        FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-19", nullptr));

        ret = RET_GEN_ERR_INVARG;
    }


    /* REF7560 - PMO */
    if (ret == RET_SUCCEED)
    {
        const int OM_OLD_ACC        =  1;   // Bit value for the old accounting status
        const int OM_NEW_ACC        =  2;   // Bit value for the new accounting status
        const int OM_MOD_BK         =  4;   // Bit value if the business key as changed
        const int OM_FUS_OK         =  8;   // Bit value if treated by the fusion
        const int OM_OLD_DBI        = 16;   // Bit value if the old status is insert
        const int OM_OLD_DBU        = 32;   // Bit value if the old status is update
        const int OM_DEL_ORDER_ACC  = 64;   // Bit value if it is a delete of an updated accounted operation untreated by the fusion    PMSTA-34656 - 060219 - PMO

        int extOrderCase = 0;   /* Current case of ext order
                                 * bit 1: value 1 if accounting status for the old
                                 * bit 2: value 2 if accounting status for the new
                                 * bit 3: value 4 if the business key as changed
                                 * bit 4: value 8 if treated by the fusion
                                 */

        ExtOrderAction extOrderAction = ExtOrderAction::Init;   // Action for ext order

        switch (action)
        {
            case Update:
                /* REF9449 - TEB - 031006 */
                if (static_cast<OPSTAT_ENUM>(GET_ENUM(oldExtOpSt, ExtOp_StatusEn)) <  accountingStatus  &&
                    static_cast<OPSTAT_ENUM>(GET_ENUM(extOpSt,    ExtOp_StatusEn)) >= accountingStatus  &&
                    GET_FLAG(extOpSt, ExtOp_ExecutedFlg) == TRUE
                )
                {
                    FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ORDER_EXECUTED_STATU", nullptr));
                    ret = RET_GEN_ERR_INVARG;
                }
                else
                {
                    /* TGU - PMSTA-13786 - 120414 - if LastModifDate is not set */
                    if(IS_NULLFLD(extOpSt,ExtOp_LastModifDate) == true)
                    {
                        DATETIME_T databaseDate;
                        ret = DBA_GetDbDate(&databaseDate);
                        if (ret != RET_SUCCEED)
                        {
                            return(ret);
                        }
                        SET_DATETIME(extOpSt, ExtOp_LastModifDate, databaseDate);
                    }
                    /* If the old have operation id and not the new, copy the operation id */
                    if (IS_NULLFLD(extOpSt,    ExtOp_OpId) == true &&
                        IS_NULLFLD(oldExtOpSt, ExtOp_OpId) == false)
                    {
                        COPY_DYNFLD(extOpSt, ExtOp, ExtOp_OpId, oldExtOpSt, ExtOp, ExtOp_OpId);
                    }

                    if (GET_FLAG(extOpSt, ExtOp_NoCheckSynthAdminFlg) == TRUE)
                    {
                        SET_FLAG(oldExtOpSt, ExtOp_NoCheckSynthAdminFlg, TRUE);
                    }

                    /* Set the flag for the old accounting status */
                    if (static_cast<OPSTAT_ENUM>(GET_ENUM(oldExtOpSt, ExtOp_StatusEn)) >= accountingStatus)
                    {
                        extOrderCase = OM_OLD_ACC;
                    }

                    /* Set the flag for the new accounting status */
                    if (static_cast<OPSTAT_ENUM>(GET_ENUM(extOpSt, ExtOp_StatusEn)) >= accountingStatus)
                    {
                        extOrderCase |= OM_NEW_ACC;
                    }

                    /* Set the flag for the change of business key */
                    if (0 != CMP_DYNFLD(extOpSt, oldExtOpSt, ExtOp_Cd, ExtOp_Cd, CodeType))
                    { /* Yes */
                        extOrderCase |= OM_MOD_BK;
                    }

                    /*  Set the flag treated by the fusion */
                    if (static_cast<OPFUSION_ENUM>(GET_ENUM(oldExtOpSt, ExtOp_FusionEn)) == OpFusion_Treated)
                    { /* Yes */
                        extOrderCase |= OM_FUS_OK;
                    }

                    /*  Set the flag for the old dbstatus */
                    switch (GET_ENUM(oldExtOpSt, ExtOp_OpActionEn))
                    {
                        case ExtOpActionEn_ToInsert:
                            extOrderCase |= OM_OLD_DBI;
                            break;

                        case ExtOpActionEn_ToUpdate:
                            extOrderCase |= OM_OLD_DBU;
                            break;
						
						case ExtOpActionEn_ToInsertMcy:              /*PMSTA-60586*/
							extOrderCase |= OM_OLD_DBI;
							break;

                        default: /* Other case */
                            break;
                    }

                    /*<REF104212-EFE-041125*/
                    /* timeStamp management take care that the time stamp of extOp is newer than the one from
                     * oldExtOp when not null,
                     * if it is not the case , we temporary change the extOrderAction for case 21 to ExtOrderAction::Insert
                     */
                    if ( NULL != oldExtOpSt  &&
                        DATETIME_CMP( GET_DATETIME( extOpSt, ExtOp_LastModifDate),
                                     GET_DATETIME( oldExtOpSt, ExtOp_LastModifDate) ) < 0  )
                    {
                        badTimeStampFlg  = TRUE;
                    }


                    switch (extOrderCase)
                    {
                        case 0:                     /* Untreated by the fusion                          */
                        case OM_FUS_OK:             /* Treated by the fusion                            */
                        case OM_FUS_OK | OM_OLD_DBI:/* treated by the fusion; Old Db status is insert   */
                            /* $_CASE_OM03
                             * - Treated or untreated by the fusion
                             * - No new or old accounting status
                             * - No change in the business key
                             */
                            /* Set the extended operation to: up to date and treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is update the record in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_MOD_BK:             /* The business key as changed                          */
                        case OM_MOD_BK | OM_FUS_OK: /* The business key as changed; treated by the fusion   */
                            /* $_CASE_OM04
                             * - Treated or untreated by the fusion
                             * - No new or old accounting status
                             * - The business key as changed
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: up to date MBK and treated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                                /* Action is update the record in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_OLD_DBI:/* Old and new have accounting status; Old Db status is insert */
                            /* $_CASE_OM05
                             * - Untreated by the fusion
                             * - Old and new have accounting status
                             * - No change in the business key
                             * - Old Db status is insert
                             */
                            /* Set the extended operation to: insert and untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsert);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is update the record in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_MOD_BK | OM_OLD_DBI:/* Old and new have accounting status; the business key as changed; Old Db status is insert */
                            /* $_CASE_OM06
                             * - Untreated by the fusion
                             * - Old and new have accounting status
                             * - The business key as changed
                             * - Old Db status is insert
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: insert MBK and untreated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsertMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                                /* Action is update the record in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                        case OM_OLD_ACC | OM_OLD_DBI:/* Old have accounting status; Old Db status is insert */
                            /* $_CASE_OM07
                             * - Untreated by the fusion
                             * - Old have accounting status
                             * - No change in the business key
                             * - Old Db status is insert
                             */
                            /* Set the extended operation to: up to date and treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is update the record in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_OLD_ACC | OM_MOD_BK | OM_OLD_DBI:/* Old have accounting status; the business key as changed; Old Db status is insert */
                            /* $_CASE_OM08
                             * - Untreated by the fusion
                             * - Old have accounting status
                             * - The business key as changed
                             * - Old Db status is insert
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: insert MBK and untreated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                                /* Action is update the record in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_OLD_DBU:/* Old and new have accounting status; Old Db status is update */
                            /* $_CASE_OM09
                             * - Untreated by the fusion
                             * - Old and new have accounting status
                             * - No change in the business key
                             * - Old Db status is update
                             */
                            /* Set the extended operation to: to update and untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is update the record in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_MOD_BK | OM_OLD_DBU:/* Old and new have accounting status; the business key as changed; Old Db status is update */
                            /* $_CASE_OM10
                             * - Untreated by the fusion
                             * - Old and new have accounting status
                             * - The business key as changed
                             * - Old Db status is update
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: update MBK and untreated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                                /* Action is update the record in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                        case OM_OLD_ACC | OM_OLD_DBU:/* Old have accounting status; Old Db status is update */
                            /* $_CASE_OM11
                             * - Untreated by the fusion
                             * - Old have accounting status
                             * - No change in the business key
                             * - Old Db status is update
                             */
                            /* Set the extended operation to: to update and treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is update the record in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_OLD_ACC | OM_MOD_BK | OM_OLD_DBU:/* Old have accounting status; the business key as changed; Old Db status is update */
                            /* $_CASE_OM12
                             * - Untreated by the fusion
                             * - Old have accounting status
                             * - The business key as changed
                             * - Old Db status is update
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: update MBK and treated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                                /* Action is update the record in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_FUS_OK:/* Old and new have accounting status and treated by the fusion */
                            /* $_CASE_OM13
                             * - Treated by the fusion
                             * - Old and new have accounting status
                             * - No change in the business key
                             */
                            /* Set the extended operation to: to update and untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is insert in ext_order */
                            extOrderAction = ExtOrderAction::Insert;
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_MOD_BK | OM_FUS_OK:/* Old and new have accounting status and treated by the fusion and the business key as changed */
                            /* $_CASE_OM14
                             * - Treated by the fusion
                             * - Old and new have accounting status
                             * - The business key as changed
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: to update MBK and untreated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                                /* Action is insert in ext_order */
                                extOrderAction = ExtOrderAction::Insert;
                            }
                            break;

                        case OM_OLD_ACC | OM_FUS_OK:/* Old have accounting status and treated by the fusion */
                            /* $_CASE_OM15
                             * - Treated by the fusion
                             * - Old have accounting status
                             * - No change in the business key
                             */
                            /* Set the extended operation to: to update and Treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is insert in ext_order */
                            extOrderAction = ExtOrderAction::Insert;
                            break;

                        case OM_OLD_ACC | OM_FUS_OK | OM_MOD_BK:/* Old have accounting status and treated by the fusion and the business key as changed */
                            /* $_CASE_OM16
                             * - Treated by the fusion
                             * - Old have accounting status
                             * - The business key as changed
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: to update MBK and Treated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                                /* Action is insert in ext_order */
                                extOrderAction = ExtOrderAction::Insert;
                            }
                            break;

                        case OM_NEW_ACC | OM_FUS_OK:/* New have accounting status and treated by the fusion */
                            /* $_CASE_OM19
                             * - Treated by the fusion
                             * - New have accounting status
                             * - No change in the business key
                             */
                            /* Set the extended operation to: to update and Treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsert);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is update in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        case OM_FUS_OK | OM_OLD_DBU:/* Treated by the fusion and old status is update */
                            /* $_CASE_OM20
                             * - Treated by the fusion
                             * - No change in the business key
                             */
                            /* Set the extended operation to: to update and Treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is update in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                            /* REF9033 - TEB - 030815 */
                        case OM_OLD_ACC | OM_NEW_ACC:/* Old and new have accounting status and untreated by the fusion */
                            /* $_CASE_OM21
                             * - Untreated by the fusion
                             * - Old and new have accounting status
                             * - No change in the business key
                             */

                            /*
                             *  This entry handle race condition like two gui that update the same accounted operation
                             */

                            /* Set the extended operation to: to update and untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            if (badTimeStampFlg  == FALSE)
                            {                               /* NORMAL case  : Action is update in ext_order */
                                extOrderAction = ExtOrderAction::Update;/*REF10517-040819-EFE*/
                            }
                            else
                            { /* concurrency Case REF10421-EFE-041125*/
                                extOrderAction = ExtOrderAction::Insert ;
                            }

                            break;

                        case OM_NEW_ACC | OM_MOD_BK | OM_FUS_OK:/* REF9705 - 031127 - PMO */
                            /* $_CASE_OM22
                             * - new accounting status
                             * - business key as changed
                             * - treated by the fusion
                             */
                            /* Define a new operation code (business key) */
                            if ((ret = DBA_SetOperationCode(extOpSt, autoCodeGenFlag, autoAccCodeGenFlag, dbiConn, codeOp)) == RET_SUCCEED)
                            { /* Ok */

                                /* Set the extended operation to: to update MBK and Treated by the fusion */
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdateMbk);
                                SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                                /* Action is update in ext_order */
                                extOrderAction = ExtOrderAction::Update;
                            }
                            break;

                            /*<REF10826-EFE-041210*/
                        case OM_NEW_ACC | OM_FUS_OK | OM_OLD_DBU:/* Treated by the fusion and old status is update */
                            /* $_CASE_OM23
                             * - Treated by the fusion
                             * - No change in the business key
                             * - Old Db status is update
                             */
                            /* Set the extended operation to: to update and Treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is update in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;
                            /*>REF10826-EFE-041210*/

                        /* BSA - PMSTA4367 - 071022 */
                        case  OM_OLD_ACC | OM_FUS_OK | OM_OLD_DBU:/* Old have accounting status,treated by the fusion and old status is update */
                            /* $_CASE_OM24
                             * - Treated by the fusion
                             * - No change in the business key
                             * - Old Db status is update
                             */
                            /* Set the extended operation to: to update and Treated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Treated);

                            /* Action is insert in ext_order */
                            extOrderAction = ExtOrderAction::Insert;
                            break;

                        /* BSA - PMSTA4367 - 071022 */
                        case OM_OLD_ACC | OM_NEW_ACC | OM_FUS_OK | OM_OLD_DBU: /* Old and new have accounting status,treated by the fusionand old status is update */
                            /* $_CASE_OM25
                             * - Treated by the fusion
                             * - No change in the business key
                             * - Old Db status is update
                             */

                            /* Set the extended operation to: to update and Untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is insert in ext_order */
                            extOrderAction = ExtOrderAction::Insert;
                            break;

                        case OM_OLD_ACC | OM_NEW_ACC | OM_MOD_BK: /* PMSTA-7310 - 020309 - PMO */
                            /* $_CASE_OM26
                             * - treated by the fusion and a new record still untreated by the fusion
                             * - business key as changed
                             */
                            /* Set the extended operation to: to update and Untreated by the fusion */
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);
                            SET_ENUM(extOpSt, ExtOp_FusionEn,   OpFusion_Untreated);

                            /* Action is insert in ext_order */
                            extOrderAction = ExtOrderAction::Update;
                            break;

                        default:
                            {
                                char messageStr[32];/* Buffer for an error message */
                                /* Format and log an error message */
                                (void)snprintf(messageStr,
                                               sizeof(messageStr) / sizeof(messageStr[0]),
                                               "Invalid data case:%d",
                                               extOrderCase);
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, messageStr );

                                /* Undefined case */
                                extOrderAction = ExtOrderAction::Init;
                                assert(4 == 5);
                                ret = RET_DBA_ERR_INVDATA;
                            }
                            break;

                    } /* End switch */


                    bool localTranFlg = false;

                    if (ret == RET_SUCCEED)
                    {
                        /* Update attached execution if need REF8116 - PMO - 021023 */
                        ret = DBA_UpdateIfNeedExecution(extOpSt,
                                                        FALSE,/* REF11344-EFE-050816 */
                                                        localTranFlg,
                                                        dbiConn);
                    }


                    if (ret == RET_SUCCEED)
                    {
                        /*
                         *  Update or Insert in ext order
                         */
                        switch (extOrderAction)
                        {

                            case ExtOrderAction::Insert:/* Insert in ext order */
                                /* Block mode processing ? */
                                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                                { /* Yes */
                                  /* Insert ext_order in block mode */
                                    ret = DBA_BlockModeInsUpdDelExtOp(extOpSt,
                                                                      inAuditData,
                                                                      localEventFlg,
                                                                      localAuditFlg,
                                                                      dbiConn,
                                                                      newStep,
                                                                      Insert,
                                                                      action); /* DLA - REF11355 - 050817 */

                                }
                                else
                                { /* No */
                                  /* Insert ext_order */
                                    ret = DBA_Insert2(ExtOrder, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
                                }

                                if (ret != RET_SUCCEED)
                                { /* Error */
                                    char tab[256];

                                    /* PMSTA-11242 - 020211 - PMO */
                                    (void)snprintf(tab,
                                                   sizeof(tab) / sizeof(tab[0]),
                                                   "update(insert) operation failed primary key : code = %s,TACode = 0x%X,case = %d,db id = %" szFormatId ",op id = %" szFormatId,
                                                   GET_CODE(extOpSt, ExtOp_Cd),
                                                   ret,
                                                   extOrderCase,
                                                   GET_ID(extOpSt, ExtOp_DbId),
                                                   GET_ID(extOpSt, ExtOp_OpId)
                                                   );

                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, tab);
                                }
                                break;

                            case ExtOrderAction::Update:/* Update in ext order */
                                /* Block mode processing ? */
                                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                                { /* Yes */
                                  /* Update ext_order in block mode */
                                    ret = DBA_BlockModeInsUpdDelExtOp(extOpSt,
                                                                      inAuditData,
                                                                      localEventFlg,
                                                                      localAuditFlg,
                                                                      dbiConn,
                                                                      newStep,
                                                                      Update,
                                                                      action); /* DLA - REF11355 - 050817 */
                                }
                                else
                                { /* No */
                                  /* Update ext_order */
                                    ret = DBA_Update2(ExtOrder, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
                                }

                                if (ret != RET_SUCCEED)
                                { /* Error */
                                    char tab[256];

                                    /* PMSTA-11242 - 020211 - PMO */
                                    (void)snprintf(tab,
                                                   sizeof(tab) / sizeof(tab[0]),
                                                   "update operation failed primary key : code = %s,TACode = 0x%X,case = %d,db id = %" szFormatId ",op id = %" szFormatId,
                                                   GET_CODE(extOpSt, ExtOp_Cd),
                                                   ret,
                                                   extOrderCase,
                                                   GET_ID(extOpSt, ExtOp_DbId),
                                                   GET_ID(extOpSt, ExtOp_OpId)
                                                   );

                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, tab);
                                }
                                break;

                            default:
                            case ExtOrderAction::Init:/* Initialization */
                                /* Undefined case */
                                break;
                        }
                    } /* End if */

                    /* Transaction as been opened */
                    if (localTranFlg == true)
                    { /* Yes */
                        if (ret == RET_SUCCEED)
                        { /* Ok */
                          /* Commit */
                            dbiConn.endTransaction(TRUE);
                        }
                        else
                        { /* Error */
                          /* Rollback */
                            dbiConn.endTransaction(FALSE);
                        }
                    }

                    if (ret == RET_SUCCEED      &&
                        localEventFlg == TRUE   &&
                        dbiConn.getConnStructPtr()->blockMode == FALSE)
                    {
                        /*
                         * Subscription.
                         */
                        ret = DBA_LogSubscriptionEvents(EOp,
                                                        Subscription_Action_Update,
                                                        ExtOp,
                                                        extOpSt,
                                                        (localAuditFlg == TRUE) ? inAuditData : NULL,
                                                        dbiConn,
                                                        outSubscriptionTab,
                                                        outSubscriptionNbr);

                    } /* End if */

                    /* Old or/and new have accounting status REF7560 - PMO */
                    if (ret == RET_SUCCEED &&
                        ((extOrderCase & (OM_NEW_ACC | OM_OLD_ACC)) > 0))
                    {
                        DATETIME_T refDatePrevious; /* Reference date of the previous extop */
                        DATETIME_T refDateUse;      /* Reference date to use        FPL-REF9069-030929 */

                        /* Portfolio change FPL-REF9069-030929 code removed REF11159-EFE-050513 */


                        /* Obtain the fusion date rule of the previous extop */
                        DBA_GetFusDateExtOp(&refDatePrevious, fusionDateRule, oldExtOpSt);

                        /* Keep the smallest date */
                        if (DATETIME_CMP(refDate, refDatePrevious) <= 0)
                        { /* Use refDate */
                            refDateUse = refDate;
                        }
                        else
                        { /* Use refDatePrevious */
                            refDateUse = refDatePrevious;
                        }


                        /*delete event only for the current operation , with fusion new */
                        ret = DBA_DeleteEventScheduler(extOpSt, dbiConn);


                        /* Insert an event for the current portfolio */
                        if ( ret == RET_SUCCEED )
                        {
                            ret = DBA_InsertEventScheduler(extOpSt,
                                                           oldExtOpSt,                          /* REF9208 - 030613 - PMO */
                                                           &refDateUse,
                                                           action,
                                                           dbiConn,
                                                           autoFusStock,
                                                           fusionAll ? FUSION_ALL : FUSION_NEW, /* PMSTA-8306 - 100111 - PMO */
                                                           accountingStatus);
                        }
                        /* FPL-REF9069-030929 code removed REF11159-EFE-050513*/
                    } /* end if */
                }

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, ExtOp);
                }
                /* End case Update */
                break;

            case Delete:
                {
                    bool    endDateNullFlg           = IS_NULLFLD(extOpSt, ExtOp_EndDate);  /* If the end date is null  REF8625 - 030113 - PMO */
                    bool    oldOrNewAccountingStatus = false;                               /* Old extOp or new extop have accounting status REF7560 - PMO */

                    /* Test if endDate is null  REF8625 - 030113 - PMO */
                    if (endDateNullFlg == true)
                    { /* Yes */

                        /* endDate is mandatory for the database */

                        /* Temporary, set the end date with the magic date (31/12/9999) */
                        SET_DATE(extOpSt, ExtOp_EndDate, MAGIC_END_DATE);
                    }


                    /* REF7560 - PMO */
                    if (ret == RET_SUCCEED)
                    {
                        // Set the flag for the new accounting status
                        if (static_cast<OPSTAT_ENUM>(GET_ENUM(extOpSt, ExtOp_StatusEn)) >= accountingStatus)
                        {
                            extOrderCase |= OM_NEW_ACC;
                            oldOrNewAccountingStatus = true;
                        }

                        //  Set the flag treated by the fusion
                        if (extOp.orEq(OpFusion_Treated))
                        { /* Yes */
                            extOrderCase |= OM_FUS_OK;
                        }

                        //  Set the flag for the delete of an updated accounted operation untreated by the fusion
                        if (extOp.getOpId() > ZERO_ID)                                                              /* PMSTA-34656 - 060219 - PMO */
                        {
                            extOrderCase |= OM_DEL_ORDER_ACC;

                            if (false == oldExtOp.empty() && oldExtOp.isDeleted())                                  /* PMSTA-34674 - 070219 - PMO */
                            { // Record is already deleted
                                extOrderCase = OM_NEW_ACC | OM_DEL_ORDER_ACC;
                                extOp.copyTimeStamp(oldExtOp);
                            }
                        }

                        switch (extOrderCase)
                        {
                            case 0:                             // Untreated by the fusion; No accounting status
                            case OM_NEW_ACC:
                            case OM_FUS_OK:                     // Treated by the fusion
                            case OM_DEL_ORDER_ACC:              // Untreated by the fusion; No accounting status       PMSTA-34656 - 060219 - PMO
                            case OM_FUS_OK  | OM_DEL_ORDER_ACC: // Treated by the fusion                               PMSTA-34656 - 060219 - PMO
                                // Delete of given operation by physical delete
                                extOrderAction = ExtOrderAction::Delete;
                                break;


                            case OM_NEW_ACC | OM_FUS_OK:// New have accounting status; Treated by the fusion
                            case OM_NEW_ACC | OM_FUS_OK | OM_DEL_ORDER_ACC:                                         /* PMSTA-34656 - 060219 - PMO */
                                // Set the extended operation to: to delete and untreated by the fusion
                                extOp.setField(ExtOpActionEn_ToDelete);
                                extOp.setFusionEToDelete();                                                         /* PMSTA-32291 - 130818 - PMO */

                                // Insert ext_order
                                extOrderAction = ExtOrderAction::Insert;
                                break;

                            case OM_NEW_ACC | OM_DEL_ORDER_ACC:                                                     /* PMSTA-34656 - 060219 - PMO */
                                // Set the extended operation to: to delete and untreated by the fusion
                                extOp.setField(ExtOpActionEn_ToDelete);
                                extOp.setFusionEToDelete();                                                         /* PMSTA-32291 - 130818 - PMO */

                                // Update ext_order
                                extOrderAction = ExtOrderAction::Update;
                                break;


                            default:
                                {   // Format and log an error message
                                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("Invalid data case:", SYS_ToString(extOrderCase)).c_str() );

                                    // Undefined case
                                    assert(5 == 6);
                                    ret = RET_DBA_ERR_INVDATA;
                                }
                                break;

                        } /* End switch */

                        bool localTranFlg = false;           /* Flag if a transaction as been opened REF11344-EFE-060105*/

                        if (ret == RET_SUCCEED)
                        {
                            ret = DBA_UpdateIfNeedExecution(extOpSt,
                                                            FALSE,/* REF11344-EFE-050808  */
                                                            localTranFlg,
                                                            dbiConn);
                        }

                        if (ret == RET_SUCCEED)
                        {
                            /*
                             *  Delete or Insert in ext order
                             */
                            switch (extOrderAction)
                            {
                                case ExtOrderAction::Update:    // Update in ext order      PMSTA-34656 - 060219 - PMO
                                case ExtOrderAction::Insert:    // Insert in ext order
                                    {
                                        CODE_T codeOpSav;/* REF9499 - 031216 - PMO */


                                        /*
                                         *  REF9499 - 031216 - PMO
                                         *  To allow the case of a delete of an Accounting operation and
                                         *  an Insert with the same code and without "fusion processing"
                                         *  The code is changed to the character $ and the id of the operation
                                         */
                                        if (OM_NEW_ACC == (extOrderCase & OM_NEW_ACC))
                                        {
                                            strcpy(codeOpSav, extOp.getOpCd());
                                            SET_CODE(extOpSt, ExtOp_Cd, extOp.getDeleteCode().c_str());  /* PMSTA-34674 - 070219 - PMO */
                                        }
                                        else
                                        {
                                            codeOpSav[0] = 0;
                                        }

                                        /* Block mode processing ? */
                                        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                                        { /* Yes */
                                          /* Insert/Update ext_order in block mode */
                                            ret = DBA_BlockModeInsUpdDelExtOp(extOpSt,
                                                                              inAuditData,
                                                                              localEventFlg,
                                                                              localAuditFlg,
                                                                              dbiConn,
                                                                              newStep,
                                                                              ExtOrderAction::Insert == extOrderAction ? Insert : Update,   /* PMSTA-34656 - 060219 - PMO */
                                                                              action); /* DLA - REF11355 - 050817 */
                                        }
                                        else
                                        { /* No */
                                            if (ExtOrderAction::Insert == extOrderAction)                                                   /* PMSTA-34656 - 060219 - PMO */
                                            { // Insert ext_order
                                                ret = DBA_Insert2(ExtOrder, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
                                            }
                                            else
                                            { // Update ext_order
                                                ret = DBA_Update2(ExtOrder, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
                                            }
                                        }

                                        if (ret != RET_SUCCEED)
                                        { /* Error */
                                            const std::string dbAction(ExtOrderAction::Insert == extOrderAction ? "insert" : "update");

                                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer( "delete("
                                                                                                        , dbAction
                                                                                                        , ") operation failed primary key : code = "
                                                                                                        , extOp.getOpCd()
                                                                                                        , ",TACode = 0x"
                                                                                                        , SYS_ToHexString(ret)
                                                                                                        , ",case = "
                                                                                                        , SYS_ToString(extOrderCase)
                                                                                                        , ",db id = "
                                                                                                        , SYS_ToString(extOp.getDbId())
                                                                                                        , ",op id = "
                                                                                                        , SYS_ToString(extOp.getOpId())).c_str());
                                        }

                                        /*
                                         *  REF9499 - 031216 - PMO
                                         *  Restore the code of the operation
                                         */
                                        if (OM_NEW_ACC == (extOrderCase & OM_NEW_ACC))
                                        {
                                            SET_CODE(extOpSt, ExtOp_Cd, codeOpSav);
                                        }

                                    }
                                    break;

                                case ExtOrderAction::Delete:                /* Delete in ext order and notepad */
                                    {
                                        DBA_DYNFLD_STP  admArg = ALLOC_DYNST(Adm_Arg);   /* DLA - REF10459 - 041125 */

                                        if (admArg == NULL)
                                        { /* Error */
                                            ret = RET_MEM_ERR_ALLOC;
                                            MSG_SendMesg(ret, 2, FILEINFO, "Adm_Arg");
                                        }

                                        if (ret == RET_SUCCEED)
                                        { /* Ok */

                                            /* Obtain the correct id */
                                            ID_T notepadId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);

                                            /* Fill fields */

                                            SET_ID(admArg, Adm_Arg_EntDictId, (DBA_GetDictEntityStSafe(Op))->entDictId);
                                            SET_ID(admArg, Adm_Arg_Id, notepadId);

                                            /* Block mode processing ? */
                                            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                                            { /* Yes */
                                              /*
                                               * Delete ext_order in block mode
                                               */
                                                ret = DBA_BlockModeInsUpdDelExtOp(extOpSt,
                                                                                  inAuditData,
                                                                                  localEventFlg,
                                                                                  localAuditFlg,
                                                                                  dbiConn,
                                                                                  newStep,
                                                                                  Delete,
                                                                                  action); /* DLA - REF11355 - 050817 */

                                                if (ret == RET_SUCCEED)
                                                { /* Ok */
                                                  /* DLA - REF10459 - 041125
                                                   *
                                                   *  Delete notepad
                                                   */
                                                    int              rows        = 0;
                                                    DBA_DYNFLD_STP * sNotepadTab = NULL;

                                                    DBA_Select2(Notepad,
                                                                UNUSED,
                                                                Adm_Arg,
                                                                admArg,
                                                                S_Notepad,
                                                                &sNotepadTab,
                                                                UNUSED,
                                                                UNUSED,
                                                                &rows,
                                                                NULL,
                                                                NULL);

                                                    for (int i = 0 ; i < rows; i++)
                                                    {
                                                        ret = DBA_MultiAccessDelNotepad(sNotepadTab[i], dbiConn);

                                                        if (ret != RET_SUCCEED)
                                                        { /* Error */
                                                            break;
                                                        }
                                                    }

                                                    /* PMSTA-16340 - 191213 - PMO */
                                                    if (ret == RET_SUCCEED)
                                                    { /* Ok */
                                                        ret = DBA_MultiAccessDelCommunication(OPE_DynStDup(admArg), dbiConn);
                                                    }

                                                    FREE_DYNST(admArg, Adm_Arg);
                                                }
                                                else
                                                { /* Error */
                                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer( "delete operation failed primary key : code = "
                                                                                                                , extOp.getOpCd()
                                                                                                                , ",TACode = 0x"
                                                                                                                , SYS_ToHexString(ret)
                                                                                                                , ",db id = "
                                                                                                                , SYS_ToString(extOp.getDbId())
                                                                                                                , ",op id = "
                                                                                                                , SYS_ToString(extOp.getOpId())).c_str());
                                                }
                                            }
                                            else
                                            { /* No */
                                                /*
                                                 * Delete notepad
                                                 */
                                                /* DLA - REF10459 - 041125 */

                                                DBA_DYNFLD_STP  * sNotepadTab = NULL;
                                                int               rows = 0;

                                                DBA_Select2(Notepad,
                                                            UNUSED,
                                                            Adm_Arg,
                                                            admArg,
                                                            S_Notepad,
                                                            &sNotepadTab,
                                                            UNUSED,
                                                            UNUSED,
                                                            &rows,
                                                            NULL,
                                                            NULL);

                                                for (int i = 0 ; i < rows; i++)
                                                {
                                                    ret = DBA_Delete2(Notepad,
                                                                      UNUSED,
                                                                      S_Notepad,
                                                                      sNotepadTab[i],
                                                                      DBA_SET_CONN | DBA_NO_CLOSE,
                                                                      dbiConn);

                                                    if (ret != RET_SUCCEED)
                                                    { /* Error */
                                                        break;
                                                    }
                                                }

                                                for (int i = 0 ; i < rows ; i++)
                                                {
                                                    FREE_DYNST(sNotepadTab[i], S_Notepad);
                                                }

                                                /* PMSTA-16340 - 191213 - PMO */
                                                if (ret == RET_SUCCEED)
                                                {
                                                    ret = DBA_Delete2(Communication,
                                                                        DBA_ROLE_FUSION,
                                                                        Adm_Arg,
                                                                        admArg,
                                                                        DBA_SET_CONN | DBA_NO_CLOSE,
                                                                        dbiConn);
                                                }

                                                FREE_DYNST(admArg, Adm_Arg);


                                                /*
                                                 * Delete ext_order
                                                 */

                                                /* REF9423 - 040216 - PMO */
                                                if (ret == RET_SUCCEED)
                                                {
                                                    DBA_DYNFLD_STP admArgStp = nullptr;     // Short operation used to delete in extOrder

                                                    ret = DBA_ConvertExtOp2Adm_Arg(&admArgStp, extOpSt, ExtOp_DbId);
                                                    if (ret == RET_SUCCEED)
                                                    { /* Ok */

                                                        ret = DBA_Delete2(ExtOrder,
                                                                          UNUSED,
                                                                          Adm_Arg,   /* REF9423 - 040216 - PMO */
                                                                          admArgStp, /* REF9423 - 040216 - PMO */
                                                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                                                          dbiConn);

                                                        FREE_DYNST(admArgStp, Adm_Arg);

                                                        if (ret != RET_SUCCEED)
                                                        { /* Error */
                                                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer( "delete operation failed primary key : code = "
                                                                                                                        , extOp.getOpCd()
                                                                                                                        , ",TACode = 0x"
                                                                                                                        , SYS_ToHexString(ret)
                                                                                                                        , ",case = "
                                                                                                                        , SYS_ToString(extOrderCase)
                                                                                                                        , ",db id = "
                                                                                                                        , SYS_ToString(extOp.getDbId())
                                                                                                                        , ",op id = "
                                                                                                                        , SYS_ToString(extOp.getOpId())).c_str());
                                                        }
                                                    }
                                                }
                                            }
                                        } /* End if */
                                    } /* End case */
                                    break;

                                default:
                                case ExtOrderAction::Init:/* Initialization */
                                    /* Undefined case */
                                    break;
                            }

                            /* Transaction as been opened */
                            if (localTranFlg == true)
                            { /* Yes */
                                if (ret == RET_SUCCEED)
                                { /* Ok */
                                    /* Commit */
                                    dbiConn.endTransaction(TRUE);
                                }
                                else
                                { /* Error */
                                    /* Rollback */
                                    dbiConn.endTransaction(FALSE);
                                }
                            } /* End if */
                        } /* End if */
                    }

                    /* DLA - PMSTA05995 - 080407 , Subscription moved after db modifications */
                    if (ret == RET_SUCCEED && dbiConn.getConnStructPtr()->blockMode == FALSE && TRUE == localEventFlg)
                    { // Subscription. Block Mode is not activated
                        ret = DBA_LogSubscriptionEvents(EOp,
                                                        Subscription_Action_Delete,
                                                        ExtOp,
                                                        extOpSt,
                                                        (localAuditFlg == TRUE) ? inAuditData : NULL,
                                                        dbiConn,
                                                        outSubscriptionTab,
                                                        outSubscriptionNbr); /* REF5037 */
                    }


                    /* Test if endDate is null  REF8625 - 030113 - PMO */
                    if (endDateNullFlg == true)
                    { /* Yes */

                        /* Remove the endDate */
                        SET_NULL_DATE(extOpSt, ExtOp_EndDate);
                    }

                    /* REF7560 - PMO */
                    if (ret == RET_SUCCEED && oldOrNewAccountingStatus == true)
                    {
                        ret = DBA_InsertEventScheduler(extOpSt,
                                                       NULL,    /* REF9208 - 030613 - PMO */
                                                       &refDate,
                                                       action,
                                                       dbiConn,
                                                       autoFusStock,
                                                       fusionAll ? FUSION_ALL : FUSION_NEW, /* PMSTA-8306 - 100111 - PMO */
                                                       accountingStatus); /* FPL-REF9069-030929 */
                    }

                    if (localAuditFlg == TRUE)
                    {
                        FREE_DYNST(inAuditData, ExtOp);
                    }
                } /* End case Delete */
                break;


            case Insert:
                {
                    /*  Hard coded values REF7560 - PMO */
                    SET_NULL_ID(extOpSt,    ExtOp_ExtStratEltId);
                    if (dbiConn.getConnStructPtr()->preserveConfirmedFlg == FALSE)
                    {
                        /* REF11338 - CHU - 051011 */
                        SET_FLAG_FALSE(extOpSt, ExtOp_ConfirmedFlg);
                    }
                    SET_NULL_ID(extOpSt,    ExtOp_ParentExtOpId);

                    /* REF9301 - 040219 - PMO */
                    COPY_DYNFLD(extOpSt, ExtOp, ExtOp_AudModifDate, extOpSt, ExtOp, ExtOp_LastModifDate);


                    /* Code Removed REF7560 - PMO */

                    /* SME REF423 980330 new index for operation code */
                    /* Beware of copy PPS, no operation generated in this case! GRD - REF1560. */
                    /* REF3088 - SSO - 981201 no code generation in case of mod curre or copy opers  */
                    /* REF3839 - SSO - 990723 do not overwrite non-null codes! */

                    if (((autoCodeGenFlag    == TRUE && IS_NULLFLD(extOpSt, ExtOp_Cd)     == true) ||
                         (autoAccCodeGenFlag == TRUE && IS_NULLFLD(extOpSt, ExtOp_AcctCd) == true)))
                    {
                        /* Define a new operation code (business key) */
                        ret = DBA_SetOperationCode(extOpSt,
                                                   autoCodeGenFlag,
                                                   autoAccCodeGenFlag,
                                                   dbiConn,
                                                   codeOp);
                        if (ret != RET_SUCCEED)
                        { /* Error */

                            if (localAuditFlg == TRUE)
                            {
                                FREE_DYNST(inAuditData, ExtOp);
                            }

                            return(ret);
                        }
                    }
                    else
                    {
                        unsigned char uCharBit;

                        uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit, AUTOINDEXCODE, FALSE);
                        SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit );/* REF9333 - TEB - 030825 */
                        uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit, AUTOINDEXACCODE, FALSE);
                        SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit );/* REF9333 - TEB - 030825 */

                        /* REF10181 - 041122 - PMO
                         *  Set the code
                         */
                        if (NULL != codeOp)
                        {
                            if (IS_NULLFLD(extOpSt, ExtOp_Cd) == false)
                            {
                                strcpy(codeOp, GET_CODE(extOpSt, ExtOp_Cd));
                            }
                            else
                            {
                                codeOp[0] = 0;
                            }
                        }

                    }

                    /* Set the field to NULL */
                    SET_NULL_ID(extOpSt, ExtOp_OpId);
                    /* REF9870 - 040201 - PMO */
                    COPY_DYNFLD(extOpSt, ExtOp, ExtOp_OpenOpCd, extOpSt, ExtOp, ExtOp_Cd);

                    {   /* REF4811 - 000519 - Generate Source code if EXECUTION_SOURCE_CODE parameter is set to 1
                         * and the source code is NULL */
                        FLAG_T execSrcCodeFlg  = FALSE;

                        GEN_GetApplInfo(ApplMatchExecSourceCdFlag, &execSrcCodeFlg);
                        if (execSrcCodeFlg == TRUE && IS_NULLFLD(extOpSt, ExtOp_SrcCd) == true)
                        {
                            COPY_DYNFLD(extOpSt, ExtOp, ExtOp_SrcCd, extOpSt, ExtOp, ExtOp_Cd);
                        }
                    }

                    /* If "Block mode" is not activated */
                    if (dbiConn.getConnStructPtr()->blockMode == FALSE)
                    {
                        bool localTranFlg = false;      /* Flag if a transaction as been opened */

                        if (ret == RET_SUCCEED)
                        {
                            ret = DBA_UpdateIfNeedExecution(extOpSt,
                                                            FALSE,/* REF11344-EFE-050808  */
                                                            localTranFlg,
                                                            dbiConn);
                        }

                        if (ret == RET_SUCCEED)
                        {
                            if (static_cast<OPSTAT_ENUM> (GET_ENUM(extOpSt, ExtOp_StatusEn)) < accountingStatus)
                            { /* Yes */
                              /* Set the extended operation to: up to date and treated by the fusion $_CASE_OM01 */
                                SET_ENUM(extOpSt, ExtOp_FusionEn, OpFusion_Treated);
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDate);
                            }
                            else
                            { /* No  */
                              /* Set the extended operation to: to insert and untreated by the fusion $_CASE_OM02 */
                                SET_ENUM(extOpSt, ExtOp_FusionEn, OpFusion_Untreated);
                                SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsert);
                            }

                            /* Insert ext_order */
                            ret = DBA_Insert2(ExtOrder, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
                        }

                        if (ret != RET_SUCCEED)
                        { /* Error */
                            char tab[192];

                            /* PMSTA-11242 - 020211 - PMO */
                            (void)snprintf(tab,
                                           sizeof(tab) / sizeof(tab[0]),
                                           "insert operation failed primary key : code = %s,TACode = 0x%X",
                                           GET_CODE(extOpSt, ExtOp_Cd),
                                           ret
                                           );

                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, tab);

                            if (localAuditFlg == TRUE)
                            {
                                FREE_DYNST(inAuditData, ExtOp);
                            }
                        }

                        /* DLA - PMSTA05995 - 080407 , subsrciption moved after database modification */
                        /*
                         * Subscription.
                         */
                        if (ret == RET_SUCCEED && localEventFlg == TRUE)/* REF7560 - PMO */
                        {
                            if ((ret = DBA_LogSubscriptionEvents(EOp,
                                                                 Subscription_Action_Insert,
                                                                 ExtOp,
                                                                 extOpSt,
                                                                 (localAuditFlg == TRUE) ? inAuditData : NULL,
                                                                 dbiConn,
                                                                 outSubscriptionTab,
                                                                 outSubscriptionNbr)) != RET_SUCCEED
                                && localAuditFlg == TRUE)
                            {                                                               /* REF5037 */
                                FREE_DYNST(inAuditData, ExtOp);
                            }
                        }

                        /*
                         * Subscription End.
                         */

                        /* Transaction as been opened */
                        if (localTranFlg == true)
                        { /* Yes */
                            if (ret == RET_SUCCEED)
                            { /* Ok */
                                /* Commit */
                                dbiConn.endTransaction(TRUE);
                            }
                            else
                            { /* Error */
                                /* Rollback */
                                dbiConn.endTransaction(FALSE);
                            }
                        } /* End if */
                    }
                    else
                    {
                        /* BLOCK MODE HANDLING - First Step */

                        if (static_cast<OPSTAT_ENUM> (GET_ENUM(extOpSt, ExtOp_StatusEn)) < accountingStatus)
                        { /* Yes */
                          /* Set the extended operation to: up to date and treated by the fusion $_CASE_OM01 */
                            SET_ENUM(extOpSt, ExtOp_FusionEn, OpFusion_Treated);
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_UpToDate);
                        }
                        else
                        { /* No  */
                          /* Set the extended operation to: to insert and untreated by the fusion $_CASE_OM02 */
                            SET_ENUM(extOpSt, ExtOp_FusionEn, OpFusion_Untreated);
                            SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsert);
							if (IS_NULLFLD(sPtf, S_Ptf_ModifCurrEn) == false
								&& ModifCurr_Ptf == static_cast<MODIFCURR_ENUM>GET_ENUM(sPtf, S_Ptf_ModifCurrEn)) /* PMSTA-50533 */
							{
								SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToInsertMcy);
							}
                        }

                        /* Insert ext_order in block mode */
                        ret = DBA_BlockModeInsUpdDelExtOp(extOpSt,
                                                          inAuditData,
                                                          localEventFlg,
                                                          localAuditFlg,
                                                          dbiConn,
                                                          newStep,
                                                          action,
                                                          action); /* DLA - REF11355 - 050817 */

                        /* PMSTA-11242 - 020211 - PMO */
                        if (ret != RET_SUCCEED)
                        { /* Error */
                            char tab[192];

                            (void)snprintf(tab,
                                           sizeof(tab) / sizeof(tab[0]),
                                           "(bl) insert operation failed primary key : code = %s,TACode = 0x%X",
                                           GET_CODE(extOpSt, ExtOp_Cd),
                                           ret
                                           );

                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, tab);
                        }
                    }

                    if (ret == RET_SUCCEED && localAuditFlg == TRUE)
                    {
                        FREE_DYNST(inAuditData, ExtOp);
                    }

                    /*
                     * BEWARE, when copying portfolio position sets, only positions are inserted.
                     * No need to fusion if no operation inserted. (DVP534 - 970703 - GRD).
                     */

                    /* SME REF2894 add an event in the future for nature instr :InstrNat_Bond InstrNat_MoneyMkt */
                    /* REF3846 SME */

                    if (ret == RET_SUCCEED && GET_ENUM(extOpSt, ExtOp_StatusEn) >= accountingStatus)
                    {
                        /*delete event only for the current portfolio and the old one, if exists */

                        ret = DBA_InsertEventScheduler(extOpSt,
                                                       NULL,    /* REF9208 - 030613 - PMO */
                                                       &refDate,
                                                       action,
                                                       dbiConn,
                                                       autoFusStock,
                                                       fusionAll ? FUSION_ALL : FUSION_NEW, /* PMSTA-8306 - 100111 - PMO */
                                                       accountingStatus); /* FPL-REF9069-030929 */
                    }                                                       /* End if */
                }                                                           /* End case Insert */
                break;

            default:
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_PerformInsUpdDelExtOp", "action");
                ret = RET_GEN_ERR_INVARG;/* REF7560 - PMO */
                break;
        }

    } /* End if */

    /* REF7560 - PMO */
    if (ret == RET_SUCCEED)
    {

        /* SME REF1402 update event scheduler for synthetic administration */
        /* REF7395 - YST - 020621 - update event scheduler for performance data */
        GEN_GetApplInfo(ApplSyntheticMinStatus, &syntheticMinStatus);
        GEN_GetApplInfo(ApplSyntheticMaxStatus, &syntheticMaxStatus);

		/* REF9883 - RAK - 040211 */
        /* Get PERF_MIN(MAX)_STATUS if they are set */
        /* If PERF_MIN(MAX)_STATUS isn't set, get the value of PERF_DEF_MIN(MAX)_STATUS */
        /* If PERF_DEF_MIN(MAX)_STATUS isn't set, get the value of SYNTHETIC_MIN(MAX)_STATUS */
        GEN_GetApplInfo(ApplPerfMinStatus, &perfMinStatus);
        GEN_GetApplInfo(ApplPerfMaxStatus, &perfMaxStatus);

        if (perfMinStatus == OpStat_None)
        {
            GEN_GetApplInfo(ApplPerfDefMinStatus, &perfDefMinStatus);

            if (perfDefMinStatus == OpStat_None)
            {
                perfMinStatus = syntheticMinStatus;
            }
            else
            {
                perfMinStatus = perfDefMinStatus;
            }
        }

        if (perfMaxStatus == OpStat_None)
        {
            GEN_GetApplInfo(ApplPerfDefMaxStatus, &perfDefMaxStatus);

            if (perfDefMaxStatus == OpStat_None)
            {
                perfMaxStatus = syntheticMaxStatus;
            }
            else
            {
                perfMaxStatus = perfDefMaxStatus;
            }
        }

        /* REF7560 - PMO / REF8996 - TEB - 031001 */
        if (GET_FLAG(extOpSt, ExtOp_NoCheckSynthAdminFlg) == FALSE)
        {
            bool processingFlg      = false;    /* REF9883 - RAK - 040211 - Init to FALSE */
            bool processingSynthFlg = false;    /* REF9883 - RAK - 040211 */
            bool processingPerfFlg  = false;    /* REF9883 - RAK - 040211 */

            switch (action)
            {
                case Delete:
                case Insert:
                    /* REF9883 - RAK - 040211 - Test on PERF_MIN(MAX)_STATUS and SYNTHETIC_MIN(MAX)_STATUS */
                    processingSynthFlg = BETWEEN_EQ(syntheticMinStatus, extOp.getStatus(), syntheticMaxStatus);
                    processingPerfFlg  = BETWEEN_EQ(perfMinStatus,      extOp.getStatus(), perfMaxStatus);
                    processingFlg      = processingSynthFlg == true || processingPerfFlg == true;
                    break;

                case Update:
                    /* REF9883 - RAK - 040211 - Test on PERF_MIN(MAX)_STATUS and SYNTHETIC_MIN(MAX)_STATUS */
                    processingSynthFlg = BETWEEN_EQ(syntheticMinStatus,    extOp.getStatus(),    syntheticMaxStatus)
                                         || BETWEEN_EQ(syntheticMinStatus, oldExtOp.getStatus(), syntheticMaxStatus);

                    processingPerfFlg = BETWEEN_EQ(perfMinStatus,    extOp.getStatus(),    perfMaxStatus)
                                        || BETWEEN_EQ(perfMinStatus, oldExtOp.getStatus(), perfMaxStatus);

                    processingFlg     =  processingSynthFlg == true || processingPerfFlg == true;
                    break;

                default:
                    break;

            } /* End switch */

            if (true == processingFlg)
            {
                DATETIME_T       dateMinSynth;
                DATETIME_T       dateMinPerfData;
                FUSDATERULE_ENUM sysFusionDateRule;
                FUSDATERULE_ENUM dateRuleEn;
                DATETIME_T       date;

                memset(&date, 0, sizeof(DATETIME_T));   /* FOR NO WARNING */

                (void)GEN_GetApplInfo(ApplFusDateRule, &sysFusionDateRule);

                /* Set dates according to the fusion date rule / REF10256 - 040608- PMO */
                dateRuleEn = DBA_GetFusDateRule(sPtf,
                                                S_Ptf_FusionDateRuleEn,
                                                S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                                NULL,
                                                0,
                                                extOpSt,
                                                ExtOp);
                DBA_GetFusDateExtOp(&dateMinSynth, dateRuleEn, extOpSt);
                if (oldExtOpSt != NULL)
                {
                    DBA_GetFusDateExtOp(&date, dateRuleEn, oldExtOpSt);
                    if (DATETIME_CMP(dateMinSynth, date) > 0)
                    {
                        dateMinSynth = date;
                    }
                }

                /* REF9883 - RAK - 040303 - Init to the same value */
                dateMinPerfData = dateMinSynth;

                /* REF9883 - RAK - 040303 - Update dateMinSynth according to A_PtfPosSet_PtfSynthFlg and A_PtfPosSet_FusDateRuleEn */
                DBA_ComputeEventSchedDateWithPPS(ppsTab, ppsNb, sPtf, extOpSt, oldExtOpSt,
                                                 EventSchedNat_SynthAdmin, &dateMinSynth);

                /* REF9883 - RAK - 040303 - Update dateMinPerfData according to A_PtfPosSet_FusDateRuleEn */
                DBA_ComputeEventSchedDateWithPPS(ppsTab, ppsNb, sPtf, extOpSt, oldExtOpSt,
                                                 EventSchedNat_PerfData, &dateMinPerfData);

                /* REF9883 - RAK - 040211 - Verify SYNTHETIC_MIN(MAX)_STATUS */
                if (processingSynthFlg == true &&
                    (IS_NULLFLD(sPtf, S_Ptf_SynthLastFinalDate) == false) &&
                    (DATETIME_CMP(dateMinSynth, GET_DATETIME(sPtf, S_Ptf_SynthLastFinalDate)) <= 0))
                {
                    DBA_DYNFLD_STP getArg = ALLOC_DYNST(Get_Arg);

                    /* REF7395 - YST - 020621 - new stored procedure used for update event scheduler */
                    if (getArg == nullptr)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
                        ret = RET_MEM_ERR_ALLOC;
                    }

                    if (ret == RET_SUCCEED)
                    {

                        SET_ID(getArg, Get_Arg_PtfId, GET_ID(extOpSt, ExtOp_PtfId));
                        SET_ID(getArg, Get_Arg_PtfPosSetId, GET_ID(extOpSt, ExtOp_PortPosSetId));
                        SET_DATETIME(getArg, Get_Arg_DateTime, dateMinSynth);               /* PMSTA-25331 - TEB - 20171018 */
                        SET_ENUM(getArg, Get_Arg_NatEn, EventSchedNat_SynthAdmin);

                        ret = DBA_Notif(EventSched, UNUSED, Get_Arg, getArg, dbiConn, DBA_SET_CONN | DBA_NO_CLOSE);

                        FREE_DYNST(getArg, Get_Arg);
                    }
                }

                /* REF7395 - YST - 020621 - update event scheduler for performance data */
                /* REF9883 - RAK - 040211 - Verify PERF_MIN(MAX)_STATUS */
                if (processingPerfFlg == true &&
                    ret == RET_SUCCEED &&
                    (IS_NULLFLD(sPtf, S_Ptf_PerfLastFinalDate) == false) &&
                    (DATETIME_CMP(dateMinPerfData, GET_DATETIME(sPtf, S_Ptf_PerfLastFinalDate)) <= 0))
                {
                    DBA_DYNFLD_STP getArg = NULL;

                    if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_EventSched");
                        ret = RET_MEM_ERR_ALLOC;
                    }

                    if (ret == RET_SUCCEED)
                    {
                        DATETIME_T PerfStartDate = dateMinPerfData;
                        SET_ID(getArg, Get_Arg_PtfId, GET_ID(extOpSt, ExtOp_PtfId));
                        SET_ID(getArg, Get_Arg_PtfPosSetId, GET_ID(extOpSt, ExtOp_PortPosSetId));
                        DATE_DatetimeMove(&PerfStartDate,
                            -1,
                            Day,
                            FALSE);                                                             /* PMSTA-39018 - AIS - 200224 */
                        SET_DATETIME(getArg, Get_Arg_DateTime, PerfStartDate);                 /* PMSTA-25331 - TEB - 20171018 */
                        SET_ENUM(getArg, Get_Arg_NatEn, EventSchedNat_PerfData);

                        /* REF9883 - RAK - 040217 - In case of insert old is NULL, send the status of modified op */
                        if (oldExtOpSt != NULL)
                        {
                            SET_ENUM(getArg, Get_Arg_Enum1, GET_ENUM(oldExtOpSt, ExtOp_StatusEn));
                        }
                        else
                        {
                            SET_ENUM(getArg, Get_Arg_Enum1, GET_ENUM(extOpSt, ExtOp_StatusEn));
                        }

                        SET_ENUM(getArg, Get_Arg_Enum2, GET_ENUM(extOpSt, ExtOp_StatusEn));

                        /* REF7594 - YST - 020624 - check performance data freezing rule and date */
						 /* PMSTA - 40506 - AIS - 200619 */
						 
                        GEN_GetApplInfo(ApplPerfDataFreezingRule, &perfDataFreezRule);
						DATETIME_T perfCompLimitDate;

                        memset(&perfCompLimitDate, 0, sizeof(DATETIME_T));
                        GEN_GetApplInfo(ApplPerfDataExtTillDate, &perfCompLimitDate.date);
						
						
                        if (perfDataFreezRule == PerfDataFreezRule_FreezDate)
                        {
                            DATETIME_T perfDataFreezDate;

                            memset(&perfDataFreezDate, 0, sizeof(DATETIME_T));
                            if ((GEN_GetApplInfo(ApplPerfDataFreezingDate, &perfDataFreezDate.date))==TRUE && DATETIME_CMP(perfCompLimitDate, perfDataFreezDate) < 0)
                            {
                                
                              perfCompLimitDate = perfDataFreezDate;
                            }
                            
                        }


						/* PMSTA-15704 - LJE - 121221 - Manage exception when the freezing date is equals to the last perf stored date */
                       /* PMSTA-20580 - LJE - 150612 - or greater */
                       if (DATETIME_CMP(dateMinPerfData, perfCompLimitDate) <= 0 &&
                                     DATETIME_CMP(perfCompLimitDate, GET_DATETIME(sPtf, S_Ptf_PerfLastFinalDate)) >= 0)
                       {
                                SET_NULL_DATETIME(getArg, Get_Arg_DateTime);                        /* PMSTA-25331 - TEB - 20171018 */
                       }
					   else if (DATETIME_CMP(dateMinPerfData, perfCompLimitDate) < 0) /* PMSTA-20580 - LJE - 150612 - No event scheduler before the freezing date */
					   {
								dateMinPerfData = perfCompLimitDate;
								SET_DATETIME(getArg, Get_Arg_DateTime, dateMinPerfData);
					   }
                        
					                     						
                        if (IS_NULLFLD(getArg, Get_Arg_DateTime) == false)                          /* PMSTA-25331 - TEB - 20171018 */
                        {
                            /* REF9125 - RAK - -031009 - one event_sched by PSP */
                            /* call with role DBA_ROLE_EVENT_SCHED_PERF_DATA */
                            ret = DBA_Notif(EventSched, DBA_ROLE_EVENT_SCHED_PERF_DATA,
                                Get_Arg, getArg, dbiConn, DBA_SET_CONN | DBA_NO_CLOSE);
                        }

                        FREE_DYNST(getArg, Get_Arg);
                    }
                }
            }
        }
    }

    /*
     *  Restore saved value
     */
    extOpSt[ExtOp_OpId] = saveOperationId;

    if ( ret != RET_SUCCEED ) /* DLA - REF9270 - 030701 */
    {
        extOpSt[ExtOp_LastUserId] = saveLastUserId;
    }

    /*
     *  Free memory allocated
     */
    (void)DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

    /* REF7560 - PMO */
    return ret;
}


RET_CODE DBA_PerformInsUpdDelExtOp(const DBA_ACTION_ENUM            action,
                                   DBA_DYNFLD_STP                   extOpSt,
                                   DBA_DYNFLD_STP                   oldExtOpSt,
                                   DBA_DYNFLD_STP                   sPtf,
                                   DBA_DYNFLD_STP *                 ppsTab,
                                   int                              ppsNb,
                                   DbiConnection                   &dbiConn,
                                   const FLAG_T                     newStep,
                                   CODE_T                           codeOp,
                                   struct AutomaticFusionStock *    autoFusStock)
{
    RET_CODE ret = RET_MEM_ERR_ALLOC;   // It might be another problem but probably around a memory error

    try
    {
        SleeveHead head;
        bool split = false;
        if (OpOpSplitRuleEn::Yes == static_cast<OpOpSplitRuleEn>(GET_ENUM(extOpSt, ExtOp_OpSplitRuleEn)) && Insert == action && (!IS_NULLFLD(extOpSt, ExtOp_SplitParentOperId)))			/* PMSTA-47417 - KOR - 07012022*/
        {            
            head.setExtOrder(extOpSt);
            split = (createChildSleeveOrder(head) == RET_SUCCEED);
                 
        }
        else if (OpOpSplitRuleEn::Yes == static_cast<OpOpSplitRuleEn>(GET_ENUM(extOpSt, ExtOp_OpSplitRuleEn)) && Delete == action && (!IS_NULLFLD(extOpSt, ExtOp_SplitParentOperId)))		/* PMSTA-47417 - KOR - 07012022*/
        {
            head.setExtOrder(extOpSt);
            deleteSleeveChildOrder(head);
        }
        else if (HierOpNatEn::HierOpNat_BlockOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpSt, ExtOp_HierOperNatEn)) && Insert == action &&
            (!IS_NULLFLD(extOpSt, ExtOp_ExecSetCriteria)))
        {
            head.setGroupExtOrder(extOpSt);
            split = (head.createGroupChildExtOrder() == RET_SUCCEED);
           
        }
        ret = _DBA_PerformInsUpdDelExtOp(action, extOpSt, oldExtOpSt, sPtf, ppsTab, ppsNb, dbiConn, newStep, codeOp, autoFusStock);

        if (RET_SUCCEED == ret && Insert == action && split) {
            head.insertExtOrder();
        }
    }
    catch (...)
    {
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }

    return ret;
}


/************************************************************************
**
** Function    : DBA_ComputeEventSchedDateWithPPS
**
** Description : Modify dateMin according to eventSchedNatEn, A_PtfPosSet_PtfSynthFlg, A_PtfPosSet_FusDateRuleEn
**				 dateMin must be already init to portfolio min value
**
** Arguments   :
**
** Return      : RET_CODE
**
** Creation    : REF9883 - RAK - 040303
**
** Last modif. : REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**               REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**
************************************************************************/
STATIC void DBA_ComputeEventSchedDateWithPPS(DBA_DYNFLD_STP *           ppsTab,
                                             const int ppsNb,
                                             const DBA_DYNFLD_STP sPtf,
                                             const DBA_DYNFLD_STP extOpSt,
                                             const DBA_DYNFLD_STP oldExtOpSt,
                                             const EVENTSCHEDNAT_ENUM eventSchedNatEn,
                                             DATETIME_T *               dateMin)
{
    int ppsIdx = 0;
    FUSDATERULE_ENUM dateRuleEn;
    DATETIME_T date, date1;

    memset(&date, 0, sizeof(DATETIME_T));   /* FOR NO WARNING */

    /* For ES-PerfData test all pps only if there is already PerfData stored */
    /* For ES-SynthAdmin test flag of each pps */
    if (eventSchedNatEn == EventSchedNat_SynthAdmin ||
        (eventSchedNatEn == EventSchedNat_PerfData  && IS_NULLFLD(sPtf, S_Ptf_PerfLastFinalDate) == false))
    {
        /* PPS */   /* find min fus. date  */
        for (ppsIdx = 0; ppsIdx < ppsNb; ppsIdx++)
        {
            /* For ES-PerfData test all pps only if there is already PerfData stored */
            /* For ES-SynthAdmin test flag of each pps */
            if ((eventSchedNatEn == EventSchedNat_PerfData) ||
                (eventSchedNatEn == EventSchedNat_SynthAdmin && GET_FLAG(ppsTab[ppsIdx], A_PtfPosSet_PtfSynthFlg) == TRUE))
            {
                /* REF10256 - 040608- PMO */
                dateRuleEn = DBA_GetFusDateRule(ppsTab[ppsIdx],
                                                A_PtfPosSet_FusDateRuleEn,
                                                A_PtfPosSet_OldFusDateRuleEn,   /* REF10785 - 041129 - PMO */
                                                NULL,
                                                0,
                                                extOpSt,
                                                ExtOp);

                /* REF10256 - 040608- PMO */
                DBA_GetFusDateExtOp(&date, dateRuleEn, extOpSt);
                if (oldExtOpSt != NULL)
                {
                    DBA_GetFusDateExtOp(&date1, dateRuleEn, oldExtOpSt);
                    if (DATETIME_CMP(date, date1) > 0)
                    {
                        date = date1;
                    }
                }

                if (DATETIME_CMP((*dateMin), date) > 0)
                {
                    (*dateMin) = date;
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_UpdOperationById()
**
**  Description :   Update an operation buy, sell, ...
**		    This function converts first the operation into an
**		    'extended' operation, which is updated into the database.
**		    It can only be called by dbaproc.c and assures people
**		    can still update an operation Buy, sell, etc.
**
**  Arguments   :   object	 the request corresponding object
**                  inputSt      the input dynamic structure format
**                  inputData    the pointer on the input dynamic structure
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**				 received messages informations.
**
**  Return      :   RET_SUCCEED 	if ok
**		    RET_GEN_ERR_INVARG	error in arguments
**		    RET_DBA_ERR_MD	error in meta-dictionary
**		    RET_MEM_ERR_ALLOC	error in memory allocation
**		    RET_DBA_ERR_NODATA  error in retrieving or constructing data
**
**  Creation    :   DVP029 - 170496 - DED
**  Modif.      :   ROI - 970407 - DVP417
**                  GRD - 000509 - REF4714.
**                  REF7560 - 020826 - PMO : Order Management Entity light project: database infrastructure
**                  REF9301 - 040219 - PMO : this message appear sometimes after update field on child and
**                                           block order:The row (id=1234567) into the table ext_order has
**                                           been modified by someone/something else in the meantime
**                  REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**                  HFI-PMSTA-46035-210908  : Replace ExtOp_TimeStampNew by ExtOp_TimeStamp. ExtOp_TimeStamp is now already modified by the procedure.
**
*************************************************************************/
RET_CODE DBA_UpdOperationById(OBJECT_ENUM object,
                              DBA_DYNST_ENUM inputSt,
                              DBA_DYNFLD_STP inputData,
                              DbiConnectionHelper& dbiConnHelper)
{
    OPNAT_ENUM operNat           = OpNat_None;
    RET_CODE ret                 = RET_SUCCEED;
    DBA_DYNFLD_STP extOpSt       = NULL;
    FLAG_T localTranFlg          = FALSE;
    DbiConnection&      dbiConn  = *dbiConnHelper.getConnection();

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdOperationById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get corresponding OPNAT_ENUM for object operation record */
    ret = OPE_DictEnumToOperNat(object, &operNat);

    if (ret != RET_SUCCEED || operNat == OpNat_None)
    {
        MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
        return(RET_DBA_ERR_MD);
    }

    /* Memory allocation for extended operation record */
    if ((extOpSt = ALLOC_DYNST(ExtOp)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
        return(RET_MEM_ERR_ALLOC);
    }

    /* Transform the operation record into an 'extended' operation record */
    ret = OPE_OpToExtOp(inputData, operNat, extOpSt, FALSE);         /*  FPL-REF9215-030811  Add last parameter  */

    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
        FREE_DYNST(extOpSt, ExtOp);
        return(RET_DBA_ERR_NODATA);
    }

    /* Update extended operation into the database */
    SET_ENUM(extOpSt, ExtOp_OpActionEn, ExtOpActionEn_ToUpdate);    /* DVP417 / REF7560 - PMO */

    if ((dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        (GET_ENUM(extOpSt, ExtOp_ParOpNatEn) != ParOpNat_None && GET_ENUM(extOpSt, ExtOp_ParOpNatEn) != ParOpNat_NoGrouping)) /* PMSTA-18601 - DDV - 141212 - Fix No grouping mode */
    {
        DBA_ACCESS_ST multiAccessSt;
        DBA_ERRMSG_HEADER_ST msgStructHead;

        /* insertion block order in block mode */
        multiAccessSt.data   = extOpSt;
        multiAccessSt.action = Update;
        multiAccessSt.role   = UNUSED;
        multiAccessSt.object = EOp;
        multiAccessSt.entity = ExtOp;

        /*
         * As we want to use DBA_NO_ERROR, we have to open a transaction before calling the MultiAccess.
         * REF4714.
         */

		if (dbiConn.isInTransaction() == false) /* DLA - REF5695 - 011030 -> <= � la place de == */
        {
            ret = dbiConn.beginTransaction();

            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(extOpSt, ExtOp);
                return ret;
            }

            localTranFlg = TRUE;
        }

        ret = DBA_HandleOperTabByBlock(dbiConn, &multiAccessSt, 0, 0, 1,
                                       DBA_NO_ERROR | DBA_SET_CONN | DBA_NO_CLOSE);

        if (ret != RET_SUCCEED)
        {
            if (localTranFlg == TRUE)
            {
                dbiConn.endTransaction(FALSE);        /* Rollback. */
            }
        }
        else
        {
            if (localTranFlg == TRUE)
            {
                dbiConn.endTransaction(TRUE);        /* Commit */
            }
        }
    }
    else
    {
        ret = DBA_Update2(EOp, UNUSED, ExtOp, extOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
    }


    /* REF9301 - 040219 - PMO */
    if (ret == RET_SUCCEED)
    {

        /**** DVP291 ****/
        /* If Block Mode isn't activated */
        if (dbiConn.getConnStructPtr()->blockMode == FALSE)
        {
            /* Copy operation Id */
            COPY_DYNFLD(inputData, inputSt, 0, extOpSt, ExtOp, ExtOp_OpId);

            /* REF8844 - LJE - 030415 */
            if (object == BuyOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, BuyOp_Cd,            extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, BuyOp_SrcCd,         extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, BuyOp_AcctCd,        extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, BuyOp_CreationTime,  extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, BuyOp_LastModifDate, extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, BuyOp_TimeStamp,     extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */  
            }
            else if (object == SellOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, SellOp_Cd,           extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, SellOp_SrcCd,        extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, SellOp_AcctCd,       extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, SellOp_CreationTime, extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, SellOp_LastModifDate, extOpSt, ExtOp, ExtOp_AudModifDate);      /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, SellOp_TimeStamp,    extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == IncOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, IncOp_Cd,            extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, IncOp_SrcCd,         extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, IncOp_AcctCd,        extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, IncOp_CreationTime,  extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, IncOp_LastModifDate, extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, IncOp_TimeStamp,     extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == InvestOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, InvestOp_Cd,             extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, InvestOp_SrcCd,          extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, InvestOp_AcctCd,         extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, InvestOp_CreationTime,   extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, InvestOp_LastModifDate,  extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, InvestOp_TimeStamp,      extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == WithdrOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, WithdrOp_Cd,             extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, WithdrOp_SrcCd,          extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, WithdrOp_AcctCd,         extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, WithdrOp_CreationTime,   extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, WithdrOp_LastModifDate,  extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, WithdrOp_TimeStamp,      extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == FtOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, FtOp_Cd,             extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, FtOp_SrcCd,          extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, FtOp_AcctCd,         extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, FtOp_CreationTime,   extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, FtOp_LastModifDate,  extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, FtOp_TimeStamp,      extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == AdjustOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, AdjustOp_Cd,             extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, AdjustOp_SrcCd,          extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, AdjustOp_AcctCd,         extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, AdjustOp_CreationTime,   extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, AdjustOp_LastModifDate,  extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, AdjustOp_TimeStamp,      extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == ShareIssOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_Cd,               extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_SrcCd,            extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_AcctCd,           extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_CreationTime,     extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_LastModifDate,    extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, ShareIssOp_TimeStamp,        extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == ShareRedmOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_Cd,              extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_SrcCd,           extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_AcctCd,          extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_CreationTime,    extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_LastModifDate,   extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, ShareRedmOp_TimeStamp,       extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == TransfOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, TransfOp_Cd,             extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, TransfOp_SrcCd,          extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, TransfOp_AcctCd,         extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, TransfOp_CreationTime,   extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, TransfOp_LastModifDate,  extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, TransfOp_TimeStamp,      extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == BpTransfOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_Cd,               extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_SrcCd,            extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_AcctCd,           extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_CreationTime,     extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_LastModifDate,    extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, BpTransfOp_TimeStamp,        extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == LockOpEnt)
            {
                COPY_DYNFLD(inputData, inputSt, LockOp_Cd,               extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, LockOp_SrcCd,            extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, LockOp_AcctCd,           extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, LockOp_CreationTime,     extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, LockOp_LastModifDate,    extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, LockOp_TimeStamp,        extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == BookAdjOpEnt )
            {
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_Cd,            extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_SrcCd,         extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_AcctCd,        extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_CreationTime,  extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_LastModifDate, extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, BookAdjOp_TimeStamp,     extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == PtfTransfOpEnt )
            {
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_Cd,              extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_SrcCd,           extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_AcctCd,          extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_CreationTime,    extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_LastModifDate,   extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, PtfTransfOp_TimeStamp,       extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
            else if (object == InitOpEnt )
            {
                COPY_DYNFLD(inputData, inputSt, InitOp_Cd,               extOpSt, ExtOp, ExtOp_Cd);
                COPY_DYNFLD(inputData, inputSt, InitOp_SrcCd,            extOpSt, ExtOp, ExtOp_SrcCd);
                COPY_DYNFLD(inputData, inputSt, InitOp_AcctCd,           extOpSt, ExtOp, ExtOp_AcctCd);
                COPY_DYNFLD(inputData, inputSt, InitOp_CreationTime,     extOpSt, ExtOp, ExtOp_CreationTime);
                COPY_DYNFLD(inputData, inputSt, InitOp_LastModifDate,    extOpSt, ExtOp, ExtOp_AudModifDate);       /* REF9301 - 040219 - PMO   */
                COPY_DYNFLD(inputData, inputSt, InitOp_TimeStamp,        extOpSt, ExtOp, ExtOp_TimeStamp);          /* REF11780 - 100406 - PMO  */
            }
        }
    }

    /* Free memory allocation for extended operation */
    FREE_DYNST(extOpSt, ExtOp);

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_InsExtOpByIdAndFuse2()
**
**  Description :   Insert an extended operation into the database
**		    and launch automatic fusion
**
**  Arguments   :   inputSt      the input dynamic structure format
**                  extOpSt    	 the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**                  copyFlag     if true, avoid executions and order operations.
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**		    RET_DBA_ERR_NODATA		error in retrieving or building data
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error
**
**  Creation    :   REF437 - 980611 -SME -
**  Last modif. :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
*************************************************************************/
RET_CODE DBA_InsExtOpByIdAndFuse2(DBA_DYNST_ENUM        ,
                                  DBA_DYNFLD_STP        extOpSt,
                                  DbiConnection &       dbiConn,
                                  FLAG_T                copyFlag)
{
    return DBA_CommonExtOpByIdAndFuse(extOpSt,
                                      dbiConn,
                                      copyFlag,
                                      NULL,
                                      DBA_InsExtOpById);
}

/************************************************************************
**
**  Function    :   DBA_InsExtOpByIdAndFuse()
**
**  Description :   Insert an extended operation into the database
**		    and lanch automatic fusion
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  extOpSt    	 the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**		    RET_DBA_ERR_NODATA		error in retrieving or building data
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error
**
**  Creation    :   REF437 - 980611 -SME -
**
*************************************************************************/
RET_CODE DBA_InsExtOpByIdAndFuse(OBJECT_ENUM object,
                                 DBA_DYNST_ENUM inputSt,
                                 DBA_DYNFLD_STP extOpSt,
                                 DbiConnectionHelper& dbiConnHelper)
{
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();
    RET_CODE status;

    if (GET_FLAG(extOpSt, ExtOp_InSessionFlg) == TRUE)
    {
        DBA_DYNFLD_STP  ptfPtr   = nullptr;
        FLAG_T          allocFlg = FALSE;

        if (!IS_NULLFLD(extOpSt, ExtOp_DbId))
        {
            SET_ID(extOpSt, ExtOp_DraftOrderId, GET_ID(extOpSt, ExtOp_DbId));
        }

        /* PMSTA09451 - DDV - 100308 - Update begin_d of ExtOperation. It is used to load orders for FinFct */
        if ((GET_EXTENSION_PTR(extOpSt, ExtOp_A_Ptf_Ext)) != NULL)
        {
            ptfPtr = *(GET_EXTENSION_PTR(extOpSt, ExtOp_A_Ptf_Ext));
        }

        if (ptfPtr == NULL)
        {
            DBA_GetPtfById(GET_ID(extOpSt, ExtOp_PtfId), TRUE, &allocFlg, &ptfPtr,
                                  DBA_GetHierOptiPtr(), UNUSED, nullptr);
        }

        DBA_UpdExtOpBeginD(extOpSt, nullptr, ptfPtr);

        if (allocFlg == TRUE)
        {
            FREE_DYNST(ptfPtr, A_Ptf);
        }

        status = dbiConnHelper.dbaInsert(object, DBA_ROLE_RECONCILE_STRATEGY, extOpSt);

        if (!IS_NULLFLD(extOpSt, ExtOp_DraftOrderId))
        {
            SET_ID(extOpSt, ExtOp_DbId, GET_ID(extOpSt, ExtOp_DraftOrderId));
        }
    }
    else
    {
        status = DBA_InsExtOpByIdAndFuse2(inputSt, extOpSt, dbiConn, FALSE);
    }

    return status;
}


/************************************************************************
**
**  Function    :   DBA_UpdExtOpBeginD()
**
**  Description :   Insert an order extended operation into the database
**		            It is inserted into ext_operation table
**
**  Arguments   :   extOpSt    	 the pointer on the extended operation record
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**		    RET_DBA_ERR_NODATA		error in retrieving or building data
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error
**
**  Creation    :   PMSTA09451 - DDV - 100305
**
*************************************************************************/
EXTERN RET_CODE DBA_UpdExtOpBeginD(DBA_DYNFLD_STP extOpSt, DBA_DYNFLD_STP sPtfParam, DBA_DYNFLD_STP aPtfParam)
{
    DATETIME_T       beginDate;
    DBA_DYNFLD_STP   sPtf=NULLDYNST;
    RET_CODE         ret=RET_SUCCEED;
    FUSDATERULE_ENUM fusionDateRule = FusDateRule_None;
    DbiConnection *  dbiConn = nullptr;

    /* PMSTA09451 - DDV - 100305 - Update begin date of ext operation before inserting it into ext_operation table */
    /* Load fusion date rule  */
    if (aPtfParam != NULLDYNST)
    {
        fusionDateRule = DBA_GetFusDateRule(aPtfParam,
                                            A_Ptf_FusionDateRuleEn,
                                            A_Ptf_OldFusionDateRuleEn,
                                            NULL,
                                            0,
                                            extOpSt,
                                            ExtOp);
    }
    else if (sPtfParam != NULLDYNST)
    {
        fusionDateRule = DBA_GetFusDateRule(sPtfParam,
                                            S_Ptf_FusionDateRuleEn,
                                            S_Ptf_OldFusionDateRuleEn,
                                            NULL,
                                            0,
                                            extOpSt,
                                            ExtOp);
    }
    else if (IS_NULLFLD(extOpSt, ExtOp_PtfId) == false)
    {
        /* Load portfolio */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            FREE_DYNST(sPtf, S_Ptf);
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }

        ret = OPE_GetPtfPps(extOpSt,
                            &sPtf,
                            NULLDYNSTPTR,
                            NULL,
                            *dbiConn);

        if (ret == RET_SUCCEED)
        {
            /* Load fusion date rule  */
            fusionDateRule = DBA_GetFusDateRule(sPtf,
                                                S_Ptf_FusionDateRuleEn,
                                                S_Ptf_OldFusionDateRuleEn,
                                                NULL,
                                                0,
                                                extOpSt,
                                                ExtOp);

        }
        DBA_EndConnection(&dbiConn); /* PMSTA09681 - DDV - 100420 */
        FREE_DYNST(sPtf, S_Ptf);
    }

    DBA_GetFusDateExtOp(&beginDate, fusionDateRule, extOpSt);
    SET_DATETIME(extOpSt, ExtOp_BeginDate, beginDate);

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadPPS()
**
**  Description :   Load all informations for a portfolio position set
**
**  Arguments   :   outputPtf       Portfolio position set allocated if the pointer is null
**                  portfolioId     Id of the portfolio position set to retrieve
**
**  Return      :   RET_SUCCEED         if ok
**		            RET_MEM_ERR_ALLOC   error in memory allocation
**                  Other value returned by the database
**
**  Creation    :   REF10568 - 040825 - PMO : When loading an  operation, the field adj_portfolio_id is lost
**
*************************************************************************/
RET_CODE DBA_LoadPPS(DBA_DYNFLD_STP * outputPtf, const ID_T portfolioId)
{
    RET_CODE        ret              = RET_SUCCEED;
    int             outputLocalAlloc = FALSE;           /* Flag if local allocation for output structure */
    DBA_DYNFLD_STP inputPtf;            /* Input argument                                */

    /* Memory allocation for input and output structure */
    if ((inputPtf = ALLOC_DYNST(S_PtfPosSet)) == NULL)
    { /* Error */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_PtfPosSet");
        ret = RET_MEM_ERR_ALLOC;
    }

    /* Allocate mermory for output structure if need */
    if (ret == RET_SUCCEED && NULL == *outputPtf)
    {       /* Allocate memory */
        if ((*outputPtf = ALLOC_DYNST(A_PtfPosSet)) == NULL)
        {   /* Error */
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_PtfPosSet");
            ret = RET_MEM_ERR_ALLOC;
        }
        else
        { /* Ok */
            outputLocalAlloc = TRUE;
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* Fill key of structure Portfolio Position Set */
        SET_ID(inputPtf, S_PtfPosSet_Id, portfolioId);
        ret = DBA_Get2(PtfPosSet,
                       UNUSED,
                       S_PtfPosSet,
                       inputPtf,
                       A_PtfPosSet,
                       outputPtf,
                       UNUSED,
                       NULL,
                       NULL);
    }

    if (inputPtf != NULL)
    {
        FREE_DYNST(inputPtf, S_PtfPosSet);
    }

    if (ret != RET_SUCCEED)
    {       /* Error */
        if (outputLocalAlloc == TRUE)
        {   /* Free only if local allocation */
            FREE_DYNST((*outputPtf), A_PtfPosSet);
        }
    }

    return (ret);
}


/************************************************************************
**
**  Function    :   DBA_LoadPtf()
**
**  Description :   Load all informations for a portfolio
**
**  Arguments   :   outputPtf       Portfolio allocated if the pointer is null
**                  portfolioId     Id of the portfolio to retrieve
**
**  Return      :   RET_SUCCEED         if ok
**		            RET_MEM_ERR_ALLOC   error in memory allocation
**                  Other value returned by the database
**
**  Creation    :   REF9350 - TEB - 030806 : Exclude cash portfolio from the fusion process
**
*************************************************************************/
RET_CODE DBA_LoadPtf(DBA_DYNFLD_STP * outputPtf, const ID_T portfolioId, int * connectNo) /* DLA - REF11538 - 051111 */
{
    RET_CODE    ret              = RET_SUCCEED;
    int         outputLocalAlloc = FALSE;   /* Flag if local allocation for output structure */
    int         options          = UNUSED;  /* DLA - REF11538 - 051111 */

    if (connectNo != NULL && *connectNo > NO_VALUE )     /* DLA - REF11538 - 051111 */ /*   FPL-PMSTA06305-080508   */
    {
        DbiConnection * dbiConn = DBA_GetDbiConnFromConnectNo(*connectNo);
        if (dbiConn == nullptr)
        {
            return RET_DBA_ERR_CONNOTFOUND;
        }
        options = DBA_SET_CONN | DBA_NO_CLOSE;
    }


    /* Memory allocation for input and output structure */
    DBA_DYNFLD_STP inputPtf = ALLOC_DYNST(S_Ptf);            /* Input argument */
    if (nullptr == inputPtf)
    { /* Error */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Ptf");
        ret = RET_MEM_ERR_ALLOC;
    }

    /* Allocate mermory for output structure if need */
    if (ret == RET_SUCCEED && NULL == *outputPtf)
    {       /* Allocate memory */
        if ((*outputPtf = ALLOC_DYNST(A_Ptf)) == NULL)
        {   /* Error */
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Ptf");
            ret = RET_MEM_ERR_ALLOC;
        }
        else
        { /* Ok */
            outputLocalAlloc = TRUE;
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* Fill key of structure Portfolio */
        SET_ID(inputPtf, S_Ptf_Id, portfolioId);
        ret = DBA_Get2(Ptf,
                       UNUSED,
                       S_Ptf,
                       inputPtf,
                       A_Ptf,
                       outputPtf,
                       options,             /* DLA - REF11538 - 051111 */
                       connectNo,           /* DLA - REF11538 - 051111 */
                       NULL);
    }

    FREE_DYNST(inputPtf, S_Ptf);

    if (ret != RET_SUCCEED)
    {       /* Error */
        if (outputLocalAlloc == TRUE)
        {   /* Free only if local allocation */
            FREE_DYNST((*outputPtf), A_Ptf);
        }
    }

    return (ret);
}



/************************************************************************
**
**  Function    :   DBA_CommonInsUpdExtOpBy()
**
**  Description :   Common code of DBA_InsExtOpById and DBA_UpdExtOpById
**                  - Some checks
**                  - Load of Portfolio and PPS
**                  - Define : noCheckImpactFlag, fusionDateRulePtr, checkParentPtr
**                  - Set some fields in extOpSt
**
**  Arguments   :   functionName        Name of the function caller
**                  extOpSt             Pointer on the extended operation record
**                  noCheckImpactFlag
**                  portfolioPtr        Portfolio loaded
**                  pps                 Pps loaded
**                  ppsNbPtr            Number of pps loaded
**                  fusionDateRulePtr   Fusion date rule
**                  checkParentPtr
**                  connectNo           Connection number
**                  msgStructPtr        Pointer on a structure which will contain
**                                      received messages informations.
**
**  Return      :   Ret code
**
**  Creation    :   REF9350 - TEB - 030806 : Exclude cash portfolio from the fusion process
**
**  Last modif. :   REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**                  REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**                  PMSTA-13078 - 250112 - PMO : Do not allow the importation of a portfolio transfer where the source and the target portfolio are the same
*************************************************************************/
STATIC RET_CODE DBA_CommonInsUpdExtOpBy(const char *            functionName,
                                        DBA_DYNFLD_STP          extOpSt,
                                        FLAG_T *                noCheckImpactFlag,
                                        DBA_DYNFLD_STP *        portfolioPtr,
                                        DBA_DYNFLD_STP * *      pps,
                                        int *                   ppsNbPtr,
                                        FUSDATERULE_ENUM *      fusionDateRulePtr,
                                        ENUM_T *                checkParentPtr,
                                        DbiConnection&          dbiConn)
{
    RET_CODE ret       = RET_SUCCEED;
    *noCheckImpactFlag = FALSE;
    *fusionDateRulePtr = FusDateRule_None;


    /* Check arguments */
    if (extOpSt == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, functionName, "extOpSt");
        ret = RET_GEN_ERR_INVARG;
    }

    if (ret == RET_SUCCEED)
    {
        /* BUG198 - 961108 - DED */
        if (IS_NULLFLD(extOpSt, ExtOp_PtfId) == true &&
			GET_ENUM(extOpSt, ExtOp_NatureEn) != OpNat_Combined) /* PMSTA06760 - DDV - 080702 */
        {
            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-20038", nullptr,
                                                   TextType, "portfolio",
                                                   CodeType, GET_CODE(extOpSt, ExtOp_Cd),
                                                   TextType, "<unknown>"));
            ret = RET_SRV_LIB_ERR_TRIGGER_MSG;
        }
    }

    if (ret == RET_SUCCEED)
    {
        /* REF3010 - SSO - 981110 no check/impact done if copy op or modif curr */
        *noCheckImpactFlag = GET_FLAG(extOpSt, ExtOp_NoCheckImpactFlg);
    }

    if (ret == RET_SUCCEED &&
		IS_NULLFLD(extOpSt, ExtOp_PtfId) == false) /* PMSTA06760 - DDV - 080702 */
    {
        /* BUG088 - 960808 - DED */
        /* DVP238 - 961108 - DED */
        /* Load portfolio */

        ret = OPE_GetPtfPps(extOpSt,
                            portfolioPtr,
                            pps,
                            ppsNbPtr,
                            dbiConn);
    }

    if (ret == RET_SUCCEED &&
		IS_NULLFLD(extOpSt, ExtOp_PtfId) == false) /* PMSTA06760 - DDV - 080702 */
    {
        /* check portfolio currency */
        if (GET_ID(extOpSt, ExtOp_PtfCurrId) != ZERO_ID &&
            (GET_ID(extOpSt, ExtOp_PtfId) == ZERO_ID || IS_NULLFLD(extOpSt, ExtOp_PtfId) == true))
        {
            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-20035", nullptr,
                                                   TextType, "Portfolio",
                                                   TextType, "Portfolio Currency",
                                                   CodeType, GET_CODE(extOpSt, ExtOp_Cd),
                                                   CodeType, GET_CODE((*portfolioPtr), S_Ptf_Cd)));
            ret = RET_SRV_LIB_ERR_TRIGGER_MSG;
        }
        else if (GET_ID(extOpSt, ExtOp_PtfCurrId) != ZERO_ID &&  /* DVP439 - XDI - 970527 */
            (GET_ID(extOpSt, ExtOp_PortPosSetId) != 0) &&
                 CMP_DYNFLD(extOpSt, (*pps)[0], ExtOp_PtfCurrId, A_PtfPosSet_CurrId, GET_FLD_TYPE(S_PtfPosSet, S_PtfPosSet_CurrId)) != 0)
        {
            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-20036", nullptr,
                                                   TextType, "Portfolio Currency",
                                                   TextType, "currency of the portfolio position set",
                                                   CodeType, GET_CODE(extOpSt, ExtOp_Cd),
                                                   CodeType, GET_CODE((*portfolioPtr), S_Ptf_Cd)));
            ret = RET_SRV_LIB_ERR_TRIGGER_MSG;
        }
        else if ((GET_ID(extOpSt, ExtOp_PtfCurrId) != ZERO_ID) &&
            (GET_ID(extOpSt, ExtOp_PortPosSetId) == 0) &&
                 CMP_DYNFLD(extOpSt, (*portfolioPtr), ExtOp_PtfCurrId, S_Ptf_CurrId, GET_FLD_TYPE(S_Ptf, S_Ptf_CurrId)) != 0)
        {
            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-20036", nullptr,
                                                   TextType, "Portfolio Currency",
                                                   TextType, "currency of the portfolio",
                                                   CodeType, GET_CODE(extOpSt, ExtOp_Cd),
                                                   CodeType, GET_CODE((*portfolioPtr), S_Ptf_Cd)));
            ret = RET_SRV_LIB_ERR_TRIGGER_MSG;
        }

        /* REF9350 - TEB - 030806 */
        if (ret == RET_SUCCEED)
        {
            DBA_DYNFLD_STP outputPtf = NULL;

            /* Load all informations for this portfolio */
            ret = DBA_LoadPtf(&outputPtf, GET_ID(extOpSt, ExtOp_PtfId), &dbiConn.getId()); /* DLA - REF11538 - 051111 */

            if (ret == RET_SUCCEED)
            {
                if (PtfNat_WithoutFusion == static_cast<PTFNAT_ENUM>(GET_ENUM(outputPtf, A_Ptf_NatEn)))
                { /* Error */
                    FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, NULL, "Unable to insert or update an operation when the portfolio has the nature \"Portfolio cash without fusion\""));
                    ret = RET_SRV_LIB_ERR_TRIGGER_MSG;  /* PMSTA-13078 - 250112 - PMO */
                }
            }

            if (outputPtf != NULL)
            {
                FREE_DYNST(outputPtf, A_Ptf);
            }

        }

        /* REF9350 - TEB - 030806 */
        /* Also check for portfolio transfer if dest ptf isn t nature WithoutFusion */
        if (ret             == RET_SUCCEED &&
            OpNat_PtfTransf == static_cast<OPNAT_ENUM>(GET_ENUM(extOpSt, ExtOp_NatureEn)) &&
            false           == IS_NULLFLD(extOpSt, ExtOp_AdjPtfId))
        {
            DBA_DYNFLD_STP adjPtf = NULL;

            /* Load all informations for this portfolio */
            ret = DBA_LoadPtf(&adjPtf, GET_ID(extOpSt, ExtOp_AdjPtfId), &dbiConn.getId()); /* DLA - REF11538 - 051111 */

            if (ret == RET_SUCCEED)
            {
                if (PtfNat_WithoutFusion == static_cast<PTFNAT_ENUM>(GET_ENUM(adjPtf, A_Ptf_NatEn)))
                { /* Error */
                    FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, NULL, "Unable to insert or update a transfer operation when the destination portfolio has the nature \"Portfolio cash without fusion\""));
                    ret = RET_SRV_LIB_ERR_TRIGGER_MSG;  /* PMSTA-13078 - 250112 - PMO */
                }
            }

            if (adjPtf != NULL)
            {
                FREE_DYNST(adjPtf, A_Ptf);
            }

            /* PMSTA-13078 - 250112 - PMO */
            if (ret == RET_SUCCEED &&
                0   == CMP_ID(GET_ID(extOpSt, ExtOp_PtfId), GET_ID(extOpSt, ExtOp_AdjPtfId)))
            { /* Error */
                FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, NULL, "A portfolio transfer must not have the same source and target portfolio"));
                ret = RET_SRV_LIB_ERR_TRIGGER_MSG;
            }
        }

        if (ret != RET_SUCCEED)
        { /* Error */
            (void)DBA_FreeDynStTab(*pps, *ppsNbPtr, A_PtfPosSet);
            FREE_DYNST((*portfolioPtr), S_Ptf);
        }
    } /* End if */

    if (ret == RET_SUCCEED)
    {
        /* REF7560 - DDV - If end date is null, set it with MAGIC_END_DATE */
        if (IS_NULLFLD(extOpSt, ExtOp_EndDate) == true)
        {
            DATETIME_T magicEndDateTime;

            magicEndDateTime.time = 0;
            magicEndDateTime.date = MAGIC_END_DATE;
            SET_DATETIME(extOpSt, ExtOp_EndDate, magicEndDateTime);
        }
    }

    if (ret == RET_SUCCEED)
    {
        DATETIME_T beginDate;

        /* Load fusion date rule / REF10256 - 040608- PMO */
        *fusionDateRulePtr = DBA_GetFusDateRule(*portfolioPtr,
                                                S_Ptf_FusionDateRuleEn,
                                                S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                                NULL,
                                                0,
                                                extOpSt,
                                                ExtOp);
        DBA_GetFusDateExtOp(&beginDate, *fusionDateRulePtr, extOpSt);
        SET_DATETIME(extOpSt, ExtOp_BeginDate, beginDate);

        *checkParentPtr = GET_ENUM(extOpSt, ExtOp_CheckParentEn);

        /* PMSTA-19835 - DDV - 150123 - Always set NoImpact for operatoin with NoGrouping */
        if (static_cast<PAROPNAT_ENUM> (GET_ENUM(extOpSt, ExtOp_ParOpNatEn)) == ParOpNat_NoGrouping)
        {
            SET_ENUM(extOpSt, ExtOp_CheckParentEn, CheckParent_Disable);
        }
        else if (static_cast<PAROPNAT_ENUM> (GET_ENUM(extOpSt, ExtOp_ParOpNatEn)) != ParOpNat_CombinedOrder &&     /* PMSTA06760 - DDV - 080702 - Don't change Check parent value for combined order and child combined order */
                 static_cast<PAROPNAT_ENUM> (GET_ENUM(extOpSt, ExtOp_ParOpNatEn)) != ParOpNat_ChildCombinedOrder)
        {
            SET_ENUM(extOpSt, ExtOp_CheckParentEn, CheckParent_Enable); /* always save operation with check */
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_InsExtOpById()
**
**  Description :   Insert an extended operation into the database
**		    Performs also various treatments for reversal and
**		    execution operations.  Performs also an audit of
**		    the insert if necessary.
**		    A fusion is launched if insert isn't a part of an update.
**
**  Arguments   :   extOpSt    	 the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               recieved messages informations.
**                  isCopyFlg    if true, avoid executions and order operations.
**                  autoFusStock
**
**  Return      :   RET_SUCCEED     if ok.
**		    RET_GEN_ERR_INVARG		error in arguments.
**		    RET_DBA_ERR_NODATA		error in retrieving or building data.
**		    RET_MEM_ERR_ALLOC		error in memory allocation.
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error.
**
**  Creation    :   DVP029  - 170496 - DED : Operation/Position modifications.
**
**  Last modif. :   DVP058  - 960520 - DED : FusServerName -> FusServerId.
**		    DVP029  - 960524 - DED : If PosNat = AttachedBp, copy openOperId into CloseOperId.
**		    DVP029  - 960612 - DED : Add management of reversal operations.
**		    BUG088  - 960808 - DED : Add test on portfolio currency.
**		    DVP168  - 960816 - DED : Add management of execution operation.
**		    DVP202  - 960910 - DED : Add audit of operations.
**		    DVP180  - 960930 - DED : Close operation if necessary.
**		    BUG177  - 961015 - DED : Change notification of fusion server.
**		    DVP238  - 961104 - DED : Replace A_Ptf by S_Ptf for optimization.
**		    BUG198  - 961108 - DED : Add check on portfolio Id.
**		    DVP291  - 961204 - PEC : Block mode handling (Dynamic SQL).
**		    DVP342  - 970210 - PEC : Gestion des ordres.
**          DVP508  - 970619 - GRD : Avoid creation of orders/execution operation if flag TRUE. (Copy operation).
**		    REF523  - 971024 - DED : Don't free revExtOpSt if not allocated.
**		    REF998  - 971205 - DED : Display portfolio code if error.
**		    REF1455 - 980326 - DED : Use SET_NULL_CODE.
**          REF1560 - 980408 - GRD : Crashes when copying PPS.
**          REF1997 - 980430 - DED : Copy code in to execute child orders
**          REF437  - 980610 - SME : No launch fusion in this function, replace DBA_Update2, DBA_Delete2,DBA_Insert2
**                                   by DBA_UpdExtOpById,DBA_DelExtOpById,DBA_InsExtOpById.
**		    REF2631 - 980902 - DED : Check security on closing periods
**          REF2807 - 980915 - GRD : Added connection info when used inside a transaction.
**          REF1402 - 981026 - SME : Update event scheduler for synthetic administration.
**          REF2956 - 981104 - GRD : Transaction integrity problem in mode block.
**          REF3846 - 990805 - SME : Do not launch fusion with status_e < accounting
**          REF4204 - 000324 - GRD : Take subscriptions into account.
**          REF7560 - 020813 - PMO : Order Management Entity light project: database infrastructure
**          REF7496 - 020822 - PMO : The reverse operation code of the reversed operation is always
**                                   equal to the operation code and not to the source code
**          REF7475 - 020829 - PMO : FlexeLint message
**          REF9350 - TEB - 030806 : Exclude cash portfolio from the fusion process
**          REF8706 - TEB - 030815 : No error message when you try to save an order after a restart of the data server
**          REF9333 - TEB - 030825 : Bad coding
**          FPL-REF8803-030929     : It's possible to modify the same order from two op-list view
**          REF9301 - 040219 - PMO : this message appear sometimes after update field on child and block order:
**                                   The row (id=1234567) into the table ext_order has been modified by
**                                   someone/something else in the meantime
**          REF10181 - 041122 - PMO : Bizard reverse code generated when you specified it in the import file
**          PMSTA-1354 - 170107 - PMO : On error, the fusion server can crash while notifying the dispatcher
**
*************************************************************************/
STATIC RET_CODE DBA_InsExtOpById(DBA_DYNFLD_STP extOpSt,
                                 DbiConnection& dbiConn,
                                 FLAG_T isCopyFlg,
                                 struct AutomaticFusionStock *  autoFusStock)
{
    DBA_DYNFLD_STP portfolio       = NULL,
                   revExtOpSt      = NULL,
                   execExtOpSt     = NULL,
                   remainingExtOp = NULL;
    DBA_DYNFLD_STP * pps   = NULL;
    int ppsNb = 0;
    DBA_DYNFLD_STP * insertExtOpChild = NULL,
    * updateExtOpChild = NULL, * remainingExtOpChild = NULL;
    int insUpdExtOpChildNb = 0;
    int callLevel = 0,
        saveLevel = 0, i;
    DBA_DYNFLD_STP * ppsChild, childPtf;
    int ppsChildNb;
    ENUM_T checkParent;
    DATETIME_T databaseDate;
    unsigned char uCharBit;
    FUSDATERULE_ENUM fusionDateRule;

#if defined (AAATIMER)
    TIMER_ST timerSt;
#endif

    FLAG_T noCheckImpactFlag = FALSE;   /* REF3010 - SSO - 981110 */
    FLAG_T localTranFlg = FALSE;        /* REF4204 */
    CODE_T codeOp, codeOp2, codeOp3;

    /*
     *  Initialization  REF7560 - PMO
     */
    codeOp[0]  = 0; /* REF10181 - 041122 - PMO */
    codeOp2[0] = 0;
    codeOp3[0] = 0;

    /* PMSTA-1354 - 170107 - PMO */
    DFT_WaitToBeUnlocked("OperationBeforeInsertOperation");

    /* Timer Management */
    DATE_RESET_TIMER(&timerSt, TIMER_MASK_OPE);
    DATE_START_TIMER(&timerSt, TIMER_MASK_OPE);

    /* REF9350 - TEB - 030806 */
    RET_CODE ret = DBA_CommonInsUpdExtOpBy("DBA_InsExtOpById",
                                              extOpSt,
                                              &noCheckImpactFlag,
                                              &portfolio,
                                              &pps,
                                              &ppsNb,
                                              &fusionDateRule,
                                              &checkParent,
                                              dbiConn);
    if (ret != RET_SUCCEED)
    {
        return ret;
    }

    /* Begin the transaction */
    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
        if (dbiConn.isInTransaction() == false)      /* REF4204 */ /* DLA - REF5695 - 011030 -> <= � la place de == */
        {
            ret = dbiConn.beginTransaction();

            if (ret != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                return ret;
            }

            localTranFlg = TRUE;
        }
    }

    if ((dbiConn.getConnStructPtr()->blockMode == FALSE ) ||
        (dbiConn.getConnStructPtr()->blockMode == TRUE &&
         dbiConn.getConnStructPtr()->blockModeExt.creation_d.date == 0 )) /* DLA - REF8880 - 030318 */
    {
        ret = DBA_GetDbDateOnServer(&databaseDate, dbiConn);
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.creation_d = databaseDate;
        }
    }
    else
    {
        databaseDate = dbiConn.getConnStructPtr()->blockModeExt.creation_d;
        ret = RET_SUCCEED;
    }

    if (ret != RET_SUCCEED)
    {
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)           /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }
        return(RET_DBA_ERR_CONNLOST);             /* REF8706 - TEB - 030815 */
    }

    /* PMSTA-12097-CHU-110628 do not lose creation time when already set */
    if (IS_NULLFLD(extOpSt, ExtOp_CreationTime) == true)
    {
        SET_DATETIME(extOpSt, ExtOp_CreationTime, databaseDate);
    }

    /* PMSTA-50799 - JPR - 221122 The database time can be less than creation time if taken from db connection in the block mode */
    if (DATETIME_CMP(databaseDate, GET_DATETIME(extOpSt, ExtOp_CreationTime)) >= 0)
    {
        SET_DATETIME(extOpSt, ExtOp_LastModifDate, databaseDate);
    }
    else
    {
        /* Set last modification date as creation time if database date is less than creation time */
        SET_DATETIME(extOpSt, ExtOp_LastModifDate, GET_DATETIME(extOpSt, ExtOp_CreationTime));
    }

    if (noCheckImpactFlag == FALSE) /* REF3010 - SSO - 981110 */
    {
        /* ref1613 SME - 980603 check ref. oper. code */
        if ((ret = OPE_CheckRefOperCode(extOpSt, dbiConn)) != RET_SUCCEED)  /* REF7475 - PMO */
        {
            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)           /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        /* PMSTA-49729 - Deepthi - 220818 - check adj ref. oper. code */
        if (GET_ENUM(extOpSt, ExtOp_NatureEn) == OpNat_Adjust)
        {
            if ((ret = OPE_CheckAdjRefOperCode(extOpSt, dbiConn)) != RET_SUCCEED)  /* REF7475 - PMO */
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)           /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }
                return(ret);
            }
        }

        if ((ret = OPE_ReverseOperation(Insert,
                                        extOpSt,
                                        NULL,
                                        &revExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
                                        &insertExtOpChild,
                                        &updateExtOpChild,
                                        &insUpdExtOpChildNb,
                                        dbiConn,
                                        autoFusStock)) != RET_SUCCEED)
        {
            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);

            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)           /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        if ((revExtOpSt == NULL) &&
            (isCopyFlg == FALSE))
        {
            if ((ret = OPE_ExecutionOperation(Insert,
                                              extOpSt,
                                              NULL,
                                              &execExtOpSt,
                                              &remainingExtOp,
                                              portfolio,
                                              pps, ppsNb,
                                              &insertExtOpChild,
                                              &updateExtOpChild,
                                              &remainingExtOpChild,
                                              &insUpdExtOpChildNb,
                                              dbiConn,
                                              autoFusStock)) != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)                   /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }

                return(ret);
            }
        }

        if ((revExtOpSt == NULL) &&
            (execExtOpSt == NULL) &&
            (isCopyFlg == FALSE) &&
            (checkParent == CheckParent_Enable))
        {
            if ((ret = OPE_OrderOperation(Insert,
                                          extOpSt,
                                          NULL,
                                          portfolio,
                                          pps, ppsNb,
                                          dbiConn,
                                          autoFusStock)) != RET_SUCCEED)    /* REF523 - 971024 - DED */
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)                   /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }

                return(ret);
            }
        }

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            saveLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
    }

    ret = DBA_PerformInsUpdDelExtOp(Insert,
                                    extOpSt,
                                    NULL,
                                    portfolio,
                                    pps, ppsNb,
                                    dbiConn,
                                    FALSE,
                                    codeOp,
                                    autoFusStock);

    if (ret != RET_SUCCEED)
    {
        /* REF6915 */
        if (dbiConn.isInTransaction() == true)
        {
            if (GET_UCHAR_BIT(GET_UCHAR(extOpSt, ExtOp_AutoIndex), AUTOINDEXCODE))
            {
                SET_NULL_CODE(extOpSt, ExtOp_Cd);
                uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
                SET_UCHAR_BIT(uCharBit, AUTOINDEXCODE, FALSE);
                SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit ); /* REF9333 - TEB - 030825 */
            }

            if (GET_UCHAR_BIT(GET_UCHAR(extOpSt, ExtOp_AutoIndex), AUTOINDEXACCODE))
            {
                SET_NULL_CODE(extOpSt, ExtOp_AcctCd);
                uCharBit = GET_UCHAR(extOpSt, ExtOp_AutoIndex);
                SET_UCHAR_BIT(uCharBit, AUTOINDEXACCODE, FALSE);
                SET_UCHAR(extOpSt, ExtOp_AutoIndex, uCharBit ); /* REF9333 - TEB - 030825 */
            }
        }

        (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
        FREE_DYNST(portfolio, S_Ptf);
        if (revExtOpSt)
        {
            if (insUpdExtOpChildNb > 0)
            {
                for (i = 0; i < insUpdExtOpChildNb; i++)
                {
                    FREE_DYNST(insertExtOpChild[i], ExtOp);
                    FREE_DYNST(updateExtOpChild[i], ExtOp);
                }
                FREE(insertExtOpChild);
                FREE(updateExtOpChild);
            }
            FREE_DYNST(revExtOpSt, ExtOp);
        }
        if (execExtOpSt)
        {
            if (insUpdExtOpChildNb > 0)
            {
                for (i = 0; i < insUpdExtOpChildNb; i++)
                {
                    FREE_DYNST(insertExtOpChild[i], ExtOp);
                    FREE_DYNST(updateExtOpChild[i], ExtOp);
                    if (remainingExtOpChild)
                    {
                        if (remainingExtOpChild[i])
                        {
                            FREE_DYNST(remainingExtOpChild[i], ExtOp);
                        }
                    }
                }
                FREE(remainingExtOpChild);
                FREE(insertExtOpChild);
                FREE(updateExtOpChild);
            }
            FREE_DYNST(remainingExtOp, ExtOp);
            FREE_DYNST(execExtOpSt, ExtOp);
        }
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)               /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }

        return(ret);
    }

    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        dbiConn.getConnStructPtr()->blockModeExt.curRecStep = saveLevel;
    }

    /* Extourne */
    if (revExtOpSt)
    {
        FLAG_T applMatchSourceCdFlag; /* State of the system parameter ApplMatchSourceCdFlag */

        /* Get system parameter and test it REF7496 - PMO */
        if ( TRUE == GEN_GetApplInfo(ApplMatchSourceCdFlag, &applMatchSourceCdFlag)
            && applMatchSourceCdFlag == TRUE)
        { /* The reverse code used is the source code */

            /* Set the reverse code with the source code */
            COPY_DYNFLD(revExtOpSt, ExtOp, ExtOp_RevOpCd, extOpSt, ExtOp, ExtOp_SrcCd);
        }
        else
        { /* The reverse code used is the operation code */

            /* Set the reverse code with the operation code */
            SET_CODE(revExtOpSt, ExtOp_RevOpCd, codeOp);
        }

        /* Code removed REF9301 - 040219 - PMO */

        ret = DBA_PerformInsUpdDelExtOp(Update,
                                        revExtOpSt,
                                        revExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
                                        dbiConn,
                                        TRUE,
                                        NULL,
                                        autoFusStock);

        if (ret != RET_SUCCEED)
        {
            if (insUpdExtOpChildNb > 0)
            {
                for (i = 0; i < insUpdExtOpChildNb; i++)
                {
                    FREE_DYNST(insertExtOpChild[i], ExtOp);
                    FREE_DYNST(updateExtOpChild[i], ExtOp);
                }
                FREE(insertExtOpChild);
                FREE(updateExtOpChild);
            }

            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);
            FREE_DYNST(revExtOpSt, ExtOp);
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)               /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        FREE_DYNST(revExtOpSt, ExtOp);

        if (insUpdExtOpChildNb > 0)
        {
            ret = RET_SUCCEED;
            for (i = 0; i < insUpdExtOpChildNb; i++)
            {
                ppsChildNb = 0;
                ppsChild = NULL;
                childPtf = NULL;

                ret = OPE_GetPtfPps(insertExtOpChild[i], &childPtf, &ppsChild, &ppsChildNb, dbiConn);

                if (ret != RET_SUCCEED)
                {
                    break;
                }

                SET_CODE(insertExtOpChild[i], ExtOp_ParOpCd, codeOp);
                if (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(insertExtOpChild[i], ExtOp_HierOperNatEn)))
                {
                    SET_CODE(insertExtOpChild[i], ExtOp_HierOperationCd, codeOp);
                    SET_NULL_CODE(insertExtOpChild[i], ExtOp_ParOpCd);
                }
                ret = DBA_PerformInsUpdDelExtOp(Insert,
                                                insertExtOpChild[i],
                                                NULL,
                                                childPtf,
                                                ppsChild, ppsChildNb,
                                                dbiConn,
                                                TRUE, /* new step for mode block */
                                                codeOp2,
                                                autoFusStock);

                if (ret != RET_SUCCEED)
                {
                    (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                    FREE_DYNST(childPtf, S_Ptf);
                    break;
                }

                /* Code removed REF9301 - 040219 - PMO */

                SET_CODE(updateExtOpChild[i], ExtOp_RevOpCd, codeOp2);
                ret = DBA_PerformInsUpdDelExtOp(Update,
                                                updateExtOpChild[i],
                                                updateExtOpChild[i],
                                                childPtf,
                                                ppsChild, ppsChildNb,
                                                dbiConn,
                                                TRUE, /* new step for mode block */
                                                NULL,
                                                autoFusStock);
                (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                FREE_DYNST(childPtf, S_Ptf);

                if (ret != RET_SUCCEED)
                {
                    break;
                }
            }
            for (i = 0; i < insUpdExtOpChildNb; i++)
            {
                FREE_DYNST(insertExtOpChild[i], ExtOp);
                FREE_DYNST(updateExtOpChild[i], ExtOp);
            }
            FREE(insertExtOpChild);
            FREE(updateExtOpChild);
            if (ret != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)               /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }

                return ret;
            }
        }
    }

    /* Execution */
    if (execExtOpSt)
    {

        /* REF7560 close the executed operation */

        COPY_DYNFLD(execExtOpSt, ExtOp, ExtOp_EndDate, extOpSt, ExtOp, ExtOp_BeginDate);
        COPY_DYNFLD(execExtOpSt, ExtOp, ExtOp_CloseOperCd, extOpSt, ExtOp, ExtOp_Cd);
        /*SET_ID(execExtOpSt, ExtOp_CloseOperId, DBA_GetOpIdFromExtOp(extOpSt));*/

        /* Code removed REF9301 - 040219 - PMO */

        ret = DBA_PerformInsUpdDelExtOp(Update,
                                        execExtOpSt,
                                        execExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
                                        dbiConn,
                                        TRUE,
                                        NULL,
                                        autoFusStock);

        if (ret != RET_SUCCEED)
        {
            if (insUpdExtOpChildNb > 0)
            {
                for (i = 0; i < insUpdExtOpChildNb; i++)
                {
                    FREE_DYNST(insertExtOpChild[i], ExtOp);
                    FREE_DYNST(updateExtOpChild[i], ExtOp);
                    if (remainingExtOpChild)
                    {
                        if (remainingExtOpChild[i])
                        {
                            FREE_DYNST(remainingExtOpChild[i], ExtOp);
                        }
                    }
                }
                FREE(remainingExtOpChild);
                FREE(insertExtOpChild);
                FREE(updateExtOpChild);
            }
            FREE_DYNST(remainingExtOp, ExtOp);
            FREE_DYNST(execExtOpSt, ExtOp);
            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)               /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        FREE_DYNST(execExtOpSt, ExtOp);

        if (remainingExtOp)
        {
            ret = DBA_PerformInsUpdDelExtOp(Insert,
                                            remainingExtOp,
                                            NULL,
                                            portfolio,
                                            pps, ppsNb,
                                            dbiConn,
                                            TRUE,
                                            codeOp2,
                                            autoFusStock);

            FREE_DYNST(remainingExtOp, ExtOp);

            if (ret != RET_SUCCEED)
            {
                if (insUpdExtOpChildNb > 0)
                {
                    for (i = 0; i < insUpdExtOpChildNb; i++)
                    {
                        FREE_DYNST(insertExtOpChild[i], ExtOp);
                        FREE_DYNST(updateExtOpChild[i], ExtOp);
                        if (remainingExtOpChild)
                        {
                            if (remainingExtOpChild[i])
                            {
                                FREE_DYNST(remainingExtOpChild[i], ExtOp);
                            }
                        }
                    }
                    FREE(remainingExtOpChild);
                    FREE(insertExtOpChild);
                    FREE(updateExtOpChild);
                }
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)               /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }
                return(ret);
            }
        }

        if (insUpdExtOpChildNb > 0)
        {
            for (i = 0; i < insUpdExtOpChildNb; i++)
            {
                ppsChildNb = 0;
                ppsChild = NULL;
                childPtf = NULL;

                if (insertExtOpChild[i] != NULL)
                {
                    ret = OPE_GetPtfPps(insertExtOpChild[i], &childPtf, &ppsChild, &ppsChildNb, dbiConn);

                    if (ret != RET_SUCCEED)
                    {
                        break;
                    }
                    SET_CODE((insertExtOpChild[i]), ExtOp_ParOpCd, codeOp);
                    ret = DBA_PerformInsUpdDelExtOp(Insert,
                                                    insertExtOpChild[i],
                                                    NULL,
                                                    childPtf,
                                                    ppsChild, ppsChildNb,
                                                    dbiConn,
                                                    TRUE,
                                                    codeOp3,
                                                    autoFusStock);
                    if (ret != RET_SUCCEED)
                    {
                        (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                        FREE_DYNST(childPtf, S_Ptf);
                        break;
                    }
                    /* close operation by execution operation */

                    COPY_DYNFLD((updateExtOpChild[i]), ExtOp, ExtOp_EndDate, (insertExtOpChild[i]), ExtOp, ExtOp_BeginDate);
                    COPY_DYNFLD((updateExtOpChild[i]), ExtOp, ExtOp_CloseOperCd, (insertExtOpChild[i]), ExtOp, ExtOp_Cd);
                    SET_ID((updateExtOpChild[i]), ExtOp_CloseOperId, DBA_GetOpIdFromExtOp(insertExtOpChild[i]));

                    /* Code removed REF9301 - 040219 - PMO */

                    ret = DBA_PerformInsUpdDelExtOp(Update,
                                                    updateExtOpChild[i],
                                                    updateExtOpChild[i],
                                                    childPtf,
                                                    ppsChild, ppsChildNb,
                                                    dbiConn,
                                                    TRUE,
                                                    NULL,
                                                    autoFusStock);
                    if (ret != RET_SUCCEED)
                    {
                        (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                        FREE_DYNST(childPtf, S_Ptf);
                        break;
                    }
                }
                else
                {
                    if (static_cast<EXECNAT_ENUM>(GET_ENUM(extOpSt, ExtOp_ExecOpNatEn)) == ExecNat_Total)
                    {
                        /* detach child */
                        SET_ENUM(updateExtOpChild[i], ExtOp_ParOpNatEn, ParOpNat_None);
                        SET_NULL_CODE(updateExtOpChild[i], ExtOp_ParOpCd);

                        ret = OPE_GetPtfPps(updateExtOpChild[i], &childPtf, &ppsChild, &ppsChildNb, dbiConn);

                        if (ret != RET_SUCCEED)
                        {
                            break;
                        }

                        /* Code removed REF9301 - 040219 - PMO */

                        ret = DBA_PerformInsUpdDelExtOp(Update,
                                                        updateExtOpChild[i],
                                                        updateExtOpChild[i],
                                                        childPtf,
                                                        ppsChild, ppsChildNb,
                                                        dbiConn,
                                                        TRUE,
                                                        NULL,
                                                        autoFusStock);
                        if (ret != RET_SUCCEED)
                        {
                            (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                            FREE_DYNST(childPtf, S_Ptf);
                            break;
                        }
                    }
                    else
                    {
                        /* case with child execution ha zero qty, => delete child */
                        ret = OPE_GetPtfPps(updateExtOpChild[i], &childPtf, &ppsChild, &ppsChildNb, dbiConn);
                        if (ret != RET_SUCCEED)
                        {
                            break;
                        }
                        ret = DBA_PerformInsUpdDelExtOp(Delete,
                                                        updateExtOpChild[i],
                                                        NULL,
                                                        childPtf,
                                                        ppsChild, ppsChildNb,
                                                        dbiConn,
                                                        TRUE,
                                                        NULL,
                                                        autoFusStock);
                        if (ret != RET_SUCCEED)
                        {
                            (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                            FREE_DYNST(childPtf, S_Ptf);
                            break;
                        }
                    }
                }
                if (remainingExtOpChild)
                {
                    if (remainingExtOpChild[i])
                    {
                        SET_CODE((remainingExtOpChild[i]), ExtOp_ParOpCd, codeOp2);

                        ret = DBA_PerformInsUpdDelExtOp(Insert,
                                                        remainingExtOpChild[i],
                                                        NULL,
                                                        childPtf,
                                                        ppsChild, ppsChildNb,
                                                        dbiConn,
                                                        TRUE,
                                                        NULL,
                                                        autoFusStock);
                        if (ret != RET_SUCCEED)
                        {
                            (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                            FREE_DYNST(childPtf, S_Ptf);
                            break;
                        }
                    }
                }
                (void)DBA_FreeDynStTab(ppsChild, ppsChildNb, A_PtfPosSet);
                FREE_DYNST(childPtf, S_Ptf);
            }

            for (i = 0; i < insUpdExtOpChildNb; i++)
            {
                FREE_DYNST(insertExtOpChild[i], ExtOp);
                FREE_DYNST(updateExtOpChild[i], ExtOp);
                if (remainingExtOpChild)
                {
                    if (remainingExtOpChild[i])
                    {
                        FREE_DYNST(remainingExtOpChild[i], ExtOp);
                    }
                }
            }

            FREE(remainingExtOpChild);
            FREE(insertExtOpChild);
            FREE(updateExtOpChild);

            if (ret != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);

                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)               /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }

                return ret;
            }

        }
    }

    (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
    FREE_DYNST(portfolio, S_Ptf);

    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
        /* End the transaction */
        if (localTranFlg == TRUE)               /* REF4204 */
        {
            dbiConn.endTransaction(TRUE);
        }
    }

    DATE_STOP_TIMER(&timerSt, TIMER_MASK_OPE);
    DATE_DISPLAY_TIMER(&timerSt, TIMER_MASK_OPE, "Total Timer insert Extended Operation");

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CommonExtOpByIdAndFuse()
**
**  Description :   Common code for DBA_UpdExtOpByIdAndFuse, DBA_DelExtOpByIdAndFuse
**                  and DBA_InsExtOpById
**
**  Arguments   :   extOpSt          The pointer on the extended operation record
**                  connectNo        The connection number
**                  msgStructPtr     pointer on a structure which will contain
**                                   received messages informations.
**                  functionToCall1  Must be NULL or DBA_UpdExtOpByIdAndFuse or DBA_DelExtOpByIdAndFuse
**                  functionToCall2  Must be NULL or DBA_InsExtOpById
**
**  Return      :   RET_SUCCEED                     if ok
**                  RET_GEN_ERR_INVARG              error in arguments
**		            RET_DBA_ERR_NODATA		        error in retrieving or building data
**		            RET_MEM_ERR_ALLOC		        error in memory allocation
**		            RET_SRV_LIB_ERR_TRIGGER_MSG	    business error
**
**  Creation    :   REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**                  PMSTA-13613 - 070212 - PMO : Decrease number of fusion request calls when modifying the currency of an instrument through function "Modify Curreny"
**
*************************************************************************/
STATIC RET_CODE DBA_CommonExtOpByIdAndFuse(DBA_DYNFLD_STP extOpSt,
                                           DbiConnection & dbiConn,
                                           FLAG_T copyFlag,
                                           RET_CODE (* functionToCall1)(DBA_DYNFLD_STP, DbiConnection &, struct AutomaticFusionStock *),
                                           RET_CODE (* functionToCall2)(DBA_DYNFLD_STP, DbiConnection &, FLAG_T, struct AutomaticFusionStock *)
)
{
    struct AutomaticFusionStock autoFusStock;

    /*
     *  Initialization
     */
    RET_CODE ret                = RET_SUCCEED;
    FLAG_T   bFreeAutoFusStock  = TRUE;
    autoFusStock.nbPtfToFuse    = 0;
    autoFusStock.nbPtfToFuseMax = 0;
    autoFusStock.ptfToFuseTab   = NULL;

    if (NULL != functionToCall1)
    {
        ret = functionToCall1(extOpSt, dbiConn, &autoFusStock);
    }

    if (ret == RET_SUCCEED && NULL != functionToCall2)
    {
        ret = functionToCall2(extOpSt, dbiConn, copyFlag, &autoFusStock);
    }

    if (ret == RET_SUCCEED)
    {
        if (dbiConn.isInTransaction() == false)
        {
            ret = DBA_AutomaticFusionRequest(dbiConn, &autoFusStock);
        }
        else
        {
            if (autoFusStock.ptfToFuseTab != NULL && false == dbiConn.getConnStructPtr()->disableEventSchedNotification)   /* PMSTA-13613 - 070212 - PMO */
            {
                /* REF9538 - 031507 - PMO */
                struct AutomaticFusionStock *    pAutoFusStock          = DBA_CreateDataDesynchronizedFusion();
                DBA_WORK_ON_CLOSE_CONNECTION_STP pWorkOnCloseConnection = DBA_CreateWorkOnCloseConnection();

                if (pAutoFusStock != NULL && pWorkOnCloseConnection != NULL)
                { /* Ok */
                    *pAutoFusStock                     = autoFusStock;
                    pWorkOnCloseConnection->pData      = pAutoFusStock;
                    pWorkOnCloseConnection->free       = DBA_LaunchFusionFree;
                    pWorkOnCloseConnection->onCommit   = DBA_LaunchFusion;
                    pWorkOnCloseConnection->onRollback = NULL;

                    if (FALSE == DBA_AddWorkOnCloseConnection(dbiConn, pWorkOnCloseConnection))
                    { /* Not enough memory */
                        ret = RET_MEM_ERR_ALLOC;
                    }
                    else
                    { /* Ok */
                        bFreeAutoFusStock = FALSE;
                    }
                }

                if (TRUE == bFreeAutoFusStock)
                { /* Error */
                    DBA_FreeDataDesynchronizedFusion(pAutoFusStock);
                }
                DBA_FreeWorkOnCloseConnection(pWorkOnCloseConnection); /* DLA - PMSTA09304 - 100208 */
            }
        }
    }

    if (autoFusStock.ptfToFuseTab != NULL && TRUE == bFreeAutoFusStock)
    {
        FREE(autoFusStock.ptfToFuseTab);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_UpdExtOpByIdAndFuse()
**
**  Description :   Update an extended operation into the database
**		    and launch automatic fusion
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  extOpSt    	 the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**		    RET_DBA_ERR_NODATA		error in retrieving or building data
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error
**
**  Creation    :   REF437 - 980611 -SME -
**
**  Last modif. : REF9538 - 031507 - PMO : Update of a record and udfields is not always in the same transaction
**
*************************************************************************/
RET_CODE DBA_UpdExtOpByIdAndFuse(OBJECT_ENUM            object       ,
                                 DBA_DYNST_ENUM                      ,
                                 DBA_DYNFLD_STP         extOpSt      ,
                                 DbiConnectionHelper &  dbiConnHelper)
{
    RET_CODE ret;

    if (GET_FLAG(extOpSt, ExtOp_InSessionFlg) == TRUE)
    {
        DBA_DYNFLD_STP  ptfPtr   = nullptr;
        FLAG_T          allocFlg = FALSE;

        if (!IS_NULLFLD(extOpSt, ExtOp_DbId))
        {
            SET_ID(extOpSt, ExtOp_DraftOrderId, GET_ID(extOpSt, ExtOp_DbId));
        }

        /* PMSTA09451 - DDV - 100308 - Update begin_d of ExtOperation. It is used to load orders for FinFct */
        if ((GET_EXTENSION_PTR(extOpSt, ExtOp_A_Ptf_Ext)) != nullptr)
        {
            ptfPtr = *(GET_EXTENSION_PTR(extOpSt, ExtOp_A_Ptf_Ext));
        }

        if (ptfPtr == nullptr)
        {
            DBA_GetPtfById(GET_ID(extOpSt, ExtOp_PtfId), TRUE, &allocFlg, &ptfPtr,
                                  DBA_GetHierOptiPtr(), UNUSED, nullptr);
        }

        DBA_UpdExtOpBeginD(extOpSt, NULLDYNST, ptfPtr);

        if (allocFlg == TRUE)
        {
            FREE_DYNST(ptfPtr, A_Ptf);
        }

        /* PMSTA17021- DDV - 131003 - Give connection number to haver correct transaction managment */
        ret = dbiConnHelper.dbaUpdate(object, DBA_ROLE_RECONCILE_STRATEGY, extOpSt);
    }
    else
    {
        DbiConnection&      dbiConn = *dbiConnHelper.getConnection();

        ret = DBA_CommonExtOpByIdAndFuse(extOpSt,
                                        dbiConn,
                                        FALSE,
                                        DBA_UpdExtOpById,
                                        nullptr);
    }

    return ret;
}




/************************************************************************
**
**  Function    :   DBA_AccGreaterBeginDate()
**
**  Description :   Check if the begin date of the new record is greater
**                  and the operation is accounted
**
**  Arguments   :   newExtOpSt  New record
**                  oldExtOpSt  Old record
**
**  Return      :   true    The record is accounted and the begin date of the new record is greater
**		            false   Otherwise
**
**  Creation    :   PMSTA-8731 - 040110 - PMO : Operation is disappeared if we change the fusion date rule of portfolio without a fusion All Portfolio
**
**  Last modif. :
**
*************************************************************************/
STATIC bool DBA_AccGreaterBeginDate(const DBA_DYNFLD_STP newExtOpSt, const DBA_DYNFLD_STP oldExtOpSt)
{
    bool ret = DATETIME_CMP(GET_DATETIME(newExtOpSt, ExtOp_BeginDate), GET_DATETIME(oldExtOpSt, ExtOp_BeginDate)) > 0;

    if (true == ret)
    {
        OPSTAT_ENUM accountingStatus = OpStat_None;   /* Level of the current accounting status */

        (void)GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

        ret = (static_cast<OPSTAT_ENUM> (GET_ENUM(newExtOpSt, ExtOp_StatusEn)) >= accountingStatus) &&
            (static_cast<OPSTAT_ENUM> (GET_ENUM(oldExtOpSt, ExtOp_StatusEn)) >= accountingStatus);   /* PMSTA-38787 - Silpakal - 200129 */
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_UpdExtOpById()
**
**  Description :   Update an extended operation into the database
**		    Steps :
**			1. Retrieve all notepad records for the old operation
**			2. Delete of old operation by physical delete or fusion
**			3. Insert new operation with OpId = NULL
**			4. Insert saved notepad records for new operation
**			5. notify fusion server to perform a fusion process
**
**  Arguments   :   extOpSt      the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**				                 received messages informations.
**
**  Return      :   RET_SUCCEED 	if ok
**		    RET_GEN_ERR_INVARG	error in arguments
**		    RET_DBA_ERR_NODATA	error in retrieving or building data
**		    RET_MEM_ERR_ALLOC	error in memory allocation
**
**  Creation    :   DVP029 - 170496 - DED
**
**  Last modif. :   BUG177 - 961015 - DED : Change notification of fusion server.
**                  DVP291 - 961204 - PEC : Block mode handling.
**                  BUG285 - 970206 - PEC : Initialization of extDataTabSize.
**	         	    DVP342 - 970210 - PEC : Gestion des ordres.
**                  REF425 - 971114 - DED : No update if reversal operation except is Server Process.
**                  REF437 - 980610 - SME : No launch fusion in this function, replace DBA_Update2, DBA_Delete2, DBA_Insert2
**                                          by DBA_UpdExtOpById,DBA_DelExtOpById,DBA_InsExtOpById.
**                  REF2573 - 980724 - SME: No update if old op. is a reversal op.
**                  REF2956 - 981104 - GRD: Transaction integrity problem in mode block.
**                  REF4204 - 000321 - GRD: Now handle subscriptions.
**                  REF7560 - 020730 - PMO : Order Management Entity light project: database infrastructure
**                  REF7475 - 020829 - PMO : FlexeLint message
**                  REF9350 - TEB - 030806 : Exclude cash portfolio from the fusion process
**                  FPL-REF8803-030929     : It's possible to modify the same order from two op-list view
**                  REF9301 - 040219 - PMO : this message appear sometimes after update field on child and block order:
**                                           The row (id=1234567) into the table ext_order has been modified by
**                                           someone/something else in the meantime
**                  REF11159 - 050509 - EFE : an update on portfolio_id becomes delete + insert
**                  REF11589 - 120606 - PMO : Memory leak when retrieving extended operations from the database
**                  PMSTA-1354 - 170107 - PMO : On error, the fusion server can crash while notifying the dispatcher
**                  PMSTA-10521 - 170810 - PMO : Last modification date of an operation is not updated when the portfolio code of the operation is changed
**
*************************************************************************/
STATIC RET_CODE DBA_UpdExtOpById(DBA_DYNFLD_STP extOpSt,
                                 DbiConnection & dbiConn,
                                 struct AutomaticFusionStock *  autoFusStock)
{
    DBA_DYNFLD_STP portfolio     = NULL;
    FLAG_T noCheckImpactFlag  = FALSE;/* REF3010 - SSO - 981110 */
    DBA_DYNFLD_STP * pps = NULL;
    int ppsNb = 0;
    DBA_DYNFLD_STP revExtOpSt = NULL, execExtOpSt = NULL, remainingExtOp = NULL;
    int callLevel  = 0;
    ENUM_T checkParent;
    DBA_DYNFLD_STP *    oldExtOpSt = NULL;  /* REF11589 - 120606 - PMO */
    int resultRows = 0;                     /* REF11589 - 120606 - PMO */
    FLAG_T localTranFlg = FALSE;
    DATETIME_T databaseDate;
    FUSDATERULE_ENUM fusionDateRule;

    MemoryPool       mp;

    /* SKE 991112 Check arguments moved to the top DBA_UpdExtOpById() */

    /* PMSTA-1354 - 170107 - PMO */
    DFT_WaitToBeUnlocked("OperationBeforeUpdateOperation");

    /* REF9350 - TEB - 030806 */
    RET_CODE ret = DBA_CommonInsUpdExtOpBy("DBA_UpdExtOpById",
                                  extOpSt,
                                  &noCheckImpactFlag,
                                  &portfolio,
                                  &pps,
                                  &ppsNb,
                                  &fusionDateRule,
                                  &checkParent,
                                  dbiConn);
    if (ret != RET_SUCCEED)
    {
        return ret;
    }

    mp.ownerDynStp(portfolio);
    mp.ownerDynStpTab(pps, ppsNb);

    /* Begin the transaction */
    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
        if (dbiConn.isInTransaction() == false)  /* REF4204 */ /* DLA - REF5695 - 011030 -> <= � la place de == */
        {
            ret = dbiConn.beginTransaction();

            if (ret != RET_SUCCEED)
            {
                return ret;
            }

            localTranFlg = TRUE;                    /* REF4204 */
        }
    }

    /* retrieve old ExtOp */
    DBA_DYNFLD_STP sOp = ALLOC_DYNST(S_Op);
    SET_ID(sOp, S_Op_Id, OPE_GetOpIdFromExtOp(extOpSt));    /* REF7560 - PMO */

    /* REF11589 - 120606 - PMO */
    ret = DBA_Select2(EOp,
                      UNUSED,
                      S_Op,
                      sOp,
                      ExtOp,
                      &oldExtOpSt,
                      DBA_SET_CONN | DBA_NO_CLOSE,
                      UNUSED,
                      &resultRows,
                      dbiConn);

    FREE_DYNST(sOp, S_Op);

    mp.ownerDynStpTab(oldExtOpSt, resultRows);

    if (ret != RET_SUCCEED)
    {
        if (ret != RET_SRV_LIB_ERR_DEADLOCK) /* REF4001 - SSO - 991008 */
        {
            ret = RET_SRV_LIB_ERR_TRIGGER_MSG;

            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-20094", nullptr, TextType, GET_CODE(extOpSt, ExtOp_Cd)));
        }
        else
        {
            FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "ERR-53", nullptr));
        }

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)                   /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }

        return(ret);
    }

    /* PMSTA-42430 - JBC - 201125 */
    if(resultRows > 0 && GEN_UseDispatcher() == false && IS_NULLFLD(extOpSt,ExtOp_FusionPrioEn) == false)
    {   /* copy fusion prio to old rec */
        COPY_DYNFLD(oldExtOpSt[0], ExtOp, ExtOp_FusionPrioEn, extOpSt, ExtOp, ExtOp_FusionPrioEn);
    }

    if ((dbiConn.getConnStructPtr()->blockMode == FALSE ) ||
        (dbiConn.getConnStructPtr()->blockMode == TRUE &&
         dbiConn.getConnStructPtr()->blockModeExt.creation_d.date == 0 )) /* DLA - REF8880 - 030318 */
    {
        ret = DBA_GetDbDateOnServer(&databaseDate, dbiConn);
        dbiConn.getConnStructPtr()->blockModeExt.creation_d = databaseDate;
    }
    else
    {
        databaseDate = dbiConn.getConnStructPtr()->blockModeExt.creation_d;
        ret = RET_SUCCEED;
    }

    if (ret != RET_SUCCEED)
    {
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)           /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }
        return(ret);
    }

    /* Code removed + set ExtOp_AudModifDate REF9301 - 040219 - PMO */
    SET_DATETIME(extOpSt, ExtOp_AudModifDate, databaseDate);

    /* SME REF4835 */
    if (GET_ENUM(extOpSt, ExtOp_ExecOpNatEn) == ExecNat_TotalUpdMode)
    {
        SET_ENUM(extOpSt, ExtOp_ExecOpNatEn, ExecNat_None);
    }

    if (noCheckImpactFlag == FALSE) /* REF3010 - SSO - 981110 */
    {
        /* ref1613 SME - 980603 check ref. oper. code */
        if ((ret = OPE_CheckRefOperCode(extOpSt, dbiConn)) != RET_SUCCEED)  /* REF7475 - PMO */
        {
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)                   /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        /* PMSTA-49729 - Deepthi - 220818 - check adj ref. oper. code */
        if (GET_ENUM(extOpSt, ExtOp_NatureEn) == OpNat_Adjust)
        {
            if ((ret = OPE_CheckAdjRefOperCode(extOpSt, dbiConn)) != RET_SUCCEED)  /* REF7475 - PMO */
            {
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)                   /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }
                return(ret);
            }
        }

        if ((ret = OPE_ReverseOperation(Update,
                                        extOpSt,
                                        oldExtOpSt[0],
                                        &revExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
                                        NULL, NULL, NULL,
										dbiConn,
                                        autoFusStock)) != RET_SUCCEED)
        {
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)                       /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        if ((ret = OPE_ExecutionOperation(Update,
                                          extOpSt,
                                          oldExtOpSt[0],
                                          &execExtOpSt,
                                          &remainingExtOp,
                                          portfolio,
                                          pps, ppsNb,
                                          NULL, NULL, NULL, NULL,
										  dbiConn,
                                          autoFusStock)) != RET_SUCCEED)
        {
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)                   /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        if (checkParent == CheckParent_Enable)
        {
            if ((ret = OPE_OrderOperation(Update,
                                          extOpSt,
                                          oldExtOpSt[0],
                                          portfolio,
                                          pps, 
                                          ppsNb,
										  dbiConn,
                                          autoFusStock)) != RET_SUCCEED)    /* REF523 - 971024 - DED */
            {
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)                   /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }
                return(ret);
            }
        }

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
    }

    /*
     * <REF11159-EFE-050503
     * Dans le cas d'une modification de portefeuille, on ne fait pas un update mais un delete sur l'ancienne operation
     * et un insert de l'op avec le nouveau portefeuille .
     * cela implique de gerer les executions et les notepad quand ceux-ci existent
     */

    if (  DBA_PtfHasChanged(       extOpSt, oldExtOpSt[0] ) == TRUE
       || DBA_AccGreaterBeginDate( extOpSt, oldExtOpSt[0] ) == true
       )
    {
        DBA_DYNFLD_STP * aNotepadTab ;
        int nbNotepad;

        if ( DBA_ExecutionHasChanged( extOpSt, oldExtOpSt[0] ) == TRUE )
        {
            /* we forbid the double modification of executions and portfolio at the same */
            char messageStr[96];   /* Buffer for an error message */
            /* Format and log an error message */
            (void)snprintf(messageStr,
                           sizeof(messageStr) / sizeof(messageStr[0]),
                           "Modifying execution and portfolio at the same time is not allowed" );
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, messageStr );
            MSG_DispMsgText(RET_GEN_ERR_PERSONAL, messageStr );

            ret = RET_GEN_ERR_PERSONAL;

        }
        else
        {

            ret = DBA_GetAllNotepadFromOp(oldExtOpSt[0], &aNotepadTab, &nbNotepad);

            if ( ret == RET_SUCCEED )
            {
                DATETIME_T databaseDate2;

                ret = DBA_GetDbDateOnServer(&databaseDate2, dbiConn);
                if (ret != RET_SUCCEED)
                {
                    if (dbiConn.getConnStructPtr()->blockMode == FALSE && localTranFlg == TRUE)
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                    return(ret);
                }

                SET_DATETIME(oldExtOpSt[0], ExtOp_AudModifDate, databaseDate2);

                /* we must clean ext_order_id  */
                SET_NULL_ID(oldExtOpSt[0], ExtOp_ExtOrderId );

                ret = DBA_PerformInsUpdDelExtOp(Delete,
                                                oldExtOpSt[0],
                                                NULL,
                                                portfolio,
                                                pps, ppsNb,
												dbiConn,
                                                FALSE,
                                                NULL,
                                                autoFusStock);
                if ( ret == RET_SUCCEED )
                {
                    /* we must clean operation_id */

                    SET_NULL_ID(extOpSt, ExtOp_OpId );
                    SET_NULL_ID(extOpSt, ExtOp_DbId );
                    SET_DATETIME(extOpSt, ExtOp_LastModifDate, databaseDate2);  /* PMSTA-10521 - 080910 - PMO */

                    ret = DBA_PerformInsUpdDelExtOp(Insert,
                                                    extOpSt,
                                                    NULL,
                                                    portfolio,
                                                    pps, ppsNb,
													dbiConn,
													TRUE,
                                                    NULL,
                                                    autoFusStock);

                    if ( ret == RET_SUCCEED )
                    {
						ret = DBA_SetAllNotepadToNewOp(extOpSt, aNotepadTab, nbNotepad, dbiConn);

                        if (aNotepadTab != NULL)
                        {
                            (void)DBA_FreeDynStTab( aNotepadTab, nbNotepad, A_Notepad);
                            aNotepadTab = NULL;
                            nbNotepad = 0;
                        }

                    }
                }   /* ret from first DBA_PerformInsUpdDelExtOp ( Delete ... ) */
            }       /* ret from DBA_GetAllNotepadFromOp */
        }

    }
    else
    {
        /* Traitement normal */
        ret = DBA_PerformInsUpdDelExtOp(Update,
                                        extOpSt,
                                        oldExtOpSt[0],
                                        portfolio,
                                        pps, ppsNb,
										dbiConn,
                                        FALSE,
                                        NULL,
                                        autoFusStock);
    }

    /*>REF11159-EFE-050503*/

    if (ret != RET_SUCCEED)
    {
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)                   /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }

        return(ret);
    }

    /* End the transaction */
    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
        if (localTranFlg == TRUE)               /* REF4204 */
        {
            dbiConn.endTransaction(TRUE);
        }
    }

    return(RET_SUCCEED);
}

/*******************************************************************************
**
**  Function    :  DBA_ExtPosToPos()
**
**  Description :  Convert an extended position into a position
**
**  Arguments   :  extPos	pointer to an extended position record
**		   pos		pointer to a position (A_Pos)
**		   No allocation in this function !!
**
**  Return      :  none
**
**  Creation    :  DVP029 - 960417 - DED
**  Last Modif. :  DVP082 - 960613 - DED : Replace GreatestValDate by AccrAmt
**
*******************************************************************************/
void DBA_ExtPosToPos(DBA_DYNFLD_STP extPos, DBA_DYNFLD_STP pos)
{
    int i;

    /* Check arguments */
    if (extPos == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_ExtPosToPos", "extPos");
        return;
    }

    COPY_DYNFLD(pos, A_Pos, A_Pos_Id,                extPos, ExtPos, ExtPos_PosObjId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PtfId,             extPos, ExtPos, ExtPos_PtfId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PtfPosSetId,       extPos, ExtPos, ExtPos_PtfPosSetId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_InstrId,           extPos, ExtPos, ExtPos_InstrId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_DepoId,            extPos, ExtPos, ExtPos_DepoId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PosCurrId,         extPos, ExtPos, ExtPos_PosCurrId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_InstrCurrId,       extPos, ExtPos, ExtPos_InstrCurrId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PtfCurrId,         extPos, ExtPos, ExtPos_RefCurrId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_CntPtyThirdId,     extPos, ExtPos, ExtPos_CntPtyThirdId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_OpenOpId,          extPos, ExtPos, ExtPos_OpenOpId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_CloseOpId,         extPos, ExtPos, ExtPos_CloseOpId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_TermTpId,          extPos, ExtPos, ExtPos_TermTpId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_LockTpId,          extPos, ExtPos, ExtPos_LockTpId);

    /* DVP355 - 970306 - PEC */
    COPY_DYNFLD(pos, A_Pos, A_Pos_ValRuleEltId,      extPos, ExtPos, ExtPos_ValRuleEltId);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SubPosNat2En,      extPos, ExtPos, ExtPos_SubPosNat2En);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SubPosNat3En,      extPos, ExtPos, ExtPos_SubPosNat3En);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookPosExchRate,   extPos, ExtPos, ExtPos_BookPosExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookInstrExchRate, extPos, ExtPos, ExtPos_BookInstrExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookSysExchRate,   extPos, ExtPos, ExtPos_BookSysExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookPrice,         extPos, ExtPos, ExtPos_BookPrice);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookQuote,         extPos, ExtPos, ExtPos_BookQuote);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookPosAmt,        extPos, ExtPos, ExtPos_BookPosNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookInstrAmt,      extPos, ExtPos, ExtPos_BookInstrNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookPtfAmt,        extPos, ExtPos, ExtPos_BookRefNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BookSysAmt,        extPos, ExtPos, ExtPos_BookSysNetAmt);
    /* DVP355 - 970306 - PEC */

    COPY_DYNFLD(pos, A_Pos, A_Pos_OpenOpNatEn,       extPos, ExtPos, ExtPos_OpenOpNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_AdjustNatEn,       extPos, ExtPos, ExtPos_AdjustNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_OpenOpCd,          extPos, ExtPos, ExtPos_OpenOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_CloseOpCd,         extPos, ExtPos, ExtPos_CloseOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_RefOpCd,           extPos, ExtPos, ExtPos_RefOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_RefNatEn,          extPos, ExtPos, ExtPos_RefNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ExecOpCd,          extPos, ExtPos, ExtPos_ExecOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ExecOpNatEn,       extPos, ExtPos, ExtPos_ExecNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ExecOpStatEn,      extPos, ExtPos, ExtPos_ExecOpStatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_RevOpCd,           extPos, ExtPos, ExtPos_RevOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_RevOpNatEn,        extPos, ExtPos, ExtPos_RevNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_LockOpCd,          extPos, ExtPos, ExtPos_LockOpCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_LockNatEn,         extPos, ExtPos, ExtPos_LockNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_EventCd,           extPos, ExtPos, ExtPos_EvtCd);
    COPY_DYNFLD(pos, A_Pos, A_Pos_EventNbr,          extPos, ExtPos, ExtPos_EvtNbr);
    COPY_DYNFLD(pos, A_Pos, A_Pos_StatEn,            extPos, ExtPos, ExtPos_StatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PrimaryEn,         extPos, ExtPos, ExtPos_PrimaryEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_MainFlag,          extPos, ExtPos, ExtPos_MainFlg);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PosNatEn,          extPos, ExtPos, ExtPos_PosNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SubPosNatEn,       extPos, ExtPos, ExtPos_SubPosNatEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ExCouponFlag,      extPos, ExtPos, ExtPos_ExCouponFlg);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Fus,               extPos, ExtPos, ExtPos_Fus);
    COPY_DYNFLD(pos, A_Pos, A_Pos_FusRuleEn,         extPos, ExtPos, ExtPos_FusRuleEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_BegDate,           extPos, ExtPos, ExtPos_BegDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_EndDate,           extPos, ExtPos, ExtPos_EndDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_OpDate,            extPos, ExtPos, ExtPos_OpDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_AcctDate,          extPos, ExtPos, ExtPos_AcctDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ValDate,           extPos, ExtPos, ExtPos_ValDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_LockLimitDate,     extPos, ExtPos, ExtPos_LockLimitDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_ExpirDate,         extPos, ExtPos, ExtPos_ExpirDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_AccrAmt,           extPos, ExtPos, ExtPos_AccrAmt); /* DVP082 - 960613 - DED */
    COPY_DYNFLD(pos, A_Pos, A_Pos_OrderLimitDate,    extPos, ExtPos, ExtPos_OrderLimitDate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Remark,            extPos, ExtPos, ExtPos_Remark);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PosExchRate,       extPos, ExtPos, ExtPos_PosExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_InstrExchRate,     extPos, ExtPos, ExtPos_InstrExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SysExchRate,       extPos, ExtPos, ExtPos_SysExchRate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Qty,               extPos, ExtPos, ExtPos_Qty);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Price,             extPos, ExtPos, ExtPos_Price);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SpotPrice,         extPos, ExtPos, ExtPos_SpotPrice);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PriceCalcRuleEn,   extPos, ExtPos, ExtPos_PriceCalcRuleEn);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Quote,             extPos, ExtPos, ExtPos_Quote);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SpotQuote,         extPos, ExtPos, ExtPos_SpotQuote);
    COPY_DYNFLD(pos, A_Pos, A_Pos_Rate,              extPos, ExtPos, ExtPos_Rate);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SupplAmt,          extPos, ExtPos, ExtPos_SupplAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PosGrossAmt,       extPos, ExtPos, ExtPos_PosGrossAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PosNetAmt,         extPos, ExtPos, ExtPos_PosNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_InstrGrossAmt,     extPos, ExtPos, ExtPos_InstrGrossAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_InstrNetAmt,       extPos, ExtPos, ExtPos_InstrNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PtfGrossAmt,       extPos, ExtPos, ExtPos_RefGrossAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_PtfNetAmt,         extPos, ExtPos, ExtPos_RefNetAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SysGrossAmt,       extPos, ExtPos, ExtPos_SysGrossAmt);
    COPY_DYNFLD(pos, A_Pos, A_Pos_SysNetAmt,         extPos, ExtPos, ExtPos_SysNetAmt);

    for (i = 0; i < A_Pos_BpPosAmtNb; i++)
    {
        COPY_DYNFLD(pos, A_Pos, A_Pos_Bp1PosAmt + i, extPos, ExtPos, ExtPos_Bp1PosAmt + i);
    }

}

/*******************************************************************************
**
**  Function    :  DBA_ExtPosToBalPos()
**
**  Description :  Convert an extended position into a balance position
**
**  Arguments   :  extPos	pointer to an extended position record
**		   balPos	pointer to a balance position (A_BalPos)
**		   No allocation in this function !!
**
**  Return      :  none
**
**  Creation    :  DVP029 - 170496 - DED
**  Last Modif. :
**
*******************************************************************************/
void DBA_ExtPosToBalPos(DBA_DYNFLD_STP extPos, DBA_DYNFLD_STP balPos)
{
    int i = 0;

    /* Check arguments */
    if (extPos == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_ExtPosToBalPos", "extPos");
    }
    else
    {
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_Id,            extPos, ExtPos, ExtPos_PosObjId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PtfId,         extPos, ExtPos, ExtPos_PtfId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PtfPosSetId,   extPos, ExtPos, ExtPos_PtfPosSetId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_InstrId,       extPos, ExtPos, ExtPos_InstrId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_BalPosTpId,    extPos, ExtPos, ExtPos_BalPosTpId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PosCurrId,     extPos, ExtPos, ExtPos_PosCurrId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_InstrCurrId,   extPos, ExtPos, ExtPos_InstrCurrId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PtfCurrId,     extPos, ExtPos, ExtPos_RefCurrId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_OpenOpId,      extPos, ExtPos, ExtPos_OpenOpId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_CloseOpId,     extPos, ExtPos, ExtPos_CloseOpId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_TermTpId,      extPos, ExtPos, ExtPos_TermTpId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_LockTpId,      extPos, ExtPos, ExtPos_LockTpId);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_OpenOpNatEn,   extPos, ExtPos, ExtPos_OpenOpNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_AdjustNatEn,   extPos, ExtPos, ExtPos_AdjustNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_OpenOpCd,      extPos, ExtPos, ExtPos_OpenOpCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_CloseOpCd,     extPos, ExtPos, ExtPos_CloseOpCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_RefOpCd,       extPos, ExtPos, ExtPos_RefOpCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_RefNatEn,      extPos, ExtPos, ExtPos_RefNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_ExecOpCd,      extPos, ExtPos, ExtPos_ExecOpCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_ExecOpNatEn,   extPos, ExtPos, ExtPos_ExecNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_ExecOpStatEn,  extPos, ExtPos, ExtPos_ExecOpStatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_RevOpCd,       extPos, ExtPos, ExtPos_RevOpCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_RevOpNatEn,    extPos, ExtPos, ExtPos_RevNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_EventCd,       extPos, ExtPos, ExtPos_EvtCd);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_EventNbr,      extPos, ExtPos, ExtPos_EvtNbr);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_StatEn,        extPos, ExtPos, ExtPos_StatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PrimaryEn,     extPos, ExtPos, ExtPos_PrimaryEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_MainFlag,      extPos, ExtPos, ExtPos_MainFlg);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PosNatEn,      extPos, ExtPos, ExtPos_PosNatEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_Fus,           extPos, ExtPos, ExtPos_Fus);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_FusRuleEn,     extPos, ExtPos, ExtPos_FusRuleEn);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_BegDate,       extPos, ExtPos, ExtPos_BegDate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_EndDate,       extPos, ExtPos, ExtPos_EndDate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_OpDate,        extPos, ExtPos, ExtPos_OpDate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_AcctDate,      extPos, ExtPos, ExtPos_AcctDate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_ValDate,       extPos, ExtPos, ExtPos_ValDate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_Remark,        extPos, ExtPos, ExtPos_Remark);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PosExchRate,   extPos, ExtPos, ExtPos_PosExchRate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_InstrExchRate, extPos, ExtPos, ExtPos_InstrExchRate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_SysExchRate,   extPos, ExtPos, ExtPos_SysExchRate);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_Qty,           extPos, ExtPos, ExtPos_Qty);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_Price,         extPos, ExtPos, ExtPos_Price);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PosGrossAmt,   extPos, ExtPos, ExtPos_PosGrossAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PosNetAmt,     extPos, ExtPos, ExtPos_PosNetAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_InstrGrossAmt, extPos, ExtPos, ExtPos_InstrGrossAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_InstrNetAmt,   extPos, ExtPos, ExtPos_InstrNetAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PtfGrossAmt,   extPos, ExtPos, ExtPos_RefGrossAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_PtfNetAmt,     extPos, ExtPos, ExtPos_RefNetAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_SysGrossAmt,   extPos, ExtPos, ExtPos_SysGrossAmt);
        COPY_DYNFLD(balPos, A_BalPos, A_BalPos_SysNetAmt,     extPos, ExtPos, ExtPos_SysNetAmt);

        for (i = 0; i < A_BalPos_BpPosAmtNb; i++)
        {
            COPY_DYNFLD(balPos, A_BalPos,  A_BalPos_Bp1PosAmt + i, extPos, ExtPos, ExtPos_Bp1PosAmt + i);
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_InverseSign()
**
**  Description :   Inverse the sign of amounts.
**
**  Arguments   :   extPos  pointer on position to modify
**
**  Return      :   none
**
**  Last Modif. :   REF033 - 970917 - DED : Add book values attributes
**					PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
*************************************************************************/
void DBA_InverseSignAmounts(DBA_DYNFLD_STP extPos)
{
    double tmp;
    int bpAmtFld;

    tmp = GET_AMOUNT(extPos, ExtPos_SupplAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_SupplAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_PosGrossAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_PosGrossAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_PosNetAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_PosNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_BookPosNetAmt) * -1;        /* REF033 - 970917 - DED */
    SET_AMOUNT(extPos, ExtPos_BookPosNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_InstrGrossAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_InstrGrossAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_InstrNetAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_InstrNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_BookInstrNetAmt) * -1;      /* REF033 - 970917 - DED */
    SET_AMOUNT(extPos, ExtPos_BookInstrNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_RefGrossAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_RefGrossAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_RefNetAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_RefNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_BookRefNetAmt) * -1;        /* REF033 - 970917 - DED */
    SET_AMOUNT(extPos, ExtPos_BookRefNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_SysGrossAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_SysGrossAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_SysNetAmt) * -1;
    SET_AMOUNT(extPos, ExtPos_SysNetAmt, tmp);

    tmp = GET_AMOUNT(extPos, ExtPos_BookSysNetAmt) * -1;        /* REF033 - 970917 - DED */
    SET_AMOUNT(extPos, ExtPos_BookSysNetAmt, tmp);

    for (bpAmtFld = ExtPos_Bp1PosAmt;
         bpAmtFld < (ExtPos_Bp1PosAmt + ExtPos_BpPosAmtNb);
         bpAmtFld++)
    {
        tmp = GET_AMOUNT(extPos, bpAmtFld) * -1;
        SET_AMOUNT(extPos, bpAmtFld, tmp);
    }
}

/*******************************************************************************
**
**  Function    : FIN_ChangePriceSign
**
**  Description : Change the sign of the price and amounts
**
**  Arguments   : extPos	Position to modify
**
**  Return      : None
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
*******************************************************************************/
void DBA_InversePriceSign(DBA_DYNFLD_STP extPos)
{
    double tmp = GET_PRICE(extPos, ExtPos_Price) * -1;
    SET_PRICE(extPos, ExtPos_Price, tmp);

	DBA_InverseSignAmounts(extPos);
}

/************************************************************************
**
**  Function    :   DBA_InverseSign()
**
**  Description :   Inverse the sign of the quantity and amounts.
**
**  Arguments   :   extPos  pointer on position to modify
**
**  Return      :   none
**
**  Last Modif. :   REF033 - 970917 - DED : Add book values attributes
**					PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
*************************************************************************/
void DBA_InverseSign(DBA_DYNFLD_STP extPos)
{
    double tmp = GET_NUMBER(extPos, ExtPos_Qty) * -1;
    SET_NUMBER(extPos, ExtPos_Qty, tmp);

	/* PMSTA-6921 - 311008 - PMO */
	DBA_InverseSignAmounts(extPos);
}

/************************************************************************
 *   Function             : DBA_DropTempDomOper()
 *
 *   Description          : Drops temporary table '#dom_oper'
 *
 *   Arguments            : connectNo  a connection number in the connection list
 *
 *   Return               : RET_SUCCEED		if ok
 *			   DBA_CONN_PROBLEM	connection error
 *
 *   Creation date        : DVP247 - 961112 - DED
 *
 *   Last Modification    : DVP249 - 961112 - PEC
 *                          DVP400 - 970321 - PEC - Handling of multi-transactions
 *                          27.09.99 - GRD - Ref.: REF3847.
 *                          REF5010 - SSO - 000828
 *************************************************************************/
STATIC RET_CODE DBA_DropTempDomOper(DbiConnection & dbiConn)
{
    RET_CODE retCode;

    /* PMSTA-18593 - LJE - 151103 */
    retCode = DBA_CreateTempTables(dbiConn, DOM_OPER);

    return(retCode);
}

/************************************************************************
**
**  Function    :   DBA_DelExtOpByIdAndFuse()
**
**  Description :   Delete an extended operation into the database
**		    and launch automatic fusion
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  extOpSt    	 the pointer on the extended operation record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**		    RET_DBA_ERR_NODATA		error in retrieving or building data
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_SRV_LIB_ERR_TRIGGER_MSG	business error
**
**  Creation    :   REF437 - 980611 -SME -
**
**  Last modif. : REF9538 - 031507 - PMO : Update of a record and udfields is not alway in the same transaction
**
*************************************************************************/
RET_CODE DBA_DelExtOpByIdAndFuse(OBJECT_ENUM,
                                 DBA_DYNST_ENUM,
                                 DBA_DYNFLD_STP         extOpSt,
                                 DbiConnectionHelper& dbiConnHelper)
{
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

    RET_CODE ret = DBA_CommonExtOpByIdAndFuse(extOpSt,
                                               dbiConn,
                                               FALSE,
                                               DBA_DelExtOpById,
                                               nullptr);

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_DelExtOpById()
**
**  Description :   Delete of an extended operation from the database.
**		    This function also audits the operation if necessary.
**                  A fusion is launched if delete isn't a part of an update
**		    (this is done in stored procedure 'del_operation_by_id').
**
**  Arguments   :   opSt      	 the pointer on a S_Op structure with operation Id
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**				                 received messages informations.
**
**  Return      :   RET_SUCCEED 	if ok
**		    RET_GEN_ERR_INVARG	error in arguments
**		    RET_DBA_ERR_NODATA	no operation found
**		    RET_MEM_ERR_ALLOC	error in memory allocation
**
**  Creation    :   DVP202 - 960909 - DED
**
**  Last modif. :   BUG177 - 961015 - DED : Add argument to call procedure 'delete'
**          DVP291 - 961204 - PEC  : Block mode handling
**		    DVP288 - 961205 - DED  : Add call to fusion_server if no update and delete by fusion
**		    DVP342 - 970210 - PEC  : Gestion des ordres
**		    REF839 - 980218 - DED  : If delete of partial execution, we must also delete the
**					                 remaining partial operation
**		    REF1373 - 980326 - DED : Warning message if update of executed operation
**	 	    REF1009 - 980513 - DED : Reinitialize executed operation if delete of total/partial execution
**		    REF956 - 980603 - DED  : - No delete of reversed operation
**					    -            Reinitialize reversed operation if delete of reversal operation
**          REF437 - 980610 - SME  : no launch fusion in this function, replace DBA_Update2 and DBA_Delete2
**                                   by DBA_UpdExtOpById and DBA_DelExtOpById
**          REF2631 - 980902 - DED : Check security on closing periods
**          REF1402 - 981026 - SME : update event scheduler for synthetic administration
**          REF2956 - 981104 - GRD : Transaction integrity problem in block mode.
**          REF4204 - 000324 - GRD : Subscription management.
**          REF7912 - 020921 - PMO : Problem with the delete of a reverse operation (status accounted)
**          REF8625 - 030113 - PMO : Problem with copy operation (Memory leak)
**          FPL-REF8803-030929     : It's possible to modify the same order from two op-list view
**          REF10181 - 041122 - PMO : Bizard reverse code generated when you specified it in the import file
**          REF11589 - 120606 - PMO : Memory leak when retrieving extended operations from the database
**          PMSTA-1354 - 170107 - PMO : On error, the fusion server can crash while notifying the dispatcher
**          PMSTA-34674 - 070219 - PMO : The second delete or update of an updated accounted operation untreated by the fusion is badly treated
**
*************************************************************************/
STATIC RET_CODE DBA_DelExtOpById(DBA_DYNFLD_STP opSt,
                                 DbiConnection& dbiConn,
                                 struct AutomaticFusionStock *  autoFusStock)
{
    DBA_DYNFLD_STP * pps = NULL;
    int ppsNb = 0;
    DBA_DYNFLD_STP portfolio     =   NULL;
    DBA_DYNFLD_STP revExtOpSt    =   NULL;
    DBA_DYNFLD_STP execExtOpSt   =   NULL;
    DBA_DYNFLD_STP * extOpSt     =   NULL;      /* REF11589 - 120606 - PMO */
    int resultRows  =   0;                      /* REF11589 - 120606 - PMO */
    int callLevel = 0, saveLevel = 0;
    CODE_T codeOp;
    FLAG_T localTranFlg = FALSE;
    DATETIME_T databaseDate;
    MemoryPool      mp;

    /* Check arguments */
    if (opSt == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_DelExtOpById", "opSt");
        return(RET_GEN_ERR_INVARG);
    }

    codeOp[0] = 0;  /* REF10181 - 041122 - PMO */

    /* REF3010 - SSO - 981110 no check/impact done if copy op or modif curr */
    FLAG_T noCheckImpactFlag = GET_FLAG(opSt, S_Op_NoCheckImpactFlg);

    /* PMSTA-1354 - 170107 - PMO */
    DFT_WaitToBeUnlocked("OperationBeforeDeleteOperation");

    /*********************************************** Get extended operation *********************************************/

    /*
     * Retrieve data to be deleted.
     */
    /* REF11589 - 120606 - PMO */
    RET_CODE ret = DBA_Select2(EOp,
                               UNUSED,
                               S_Op,
                               opSt,
                               ExtOp,
                               &extOpSt,
                               DBA_SET_CONN | DBA_NO_CLOSE,
                               UNUSED,
                               &resultRows,
                               dbiConn);

    if (ret != RET_SUCCEED || extOpSt == NULL)
    {
        (void)DBA_FreeDynStTab(extOpSt, resultRows, ExtOp); /* REF11589 - 120606 - PMO */

        if (ret != RET_SRV_LIB_ERR_DEADLOCK)                /* REF4001 - SSO - 991008 */
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Extended Operation");
            ret = RET_DBA_ERR_NODATA;
        }

        return(ret);
    }

    if(GEN_UseDispatcher() == false && IS_NULLFLD(opSt,S_Op_FusionPrioEn) == false)
    {
        SET_ENUM(extOpSt[0],ExtOp_FusionPrioEn,GET_ENUM(opSt,S_Op_FusionPrioEn));
    }

	ret = OPE_GetPtfPps(extOpSt[0], &portfolio, &pps, &ppsNb, dbiConn);

    if (ret != RET_SUCCEED)
    {
        (void)DBA_FreeDynStTab(extOpSt, resultRows, ExtOp); /* REF11589 - 120606 - PMO */
        return ret;
    }

    /* Begin the transaction */
    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
		if (dbiConn.isInTransaction() == false)      /* REF4204 */ /* DLA - REF5695 - 011030 -> <= � la place de == */
        {
            ret = dbiConn.beginTransaction();

            if (ret != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(extOpSt, resultRows, ExtOp); /* REF11589 - 120606 - PMO */
                FREE_DYNST(portfolio, S_Ptf);
                return ret;
            }

            localTranFlg = TRUE;
        }
    }

    ret = DBA_GetDbDateOnServer(&databaseDate, dbiConn);
    if (ret != RET_SUCCEED)
    {
        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)           /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }
        return(ret);
    }

    /* REF9301 - 040219 - PMO */
    SET_DATETIME(extOpSt[0], ExtOp_AudModifDate, databaseDate);

    /* SME REF4835 */
    if (GET_ENUM(extOpSt[0], ExtOp_ExecOpNatEn) == ExecNat_TotalUpdMode)
    {
        SET_ENUM(extOpSt[0], ExtOp_ExecOpNatEn, ExecNat_None);
    }

    if (noCheckImpactFlag == FALSE) /* REF3010 - SSO - 981110 */
    {
        if ((ret = OPE_ReverseOperation(Delete,
                                        extOpSt[0],
                                        NULL,
                                        &revExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
                                        NULL, NULL, NULL,
										dbiConn,
                                        autoFusStock)) != RET_SUCCEED)
        {
            FREE_DYNST(portfolio, S_Ptf);
            (void)DBA_FreeDynStTab(extOpSt, resultRows, ExtOp); /* REF11589 - 120606 - PMO */

            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)           /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }

        if (revExtOpSt == NULL)
        {
            if ((ret = OPE_ExecutionOperation(Delete,
                                              extOpSt[0],
                                              NULL,
                                              &execExtOpSt,
                                              NULL,
                                              portfolio,
                                              pps, 
                                              ppsNb,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
											  dbiConn,
                                              autoFusStock)) != RET_SUCCEED)
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);

                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)       /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }
                return(ret);
            }
        }

        if ((revExtOpSt == NULL) &&
            (execExtOpSt == NULL) &&
            (GET_ENUM(extOpSt[0], ExtOp_CheckParentEn) == CheckParent_Enable ||
            static_cast<PAROPNAT_ENUM> (GET_ENUM(extOpSt[0], ExtOp_ParOpNatEn)) == ParOpNat_CombinedOrder)) /* PMSTA06760 - DDV - 080702 */
        {
            if ((ret = OPE_OrderOperation(Delete,
                                          extOpSt[0],
                                          NULL,
                                          portfolio,
                                          pps, ppsNb,
										  dbiConn,
                                          autoFusStock)) != RET_SUCCEED)    /* REF523 - 971024 - DED */
            {
                (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
                FREE_DYNST(portfolio, S_Ptf);
                if (dbiConn.getConnStructPtr()->blockMode == TRUE)
                {
                    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
                }
                else
                {
                    if (localTranFlg == TRUE)       /* REF4204 */
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                }

                return(ret);
            }
        }

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            saveLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
    }

    /* PMSTA-34674 - 070219 - PMO */
    ExtOpLog extOp(extOpSt[0]);         // Current record
    ExtOpLog extOpDeleted;              // ext_order record marked for delete
    if (extOp.getOpId() > ZERO_ID)
    {
        DBA_DYNFLD_STP oldExtOpSt = mp.allocDynst(FILEINFO, ExtOp);

        SET_CODE(oldExtOpSt, ExtOp_Cd, extOp.getDeleteCode().c_str());

        RET_CODE retCode = DBA_Get2(ExtOrder, UNUSED, ExtOp, oldExtOpSt, ExtOp, &oldExtOpSt, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn, nullptr);

        if (retCode == RET_SUCCEED)
        {
            extOpDeleted.set(oldExtOpSt);
        }
    }

    ret = DBA_PerformInsUpdDelExtOp(Delete,
                                    extOpSt[0],
                                    extOpDeleted.extOp(),
                                    portfolio,
                                    pps, ppsNb,
									dbiConn,
                                    FALSE,
                                    codeOp,
                                    autoFusStock);

    if (ret != RET_SUCCEED)
    {
        (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
        FREE_DYNST(portfolio, S_Ptf);

        if (revExtOpSt)
        {
            FREE_DYNST(revExtOpSt, ExtOp);
        }
        if (execExtOpSt)
        {
            FREE_DYNST(execExtOpSt, ExtOp);
        }

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        {
            dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
        }
        else
        {
            if (localTranFlg == TRUE)       /* REF4204 */
            {
                dbiConn.endTransaction(FALSE);
            }
        }
        return(ret);
    }

    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        dbiConn.getConnStructPtr()->blockModeExt.curRecStep = saveLevel;
    }

    if (revExtOpSt)
    {
        DATETIME_T magicEndDateTime;    /* Date with the magic end date (31-dec-9999) */

        /* REF7912 - PMO */
        magicEndDateTime.time = 0;
        magicEndDateTime.date = MAGIC_END_DATE;
        SET_DATETIME(revExtOpSt, ExtOp_EndDate, magicEndDateTime);

        /* Code removed REF9301 - 040219 - PMO */

        ret = DBA_PerformInsUpdDelExtOp(Update,
                                        revExtOpSt,
                                        revExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
										dbiConn,
                                        TRUE,
                                        NULL,
                                        autoFusStock);

        if (ret != RET_SUCCEED)
        {
            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);
            FREE_DYNST(revExtOpSt, ExtOp);
            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)       /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }
            return(ret);
        }
        FREE_DYNST(revExtOpSt, ExtOp);
    }

    if (execExtOpSt)
    {
        /* Code removed REF9301 - 040219 - PMO */

        ret = DBA_PerformInsUpdDelExtOp(Update,
                                        execExtOpSt,
                                        execExtOpSt,
                                        portfolio,
                                        pps, ppsNb,
										dbiConn,
                                        TRUE,
                                        NULL,
                                        autoFusStock);

        if (ret != RET_SUCCEED)
        {
            (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
            FREE_DYNST(portfolio, S_Ptf);
            FREE_DYNST(revExtOpSt, ExtOp);

            if (dbiConn.getConnStructPtr()->blockMode == TRUE)
            {
                dbiConn.getConnStructPtr()->blockModeExt.curRecStep = callLevel;
            }
            else
            {
                if (localTranFlg == TRUE)           /* REF4204 */
                {
                    dbiConn.endTransaction(FALSE);
                }
            }

            return(ret);
        }
        FREE_DYNST(execExtOpSt, ExtOp);
    }

    (void)DBA_FreeDynStTab(pps, ppsNb, A_PtfPosSet);
    FREE_DYNST(portfolio, S_Ptf);
    (void)DBA_FreeDynStTab(extOpSt, resultRows, ExtOp); /* REF11589 - 120606 - PMO */


    /* End the transaction */

    if (dbiConn.getConnStructPtr()->blockMode == TRUE)
    {
        callLevel = dbiConn.getConnStructPtr()->blockModeExt.curRecStep;
    }
    else
    {
        /* REF9982 - TEB - 040303 - Missing test */
        if (localTranFlg == TRUE)
        {
            dbiConn.endTransaction(TRUE);
        }
    }

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_IsAutomaticFusionEnable()
**
**  Description :   Check if the system parameter Automatic fusion is on or off
**
**  Arguments   :   dbiConn Database connection foir checking the parameter
**
**  Return      :   true  Automatic fusion is on
**                  false Automatic fusion is off
**
**  Creation    :   PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
**
**  Last modif. :
**
*************************************************************************/
bool DBA_IsAutomaticFusionEnable(DbiConnection & dbiConn)
{
    bool            ret                 = false;
    DBA_DYNFLD_STP  inputSt             = nullptr;
    DBA_DYNFLD_STP  applParam           = nullptr;

    /* Memory allocation */
    if ((inputSt = ALLOC_DYNST(S_ApplParam)) != nullptr)
    {
        if ((applParam = ALLOC_DYNST(A_ApplParam)) != nullptr)
        {
            const char * pszAutomaticFusion  = "AUTOMATIC_FUSION";

            /* Input parameter */
            SET_NAME(inputSt, S_ApplParam_ParamName, pszAutomaticFusion);

            if ((DBA_Get2(ApplParam, DBA_ROLE_NO_OPTI, S_ApplParam, inputSt, A_ApplParam, &applParam, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn, nullptr)) == RET_SUCCEED)
            {
                ret = atoi (GET_INFO(applParam, A_ApplParam_Value)) > 0;
            }
            else
            { /* Error */
                MSG_SendMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "ApplParam", pszAutomaticFusion);
            }
        }
        else
        { /* Error */
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ApplParam");
        }
    }
    else
    { /* Error */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_ApplParam");
    }

    /* Free memory allocations */
    FREE_DYNST(inputSt,   S_ApplParam);
    FREE_DYNST(applParam, A_ApplParam);

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_AutomaticFusionRequest()
**
**  Description :   Notify the fusion server to launch a fusion process
**		    This function can only be used for 'automatic' fusions,
**		    i.e. fusions not launched manually.
**		    Fusion is launched with following parameters :
**			- 1 portfolio
**			- fusion scope = new operations
**			- begin date = null
**			- end date = null
**			- automatic flag = 1
**		    There is no fusion launched if not a GUI process !!
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**		    RET_GEN_ERR_NOACTION 	notification failed
**
**  Creation    :   BUG177 - 961015 - DED
**
**  Last modif. :   DVP291 - 961204 - PEC
**		    DVP288 - 961205 - DED : Change Fus_Arg structure
**					    No call of fusion server if SRV or BATCH
**		    REF1077 - 980316 - DED : if GUI, check domain for function
**		    REF2580 - SSO - 980727
**          REF8284 - 021031 - PMO : The Fin. Server must launch the fusion when necessary
**          PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
**
*************************************************************************/
STATIC RET_CODE DBA_AutomaticFusionRequest(DbiConnection& dbiConn, struct AutomaticFusionStock * autoFusStock)
{
    /* Tests when to accept automatic fusion request */
    /* BATCH  : (import) always refused
     * SERVER : always refused (eg. copy operations, currency modify)
     * GUI    : refuse for financial functions
     * - allocate order
     * - event generation
     * - strategy reconciliation
     */
    if (SYS_IsBatchMode() == TRUE) /* REF8284 - PMO - 021031 */
    {
        /* All automatic fusion request are refused */
        if (autoFusStock->ptfToFuseTab)
        {
            FREE(autoFusStock->ptfToFuseTab);
            autoFusStock->nbPtfToFuse = autoFusStock->nbPtfToFuseMax = 0;
        }
        return(RET_SUCCEED);
    }
    else
    {
        /* Get domain structure in GUI */                   /* REF1077 - 980316 - DED   */
        DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(-1);
        if (nullptr != domainPtr)     /* REF2580 - SSO - 980727  */
        /* NB: do NOT use connectNo for DBA_GetDomainPtr   */
        {
            DICT_T parFctId;                                                                                                    /*  FIH-REF4856-000526  Test parent         */
            /* Refuse following financial functions */
            DBA_GetDictFctInfo(GET_ID(domainPtr, A_Domain_FctDictId), DictFctInfo_ParDictId, static_cast<PTR>(&parFctId));      /* REF7264 - PMO */    /*  FPL-PMSTA08801-100714 cast  */
            switch (parFctId)
            {
                case DictFct_EventGeneration:
                case DictFct_CurrencyModify:
                case DictFct_CopyOperation:
                case DictFct_ReconcStrat:
                case DictFct_AllocateOrder:
                case DictFct_OrderEntry:
                case DictFct_OrderAllocation:   /*  FIH-REF7228-011205  */
                case DictFct_OrderList:         /*  FIH-REF4856-000526  */
                case DictFct_CreateChildOrder:  /*  FIH-REF7338-020211  */
                case DictFct_OrderGrouping:     /*  FIH-REF7174-020213  */
                case DictFct_GroupingIndex:     /*  FIH-REF7174-020213  */
                case DictFct_UpdateField:       /*  FIH-REF4856-000526  */
                case DictFct_UpdateDraft:       /*  FIH-REF5199-000907  */
                case DictFct_Reversal:          /*  FIH-REF4856-000526  */
                    if (autoFusStock->ptfToFuseTab)
                    {
                        FREE(autoFusStock->ptfToFuseTab);
                        autoFusStock->nbPtfToFuse = autoFusStock->nbPtfToFuseMax = 0;
                    }
                    return(RET_SUCCEED);
            }
        }
    }

    if (dbiConn.getConnStructPtr()->blockMode == FALSE && GEN_UseDispatcher())
    {
        for (int i = 0; i < autoFusStock->nbPtfToFuse; i++)
        {
            /* Memory allocation */
            DBA_DYNFLD_STP fusArg = ALLOC_DYNST(Fus_Arg);

            if (nullptr == fusArg)
            {
                if (autoFusStock->ptfToFuseTab)
                {
                    FREE(autoFusStock->ptfToFuseTab);
                    autoFusStock->nbPtfToFuse = autoFusStock->nbPtfToFuseMax = 0;
                }
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Fus_Arg");
                return(RET_MEM_ERR_ALLOC);
            }

            /* Get portfolio Dict Id */
            DICT_T dictId;
            DBA_GetDictId(Ptf, &dictId);

            /* Set fusion_arg fields */
            SET_DICT(fusArg, Fus_Arg_DictId, dictId);
            SET_ID(fusArg, Fus_Arg_Id, (autoFusStock->ptfToFuseTab[i]));
            SET_NULL_DATETIME(fusArg, Fus_Arg_BegDate);         /* DVP288 - 961205 - DED */
            SET_NULL_DATETIME(fusArg, Fus_Arg_EndDate);         /* DVP288 - 961205 - DED */
            SET_FLAG(fusArg, Fus_Arg_Flg, FALSE);
            SET_FLAG(fusArg, Fus_Arg_AutomaticFlg, TRUE);       /* DVP288 - 961205 - DED */
            SET_ENUM(fusArg, Fus_Arg_PtfSize, PtfSize_None);    /* DVP288 - 961213 - DED */
            CODE_T sessCode;
            DBA_GetApplSessionCode(&sessCode);
            SET_CODE(fusArg, Fus_Arg_ApplSessionCd, sessCode);

            /* PMSTA-21215 - 271015 - PMO
             * Notify the dispatcher over the financial server
             */
            if (DBA_IsAutomaticFusionEnable(dbiConn))
            {
                /*
                 * Looks for the financial server
                 */
                DbiConnectionHelper dbiConnFinSrv("");

                if (true == dbiConnFinSrv.isValidAndInit())
                {
                    if (DBA_Notif(Fus, UNUSED, Fus_Arg, fusArg, *dbiConnFinSrv.getConnection(), DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED)
                    {
                        if (autoFusStock->ptfToFuseTab)
                        {
                            FREE(autoFusStock->ptfToFuseTab);
                            autoFusStock->nbPtfToFuse = autoFusStock->nbPtfToFuseMax = 0;
                        }
                        FREE_DYNST(fusArg, Fus_Arg);
                        MSG_RETURN(RET_GEN_ERR_NOACTION);
                    }
                }
            }

            /* Free memory allocations */
            FREE_DYNST(fusArg, Fus_Arg);
        }

    }

    if (autoFusStock->ptfToFuseTab)
    {
        FREE(autoFusStock->ptfToFuseTab);
        autoFusStock->nbPtfToFuse = autoFusStock->nbPtfToFuseMax = 0;
    }
    return(RET_SUCCEED);
}



/*******************************************************************************
**
**  Function    :  DBA_LoadExtOpByHier()
**
**  Description :  Load of an array of Extended Operations records using a hierarchy.
**                 expects multiselect block of { A_Op, ExtOp, ExtPos,  ExtOp, A_Instr }
**                 encapsulated from DBA_LoadExtOp
**
**  Arguments   :  data block (all data is freed in hierarchy free)
**                 rows block
**                 outputSt  block
**                 outputBlkNb  block
**		           extOpTab	pointer on a array of ExtOp records
**		           extOpTabNbr	number of ExtOp records returned
**
**  Return      :  RET_SUCCEED 			if ok
**
**  Creation    :  WEALTH-6326 - JBC - 20240507
*******************************************************************************/
RET_CODE DBA_LoadExtOpByHier(DBA_DYNFLD_STP **      data, 
                            int              *      rows,
                            const DBA_DYNST_ENUM ** outputSt,
                            const int           outputBlkNb,
                            DBA_DYNFLD_STP **   extOpTab,
                            int *               extOpTabNbr)
{
     RET_CODE ret = RET_SUCCEED;
     DBA_HIER_HEAD_STP hierHead = nullptr;

#define PosBlkPos    1
#define BalPosBlkPos 2
#define ExtOpBlkPos  3
#define InstrBlkPos  4
    
    /* Set values of all ExtPos (data[1] and data[2]) needed to create hierarchy links */
    for (int i = PosBlkPos; i <= BalPosBlkPos; i++)
    {
        for (int j = 0; j < rows[i]; j++)
        {
            SET_FLAG(data[i][j], ExtPos_ForecastFlg, FALSE);
            SET_PERCENT(data[i][j], ExtPos_Proba, 100);
            SET_ENUM(data[i][j], ExtPos_PosDateRuleEn, PosDateRule_BaseValue);
            SET_FLAG(data[i][j], ExtPos_AcctFlg, TRUE);
            SET_ENUM(data[i][j], ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
            SET_ENUM(data[i][j], ExtPos_NatEn, ExtPosNat_Flow);
            COPY_DYNFLD(data[i][j], ExtPos, ExtPos_ExtPosDate, data[i][j], ExtPos, ExtPos_BegDate);
        }
    }

    /* Create hierarchy structure for extended positions */
    if ((hierHead = DBA_CreateHier()) == NULL)   /* REF5239 - RAK - 001025 */
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /* Create all necessary links */
    /*** Instrument ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_A_Instr_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_A_Instr_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Open operation ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Open_A_Op_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Open_A_Op_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Main position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Main_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Main_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Locking position ***/                      /* DVP545 - 970724 - DED */
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Locking_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Locking_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Instrument position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Instr_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Instr_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Main Account position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Acct_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Acct_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Account 2 position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Acct2_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Acct2_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Account 3 position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Acct3_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Acct3_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Adjustment position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_Adjust_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_Adjust_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Accrued interest balance position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_AccrInter_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_AccrInter_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Counterparty position ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_CntPty_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_CntPty_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Balance positions ***/
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_BalPos_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_BalPos_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }


    /*** Book Value Adj. Profit balance position */             /* DVP545 - 970724 - DED */
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_BVAdjProfit_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_BVAdjProfit_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /*** Book Value Adj. Loss balance position */               /* DVP545 - 970724 - DED */
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_BVAdjLoss_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_BVAdjLoss_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /* Portfolio transfer instrument position */               /* DVP545 - 970724 - DED */
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_ToInstr_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_ToInstr_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /* Portfolio transfer balance position */              /* DVP545 - 970724 - DED */
    if (DBA_SetHierLnkUsed(hierHead, ExtPos, ExtPos_ToBalPos_ExtPos_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "DBA_LoadExtOp", ExtPos_ToBalPos_ExtPos_Ext,
                     ExtPos);
        DBA_FreeHier(hierHead);
        DBA_MultiFree(data, outputSt, rows, outputBlkNb);
        return(RET_DBA_ERR_HIER);
    }

    /* Distribute data into hierarchy */
    for (int i = 0; i < outputBlkNb; i++)
    {
        /* REF7863 - DDV - 020917 - Insert all records except extended operations */
        if (i != ExtOpBlkPos)
        {
            ret = DBA_AddHierRecordList(hierHead,
                                        data[i],
                                        rows[i],
                                        *(outputSt[i]),
                                        TRUE);

            if (ret != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                DBA_FreeHier(hierHead);
                for (i = 0; i < outputBlkNb; i++)
                    FREE(data[i]);
                return(RET_DBA_ERR_HIER);
            }
        }
    }

    /* Free memory allocations */
    for (int i = 0; i < outputBlkNb; i++)
    {
        /* REF7863 - DDV - 020917 - free all array except extended operations */
        if (i != ExtOpBlkPos)
        {
            FREE(data[i]);
        }
    }

    /* Create link between position and instrument, */
    /* because it must exist for others links       */
    if (DBA_MakeSpecRecLinks(hierHead, ExtPos, ExtPos_A_Instr_Ext) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        DBA_FreeHier(hierHead);
        return(RET_DBA_ERR_HIER);
    }

    /* Create all hierarchy links */
    if (DBA_MakeLinks(hierHead) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        DBA_FreeHier(hierHead);
        return(RET_DBA_ERR_HIER);
    }

    /* Set book values for balance position */              /* DVP545 - 970724 - DED */
    if ((ret = OPE_SetExtPosBookVal(hierHead, 0, NULL)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        DBA_FreeHier(hierHead);
        return(RET_DBA_ERR_HIER);
    }

    /*********************************** CREATE EXTOP ********************************/

    /* Create all extended operations from hierarchy */
    ret = OPE_CreateExtOpfromExtPos(hierHead, extOpTab, extOpTabNbr, NULL, NULL); /* DVP166 - 970106 - DED / REF7264 - PMO */
    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "ExtOp");
        DBA_FreeHier(hierHead);
        return(RET_DBA_ERR_NODATA);
    }

    /* REF7863 - 020917 - DDV - expand extended operation array with records loaded from table ext_order */
    if (*extOpTabNbr == 0)
    {
        *extOpTab = data[ExtOpBlkPos];
        *extOpTabNbr = rows[ExtOpBlkPos];
    }
    else if (rows[ExtOpBlkPos] > 0)
    {
        if ((*extOpTab = static_cast<DBA_DYNFLD_STP *>(REALLOC((*extOpTab), ((*extOpTabNbr) + rows[ExtOpBlkPos]) * sizeof(DBA_DYNFLD_STP *)))) != NULL)
        {
            for (int i = 0; i < rows[ExtOpBlkPos]; i++)
            {
                (*extOpTab)[(*extOpTabNbr) + i] = data[ExtOpBlkPos][i];
            }
            (*extOpTabNbr) += rows[ExtOpBlkPos];
            FREE(data[ExtOpBlkPos]);
        }
        else
        {
            (*extOpTab) = NULL;
            (*extOpTabNbr) = 0;

            (void)DBA_FreeDynStTab(data[ExtOpBlkPos], rows[ExtOpBlkPos], *(outputSt[ExtOpBlkPos])); /* REF7863 - DDV - 020917 - Free all balance positions */
        }
    }

    /* Free hierarchy */
    DBA_FreeHier(hierHead);

    return ret;
}


/*******************************************************************************
**
**  Function    :  DBA_LoadExtOp()
**
**  Description :  Load of an array of Extended Operations records
**
**  Arguments   :  domainArg	input structure (A_Domain)
**		   extOpTab	pointer on a array of ExtOp records
**		   extOpTabNbr	number of ExtOp records returned
**		   connectNoArg a connection number or -1 if any
**
**  Return      :  RET_SUCCEED 			if ok
**		   RET_GEN_ERR_INVARG		error in arguments
**		   RET_DBA_ERR_CONNOTFOUND	no connection number found
**		   RET_GEN_ERR_NOACTION		error in DBA_Notif
**		   RET_DBA_ERR_NODATA		no data found
**		   RET_DBA_ERR_HIER		error in hierarchy
**
**  Creation    :  DVP247 - 961111 - DED
**
**  Last modif. :  DVP249  - 961112 - PEC
**		   DVP166  - 970106 - DED : Add new argument to function OPE_CreateExtOpfromExtPos
**		   DVP394  - 970321 - PEC : Add new argument connectNoArg
**		   DVP545  - 970724 - DED : Add new links for PtfTransfer and CashPtf operations
**         REF1459 - 980323 - GRD : 2 new parameters for OPE_SetExtPosBookVal.
**         REF5010 - SSO - 000828
**         REF7264 - 020205 - PMO : Compilation errors and warnings with C++ compiler
*******************************************************************************/
RET_CODE DBA_LoadExtOp(DBA_DYNFLD_STP domainArg,
                       DBA_DYNFLD_STP * *    extOpTab,
                       int *                extOpTabNbr,
                       int connectNoArg)
{
    DBA_DYNFLD_STP *    data[5] = { NULL,
                                    NULL,
                                    NULL,
                                    NULL, /* REF7828 - LJE - 020905 */
                                    NULL };

#define OpBlkPos     0
#define PosBlkPos    1
#define BalPosBlkPos 2
#define ExtOpBlkPos  3
#define InstrBlkPos  4

    /* REF8844 - LJE - 030415 */
    const DBA_DYNST_ENUM * outputSt[] =   { &A_Op,
                                            &ExtPos,
                                            &ExtPos,
                                            &ExtOp,  /* REF7828 - LJE - 020905 */
                                            &A_Instr };

    int rows[5] = { 0, 0, 0, 0, 0 };        /* REF7828 - LJE - 020905 */
    int outputBlkNb = 5;
   
    FLAG_T useLocalConn = TRUE;         /* DVP394 */
	DbiConnection * dbiConn = nullptr;

    /* Check of arguments */
    if (domainArg == NULL || * extOpTabNbr != 0)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_LoadExtOp", "domainArg or extOpTabNbr");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get a free connection in the connection list */
    if (connectNoArg >= 0)              /* DVP394 */
    {
        dbiConn    = DBA_GetDbiConnFromConnectNo(connectNoArg);    /* DVP394 */
        useLocalConn = FALSE;
    }
    else
    {
		if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }

    /************************************ INIT WORK TABLE ********************************/

    /* Create temporary worktable '#dom_oper' */
    RET_CODE retCode = DBA_CreateTempTables(*dbiConn, DOM_OPER | TCT_VECTOR_ID);
    if (retCode != RET_SUCCEED)
    {
        return(retCode);
    }

    /* Send an Init request to fill #dom_oper work table */
    if (DBA_Notif(EOp, UNUSED, A_Domain, domainArg, *dbiConn, DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED)
    {
        DBA_DropTempDomOper(*dbiConn);
        if (useLocalConn)
        {
            DBA_EndConnection(&dbiConn);
        }
        MSG_RETURN(RET_GEN_ERR_NOACTION);
    }

    /************************************** SELECT DATA *********************************/

    /* Retrieve all data blocks for hierarchy */
    RET_CODE ret = DBA_MultiSelect2(EOp, UNUSED, A_Domain, domainArg, outputSt, data,
                           DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, rows, *dbiConn, nullptr);
    if (ret != RET_SUCCEED)
    {
        DBA_DropTempDomOper(*dbiConn);
        if (useLocalConn)
        {
            DBA_EndConnection(&dbiConn);
        }
        MSG_RETURN(RET_DBA_ERR_NODATA);
    }

    /* Drop temporary worktable and close connection */
    DBA_DropTempDomOper(*dbiConn);
    if (useLocalConn)
    {
        DBA_EndConnection(&dbiConn);
    }

    /* Exit if no records found */
    /* REF7856 - generate all ExtOp from operation/position/balance positions */
    if (rows[OpBlkPos] != 0)
    {
        /******************************* CREATE HIERARCHY ************************************/		
        if((ret = DBA_LoadExtOpByHier(data,rows,outputSt,outputBlkNb,extOpTab,extOpTabNbr)) != RET_SUCCEED)
        {
            return ret;
        }
    }
    else
    {
        (void)DBA_FreeDynStTab(data[OpBlkPos],      rows[OpBlkPos],     *(outputSt[OpBlkPos]));     /* REF7863 - DDV - 020917 - Free all operations */
        (void)DBA_FreeDynStTab(data[PosBlkPos],     rows[PosBlkPos],    *(outputSt[PosBlkPos]));    /* REF7863 - DDV - 020917 - Free all positions */
        (void)DBA_FreeDynStTab(data[BalPosBlkPos],  rows[BalPosBlkPos], *(outputSt[BalPosBlkPos])); /* REF7863 - DDV - 020917 - Free all balance positions */

        /* REF7863 - DDV - 020917 - If extended operations has been loaded form tables ext_order, return them */
        if (rows[ExtOpBlkPos] > 0)
        {
            (*extOpTab) = data[ExtOpBlkPos];
            (*extOpTabNbr) = rows[ExtOpBlkPos];
        }

        (void)DBA_FreeDynStTab(data[InstrBlkPos], rows[InstrBlkPos], *(outputSt[InstrBlkPos])); /* REF7863 - DDV - 020917 - Free all instruments */
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_FusionRequestAllPtfNewOp()
**
**  Description :   Function which launches a manual fusion of type
**			- dimension = all portfolio's
**			- scope = new operations
**		    Fusions are only launched if system parameter 'automatic fusion'
**		    is ON.
**
**  Arguments   :   getOptions   can be DBA_SET_CONN, DBA_NO_CLOSE
**		    connectNo    the connection number
**
**  Return      :   RET_SUCCEED 		if ok
**		    RET_MEM_ERR_ALLOC		error in memory allocation
**
**  Creation    :   REF1077 - 980316 - DED
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FusionRequestAllPtfNewOp(int getOptions, int connectNo)
{
    DBA_DYNFLD_STP fusArg    = NULL,
                   inputSt   = NULL,
                   applParam = NULL;
    RET_CODE ret;
    INFO_T value;
    const char * pszAutomaticFusion = "AUTOMATIC_FUSION";   /* REF8728 - YST - 030218 */

    /* No fusion if system parameter 'AUTOMATIC_FUSION' = FALSE */
    /* Memory allocation */
    if ((inputSt = ALLOC_DYNST(S_ApplParam)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_ApplParam");
        return(RET_MEM_ERR_ALLOC);
    }
    if ((applParam = ALLOC_DYNST(A_ApplParam)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_ApplParam");
        FREE_DYNST(inputSt, S_ApplParam);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Get system parameter */
    SET_NAME(inputSt, S_ApplParam_ParamName, pszAutomaticFusion); /* DLA - PMSTA09887 - 101115 */
    if ((ret = DBA_Get2(ApplParam, DBA_ROLE_NO_OPTI, S_ApplParam, inputSt, A_ApplParam, &applParam, /* PMSTA11636 - DDV - 110318 - Add role to avoid new optimisation usage */
                        getOptions, &connectNo, nullptr)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "ApplParam", pszAutomaticFusion);
        FREE_DYNST(inputSt, S_ApplParam);
        FREE_DYNST(applParam, A_ApplParam);
        return(RET_DBA_ERR_NODATA);
    }
    strcpy(value, GET_INFO(applParam, A_ApplParam_Value));
    FLAG_T autoFusFlg = static_cast<FLAG_T>(atoi(value));

    /* Free memory allocations */
    FREE_DYNST(inputSt, S_ApplParam);
    FREE_DYNST(applParam, A_ApplParam);

    if (autoFusFlg != TRUE)
    {
        return(RET_SUCCEED);
    }

    /************************************** Launch Fusion Request **********************************/

    /* Memory allocation */
    if ((fusArg = ALLOC_DYNST(Fus_Arg)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Fus_Arg");
        return(RET_MEM_ERR_ALLOC);
    }

    /* Set fields */
    SET_NULL_DICT(fusArg, Fus_Arg_DictId);
    SET_NULL_ID(fusArg, Fus_Arg_Id);
    SET_NULL_DATETIME(fusArg, Fus_Arg_BegDate);
    SET_NULL_DATETIME(fusArg, Fus_Arg_EndDate);
    SET_FLAG(fusArg, Fus_Arg_Flg, FALSE);
    SET_FLAG(fusArg, Fus_Arg_AutomaticFlg, FALSE);
    SET_ENUM(fusArg, Fus_Arg_PtfSize, PtfSize_None);

    /* Notify the fusion server */
    if (DBA_Notif(Fus, UNUSED, Fus_Arg, fusArg, nullptr, UNUSED) != RET_SUCCEED) /* PMSTA-26267 - CHU - 170301 */
    {
        FREE_DYNST(fusArg, Fus_Arg);
        MSG_RETURN(RET_GEN_ERR_NOACTION);
    }

    /* Free memory allocations */
    FREE_DYNST(fusArg, Fus_Arg);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ClosingSecurity()
**
**  Description :   Function which checks if
**                      - fusion start
**                      - insert/update/delete of an operation
**		    in an intermediate or final closing period
**
**  Arguments   :   ptfPtr		pointer on portfolio record (S_Ptf)
**		    superUserFlag	flag that indicates if user is superuser or not
**		    fusionStartFlag 	flag that indicates if this function is called by the dispatch server
**		    refdate		date to verify (operation reference date or fusion start date)
**                  msgStructPtr 	pointer on a structure which will contain
**                               	received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		    RET_FIN_ERR_CLOSINGSECURITY	closing period exists, no action is allowed
**		    RET_GEN_ERR_INVARG		error in arguments
**
**  Creation    :   REF2631 - 980902 - DED
**  Last modif. :   REF9303 - 030915 - PMO : Implementation of Unicode
**
*************************************************************************/
RET_CODE DBA_ClosingSecurity(DBA_DYNFLD_STP ptfPtr,
                             FLAG_T superUserFlag,
                             FLAG_T fusionStartFlag,
                             DATETIME_T refDate,
                             DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE ret = RET_SUCCEED;
    char buf[10], dateFmt[30], buf2[30];
    CLOSINGSECURITYRULE_ENUM closingSecRule;

    /* Check of arguments */
    if (ptfPtr == NULL || refDate.date == BAD_DATE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_ClosingSecurity", "portfolio or reference date");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get system parameter */
    GEN_GetApplInfo(ApplClosingSecurityRule, &closingSecRule);
    if (closingSecRule == ClosingSecurityRule_NoChecks)
    {
        /* Nothing to do */
        return(RET_SUCCEED);
    }

    /* Get portfolio information */
    DATETIME_T closingdate = GET_DATETIME(ptfPtr, S_Ptf_ClosingDate);
    FLAG_T finalClosingFlg = GET_FLAG(ptfPtr, S_Ptf_FinalClosingFlg);

    switch (closingSecRule)
    {
        case ClosingSecurityRule_UserIntermediate:
            if (finalClosingFlg == TRUE && superUserFlag == FALSE && DATETIME_CMP(refDate, closingdate) <= 0)
            {
                ret = RET_FIN_ERR_CLOSINGSECURITY;
            }
            break;

        case ClosingSecurityRule_SUInterFinal:
            if (DATETIME_CMP(refDate, closingdate) <= 0 && superUserFlag == FALSE)
            {
                ret = RET_FIN_ERR_CLOSINGSECURITY;
            }
            break;

        case ClosingSecurityRule_SUIntermediate:
            if ((DATETIME_CMP(refDate, closingdate) <= 0 && superUserFlag == FALSE) ||
                (DATETIME_CMP(refDate, closingdate) <= 0 && finalClosingFlg == TRUE && superUserFlag == TRUE))
            {
                ret = RET_FIN_ERR_CLOSINGSECURITY;
            }
            break;

        case ClosingSecurityRule_AllChecks:
            if (DATETIME_CMP(refDate, closingdate) <= 0)
            {
                ret = RET_FIN_ERR_CLOSINGSECURITY;
            }
            break;

        case ClosingSecurityRule_NoChecks:
            break;
    }

    /* Display error */
    if (ret == RET_FIN_ERR_CLOSINGSECURITY)
    {
        if (finalClosingFlg == TRUE)
        {
            strcpy(buf, "final");
        }
        else
        {
            strcpy(buf, "initial");
        }

        if (fusionStartFlag == FALSE)
        {
            FILLMSGSTRUCT(MSG_BuildMesg(UNUSED, "ERR-78", nullptr,
                                        TextType, buf,
                                        CodeType, GET_CODE(ptfPtr, S_Ptf_Cd),
                                        DatetimeType, refDate));
            return(RET_SRV_LIB_ERR_TRIGGER_MSG);
        }
        else
        {
            if (SYS_IsGuiMode() == FALSE)
            {
                CONV_GetDfltDateFmt(DatetimeType, dateFmt, NULL);
                CONV_DataToStr(buf2, sizeof(buf2), DatetimeType, dateFmt, GET_DATETIME64(refDate), FALSE, TextConversion_None);    /* REF9303 - 030915 - PMO */
                MSG_SendMesg(RET_FIN_ERR_CLOSINGSECURITY, 0, FILEINFO, buf, GET_CODE(ptfPtr, S_Ptf_Cd), buf2);
                MSG_LogSrvMesg(UNUSED, UNUSED, "Cannot start fusion on portfolio %1 because a %2 closing exists for this period (%3): see log file",
                               CodeType, GET_CODE(ptfPtr, S_Ptf_Cd),
                               InfoType, buf,
                               DatetimeType, refDate);
                return(RET_FIN_ERR_CLOSINGSECURITY);
            }
            else
            {
                FILLMSGSTRUCT(MSG_BuildMesg(UNUSED, "ERR-79", nullptr,
                                            TextType, buf,
                                            CodeType, GET_CODE(ptfPtr, S_Ptf_Cd),
                                            DatetimeType, refDate));
                return(RET_SRV_LIB_ERR_TRIGGER_MSG);
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_GetOldDataForAudit()
**
**  Description :   Retrieve the old value of a given entity.
**                  The behavior differs slightly when dealing
**                  with ExtOp.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    :   GRD - 000323 - Ref.: REF4204.
**
**  Last modif. :   FIH - 000425 - Ref.: REF4561.
**                  REF11589 - 120606 - PMO : Memory leak when retrieving extended operations from the database
*************************************************************************/
RET_CODE DBA_GetOldDataForAudit(OBJECT_ENUM object,
                                DBA_DYNST_ENUM dynStEn,
                                DBA_DYNFLD_STP inputData,
                                DbiConnection &dbiConn,
                                FLAG_T extOpFlg)
{
    RET_CODE retCode = RET_SUCCEED;

    if (object != EOp || extOpFlg == TRUE)
    {
        DBA_DYNFLD_STP shInputData = NULL;  /* REF11589 - 120606 - PMO */

        /*
         * Get the current value for the given entity.
         * DBA_ConvertAllDynstToShort does not work for ExtOp!
         * REF4204 - GRD - 000323. (Audit purpose).
         */

        if (GET_ADMINGUIST(object) != dynStEn)
        {
            DBA_ConvertAllDynstToShort(object, inputData, &shInputData);
            /*  FIH-REF4561-000426  In delete case input data is already a short structure  */
        }
        else
        {
            if ((shInputData = ALLOC_DYNST(dynStEn)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            DBA_CopyDynSt(shInputData, inputData, dynStEn);
        }

        if ((dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp =
                 ALLOC_DYNST(GET_EDITGUIST(object))) == NULL)
        {
            FREE_DYNST(shInputData, GET_ADMINGUIST(object));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        dbiConn.getConnStructPtr()->subscriptionElem.auditRecSt = GET_EDITGUIST(object);

        if (DBA_Get2(object,
                     UNUSED,
                     GET_ADMINGUIST(object),
                     shInputData,
                     dbiConn.getConnStructPtr()->subscriptionElem.auditRecSt,
                     & dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp,
                     DBA_SET_CONN | DBA_NO_CLOSE,
                     dbiConn) != RET_SUCCEED)
        {
            retCode = RET_GEN_INFO_NODATA;
        }
        FREE_DYNST(shInputData, GET_ADMINGUIST(object));  /* DLA - REF8666 - 030107 */
    }
    else
    {
        DBA_DYNFLD_STP *    oldExtOpSt = NULL;  /* REF11589 - 120606 - PMO */
        int resultRows = 0;                     /* REF11589 - 120606 - PMO */

        /*
         * Old ExtOp must be handled that way.
         */

        DBA_DYNFLD_STP sOp = ALLOC_DYNST(S_Op);
        SET_ID(sOp, S_Op_Id, OPE_GetOpIdFromExtOp(inputData)); /* DLA - REF7560 - 020821 */

        /* REF11589 - 120606 - PMO */
        retCode = DBA_Select2(EOp,
                              UNUSED,
                              S_Op,
                              sOp,
                              ExtOp,
                              &oldExtOpSt,
                              DBA_SET_CONN | DBA_NO_CLOSE,
                              UNUSED,
                              &resultRows,
                              dbiConn);

        FREE_DYNST(sOp, S_Op);

        if (retCode == RET_SUCCEED)
        {
            dbiConn.getConnStructPtr()->subscriptionElem.auditRecSt  = GET_EDITGUIST(object);
            dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp = oldExtOpSt[0];
            oldExtOpSt[0] = NULL;   /* REF11589 - 120606 - PMO */
        }

        (void)DBA_FreeDynStTab(oldExtOpSt, resultRows, ExtOp);  /* REF11589 - 120606 - PMO */
    }

    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_GetOldFusDateRule()
**
**  Description :   Return the fusion date rule with the old rule.
**                  This is a special function. The function to normally use
**                  is DBA_GetFusDateRule
**
**  Arguments   :   dynFldPtf               Record what contain the fusion date rule
**                  fusDateRuleIdx          Index into dynFldPtf about the field what contain the fusion date rule
**                  dynFldPpsPtf            Record what contain the fusion date rule of the PPS. NULL if no PPS
**                  fusDateRuleIdxPpsPtf    Index into dynFldPpsPtf about the field what contain the fusion date rule
**
**  Return      :   FusDateRule_None
**                  FusDateRule_OpDate
**                  FusDateRule_AcctDate
**                  FusDateRule_ValDate
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**                  REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**
*************************************************************************/
FUSDATERULE_ENUM DBA_GetOldFusDateRule(const DBA_DYNFLD_STP dynFldPtf,
                                       const int fusDateRuleIdx,
                                       const DBA_DYNFLD_STP dynFldPpsPtf,
                                       const int fusDateRuleIdxPpsPtf)
{
    FUSDATERULE_ENUM fusionDateRule = FusDateRule_None;

    if (NULL != dynFldPpsPtf)
    { /* Use the Fusion date rule from the PPS */
      /* Fusion date rule from the PPS portfolio */
        fusionDateRule = static_cast<FUSDATERULE_ENUM>(GET_ENUM(dynFldPpsPtf, fusDateRuleIdxPpsPtf));
    }

    /* Fusion date rule not defined from the PPS portfolio */
    if (fusionDateRule == FusDateRule_None && NULL != dynFldPtf)
    {
        /* Fusion date rule from the portfolio */
        fusionDateRule = static_cast<FUSDATERULE_ENUM>(GET_ENUM(dynFldPtf, fusDateRuleIdx));
    }

    /* Fusion date rule not defined for this portfolio */
    if (fusionDateRule == FusDateRule_None)
    { /* Fusion date rule from the application */
        (void)GEN_GetApplInfo(ApplFusDateRule, &fusionDateRule);
    }

    return fusionDateRule;
}




/************************************************************************
**
**  Function    :   DBA_GetOldFusDateRule()
**
**  Description :   Return the old fusion date rule. This function is for the case when all fusion dates are smaller than the switch date
**                  This is a special function.
**
**  Arguments   :   dynFldPtf                       Record what contain the fusion date rule
**                  fusDateRuleIdx                  Index into dynFldPtf about the field what contain the fusion date rule
**                  fusOldDateRuleIdx               Index into dynFldPtf about the field what contain the old fusion date rule
**                  dynFldPpsPtf                    Record what contain the fusion date rule of the PPS. NULL if no PPS
**                  fusDateRuleIdxPpsPtf            Index into dynFldPpsPtf about the field what contain the fusion date rule
**                  fusOldDateRuleIdx               Index into dynFldPpsPtf about the field what contain the old fusion date rule
**                  oldFusDateRuleSystemParameter   Old fusion date rule system parameter
**
**  Return      :   FusDateRule_None
**                  FusDateRule_OpDate
**                  FusDateRule_AcctDate
**                  FusDateRule_ValDate
**
**  Creation    :   REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**
*************************************************************************/
STATIC FUSDATERULE_ENUM DBA_GetFusDateRuleWhenBefore(const DBA_DYNFLD_STP   dynFldPtf,
                                                     const int              ,
                                                     const int              fusOldDateRuleIdx,
                                                     const DBA_DYNFLD_STP   dynFldPpsPtf,
                                                     const int              ,
                                                     const int              fusOldDateRulePpsIdx,
                                                     const FUSDATERULE_ENUM oldFusDateRuleSystemParameter)
{
    FUSDATERULE_ENUM fusionDateRule = FusDateRule_None;

    if ( NULL != dynFldPpsPtf && IS_NULLFLD(dynFldPpsPtf, fusOldDateRulePpsIdx) == false)
    { /* Use the Fusion date rule from the PPS */
      /* Fusion date rule from the PPS portfolio */
        fusionDateRule = static_cast<FUSDATERULE_ENUM>(GET_ENUM(dynFldPpsPtf, fusOldDateRulePpsIdx));
    }

    if ( FusDateRule_None == fusionDateRule
        && NULL != dynFldPtf   /*REF10256-EFE-041203*/
        && IS_NULLFLD(dynFldPtf, fusOldDateRuleIdx) == false
        && FusDateRule_None != static_cast<FUSDATERULE_ENUM>(GET_ENUM(dynFldPtf, fusOldDateRuleIdx))
    )
    {
        fusionDateRule = static_cast<FUSDATERULE_ENUM>(GET_ENUM(dynFldPtf, fusOldDateRuleIdx));
    }

    if (FusDateRule_None == fusionDateRule)
    {
        fusionDateRule = oldFusDateRuleSystemParameter;
    }

    return fusionDateRule;
}

/************************************************************************
**
**  Function    :   DBA_GetFusDateRule()
**
**  Description :   Return the fusion date rule
**                  You can use the function DBA_GetFusDate to copy the fusion date according to all rules
**
**  Arguments   :   dynFldPtf               Record what contain the fusion date rule
**                  fusDateRuleIdx          Index into dynFldPtf about the field what contain the fusion date rule
**                  fusOldDateRuleIdx       Index into dynFldPtf about the field what contain the old fusion date rule
**                  dynFldPpsPtf            Record what contain the fusion date rule of the PPS. NULL if no PPS
**                  fusDateRuleIdxPpsPtf    Index into dynFldPpsPtf about the field what contain the fusion date rule
**                  dynFld                  Input structure used to extract dates if ApplFusionSwitchDate is defined
**                  inputSt                 Wich structure {A_Execution, A_GlExecFee, ExtOp, ExtPos}
**                  aPtf                    The structure all portfolio
**
**  Return      :   FusDateRule_None
**                  FusDateRule_OpDate
**                  FusDateRule_AcctDate
**                  FusDateRule_ValDate
**                  FusDateRule_UseSwitchDate
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**                  REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**                  REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**
*************************************************************************/
FUSDATERULE_ENUM DBA_GetFusDateRule(const DBA_DYNFLD_STP dynFldPtf,
                                    const int fusDateRuleIdx,
                                    const int fusOldDateRuleIdx,     /* REF10785 - 041129 - PMO */
                                    const DBA_DYNFLD_STP dynFldPpsPtf,
                                    const int fusDateRuleIdxPpsPtf,
                                    const DBA_DYNFLD_STP dynFld,
                                    const DBA_DYNST_ENUM inputSt)
{
    DATE_T           fusionSwitchDate;            /* Value of the system parameter    */
    FUSDATERULE_ENUM fusionDateRule = DBA_GetOldFusDateRule(dynFldPtf,
                                                           fusDateRuleIdx,
                                                           dynFldPpsPtf,
                                                           fusDateRuleIdxPpsPtf);

    /* Obtain the system parameter */
    (void)GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate);

    /* System parameter defined */
    if (0 != DATE_Cmp(fusionSwitchDate, MAGIC_END_DATE))
    {                                                       /* Yes */
        FUSDATERULE_ENUM oldFusionDateRule;                 /* Old fusion date rule from the system parameter   */
        DATE_T beginDateOldFusionDateRule;                  /* Calculated with old fusion date                  */
        DATE_T beginDateFusionDateRule;                     /* Calculated with fusion date rule                 */
        DATETIME_T beginDateTimeOldFusionDateRule;          /* Calculated with old fusion date                  */
        DATETIME_T beginDateTimeFusionDateRule;             /* Calculated with fusion date rule                 */
        int accountingDateIdx;                              /* Index of the accounting date in dynFld           */
        int valueDateDateIdx;                               /* Index of the value date in dynFld                */
        int operationDateIdx;                               /* Index of the operation date in dynFld            */

        if (inputSt == ExtOp)
        {
            accountingDateIdx = ExtOp_AcctDate;
            valueDateDateIdx  = ExtOp_ValueDate;
            operationDateIdx  = ExtOp_OpDate;
        }
        else if (inputSt == A_Execution)
        {
            accountingDateIdx = A_Execution_AccountDate;
            valueDateDateIdx  = A_Execution_ValueDate;
            operationDateIdx  = A_Execution_OperationDate;
        }
        else if (inputSt == A_GlExecFee)
        {
            accountingDateIdx = A_GlExecFee_AccountDate;
            valueDateDateIdx  = A_GlExecFee_ValueDate;
            operationDateIdx  = A_GlExecFee_OperationDate;
        }
        else if (inputSt == ExtPos)
        {
            accountingDateIdx = ExtPos_AcctDate;
            valueDateDateIdx  = ExtPos_ValDate;
            operationDateIdx  = ExtPos_OpDate;
        }
        else
        {
            /* Bad structure and bad values */
            assert(178 == 291);
            accountingDateIdx = 0;
            valueDateDateIdx  = 0;
            operationDateIdx  = 0;
        }

        (void)GEN_GetApplInfo(ApplOldFusionDateRule, &oldFusionDateRule);

        /* Compute begin date */
        DBA_GetFusDate(&beginDateTimeOldFusionDateRule,
                       oldFusionDateRule,
                       dynFld,
                       accountingDateIdx,
                       valueDateDateIdx,
                       operationDateIdx);
        DBA_GetFusDate(&beginDateTimeFusionDateRule,
                       fusionDateRule,
                       dynFld,
                       accountingDateIdx,
                       valueDateDateIdx,
                       operationDateIdx);

        /* Extract the date from datetime */
        beginDateOldFusionDateRule = beginDateTimeOldFusionDateRule.date;
        beginDateFusionDateRule    = beginDateTimeFusionDateRule.date;

        /* The switch date is enabled only when all ways to compute begin dates are lower */
        if (DATE_Cmp(beginDateOldFusionDateRule, fusionSwitchDate) < 0 &&
            DATE_Cmp(beginDateFusionDateRule,    fusionSwitchDate) < 0)
        { /* All fusion dates are smaler than the fusion swithc date */

            fusionDateRule = DBA_GetFusDateRuleWhenBefore(dynFldPtf,
                                                          fusDateRuleIdx,
                                                          fusOldDateRuleIdx,
                                                          dynFldPpsPtf,
                                                          fusDateRuleIdxPpsPtf,
                                                          A_PtfPosSet_OldFusDateRuleEn,
                                                          oldFusionDateRule);
        }
        else
        {
            /* One of begin dates is greater than the switch date */
            if (DATE_Cmp(beginDateOldFusionDateRule, fusionSwitchDate) > 0 &&
                DATE_Cmp(beginDateFusionDateRule,    fusionSwitchDate) > 0)
            {
                /* No code, default is ok */
            }
            else
            { /* fusionSwitchDate is between beginDateOldFusionDateRule and beginDateFusionDateRule */
                FLAG_T fusionSwitchRule;

                /* Obtain system parameters */
                (void)GEN_GetApplInfo(ApplFusionSwitchRule, &fusionSwitchRule);

                switch (fusionSwitchRule)
                {
                    case 0:
                        /* No code, default is ok */
                        break;

                    case 1:
                        /* Fusion date rule from the application */
                        fusionDateRule = oldFusionDateRule;
                        break;

                    case 2:
                        fusionDateRule = FusDateRule_UseSwitchDate;
                        break;

                }   /* End switch */

            }       /* End if */

        }           /* End if */

    }               /* End if */

    return fusionDateRule;
}


/************************************************************************
**
**  Function    :   DBA_GetFusDate()
**
**  Description :   Copy the fusion date in *refDatePtr according to the fusion date rule
**
**  Arguments   :   refDatePtr          The fusion reference date
**                  fusionDateRule      The fusion date rule
**                  dynFld              Source of the date
**                  accountingDateIdx   Index of the accounting date in dynFld
**                  valueDateDateIdx    Index of the value date in dynFld
**                  operationDateIdx    Index of the operation date in dynFld
**
**  Return      :   None
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
void DBA_GetFusDate(DATETIME_T *             refDatePtr,
                    const FUSDATERULE_ENUM fusionDateRule,
                    const DBA_DYNFLD_STP dynFld,
                    const int accountingDateIdx,
                    const int valueDateDateIdx,
                    const int operationDateIdx)
{
    /* Check security on closing periods */
    switch (fusionDateRule)
    {
        case FusDateRule_AcctDate:
            *refDatePtr = GET_DATETIME(dynFld, accountingDateIdx);
            break;

        case FusDateRule_ValDate:
            *refDatePtr = GET_DATETIME(dynFld, valueDateDateIdx);
            break;

        case FusDateRule_OpDate:
        case FusDateRule_None:
            *refDatePtr = GET_DATETIME(dynFld, operationDateIdx);
            break;

        case FusDateRule_UseSwitchDate:
            {
                DATE_T fusionSwitchDate;    /* Value of the system parameter    */

                /* Obtain the system parameter */
                (void)GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate);

                /* Init the structure and copy the date */
                memset(refDatePtr, 0, sizeof(DATETIME_T));
                refDatePtr->date = fusionSwitchDate;
            }
            break;
    }
}


/************************************************************************
**
**  Function    :   DBA_GetFusDateExtPos()
**
**  Description :   Set the fusion date according to the fusion date rule
**
**  Arguments   :   refDatePtr      The fusion reference date
**                  fusionDateRule  The fusion date rule
**                  extOpStPtr      Source of the date
**
**  Return      :   None
**
**  Creation    :   REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**
*************************************************************************/
void DBA_GetFusDateExtPos(DATETIME_T *              refDatePtr,
                          const FUSDATERULE_ENUM fusionDateRule,
                          const DBA_DYNFLD_STP extOpStPtr)
{
    DBA_GetFusDate(refDatePtr,
                   fusionDateRule,
                   extOpStPtr,
                   ExtPos_AcctDate,
                   ExtPos_ValDate,
                   ExtPos_OpDate);
}


/************************************************************************
**
**  Function    :   DBA_GetFusDateExtOp()
**
**  Description :   Set the fusion date according to the fusion date rule
**
**  Arguments   :   refDatePtr      The fusion reference date
**                  fusionDateRule  The fusion date rule
**                  extOpStPtr      Source of the date
**
**  Return      :   None
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**                  REF10256 - 040608 - PMO : Switch from old Fusion Date Rule to new Fusion Date Rule at the Fusion Switch Date
**
*************************************************************************/
void DBA_GetFusDateExtOp(DATETIME_T *             refDatePtr,
                         const FUSDATERULE_ENUM fusionDateRule,
                         const DBA_DYNFLD_STP extOpStPtr)
{
    DBA_GetFusDate(refDatePtr,
                   fusionDateRule,
                   extOpStPtr,
                   ExtOp_AcctDate,
                   ExtOp_ValueDate,
                   ExtOp_OpDate);
}




/************************************************************************
**
**  Function    :   DBA_GetFusDateExecution()
**
**  Description :   Copy the fusion date in *refDatePtr according to the fusion date rule
**
**  Arguments   :   refDatePtr      The fusion reference date
**                  fusionDateRule  The fusion date rule
**                  aExecutionPtr   Source of the date
**
**  Return      :   None
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
STATIC void DBA_GetFusDateExecution(DATETIME_T *             refDatePtr,
                                    const FUSDATERULE_ENUM fusionDateRule,
                                    const DBA_DYNFLD_STP aExecutionPtr)
{
    DBA_GetFusDate(refDatePtr,
                   fusionDateRule,
                   aExecutionPtr,
                   A_Execution_AccountDate,
                   A_Execution_ValueDate,
                   A_Execution_OperationDate);
}


/************************************************************************
**
**  Function    :   DBA_GetFusDateGlobalFee()
**
**  Description :   Copy the fusion date in *refDatePtr according to the fusion date rule
**
**  Arguments   :   refDatePtr      The fusion reference date
**                  fusionDateRule  The fusion date rule
**                  aGlExecFee      Source of the date
**
**  Return      :   None
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
STATIC void DBA_GetFusDateGlobalFee(DATETIME_T *             refDatePtr,
                                    const FUSDATERULE_ENUM fusionDateRule,
                                    const DBA_DYNFLD_STP aGlExecFee)
{
    DBA_GetFusDate(refDatePtr,
                   fusionDateRule,
                   aGlExecFee,
                   A_GlExecFee_AccountDate,
                   A_GlExecFee_ValueDate,
                   A_GlExecFee_OperationDate);
}


/************************************************************************
**
**  Function    :   DBA_BeginDateExecutionProcessing()
**
**  Description :   Set the begin date according to the fusion date rule
**
**  Arguments   :   inputSt             The input dynamic structure format
**                  dynFld              The pointer on a all execution record
**                  dynFldExtOrderIdx   Index of the field ExtOrderId.
**                                      Can be A_Execution_ExtOrderId or A_GlExecFee_ExtOrderId
**                  dynFldBeginDateIdx  Index of the field begin date in dynFld
**                                      Can be A_Execution_BeginDate or A_GlExecFee_BeginDate
**                  connectNo           The connection number
**                  msgStructPtr        Pointer on a structure which will contain
**                                      received messages informations.
**
**  Return      :   RET_SUCCEED         If ok
**		            RET_MEM_ERR_ALLOC   Error in memory allocation
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
**  Last modif. :   REF10785 - 041129 - PMO : A fusion all not take into account the OLD_FUSION_DATE_RULE or/and THE FUSION_SWITCH_DATE parameter
**
*************************************************************************/
STATIC RET_CODE DBA_BeginDateExecutionProcessing(DBA_DYNST_ENUM inputSt,
                                                 DBA_DYNFLD_STP dynFld,
                                                 const int dynFldExtOrderIdx,
                                                 const int dynFldBeginDateIdx,
                                                 DbiConnection &dbiConn)

{
    DBA_DYNFLD_STP getArg;          /* Input structure                      */
    DBA_DYNFLD_STP sPtf;            /* Output structure                     */
    RET_CODE ret;                   /* Return value                         */


    /* Allocate memory for input structure */
    if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 2, FILEINFO, "DBA_BeginDateExecutionProcessing");
    }
    else
    { /* Ok */
        ret = RET_SUCCEED;
    }


    if (ret == RET_SUCCEED)
    {
        /* Allocate memory for input structure */
        if ((sPtf = ALLOC_DYNST(S_Ptf)) == NULL)
        { /* Error */
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "DBA_BeginDateExecutionProcessing");
        }
        else
        { /* Ok */

            /* Fill input structure */
            COPY_DYNFLD(getArg, Get_Arg, Get_Arg_Id, dynFld, inputSt, dynFldExtOrderIdx);

            /* Call get_sh_portfolio_by_eo_id */
            ret = DBA_Get2(Ptf, UNUSED, Get_Arg, getArg, S_Ptf, &sPtf, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            if (ret == RET_SUCCEED)
            {
                DATETIME_T refDate;             /* Reference date for this portfolio    */

                /* REF8844 - LJE - 030415 */
                if (inputSt == A_Execution )
                {
                    /* Obtain the fusion date rule for this portfolio */
                    DBA_GetFusDateExecution(&refDate,
                                            DBA_GetFusDateRule(sPtf,
                                                               S_Ptf_FusionDateRuleEn,
                                                               S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                                               NULL,
                                                               0,
                                                               dynFld,
                                                               inputSt),
                                            dynFld);

                }
                else if (inputSt == A_GlExecFee)
                {
                    /* Obtain the fusion date rule for this portfolio */
                    DBA_GetFusDateGlobalFee(&refDate,
                                            DBA_GetFusDateRule(sPtf,
                                                               S_Ptf_FusionDateRuleEn,
                                                               S_Ptf_OldFusionDateRuleEn, /* REF10785 - 041129 - PMO */
                                                               NULL,
                                                               0,
                                                               dynFld,
                                                               inputSt),
                                            dynFld);

                }
                else
                {
                    ret = RET_GEN_ERR_INVARG;
                    MSG_SendMesg(ret, 2, FILEINFO, "DBA_BeginDateExecutionProcessing");
                    memset(&refDate, 0, sizeof(refDate));
                }

                if (ret == RET_SUCCEED)
                {
                    /* Set the begin date with the date defined by the fusion date rule */
                    SET_DATETIME(dynFld, dynFldBeginDateIdx, refDate);
                }

                FREE_DYNST(sPtf, S_Ptf);
            }

        }

        FREE_DYNST(getArg, Get_Arg);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_CheckExecution()
**
**  Description :   Check the validity of a execution
**
**  Arguments   :   dynFld              The pointer on a all execution record
**                  dynFldStatusEnIdx   Index of the field begin date in dynFld
**                                      Can be A_Execution_StatusEn or A_GlExecFee_StatusEn
**                  msgStructPtr        Pointer on a structure which will contain
**                                      received messages informations.
**
**  Return      :   RET_SUCCEED         if ok
**		            RET_GEN_ERR_INVARG	invalid argument
**
**  Creation    :   REF7560 - 021015 - PMO : Order Management Entity light project: database infrastructure
**  Last modif. :   REF8426 - 021112 - PMO : Wrong message is called
**
*************************************************************************/
static RET_CODE DBA_CheckExecution(const DBA_DYNFLD_STP dynFld,
                                   const int dynFldStatusEnIdx,
                                   DbiConnection         &dbiConn)
{
    OPSTAT_ENUM     accountingStatus = OpStat_None;   /* Level of the current accounting status */
    RET_CODE        ret              = RET_SUCCEED;

    (void)GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

    /*
     *  Set an error if the execution is accounted
     */
    if (static_cast<OPSTAT_ENUM>(GET_ENUM(dynFld, dynFldStatusEnIdx)) >= accountingStatus)
    {
        FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "EXECUTION_STATUS", nullptr));

        ret = RET_GEN_ERR_INVARG;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_InsExecutionById()
**
**  Description :   Insert an execution into the database
**                  Set begin date is defined according to the fusion date rule
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  aExecution   the pointer on a all execution record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
RET_CODE DBA_InsExecutionById(OBJECT_ENUM object,
                              DBA_DYNST_ENUM inputSt,
                              DBA_DYNFLD_STP aExecution,
                              DbiConnectionHelper& dbiConnHelper)
{
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

    /* Processing of the begin date */
    RET_CODE ret = DBA_BeginDateExecutionProcessing(inputSt,
                                                    aExecution,
                                                    A_Execution_ExtOrderId,
                                                    A_Execution_BeginDate,
                                                    dbiConn);

    if (ret == RET_SUCCEED)
    {
        /* Check the execution */
        ret = DBA_CheckExecution(aExecution, A_Execution_StatusEn, dbiConn);
    }

    /*
     *  Set the flag ExtOp_NoPositionFlg
     */
    NOTE_T applNoOpenPositionStatusesStr;   /* DLA - PMSTA07201 - 090402 */
    applNoOpenPositionStatusesStr[0] = 0;   /* DLA - PMSTA07201 - 090402 */
    (void)GEN_GetApplInfo(ApplNoOpenPositionStatuses, applNoOpenPositionStatusesStr ); /* DLA - PMSTA07201 - 090402 */

    /* Check if Op_StatusEn match with a number in the string */
    if (DBA_IntExistInString(static_cast<int>(GET_ENUM(aExecution, A_Execution_StatusEn)), applNoOpenPositionStatusesStr) == TRUE) /* DLA - PMSTA07201 - 090402 */
    { /* Number found */
        SET_FLAG(aExecution, A_Execution_NoPositionFlg, TRUE);
    }
    else
    { /* Number not found */
        SET_FLAG(aExecution, A_Execution_NoPositionFlg, FALSE);
    }

    /* In block mode skip the insert. Another call as been made */
    if (ret == RET_SUCCEED && dbiConn.getConnStructPtr()->blockMode == FALSE)
    {
        if ( (ret= createHierExecution(object, inputSt, aExecution, dbiConnHelper)) != RET_SUCCEED)
        {
            /* split failed. do not insert block also. */
            MSG_SendMesg(FILEINFO, "Execution split for hier grouping failed.");
            return ret;
        } 
       ret = dbiConnHelper.dbaInsert(object, DBA_ROLE_EXECUTIONS, aExecution);
       
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_UpdExecution()
**
**  Description :   Update an execution into the database
**                  Set begin date is defined according to the fusion date rule
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  aExecution   the pointer on a all execution record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    : REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
RET_CODE DBA_UpdExecution(OBJECT_ENUM object,
                          DBA_DYNST_ENUM inputSt,
                          DBA_DYNFLD_STP aExecution,
                          DbiConnectionHelper& dbiConnHelper)
{
    NOTE_T               applNoOpenPositionStatusesStr;   /* DLA - PMSTA07201 - 090402 */
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

    applNoOpenPositionStatusesStr[0] = 0;   /* DLA - PMSTA07201 - 090402 */


    /* Processing of the begin date */
    RET_CODE ret = DBA_BeginDateExecutionProcessing(inputSt,
                                                   aExecution,
                                                   A_Execution_ExtOrderId,
                                                   A_Execution_BeginDate,
                                                   dbiConn);

    if (ret == RET_SUCCEED)
    {
        /* Check the execution */
        ret = DBA_CheckExecution(aExecution, A_Execution_StatusEn, dbiConn);
    }

    /*
     *  Set the flag ExtOp_NoPositionFlg
     */
    (void)GEN_GetApplInfo(ApplNoOpenPositionStatuses, applNoOpenPositionStatusesStr ); /* DLA - PMSTA07201 - 090402 */

    /* Check if Op_StatusEn match with a number in the string */
    if (DBA_IntExistInString(static_cast<int>(GET_ENUM(aExecution, A_Execution_StatusEn)), applNoOpenPositionStatusesStr) == TRUE) /* DLA - PMSTA07201 - 090402 */
    { /* Number found */
        SET_FLAG(aExecution, A_Execution_NoPositionFlg, TRUE);
    }
    else
    { /* Number not found */
        SET_FLAG(aExecution, A_Execution_NoPositionFlg, FALSE);
    }

    /* In block mode skip the insert. Another call as been made */
    if (ret == RET_SUCCEED && dbiConn.getConnStructPtr()->blockMode == FALSE)
    {
        /* Call upd_execution */
        ret = DBA_Update2(object,
                          DBA_ROLE_EXECUTIONS,
                          inputSt,
                          aExecution,
                          DBA_SET_CONN | DBA_NO_CLOSE,
                          dbiConn);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_InsExecutionFeeById()
**
**  Description :   Insert an execution into the database
**                  Set begin date is defined according to the fusion date rule
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  aExecution   the pointer on a all execution record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    :   REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
RET_CODE DBA_InsExecutionFeeById(OBJECT_ENUM object,
                                 DBA_DYNST_ENUM inputSt,
                                 DBA_DYNFLD_STP aGlExecFee,
                                 DbiConnectionHelper& dbiConnHelper)
{
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

    /* Processing of the begin date */
    RET_CODE ret = DBA_BeginDateExecutionProcessing(inputSt,
                                                   aGlExecFee,
                                                   A_GlExecFee_ExtOrderId,
                                                   A_GlExecFee_BeginDate,
                                                   dbiConn);

    if (ret == RET_SUCCEED)
    {
        /* Check the execution */
        ret = DBA_CheckExecution(aGlExecFee, A_GlExecFee_StatusEn, dbiConn);
    }

    /* In block mode skip the insert. Another call as been made */
    if (ret == RET_SUCCEED && dbiConn.getConnStructPtr()->blockMode == FALSE)
    {

        /* Call ins_execution_by_id */
        ret = dbiConnHelper.dbaInsert(object, DBA_ROLE_EXECUTIONS, aGlExecFee);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_UpdExecutionFee()
**
**  Description :   Update an execution into the database
**                  Set begin date is defined according to the fusion date rule
**
**  Arguments   :   object       the request corresponding object
**                  inputSt      the input dynamic structure format
**                  aExecution   the pointer on a all execution record
**                  connectNo    the connection number
**                  msgStructPtr pointer on a structure which will contain
**                               received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    : REF7560 - 020814 - PMO : Order Management Entity light project: database infrastructure
**
*************************************************************************/
RET_CODE DBA_UpdExecutionFee(OBJECT_ENUM object,
                             DBA_DYNST_ENUM inputSt,
                             DBA_DYNFLD_STP aGlExecFee,
                             DbiConnectionHelper& dbiConnHelper)
{
    DbiConnection&      dbiConn = *dbiConnHelper.getConnection();

    /* Processing of the begin date */
    RET_CODE ret = DBA_BeginDateExecutionProcessing(inputSt,
                                                    aGlExecFee,
                                                    A_GlExecFee_ExtOrderId,
                                                    A_GlExecFee_BeginDate,
                                                    dbiConn);

    if (ret == RET_SUCCEED)
    {
        /* Check the execution */
        ret = DBA_CheckExecution(aGlExecFee, A_GlExecFee_StatusEn, dbiConn);
    }

    /* In block mode skip the insert. Another call as been made */
    if (ret == RET_SUCCEED && dbiConn.getConnStructPtr()->blockMode == FALSE)
    {
        /* Call upd_execution */
        ret = DBA_Update2(object,
                          DBA_ROLE_EXECUTIONS,
                          inputSt,
                          aGlExecFee,
                          DBA_SET_CONN | DBA_NO_CLOSE,
                          dbiConn);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_SaveUnmatchedExecution
**
**  Description :   Save an unmatched execution
**
**  Arguments   :   aUnmatched      the pointer on a all unmatched execution record
**                  msgStructPtr    pointer on a structure which will contain
**                                  received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    :   REF9764 - TEB - 040205
**
**  Last modif. :   REF10233 - TEB - 040513
**                  REF10339 - TEB - 040603
**
*************************************************************************/
RET_CODE DBA_SaveUnmatchedExecution(DbiConnectionHelper& dbiConnHelper, DBA_DYNFLD_STP aUnmatched)
{
    DBA_DYNFLD_STP aExecOrGloFee = NULL;        /*  All execution or global fee */
    DBA_DYNST_ENUM aDynSt = NullDynSt,          /*  Dynamic structure enum      */
                   sDynSt = NullDynSt;          /*  Dynamic structure enum      */
    OBJECT_ENUM enObject = NullEntity;          /*  Execution or global exec    */
    int aIdFldIndex = -1,                       /*  Index for id field          */
        sIdFldIndex = -1;                       /*  Index for id field          */
    FLAG_T retFlg = FALSE;                      /*  Some Flags                  */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection &dbiConn = *dbiConnHelper.getConnection();

    /* Open transaction */
    RET_CODE retCode = dbiConn.beginTransaction();

    if (retCode == RET_SUCCEED)
    {
        /* First convert unmatched exec into db entity ExecutionEnt or GlExecFeeEnt */
        switch (GET_ENUM(aUnmatched, A_UnMatchedExecution_ExecNatureEn))
        {
            case UnmatchNat_Execution:
                aDynSt        = A_Execution;
                sDynSt        = S_Execution;
                enObject      = ExecutionEnt;
                aIdFldIndex   = A_Execution_Id;
                sIdFldIndex   = S_Execution_Id;
                break;

            case UnmatchNat_GlExecFee:
                aDynSt        = A_GlExecFee;
                sDynSt        = S_GlExecFee;
                enObject      = GlExecFeeEnt;
                aIdFldIndex   = A_GlExecFee_Id;
                sIdFldIndex   = A_GlExecFee_Id;
                break;

            default:
                aDynSt        = NullDynSt;
                sDynSt        = NullDynSt;
                enObject      = NullEntity;
                aIdFldIndex   = -1;
                sIdFldIndex   = -1;
                FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "UMEX_NATURE", nullptr));
                retCode  = RET_GEN_ERR_INVARG;
                break;
        }
    }

    if (retCode == RET_SUCCEED)
    {
        if ((aExecOrGloFee = ALLOC_DYNST(aDynSt)) == NULL)
        {
            retCode = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(retCode, 0, FILEINFO, retCode);
            /* Rollback. */
            dbiConn.endTransaction(FALSE);
            return(retCode);
        }
        else
        {
            retCode = CONVERT_DYNST(aExecOrGloFee, aDynSt, aUnmatched, A_UnMatchedExecution);
        }
    }


    /* Check the import mode */
    if (retCode == RET_SUCCEED)
    {
        switch (GET_ENUM(aUnmatched, A_UnMatchedExecution_ImportModeEn))
        {                                   /* Actions to take */
            case ImportModeNat_Insert:
            case ImportModeNat_GuiEntry:    /* REF10233 - TEB - 040513 */

                /* REF10339 - TEB - 040603 */
                /* Insert the execution (or glob fee) */
                retCode = DBA_Insert2(enObject,
                                      UNUSED,  /* REF10339 - TEB - 040603 */
                                      aDynSt,
                                      aExecOrGloFee,
                                      DBA_SET_CONN | DBA_NO_CLOSE,
                                      dbiConn);

                /* If every thing is ok, delete unmatched execution */
                if (retCode == RET_SUCCEED)
                {
                    retCode = DBA_DelRecById(GET_ID(aUnmatched, A_UnMatchedExecution_Id),
                                             UnMatchedExecution,
                                             S_UnMatchedExecution,
                                             S_UnMatchedExecution_Id,
                                             dbiConn);
                }

                break;

            case ImportModeNat_Update:
                /* REF10339 - TEB - 040603 */
                /* Verify that we have the Id on the record */
                retCode = DBA_GetExecWithId(&aExecOrGloFee,
                                            enObject,
                                            FALSE,
                                            &retFlg,
                                            dbiConn);
                if (retFlg == FALSE)
                {
                    retCode = RET_GEN_ERR_INVARG;
                }

                /* Try to make the update */
                if (retCode == RET_SUCCEED)
                {
                    retCode = DBA_Update2(enObject,
                                          UNUSED,       /* REF10339 - TEB - 040603 */
                                          aDynSt,
                                          aExecOrGloFee,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConn);
                }

                /* If every thing is ok, delete unmatched execution */
                if (retCode == RET_SUCCEED)
                {
                    retCode = DBA_DelRecById(GET_ID(aUnmatched, A_UnMatchedExecution_Id),
                                             UnMatchedExecution,
                                             S_UnMatchedExecution,
                                             S_UnMatchedExecution_Id,
                                             dbiConn);
                }
                break;

            case ImportModeNat_Delete:
                /* Verify that we have the Id on the record */
                retCode = DBA_GetExecWithId(&aExecOrGloFee,
                                            enObject,
                                            FALSE,
                                            &retFlg,
                                            dbiConn);

                if (retFlg == FALSE)
                {
                    retCode = RET_GEN_ERR_INVARG;
                }

                /* Perform the delete of the execution (or glob fee) */
                if (retCode == RET_SUCCEED)
                {
                    retCode = DBA_DelRecById(GET_ID(aExecOrGloFee, aIdFldIndex),
                                             enObject,
                                             sDynSt,
                                             sIdFldIndex,
                                             dbiConn);
                }

                /* If every thing is ok, delete unmatched execution */
                if (retCode == RET_SUCCEED)
                {
                    retCode = DBA_DelRecById(GET_ID(aUnmatched, A_UnMatchedExecution_Id),
                                             UnMatchedExecution,
                                             S_UnMatchedExecution,
                                             S_UnMatchedExecution_Id,
                                             dbiConn);
                }
                break;

            case ImportModeNat_InsUpd:
            case ImportModeNat_UpdIns:
                /* REF10339 - TEB - 040603 */
                /* First make a get */
                retCode = DBA_GetExecWithId(&aExecOrGloFee,
                                            enObject,
                                            TRUE,
                                            &retFlg,
                                            dbiConn);

                if (retCode == RET_SUCCEED)
                {
                    /* If record doesn't exist in DB, insert, else update */
                    if (retFlg == FALSE)
                    {
                        retCode = DBA_Insert2(enObject,
                                              UNUSED,       /* REF10339 - TEB - 040603 */
                                              aDynSt,
                                              aExecOrGloFee,
                                              DBA_SET_CONN | DBA_NO_CLOSE,
                                              dbiConn);
                    }
                    else
                    {
                        retCode = DBA_Update2(enObject,
                                              UNUSED,       /* REF10339 - TEB - 040603 */
                                              aDynSt,
                                              aExecOrGloFee,
                                              DBA_SET_CONN | DBA_NO_CLOSE,
                                              dbiConn);
                    }

                    /* If every thing is ok, delete unmatched execution */
                    if (retCode == RET_SUCCEED)
                    {
                        retCode = DBA_DelRecById(GET_ID(aUnmatched, A_UnMatchedExecution_Id),
                                                 UnMatchedExecution,
                                                 S_UnMatchedExecution,
                                                 S_UnMatchedExecution_Id,
                                                 dbiConn);
                    }
                }
                break;

            default:  /* This should be an error */
                FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "UMEX_IMP_MODE", nullptr));
                retCode  = RET_GEN_ERR_INVARG;
                break;
        }
    }

    /* Close transaction */
    if (retCode == RET_SUCCEED)
    {
        dbiConn.endTransaction(TRUE);    /* Commit. */
    }
    else
    {
        dbiConn.endTransaction(FALSE);   /* Rollback. */
    }
    FREE_DYNST(aExecOrGloFee, aDynSt);

    return(retCode);
}


/************************************************************************
**
**  Function    :   DBA_GetExecWithId
**
**  Description :   Get the existing execution / global exec fee (in
**                  function of enObject) with his Id
**
**  Arguments   :   *aExecOrGloFee  record to be checked (always All struct)
**                  enObject        onject enum
**                  connectNo       the connection number
**                  dbCheckFlag     with check existing of record in DB
**                  retFlg          returned Flg
**                  msgStructPtr    pointer on a structure which will contain
**                                  received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    :   REF9764 - TEB - 040210
**
*************************************************************************/
STATIC RET_CODE DBA_GetExecWithId(DBA_DYNFLD_STP * aExecOrGloFee,
                                  OBJECT_ENUM enObject,
                                  FLAG_T dbCheckFlag,
                                  FLAG_T * retFlg,
                                  DbiConnection &dbiConn)
{
    DICT_ATTRIB_STP attribute;

    *retFlg = FALSE;

    memset(&attribute, 0, sizeof(attribute));

    /* Search index of Ids */
    RET_CODE ret = DBA_SearchAttribSqlName(enObject, "id", &attribute);

    if (ret == RET_SUCCEED)
    {
        const int sIdFldIndex = attribute->shortIdx;   /* Index for id in short */
        const int aIdFldIndex = attribute->progN;      /* Index for id in all */

        /* Check if id is forhanden, else search record on BK */
        if (IS_NULLFLD((*aExecOrGloFee), aIdFldIndex) == true ||
            GET_ID((*aExecOrGloFee), aIdFldIndex) <= 0 )
        {
            DBA_DYNFLD_STP  sExecOrGloFee = ALLOC_DYNST(GET_ADMINGUIST(enObject));

            if (nullptr == sExecOrGloFee)
            {
                ret = RET_MEM_ERR_ALLOC;
                MSG_SendMesg(ret, 0, FILEINFO, ret);
                return (ret);
            }

            /* Build the business key for the get */
            const DBA_DYNST_ENUM    aDynSt     = GET_EDITGUIST(enObject);
            int                     count      = 0;
            DICT_ATTRIB_STP *       attributes = nullptr;

            DBA_GetBusinessAttrib(enObject, &count, &attributes);
            for (int n = 0; n < count; n++)
            {
                if ( IS_NULLFLD((*aExecOrGloFee), attributes[n]->progN) == true )
                {
                    FILLMSGSTRUCTC(&dbiConn, MSG_BuildMesg(UNUSED, "UMEX_BK_INCOMPLET", nullptr));
                    ret = RET_GEN_ERR_INVARG;
                }
                else
                {
                    COPY_DYNFLD(sExecOrGloFee,
                                GET_ADMINGUIST(enObject),
                                attributes[n]->shortIdx,
                                (*aExecOrGloFee),
                                aDynSt,
                                attributes[n]->progN);
                }
            }

            /* Get the record by BK to find the id */
            if (ret == RET_SUCCEED &&
                DBA_Get2(enObject,
                         UNUSED,
                         GET_ADMINGUIST(enObject),
                         sExecOrGloFee,
                         GET_ADMINGUIST(enObject),
                         &sExecOrGloFee,
                         DBA_SET_CONN | DBA_NO_CLOSE,
                         dbiConn) == RET_SUCCEED)
            { /*If we found id, put it in All struct */
                COPY_DYNFLD((*aExecOrGloFee),
                            aDynSt,
                            aIdFldIndex,
                            sExecOrGloFee,
                            GET_ADMINGUIST(enObject),
                            sIdFldIndex);

                *retFlg = TRUE;
            }

            FREE_DYNST(sExecOrGloFee, GET_ADMINGUIST(enObject));
        }
        else
        {
            /* Input structure has got an Id */
            /* Do we have to check in DB ?   */
            if (dbCheckFlag == TRUE)
            {
                DBA_DYNFLD_STP tmpExecOrGloFee = ALLOC_DYNST(GET_EDITGUIST(enObject));

                if (nullptr == tmpExecOrGloFee)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    MSG_SendMesg(ret, 0, FILEINFO, ret);
                    return(ret);
                }

                if (DBA_Get2(enObject,
                             UNUSED,
                             GET_EDITGUIST(enObject),
                             (*aExecOrGloFee),
                             GET_EDITGUIST(enObject),
                             &tmpExecOrGloFee,
                             DBA_SET_CONN | DBA_NO_CLOSE,
                             dbiConn) == RET_SUCCEED )
                {
                    *retFlg = TRUE;
                }
                else
                {
                    *retFlg = FALSE;
                }

                FREE_DYNST(tmpExecOrGloFee, GET_EDITGUIST(enObject));
            }
            else
            {
                *retFlg = TRUE;
            }
        }
    }
    else
    {
        *retFlg = FALSE;
    }

    return (ret);
}


/************************************************************************
**
**  Function    :   DBA_DelRecById
**
**  Description :   Delete the record (umex /execution / global exec fee)
**
**  Arguments   :   id              the id
**                  enObject        object enum
**                  sDynSt          dynamic struct enum
**                  sIdFldIndex     index of id field
**                  connectNo       the connection number
**                  msgStructPtr    pointer on a structure which will contain
**                                  received messages informations.
**
**  Return      :   RET_SUCCEED                 if ok
**		            RET_MEM_ERR_ALLOC		    error in memory allocation
**
**  Creation    :   REF9764 - TEB - 040210
**
*************************************************************************/
STATIC RET_CODE DBA_DelRecById(ID_T id,
                               OBJECT_ENUM enObject,
                               DBA_DYNST_ENUM sDynSt,
                               int sIdFldIndex,
                               DbiConnection & dbiConn)
{
    RET_CODE retCode = RET_SUCCEED;
    DBA_DYNFLD_STP sRecord = ALLOC_DYNST(sDynSt);

    if (nullptr == sRecord)
    {
        retCode = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(retCode, 0, FILEINFO, retCode);
    }
    else
    {
        SET_ID(sRecord, sIdFldIndex, id);

        retCode = DBA_Delete2(enObject,
                              UNUSED,
                              sDynSt,
                              sRecord,
                              DBA_SET_CONN | DBA_NO_CLOSE,
                              dbiConn);

        FREE_DYNST(sRecord, sDynSt);
    }

    return(retCode);
}


/************************************************************************
**
**  Function    :   DBA_PtfHasChanged()
**
**  Description :   tells if portfolio_id has changed between 2 ExtOpSt
**
**  Arguments   :
**
**
**  Return      :   TRUE if changed
**                  FALSE otherwise
**
**  Creation    : REF11159-EFE-050503
**
*************************************************************************/
FLAG_T DBA_PtfHasChanged( const DBA_DYNFLD_STP newExtOpSt, const DBA_DYNFLD_STP oldExtOpSt )
{
    return GET_ID(newExtOpSt, ExtOp_PtfId) != GET_ID(oldExtOpSt, ExtOp_PtfId) ? TRUE : FALSE;
}

/************************************************************************
**
**  Function    :   DBA_ExecutionHasChanged()
**
**  Description :   tells if ext_order_id or has changed between 2 ExtOpSt
**
**  Arguments   :
**
**
**  Return      :   TRUE if changed
**                  FALSE otherwise
**
**  Creation    : REF11159-EFE-050503
**
*************************************************************************/
FLAG_T DBA_ExecutionHasChanged( const DBA_DYNFLD_STP newExtOpSt, const DBA_DYNFLD_STP oldExtOpSt )
{
    return (0 != CMP_DYNFLD(newExtOpSt, oldExtOpSt, ExtOp_ExtOrderId,      ExtOp_ExtOrderId,      IdType) ||
            0 != CMP_DYNFLD(newExtOpSt, oldExtOpSt, ExtOp_ExecSetCriteria, ExtOp_ExecSetCriteria, InfoType))
            ? TRUE : FALSE;
}

/************************************************************************
**
**  Function    :   DBA_GetAllNotepadFronOp()
**
**  Description :   Get all notepad from an operation
**
**  Arguments   :   oldExtOpSt  : pointer on extOp from which get the notepad
**                  lstNotepadP : pointer on pointer on a list of notepad
**
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    : REF11159-EFE-050509
**
*************************************************************************/
RET_CODE DBA_GetAllNotepadFromOp(const DBA_DYNFLD_STP extOpSt, DBA_DYNFLD_STP * * aNotepadTab, int * rows)
{
    RET_CODE        ret      = RET_SUCCEED;
    DBA_DYNFLD_STP  sNotepad = ALLOC_DYNST(S_Notepad);

    if (sNotepad == NULL)
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 2, FILEINFO, "S_Notepad");
    }
    else
    {
        const ID_T notepadId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);
        SET_ID(sNotepad, S_Notepad_EntDictId, (DBA_GetDictEntityStSafe(Op))->entDictId);
        SET_ID(sNotepad, S_Notepad_ObjId, notepadId);

        ret = DBA_Select2(Notepad,
                          UNUSED,
                          S_Notepad,
                          sNotepad,
                          A_Notepad,
                          aNotepadTab,
                          UNUSED,
                          UNUSED,
                          rows,
                          NULL,
                          NULL);

        if ( ret != RET_SUCCEED)
        {
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "S_Notepad");
        }

        FREE_DYNST(sNotepad, S_Notepad);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_SetAllNotepadToNewOp ()
**
**  Description :   Set notepads to an operation
**
**  Arguments   :   ExtOpSt  : pointer on extOp to which set the notepad
**                  aNotepadTab  : pointer on pointer on a list of notepad
**                  Number of notepad to assign
**
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    : REF11159-EFE-050509
**
*************************************************************************/
RET_CODE DBA_SetAllNotepadToNewOp(const DBA_DYNFLD_STP extOpSt,
                                  DBA_DYNFLD_STP *     aNotepadTab,
                                  int                  nbNotepad,
                                  DbiConnection       &dbiConn)
{
    RET_CODE        ret     = RET_SUCCEED;

    const ID_T notepadId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);

    for (int i = 0; i < nbNotepad; i++ )
    {
        SET_ID(aNotepadTab[i], A_Notepad_ObjId,  notepadId );

        /*PMSTA-28772-NRAO-171017 - set notepad record entity_dict_id */
        SET_DICT(aNotepadTab[i], A_Notepad_EntDictId, (DBA_GetDictEntityStSafe(Op))->entDictId);

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        { /* Yes */

            ret  = DBA_AddElemToBlockModeSt( Insert,
                                            UNUSED,
                                            Notepad,
                                            A_Notepad,
                                            aNotepadTab[i],
                                            dbiConn);
        }
        else
        { /* No */
            ret = DBA_Insert2(Notepad, UNUSED, A_Notepad,
                              aNotepadTab[i], DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            if ( ret != RET_SUCCEED)
            {
                dbiConn.sendAllMsg();
                break;
            }
        }
    }

    return ret;
}

/*********************************************
**
**  Function    :   DBA_GetAllCommunicationFromOp()
**
**  Description :   Get all Communication from an operation
**
**  Arguments   :   oldExtOpSt  : pointer on extOp from which get the notepad
**                  lstNotepadP : pointer on pointer on a list of notepad
**
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    :   PMSTA09264-CHU-100211
**
*************************************************************************/
RET_CODE DBA_GetAllCommunicationFromOp(const DBA_DYNFLD_STP extOpSt, DBA_DYNFLD_STP * * aCommunicationTab, int * rows)
{
    RET_CODE        ret            = RET_SUCCEED;
    DBA_DYNFLD_STP  sCommunication = ALLOC_DYNST(S_Communication);

    if (sCommunication == NULL)
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 2, FILEINFO, "S_Communication");
    }
    else
    {
        const ID_T communicationId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);
        SET_ID(sCommunication, S_Communication_OpId, communicationId);

        ret = DBA_Select2(Communication,
                          UNUSED,
                          S_Communication,
                          sCommunication,
                          A_Communication,
                          aCommunicationTab,
                          UNUSED,
                          UNUSED,
                          rows,
                          NULL,
                          NULL);

        if ( ret != RET_SUCCEED)
        {
            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 2, FILEINFO, "S_Communication");
        }

        FREE_DYNST(sCommunication, S_Communication);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DBA_SetAllCommunicationToNewOp ()
**
**  Description :   Set communications to an operation
**
**  Arguments   :   ExtOpSt  : pointer on extOp to which set the notepad
**                  aCommunicationTab  : pointer on pointer on a list of Communication
**                  Number of Communication to assign
**
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    :   PMSTA09264-CHU-100211
**
*************************************************************************/
RET_CODE DBA_SetAllCommunicationToNewOp(const DBA_DYNFLD_STP extOpSt,
                                        DBA_DYNFLD_STP *     aCommunicationTab,
                                        int nbCommunication,
                                        DbiConnection &dbiConn)
{

    RET_CODE        ret     = RET_SUCCEED;

    const ID_T communicationId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);

    for (int i = 0; i < nbCommunication; i++ )
    {
        SET_ID(aCommunicationTab[i], A_Communication_OpId,  communicationId);

        /*PMSTA-28772-NRAO-171017 - set communication record entity_dict_id*/
        SET_DICT(aCommunicationTab[i], A_Communication_EntDictId, (DBA_GetDictEntityStSafe(Op))->entDictId);

        if (dbiConn.getConnStructPtr()->blockMode == TRUE)
        { /* Yes */

            ret  = DBA_AddElemToBlockModeSt( Insert,
                                            UNUSED,
                                            Communication,
                                            A_Communication,
                                            aCommunicationTab[i],
                                            dbiConn);
        }
        else
        { /* No */
            ret = DBA_Insert2(Communication, UNUSED, A_Communication,
                              aCommunicationTab[i], DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            if ( ret != RET_SUCCEED)
            {
                dbiConn.sendAllMsg();
                break;
            }
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DBA_CheckMatchingCode()
**
**  Description :  Compares a code with the operation code or source code
**         depending on the parameter matchingSrcCdFlg (application parameter MATCHING_SOURCE_CODE)
**
**  Arguments   :  matchingSrcCdFlg     Application parameter MATCHING_SOURCE_CODE
**                 code                 Code to compare with
**                 pos                  Pointer on extended position
**
**  Return      :  TRUE     if code matches operation code/source code
**                 FALSE    if no matching or error
**
**  Creation    :  DVP183 - 960903 - DED
**
**  Last modif. :  PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**
*************************************************************************/
int DBA_CheckMatchingCode(const FLAG_T          matchingSrcCdFlg,
                          const CODE_T          code,
                          const DBA_DYNFLD_STP  pos)
{
    switch (matchingSrcCdFlg)
    {
    case FALSE :                    /* check open_oper_code */

        /* Matched if both are null */
        if (code == NULL && IS_NULLFLD(pos, ExtPos_OpenOpCd) == true)
        {
            return(TRUE);
        }
        else if ((code == NULL && IS_NULLFLD(pos, ExtPos_OpenOpCd) != true) ||
                 (code != NULL && IS_NULLFLD(pos, ExtPos_OpenOpCd) == true))
        {
            return(FALSE);
        }
        else if (strcmp(GET_CODE(pos, ExtPos_OpenOpCd), code) != 0)
        {
            return(FALSE);
        }
        break;

    case TRUE :                     /* check source code */

        /* Matched if both are null */
        if (code == NULL && IS_NULLFLD(pos, ExtPos_SrcCd) == true)
        {
            return(TRUE);
        }
        else if ((code == NULL && IS_NULLFLD(pos, ExtPos_SrcCd) != true) ||
                 (code != NULL && IS_NULLFLD(pos, ExtPos_SrcCd) == true))
        {
            return(FALSE);
        }
        else if (strcmp(GET_CODE(pos, ExtPos_SrcCd), code) != 0)
        {
            return(FALSE);
        }
        break;
    }

    return(TRUE);
}

/************************************************************************
**
**  Function    :  DBA_IsRejectedOrder()
**
**  Description :  Check if order Inclusion enum is part of ORDER_EXCLUSION values
**
**  Arguments   :  extOpSt  Pointer on ext_operation
**
**  Return      :  TRUE     if found amongst sys param values
**                 FALSE    if not...
**
**  Creation    :  PMSTA-25573 - CHU - 170410
**
*************************************************************************/
FLAG_T DBA_IsRejectedOrder(DBA_DYNFLD_STP extOpSt)
{
    if (extOpSt == nullptr || extOpSt->dynStEnum != ExtOp)
        return(FALSE);

    if (IS_NULLFLD(extOpSt, ExtOp_OrderInclusionEn) == false && /* PMSTA-30894 - CHU - Friday 180713  */
        static_cast<ORDERINCLUSION_ENUM> (GET_ENUM(extOpSt, ExtOp_OrderInclusionEn)) == OrderInclusionEn_Rejected)
    {
        return (TRUE);
    }

    /* else */
    /* Check if ExtOp_OrderInclusionEn matches a number in the string */
    INFO_T applOrderExclusionStr;   /* String with status rejected */ /* PMSTA-27506 - CHU - 170613 */
    applOrderExclusionStr[0] = END_OF_STRING;
    (void)GEN_GetApplInfo(ApplOrderExclusionEn, applOrderExclusionStr); /* PMSTA-27506 - CHU - 170613 : GEN_APPLINFO_ENUM was wrong */
    return DBA_IntExistInString(static_cast<int>(GET_ENUM(extOpSt, ExtOp_OrderInclusionEn)), applOrderExclusionStr);

}

/*****************************************************************************
**
**  Function    :   DBA_SelectAllNotepad()
**
**  Description :   Select all notepad from a given op/extop entity
**
**  Arguments   :   extOpSt       Pointer on ext operation
**                  aNotepadTab   Array to retun notepad details
**                  rows          Holds the count of Notepad records retrieved
**                  entity        object refernce for notepad
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    : PMSTA-28772-NRAO-171017
**
*******************************************************************************/
RET_CODE DBA_SelectAllNotepad(const DBA_DYNFLD_STP extOpSt,
                              DBA_DYNFLD_STP **aNotepadTab,
                              int *rows,
                              OBJECT_ENUM entity,
                              DbiConnection &dbiConn)
{
    RET_CODE        ret      = RET_SUCCEED;
    DBA_DYNFLD_STP  sNotepad = ALLOC_DYNST(S_Notepad);

    if (sNotepad == NULL)
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 2, FILEINFO, "S_Notepad");
    }

    if (ret == RET_SUCCEED)
    {
        const ID_T objId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);
        SET_ID(sNotepad, S_Notepad_ObjId, objId);
        SET_DICT(sNotepad, S_Notepad_EntDictId, (DBA_GetDictEntityStSafe(entity))->entDictId);

        ret = DBA_Select2(Notepad,
                            UNUSED,
                            S_Notepad,
                            sNotepad,
                            A_Notepad,
                            aNotepadTab,
                            DBA_SET_CONN | DBA_NO_CLOSE,
                            UNUSED,
                            rows,
                            dbiConn,
                            NULL);

        if (ret != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_NODATA;
            MSG_SendMesg(ret, 2, FILEINFO, "S_Notepad");
        }
    }

    FREE_DYNST(sNotepad, S_Notepad);
    return ret;
}

/**********************************************************************************
**
**  Function    :   DBA_SelectAllCommunication()
**
**  Description :   Select all Communication from Op/ExtOp
**
**  Arguments   :   extOpSt             Pointer on ext operation
**                  aCommunicationTab   Array to retun communication details
**                  rows                Holds the count of comm records retrieved
**                  entity              object refernce for communication
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    :   PMSTA-28772-NRAO-171017
**
************************************************************************************/
RET_CODE DBA_SelectAllCommunication(const DBA_DYNFLD_STP extOpSt,
                                    DBA_DYNFLD_STP **aCommunicationTab,
                                    int *rows,
                                    OBJECT_ENUM entity,
                                    DbiConnection &dbiConn)
{
    RET_CODE        ret            = RET_SUCCEED;
    DBA_DYNFLD_STP  sCommunication = ALLOC_DYNST(S_Communication);

    if (sCommunication == NULL)
    { /* Error */
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 2, FILEINFO, "S_Communication");
    }

    if (ret == RET_SUCCEED)
    {
        const ID_T operationId = OPE_GetOpIdFromExtOpPriorityOperation(extOpSt);
        SET_ID(sCommunication, S_Communication_OpId, operationId);
        SET_DICT(sCommunication, S_Communication_EntDictId, (DBA_GetDictEntityStSafe(entity))->entDictId);

        ret = DBA_Select2(Communication,
                        UNUSED,
                        S_Communication,
                        sCommunication,
                        A_Communication,
                        aCommunicationTab,
                        DBA_SET_CONN | DBA_NO_CLOSE,
                        UNUSED,
                        rows,
                        dbiConn,
                        NULL);

        if (ret != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_NODATA;
            MSG_SendMesg(ret, 2, FILEINFO, "S_Communication");
        }
    }

    FREE_DYNST(sCommunication, S_Communication);
    return ret;
}

/*
    SLEEVE MANAGEMENT - PMSTA-40207 - 01062020 - LIK
*/

RET_CODE SleeveProcessor::createRevDelSleeveOp(SleeveHead& head) {

    RET_CODE ret = RET_SUCCEED;
    if (!head.sleeveConnHelper.isValidAndInit())
    {
        MSG_SendMesg(FILEINFO, "Sleeve CA : Invalid Conn helper");
        return RET_GEN_ERR_NOACTION;
    }

    MemoryPool mp;
    DBA_DYNFLD_STP getArg = mp.allocDynst(FILEINFO, Get_Arg);
    if (SleeveOpType::Normal == head.type)
    {
        const DBA_DYNST_ENUM * outputStLst[] = { &A_Pos, &A_Ptf, &A_Instr };
        int                    outputMatch[] = { A_Pos, A_Ptf, A_Instr };
        int                    outputBlkNb = sizeof(outputMatch) / sizeof(outputMatch[0]);
        DBA_DYNFLD_STP *       data[] = {  NULLDYNSTPTR, NULLDYNSTPTR,NULLDYNSTPTR };
        int                    rows[] = { 0, 0, 0};

        
        SET_ID(getArg, Get_Arg_PtfId, head.m_ptfId);
        SET_ID(getArg, Get_Arg_InstrId, head.m_adjInstrId); /* need to split qty based on adj instr. if its null in extop, adjInstr will hold operInstrId val*/
        SET_ID(getArg, Get_Arg_Id, head.m_operInstrId); /* we have to create operation for this instr. need odd lot qty*/
        SET_DATETIME(getArg, Get_Arg_DateTime, head.m_operDate);


        ret = head.sleeveConnHelper.dbaMultiSelect(Fus,
            UNUSED,
            getArg,
            outputStLst,
            data,
            rows
        );

        if (RET_SUCCEED != ret)
        {
            MSG_SendMesg(FILEINFO, "creatRevDelSleeveOp : Database fetch failed!");
            DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
            return ret;
        }

        if (rows[IDX_S_POS] <= 0 || rows[IDX_S_PTF] <= 0 || rows[IDX_S_INSTR] <= 0)
        {
            DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
            MSG_SendMesg(FILEINFO, "creatRevDelSleeveOp : all rows 0");
            return RET_GEN_ERR_NOACTION;
        }

        posTab = &data[IDX_S_POS][0];
        posNbr = rows[IDX_S_POS];

        ptfTab = &data[IDX_S_PTF][0];
        ptfNbr = rows[IDX_S_PTF];

        instrTab = &data[IDX_S_INSTR][0];
        instrNbr = rows[IDX_S_INSTR];

        ret = processNormal(head);

        DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
    }
    else if (SleeveOpType::Reveresal == head.type || SleeveOpType::Deleted == head.type)
    {

        if (SleeveOpType::Reveresal == head.type)
        {
            SET_CODE(getArg, Get_Arg_Cd, (GET_CODE(head.m_extOrder, ExtOp_RevOpCd)));
        }
        else
        {
            SET_CODE(getArg, Get_Arg_Cd, (GET_CODE(head.m_extOrder, ExtOp_Cd)));
        }

        ret = head.sleeveConnHelper.dbaSelect(Fus, UNUSED, getArg, A_Op, &opTab, &opNbr);
        if (RET_SUCCEED != ret)
        {
            MSG_SendMesg(FILEINFO, "creatRevDelSleeveOp: db select in rev or del failed");
            return ret;
        }
        if (opNbr <= 0)
        {
            MSG_SendMesg(FILEINFO, "creatRevDelSleeveOp: op tab 0 elements");
            return ret;
        }
       
        if (SleeveOpType::Reveresal == head.type)
        {
            ret = head.createChildRevOrders(*this);
        }
        else
        {
            ret = head.deleteChildOperations(*this);
        }
        DBA_FreeDynStTab(opTab, opNbr, A_Op);
    }
    return ret;
}
/************************************************************************
*   Function         :   SleeveContext::process()
*   Description     :   create sleeve orders if needed.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
RET_CODE SleeveProcessor::processNormal(SleeveHead &sleeveHead)
{
    RET_CODE ret = RET_SUCCEED;
    int startPtfIndex = 0;
    int index = 0;

    if (posNbr > 0) 
    {
        ID_T posPtfId = GET_ID(posTab[0], A_Pos_PtfId);
        PosIndex posIndex;
        for (index = 0; index < posNbr; ++index)
        {
            if (0 != CMP_ID(posPtfId, GET_ID(posTab[index], A_Pos_PtfId)))
            {
                posIndex.m_ptfIndex = std::make_pair(startPtfIndex, index - 1);
                posIndex.m_ptfId = posPtfId;
                m_posVector.push_back(posIndex);

                startPtfIndex = index;
                posPtfId = GET_ID(posTab[index], A_Pos_PtfId);
                posIndex.m_ptfId = ZERO_ID;
                continue;
            }
        }

        /* last item */
        posIndex.m_ptfIndex = std::make_pair(startPtfIndex, index - 1);
        posIndex.m_ptfId = posPtfId;
        m_posVector.push_back(posIndex);
    }
    else {
        MSG_SendMesg(FILEINFO, "Position array empty. cannot split operation");
        return RET_GEN_ERR_NOACTION;
    }


    if (sleeveHead.type == SleeveOpType::Normal && posNbr > 0) /* normal  CA, with some position. if len(position arr) = 0, all to head, no split*/
    {
        sleeveHead.build(*this);
        if (sleeveHead.m_total > 0 && sleeveHead.sleeves.size() > 1)
        {
            ret = sleeveHead.createChildOrders(*this);
        }
        else {
            MSG_SendMesg(FILEINFO, "Sleeve size is 1. ie only parent, cannot split operation");
            ret = RET_GEN_ERR_NOACTION;
        }
    }
    else
    {
        return RET_GEN_ERR_NOACTION;
    }
    return ret;
}


/************************************************************************
*   Function         :   SleeveContext::getPortfolio
*   Description     :   get ptf dynstp from tab for given id
*   Arguments      :   ptf id
*   Return            :   None
*************************************************************************/
DBA_DYNFLD_STP SleeveProcessor::getPortfolio(ID_T ptfId)
{
    for (int i = 0; i < ptfNbr; ++i)
    {
        if (0 == CMP_ID(ptfId, GET_ID(ptfTab[i], A_Ptf_Id)))
        {
            return ptfTab[i];
        }
    }
    return nullptr;
}

/************************************************************************
*   Function         :   SleeveContext::getOddLotQty
*   Description     :   get lot qty for instrument
*   Arguments      :   instr id
*   Return            :   None
*************************************************************************/
NUMBER_T SleeveProcessor::getOddLotQty(ID_T instrId)
{
    for (int i = 0; i < instrNbr; ++i)
    {
        if (0 == CMP_ID(instrId, GET_ID(instrTab[i], A_Instr_Id)))
        {
            if (IS_NULLFLD(instrTab[i], A_Instr_OddLotQty))
                return 1.0;
            return (GET_NUMBER(instrTab[i], A_Instr_OddLotQty));
        }
    }
    return 1.0;
}

/************************************************************************
*   Function         :   SleeveHead::SleeveHead
*   Description     :   constructor
*   Arguments      :   ext_order dynstp
*   Return            :   None
*************************************************************************/
SleeveHead::SleeveHead(DBA_DYNFLD_STP extOrder) :m_extOrder(extOrder)
{
    init();
}
void SleeveHead::setExtOrder(DBA_DYNFLD_STP extOrder)
{
    m_extOrder = extOrder;
    init();
}
/************************************************************************
*   Function         :   SleeveHead::setGroupExtOrder
*   Description     :   fo hier grouping
*   Arguments      :   ext_order dynstp
*   Return            :   None
*************************************************************************/
void SleeveHead::setGroupExtOrder(DBA_DYNFLD_STP extOrder)
{
    isDirty = false;
    hierGroup = true;
    m_extOrder = extOrder;
    m_extQty = GET_NUMBER(m_extOrder, ExtOp_Qty);
    m_operDate = GET_DATETIME(m_extOrder, ExtOp_OpDate);

    if (!IS_NULLFLD(m_extOrder, ExtOp_RevOpCd) && PosRevNat_Reverse == GET_ENUM(m_extOrder, ExtOp_RevOpNatEn) && IS_NULLFLD(m_extOrder, ExtOp_OpId))
    {
        type = SleeveOpType::Reveresal;
    }
    else if ((CMP_NUMBER(m_extQty, ZERO_NUMBER) != 0) && IS_NULLFLD(m_extOrder, ExtOp_OpId) &&
        static_cast<OPFUSION_ENUM>(GET_ENUM(m_extOrder, ExtOp_FusionEn)) == OPFUSION_ENUM::OpFusion_Untreated)
    {
        type = SleeveOpType::Normal;
    }
}

/************************************************************************
*   Function         :   SleeveHead::createGroupChildExtOrder
*   Description     :   fo hier grouping - create child
*   Arguments      :   ext_order dynstp
*   Return            :   None
*************************************************************************/
RET_CODE SleeveHead::createGroupChildExtOrder()
{
    RET_CODE ret = RET_SUCCEED;
    if (SleeveOpType::Normal == type)
    {
        /*
            1. its a block order - criteria & seq.
            ext_order_id will have actual order id. -> get all child ext_order.
            using this ext_order ids and criteria, get all execution. (not ac)
        */

        if (!sleeveConnHelper.isValidAndInit())
        {
            MSG_SendMesg(FILEINFO, "createGroupChildExtOrder : Invalid Conn helper");
            return RET_GEN_ERR_NOACTION;
        }
        MemoryPool mp;
        DBA_DYNFLD_STP getArg = mp.allocDynst(FILEINFO, S_Execution);
        SET_ID(getArg, S_Execution_ExtOrderId, (GET_ID(m_extOrder, ExtOp_ExtOrderId)));
        SET_CODE(getArg, S_Execution_ExecutionSetCriteria, (GET_CODE(m_extOrder, ExtOp_ExecSetCriteria)));

        const DBA_DYNST_ENUM *   outputStLst[] = { &ExtOp, &A_Execution }; /* child order (sort-qty desc), accounted execution, not accounted but soon, instr */
        DBA_DYNFLD_STP *            data[] = { NULL, NULL };
        int                                    rows[] = { 0, 0 };
        const size_t                       outputBlkNb = sizeof(outputStLst) / sizeof(outputStLst[0]);
        const int  ORDER = 0, EXEC = 1;

        if ((ret = sleeveConnHelper.dbaMultiSelect(ExecutionEnt, UNUSED, getArg, outputStLst, data, rows)) != RET_SUCCEED)
        {
            MSG_SendMesg(FILEINFO, "createGroupChildExtOrder : DBA_MultiSelect for hier group failed");
            DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
            return ret;
        }

        int fldNbr = GET_FLD_NBR(ExtOp) ;
        FLAG_T* scptFlagTab = (FLAG_T*)mp.calloc(FILEINFO, fldNbr, sizeof(FLAG_T));

        for (int execIdx = 0; execIdx < rows[EXEC]; ++execIdx)
        {
            if (isDirty)
                break;

            for (int orderIdx = 0; orderIdx < rows[ORDER]; ++orderIdx)
            {
                if (CMP_ID((GET_ID(data[EXEC][execIdx], A_Execution_ExtOrderId)),
                    (GET_ID(data[ORDER][orderIdx], ExtOp_DbId))) == 0)
                {
                    DBA_DYNFLD_STP extOrder = mp.allocDynst(FILEINFO, ExtOp);
                    ret = OPE_ExecutionToExtOp2(data[EXEC][execIdx], extOrder, data[ORDER][orderIdx]);
                    if (RET_SUCCEED != ret)
                    {
                        MSG_SendMesg(FILEINFO, "createGroupChildExtOrder : OPE_ExecutionToExtOp2 failed");
                        isDirty = true;
                    }
                    else
                    {
                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_StatusEn, m_extOrder, ExtOp, ExtOp_StatusEn);
                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_HierOperationCd, m_extOrder, ExtOp, ExtOp_Cd);
                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_ExecutedFlg, m_extOrder, ExtOp, ExtOp_ExecutedFlg);
                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_PaymentStatusEn, m_extOrder, ExtOp, ExtOp_PaymentStatusEn);
                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_SettleStatusEn, m_extOrder, ExtOp, ExtOp_SettleStatusEn);
                        SET_NULL_CODE(extOrder, ExtOp_Cd);
                        SET_NULL_ID(extOrder, ExtOp_ParentHierExtOpId);
                        SET_ENUM(extOrder, ExtOp_HierOperNatEn,HierOpNatEn::HierOpNat_ChildOrder);
                        for (int fld = 0; fld < fldNbr; ++fld)
                        {
                            scptFlagTab[fld] = (IS_NULLFLD(extOrder, fld)? FALSE:TRUE);
                        }
                        if (0 != SCPT_ComputeDV(EOp, scptFlagTab, extOrder, TRUE, TRUE, NULL))
                        {
                            MSG_SendMesg(FILEINFO, "setValues: default value failed.");
                        }

                        COPY_DYNFLD(extOrder, ExtOp, ExtOp_SequenceNo, m_extOrder, ExtOp, ExtOp_SequenceNo);

                        m_newExtOrder.push_back(extOrder);
                        mp.remove(extOrder);
                    }
                    break;
                }
            }
        }

        if (RET_SUCCEED == ret)
        {
            for (int fld = 0; fld < fldNbr; ++fld)
            {
                scptFlagTab[fld] = FALSE;
            }
            scptFlagTab[ExtOp_Cd] = TRUE;
            SET_NUMBER(m_extOrder, ExtOp_Qty, ZERO_NUMBER);
            if (0 != SCPT_ComputeDV(EOp, scptFlagTab, m_extOrder, FALSE, TRUE, NULL))
            {
                MSG_SendMesg(FILEINFO, "setValues: default value failed. Parent");
            }
        }
    
    }
   
    return ret;
}

void SleeveHead::init()
{
    hierGroup = false; 
    m_operDate = GET_DATETIME(m_extOrder, ExtOp_OpDate);
    m_ptfId = GET_ID(m_extOrder, ExtOp_PtfId);
    m_extQty = GET_NUMBER(m_extOrder, ExtOp_Qty);
    m_total = 0; /* check this before division*/
    isDirty = false;
    m_extAdjQty = GET_NUMBER(m_extOrder, ExtOp_AdjQty);

     if (!IS_NULLFLD(m_extOrder, ExtOp_RevOpCd) && PosRevNat_Reverse == GET_ENUM(m_extOrder, ExtOp_RevOpNatEn) && IS_NULLFLD(m_extOrder, ExtOp_OpId))
    {
        type = SleeveOpType::Reveresal;
    }
    else if ( (CMP_NUMBER(m_extQty, ZERO_NUMBER) != 0 || CMP_NUMBER(m_extAdjQty, ZERO_NUMBER) != 0) && IS_NULLFLD(m_extOrder, ExtOp_OpId) &&
        static_cast<OPFUSION_ENUM>(GET_ENUM(m_extOrder, ExtOp_FusionEn)) == OPFUSION_ENUM::OpFusion_Untreated)
    {
        type = SleeveOpType::Normal;
        m_operInstrId = GET_ID(m_extOrder, ExtOp_InstrId);
        if (!IS_NULLFLD(m_extOrder, ExtOp_AdjNatEn) && OpAdjustNat_None != GET_ENUM(m_extOrder, ExtOp_AdjNatEn) && !IS_NULLFLD(m_extOrder, ExtOp_AdjInstrId))
        {
            if (OpAdjustNat_Pl == GET_ENUM(m_extOrder, ExtOp_AdjNatEn) && CMP_NUMBER(m_extQty, ZERO_NUMBER) == -1)
            {
                /* Exchange adj with nature pl. here we have to use ExtOp_Instr id's quantity for deriving split percentage*
                 * So assign ExtOp_InstrId value to m_adjInstrId. its used only in db fetch. */
                m_adjInstrId = GET_ID(m_extOrder, ExtOp_InstrId);
                m_operInstrId = GET_ID(m_extOrder, ExtOp_AdjInstrId);

            }
            else
            {
                m_adjInstrId = GET_ID(m_extOrder, ExtOp_AdjInstrId);
            }
        }
        else
        {
            m_adjInstrId = m_operInstrId;
        }
    }
}


/************************************************************************
*   Function         :   SleeveHead::createChildOrders
*   Description     :   create child order for reversal operation based on the parent order.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
RET_CODE SleeveHead::deleteChildOperations(SleeveProcessor& ctx)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;
    sleeveConnHelper.beginTransaction();
    for (int idx = 0; idx < ctx.opNbr; ++idx)
    {
      
        /* delete it from db. */
        DBA_DYNFLD_STP opShort = mp.allocDynst(FILEINFO, S_Op);

        COPY_DYNFLD(opShort, S_Op, S_Op_Id, ctx.opTab[idx], A_Op, A_Op_Id);
        COPY_DYNFLD(opShort, S_Op, S_Op_Cd, ctx.opTab[idx], A_Op, A_Op_Cd);
        COPY_DYNFLD(opShort, S_Op, S_Op_SequenceNo, ctx.opTab[idx], A_Op, A_Op_SequenceNo);
        COPY_DYNFLD(opShort, S_Op, S_Op_StatEn, ctx.opTab[idx], A_Op, A_Op_StatEn);
        COPY_DYNFLD(opShort, S_Op, S_Op_NatEn, ctx.opTab[idx], A_Op, A_Op_NatEn);

        ret = sleeveConnHelper.dbaDelete(Op, UNUSED, opShort);
        if (ret != RET_SUCCEED)
        {
            sleeveConnHelper.endTransaction(FALSE);
            MSG_SendMesg(FILEINFO, "deleteChildOperations : DB delete failed.");
            return ret;
        }
        
    }
    sleeveConnHelper.endTransaction(TRUE);
    return ret;
}


/************************************************************************
*   Function         :   SleeveHead::createChildOrders
*   Description     :   create child order for reversal operation based on the parent order.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
RET_CODE SleeveHead::createChildRevOrders(SleeveProcessor& ctx)
{
    MemoryPool mp;

    /* for each child order, create a new ext_order for reversal */
    /* def values falg init*/
    FLAG_T			*scptFlagTab = NULL;

    if ((scptFlagTab = (FLAG_T*)
        CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
    {
        MSG_SendMesg(FILEINFO, "setValues: scptFlagTab allocation failed. NULL.");
        isDirty = true;
        return RET_GEN_ERR_NOACTION;
    }
    else
    {
        /* force set everything to true*/
        for (int i = 0; i < GET_FLD_NBR(ExtOp); ++i)
        {
            scptFlagTab[i] = FALSE;
        }

        scptFlagTab[ExtOp_RevOpCd] = TRUE;
        scptFlagTab[ExtOp_RevOpNatEn] = TRUE;
        scptFlagTab[ExtOp_OpSplitRuleEn] = TRUE;
        scptFlagTab[ExtOp_OpDate] = TRUE;
        scptFlagTab[ExtOp_AcctDate] = TRUE;
        scptFlagTab[ExtOp_ValueDate] = TRUE;
        scptFlagTab[ExtOp_FusionEn] = TRUE;
        scptFlagTab[ExtOp_Price] = TRUE;
        scptFlagTab[ExtOp_Quote] = TRUE;
        scptFlagTab[ExtOp_SplitParentOperId] = TRUE;
        scptFlagTab[ExtOp_SplitParOpCd] = TRUE;

    }
    /* flag init end */


    for (int idx = 0; idx < ctx.opNbr; ++idx)
    {
            DBA_DYNFLD_STP locExtOrder = mp.allocDynst(FILEINFO, ExtOp);
            DBA_SetDfltEntityFld(EOp, ExtOp, locExtOrder);

            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_PtfId, ctx.opTab[idx], A_Op, A_Op_PtfId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_NatureEn, ctx.opTab[idx], A_Op, A_Op_NatEn);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_InstrId, ctx.opTab[idx], A_Op, A_Op_InstrId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_StatusEn, m_extOrder, ExtOp, ExtOp_StatusEn);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_OpDate, m_extOrder, ExtOp, ExtOp_OpDate);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_AcctDate, m_extOrder, ExtOp, ExtOp_AcctDate);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_ValueDate, m_extOrder, ExtOp, ExtOp_ValueDate);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_InstrCurrId, m_extOrder, ExtOp, ExtOp_InstrCurrId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_OpCurrId, m_extOrder, ExtOp, ExtOp_OpCurrId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_Price, m_extOrder, ExtOp, ExtOp_Price);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_Qty, m_extOrder, ExtOp, ExtOp_Quote);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_RevOpNatEn, m_extOrder, ExtOp, ExtOp_RevOpNatEn);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_RevOpCd, ctx.opTab[idx], A_Op, A_Op_Cd);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_SplitParentOperId, m_extOrder, ExtOp, ExtOp_DbId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_SplitParOpCd, m_extOrder, ExtOp, ExtOp_Cd);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_AdjInstrId, m_extOrder, ExtOp, ExtOp_AdjInstrId);
            COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_AdjNatEn, m_extOrder, ExtOp, ExtOp_AdjNatEn);
            SET_ENUM(locExtOrder, ExtOp_FusionEn, OPFUSION_ENUM::OpFusion_Untreated);


            SET_ENUM(locExtOrder, ExtOp_OpSplitRuleEn, OpOpSplitRuleEn::No);

            if (0 != SCPT_ComputeDV(EOp, scptFlagTab, locExtOrder, TRUE, FALSE, NULL))
            {
                MSG_SendMesg(FILEINFO, "setValues: default value failed.");
                isDirty = true;
                FREE(scptFlagTab);
                return RET_GEN_ERR_NOACTION;
            }

            m_newExtOrder.push_back(locExtOrder);
            mp.remove(locExtOrder); /* to be freed explicitly */
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function         :   SleeveHead::createChildOrders
*   Description     :   create child order for the parent order.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
RET_CODE SleeveHead::createChildOrders(SleeveProcessor& ctx)
{
    RET_CODE ret = RET_SUCCEED;
    /*
        sleeves will have all ptf under the parent. we will split parent ext_order based on existing
        position.
        sleeves will be sorted in desc order of curr pos. bcoz priority is for sleeve with hieghest position.
    */
    MemoryPool mp;

    NUMBER_T roundUnit = ctx.getOddLotQty(m_operInstrId);
    NUMBER_T availableQty = m_extQty;
    NUMBER_T availableAdjQty = m_extAdjQty;

    NUMBER_T adjMultplier = 1;
    NUMBER_T multiplier = 1;
    if (CMP_NUMBER(availableQty,ZERO_NUMBER)  == -1)
    {
        multiplier = -1;
        availableQty *= multiplier;
        m_extQty *= multiplier;
    }
    if (CMP_NUMBER(availableAdjQty, ZERO_NUMBER) == -1)
    {
        adjMultplier = -1;
        availableAdjQty *= adjMultplier;
        m_extAdjQty *= adjMultplier;
    }


    if (-1 == CMP_NUMBER(m_extQty, roundUnit) && -1 == CMP_NUMBER(m_extAdjQty, roundUnit))
    {
        MSG_SendMesg(FILEINFO, "createChildOrders: parent order Qty less than odd lot qty. Can't create child orders");
        isDirty = true;
        return RET_GEN_ERR_NOACTION;
    }

    /* Fees and taxes - do not change array order.*/
    FIELD_IDX_T bpFlds[]    =      { ExtOp_Bp1Amt, ExtOp_Bp2Amt , ExtOp_Bp3Amt , ExtOp_Bp4Amt , ExtOp_Bp5Amt , ExtOp_Bp6Amt , ExtOp_Bp7Amt, ExtOp_Bp8Amt , ExtOp_Bp9Amt ,ExtOp_Bp10Amt };
    FIELD_IDX_T bpFldsCurr[] =    { ExtOp_Bp1CurrId, ExtOp_Bp2CurrId , ExtOp_Bp3CurrId , ExtOp_Bp4CurrId , ExtOp_Bp5CurrId , ExtOp_Bp6CurrId , ExtOp_Bp7CurrId, ExtOp_Bp8CurrId , ExtOp_Bp9CurrId ,ExtOp_Bp10CurrId };
    FIELD_IDX_T bpFldsTpId[] =   { ExtOp_Bp1TpId, ExtOp_Bp2TpId , ExtOp_Bp3TpId , ExtOp_Bp4TpId , ExtOp_Bp5TpId , ExtOp_Bp6TpId , ExtOp_Bp7TpId, ExtOp_Bp8TpId , ExtOp_Bp9TpId ,ExtOp_Bp10TpId };
    int                         bpFldCount = sizeof(bpFlds) / sizeof(bpFlds[0]);
    
    /* pair - bp field and remaining amount to split. total will be always in m_extOrder*/
    std::vector<std::pair<int, AMOUNT_T>> bpList;
    std::vector<ID_T> currList;
    for (int bpIndex = 0; bpIndex < bpFldCount; ++bpIndex) 
    {
        if (CMP_NUMBER(GET_AMOUNT(m_extOrder, (bpFlds[bpIndex])), ZERO_NUMBER) == 1)
        {
            bpList.push_back(std::make_pair(bpIndex, GET_AMOUNT(m_extOrder, (bpFlds[bpIndex]))));
        }
    }


    FIELD_IDX_T fields[] = { ExtOp_NatureEn , ExtOp_PriceCalcRuleEn , ExtOp_Price , ExtOp_Quote , ExtOp_OpenOpCd , ExtOp_InstrId , ExtOp_StatusEn , ExtOp_OpDate
                           , ExtOp_AcctDate , ExtOp_ValueDate , ExtOp_InstrCurrId , ExtOp_OpCurrId , ExtOp_AdjInstrId , ExtOp_AdjNatEn , ExtOp_OrderType, ExtOp_DepoId, ExtOp_AdjDepoId };

    int                         fldCount = sizeof(fields) / sizeof(fields[0]);

    /* def values falg init*/
    FLAG_T			*scptFlagTab = NULL;

    if ((scptFlagTab = (FLAG_T*)
        CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
    {
        MSG_SendMesg(FILEINFO, "setValues: scptFlagTab allocation failed. NULL.");
        isDirty = true;
        return RET_GEN_ERR_NOACTION;
    }
    else
    {

        /* force set everything to true*/
        for ( int i = 0; i < GET_FLD_NBR(ExtOp); ++i)
        {
            scptFlagTab[i] = FALSE;
        }
        scptFlagTab[ExtOp_Qty] = TRUE;
        scptFlagTab[ExtOp_OpSplitRuleEn] = TRUE;

        for (int fldIndex = 0; fldIndex < fldCount; ++fldIndex)
        {
            scptFlagTab[fields[fldIndex]] = TRUE;
        }
        for (int fldIndex = 0; fldIndex < bpFldCount; ++fldIndex)
        {
            scptFlagTab[bpFlds[fldIndex]] = TRUE;
            scptFlagTab[bpFldsCurr[fldIndex]] = TRUE;
            scptFlagTab[bpFldsTpId[fldIndex]] = TRUE;
        }
    }
    /* flag init end */

    for (auto iter = sleeves.begin(); iter != sleeves.end(); ++iter)
    {
        if (CMP_NUMBER(availableQty, ZERO_NUMBER) == 0 && CMP_NUMBER(availableAdjQty, ZERO_NUMBER) == 0)
        {
            /* nothing left to allocate*/
            break;
        }
        NUMBER_T share = (iter->m_currentPos / m_total);
        NUMBER_T locQty = share * m_extQty;
        NUMBER_T locAdjQty = share * m_extAdjQty;

        if (locQty <= 0 && locAdjQty <= 0) /*^_^*/
        {
            continue;
        }

        NUMBER_T roundedQty = 0;
        NUMBER_T roundedAdjQty = 0;

        if (-1 == CMP_NUMBER(availableQty, locQty))
        {
            roundedQty = availableQty;

            /* this availableQtyis less than locQty and is already proper. no need to round off. *
             * also, the last one get least qty. (its alreary sorted)
             * Total will be already proper value ,bcoz its coming from B.O
             * subtracting multiples of roundUnit from total will result in another
             * multiple of roundUnit. Right?
             */
        }
        else
        {
            if (-1 == CMP_NUMBER(locQty, roundUnit))
            {
                roundedQty = TLS_Round(locQty, roundUnit, RndRule_Up);
            }
            else
            {
                roundedQty = TLS_Round(locQty, roundUnit, RndRule_Nearest);
            }
        }

        availableQty -= roundedQty;
        if (CMP_NUMBER(availableQty, ZERO_NUMBER) == -1)
        {
            availableQty = ZERO_NUMBER;
        }


        if (-1 == CMP_NUMBER(availableAdjQty, locAdjQty))
        {
            roundedAdjQty = availableAdjQty;

            /* this availableQtyis less than locQty and is already proper. no need to round off. *
             * also, the last one get least qty. (its alreary sorted)
             * Total will be already proper value ,bcoz its coming from B.O
             * subtracting multiples of roundUnit from total will result in another
             * multiple of roundUnit. Right?
             */
        }
        else
        {
            if (-1 == CMP_NUMBER(locAdjQty, roundUnit))
            {
                roundedAdjQty = TLS_Round(locAdjQty, roundUnit, RndRule_Up);
            }
            else
            {
                roundedAdjQty = TLS_Round(locAdjQty, roundUnit, RndRule_Nearest);
            }
        }

        availableAdjQty -= roundedAdjQty;
        if (CMP_NUMBER(availableAdjQty, ZERO_NUMBER) == -1)
        {
            availableAdjQty = ZERO_NUMBER;
        }

      

        DBA_DYNFLD_STP locExtOrder = mp.allocDynst(FILEINFO, ExtOp);

        DBA_SetDfltEntityFld(EOp, ExtOp, locExtOrder);

        /* Fees and tax calculation*/

        for (auto bpPairIter = bpList.begin(); bpPairIter != bpList.end(); ++bpPairIter)
        {
            AMOUNT_T tempAmt = (roundedQty * (GET_AMOUNT(m_extOrder, bpFlds[(bpPairIter->first)]) / m_extQty) );
            tempAmt = CAST_AMOUNT( tempAmt, (GET_ID(m_extOrder, (bpFldsCurr[bpPairIter->first]))) );
            
            if (CMP_NUMBER(bpPairIter->second, tempAmt) >= 0)
            {
                SET_AMOUNT(locExtOrder, (bpFlds[bpPairIter->first]), tempAmt);
                SET_ID(locExtOrder, (bpFldsCurr[bpPairIter->first]), (GET_ID(m_extOrder, (bpFldsCurr[bpPairIter->first]))));
                SET_ID(locExtOrder, (bpFldsTpId[bpPairIter->first]), (GET_ID(m_extOrder, (bpFldsTpId[bpPairIter->first]))));

                bpPairIter->second -= tempAmt;
            }
            else if (CMP_NUMBER(bpPairIter->second, ZERO_NUMBER) >= 0)
            {
                tempAmt = bpPairIter->second;

                SET_AMOUNT(locExtOrder, (bpFlds[bpPairIter->first]), tempAmt);
                SET_ID(locExtOrder, (bpFldsCurr[bpPairIter->first]), (GET_ID(m_extOrder, (bpFldsCurr[bpPairIter->first]))));
                SET_ID(locExtOrder, (bpFldsTpId[bpPairIter->first]), (GET_ID(m_extOrder, (bpFldsTpId[bpPairIter->first]))));

                bpPairIter->second = -1;
            }
        }

        /* EO Feeandtax*/

        SET_NULL_ID(locExtOrder, ExtOp_DbId);
        SET_NUMBER(locExtOrder, ExtOp_Qty, (roundedQty * multiplier));
        SET_NUMBER(locExtOrder, ExtOp_AdjQty, (roundedAdjQty * adjMultplier));
        /* copy some from parent */

        for ( int fldIndex = 0; fldIndex < fldCount; fldIndex++)
        {
            COPY_DYNFLD(locExtOrder, ExtOp, (fields[fldIndex]), m_extOrder, ExtOp, (fields[fldIndex]));
        }


        SET_ENUM(locExtOrder, ExtOp_OpSplitRuleEn, OpOpSplitRuleEn::No);

        COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_PtfId, iter->m_ptf, A_Ptf, A_Ptf_Id);
        COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_PtfCurrId, iter->m_ptf, A_Ptf, A_Ptf_CurrId);
        COPY_DYNFLD(locExtOrder, ExtOp, ExtOp_SplitParOpCd, m_extOrder, ExtOp, ExtOp_Cd);

        if (0 != SCPT_ComputeDV(EOp, scptFlagTab, locExtOrder, TRUE, FALSE, NULL))
        {
            MSG_SendMesg(FILEINFO, "setValues: default value failed.");
            isDirty = true;
            FREE(scptFlagTab);
            return RET_GEN_ERR_NOACTION;
        }

        m_newExtOrder.push_back(locExtOrder);
        mp.remove(locExtOrder); /* to be freed explicitly */
    }

    /* check fee , if anything remaing, add it to highest holder*/
    if (m_newExtOrder.size() > 0)
    {
        for (auto bpPairIter = bpList.begin(); bpPairIter != bpList.end(); ++bpPairIter)
        {
            if (CMP_NUMBER(bpPairIter->second, ZERO_NUMBER) == 1)
            {
                SET_AMOUNT(m_newExtOrder[0], (bpFlds[bpPairIter->first]), (GET_AMOUNT(m_newExtOrder[0], (bpFlds[bpPairIter->first])) + bpPairIter->second));
            }
        }
    }

    /* if some qty remaining, add it ot head.
     * for eg : head            child1           child2
     *             33.33%        33.33%        33.33%
     *  order : 100 Qty, round off 1, nearest
     *              33                33                33      (99)
     *  this remaining 1 will be added to the one having higest %,
     *  if all same, then to head.
     * if round off to 5, then
     *              35                35                30 (handled inside loop)
     *if round off is 0.1
     *             33.3             33.3              33.3  (99.9)
     * 0.1 is added to first one, 33.4
     */


    if ((CMP_NUMBER(availableQty, ZERO_NUMBER) > 0 || CMP_NUMBER(availableAdjQty, ZERO_NUMBER) > 0)&& m_newExtOrder.size() > 0)
    {
        SET_NUMBER(m_newExtOrder[0], ExtOp_Qty, (GET_NUMBER(m_newExtOrder[0], ExtOp_Qty) + (availableQty * multiplier)));
        SET_NUMBER(m_newExtOrder[0], ExtOp_AdjQty, (GET_NUMBER(m_newExtOrder[0], ExtOp_AdjQty) + (availableAdjQty * adjMultplier)));

        if (0 != SCPT_ComputeDV(EOp, scptFlagTab, m_newExtOrder[0], TRUE, FALSE, NULL))
        {
            MSG_SendMesg(FILEINFO, "setValues: default value failed.");
            isDirty = true;
            FREE(scptFlagTab);
            return RET_GEN_ERR_NOACTION;
        }
    }

    FREE(scptFlagTab);
    return ret;

}

/************************************************************************
*   Function         :   SleeveHead::insertExtOrder
*   Description     :   insert child order to db. update parent order qty to ZERO. commit.
*                             commit only if all insert and update are success.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
void SleeveHead::insertExtOrder()
{
    bool copyOperCode = false;
    if (isDirty)
    {
        MSG_SendMesg(FILEINFO, "insertExtOrder Sleeve: data is not proepr. isDirty = false.");
        return;
    }
    copyOperCode = (hierGroup && m_extOrder != NULL && HierOpNatEn::HierOpNat_BlockOrder == static_cast<HierOpNatEn>(GET_ENUM(m_extOrder, ExtOp_HierOperNatEn)));
       
    sleeveConnHelper.beginTransaction();

    for (auto iter = m_newExtOrder.begin(); iter != m_newExtOrder.end(); ++iter)
    {
        if (copyOperCode && IS_NULLFLD(*iter, ExtOp_HierOperationCd))
        {
            COPY_DYNFLD((*iter), ExtOp, ExtOp_HierOperationCd, m_extOrder, ExtOp, ExtOp_Cd);
        }
        if (RET_SUCCEED != sleeveConnHelper.dbaInsert(EOp, UNUSED, *iter))
        {
            sleeveConnHelper.endTransaction(FALSE);
            MSG_SendMesg(FILEINFO, "Inserting order failed. check db logs");
            return;
        }
    }
    sleeveConnHelper.endTransaction(TRUE);
}

/************************************************************************
*   Function         :   SleeveHead::build
*   Description     :   create position list for all child ptf and head. sort it based on position.
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
void SleeveHead::build(SleeveProcessor& ctx)
{
    /* for head only */
    SleeveData head(ctx.getPortfolio(m_ptfId));
    head.derivePositionForGivenDate(ctx,  m_operDate);
    m_total = head.m_currentPos;
    sleeves.push_back(head);

    for (int i = 0; i < ctx.ptfNbr; ++i)
    {
        if (CMP_ID(m_ptfId, GET_ID(ctx.ptfTab[i], A_Ptf_Id)) == 0) /* head is already done. its may not be sleeve. so..*/
            continue;

        DBA_DYNFLD_STP ptf = ctx.getPortfolio(GET_ID(ctx.ptfTab[i], A_Ptf_Id));

        if (ptf!= nullptr && PtfNatEn::Sleeve == static_cast<PtfNatEn>(GET_ENUM(ptf, A_Ptf_NatEn)))
        {
            SleeveData data(ptf);
            data.derivePositionForGivenDate(ctx,  m_operDate);
            m_total += data.m_currentPos;
            sleeves.push_back(data);
        }
    }

    std::sort(sleeves.begin(), sleeves.end(), std::greater<SleeveData>());

}

/************************************************************************
*   Function         :   SleeveHead::~SleeveHead()
*   Description     :   free all the dynst allocated for new ext order
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
SleeveHead::~SleeveHead()
{
    for (auto iter = m_newExtOrder.begin(); iter != m_newExtOrder.end(); ++iter)
    {
        FREE_DYNST(*iter, ExtOp);
    }
}

SleeveData::SleeveData(DBA_DYNFLD_STP ptf) :m_ptf(ptf)
{
    m_currentPos = 0;
    m_newPos = 0;
    m_ptfId = GET_ID(m_ptf, A_Ptf_Id);
}


/************************************************************************
*   Function         :   SleeveData::derivePositionForGivenDate
*   Description     :   derive position for a given date
*   Arguments      :   None
*   Return            :   None
*************************************************************************/
void SleeveData::derivePositionForGivenDate(SleeveProcessor& ctx, DATETIME_T operDate)
{
    std::pair<int, int> index = ctx.getPosIndex(m_ptfId);
    if (index.first == -1)
    {
        m_currentPos = 0;
        return;
    }

    for (int i = index.first; i <= index.second; ++i)
    {
        /*posTab will have only primary_e=1 records */
        if (DATETIME_CMP(operDate, GET_DATETIME(ctx.posTab[i], A_Pos_BegDate)) >= 0)
        {
            m_positions.push_back(ctx.posTab[i]);
            m_currentPos += GET_NUMBER(ctx.posTab[i], A_Pos_Qty);
        }
    }
}
/*
    SLEEVE MANAGEMENT - PMSTA-40207 - 01062020 - LIK
*/

/************************************************************************
**   END  dbaop.c                                              Odyssey **
*************************************************************************/

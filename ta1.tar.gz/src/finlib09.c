/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB08_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "fin.h"
#include "scptyl.h"

/************************************************************************
**
**      Functions Description
**		FIN_StratUpdHierAndValue		Update hierarchy information for current record.
**      FIN_StratUpdAllSubStratContrib  Update the contributions and ordinate contributions
                                        of the sub-strategies linked to the modified field.
**      FIN_StratUpdSubStratContrib     Update the contributions of strategies linked
**                                      to the modified field.
**      FIN_StratUpdSubStratOrdContrib  Update the contributions of strategies (ordinate) linked
                                        to the modified field.
**      FIN_StratUpdContrib             Update the contributions of the current ESE
**                                      and the A_StratElt linked to.
**		FIN_StratUpdRecAndParent		Update extended strategy element and parent(s).
*************************************************************************/

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/


STATIC RET_CODE FIN_StratUpdSubStratContrib(DBA_HIER_HEAD_STP,
											DBA_DYNFLD_STP,
											int,
											int,
											int*,
											int (*)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020130 */
											PTR);
STATIC RET_CODE FIN_StratUpdSubStratOrdContrib(DBA_HIER_HEAD_STP,
											   DBA_DYNFLD_STP,
											   int,
											   int,
											   int*,
											   int (*)(PTR , DBA_DYNFLD_STP, FLAG_T*), /* REF7264 - LJE - 020130 */
											   PTR);
STATIC RET_CODE FIN_StratUpdContrib(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int, int*);





/************************************************************************
**
**  Function    :   FIN_CheckValidESE
**
**  Description :   Check if given ESE is valid or not
**
**  Arguments   :	ESEPtr          extended strategy element to update
**
**  Return      :   TRUE if valid
**
**  Creation	:	FPL-PMSTA12368-110728
**
*************************************************************************/
FLAG_T  FIN_CheckValidESE ( DBA_DYNFLD_STP      ESEPtr
                          )
{
    if ((ESEPtr != NULL) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeight               ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_MinWeight               ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_MaxWeight               ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjDura                 ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjDuraContrib          ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjBeta                 ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjBetaContrib          ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjCrtYield             ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjCrtYieldContrib      ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_MinRatingRank           ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjTrackErr             ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContrib        ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightMarg           ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjDuraMarg             ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjDuraContribMarg      ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjBetaMarg             ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjBetaContribMarg      ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjCrtYieldMarg         ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjCrtYieldContribMarg  ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjTrackErrMarg         ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContribMarg    ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_BenchEntDictId          ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_BenchObjId              ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_AnaBenchEntDictId       ) == TRUE) &&
        (IS_NULLFLD(ESEPtr, ExtStratElt_AnaBenchObjId           ) == TRUE) &&
        ((IS_NULLFLD(ESEPtr, ExtStratElt_Priority               ) == TRUE) ||
         (GET_SMALLINT(ESEPtr, ExtStratElt_Priority             ) == 0  )) &&
        ((IS_NULLFLD(ESEPtr, ExtStratElt_CriticalnessEn         ) == TRUE) ||
         (GET_ENUM(ESEPtr, ExtStratElt_CriticalnessEn           ) == 0)))
        return FALSE ;
    else
        return TRUE ;
}


/************************************************************************
**
**  Function    :   FIN_StratUpdHierAndValue()
**
**  Description :   Update hierarchy information for current record.
**
**  Arguments   :   stratHierPtr    strategy hierarchy header pointer
**					ESEPtr          extended strategy element to update
**					action          action to perfome with given ExtStratElt.
**                  field           modified field -> update A_StratElt with corresponding nature
**					context			current context for new lines.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	RAK - 990719 - REF3729
**  Modif.		:   ROI - 990909 - REF3729
**	Modif.		:	MRA - 991220 - REF4047  Set Default Values described in script
**
*************************************************************************/
RET_CODE FIN_StratUpdHierAndValue(DBA_HIER_HEAD_STP      stratHierPtr,
                                 DBA_DYNFLD_STP         ESEPtr,
                                 DBA_ACTION_ENUM        action,
                                 int                    field,
                                 int                    selOptions,
                                 int*                   connectNo,
                                 FLAG_T                 keepAllStratEltFlg) /* PMSTA-27076 - CHU - 170626 */
{
    RET_CODE			ret             = RET_SUCCEED;
    STRATELTNAT_ENUM	stratEltNatEn   = StratEltNat_Weight;   /* REF7264 - RAK - 020307 */
    StratSubNatEn       subNatEn        = StratSubNatEn::None;     /* REF7264 - LJE - 020130 */
    FLAG_T				found           = FALSE;
    FLAG_T              valueFlg        = FALSE;
    FLAG_T              marginFlg       = FALSE;
    FLAG_T              benchFlg        = FALSE;
    FLAG_T              flagAnaBench    = FALSE;
	FLAG_T              priorityFlg     = FALSE;	/* FIH-REF6989-010911 */
	FLAG_T				criticalFlg		= TRUE;		/* PMSTA07151 - RAK - 081030 */
    FLAG_T				excludedFlg     = FALSE;    /* PMSTA-39969 - sanand - 12052020 */
    FLAG_T				noTargetWtFlg   = FALSE;    /* PMSTA-40203 - sanand - 17062020 */
    FLAG_T             *scptFlagTab     = NULL;
	FLAG_T              lowerMarginFlg  = FALSE; /* PMSTA-40213-badhri-23072020 */
	FLAG_T              upperMarginFlg  = FALSE; /* PMSTA-40213-badhri-23072020 */
	FLAG_T				quasiCashFlg    = FALSE; /* PMSTA-43175-Badhri-21122020 */
    int                 i;
    int                 stratEltNbr     = 0;
    int                 ESLNbr          = 0;
    int                 code;
    DBA_DYNFLD_STP     *stratEltTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP     *ESLTab          = NULLDYNSTPTR;
    DBA_DYNFLD_STP      stratHistPtr    = NULLDYNST;
	DBA_DYNFLD_STP      stratEltPtr     = NULLDYNST;

    /* Get current ExtStratLnk to get history and all strategy element list */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                     ExtStratLnk,
			                                     FALSE,
                                                 FIN_StratFilterCrtESL,
                                                 ESEPtr,
                                                 NULLFCT,
                                                 &ESLNbr,
                                                 &ESLTab)) != RET_SUCCEED)
	return(ret);

    /* Always 1 ExtStratLnk */
    if (ESLNbr != 1 || ESLTab == NULLDYNSTPTR)
    {
        return(RET_DBA_ERR_HIER);
    }

    /* Get history and element(s) */
    if (GET_EXTENSION_PTR(ESLTab[0], ExtStratLnk_A_StratHist_Ext) != NULL &&
	   (stratHistPtr = *(GET_EXTENSION_PTR(ESLTab[0], ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
    }

    /* REF3729 - RAK - 990924 - 0 stratElt is treated ... */
	/* if (stratEltNbr == 0 || stratEltTab == NULLDYNSTPTR)
		return(RET_DBA_ERR_HIER);
	*/


    /* Update hierarchy information for A_StratElt */
    /* (because of they are save in database) */

    /* REF4047 - 000118 - SKE

    if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == (ENUM_T) ExtStratEltNat_Alloc ||
        GET_ENUM(ESEPtr, ExtStratElt_NatEn) == (ENUM_T) ExtStratEltNat_BreakCriteria)

    */
    /* */
    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_Alloc)
    {
	    /* Get A_StratElt nature corresponding to modified field. */
        /* REF8844 - LJE - 030410 : switch -> if */
	    if (field==ExtStratElt_ObjWeight )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_Weight;
	    }
        else if (field==ExtStratElt_MinWeight )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_MinWeight;
	    }
        else if (field==ExtStratElt_MaxWeight )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_MaxWeight;
	    }
        else if (field==ExtStratElt_ObjDura )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_Duration;
	    }
        else if (field==ExtStratElt_ObjDuraContrib )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_ContrDura;
	    }
        else if (field==ExtStratElt_ObjBeta )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_Beta;
	    }
        else if (field==ExtStratElt_ObjBetaContrib )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_ContrBeta;
	    }
        else if (field==ExtStratElt_ObjCrtYield )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_CurrRtn;
	    }
        else if (field==ExtStratElt_ObjCrtYieldContrib )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_ContrCurrRtn;
	    }
        else if (field==ExtStratElt_MinRatingRank )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_MinRatingRk;
	    }
        else if (field==ExtStratElt_ObjTrackErr )
        {
            valueFlg = TRUE;
	        stratEltNatEn = StratEltNat_TrackError;
	    }
        else if (field==ExtStratElt_ObjWeightContrib)
        {
            /* REF4047 - 991224 - SKE */
            stratEltNatEn = StratEltNat_Weight;
            valueFlg = TRUE;
        }
        else if (field==ExtStratElt_ObjWeightMarg ) /* Margin */
        {
	        stratEltNatEn = StratEltNat_Weight;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjDuraMarg )
        {
	        stratEltNatEn = StratEltNat_Duration;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjDuraContribMarg )
        {
	        stratEltNatEn = StratEltNat_ContrDura;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjBetaMarg )
        {
	        stratEltNatEn = StratEltNat_Beta;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjBetaContribMarg )
        {
	        stratEltNatEn = StratEltNat_ContrBeta;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjCrtYieldMarg )
        {
	        stratEltNatEn = StratEltNat_CurrRtn;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjCrtYieldContribMarg )
        {
	        stratEltNatEn = StratEltNat_ContrCurrRtn;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjTrackErrMarg )
        {
	        stratEltNatEn = StratEltNat_TrackError;
	        marginFlg = TRUE;
	    }
        else if (field==ExtStratElt_ObjWeightContribMarg) /* REF4047 - 000104 - SKE */
        {
            stratEltNatEn = StratEltNat_Weight;
            marginFlg = TRUE;
        }
		else if (field == ExtStratElt_ObjLowerMarg) /* PMSTA-40213-badhri-23072020 : lower margin */
		{
			stratEltNatEn = StratEltNat_Weight;
			lowerMarginFlg = TRUE;
		}
		else if (field == ExtStratElt_ObjUpperMarg) /* PMSTA-40213-badhri-23072020 : upper margin */
		{
			stratEltNatEn = StratEltNat_Weight;
			upperMarginFlg = TRUE;
		}
		else if (field == ExtStratElt_ObjLowerContribMarg) /* PMSTA-40213-badhri-23072020 : lower contribution margin */
		{
			stratEltNatEn = StratEltNat_Weight;
			lowerMarginFlg = TRUE;
		}
		else if (field == ExtStratElt_ObjUpperContribMarg) /* PMSTA-40213-badhri-23072020 : upper contribution margin*/
		{
			stratEltNatEn = StratEltNat_Weight;
			upperMarginFlg = TRUE;
		}
        /* REF4047 - 991227 - SKE */
        else if (field==ExtStratElt_BenchEntDictId ||
                 field==ExtStratElt_BenchObjId)
        {
            stratEltNatEn = StratEltNat_Weight;
            benchFlg = TRUE;
        }
        /*  FIH-REF8538-021126  */
        else if (field==ExtStratElt_AnaBenchEntDictId ||
                 field==ExtStratElt_AnaBenchObjId)
        {
            stratEltNatEn = StratEltNat_Weight;
            flagAnaBench = TRUE;
        }
		/* FIH-REF6989-010911 */
		else if (field==ExtStratElt_Priority)
        {
			priorityFlg = TRUE;
			stratEltNatEn = StratEltNat_Weight;
		}
        else if (field==ExtStratElt_ActualWeight ||       /* SKE 000913 REF5192 */
                 field==ExtStratElt_ActualWeightContrib)  /* SKE 000913 REF5192 */
        {
            stratEltNatEn = StratEltNat_Weight;
            valueFlg = TRUE;
        }
        else if (field==ExtStratElt_CriticalnessEn)		/* PMSTA07121 - RAK - 081030 */
		{
			stratEltNatEn = StratEltNat_Weight;
			criticalFlg = TRUE;
		}
        else if (field == ExtStratElt_ExcludedFlg)		/* PMSTA-39969 - sanand - 05052020 - Update Excluded flag */
        {
            excludedFlg = GET_FLAG(ESEPtr, ExtStratElt_ExcludedFlg);
        }
        else if (field == ExtStratElt_NoTargetWeightEn)		/* PMSTA-40203 - sanand - 24072020 - No Target Weight */
        {
            noTargetWtFlg = TRUE;
        }
		else if (field == ExtStratElt_QuasiCashEn) /* PMSTA-43175-Badhri-21122020 */
		{
			quasiCashFlg = TRUE;
		}
        else
        {
	        ret = RET_GEN_ERR_INVARG;
	        MSG_SendMesg(ret, 3, FILEINFO, "FIN_StratUpdHierAndValue", "modified field");
            FREE(ESLTab);
	        return(ret);
	    }

        /* Update ESE (to update format) */
	    if ((ret = DBA_UpdHierEltRec(stratHierPtr, ExtStratElt, ESEPtr)) != RET_SUCCEED)
        {
            FREE(ESLTab);
	        return(ret);
        }

	    /* Search A_StratElt which correspond to modified field */
	    for (i=0, found=FALSE; i<stratEltNbr && found==FALSE; i++)
	    {
			/* REF11559 - CHU - 051124 : check validity of Strategy element */
			if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
				IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
				CMP_ID(GET_ID(ESLTab[0], ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
			{
				continue;
			}

	        if ((STRATELTNAT_ENUM) GET_ENUM(stratEltTab[i], A_StratElt_NatEn) == stratEltNatEn &&
		        GET_ID(ESEPtr, ExtStratElt_StratHistId) == GET_ID(stratHistPtr, A_StratHist_Id) &&
		        GET_ID(ESEPtr, ExtStratElt_MktSegtId)   == GET_ID(stratEltTab[i], A_StratElt_MktSegtId))
	        {
		        found = TRUE;
                stratEltPtr = stratEltTab[i];
		        ret = DBA_UpdHierEltRec(stratHierPtr, A_StratElt, stratEltPtr);
                if (ret != RET_SUCCEED)
                {
                    FREE(ESLTab);
                    return(ret);
                }

            }
	    }

	    /* If not found, create a new strategy element */
	    if (found == FALSE)
	    {
	        if ((stratEltPtr = ALLOC_DYNST(A_StratElt)) == NULLDYNST)
	        {
                FREE(ESLTab);
		        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_StratElt");
		        return(RET_MEM_ERR_ALLOC);
	        }
	        DBA_SetDfltEntityFld(StratElt, A_StratElt, stratEltPtr);
		    if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_StratElt), sizeof(FLAG_T))) == NULL)		/* REF4047 */ /* REF7264 - LJE - 020130 */
            {
                FREE(ESLTab);
                FREE_DYNST(stratEltPtr, A_StratElt);
		        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "scptFlagTab");
		        return(RET_MEM_ERR_ALLOC);
            }
	        SET_ID(stratEltPtr,   A_StratElt_StratHistId, GET_ID(ESEPtr, ExtStratElt_StratHistId));
	        SET_ID(stratEltPtr,   A_StratElt_MktSegtId,   GET_ID(ESEPtr, ExtStratElt_MktSegtId));
	        SET_ENUM(stratEltPtr, A_StratElt_NatEn,       (ENUM_T) stratEltNatEn);
            /* REF4047 - 000105 - SKE */
            SET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));
		    /* REF4047 */
		    scptFlagTab[A_StratElt_StratHistId] = TRUE;
		    scptFlagTab[A_StratElt_MktSegtId] = TRUE;
		    scptFlagTab[A_StratElt_NatEn] = TRUE;
            scptFlagTab[A_StratElt_ExtStratElt_Id] = TRUE;
        }

		/* Update value (or margin) in strategy element */
		/* (which will be updated in database)          */
	    if (valueFlg == TRUE)
	    {
            if (field == ExtStratElt_ObjWeightContrib   ||
                field == ExtStratElt_ActualWeight       ||  /* SKE 000913 REF5192 */
                field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_ObjWeight);
            }
            else
            {
                /* PMSTA08782 - RAK - 091013 must add cast int -> double */
				if (field == ExtStratElt_MinRatingRank)
				{
					SET_NUMBER(stratEltPtr, A_StratElt_Value, (NUMBER_T)GET_SMALLINT(ESEPtr, field));
				}
				else
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt,  A_StratElt_Value,
						        ESEPtr,      ExtStratElt, field);
				}
            }
			if (scptFlagTab != NULL) scptFlagTab[A_StratElt_Value] = TRUE;		/* REF4047 */
	    }
	    else if (marginFlg == TRUE)
	    {
            if (field == ExtStratElt_ObjWeightContribMarg)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightMarg);
            }
            else
            {
    			COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, field);
            }
			if (scptFlagTab != NULL) scptFlagTab[A_StratElt_FluctMargin] = TRUE;		/* REF4047 */
	    }
		else if (lowerMarginFlg == TRUE)
		{
			/* PMSTA-40213-badhri-23072020 : set the lower margins*/
			if (field == ExtStratElt_ObjLowerContribMarg)
			{
				COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjLowerMarg);
			}
			else
			{
				COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, field);
			}
			if (scptFlagTab != NULL) scptFlagTab[A_StratElt_LowerMarg] = TRUE;
		}
		else if (upperMarginFlg == TRUE)
		{
			/* PMSTA-40213-badhri-23072020 : set the upper margins*/
			if (field == ExtStratElt_ObjUpperContribMarg)
			{
				COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjUpperMarg);
			}
			else
			{
				COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, field);
			}
			if (scptFlagTab != NULL) scptFlagTab[A_StratElt_UpperMarg] = TRUE;
		}
		else if(priorityFlg == TRUE)	/* FIH-REF6989-010911 */
		{
			COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Priority, ESEPtr, ExtStratElt, field);
			if (scptFlagTab != NULL)
				scptFlagTab[A_StratElt_Priority] = TRUE;
		}
        /*  FIH-REF8538-021126  */
        else if (flagAnaBench == TRUE)
        {
            if (field == ExtStratElt_AnaBenchEntDictId)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_AnaBenchEntDictId, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_AnaBenchEntDictId] = TRUE;
                if (IS_NULLFLD(stratEltPtr, A_StratElt_AnaBenchEntDictId) == TRUE)
                {
                    SET_NULL_ID(ESEPtr, ExtStratElt_AnaBenchObjId);
                    SET_NULL_ID(stratEltPtr, A_StratElt_AnaBenchObjId);
                    if (scptFlagTab != NULL)
                        scptFlagTab[A_StratElt_AnaBenchObjId] = TRUE;
                }
            }
            else
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_AnaBenchObjId, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_AnaBenchObjId] = TRUE;
            }
        }
        /* REF4047 - 000104 - SKE */
        else if (benchFlg == TRUE)
        {
            if (field == ExtStratElt_BenchEntDictId)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_BenchEntDictId, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_BenchEntDictId] = TRUE;
                /* REF4047 - 000126 - SKE : if bench entity dict id is NULL set bench obj id at NULL */
                if (IS_NULLFLD(stratEltPtr, A_StratElt_BenchEntDictId) == TRUE)
                {
                    SET_NULL_ID(ESEPtr, ExtStratElt_BenchObjId);
                    SET_NULL_ID(stratEltPtr, A_StratElt_BenchObjId);
                    if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_BenchObjId] = TRUE;
                }
            }
            else
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_BenchObjId, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_BenchObjId] = TRUE;
            }
        }
		/* PMSTA07121 - RAK - 081030 */
		else if (criticalFlg == TRUE && field == ExtStratElt_CriticalnessEn) /* PMSTA-40526 -sanand- save only corresponding field */
		{
            if (keepAllStratEltFlg == TRUE)
            {
                if (IS_NULLFLD(ESEPtr, field) == FALSE) /* PMSTA-27076 - CHU - 170627 : do not set StratElt MD default to NULL for an Enum, may lead to DB insert error */
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn, ESEPtr, ExtStratElt, field);
                }
                else /* PMSTA-27076 - CHU - 170627 : Get the value from the strategy itself, if available */
                {
                    DBA_DYNFLD_STP	aStratPtr = NULLDYNST;
                    if (DBA_GetRecPtrFromHierById(stratHierPtr, GET_ID(ESEPtr, ExtStratElt_StratId), A_Strat, &aStratPtr) == RET_SUCCEED && (aStratPtr != NULLDYNST))
                    {
                        COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn, aStratPtr, A_Strat, A_Strat_CriticalnessEn);
                    }
                }
            }
            else /* PMSTA-27076 - CHU - 170627 : do as before... */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn, ESEPtr, ExtStratElt, field);
            }
            if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_CriticalnessEn] = TRUE;
		}
		else if (quasiCashFlg == TRUE && field == ExtStratElt_QuasiCashEn) /* PMSTA-43175-Badhri-21122020 */
		{
			COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_QuasiCashEn, ESEPtr, ExtStratElt, field);
			if (scptFlagTab != NULL)
				scptFlagTab[A_StratElt_QuasiCashEn] = TRUE;
		}

        /* PMSTA-40526 - sanand - To update only when save on corresponding field */
        if( field == ExtStratElt_ExcludedFlg)
        {
            SET_FLAG(stratEltPtr, A_StratElt_ExcludedFlg, excludedFlg);
            if (scptFlagTab != NULL) scptFlagTab[A_StratElt_ExcludedFlg] = TRUE;
        }

        if (noTargetWtFlg && field == ExtStratElt_NoTargetWeightEn)		/* PMSTA-40203 - sanand - 17062020 -  To update NoTargetWeight Field */
        {
            COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_NoTargetWeightEn, ESEPtr, ExtStratElt, field);
            if (scptFlagTab != NULL)
                scptFlagTab[A_StratElt_NoTargetWeightEn] = TRUE;
        }
		
        if ((selOptions & DBA_IN_TRAN) != DBA_IN_TRAN &&
            found == FALSE)
        {
		    /* Set Default Values described in script */	/* REF4047 */
		    if((code = SCPT_ComputeScreenDV(StratElt,
                                            DictFct_0,
										    scptFlagTab,
                                            NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
										    stratEltPtr,
										    NULL,
										    NULL,
                                            NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
										    TRUE,
										    TRUE,
                                            EvalType_DefValAndFilter,   /* FPL-REF9507-030930 */
										    -1,
										    connectNo,
										    NULL,
										    stratHierPtr,
										    0,
                                            DictScreen,                 /*  FIH-REF9789-040209  */
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NullEntity,
                                            FALSE,
                                            FALSE,
                                            0)) != 0)   /*  FPL-REF9215-030811  Flag Impact */
            {
                FREE(ESLTab);
                FREE(scptFlagTab);
                FREE_DYNST(stratEltPtr, A_StratElt);
                return(RET_GEN_ERR_INVARG);
            }
            FREE(scptFlagTab);
	        if ((ret = DBA_AddHierRecord(stratHierPtr,
                                         stratEltPtr,
                                         A_StratElt,
                                         FALSE,
                                         HierAddRec_TestMandatLnk)) != RET_SUCCEED)
	        {
                FREE(ESLTab);
                FREE_DYNST(stratEltPtr, A_StratElt);
			    return(ret);
	        }

            if ((ret = DBA_SetStatusHierModInsert(stratHierPtr,
									              A_StratElt,
									              stratEltPtr)) != RET_SUCCEED)
            {
                FREE(ESLTab);
			    return(ret);
            }


		    if (stratHistPtr != NULLDYNST)
		    {
			    if ((ret = DBA_ForceLink(stratHierPtr,
                                         A_StratHist,
                                         A_StratHist_A_StratElt_Ext,
                                         stratHistPtr,
                                         stratEltPtr)) != RET_SUCCEED)
                {
                    FREE(ESLTab);
                    return(ret);
                }
		    }
	    }
        /*  FPL-PMSTA12368-110728 if not valid, set the SE to be deleted from DB    */
        if (FIN_CheckValidESE(ESEPtr) == FALSE)
        {
            if (keepAllStratEltFlg == FALSE)
            {
                ret = DBA_DelHierEltRec(stratHierPtr, A_StratElt, stratEltPtr);
            }
        }
    }
    else
    {
        if (action == Update)
        {
            ret = DBA_UpdHierEltRec(stratHierPtr, ExtStratElt, ESEPtr);
            if (ret != RET_SUCCEED)
            {
                FREE(ESLTab);
                return(ret);
            }

            /* REF4047 - 000203 - SKE : Sub Nature management */
            subNatEn = static_cast<StratSubNatEn> GET_ENUM(ESLTab[0], ExtStratLnk_SubNatEn); /* REF7264 - LJE - 020130 */

            /* Search A_StratElt which correspond to received ExtStratElt */
	        for (i=0, found = FALSE ; i<stratEltNbr ; i++)
	        {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLTab[0], ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

                if (GET_ID(stratEltTab[i], A_StratElt_ExtStratElt_Id) == GET_ID(ESEPtr, ExtStratElt_Id))
			    {
                    found = TRUE;
                    stratEltPtr = stratEltTab[i];
                    ret = DBA_UpdHierEltRec(stratHierPtr, A_StratElt, stratEltPtr);
                    if (ret != RET_SUCCEED)
                    {
                        FREE(ESLTab);
                        return(ret);
                    }
                    break;
                }
            }
            if (found == FALSE)
            {
	            if ((stratEltPtr = ALLOC_DYNST(A_StratElt)) == NULLDYNST)
	            {
                    FREE(ESLTab);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_StratElt");
		            return(RET_MEM_ERR_ALLOC);
	            }
	            DBA_SetDfltEntityFld(StratElt, A_StratElt, stratEltPtr);
		        if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_StratElt), sizeof(FLAG_T))) == NULL)		/* REF4047 */ /* REF7264 - LJE - 020130 */
                {
                    FREE(ESLTab);
                    FREE_DYNST(stratEltPtr, A_StratElt);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "scptFlagTab");
		            return(RET_MEM_ERR_ALLOC);
                }
	            SET_ID(stratEltPtr, A_StratElt_StratHistId, GET_ID(ESEPtr, ExtStratElt_StratHistId));
                scptFlagTab[A_StratElt_StratHistId] = TRUE;
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_MktSegtId, ESEPtr, ExtStratElt, ExtStratElt_MktSegtId);
                scptFlagTab[A_StratElt_MktSegtId] = TRUE;

	            if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_ModelPtf)
	            {
                    if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == (ENUM_T)ExtStratEltNat_BreakCriteria)
                    {
                        /* REF4047 - 000203 - SKE : Sub Nature management */
                        if (subNatEn == StratSubNatEn::ConstantWeight)
                        {
                            SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelConstWeight);
                        }
                        else
                        {
                            SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T) StratEltNat_Model);
                        }
                    }
                    else
                    {
                        /* REF4047 - 000203 - SKE : Sub Nature management */
                        if (subNatEn == StratSubNatEn::ConstantWeight)
                        {
                            SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelPtfConstWeight);
                        }
                        else
                        {
                            SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelPtf);
                        }
                    }
                }
	            else
				{
		            if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_RecomList)
					{
						SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T)StratEltNat_RecommList);
					}
		            else
					{
						SET_ENUM(stratEltPtr, A_StratElt_NatEn, (ENUM_T)StratEltNat_SSL); /* REF7487 VST 020807 */
					}
				}
                scptFlagTab[A_StratElt_NatEn] = TRUE;
                SET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));
                scptFlagTab[A_StratElt_ExtStratElt_Id] = TRUE;
            }

            /* REF8844 - LJE - 030410 : switch -> if */
            if (field==ExtStratElt_MaxWeight ||       /* REF4221 - 991220 - RAK/SKE */
                field==ExtStratElt_MaxWeightContrib)  /* REF4221 - 991220 - RAK/SKE */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_MaxWeight);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_Value] = TRUE;
            }
            else if (field==ExtStratElt_ObjWeight)
            {
                /* REF4047 - 000203 - SKE : Sub Nature management */
                if (subNatEn == StratSubNatEn::ConstantWeight)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightContrib);
                }
                else
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_ObjWeight);
                }
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_Value] = TRUE;
            }
            else if (field==ExtStratElt_ObjWeightContrib)
            {
                if (subNatEn == StratSubNatEn::ConstantWeight)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightContrib);
                }
                else
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Value, ESEPtr, ExtStratElt, ExtStratElt_ObjWeight);
                }
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_Value] = TRUE;
            }
            else if (field==ExtStratElt_ObjWeightMarg) /* REF4047 - 000203 - SKE : Sub Nature management */
            {
                if (subNatEn == StratSubNatEn::ConstantWeight)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightContribMarg);
                }
                else
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightMarg);
                }
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_FluctMargin] = TRUE;
            }
            else if (field==ExtStratElt_ObjWeightContribMarg) /* REF4047 - 000203 - SKE : Sub Nature management */
            {
                if (subNatEn == StratSubNatEn::ConstantWeight)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightContribMarg);
                }
                else
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_FluctMargin, ESEPtr, ExtStratElt, ExtStratElt_ObjWeightMarg);
                }
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_FluctMargin] = TRUE;
            }
			else if (field == ExtStratElt_ObjLowerMarg) /* PMSTA-40213-badhri-23072020 :  lower margin */
			{
				if (subNatEn == StratSubNatEn::ConstantWeight)
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjLowerContribMarg);
				}
				else
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjLowerMarg);
				}
				if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_LowerMarg] = TRUE;
			}
			else if (field == ExtStratElt_ObjLowerContribMarg) /* PMSTA-40213-badhri-23072020 :  lower contribution margin*/
			{
				if (subNatEn == StratSubNatEn::ConstantWeight)
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjLowerContribMarg);
				}
				else
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_LowerMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjLowerMarg);
				}
				if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_LowerMarg] = TRUE;
			}
			else if (field == ExtStratElt_ObjUpperMarg) /* PMSTA-40213-badhri-23072020 :  upper margin */
			{
				if (subNatEn == StratSubNatEn::ConstantWeight)
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjUpperContribMarg);
				}
				else
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjUpperMarg);
				}
				if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_UpperMarg] = TRUE;
			}
			else if (field == ExtStratElt_ObjUpperContribMarg) /* PMSTA-40213-badhri-23072020 :  upper contribution margin*/
			{
				if (subNatEn == StratSubNatEn::ConstantWeight)
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjUpperContribMarg);
				}
				else
				{
					COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_UpperMarg, ESEPtr, ExtStratElt, ExtStratElt_ObjUpperMarg);
				}
				if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_UpperMarg] = TRUE;
			}
            else if (field==ExtStratElt_InstrId)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_InstrId, ESEPtr, ExtStratElt, ExtStratElt_InstrId);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_InstrId] = TRUE;
            }
            else if (field==ExtStratElt_Rank)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Rank, ESEPtr, ExtStratElt, ExtStratElt_Rank);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_Rank] = TRUE;
            }
            else if (field==ExtStratElt_RecomNatEn)
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_RecomNatEn, ESEPtr, ExtStratElt, ExtStratElt_RecomNatEn);
                if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_RecomNatEn] = TRUE;
            }
			else if (field==ExtStratElt_BenchEntDictId )
            {
                if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_BenchEntDictId, ESEPtr, ExtStratElt, ExtStratElt_BenchEntDictId);
                    if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_BenchEntDictId] = TRUE;
                }
			}
            else if (field==ExtStratElt_BenchObjId )
            {
                if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
                {
                    COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_BenchObjId, ESEPtr, ExtStratElt, ExtStratElt_BenchObjId);
                    if (scptFlagTab != NULL)  scptFlagTab[A_StratElt_BenchObjId] = TRUE;
                }
			}
            else if (field==ExtStratElt_Priority)  /* FIH-REF6989-010911 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Priority, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_Priority] = TRUE;
            }
            else if (field==ExtStratElt_Min)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Min, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_Min] = TRUE;
            }
			else if (field==ExtStratElt_Max)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_Max, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_Max] = TRUE;
            }
			else if (field==ExtStratElt_ObjTrackErr)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_ObjTrackErr, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_ObjTrackErr] = TRUE;
            }
			else if (field==ExtStratElt_ObjTrackErrMarg)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_ObjTrackErrMarg, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_ObjTrackErrMarg] = TRUE;
            }
			else if (field==ExtStratElt_ActualTrackErr)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_ActualTrackErr, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_ActualTrackErr] = TRUE;
            }
			else if (field==ExtStratElt_EffTrackErr)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_EffTrackErr, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_EffTrackErr] = TRUE;
            }
			else if (field==ExtStratElt_ObjTrackErrCheckEn)  /* PMSTA05345-CHU-080505 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_ObjTrackErrCheckEn, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_ObjTrackErrCheckEn] = TRUE;
            }
			else if (field==ExtStratElt_CriticalnessEn)		/* PMSTA07121-RAK-090424 */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
					scptFlagTab[A_StratElt_CriticalnessEn] = TRUE;
            }
            else if (field == ExtStratElt_ExcludedFlg)		/* PMSTA-40526 - sanand - To update only when save on corresponding field */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_ExcludedFlg, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_ExcludedFlg] = TRUE;
            }
            else if (field == ExtStratElt_MinThreshold )  /*PMSTA-42402 Autocash Vishnu 09122020*/
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_MinThreshold, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_MinThreshold] = TRUE;
            }else if (field == ExtStratElt_MaxThreshold)  /*PMSTA-42402 Autocash Vishnu 09122020*/
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_MaxThreshold, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_MaxThreshold] = TRUE;
            }
            else if (field == ExtStratElt_MinForecast)  /*PMSTA-42402 Autocash Vishnu 09122020*/
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_MinCashForecastM , ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_MinCashForecastM] = TRUE;
            }
            else if (field == ExtStratElt_MaxForecast)  /*PMSTA-42402 Autocash Vishnu 09122020*/
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_MaxCashForecastM, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_MaxCashForecastM] = TRUE;
            }
            else if (field == ExtStratElt_CashForecastM)  /*PMSTA-42402 Autocash Vishnu 09122020*/
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_CashForecastM, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_CashForecastM] = TRUE;
            }
     
            if (noTargetWtFlg && field == ExtStratElt_NoTargetWeightEn)		/* PMSTA-40203 - sanand - 17062020 -  To update NoTargetWeight Field */
            {
                COPY_DYNFLD(stratEltPtr, A_StratElt, A_StratElt_NoTargetWeightEn, ESEPtr, ExtStratElt, field);
                if (scptFlagTab != NULL)
                    scptFlagTab[A_StratElt_NoTargetWeightEn] = TRUE;
            }
            if (found == FALSE)
            {
                if ((selOptions & DBA_IN_TRAN) != DBA_IN_TRAN)
                {
		            /* Set Default Values described in script */
		            if((code = SCPT_ComputeScreenDV(StratElt,
                                                    DictFct_0,
										            scptFlagTab,
                                                    NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
										            stratEltPtr,
										            NULL,
										            NULL,
                                                    NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
										            TRUE,
										            TRUE,
                                                    EvalType_DefValAndFilter,   /* FPL-REF9507-030930 */
										            -1,
										            connectNo,
										            NULL,
										            stratHierPtr,
                                                    0,
                                                    DictScreen,                 /*  FIH-REF9789-040209  */
										            NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NULL,
                                                    NullEntity,
                                                    FALSE,
                                                    FALSE,
                                                    0)) != 0)   /*  FPL-REF9215-030811  Flag Impact */
                    {
                        FREE(ESLTab);
                        FREE(scptFlagTab);
                        FREE_DYNST(stratEltPtr, A_StratElt);
                        return(RET_GEN_ERR_INVARG);
                    }
                }

                FREE(scptFlagTab);
	            if ((ret = DBA_AddHierRecord(stratHierPtr,
                                             stratEltPtr,
                                             A_StratElt,
                                             FALSE,
                                             HierAddRec_TestMandatLnk)) != RET_SUCCEED)
	            {
                    FREE(ESLTab);
                    FREE_DYNST(stratEltPtr, A_StratElt);
			        return(ret);
	            }
                if ((ret = DBA_SetStatusHierModInsert(stratHierPtr,
									                  A_StratElt,
									                  stratEltPtr)) != RET_SUCCEED)
                {
                    FREE(ESLTab);
			        return(ret);
                }
                SET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));
				if (stratHistPtr != NULLDYNST) /* PMSTA17155-CHU-131108 : check validity of strategy history pointer */
				{
					if ((ret = DBA_ForceLink(stratHierPtr,
											 A_StratHist,
											 A_StratHist_A_StratElt_Ext,
											 stratHistPtr,
											 stratEltPtr)) != RET_SUCCEED)
					{
						FREE(ESLTab);
						return(ret);
					}
				}
	        }
        }
        else if (action == Delete)
        {
            /* Search A_StratElt which correspond to received ExtStratElt */
	        for (i=0 ; i<stratEltNbr ; i++)
	        {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLTab[0], ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

                if (GET_ID(stratEltTab[i], A_StratElt_ExtStratElt_Id) == GET_ID(ESEPtr, ExtStratElt_Id))
			    {
                    stratEltPtr = stratEltTab[i];
			        ret = DBA_DelHierEltRec(stratHierPtr, A_StratElt, stratEltPtr);
                    if (ret != RET_SUCCEED)
                    {
                        FREE(ESLTab);
                        return(ret);
                    }
					if (stratHistPtr != NULLDYNST) /* PMSTA17155-CHU-131108 : check validity of strategy history pointer */
					{
						if ((ret = DBA_ForceLink(stratHierPtr,
												 A_StratHist,
												 A_StratHist_A_StratElt_Ext,
												 stratHistPtr,
												 stratEltPtr)) != RET_SUCCEED)
						{
							FREE(ESLTab);
							return(ret);
						}
					}
                    ret = DBA_DelHierEltRec(stratHierPtr, ExtStratElt, ESEPtr);
                    if (ret != RET_SUCCEED)
                    {
                        FREE(ESLTab);
                        return(ret);
                    }
                    FREE(ESLTab);
                    return(ret);
                }
            }
            /* A_StratElt not found => Error ! */
            MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
            FREE(ESLTab);
            return(RET_DBA_ERR_NODATA);
        }
    }
    FREE(ESLTab);
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_StratUpdAllSubStratContrib()
**
**  Description :   Update the contributions and ordinate contributions
**                  of the sub-strategies linked to the modified field.
**
**
**  Arguments   :   stratHierPtr	strategy hierarchy header pointer
**					ESEPtr			extended strategy element updated
**                  field			modified field
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	REF4047 - 20000207 - SKE
**
*************************************************************************/
RET_CODE FIN_StratUpdAllSubStratContrib(DBA_HIER_HEAD_STP        stratHierPtr,
                                       DBA_DYNFLD_STP           ESEPtr,
                                       int                      field,
                                       int                      selOptions,
                                       int*                     connectNo,
                                       int                      (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*),
                                       PTR                      context)
{
    RET_CODE        ret         = RET_SUCCEED;

    if (field == ExtStratElt_ObjWeight  ||
        field == ExtStratElt_ObjWeightContrib)
    {
        /* Do the same with current ESE */
        ret = FIN_StratUpdSubStratContrib(stratHierPtr, ESEPtr, field, selOptions, connectNo, fct, context);
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }
        ret = FIN_StratUpdSubStratOrdContrib(stratHierPtr, ESEPtr, field, selOptions, connectNo, fct, context);
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }
    }
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_StratUpdSubStratContrib()
**
**  Description :   Update the contributions of strategies linked
**                  to the modified field.
**
**
**  Arguments   :   stratHierPtr	strategy hierarchy header pointer
**					ESEPtr			extended strategy element updated
**                  field			modified field
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	REF4047 - 20000207 - SKE
**
*************************************************************************/
STATIC RET_CODE FIN_StratUpdSubStratContrib(DBA_HIER_HEAD_STP       stratHierPtr,
                                            DBA_DYNFLD_STP          ESEPtr,
                                            int                     field,
                                            int                     selOptions,
                                            int*                    connectNo,
                                            int                     (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*),
                                            PTR                     context)
{
    RET_CODE        ret         = RET_SUCCEED;
    DBA_DYNFLD_STP *ESETab      = NULLDYNSTPTR;
    int             ESENbr      = 0;
    int             i;

    /* Extract children */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                     ExtStratElt,
			                                     FALSE,
                                                 FIN_StratFilterChildrenESE,
                                                 ESEPtr,
                                                 NULLFCT,
                                                 &ESENbr,
                                                 &ESETab)) != RET_SUCCEED)
    {
	    return(ret);
    }
    for (i=0 ; i<ESENbr; i++)
    {
        /* Update contrib values */
        ret = FIN_StratUpdContrib(stratHierPtr, ESETab[i], selOptions, connectNo);
        if (ret != RET_SUCCEED)
        {
            FREE(ESETab);
            return(ret);
        }
        if (fct != NULL)
        {
	        fct(context, ESETab[i], NULL); /* REF7264 - LJE - 020130 */
        }
        /* Update the children ESE recursively */
        ret = FIN_StratUpdSubStratContrib(stratHierPtr, ESETab[i], field, selOptions, connectNo, fct, context);
        if (ret != RET_SUCCEED)
        {
            FREE(ESETab);
            return(ret);
        }
    }
    FREE(ESETab);
    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_StratUpdSubStratOrdContrib()
**
**  Description :   Update the contributions of strategies (ordinate) linked
**                  to the modified field.
**
**
**  Arguments   :   stratHierPtr	strategy hierarchy header pointer
**					ESEPtr			extended strategy element updated
**                  field			modified field
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	REF4047 - 20000207 - SKE
**
*************************************************************************/
STATIC RET_CODE FIN_StratUpdSubStratOrdContrib(DBA_HIER_HEAD_STP    stratHierPtr,
                                               DBA_DYNFLD_STP       ESEPtr,
                                               int                  field,
                                               int                  selOptions,
                                               int*                 connectNo,
                                               int                  (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*), /* REF7264 - LJE - 020130 */
                                               PTR                  context)
{
    RET_CODE        ret         = RET_SUCCEED;
    DBA_DYNFLD_STP *ESETab      = NULLDYNSTPTR;
    int             ESENbr      = 0;
    int             i;

    /* Extract children */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                     ExtStratElt,
			                                     FALSE,
                                                 FIN_StratFilterChildrenESE,
                                                 ESEPtr,
                                                 NULLFCT,
                                                 &ESENbr,
                                                 &ESETab)) != RET_SUCCEED)
    {
	    return(ret);
    }
    for (i=0 ; i<ESENbr; i++)
    {
        /* Update contrib values */
        ret = FIN_StratUpdContrib(stratHierPtr, ESETab[i], selOptions, connectNo);
        if (ret != RET_SUCCEED)
        {
            FREE(ESETab);
            return(ret);
        }
        if (fct != NULL) /* REF7264 - LJE - 020130 */
        {
	        fct(context, ESETab[i], NULL); /* REF7264 - LJE - 020130 */
        }
        /* Do the same with current ESE */
        ret = FIN_StratUpdSubStratOrdContrib(stratHierPtr, ESETab[i], field, selOptions, connectNo, fct, context);
        if (ret != RET_SUCCEED)
        {
            FREE(ESETab);
            return(ret);
        }
    }
    FREE(ESETab);
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_StratUpdContrib()
**
**  Description :   Update the contributions of the current ESE
**                  and the A_StratElt linked to.
**
**
**  Arguments   :   stratHierPtr	strategy hierarchy header pointer.
**					ESEPtr			extended strategy element to update.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	REF4047 - 20000207 - SKE
**
*************************************************************************/
STATIC RET_CODE FIN_StratUpdContrib(DBA_HIER_HEAD_STP       stratHierPtr,
                                    DBA_DYNFLD_STP          ESEPtr,
                                    int                     selOptions,
                                    int*                    connectNo)
{
    RET_CODE        ret                 = RET_SUCCEED;
    DBA_DYNFLD_STP  contribParESEPtr    = NULLDYNST;
    NUMBER_T        contrib             = 0.0;

	if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	{
        if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
        {
            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeight) == FALSE)
            {
                contrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeight) *
                          GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) /100.0;
                SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, CAST_NUMBER(contrib));
                /* Update A_StratElt values */
                ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                               ESEPtr,
                                               Update,
                                               ExtStratElt_ObjWeightContrib,
                                               selOptions,
                                               connectNo,
                                               FALSE); /* PMSTA-27076 - CHU - 170626 */
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }
            }
            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightMarg) == FALSE)
            {

				switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))/* <SKE - 010208 - REF5599 */
				{
					case ExtStratEltForecast_Absolute:
	 			         contrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg) *
                         GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) /100.0;
						 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, CAST_NUMBER(contrib));
						 break;
					case ExtStratEltForecast_Relative:
 	                     SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
            			 break;
	 			    case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
						 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg,
                         GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
	 			         break;
				}

                /* Update A_StratElt values */
                ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                               ESEPtr,
                                               Update,
                                               ExtStratElt_ObjWeightContribMarg,
                                               selOptions,
                                               connectNo,
                                               FALSE); /* PMSTA-27076 - CHU - 170626 */
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }
            }
        }
    }
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_StratUpdRecAndParent()
**
**  Description :   Update extended strategy element and parent(s).
**
**  Arguments   :   stratHierPtr	strategy hierarchy eader pointer
**					ESEPtr			extended strategy element to update
**					action          TRUE if record is to delete (not possible for allocation)
**                  field			modified field (update A_StratElt according to is value)
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	RAK - 990719 - REF3729
**  Modif.		:   ROI - 990909 - REF3729
**
*************************************************************************/
RET_CODE FIN_StratUpdRecAndParent(DBA_HIER_HEAD_STP      stratHierPtr,
                                 DBA_DYNFLD_STP         ESEPtr,
                                 DBA_ACTION_ENUM        action,
                                 int                    field,
                                 int                    selOptions,
                                 int*                   connectNo,
                                 int                    (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020130 */
                                 PTR                    context,
                                 FLAG_T                 *dfltValTab,
                                 FLAG_T                 keepAllStratEltFlg) /* PMSTA-27076 - CHU - 170626*/
{
    RET_CODE	ret=RET_SUCCEED;


    if (action == Delete)
    {
        /* SKE - 000224 - : no vertical update for Recommendation */
        if ( (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_RecomList) ||
             (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_SSL) )
        {
            return(RET_SUCCEED);
        }
		/* recompute all fields total (current record) */
		if (field == -1)
		{
			dfltValTab[ExtStratElt_ObjWeight] = TRUE;
			dfltValTab[ExtStratElt_ObjWeightMarg] = TRUE;
			dfltValTab[ExtStratElt_ObjDuraContrib] = TRUE;
			dfltValTab[ExtStratElt_ObjBetaContrib] = TRUE;
			dfltValTab[ExtStratElt_ObjCrtYieldContrib] = TRUE;

            ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, ESEPtr, action, ExtStratElt_ObjWeight, selOptions, connectNo, NULL, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/

			if (ret == RET_SUCCEED)
                ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, ESEPtr, action, ExtStratElt_ObjWeightMarg, selOptions, connectNo, NULL, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/

			if (ret == RET_SUCCEED)
                ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, ESEPtr, action, ExtStratElt_ObjDuraContrib, selOptions, connectNo, NULL, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/

			if (ret == RET_SUCCEED)
                ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, ESEPtr, action, ExtStratElt_ObjBetaContrib, selOptions, connectNo, NULL, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/

			/* ! last send fct pointer for parent (and only last so it's done one time ...) */
			if (ret == RET_SUCCEED)
                ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, ESEPtr, action, ExtStratElt_ObjCrtYieldContrib, selOptions, connectNo, fct, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/
		}
		else	/* parents called by one of the line above */
		{
            ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, NULLDYNST, action, field, selOptions, connectNo, fct, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/
		}

		/* Call default value function and format element update function */
		if (fct != NULL) /* REF7264 - LJE - 020130 */
        {
			fct(context, ESEPtr, dfltValTab);
        }
    }
    else
    {
        ret = FIN_FieldStratUpdRecAndParent(stratHierPtr, ESEPtr, NULLDYNST, action, field, selOptions, connectNo, fct, context, dfltValTab, keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626*/
    }

    return(ret);
}


/************************************************************************
**      END  finlib09.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifndef DbiBindDataDef_H_
#define DbiBindDataDef_H_

const int INTERNAL_DB      = 1;
const int INTERNAL_FILL    = 2;
const int INTERNAL_BK      = 4;
const int INTERNAL_TREATED = 8;

/* PMSTA-45027 - LJE - 210430 */
class DbiBindDataDef;
class BuildBindOptionGuard;
class BuildBindOption
{
    friend BuildBindOptionGuard;

public:

    enum class Categ
    {
        MdAttribute,
        AllFields,
        MdAttributeBk,
        BusinessKey,
        BusinessKeyOnly,
        BusinessKeyOnlyShort,
        AllMdAttributeBk,
        ExportFullObject,
        ImportFullObject,
        CleanUpFullObject,
        OutboxEvent,
        OutboxEventBusinessKeyOnly,
        FlatBusinessKeyOnly,
        ExportCopyObject,
        Denied,
        NotExported
    };

    enum class Config
    {
        Null,
        Enable,
        Disable
    };

    enum class OutputArtefact
    {
        JSonString,
        File,
        FilePerObject,
        WriteInDb,
        WriteInDbByBatch,
        DelayWrite
    };

    BuildBindOption(Categ optionCategory = Categ::MdAttribute)
        : m_currentExecCtxStp(nullptr)
        , m_rootBuildBindOption(*this)
        , m_currentObjectEn(NullEntity)
        , m_currentDynStEn(NullDynSt)
        , m_currentRecordStp(nullptr)
        , m_currentPckDefStp(nullptr)
        , m_currentFieldIdx(Null_Dynfld)
        , m_currentInitialDVDynStp(nullptr)
        , m_dictEntityStp(nullptr)
        , m_bDescObject(false)
        , m_startDateTime({ 0, 0 })
        , m_processingResultStp(nullptr)
        , m_bProcessingResultLevel(false)
        , m_logLevelEn(ProcessingMessageNatEn::Success)
        , m_bForceStringOnArray(false)
        , m_isPackager(false)
        , m_optionCategory(optionCategory)
        , m_showCustom(Config::Null)
        , m_showPrecomp(Config::Null)
        , m_bPrintNullString(true)
        , m_zipEntryPos(-1)
        , m_outputArtefact(OutputArtefact::JSonString)
    {
        if (optionCategory == Categ::OutboxEvent)
        {
            this->m_showPrecomp = Config::Disable;
        }
    }

    BuildBindOption(const BuildBindOption & ref)
        : m_rootBuildBindOption(ref.m_rootBuildBindOption)
        , m_objectPathMap(ref.m_objectPathMap)
        , m_currentExecCtxStp(ref.m_currentExecCtxStp)
        , m_currentObjectEn(ref.m_currentObjectEn)
        , m_currentDynStEn(ref.m_currentDynStEn)
        , m_currentRecordStp(ref.m_currentRecordStp)
        , m_currentPckDefStp(ref.m_currentPckDefStp)
        , m_currentFieldIdx(ref.m_currentFieldIdx)
        , m_currentInitialDVDynStp(ref.m_currentInitialDVDynStp)
        , m_dictEntityStp(ref.m_dictEntityStp)
        , m_bDescObject(ref.m_bDescObject)
        , m_startDateTime(ref.m_startDateTime)
        , m_processingResultStp(ref.m_processingResultStp)
        , m_bProcessingResultLevel(false)
        , m_logLevelEn(ref.m_logLevelEn)
        , m_bForceStringOnArray(ref.m_bForceStringOnArray)
        , m_isPackager(ref.m_isPackager)
        , m_initialDVDynMap(ref.m_initialDVDynMap)
        , m_entityProfileMap(ref.m_entityProfileMap)
        , m_optionCategory(ref.m_optionCategory)
        , m_exportModeMap(ref.m_exportModeMap)
        , m_outputModeMap(ref.m_outputModeMap)
        , m_exportFiltersMap(ref.m_exportFiltersMap)
        , m_exportSkipMap(ref.m_exportSkipMap)
        , m_exportKeepMap(ref.m_exportKeepMap)
        , m_exportCleanUpMap(ref.m_exportCleanUpMap)
        , m_showCustom(ref.m_showCustom)
        , m_showPrecomp(ref.m_showPrecomp)
        , m_showIdentityMap(ref.m_showIdentityMap)
        , m_bPrintNullString(ref.m_bPrintNullString)
        , m_zipEntryPos(ref.m_zipEntryPos)
        , m_outputArtefact(ref.m_outputArtefact)
    {
    }

    BuildBindOption & operator=(const BuildBindOption &ref)
    {
        this->m_optionCategory  = ref.m_optionCategory;
        if (ref.m_processingResultStp != nullptr)
        {
            this->m_processingResultStp = ref.m_processingResultStp;
        }

        return *this;
    }

    virtual ~BuildBindOption();

    void        sync(const BuildBindOption &ref)
    {
        this->m_initialDVDynMap          = ref.m_initialDVDynMap;
        this->m_exportModeMap            = ref.m_exportModeMap;
        this->m_outputModeMap            = ref.m_outputModeMap;
        this->m_exportFiltersMap         = ref.m_exportFiltersMap;
        this->m_exportKeepMap            = ref.m_exportKeepMap;
        this->m_exportSkipMap            = ref.m_exportSkipMap;
        this->m_exportCleanUpMap         = ref.m_exportCleanUpMap;
        this->m_showCustom               = ref.m_showCustom;
        this->m_showPrecomp              = ref.m_showPrecomp;
        this->m_showIdentityMap          = ref.m_showIdentityMap;
        this->m_bPrintNullString         = ref.m_bPrintNullString;
        this->m_logLevelEn               = ref.m_logLevelEn;
        this->m_bForceStringOnArray      = ref.m_bForceStringOnArray;
        this->m_isPackager               = ref.m_isPackager;
        this->m_defaultEntityProfileCode = ref.m_defaultEntityProfileCode;

        if (ref.m_processingResultStp != nullptr)
        {
            this->m_processingResultStp = ref.m_processingResultStp;
        }
    }

    bool operator==(Categ optionCategory)
    {
        return this->m_optionCategory == optionCategory;
    }

    bool operator!=(Categ optionCategory)
    {
        return this->m_optionCategory != optionCategory;
    }

    const Categ getCateg() const
    {
        return this->m_optionCategory;
    }

    void fixExportCateg(Categ &optionCategory)  const;

    void setObjectEn(OBJECT_ENUM, DbiBindDataDef * = nullptr);

    OBJECT_ENUM getObjectEn() const
    {
        return this->m_currentObjectEn;
    }

    DICT_ENTITY_STP  getDictEntityStp() const
    {
        return this->m_dictEntityStp;
    }

    void setDynStEn(DBA_DYNST_ENUM dynStEn);

    DBA_DYNST_ENUM getDynStEn() const
    {
        return this->m_currentDynStEn;
    }

    void setRecordStp(DBA_DYNFLD_STP);

    DBA_DYNFLD_STP getRecordStp() const
    {
        return this->m_currentRecordStp;
    }

    void setPckDefStp(DBA_DYNFLD_STP);

    DBA_DYNFLD_STP getPckDefStp() const
    {
        return this->m_currentPckDefStp;
    }

    void setFieldIdx(FIELD_IDX_T fieldIdx)
    {
        this->m_currentFieldIdx = fieldIdx;
    }

    FIELD_IDX_T getFieldIdx() const
    {
        return this->m_currentFieldIdx;
    }

    void setInitialDVDynStp(DBA_DYNFLD_STP initialDVDynStp);

    DBA_DYNFLD_STP getInitialDVDynStp() const
    {
        return this->m_currentInitialDVDynStp;
    }

    void setExportMode(OBJECT_ENUM objectEn, EntityConfigExportModeEn exportMode)
    {
        this->m_exportModeMap[objectEn] = exportMode;
    }

    const EntityConfigExportModeEn getExportMode() const
    {
        auto it = this->m_exportModeMap.find(this->getObjectEn());
        if (it != this->m_exportModeMap.end())
        {
            return it->second;
        }
        it = this->m_exportModeMap.find(NullEntity);
        if (it != this->m_exportModeMap.end())
        {
            return it->second;
        }
        return EntityConfigExportModeEn::Standard;
    }

    void setOutputMode(OBJECT_ENUM objectEn, FIELD_IDX_T fieldIdx, EntityConfigOutputModeEn outputMode)
    {
        this->m_outputModeMap[objectEn][fieldIdx] = outputMode;
    }

    const EntityConfigOutputModeEn getOutputMode(OBJECT_ENUM objectEn = NullEntity) const
    {
        auto it = this->m_outputModeMap.find(objectEn == NullEntity ? this->getObjectEn() : objectEn);
        if (it != this->m_outputModeMap.end())
        {
            auto it2 = it->second.find(this->getFieldIdx());
            if (it2 != it->second.end())
            { 
                return it2->second;
            }

            if (this->getFieldIdx() != Null_Dynfld)
            {
                it2 = it->second.find(Null_Dynfld);
                if (it2 != it->second.end())
                {
                    return it2->second;
                }
            }
        }
        it = this->m_outputModeMap.find(NullEntity);
        if (it != this->m_outputModeMap.end())
        {
            auto it2 = it->second.find(Null_Dynfld);
            if (it2 != it->second.end())
            {
                return it2->second;
            }
        }
        return EntityConfigOutputModeEn::Standard;
    }

    const bool isPrintNull() const
    {
        if (this->getExportMode() == EntityConfigExportModeEn::NotNull ||
            this->getExportMode() == EntityConfigExportModeEn::NotNullOnly)
        {
            return false;
        }
        return true;
    }

    const bool isImportExport() const
    {
        if (this->isExport() ||
            this->m_optionCategory == Categ::ImportFullObject)
        {
            return true;
        }
        return false;
    }

    static const bool isExportCateg(Categ optionCategory)
    {
        if (optionCategory == Categ::ExportFullObject ||
            optionCategory == Categ::ExportCopyObject ||
            optionCategory == Categ::CleanUpFullObject ||
            optionCategory == Categ::OutboxEvent)
        {
            return true;
        }
        return false;
    }

    const bool isExport() const
    {
        if (isExportCateg(this->m_optionCategory))
        {
            return true;
        }
        return false;
    }

    const bool isBusinessKey() const
    {
        if (this->m_optionCategory == Categ::BusinessKey ||
            this->m_optionCategory == Categ::BusinessKeyOnly ||
            this->m_optionCategory == Categ::BusinessKeyOnlyShort ||
            this->m_optionCategory == Categ::FlatBusinessKeyOnly ||
            this->m_optionCategory == Categ::OutboxEventBusinessKeyOnly)
        {
            return true;
        }

        return false;
    }
    const bool isBusinessKeyOnly() const
    {
        if (this->m_optionCategory == Categ::BusinessKeyOnly ||
            this->m_optionCategory == Categ::BusinessKeyOnlyShort ||
            this->m_optionCategory == Categ::FlatBusinessKeyOnly ||
            this->m_optionCategory == Categ::OutboxEventBusinessKeyOnly)
        {
            return true;
        }

        return false;
    }

    const bool showSpecialAttributes() const
    {
        if (this->isImportExport())
        {
            return false;
        }
        return true;
    }

    const bool showPrecompAttributes() const
    {
        switch (this->m_showPrecomp)
        {
            case Config::Enable:
                return true;
                break;

            case Config::Disable:
                return false;
                break;

            case Config::Null:
            default:
                if (this->isImportExport())
                {
                    return false;
                }
                return true;
                break;
        }
    }

    const bool showCustomAttributes() const
    {
        switch (this->m_showCustom)
        {
            case Config::Enable:
                return true;
                break;

            case Config::Disable:
                return false;
                break;

            case Config::Null:
            default:
                return true;
                break;
        }
    }

    const bool showIdentity() const;

    const bool showLogicalAttributes() const
    {
        if (this->isImportExport() &&
            this->m_optionCategory != Categ::OutboxEvent)
        {
            return true;
        }
        return false;
    }

    const bool showCalculatedAttributes() const
    {
        if (this->isImportExport())
        {
            return false;
        }
        return true;
    }

    const bool printNameOfEnum() const
    {
        if (this->isImportExport() || this->isBusinessKey())
        {
            return true;
        }
        return false;
    }

    const bool printStringOnArray() const
    {
        if (this->isImportExport())
        {
            return true;
        }
        return false;
    }

    const bool isForceStringOnArray() const;
    void       setForceStringOnArray(bool bForceStringOnArray)
    {
        this->m_bForceStringOnArray = bForceStringOnArray;
    }

    void setPrintNullString(bool bPrintNullString)
    {
        this->m_bPrintNullString = bPrintNullString;
    }

    const bool isPackager() const
    {
        return this->m_isPackager;
    }
    void       setPackager()
    {
        this->m_isPackager = true;
    }

    const bool printNullString() const
    {
        return this->m_bPrintNullString;
    }

    static void fixJSonString(std::string &);

    DBA_DYNFLD_STP getEntityProfileStp()
    {
        return this->m_entityProfileMap[0];
    }

    Categ       getBusinessKeyOnlyCateg() const;
    Categ       getExportFullCateg() const;

    bool        printBkOfReference() const;
    bool        printAllRecord() const;
    bool        isVisible(DBA_DYNFLD_STP, bool);
    bool        isToDelete(DBA_DYNFLD_STP, bool = true) const;
    bool        isToModify(DBA_DYNFLD_STP) const;
    void        fillConfig(DBA_DYNFLD_STP);
    void        setConfig(const std::string&, const std::string &, const std::string &, EntityConfigElementRuleEn);
    void        clearConfig();
    void        generateEntityConfig(DICT_T, DBA_DYNFLD_STP);

    const bool  rootStartByArray() const;
    const bool  forceArrayFirstObject() const;
    const bool  usePrettyWritter() const;

    std::string getFilter(const std::string &, const std::string &) const;
    bool        getKeep(const std::string &, const std::string &, std::string &) const;
    bool        getSkip(const std::string &, const std::string &, std::string &) const;
    bool        getCleanUp(const std::string &, const std::string &, std::string &) const;
    bool        isCleanUpProvidedOnly(OBJECT_ENUM);
    bool        isAuto(const std::string&, const std::string&) const;

    void        setOutputArtefact(OutputArtefact outputArtefact);
    void        setFilePathInfo(const std::string &, const std::string &, int = -1);

    OutputArtefact getOutputArtefact()
    {
        return this->m_outputArtefact;
    }

    std::string    getFullFileName()
    {
        return this->m_rootPath + this->m_fileName;
    }

    std::string    getFileName()
    {
        return this->m_fileName;
    }

    std::string    getRootPath()
    {
        return this->m_rootPath;
    }

    static bool    isZipFileType(std::string);
    bool           isZipFile();
    bool           isZipZipFile();
    int            getZipEntryPos()
    {
        return this->m_zipEntryPos;
    }

    void setDefaultEntityProfileCode(const std::string &defaultEntityProfileCode)
    {
        this->m_defaultEntityProfileCode = defaultEntityProfileCode;
    }

    std::string    getDefaultEntityProfileCode()
    {
        return this->m_defaultEntityProfileCode;
    }

    bool           isExportedAttrib(DictAttribClass *, DBA_DYNFLD_STP, BuildBindOption::Categ &) const;
    bool           isExportedLogicalAttrib(DictAttribClass *, DBA_DYNFLD_STP, std::string &, BuildBindOption::Categ &);

    void           start();
    void           printMsg(ProcessingMessageNatEn, INT_T, const std::string &, bool = false);
    DBA_DYNFLD_STP finish(RET_CODE);

    void           setDescObject(bool bDescObject)
    {
        this->m_bDescObject = bDescObject;
    }
    bool           getDescObject()
    {
        return this->m_bDescObject;
    }

    void               setLogLevel(ProcessingMessageNatEn logLevelEn)
    {
        this->m_logLevelEn = logLevelEn;
    }
    ProcessingMessageNatEn getLogLevel()
    {
        return this->m_logLevelEn;
    }


    std::map<OBJECT_ENUM, std::set<ID_T>> m_objectPathMap;
    DBA_DYNFLD_STP                        m_currentExecCtxStp;

protected:
    BuildBindOption&                      m_rootBuildBindOption;

    OBJECT_ENUM                           m_currentObjectEn;
    DBA_DYNST_ENUM                        m_currentDynStEn;
    DBA_DYNFLD_STP                        m_currentRecordStp;
    DBA_DYNFLD_STP                        m_currentPckDefStp;
    FIELD_IDX_T                           m_currentFieldIdx;
    DBA_DYNFLD_STP                        m_currentInitialDVDynStp;

    DICT_ENTITY_STP                       m_dictEntityStp;

    bool                                  m_bDescObject;
    DATETIME_T                            m_startDateTime;
    DBA_DYNFLD_STP                        m_processingResultStp;
    bool                                  m_bProcessingResultLevel;
    ProcessingMessageNatEn                    m_logLevelEn;
    bool                                  m_bForceStringOnArray;
    bool                                  m_isPackager;

    std::map<std::string, DBA_DYNFLD_STP> m_initialDVDynMap;

    std::map<ID_T, DBA_DYNFLD_STP>        m_entityProfileMap;

    std::set<OBJECT_ENUM>                 m_cleanUpProvidedOnlyObjectSet;

    MemoryPool                            m_mp;

private:

    void        setFilter(const std::string &, const std::string &, const std::string &);
    void        setKeep(const std::string &, const std::string &, const std::string &);
    void        setSkip(const std::string &, const std::string &, const std::string &);
    void        setCleanUp(const std::string &, const std::string &, const std::string &);

    Categ                                                                   m_optionCategory;
    std::map<OBJECT_ENUM, EntityConfigExportModeEn>                         m_exportModeMap;
    std::map<OBJECT_ENUM, std::map<FIELD_IDX_T, EntityConfigOutputModeEn>>  m_outputModeMap;

    Config                                                                  m_showCustom;
    Config                                                                  m_showPrecomp;
    std::map<OBJECT_ENUM, Config>                                           m_showIdentityMap;

    bool                                                                    m_bPrintNullString;

    OutputArtefact                                                          m_outputArtefact;
    std::string                                                             m_rootPath;
    std::string                                                             m_fileName;
    int                                                                     m_zipEntryPos;
    std::string                                                             m_defaultEntityProfileCode;

    std::map<std::string, std::map<std::string, std::string>> m_exportFiltersMap;
    std::map<std::string, std::map<std::string, std::string>> m_exportKeepMap;
    std::map<std::string, std::map<std::string, std::string>> m_exportSkipMap;
    std::map<std::string, std::map<std::string, std::string>> m_exportCleanUpMap;
    std::map<std::string, std::set<std::string>>              m_exportAutoMap;
};

class BuildBindOptionGuard
{
public:

    BuildBindOptionGuard(BuildBindOption& buildBindOption)
        : m_buildBindOption(buildBindOption)
        , m_savedCateg(buildBindOption.getCateg())
        , m_savedOutputArtefact(buildBindOption.getOutputArtefact())
        , m_savedObjectEn(buildBindOption.getObjectEn())
        , m_savedDynStEn(buildBindOption.getDynStEn())
        , m_savedRecordStp(buildBindOption.getRecordStp())
        , m_savedFieldPos(buildBindOption.getFieldIdx())
        , m_savedInitialDVDynStp(buildBindOption.getInitialDVDynStp())
        , m_savedRootPath(buildBindOption.getRootPath())
        , m_savedFileName(buildBindOption.getFileName())
        , m_savedPckDefStp(buildBindOption.getPckDefStp())
        , m_savedObjectPathMap(buildBindOption.m_objectPathMap)
    {
    }

    virtual ~BuildBindOptionGuard()
    {
        this->m_buildBindOption.setObjectEn(this->m_savedObjectEn);
        this->m_buildBindOption.setDynStEn(this->m_savedDynStEn);
        this->m_buildBindOption.setRecordStp(this->m_savedRecordStp);
        this->m_buildBindOption.setPckDefStp(this->m_savedPckDefStp);
        this->m_buildBindOption.setFieldIdx(this->m_savedFieldPos);

        this->m_buildBindOption                          = this->m_savedCateg;
        this->m_buildBindOption.m_outputArtefact         = this->m_savedOutputArtefact;
        this->m_buildBindOption.m_currentInitialDVDynStp = this->m_savedInitialDVDynStp;
        this->m_buildBindOption.m_rootPath               = this->m_savedRootPath;
        this->m_buildBindOption.m_fileName               = this->m_savedFileName;
        this->m_buildBindOption.m_objectPathMap          = this->m_savedObjectPathMap;
    }

private:
    BuildBindOption&                m_buildBindOption;

    BuildBindOption::Categ          m_savedCateg;
    BuildBindOption::OutputArtefact m_savedOutputArtefact;
    OBJECT_ENUM                     m_savedObjectEn;
    DBA_DYNST_ENUM                  m_savedDynStEn;
    DBA_DYNFLD_STP                  m_savedRecordStp;
    FIELD_IDX_T                     m_savedFieldPos;
    DBA_DYNFLD_STP                  m_savedInitialDVDynStp;
    std::string                     m_savedRootPath;
    std::string                     m_savedFileName;
    DBA_DYNFLD_STP                  m_savedPckDefStp;

    std::map<OBJECT_ENUM, std::set<ID_T>> m_savedObjectPathMap;
};

class DbiInOutData;
class DbiBindData
{
public:
    DbiBindData()
        : m_columnNbr(Null_Dynfld)
        , m_dataType(NullDataType)
        , m_dataLength(nullptr)
        , m_nullValue(nullptr)
        , m_dataIn(nullptr)
        , m_inOutDynStPos(Null_Dynfld)
        , m_bindDynStPos(Null_Dynfld)
        , m_bDynFld(false)
        , m_nullIndicatorDynFld(nullptr)
        , m_allocSize(0)
        , m_attribStp(nullptr)
        , m_dbiInOutDataPtr(nullptr)
    {
    }

    DbiBindData(const DbiBindData& ref): DbiBindData()
    {
        *this = ref;
    }

    DbiBindData& operator=(const DbiBindData& ref)
    {
        this->m_columnName          = ref.m_columnName;
        this->m_columnNbr           = ref.m_columnNbr;
        this->m_dataType            = ref.m_dataType;
        this->m_dataLength          = ref.m_dataLength;
        this->m_nullValue           = ref.m_nullValue;
        this->m_dataIn              = ref.m_dataIn;
        this->m_inOutDynStPos       = ref.m_inOutDynStPos;
        this->m_bindDynStPos        = ref.m_bindDynStPos;
        this->m_bDynFld             = ref.m_bDynFld;
        this->m_nullIndicatorDynFld = ref.m_nullIndicatorDynFld;
        this->m_allocSize           = ref.m_allocSize;
        this->m_attribStp           = ref.m_attribStp;
        this->m_dbiInOutDataPtr     = ref.m_dbiInOutDataPtr;

        return *this;
    }

    std::string       m_columnName;
    int               m_columnNbr;
    DATATYPE_ENUM     m_dataType;
    DBI_INT* m_dataLength;
    SMALLINT_T* m_nullValue;
    void* m_dataIn;
    FIELD_IDX_T       m_inOutDynStPos;
    FIELD_IDX_T       m_bindDynStPos;
    bool              m_bDynFld;
    unsigned char* m_nullIndicatorDynFld;
    size_t            m_allocSize;
    DICT_ATTRIB_STP   m_attribStp;
    DbiInOutData* m_dbiInOutDataPtr;
};

class DbiBindDataDef
{
public:
    DbiBindDataDef()
        : rowsSentNbr(0)
        , bindObjectEn(InvalidEntity)
        , bindDynStEn(InvalidDynSt)
        , inOutObjectEn(InvalidEntity)
        , inOutDynStEn(InvalidDynSt)
        , m_usage(Usage::Standard)
        , m_dictEntityStp(nullptr)
    {
    }

    DbiBindDataDef(const DbiBindDataDef &ref)
        : DbiBindDataDef()
    {
        *this = ref;
    }

    DbiBindDataDef& operator= (const DbiBindDataDef& toCopy)
    {
        this->rowsSentNbr       = toCopy.rowsSentNbr;
        this->bindObjectEn      = toCopy.bindObjectEn;
        this->bindDynStEn       = toCopy.bindDynStEn;
        this->inOutObjectEn     = toCopy.inOutObjectEn;
        this->inOutDynStEn      = toCopy.inOutDynStEn;
        this->m_usage           = toCopy.m_usage;
        this->m_dictEntityStp   = toCopy.m_dictEntityStp;
        this->m_buildBindOption = toCopy.m_buildBindOption;
        this->bindData          = toCopy.bindData;

        return *this;
    }

    enum class Usage
    {
        Standard,
        DbInOut,
        OutputParam,
        ImportExport
    };

    void clear()
    {
        this->bindData.clear();

        this->bindObjectEn      = InvalidEntity;
        this->bindDynStEn       = InvalidDynSt;
        this->inOutObjectEn     = InvalidEntity;
        this->inOutDynStEn      = InvalidDynSt;
        this->m_usage           = Usage::Standard;
        this->m_dictEntityStp   = nullptr;
        this->m_buildBindOption = BuildBindOption::Categ::MdAttribute;
        this->rowsSentNbr       = 0;
    }

    void init(const DbiBindDataDef& toCopy)
    {
        this->clear();

        this->bindObjectEn         = toCopy.bindObjectEn;
        this->bindDynStEn          = toCopy.bindDynStEn;
        this->inOutObjectEn        = toCopy.inOutObjectEn;
        this->inOutDynStEn         = toCopy.inOutDynStEn;
        this->m_usage              = toCopy.m_usage;
        this->m_dictEntityStp      = toCopy.m_dictEntityStp;
        this->m_buildBindOption    = toCopy.m_buildBindOption;
    }

    inline FIELD_IDX_T getDynStPos(const DBA_DYNFLD_STP dynStp, const DbiBindData &paramBindData)
    {
        if (dynStp == nullptr)
        {
            return paramBindData.m_bindDynStPos;
        }
        return (this->inOutDynStEn == dynStp->dynStEnum && paramBindData.m_inOutDynStPos != Null_Dynfld ? paramBindData.m_inOutDynStPos : paramBindData.m_bindDynStPos);
    }

    size_t                    rowsSentNbr;
                              
    OBJECT_ENUM               bindObjectEn;
    DBA_DYNST_ENUM            bindDynStEn;
                              
    OBJECT_ENUM               inOutObjectEn;
    DBA_DYNST_ENUM            inOutDynStEn;
                              
    Usage                      m_usage;

    /* PMSTA-46259 - LJE - 211008 */
    DICT_ENTITY_STP            m_dictEntityStp;
    BuildBindOption            m_buildBindOption;

    std::map<int, DbiBindData> bindData;
};

#endif

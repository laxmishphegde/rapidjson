/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "proc.h"
#include "dbi.h"

#include "conv.h"

#include "oralib.h"
#include "syslib.h"
#include "conexcept.h"

#include "crypt.h"
#include <stdarg.h>
#include "conallocator.h"
#include "sybconnection.h"
#include "oraconnection.h"
#ifdef NUODB_ENABLE
#include "nuodblib.h"
#include "nuodbconnection.h"
#endif
#ifdef MSDB_ENABLE
#include "odbcconnection.h"
#endif
#ifdef POSTGRESQL_ENABLE
#include "libpq-fe.h"
#include "pgsconnection.h"
#include "pgslib.h"
#endif
#include "json.h"
#include "httpclient.h"
#include "httpconnection.h"

#include "sqliteconnection.h"
#include "sqlitelib.h"

#include "conprovider.h"
#include "ddlgen.h"

#include "httplib.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

using namespace std;

extern int EV_AAAInstallLevel;
extern bool EV_UseOneConnection;

extern std::string    EV_SourceDataSource;
extern std::string    EV_TargetDataSource;

extern CODE_T EV_DbTimeZoneCd; /* PMSTA-43454 - DDV - 210128 */


/************************************************************************
*   Function             : copyDbaErrMsgHeaderClassObject()
*
*   Description          : Deep Copying DbaErrmsgHeaderClass members
*
*   Arguments            : Copy of DbaErrmsgHeaderClass
*
*   Return               : None
*
*   Creation Date        : 040722
*
*   Last Modif           : PMSTA-49780- BSV- 040722
*
*************************************************************************/
void DbaErrmsgHeaderClass::copyDbaErrMsgHeaderClassObject(const DbaErrmsgHeaderClass &copyFrom)
{
    this->startPos = copyFrom.startPos;

    this->msgStructTab.reserve(copyFrom.msgStructTab.size());
    for (auto it = copyFrom.msgStructTab.begin(); it != copyFrom.msgStructTab.end(); it++)
    {
        this->msgStructTab.push_back(*it);
    }

    if (copyFrom.autoRefRecPtr != nullptr)
    {
        this->autoRefRecPtr = ALLOC_DYNST(GET_DYNSTENUM(copyFrom.autoRefRecPtr));
        COPY_DYNST(this->autoRefRecPtr, copyFrom.autoRefRecPtr, GET_DYNSTENUM(this->autoRefRecPtr));
    }

    for (size_t i = 0; i < copyFrom.autoInputCtrlMsgTab.size(); i++)
    {
        this->autoInputCtrlMsgTab[i] = ALLOC_DYNST(GET_DYNSTENUM(copyFrom.autoInputCtrlMsgTab[i]));
        COPY_DYNST(this->autoInputCtrlMsgTab[i], copyFrom.autoInputCtrlMsgTab[i], GET_DYNSTENUM(copyFrom.autoInputCtrlMsgTab[i]));
    }
}
/************************************************************************
*   Function             : freeDbaErrMsgHeaderClassMemory()
*
*   Description          : This function will free the DbaErrmsgHeaderClass object
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 040722
*
*   Last Modif           : PMSTA-49780- BSV- 040722
*
*************************************************************************/
void DbaErrmsgHeaderClass::freeDbaErrMsgHeaderClassMemory() {

    for (size_t i = 0; i < this->autoInputCtrlMsgTab.size(); i++)
    {
        FREE_DYNST(this->autoInputCtrlMsgTab[i], GET_DYNSTENUM(this->autoInputCtrlMsgTab[i]));
    }
    if (autoRefRecPtr != nullptr)
    {
        FREE_DYNST(this->autoRefRecPtr, GET_DYNSTENUM(this->autoRefRecPtr));
    }
    clear();
}


/************************************************************************
*   Function             : DBI_GetSqlServerNameByRdbms()
*
*   Description          : Return the application server name
*
*   Arguments            :
*
*   Return               : The pointer of the SQL server name char.
*
*   Creation Date        : PMSTA-nuodb - LJE - 190412
*
*   Last Modif           :
*
*************************************************************************/
const string DBI_GetSqlServerNameByRdbms(DBA_RDBMS_ENUM rdbmsEn, bool bTargetDataSource)
{
    const char * tmp = nullptr;

    if (bTargetDataSource == false && 
        EV_SourceDataSource.empty() == false)
    {
        return EV_SourceDataSource;
    }
    else if (bTargetDataSource == true &&
             EV_TargetRdbmsVendor == rdbmsEn &&
             EV_TargetDataSource.empty() == false)
    {
        return EV_TargetDataSource;
    }
    else if (rdbmsEn == Oracle)
    {
        if ((tmp = SYS_GetEnv("AAATNSNAME")) != nullptr)
        {
            return tmp;
        }
    }
    else if (rdbmsEn == MSSql)
    {
        if ((tmp = SYS_GetEnv("AAADSNNAME")) != nullptr)
        {
            return tmp;
        }
    }

    tmp = SYS_GetEnv("DSQUERY");

    if (tmp != nullptr)
    {
        return tmp;
    }
    else
    {
        return "Unknown";
    }
}


/************************************************************************
*   Function             : DBI_GetSqlServerName()
*
*   Description          : Return the application server name
*
*   Arguments            :
*
*   Return               : The pointer of the SQL server name char.
*
*   Creation Date        : PMSTA-18593 - LJE - 150901
*
*   Last Modif           : PMSTA-41113 - KNI - 270720
*
*************************************************************************/
const string &DBI_GetSqlServerName(std::string srvNameFrmDB)
{
    static std::string dsQuery;

    if (srvNameFrmDB.empty())
    {
        if (dsQuery.empty())
        {
            GEN_GetApplInfo(ApplSqlServerName, dsQuery);

            if (dsQuery.empty())
            {
                dsQuery = DBI_GetSqlServerNameByRdbms(EV_RdbmsVendor, true);
            }

            if (dsQuery.empty() == false)
            {
                GEN_SetApplInfo(ApplSqlServerName, dsQuery.c_str());
            }
        }
    }
    else
        dsQuery = srvNameFrmDB;

    return dsQuery;
}

static std::set<DBA_RDBMS_ENUM> SV_rdbmsToLoad;

/************************************************************************
*   Function             : DBI_InitializeContext()
*
*   Description          : Allocate an application context, install
*                          message handlers and conversion functions for
*                          dates fields.
*
*   Arguments            : installMemoryCallBack    If Sybase memory callback must be installed
*
*   Functions call       : None
*
*   Last modif.          : PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*
*************************************************************************/
RET_CODE DBI_InitializeContext(const bool installMemoryCallBack)
{
    RET_CODE ret = RET_GEN_ERR_WRONG_VERSION;

    /* PMSTA-nuodb - LJE - 190411 */
    SV_rdbmsToLoad.insert(EV_RdbmsVendor);
    SV_rdbmsToLoad.insert(EV_SourceRdbmsVendor);
    SV_rdbmsToLoad.insert(EV_TargetRdbmsVendor);
    SV_rdbmsToLoad.insert(QtHttp);

    if (EV_RdbmsVendor != Sybase) /* DLA - PMSTA-24721 - 190916 */
    {
        if (SYS_GetEnvBoolOrDefValue("LOAD_SYBASE_CONTEXT", false))
        {
            SV_rdbmsToLoad.insert(Sybase);
        }
    }

    for (auto it = SV_rdbmsToLoad.begin(); it != SV_rdbmsToLoad.end(); ++it)
    {
        AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SqlServer, *it, DBI_GetConnAllocatorPtr(SqlServer, *it));

        switch (*it)
        {
            case Sybase:
                if (SYS_LoadLibraryContext(Sybase) == true)
                {
                    if ((ret = SYB_InitializeContext(installMemoryCallBack)) != RET_SUCCEED)
                    { /* Error */
                        MSG_SendMesg(FILEINFO, "Sybase Initialization Context Error");
                    }
                }
                break;

            case Oracle:
                if (SYS_LoadLibraryContext(Oracle) == true)
                {
                    if ((ret = ORA_InitializeContext(installMemoryCallBack)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(FILEINFO, "Oracle Initialization Context Error");
                    }
                }
                break;
#ifdef NUODB_ENABLE
            case Nuodb:
                if (SYS_LoadLibraryContext(Nuodb) == true)
                {
                    if ((ret = NUODB_InitializeContext(installMemoryCallBack)) != RET_SUCCEED)
                    { /* Error */
                        MSG_SendMesg(FILEINFO, "NuoDB Initialization Context Error");
                    }
                }
                break;
#endif
            case QtHttp:
                /* PMSTA-34344 - TEB - 190319 */
                ret = RET_SUCCEED;
                break;

#ifdef MSDB_ENABLE
            case MSSql:
                (void)SYS_LoadLibraryContext(MSSql);
                break; 

#endif
            case Sqlite:
                if (SYS_LoadLibraryContext(Sqlite) == true)
                {
                    if ((ret = SQLITE_InitializeContext(installMemoryCallBack)) != RET_SUCCEED)
                    { /* Error */
                        MSG_SendMesg(FILEINFO, "Sqlite Initialization Context Error");
                    }
                }
                break;

#ifdef POSTGRESQL_ENABLE
            case PostgreSQL:
                if (SYS_LoadLibraryContext(PostgreSQL) == true)
                {
                    if ((ret = PGS_InitializeContext()) != RET_SUCCEED)
                    { /* Error */
                        MSG_SendMesg(FILEINFO, "PostgreSQL Initialization Context Error");
                    }
                }
                break;

#endif
            default:
                break;
        }
    }

    AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(FinServer, QtHttp, DBI_GetConnAllocatorPtr(FinServer, QtHttp));
    AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(DispatchServer, QtHttp, DBI_GetConnAllocatorPtr(FinServer, QtHttp));
    AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SqlServer, QtHttp, DBI_GetConnAllocatorPtr(SqlServer, QtHttp));         /* TO DELETE should be done by config with upper line  */ /* PMSTA-34344 - TEB - 190805 */
    AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SqlServer, Sqlite, DBI_GetConnAllocatorPtr(SqlServer, Sqlite));

    return ret;
}

/************************************************************************
*   Function             : DBI_FreeContext()
*
*   Description          : 
*
*   Arguments            : 
*
*   Functions call       : None
*
*   Last modif.          : PMSTA-37366 - LJE - 200831
*
*************************************************************************/
void DBI_FreeContext()
{
    for (auto it = SV_rdbmsToLoad.begin(); it != SV_rdbmsToLoad.end(); ++it)
    {
        AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SqlServer, *it, DBI_GetConnAllocatorPtr(SqlServer, *it));

        switch (*it)
        {
            case Oracle:
                ORA_FreeContext();
                break;

            default:
                break;
        }
    }
}

/************************************************************************
*   Function             : DBI_GetDbDateOnServer()
*
*   Description          :
*
*
*   Return               : RET_SUCCEED               : if ok
*                          RET_DBA_ERR_CONNOTFOUND   : if no free connection found
*
*   Creation Date        :
*   Last Modification    :
*************************************************************************/
RET_CODE DBI_GetDbDateOnServer(DATETIME_STP datetimeStp, DbiConnection& dbiConn)
{
    try
    {
        DbiConnectionHelper dbiConnHelper(&dbiConn, false);
        if (dbiConnHelper.isValidAndInit())
        {
            RequestHelper requestHelper(dbiConnHelper);
            requestHelper.setReadOnly(true);

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.GetDbDate";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            DATETIME64_STP datetimePtr = nullptr;

            requestHelper.setCommand("select #GETDATETIME" + DdlGen::getEmptyFrom(dbiConn.m_connectToRDBMS));     /* PMSTA-34344 - TEB - 190805 */
            requestHelper.addNewOutputData(DatetimeType);
            requestHelper.getBindVariablePtr(datetimePtr);

            if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
            {
                *datetimeStp = datetimePtr->dateTime();
            }
        }
    }
    catch (exception&)
    {
        return RET_DBA_ERR_DBPROBLEM;
    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GimmeNetRunning()
*
*   Description          : Retrieve running processes corresponding to
*                          the given string from Sybase.
*
*   Arguments            : An application name.
*                          Modules.
*
*   Functions call       :
*
*   Return               : RET_SUCCEED           : if ok.
*                          DBA_CONN_NOT_FOUND    : if connection failed.
*                          RET_DBA_ERR_DBPROBLEM : if problem with sybase.
*                          RET_GEN_ERR_INVARG    : if application name null.
*
*   Creation Date        : 01.04.1997: GRD - DVP404.
*   Last Modif           : 14.12.1998: GRD - REF3073.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*************************************************************************/
RET_CODE DBI_GimmeNetRunning(const char	*appName,		/* Application name to spy. *//* REF8728 - YST - 030218 */
    short	*netCoreNb,
    short	*netProdModNb,
    short	*netAttribModNb,
    short	*netRiskModNb,
    short	*netAccModNb,
    short	*netFundModNb,
    short	*netCorpActionsModNb,
    short	*netAdvAnalyticsModNb,
    short	*netCompManagementModNb,
    short	*netExcelReportModNb,
    short	*netRAModNb,
    short	*netACMModNb,
    short	*netOMModNb)
{
    RET_CODE ret = RET_SUCCEED;
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        ret = SYB_GimmeNetRunning(appName,
            netCoreNb,
            netProdModNb,
            netAttribModNb,
            netRiskModNb,
            netAccModNb,
            netFundModNb,
            netCorpActionsModNb,
            netAdvAnalyticsModNb,
            netCompManagementModNb,
            netExcelReportModNb,
            netRAModNb,
            netACMModNb,
            netOMModNb);
    }
    return ret;
}

/************************************************************************
*   Function             : DBI_SetGeneralCharset()
*
*   Description          :
*
*   Arguments            : currentCharsetCode : a valid charset code.
*
*   Return               : RET_SUCCEED        : if no problem was detected
*
*   Creation Date        : PMSTA-nuodb - LJE - 190501
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBI_SetGeneralCharset(CURRENTCHARSETCODE_ENUM currentCharsetCode)
{
    switch (EV_RdbmsVendor)
    {
        case Sybase:
            return SYB_SetGeneralCharset(currentCharsetCode);

        /* PMSTA-51352 - LJE - 230814 */
        case Oracle:
        case QtHttp:
            break;

        default:
            GEN_SetApplInfo(ApplDbCommCharsetCodeEnum, &currentCharsetCode);
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBI_InsertPasswdHistory()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*
*   Last Modif           : PMSTA-10235 - 190710 - PMO : Upgrade MD5 with new Salted H MD5 for password encryption for OCS and Triple'A
*************************************************************************/
int DBI_InsertPasswdHistory(SYSNAME_T user_code, PasswordEncrypted& password, DbiConnectionHelper& dbiConnHelper) /* DLA - PMSTA09887 - 101115 */
{

    char		userName[MAX_USERINFO_LEN + 1];		/* VST 020927 REF7950 */

    char       *pMD5Password = NULL;
    char    *pSHA256Password = NULL;
    char *pMD5SaltedPassword = NULL;

    {
        SYSNAME_T szPassword; /* DLA - PMSTA-21596 - 160519 */
        AUTO_PASSWORD_CLEAR(szPassword, sizeof(szPassword));

        strcpy(szPassword, password.getClearPassword().getPassword());

        _CRYPT_HashMD5(szPassword, &pMD5Password);
        _CRYPT_HashSHA256(szPassword, &pSHA256Password);
        _CRYPT_HashMD5Salted(szPassword, pSHA256Password, &pMD5SaltedPassword);
    }

    char *                      passwordDigested;                               /* PMSTA-10235 - 190710 - PMO */
    int                         iApplPasswordHashAlgorithm;                     /* PMSTA-10235 - 190710 - PMO */
    char                        szAlgo[2];                                      /* PMSTA-10235 - 190710 - PMO */
    GEN_GetApplInfo(ApplPasswordHashAlgorithm, &iApplPasswordHashAlgorithm);    /* PMSTA-10235 - 190710 - PMO */
    CRYPTMETHOD_ENUM   applPasswordHashAlgorithm = (CRYPTMETHOD_ENUM)iApplPasswordHashAlgorithm;                      /* PMSTA-10235 - 190710 - PMO */

    switch (applPasswordHashAlgorithm)
    {
    case CryptMethod_SALTED_MD5:
        passwordDigested = pMD5SaltedPassword;
        snprintf(szAlgo, sizeof(szAlgo), "%c", PREFIX_ALGO_USED_ENUM::SALTED_MD5);
        break;

    case CryptMethod_SHA256:
        passwordDigested = pSHA256Password;
        snprintf(szAlgo, sizeof(szAlgo), "%c", PREFIX_ALGO_USED_ENUM::SHA256);
        break;

    case CryptMethod_MD5:
    default:
        passwordDigested = pMD5Password;
        szAlgo[0] = 0;
        break;
    }

    RequestHelper requestHelper(dbiConnHelper);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        sqlTrace.m_procedure = "DynSql.InsPasswordHistory";
    }

    requestHelper.setCommand("#EXEC ins_appl_pwd_hist_by_cd ?, ?, ?");
    requestHelper.addNewParamCharPtr(user_code, SysnameType);
    requestHelper.addNewParamString(string(szAlgo) + passwordDigested, String1000Type);

    GEN_GetUserInfo(UserLogin, userName);   /* PMSTA-43741 - LJE - 210406 */

    if (strcmp(user_code, userName) != 0)
    {
        /* When changing password for another user put validity date at today VST-020927-REF7950 */
        requestHelper.addNewParamUChar(UCHAR_T(1));
    }
    else
    {
        requestHelper.addNewParamUChar(UCHAR_T(0));
    }
    RET_CODE ret = requestHelper.sendAndGetCommand();

    FREE(      pMD5Password);
    FREE(   pSHA256Password);
    FREE(pMD5SaltedPassword);

    return ret;
}
/************************************************************************
*   Function             : DBI_InsertPasswdHistory()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           : REF5010 - SSO - 000828
*************************************************************************/
int DBI_CheckExpiredPassword()
{
    DbiConnectionHelper dbiConnHelper;
    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.CheckExpiredPassword";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("#EXEC chk_validity_d ?");

    DbiInOutData *returnStatusParam = requestHelper.addNewParamInt(10);
    returnStatusParam->m_bInput     = false;
    returnStatusParam->m_bOutput    = true;

    requestHelper.sendAndGetCommand();

    return(GET_INT(returnStatusParam->getDynFldStp(), 0));
}

/************************************************************************
*   Function             : DBI_CheckMaxRunningGui()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           :
*************************************************************************/
int DBI_CheckMaxRunningGui()
{
    DbiConnectionHelper dbiConnHelper;
    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.CheckMaxRunningGui";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    (void) requestHelper.addNewParamInt(dbiConnHelper.isHttp() == true ? INT_T(1) : INT_T(0));
    DbiInOutData *returnStatusParam = requestHelper.addNewParamInt(10);
    returnStatusParam->m_bInput     = false;
    returnStatusParam->m_bOutput    = true;

    requestHelper.setCommand("#EXEC chk_max_running_gui ?, ?");
    requestHelper.sendAndGetCommand();

    return(GET_INT(returnStatusParam->getDynFldStp(), 0));
}

/************************************************************************
*   Function             : DBA_CleanLoginFailed()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           :
*************************************************************************/
int DBI_CleanLoginFailed()
{
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);
    RequestHelper       requestHelper(dbiConnHelper);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.CleanLoginFailed";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("#EXEC #AAALOGIN_DB.del_login_failed");

    if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
    {
        return TRUE;
    }

    return FALSE;
}

/************************************************************************
*   Function             : DBI_SetDateApplInfo()
*
*   Description          : Format the date and call GEN_SetApplInfo
*
*   Arguments            : applInfo     Parameter to set
*                          value_n      Value that contain the date
*
*   Return               : None
*
*   Creation date        : REF10256 - 040608 - PMO : Switch from old Fusion
*                          Date Rule to new Fusion Date Rule at the Fusion Switch Date
*
*   Last Modif Date      :
*
***************************************************************************/
void DBI_SetDateApplInfo(const GEN_APPLINFO_ENUM applInfo, INFO_T value)
{
    DATETIME_T     datetime;
    DATE_FORMAT_ST format;

    if (value[0] != END_OF_STRING)
    {
        format.ordre = Dmy;
        strcpy(format.yearSep, "/");
        strcpy(format.monthSep, "/");
        strcpy(format.daySep, "/");
        format.yearFormat = 1;
        format.monthFormat = 0;

        datetime.date = DATE_FormatToDate(value, &format);

        /* DLA - PMSTA-29051 - 171108 */
        if (datetime.date == BAD_DATE)
        {
            NOTE_T tmp;
            std::string DATE_ORDRE_ENUM_TAB[] = { "Ymd", "Dmy", "Mdy", "Iso" };
            sprintf(tmp, "Invalid date: string received:\"%s\", unable to convert with these settings: order=%s, sep=%s, YearLen=%s, monthFormat=%s", value, DATE_ORDRE_ENUM_TAB[format.ordre].c_str(), format.monthSep, format.yearFormat == 0 ? "short(YY)" : "long(YYYY)", format.monthFormat == 0 ? "numeric(MM)" : "short(mmm)");
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBI_SetDateApplInfo", tmp);
        }
    }
    else
    {
        datetime.date = MAGIC_END_DATE;
    }

    datetime.time = 0;
    GEN_SetApplInfo(applInfo, &datetime.date);
}

/************************************************************************
*
*   Function             :   DBI_InsertLoginHistory()
*
*   Description          :   Inserts one record in login_history table
*
*
*
*   Arguments            :   user_code, display, reason
*
*
*
*   Return               :
*
*   Creation date        : 14-Feb-2000  VST             REF4170
*   Last Modif. Date     : REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*************************************************************************/
int DBI_InsertLoginHistory(SYSNAME_T user_code, char *display, LOGINHISTORY_NATURE_ENUM reason)
{
    DATE_START_TIMER(1, TIMER_MASK_SQLC);
    try
    {
        DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);
        RequestHelper requestHelper(dbiConnHelper);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
            sqlTrace.m_procedure = "DynSql.InsLoginHistory";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        }

        requestHelper.addNewParamCharPtr(user_code, SysnameType);
        requestHelper.addNewParamCharPtr(display, String1000Type);
        requestHelper.addNewParamUChar(static_cast<UCHAR_T>(reason));
        requestHelper.setCommand("#EXEC #AAALOGIN_DB.ins_login_history_by_cd ?, ?, ?");

        if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
        {
            return RET_DBA_ERR_INSERT_FAILED;
        }
    }
    catch (exception&)
    {
        return RET_DBA_ERR_CANNOTCONNECT;
    }
    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);
    return TRUE;
}

/************************************************************************
*
*   Function     :   DBI_FetchDBServiceName()
*
*   Description  :   Fetches the DB Service Name from DB using the default one
*
*   Arguments    :   server   server Name
*
*   Return       :
*
*   Creation     :   KNI - 310820 - PMSTA-41113 - Multiple DB Connections
*
*   Last Modif.  : 
*
*************************************************************************/
int DBI_FetchDBServiceNameBE(const std::string & server, std::string & serverBECd, ID_T & serverBEId)
{
    int found = 0;

    std::string     userLogin;
    std::string     newServer, newDBService;
    string dsQueryPtr = DBI_GetSqlServerName();

    GEN_GetUserInfo(UserLogin, userLogin);

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);
    DbiConnection* dbiConn = nullptr;

    if (dbiConnHelper.isValidAndInit() == false ||
        (dbiConn = dbiConnHelper.getConnection()) == nullptr)
    {
        string buffer = SYS_Stringer("Cannot connect to default Data Server ", dsQueryPtr);
        MSG_LogMesg(RET_SUCCEED, 1, FILEINFO, buffer.c_str());
        return FALSE;
    }

    {
        found = DBA_GetServiceNameBEFromDB(*dbiConn, server, newServer, newDBService, serverBECd, serverBEId);

        if (!newDBService.empty())
            dsQueryPtr = DBI_GetSqlServerName(newDBService);
    }
    return found;
}

/************************************************************************
*
*   Function             :   DBI_ScanCfg()
*
*   Description          :   Scan $AAALOGINDB Tables for Matching Input Parameters,
*                            load SqlServerName, SqlDbName SqrDbName and ServerName
*                            Application Information.
*
*   Arguments            :   case (int mode) TRUE if server, FALSE elsewhere
*                               TRUE:
*                                char *server
*                              FALSE:
*                                char *user
*                                char *host
*
*   Return               :   TRUE if success, FALSE elsewhere
*

*************************************************************************/
int DBI_ScanCfg(int mode, ...)
{
    if (EV_AAAInstallLevel == 0)
    {
        EV_AAAInstallLevel = SYS_GetEnvIntOrDefValue("RUN_AAA_INSTALL", EV_AAAInstallLevel);

        /* PMSTA-43367 - LJE - 210608 */
        if (EV_AAAInstallLevel == 0 && SYS_IsDdlGenMode() == TRUE)
        {
            EV_AAAInstallLevel = 1;
        }
    }

    EV_CheckTransState = SYS_GetEnvBoolOrDefValue("AAACHECKTRANSSTATE", EV_CheckTransState);
    EV_UseOneConnection = SYS_GetEnvBoolOrDefValue("AAAUSEONECONNECTION", EV_UseOneConnection);

    if ((SYS_IsGuiMode() == TRUE || EV_GenDdlContext.bCheckOnly) && EV_AAAInstallLevel != 0)
    {
        EV_AAAInstallLevel = 0;
    }
    else if (SYS_IsDdlGenMode() && EV_AAAInstallLevel == 0)
    {
        EV_AAAInstallLevel = 4;
    }

    if (EV_AAAInstallLevel != 0 && SYS_IsSrvMode() == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to start GUI or Financial Server with the system variable RUN_AAA_INSTALL defined!");
        return(FALSE);
    }

    std::string             userLogin;
    ID_T                    serverId = 0;
    std::string             forcedServerName;
    CURRENTCHARSETCODE_ENUM currentCharsetCode;
    FLAG_T                  flag = FALSE, gui_user_flag = FALSE;
    char *user = NULL, *display = NULL;
    string              sql, sqr, audit, permtsl, temptsl;
    string              newServer;
    char               *dbTimeZoneCd = nullptr;

    DATETIME_T          resetDate; /* PMSTA-18349 - cashwini - 140710 */
    memset(&resetDate, 0, sizeof(resetDate));

    string dsQueryPtr = DBI_GetSqlServerName();

    GEN_GetUserInfo(UserLogin, userLogin);

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);
    DbiConnection* dbiConn = nullptr;

    if (dbiConnHelper.isValidAndInit() == false ||
        (dbiConn = dbiConnHelper.getConnection()) == nullptr)
    {
        string buffer = SYS_Stringer("Cannot connect to Data server ", dsQueryPtr);

        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer.c_str());
        if (SYS_IsGuiMode() == TRUE)
            MSG_DispMsgTextIC(RET_GEN_ERR_PERSONAL, buffer.c_str());
        return(FALSE);
    }

    int found = 0;
    {
        va_list argLst;
        va_start(argLst, mode);

        if (mode)
        {
            char * server = va_arg(argLst, char *);

            if (server == nullptr || server[0] == 0)
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to start Financial Server when the server name is not provided !");
                return(FALSE);
            }

            found = DBA_GetExdClientConnectByCd(*dbiConn, server, NULL, "", &serverId, newServer, sql, sqr, audit, permtsl, temptsl);
        }
        else
        {
            user = va_arg(argLst, char *);
            display = va_arg(argLst, char *);
            found = DBA_GetExdClientConnectByCd(*dbiConn, NULL, user, display, &serverId, newServer, sql, sqr, audit, permtsl, temptsl);
        }
        va_end(argLst);
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

    if (found && sql.empty() == false)
    {
        if (EV_AAAInstallLevel < 10) /* PMSTA-24676 - LJE - 160905 */
        {
            GEN_SetApplInfo(ApplServerId, &serverId);
            GEN_SetApplInfo(ApplSqlServerName, dsQueryPtr);
            if (newServer.empty() == false)
            {
                GEN_SetApplInfo(ApplServerName, newServer);
            }
            GEN_SetApplInfo(ApplSqlDbName, sql);
            GEN_SetApplInfo(ApplSqrDbName, sqr);
            GEN_SetApplInfo(ApplPermTslDbName, permtsl); /* DLA - PMSTA-12296 - 110706 */
            GEN_SetApplInfo(ApplTempTslDbName, temptsl); /* DLA - PMSTA-12296 - 110706 */
        }
        else if (EV_AAAInstallLevel < 99 || SYS_IsDdlGenMode()) /* PMSTA-37366 - LJE - 191118 - Set only the main db if not IFS case */
        {
            GEN_SetApplInfo(ApplSqlDbName, sql);
            GEN_SetApplInfo(ApplSqrDbName, (sqr.empty()?sql:sqr));
            GEN_SetApplInfo(ApplPermTslDbName, (permtsl.empty() ? sql : permtsl));
            GEN_SetApplInfo(ApplTempTslDbName, (temptsl.empty() ? sql : temptsl));
        }

        if (audit.empty() == false)
        {
            GEN_SetApplInfo(ApplAuditDbName, audit);
        }

        if (EV_AAAInstallLevel == 0)
        {
            FLAG_T          *flagPtr       = nullptr;
            FLAG_T *guiUserFlagPtr         = nullptr;
            ID_T            *userIdPtr     = nullptr;
            DICT_T          *langDictIdPtr = nullptr;
            DATETIME64_ST      *resetDatePtr  = nullptr;

            RequestHelper requestHelper(dbiConn);
            requestHelper.setReadOnly(true);
            requestHelper.useDb(sql);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConn->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.GetUserInfo";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.addNewParamCharPtr(userLogin, SysnameType);
            requestHelper.addNewOutputData(IdType);
            requestHelper.getBindVariablePtr(userIdPtr);
            requestHelper.addNewOutputData(DictType);
            requestHelper.getBindVariablePtr(langDictIdPtr);

            if (SYS_IsSqlMode() == FALSE)
            {
                requestHelper.addNewOutputData(FlagType);
                requestHelper.getBindVariablePtr(flagPtr);
                requestHelper.addNewOutputData(FlagType);
                requestHelper.getBindVariablePtr(guiUserFlagPtr);
                requestHelper.addNewOutputData(DatetimeType);
                requestHelper.getBindVariablePtr(resetDatePtr);

                requestHelper.setCommand("select id, language_dict_id, active_f, gui_user_f, reset_d from appl_user_vw where code = ?");
            }
            else
            {
                requestHelper.setCommand("select id, language_dict_id from appl_user_vw where code = ?");
            }

            DATE_START_TIMER(1, TIMER_MASK_SQLC);

            if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
            {
                MSG_DispMsgText(RET_GEN_ERR_PERSONAL, "The user is not authorized to start Client application (See configuration)");
                return FALSE;
            }

            if (flagPtr != nullptr)
            {
                flag = *flagPtr;
            }
            else
            {
                flag = TRUE;
            }
            if (guiUserFlagPtr != nullptr)
            {
                gui_user_flag = *guiUserFlagPtr;
            }
            if (resetDatePtr != nullptr)
            {
                resetDate = resetDatePtr->dateTime();
            }

            GEN_SetUserInfo(UserId, userIdPtr);
            GEN_SetUserInfo(UserLanguage, langDictIdPtr);

            DATE_STOP_TIMER(1, TIMER_MASK_SQLC);
        }
        else
        {
            flag = TRUE;
        }
    }
    else
    {
        if (SERVER_MODE())    /* DVP257 */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                        "No matching row found in server_connect table (see configuration)");
        else
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                        "No matching row found in client_connect table (see configuration)");

        MSG_DispMsgText(RET_GEN_ERR_PERSONAL, "The user is not authorized to start Client application (See configuration)"); /*  FIH-REF8683-030708  Add retCode */
        return FALSE;
    }

    /* PMSTA-18349 - cashwini - 140710 */
    if (resetDate.date != 0)
    {
        DATETIME_T 		    crtDate;  /* PMSTA-18349 - cashwini - 140710 */
        memset(&crtDate, 0, sizeof(crtDate));

        crtDate.date = DATE_CurrentDate();

        if (DATETIME_CMP(resetDate, crtDate) <= 0)
        {
            RequestHelper requestHelper(dbiConn);
            requestHelper.setReadOnly(true);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                sqlTrace.m_procedure = "DynSql.CheckLoginFailed";
            }

            requestHelper.setCommand("#EXEC #AAALOGIN_DB.chk_login_failed ?, ?");
            requestHelper.addNewParamCharPtr(userLogin, SysnameType);
            requestHelper.addNewParam(FlagType);

            DATE_START_TIMER(1, TIMER_MASK_SQLC);

            if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
            {
                return FALSE;
            }

            DATE_STOP_TIMER(1, TIMER_MASK_SQLC);
            if (requestHelper.getLastStatus())
            {
                MSG_LogMesg(RET_DBA_ERR_LOGIN, 1, FILEINFO, userLogin.c_str());
            }

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.UpdApplUserActiveFlg";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            FLAG_T activeFlg = FALSE;
            requestHelper.finishRequest();
            requestHelper.addNewParamCharPtr(userLogin, SysnameType);
            requestHelper.addNewParamUChar(activeFlg);
            requestHelper.setCommand("#EXEC upd_appl_user_active_f ?, ?");

            DATE_START_TIMER(1, TIMER_MASK_SQLC);

            if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
            {
                return FALSE;
            }

            DATE_STOP_TIMER(1, TIMER_MASK_SQLC);
        }

        /* DLA - PMSTA-10484 - 100826*/
        MSG_DispMsgText(RET_DBA_ERR_LOGIN, "Reset Time is expired, Please contact your Administrator");

        return FALSE;
    }
    /* PMSTA-18349 - cashwini - 140710 -End */

    if (flag == FALSE)
    {
        char buffer[100];
        if (SYS_IsGuiMode() == TRUE)
            DBI_InsertLoginHistory(user, display, LoginHistory_InactiveUser);
        MSG_LogMesg(RET_DBA_ERR_LOGIN, 1, FILEINFO, userLogin.c_str());
        /* DLA - PMSTA05561 - 081103 */
        sprintf(buffer, "Cannot connect to Data server %s", dsQueryPtr.c_str());
        if (SYS_IsGuiMode() == TRUE)
            MSG_DispMsgTextIC(RET_GEN_ERR_PERSONAL, buffer);/*  FPL-080725-PMSTA06926    */
        return FALSE;
    }

    if ((SYS_IsGuiMode() == TRUE) && gui_user_flag == FALSE)
    {
        char buffer[100];
        DBI_InsertLoginHistory(user, display, LoginHistory_BatchUser);
        sprintf(buffer, "Cannot connect to Data server %s", dsQueryPtr.c_str()); /*<PMSTA04718-BRO-071204*/
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
        MSG_DispMsgText(RET_GEN_ERR_PERSONAL, buffer);	/*  FIH-REF8683-030708  Add retCode */ /*>PMSTA04718-BRO-071204*/
        return FALSE;
    }

    GEN_GetUserInfo(ForcedServerName, forcedServerName);

    if (SERVER_MODE() == FALSE && forcedServerName.length() > 0 && EV_AAAInstallLevel == 0 && newServer.compare(forcedServerName) != 0)
    {
        RequestHelper  requestHelper(dbiConn);
        requestHelper.setReadOnly(true);

        char          *serverPtr, *sqlPtr, *sqrPtr, *auditPtr, *permtslPtr, *temptslPtr;
        ID_T          *serverIdPtr;

        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
            sqlTrace.m_procedure = "DynSql.GetServerConnect";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        }

        requestHelper.addNewParamCharPtr(forcedServerName, String1000Type);
        requestHelper.setCommand("#EXEC #AAALOGIN_DB.get_exd_server_connect_by_nm ?");
        requestHelper.addNewOutputData(IdType);
        requestHelper.getBindVariablePtr(serverIdPtr);
        requestHelper.addNewOutputData(NameType);
        requestHelper.getBindVariablePtr(serverPtr);
        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(sqlPtr);
        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(sqrPtr);
        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(auditPtr);
        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(permtslPtr);
        requestHelper.addNewOutputData(SysnameType);
        requestHelper.getBindVariablePtr(temptslPtr);
        requestHelper.addNewOutputData(CodeType);          /* PMSTA-43454 - DDV - 210128 */
        requestHelper.getBindVariablePtr(dbTimeZoneCd);    /* PMSTA-43454 - DDV - 210128 */

        if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
        {
            return(FALSE);
        }

        if (*serverIdPtr != 0)
        {
            GEN_SetApplInfo(ApplServerId, serverIdPtr);
            GEN_SetApplInfo(ApplServerName, serverPtr);
            GEN_SetApplInfo(ApplSqlDbName, sqlPtr);
            GEN_SetApplInfo(ApplSqrDbName, sqrPtr);
            GEN_SetApplInfo(ApplPermTslDbName, permtslPtr);
            GEN_SetApplInfo(ApplTempTslDbName, temptslPtr);

            /* PMSTA-43454 - DDV - 210128 */
            if (dbTimeZoneCd && dbTimeZoneCd[0] != 0)
            {
                strncpy(EV_DbTimeZoneCd, dbTimeZoneCd, CODE_T_LEN);
            }
        }
        else
        {
            std::stringstream buf;
            buf <<  "Cannot find the forced server name in server connect: " << forcedServerName;
            MSG_LogMesg(RET_GEN_ERR_PERSONAL_WARN, 1, FILEINFO, buf.str().c_str());
        }
    }

    /*
    * Retrieve the default charset id from Sybase.
    * Ref.: DVP493, GRD 970609.
    */
    std::string defaultCharset = dbiConn->getDefaultCharset();

    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currentCharsetCode);

    if (SERVER_MODE() || SYS_IsSqlMode() || (SYS_IsBatchMode() && (currentCharsetCode == CurrentCharsetCode_IsNull))) /* PMSTA-24913 - LJE - 161018 */
    {
        /* Set the current Database charset as default. */
        if (GEN_SetCurCharset(defaultCharset.c_str(), CharsetCodeType_Rdbms, CharsetCodeNoCtx, EV_RdbmsVendor) != RET_SUCCEED) /* DLA - REF9303 - 030826 */
        {
            return(FALSE);
        }
    }

    if (defaultCharset.compare("utf8") == 0 || defaultCharset.compare("al32utf8") == 0)
    {
        /*
        ** If SQL server is configured for unicode support then use UTF8 as
        ** default charset for all connection, even for the GUI - this is
        ** required for correct handling of non ASCII character in language
        ** mode.
        ** Non ASCII character are then only allowed in unicode string types,
        ** Normal string types no longer support characters from 128 to 255.
        */
        DBI_SetGeneralCharset(CurrentCharsetCode_UTF8);

        if (dbiConn->isUtf16Allowed())
        {
            ICU4AAA_SQLServerUTF8 = !0;
        }
    }
    else if (SERVER_MODE() || SYS_IsBatchMode() || SYS_IsSqlMode())
    {
        /*
        * Set the loaded charset id to the general context. (DVP493).
        * Same for the interface except if '-J' mode is used. REF4838.
        */
        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currentCharsetCode);

        if (currentCharsetCode != CurrentCharsetCode_IsNull)
        {
            DBI_SetGeneralCharset(currentCharsetCode);
        }
    }

    DBA_ResizeMaxLenDataType();

    if (SYS_IsGuiMode() == TRUE)
    {
        DBI_InsertLoginHistory(user, display, LoginHistory_LoginSucceeded);
    }

    return TRUE;
}

/************************************************************************
*
*   Function             :   DBI_CheckSecurity()
*
*   Description          :
*
*
*
*   Arguments            :
*
*
*
*   Return               :
*
*   Creation date        : 1-Dec-1999   VST             REF4170
*
*   Last Modif. Date     : REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*************************************************************************/
bool DBI_CheckSecurity(const char *display)
{
    bool ret = false;

    if (EV_RdbmsVendor == QtHttp)
    {
        ret = HTTP_CheckSecurity(display);
    }
    else
    {
        DbiConnection* dbiConnection = nullptr;

        try
        {
            dbiConnection = DBA_GetDbiConnection(SqlServer, ROLE_INIT);
            if (dbiConnection != nullptr)
            {
                ret = true;
            }
            else
            {
                throw AAAPoolUsageException("Login failed");
            }
        }
        catch (AAAPoolUsageException&)
        {
            ret = false;
            try
            {
                dbiConnection = DBA_GetDbiConnection(SqlServer, ROLE_SECURITY);
            }
            catch (AAAPoolUsageException& e)
            {
                MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());
            }
        }

        if (ret == false && dbiConnection != nullptr && dbiConnection->isValid())
        {
            RequestHelper requestHelper(dbiConnection);

            std::string userLogin;

            GEN_GetUserInfo(UserLogin, userLogin);

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnection->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.CheckLoginFailed";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.setCommand("#EXEC #AAALOGIN_DB.chk_login_failed ?, ?");

            requestHelper.addNewParamCharPtr(userLogin, SysnameType);
            requestHelper.addNewParam(FlagType);

            if (requestHelper.sendAndGetCommand() == RET_SUCCEED &&
                requestHelper.getLastStatus())
            {
                MSG_LogMesg(RET_DBA_ERR_LOGIN, 1, FILEINFO, userLogin.c_str());
            }

            requestHelper.finishRequest();

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnection->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsertLoginFailed";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.setCommand("#EXEC #AAALOGIN_DB.ins_login_failed_by_cd ?, ?");
            requestHelper.addNewParamCharPtr(userLogin, SysnameType);
            requestHelper.addNewParamCharPtr(display, String1000Type);
            requestHelper.sendAndGetCommand();
        }
        else
        {
            if (dbiConnection != nullptr)
            {
                dbiConnection->release();
            }
            else
            {
                ret = false;
            }
        }
    }

    if (ret != true)
    {
        string message = SYS_Stringer("Cannot connect to Data server ", DBI_GetSqlServerName());
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, message.c_str());
        if (SYS_IsGuiMode() == TRUE)
            MSG_DispMsgTextIC(RET_GEN_ERR_PERSONAL, message.c_str());
    }

    return ret;
}

/************************************************************************
**
** Function    : DBI_PrintVersion
**
** Description : Print to stdout the ORACLE library actually loaded
**
** Arguments   :
**
** Return      : None
**
************************************************************************/
void DBI_PrintVersion()
{
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        SYB_PrintVersion();
        break;
    case Oracle:
        ORA_PrintVersion();
        break;
#ifdef NUODB_ENABLE
    case Nuodb:
        NUODB_PrintVersion();
        break;

#endif

    case Sqlite:
        SQLITE_PrintVersion();
        break;

#ifdef MSDB_ENABLE
    case MSSql:
        /*MSDB_PrintVersion(); MSDB-TODO*/
        break;
#endif
#ifdef POSTGRESQL_ENABLE
    case PostgreSQL:
        PGS_PrintVersion();
        break;

#endif
    }
}

/************************************************************************
**
** Function    : DBI_CheckUserRole
**
** Description : Check if the user define in the connection have the parameter role
**
** Arguments   :
**
** Return      : true if the current user have the role
**
************************************************************************/
bool DBI_CheckUserRole(DbiConnection& dbiConn, const std::string& role)
{
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        return SYB_CheckUserRole(dynamic_cast<SybConnection&>(dbiConn), role);
        break;
    case Oracle: /*ORACLE-TODO*/
        return true;
        break;
    case Nuodb: /*NUODB-TODO*/
        return true;
        break;
    case MSSql: /*MSSQL-TODO*/
        return true;
        break;
    case PostgreSQL:
        return true;
        break;
    case QtHttp: /*PROXY-TODO*/ /* PMSTA-43741 - LJE - 210224 */
        return true;
        break;
    case Sqlite:
        return true;
        break;
    }
    return false;
}


/************************************************************************
*   Function             : DBI_GetConnAllocator()
*
*   Description          : Return the connection method allocator
*
*   Arguments            : server type (Finserver or Sql)
*                        : connection model (Sybase, Oracle, ...)
*
*   Global var. modified : None
*
*   Return               : None
*
*************************************************************************/
AAACONNECTION_ALLOCATOR_FPTR DBI_GetConnAllocatorPtr(DBA_SERVER_TYPE_ENUM type, DBA_RDBMS_ENUM serverModel)
{
    AAACONNECTION_ALLOCATOR_FPTR ret = nullptr;

    switch (type)
    {
        case SqlServer:
        {
            switch (serverModel)
            {
                case Sybase:
                    ret = &SybConnection::createConnection;
                    break;
                case Oracle:
                    ret = &OraConnection::createConnection;
                    break;
                case QtHttp:
                    /* PMSTA-34344 - TEB - 190319 */
                    ret = &HttpConnection::createConnection;
                    break;
#ifdef NUODB_ENABLE
                case Nuodb:
                    ret = &NuoDbConnection::createConnection;
                    break;
#endif
#ifdef MSDB_ENABLE
                case MSSql:
                    ret = &ODBCConnection::createConnection;
                    break;
#endif
#ifdef POSTGRESQL_ENABLE
                case PostgreSQL:
                    ret = &PgsConnection::createConnection;
                    break;
#endif
            case Sqlite:
                ret = &SqliteConnection::createConnection;
                break;
            }
        }
        break;
        case FinServer:
        case DispatchServer: /* PMSTA-24563 - LJE - 160908 */
            switch (serverModel)
            {
                case Sybase:
                    ret = &SybConnection::createConnection;
                    break;
                default:
                    ret = &HttpConnection::createConnection;
                    break;
            }
            break;
    }
    return ret;
}


/************************************************************************
*   Function             : DBI_LoadApplParam()
*
*   Description          : Retrieve all application parameters and save
*                          them in a GEN_APPLINFO_ST structure.
*
*   Arguments            : Statement   : a pointer on a statement structure.
*
*   Functions call       : SYB_ColBind
*                          GEN_SetApplInfo
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if problem with input arg.
*                          RET_GEN_ERR_NOACTION   : if an action was impossible.
*
***************************************************************************/
RET_CODE DBI_LoadApplParam(DbiConnection& dbiConn, ID_T userId, std::map<std::string,std::string>& map_param_bootstrap)
{
    RET_CODE			retCode = RET_SUCCEED;

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (map_param_bootstrap.empty() == false)
    {
        stringstream        request;
        RequestHelper       requestHelper(&dbiConn);

        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = dbiConn.getSqlTrace();
            sqlTrace.m_procedure = "DynSql.LoadApplParam";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        }

        request << "select param_name, value_n from appl_param_bootstrap where param_name in ( ";

        for (auto it = map_param_bootstrap.begin(); it != map_param_bootstrap.end(); ++it)
        {
            if (it != map_param_bootstrap.begin())
            {
                request << ",";
            }
            request << "'" << (*it).first << "'";
        }
        request << ")";

        char               *param_name = nullptr;
        char               *value = nullptr;

        requestHelper.setCommand(request.str());

        requestHelper.addNewOutputData(NameType);
        requestHelper.getBindVariablePtr(param_name);
        requestHelper.addNewOutputData(InfoType);
        requestHelper.getBindVariablePtr(value);

        if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {
                auto it = map_param_bootstrap.find(param_name);
                if (it != map_param_bootstrap.end())
                {
                    (*it).second = value;
                }
            }
        }
        request.clear();
        request.str(std::string());
    }

    /* Override value with user if defined*/
    if (userId != 0)
    {
        char               *param_name = nullptr;
        char               *value = nullptr;
        RequestHelper       requestHelper(&dbiConn);

        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = dbiConn.getSqlTrace();
            sqlTrace.m_procedure = "DynSql.LoadApplParam";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        }

        requestHelper.setCommand("select param_name, value_n from appl_param_vw where param_name = 'LOGIN_MESSAGE' and user_id = ?");

        requestHelper.addNewParamId(userId, IdType);

        requestHelper.addNewOutputData(NameType);
        requestHelper.getBindVariablePtr(param_name);
        requestHelper.addNewOutputData(InfoType);
        requestHelper.getBindVariablePtr(value);

        if (requestHelper.sendAndGetCommand())
        {
            map_param_bootstrap.insert(make_pair("LOGIN_MESSAGE", std::string(value)));
        }
    }

    return(retCode);
}


/************************************************************************
*   Function             : DBI_FldToDbDataStr()
*
*   Description          :
*
*   Arguments            : str          : destination string
*                          p            : the input data
*                          dataType     : the DATATYPE_ENUM member of data
*
*   Return               : RET_SUCCEED              : if no problem was detected
*
*   Creation Date        : 20.05.96 - PEC - Ref.: DVP061
*   Last Modification    : 07.11.96 - PEC - Ref.: DVP244  - Ajout de la variable carNbr + arg length.
*                          06.07.98 - GRD - Ref.: REF2220 - Beware of precision number. (avoid overflows).
*                          REF8844 - LJE - 030324 : Add fld parameter
*                          REF10557 - TEB - 040825 : Performance trouble because TLS_Round
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                          PMSTA-42605 - DDV - 201124 - Traces must not impact data, add noImpactFlg argument
*************************************************************************/
RET_CODE DBI_FldToDbDataStr(char *str, size_t capacity, DBA_DYNFLD_STP p, int fld, DATATYPE_ENUM dataType, int *length, bool noImpactFlg)
{
    RET_CODE        ret = RET_SUCCEED;
    int             carNbr = 0;

    /*
    * The conversion function now checks overflows.
    * It now returns RET_SRV_LIB_ERR_DB_OVERFLOW if needed.
    * GRD - REF2220.
    */

    if (IS_NULLFLD(p, fld) == TRUE)
    {
        switch (dataType)
        {
        case FlagType:
            /* If flag is null, set to 0 */
            if (noImpactFlg)
            {
                carNbr = sprintf(str, "0");
                if (length != UNUSED)
                    *length = carNbr;
                return(RET_SUCCEED);
            }
            else
            {
                SET_FLAG(p, fld, 0);
            }
            break;

        default:
            carNbr = sprintf(str, " NULL");
            if (length != UNUSED)
                *length = carNbr;
            return(RET_SUCCEED);
        }
    }

    if (dataType != NoteType && GET_CTYPE(dataType) == CharPtrCType)
    {
        char *ptr = GET_STRING(p, fld);
        char *l;

        while ((l = strchr(ptr, '"')) != NULL)
            *l = '\'';
    }

    switch (dataType)
    {
    case NullDataType:      carNbr = sprintf(str, " ??? "); break;
    case TimeStampTType: /* PMSTA-20883 - TEB - 150608 */
    case TimeStampType:
        switch (EV_RdbmsVendor)
        {
        case Sybase:
            carNbr = sprintf(str, szFormatTimeStamp, GET_TIMESTAMP(p, fld));
            break;

        case Oracle:
        case Nuodb:
            carNbr = sprintf(str, "%" szFormatId, GET_TIMESTAMP(p, fld));
            break;
        }
        break;
    case AmountType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb;
                    double db = GET_AMOUNT(p, fld);
                    double db2 = 0;

                    decNb = GET_DECIMAL(AmountType);

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, GET_DECIMAL(AmountType), &decNb), /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
                        RndRule_Nearest,
                        FALSE);

                    /* Check for arithmetic overflows. */
                    db2 = TLS_IsOverflowPrec(db, (GET_MAXLEN(AmountType) - GET_DECIMAL(AmountType))); /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Oracle:
            case Nuodb:
                {
                    double number = GET_AMOUNT(p, fld);

                    if (CONV_DoubleToNumericString(number, GET_MAXLEN(AmountType), GET_DECIMAL(AmountType), str,  &carNbr)) /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
                    {
                        CONV_GetMaxNumericAsString(
                            GET_MAXLEN(AmountType), GET_DECIMAL(AmountType), number < 0, str, &carNbr); /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    case CodeType:      if (strlen(GET_CODE(p, fld)) > (unsigned)capacity - 3)
        MSG_RETURN(RET_GEN_ERR_LENGTH);
        carNbr = sprintf(str, "\'%s\'", GET_CODE(p, fld)); break;	/* PMSTA-20159 - TEB - 151117 */
    case DateType:      {
        YEAR_T y; MONTH_T m; DAY_T d;

        DATE_Get(GET_DATE(p, fld), &y, &m, &d);

        /***** BEGIN BUG204 date : 00/00/0000 *****/
        if (m == 0 || d == 0 || y == 0)
        {
            carNbr = sprintf(str, " NULL");
            break;
        }
        /***** END   BUG204 date : 00/00/0000 *****/

        switch (EV_RdbmsVendor)
        {
        case Sybase:
            DATE_ToDbStr(str, GET_DATE(p, fld));   /* PMSTA-20159 - TEB - 151117 */
            carNbr = SYS_StrLen(str);
            break;

        case Oracle:
        case Nuodb:
            carNbr = sprintf(str, "\'%02d-%02d-%04d\'", d, m, y);
            break;
        }
    }
                        break;
    case DatetimeType:
    {
        YEAR_T y; MONTH_T  m; DAY_T d;

        DATETIME_ST datetimeSt = GET_DATETIME(p, fld);

        DATE_Get(datetimeSt.date, &y, &m, &d);

        /***** BEGIN BUG204 date : 00/00/0000 *****/
        if (m == 0 || d == 0 || y == 0)
        {
            carNbr = sprintf(str, " NULL");
            break;
        }
        /***** END   BUG204 date : 00/00/0000 *****/
        /* DLA - PMSTA-25331 - 171108 */
        DATETIME_ToDbStr(str, datetimeSt.date, datetimeSt.time);	/* PMSTA-20159 - TEB - 151117 */
        carNbr = SYS_StrLen(str);
    }
                            break;
    case EnumType:      carNbr = sprintf(str, "%d", GET_ENUM(p, fld)); break;
    case ExchangeType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb = EXCHANGE_T_DEC;
                    double db = GET_EXCHANGE(p, fld);
                    double db2 = 0;

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, EXCHANGE_T_DEC, &decNb),
                        RndRule_Nearest,
                        FALSE);

                    /* Check for arithmetic overflows. */
                    db2 = TLS_IsOverflowPrec(db, (EXCHANGE_T_LEN - EXCHANGE_T_DEC));

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Oracle:
            case Nuodb:
                {
                    double number = GET_EXCHANGE(p, fld);

                    if (CONV_DoubleToNumericString(number, EXCHANGE_T_LEN, EXCHANGE_T_DEC, str,  &carNbr))
                    {
                        CONV_GetMaxNumericAsString(
                            EXCHANGE_T_LEN, EXCHANGE_T_DEC, number < 0, str, &carNbr);

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    case ExtensionType:    {
        auto dynStNbr = GET_EXTENSION_NBR(p, fld);

        carNbr = sprintf(str, "ptr=0x" szFormatPointer ", dynStp=%d, nbr=%d",                /* PMSTA-16124 - 250413 - PMO */
            (void*)GET_EXTENSION_PTR(p, fld),
            (DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld),
            dynStNbr);
    }
                           break;

    case FlagType:       carNbr = sprintf(str, "%d", GET_FLAG(p, fld)); break;
    case DictType:       carNbr = sprintf(str, "%" szFormatId, GET_DICT(p, fld)); break;
    case IdType:         carNbr = sprintf(str, "%" szFormatId, GET_ID(p, fld)); break; /* DLA - PMSTA08801 - 091222 */
    case InfoType:       carNbr = sprintf(str, "\'%s\'", GET_INFO(p, fld)); break;	/* PMSTA-20159 - TEB - 151117 */
    case IntType:        carNbr = sprintf(str, "%d", GET_INT(p, fld)); break;
    case LongintType:    carNbr = sprintf(str, "%" szFormatId, GET_LONGLONG(p, fld)); break;
    case TzOffsetType:   carNbr = sprintf(str, "%d", GET_TZOFFSET(p, fld)); break;
    case LongamountType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb = LONGAMOUNT_T_DEC;
                    double db = GET_LONGAMOUNT(p, fld);
                    double db2 = 0;

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, LONGAMOUNT_T_DEC, &decNb),
                        RndRule_Nearest,
                        FALSE);

                    db2 = TLS_IsOverflowPrec(db, (LONGAMOUNT_T_LEN - LONGAMOUNT_T_DEC));

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Nuodb:
            case Oracle:
                {
                    double number = GET_LONGAMOUNT(p, fld);

                    if (CONV_DoubleToNumericString(number, LONGAMOUNT_T_LEN, LONGAMOUNT_T_DEC, str,  &carNbr))
                    {
                        CONV_GetMaxNumericAsString(
                            LONGAMOUNT_T_LEN, LONGAMOUNT_T_DEC, number < 0, str, &carNbr);

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    case MaskType:       carNbr = sprintf(str, "%d", GET_MASK(p, fld));   break;
    case EnumMaskType:		carNbr = sprintf(str, "%" szFormatId, GET_MASK64(p, fld)); break;	/* PMSTA13460 - TGU - 120423 */
    case MethodType:       carNbr = sprintf(str, "%d", GET_METHOD(p, fld)); break;
    case NameType:       carNbr = sprintf(str, "\'%s\'", GET_NAME(p, fld));   break;	/* PMSTA-20159 - TEB - 151117 */
    case NoteType:       carNbr = sprintf(str, "\'%s\'", GET_NOTE(p, fld));  break;	    /* PMSTA-20159 - TEB - 151117 */    /*  HFI-PMSTA-28195-170818  Remove -30 in printf parameter  */
    case NumberType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb = NUMBER_T_DEC;
                    double db = GET_NUMBER(p, fld);
                    double db2 = 0;

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, NUMBER_T_DEC, &decNb),
                        RndRule_Nearest,
                        FALSE);

                    db2 = TLS_IsOverflowPrec(db, (NUMBER_T_LEN - NUMBER_T_DEC));

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Oracle:
            case Nuodb:
                {
                    double number = GET_NUMBER(p, fld);

                    if (CONV_DoubleToNumericString(number, NUMBER_T_LEN, NUMBER_T_DEC, str,  &carNbr))
                    {
                        CONV_GetMaxNumericAsString(
                            NUMBER_T_LEN, NUMBER_T_DEC, number < 0, str, &carNbr);

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    case PercentType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb = PERCENT_T_DEC;
                    double db = GET_PERCENT(p, fld);
                    double db2 = 0;

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, PERCENT_T_DEC, &decNb),
                        RndRule_Nearest,
                        FALSE);

                    db2 = TLS_IsOverflowPrec(db, (PERCENT_T_LEN - PERCENT_T_DEC));

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Oracle:
            case Nuodb:
                {
                    double number = GET_PERCENT(p, fld);

                    if (CONV_DoubleToNumericString(number, PERCENT_T_LEN, PERCENT_T_DEC, str,  &carNbr))
                    {
                        CONV_GetMaxNumericAsString(
                            PERCENT_T_LEN, PERCENT_T_DEC, number < 0, str, &carNbr);

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    case PeriodType:       carNbr = sprintf(str, "%d", GET_PERIOD(p, fld));     break;
    case PhoneType:       carNbr = sprintf(str, "\'%s\'", GET_PHONE(p, fld));      break;	/* PMSTA-20159 - TEB - 151117 */
    case ShortinfoType:     carNbr = sprintf(str, "\'%s\'", GET_SHORTINFO(p, fld));  break;	/* PMSTA-20159 - TEB - 151117 */
    case SmallintType:      carNbr = sprintf(str, "%d", GET_SMALLINT(p, fld));   break;
    case SysnameType:       carNbr = sprintf(str, "\'%s\'", GET_SYSNAME(p, fld));    break;	/* PMSTA-20159 - TEB - 151117 */
    case LongSysnameType:   carNbr = sprintf(str, "\'%s\'", GET_LONGSYSNAME(p, fld));    break; /* PMSTA-20159 - TEB - 151117 */ /* PMSTA-14086 - LJE - 121008 */
    case TextType:       carNbr = sprintf(str, "\'%s\'", GET_TEXT(p, fld));       break;
    case TimeType:       carNbr = sprintf(str, "time !");                         break;
    case TinyintType:       carNbr = sprintf(str, "%d", GET_TINYINT(p, fld));    break;
    case YearType:       carNbr = sprintf(str, "year !");                         break;
    case LongnameType:      carNbr = sprintf(str, "\'%s\'", GET_NAME(p, fld));       break;  /* PMSTA-20159 - TEB - 151117 */	/* FPL-REF9956-040224 add break */
    case String1000Type:    carNbr = sprintf(str, "\'%s\'", GET_VARSTRING1000(p, fld));  break;   	/* PMSTA-20159 - TEB - 151117 */ /*  DLA - PMSTA07121 - 081212 */
    case String2000Type:    carNbr = sprintf(str, "\'%s\'", GET_VARSTRING2000(p, fld));  break;		/* PMSTA-20159 - TEB - 151117 */
    case String3000Type:    carNbr = sprintf(str, "\'%s\'", GET_VARSTRING3000(p, fld));  break;		/* PMSTA-20159 - TEB - 151117 */
    case String4000Type:    carNbr = sprintf(str, "\'%s\'", GET_VARSTRING4000(p, fld));  break;		/* PMSTA-20159 - TEB - 151117 */
    case String7000Type:    carNbr = sprintf(str, "\'%s\'", GET_VARSTRING7000(p, fld));  break;		/* PMSTA-20159 - TEB - 151117 */
    case String15000Type:   carNbr = sprintf(str, "\'%s\'", GET_VARSTRING15000(p, fld)); break;		/* PMSTA-20159 - TEB - 151117 */

    case UrlType:         carNbr = sprintf(str, "\'%s\'", GET_URL(p, fld));        break;		/* PMSTA-20159 - TEB - 151117 */
        /* PMSTA14256 - DDV - 120510 - Adapt convertion to better manager dynfld that are not part of dynst (like fmtElt results) */
    case UniString1000Type:
    case UniString2000Type:
    case UniString3000Type:
    case UniString4000Type:
    case UniString7000Type:
    case UniString15000Type:
    case UniCodeType:
    case UniInfoType:
    case UniLongnameType:
    case UniNameType:
    case UniNoteType:
    case UniPhoneType:
    case UniShortinfoType:
    case UniSysnameType:
    case UniTextType:

        /* if it is a dynamic structure, use VARSTRING macros */
        if (GET_DYNSTENUM(p) <= InvalidDynSt &&
            (GET_CTYPE(p[fld].dataType) == CharPtrCType ||
            GET_CTYPE(p[fld].dataType) == TextPtrCType))
        {
            carNbr = sprintf(str, "\'%s\'", GET_STRING(p, fld));
        }
        else if (capacity >= 2 &&
            ICU4AAA_ConvertToUTF8(
            GET_USTRING(p, fld), -1, str + 1, int(capacity) - 2, NULL) != -1)   /* PMSTA-17133 - 051113 - PMO */
        {
            *str = '\'';	/* PMSTA-20159 - TEB - 151117 */

            strcat(
                str, "\'");	/* PMSTA-20159 - TEB - 151117 */

            carNbr = SYS_StrLen(str);
        }
        else
        {
            carNbr = sprintf(str, " NULL");
        }
        break;

    case UniUrlType:

        if (capacity >= 2 &&
            ICU4AAA_ConvertToHTML(
            GET_USTRING(p, fld), -1, str + 1, int(capacity) - 2, NULL) != -1)       /* PMSTA-17133 - 051113 - PMO */
        {
            *str = '\'';	/* PMSTA-20159 - TEB - 151117 */

            strcat(
                str, "\'");	/* PMSTA-20159 - TEB - 151117 */

            carNbr = SYS_StrLen(str);
        }
        else
            carNbr =
            sprintf(str, " NULL");
        break;
    case PriceType:
        switch (EV_RdbmsVendor)
        {
            case Sybase:
                {
                    int    decNb = PRICE_T_DEC;
                    double db = GET_PRICE(p, fld);
                    double db2 = 0;

                    db = TLS_Round2(db,
                        TLS_GetNumericPrec(db, PRICE_T_DEC, &decNb),
                        RndRule_Nearest,
                        FALSE);

                    /* Check for arithmetic overflows. */
                    db2 = TLS_IsOverflowPrec(db, (PRICE_T_LEN - PRICE_T_DEC));

                    if (db != db2)
                    {
                        db = db2;
                        if (decNb<0)
                        {
                            decNb = 0;
                        }
                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }

                    carNbr = sprintf(str, "%.*f", decNb, db);
                }
                break;

            case Oracle:
                {
                    double number = GET_PRICE(p, fld);

                    if (CONV_DoubleToNumericString(number, PRICE_T_LEN, PRICE_T_DEC, str,  &carNbr))
                    {
                        CONV_GetMaxNumericAsString(
                            PRICE_T_LEN, PRICE_T_DEC, number < 0, str, &carNbr);

                        ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                    }
                }
                break;

            default:
                ret = RET_GEN_ERR_INVARG;
                break;
        }
        break;

    default:
        break;
    }

    if (length != UNUSED)
        *length = carNbr;

    return(ret);
}


/************************************************************************
*   Function             : DBI_FldToDbDataStr()
*
*   Description          :
*
*   Arguments            : str          : destination string
*                          p            : the input data
*                          dataType     : the DATATYPE_ENUM member of data
*
*   Return               : RET_SUCCEED              : if no problem was detected
*
*   Creation Date        : PMSTA-nuodb - LJE - 190910
*   Last Modification    : PMSTA-42605 - DDV - 201124 - Traces must not impact data, add noImpactFlg argument 
*
*************************************************************************/
RET_CODE DBI_FldToDbDataStr(std::stringstream &outStream, 
                            DBA_DYNFLD_STP     p, 
                            FIELD_IDX_T        fld, 
                            DATATYPE_ENUM      dataType,
                            bool               noImpactFlg,
                            DBA_RDBMS_ENUM     rdbmsEn,
                            const char        *strDelimiterPtr)
{
    RET_CODE        ret = RET_SUCCEED;

    if (IS_NULLFLD(p, fld) == TRUE)
    {
        switch (dataType)
        {
            case FlagType:
                /* If flag is null, set to 0 */
                if (noImpactFlg)
                {
                    outStream << "0";
                    return(RET_SUCCEED);
                }
                else
                {
                    SET_FLAG(p, fld, 0);
                }
                break;

            default:
                outStream << "null";
                return(RET_SUCCEED);
        }
    }

    char      *stringPtr = nullptr;
    char       str[255] = { 0 };
    double     numberVal = 0.0;
    int        numberDec = 0;
    int        numberLen = 0;
    MemoryPool mp;

    switch (GET_CTYPE(dataType))
    {
        case CharPtrCType:
        case TextPtrCType:
            stringPtr = GET_STRING(p, fld);
            break;

        case UniCharPtrCType:
        case UniTextPtrCType:

            /* if it is a dynamic structure, use VARSTRING macros */
            if (GET_DYNSTENUM(p) <= InvalidDynSt &&
                (GET_CTYPE(p[fld].dataType) == CharPtrCType ||
                 GET_CTYPE(p[fld].dataType) == TextPtrCType))
            {
                stringPtr = GET_STRING(p, fld);
            }
            else
            {
                size_t utf8StrLen = ICU4AAA_UnicodeStrLenForAlloc(GET_USTRING(p, fld), TextConversion_Utf8) + 1;
                stringPtr = (char*)mp.calloc(utf8StrLen, sizeof(char));

                if (ICU4AAA_ConvertToUTF8(GET_USTRING(p, fld), -1, stringPtr, int(utf8StrLen), NULL) == -1)
                {
                    outStream << "!!Convert to UTF8 error!!";
                }
            }
            break;

        default:
            switch (dataType)
            {
                case NullDataType:
                    outStream << "null";
                    break;

                case TimeStampTType:
                case TimeStampType:
                    outStream << GET_TIMESTAMP(p, fld);
                    break;

                case AmountType:
                    numberVal   = GET_AMOUNT(p, fld);
                    numberDec   = GET_DECIMAL(AmountType); /* PMSTA-36302 - DDV - 210305 - Make 6 digits amount optional */
                    numberLen   = GET_MAXLEN(AmountType);  /* PMSTA-36302 - DDV - 210305 - Make 6 digits amount optional */
                    break;

                case DateType: {
                    YEAR_T y; MONTH_T m; DAY_T d;

                    DATE_Get(GET_DATE(p, fld), &y, &m, &d);

                    /***** BEGIN BUG204 date : 00/00/0000 *****/
                    if (m == 0 || d == 0 || y == 0)
                    {
                        outStream << "null";
                        break;
                    }
                    /***** END   BUG204 date : 00/00/0000 *****/

                    switch (EV_RdbmsVendor)
                    {
                        case Sybase:
                        case MSSql:
                            DATE_ToDbStr(str, GET_DATE(p, fld));
                            break;

                        case Oracle:
                        case Nuodb:
                            sprintf(str, "\'%02d-%02d-%04d\'", d, m, y);
                            break;
                    }
                }
                               break;

                case DatetimeType:
                {
                    YEAR_T y; MONTH_T  m; DAY_T d;

                    DATETIME_ST datetimeSt = GET_DATETIME(p, fld);

                    DATE_Get(datetimeSt.date, &y, &m, &d);

                    /***** BEGIN BUG204 date : 00/00/0000 *****/
                    if (m == 0 || d == 0 || y == 0)
                    {
                        outStream << "null";
                        break;
                    }
                    /***** END   BUG204 date : 00/00/0000 *****/
                    DATETIME_ToDbStr(str, datetimeSt.date, datetimeSt.time);
                }
                break;
                case EnumType:
                    sprintf(str, "%d", GET_ENUM(p, fld));
                    break;

                case ExchangeType:
                    numberVal   = GET_EXCHANGE(p, fld);
                    numberDec   = EXCHANGE_T_DEC;
                    numberLen   = EXCHANGE_T_LEN;
                    break;

                case ExtensionType:
                {
                    auto dynStNbr = GET_EXTENSION_NBR(p, fld);

                    sprintf(str, "ptr=0x" szFormatPointer ", dynStp=%d, nbr=%d",
                        (void*)GET_EXTENSION_PTR(p, fld),
                            (DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld),
                            dynStNbr);
                }
                break;

                case FlagType:       sprintf(str, "%d", GET_FLAG(p, fld)); break;
                case DictType:       sprintf(str, "%" szFormatId, GET_DICT(p, fld)); break;
                case IdType:         sprintf(str, "%" szFormatId, GET_ID(p, fld)); break;
                case InfoType:       sprintf(str, "\'%s\'", GET_INFO(p, fld)); break;
                case IntType:        sprintf(str, "%d", GET_INT(p, fld)); break;
                case LongintType:    sprintf(str, "%" szFormatId, GET_LONGLONG(p, fld)); break;
                case TzOffsetType:   sprintf(str, "%d", GET_TZOFFSET(p, fld)); break;

                case LongamountType:
                    numberVal   = GET_LONGAMOUNT(p, fld);
                    numberDec   = LONGAMOUNT_T_DEC;
                    numberLen   = LONGAMOUNT_T_LEN;
                    break;

                case MaskType:      sprintf(str, "%d", GET_MASK(p, fld));   break;
                case EnumMaskType:	sprintf(str, "%" szFormatId, GET_MASK64(p, fld)); break;
                case MethodType:    sprintf(str, "%d", GET_METHOD(p, fld)); break;
                case NumberType:
                    numberVal   = GET_NUMBER(p, fld);
                    numberDec   = NUMBER_T_DEC;
                    numberLen   = NUMBER_T_LEN;
                    break;

                case PercentType:
                    numberVal   = GET_PERCENT(p, fld);
                    numberDec   = PERCENT_T_DEC;
                    numberLen   = PERCENT_T_LEN;
                    break;
                case PriceType:
                    numberVal   = GET_PRICE(p, fld);
                    numberDec   = PRICE_T_DEC;
                    numberLen   = PRICE_T_LEN;
                    break;

                case PeriodType:       sprintf(str, "%d", GET_PERIOD(p, fld));     break;
                case SmallintType:     sprintf(str, "%d", GET_SMALLINT(p, fld));   break;
                case TimeType:         sprintf(str, "time !");                     break;
                case TinyintType:      sprintf(str, "%d", GET_TINYINT(p, fld));    break;
                case YearType:         sprintf(str, "year !");                     break;

                default:
                    break;
            }
    }

    if (stringPtr != nullptr)
    {
        if (strDelimiterPtr != nullptr)
        {
            if (strstr(stringPtr, strDelimiterPtr) != nullptr)
            {
                string stringStr(stringPtr);
                string strReplace(strDelimiterPtr);
                strReplace += strDelimiterPtr;

                string::size_type pos = 0;
                while ((pos = stringStr.find(strDelimiterPtr, pos)) != string::npos)
                {
                    stringStr.replace(pos, 1, strReplace);
                    pos += 2;
                }
                outStream << strDelimiterPtr << stringStr << strDelimiterPtr;
            }
            else
            {
                outStream << strDelimiterPtr << stringPtr << strDelimiterPtr;
            }
        }
        else
        {
            outStream << stringPtr;
        }
    }
    else if (str[0] != 0)
    {
        if (rdbmsEn == PostgreSQL)
        {
            switch (GET_CTYPE(dataType))
            {
                case ShortCType:
                case UShortCType:
                case UCharCType:
                    outStream << "cast(" << str << " as smallint)";
                    break;

                default:
                    outStream << str;
            }
        }
        else
        {
            outStream << str;
        }
    }
    else if (outStream.str().empty())
    {
        switch (rdbmsEn)
        {
            case Sybase:
            {
                int    decNb = numberDec;
                double db2 = 0;

                numberVal = TLS_Round2(numberVal,
                                TLS_GetNumericPrec(numberVal, numberDec, &decNb),
                                RndRule_Nearest,
                                FALSE);

                /* Check for arithmetic overflows. */
                db2 = TLS_IsOverflowPrec(numberVal, (numberLen - numberDec));

                if (numberVal != db2)
                {
                    numberVal = db2;
                    if (decNb < 0)
                    {
                        decNb = 0;
                    }
                    ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                }

                sprintf(str, "%.*f", decNb, numberVal);
            }
            break;

            default:
            {
                int    carNbr = 0;
                if (CONV_DoubleToNumericString(numberVal, numberLen, numberDec, str, &carNbr))
                {
                    CONV_GetMaxNumericAsString(
                        numberLen, numberDec, numberVal < 0, str, &carNbr);

                    ret = RET_SRV_LIB_ERR_DB_OVERFLOW;
                }
            }
            break;
        }
        outStream << str;
    }

    return(ret);
}

/************************************************************************
*   Function             : DBI_GetFinancialServerVersionEx()
*
*   Description          : Get information from a remote server
*
*   Arguments            : getVersionSt Information to fill
*                        : server       Server name
*
*   Return               : RET_CODE
*
*   Creation Date        :
*
*   Last Modif.          : PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
RET_CODE DBI_GetFinancialServerVersionEx(DBA_DYNFLD_STP getVersionSt, const std::string & server)
{
    /* DLA - PMSTA-25211 - 161107 */
    RET_CODE            ret = RET_DBA_ERR_DIALOG;
    DbiConnectionHelper connection(server);

     for(int i=0;i<3;i++)
    {
        if(connection.isValidAndInit())
        {
            break;
        }
        SYS_MilliSleep(1000);
    }

    if(connection.isValidAndInit())
    {
        ret = connection.dbaGet(Technical, DBA_ROLE_GET_VERSION, nullptr, &getVersionSt);
    }
    
    return ret;
}


/************************************************************************
*   Function             : DBI_CheckVersion()
*
*   Description          : Check if the remote fusion server as the same version than the dispatcher
*
*   Arguments            : pszServer    Fusion server to check
*                        : verbose      print result in log
*
*   Return               :
*
*   Creation Date        : REF10887 - R.4.20.predev - Check of the same environment
*   Last Modif.          : DLA - PMSTA09875 - 100720
*                          PMSTA15386-JPP-121128  - Display 32 or 64 bits server version
*                          PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
bool DBI_CheckVersion(const std::string & server, const bool & verbose, std::string & pszBits)
{
    bool            bRet            = false;    /* Return value               */
    DBA_DYNFLD_STP  getVersionSt    = ALLOC_DYNST(GetVersion_Arg);  /* PMSTA-24510 - 220816 - PMO */

    if (nullptr != getVersionSt)
    {
        if (RET_SUCCEED == DBI_GetFinancialServerVersionEx(getVersionSt, server))
        { /* We have the version of the remote fusion server */
            pszBits = GET_CODE(getVersionSt, GetVersion_Arg_BitsCd);                 /*PMSTA15386-JPP-121128*/
            /* CMT-12245-FME-190430 Git Version Management*/
            bRet    =  0 == strcmp ( AAAVersion::getVersion().getVersionCode().c_str(), GET_CODE(getVersionSt, GetVersion_Arg_MajorCd))
                    && 0 == strcmp ( AAAVersion::getVersion().getFixCode().c_str(), GET_CODE(getVersionSt, GetVersion_Arg_MinorCd));

            if (false == bRet && true == verbose)
            { /* Bad major and/or minor version */
                MSG_SendMesg(FILEINFO, SYS_Stringer( "Mismatch version srv:"
                                                    , GET_CODE(getVersionSt, GetVersion_Arg_MajorCd)
                                                    , "."
                                                    , GET_CODE(getVersionSt, GetVersion_Arg_MinorCd)
                                                    , " / disp:"
                                                    , AAAVersion::getVersion().getVersionCode().c_str()
                                                    , "."
                                                    , AAAVersion::getVersion().getFixCode().c_str()
                                                    , " with "
                                                    , server
                                                    , ". Server ignored."));
            }
        }
    }
    else
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "GetVersion_Arg");
    }

    FREE_DYNST(getVersionSt, GetVersion_Arg);               /* PMSTA-24510 - 220816 - PMO */

    return bRet;
}


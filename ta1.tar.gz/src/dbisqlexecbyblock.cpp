/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"

#include <string.h>
#include "dbiconnection.h"
#include "dbisqlexecbyblock.h"

extern DBA_RDBMS_ENUM EV_RdbmsDdlGen;

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::DbiSqlExecByBlock()
**
**  Description : Constructors and destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/

DbiSqlExecByBlock::DbiSqlExecByBlock() {
	this->blockSize = 100;
}
DbiSqlExecByBlock::DbiSqlExecByBlock(int bs) : blockSize(bs) {
}

DbiSqlExecByBlock::~DbiSqlExecByBlock(){}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::addSql()
**
**  Description : Add a query string to be executed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
void DbiSqlExecByBlock::addSql(const std::string & sqlBuff)
{
	this->sqlCmdList.push(sqlBuff);
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::getNextSqlBlock()
**
**  Description : Get the next block of queries for the correct DB
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
std::string DbiSqlExecByBlock::getNextSqlBlock(int maxBlockSize)
{
	std::string outString = DBI_GetSqlStatementBegin();
	int cpt = 0;

	while (!this->sqlCmdList.empty() && cpt < maxBlockSize )
	{
		if ((EV_RdbmsDdlGen == Oracle && (outString.size() + 8 + sqlCmdList.back().size()) > 4000) ||
			(EV_RdbmsDdlGen == Sybase && (outString.size() + sqlCmdList.back().size()) > 10240)){
			cpt = maxBlockSize;
		}
		else {
			outString.append(sqlCmdList.front());

            outString += DBI_GetSqlStatementSeparator();
            outString += "\n";

			sqlCmdList.pop();
			cpt++;
		}
	}

    outString += DBI_GetSqlStatementEnd();

	return outString;
}


/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::getSize()
**
**  Description : Get the number of queries to be executed
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
int DbiSqlExecByBlock::getSize(void) {
	return static_cast<int>(this->sqlCmdList.size());
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::getBlockSize()
**
**  Description : Get the size of the blocks
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
int DbiSqlExecByBlock::getBlockSize(void) {
	return this->blockSize;
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::setBlockSize()
**
**  Description : Set the size of the blocks
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
void DbiSqlExecByBlock::setBlockSize(int bs) {
	this->blockSize = bs;
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::execSqlExecByBloc()
**
**  Description : Executes the queries by blocks with the given connection
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
RET_CODE DbiSqlExecByBlock::execSqlExecByBloc(DbiConnection *dbiCon) {
	RET_CODE ret = RET_SUCCEED;

	while (ret == RET_SUCCEED && this->getSize() > 0) {
		ret = dbiCon->sqlExecSt(this->getNextSqlBlock(this->getBlockSize()).c_str());
	}

	return ret;
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::execSqlExecByBloc()
**
**  Description : Execute the queries by blocks, the global executed string
**                is returned.
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
RET_CODE DbiSqlExecByBlock::execSqlExecByBloc(DbiConnection *dbiCon, std::string *executedQuery) {
	RET_CODE ret = RET_SUCCEED;

	while (ret == RET_SUCCEED && this->getSize() > 0) {
		std::string nextBlock = this->getNextSqlBlock(this->getBlockSize());
		(*executedQuery) += nextBlock + '\n';
		ret = dbiCon->sqlExecSt(nextBlock.c_str());
	}

	return ret;
}


/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::execSqlExecByBloc()
**
**  Description : Executes the queries by blocks with the given connection
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
RET_CODE DbiSqlExecByBlock::execSqlExecByBloc(int noConnect) {
	RET_CODE ret = RET_SUCCEED;
	DbiConnection *dbiCon = this->getConnection(noConnect);
	ret = this->execSqlExecByBloc(dbiCon);
	return ret;
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::execSqlExecByBloc()
**
**  Description : Executes the queries by block.
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
RET_CODE DbiSqlExecByBlock::execSqlExecByBloc(void) {
    RET_CODE ret = RET_SUCCEED;
    DbiConnection* dbiCon = this->getConnection();

    dbiCon->beginTransaction();

    ret = this->execSqlExecByBloc(dbiCon);

    if (ret == RET_SUCCEED) {
        dbiCon->endTransaction(TRUE);
    }
    else {
        dbiCon->endTransaction(FALSE);
    }

    DBA_EndConnection(&dbiCon, ret != RET_SUCCEED); /* DLA - PMSTA-25748 - 170111 */
    return ret;
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::getConnection()
**
**  Description : Get a connection
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
DbiConnection* DbiSqlExecByBlock::getConnection(void){
	return DBA_GetDbiConnection(SqlServer);
}

/************************************************************************
**
**  Function    :   DbiSqlExecByBlock::getConnection()
**
**  Description : Get the connection
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 151110
**
*************************************************************************/
DbiConnection* DbiSqlExecByBlock::getConnection(int noConnect){
	return DBA_GetDbiConnFromConnectNo(noConnect);
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINAI_H
#define FINAI_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finai.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINAI_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_AccrInter(DATETIME_T, ID_T, DBA_DYNFLD_STP, ID_T, FIN_AIARG_STP, /*REF1457*/
			                NUMBER_T, DBA_DYNFLD_STP, FIN_MKTVAL_STP, DBA_HIER_HEAD_STP),
                FIN_ComputeInterFloatRate(DBA_DYNFLD_STP, DATE_T, DATE_T, 
					        PERIOD_T, ACCRRULE_ENUM, DBA_DYNFLD_STP, PERCENT_T *, DBA_HIER_HEAD_STP),
		        FIN_PeriodUnitAccrInter(DBA_DYNFLD_STP, DATE_T, DATE_T, PERCENT_T*, /* REF1079 */
					        DBA_DYNFLD_STP, ACCRRULE_ENUM,	 /* REF11218 - TEB - 050627 */
							DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T *), 
		/* BUG043 - RAK - 960627 */
                FIN_SearchInterRate(DATE_T, DATE_T, PERIOD_T, ACCRRULE_ENUM, 
		                    DBA_DYNFLD_STP, FIN_INTERRATE_STP, DBA_HIER_HEAD_STP, INTERCONDNAT_ENUM, FLAG_T, FLAG_T *, FLAG_T = FALSE),   /* REF7475 - YST - 020516 */
	            FIN_UnitAccrInter(DATETIME_T, ID_T, DBA_DYNFLD_STP, FUSDATERULE_ENUM, char, char, 
                            ACCRINTERMETHOD_ENUM, DATETIME_T,                                           /* REF7265 - YST - 020320 */
							ACCRRULE_ENUM, /* REF11218 - TEB - 050627 */
                            DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T, FIN_AIARG_STP), /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/
		        FIN_GetInstrAccrRule(DATE_T, DBA_DYNFLD_STP,
				            DBA_HIER_HEAD_STP, ACCRRULE_ENUM*), /* REF3410 - SSO - 990315 */
				FIN_ResetSceActActRule(DBA_DYNFLD_STP, FLAG_T),
				FIN_SetSceActActRule(DBA_DYNFLD_STP, FLAG_T*),		/* PMSTA-10443 - RAK - 101022 */
                FIN_GetLastCouponPeriod(DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP,
                                        ACCRRULE_ENUM, DBA_HIER_HEAD_STP, DATETIME_T*, DATETIME_T*),  /* PMSTA-37777 - Silpakal - 191106 */
                FIN_InstrPriceAtBenchmarkDate(DBA_DYNFLD_STP, DATETIME_T, DBA_HIER_HEAD_STP, INSTR_UNDERLYING_CATEGORY_ENUM, NUMBER_T*, DBA_DYNFLD_STP);   /* PMSTA-35536 - Silpakal  - 191224 */

EXTERN int      FIN_CmpPosForAccrVal(void *, void *); /* REF - YST - 020528 */

#endif /* FINAI_H */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AAADDLGEN_C

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

/************************************************************************
**      Include files
*************************************************************************/

#ifdef NTWIN
#include <windows.h>        /* REF8728 - 030311 - PMO */
#include "sysnt.h"  /* REF7264 - PMO */
extern  char SV_KeywordNT[64];
#endif

#include      "unidef.h"     /* Mandatory */
#include      "gen.h"
#include      "dba.h"
#include      "ddlgen.h" /* PMSTA-13122 - LJE - 120516 */
#include      "csrv.h"
#include      "sig.h"

#ifndef CALLSTACK_H
#include "callstack.h"
#endif

#if ((defined AAAPURIFY) || (defined AAAQUANTIFY)) && (defined NT)
#include "pure.h"
#endif

#include "main.h"

/************************************************************************
**      External entry points
**
*************************************************************************/

extern  int     EV_AAAInstallLevel;
extern char     SV_FlgLoginPassed; /* PMSTA-CARG - DDV - 130426 - No more static, they can be during cfg file load */
extern char     SV_User[MAX_USERINFO_LEN + 1];
extern char     SV_ServerLogFileName[256];
extern int      SV_ServerMode;
extern int      SV_ServerInitFlg;

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

static RET_CODE SV_LoginOk = FALSE;

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
*   Function             : initCallback()
*
*   Description          : No special initialization at this level for the GUI
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modif.          : PMSTA-24076 - 180716 - PMO : Unstable connections
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                       ,GEN_ThreadDataCtxGenericAllocate
                                       ,GEN_ThreadDataCtxGenericInit
                                       ,GEN_ThreadDataCtxGenericPrepareApplicationData      /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericCleaningApplicationData     /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericDestroy);
}

#ifdef NTWIN
#pragma warning(disable:4189)
#endif

/************************************************************************
**
**  Function    :   mainTripleAProgram
**
**  Description :   application entrypoint
**                  executable accepts parameters
**                  -Uusername or -U username
**                  -Ppassword or -P Password
**                  -Sserver or -S Server
**                  -display DISPLAY
**                  -W
**
**  Arguments   :   argc   arguments number
**                  argv   arguments list
**
**  Return      :   none
**
**  Modif.      :   ROI - 970318 - DVP388
**                  GRD - 971103 - REF1038.
**                  FIH - 980306 - REF064
**                  ROI - 980317 - REF1447
**                  REF9165 - 030610  - PMO : Display the call stack
**                  REF10380 - 041124 - EFE : Stack size problem with HPUX when creating threads
**                                            the new stck size value must be multiple of 8192
**                  PMSTA-9107 -141209 - PMO : Fix visual C++ 2008 issues
**                  PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-18893 - 101114 - PMO : Core dump during precomp on instrument
**                  PMSTA-19736 - 030315 - PMO : OpenServer, Client / P1 / Locking
**                  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**                  PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**                  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                  PMSTA-25236 - 231116 - PMO : Remove AAACORE environment variable handling
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**                  PRO-7103 - 280818 - PMO : Provide libraries log4cplus on different platforms
**                  PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
**
*************************************************************************/
int mainTripleAProgram(int argc, char *argv[])
{

#ifndef NTWIN
    setvbuf(stdout, NULL, _IOLBF, BUFSIZ);
    setvbuf(stderr, NULL, _IOLBF, BUFSIZ);
#endif

    CURRENTCHARSETCODE_ENUM defCurrCharSetEn = CurrentCharsetCode_UTF8;
    GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &defCurrCharSetEn);

    /* General Initialization */
    RET_CODE ret = GEN_Initial();
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        /* PMSTA-11725 - TGU - 130810 - Update the error message @startup */
        char * logFilePath = SYS_GetEnv("AAALOG");
        if (logFilePath != NULL)
        {
            fprintf(stderr, "aaa_ddlgen: initialisation error (see log file: \"%s\")\n", logFilePath);
        }
        else
        {
            fprintf(stderr, "aaa_ddlgen: initialisation error.\n");
        }
        return(1);
    }

    if (CSRV_Init(false) != RET_SUCCEED)
    {
        return(1);
    }

    {
        char path[256];

        sprintf(path, "%s/ddlgen.log", SYS_GetEnv("AAAMSG"));

        MSG_OpenSrvLogFile(path);
    }

    /* PMSTA-11505 - LJE - 110611 */
    *EV_ServerMode = 0;

    if (SV_FlgLoginPassed == TRUE)
    {
        PasswordEncrypted * pE = nullptr;
        GEN_GetUserInfo(UserPasswd, &pE);

        SV_LoginOk = GEN_AppLogin(SV_User, *pE);        /* PMSTA-18094 - 130514 - PMO   */
    }

    /* Last Login check */
    if (SV_LoginOk != RET_SUCCEED)
    {
        return(1);
    }

    ret = RET_SUCCEED;
    if (DBA_InitDictInfo(FALSE) != RET_SUCCEED)
    {
        return(1);
    }

    if ((ret = GEN_InitPoolConnectionFinal()) != RET_SUCCEED ||
        (ret = DDL_InstallDdlObjectByParam()) != RET_SUCCEED)
    {
        return(ret);
    }

#ifdef NTWIN
    NT_Done();
#endif

    return(0);
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType()
{
    return(AAAProgramType::DdlGen);
}

#ifdef NTWIN
#pragma warning(default:4189)
#endif

/*************************************************************************
**   END  aaaddlgen.c                                           Odyssey **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB07_H
#define FINLIB07_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib07.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB07_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN RET_CODE FIN_StratCreateESEModel(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP, int, int*, FLAG_T);
EXTERN RET_CODE FIN_StratCreateESEModelDet(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP, 
					                       DBA_DYNFLD_STP, DBA_DYNFLD_STP, EXTSTRATELTNAT_ENUM);
EXTERN RET_CODE FIN_StratInsStratElt(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, ID_T*);
EXTERN RET_CODE FIN_StratCreateESEModelTot(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP, int, int*);

/* PMSTA05345-CHU-080505 */
EXTERN RET_CODE FIN_StratCreateESERiskDet(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP,
					                       DBA_DYNFLD_STP, DBA_DYNFLD_STP, EXTSTRATELTNAT_ENUM);

#endif /* FINLIB07_H */


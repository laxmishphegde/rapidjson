/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DbiContext_H_
#define DbiContext_H_
#include "connection.h"
#include "dbiconnection.h"
#include "unidef.h"
#include "gen.h"
#include "dba.h"

class DbiContext
{
public:
	DbiContext(const  AAAConnection& connection);
	const DbiConnection* getDbiConnection();

private:
	const DbiConnection * dbiConnection;
};
#endif

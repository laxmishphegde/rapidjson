/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

#define AAALOGGER_C
#ifdef NTWIN
#pragma warning (push)
#endif

#ifdef UNICODE
#error  Unicode not suppported by this implemantation
#endif

/************************************************************************
**      Include files
*************************************************************************/

#include <string>
#include <iomanip>
#include <regex>


#include <QString>
#include <QUuid>

#include <log4cplus/version.h>
#include <log4cplus/logger.h>
#include <log4cplus/configurator.h>
#include <log4cplus/mdc.h>
#include <log4cplus/spi/factory.h>
#include <log4cplus/spi/loggingevent.h>

#include <log4cplus/config.hxx>
#include <log4cplus/appender.h>
#include <log4cplus/helpers/socket.h>
#include <log4cplus/helpers/loglog.h>

#include <log4cplus/initializer.h>


#include "aaalogger.h"
#include "aaatelemetry.h"

#include "syslib.h"
#include "callstack.h"
#include "gen.h"
#include "tls.h"
#include "str.h"
#include "crypto.h"

// rapidjson
#include <fstream>
#include "document.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

/************************************************************************
** PMSTA-32895 - 140918 - FME Cluster Logger
*************************************************************************/

class AAABackwardErrorLayout;

class AAAErrorNumberFilter;

class AAAUdpAppender;
class L4C_StreamAppender;
class AAATelemetryAppender;


/************************************************************************
** AAAEnvironmentCache
*************************************************************************/

class EnvironmentCache
{
public:
    enum class Key
    {
        Mode,
        AAAVersion,
        ServerName,
        ProcessID,
        Param,
        User,
        SysLogin,
        Display
    };

    static EnvironmentCache &getInstance();

    bool getEnvironment(Key key, std::string &value);

private:
    EnvironmentCache();
    EnvironmentCache(const EnvironmentCache &) = delete;
    EnvironmentCache & operator=(const EnvironmentCache &) = delete;

    typedef std::map<Key, std::string> EnvironementMapType;

    EnvironementMapType map;
};

/************************************************************************
*   Method             : EnvironmentCache::
*
*   Description        :
*
*************************************************************************/
EnvironmentCache &EnvironmentCache::getInstance()
{
    static  EnvironmentCache cache;

    return cache;
}

/************************************************************************
*   Method             : EnvironmentCache::
*
*   Description        :
*
*************************************************************************/
EnvironmentCache::EnvironmentCache()
{
    // Singleton built by one single thread

    const char *pointer;

    map.clear();

    if ((pointer = SYS_GetEnv("L4C_MODE")) != NULL) {
        map.insert(std::make_pair(Key::Mode, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_VERSION")) != NULL) {
        map.insert(std::make_pair(Key::AAAVersion, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_SERVERNAME")) != NULL) {
        map.insert(std::make_pair(Key::ServerName, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_PROGRAMNAME")) != NULL) {
        map.insert(std::make_pair(Key::ServerName, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_PID")) != NULL) {
        map.insert(std::make_pair(Key::ProcessID, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_PARAM")) != NULL) {
        map.insert(std::make_pair(Key::Param, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_USER")) != NULL) {
        map.insert(std::make_pair(Key::User, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_SYSLOGIN")) != NULL) {
        map.insert(std::make_pair(Key::SysLogin, pointer));
    }
    if ((pointer = SYS_GetEnv("L4C_DISPLAY")) != NULL) {
        map.insert(std::make_pair(Key::Display, pointer));
    }
}

/************************************************************************
*   Method             : EnvironmentCache::
*
*   Description        :
*
*************************************************************************/
bool EnvironmentCache::getEnvironment(Key key, std::string &value)
{
    EnvironementMapType::iterator it;

    if ((it = map.find(key)) != map.end()) {
        value = it->second;
    }

    return !value.empty();
}

/************************************************************************
** AAALoggerInitializerImpl
*************************************************************************/
class AAALoggerInitializerImpl {
public:
    AAALoggerInitializerImpl();
    ~AAALoggerInitializerImpl();
    void configure(const AAALogger::ConfigurationOption options);
    void basicConfiguration(AAALogger::Level withlevel);
private:
};


/************************************************************************
*   Class             : L4C_StreamAppender
*
*   Description        :
*
*************************************************************************/

class LOG4CPLUS_EXPORT L4C_StreamAppender : public log4cplus::Appender {
public:
    // Ctors
    L4C_StreamAppender(const log4cplus::helpers::Properties& properties);
    L4C_StreamAppender(std::ostream& output);

    // Dtor
    ~L4C_StreamAppender();

    L4C_StreamAppender(const L4C_StreamAppender&) = delete;
    L4C_StreamAppender& operator=(const L4C_StreamAppender&) = delete;

    // Methods
    virtual void close() {};

protected:
    virtual void append(const log4cplus::spi::InternalLoggingEvent& event);

private:
    std::ostream& mOutput;
    bool mImmediateFlush;
};

/************************************************************************
*   Class             : AAAStreamAppenderImpl
*
*   Description        :
*
*************************************************************************/

class AAAStreamAppenderImpl {
public:
    AAAStreamAppenderImpl(std::ostream& withStream);
    ~AAAStreamAppenderImpl();
    log4cplus::SharedAppenderPtr impl_;
private:
    AAAStreamAppenderImpl(const AAAStreamAppenderImpl&) = delete;
    AAAStreamAppenderImpl& operator=(const AAAStreamAppenderImpl&) = delete;
};


AAAStreamAppenderImpl::AAAStreamAppenderImpl(std::ostream& withStream) : impl_(new L4C_StreamAppender(withStream))
{
    ;
}
AAAStreamAppenderImpl::~AAAStreamAppenderImpl()
{
    impl_->waitToFinishAsyncLogging();
}



/************************************************************************
*   Class             : PIIConfiguration/PIIConfigurationItem
*
*   Description        : Manage the PII (Personal Identifiable Information) configuration file 
*                        See AAA_PIICONFIGFILE 
*
*************************************************************************/

class PIIConfigurationItem {
public:
    std::string mDescription;
    std::string mName;
    std::string mType;
};

class PIIConfiguration {
public:
    static std::map<std::string, std::shared_ptr<PIIConfigurationItem>> sv_PIIKeyMap;

    static void configure(const std::string& fromJsonString);
};

std::map<std::string, std::shared_ptr<PIIConfigurationItem>> PIIConfiguration::sv_PIIKeyMap;

void PIIConfiguration::configure(const std::string& fromfileName)
{
    rapidjson::Document document;
    std::string fromJsonString;

    std::ifstream ifs(fromfileName);
    fromJsonString.assign((std::istreambuf_iterator<char>(ifs)), (std::istreambuf_iterator<char>()));

    AAALogger logger = AAALogger::get(AAALogger::Logger::Configuration);

    if (document.Parse(fromJsonString).HasParseError())
    {
        std::stringstream ss;
        ss << "Can not parse PII Json file : " << fromfileName;
        logger.error(ss.str());
        return;
    }
    if (document.IsArray())
    {
        const rapidjson::Value& a = document;
        for (rapidjson::SizeType i = 0; i < a.Size(); i++)
        {
            const rapidjson::Value& o = a[i];
            if (o.IsObject())
            {
                logger.assertion(o.HasMember("description") && o["description"].IsString(), "Require ""description""  field as string");
                logger.assertion(o.HasMember("name") && o["name"].IsString(), "Require ""name""  field as string");
                logger.assertion(o.HasMember("type") && o["type"].IsString(), "Require ""type""  field as string");

                logger.assertion(o.HasMember("search"), "Require ""search"" field");

                const rapidjson::Value& searchArray = o["search"];

                logger.assertion(searchArray.IsArray(), "Require ""search"" field as array");

                auto configItem = std::shared_ptr<PIIConfigurationItem >(new PIIConfigurationItem());
                configItem.get()->mDescription.assign(o["description"].GetString());
                configItem.get()->mName.assign(o["name"].GetString());
                configItem.get()->mType.assign(o["type"].GetString());


                for (rapidjson::Value::ConstValueIterator itr = searchArray.Begin(); itr != searchArray.End(); ++itr)
                { 
                    std::string tagKey= itr->GetString();

                    sv_PIIKeyMap.emplace(tagKey, configItem);
                }
            }
            else 
            {
                std::stringstream ss;
                ss << "Can not understand PII Json file : " << fromfileName << " requires an array of object";
                logger.error(ss.str());

            }
        }
    }else 
    {
        std::stringstream ss;
        ss << "Can not understand PII Json file : " << fromfileName << " requires a top level array";
        logger.error(ss.str());
    }

};


/************************************************************************
** AAALoggerImpl
*************************************************************************/
class AAALoggerImpl : public virtual log4cplus::helpers::SharedObject
{
public:
    AAALoggerImpl(AAALogger::Logger logger);
    ~AAALoggerImpl();

    static AAALogger get(AAALogger::Logger logger);
    
    AAALogger::Logger getLogerEnum() const { return  mLoggerEnum; };

    AAALoggerImpl(const AAALoggerImpl &) = delete;
    AAALoggerImpl & operator=(const AAALoggerImpl &) = delete;

    void log(
        AAALogger::Level level, 
        const std::string& message,
        const std::map<std::string, std::string>& attributes,
        const char* file,
        int line,
        const char* function) const;

    void fatal(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;
    void error(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;
    void warn(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;
    void info(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;
    void debug(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;
    void trace(const std::string& message,
        const char* file = NULL,
        int line = -1,
        const char* function = NULL) const;

    bool isEnabledFor(AAALogger::Level level) const;
    bool isFatalEnabled() const;
    bool isErrorEnabled() const;
    bool isWarnEnabled() const;
    bool isInfoEnabled() const;
    bool isDebugEnabled() const;
    bool isTraceEnabled() const;

    void assertion(bool assertionVal, const std::string& message) const;
    static AAALogger getApplication();

    // TWAC
    AAALogger::Level getLogLevel() const;
    void setLogLevel(AAALogger::Level toLevel);

    // Enum mapping
    static std::string getMdcKeyName(AAALogger::MDC_keys);
    static std::string loggerName(AAALogger::Logger);
    static log4cplus::LogLevel convertToLog4cplusLevel(AAALogger::Level);
    static AAALogger::Level convertFromLog4cplusLevel(log4cplus::LogLevel);

    // MDC
    static void putMDC(AAALogger::MDC_keys key, const std::string& value);
    static void removeMDC(AAALogger::MDC_keys key);
    static void clearMDC();
    static bool getMDC(AAALogger::MDC_keys key, std::string& value);
    void putMDCThreadInfos() const;

    // Lifecycle
    // Use either an instanceof the class Initializer Class or use the static method below.
    static void init();
    static void configure(const AAALogger::ConfigurationOption options);
    static void basicConfiguration(AAALogger::Level withlevel);

    static void terminate();

    static bool IsLog4cplusConfigured();

    // 
    static void InsertPIITagInMap(const std::string& aKey, std::string& aValueToChange, std::map<std::string, std::string>& tagMap );

    // Appender
    void addAppender(const std::unique_ptr< AAAStreamAppenderImpl>&);
    void removeAppender(const std::unique_ptr< AAAStreamAppenderImpl>&);

private:

    static void QTmessageHandler(QtMsgType type, const QMessageLogContext& context, const QString& msg);
    static void writeQtMessage(log4cplus::LogLevel level, const QMessageLogContext& context, const QString& msg);

    static AAALogger makeNewLoggerInstance(AAALogger::Logger name);

    static void setEnvironement(const std::string& environementVariableName, const std::string& environementVariableValue);
    static std::string TryToFindDeveloperConfigFile(const std::string& rootOfWorkspace, bool considereTelemetry);

    typedef std::map<AAALogger::Logger, AAALogger> LoggerMapType;

    static LoggerMapType sv_allLogers_;

    static log4cplus::Initializer* sv_Initializer;

    static log4cplus::ConfigureAndWatchThread* sv_WatchDogThread;
    static bool log4cplusConfigured;

    static void configureEnvironment();

    static const std::string  sv_stdConfigFileName;
    static const std::string  sv_otelConfigFileName;

    AAALogger::Logger mLoggerEnum;
    log4cplus::Logger mlog4cplusLogger;
};

log4cplus::ConfigureAndWatchThread* AAALoggerImpl::sv_WatchDogThread = nullptr;

log4cplus::Initializer* AAALoggerImpl::sv_Initializer = nullptr;


bool AAALoggerImpl::log4cplusConfigured = false;

AAALoggerImpl::LoggerMapType AAALoggerImpl::sv_allLogers_;
std::mutex sv_allLogers_Mutex;




/************************************************************************
*   Method             : AAALoggerImpl::AAALoggerImpl
*
*   Description        : Constructor
*
*************************************************************************/
AAALoggerImpl::AAALoggerImpl(AAALogger::Logger logger) :
    mLoggerEnum(logger)
{
    mlog4cplusLogger = log4cplus::Logger::getInstance(loggerName(logger));
}

/************************************************************************
*   Method             : AAALoggerImpl::~AAALoggerImpl
*
*   Description        : Destructor
*
*************************************************************************/
AAALoggerImpl::~AAALoggerImpl()
{
    AAALoggerImpl::log4cplusConfigured = false;
}

/************************************************************************
*   Method             : AAALoggerImpl::get
*
*   Description        : static method to obtain a logger
*
*************************************************************************/
AAALogger AAALoggerImpl::get(AAALogger::Logger logger)
{
    LoggerMapType::iterator lm_it;

    if ((lm_it = sv_allLogers_.find(logger)) != sv_allLogers_.end())
    {
        return lm_it->second;
    }
    else
    {   // Need to create a new logger
        // Check again with a mutex
        std::lock_guard<std::mutex> lock_guard{ sv_allLogers_Mutex };

        if ((lm_it = sv_allLogers_.find(logger)) != sv_allLogers_.end())
        {
            return lm_it->second;
        }
        else {
            AAALogger resultLogger = AAALoggerImpl::makeNewLoggerInstance(logger);

            bool inserted = sv_allLogers_.insert(std::make_pair(logger, resultLogger)).second;
            if (!inserted)
            {
                log4cplus::Logger::getRoot().assertion(false, " AAALoggerImpl::getl()- Insert failed");
            }
            return resultLogger;
        }
    }
}

bool AAALoggerImpl::IsLog4cplusConfigured()
{
    return(AAALoggerImpl::log4cplusConfigured);
}

/************************************************************************
*   Method             : AAALoggerImpl::init
*
*   Description        : Initalise the logger. This must be done very early in the main programm
*
*************************************************************************/
void AAALoggerImpl::init()
{
    if (nullptr == sv_Initializer) {
        sv_Initializer = new log4cplus::Initializer();
    }
    else {
        assert(false);
        log4cplus::Logger::getRoot().assertion(false, "Initialize only once");
    }

    log4cplus::spi::LayoutFactoryRegistry& regLayout = log4cplus::spi::getLayoutFactoryRegistry();
    LOG4CPLUS_REG_PRODUCT(regLayout, "TripleA::", AAABackwardErrorLayout, ::, log4cplus::spi::LayoutFactory);

    log4cplus::spi::FilterFactoryRegistry& regFilter = log4cplus::spi::getFilterFactoryRegistry();
    LOG4CPLUS_REG_PRODUCT(regFilter, "TripleA::", AAAErrorNumberFilter, ::, log4cplus::spi::FilterFactory);

    log4cplus::spi::AppenderFactoryRegistry& regAppender = log4cplus::spi::getAppenderFactoryRegistry();
    LOG4CPLUS_REG_PRODUCT(regAppender, "TripleA::", AAAUdpAppender, ::, log4cplus::spi::AppenderFactory);
    LOG4CPLUS_REG_PRODUCT(regAppender, "TripleA::", L4C_StreamAppender, ::, log4cplus::spi::AppenderFactory);

    bool forceDebugStdout = SYS_GetEnvBoolOrDefValue("AAA_LOG4CPLUS_AT_INIT",false);

    if (forceDebugStdout)
    {
        // Define a ConsoleAppender in DEBUG level on std err PMSTA-43696 -FME-20210216
        log4cplus::BasicConfigurator::doConfigure(log4cplus::Logger::getDefaultHierarchy() , /*logToStdErr*/ true);

        log4cplusConfigured = true;
    }

}

const std::string  AAALoggerImpl::sv_stdConfigFileName = "log4cplus.properties";
const std::string  AAALoggerImpl::sv_otelConfigFileName = "otel4cplus.properties";

std::string AAALoggerImpl::TryToFindDeveloperConfigFile(const std::string& rootOfWorkspace, bool considereTelemetry)
{
    std::string result;
    bool found = false;
    std::string developerFilePath;
    const std::string workspaceStdLogPropertiePath = "/triplea_home/config/" + sv_stdConfigFileName;
    const std::string workspaceOtelLogPropertiePath = "/triplea_home/config/" + sv_otelConfigFileName;

    if (considereTelemetry)
    {
        SYS_GetAbsoluteFilePath(rootOfWorkspace + workspaceOtelLogPropertiePath, developerFilePath, /*relativeToAAAHome*/ false);
        if (SYS_FileExists(developerFilePath.c_str()))
        {
            result = developerFilePath;
            found = true;
        }
    }
    if (found == false)
    {
        SYS_GetAbsoluteFilePath(rootOfWorkspace + workspaceStdLogPropertiePath, developerFilePath, /*relativeToAAAHome*/ false);
        if (SYS_FileExists(developerFilePath.c_str()))
        {
            result = developerFilePath;
        }
    }
    return result;
}

/************************************************************************
*   Method             : AAALoggerImpl::configure
*
*   Description        : Configure the logger and specifiy if the configuration is hot reloaded or not
*
*************************************************************************/
void AAALoggerImpl::configure(const AAALogger::ConfigurationOption options)
{
    // Environement variable can be used in configuration
    configureEnvironment();

    std::string filePath = SYS_GetEnvStringOrDefValue("AAA_LOG4CPLUS", "");
    if (filePath.empty())
    { 
        const std::string  aaaHome = SYS_GetEnvStringOrDefValue("AAAHOME", "");
        const std::string standardLog4CplusFileName = aaaHome + "/config/" + sv_stdConfigFileName;
        const std::string otelLog4CplusFileName = aaaHome + "/config/" + sv_otelConfigFileName;

        if (options.startTelemetry && SYS_FileExists(otelLog4CplusFileName.c_str())) {
            filePath = otelLog4CplusFileName;
        }
        else
        {
            filePath = standardLog4CplusFileName;
        }

        if ( SYS_FileExists(filePath.c_str())  == false )
        {
            // Try the workspace for a developper
            const std::string curDir= SYS_GetCurrentDir();
            const std::string topTripleaCoreDir = SYS_Stringer(PATH_SEPARATOR, "triplea_core");
            auto pos = curDir.find(topTripleaCoreDir);
            if (pos != std::string::npos && pos < curDir.length()) 
            {
                const std::string rootOfWorkspace = curDir.substr(0, pos);
                filePath = TryToFindDeveloperConfigFile(rootOfWorkspace, options.startTelemetry);
            }
            else {// Try for gateway
                const std::string topGatewayDir = SYS_Stringer(PATH_SEPARATOR, "gateway");
                auto posGate = curDir.find(topGatewayDir);
                if (posGate != std::string::npos && posGate < curDir.length())
                {
                    const std::string rootOfWorkspace = curDir.substr(0, posGate);
                    filePath = TryToFindDeveloperConfigFile(rootOfWorkspace, options.startTelemetry);
                }
            }
        }
    }
    if (SYS_FileExists(filePath.c_str()))
    {
        if (options.startWatcherThread)
        {
            if (nullptr == AAALoggerImpl::sv_WatchDogThread)
            {
                AAALoggerImpl::sv_WatchDogThread = new log4cplus::ConfigureAndWatchThread(filePath.c_str(), 5 * 1000);
            }
            else
            {
                assert(false);
                log4cplus::Logger::getRoot().assertion(false, "Configure only once");
            }
        }
        else
        {
            log4cplus::PropertyConfigurator::doConfigure(filePath.c_str());
        }
        log4cplusConfigured = true;
        AAALogger::get(AAALogger::Logger::Configuration).prepareInfo("Log4cplus config file: " + filePath)->log();
    }
    else
    {
        log4cplusConfigured = false; // Disable the logger system
    }

    qInstallMessageHandler(QTmessageHandler);

    if (log4cplusConfigured)
    {
        const std::string  directoryUsedByConfig = SYS_GetDir(filePath.c_str());
        const std::string  standardPIIfilePath = directoryUsedByConfig + "/PII.json";

        std::string forcedPIIfilePath = SYS_GetEnvStringOrDefValue("AAA_PIICONFIGFILE", "");
        if (SYS_FileExists(forcedPIIfilePath.c_str()))
        {
            AAALogger::get(AAALogger::Logger::Configuration).prepareInfo("PII config file used : {PIIConfigFile}")->tag("PIIConfigFile", forcedPIIfilePath)->log();
            PIIConfiguration::configure(forcedPIIfilePath);
        } 
        else if (SYS_FileExists(standardPIIfilePath.c_str()))
        {
            switch (GEN_GetProgramType())
            {
            case AAAProgramType::Batch: /* Maybe AAAProgramType is a bit too large to solve WEALTH-9830 but for now PII information is not used/hidden in this context */
                AAALogger::get(AAALogger::Logger::Configuration).prepareDebug("PII config file (standard) not used for 'online' due to WEALTH-9830 : {PIIConfigFile}")->tag("PIIConfigFile", standardPIIfilePath)->log();
                break;
            default:
                AAALogger::get(AAALogger::Logger::Configuration).prepareDebug("PII config file used (standard): {PIIConfigFile}")->tag("PIIConfigFile", standardPIIfilePath)->log();
                PIIConfiguration::configure(standardPIIfilePath);
                break;
            }
        }
        else
        {
            AAALogger::get(AAALogger::Logger::Configuration).prepareWarn("PII config file doesn't exists : {PIIConfigFile}")->tag("PIIConfigFile", forcedPIIfilePath)->log();
        }
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::basicConfigure
*
*   Description        : Configure the logger to stdout/stderr
*
*************************************************************************/
void AAALoggerImpl::basicConfiguration(AAALogger::Level withlevel)
{
    log4cplus::BasicConfigurator::doConfigure(log4cplus::Logger::getDefaultHierarchy(), /*logToStdErr*/ true);
    log4cplus::LogLevel implLevel = convertToLog4cplusLevel(withlevel);

    log4cplus::Logger::getRoot().setLogLevel(implLevel);

    log4cplusConfigured = true;
}

/************************************************************************
*   Method             : AAALoggerImpl::terminate
*
*   Description        : Terminate the all loggers
*
*************************************************************************/
void AAALoggerImpl::terminate()
{
    qInstallMessageHandler(0); // Uninstall QT message handler or do nothing if not installed

    if (nullptr != AAALoggerImpl::sv_WatchDogThread) {
        delete AAALoggerImpl::sv_WatchDogThread;
        AAALoggerImpl::sv_WatchDogThread = nullptr;
    }
    if (nullptr != sv_Initializer) {
        delete AAALoggerImpl::sv_Initializer;
        AAALoggerImpl::sv_Initializer = nullptr;
        log4cplusConfigured = false;
    }
    else {
        std::cout << "AAALoggerImpl::terminate called more than once" << std::endl;
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::setEnvironement
*
*   Description        : Set the environement variable
*
*
*************************************************************************/
void AAALoggerImpl::setEnvironement(const std::string& environementVariableName, const std::string& environementVariableValue)
{
    SYS_PutEnv(environementVariableName.c_str(), environementVariableValue.c_str());
}

/************************************************************************
*   Method             : AAALoggerImpl::configureEnvironment
*
*   Description        : Configure the environement variable
*                        used in the log4Cplus configuration file e.g tag  %E{} of the layout.ConversionPattern)
*
*************************************************************************/
void AAALoggerImpl::configureEnvironment()
{
    {
        if (SYS_IsSrvMode()) {
            setEnvironement("L4C_MODE", "SERVER");
        }
        else if (SYS_IsGuiMode()) {
            setEnvironement("L4C_MODE", "GUI");
        }
        else if (SYS_IsBatchMode()) {
            setEnvironement("L4C_MODE", "BATCH");
        }
        else if (SYS_IsDdlGenMode()) {
            setEnvironement("L4C_MODE", "DDLGEN");
        }
        else if (SYS_IsSqlMode()) {
            setEnvironement("L4C_MODE", "SQL");
        }
    }

    {
        /* CMT-12245-FME-190430 Git Version Management*/
        setEnvironement("L4C_VERSION", AAAVersion::getVersion().getfullVersionInfo());
    }

    {
        setEnvironement("L4C_PID", std::to_string(SYS_GetPid()));
    }

    {
        setEnvironement("L4C_SERVERNAME", GEN_GetApplName());
    }
    {
        setEnvironement("L4C_PROGRAMNAME", GEN_GetProgramName());
    }

    if (!EV_RunParam.empty())
    {
        setEnvironement("L4C_PARAM", EV_RunParam);
    }

    const std::string &userName = SYS_GetThreadUser();

    if (!userName.empty())
    {
        setEnvironement("L4C_USER", userName);
    }

    char *userLogin = SYS_GetEnv("LOGNAME");

    if (userLogin != nullptr && *userLogin)
    {
        std::string userLoginString(userLogin);

        setEnvironement("L4C_SYSLOGIN", userLogin);
    }

    if (SYS_IsGuiMode())
    {
        char *display = SYS_GetEnv("DISPLAY");

        if (display != nullptr && *display)
        {
            std::string displayString(display);
            setEnvironement("L4C_DISPLAY", displayString);
        }
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::putMDCThreadInfos
*
*   Description        : Set all MDC information from Thread
*
*************************************************************************/
void AAALoggerImpl::putMDCThreadInfos() const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        if (nullptr != SYS_GetTlsThread())
        {
            putMDC(AAALogger::MDC_keys::ThreadUser, SYS_GetThreadUser().c_str());
            putMDC(AAALogger::MDC_keys::BusinessEntity, SYS_GetThread().getCurrBusinessEntity());
        }
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::log
*
*   Description        : Log a message with a specific level
*
*************************************************************************/
void AAALoggerImpl::log(
    AAALogger::Level level,
    const std::string& message,
    const std::map<std::string, std::string>& attributes,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        this->putMDCThreadInfos();

        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));

        // std::for_each(attrib.begin(), attrib.end(), [](const std::pair<std::string, std::string>& p) { log4cplus::getMDC().put(p.first, p.second); });

        for (auto& attrib : attributes)
        {
            log4cplus::getMDC().put(attrib.first , attrib.second);
        }

        this->mlog4cplusLogger.log(convertToLog4cplusLevel(level), message, file, line, function);

        for (auto& attrib : attributes)
        {
            log4cplus::getMDC().remove(attrib.first);
        }
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::fatal
*
*   Description        : Log a fatal message
*
*************************************************************************/
void AAALoggerImpl::fatal(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        this->mlog4cplusLogger.log(log4cplus::FATAL_LOG_LEVEL, message, file, line, function);
    }
}
/************************************************************************
*   Method             : AAALoggerImpl::error
*
*   Description        : Log an error message
*
*************************************************************************/
void AAALoggerImpl::error(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        this->mlog4cplusLogger.log(log4cplus::ERROR_LOG_LEVEL, message, file, line, function);
    }
}
/************************************************************************
*   Method             : AAALoggerImpl::warn
*
*   Description        : Log a warning message
*
*************************************************************************/
void AAALoggerImpl::warn(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        this->mlog4cplusLogger.log(log4cplus::WARN_LOG_LEVEL, message, file, line, function);
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::info
*
*   Description        : Log an informational message
*
*************************************************************************/
void AAALoggerImpl::info(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        if (nullptr != SYS_GetTlsThread())
        {
            putMDC(AAALogger::MDC_keys::ThreadUser, SYS_GetThreadUser().c_str()); /*PMSTA-55605 - 2024-05-27 - Suparna - Adding Thread-User in Finserver.log*/
        }
        this->mlog4cplusLogger.log(log4cplus::INFO_LOG_LEVEL, message, file, line, function);
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::debug
*
*   Description        : Log a debug message
*
*************************************************************************/
void AAALoggerImpl::debug(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        this->mlog4cplusLogger.log(log4cplus::DEBUG_LOG_LEVEL, message, file, line, function);
    }
}
/************************************************************************
*   Method             : AAALoggerImpl::trace
*
*   Description        : Log a tracing message
*
*************************************************************************/
void AAALoggerImpl::trace(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    if (log4cplusConfigured) {
        putMDC(AAALogger::MDC_keys::ThreadID, SYS_ToString(OS_GetTid()));
        this->mlog4cplusLogger.log(log4cplus::TRACE_LOG_LEVEL, message, file, line, function);
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::isEnabledFor
*
*   Description        : Indicate is the logger is enabled for a specific level
*
*************************************************************************/
bool AAALoggerImpl::isEnabledFor(AAALogger::Level level) const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(convertToLog4cplusLevel(level));
}

/************************************************************************
*   Method             : AAALoggerImpl::isFatalEnabled
*
*   Description        : Indicate is the logger is enabled for Fatal level
*
*************************************************************************/
bool AAALoggerImpl::isFatalEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::FATAL_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::isErrorEnabled
*
*   Description        : Indicate is the logger is enabled for Warning level
*
*************************************************************************/
bool AAALoggerImpl::isErrorEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::ERROR_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::isWarnEnabled
*
*   Description        : Indicate is the logger is enabled for Warning level
*
*************************************************************************/
bool AAALoggerImpl::isWarnEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::WARN_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::isInfoEnabled
*
*   Description        : Indicate is the logger is enabled for Informational level
*
*************************************************************************/
bool AAALoggerImpl::isInfoEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::INFO_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::isDebugEnabled
*
*   Description        : Indicate is the logger is enabled for Debug level
*
*************************************************************************/
bool AAALoggerImpl::isDebugEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::DEBUG_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::isTraceEnabled
*
*   Description        : Indicate is the logger is enabled for Tracing level
*
*************************************************************************/
bool AAALoggerImpl::isTraceEnabled() const
{
    return log4cplusConfigured && this->mlog4cplusLogger.isEnabledFor(log4cplus::TRACE_LOG_LEVEL);
}

/************************************************************************
*   Method             : AAALoggerImpl::assertion
*
*   Description        : Assert a condition and log a message
*
*************************************************************************/
void AAALoggerImpl::assertion(bool assertionVal, const std::string& message) const
{
    this->mlog4cplusLogger.assertion(assertionVal, message);
}

/************************************************************************
*   Method             : AAALoggerImpl::getApplication
*
*   Description        : Return the main logger
*
*************************************************************************/
AAALogger  AAALoggerImpl::getApplication()
{
    return AAALoggerImpl::get(AAALogger::Logger::Application);
}

/************************************************************************
*   Method             : AAALoggerImpl::getLogLevel
*
*   Description        : Return the log level
*
*************************************************************************/
AAALogger::Level AAALoggerImpl::getLogLevel() const
{
 
    log4cplus::LogLevel implLevel = this->mlog4cplusLogger.getChainedLogLevel();
    AAALogger::Level result = convertFromLog4cplusLevel(implLevel);

    return result;
}

/************************************************************************
*   Method             : AAALoggerImpl::setLogLevel
*
*   Description        : change the log level
*
*************************************************************************/
void AAALoggerImpl::setLogLevel(AAALogger::Level toLevel)
{
    log4cplus::LogLevel implLevel = convertToLog4cplusLevel(toLevel);
    this->mlog4cplusLogger.setLogLevel(implLevel);
}

/************************************************************************
*   Method             : AAALoggerImpl::getMdcKeyName
*
*   Description        : Return the string of the Mapped Diagnostic Context name
*                        (used in the log4Cplus configuration file e.g tag  %X{} of the layout.ConversionPattern)
*                        to the corresponding AAALogger::MDC_keys
*
*************************************************************************/
std::string AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys key)
{
    std::string ret;
    switch (key)
    {
    case AAALogger::MDC_keys::Session:
        ret = "???TODO???"; // @TODO FME
        break;
    case AAALogger::MDC_keys::RequestMethod:
        ret = "requestMethod";
        break;
    case AAALogger::MDC_keys::Uri:
        ret = "uri";
        break;
    case AAALogger::MDC_keys::Status:
        ret = "Status";
        break;
    case AAALogger::MDC_keys::Duration:
        ret = "Duration";
        break;
    case AAALogger::MDC_keys::CorrelationID:
        ret = "X-Correlation-ID";
        break;
    case AAALogger::MDC_keys::TraceID:
        ret = "TraceID";
        break;
    case AAALogger::MDC_keys::SpanID:
        ret = "SpanID";
        break;
    case AAALogger::MDC_keys::Principal:
        ret = "???TODO???";  // @TODO FME
        break;
    case AAALogger::MDC_keys::ApplSession:
        ret = "???TODO???";  // @TODO FME
        break;
    case AAALogger::MDC_keys::Type:
        ret = "TYPE";
        break;
    case AAALogger::MDC_keys::HostName:
        ret = "HOSTNAME";
        break;
    case AAALogger::MDC_keys::Exception:
        ret = "EXCEPTION";
        break;
    case AAALogger::MDC_keys::CallStack:
        ret = "CALLSTACK";
        break;
    case AAALogger::MDC_keys::MessageNumber:
        ret = "MESSAGE-NUMBER";
        break;
    case AAALogger::MDC_keys::Param:
        ret = "PARAM";
        break;
    case AAALogger::MDC_keys::ThreadUser:
        ret = "THREAD-USER";
        break;
    case AAALogger::MDC_keys::ThreadID:
        ret = "THREAD-ID";
        break;
    case AAALogger::MDC_keys::ThreadType:
        ret = "THREAD-TYPE";
        break;
    case AAALogger::MDC_keys::RPC:
        ret = "RPC";
        break;
    case AAALogger::MDC_keys::ServerName:
        ret = "SERVERNAME";
        break;
    case AAALogger::MDC_keys::Procedure:
        ret = "PROCEDURE";
        break;

    /* PMSTA-nuodb - LJE - 190912 */
    case AAALogger::MDC_keys::SqlDurationMs:
        ret = "SqlDurationMs";
        break;
    case AAALogger::MDC_keys::SqlDurationS:
        ret = "SqlDurationS";
        break;
    case AAALogger::MDC_keys::SqlCommand:
        ret = "SqlCommand";
        break;
    case AAALogger::MDC_keys::SqlStatus:
        ret = "SqlStatus";
        break;
    case AAALogger::MDC_keys::SqlDatabase:
        ret = "SqlDatabase";
        break;
    case AAALogger::MDC_keys::BusinessEntity:
        ret = "BusinessEntity";
        break;
    case AAALogger::MDC_keys::SqlConnection:
        ret = "SqlConnection";
        break;
    case AAALogger::MDC_keys::SqlFmtEltInfo:
        ret = "SqlFmtEltInfo";
        break;
    case AAALogger::MDC_keys::SqlFmtRowNbr:
        ret = "SqlFmtRowNbr";
        break;
    case AAALogger::MDC_keys::SqlRequestLevel:
        ret = "SqlRequestLevel";
        break;
    case AAALogger::MDC_keys::SqlDbMsgStrings:
        ret = "SqlDbMsgStrings";
        break;
    case AAALogger::MDC_keys::SqlMode:
        ret = "SqlMode";
        break;
    case AAALogger::MDC_keys::MutexType:
        ret = "MutexType";
        break;
    case AAALogger::MDC_keys::MutexAction:
        ret = "MutexAction";
        break;
    case AAALogger::MDC_keys::MutexName:
        ret = "MutexName";
        break;
    case AAALogger::MDC_keys::MutexId:
        ret = "MutexId";
        break;
    case AAALogger::MDC_keys::MutexOwner:
        ret = "MutexOwner";
        break;
    case AAALogger::MDC_keys::MutexOwnerServer:
        ret = "MutexOwnerServer";
        break;

    default:
        assert(false);
        getApplication().assertion(false, "MDC_keys not defined");
    }

    return ret;
}

/************************************************************************
*   Method             : AAALoggerImpl::loggerName
*
*   Description        : Return the string logger name (used in the log4Cplus configuration file)
*                        to the corresponding AAALogger::Logger
*
*************************************************************************/
std::string AAALoggerImpl::loggerName(AAALogger::Logger logger)
{
    return logger.getLoggerName();
}

/************************************************************************
*   Method             : AAALoggerImpl::convertToLog4cplusLevel
*
*   Description        : Convert the AAALogger::Level to the log4cplus::LogLevel
*
*************************************************************************/
log4cplus::LogLevel AAALoggerImpl::convertToLog4cplusLevel(AAALogger::Level level)
{
    if (level == AAALogger::Level::Fatal) return log4cplus::FATAL_LOG_LEVEL;
    if (level == AAALogger::Level::Error) return log4cplus::ERROR_LOG_LEVEL;
    if (level == AAALogger::Level::Warn) return log4cplus::WARN_LOG_LEVEL;
    if (level == AAALogger::Level::Info) return log4cplus::INFO_LOG_LEVEL;
    if (level == AAALogger::Level::Debug) return log4cplus::DEBUG_LOG_LEVEL;
    if (level == AAALogger::Level::Trace) return log4cplus::TRACE_LOG_LEVEL;

    getApplication().assertion(false, "level not defined");
    return log4cplus::NOT_SET_LOG_LEVEL;
}


void AAALoggerImpl::writeQtMessage(log4cplus::LogLevel level, const QMessageLogContext& context, const QString& msg)
{
    auto log4Cpluslogger = get(AAALogger::Logger::QT).mLoggerImpl->mlog4cplusLogger;

    if (log4Cpluslogger.isEnabledFor(level)) {

        log4cplus::tostringstream _log4cplus_buf;
        _log4cplus_buf << msg.toLocal8Bit().constData();
        std::string _log4cplus_filename;
        if (context.file != nullptr) 
        {
            _log4cplus_filename = context.file;
            std::size_t found = _log4cplus_filename.find_last_of("/\\");
            if (found != std::string::npos) {
                _log4cplus_filename.erase(0, found + 1);
            }
        }
        std::string callStackValue;

        bool callstackAlreadyPresent = AAALoggerImpl::getMDC(AAALogger::MDC_keys::CallStack, callStackValue);
        if (callstackAlreadyPresent == false || callStackValue.length() == 0)
        {
            AAALogger::putMDC(AAALogger::MDC_keys::CallStack, SYS_GetCallStack(0,true));
        }

        log4Cpluslogger.forcedLog(level, _log4cplus_buf.str(), _log4cplus_filename.c_str(), context.line);
        
        AAALogger::putMDC(AAALogger::MDC_keys::CallStack, callStackValue);
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::QTmessageHandler
*
*   Description        : Static callback method invoked by QT to send messages
*
*************************************************************************/
void AAALoggerImpl::QTmessageHandler(QtMsgType type, const QMessageLogContext& context, const QString& msg)
{
    switch (type)
    {
    case QtDebugMsg:
        writeQtMessage(log4cplus::DEBUG_LOG_LEVEL, context, msg);
            break;
    case QtInfoMsg:
        writeQtMessage(log4cplus::INFO_LOG_LEVEL, context, msg);
            break;
    case QtWarningMsg:
        writeQtMessage(log4cplus::WARN_LOG_LEVEL, context, msg);
            break;
    case QtCriticalMsg:
        writeQtMessage(log4cplus::ERROR_LOG_LEVEL, context, msg);
            break;
    case QtFatalMsg:
        writeQtMessage(log4cplus::FATAL_LOG_LEVEL, context, msg);
            break;
    default:
        writeQtMessage(log4cplus::ERROR_LOG_LEVEL, context, msg);
        break;
    }
}

void AAALoggerImpl::InsertPIITagInMap(const std::string& aKey, std::string& aValueToChange, std::map<std::string, std::string>& tagMap)
{
    std::map<std::string, std::shared_ptr<PIIConfigurationItem>>::iterator it;

    if ((it = PIIConfiguration::sv_PIIKeyMap.find(aKey)) != PIIConfiguration::sv_PIIKeyMap.end()) {

        if (it->second.get()->mType.compare("MASK") == 0) // only the end 3/4
        {
            auto remainingVisible = aValueToChange.length() / 4;
            auto start = aValueToChange.begin();
            auto end = aValueToChange.end() - remainingVisible;

            std::transform(start, end, start, [](unsigned char ) { return static_cast<char>('*'); });

        }
        else if (it->second.get()->mType.compare("STRIP") == 0) // only ***
        {
            aValueToChange = "***";
        }
        else if (it->second.get()->mType.compare("HASH") == 0) // SHA256
        {
            static CryptoManager  cryptMgr = CryptoManager::getInstance();
            static CryptoProvider* cryptProvid = cryptMgr.getProvider(CryptoManager::OpenSSL);
            assert(cryptProvid != nullptr);
            CryptoBuffer result;
            CryptoBuffer* presult = &result;
            cryptProvid->Hash(HashAlgo::SHA256, aValueToChange.c_str(), presult);
            aValueToChange.assign(result.buffer(), result.size());
        }
        else if (it->second.get()->mType.compare("IGNORE") == 0)
        {
            // No conversion 
        }
        else
        {
            // Tag with unknown Type conversion 
        }
    }
    else
    {
       // Tag not described
    }

    tagMap.emplace(aKey, aValueToChange);

}

void AAALoggerImpl::addAppender(const std::unique_ptr< AAAStreamAppenderImpl>& appImpl)
{
    mlog4cplusLogger.addAppender(appImpl.get()->impl_);
}

void AAALoggerImpl::removeAppender(const std::unique_ptr< AAAStreamAppenderImpl>& appImpl)
{
    mlog4cplusLogger.removeAppender(appImpl.get()->impl_);
}


/************************************************************************
*   Method             : AAALogger::Level::values
*
*   Description        : return all possible log level values
*
*************************************************************************/
std::vector<AAALogger::Level> AAALogger::Level::values()
{
    std::vector<AAALogger::Level> result;

    for (int i = static_cast<int>(Value::Fatal); i < static_cast<int>(Value::Trace); i++)
    {
        Level res(static_cast<Value>(i));
        result.push_back(res);
    }
    return result;
}

/************************************************************************
*   Method             : AAALogger::Level::getLevelName()
*
*   Description        : Return the string representing the log level
*
*************************************************************************/
std::string AAALogger::Level::getLevelName() const
{
    std::string ret;

    switch (static_cast<int>(value))
    {
    case Fatal:
        ret = "FATAL";
        break;
    case Error:
        ret = "ERROR";
        break;
    case Warn:
        ret = "WARN";
        break;
    case Info:
        ret = "INFO";
        break;
    case Debug:
        ret = "DEBUG";
        break;
    case Trace:
        ret = "TRACE";
        break;
    default:
        assert(false);
        AAALogger::getApplicationLogger().assertion(false, "AAALogger::Level::getLevelName not defined");
    }
    return ret;
}

/************************************************************************
*   Method             : AAALogger::Level::getByName
*
*   Description        : Convert to the AAALogger::Level from a string
*
*************************************************************************/
AAALogger::Level AAALogger::Level::getByName(const std::string& input)
{
    std::string _str (input);

    std::transform(_str.begin(), _str.end(), _str.begin(), [](unsigned char c) { return static_cast<char>(toupper(c)); });

    if (_str == "FATAL") return Fatal;
    if (_str == "ERROR") return Error;
    if (_str == "WARN") return Warn;
    if (_str == "INFO") return Info;
    if (_str == "DEBUG") return Debug;
    if (_str == "TRACE") return Trace;

    AAALogger::getApplicationLogger().assertion(false, "AAALogger::Level::getByName Invalid value " + _str);
    return Fatal;
}

/************************************************************************
*   Method             : AAALoggerImpl::convertFromLog4cplusLevel
*
*   Description        : Convert the log4cplus::LogLevel to the AAALogger::Level
*
*************************************************************************/
AAALogger::Level AAALoggerImpl::convertFromLog4cplusLevel(log4cplus::LogLevel level)
{
    switch (level)
    {
    case log4cplus::FATAL_LOG_LEVEL:
    /* case log4cplus::NOT_SET_LOG_LEVEL: ?!?! */
        return AAALogger::Level::Fatal;
        break;
    case log4cplus::ERROR_LOG_LEVEL:
        return AAALogger::Level::Error;
        break;
    case log4cplus::WARN_LOG_LEVEL:
        return AAALogger::Level::Warn;
        break;
    case log4cplus::INFO_LOG_LEVEL:
        return AAALogger::Level::Info;
        break;
    case log4cplus::DEBUG_LOG_LEVEL:
        return AAALogger::Level::Debug;
        break;
    case log4cplus::TRACE_LOG_LEVEL:
        return AAALogger::Level::Trace;
        break;
    default:
        assert(false);
        getApplication().assertion(false, "level not defined");
        return AAALogger::Level::Fatal;;
    }
}

/************************************************************************
*   Method             : AAALoggerImpl::putMDC
*
*   Description        : add a key or change it's value in the Mapped Diagnostic Context
*
*************************************************************************/
void AAALoggerImpl::putMDC(AAALogger::MDC_keys key, const std::string& value)
{
    log4cplus::getMDC().put(getMdcKeyName(key), value);
}

/************************************************************************
*   Method             : AAALoggerImpl::removeMDC
*
*   Description        : Remove a key from the Mapped Diagnostic Context
*
*************************************************************************/
void AAALoggerImpl::removeMDC(AAALogger::MDC_keys key)
{
    log4cplus::getMDC().remove(getMdcKeyName(key));
}

/************************************************************************
*   Method             : AAALoggerImpl::clearMDC
*
*   Description        : Clear the Mapped Diagnostic Context
*
*************************************************************************/
void AAALoggerImpl::clearMDC()
{
    log4cplus::getMDC().clear();
}

/************************************************************************
*   Method             : AAALoggerImpl::getMDC
*
*   Description        : get the value of a MDC key and return true if defined
*
*************************************************************************/
bool AAALoggerImpl::getMDC(AAALogger::MDC_keys key, std::string & value)
{
    log4cplus::tstring log4cplus_value;
    bool result = log4cplus::getMDC().get(&log4cplus_value, getMdcKeyName(key));
    if (result) {
        value = log4cplus_value;
    }
    return result;
}

/************************************************************************
*   Method             : AAALoggerImpl::makeNewLoggerInstance
*
*   Description        : create a new instance of the logger Implementation
*
*************************************************************************/
AAALogger AAALoggerImpl::makeNewLoggerInstance(AAALogger::Logger name)
{
    return AAALogger(new AAALoggerImpl(name));
}

/************************************************************************
** AAALogger::Initializer
*************************************************************************/

AAALogger::ConfigurationOption::ConfigurationOption(bool _startWatcherThread) : startWatcherThread(_startWatcherThread)
{
    startTelemetry = AAATelemetry::isStartRequested();
}

AAALogger::ConfigurationOption::~ConfigurationOption() {}

/************************************************************************
*   Method             : AAALogger::Initializer::Initializer
*
*   Description        : Initalise the logger. This must be done very early in the main programm
*                        Use either an instanceof the class Initializer Class or
*                        use the static  AAALogger::init/configure/terminate
*
*************************************************************************/
AAALogger::Initializer::Initializer() {
    mLoggerInitializerImpl = new AAALoggerInitializerImpl();
}

AAALogger::Initializer::~Initializer() {
    delete mLoggerInitializerImpl;
    mLoggerInitializerImpl = nullptr;
}

void AAALogger::Initializer::configure(const ConfigurationOption options) {
    mLoggerInitializerImpl->configure(options);
}
void AAALogger::Initializer::basicConfiguration(Level withlevel) {
    mLoggerInitializerImpl->basicConfiguration(withlevel);
}

/************************************************************************
** AAALoggerInitializerImpl
*************************************************************************/

/************************************************************************
*   Method             : AAALoggerInitializerImpl custructor
*
*   Description        : Initalise the logger with an automatic variable
*
*************************************************************************/
AAALoggerInitializerImpl::AAALoggerInitializerImpl()
{
    AAALoggerImpl::init();
}

/************************************************************************
*   Method             : AAALoggerInitializerImpl destructor
*
*   Description        : terminate the logger using  an automatic variable
*************************************************************************/
AAALoggerInitializerImpl::~AAALoggerInitializerImpl()
{
    AAALoggerImpl::terminate();
}

/************************************************************************
*   Method             : AAALoggerInitializerImpl::configure
*
*   Description        : Configure the logger and specifiy if the configuration is hot reloaded or not
*
*************************************************************************/
void AAALoggerInitializerImpl::configure(const AAALogger::ConfigurationOption options)
{
    AAALoggerImpl::configure(options);
}

/************************************************************************
*   Method             : AAALoggerInitializerImpl::basicConfiguration
*
*   Description        : Configure the top level logger to stdout with a specific level
*
*************************************************************************/
void AAALoggerInitializerImpl::basicConfiguration(AAALogger::Level withlevel)
{
    AAALoggerImpl::basicConfiguration(withlevel);
}

/************************************************************************
** AAALogger
*************************************************************************/

/************************************************************************
*   Method             : AAALogger::init
*
*   Description        : Initalise the logger. This must be done very early in the main programm
*
*************************************************************************/
void AAALogger::init()
{
    AAALoggerImpl::init();
}

/************************************************************************
*   Method             : AAALogger::configure
*
*   Description        : Configure the logger and specifiy if the configuration is hot reloaded or not
*
*************************************************************************/
void AAALogger::configure(const AAALogger::ConfigurationOption options)
{
    AAALoggerImpl::configure(options);
}

/************************************************************************
*   Method             : AAALogger::basicConfiguration
*
*   Description        : Configure the top level logger to stdout with a specific level
*
*************************************************************************/
void AAALogger::basicConfiguration(Level withlevel)
{
    AAALoggerImpl::basicConfiguration(withlevel);
}

/************************************************************************
*   Method             : AAALogger::terminate
*
*   Description        : Terminate the all loggers
*
*************************************************************************/
void AAALogger::terminate()
{
    AAALoggerImpl::terminate();
}

/************************************************************************
*   Method             : AAALogger::putMDC
*
*   Description        : add a key or change it's value in the Mapped Diagnostic Context
*
*************************************************************************/
void AAALogger::putMDC(MDC_keys key, const std::string& value)
{
    AAALoggerImpl::putMDC(key, value);
}

/************************************************************************
*   Method             : AAALogger::getMDC
*
*   Description        :  get the value of a MDC key and return true if defined
*
*************************************************************************/
bool AAALogger::getMDC(MDC_keys key, std::string& value)
{
    return  AAALoggerImpl::getMDC(key, value);
}

/************************************************************************
*   Method             : AAALogger::removeMDC
*
*   Description        : Remove a key from the Mapped Diagnostic Context
*
*************************************************************************/
void AAALogger::removeMDC(MDC_keys key)
{
    AAALoggerImpl::removeMDC(key);
}

/************************************************************************
*   Method             : AAALogger::clearMDC
*
*   Description        : Clear the Mapped Diagnostic Context
*
*************************************************************************/
void AAALogger::clearMDC()
{
    AAALoggerImpl::clearMDC();
}

/************************************************************************
  **      Correlation-ID
*************************************************************************/

/************************************************************************
*   Method             : constructor AALogger::CorrelationIdGenerator
*
*   Description        :
*
*************************************************************************/

AAALogger::CorrelationIdGenerator::CorrelationIdGenerator()
{
    m_correlationId = AAALogger::renewCorrelationId();
}

/************************************************************************
*   Method             : destructor AALogger::CorrelationIdGenerator
*
*   Description        : 
*
*************************************************************************/

AAALogger::CorrelationIdGenerator::~CorrelationIdGenerator() 
{
    std::string correlationIdValue;

    bool exist = AAALogger::getMDC(AAALogger::MDC_keys::CorrelationID, correlationIdValue);
    if (exist)
    {
        AAALoggerImpl::putMDC(AAALogger::MDC_keys::CorrelationID, "");
    }
    // assert (correlationIdValue == m_correlationId
}


/************************************************************************
*   Method             : AAALogger::renewCorrelationId
*
*   Description        : Force the creation of a New correlation ID for the current Thread
*                        To be used by client side application
*
*************************************************************************/
std::string AAALogger::renewCorrelationId() 
{
    std::string  correlationIdValue = STRING_GetStringFromQByteArray(QUuid::createUuid().toString().toLatin1());

    AAALoggerImpl::putMDC(AAALogger::MDC_keys::CorrelationID, correlationIdValue);     /*  PMSTA-38939 - FME - 20200210 */

    return correlationIdValue;
}


/************************************************************************
*   Method             : AAALogger::currentCorrelationId
*
*   Description        : Return the correlation ID of the current Thread
*
*************************************************************************/
std::string AAALogger::currentCorrelationId() {

    std::string correlationIdValue;
    AAALogger::getMDC(AAALogger::MDC_keys::CorrelationID, correlationIdValue);

    return correlationIdValue;
}


/************************************************************************
*   Method             : AAALogger::ensureCorrelationId
*
*   Description        : Ensure a correlation Id exists for the current Thread
*                        return true if a new value has been created , and return the value as an out parameter
*
*************************************************************************/
bool AAALogger::ensureCorrelationId(std::string& correlationIdValue)
{

    bool created = false;
    if (!AAALogger::getMDC(AAALogger::MDC_keys::CorrelationID, correlationIdValue))
    {
        correlationIdValue = renewCorrelationId();
        created = true;
    }
    return created;
}



/************************************************************************
*   Method             : AAALogger::forceRemovalCorrelationId
*
*   Description        : enforce the cleanup of the correlation ID of the current Thread
*                        return true if a value was present
*
*************************************************************************/
bool AAALogger::forceRemovalCorrelationId() {
    std::string correlationIdValue;

    bool exist = AAALogger::getMDC(AAALogger::MDC_keys::CorrelationID, correlationIdValue);
    if (exist)
    {
        AAALoggerImpl::putMDC(AAALogger::MDC_keys::CorrelationID, "");
    }
    return exist;

}





/************************************************************************
*   Method             : AAALogger::isLegacyLoggingEnabled
*
*   Description        : Indicate if the legacy logging is enabled
*                        The environement variable AAADISABLEOLDLOG drive this
*
*************************************************************************/
bool  AAALogger::isLegacyLoggingEnabled() {
    static bool isInited = false;
    static bool isDisabled = false;

    if (!isInited)
    {
        isDisabled = SYS_GetEnvBoolOrDefValue("AAADISABLEOLDLOG", false);

        isInited = true;
    }
    return (!isDisabled);
}

/************************************************************************
*   Method             : AAALogger::AAALogger
*
*   Description        : Constructor
*
*************************************************************************/
AAALogger::AAALogger(AAALoggerImpl * ptr)
    : mLoggerImpl(ptr)
{
    if (mLoggerImpl) {
        mLoggerImpl->addReference();
    }
}

/************************************************************************
*   Method             : AAALogger::AAALogger
*
*   Description        : Constructor
*
*************************************************************************/

AAALogger::AAALogger(Logger logger) :
    mLoggerImpl(nullptr)
{
    AAALogger gotLog = AAALoggerImpl::get(logger);
    gotLog.swap(*this);
}

/************************************************************************
*   Method             : AAALogger::AAALogger
*
*   Description        : Constructor
*
*************************************************************************/

AAALogger::AAALogger(const AAALogger & rhs) :
    mLoggerImpl(rhs.mLoggerImpl)
{
    if (mLoggerImpl) {
        mLoggerImpl->addReference();
    }
}

/************************************************************************
*   Method             : AAALogger::operator=
*
*   Description        : Affectation
*
*************************************************************************/
AAALogger & AAALogger::operator=(const AAALogger & rhs)
{
    AAALogger(rhs).swap(*this);
    return *this;
}

/************************************************************************
*   Method             : AAALogger::~AAALogger
*
*   Description        : Destructor
*
*************************************************************************/
AAALogger::~AAALogger() {
    if (mLoggerImpl) {
        mLoggerImpl->removeReference();
    }
}

/************************************************************************
*   Method             : AAALogger::swap
*
*   Description        : Swap this with an other logger
*
*************************************************************************/
void AAALogger::swap(AAALogger &other)
{
    std::swap(mLoggerImpl, other.mLoggerImpl);
}

/************************************************************************
*   Method             : AAALogger::get
*
*   Description        : static method to obtain a logger
*
*************************************************************************/
AAALogger AAALogger::get(Logger logger)
{
    return AAALoggerImpl::get(logger);
}

bool AAALogger::IsLog4cplusConfigured()
{
    return AAALoggerImpl::IsLog4cplusConfigured();
}

/************************************************************************
*   Method             : AAALogger::log
*
*   Description        : Log a message with a specific level
*
*************************************************************************/
void AAALogger::log(Level level,
    const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    std::map<std::string, std::string> attributes;
    this->mLoggerImpl->log(level, message, attributes, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::fatal
*
*   Description        : Log a fatal message
*
*************************************************************************/
void AAALogger::fatal(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->fatal(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::error
*
*   Description        : Log an error message
*
*************************************************************************/

void AAALogger::error(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->error(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::warn
*
*   Description        : Log a warning message
*
*************************************************************************/
void AAALogger::warn(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->warn(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::info
*
*   Description        : Log an informational message
*
*************************************************************************/
void AAALogger::info(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->info(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::debug
*
*   Description        : Log a debug message
*
*************************************************************************/
void AAALogger::debug(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->debug(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::trace
*
*   Description        : Log a tracing message
*
*************************************************************************/
void AAALogger::trace(const std::string& message,
    const char* file,
    int line,
    const char* function) const
{
    this->mLoggerImpl->trace(message, file, line, function);
}

/************************************************************************
*   Method             : AAALogger::isEnabledFor
*
*   Description        : Indicate is the logger is enabled for a specific level
*
*************************************************************************/
bool AAALogger::isEnabledFor(Level level) const
{
    return this->mLoggerImpl->isEnabledFor(level);
}

/************************************************************************
*   Method             : AAALogger::isFatalEnabled
*
*   Description        : Indicate is the logger is enabled for Fatal level
*
*************************************************************************/
bool AAALogger::isFatalEnabled() const
{
    return this->mLoggerImpl->isFatalEnabled();
}

/************************************************************************
*   Method             : AAALogger::isErrorEnabled
*
*   Description        : Indicate is the logger is enabled for Error level
*
*************************************************************************/
bool AAALogger::isErrorEnabled() const
{
    return this->mLoggerImpl->isErrorEnabled();
}

/************************************************************************
*   Method             : AAALogger::isWarnEnabled
*
*   Description        : Indicate is the logger is enabled for Warning level
*
*************************************************************************/
bool AAALogger::isWarnEnabled() const
{
    return this->mLoggerImpl->isWarnEnabled();
}

/************************************************************************
*   Method             : AAALogger::isInfoEnabled
*
*   Description        : Indicate is the logger is enabled for Informational level
*
*************************************************************************/
bool AAALogger::isInfoEnabled() const
{
    return this->mLoggerImpl->isInfoEnabled();
}

/************************************************************************
*   Method             : AAALogger::isDebugEnabled
*
*   Description        : Indicate is the logger is enabled for Debug level
*
*************************************************************************/
bool AAALogger::isDebugEnabled() const
{
    return this->mLoggerImpl->isDebugEnabled();
}

/************************************************************************
*   Method             : AAALogger::isTraceEnabled
*
*   Description        : Indicate is the logger is enabled for Tracing level
*
*************************************************************************/
bool AAALogger::isTraceEnabled() const
{
    return this->mLoggerImpl->isTraceEnabled();
}


/************************************************************************
*   Method             : AAALogger::getLogLevel()
*
*   Description        : return the Log level
*
*************************************************************************/
AAALogger::Level AAALogger::getLogLevel() const 
{
    return this->mLoggerImpl->getLogLevel();
}

/************************************************************************
*   Method             : AAALogger::setLogLevel
*
*   Description        : change the log level
*
*************************************************************************/
void  AAALogger::setLogLevel(Level toLevel) 
{
    this->mLoggerImpl->setLogLevel(toLevel);
}

/************************************************************************
*   Method             : AAALogger::get()
*
*   Description        : get the logger
*
*************************************************************************/
AAALogger::Logger  AAALogger::get() const
{
    return  this->mLoggerImpl->getLogerEnum();
}

/************************************************************************
*   Method             :  AAALogger::getLoggerName
*
*   Description        : get the logger name
*
*************************************************************************/
std::string AAALogger::getLoggerName() const
{
    std::string result= AAALoggerImpl::loggerName(this->get());

    return result;
}
/************************************************************************
*   Method             : AAALogger::Logger::values
*
*   Description        : return all possible loggers
*
*************************************************************************/
std::vector< AAALogger::Logger> AAALogger::Logger::values()
{
    std::vector<AAALogger::Logger> result;
     
    for ( int i = static_cast<int>(Value::Message) ; i  < static_cast<int>(Value::Last) ; i++)
    {
        Logger res(static_cast<Value>(i));
        result.push_back(res);
    }
    return result;

}


void AAALogger::MessageBuilder::managePIITags(std::string& finalMessage, std::map<std::string, std::string>& tagMap, const std::string& aKey, const std::string& aOriginalValue)
{
    std::string hiddenValue = aOriginalValue;

    AAALoggerImpl::InsertPIITagInMap(aKey, hiddenValue, tagMap);

    finalMessage.append(hiddenValue);
}



/************************************************************************
*   Method             : AAALogger::Logger::getLoggerName
*
*   Description        : return the logger name
*
*************************************************************************/
std::string AAALogger::Logger::getLoggerName() const
{

    /* DO not FORGET to change also AAALogger::Logger::getByName() below */

    std::string ret;

    switch (static_cast<int>(value))
    {
    case AAALogger::Logger::Message:
        ret = "TripleA.Message";
        break;
    case AAALogger::Logger::Server:
        ret = "TripleA.Server";
        break;
    case AAALogger::Logger::ServerPerformance:
        ret = "TripleA.Server.Performance";
        break;
    case AAALogger::Logger::HttpAccessServer:
        ret = "TripleA.Access.Server";
        break;
    case AAALogger::Logger::HttpAccessClient:
        ret = "TripleA.Access.Client";
        break;
    case AAALogger::Logger::SqlTrace:
        ret = "TripleA.SqlTrace";
        break;
    case AAALogger::Logger::SqlTraceFmt:
        ret = "TripleA.SqlTraceFmt";
        break;
    case AAALogger::Logger::Connections:
        ret = "TripleA.Connections";
        break;
    case AAALogger::Logger::Application:
        ret = "TripleA.Application";
        break;
    case AAALogger::Logger::HttpClient:
        ret = "TripleA.Application.HttpClient";
        break;
    case AAALogger::Logger::HttpServer:
        ret = "TripleA.Application.HttpServer";
        break;
    case AAALogger::Logger::Fusion:
        ret = "TripleA.Application.Fusion";
        break;
    case AAALogger::Logger::TWAC:
        ret = "TripleA.Application.TWAC";
        break;
    case AAALogger::Logger::SqlApplication:
        ret = "TripleA.Application.aaasql";
        break;
    case AAALogger::Logger::DdlGen:
        ret = "TripleA.Application.ddlgen";
        break;
    case AAALogger::Logger::Tracer:
        ret = "TripleA.Application.Tracer";
        break;
    case AAALogger::Logger::Process:
        ret = "TripleA.Application.Process";
        break;
    case AAALogger::Logger::SSL:
        ret = "TripleA.Application.SSL";
        break;
    case AAALogger::Logger::Configuration:
        ret = "TripleA.Application.Configuration";
        break;
    case AAALogger::Logger::ScriptTrace:
        ret = "TripleA.Application.ScriptTrace";
        break;
    case AAALogger::Logger::Mutex:
        ret = "TripleA.Application.Mutex";
        break;
    case AAALogger::Logger::QT:
        ret = "TripleA.Application.QT";
        break;
    case AAALogger::Logger::OTEL:
        ret = "TripleA.Application.OTEL";
        break;
    case AAALogger::Logger::UserAccess:
        ret = "TripleA.Application.UserAccess";
        break;
    case AAALogger::Logger::Import:
        ret = "TripleA.Application.Import";
        break;
    case AAALogger::Logger::Other:
        ret = "TripleA.Application.Other";
        break;
    default:
        assert(false);
        AAALogger::getApplicationLogger().assertion(false, "AAALogger::Logger::getLoggerName Logger not defined");
    }
    return ret;
}


/************************************************************************
*   Method             : AAALogger::Logger::getByName
*
*   Description        : get a logger by name
*
*************************************************************************/
AAALogger::Logger AAALogger::Logger::getByName(const std::string& str)
{
/* DO not FORGET to change also AAALogger::Logger::getLoggerName() above */

    if (str == "TripleA.Message") return Message;
    if (str == "TripleA.Server") return Server;
    if (str == "TripleA.Server.Performance") return ServerPerformance;
    if (str == "TripleA.Access.Server") return HttpAccessServer;
    if (str == "TripleA.Access.Client") return HttpAccessClient;
    if (str == "TripleA.SqlTrace") return SqlTrace;
    if (str == "TripleA.SqlTraceFmt") return SqlTraceFmt;
    if (str == "TripleA.Connections") return Connections;
    if (str == "TripleA.Application") return Application;
    if (str == "TripleA.Application.HttpClient") return HttpClient;
    if (str == "TripleA.Application.HttpServer") return HttpServer;
    if (str == "TripleA.Application.Fusion") return Fusion;
    if (str == "TripleA.Application.TWAC") return TWAC;
    if (str == "TripleA.Application.aaasql") return SqlApplication;
    if (str == "TripleA.Application.ddlgen") return DdlGen;
    if (str == "TripleA.Application.Tracer") return Tracer;
    if (str == "TripleA.Application.Process") return Process;
    if (str == "TripleA.Application.SSL") return SSL;
    if (str == "TripleA.Application.Configuration") return Configuration;
    if (str == "TripleA.Application.ScriptTrace") return ScriptTrace;
    if (str == "TripleA.Application.Mutex") return Mutex;
    if (str == "TripleA.Application.QT") return QT;
    if (str == "TripleA.Application.OTEL") return OTEL;
    if (str == "TripleA.Application.UserAccess") return UserAccess;
    if (str == "TripleA.Application.Import") return Import;
    if (str == "TripleA.Application.Other") return Other;

    AAALogger::getApplicationLogger().assertion(false, "AAALogger::Logger::getByName Invalid value " + str);
    return Last;
 }

/************************************************************************
*   Method             :  AAALogger::getAllLoggers
*
*   Description        : return all possible loggers
*
*************************************************************************/
std::vector<AAALogger> AAALogger::getAllLoggers() 
{
    std::vector<AAALogger> result;
    std::vector< AAALogger::Logger> loggersEnum = AAALogger::Logger::values();
    for (std::vector<AAALogger::Logger>::iterator it = loggersEnum.begin(); it != loggersEnum.end(); ++it)
    {
        result.push_back(get(*it));
    }
    return result;
}

/************************************************************************
*   Method             : AAALogger::getLoggerByName
*
*   Description        : return the logger by name 
*
*************************************************************************/
AAALogger AAALogger::getLoggerByName(const std::string& name) 
{
    return Logger::getByName(name);
}

/************************************************************************
*   Method             :
*
*   Description        :
*
*************************************************************************/
std::ostream& operator<<(std::ostream& os, AAALogger::Level logLevel)
{
    os << logLevel.getLevelName();
    return os;
}

/************************************************************************
*   Method             : 
*
*   Description        :
*
*************************************************************************/
std::ostream& operator<<(std::ostream& os, AAALogger::Logger logger)
{
    os << AAALoggerImpl::get(logger).getLoggerName();
    return os;
}


/************************************************************************
*   Method             : AAALogger::assertion
*
*   Description        : Assert a condition and log a message
*
*************************************************************************/
void AAALogger::assertion(bool assertionVal, const std::string& message) const
{
    this->mLoggerImpl->assertion(assertionVal, message);
}

/************************************************************************
*   Method             : AAALogger::getApplication
*
*   Description        : Return the main logger
*                        use a more specific logger when possible see enum AAALogger::Logger
*
*************************************************************************/
AAALogger AAALogger::getApplicationLogger()
{
    switch (GEN_GetProgramType())
    {
        case AAAProgramType::Batch:
            return AAALoggerImpl::get(Logger::Import);

        case AAAProgramType::Sql:
            return AAALoggerImpl::get(Logger::SqlApplication);

        case AAAProgramType::DdlGen:
            return AAALoggerImpl::get(Logger::DdlGen);

    }
    return AAALoggerImpl::get(Logger::Application);
}

////////////////////// FME NEW
/************************************************************************
*   Class              : AAALogger::AAAStreamAppender
*
*   Description        : 
*                        
*
*************************************************************************/

AAALogger::AAAStreamAppender::AAAStreamAppender(const AAALogger& forLogger, std::ostream& withStream) : mLoggerImpl (forLogger.mLoggerImpl)
{
    mAppenderImpl = std::unique_ptr< AAAStreamAppenderImpl>(new AAAStreamAppenderImpl(withStream));

    mLoggerImpl->addAppender(mAppenderImpl);

}
AAALogger::AAAStreamAppender::~AAAStreamAppender()
{
    mLoggerImpl->removeAppender(mAppenderImpl);

}

/************************************************************************
*   Class              : AAALogger::MessageBuilder
*
*   Description        :
*
*
*************************************************************************/

std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::MessageBuilder::tag(const std::string& aKey, const std::string& value)
{
    std::string hiddenValue;
    hiddenValue.assign(value);
    AAALoggerImpl::InsertPIITagInMap(aKey, hiddenValue, mTagMap);

    return shared_from_this();
}

void AAALogger::MessageBuilder::log(const char* file , int line, const char* function) 
{
    if (mTagMap.size() > 0) {
        // replace tags in the message

        static const std::regex  tag_regexp(MessageBuilder::SC_TAG_REGEXP);
        std::string finalMessage;

        auto tags_Iter = std::sregex_iterator(mMessage.begin(), mMessage.end(), tag_regexp);
        auto tags_end = std::sregex_iterator();
        if (tags_Iter == tags_end)
        { 
            // tags not refered in the message
            finalMessage.assign(mMessage);
        }
        else
        {
            std::string lastPart;
            for (std::sregex_iterator i = tags_Iter; i != tags_end; ++i)
            {
                std::smatch tag_match = *i;
                auto aKey = tag_match.str(1);
                auto aValue = mTagMap.find(aKey);
                finalMessage.append(tag_match.prefix());
                if (aValue != mTagMap.end())
                {
                    finalMessage.append(aValue->second);
                }
                else
                { // Tag not found; keep the key as it is
                    finalMessage.append(tag_match.str(0));
                }
                lastPart = tag_match.suffix();
            }
            finalMessage.append(lastPart);
        }
        mLoggerImpl.log(mLevel, finalMessage, mTagMap, file, line, function);
    }
    else
    {
        mLoggerImpl.log(mLevel, mMessage, mTagMap, file, line, function);
    }
}


std::shared_ptr<AAALogger::MessageBuilder > AAALogger::prepare(Level level, const std::string& message) const
{
    return AAALogger::MessageBuilder::create(*mLoggerImpl, level, message);
}
std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::prepareFatal(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Fatal, message);
}

std::shared_ptr<AAALogger::MessageBuilder> AAALogger::prepareError(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Error, message);
}

std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::prepareWarn(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Warn, message);
}

std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::prepareInfo(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Info, message);
}

std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::prepareDebug(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Debug, message);
}

std::shared_ptr<AAALogger::MessageBuilder>  AAALogger::prepareTrace(const std::string& message) const {
    return AAALogger::MessageBuilder::create(*mLoggerImpl, Level::Trace, message);
}



/************************************************************************
*   Method             : L4C_StreamAppender::L4C_StreamAppender
*
*   Description        : Constructor
*
*************************************************************************/
L4C_StreamAppender::L4C_StreamAppender(std::ostream& output)
    : mOutput(output), mImmediateFlush(true)

{
    layout.reset(new log4cplus::PatternLayout(LOG4CPLUS_TEXT("%m")));
}

/************************************************************************
*   Method             : L4C_StreamAppender::L4C_StreamAppender
*
*   Description        : Constructor
*
*************************************************************************/
L4C_StreamAppender::L4C_StreamAppender(const log4cplus::helpers::Properties& properties)
    : Appender(properties),
    mOutput(std::cout), // @@TODO see for a better default value
    mImmediateFlush(true)
{

}

/************************************************************************
*   Method             : L4C_StreamAppender::L4C_StreamAppender
*
*   Description        : ~Destructor
*
*************************************************************************/
L4C_StreamAppender::~L4C_StreamAppender()
{
    mOutput.flush();
    destructorImpl();
}


/************************************************************************
*   Method             : L4C_StreamAppender::append
*
*   Description        : append the event to the appender (format & write on the stream)
*
*************************************************************************/
void L4C_StreamAppender::append(const log4cplus::spi::InternalLoggingEvent& event)
{
    layout->formatAndAppend(mOutput, event);
    if (mImmediateFlush) 
    {
        mOutput.flush();
    }
}



/************************************************************************
** AAAUdpAppender
* Inspired from log4cplus::Log4jUdpAppender
* registered as TripleA::AAAUdpAppender
* use a standard formating driven by the configured layout
*
*************************************************************************/

class LOG4CPLUS_EXPORT AAAUdpAppender : public log4cplus::Appender {
public:
    // Ctors
    AAAUdpAppender(const log4cplus::tstring& host, int port);
    AAAUdpAppender(const log4cplus::helpers::Properties & properties);

    // Dtor
    ~AAAUdpAppender();

    AAAUdpAppender(const AAAUdpAppender&) = delete;
    AAAUdpAppender& operator=(const AAAUdpAppender&) = delete;

    // Methods
    virtual void close();

protected:
    void openSocket();
    virtual void append(const log4cplus::spi::InternalLoggingEvent& event);

private:

    static inline void ReplaceAll(std::string &str, const std::string& from, const std::string& to)
    {
        size_t start_pos = 0;
        while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length(); // Handles case where 'to' is a substring of 'from'
        }
    }

    // Data
    log4cplus::helpers::Socket socket;
    log4cplus::tstring host;
    int port;
    log4cplus::tstring newLineReplacement; /* PMSTA-37933 - FME - 191119 - AAAUdpAppender must convert newline character */
    bool isConfigured;
};

/************************************************************************
*   Method             : AAAUdpAppender::AAAUdpAppender
*
*   Description        : Constructor
*
*************************************************************************/
AAAUdpAppender::AAAUdpAppender(const log4cplus::tstring& host_, int port_)
    : host(host_)
    , port(port_)
    , newLineReplacement("")
    , isConfigured(false)
{
    layout.reset(new log4cplus::PatternLayout(LOG4CPLUS_TEXT("%m")));
    openSocket();
}

/************************************************************************
*   Method             : AAAUdpAppender::AAAUdpAppender
*
*   Description        : Constructor
*
*************************************************************************/
AAAUdpAppender::AAAUdpAppender(const log4cplus::helpers::Properties & properties)
    : Appender(properties)
    , port(0)
    , isConfigured(false)
{
    host = properties.getProperty(LOG4CPLUS_TEXT("host"), LOG4CPLUS_TEXT("localhost"));
    isConfigured = properties.getInt(port, LOG4CPLUS_TEXT("port"));
    newLineReplacement = properties.getProperty(LOG4CPLUS_TEXT("newLineReplacement"), LOG4CPLUS_TEXT(""));

    if (isConfigured) 
    {
        openSocket();
    }
    else
    {
        log4cplus::helpers::getLogLog().warn(LOG4CPLUS_TEXT("AAAUdpAppender::AAAUdpAppender() - Not Configured - host=" + host + " port=" + properties.getProperty(LOG4CPLUS_TEXT("port"))));
    }
}

/************************************************************************
*   Method             : AAAUdpAppender::AAAUdpAppender
*
*   Description        : ~Destructor
*
*************************************************************************/
AAAUdpAppender::~AAAUdpAppender()
{
    destructorImpl();
}

/************************************************************************
*   Method             : AAAUdpAppender::close
*
*   Description        : close the socket
*
*************************************************************************/
void AAAUdpAppender::close()
{
    log4cplus::helpers::getLogLog().debug(LOG4CPLUS_TEXT("Entering AAAUdpAppender::close()..."));

    socket.close();
    closed = true;
}

/************************************************************************
*   Method             : AAAUdpAppender::openSocket
*
*   Description        : open the socket
*
*************************************************************************/
void AAAUdpAppender::openSocket()
{
    if (!socket.isOpen())
    {
        log4cplus::helpers::getLogLog().debug(LOG4CPLUS_TEXT("AAAUdpAppender::openSocket() - opening socket to - host=" + host + " port=" + std::to_string(port)));

        socket = log4cplus::helpers::Socket(host, static_cast<unsigned short int >(port), true);
    }
}

/************************************************************************
*   Method             : AAAUdpAppender::append
*
*   Description        : append the event to the appender (format & write on the socket)
*
*************************************************************************/
void AAAUdpAppender::append(const log4cplus::spi::InternalLoggingEvent& event)
{
    if (isConfigured)
    {

        log4cplus::tstring & str = formatEvent(event);

        if (!socket.isOpen())
        {
            openSocket();
            if (!socket.isOpen())
            {
                log4cplus::helpers::getLogLog().error(LOG4CPLUS_TEXT("AAAUdpAppender::append()") LOG4CPLUS_TEXT(" - Cannot connect to server - " + str));
                return;
            }
        }

        if (newLineReplacement.length() > 0) /* PMSTA-37933 - FME - 191119 - AAAUdpAppender must convert newline character */
        {
            ReplaceAll(str, "\n", newLineReplacement);
        }

        bool ret = socket.write(str);

        if (!ret)
        {
            log4cplus::helpers::getLogLog().error(LOG4CPLUS_TEXT("AAAUdpAppender::append() - Write failed - " + str));
        }
    }
}

/************************************************************************
** AAABackwardErrorLayout
*************************************************************************/

class LOG4CPLUS_EXPORT AAABackwardErrorLayout : public ::log4cplus::Layout {
public:

    AAABackwardErrorLayout(const log4cplus::helpers::Properties& properties);
    ~AAABackwardErrorLayout();

    AAABackwardErrorLayout(const AAABackwardErrorLayout&) = delete;
    AAABackwardErrorLayout& operator=(const AAABackwardErrorLayout&) = delete;

    virtual void formatAndAppend(log4cplus::tostream& output, const log4cplus::spi::InternalLoggingEvent& event);

private:

    bool mustPrintStack;
};

/************************************************************************
*   Method             : AAABackwardErrorLayout::AAABackwardErrorLayout
*
*   Description        : Constructor
*
*************************************************************************/
AAABackwardErrorLayout::AAABackwardErrorLayout(const log4cplus::helpers::Properties & properties)
{
    mustPrintStack = false;

    bool hasPrintStack = properties.exists("printCallstack");

    if (hasPrintStack)
        properties.getBool(mustPrintStack, "printCallstack");
}

/************************************************************************
*   Method             : AAABackwardErrorLayout::~AAABackwardErrorLayout
*
*   Description        : Destructor
*
*************************************************************************/
AAABackwardErrorLayout::~AAABackwardErrorLayout()
{
}

/************************************************************************
*   Method             : AAABackwardErrorLayout::formatAndAppend
*
*   Description        : Format the Job
*
*************************************************************************/
void AAABackwardErrorLayout::formatAndAppend(log4cplus::tostream & output, const log4cplus::spi::InternalLoggingEvent & event)
{
    // TO BE REMOVED: BEGIN
    // TO BE REMOVED: END

    std::string string;

    /*
    ** DateTimeInfo #1
    */

    const log4cplus::helpers::Time& time = event.getTimestamp();

    char backup = output.fill();

#define HAS_LOG4CPLUS_NEW_TIME_HELPER  LOG4CPLUS_MAKE_VERSION(2, 0, 0)

#if LOG4CPLUS_VERSION > HAS_LOG4CPLUS_NEW_TIME_HELPER
    output
        << "DATE        : "
        << log4cplus::helpers::getFormattedTime("%Y/%m/%d  %H:%M:%S.", time)
        << std::setw(6) << std::right << std::setfill('0') << log4cplus::helpers::microseconds_part(time)
        << LOG4CPLUS_TEXT("\n");
#else   // log4cplus 1.2.1
    output
        << "DATE        : "
        << time.getFormattedTime("%Y/%m/%d  %H:%M:%S.")
        << std::setw(6) << std::right << std::setfill('0') << time.usec()
        << LOG4CPLUS_TEXT("\n");
#endif

    output.fill(backup);

    /*
    ** AAAVersionInfo #1
    */

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::AAAVersion, string);

    output
        << "VERSION     : "
        << std::left << string
        << LOG4CPLUS_TEXT("\n");

    /*
    ** MsgTypeInfo #2
    */

    string.clear();
    string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::Type).c_str());

    output
        << "TYPE        : "
        << std::setw(20) << std::left << string;

    /*
    ** ModeInfo #3
    */

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::Mode, string);

    if (!string.compare("GUI"))
    {
        output
            << "GUI_INFO : //"
            << LOG4CPLUS_TEXT("\n");
    }
    else
        if (!string.compare("BATCH"))
        {
            output
                << "BATCH_INFO : //"
                << LOG4CPLUS_TEXT("\n");
        }
        else
            if (!string.compare("DDLGEN"))
            {
                output
                    << "DDLGEN_INFO : //"
                    << LOG4CPLUS_TEXT("\n");
            }
    if (!string.compare("SQL"))
    {
        output
            << "SQL_INFO : //"
            << LOG4CPLUS_TEXT("\n");
    }
    if (!string.compare("SERVER"))
    {
        output
            << "OSERVER_INFO : ";

        string.clear();
        EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::ServerName, string);

        output
            << string
            << " THREAD : ";

        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::ThreadType).c_str());

        unsigned char c = 's';

        if (!string.compare("Client"))
            c = 'c';

        output
            << c
            << " - ";

        string.clear();
        EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::ProcessID, string);

        output
            << "pid#"
            << string
            << "-";

        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::ThreadID).c_str());

        output
            << "tid#"
            << string;

        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::ThreadUser).c_str());

        output
            << " USER : "
            << string;

        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::RPC).c_str());

        if (!string.empty())
            output
            << " RPC : "
            << string;

        output
            << LOG4CPLUS_TEXT("\n");
    }

    /*
    ** ParamInfo #4
    */

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::Param, string);

    if (!string.empty())
    {
        output
            << "PARAM       : "
            << std::left << string
            << LOG4CPLUS_TEXT("\n");
    }

    /*
    ** UserInfo #5
    */

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::User, string);

    output
        << "USER        : "
        << std::setw(20) << std::left << string
        << LOG4CPLUS_TEXT("\n");

    /*
    ** SysLoginInfo #6
    */

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::SysLogin, string);

    output
        << "SYS LOGIN   : "
        << std::setw(20) << std::left << string;

    string.clear();
    string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::HostName).c_str());

    output
        << "HOSTNAME : "
        << std::setw(20) << std::left << string;

    string.clear();
    EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::Mode, string);

    if (string.compare("GUI"))
    {
        string.clear();
        EnvironmentCache::getInstance().getEnvironment(EnvironmentCache::Key::Display, string);

        output
            << "DISPLAY : "
            << std::setw(20) << std::left << string;
    }

    output
        << LOG4CPLUS_TEXT("\n");

    /*
    ** FileInfo #7
    */

    std::string line;

    output
        << "FILE        : "
        << event.getFile()
        << "  LINE :"
        << SYS_ToString(event.getLine())
        << LOG4CPLUS_TEXT("\n");

    /*
    ** MsgText
    */
    string.clear();
    string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::ServerName).c_str());

    if (!string.empty())
    {
        output
            << "FROM SERVER : "
            << string
            << LOG4CPLUS_TEXT("\n");
    }

    string.clear();
    string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::Procedure).c_str());

    if (!string.empty())
    {
        output
            << "PROC        : "
            << string
            << LOG4CPLUS_TEXT("\n");
    }

    output
        << "MESSAGE     : "
        << event.getMessage()
        << LOG4CPLUS_TEXT("\n");

    /*
    ** CallStack
    */

    if (mustPrintStack)
    {
        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::Exception).c_str());

        if (!string.empty())
            output
            << "EXCEPTION   : "
            << LOG4CPLUS_TEXT("\n")
            << string;

        string.clear();
        string = event.getMDC(AAALoggerImpl::getMdcKeyName(AAALogger::MDC_keys::CallStack).c_str());

        if (!string.empty())
            output
            << "CALLSTACK   : "
            << LOG4CPLUS_TEXT("\n")
            << string;
    }

    /*
    **
    */

    output
        << "--------------------------------------------------"
        << LOG4CPLUS_TEXT("\n");

    // logger implementation of log4cplus (e.g  PatternConverter::formatAndAppend) are not flushing
    // output.flush();
}

/************************************************************************
** AAAErrorNumberFilter
*************************************************************************/

class LOG4CPLUS_EXPORT AAAErrorNumberFilter : public ::log4cplus::spi::Filter {
public:

    AAAErrorNumberFilter(const log4cplus::helpers::Properties& properties);
    AAAErrorNumberFilter(const AAAErrorNumberFilter&) = delete;
    AAAErrorNumberFilter& operator=(const AAAErrorNumberFilter&) = delete;

    ~AAAErrorNumberFilter();

    virtual log4cplus::spi::FilterResult decide(const log4cplus::spi::InternalLoggingEvent& event) const;

private:

    bool getUInProperty(unsigned int & value, const log4cplus::helpers::Properties& properties, log4cplus::tstring const & key);

    unsigned int mErrorToMatchMinRange;
    unsigned int mErrorToMatchMaxRange;

    bool mAcceptOnMatch;
};

/************************************************************************
*   Method             : AAAErrorNumberFilter::getUInProperty
*
*   Description        : Parse a property
*
*************************************************************************/
bool AAAErrorNumberFilter::getUInProperty(
    unsigned int & value,
    const log4cplus::helpers::Properties& properties,
    log4cplus::tstring const & key)
{
    log4cplus::tstring string;

    bool status;

    if (!properties.getString(string, key)) {
        return false;
    }

    value = QString(string.c_str()).toUInt(&status, 0);

    return status;
}

/************************************************************************
*   Method             : AAAErrorNumberFilter::AAAErrorNumberFilter
*
*   Description        : Constructor
*
*************************************************************************/
AAAErrorNumberFilter::AAAErrorNumberFilter(const log4cplus::helpers::Properties& properties)
{
    unsigned int errorToMatch = 0;

    mErrorToMatchMinRange = 0;
    mErrorToMatchMaxRange = 0;

    mAcceptOnMatch = false;

    if (getUInProperty(errorToMatch, properties, "ErrorToMatch"))
    {
        mErrorToMatchMinRange = errorToMatch;
        mErrorToMatchMaxRange = errorToMatch;
    }

    getUInProperty(mErrorToMatchMinRange, properties, "ErrorToMatchMinRange");
    getUInProperty(mErrorToMatchMaxRange, properties, "ErrorToMatchMaxRange");

    properties.getBool(mAcceptOnMatch, "AcceptOnMatch");
}

/************************************************************************
*   Method             : AAAErrorNumberFilter::~AAAErrorNumberFilter
*
*   Description        : Destructor
*
*************************************************************************/
AAAErrorNumberFilter::~AAAErrorNumberFilter()
{
}

/************************************************************************
*   Method             : AAAErrorNumberFilter::decide
*
*   Description        : Decide if the message must be filtered or not
*
*************************************************************************/
log4cplus::spi::FilterResult AAAErrorNumberFilter::decide(const log4cplus::spi::InternalLoggingEvent& event) const
{
    log4cplus::tstring string = event.getMDC("MSG_NUMBER");

    unsigned long value;

    if (!string.empty())
    {
        std::stringstream ss(string);

        ss >> value;

        if (mAcceptOnMatch && value >= mErrorToMatchMinRange && value <= mErrorToMatchMaxRange)
            return log4cplus::spi::FilterResult::ACCEPT;
        else
            if (!mAcceptOnMatch && value >= mErrorToMatchMinRange && value <= mErrorToMatchMaxRange)
                return log4cplus::spi::FilterResult::DENY;
    }

    return log4cplus::spi::FilterResult::NEUTRAL;
}




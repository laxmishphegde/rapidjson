/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Includes
*************************************************************************/
//#include <sys/stat.h>
//#include <assert.h>
//#include <ctype.h>
//#include <algorithm>

#include <cstdio>

#ifdef AIX
#include <math.h>
#else
//#include <cmath>
#endif

//#define MATH_H
//#define STDIO_H
//#define STRING_H
//#define STDLIB_H

#include "unidef.h"     /* Mandatory */

#include "permval.h"
#include "sysformat.h"

#ifndef DBA_H
#include "dba.h"
#endif

#ifndef HIER_H
#include "hier.h"
#endif

#include "date.h"
#include "fus.h"
#include "proc.h"
#include "gen.h"
#include "serv.h"
#include "dfttestfusion.h"

#include "ope.h"
#include "dbaexec.h"



#ifdef AAAPURIFY
#ifdef NT
#include <pure.h>   /* PMSTA08746 - 061009 - PMO */
#endif
#endif


/************************************************************************
**
** Static data used by SQL hooks
**
*************************************************************************/
static DATAFILEFUSION_STP SV_DataFileFusion = NULL;


/************************************************************************
**      Static Data Definitions
*************************************************************************/
static const char separatorLine[] = "------------------------------------------------------\n";
static /*const*/ ID_T ID_1        = 1;

/*******************************************************************************
**      Local declarations
*******************************************************************************/
STATIC bool DFT_CompareDynFld       (const FUSIONDIFF_STP, const char *, const DBA_DYNFLD_STP, const DBA_DYNFLD_STP);
STATIC void DFT_DynStLoadXmlFields  (DBA_DYNFLD_STP, const DBA_DYNDEF_STP, gzFile);
STATIC bool DFT_XmlGetNextTag       (char *, size_t, gzFile);
STATIC bool DFT_SeekTag(gzFile hgzFile, const char * pszTag, const char * pszEndTag = NULL);


/************************************************************************
**
**  Function    :   DFT_XMLDump()
**
**  Description :   Dump a dynamic structure into a XML dump file in $AAAMSG/xml_dump_000.txt
**                  where 000 is a counter
**
**  Argument    :   dynStp      Dynamic structure to dump
**
**  Return      :   true    if of
**                  false   if error
**
**  Last modif. :   PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**
*************************************************************************/
bool DFT_XMLDump (const DBA_DYNFLD_STP dynStp)
{
    static int  iCounter    = 0;
    char        szPath[256];
    bool        ret         = false;

    snprintf(szPath, sizeof (szPath),"%s/xml_dump_%03d.xml.gz",SYS_GetEnv("AAAMSG"), iCounter++);

    gzFile hgzFile = gzopen(szPath, "wb");

    if (NULL != hgzFile)
    { /* Ok */

        DBA_CFIELDDEF_STP   fieldStp;
        FLAG_T              allocFlg=FALSE;
        char                buffer[256];
        char                fieldName[256];
        char                fieldValue[256];
        DBA_DYNST_ENUM      dynStEn             = GET_DYNSTENUM(dynStp);
        OBJECT_ENUM         object              = GET_OBJ_DYNST(dynStEn);

        gzprintf(hgzFile, "<object>\n<entity>\n");
        gzprintf(hgzFile, "<name>%s</name>\n", object >=0?OBJ_V2N(object):"Null Entity");
        gzprintf(hgzFile, "<dynSt>%s</dynSt>\n", dynStEn>=0?DYN_V2N(dynStEn):"NullDynSt");
        gzprintf(hgzFile, "</entity>\n");

        gzprintf(hgzFile, "<fields>\n");

        for (FIELD_IDX_T fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL; fld++)
        {
            gzprintf(hgzFile, "<field>");
            DBA_GetFieldName(fieldName, fieldStp);

            gzprintf(hgzFile, "<name>%s</name>", fieldName);

            DBA_GetFieldDataType ( buffer, dynStp, fld, fieldStp, FALSE) ;
            gzprintf(hgzFile, "<type>%s</type>", buffer);

            DBA_GetFieldValue(fieldValue, sizeof (fieldValue), dynStp, fld, FALSE);
            gzprintf(hgzFile, "<value>%s</value>", fieldValue);

            gzprintf(hgzFile, "<rank>%d</rank>", fld);

            gzprintf(hgzFile, "<isnull>%s</isnull>", IS_NULLFLD(dynStp, fld)==TRUE?"TRUE":"FALSE");

            gzprintf(hgzFile, "</field>\n");

            if (TRUE == allocFlg)
            {
                FREE(fieldStp);
            }
        } /* End for */

        gzprintf(hgzFile, "</fields>\n</object>\n");

        gzclose(hgzFile);

        ret = true;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DFT_XMLDumpLoad()
**
**  Description :   Load a dynamic structure from a XML dump file in $AAAMSG/xml_dump_000.txt
**                  where 000 is a counter
**
**  Argument    :   pszFileName file name of the xml dump
**
**  Return      :   Dynamic structure allocated from the dump
**                  NULL if error
**
**  Last modif. :   PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**
*************************************************************************/
DBA_DYNFLD_STP DFT_XMLDumpLoad(const char * pszFileName)
{
    DBA_DYNFLD_STP  dynStp  = NULL;
    char            szPath[256];

    snprintf(szPath, sizeof (szPath),"%s/%s",SYS_GetEnv("AAAMSG"), pszFileName);

    gzFile          hgzFile = gzopen(szPath, "rb");

    if (NULL != hgzFile)
    { /* Ok */

        if (true == DFT_SeekTag(hgzFile, "<dynSt>", NULL))
        {
            char szDyn[256];

            DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile);

            if (0 != szDyn[0])
            {
                DBA_DYNDEF_STP dynDefStp = DBA_GetDynDefStTab(szDyn);

                if (NULL != dynDefStp)
                {
                    dynStp = ALLOC_DYNST(dynDefStp->dynStPos);
                }

                if ( NULL != dynStp && true == DFT_SeekTag(hgzFile, "<fields>"))
                {
                    DFT_DynStLoadXmlFields(dynStp, dynDefStp, hgzFile);
                }
            }
        }

        gzclose(hgzFile);
    }

    return dynStp;
}


/************************************************************************
**
**  Function    :   DFT_SeekTag()
**
**  Description :   Read the file until the tag is reached
**
**  Argument    :   hgzFile     Handle of the compressed xml fusion trace file
**                  pszTag      Read the file until the tag is reached
**                  pszEndTag   End tag
**
**  Return      :   true    if found
**                  false   for not found
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**
*************************************************************************/
STATIC bool DFT_SeekTag(gzFile hgzFile, const char * pszTag, const char * pszEndTag)
{
    int             iChar;
    bool            bRet            = false;
    int             iState          = 0;
    int             iStateEnd       = 0;            /* PMSTA-15298 - 040213 - PMO */
    const char *    pCurrentChar    = NULL;
    const char *    pCurrentCharEnd = NULL;         /* PMSTA-15298 - 040213 - PMO */

    for(;;)
    {
        iChar = gzgetc (hgzFile);

        if (iChar > 0)
        {
            switch (iState)
            {
                case 0: /* Start */
                    pCurrentChar = pszTag;
                    if (unsigned(*pCurrentChar) == unsigned(iChar))
                    { /* Found one same character */
                        pCurrentChar++;
                        iState++;
                    }
                    break;

                case 1:
                    if (unsigned(*pCurrentChar) == unsigned(iChar))
                    { /* Found one same character */
                        pCurrentChar++;
                    }
                    else
                    {
                        iState--;
                    }
                    break;
            }

            if (0 == *pCurrentChar)
            { /* Found */
                bRet = true;
                break;
            }

            /* PMSTA-15298 - 040213 - PMO */
            if (NULL != pszEndTag)
            {
                switch (iStateEnd)
                {
                    case 0: /* Start */
                        pCurrentCharEnd = pszEndTag;
                        if (unsigned(*pCurrentCharEnd) == unsigned(iChar))
                        { /* Found one same character */
                            pCurrentCharEnd++;
                            iStateEnd++;
                        }
                        break;

                    case 1:
                        if (unsigned(*pCurrentCharEnd) == unsigned(iChar))
                        { /* Found one same character */
                            pCurrentCharEnd++;
                        }
                        else
                        {
                            iStateEnd--;
                        }
                        break;
                }

                if (0 == *pCurrentCharEnd)
                { /* End tag encoutered */
                    bRet = false;
                    break;
                }
            }
        }

        if (-1 == iChar)
        {
            printf("Error while reading\n");
            break;
        }
    } /* End for */

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_XmlGetNextTag()
**
**  Description :   Copy into szDyn until < or > or the end of file is reached
**
**  Argument    :   szDyn       String where to copy
**                  hgzFile     Handle of the compressed xml fusion trace file
**
**
**  Return      :   true    if found
**                  false   for not found
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC bool DFT_XmlGetNextTag(char * szDyn, size_t size, gzFile hgzFile)
{
    int     iChar;
    bool    bRet = false;

    /*
     *  Initialization
     */
    szDyn[0] = 0;

    for(;;)
    {
        iChar = gzgetc(hgzFile);

        if (iChar > 0)
        {
            if ('<' == iChar || '>' == iChar)
            { /* Stop the copy of the tag */
                bRet = true;
                break;
            }
            else
            { /* Add the current char */
                if (0 == szDyn[0] && ( ' ' == iChar || '\n' == iChar))
                { /* Skip the first blank characters */
                }
                else
                {
                    size_t len = strlen(szDyn);

                    snprintf(
                        szDyn + len, size - len, "%c", iChar);
                }
            }
        }
        else
        {
            if (-1 == iChar)
            { /* Error */
                szDyn[0] = 0;
                printf("Error while reading\n");
                break;
            }
        }
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_ConvertUtf8ToUnicode()
**
**  Description :   Convert an UTF8 string into a UChar string
**
**  Argument    :   unicodeStr  Target Unicode String
**                  size        Size of the target
**                  src         Source UTF8 string
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC UChar * DFT_ConvertUtf8ToUnicode(UChar * unicodeStr, const size_t size, const char * src)
{
    (void)ICU4AAA_ConvertFromUTF8(src , SYS_StrLen(src), unicodeStr, (int)(size / sizeof (UChar)), NULL);

    return unicodeStr;
}


/************************************************************************
**
**  Function    :   DFT_DynStLoadXmlFields()
**
**  Description :   Parse the xml structure and fill each field of the dynStp structure
**
**  Argument    :   dynStp      Dynamic structure to fill
**                  dynDefStp   Definition of the structure
**                  hgzFile     Handle of the compressed xml fusion trace file
**
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                  PMSTA-14362 - 310512 - PMO : Fusion engine is not working well with portfolio position sets (PPS) and big portfolios
**                  PMSTA-19231 - 060115 - PMO : Set the Sun compiler to C++11 like all other compilers
*************************************************************************/
STATIC void DFT_DynStLoadXmlFields(DBA_DYNFLD_STP dynStp, const DBA_DYNDEF_STP dynDefStp, gzFile hgzFile)
{
    char    szDyn[256];
    FIELD_IDX_T     iClue = 0;
    OBJECT_ENUM objectToFill;
    (void)DBA_GetObjectEnum(GET_DYNSTENUM(dynStp), &objectToFill);

    FIELD_IDX_T   fldNbr;
    if (NullEntityCst == objectToFill)
    {
        for (fldNbr = 0; NULL != (dynDefStp->cFieldTab[fldNbr]).fieldPosPtr ; fldNbr++);
    }
    else
    {
        fldNbr = GET_FLD_NBR(GET_EDITGUIST(objectToFill));
    }

    for(;;)
    {
        if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
        {
            break;
        }

        if (0 == strcmp ("field" , szDyn))
        { /* Found a field */
            if (true == DFT_SeekTag(hgzFile, "<name>"))
            {
                /* Extract the field name */
                DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile);

                if (true == DFT_SeekTag(hgzFile, "<type>"))
                {
                    char szType[32];

                    /* Extract the field type */
                    DFT_XmlGetNextTag(szType, sizeof(szDyn), hgzFile);

                    if (true == DFT_SeekTag(hgzFile, "<value>"))
                    {
                        char szValue[512];

                        /* Extract the field value */
                        DFT_XmlGetNextTag(szValue, sizeof(szDyn), hgzFile);

                        if (true == DFT_SeekTag(hgzFile, "</field>"))
                        {
                            /* PMSTA-24007 - LJE - 161215 */
                            FIELD_IDX_T idx = DBA_GetIdxFieldName(dynDefStp->cFieldTab, szDyn, fldNbr, iClue);

                            iClue = static_cast<FIELD_IDX_T> (idx + 1);

                            if (-1 != idx)
                            { /* Field found */

                                if (0 != strcmp("NULL", szValue))
                                { /* Field have a value */

                                    switch (GET_FLD_DTP(dynStp, idx))
                                    {
                                    case NullDataType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case CodeType:
                                        SET_CODE(dynStp, idx, szValue);
                                        break;

                                    case DateType:
                                        if (strlen(szValue) > 9)
                                        {
                                            szValue[2] = 0;
                                            szValue[5] = 0;
                                            DATE_T date = DATE_Put((YEAR_T)atoi(szValue + 6), (MONTH_T)atoi(szValue + 3), (DAY_T)atoi(szValue));
                                            SET_DATE(dynStp, idx, date);
                                        }
                                        break;

                                    case DatetimeType:
                                        if (strlen(szValue) > 18)
                                        {
                                            szValue[16] = 0;
                                            szValue[13] = 0;
                                            szValue[10] = 0;
                                            szValue[5] = 0;
                                            szValue[2] = 0;
                                            DATETIME_T dateTime = { DATE_Put((YEAR_T)atoi(szValue + 6), (MONTH_T)atoi(szValue + 3), (DAY_T)atoi(szValue))
                                                , TIME_Put((HOUR_T)atoi(szValue + 11), (MINUTE_T)atoi(szValue + 14), (SECOND_T)atoi(szValue + 17))
                                            };

                                            SET_DATETIME(dynStp, idx, dateTime);
                                        }
                                        break;

                                    case EnumType:
                                    {
                                        ENUM_T enum_value = (ENUM_T)atoi(szValue);
                                        SET_ENUM(dynStp, idx, enum_value);
                                    }
                                    break;

                                    case ExchangeType:
                                    {
                                        EXCHANGE_T tmpExchange = atof(szValue);
                                        SET_EXCHANGE(dynStp, idx, tmpExchange);
                                    }
                                    break;

                                    case FlagType:
                                    {
                                        FLAG_T flag = (FLAG_T)atoi(szValue);
                                        SET_FLAG(dynStp, idx, flag);
                                    }
                                    break;

                                    case DictType:
                                    case IdType:
                                    {
                                        ID_T id = (ID_T)atof(szValue);    /* DLA - PMSTA08801 - 100511 */
                                        SET_ID(dynStp, idx, id);
                                    }
                                    break;

                                    case InfoType:
                                        SET_INFO(dynStp, idx, szValue);
                                        break;

                                    case IntType:
                                    {
                                        INT_T tmpInt = (INT_T)atoi(szValue);
                                        SET_INT(dynStp, idx, tmpInt);
                                    }
                                    break;

                                    case LongnameType:
                                    case MaskType:
                                    case MethodType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case NameType:
                                        SET_NAME(dynStp, idx, szValue);
                                        break;

                                    case NoteType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case NumberType:
                                    {
                                        NUMBER_T number = atof(szValue);
                                        SET_NUMBER(dynStp, idx, number);
                                    }
                                    break;

                                    case PercentType:
                                    {
                                        PERCENT_T percent = atof(szValue);
                                        SET_PERCENT(dynStp, idx, percent);
                                    }
                                    break;

                                    case PeriodType:
                                    {
                                        PERIOD_T tmpPeriod = (PERIOD_T)atoi(szValue);
                                        SET_PERIOD(dynStp, idx, tmpPeriod);
                                    }
                                    break;

                                    case PhoneType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case SmallintType:
                                    {
                                        SMALLINT_T tmpSmall = (SMALLINT_T)atoi(szValue);
                                        SET_SMALLINT(dynStp, idx, tmpSmall);
                                    }
                                    break;

                                    case SysnameType:
                                    case TextType:
                                    case TimeType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case TinyintType:
                                    {
                                        TINYINT_T tmpTiny = (TINYINT_T)atoi(szValue);
                                        SET_TINYINT(dynStp, idx, tmpTiny);
                                    }
                                    break;

                                    case YearType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case AmountType:
                                    {
                                        AMOUNT_T number = atof(szValue);
                                        SET_AMOUNT(dynStp, idx, number);
                                    }
                                    break;

                                    case ShortinfoType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case LongamountType:
                                    {
                                        LONGAMOUNT_T number = atof(szValue);
                                        SET_LONGAMOUNT(dynStp, idx, number);
                                    }
                                    break;

                                    case UniNoteType:
                                    {
                                        UChar unicodeStr[512];

                                        SET_UNOTE(dynStp, idx, DFT_ConvertUtf8ToUnicode(unicodeStr, sizeof(unicodeStr), szValue));
                                    }
                                    break;

                                    case UniInfoType:
                                    {
                                        UChar unicodeStr[512];

                                        SET_UINFO(dynStp, idx, DFT_ConvertUtf8ToUnicode(unicodeStr, sizeof(unicodeStr), szValue));
                                    }
                                    break;

                                    case BlobType:
                                    case LongintType:
                                    case UrlType:
                                    case UniCodeType:
                                    case UniLongnameType:
                                    case UniNameType:
                                    case UniPhoneType:
                                    case UniShortinfoType:
                                    case UniSysnameType:
                                    case UniTextType:
                                    case UniUrlType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case TimeStampType:
                                    {
                                        TIMESTAMP_T timeStamp;
                                        if (strcmp("NULL", szValue))
                                        {
                                            sscanf(szValue, szFormatTimeStampSScanf, &timeStamp);
                                            SET_TIMESTAMP(dynStp, idx, timeStamp);
                                        }
                                    }
                                    break;

                                    case BinaryType:
                                    case ArrayType:
                                    case MultiArrayType:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;

                                    case ExtensionType:                     /* PMSTA-14362 - 310512 - PMO */
                                        SET_NULL_EXTENSION(dynStp, idx);
                                        break;

                                    case LongStringType:
                                        SET_LONGSTRING(dynStp, idx, szValue);
                                        break;

                                    case PriceType:
                                        {
                                        PRICE_T tmpPrice = atof(szValue);
                                        SET_PRICE(dynStp, idx, tmpPrice);
                                        }
                                        break;

                                    case PtrType:
                                    case VarInfoType:
                                    case VarNoteType:
                                    case VarNameType:
                                    case VarLongnameType:
                                    case VarStringType:
                                    case VarTextType:
                                    default:
                                        assert(1 == dynStp[idx].dataType); /* Please code this conversion :-) */
                                        break;
                                    }
                                }
                                else
                                { /* The field is empty */
                                    SET_NULL(dynStp, idx, dynStp[idx].dataType);
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        { /* Another tag */
            if (0 == strcmp ("/fields" , szDyn))
            { /* End of fields */
                break;
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadXmlRecord()
**
**  Description :   Alocate the structure, parse the xml structure and fill the dynStp structure
**
**  Argument    :   hgzFile     Handle of the compressed xml fusion trace file
**                  bLoadObject If the object id must be loaded into pObjectId
**                  pObjectId   Pointer on the buffer that must be filled
**
**  Return      :   A Filled dynamic structure
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
*************************************************************************/
STATIC DBA_DYNFLD_STP DFT_LoadXmlRecord(gzFile hgzFile, const bool bLoadObject = false, char * pObjectId = NULL)
{
    DBA_DYNFLD_STP  dynStp    = NULL;
    DBA_DYNDEF_STP  dynDefStp = NULL;
    char            szDyn[256];

    /* Check also the P&L */
    if (true == bLoadObject && NULL != pObjectId)   /* PMSTA-6921 - 311008 - PMO */
    {
       *pObjectId = 0;

       if (true == DFT_SeekTag(hgzFile, "<object id=\""))
       {
           char szObjectId[256];

            if (true == DFT_XmlGetNextTag(szObjectId, sizeof(szObjectId), hgzFile))
            {
                const size_t length = strlen (szObjectId);
                if ( length > 0 )
                {   /* Remove the last character */
                    szObjectId[length -1] = 0;
                }

                strcpy(pObjectId, szObjectId);
            }
       }
    }

    if (  true == DFT_SeekTag(hgzFile, "<entity>")
       && true == DFT_SeekTag(hgzFile, "<dynSt>")
       )
    {
        DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile);

        if (0 != szDyn[0])
        {
            dynDefStp = DBA_GetDynDefStTab(szDyn);

            if (NULL != dynDefStp)
            {
                dynStp = ALLOC_DYNST(dynDefStp->dynStPos);
            }

            if ( NULL != dynStp && true == DFT_SeekTag(hgzFile, "<fields>"))
            {
                DFT_DynStLoadXmlFields(dynStp, dynDefStp, hgzFile);
            }
        }
    }

    return dynStp;
}

/************************************************************************
**
**  Function    :   DFT_LoadSystemParameter()
**
**  Description :   Load system parameters from the xml file and put in pDataFileFusion
**
**  Argument    :   hgzFile             Handle of the compressed xml fusion trace file
**                  pDataFileFusion     Structure with all data stored in the xml file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**
*************************************************************************/
STATIC void DFT_LoadSystemParameter(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion)
{
    if ( true == DFT_SeekTag(hgzFile, "<FusionSystemParam>"))
    {
        char szAppl[32];
        char szDyn[256];

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            /* Copy the system parameter */
            snprintf(szAppl, sizeof(szAppl), "%s", szDyn);

            if (     0 == strncmp ("Appl", szDyn, 4)
               && true == DFT_SeekTag(hgzFile, "<value>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            { /* Found a system parameter and his value */
                pDataFileFusion->setSetSystemParameter(szAppl, atoi (szDyn));
            }
            else
            { /* Another tag */
                if (0 == strcmp ("/FusionSystemParam", szDyn))
                { /* End of fields */
                    break;
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DFT_LoadFusArg()
**
**  Description :   Load the fist FusArg from the xml file and put in pDataFileFusion
**
**  Argument    :   hgzFile             Handle of the compressed xml fusion trace file
**                  pDataFileFusion     Structure with all data stored in the xml file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
*************************************************************************/
STATIC void DFT_LoadFusArg(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion)
{
    if ( true == DFT_SeekTag(hgzFile, "<fusArg>"))
    {
        char            szDyn[256];
        int             iStep;
        FUSIONSTEP_ST   tagFusionStep;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (     0 == strcmp ("object id=\"fusArg\"", szDyn)
               && true == DFT_SeekTag(hgzFile, "<step>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            { /* Found a field */
                iStep = atoi (szDyn);

                DBA_DYNFLD_STP dynStp = DFT_LoadXmlRecord(hgzFile);
                pDataFileFusion->addFusArg(dynStp);

                tagFusionStep.set(iStep, 0, SD_FUSARG, dynStp);     /* PMSTA-8062 - 190509 - PMO */
                pDataFileFusion->addFusionStep(&tagFusionStep);
            }
            else
            { /* Another tag */
                if (0 == strcmp ("/fusArg", szDyn))
                { /* End of fields */
                    break;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadPtf()
**
**  Description :   Load the Ptf from the xml file and put in pDataFileFusion
**
**  Argument    :   hgzFile         Handle of the compressed xml fusion trace file
**                  pszFileFusion   Compressed xml trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
*************************************************************************/
STATIC void DFT_LoadPtf(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion)
{
    if (  true == DFT_SeekTag(hgzFile, "<FUS_PortfolioProcessing>")
       && true == DFT_SeekTag(hgzFile, "<ptfTab>"))
    {
        char            szDyn[256];
        int             iStep;
        FUSIONSTEP_ST   tagFusionStep;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (0 == strcmp ("ptf", szDyn)
               && true == DFT_SeekTag(hgzFile, "<step>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            { /* Found a field */
                iStep = atoi (szDyn);

                DBA_DYNFLD_STP dynStp = DFT_LoadXmlRecord(hgzFile);
                pDataFileFusion->addPtf(dynStp);

                tagFusionStep.set(iStep, 0, SD_PORTFOLIO, dynStp);      /* PMSTA-8062 - 190509 - PMO */
                pDataFileFusion->addFusionStep(&tagFusionStep);
            }
            else
            { /* Another tag */
                if (0 == strcmp ("/ptfTab", szDyn))
                { /* End of fields */
                    break;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :   sort()
**
**  Description :   After a load data must be sorted because the search use bsearch
**
**  Argument    :   fnCmp   Function used for sorting
**
**  Return      :   None
**
**  Last modif. :   PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::sort(int (*fnCmp)(const void *p1, const void *p2))
{
    qsort(tabFusionStep, nbEntriesFusionStep, sizeof(FUSIONSTEP_ST), fnCmp);
}




/************************************************************************
**
**  Function    :   addEntry()
**
**  Description :   add an entry in the tab and growth it if needs
**
**  Argument    :   tab         Array where to add the element at the end
**                  nbEntries   # of entries in tab. Incremented
**                  pRemapID    Pointer to the structure to add
**
**  Return      :   None
**
**  Last modif. : PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::addEntry(REMAPID_STP & tab, int & nbEntries, REMAPID_STP pRemapID)
{
    const size_t    allocateSize = sizeof (REMAPID_ST) * (nbEntries + 1);
    REMAPID_STP     tmpTab       = (REMAPID_STP) REALLOC(tab , allocateSize);

    if (NULL != tmpTab)
    { /* Ok */
        tab = tmpTab;
        tab[nbEntries] = *pRemapID;
        nbEntries++;
    }
    else
    { /* Memory error */
        fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)allocateSize);
        abort();
    }
}



/************************************************************************
**
**  Function    :   addEntry()
**
**  Description :   add an entry in the tab and growth it if needs
**
**  Argument    :   tab         Array where to add the element at the end
**                  nbEntries   # of entries in tab. Incremented
**                  pDynFld     Pointer to the structure to add
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::addEntry(DBA_DYNFLD_STP * & tab, int & nbEntries, DBA_DYNFLD_STP pDynFld)
{
    const size_t        allocateSize = sizeof (DBA_DYNFLD_STP) * (nbEntries + 1);
    DBA_DYNFLD_STP *    tmpFusArg    = (DBA_DYNFLD_STP *) REALLOC(tab , allocateSize);

    if (NULL != tmpFusArg)
    { /* Ok */
        tab = tmpFusArg;
        tab[nbEntries] = pDynFld;
        nbEntries++;
    }
    else
    { /* Memory error */
        fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)allocateSize);
        abort();
    }
}


/************************************************************************
**
**  Function    :   addEntry()
**
**  Description :   add an entry in the array tabFusionStep
**
**  Argument    :   ptagFusionStep  Fusion step to add
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**                  PMSTA-9324 - 281210 - PMO : New adjustment nature, same as exchange with initial instrument (including F&T) cost value instead of "mark-to-market" cost value
*************************************************************************/
void STRUCT_DATAFILEFUSION::addFusionStep(FUSIONSTEP_STP ptagFusionStep)
{
    const size_t    allocateSize  = sizeof(FUSIONSTEP_ST) * (nbEntriesFusionStep + 1);
    FUSIONSTEP_STP  tmpFusionStep = (FUSIONSTEP_STP) REALLOC(tabFusionStep , allocateSize);

    if (NULL != tmpFusionStep)
    { /* Ok */

        /* For synchronization problems, use a specific counter PMSTA-8062 - 190509 - PMO */
        switch(ptagFusionStep->M_enumStepData)
        {
            case SD_FUSIONLOOP:
                char szBuffer[32];

                /* JJ/MM/AAAA -> AAAAMMJJ */
                snprintf(szBuffer
                        ,sizeof(szBuffer)
                        ,"%.4s%.2s%.2s"
                        ,(char*) ptagFusionStep->M_pData + 6
                        ,(char*) ptagFusionStep->M_pData + 3
                        ,(char*) ptagFusionStep->M_pData
                        );

                uFnFusionLoop                    = atoi (szBuffer);
                ptagFusionStep->M_iPrimaryStep   = uFnFusionLoop;
                ptagFusionStep->M_iSecondaryStep = 0;
                uFnPosFusion                     = 0;   /* Reset for synchronization */
                uFnBalPosFusion                  = 0;   /* Reset for synchronization */
                break;

            case SD_POSFUSION:
                ptagFusionStep->M_iPrimaryStep   = uFnFusionLoop;
                ptagFusionStep->M_iSecondaryStep = uFnPosFusion++;
                break;

            case SD_BALPOSFUSION:
                ptagFusionStep->M_iPrimaryStep   = uFnFusionLoop;
                ptagFusionStep->M_iSecondaryStep = uFnBalPosFusion++;
                break;

            case SD_ADJEXCHANGEWITHFEES:    /* PMSTA-9324 - 281210 - PMO */
                ptagFusionStep->M_iPrimaryStep   = uFnFusionLoop;
                ptagFusionStep->M_iSecondaryStep = uFnAdjExchangeWithFees++;
                break;

            default:
                break;
        }

        tabFusionStep = tmpFusionStep;
        tabFusionStep[nbEntriesFusionStep] = *ptagFusionStep;
        nbEntriesFusionStep++;
    }
    else
    { /* Memory error */
        fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)allocateSize);
        abort();
    }
}


/************************************************************************
**
**  Function    :   DFT_CompareFusionStep()
**
**  Description :   Compare two positions in a uniq way
**
**  Argument    :   p1  Pointer on the first position
**                  p2  Pointer on the first position
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
*************************************************************************/
extern "C" int DFT_ComparePositionUniqOrder(const void *p1, const void *p2)
{
    DBA_DYNFLD_STP * pos1 = (DBA_DYNFLD_STP*)p1;
    DBA_DYNFLD_STP * pos2 = (DBA_DYNFLD_STP*)p2;

    int ret = FIN_PosBasicLogIdCmp(*pos1, *pos2);

    if (0 == ret)
    {
        ret = FIN_PosCmp(pos1, pos2);
    }

    if (0 == ret)
    { /* Error, it is not acceptable to have an equal situation */
        assert(1==77);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DFT_CompareRemapID()
**
**  Description :   Compare two remapping ID in a unique way
**
**  Argument    :   p1  Pointer on the first position
**                  p2  Pointer on the first position
**
**  Return      :   None
**
**  Last modif. : PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
extern "C" int DFT_CompareRemapID(const void *p1, const void *p2)
{
    REMAPID_STP pID1 = (REMAPID_STP)p1;
    REMAPID_STP pID2 = (REMAPID_STP)p2;

    ID_T retID = pID2->idOld - pID1->idOld;

    return retID > 0 ? 1 : retID < 0 ? -1 : 0;
}


/************************************************************************
**
**  Function    :   checkOpenedPositions()
**
**  Description :   Check only inserted and updated positions without any end date
**
**  Argument    :   pdataFileFusion Pointer on data from the fusion trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
**                  PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::checkOpenedPositions(FIN_FUS_CONTEXT_STP ctx2)      /* PMSTA-15184 - 151012 - PMO */
{
    const size_t    maxPos          = 8192;
    size_t          idxRefTab       = 0;
    size_t          idxNewTab       = 0;
    DBA_DYNFLD_STP  refTab[maxPos];
    DBA_DYNFLD_STP  newTab[maxPos];
    DBA_DYNFLD_STP  currPos;

    /*
     * Browse all steps and extract all opened positions
     */
    for(int idxFusionStep = 0 ; idxFusionStep < nbEntriesUpdateDataBase ; idxFusionStep++)
    {
        currPos = tabUpdateDataBase[idxFusionStep];

        if ((MAGIC_END_DATE == GET_DATE(currPos, ExtPos_EndDate) || TRUE == IS_NULLFLD(currPos, ExtPos_EndDate))
           && (    DbStatus_ToUpdate == (DbStatus)GET_ENUM(currPos, ExtPos_DbStatus)
              || ( DbStatus_ToInsert == (DbStatus)GET_ENUM(currPos, ExtPos_DbStatus)
                 && TRUE             == FIN_CheckInsert(ctx2, currPos)
                 )
              )
           )
        {
            refTab[idxRefTab++] = currPos;
        }
    }


    /*
     * Browse all positions of the current fusion and extract all opened positions
     */
    for (int posLogTypesIdx = 0; posLogTypesIdx < ctx2->posLogTypesNb; posLogTypesIdx++)
    {
        if (ctx2->posLogTypesTab[posLogTypesIdx].portfolioInfo->status == ReadyForFusionLoop)
        {
            for (int posIdx=0; posIdx < ctx2->posLogTypesTab[posLogTypesIdx].posNb; posIdx++)
            {
                currPos = ctx2->posLogTypesTab[posLogTypesIdx].posTab[posIdx];

                if (  (MAGIC_END_DATE == GET_DATE(currPos, ExtPos_EndDate) || TRUE == IS_NULLFLD(currPos, ExtPos_EndDate))
                   && (    DbStatus_ToUpdate == (DbStatus)GET_ENUM(currPos, ExtPos_DbStatus)
                      || ( DbStatus_ToInsert == (DbStatus)GET_ENUM(currPos, ExtPos_DbStatus)
                         && TRUE             == FIN_CheckInsert(ctx2, currPos)
                         )
                      )
                   )
                {
                    newTab[idxNewTab++] = currPos;
                }
            }
        }
    }

    /*
     *  Browse cash portfolio position
     */
    for (int idxPtf = 0; idxPtf < ctx2->nbPtf; idxPtf++)
    {
        if (ctx2->ptfTab[idxPtf].status != ReadyForFusionLoop)
            continue;

        for (int idxPosCash = 0; idxPosCash < ctx2->ptfTab[idxPtf].posCashNb; idxPosCash++)
        {
            currPos = ctx2->ptfTab[idxPtf].posCashPtf[idxPosCash];

            if (FusState_Untreated != (POSFUSSTATE_ENUM)GET_ENUM(currPos, ExtPos_FusStateEn))
            {
                SET_ENUM(currPos, ExtPos_Fus, OpFusion_Untreated);
                newTab[idxNewTab++] = currPos;
            }
        }
    }

    if ( idxRefTab > 0 )
    {
        /* Same amount of positions */
        if ( idxRefTab == idxNewTab)
        { /* Ok */
            qsort(refTab, idxRefTab, sizeof(DBA_DYNFLD_STP), DFT_ComparePositionUniqOrder);
            qsort(newTab, idxNewTab, sizeof(DBA_DYNFLD_STP), DFT_ComparePositionUniqOrder);

            const int   iStepSave = tagDiff.iReferenceStep;
            bool        bEqual;

            for (unsigned posCmpIdx = 0; posCmpIdx < idxRefTab; posCmpIdx++)
            {
                tagDiff.iReferenceStep = posCmpIdx;

                bEqual = DFT_CompareDynFld(&tagDiff, "Opened positions check failure", refTab[posCmpIdx], newTab[posCmpIdx]);

                if (false == bEqual && true == tagDiff.bDebugOnDiff)
                { /* We stop in the debugger */
                    SYS_BreakOnDebug();
                }

                /* Update statistics */
                true == bEqual ? tagDiff.uStatCmpEventOk++ : tagDiff.uStatCmpEventFail++;
            }

            tagDiff.iReferenceStep = iStepSave;
        }
        else
        { /* Error */
            tagDiff.uStatCmpEventFail++;

            printf("[XXX] Missing positions in check opened positions\n");
            if (NULL != tagDiff.hLogFile)
            { /* Log file */
                fprintf(tagDiff.hLogFile, "[XXX] Missing positions in check opened positions\n");
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_CompareFusionStep()
**
**  Description :   Compare the value of a step with the value in a fusion step
**
**  Argument    :   p1  Pointer on a step
**                  p2  Pointer on a Fusion step
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
*************************************************************************/
STATIC int DFT_CompareFusionStep(const void *p1, const void *p2)
{
    FUSIONSTEP_STP  pFusionStep1 = (FUSIONSTEP_STP)p1;              /* PMSTA-8062 - 190509 - PMO */
    FUSIONSTEP_STP  pFusionStep2 = (FUSIONSTEP_STP)p2;

    int ret = pFusionStep1->M_enumStepData - pFusionStep2->M_enumStepData;

    if (0 == ret)
    {
        ret = pFusionStep1->M_iPrimaryStep - pFusionStep2->M_iPrimaryStep;

        if (0 == ret)
        {
            ret = pFusionStep1->M_iSecondaryStep - pFusionStep2->M_iSecondaryStep;
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DFT_CompareField()
**
**  Description :   Compare the value of two fields.
**                  For floating point the precision is only 6 digits, the same precision than in the trace file
**
**  Argument    :   ptagDiff    Structure with options of what to do when a difference occurs
**                  dynFld1     First field to compare
**                  dynFld2     Second field to compare
**                  fld         Field #
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                  PMSTA-9175 - 050110 - PMO : TDDJ can crash if the exchange gain P&L is no more generated
*************************************************************************/
STATIC bool DFT_CompareField(const FUSIONDIFF_STP ptagDiff, const DBA_DYNFLD_STP dynFld1, const DBA_DYNFLD_STP dynFld2, const DBA_DYNST_ENUM dynStEnum, const int fld)
{
    bool   bRet    = true;                                 /* Return value     */

    /* Test if the state isn't the same / PMSTA-9175 - 050110 - PMO */
    if (dynFld1 == NULL || dynFld2 == NULL || IS_NULLFLD(dynFld1, fld) != IS_NULLFLD(dynFld2, fld))
    { /* Different state */

        /* PMSTA-9175 - 050110 - PMO */
        if (dynFld1 != NULL && dynFld2 != NULL && true == ptagDiff->bCompareZeroEqualNULL)
        { /* When we compare. We consider 0 and NULL equal */
            const DBA_DYNFLD_STP dynFldIsZero = IS_NULLFLD(dynFld1, fld) ? dynFld2 : dynFld1;
            switch (GET_FLD_TYPE(dynStEnum, fld))
            {
                case AmountType :
                    bRet = TLS_Cmp(GET_AMOUNT(dynFldIsZero, fld), .0 , 0.000001) == 0;
                    break;

                case EnumType :
                    bRet = GET_ENUM(dynFldIsZero, fld) - 0 == 0;
                    break;

                case FlagType :
                    bRet = GET_FLAG(dynFldIsZero, fld) - 0 == 0;
                    break;

                case PercentType :
                    bRet = GET_PERCENT(dynFldIsZero, fld) - .0 == .0;
                    break;

                case NumberType :
                    bRet = TLS_Cmp(GET_NUMBER(dynFldIsZero, fld), .0, 0.000001) == 0;
                    break;

                case ExchangeType :
                    bRet = TLS_Cmp(GET_EXCHANGE(dynFldIsZero, fld), .0, 0.000001) == 0;
                    break;

                case TinyintType :
                    bRet = GET_TINYINT(dynFldIsZero, fld) - 0 == 0;
                    break;

                case PriceType :
                    bRet = TLS_Cmp(GET_PRICE(dynFldIsZero, fld), .0, 0.00000000000001) == 0;
                    break;

                case InfoType :
                case IdType :
                case CodeType :
                case DatetimeType :
                case ExtensionType :
                case ChainedTypeType: /* PMSTA-34537 - LJE - 190129 */
                case NullDataType:
                default:
                    /* Nothing to do */
                    break;

            } /* End switch */
        }
        else
        {
            /* Return value */
            bRet = false;
        }
    }
    else
    {
        /* Test if the field is present */
        if (IS_NULLFLD(dynFld1, fld) == FALSE)
        { /* Yes */

            switch (GET_FLD_TYPE(dynStEnum, fld))
            {
                case DatetimeType :
                    bRet = DATETIME_CMP(GET_DATETIME(dynFld1, fld),GET_DATETIME(dynFld2, fld)) == 0;
                    break;

                case AmountType :
                    bRet = TLS_Cmp(GET_AMOUNT(dynFld1, fld), GET_AMOUNT(dynFld2, fld), 0.000001) == 0;
                    break;

                case CodeType :
                    bRet = strcmp(GET_CODE(dynFld1, fld), GET_CODE(dynFld2, fld)) == 0;
                    break;

                case EnumType :
                    bRet = GET_ENUM(dynFld1, fld) - GET_ENUM(dynFld2, fld) == 0;
                    break;

                case FlagType :
                    bRet = GET_FLAG(dynFld1, fld) - GET_FLAG(dynFld2, fld) == 0;
                    break;

                case IdType :
                    bRet = CMP_ID(GET_ID(dynFld1, fld) , GET_ID(dynFld2, fld)) == 0L;
                    break;

                case PercentType :
                    bRet = GET_PERCENT(dynFld1, fld) - GET_PERCENT(dynFld2, fld) == .0;
                    break;

                case NumberType :
                    bRet = TLS_Cmp(GET_NUMBER(dynFld1, fld), GET_NUMBER(dynFld2, fld), 0.000001) == 0;
                    break;

                case ExchangeType :
                    bRet = TLS_Cmp(GET_EXCHANGE(dynFld1, fld), GET_EXCHANGE(dynFld2, fld), 0.000001) == 0;
                    break;

                case TinyintType :
                    bRet = GET_TINYINT(dynFld1, fld) - GET_TINYINT(dynFld2, fld) == 0;
                    break;

                case InfoType :
                    bRet = strcmp(GET_INFO(dynFld1, fld), GET_INFO(dynFld2, fld)) == 0;
                    break;

    		case PriceType :
                    bRet = TLS_Cmp(GET_PRICE(dynFld1, fld), GET_PRICE(dynFld2, fld), 0.00000000000001) == 0;
                    break;

                case ExtensionType :
                case ChainedTypeType: /* PMSTA-34537 - LJE - 190129 */
                case NullDataType:
                default:
                    /* Nothing to do */
                    break;

            } /* End switch */
        } /* End if */
    } /* End if */

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_GetStringDifferenceField()
**
**  Description :   Create a string that explain the difference between two fields
**
**  Argument    :   szDiff  Output string
**                  size    Size of szDiff
**                  dynFld1 First structure
**                  dynFld2 Second structure
**                  fld     Index field
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC void DFT_GetStringDifferenceField(char * szDiff, const size_t size, const DBA_DYNFLD_STP dynFld1, const DBA_DYNFLD_STP dynFld2, const FIELD_IDX_T fld)
{
    char szField1[1024];
    char szField2[1024];

    DBA_GetFieldValue(szField1, sizeof (szField1), dynFld1, fld, FALSE);
    DBA_GetFieldValue(szField2, sizeof (szField2), dynFld2, fld, FALSE);

    snprintf(szDiff, size, "[%d] [%s][%s]", fld, szField1, szField2);
}


/************************************************************************
**
**  Function    :   DFT_IsFieldMustBeCompared()
**
**  Description :   Define if the field must be compared according
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  dynFld1         Dynamic structure to check
**                  fld             Field #
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**                  PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
*************************************************************************/
STATIC inline bool DFT_IsFieldMustBeCompared(const FUSIONDIFF_STP ptagDiff, const DBA_DYNFLD_STP dynFld1, const int fld)
{
    bool                    bRet      = true;                   /* Return value             */
    const DBA_DYNST_ENUM    dynStEnum = GET_DYNSTENUM(dynFld1); /* Type of structure        */

    if (ExtPos == dynStEnum)
    {
        if (false == ptagDiff->bCompareID)
        { /* If we don't check id fields */
            bRet =  fld != ExtPos_PosObjId
                 && fld != ExtPos_OpenOpId
                 && fld != ExtPos_CloseOpId
                 && fld != ExtPos_LogicalId
                 && fld != ExtPos_SortDate;     /* PMSTA-10139 - 041010 - PMO */
        }

        /* PMSTA-8062 - 190509 - PMO */
        if (true == bRet && false == ptagDiff->bCompareFusState)
        { /* If we don't check this field */
            bRet =  fld != ExtPos_FusStateEn;
        }


        if (true == bRet)
        {
            bRet =  fld != ExtPos_Remark;
        }
    }

    return bRet;
}

/************************************************************************
**
**  Function    :   DFT_CompareDynFld()
**
**  Description :   Compare two Positions structure and maybe do an action on difference
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  pszTitle        Title to display on error
**                  p1              Pointer on a step
**                  p2              Pointer on a Fusion step
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
**                  PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
**
*************************************************************************/
STATIC bool DFT_CompareDynFld(const FUSIONDIFF_STP ptagDiff, const char * pszTitle, const DBA_DYNFLD_STP dynFld1, const DBA_DYNFLD_STP dynFld2)
{
    bool                    bFirst    = true;                   /* For the first message    */
    bool                    bRet      = true;                   /* Return value             */
    bool                    bCompare  = true;                   /* Comparison return value  */
    const DBA_DYNST_ENUM    dynStEnum = GET_DYNSTENUM(dynFld1); /* Type of structure        */
    int                     iNbrFld   = GET_FLD_NBR(dynStEnum); /* # of fields              */

    if (false == ptagDiff->bCompareUD)
    { /* If we don't compare ud fields */
        iNbrFld -= GET_CUST_NBR(dynStEnum);
    }

    for (FIELD_IDX_T fld = 0; fld < iNbrFld && true == bCompare; fld++)
	{
        if (true == DFT_IsFieldMustBeCompared(ptagDiff, dynFld1, fld))
        {
            bCompare = DFT_CompareField(ptagDiff, dynFld1, dynFld2, dynStEnum, fld);

            if (false == bCompare)
            {
                char            szDiff[2048];
                const char  *   pszCash = "";   /* PMSTA-15184 - 151012 - PMO / PMSTA-9134 - 160310 - PMO */

                if ( dynStEnum == ExtPos && InstrNat_CashAcct == GET_INSTRNAT(dynFld1, ExtPos_InstrNat))
                {
                    pszCash = "(cash positions)";
                }

                if (true == bFirst && NULL != ptagDiff->hLogFile)
                { /* Log file */
                    fprintf(ptagDiff->hLogFile, "\n[%d] %s %s %s\n", ptagDiff->iReferenceStep, pszTitle, DYN_V2N(dynStEnum), pszCash);  /* PMSTA-9134 - 160310 - PMO */
                }

                if (true == ptagDiff->bDispField)
                { /* We display a difference on stdout */

                    if (true == bFirst)
                    {
                        bFirst = false;
                        printf ( "\n[%d] %s %s %s\n", ptagDiff->iReferenceStep, pszTitle, DYN_V2N(dynStEnum), pszCash);                 /* PMSTA-9134 - 160310 - PMO */
                    }
                }

                DFT_GetStringDifferenceField(szDiff, sizeof(szDiff), dynFld1, dynFld2, fld);
                FLAG_T              allocFlg    = FALSE;
                DBA_CFIELDDEF_STP   cfield      = DBA_GetCFieldDef(dynStEnum, fld, &allocFlg);

                if (true == ptagDiff->bDispField)
                { /* We display a difference on stdout */
                    printf ( ">%s%s\n", cfield->sqlName, szDiff);
                }

                if (NULL != ptagDiff->hLogFile)
                { /* Log file */
                    fprintf (ptagDiff->hLogFile, ">%s%s\n", cfield->sqlName, szDiff);
                }

                if (true == ptagDiff->bDebugOnDiff)
                { /* We stop in the debugger */
                    SYS_BreakOnDebug();
                }

                bCompare = ptagDiff->bContinueOnDiff;
                bRet     = false;
            }
        }
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_CompareFusionLoop()
**
**  Description :   Compare two entry in the function fusion loop and maybe do an action on difference
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  fusionLoop1     Pointer on a Fusion loop
**                  fusionLoop2     Pointer on a Fusion loop
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC bool DFT_CompareFusionLoop(const FUSIONDIFF_STP ptagDiff, const FUSIONLOOP_STP fusionLoop1, const FUSIONLOOP_STP fusionLoop2)
{
    const bool bRet = 0 == strcmp (fusionLoop1->szDate, fusionLoop2->szDate);

    if (false == bRet && true == ptagDiff->bDispField)
    {
        printf("\n[%d] FusionLoop\n>[%s][%s]\n", ptagDiff->iReferenceStep, fusionLoop1->szDate, fusionLoop2->szDate);
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_ComparePosFusion()
**
**  Description :   Compare pos1 pos2 and respos from a fusion and maybe do an action on difference
**                  If there is also a P&L or a exchange P&L, do also a comparison in the same way
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  posFusion1      Positions of the fusion
**                  posFusion2      Positions of the fusion
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**
*************************************************************************/
STATIC bool DFT_ComparePosFusion(const FUSIONDIFF_STP ptagDiff, const POSFUSION_STP posFusion1, const POSFUSION_STP posFusion2)
{
    /* PMSTA-10139 - 041010 - PMO */
    if (  true == ptagDiff->bAccruedInterest
       && 0    == CMP_NUMBER(GET_NUMBER(posFusion2->resPos, ExtPos_AccrAmt), 0.0)
       && 0    != CMP_NUMBER(GET_NUMBER(posFusion1->resPos, ExtPos_AccrAmt), 0.0)
       )
    {
        COPY_DYNFLD(posFusion2->resPos, ExtPos, ExtPos_AccrAmt,  posFusion1->resPos, ExtPos, ExtPos_AccrAmt);
    }

    bool bRet = DFT_CompareDynFld(ptagDiff, "FIN_PosFusion, pos1",   posFusion1->pos1,   posFusion2->pos1)  &&
                DFT_CompareDynFld(ptagDiff, "FIN_PosFusion, pos2",   posFusion1->pos2,   posFusion2->pos2)  &&
                DFT_CompareDynFld(ptagDiff, "FIN_PosFusion, resPos", posFusion1->resPos, posFusion2->resPos);

    if (true == bRet && NULL != posFusion1->capProfitLossPos)
    {
        bRet = DFT_CompareDynFld(ptagDiff, "FIN_PosFusion, capProfitLossPos", posFusion1->capProfitLossPos, posFusion2->capProfitLossPos);
    }

    if (true == bRet && NULL != posFusion1->exchGainLossPos)
    {
        bRet = DFT_CompareDynFld(ptagDiff, "FIN_PosFusion, exchGainLossPos", posFusion1->exchGainLossPos, posFusion2->exchGainLossPos);
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_CompareBalPosFusion()
**
**  Description :   Compare pos1 pos2 and respos from a fusion and maybe do an action on difference
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  posFusion1      Positions of the fusion
**                  posFusion2      Positions of the fusion
**
**  Return      :   None
**
**  Last modif. :   PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**
*************************************************************************/
STATIC bool DFT_CompareBalPosFusion(const FUSIONDIFF_STP ptagDiff, const POSFUSION_STP posFusion1, const POSFUSION_STP posFusion2)
{
    return DFT_CompareDynFld(ptagDiff, "FIN_BalPosFusion, pos1",   posFusion1->pos1,   posFusion2->pos1)  &&
           DFT_CompareDynFld(ptagDiff, "FIN_BalPosFusion, pos2",   posFusion1->pos2,   posFusion2->pos2)  &&
           DFT_CompareDynFld(ptagDiff, "FIN_BalPosFusion, resPos", posFusion1->resPos, posFusion2->resPos);
}


/************************************************************************
**
**  Function    :   DFT_CompareFunctionCallExist()
**
**  Description :   Check if a function call exist
**
**  Argument    :   ptagDiff        Structure with options of what to do when a difference occurs
**                  p1              NULL Pointer
**                  p2              NULL Pointer
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9324 - 281210 - PMO : New adjustment nature, same as exchange with initial instrument (including F&T) cost value instead of "mark-to-market" cost value
**
*************************************************************************/
STATIC bool DFT_CompareFunctionCallExist(const FUSIONDIFF_STP ptagDiff, const void * p1, const void * p2)
{
    const bool bRet = NULL == p1 && NULL == p2;

    if (false == bRet && true == ptagDiff->bDispField)
    {
        printf("\n[%d] Missing function call\n>", ptagDiff->iReferenceStep);
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   getTagPosFusion()
**
**  Description :   Return a fusion step
**
**  Argument    :   iFusionCounter      Fusion counter
**                  ppTagFusion         Pointer to the fusion step
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
void STRUCT_DATAFILEFUSION::getTagPosFusion(const int iFusionCounter, POSFUSION_STP * ppTagFusion)
{
    POSFUSION_STP   posFusion   = NULL;;
    FUSIONSTEP_ST   fusionStep;
    bool            bFound      = false;

    fusionStep.set(iFusionCounter, 0, SD_POSFUSION, NULL);

    /* Search based on the step identifier */
    for(int idx = 0 ; idx < nbEntriesFusionStep ; idx++)
    {
        if (SD_POSFUSION == tabFusionStep[idx].M_enumStepData)
        {
            posFusion = (const POSFUSION_STP)tabFusionStep[idx].M_pData;

            if (NULL != posFusion && posFusion->fusionCptr == iFusionCounter)
            {
                bFound = true;
                break;
            }
        }
    }

    if (true == bFound)
    { /* Found */
        *ppTagFusion = posFusion;
    }
    else
    {
        *ppTagFusion = NULL;
    }
}


/************************************************************************
**
**  Function    :   check()
**
**  Description :   Check a fusion step
**
**  Argument    :   iStep           Fusion step
**                  enumStepData    Type of data
**                  pData           Pointer on data to compare
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
*************************************************************************/
void STRUCT_DATAFILEFUSION::check(const int iStep, const ENUMSTEPDATA enumStepData, void * pData)
{
    FUSIONSTEP_ST  fusionStep;                                                          /* PMSTA-8062 - 190509 - PMO */
    bool            bEqual      = true;

    /* PMSTA-8062 - 190509 - PMO */
    switch(enumStepData)
    {
        case SD_INSTRUMENT:
        case SD_POSITION:
        case SD_EXTOP:
        case SD_FUSARG:
        case SD_PORTFOLIO:
        case SD_TAXLOTINITIAL:
        case SD_TAXLOT:
            fusionStep.set(iStep, 0, enumStepData, pData);
            break;

        case SD_FUSIONLOOP:
            char szBuffer[32];

            /* JJ/MM/AAAA -> AAAAMMJJ */
            snprintf(szBuffer
                    ,sizeof(szBuffer)
                    ,"%.4s%.2s%.2s"
                    ,((FUSIONLOOP_STP) pData)->szDate + 6
                    ,((FUSIONLOOP_STP) pData)->szDate + 3
                    ,((FUSIONLOOP_STP) pData)->szDate
                    );

            uFnFusionLoop   = atoi (szBuffer);
            fusionStep.set(uFnFusionLoop, 0, enumStepData, pData);
            uFnPosFusion    = 0;   /* Reset for synchronization */
            uFnBalPosFusion = 0;   /* Reset for synchronization */
            break;

        case SD_POSFUSION:
            fusionStep.set(uFnFusionLoop, uFnPosFusion++, enumStepData, pData);
            break;

        case SD_BALPOSFUSION:
            fusionStep.set(uFnFusionLoop, uFnBalPosFusion++, enumStepData, pData);
            break;

        case SD_ADJEXCHANGEWITHFEES:
            fusionStep.set(uFnFusionLoop, uFnAdjExchangeWithFees++, enumStepData, pData);
            break;

        case SD_NONE:
        default:
            fusionStep.set(0, 0, enumStepData, NULL);
            break;
    }

    /* Search based on the step identifier */
    FUSIONSTEP_STP pReferenceData = (FUSIONSTEP_STP) bsearch(&fusionStep,               /* PMSTA-8062 - 190509 - PMO */
                                                             tabFusionStep,
                                                             nbEntriesFusionStep,
                                                             sizeof(FUSIONSTEP_ST),
                                                             DFT_CompareFusionStep);

    if (NULL != pReferenceData)
    { /* Found */
        if(enumStepData == pReferenceData->M_enumStepData)
        { /* Same type of data */

            tagDiff.iReferenceStep = iStep;

            switch(enumStepData)
            {
                case SD_INSTRUMENT:
                case SD_POSITION:
                case SD_EXTOP:
                case SD_FUSARG:
                case SD_TAXLOTINITIAL:
                case SD_TAXLOT:
                    bEqual = DFT_CompareDynFld(&tagDiff, "FIN_ExtractPositionFromDatabase", (const DBA_DYNFLD_STP)pReferenceData->M_pData, (const DBA_DYNFLD_STP)pData);
                    break;

                case SD_PORTFOLIO:  /* PMSTA-8062 - 190509 - PMO */
                    bEqual = DFT_CompareDynFld(&tagDiff, "FUS_PortfolioProcessing", (const DBA_DYNFLD_STP)pReferenceData->M_pData, (const DBA_DYNFLD_STP)pData);
                    break;

                case SD_FUSIONLOOP:
                    bEqual = DFT_CompareFusionLoop(&tagDiff, (const FUSIONLOOP_STP)pReferenceData->M_pData, (const FUSIONLOOP_STP)pData);
                    break;

                case SD_POSFUSION:
                    bEqual = DFT_ComparePosFusion(&tagDiff, (const POSFUSION_STP)pReferenceData->M_pData, (const POSFUSION_STP)pData);
                    break;

                case SD_BALPOSFUSION:   /* PMSTA-6921 - 311008 - PMO */
                    bEqual = DFT_CompareBalPosFusion(&tagDiff, (const POSFUSION_STP)pReferenceData->M_pData, (const POSFUSION_STP)pData);
                    break;

                case SD_ADJEXCHANGEWITHFEES:
                    bEqual = DFT_CompareFunctionCallExist(&tagDiff, (const void*)pReferenceData->M_pData, (const void*)pData);
                    break;

                case SD_NONE:
                default:
                    break;
            }
        }
    }
    else
    {
        switch(enumStepData)
        {
            case SD_FUSIONLOOP:
                bEqual = false;
                printf("[%d] Missing FIN_FusionLoop\n", iStep);
                if (NULL != tagDiff.hLogFile)
                { /* Log file */
                    fprintf(tagDiff.hLogFile, "[%d] Missing FIN_FusionLoop\n", iStep);
                }
                break;

            case SD_POSFUSION:
                bEqual = false;
                printf("[%d] Missing FIN_PosFusion\n", iStep);
                if (NULL != tagDiff.hLogFile)
                { /* Log file */
                    fprintf(tagDiff.hLogFile, "[%d] Missing FIN_PosFusion\n", iStep);
                }
                break;

            case SD_BALPOSFUSION:   /* PMSTA-6921 - 311008 - PMO */
                bEqual = false;
                printf("[%d] Missing FIN_BalPosFusion\n", iStep);
                if (NULL != tagDiff.hLogFile)
                { /* Log file */
                    fprintf(tagDiff.hLogFile, "[%d] Missing FIN_BalPosFusion\n", iStep);
                }
                break;

            case SD_INSTRUMENT:
            case SD_POSITION:
            case SD_EXTOP:
            case SD_FUSARG:
            case SD_PORTFOLIO:
            case SD_NONE:
            case SD_TAXLOTINITIAL:
            case SD_TAXLOT:
            default:
                break;
        }

        if (false == bEqual && true == tagDiff.bDebugOnDiff)
        { /* We stop in the debugger */
            SYS_BreakOnDebug();
        }
    }

    /* Update statistics */
    true == bEqual ? tagDiff.uStatCmpEventOk++ : tagDiff.uStatCmpEventFail++;
}


/************************************************************************
**
**  Function    :   checkBalance()
**
**  Description :   Check the balance of the given portfolio at the reference date
**
**  Argument    :   refDate         Reference date
**
**  Return      :   None
**
**  Last modif. :   PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced
**                  PMSTA-20838 - 160715 - PMO : Spot movements created by a forex swap do not merge and create multiple positions even if value date is reached
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::checkBalance(const DATETIME_T refDate)
{

    for(int idxPtf = 0 ; idxPtf < ctx->nbPtf ; idxPtf++)
    {
        const ID_T  portfolioID = ctx->ptfTab[idxPtf].portfolioId;
        double      balance     = 0.;

        /* Compute the balance of positions */
        for(int idx = 0 ; idx < nbEntriesUpdateDataBase ; idx++)
        {
            DBA_DYNFLD_STP position = tabUpdateDataBase[idx];

            if (IS_NULLFLD(position, ExtPos_EndDate))
            {
                SET_DATE(position, ExtPos_EndDate, MAGIC_END_DATE);
            }

            if (  DATETIME_CMP(refDate, GET_DATETIME(position, ExtPos_BegDate)) >= 0
               && DATETIME_CMP(refDate, GET_DATETIME(position, ExtPos_EndDate)) <= 0
               && 0 == CMP_ID(portfolioID,    GET_ID(position, ExtPos_PtfId))
               && OpFusion_ToDelete   != GET_OPFUSION(position, ExtPos_Fus)
               && BEFORESAVEDPOSITION == GET_INT(position,      ExtPos_ExtOrderSavedPosition)
               && false               == DBA_IsTechnicalPosition(position)                          /* PMSTA-20838 - 160715 - PMO */
               )
            {
                balance += GET_AMOUNT(position, ExtPos_RefNetAmt);
            }
        }


        if (fabs(balance) <= 0.03)
        { /* Ok */
            tagDiff.uStatCmpEventOk++;
        }
        else
        { /* Error */
            tagDiff.uStatCmpEventFail++;

            char dateTime[32];

            DATE_DateConvToddmmyyyy(refDate.date, dateTime);

            printf("The balance at %s of portfolioID %" szFormatId " is %.4f\n", dateTime, portfolioID, balance);

            if (NULL != tagDiff.hLogFile)
            { /* Log file */
                fprintf(tagDiff.hLogFile, "The balance at %s of portfolioID %" szFormatId " is %.4f\n", dateTime, portfolioID, balance);
            }
        }
    } /* End for */
}


/************************************************************************
**
**  Function    :   freeFusionLoadData()
**
**  Description :   Free data loaded by the fusion load
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-14047 - 260412 - PMO : Rounding difference because of difference between net and gross amount of main position when portfolio currency <> the currency in which the performance analysis is executed
**                  PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced
**                  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::freeFusionLoadData()
{
    clearPositionBalancePosition();                                                                 /* PMSTA-27843 - 200717 - PMO */

    DBA_FreeDynStTab(tabExtOp1,                 nbEntriesExtOp1,                ExtOp);             /* PMSTA-15298 - 040213 - PMO */
    DBA_FreeDynStTab(tabExtOp2,                 nbEntriesExtOp2,                ExtOp);             /* PMSTA-15298 - 040213 - PMO */
    DBA_FreeDynStTab(tabFusArg2,                nbEntriesFusArg2,               Fus_Arg);
    DBA_FreeDynStTab(tabOperation1,             nbEntriesOperation1,            A_Op);              /* PMSTA-15298 - 040213 - PMO */
    DBA_FreeDynStTab(tabOperation2,             nbEntriesOperation2,            A_Op);              /* PMSTA-15298 - 040213 - PMO */
    DBA_FreeDynStTab(tabConversionPosition1,    nbEntriesConversionPosition1,   ExtPos);            /* PMSTA-15298 - 040213 - PMO */
    DBA_FreeDynStTab(tabConversionPosition2,    nbEntriesConversionPosition2,   ExtPos);            /* PMSTA-15298 - 040213 - PMO */


    tabExtOp1                       = NULL;
    nbEntriesExtOp1                 = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabExtOp2                       = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesExtOp2                 = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabFusArg2                      = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesFusArg2                = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabOperation1                   = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesOperation1             = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabOperation2                   = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesOperation2             = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabConversionPosition1          = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesConversionPosition1    = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
    tabConversionPosition2          = NULL;                                                         /* PMSTA-15298 - 040213 - PMO */
    nbEntriesConversionPosition2    = 0;                                                            /* PMSTA-15298 - 040213 - PMO */
}


/************************************************************************
**
**  Function    :   free()
**
**  Description :   Free all memory allocated in the structure
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA08450 - 200709 - PMO : Calculation of accrued interests are not always right computed
**                  PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
**                  PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**
*************************************************************************/
void STRUCT_DATAFILEFUSION::free()
{
    DBA_FreeDynStTab(tabFusArg,         nbEntriesFusArg,            Fus_Arg);
    DBA_FreeDynStTab(tabPtf,            nbEntriesPtf,               A_Ptf);
    DBA_FreeDynStTab(tabInstrument,     nbEntriesInstrument,        A_Instr);
    DBA_FreeDynStTab(tabUpdateDataBase, nbEntriesUpdateDataBase,    ExtPos);    /* PMSTA-9134 - 160310 - PMO */

    freeFusionLoadData();

    /* PMSTA-6921 - 311008 - PMO */
    for (int idx = 0 ; idx < nbEntriesFusionStep ; idx++)
    {
        POSFUSION_STP ptagPosFusion;

        switch(tabFusionStep[idx].M_enumStepData)
        {
            case SD_INSTRUMENT:
            case SD_POSITION:
            case SD_EXTOP:
            case SD_FUSARG:
            case SD_PORTFOLIO:
            case SD_TAXLOTINITIAL:
            case SD_TAXLOT:
                /* No free needs */
                break;

            case SD_FUSIONLOOP:         /* PMSTA08450 - 200709 - PMO */
                FREE(tabFusionStep[idx].M_pData);
                break;

            case SD_BALPOSFUSION:
            case SD_POSFUSION:
                ptagPosFusion = (POSFUSION_STP) tabFusionStep[idx].M_pData;

                FREE_DYNST(ptagPosFusion->pos1,             ExtPos);
                FREE_DYNST(ptagPosFusion->pos2,             ExtPos);
                FREE_DYNST(ptagPosFusion->resPos,           ExtPos);
                FREE_DYNST(ptagPosFusion->exchGainLossPos,  ExtPos);
                FREE_DYNST(ptagPosFusion->capProfitLossPos, ExtPos);

                FREE(ptagPosFusion);    /* PMSTA08450 - 200709 - PMO */
                break;

            case SD_NONE:
            default:
                break;
        }
    }

    /* PMSTA08450 - 200709 - PMO */
    FREE(tabFusionStep);
    nbEntriesFusionStep = 0;

    /* PMSTA-9072 - 050510 - PMO */
    FREE(tabRemapBalPosType);
    nbEntriesRemapBalPosType = 0;
}


/************************************************************************
**
**  Function    :   IS_AlNumLine()
**
**  Description :   Test if there is some alpha numeric characters
**
**  Argument    :   pszLine     Line to test
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC bool IS_AlNumLine(const char * pszLine)
{
    bool bRet = false;

    while (*pszLine)
    {
        if (isalnum(*pszLine))
        {
            bRet = true;
            break;
        }

        pszLine++;
    }

    return bRet;
}


/************************************************************************
**
**  Function    :   DFT_LoadFusion()
**
**  Description :   Load the content of the multi select from the xml file and put it in pDataFileFusion
**
**  Argument    :   hgzFile             Handle of the compressed xml fusion trace file
**                  pszFileFusion       Compressed xml trace file
**                  bExclExtPosTaxLot   Skip loading pos and tax lot structures
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**                  PMSTA-17846 - 140414 - PMO : Adjustment "Partially Paid", fees & taxes are not included in P&L
**                  PMSTA-27843 - 021117 - JBC : Add Tax Lots, Detail Pos; Add Flag to limit xml data loaded
**
*************************************************************************/
STATIC void DFT_LoadFusion(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion, const bool bExclExtPosTaxLot)
{
    enum DATATOLOAD { E_NONE
                    , E_POSITION
                    , E_POSITION_DETAIL
                    , E_INSTRUMENT
                    , E_BALANCE_POSITION
                    , E_BALANCE_POS_DETAIL
                    , E_TAX_LOT_INITIAL
                    , E_TAX_LOT
                    , E_EXTOP
                    , E_FUSARG
                    , E_EXTOP_CONVERSION                /* PMSTA-15298 - 040213 - PMO */
                    } enumDataToLoad = E_NONE;

    if (  (  0 == strcmp("FIN_ExtractPositionFromDatabase", pDataFileFusion->szCurrentTag) || true == DFT_SeekTag(hgzFile, "<FIN_ExtractPositionFromDatabase>"))
       && true == DFT_SeekTag(hgzFile, "<MultiSelect>"))
    {
        char            szDyn[256];
        DBA_DYNFLD_STP  dynStp;
        bool            bIsExtPosTaxLot; /* PMSTA-27843 - 021117 - JBC */

        pDataFileFusion->maxFusionLoad++;
        pDataFileFusion->szCurrentTag[0] = 0;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (  0 == strcmp("/ExtOpLst"     ,szDyn)
               || 0 == strcmp("/FusArgLst"    ,szDyn)
               || 0 == strcmp("/PositionsLst" ,szDyn)
               || 0 == strcmp("/PosDetailLst"    , szDyn)
               || 0 == strcmp("/BalPosLst"       , szDyn)
               || 0 == strcmp("/BalPosDetailLst" , szDyn)
               || 0 == strcmp("/TaxLotInitLst"   , szDyn)
               || 0 == strcmp("/TaxLotsLst"      , szDyn))
            {
                enumDataToLoad = E_NONE;
            }
            else
            {
                if (0 == strcmp("/FIN_ExtractPositionFromDatabase", szDyn))
                { /* End of fields */

                    /* Second load PMSTA-15298 - 040213 - PMO */
                    while (true == DFT_XmlGetNextTag(pDataFileFusion->szCurrentTag, sizeof(pDataFileFusion->szCurrentTag), hgzFile))
                    {
                        if (0 == strcmp("FIN_ExtractPositionFromDatabase", pDataFileFusion->szCurrentTag))
                        {
                            DFT_LoadFusion(hgzFile, pDataFileFusion, false);
                        }

                        if (  0 == strcmp("/FIN_ExtractPositionFromDatabase", pDataFileFusion->szCurrentTag)
                           || 0 == strcmp("FIN_InitPosLogTypes"             , pDataFileFusion->szCurrentTag))
                        {
                            break;
                        }
                    }

                    break;
                }
            }

            if ('/' != szDyn[0] && true == IS_AlNumLine(szDyn))
            {
                bIsExtPosTaxLot = false;
                dynStp = NULL;

                if (0 == strcmp("PositionsTab", szDyn))
                {
                    enumDataToLoad = E_POSITION;
                    bIsExtPosTaxLot = true;
                }
                else
                {
                    if (0 == strcmp("PosDetailTab", szDyn))
                    {
                        enumDataToLoad = E_POSITION_DETAIL;
                        bIsExtPosTaxLot = true;
                    }
                    else
                    {
                        if (0 == strcmp("InstrumentTab", szDyn))
                        {
                            enumDataToLoad = E_INSTRUMENT;
                        }
                        else
                        {
                            if (0 == strcmp("BalPosTab", szDyn))
                            {
                                enumDataToLoad = E_BALANCE_POSITION;
                                bIsExtPosTaxLot = true;
                            }
                            else
                            {
                                if (0 == strcmp("BalPosDetailTab", szDyn))
                                {
                                    enumDataToLoad = E_BALANCE_POS_DETAIL;
                                    bIsExtPosTaxLot = true;
                                }
                                else
                                {
                                    if (0 == strcmp("TaxLotInitTab", szDyn))
                                    {
                                        enumDataToLoad = E_TAX_LOT_INITIAL;
                                        bIsExtPosTaxLot = true;
                                    }
                                    else
                                    {
                                        if (0 == strcmp("TaxLotsTab", szDyn))
                                        {
                                            enumDataToLoad = E_TAX_LOT;
                                            bIsExtPosTaxLot = true;
                                        }
                                        else
                                        {
                                            if (0 == strcmp("ExtOpTab", szDyn))
                                            {
                                                enumDataToLoad = E_EXTOP;
                                            }
                                            else
                                            {
                                                if (0 == strcmp("FusArgTab", szDyn))
                                                {
                                                    enumDataToLoad = E_FUSARG;
                                                }
                                                else
                                                {
                                                    if (0 == strcmp("FUS_LoadMergeExtOpWithExtPos", szDyn))
                                                    { /* First Extop to ExtPos */
                                                        if (true == DFT_SeekTag(hgzFile, "<ExtOpToExtPos>", "</FUS_LoadMergeExtOpWithExtPos>"))
                                                        {
                                                            enumDataToLoad = E_EXTOP_CONVERSION;                    /* PMSTA-15298 - 040213 - PMO */
                                                        }
                                                        else
                                                        {
                                                            enumDataToLoad = E_NONE;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        /* Next Extop to ExtPos */
                                                        if (0 == strcmp("ExtOpToExtPos", szDyn))
                                                        {
                                                            enumDataToLoad = E_EXTOP_CONVERSION;                    /* PMSTA-15298 - 040213 - PMO */
                                                        }
                                                        else
                                                        {
                                                            /* PMSTA-17846 - 140414 - PMO */
                                                            if (0 != strncmp("object id=\"", szDyn, 11))
                                                            {
                                                                enumDataToLoad = E_NONE;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                /* PMSTA-27843 - 021117 - JBC */
                if (true == bIsExtPosTaxLot && true == bExclExtPosTaxLot)
                {
                    enumDataToLoad = E_NONE;
                }

                if (E_NONE != enumDataToLoad)
                {
                    int             iStep;
                    FUSIONSTEP_ST   tagFusionStep;

                    if (  true == DFT_SeekTag(hgzFile, "<step>", "</FUS_LoadMergeExtOpWithExtPos>")
                       && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile)
                       )
                    { /* Found a field */
                        iStep = atoi (szDyn);

                        dynStp = DFT_LoadXmlRecord(hgzFile);

                        if (NULL != dynStp)
                        {
                            switch (enumDataToLoad)
                            {
                                case E_NONE:
                                    break;

                                case E_POSITION:
                                    pDataFileFusion->addPosition(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_POSITION, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_POSITION_DETAIL:
                                    pDataFileFusion->addPosDetail(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_POSITION, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_INSTRUMENT:
                                    pDataFileFusion->addInstrument(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_INSTRUMENT, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_BALANCE_POSITION:
                                    pDataFileFusion->addBalPos(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_POSITION, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_BALANCE_POS_DETAIL:
                                    pDataFileFusion->addBalPosDetail(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_POSITION, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_TAX_LOT_INITIAL:
                                    pDataFileFusion->addTaxLotInitial(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_TAXLOTINITIAL, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_TAX_LOT:
                                    pDataFileFusion->addTaxLot(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_TAXLOT, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_EXTOP:
                                    pDataFileFusion->addExtOp(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_EXTOP, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_FUSARG:
                                    pDataFileFusion->addFusArg2(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_FUSARG, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);
                                    break;

                                case E_EXTOP_CONVERSION:                                        /* PMSTA-15298 - 040213 - PMO */
                                    pDataFileFusion->addExtOpConversionOperation(dynStp);

                                    tagFusionStep.set(iStep, 0, SD_FUSARG, dynStp);
                                    pDataFileFusion->addFusionStep(&tagFusionStep);

                                    while (  true == DFT_SeekTag(hgzFile, "<step>", "</PositionsTab>")
                                          && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
                                    {
                                        iStep = atoi (szDyn);

                                        dynStp = DFT_LoadXmlRecord(hgzFile);

                                        pDataFileFusion->addConversionPosition(dynStp);

                                        tagFusionStep.set(iStep, 0, SD_POSITION, dynStp);
                                        pDataFileFusion->addFusionStep(&tagFusionStep);
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
        } /* End for */
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadFusionProcessing()
**
**  Description :   Load the content of the fusion processing from the xml file and put it in pDataFileFusion
**
**  Argument    :   hgzFile         Handle of the compressed xml fusion trace file
**                  pszFileFusion   Compressed xml trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**                  PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                  PMSTA-9324 - 281210 - PMO : New adjustment nature, same as exchange with initial instrument (including F&T) cost value instead of "mark-to-market" cost value
*************************************************************************/
STATIC void DFT_LoadFusionProcessing(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion)
{
    if (true == DFT_SeekTag(hgzFile, "<FIN_FusionDateLoop>"))
    {
        FUSIONSTEP_ST   tagFusionStep;
        char            szDyn[256];
        char            szDate[256];
        int             iStep;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (0 == strcmp("/FIN_FusionDateLoop", szDyn))
            { /* End of fields */
                break;
            }

            if (0 == strcmp("FIN_FusionLoop", szDyn)
               && true == DFT_SeekTag(hgzFile, "<step>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                iStep = atoi (szDyn);

                if (  true == DFT_SeekTag(hgzFile, "<date>")
                   && true == DFT_XmlGetNextTag(szDate, sizeof(szDyn), hgzFile))
                {
                    FUSIONLOOP_STP  ptagFusionLoop = (FUSIONLOOP_STP) CALLOC(1, sizeof(FUSIONLOOP_ST));

                    if (NULL != ptagFusionLoop)
                    { /* Ok */
                        strcpy(ptagFusionLoop->szDate, szDate);

                        tagFusionStep.set(iStep, 0, SD_FUSIONLOOP, ptagFusionLoop);         /* PMSTA-8062 - 190509 - PMO */
                        pDataFileFusion->addFusionStep(&tagFusionStep);
                    }
                    else
                    { /* Memory error */
                        fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)sizeof(FUSIONLOOP_ST));
                        abort();
                    }
                }
                else
                {
                    szDate[0] = 0;
                }
            }
            else
            {
                if (0 == strcmp("FIN_PosFusion", szDyn)
                    && true == DFT_SeekTag(hgzFile, "<step>")
                    && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
                {
                    POSFUSION_STP   ptagFusion = (POSFUSION_STP) CALLOC(1, sizeof(POSFUSION_ST));

                    if (NULL != ptagFusion)
                    { /* Ok */
                        iStep = atoi (szDyn);

                        DBA_DYNFLD_STP  pos = DFT_LoadXmlRecord(hgzFile, true, szDyn);

                        if (0 == strcmp("CapProfitLossPos", szDyn))
                        {
                            ptagFusion->capProfitLossPos = pos;
                            pos = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                        }

                        if (0 == strcmp("ExchGainLossPos", szDyn))
                        {
                            ptagFusion->exchGainLossPos = pos;
                            pos = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                        }

                        ptagFusion->pos1        = pos;
                        ptagFusion->pos2        = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                        ptagFusion->resPos      = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                        ptagFusion->fusionCptr  = iStep;                                    /* PMSTA-9072 - 050510 - PMO */

                        tagFusionStep.set(iStep, 0, SD_POSFUSION, ptagFusion);              /* PMSTA-8062 - 190509 - PMO */
                        pDataFileFusion->addFusionStep(&tagFusionStep);
                    }
                    else
                    { /* Memory error */
                        fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)sizeof(FUSIONLOOP_ST));
                        abort();
                    }
                }
                else
                { /* PMSTA-6921 - 311008 - PMO */
                    if (0 == strcmp("FIN_BalPosFusion", szDyn)
                        && true == DFT_SeekTag(hgzFile, "<step>")
                        && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
                    {
                        POSFUSION_STP   ptagFusion = (POSFUSION_STP) CALLOC(1, sizeof(POSFUSION_ST));

                        if (NULL != ptagFusion)
                        { /* Ok */
                            iStep = atoi (szDyn);

                            ptagFusion->pos1   = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                            ptagFusion->pos2   = DFT_LoadXmlRecord(hgzFile, true, szDyn);
                            ptagFusion->resPos = DFT_LoadXmlRecord(hgzFile, true, szDyn);

                            tagFusionStep.set(iStep, 0, SD_BALPOSFUSION, ptagFusion);       /* PMSTA-8062 - 190509 - PMO */
                            pDataFileFusion->addFusionStep(&tagFusionStep);
                        }
                        else
                        { /* Memory error */
                            fprintf (stderr, "Not enough memory to allocate " szSimpleFormatLongInt"\n" , (LONGINT_T)sizeof(FUSIONLOOP_ST));
                            abort();
                        }
                    }
                    else
                    {
                        /* PMSTA-9324 - 281210 - PMO */
                        if (0 == strcmp("FUS_AdjExchangeWithFees", szDyn)
                           && true == DFT_SeekTag(hgzFile, "<step>")
                           && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
                        {
                            iStep = atoi (szDyn);

                            tagFusionStep.set(iStep, 0, SD_ADJEXCHANGEWITHFEES, NULL);
                            pDataFileFusion->addFusionStep(&tagFusionStep);
                        }
                    }
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadUpdateDataBase()
**
**  Description :   Load the content of the update database from the xml file and put it in pDataFileFusion
**
**  Argument    :   hgzFile         Handle of the compressed xml fusion trace file
**                  pszFileFusion   Compressed xml trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
*************************************************************************/
STATIC void DFT_LoadUpdateDataBase(gzFile hgzFile, DATAFILEFUSION_STP pDataFileFusion)
{
    if (true == DFT_SeekTag(hgzFile, "<FIN_UpdateDataBase>"))
    {
        char            szDyn[256];
        DBA_DYNFLD_STP  dynStp;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (0 == strcmp("/FIN_UpdateDataBase", szDyn))
            { /* End of fields */
                break;
            }

            if (0 == strncmp("object id=", szDyn, 10)
               && true == DFT_SeekTag(hgzFile, "<step>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            { /* Found a field */
                dynStp = DFT_LoadXmlRecord(hgzFile);

                if (NULL != dynStp)
                {
                    const DBA_DYNST_ENUM dynStEnum = GET_DYNSTENUM(dynStp);
                    if (ExtPos == dynStEnum)
                    {
                        pDataFileFusion->addUpdateDataBase(dynStp);
                    }
                    else
                    { /* Another structure */
                        FREE_DYNST(dynStp, dynStEnum);
                    }
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadFusionSecondTime()
**
**  Description :   Load the second content of the multi select from the xml file and put it in pDataFileFusion
**
**  Argument    :   ctx     Fusion context
**
**  Return      :   None
**
**  Last modif. :   PMSTA-14047 - 260412 - PMO : Rounding difference because of difference between net and gross amount of main position when portfolio currency <> the currency in which the performance analysis is executed
**
*************************************************************************/
void DFT_LoadFusionSecondTime(FIN_FUS_CONTEXT_STP ctx)
{
    gzFile hgzFile = ctx->pDataFileFusion->hgzFile;

    if (NULL != hgzFile)
    { /* Ok */

        /* Restart from the start */
        (void)gzrewind(hgzFile);

        /* Skip the first Database load */
        if (  true == DFT_SeekTag(hgzFile, "<FIN_ExtractPositionFromDatabase>")
           && true == DFT_SeekTag(hgzFile, "<MultiSelect>")
           && true == DFT_SeekTag(hgzFile, "</FIN_ExtractPositionFromDatabase>")
           )
        {
            ctx->pDataFileFusion->freeFusionLoadData();

            /*
             *  Load data from the xml file
             */
            DFT_LoadFusion(hgzFile,           ctx->pDataFileFusion, false);
            DFT_LoadFusionProcessing(hgzFile, ctx->pDataFileFusion);

            /* The first Database update is already skipped */
            DFT_LoadUpdateDataBase(hgzFile,   ctx->pDataFileFusion);
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_Trace_SetCheckFn()
**
**  Description :   Callback function for checking an event
**
**  Argument    :   ctx             The fusion context
**                  iFusionCounter  Reference value of the fusion counter
**                  enumStepData    Type of data
**                  pData           Pointer on data to compare
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
void DFT_Trace_SetCheckFn (const FIN_FUS_CONTEXT_STP ctx, const int iFusionCounter, const ENUMSTEPDATA enumStepData, void * pData)
{
    switch (ctx->pDataFileFusion->tagDiff.eStepProcessing)
    {
        case SP_LOAD:
            if (true == ctx->pDataFileFusion->tagDiff.bCheckLoad)
            {
                ctx->pDataFileFusion->check(iFusionCounter, enumStepData, pData);
            }
            break;

        default:
        case SP_INIT:
        case SP_SAVE:
        case SP_PROC:
            ctx->pDataFileFusion->check(iFusionCounter, enumStepData, pData);
            break;
    }
}


/************************************************************************
**
**  Function    :   DFT_Settings()
**
**  Description :   Load settings from environment variables
**
**  Argument    :   pdataFileFusion Pointer on data from the fusion trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**                  PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                  PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
*************************************************************************/
STATIC void DFT_Settings(DATAFILEFUSION_STP pdataFileFusion)
{
    char * pEnv = SYS_GetEnv("AAADFTFUSDEBUGONDIFF");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bDebugOnDiff = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSCOMPAREID");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bCompareID = pEnv[0] == '1';
    }

    /* PMSTA-8062 - 190509 - PMO */
    pEnv = SYS_GetEnv("AAADFTFUSCOMPAREFUSSTATE");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bCompareFusState = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSCOMPAREUD");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bCompareUD = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSCOMPAREZEROEQUALNULL");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bCompareZeroEqualNULL = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSCONTINUEONDIFF");   /* PMSTA-6921 - 311008 - PMO */

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bContinueOnDiff = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSDISPFIELD");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bDispField = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSLOADDATAFROMFILE");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bLoadDataFromFile = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSWRITELOGFIELD");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bWriteLogField = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTFUSCHECKLOAD");

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bCheckLoad = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTREMOVEUSELESSFILE");       /* PMSTA08746 - 061009 - PMO */

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bRemoveUseLessFile = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTREMAPBALPOSTYPEFILE");     /* PMSTA-9072 - 050510 - PMO */

    if (NULL != pEnv)
    {
        pdataFileFusion->pszRemapBalPosTypeFile = pEnv;
    }

    pEnv = SYS_GetEnv("AAADFTSETACCRUEDINTEREST");      /* PMSTA-10139 - 041010 - PMO */

    if (NULL != pEnv)
    {
        pdataFileFusion->tagDiff.bAccruedInterest = pEnv[0] == '1';
    }

    pEnv = SYS_GetEnv("AAADFTSAMEFILENAME");            /* PMSTA-9072 - 050510 - PMO */

    if (NULL != pEnv)
    {
        pdataFileFusion->bSameFilename = pEnv[0] == '1';
    }
}


/************************************************************************
**
**  Function    :   DFT_LoadConfig()
**
**  Description :   Load configuration
**
**  Argument    :   pdataFileFusion Pointer on data from the fusion trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
STATIC void DFT_LoadConfig(DATAFILEFUSION_STP pdataFileFusion)
{
    /* Is there a remapping of balance position type file */
    if (NULL != pdataFileFusion->pszRemapBalPosTypeFile)
    { /* Yes */
        FILE * hRemapFile = fopen(pdataFileFusion->pszRemapBalPosTypeFile, "r");

        if (NULL != hRemapFile)
        {
            char szFormat[32];
            char szLine[2048];
            REMAPID_ST remapID;

            snprintf(szFormat, sizeof(szFormat), "%s%s", szFormatIdSScanf, szFormatIdSScanf);

            /* Browse the file */
            while(fgets(szLine, sizeof(szLine), hRemapFile))
            {
                if (strlen(szLine) > 0 && szLine[0] != '#' )
                { /* One data line */
                    remapID.idOld  = 0;
                    remapID.idNew  = 0;

                    sscanf(szLine, szFormat, &remapID.idOld , &remapID.idNew);

                    if (remapID.idOld > 0 && remapID.idNew > 0)
                    {
                        pdataFileFusion->addRemapBalPosType(&remapID);
                    }
                }
            }

            fclose(hRemapFile);

            qsort(pdataFileFusion->tabRemapBalPosType, pdataFileFusion->nbEntriesRemapBalPosType, sizeof(REMAPID_ST), DFT_CompareRemapID);
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_RemapPositionBalPosTypeID()
**
**  Description :   Remap some Balance position type ID
**
**  Argument    :   pdataFileFusion Pointer on data from the fusion trace file
**                  currPos         Position to check
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
STATIC void DFT_RemapPositionBalPosTypeID(DATAFILEFUSION_STP pdataFileFusion, DBA_DYNFLD_STP currPos)
{
    if (currPos != NULL && IS_NULLFLD(currPos, ExtPos_BalPosTpId) == FALSE)
    { /* We have an ID */
        REMAPID_ST remapID;
        remapID.idOld = GET_ID(currPos, ExtPos_BalPosTpId);

        /* Search based on the step identifier */
        REMAPID_STP pRemapID = (REMAPID_STP) bsearch(&remapID,
                                                     pdataFileFusion->tabRemapBalPosType,
                                                     pdataFileFusion->nbEntriesRemapBalPosType,
                                                     sizeof(REMAPID_ST),
                                                     DFT_CompareRemapID);
        if (NULL != pRemapID)
        { /* Found */
            SET_ID(currPos, ExtPos_BalPosTpId, pRemapID->idNew);
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_RemapBalPosTypeID()
**
**  Description :   Remap some Balance position type ID
**
**  Argument    :   pdataFileFusion Pointer on data from the fusion trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
STATIC void DFT_RemapBalPosTypeID(DATAFILEFUSION_STP pdataFileFusion)
{
    int             idx;

    /*
     * Browse balance positions
     */
    for(idx = 0 ; idx < pdataFileFusion->nbEntriesBalPos ; idx++)
    {
        DFT_RemapPositionBalPosTypeID(pdataFileFusion, pdataFileFusion->tabBalPos[idx]);
    }

    for(idx = 0 ; idx < pdataFileFusion->nbEntriesUpdateDataBase ; idx++)
    {
        DFT_RemapPositionBalPosTypeID(pdataFileFusion, pdataFileFusion->tabUpdateDataBase[idx]);
    }

    for(idx = 0 ; idx < pdataFileFusion->nbEntriesFusionStep ; idx++)
    {
        switch (pdataFileFusion->tabFusionStep[idx].M_enumStepData)
        {
            case SD_BALPOSFUSION:
                DFT_RemapPositionBalPosTypeID(pdataFileFusion, ((POSFUSION_STP)pdataFileFusion->tabFusionStep[idx].M_pData)->pos1);
                DFT_RemapPositionBalPosTypeID(pdataFileFusion, ((POSFUSION_STP)pdataFileFusion->tabFusionStep[idx].M_pData)->pos2);
                DFT_RemapPositionBalPosTypeID(pdataFileFusion, ((POSFUSION_STP)pdataFileFusion->tabFusionStep[idx].M_pData)->resPos);
                break;

            case SD_POSFUSION:
                DFT_RemapPositionBalPosTypeID(pdataFileFusion, ((POSFUSION_STP)pdataFileFusion->tabFusionStep[idx].M_pData)->capProfitLossPos);
                DFT_RemapPositionBalPosTypeID(pdataFileFusion, ((POSFUSION_STP)pdataFileFusion->tabFusionStep[idx].M_pData)->exchGainLossPos);
                break;

            default:
                break;
        }
    }


    for(unsigned idxParam = 0; idxParam < pdataFileFusion->nbEntriesSysParameters; idxParam++)
    {
        switch ( pdataFileFusion->tabSysParameters[idxParam].applParameter )
        {
            case ApplDefBookProfitBpTpId:
            case ApplDefBookLossBpTpId:
            case ApplBookAdjLossBpTpId:
            case ApplBookAdjProfitBpTpId:
            case ApplEuroCurrId:
            case ApplFutMergeInvestBpTypeId:
            case ApplFutMergeWithdrBpTypeId:
            case ApplFutCloseInvestBpTypeId:
            case ApplFutCloseWithdrBpTypeId:
            case ApplFwdMergeInvestBpTypeId:
            case ApplFwdMergeWithdrBpTypeId:
            case ApplFwdCloseInvestBpTypeId:
            case ApplFwdCloseWithdrBpTypeId:
            case ApplCapPBpTypeId:
            case ApplCapLBpTypeId:
            case ApplCurPBpTypeId:
            case ApplCurLBpTypeId:
            case ApplTrsfCapPBpTpId:
            case ApplTrsfCapLBpTpId:
            case ApplTrsfCurPBpTpId:
            case ApplTrsfCurLBpTpId:
                {
                    REMAPID_ST remapID;
                    remapID.idOld = pdataFileFusion->tabSysParameters[idxParam].lValue;

                    /* Search based on the step identifier */
                    REMAPID_STP pRemapID = (REMAPID_STP) bsearch(&remapID,
                                                                 pdataFileFusion->tabRemapBalPosType,
                                                                 pdataFileFusion->nbEntriesRemapBalPosType,
                                                                 sizeof(REMAPID_ST),
                                                                 DFT_CompareRemapID);
                    if (NULL != pRemapID)
                    { /* Found */
                        pdataFileFusion->setSetSystemParameter(pdataFileFusion->tabSysParameters[idxParam].pszName, (long) pRemapID->idNew);
                    }
                }
                break;

            default:
                break;
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_HookGetExdInstrumentById()
**
**  Description :   Hook for the SQL proc get_exd_instrument_by_id
**
**  Argument    :   Standard arguments for a get function
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
RET_CODE DFT_HookGetExdInstrumentById(  OBJECT_ENUM         ,
                                        DBA_DYNFLD_STP      inputSt,
                                        DBA_DYNFLD_STP *    outputStp,
                                        int			        ,
                                        int			        )
{
    RET_CODE ret = RET_DBA_INFO_NODATA;

    if (NULL != SV_DataFileFusion && NULL != SV_DataFileFusion->ctx)
    {
        DBA_DYNFLD_STP  currInstr;
        ID_T            id = GET_ID(inputSt ,S_Instr_Id);

        for (int posIdx=0; posIdx < SV_DataFileFusion->ctx->nbAllInstr; posIdx++)
        {
            currInstr = SV_DataFileFusion->ctx->allInstrTab[posIdx];

            if (0 == CMP_ID(id,GET_ID(currInstr, A_Instr_Id)))
            { /* Found */
                COPY_DYNST(*outputStp, currInstr, A_Instr);
                ret = RET_SUCCEED;
                break;
            }
        }
    }

   return ret;
}

/************************************************************************
**
**  Function    :   DFT_HookSQLProc()
**
**  Description :   Hook some SQL procs to allow retrieving data from the XML file
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*************************************************************************/
STATIC void DFT_HookSQLProc()
{
    static DBA_PROC_ST  procedureGetExdInstrumentById;
    DBA_DYNFLD_STP      getInstr;

    if ((getInstr = ALLOC_DYNST(S_Instr)) == NULL)
    { /* Memory error */
        fprintf (stderr, "Not enough memory for allocating S_Instr\n" );
        abort();
    }

    SET_ID(getInstr, S_Instr_Id, ID_1);

    DBA_PROC_STP procedure = DBA_GetStoredProcs(Get, Instr, UNUSED, S_Instr, getInstr, A_Instr);

    FREE_DYNST(getInstr, S_Instr);

    RET_CODE (*fn)(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, int) = (RET_CODE (*)(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, int)) procedure->procName;

    if ( fn != DFT_HookGetExdInstrumentById)
    {
        procedureGetExdInstrumentById = *procedure;
        procedure->server   = InternalProc;
        procedure->procName = (const char *)DFT_HookGetExdInstrumentById;
    }
}

/************************************************************************
**
**  Function    :   DFT_FileFusionProcessing()
**
**  Description :   Testing the fusion for one given file
**
**  Argument    :   pszFileFusion           Compressed xml trace file
**                  pTotalDataFileFusion    Storage of global statistics
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**                  PMSTA08450 - 200709 - PMO : Calculation of accrued interests are not always right computed
**                  PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                  PMSTA-9134 - 160310 - PMO : Future instrument with foreign currency: wrong rounding on BP currency P&L leads unbalanced portfolio & unbalanced account on Return function
**                  PMSTA-29510 - 071217 - PMO : Memory overflow when too much ptf are sent to a fusion server
**
*************************************************************************/
STATIC void DFT_FileFusionProcessing(const char * pszFileFusion, DATAFILEFUSION_STP pTotalDataFileFusion)   /* PMSTA08746 - 061009 - PMO */
{
#ifdef AAAPURIFY
#ifdef NT
	PurifyPrintf("Testing %s", pszFileFusion);      /* PMSTA08746 - 061009 - PMO */
#endif
#endif

    DATAFILEFUSION_ST   dataFileFusion;
    bool                bRemoveFile     = false;    /* PMSTA08746 - 061009 - PMO */

    gzFile hgzFile = gzopen(pszFileFusion, "rb");

    if (NULL != hgzFile)
    { /* Ok */

        dataFileFusion.hgzFile = hgzFile;

        /*
         *  Load data from the xml file
         */
        DFT_LoadSystemParameter(hgzFile,  &dataFileFusion);
        DFT_LoadFusArg(hgzFile,           &dataFileFusion);
        DFT_LoadPtf(hgzFile,              &dataFileFusion);
        DFT_LoadFusion(hgzFile,           &dataFileFusion, false);
        DFT_LoadFusionProcessing(hgzFile, &dataFileFusion);
        DFT_LoadUpdateDataBase(hgzFile,   &dataFileFusion); /* PMSTA-9134 - 160310 - PMO */


        /*
         *  Load settings from environment variables
         */
        DFT_Settings(&dataFileFusion);

        /* PMSTA-9072 - 050510 - PMO
         * Load configuration
         */
        DFT_LoadConfig(&dataFileFusion);

        /* PMSTA-9072 - 050510 - PMO
         * Remap some Balance position type ID
         */
        DFT_RemapBalPosTypeID(&dataFileFusion);

        /* PMSTA-8062 - 190509 - PMO
         * - Clear function call counters
         * - Sort data
         */
        dataFileFusion.clearFunctionCallCounters();
        dataFileFusion.sort(DFT_CompareFusionStep);

        /* For SQL hooks / PMSTA-9072 - 050510 - PMO */
        SV_DataFileFusion = &dataFileFusion;

        /* PMSTA-9072 - 050510 - PMO */
        if (true == dataFileFusion.bSameFilename)
        {
            size_t          length      = strlen (pszFileFusion);
            const char *    pszBaseName = pszFileFusion + length;

            while (length > 0)
            {
                if (*pszBaseName == '/' || *pszBaseName == '\\')
                {
                    pszBaseName++;
                    break;
                }

                length--;
                pszBaseName--;
            }

            dataFileFusion.pszFileName = pszBaseName;
        }
        else
        {
            dataFileFusion.pszFileName = NULL;
        }

        if (dataFileFusion.nbEntriesPtf > 0)
        {
            char szTime[32];
            FUS_TraceStartFormatTime(szTime, sizeof(szTime));

            /* Log differences */
            if(true == dataFileFusion.tagDiff.bWriteLogField)
            { /* Yes */
                dataFileFusion.openLogFile();  /* PMSTA08746 - 061009 - PMO */

                fprintf(dataFileFusion.tagDiff.hLogFile, "%s Processing of %s\n", szTime, pszFileFusion);
            }

            fprintf (stdout, "%s Processing of %s\n", szTime, pszFileFusion);


            /*
             *  Launch a fusion in test mode
             */
            FusionContext   ctx;    /* PMSTA-29510 - 071217 - PMO */

            /* Create or truncate temporaries tables #vector_id, #dom_port_fus, #fus_tab REF7560 - PMO */
            if (true == ctx.isTemporaryTableOk())
            { /* Ok */
                FUS_TraceSetCheckFn(DFT_Trace_SetCheckFn);

                for (int iIdxPtf = 0; iIdxPtf < dataFileFusion.nbEntriesPtf ; iIdxPtf++)
                {
                    ctx.addPtf(GET_ID(dataFileFusion.tabPtf[iIdxPtf], A_Ptf_Id));
                }

                ctx.setDataFileFusion(&dataFileFusion);

                const RET_CODE ret = ctx.fusion(dataFileFusion.tabFusArg[0]);

                if (RET_SUCCEED != ret)
                { /* Error */
                    fprintf (stderr, "Error %d returned by the FIN_Fusion with %s\n", ret, pszFileFusion);

                    /* Remove useless file / PMSTA08746 - 061009 - PMO */
                    if (true == dataFileFusion.tagDiff.bRemoveUseLessFile)
                    {
                        bRemoveFile = true;
                    }
                }
            }
            else
            { /* Error */
                fprintf (stderr, "Error while creating temporaries tables\n");
            }

            FUS_TraceStartFormatTime(szTime, sizeof(szTime));

            /* Write statistics */
            fprintf(stdout,                          "%s Events, passed:%u    failed:%u\n", szTime, dataFileFusion.tagDiff.uStatCmpEventOk , dataFileFusion.tagDiff.uStatCmpEventFail);
            fprintf(dataFileFusion.tagDiff.hLogFile, "%s Events, passed:%u    failed:%u\n", szTime, dataFileFusion.tagDiff.uStatCmpEventOk , dataFileFusion.tagDiff.uStatCmpEventFail);

            /* Global statistics / PMSTA08746 - 061009 - PMO */
            pTotalDataFileFusion->tagDiff.uStatCmpEventOk += dataFileFusion.tagDiff.uStatCmpEventOk;
            pTotalDataFileFusion->tagDiff.uStatCmpEventFail += dataFileFusion.tagDiff.uStatCmpEventFail;

            /* Remove useless file / PMSTA08746 - 061009 - PMO */
            if (true == dataFileFusion.tagDiff.bRemoveUseLessFile
                && 2 == dataFileFusion.tagDiff.uStatCmpEventOk
                && 0 == dataFileFusion.tagDiff.uStatCmpEventFail)
            {
                bRemoveFile = true;
            }

            dataFileFusion.closeLogFile();
        }
        else
        {
            /* Remove useless file / PMSTA08746 - 061009 - PMO */
            if (true == dataFileFusion.tagDiff.bRemoveUseLessFile)
            {
                bRemoveFile = true;
            }
        }
    }
    else
    { /* Error */
        printf("Error while opening %s\n", pszFileFusion);
    }

    gzclose(hgzFile);

    /* PMSTA08746 - 061009 - PMO */
    if (true == bRemoveFile)
    {
        fprintf(stdout, "Useless file %s has been removed\n", pszFileFusion);

        if (NULL != dataFileFusion.tagDiff.hLogFile)
        {
            fprintf(dataFileFusion.tagDiff.hLogFile, "Useless file %s has been removed\n", pszFileFusion);
        }

        remove(pszFileFusion);
    }

    /* Free all memory allocated */
    dataFileFusion.free();

#ifdef AAAPURIFY
#ifdef NT
    PurifyNewLeaks();       /* PMSTA08746 - 061009 - PMO */
    PurifyClearLeaks();     /* PMSTA08746 - 061009 - PMO */
#endif
#endif
}


/************************************************************************
**
**  Function    :   DFT_DisableProcOpti()
**
**  Description :   Disable all optimizations
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC void DFT_DisableProcOpti()
{
    for (int i = 0; i <= LASTENTITYOBJECT; i++) /* PMSTA07476 - DDV - 081127 - replace "<" with "<=" */
	{
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(i);

        if (objProcLstStp != nullptr)
	    {
		    for (int j = 0; objProcLstStp[j].action != NullAction ; j++)
		    {
	    	    if (objProcLstStp[j].optiIdx != NullOpti)
                {
                    objProcLstStp[j].optiIdx = NullOpti;
                }
            }
        }
    }
}
/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadInstrument()
**
**  Description :   Load from a fusion trace the instrument given has parameter
**
**  Argument    :   hgzFile         Handle on the compressed file
**                  instrumentID    Instrument
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadInstrument( gzFile                   hgzFile
                                          , const DBA_DYNFLD_STP *   // dynstPositionsTab
                                          , const int                // dynstPositionsNb
                                          , DBA_DYNFLD_STP **        pDynstInstrumentsTab
                                          , int *                    pDynstInstrumentsNb
                                          , const ID_T               instrumentID
                                          )
{
    bool found = false;

    for (int dynstInstrumentsIdx = 0 ; dynstInstrumentsIdx < *pDynstInstrumentsNb ; dynstInstrumentsIdx++ )
    {
        if (0 == CMP_ID(instrumentID, GET_ID((*pDynstInstrumentsTab)[dynstInstrumentsIdx], A_Instr_Id)))
        {
            found = true;
            break;
        }
    }

    if (false == found)
    {
        (void)gzrewind(hgzFile);

        if ( true == DFT_SeekTag(hgzFile, "<InstrumentTab>"))
        {
            DBA_DYNFLD_STP  instr;
            DBA_DYNST_ENUM  dynst;

            while (NULL != (instr = DFT_LoadXmlRecord(hgzFile)))
            {
                dynst = GET_DYNSTENUM(instr);

                if (  A_Instr == dynst
                   && 0 == CMP_ID(instrumentID, GET_ID(instr, A_Instr_Id))
                   )
                { /* Found */

                    const size_t size = ((*pDynstInstrumentsNb) + 1 ) * sizeof (DBA_DYNFLD_STP);
                    DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstInstrumentsTab, size);

                    if (NULL != pDynstTabTmp)
                    { /* Ok */
                        *pDynstInstrumentsTab = pDynstTabTmp;
                        (*pDynstInstrumentsTab)[*pDynstInstrumentsNb] = instr;
                        (*pDynstInstrumentsNb)++;
                    }
                    else
                    { /* Error */
                        printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                    }

                    break;
                }
                else
                { /* Not Found */
                    FREE_DYNST(instr, dynst);
                }
            }
        }
        else
        { /* Error */
            printf("Error Tag <InstrumentTab> not found in the fusion trace");
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadFusArg()
**
**  Description :   Load from a fusion trace the fusarg
**
**  Argument    :   hgzFile         Handle on the compressed file
**                  instrumentID    Instrument
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadFusArg( gzFile              hgzFile
                                      , DBA_DYNFLD_STP **   pDynstFusArgTab
                                      , int *               pDynstFusArgNb
                                      )
{
    (void)gzrewind(hgzFile);

    if ( true == DFT_SeekTag(hgzFile, "<fusArg>"))
    {
        DBA_DYNFLD_STP  fusArg;
        DBA_DYNST_ENUM  dynst;

        while (NULL != (fusArg = DFT_LoadXmlRecord(hgzFile)))
        {
            dynst = GET_DYNSTENUM(fusArg);

            if ( Fus_Arg == dynst )
            { /* Found */

                const size_t size = ((*pDynstFusArgNb) + 1 ) * sizeof (DBA_DYNFLD_STP);
                DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstFusArgTab, size);

                if (NULL != pDynstTabTmp)
                { /* Ok */
                    *pDynstFusArgTab = pDynstTabTmp;
                    (*pDynstFusArgTab)[*pDynstFusArgNb] = fusArg;
                    (*pDynstFusArgNb)++;
                }
                else
                { /* Error */
                    printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                }

                break;
            }
            else
            { /* Not Found */
                FREE_DYNST(fusArg, dynst);
            }
        }
    }
    else
    { /* Error */
        printf("Error Tag <fusArg> not found in the fusion trace");
    }
}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadFusArg()
**
**  Description :   Load from a fusion trace the FusArgTab
**
**  Argument    :   hgzFile         Handle on the compressed file
**                  instrumentID    Instrument
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadFusArgTab( gzFile              hgzFile
                                         , DBA_DYNFLD_STP **   pDynstFusArgTab
                                         , int *               pDynstFusArgNb
                                         )
{
    (void)gzrewind(hgzFile);

    if ( true == DFT_SeekTag(hgzFile, "<FusArgTab>"))
    {
        DBA_DYNFLD_STP  fusArg;
        DBA_DYNST_ENUM  dynst;

        while (NULL != (fusArg = DFT_LoadXmlRecord(hgzFile)))
        {
            dynst = GET_DYNSTENUM(fusArg);

            if ( Fus_Arg == dynst )
            { /* Found */

                const size_t size = ((*pDynstFusArgNb) + 1 ) * sizeof (DBA_DYNFLD_STP);
                DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstFusArgTab, size);

                if (NULL != pDynstTabTmp)
                { /* Ok */
                    *pDynstFusArgTab = pDynstTabTmp;
                    (*pDynstFusArgTab)[*pDynstFusArgNb] = fusArg;
                    (*pDynstFusArgNb)++;
                }
                else
                { /* Error */
                    printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                }

                break;
            }
            else
            { /* Not Found */
                FREE_DYNST(fusArg, dynst);
            }
        }
    }
    else
    { /* Error */
        printf("Error Tag <fusArg> not found in the fusion trace");
    }
}

/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadPortfolio()
**
**  Description :   Load from a fusion trace the portfolio given has parameter
**
**  Argument    :   hgzFile         Handle on the compressed file
**                  portfolioID     Portfolio
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadPortfolio( gzFile                   hgzFile
                                         , const DBA_DYNFLD_STP *   // dynstPositionsTab
                                         , const int                // dynstPositionsNb
                                         , DBA_DYNFLD_STP **        pDynstPortfoliosTab
                                         , int *                    pDynstPortfoliosNb
                                         , const ID_T               portfolioID
                                         )
{
    bool found = false;

    for (int dynstPortfoliosIdx = 0 ; dynstPortfoliosIdx < *pDynstPortfoliosNb ; dynstPortfoliosIdx++ )
    {
        if (0 == CMP_ID(portfolioID, GET_ID((*pDynstPortfoliosTab)[dynstPortfoliosIdx], A_Ptf_Id)))
        {
            found = true;
            break;
        }
    }

    if (false == found)
    {
        (void)gzrewind(hgzFile);

        if ( true == DFT_SeekTag(hgzFile, "<FUS_PortfolioProcessing>"))
        {
            DBA_DYNFLD_STP  ptf;
            DBA_DYNST_ENUM  dynst;

            while (NULL != (ptf = DFT_LoadXmlRecord(hgzFile)))
            {
                dynst = GET_DYNSTENUM(ptf);

                if (  A_Ptf == dynst
                   && 0 == CMP_ID(portfolioID, GET_ID(ptf, A_Ptf_Id))
                   )
                { /* Found */

                    const size_t size = ((*pDynstPortfoliosNb) + 1 ) * sizeof (DBA_DYNFLD_STP);
                    DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstPortfoliosTab, size);

                    if (NULL != pDynstTabTmp)
                    { /* Ok */
                        *pDynstPortfoliosTab = pDynstTabTmp;
                        (*pDynstPortfoliosTab)[*pDynstPortfoliosNb] = ptf;
                        (*pDynstPortfoliosNb)++;
                    }
                    else
                    { /* Error */
                        printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                    }

                    break;
                }
                else
                { /* Not Found */
                    FREE_DYNST(ptf, dynst);
                }
            }
        }
        else
        { /* Error */
            printf("Error Tag <FUS_PortfolioProcessing> not found in the fusion trace");
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadInstrumentsPortfolios()
**
**  Description :   Load from a fusion trace, instruments and portfolios related to positions given
**
**  Argument    :   hgzFile Handle on the compressed file
**                  code    Operation code
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadInstrumentsPortfolios( gzFile                   hgzFile
                                                     , const DBA_DYNFLD_STP *   dynstPositionsTab
                                                     , const int                dynstPositionsNb
                                                     , DBA_DYNFLD_STP **        pDynstPortfoliosTab
                                                     , int *                    pDynstPortfoliosNb
                                                     , DBA_DYNFLD_STP **        pDynstInstrumentsTab
                                                     , int *                    pDynstInstrumentsNb
                                                     , DBA_DYNFLD_STP **        pDynstFusArgTab
                                                     , int *                    pDynstFusArgNb
                                                     , DBA_DYNFLD_STP **        pDynstFusArgTabTab
                                                     , int *                    pDynstFusArgTabNb
                                                     )
{
    /* Browse all positions */
    for (int dynstPositionsIdx = 0 ; dynstPositionsIdx < dynstPositionsNb ; dynstPositionsIdx++ )
    {
        /* Load the portfolio if it is not already loaded */
        DFT_DebugConsoleLoadPortfolio( hgzFile
                                     , dynstPositionsTab
                                     , dynstPositionsNb
                                     , pDynstPortfoliosTab
                                     , pDynstPortfoliosNb
                                     , GET_ID(dynstPositionsTab[dynstPositionsIdx], ExtPos_PtfId)
                                     );

        /* Load the instrument if it is not already loaded */
        DFT_DebugConsoleLoadInstrument( hgzFile
                                      , dynstPositionsTab
                                      , dynstPositionsNb
                                      , pDynstInstrumentsTab
                                      , pDynstInstrumentsNb
                                      , GET_ID(dynstPositionsTab[dynstPositionsIdx], ExtPos_InstrId)
                                      );
    }

    /* Load fusarg if it is not already loaded */
    DFT_DebugConsoleLoadFusArg( hgzFile
                              , pDynstFusArgTab
                              , pDynstFusArgNb
                              );

    /* Load FusArgTab if it is not already loaded */
    DFT_DebugConsoleLoadFusArgTab( hgzFile
                              , pDynstFusArgTabTab
                              , pDynstFusArgTabNb
                              );

}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadPosition()
**
**  Description :   Load primary position from a fusion trace
**
**  Argument    :   hgzFile Handle on the compressed file
**                  code    Operation code
**                  bSecondLoad         Use the second load section
**                  bSecondaryPosition  Load secondary position
**                  pDynstTab           Array to fill
**                  pDynstNb            # entries into pDynstTab
**
**  Return      :   None
**
**  Last modif. :   PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadPosition(gzFile hgzFile, CODE_T code, const bool bSecondLoad, const bool bSecondaryPosition, DBA_DYNFLD_STP ** pDynstTab, int * pDynstNb)
{
    (void)gzrewind(hgzFile);

    bool bStatus = true;

    if (true == bSecondLoad)
    {
        bStatus =  true == DFT_SeekTag(hgzFile, "<FIN_UpdateDataBase>")
                && true == DFT_SeekTag(hgzFile, "<step>");
    }

    if (true == bStatus && true == DFT_SeekTag(hgzFile, "<FIN_UpdateDataBase>"))
    {
        DBA_DYNFLD_STP  pos;
        DBA_DYNST_ENUM  dynst;
        int             found = 0;

        while (NULL != (pos = DFT_LoadXmlRecord(hgzFile)))
        {
            dynst = GET_DYNSTENUM(pos);

            if (  ExtPos == dynst
               && (   PosPrimary_Primary == GET_POSPRIMARY(pos, ExtPos_PrimaryEn)
                  || (PosPrimary_Second  == GET_POSPRIMARY(pos, ExtPos_PrimaryEn) && true == bSecondaryPosition)
                  )
               && NULL != strstr (code, GET_CODE(pos, ExtPos_OpenOpCd))       /* PMSTA-17020 - 021013 - PMO */
               )
            { /* Found */

                const size_t size = ((*pDynstNb) + 1 ) * sizeof (DBA_DYNFLD_STP);
                DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstTab, size);

                if (NULL != pDynstTabTmp)
                { /* Ok */
                    *pDynstTab = pDynstTabTmp;
                    (*pDynstTab)[*pDynstNb] = pos;
                    (*pDynstNb)++;
                }
                else
                { /* Error */
                    printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                }

                found++;
            }
            else
            { /* Not Found */
                FREE_DYNST(pos, dynst);
            }
        }

        if (found > 0)
        {
            printf ( "%d positions loaded" , found);
        }
        else
        {
            printf ( "Not Found !!!" );
        }
    }
    else
    { /* Error */
        printf ( "Error: tag FIN_UpdateDataBase not found\n" );
    }
}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleLoadFusionStep()
**
**  Description :   Load primary position from a fusion trace
**
**  Argument    :   hgzFile Handle on the compressed file
**                  code    Operation code
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsoleLoadFusionStep(gzFile hgzFile, const int fusionStepToLoad, DBA_DYNFLD_STP ** pDynstTab, int * pDynstNb)
{
    (void)gzrewind(hgzFile);

    if (  true == DFT_SeekTag(hgzFile, "<FIN_FusionLoop>"))
    {
        DBA_DYNFLD_STP  pos1        = NULL;
        DBA_DYNFLD_STP  pos2        = NULL;
        char            szDyn[256];
        int             iStep;
        bool            found       = false;

        for(;;)
        {
            if (false == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                break;
            }

            if (0 == strcmp("FIN_PosFusion", szDyn)
               && true == DFT_SeekTag(hgzFile, "<step>")
               && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), hgzFile))
            {
                iStep = atoi (szDyn);

                if (iStep == fusionStepToLoad)
                {
                    DBA_DYNFLD_STP pos;

                    found = true;

                    for ( int x = 0 ; x < 4 ; x++ )
                    {
                        pos = DFT_LoadXmlRecord(hgzFile, true, szDyn);

                        if (0 == strcmp(szDyn, "position1"))
                        {
                            pos1 = pos;
                            pos  = NULL;
                        }

                        if (0 == strcmp(szDyn, "position2"))
                        {
                            pos2 = pos;
                            break;
                        }

                        FREE_DYNST(pos, ExtPos);
                    }
                    break;
                }
            }
        }

        if (true == found)
        {
            if (NULL != pos1 && NULL != pos2)
            {
                const size_t size = ((*pDynstNb) + 2 ) * sizeof (DBA_DYNFLD_STP);
                DBA_DYNFLD_STP * pDynstTabTmp = (DBA_DYNFLD_STP*) realloc(*pDynstTab, size);

                if (NULL != pDynstTabTmp)
                { /* Ok */
                    *pDynstTab = pDynstTabTmp;
                    (*pDynstTab)[*pDynstNb] = pos1;
                    (*pDynstNb)++;
                    (*pDynstTab)[*pDynstNb] = pos2;
                    (*pDynstNb)++;
                }
                else
                { /* Error */
                    printf ( "Error: not enough memory to allocate " szSimpleFormatLongInt" bytes\n" , (LONGINT_T)size);
                }
            }
            else
            { /* Error */
                printf ( "Error: while loading position for the FIN_PosFusion\n" );
            }
        }
        else
        { /* Error */
            printf ( "Error: step %d of the FIN_PosFusion not found\n" , fusionStepToLoad);
        }
    }
    else
    { /* Error */
        printf ( "Error: tag FIN_FusionLoop not found\n" );
    }
}


/************************************************************************
**
**  Function    :   DFT_DebugConsoleFusion()
**
**  Description :   Testing the fusion for specific positions
**
**  Argument    :
**
**  Return      :   None
**
**  Last modif. :   PMSTA-29510 - 071217 - PMO : Memory overflow when too much ptf are sent to a fusion server
**
*************************************************************************/
STATIC void DFT_DebugConsoleFusion( const DBA_DYNFLD_STP *  dynstPositionsTab
                                  , const int               dynstPositionsNb
                                  , const DBA_DYNFLD_STP *  dynstPortfoliosTab
                                  , const int               dynstPortfoliosNb
                                  , const DBA_DYNFLD_STP *  dynstInstrumentsTab
                                  , const int               dynstInstrumentsNb
                                  , const DBA_DYNFLD_STP *  // dynstFusArgTab
                                  , const int               // dynstFusArgNb
                                  , const DBA_DYNFLD_STP *  dynstFusArgTabTab
                                  , const int               dynstFusArgTabNb
                                  )
{
    DATAFILEFUSION_ST dataFileFusion;


    if (   dynstPositionsNb   > 0
        && dynstPortfoliosNb  > 0
        && dynstInstrumentsNb > 0
       )
    { /* Ok */
        /*
         *  Load data from the xml file
         */
//        DFT_LoadFusArg(hgzFile,           &dataFileFusion);

        int             iStep = 1;
        FUSIONSTEP_ST   tagFusionStep;
        DBA_DYNFLD_STP  dynStp;


        dataFileFusion.console = true;

        /*
         * FusArg
        for (int dynstFusArgIdx = 0 ; dynstFusArgIdx < dynstFusArgNb ; dynstFusArgIdx++ )
        {
            dynStp = FUS_DynStDup(dynstFusArgTab[dynstFusArgIdx], NULL);
            dataFileFusion.addFusArg(dynStp);

            tagFusionStep.set(iStep++, SD_FUSARG, dynStp);
            dataFileFusion.addFusionStep(&tagFusionStep);
        }
         */

        /*
         * FusArgTab
         */
        for (int dynstFusArgTabIdx = 0 ; dynstFusArgTabIdx < dynstFusArgTabNb ; dynstFusArgTabIdx++ )
        {
            dynStp = FUS_DynStDup(dynstFusArgTabTab[dynstFusArgTabIdx], NULL);
            dataFileFusion.addFusArg(dynStp);

            tagFusionStep.set(iStep++, 0, SD_FUSARG, dynStp);
            dataFileFusion.addFusionStep(&tagFusionStep);
        }

        /*
         * Portfolios
         */
        for (int dynstPortfoliosIdx = 0 ; dynstPortfoliosIdx < dynstPortfoliosNb ; dynstPortfoliosIdx++ )
        {
            dynStp = FUS_DynStDup(dynstPortfoliosTab[dynstPortfoliosIdx], NULL);
            dataFileFusion.addPtf(dynStp);

            tagFusionStep.set(iStep++, 0, SD_PORTFOLIO, dynStp);
            dataFileFusion.addFusionStep(&tagFusionStep);
        }

        /*
         * Positions
         */
        for (int dynstPositionsIdx = 0 ; dynstPositionsIdx < dynstPositionsNb ; dynstPositionsIdx++ )
        {
            dynStp = FUS_DynStDup(dynstPositionsTab[dynstPositionsIdx], NULL);
            dataFileFusion.addPosition(dynStp);

            tagFusionStep.set(iStep++, 0, SD_POSITION, dynStp);
            dataFileFusion.addFusionStep(&tagFusionStep);
        }

        /*
         * Instruments
         */
        for (int dynstInstrumentsIdx = 0 ; dynstInstrumentsIdx < dynstInstrumentsNb ; dynstInstrumentsIdx++ )
        {
            dynStp = FUS_DynStDup(dynstInstrumentsTab[dynstInstrumentsIdx], NULL);
            dataFileFusion.addInstrument(dynStp);

            tagFusionStep.set(iStep++, 0, SD_INSTRUMENT, dynStp);
            dataFileFusion.addFusionStep(&tagFusionStep);
        }


// ok       DFT_LoadPtf(hgzFile,              &dataFileFusion);
// ok       DFT_LoadFusion(hgzFile,           &dataFileFusion);
//        DFT_LoadFusionProcessing(hgzFile, &dataFileFusion);

        /*
         *  Load settings from envrionment variables
         */
        DFT_Settings(&dataFileFusion);

        if (dataFileFusion.nbEntriesPtf > 0)
        {
            /*
             *  Launch a fusion in test mode
             */
            FusionContext ctx;    /* PMSTA-29510 - 071217 - PMO */

            /* Create or truncate temporaries tables #vector_id, #dom_port_fus, #fus_tab REF7560 - PMO */
            if (true == ctx.isTemporaryTableOk())
            { /* Ok */
//                    FUS_TraceSetCheckFn(DFT_Trace_SetCheckFn);

                for (int iIdxPtf = 0; iIdxPtf < dataFileFusion.nbEntriesPtf ; iIdxPtf++)
                {
                    ctx.addPtf(GET_ID(dataFileFusion.tabPtf[iIdxPtf], A_Ptf_Id));
                }

                ctx.setDataFileFusion(&dataFileFusion);

                const RET_CODE ret = ctx.fusion(dataFileFusion.tabFusArg[0]);

                if (RET_SUCCEED != ret)
                { /* Error */
                    printf("Error %d returned by the FIN_Fusion\n", ret);
                }
            }
            else
            { /* Error */
                printf("Error while creating temporaries tables\n");
            }

            if (NULL != dataFileFusion.tagDiff.hLogFile)
            {
                fclose(dataFileFusion.tagDiff.hLogFile);
            }
        }
    }
    else
    { /* Error */
        printf("Error missing data: #pos:%d #instr:%d #ptf:%d\n", dynstPositionsNb, dynstPortfoliosNb, dynstInstrumentsNb);

    }

    /* Free all memory allocated */
    dataFileFusion.free();
}





/************************************************************************
**
**  Function    :   DFT_DebugConsole()
**
**  Description :   Console for debugging a XLM fusion trace
**
**  Argument    :   hgzFile Handle on the compressed file
**
**  Return      :   None
**
**  Last modif. :
**
*************************************************************************/
STATIC void DFT_DebugConsole(gzFile hgzFile)
{
    DBA_DYNFLD_STP *    dynstPositionsTab   = NULL;
    int                 dynstPositionsNb    = 0;
    DBA_DYNFLD_STP *    dynstPortfoliosTab  = NULL;
    int                 dynstPortfoliosNb   = 0;
    DBA_DYNFLD_STP *    dynstInstrumentsTab = NULL;
    int                 dynstInstrumentsNb  = 0;
    DBA_DYNFLD_STP *    dynstFusArgTab      = NULL;
    int                 dynstFusArgNb       = 0;
    DBA_DYNFLD_STP *    dynstFusArgTabTab   = NULL;
    int                 dynstFusArgTabNb    = 0;
    char                szCmd[64];
    char                code[32768];                                           /* PMSTA-17020 - 021013 - PMO */
    bool                bExit               = false;
    bool                bSecondLoad         = false;
    bool                bSecondaryPosition  = false;

    do
    {
        printf ( "\n -- Console --\n"
                 "1) Load secondary positions (%s)\n"
                 "2) Use the second database load (%s)\n\n"
                 "a) Load primary positions from the update database section\n"
                 "b) Load a FIN_PosFusion processing\n"
                 "c) Load involved instruments & portfolios (+fusarg)\n\n"
                 "s) Call FIN_SetFusState\n"
                 "y) Launch the fusion engine with loaded data in memory\n\n"
                 "x) Exit\n>"
               , true == bSecondaryPosition ? "enable" : "disable"
               , true == bSecondLoad        ? "enable" : "disable"
               );

        fgets ( szCmd , sizeof ( szCmd ) , stdin );

        switch  ( szCmd[0] )
        {
            case '1': /* Load secondary positions */
                bSecondaryPosition = ! bSecondaryPosition;
                break;

            case '2': /* Use the second database load */
                bSecondLoad = ! bSecondLoad;
                break;

            case 'a': /* Load primary positions from the update database section */
                {
                    printf ( "Operation code:\n>" );
                    fgets ( code , sizeof ( code ) , stdin );
                    int newLine = SYS_StrLen ( code ) - 1;

                    /* Remove the new line character */
                    if ( newLine > 0 && code[newLine] == '\n' )
                    {
                        code[newLine] = 0;
                    }

                    DFT_DebugConsoleLoadPosition(hgzFile, code, bSecondLoad, bSecondaryPosition, &dynstPositionsTab, &dynstPositionsNb);
                }
                break;

            case 'b': /* Load a FIN_PosFusion processing */
                {
                    printf ( "Fusion step of the FIN_PosFusion:\n>" );
                    fgets ( code , sizeof ( code ) , stdin );

                    DFT_DebugConsoleLoadFusionStep(hgzFile, atoi (code), &dynstPositionsTab, &dynstPositionsNb);
                }
                break;

            case 'c' : /* Load related instruments & portfolios (+fusarg) */
                DFT_DebugConsoleLoadInstrumentsPortfolios( hgzFile
                                                         , dynstPositionsTab
                                                         , dynstPositionsNb
                                                         , &dynstPortfoliosTab
                                                         , &dynstPortfoliosNb
                                                         , &dynstInstrumentsTab
                                                         , &dynstInstrumentsNb
                                                         , &dynstFusArgTab
                                                         , &dynstFusArgNb
                                                         , &dynstFusArgTabTab
                                                         , &dynstFusArgTabNb
                                                         );
                break;

            case 's': /* Call FIN_SetFusState */
                {
                    FIN_FUS_CONTEXT_ST  ctx;
                    DATETIME_T          startDate;

                    startDate.time = 0;
                    startDate.date = 1;

                    for (int idx=0; idx < dynstPositionsNb; idx++)
                    {
                        (void)FIN_SetFusState(&ctx, dynstPositionsTab[idx], startDate, 0);
                        printf ("[%2d] FusState %d\n", idx, (int) GET_ENUM(dynstPositionsTab[idx], ExtPos_FusStateEn));
                    }
                }
                break;

            case 'y': /* Insert in memory all loaded data */
                DFT_DebugConsoleFusion( dynstPositionsTab
                                      , dynstPositionsNb
                                      , dynstPortfoliosTab
                                      , dynstPortfoliosNb
                                      , dynstInstrumentsTab
                                      , dynstInstrumentsNb
                                      , dynstFusArgTab
                                      , dynstFusArgNb
                                      , dynstFusArgTabTab
                                      , dynstFusArgTabNb
                                      );
                break;



            case 'x': /* Exit */
                bExit = true;
                break;
        }

    }
    while ( false == bExit );
}


/************************************************************************
**
**  Function    :   DFT_DebugXmlFile()
**
**  Description :   Testing the fusion for one given file
**
**  Argument    :   pszFileFusion   Compressed xml trace file
**
**  Return      :   None
**
**  Last modif. :   PMSTA-YYYY - 150409 - PMO : Fusion test like TDDJ
**
*************************************************************************/
STATIC void DFT_DebugXmlFile(const char * pszFileFusion)
{
    gzFile hgzFile = gzopen(pszFileFusion, "rb");

    if (NULL != hgzFile)
    { /* Ok */

        DFT_DebugConsole(hgzFile);

        gzclose(hgzFile);
    }
    else
    { /* Error */
        printf("Unable to open %s",pszFileFusion);
    }
}


/************************************************************************
**
**  Function    :   DFT_FileFusion()
**
**  Description :   Main function for testing the fusion
**
**  Argument    :   pszTestFusion           File or directory to test
**                  pTotalDataFileFusion    Storage of global statistics
**
**  Return      :   None
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**
*************************************************************************/
STATIC void DFT_FileFusion(const char * pszTestFusion, DATAFILEFUSION_STP pTotalDataFileFusion) /* PMSTA08746 - 061009 - PMO */
{
    if (pszTestFusion[0] == '#')
    {
        DFT_DebugXmlFile(pszTestFusion + 1);
    }
    else
    {
        if (SYS_EndWith(pszTestFusion, ".gz"))
        {
            DFT_FileFusionProcessing(pszTestFusion, pTotalDataFileFusion);
        }
        else 
        {
            std::string directory(pszTestFusion);
            std::vector<SYS_FileInfo> fileList;

            bool ok = SYS_DIRentryList(directory, fileList);
            if (ok)
            {
                for (auto const& aFileInfo : fileList) {
                    if (aFileInfo.isFile && aFileInfo.isReadable)
                    {
                        if (SYS_EndWith(aFileInfo.fileName.c_str(), ".gz")) {
                            DFT_FileFusionProcessing(aFileInfo.fileName.c_str(), pTotalDataFileFusion);
                        }
                    }
                }
            }
            else
            { /* Error */
                printf("Error while retrieving stat of %s\n", pszTestFusion);
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DFT_TestFusion()
**
**  Description :   Main function for testing the fusion
**
**  Argument    :   pszTestFusion           File or directory to test
**
**  Return      :   None
**
**  Last modif. :   PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                  PMSTA-9175 - 050110 - PMO : TDDJ can crash if the exchange gain P&L is no more generated
*************************************************************************/

void DFT_TestFusion (const char * pszTestFusion)
{
extern bool EV_ICUContextStatic;

    /* Avoid crash */
    EV_ICUContextStatic = true;

    DATAFILEFUSION_ST   dataFileFusion;     /* PMSTA08746 - 061009 - PMO */

    /* Load settings from environment variables */
    DFT_Settings(&dataFileFusion);

    /* Load configuration / PMSTA-9072 - 050510 - PMO */
    DFT_LoadConfig(&dataFileFusion);

    /* Remap some Balance position type ID / PMSTA-9072 - 050510 - PMO */
    DFT_RemapBalPosTypeID(&dataFileFusion);

    /* Disable proc optimization. Enabling implies more work */
    DFT_DisableProcOpti();

    /* Hook some SQL procs to allow retrieving data from the XML file / PMSTA-9072 - 050510 - PMO */
    DFT_HookSQLProc();

    //SERV_InitThreadTable();

#ifdef AAAPURIFY
#ifdef NT
            PurifyNewLeaks();                   /* PMSTA08746 - 061009 - PMO */
	        PurifyPrintf("DFT Testing...");     /* PMSTA08746 - 061009 - PMO */
#endif
#endif

    DFT_FileFusion(pszTestFusion, &dataFileFusion);


    /* PMSTA08746 - 061009 - PMO
     * Log total's differences
     */
    if(true == dataFileFusion.tagDiff.bWriteLogField)
    { /* Yes */
        dataFileFusion.openLogFile();

        /* Write statistics */
        fprintf(stdout,                          "\nTotal Events, passed:%u    failed:%u\n", dataFileFusion.tagDiff.uStatCmpEventOk , dataFileFusion.tagDiff.uStatCmpEventFail);
        fprintf(dataFileFusion.tagDiff.hLogFile, "\nTotal Events, passed:%u    failed:%u\n", dataFileFusion.tagDiff.uStatCmpEventOk , dataFileFusion.tagDiff.uStatCmpEventFail);

        dataFileFusion.closeLogFile();
    }

}


/* PMSTA-27843 - 200717 - PMO
 * File tree traversal
 */
class DftFileTreeTraversal
{
    public:
        DftFileTreeTraversal();
        ~DftFileTreeTraversal();

	    DftFileTreeTraversal            (const DftFileTreeTraversal &) = delete;
	    DftFileTreeTraversal & operator=(const DftFileTreeTraversal &) = delete;

        bool next   (std::string &);
        void setPath(const std::string &);

        void addFile            (const std::string &);  // For Unix ftw only
        void directoryProcessing(const std::string &);  // For Unix ftw only

    private:
        std::vector<std::string>    m_tabFiles;
        std::string                 m_error;
        std::string                 m_path;
        bool                        m_firstCall;
        size_t                      m_idxFiles;
};

/************************************************************************
**
**  Function    :  DftFileTreeTraversal::DftFileTreeTraversal
**
**  Description :  Constructor
**
**  Arguments   :  path
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFileTreeTraversal::DftFileTreeTraversal() : m_firstCall(true)
                                             , m_idxFiles(0)
{
}


/************************************************************************
**
**  Function    :  DftFileTreeTraversal::~DftFileTreeTraversal
**
**  Description :  Destructor
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFileTreeTraversal::~DftFileTreeTraversal()
{
}


/************************************************************************
**
**  Function    :   DftFileTreeTraversal::next
**
**  Description :   Obtain the next file
**
**  Arguments   :   fileName
**
**  Return      :   true  if ok
**                  false if no more file
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DftFileTreeTraversal::next(std::string & fileName)
{
    if (true == m_firstCall)
    {
        m_firstCall = false;
        struct  stat tagstat;

        if (0 == stat(m_path.c_str(), &tagstat))
        { // Ok
            if (S_IFDIR == (tagstat.st_mode & S_IFDIR))
            { // Directory processing
                directoryProcessing(m_path);
            }
            else
            { // File processing
                fileName = m_path;
                return true;
            }
        }
        else
        { /* Error */
            m_error = "Error while retrieving stat of " + m_path;
        }
    }

    const bool ret = m_idxFiles < m_tabFiles.size();

    if (true == ret)
    {
        fileName = m_tabFiles[m_idxFiles];
        m_idxFiles++;
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFileTreeTraversal::setPath
**
**  Description :  Define the path and reset data
**
**  Arguments   :  path
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void DftFileTreeTraversal::setPath(const std::string & path)
{
    m_tabFiles.clear();
    m_error.clear();
    m_path = path;
    m_firstCall = true;
    m_idxFiles = 0;
}


/************************************************************************
**
**  Function    :  DftFileTreeTraversal::addFile
**
**  Description :  Add the file name given. Used on Unix by ftw
**
**  Arguments   :  fileName
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void DftFileTreeTraversal::addFile(const std::string & fileName)
{
    m_tabFiles.push_back(fileName);
}


/************************************************************************
**
**  Function    :   DftFileTreeTraversal::directoryProcessing
**
**  Description :   Directory processing. Might call it recursively. File found (with extention .txt) are stored internally into m_tabFiles. Have to be obtained over the "next()" function
**
**  Arguments   :   directory
**
**  Return      :   true  if ok
**                  false if no more file
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
*                                 2023-02-02 FME Use SYS_DIRentryList
**
*************************************************************************/
void DftFileTreeTraversal::directoryProcessing(const std::string& directory)
{
    std::vector<SYS_FileInfo> fileList;

    bool ok = SYS_DIRentryList(directory, fileList);
    if (ok)
    {
        for (auto const& aFileInfo : fileList) {
            if (aFileInfo.isFile && aFileInfo.isReadable)
            {
                if (SYS_EndWith(aFileInfo.fileName.c_str(), ".txt")) {
                    addFile(aFileInfo.fileName);
                }
            }
        }
    }
}


/* PMSTA-27843 - 200717 - PMO
 * Data Loading from the fusion trace file
 */
class DftFusionLoadFusionTrace
{
    public:
        DftFusionLoadFusionTrace();
        ~DftFusionLoadFusionTrace();

	    DftFusionLoadFusionTrace            (const DftFusionLoadFusionTrace &) = delete;
	    DftFusionLoadFusionTrace & operator=(const DftFusionLoadFusionTrace &) = delete;

        bool load(std::string &, const bool);
        void loadExtOpImportSection();

        void setSetSystemParameter(const std::string &, int );

        void clearPositionBalancePosition()
        {
            m_dataFileFusion.clearPositionBalancePosition();
        }

        int getNbPtf()
        {
            return m_dataFileFusion.nbEntriesPtf;
        }

        DBA_DYNFLD_STP getPtf(const int idx)
        {
            return m_dataFileFusion.tabPtf[idx];
        }

        DBA_DYNFLD_STP getFusArg(const int idx)
        {
            return m_dataFileFusion.tabFusArg[idx];
        }

        DATAFILEFUSION_STP getDataFileFusion()
        {
            return &m_dataFileFusion;
        }

        std::string getError()
        {
            return m_error;
        }

        /* This enable unit testing validation mode */
        void setValidationMode()
        {
            m_dataFileFusion.setValidationMode();
        }


    private:
        gzFile              m_gzFile;
        DATAFILEFUSION_ST   m_dataFileFusion;
        std::string         m_error;
};


/************************************************************************
**
**  Function    :  DftFusionLoadFusionTrace::DftFusionLoadFusionTrace
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFusionLoadFusionTrace::DftFusionLoadFusionTrace() : m_gzFile(nullptr)
{
}


/************************************************************************
**
**  Function    :  DftFusionLoadFusionTrace::~DftFusionLoadFusionTrace
**
**  Description :  Destructor
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFusionLoadFusionTrace::~DftFusionLoadFusionTrace()
{
    gzclose(m_gzFile);
}


/************************************************************************
**
**  Function    :   DftFusionLoadFusionTrace::load
**
**  Description :   Load the given "fusion trace file" into the object
**
**  Arguments   :   fileName
**                  bExclPosBpTaxLot
**
**  Return      :   true  if ok
**                  false if error
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**                  PMSTA-27843 - 021117 - JBC : Add Flag to limit xml data loaded
**
*************************************************************************/
bool DftFusionLoadFusionTrace::load(std::string & fileName, const bool bExclPosBpTaxLot)
{
    bool ret = false;

    m_gzFile = gzopen(fileName.c_str(), "rb");

    if (nullptr != m_gzFile)
    { /* Ok */
        /*
         *  Load data from the xml file
         */
        DFT_LoadFusArg(m_gzFile,           &m_dataFileFusion);
        DFT_LoadPtf(m_gzFile,              &m_dataFileFusion);
        DFT_LoadFusion(m_gzFile,           &m_dataFileFusion, bExclPosBpTaxLot);
        DFT_LoadFusionProcessing(m_gzFile, &m_dataFileFusion);

        loadExtOpImportSection();

        ret = true;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DftFusionLoadFusionTrace::loadExtOpImportSection
**
**  Description :   Load extOp from the import section of the "fusion trace file"
**
**  Arguments   :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void DftFusionLoadFusionTrace::loadExtOpImportSection()
{
    if (true == DFT_SeekTag(m_gzFile, "<Import>") && true == DFT_SeekTag(m_gzFile, "<ExtOpTab>"))
    {
        char szDyn[256];

        for(;;)
        {
            if (   true == DFT_SeekTag(m_gzFile, "<step>", "</ExtOpTab>")
                && true == DFT_XmlGetNextTag(szDyn, sizeof(szDyn), m_gzFile)
                )
            { // Found an extOp
                m_dataFileFusion.addExtOp(DFT_LoadXmlRecord(m_gzFile));
            }
            else
            { // Finish
                break;
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DftFusionLoadFusionTrace::setSetSystemParameter
**
**  Description :   Define the value of a system parameter
**
**  Arguments   :   parameter   System parameter
**                  value
**
**  Return      :   None
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void DftFusionLoadFusionTrace::setSetSystemParameter(const std::string & parameter, int value)
{
    m_dataFileFusion.setSetSystemParameter(parameter.c_str(), value);
}


/* PMSTA-27843 - 200717 - PMO
 * For the given file quick check file:
 *  1) Test the file content
 *  2) Extract the ptf name
 *  3) Check if it can be treated (no unknown keyword)
 *  4) Check if expected keyword(s) is/are exist                   -> For example, I want to test all tests with the keyowrd AdjustmentExchange
 *  5) Load system parameters
 */
class DftFusionQuickCheckProcessingFile
{
    public:
        DftFusionQuickCheckProcessingFile();

	    DftFusionQuickCheckProcessingFile            (const DftFusionQuickCheckProcessingFile &) = delete;
	    DftFusionQuickCheckProcessingFile & operator=(const DftFusionQuickCheckProcessingFile &) = delete;

        int load(DftFusionLoadFusionTrace &, const std::string &, const std::string &);

        std::string getPtfCode()
        {
            return m_ptfCode;
        }

        std::string getError()
        {
            return m_error;
        }

    private:
        std::string m_ptfCode;
        std::string m_keywords;
        std::string m_error;
};


/************************************************************************
**
**  Function    :  DftFusionQuickCheckProcessingFile::DftFusionQuickCheckProcessingFile
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFusionQuickCheckProcessingFile::DftFusionQuickCheckProcessingFile()
{
}


/************************************************************************
**
**  Function    :   DftFusionQuickCheckProcessingFile::load
**
**  Description :   Load the given "validation file"
**                  1) Test the file content
**                  2) Extract the ptf code
**                  3) Check if it can be treated (no unknown keyword)
**                  4) Check if expected keyword(s) is/are exist                   -> For example, I want to test all tests with the keyowrd AdjustmentExchange
**                  5) Load system parameters
**
**  Arguments   :   dftFusionLoadFusionTrace    System parameters while be loaded into
**                  fileName
**                  expectedKeywords     Example: "Buy AdjustmentExchange" To test only portfolios that have at least a buy and an Adjustment of type Exchange
**
**  Return      :   0 ok
**                  -1 if error
**                  1 if skipped
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
int DftFusionQuickCheckProcessingFile::load(DftFusionLoadFusionTrace & dftFusionLoadFusionTrace, const std::string & fileName, const std::string & expectedKeywords)
{
    std::fstream validationFile;

    validationFile.open(fileName.c_str(), std::fstream::in);                                  // c_str() for AIX obsolete compiler

    int ret = true == validationFile.is_open() ? 0 : -1;

    if (0 == ret)
    { // Reading the file
        std::string line;
        int         step            = 1;
        int         nbSeparatorLine = 0;

        while(std::getline(validationFile, line))
        {
            if (false == line.empty())
            {
                SYS_StringRemoveTags(line, "\r");

                if (true == std::equal(line.begin(), line.end(), separatorLine))
                {
                    nbSeparatorLine++;
                }

                switch (step)
                {
                    case 1: // Test if the file start with the expected line
                        ret = nbSeparatorLine > 0 ? 0 : -1;
                        step++;

                        if (-1 == ret)
                        {
                            m_error = "The file " + fileName + " doesn't start with the expected line. Line:'" + line + "'\n";
                        }
                        break;

                    case 2: // Extract ptf code
                        if (0 == line.compare(0, 5, "Ptf: "))
                        {
                            m_ptfCode = line.substr(5);
                            step++;
                        }
                        break;

                    case 3: // Check if it can be treated (no unknown keyword) and if expected keyword(s) is/are exist
                        if (0 == line.compare(0, 10, "Keywords: "))
                        {
                            m_keywords = line.substr(10);

                            DftFusionQuickCheckHeaderKeywords headerKeywords;

                            ret = true == headerKeywords.checkKeywords(m_keywords, expectedKeywords) ? 0 : 1;

                            step += 2;
                        }
                        break;

                    case 5: // Load system parameters
                        if (nbSeparatorLine == 3)
                        {
                            std::vector<std::string> tokens;

                            SYS_StringTokenize(tokens, line, ":");

                            if (2 == tokens.size())
                            {
                                const int value = atoi(tokens[1].c_str());

                                if (value > 0 || '0' == tokens[1][0])
                                { // A number. BP name are skipped
                                    dftFusionLoadFusionTrace.setSetSystemParameter(tokens[0], value);
                                }
                            }
                        }
                        break;
                }
            }

            if (0 != ret || nbSeparatorLine > 3)
            {
                break;
            }
        }
    }
    else
    {
        m_error = "Unable to open the file " + fileName;
    }

    return ret;
}


/* PMSTA-27843 - 200717 - PMO
 * Do the validation of the given file
 */
class DftFusionValidationFile
{
    public:
        DftFusionValidationFile();

	    DftFusionValidationFile            (const DftFusionValidationFile &) = delete;
	    DftFusionValidationFile & operator=(const DftFusionValidationFile &) = delete;

        bool validate(const std::string &, const std::string &, DftFusionReport &);
        void fusion  (DftFusionLoadFusionTrace &, DftFusionReport &);

        DftFileTreeTraversal & getDftFileTreeTraversal();

    private:
        bool validateFile(const std::string &, const std::string &, DftFusionReport &);

        DftFileTreeTraversal m_ftt;

};


/************************************************************************
**
**  Function    :  DftFusionValidationFile::DftFusionValidationFile
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFusionValidationFile::DftFusionValidationFile()
{
}


/************************************************************************
**
**  Function    :  DftFusionValidationFile::validateFile
**
**  Description :  Validate the given "validation file"
**
**  Arguments   :  fileName
**                 keywords             Expected keywords
**                 testFusionReport     Catch Fusion report
**
**  Return      :  true  if ok
**                 false if error
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DftFusionValidationFile::validateFile(const std::string & fileName, const std::string & keywords, DftFusionReport & testFusionReport)
{
    DftFusionQuickCheckProcessingFile   dftFusionQuickCheckProcessingFile;
    DftFusionLoadFusionTrace            dftFusionLoadFusionTrace;
    const int                           status = dftFusionQuickCheckProcessingFile.load(dftFusionLoadFusionTrace, fileName, keywords);
    bool                                ret    = true;

    switch (status)
    {
        case 0: // Normal processing
            { // OK
                dftFusionLoadFusionTrace.setValidationMode();

                if (true == testFusionReport.m_first)
                {
                    testFusionReport.m_first = false;
                    testFusionReport.m_testName += ": ";
                }
                else
                {
                    testFusionReport.m_testName += ", ";
                }

                testFusionReport.m_testName += dftFusionQuickCheckProcessingFile.getPtfCode();

                std::string fileXmlData = fileName;

                SYS_StringFindAndReplaceAll(fileXmlData, ".txt", ".xml.gz");

                if (true == dftFusionLoadFusionTrace.load(fileXmlData,true))
                {
                    dftFusionLoadFusionTrace.clearPositionBalancePosition();

                    std::string     envFolder            = fileName;
                    const char *    directorySeparator[] = { "\\" , "/"};

                    for (int idxSeparator = 0 ; idxSeparator < 2 ; idxSeparator++)
                    {
                        const std::string::size_type length = envFolder.length();
                        const std::string::size_type idx    = envFolder.rfind(directorySeparator[idxSeparator]);
                        if (std::string::npos != idx)
                        {
                            envFolder.erase(idx, length);
                        }
                    }

                    SYS_PutEnv("AAADFTFUSIONQUICKVALIDATION", envFolder.c_str());

                    fusion(dftFusionLoadFusionTrace, testFusionReport);
                }
                else
                { // Error
                    testFusionReport.m_output << dftFusionLoadFusionTrace.getError();
                }
            }
            break;

        case 1: // Test case skipped
//            testFusionReport.m_testName += "(" + dftFusionQuickCheckProcessingFile.getPtfCode() + ")";
            break;

        default: // Error
            testFusionReport.m_output << dftFusionQuickCheckProcessingFile.getError();
            ret = false;
            break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionValidationFile::validate
**
**  Description :  Validate the given directory tree
**
**  Arguments   :  directory
**                 keywords             Expected keywords
**                 testFusionReport     Catch Fusion report
**
**  Return      :  true  if ok
**                 false if error
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DftFusionValidationFile::validate(const std::string & directory, const std::string & keywords, DftFusionReport & testFusionReport)
{
    m_ftt.setPath(directory);

#ifndef NT
    // For ftw on Unix
    ThreadDataCtxGeneric *  pthreadDataCtxGeneric   = SYS_GetThreadDataCtxGeneric();
    pthreadDataCtxGeneric->pDftFusionValidationFile = static_cast<void *>(this);
#endif

    std::string fileName;
    bool        ret = true;

    while (true == m_ftt.next(fileName) && false == fileName.empty())
    {
        if (false == validateFile(fileName, keywords, testFusionReport))
        {
            ret = false;
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionValidationFile::fusion
**
**  Description :  Run the fusion
**
**  Arguments   :  dftFusionLoadFusionTrace
**
**  Return      :  None
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**                 PMSTA-29510 - 071217 - PMO : Memory overflow when too much ptf are sent to a fusion server
**                 PMSTA-22886 - 141217 - PMO : Fusion issue on partial Exchange - Adjustment with adj nature = Exchange
**
*************************************************************************/
void DftFusionValidationFile::fusion(DftFusionLoadFusionTrace & dftFusionLoadFusionTrace, DftFusionReport & testFusionReport)
{
    FusionContext   ctx;    /* PMSTA-29510 - 071217 - PMO */

    /* Create or truncate temporaries tables #vector_id, #dom_port_fus, #fus_tab REF7560 - PMO */
    if (true == ctx.isTemporaryTableOk())
    { /* Ok */
        const int nbPtf = dftFusionLoadFusionTrace.getNbPtf();

        for (int iIdxPtf = 0; iIdxPtf < nbPtf; iIdxPtf++)
        {
            ctx.addPtf(GET_ID(dftFusionLoadFusionTrace.getPtf(iIdxPtf), A_Ptf_Id));
        }

        ctx.setTestFusionReport(&testFusionReport);                                     /* PMSTA-29510 - 071217 - PMO */
        ctx.setDataFileFusion(dftFusionLoadFusionTrace.getDataFileFusion());            /* PMSTA-29510 - 071217 - PMO */

        ThreadDataCtxGeneric *  threadDataCtxGeneric = SYS_GetThreadDataCtxGeneric();   /* PMSTA-22886 - 141217 - PMO */
        if (nullptr != threadDataCtxGeneric)
        {
            threadDataCtxGeneric->setDftFusionLoadFusionTrace(&dftFusionLoadFusionTrace);
        }

        const RET_CODE ret = ctx.fusion(dftFusionLoadFusionTrace.getFusArg(0));

        if (nullptr != threadDataCtxGeneric)
        {
            threadDataCtxGeneric->setDftFusionLoadFusionTrace(nullptr);
        }

        if (RET_SUCCEED != ret)
        { /* Error */
            testFusionReport.m_output << "Error " << SYS_ToString(ret) << " returned by the FIN_Fusion" << std::endl;
        }
    }
    else
    { /* Error */
        testFusionReport.m_output << "Error while creating temporaries tables" << std::endl;
    }
}


/************************************************************************
**
**  Function    :  DftFusionValidationFile::getDftFileTreeTraversal
**
**  Description :  Return the DftFileTreeTraversal
**
**  Arguments   :  None
**
**  Return      :  The DftFileTreeTraversal
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFileTreeTraversal & DftFusionValidationFile::getDftFileTreeTraversal()
{
    return m_ftt;
}


#ifdef FMETOREMOVE
//ifndef NT

/************************************************************************
**
**  Function    :   DFT_UnixFileTreeTraversal
**
**  Description :   Unix callback function for Directory processing. Might call it recursively with DftFileTreeTraversal::directoryProcessing
**
**  Arguments   :   fileName
**                  type
**
**  Return      :   0
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
int DFT_UnixFileTreeTraversal(const char * fileName, const struct stat *, int type)
{
    switch (type)
    {
        case FTW_F: // A file
            if (strstr(fileName, ".txt") != nullptr)
            {
                ThreadDataCtxGeneric *      pthreadDataCtxGeneric    = SYS_GetThreadDataCtxGeneric();
                DftFusionValidationFile *   pDftFusionValidationFile = static_cast<DftFusionValidationFile *>(pthreadDataCtxGeneric->pDftFusionValidationFile);
                DftFileTreeTraversal &      dftFileTreeTraversal     = pDftFusionValidationFile->getDftFileTreeTraversal();
                dftFileTreeTraversal.addFile(fileName);
            }
            break;

        default:
            break;
    }

    return 0;
}

#endif


/************************************************************************
**
** Function    : DFT_GetInstrumentById
**
** Description : Function C Replace Stored Proc for unittest
**
** Arguments   : admArg     Input ID
**               sInstr     Resulting instrument
**
** Return      :
**
** Creation    : PMSTA-22886 - 141217 - PMO : Fusion issue on partial Exchange - Adjustment with adj nature = Exchange
**
************************************************************************/
RET_CODE DFT_GetInstrumentById(OBJECT_ENUM                    ,
                               DBA_DYNFLD_STP           admArg,
                               DBA_DYNFLD_STP *         sInstr,
                               DbiConnectionHelper &          )
{
    RET_CODE                ret                  = RET_GEN_INFO_NODATA;
    ThreadDataCtxGeneric *  threadDataCtxGeneric = SYS_GetThreadDataCtxGeneric();

    if (nullptr != threadDataCtxGeneric)
    {
        DftFusionLoadFusionTrace * pDftFusionLoadFusionTrace = static_cast<DftFusionLoadFusionTrace *>(threadDataCtxGeneric->getDftFusionLoadFusionTrace());
        if (nullptr != pDftFusionLoadFusionTrace)
        {
            const int           nbInstrument = pDftFusionLoadFusionTrace->getDataFileFusion()->nbEntriesInstrument;
            DBA_DYNFLD_STP *    tabInstrument= pDftFusionLoadFusionTrace->getDataFileFusion()->tabInstrument;

            for (int idx = 0; idx < nbInstrument; idx++)
            {
                if (GET_ID(admArg, Adm_Arg_Id) == GET_ID(tabInstrument[idx], A_Instr_Id))
                {
                    CONVERT_DYNST(*sInstr, S_Instr, tabInstrument[idx], A_Instr);

                    ret = RET_SUCCEED;
                    break;
                }
            }
        }
    }

    return ret;
}


/************************************************************************
**
** Function    : DFT_GetPortfolioById
**
** Description : Function C Replace Stored Proc for unittest
**
** Arguments   : admArg     Input ID
**               sPtf       Resulting portfolio
**
** Return      :
**
** Creation    : PMSTA-29130 - 141117 - PMO : TaxLot / Adjustments Gross Amount
**
************************************************************************/
RET_CODE DFT_GetPortfolioById(OBJECT_ENUM                     ,
                               DBA_DYNFLD_STP           admArg,
                               DBA_DYNFLD_STP *         sPtf  ,
                               DbiConnectionHelper &          )
{
    RET_CODE                ret                  = RET_GEN_INFO_NODATA;
    ThreadDataCtxGeneric *  threadDataCtxGeneric = SYS_GetThreadDataCtxGeneric();

    if (nullptr != threadDataCtxGeneric)
    {
        DftFusionLoadFusionTrace * pDftFusionLoadFusionTrace = static_cast<DftFusionLoadFusionTrace *>(threadDataCtxGeneric->getDftFusionLoadFusionTrace());
        if (nullptr != pDftFusionLoadFusionTrace)
        {
            const int           nbPtf = pDftFusionLoadFusionTrace->getDataFileFusion()->nbEntriesPtf;
            DBA_DYNFLD_STP *    tabPtf= pDftFusionLoadFusionTrace->getDataFileFusion()->tabPtf;

            for (int idx = 0; idx < nbPtf; idx++)
            {
                if (GET_ID(admArg, Adm_Arg_Id) == GET_ID(tabPtf[idx], A_Ptf_Id))
                {
                    CONVERT_DYNST(*sPtf, S_Ptf, tabPtf[idx], A_Ptf);

                    ret = RET_SUCCEED;
                    break;
                }
            }
        }
    }

    return ret;
}


/************************************************************************
**
** Function    : DFT_GetAllPortfolioById
**
** Description : Function C Replace Stored Proc for unittest
**
** Arguments   : sPtf     Input ID
**               aPtf       Resulting portfolio
**
** Return      :
**
** Creation    : PMSTA-29130 - 141117 - PMO : TaxLot / Adjustments Gross Amount
**
************************************************************************/
RET_CODE DFT_GetAllPortfolioById(OBJECT_ENUM                  ,
                                 DBA_DYNFLD_STP           sPtf,
                                 DBA_DYNFLD_STP *         aPtf,
                                 DbiConnectionHelper &        )
{
    RET_CODE                ret                  = RET_GEN_INFO_NODATA;
    ThreadDataCtxGeneric *  threadDataCtxGeneric = SYS_GetThreadDataCtxGeneric();

    if (nullptr != threadDataCtxGeneric)
    {
        DftFusionLoadFusionTrace * pDftFusionLoadFusionTrace = static_cast<DftFusionLoadFusionTrace *>(threadDataCtxGeneric->getDftFusionLoadFusionTrace());
        if (nullptr != pDftFusionLoadFusionTrace)
        {
            const int           nbPtf = pDftFusionLoadFusionTrace->getDataFileFusion()->nbEntriesPtf;
            DBA_DYNFLD_STP *    tabPtf= pDftFusionLoadFusionTrace->getDataFileFusion()->tabPtf;

            for (int idx = 0; idx < nbPtf; idx++)
            {
                if (GET_ID(sPtf, S_Ptf_Id) == GET_ID(tabPtf[idx], A_Ptf_Id))
                {
                    COPY_DYNST(*aPtf, tabPtf[idx], A_Ptf);
                    ret = RET_SUCCEED;
                    break;
                }
            }
        }
    }

    return ret;
}


/* PMSTA-22886 - 141217 - PMO
 * Load data from the fusion trace in place of database
 */
class DftFusionHookDatabaseToFusionTrace
{
    public:
        DftFusionHookDatabaseToFusionTrace()
        {
            hookGetShInstrumentByCid();
            hookGetShPortfolioByCid();
            hookGetAllPortfolioById();
        }

        ~DftFusionHookDatabaseToFusionTrace()
        {
            unHookGetShInstrumentByCid();
            unHookGetShPortfolioByCid();
            unHookGetAllPortfolioById();
        }

    private:
        /*
         * get_sh_instrument_by_cid
         */
        DBA_PROC_STP getProcedureShInstrumentByCid()
        {
            MemoryPool      mp;
            DBA_DYNFLD_STP  admArg = mp.allocDynst(FILEINFO, Adm_Arg);

            SET_ID(admArg, Adm_Arg_Id, ID_1);

            return DBA_GetStoredProcs(Get, Instr, UNUSED, Adm_Arg, admArg, S_Instr);
        }

        void hookGetShInstrumentByCid()
        {
            DBA_PROC_STP procedure = getProcedureShInstrumentByCid();

            if (nullptr != procedure)
            {
                m_get_sh_instrument_by_cid = *procedure;

                procedure->server   = InternalProc;

                DBA_FCTDEF_ST fctdef;
                SYS_Bzero(&fctdef, sizeof(fctdef));

                fctdef.getFct = DFT_GetInstrumentById;
                procedure->fctDefSt = fctdef;

                // Don't compile on AIX procedure->fctDefSt = GETFCT(DFT_GetInstrumentById);
            }
        }

        void unHookGetShInstrumentByCid()
        {
            DBA_PROC_STP procedure = getProcedureShInstrumentByCid();

            if (nullptr != procedure)
            {
                *procedure = m_get_sh_instrument_by_cid;
            }
        }


        /*
         * m_get_sh_portfolio_by_cid
         */
        DBA_PROC_STP getProcedureShPortfolioByCid()
        {
            MemoryPool      mp;
            DBA_DYNFLD_STP  admArg = mp.allocDynst(FILEINFO, Adm_Arg);

            SET_ID(admArg, Adm_Arg_Id, ID_1);

            return DBA_GetStoredProcs(Get, Ptf, UNUSED, Adm_Arg, admArg, S_Ptf);
        }

        void hookGetShPortfolioByCid()
        {
            DBA_PROC_STP procedure = getProcedureShPortfolioByCid();

            if (nullptr != procedure)
            {
                m_get_sh_portfolio_by_cid = *procedure;

                procedure->server   = InternalProc;

                DBA_FCTDEF_ST fctdef;
                SYS_Bzero(&fctdef, sizeof(fctdef));

                fctdef.getFct = DFT_GetPortfolioById;
                procedure->fctDefSt = fctdef;

                // Don't compile on AIX procedure->fctDefSt = GETFCT(DFT_GetInstrumentById);
            }
        }

        void unHookGetShPortfolioByCid()
        {
            DBA_PROC_STP procedure = getProcedureShPortfolioByCid();

            if (nullptr != procedure)
            {
                *procedure = m_get_sh_portfolio_by_cid;
            }
        }


        /*
         * m_get_all_portfolio_by_id
         */
        DBA_PROC_STP getProcedureAllPortfolioById()
        {
            MemoryPool      mp;
            DBA_DYNFLD_STP  sptf = mp.allocDynst(FILEINFO, S_Ptf);

            SET_ID(sptf, S_Ptf_Id, ID_1);

            return DBA_GetStoredProcs(Get, Ptf, UNUSED, S_Ptf, sptf, A_Ptf);
        }

        void hookGetAllPortfolioById()
        {
            DBA_PROC_STP procedure = getProcedureAllPortfolioById();

            if (nullptr != procedure)
            {
                m_get_all_portfolio_by_id = *procedure;

                procedure->server   = InternalProc;

                DBA_FCTDEF_ST fctdef;
                SYS_Bzero(&fctdef, sizeof(fctdef));

                fctdef.getFct = DFT_GetAllPortfolioById;
                procedure->fctDefSt = fctdef;

                // Don't compile on AIX procedure->fctDefSt = GETFCT(DFT_GetInstrumentById);
            }
        }

        void unHookGetAllPortfolioById()
        {
            DBA_PROC_STP procedure = getProcedureAllPortfolioById();

            if (nullptr != procedure)
            {
                *procedure = m_get_all_portfolio_by_id;
            }
        }


        DBA_PROC_ST m_get_sh_instrument_by_cid;
        DBA_PROC_ST m_get_sh_portfolio_by_cid;
        DBA_PROC_ST m_get_all_portfolio_by_id;
};


/************************************************************************
**
**  Function    :   DFT_TestsFusionModeValidation()
**                  - Launch a fusion
**
**  Description :   Main function for testing the fusion
**
**  Argument    :   pszTestFusion           File or directory to test
**
**  Last modif. :   PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**                  PMSTA-22886 - 141217 - PMO : Fusion issue on partial Exchange - Adjustment with adj nature = Exchange
**
*************************************************************************/
bool DFT_TestFusionModeValidation(std::ostringstream & output, std::string & testName, const std::string & directory, const std::string & tags)
{
    if (EV_DictInitFlg == FALSE)
    {
        std::cerr << "Metadictionary not inititialized, can not run fusion tests\n";
        return false;
    }

    DftFusionValidationFile             fusionValidationFile;               /* PMSTA-27843 - 200717 - PMO */
    DftFusionReport                     testFusionReport(output, testName);
    DftFusionHookDatabaseToFusionTrace  dftFusionHookDatabaseToFusionTrace; /* PMSTA-22886 - 141217 - PMO */

    // Mapping of catch arguments with fusion validation expected keywords
    std::string validationKeywords = tags;
    SYS_StringRemoveTags(validationKeywords, "[Fusion]");

    SYS_StringRemoveTags(validationKeywords, "[");
    SYS_StringFindAndReplaceAll(validationKeywords, "]" , " ");

    return true == fusionValidationFile.validate(directory, validationKeywords, testFusionReport) ? testFusionReport.m_testOk : false;
}


/************************************************************************
**
**  Function    :  DFT_GetFieldName
**
**  Description :  Return the fieldname
**
**  Arguments   :  dynFld   Structure
**                 idx      Index field
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustement P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
STATIC std::string DFT_GetFieldName(DBA_DYNFLD_STP dynFld, const FIELD_IDX_T idx)
{
    DBA_DYNST_ENUM      dynStEn  = GET_DYNSTENUM(dynFld);
    FLAG_T              allocFlg = FALSE;
    DBA_CFIELDDEF_STP   fieldStp = DBA_GetCFieldDef(dynStEn, idx, &allocFlg);

    char fieldName[256];
    DBA_GetFieldName(fieldName, fieldStp);

	if (TRUE == allocFlg)
	{
		FREE(fieldStp);
	}

    return fieldName;
}


/************************************************************************
**
**  Function    :  DFT_GetOperationNatureName
**
**  Description :  Return corresponding name of the operation nature
**
**  Arguments   :  operationNature
**
**  Return      :  The corresponding name of the operation nature
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
STATIC std::string DFT_GetOperationNatureName(const OPNAT_ENUM & operationNature)
{
    std::string ret;

    switch (operationNature)
    {
        case OpNat_None:
            ret += "None";
            break;

        case OpNat_Buy:
            ret += "Buy";
            break;

        case OpNat_Sell:
            ret += "Sell";
            break;

        case OpNat_Income:
            ret += "Income";
            break;

        case OpNat_Invest:
            ret += "Invest";
            break;

        case OpNat_Withdr:
            ret += "Withdr";
            break;

        case OpNat_Fee:
            ret += "Fee";
            break;

        case OpNat_Adjust:
            ret += "Adjust";
            break;

        case OpNat_ShareIss:
            ret += "ShareIss";
            break;

        case OpNat_ShareRedm:
            ret += "ShareRedm";
            break;

        case OpNat_Transf:
            ret += "Transf";
            break;

        case OpNat_BpTransf:
            ret += "BpTransf";
            break;

        case OpNat_Locking:
            ret += "Locking";
            break;

        case OpNat_PtfTransf:
            ret += "PtfTransf";
            break;

        case OpNat_BookAdjust:
            ret += "BookAdjust";
            break;

        case OpNat_Init:
            ret += "Init";
            break;

        case OpNat_Combined:
            ret += "Combined";
            break;

        case OpNat_OpNatNbr:
            ret += "OpNatNbr";
            break;

        default:
            ret += "Unknown";
            break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DFT_FusionQuickCheckPtfCriteriaSelection
**
**  Description :  Test if this portfolio must be treated
**
**  Arguments   :  ctx      Fusion context
**                 idx      Index of the array position logical type
**                 ptfID
**
**  Return      :  true     Must be treated
**                 false    Mustn't treated
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DFT_FusionQuickCheckPtfCriteriaSelection(FIN_FUS_CONTEXT_STP ctx, const int idx, const ID_T ptfID)
{
    return !(ReadyForFusionLoop        != ctx->posLogTypesTab[0].portfolioInfo->status
            || (   nullptr            != ctx->posLogTypesTab[0].ptrInstrument
                && ctx->posLogTypesTab[idx].posNb > 0
                && ptfID              != GET_ID(ctx->posLogTypesTab[idx].posTab[0], ExtPos_PtfId)
                )
            ||  0     != DATE_Cmp(ctx->posLogTypesTab[0].portfolioInfo->fusionStartDate.date, DATE_19000101)  // Fusion check only if the fusion started on 01/01/1900
            ||  FALSE == ctx->posLogTypesTab[0].portfolioInfo->all                                            // Fusion check only in fusion ALL mode
            );
}


/************************************************************************
**
**  Function    :  DFT_FusionQuickCheckPositionCriteriaSelection
**
**  Description :  Test if this position must be treated
**
**  Arguments   :  currPos
**
**  Return      :  true     Must be treated
**                 false    Mustn't treated
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DFT_FusionQuickCheckPositionCriteriaSelection(PosLog & pos)
{
    return FusState_Final == pos.getFusState()          &&
           false          == pos.isTechnicalPosition()  &&
           (DbStatus_ToInsert == GET_ENUM(pos.pos(), ExtPos_DbStatus) || DbStatus_ToUpdate == GET_ENUM(pos.pos(), ExtPos_DbStatus));
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckHeaderKeywords::DftFusionQuickCheckHeaderKeywords
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
DftFusionQuickCheckHeaderKeywords::DftFusionQuickCheckHeaderKeywords()  : m_AdjustmentGrossAmt        (false)
                                                                        , m_AdjustmentPL              (false)
                                                                        , m_AdjustmentManualBookAdj   (false)
                                                                        , m_AdjustmentAutomaticBookAdj(false)
                                                                        , m_AdjustmentMarketPrice     (false)
                                                                        , m_AdjustmentAcqCostBookValue(false)
                                                                        , m_AdjustmentBookAdjFunction (false)
                                                                        , m_AdjustmentMarginCall      (false)
                                                                        , m_AdjustmentPtfTransfLocked (false)
                                                                        , m_AdjustmentProportional    (false)
                                                                        , m_AdjustmentExchange        (false)
                                                                        , m_AdjustmentCostPrice       (false)
                                                                        , m_AdjustmentExchangeWithFees(false)
                                                                        , m_AdjustmentPartiallyPaid   (false)
                                                                        , m_OpFuture                  (false)
                                                                        , m_OpForex                   (false)
                                                                        , m_OpForward                 (false)
                                                                        , m_TaxLot                    (false)
{
    for(int idx = 0 ; idx < OpNat_OpNatNbr; idx++)
    {
        m_OpNat[idx] = false;
        m_setKnownKeywords.insert(DFT_GetOperationNatureName(static_cast<OPNAT_ENUM>(idx)));
    }

    m_setKnownKeywords.insert( "AdjustmentGrossAmt"        );
    m_setKnownKeywords.insert( "AdjustmentPL"              );
    m_setKnownKeywords.insert( "AdjustmentManualBookAdj"   );
    m_setKnownKeywords.insert( "AdjustmentAutomaticBookAdj");
    m_setKnownKeywords.insert( "AdjustmentMarketPrice"     );
    m_setKnownKeywords.insert( "AdjustmentAcqCostBookValue");
    m_setKnownKeywords.insert( "AdjustmentBookAdjFunction" );
    m_setKnownKeywords.insert( "AdjustmentMarginCall"      );
    m_setKnownKeywords.insert( "AdjustmentPtfTransfLocked" );
    m_setKnownKeywords.insert( "AdjustmentProportional"    );
    m_setKnownKeywords.insert( "AdjustmentExchange"        );
    m_setKnownKeywords.insert( "AdjustmentCostPrice"       );
    m_setKnownKeywords.insert( "AdjustmentExchangeWithFees");
    m_setKnownKeywords.insert( "AdjustmentPartiallyPaid"   );
    m_setKnownKeywords.insert( "Future"                    );
    m_setKnownKeywords.insert( "Forex"                     );
    m_setKnownKeywords.insert( "Forward"                   );
    m_setKnownKeywords.insert( "TaxLot"                    );
}


/************************************************************************
**
**  Function    :   DftFusionQuickCheckHeaderKeywords::updateKeywords
**
**  Description :   Analyze the position.
**                  For example, if it is an "Margin Call" position,
**                  The flag Adjustment will be defined as well the flag AdjustmentMarginCall
**
**  Arguments   :   pos   Position to analyze
**
**  Return      :  void
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
void DftFusionQuickCheckHeaderKeywords::updateKeywords(const PosLog & pos)
{
    if (true == pos.isPrimary())
    {
        if (true == pos.isAdjustment())
        {
            m_AdjustmentGrossAmt           |= pos.isAdjustmentGrossAmt         ();
            m_AdjustmentPL                 |= pos.isAdjustmentPL               ();
            m_AdjustmentManualBookAdj      |= pos.isAdjustmentManualBookAdj    ();
            m_AdjustmentAutomaticBookAdj   |= pos.isAdjustmentAutomaticBookAdj ();
            m_AdjustmentMarketPrice        |= pos.isAdjustmentMarketPrice      ();
            m_AdjustmentAcqCostBookValue   |= pos.isAdjustmentAcqCostBookValue ();
            m_AdjustmentBookAdjFunction    |= pos.isAdjustmentBookAdjFunction  ();
            m_AdjustmentMarginCall         |= pos.isAdjustmentMarginCall       ();
            m_AdjustmentPtfTransfLocked    |= pos.isAdjustmentPtfTransfLocked  ();
            m_AdjustmentProportional       |= pos.isAdjustmentProportional     ();
            m_AdjustmentExchange           |= pos.isAdjustmentExchange         ();
            m_AdjustmentCostPrice          |= pos.isAdjustmentCostPrice        ();
            m_AdjustmentExchangeWithFees   |= pos.isAdjustmentExchangeWithFees ();
            m_AdjustmentPartiallyPaid      |= pos.isAdjustmentPartiallyPaid    ();
        }

        if (pos.getOpenOpNat() < OpNat_OpNatNbr)
        {
            m_OpNat[pos.getOpenOpNat()] = true;
        }

        if (true == pos.isRefNatFuture())
        {
            m_OpFuture = true;
        }

        if (true == pos.isRefNatForex())
        {
            m_OpForex = true;
        }

        if (true == pos.isRefNatForward())
        {
            m_OpForward = true;
        }

        if (true == pos.hasTaxLot())
        {
            m_TaxLot = true;
        }
    }
}


/************************************************************************
**
**  Function    :   DftFusionQuickCheckHeaderKeywords::checkKeywords
**
**  Description :   Check if all given keyworks are know and, expected keywords if any exists
**
**  Arguments   :   keywords            Keywords to check
**                  expectedKeywords    Example: "Buy AdjustmentExchange" To test only portfolios that have at least a buy and an Adjustment of type Exchange
**
**  Return      :   true  if ok
**                  false if ko
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
bool DftFusionQuickCheckHeaderKeywords::checkKeywords (const std::string & keywords, const std::string & expectedKeywords)
{
    /* Follow the white rabbit

                          (\(\
                          (-.-)
                        o_(")(")
    */
    bool ret = true;

    // Check for know keywords
    std::vector<std::string> tokens;

    SYS_StringTokenize(tokens, keywords, " ");

    for (size_t idx = 0; idx < tokens.size() && true == ret; idx++)
    {
        std::set<std::string>::iterator it = m_setKnownKeywords.find(tokens[idx]);

        ret = it != m_setKnownKeywords.end();
    }


    if (true == ret && false == expectedKeywords.empty())
    { // Check that expected keywords are present
        std::vector<std::string>    expectedKeywordsTokens;
        std::set<std::string>       setKeywords;

        for (size_t idx = 0; idx < tokens.size(); idx++)
        {
            setKeywords.insert(tokens[idx]);
        }

        SYS_StringTokenize(expectedKeywordsTokens, expectedKeywords, " ");

        for (size_t idx = 0; idx < expectedKeywordsTokens.size(); idx++)
        {
            std::set<std::string>::iterator it = setKeywords.find(expectedKeywordsTokens[idx]);

            ret = it != setKeywords.end();

            if (false == ret)
            {
                m_MissingExpectedKeywords = expectedKeywordsTokens[idx];
                break;
            }
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckHeaderKeywords::getKeywordsLine
**
**  Description :  Return a line will all keywords encountered
**
**  Arguments   :  None
**
**  Return      :  A line will all keywords encountered
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
std::string DftFusionQuickCheckHeaderKeywords::getKeywordsLine()
{
    std::string ret;

    for(int idx = 0 ; idx < OpNat_OpNatNbr; idx++)
    {
        if (true == m_OpNat[idx])
        {
            ret += DFT_GetOperationNatureName(static_cast<OPNAT_ENUM>(idx));
            ret += " ";
        }
    }

    // !!! Space at the end of the string is mandatory !!!
    ret += (false == m_AdjustmentGrossAmt)          ? "" : "AdjustmentGrossAmt "        ;
    ret += (false == m_AdjustmentPL)                ? "" : "AdjustmentPL "              ;
    ret += (false == m_AdjustmentManualBookAdj)     ? "" : "AdjustmentManualBookAdj "   ;
    ret += (false == m_AdjustmentAutomaticBookAdj)  ? "" : "AdjustmentAutomaticBookAdj ";
    ret += (false == m_AdjustmentMarketPrice)       ? "" : "AdjustmentMarketPrice "     ;
    ret += (false == m_AdjustmentAcqCostBookValue)  ? "" : "AdjustmentAcqCostBookValue ";
    ret += (false == m_AdjustmentBookAdjFunction)   ? "" : "AdjustmentBookAdjFunction " ;
    ret += (false == m_AdjustmentMarginCall)        ? "" : "AdjustmentMarginCall "      ;
    ret += (false == m_AdjustmentPtfTransfLocked)   ? "" : "AdjustmentPtfTransfLocked " ;
    ret += (false == m_AdjustmentProportional)      ? "" : "AdjustmentProportional "    ;
    ret += (false == m_AdjustmentExchange)          ? "" : "AdjustmentExchange "        ;
    ret += (false == m_AdjustmentCostPrice)         ? "" : "AdjustmentCostPrice "       ;
    ret += (false == m_AdjustmentExchangeWithFees)  ? "" : "AdjustmentExchangeWithFees ";
    ret += (false == m_AdjustmentPartiallyPaid)     ? "" : "AdjustmentPartiallyPaid "   ;
    ret += (false == m_OpFuture)                    ? "" : "Future "                    ;
    ret += (false == m_OpForex)                     ? "" : "Forex "                     ;
    ret += (false == m_OpForward)                   ? "" : "Forward "                   ;
    ret += (false == m_TaxLot)                      ? "" : "TaxLot "                    ;

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckHeaderKeywords::getMissingExpectedKeywords
**
**  Description :  Return the missing keyword encountered
**
**  Arguments   :  None
**
**  Return      :  A line will the first missing keyword encountered
**
**  Last modif. :  PMSTA-27843 - 200717 - PMO : Setup Tax Lot Intial test infrastructure
**
*************************************************************************/
std::string DftFusionQuickCheckHeaderKeywords::getMissingExpectedKeywords()
{
    return m_MissingExpectedKeywords;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkTotalCashAccount
**
**  Description :  Check if the sum of cash position are equal to the final position
**
**  Arguments   :  ptfID        Portfolio id
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22890 - 240316 - PMO : FX Swap - Fusion wrong on cash account 2
**
*************************************************************************/
void DftFusionQuickCheck::checkTotalCashAccount(const ID_T ptfID)
{
    static FIELD_IDX_T fieldsTotal[] = { ExtPos_PosGrossAmt, ExtPos_PosNetAmt, ExtPos_Qty };
    DBA_DYNFLD_STP totalCash = ALLOC_DYNST(ExtPos);

    if (NULL != totalCash)
    {
        for (int i = 0; i < getCtx()->posLogTypesNb; i++)
        {
            if (  ReadyForFusionLoop    != getCtx()->posLogTypesTab[i].portfolioInfo->status
               || 0                     == getCtx()->posLogTypesTab[i].posNb
               || ptfID                 != GET_ID(getCtx()->posLogTypesTab[i].posTab[0], ExtPos_PtfId)
               || (   NULL              != getCtx()->posLogTypesTab[i].ptrInstrument
                  && InstrNat_CashAcct  != GET_INSTRNAT(getCtx()->posLogTypesTab[i].posTab[0], ExtPos_InstrNat)
                  )
               )
            {
                continue;
            }

            ID_T bpID           = ZERO_ID;
            ID_T nextMinBpID    = ZERO_ID;

            do
            {
                bpID = nextMinBpID;

                FUS_ZeroAmounts(totalCash);
                SET_NUMBER(totalCash, ExtPos_Qty, ZERO_NUMBER);

                DBA_DYNFLD_STP  finalPos     = NULL;
                int             nbFinalPos   = 0;
                int             nbPos        = 0;

                for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
                {
                    DBA_DYNFLD_STP  currPos = getCtx()->posLogTypesTab[i].posTab[j];
                    PosLog          pos(currPos, i);
                    const ID_T      posBbID = GET_ID(currPos, ExtPos_BalPosTpId);

                    if ( posBbID > nextMinBpID)
                    {
                        if (nextMinBpID == bpID)
                        { /* Take next bigger BP ID */
                            nextMinBpID = posBbID;
                        }
                        else
                        {
                            if (posBbID < nextMinBpID && posBbID > bpID)
                            { /* Found a smaller BP ID */
                                nextMinBpID = posBbID;
                            }
                        }
                    }

                    if (FusState_Final  == GET_POSFUSSTATE(currPos, ExtPos_FusStateEn)  &&
                        false           == pos.isTechnicalPosition()                    &&
                        true            == pos.isSaveDbStatus()                         &&
                        (  true         == pos.isRefNatNone()
                        || true         == pos.isRefNatForex()
                        || true         == pos.isRefNatForward()
                        || true         == pos.isRefNatFuture()
                        )                                                               &&
                        bpID                == GET_ID(currPos, ExtPos_BalPosTpId)
                       )
                    {
                        if (true == pos.isEndDate9999())
                        {
                            finalPos = currPos;
                            nbFinalPos++;
                        }
                        else
                        {
                            if (true == pos.isPrimary())
                            {
                                nbPos++;

                                for (size_t idx = 0; idx < sizeof(fieldsTotal) / sizeof(fieldsTotal[0]); idx++)
                                {
                                    OPE_ADD_AMOUNT(totalCash, fieldsTotal[idx], GET_AMOUNT(currPos, fieldsTotal[idx]));
                                }
                            }
                        }
                    }
                }

                if (1 == nbFinalPos && nbPos > 0)
                {
                    for (size_t idx = 0; idx < sizeof(fieldsTotal) / sizeof(fieldsTotal[0]); idx++)
                    {
                        if (0 != CMP_DYNFLD(finalPos, totalCash, fieldsTotal[idx], fieldsTotal[idx], GET_FLD_TYPE(ExtPos, fieldsTotal[idx])))
                        {
                            std::string instrName;
                            FUS_GetInstrCode(getCtx(), GET_ID(finalPos, ExtPos_InstrId), instrName);

                            bool        compareOk = true;
                            std::string fielDiffValue1;
                            std::string fielDiffValue2;
                            std::string fielDeltaValue;

                            switch (GET_FLD_TYPE(ExtPos, fieldsTotal[idx]))
                            {
                                case AmountType:
                                    {
                                        char     value[32];
                                        NUMBER_T value1 = GET_AMOUNT(totalCash, fieldsTotal[idx]);
                                        NUMBER_T value2 = GET_AMOUNT(finalPos,  fieldsTotal[idx]);

                                        sprintf(value, "%.2f", value2);
                                        value2 = atof(value);

                                        compareOk = TLS_Cmp(value1, value2, 0.001) == 0;

                                        if (false == compareOk)
                                        {
                                            fielDiffValue2 = value;
                                            sprintf(value, "%.2f", value1);
                                            fielDiffValue1 = value;

                                            sprintf(value, "%.2f", value1 - value2);
                                            fielDeltaValue = value;
                                        }
                                    }
                                    break;

                                case NumberType:
                                    {
                                        char     value[32];
                                        NUMBER_T value1 = GET_NUMBER(totalCash, fieldsTotal[idx]);
                                        NUMBER_T value2 = GET_NUMBER(finalPos,  fieldsTotal[idx]);

                                        sprintf(value, "%f", value2);
                                        value2 = atof(value);

                                        compareOk = TLS_Cmp(value1, value2, 0.000001) == 0;

                                        if (false == compareOk)
                                        {
                                            fielDiffValue2 = value;
                                            sprintf(value, "%f", value1);
                                            fielDiffValue1 = value;

                                            sprintf(value, "%.2f", value1 - value2);
                                            fielDeltaValue = value;
                                        }
                                    }
                                    break;

                                default:
                                    break;
                            }

                            if (false == compareOk)
                            {
                                char szBuf[512];
                                /* I need to put more code. For example the merge of 2 sell rise false message */
                                sprintf(szBuf, "%s: cash account sum: %s: %s %s:%s/%s -> %s", Console::ColorizeInfo("Warning").c_str(), m_ptfName.c_str(), instrName.c_str(), DFT_GetFieldName(finalPos, fieldsTotal[idx]).c_str(), fielDiffValue1.c_str(), fielDiffValue2.c_str(), fielDeltaValue.c_str());

                                std::string message = szBuf;
                                log(message);
                            }
                        }
                    }
                }
            }
            while (bpID != nextMinBpID);
        }

        FUS_DynStFree(totalCash);
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::computeOnly
**
**  Description :  Do only the computation of the given portfolio
**                 Results if any are stored into:
**                 - m_computePositions
**                 - m_computeBalance
**
**  Arguments   :  ptfID        Portfolio id
**
**  Return      :  None
**
**  Last modif. :  PMSTA-25964 - 240117 - PMO : Cost price, position amounts and position currency are wrong as a result of P&L adjustment - change of position currency
**
*************************************************************************/
void DftFusionQuickCheck::computeOnly(const ID_T ptfId)
{
    enableComputeHtmlOutput();

    m_computePtfID = ptfId;
    m_computePositions.erase();
    m_computeTaxLot.erase();
    m_computeTaxLotInitial.erase();
    m_computeBalance.erase();

    quickCheck();
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::getComputedOpenedPositions
**
**  Description :  Return opened positions of the portfolio used for computation
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-25964 - 240117 - PMO : Cost price, position amounts and position currency are wrong as a result of P&L adjustment - change of position currency
**
*************************************************************************/
std::string DftFusionQuickCheck::getComputedOpenedPositions()
{
    return m_computePositions;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::getComputedOpenedTaxLot
**
**  Description :  Return opened TaxLot of the portfolio used for computation
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
std::string DftFusionQuickCheck::getComputedOpenedTaxLot()
{
    return m_computeTaxLot;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::getComputedOpenedTaxLotInitial
**
**  Description :  Return opened TaxLotInitial of the portfolio used for computation
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
std::string DftFusionQuickCheck::getComputedOpenedTaxLotInitial()
{
    return m_computeTaxLotInitial;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::getComputedBalance
**
**  Description :  Return the balance of the opened positions of the portfolio used for computation
**
**  Arguments   :  None
**
**  Return      :  None
**
**  Last modif. :  PMSTA-25964 - 240117 - PMO : Cost price, position amounts and position currency are wrong as a result of P&L adjustment - change of position currency
**
*************************************************************************/
std::string DftFusionQuickCheck::getComputedBalance()
{
    return m_computeBalance;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::quickFusionTestCompareAndLog
**
**  Description :  Compare two numbers and log in case of any difference
**
**  Arguments   :  pMsg         Message to write
**                 currPos      Current position
**                 value1       First value to compare
**                 value2       Second value to compare
**                 nbDigit      How much digits for writting message
**                 precision    Precision for comparison
**
**  Return      :  void
**
**  Last modif. :  PMSTA-23184 - 060516 - PMO : Regression : cost price and position/instrument exchange rate are wrong after a P&L adjustment
**
*************************************************************************/
void DftFusionQuickCheck::quickFusionTestCompareAndLog(const char * pMsg, DBA_DYNFLD_STP currPos, const double value1, const double value2, const int nbDigit, const double precision)
{
    if (0 != TLS_Cmp(value1, value2, precision))
    {
        char value[32];

        sprintf(value, "%.*f", nbDigit, value1);
        std::string fielDiffValue1 = value;

        sprintf(value, "%.*f", nbDigit, value2);
        std::string fielDiffValue2 = value;

        sprintf(value, "%.*f", nbDigit, value1 - value2);
        std::string fielDeltaValue = value;

        char szBuf[512];

        sprintf(szBuf, "%s: %s: %s: %s Operation code:%s, %s/%s -> %s", Console::ColorizeInfo("Warning").c_str(), pMsg, m_ptfName.c_str(), m_instrName.c_str(), GET_CODE(currPos, ExtPos_OpenOpCd), fielDiffValue1.c_str(), fielDiffValue2.c_str(), fielDeltaValue.c_str());

        std::string message = szBuf;

        log(message);
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkCurrenciesAmounts
**
**  Description :  Check if the different amounts and exchange rate are equal in case of it is the same currency
**
**  Arguments   :  ptfID        Portfolio id
**
**  Return      :  void
**
**  Last modif. :  PMSTA-23184 - 060516 - PMO : Regression : cost price and position/instrument exchange rate are wrong after a P&L adjustment
**                 PMSTA-22484 - 060417 - PMO : Adjustement nature "Exchange" - Position with new instrument is not enable in Valuation
**
*************************************************************************/
void DftFusionQuickCheck::checkCurrenciesAmounts(const ID_T ptfID)
{
    for (int i = 0; i < getCtx()->posLogTypesNb; i++)
    {
        if (  ReadyForFusionLoop != getCtx()->posLogTypesTab[i].portfolioInfo->status
           || 0                  == getCtx()->posLogTypesTab[i].posNb
           || ptfID              != GET_ID(getCtx()->posLogTypesTab[i].posTab[0], ExtPos_PtfId)
           )
        {
            continue;
        }

        for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
        {
            DBA_DYNFLD_STP currPos = getCtx()->posLogTypesTab[i].posTab[j];

            if (FusState_Final      == GET_POSFUSSTATE(currPos, ExtPos_FusStateEn)  &&
                FALSE == DBA_IsTechnicalPosition(currPos)                           &&
                (DbStatus_ToInsert  == GET_ENUM(currPos, ExtPos_DbStatus) || DbStatus_ToUpdate == GET_ENUM(currPos, ExtPos_DbStatus)))
            { /* Do a check of this position */

                const ID_T bpID = GET_ID(currPos, ExtPos_BalPosTpId);

                if (0 == CMP_ID(GET_ID(currPos, ExtPos_PosCurrId), GET_ID(currPos, ExtPos_InstrCurrId)))
                { /* Position amounts have the same currency than instrument amounts */
                    quickFusionTestCompareAndLog("same currency but not same Gross amount  for Position & Instrument", currPos, GET_AMOUNT(currPos, ExtPos_PosGrossAmt), GET_AMOUNT(  currPos, ExtPos_InstrGrossAmt), 2, 0.001);
                    quickFusionTestCompareAndLog("same currency but not same Net   amount  for Position & Instrument", currPos, GET_AMOUNT(currPos, ExtPos_PosNetAmt),   GET_AMOUNT(  currPos, ExtPos_InstrNetAmt),   2, 0.001);

                    if (ZERO_ID == bpID)
                    { /* BP don't have the exchange rate */
                        quickFusionTestCompareAndLog("same currency but not same Exchange rate for Position & Instrument", currPos, GET_EXCHANGE(currPos, ExtPos_PosExchRate), GET_EXCHANGE(currPos, ExtPos_InstrExchRate), 9, 0.0000000001);
                    }
                }

                if (0 == CMP_ID(GET_ID(currPos, ExtPos_PosCurrId), GET_ID(currPos, ExtPos_RefCurrId)))
                { /* Position amounts have the same currency than reference amounts */
                    quickFusionTestCompareAndLog("same currency but not same Gross amount for Position & Reference",  currPos, GET_AMOUNT(currPos, ExtPos_PosGrossAmt), GET_AMOUNT(currPos,   ExtPos_RefGrossAmt), 2, 0.001);
                    quickFusionTestCompareAndLog("same currency but not same Net   amount for Position & Reference",  currPos, GET_AMOUNT(currPos, ExtPos_PosNetAmt),   GET_AMOUNT(currPos,   ExtPos_RefNetAmt),   2, 0.001);
                }

                if (0 == CMP_ID(GET_ID(currPos, ExtPos_PosCurrId), getCtx()->currPtfInfo->sysCurrId))
                { /* Position amounts have the same currency than instrument amounts */
                    quickFusionTestCompareAndLog("same currency but not same Gross amount  for Position & System", currPos, GET_AMOUNT(currPos, ExtPos_PosGrossAmt), GET_AMOUNT(  currPos, ExtPos_SysGrossAmt), 2, 0.001);
                    quickFusionTestCompareAndLog("same currency but not same Net   amount  for Position & System", currPos, GET_AMOUNT(currPos, ExtPos_PosNetAmt),   GET_AMOUNT(  currPos, ExtPos_SysNetAmt),   2, 0.001);

                    if (ZERO_ID == bpID)
                    { /* BP don't have the exchange rate */
                        quickFusionTestCompareAndLog("same currency but not same Exchange rate for Position & System", currPos, GET_EXCHANGE(currPos, ExtPos_PosExchRate), GET_EXCHANGE(currPos, ExtPos_SysExchRate), 9, 0.0000000001);
                    }
                }

                /* PMSTA-22484 - 220216 - PMO */
                if (0 == CMP_ID(GET_ID(currPos, ExtPos_RefCurrId), getCtx()->currPtfInfo->sysCurrId))
                { /* Position amounts have the same currency than reference amounts */
                    quickFusionTestCompareAndLog("same currency but not same Gross amount for Reference & System",  currPos, GET_AMOUNT(currPos, ExtPos_RefGrossAmt), GET_AMOUNT(currPos,   ExtPos_SysGrossAmt), 2, 0.001);
                    quickFusionTestCompareAndLog("same currency but not same Net   amount for Reference & System",  currPos, GET_AMOUNT(currPos, ExtPos_RefNetAmt),   GET_AMOUNT(currPos,   ExtPos_SysNetAmt),   2, 0.001);
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkBalanceVsBalance
**
**  Description :  Check if the amounts are the same between the 2 balances
**
**  Arguments   :  description      Error description
**                 fields           Fields to compare
**                 balPos1          Record 1
**                 balPos2          Record 2
**                 bAllFieldsEqual  Flag of fatal error
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheck::checkBalanceVsBalance(const std::string & description,const std::vector<FIELD_IDX_T> & fields, const DBA_DYNFLD_STP balPos1, const DBA_DYNFLD_STP balPos2, bool & bAllFieldsEqual)
{
    for (size_t idx = 0; idx < fields.size(); idx++)
    {
        if (   IS_NULLFLD(balPos1,  fields[idx]) == FALSE
            && IS_NULLFLD(balPos2,  fields[idx]) == FALSE
            && CMP_DYNFLD(balPos1, balPos2, fields[idx], fields[idx], GET_FLD_TYPE(ExtPos, fields[idx])) != 0)
        {
            bAllFieldsEqual = false;

            std::string message = m_ptfName;
            message += ": ";
            message += description;
            message += ": ";
            message += DFT_GetFieldName(balPos1, fields[idx]);
            message += ":";
            message += formatAmount(GET_AMOUNT(balPos1, fields[idx]));
            message += "/";
            message += formatAmount(GET_AMOUNT(balPos2, fields[idx]));

            log(message);
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::getOperationsInvolved
**
**  Description :  Update the string operationsInvolved for easy diagnostic when operations are missing or changed
**
**  Arguments   :  pos                  Current position
**                 operationsInvolved   Operations involved
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22847 - 210316 - PMO : Fusion of swap close and forward close on the same day is not correct
**                 PMSTA-23091 - 210416 - PMO : Fusion request "fusion all" on a portfolio gives different Valorisation results than "fusion new" scope (account 2)
**
*************************************************************************/
void DftFusionQuickCheck::getOperationsInvolved(DBA_DYNFLD_STP pos, std::string & operationsInvolved)
{
    PosLog posLog(pos);

    if (posLog.isMainPos() && posLog.isPrimary())
    {
        operationsInvolved += posLog.getOpCd();
        operationsInvolved += " ";
        operationsInvolved += DFT_GetOperationNatureName(posLog.getOperNat());

        { /* PMSTA-23091 - 210416 - PMO */
            std::string instrBpName;
            getInstrBpName(posLog, instrBpName);

            char number[32];
            snprintf(number, sizeof(number), " %f ", posLog.getQty());
            operationsInvolved += number;
            operationsInvolved += instrBpName;

            snprintf(number, sizeof(number), "@%f", posLog.getPrice());
            operationsInvolved += number;

            /* PMSTA-23184 - 060516 - PMO */
            const AMOUNT_T bpSum = posLog.computeBPSum();

            if (bpSum > .001)
            {
                snprintf(number, sizeof(number), " Fees:%.2f ", bpSum);
                operationsInvolved += number;
            }
        }

        operationsInvolved += "\n";
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::addBalancePosAmount
**
**  Description :  For ExtPos only Update balance amounts for doing comparison
**
**  Arguments   :  fields
**                 fieldsBalance
**                 idx
**                 dynFld
**                 dynMemBalPos
**                 dynMemBalPosWMP
**                 cashAccount          True if it is a cash account
**
**  Return      :  None
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheckBasic::addBalancePosAmount( std::vector<FIELD_IDX_T> &   fields
                                                  , std::vector<FIELD_IDX_T> &   fieldsBalance
                                                  , const size_t                 idx
                                                  , DBA_DYNFLD_STP               dynFld
                                                  , DBA_DYNFLD_STP               dynMemBalPos
                                                  , DBA_DYNFLD_STP               dynMemBalPosWMP
                                                  , const bool &                 bCashAccount
                                                  , const bool &                 bTaxLot
                                                  )

{
    if (ExtPos == GET_DYNSTENUM(dynFld))
    {
        PosLog pos(dynFld);

        if (nullptr != dynMemBalPos && true == pos.orEq(PosDetail_Yes))
        {
            for (size_t idx2 = 0; idx2 < fieldsBalance.size(); idx2++)
            {
                if (fields[idx] == fieldsBalance[idx2])
                {
                    OPE_ADD_AMOUNT(dynMemBalPos, fields[idx], GET_AMOUNT(dynFld, fields[idx]));
                    break;
                }
            }
        }

        if (nullptr != dynMemBalPosWMP && true == pos.orEq(PosDetail_No))
        {
            for (size_t idx2 = 0; idx2 < fieldsBalance.size(); idx2++)
            {
                if (fields[idx] == fieldsBalance[idx2])
                {
                    OPE_ADD_AMOUNT(dynMemBalPosWMP, fields[idx], GET_AMOUNT(dynFld, fields[idx]));
                    if (true == bCashAccount || false == bTaxLot)
                    {
                        OPE_ADD_AMOUNT(dynMemBalPos, fields[idx], GET_AMOUNT(dynFld, fields[idx]));
                    }
                    break;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::addFormatedRecord
**
**  Description :  Format the dynfld into the string line
**
**  Arguments   :  dynStpFileBalPos     For ExtOp to add amounts for balance checking
**                 dynFld               Position or TaxLot or TaxLotInitial
**                 line                 Output line of difference(s)
**                 fieldName            FieldName to fill
**                 field                Index of the current field
**                 bCompute             Flag if only computation
**                 bComputeHtmlOutput   Format has html tag for fusion trace
**                 cashAccount          True if it is a cash account
**
**  Return      :  true     It is a zero position
**                 false    It is not a zero position
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheckBasic::addFormatedExtPosRecord( std::vector<FIELD_IDX_T> &  fields
                                                      , std::vector<FIELD_IDX_T> &  fieldsBalance
                                                      , DBA_DYNFLD_STP              dynMemBalPos
                                                      , DBA_DYNFLD_STP              dynMemBalPosWMP
                                                      , const DBA_DYNFLD_STP        dynFld
                                                      , std::string &               line
                                                      , std::string &               fieldName
                                                      , FIELD_IDX_T                 field
                                                      , const size_t                idx
                                                      , const bool &                cashAccount
                                                      )
{
    if (0 == idx)
    {
        getInstrBpName(dynFld, m_instrName);
    }

    std::string lineHtml;
    _addFormatedRecord(fields, fieldsBalance, dynMemBalPos, dynMemBalPosWMP, dynFld, line, lineHtml, fieldName, field, idx, cashAccount);
}

void DftFusionQuickCheckBasic::addFormatedTaxLotRecord(PosLog & pos, DBA_DYNFLD_STP dynFld, std::string & line, std::string & taxLotData,  std::string & fieldName, FIELD_IDX_T field, const size_t idx)
{
    if (0 == idx)
    {
        getInstrTaxLotName(pos.pos(), m_instrName);
    }

    std::vector<FIELD_IDX_T> fields;
    _addFormatedRecord(fields, fields, nullptr, nullptr, dynFld, line, taxLotData, fieldName, field, 0, false);
}

void DftFusionQuickCheckBasic::addFormatedTaxLotInitialRecord(PosLog & pos, DBA_DYNFLD_STP dynFld, std::string & line, std::string & taxLotInitialData, std::string & fieldName, FIELD_IDX_T field, const size_t idx)
{
    if (0 == idx)
    {
        getInstrTaxLotName(pos.pos(), m_instrName);
    }

    std::vector<FIELD_IDX_T> fields;
    _addFormatedRecord(fields, fields, nullptr, nullptr, dynFld, line, taxLotInitialData, fieldName, field, 0, false);
}


void DftFusionQuickCheckBasic::_addFormatedRecord( std::vector<FIELD_IDX_T> &    fields
                                                 , std::vector<FIELD_IDX_T> &    fieldsBalance
                                                 , DBA_DYNFLD_STP                dynMemBalPos
                                                 , DBA_DYNFLD_STP                dynMemBalPosWMP
                                                 , const DBA_DYNFLD_STP          dynFld
                                                 , std::string &                 line
                                                 , std::string &                 lineHtml
                                                 , std::string &                 fieldName
                                                 , FIELD_IDX_T                   field
                                                 , const size_t                  idx
                                                 , const bool &                  bCashAccount
                                                 )
{
    const DBA_DYNST_ENUM dynstEnum        = GET_DYNSTENUM(dynFld);
    const bool           taxLotHtmlOutput = true == isComputeHtmlOutput() && (A_TaxLot == dynstEnum || A_TaxLotInitial == dynstEnum);

    fieldName = DFT_GetFieldName(dynFld, field);

    switch (GET_FLD_TYPE(dynstEnum, field))
    {
        case IdType:
            if (true == taxLotHtmlOutput)
            {
                addHtmlTagAndValue(lineHtml, "td", m_instrName);
            }

            line += m_instrName;

            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += ":  ";
            }

            break;

        case CodeType:
            if (true == taxLotHtmlOutput)
            {
                addHtmlTagAndValue(lineHtml, "td", GET_CODE(dynFld, field));
            }

            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += fieldName;
                line += ":";
            }

            line += GET_CODE(dynFld, field);

            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += " ";
            }
            break;

        case NumberType:
            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += fieldName;
                line += ":";
            }

            {
                char number[32];
                snprintf(number, sizeof(number), "%f ", GET_NUMBER(dynFld, field));
                line += number;

                if (true == taxLotHtmlOutput)
                {
                    addHtmlTagAndValue(lineHtml, "td", number);
                }
            }
            break;

        case AmountType:
            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += fieldName;
                line += ":";
            }

            {
                const std::string amount = formatAmount(GET_AMOUNT(dynFld, field));

                line += amount;

                if (true == taxLotHtmlOutput)
                {
                    addHtmlTagAndValue(lineHtml, "td", amount);
                }
            }

            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += " ";
            }

            addBalancePosAmount(fields, fieldsBalance, idx, dynFld, dynMemBalPos, dynMemBalPosWMP, bCashAccount, false);
            break;

        default:
            if (false == isCompute() || false == isComputeHtmlOutput())                 /* PMSTA-25964 - 240117 - PMO */
            {
                line += "Untreated type field for ";
                line += fieldName;
                line += " ";
            }
            else
            {
                line += "Untreated type";
            }
            break;
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::parseAndCompare
**
**  Description :  Parse the current file line and compare with memory data
**
**  Arguments   :  ptfName          Portfolio name
**                 line             File line to parse
**                 fields           Fields to compare
**                 fieldsBalance    Fields to compare for the balance
**                 dynFld           Position or TaxLot or TaxLotInitial
**                 dynMemBalPos     For ExtOp to add amounts for balance checking
**                 dynMemBalPosWMP  For TaxLot WMP balance checking
**                 bCashAccount     The instrument is a cash account
**                 bTaxLot          There is TaxLot inside this portfolio
**                 bAllFieldsEqual  Flag if a difference was found
**
**  Return      :  The difference if any
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
std::string DftFusionQuickCheckBasic::parseAndCompare( const std::string &          ptfName
                                                     , const std::string &          line
                                                     , std::vector<FIELD_IDX_T> &   fields
                                                     , std::vector<FIELD_IDX_T> &   fieldsBalance
                                                     , DBA_DYNFLD_STP               dynFld
                                                     , DBA_DYNFLD_STP               dynMemBalPos
                                                     , DBA_DYNFLD_STP               dynMemBalPosWMP
                                                     , const bool &                 bCashAccount
                                                     , const bool &                 bTaxLot
                                                     , bool &                       bAllFieldsEqual)
{
    MemoryPool                  mp;
    const DBA_DYNST_ENUM        dynstEnum     = GET_DYNSTENUM(dynFld);
    DBA_DYNFLD_STP              dynStpFilePos = mp.allocDynst(FILEINFO, dynstEnum);
    size_t                      idxToken      = 0;
    std::vector<std::string>    tokens;
    std::string                 ret;

    if (ExtPos == dynstEnum)
    {
        getInstrBpName(dynFld, m_instrName);
    }
    else
    {
        if (A_TaxLotInitial == dynstEnum)
        {
            FUS_GetInstrCode(getCtx(), GET_ID(dynMemBalPos, A_TaxLotInitial_InstrId), m_instrName);
        }
        else
        {
            if (A_TaxLot == dynstEnum)
            {
                getInstrBpName(dynMemBalPos, m_instrName);
            }
            else
            {
                m_instrName = "Unknown";
            }
        }
    }

    SYS_StringTokenize(tokens, line, ": ");

    for (size_t idx = 0; idx < fields.size() && idxToken < tokens.size(); idx++, idxToken++)
    {
        const DATATYPE_ENUM fieldType = GET_FLD_TYPE(dynstEnum, fields[idx]);
        bool                treated   = false;

        if (IdType == fieldType && 0 == tokens[idxToken].compare(m_instrName))
        {
            if (ExtPos == dynstEnum && ExtPos_InstrId == fields[idx])
            {
                COPY_DYNFLD(dynStpFilePos, dynstEnum, ExtPos_InstrId,    dynFld, dynstEnum, ExtPos_InstrId);
                COPY_DYNFLD(dynStpFilePos, dynstEnum, ExtPos_BalPosTpId, dynFld, dynstEnum, ExtPos_BalPosTpId);
                treated = true;
            }

            if (A_TaxLot == dynstEnum && A_TaxLot_InstrId == fields[idx])
            {
                COPY_DYNFLD(dynStpFilePos, dynstEnum, A_TaxLot_InstrId, dynFld, dynstEnum, A_TaxLot_InstrId);
                treated = true;
            }

            if (A_TaxLotInitial == dynstEnum && A_TaxLotInitial_InstrId == fields[idx])
            {
                COPY_DYNFLD(dynStpFilePos, dynstEnum, A_TaxLotInitial_InstrId, dynFld, dynstEnum, A_TaxLotInitial_InstrId);
                treated = true;
            }
        }

        if (false == treated)
        {
            if (true == std::equal(tokens[idxToken].begin(), tokens[idxToken].end(), DFT_GetFieldName(dynFld, fields[idx]).begin()))
            {
                idxToken++;

                switch (fieldType)
                {
                    case IdType:
                        SET_ID(dynStpFilePos, fields[idx], ATOLL(tokens[idxToken].c_str()));
                        break;

                    case CodeType:
                        SET_CODE(dynStpFilePos, fields[idx], tokens[idxToken].c_str());
                        break;

                    case NumberType:
                        SET_NUMBER(dynStpFilePos, fields[idx], atof(tokens[idxToken].c_str()));
                        break;

                    case AmountType:
                        SET_AMOUNT(dynStpFilePos, fields[idx], atof(tokens[idxToken].c_str()));

                        addBalancePosAmount(fields, fieldsBalance, idx, dynFld, dynMemBalPos, dynMemBalPosWMP, bCashAccount, bTaxLot);
                        break;

                    default:
                        break;
                }
            }
        }
    } // End for

    for (size_t idx = 0; idx < fields.size(); idx++)
    {
        if (IS_NULLFLD(dynStpFilePos, fields[idx]) == TRUE && IS_NULLFLD(dynFld, fields[idx]) == TRUE)
        {
            continue;
        }

        bool        compareOk = true;
        std::string fielDiffValue1;
        std::string fielDiffValue2;

        switch (GET_FLD_TYPE(dynstEnum, fields[idx]))
        {
            case IdType:
                compareOk = CMP_DYNFLD(dynStpFilePos, dynFld, fields[idx], fields[idx], GET_FLD_TYPE(dynstEnum, fields[idx])) == 0;

                if (false == compareOk)
                {
                    char value[32];

                    sprintf(value, "%" szFormatId, GET_ID(dynStpFilePos, fields[idx]));
                    fielDiffValue1 = value;

                    sprintf(value, "%" szFormatId, GET_ID(dynFld, fields[idx]));
                    fielDiffValue2 = value;
                }
                break;

            case CodeType:
                compareOk = CMP_DYNFLD(dynStpFilePos, dynFld, fields[idx], fields[idx], GET_FLD_TYPE(dynstEnum, fields[idx])) == 0;
                if (false == compareOk)
                {
                    const char * code1 = GET_CODE(dynStpFilePos, fields[idx]);
                    const char * code2 = GET_CODE(dynFld,       fields[idx]);

                    code1 = nullptr == code1 ? "" : code1;
                    code2 = nullptr == code2 ? "" : code2;

                    fielDiffValue1 = code1;
                    fielDiffValue2 = code2;
                }
                break;

            case NumberType:
                {
                    char     value[32];
                    NUMBER_T value1 = GET_NUMBER(dynStpFilePos, fields[idx]);
                    NUMBER_T value2 = GET_NUMBER(dynFld,       fields[idx]);

                    sprintf(value, "%f", value2);
                    value2 = atof(value);

                    compareOk = TLS_Cmp(value1, value2, 0.000001) == 0;

                    if (false == compareOk)
                    {
                        fielDiffValue2 = value;
                        sprintf(value, "%f", value1);
                        fielDiffValue1 = value;
                    }
                }
                break;

            case AmountType:
                {
                    char     value[32];
                    NUMBER_T value1 = GET_AMOUNT(dynStpFilePos, fields[idx]);
                    NUMBER_T value2 = GET_AMOUNT(dynFld,       fields[idx]);

                    sprintf(value, "%.2f", value2);
                    value2 = atof(value);

                    compareOk = TLS_Cmp(value1, value2, 0.001) == 0;

                    if (false == compareOk)
                    {
                        fielDiffValue2 = value;
                        sprintf(value, "%.2f", value1);
                        fielDiffValue1 = value;
                    }
                }
                break;

            default:
                compareOk = false;
                break;
        }

        if (false == compareOk)
        { // Build a discrepency message about a field
            ret += ptfName;
            ret += ": ";
            ret += m_instrName;
            ret += " ";

            if (A_TaxLot == dynstEnum)
            {
                ret += "TaxLot ";
            }

            if (A_TaxLotInitial == dynstEnum)
            {
                ret += "TaxLotInitial ";
            }

            ret += DFT_GetFieldName(dynFld, fields[idx]);
            ret += ":";
            ret += fielDiffValue1;
            ret += "/";
            ret += fielDiffValue2;

            bAllFieldsEqual = false;
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::formatAmount
**
**  Description :  Format an amount. Avoid -0.00
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-24997 - 281016 - PMO : The Cost Price and Cost Exchange Rate are wrong after P&L adjustment
**
*************************************************************************/
std::string DftFusionQuickCheckBasic::formatAmount(const AMOUNT_T & mnt)
{
    std::string ret;

#ifdef AIX
    switch (fpclassify(mnt))
#else
    switch (std::fpclassify(mnt))
#endif
    {
        // Bad floating point value
        case FP_INFINITE:
            ret = "NAN";
            break;

        case FP_NAN:
            ret = "NAN";
            break;

        case FP_NORMAL:
            if (0 == CMP_NUMBER(ZERO_AMOUNT, mnt))
            { // Avoid -0.00
                ret = "0.00";
            }
            else
            {
                char number[32];
                snprintf(number, sizeof(number), "%.2f", mnt);
                ret = number;
            }
            break;

        case FP_SUBNORMAL:
            ret = "NAN";
            break;

        case FP_ZERO:
            ret = "0.00";
            break;

        default:
            break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::getCtx
**
**  Description :  Return the fusion context
**
**  Arguments   :  None
**
**  Return      :  ctx          Fusion context
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
FIN_FUS_CONTEXT_STP DftFusionQuickCheckBasic::getCtx()
{
    return m_refCheckCtx.getCtx();
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::getInstrBpName
**
**  Description :  For the given instrument add the BP name if any
**
**  Arguments   :  ctx          Fusion context
**                 currPos      Current Position
**                 instrBpName  Instrument name and BP name if any (EUR/INVEST)
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**                 PMSTA-24997 - 281016 - PMO : The Cost Price and Cost Exchange Rate are wrong after P&L adjustment
**
*************************************************************************/
void DftFusionQuickCheckBasic::getInstrBpName(const PosLog & pos, std::string & instrBpName)
{
    FUS_GetInstrCode(getCtx(), pos.getInstrId(), instrBpName);

    if (IS_NULLFLD(pos.pos(), ExtPos_BalPosTpId) == FALSE)
    {
        const std::string bpName = FUS_GetBpName(GET_ID(pos.pos(), ExtPos_BalPosTpId));   /* PMSTA-24997 - 281016 - PMO */

        if (false == bpName.empty())
        {
            instrBpName += "/";
            instrBpName += bpName;
        }
    }

    if (true == pos.isDetail())
    {
        instrBpName += "/TaxLotWMP";
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::getInstrTaxLotName
**
**  Description :  For the given instrument add the BP name if any
**
**  Arguments   :  ctx          Fusion context
**                 currPos      Current Position
**                 instrBpName  Instrument name and BP name if any (EUR/INVEST)
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**                 PMSTA-24997 - 281016 - PMO : The Cost Price and Cost Exchange Rate are wrong after P&L adjustment
**
*************************************************************************/
void DftFusionQuickCheckBasic::getInstrTaxLotName(const PosLog & pos, std::string & instrBpName)
{
    FUS_GetInstrCode(getCtx(), pos.getInstrId(), instrBpName);

    if (true == pos.isDetail())
    {
        instrBpName += "/TaxLotWMP";
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::getTaxLot
**
**  Description :  Return the TaxLot of the given position
**
**  Arguments   :  pos  Position
**
**  Return      :  The TaxLot of the given position
**                 NULL if not found
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DBA_DYNFLD_STP DftFusionQuickCheckBasic::getTaxLot(const PosLog & pos)
{
    DBA_DYNFLD_STP ret = nullptr;

    if (true == pos.hasTaxLot())
    {
        DBA_DYNFLD_STP * taxLotTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(pos.pos(), ExtPos_TaxLot_Ext);

        if (nullptr != taxLotTab && nullptr != taxLotTab[0])
        { // Return the TaxLot
            ret = taxLotTab[0];
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::getTaxLotInitial
**
**  Description :  Return the TaxLotInitial of the given position
**
**  Arguments   :  pos  Position
**
**  Return      :  The TaxLotInitial of the given position
**                 NULL if not found
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DBA_DYNFLD_STP DftFusionQuickCheckBasic::getTaxLotInitial(const PosLog & pos)
{
    DBA_DYNFLD_STP ret = nullptr;

    if (true == pos.hasTaxLot())
    {
        ret = getTaxLot(pos);

        if (nullptr != ret)
        { // Return the TaxLot
            ret = getCtx()->taxLots.getTaxLotInitial(GET_ID(ret, A_TaxLot_TaxLotInitialId));
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::writeDataLines
**
**  Description :  Write the data line to the given opened file
**
**  Arguments   :  stream
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheckBasic::writeDataLines(std::fstream & stream)
{
    stream << m_dataLines;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::writeHtmlHeaderArray
**
**  Description :  build the html array and his header into lineHtml
**
**  Arguments   :  lineHtml     The html array and his header into lineHtml
**                 fields       Index of fields to use
**                 dynFld       Dynamic structure used for the name of headers fields
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheckBasic::buildHtmlHeaderArray(std::string & lineHtml, const std::vector<FIELD_IDX_T> & fields, const DBA_DYNFLD_STP dynFld)
{
    lineHtml += "<table border=\"1\">";
    DftFusionConditionalTag dftFusionConditionalTag(lineHtml, "tr");

    for (size_t idx = 0; idx < fields.size(); idx++)
    {
        if (true == isCompute())
        {
            addHtmlTagAndValue(lineHtml, "td", DFT_GetFieldName(dynFld, fields[idx]));
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckBasic::addHtmlTagAndValue
**
**  Description :  add to the given string the value between two tags
**                 Example: <td>value</td>
**
**  Arguments   :  lineHtml     The html where to concatenate
**                 tag
**                 value
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheckBasic::addHtmlTagAndValue(std::string & lineHtml, const std::string & tag, const std::string & value)
{
    lineHtml += "<";
    lineHtml += tag;
    lineHtml += ">";
    lineHtml +=  value;
    lineHtml += "</";
    lineHtml += tag;
    lineHtml += ">";
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLot::DftFusionQuickCheckTaxLot
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DftFusionQuickCheckTaxLot::DftFusionQuickCheckTaxLot(DftFusionQuickCheckCtx & checkCtx) : DftFusionQuickCheckBasic(checkCtx)
{
//    fields = {  A_TaxLot_InstrId,          A_TaxLot_Quantity,      A_TaxLot_Price,          A_TaxLot_Quote,
//                A_TaxLot_PosGrossAmount,  A_TaxLot_PosNetAmount, A_TaxLot_PfGrossAmount, A_TaxLot_PfNetAmount
//             };
    // For AIX obsolete compiler
    fields.push_back(A_TaxLot_InstrId);
    fields.push_back(A_TaxLot_Quantity);
    fields.push_back(A_TaxLot_Price);
    fields.push_back(A_TaxLot_Quote);
    fields.push_back(A_TaxLot_PosGrossAmount);
    fields.push_back(A_TaxLot_PosNetAmount);
    fields.push_back(A_TaxLot_OpPosGrossAmount);
    fields.push_back(A_TaxLot_OpPosNetAmount);
    fields.push_back(A_TaxLot_PfGrossAmount);
    fields.push_back(A_TaxLot_PfNetAmount);
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLot::~DftFusionQuickCheckTaxLot
**
**  Description :  Destructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DftFusionQuickCheckTaxLot::~DftFusionQuickCheckTaxLot()
{
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLot::fill
**
**  Description :  Fill the object with the related TaxLot
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheckTaxLot::fill(const ID_T & ptfID, std::string & taxLotData)
{
    bool headerHtml = false;

    for (int i = 0; i < getCtx()->posLogTypesNb; i++)
    {
        if (true == DFT_FusionQuickCheckPtfCriteriaSelection(getCtx(), i, ptfID))
        {
            for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
            {
                PosLog pos(getCtx()->posLogTypesTab[i].posTab[j]);

                if (false == pos.isZeroPosition() && true == DFT_FusionQuickCheckPositionCriteriaSelection(pos) && true == pos.isEndDate9999() && true == pos.isDetail())
                {
                    DBA_DYNFLD_STP taxLot = getTaxLot(pos);

                    if (nullptr != taxLot)
                    { // Save the TaxLot

                        if (true == isCompute() && false == headerHtml)
                        { // The header of the array
                            headerHtml = true;
                            buildHtmlHeaderArray(taxLotData, fields, taxLot);
                        }

                        {
                            DftFusionConditionalTag dftFusionConditionalTag(taxLotData, "tr", isComputeHtmlOutput());

                            for (size_t idx = 0; idx < fields.size(); idx++)
                            {
                                std::string fieldName;

                                addFormatedTaxLotRecord(pos, taxLot, m_dataLines, taxLotData, fieldName, fields[idx], idx);
                            }
                        }

                        m_dataLines += "\n";
                    }
                }
            }
        }
    }

    if (true == headerHtml)
    {
        taxLotData += "</table>";
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLot::compareAll
**
**  Description :  Read a line on the given file (a TaxLot line expected) and compare with data memory
**
**  Arguments   :  stream           Opened file
**                 ptfName          Portfolio name
**                 pos              Position having the TaxLot
**                 bAllFieldsEqual  Resulting flag if all fields are equal
**
**  Return      :  The difference if any
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
std::string DftFusionQuickCheckTaxLot::compareAll(std::fstream & stream, const std::string & ptfName, const PosLog & pos, bool & bAllFieldsEqual)
{
    std::string     ret;
    DBA_DYNFLD_STP  taxLot = getTaxLot(pos);

    if (nullptr != taxLot)
    { // Save the TaxLot
        std::string line;

        std::getline(stream, line);

        ret = parseAndCompare(ptfName, line, fields, fields, taxLot, pos.pos(), nullptr, false, false, bAllFieldsEqual);
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLotInitial::DftFusionQuickCheckTaxLotInitial
**
**  Description :  Constructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DftFusionQuickCheckTaxLotInitial::DftFusionQuickCheckTaxLotInitial(DftFusionQuickCheckCtx & checkCtx) : DftFusionQuickCheckBasic(checkCtx)
{
//    fields = {  A_TaxLotInitial_InstrId,                A_TaxLotInitial_Cd,
//                A_TaxLotInitial_InitialQuantity,        A_TaxLotInitial_InitialPrice,
//                A_TaxLotInitial_InitialQuote,           A_TaxLotInitial_InitialPosGrossAmount,
//                A_TaxLotInitial_InitialPosNetAmount,   A_TaxLotInitial_InitialPfGrossAmount,
//                A_TaxLotInitial_InitialPfNetAmount
//             };

    // For AIX obsolete compiler
    fields.push_back(A_TaxLotInitial_InstrId);
    fields.push_back(A_TaxLotInitial_Cd);
    fields.push_back(A_TaxLotInitial_InitialQuantity);
    fields.push_back(A_TaxLotInitial_InitialPrice);
    fields.push_back(A_TaxLotInitial_InitialQuote);
    fields.push_back(A_TaxLotInitial_InitialPosGrossAmount);
    fields.push_back(A_TaxLotInitial_InitialPosNetAmount);
    fields.push_back(A_TaxLotInitial_InitialPfGrossAmount);
    fields.push_back(A_TaxLotInitial_InitialPfNetAmount);
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLotInitial::~DftFusionQuickCheckTaxLotInitial
**
**  Description :  Destructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
DftFusionQuickCheckTaxLotInitial::~DftFusionQuickCheckTaxLotInitial()
{
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLotInitial::fill
**
**  Description :  Fill the object with the related TaxLot.
**                 m_dataLines will be used for writting TaxLotInitial into the validation file
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheckTaxLotInitial::fill(const ID_T & ptfID, std::string & taxLotInitialData)
{
    bool headerHtml = false;

    for (int i = 0; i < getCtx()->posLogTypesNb; i++)
    {
        if (true == DFT_FusionQuickCheckPtfCriteriaSelection(getCtx(), i, ptfID))
        {
            for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
            {
                PosLog pos(getCtx()->posLogTypesTab[i].posTab[j]);

                if (false == pos.isZeroPosition() && true == pos.hasTaxLot() && true == pos.isPrimary() && true == DFT_FusionQuickCheckPositionCriteriaSelection(pos))
                {
                    DBA_DYNFLD_STP * taxLotTab = (DBA_DYNFLD_STP *) GET_EXTENSION_PTR(pos.pos(), ExtPos_TaxLot_Ext);

                    if (nullptr != taxLotTab && nullptr != taxLotTab[0])
                    { // Search the TaxLotInitial
                        DBA_DYNFLD_STP taxLotInitial = getCtx()->taxLots.getTaxLotInitial(GET_ID(taxLotTab[0], A_TaxLot_OpenOperId));

                        if (nullptr != taxLotInitial)
                        { // Save the TaxLotInitial

                            if (true == isCompute() && false == headerHtml)
                            { // The header of the array
                                headerHtml = true;
                                buildHtmlHeaderArray(taxLotInitialData, fields, taxLotInitial);
                            }

                            {
                                DftFusionConditionalTag dftFusionConditionalTag(taxLotInitialData, "tr", isComputeHtmlOutput());

                                for (size_t idx = 0; idx < fields.size(); idx++)
                                {
                                    std::string fieldName;

                                    addFormatedTaxLotInitialRecord(pos, taxLotInitial, m_dataLines, taxLotInitialData, fieldName, fields[idx], idx);
                                }

                                m_dataLines += "\n";
                            }
                        }
                    }
                }
            }
        }
    }

    if (true == headerHtml)
    {
        taxLotInitialData += "</table>";
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheckTaxLotInitial::compareAll
**
**  Description :  Read a line on the given file (a TaxLotInitial line is expected) and compare with data memory
**
**  Arguments   :  stream           Opened file
**                 ptfName          Portfolio name
**                 pos              Position having the TaxLot
**                 bAllFieldsEqual  Resulting flag if all fields are equal
**
**  Return      :  The difference if any
**
**  Last modif. :  PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
std::string DftFusionQuickCheckTaxLotInitial::compareAll(std::fstream & stream, const std::string & ptfName, const PosLog & pos, bool & bAllFieldsEqual)
{
    std::string     ret;
    DBA_DYNFLD_STP  taxLotInitial = getTaxLotInitial(pos);

    if (nullptr != taxLotInitial)
    { // Save the TaxLot
        std::string line;

        std::getline(stream, line);

        ret = parseAndCompare(ptfName, line, fields, fields, taxLotInitial, pos.pos(), nullptr, false, false, bAllFieldsEqual);
    }

    return ret;
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::saveSystemParameters
**
**  Description :  Write all system parameters
**
**  Arguments   :  hFile    Where to write all system parameters
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**
*************************************************************************/
void DftFusionQuickCheck::saveSystemParameters()
{
    INT64_T value;

    for(size_t idx = 0; idx < sizeof(SV_tabSysParameters) / sizeof(SV_tabSysParameters[0]); idx++)
    {
        if (TRUE == GEN_GetApplInfo(SV_tabSysParameters[idx].applParameter, &value))
        {
            /* PMSTA-24997 - 281016 - PMO */
            if (  nullptr != strstr(SV_tabSysParameters[idx].pszName, "BpTypeId")
               || nullptr != strstr(SV_tabSysParameters[idx].pszName, "BpTpId")
               )
            { // Save the label in place of ID since ID might change
                m_streamFile << SV_tabSysParameters[idx].pszName << ":" << FUS_GetBpName(value) << std::endl;
            }
            else
            { // Save the value
                m_streamFile << SV_tabSysParameters[idx].pszName << ":" << SYS_ToString(value) << std::endl;
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::DftFusionQuickCheck
**
**  Description :  Constructor
**
**  Arguments   :  ctx          Fusion context
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**
*************************************************************************/
DftFusionQuickCheck::DftFusionQuickCheck(FIN_FUS_CONTEXT_STP ctx) : DftFusionQuickCheckBasic(m_checkCtx)
                                                                  , m_computePtfID(ZERO_ID)
                                                                  , m_checkCtx(ctx)
                                                                  , m_taxLot(m_checkCtx)
                                                                  , m_taxLotInitial(m_checkCtx)

{
    if (getCtx()->pTestFusionReport != nullptr){
        m_logConsole = false;
        m_streamLog = &getCtx()->pTestFusionReport->m_output;
    } else {
        m_logConsole = true;
        m_streamLog = nullptr;
    }

}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::~DftFusionQuickCheck
**
**  Description :  Destructor
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**
*************************************************************************/
DftFusionQuickCheck::~DftFusionQuickCheck()
{
    if (true == m_streamLogFile.is_open())
    {
        m_streamLogFile.close();
    }

    if (true == m_streamFile.is_open())
    {
        m_streamFile.close();
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::taxLotProcessing
**
**  Description :  Processing of TaxLot & TaxLotInitial
**
**  Arguments   :  ptfID
**                 readOnly
**                 compute
**                 bAllFieldsEqual
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheck::taxLotProcessing(const ID_T ptfID, const bool readOnly, bool & bAllFieldsEqual, std::string & taxLotInitial, std::string & taxLot)
{
    m_taxLot.fill       (ptfID, taxLot);
    m_taxLotInitial.fill(ptfID, taxLotInitial);

    if (true == readOnly)
    {
        _taxLotProcessing(ptfID, false, bAllFieldsEqual);
        _taxLotProcessing(ptfID, true,  bAllFieldsEqual);
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::_taxLotProcessing
**
**  Description :  Sub function for checking of TaxLot & TaxLotInitial
**
**  Arguments   :  ptfID
**                 taxLotProcessing     true=TaxLot  false=TaxLotInitial
**                 bAllFieldsEqual
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheck::_taxLotProcessing(const ID_T ptfID, const bool taxLotProcessing, bool & bAllFieldsEqual)
{
    { // Skip the line separator
        std::string line;
        std::getline(m_streamFile, line);
    }

    for (int i = 0; i < getCtx()->posLogTypesNb; i++)
    {
        if (true == DFT_FusionQuickCheckPtfCriteriaSelection(getCtx(), i, ptfID))
        {
            for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
            {
                PosLog currPos(getCtx()->posLogTypesTab[i].posTab[j]);

                if (  false == currPos.isZeroPosition()
                   && true  == currPos.hasTaxLot()
                   && false == currPos.isPrimary()
                   && true  == currPos.isEndDate9999()
                   && true  == DFT_FusionQuickCheckPositionCriteriaSelection(currPos)
                   )
                {
                    std::string message;

                    if (true == taxLotProcessing)
                    { // TaxLot
                        message = m_taxLot.compareAll(m_streamFile, m_ptfName, currPos, bAllFieldsEqual);
                    }
                    else
                    { // TaxLotInitial
                        message = m_taxLotInitial.compareAll(m_streamFile, m_ptfName, currPos, bAllFieldsEqual);
                    }

                    if (false == message.empty())
                    {
                        log(message);
                    }
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::writeBalance
**
**  Description :  Write the balance into the validation file
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA-28355 - 291017 - PMO : 10 - WMP operation updating
**
*************************************************************************/
void DftFusionQuickCheck::writeBalance(const std::vector<FIELD_IDX_T> & fieldsBalance, const DBA_DYNFLD_STP dynBalPos, const bool wmp)
{
    if (false == isCompute())
    {
        if (true == wmp)
        {
            m_streamFile <<std::endl << "BalanceWMP: ";
        }
        else
        {
            m_streamFile << "Balance: ";
        }
    }

    DftFusionConditionalTag dftFusionConditionalTag(m_computeBalance, "tr", isComputeHtmlOutput());

    for (size_t idx = 0; idx < fieldsBalance.size(); idx++)
    {
        if (GET_FLD_TYPE(ExtPos, fieldsBalance[idx]) == AmountType)
        {
            const std::string fieldName = DFT_GetFieldName(dynBalPos, fieldsBalance[idx]);
            const std::string value     = formatAmount(GET_AMOUNT(dynBalPos, fieldsBalance[idx]));

            if (false == isCompute())
            {
                m_streamFile << fieldName << ":" << value << " ";
            }
            else
            {
                if (true == isComputeHtmlOutput())
                {
                    addHtmlTagAndValue(m_computeBalance, "td", value);
                }
                else
                {
                    m_computeBalance += fieldName;
                    m_computeBalance += ":";
                    m_computeBalance += value;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::DftFusionQuickCheck
**
**  Description :  Creates a file for each Portfolio of the system if the file doesn't exist in the folder(If we select FusionAll in GUI).
**                 Compares the file contents(positions) with the current memory contents(positions) if file exist in the folder (If we select FusionAll in GUI).
**                 Environment variable "AAADFTFUSIONQUICKVALIDATION" gives path for the folder.
**                 Fusion check only if the fusion started on 01/01/1900 and in fusion ALL mode
**
**  Arguments   :  None
**
**  Return      :  void
**
**  Last modif. :  PMSTA - 21806 - 020916 - SRIDHARA - Quick basic validation of the fusion
**                 PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**                 PMSTA-22890 - 240316 - PMO : FX Swap - Fusion wrong on cash account 2
**                 PMSTA-22177 - 220216 - PMO : Treatment of position exchange rate in case of Gross Amount adjustments
**                 PMSTA-25964 - 240117 - PMO : Cost price, position amounts and position currency are wrong as a result of P&L adjustment - change of position currency
**                 PMSTA-28340 - 270917 - PMO : 8.2 - Fusion Process - Fusion Process (120 total)
**
*************************************************************************/
void DftFusionQuickCheck::quickCheck()
{
    //First elements of the array must be InstrumentId
//    std::vector<FIELD_IDX_T> fields         = {  ExtPos_InstrId,     ExtPos_OpenOpCd,      ExtPos_Qty,           ExtPos_Price,       ExtPos_Quote,      ExtPos_PosGrossAmt,
//                                                 ExtPos_PosNetAmt,   ExtPos_InstrGrossAmt, ExtPos_InstrNetAmt,   ExtPos_RefGrossAmt,
//                                                 ExtPos_RefNetAmt,   ExtPos_SysGrossAmt,   ExtPos_SysNetAmt,     ExtPos_Bp1PosAmt,
//                                                 ExtPos_Bp2PosAmt,   ExtPos_Bp3PosAmt,     ExtPos_Bp4PosAmt,     ExtPos_Bp5PosAmt,
//                                                 ExtPos_Bp6PosAmt,   ExtPos_Bp7PosAmt,     ExtPos_Bp8PosAmt,     ExtPos_Bp9PosAmt,   ExtPos_Bp10PosAmt, ExtPos_AccrAmt};
//    std::vector<FIELD_IDX_T> fieldsBalance  = {  ExtPos_PosGrossAmt, ExtPos_PosNetAmt,     ExtPos_InstrGrossAmt, ExtPos_InstrNetAmt,
//                                                 ExtPos_RefGrossAmt, ExtPos_RefNetAmt,     ExtPos_SysGrossAmt,   ExtPos_SysNetAmt};
    // For AIX obsolete compiler
    std::vector<FIELD_IDX_T> fields;
    std::vector<FIELD_IDX_T> fieldsBalance;

    fields.push_back(ExtPos_InstrId);
    fields.push_back(ExtPos_OpenOpCd);
    fields.push_back(ExtPos_Qty);
    fields.push_back(ExtPos_Price);
    fields.push_back(ExtPos_Quote);
    fields.push_back(ExtPos_PosGrossAmt);
    fields.push_back(ExtPos_PosNetAmt);
    fields.push_back(ExtPos_InstrGrossAmt);
    fields.push_back(ExtPos_InstrNetAmt);
    fields.push_back(ExtPos_RefGrossAmt);
    fields.push_back(ExtPos_RefNetAmt);
    fields.push_back(ExtPos_SysGrossAmt);
    fields.push_back(ExtPos_SysNetAmt);
    fields.push_back(ExtPos_Bp1PosAmt);
    fields.push_back(ExtPos_Bp2PosAmt);
    fields.push_back(ExtPos_Bp3PosAmt);
    fields.push_back(ExtPos_Bp4PosAmt);
    fields.push_back(ExtPos_Bp5PosAmt);
    fields.push_back(ExtPos_Bp6PosAmt);
    fields.push_back(ExtPos_Bp7PosAmt);
    fields.push_back(ExtPos_Bp8PosAmt);
    fields.push_back(ExtPos_Bp9PosAmt);
    fields.push_back(ExtPos_Bp10PosAmt);
    fields.push_back(ExtPos_AccrAmt);

    fieldsBalance.push_back(ExtPos_PosGrossAmt);
    fieldsBalance.push_back(ExtPos_PosNetAmt);
    fieldsBalance.push_back(ExtPos_InstrGrossAmt);
    fieldsBalance.push_back(ExtPos_InstrNetAmt);
    fieldsBalance.push_back(ExtPos_RefGrossAmt);
    fieldsBalance.push_back(ExtPos_RefNetAmt);
    fieldsBalance.push_back(ExtPos_SysGrossAmt);
    fieldsBalance.push_back(ExtPos_SysNetAmt);

    std::string         fieldName;
    std::string         line;
    std::string         ptfsPath;

    {
        CurrentTime currentTime(CurrentTime::Kind::Current);
        m_dateTime = currentTime.formatYYYYMMDDHMS();
    }

    if (false == isCompute())
    {
        ptfsPath = SYS_GetEnv("AAADFTFUSIONQUICKVALIDATION");
        ptfsPath += "/";

        if (m_streamLog == nullptr){
            std::string logPath = SYS_GetEnv("AAAMSG");
            logPath += "/fusion_quick_validation.txt";
            m_streamLogFile.open(logPath.c_str(), std::fstream::app);   // c_str() for AIX obsolete compiler
        }
    }

    for (int k = 0; k < getCtx()->nbPtf; k++)
    {
        getCtx()->currPtfInfo  = &getCtx()->ptfTab[k];
        const ID_T ptfID = getCtx()->currPtfInfo->portfolioId;

        if (true == isCompute() && ptfID != m_computePtfID)
        { /* Only the expected portfolio will be treated */
            continue;
        }

        m_ptfName = getCtx()->currPtfInfo->portfolioCd;

        bool                                readOnly         = false;
        int                                 count            = 0;
        bool                                bAllFieldsEqual  = true;
        std::string                         positions;
        std::string                         operationsInvolved;        // Small "list" of operations involved
        std::string                         taxLot;
        std::string                         taxLotInitial;
        DftFusionQuickCheckHeaderKeywords   headerKeywords;

        {
            MemoryPool      mp;
            DBA_DYNFLD_STP  dynFileBalPos    = mp.allocDynst(FILEINFO, ExtPos);     // Balance decomposed from the validation file
            DBA_DYNFLD_STP  dynFileBalPosWMP = mp.allocDynst(FILEINFO, ExtPos);     // TaxLot balance     from the validation file
            DBA_DYNFLD_STP  dynMemBalPos     = mp.allocDynst(FILEINFO, ExtPos);     // The balance of positions in memory
            DBA_DYNFLD_STP  dynMemBalPosWMP  = mp.allocDynst(FILEINFO, ExtPos);     // The balance of the WMP positions in memory

            for (int i = 0; i < getCtx()->posLogTypesNb; i++)
            {
                /* PMSTA-22890 - 240316 - PMO */
                if (false == DFT_FusionQuickCheckPtfCriteriaSelection(getCtx(), i, ptfID))
                {
                    continue;
                }

                const bool cashAccount = InstrNat_CashAcct == GET_INSTRNAT(getCtx()->posLogTypesTab[i].ptrInstrument, A_Instr_NatEn);

                for (int j = 0; j < getCtx()->posLogTypesTab[i].posNb; j++)
                {
                    DBA_DYNFLD_STP  currPos = getCtx()->posLogTypesTab[i].posTab[j];
                    PosLog          currPosLog(currPos);

                    if (true == currPosLog.isZeroPosition())                                                            /* PMSTA-25964 - 240117 - PMO */
                    { /* Dont compare zero position since they can be closed by the fusion engine */
                        continue;
                    }

                    getOperationsInvolved(currPos, operationsInvolved);

                    headerKeywords.updateKeywords(currPosLog);

                    /* PMSTA-22890 - 240316 - PMO */
                    if (true == DFT_FusionQuickCheckPositionCriteriaSelection(currPosLog))
                    {
                        if (true == currPosLog.isEndDate9999())
                        {
                            if (false == m_streamFile.is_open() && false == isCompute())                                /* PMSTA-25964 - 240117 - PMO */
                            {
                                std::string sha256   = FUS_ComputeSHA256SystemParameters(QUICKCHECKFILEVERSION);
                                std::string fileName = ptfsPath + m_ptfName + "_" + sha256 + ".txt";

                                m_streamFile.open(fileName.c_str(), std::fstream::in);                                  // c_str() for AIX obsolete compiler

                                if (false == m_streamFile.is_open())
                                {
                                    m_streamFile.open(fileName.c_str(), std::fstream::out);                             // c_str() for AIX obsolete compiler

                                    if (true == m_streamFile.is_open())
                                    {
                                        /* CMT-12245-FME-190430 Git Version Management*/
                                        m_streamFile << "Version: " << AAAVersion::getVersion().getVersionAndFix() << std::endl;
                                        m_streamFile << "DataBase: " << SYS_GetEnv("DSQUERY") << std::endl;
                                        m_streamFile << "QuickCheckFileVersion: " << QUICKCHECKFILEVERSION << std::endl;
                                        m_streamFile << "SHA256: "   << sha256    << std::endl;
                                        m_streamFile << "Ptf: "      << m_ptfName << std::endl;
                                    }
                                }
                                else
                                {
                                    readOnly = true;
                                }
                            }

                            if ((true == m_streamFile.is_open() && readOnly == false) || true == isCompute())           /* PMSTA-25964 - 240117 - PMO */
                            {
                                if (true == isCompute() && true == isComputeHtmlOutput() && true == positions.empty())  /* PMSTA-25964 - 240117 - PMO */
                                {
                                    positions += "<table border=\"1\"><tr>";

                                    for (size_t idx = 0; idx < fields.size(); idx++)
                                    {
                                        addHtmlTagAndValue(positions, "td", DFT_GetFieldName(currPos, fields[idx]));
                                    }

                                    positions += "</tr>";
                                }

                                for (size_t idx = 0; idx < fields.size(); idx++)
                                {
                                    if (true == isCompute() && true == isComputeHtmlOutput())                       /* PMSTA-25964 - 240117 - PMO */
                                    {
                                        if (0 == idx)
                                        {
                                            positions += "<tr>";
                                        }

                                        positions += "<td>";
                                    }

                                    addFormatedExtPosRecord(fields, fieldsBalance, dynMemBalPos, dynMemBalPosWMP, currPos, positions, fieldName, fields[idx], idx, cashAccount);

                                    if (true == isCompute() && true == isComputeHtmlOutput())                       /* PMSTA-25964 - 240117 - PMO */
                                    {
                                        positions += "</td>";
                                    }
                                }

                                if (true == isCompute() && true == isComputeHtmlOutput())                           /* PMSTA-25964 - 240117 - PMO */
                                {
                                    positions += "</tr>";
                                }

                                positions += "\n";
                            }
                            else
                            {
                                /* Read the header of the file. See below:
                                        Creation: 2017/04/04
                                        Version: R21.0.09
                                        DataBase: D_ORA_PMORF
                                        QuickCheckFileVersion: 7015
                                        SHA256: d29174b71ead184d0b694cc049e88a197c8a51cd8f80673121a55b7167b3788a
                                        Ptf: FDV_01ADJ_CHF
                                        Balance: pos_gross_amount_m:-40.00 pos_net_amount_m:0.00 fi_gross_amount_m:-40.00 fi_net_amount_m:0.00 ref_gross_amount_m:-40.00 ref_net_amount_m:0.00 sys_gross_amount_m:-27.25 sys_net_amount_m:0.00
                                 Maybe: BalanceWMP: pos_gross_amount_m:-40.00 pos_net_amount_m:0.00 fi_gross_amount_m:-40.00 fi_net_amount_m:0.00 ref_gross_amount_m:-40.00 ref_net_amount_m:0.00 sys_gross_amount_m:-27.25 sys_net_amount_m:0.00
                                        ------------------------------------------------------
                                 */
                                while (count < 2)
                                {
                                    /* PMSTA-26884 - 030417 - PMO
                                     * Processing using C++ layer and avoiding strtok
                                     */
                                    if (std::getline(m_streamFile, line))
                                    {
                                        std::string prefix("Balance");

                                        if (true == std::equal(prefix.begin(), prefix.end(), line.begin()))
                                        {
                                            std::string                 prefixWMP("BalanceWMP");
                                            std::vector<std::string>    tokens;
                                            size_t                      idxToken = 1;

                                            SYS_StringTokenize(tokens, line, ": ");

                                            DBA_DYNFLD_STP dyn = std::equal(prefixWMP.begin(), prefixWMP.end(), line.begin()) ? dynFileBalPosWMP : dynFileBalPos;

                                            for (size_t idx = 0; idx < fieldsBalance.size() && idxToken < tokens.size(); idx++, idxToken += 2)
                                            {
                                                if (0 == tokens[idxToken].compare(DFT_GetFieldName(currPos, fieldsBalance[idx])))
                                                {
                                                    SET_AMOUNT(dyn, fieldsBalance[idx], atof(tokens[idxToken + 1].c_str()));
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (true == std::equal(line.begin(), line.end(), separatorLine))
                                            {
                                                count++;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }

                                std::getline(m_streamFile, line);

                                {
                                    std::string message = parseAndCompare( m_ptfName
                                                                         , line
                                                                         , fields
                                                                         , fieldsBalance
                                                                         , currPos
                                                                         , dynMemBalPos
                                                                         , dynMemBalPosWMP
                                                                         , cashAccount
                                                                         , headerKeywords.hasTaxLot()
                                                                         , bAllFieldsEqual);

                                    if (false == message.empty())
                                    {
                                        log(message);
                                    }
                                }

                                checkFeesPosNetGross        (currPos, bAllFieldsEqual);
                                checkNegativeExchangeRate   (currPos, bAllFieldsEqual);     /* PMSTA-23318 - 120516 - PMO */
                                checkCloseFutureFeesAccount3(currPos);                      /* PMSTA-23318 - 120516 - PMO */
                            }
                        }
                        else
                        {
                            if (false == isCompute())                                       /* PMSTA-25964 - 240117 - PMO */
                            {
                                checkNegativeExchangeRate   (currPos, bAllFieldsEqual);     /* PMSTA-23318 - 120516 - PMO */
                                checkCloseFutureFeesAccount3(currPos);                      /* PMSTA-23318 - 120516 - PMO */
                            }
                        }
                    }
                }
            }

            /* PMSTA-28340 - 270917 - PMO
             * TaxLot & TaxLot comparison
             */
            if (true == headerKeywords.hasTaxLot())
            {
                taxLotProcessing(ptfID, readOnly, bAllFieldsEqual, taxLotInitial, taxLot);
            }

            if (true == isCompute() && true == isComputeHtmlOutput() && false == positions.empty())                     /* PMSTA-25964 - 240117 - PMO */
            {
                positions += "</table>";
            }

            if (true == m_streamFile.is_open() || true == isCompute())                                                  /* PMSTA-25964 - 240117 - PMO */
            {
                if (readOnly == false)
                {
                    bool htmlHeader = false;
                    if (false == isCompute())                                                                           /* PMSTA-25964 - 240117 - PMO */
                    {
                        m_streamFile << "Keywords: " << headerKeywords.getKeywordsLine() << std::endl;
                    }
                    else
                    {
                        if (true == isComputeHtmlOutput())                                                              /* PMSTA-25964 - 240117 - PMO */
                        {
                            buildHtmlHeaderArray(m_computeBalance, fieldsBalance, dynFileBalPos);
                            htmlHeader = true;
                        }
                    }


                    /*
                     * Write the balance into the validation file
                     */
                    writeBalance(fieldsBalance, dynMemBalPos);

                    if (true == headerKeywords.hasTaxLot())
                    {
                        writeBalance(fieldsBalance, dynFileBalPosWMP, true);
                    }


                    if (false == isCompute())                                                                           /* PMSTA-25964 - 240117 - PMO */
                    {
                        m_streamFile << std::endl << separatorLine << positions << separatorLine;

                        if (true == headerKeywords.hasTaxLot())                                                         /* PMSTA-28340 - 270917 - PMO */
                        {
                            m_taxLotInitial.writeDataLines(m_streamFile);
                            m_streamFile << separatorLine;

                            m_taxLot.writeDataLines(m_streamFile);
                            m_streamFile << separatorLine;
                        }

                        saveSystemParameters();

                        m_streamFile << separatorLine << operationsInvolved;
                    }
                    else
                    {
                        if (true == htmlHeader)                                                                         /* PMSTA-25964 - 240117 - PMO */
                        {
                            m_computeBalance += "</table>";
                        }
                    }
                }

                if (readOnly == true && false == isCompute())                                                           /* PMSTA-25964 - 240117 - PMO */
                {
                    checkBalanceVsBalance("Balance", fieldsBalance, dynFileBalPos, dynMemBalPos, bAllFieldsEqual);      /* PMSTA-28355 - 291017 - PMO */

                    if (true == headerKeywords.hasTaxLot())                                                             /* PMSTA-28355 - 291017 - PMO */
                    {
                        checkBalanceVsBalance("Balance vs BalanceWMP", fieldsBalance, dynFileBalPos, dynFileBalPosWMP, bAllFieldsEqual);
                    }
                }
            }

            if (false == isCompute())                   /* PMSTA-25964 - 240117 - PMO */
            {
                checkTotalCashAccount (ptfID);          /* PMSTA-22890 - 240316 - PMO */
                checkCurrenciesAmounts(ptfID);          /* PMSTA-23184 - 060516 - PMO */

                /* PMSTA-22890 - 240316 - PMO */
                if (true == m_streamFile.is_open())
                {
                    char            szBuf[512];

                    std::string status = false == readOnly ? "saved" : true == bAllFieldsEqual ? "ok" : "failed";
                    sprintf(szBuf, "%s: %s", m_ptfName.c_str(), status.c_str());
                    std::string message = szBuf;

                    logFile(message);

                    status = false == readOnly ? Console::ColorizeInfo("saved") : true == bAllFieldsEqual ? Console::ColorizeOk("ok") : Console::ColorizeError("failed");
                    sprintf(szBuf, "%s: %s", m_ptfName.c_str(), status.c_str());
                    message = szBuf;

                    logConsole(message);

                    m_streamFile.close();

                    if (getCtx()->pTestFusionReport != nullptr){
                        getCtx()->pTestFusionReport->m_testOk = bAllFieldsEqual;
                    }
                }
            }
            else
            {
                /* Keep data */
                m_computePositions     = positions;
                m_computeTaxLot        = taxLot;
                m_computeTaxLotInitial = taxLotInitial;
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkFeesNetVsGross
**
**  Description :  When we have no BP Net and Gross amounts are equal
**
**  Arguments   :  currPos          Position to test
**                 bAllFieldsEqual  Comparison status set to false on difference
**                 grossIdx         Index of the gross amounts
**                 netIdx           Index of the net amounts
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustment P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
void DftFusionQuickCheck::checkFeesNetVsGross(const DBA_DYNFLD_STP currPos, bool & bAllFieldsEqual, const char * fieldName, const FIELD_IDX_T grossIdx, const FIELD_IDX_T netIdx)
{
    if (0 != TLS_Cmp(GET_AMOUNT(currPos, grossIdx), GET_AMOUNT(currPos, netIdx), 0.001))
    {
        char szBuf[512];
        sprintf(szBuf, "%s: %s Same amounts expected for %s amounts Net:%.2f != Gross:%.2f ", m_ptfName.c_str(), m_instrName.c_str(), fieldName,  GET_AMOUNT(currPos, netIdx), GET_AMOUNT(currPos, grossIdx));

        std::string message = szBuf;
        log(message);

        bAllFieldsEqual = false;
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkFeesPosNetGross
**
**  Description :  Check if the sum of BP is equal to the difference between the position amounts net and gross
**
**  Arguments   :  currPos          Position to test
**                 bAllFieldsEqual  Comparison status set to false on difference
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustment P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
void DftFusionQuickCheck::checkFeesPosNetGross(const DBA_DYNFLD_STP currPos, bool & bAllFieldsEqual)
{
    const AMOUNT_T totalFees = FUS_ComputeBPSumPos(currPos);
    const AMOUNT_T delatPos  = GET_AMOUNT(currPos, ExtPos_PosNetAmt)
                             - GET_AMOUNT(currPos, ExtPos_PosGrossAmt);

    if (0 != TLS_Cmp(totalFees, delatPos, 0.001))
    {
        char szBuf[512];
        sprintf(szBuf, "%s: %s Delta Net:%.2f - Gross:%.2f != fees:%.2f", m_ptfName.c_str(), m_instrName.c_str(), GET_AMOUNT(currPos, ExtPos_PosNetAmt), GET_AMOUNT(currPos, ExtPos_PosGrossAmt), totalFees);

        std::string message = szBuf;
        log(message);

        bAllFieldsEqual = false;
    }
    else
    {
        /* No test for now when we have accured interest */
        if (0 == TLS_Cmp(totalFees, ZERO_AMOUNT, 0.001) && 0 == TLS_Cmp(GET_AMOUNT(currPos, ExtPos_AccrAmt), ZERO_AMOUNT, 0.001))
        { /* We can compare Net vs Gross */
            checkFeesNetVsGross(currPos, bAllFieldsEqual, "Pos", ExtPos_PosGrossAmt, ExtPos_PosNetAmt);
            checkFeesNetVsGross(currPos, bAllFieldsEqual, "Ref", ExtPos_RefGrossAmt, ExtPos_RefNetAmt);
            checkFeesNetVsGross(currPos, bAllFieldsEqual, "Sys", ExtPos_SysGrossAmt, ExtPos_SysNetAmt);
        }
	}
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkNegativeExchangeRate
**
**  Description :  Check if we have a negative exchange rate
**
**  Arguments   :  currPos          Position to test
**                 bAllFieldsEqual  Comparison status set to false on difference
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustment P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
void DftFusionQuickCheck::checkNegativeExchangeRate(const DBA_DYNFLD_STP currPos, bool & bAllFieldsEqual)
{
    static FIELD_IDX_T fields[] = { ExtPos_PosExchRate
                                  , ExtPos_InstrExchRate
                                  , ExtPos_SysExchRate
                                  , ExtPos_BookPosExchRate
                                  , ExtPos_BookInstrExchRate
                                  , ExtPos_BookSysExchRate
                                  };

    for (size_t idx = 0; idx < sizeof(fields) / sizeof(fields[0]); idx++)
    {
        if (GET_EXCHANGE(currPos, fields[idx]) < ZERO_EXCHANGE && ZERO_ID == GET_ID(currPos, ExtPos_BalPosTpId))
        { /* Probably an error */
            std::string fieldName = DFT_GetFieldName(currPos, fields[idx]);

            char szBuf[512];
            sprintf(szBuf, "%s: %s Operation code:%s, negative exchange rate for %s: %f", m_ptfName.c_str(), m_instrName.c_str(), GET_CODE(currPos, ExtPos_OpenOpCd), fieldName.c_str(), GET_EXCHANGE(currPos, fields[idx]));

            std::string message = szBuf;
            log(message);

            bAllFieldsEqual = false;
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::checkCloseFutureFeesAccount3
**
**  Description :  Check if we the closing future have fees into account 3 like expected
**
**  Arguments   :  currPos          Position to test
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustment P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
void DftFusionQuickCheck::checkCloseFutureFeesAccount3(const DBA_DYNFLD_STP currPos)
{
    PosLog pos(currPos, 0);

    if (  true == pos.isPrimary()
       && true == pos.isBuyOrSell()
       && true == pos.isFutureKindCloseCase()
       )
    {
        const AMOUNT_T bpSum = pos.computeBPSum();

        if (bpSum > ZERO_AMOUNT && false == pos.hasCashAccount3())
        {
            if (true == pos.isFutureCloseCase() || pos.isClosedItSelf())
            { /* Fees are not in account 3 */
                char szBuf[512];
                /* I need to put more code. For example the merge of 2 sell rise false message */
                sprintf(szBuf, "%s: %s Operation code:%s, fees:%f has to be in Account 3", m_ptfName.c_str(), m_instrName.c_str(), GET_CODE(currPos, ExtPos_OpenOpCd), bpSum);

                std::string message = szBuf;
                log(message);
            }
        }
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::logFile
**
**  Description :  Message to log into the log file
**
**  Arguments   :  message         Message to log
**
**  Return      :  void
**
**  Last modif. :  PMSTA-24997 - 281016 - PMO : The Cost Price and Cost Exchange Rate are wrong after P&L adjustment
**
*************************************************************************/
void DftFusionQuickCheck::logFile(const std::string & message)
{
    std::string out = message;

    // Remove output sequence when writting into the file
    SYS_StringRemoveTags(out, "\x1b[31m");
    SYS_StringRemoveTags(out, "\x1b[32m");
    SYS_StringRemoveTags(out, "\x1b[33m");
    SYS_StringRemoveTags(out, "\x1b[1m");
    SYS_StringRemoveTags(out, "\x1b[0m");

    if (m_streamLog != nullptr){
        *m_streamLog << m_dateTime << "  " << out << std::endl;
    } else if (m_streamLogFile.is_open()){
        m_streamLogFile << m_dateTime << "  " << out << std::endl;
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::logConsole
**
**  Description :  Message to log to the console
**
**  Arguments   :  message         Message to log
**
**  Return      :  void
**
**  Last modif. :  PMSTA-24997 - 281016 - PMO : The Cost Price and Cost Exchange Rate are wrong after P&L adjustment
**
*************************************************************************/
void DftFusionQuickCheck::logConsole(const std::string & message)
{
    if (m_logConsole){
        std::cout << "    " << message << std::endl;
    }
}


/************************************************************************
**
**  Function    :  DftFusionQuickCheck::log
**
**  Description :  Message to log
**
**  Arguments   :  message         Message to log
**
**  Return      :  void
**
**  Last modif. :  PMSTA-22368 - 080316 - PMO : Adjustment P&L without fees & taxes: position amounts of adjusted position are wrong
**
*************************************************************************/
void DftFusionQuickCheck::log(const std::string & message)
{

    logFile(message);
    logConsole(message);
}


/************************************************************************
**      END        dfttestfusion.c
*************************************************************************/

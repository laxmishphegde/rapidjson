/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Includes
*************************************************************************/
#define STRING_H
#include "unidef.h"
#include "syslib.h"

#include "icu4aaa.h"
#include <unicode/unistr.h>

/************************************************************************
**      Static Data Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   DFT_EmptyFuntion()
**
**  Description :   Empty function
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   Last modif. : PMSTA-8189 - 300409 - PMO : Missing Hebrew tests in the Unicode self test command line
*************************************************************************/
STATIC void DFT_EmptyFuntion(void* p, const char* cchar, const TEXT_CONVERSION_TYPE_ENUM convType)
{
}

/************************************************************************
**
**  Function    :   DFT_TestIcu()
**
**  Description :   Test ICU functions used
**
**  Argument    :   None
**
**  Return      :   0 Ok
**                  1 Error
**
**  Last modif. :   REF11770 - 4.20 - Test of the ICU library
**                  PMSTA-8189 - 300409 - PMO : Missing Hebrew tests in the Unicode self test command line
**                  PMSTA-10238 - 140710 - PMO : Import rejects special characters in the field name in Unicode database
**                  PMSTA-10929 - 021110 - PMO : A Unicode denomination is not displayed when his default value is set to the maximum field length (g. 80 chars)
**                  PMSTA-13866 - 070312 - PMO : Allow SQLDUMP to works with long ID, Unicode and timestamp
**
*************************************************************************/
int DFT_TestIcu(void)
{
    const char          cszTesz1[]      = "Simple test of a Unicode object";
    const char          cszHtmlHebrew[] = "&#x05D0;";
    const char          cszError[]      = "Error: ICU test ";
    UnicodeString       uString1;
    const UnicodeString uString2        = cszTesz1;
    UChar               uchar1[128];            /* Unicode work buffer              */
    UChar               uchar2[128];            /* Unicode work buffer              */
    UChar               uchar3[128];            /* Unicode work buffer              */
    char                szChar1[128];           /* Char work buffer                 */
    char                szChar2[128];           /* Char work buffer                 */
    UChar				szUniChar1[128];        /* Sybase implementation of Unicode */
    UChar				szUniChar2[128];        /* Sybase implementation of Unicode */
    int                 ret             = 0;    /* Return value                     */
    int                 written;                /* Number of output characters      */
    PAD_ENUM            penPad;


    /*
     * For coverage
     */
    memset(uchar1,  0, sizeof(uchar1));
    memset(szChar1, 0, sizeof(szChar1));
    (void)ICU4AAA_ConvertToHTML(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written);
    (void)ICU4AAA_ConvertToHTML(uchar1,  1, szChar1, 0, &written);
    (void)ICU4AAA_ConvertToHTML(uchar1,  1, szChar1, 0, NULL);

    (void)ICU4AAA_ConvertFromHTML(szChar1, -1, uchar1, sizeof(uchar1)/sizeof(UChar), &written);
    (void)ICU4AAA_ConvertFromHTML(szChar1,  1, uchar1, 0, &written);
    (void)ICU4AAA_ConvertFromHTML(szChar1,  1, uchar1, 0, NULL);
    (void)ICU4AAA_ConvertFromHTML("&",      1, uchar1, sizeof(uchar1)/sizeof(UChar), NULL);    /* Bad encoding */
    (void)ICU4AAA_ConvertFromHTML("&.#",    1, uchar1, sizeof(uchar1)/sizeof(UChar), NULL);    /* Bad encoding */
    (void)ICU4AAA_ConvertFromHTML("&#.x",   1, uchar1, sizeof(uchar1)/sizeof(UChar), NULL);    /* Bad encoding */
    (void)ICU4AAA_ConvertFromHTML("&#x.;",  1, uchar1, sizeof(uchar1)/sizeof(UChar), NULL);    /* Bad encoding */

    (void)ICU4AAA_ConvertToASCII(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written);
    (void)ICU4AAA_ConvertToASCII(uchar1,  1, szChar1, 0, &written);
    (void)ICU4AAA_ConvertToASCII(uchar1,  1, szChar1, 0, NULL);

    (void)ICU4AAA_ConvertFromASCII(szChar1, -1, uchar1, sizeof(uchar1)/sizeof(UChar), &written);
    (void)ICU4AAA_ConvertFromASCII(szChar1,  1, uchar1, 0, &written);
    (void)ICU4AAA_ConvertFromASCII(szChar1, -1, uchar1, 1, &written);    /* PMSTA-10929 - 021110 - PMO */
    (void)ICU4AAA_ConvertFromASCII(szChar1,  1, uchar1, 1, &written);    /* PMSTA-10929 - 021110 - PMO */
    (void)ICU4AAA_ConvertFromASCII(szChar1, -1, uchar1, 2, &written);    /* PMSTA-10929 - 021110 - PMO */
    (void)ICU4AAA_ConvertFromASCII(szChar1,  1, uchar1, 2, &written);    /* PMSTA-10929 - 021110 - PMO */
    (void)ICU4AAA_ConvertFromASCII(szChar1,  1, uchar1, 0, NULL);

    (void)ICU4AAA_ConvertToUTF8(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written);
    (void)ICU4AAA_ConvertToUTF8(uchar1,  1, szChar1, 0, &written);
    (void)ICU4AAA_ConvertToUTF8(uchar1,  1, szChar1, 0, NULL);

    (void)ICU4AAA_ConvertToISO1(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written);
    (void)ICU4AAA_ConvertToISO1(uchar1,  1, szChar1, 0, &written);
    (void)ICU4AAA_ConvertToISO1(uchar1,  1, szChar1, 0, NULL);

    (void)ICU4AAA_ConvertFromISO1(szChar1, -1, uchar1, sizeof(uchar1)/sizeof(UChar), &written);
    (void)ICU4AAA_ConvertFromISO1(szChar1,  1, uchar1, 0, &written);
    (void)ICU4AAA_ConvertFromISO1(szChar1,  1, uchar1, 0, NULL);

    (void)ICU4AAA_ConvertToISO8(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written);
    (void)ICU4AAA_ConvertToISO8(uchar1,  1, szChar1, 0, &written);
    (void)ICU4AAA_ConvertToISO8(uchar1,  1, szChar1, 0, NULL);

    (void)ICU4AAA_ConvertFromISO8(szChar1, -1, uchar1, sizeof(uchar1)/sizeof(UChar), &written);
    (void)ICU4AAA_ConvertFromISO8(szChar1,  1, uchar1, 0, &written);
    (void)ICU4AAA_ConvertFromISO8(szChar1,  1, uchar1, 0, NULL);

    (void)ICU4AAA_ConvertFromUTF8(szChar1, -1, uchar1, sizeof(uchar1)/sizeof(UChar), &written);
    (void)ICU4AAA_ConvertFromUTF8(szChar1,  1, uchar1, 0, &written);
    (void)ICU4AAA_ConvertFromUTF8(szChar1,  1, uchar1, 0, NULL);


    uchar1[0] = 'X';
    uchar1[1] = 0;
    uchar2[0] = '&';
    uchar2[1] = 0;

    (void)ICU4AAA_UnicodeStrLen(uchar1, TextConversion_Iso1);
    (void)ICU4AAA_UnicodeStrLen(uchar1, TextConversion_Utf8);
    (void)ICU4AAA_UnicodeStrLen(uchar2, TextConversion_Xml);
    (void)ICU4AAA_UnicodeStrLen(NULL,   TextConversion_Xml);

    (void)ICU4AAA_CodePageStrLen("XYZ", TextConversion_Iso1);
    (void)ICU4AAA_CodePageStrLen("א",  TextConversion_Utf8);
    (void)ICU4AAA_CodePageStrLen("&#x05E8;&#x05D3;&#x05E1;&#x05D1;", TextConversion_Xml);

#if defined AAADEBUG || defined AAADEBUGMSG
    uchar1[0] = 0;
    (void) ICU4AAA_DEBUG_DisplayAsHTML(uchar1);
    (void) ICU4AAA_DEBUG_DisplayAsASCII(uchar1);
    (void) ICU4AAA_DEBUG_DisplayAsUTF8(uchar1);
    (void) ICU4AAA_DEBUG_DisplayAsISO1(uchar1);
    (void) ICU4AAA_DEBUG_DisplayAsISO8(uchar1);
#endif


    /*
     *  ICU Test 1
     *  - Simple test of a Unicode string
     */
    uString1  = "#";
    uString1 += cszTesz1;
    uString1 += "#";

    uString1.findAndReplace("#", "");

    if (uString1 != uString2)
    { /* Error */
        fprintf (stderr, "Error: ICU test 1 failed (UnicodeString)\n");
        ret = 1;
    }


    /*
     *  ICU Test 2
     *  - Simple conversion test with ascii characters
     */
    uchar1[0] = 'H';
    uchar1[1] = 'e';
    uchar1[2] = 'l';
    uchar1[3] = 'l';
    uchar1[4] = 'o';
    uchar1[5] = 0;
    if (0 != ICU4AAA_ConvertToHTML(uchar1, 6, szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp ("Hello" , szChar1))
    { /* Error */
        fprintf (stderr, "%s2 failed (ICU4AAA_ConvertToHTML)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 3
     *  - Simple conversion test with ascii characters
     */
    if (0 != ICU4AAA_ConvertToASCII(uchar1, 6, szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp ("Hello" , szChar1))
    { /* Error */
        fprintf (stderr, "%s3 failed (ICU4AAA_ConvertToASCII)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 4
     *  - Simple conversion test test with ascii characters
     */
    uchar2[0] = 'H';
    uchar2[1] = 'e';
    uchar2[2] = 'l';
    uchar2[3] = 'l';
    uchar2[4] = 'o';
    uchar2[5] = 0;
    if (0 != ICU4AAA_ConvertFromASCII(szChar1, sizeof(szChar1)/sizeof(char), uchar1, sizeof(uchar1)/sizeof(UChar), &written) ||
        0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s4 failed (ICU4AAA_ConvertFromASCII)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 5
     *  - Simple conversion test with Hebrew character
     */
    uchar1[0] = 1488;
    uchar1[1] = 0;
    if (0 != ICU4AAA_ConvertToHTML(uchar1, 2, szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp (cszHtmlHebrew , szChar1))
    { /* Error */
        fprintf (stderr, "%s5 failed (ICU4AAA_ConvertToHTML)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 6
     *  - Simple conversion test with Hebrew character
     */
    if (0 != ICU4AAA_ConvertFromHTML(cszHtmlHebrew, sizeof(cszHtmlHebrew)/sizeof(char), uchar2 , sizeof(uchar2)/sizeof(UChar), &written) ||
        0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s6 failed (ICU4AAA_ConvertFromHTML)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 7
     *  - Simple conversion test with Hebrew character
     */
    uchar1[0] = 1488;
    uchar1[1] = 0;
    if (0 != ICU4AAA_ConvertToUTF8(uchar1, 2, szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp ("\xd7\x90" , szChar1))
    { /* Error */
        fprintf (stderr, "%s7 failed (ICU4AAA_ConvertToUTF8)\n", cszError);
        ret = 1;
    }



    /*
     *  ICU Test 8
     *  - Simple conversion test with Hebrew character
     */
    if (0 != ICU4AAA_ConvertFromUTF8(szChar1, sizeof(szChar1)/sizeof(char), uchar2, sizeof(uchar2)/sizeof(UChar), &written) ||
        0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s8 failed (ICU4AAA_ConvertFromUTF8)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 9
     *  - Simple conversion test with ISO8859-1 characters
     */
    uchar1[0] = 'd';
    uchar1[1] = 0xE9;
    uchar1[2] = 'm';
    uchar1[3] = 0xEA;
    uchar1[4] = 'l';
    uchar1[5] = 0xE9;
    uchar1[6] = 'r';
    uchar1[7] = 'e';
    uchar1[8] = 'n';
    uchar1[9] = 't';
    uchar1[10] = 0;
    if (0 != ICU4AAA_ConvertToISO1(uchar1, sizeof(uchar1)/sizeof(UChar), szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp ("d\xe9m\xeal\xe9rent" , szChar1))
    { /* Error */
        fprintf (stderr, "%s9 failed (ICU4AAA_ConvertToISO1)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 10
     *  - Simple conversion test with ISO8859-1 characters
     */
    uchar1[0] = 'd';
    uchar1[1] = 0xE9;
    uchar1[2] = 'm';
    uchar1[3] = 0xEA;
    uchar1[4] = 'l';
    uchar1[5] = 0xE9;
    uchar1[6] = 'r';
    uchar1[7] = 'e';
    uchar1[8] = 'n';
    uchar1[9] = 't';
    uchar1[10] = 0;
    if (0 != ICU4AAA_ConvertFromISO1(szChar1, sizeof(szChar1)/sizeof(char), uchar2, sizeof(uchar2)/sizeof(UChar), &written)||
        0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s10 failed (ICU4AAA_ConvertFromISO1)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 11
     *  - Simple conversion test with Hebrew character
     */
    uchar1[0] = 1488;
    uchar1[1] = 0;
    if (0 != ICU4AAA_ConvertToISO8(uchar1, 2, szChar1, sizeof(szChar1)/sizeof(char), &written) ||
        0 != strcmp ("\xe0" , szChar1))
    { /* Error */
        fprintf (stderr, "%s11 failed (ICU4AAA_ConvertToISO8)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 12
     *  - Simple conversion test with Hebrew character
     */
    if (0 != ICU4AAA_ConvertFromISO8(szChar1, 2, uchar2, sizeof(uchar2)/sizeof(UChar), &written) ||
        0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s12 failed (ICU4AAA_ConvertFromISO8)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 13
     *  - Simple bidirectional test with the keyword Shalom in Hebrew
     */
    uchar1[0] = 1501;
    uchar1[1] = 1493;
    uchar1[2] = 1500;
    uchar1[3] = 1513;
    uchar1[4] = 0;
    uchar3[0] = 1513;
    uchar3[1] = 1500;
    uchar3[2] = 1493;
    uchar3[3] = 1501;
    uchar3[4] = 0;
    if (0 != ICU4AAA_BidiISO8(uchar1, u_strlen(uchar1), uchar2, sizeof(uchar2)/sizeof(UChar), &penPad) ||
        RightPad != penPad ||
        0 != u_strcmp (uchar3 , uchar2))
    { /* Error */
        fprintf (stderr, "%s13 failed (ICU4AAA_BidiISO8)\n", cszError);
        ret = 1;
    }


    /* PMSTA-8189 - 300409 - PMO */
    struct STRUCT_TEST
    {
        const char * pInput;  /* Input data                               / PMSTA-8189 - 300409 - PMO */
        const char * pOutput; /* Expected output data after processing    / PMSTA-8189 - 300409 - PMO */
    };


    /*
     *  ICU Test 14
     *  - Bidirectional test with Hebrew characters
     *  Source and target are encoded in XML
     */
    struct STRUCT_TEST  testToDo[] =
    {
        { "&#xFEFF;car is &#x05EA;&#x05D9;&#x05E0;&#x05D5;&#x05DB;&#x05DE; &#x05DC;&#x05DB;&#x05DB; in arabic"
        , "&#xFEFF;car is &#x05DB;&#x05DB;&#x05DC; &#x05DE;&#x05DB;&#x05D5;&#x05E0;&#x05D9;&#x05EA; in arabic"
        }
    ,   { "&#x05D9;&#x05DC;&#x05D2;&#x05E0;&#x05D0; &#x05D9;&#x05DE;&#x05D9;&#x05E0;&#x05E4; the car &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05EA;&#x05D9;&#x05E0;&#x05D5;&#x05DB;&#x05DE;"
        , "&#x05DE;&#x05DB;&#x05D5;&#x05E0;&#x05D9;&#x05EA; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; the car &#x05E4;&#x05E0;&#x05D9;&#x05DE;&#x05D9; &#x05D0;&#x05E0;&#x05D2;&#x05DC;&#x05D9;"
        }
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1;,456 ,123 &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6;\""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; 123, 456,&#x05D1;&#x05E1;&#x05D3;&#x05E8;\""
        }
    /*
     * This is a problem that exists with ICU 2.6 and 3.4.1.
     * After the bidirectional algorithm, parenthesis are ")456 ,123(" in place of "(456 ,123)".
     * Because numbers and parenthesis are between Hebrew characters I think that the test is right and must works.
     * We don't have received any call about.
     * A futur version of ICU will solve this problem.
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,(456 ,123) &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6;\""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; (123, 456), &#x05D1;&#x05E1;&#x05D3;&#x05E8;\""
        }

     */
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,123,456 &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; 123,456, &#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
    /*
     * This is a another bidirectional algorithm parenthesis problem that exists with ICU 2.6 and 3.4.1.
     * Because numbers and parenthesis are between Hebrew characters I think that the test is right and must works.
     * We don't have received any call about.
     * A futur version of ICU will solve this problem.
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1;,(123,456) &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; (123,456),&#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
     */
    ,   { "\"ok ,it is 123, 456\" &#x05D1;&#x05D5;&#x05E9;&#x05D7;&#x05DC; &#x05E8;&#x05DB;&#x05D6;\""
        , "\"ok ,it is 123, 456\" &#x05D6;&#x05DB;&#x05E8; &#x05DC;&#x05D7;&#x05E9;&#x05D5;&#x05D1;\""
        }
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,678 ,789 &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; 789, 678, &#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
    /*
     * This is a another bidirectional algorithm parenthesis problem that exists with ICU 2.6 and 3.4.1.
     * Because numbers and parenthesis are between Hebrew characters I think that the test is right and must works.
     * We don't have received any call about.
     * A futur version of ICU will solve this problem.
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,(678 ,789) &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; (789, 678), &#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
     */
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,789,678 &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; 789,678, &#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
    /*
     * This is a another bidirectional algorithm parenthesis problem that exists with ICU 2.6 and 3.4.1.
     * Because numbers and parenthesis are between Hebrew characters I think that the test is right and must works.
     * We don't have received any call about.
     * A futur version of ICU will solve this problem.
    ,   { "he said \" &#x05E8;&#x05D3;&#x05E1;&#x05D1; ,(789,678) &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D4;&#x05D6; \""
        , "he said \" &#x05D6;&#x05D4; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; (789,678), &#x05D1;&#x05E1;&#x05D3;&#x05E8; \""
        }
     */
    ,   { "\"ok ,678 ,789 it is\" &#x05D1;&#x05D5;&#x05E9;&#x05D7;&#x05DC; &#x05E8;&#x05DB;&#x05D6;"
        , "\"ok ,678 ,789 it is\" &#x05D6;&#x05DB;&#x05E8; &#x05DC;&#x05D7;&#x05E9;&#x05D5;&#x05D1;"
        }
    ,   { "&#x05DD;&#x05D5;&#x05DC;&#x05E9;"
        , "&#x05E9;&#x05DC;&#x05D5;&#x05DD;"
        }
    ,   { "MALAAS"
        , "MALAAS"
        }
    ,   { "&#x05D7;&#x05D5;&#x05E8;&#x05D1;&#x05DC;  &#x05DD;&#x05D2; \"!it is a car\" &#x05D1;&#x05D5;&#x05E9;&#x05D7;&#x05DC; &#x05E8;&#x05DB;&#x05D6;"
        , "&#x05D6;&#x05DB;&#x05E8; &#x05DC;&#x05D7;&#x05E9;&#x05D5;&#x05D1; \"it is a car!\" &#x05D2;&#x05DD;  &#x05DC;&#x05D1;&#x05E8;&#x05D5;&#x05D7;"
        }
    ,   { "&#x05D7;&#x05D5;&#x05E8;&#x05D1;&#x05DC;  &#x05DD;&#x05D2; \"it is a car!x\" &#x05D1;&#x05D5;&#x05E9;&#x05D7;&#x05DC; &#x05E8;&#x05DB;&#x05D6;"
        , "&#x05D6;&#x05DB;&#x05E8; &#x05DC;&#x05D7;&#x05E9;&#x05D5;&#x05D1; \"it is a car!x\" &#x05D2;&#x05DD;  &#x05DC;&#x05D1;&#x05E8;&#x05D5;&#x05D7;"
        }

    /*
     * This is a problem about where the sign is after the processing of the bidirectional algorithm.
     * The place isn't the same between ICU 2.6 and 3.4.1. "2-" vs "-2"
    ,   { "&#x05EA;&#x05DC;&#x05D6;&#x05E0; &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC;  &#x05E1;&#x05D5;&#x05D9;&#x05E1;&#x05DC;&#x05E6; 2-"
        , "2- &#x05E6;&#x05DC;&#x05E1;&#x05D9;&#x05D5;&#x05E1;  &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; &#x05E0;&#x05D6;&#x05DC;&#x05EA;"
        }
     */
    ,   { "5+1 5/1 5-1 5*1 &#x05E8;&#x05D5;&#x05EA;&#x05E4;&#x05DC;"
        , "&#x05DC;&#x05E4;&#x05EA;&#x05D5;&#x05E8; 1*5 5-1 5/1 5+1"
        }
    ,   { "5..2.5 &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC; &#x05D7;&#x05D5;&#x05D5;&#x05D8;&#x05DE; &#x05EA;&#x05D5;&#x05D9;&#x05D4;&#x05DC;"
        , "&#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; &#x05DE;&#x05D8;&#x05D5;&#x05D5;&#x05D7; &#x05DC;&#x05D4;&#x05D9;&#x05D5;&#x05EA; 2.5..5"
        }
    ,   { "$10 &#x05E8;&#x05D8;&#x05E9;"
        , "&#x05E9;&#x05D8;&#x05E8; $10"
        }

    /*
     * This is a problem about where the sign is after the processing of the bidirectional algorithm.
     * The place isn't the same between ICU 2.6 and 3.4.1. "-%10" vs "%10-"
    ,   { "%10- &#x05D4;&#x05E4;&#x05DC;&#x05D7;&#x05D4;"
        , "&#x05D4;&#x05D7;&#x05DC;&#x05E4;&#x05D4; %10-"
        }
    ,   { "&#x05D4;&#x05E4;&#x05DC;&#x05D7;&#x05D4; %10-"
        , "%10- &#x05D4;&#x05D7;&#x05DC;&#x05E4;&#x05D4;"
        }
    ,   { "456,123+ : &#x05D2;&#x05D5;&#x05E1; &#x05DF;&#x05E2;&#x05DE;&#x05DC; &#x05DF;&#x05E2;&#x05DE;&#x05DC; &#x05DF;&#x05D7;&#x05D1;&#x05DE; &#x05D9;&#x05D0;"
        , "&#x05D0;&#x05D9; &#x05DE;&#x05D1;&#x05D7;&#x05DF; &#x05DC;&#x05DE;&#x05E2;&#x05DF; &#x05DC;&#x05DE;&#x05E2;&#x05DF; &#x05E1;&#x05D5;&#x05D2; : 456,123+"
        }
     */
    ,   { "123,456A : &#x05D2;&#x05D5;&#x05E1; &#x05DF;&#x05E2;&#x05DE;&#x05DC; &#x05DF;&#x05E2;&#x05DE;&#x05DC; &#x05E3;&#x05E1;&#x05D5;&#x05E0;"
        , "123,456A : &#x05E0;&#x05D5;&#x05E1;&#x05E3; &#x05DC;&#x05DE;&#x05E2;&#x05DF; &#x05DC;&#x05DE;&#x05E2;&#x05DF; &#x05E1;&#x05D5;&#x05D2;"
        }
    ,   { "hooloo123,456 : &#x05D2;&#x05D5;&#x05E1; &#x05DF;&#x05E2;&#x05DE;&#x05DC; &#x05E8;&#x05EA;&#x05D5;&#x05D9;"
        , "hooloo123,456 : &#x05D9;&#x05D5;&#x05EA;&#x05E8; &#x05DC;&#x05DE;&#x05E2;&#x05DF; &#x05E1;&#x05D5;&#x05D2;"
        }
    ,   { "and &#x05DF;&#x05D7;&#x05D1;&#x05DE; |1&#x05DC;&#x05D0; ||too"
        , "and &#x05D0;&#x05DC;1| &#x05DE;&#x05D1;&#x05D7;&#x05DF; ||too"
        }
    };

    for ( int iTest = 0 ;  iTest < sizeof ( testToDo ) / sizeof ( testToDo[0] ) ; iTest++ )
    {
        memset(uchar1, 0, sizeof(uchar1));
        memset(uchar2, 0, sizeof(uchar2));
        memset(uchar3, 0, sizeof(uchar3));

        /* Convert the test and the expected result in Unicode strings */
        if (0 != ICU4AAA_ConvertFromHTML(testToDo[iTest].pInput,  SYS_StrLen(testToDo[iTest].pInput),  uchar1, sizeof(uchar1)/sizeof(UChar), &written) ||
            0 != ICU4AAA_ConvertFromHTML(testToDo[iTest].pOutput, SYS_StrLen(testToDo[iTest].pOutput), uchar3, sizeof(uchar3)/sizeof(UChar), &written)
           )
        { /* Error */
            fprintf (stderr, "%s14.%d failed (ICU4AAA_ConvertFromHTML)\n", cszError, iTest );
            ret = 1;
        }

        /* Apply the bidirectional algorithm and compare the result */
        if (0 != ICU4AAA_BidiISO8(uchar1, u_strlen(uchar1), uchar2, sizeof(uchar2)/sizeof(UChar), &penPad) ||
            0 != u_strcmp (uchar3 , uchar2))
        { /* Error */
            fprintf (stderr, "%s14.%d failed (ICU4AAA_BidiISO8)\n", cszError, iTest);
            ret = 1;
        }
    }


    /*
     *  ICU Test 16
     *  Simple conversion ascii to unicode and unicode to ascii
     * The conversion TextConversion_Ascii raise an assertion failure
     */
    strcpy(szChar1, "abc");
    if (  0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar1,  sizeof(uchar1)/sizeof(UChar), &written, TextConversion_None)
       || 0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar2, sizeof(szChar2)/sizeof(char), &written, TextConversion_None)
       || 0 != strcmp(szChar1, szChar2)
       )
    { /* Error */
        fprintf (stderr, "%s16 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 17
     *  Simple conversion ascii to unicode and unicode to ascii
     */
    strcpy(szChar1, "&");
    memset(uchar1, 0, sizeof(uchar1));
    memset(szChar2, 0, sizeof(szChar2)); /* PMSTA-8189 - 300409 - PMO */
    if (  0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar1,  sizeof(uchar1)/sizeof(UChar), &written, TextConversion_Xml)
       || 0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar2, sizeof(szChar2)/sizeof(char), &written, TextConversion_Xml)
       || 0 != strcmp("&#x26;", szChar2)
       )
    { /* Error */
        fprintf (stderr, "%s17 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 18
     *  - Simple ISO8859-1 Characters
     */
    uchar1[0] = 232;
    uchar1[1] = 233;
    uchar1[2] = 0;
    memset(szChar1, 0, sizeof(szChar1));
    memset(uchar2,  0, sizeof(uchar2));
    if (  0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar1, sizeof(szChar1)/sizeof(char), &written, TextConversion_Iso1)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar2,  sizeof(uchar2)/sizeof(UChar), &written, TextConversion_Iso1)
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s18 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 19
     *  - Simple ISO8859-5 Character
     */
    uchar1[0] = 1071;
    uchar1[1] = 0;
    memset(szChar1, 0, sizeof(szChar1));
    memset(uchar2,  0, sizeof(uchar2));
    if (  0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar1, sizeof(szChar1)/sizeof(char), &written, TextConversion_Iso5)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar2,  sizeof(uchar2)/sizeof(UChar), &written, TextConversion_Iso5)
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s19 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 20
     *  - Simple conversion test with Hebrew character
     */
    uchar1[0] = 1488;
    uchar1[1] = 0;
    memset(szChar1, 0, sizeof(szChar1));
    memset(uchar2,  0, sizeof(uchar2));
    if (  0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar1, sizeof(szChar1)/sizeof(char), &written, TextConversion_Iso8)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar2,  sizeof(uchar2)/sizeof(UChar), &written, TextConversion_Iso8)
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s20 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 21
     *  - Simple conversion test with Arabic character
     */
    uchar1[0] = 1589;
    uchar1[1] = 0;
    memset(szChar1, 0, sizeof(szChar1));
    memset(uchar2,  0, sizeof(uchar2));
    if (  0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar1, sizeof(szChar1)/sizeof(char), &written, TextConversion_Iso6)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,   SYS_StrLen(szChar1), uchar2,  sizeof(uchar2)/sizeof(UChar), &written, TextConversion_Iso6)
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s21 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 22
     *  - Simple conversion test with ASCII, Latin-1, Cyrillic, Hebrew and Arabic characters
     */
    uchar1[0] = 'A';
    uchar1[1] = 232;
    uchar1[2] = 233;
    uchar1[3] = 1071;
    uchar1[4] = 1488;
    uchar1[5] = 1589;
    uchar1[6] = 0;
    memset(szChar1, 0, sizeof(szChar1));
    memset(uchar2,  0, sizeof(uchar2));
    if (  0 != ICU4AAA_ConvertFromUChars(uchar1, u_strlen(uchar1), szChar1, sizeof(szChar1)/sizeof(char), &written, TextConversion_Utf8)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,  SYS_StrLen(szChar1),  uchar2,  sizeof(uchar2)/sizeof(UChar), &written, TextConversion_Utf8)
       || 0 != ICU4AAA_ConvertToUChars(szChar1,  -1,               uchar3,  sizeof(uchar3)/sizeof(UChar), &written, TextConversion_Utf8)
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s22 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*
     *  ICU Test 23
     *  - Simple parsing with characters ASCII, Latin-1, Cyrillic, Hebrew and Arabic 
     */
    uchar2[0] = 65279;
    uchar2[1] = 0;
    if (  0 != ICU4AAA_ParseCodePage(NULL, uchar1, DFT_EmptyFuntion)
       || 0 != ICU4AAA_ParseCodePage(NULL, uchar2, DFT_EmptyFuntion)
       )
    { /* Error */
        fprintf (stderr, "%s23 failed (ICU4AAA_ConvertToUChars/ICU4AAA_ConvertFromUChars)\n", cszError);
        ret = 1;
    }


    /*  PMSTA-10238 - 140710 - PMO
     *  ICU Test 24
     *  Test the function RemoveDiacriticalMarks
     */
    strcpy( szChar1 , "&#xE9;&#xEB;&#xE8;&#xE0;&#xE4;&#xF4;&#xEA;&#xEE;&#xCE;&#xC9;&#xCA;&#xC8;" );
    (void)ICU4AAA_ConvertFromHTML(szChar1, -1, uchar1,  sizeof(uchar1)  / sizeof(uchar1[0]),  NULL);
    (void)ICU4AAA_ConvertToISO1(uchar1,    -1, szChar1, sizeof(szChar1) / sizeof(szChar1[0]), NULL);

    bool bRet = ICU4AAA_RemoveDiacriticalMarks(szChar1);
    if (false == bRet || 0 != strcmp ("eeeaaoeiIEEE" , szChar1))
    { /* Error */
        fprintf (stderr, "%s24 failed (ICU4AAA_RemoveDiacriticalMarks)\n", cszError);
        ret = 1;
    }



    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 25
     *  Test the function ICU4AAA_sprintf
     */
    uchar2[0]  = '1';
    uchar2[1]  = '2';
    uchar2[2]  = '3';
    uchar2[3]  = '4';
    uchar2[4]  = '5';
    uchar2[5]  = '6';
    uchar2[6]  = '7';
    uchar2[7]  = '8';
    uchar2[8]  = '9';
    uchar2[9]  = '0';
    uchar2[10] = 'x';
    uchar2[11] = 'y';
    uchar2[12] = 'z';
    uchar2[13] = 0;
    if ( 13 != ICU4AAA_sprintf(uchar1, "%d%s", 1234567890,"xyz")
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s25 failed (ICU4AAA_sprintf)\n", cszError);
        ret = 1;
    }


    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 26
     *  Test the function ICU4AAA_sprintfU
     */
    uchar3[0] = '%';
    uchar3[1] = 'd';
    uchar3[2] = '%';
    uchar3[3] = 's';
    uchar3[4] = 0;
    if ( 13 != ICU4AAA_sprintfU(uchar1, uchar3, 1234567890,"xyz")
       || 0 != u_strcmp (uchar1 , uchar2)
       )
    { /* Error */
        fprintf (stderr, "%s26 failed (ICU4AAA_sprintfU)\n", cszError);
        ret = 1;
    }


    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 27
     *  Test the function ICU4AAA_strcat
     */
    uchar2[13] = 'a';
    uchar2[14] = 'b';
    uchar2[15] = 'c';
    uchar2[16] = 0;
    uchar3[0] = 'a';
    uchar3[1] = 'b';
    uchar3[2] = 'c';
    uchar3[3] = 0;
    ICU4AAA_strcat(uchar1, uchar3);
    if (0 != u_strcmp (uchar1 , uchar2))
    { /* Error */
        fprintf (stderr, "%s27 failed (ICU4AAA_strcat)\n", cszError);
        ret = 1;
    }


    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 28
     *  Test the function ICU4AAA_strlen
    uchar3[0] = 0;
    if (  16 != ICU4AAA_strlen(uchar2)
       || 0  != ICU4AAA_strlen(uchar3)
       )
    { * Error *
        fprintf (stderr, "%s28 failed (ICU4AAA_strlen)\n", cszError);
        ret = 1;
    }

     */


    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 29
     *  Test the function ICU4AAA_strlenUnichar
     */
    szUniChar1[0]  = '1';
    szUniChar1[1]  = '2';
    szUniChar1[2]  = '3';
    szUniChar1[3]  = '4';
    szUniChar1[4]  = '5';
    szUniChar1[5]  = '6';
    szUniChar1[6]  = '7';
    szUniChar1[7]  = '8';
    szUniChar1[8]  = '9';
    szUniChar1[9]  = '0';
    szUniChar1[10] = 'x';
    szUniChar1[11] = 'y';
    szUniChar1[12] = 'z';
    szUniChar1[13] = 'a';
    szUniChar1[14] = 'b';
    szUniChar1[15] = 'c';
    szUniChar1[16] = 0;
    szUniChar2[0] = 0;
    if (  16 != ICU4AAA_strlenUnichar(szUniChar1)
       || 0  != ICU4AAA_strlenUnichar(szUniChar2)
       )
    { /* Error */
        fprintf (stderr, "%s29 failed (ICU4AAA_strlenUnichar)\n", cszError);
        ret = 1;
    }


    /*  PMSTA-13866 - 070312 - PMO
     *  ICU Test 30
     *  Test the function ICU4AAA_ConvertFromUTF8
     */
    for ( int iTest = 0 ;  iTest < sizeof ( testToDo ) / sizeof ( testToDo[0] ) ; iTest++ )
    {
        memset(uchar1, 0, sizeof(uchar1));
        memset(uchar2, 0, sizeof(uchar2));
        memset(uchar3, 0, sizeof(uchar3));

        /* Convert the test and the expected result in Unicode strings */
        if (  0 != ICU4AAA_ConvertFromHTML(testToDo[iTest].pInput,  SYS_StrLen(testToDo[iTest].pInput),  uchar1, sizeof(uchar1)/sizeof(UChar), &written)
           || 0 != ICU4AAA_ConvertToUTF8(uchar1, -1, szChar1, sizeof(szChar1)/sizeof(char), &written)
           || 0 != ICU4AAA_ConvertFromUTF8Unichar(szChar1, SYS_StrLen(szChar1), szUniChar1, sizeof(szUniChar1), &written)
           || 0 != u_strcmp (uchar1, (const UChar *)szUniChar1)
           )
        { /* Error */
            fprintf (stderr, "%s30.%d failed (ICU4AAA_ConvertFromUTF8)\n", cszError, iTest );
            ret = 1;
        }
    }

    return ret;
}




/************************************************************************
**      END        dfttesticu.c                                   
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINPERFA2_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define MATH_H
#define TIME_H
#define STDLIB_H

#include "unidef.h" 
#include "gen.h"
#include "conv.h"
#include "dba.h"
#include "ope.h"
#include "date.h"
#include "cmp.h"
#include "hier.h"
#include "fin.h"
#include "finperfa.h"
#include "finlib04.h"

/************************************************************************
**      External entry points
**
**
**
*************************************************************************/
                             
/************************************************************************
**      Static definitions & data
*************************************************************************/
typedef struct {
    NUMBER_T           *retValTab;
    NUMBER_T           retTotal;
    NUMBER_T           average;
    NUMBER_T           volatility;
    DBA_DYNFLD_STP     statPtr;
} RETURN_INFO_ST;


/************************************************************************
**      Local functions
**
**
**
*************************************************************************/
STATIC RET_CODE FIN_ReturnTotal(RETURN_INFO_ST*, int);

/************************************************************************
**      FONCTIONS
************************************************************************/

/************************************************************************
**
**  Function    :   FIN_RiskRatioPAA()
**
**  Description :   Compute risk ratio for performance attribution
**                 
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED
**
**  Creation D. : REF8705 - LJE - 030120
**  Last modif. : 
** 
*************************************************************************/
RET_CODE FIN_RiskRatioPAA(DATETIME_T     *datesTab, 
                          DBA_DYNFLD_STP *returnTab, 
                          int            dataNbr, 
                          FLAG_T         yearFlg,
                          FREQUNIT_ENUM  freqUnit,
                          DBA_DYNFLD_STP aRiskRatioSt)
{

    RETURN_INFO_ST     retInfo[4];
    int                retValNbr;
	int                i, j, nbrYear;
	RET_CODE           ret;
    NUMBER_T           number, betaPtf, covRptfRbench,
                       aAveragePtf, aAverageBench, aAverageRF,
                       averagePtf, averageBench, averageRF;

    /* REF8799 - LJE - 030217 */
    for (j=0; j<4; j++)
    {
	    retInfo[j].retValTab = NULL;
        retInfo[j].statPtr   = NULLDYNST;
    }


    switch (freqUnit)
	{
	case FreqUnit_Day: 
        nbrYear = 360;
		break;

	case FreqUnit_BusDay: 
        nbrYear = 360;
		break;

	case FreqUnit_Week: 
        nbrYear = 52;
		break;

	case FreqUnit_Month: 
        nbrYear = 12;
		break;

	case FreqUnit_Quarter: 
        nbrYear = 4;
		break;

	case FreqUnit_Semester: 
        nbrYear = 2;
		break;

	case FreqUnit_Year:
        nbrYear = 1;
		break;

    default :
        nbrYear = 12; /* Month... */
	}


    for (j=0; j<4; j++)
    {
        if ((retInfo[j].statPtr = ALLOC_DYNST(A_Stat)) == NULLDYNST)
        {
            /* REF8799 - LJE - 030217 */
            for (i=0; i<j; i++)
            {
	            FREE(retInfo[i].retValTab);
                FREE_DYNST(retInfo[i].statPtr, A_Stat);
            }

		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((retInfo[j].retValTab = (double *)CALLOC(dataNbr, sizeof(double))) == (double*)NULL )
	    {
            /* REF8799 - LJE - 030217 */
            for (i=0; i<=j; i++)
            {
	            FREE(retInfo[i].retValTab);
                FREE_DYNST(retInfo[i].statPtr, A_Stat);
            }

		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }
    }

	for (i=0, retValNbr=0; i<dataNbr; i++)
	{
		/* Exclude lines where the value is NULL */
		if (IS_NULLFLD(returnTab[i], 0) == FALSE)
		{
			retInfo[0].retValTab[retValNbr] = GET_NUMBER(returnTab[i], 0) / 100.;
            retInfo[1].retValTab[retValNbr] = GET_NUMBER(returnTab[i], 1) / 100.;
            retInfo[2].retValTab[retValNbr] = GET_NUMBER(returnTab[i], 2) / 100.;
            /* For tracking error */
            retInfo[3].retValTab[retValNbr] = retInfo[0].retValTab[retValNbr] - retInfo[1].retValTab[retValNbr];

			++retValNbr;
		}
	}

	if (retValNbr > 1)
	{
        /* Compute Return total */
        for (j = 0; j < 4; j++)
        {
    		ret = FIN_CalcStat(retInfo[j].retValTab, retValNbr, retInfo[j].statPtr);
            ret = FIN_ReturnTotal(&retInfo[j], retValNbr);
        }

	}
	else
	{
        /* REF8799 - LJE - 030217 */
        for (j = 0; j < 4; j++)
        {
	        FREE(retInfo[j].retValTab);
            FREE_DYNST(retInfo[j].statPtr, A_Stat);
        }

		return(RET_FIN_ERR_INVDATA);
	}

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Volatility,GET_NUMBER(retInfo[0].statPtr, A_Stat_StdDeviation) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchVolat,GET_NUMBER(retInfo[1].statPtr, A_Stat_StdDeviation) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFVolat,   GET_NUMBER(retInfo[2].statPtr, A_Stat_StdDeviation) * 100);

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Min,       GET_NUMBER(retInfo[0].statPtr, A_Stat_Min) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchMin,  GET_NUMBER(retInfo[1].statPtr, A_Stat_Min) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFMin,     GET_NUMBER(retInfo[2].statPtr, A_Stat_Min) * 100);

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Max,       GET_NUMBER(retInfo[0].statPtr, A_Stat_Max) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchMax,  GET_NUMBER(retInfo[1].statPtr, A_Stat_Max) * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFMax,     GET_NUMBER(retInfo[2].statPtr, A_Stat_Max) * 100);

    averagePtf   = retInfo[0].average;
    averageBench = retInfo[1].average;
    averageRF    = retInfo[2].average;
    
    aAveragePtf   = pow((retInfo[0].average+1), nbrYear) - 1;
    aAverageBench = pow((retInfo[1].average+1), nbrYear) - 1;
    aAverageRF    = pow((retInfo[2].average+1), nbrYear) - 1;

    if (yearFlg)
    {
        averagePtf   = aAveragePtf;
        averageBench = aAverageBench;
        averageRF    = aAverageRF;

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_AMean,     GET_NUMBER(retInfo[0].statPtr, A_Stat_Mean) * 100 * nbrYear);
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchAMean,GET_NUMBER(retInfo[1].statPtr, A_Stat_Mean) * 100 * nbrYear);
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFAMean,   GET_NUMBER(retInfo[2].statPtr, A_Stat_Mean) * 100 * nbrYear);

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_GMean,     aAveragePtf   * 100);

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchGMean,aAverageBench * 100);

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFGMean,   aAverageRF    * 100);

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_Volatility, 
                                 sqrt((double)nbrYear) * GET_NUMBER(aRiskRatioSt, A_RiskRatio_Volatility));

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchVolat, 
                                 sqrt((double)nbrYear) * GET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchVolat));

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFVolat, 
                                 sqrt((double)nbrYear) * GET_NUMBER(aRiskRatioSt, A_RiskRatio_RFVolat));
    }
    else
    {
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_AMean,     GET_NUMBER(retInfo[0].statPtr, A_Stat_Mean) * 100);
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchAMean,GET_NUMBER(retInfo[1].statPtr, A_Stat_Mean) * 100);
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_RFAMean,   GET_NUMBER(retInfo[2].statPtr, A_Stat_Mean) * 100);

        SET_NUMBER(aRiskRatioSt,  A_RiskRatio_GMean,     averagePtf   * 100);
        SET_NUMBER(aRiskRatioSt,  A_RiskRatio_BenchGMean,averageBench * 100);
        SET_NUMBER(aRiskRatioSt,  A_RiskRatio_RFGMean,   averageRF    * 100);

    }

    /*          average(Rptf) - average(Rrf)
     * Sharpe = ----------------------------
     *                volatility(Rptf)
     */

    number = FIN_DIV((averagePtf - averageRF), (GET_NUMBER(aRiskRatioSt, A_RiskRatio_Volatility)/100));

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Sharpe, number);

    /*               average(Rbench) - average(Rrf)
     * BenchSharpe = ------------------------------
     *                     volatility(Rbench)
     */
    number = FIN_DIV((averageBench - averageRF), (GET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchVolat)/100));

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_BenchSharpe, number);


    /*           average(Rptf) - average(Rrf)
     * Treynor = ----------------------------
     *                  Bptf
     *
     *           CovRptfRbench      CovRptfRbench
     * Bptf    = --------------- =  -------------
     *              VarRbench        volatility^2
     */
    covRptfRbench = 0.0;
    for (i=0; i<retValNbr; i++)
    {
        number = (retInfo[0].retValTab[i]-GET_NUMBER(retInfo[0].statPtr, A_Stat_Mean))*
                           (retInfo[1].retValTab[i]-GET_NUMBER(retInfo[1].statPtr, A_Stat_Mean));

        covRptfRbench += number;
    }

    /* PMSTA-39941 - DDV - 200429 - Add check to avoid divide by zero */
    if ((retValNbr-1) != 0.0)
    {
        covRptfRbench *= 1./(double)(retValNbr-1);
    }
    else
    {
        covRptfRbench = 0.0;
    }

    betaPtf = FIN_DIV(covRptfRbench, pow(GET_NUMBER(retInfo[1].statPtr, A_Stat_StdDeviation), 2));

    number = FIN_DIV((averagePtf - averageRF), betaPtf);

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Treynor, number * 100);
    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Beta,    betaPtf);


    /*
     * Jensen = average(Rptf)-[average(Rrf) + Beta*(average(Rbench) - average(Rrf)]
     */
    number = averagePtf - (averageRF + betaPtf * (averageBench - averageRF));

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_Jensen, number * 100);

    /*
     * ExcessReturn XRi     = Rptf,i - Rbench,i
     *
     * ExcessReturnTotal XR = Rptf - Rbench
     * 
     * Average              =    (1+ExcessReturnTotal)^1/2 - 1
     *                         __________________________________
     * volatility           = V 1/n-1 * SUM(XRi - average(XR))^2
     *
     * Tracking error       = volatility(Rptf,i - Rbench,i)
     *
     */
    

    if (yearFlg)
    {
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_TrackingError, sqrt((double)nbrYear) * GET_NUMBER(retInfo[3].statPtr, A_Stat_StdDeviation) * 100);

        /* PMSTA-39941 - DDV - 200429 - Add check to avoid divide by zero */
        if (retValNbr != 0.0)
        {
            number = pow(1+(retInfo[0].retTotal+1) - (retInfo[1].retTotal+1), nbrYear / (double)retValNbr) -1;
        }
        else
        {
            number = 0.0;
        }

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_ExcessReturn, number * 100);
    }
    else
    {
        SET_NUMBER(aRiskRatioSt, A_RiskRatio_TrackingError, GET_NUMBER(retInfo[3].statPtr, A_Stat_StdDeviation) * 100);

        /* PMSTA-39941 - DDV - 200429 - Add check to avoid divide by zero */
        if (retValNbr != 0.0)
        {
            number = pow(1+(retInfo[0].retTotal+1) - (retInfo[1].retTotal+1), 1 / (double)retValNbr) -1;
        }
        else
        {
            number = 0.0;
        }

        SET_NUMBER(aRiskRatioSt, A_RiskRatio_ExcessReturn, number * 100);
    }


    /*
     * Information Ratio = ExcessReturn / TrackingError
     */

    number = FIN_DIV(GET_NUMBER(aRiskRatioSt, A_RiskRatio_ExcessReturn), GET_NUMBER(aRiskRatioSt, A_RiskRatio_TrackingError));

    SET_NUMBER(aRiskRatioSt, A_RiskRatio_InformationRatio, number);


    for (j=0; j<4; j++)
    {
        FREE(retInfo[j].retValTab);
        FREE_DYNST(retInfo[j].statPtr, A_Stat);
    }

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ReturnTotal()
**
**  Description :   Compute risk ratio for performance attribution
**                 
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED
**
**  Creation D. : REF8705 - LJE - 030120
**  Last modif. : 
** 
*************************************************************************/
STATIC RET_CODE FIN_ReturnTotal(RETURN_INFO_ST *retInfo, int retValNbr)
{

    int      i;
    
    retInfo->retTotal=0.0;

    for (i=0; i<retValNbr; i++)
    {
        if (i==0)
            retInfo->retTotal = 1+retInfo->retValTab[i];
        else
            retInfo->retTotal *= 1+retInfo->retValTab[i];
    }

    retInfo->retTotal -= 1;

    retInfo->average = pow((1+retInfo->retTotal), 1./(double)retValNbr) -1; 

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpObjectLnkFromObjectId()
**
**  Description :   Object links are sorted by A_ObjectLnk_FromObjectId
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_ObjectLnk
**                  ptr2   pointer on dynamic structure type A_ObjectLnk
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7758 - DDV - 021002
**  Last modif. : 
** 
*************************************************************************/
EXTERN int FIN_CmpObjectLnkFromObjectId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmpRet=CMP_ID(GET_ID((*ptr1), A_ObjectLnk_FromObjectId) , GET_ID((*ptr2), A_ObjectLnk_FromObjectId));

    if (cmpRet == 0)
        cmpRet=CMP_ID(GET_ID((*ptr1), A_ObjectLnk_FromEntDictId) , GET_ID((*ptr2), A_ObjectLnk_FromEntDictId));
    return(cmpRet); 
}

/************************************************************************
**
**  Function    :   FIN_CmpObjectLnkToObjectId()
**
**  Description :   Object links are sorted by A_ObjectLnk_ToObjectId
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type A_ObjectLnk
**                  ptr2   pointer on dynamic structure type A_ObjectLnk
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7758 - DDV - 021002
**  Last modif. : 
** 
*************************************************************************/
EXTERN int FIN_CmpObjectLnkToObjectId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmpRet=CMP_ID(GET_ID((*ptr1), A_ObjectLnk_ToObjectId) , GET_ID((*ptr2), A_ObjectLnk_ToObjectId));

    if (cmpRet == 0)
        cmpRet=CMP_ID(GET_ID((*ptr1), A_ObjectLnk_ToEntDictId) , GET_ID((*ptr2), A_ObjectLnk_ToEntDictId));
    return(cmpRet); 
}

/************************************************************************
**
**  Function    :   FIN_FilterUnusedObjectLnk()
**
**  Description :   Return only unused ObjectLnk (nature is NULL or None)
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF7758 - DDV - 021002
**
*************************************************************************/
EXTERN int FIN_FilterUnusedObjectLnk(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == TRUE ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T) ObjectLnkNat_None)
		return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterUsedObjectLnk()
**
**  Description :   Return only used ObjectLnk (nature is define)
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF7758 - DDV - 021002
**
*************************************************************************/
EXTERN int FIN_FilterUsedObjectLnk(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) != TRUE &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) != (ENUM_T) ObjectLnkNat_None)
		return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPerfInterBenchByPAId()
**
**  Description :   
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA08736 - LJE - 100603
**
*************************************************************************/
int FIN_FilterPerfInterBenchByPAId(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testSt)
{
    if (CMP_DYNFLD(dynSt, testSt, 
                   A_PerfInterBench_LinkedPerfAttribId, A_PerfInterBench_LinkedPerfAttribId, IdType) == 0 &&
        CMP_DYNFLD(dynSt, testSt, 
                   A_PerfInterBench_PerfEffectDefId, A_PerfInterBench_PerfEffectDefId, IdType) == 0)
    {
        return (TRUE);
    }
    return (FALSE);
}

/************************************************************************
**
**  Function    :   FIN_GetPerfInterBench()
**
**  Description :   Get a perf intermediate benchmark
**                 
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED
**
**  Creation D. : PMSTA08736 - LJE - 100603
**  Last modif. : 
** 
*************************************************************************/
RET_CODE FIN_GetPerfInterBench(DBA_HIER_HEAD_STP hierHead,
                               ID_T              perfAttribBenchId,
                               ID_T              perfEffectDefId,
                               DBA_DYNFLD_STP    currentRecordStp,
                               DBA_DYNFLD_STP   *perfInterBenchStpPtr)
{
    RET_CODE       ret=RET_SUCCEED;
    DBA_DYNFLD_STP benchRecStp=NULL, perfInterBenchStp=NULL;
    int            k;

    if (perfInterBenchStpPtr == NULL)
        return RET_GEN_ERR_INVARG;

    *perfInterBenchStpPtr = NULL;

    /* First, try to search in the current record */
    if (GET_DYNSTENUM(currentRecordStp) == A_PerfAttrib)
    {
        for (k=A_PerfAttrib_Bench1PerfAttrib_Ext; 
             k<=A_PerfAttrib_Bench3PerfAttrib_Ext && benchRecStp == NULL; 
             k++)
        {
            if (GET_EXTENSION_PTR(currentRecordStp, k) != NULL)
            {
                if ((benchRecStp = *GET_EXTENSION_PTR(currentRecordStp, k)) != NULL &&
                    CMP_ID(perfAttribBenchId, GET_ID(benchRecStp, A_PerfAttrib_Id)) != 0)
                {
                    benchRecStp = NULL;
                }
            }
        }
        if (benchRecStp != NULL &&
            GET_EXTENSION_PTR(benchRecStp, A_PerfAttrib_FirstPerfInterBench_Ext) != NULL)
        {
            perfInterBenchStp = *GET_EXTENSION_PTR(benchRecStp, A_PerfAttrib_FirstPerfInterBench_Ext);
        }

        if (perfInterBenchStp != NULL)
        {
            while (*perfInterBenchStpPtr == NULL &&
                   perfInterBenchStp != NULL)
            {
                if (GET_ID(perfInterBenchStp, A_PerfInterBench_PerfEffectDefId) == perfEffectDefId)
                {
                    *perfInterBenchStpPtr = perfInterBenchStp;
                }
                else
                {
                    if (GET_EXTENSION_PTR(perfInterBenchStp, A_PerfInterBench_NextPerfInterBench_Ext) != NULL)
                    {
                        perfInterBenchStp = *GET_EXTENSION_PTR(perfInterBenchStp, A_PerfInterBench_NextPerfInterBench_Ext);
                    }
                    else
                    {
                        perfInterBenchStp = NULL;
                    }
                }
            }
        }    
    }

    if (benchRecStp == NULL)
    {
		DBA_DYNFLD_STP *findTab;
		int             findNbr;

        /* If not found, search in the full table */
        if ((perfInterBenchStp = ALLOC_DYNST(A_PerfInterBench)) == NULL)
        {
            return RET_MEM_ERR_ALLOC;
        }

        SET_ID(perfInterBenchStp, A_PerfInterBench_LinkedPerfAttribId, perfAttribBenchId);
        SET_ID(perfInterBenchStp, A_PerfInterBench_PerfEffectDefId, perfEffectDefId);

        if (DBA_ExtractHierEltRecByIndexKey(hierHead, 
                                            A_PerfInterBench,
                                            A_PerfInterBench_LinkedPerfAttribId,
                                            perfInterBenchStp[A_PerfInterBench_LinkedPerfAttribId],
                                            FALSE, 
                                            FIN_FilterPerfInterBenchByPAId, 
                                            perfInterBenchStp,
                                            NULL,
                                            FALSE, 
                                            &findNbr,
                                            &findTab) == RET_SUCCEED &&
             findNbr == 1)
        {
            *perfInterBenchStpPtr = findTab[0];
        }

        FREE(findTab);
        FREE_DYNST(perfInterBenchStp, A_PerfInterBench);
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterPerfEffectDefByRank()
**
**  Description :   
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum 
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA08736 - LJE - 100603
**
*************************************************************************/
int FIN_FilterPerfEffectDefByRank(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testSt)
{
    if (CMP_DYNFLD(dynSt, testSt, 
                   A_PerfEffectDef_Rank, A_PerfEffectDef_Rank, SmallintType) == 0 &&
        /* PMSTA-15017 - LJE - 120925 */
        CMP_DYNFLD(dynSt, testSt, 
                   A_PerfEffectDef_BreakCriteria, A_PerfEffectDef_BreakCriteria, IdType) == 0)
    {
        return (TRUE);
    }
    return (FALSE);
}

/************************************************************************
**
**  Function    :   FIN_SearchPerfEffectDef()
**
**  Description :   Search a perf effect definition by rank
**                 
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED
**
**  Creation D. : PMSTA08736 - LJE - 100603
**  Last modif. : 
** 
*************************************************************************/
RET_CODE FIN_SearchPerfEffectDef(DBA_HIER_HEAD_STP hierHead,
                                 SMALLINT_T        rank,
                                 DBA_DYNFLD_STP    rec, /* PMSTA-15017 - LJE - 120925 */
                                 DBA_DYNFLD_STP   *perfEffectDefStpPtr)
{
    RET_CODE       ret=RET_SUCCEED;
    DBA_DYNFLD_STP perfEffectDefStp, *perfEffectDefTab;
    int            perfEffectDefNbr;

    if (perfEffectDefStpPtr == NULL ||
        /* PMSTA-15017 - LJE - 120925 */
        rec == NULL ||
        GET_DYNSTENUM(rec) != A_PerfAttrib)
        return RET_GEN_ERR_INVARG;

    *perfEffectDefStpPtr = NULL;

    if ((perfEffectDefStp = ALLOC_DYNST(A_PerfEffectDef)) == NULL)
    {
        return RET_MEM_ERR_ALLOC;
    }

    SET_SMALLINT(perfEffectDefStp, A_PerfEffectDef_Rank, rank);
    /* PMSTA-15017 - LJE - 120925 */
    COPY_DYNFLD(perfEffectDefStp, A_PerfEffectDef, A_PerfEffectDef_BreakCriteria, 
                rec,              A_PerfAttrib,    A_PerfAttrib_BreakCriteria);

    if ((ret = DBA_HierEltRecExtract(hierHead, 
                                     A_PerfEffectDef,
                                     FALSE, 
                                     FIN_FilterPerfEffectDefByRank, 
                                     perfEffectDefStp,
                                     NULL,
                                     FALSE, 
                                     FALSE, 
                                     &perfEffectDefNbr,
                                     &perfEffectDefTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    if (perfEffectDefNbr == 1)
    {
        *perfEffectDefStpPtr = perfEffectDefTab[0];
    }

    FREE_DYNST(perfEffectDefStp, A_PerfEffectDef);
	FREE(perfEffectDefTab);

    return (ret);
}

/************************************************************************
*
*  Function          : FIN_GetDomainPerfFirstDate
*
*  Description       : Get Performance first operation date for given domain.
*
*  Arguments         : domain        : the domain to use
*                      perfFirstDate : returned perfFirstDate
*
*
*  Return            : RET_SUCCEED
*
*  Creation date     : PMSTA-50973 - DDV - 230921
*  Last modification : WEALTH-6158 - JBC - 20240330 Optimization
*
*
*************************************************************************/
RET_CODE FIN_GetDomainPerfFirstDate(DBA_DYNFLD_STP    aDomain,
                                    DATE_T &          perfFirstDate)
{
    DICT_T          dimEntityDictId = NullEntityCst;
    RET_CODE        ret = RET_SUCCEED;

    /* initialize inception date */
    perfFirstDate = 0;

    /* WEALTH-8562 - DDV - 240528 - Fix wrong condition */
    if (IS_NOTNULL(aDomain, A_Domain_DimEntityDictId))
    {
        dimEntityDictId = GET_DICT(aDomain, A_Domain_DimEntityDictId);
    }

    DICT_T  dimPtfDictId = GET_DICT(aDomain, A_Domain_DimPtfDictId);
    ID_T    ptfObjId = GET_ID(aDomain, A_Domain_PtfObjId);

    /* WEALTH-4451 - DDV - 240301 */
    if (dimEntityDictId == EmptyCst || dimEntityDictId == NullEntityCst)
    {
        if (dimPtfDictId == ListCst || 
            dimPtfDictId == QuickSearchCst)
        {
            dimEntityDictId = dimPtfDictId;
            dimPtfDictId = PtfCst;
        }
        else
        {
            dimEntityDictId = OneCst;
        }
    }

    if (ptfObjId == ZERO_ID && dimEntityDictId != QuickSearchCst)
    {
        return(RET_GEN_ERR_INVARG);
    }

    /* backup from date, using AAAValueGuard. Its value is restored automatically when exiting the function */
    AAAValueGuard < DBA_DYNFLD_ST > fromDateBck (aDomain[A_Domain_InterpFromDate]);

    SET_NULL_FLD(aDomain, A_Domain_InterpFromDate);

    DbiConnectionHelper dbiConnHelper;
    MemoryPool          mp;
    DBA_DYNFLD_STP      aPerfCompPeriod = mp.allocDynst(FILEINFO,A_PerfComputationPeriod);

    switch (dimEntityDictId)
    {
        case OneCst:
        case EmptyCst:
            switch (dimPtfDictId)
            {
                case PtfCst:
                    if (ptfObjId != 0)

                    ret = dbiConnHelper.dbaGet(Ptf, UNUSED, aDomain, &aPerfCompPeriod);
                    break;

                case ThirdCst:
                    ret = dbiConnHelper.dbaGet(Third, UNUSED, aDomain, &aPerfCompPeriod);
                    break;

                default:
                    break;
            }
            break;

        case ListCst:
        {
            FLAG_T       LoadDimPtfHistFlg = GET_FLAG(aDomain, A_Domain_LoadDimPtfHistFlg);

            if (LoadDimPtfHistFlg == TRUE)
            {                
                DBA_DYNFLD_STP  sListCompo = mp.allocDynst(FILEINFO, S_ListCompo);
                DBA_DYNFLD_STP  ioIdRec = mp.allocDynst(FILEINFO, Io_Id);

                /* check if list has historical list_compo */
                SET_ID(sListCompo, S_ListCompo_Id, ptfObjId);
	            if (dbiConnHelper.dbaGet(ListCompo, UNUSED, sListCompo,&ioIdRec) != RET_SUCCEED)
	            {
	                LoadDimPtfHistFlg = FALSE;
	            }
            }

            if (LoadDimPtfHistFlg == TRUE)
            {
                ret = dbiConnHelper.dbaGet(List, UNUSED, aDomain,&aPerfCompPeriod);
                break;
            }

            /* No break here. It is normal, when list is not historized, it is treated as actual list (same function than QSearch) */
        }

        case QuickSearchCst:

            if (ret == RET_SUCCEED)
            {                
                /* Optimization */
                DBA_DYNFLD_STP inceptDtArg = mp.allocDynst(FILEINFO,InceptDtArg);

                SET_DICT(inceptDtArg, InceptDtArg_DimEntityDictId, dimEntityDictId);
                SET_ID(inceptDtArg, InceptDtArg_DimPtfDictId, dimPtfDictId);
                SET_ID(inceptDtArg, InceptDtArg_PtfObjId, ptfObjId);
                SET_ENUM(inceptDtArg, InceptDtArg_LoadHierFlg,  GET_ENUM(aDomain, A_Domain_LoadHierFlg));
                SET_TEXT(inceptDtArg, InceptDtArg_PtfListDef,  GET_TEXT(aDomain, A_Domain_PtfListDef));

   	            if (DBA_GetMemory(OptiFct, UNUSED, InceptDtArg, inceptDtArg, A_PerfComputationPeriod, 
        			              aPerfCompPeriod, (DBA_DYNFLD_STP *) NULL, Opti_Local) == RET_SUCCEED)
	            {
	                break;
	            }

                if ((ret = DBA_FillDomPortByDomain(aDomain, false, true, dbiConnHelper)) == RET_SUCCEED)
                {
                    if ((ret = dbiConnHelper.dbaGet(Ptf, DBA_ROLE_USE_DOM_PORT, aDomain, &aPerfCompPeriod)) == RET_SUCCEED)
                    {
                        /* Set optimization */
                        DBA_SetMemory(OptiFct, UNUSED, InceptDtArg, inceptDtArg, A_PerfComputationPeriod, aPerfCompPeriod, Opti_Local);
                    }

                    DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); 
                }
            }

            break;
        default:
            break;
    }

    if (ret == RET_SUCCEED)
    {
        DATETIME_T perfFirstDatetime = GET_DATETIME(aPerfCompPeriod, A_PerfComputationPeriod_BeginDate);
        perfFirstDate = perfFirstDatetime.date;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_IsContribMethod()
**
**  Description :   Return TRUE if PerfCalcDefReturnMethodEn given as 
**                  parameter is a contibution method
**
**
**  Arguments   :   input:
**                  PerfCalcDefReturnMethodEn returnMethodEn
**
**                  output: 
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-2417 - DDV - 231004
**
*************************************************************************/
EXTERN FLAG_T FIN_IsContribMethod(PerfCalcDefReturnMethodEn     returnMethodEn)
{
    switch (returnMethodEn)
    {
        case PerfCalcDefReturnMethodEn::TWR:
        case PerfCalcDefReturnMethodEn::MglTWR:
        case PerfCalcDefReturnMethodEn::MMWR:
        case PerfCalcDefReturnMethodEn::MWR:
        case PerfCalcDefReturnMethodEn::YMWR:
        case PerfCalcDefReturnMethodEn::MIRR:
        case PerfCalcDefReturnMethodEn::IRR:
            return(FALSE);
            break;

        case PerfCalcDefReturnMethodEn::MMWRc:
        case PerfCalcDefReturnMethodEn::MWRc:
        case PerfCalcDefReturnMethodEn::YMWRc:
        case PerfCalcDefReturnMethodEn::TWRc:    /* Without PtfSynth Merge */
        case PerfCalcDefReturnMethodEn::MglTWRc: /* Without PtfSynth Merge */
            return(TRUE);
                break;

        default:
            SYS_BreakOnDebug();
            return(FALSE);
            break;
    }
}

/************************************************************************
**
**  Function    :   FIN_IsContribMethodBeforePtfSynthMerge()
**
**  Description :   Return TRUE if PerfCalcDefReturnMethodEn given as
**                  parameter is a contibution method that must be computed
**                  before merge of PtfSynth
**
**
**  Arguments   :   input:
**                  PerfCalcDefReturnMethodEn returnMethodEn
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-5121 - DDV - 240219
**
*************************************************************************/
FLAG_T FIN_IsContribMethodBeforePtfSynthMerge(PerfCalcDefReturnMethodEn     returnMethodEn)
{
    switch (returnMethodEn)
    {
    case PerfCalcDefReturnMethodEn::TWR:
    case PerfCalcDefReturnMethodEn::MglTWR:
    case PerfCalcDefReturnMethodEn::MMWR:
    case PerfCalcDefReturnMethodEn::MWR:
    case PerfCalcDefReturnMethodEn::YMWR:
    case PerfCalcDefReturnMethodEn::MIRR:
    case PerfCalcDefReturnMethodEn::IRR:
    case PerfCalcDefReturnMethodEn::MMWRc:
    case PerfCalcDefReturnMethodEn::MWRc:
    case PerfCalcDefReturnMethodEn::YMWRc:
        return(FALSE);
        break;

    case PerfCalcDefReturnMethodEn::TWRc:    /* Without PtfSynth Merge */
    case PerfCalcDefReturnMethodEn::MglTWRc: /* Without PtfSynth Merge */
        return(TRUE);
        break;

    default:
        SYS_BreakOnDebug();
        return(FALSE);
        break;
    }
}

/************************************************************************
**
**  Function    :   FIN_IsGlobalOpMethod()
**
**  Description :   Return TRUE if PerfCalcDefReturnMethodEn given as
**                  parameter is a method that need only global Op date (mglTWR(c) and mMWR(c))
**
**
**  Arguments   :   input:
**                  PerfCalcDefReturnMethodEn returnMethodEn
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-3330 - DDV - 240308
**
*************************************************************************/
FLAG_T FIN_IsGlobalOpMethod(PerfCalcDefReturnMethodEn     returnMethodEn)
{
    switch (returnMethodEn)
    {
    case PerfCalcDefReturnMethodEn::TWR:
    case PerfCalcDefReturnMethodEn::MWR:
    case PerfCalcDefReturnMethodEn::YMWR:
    case PerfCalcDefReturnMethodEn::MIRR:
    case PerfCalcDefReturnMethodEn::IRR:
    case PerfCalcDefReturnMethodEn::MWRc:
    case PerfCalcDefReturnMethodEn::YMWRc:
    case PerfCalcDefReturnMethodEn::TWRc:    /* Without PtfSynth Merge */
        return(FALSE);
        break;

    case PerfCalcDefReturnMethodEn::MglTWR:
    case PerfCalcDefReturnMethodEn::MglTWRc: /* Without PtfSynth Merge */
    case PerfCalcDefReturnMethodEn::MMWR:
    case PerfCalcDefReturnMethodEn::MMWRc:
        return(TRUE);
        break;

    default:
        SYS_BreakOnDebug();
        return(FALSE);
        break;
    }
}

/************************************************************************
 **   END  finperfa2.c
 *************************************************************************/

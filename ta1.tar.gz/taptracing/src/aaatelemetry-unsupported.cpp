/************************************************************************
**
**           Copyright (C) 1995-2022 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "aaatelemetry.h"
#include "aaalogger.h"

#include <log4cplus/spi/factory.h>

class AAATracerImpl
{
public:
};

class AAASpanImpl {
public:

};

class AAATracerInitializerImpl {
public:

};
// ------------------AAATracer

//static

AAATracer AAATelemetry::GetTracer(AAATracer::TraceName::Value)
{
    static std::shared_ptr<AAATracerImpl> nullImpl = nullptr;
    static AAATracer nullTracer(nullImpl);

    return nullTracer;
}


std::shared_ptr<AAAMeter> AAATelemetry::GetMeter(AAAMeter::MeterName::Value)
{
    static std::shared_ptr<AAAMeter>nullMeter = std::shared_ptr<AAAMeter>(new AAAMeter(AAAMeter::MeterName::Value::Null));
    return  nullMeter;
}

AAATracer::AAATracer(std::shared_ptr<AAATracerImpl>&)
{

}

AAATracer::AAATracer(const AAATracer& rhs)
{
    mTracerImpl = rhs.mTracerImpl;
}

std::string AAATracer::TraceName::to_string(void) const
{
    return "";
}


bool AAATracer::TraceName::isActive() const
{
   return false;
}

AAATracer::AAASpan AAATracer::startNewSpan(const std::string& )
{
    static AAASpan nullSpan;

    return nullSpan;
}

AAATracer::TraceName AAATracer::getTraceByName(const std::string& )
{
    static TraceName nullTrace;
    return  nullTrace;
}

void AAATracer::setTraceActiveByName(const std::string& , bool )
{

}

void AAATracer::getAllTraces(std::vector<AAATracer::TraceName>& )
{

}

bool AAATracer::isEnabled() const
{
    return false;
}

void AAATracer::setEnable(bool)
{
}

void AAATracer::SetEnableAll(bool)
{
}

void AAATracer::SetGloballyEnabled(bool)
{
}
bool AAATracer::IsGloballyEnabled()
{
    return false;
}

AAATracer::AAASpan AAATracer::getActiveSpan()
{
    static AAASpan nullSpan;

    return nullSpan;
}

AAATracer::AAASpan AAATracer::continueSpanFrom(const std::string& , const std::string&, AAATracer::LinkNature)
{
    static AAASpan nullSpan;

    return nullSpan;
}

AAATracer::AAASpan AAATracer::continueSpanFrom(const std::string&, std::unordered_map<std::string, std::string >&, AAATracer::LinkNature)
{
    static AAASpan nullSpan;

    return nullSpan;
}

// ------------------AAATelemetry

std::string AAATelemetry::sv_ServiceNameConfigured;
std::string AAATelemetry::TwacTelemetryProperties::twacInstance;
std::string AAATelemetry::TwacTelemetryProperties::twacType;
std::string AAATelemetry::TwacTelemetryProperties::twacZone;
std::chrono::milliseconds AAATelemetry::TwacTelemetryProperties::exportInterval;

void AAATelemetry::init(bool )
{
}

void AAATelemetry::configure( std::initializer_list<StringPair> )
{
}


bool  AAATelemetry::isStarted()
{
    return false;
}

bool  AAATelemetry::isStartRequested()
{
    return false;
}

void AAATelemetry::terminate()
{
}

void AAATelemetry::addTWACattributes(std::map<std::string, std::string> , const std::string& , const std::string& )
{
}

void AAATelemetry::setTwacStarted(const bool)
{
}

void AAATelemetry::enableMetrics()
{
}

void AAATelemetry::disableMetrics()
{
}

// ------------------AAATracer::AAASpan

AAATracer::AAASpan& AAATracer::AAASpan::log(const std::string& , const std::string& )
{
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::updateOperationName(const std::string& )
{
    return *this;
}
AAATracer::AAASpan& AAATracer::AAASpan::setTagb(const std::string&, bool )
{
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string&, const std::string& )
{
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string&, char const*)
{
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string&, int64_t)
{
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::addEvent(const std::string&, const std::map<std::string, std::string>&)
{
    return *this;
}

std::string AAATracer::AAASpan::getTracePropagation()
{
    return "";
}

std::string AAATracer::AAASpan::getTraceId()
{
    return "";
}

void AAATracer::AAASpan::finish()
{

}
AAATracer::AAASpan::AAASpan()
{
    m_impl = nullptr;
}

AAATracer::AAASpan::AAASpan(std::shared_ptr<AAASpanImpl> )
{
    m_impl = nullptr;
}

AAATracer::AAASpan::AAASpan(const AAASpan& )
{
    m_impl = nullptr;

}

AAATracer::AAASpan& AAATracer::AAASpan::operator=(const AAASpan&)
{
    m_impl = nullptr;
    return *this;
}

AAATracer::AAASpan::~AAASpan()
{
    m_impl = nullptr;
}



// ------------------AAATracer::Initializer

AAATelemetry::Initializer::Initializer(bool) 
{
    mTelemetryInitializerImpl = nullptr;

    // Register the dummy appender to avoid to have 2 configuration log4cplus.properties file

    log4cplus::spi::AppenderFactoryRegistry& regAppender = log4cplus::spi::getAppenderFactoryRegistry();
    LOG4CPLUS_REG_PRODUCT(regAppender, "TripleA::", AAATelemetryAppender, ::, log4cplus::spi::AppenderFactory);

}

AAATelemetry::Initializer::~Initializer() {
    mTelemetryInitializerImpl = nullptr;
}

void AAATelemetry::Initializer::configure(std::initializer_list<std::pair<std::string, std::string>>)
{
}

class AAATelemetryInitializerImpl {
public:
    AAATelemetryInitializerImpl() =default;
    ~AAATelemetryInitializerImpl() =default;
private:
};


std::shared_ptr<AAACounterMeterI> AAAMeter::registerCounterMeter(const std::string& , const std::string& , const std::string& )
{
    static std::shared_ptr<AAACounterMeterI> nullCounter = std::make_shared<AAANullCounterMeter>();

    return  nullCounter;
}

std::shared_ptr<AAACounterMeterI> AAAMeter::getCounterMeter(const std::string& ) {
    static std::shared_ptr<AAACounterMeterI> nullCounter = std::make_shared<AAANullCounterMeter>();

    return  nullCounter;
};

std::string AAAMeter::buildTemnMetricName(const std::string )
{
    static std::string  nullString;
    return nullString;
}

std::shared_ptr<AAAHistogramMeterI> AAAMeter::registerHistogramMeter(const std::string&, const std::string&, const std::string&)
{
    static std::shared_ptr<AAAHistogramMeterI> nullHisto = std::make_shared<AAANullHistogramMeter>();
    return  nullHisto;
}


std::shared_ptr<AAAHistogramMeterI> AAAMeter::getHistogramMeter(const std::string & ) {
        static std::shared_ptr<AAAHistogramMeterI> nullHisto = std::make_shared<AAANullHistogramMeter>();
        return  nullHisto;
};

AAAPointMeterAggregator::AAAPointMeterAggregator(AAAMeter::MeterName::Value , const std::string& ) : m_parent(nullptr), m_name(), m_count(0), m_mean(0), /*m_stddev(0), */ m_sum(0), m_mean2(0), m_min(0), m_max(0)
{
};
void AAAPointMeterAggregator::recordPoint(int64_t)
{
}


std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::GetAggregator(AAAMeter::MeterName::Value, const std::string& )
{
    static std::shared_ptr<AAAPointMeterAggregator> nullPMA = std::shared_ptr<AAAPointMeterAggregator>(nullptr);

    return  nullPMA;
}

void AAAPointMeterThreadRegistery::UnRegisterAllPointMeterAggregator()
{
}


std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::RegisterPointMeterAggregator(const std::shared_ptr<AAAPointMeterAggregator>& ,  const std::string& )
{
    static std::shared_ptr<AAAPointMeterAggregator> nullPMA = std::shared_ptr<AAAPointMeterAggregator>(nullptr);

    return  nullPMA;
}

std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::RegisterPointMeterAggregator(AAAMeter::MeterName::Value, const std::string&)
{
    static std::shared_ptr<AAAPointMeterAggregator> nullPMA = std::shared_ptr<AAAPointMeterAggregator>(nullptr);

    return  nullPMA;
}


void AAAPointMeterThreadRegistery::ReportAllDeclaredMeterAggregator(bool unregister)
{
}


/************************************************************************
*   Class              : AAATelemetryAppender
*
*   Description        : See the 2 implementations in triplea_core\taptracing\src\
*
*************************************************************************/

AAATelemetryAppender::AAATelemetryAppender(const log4cplus::helpers::Properties& properties)
    : Appender(properties), otelProxy_(nullptr)
{
}

void AAATelemetryAppender::append(const log4cplus::spi::InternalLoggingEvent& event)
{
    // DO Nothing
}

void AAATelemetryAppender::OTELProxyDeleter::operator()(OTELProxy* )
{
    // no definition of OTELProxy; nothing to delete
};

/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

#include "syslib.h"
#include <math.h>

// http://rd.temenosgroup.com/browse/PMSTA-43137

// see https://opentelemetry-cpp.readthedocs.io/en/latest/api/GettingStarted.html
// from https://opentelemetry.io/docs/cpp/


#include "opentelemetry/context/context.h"
#include "opentelemetry/context/propagation/text_map_propagator.h"
#include "opentelemetry/context/propagation/global_propagator.h"
#include "opentelemetry/context/runtime_context.h"



#include "opentelemetry/ext/http/client/http_client.h"

#include "opentelemetry/metrics/provider.h"


#include "opentelemetry/sdk/metrics/meter_context.h"
#include "opentelemetry/sdk/metrics/meter_context_factory.h"
#include "opentelemetry/sdk/metrics/meter_provider_factory.h"
#include "opentelemetry/sdk/metrics/export/metric_producer.h"
#include "opentelemetry/sdk/metrics/export/periodic_exporting_metric_reader.h"
#include "opentelemetry/sdk/metrics/export/periodic_exporting_metric_reader_factory.h"
#include "opentelemetry/sdk/metrics/export/periodic_exporting_metric_reader_options.h"
#include "opentelemetry/sdk/metrics/metric_reader.h"
#include "opentelemetry/sdk/metrics/push_metric_exporter.h"


#include "opentelemetry/exporters/otlp/otlp_environment.h"
#include "opentelemetry/exporters/otlp/otlp_http.h"
#include "opentelemetry/exporters/otlp/otlp_http_exporter_factory.h"
#include "opentelemetry/exporters/otlp/otlp_http_exporter_options.h"
#include "opentelemetry/exporters/otlp/otlp_http_log_record_exporter_factory.h"
#include "opentelemetry/exporters/otlp/otlp_http_log_record_exporter_options.h"
#include "opentelemetry/exporters/otlp/otlp_http_metric_exporter_factory.h"
#include "opentelemetry/exporters/otlp/otlp_http_metric_exporter_options.h"

#include "opentelemetry/exporters/ostream/log_record_exporter.h"
#include "opentelemetry/exporters/ostream/log_record_exporter_factory.h"
#include "opentelemetry/exporters/ostream/metric_exporter_factory.h"
#include "opentelemetry/exporters/ostream/metric_exporter.h"
#include "opentelemetry/exporters/ostream/span_exporter.h"
#include "opentelemetry/exporters/ostream/span_exporter_factory.h"


#include "opentelemetry/logs/log_record.h"
#include "opentelemetry/logs/logger_provider.h"
#include "opentelemetry/logs/provider.h"
#include "opentelemetry/sdk/common/global_log_handler.h"
#include "opentelemetry/sdk/logs/logger_provider.h"
#include "opentelemetry/sdk/logs/logger_provider_factory.h"
#include "opentelemetry/sdk/logs/recordable.h"
#include "opentelemetry/sdk/logs/simple_log_record_processor_factory.h"
#include "opentelemetry/sdk/trace/batch_span_processor_options.h"
#include "opentelemetry/sdk/trace/batch_span_processor.h"
#include "opentelemetry/sdk/trace/processor.h"
#include "opentelemetry/sdk/trace/recordable.h"
#include "opentelemetry/sdk/trace/simple_processor.h"
#include "opentelemetry/sdk/trace/simple_processor_factory.h"
#include "opentelemetry/sdk/trace/tracer_provider.h"
#include "opentelemetry/sdk/trace/tracer_provider_factory.h"

#include "opentelemetry/sdk/version/version.h"

#include "opentelemetry/trace/context.h"
#include "opentelemetry/trace/provider.h"
#include "opentelemetry/trace/propagation/http_trace_context.h"
#include "opentelemetry/trace/span_context.h"
#include "opentelemetry/trace/provider.h"
#include "opentelemetry/trace/span_id.h"
#include "opentelemetry/trace/tracer_provider.h"




#include "tls.h"
#include <algorithm>

#include "aaatelemetry.h"
#include "aaalogger.h"
#include <log4cplus/spi/loggingevent.h>
#include <log4cplus/spi/factory.h>

#include "sigar4aaa.h"


using ThreadLocalSpanMap = std::map<AAATracerImpl*, std::vector<std::shared_ptr<AAASpanImpl>>>;

thread_local ThreadLocalSpanMap sv_thread_local_span_map;

static const char carrier_line_delimiter = ';'; // '\n';
static const char carrier_KV_delimiter = '=';


class AAATelemetryImpl
{

public:

  static std::map<std::string, std::string> GetDefaultTags();

  static void Merge(std::map<std::string, std::string>& fromEnvironmentVariable, std::map<std::string, std::string> tags);
  
  static opentelemetry::sdk::resource::ResourceAttributes Convert(std::map<std::string, std::string> tags);

  static void Init_Telemetry_InternalLogger(bool debugConfiguration, bool startTelemetry);
  static void ConfigureAndSetTheLoggerProviderWithExporter(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes ra);
  static void addResourceAttributes(std::map<std::string, std::string> attributes);
};

class AAATracerImpl
{
public:
    static AAATracer get(AAATracer::TraceName::Value forTrace);

    static void init(bool startTracer);
    static void configure(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes ra);
    static void addResourceAttributes(std::map<std::string, std::string> attributes);

    static void terminate();

    static std::shared_ptr<AAASpanImpl>&  getNoopSpan();


    AAATracer::AAASpan startSpan(const std::string& withName);

    AAATracer::AAASpan continueSpanFrom(const std::string& withName, const std::string& fromTraceID, AAATracer::LinkNature linkNature);
    AAATracer::AAASpan continueSpanFrom(const std::string& operationName, std::unordered_map<std::string, std::string >& externalRepresentation, AAATracer::LinkNature linkNature);


    std::shared_ptr<AAASpanImpl>& getActiveSpan();


    ~AAATracerImpl();

    AAATracerImpl(const std::string& name);

    static AAATracer::TraceName getTrace(AAATracer::TraceName::Value);
    static AAATracer::TraceName getTraceByName(const std::string&);
    static void setTraceActiveByName(const std::string&, bool to);

    static void getAllTraces(std::vector<AAATracer::TraceName> & );
    
    static void SetEnableAll(bool to);
    static bool IsGloballyEnabled();
    static void SetGloballyEnabled(bool);

    bool isEnabled() const;
    void setEnable(bool to);

private:
    void pushActiveSpan(std::shared_ptr<AAASpanImpl>& span);
    bool popActiveSpan();
    static void initializeAllTraces();

    friend class AAATracer::TraceName;
    static AAATracer getLazyConstructor(AAATracer::TraceName::Value forTrace);


private:

    friend class AAASpanImpl;

    std::shared_ptr<AAASpanImpl> createSpanImpl();



private:// static Attributes

    std::set<std::shared_ptr<AAASpanImpl>>    m_allSpan;

    using TraceMapType = std::map<std::string, AAATracer::TraceName>;

    static TraceMapType  sv_allTraces;

    static bool sv_globallyEnabled;
    static  AAATracer::TraceName sv_nullTrace;

    static std::map<AAATracer::TraceName, std::shared_ptr<AAATracerImpl>> sv_AAATracerImpl;
    static std::shared_ptr<AAASpanImpl> sv_noopspan;

    static bool sv_startTracerClient;

private: // Attributes

    bool m_isEnabled;
    bool m_debugTraceActive;
    std::string m_name;
    opentelemetry::nostd::shared_ptr<opentelemetry::trace::Tracer> m_OpenTracerImpl;

};

class AAASpanImpl {
public:

    AAASpanImpl(const AAASpanImpl&) = delete;
    AAASpanImpl& operator=(const AAASpanImpl&) = delete;
    ~AAASpanImpl();

    AAASpanImpl& startSpan(const std::string& operationName);
    AAASpanImpl& continueSpanFrom(const std::string& operationName, const std::string& fromTraceID, AAATracer::LinkNature linkNature);
    AAASpanImpl& continueSpanFrom(const std::string& operationName, std::unordered_map<std::string, std::string >& externalRepresentation, AAATracer::LinkNature linkNature);

    AAASpanImpl& log(const std::string& key, const std::string& value);
    AAASpanImpl& setOperationName(const std::string&);
    AAASpanImpl& setTagb(const std::string&, bool);
    AAASpanImpl& setTag(const std::string&, const std::string&);
    AAASpanImpl& addEvent(const std::string&, const std::map<std::string, std::string>&);


    std::string getTracePropagation();
    std::string getTraceId();

    void finish();

    bool isEnabled() const;
    void setEnabled(bool to);

    using LinkReferenceType = std::pair<opentelemetry::trace::SpanContext, std::map<std::string, std::string>>;
    using LinkReferenceVectorType = std::vector<LinkReferenceType>;

private:
 
    void _startSpanAndActivateWithLink(const std::string& operationName, 
                                       const opentelemetry::trace::SpanContextKeyValueIterable& links,
                                       const opentelemetry::v1::trace::StartSpanOptions& options);
    void _startSpanAndActivate(const std::string& operationName,
                               const opentelemetry::trace::StartSpanOptions& options);

    void startLinkedSpanAndActivate(const std::string& operationName, const opentelemetry::trace::SpanContext& linkedSpanContext, AAATracer::LinkNature linkNature);

    void _verifyRuntimeContextValid();

private:
    friend AAATracerImpl;

    AAASpanImpl();
    AAASpanImpl(AAATracerImpl * creator);


private:
    AAATracerImpl* m_creator;
    bool m_enabled;

    opentelemetry::nostd::shared_ptr<opentelemetry::trace::Span> m_spanimpl;
    opentelemetry::nostd::unique_ptr<opentelemetry::context::Token> m_contextToken;

};



template <typename T>
class HttpTextMapCarrier : public opentelemetry::context::propagation::TextMapCarrier
{
public:
    HttpTextMapCarrier<T>(T &headers) : 
        headers_(headers)
    {
    }
    HttpTextMapCarrier() = default;
    virtual  opentelemetry::nostd::string_view Get(opentelemetry::nostd::string_view key) const noexcept override
    {
        std::string key_to_compare = key.data();
        auto it = headers_.find(key_to_compare);
        if (it != headers_.end())
        {
            return it->second;
        }
        return "";
    }

    virtual void Set(opentelemetry::nostd::string_view key, opentelemetry::nostd::string_view value) noexcept override
    {
        headers_.insert(std::pair<std::string, std::string>(std::string(key), std::string(value)));
    }

    void saveguds(std::ostream& oss) const
    {
        auto it = headers_.cbegin();
        bool firstLine = true;
        while (it != headers_.cend())
        {
            if (firstLine == false)
            {
                oss << carrier_line_delimiter;
            }
            else 
            {
                firstLine = false;
            }
            oss << it->first << carrier_KV_delimiter << it->second;
            it++;
        }
    }

    void restoreguds(std::istream& iss)
    {
        std::string line;

        while (std::getline(iss, line, carrier_line_delimiter))
        {
            std::istringstream is_line(line);
            std::string key;
            if (std::getline(is_line, key, carrier_KV_delimiter))
            {
                std::string value;

                if (std::getline(is_line, value))
                {
                    Set(key, value);
                }
            }
        }
    }
private:
    T headers_;

};

class AAA2internalOTELlogHandler : public opentelemetry::sdk::common::internal_log::LogHandler
{
public:
    void Handle(opentelemetry::sdk::common::internal_log::LogLevel level,
        const char* file,
        int line,
        const char* msg,
        const opentelemetry::sdk::common::AttributeMap&) noexcept override
    {
        AAALogger::Level _level (AAALogger::Level::Value::Trace);
        switch (level)
        {
        case opentelemetry::v1::sdk::common::internal_log::LogLevel::Error:
            ++errorCount;
            _level = AAALogger::Level::Value::Error;
            break;
        case opentelemetry::v1::sdk::common::internal_log::LogLevel::Warning:
            ++warningCount;
            _level = AAALogger::Level::Value::Warn;
            break;
        case opentelemetry::v1::sdk::common::internal_log::LogLevel::Info:
            ++infoCount;
            _level = AAALogger::Level::Value::Info;
            break;
        case opentelemetry::v1::sdk::common::internal_log::LogLevel::Debug:
            ++debugCount;
            _level = AAALogger::Level::Value::Debug;
            break;
        default:
            _level = AAALogger::Level::Value::Fatal;
            SYS_BreakOnDebug();
            break;
        }


        if (m_captureInternalBuffer)
        {
            if (msg != nullptr)
            {
                m_oss << msg << " ; ";
            }
        }
        else
        {
            std::string output_s;
            if (msg != nullptr)
            {
                output_s+=msg;
            }
            startCapture(); // To avoid recursion in case of error with the OTEL appender
            AAALogger::get(AAALogger::Logger::OTEL).prepare(_level, output_s)->log(file, line);
            stopCapture();
        }
    }

    void startCapture()
    {
        m_captureInternalBuffer = true;
        m_oss.clear();
    }

    void stopCapture()
    {
        m_captureInternalBuffer = false;
        m_oss.clear();
    }
    size_t debugCount = 0;
    size_t errorCount = 0;
    size_t infoCount = 0;
    size_t warningCount = 0;
    bool m_captureInternalBuffer = false;
    std::ostringstream m_oss;
};


// ------------------AAAMeterFactory::

class AAAMeterFactory
{
public:
    static  std::shared_ptr<AAAMeter> GetMeter(AAAMeter::MeterName::Value forMeter);

    static std::map<AAAMeter::MeterName::Value, std::shared_ptr<AAAMeter>> sv_AllMeters;

    static void configure(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes resAttributes);
    static void addResourceAttributes(std::map<std::string, std::string> attributes);

    static void terminate();
    /* WEALTH-18208 - 020225 - vivek - enable and disable metrics at runtime based on TWAC properties */
    static void enableMetrics();
    static void disableMetrics();


    static std::shared_ptr<AAAMeter> sv_NullMeter;
    static bool sv_started;
    static opentelemetry::nostd::shared_ptr<opentelemetry::metrics::MeterProvider> sv_noop_provider;
    /* WEALTH-18208 - 020225 - vivek - save metric reader for explicit shutdown during disable */
    static std::shared_ptr<opentelemetry::sdk::metrics::MetricReader> sv_MetricReader;                        

};
std::map < AAAMeter::MeterName::Value, std::shared_ptr<AAAMeter>> AAAMeterFactory::sv_AllMeters;
std::shared_ptr<opentelemetry::sdk::metrics::MetricReader> AAAMeterFactory::sv_MetricReader = nullptr;

bool AAAMeterFactory::sv_started = false;

std::shared_ptr<AAAMeter> AAAMeterFactory::sv_NullMeter = std::shared_ptr<AAAMeter>(new AAAMeter(AAAMeter::MeterName::Value::Null));

opentelemetry::nostd::shared_ptr<opentelemetry::metrics::MeterProvider> AAAMeterFactory::sv_noop_provider(new opentelemetry::metrics::NoopMeterProvider);

void AAAMeterFactory::configure(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes resAttributes)
{
    sv_started = true;
    sv_NullMeter->m_otel_impl = sv_noop_provider->GetMeter("dummy");

    // OTLP via HTTP Metric

    opentelemetry::exporter::otlp::OtlpHttpMetricExporterOptions exporter_options;

    if (SYS_GetEnvBoolOrDefValue("AAA_OTEL_EXPORTER_OTLP_METRICS_AGGREGATION_DELTA", false))
    {
        exporter_options.aggregation_temporality = opentelemetry::exporter::otlp::PreferredAggregationTemporality::kDelta;
    }
    auto _httpPushMetricExporter = opentelemetry::exporter::otlp::OtlpHttpMetricExporterFactory::Create(exporter_options);

    // Initialize and set the global MeterProvider
    opentelemetry::sdk::metrics::PeriodicExportingMetricReaderOptions _reader_options;

    // Default 60 sec loose some vaues if ForceFlush not called -- see AAAMeterFactory::terminate()
    //_reader_options.export_interval_millis = std::chrono::milliseconds(1000);
    //_reader_options.export_timeout_millis = std::chrono::milliseconds(500);

    _reader_options.export_timeout_millis = AAATelemetry::TwacTelemetryProperties::exportInterval;

    auto _PeriodicHttpExporterMetricReader = opentelemetry::sdk::metrics::PeriodicExportingMetricReaderFactory::Create(std::move(_httpPushMetricExporter), _reader_options);
    sv_MetricReader = std::shared_ptr<opentelemetry::sdk::metrics::MetricReader>(std::move(_PeriodicHttpExporterMetricReader));

    auto meterResource = opentelemetry::sdk::resource::Resource::Create(resAttributes);
    auto dummyView = std::unique_ptr <opentelemetry::sdk::metrics::ViewRegistry> (new opentelemetry::sdk::metrics::ViewRegistry());

    auto context = opentelemetry::sdk::metrics::MeterContextFactory::Create(std::move(dummyView), meterResource);
    context->AddMetricReader(sv_MetricReader);


    if (debugConfiguration)
    {
        // STDOUT Metric Exporter

        auto _ostreamExporter = opentelemetry::exporter::metrics::OStreamMetricExporterFactory::Create();

        opentelemetry::sdk::metrics::PeriodicExportingMetricReaderOptions _osMeOptions;
        _osMeOptions.export_interval_millis = std::chrono::milliseconds(1000);
        _osMeOptions.export_timeout_millis = std::chrono::milliseconds(500);

        auto _PeriodicOstreamExporterMetricReader = opentelemetry::sdk::metrics::PeriodicExportingMetricReaderFactory::Create(std::move(_ostreamExporter), _osMeOptions);

        context->AddMetricReader(std::move(_PeriodicOstreamExporterMetricReader));
    }

    auto uniq_provider = opentelemetry::sdk::metrics::MeterProviderFactory::Create(std::move(context));
    std::shared_ptr<opentelemetry::metrics::MeterProvider> shared_provider(std::move(uniq_provider));

    opentelemetry::metrics::Provider::SetMeterProvider(shared_provider);
}
void  AAAMeterFactory::addResourceAttributes(std::map<std::string, std::string> attributes)
{
    auto meterProvider = opentelemetry::metrics::Provider::GetMeterProvider();
    if (meterProvider.get() != nullptr)
    {
        auto* sdk_meterProvider = dynamic_cast<opentelemetry::sdk::metrics::MeterProvider*> (meterProvider.get());
        if (sdk_meterProvider) {
            auto _ra = AAATelemetryImpl::Convert(attributes);
            auto other = opentelemetry::sdk::resource::Resource::Create(_ra);
            auto merged = sdk_meterProvider->GetResource().Merge(other);
            // @@ TODO How to set them ? sdk_meterProvider->SetResource(merged);
        }
    }
}

void AAAMeterFactory::terminate()
{
    sv_started = false;
    std::shared_ptr<opentelemetry::metrics::MeterProvider> none;
    auto meterProvider = opentelemetry::metrics::Provider::GetMeterProvider();
    if (meterProvider.get() != nullptr)
    {
        auto* sdk_meterProvider = dynamic_cast<opentelemetry::sdk::metrics::MeterProvider *> (meterProvider.get());
        if (sdk_meterProvider) {
            auto timeout = std::chrono::microseconds(1000000);// 1 sec for now @@TODO do we need it configurable depending on the executable ?
            sdk_meterProvider->ForceFlush(timeout);
        }
    }
    opentelemetry::metrics::Provider::SetMeterProvider(none);
}

std::shared_ptr<AAAMeter> AAAMeterFactory::GetMeter(AAAMeter::MeterName::Value forMeter)
{
    if (sv_started)
    {
        auto meterItr = sv_AllMeters.find(forMeter);

        if (meterItr != sv_AllMeters.end())
        {
            return meterItr->second;
        }
        else {
            auto impl = std::shared_ptr<AAAMeter>(new AAAMeter(forMeter));

            auto meterName = AAAMeter::MeterName::GetMeterName(forMeter);

            opentelemetry::nostd::shared_ptr<opentelemetry::metrics::Meter> meter = opentelemetry::metrics::Provider::GetMeterProvider()->GetMeter(meterName);
            impl->m_otel_impl = meter;
            sv_AllMeters.emplace(std::make_pair(forMeter, impl));


            return impl;

        }
    }
    else
    {
        static bool inited = false;
        if (inited == false)
        {
            sv_NullMeter->m_otel_impl = sv_noop_provider->GetMeter("dummy");
            inited = true;
        }
        return sv_NullMeter;
    }

}

/************************************************************************
**
**  Method      :  AAAMeterFactory::disableMetrics
**
**  Description :  disable Metrics collection and propogation
**
**  MOdif.      :  WEALTH-18208 - 020225 - vivek
*************************************************************************/
void AAAMeterFactory::disableMetrics()
{
    if (sv_started)
    {
        auto timeout = std::chrono::microseconds(1000000);
        sv_MetricReader->ForceFlush(timeout);
        sv_MetricReader->Shutdown();
        sv_MetricReader.reset();

        terminate();
        sv_AllMeters.clear();
    }
}

/************************************************************************
**
**  Method      :  AAAMeterFactory::enableMetrics
**
**  Description :  enable Metrics collection and propogation
**
**  MOdif.      :  WEALTH-18208 - 020225 - vivek
*************************************************************************/
void AAAMeterFactory::enableMetrics()
{
    if (!sv_started)
    {
        std::map<std::string, std::string> twacAttributes = { AAATelemetry::StringPair("twac.instance", AAATelemetry::TwacTelemetryProperties::twacInstance),
                                                              AAATelemetry::StringPair("twac.type", AAATelemetry::TwacTelemetryProperties::twacType),
                                                              AAATelemetry::StringPair("twac.zone", AAATelemetry::TwacTelemetryProperties::twacZone) };
        auto tagsList = AAATelemetryImpl::GetDefaultTags();

        /* getting final list of attributes to be set for resource */
        AAATelemetryImpl::Merge(twacAttributes, tagsList);

        auto _ra = AAATelemetryImpl::Convert(twacAttributes);
        bool debugConfiguration = (_ra.find("debug") != _ra.end()) && ((opentelemetry::nostd::get<std::string>(_ra.find("debug")->second).compare("true") == 0));
        configure(debugConfiguration, _ra);
    }
}


// ------------------AAATelemetry::
const char* AAATelemetry::sv_GlobalPrefix = "Temn";

std::string AAATelemetry::sv_ServiceNameConfigured;

bool  AAATelemetry::sv_TelemetryStartRequested = false;
bool  AAATelemetry::sv_TelemetryStarted = false;
bool AAATelemetry::sv_TwacStarted = false;
std::string AAATelemetry::TwacTelemetryProperties::twacInstance;
std::string AAATelemetry::TwacTelemetryProperties::twacType;
std::string AAATelemetry::TwacTelemetryProperties::twacZone;
std::chrono::milliseconds AAATelemetry::TwacTelemetryProperties::exportInterval = std::chrono::milliseconds(60000);    /* default interval as per opentelemetry */


AAATracer AAATelemetry::GetTracer(AAATracer::TraceName::Value forTrace)
{
    return  AAATracerImpl::get(forTrace);
}

std::shared_ptr<AAAMeter> AAATelemetry::GetMeter(AAAMeter::MeterName::Value forMeter)
{
    return AAAMeterFactory::GetMeter(forMeter);
}

void AAATelemetry::init(bool startByDefault)
{
    
    // See OTELResourceDetector::Detect() looks like OTEL_SERVICE_NAME not implemented
    std::string resourceAttibutes = SYS_GetEnvStringOrDefValue("OTEL_RESOURCE_ATTRIBUTES");

    if (resourceAttibutes.find("service.name") == std::string::npos) // opentelemetry::sdk::resource::SemanticConventions::kServiceName
    {
        if (resourceAttibutes.length() > 0) {
            resourceAttibutes.append(",");
        }
        resourceAttibutes.append("service.name=" ).append(GEN_GetProgramName());
        SYS_PutEnv("OTEL_RESOURCE_ATTRIBUTES", resourceAttibutes.c_str());
    }
    
    bool startTracer = SYS_GetEnvBoolOrDefValue("AAASTARTTELEMETRY", startByDefault); // also used in AAATelemetryAppender
    bool debugAtStartup = SYS_GetEnvBoolOrDefValue("AAAOTELDEBUGLOG", false); 

    sv_TelemetryStartRequested = startTracer && sv_TwacStarted;

    AAATelemetryImpl::Init_Telemetry_InternalLogger(debugAtStartup, sv_TelemetryStartRequested);

    AAATracerImpl::init(sv_TelemetryStartRequested);

}

void AAATelemetry::configure(std::initializer_list<StringPair> environmentVariables)
{
    if (sv_TelemetryStartRequested)
    {
        if (sv_TelemetryStarted)
        {
            std::ostringstream oss;
            oss << "AAATelemetry::configure Already started !! Reconfigure Not Yet implemented !! TelemetryStartRequested=" << std::boolalpha << sv_TelemetryStartRequested << " TelemetryStarted=" << sv_TelemetryStarted;
            AAALogger::get(AAALogger::Logger::Configuration).error(oss.str());
        }
        else {
            std::map<std::string, std::string>   _params;

            for (auto aEnv : environmentVariables)
            {
                _params.emplace(aEnv);
            }

            auto tagsList = AAATelemetryImpl::GetDefaultTags();

            AAATelemetryImpl::Merge(_params, tagsList);

            auto _ra = AAATelemetryImpl::Convert(_params);

            bool debugConfiguration = (_ra.find("debug") != _ra.end()) && ((opentelemetry::nostd::get<std::string>(_ra.find("debug")->second).compare("true") == 0));

            AAATelemetryImpl::ConfigureAndSetTheLoggerProviderWithExporter(debugConfiguration, _ra);

            AAATracerImpl::configure(debugConfiguration, _ra);

            AAAMeterFactory::configure(debugConfiguration, _ra);

            sv_TelemetryStarted = true;
        }
    }

    std::ostringstream oss;
    oss << "AAATelemetry::configure TelemetryStartRequested=" << std::boolalpha << sv_TelemetryStartRequested << " TelemetryStarted=" << sv_TelemetryStarted;
    AAALogger::get(AAALogger::Logger::Configuration).info(oss.str());
}

// https://opentelemetry.io/docs/languages/sdk-configuration/otlp-exporter/
// 
// OTEL_EXPORTER_OTLP_PROTOCOL exportProtocolChoice = ExportProtocol::http_protobuf; "http/protobuf"
// OTEL_EXPORTER_OTLP_ENDPOINT  (SDK Supported)
// OTEL_EXPORTER_OTLP_(METRIC/LOGS)_ENDPOINT (SDK Supported)
// OTEL_EXPORTER_OTLP_SSL_ENABLE  (SDK Supported)
// debug 


void AAATelemetry::addTWACattributes(std::map<std::string, std::string> environmentVariables, const std::string& forZone, const std::string& serviceType)
{

    std::map<std::string, std::string>  results;
    results.emplace(AAATelemetry::StringPair("twac.instance", GEN_GetApplName()));
    results.emplace(AAATelemetry::StringPair("twac.type", serviceType));
    results.emplace(AAATelemetry::StringPair("twac.zone", forZone));


    AAATelemetryImpl::addResourceAttributes(results);

    AAATracerImpl::addResourceAttributes(results);

    AAAMeterFactory::addResourceAttributes(results);

}




std::map<std::string, std::string>  AAATelemetryImpl::GetDefaultTags()
{
    std::map<std::string, std::string>  results;
    results.emplace(AAATelemetry::StringPair("TAP.version", AAAVersion::getVersion().getfullVersionInfo()));

#if 0
    // see https://opentelemetry.io/docs/specs/semconv/resource/process/#process
    std::string exeName;
    AAA_Sigar::GetExecutableName(exeName);
    results.emplace(AAATelemetry::StringPair("process.executable.name", exeName));

    std::string exePath;
    AAA_Sigar::GetExecutablePath(exePath);
    results.emplace(AAATelemetry::StringPair("process.executable.path", exePath));

    results.emplace(AAATelemetry::StringPair("process.pid", std::to_string(AAA_Sigar::getPid())));

    results.emplace(AAATelemetry::StringPair("process.owner", SYS_GetOsUserName()));
#endif

    return results;

}

void AAATelemetryImpl::Merge(std::map<std::string, std::string>& fromEnvironmentVariable, std::map<std::string, std::string> tags)
{
    fromEnvironmentVariable.insert(tags.begin(), tags.end());
}

#if 0
void AAATelemetryImpl::completeMissingTags(AAATelemetry::StringPairVector fromEnvironmentVariable, AAATelemetry::StringPairVector& )
 {
    std::string forServiceName;
    std::string debugValue;
    std::chrono::milliseconds export_interval_millis = opentelemetry::sdk::metrics::kExportIntervalMillis; // @TODO remove when implemeneted is SDK.

    bool service_name_set = false;

    // https://opentelemetry.io/docs/specs/semconv/resource/#service
    static const std::string kServiceName("service.name");
    static const std::string kDebug("debug");

    // https://opentelemetry.io/docs/concepts/sdk-configuration/general-sdk-configuration/
    static const std::string kEnvResoureAttributes("OTEL_RESOURCE_ATTRIBUTES");
    static const std::string kEnvServiceName("OTEL_SERVICE_NAME");
    static const std::string kEnvMericExportInterval("OTEL_METRIC_EXPORT_INTERVAL");

    static const std::string kEnvExporterOtlpProtocol("OTEL_EXPORTER_OTLP_PROTOCOL");

    static const std::string kEnvTelemetryMeticEnable("telemetry.metrics.enable");
    static const std::string kEnvTelemetryTracingEnable("telemetry.tracing.enable");

    enum class ExportProtocol { grpc, http_protobuf, http_json };

    // https://opentelemetry.io/docs/concepts/sdk-configuration/otlp-exporter-configuration/#otel_exporter_otlp_protocol
    // Default value: SDK-dependent, but will typically be either http/protobuf or grpc.
    // see https://github.com/open-telemetry/opentelemetry-specification/blob/main/specification/protocol/exporter.md#specify-protocol
    // "If no configuration is provided the default transport SHOULD be http/protobuf"

    for (auto& aEnv : fromEnvironmentVariable)
    {
        std::string key = aEnv.first;
        std::string value = aEnv.second;

        std::string keyUpperNoDot(key);
        std::transform(keyUpperNoDot.begin(), keyUpperNoDot.end(), keyUpperNoDot.begin(), [](char c) {if (c == '.') return '_'; else return static_cast<char>(::toupper(c)); });

        // Force the environement variables received
        SYS_PutEnv(keyUpperNoDot.c_str(), value.c_str());

        if (keyUpperNoDot.compare(kEnvResoureAttributes) == 0) {
            std::vector<std::string> kvpair;
            SYS_StringTokenize(kvpair, value, ",");
            for (auto& kv : kvpair)
            {
                std::vector<std::string> kvvals;
                SYS_StringTokenize(kvvals, kv, "=");
                if (kvvals.size() == 2) {
                    if (kvvals[0] == kServiceName) {
                        service_name_set = true;
                        forServiceName = kvvals[1];
                    }
                }
            }
        }
        if (keyUpperNoDot.compare(kEnvServiceName) == 0) {
            service_name_set = true;
            forServiceName = value;
        }

        if (keyUpperNoDot.compare(kEnvMericExportInterval) == 0) {
            try {
                int _val = std::stoi(value);
                if (_val > 0) {
                    export_interval_millis = std::chrono::milliseconds(_val);
                }
            }
            catch (...) {}; // @TODO remove when implemeneted is SDK.
        }
        if (key.compare(kDebug) == 0) {
            debugValue = value;
        }
    }

    //if (service_name_set == false) {
    //    forServiceName = GEN_GetProgramName();
    //    if (result.find(kServiceName) == result.end())
    //    {
    //        result.SetAttribute(kServiceName, forServiceName);
    //    }
    //}

}
#endif

opentelemetry::sdk::resource::ResourceAttributes  AAATelemetryImpl::Convert(std::map<std::string, std::string> tags)
{
    opentelemetry::sdk::resource::ResourceAttributes result;

        for (auto& aTag : tags)
        {
            const opentelemetry::nostd::string_view _key(aTag.first);
            const opentelemetry::common::AttributeValue _value(aTag.second);
            result.SetAttribute(_key, _value);
        }

  return result;
}

void AAATelemetryImpl::ConfigureAndSetTheLoggerProviderWithExporter(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes ressourceAttributes)
{
    std::vector<std::unique_ptr<opentelemetry::sdk::logs::LogRecordProcessor>> logProcessors;

    opentelemetry::exporter::otlp::OtlpHttpLogRecordExporterOptions opts;

    auto otlpHTTPlogExporter = opentelemetry::exporter::otlp::OtlpHttpLogRecordExporterFactory::Create(opts);

    auto processor = opentelemetry::sdk::logs::SimpleLogRecordProcessorFactory::Create(std::move(otlpHTTPlogExporter));

    logProcessors.push_back(std::move(processor));
    
    auto resource = opentelemetry::sdk::resource::Resource::Create(ressourceAttributes);

    std::shared_ptr<opentelemetry::sdk::logs::LoggerProvider> sdk_provider( opentelemetry::sdk::logs::LoggerProviderFactory::Create(std::move(logProcessors), resource));
    
    const std::shared_ptr<opentelemetry::logs::LoggerProvider> &api_provider = sdk_provider;

    opentelemetry::logs::Provider::SetLoggerProvider(api_provider);

    if (debugConfiguration)
    {
        opentelemetry::sdk::common::internal_log::GlobalLogHandler::SetLogLevel(opentelemetry::sdk::common::internal_log::LogLevel::Debug);
    }

}


void  AAATelemetryImpl::Init_Telemetry_InternalLogger(bool debugConfiguration, bool startTelemetry)
{

    log4cplus::spi::AppenderFactoryRegistry& regAppender = log4cplus::spi::getAppenderFactoryRegistry();
    LOG4CPLUS_REG_PRODUCT(regAppender, "TripleA::", AAATelemetryAppender, ::, log4cplus::spi::AppenderFactory);



 //        auto backup_log_handle =  opentelemetry::sdk::common::internal_log::GlobalLogHandler::GetLogHandler();
//        auto backup_log_level = opentelemetry::sdk::common::internal_log::GlobalLogHandler::GetLogLevel();

    if (startTelemetry)
    {
        auto custom_log_handler = opentelemetry::nostd::shared_ptr<opentelemetry::sdk::common::internal_log::LogHandler>(new AAA2internalOTELlogHandler{});
        opentelemetry::sdk::common::internal_log::GlobalLogHandler::SetLogHandler(custom_log_handler);
    }
}
void  AAATelemetryImpl::addResourceAttributes(std::map<std::string, std::string> attributes)
{
    auto loggerProvider = opentelemetry::logs::Provider::GetLoggerProvider();

    if (loggerProvider.get() != nullptr)
    {
        auto* sdk_loggerProvider = dynamic_cast<opentelemetry::sdk::logs::LoggerProvider*> (loggerProvider.get());
        if (sdk_loggerProvider) {
            auto _ra = AAATelemetryImpl::Convert(attributes);
            auto other = opentelemetry::sdk::resource::Resource::Create(_ra);
            auto merged = sdk_loggerProvider->GetResource().Merge(other);
            // @@ TODO How to set them ? sdk_loggerProvider->SetResource(merged);
        }
    }
}

// -----

bool  AAATelemetry::isStarted()
{
    return AAATracerImpl::IsGloballyEnabled();
}

bool  AAATelemetry::isStartRequested()
{
    return sv_TelemetryStartRequested;
}


void AAATelemetry::setTwacStarted(const bool status)
{
    sv_TwacStarted = status;
}

void AAATelemetry::disableMetrics()
{
    AAAMeterFactory::disableMetrics();
}

void AAATelemetry::enableMetrics()
{
    AAAMeterFactory::enableMetrics();
}

void AAATelemetry::terminate()
{
    AAATracerImpl::terminate();
    AAAMeterFactory::terminate();
}





/************************************************************************
*   Method             : AAATelemetryAppender SeverityToOTEL
*
*   Description        :
*
*************************************************************************/
opentelemetry::logs::Severity SeverityToOTEL(const log4cplus::LogLevel& ll)
{
    switch (ll) {
    case         log4cplus::TRACE_LOG_LEVEL:
        return opentelemetry::logs::Severity::kTrace;
        break;
    case        log4cplus::DEBUG_LOG_LEVEL:
        return opentelemetry::logs::Severity::kDebug;
        break;
    case        log4cplus::INFO_LOG_LEVEL:
        return opentelemetry::logs::Severity::kInfo;
        break;
    case        log4cplus::WARN_LOG_LEVEL:
        return opentelemetry::logs::Severity::kWarn;
        break;
    case        log4cplus::ERROR_LOG_LEVEL:
        return opentelemetry::logs::Severity::kError;
        break;
    case        log4cplus::FATAL_LOG_LEVEL:
        return opentelemetry::logs::Severity::kFatal;
        break;
    default:
        return opentelemetry::logs::Severity::kWarn;
        break;
    }
}


struct AAATelemetryAppender::OTELProxy
{
    bool isActive = false;
    bool connectionOTELtested = false;
    bool inUse=false;
    opentelemetry::nostd::shared_ptr<opentelemetry::logs::Logger> logger_;
};

void AAATelemetryAppender::OTELProxyDeleter::operator()(OTELProxy* p)
{
    delete p;
};

/************************************************************************
*   Method             : AAATelemetryAppender::AAATelemetryAppender
*
*   Description        :
*
*************************************************************************/
AAATelemetryAppender::AAATelemetryAppender(const log4cplus::helpers::Properties& properties)
    : Appender(properties),
    otelProxy_(new AAATelemetryAppender::OTELProxy())
{
    
    bool defValueActive = SYS_GetEnvBoolOrDefValue("AAASTARTTELEMETRY", true); // also used in AAATelemetry::init
    bool isDefined = properties.getBool(otelProxy_->isActive, LOG4CPLUS_TEXT("enabled"));
    if (isDefined == false)
    {
        otelProxy_->isActive = defValueActive;
    }

}


/************************************************************************
*   Method             : AAATelemetryAppender::append
*
*   Description        : See the 2 implementations in triplea_core\taptracing\src\
                            aaatelemetry-unsupported.cpp
                            aaatelemetry-opentelemetry.cpp
*
*************************************************************************/



void AAATelemetryAppender::append(const log4cplus::spi::InternalLoggingEvent& event)
{
    if (otelProxy_->isActive)
    {
        if (otelProxy_->inUse)
        {
        }
        else
        {
            otelProxy_->inUse = true;

            const std::string _logerName = LOG4CPLUS_TSTRING_TO_STRING(event.getLoggerName());
            const std::string _appenderName = LOG4CPLUS_TSTRING_TO_STRING(this->getName());
            if (otelProxy_->logger_ == nullptr)
            {
                auto lp = opentelemetry::logs::Provider::GetLoggerProvider();  // May return a NoopLoggerProvider
                static const std::string schema_url{ "https://opentelemetry.io/schemas/1.11.0" };
                // Use the apender name as the logger name inside the OTEL client library as this is created on demand by the 1st log message per appender
                otelProxy_->logger_ = lp->GetLogger(_appenderName, "opentelemetry_library", OPENTELEMETRY_SDK_VERSION, schema_url);  //might be a NoopLogger
            }

            if (otelProxy_->logger_->CreateLogRecord())  // One way of testing if not NoopLoggerProvider, the fastest ? as logger->Enabled (_severity) looks not good.
            {
                const auto _severity = SeverityToOTEL(event.getLogLevel());
                const std::string _message = LOG4CPLUS_TSTRING_TO_STRING(event.getMessage());
                std::map<opentelemetry::nostd::string_view, opentelemetry::common::AttributeValue> _attributes;
                // https://opentelemetry.io/docs/specs/semconv/general/logs/#log-file
                _attributes.emplace("code.filepath", LOG4CPLUS_TSTRING_TO_STRING(event.getFile()));
                const std::string _lineStringToAvoidASANerror = std::to_string(event.getLine()); // requires a temporary Variable otherwise : ERROR: AddressSanitizer: stack-use-after-scope
                _attributes.emplace("code.lineno", _lineStringToAvoidASANerror);
                _attributes.emplace("thread.id", LOG4CPLUS_TSTRING_TO_STRING(event.getThread2())); // getThread2 is the TID expected on Linux 
                _attributes.emplace("logger.name", _logerName);
                _attributes.emplace("appender.name", _appenderName);

                const log4cplus::MappedDiagnosticContextMap& mdc = event.getMDCCopy();

                for (log4cplus::MappedDiagnosticContextMap::const_iterator it = mdc.begin(); it != mdc.end(); it++)
                {
                    _attributes.emplace(LOG4CPLUS_TSTRING_TO_STRING(it->first), LOG4CPLUS_TSTRING_TO_STRING(it->second));
                }

                opentelemetry::context::Context  _current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();
                opentelemetry::trace::SpanContext _span_context = opentelemetry::trace::GetSpan(_current_ctx)->GetContext();
                const std::chrono::time_point<std::chrono::system_clock>  _eventTimestamp = event.getTimestamp();

                auto current_log_handle = opentelemetry::sdk::common::internal_log::GlobalLogHandler::GetLogHandler();

                size_t before_ErrorCount = 0;
                if (otelProxy_->connectionOTELtested == false)
                {
                    if (current_log_handle.get() && dynamic_cast<AAA2internalOTELlogHandler*>(current_log_handle.get()) != nullptr)
                    {
                        auto logH = dynamic_cast<AAA2internalOTELlogHandler*>(current_log_handle.get());
                        before_ErrorCount = logH->errorCount;
                        logH->startCapture();
                    }
                }

                otelProxy_->logger_->EmitLogRecord(
                    _severity,
                    _message,
                    _attributes,
                    _span_context,
                    _eventTimestamp);
                /**
                 * Emit a Log Record object with arguments
                 *
                 * @tparam args Arguments which can be used to set data of log record by type.
                 *  Severity                                -> severity, severity_text
                 *  string_view                             -> body
                 *  AttributeValue                          -> body
                 *  SpanContext                             -> span_id,tace_id and trace_flags
                 *  SpanId                                  -> span_id
                 *  TraceId                                 -> tace_id
                 *  TraceFlags                              -> trace_flags
                 *  SystemTimestamp                         -> timestamp
                 *  system_clock::time_point                -> timestamp
                 *  KeyValueIterable                        -> attributes
                 *  Key value iterable container            -> attributes
                 *  span<pair<string_view, AttributeValue>> -> attributes(return type of MakeAttributes)
                */

                if (otelProxy_->connectionOTELtested == false)
                {
                    if (current_log_handle.get() && dynamic_cast<AAA2internalOTELlogHandler*>(current_log_handle.get()) != nullptr)
                    {
                        size_t after_ErrorCount = dynamic_cast<AAA2internalOTELlogHandler*>(current_log_handle.get())->errorCount;
                        auto logH = dynamic_cast<AAA2internalOTELlogHandler*>(current_log_handle.get());
                        after_ErrorCount = logH->errorCount;
                        if (after_ErrorCount > before_ErrorCount)
                        {
                            otelProxy_->isActive = false;

                            AAALogger::get(AAALogger::Logger::Configuration).warnT("Log4cplus Appender: {Log4CplusAppenderName} (AAATelemetryAppender) disabled due to errors : {errorMessagesOTELclientLibrary}", LOG4CPLUS_TSTRING_TO_STRING(this->getName()), logH->m_oss.str());
                        }
                        logH->stopCapture();
                    }
                    otelProxy_->connectionOTELtested = true;
                }
                otelProxy_->inUse = false;
            }
        }
    }
}


//-------------AAAMeterName


std::string AAAMeter::MeterName::GetMeterName(enum AAAMeter::MeterName::Value fromName)
{
    std::string ret;

    switch (static_cast<int>(fromName))
    {
    case AAAMeter::MeterName::General:
        ret = "General";
        break;
    case AAAMeter::MeterName::Process:
        ret = "Process";
        break;
    case AAAMeter::MeterName::HttpServer:
        ret = "HttpServer";
        break;
    case AAAMeter::MeterName::Script:
        ret = "Script";
        break;
    default:
        assert(false);
        AAALogger::get(AAALogger::Logger::Tracer).assertion(false, "AAAMeter::MeterName:::GetMeterName Meter not defined");
    }
    return ret;
}


// ------------------AAATracer

AAATracer::AAATracer(std::shared_ptr<AAATracerImpl>& ptr) :
    mTracerImpl(ptr)
{
}
/*
AAATracer::AAATracer(const AAATracer& rhs)
{
    mTracerImpl = rhs.mTracerImpl;
}
*/
AAATracer::AAASpan AAATracer::startNewSpan(const std::string& operationName)
{
    return mTracerImpl->startSpan(operationName);
}


AAATracer::AAASpan AAATracer::getActiveSpan()
{
    std::shared_ptr<AAASpanImpl> current = mTracerImpl->getActiveSpan();
    return AAASpan(current);
}

AAATracer::AAASpan AAATracer::continueSpanFrom(const std::string& operationName, const std::string& externalTraceID, AAATracer::LinkNature linkNature)
{
    return mTracerImpl->continueSpanFrom(operationName, externalTraceID, linkNature);
}

AAATracer::AAASpan AAATracer::continueSpanFrom(const std::string& operationName, std::unordered_map<std::string, std::string >& externalRepresentation, AAATracer::LinkNature linkNature)
{
    return mTracerImpl->continueSpanFrom(operationName, externalRepresentation, linkNature);
}

AAATracer::TraceName AAATracer::getTrace(AAATracer::TraceName::Value v)
{
    return  AAATracerImpl::getTrace(v);
}

AAATracer::TraceName AAATracer::getTraceByName(const std::string& name)
{
    return  AAATracerImpl::getTraceByName(name);
}

void AAATracer::setTraceActiveByName(const std::string& name, bool to)
{
    AAATracerImpl::setTraceActiveByName(name, to);
}

void AAATracer::getAllTraces(std::vector<AAATracer::TraceName>& result)
{
    AAATracerImpl::getAllTraces(result);
}

bool AAATracer::isEnabled() const
{
    return mTracerImpl->isEnabled();
}

void AAATracer::setEnable(bool to)
{
    mTracerImpl->setEnable(to);
}

bool AAATracer::IsGloballyEnabled()
{
    return AAATracerImpl::IsGloballyEnabled();
}

void AAATracer::SetGloballyEnabled(bool to)
{
    AAATracerImpl::SetGloballyEnabled(to);
}
void AAATracer::SetEnableAll(bool to) 
{
    AAATracerImpl::SetEnableAll(to);
}

// ------------------AAATracer::Trace

std::string AAATracer::TraceName::to_string() const
{
    return getTraceString(this->name);
}

std::string AAATracer::TraceName::getTraceString(Value fromName)
{

    std::string ret;

    switch (static_cast<int>(fromName))
    {
    case AAATracer::TraceName::HttpServer:
        ret = "HttpServer";
        break;
    case AAATracer::TraceName::HttpServerDetailed:
        ret = "HttpServerDetailed";
        break;
    case AAATracer::TraceName::HttpServerDetailedCusto:                                                       /* WEALTH-18208 - 020225 - vivek - Additional Trace type for Custo information */
        ret = "HttpServerDetailedCusto";
        break;
    case AAATracer::TraceName::Importation:
        ret = "Importation";
        break;
    case AAATracer::TraceName::Subscription:
        ret = "Subscription";
        break;
    case AAATracer::TraceName::General:
        ret = "General";
        break;
    case AAATracer::TraceName::Null:
        ret = "Null";
        break;
    default:
        SYS_BreakOnDebug();
        AAALogger::get(AAALogger::Logger::Tracer).assertion(false, "AAATracer::Trace::getTraceName Trace not defined");
    }
    return ret;
}
bool AAATracer::TraceName::isActive() const 
{ 
    AAATracer correcpondingTracer = AAATracerImpl::getLazyConstructor(this->name);
    return correcpondingTracer.isEnabled();
}
void AAATracer::TraceName::setActive(bool to) 
{ 
    AAATracer correcpondingTracer = AAATracerImpl::getLazyConstructor(this->name);

    correcpondingTracer.setEnable(to);
}

// ------------------AAATracer::AAASpan

AAATracer::AAASpan& AAATracer::AAASpan::log(const std::string& key, const std::string& value)
{
    if (m_impl) {
        m_impl->log(key, value);
    }
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::updateOperationName(const std::string& opName)
{
    if (m_impl) {
        m_impl->setOperationName(opName);
    }
    return *this;
}
AAATracer::AAASpan& AAATracer::AAASpan::setTagb(const std::string&key, bool value)
{
    if (m_impl) {
        std::string _value = std::to_string(value);
        m_impl->setTag(key, _value);
    }
    return *this;
}
AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string& key, const char* value)
{
    if (m_impl) {
        std::string _value(value);
        m_impl->setTag(key, _value);
    }
    return *this;
}
AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string& key, int64_t  value)
{
    if (m_impl) {
        std::string _value= std::to_string(value);
        m_impl->setTag(key, _value);
    }
    return *this;
}
AAATracer::AAASpan& AAATracer::AAASpan::setTag(const std::string&key, const std::string& value)
{
    if (m_impl) {
        m_impl->setTag(key, value);
    }
    return *this;
}

AAATracer::AAASpan& AAATracer::AAASpan::addEvent(const std::string& key, const std::map<std::string, std::string>& value)
{
    if (m_impl) {
        m_impl->addEvent(key, value);
    }
    return *this;
}


std::string AAATracer::AAASpan::getTracePropagation()
{
    std::string result;
    if (m_impl) {
        result = m_impl->getTracePropagation();
    }
    return result;
}

std::string AAATracer::AAASpan::getTraceId()
{
    std::string result;
    if (m_impl) {
        result = m_impl->getTraceId();
    }
    return result;
}

void AAATracer::AAASpan::finish()
{
    if (m_impl) {
        m_impl->finish();
    }
}
AAATracer::AAASpan::AAASpan()
{
    m_impl = nullptr;
}

AAATracer::AAASpan::AAASpan(std::shared_ptr<AAASpanImpl> impl)
{
    m_impl = impl;

}

AAATracer::AAASpan::AAASpan(const AAASpan& rhs)
{
    m_impl = rhs.m_impl;

}

AAATracer::AAASpan& AAATracer::AAASpan::operator=(const AAASpan&rhs)
{
    m_impl = rhs.m_impl;


    return *this;
}

AAATracer::AAASpan::~AAASpan()
{

    if (m_impl.use_count() == 1)
    {
        m_impl->finish();
    }
    m_impl = nullptr;
}


// ------------------AAASpanImpl
AAASpanImpl::AAASpanImpl(AAATracerImpl * creator) :
    m_creator(creator),
    m_spanimpl(nullptr),
    m_contextToken(nullptr),
    m_enabled(true)
{
}

AAASpanImpl::AAASpanImpl() :
    m_creator(nullptr),
    m_spanimpl(nullptr),
    m_contextToken(nullptr),
    m_enabled(false)
{
}


/* @TODO

AAASpanImpl::AAASpanImpl(const AAASpanImpl& rhs) :
    m_creator(rhs.m_creator),
    m_span(rhs.m_span),
    m_spanimpl(rhs.m_spanimpl)
{

}
AAASpanImpl& AAASpanImpl::operator=(const AAASpanImpl&rhs)
{
    m_creator = rhs.m_creator;
    m_span = rhs.m_span;
    m_spanimpl = rhs.m_spanimpl;

    return *this;
}
*/
AAASpanImpl::~AAASpanImpl()
{
    m_spanimpl = nullptr;
    m_contextToken = nullptr;
}


AAASpanImpl & AAASpanImpl::startSpan(const std::string& operationName)
{
    if (nullptr != m_creator && (m_creator->m_OpenTracerImpl)) {

        std::shared_ptr<AAASpanImpl> parent = m_creator->getActiveSpan();

        opentelemetry::trace::StartSpanOptions options;


        if (nullptr != parent && parent->m_spanimpl)
        {

             options.parent = parent->m_spanimpl->GetContext();
        }

         _startSpanAndActivate(operationName, options);

        _verifyRuntimeContextValid();
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled())
        {
            logger.trace("AAASpanImpl::startSpan =" + operationName);
        }
    }
    return *this;
}

void AAASpanImpl::_startSpanAndActivateWithLink(const std::string& operationName,
                                                const opentelemetry::trace::SpanContextKeyValueIterable& links,
                                                const opentelemetry::trace::StartSpanOptions& options)
{
    //std::map<std::string, std::string> attrs1 = { {} }; // { {"attr1", "1"}, { "attr2", "2" } };

    std::map<opentelemetry::nostd::string_view, opentelemetry::common::AttributeValue> _attributes;
    // _attributes.emplace("thread.id", OS_GetTid());
    opentelemetry::common::KeyValueIterableView < std::map<opentelemetry::nostd::string_view, opentelemetry::common::AttributeValue> > _attributesView(_attributes);


    m_spanimpl = m_creator->m_OpenTracerImpl->StartSpan(operationName, _attributesView, links, options);

    opentelemetry::context::Context  current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();

    auto new_current_ctx = opentelemetry::trace::SetSpan(current_ctx, m_spanimpl);

    m_contextToken = opentelemetry::context::RuntimeContext::Attach(new_current_ctx);
}


void AAASpanImpl::_startSpanAndActivate(const std::string& operationName,
                                       const opentelemetry::trace::StartSpanOptions& options)
{
    m_spanimpl = m_creator->m_OpenTracerImpl->StartSpan(operationName, options);

    opentelemetry::context::Context  current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();

    auto new_current_ctx = opentelemetry::trace::SetSpan(current_ctx, m_spanimpl);

    m_contextToken = opentelemetry::context::RuntimeContext::Attach(new_current_ctx);

    _verifyRuntimeContextValid();
}


void AAASpanImpl::startLinkedSpanAndActivate(const std::string& operationName, const opentelemetry::trace::SpanContext& linkedSpanContext, AAATracer::LinkNature linkNature)
{
    switch (linkNature)
    {
    case AAATracer::LinkNature::CHILD_OF:
    {
        opentelemetry::trace::StartSpanOptions options;
        options.kind = opentelemetry::trace::SpanKind::kServer;
        if (linkedSpanContext.IsValid())
        {
            options.parent = linkedSpanContext;
        }
        _startSpanAndActivate(operationName, options);
    }
    break;

    case AAATracer::LinkNature::FOLLOWS_FROM:
    {
        opentelemetry::trace::StartSpanOptions options;
        options.kind = opentelemetry::trace::SpanKind::kConsumer;

        static std::map<std::string, std::string> emptymap;
        AAASpanImpl::LinkReferenceType _p = std::make_pair(linkedSpanContext, emptymap);

        AAASpanImpl::LinkReferenceVectorType _links;
        _links.push_back(_p);

        opentelemetry::trace::SpanContextKeyValueIterableView<AAASpanImpl::LinkReferenceVectorType> iterlinks(_links);

        _startSpanAndActivateWithLink(operationName, iterlinks, options);
    }
    break;
    default:
        SYS_BreakOnDebug();
        break;
    }
}

//Debug
void AAASpanImpl::_verifyRuntimeContextValid()
{
    AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
    bool _debug = logger.isDebugEnabled();

    if (_debug)
    {
        opentelemetry::context::Context  new_current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();

        opentelemetry::trace::SpanContext span_context = opentelemetry::trace::GetSpan(new_current_ctx)->GetContext();

        opentelemetry::trace::SpanContext invalid_context = opentelemetry::trace::SpanContext::GetInvalid();

        bool valid = span_context.IsValid();

        if (valid == false)
        {
            std::ostringstream oss;
            oss << "AAASpanImpl::_verifyRuntimeContextValid  Invalid span_context";
            logger.debug(oss.str());
        }
    }
}

AAASpanImpl& AAASpanImpl::continueSpanFrom(const std::string& operationName, const std::string& externalTraceID, AAATracer::LinkNature linkNature)
{

    if (nullptr != m_creator && (m_creator->m_OpenTracerImpl))
    {
        std::istringstream iss(externalTraceID);

        HttpTextMapCarrier<opentelemetry::ext::http::client::Headers> text_map_carrier;
        text_map_carrier.restoreguds(iss);
 
        auto propagator = opentelemetry::context::propagation::GlobalTextMapPropagator::GetGlobalPropagator();
        auto current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();
        opentelemetry::context::Context new_context = propagator->Extract(text_map_carrier, current_ctx);

        opentelemetry::trace::SpanContext linkedSpanContext = opentelemetry::trace::GetSpan(new_context)->GetContext();

        startLinkedSpanAndActivate(operationName, linkedSpanContext, linkNature);
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled())
        {
            logger.trace("AAASpanImpl::continueSpanFrom =" + operationName + " externalTraceID=" + externalTraceID);
        }
    }
    return *this;

}

AAASpanImpl& AAASpanImpl::continueSpanFrom(const std::string& operationName, std::unordered_map<std::string, std::string >& externalRepresentation, AAATracer::LinkNature linkNature)
{
    if (nullptr != m_creator && (m_creator->m_OpenTracerImpl))
    {
        HttpTextMapCarrier<std::unordered_map<std::string, std::string >> text_map_carrier(externalRepresentation);

        auto propagator = opentelemetry::context::propagation::GlobalTextMapPropagator::GetGlobalPropagator();
        auto current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();
        opentelemetry::context::Context new_context = propagator->Extract(text_map_carrier, current_ctx);

        opentelemetry::trace::SpanContext linkedSpanContext = opentelemetry::trace::GetSpan(new_context)->GetContext();

        startLinkedSpanAndActivate(operationName, linkedSpanContext, linkNature);

    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled())
        {
            logger.trace("AAASpanImpl::continueSpanFrom =" + operationName + " externalTraceID unordered_map");
        }
    }
    return *this;
}

AAASpanImpl& AAASpanImpl::log(const std::string& key, const std::string& value)
{
    if (nullptr != m_spanimpl) {
      //  m_spanimpl->Log({ { key, value } });
        m_spanimpl->AddEvent("log", { { key, value } });
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled()) 
        {
            logger.trace("AAASpanImpl::log k=" + key + " v=" + value);
        }
    }
    return *this;
}
AAASpanImpl& AAASpanImpl::setOperationName(const std::string& name)
{
    if (nullptr != m_spanimpl) {
        m_spanimpl->UpdateName(name);
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled()) {
            logger.trace("AAASpanImpl::setOperationName =" + name);
        }
    }
    return *this;
}
AAASpanImpl& AAASpanImpl::setTagb(const std::string& key, bool value)
{
    if (nullptr != m_spanimpl) {
        m_spanimpl->SetAttribute(key, value);
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled()) 
        {
            logger.trace("AAASpanImpl::setTag  k=" + key + " v=" + (value ? "true" : "false"));
        }
    }
    return *this;
}
AAASpanImpl& AAASpanImpl::setTag(const std::string& key, const std::string& value)
{
    if (nullptr != m_spanimpl) {
        m_spanimpl->SetAttribute (key, value);
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled()) 
        {
            logger.trace("AAASpanImpl::setTag  k=" + key + " v=" + value);
        }
    }
    return *this;
}


AAASpanImpl& AAASpanImpl::addEvent(const std::string& key, const std::map<std::string, std::string>& value)
{
    if (nullptr != m_spanimpl) {
        m_spanimpl->AddEvent(key, value);
    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled())
        {
            logger.trace("AAASpanImpl::addEvent  k=" + key + " v= @@TODO" );
        }
    }
    return *this;
}


std::string AAASpanImpl::getTracePropagation()
{
    std::string result;

    if (nullptr != m_spanimpl) {

        _verifyRuntimeContextValid();

        opentelemetry::context::Context  current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();

        HttpTextMapCarrier<opentelemetry::ext::http::client::Headers> http_text_map_carrier;
        auto prop = opentelemetry::context::propagation::GlobalTextMapPropagator::GetGlobalPropagator();
        prop->Inject(http_text_map_carrier, current_ctx);

        std::ostringstream oss;
        http_text_map_carrier.saveguds(oss);
        result = oss.str();
    }

    return result;
}

std::string AAASpanImpl::getTraceId()
{
    std::string result;
    if (nullptr != m_spanimpl) {

        opentelemetry::context::Context  current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();
        opentelemetry::trace::SpanContext span_context = opentelemetry::trace::GetSpan(current_ctx)->GetContext();

        const opentelemetry::trace::TraceId& trace = span_context.trace_id();

        char buf[32];
        trace.ToLowerBase16(buf);
        result= std::string(buf, sizeof(buf));
    }

    return result;
}

void AAASpanImpl::finish()
{
    std::shared_ptr<AAASpanImpl> currentActive = m_creator==nullptr? nullptr:m_creator->getActiveSpan();

    if (nullptr != m_spanimpl) 
    {
        m_spanimpl->End();

        m_contextToken = nullptr;

    }
    if (nullptr == m_creator || m_creator->m_debugTraceActive)
    {
        AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
        if (logger.isTraceEnabled()) 
        {
            logger.trace("AAASpanImpl::finish");
        }
    }
    else if(isEnabled() && AAATracerImpl::sv_globallyEnabled)
    {
        if (this != currentActive.get())
        {
            AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
            if (logger.isInfoEnabled()) {
                logger.info("AAASpanImpl::finish  try to terminate a AAASpanImpl which is not current");
            }
        }
        else {
            bool status = m_creator->popActiveSpan();
            if (status == false)
            {
                AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);
                if (logger.isInfoEnabled()) {
                    logger.info("AAASpanImpl::finish popActiveSpan not found");
                }
            }
        }
    }
}



bool  AAASpanImpl::isEnabled() const 
{ 
    return m_enabled; 
}

void  AAASpanImpl::setEnabled(bool to) 
{ 
    m_enabled = to; 
}

class AAATelemetryInitializerImpl {
public:
    AAATelemetryInitializerImpl(bool defaultStartingBehavour);
    ~AAATelemetryInitializerImpl();
    void configure(std::initializer_list<std::pair<std::string, std::string>> envContext);
private:
};

// ------------------AAATracerImpl

bool  AAATracerImpl::sv_startTracerClient = false;

AAATracerImpl::TraceMapType   AAATracerImpl::sv_allTraces;

bool  AAATracerImpl::sv_globallyEnabled = false;



std::map<AAATracer::TraceName, std::shared_ptr<AAATracerImpl>> AAATracerImpl::sv_AAATracerImpl;

std::shared_ptr<AAASpanImpl> AAATracerImpl::sv_noopspan = std::shared_ptr<AAASpanImpl>(new AAASpanImpl()); 


AAATracer::TraceName  AAATracerImpl::sv_nullTrace(AAATracer::TraceName::Null);

AAATracerImpl::AAATracerImpl(const std::string& name):
    m_isEnabled(false), 
    m_debugTraceActive(false),
    m_name(name)
{
    // CHeck done only once at startup.
    m_debugTraceActive = AAALogger::get(AAALogger::Logger::Tracer).isDebugEnabled();
}

AAATracerImpl::~AAATracerImpl()
{

}


AAATracer::TraceName AAATracerImpl::getTrace(AAATracer::TraceName::Value _name)
{
    return getTraceByName(AAATracer::TraceName::getTraceString(_name));
}

AAATracer::TraceName AAATracerImpl::getTraceByName(const std::string& name)
{
    TraceMapType::iterator allTrace_it;
    if ((allTrace_it = sv_allTraces.find(name)) != sv_allTraces.end())
    {
        return allTrace_it->second;
    }
    else
    {
        return sv_nullTrace;
    }
}

void AAATracerImpl::setTraceActiveByName(const std::string& name, bool to)
{
    TraceMapType::iterator allTrace_it;
    if ((allTrace_it = sv_allTraces.find(name)) != sv_allTraces.end())
    {
        allTrace_it->second.setActive(to);
    }

}

void  AAATracerImpl::getAllTraces(std::vector<AAATracer::TraceName> & result)
{
    result.clear();

    for (TraceMapType::iterator it = sv_allTraces.begin(); it != sv_allTraces.end(); ++it) 
    {
        result.push_back(it->second);
    }

}



bool AAATracerImpl::IsGloballyEnabled()
{
    return sv_globallyEnabled;
}

void AAATracerImpl::SetGloballyEnabled(bool to )
{
    sv_globallyEnabled = to;
}

void AAATracerImpl::SetEnableAll(bool to)
{
    for (TraceMapType::iterator it = sv_allTraces.begin(); it != sv_allTraces.end(); ++it) 
    {
        it->second.setActive(to);
    }
}


AAATracer AAATracerImpl::get(AAATracer::TraceName::Value forTrace)
{
    if (sv_startTracerClient == false) {
        forTrace = AAATracer::TraceName::Null;
    }
    return  getLazyConstructor(forTrace);
}


AAATracer AAATracerImpl::getLazyConstructor(AAATracer::TraceName::Value forTrace)
{
    auto traceritr = sv_AAATracerImpl.find(forTrace);

    std::shared_ptr<AAATracerImpl> impl = nullptr;

    if (traceritr != sv_AAATracerImpl.end())
    {
        impl = traceritr->second;
    }
    else
    {
        impl = std::shared_ptr<AAATracerImpl>(new AAATracerImpl(AAATracer::TraceName::getTraceString(forTrace)));
        sv_AAATracerImpl.emplace(std::make_pair(forTrace, impl));
    }
    return  AAATracer(impl);
}

void  AAATracerImpl::init(bool startTracer)
{
    sv_startTracerClient = startTracer;
}

void AAATracerImpl::initializeAllTraces()
{
    AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);

    if (sv_allTraces.size() == 0)
    {
        for (int i = 0; i < static_cast<int>(AAATracer::TraceName::Last); i++)
        {
            AAATracer::TraceName aTrace(static_cast<AAATracer::TraceName::Value>(i));
            std::string traceName = aTrace.to_string();
            sv_allTraces.insert(std::make_pair(traceName, aTrace)).second;

            AAATracer correcpondingTracer = AAATracerImpl::getLazyConstructor(aTrace.getName());
            correcpondingTracer.setEnable(aTrace.isActive());
            if (logger.isDebugEnabled()) {
                std::ostringstream oss;
                oss << "AAATracerImpl::init TracerName<" << traceName << "> found and disabled by default";
                logger.debug(oss.str());
            }
        }
    }
}

class MockMetricProducer : public opentelemetry::sdk::metrics::MetricProducer
{
public:
    MockMetricProducer(std::chrono::microseconds sleep_ms = std::chrono::microseconds::zero())
        : sleep_ms_{ sleep_ms }
    {}

    MetricProducer::Result Produce() noexcept override
    {
        std::this_thread::sleep_for(sleep_ms_);
        data_sent_size_++;
        opentelemetry::sdk::metrics::ResourceMetrics data;
        return { data, MetricProducer::Status::kSuccess };
    }

    size_t GetDataCount() { return data_sent_size_; }

private:
    std::chrono::microseconds sleep_ms_;
    size_t data_sent_size_{ 0 };
};

class MockMetricExporter : public opentelemetry::sdk::metrics::PushMetricExporter
{
public:
    MockMetricExporter() = default;
    opentelemetry::sdk::common::ExportResult Export(
        const opentelemetry::sdk::metrics::ResourceMetrics&) noexcept override;

    opentelemetry::sdk::metrics::AggregationTemporality GetAggregationTemporality(
        opentelemetry::sdk::metrics::InstrumentType) const noexcept override;

    bool ForceFlush(std::chrono::microseconds) noexcept override;

    bool Shutdown(std::chrono::microseconds) noexcept override;
};

class MockMetricReader : public opentelemetry::sdk::metrics::MetricReader
{
public:
    MockMetricReader(std::unique_ptr<opentelemetry::sdk::metrics::PushMetricExporter>);

    MockMetricReader();

    opentelemetry::sdk::metrics::AggregationTemporality GetAggregationTemporality(
        opentelemetry::sdk::metrics::InstrumentType) const noexcept override;

    bool OnForceFlush(std::chrono::microseconds) noexcept override;

    bool OnShutDown(std::chrono::microseconds) noexcept override;

    void OnInitialized() noexcept override;

private:
    std::unique_ptr<opentelemetry::sdk::metrics::PushMetricExporter> exporter_;
};

class MockCollectorHandle : public opentelemetry::sdk::metrics::CollectorHandle
{
public:
    MockCollectorHandle(opentelemetry::sdk::metrics::AggregationTemporality);

    ~MockCollectorHandle() override = default;

    opentelemetry::sdk::metrics::AggregationTemporality GetAggregationTemporality(
        opentelemetry::sdk::metrics::InstrumentType) noexcept override;

private:
    opentelemetry::sdk::metrics::AggregationTemporality temporality_;
};


// MockMetricExporter

opentelemetry::sdk::common::ExportResult MockMetricExporter::Export(const opentelemetry::sdk::metrics::ResourceMetrics& /*resource_metrics*/) noexcept
{
    return opentelemetry::sdk::common::ExportResult::kSuccess;
}

opentelemetry::sdk::metrics::AggregationTemporality MockMetricExporter::GetAggregationTemporality(
    opentelemetry::sdk::metrics::InstrumentType /*instrument_type*/) const noexcept
{
    return opentelemetry::sdk::metrics::AggregationTemporality::kCumulative;
}

bool MockMetricExporter::ForceFlush(std::chrono::microseconds /* timeout */) noexcept
{
    return true;
}

bool MockMetricExporter::Shutdown(std::chrono::microseconds /* timeout */) noexcept
{
    return true;
}

// MockMetricReader
MockMetricReader::MockMetricReader(std::unique_ptr<opentelemetry::sdk::metrics::PushMetricExporter> exporter)
    : exporter_(std::move(exporter))
{}

MockMetricReader::MockMetricReader() : exporter_{ new MockMetricExporter() } {}

opentelemetry::sdk::metrics::AggregationTemporality MockMetricReader::GetAggregationTemporality(
    opentelemetry::sdk::metrics::InstrumentType instrument_type) const noexcept

{
    return exporter_->GetAggregationTemporality(instrument_type);
}

bool MockMetricReader::OnForceFlush(std::chrono::microseconds /* timeout */) noexcept
{
    return true;
}

bool MockMetricReader::OnShutDown(std::chrono::microseconds /* timeout */) noexcept
{
    return true;
}

void MockMetricReader::OnInitialized() noexcept {}

// MockCollectorHandle

MockCollectorHandle::MockCollectorHandle(opentelemetry::sdk::metrics::AggregationTemporality temp) : temporality_(temp) {}

opentelemetry::sdk::metrics::AggregationTemporality MockCollectorHandle::GetAggregationTemporality(
    opentelemetry::sdk::metrics::InstrumentType /* instrument_type */) noexcept
{
    return temporality_;
}





void AAATracerImpl::configure(bool debugConfiguration, opentelemetry::sdk::resource::ResourceAttributes resAttributes)
{
    AAATracerImpl::initializeAllTraces();

    AAALogger logger = AAALogger::get(AAALogger::Logger::Tracer);

    // see C:\git\thirdparty\opentelemetry\1.1.0\include\opentelemetry\exporters\otlp\otlp_environment.h


    if (sv_startTracerClient)
    {
        auto mergedResource = opentelemetry::sdk::resource::Resource::Create(resAttributes);
        {

            std::vector<std::unique_ptr<opentelemetry::sdk::trace::SpanProcessor>> spanProcessors;

            opentelemetry::exporter::otlp::OtlpHttpExporterOptions _HttpOptions;

            auto _httpExporter = opentelemetry::exporter::otlp::OtlpHttpExporterFactory::Create(_HttpOptions);


            auto _batch_processor_opts = opentelemetry::sdk::trace::BatchSpanProcessorOptions();
            // _batch_processor_opts.max_export_batch_size = 5;
            // _batch_processor_opts.max_queue_size = 5;
            // _batch_processor_opts.schedule_delay_millis = std::chrono::milliseconds(256);

            auto _httpBatchSpanProcessor = std::unique_ptr<opentelemetry::sdk::trace::SpanProcessor>(new opentelemetry::sdk::trace::BatchSpanProcessor(std::move(_httpExporter), _batch_processor_opts));

            spanProcessors.push_back(std::move(_httpBatchSpanProcessor));

            if (debugConfiguration)
            {
                // STDOUT SPAN
                auto _ostremExporter = opentelemetry::exporter::trace::OStreamSpanExporterFactory::Create();
                auto _ostremProcessor = std::unique_ptr<opentelemetry::sdk::trace::SpanProcessor>(
                    new opentelemetry::sdk::trace::SimpleSpanProcessor(std::move(_ostremExporter)));

                spanProcessors.push_back(std::move(_ostremProcessor));

            }
            std::shared_ptr<opentelemetry::trace::TracerProvider>  traceProvider = opentelemetry::sdk::trace::TracerProviderFactory::Create(std::move(spanProcessors), mergedResource);


            // Set the global trace provider
            opentelemetry::trace::Provider::SetTracerProvider(traceProvider);

            // set global propagator
            opentelemetry::context::propagation::GlobalTextMapPropagator::SetGlobalPropagator(
                opentelemetry::nostd::shared_ptr<opentelemetry::context::propagation::TextMapPropagator>(
                    new opentelemetry::trace::propagation::HttpTraceContext()));

        }


        bool enableAll = SYS_GetEnvBoolOrDefValue("AAASTARTALLTRACES", debugConfiguration);
        std::ostringstream oss;
        oss << "AAATracerImpl::configure AAASTARTALLTRACES=" << std::boolalpha << enableAll;
        logger.debug(oss.str());
        if (enableAll)
        {
            AAATracerImpl::SetEnableAll(true);
            AAATracerImpl::SetGloballyEnabled(true);
        }
    }
}
void  AAATracerImpl::addResourceAttributes(std::map<std::string, std::string> attributes)
{
    auto tracerProvider = opentelemetry::trace::Provider::GetTracerProvider();
    if (tracerProvider.get() != nullptr)
    {
        auto* sdk_tracerProviderr = dynamic_cast<opentelemetry::sdk::trace::TracerProvider*> (tracerProvider.get());
        if (sdk_tracerProviderr) {
            auto _ra = AAATelemetryImpl::Convert(attributes);
            auto other = opentelemetry::sdk::resource::Resource::Create(_ra);
            auto merged = sdk_tracerProviderr->GetResource().Merge(other);
            // @@ TODO How to set them ? sdk_tracerProviderr->SetResource(merged);
        }
    }
}


void AAATracerImpl::terminate()
{

    for (auto& aTraceImpl : sv_AAATracerImpl)
    {

        int maxloop = 1000;

        do
        {
            std::shared_ptr<AAASpanImpl> activeSpan = aTraceImpl.second->getActiveSpan();

            if (activeSpan != sv_noopspan)
            {
                activeSpan->log("info", "Terminated by AAATracerImpl::terminate");
                activeSpan->finish();
            }
            else
            {
                break;
            }
            --maxloop;
        } while (maxloop > 0);
		if (aTraceImpl.second.get() != nullptr)
        {
            if (aTraceImpl.second->m_OpenTracerImpl.get() != nullptr)
            {
                aTraceImpl.second->m_OpenTracerImpl->CloseWithMicroseconds(1000000);
            }
        }
    }
    sv_AAATracerImpl.clear();
    sv_allTraces.clear();


    static std::shared_ptr<opentelemetry::trace::TracerProvider> noneT;
    opentelemetry::trace::Provider::SetTracerProvider(noneT);

}


AAATracer::AAASpan  AAATracerImpl::startSpan(const std::string& operationName)
{
    if (isEnabled() && sv_globallyEnabled)
    {
        std::shared_ptr<AAASpanImpl> impl = createSpanImpl();
        bool mustBeEnabled = isEnabled();
        impl->setEnabled(mustBeEnabled);

        impl->startSpan(operationName);
        pushActiveSpan(impl);

        return  AAATracer::AAASpan(impl);
    }
    else
    {
        return AAATracer::AAASpan(getNoopSpan());
    }

}

AAATracer::AAASpan AAATracerImpl::continueSpanFrom(const std::string& operationName, const std::string& externalTraceID, AAATracer::LinkNature linkNature)
{
    if (isEnabled() && sv_globallyEnabled)
    {
        std::shared_ptr<AAASpanImpl> impl = createSpanImpl();

        impl->continueSpanFrom(operationName, externalTraceID, linkNature);
        pushActiveSpan(impl);

        return  AAATracer::AAASpan(impl);
    }
    else
    {
        return AAATracer::AAASpan(getNoopSpan());
    }
}


AAATracer::AAASpan AAATracerImpl::continueSpanFrom(const std::string& operationName, std::unordered_map<std::string, std::string >& externalRepresentation, AAATracer::LinkNature linkNature)
{
    if (isEnabled() && sv_globallyEnabled)
    {
        std::shared_ptr<AAASpanImpl> impl = createSpanImpl();

        impl->continueSpanFrom(operationName, externalRepresentation, linkNature);
        pushActiveSpan(impl);

        return  AAATracer::AAASpan(impl);
    }
    else
    {
        return AAATracer::AAASpan(getNoopSpan());
    }
}


std::shared_ptr<AAASpanImpl>&  AAATracerImpl::getNoopSpan()
{
    return sv_noopspan;
}


void AAATracerImpl::pushActiveSpan(std::shared_ptr<AAASpanImpl>& span)
{

    auto search = sv_thread_local_span_map.find(this);
    if (search != sv_thread_local_span_map.end()) {

        search->second.push_back(span);

    }
    else {
        std::vector<std::shared_ptr<AAASpanImpl>> stack;
        stack.push_back(span);
        sv_thread_local_span_map.insert(std::make_pair(this, stack));
    }

}

bool AAATracerImpl::popActiveSpan()
{
    auto search = sv_thread_local_span_map.find(this);
    if (search != sv_thread_local_span_map.end()) {

        std::vector<std::shared_ptr<AAASpanImpl>> &stack = search->second;

        if (stack.size() > 0)
        {
            auto span = stack.back();

            stack.pop_back();
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}



std::shared_ptr<AAASpanImpl>& AAATracerImpl::getActiveSpan()
{
    if (nullptr != m_OpenTracerImpl && sv_globallyEnabled && isEnabled())
    {
        auto active_it = sv_thread_local_span_map.find(this);
        if (active_it != sv_thread_local_span_map.end())
        {
            if (active_it->second.size() > 0)
            {
                return active_it->second.back();
            }
            else
            {
                return AAATracerImpl::getNoopSpan();
            }
        }
    }
    return AAATracerImpl::getNoopSpan();
}

std::shared_ptr<AAASpanImpl> AAATracerImpl::createSpanImpl()
{
    if (nullptr != m_OpenTracerImpl && sv_globallyEnabled && isEnabled())
    {
            std::shared_ptr<AAASpanImpl> spanPtr (std::unique_ptr<AAASpanImpl>(new AAASpanImpl(this)));
            
            this->m_allSpan.insert(spanPtr);
            return spanPtr;

    }
    return AAATracerImpl::getNoopSpan();
}

bool AAATracerImpl::isEnabled() const 
{ 
    return m_isEnabled; 
}

void AAATracerImpl::setEnable(bool to) 
{ 
    m_isEnabled = to;

    m_OpenTracerImpl = opentelemetry::trace::Provider::GetTracerProvider()->GetTracer(m_name, OPENTELEMETRY_SDK_VERSION);

}



// ------------------AAATracer::Initializer

AAATelemetry::Initializer::Initializer(bool defaultStartingBehavour) {
    mTelemetryInitializerImpl = std::make_unique <AAATelemetryInitializerImpl>(defaultStartingBehavour);
}

AAATelemetry::Initializer::~Initializer() {
    mTelemetryInitializerImpl = nullptr;
}

void AAATelemetry::Initializer::configure(std::initializer_list<std::pair<std::string, std::string>> envContext) {
    mTelemetryInitializerImpl->configure(envContext);
}

// ------------------AAATracerInitializerImpl

AAATelemetryInitializerImpl::AAATelemetryInitializerImpl(bool defaultStartingBehavour)
{
    AAATelemetry::init(defaultStartingBehavour);
}

AAATelemetryInitializerImpl::~AAATelemetryInitializerImpl()
{
    AAATracerImpl::terminate();
}

void AAATelemetryInitializerImpl::configure(std::initializer_list<std::pair<std::string, std::string>> envContext)
{
    AAATelemetry::configure(envContext);
}

std::string AAAMeter::buildTemnMetricName(const std::string fromName) 
{ 
    return SYS_Stringer(AAATelemetry::sv_GlobalPrefix, "_", AAATelemetry::sv_ServiceNameConfigured, "_", fromName); 
}

void AAAMeter::fillLabelsMap(LabelDetail fromLabel, std::map<std::string, std::string>& labels)
{
    if (fromLabel == AAAMeter::LabelDetail::ThreadId || fromLabel == AAAMeter::LabelDetail::TraceId || fromLabel == AAAMeter::LabelDetail::SpanId)
    {
        auto myid = std::this_thread::get_id();
        std::stringstream ss;
        ss << myid;
        labels.emplace("thread.id", ss.str()); 
        // https://opentelemetry.io/docs/specs/otel/trace/semantic_conventions/span-general/#general-thread-attributes
    }
    if (fromLabel == AAAMeter::LabelDetail::TraceId || fromLabel == AAAMeter::LabelDetail::SpanId)
    {
        opentelemetry::context::Context  current_ctx = opentelemetry::context::RuntimeContext::GetCurrent();
        opentelemetry::trace::SpanContext span_context = opentelemetry::trace::GetSpan(current_ctx)->GetContext();

        const opentelemetry::trace::TraceId& trace = span_context.trace_id();

        char buf32[32];
        trace.ToLowerBase16(buf32);
        std::string resulttrace = std::string(buf32, sizeof(buf32));
        labels.emplace("trace_id", resulttrace);
        if (fromLabel == AAAMeter::LabelDetail::SpanId)
        {
            const opentelemetry::trace::SpanId& spanId = span_context.span_id();
            char buf16[16];
            spanId.ToLowerBase16(buf16);
            std::string resultspan = std::string(buf16, sizeof(buf16));
            labels.emplace("span_id", resultspan);

        }
    }
}



// --------------------AAAMeter::

std::shared_ptr<AAAHistogramMeterI> AAAMeter::registerHistogramMeter(const std::string& name, const std::string& description , const std::string& unit )
{

    auto found = m_registeredHistogram.find(name);
    if (found != m_registeredHistogram.end()) {
        // @TODO Warn already registered
        return found->second;
    }
    else
    {
        std::string internalName = buildTemnMetricName(name);
        opentelemetry::nostd::unique_ptr <opentelemetry::metrics::Histogram<uint64_t>> histo = m_otel_impl->CreateUInt64Histogram(internalName, description, unit);
        opentelemetry::nostd::shared_ptr <opentelemetry::metrics::Histogram<uint64_t>> histoShared(histo.release());
        std::shared_ptr<AAAHistogramMeterI> meter = std::make_shared<AAAHistogramMeter>(this->m_attributeDetails, histoShared);
        m_registeredHistogram.emplace(name, meter);
        return meter;
    }
};

std::shared_ptr<AAACounterMeterI> AAAMeter::registerCounterMeter(const std::string& name, const std::string& description, const std::string& unit)
{

    auto found = m_registeredCounter.find(name);
    if (found != m_registeredCounter.end()) {
        // @TODO Warn already registered
        return found->second;
    }
    else
    {
        std::string internalName = buildTemnMetricName(name);
        opentelemetry::nostd::unique_ptr <opentelemetry::metrics::Counter<uint64_t>> counter = m_otel_impl->CreateUInt64Counter(internalName, description, unit);
        opentelemetry::nostd::shared_ptr <opentelemetry::metrics::Counter<uint64_t>> counterShared(counter.release());
        std::shared_ptr<AAACounterMeterI> meter = std::make_shared<AAACounterMeter>(this->m_attributeDetails, counterShared);
        m_registeredCounter.emplace(name, meter);
        return meter;
    }
};

std::shared_ptr<AAAUpDownCounterMeterI> AAAMeter::registerUpDownCounterMeter(const std::string& name, const std::string& description, const std::string& unit)
{

    auto found = m_registeredUpDownCounter.find(name);
    if (found != m_registeredUpDownCounter.end()) {
        // @TODO Warn already registered
        return found->second;
    }
    else
    {
        std::string internalName = buildTemnMetricName(name);
        opentelemetry::nostd::unique_ptr <opentelemetry::metrics::UpDownCounter<int64_t>> counter = m_otel_impl->CreateInt64UpDownCounter(internalName, description, unit);
        opentelemetry::nostd::shared_ptr <opentelemetry::metrics::UpDownCounter<int64_t>> counterShared(counter.release());
        std::shared_ptr<AAAUpDownCounterMeterI> meter = std::make_shared<AAAUpDownCounterMeter>(this->m_attributeDetails, counterShared);
        m_registeredUpDownCounter.emplace(name, meter);
        return meter;
    }
};


std::shared_ptr<AAAHistogramMeterI> AAAMeter::getHistogramMeter(const std::string& name) {
    static std::shared_ptr<AAAHistogramMeterI> nullHisto = std::make_shared<AAANullHistogramMeter>();
    if (m_attributeDetails != LabelDetail::MeterDiscared) {
        //@@TODO add a lock
        auto found = m_registeredHistogram.find(name);
        if (found != m_registeredHistogram.end()) {
            return found->second;
        }
        else {
            // @TODO log not registered
            return  nullHisto;
        }
    }
    else {
        return  nullHisto;
    }
};

std::shared_ptr<AAACounterMeterI> AAAMeter::getCounterMeter(const std::string& name) {
    static std::shared_ptr<AAACounterMeterI> nullCounter = std::make_shared<AAANullCounterMeter>();
    if (m_attributeDetails != LabelDetail::MeterDiscared) {
        auto found = m_registeredCounter.find(name);
        if (found != m_registeredCounter.end()) {
            return found->second;
        }
        else {
            // @TODO log not registered
            return  nullCounter;
        }
    }
    else {
        return  nullCounter;
    }
};

std::shared_ptr<AAAUpDownCounterMeterI> AAAMeter::getUpDownCounterMeter(const std::string& name) {
    static std::shared_ptr<AAAUpDownCounterMeterI> nullCounter = std::make_shared<AAANullUpDownCounterMeter>();
    if (m_attributeDetails != LabelDetail::MeterDiscared) {
        auto found = m_registeredUpDownCounter.find(name);
        if (found != m_registeredUpDownCounter.end()) {
            return found->second;
        }
        else {
            // @TODO log not registered
            return  nullCounter;
        }
    }
    else {
        return  nullCounter;
    }
};

void AAAHistogramMeter::Record(int64_t value)
{
   std::map<std::string, std::string> attributes{ };
   Record(value, attributes);
};

void AAAHistogramMeter::Record(int64_t value, std::map<std::string, std::string> attributes)
{
    opentelemetry::context::Context ctx;

    AAAMeter::fillLabelsMap(m_details, attributes);
    m_impl->Record(value, attributes, ctx);
};

void AAACounterMeter::Add(int64_t value)
{
    opentelemetry::context::Context ctx;
    std::map<std::string, std::string> labels{ };

    AAAMeter::fillLabelsMap(m_details, labels);
    m_counterImpl->Add(value, labels, ctx);
};

void AAAUpDownCounterMeter::Add(int64_t value) {
    opentelemetry::context::Context ctx;
    std::map<std::string, std::string> labels{ };

    AAAMeter::fillLabelsMap(m_details, labels);
    m_impl->Add(value, labels, ctx);
};

// ---------------------------------------------------------------

AAAPointMeterAggregator::AAAPointMeterAggregator(AAAMeter::MeterName::Value forMeter, const std::string& metricBaseName) : m_parent(nullptr), m_name(metricBaseName), m_count(0), m_mean(0), /*m_stddev(0), */ m_sum(0), m_mean2(0), m_min(0), m_max(0)
{
    m_InMeter = AAATelemetry::GetMeter(forMeter);
    _otelhistogram = m_InMeter->registerHistogramMeter(metricBaseName);
};

void AAAPointMeterAggregator::recordPoint(int64_t newValue) {
    // https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#Welford's_online_algorithm

    m_count++;
    m_sum += newValue;
    int64_t delta = newValue - m_mean;
    m_mean += delta / m_count;
    int64_t delta2 = newValue - m_mean;
    m_mean2 += delta * delta2;
    if (m_count == 1)
    {
        m_min = newValue;
        m_max = newValue;
    }
    else
    {
        if (newValue < m_min) {
            m_min = newValue;
        }
        if (newValue > m_max) {
            m_max = newValue;
        }
    }
    _otelhistogram->Record(newValue);
}

void AAAPointMeterAggregator::aggregate(const AAAPointMeterAggregator& fromChild)
{

    m_count += fromChild.m_count;
    m_sum += fromChild.m_sum;

    m_mean;

    m_mean2;

    if (m_min > fromChild.m_min)
    {
        m_min = fromChild.m_min;
    }
    if (m_max < fromChild.m_max)
    {
        m_max = fromChild.m_max;
    }

}


void AAAPointMeterAggregator::aggregateInParent()
{
    if (hasParent()) {
        m_parent->aggregate(*this);
    }
}

void AAAPointMeterAggregator::reportMeterAggregatorInCurrentTrace()
{
    AAATracer t = AAATelemetry::GetTracer(AAATracer::TraceName::Importation); //@@TODO SHouldn't it comes from the AAAMeterName ?
    auto actSpan = t.getActiveSpan();

    std::map<std::string, std::string>   _toReport;
    _toReport.emplace("count", std::to_string(m_count));
    _toReport.emplace("sum", std::to_string(m_sum));
    _toReport.emplace("min", std::to_string(m_min));
    _toReport.emplace("max", std::to_string(m_max));
    _toReport.emplace("mean", std::to_string(m_mean));
    if (m_count > 1) {
        _toReport.emplace("stddev", std::to_string(llround(sqrt(m_mean2 / (m_count - 1)))));
    }
    actSpan.addEvent(m_name,_toReport);
}


void AAAPointMeterAggregator::reportAggregatorMetrics()
{
    auto meter = AAATelemetry::GetMeter(AAAMeter::MeterName::Script);
    meter->m_attributeDetails = AAAMeter::LabelDetail::ThreadId;

    auto histMeter = meter->registerHistogramMeter(m_name, "Desc of toto", "ms");

    histMeter->Record(m_sum);

    if (m_InMeter->m_attributeDetails == AAAMeter::LabelDetail::SpanId)
    {
        reportMeterAggregatorInCurrentTrace();
    }
}

void  AAAPointMeterAggregator::clear()
{
    m_count = 0;
    m_mean = 0;
    m_mean2 = 0;
    m_sum = 0;
    m_min = 0;
    m_max = 0;
};
// ---------------------------------------------------------------


thread_local std::map<AAAPointMeterThreadRegistery::AAAMeterIdentifier, std::shared_ptr<AAAPointMeterAggregator>> AAAPointMeterThreadRegistery::sv_thread_local_PointsMetersAggregator;


std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::RegisterPointMeterAggregator(AAAMeter::MeterName::Value forMeter, const std::string& forPointMeterAggregatorName/*, const std::string& description = ""*/)
{
    static const std::string nullStr;
    AAAMeterIdentifier identifier = std::make_tuple(forMeter, nullStr, forPointMeterAggregatorName);
    return internalRegisterPointMeterAggregator(identifier);
}
std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::internalRegisterPointMeterAggregator(AAAMeterIdentifier identifier)
{

    auto pointMetersItr = sv_thread_local_PointsMetersAggregator.find(identifier);

    if (pointMetersItr != sv_thread_local_PointsMetersAggregator.end())
    {
        return pointMetersItr->second;
    }
    else
    {
        auto impl = std::shared_ptr<AAAPointMeterAggregator>(new AAAPointMeterAggregator(std::get<0>(identifier), std::get<2>(identifier)));
        sv_thread_local_PointsMetersAggregator.emplace(std::make_pair(identifier, impl));
        //            impl->registerPointMeterAggregator(forMeter, description, unit);
        return impl;
    }
}

std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::RegisterPointMeterAggregator(const std::shared_ptr<AAAPointMeterAggregator>& withParent, const std::string& forPointMeterAggregatorName/*, const std::string& description = ""*/)
{

    AAAMeterIdentifier identifier = std::make_tuple(withParent->m_InMeter->m_meterNameValue, withParent->m_name, forPointMeterAggregatorName);
    auto result = internalRegisterPointMeterAggregator(identifier);

    result->setParent(withParent);
    return result;

}

 void AAAPointMeterThreadRegistery::UnRegisterAllPointMeterAggregator()
{
    sv_thread_local_PointsMetersAggregator.clear();
}


 void AAAPointMeterThreadRegistery::ReportAllDeclaredMeterAggregator(bool )
 {

     for (auto it = sv_thread_local_PointsMetersAggregator.begin(); it != sv_thread_local_PointsMetersAggregator.end(); ++it)
     {
         if (it->second->hasParent() == true)
         {
             it->second->aggregateInParent();
         }
         if ((it->second->m_InMeter->m_attributeDetails == AAAMeter::LabelDetail::SpanId))
         {

         }
     }

     if (false)
     {
         for (auto it = sv_thread_local_PointsMetersAggregator.begin(); it != sv_thread_local_PointsMetersAggregator.end(); ++it)
         {
             if (it->second->hasParent() == false)
             {
                 it->second->reportAggregatorMetrics();
             }
         }
     }
     else
     {
         //@@TODO
     }
 }

std::shared_ptr<AAAPointMeterAggregator> AAAPointMeterThreadRegistery::GetAggregator(AAAMeter::MeterName::Value forMeter, const std::string& forPointMeterAggregatorName)
{
    return RegisterPointMeterAggregator(forMeter, forPointMeterAggregatorName);
}




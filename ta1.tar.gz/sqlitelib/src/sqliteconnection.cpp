/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

#include <string.h>

#include "unidef.h"
#include "gen.h"
#include "dba.h"
#include "conexcept.h"
#include "qdatetime.h"
#include "icu4aaa.h"
#include "icu4aaadate.h"
#include "callstack.h"

#include "sqliteconnection.h"

using namespace std;

AAAConnection* SqliteConnection::createConnection(const AAAConnectionSpecification& spec, const int& id) {
    return new SqliteConnection(spec, id);
}

/************************************************************************
**
**  Function    :   SqliteConnection::SqliteConnection()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
SqliteConnection::SqliteConnection(const AAAConnectionSpecification& spec, const int& id)
    : DbiConnection(spec, id)
    , m_connection(nullptr)
    , m_statement(nullptr)
    , m_bLastExecStatus(false)
    , m_lastSqlCode(SQLITE_NULL)
    , m_bOutputInParam(false)
    , m_rowPos(0)
{
    this->m_connectToRDBMS = Sqlite;

    DBA_CONNECT_INFO_STP connStp = getConnStructPtr();

    if (connStp)
    {
        connStp->maxRows                                = NO_VALUE;
        connStp->blockMode                              = 0;
        connStp->subscriptionElem.eventNat              = Event_Nature_None;
        connStp->subscriptionElem.auditRecSt            = NullDynSt;
        connStp->subscriptionElem.auditRecStp           = NULL;
        connStp->subscriptionElem.currAction            = NullAction;
        connStp->subscriptionElem.subscripCodifCompoStp = NULL;
        connStp->subscriptionElem.subscripCodifCompoNmb = 0;
        memset(&(connStp->subscriptionElem.creation_d), 0, sizeof(DATETIME_ST));
        connStp->preserveConfirmedFlg                   = FALSE;
        connStp->passwordChange                         = false;
        connStp->timeOut                                = NO_VALUE;
        connStp->poolConnectNo                          = id;
    }
}


/************************************************************************
*   Function             :  SqliteConnection::~SqliteConnection()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
SqliteConnection::~SqliteConnection()
{
    this->disconnect();
}

/************************************************************************
**
**  Function    :   SqliteConnection::isMainDb()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool SqliteConnection::isMainDb(const std::string &sqlName)
{
    if (sqlName.find("dict_") == 0 ||
        sqlName.find("xd_") == 0 ||
        sqlName == "init" ||
        sqlName == "appl_param" ||
        sqlName == "appl_message" ||
        sqlName == "script_definition" ||
        sqlName == "table_modif_stat" ||
        sqlName == "object_modif_stat")
    {
        return true;
    }

    return false;
}


/************************************************************************
**
**  Function    :   SqliteConnection::doConnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool SqliteConnection::doConnect()
{
    const AAALogger& logger = AAALogger::get(AAALogger::Logger::Application);
    logger.log(AAALogger::Level::Info, this->getDescription().getServerName());

    this->m_databaseName = this->getDescription().getServerName();

    if (this->m_databaseName.find(".db") == string::npos)
    {
        SYS_MkPath(this->m_databaseName.c_str());

        if (this->m_dbNameOption.empty() ||
            SqliteConnection::isMainDb(this->m_dbNameOption))
        {
            this->m_databaseName += "/main.db";
        }
        else
        {
            auto database = this->getTargetSessionProperties().getDbName();

            if (database.empty() == false)
            {
                this->getConnSessionPropertiesForUpd().setDbName(database);
                this->m_databaseName += "/" + database;

                SYS_MkPath(this->m_databaseName.c_str());
            }
            this->m_databaseName += "/" + this->m_dbNameOption + ".db";
        }
        this->m_currDbNameOption = this->m_dbNameOption;
    }

    const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
    if (connectionLog.isDebugEnabled())
    {
        std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                              "User : ", this->getSpecification().getCredentials().getUser(), " - ",
                                              "Database: ", this->m_databaseName,
                                              "Connect No: ", this->getId(), " - ",
                                              "SqliteConnection::connect");

        if (connectionLog.isTraceEnabled())
        {
            logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
        }

        connectionLog.debug(logMessage);
    }

    this->m_lastSqlCode = sqlite3_open_v2(this->m_databaseName.c_str(),
                                          &this->m_connection,
                                          SQLITE_OPEN_READWRITE,
                                          nullptr);

    if (this->m_lastSqlCode == SQLITE_CANTOPEN)
    {
        this->m_lastSqlCode = sqlite3_open_v2(this->m_databaseName.c_str(),
                                              &this->m_connection,
                                              SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE,
                                              nullptr);
        sqlite3_user_add(this->m_connection, "aaa", "aaaaaa", 6, TRUE);
    }
    sqlite3_user_authenticate(this->m_connection, "aaa", "aaaaaa", 6);

    return (this->m_lastSqlCode == SQLITE_OK);
}


/************************************************************************
**
**  Function    :   SqliteConnection::doDisconnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool SqliteConnection::doDisconnect()
{
    if (this->m_connection != nullptr)
    {
        this->doReleaseCommand();

        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isDebugEnabled())
        {
            std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                                  "User : ", this->getSpecification().getCredentials().getUser(), " - ",
                                                  "Connect No: ", this->getId(), " - ",
                                                  "SqliteConnection::disconnect");

            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        sqlite3_close(this->m_connection);
        this->m_connection = nullptr;

        this->m_currDbNameOption.clear();
    }

    return true;
}

PTR SqliteConnection::getConnectionPtr()
{
    return this->m_connection;
}

PTR SqliteConnection::getCommandPtr()
{
    return this->m_statement;
}

RET_CODE SqliteConnection::createStatement(const std::string &sql, DBA_ACTION_ENUM action)
{
    this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
    this->startRequest();

    this->m_lastSqlCode = sqlite3_prepare_v2(this->m_connection,           /* Database handle */
                                             sql.c_str(),                  /* SQL statement, UTF-8 encoded */
                                             CAST_INT(sql.length() + 1),   /* Maximum length of zSql in bytes. */
                                             &this->m_statement,           /* OUT: Statement handle */
                                             nullptr);                     /* OUT: Pointer to unused portion of zSql */

    this->manageError();

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_retCode = this->m_lastResultRetCode;
    }

    return this->m_lastResultRetCode;
}

RET_CODE SqliteConnection::doAddBatch()
{
    if (this->m_statement != nullptr &&
        (this->m_lastResultRetCode = this->setParameters()) == RET_SUCCEED)
    {
        this->m_lastSqlCode = sqlite3_step(this->m_statement);

        this->manageError();

        if (this->m_bOutputInParam)
        {
            ID_T newId = sqlite3_last_insert_rowid(this->m_connection);

            for (auto &it : this->getRequestParamMap())
            {
                if (it.second->m_bOutput)
                {
                    SET_ID(it.second->getDynFldStp(), 0, newId);

                    it.second->updOutputData();
                    break;
                }
            }
        }
        sqlite3_reset(this->m_statement);

        return this->m_lastResultRetCode;
    }
    return this->m_lastResultRetCode;
}

RET_CODE SqliteConnection::doExecuteBatch()
{
    if (this->m_statement != nullptr)
    {
        this->getSqlRequest().m_batchOutputSet.clear();

        this->processAllResults(nullptr,
                                NullEntity,
                                NullDynSt,
                                nullptr,
                                nullptr);
    }

    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             :  SqliteConnection:getColumnCount()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SqliteConnection::getColumnCount()
{
    if (this->m_statement != nullptr)
    {
        return sqlite3_column_count(this->m_statement);
    }
    return 0;
}


/************************************************************************
*   Function             :  SqliteConnection:getColumnName()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE SqliteConnection::getColumnName(int colNum, std::string &colName)
{
    if (this->m_statement != nullptr)
    {
        const char * colSqlName = sqlite3_column_name(this->m_statement, colNum - 1);
        if (colSqlName != nullptr)
        {
            colName = colSqlName;
            return RET_SUCCEED;
        }
    }
    return RET_DBA_ERR_DBPROBLEM;
}

/************************************************************************
*   Function             :  SqliteConnection:getColumnType()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE SqliteConnection::getColumnType(int colNum, CTYPE_ENUM &cTypeEn)
{
    if (this->m_statement != nullptr)
    {
        int sqlType = sqlite3_column_type(this->m_statement, colNum - 1);
        cTypeEn = this->getCType(sqlType);

        const char* strType = sqlite3_column_decltype(this->m_statement, colNum - 1);
        if (strType != nullptr)
        {
            cTypeEn = this->getCType(sqlType);
        }
    }
    return RET_DBA_ERR_DBPROBLEM;
}

/************************************************************************
*   Function             :  SqliteConnection:getPrecision()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SqliteConnection::getPrecision(int colNum)
{
    return 0;
}

/************************************************************************
*   Function             :  SqliteConnection:getScale()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SqliteConnection::getScale(int colNum)
{
    return 0;
}

/************************************************************************
*   Function             :  SqliteConnection:getColumnMaxLength()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SqliteConnection::getColumnMaxLength(int colNum)
{
    return 0;
}

/************************************************************************
*   Function             :  SqliteConnection:getColumnDisplaySize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-Sqlite - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SqliteConnection::getColumnDisplaySize(int colNum)
{
    return 0;
}

/************************************************************************
*   Function             :  SqliteConnection:isBcpAllowed()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201112
*
*   Last Modification    :
*
*************************************************************************/
bool SqliteConnection::isBcpAllowed()
{
    return false;
}

/************************************************************************
*   Function             : SqliteConnection::clearPassword()
*
*   Description          :
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        :
*
*   Last modification    :
*
*************************************************************************/
void SqliteConnection::clearPassword()
{

}

bool SqliteConnection::changePassword(const PasswordEncrypted& password)
{
    return this->changePassword(this->getSpecification().getCredentials().getUser(), password);
}
bool SqliteConnection::changePassword(const  std::string& user, const PasswordEncrypted& password)
{
    RequestHelper requestHelper(this);

    PasswordClear newClearPassword = password.getClearPassword();
    const char* newClearPasswordStr = newClearPassword.getPassword();

    this->setCurrentAction(Special);

    auto passwBind = requestHelper.addNewParamString(newClearPasswordStr, String1000Type);
    passwBind->m_sqlTraceHide = true;

    requestHelper.setCommand("alter user " + user + " password ?");
    requestHelper.sendAndGetCommand();

    return (RET_GET_LEVEL(requestHelper.getLastResultRetCode()) != RET_LEV_ERROR);
}

void SqliteConnection::enableOutput()
{
}

void SqliteConnection::disableOutput()
{
}

/************************************************************************
*   Function             :  SqliteConnection::setConnMaxRows
*
*   Description          :  Set the max db read nbr value for select in connection
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SqliteConnection::setConnMaxRows(int maxRow)
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
*   Function             :  SqliteConnection::setDefaultProperties
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SqliteConnection::setDefaultProperties()
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
*   Function             :  SqliteConnection::setDateTimeFormat
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  none
*
*   Creation Date        :
*
*************************************************************************/
void SqliteConnection::setDateTimeFormat(DATE_STYLE_ENUM  inDateTimeStyleEn)
{
}

/************************************************************************
*   Function             : DbiConnection::doStartRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE SqliteConnection::doStartRequest()
{
    if (this->m_dbNameOption != this->m_currDbNameOption)
    {
        this->reconnect();
    }

    if (this->m_batchMode != BatchMode::RowByRow &&
        (this->m_beginTransToDo == true || this->m_transactCpt == 0))
    {
        char* errorMessage = nullptr;
        sqlite3_exec(this->m_connection, "PRAGMA synchronous=OFF", NULL, NULL, &errorMessage);
        this->manageError(errorMessage);
        sqlite3_exec(this->m_connection, "PRAGMA count_changes=OFF", NULL, NULL, &errorMessage);
        this->manageError(errorMessage);
        sqlite3_exec(this->m_connection, "PRAGMA journal_mode=OFF", NULL, NULL, &errorMessage);
        this->manageError(errorMessage);
        sqlite3_exec(this->m_connection, "PRAGMA temp_store=MEMORY", NULL, NULL, &errorMessage);
        this->manageError(errorMessage);
    }

    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             : SqliteConnection::doBeginTransaction()
*
*   Description          : Send a "begin tran" command to the server and retrieve
*                          returned status
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE SqliteConnection::doBeginTransaction()
{
    int isAutoCommit = sqlite3_get_autocommit(this->m_connection);
    if (isAutoCommit == 0)
    {
        char* errorMessage = nullptr;
        sqlite3_exec(this->m_connection, "BEGIN TRANSACTION", NULL, NULL, &errorMessage);
        this->manageError(errorMessage);
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : SqliteConnection::endTransaction()
*
*   Description          : Send a "commit tran" or "rollback tran" command to
*                          the server according to the given status.
*
*   WARNING              : if status is different from TRUE or FALSE or if given
*                          connection number is invalid, no command
*                          is sent to the server to close the transaction and the
*                          tables concerned by the transaction stays locked.
*
*   Arguments            : status       : TRUE or FALSE
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input argument problem
*
*************************************************************************/
RET_CODE SqliteConnection::doEndTransaction(const FLAG_T status)
{
    RET_CODE ret = RET_SUCCEED;

    int isAutoCommit = sqlite3_get_autocommit(this->m_connection);
    if (isAutoCommit == 0)
    {
        char* errorMessage = nullptr;

        switch (status)
        {
            case FALSE:
                sqlite3_exec(this->m_connection, "ROLLBACK TRANSACTION", NULL, NULL, &errorMessage);
                break;
            case TRUE:
                sqlite3_exec(this->m_connection, "COMMIT TRANSACTION", NULL, NULL, &errorMessage);
                break;
        }

        this->manageError(errorMessage);
        ret = this->m_lastResultRetCode;
    }
    return ret;
}

/************************************************************************
*   Function             :  SqliteConnection::setParameters
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SqliteConnection::setParameters()
{
    this->m_lastResultRetCode = RET_SUCCEED;
    this->m_bOutputInParam    = false;

    auto& paramMap = this->getRequestParamMap();

    for (auto &dynFldIt : paramMap)
    {
        DbiInOutData* outputDataPtr = dynFldIt.second;

        int colPos = dynFldIt.first + 1;

        if (outputDataPtr->m_bOutput)
        {
            this->m_bOutputInParam = true;
        }

        if (outputDataPtr->m_bInput)
        {
            if (IS_NULLFLD(outputDataPtr->getDynFldStp(), 0) == FALSE)
            {
                switch (GET_CTYPE(outputDataPtr->m_dataType))
                {
                    case DoubleCType:
                        sqlite3_bind_double(this->m_statement, colPos, GET_DOUBLE(outputDataPtr->getDynFldStp(), 0));
                        break;

                    case IntCType:
                        sqlite3_bind_int(this->m_statement, colPos, GET_INT(outputDataPtr->getDynFldStp(), 0));
                        break;

                    case UIntCType:
                        sqlite3_bind_int(this->m_statement, colPos, static_cast<int>(GET_UINT(outputDataPtr->getDynFldStp(), 0)));
                        break;

                    case UCharCType:
                        sqlite3_bind_int(this->m_statement, colPos, static_cast<int>(GET_UCHAR(outputDataPtr->getDynFldStp(), 0)));
                        break;

                    case ShortCType:
                        sqlite3_bind_int(this->m_statement, colPos, static_cast<int>(GET_SHORT(outputDataPtr->getDynFldStp(), 0)));
                        break;

                    case UShortCType:
                        sqlite3_bind_int(this->m_statement, colPos, static_cast<int>(GET_USHORT(outputDataPtr->getDynFldStp(), 0)));
                        break;

                    case DateTimeStCType:
                    {
                        DATETIME_T     dateTimeSt = GET_DATETIME(outputDataPtr->getDynFldStp(), 0);

                        YEAR_T      yyyy;
                        MONTH_T       mm;
                        DAY_T         dd;
                        HOUR_T         h;
                        MINUTE_T       m;
                        SECOND_T       s;
                        MICROSECOND_T ms;

                        DATE_Get(GET_DATETIME(outputDataPtr->getDynFldStp(), 0).date, &yyyy, &mm, &dd);
                        TIME_Get(GET_DATETIME(outputDataPtr->getDynFldStp(), 0).time, &h, &m, &s, &ms);

                        const int TIME_STRING_LENGTH = 30;
                        char* buffer = static_cast<char*>(CALLOC(TIME_STRING_LENGTH, sizeof(char)));
                        outputDataPtr->setPtrToFree(buffer);

                        // SQLite expected date string format is "YYYY-MM-DD HH:MM:SS.SSS" (there are others too)
                        sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d.%03d", yyyy, mm, dd, h, m, s, ms);
                        sqlite3_bind_text(this->m_statement, colPos, buffer, -1, SQLITE_STATIC);

                        break;
                    }

                    case CharPtrCType:
                    case TextPtrCType:
                    {
                        const char* fieldValue = GET_STRING(outputDataPtr->getDynFldStp(), 0);

                        if (this->getCurrCharsetEn() != CurrentCharsetCode_UTF8)
                        {
                            int cursorLen = static_cast<int>(strlen(fieldValue) + 1);
                            int uCharLen = 0;
                            int isoLen = 0;
                            UChar* cursorUChar = static_cast<UChar*> (CALLOC(cursorLen, sizeof(UChar)));

                            ICU4AAA_ConvertFromDefaultCharSet(fieldValue, cursorLen, cursorUChar, cursorLen, &uCharLen, this->getCurrCharsetEn());

                            cursorLen *= 4;
                            char* cursorUtf8 = static_cast<char*> (CALLOC(cursorLen, sizeof(char)));
                            ICU4AAA_ConvertToUTF8(cursorUChar, uCharLen, cursorUtf8, cursorLen, &isoLen);

                            sqlite3_bind_text(this->m_statement, colPos, cursorUtf8, CAST_INT(strlen(cursorUtf8)), SQLITE_STATIC);

                            FREE(cursorUChar);
                            FREE(cursorUtf8);
                        }
                        else
                        {
                            sqlite3_bind_text(this->m_statement, colPos, fieldValue, CAST_INT(strlen(fieldValue)), SQLITE_STATIC);
                        }
                        break;
                    }

                    case UniCharPtrCType:
                    case UniTextPtrCType:
                    {
                        int written;
                        int capacity = (u_strlen(GET_USTRING(outputDataPtr->getDynFldStp(), 0)) * 4) + 1;
                        char* string = (char*)CALLOC(capacity, sizeof(char));
                        ICU4AAA_ConvertToUTF8(GET_USTRING(outputDataPtr->getDynFldStp(), 0), -1, string, capacity, &written);

                        sqlite3_bind_text(this->m_statement, colPos, string, CAST_INT(strlen(string)), SQLITE_STATIC);
                        FREE(string);
                        break;
                    }

                    case LongLongCType:
                        sqlite3_bind_int64(this->m_statement, colPos, GET_LONGLONG(outputDataPtr->getDynFldStp(), 0));
                        break;

                    case TimeStampCType:
                        sqlite3_bind_int64(this->m_statement, colPos, GET_TIMESTAMP(outputDataPtr->getDynFldStp(), 0));
                        break;

                    case BinaryCType:
                        SYS_BreakOnDebug();
                        break;

                    case ArrayPtrCType:
                    case MultiArrayPtrCType:
                    case VarCharPtrCType:
                    case VarTextPtrCType:
                    case ExtPtrCType:
                    case PtrCType:
                    default:
                        assert(GET_CTYPE(outputDataPtr->m_dataType) == LastCtype);
                }
            }
            else
            {
                sqlite3_bind_null(this->m_statement, colPos);
            }
        }
    }

    return (this->m_lastResultRetCode);
}

/************************************************************************
*   Function             :  SqliteConnection::doSendCommand
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SqliteConnection::doSendCommand(DBA_DYNST_ENUM outputSt) /* PMSTA-34344 - TEB - 190805 */
{
    this->m_lastResultRetCode = RET_SUCCEED;

    string    requestToSend = this->getRequestToSend();

    if ((this->m_lastResultRetCode = this->createStatement(requestToSend, this->getCurrentAction())) == RET_SUCCEED)
    {
        if ((this->m_lastResultRetCode = this->setParameters()) == RET_SUCCEED)
        {
            this->m_lastResultRetCode = this->sendRequest(&this->m_lastResultType);
        }
    }

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        (void)this->getNextResultSet();
    }

    return (this->m_lastResultRetCode);
}

/************************************************************************
*   Function             :  SqliteConnection::sendRequest
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SqliteConnection::sendRequest(DBI_INT * resultType)
{
    this->m_lastResultRetCode = RET_SUCCEED;

    this->m_bLastExecStatus = true;

    if (this->m_bLastExecStatus == false)
    {
        if (this->m_bOutputInParam)
        {
            *resultType = DBI_PARAM_RESULT;
        }
        else
        {
            *resultType = DBI_CMD_SUCCEED;
        }
    }
    else
    {
        *resultType = DBI_ROW_RESULT;
    }

    this->m_lastResultType = *resultType;

    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             : SqliteConnection::doReleaseCommand()
*
*   Description : If Oracle statement in command PTR the we delete the Statement
*
*   Arguments : connectNo : the connection number in the connection
*                                      list.
*
*   Global var.modified : None
*
*   Return : TRUE if ok
*            FALSE if problem
*
*************************************************************************/
RET_CODE SqliteConnection::doReleaseCommand()
{
    this->m_lastSqlCode     = sqlite3_finalize(this->m_statement);
    this->m_statement       = nullptr;
    this->m_bLastExecStatus = false;
    this->m_rowPos          = 0;

    return RET_SUCCEED;
}

/************************************************************************
*   Function             : SqliteConnection::isDbTransactionRequired()
*
*   Description : If we must open a transaction
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool SqliteConnection::isDbTransactionRequired()
{
    int isAutoCommit = sqlite3_get_autocommit(this->m_connection);
    return (isAutoCommit == FALSE);
}

/************************************************************************
*   Function             : SqliteConnection::isDdlGenOnTran()
*
*   Description          :
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool SqliteConnection::isDdlGenOnTran()
{
    return false;
}

/************************************************************************
*   Function             :  SqliteConnection::getDefaultCharset
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  The default charset
*
*   Creation Date        :
*
*************************************************************************/
std::string SqliteConnection::getDefaultCharset()
{
    return "al32utf8";
}

std::string SqliteConnection::getConnectionCharset()
{
    return this->getDefaultCharset();
}

RET_CODE SqliteConnection::setAppContextProperty(const std::string &propertyName, const std::string &propertyValue)
{
    RET_CODE retCode = RET_DBA_ERR_SETPARAM;
    int *rmValue = nullptr, *setValue = nullptr;
    char *getValue = nullptr;

    std::stringstream command;

    command << "select rm_appcontext('TASC_CONTEXT', '" << propertyName << "')";

    if (propertyValue.empty())
    {
        command << ", 0, ''";
    }
    else
    {
        command
            << ", set_appcontext('TASC_CONTEXT', '" << propertyName << "', '" << propertyValue + "')"
            << ", get_appcontext('TASC_CONTEXT', '" << propertyName << "')";
    }
    command << " from dual";

    RequestHelper requestHelper(this);

    requestHelper.setCommand(command.str());

    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(rmValue);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(setValue);
    requestHelper.addNewOutputData(NoteType);
    requestHelper.getBindVariablePtr(getValue);

    if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
    {
        if (*rmValue != 0)
        {
            stringstream msg;
            msg << "Remove appContext error for connection=" << this->getId() << ", Properties=" << propertyName;
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
            retCode = RET_SUCCEED; /* if the rm is not working an error will be raised on NEW else the appContext was not set*/
        }

        if (*setValue == 0 && propertyValue.compare(getValue) == 0)
        {
            retCode = RET_SUCCEED;
        }
        else
        {
            stringstream msg;
            msg << "Set appContext error for connection=" << this->getId() << ", Properties=" << propertyName << ", Value=" << propertyValue;
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
        }
    }

    return retCode;
}

bool SqliteConnection::isUtf16Allowed()
{
    return false;
}

RET_CODE SqliteConnection::prepareReceivedData()
{
    this->m_resultSetPos = 0;
    return true;
}

RET_CODE SqliteConnection::colBind(int            colNum,
    DATATYPE_ENUM  type,
    const std::string &colName,
    DBI_PTR        dataPtr,
    size_t         allocSize,
    DBI_INT       *dataLength,
    DBI_SMALLINT  *nullData,
    bool           dynFldFlag,
    unsigned char *nullIndicatorDynFld,
                                   DbiInOutData* dbiInOutDataPtr)
{
    if (static_cast<int>(this->getRequestBindDataVector().size()) < colNum)
    {
        this->getRequestBindDataVector().resize(colNum);
    }
    DbiBindData &bindData = this->getRequestBindDataVector()[colNum - 1];

    bindData.m_dataType   = type;
    bindData.m_columnNbr  = colNum;
    bindData.m_dbiInOutDataPtr = dbiInOutDataPtr;

    if (dynFldFlag &&
        (GET_CTYPE(type) == CharPtrCType ||
        GET_CTYPE(type) == TextPtrCType ||
        GET_CTYPE(type) == UniCharPtrCType ||
        GET_CTYPE(type) == UniTextPtrCType))
    {
        bindData.m_dataIn = *((void **)dataPtr);
    }
    else
    {
        bindData.m_dataIn = dataPtr;
    }
    bindData.m_dataLength          = dataLength;
    bindData.m_nullValue           = nullData;
    bindData.m_bDynFld             = dynFldFlag;
    bindData.m_nullIndicatorDynFld = nullIndicatorDynFld;
    bindData.m_allocSize           = allocSize;
    bindData.m_columnName          = colName;

    return RET_SUCCEED;
}

RET_CODE SqliteConnection::fetch()
{
    this->m_lastResultRetCode = this->bindRequestOutput();

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        if (this->m_rowPos > 1)
        {
            if (SQLITE_ROW != sqlite3_step(this->m_statement))
            {
                this->m_lastResultType = DBI_CMD_DONE;
                this->m_lastResultRetCode = RET_DBA_INFO_NO_MORE_DATA;
                return this->m_lastResultRetCode;
            }
        }
        this->m_rowPos++;

        for (auto it = this->getRequestBindDataVector().begin(); it != this->getRequestBindDataVector().end(); ++it)
        {
            *it->m_nullValue = DBI_GOODDATA;

            int sqlType = sqlite3_column_type(this->m_statement, it->m_columnNbr - 1);

            switch (sqlType)
            {
                case SQLITE_INTEGER:
                    switch (GET_CTYPE(it->m_dataType))
                    {
                        case IntCType:
                            *(static_cast<int*>(it->m_dataIn)) = sqlite3_column_int(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case UIntCType:
                            *(static_cast<unsigned int*>(it->m_dataIn)) = sqlite3_column_int(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case ShortCType:
                            *(static_cast<short*>(it->m_dataIn)) = sqlite3_column_int(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case UCharCType:
                            *(static_cast<unsigned char*>(it->m_dataIn)) = sqlite3_column_int(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case UShortCType:
                            *(static_cast<unsigned short*>(it->m_dataIn)) = sqlite3_column_int(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case TimeStampCType:
                            *(static_cast<TIMESTAMP_T*>(it->m_dataIn)) = sqlite3_column_int64(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case LongLongCType:
                            *(static_cast<ID_T*>(it->m_dataIn)) = sqlite3_column_int64(this->m_statement, it->m_columnNbr - 1);
                            break;

                        case DoubleCType:
                            *(static_cast<double*>(it->m_dataIn)) = sqlite3_column_double(this->m_statement, it->m_columnNbr - 1);
                            break;

                        default:
                            SYS_BreakOnDebug();
                    }
                    break;

                case SQLITE_FLOAT:

                    switch (GET_CTYPE(it->m_dataType))
                    {
                        case DoubleCType:
                            *(static_cast<double*>(it->m_dataIn)) = sqlite3_column_double(this->m_statement, it->m_columnNbr - 1);
                            break;

                        default:
                            SYS_BreakOnDebug();
                    }

                    break;

                case SQLITE_TEXT:
                    if (IS_STRING_TYPE(it->m_dataType) || IS_USTRING_TYPE(it->m_dataType))
                    {
                        const char* value = reinterpret_cast<const char*>(sqlite3_column_text(this->m_statement, it->m_columnNbr - 1));
                        if (value != nullptr)
                        {
                            strncpy((static_cast<char*>(it->m_dataIn)), value, it->m_allocSize);
                        }
                        else
                        {
                            *it->m_nullValue = DBI_NULLDATA;
                        }
                        break;
                    }
                    else if (it->m_dataType == DatetimeType || it->m_dataType == DateType)
                    {
                        const char* value = reinterpret_cast<const char*>(sqlite3_column_text(this->m_statement, it->m_columnNbr - 1));
                        if (value != nullptr)
                        {
                            QDateTime qDateTime = QDateTime::fromString(value, Qt::ISODateWithMs);

                            if (qDateTime.isValid() == false)
                            {
                                qDateTime = QDateTime::fromString(value, Qt::ISODate);
                            }

                            YEAR_T      yyyy = qDateTime.date().year();
                            MONTH_T       mm = qDateTime.date().month();
                            DAY_T         dd = qDateTime.date().day();
                            HOUR_T         h = qDateTime.time().hour();
                            MINUTE_T       m = qDateTime.time().minute();
                            SECOND_T       s = qDateTime.time().second();
                            MICROSECOND_T ms = qDateTime.time().msec();

                            (static_cast<DATETIME64_ST*>(it->m_dataIn))->setDate(DATE_Put(yyyy, mm, dd));
                            (static_cast<DATETIME64_ST*>(it->m_dataIn))->setTime(TIME_Put(h, m, s, ms));
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                    else
                    {
                        SYS_BreakOnDebug();
                    }
                    break;

                case SQLITE_BLOB:
                    SYS_BreakOnDebug();
                    break;

                case SQLITE_NULL:
                    *it->m_nullValue = DBI_NULLDATA;
                    break;

                default:
                    SYS_BreakOnDebug();
            }

            if (it->m_nullIndicatorDynFld != nullptr)
            {
                SET_BIT((*it->m_nullIndicatorDynFld), BIT_NOTNULLFLG, *it->m_nullValue == DBI_GOODDATA ? TRUE : FALSE);
            }
        }
    }

    return this->m_lastResultRetCode;
}

RET_CODE SqliteConnection::getNextResultSet()
{
    this->m_lastResultRetCode = RET_SUCCEED;
    if (this->m_bLastExecStatus == true)
    {
        int stepResult = sqlite3_step(this->m_statement);
        if (SQLITE_ROW == stepResult)
        {
            this->m_rowPos++;
            this->m_resultSetPos++;
            this->m_lastResultType = DBI_ROW_RESULT;
            this->m_lastResultRetCode = RET_SUCCEED;
        }
        else if (SQLITE_DONE == stepResult)
        {
            this->m_lastResultType = DBI_CMD_DONE;
            this->m_lastResultRetCode = RET_DBA_INFO_NO_MORE_DATA;
        }
        else
        {
            this->m_lastSqlCode = stepResult;
            this->manageError();
        }
    }
    else
    {
        this->m_lastResultRetCode = RET_DBA_INFO_NO_MORE_DATA;
    }
    return this->m_lastResultRetCode;
}

RET_CODE SqliteConnection::copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP bindData, DBA_DYNST_ENUM dynStEnum)
{
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   SqliteConnection::processAllResults()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE SqliteConnection::processAllResults(DBI_INT       *status,
    OBJECT_ENUM    object,
    DBA_DYNST_ENUM dynSt,
    DBA_DYNFLD_STP record,
    DBA_PROC_STP   procedure)
{
    if (this->m_lastResultRetCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        this->m_lastResultRetCode = RET_SUCCEED;
    }

    if (status != nullptr)
    {
        *status = 1;  /* PMSTA-46731 - DDV - 211124 - 1 means SUCCESS and 0 means ERROR */
    }

    return this->m_lastResultRetCode;
}



/************************************************************************
*   Function             : SqliteConnection::cancellDbRequest()
*
*   Description          : Cancel all results pending
*
*   Arguments            : connectNo : a connection number in the connection
*                                      list
*                          level     : CONNECTION_LEVEL or COMMAND_LEVEL
*                          mode      : CANCEL_CURRENT or CANCEL_ATTN or
*                                      CANCEL_ALL
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*
*************************************************************************/
RET_CODE SqliteConnection::cancelDbRequest(int level, int mode)
{
    this->m_bLastExecStatus = false;

    if (((level != CONNECTION_LEVEL) && (level != COMMAND_LEVEL)) || ((mode != CANCEL_CURRENT) && (mode != CANCEL_ATTN) && (mode != CANCEL_ALL)))
    {
        char          errMsg[256];

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            sprintf(errMsg, "Connection (" szFormatPointer "), thread (" szFormatPointer "), level (%s), mode (%s)",
                (void*)this->getConnStructPtr(),
                DBA_GetCurrThread(),
                (level == CONNECTION_LEVEL) ? "Connection" :
                (level == COMMAND_LEVEL) ? "Command" :
                "Unknown",
                (mode == CANCEL_CURRENT) ? "Cancel current" :
                (mode == CANCEL_ATTN) ? "Cancel attn" :
                (mode == CANCEL_ALL) ? "Cancel all" :
                "Unknown");

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SqliteConnection::cancelDbRequest", errMsg);
        }
        else
        {
            sprintf(errMsg, "SqliteConnection::cancelDbRequest. Invalid argument. Connection (" szFormatPointer "), thread (" szFormatPointer "), level (%s), mode (%s)",
                (void*)this->getConnStructPtr(),
                DBA_GetCurrThread(),
                (level == CONNECTION_LEVEL) ? "Connection" :
                (level == COMMAND_LEVEL) ? "Command" :
                "Unknown",
                (mode == CANCEL_CURRENT) ? "Cancel current" :
                (mode == CANCEL_ATTN) ? "Cancel attn" :
                (mode == CANCEL_ALL) ? "Cancel all" :
                "Unknown");

            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }

    this->releaseCommand();

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   SqliteConnection::getTransState()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
int SqliteConnection::getTransState()
{
    return 0;
}

std::string SqliteConnection::endOfCmd()
{
    return ";";
}

RET_CODE SqliteConnection::getLastCmdRetCode()
{
    return this->m_lastResultRetCode;
}


RET_CODE SqliteConnection::getCmdRetCode(int msgIdx)
{
    if (msgIdx < this->m_msgStack.size())
    {
        //return this->m_msgErrorHelper.getRetCode(static_cast<Sqlite::SqlCode>(this->m_msgStack.getMember(msgIdx).rdbmsMsgNb));
    }
    return RET_SUCCEED;
}

bool SqliteConnection::isSamePasswordMsg()
{
    return false;
}

bool SqliteConnection::isWarningMsgToHide(const DbaErrmsgInfosClass &)
{
    return false;
}

bool SqliteConnection::convParamFromPos(std::string &, std::string::size_type &, int, const std::string&)
{
    /* Keep the ? */
    return true;
}

RET_CODE SqliteConnection::convertToRetCode(int SqliteCode)
{
    if (SqliteCode)
    {
        //return this->m_msgErrorHelper.getRetCode(static_cast<Sqlite::SqlCode>(SqliteCode));
    }
    return RET_SUCCEED;
}

int SqliteConnection::getSqliteDataType(DATATYPE_ENUM dataType)
{
    switch (GET_CTYPE(dataType))
    {
    case DoubleCType:
        return SQLITE_FLOAT;
        break;

    case UIntCType:
    case IntCType:
    case ShortCType:
    case UShortCType:
    case UCharCType:
        return SQLITE_INTEGER;
        break;

    case DateTimeStCType:
        return SQLITE_TEXT;
        break;

    case CharPtrCType:
    case UniCharPtrCType:
        return SQLITE_TEXT;
        break;

    case TextPtrCType:
    case UniTextPtrCType:
        return SQLITE_TEXT;
        break;

    case LongLongCType:
    case TimeStampCType:
    case BinaryCType:
        return SQLITE_INTEGER;
        break;

    case ArrayPtrCType:
    case MultiArrayPtrCType:
    case VarCharPtrCType:
    case VarTextPtrCType:
    case ExtPtrCType:
    case PtrCType:
    default:
        assert(dataType == LastCtype);
    }

    return SQLITE_NULL;
}



CTYPE_ENUM SqliteConnection::getCType(int sqlType)
{
    switch (sqlType)
    {
        case SQLITE_NULL:
            return LastCtype;
            break;

        case SQLITE_FLOAT:
            return DoubleCType;
            break;

        case SQLITE_INTEGER:
            return IntCType;
            break;

        case SQLITE_TEXT:
            return CharPtrCType;
            break;

        case SQLITE_BLOB:
            return BinaryCType;
            break;

        default:
            assert(sqlType == LastCtype);
    }

    return LastCtype;
}

void SqliteConnection::manageError()
{
    if (this->m_lastSqlCode != SQLITE_OK &&
        this->m_lastSqlCode != SQLITE_DONE)
    {
        const char* errorMessage = sqlite3_errmsg(this->m_connection);
        this->manageError(errorMessage);
    }
}

void SqliteConnection::manageError(const char* errorMessage)
{
    if (errorMessage != nullptr)
    {
        DbaMsgStackMemberClass& msgMember = this->m_msgStack.getNewMember();

        msgMember.msgOrigin = ServerHandler;
        msgMember.rdbmsMsgNb = this->m_lastSqlCode;

        msgMember.retCode = this->m_msgErrorHelper.getRetCode(msgMember.rdbmsMsgNb);
        msgMember.msgString = errorMessage;
        this->m_lastResultRetCode = msgMember.retCode;
        this->m_msgStack.lastMsgNb = msgMember.rdbmsMsgNb;

        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isInfoEnabled())
        {
            std::string	logMessage = SYS_Stringer("No: ", msgMember.retCode, " - ",
                                                  "NativeError: ", msgMember.rdbmsMsgNb, " - ",
                                                  "Severity: ", msgMember.severityStr, " - ",
                                                  "SqlState: ", msgMember.stateStr, " - ",
                                                  "ErrorMsg: ", msgMember.msgString);
            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        if (EV_ExtractFile)
        {
            std::string			sqlTraceStr("error in the upper call with error: ");
            fputs(sqlTraceStr.append(msgMember.msgString).c_str(), EV_ExtractFile);
            fputs("\n", EV_ExtractFile);
            fflush(EV_ExtractFile);
        }
    }
}

Sqlite_MsgError::Sqlite_MsgError()
{
}

Sqlite_MsgError::~Sqlite_MsgError()
{
}

RET_CODE Sqlite_MsgError::getRetCode(int errorCodeEn)
{
    /* Add here Sqlite Error Message to match with a RET_CODE */
    switch (errorCodeEn)
    {
    case SQLITE_CONSTRAINT_UNIQUE:
        return RET_SRV_LIB_ERR_DUPLICATEKEY;

    case MSG_INFO_EXTERNAL_SEQ:
        return RET_DBA_INFO_EXTERNAL_SEQ;

    default:
        RET_CODE err = RET_DBA_ERR_DBPROBLEM;

        if (isValidRetCode(err))
        {
            return err;
        }
        return RET_DBA_ERR_DBPROBLEM;
    }
}

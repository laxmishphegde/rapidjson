/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SqliteLIB01_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define MATH_H
#define TIME_H
#define STDLIB_H
#define STRING_H
#define STDARG_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "msg.h"
#include "date.h"
#include "dba.h"
#include "dbi.h"
#include "crypt.h"
#include "conlocprovider.h"
#include "dbiconnection.h"
#include "sqliteconnection.h"

#include "ddlgenfromfile.h"
#include "ddlgenvar.h"
#include "aaasql.h"

#include <conv.h>

#include "str.h"

#include <iomanip>

using namespace std;


/************************************************************************
*   Function             : SQLITE_InitializeContext()
*
*   Description          : Allocate an application context, install
*                          message handlers and conversion functions for
*                          dates fields.
*
*   Arguments            : installMemoryCallBack    If memory callback must be installed
*
*   Functions call       : None
*
*   Last modif.          :
*
*************************************************************************/
RET_CODE SQLITE_InitializeContext(const bool)
{
	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SQLITE_GetDatatypeFromDesc()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Last Modification    :
*************************************************************************/
DATATYPE_ENUM SQLITE_GetDatatypeFromDesc(CTYPE_ENUM cType, int &dataSize, int precision, int scale)
{
    DATATYPE_ENUM dataType, defaultDataType = NullDataType;
    string nativType;
    int defaultDataSize = 0;

    switch (cType)
    {
        case DoubleCType:
            nativType = "numeric";
            defaultDataType = NumberType;
            break;
        case CharPtrCType:
            nativType = "varchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UIntCType:
        case IntCType:
            nativType = "int";
            defaultDataType = IntType;
            break;
        case ShortCType:
        case UShortCType:
            nativType = "smallint";
            defaultDataType = SmallintType;
            break;
        case UCharCType:
            nativType = "tinyint";
            defaultDataType = FlagType;
            break;
        case DateTimeStCType:
            defaultDataType = DatetimeType;
            break;
        case TextPtrCType:
            nativType = "text";
            defaultDataType = TextType;
            defaultDataSize = MAX_USHORT;
            break;
        case UniCharPtrCType:
            nativType = "univarchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UniTextPtrCType:
            nativType = "unitext";
            defaultDataType = UniTextType;
            defaultDataSize = MAX_USHORT;
            break;
        case LongLongCType:
            nativType = "numeric";
            defaultDataType = IdType;
            break;
        case TimeStampCType:
            nativType = "timestamp";
            defaultDataType = TimeStampType;
            break;
        case BinaryCType:
            nativType = "binary";
            defaultDataType = BinaryType;
            break;

        case VarTextPtrCType:
        case VarCharPtrCType:
        case PtrCType:
        case ExtPtrCType:
        case ArrayPtrCType:
        case MultiArrayPtrCType:
            nativType = "unknown";
            break;
    }

    dataType = DBA_GetDataTypeFromEquivType(Sybase, nativType, precision, scale);

    if (dataType == NullDataType)
    {
        dataType = defaultDataType;
        if (defaultDataSize)
        {
            dataSize = defaultDataSize;
        }
    }
    return dataType;
}

/************************************************************************
*   Function             : SQLITE_ManagedSqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request. Bind status
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*                          ConnectNo       : pointer on a connection number (to be used if DBA_SET_CONN set)
*                          option          : DBA_SET_CONN or UNUSED
*                          status          : pointer on status to be binded
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE SQLITE_ManagedSqlExec(AAASQL_CONTEXT_STP  sqlContextStp, int*)
{
    MemoryPool           mp;
    RET_CODE             retCode = RET_SUCCEED;

    DbiConnection       *dbiConnPtr = sqlContextStp->connHelperPtr->getConnection();
    bool                 bAssignVars = false;
    bool                 bPrintMsgOnly = false;
    bool                 bISqlBehavior = (sqlContextStp->verboseLevel == VerboseLevel_iSQL ||
                                          sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet ||
                                          sqlContextStp->verboseLevel == VerboseLevel_Align);


    DBA_ACTION_ENUM action = DBA_ACTION_ENUM::Custom;

    if (sqlContextStp->firstCmd.compare("select") == 0)
    {
        action = DBA_ACTION_ENUM::Select;
    }
    else if (sqlContextStp->firstCmd.compare("insert") == 0 ||
             sqlContextStp->firstCmd.compare("update") == 0)
    {
        action = DBA_ACTION_ENUM::Update;
    }

    if (sqlContextStp->ddlGenContext.m_bOutputMessage)
    {
        dbiConnPtr->sqlExecSt("create temporary table output_message (prompt_message text null);");

        sqlContextStp->sqlCmd += "\nselect prompt_message from output_message;";
    }

    RequestHelper requestHelper(dbiConnPtr);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = sqlContextStp->connHelperPtr->getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.SQLITE_ManagedSqlExec";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    /* PMSTA-37366 - LJE - 200429 */
    if (sqlContextStp->scriptDdlGenPtr &&
        sqlContextStp->scriptDdlGenPtr->bKeepData == true &&
        sqlContextStp->scriptDdlGenPtr->bKeepResultSetData == false)
    {
        sqlContextStp->scriptDdlGenPtr->freeResultSetData();
    }

    requestHelper.setExternalMsgManagement(true);
    requestHelper.setCommand(sqlContextStp->sqlCmd);

    retCode = requestHelper.sendCommandForFetch();

    if (RET_GET_LEVEL(retCode) != RET_LEV_ERROR && retCode != RET_DBA_INFO_NO_MORE_DATA)
    {
        bool             bRowResPrinted = false;
        int                   row_count = 0;
        size_t             resultSetIdx = 0;

        do
        {
            int colCountNbr = requestHelper.getColumnCount();

            AAASQL_OUTPUT_PARAM_STP outParamTab = (AAASQL_OUTPUT_PARAM_STP)mp.calloc(colCountNbr, sizeof(AAASQL_OUTPUT_PARAM_ST));

            /* PMSTA-37366 - LJE - 200429 */
            vector<DdlGenDataField> ddlGenDataFieldVector;

            if (sqlContextStp->scriptDdlGenPtr &&
                sqlContextStp->scriptDdlGenPtr->bKeepData == true &&
                sqlContextStp->scriptDdlGenPtr->bKeepResultSetData == false)
            {
                ddlGenDataFieldVector.resize(colCountNbr);
            }

            for (int i = 0; i < colCountNbr; i++)
            {
                int colNum = i + 1;

                string colName;
                requestHelper.getColumnName(colNum, colName);

                strcpy(outParamTab[i].colName, colName.c_str());

                CTYPE_ENUM cType = LastCtype;
                requestHelper.getColumnType(colNum, cType);

                outParamTab[i].precision = requestHelper.getPrecision(colNum);
                outParamTab[i].scale     = requestHelper.getScale(colNum);
                outParamTab[i].dataSize  = requestHelper.getColumnMaxLength(colNum);
                outParamTab[i].colWith   = requestHelper.getColumnDisplaySize(colNum);

                outParamTab[i].dataType  = SQLITE_GetDatatypeFromDesc(cType, outParamTab[i].dataSize, outParamTab[i].precision, outParamTab[i].scale);

                if (outParamTab[i].dataType == TextType ||
                    outParamTab[i].dataType == UniTextType)
                {
                    outParamTab[i].dataSize = GET_MAXLEN(TextType);
                }

                if (outParamTab[i].dataType == NullDataType)
                {
                    outParamTab[i].dataType = String1000Type;
                }

                requestHelper.addNewOutputData(outParamTab[i].dataType);
            }

            FLAG_T done = 0;
            size_t rowNumber = 0, alignNbr;
            stringstream headStream;
            stringstream  sepStream;

            if (bISqlBehavior &&
                sqlContextStp->bPrintHeader)
            {
                headStream << sqlContextStp->separator;
                sepStream << sqlContextStp->separator;
            }

            for (int i = 0; i < colCountNbr; i++)
            {
                alignNbr = DBA_GetDataTypeAlignSize(outParamTab[i].dataType, strlen(outParamTab[i].colName), outParamTab[i].colWith, false, outParamTab[i].szAlignPos);
                sepStream << STRING_FillPatern(string(), alignNbr, '-') << sqlContextStp->separator;

                outParamTab[i].colWith = static_cast<int>(alignNbr);

                if (bISqlBehavior &&
                    sqlContextStp->bPrintHeader)
                {
                    char szFmt[128];
                    string headStr;
                    sprintf(szFmt, "%s%ds%s", "%-", (int)alignNbr, sqlContextStp->separator.c_str());
                    if (sqlContextStp->bHeaderLowerCase)
                    {
                        SYS_StringFormat(headStr, szFmt, lower(outParamTab[i].colName).c_str());
                    }
                    else
                    {
                        SYS_StringFormat(headStr, szFmt, outParamTab[i].colName);
                    }
                    headStream << headStr;
                }

                if (i == 0 && strcmp(outParamTab[i].colName, "get_variable") == 0)
                {
                    bAssignVars = true;
                }
                else if (colCountNbr == 1 && strcasecmp(outParamTab[i].colName, "prompt_message") == 0)
                {
                    bPrintMsgOnly = true;
                }

                if (ddlGenDataFieldVector.empty() == false)
                {
                    ddlGenDataFieldVector[i].setSqlName(outParamTab[i].colName);
                    ddlGenDataFieldVector[i].dataType = outParamTab[i].dataType;
                }
            }

            if (bAssignVars == false &&
                bPrintMsgOnly == false &&
                sqlContextStp->verboseLevel == VerboseLevel_iSQL &&
                sqlContextStp->bPrintHeader)
            {
                cout << headStream.str() << endl
                    << sepStream.str() << endl;
            }

            bool bConcat = false;
            int  rank = 0;

            while (requestHelper.fetch() == RET_SUCCEED)
            {
                if (rowNumber == 0 &&
                    sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet &&
                    bAssignVars == false &&
                    bPrintMsgOnly == false &&
                    sqlContextStp->bPrintHeader)
                {
                    cout << headStream.str() << endl
                        << sepStream.str() << endl;
                }

                stringstream currValueStream;

                if (bAssignVars == false &&
                    bPrintMsgOnly == false &&
                    bISqlBehavior &&
                    sqlContextStp->bPrintHeader)
                {
                    cout << sqlContextStp->separator;
                }

                for (int i = 0; i < colCountNbr; i++)
                {
                    // int colNum = i + 1;

                    if (bConcat == false)
                    {
                        currValueStream.clear();
                        currValueStream.str(string());
                    }

                    if (bAssignVars && i == 0)
                    {
                        if (outParamTab[i].dataType != String1000Type && strcmp(requestHelper.getCharPtrValue(i), "++VAR++") != 0)
                        {
                            if (bISqlBehavior &&
                                sqlContextStp->bPrintHeader)
                            {
                                cout << headStream.str() << endl;
                                cout << sepStream.str() << endl;
                            }
                            bAssignVars = false;
                        }
                        else
                        {
                            continue;
                        }
                    }

                    if (requestHelper.isNullValue(i))
                    {
                        outParamTab[i].nullInd = -1;

                        currValueStream << "NULL";
                    }
                    else
                    {
                        outParamTab[i].nullInd = 0;

                        switch (GET_CTYPE(outParamTab[i].dataType))
                        {
                            case LongLongCType:
                            case TimeStampCType:
                            case BinaryCType:
                                currValueStream << requestHelper.getLongLongValue(i);
                                break;

                            case CharPtrCType:
                            case TextPtrCType:
                            {
                                currValueStream << requestHelper.getCharPtrValue(i);

                                if (bAssignVars)
                                {
                                    size_t lenght = strlen(outParamTab[i].colName);

                                    stringstream concatStr;
                                    concatStr << "$" << rank++;

                                    if (lenght > 2 && strcmp(&(outParamTab[i].colName[lenght - 2]), concatStr.str().c_str()) == 0)
                                    {
                                        bConcat = true;
                                    }
                                    else
                                    {
                                        rank = 0;
                                        bConcat = false;
                                    }
                                }
                                break;
                            }

                            case UniCharPtrCType:
                            case UniTextPtrCType:
                            {
                                char * tmp = (char*)CALLOC(GET_SIZEAL32(outParamTab[i].dataSize), sizeof(char));

                                if (tmp != nullptr && !ICU4AAA_ConvertToUTF8(requestHelper.getUCharPtrValue(i), -1, tmp, GET_SIZEAL32(outParamTab[i].dataSize) * sizeof(char), NULL))
                                {
                                    currValueStream << tmp;
                                }
                                else
                                {
                                    currValueStream << "N/A";
                                }

                                FREE(tmp);
                            }
                            break;

                            case DoubleCType:
                                currValueStream << CONV_DoubleToNumericString(
                                    requestHelper.getDoubleValue(i), outParamTab[i].precision, outParamTab[i].scale);
                                break;

                            case IntCType:
                                currValueStream << requestHelper.getIntValue(i);
                                break;

                            case UIntCType:
                                currValueStream << requestHelper.getUIntValue(i);
                                break;

                            case ShortCType:
                            {
                                std::string strOut;
                                SYS_StringFormat(strOut, "%d", int(requestHelper.getShortValue(i)));
                                currValueStream << strOut;
                            }
                            break;

                            case UShortCType:
                            {
                                std::string strOut;
                                SYS_StringFormat(strOut, "%d", int(requestHelper.getUShortValue(i)));
                                currValueStream << strOut;
                            }
                            break;

                            case UCharCType:
                            {
                                std::string strOut;
                                SYS_StringFormat(strOut, "%d", int(requestHelper.getUCharValue(i)));
                                currValueStream << strOut;
                            }
                            break;

                            case DateTimeStCType:
                            {
                                string dateStr;
                                DATETIME_ToSqlStr(dateStr,
                                                  requestHelper.getDateTimeValue(i),
                                                  bAssignVars ? sqlContextStp->inDateTimeStyleEn : sqlContextStp->outDateTimeStyleEn,
                                                  outParamTab[i].dataType == DateType ? TimeStyle_None : TimeStyle_24);
                                currValueStream << dateStr;

                                if (bAssignVars)
                                {
                                    DdlGenVar *currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(outParamTab[i].colName);

                                    if (currVar)
                                    {
                                        currVar->dateTimeValue = requestHelper.getDateTimeValue(i);
                                    }
                                }
                                break;
                            }

                            default:
                                currValueStream << "N/A";
                                break;
                        }
                    }

                    if (bAssignVars)
                    {
                        if (bConcat == false)
                        {
                            DdlGenVar *currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(outParamTab[i].colName);
                            if (currVar)
                            {
                                currVar->setValue(currValueStream.str());
                                currVar->bNullValue    = requestHelper.isNullValue(i);
                                currVar->bRuntimeValue = true;
                            }
                        }
                    }
                    else
                    {
                        if (bPrintMsgOnly == false &&
                            bISqlBehavior &&
                            (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                            outParamTab[i].szAlignPos[0] != 0)
                        {
                            cout << STRING_FillPatern(currValueStream.str(), outParamTab[i].colWith, ' ');
                        }

                        cout << currValueStream.str();

                        if (bPrintMsgOnly == false)
                        {
                            if (bISqlBehavior &&
                                (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                                outParamTab[i].szAlignPos[0] == 0)
                            {
                                cout << STRING_FillPatern(currValueStream.str(), outParamTab[i].colWith, ' ');
                            }

                            cout << sqlContextStp->separator;
                        }
                    }

                    if (ddlGenDataFieldVector.empty() == false)
                    {
                        if (requestHelper.isNullValue(i))
                        {
                            ddlGenDataFieldVector[i].bNullValue = true;
                        }
                        else
                        {
                            ddlGenDataFieldVector[i].value      = currValueStream.str();
                            ddlGenDataFieldVector[i].bNullValue = false;
                        }
                    }
                }

                /* PMSTA-37366 - LJE - 200429 */
                if (sqlContextStp->scriptDdlGenPtr &&
                    sqlContextStp->scriptDdlGenPtr->bKeepData == true &&
                    sqlContextStp->scriptDdlGenPtr->bKeepResultSetData == false)
                {
                    sqlContextStp->scriptDdlGenPtr->addResultSetData(resultSetIdx, rowNumber, ddlGenDataFieldVector);
                }

                cout << endl;

                rowNumber++;
                if (bAssignVars)
                {
                    done = 1;
                }
            }

            bRowResPrinted = true;

            if (sqlContextStp->verboseLevel != VerboseLevel_None &&
                sqlContextStp->verboseLevel != VerboseLevel_Align &&
                sqlContextStp->bPrintRowCount &&
                (sqlContextStp->verboseLevel != VerboseLevel_HideEmptyResultSet || rowNumber > 0))
            {
                if (rowNumber > 0)
                {
                    cout << endl;
                }

                if (rowNumber == 1)
                {
                    cout << "(" << rowNumber << " row affected)" << endl;
                }
                else if (bPrintMsgOnly == false)
                {
                    cout << "(" << rowNumber << " rows affected)" << endl;
                }
            }

            resultSetIdx++;
        } while (requestHelper.getLastResultType() == DBI_ROW_RESULT);

        if (bRowResPrinted == false)
        {
            if (sqlContextStp->verboseLevel != VerboseLevel_None &&
                sqlContextStp->verboseLevel != VerboseLevel_Align &&
                sqlContextStp->bPrintRowCount)
            {
                if (row_count == 1)
                {
                    cout << endl << "(" << row_count << " row affected)" << endl;
                }
                else
                {
                    cout << endl << "(" << row_count << " rows affected)" << endl;
                }
            }
        }
    }

    if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
    {
        dbiConnPtr->endTransaction(FALSE);
    }
    else
    {
        if (retCode == RET_DBA_INFO_NO_MORE_DATA)
        {
            retCode = RET_SUCCEED;
        }
        dbiConnPtr->endTransaction(TRUE);
    }

    if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
    {
        bool bKeepError = false;
        for (auto msgStructIt = dbiConnPtr->m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != dbiConnPtr->m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
        {
            string      msgTxt;
            RET_CODE    locRetCode = msgStructIt->retCode;

            if (dbiConnPtr->isWarningMsgToHide(*msgStructIt))
            {
                locRetCode = RET_SUCCEED;
                msgTxt = msgStructIt->getMsgString().c_str();
            }
            else
            {
                bKeepError = true;
                SYS_StringFormat(msgTxt,
                                 "Msg Error (SQL) %d: %s",
                                 msgStructIt->rdbmsMsgNb,
                                 msgStructIt->getMsgString().c_str());
            }

            sqlContextStp->ddlGenPtr->printMsg(retCode, msgTxt);
        }
        if (bKeepError == false)
        {
            retCode = RET_SUCCEED;
        }
    }

    if (sqlContextStp->verboseLevel != VerboseLevel_None &&
        sqlContextStp->verboseLevel != VerboseLevel_Align)
    {
        cout << "(return status = " << (retCode == RET_SUCCEED ? 0 : retCode) << ")" << endl;
    }

    dbiConnPtr->releaseCommand();

    if (sqlContextStp->ddlGenContext.m_bOutputMessage)
    {
        dbiConnPtr->sqlExecSt("drop table output_message;");
    }

    return(retCode);
}


/************************************************************************
**
** Function    : SQLITE_PrintVersion
**
** Description : Print to stdout the Sqlite library actually loaded
**
** Arguments   :
**
** Return      : None
**
************************************************************************/
void SQLITE_PrintVersion()
{
	char buff[128];
	sprintf(buff, "Sqlite client library version: %s", SQLITE_VERSION);
	printf(buff);
}

/************************************************************************
**  Function    :   SQLITE_InsUpdNuoUser
**
**  Description :   Insert or update an Sqlite user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-37366 - LJE - 191112
**
**  Modif.      :
**
*************************************************************************/
RET_CODE SQLITE_InsUpdNuoUser(DBA_DYNFLD_STP       inputData,
                             DbiConnection&       dbiConn,
                             bool                 isInsert)
{
    SYSNAME_T	   code;
    char          *userPasswd;
    char		   buffer[256];
    AUTO_PASSWORD_CLEAR(buffer, sizeof(buffer));
    char		   errMsg[256];
    RET_CODE       retCode = RET_SUCCEED;
    DBA_DYNFLD_STP AdmArgStp;
    FLAG_T         hasDBLoginflg = TRUE;
    DbiConnection* dbiConnAdm = nullptr;
    SYSNAME_T	   admLogin;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SQLITE_InsUpdNuoUser", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    code[0] = END_OF_STRING;

    if (IS_NULLFLD(inputData, A_ApplUser_Cd) == FALSE)
    {
        strcpy(code, GET_SYSNAME(inputData, A_ApplUser_Cd));
    }

    if (IS_NULLFLD(inputData, A_ApplUser_HasDbLoginFlg) == FALSE) /* PMSTA-14286 - EFE - 120608 */
    {
        hasDBLoginflg = GET_ENUM(inputData, A_ApplUser_HasDbLoginFlg);
    }

    SYBASE_LOGIN_ACTION_ENUM loginActionEn = LoginActionEn_Nothing;
    FLAG_T lockActionFlg = FALSE;

    if (IS_NULLFLD(inputData, A_ApplUser_LoginActionEn) == FALSE)
        loginActionEn = (SYBASE_LOGIN_ACTION_ENUM)GET_ENUM(inputData, A_ApplUser_LoginActionEn);
    if (IS_NULLFLD(inputData, A_ApplUser_LockActionFlg) == FALSE)
        lockActionFlg = GET_FLAG(inputData, A_ApplUser_LockActionFlg);

    if (!hasDBLoginflg && loginActionEn != LoginActionEn_Drop)
        return retCode;

    if (nullptr != GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin))
    {
        strcpy(admLogin, GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin));
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SQLITE_InsUpdNuoUser", "ApplUser_SuperUserLogin");
        retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    /* The use of interface to create users needs to
    verify that the user given is administrator. */

    if (retCode == RET_SUCCEED && SYS_IsBatchMode())
    {
        if (DBA_CheckDbAdminUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd)))) != RET_SUCCEED)
        {
            sprintf(errMsg, "user %s is not entitled to create/lock/unlock user %s", admLogin, code);
            auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

            msgStructSt.msgString = errMsg;
            msgStructSt.techMsg = FALSE;
            retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
        }
    }

    if (retCode == RET_SUCCEED && DBA_OpenConnForUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd))), &dbiConnAdm, ROLE_DBSO) != RET_SUCCEED)
    {
        sprintf(errMsg, "unable to open a connection with ROLE_DBSO, user %s", admLogin);
        auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
        msgStructSt.msgString = errMsg;
        msgStructSt.techMsg = FALSE;
        retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    bool isEmpty = true;

    if (retCode == RET_SUCCEED && hasDBLoginflg == TRUE && (isInsert || loginActionEn == LoginActionEn_Add))
    {
        if ((AdmArgStp = ALLOC_DYNST(Adm_Arg)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_CODE(AdmArgStp, Adm_Arg_Sysname, code);

        retCode = DBA_Notif2(DictUser
                             , UNUSED
                             , Adm_Arg
                             , AdmArgStp
                             , DBA_SET_CONN | DBA_NO_CLOSE
                             , dbiConn
                             , UNUSED
        );

        if (retCode == RET_SUCCEED && GET_INT(AdmArgStp, Adm_Arg_ReturnStatus) != 0)
        {   /* insert */
            userPasswd = NULL;
            if (IS_NULLFLD(inputData, A_ApplUser_UserPassword) == FALSE)
            {
                /*  replace double quote in userPasswd  */
                userPasswd = GEN_ManageQuoteInPassword(GET_INFO(inputData, A_ApplUser_UserPassword));
            }

            /* Test if password is long enough for Sqlite. */
            if (userPasswd == NULL ||
                SYS_StrLen(code) < 1 || SYS_StrLen(userPasswd) < 6)
            {
                auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                msgStructSt.msgString = "Invalid username or password";
                msgStructSt.techMsg = FALSE;

                retCode = RET_DBA_ERR_PASSWD_TOO_SHORT;
            }

            /* The use of interface to create users needs to
            verify that the user given is administrator. */
            if (retCode == RET_SUCCEED && DBI_CheckUserRole(*dbiConnAdm, "sso_role") == false)
            {
                sprintf(errMsg, "user %s is not entitled to create user %s", admLogin, code);
                auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                msgStructSt.msgString = errMsg;
                msgStructSt.techMsg = FALSE;
                DBA_PasswordClear(userPasswd, strlen(userPasswd));            /* PMSTA-18094 - 130514 - PMO */
                retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
            }

            if (retCode == RET_SUCCEED)
            {
                RequestHelper requestHelper(dbiConnAdm);

                const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdNuoUser";
                    sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                }

                int *countNbr = nullptr;
                requestHelper.addNewParamCharPtr(GET_SYSNAME(inputData, A_ApplUser_Cd), SysnameType);
                requestHelper.setCommand("select count(*) from system.users where username = upper(?)");
                requestHelper.addNewOutputData(IntType);
                requestHelper.getBindVariablePtr(countNbr);

                if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
                {
                    requestHelper.finishRequest();

                    if (countNbr != nullptr &&
                        (requestHelper.getIntValue(1) == 0 || countNbr == 0))
                    {
                        std::string mainDbSqlName;
                        GEN_GetApplInfo(ApplSqlDbName, mainDbSqlName);

                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto &sqlTrace = dbiConnAdm->getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.InsUpdNuoUser";
                            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                        }

                        requestHelper.setCommand("create user " + string(GET_SYSNAME(inputData, A_ApplUser_Cd)) + " password '" + userPasswd + "'");

                        if((retCode = requestHelper.sendAndGetCommand()) == RET_SUCCEED)
                        {
                            requestHelper.finishRequest();

                            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                            {
                                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                                sqlTrace.m_procedure = "DynSql.InsUpdNuoUser";
                                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                            }

                            requestHelper.setCommand("grant " + mainDbSqlName + ".TRIPLEA to " + string(GET_SYSNAME(inputData, A_ApplUser_Cd)));
                            retCode = requestHelper.sendAndGetCommand();
                        }
                    }
                    else
                    {
                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto &sqlTrace = dbiConnAdm->getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.InsUpdNuoUser";
                            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                        }

                        requestHelper.setCommand("alter user " + string(GET_SYSNAME(inputData, A_ApplUser_Cd)) + " password '" + userPasswd + "'");
                        retCode = requestHelper.sendAndGetCommand();
                    }
                }
                isEmpty = false;
            }

            /*  Free allocated memory               */
            if (userPasswd != NULL)
            {
                DBA_PasswordClear(userPasswd, strlen(userPasswd));
                FREE(userPasswd);
            }
        }
        FREE_DYNST(AdmArgStp, Adm_Arg);
    }

    DBA_EndConnection(&dbiConnAdm);

    return retCode;
}

/************************************************************************
**  Function    :   SQLITE_InsApplUserById
**
**  Description :   Create a new user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-37366 - LJE - 191112
**  Modif.      :
**
*************************************************************************/
RET_CODE SQLITE_InsApplUserById(DBA_DYNFLD_STP       inputData,
                               DbiConnection&       dbiConn)
{
    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SQLITE_InsApplUserById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    RET_CODE retCode = SQLITE_InsUpdNuoUser(inputData,
                                           dbiConn,
                                           true);
    return retCode;
}


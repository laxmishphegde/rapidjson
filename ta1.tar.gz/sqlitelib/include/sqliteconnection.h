/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef SqliteConnection_H_
#define SqliteConnection_H_

#include "dbiconnection.h"
#include "sqlite3.h"
#include "sqlite3userauth.h"

class Sqlite_MsgError : protected DBI_MsgError
{
public:
    Sqlite_MsgError();
    ~Sqlite_MsgError();
    Sqlite_MsgError &          operator=(const Sqlite_MsgError &) = delete;
    static RET_CODE         getRetCode(int);
};

class SqliteConnection : protected DbiConnection
{
public:
    SqliteConnection(const AAAConnectionSpecification& spec, const int& id);
    virtual ~SqliteConnection();

    SqliteConnection            (const SqliteConnection &) = delete;
    SqliteConnection & operator=(const SqliteConnection &) = delete;

    static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id);

    static bool  isMainDb(const std::string &);

    virtual bool doConnect();
    virtual bool doDisconnect();
    virtual PTR  getConnectionPtr();
    virtual PTR  getCommandPtr();

    virtual RET_CODE createStatement(const std::string &sql, DBA_ACTION_ENUM action);

    virtual RET_CODE         doAddBatch();
    virtual RET_CODE         doExecuteBatch();

    virtual int              getColumnCount();
    virtual RET_CODE         getColumnName(int, std::string &);
    virtual RET_CODE         getColumnType(int, CTYPE_ENUM &);
    virtual int              getPrecision(int);
    virtual int              getScale(int);
    virtual int              getColumnMaxLength(int);
    virtual int              getColumnDisplaySize(int);

    virtual bool             isBcpAllowed();

    virtual void clearPassword();

    virtual void manageError();
    void         manageError(const char *);

    virtual std::string getDefaultCharset();
    virtual std::string getConnectionCharset();
    virtual bool        isUtf16Allowed();

    bool changePassword(const PasswordEncrypted& password);
    bool changePassword(const  std::string& user, const PasswordEncrypted& password);

    void setDateTimeFormat(DATE_STYLE_ENUM  inDateTimeStyleEn);

    RET_CODE setAppContextProperty(const std::string &propertyName, const std::string &propertyValue);

    virtual RET_CODE doStartRequest();
    virtual RET_CODE doBeginTransaction();
    virtual RET_CODE doEndTransaction(const FLAG_T status);
    virtual RET_CODE getNextResultSet();
    virtual RET_CODE setParameters();
    virtual RET_CODE doSendCommand(DBA_DYNST_ENUM outputSt = NullDynSt);    /* PMSTA-34344 - TEB - 190805 */
    virtual RET_CODE sendRequest(DBI_INT * resultType);
    virtual RET_CODE doReleaseCommand();
    virtual bool     isDbTransactionRequired();
    virtual bool     isDdlGenOnTran();
    virtual RET_CODE prepareReceivedData();
    virtual RET_CODE colBind(int, DATATYPE_ENUM, const std::string&, DBI_PTR, size_t, DBI_INT*, DBI_SMALLINT*, bool dynFldFlag, unsigned char* nullIndicatorDynFld, DbiInOutData*);
    virtual RET_CODE fetch();
    virtual RET_CODE copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM);
    virtual RET_CODE processAllResults(DBI_INT       *status,
                                       OBJECT_ENUM    object,
                                       DBA_DYNST_ENUM dynSt,
                                       DBA_DYNFLD_STP record,
                                       DBA_PROC_STP   procedure);

    virtual RET_CODE cancelDbRequest(int level, int mode);

    /* Command RDBMS depends part */
    virtual std::string             endOfCmd();

    virtual RET_CODE setDefaultProperties();
    virtual RET_CODE setConnMaxRows(int);
    
    virtual void enableOutput();
    virtual void disableOutput();

    virtual int getTransState();

    virtual RET_CODE getLastCmdRetCode();
    virtual RET_CODE getCmdRetCode(int msgNo);

    virtual bool isSamePasswordMsg();
    virtual bool isWarningMsgToHide(const DbaErrmsgInfosClass &);

    virtual bool        convParamFromPos(std::string&, std::string::size_type&, int, const std::string&);

    virtual RET_CODE                convertToRetCode(int);

    int                             getSqliteDataType(DATATYPE_ENUM);

    CTYPE_ENUM                      getCType(int sqlType);

    sqlite3                        *m_connection;                     /* pointer on CONNECTION structure, depends of the RDBMS */

protected:

    sqlite3_stmt                   *m_statement;                      /* pointer on COMMAND structure*/

private:

    bool              m_bLastExecStatus;
    int               m_lastSqlCode;

    Sqlite_MsgError   m_msgErrorHelper;

    bool              m_bOutputInParam;

    size_t            m_rowPos;

    std::string       m_currDbNameOption;
    std::string       m_databaseName;
};

#endif

/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef SQLITELIB_H
#define SQLITELIB_H
#include "dba.h"
#include "dbi.h"

class DbiConnection;
extern RET_CODE SQLITE_InitializeContext(const bool);

extern RET_CODE SQLITE_ManagedSqlExec(AAASQL_CONTEXT_STP sqlContextStp, int* status);
extern void     SQLITE_PrintVersion();

extern RET_CODE SQLITE_InsApplUserById(DBA_DYNFLD_STP, DbiConnection&);

#endif
/************************************************************************
**      END        sqlitelib.h
*************************************************************************/

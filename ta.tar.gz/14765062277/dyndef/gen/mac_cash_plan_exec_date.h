/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CashPlanExecDateStatusEn     GET_A_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateStatusEn>  (GET_ENUM(p, A_CashPlanExecDate_StatusEn)));
}
inline CashPlanExecDateStatusEn     GET_S_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateStatusEn>  (GET_ENUM(p, S_CashPlanExecDate_StatusEn)));
}
inline CashPlanExecDateCompliantEn  GET_A_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateCompliantEn>  (GET_ENUM(p, A_CashPlanExecDate_CompliantEn)));
}
inline CashPlanExecDateCompliantEn  GET_S_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateCompliantEn>  (GET_ENUM(p, S_CashPlanExecDate_CompliantEn)));
}

inline CashPlanExecDateStatusEn     _GET_A_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateStatusEn>  (_GET_ENUM(p, A_CashPlanExecDate_StatusEn)));
}
inline CashPlanExecDateStatusEn     _GET_S_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateStatusEn>  (_GET_ENUM(p, S_CashPlanExecDate_StatusEn)));
}
inline CashPlanExecDateCompliantEn  _GET_A_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateCompliantEn>  (_GET_ENUM(p, A_CashPlanExecDate_CompliantEn)));
}
inline CashPlanExecDateCompliantEn  _GET_S_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CashPlanExecDateCompliantEn>  (_GET_ENUM(p, S_CashPlanExecDate_CompliantEn)));
}

inline void                         SET_A_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p, CashPlanExecDateStatusEn enumValue)
{
    SET_ENUM(p, A_CashPlanExecDate_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CashPlanExecDate_StatusEn(DBA_DYNFLD_STP p, CashPlanExecDateStatusEn enumValue)
{
    SET_ENUM(p, S_CashPlanExecDate_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p, CashPlanExecDateCompliantEn enumValue)
{
    SET_ENUM(p, A_CashPlanExecDate_CompliantEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CashPlanExecDate_CompliantEn(DBA_DYNFLD_STP p, CashPlanExecDateCompliantEn enumValue)
{
    SET_ENUM(p, S_CashPlanExecDate_CompliantEn, static_cast<unsigned char>(enumValue));
}


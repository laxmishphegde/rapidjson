/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CaseManagementNatEn          GET_A_CaseManagement_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementNatEn>  (GET_ENUM(p, A_CaseManagement_NatEn)));
}
inline CaseManagementNatEn          GET_S_CaseManagement_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementNatEn>  (GET_ENUM(p, S_CaseManagement_NatEn)));
}
inline CaseManagementSubNatEn       GET_A_CaseManagement_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementSubNatEn>  (GET_ENUM(p, A_CaseManagement_SubNatEn)));
}
inline CaseManagementSubNatEn       GET_S_CaseManagement_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementSubNatEn>  (GET_ENUM(p, S_CaseManagement_SubNatEn)));
}
inline CaseManagementStatusEn       GET_A_CaseManagement_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementStatusEn>  (GET_ENUM(p, A_CaseManagement_StatusEn)));
}
inline CaseManagementStatusEn       GET_S_CaseManagement_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementStatusEn>  (GET_ENUM(p, S_CaseManagement_StatusEn)));
}

inline CaseManagementNatEn          _GET_A_CaseManagement_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementNatEn>  (_GET_ENUM(p, A_CaseManagement_NatEn)));
}
inline CaseManagementNatEn          _GET_S_CaseManagement_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementNatEn>  (_GET_ENUM(p, S_CaseManagement_NatEn)));
}
inline CaseManagementSubNatEn       _GET_A_CaseManagement_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementSubNatEn>  (_GET_ENUM(p, A_CaseManagement_SubNatEn)));
}
inline CaseManagementSubNatEn       _GET_S_CaseManagement_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementSubNatEn>  (_GET_ENUM(p, S_CaseManagement_SubNatEn)));
}
inline CaseManagementStatusEn       _GET_A_CaseManagement_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementStatusEn>  (_GET_ENUM(p, A_CaseManagement_StatusEn)));
}
inline CaseManagementStatusEn       _GET_S_CaseManagement_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CaseManagementStatusEn>  (_GET_ENUM(p, S_CaseManagement_StatusEn)));
}

inline void                         SET_A_CaseManagement_NatEn(DBA_DYNFLD_STP p, CaseManagementNatEn enumValue)
{
    SET_ENUM(p, A_CaseManagement_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CaseManagement_NatEn(DBA_DYNFLD_STP p, CaseManagementNatEn enumValue)
{
    SET_ENUM(p, S_CaseManagement_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CaseManagement_SubNatEn(DBA_DYNFLD_STP p, CaseManagementSubNatEn enumValue)
{
    SET_ENUM(p, A_CaseManagement_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CaseManagement_SubNatEn(DBA_DYNFLD_STP p, CaseManagementSubNatEn enumValue)
{
    SET_ENUM(p, S_CaseManagement_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CaseManagement_StatusEn(DBA_DYNFLD_STP p, CaseManagementStatusEn enumValue)
{
    SET_ENUM(p, A_CaseManagement_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CaseManagement_StatusEn(DBA_DYNFLD_STP p, CaseManagementStatusEn enumValue)
{
    SET_ENUM(p, S_CaseManagement_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline FiscalPeriodCompoNatEn       GET_A_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FiscalPeriodCompoNatEn>  (GET_ENUM(p, A_FiscalPeriodCompo_NatEn)));
}
inline FiscalPeriodCompoNatEn       GET_S_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FiscalPeriodCompoNatEn>  (GET_ENUM(p, S_FiscalPeriodCompo_NatEn)));
}
inline InstrNatEn                   GET_A_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_FiscalPeriodCompo_InstrNatEn)));
}
inline InstrNatEn                   GET_S_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_FiscalPeriodCompo_InstrNatEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  GET_S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn)));
}

inline FiscalPeriodCompoNatEn       _GET_A_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FiscalPeriodCompoNatEn>  (_GET_ENUM(p, A_FiscalPeriodCompo_NatEn)));
}
inline FiscalPeriodCompoNatEn       _GET_S_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FiscalPeriodCompoNatEn>  (_GET_ENUM(p, S_FiscalPeriodCompo_NatEn)));
}
inline InstrNatEn                   _GET_A_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_FiscalPeriodCompo_InstrNatEn)));
}
inline InstrNatEn                   _GET_S_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_FiscalPeriodCompo_InstrNatEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn)));
}

inline void                         SET_A_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p, FiscalPeriodCompoNatEn enumValue)
{
    SET_ENUM(p, A_FiscalPeriodCompo_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_FiscalPeriodCompo_NatEn(DBA_DYNFLD_STP p, FiscalPeriodCompoNatEn enumValue)
{
    SET_ENUM(p, S_FiscalPeriodCompo_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_FiscalPeriodCompo_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_FiscalPeriodCompo_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_FiscalPeriodCompo_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_FiscalPeriodCompo_FiscalPeriodFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, S_FiscalPeriodCompo_FiscalPeriodFreqUnitEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdLegalEntityTypeEn       GET_A_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, A_DocChecklistDef_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       GET_S_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, S_DocChecklistDef_LegalEntityTypeEn)));
}

inline ThirdLegalEntityTypeEn       _GET_A_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, A_DocChecklistDef_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       _GET_S_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, S_DocChecklistDef_LegalEntityTypeEn)));
}

inline void                         SET_A_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, A_DocChecklistDef_LegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DocChecklistDef_LegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, S_DocChecklistDef_LegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusIndicatorObjectiveUsageNatEn GET_A_BusIndicatorObjective_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusIndicatorObjectiveUsageNatEn>  (GET_ENUM(p, A_BusIndicatorObjective_UsageNatEn)));
}

inline BusIndicatorObjectiveUsageNatEn _GET_A_BusIndicatorObjective_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusIndicatorObjectiveUsageNatEn>  (_GET_ENUM(p, A_BusIndicatorObjective_UsageNatEn)));
}

inline void                         SET_A_BusIndicatorObjective_UsageNatEn(DBA_DYNFLD_STP p, BusIndicatorObjectiveUsageNatEn enumValue)
{
    SET_ENUM(p, A_BusIndicatorObjective_UsageNatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline IrlInstrumentRuleStatusEn    GET_A_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlInstrumentRuleStatusEn>  (GET_ENUM(p, A_IrlApplUserRule_StatusEn)));
}
inline IrlInstrumentRuleStatusEn    GET_S_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlInstrumentRuleStatusEn>  (GET_ENUM(p, S_IrlApplUserRule_StatusEn)));
}

inline IrlInstrumentRuleStatusEn    _GET_A_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlInstrumentRuleStatusEn>  (_GET_ENUM(p, A_IrlApplUserRule_StatusEn)));
}
inline IrlInstrumentRuleStatusEn    _GET_S_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlInstrumentRuleStatusEn>  (_GET_ENUM(p, S_IrlApplUserRule_StatusEn)));
}

inline void                         SET_A_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p, IrlInstrumentRuleStatusEn enumValue)
{
    SET_ENUM(p, A_IrlApplUserRule_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_IrlApplUserRule_StatusEn(DBA_DYNFLD_STP p, IrlInstrumentRuleStatusEn enumValue)
{
    SET_ENUM(p, S_IrlApplUserRule_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrMktsegOverrideOverrideScopeEn GET_A_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktsegOverrideOverrideScopeEn>  (GET_ENUM(p, A_InstrMktsegOverride_OverrideScopeEn)));
}
inline InstrMktsegOverrideOverrideScopeEn GET_S_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktsegOverrideOverrideScopeEn>  (GET_ENUM(p, S_InstrMktsegOverride_OverrideScopeEn)));
}

inline InstrMktsegOverrideOverrideScopeEn _GET_A_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktsegOverrideOverrideScopeEn>  (_GET_ENUM(p, A_InstrMktsegOverride_OverrideScopeEn)));
}
inline InstrMktsegOverrideOverrideScopeEn _GET_S_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktsegOverrideOverrideScopeEn>  (_GET_ENUM(p, S_InstrMktsegOverride_OverrideScopeEn)));
}

inline void                         SET_A_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p, InstrMktsegOverrideOverrideScopeEn enumValue)
{
    SET_ENUM(p, A_InstrMktsegOverride_OverrideScopeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InstrMktsegOverride_OverrideScopeEn(DBA_DYNFLD_STP p, InstrMktsegOverrideOverrideScopeEn enumValue)
{
    SET_ENUM(p, S_InstrMktsegOverride_OverrideScopeEn, static_cast<unsigned char>(enumValue));
}


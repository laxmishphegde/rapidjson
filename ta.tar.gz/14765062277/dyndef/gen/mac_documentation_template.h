/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DocumentationTemplateStatusEn GET_A_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateStatusEn>  (GET_ENUM(p, A_DocumentationTemplate_StatusEn)));
}
inline DocumentationTemplateStatusEn GET_S_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateStatusEn>  (GET_ENUM(p, S_DocumentationTemplate_StatusEn)));
}
inline DocumentationTemplateDocSyntaxEn GET_A_DocumentationTemplate_DocSyntaxEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateDocSyntaxEn>  (GET_ENUM(p, A_DocumentationTemplate_DocSyntaxEn)));
}

inline DocumentationTemplateStatusEn _GET_A_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateStatusEn>  (_GET_ENUM(p, A_DocumentationTemplate_StatusEn)));
}
inline DocumentationTemplateStatusEn _GET_S_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateStatusEn>  (_GET_ENUM(p, S_DocumentationTemplate_StatusEn)));
}
inline DocumentationTemplateDocSyntaxEn _GET_A_DocumentationTemplate_DocSyntaxEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocumentationTemplateDocSyntaxEn>  (_GET_ENUM(p, A_DocumentationTemplate_DocSyntaxEn)));
}

inline void                         SET_A_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p, DocumentationTemplateStatusEn enumValue)
{
    SET_ENUM(p, A_DocumentationTemplate_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DocumentationTemplate_StatusEn(DBA_DYNFLD_STP p, DocumentationTemplateStatusEn enumValue)
{
    SET_ENUM(p, S_DocumentationTemplate_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DocumentationTemplate_DocSyntaxEn(DBA_DYNFLD_STP p, DocumentationTemplateDocSyntaxEn enumValue)
{
    SET_ENUM(p, A_DocumentationTemplate_DocSyntaxEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DataDependencyNatEn          GET_A_DataDependency_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DataDependencyNatEn>  (GET_ENUM(p, A_DataDependency_NatEn)));
}

inline DataDependencyNatEn          _GET_A_DataDependency_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DataDependencyNatEn>  (_GET_ENUM(p, A_DataDependency_NatEn)));
}

inline void                         SET_A_DataDependency_NatEn(DBA_DYNFLD_STP p, DataDependencyNatEn enumValue)
{
    SET_ENUM(p, A_DataDependency_NatEn, static_cast<unsigned char>(enumValue));
}


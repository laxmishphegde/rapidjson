/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InducementFeesReimbursementEn GET_A_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InducementFeesReimbursementEn>  (GET_ENUM(p, A_InducementFees_ReimbursementEn)));
}
inline InducementFeesReimbursementEn GET_S_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InducementFeesReimbursementEn>  (GET_ENUM(p, S_InducementFees_ReimbursementEn)));
}

inline InducementFeesReimbursementEn _GET_A_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InducementFeesReimbursementEn>  (_GET_ENUM(p, A_InducementFees_ReimbursementEn)));
}
inline InducementFeesReimbursementEn _GET_S_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InducementFeesReimbursementEn>  (_GET_ENUM(p, S_InducementFees_ReimbursementEn)));
}

inline void                         SET_A_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p, InducementFeesReimbursementEn enumValue)
{
    SET_ENUM(p, A_InducementFees_ReimbursementEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InducementFees_ReimbursementEn(DBA_DYNFLD_STP p, InducementFeesReimbursementEn enumValue)
{
    SET_ENUM(p, S_InducementFees_ReimbursementEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictAttrCalcEn               GET_A_DictAttr_CalcEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrCalcEn>  (GET_ENUM(p, A_DictAttr_CalcEn)));
}
inline DictAttrPermAuthFlg          GET_A_DictAttr_PermAuthFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (GET_ENUM(p, A_DictAttr_PermAuthFlg)));
}
inline DictAttrEditEn               GET_A_DictAttr_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (GET_ENUM(p, A_DictAttr_EditEn)));
}
inline DictAttrSecurityLevelEn      GET_A_DictAttr_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrSecurityLevelEn>  (GET_ENUM(p, A_DictAttr_SecurityLevelEn)));
}
inline DictAttrWidgetEn             GET_A_DictAttr_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (GET_ENUM(p, A_DictAttr_WidgetEn)));
}
inline DictAttrTascViewEn           GET_A_DictAttr_TascViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrTascViewEn>  (GET_ENUM(p, A_DictAttr_TascViewEn)));
}
inline DictAttrEnumValue            GET_A_DictAttr_EnumValue(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEnumValue>  (GET_ENUM(p, A_DictAttr_EnumValue)));
}
inline DictAttrFkPresentationEn     GET_A_DictAttr_FkPresentationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrFkPresentationEn>  (GET_ENUM(p, A_DictAttr_FkPresentationEn)));
}
inline XdEntityXdStatusEn           GET_A_DictAttr_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictAttr_XdStatusEn)));
}
inline XdAttribRefDeleteRuleEn      GET_A_DictAttr_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (GET_ENUM(p, A_DictAttr_RefDeleteRuleEn)));
}
inline XdAttribRefSecurityRuleEn    GET_A_DictAttr_RefSecurityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefSecurityRuleEn>  (GET_ENUM(p, A_DictAttr_RefSecurityRuleEn)));
}
inline XdAttribRefCheckRuleEn       GET_A_DictAttr_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (GET_ENUM(p, A_DictAttr_RefCheckRuleEn)));
}
inline XdAttribExportEn             GET_A_DictAttr_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (GET_ENUM(p, A_DictAttr_ExportEn)));
}
inline XdEntityLastModifEn          GET_A_DictAttr_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_DictAttr_ObjModifStatEn)));
}
inline XdEntityFeatureFeatureEn     GET_A_DictAttr_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (GET_ENUM(p, A_DictAttr_FeatureEn)));
}
inline XdAttribModelBankEn          GET_A_DictAttr_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (GET_ENUM(p, A_DictAttr_ModelBankEn)));
}
inline XdAttribMeSpecialisationEn   GET_A_DictAttr_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (GET_ENUM(p, A_DictAttr_MeSpecialisationEn)));
}
inline XdAttribOutboxPublishEn      GET_A_DictAttr_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (GET_ENUM(p, A_DictAttr_OutboxPublishEn)));
}

inline DictAttrCalcEn               _GET_A_DictAttr_CalcEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrCalcEn>  (_GET_ENUM(p, A_DictAttr_CalcEn)));
}
inline DictAttrPermAuthFlg          _GET_A_DictAttr_PermAuthFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (_GET_ENUM(p, A_DictAttr_PermAuthFlg)));
}
inline DictAttrEditEn               _GET_A_DictAttr_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (_GET_ENUM(p, A_DictAttr_EditEn)));
}
inline DictAttrSecurityLevelEn      _GET_A_DictAttr_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrSecurityLevelEn>  (_GET_ENUM(p, A_DictAttr_SecurityLevelEn)));
}
inline DictAttrWidgetEn             _GET_A_DictAttr_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (_GET_ENUM(p, A_DictAttr_WidgetEn)));
}
inline DictAttrTascViewEn           _GET_A_DictAttr_TascViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrTascViewEn>  (_GET_ENUM(p, A_DictAttr_TascViewEn)));
}
inline DictAttrEnumValue            _GET_A_DictAttr_EnumValue(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEnumValue>  (_GET_ENUM(p, A_DictAttr_EnumValue)));
}
inline DictAttrFkPresentationEn     _GET_A_DictAttr_FkPresentationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrFkPresentationEn>  (_GET_ENUM(p, A_DictAttr_FkPresentationEn)));
}
inline XdEntityXdStatusEn           _GET_A_DictAttr_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictAttr_XdStatusEn)));
}
inline XdAttribRefDeleteRuleEn      _GET_A_DictAttr_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (_GET_ENUM(p, A_DictAttr_RefDeleteRuleEn)));
}
inline XdAttribRefSecurityRuleEn    _GET_A_DictAttr_RefSecurityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefSecurityRuleEn>  (_GET_ENUM(p, A_DictAttr_RefSecurityRuleEn)));
}
inline XdAttribRefCheckRuleEn       _GET_A_DictAttr_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (_GET_ENUM(p, A_DictAttr_RefCheckRuleEn)));
}
inline XdAttribExportEn             _GET_A_DictAttr_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (_GET_ENUM(p, A_DictAttr_ExportEn)));
}
inline XdEntityLastModifEn          _GET_A_DictAttr_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_DictAttr_ObjModifStatEn)));
}
inline XdEntityFeatureFeatureEn     _GET_A_DictAttr_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (_GET_ENUM(p, A_DictAttr_FeatureEn)));
}
inline XdAttribModelBankEn          _GET_A_DictAttr_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (_GET_ENUM(p, A_DictAttr_ModelBankEn)));
}
inline XdAttribMeSpecialisationEn   _GET_A_DictAttr_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (_GET_ENUM(p, A_DictAttr_MeSpecialisationEn)));
}
inline XdAttribOutboxPublishEn      _GET_A_DictAttr_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (_GET_ENUM(p, A_DictAttr_OutboxPublishEn)));
}

inline void                         SET_A_DictAttr_CalcEn(DBA_DYNFLD_STP p, DictAttrCalcEn enumValue)
{
    SET_ENUM(p, A_DictAttr_CalcEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_PermAuthFlg(DBA_DYNFLD_STP p, DictAttrPermAuthFlg enumValue)
{
    SET_ENUM(p, A_DictAttr_PermAuthFlg, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_EditEn(DBA_DYNFLD_STP p, DictAttrEditEn enumValue)
{
    SET_ENUM(p, A_DictAttr_EditEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_SecurityLevelEn(DBA_DYNFLD_STP p, DictAttrSecurityLevelEn enumValue)
{
    SET_ENUM(p, A_DictAttr_SecurityLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_WidgetEn(DBA_DYNFLD_STP p, DictAttrWidgetEn enumValue)
{
    SET_ENUM(p, A_DictAttr_WidgetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_TascViewEn(DBA_DYNFLD_STP p, DictAttrTascViewEn enumValue)
{
    SET_ENUM(p, A_DictAttr_TascViewEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_EnumValue(DBA_DYNFLD_STP p, DictAttrEnumValue enumValue)
{
    SET_ENUM(p, A_DictAttr_EnumValue, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_FkPresentationEn(DBA_DYNFLD_STP p, DictAttrFkPresentationEn enumValue)
{
    SET_ENUM(p, A_DictAttr_FkPresentationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictAttr_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_RefDeleteRuleEn(DBA_DYNFLD_STP p, XdAttribRefDeleteRuleEn enumValue)
{
    SET_ENUM(p, A_DictAttr_RefDeleteRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_RefSecurityRuleEn(DBA_DYNFLD_STP p, XdAttribRefSecurityRuleEn enumValue)
{
    SET_ENUM(p, A_DictAttr_RefSecurityRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_RefCheckRuleEn(DBA_DYNFLD_STP p, XdAttribRefCheckRuleEn enumValue)
{
    SET_ENUM(p, A_DictAttr_RefCheckRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_ExportEn(DBA_DYNFLD_STP p, XdAttribExportEn enumValue)
{
    SET_ENUM(p, A_DictAttr_ExportEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_ObjModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_DictAttr_ObjModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_FeatureEn(DBA_DYNFLD_STP p, XdEntityFeatureFeatureEn enumValue)
{
    SET_ENUM(p, A_DictAttr_FeatureEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_ModelBankEn(DBA_DYNFLD_STP p, XdAttribModelBankEn enumValue)
{
    SET_ENUM(p, A_DictAttr_ModelBankEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_MeSpecialisationEn(DBA_DYNFLD_STP p, XdAttribMeSpecialisationEn enumValue)
{
    SET_ENUM(p, A_DictAttr_MeSpecialisationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttr_OutboxPublishEn(DBA_DYNFLD_STP p, XdAttribOutboxPublishEn enumValue)
{
    SET_ENUM(p, A_DictAttr_OutboxPublishEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictDependsAccessEn          GET_A_DictDepends_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsAccessEn>  (GET_ENUM(p, A_DictDepends_AccessEn)));
}
inline DictDependsAccessEn          GET_S_DictDepends_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsAccessEn>  (GET_ENUM(p, S_DictDepends_AccessEn)));
}
inline XdEntityXdStatusEn           GET_A_DictDepends_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictDepends_XdStatusEn)));
}
inline DictDependsGenDdlObjEn       GET_A_DictDepends_GenDdlObjEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsGenDdlObjEn>  (GET_ENUM(p, A_DictDepends_GenDdlObjEn)));
}

inline DictDependsAccessEn          _GET_A_DictDepends_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsAccessEn>  (_GET_ENUM(p, A_DictDepends_AccessEn)));
}
inline DictDependsAccessEn          _GET_S_DictDepends_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsAccessEn>  (_GET_ENUM(p, S_DictDepends_AccessEn)));
}
inline XdEntityXdStatusEn           _GET_A_DictDepends_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictDepends_XdStatusEn)));
}
inline DictDependsGenDdlObjEn       _GET_A_DictDepends_GenDdlObjEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictDependsGenDdlObjEn>  (_GET_ENUM(p, A_DictDepends_GenDdlObjEn)));
}

inline void                         SET_A_DictDepends_AccessEn(DBA_DYNFLD_STP p, DictDependsAccessEn enumValue)
{
    SET_ENUM(p, A_DictDepends_AccessEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DictDepends_AccessEn(DBA_DYNFLD_STP p, DictDependsAccessEn enumValue)
{
    SET_ENUM(p, S_DictDepends_AccessEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictDepends_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictDepends_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictDepends_GenDdlObjEn(DBA_DYNFLD_STP p, DictDependsGenDdlObjEn enumValue)
{
    SET_ENUM(p, A_DictDepends_GenDdlObjEn, static_cast<unsigned char>(enumValue));
}


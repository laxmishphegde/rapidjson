/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline IrlPortfolioRuleCompoNatEn   GET_A_IrlPortfolioRuleCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlPortfolioRuleCompoNatEn>  (GET_ENUM(p, A_IrlPortfolioRuleCompo_NatEn)));
}

inline IrlPortfolioRuleCompoNatEn   _GET_A_IrlPortfolioRuleCompo_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IrlPortfolioRuleCompoNatEn>  (_GET_ENUM(p, A_IrlPortfolioRuleCompo_NatEn)));
}

inline void                         SET_A_IrlPortfolioRuleCompo_NatEn(DBA_DYNFLD_STP p, IrlPortfolioRuleCompoNatEn enumValue)
{
    SET_ENUM(p, A_IrlPortfolioRuleCompo_NatEn, static_cast<unsigned char>(enumValue));
}


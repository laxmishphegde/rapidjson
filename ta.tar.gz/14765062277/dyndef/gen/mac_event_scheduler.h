/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline EventSchedNatEn              GET_A_EventSched_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedNatEn>  (GET_ENUM(p, A_EventSched_NatEn)));
}
inline EventSchedNatEn              GET_S_EventSched_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedNatEn>  (GET_ENUM(p, S_EventSched_NatEn)));
}
inline EventSchedStatusEn           GET_A_EventSched_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedStatusEn>  (GET_ENUM(p, A_EventSched_StatusEn)));
}
inline EventSchedStatusEn           GET_S_EventSched_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedStatusEn>  (GET_ENUM(p, S_EventSched_StatusEn)));
}
inline EventSchedFusionPrioEn       GET_A_EventSched_FusionPrioEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionPrioEn>  (GET_ENUM(p, A_EventSched_FusionPrioEn)));
}
inline EventSchedFusionEn           GET_A_EventSched_FusionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionEn>  (GET_ENUM(p, A_EventSched_FusionEn)));
}
inline EventSchedFusionEn           GET_S_EventSched_FusionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionEn>  (GET_ENUM(p, S_EventSched_FusionEn)));
}

inline EventSchedNatEn              _GET_A_EventSched_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedNatEn>  (_GET_ENUM(p, A_EventSched_NatEn)));
}
inline EventSchedNatEn              _GET_S_EventSched_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedNatEn>  (_GET_ENUM(p, S_EventSched_NatEn)));
}
inline EventSchedStatusEn           _GET_A_EventSched_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedStatusEn>  (_GET_ENUM(p, A_EventSched_StatusEn)));
}
inline EventSchedStatusEn           _GET_S_EventSched_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedStatusEn>  (_GET_ENUM(p, S_EventSched_StatusEn)));
}
inline EventSchedFusionPrioEn       _GET_A_EventSched_FusionPrioEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionPrioEn>  (_GET_ENUM(p, A_EventSched_FusionPrioEn)));
}
inline EventSchedFusionEn           _GET_A_EventSched_FusionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionEn>  (_GET_ENUM(p, A_EventSched_FusionEn)));
}
inline EventSchedFusionEn           _GET_S_EventSched_FusionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventSchedFusionEn>  (_GET_ENUM(p, S_EventSched_FusionEn)));
}

inline void                         SET_A_EventSched_NatEn(DBA_DYNFLD_STP p, EventSchedNatEn enumValue)
{
    SET_ENUM(p, A_EventSched_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_EventSched_NatEn(DBA_DYNFLD_STP p, EventSchedNatEn enumValue)
{
    SET_ENUM(p, S_EventSched_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_EventSched_StatusEn(DBA_DYNFLD_STP p, EventSchedStatusEn enumValue)
{
    SET_ENUM(p, A_EventSched_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_EventSched_StatusEn(DBA_DYNFLD_STP p, EventSchedStatusEn enumValue)
{
    SET_ENUM(p, S_EventSched_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_EventSched_FusionPrioEn(DBA_DYNFLD_STP p, EventSchedFusionPrioEn enumValue)
{
    SET_ENUM(p, A_EventSched_FusionPrioEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_EventSched_FusionEn(DBA_DYNFLD_STP p, EventSchedFusionEn enumValue)
{
    SET_ENUM(p, A_EventSched_FusionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_EventSched_FusionEn(DBA_DYNFLD_STP p, EventSchedFusionEn enumValue)
{
    SET_ENUM(p, S_EventSched_FusionEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictFctNatEn                 GET_A_DictFct_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctNatEn>  (GET_ENUM(p, A_DictFct_NatEn)));
}
inline DictFctFctNatEn              GET_A_DictFct_FctNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctFctNatEn>  (GET_ENUM(p, A_DictFct_FctNatEn)));
}
inline DictFctLicenseKeyEn          GET_A_DictFct_LicenseKeyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctLicenseKeyEn>  (GET_ENUM(p, A_DictFct_LicenseKeyEn)));
}

inline DictFctNatEn                 _GET_A_DictFct_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctNatEn>  (_GET_ENUM(p, A_DictFct_NatEn)));
}
inline DictFctFctNatEn              _GET_A_DictFct_FctNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctFctNatEn>  (_GET_ENUM(p, A_DictFct_FctNatEn)));
}
inline DictFctLicenseKeyEn          _GET_A_DictFct_LicenseKeyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictFctLicenseKeyEn>  (_GET_ENUM(p, A_DictFct_LicenseKeyEn)));
}

inline void                         SET_A_DictFct_NatEn(DBA_DYNFLD_STP p, DictFctNatEn enumValue)
{
    SET_ENUM(p, A_DictFct_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictFct_FctNatEn(DBA_DYNFLD_STP p, DictFctFctNatEn enumValue)
{
    SET_ENUM(p, A_DictFct_FctNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictFct_LicenseKeyEn(DBA_DYNFLD_STP p, DictFctLicenseKeyEn enumValue)
{
    SET_ENUM(p, A_DictFct_LicenseKeyEn, static_cast<unsigned char>(enumValue));
}


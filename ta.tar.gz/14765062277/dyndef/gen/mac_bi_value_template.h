/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BiValueTemplateStatusEn      GET_A_BiValueTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiValueTemplateStatusEn>  (GET_ENUM(p, A_BiValueTemplate_StatusEn)));
}
inline BiValueTemplateFlagEn        GET_A_BiValueTemplate_FlagEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiValueTemplateFlagEn>  (GET_ENUM(p, A_BiValueTemplate_FlagEn)));
}

inline BiValueTemplateStatusEn      _GET_A_BiValueTemplate_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiValueTemplateStatusEn>  (_GET_ENUM(p, A_BiValueTemplate_StatusEn)));
}
inline BiValueTemplateFlagEn        _GET_A_BiValueTemplate_FlagEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiValueTemplateFlagEn>  (_GET_ENUM(p, A_BiValueTemplate_FlagEn)));
}

inline void                         SET_A_BiValueTemplate_StatusEn(DBA_DYNFLD_STP p, BiValueTemplateStatusEn enumValue)
{
    SET_ENUM(p, A_BiValueTemplate_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_BiValueTemplate_FlagEn(DBA_DYNFLD_STP p, BiValueTemplateFlagEn enumValue)
{
    SET_ENUM(p, A_BiValueTemplate_FlagEn, static_cast<unsigned char>(enumValue));
}


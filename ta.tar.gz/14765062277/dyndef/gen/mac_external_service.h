/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ExtServiceNatEn              GET_A_ExtService_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceNatEn>  (GET_ENUM(p, A_ExtService_NatEn)));
}
inline ExtServiceNatEn              GET_S_ExtService_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceNatEn>  (GET_ENUM(p, S_ExtService_NatEn)));
}
inline ExtServiceBreakCriteriaEn    GET_A_ExtService_BreakCriteriaEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceBreakCriteriaEn>  (GET_ENUM(p, A_ExtService_BreakCriteriaEn)));
}
inline ExtServiceReportTypeDataEn   GET_A_ExtService_ReportTypeDataEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceReportTypeDataEn>  (GET_ENUM(p, A_ExtService_ReportTypeDataEn)));
}

inline ExtServiceNatEn              _GET_A_ExtService_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceNatEn>  (_GET_ENUM(p, A_ExtService_NatEn)));
}
inline ExtServiceNatEn              _GET_S_ExtService_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceNatEn>  (_GET_ENUM(p, S_ExtService_NatEn)));
}
inline ExtServiceBreakCriteriaEn    _GET_A_ExtService_BreakCriteriaEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceBreakCriteriaEn>  (_GET_ENUM(p, A_ExtService_BreakCriteriaEn)));
}
inline ExtServiceReportTypeDataEn   _GET_A_ExtService_ReportTypeDataEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExtServiceReportTypeDataEn>  (_GET_ENUM(p, A_ExtService_ReportTypeDataEn)));
}

inline void                         SET_A_ExtService_NatEn(DBA_DYNFLD_STP p, ExtServiceNatEn enumValue)
{
    SET_ENUM(p, A_ExtService_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ExtService_NatEn(DBA_DYNFLD_STP p, ExtServiceNatEn enumValue)
{
    SET_ENUM(p, S_ExtService_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExtService_BreakCriteriaEn(DBA_DYNFLD_STP p, ExtServiceBreakCriteriaEn enumValue)
{
    SET_ENUM(p, A_ExtService_BreakCriteriaEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExtService_ReportTypeDataEn(DBA_DYNFLD_STP p, ExtServiceReportTypeDataEn enumValue)
{
    SET_ENUM(p, A_ExtService_ReportTypeDataEn, static_cast<unsigned char>(enumValue));
}


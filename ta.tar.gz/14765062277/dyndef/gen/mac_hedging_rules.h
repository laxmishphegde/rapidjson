/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline HedgingRulesHedgeNatEn       GET_A_HedgingRules_HedgeNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesHedgeNatEn>  (GET_ENUM(p, A_HedgingRules_HedgeNatEn)));
}
inline HedgingRulesFxRateDirectionFlg GET_A_HedgingRules_FxRateDirectionFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesFxRateDirectionFlg>  (GET_ENUM(p, A_HedgingRules_FxRateDirectionFlg)));
}
inline HedgingRulesContractLengthUnitEn GET_A_HedgingRules_ContractLengthUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesContractLengthUnitEn>  (GET_ENUM(p, A_HedgingRules_ContractLengthUnitEn)));
}

inline HedgingRulesHedgeNatEn       _GET_A_HedgingRules_HedgeNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesHedgeNatEn>  (_GET_ENUM(p, A_HedgingRules_HedgeNatEn)));
}
inline HedgingRulesFxRateDirectionFlg _GET_A_HedgingRules_FxRateDirectionFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesFxRateDirectionFlg>  (_GET_ENUM(p, A_HedgingRules_FxRateDirectionFlg)));
}
inline HedgingRulesContractLengthUnitEn _GET_A_HedgingRules_ContractLengthUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<HedgingRulesContractLengthUnitEn>  (_GET_ENUM(p, A_HedgingRules_ContractLengthUnitEn)));
}

inline void                         SET_A_HedgingRules_HedgeNatEn(DBA_DYNFLD_STP p, HedgingRulesHedgeNatEn enumValue)
{
    SET_ENUM(p, A_HedgingRules_HedgeNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_HedgingRules_FxRateDirectionFlg(DBA_DYNFLD_STP p, HedgingRulesFxRateDirectionFlg enumValue)
{
    SET_ENUM(p, A_HedgingRules_FxRateDirectionFlg, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_HedgingRules_ContractLengthUnitEn(DBA_DYNFLD_STP p, HedgingRulesContractLengthUnitEn enumValue)
{
    SET_ENUM(p, A_HedgingRules_ContractLengthUnitEn, static_cast<unsigned char>(enumValue));
}


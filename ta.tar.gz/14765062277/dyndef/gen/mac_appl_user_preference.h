/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ApplUserPreferenceNatEn      GET_A_ApplUserPreference_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserPreferenceNatEn>  (GET_ENUM(p, A_ApplUserPreference_NatEn)));
}
inline ApplUserPreferenceNatEn      GET_S_ApplUserPreference_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserPreferenceNatEn>  (GET_ENUM(p, S_ApplUserPreference_NatEn)));
}

inline ApplUserPreferenceNatEn      _GET_A_ApplUserPreference_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserPreferenceNatEn>  (_GET_ENUM(p, A_ApplUserPreference_NatEn)));
}
inline ApplUserPreferenceNatEn      _GET_S_ApplUserPreference_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserPreferenceNatEn>  (_GET_ENUM(p, S_ApplUserPreference_NatEn)));
}

inline void                         SET_A_ApplUserPreference_NatEn(DBA_DYNFLD_STP p, ApplUserPreferenceNatEn enumValue)
{
    SET_ENUM(p, A_ApplUserPreference_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ApplUserPreference_NatEn(DBA_DYNFLD_STP p, ApplUserPreferenceNatEn enumValue)
{
    SET_ENUM(p, S_ApplUserPreference_NatEn, static_cast<unsigned char>(enumValue));
}


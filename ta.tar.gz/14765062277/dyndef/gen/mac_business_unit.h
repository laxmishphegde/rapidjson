/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusinessUnitUserLnkNatEn     GET_A_BusinessUnit_UserLnkNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitUserLnkNatEn>  (GET_ENUM(p, A_BusinessUnit_UserLnkNatEn)));
}

inline BusinessUnitUserLnkNatEn     _GET_A_BusinessUnit_UserLnkNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitUserLnkNatEn>  (_GET_ENUM(p, A_BusinessUnit_UserLnkNatEn)));
}

inline void                         SET_A_BusinessUnit_UserLnkNatEn(DBA_DYNFLD_STP p, BusinessUnitUserLnkNatEn enumValue)
{
    SET_ENUM(p, A_BusinessUnit_UserLnkNatEn, static_cast<unsigned char>(enumValue));
}


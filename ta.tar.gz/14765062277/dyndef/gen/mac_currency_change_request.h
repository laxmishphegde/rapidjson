/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CurrencyChangeRequestStatusEn GET_A_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestStatusEn>  (GET_ENUM(p, A_CurrencyChangeRequest_StatusEn)));
}
inline CurrencyChangeRequestStatusEn GET_S_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestStatusEn>  (GET_ENUM(p, S_CurrencyChangeRequest_StatusEn)));
}
inline CurrencyChangeRequestRequestActionEn GET_A_CurrencyChangeRequest_RequestActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestRequestActionEn>  (GET_ENUM(p, A_CurrencyChangeRequest_RequestActionEn)));
}

inline CurrencyChangeRequestStatusEn _GET_A_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestStatusEn>  (_GET_ENUM(p, A_CurrencyChangeRequest_StatusEn)));
}
inline CurrencyChangeRequestStatusEn _GET_S_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestStatusEn>  (_GET_ENUM(p, S_CurrencyChangeRequest_StatusEn)));
}
inline CurrencyChangeRequestRequestActionEn _GET_A_CurrencyChangeRequest_RequestActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CurrencyChangeRequestRequestActionEn>  (_GET_ENUM(p, A_CurrencyChangeRequest_RequestActionEn)));
}

inline void                         SET_A_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p, CurrencyChangeRequestStatusEn enumValue)
{
    SET_ENUM(p, A_CurrencyChangeRequest_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_CurrencyChangeRequest_StatusEn(DBA_DYNFLD_STP p, CurrencyChangeRequestStatusEn enumValue)
{
    SET_ENUM(p, S_CurrencyChangeRequest_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CurrencyChangeRequest_RequestActionEn(DBA_DYNFLD_STP p, CurrencyChangeRequestRequestActionEn enumValue)
{
    SET_ENUM(p, A_CurrencyChangeRequest_RequestActionEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DdlgenActionDdlObjNatEn      GET_A_DdlgenAction_DdlObjNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionDdlObjNatEn>  (GET_ENUM(p, A_DdlgenAction_DdlObjNatEn)));
}
inline DdlgenActionExecModeEn       GET_A_DdlgenAction_ExecModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionExecModeEn>  (GET_ENUM(p, A_DdlgenAction_ExecModeEn)));
}
inline DdlgenActionBuildRuleEn      GET_A_DdlgenAction_BuildRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionBuildRuleEn>  (GET_ENUM(p, A_DdlgenAction_BuildRuleEn)));
}

inline DdlgenActionDdlObjNatEn      _GET_A_DdlgenAction_DdlObjNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionDdlObjNatEn>  (_GET_ENUM(p, A_DdlgenAction_DdlObjNatEn)));
}
inline DdlgenActionExecModeEn       _GET_A_DdlgenAction_ExecModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionExecModeEn>  (_GET_ENUM(p, A_DdlgenAction_ExecModeEn)));
}
inline DdlgenActionBuildRuleEn      _GET_A_DdlgenAction_BuildRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenActionBuildRuleEn>  (_GET_ENUM(p, A_DdlgenAction_BuildRuleEn)));
}

inline void                         SET_A_DdlgenAction_DdlObjNatEn(DBA_DYNFLD_STP p, DdlgenActionDdlObjNatEn enumValue)
{
    SET_ENUM(p, A_DdlgenAction_DdlObjNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DdlgenAction_ExecModeEn(DBA_DYNFLD_STP p, DdlgenActionExecModeEn enumValue)
{
    SET_ENUM(p, A_DdlgenAction_ExecModeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DdlgenAction_BuildRuleEn(DBA_DYNFLD_STP p, DdlgenActionBuildRuleEn enumValue)
{
    SET_ENUM(p, A_DdlgenAction_BuildRuleEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrNatEn                   GET_A_Instr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_Instr_NatEn)));
}
inline InstrNatEn                   GET_S_Instr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_Instr_NatEn)));
}
inline InstrValRuleEn               GET_A_Instr_ValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrValRuleEn>  (GET_ENUM(p, A_Instr_ValRuleEn)));
}
inline InstrAccrualRuleEn           GET_A_Instr_AccrualRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAccrualRuleEn>  (GET_ENUM(p, A_Instr_AccrualRuleEn)));
}
inline InstrIssueCdEn               GET_A_Instr_IssueCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIssueCdEn>  (GET_ENUM(p, A_Instr_IssueCdEn)));
}
inline InstrIncomeCdEn              GET_A_Instr_IncomeCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIncomeCdEn>  (GET_ENUM(p, A_Instr_IncomeCdEn)));
}
inline InstrRedempCdEn              GET_A_Instr_RedempCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRedempCdEn>  (GET_ENUM(p, A_Instr_RedempCdEn)));
}
inline InstrTermCdEn                GET_A_Instr_TermCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTermCdEn>  (GET_ENUM(p, A_Instr_TermCdEn)));
}
inline InstrInterestCdEn            GET_A_Instr_InterestCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestCdEn>  (GET_ENUM(p, A_Instr_InterestCdEn)));
}
inline InstrExchangeCdEn            GET_A_Instr_ExchangeCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrExchangeCdEn>  (GET_ENUM(p, A_Instr_ExchangeCdEn)));
}
inline IncEvtPayFreqUnitEn          GET_A_Instr_PayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (GET_ENUM(p, A_Instr_PayFreqUnitEn)));
}
inline InstrOptionClassEn           GET_A_Instr_OptionClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOptionClassEn>  (GET_ENUM(p, A_Instr_OptionClassEn)));
}
inline InstrOptStyleEn              GET_A_Instr_OptStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOptStyleEn>  (GET_ENUM(p, A_Instr_OptStyleEn)));
}
inline InstrIdxReturnTypeEn         GET_A_Instr_IdxReturnTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxReturnTypeEn>  (GET_ENUM(p, A_Instr_IdxReturnTypeEn)));
}
inline InstrIdxCalcRuleEn           GET_A_Instr_IdxCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxCalcRuleEn>  (GET_ENUM(p, A_Instr_IdxCalcRuleEn)));
}
inline InstrIdxTimeRuleEn           GET_A_Instr_IdxTimeRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxTimeRuleEn>  (GET_ENUM(p, A_Instr_IdxTimeRuleEn)));
}
inline InstrRateFreqUnitEn          GET_A_Instr_RateFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (GET_ENUM(p, A_Instr_RateFreqUnitEn)));
}
inline InstrInvoicePriceRuleEn      GET_A_Instr_InvoicePriceRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInvoicePriceRuleEn>  (GET_ENUM(p, A_Instr_InvoicePriceRuleEn)));
}
inline InstrRiskNatEn               GET_A_Instr_RiskNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRiskNatEn>  (GET_ENUM(p, A_Instr_RiskNatEn)));
}
inline InstrSubNatEn                GET_A_Instr_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrSubNatEn>  (GET_ENUM(p, A_Instr_SubNatEn)));
}
inline InstrSubNatEn                GET_S_Instr_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrSubNatEn>  (GET_ENUM(p, S_Instr_SubNatEn)));
}
inline InstrAiRoundRuleEn           GET_A_Instr_AiRoundRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAiRoundRuleEn>  (GET_ENUM(p, A_Instr_AiRoundRuleEn)));
}
inline InstrContractNatEn           GET_A_Instr_ContractNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrContractNatEn>  (GET_ENUM(p, A_Instr_ContractNatEn)));
}
inline InstrDefModelEn              GET_A_Instr_DefModelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDefModelEn>  (GET_ENUM(p, A_Instr_DefModelEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_Instr_CompFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_Instr_CompFreqUnitEn)));
}
inline InstrCompConvEn              GET_A_Instr_CompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCompConvEn>  (GET_ENUM(p, A_Instr_CompConvEn)));
}
inline InterCondResetFreqUnitEn     GET_A_Instr_BacksetDelayUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondResetFreqUnitEn>  (GET_ENUM(p, A_Instr_BacksetDelayUnitEn)));
}
inline InstrAccrualRuleEn           GET_A_Instr_PaidAccrualRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAccrualRuleEn>  (GET_ENUM(p, A_Instr_PaidAccrualRuleEn)));
}
inline InstrMortgageNatEn           GET_A_Instr_MortgageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMortgageNatEn>  (GET_ENUM(p, A_Instr_MortgageNatEn)));
}
inline InstrLongTermPeriodUnitEn    GET_A_Instr_LongTermPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLongTermPeriodUnitEn>  (GET_ENUM(p, A_Instr_LongTermPeriodUnitEn)));
}
inline InstrPremiumPmtEn            GET_A_Instr_PremiumPmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPremiumPmtEn>  (GET_ENUM(p, A_Instr_PremiumPmtEn)));
}
inline InstrEomEn                   GET_A_Instr_EomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (GET_ENUM(p, A_Instr_EomEn)));
}
inline InstrEomEn                   GET_A_Instr_PaidEomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (GET_ENUM(p, A_Instr_PaidEomEn)));
}
inline InstrPrincipalRuleEn         GET_A_Instr_PrincipalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPrincipalRuleEn>  (GET_ENUM(p, A_Instr_PrincipalRuleEn)));
}
inline InstrInterpolConvEn          GET_A_Instr_InterpolConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterpolConvEn>  (GET_ENUM(p, A_Instr_InterpolConvEn)));
}
inline InstrInterpolRuleEn          GET_A_Instr_InterpolRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterpolRuleEn>  (GET_ENUM(p, A_Instr_InterpolRuleEn)));
}
inline InstrInterestRateConvEn      GET_A_Instr_InterestRateConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestRateConvEn>  (GET_ENUM(p, A_Instr_InterestRateConvEn)));
}
inline InstrCouponConvEn            GET_A_Instr_CouponConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCouponConvEn>  (GET_ENUM(p, A_Instr_CouponConvEn)));
}
inline InstrPmtCalcConvEn           GET_A_Instr_PmtCalcConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPmtCalcConvEn>  (GET_ENUM(p, A_Instr_PmtCalcConvEn)));
}
inline InstrBusDayConvEn            GET_A_Instr_BusDayConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrBusDayConvEn>  (GET_ENUM(p, A_Instr_BusDayConvEn)));
}
inline InstrAverPeriodUnitEn        GET_A_Instr_AverPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAverPeriodUnitEn>  (GET_ENUM(p, A_Instr_AverPeriodUnitEn)));
}
inline InstrDecompConvEn            GET_A_Instr_DecompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDecompConvEn>  (GET_ENUM(p, A_Instr_DecompConvEn)));
}
inline IncEvtPayFreqUnitEn          GET_A_Instr_TenorFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (GET_ENUM(p, A_Instr_TenorFreqUnitEn)));
}
inline IncEvtPayFreqUnitEn          GET_A_Instr_PaidPayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (GET_ENUM(p, A_Instr_PaidPayFreqUnitEn)));
}
inline ExchEvtEuroConvRuleEn        GET_A_Instr_EuroConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtEuroConvRuleEn>  (GET_ENUM(p, A_Instr_EuroConvRuleEn)));
}
inline InstrDecimalDispEn           GET_A_Instr_DecimalDispEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDecimalDispEn>  (GET_ENUM(p, A_Instr_DecimalDispEn)));
}
inline InstrLinearValUnitEn         GET_A_Instr_LinearValUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLinearValUnitEn>  (GET_ENUM(p, A_Instr_LinearValUnitEn)));
}
inline InstrRateFreqUnitEn          GET_A_Instr_FixingRuleFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (GET_ENUM(p, A_Instr_FixingRuleFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_Instr_PaidCompFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_Instr_PaidCompFreqUnitEn)));
}
inline InstrPaidCompConvEn          GET_A_Instr_PaidCompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPaidCompConvEn>  (GET_ENUM(p, A_Instr_PaidCompConvEn)));
}
inline InstrHeartUploadEn           GET_A_Instr_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrHeartUploadEn>  (GET_ENUM(p, A_Instr_HeartUploadEn)));
}
inline InstrStatusEn                GET_A_Instr_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrStatusEn>  (GET_ENUM(p, A_Instr_StatusEn)));
}
inline IncEvtPayFreqUnitEn          GET_A_Instr_PriceCalcFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (GET_ENUM(p, A_Instr_PriceCalcFreqUnitEn)));
}
inline InstrStpOrderEn              GET_A_Instr_StpOrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrStpOrderEn>  (GET_ENUM(p, A_Instr_StpOrderEn)));
}
inline InstrTradeNatEn              GET_A_Instr_TradeNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTradeNatEn>  (GET_ENUM(p, A_Instr_TradeNatEn)));
}
inline TermEvtBarrierNatEn          GET_A_Instr_BarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (GET_ENUM(p, A_Instr_BarrierNatEn)));
}
inline TermEvtBarrierNatEn          GET_A_Instr_UpperBarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (GET_ENUM(p, A_Instr_UpperBarrierNatEn)));
}
inline TermEvtPayOffNatEn           GET_A_Instr_PayOffNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtPayOffNatEn>  (GET_ENUM(p, A_Instr_PayOffNatEn)));
}
inline InstrInstrumentClassEn       GET_A_Instr_InstrumentClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInstrumentClassEn>  (GET_ENUM(p, A_Instr_InstrumentClassEn)));
}
inline InstrComplexityLevelEn       GET_A_Instr_ComplexityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrComplexityLevelEn>  (GET_ENUM(p, A_Instr_ComplexityLevelEn)));
}
inline InstrIslamicComplianceEn     GET_A_Instr_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (GET_ENUM(p, A_Instr_IslamicComplianceEn)));
}
inline InstrFundIncomeStyleEn       GET_A_Instr_FundIncomeStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrFundIncomeStyleEn>  (GET_ENUM(p, A_Instr_FundIncomeStyleEn)));
}
inline InstrRateFreqUnitEn          GET_A_Instr_CoolperiodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (GET_ENUM(p, A_Instr_CoolperiodUnitEn)));
}
inline InstrUnderlyCatEn            GET_A_Instr_UnderlyCatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrUnderlyCatEn>  (GET_ENUM(p, A_Instr_UnderlyCatEn)));
}
inline InstrInterestCalculationRuleEn GET_A_Instr_InterestCalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestCalculationRuleEn>  (GET_ENUM(p, A_Instr_InterestCalculationRuleEn)));
}
inline InstrConvertInterestEn       GET_A_Instr_ConvertInterestEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrConvertInterestEn>  (GET_ENUM(p, A_Instr_ConvertInterestEn)));
}
inline InstrUsageNatEn              GET_A_Instr_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrUsageNatEn>  (GET_ENUM(p, A_Instr_UsageNatEn)));
}
inline InstrOrderGenMngtEn          GET_A_Instr_OrderGenMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOrderGenMngtEn>  (GET_ENUM(p, A_Instr_OrderGenMngtEn)));
}
inline InstrAutoRenewalEn           GET_A_Instr_AutoRenewalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAutoRenewalEn>  (GET_ENUM(p, A_Instr_AutoRenewalEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_Instr_PriceFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_Instr_PriceFreqUnitEn)));
}
inline InstrTempDerivedInstrLocEn   GET_A_Instr_TempDerivedInstrLocEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTempDerivedInstrLocEn>  (GET_ENUM(p, A_Instr_TempDerivedInstrLocEn)));
}
inline InstrEventTypeEn             GET_A_Instr_EventTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEventTypeEn>  (GET_ENUM(p, A_Instr_EventTypeEn)));
}
inline InstrBoAccruedIntRuleEn      GET_A_Instr_BoAccruedIntRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrBoAccruedIntRuleEn>  (GET_ENUM(p, A_Instr_BoAccruedIntRuleEn)));
}
inline InstrMktConvMethodEn         GET_A_Instr_MktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (GET_ENUM(p, A_Instr_MktConvMethodEn)));
}
inline InstrLookbackConvEn          GET_A_Instr_LookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (GET_ENUM(p, A_Instr_LookbackConvEn)));
}
inline InstrMktConvMethodEn         GET_A_Instr_PaidMktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (GET_ENUM(p, A_Instr_PaidMktConvMethodEn)));
}
inline InstrLookbackConvEn          GET_A_Instr_PaidLookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (GET_ENUM(p, A_Instr_PaidLookbackConvEn)));
}
inline InstrRenewalTreatmentEn      GET_A_Instr_RenewalTreatmentEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRenewalTreatmentEn>  (GET_ENUM(p, A_Instr_RenewalTreatmentEn)));
}
inline DictAttributeTemplateDlmEn   GET_A_Instr_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (GET_ENUM(p, A_Instr_DlmEn)));
}

inline InstrNatEn                   _GET_A_Instr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_Instr_NatEn)));
}
inline InstrNatEn                   _GET_S_Instr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_Instr_NatEn)));
}
inline InstrValRuleEn               _GET_A_Instr_ValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrValRuleEn>  (_GET_ENUM(p, A_Instr_ValRuleEn)));
}
inline InstrAccrualRuleEn           _GET_A_Instr_AccrualRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAccrualRuleEn>  (_GET_ENUM(p, A_Instr_AccrualRuleEn)));
}
inline InstrIssueCdEn               _GET_A_Instr_IssueCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIssueCdEn>  (_GET_ENUM(p, A_Instr_IssueCdEn)));
}
inline InstrIncomeCdEn              _GET_A_Instr_IncomeCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIncomeCdEn>  (_GET_ENUM(p, A_Instr_IncomeCdEn)));
}
inline InstrRedempCdEn              _GET_A_Instr_RedempCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRedempCdEn>  (_GET_ENUM(p, A_Instr_RedempCdEn)));
}
inline InstrTermCdEn                _GET_A_Instr_TermCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTermCdEn>  (_GET_ENUM(p, A_Instr_TermCdEn)));
}
inline InstrInterestCdEn            _GET_A_Instr_InterestCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestCdEn>  (_GET_ENUM(p, A_Instr_InterestCdEn)));
}
inline InstrExchangeCdEn            _GET_A_Instr_ExchangeCdEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrExchangeCdEn>  (_GET_ENUM(p, A_Instr_ExchangeCdEn)));
}
inline IncEvtPayFreqUnitEn          _GET_A_Instr_PayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (_GET_ENUM(p, A_Instr_PayFreqUnitEn)));
}
inline InstrOptionClassEn           _GET_A_Instr_OptionClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOptionClassEn>  (_GET_ENUM(p, A_Instr_OptionClassEn)));
}
inline InstrOptStyleEn              _GET_A_Instr_OptStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOptStyleEn>  (_GET_ENUM(p, A_Instr_OptStyleEn)));
}
inline InstrIdxReturnTypeEn         _GET_A_Instr_IdxReturnTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxReturnTypeEn>  (_GET_ENUM(p, A_Instr_IdxReturnTypeEn)));
}
inline InstrIdxCalcRuleEn           _GET_A_Instr_IdxCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxCalcRuleEn>  (_GET_ENUM(p, A_Instr_IdxCalcRuleEn)));
}
inline InstrIdxTimeRuleEn           _GET_A_Instr_IdxTimeRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIdxTimeRuleEn>  (_GET_ENUM(p, A_Instr_IdxTimeRuleEn)));
}
inline InstrRateFreqUnitEn          _GET_A_Instr_RateFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (_GET_ENUM(p, A_Instr_RateFreqUnitEn)));
}
inline InstrInvoicePriceRuleEn      _GET_A_Instr_InvoicePriceRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInvoicePriceRuleEn>  (_GET_ENUM(p, A_Instr_InvoicePriceRuleEn)));
}
inline InstrRiskNatEn               _GET_A_Instr_RiskNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRiskNatEn>  (_GET_ENUM(p, A_Instr_RiskNatEn)));
}
inline InstrSubNatEn                _GET_A_Instr_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrSubNatEn>  (_GET_ENUM(p, A_Instr_SubNatEn)));
}
inline InstrSubNatEn                _GET_S_Instr_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrSubNatEn>  (_GET_ENUM(p, S_Instr_SubNatEn)));
}
inline InstrAiRoundRuleEn           _GET_A_Instr_AiRoundRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAiRoundRuleEn>  (_GET_ENUM(p, A_Instr_AiRoundRuleEn)));
}
inline InstrContractNatEn           _GET_A_Instr_ContractNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrContractNatEn>  (_GET_ENUM(p, A_Instr_ContractNatEn)));
}
inline InstrDefModelEn              _GET_A_Instr_DefModelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDefModelEn>  (_GET_ENUM(p, A_Instr_DefModelEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_Instr_CompFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_Instr_CompFreqUnitEn)));
}
inline InstrCompConvEn              _GET_A_Instr_CompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCompConvEn>  (_GET_ENUM(p, A_Instr_CompConvEn)));
}
inline InterCondResetFreqUnitEn     _GET_A_Instr_BacksetDelayUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondResetFreqUnitEn>  (_GET_ENUM(p, A_Instr_BacksetDelayUnitEn)));
}
inline InstrAccrualRuleEn           _GET_A_Instr_PaidAccrualRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAccrualRuleEn>  (_GET_ENUM(p, A_Instr_PaidAccrualRuleEn)));
}
inline InstrMortgageNatEn           _GET_A_Instr_MortgageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMortgageNatEn>  (_GET_ENUM(p, A_Instr_MortgageNatEn)));
}
inline InstrLongTermPeriodUnitEn    _GET_A_Instr_LongTermPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLongTermPeriodUnitEn>  (_GET_ENUM(p, A_Instr_LongTermPeriodUnitEn)));
}
inline InstrPremiumPmtEn            _GET_A_Instr_PremiumPmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPremiumPmtEn>  (_GET_ENUM(p, A_Instr_PremiumPmtEn)));
}
inline InstrEomEn                   _GET_A_Instr_EomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (_GET_ENUM(p, A_Instr_EomEn)));
}
inline InstrEomEn                   _GET_A_Instr_PaidEomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (_GET_ENUM(p, A_Instr_PaidEomEn)));
}
inline InstrPrincipalRuleEn         _GET_A_Instr_PrincipalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPrincipalRuleEn>  (_GET_ENUM(p, A_Instr_PrincipalRuleEn)));
}
inline InstrInterpolConvEn          _GET_A_Instr_InterpolConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterpolConvEn>  (_GET_ENUM(p, A_Instr_InterpolConvEn)));
}
inline InstrInterpolRuleEn          _GET_A_Instr_InterpolRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterpolRuleEn>  (_GET_ENUM(p, A_Instr_InterpolRuleEn)));
}
inline InstrInterestRateConvEn      _GET_A_Instr_InterestRateConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestRateConvEn>  (_GET_ENUM(p, A_Instr_InterestRateConvEn)));
}
inline InstrCouponConvEn            _GET_A_Instr_CouponConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCouponConvEn>  (_GET_ENUM(p, A_Instr_CouponConvEn)));
}
inline InstrPmtCalcConvEn           _GET_A_Instr_PmtCalcConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPmtCalcConvEn>  (_GET_ENUM(p, A_Instr_PmtCalcConvEn)));
}
inline InstrBusDayConvEn            _GET_A_Instr_BusDayConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrBusDayConvEn>  (_GET_ENUM(p, A_Instr_BusDayConvEn)));
}
inline InstrAverPeriodUnitEn        _GET_A_Instr_AverPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAverPeriodUnitEn>  (_GET_ENUM(p, A_Instr_AverPeriodUnitEn)));
}
inline InstrDecompConvEn            _GET_A_Instr_DecompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDecompConvEn>  (_GET_ENUM(p, A_Instr_DecompConvEn)));
}
inline IncEvtPayFreqUnitEn          _GET_A_Instr_TenorFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (_GET_ENUM(p, A_Instr_TenorFreqUnitEn)));
}
inline IncEvtPayFreqUnitEn          _GET_A_Instr_PaidPayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (_GET_ENUM(p, A_Instr_PaidPayFreqUnitEn)));
}
inline ExchEvtEuroConvRuleEn        _GET_A_Instr_EuroConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtEuroConvRuleEn>  (_GET_ENUM(p, A_Instr_EuroConvRuleEn)));
}
inline InstrDecimalDispEn           _GET_A_Instr_DecimalDispEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrDecimalDispEn>  (_GET_ENUM(p, A_Instr_DecimalDispEn)));
}
inline InstrLinearValUnitEn         _GET_A_Instr_LinearValUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLinearValUnitEn>  (_GET_ENUM(p, A_Instr_LinearValUnitEn)));
}
inline InstrRateFreqUnitEn          _GET_A_Instr_FixingRuleFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (_GET_ENUM(p, A_Instr_FixingRuleFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_Instr_PaidCompFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_Instr_PaidCompFreqUnitEn)));
}
inline InstrPaidCompConvEn          _GET_A_Instr_PaidCompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPaidCompConvEn>  (_GET_ENUM(p, A_Instr_PaidCompConvEn)));
}
inline InstrHeartUploadEn           _GET_A_Instr_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrHeartUploadEn>  (_GET_ENUM(p, A_Instr_HeartUploadEn)));
}
inline InstrStatusEn                _GET_A_Instr_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrStatusEn>  (_GET_ENUM(p, A_Instr_StatusEn)));
}
inline IncEvtPayFreqUnitEn          _GET_A_Instr_PriceCalcFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (_GET_ENUM(p, A_Instr_PriceCalcFreqUnitEn)));
}
inline InstrStpOrderEn              _GET_A_Instr_StpOrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrStpOrderEn>  (_GET_ENUM(p, A_Instr_StpOrderEn)));
}
inline InstrTradeNatEn              _GET_A_Instr_TradeNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTradeNatEn>  (_GET_ENUM(p, A_Instr_TradeNatEn)));
}
inline TermEvtBarrierNatEn          _GET_A_Instr_BarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (_GET_ENUM(p, A_Instr_BarrierNatEn)));
}
inline TermEvtBarrierNatEn          _GET_A_Instr_UpperBarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (_GET_ENUM(p, A_Instr_UpperBarrierNatEn)));
}
inline TermEvtPayOffNatEn           _GET_A_Instr_PayOffNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtPayOffNatEn>  (_GET_ENUM(p, A_Instr_PayOffNatEn)));
}
inline InstrInstrumentClassEn       _GET_A_Instr_InstrumentClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInstrumentClassEn>  (_GET_ENUM(p, A_Instr_InstrumentClassEn)));
}
inline InstrComplexityLevelEn       _GET_A_Instr_ComplexityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrComplexityLevelEn>  (_GET_ENUM(p, A_Instr_ComplexityLevelEn)));
}
inline InstrIslamicComplianceEn     _GET_A_Instr_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (_GET_ENUM(p, A_Instr_IslamicComplianceEn)));
}
inline InstrFundIncomeStyleEn       _GET_A_Instr_FundIncomeStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrFundIncomeStyleEn>  (_GET_ENUM(p, A_Instr_FundIncomeStyleEn)));
}
inline InstrRateFreqUnitEn          _GET_A_Instr_CoolperiodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (_GET_ENUM(p, A_Instr_CoolperiodUnitEn)));
}
inline InstrUnderlyCatEn            _GET_A_Instr_UnderlyCatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrUnderlyCatEn>  (_GET_ENUM(p, A_Instr_UnderlyCatEn)));
}
inline InstrInterestCalculationRuleEn _GET_A_Instr_InterestCalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrInterestCalculationRuleEn>  (_GET_ENUM(p, A_Instr_InterestCalculationRuleEn)));
}
inline InstrConvertInterestEn       _GET_A_Instr_ConvertInterestEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrConvertInterestEn>  (_GET_ENUM(p, A_Instr_ConvertInterestEn)));
}
inline InstrUsageNatEn              _GET_A_Instr_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrUsageNatEn>  (_GET_ENUM(p, A_Instr_UsageNatEn)));
}
inline InstrOrderGenMngtEn          _GET_A_Instr_OrderGenMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrOrderGenMngtEn>  (_GET_ENUM(p, A_Instr_OrderGenMngtEn)));
}
inline InstrAutoRenewalEn           _GET_A_Instr_AutoRenewalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAutoRenewalEn>  (_GET_ENUM(p, A_Instr_AutoRenewalEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_Instr_PriceFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_Instr_PriceFreqUnitEn)));
}
inline InstrTempDerivedInstrLocEn   _GET_A_Instr_TempDerivedInstrLocEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrTempDerivedInstrLocEn>  (_GET_ENUM(p, A_Instr_TempDerivedInstrLocEn)));
}
inline InstrEventTypeEn             _GET_A_Instr_EventTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEventTypeEn>  (_GET_ENUM(p, A_Instr_EventTypeEn)));
}
inline InstrBoAccruedIntRuleEn      _GET_A_Instr_BoAccruedIntRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrBoAccruedIntRuleEn>  (_GET_ENUM(p, A_Instr_BoAccruedIntRuleEn)));
}
inline InstrMktConvMethodEn         _GET_A_Instr_MktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (_GET_ENUM(p, A_Instr_MktConvMethodEn)));
}
inline InstrLookbackConvEn          _GET_A_Instr_LookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (_GET_ENUM(p, A_Instr_LookbackConvEn)));
}
inline InstrMktConvMethodEn         _GET_A_Instr_PaidMktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (_GET_ENUM(p, A_Instr_PaidMktConvMethodEn)));
}
inline InstrLookbackConvEn          _GET_A_Instr_PaidLookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (_GET_ENUM(p, A_Instr_PaidLookbackConvEn)));
}
inline InstrRenewalTreatmentEn      _GET_A_Instr_RenewalTreatmentEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRenewalTreatmentEn>  (_GET_ENUM(p, A_Instr_RenewalTreatmentEn)));
}
inline DictAttributeTemplateDlmEn   _GET_A_Instr_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (_GET_ENUM(p, A_Instr_DlmEn)));
}

inline void                         SET_A_Instr_NatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_Instr_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Instr_NatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_Instr_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_ValRuleEn(DBA_DYNFLD_STP p, InstrValRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_ValRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_AccrualRuleEn(DBA_DYNFLD_STP p, InstrAccrualRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_AccrualRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IssueCdEn(DBA_DYNFLD_STP p, InstrIssueCdEn enumValue)
{
    SET_ENUM(p, A_Instr_IssueCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IncomeCdEn(DBA_DYNFLD_STP p, InstrIncomeCdEn enumValue)
{
    SET_ENUM(p, A_Instr_IncomeCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_RedempCdEn(DBA_DYNFLD_STP p, InstrRedempCdEn enumValue)
{
    SET_ENUM(p, A_Instr_RedempCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_TermCdEn(DBA_DYNFLD_STP p, InstrTermCdEn enumValue)
{
    SET_ENUM(p, A_Instr_TermCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InterestCdEn(DBA_DYNFLD_STP p, InstrInterestCdEn enumValue)
{
    SET_ENUM(p, A_Instr_InterestCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_ExchangeCdEn(DBA_DYNFLD_STP p, InstrExchangeCdEn enumValue)
{
    SET_ENUM(p, A_Instr_ExchangeCdEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PayFreqUnitEn(DBA_DYNFLD_STP p, IncEvtPayFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_PayFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_OptionClassEn(DBA_DYNFLD_STP p, InstrOptionClassEn enumValue)
{
    SET_ENUM(p, A_Instr_OptionClassEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_OptStyleEn(DBA_DYNFLD_STP p, InstrOptStyleEn enumValue)
{
    SET_ENUM(p, A_Instr_OptStyleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IdxReturnTypeEn(DBA_DYNFLD_STP p, InstrIdxReturnTypeEn enumValue)
{
    SET_ENUM(p, A_Instr_IdxReturnTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IdxCalcRuleEn(DBA_DYNFLD_STP p, InstrIdxCalcRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_IdxCalcRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IdxTimeRuleEn(DBA_DYNFLD_STP p, InstrIdxTimeRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_IdxTimeRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_RateFreqUnitEn(DBA_DYNFLD_STP p, InstrRateFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_RateFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InvoicePriceRuleEn(DBA_DYNFLD_STP p, InstrInvoicePriceRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_InvoicePriceRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_RiskNatEn(DBA_DYNFLD_STP p, InstrRiskNatEn enumValue)
{
    SET_ENUM(p, A_Instr_RiskNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_SubNatEn(DBA_DYNFLD_STP p, InstrSubNatEn enumValue)
{
    SET_ENUM(p, A_Instr_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Instr_SubNatEn(DBA_DYNFLD_STP p, InstrSubNatEn enumValue)
{
    SET_ENUM(p, S_Instr_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_AiRoundRuleEn(DBA_DYNFLD_STP p, InstrAiRoundRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_AiRoundRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_ContractNatEn(DBA_DYNFLD_STP p, InstrContractNatEn enumValue)
{
    SET_ENUM(p, A_Instr_ContractNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_DefModelEn(DBA_DYNFLD_STP p, InstrDefModelEn enumValue)
{
    SET_ENUM(p, A_Instr_DefModelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_CompFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_CompFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_CompConvEn(DBA_DYNFLD_STP p, InstrCompConvEn enumValue)
{
    SET_ENUM(p, A_Instr_CompConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_BacksetDelayUnitEn(DBA_DYNFLD_STP p, InterCondResetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_BacksetDelayUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidAccrualRuleEn(DBA_DYNFLD_STP p, InstrAccrualRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidAccrualRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_MortgageNatEn(DBA_DYNFLD_STP p, InstrMortgageNatEn enumValue)
{
    SET_ENUM(p, A_Instr_MortgageNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_LongTermPeriodUnitEn(DBA_DYNFLD_STP p, InstrLongTermPeriodUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_LongTermPeriodUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PremiumPmtEn(DBA_DYNFLD_STP p, InstrPremiumPmtEn enumValue)
{
    SET_ENUM(p, A_Instr_PremiumPmtEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_EomEn(DBA_DYNFLD_STP p, InstrEomEn enumValue)
{
    SET_ENUM(p, A_Instr_EomEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidEomEn(DBA_DYNFLD_STP p, InstrEomEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidEomEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PrincipalRuleEn(DBA_DYNFLD_STP p, InstrPrincipalRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_PrincipalRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InterpolConvEn(DBA_DYNFLD_STP p, InstrInterpolConvEn enumValue)
{
    SET_ENUM(p, A_Instr_InterpolConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InterpolRuleEn(DBA_DYNFLD_STP p, InstrInterpolRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_InterpolRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InterestRateConvEn(DBA_DYNFLD_STP p, InstrInterestRateConvEn enumValue)
{
    SET_ENUM(p, A_Instr_InterestRateConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_CouponConvEn(DBA_DYNFLD_STP p, InstrCouponConvEn enumValue)
{
    SET_ENUM(p, A_Instr_CouponConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PmtCalcConvEn(DBA_DYNFLD_STP p, InstrPmtCalcConvEn enumValue)
{
    SET_ENUM(p, A_Instr_PmtCalcConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_BusDayConvEn(DBA_DYNFLD_STP p, InstrBusDayConvEn enumValue)
{
    SET_ENUM(p, A_Instr_BusDayConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_AverPeriodUnitEn(DBA_DYNFLD_STP p, InstrAverPeriodUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_AverPeriodUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_DecompConvEn(DBA_DYNFLD_STP p, InstrDecompConvEn enumValue)
{
    SET_ENUM(p, A_Instr_DecompConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_TenorFreqUnitEn(DBA_DYNFLD_STP p, IncEvtPayFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_TenorFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidPayFreqUnitEn(DBA_DYNFLD_STP p, IncEvtPayFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidPayFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_EuroConvRuleEn(DBA_DYNFLD_STP p, ExchEvtEuroConvRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_EuroConvRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_DecimalDispEn(DBA_DYNFLD_STP p, InstrDecimalDispEn enumValue)
{
    SET_ENUM(p, A_Instr_DecimalDispEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_LinearValUnitEn(DBA_DYNFLD_STP p, InstrLinearValUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_LinearValUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_FixingRuleFreqUnitEn(DBA_DYNFLD_STP p, InstrRateFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_FixingRuleFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidCompFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidCompFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidCompConvEn(DBA_DYNFLD_STP p, InstrPaidCompConvEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidCompConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_HeartUploadEn(DBA_DYNFLD_STP p, InstrHeartUploadEn enumValue)
{
    SET_ENUM(p, A_Instr_HeartUploadEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_StatusEn(DBA_DYNFLD_STP p, InstrStatusEn enumValue)
{
    SET_ENUM(p, A_Instr_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PriceCalcFreqUnitEn(DBA_DYNFLD_STP p, IncEvtPayFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_PriceCalcFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_StpOrderEn(DBA_DYNFLD_STP p, InstrStpOrderEn enumValue)
{
    SET_ENUM(p, A_Instr_StpOrderEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_TradeNatEn(DBA_DYNFLD_STP p, InstrTradeNatEn enumValue)
{
    SET_ENUM(p, A_Instr_TradeNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_BarrierNatEn(DBA_DYNFLD_STP p, TermEvtBarrierNatEn enumValue)
{
    SET_ENUM(p, A_Instr_BarrierNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_UpperBarrierNatEn(DBA_DYNFLD_STP p, TermEvtBarrierNatEn enumValue)
{
    SET_ENUM(p, A_Instr_UpperBarrierNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PayOffNatEn(DBA_DYNFLD_STP p, TermEvtPayOffNatEn enumValue)
{
    SET_ENUM(p, A_Instr_PayOffNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InstrumentClassEn(DBA_DYNFLD_STP p, InstrInstrumentClassEn enumValue)
{
    SET_ENUM(p, A_Instr_InstrumentClassEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_ComplexityLevelEn(DBA_DYNFLD_STP p, InstrComplexityLevelEn enumValue)
{
    SET_ENUM(p, A_Instr_ComplexityLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_IslamicComplianceEn(DBA_DYNFLD_STP p, InstrIslamicComplianceEn enumValue)
{
    SET_ENUM(p, A_Instr_IslamicComplianceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_FundIncomeStyleEn(DBA_DYNFLD_STP p, InstrFundIncomeStyleEn enumValue)
{
    SET_ENUM(p, A_Instr_FundIncomeStyleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_CoolperiodUnitEn(DBA_DYNFLD_STP p, InstrRateFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_CoolperiodUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_UnderlyCatEn(DBA_DYNFLD_STP p, InstrUnderlyCatEn enumValue)
{
    SET_ENUM(p, A_Instr_UnderlyCatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_InterestCalculationRuleEn(DBA_DYNFLD_STP p, InstrInterestCalculationRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_InterestCalculationRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_ConvertInterestEn(DBA_DYNFLD_STP p, InstrConvertInterestEn enumValue)
{
    SET_ENUM(p, A_Instr_ConvertInterestEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_UsageNatEn(DBA_DYNFLD_STP p, InstrUsageNatEn enumValue)
{
    SET_ENUM(p, A_Instr_UsageNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_OrderGenMngtEn(DBA_DYNFLD_STP p, InstrOrderGenMngtEn enumValue)
{
    SET_ENUM(p, A_Instr_OrderGenMngtEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_AutoRenewalEn(DBA_DYNFLD_STP p, InstrAutoRenewalEn enumValue)
{
    SET_ENUM(p, A_Instr_AutoRenewalEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PriceFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Instr_PriceFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_TempDerivedInstrLocEn(DBA_DYNFLD_STP p, InstrTempDerivedInstrLocEn enumValue)
{
    SET_ENUM(p, A_Instr_TempDerivedInstrLocEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_EventTypeEn(DBA_DYNFLD_STP p, InstrEventTypeEn enumValue)
{
    SET_ENUM(p, A_Instr_EventTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_BoAccruedIntRuleEn(DBA_DYNFLD_STP p, InstrBoAccruedIntRuleEn enumValue)
{
    SET_ENUM(p, A_Instr_BoAccruedIntRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_MktConvMethodEn(DBA_DYNFLD_STP p, InstrMktConvMethodEn enumValue)
{
    SET_ENUM(p, A_Instr_MktConvMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_LookbackConvEn(DBA_DYNFLD_STP p, InstrLookbackConvEn enumValue)
{
    SET_ENUM(p, A_Instr_LookbackConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidMktConvMethodEn(DBA_DYNFLD_STP p, InstrMktConvMethodEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidMktConvMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_PaidLookbackConvEn(DBA_DYNFLD_STP p, InstrLookbackConvEn enumValue)
{
    SET_ENUM(p, A_Instr_PaidLookbackConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_RenewalTreatmentEn(DBA_DYNFLD_STP p, InstrRenewalTreatmentEn enumValue)
{
    SET_ENUM(p, A_Instr_RenewalTreatmentEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Instr_DlmEn(DBA_DYNFLD_STP p, DictAttributeTemplateDlmEn enumValue)
{
    SET_ENUM(p, A_Instr_DlmEn, static_cast<unsigned char>(enumValue));
}


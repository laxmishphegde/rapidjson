/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline FmtNatEn                     GET_A_Fmt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtNatEn>  (GET_ENUM(p, A_Fmt_NatEn)));
}
inline FmtNatEn                     GET_S_Fmt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtNatEn>  (GET_ENUM(p, S_Fmt_NatEn)));
}
inline FmtGraphTypeEn               GET_A_Fmt_GraphTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphTypeEn>  (GET_ENUM(p, A_Fmt_GraphTypeEn)));
}
inline FmtGraphViewEn               GET_A_Fmt_GraphViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphViewEn>  (GET_ENUM(p, A_Fmt_GraphViewEn)));
}
inline FmtJustifEn                  GET_A_Fmt_JustifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtJustifEn>  (GET_ENUM(p, A_Fmt_JustifEn)));
}
inline FmtHeaderFrameEn             GET_A_Fmt_HeaderFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFrameEn>  (GET_ENUM(p, A_Fmt_HeaderFrameEn)));
}
inline FmtHeaderFontEn              GET_A_Fmt_HeaderFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (GET_ENUM(p, A_Fmt_HeaderFontEn)));
}
inline FmtTitleJustifEn             GET_A_Fmt_TitleJustifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTitleJustifEn>  (GET_ENUM(p, A_Fmt_TitleJustifEn)));
}
inline FmtHeaderFontEn              GET_A_Fmt_TitleFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (GET_ENUM(p, A_Fmt_TitleFontEn)));
}
inline FmtTitleFrameEn              GET_A_Fmt_TitleFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTitleFrameEn>  (GET_ENUM(p, A_Fmt_TitleFrameEn)));
}
inline FmtHeaderFontEn              GET_A_Fmt_TotalFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (GET_ENUM(p, A_Fmt_TotalFontEn)));
}
inline FmtTotalFrameEn              GET_A_Fmt_TotalFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTotalFrameEn>  (GET_ENUM(p, A_Fmt_TotalFrameEn)));
}
inline FmtGraphPatternEn            GET_A_Fmt_GraphPatternEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphPatternEn>  (GET_ENUM(p, A_Fmt_GraphPatternEn)));
}
inline FmtGraphLegendPosEn          GET_A_Fmt_GraphLegendPosEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphLegendPosEn>  (GET_ENUM(p, A_Fmt_GraphLegendPosEn)));
}
inline FmtGraphExplodeEn            GET_A_Fmt_GraphExplodeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphExplodeEn>  (GET_ENUM(p, A_Fmt_GraphExplodeEn)));
}
inline FmtTslExtensionNatEn         GET_A_Fmt_TslExtensionNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTslExtensionNatEn>  (GET_ENUM(p, A_Fmt_TslExtensionNatEn)));
}
inline FmtReferenceStatusEn         GET_A_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtReferenceStatusEn>  (GET_ENUM(p, A_Fmt_ReferenceStatusEn)));
}
inline FmtReferenceStatusEn         GET_S_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtReferenceStatusEn>  (GET_ENUM(p, S_Fmt_ReferenceStatusEn)));
}
inline FmtColumnLimitEn             GET_A_Fmt_ColumnLimitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtColumnLimitEn>  (GET_ENUM(p, A_Fmt_ColumnLimitEn)));
}
inline FmtRowLimitEn                GET_A_Fmt_RowLimitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtRowLimitEn>  (GET_ENUM(p, A_Fmt_RowLimitEn)));
}

inline FmtNatEn                     _GET_A_Fmt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtNatEn>  (_GET_ENUM(p, A_Fmt_NatEn)));
}
inline FmtNatEn                     _GET_S_Fmt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtNatEn>  (_GET_ENUM(p, S_Fmt_NatEn)));
}
inline FmtGraphTypeEn               _GET_A_Fmt_GraphTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphTypeEn>  (_GET_ENUM(p, A_Fmt_GraphTypeEn)));
}
inline FmtGraphViewEn               _GET_A_Fmt_GraphViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphViewEn>  (_GET_ENUM(p, A_Fmt_GraphViewEn)));
}
inline FmtJustifEn                  _GET_A_Fmt_JustifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtJustifEn>  (_GET_ENUM(p, A_Fmt_JustifEn)));
}
inline FmtHeaderFrameEn             _GET_A_Fmt_HeaderFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFrameEn>  (_GET_ENUM(p, A_Fmt_HeaderFrameEn)));
}
inline FmtHeaderFontEn              _GET_A_Fmt_HeaderFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (_GET_ENUM(p, A_Fmt_HeaderFontEn)));
}
inline FmtTitleJustifEn             _GET_A_Fmt_TitleJustifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTitleJustifEn>  (_GET_ENUM(p, A_Fmt_TitleJustifEn)));
}
inline FmtHeaderFontEn              _GET_A_Fmt_TitleFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (_GET_ENUM(p, A_Fmt_TitleFontEn)));
}
inline FmtTitleFrameEn              _GET_A_Fmt_TitleFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTitleFrameEn>  (_GET_ENUM(p, A_Fmt_TitleFrameEn)));
}
inline FmtHeaderFontEn              _GET_A_Fmt_TotalFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (_GET_ENUM(p, A_Fmt_TotalFontEn)));
}
inline FmtTotalFrameEn              _GET_A_Fmt_TotalFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTotalFrameEn>  (_GET_ENUM(p, A_Fmt_TotalFrameEn)));
}
inline FmtGraphPatternEn            _GET_A_Fmt_GraphPatternEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphPatternEn>  (_GET_ENUM(p, A_Fmt_GraphPatternEn)));
}
inline FmtGraphLegendPosEn          _GET_A_Fmt_GraphLegendPosEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphLegendPosEn>  (_GET_ENUM(p, A_Fmt_GraphLegendPosEn)));
}
inline FmtGraphExplodeEn            _GET_A_Fmt_GraphExplodeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtGraphExplodeEn>  (_GET_ENUM(p, A_Fmt_GraphExplodeEn)));
}
inline FmtTslExtensionNatEn         _GET_A_Fmt_TslExtensionNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtTslExtensionNatEn>  (_GET_ENUM(p, A_Fmt_TslExtensionNatEn)));
}
inline FmtReferenceStatusEn         _GET_A_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtReferenceStatusEn>  (_GET_ENUM(p, A_Fmt_ReferenceStatusEn)));
}
inline FmtReferenceStatusEn         _GET_S_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtReferenceStatusEn>  (_GET_ENUM(p, S_Fmt_ReferenceStatusEn)));
}
inline FmtColumnLimitEn             _GET_A_Fmt_ColumnLimitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtColumnLimitEn>  (_GET_ENUM(p, A_Fmt_ColumnLimitEn)));
}
inline FmtRowLimitEn                _GET_A_Fmt_RowLimitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtRowLimitEn>  (_GET_ENUM(p, A_Fmt_RowLimitEn)));
}

inline void                         SET_A_Fmt_NatEn(DBA_DYNFLD_STP p, FmtNatEn enumValue)
{
    SET_ENUM(p, A_Fmt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Fmt_NatEn(DBA_DYNFLD_STP p, FmtNatEn enumValue)
{
    SET_ENUM(p, S_Fmt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_GraphTypeEn(DBA_DYNFLD_STP p, FmtGraphTypeEn enumValue)
{
    SET_ENUM(p, A_Fmt_GraphTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_GraphViewEn(DBA_DYNFLD_STP p, FmtGraphViewEn enumValue)
{
    SET_ENUM(p, A_Fmt_GraphViewEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_JustifEn(DBA_DYNFLD_STP p, FmtJustifEn enumValue)
{
    SET_ENUM(p, A_Fmt_JustifEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_HeaderFrameEn(DBA_DYNFLD_STP p, FmtHeaderFrameEn enumValue)
{
    SET_ENUM(p, A_Fmt_HeaderFrameEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_HeaderFontEn(DBA_DYNFLD_STP p, FmtHeaderFontEn enumValue)
{
    SET_ENUM(p, A_Fmt_HeaderFontEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TitleJustifEn(DBA_DYNFLD_STP p, FmtTitleJustifEn enumValue)
{
    SET_ENUM(p, A_Fmt_TitleJustifEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TitleFontEn(DBA_DYNFLD_STP p, FmtHeaderFontEn enumValue)
{
    SET_ENUM(p, A_Fmt_TitleFontEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TitleFrameEn(DBA_DYNFLD_STP p, FmtTitleFrameEn enumValue)
{
    SET_ENUM(p, A_Fmt_TitleFrameEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TotalFontEn(DBA_DYNFLD_STP p, FmtHeaderFontEn enumValue)
{
    SET_ENUM(p, A_Fmt_TotalFontEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TotalFrameEn(DBA_DYNFLD_STP p, FmtTotalFrameEn enumValue)
{
    SET_ENUM(p, A_Fmt_TotalFrameEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_GraphPatternEn(DBA_DYNFLD_STP p, FmtGraphPatternEn enumValue)
{
    SET_ENUM(p, A_Fmt_GraphPatternEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_GraphLegendPosEn(DBA_DYNFLD_STP p, FmtGraphLegendPosEn enumValue)
{
    SET_ENUM(p, A_Fmt_GraphLegendPosEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_GraphExplodeEn(DBA_DYNFLD_STP p, FmtGraphExplodeEn enumValue)
{
    SET_ENUM(p, A_Fmt_GraphExplodeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_TslExtensionNatEn(DBA_DYNFLD_STP p, FmtTslExtensionNatEn enumValue)
{
    SET_ENUM(p, A_Fmt_TslExtensionNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p, FmtReferenceStatusEn enumValue)
{
    SET_ENUM(p, A_Fmt_ReferenceStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Fmt_ReferenceStatusEn(DBA_DYNFLD_STP p, FmtReferenceStatusEn enumValue)
{
    SET_ENUM(p, S_Fmt_ReferenceStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_ColumnLimitEn(DBA_DYNFLD_STP p, FmtColumnLimitEn enumValue)
{
    SET_ENUM(p, A_Fmt_ColumnLimitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Fmt_RowLimitEn(DBA_DYNFLD_STP p, FmtRowLimitEn enumValue)
{
    SET_ENUM(p, A_Fmt_RowLimitEn, static_cast<unsigned char>(enumValue));
}


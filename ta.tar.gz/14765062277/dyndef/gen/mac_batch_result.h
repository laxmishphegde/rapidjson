/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BatchResultNatEn             GET_A_BatchResult_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultNatEn>  (GET_ENUM(p, A_BatchResult_NatEn)));
}
inline BatchResultNatEn             GET_S_BatchResult_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultNatEn>  (GET_ENUM(p, S_BatchResult_NatEn)));
}
inline BatchResultStatusEn          GET_A_BatchResult_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultStatusEn>  (GET_ENUM(p, A_BatchResult_StatusEn)));
}
inline BatchResultStatusEn          GET_S_BatchResult_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultStatusEn>  (GET_ENUM(p, S_BatchResult_StatusEn)));
}

inline BatchResultNatEn             _GET_A_BatchResult_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultNatEn>  (_GET_ENUM(p, A_BatchResult_NatEn)));
}
inline BatchResultNatEn             _GET_S_BatchResult_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultNatEn>  (_GET_ENUM(p, S_BatchResult_NatEn)));
}
inline BatchResultStatusEn          _GET_A_BatchResult_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultStatusEn>  (_GET_ENUM(p, A_BatchResult_StatusEn)));
}
inline BatchResultStatusEn          _GET_S_BatchResult_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BatchResultStatusEn>  (_GET_ENUM(p, S_BatchResult_StatusEn)));
}

inline void                         SET_A_BatchResult_NatEn(DBA_DYNFLD_STP p, BatchResultNatEn enumValue)
{
    SET_ENUM(p, A_BatchResult_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_BatchResult_NatEn(DBA_DYNFLD_STP p, BatchResultNatEn enumValue)
{
    SET_ENUM(p, S_BatchResult_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_BatchResult_StatusEn(DBA_DYNFLD_STP p, BatchResultStatusEn enumValue)
{
    SET_ENUM(p, A_BatchResult_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_BatchResult_StatusEn(DBA_DYNFLD_STP p, BatchResultStatusEn enumValue)
{
    SET_ENUM(p, S_BatchResult_StatusEn, static_cast<unsigned char>(enumValue));
}


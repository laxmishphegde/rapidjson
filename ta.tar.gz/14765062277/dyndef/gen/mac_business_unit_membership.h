/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusinessUnitMembershipPermissionEn GET_A_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitMembershipPermissionEn>  (GET_ENUM(p, A_BusinessUnitMembership_PermissionEn)));
}
inline BusinessUnitMembershipPermissionEn GET_S_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitMembershipPermissionEn>  (GET_ENUM(p, S_BusinessUnitMembership_PermissionEn)));
}

inline BusinessUnitMembershipPermissionEn _GET_A_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitMembershipPermissionEn>  (_GET_ENUM(p, A_BusinessUnitMembership_PermissionEn)));
}
inline BusinessUnitMembershipPermissionEn _GET_S_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitMembershipPermissionEn>  (_GET_ENUM(p, S_BusinessUnitMembership_PermissionEn)));
}

inline void                         SET_A_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p, BusinessUnitMembershipPermissionEn enumValue)
{
    SET_ENUM(p, A_BusinessUnitMembership_PermissionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_BusinessUnitMembership_PermissionEn(DBA_DYNFLD_STP p, BusinessUnitMembershipPermissionEn enumValue)
{
    SET_ENUM(p, S_BusinessUnitMembership_PermissionEn, static_cast<unsigned char>(enumValue));
}


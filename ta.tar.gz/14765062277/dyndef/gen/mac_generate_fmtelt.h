/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline GenerateFmteltScopeEn        GET_A_GenerateFmtelt_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<GenerateFmteltScopeEn>  (GET_ENUM(p, A_GenerateFmtelt_ScopeEn)));
}

inline GenerateFmteltScopeEn        _GET_A_GenerateFmtelt_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<GenerateFmteltScopeEn>  (_GET_ENUM(p, A_GenerateFmtelt_ScopeEn)));
}

inline void                         SET_A_GenerateFmtelt_ScopeEn(DBA_DYNFLD_STP p, GenerateFmteltScopeEn enumValue)
{
    SET_ENUM(p, A_GenerateFmtelt_ScopeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline EventStatusErrorReasonEn     GET_A_EventStatus_ErrorReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventStatusErrorReasonEn>  (GET_ENUM(p, A_EventStatus_ErrorReasonEn)));
}

inline EventStatusErrorReasonEn     _GET_A_EventStatus_ErrorReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EventStatusErrorReasonEn>  (_GET_ENUM(p, A_EventStatus_ErrorReasonEn)));
}

inline void                         SET_A_EventStatus_ErrorReasonEn(DBA_DYNFLD_STP p, EventStatusErrorReasonEn enumValue)
{
    SET_ENUM(p, A_EventStatus_ErrorReasonEn, static_cast<unsigned char>(enumValue));
}


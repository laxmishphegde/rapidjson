/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictAttributeTemplateDlmEn   GET_A_DictAttributeTemplate_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (GET_ENUM(p, A_DictAttributeTemplate_DlmEn)));
}
inline DictAttributeTemplateObjStatusEn GET_A_DictAttributeTemplate_ObjStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateObjStatusEn>  (GET_ENUM(p, A_DictAttributeTemplate_ObjStatusEn)));
}
inline DictAttributeTemplateShActionEn GET_A_DictAttributeTemplate_ShActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateShActionEn>  (GET_ENUM(p, A_DictAttributeTemplate_ShActionEn)));
}
inline DictAttributeTemplateRightReasonEn GET_A_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateRightReasonEn>  (GET_ENUM(p, A_DictAttributeTemplate_RightReasonEn)));
}
inline DictAttributeTemplateRightReasonEn GET_S_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateRightReasonEn>  (GET_ENUM(p, S_DictAttributeTemplate_RightReasonEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_A_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, A_DictAttributeTemplate_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_S_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, S_DictAttributeTemplate_MeRecordLocationEn)));
}
inline DictAttributeTemplateXActiveEn GET_A_DictAttributeTemplate_XActiveEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateXActiveEn>  (GET_ENUM(p, A_DictAttributeTemplate_XActiveEn)));
}
inline DictAttributeTemplatePrivilegeEn GET_A_DictAttributeTemplate_PrivilegeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplatePrivilegeEn>  (GET_ENUM(p, A_DictAttributeTemplate_PrivilegeEn)));
}

inline DictAttributeTemplateDlmEn   _GET_A_DictAttributeTemplate_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (_GET_ENUM(p, A_DictAttributeTemplate_DlmEn)));
}
inline DictAttributeTemplateObjStatusEn _GET_A_DictAttributeTemplate_ObjStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateObjStatusEn>  (_GET_ENUM(p, A_DictAttributeTemplate_ObjStatusEn)));
}
inline DictAttributeTemplateShActionEn _GET_A_DictAttributeTemplate_ShActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateShActionEn>  (_GET_ENUM(p, A_DictAttributeTemplate_ShActionEn)));
}
inline DictAttributeTemplateRightReasonEn _GET_A_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateRightReasonEn>  (_GET_ENUM(p, A_DictAttributeTemplate_RightReasonEn)));
}
inline DictAttributeTemplateRightReasonEn _GET_S_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateRightReasonEn>  (_GET_ENUM(p, S_DictAttributeTemplate_RightReasonEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_A_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, A_DictAttributeTemplate_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_S_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, S_DictAttributeTemplate_MeRecordLocationEn)));
}
inline DictAttributeTemplateXActiveEn _GET_A_DictAttributeTemplate_XActiveEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateXActiveEn>  (_GET_ENUM(p, A_DictAttributeTemplate_XActiveEn)));
}
inline DictAttributeTemplatePrivilegeEn _GET_A_DictAttributeTemplate_PrivilegeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplatePrivilegeEn>  (_GET_ENUM(p, A_DictAttributeTemplate_PrivilegeEn)));
}

inline void                         SET_A_DictAttributeTemplate_DlmEn(DBA_DYNFLD_STP p, DictAttributeTemplateDlmEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_DlmEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_ObjStatusEn(DBA_DYNFLD_STP p, DictAttributeTemplateObjStatusEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_ObjStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_ShActionEn(DBA_DYNFLD_STP p, DictAttributeTemplateShActionEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_ShActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p, DictAttributeTemplateRightReasonEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_RightReasonEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DictAttributeTemplate_RightReasonEn(DBA_DYNFLD_STP p, DictAttributeTemplateRightReasonEn enumValue)
{
    SET_ENUM(p, S_DictAttributeTemplate_RightReasonEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DictAttributeTemplate_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, S_DictAttributeTemplate_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_XActiveEn(DBA_DYNFLD_STP p, DictAttributeTemplateXActiveEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_XActiveEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictAttributeTemplate_PrivilegeEn(DBA_DYNFLD_STP p, DictAttributeTemplatePrivilegeEn enumValue)
{
    SET_ENUM(p, A_DictAttributeTemplate_PrivilegeEn, static_cast<unsigned char>(enumValue));
}


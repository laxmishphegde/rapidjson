/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictEntityTypingNat          GET_A_DictEntity_TypingNat(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityTypingNat>  (GET_ENUM(p, A_DictEntity_TypingNat)));
}
inline DictEntityInterfaceEn        GET_A_DictEntity_InterfaceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityInterfaceEn>  (GET_ENUM(p, A_DictEntity_InterfaceEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_AuditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_AuditEn)));
}
inline DictEntityNatEn              GET_A_DictEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, A_DictEntity_NatEn)));
}
inline DictEntityNatEn              GET_S_DictEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, S_DictEntity_NatEn)));
}
inline XdEntityXdStatusEn           GET_A_DictEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictEntity_XdStatusEn)));
}
inline DictEntitySecurityLevelEn    GET_A_DictEntity_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntitySecurityLevelEn>  (GET_ENUM(p, A_DictEntity_SecurityLevelEn)));
}
inline DictEntityPkRuleEn           GET_A_DictEntity_PkRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityPkRuleEn>  (GET_ENUM(p, A_DictEntity_PkRuleEn)));
}
inline XdEntityDeleteRuleEn         GET_A_DictEntity_DeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDeleteRuleEn>  (GET_ENUM(p, A_DictEntity_DeleteRuleEn)));
}
inline XdEntityLastModifEn          GET_A_DictEntity_LastModifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_DictEntity_LastModifEn)));
}
inline XdEntityLastModifEn          GET_A_DictEntity_TableModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_DictEntity_TableModifStatEn)));
}
inline XdEntityLastModifEn          GET_A_DictEntity_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_DictEntity_ObjModifStatEn)));
}
inline XdEntityDbRuleEn             GET_A_DictEntity_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDbRuleEn>  (GET_ENUM(p, A_DictEntity_DbRuleEn)));
}
inline XdEntityLoadDictRuleEn       GET_A_DictEntity_LoadDictRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLoadDictRuleEn>  (GET_ENUM(p, A_DictEntity_LoadDictRuleEn)));
}
inline XdEntityCopyRightEn          GET_A_DictEntity_CopyRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityCopyRightEn>  (GET_ENUM(p, A_DictEntity_CopyRightEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_ExternalSeqAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_UpdFctAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_UpdFctAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_ActiveAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_ActiveAuthEn)));
}
inline XdEntityDmlModifTrackEn      GET_A_DictEntity_DmlModifTrackEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDmlModifTrackEn>  (GET_ENUM(p, A_DictEntity_DmlModifTrackEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_PartAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_PartAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_DictEntity_DlmAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_DictEntity_DlmAuthEn)));
}
inline XdEntityMultiEntityCategoryEn GET_A_DictEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (GET_ENUM(p, A_DictEntity_MultiEntityCategoryEn)));
}

inline DictEntityTypingNat          _GET_A_DictEntity_TypingNat(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityTypingNat>  (_GET_ENUM(p, A_DictEntity_TypingNat)));
}
inline DictEntityInterfaceEn        _GET_A_DictEntity_InterfaceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityInterfaceEn>  (_GET_ENUM(p, A_DictEntity_InterfaceEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_AuditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_AuditEn)));
}
inline DictEntityNatEn              _GET_A_DictEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, A_DictEntity_NatEn)));
}
inline DictEntityNatEn              _GET_S_DictEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, S_DictEntity_NatEn)));
}
inline XdEntityXdStatusEn           _GET_A_DictEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictEntity_XdStatusEn)));
}
inline DictEntitySecurityLevelEn    _GET_A_DictEntity_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntitySecurityLevelEn>  (_GET_ENUM(p, A_DictEntity_SecurityLevelEn)));
}
inline DictEntityPkRuleEn           _GET_A_DictEntity_PkRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityPkRuleEn>  (_GET_ENUM(p, A_DictEntity_PkRuleEn)));
}
inline XdEntityDeleteRuleEn         _GET_A_DictEntity_DeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDeleteRuleEn>  (_GET_ENUM(p, A_DictEntity_DeleteRuleEn)));
}
inline XdEntityLastModifEn          _GET_A_DictEntity_LastModifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_DictEntity_LastModifEn)));
}
inline XdEntityLastModifEn          _GET_A_DictEntity_TableModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_DictEntity_TableModifStatEn)));
}
inline XdEntityLastModifEn          _GET_A_DictEntity_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_DictEntity_ObjModifStatEn)));
}
inline XdEntityDbRuleEn             _GET_A_DictEntity_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDbRuleEn>  (_GET_ENUM(p, A_DictEntity_DbRuleEn)));
}
inline XdEntityLoadDictRuleEn       _GET_A_DictEntity_LoadDictRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLoadDictRuleEn>  (_GET_ENUM(p, A_DictEntity_LoadDictRuleEn)));
}
inline XdEntityCopyRightEn          _GET_A_DictEntity_CopyRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityCopyRightEn>  (_GET_ENUM(p, A_DictEntity_CopyRightEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_ExternalSeqAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_UpdFctAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_UpdFctAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_ActiveAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_ActiveAuthEn)));
}
inline XdEntityDmlModifTrackEn      _GET_A_DictEntity_DmlModifTrackEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDmlModifTrackEn>  (_GET_ENUM(p, A_DictEntity_DmlModifTrackEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_PartAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_PartAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_DictEntity_DlmAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_DictEntity_DlmAuthEn)));
}
inline XdEntityMultiEntityCategoryEn _GET_A_DictEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (_GET_ENUM(p, A_DictEntity_MultiEntityCategoryEn)));
}

inline void                         SET_A_DictEntity_TypingNat(DBA_DYNFLD_STP p, DictEntityTypingNat enumValue)
{
    SET_ENUM(p, A_DictEntity_TypingNat, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_InterfaceEn(DBA_DYNFLD_STP p, DictEntityInterfaceEn enumValue)
{
    SET_ENUM(p, A_DictEntity_InterfaceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_AuditEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_AuditEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_NatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, A_DictEntity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DictEntity_NatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, S_DictEntity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictEntity_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_SecurityLevelEn(DBA_DYNFLD_STP p, DictEntitySecurityLevelEn enumValue)
{
    SET_ENUM(p, A_DictEntity_SecurityLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_PkRuleEn(DBA_DYNFLD_STP p, DictEntityPkRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntity_PkRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_DeleteRuleEn(DBA_DYNFLD_STP p, XdEntityDeleteRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntity_DeleteRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_LastModifEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_DictEntity_LastModifEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_TableModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_DictEntity_TableModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_ObjModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_DictEntity_ObjModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_DbRuleEn(DBA_DYNFLD_STP p, XdEntityDbRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntity_DbRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_LoadDictRuleEn(DBA_DYNFLD_STP p, XdEntityLoadDictRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntity_LoadDictRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_CopyRightEn(DBA_DYNFLD_STP p, XdEntityCopyRightEn enumValue)
{
    SET_ENUM(p, A_DictEntity_CopyRightEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_ExternalSeqAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_UpdFctAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_UpdFctAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_ActiveAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_ActiveAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_DmlModifTrackEn(DBA_DYNFLD_STP p, XdEntityDmlModifTrackEn enumValue)
{
    SET_ENUM(p, A_DictEntity_DmlModifTrackEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_PartAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_PartAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_DlmAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_DictEntity_DlmAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p, XdEntityMultiEntityCategoryEn enumValue)
{
    SET_ENUM(p, A_DictEntity_MultiEntityCategoryEn, static_cast<unsigned char>(enumValue));
}


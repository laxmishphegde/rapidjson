/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ApplUserRoleEn               GET_A_ApplUser_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserRoleEn>  (GET_ENUM(p, A_ApplUser_RoleEn)));
}

inline ApplUserRoleEn               _GET_A_ApplUser_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplUserRoleEn>  (_GET_ENUM(p, A_ApplUser_RoleEn)));
}

inline void                         SET_A_ApplUser_RoleEn(DBA_DYNFLD_STP p, ApplUserRoleEn enumValue)
{
    SET_ENUM(p, A_ApplUser_RoleEn, static_cast<unsigned char>(enumValue));
}


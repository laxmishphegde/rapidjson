/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DdlgenMessageMessageLevelEn  GET_A_DdlgenMessage_MessageLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenMessageMessageLevelEn>  (GET_ENUM(p, A_DdlgenMessage_MessageLevelEn)));
}

inline DdlgenMessageMessageLevelEn  _GET_A_DdlgenMessage_MessageLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenMessageMessageLevelEn>  (_GET_ENUM(p, A_DdlgenMessage_MessageLevelEn)));
}

inline void                         SET_A_DdlgenMessage_MessageLevelEn(DBA_DYNFLD_STP p, DdlgenMessageMessageLevelEn enumValue)
{
    SET_ENUM(p, A_DdlgenMessage_MessageLevelEn, static_cast<unsigned char>(enumValue));
}


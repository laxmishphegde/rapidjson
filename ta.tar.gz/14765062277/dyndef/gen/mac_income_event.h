/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline IncEvtNatEn                  GET_A_IncEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtNatEn>  (GET_ENUM(p, A_IncEvt_NatEn)));
}
inline IncEvtNatEn                  GET_S_IncEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtNatEn>  (GET_ENUM(p, S_IncEvt_NatEn)));
}
inline IncEvtPayFreqUnitEn          GET_A_IncEvt_PayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (GET_ENUM(p, A_IncEvt_PayFreqUnitEn)));
}
inline InstrNatEn                   GET_A_IncEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_IncEvt_InstrNatEn)));
}
inline InstrNatEn                   GET_S_IncEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_IncEvt_InstrNatEn)));
}

inline IncEvtNatEn                  _GET_A_IncEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtNatEn>  (_GET_ENUM(p, A_IncEvt_NatEn)));
}
inline IncEvtNatEn                  _GET_S_IncEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtNatEn>  (_GET_ENUM(p, S_IncEvt_NatEn)));
}
inline IncEvtPayFreqUnitEn          _GET_A_IncEvt_PayFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IncEvtPayFreqUnitEn>  (_GET_ENUM(p, A_IncEvt_PayFreqUnitEn)));
}
inline InstrNatEn                   _GET_A_IncEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_IncEvt_InstrNatEn)));
}
inline InstrNatEn                   _GET_S_IncEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_IncEvt_InstrNatEn)));
}

inline void                         SET_A_IncEvt_NatEn(DBA_DYNFLD_STP p, IncEvtNatEn enumValue)
{
    SET_ENUM(p, A_IncEvt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_IncEvt_NatEn(DBA_DYNFLD_STP p, IncEvtNatEn enumValue)
{
    SET_ENUM(p, S_IncEvt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_IncEvt_PayFreqUnitEn(DBA_DYNFLD_STP p, IncEvtPayFreqUnitEn enumValue)
{
    SET_ENUM(p, A_IncEvt_PayFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_IncEvt_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_IncEvt_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_IncEvt_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_IncEvt_InstrNatEn, static_cast<unsigned char>(enumValue));
}


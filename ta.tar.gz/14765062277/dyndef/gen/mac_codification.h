/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CodifKeyEn                   GET_A_Codif_KeyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CodifKeyEn>  (GET_ENUM(p, A_Codif_KeyEn)));
}
inline CodifNatEn                   GET_A_Codif_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CodifNatEn>  (GET_ENUM(p, A_Codif_NatEn)));
}

inline CodifKeyEn                   _GET_A_Codif_KeyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CodifKeyEn>  (_GET_ENUM(p, A_Codif_KeyEn)));
}
inline CodifNatEn                   _GET_A_Codif_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CodifNatEn>  (_GET_ENUM(p, A_Codif_NatEn)));
}

inline void                         SET_A_Codif_KeyEn(DBA_DYNFLD_STP p, CodifKeyEn enumValue)
{
    SET_ENUM(p, A_Codif_KeyEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Codif_NatEn(DBA_DYNFLD_STP p, CodifNatEn enumValue)
{
    SET_ENUM(p, A_Codif_NatEn, static_cast<unsigned char>(enumValue));
}


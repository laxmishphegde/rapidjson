/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ApplSessionHistoInvalidationReasonEn GET_A_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplSessionHistoInvalidationReasonEn>  (GET_ENUM(p, A_ApplSessionHisto_InvalidationReasonEn)));
}
inline ApplSessionHistoInvalidationReasonEn GET_S_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplSessionHistoInvalidationReasonEn>  (GET_ENUM(p, S_ApplSessionHisto_InvalidationReasonEn)));
}

inline ApplSessionHistoInvalidationReasonEn _GET_A_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplSessionHistoInvalidationReasonEn>  (_GET_ENUM(p, A_ApplSessionHisto_InvalidationReasonEn)));
}
inline ApplSessionHistoInvalidationReasonEn _GET_S_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplSessionHistoInvalidationReasonEn>  (_GET_ENUM(p, S_ApplSessionHisto_InvalidationReasonEn)));
}

inline void                         SET_A_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p, ApplSessionHistoInvalidationReasonEn enumValue)
{
    SET_ENUM(p, A_ApplSessionHisto_InvalidationReasonEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ApplSessionHisto_InvalidationReasonEn(DBA_DYNFLD_STP p, ApplSessionHistoInvalidationReasonEn enumValue)
{
    SET_ENUM(p, S_ApplSessionHisto_InvalidationReasonEn, static_cast<unsigned char>(enumValue));
}


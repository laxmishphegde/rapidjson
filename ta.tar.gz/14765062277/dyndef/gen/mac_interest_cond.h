/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InterCondIntCalcRuleEn       GET_A_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondIntCalcRuleEn>  (GET_ENUM(p, A_InterCond_IntCalcRuleEn)));
}
inline InterCondIntCalcRuleEn       GET_S_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondIntCalcRuleEn>  (GET_ENUM(p, S_InterCond_IntCalcRuleEn)));
}
inline InterCondNatEn               GET_A_InterCond_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondNatEn>  (GET_ENUM(p, A_InterCond_NatEn)));
}
inline InterCondNatEn               GET_S_InterCond_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondNatEn>  (GET_ENUM(p, S_InterCond_NatEn)));
}
inline InterCondResetFreqUnitEn     GET_A_InterCond_ResetFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondResetFreqUnitEn>  (GET_ENUM(p, A_InterCond_ResetFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_InterCond_CompoundFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_InterCond_CompoundFreqUnitEn)));
}
inline InstrCompConvEn              GET_A_InterCond_CompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCompConvEn>  (GET_ENUM(p, A_InterCond_CompConvEn)));
}
inline InstrMktConvMethodEn         GET_A_InterCond_MktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (GET_ENUM(p, A_InterCond_MktConvMethodEn)));
}
inline InstrLookbackConvEn          GET_A_InterCond_LookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (GET_ENUM(p, A_InterCond_LookbackConvEn)));
}
inline InstrNatEn                   GET_A_InterCond_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_InterCond_InstrNatEn)));
}
inline InstrNatEn                   GET_S_InterCond_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_InterCond_InstrNatEn)));
}
inline InstrAverPeriodUnitEn        GET_A_InterCond_AverPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAverPeriodUnitEn>  (GET_ENUM(p, A_InterCond_AverPeriodUnitEn)));
}

inline InterCondIntCalcRuleEn       _GET_A_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondIntCalcRuleEn>  (_GET_ENUM(p, A_InterCond_IntCalcRuleEn)));
}
inline InterCondIntCalcRuleEn       _GET_S_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondIntCalcRuleEn>  (_GET_ENUM(p, S_InterCond_IntCalcRuleEn)));
}
inline InterCondNatEn               _GET_A_InterCond_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondNatEn>  (_GET_ENUM(p, A_InterCond_NatEn)));
}
inline InterCondNatEn               _GET_S_InterCond_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondNatEn>  (_GET_ENUM(p, S_InterCond_NatEn)));
}
inline InterCondResetFreqUnitEn     _GET_A_InterCond_ResetFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondResetFreqUnitEn>  (_GET_ENUM(p, A_InterCond_ResetFreqUnitEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_InterCond_CompoundFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_InterCond_CompoundFreqUnitEn)));
}
inline InstrCompConvEn              _GET_A_InterCond_CompConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCompConvEn>  (_GET_ENUM(p, A_InterCond_CompConvEn)));
}
inline InstrMktConvMethodEn         _GET_A_InterCond_MktConvMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrMktConvMethodEn>  (_GET_ENUM(p, A_InterCond_MktConvMethodEn)));
}
inline InstrLookbackConvEn          _GET_A_InterCond_LookbackConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrLookbackConvEn>  (_GET_ENUM(p, A_InterCond_LookbackConvEn)));
}
inline InstrNatEn                   _GET_A_InterCond_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_InterCond_InstrNatEn)));
}
inline InstrNatEn                   _GET_S_InterCond_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_InterCond_InstrNatEn)));
}
inline InstrAverPeriodUnitEn        _GET_A_InterCond_AverPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrAverPeriodUnitEn>  (_GET_ENUM(p, A_InterCond_AverPeriodUnitEn)));
}

inline void                         SET_A_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p, InterCondIntCalcRuleEn enumValue)
{
    SET_ENUM(p, A_InterCond_IntCalcRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InterCond_IntCalcRuleEn(DBA_DYNFLD_STP p, InterCondIntCalcRuleEn enumValue)
{
    SET_ENUM(p, S_InterCond_IntCalcRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_NatEn(DBA_DYNFLD_STP p, InterCondNatEn enumValue)
{
    SET_ENUM(p, A_InterCond_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InterCond_NatEn(DBA_DYNFLD_STP p, InterCondNatEn enumValue)
{
    SET_ENUM(p, S_InterCond_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_ResetFreqUnitEn(DBA_DYNFLD_STP p, InterCondResetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_InterCond_ResetFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_CompoundFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_InterCond_CompoundFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_CompConvEn(DBA_DYNFLD_STP p, InstrCompConvEn enumValue)
{
    SET_ENUM(p, A_InterCond_CompConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_MktConvMethodEn(DBA_DYNFLD_STP p, InstrMktConvMethodEn enumValue)
{
    SET_ENUM(p, A_InterCond_MktConvMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_LookbackConvEn(DBA_DYNFLD_STP p, InstrLookbackConvEn enumValue)
{
    SET_ENUM(p, A_InterCond_LookbackConvEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_InterCond_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InterCond_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_InterCond_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_InterCond_AverPeriodUnitEn(DBA_DYNFLD_STP p, InstrAverPeriodUnitEn enumValue)
{
    SET_ENUM(p, A_InterCond_AverPeriodUnitEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BuyingPowerStatusEn          GET_A_BuyingPower_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BuyingPowerStatusEn>  (GET_ENUM(p, A_BuyingPower_StatusEn)));
}

inline BuyingPowerStatusEn          _GET_A_BuyingPower_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BuyingPowerStatusEn>  (_GET_ENUM(p, A_BuyingPower_StatusEn)));
}

inline void                         SET_A_BuyingPower_StatusEn(DBA_DYNFLD_STP p, BuyingPowerStatusEn enumValue)
{
    SET_ENUM(p, A_BuyingPower_StatusEn, static_cast<unsigned char>(enumValue));
}


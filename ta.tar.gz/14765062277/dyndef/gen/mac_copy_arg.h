/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CopyArgCopyLogicalEn         GET_A_CopyArg_CopyLogicalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CopyArgCopyLogicalEn>  (GET_ENUM(p, A_CopyArg_CopyLogicalEn)));
}

inline CopyArgCopyLogicalEn         _GET_A_CopyArg_CopyLogicalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CopyArgCopyLogicalEn>  (_GET_ENUM(p, A_CopyArg_CopyLogicalEn)));
}

inline void                         SET_A_CopyArg_CopyLogicalEn(DBA_DYNFLD_STP p, CopyArgCopyLogicalEn enumValue)
{
    SET_ENUM(p, A_CopyArg_CopyLogicalEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictSprocActionEn            GET_A_DictSproc_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictSprocActionEn>  (GET_ENUM(p, A_DictSproc_ActionEn)));
}
inline DictSprocAccessEn            GET_A_DictSproc_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictSprocAccessEn>  (GET_ENUM(p, A_DictSproc_AccessEn)));
}
inline XdEntityXdActionEn           GET_A_DictSproc_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_DictSproc_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_DictSproc_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictSproc_XdStatusEn)));
}

inline DictSprocActionEn            _GET_A_DictSproc_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictSprocActionEn>  (_GET_ENUM(p, A_DictSproc_ActionEn)));
}
inline DictSprocAccessEn            _GET_A_DictSproc_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictSprocAccessEn>  (_GET_ENUM(p, A_DictSproc_AccessEn)));
}
inline XdEntityXdActionEn           _GET_A_DictSproc_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_DictSproc_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_DictSproc_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictSproc_XdStatusEn)));
}

inline void                         SET_A_DictSproc_ActionEn(DBA_DYNFLD_STP p, DictSprocActionEn enumValue)
{
    SET_ENUM(p, A_DictSproc_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictSproc_AccessEn(DBA_DYNFLD_STP p, DictSprocAccessEn enumValue)
{
    SET_ENUM(p, A_DictSproc_AccessEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictSproc_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_DictSproc_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictSproc_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictSproc_XdStatusEn, static_cast<unsigned char>(enumValue));
}


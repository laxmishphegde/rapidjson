/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline AuthenticationAttributeKindEn GET_A_AuthenticationAttribute_KindEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationAttributeKindEn>  (GET_ENUM(p, A_AuthenticationAttribute_KindEn)));
}
inline AuthenticationMechanismNatEn GET_A_AuthenticationAttribute_AuthenticationMechanismNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (GET_ENUM(p, A_AuthenticationAttribute_AuthenticationMechanismNatEn)));
}

inline AuthenticationAttributeKindEn _GET_A_AuthenticationAttribute_KindEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationAttributeKindEn>  (_GET_ENUM(p, A_AuthenticationAttribute_KindEn)));
}
inline AuthenticationMechanismNatEn _GET_A_AuthenticationAttribute_AuthenticationMechanismNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (_GET_ENUM(p, A_AuthenticationAttribute_AuthenticationMechanismNatEn)));
}

inline void                         SET_A_AuthenticationAttribute_KindEn(DBA_DYNFLD_STP p, AuthenticationAttributeKindEn enumValue)
{
    SET_ENUM(p, A_AuthenticationAttribute_KindEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AuthenticationAttribute_AuthenticationMechanismNatEn(DBA_DYNFLD_STP p, AuthenticationMechanismNatEn enumValue)
{
    SET_ENUM(p, A_AuthenticationAttribute_AuthenticationMechanismNatEn, static_cast<unsigned char>(enumValue));
}


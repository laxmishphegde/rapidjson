/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CategoryNatEn                GET_A_Category_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CategoryNatEn>  (GET_ENUM(p, A_Category_NatEn)));
}
inline CategoryNatEn                GET_S_Category_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CategoryNatEn>  (GET_ENUM(p, S_Category_NatEn)));
}

inline CategoryNatEn                _GET_A_Category_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CategoryNatEn>  (_GET_ENUM(p, A_Category_NatEn)));
}
inline CategoryNatEn                _GET_S_Category_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CategoryNatEn>  (_GET_ENUM(p, S_Category_NatEn)));
}

inline void                         SET_A_Category_NatEn(DBA_DYNFLD_STP p, CategoryNatEn enumValue)
{
    SET_ENUM(p, A_Category_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Category_NatEn(DBA_DYNFLD_STP p, CategoryNatEn enumValue)
{
    SET_ENUM(p, S_Category_NatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ApplChannelChannelTypeEn     GET_A_ApplChannel_ChannelTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplChannelChannelTypeEn>  (GET_ENUM(p, A_ApplChannel_ChannelTypeEn)));
}

inline ApplChannelChannelTypeEn     _GET_A_ApplChannel_ChannelTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplChannelChannelTypeEn>  (_GET_ENUM(p, A_ApplChannel_ChannelTypeEn)));
}

inline void                         SET_A_ApplChannel_ChannelTypeEn(DBA_DYNFLD_STP p, ApplChannelChannelTypeEn enumValue)
{
    SET_ENUM(p, A_ApplChannel_ChannelTypeEn, static_cast<unsigned char>(enumValue));
}


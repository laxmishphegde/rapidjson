/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusEntityUserCompoRoleEn     GET_A_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusEntityUserCompoRoleEn>  (GET_ENUM(p, A_BusEntityUserCompo_RoleEn)));
}
inline BusEntityUserCompoRoleEn     GET_S_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusEntityUserCompoRoleEn>  (GET_ENUM(p, S_BusEntityUserCompo_RoleEn)));
}

inline BusEntityUserCompoRoleEn     _GET_A_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusEntityUserCompoRoleEn>  (_GET_ENUM(p, A_BusEntityUserCompo_RoleEn)));
}
inline BusEntityUserCompoRoleEn     _GET_S_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusEntityUserCompoRoleEn>  (_GET_ENUM(p, S_BusEntityUserCompo_RoleEn)));
}

inline void                         SET_A_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p, BusEntityUserCompoRoleEn enumValue)
{
    SET_ENUM(p, A_BusEntityUserCompo_RoleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_BusEntityUserCompo_RoleEn(DBA_DYNFLD_STP p, BusEntityUserCompoRoleEn enumValue)
{
    SET_ENUM(p, S_BusEntityUserCompo_RoleEn, static_cast<unsigned char>(enumValue));
}


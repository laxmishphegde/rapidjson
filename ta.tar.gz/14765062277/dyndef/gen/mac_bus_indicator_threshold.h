/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusIndicatorThresholdUsageNatEn GET_A_BusIndicatorThreshold_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusIndicatorThresholdUsageNatEn>  (GET_ENUM(p, A_BusIndicatorThreshold_UsageNatEn)));
}

inline BusIndicatorThresholdUsageNatEn _GET_A_BusIndicatorThreshold_UsageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusIndicatorThresholdUsageNatEn>  (_GET_ENUM(p, A_BusIndicatorThreshold_UsageNatEn)));
}

inline void                         SET_A_BusIndicatorThreshold_UsageNatEn(DBA_DYNFLD_STP p, BusIndicatorThresholdUsageNatEn enumValue)
{
    SET_ENUM(p, A_BusIndicatorThreshold_UsageNatEn, static_cast<unsigned char>(enumValue));
}


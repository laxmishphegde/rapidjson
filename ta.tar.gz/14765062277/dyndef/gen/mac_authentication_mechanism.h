/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline AuthenticationMechanismNatEn GET_A_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (GET_ENUM(p, A_AuthenticationMechanism_NatEn)));
}
inline AuthenticationMechanismNatEn GET_S_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (GET_ENUM(p, S_AuthenticationMechanism_NatEn)));
}
inline AuthenticationMechanismAlgorithmEn GET_A_AuthenticationMechanism_AlgorithmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismAlgorithmEn>  (GET_ENUM(p, A_AuthenticationMechanism_AlgorithmEn)));
}

inline AuthenticationMechanismNatEn _GET_A_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (_GET_ENUM(p, A_AuthenticationMechanism_NatEn)));
}
inline AuthenticationMechanismNatEn _GET_S_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismNatEn>  (_GET_ENUM(p, S_AuthenticationMechanism_NatEn)));
}
inline AuthenticationMechanismAlgorithmEn _GET_A_AuthenticationMechanism_AlgorithmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AuthenticationMechanismAlgorithmEn>  (_GET_ENUM(p, A_AuthenticationMechanism_AlgorithmEn)));
}

inline void                         SET_A_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p, AuthenticationMechanismNatEn enumValue)
{
    SET_ENUM(p, A_AuthenticationMechanism_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_AuthenticationMechanism_NatEn(DBA_DYNFLD_STP p, AuthenticationMechanismNatEn enumValue)
{
    SET_ENUM(p, S_AuthenticationMechanism_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AuthenticationMechanism_AlgorithmEn(DBA_DYNFLD_STP p, AuthenticationMechanismAlgorithmEn enumValue)
{
    SET_ENUM(p, A_AuthenticationMechanism_AlgorithmEn, static_cast<unsigned char>(enumValue));
}


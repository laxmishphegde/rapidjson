/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline EntityConfigExportModeEn     GET_A_EntityConfig_ExportModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigExportModeEn>  (GET_ENUM(p, A_EntityConfig_ExportModeEn)));
}
inline EntityConfigOutputModeEn     GET_A_EntityConfig_OutputModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigOutputModeEn>  (GET_ENUM(p, A_EntityConfig_OutputModeEn)));
}

inline EntityConfigExportModeEn     _GET_A_EntityConfig_ExportModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigExportModeEn>  (_GET_ENUM(p, A_EntityConfig_ExportModeEn)));
}
inline EntityConfigOutputModeEn     _GET_A_EntityConfig_OutputModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigOutputModeEn>  (_GET_ENUM(p, A_EntityConfig_OutputModeEn)));
}

inline void                         SET_A_EntityConfig_ExportModeEn(DBA_DYNFLD_STP p, EntityConfigExportModeEn enumValue)
{
    SET_ENUM(p, A_EntityConfig_ExportModeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_EntityConfig_OutputModeEn(DBA_DYNFLD_STP p, EntityConfigOutputModeEn enumValue)
{
    SET_ENUM(p, A_EntityConfig_OutputModeEn, static_cast<unsigned char>(enumValue));
}


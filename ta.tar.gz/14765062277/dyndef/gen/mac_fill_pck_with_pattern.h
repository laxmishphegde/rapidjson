/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageDefinitionNatEn       GET_A_FillPckWithPattern_PackageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (GET_ENUM(p, A_FillPckWithPattern_PackageNatEn)));
}

inline PackageDefinitionNatEn       _GET_A_FillPckWithPattern_PackageNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (_GET_ENUM(p, A_FillPckWithPattern_PackageNatEn)));
}

inline void                         SET_A_FillPckWithPattern_PackageNatEn(DBA_DYNFLD_STP p, PackageDefinitionNatEn enumValue)
{
    SET_ENUM(p, A_FillPckWithPattern_PackageNatEn, static_cast<unsigned char>(enumValue));
}


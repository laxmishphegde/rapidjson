/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline EntityConfigElementRuleEn    GET_A_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigElementRuleEn>  (GET_ENUM(p, A_EntityConfigElement_RuleEn)));
}
inline EntityConfigElementRuleEn    GET_S_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigElementRuleEn>  (GET_ENUM(p, S_EntityConfigElement_RuleEn)));
}

inline EntityConfigElementRuleEn    _GET_A_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigElementRuleEn>  (_GET_ENUM(p, A_EntityConfigElement_RuleEn)));
}
inline EntityConfigElementRuleEn    _GET_S_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<EntityConfigElementRuleEn>  (_GET_ENUM(p, S_EntityConfigElement_RuleEn)));
}

inline void                         SET_A_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p, EntityConfigElementRuleEn enumValue)
{
    SET_ENUM(p, A_EntityConfigElement_RuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_EntityConfigElement_RuleEn(DBA_DYNFLD_STP p, EntityConfigElementRuleEn enumValue)
{
    SET_ENUM(p, S_EntityConfigElement_RuleEn, static_cast<unsigned char>(enumValue));
}


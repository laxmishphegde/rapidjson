/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CrmDocumentDocumentCopyEn    GET_A_CrmDocument_DocumentCopyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CrmDocumentDocumentCopyEn>  (GET_ENUM(p, A_CrmDocument_DocumentCopyEn)));
}
inline CrmDocumentStatusEn          GET_A_CrmDocument_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CrmDocumentStatusEn>  (GET_ENUM(p, A_CrmDocument_StatusEn)));
}

inline CrmDocumentDocumentCopyEn    _GET_A_CrmDocument_DocumentCopyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CrmDocumentDocumentCopyEn>  (_GET_ENUM(p, A_CrmDocument_DocumentCopyEn)));
}
inline CrmDocumentStatusEn          _GET_A_CrmDocument_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CrmDocumentStatusEn>  (_GET_ENUM(p, A_CrmDocument_StatusEn)));
}

inline void                         SET_A_CrmDocument_DocumentCopyEn(DBA_DYNFLD_STP p, CrmDocumentDocumentCopyEn enumValue)
{
    SET_ENUM(p, A_CrmDocument_DocumentCopyEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CrmDocument_StatusEn(DBA_DYNFLD_STP p, CrmDocumentStatusEn enumValue)
{
    SET_ENUM(p, A_CrmDocument_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ChangeSetDiscardReasonEn     GET_A_ChangeSet_DiscardReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ChangeSetDiscardReasonEn>  (GET_ENUM(p, A_ChangeSet_DiscardReasonEn)));
}

inline ChangeSetDiscardReasonEn     _GET_A_ChangeSet_DiscardReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ChangeSetDiscardReasonEn>  (_GET_ENUM(p, A_ChangeSet_DiscardReasonEn)));
}

inline void                         SET_A_ChangeSet_DiscardReasonEn(DBA_DYNFLD_STP p, ChangeSetDiscardReasonEn enumValue)
{
    SET_ENUM(p, A_ChangeSet_DiscardReasonEn, static_cast<unsigned char>(enumValue));
}


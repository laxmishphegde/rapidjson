/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DocIndexParamCycleEn         GET_A_DocIndexParam_CycleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocIndexParamCycleEn>  (GET_ENUM(p, A_DocIndexParam_CycleEn)));
}

inline DocIndexParamCycleEn         _GET_A_DocIndexParam_CycleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DocIndexParamCycleEn>  (_GET_ENUM(p, A_DocIndexParam_CycleEn)));
}

inline void                         SET_A_DocIndexParam_CycleEn(DBA_DYNFLD_STP p, DocIndexParamCycleEn enumValue)
{
    SET_ENUM(p, A_DocIndexParam_CycleEn, static_cast<unsigned char>(enumValue));
}


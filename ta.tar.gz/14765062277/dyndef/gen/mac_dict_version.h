/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdEntityXdStatusEn           GET_A_DictVersion_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictVersion_XdStatusEn)));
}

inline XdEntityXdStatusEn           _GET_A_DictVersion_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictVersion_XdStatusEn)));
}

inline void                         SET_A_DictVersion_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictVersion_XdStatusEn, static_cast<unsigned char>(enumValue));
}


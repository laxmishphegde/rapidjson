/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ListNatEn                    GET_A_List_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListNatEn>  (GET_ENUM(p, A_List_NatEn)));
}
inline ListNatEn                    GET_S_List_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListNatEn>  (GET_ENUM(p, S_List_NatEn)));
}
inline ListSubNatEn                 GET_A_List_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListSubNatEn>  (GET_ENUM(p, A_List_SubNatEn)));
}

inline ListNatEn                    _GET_A_List_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListNatEn>  (_GET_ENUM(p, A_List_NatEn)));
}
inline ListNatEn                    _GET_S_List_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListNatEn>  (_GET_ENUM(p, S_List_NatEn)));
}
inline ListSubNatEn                 _GET_A_List_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListSubNatEn>  (_GET_ENUM(p, A_List_SubNatEn)));
}

inline void                         SET_A_List_NatEn(DBA_DYNFLD_STP p, ListNatEn enumValue)
{
    SET_ENUM(p, A_List_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_List_NatEn(DBA_DYNFLD_STP p, ListNatEn enumValue)
{
    SET_ENUM(p, S_List_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_List_SubNatEn(DBA_DYNFLD_STP p, ListSubNatEn enumValue)
{
    SET_ENUM(p, A_List_SubNatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdAttribRefDeleteRuleEn      GET_A_DictEntityConstraints_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (GET_ENUM(p, A_DictEntityConstraints_RefDeleteRuleEn)));
}
inline XdAttribRefCheckRuleEn       GET_A_DictEntityConstraints_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (GET_ENUM(p, A_DictEntityConstraints_RefCheckRuleEn)));
}
inline DictEntityConstraintsAggregationEn GET_A_DictEntityConstraints_AggregationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityConstraintsAggregationEn>  (GET_ENUM(p, A_DictEntityConstraints_AggregationEn)));
}
inline DictEntityConstraintsMultiplicityEn GET_A_DictEntityConstraints_MultiplicityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityConstraintsMultiplicityEn>  (GET_ENUM(p, A_DictEntityConstraints_MultiplicityEn)));
}
inline XdEntityMultiEntityCategoryEn GET_A_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (GET_ENUM(p, A_DictEntityConstraints_MultiEntityCategoryEn)));
}
inline XdEntityMultiEntityCategoryEn GET_S_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (GET_ENUM(p, S_DictEntityConstraints_MultiEntityCategoryEn)));
}

inline XdAttribRefDeleteRuleEn      _GET_A_DictEntityConstraints_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (_GET_ENUM(p, A_DictEntityConstraints_RefDeleteRuleEn)));
}
inline XdAttribRefCheckRuleEn       _GET_A_DictEntityConstraints_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (_GET_ENUM(p, A_DictEntityConstraints_RefCheckRuleEn)));
}
inline DictEntityConstraintsAggregationEn _GET_A_DictEntityConstraints_AggregationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityConstraintsAggregationEn>  (_GET_ENUM(p, A_DictEntityConstraints_AggregationEn)));
}
inline DictEntityConstraintsMultiplicityEn _GET_A_DictEntityConstraints_MultiplicityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityConstraintsMultiplicityEn>  (_GET_ENUM(p, A_DictEntityConstraints_MultiplicityEn)));
}
inline XdEntityMultiEntityCategoryEn _GET_A_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (_GET_ENUM(p, A_DictEntityConstraints_MultiEntityCategoryEn)));
}
inline XdEntityMultiEntityCategoryEn _GET_S_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (_GET_ENUM(p, S_DictEntityConstraints_MultiEntityCategoryEn)));
}

inline void                         SET_A_DictEntityConstraints_RefDeleteRuleEn(DBA_DYNFLD_STP p, XdAttribRefDeleteRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntityConstraints_RefDeleteRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntityConstraints_RefCheckRuleEn(DBA_DYNFLD_STP p, XdAttribRefCheckRuleEn enumValue)
{
    SET_ENUM(p, A_DictEntityConstraints_RefCheckRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntityConstraints_AggregationEn(DBA_DYNFLD_STP p, DictEntityConstraintsAggregationEn enumValue)
{
    SET_ENUM(p, A_DictEntityConstraints_AggregationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntityConstraints_MultiplicityEn(DBA_DYNFLD_STP p, DictEntityConstraintsMultiplicityEn enumValue)
{
    SET_ENUM(p, A_DictEntityConstraints_MultiplicityEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p, XdEntityMultiEntityCategoryEn enumValue)
{
    SET_ENUM(p, A_DictEntityConstraints_MultiEntityCategoryEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_DictEntityConstraints_MultiEntityCategoryEn(DBA_DYNFLD_STP p, XdEntityMultiEntityCategoryEn enumValue)
{
    SET_ENUM(p, S_DictEntityConstraints_MultiEntityCategoryEn, static_cast<unsigned char>(enumValue));
}


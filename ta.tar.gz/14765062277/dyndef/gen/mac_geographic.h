/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline GeoGeographicHierEn          GET_A_Geo_GeographicHierEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<GeoGeographicHierEn>  (GET_ENUM(p, A_Geo_GeographicHierEn)));
}

inline GeoGeographicHierEn          _GET_A_Geo_GeographicHierEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<GeoGeographicHierEn>  (_GET_ENUM(p, A_Geo_GeographicHierEn)));
}

inline void                         SET_A_Geo_GeographicHierEn(DBA_DYNFLD_STP p, GeoGeographicHierEn enumValue)
{
    SET_ENUM(p, A_Geo_GeographicHierEn, static_cast<unsigned char>(enumValue));
}


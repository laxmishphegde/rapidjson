/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DdlgenObjectDdlObjEn         GET_A_DdlgenObject_DdlObjEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenObjectDdlObjEn>  (GET_ENUM(p, A_DdlgenObject_DdlObjEn)));
}

inline DdlgenObjectDdlObjEn         _GET_A_DdlgenObject_DdlObjEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DdlgenObjectDdlObjEn>  (_GET_ENUM(p, A_DdlgenObject_DdlObjEn)));
}

inline void                         SET_A_DdlgenObject_DdlObjEn(DBA_DYNFLD_STP p, DdlgenObjectDdlObjEn enumValue)
{
    SET_ENUM(p, A_DdlgenObject_DdlObjEn, static_cast<unsigned char>(enumValue));
}


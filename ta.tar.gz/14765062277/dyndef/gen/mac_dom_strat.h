/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfNatEn                     GET_A_DomStrat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (GET_ENUM(p, A_DomStrat_NatEn)));
}

inline PtfNatEn                     _GET_A_DomStrat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (_GET_ENUM(p, A_DomStrat_NatEn)));
}

inline void                         SET_A_DomStrat_NatEn(DBA_DYNFLD_STP p, PtfNatEn enumValue)
{
    SET_ENUM(p, A_DomStrat_NatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ApplParamNatEn               GET_A_ApplParam_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamNatEn>  (GET_ENUM(p, A_ApplParam_NatEn)));
}
inline ApplParamNatEn               GET_S_ApplParam_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamNatEn>  (GET_ENUM(p, S_ApplParam_NatEn)));
}
inline ApplParamSpecializationEn    GET_A_ApplParam_SpecializationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamSpecializationEn>  (GET_ENUM(p, A_ApplParam_SpecializationEn)));
}

inline ApplParamNatEn               _GET_A_ApplParam_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamNatEn>  (_GET_ENUM(p, A_ApplParam_NatEn)));
}
inline ApplParamNatEn               _GET_S_ApplParam_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamNatEn>  (_GET_ENUM(p, S_ApplParam_NatEn)));
}
inline ApplParamSpecializationEn    _GET_A_ApplParam_SpecializationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ApplParamSpecializationEn>  (_GET_ENUM(p, A_ApplParam_SpecializationEn)));
}

inline void                         SET_A_ApplParam_NatEn(DBA_DYNFLD_STP p, ApplParamNatEn enumValue)
{
    SET_ENUM(p, A_ApplParam_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ApplParam_NatEn(DBA_DYNFLD_STP p, ApplParamNatEn enumValue)
{
    SET_ENUM(p, S_ApplParam_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ApplParam_SpecializationEn(DBA_DYNFLD_STP p, ApplParamSpecializationEn enumValue)
{
    SET_ENUM(p, A_ApplParam_SpecializationEn, static_cast<unsigned char>(enumValue));
}


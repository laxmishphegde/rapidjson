/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ExchEvtNatEn                 GET_A_ExchEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtNatEn>  (GET_ENUM(p, A_ExchEvt_NatEn)));
}
inline ExchEvtNatEn                 GET_S_ExchEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtNatEn>  (GET_ENUM(p, S_ExchEvt_NatEn)));
}
inline ExchEvtEuroConvRuleEn        GET_A_ExchEvt_EuroConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtEuroConvRuleEn>  (GET_ENUM(p, A_ExchEvt_EuroConvRuleEn)));
}
inline ExchEvtRoundRuleEn           GET_A_ExchEvt_RoundRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtRoundRuleEn>  (GET_ENUM(p, A_ExchEvt_RoundRuleEn)));
}
inline ExchEvtOddLotCompEn          GET_A_ExchEvt_OddLotCompEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtOddLotCompEn>  (GET_ENUM(p, A_ExchEvt_OddLotCompEn)));
}
inline ExchEvtRoundLevelEn          GET_A_ExchEvt_RoundLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtRoundLevelEn>  (GET_ENUM(p, A_ExchEvt_RoundLevelEn)));
}
inline InstrNatEn                   GET_A_ExchEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_ExchEvt_InstrNatEn)));
}

inline ExchEvtNatEn                 _GET_A_ExchEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtNatEn>  (_GET_ENUM(p, A_ExchEvt_NatEn)));
}
inline ExchEvtNatEn                 _GET_S_ExchEvt_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtNatEn>  (_GET_ENUM(p, S_ExchEvt_NatEn)));
}
inline ExchEvtEuroConvRuleEn        _GET_A_ExchEvt_EuroConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtEuroConvRuleEn>  (_GET_ENUM(p, A_ExchEvt_EuroConvRuleEn)));
}
inline ExchEvtRoundRuleEn           _GET_A_ExchEvt_RoundRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtRoundRuleEn>  (_GET_ENUM(p, A_ExchEvt_RoundRuleEn)));
}
inline ExchEvtOddLotCompEn          _GET_A_ExchEvt_OddLotCompEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtOddLotCompEn>  (_GET_ENUM(p, A_ExchEvt_OddLotCompEn)));
}
inline ExchEvtRoundLevelEn          _GET_A_ExchEvt_RoundLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ExchEvtRoundLevelEn>  (_GET_ENUM(p, A_ExchEvt_RoundLevelEn)));
}
inline InstrNatEn                   _GET_A_ExchEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_ExchEvt_InstrNatEn)));
}

inline void                         SET_A_ExchEvt_NatEn(DBA_DYNFLD_STP p, ExchEvtNatEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ExchEvt_NatEn(DBA_DYNFLD_STP p, ExchEvtNatEn enumValue)
{
    SET_ENUM(p, S_ExchEvt_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExchEvt_EuroConvRuleEn(DBA_DYNFLD_STP p, ExchEvtEuroConvRuleEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_EuroConvRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExchEvt_RoundRuleEn(DBA_DYNFLD_STP p, ExchEvtRoundRuleEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_RoundRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExchEvt_OddLotCompEn(DBA_DYNFLD_STP p, ExchEvtOddLotCompEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_OddLotCompEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExchEvt_RoundLevelEn(DBA_DYNFLD_STP p, ExchEvtRoundLevelEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_RoundLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ExchEvt_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_ExchEvt_InstrNatEn, static_cast<unsigned char>(enumValue));
}


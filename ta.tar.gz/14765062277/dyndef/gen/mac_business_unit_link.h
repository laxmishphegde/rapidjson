/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BusinessUnitLinkNatEn        GET_A_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitLinkNatEn>  (GET_ENUM(p, A_BusinessUnitLink_NatEn)));
}
inline BusinessUnitLinkNatEn        GET_S_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitLinkNatEn>  (GET_ENUM(p, S_BusinessUnitLink_NatEn)));
}

inline BusinessUnitLinkNatEn        _GET_A_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitLinkNatEn>  (_GET_ENUM(p, A_BusinessUnitLink_NatEn)));
}
inline BusinessUnitLinkNatEn        _GET_S_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BusinessUnitLinkNatEn>  (_GET_ENUM(p, S_BusinessUnitLink_NatEn)));
}

inline void                         SET_A_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p, BusinessUnitLinkNatEn enumValue)
{
    SET_ENUM(p, A_BusinessUnitLink_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_BusinessUnitLink_NatEn(DBA_DYNFLD_STP p, BusinessUnitLinkNatEn enumValue)
{
    SET_ENUM(p, S_BusinessUnitLink_NatEn, static_cast<unsigned char>(enumValue));
}


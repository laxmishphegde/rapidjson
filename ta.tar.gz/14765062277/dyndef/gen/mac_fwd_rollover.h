/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline FwdRolloverRolloverEligibleEn GET_A_FwdRollover_RolloverEligibleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FwdRolloverRolloverEligibleEn>  (GET_ENUM(p, A_FwdRollover_RolloverEligibleEn)));
}
inline FwdRolloverNearlegTypeEn     GET_A_FwdRollover_NearlegTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FwdRolloverNearlegTypeEn>  (GET_ENUM(p, A_FwdRollover_NearlegTypeEn)));
}

inline FwdRolloverRolloverEligibleEn _GET_A_FwdRollover_RolloverEligibleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FwdRolloverRolloverEligibleEn>  (_GET_ENUM(p, A_FwdRollover_RolloverEligibleEn)));
}
inline FwdRolloverNearlegTypeEn     _GET_A_FwdRollover_NearlegTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FwdRolloverNearlegTypeEn>  (_GET_ENUM(p, A_FwdRollover_NearlegTypeEn)));
}

inline void                         SET_A_FwdRollover_RolloverEligibleEn(DBA_DYNFLD_STP p, FwdRolloverRolloverEligibleEn enumValue)
{
    SET_ENUM(p, A_FwdRollover_RolloverEligibleEn, enumValue);
}
inline void                         SET_A_FwdRollover_NearlegTypeEn(DBA_DYNFLD_STP p, FwdRolloverNearlegTypeEn enumValue)
{
    SET_ENUM(p, A_FwdRollover_NearlegTypeEn, enumValue);
}


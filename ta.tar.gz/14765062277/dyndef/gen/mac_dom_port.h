/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfFusionDateRuleEn          GET_A_DomPort_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (GET_ENUM(p, A_DomPort_FusionDateRuleEn)));
}
inline PtfNatEn                     GET_A_DomPort_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (GET_ENUM(p, A_DomPort_NatEn)));
}

inline PtfFusionDateRuleEn          _GET_A_DomPort_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (_GET_ENUM(p, A_DomPort_FusionDateRuleEn)));
}
inline PtfNatEn                     _GET_A_DomPort_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (_GET_ENUM(p, A_DomPort_NatEn)));
}

inline void                         SET_A_DomPort_FusionDateRuleEn(DBA_DYNFLD_STP p, PtfFusionDateRuleEn enumValue)
{
    SET_ENUM(p, A_DomPort_FusionDateRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_DomPort_NatEn(DBA_DYNFLD_STP p, PtfNatEn enumValue)
{
    SET_ENUM(p, A_DomPort_NatEn, static_cast<unsigned char>(enumValue));
}


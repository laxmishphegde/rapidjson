/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline IndicatorAttribStatusEn      GET_A_IndicatorAttrib_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IndicatorAttribStatusEn>  (GET_ENUM(p, A_IndicatorAttrib_StatusEn)));
}

inline IndicatorAttribStatusEn      _GET_A_IndicatorAttrib_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<IndicatorAttribStatusEn>  (_GET_ENUM(p, A_IndicatorAttrib_StatusEn)));
}

inline void                         SET_A_IndicatorAttrib_StatusEn(DBA_DYNFLD_STP p, IndicatorAttribStatusEn enumValue)
{
    SET_ENUM(p, A_IndicatorAttrib_StatusEn, static_cast<unsigned char>(enumValue));
}


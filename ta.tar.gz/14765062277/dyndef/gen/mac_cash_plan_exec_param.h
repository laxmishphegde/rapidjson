/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrRateFreqUnitEn          GET_A_CashPlanExecParam_FreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (GET_ENUM(p, A_CashPlanExecParam_FreqUnitEn)));
}
inline InstrEomEn                   GET_A_CashPlanExecParam_EndOfMonthConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (GET_ENUM(p, A_CashPlanExecParam_EndOfMonthConvEn)));
}

inline InstrRateFreqUnitEn          _GET_A_CashPlanExecParam_FreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (_GET_ENUM(p, A_CashPlanExecParam_FreqUnitEn)));
}
inline InstrEomEn                   _GET_A_CashPlanExecParam_EndOfMonthConvEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrEomEn>  (_GET_ENUM(p, A_CashPlanExecParam_EndOfMonthConvEn)));
}

inline void                         SET_A_CashPlanExecParam_FreqUnitEn(DBA_DYNFLD_STP p, InstrRateFreqUnitEn enumValue)
{
    SET_ENUM(p, A_CashPlanExecParam_FreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CashPlanExecParam_EndOfMonthConvEn(DBA_DYNFLD_STP p, InstrEomEn enumValue)
{
    SET_ENUM(p, A_CashPlanExecParam_EndOfMonthConvEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline CorpActionDetailDispositionFractionEn GET_A_CorpActionDetail_DispositionFractionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CorpActionDetailDispositionFractionEn>  (GET_ENUM(p, A_CorpActionDetail_DispositionFractionEn)));
}
inline CorpActionDetailIssueTypeEn  GET_A_CorpActionDetail_IssueTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CorpActionDetailIssueTypeEn>  (GET_ENUM(p, A_CorpActionDetail_IssueTypeEn)));
}
inline InstrRateFreqUnitEn          GET_A_CorpActionDetail_MinHoldingPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (GET_ENUM(p, A_CorpActionDetail_MinHoldingPeriodUnitEn)));
}

inline CorpActionDetailDispositionFractionEn _GET_A_CorpActionDetail_DispositionFractionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CorpActionDetailDispositionFractionEn>  (_GET_ENUM(p, A_CorpActionDetail_DispositionFractionEn)));
}
inline CorpActionDetailIssueTypeEn  _GET_A_CorpActionDetail_IssueTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<CorpActionDetailIssueTypeEn>  (_GET_ENUM(p, A_CorpActionDetail_IssueTypeEn)));
}
inline InstrRateFreqUnitEn          _GET_A_CorpActionDetail_MinHoldingPeriodUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRateFreqUnitEn>  (_GET_ENUM(p, A_CorpActionDetail_MinHoldingPeriodUnitEn)));
}

inline void                         SET_A_CorpActionDetail_DispositionFractionEn(DBA_DYNFLD_STP p, CorpActionDetailDispositionFractionEn enumValue)
{
    SET_ENUM(p, A_CorpActionDetail_DispositionFractionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CorpActionDetail_IssueTypeEn(DBA_DYNFLD_STP p, CorpActionDetailIssueTypeEn enumValue)
{
    SET_ENUM(p, A_CorpActionDetail_IssueTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_CorpActionDetail_MinHoldingPeriodUnitEn(DBA_DYNFLD_STP p, InstrRateFreqUnitEn enumValue)
{
    SET_ENUM(p, A_CorpActionDetail_MinHoldingPeriodUnitEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrCurrOverrideOverrideScopeEn GET_A_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCurrOverrideOverrideScopeEn>  (GET_ENUM(p, A_InstrCurrOverride_OverrideScopeEn)));
}
inline InstrCurrOverrideOverrideScopeEn GET_S_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCurrOverrideOverrideScopeEn>  (GET_ENUM(p, S_InstrCurrOverride_OverrideScopeEn)));
}

inline InstrCurrOverrideOverrideScopeEn _GET_A_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCurrOverrideOverrideScopeEn>  (_GET_ENUM(p, A_InstrCurrOverride_OverrideScopeEn)));
}
inline InstrCurrOverrideOverrideScopeEn _GET_S_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrCurrOverrideOverrideScopeEn>  (_GET_ENUM(p, S_InstrCurrOverride_OverrideScopeEn)));
}

inline void                         SET_A_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p, InstrCurrOverrideOverrideScopeEn enumValue)
{
    SET_ENUM(p, A_InstrCurrOverride_OverrideScopeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_InstrCurrOverride_OverrideScopeEn(DBA_DYNFLD_STP p, InstrCurrOverrideOverrideScopeEn enumValue)
{
    SET_ENUM(p, S_InstrCurrOverride_OverrideScopeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline BiObjectiveEltRecomNatEn     GET_A_BiObjectiveElt_RecomNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiObjectiveEltRecomNatEn>  (GET_ENUM(p, A_BiObjectiveElt_RecomNatEn)));
}
inline BiObjectiveEltFlagEn         GET_A_BiObjectiveElt_FlagEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiObjectiveEltFlagEn>  (GET_ENUM(p, A_BiObjectiveElt_FlagEn)));
}

inline BiObjectiveEltRecomNatEn     _GET_A_BiObjectiveElt_RecomNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiObjectiveEltRecomNatEn>  (_GET_ENUM(p, A_BiObjectiveElt_RecomNatEn)));
}
inline BiObjectiveEltFlagEn         _GET_A_BiObjectiveElt_FlagEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<BiObjectiveEltFlagEn>  (_GET_ENUM(p, A_BiObjectiveElt_FlagEn)));
}

inline void                         SET_A_BiObjectiveElt_RecomNatEn(DBA_DYNFLD_STP p, BiObjectiveEltRecomNatEn enumValue)
{
    SET_ENUM(p, A_BiObjectiveElt_RecomNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_BiObjectiveElt_FlagEn(DBA_DYNFLD_STP p, BiObjectiveEltFlagEn enumValue)
{
    SET_ENUM(p, A_BiObjectiveElt_FlagEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictPermValPermValNatEn      GET_A_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (GET_ENUM(p, A_DictPermVal_PermValNatEn)));
}
inline DictPermValPermValNatEn      GET_S_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (GET_ENUM(p, S_DictPermVal_PermValNatEn)));
}
inline DictPermValPermValRuleEn     GET_A_DictPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (GET_ENUM(p, A_DictPermVal_PermValRuleEn)));
}
inline XdEntityXdStatusEn           GET_A_DictPermVal_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_DictPermVal_XdStatusEn)));
}
inline DictPermValDbRuleEn          GET_A_DictPermVal_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValDbRuleEn>  (GET_ENUM(p, A_DictPermVal_DbRuleEn)));
}

inline DictPermValPermValNatEn      _GET_A_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (_GET_ENUM(p, A_DictPermVal_PermValNatEn)));
}
inline DictPermValPermValNatEn      _GET_S_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (_GET_ENUM(p, S_DictPermVal_PermValNatEn)));
}
inline DictPermValPermValRuleEn     _GET_A_DictPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (_GET_ENUM(p, A_DictPermVal_PermValRuleEn)));
}
inline XdEntityXdStatusEn           _GET_A_DictPermVal_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_DictPermVal_XdStatusEn)));
}
inline DictPermValDbRuleEn          _GET_A_DictPermVal_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValDbRuleEn>  (_GET_ENUM(p, A_DictPermVal_DbRuleEn)));
}

inline void                         SET_A_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p, DictPermValPermValNatEn enumValue)
{
    SET_ENUM(p, A_DictPermVal_PermValNatEn, enumValue);
}
inline void                         SET_S_DictPermVal_PermValNatEn(DBA_DYNFLD_STP p, DictPermValPermValNatEn enumValue)
{
    SET_ENUM(p, S_DictPermVal_PermValNatEn, enumValue);
}
inline void                         SET_A_DictPermVal_PermValRuleEn(DBA_DYNFLD_STP p, DictPermValPermValRuleEn enumValue)
{
    SET_ENUM(p, A_DictPermVal_PermValRuleEn, enumValue);
}
inline void                         SET_A_DictPermVal_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_DictPermVal_XdStatusEn, enumValue);
}
inline void                         SET_A_DictPermVal_DbRuleEn(DBA_DYNFLD_STP p, DictPermValDbRuleEn enumValue)
{
    SET_ENUM(p, A_DictPermVal_DbRuleEn, enumValue);
}


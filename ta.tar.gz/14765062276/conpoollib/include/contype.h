/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionType_H_
#define  AAAConnectionType_H_

#include <string>

class DbiConnection;

typedef enum AAAConnectionTypeEnum {
        NullServer=-1,
        SqlServer,
        FinServer,
        InternalProc,
        DispatchServer,  /* PMSTA-24563 - LJE - 160830 */

        LastServerType 
} DBA_SERVER_TYPE_ENUM;

typedef enum
{
    Asynchronous,
    Synchronous,
    ReadOnly,
    WriteTable,
    WriteTempTable
} DBA_CONNECT_TYPE_ENUM;

typedef enum
{
    NullConn = -1,
    UnmountedConn,
    UsedConn,
    FreeConn,
    UnmountedButUsedConn
} DBA_CONNECT_STATE_ENUM;

typedef AAAConnectionTypeEnum AAAConnectionType;

/*
*  Structure used to store a work to be done after the connection is closed
*/
struct STRUCT_DBA_WORK_ON_CLOSE_CONNECTION
{
    void(*onCommit)   (void *, DbiConnection &);    /* Function to call for a successful commit     */
    void(*onRollback) (void *, DbiConnection &);    /* Function to call for a successful rollback   */
    void(*free)       (void *);                     /* Function to call to free memory              */
    void *pData;                                    /* Pointer to the data                          */
};

typedef struct STRUCT_DBA_WORK_ON_CLOSE_CONNECTION   DBA_WORK_ON_CLOSE_CONNECTION_ST;
typedef struct STRUCT_DBA_WORK_ON_CLOSE_CONNECTION * DBA_WORK_ON_CLOSE_CONNECTION_STP;

#endif

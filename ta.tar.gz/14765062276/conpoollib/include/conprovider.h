/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionProvider_H_
#define  AAAConnectionProvider_H_

#include <map>
#include <vector>
#include <ostream>

#include "conpool.h"
#include "conpoolconf.h"
#include "conallocator.h"
#include "conpoolstatus.h"

class  AAAConnectionPoolObserver;
class  AAAConnectionProvider :public ThreadArg
{
public:
	static  AAAConnectionProvider& getConnectionProviderInstance();
	static void close();
	~AAAConnectionProvider(void);
	void configure(const std::vector< AAAConnectionPoolConfiguration>& config);
	void configure(const  AAAConnectionPoolConfiguration& config);
    DbiConnection* getConnection(const int& connecitonId);
    DbiConnection* getConnection(const  AAAConnectionDescription& desc);
    const AAAConnectionPoolStatus getPoolStatus(const  AAAConnectionDescription& desc)  const;
	std::vector< AAAConnectionPoolStatus*>* getPoolStatus() const;
	void registerAllocator(const  AAAConnectionType& type, const  DBA_RDBMS_ENUM& model, AAACONNECTION_ALLOCATOR_FPTR allocatorPtr);
	bool hasPool(const  AAAConnectionDescription& desc);
	void setObserver(AAAConnectionPoolObserver * observer);
	bool isCredentialIdentical(const AAAConnectionDescription& desc, const PasswordEncrypted& password);
	bool validateDatabaseCredential(const std::string& userName, const PasswordEncrypted& password);

	void unconfigure(const AAAConnectionDescription& config);
    void unconfigure(const  AAAConnectionType& type);
	void unconfigureAll();
	void release(DbiConnection* connection);
    int addPoolReference(const  AAAConnectionDescription& desc);
    int decPoolReference(const  AAAConnectionDescription& desc);
    void ApplyAllPolicies();
    void startCleanupConnectionThread();
    void stopCleanupConnectionThread();

    DbiConnection* find(const AAAConnectionType* typeScopeFilter, const char* user , const char* serverNameScopeFilter, bool(*searchFunc)(DbiConnection&, void*), 	void* searchArg);
	void updatePassword(const std::string& user, const PasswordEncrypted& password);    /* PMSTA-29708 - DLA - 180507 */
    void updatePassword(const AAAConnectionDescription& desc, const PasswordEncrypted& password);   /* PMSTA-29708 - DLA - 180507 */
    PasswordEncrypted getEncryptedPassword(const std::string& user);    /* PMSTA-29708 - DLA - 180507 */
	AAAConnectionProvider(AAAConnectionProvider const&) = delete;
	void operator=(AAAConnectionProvider const&) = delete;

    friend std::ostream& operator<<(std::ostream& os, const AAAConnectionProvider& obj);
    std::vector<AAAConnectionStatus> getAllConnectionsStatus();
    std::vector < std::pair<AAAConnectionPoolStatus, std::vector<AAAConnectionStatus>>> getAllConnectionsStatusByPool(const AAAConnectionStatusParam&);

private:
	AAAConnectionProvider(void);
    void setObserver();
	std::map< AAAConnectionDescription, AAAConnectionPool*> pools;
	std::map< AAAConnectionAllocatorKey, AAAConnectionAllocator> allocatorMap;
	AAAConnectionPool* lastPool;
	AAAConnectionPoolObserver* m_observer;
	Lock lock;
 };

#endif

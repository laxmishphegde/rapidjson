/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionPoolEvent_H_
#define  AAAConnectionPoolEvent_H_
#include <conpoolstatus.h>
#include <conpooleventtype.h>
#include <iostream>
class  AAAConnectionPoolEvent {
public:
	/**
	* Semantic constructor
	" @param eventType the event type
	* @param descriptor the connection description for which the event is related to
	* @param connectionId the connection identifier for which the event is related to
	* @param poolStatus the status of the pool where the connection is managed
	* @param successfull boolean indicating if the event processing was performed successfully or not
	* @param duration the duration of the event processing (0 means no significant)
	*/
	AAAConnectionPoolEvent(const AAAConnectionPoolEventType& eventType,
						   const AAAConnectionDescription& descriptor,
						   const int& connectionId, 
						   const AAAConnectionPoolStatus& poolStatus,
						   bool  successfull, 
						   const unsigned long &duration = 0);
	/**
	* Copy constructor.
	*@param toCopy the object to copy
	*/
	AAAConnectionPoolEvent(const  AAAConnectionPoolEvent& toCopy);

    AAAConnectionPoolEvent & operator=(const AAAConnectionPoolEvent &) = delete;    /* PMSTA-24076 - 180716 - PMO */

	/**
	* @return the connection description for which the event is related to
	*/
	const  AAAConnectionDescription& getDescriptor() const;
	/**
	* @return the event type
	*/
	const  AAAConnectionPoolEventType& getEventType() const;
	/**
	* @return the connection identifier for which the event is related to
	*/
	const int& getConnectionId() const;
	/**
	* @return the status of the pool where the connection is managed
	*/
	const  AAAConnectionPoolStatus& getPoolStatus() const;
	/**
	* @return the duration of the event processing (0 means no significant)
	*/
	const unsigned long& getDuration() const;
	/**
	* @return boolean indicating if the event processing was performed successfully or not
	*/
	const bool& isSuccessfull() const;
	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolEvent& obj);


private:
	/**
	*the connection identifier for which the event is related to
	*/
	AAAConnectionDescription descriptor;
	/**
	* the event type
	*/
	AAAConnectionPoolEventType eventType;
	/**
	*the connection identifier for which the event is related to
	*/
	int connectionId;
	/**
	*the status of the pool where the connection is managed
	*/
	AAAConnectionPoolStatus poolStatus;
	/**
	*the duration of the event processing (0 means no significant)
	*/
	unsigned long duration;
	/**
	*boolean indicating if the event processing was performed successfully or not
	*/
	bool successfull;


};
#endif

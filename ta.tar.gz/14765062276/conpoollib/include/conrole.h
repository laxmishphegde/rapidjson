/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionRole_H_
#define  AAAConnectionRole_H_

typedef enum
{
    ROLE_INIT,
    ROLE_ADMIN,         /* Connection open with user having administration rigths on data, used by financial server */
    ROLE_USER,          /* Connection open with standard user */
    ROLE_SECURITY,      /* Connection open with security user (aaa_login_manager) */
    ROLE_DBSO,          /* Connection open with security officer (sso_role in sybase) */
    ROLE_PROXY,         /* PMSTA-34344 - LJE - 201218 - Role for proxy user (GUI without Database) */

    LAST_ROLE
} AAAConnectionRole;
#endif

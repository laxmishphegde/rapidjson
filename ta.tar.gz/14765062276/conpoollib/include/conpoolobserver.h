/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef AAAConnectionPoolObserver_H__
#define AAAConnectionPoolObserver_H__
#include <fstream>
#include <conpoolevent.h>

enum class ObserverDetailEn
{
    compact = 0,
    medium,
    high

};

inline ObserverDetailEn ObserverDetailEnFromIntValue(const int value)
{ 
    if (value >= (int)ObserverDetailEn::compact && value <= (int)ObserverDetailEn::high)
    {
        return static_cast<ObserverDetailEn>(value);
    }
    else
    {
        return ObserverDetailEn::compact;
    }
};

class  AAAObserver
{
public:
    virtual void processEvent(const  AAAConnectionPoolEvent& event) = 0;
    AAAObserver(const std::string& filename, const ObserverDetailEn& detail);
    virtual ~AAAObserver()                                                              /* PMSTA-30941 - 200418 - PMO */
    {
        if (outfile)
        {
            outfile.close();
        }
    }

    AAAObserver            (const AAAObserver &) = delete;                              /* PMSTA-30941 - 200418 - PMO */
    AAAObserver & operator=(const AAAObserver &) = delete;                              /* PMSTA-30941 - 200418 - PMO */

    ObserverDetailEn    detail;
    std::ofstream       outfile;
};


class  AAAConnectionPoolObserver : public AAAObserver
{
public:
    AAAConnectionPoolObserver(const std::string& filename, const ObserverDetailEn& detail);

    virtual ~AAAConnectionPoolObserver()                                                /* PMSTA-30941 - 200418 - PMO */
    {
    }

    virtual void processEvent(const  AAAConnectionPoolEvent& event);
};

#endif

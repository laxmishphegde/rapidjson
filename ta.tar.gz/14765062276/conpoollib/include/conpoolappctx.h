/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/**********************************************************************
*
*	Header %name:	conpoolappctx.h %
*	Instance:		lau1_1
*	Description:	
*	%created_by:	pmo %
*	%date_created:	Mon Jul 18 18:30:44 2016 %
*
**********************************************************************/
#ifndef conpoolappctx_h_H
#define conpoolappctx_h_H

#include <iostream>

typedef enum {
	appCxtNone,
	appCxtTextSize,
	appCtxSecurity
} AAATypeAppCtxEnum;

class AAAConpoolAppCtx 
{
public:
	AAAConpoolAppCtx(AAATypeAppCtxEnum, std::string, std::string);

    AAAConpoolAppCtx            (const AAAConpoolAppCtx &) = delete;    /* PMSTA-24076 - 180716 - PMO */
    AAAConpoolAppCtx & operator=(const AAAConpoolAppCtx &) = delete;    /* PMSTA-24076 - 180716 - PMO */

	AAATypeAppCtxEnum   getType() const;
	std::string         getCtxName() const;
	std::string         getValue() const;

private:
	AAATypeAppCtxEnum	_type;
	std::string			_ctxName;
	std::string			_value;
};

#endif


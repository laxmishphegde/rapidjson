/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef _lau1_1_conexcept_h_H
#define _lau1_1_conexcept_h_H

#include <stdexcept>
#include <string>

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/
class AAAPoolUsageException : public std::logic_error
{
public:
    AAAPoolUsageException(const std::string& error);
    virtual ~AAAPoolUsageException() throw ();                                                                                   /* PMSTA-21907 - 281215 - PMO */

	AAAPoolUsageException & operator=(const AAAPoolUsageException &) = delete;                                                  /* PMSTA-21907 - 281215 - PMO */
    std::string             getCallStack();                                                                                     /* PMSTA-21907 - 281215 - PMO */

private:
    std::string m_callstack;        /* Storage of the callstack where the exception is created                                     PMSTA-21907 - 281215 - PMO */
};

class AAAInvalidPoolDescriptionException : public AAAPoolUsageException
{
public:
    AAAInvalidPoolDescriptionException(const std::string&  error, const AAAConnectionDescription& desc);
    virtual ~AAAInvalidPoolDescriptionException() throw ();                                                                     /* PMSTA-21907 - 281215 - PMO */

	AAAInvalidPoolDescriptionException & operator=(const AAAInvalidPoolDescriptionException &) = delete;                        /* PMSTA-21907 - 281215 - PMO */

    const AAAConnectionDescription& getPoolDescription() const;
    virtual const char *            what()               const throw ();                                                        /* PMSTA-21907 - 281215 - PMO */

private:
    AAAConnectionDescription    desc;
    mutable std::string         m_whatExplanation;        /* Storage of what explanation */                                     /* PMSTA-21907 - 281215 - PMO */
};




class AAAInvalidConnectionIdentifierException :public  AAAPoolUsageException
{
public:
    AAAInvalidConnectionIdentifierException(const std::string&  error, const int& id);
    virtual ~AAAInvalidConnectionIdentifierException() throw ();                                                                /* PMSTA-21907 - 281215 - PMO */

	AAAInvalidConnectionIdentifierException & operator=(const AAAInvalidConnectionIdentifierException &) = delete;              /* PMSTA-21907 - 281215 - PMO */

    const int  &            getConnectionId()   const;
    virtual const char *    what()              const throw ();                                                                 /* PMSTA-21907 - 281215 - PMO */

private:
    int                     id;
    mutable std::string     m_whatExplanation;          /* Storage of what explanation */                                       /* PMSTA-21907 - 281215 - PMO */
};




class AAAInvalidConnectionAliasException :public  AAAPoolUsageException
{
public:
    AAAInvalidConnectionAliasException(const std::string&  error, const std::string& alias);
    virtual ~AAAInvalidConnectionAliasException() throw ();                                                                     /* PMSTA-21907 - 281215 - PMO */

    AAAInvalidConnectionAliasException & operator=(const AAAInvalidConnectionAliasException &) = delete;                        /* PMSTA-21907 - 281215 - PMO */

    const std::string &     getConnectionAlias()    const;
    virtual const char *    what()                  const throw ();                                                             /* PMSTA-21907 - 281215 - PMO */

private:
    std::string             alias;
    mutable std::string     m_whatExplanation;          /* Storage of what explanation */                                       /* PMSTA-21907 - 281215 - PMO */
};




class AAAMaximumPoolCapacityReachedException :public  AAAPoolUsageException
{
public:
    AAAMaximumPoolCapacityReachedException(const std::string&  error, const AAAConnectionDescription& desc, const int maxSize);
    virtual ~AAAMaximumPoolCapacityReachedException() throw ();                                                                 /* PMSTA-21907 - 281215 - PMO */

    AAAMaximumPoolCapacityReachedException & operator=(const AAAMaximumPoolCapacityReachedException &) = delete;                /* PMSTA-21907 - 281215 - PMO */

    const AAAConnectionDescription &    getPoolDescription() const;
    const int  &                        getMaxSize()         const;
    virtual const char *                what()               const throw ();                                                    /* PMSTA-21907 - 281215 - PMO */

private:
    AAAConnectionDescription    desc;
    int                         maxSize;
    mutable std::string         m_whatExplanation;      /* Storage of what explanation */                                       /* PMSTA-21907 - 281215 - PMO */
};




class AAAInvalidConnectionStateException : public AAAPoolUsageException
{
public:
    AAAInvalidConnectionStateException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId);
    virtual ~AAAInvalidConnectionStateException() throw ();                                                                     /* PMSTA-21907 - 281215 - PMO */

    AAAInvalidConnectionStateException & operator=(const AAAInvalidConnectionStateException &) = delete;                        /* PMSTA-21907 - 281215 - PMO */

    const AAAConnectionDescription &    getPoolDescription() const;
    const int &                         getConnectionId()    const;
    virtual const char *                what()               const throw ();                                                    /* PMSTA-21907 - 281215 - PMO */

private:
    AAAConnectionDescription    desc;
    int                         connectionId;
    mutable std::string         m_whatExplanation;      /* Storage of what explanation */                                       /* PMSTA-21907 - 281215 - PMO */
};




class AAACannotConnectException : public AAAPoolUsageException
{
public:
    AAACannotConnectException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId);
    virtual ~AAACannotConnectException() throw ();                                                                              /* PMSTA-21907 - 281215 - PMO */

    AAACannotConnectException & operator=(const AAACannotConnectException &) = delete;                                          /* PMSTA-21907 - 281215 - PMO */

    const AAAConnectionDescription &    getConnectionDescription()  const;
    const int &                         getConnectionId()           const;
    virtual const char *                what()                      const throw ();

private:
    friend class AAACannotConnectDbException;
    AAAConnectionDescription    desc;
    int                         connectionId;
    mutable std::string         m_whatExplanation;      /* Storage of what explanation */                                       /* PMSTA-21907 - 281215 - PMO */
};


class AAACannotConnectDbException : public AAACannotConnectException
{
public:
    AAACannotConnectDbException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId);
    virtual ~AAACannotConnectDbException() throw ();                                                                            /* PMSTA-21907 - 281215 - PMO */

    AAACannotConnectDbException & operator=(const AAACannotConnectDbException &) = delete;                                      /* PMSTA-21907 - 281215 - PMO */

private:
};

class AAAInvalidConnectionPropertiesException : public AAAPoolUsageException
{
public:
    AAAInvalidConnectionPropertiesException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId);
    virtual ~AAAInvalidConnectionPropertiesException() throw ();

    AAAInvalidConnectionPropertiesException & operator=(const AAAInvalidConnectionPropertiesException &) = delete;

    const AAAConnectionDescription &    getPoolDescription() const;
    const int &                         getConnectionId()    const;
    virtual const char *                what()               const throw ();

private:
    AAAConnectionDescription    desc;
    int                         connectionId;
    mutable std::string         m_whatExplanation;
};

#endif

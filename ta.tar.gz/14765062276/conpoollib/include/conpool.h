/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef ConnectionPool_H_
#define ConnectionPool_H_
#include <vector>
#include "conspec.h"
#include "conallocator.h"
#include "conpooleventtype.h"
#include "os.h"
#include "syslib.h"
#include <ostream>

extern int CON_GetNbUsedConnection();
extern int CON_GetTotalConnection();
extern AtomicInt SV_NbUsedConnection;

class DbiConnection;
class AAAConnectionPoolStatus;
class AAAConnectionStatus;
class AAAConnectionPoolObserver;
class AAAConpoolAppCtx;

class AAAConnectionPool
{
public:
    /**
    * Semantic constructor
    * @param spec the connection specifier, containing description of the model, type, role and username)
    * @param allocator the connection allocator used to allocate a connection  for the provided connection specification
    * @param maxASize the maximum number of authorized connection managed in the pool
    * @param startId the first id of the connection in the pool
    * @param maxId  the maxId that the pool will support
    */
    AAAConnectionPool(const  AAAConnectionSpecification& spec, const AAAConnectionAllocator& allocator, const int& minSize, const int& maxSize, const  int& startId, int& maxId);

    /**
    * Destructor
    */
    virtual ~AAAConnectionPool(void);

    AAAConnectionPool & operator=(const AAAConnectionPool &) = delete;    /* PMSTA-24076 - 180716 - PMO */

    /**
    * Obtain a new connection
    * @return an available connection in the pool, connection if returned is connected and ready to use
    * @throws
    */
    DbiConnection* getConnection();

    /**
    * Obtain an identified used connection
    * @param identifier  the connection identifier
    * @return a used connection in the pool
    * @throws
    */
    DbiConnection* getConnection(const int& identifier);

    /**
    * check if a connection identified by its identifier is managed ba the pool
    * @param identifier identifier a connection identifier
    * @return  bool if the identifier corresponds to a identifier of connection managed in the pool
    */
    bool containsId(const int& identifier);

    /**
    * add an available connection in the pool
    * @param connection the connection to ass
    */
    void add(DbiConnection* connection);

    /**
    * @return the last identifier of the connections managed by the pool
    */
    const int &getEndId() const;
    /**
    * @return the first identifier of the connections managed by the pool
    */
    const int &getStartId() const;

    bool reconnect(DbiConnection& connection);
    /**
    * Release a used connection in the pool
    * Depending on pool management policies the connection is disconnected, and potentially reconnected
    * @param  connection the used connection to release in the pool
    * @throws AAAInvalidConnectionStateException in case of the connection not in the correct state (i.e. not marked as used)
    */
    void release(DbiConnection* connection);
    void remove(DbiConnection* connection);
    /**
    * Mark a connection as used
    */
    void use(DbiConnection* connection);
    /**
    * @return the max number of connection that the pool can manage
    */
    const int& getMaxSize() const;
    /**
    * @return the min number of connection that the pool must keep connected
    */
    const int& getMinSize() const;
    /**
    * @return the actual count of managed connection (used and available)
    */
    int getConnectionCount() const;
    /**
    * @return the actual count of used connection
    */
    int getUsedConnectionCount() const;
    /**
    * @return the actual count of available connection
    */
    int getAvaibleConnectionCount()  const;
    /**
    * @return the remaining count of allocable connection (is maxSize - connectionCount)
    */
    int getRemainingAllocableConnectionCount() const;
    /**
    * @return the number of total connection connected (used + available)
    */
    int getConnectedConnectionCount() const;
    /**
    * set an observer in the pool.
    * if there is an already attached observed this one is replaced. if the provided observer pointer is null there is no more observer attached to the pool.
    * @param observer pointer on the observer to attach
    */
    void setObserver(AAAConnectionPoolObserver * observer);
    /**
    * obtain pool status
    * @return the connection pool status (note that the object must be deleted in the caller context
    */
    AAAConnectionPoolStatus getStatus()const ;

    /**
    * check if provided credential are identical with those of the pool
    * @param username the user name  username
    * @param cryptedpassword the crypted password
    */
    bool isCredentialIdentical(const char* username, const PasswordEncrypted&) const;
    /**
    * search a used connection in the pool by the use of a search function
    * @param searchFunc search function to apply, in case of search returned true, the search is interpreted as terminated
    * @param searchArg the search context
    * @return pointer on the found connection (nullptr if not found)
    */
    DbiConnection* find(bool(*searchFunc)(DbiConnection&, void*), void* searchArg);


    void updatePassword(const PasswordEncrypted& password);

    friend std::ostream& operator<<(std::ostream& os, const AAAConnectionPool& obj);

    std::vector<AAAConnectionStatus> getAllConnectionsStatus(const AAAConnectionStatusParam&);
    std::string& getPoolName();
    AAAConnectionSpecification& getConnectionSpecification();
    void ApplyPolicies();

    /* DLA - PMSTA-24234 - 160803 */
    /* incRef,decRef,getRefNb TO NOT USE DIRECTLY, only via Conprovider class and locked*/
    void incRef();
    void decRef();
    int  getRefNb();

    std::string getUrl();
    void        setUrl(const AAAConnectionDescription& desc);

    /* PMSTA-30415 - 090318 - PMO
     * For AAAConnectionPoolGuard
     */
    void lock()
    {
        m_lock.lock();
    }

    void unlock()
    {
        m_lock.unlock();
    }

private:
    void publishEvent(const  AAAConnectionPoolEventType &eventType, const int& connectionId, const bool& success) const;
    DbiConnection* createConnection();//throws bad_function_call
    DbiConnection* createConnection(unsigned  long& id);
    bool connect(DbiConnection& connection);
    void disconnect(DbiConnection& connection);

    std::set<DbiConnection*>    allConnections;
    std::set<DbiConnection*>    availableConnections;
    std::set<DbiConnection*>    usedConnections;
    int maxSize;
    int minSize;
    int startId;
    int endId;
    int refToPool;  /* DLA - PMSTA-24234 - 160803 */
    int nbConnectionConnected;
    AAAConnectionSpecification m_specification;
    AAAConnectionPoolObserver *m_observer;
    AAAConnectionAllocator allocator;
    AAAConpoolAppCtx * appCtx;
    Lock m_lock;
    std::string poolName;

};

/* PMSTA-30415 - 090318 - PMO */
class AAAConnectionPoolGuard
{
    public:
        AAAConnectionPoolGuard() : m_pool(nullptr)
        {
        }

        void lock(AAAConnectionPool * pool)
        {
            m_pool = pool;
            if (nullptr != pool)
            {
                pool->lock();
            }
        }

        ~AAAConnectionPoolGuard()
        {
            if (nullptr != m_pool)
            {
                m_pool->unlock();
            }
        }

    private:
        AAAConnectionPool * m_pool;
};

#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef LocalConnectionProvider_H_
#define LocalConnectionProvider_H_

#include <map>
#include <vector>

class AAAConnectionPoolConfiguration;
class AAAConnection;
class AAAConnectionPoolStatus;
class AAAConnectionStatus;
class AAAConnectionStatusParam;

class SessionProperties;
class DbiConnection;

/* DLA - PMSTA-25748 - 161220 */
class localConnection
{
public:
    localConnection();
    localConnection(localConnection const & src)
        : localConnection()
    {
        *this = src;
    }

    virtual ~localConnection();

    localConnection & operator=(const localConnection &src)
    {
        connectionPtr = src.connectionPtr;
        return *this;
    }

    bool operator== (const  localConnection& toCompare) const;

    DbiConnection* connectionPtr;
};

typedef struct DBA_DYNFLD DBA_DYNFLD_ST, *DBA_DYNFLD_STP;

/**
* Class implement as a singleton dedicated to front the global Connection Provider and front all
* public primitives of the global connection provider enabling to
* - obtain a connection based on its description
* - obtain a connection based on its identifier
* - release a connection after usage
* - configure a connection pool (mentionning that connection issued from this pool is the preferred one)
* - unconfigure a connection pool
*
* One instance of such class is dedicated for each thread of the application.
*
* It implement the prefered connection mechanism:
* - when a connection is obtained from the pool is there is no already cached connection,  if the preferred connection pool has
*    been specified at the configuration time and the connection is issued from this pool, the connection is cache, and marked as used.
* - when a connection is requested by id and correspond to the prefered connection than the cached connection is returned.
*
* Every connection when consumer does not need it anymore MUST be released.
*
* Every consumer must use this local connection provider instead of global connection pool.
*
* Flow sample:
*
*   try {
* 		AAALocalConnectionProvider.get().configure(connectionPoolConfiguration,true);
*	}
*   catch (std::std::bad_function_call &e) {
*     //if we arriving there it means that: a connection pool for same kind of configuration is already configured
*          .
*          .
*		}
*   .
*   .
*   DbiConnection* connection ;
*   ConnectionDescription desc  (.....) ;
*   try {
*		DbiConnection* AAALocalConnectionProvider.get().get(desc) ;
*   }
*   catch (std::std::bad_function_call &e) {
*     //if we arriving there it means that: desc is bad
*          .
*          .
*   }
*	int id = connection->getId() ;
*   .
*   .
*	try {
*		DbiConnection* theConnection = AAALocalConnectionProvider.get().get(id) ;
*   }
*   catch (std::std::bad_function_call &e) {
*     //if we arriving there it means that: desc is bad
*          .
*          .
*   }
*	AAALocalConnectionProvider.get().release(theConnection) ;
*
*   // required at the end of the thread
*	AAALocalConnectionProvider.close();
*
*/
class AAALocalConnectionProvider
{
public:

    virtual   ~AAALocalConnectionProvider();

    AAALocalConnectionProvider(AAALocalConnectionProvider const & )            = delete;    /* PMSTA-25793 - 281216 - PMO */
    AAALocalConnectionProvider & operator=(const AAALocalConnectionProvider &) = delete;    /* PMSTA-24076 - 180716 - PMO */

	/**
	*
	* @return the local connection provider
	*/
	static AAALocalConnectionProvider& get();
	/**
	* Close the local connection provider.
	* This method must be call at the end of the thread
	*/
	static void close(AAALocalConnectionProvider * &);
	/**
	* Return a connection from its description.
	* The connection must  be released after usage through AAALocalConnectionProvider::get().release(connectionPointer).
	* The connection at this stage is connected and isValid and can be used for functional purpose.
	* @return the connection
	* @throws
	*/
	DbiConnection* getConnection(const AAAConnectionDescription& desc);
	/**
	* Return a connection from its identifier.
	* Not that if a connection match this id, this connection must be in use (not been released).
	* There is no guarantee about connection validity.
	* @return the connection
	* @throws
	*/
	DbiConnection* getConnection(const int& id);

    /**
	* Release a connection.
	* The connection must have not been already release
	*/
	void release(DbiConnection* connection);

    /*
    * Remove a connection.
    */
    void remove(DbiConnection* connection);

    /**
	* Reconnection a connection in use without delete his context
	* @param connection the connection to reconnect
	* @return the reconnected connection, null if the reconnection failed (in this case the connection is
    d)
	*/
	bool reconnect(DbiConnection& connection);
	void configure(const AAAConnectionPoolConfiguration& connectionPoolConfiguration);
	void unconfigure(const AAAConnectionDescription&);
    void reset(AAAConnectionTypeEnum);
    void reset(void);

    DbiConnection* find(const AAAConnectionType* typeScopeFilter, const char* user, const char* serverNameScopeFilter, bool(*searchFunc)(DbiConnection&, void*), void* searchArg);

    bool changePassword(DbiConnection& connection, const PasswordEncrypted& password);
    bool changePassword(DbiConnection& adminConnection, const  std::string& user , const PasswordEncrypted& password);
    std::vector<AAAConnectionStatus> getAllConnectionsStatus();
    std::vector<std::pair<AAAConnectionPoolStatus, std::vector<AAAConnectionStatus>>> getAllConnectionsStatusByPool(const AAAConnectionStatusParam& );

    static void           initAdminSessionMap();

    std::vector<AAAConnectionStatus> getCachedConnectionsStatus();

    std::vector<localConnection> *getLocalConnections();

    SessionProperties            &getSessionProperties(const AAAConnectionDescription& desc);

    void           clearSessionMap(); /* PMSTA-34344 - TEB - 190805 */

private:
    RET_CODE    installSessionProperties(DbiConnection& connection);
    RET_CODE    removeSessionProperties (DbiConnection& connection);

    AAALocalConnectionProvider();

    void applyPolicies();

    std::vector<localConnection>                    preferredConnections;
    std::map<int, DbiConnection*>                   m_usedConnectionsMap;   /* PMSTA-30415 - 090318 - PMO */
    time_t                                          lastCleanUp;            /* DLA - PMSTA-25748 - 161230 */
    std::map<AAAConnectionRole, SessionProperties>  m_mapSessionProperties;

#ifdef _DEBUG
    Lock lock;
#endif
};

class LocalConnectionStatus
{
public:
    LocalConnectionStatus();

    LocalConnectionStatus(LocalConnectionStatus const & )            = delete;    /* PMSTA-25793 - 281216 - PMO */
    LocalConnectionStatus & operator=(const LocalConnectionStatus &) = delete;    /* PMSTA-25793 - 281216 - PMO */

    friend std::ostream& operator<<(std::ostream& os, const LocalConnectionStatus& obj);

private:
    std::string m_strOut;
};
#endif

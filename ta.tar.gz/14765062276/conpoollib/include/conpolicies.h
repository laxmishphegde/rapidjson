/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef CON_POLICIES_H__
#define CON_POLICIES_H__
#include <iostream>
/**
* enumeration dedicated to support connection policy: when the connection has to be connected
*/
typedef enum { 
	/**
	* connection is performed at creation time
	*/
	ConnectAtCreate, 
	/**
	* connection is performed when connection is taken from the pool
	*/
	ConnectAtUse 
}  AAAConnectionPolicy;
/**
* enumeration dedicated to support connection policy: when the connection has to be connected
*/
typedef enum { 
	/**
	* disconnection is performed at desctuction time
	*/
	DisconnectAtDelete, 
	/**
	*disconnection is performed when connection is returned into the pool
	*/
	DisconnectAtRelease, 
    /**
    *disconnection is performed when connection is too old (linked to AAAAgingPolicy)
    */
    DisconnectAtUnusedConnTimeout
}  AAADisconnectionPolicy;

inline const char * AAA_GetAAADisconnectionPolicyStr(const int idx)
{
    static const char * AAADisconnectionPolicyStr[] = {"DisconnectAtDelete", "DisconnectAtRelease", "DisconnectAtUnusedConnTimeout"}; 

    return AAADisconnectionPolicyStr[idx];
}

typedef enum {
	/**
	* no explicit aging process
	*/
	NoAging,
	/**
	* connection are subject to aging, when connection is taken from the pool if the connected state is more than maxAge, connection is reconnected.
	*/
	Aging 
}  AAAAgingPolicy;

/**
* ConnectionPolocies is to describe how the connection has to be managed on the pool regarding there lifecycle and desribe
* <ul>
* <li> when connection has to be connected though the connectionPolicy property : either at  creation time or when  a  connection istaken from the pool</li>
* <li> when connection has to be disconnection through the disconnectionPolicy property :  either at destuction time or when a  connection is released into the pool</li>
* <li> if the connection are subject to aging, i.e reconnected after a given time, where max age time is expressed in ms and is correspond to the connected state duration of a connection </li>
* </ul>
*
*
*/
class  AAAConnectionPolicies {
public:
	/**
	* Semantic constructor.
	* @param connectionPolicy the connection policy
	* @param disconnectionPolicy the disconneciton policy
	* @param agingPolicy the aging policiy
	* @param maxAge the max age of the connection (relevant if the aging policy)
	*/
    AAAConnectionPolicies(const  AAAConnectionPolicy& connectionPolicy, const  AAADisconnectionPolicy& disconnectionPolicy, const unsigned long& maxIdleTime, const  AAAAgingPolicy& agingPolicy, const unsigned long& maxAge);
	/**
	* Copy constructor.
	* @param toCopy  the object to copy into the new instance
	*/
	AAAConnectionPolicies(const  AAAConnectionPolicies& toCopy);
	/**
	* Destructor.
	*/
	~AAAConnectionPolicies();
	/**
	* Assignment operator.
	* @param toCopy  the object to copy into the operand instance
	*/
	void operator = (const  AAAConnectionPolicies& toCopy);
	/**
	* @return the connection policy
	*/
	const AAAConnectionPolicy& getConnectionPolicy() const;
	/**
	* @return the disconnection policy
	*/
	const AAADisconnectionPolicy& getDisconnectionPolicy() const;
	/**
	* @return the aging policy
	*/
	const AAAAgingPolicy& getAgingPolicy() const;
	/**
	* @return the max connection state duration of a connection. Note that is significant if agingPolicy is not NoAging
	*/
	const unsigned long& getMaxAge() const;
    /**
    * @return the aging policy
    */
    const unsigned long& getMaxIdleTime() const;



	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionPolicies& obj);

private:
	/**
	* the connection policy
	*/
	AAAConnectionPolicy connectionPolicy;
	/**
	* the disconnection policy
	*/
	AAADisconnectionPolicy disconnectionPolicy;
	/**
	* the aging policy
	*/
	AAAAgingPolicy agingPolicy;
	/**
	* the max connection state duration of a connection. Note that is significant if agingPolicy is not NoAging
	*/
	unsigned long maxAge;
    /**
    * the max connection state duration of an Ilde connection. Note that is significant if disconnectionPolicy is DisconnectAtUnusedConnTimeout
    */
    unsigned long maxIdleTime;
};

#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionDescription_H
#define  AAAConnectionDescription_H

#define TIME_H

#include "conspec.h"
#include "conrole.h"

#include <map>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

class ostream;

/**
* Utility class to determine the type of Database autenticatin mechanism used by the process (static)
* <ul>
* <li>password </li>
* <li>iam AWS</li>
* <li>kerberos @@TODO</li>
* </ul>
*/
class DBAuthenticationMethod
{
public:
    enum Value
    {
        password,
        iam
        // kerberos
    };

    constexpr static const char* ENV_VARIABLE_NAME = "DB_AUTH_MODE";

    DBAuthenticationMethod() : value(password) { }
    constexpr DBAuthenticationMethod(Value aMethod) : value(aMethod) { }

    constexpr bool operator==(DBAuthenticationMethod a) const { return value == a.value; }
    constexpr bool operator!=(DBAuthenticationMethod a) const { return value != a.value; }

    static const DBAuthenticationMethod get();

private:
    Value value;
};


/**
* Class dedicated to describe a connection, where a connection is described through
* <ul>
* <li> a connection type </li>
* <li> a connection model </li>
* <li> a connection role </li>
* <li> the user for which the connection is made available </li
* <li> a connection serverName, the target server name </li>
* </ul>
*/
class  AAAConnectionDescription
{
public:
	/**
	* create a connection description for a given type, mode and dedicated to be provided for a given user.
	* @param  type the connection type
	* @param  model the connection model
	* @param  user for which the described connection is dedicated.
    * @param  serverName for which the described connection is dedicated.
	*/
    AAAConnectionDescription(const  AAAConnectionType& type = NullServer,
                             const std::string& serverName = "",
                             const AAAConnectionRole& role = ROLE_USER,
                             const  DBA_RDBMS_ENUM& model = UnknownRdbms,
                             const std::string& urlStr = "");

    AAAConnectionDescription(const AAAConnectionRole& role);

    AAAConnectionDescription(const AAAConnectionSpecification& specification);
	/**
	* copy constructor.
	* @param toCopy the connection description to copy into the new instance.
	*/
	AAAConnectionDescription(const  AAAConnectionDescription& toCopy);
	/**
	* Destructor.
	*/
	~AAAConnectionDescription(void);
	/**
	* Assignment operator.
	* @param toCopy the operand to assign.
	*/
	AAAConnectionDescription & operator= (const  AAAConnectionDescription& toCopy);
	/**
	* Comparison operator.
	* Connection description are considered identical if they have same type, same modal and dedicated to the same user.
	" @param toCompare the connection description to compare with
	* @return true if two instance are considered identical.
	*/
	bool operator== (const  AAAConnectionDescription& toCompare) const;
    bool operator<  (const  AAAConnectionDescription& toCompare) const;
    bool match(const AAAConnectionType* typeScopeFilter,
               const char* serverNameScopeFilter,
               const char* user) const;

    /**
	* Connection type accessors.
	* @return the type of the described connection
	*/
	const  AAAConnectionType& getType() const;
    const  std::string& getTypeName() const;
	/**
	* Connection model accessors
	* @return the model of the described connections
	*/
	const  DBA_RDBMS_ENUM& getModel() const;
    const  std::string& getModelName() const;
    void                   setModel(const DBA_RDBMS_ENUM &newModel);

	/** connection role accessors
	* @return the role of the described connections
	*/
	const  AAAConnectionRole& getRole() const;
    const std::string& getRoleName() const;

    const std::string& getServerName()const;
    void               setServerName(const std::string &newServerName);

    const std::string& getUrl()const;
    void               setUrl(const std::string &newUrl);
	/**
	* Connection user accessors
	* @return the user of the connection
	*/
	const std::string& getUser() const;
    void               setUser(const std::string&);

	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionDescription& obj);

    void setSilentMode(bool bSilentMode);
    bool getSilentMode() const;

    void setReloadProcess();

    void reload();
	void updateSrvPoolCfg();
	SERVERCONNECTNAT_ENUM isFinServerPool();
	bool isLastServer();
    std::string getReportServer();  /* PMSTA-41931 - JOS - 20201011 */

    void               setDatabase(const std::string& database);
    const std::string& getDatabase() const;

private:
    void loadConfig();

    AAAConnectionType   m_type;         /* the connection type                      */
    DBA_RDBMS_ENUM      m_model;        /* the connection model                     */
    AAAConnectionRole   m_role;         /* the connection role                      */
    std::string         m_serverName;   /* the connection serverName                */
    std::string         m_user;         /* the connection associated user identity  */
    std::string         m_url;
    bool                m_bSilentMode;
    bool                m_bReloadProcess;
    std::string         m_database;     /* PMSTA-46681 - LJE - 230124 */
};


class ServerClientConfig
{
public:

    static std::string toUrl(const std::string& host, int port, bool usingSsl, bool isHttp);
public:
    ServerClientConfig();
    ServerClientConfig(std::string forServerName);

    ServerClientConfig & operator=(const ServerClientConfig &);

    bool           compare(const ServerClientConfig &);
    bool           isHttpServer() const;
    DBA_RDBMS_ENUM getServerModel() const;

    std::string    getUrl() const;          // The URL visible on the host running the server
    std::string    getExternalUrl() const;  // The URL used by client application to connect to the server

    std::string    getServerName() const;
    SCHEME_ENUM    getScheme() const;
    SCHEME_ENUM    getExternalScheme() const; /* PMSTA-30135 CMILOS 140219 */
    const std::string& getSchemeName() const;
    const std::string& getHost();
    const std::string& getHostName(); /* PMSTA - 32186 CMILOS 05032019 */
    int                getPort();
    const std::string& getExternalHost();
    int                getExternalPort();
    bool               isDispatcher();
    const std::string& getBusEntityCd(); /* PMSTA-41113 - KNI - 26092020 */
    const int getBusEntityId();          /* PMSTA-41113 - KNI - 26092020 */
    bool               isReportServer();    /* PMSTA-41931 - JOS - 20201011 */


    ServerClientConfig(const ServerClientConfig &);

    void setServerName(const std::string&);
    void setHost(const std::string&);
    void setHostName(const std::string&); /* PMSTA - 32186 CMILOS 05032019 */
    void setPort(int);
    void setExternalHost(const std::string&);
    void setExternalPort(int);
    void setUseSsl(bool);
    void setServerModel(const DBA_RDBMS_ENUM);
    void setScheme(const SCHEME_ENUM);
    void setExternalScheme(const SCHEME_ENUM); /* PMSTA-30135 CMILOS 140219 */
    void setDispatcher(bool);
    void setBusinessEntity(const std::string&, int); /* PMSTA-41113 - KNI - 26092020 */

private:
    void updateUrl();
    void set(const ServerClientConfig &);

    int             m_port;
    int             m_externalPort;
    std::string     m_host; /* when the server binds stores the resolved IP address if necessary */
    std::string     m_host_name; /* when the server binds stores the qualified name from listener.host */ /* PMSTA - 32186 CMILOS 05032019 */
    std::string     m_externalHost;
    std::string     m_servername;
    std::string     m_url;
    std::string     m_externalUrl;
    bool            m_useSsl;
    bool            m_useExternalSsl; /* PMSTA-30135 CMILOS 140219 */
    bool            m_bDispatcher;
    bool            m_isHttpServer;
    DBA_RDBMS_ENUM  m_serverModel;
    SCHEME_ENUM     m_schemeEn;
    SCHEME_ENUM     m_external_schemeEn; /* PMSTA-30135 CMILOS 140219 */
    std::string     m_businessEntityCd;   /* PMSTA-41113 - KNI - 26092020 */
    int             m_businessEntityId;   /* PMSTA-41113 - KNI - 26092020 */
};

class AAAFinServerPool {

public:

	AAAFinServerPool();

	AAAFinServerPool(const AAAFinServerPool&) = delete;
	AAAFinServerPool& operator=(const AAAFinServerPool&) = delete;

	const ServerClientConfig&        next();
	void 	                         updateServerPoolCompo(const std::string &);
	size_t                           availableFinSrv();
	void                             initFinServerPool(const std::string &);
	void 	                         addServerInQuarantine();
	const ServerClientConfig &       getCurrentServer();
	bool                             isLastServer();
    std::string                      getReportServerFromPool(); /* PMSTA-41931 - JOS - 20201011 */

private:
	void							 getListOfServers(const std::string &poolName, std::vector<ServerClientConfig>&);
	bool 							 isInQuarantine(const ServerClientConfig&);

	std::vector<ServerClientConfig> m_finServers;
	std::map<std::string, time_t>   m_srvInQuarantine;
	ServerClientConfig              m_currentServer;
	bool                            m_isLastServer;

	INT64_T m_quarantinePeriod;
};

class ClientConfig
{
public:
    ClientConfig();

    ClientConfig(const ClientConfig &) = delete;
    ClientConfig & operator=(const ClientConfig &) = delete;

    const ServerClientConfig& getServerClientConfig(const std::string&);

    void reload(const std::string&);
	void updateSrvPoolCfg(const std::string&);
	SERVERCONNECTNAT_ENUM getServerType();
	size_t availableServerInPool();
	bool isLastServer();
    std::string getReportServer(const std::string&);    /* PMSTA-41931 - JOS - 20201011 */

private:

	bool isFinServerPool(const std::string &);

	SERVERCONNECTNAT_ENUM                     serverType;
    static const ServerClientConfig           Null_ServerClientConfig;
    std::map<std::string, ServerClientConfig> m_allClientServerConfig;
	AAAFinServerPool                          m_finSvrPool;
};

#endif

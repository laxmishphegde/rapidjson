/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionCredentials_H_
#define  AAAConnectionCredentials_H_
#include <string>
#include <ostream>
#include "password.h"
#include <memory>

/**
* Capture credentials to be associated to a connection, where credential correspond to a user identity and an associated password.
*/


class  AAAConnectionCredentialsI
{
public:
	virtual ~AAAConnectionCredentialsI() {};

	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionCredentialsI& obj);

};

class  AAAConnectionCredentialsFactory
{
public:
	static  std::unique_ptr<AAAConnectionCredentialsFactory> get();

	AAAConnectionCredentialsI createCredential(const std::string& user);
};



class  AAAConnectionCredentials //: public AAAConnectionCredentialsI
{
public:
	/**
	* Semantic constructor.
	* @param user the user identity
	* @param password the related password
	*/
	AAAConnectionCredentials(const std::string& user, const PasswordEncrypted& password);
	/**
	* Copy constructor.
	* @param toCopy the object to copy into the new object
	*/
	AAAConnectionCredentials(const  AAAConnectionCredentials& toCopy);
	/**
	* Descructor.
	*/
	~AAAConnectionCredentials();
	/**
	* Assignment operator.
	* @param toCopy the object to copy into the operand.
	*/
	void operator=(const  AAAConnectionCredentials& toCopy);
	/**
	* @return the user identity
	*/
	const std::string& getUser()const;
	/**
	* @return the password
	*/
	const PasswordEncrypted& getPassword() const ;
	/**
	* Check is credentials match a given user and password
	* @param user the  user name to match against credentials properties
	* @param password the  password  to match against credentials properties
	* @return true if params match credentials false otherwise.
	*/
	bool match(const char* user, const PasswordEncrypted& password) const;

	void updatePassword(const PasswordEncrypted& password);

	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionCredentials& obj);


private:
	/**
	* Prohibited default constructor
	*/
	AAAConnectionCredentials();
	/**
	* the user identity
	*/
	std::string user ;
	/**
	* the password
	*/
	PasswordEncrypted password ;
};
#endif

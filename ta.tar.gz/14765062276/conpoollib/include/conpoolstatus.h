/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef PoolStatus_H__
#define PoolStatus_H__
#include <string>
#include <iostream>
class  AAAConnectionPoolStatus
{
public:
    AAAConnectionPoolStatus();
	AAAConnectionPoolStatus(const AAAConnectionDescription& desc, const int& maxSize, const int& availableConnectionsCount, const int& usedConnectionsCount ,const int& beginId);
    AAAConnectionPoolStatus(const AAAConnectionPoolStatus& tocopy);
	~AAAConnectionPoolStatus(void);

    AAAConnectionPoolStatus & operator=(const AAAConnectionPoolStatus &);

	const int& getMaxSize() const;
	const int& getAvailableConnectionsCount() const;
	const int& getUsedConnectionsCount() const;
	const std::string& getStringRep() ;

	bool operator==(const AAAConnectionPoolStatus& toCompare)const;
    bool operator<(const AAAConnectionPoolStatus& toCompare)const;

	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolStatus& obj);

private:
	AAAConnectionDescription description;
	int maxSize ;
	int availableConnectionsCount;
	int usedConnectionsCount;
    int beginId;
	std::string  stringRep ;
    int tascTechGroup;
};
#endif

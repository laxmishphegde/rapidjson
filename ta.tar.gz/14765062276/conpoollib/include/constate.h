/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionState_H_
#define  AAAConnectionState_H_
enum class AAAConnectionState {
    AVAILABLE, 
    IN_USE, 
    TRANS_OPEN,
    DEAD_FOOD           /* Destructor value PMSTA-30415 - 090318 - PMO */
};
#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef Connection_H_
#define Connection_H_

#include "syslib.h"
#include "conspec.h"
#include "constate.h"
#include <time.h>
#include <iostream>
#include <vector>
#include "os.h"
#include "date.h"

class AAAConnectionPool;
class AAAConnectionDescription;
class AAAConnection;

typedef struct DBA_DYNFLD DBA_DYNFLD_ST, *DBA_DYNFLD_STP;
typedef struct DBA_PROC_STRUCT DBA_PROC_ST, *DBA_PROC_STP;

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

class AAASessionProperty {

public:
	/**
	* Semantic constructor
	* @param propertyName the property name
	* @param propertyValue the property value
	*/
	AAASessionProperty(const std::string& propertyName, const std::string& propertyValue);

    /**
	* Copy constructor
	* @param toCopy the object to copy
	*/
	AAASessionProperty(const AAASessionProperty& toCopy);

    AAASessionProperty & operator=(const AAASessionProperty &);     /* PMSTA-24076 - 180716 - PMO */

    /**
    * @return the property name
    */
     std::string getPropertyName() const;

	/**
	* @return the property value
	*/
	const std::string& getPropertyValue() const;


private :
    std::string m_propertyName;
	std::string m_propertyValue;

};
enum class SessionPropertyActionType{
	NEW,
	REMOVE,
	CHANGE
};

class SessionPropertyAction
{
public:
	SessionPropertyAction(const SessionPropertyActionType& _action, const AAASessionProperty& _sessionProperty) :   action(_action),
                                                                                                                    sessionProperty(_sessionProperty)
    {
	}

	~SessionPropertyAction()  {}

    SessionPropertyAction & operator=(const SessionPropertyAction & src)      /* PMSTA-24076 - 180716 - PMO */
    {
        action          = src.action;
        sessionProperty = src.sessionProperty;

        return *this;
    }

	const SessionPropertyActionType& getAction() const{ return action; }
	const AAASessionProperty& getSessionProperty() const { return sessionProperty; }

private:
	SessionPropertyActionType   action;
	AAASessionProperty          sessionProperty;
};

class SessionProperties
{
public:
    SessionProperties();
    SessionProperties(const SessionProperties& toCopy);
    SessionProperties & operator=(const SessionProperties &);

    bool operator== (const  SessionProperties& toCompare) = delete;

    void               setUserId(ID_T userId);
    ID_T               getUserId() const;

    void               setDataProfileId(ID_T dataProfileId);
    ID_T               getDataProfileId() const;

    void               setModifStat(int modifStat);
    int                getModifStat() const;

    void               setLanguageDictId(DICT_T languageDictId);
    DICT_T             getLanguageDictId() const;

    void               setApplSessionCd(const std::string &applSessionCd);
    std::string        getApplSessionCd() const;

    ID_T               getBusinessEntityId() const;

    void               setMainDlmEnMax(DLM_ENUM m_mainDlmEnMax);
    DLM_ENUM           getMainDlmEnMax() const;

    void               setAddDlmEnMax(DLM_ENUM m_addDlmEnMax);
    DLM_ENUM           getAddDlmEnMax() const;

    ID_T               getChangeSetId() const;

    void               setApplSessionStp(DBA_DYNFLD_STP applSessionStp);
    DBA_DYNFLD_STP     getApplSessionStp();

    void               setSetConnUser();
    bool               isSetConnUser() const;

    void               setSetDefaultProp();
    bool               isSetDefaultProp() const;

    void               setDbName(const std::string &dbName);
    const std::string &getDbName() const;

    void               setDateTimeFormat(DATE_STYLE_ENUM dateTimeFormatEn);
    DATE_STYLE_ENUM    getDateTimeFormat() const;

    void               setDeferredNameResolution(bool);
    bool               isDeferredNameResolution() const;

    void           setPropFromApplSession();

    void           resetSessionproperties();

    /* PMSTA-34344 - TEB - 190805 */
    void           setHttpSessionId(const std::string &httpSessionId);
    std::string    getHttpSessionId() const;


private:

    void             setBusinessEntityId(ID_T businessEntityId);
    void             setChangeSetId(ID_T changeSetId);

    ID_T             m_userId;
    ID_T             m_dataProfileId;
    int              m_modifStat;
    DICT_T           m_languageDictId;
    std::string      m_applSessionCd;
    ID_T             m_businessEntityId;
    DLM_ENUM         m_mainDlmEnMax;
    DLM_ENUM         m_addDlmEnMax;
    ID_T             m_changeSetId;
    bool             m_bSetConnUser;
    bool             m_bSetDefaultProp;
    std::string      m_dbName;
    std::string      m_defaultDbName;
    DATE_STYLE_ENUM  m_dateTimeFormatEn;
    bool             m_bDeferredNameResolution;
    bool             m_bReadOnly;

    DBA_DYNFLD_STP   m_applSessionStp;
    AAAConnection  * m_connectionPtr;

    MemoryPool       m_mp;

    /* PMSTA-34344 - TEB - 190805 */
    // Add httpSessionId, map of ids put into the cookies
    std::string      m_httpSessionId;

};

enum class KindOfRequest
{
    Init = 0,
    InitSession,
    RequestHelper,
    Internal,
    Default
};

/**
* Abstract root class for the connection classes dedicated to be managed through the connection pool.
*
*/
class  AAAConnection
{
public:
	/**
	* Constructor
	* @param spec the connection specification
	* @param id the connection identifier
	*/
	AAAConnection(const  AAAConnectionSpecification& spec, const int& id);
	 /**
	 * Destructor
	 */
	virtual ~AAAConnection(void);

    AAAConnection & operator=(const AAAConnection &) = delete;      /* PMSTA-24076 - 180716 - PMO */

	/**
	* Check if a connection match a provided identifier.
	* @param the identifier to check
	* @return true if the identifier match the provided identifier.
	*/
	bool matchId(const int& id) const;
	/**
	* Connection identifier accessors.
	* @return the connection identifier
	*/
	int& getId() const;
	/**
	* Connection identifier modifier.
	* @param the connect identifier.
	*/
	void setId(const int& id);
	/**
	* Connection specification accessors.
	* @return the connection specification.
	*/
	const  AAAConnectionSpecification& getSpecification()const;
	/**
	* Make the connection as in use. The connection must be in available state.
	*  @throws std::bad_function_call in the connection is no in available state
	*/
	/**
	* use status accessors
	* @return true if the connection is in use
	*/
	bool isInUse (void) const	;
	/**
	*  set the pool owning the connection
	* @param pool pointer to the owning connection pool
	*/
    void setOwningPool(AAAConnectionPool* pool)
    {
        this->owningPool = pool;
    }

    AAAConnectionPool* getOwningPool() const
    {
        return this->owningPool;
    }

    /**
    *  set the pool owning the connection
    * @param pool pointer to the owning connection pool
    */
    void setOwningLocalProvider(AAALocalConnectionProvider* localProvider)
    {
        this->owningLocalProvider = localProvider;
    }
    AAALocalConnectionProvider* getOwingLocalProvider() const
    {
        return this->owningLocalProvider;
    }

    /**
	* connect the connection to the target system
	* @return a boolean indicating the connection succeed or not
	*/
	virtual bool connect() = 0;
	/**
	* disconnect the connection from the target system
	* @return a boolean indicating the disconnection succeed or not
	*/
	virtual bool disconnect() = 0;
    /**
    * re-connect the connection to the target system
    * @return a boolean indicating the connection succeed or not
    */
    virtual bool reconnect() = 0;
    /**
    * release the connection to the target system
    */
    virtual void release();
    /**
    * check if the connection is not dead
    * @return a boolean indicating if the connection is valid or not
    */
    virtual bool checkDbConn()
    {
        return true;
    }
    /**
	* check if the connection is valid
	* @return a boolean indicating if the connection is valid or not
	*/
	bool isValid();
	/**
	* check if the connection is valid
	* @return a boolean indicating if the connection is valid or not
	*/
	void setValidConnection(bool) ;
	/**
	* return the connection time
	*/
	const time_t & getConnectionTime()  const;
    /**
    * return the connection time
    */
    const time_t & getIdleTime()  const;
    /**
    * return the connection time
    */
    const time_t &getStartProcTime() const;
    /**
    * return the connection time
    */
    const time_t & setStartProcTime();
    /**
    * return the connection time
    */
    void resetStartProcTime();
    /**
    * reset the connection idle time
    */
    void resetIdleTime();
	/**
	* indicates if the connection has to be considered has expired
	*/
	bool isExpired(const unsigned long&);
    /**
    * indicates if the connection has to be considered has expired
    */
    bool isIdleTimeOut(const unsigned long&);
	/**
	* change the connection state.
	* if the connection is marked as connected the connection time of the connection is set to current time
	* if the connection is marked as not connected the connection time of the connection is set to  0
	* @param connectFlag the connection indicator
	*/
	void setConnected(bool connectFlag);
	/**
	* @return the connection state
	*/
	bool isConnected() const;
	/**
	* obtain the connection description
	* @return the connection description
	*/
	AAAConnectionDescription&       getDescription();
    void                            reloadDescription();
    void                            freeDescription();          /* PMSTA-26427 - 240217 - PMO */

    const AAAConnectionState&   getState() const;
    void                        setState(const AAAConnectionState& state);
    std::string                 getStateLabel() const;
    static std::string          getStateLabel(const AAAConnectionState &);

	friend std::ostream& operator<<(std::ostream& os, const AAAConnection& obj);


	virtual void clean() = 0;


	virtual std::string getConnectionCharset()=0;

    virtual RET_CODE setApplSession(DBA_DYNFLD_STP applSessionStp) = 0;
    virtual RET_CODE setAppContext(const std::string &propertyName, ID_T propertyValueId) = 0;
    virtual RET_CODE setLanguageDictId(DICT_T propertyValueId) = 0;

    virtual RET_CODE setAppContextProperty(const std::string &propertyName, const std::string &propertyValue) = 0;
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, ID_T valueId) = 0;
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, ENUM_T valueEn) = 0;
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName, INT_T  valueInt) = 0;
    virtual RET_CODE setPropertyByStoredProc(const std::string &storedProcSqlName) = 0;

    void updatePassword(const PasswordEncrypted& password);
	virtual bool changePassword(const PasswordEncrypted& password) = 0;
	virtual bool changePassword(const  std::string& user, const PasswordEncrypted& password) = 0;

    void setThreadId();
    void resetThreadId();
    TID_T getThreadId();

    void assertThreadConnectionCoherence();

    bool mustCreateTempTables();

    virtual void enableOutput() = 0;
    virtual void disableOutput() = 0;
    virtual RET_CODE setConnMaxRows(int) = 0;   /* DLA - PMSTA-26898 - 170426 */

    virtual int getTransState() = 0;

    const std::string& getActualDbName() const;
    void setDbName(const std::string& dbName);

    virtual RET_CODE         setDefaultProperties();
    void                     setSessionProperties(const SessionProperties &sessionProperties);
    const SessionProperties &getConnSessionProperties() const;
    SessionProperties       &getTargetSessionProperties();
    RET_CODE                 applyPropertiesOnConnection();
    RET_CODE                 removePropertiesOnConnection();

    int statmentAllocatedNb;
    std::string callStack;

    int                      m_usedConnectionNbr;
    unsigned int             m_tempTablesMask;

    std::string              stackWhenConnCreated;
    std::vector<std::string> stackWhenUsed;

#ifdef _DEBUG
    Lock lock;
#endif

protected:

    virtual void            pushSqlRequest(KindOfRequest) = 0;
    virtual void            popSqlRequest(KindOfRequest = KindOfRequest::Default) = 0;

    virtual bool            useDb(const std::string&) = 0;
    virtual void            setDateTimeFormat(DATE_STYLE_ENUM) = 0;
    SessionProperties       &getConnSessionPropertiesForUpd();

    bool                    m_onApplySessionProperties;  /* PMSTA-nuodb - LJE - 190613 */

private :

    /**
	* the pool owing the connection
	*/
	AAAConnectionPool *owningPool;
    /**
    * the local provider owing the connection
    */
    AAALocalConnectionProvider *owningLocalProvider;
    /**
	* the connection specification
	*/
	AAAConnectionSpecification specification;
	/**
	* the state of the connection (in use or available)
	*/
	AAAConnectionState state;
	/**
	* time in  since epoch when the connection has been created
	*/
	time_t connectionTime;
    /**
    * time in  since epoch when the connection has been released
    */
    time_t IdleTime;
    /**
    * time in  since epoch when the connection has started a proc
    */
    time_t startProcTime;
    /**
	* the connection identifier
	*/
	mutable int id;                 /* PMSTA-22990 - 080416 - PMO */
	/**
	* indicate if the connection is connected or not
	*/
	bool connected;
	/**
	* connection description (cached inside the connection)
	*/
	AAAConnectionDescription* connectionDescription;

    TID_T threadId;

    bool isValidConnection;

    SessionProperties m_connSessionProperties;
    SessionProperties m_targetSessionProperties;
};

class AAAConnectionStatus
{
public:

    /*Constructor
     * @param spec the connection specification
     * @param id the connection identifier
     */
    AAAConnectionStatus(const AAAConnectionSpecification& spec);

    AAAConnectionStatus & operator=(const AAAConnectionStatus &);      /* PMSTA-24076 - 180716 - PMO */

    void setCallStack(const bool &);        // Allow to display the callstack
    void setThreadId (TID_T);               // Define the thread id
    void setSessionCd(const std::string &); // Define the session code

    AAAConnectionSpecification spec;
    int id;
    AAAConnectionState state;
    bool connected;
    TID_T threadId;
    std::string chasetNameName;
    time_t connectionTime;
    time_t currentProcTime;
    time_t idleTime;
    std::string m_callStackStr;
    std::string sessionCd;

    friend std::ostream& operator<<(std::ostream& os, const AAAConnectionStatus& obj);

    private:
        bool m_callStack;
};

class AAAConnectionStatusParam
{
public:
    AAAConnectionStatusParam() : onlyUsedConnection(false), onlyFreeConnection(false){}
    bool onlyUsedConnection;
    bool onlyFreeConnection;
};

#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionPoolConfiguration_H_
#define  AAAConnectionPoolConfiguration_H_
#include <conpolicies.h>
#include "password.h"
#include <iostream>

class  AAAConnectionPoolConfiguration
{
public:

	AAAConnectionPoolConfiguration(const  AAAConnectionDescription& description,
		const int& maxsize,
        const int& minsize,
		const PasswordEncrypted& password, 
		const  AAAConnectionPolicies& policies);

	AAAConnectionPoolConfiguration(const  AAAConnectionPoolConfiguration& toCopy);
	~AAAConnectionPoolConfiguration(void);

    AAAConnectionPoolConfiguration & operator=(const AAAConnectionPoolConfiguration &) = delete;    /* PMSTA-24076 - 180716 - PMO */

	const int& getMaxsize() const;
    const int& getMinsize() const;
	const  AAAConnectionDescription& getDescription() const;
	const PasswordEncrypted & getPassword()  const;
	const std::string & getProperty() const;
	const  AAAConnectionPolicies& getPolicies() const;
	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolConfiguration& obj);

private:
	AAAConnectionDescription description;
	int maxSize;
    int minSize;
	PasswordEncrypted password;
	AAAConnectionPolicies policies;
};
#endif

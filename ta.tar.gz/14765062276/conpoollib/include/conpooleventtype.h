/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef ConnectionPoolEventType_H__
#define ConnectionPoolEventType_H__
enum  AAAConnectionPoolEventType 
{
	ConnectionCreated,
	ConnectionDeleted,
	ConnectionTaken,
	ConnectionReleased,
	ConnectionConnected,
	ConnectionDisconnected,
    ConnectionReleaseError,
    ConnectionPoolEventLast
};
#endif

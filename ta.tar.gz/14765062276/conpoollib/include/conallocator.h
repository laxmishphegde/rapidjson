/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionAllocator_H__
#define  AAAConnectionAllocator_H__

#include <string>

#include "contype.h"

class  DbiConnection;
class  AAAConnection;
class  AAAConnectionSpecification;
/**
* prototype of connection allocator function pointer.
* Allocation of connection is not expected to throw exception, in case of error returned connection pointer is expected
* to be  null.
* Note that this allocator is dedicated to allocate a connection object, the connection with sub system is not performed
*  at this stage.
* @param spec the connection specification
* @param spec the identifier of the connection
* @return the newly allocated connection. Null if allocation failed
*/
typedef  AAAConnection* (AAACONNECTION_ALLOCATOR_FUNCT) (const  AAAConnectionSpecification& spec, const int& id);
using AAACONNECTION_ALLOCATOR_FPTR = AAACONNECTION_ALLOCATOR_FUNCT* ;
/**
* describe the identity of an connection allocator where an allocator is identified by
* <ul>
*	<li> the connection type </li>
*   <li> the connection model </li>
* </ul>
*/
class AAAConnectionAllocatorKey  {
public:
	/**
	* Semantic constructor.
	* @param type the type of the connection
	* @param mode the model of the connection
	*/
	AAAConnectionAllocatorKey(const  AAAConnectionType& type, const  DBA_RDBMS_ENUM& model);
	/**
	* Copy Constructor
	* @param toCopy the allocator key to copy into the new object.
	*/
	AAAConnectionAllocatorKey(const AAAConnectionAllocatorKey& toCopy);
	/**
	* Assignment operator.
	* @param toCopy the allocator key to copy into the operand.
	*/
	void operator=(const AAAConnectionAllocatorKey& toCopy);
	/**
	* Equality operator.
	* Two key are considered equals if model and type are equals.
	* @param toCompare object to compare with operand.
	*/
	bool operator==(const AAAConnectionAllocatorKey& toCompare) const;
	/**
	* @return the connection type
	*/
	const  AAAConnectionType&  getType() const;
	/**
	* @return the connection model
	*/
	const  DBA_RDBMS_ENUM& getModel()  const;


	/**
	* less operator (since used as key in map)
	*/
	bool operator <(const AAAConnectionAllocatorKey& toCompare) const;
private:
	/**
	* the connection type
	*/
	AAAConnectionType  type;
	/**
	* the connection model
	*/
	DBA_RDBMS_ENUM model;
};


/**
* Connection allocator is the class in charge to create a connection for a given connection type and model.
*/
class AAAConnectionAllocator {

public:
	/**
	* Semantic constructor.
	* @param type the connection type
	* @param model the connection model
	* @param allocatorPtr the pointer on the  allocation function
	*/
	AAAConnectionAllocator(const  AAAConnectionType& type, const  DBA_RDBMS_ENUM& model, AAACONNECTION_ALLOCATOR_FPTR allocatorPtr);
	/**
	* Copy constructor.
	* @param toCopy the allocator  to copy into the new object.
	*/
	AAAConnectionAllocator(const  AAAConnectionAllocator& toCopy);
	/**
	* Assignment operator.
	* @param toCopy the allocator  to copy into the operand.
	*/
	void operator=(const  AAAConnectionAllocator& toCopy);
	/**
	* @return the connection type the allocator is dedicated for
	*/
	const  AAAConnectionType&  getType() const;
	/**
	* @return the connection model the allocator is dedicated for
	*/
	const  DBA_RDBMS_ENUM& getModel()  const;
	/**
	* @return the allocator key
	*/
	const  AAAConnectionAllocatorKey& getKey() const;
	/**
	* Create a connection.
	* @param spec the connection specification
	* @param id   the connection identifier
	* @return the new connection, null if connection creation failed
	*/
	AAAConnection* createConnection(const  AAAConnectionSpecification& spec, const int& id);


private:
	/**
	* pointer on the connection allocator
	*/
	AAACONNECTION_ALLOCATOR_FPTR alloFunc;
	/**
	* the allocator key
	*/
	AAAConnectionAllocatorKey key;
};

#endif

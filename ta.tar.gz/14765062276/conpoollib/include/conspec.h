/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef  AAAConnectionSpecification_H_
#define  AAAConnectionSpecification_H_
#include "contype.h"
#include "concredentials.h"
#include "conpolicies.h"
#include "conrole.h"

class otstream;

class  AAAConnectionSpecification
{
public:
	AAAConnectionSpecification(const  AAAConnectionRole& role, 
                               const  AAAConnectionType& type, 
                               const  DBA_RDBMS_ENUM& model, 
                               const  AAAConnectionCredentials& credential, 
                               std::string serverName,
                               const  AAAConnectionPolicies& connectionPolicies,
                               std::string serverUrl = "");
	AAAConnectionSpecification(const  AAAConnectionSpecification& toCopy);
	~AAAConnectionSpecification(void);

	void operator= (const AAAConnectionSpecification& toCopy) ;
	
	const  AAAConnectionType& getType() const;
    const  std::string& getTypeName() const;
	const  DBA_RDBMS_ENUM& getModel() const;
    const std::string& getModelName() const;
 	const  AAAConnectionRole& getRole() const;
    const std::string& getRoleName() const;
	const  AAAConnectionCredentials& getCredentials() const;
	const  std::string& getServerName() const;
	const  AAAConnectionPolicies& getConnectionPolicies() const;
	const  std::string& getPoolAlias()const;
	friend std::ostream& operator<<(std::ostream& os, const AAAConnectionSpecification& obj);
	void   updatePassword(const PasswordEncrypted& password);

    const  std::string& getServerUrl()const;
    void                setServerUrl(const  std::string &);

private:
	
	AAAConnectionCredentials credentials;
	AAAConnectionType  type;
	DBA_RDBMS_ENUM model;
	AAAConnectionRole role;
	std::string serverName ;
	AAAConnectionPolicies connectionPolicies;
    std::string serverUrl;

};
#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <conpoolappctx.h>

AAAConpoolAppCtx::AAAConpoolAppCtx(AAATypeAppCtxEnum type, std::string name, std::string value){
	_type	 = type;
	_ctxName = name;
	_value	 = value;
}
AAATypeAppCtxEnum AAAConpoolAppCtx::getType() const{
	return _type;
}

std::string AAAConpoolAppCtx::getCtxName() const {
	return _ctxName;
}
std::string AAAConpoolAppCtx::getValue() const{
	return _value;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <iostream>
#include <sstream>

#include "unidef.h"
#include "conexcept.h"
#include "callstack.h"

/*************************************************************************
*   Function            :   AAAPoolUsageException::AAAPoolUsageException
*
*   Description         :   Constructor. Take the callstack where the exception is raised
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   
*
*   Last Modif          :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
AAAPoolUsageException::AAAPoolUsageException(const std::string& error) 
                                                                     : std::logic_error(error)
                                                                     , m_callstack(SYS_GetCallStack())   /* PMSTA-21907 - 281215 - PMO */
{
}

AAAPoolUsageException::~AAAPoolUsageException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}

/*************************************************************************
*   Function            :   AAAPoolUsageException::getCallStack
*
*   Description         :   Return the callstack where the exception is raised
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
std::string AAAPoolUsageException::getCallStack()
{
    return m_callstack;
}




AAAInvalidPoolDescriptionException::AAAInvalidPoolDescriptionException(const std::string&  error, const AAAConnectionDescription& desc) 
                                                                                                                                      : AAAPoolUsageException(error) 
                                                                                                                                      , desc(desc)
{
}

AAAInvalidPoolDescriptionException::~AAAInvalidPoolDescriptionException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}

const AAAConnectionDescription& AAAInvalidPoolDescriptionException::getPoolDescription() const 
{ 
	return desc; 
}


/*************************************************************************
*   Function            :   AAAInvalidPoolDescriptionException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAInvalidPoolDescriptionException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << desc;

        m_whatExplanation += ", ";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}


AAAInvalidConnectionAliasException::AAAInvalidConnectionAliasException(const std::string&  error, const std::string& alias)
	                                                                                                                      : AAAPoolUsageException(error)
                                                                                                                          , alias(alias)
{ 
}


AAAInvalidConnectionAliasException::~AAAInvalidConnectionAliasException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const std::string & AAAInvalidConnectionAliasException::getConnectionAlias() const 
{
	return alias; 
}


/*************************************************************************
*   Function            :   AAAInvalidConnectionAliasException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAInvalidConnectionAliasException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << alias;

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}


AAAMaximumPoolCapacityReachedException::AAAMaximumPoolCapacityReachedException(const std::string&  error, const AAAConnectionDescription& desc, const int maxSize)
                                                                                                                                                                 : AAAPoolUsageException(error)
                                                                                                                                                                 , desc(desc)
                                                                                                                                                                 , maxSize(maxSize)
{
}


AAAMaximumPoolCapacityReachedException::~AAAMaximumPoolCapacityReachedException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const AAAConnectionDescription& AAAMaximumPoolCapacityReachedException::getPoolDescription() const 
{
	return desc;
}


const int & AAAMaximumPoolCapacityReachedException::getMaxSize() const 
{
	return maxSize;
}


/*************************************************************************
*   Function            :   AAAMaximumPoolCapacityReachedException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAMaximumPoolCapacityReachedException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << " " << desc << ", max:" << getMaxSize();

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}


AAAInvalidConnectionStateException::AAAInvalidConnectionStateException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId) 
                                                                                                                                                              : AAAPoolUsageException(error)
                                                                                                                                                              , desc(desc)
                                                                                                                                                              , connectionId(connectionId)
{
}


AAAInvalidConnectionStateException::~AAAInvalidConnectionStateException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const AAAConnectionDescription& AAAInvalidConnectionStateException::getPoolDescription() const 
{
    return desc;
}


const int& AAAInvalidConnectionStateException::getConnectionId() const
{
    return connectionId;
}


/*************************************************************************
*   Function            :   AAAInvalidConnectionStateException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAInvalidConnectionStateException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << " " << desc << ", connectionId:" << getConnectionId();

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}



AAAInvalidConnectionIdentifierException::AAAInvalidConnectionIdentifierException(const std::string&  error,  const int& id)
                                                                                                                          : AAAPoolUsageException(error), id(id)
{
}


AAAInvalidConnectionIdentifierException::~AAAInvalidConnectionIdentifierException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const int & AAAInvalidConnectionIdentifierException::getConnectionId() const
{
	return id;
}


/*************************************************************************
*   Function            :   AAAInvalidConnectionIdentifierException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAInvalidConnectionIdentifierException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << id;

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}




AAACannotConnectException::AAACannotConnectException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId)
                                                                                                                                            : AAAPoolUsageException(error)
                                                                                                                                            , desc(desc)
                                                                                                                                            , connectionId(connectionId)
{
}


AAACannotConnectException::~AAACannotConnectException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const AAAConnectionDescription& AAACannotConnectException::getConnectionDescription() const
{
    return desc;
}


const int& AAACannotConnectException::getConnectionId() const
{
    return connectionId;
}


/*************************************************************************
*   Function            :   AAAInvalidConnectionIdentifierException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char* AAACannotConnectException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << " " << desc << ", connectionId:" << getConnectionId();

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}


/*************************************************************************
*   Function            :   AAACannotConnectDbException::AAACannotConnectDbException
*
*   Description         :   Constructor
*
*   Arguments           :   
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   
*
*   Last Modif          :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
AAACannotConnectDbException::AAACannotConnectDbException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId)
                                                                                                                                                : AAACannotConnectException(error, desc, connectionId)
{
}


AAACannotConnectDbException::~AAACannotConnectDbException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}

AAAInvalidConnectionPropertiesException::AAAInvalidConnectionPropertiesException(const std::string&  error, const AAAConnectionDescription& desc, const int connectionId)
    : AAAPoolUsageException(error)
    , desc(desc)
    , connectionId(connectionId)
{
}


AAAInvalidConnectionPropertiesException::~AAAInvalidConnectionPropertiesException() throw ()                                                 /* PMSTA-21907 - 281215 - PMO */
{
}


const AAAConnectionDescription& AAAInvalidConnectionPropertiesException::getPoolDescription() const
{
    return desc;
}


const int& AAAInvalidConnectionPropertiesException::getConnectionId() const
{
    return connectionId;
}


/*************************************************************************
*   Function            :   AAAInvalidConnectionStateException::what
*
*   Description         :   Return what exception information
*
*   Arguments           :   None
*
*   Functions call      :
*
*   Return              :   None
*
*   Creation Date       :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*   Last Modif          :
*
*************************************************************************/
const char * AAAInvalidConnectionPropertiesException::what() const throw ()
{
    m_whatExplanation = std::logic_error::what();

    {
        std::ostringstream txt;
        txt << " " << desc << ", connectionId:" << getConnectionId();

        m_whatExplanation += ":";
        m_whatExplanation += txt.str();
    }

    return m_whatExplanation.c_str();
}

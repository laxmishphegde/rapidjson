/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"
#include "aaaconnection.h"
#include "conpool.h"
#include "conpoolevent.h"
#include "conpoolobserver.h"
#include "conexcept.h"
#include "contype.h"
#include <functional>
#include <sstream>
#include <string>
#include <iterator>
#include "conpoolappctx.h"
#include "syslib.h"
#include "dba.h"
#include "callstack.h"
#include "conprovider.h"

/************************************************************************
**      Static definitions & data
*************************************************************************/
static AtomicInt    SV_TotalConnection;     /* Atomic counter of how much connection exists   / PMSTA-24510 - 220816 - PMO */
AtomicInt           SV_NbUsedConnection;    /* Atomic counter of how much connection are used / PMSTA-24510 - 220816 - PMO */

/************************************************************************
*   Function             :  CON_GetNbUsedConnection()
*
*   Description          :  Return how much connection are used
*
*   Arguments            :  None
*
*   Return               :  How much connection are used
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
int CON_GetNbUsedConnection()
{
    return SV_NbUsedConnection.load();
}


/************************************************************************
*   Function             :  CON_GetTotalConnection()
*
*   Description          :  Return how much connection are created
*
*   Arguments            :  None
*
*   Return               :  How much connection are created
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
int CON_GetTotalConnection()
{
    return SV_TotalConnection.load();
}


/************************************************************************
*   Function             :  AAAConnectionPool::AAAConnectionPool()
*
*   Description          :  Constructor
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-24963 - 051016 - PMO : Fusion not running after installing TA 21.0.01
*
*************************************************************************/
AAAConnectionPool::AAAConnectionPool(const  AAAConnectionSpecification& spec, const AAAConnectionAllocator& allocator, const int& minSize, const int& maxSize, const  int& startId, int& maxId) : maxSize(maxSize)
                                                                                                                                                                                                , minSize(minSize)
	                                                                                                                                                                                            , startId(startId)
	                                                                                                                                                                                            , endId(startId + maxSize - 1)
                                                                                                                                                                                                , refToPool(0) /* DLA - PMSTA-24234 - 160803 */
                                                                                                                                                                                                , nbConnectionConnected(0)
                                                                                                                                                                                                , m_specification(spec)
                                                                                                                                                                                                , m_observer(nullptr)     /* PMSTA-24963 - 051016 - PMO */
                                                                                                                                                                                                , allocator(allocator)
                                                                                                                                                                                                , appCtx(nullptr)       /* PMSTA-24963 - 051016 - PMO */
{
	maxId = endId;
}
bool AAAConnectionPool::containsId(const int& id)
{
    return id >= startId && id <= endId;
}
const int &AAAConnectionPool::getEndId() const
{
    return this->endId;
}
const int &AAAConnectionPool::getStartId() const
{
    return this->startId;
}
const int& AAAConnectionPool::getMaxSize() const
{
    return maxSize;
}
const int& AAAConnectionPool::getMinSize() const
{
    return minSize;
}
int AAAConnectionPool::getConnectionCount() const
{
    return (int)(availableConnections.size()) + (int)(usedConnections.size());
}
int AAAConnectionPool::getUsedConnectionCount() const
{
    return (int)usedConnections.size();
}
int AAAConnectionPool::getAvaibleConnectionCount()  const
{
    return (int) availableConnections.size();
}
int AAAConnectionPool::getRemainingAllocableConnectionCount() const
{
    return maxSize - getConnectionCount();
}
int AAAConnectionPool::getConnectedConnectionCount() const
{
    return nbConnectionConnected;
}
void AAAConnectionPool::setObserver(AAAConnectionPoolObserver * observer)
{
    this->m_observer = observer;
}
AAAConnectionPool::~AAAConnectionPool(void)
{
    LockGuard guard(this->m_lock);

    auto it = this->availableConnections.begin();
    while (it != this->availableConnections.end())
    {
        int id = (*it)->getId();
        delete ((*it));
        this->publishEvent(AAAConnectionPoolEventType::ConnectionDeleted, id, true);

        it = this->availableConnections.begin();
	}

    it = this->usedConnections.begin();
    while (it != this->usedConnections.end())
    {
        int id = (*it)->getId();
        delete ((*it));
        this->publishEvent(AAAConnectionPoolEventType::ConnectionDeleted, id, true);

        it = this->usedConnections.begin();
	}

    it = this->allConnections.begin();
    while (it != this->allConnections.end())
    {
        int id = (*it)->getId();
        delete ((*it));
        this->publishEvent(AAAConnectionPoolEventType::ConnectionDeleted, id, true);
    }
}

/************************************************************************
*   Function             :  AAAConnectionPool::getConnection()
*
*   Description          :
*
*   Arguments            :  id
*
*   Return               :  DbiConnection
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnection* AAAConnectionPool::getConnection(const int& id)
{
    DbiConnection* dbiConnPtr = nullptr;
    LockGuard guard(m_lock);

    for (auto it = this->usedConnections.begin(); it != this->usedConnections.end(); ++it)
	{
		if((*it)->matchId(id))
        {
            dbiConnPtr = *it;
			break ;
		}
	}

	if (dbiConnPtr == nullptr)
    {
		throw AAAInvalidConnectionIdentifierException("no connection used for identifier", id);
	}

    return dbiConnPtr;
}

/************************************************************************
*   Function             :  AAAConnectionPool::getConnection()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
DbiConnection* AAAConnectionPool::getConnection()
{
    enum class ConnectionUsage {Initialization, Existing, New, Reconnect};

    DbiConnection*  dbiConnPtr       = nullptr;
    ConnectionUsage connectionUsage  = ConnectionUsage::Initialization;

    {
        LockGuard lockGuard(m_lock);

        if (this->availableConnections.empty() == false)
        {
            DbiConnection*  lastDbiConnPtr = nullptr;

            /* 1rst search for a connected DbiConnection*/ /* DLA - PMSTA-24911 - 161012 */
            for (auto x = this->availableConnections.begin(); dbiConnPtr == nullptr && x != this->availableConnections.end(); ++x)
            {
                if ((*x)->isConnected() == true)
                {
                    dbiConnPtr = (*x);
                }
                else
                {
                    lastDbiConnPtr = (*x);
                }
            }

            if (dbiConnPtr == nullptr)
            {
                dbiConnPtr = lastDbiConnPtr;
            }
        }
        else
        {
            dbiConnPtr = this->createConnection();
            this->availableConnections.insert(dbiConnPtr);
            connectionUsage = ConnectionUsage::New;
        }
        this->use(dbiConnPtr);
    }

    auto bConnected = true;
    if (ConnectionUsage::New == connectionUsage && nullptr != dbiConnPtr && this->m_specification.getConnectionPolicies().getConnectionPolicy() == ConnectAtCreate)
    {
        bConnected = this->connect(*dbiConnPtr);
    }

    if (ConnectionUsage::Initialization == connectionUsage &&
        (this->m_specification.getConnectionPolicies().getConnectionPolicy() != ConnectAtCreate ||
         this->m_specification.getConnectionPolicies().getDisconnectionPolicy() == DisconnectAtRelease ||
         this->m_specification.getConnectionPolicies().getDisconnectionPolicy() == DisconnectAtUnusedConnTimeout))
    {
        if ((bConnected = dbiConnPtr->isConnected()) == false)
        {
            if (this->m_specification.getConnectionPolicies().getConnectionPolicy() != ConnectAtUse)
            {
                bConnected = this->connect(*dbiConnPtr);
            }
            connectionUsage = ConnectionUsage::New;                                                 /* PMSTA-30415 - 090318 - PMO */
        }
        else
        {
            if (this->m_specification.getConnectionPolicies().getAgingPolicy() == Aging &&
                dbiConnPtr->isExpired(this->m_specification.getConnectionPolicies().getMaxAge()))
            {
                bConnected = this->reconnect(*dbiConnPtr);
                connectionUsage = ConnectionUsage::Reconnect;                                       /* PMSTA-30415 - 090318 - PMO */
            }
        }
    }

    if (bConnected == false || dbiConnPtr->isConnected() == false)
    {
        this->release(dbiConnPtr);
        throw AAACannotConnectException("Connection error for user " + dbiConnPtr->getDescription().getUser() + " to server " + dbiConnPtr->getDescription().getServerName(),
                                        dbiConnPtr->getDescription(),
                                        0);
    }

    return dbiConnPtr;
}

/************************************************************************
*   Function             :  AAAConnectionPool::createConnection()
*
*   Description          :
*
*   Arguments            :  DbiConnection*
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnection* AAAConnectionPool::createConnection()
{
    DbiConnection* res = nullptr ;
    bool idFound = false;
    unsigned long newId = 0;
	if (this->getConnectionCount() < this->maxSize)
    {
        for (int i = this->startId; i <= this->endId; i++)
        {
            idFound = false;
            for (auto s = this->availableConnections.begin(), e = this->availableConnections.end(); s != e; ++s)
            {
                if ((*s)->getId() == i)
                {
                    idFound = true;
                    break;
                }
            }
            if (idFound == false)
            {
                for (auto s = this->usedConnections.begin(), e = this->usedConnections.end(); s != e; ++s)
                {
                    if ((*s)->getId() == i)
                    {
                        idFound = true;
                        break;
                    }
                }
            }

            if (idFound == false)
            {
                newId = i;
                break;
            }
        }

        if (newId == 0)
        {
            std::stringstream ss;
            std::vector<AAAConnectionStatus>  listConnStatus = AAALocalConnectionProvider::get().getAllConnectionsStatus();
            for (std::vector<AAAConnectionStatus>::iterator x = listConnStatus.begin(); x != listConnStatus.end(); ++x)
            {
                ss << *x << std::endl;
            }

            throw AAAMaximumPoolCapacityReachedException("Unable to find a free connection Id\n" + ss.str(),
                AAAConnectionDescription(this->m_specification),
                this->maxSize);
        }
        res = this->createConnection(newId);
		res->setOwningPool(this) ;
	}
	else
    {
        std::stringstream ss;
        std::vector<AAAConnectionStatus>  listConnStatus = AAALocalConnectionProvider::get().getAllConnectionsStatus();
        for (std::vector<AAAConnectionStatus>::iterator x = listConnStatus.begin(); x != listConnStatus.end(); ++x)
        {
            ss << *x << std::endl;
        }

		throw AAAMaximumPoolCapacityReachedException("max number of connection reached" + ss.str(),
            AAAConnectionDescription(this->m_specification),
			this->maxSize);
	}
	return res ;
}

/************************************************************************
*   Function             :  AAAConnectionPool::release()
*
*   Description          :  Release a given connection in the pool
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
void AAAConnectionPool::release(DbiConnection* connection)
{
    LockGuard guard(m_lock);

	bool foundAsused = false ;
    auto objToErase = this->usedConnections.begin();

    while (objToErase != this->usedConnections.end())
    {
        if (*objToErase == connection)
        {
			foundAsused = true ;
			break ;
		}
        ++objToErase;
	}

	if (foundAsused == true)
    {
		if ((this->m_specification.getConnectionPolicies().getDisconnectionPolicy() == DisconnectAtRelease) &&
			connection->isConnected())
		{
            this->disconnect(*connection);
		}

        this->usedConnections.erase(objToErase);
        connection->clean();
        if (connection->getOwingLocalProvider() == nullptr)
        {
            this->availableConnections.insert(connection);
        }
        else
        {
            SYS_BreakOnDebug();
        }
        connection->setState(AAAConnectionState::AVAILABLE);
        connection->resetIdleTime();

        if (this->allConnections.size() != this->usedConnections.size() + this->availableConnections.size())
        {
            SYS_BreakOnDebug();
        }
        this->publishEvent(AAAConnectionPoolEventType::ConnectionReleased, connection->getId(), foundAsused);
	}
    else
    {
        SYS_BreakOnDebug();
    }
}

/************************************************************************
*   Function             :  AAAConnectionPool::remove()
*
*   Description          :  Release a given connection in the pool
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-41612 - LJE - 201006
*
*************************************************************************/
void AAAConnectionPool::remove(DbiConnection* connection)
{
    LockGuard guard(m_lock);

    this->availableConnections.erase(connection);
    this->usedConnections.erase(connection);

    this->allConnections.erase(connection);
}

/************************************************************************
*   Function             :  AAAConnectionPool::use()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
void AAAConnectionPool::use(DbiConnection* connection)
{
    LockGuard guard(m_lock);
    
    bool foundAsavailable = false ;

    for (auto s = this->availableConnections.begin(), e = this->availableConnections.end(); s != e; ++s)
    {
        if (*s == connection)
        {
            this->availableConnections.erase(s);
            foundAsavailable = true;
            this->usedConnections.insert(connection);
            connection->setState(AAAConnectionState::IN_USE);
            connection->setThreadId();

            if (this->m_observer != nullptr && this->m_observer->detail == ObserverDetailEn::high )
            {
                connection->callStack = SYS_GetCallStack(1);
            }
            break ;
        }
    }

    publishEvent(AAAConnectionPoolEventType::ConnectionTaken, connection->getId(), foundAsavailable);
}

/************************************************************************
*   Function             :  AAAConnectionPool::createConnection()
*
*   Description          :
*
*   Arguments            :  id of connection
*
*   Return               :  None
*
*   Creation Date        :
*
*
*************************************************************************/
DbiConnection* AAAConnectionPool::createConnection(unsigned  long& id)
{
    AAAConnection* connectionCreated  = this->allocator.createConnection(this->m_specification, id);

    DbiConnection* res = dynamic_cast <DbiConnection*> (connectionCreated);

    LockGuard guard(m_lock);
    this->allConnections.insert(res);
	publishEvent(AAAConnectionPoolEventType::ConnectionCreated, id, res != nullptr);
	return res;
}

/************************************************************************
*   Function            :   AAAConnectionPool::connect()
*
*   Description         :
*
*   Arguments           :   connection
*
*   Return              :   boolean connected or not
*
*   Creation Date       :
*
*   Last modif.         :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
bool AAAConnectionPool::connect(DbiConnection& connection)
{
    bool res = false;
    try
    {
        res = connection.connect();
    }
    catch (AAACannotConnectDbException& e)
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                        /* PMSTA-21907 - 281215 - PMO */
        res = false;
    }

    /* PMSTA-24510 - 220816 - PMO */
    if (true == res)
    {
        connection.setConnected(res);
        connection.setValidConnection(res);
        this->publishEvent(AAAConnectionPoolEventType::ConnectionConnected, connection.getId(), res);

        nbConnectionConnected++;
        SV_TotalConnection.fetch_add(1);
    }

	return res;
}

/************************************************************************
*   Function             :  AAAConnectionPool::disconnect()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :
*
*   Creation Date        :
*
*   Last modif.          : PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
void AAAConnectionPool::disconnect(DbiConnection& connection)
{
    const bool res = connection.disconnect();

    publishEvent(AAAConnectionPoolEventType::ConnectionDisconnected, connection.getId(), res);

    /* PMSTA-24510 - 220816 - PMO */
    if (true == res)
    {
        nbConnectionConnected--;
        SV_TotalConnection.fetch_sub(1);
    }
}

/************************************************************************
*   Function            :   AAAConnectionPool::reconnect()
*
*   Description         :
*
*   Arguments           :   connection
*
*   Return              :   boolean connected or not
*
*   Creation Date       :
*
*   Last modif.         :   PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
bool AAAConnectionPool::reconnect(DbiConnection& connection)
{
    try
    {
        return connection.reconnect();
    }
    catch (AAACannotConnectDbException& e)
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                        /* PMSTA-21907 - 281215 - PMO */
        return false;
    }
}

/************************************************************************
*   Function             :  AAAConnectionPool::getStatus()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  connection status
*
*   Creation Date        :
*
*
************************************************************************/
AAAConnectionPoolStatus AAAConnectionPool::getStatus()const
{
	return AAAConnectionPoolStatus(AAAConnectionDescription(this->m_specification),
			                       getMaxSize(),
			                       getAvaibleConnectionCount(),
			                       getUsedConnectionCount(),
                                   startId);
}

void AAAConnectionPool::publishEvent(const AAAConnectionPoolEventType &eventType, const int& connectionId, const bool& success) const
{
	if (this->m_observer != nullptr)
    {
        AAAConnectionDescription desc(this->m_specification);
        this->m_observer->processEvent(AAAConnectionPoolEvent( eventType, desc, connectionId,
                                                       AAAConnectionPoolStatus(desc, getMaxSize(), getAvaibleConnectionCount(), getUsedConnectionCount(), startId), success));
	}
}

bool AAAConnectionPool::isCredentialIdentical(const char* username, const PasswordEncrypted& password) const
{
	
    const bool credentialIdentical = this->m_specification.getCredentials().match(username, password);
    
    return credentialIdentical;
}

DbiConnection* AAAConnectionPool::find(bool(*searchFunc)(DbiConnection&, void*), void* searchArg)
{
    DbiConnection* res = nullptr;
    LockGuard lockGuard(m_lock);

	//for (DbiConnection* con : this->usedConnections)
    for (auto con = this->usedConnections.begin(); con != this->usedConnections.end(); ++con)
    {
		if ((*searchFunc)(**con, searchArg))
        {
			res = *con;
			break;
		}
	}
    if (res == nullptr)
    {
        //for (DbiConnection* con : this->availableConnections)
        for (auto con = this->availableConnections.begin(); con != this->availableConnections.end(); ++con)
        {
            if ((*searchFunc)(**con, searchArg))
            {
                res = *con;
                break;
            }
        }
    }
	return res;
}

void AAAConnectionPool::updatePassword(const PasswordEncrypted& password)
{
    LockGuard guard(m_lock);

    this->m_specification.updatePassword(password); /* DLA - PMSTA-21596 - 160519 */

    for (auto con = this->availableConnections.begin(); con != this->availableConnections.end(); ++con)
    {
        (*con)->updatePassword(password);
	}
    for (auto con = this->usedConnections.begin(); con != this->usedConnections.end(); ++con)
    {
		(*con)->updatePassword(password);
	}
}

std::ostream& operator<<(std::ostream& os, const AAAConnectionPool& obj)
{
    LockGuard guard((Lock&)obj.m_lock);

    os << "POOL:" << std::endl;
    os << "    -" << obj.getStatus().getStringRep() << std::endl;
    os << "    CONNECTIONS:" << std::endl;
    //for (auto x : obj.availableConnections)
    for (auto x = obj.availableConnections.begin(); x != obj.availableConnections.end();++x)
    {
        os << "        -";
        os << *(*x) << std::endl;
    }

    //for (auto x : obj.usedConnections)
    for (auto x = obj.usedConnections.begin(); x != obj.usedConnections.end(); ++x)
    {
        os << "        -";
        os << *(*x) << std::endl;
    }
    return os;
}

STATIC void writeConnStatus(AAAConnectionStatus& stat, DbiConnection* conn)
{
    stat.id             = conn->getId();
    stat.chasetNameName = conn->getConnectionCharset();
    stat.state          = conn->getState();
    stat.connected      = conn->isConnected();
    stat.connectionTime = conn->getConnectionTime();
    stat.idleTime       = conn->getIdleTime() == 0 ? 0 : time(NULL) - conn->getIdleTime();
    stat.threadId       = conn->getThreadId();
    stat.sessionCd      = (conn->getConnSessionProperties().getApplSessionCd() == nullptr ? "" : conn->getConnSessionProperties().getApplSessionCd());
    stat.m_callStackStr = conn->callStack;
}

/************************************************************************
*   Function             :  AAAConnectionPool::getAllConnectionsStatus()
*
*   Description          :  Return a snapshot of all connections in the pool
*
*   Arguments            :
*
*   Return               :  A vector of connections
*
*************************************************************************/
std::vector<AAAConnectionStatus> AAAConnectionPool::getAllConnectionsStatus(const AAAConnectionStatusParam& param){
    std::vector<AAAConnectionStatus> listConnStatus;

    if (param.onlyUsedConnection == false)
    {
        for (auto x = availableConnections.begin(); x != availableConnections.end(); ++x)
        {
            AAAConnectionStatus stat((*x)->getSpecification());
            writeConnStatus(stat, *x);
            listConnStatus.push_back(stat);
        }
    }

    if (param.onlyFreeConnection == false)
    {
        for (auto x = usedConnections.begin(); x != usedConnections.end(); ++x)
        {
#ifdef _DEBUG
            LockGuard lock((*x)->lock);
#endif
            AAAConnectionStatus  stat((*x)->getSpecification());
            writeConnStatus(stat, *x);
            listConnStatus.push_back(stat);
        }
    }
    return listConnStatus;
}

AAAConnectionSpecification& AAAConnectionPool::getConnectionSpecification()
{
    return this->m_specification;
}

/************************************************************************
*   Function             :  AAAConnectionPool::ApplyPolicies()
*
*   Description          :  Apply the policies for Aging and idleTime
*
*   Arguments            :
*
*   Return               :  void
*
*   Creation date        : DLA - PMSTA-24911 - 161024
*
*************************************************************************/
void AAAConnectionPool::ApplyPolicies()
{
    bool res = false;
    LockGuard guard(m_lock);

    for (auto x = availableConnections.begin(); x != availableConnections.end(); ++x)
    {
        if (getConnectedConnectionCount() > getMinSize()) /* DLA - PMSTA-24911 - 161024 */
        {
            if ((*x)->isConnected() &&
                this->m_specification.getConnectionPolicies().getDisconnectionPolicy() == AAADisconnectionPolicy::DisconnectAtUnusedConnTimeout &&
                (*x)->isIdleTimeOut(this->m_specification.getConnectionPolicies().getMaxIdleTime()))
            {
                disconnect(*(*x));
            }
        }

        if ((*x)->isConnected() &&
            this->m_specification.getConnectionPolicies().getAgingPolicy() == AAAAgingPolicy::Aging &&
            (*x)->isExpired(this->m_specification.getConnectionPolicies().getMaxAge()))
        {
            res = reconnect(*(*x));
            if (!res)
            {
                int id = (*x)->getId();
                delete((*x));
                availableConnections.erase(x);
                publishEvent(AAAConnectionPoolEventType::ConnectionDeleted, id, res);
                SV_TotalConnection.fetch_sub(1);
            }
        }
    }
}

/************************************************************************
*   Function             :  AAAConnectionPool::incRef()
*
*   Description          :  A reference is added to this pool.
*                           !!! This method must be used only from the connectionProvider Class and locked before !!!
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  DLA - PMSTA-24234 - 160803
*
*
*************************************************************************/
void AAAConnectionPool::incRef()
{
    refToPool++;
}

/************************************************************************
*   Function             :  AAAConnectionPool::decRef()
*
*   Description          :  A reference is removed to this pool.
*                           !!! This method must be used only from the connectionProvider Class and locked before !!!
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  DLA - PMSTA-24234 - 160803
*
*
*************************************************************************/
void AAAConnectionPool::decRef()
{
    refToPool--;
}

/************************************************************************
*   Function             :  AAAConnectionPool::getRefNb()
*
*   Description          :  get the number of reference to this pool.
*                           !!! This method must be used only from the connectionProvider Class and locked before !!!
*   Arguments            :
*
*   Return               :   int reference number
*
*   Creation Date        :  DLA - PMSTA-24234 - 160803
*
*
*************************************************************************/
int AAAConnectionPool::getRefNb()
{
    return refToPool;
}


/************************************************************************
*   Function             :  AAAConnectionPool::getUrl()
*
*   Description          :  Return the URL of this pool
*
*   Arguments            :
*
*   Return               :  URL of this pool
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*
*************************************************************************/
std::string AAAConnectionPool::getUrl()
{
    return this->m_specification.getServerUrl();
}


/************************************************************************
*   Function             :  AAAConnectionPool::setUrl()
*
*   Description          :  Define the URL of this pool
*
*   Arguments            :  desc Connection description
*
*   Return               :
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*
*************************************************************************/
void AAAConnectionPool::setUrl(const AAAConnectionDescription& desc)
{
    this->m_specification.setServerUrl(desc.getUrl());
}


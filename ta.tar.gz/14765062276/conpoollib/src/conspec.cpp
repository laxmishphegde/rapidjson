/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"
#include "conspec.h"

AAAConnectionSpecification::AAAConnectionSpecification(const AAAConnectionRole& role, const AAAConnectionType& type, const DBA_RDBMS_ENUM& model, const AAAConnectionCredentials& credential, std::string serverName,
    const AAAConnectionPolicies& connectionPolicies, std::string serverUrl)
    : credentials(credential), connectionPolicies(connectionPolicies), serverUrl(serverUrl){
	this->type =  type ;
	this->model = model ;
	this->role = role;
	this->serverName = serverName;

}
AAAConnectionSpecification::AAAConnectionSpecification(const AAAConnectionSpecification& toCopy) : credentials(toCopy.getCredentials()), connectionPolicies(toCopy.getConnectionPolicies()) {
	this->type =  toCopy.getType() ;
	this->model = toCopy.getModel() ;
	this->role = toCopy.getRole();
    this->serverName = toCopy.getServerName();
    this->serverUrl = toCopy.getServerUrl();
}
void AAAConnectionSpecification::operator= (const AAAConnectionSpecification& toCopy) {
	this->type =  toCopy.getType() ;
	this->model = toCopy.getModel() ;
	this->role = toCopy.getRole();
	this->credentials =  toCopy.getCredentials();
    this->serverName = toCopy.getServerName();
	this->connectionPolicies = toCopy.getConnectionPolicies();
    this->serverUrl = toCopy.getServerUrl();
}
AAAConnectionSpecification::~AAAConnectionSpecification(void)
{
}

const std::string & AAAConnectionSpecification::getServerUrl() const
{
    return serverUrl;
}

/************************************************************************
*   Function             :  AAAConnectionSpecification::setServerUrl()
*
*   Description          :  Define the URL
*
*   Arguments            :  url
*
*   Return               :
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionSpecification::setServerUrl(const  std::string & url)
{
    serverUrl = url;
}




const AAAConnectionType&  AAAConnectionSpecification::getType() const	{return type ;}
const DBA_RDBMS_ENUM&  AAAConnectionSpecification::getModel() const {return model;}
const AAAConnectionRole&  AAAConnectionSpecification::getRole() const { return role; }
const AAAConnectionCredentials&  AAAConnectionSpecification::getCredentials() const {return credentials;}
const std::string& AAAConnectionSpecification::getServerName() const		{return serverName ;}
const AAAConnectionPolicies& AAAConnectionSpecification::getConnectionPolicies() const { return  connectionPolicies; }
void AAAConnectionSpecification::updatePassword(const PasswordEncrypted& password) { credentials.updatePassword(password); }

static std::string typeNameTab[] = {
        "NullServer",
        "SqlServer",
        "FinServer",
        "InternalProc",
		"DispatchServer"};

AAASTATIC_ASSERT(sizeof(typeNameTab) / sizeof(typeNameTab[0]) == LastServerType + 1);

extern DBA_RDBMS_ENUM EV_RdbmsVendor;

static std::string rdbmsNameTab[] = {
    "Sybase",
    "Oracle",
    "QtHttp",
    "NuoDB",
    "MSSql",
    "Sqlite",
    "PostgreSQL",
    "Unknown"};

AAASTATIC_ASSERT(sizeof(rdbmsNameTab) / sizeof(rdbmsNameTab[0]) == UnknownRdbms + 1);

static std::string roleNameTab[] = {
    "Init",
    "Admin",
    "User",
    "Security",
    "SSO",
    "ProxyUser" }; /* PMSTA-34344 - LJE - 201221 */

AAASTATIC_ASSERT(sizeof(roleNameTab) / sizeof(roleNameTab[0]) == LAST_ROLE);


const std::string& AAAConnectionSpecification::getTypeName() const
{
    return typeNameTab[this->type + 1];
}

const std::string& AAAConnectionSpecification::getModelName() const
{
    return rdbmsNameTab[this->model];
}

const std::string& AAAConnectionSpecification::getRoleName() const
{
    return roleNameTab[this->role];
}


std::ostream& operator<<(std::ostream& os, const AAAConnectionSpecification& obj) {
    os << "AAAConnectionSpecification["
        << "type=" << obj.getTypeName()
        << ",model=" << obj.getModelName()
        << ",role=" << obj.getRoleName()
		<< ",credentials=" <<  obj.getCredentials()
		<< ",property=" <<  obj.getServerName()
		<< ",policies=" <<  obj.getConnectionPolicies()
		<< "]";
	return os;
}

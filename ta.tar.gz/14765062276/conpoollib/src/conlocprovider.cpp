/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include <sstream>
#include <QString>

#include "unidef.h"

#include "aaaconnection.h"
#include "conlocprovider.h"
#include "conprovider.h"
#include "conexcept.h"
#include "syslib.h" /* this reference to Common in project properties->directories must be replaced with interop  */
#include "callstack.h"
#include "dba.h"
#include "dbabusec.h"
#include "conpoolstatus.h"
#include "dbacurr.hpp"

#include "httplib.h"        /* PMSTA-34344 - TEB - 190805 */

#ifdef NTWIN
#pragma warning (pop)
#endif

/* PMSTA-24079 - LJE - 160719 */
extern int EV_AAAInstallLevel;
extern int EV_TableAndObjectModifFlag;

bool EV_UseOneConnection = false;

/* DLA - PMSTA-25748 - 161220 */
localConnection::localConnection() : connectionPtr(nullptr)
{
}

/************************************************************************
*   Function             :  localConnection::~localConnection()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*   Last Modification    :
*
*************************************************************************/
localConnection::~localConnection()
{
    connectionPtr = nullptr;
}


/* DLA - PMSTA-25748 - 161230 */
bool localConnection::operator== (const localConnection& toCompare) const
{
    return	(this->connectionPtr == toCompare.connectionPtr);
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::get()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
AAALocalConnectionProvider& AAALocalConnectionProvider::get()
{
    ThreadDataCtxGeneric * pThreadDataCtxGeneric = SYS_GetThreadDataCtxGeneric();       /* PMSTA-19735 - 020415 - PMO */

    if (nullptr != pThreadDataCtxGeneric)
    {
        /**
        * create the provider if null
        */
        if (pThreadDataCtxGeneric->getLocalConnectionProvider() == nullptr)
        {
            pThreadDataCtxGeneric->setLocalConnectionProvider(new AAALocalConnectionProvider());
        }
    }
    else
    {
        SYS_BreakOnDebug();
    }

    return *pThreadDataCtxGeneric->getLocalConnectionProvider();
}

/************************************************************************
*   Function             :  AAAConnectionPool::getConnection()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
void AAALocalConnectionProvider::close(AAALocalConnectionProvider * & pLocalConnectionProvider) /* PMSTA-30415 - 090318 - PMO */
{
    delete pLocalConnectionProvider;
    pLocalConnectionProvider = nullptr;
}


/************************************************************************
*   Function             :  AAALocalConnectionProvider::AAALocalConnectionProvider()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
AAALocalConnectionProvider::AAALocalConnectionProvider()
{
    /**
    * erase all properties
    */
    this->m_usedConnectionsMap.clear();           /* PMSTA-30415 - 090318 - PMO */
    time(&this->lastCleanUp);
}


/************************************************************************
*   Function             :  AAAConnectionPool::~AAALocalConnectionProvider()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
AAALocalConnectionProvider::~AAALocalConnectionProvider()
{
    /**
    * reset the provider
    */
    this->reset();
    for (auto it = this->m_usedConnectionsMap.begin(); it != m_usedConnectionsMap.end(); ++it)
    {
        try
        {
            it->second->setOwningLocalProvider(nullptr);

            if (true == it->second->isInUse())                                                  /* PMSTA-19735 - 020415 - PMO */
            {
                AAAConnectionProvider::getConnectionProviderInstance().release(it->second);
            }
        }
        catch (AAAPoolUsageException &)
        {
            //do nothing since we're ending the local provider
        }
    }
}


/************************************************************************
*   Function             : AAALocalConnectionProvider::getConnection()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*                           PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
DbiConnection* AAALocalConnectionProvider::getConnection(const AAAConnectionDescription& desc)
{
    DbiConnection*  res = nullptr;
    bool            retrievedConnection = false;    /* Avoid duplicate count of used connection PMSTA-24510 - 220816 - PMO */

    /**
    * if there is a held preferred connection, that is not in use and correspond to the requested connection descriptor
    * => this is the connection that we provide
    */
    if (this->preferredConnections.size() > 0)
    {
        for (auto itConn = this->preferredConnections.begin(); res == nullptr && itConn != this->preferredConnections.end(); ++itConn)
        {
            if ((EV_UseOneConnection == true || (*itConn).connectionPtr->m_usedConnectionNbr == 0) && /* PMSTA-34402 - LJE - 190125 */
                (*itConn).connectionPtr->getDescription() == desc &&
                (*itConn).connectionPtr->isStatementInProgress() == false)
            {
                /* PMSTA-34402 - LJE - 190129 */
                res = (*itConn).connectionPtr;
                res->m_usedConnectionNbr++;
                res->setState(AAAConnectionState::IN_USE);
                res->setThreadId();
#ifdef AAACONNECTIONTRACE
                /* DLA - PMSTA-26448 - useful for connection leak (search pmsta to remove #if 0 if needed */
                res->stackWhenUsed.push_back(SYS_GetCallStack());
#endif
                break;
            }
        }
    }

    if (res == nullptr)
    {
        /**
        * we have to retrieve the connection in the central connection provider
        */
        res = AAAConnectionProvider::getConnectionProviderInstance().getConnection(desc);
        retrievedConnection = true;
#ifdef AAACONNECTIONTRACE
        /* DLA - PMSTA-26448 - useful for connection leak (search pmsta to remove #if 0 if needed */
        res->stackWhenConnCreated = SYS_GetCallStack();
#endif
    }

    /**
    * if there is no held preferred connection and
    * if there is no description defined for the preferred connection
    *    or the selected connection corresponds to the preferred connection descriptor
    *    and the connection is not used in substitution of the RealUser
    * we cache the selected connection as the preferred one
    */
    if (res != nullptr)
    {
        if (retrievedConnection == true)
        {
            res->m_usedConnectionNbr++;
#ifdef AAACONNECTIONTRACE
            /* DLA - PMSTA-26448 - useful for connection leak (search pmsta to remove #if 0 if needed */
            res->stackWhenUsed.push_back(SYS_GetCallStack()); 
#endif

            if (res->getSpecification().getConnectionPolicies().getDisconnectionPolicy() != AAADisconnectionPolicy::DisconnectAtRelease && /* DLA - PMSTA-24738 - 160913 - We don't cache a connection with DisconnectionPolicy = DisconnectAtRelease  */
                SYS_GetThreadUseServerUser() == false)
            {
                if (SYS_IsSrvMode() && SYS_IsThreadMain()) /* We don't cache the connection's main thread of the financial server, so they can be freed by the cleaning connections thread */
                {
                    this->m_usedConnectionsMap.insert(std::make_pair(res->getId(), res));  /* emplace is not implemented on AIX 13.1 compiler PMSTA-21500 - 161015 - PMO */
                }
                else
                {
                    localConnection aPreferredConnection;
                    aPreferredConnection.connectionPtr = res;
                    preferredConnections.push_back(aPreferredConnection);
                }
            }
            else
            {
                this->m_usedConnectionsMap.insert(std::make_pair(res->getId(), res));  /* emplace is not implemented on AIX 13.1 compiler PMSTA-21500 - 161015 - PMO */
            }

            res->setOwningLocalProvider(this);    /* PMSTA-nuodb - LJE - 190502 */
        }

        if (this->installSessionProperties(*res) != RET_SUCCEED)
        {
            for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); ++itConn)
            {
                if ((*itConn).connectionPtr->getId() == res->getId())
                {
                    this->preferredConnections.erase(itConn);
                    break;
                }
            }
            this->m_usedConnectionsMap.erase(res->getId());
            res->release();
            res->setOwningLocalProvider(nullptr);    /* PMSTA-nuodb - LJE - 190502 */
            res = nullptr;

            throw AAACannotConnectException("installSessionProperties error connection not allowed", desc, -1);
        }

        /* PMSTA-24510 - 220816 - PMO */
        if (false == retrievedConnection)
        {
            SV_NbUsedConnection.fetch_add(1);
        }
    }

    return res;
}


void AAALocalConnectionProvider::reset(void)
{
    if (this->preferredConnections.size() > 0)
    {
        for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); ++itConn)
        {
                /* check if the preferred connection is un use ?*/
            if (itConn->connectionPtr->m_usedConnectionNbr != 0)
            {
                std::string message;
                SYS_StringFormat(message, "Reset still used connection failed (connect No:%d)", itConn->connectionPtr->getId());
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, message.c_str());

                /* the cache is reset while connections are used ! -> big bada boom*/
                SYS_BreakOnDebug();
            }

            itConn->connectionPtr->setOwningLocalProvider(nullptr);
            itConn->connectionPtr->getOwningPool()->release((*itConn).connectionPtr);
        }
        this->preferredConnections.clear();
    }
}

void AAALocalConnectionProvider::reset(const AAAConnectionTypeEnum type)
{
    if (this->preferredConnections.size() > 0)
    {
        bool erased;
        for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); )
        {
            erased = false;
            if ((*itConn).connectionPtr->getDescription().getType() == type)
            {
                /* check if the preferred connection is unused ?*/
                if (itConn->connectionPtr->m_usedConnectionNbr != 0)
                {
                    std::string message;
                    SYS_StringFormat(message, "Reset still used connection failed (connect No:%d)", itConn->connectionPtr->getId());
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, message.c_str());

                    /* the case is reseted while connections are used ! -> big bada boom*/
                    /* The connection is delete from the cache but not released -> this connection should be definitely lost -> to debug if happens*/
                    SYS_BreakOnDebug();
                }
                itConn->connectionPtr->setOwningLocalProvider(nullptr);
                (*itConn).connectionPtr->getOwningPool()->release((*itConn).connectionPtr);
                itConn = preferredConnections.erase(itConn);
                erased = true;
            }

            if (erased == false)
            {
                ++itConn;
            }
        }
    }
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::getConnection()
*
*   Description          :
*
*   Arguments            :  id
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
DbiConnection* AAALocalConnectionProvider::getConnection(const int& id)
{
    DbiConnection* res = nullptr;
    /**
    * if there is a held preferred connection that is not used and that has id equals to requested id
    * => the preferred connection is the selected connection.
    * we mark the preferred connection has used
    */
    if (this->preferredConnections.size() > 0)
    {
        for (auto itConn = this->preferredConnections.begin(); res == nullptr && itConn != this->preferredConnections.end(); ++itConn)
        {
            if ((*itConn).connectionPtr->getId() == id)
            {
                if (itConn->connectionPtr->m_usedConnectionNbr != 0)
                {
                    res = (*itConn).connectionPtr;
                }
                else
                {
                    throw AAAInvalidConnectionIdentifierException("the preferred connection is not in use", id);
                }
            }
        }
    }
    /**
    * we have to retrieve the connection in  the pool
    */
    if (res == nullptr)
    {
        /* DLA NORMALY  USED only for connection with Disconnection policy = DisconnectAtRelease taht are not in cache*/
        std::map<int, DbiConnection*>::const_iterator it = m_usedConnectionsMap.find(id);       /* PMSTA-19735 - 020415 - PMO */

        if (it != m_usedConnectionsMap.end())                                                   /* PMSTA-19735 - 020415 - PMO */
        {
            res = it->second;                                                                   /* PMSTA-19735 - 020415 - PMO */
        }
        else
        {
            try
            {   /* an exception is done for DISPATCH Server*/
                /* DLA - PMSTA-25748 - 161230  and at exit process*/
                res = AAAConnectionProvider::getConnectionProviderInstance().getConnection(id);
                /* We dont add this id in usedConnectionsMap because this connection is directly create via AAAConnectionProvider instead the local provider...*/
            }
            catch (AAAInvalidConnectionIdentifierException&)
            {
                throw;
            }
        }
    }
    return res;
}

bool AAALocalConnectionProvider::reconnect(DbiConnection& connection)
{
    bool res = true;

    if (connection.reconnect() &&
        connection.isConnected())
    {
        if (this->installSessionProperties(connection) != RET_SUCCEED)
        {
            res = false;
            connection.setValidConnection(false);
        }
        res = true;
    }
    else
    {
        connection.setValidConnection(false);
        res = false;
    }
    return res;
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::release()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
void AAALocalConnectionProvider::release(DbiConnection* connection)
{
    bool bFound = false;

    /**
     * if the connection is the preferred one we just mark the preferred connection has not use
     */
    for (auto itConn = this->preferredConnections.begin(); bFound == false && itConn != this->preferredConnections.end(); ++itConn)
    {
        if (connection == (*itConn).connectionPtr)
        {
            bFound = true;
            assert(connection->getSpecification().getConnectionPolicies().getDisconnectionPolicy() != AAADisconnectionPolicy::DisconnectAtRelease); /* DLA - PMSTA-24738 - 160913 - This case is normally impossible -> connection not cached if AAADisconnectionPolicy == DisconnectAtRelease */

            if (itConn->connectionPtr->m_usedConnectionNbr == 0)
            {
                (*itConn).connectionPtr->resetIdleTime();
            }
            else
            {
                throw AAAInvalidConnectionStateException("preferred connection is in use", connection->getDescription(), connection->getId());
            }
        }
    }

    if (bFound == false)
    {
        this->m_usedConnectionsMap.erase(connection->getId());

        connection->setOwningLocalProvider(nullptr);    /* PMSTA-nuodb - LJE - 190502 */
        if (connection->getOwningPool() != nullptr)
        {
            connection->getOwningPool()->release(connection);
        }
    }

    /* DLA - PMSTA-24911 - 161024 */
    this->applyPolicies();

    /* PMSTA-24510 - 220816 - PMO */
    SV_NbUsedConnection.fetch_sub(1);
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::remove()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-37366 - LJE - 200830
*
*************************************************************************/
void AAALocalConnectionProvider::remove(DbiConnection* connection)
{
    /**
     * if the connection is the preferred one we just mark the preferred connection has not use
     */
    for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); ++itConn)
    {
        if (connection == (*itConn).connectionPtr)
        {
            (*itConn).connectionPtr->setOwningLocalProvider(nullptr);
            this->preferredConnections.erase(itConn);
            break;
        }
    }

    this->m_usedConnectionsMap.erase(connection->getId());
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::applyPolicies()
*
*   Description          :  Apply the connection policies for the cache
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  DLA - PMSTA-24911 - 161024
*
*
*************************************************************************/
void AAALocalConnectionProvider::applyPolicies()
{
    if (this->preferredConnections.size() > 0)
    {
        int connTimeout = 0;
        time_t now;
        time(&now);
        GEN_GetApplInfo(ApplConnPoolUnusedTimeout, &connTimeout);

        if (connTimeout > 0 && difftime(now, this->lastCleanUp) >= connTimeout)
        {
            this->lastCleanUp = now;

            for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); ++itConn)
            {
                if (itConn->connectionPtr->m_usedConnectionNbr == 0 &&
                    ((*itConn).connectionPtr->isConnected()))
                {
                    if ((*itConn).connectionPtr->getSpecification().getConnectionPolicies().getDisconnectionPolicy() == AAADisconnectionPolicy::DisconnectAtUnusedConnTimeout &&
                        (*itConn).connectionPtr->isIdleTimeOut((*itConn).connectionPtr->getSpecification().getConnectionPolicies().getMaxIdleTime()))
                    {
                        (*itConn).connectionPtr->disconnect();
                    }

                    if ((*itConn).connectionPtr->getSpecification().getConnectionPolicies().getAgingPolicy() == AAAAgingPolicy::Aging &&
                        (*itConn).connectionPtr->isExpired((*itConn).connectionPtr->getSpecification().getConnectionPolicies().getMaxAge()))
                    {
                        itConn->connectionPtr->m_usedConnectionNbr++;
                        this->reconnect(*(*itConn).connectionPtr);
                        itConn->connectionPtr->m_usedConnectionNbr--;
                    }
                }
            }
        }
    }
}


/************************************************************************
*   Function             :  AAALocalConnectionProvider::configure()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*                           PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
void AAALocalConnectionProvider::configure(const AAAConnectionPoolConfiguration& connectionPoolConfiguration)
{
    try
    {
        /**
        * configure the pool
        */
        AAAConnectionProvider::getConnectionProviderInstance().configure(connectionPoolConfiguration);
    }
    catch (...)
    { // Avoid to kill the current thread
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }
}

void AAALocalConnectionProvider::unconfigure(const AAAConnectionDescription& desc)
{
    /**
    * if the held connection description correspond to the connection description
    * => reset the local provider
    */

    if (preferredConnections.size() > 0)
    {
        this->reset();
    }
    AAAConnectionProvider::getConnectionProviderInstance().unconfigure(desc);
}

DbiConnection*  AAALocalConnectionProvider::find(const AAAConnectionType* typeScopeFilter, const char* user, const char* serverNameScopeFilter, bool(*searchFunc)(DbiConnection&, void*), void* searchArg)
{
    DbiConnection* res = nullptr;
    if (this->preferredConnections.size() > 0)
    {
        for (auto itConn = this->preferredConnections.begin(); itConn != this->preferredConnections.end(); ++itConn)
        {
            if (itConn->connectionPtr->m_usedConnectionNbr &&
                (*itConn).connectionPtr->getDescription().match(typeScopeFilter, user, serverNameScopeFilter) &&
                ((*searchFunc) (*(*itConn).connectionPtr, searchArg)))
            {
                res = (*itConn).connectionPtr;
            }
        }
    }

    if (res == nullptr)
    {
        for (auto it = m_usedConnectionsMap.begin(); it != m_usedConnectionsMap.end(); ++it)
        {
            if ((it->second->getDescription().match(typeScopeFilter, user, serverNameScopeFilter))
                && (((*searchFunc) (*(it->second), searchArg))))
            {
                res = it->second;
            }
        }
    }
    if (res == nullptr)
    {
        res = AAAConnectionProvider::getConnectionProviderInstance().find(typeScopeFilter, user, serverNameScopeFilter, searchFunc, searchArg);
    }
    return res;
}

/************************************************************************
**
**  Function    :   DBA_CreateApplSession()
**
**  Description :   create new session for current channel/user
**
**  Arguments   :   none
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_INFO_NOACTION
**                  ....
**
** Creation     :   PMSTA-22549 - CHU - 160518
**
** Last modif.  :   PMSTA-32327 - 260718 - PMO : Improve error management in the fusion process regarding connection error
**
*************************************************************************/
STATIC RET_CODE DBA_CreateApplSession(DbiConnection& dbiConn, char *applSessionCode, const size_t size)
{
    RET_CODE        ret = RET_GEN_ERR_INVARG;
    std::string     loginCd;
    CODE_T          channelCd;

    GEN_GetUserInfo(UserLogin, loginCd);
    DBA_GetChannelCd(channelCd);

    if (SYS_StrLen(channelCd) == 0 || loginCd.length() == 0)
    {
        char message[512];
        sprintf(message, "create_appl_session error for connection=%d (channel='%s'/login='%s')", dbiConn.getId(), channelCd, loginCd.c_str());
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, message);
    }
    else
    {
        std::string mainDb;
        GEN_GetApplInfo(ApplSqlDbName, mainDb);

        DbiConnectionHelper  dbiConnectionHelper(&dbiConn, false);
        RequestHelper        requestHelper(dbiConnectionHelper);
        requestHelper.useDb(mainDb);

        if (false == dbiConnectionHelper.isValidAndInit())
        {
            MSG_SendMesg(FILEINFO, "Unable to get a connection");
            MSG_RETURN(RET_DBA_ERR_CANNOTCONNECT);
        }

        DbaTransactionGuard dbaTransactionGuard(dbiConn, ret);
        dbaTransactionGuard.beginTransaction();

		if (EV_AAAInstallLevel == 0 && SYS_IsDdlGenMode() == FALSE)
		{
			FLAG_T activateorgsecurityFlg = FALSE;
			GEN_GetApplInfo(ApplActivateOrgSecurityFlg, &activateorgsecurityFlg);
			if (activateorgsecurityFlg == TRUE)
			{
				RET_CODE retCode = RET_GEN_INFO_NOACTION;
				MemoryPool          mp;
				ID_T userId;
				GEN_GetUserInfo(UserId, &userId);
				DBA_DYNFLD_STP      aApplUser = mp.allocDynst(FILEINFO, A_ApplUser);
				DBA_DYNFLD_STP      sApplUser = mp.allocDynst(FILEINFO, S_ApplUser);
				SET_ID(sApplUser, S_ApplUser_Id, userId);
				retCode = dbiConnectionHelper.dbaGet(ApplUser, UNUSED, sApplUser, &aApplUser);
				if ((retCode == RET_SUCCEED) &&
					(GET_FLAG(aApplUser, A_ApplUser_SecurityAdminFlg) == FALSE) &&
					(GET_FLAG(aApplUser, A_ApplUser_SuperuserFlg) == FALSE))
				{
					retCode = DBA_BuildDataProfileCompoApplUser(aApplUser, InsUpd, dbiConnectionHelper);
					if (retCode != RET_SUCCEED)
					{
						MSG_SendMesg(FILEINFO, "Error during Data Profile evaluation for the user");
						MSG_RETURN(RET_DBA_ERR_NODATA);
					}
				}
			}
		}
		
        DBA_DYNFLD_STP  sApplSessionSt = ALLOC_DYNST(S_ApplSession);
        if (sApplSessionSt == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_CODE(sApplSessionSt, S_ApplSession_ApplSessionChannel, channelCd);
        SET_CODE(sApplSessionSt, S_ApplSession_ApplSessionUser, loginCd.c_str());
        SET_INT( sApplSessionSt, S_ApplSession_Pid, static_cast<INT_T>(SYS_GetPid()));  /* PMSTA-27274 CMILOS 250618 */

        /* PMSTA-26108 - LJE - 170829 */
        if (SYS_GetThreadCurrBusinessEntity().empty() == false)
        {
            SET_CODE(sApplSessionSt, S_ApplSession_ConnectedBusEntityCd, SYS_GetThreadCurrBusinessEntity().c_str());
        }
        dbiConnectionHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE);

        if ((ret = dbiConnectionHelper.dbaUpdate(ApplSession, DBA_ROLE_MANAGE_APPL_SESSION, sApplSessionSt)) == RET_SUCCEED)                                 /* PMSTA-32327 - 260718 - PMO */
        {
            if (RET_SUCCEED == ret)
            {
                nstrcpy(applSessionCode, size, GET_CODE(sApplSessionSt, S_ApplSession_Cd));
            }
            else
            { // Error
                applSessionCode[0] = END_OF_STRING;
            }
        }
        else
        {
            dbiConnectionHelper.sendAllMsg();
        }

        FREE_DYNST(sApplSessionSt, S_ApplSession);
    }
    return (ret);
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::installSessionProperties()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*                           PMSTA-25238 - 141116 - PMO : It is possible to run a GUI even if the channel GUI is deactivated
*                           PMSTA-25793 - 281216 - PMO : Dispatcher might crash on AIX into putProperty
*                           PMSTA-32327 - 260718 - PMO : Improve error management in the fusion process regarding connection error
*
*************************************************************************/
RET_CODE AAALocalConnectionProvider::installSessionProperties(DbiConnection& connection)
{
    RET_CODE retCode = RET_SUCCEED;

#ifdef _DEBUG
    LockGuard(connection.lock);
#endif

    bool bSetAllThreadContextProperties = false;

    if (connection.getDescription().getType() == SqlServer)
    {
        AAAConnectionDescription desc(connection.getSpecification());
        SessionProperties &currSessionProperties = this->getSessionProperties(desc.getRole());

        std::string str(connection.getDescription().getDatabase());
        if (str.empty())
        {
            GEN_GetApplInfo(ApplSqlDbName, str);
        }
        currSessionProperties.setDbName(str);
        currSessionProperties.setDateTimeFormat(DateStyle_DdMmYyyy);

        /* PMSTA-24079 - LJE - 160719 - Move and fix... */
        /* < PMSTA-22549 - CHU - 160518 : use appSession management instead of context */
        /* PMSTA-26108 - 171116 - DDV - refactoring to correctly use appl_session */
        /* DLA - PMSTA-29464 - 171207 */
        if (EV_DictInitFlg == TRUE &&
            (EV_AAAInstallLevel == 0 || (EV_AAAInstallLevel <= 2 && GEN_IsMultiEntity() && SYS_IsDdlGenMode() == FALSE)) &&
            desc.getRole() != AAAConnectionRole::ROLE_DBSO)
        {
            CODE_T       applSessionCode;
            DBA_GetApplSessionCode(&applSessionCode, desc.getRole(), &currSessionProperties);
            if (applSessionCode[0] == END_OF_STRING &&
                SYS_GetThreadUseProxyUser() == false) /* PMSTA-34344 - LJE - 210211 */
            {
                /* PMSTA-34344 - TEB - 190805 */
                if (EV_RdbmsVendor == QtHttp)
                {
                    retCode = HTTP_CreateApplSession(connection, applSessionCode);
                }
                else
                {
                    retCode = DBA_CreateApplSession(connection, applSessionCode, sizeof(applSessionCode));
                }

                if (RET_SUCCEED == retCode && END_OF_STRING != applSessionCode[0])                  /* PMSTA-32327 - 260718 - PMO */
                {
                    currSessionProperties.setApplSessionCd(applSessionCode);
                }

                retCode = nullptr != SYS_SetAllThreadContextProperties(connection, currSessionProperties.getApplSessionCd(), connection.getDescription().getRole()) ? RET_SUCCEED : RET_DBA_ERR_SETPARAM;

                bSetAllThreadContextProperties = true;
            }
        }
        /* > PMSTA-22549 - CHU - 160518 */

        if (retCode == RET_SUCCEED) /* DLA - PMSTA-29891 - 180122 */
        {
            auto sessionPropertiesIt = this->m_mapSessionProperties.find(desc.getRole());
            if (sessionPropertiesIt != this->m_mapSessionProperties.end())
            {
                try
                {
                    connection.setSessionProperties(sessionPropertiesIt->second);

                    if (SYS_IsDdlGenMode() == FALSE)
                    {
                        /* DLA - PMSTA-29812 - 180116 */
                        if (SYS_IsBatchMode() && EV_AAAInstallLevel <= 2 &&
                            desc.getRole() != AAAConnectionRole::ROLE_DBSO) /*PMSTA-55380 - FME 2024-01-25*/
                        {
                            connection.getTargetSessionProperties().setModifStat(EV_TableAndObjectModifFlag);
                        }
                    }

                    if (EV_AAAInstallLevel != 0 && EV_AAAInstallLevel <= 2 && str[0] != 0)
                    {
                        connection.getTargetSessionProperties().setSetConnUser();
                    }

                    retCode = connection.applyPropertiesOnConnection();
                }
                catch (AAAInvalidConnectionPropertiesException& e)
                {
                    MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());
                    retCode = RET_DBA_ERR_SETPARAM;
                }
            }
        }

        if (retCode == RET_SUCCEED &&
            bSetAllThreadContextProperties == true)
        {
            DBA_DYNFLD_STP aApplSessionStp = SYS_GetThreadApplSessionStpByCd(connection.getConnSessionProperties().getApplSessionCd());
            if (nullptr != aApplSessionStp)
            {
                DbiConnectionHelper dbiConnHelper(&connection, false);
                SYS_SetThreadApplUser(dbiConnHelper, nullptr, true);
                retCode = DBA_SetUserSessionInfo(dbiConnHelper, aApplSessionStp);
            }
        }
    } else  if (SYS_IsGuiMode() == TRUE && EV_RdbmsVendor == QtHttp && connection.getDescription().getType() == FinServer) /* PMSTA-34344 - TEB - 191011 */
    {
        AAAConnectionDescription desc(connection.getSpecification());
        SessionProperties &currSessionProperties = this->getSessionProperties(desc.getRole());

        connection.getTargetSessionProperties().setHttpSessionId(currSessionProperties.getHttpSessionId());
    }

    return retCode;
}


/************************************************************************
*   Function             :  AAALocalConnectionProvider::removeSessionProperties()
*
*   Description          :
*
*   Arguments            :  connection
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
 RET_CODE AAALocalConnectionProvider::removeSessionProperties(DbiConnection& connection)
{
    RET_CODE retCode = RET_SUCCEED;

    if (connection.getDescription().getType() == SqlServer)
    {
        AAAConnectionDescription desc(connection.getSpecification());

        auto sessionPropertiesIt = this->m_mapSessionProperties.find(desc.getRole());
        if (sessionPropertiesIt != this->m_mapSessionProperties.end())
        {
            try
            {
                retCode = connection.removePropertiesOnConnection();
            }
            catch (AAAInvalidConnectionPropertiesException& e)
            {
                MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());
                retCode = RET_DBA_ERR_SETPARAM;
            }
        }
    }

    return retCode;
}


 /************************************************************************
 *   Function             :  AAALocalConnectionProvider::clearSessionMap()
 *
 *   Description          :
 *
 *   Arguments            :
 *
 *   Return               :
 *
 *   Creation Date        :
 *
 *   Last Modification    :
 *
 *************************************************************************/
 void  AAALocalConnectionProvider::clearSessionMap()
 {
     this->m_mapSessionProperties.clear();
     //this->m_mapSessionProperties
 }

bool  AAALocalConnectionProvider::changePassword(DbiConnection& connection, const PasswordEncrypted& password)
{
    bool ret = connection.changePassword(password);
    if (ret)
    {
        AAAConnectionProvider::getConnectionProviderInstance().updatePassword(connection.getDescription().getUser(), password);
    }
    return ret;
}

bool AAALocalConnectionProvider::changePassword(DbiConnection& adminConnection, const  std::string& user, const PasswordEncrypted& password)
{
    bool ret = adminConnection.changePassword(user, password);
    if (ret)
    {
        AAAConnectionProvider::getConnectionProviderInstance().updatePassword(user, password);
    }
    return ret;
}

/************************************************************************
*   Function             :  AAALocalConnectionProvider::initAdminSessionMap()
*
*   Description          :
*
*   Arguments            :  adimin. session code to return
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void  AAALocalConnectionProvider::initAdminSessionMap()
{
    if (!GEN_IsMultiEntity())
    {
        return;
    }

    ID_T servId = 0;

    if (SERVER_MODE())
    {
        GEN_GetApplInfo(ApplServerId, &servId);
    }

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
    int	row = 0, currNbr=0;
	FLAG_T			loadAllBECurrFlg = FALSE;

    DBA_DYNFLD_STP* sBusTab = nullptr;
	DBA_DYNFLD_STP* aCurrTab = nullptr;
    dbiConnHelper.dbaSelect(BusEntity, DBA_ROLE_BY_BUS_ENTITY, nullptr, S_BusEntity, &sBusTab, &row);

    std::string oldBe = SYS_GetThreadCurrBusinessEntity();

    DICT_ENTITY_STP dictEntityPtr = DBA_GetDictEntitySt(Curr);
	if (dictEntityPtr != NULL &&
        dictEntityPtr->multiEntityCateg.isBusinessEntityDependents()) /* PMSTA-30152 - LJE - 180509 */ /* PMSTA-29879 - LJE - 180712 */
	{
		loadAllBECurrFlg = TRUE;
	}

    for (int i = 0; i < row; i++)
    {
        std::string currBusinessEntity = GET_CODE(sBusTab[i], S_BusEntity_Cd);
        SYS_SetThreadCurrBusinessEntity(currBusinessEntity);

        DbiConnectionHelper beConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);

        if (beConnHelper.isValidAndInit()) /* Activation of the current business entity */
        {
            /* PMSTA-26108 - LJE - 171128 - Move here appl_session */
            if (SERVER_MODE())
            {
                DBA_LoadServerInfos(servId);
            }

            /* PMSTA-28455 - RAK - 171102 - Load current BE currencies */
            if (loadAllBECurrFlg == TRUE)
            {
                beConnHelper.dbaSelect(Curr, DBA_ROLE_SEL_ALL_CURRENCY, nullptr, A_Curr, &aCurrTab, &currNbr);
                if (currNbr > 0)
                {
                    CurrenciesMap::getInstance().init(aCurrTab, currNbr, GET_ID(sBusTab[i], S_BusEntity_Id));
                    FREE(aCurrTab);
                }
            }
        }
    }

	SYS_SetThreadCurrBusinessEntity(oldBe);
    DBA_FreeDynStTab(sBusTab, row, S_BusEntity);
}


std::vector<localConnection> * AAALocalConnectionProvider::getLocalConnections()
{
    return &this->preferredConnections;
}

SessionProperties &AAALocalConnectionProvider::getSessionProperties(const AAAConnectionDescription& desc)
{
    auto it = this->m_mapSessionProperties.find(desc.getRole());

    if (it == this->m_mapSessionProperties.end())
    {
        this->m_mapSessionProperties.insert(std::make_pair(desc.getRole(), SessionProperties()));
        it = this->m_mapSessionProperties.find(desc.getRole());
    }

    return it->second;
}

LocalConnectionStatus::LocalConnectionStatus()
{
    /*
    std::stringstream str;
    DbiConnection* conn = AAALocalConnectionProvider::get().getPreferedConnection();
    if (conn != nullptr)
    {
    str << "predered connection no=" << conn->getId() << "\n"
    << "spec=" << conn->getSpecification() << "\n"
    << "desc=" << conn->getDescription() << "\n"
    << "prop=" << conn->getPropertyRegistry() << "\n";
    m_strOut = str.str();
    }
    else
    {
    m_strOut = "No prefered connection";
    }
    */

};

std::vector<AAAConnectionStatus> AAALocalConnectionProvider::getAllConnectionsStatus()
{
    return AAAConnectionProvider::getConnectionProviderInstance().getAllConnectionsStatus();
}

std::vector < std::pair<AAAConnectionPoolStatus, std::vector<AAAConnectionStatus>>> AAALocalConnectionProvider::getAllConnectionsStatusByPool(const AAAConnectionStatusParam& param)
{
    return AAAConnectionProvider::getConnectionProviderInstance().getAllConnectionsStatusByPool(param);
}

std::vector<AAAConnectionStatus> AAALocalConnectionProvider::getCachedConnectionsStatus()
{

    return AAAConnectionProvider::getConnectionProviderInstance().getAllConnectionsStatus();
}


std::ostream& operator<<(std::ostream& os, const LocalConnectionStatus& obj)
{
    os << obj.m_strOut;
    return os;
}

SessionProperties::SessionProperties()
    : m_userId(ZERO_ID)
    , m_dataProfileId(ZERO_ID)
    , m_modifStat(0)               /* PMSTA-30604 - DLA - 180315 */
    , m_languageDictId(ZERO_ID)
    , m_applSessionCd("Invalid")
    , m_businessEntityId(ZERO_ID)
    , m_mainDlmEnMax(Dlm_HistoRO)
    , m_addDlmEnMax(Dlm_HistoRO)
    , m_changeSetId(ZERO_ID)
    , m_bSetConnUser(false)
    , m_bSetDefaultProp(false)
    , m_dateTimeFormatEn(DateStyle_None)
    , m_bDeferredNameResolution(false)
    , m_bReadOnly(false)
    , m_applSessionStp(nullptr)
    , m_connectionPtr(nullptr)
{
}

SessionProperties::SessionProperties(const SessionProperties& toCopy)
    : SessionProperties()
{
    *this = toCopy;
}

SessionProperties & SessionProperties::operator = (const SessionProperties & toCopy)
{
    this->m_userId                    = toCopy.m_userId;
    this->m_dataProfileId             = toCopy.m_dataProfileId;
    this->m_modifStat                 = toCopy.m_modifStat;
    this->m_languageDictId            = toCopy.m_languageDictId;
    this->m_applSessionCd             = toCopy.m_applSessionCd;
    this->m_businessEntityId          = toCopy.m_businessEntityId;
    this->m_mainDlmEnMax              = toCopy.m_mainDlmEnMax;
    this->m_addDlmEnMax               = toCopy.m_addDlmEnMax;
    this->m_changeSetId               = toCopy.m_changeSetId;
    this->m_bSetConnUser              = toCopy.m_bSetConnUser;
    this->m_bSetDefaultProp           = toCopy.m_bSetDefaultProp;
    this->m_dateTimeFormatEn          = toCopy.m_dateTimeFormatEn;
    this->m_bDeferredNameResolution   = toCopy.m_bDeferredNameResolution;
    this->m_bReadOnly                 = toCopy.m_bReadOnly;
    this->m_dbName                    = toCopy.m_dbName;
    this->m_httpSessionId             = toCopy.m_httpSessionId;

    this->setApplSessionStp(nullptr);
    return *this;
}

void SessionProperties::resetSessionproperties()
{
    this->m_userId                    = ZERO_ID;
    this->m_dataProfileId             = ZERO_ID;
    this->m_modifStat                 = 0;
    this->m_languageDictId            = ZERO_ID;
    this->m_applSessionCd             = "Invalid";
    this->m_businessEntityId          = ZERO_ID;
    this->m_mainDlmEnMax              = Dlm_HistoRO;
    this->m_addDlmEnMax               = Dlm_HistoRO;
    this->m_changeSetId               = ZERO_ID;
    this->m_bSetConnUser              = false;
    this->m_bSetDefaultProp           = false;
    this->m_connectionPtr             = nullptr;
    this->m_dateTimeFormatEn          = DateStyle_None;
    this->m_bDeferredNameResolution   = false;
    this->m_bReadOnly                 = false;
    this->m_dbName.clear();
    this->m_httpSessionId.clear();

    this->setApplSessionStp(nullptr);
}

void SessionProperties::setUserId(ID_T userId)
{
    this->m_userId = userId;
}

ID_T SessionProperties::getUserId() const
{
    return this->m_userId;
}

void SessionProperties::setDataProfileId(ID_T dataProfileId)
{
    this->m_dataProfileId = dataProfileId;
}

ID_T SessionProperties::getDataProfileId() const
{

    return this->m_dataProfileId;
}

void SessionProperties::setModifStat(int modifStat)
{
    this->m_modifStat = modifStat;
}

int SessionProperties::getModifStat() const
{
    return this->m_modifStat;
}

void SessionProperties::setLanguageDictId(DICT_T languageDictId)
{
    this->m_languageDictId = languageDictId;
}

DICT_T SessionProperties::getLanguageDictId() const
{
    return this->m_languageDictId;
}

void SessionProperties::setApplSessionCd(const std::string &applSessionCd)
{
    this->m_applSessionCd = applSessionCd;
    this->setApplSessionStp(nullptr);
}

std::string SessionProperties::getApplSessionCd() const
{
    if (this->m_applSessionCd.compare("Invalid"))
    {
        return this->m_applSessionCd;
    }
    return std::string();
}

/* PMSTA-34344 - TEB - 190805 */
void SessionProperties::setHttpSessionId(const std::string &httpSessionId)
{
    this->m_httpSessionId = httpSessionId;
}

/* PMSTA-34344 - TEB - 190805 */
std::string SessionProperties::getHttpSessionId() const
{
    if (this->m_httpSessionId.compare("Invalid"))
    {
        return this->m_httpSessionId;
    }
    return std::string();
}

void SessionProperties::setBusinessEntityId(ID_T businessEntityId)
{
    this->m_businessEntityId = businessEntityId;
}

ID_T SessionProperties::getBusinessEntityId() const
{
    return this->m_businessEntityId;
}

void SessionProperties::setMainDlmEnMax(DLM_ENUM mainDlmEnMax)
{
    this->m_mainDlmEnMax = mainDlmEnMax;
}

DLM_ENUM SessionProperties::getMainDlmEnMax() const
{
    return this->m_mainDlmEnMax;
}

void SessionProperties::setAddDlmEnMax(DLM_ENUM addDlmEnMax)
{
    this->m_addDlmEnMax = addDlmEnMax;
}

DLM_ENUM SessionProperties::getAddDlmEnMax() const
{
    return this->m_addDlmEnMax;
}

void SessionProperties::setChangeSetId(ID_T changeSetId)
{
    this->m_changeSetId = changeSetId;
}

ID_T SessionProperties::getChangeSetId() const
{
    return this->m_changeSetId;
}

void SessionProperties::setSetConnUser()
{
    this->m_bSetConnUser = true;
}

bool SessionProperties::isSetConnUser() const
{
    return this->m_bSetConnUser;
}

void SessionProperties::setSetDefaultProp()
{
    this->m_bSetDefaultProp = true;
}

bool SessionProperties::isSetDefaultProp() const
{
    return this->m_bSetDefaultProp;
}

void SessionProperties::setDateTimeFormat(DATE_STYLE_ENUM dateTimeFormatEn)
{
    this->m_dateTimeFormatEn = dateTimeFormatEn;
}

DATE_STYLE_ENUM SessionProperties::getDateTimeFormat() const
{
    return this->m_dateTimeFormatEn;
}

void SessionProperties::setDeferredNameResolution(bool bDeferredNameResolution)
{
    this->m_bDeferredNameResolution = bDeferredNameResolution;
}

bool SessionProperties::isDeferredNameResolution() const
{
    return this->m_bDeferredNameResolution;
}

void SessionProperties::setDbName(const std::string &dbName)
{
    if (dbName.empty() && this->m_dbName.empty())
    {
        if (this->m_defaultDbName.empty())
        {
            GEN_GetApplInfo(ApplSqlDbName, this->m_defaultDbName);
        }
        this->m_dbName = this->m_defaultDbName;
    }

    if (dbName.empty() == false &&
        strcasecmp(this->m_dbName.c_str(), dbName.c_str()) != 0)
    {
        this->m_dbName = dbName;
    }
}

const std::string &SessionProperties::getDbName() const
{
    return this->m_dbName;
}

void SessionProperties::setPropFromApplSession()
{
    if (this->m_applSessionStp)
    {
        this->setUserId(GET_ID(this->m_applSessionStp, A_ApplSession_ApplUserId));
        this->setDataProfileId(GET_ID(this->m_applSessionStp, A_ApplSession_DataProfileId));
        this->setChangeSetId(GET_ID(this->m_applSessionStp, A_ApplSession_ChangeSetId));
        this->setBusinessEntityId(GET_ID(this->m_applSessionStp, A_ApplSession_ConnectedBusEntityId));
    }
    else
    {
        this->setUserId(ZERO_ID);
        this->setDataProfileId(ZERO_ID);
        this->setChangeSetId(ZERO_ID);
        this->setBusinessEntityId(ZERO_ID);
    }
}

void SessionProperties::setApplSessionStp(DBA_DYNFLD_STP applSessionStp)
{
    if (this->m_applSessionStp != nullptr)
    {
        this->m_mp.remove(this->m_applSessionStp);
        FREE_DYNST(this->m_applSessionStp, A_ApplSession);
        this->m_applSessionStp = nullptr;
    }

    if (applSessionStp != nullptr &&
        IS_NULLFLD(applSessionStp, A_ApplSession_Cd) == false)
    {
        this->m_applSessionStp = this->m_mp.allocDynst(FILEINFO, A_ApplSession);
        COPY_DYNST(this->m_applSessionStp, applSessionStp, A_ApplSession);

        this->m_applSessionCd = GET_CODE(this->m_applSessionStp, A_ApplSession_Cd);
    }
    this->setPropFromApplSession();
}

DBA_DYNFLD_STP SessionProperties::getApplSessionStp()
{
    if (this->m_applSessionStp == nullptr && this->m_applSessionCd.empty() == false)
    {
        this->setApplSessionStp(SYS_GetThreadApplSessionStpByCd(this->m_applSessionCd));
    }
    return this->m_applSessionStp;
}


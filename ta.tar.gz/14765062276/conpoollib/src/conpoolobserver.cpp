/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <sstream>
#include <fstream>
#include "unidef.h"
#include "syslib.h"
#include "callstack.h"
#include "conpoolobserver.h"
#include "conpoolevent.h"

AAAObserver::AAAObserver(const std::string& filename, const ObserverDetailEn& detail) : outfile(filename.c_str(), std::ios::out | std::ios::app),
                                                                                  detail(detail)
{
    if (!outfile)
    {
        std::cout << "Unable to open AAAConnectionPoolObserver trace file: " << filename;
    }
}

AAAConnectionPoolObserver::AAAConnectionPoolObserver(const std::string& filename, const ObserverDetailEn& detail) : AAAObserver(filename, detail){};

void AAAConnectionPoolObserver::processEvent(const  AAAConnectionPoolEvent& event)
{
    CurrentTime now(CurrentTime::Kind::CurrentUs);
    std::stringstream sstm;
    
    sstm << now.formatYYYYMMDDHMSUS() << "  :  " << event;

    if (this->detail >= ObserverDetailEn::medium)
    {
        /* sstm << std::endl; DDV - 190430 - Display Rpc and thread info on the same line */
        if (SYS_GetRpcName().length() > 0)
        {
            sstm << "    rpc: " << SYS_GetRpcName() << "    tid: " << SYS_GetThreadId();
        }
        else
        {
            sstm << "    tid: " << SYS_GetThreadId();
        }
    }
    
    if (this->detail == ObserverDetailEn::high)
    {
        sstm << std::endl;
        sstm << SYS_GetCallStack(1);
    }
    
    if (outfile)
    {
        outfile   << sstm.str() << std::endl;
    }
    else
    {
        std::cout << sstm.str() << std::endl;
    }
}


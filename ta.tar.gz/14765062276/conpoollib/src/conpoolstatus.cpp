/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <sstream>
#include "unidef.h"
#include "conpoolconf.h"
#include "dba.h"
#include "dbiconnection.h"
#include "conpoolstatus.h"

AAAConnectionPoolStatus::AAAConnectionPoolStatus(const AAAConnectionDescription& desc, const int& maxSize, const int& availableConnectionsCount, const int& usedConnectionsCount, const int& beginId) : description(desc){
	this->maxSize =  maxSize ;
	this->availableConnectionsCount = availableConnectionsCount ;
	this->usedConnectionsCount = usedConnectionsCount ;
    this->beginId = beginId;
    this->tascTechGroup = -1;
}
AAAConnectionPoolStatus::AAAConnectionPoolStatus(const AAAConnectionPoolStatus& tocopy) : description(tocopy.description)
{
    this->maxSize = tocopy.maxSize;
    this->availableConnectionsCount = tocopy.availableConnectionsCount;
    this->usedConnectionsCount = tocopy.usedConnectionsCount;
    this->beginId = tocopy.beginId;
    this->tascTechGroup = tocopy.tascTechGroup;
}
AAAConnectionPoolStatus::AAAConnectionPoolStatus() :
    description(),
    maxSize(0),
    availableConnectionsCount(0),
    usedConnectionsCount(0),
    beginId (0),
    tascTechGroup (-1)
    {
    }

AAAConnectionPoolStatus::~AAAConnectionPoolStatus(void){
}

const int& AAAConnectionPoolStatus::getMaxSize() const {
	return maxSize ;
}
const int& AAAConnectionPoolStatus::getAvailableConnectionsCount() const {
	return this->availableConnectionsCount ;
}
const int& AAAConnectionPoolStatus::getUsedConnectionsCount() const {
	return this->usedConnectionsCount ;
}
const std::string& AAAConnectionPoolStatus::getStringRep() {
	if (this->stringRep.empty() ) {
		std::stringstream stream ;
        stream << " role=" << description.getRoleName()
            << " type=" << description.getTypeName()
            << " model=" << description.getModelName()
            << " user=" << description.getUser()
            << " maxSize=" << this->maxSize
            << " used=" << this->usedConnectionsCount
            << " avail=" << this->availableConnectionsCount
            << " rangeId=" << this->beginId << "-" << (this->beginId + this->maxSize) - 1
            << " srv=" << description.getServerName();
	this->stringRep = stream.str() ;
	}
	return stringRep ;
}
std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolStatus& obj) {
	os << "AAAConnectionPoolStatus ["
		<< "maxSize=" << obj.getMaxSize()
		<< ",used=" << obj.getUsedConnectionsCount()
		<< ",available=" << obj.getAvailableConnectionsCount()
        << ",rangeId=" << obj.beginId << "-" << (obj.beginId + obj.maxSize) -1
		<< "]";
	return os;
}

bool AAAConnectionPoolStatus::operator==(const AAAConnectionPoolStatus& toCompare)const {
    return (description == toCompare.description);
}

bool AAAConnectionPoolStatus::operator<(const AAAConnectionPoolStatus& toCompare)const {
    return (description < toCompare.description);
}

AAAConnectionPoolStatus& AAAConnectionPoolStatus::operator=(const AAAConnectionPoolStatus& tocopy)
{
    this->description = tocopy.description;
    this->maxSize = tocopy.maxSize;
    this->availableConnectionsCount = tocopy.availableConnectionsCount;
    this->usedConnectionsCount = tocopy.usedConnectionsCount;
    this->beginId = tocopy.beginId;
    this->tascTechGroup = tocopy.tascTechGroup;
    return *this;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <functional>
#include <sstream>
#include <vector>

#include "unidef.h"
#include "dbiconnection.h"
#include "conprovider.h"
#include "conpool.h"
#include "conexcept.h"
#include "conspec.h"
#include "conpoolstatus.h"
#include "conpoolobserver.h"

#include "syslib.h"
#include "gen.h"

extern int EV_AAAInstallLevel;

static AAAConnectionProvider *instance;
Lock instanceLock;

static void ThreadCleanupConnection(ThreadArg* obj);

static Atomic<ThreadState> state(ThreadState::Initialization);           /* If the thread must loop / PMSTA-29083 - 041217 - PMO */

/* DLA - PMSTA - 27649 - 170704 - Add observer for debug information*/
AAAConnectionProvider::AAAConnectionProvider()
{
    this->setObserver();

    this->lastPool        = nullptr;
    this->m_ownedByCaller = true;
}

AAAConnectionProvider::~AAAConnectionProvider(void)
{
    for (auto x = pools.begin(); x != pools.end(); ++x)
    {
        delete (x->second);
    }
    delete(this->m_observer);
}

/* DLA - PMSTA - 27649 - 170704 - Add observer for debug information*/
void AAAConnectionProvider::setObserver()
{
    this->m_observer = nullptr;
    char * tmp = SYS_GetEnv("AAACONNECTIONPOOLTRACE");

    if (tmp != nullptr)
    {
        int traceDetail = strtol(tmp, &tmp, 10);
        char *dirname = SYS_GetEnv("AAAMSG");

        if (dirname != nullptr)
        {
            std::string filename(dirname);

            filename += "/obs_conprov_";
            const char *name =
                SYS_IsGuiMode() ? "aaa_gui" :
                SYS_IsSrvMode() ? "aaa_srv" :
                SYS_IsSqlMode() ? "aaa_sql" :
                SYS_IsBatchMode() ? GEN_GetApplName() == "aaa_subd" ? "aaa_subd" : "aaa_imp" :
                SYS_IsDdlGenMode() ? "aaa_ddlgen" :
                "unkown";

            filename += name;
            filename += ".log";

            this->m_observer = new AAAConnectionPoolObserver(filename, ObserverDetailEnFromIntValue(traceDetail));
        }
    }
}

AAAConnectionProvider& AAAConnectionProvider::getConnectionProviderInstance()
{
	LockGuard guard(instanceLock);
	if (instance == nullptr)
    {
		instance = new AAAConnectionProvider();
	}
	return *instance;
}

void AAAConnectionProvider::close()
{
	LockGuard guard(instanceLock);
	if (instance != nullptr)
    {
        instance->stopCleanupConnectionThread();
        instance->unconfigureAll();
		delete (instance);
		instance = nullptr;

        DBI_FreeContext();
    }
}

void AAAConnectionProvider::configure(const std::vector<AAAConnectionPoolConfiguration>& config)
{
	for (unsigned int i = 0 ; i <config.size(); i++)
    {
		 configure(config[i]) ;
	}
}

/************************************************************************
*   Function             :  AAAConnectionProvider::configure()
*
*   Description          :
*
*   Arguments            :  config
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
void AAAConnectionProvider::configure(const AAAConnectionPoolConfiguration& config)
{
    if (config.getDescription().getModel() == UnknownRdbms)
    {
        std::stringstream sstm;
        sstm << "Unable to determine server model while pool configuration (Unable to find record in server_running table),  description pool : ";
        throw AAAInvalidPoolDescriptionException(sstm.str(), config.getDescription());
    }

	LockGuard guard(lock);

    auto                it           = pools.find(config.getDescription());                                             /* PMSTA-19735 - 020415 - PMO */
    AAAConnectionPool * poolByConfig = it == pools.end() ? nullptr : it->second;                                        /* PMSTA-19735 - 020415 - PMO */

	if (poolByConfig != nullptr)
    {
        return; /* DLA - PMSTA-28104 - 170815 */
		//throw AAAInvalidPoolDescriptionException("pool already configured for description", config.getDescription());
	}

	const int                   startId     = lastPool != nullptr ? lastPool->getEndId() +1 : 1;
	int                         lastId      = 0;
    AAAConnectionSpecification  spec(config.getDescription().getRole(),
                                     config.getDescription().getType(),
                                     config.getDescription().getModel(),
                                     AAAConnectionCredentials(config.getDescription().getUser(), config.getPassword()),
                                     config.getDescription().getServerName(),
                                     config.getPolicies(),
                                     config.getDescription().getUrl());

    auto                        it2         = allocatorMap.find(AAAConnectionAllocatorKey(config.getDescription().getType(), config.getDescription().getModel()));  /* PMSTA-21500 - 161015 - PMO */

    if (it2 != allocatorMap.end())
    {
	    AAAConnectionAllocator  allocator   = it2->second;
        AAAConnectionPool*      pool = new AAAConnectionPool(spec, allocator, config.getMinsize(), config.getMaxsize(), startId, lastId);

	    pool->setObserver(this->m_observer);

	    pools.insert(std::make_pair(config.getDescription(), pool));                                                    /* emplace is not implemented on AIX 13.1 compiler PMSTA-21500 - 161015 - PMO */

	    lastPool =  pool;
    }
    else
    {
        std::stringstream sstm;
        sstm << "No Connection allocator found while pool configuration : " << config.getDescription();
        throw AAAInvalidPoolDescriptionException(sstm.str(), config.getDescription());
    }
}


/************************************************************************
*   Function             :  AAAConnectionProvider::unconfigure()
*
*   Description          :
*
*   Arguments            :
*
*
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
void AAAConnectionProvider::unconfigure(const  AAAConnectionType& type)
{
    bool bContinue = true;

    while (bContinue)
    {
        bContinue = false;
        for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
        {
            if (x->first.getType() == type)
            {
                bContinue = true;
                this->unconfigure(x->first);
                break;
            }
        }
    }
}

void AAAConnectionProvider::unconfigure(const AAAConnectionDescription& desc)
{
	AAAConnectionPool* pool = nullptr;
	std::string aliasName = "";
	LockGuard guard(lock);

    auto it = this->pools.find(desc);                         /* PMSTA-21500 - 161015 - PMO */

    if (it != this->pools.end())                              /* PMSTA-21500 - 161015 - PMO */
    {
        pool = it->second;                              /* PMSTA-21500 - 161015 - PMO */
    }

	if (pool == nullptr)
    {
        throw  AAAInvalidPoolDescriptionException("no pool found for description", desc);
    }


	if (this->lastPool == pool)
    {
		AAAConnectionPool* newLastPool = nullptr;
		if (this->pools.size() == 1)
        {
			lastPool = newLastPool;
		}
		else
        {
			//for (auto &x : pools)
            for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = this->pools.begin(); x != this->pools.end(); ++x)
            {
				if (x->second != pool && ((newLastPool == nullptr) || (x->second->getEndId() > newLastPool->getEndId())))
                {
					newLastPool = x->second;
				}
			}
            this->lastPool = newLastPool;
		}
	}

    if (pool->getRefNb() > 0) /* DLA - PMSTA-24234 - 160803 */
    {
        /* This pool is always referenced by other incoming connection */
        assert(1357 == 7531);
    }

    this->pools.erase(desc);
	delete (pool);
}

void AAAConnectionProvider::unconfigureAll()
{
    LockGuard guard(this->lock);
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = this->pools.begin(); x != this->pools.end(); ++x)
    {
       delete(x->second);
    }
    this->pools.clear();

    this->lastPool = nullptr;
}

DbiConnection* AAAConnectionProvider::getConnection(const int& connectionId) //throws bad_function_call
{
    DbiConnection* res = nullptr;
    AAAConnectionPool* candidate = nullptr;
    {
        LockGuard guard(this->lock);
        //for (auto &x : pools)
        for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = this->pools.begin(); x != this->pools.end(); ++x)
        {
            if (x->second->containsId(connectionId))
            {
                candidate = x->second;
                break;
            }
        }
    }
	if (candidate != nullptr)
    {
		res = candidate->getConnection(connectionId) ;
	}
	else
    {
		throw  AAAInvalidConnectionIdentifierException("no pool found for connection identifier", connectionId);
	}
	return res ;
}


/************************************************************************
*   Function             :  AAAConnectionProvider::getConnection()
*
*   Description          :
*
*   Arguments            :  desc
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*                           PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*                           PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
DbiConnection* AAAConnectionProvider::getConnection(const AAAConnectionDescription& pDesc)
{
    AAAConnectionPool *         pool        = nullptr;
    AAAConnectionPoolGuard      poolGuard;              /* PMSTA-30415 - 090318 - PMO */
    AAAConnectionDescription    desc        = pDesc;    /* DLA - PMSTA-29743 - 180209 */

    { /* PMSTA-19735 - 020415 - PMO */
        LockGuard guard(lock);

        std::map<AAAConnectionDescription,AAAConnectionPool*>::const_iterator it = pools.find(desc);

        if (it == pools.end() &&
            (desc.getType() == FinServer || desc.getType() == DispatchServer))
        {
            GEN_SetServerPoolConnection(false, &desc, false); /* DLA - PMSTA-25325 - 170125 */

            /* DLA - PMSTA-29743 - 180209 */
            if(desc.getModel() == UnknownRdbms)
            {
                AAAConnectionDescription desc2(desc.getType());
                desc = desc2;
            }
            it = pools.find(desc);
        }

        if(it == pools.end())
        {
            if (desc.getSilentMode() == false)
            {
                if (desc.getModel() == UnknownRdbms)
                {
                    throw  AAAInvalidPoolDescriptionException("server not running for description", desc);
                }
                else
                {
                    throw  AAAInvalidPoolDescriptionException("no pool found for description", desc);
                }
            }
            return nullptr;
        }

        pool = it->second;
    }

    DbiConnection* res = nullptr;

    if (pool !=  nullptr )
    {
        /* PMSTA-25644 - 141216 - PMO */
		/* PMSTA-34344 - TEB - 190319 */
		if ((FinServer == desc.getType() || DispatchServer == desc.getType() || SqlServer == desc.getType()) && 0 != desc.getUrl().compare(pool->getUrl()))
		{ // Configuration has changed
            pool->setUrl(desc);
        }

        res = pool->getConnection();

        if (nullptr != res &&
            res->isValid() == false &&
            pool->getConnectionSpecification().getConnectionPolicies().getConnectionPolicy() == ConnectAtCreate)
        {
            if ((FinServer == desc.getType() || DispatchServer == desc.getType() || SqlServer == desc.getType()))
            {
                if (EV_AAAInstallLevel == 0)
                {
                    desc.reload();
                    if (0 != desc.getUrl().compare(pool->getUrl()))
                    {
                        pool->setUrl(desc);
                    }
                }
            }
            pool->reconnect(*res);
        }

        /* PMSTA-24510 - 220816 - PMO */
        if (nullptr != res)
        {
            SV_NbUsedConnection.fetch_add(1);

            /* PMSTA-46681 - LJE - 230124 */
            res->getDescription().setDatabase(desc.getDatabase());
        }
    }
    else
    {
        throw  AAAInvalidPoolDescriptionException("no pool found for description", desc);
    }

    return res ;
}

/************************************************************************
*   Function             :  AAAConnectionProvider::getPoolStatus()
*
*   Description          :
*
*   Arguments            :
*
*
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
const AAAConnectionPoolStatus AAAConnectionProvider::getPoolStatus(const AAAConnectionDescription& desc)  const
{
	AAAConnectionPool* pool = nullptr;

    auto it = pools.find(desc);                                                                         /* PMSTA-21500 - 161015 - PMO */

    if (it != pools.end())                                                                              /* PMSTA-21500 - 161015 - PMO */
    {
        pool = it->second;                                                                              /* PMSTA-21500 - 161015 - PMO */
    }
    else
    {
        throw AAAInvalidPoolDescriptionException("no pool found for description", desc);
	}

    return AAAConnectionPoolStatus(desc, pool->getMaxSize(), pool->getAvaibleConnectionCount(), pool->getUsedConnectionCount(), pool->getStartId());
}

std::vector<AAAConnectionPoolStatus*>* AAAConnectionProvider::getPoolStatus() const
{
	std::vector<AAAConnectionPoolStatus*>* res = new std::vector<AAAConnectionPoolStatus*>();
	//for (auto &x : pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::const_iterator x = pools.begin(); x != pools.end(); ++x)
    {
		AAAConnectionPoolStatus* status = new AAAConnectionPoolStatus(x->first, x->second->getMaxSize(), x->second->getAvaibleConnectionCount(), x->second->getUsedConnectionCount(), x->second->getStartId());
		res->push_back(status) ;
	}
	return res ;
}


/************************************************************************
*   Function             :  AAAConnectionProvider::registerAllocator()
*
*   Description          :
*
*   Arguments            :  type
*                           model
*                           allocatorPtr
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                           PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
void AAAConnectionProvider::registerAllocator(const AAAConnectionType& type, const DBA_RDBMS_ENUM& model, AAACONNECTION_ALLOCATOR_FPTR allocatorPtr)
{
	LockGuard guard(lock);
	AAAConnectionAllocator conAlloc(type, model, allocatorPtr);

    auto it = allocatorMap.find(conAlloc.getKey());                                 /* PMSTA-19735 - 020415 - PMO */

    if (it == allocatorMap.end())                                                   /* PMSTA-19735 - 020415 - PMO */
    {
        this->allocatorMap.insert(std::make_pair(conAlloc.getKey(), conAlloc));     /* emplace is not implemented on AIX 13.1 compiler PMSTA-21500 - 161015 - PMO / PMSTA-19735 - 020415 - PMO */
    }
}

/************************************************************************
*   Function             : AAAConnectionProvider::isCredentialIdentical()
*
*   Description          : Determine if the credential stored in the pool are identicat to those passed as argument
*
*   Arguments            : 
*                          
*                          
*
*   Return               : true    yes
*                          false   no
*
*   Creation Date        : 
*
*   Last Modification    : PMSTA-49139 - FME - 2022-06-03 (renaming)
*
*************************************************************************/
bool AAAConnectionProvider::isCredentialIdentical(const AAAConnectionDescription& desc, const PasswordEncrypted& password)
{
	bool res = false;
    const AAAConnectionPool* pool = nullptr;
    {
        LockGuard guard(lock);
        std::map<AAAConnectionDescription, AAAConnectionPool*>::const_iterator it = pools.find(desc);

        if (it != pools.end())
        {
            pool = it->second;
        }
        else
        {
            throw  AAAInvalidPoolDescriptionException("no pool found for description", desc);
        }
    }

    if (pool != nullptr)
    {
        res = pool->isCredentialIdentical(desc.getUser().c_str(), password);

    }

	return res;
}

/************************************************************************
*   Function             : AAAConnectionProvider::validateDatabaseCredential()
*
*   Description          : Open a physical connection to the database just for password validation
*
*   Arguments            : the user and the encypted password to the user to connect on.
*
*   Return               : true    yes
*                          false   no
*
*   Creation Date        : PMSTA-49139 - FME - 2022-06-03
*
*   Last Modification    : 
*
*************************************************************************/
bool AAAConnectionProvider::validateDatabaseCredential(const std::string& userName, const PasswordEncrypted& password)
{
    bool result = false;
    const DBA_RDBMS_ENUM rdbms = EV_RdbmsVendor;
    std::string sqlServerName;
    GEN_GetApplInfo(ApplSqlServerName, sqlServerName);

    auto  it2 = allocatorMap.find(AAAConnectionAllocatorKey(SqlServer, rdbms));

    if (it2 != allocatorMap.end())
    {
        AAAConnectionAllocator  allocator = it2->second;
        AAAConnectionCredentials cred(userName, password);
        AAAConnectionPolicies policiesNotUsed (ConnectAtCreate, DisconnectAtRelease, 0, NoAging, 0);

        AAAConnectionSpecification spec (ROLE_USER, SqlServer, rdbms, cred, sqlServerName, policiesNotUsed);
        int idNotUsed = 666666;

        AAAConnection* connectionCreated = allocator.createConnection(spec, idNotUsed);

        if (connectionCreated != nullptr) 
        {
            connectionCreated->connect();
            if (connectionCreated->isConnected())
            {
                result = true;
                connectionCreated->disconnect();
            }
            delete connectionCreated;
        }
    }
    return result;
}



/************************************************************************
*   Function             :  AAAConnectionProvider::hasPool()
*
*   Description          :
*
*   Arguments            :  desc
*
*   Return               :  true    yes
*                           false   no
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
bool AAAConnectionProvider::hasPool(const AAAConnectionDescription& desc)
{
    LockGuard guard(lock);
    std::map<AAAConnectionDescription, AAAConnectionPool*>::const_iterator it = pools.find(desc);   /* PMSTA-19735 - 020415 - PMO */

    return it != pools.end();                                                                       /* PMSTA-19735 - 020415 - PMO */
}

void AAAConnectionProvider::setObserver(AAAConnectionPoolObserver * observer)
{
	LockGuard guard(lock);
	this->m_observer = observer;
	//for (auto &x : pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
    {
		x->second->setObserver(observer);
	}
}


/************************************************************************
*   Function             :  AAAConnectionProvider::release()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21500 - 161015 - PMO : Compilation fix
*
*************************************************************************/
void AAAConnectionProvider::release(DbiConnection* connection)
{
	AAAConnectionPool* pool = connection->getOwningPool();

	if (pool != nullptr)
    {
        LockGuard guard(lock);

        auto it2 = pools.find(connection->getDescription());                        /* PMSTA-21500 - 161015 - PMO */

        if (it2 != pools.end())                                                     /* PMSTA-21500 - 161015 - PMO */
        {
			pool = it2->second;                                                     /* PMSTA-21500 - 161015 - PMO */
		}
        else
        {
			throw AAAInvalidPoolDescriptionException("no pool found for connection description", connection->getDescription());
		}

        pool->release(connection);                                                  /* PMSTA-21500 - 161015 - PMO */
	}
}

/************************************************************************
*   Function             :  AAAConnectionProvider::addPoolReference()
*
*   Description          :  add a reference to this pool
*
*   Arguments            :
*
*   Return               :  the new number of reference
*
*   Last Modification    :  DLA - PMSTA-24234 - 160803
*
*************************************************************************/
int AAAConnectionProvider::addPoolReference(const AAAConnectionDescription& desc)
{
    LockGuard guard(lock);
    int ret = 0;
    auto poolIt = pools.find(desc);
    if (poolIt != pools.end())
    {
       poolIt->second->incRef();
       ret = poolIt->second->getRefNb();
    }
    return ret;
}

/************************************************************************
*   Function             :  AAAConnectionProvider::decPoolReference()
*
*   Description          :  decrement a reference to this pool
*
*   Arguments            :
*
*   Return               :  the new number of reference
*
*   Last Modification    :  DLA - PMSTA-24234 - 160803
*
*************************************************************************/
int AAAConnectionProvider::decPoolReference(const AAAConnectionDescription& desc)
{
    LockGuard guard(lock);
    int ret = 0;
    auto poolIt = pools.find(desc);
    if (poolIt != pools.end())
    {
        poolIt->second->decRef();
        ret = poolIt->second->getRefNb();
    }
    return ret;
}

/************************************************************************
*   Function             :  AAAConnectionProvider::updatePassword()
*
*   Description          :  Update the password for a given user (all pools are impacted)
*
*   Arguments            :  AAAConnectionDescription& PasswordEncrypted password
*
*   Return               :
*
*   Last Modification    :  PMSTA-29708 - DLA - 180507
*
*************************************************************************/
void AAAConnectionProvider::updatePassword(const std::string& user, const PasswordEncrypted& password)
{
	LockGuard guard(lock);
	//for (auto &x : pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
    {
		if (x->first.getUser() == user)
        {
			x->second->updatePassword(password);
		}
	}
}

/************************************************************************
*   Function             :  AAAConnectionProvider::updatePassword()
*
*   Description          :  Update the password for a given description (only the pool related to the description is impacted)
*                        :  This function should be used carefully, if no actions are doing after this call, the pools can be inconsistent (many passwords for one user)
*
*   Arguments            :  AAAConnectionDescription& PasswordEncrypted password
*
*   Return               :
*
*   Last Modification    :  PMSTA-29708 - DLA - 180507
*
*************************************************************************/
void AAAConnectionProvider::updatePassword(const AAAConnectionDescription& desc, const PasswordEncrypted& password)
{
	LockGuard guard(lock);
    auto poolIt = pools.find(desc);
    if (poolIt != pools.end())
    {
		poolIt->second->updatePassword(password);
	}
}

/************************************************************************
*   Function             :  AAAConnectionProvider::getEncryptedPassword()
*
*   Description          :  Retrun the encrypted password for a user
*
*   Arguments            :
*
*   Return               :  the new number of reference
*
*   Last Modification    :  PMSTA-29708 - DLA - 180507
*
*************************************************************************/
PasswordEncrypted AAAConnectionProvider::getEncryptedPassword(const std::string& user)
{
	LockGuard guard(lock);
	//for (auto &x : pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
    {
		if (x->first.getUser() == user)
        {
			return x->second->getConnectionSpecification().getCredentials().getPassword();
		}
	}
    return PasswordEncrypted();
}


DbiConnection* AAAConnectionProvider::find(const AAAConnectionType* typeScopeFilter, const char* user, const char* serverNameScopeFilter, bool(*searchFunc)(DbiConnection&, void*), void* searchArg)
{
    DbiConnection* res = nullptr;
	//for (auto &x : pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
    {
        if (x->first.match(typeScopeFilter, user, serverNameScopeFilter))
        {
			res = x->second->find(searchFunc, searchArg);
			if (res != nullptr)
            {
				break;
			}
		}
	}
	return res;
}

std::ostream& operator<<(std::ostream& os, const AAAConnectionProvider& obj)
{
    LockGuard guard((Lock&)obj.lock);
    //for (auto x : obj.pools)
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::const_iterator x = obj.pools.begin(); x != obj.pools.end(); ++x)
    {
         os << *x->second;
    }
    return os;
}

std::vector<AAAConnectionStatus> AAAConnectionProvider::getAllConnectionsStatus()
{
    std::vector<AAAConnectionStatus> listTmp;
    std::vector<AAAConnectionStatus> listPoolConnStatus;
    {
        LockGuard guard(lock);
        //for (auto &x : pools)
        for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
        {
            listTmp = x->second->getAllConnectionsStatus(AAAConnectionStatusParam());
            listPoolConnStatus.insert(listPoolConnStatus.end(), listTmp.begin(), listTmp.end());
        }
    }
    return listPoolConnStatus;
}

std::vector < std::pair<AAAConnectionPoolStatus, std::vector<AAAConnectionStatus>>> AAAConnectionProvider::getAllConnectionsStatusByPool(const AAAConnectionStatusParam& param)
{
    std::vector<AAAConnectionStatus> connListByPool;
    std::vector < std::pair<AAAConnectionPoolStatus, std::vector<AAAConnectionStatus>>> res;
    {
        LockGuard guard(lock);

        for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
        {
            AAAConnectionPoolStatus poolStatus = x->second->getStatus();
            connListByPool = x->second->getAllConnectionsStatus(param);
            res.push_back(std::make_pair(poolStatus, connListByPool));
        }
    }
    return res;
}



/************************************************************************
*   Function             :  AAAConnectionProvider::ApplyAllPolicies()
*
*   Description          :  Parse all pool to disconnect the unused connection with an Idle time > idleTimeout
*
*   Arguments            :
*
*   Return               :
*
*   Last Modification    :  DLA - PMSTA-24911 - 161003
*
*************************************************************************/
void AAAConnectionProvider::ApplyAllPolicies()
{
    LockGuard guard(lock);
    for (std::map< AAAConnectionDescription, AAAConnectionPool*>::iterator x = pools.begin(); x != pools.end(); ++x)
    {
        x->second->ApplyPolicies();
    }
}

/************************************************************************
*   Function             :  AAAConnectionProvider::startCleanupConnectionThread()
*
*   Description          :  Start the connection pools clean up thread.
*
*   Arguments            :
*
*   Return               :
*
*   Last Modification    :  DLA - PMSTA-24911 - 161003
*
*************************************************************************/
void AAAConnectionProvider::startCleanupConnectionThread()
{
    this->m_ownedByCaller = true;

    (void)SYS_SpawnAdministrativeThread(ThreadCleanupConnection, this, "CleanUp Connection");
}

/************************************************************************
*   Function             :  AAAConnectionProvider::stopCleanupConnectionThread()
*
*   Description          :  Stop the connection pools clean up thread.
*
*   Arguments            :
*
*   Return               :
*
*   Last Modification    :  DLA - PMSTA-24911 - 161003
*                           PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*
*************************************************************************/
void AAAConnectionProvider::stopCleanupConnectionThread()
{
    state.store(ThreadState::Leaving);              /* PMSTA-29083 - 041217 - PMO */
}

/************************************************************************
*   Function             :  AAAConnectionProvider::startCleanupConnectionThread()
*
*   Description          :  The connection polls clean up thread.
*
*   Arguments            :
*
*   Return               :
*
*   Last Modification    :  DLA - PMSTA-24911 - 161003
*                           PMSTA-29083 - 041217 - PMO : Fin srv crash while running the Valuation/PBA_PMSTA_14712 TaAutomator test case
*                           PMSTA-33076 - 071218 - PMO : Financial server crash when stopping
*
*************************************************************************/
void ThreadCleanupConnection(ThreadArg* obj)
{
    ThreadStateCycle            threadStateCycle(state);                            /* PMSTA-29083 - 041217 - PMO */

    /* Don't execute cleanup until the server has finish his initialization PMSTA-33076 - 071218 - PMO */
    while (true == SYS_IsStateInitialization())
    {
        SYS_MilliSleep(50);
    }

    if (threadStateCycle.isLeaving())
    {
        return;
    }

    AAAConnectionProvider * prov = dynamic_cast<AAAConnectionProvider *>(obj);

    const int               reapTime = SYS_GetEnvIntOrDefValue("AAACONNECTION_POOL_REAPTIME_THREAD", 180);
    
    int                     app_reapTime = reapTime;

    if (SYS_IsSrvMode())
    {
        app_reapTime = 0;
        GEN_GetApplInfo(ApplConnPoolReapTime, &app_reapTime);
        if (app_reapTime == 0)
        {
            app_reapTime = reapTime;
        }
    }

    if (app_reapTime > 0)
    {
        threadStateCycle.setRunning();

        const unsigned int  waitTime = SYS_IsSrvMode() ? 100 : 50;
        int                 iLoop = 0;
        size_t              count = 0;
        std::stringstream   sstm;

        while (true == threadStateCycle.isRunning() && true == SYS_IsStateRunning())    /* PMSTA-33076 - 071218 - PMO / DLA - PMSTA-29888 - 180201 */
        {
            /* DLA - PMSTA-25850 - 170224 */
            sstm.clear();
            sstm.str(std::string());
            sstm << "waiting, has been run " << count << " times";
            SYS_SetThreadStateDescription(sstm.str());
            SYS_MilliSleep(waitTime);
            if (true == threadStateCycle.isRunning() && true == SYS_IsStateRunning())   /* PMSTA-33076 - 071218 - PMO / DLA - PMSTA-29536 - 171211 / DLA - PMSTA-29888 - 180201 */
            {
                iLoop++;

                if (iLoop >= app_reapTime * 10)
                {
                    count++;
                    sstm.clear();
                    sstm.str(std::string());
                    sstm << "running count= " << count;
                    SYS_SetThreadStateDescription(sstm.str());
                    iLoop = 0;
                    prov->ApplyAllPolicies();
#ifdef AAADEBUGMSG
                    static bool traceCleanupConnection = SYS_GetEnvBoolOrDefValue("AAATRACE_CLEANUP_CONNECTION_THREAD", false);
                    if (traceCleanupConnection)
                    {
                        std::vector<AAAConnectionStatus> vector = prov->getAllConnectionsStatus();
                        for (auto x = vector.begin(); x != vector.end(); ++x)
                        {
                            std::cout << (*x) << std::endl;
                        }
                    }
#endif
                }
            }
        }
    }

    return;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <concredentials.h>

AAAConnectionCredentials::AAAConnectionCredentials(const std::string& user, const PasswordEncrypted& password)  {
	this->user = user ;
	this->password = password ;
}
AAAConnectionCredentials::AAAConnectionCredentials(const AAAConnectionCredentials& toCopy) {
	this->user = toCopy.getUser() ;
	this->password = toCopy.getPassword() ;
}
void AAAConnectionCredentials::operator=(const AAAConnectionCredentials& toCopy) {
	this->user = toCopy.getUser() ;
	this->password = toCopy.getPassword() ;
}
const std::string& AAAConnectionCredentials::getUser()const {
	return user ; 
}
const PasswordEncrypted& AAAConnectionCredentials::getPassword() const {
	return password; 
}

AAAConnectionCredentials::AAAConnectionCredentials(){
}

AAAConnectionCredentials::~AAAConnectionCredentials(){
}

bool AAAConnectionCredentials::match(const char* userGiven, const PasswordEncrypted& passwordToCompare) const {
	bool result = this->user.compare(userGiven) == 0;
	if (result)
	{
		result = password.match(passwordToCompare) == true;
	}
	return result;
}

std::ostream& operator<<(std::ostream& os, const AAAConnectionCredentials& desc){
	os << "AAAConnectionCredentials[" << "user:" << desc.getUser() << ",password:" << "*******"  << "]";
	return os;
}
void AAAConnectionCredentials::updatePassword(const PasswordEncrypted& passwordGiven) {
	this->password = passwordGiven;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <iostream>
#include "unidef.h"

#include "aaaconnection.h"
#include "conpool.h"
#include "unidef.h"
#include "syslib.h"
#include "dba.h"
#include "conexcept.h"

extern int EV_AAAInstallLevel;

/**
* Semantic constructor
* @param context the context name
* @param propertyName the property name
* @param propertyValue the property value
*/
AAASessionProperty::AAASessionProperty(const std::string& propertyName, const std::string& propertyValue)
    : m_propertyName(propertyName)
    , m_propertyValue(propertyValue)
{
}

AAASessionProperty::AAASessionProperty(const AAASessionProperty& toCopy)
    : m_propertyName(toCopy.m_propertyName)
    , m_propertyValue(toCopy.m_propertyValue)
{
}

/************************************************************************
*   Function             :  AAASessionProperty::operator=()
*
*   Description          :  Operator equal
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-24076 - 180716 - PMO : Unstable connections
*
*   Last Modification    :
*
*************************************************************************/
AAASessionProperty & AAASessionProperty::operator=(const AAASessionProperty & src)
{
    m_propertyName = src.m_propertyName;
    m_propertyValue = src.m_propertyValue;

    return *this;
}

/**
* @return the property name
*/
std::string AAASessionProperty::getPropertyName() const
{
    return(this->m_propertyName);
}

/**
* @return the property value
*/
const std::string& AAASessionProperty::getPropertyValue() const
{
    return this->m_propertyValue;
}

AAAConnection::AAAConnection(const AAAConnectionSpecification& spec, const int& _id) :  specification(spec)
{
    this->statmentAllocatedNb        = 0;
    this->m_onApplySessionProperties = false;                                /* PMSTA-nuodb - LJE - 190806 */
    this->owningPool                 = nullptr;
    this->owningLocalProvider        = nullptr;
    this->state                      = AAAConnectionState::AVAILABLE;
    this->connectionTime             = 0;
    this->startProcTime              = 0;
    this->id                         = _id;
    this->connected                  = false;
    this->connectionDescription      = nullptr;
    this->threadId                   = SYS_GetThreadId();
    this->isValidConnection          = true;
    this->IdleTime                   = 0;
    this->connectionTime             = 0;
    this->m_usedConnectionNbr        = 0;
    this->m_tempTablesMask           = 0;
}

/************************************************************************
*   Function             :  AAAConnection::~AAAConnection()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*   Last Modification    :  PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*************************************************************************/
AAAConnection::~AAAConnection(void)
{
    this->freeDescription();           /* PMSTA-26427 - 240217 - PMO */

    /* PMSTA-30415 - 090318 - PMO */
    this->statmentAllocatedNb   = 0;
    this->owningPool            = nullptr;
    this->owningLocalProvider   = nullptr;
    this->state                 = AAAConnectionState::DEAD_FOOD;
    this->connectionTime        = 0;
    this->startProcTime         = 0;
    this->id                    = 0;
    this->connected             = false;
    this->threadId              = 0;
    this->isValidConnection     = false;
    this->IdleTime              = 0;
    this->connectionTime        = 0;
    this->m_usedConnectionNbr   = 0;
    this->m_tempTablesMask      = 0;
}

bool AAAConnection::matchId(const int& _id) const
{
    return this->id == _id ;
}

/************************************************************************
*   Function             :  AAAConnection::getId()
*
*   Description          :  Return the connecto no. Thisis a legacy function
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-22990 - 080416 - PMO : Financial server crash during logical fusion for check strat
*
*************************************************************************/
int& AAAConnection::getId() const
{
	return id;
}

void AAAConnection::setId(const int& _id)
{
	this->id = _id ;
}

const AAAConnectionSpecification& AAAConnection::getSpecification() const
{
	return this->specification;
}

void AAAConnection::setValidConnection(bool value)
{
    this->isValidConnection = value;
}

void AAAConnection::release()
{
    #ifdef AAACONNECTIONTRACE
        this->stackWhenUsed.clear();
    #endif
}

bool AAAConnection::isValid()
{
    return this->isValidConnection && this->isInUse() && this->isConnected();
}

const std::string& AAAConnection::getActualDbName() const
{
    return this->getConnSessionProperties().getDbName();
}

void AAAConnection::setDbName(const std::string& dbName)
{
    this->getTargetSessionProperties().setDbName(dbName);
}

RET_CODE AAAConnection::setDefaultProperties()
{
    return RET_SUCCEED;
}

void AAAConnection::setSessionProperties(const SessionProperties &sessionProperties)
{
    this->m_targetSessionProperties = sessionProperties;
}

const SessionProperties &AAAConnection::getConnSessionProperties() const
{
    return this->m_connSessionProperties;
}

SessionProperties &AAAConnection::getConnSessionPropertiesForUpd()
{
    return this->m_connSessionProperties;
}

SessionProperties &AAAConnection::getTargetSessionProperties()
{
    return this->m_targetSessionProperties;
}

RET_CODE AAAConnection::applyPropertiesOnConnection()
{
    RET_CODE ret = RET_SUCCEED;
    if (this->m_onApplySessionProperties == false)
    {
        AAAValueGuardBool onApplySessionProperties(this->m_onApplySessionProperties, true);

        if (this->isValid() == false || this->checkDbConn() == false)
        {
            try
            {
                if (this->reconnect() == false)
                {
                    ret = RET_DBA_ERR_DBPROBLEM;
                }
            }
            catch (AAACannotConnectDbException& e)
            {
                MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());
                ret = RET_DBA_ERR_CONNOTFOUND;
            }
        }
        this->pushSqlRequest(KindOfRequest::InitSession);

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->m_connSessionProperties.isSetDefaultProp() == false)
        {
            ret = this->setDefaultProperties();
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                this->m_connSessionProperties.setSetDefaultProp();
            }
        }

        /* PMSTA-34402 - LJE - 190121 */
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->m_targetSessionProperties.getDateTimeFormat() != this->m_connSessionProperties.getDateTimeFormat() &&
            this->m_targetSessionProperties.getDateTimeFormat() != DateStyle_None)
        {
            this->setDateTimeFormat(this->m_targetSessionProperties.getDateTimeFormat());
            this->m_connSessionProperties.setDateTimeFormat(this->m_targetSessionProperties.getDateTimeFormat());
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->m_targetSessionProperties.isDeferredNameResolution() != this->m_connSessionProperties.isDeferredNameResolution())
        {
            // ret = this->setDeferredNameResolution(this->m_targetSessionProperties.isDeferredNameResolution()); -> TODO
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                this->m_connSessionProperties.setDeferredNameResolution(this->m_targetSessionProperties.isDeferredNameResolution());
            }
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->m_targetSessionProperties.getDbName().empty() == false)
        {
            /* PMSTA-34402 - LJE - 190121 */
            if (strcasecmp(this->m_targetSessionProperties.getDbName().c_str(), this->m_connSessionProperties.getDbName().c_str()) != 0)
            {
                this->useDb(this->m_targetSessionProperties.getDbName());
            }

            if (EV_AAAInstallLevel <= 2) /* PMSTA-37366 - LJE - 191118 */
            {
                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.getApplSessionCd() != this->m_connSessionProperties.getApplSessionCd())
                {
                    if (EV_DictInitFlg == TRUE)
                    {
                        bool oldUseServerUser = SYS_GetThreadUseServerUser();
                        if (this->getDescription().getRole() == ROLE_ADMIN)
                        {
                            SYS_SetThreadUseServerUser(true);
                        }
                        DBA_DYNFLD_STP applSessionStp = this->m_targetSessionProperties.getApplSessionStp();
                        SYS_SetThreadUseServerUser(oldUseServerUser);
                        ret = this->setApplSession(applSessionStp);
                    }
                }
                else if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                         this->m_connSessionProperties.getApplSessionCd().empty())
                {
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                        this->m_targetSessionProperties.getUserId() != this->m_connSessionProperties.getUserId())
                    {
                        ret = this->setAppContext("user_id", this->m_targetSessionProperties.getUserId());
                        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                        {
                            this->m_connSessionProperties.setUserId(this->m_targetSessionProperties.getUserId());
                        }
                    }
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                        this->m_targetSessionProperties.getDataProfileId() != this->m_connSessionProperties.getDataProfileId())
                    {
                        ret = this->setAppContext("data_profile_id", this->m_targetSessionProperties.getDataProfileId());
                        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                        {
                            this->m_connSessionProperties.setDataProfileId(this->m_targetSessionProperties.getDataProfileId());
                        }
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.getMainDlmEnMax() != this->m_connSessionProperties.getMainDlmEnMax())
                {
                    ret = this->setPropertyByStoredProc("set_main_dlm_e_max", (ENUM_T)this->m_targetSessionProperties.getMainDlmEnMax());
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        this->m_connSessionProperties.setMainDlmEnMax(this->m_targetSessionProperties.getMainDlmEnMax());
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.getAddDlmEnMax() != this->m_connSessionProperties.getAddDlmEnMax())
                {
                    ret = this->setPropertyByStoredProc("set_add_dlm_e_max", (ENUM_T)this->m_targetSessionProperties.getAddDlmEnMax());
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        this->m_connSessionProperties.setAddDlmEnMax(this->m_targetSessionProperties.getAddDlmEnMax());
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.getModifStat() != this->m_connSessionProperties.getModifStat())
                {
                    ret = this->setPropertyByStoredProc("set_modif_stat_mask", this->m_targetSessionProperties.getModifStat());
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        this->m_connSessionProperties.setModifStat(this->m_targetSessionProperties.getModifStat());
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.isSetConnUser() != this->m_connSessionProperties.isSetConnUser())
                {
                    ret = this->setPropertyByStoredProc("set_connected_user");
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        this->m_connSessionProperties.setSetConnUser();
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    this->m_targetSessionProperties.getLanguageDictId() != this->m_connSessionProperties.getLanguageDictId())
                {
                    ret = this->setLanguageDictId(this->m_targetSessionProperties.getLanguageDictId());
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        this->m_connSessionProperties.setLanguageDictId(this->m_targetSessionProperties.getLanguageDictId());
                    }
                }
            }
        }

        this->popSqlRequest();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        return ret;
    }
    else
    {
        return (RET_DBA_ERR_INVALID_SESSION);
    }
}

RET_CODE AAAConnection::removePropertiesOnConnection()
{
    RET_CODE ret = RET_SUCCEED;

    this->m_targetSessionProperties.resetSessionproperties();
    ret = this->applyPropertiesOnConnection();
    return ret;
}

bool AAAConnection::isInUse (void) const
{
	return state == AAAConnectionState::IN_USE;
}

bool AAAConnection::isExpired(const unsigned long& maxAge)
{
    if (maxAge == 0)
    {
        return false;
    }
    time_t now = time(NULL);
    return (now - connectionTime > time_t(maxAge));
}

bool AAAConnection::isIdleTimeOut(const unsigned long& maxIdleTime)
{
    if (maxIdleTime == 0)
    {
        return false;
    }

    time_t now = time(NULL);
    return (now - IdleTime > time_t(maxIdleTime));
}

const time_t &AAAConnection::getConnectionTime() const
{
	return connectionTime;
}

const time_t &AAAConnection::getIdleTime() const
{
    return IdleTime;
}

const time_t &AAAConnection::getStartProcTime() const
{
    return startProcTime;
}

const time_t &AAAConnection::setStartProcTime()
{
    return startProcTime = time(NULL);
}

void AAAConnection::resetStartProcTime()
{
    startProcTime = 0;
}

void AAAConnection::resetIdleTime()
{
    IdleTime = time(NULL);
}

void AAAConnection::setConnected(bool connectFlag)
{
    this->connected = connectFlag;
    if (connectFlag)
    {
        this->connectionTime = time(NULL);
    }
    else
    {
        this->connectionTime = 0;
    }
}

bool AAAConnection::isConnected() const
{
    return this->connected;
}

AAAConnectionDescription& AAAConnection::getDescription()
{
    if (this->connectionDescription == nullptr)
    {
        this->connectionDescription = new AAAConnectionDescription(this->getSpecification());
    }
    return *this->connectionDescription;
}


/************************************************************************
*   Function             :  AAAConnection::freeDescription()
*
*   Description          :  Free the description
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnection::freeDescription()
{
    delete connectionDescription;
    connectionDescription = nullptr;
}


/************************************************************************
*   Function             :  AAAConnection::reloadDescription()
*
*   Description          :  Reload the description (configuration has changed)
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void AAAConnection::reloadDescription()
{
    connectionDescription->reload();
}

const AAAConnectionState& AAAConnection::getState() const
{
    return this->state;
}

/************************************************************************
*   Function             :  operator<<
*
*   Description          :  Return the connection state as string
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*   Last Modification    :
*
*************************************************************************/
std::string AAAConnection::getStateLabel() const
{
    return AAAConnection::getStateLabel(getState());
}

std::string AAAConnection::getStateLabel(const AAAConnectionState & connectionState)
{
    std::string state = "UNKNOWN";

    switch (connectionState)
    {
        case AAAConnectionState::AVAILABLE:
        case AAAConnectionState::TRANS_OPEN:
            state = "AVAILABLE";
            break;

        case AAAConnectionState::IN_USE:
            state = "USED";
            break;

        case AAAConnectionState::DEAD_FOOD:
            state = "DEAD";
            break;
    }

    return state;
}


void AAAConnection::setState(const AAAConnectionState& _state)
{
    this->state = _state;
}

/************************************************************************
*   Function             :  operator<<
*
*   Description          :  Return the connection status
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*   Last Modification    :
*
*************************************************************************/
std::ostream& operator<<(std::ostream& os, const AAAConnection& obj)
{
    os << "AAAConnection[" << "id=" << obj.getId() << ",specification:" << obj.getSpecification() << ",state:" << obj.getStateLabel() << "]";   /* PMSTA-30415 - 090318 - PMO */
    return os;
}

void AAAConnection::updatePassword(const PasswordEncrypted& password)
{
	this->specification.updatePassword(password);
}

void AAAConnection::setThreadId()
{
    threadId = SYS_GetThreadId();
}

void AAAConnection::resetThreadId()
{
    threadId = 0;
}

TID_T AAAConnection::getThreadId()
{
    return threadId;
}


/************************************************************************
*   Function             :  AAAConnection::assertThreadConnectionCoherence()
*
*   Description          :  Check if the connection was attribued to this thread.
*                           But dispatcher connection are not checked since they are shared between threads
*
*   Arguments            :
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*************************************************************************/
void AAAConnection::assertThreadConnectionCoherence()
{
    if (SYS_IsSrvMode() && SYS_GetThreadId() != threadId && DispatchServer != specification.getType())  /* PMSTA-21215 - 271015 - PMO */ /* DLA - PMSTA-26026 - 170201 - This test is useful for a server, and moreover does not work with the Gatit because it's not the same thread that initializes connections */
    {
        MSG_SendMesg(FILEINFO, SYS_Stringer("!!!!!!! Connection threadId discrepancy: Thread:", SYS_ToString(SYS_GetThreadId()), " vs ", SYS_ToString(threadId), " !!!!!!!"));
        // assert(987614 == 7987);
    }
}

bool  AAAConnection::mustCreateTempTables()
{
    if (this->getDescription().getType() == SqlServer && 
        this->getDescription().getModel() != QtHttp &&
        this->getDescription().getRole() != ROLE_DBSO &&
        this->getDescription().getRole() != ROLE_INIT &&
        this->m_tempTablesMask == 0)
    {
        return true;
    }
    return false;
}

AAAConnectionStatus::AAAConnectionStatus(const AAAConnectionSpecification& _spec) :
    spec(_spec),
    id(-1),
    state(AAAConnectionState::AVAILABLE),
    connected(false),
    threadId(0),
    chasetNameName(""),
    connectionTime(0),
    currentProcTime(0),
    idleTime(0),
    m_callStackStr(""),
    sessionCd(""),
    m_callStack(true)
{
}


/************************************************************************
*   Function             :  AAAConnectionStatus & AAAConnectionStatus()
*
*   Description          :  Equal operator
*
*   Arguments            :  src Data source
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-24076 - 180716 - PMO : Unstable connections
*
*   Last Modification    :
*
*************************************************************************/
AAAConnectionStatus & AAAConnectionStatus::operator=(const AAAConnectionStatus & src)
{
    spec            = src.spec;
    id              = src.id;
    state           = src.state;
    connected       = src.connected;
    threadId        = src.threadId;
    chasetNameName  = src.chasetNameName;
    connectionTime  = src.connectionTime;
    currentProcTime = src.currentProcTime;
    idleTime        = src.idleTime;
    m_callStackStr  = src.m_callStackStr;
    sessionCd       = src.sessionCd;
    m_callStack     = src.m_callStack;

    return *this;
}


/************************************************************************
*   Function             :  AAAConnectionStatus::setCallStack()
*
*   Description          :  Allow to display the callstack when calling operator<<
*
*   Arguments            :  callStack
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionStatus::setCallStack(const bool & callStack)
{
    m_callStack = callStack;
}


/************************************************************************
*   Function             :  AAAConnectionStatus::setThreadId()
*
*   Description          :  Define the thread ID
*
*   Arguments            :  thread ID
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionStatus::setThreadId(TID_T _threadId)
{
    threadId = _threadId;
}


/************************************************************************
*   Function             :  AAAConnectionStatus::setSessionCd()
*
*   Description          :  Define the session code
*
*   Arguments            :  Session code
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionStatus::setSessionCd(const std::string & _sessionCd)
{
    sessionCd = _sessionCd;
}


std::ostream& operator<<(std::ostream& os, const AAAConnectionStatus& obj)
{
    os << obj.spec;
    os << "id=" << obj.id << " state=" << (obj.state == AAAConnectionState::AVAILABLE ? "AVAILABLE" : "IN_USE") << " connected=" << (obj.connected ? "YES" : "NO")  << " threadId=" << obj.threadId << " charset=" << obj.chasetNameName
        << " connectTime=" << obj.connectionTime << " idleTime=" << obj.idleTime << " sessionCd=" << obj.sessionCd <<"\n";

    if (true == obj.m_callStack)
    {
        os << "    callstack :\n" << (obj.m_callStackStr.length() == 0 ? "To get callstack set AAACONNECTIONPOOLTRACE=2 " : obj.m_callStackStr);
    }

    return os;
}

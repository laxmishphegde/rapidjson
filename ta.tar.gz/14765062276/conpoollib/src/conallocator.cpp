/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"
#include "conallocator.h"

AAAConnectionAllocatorKey::AAAConnectionAllocatorKey(const AAAConnectionType& type, const DBA_RDBMS_ENUM& model)
{
    this->type = type;
    this->model = model;
}
AAAConnectionAllocatorKey::AAAConnectionAllocatorKey(const AAAConnectionAllocatorKey& toCopy)
{
    this->type = toCopy.type;
    this->model = toCopy.model;
}
void AAAConnectionAllocatorKey::operator=(const AAAConnectionAllocatorKey& toCopy)
{
    this->type = toCopy.type;
    this->model = toCopy.model;
}

bool AAAConnectionAllocatorKey::operator== (const AAAConnectionAllocatorKey& toCopy) const
{
    return (this->type == toCopy.getType()) && (this->model == toCopy.getModel());
}
const AAAConnectionType&  AAAConnectionAllocatorKey::getType() const
{
    return type;
}
const DBA_RDBMS_ENUM& AAAConnectionAllocatorKey::getModel()  const
{
    return model;
}

AAAConnectionAllocator::AAAConnectionAllocator(const AAAConnectionType& type, const DBA_RDBMS_ENUM& model, AAACONNECTION_ALLOCATOR_FPTR allocatorPtr): key(type, model)
{

    this->alloFunc = allocatorPtr;
}


AAAConnectionAllocator::AAAConnectionAllocator(const AAAConnectionAllocator& toCopy): key(toCopy.key)
{
    this->alloFunc = toCopy.alloFunc;
}
void AAAConnectionAllocator::operator=(const AAAConnectionAllocator& toCopy)
{
    this->key = toCopy.key;
    this->alloFunc = toCopy.alloFunc;
}

const AAAConnectionType&  AAAConnectionAllocator::getType() const
{
    return key.getType();
}

const DBA_RDBMS_ENUM& AAAConnectionAllocator::getModel()  const
{
    return key.getModel();
}

AAAConnection* AAAConnectionAllocator::createConnection(const AAAConnectionSpecification& spec, const int& id)
{
    return (*alloFunc)(spec, id);
}
const AAAConnectionAllocatorKey& AAAConnectionAllocator::getKey() const
{
    return key;
}


bool AAAConnectionAllocatorKey::operator <(const AAAConnectionAllocatorKey& toCompare) const
{
    if (type < toCompare.type)
        return true;

    if (type != toCompare.type)
        return false;

    if (model < toCompare.model)
        return true;

    return false;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"
#include "conpoolevent.h"

static char eventTypeNames[ConnectionPoolEventLast][50] = {
	"ConnectionCreated",
	"ConnectionDeleted",
	"ConnectionTaken",
	"ConnectionReleased",
	"ConnectionConnected",
	"ConnectionDisconnected",
    "ConnectionReleaseError"
};

AAAConnectionPoolEvent::AAAConnectionPoolEvent(const AAAConnectionPoolEventType& eventType, const AAAConnectionDescription& descriptor, const int& connectionId, const AAAConnectionPoolStatus& poolStatus, bool successfull, const unsigned long &duration)
: descriptor(descriptor), eventType(eventType), connectionId(connectionId), poolStatus(poolStatus), duration(duration), successfull(successfull){
}
AAAConnectionPoolEvent::AAAConnectionPoolEvent(const AAAConnectionPoolEvent& toCopy)
: descriptor(toCopy.getDescriptor()), eventType(toCopy.getEventType()), connectionId(toCopy.getConnectionId()), poolStatus(toCopy.getPoolStatus()), duration(toCopy.getDuration()), successfull(toCopy.isSuccessfull()) {
}
const AAAConnectionDescription& AAAConnectionPoolEvent::getDescriptor()  const { return descriptor; }
const AAAConnectionPoolEventType& AAAConnectionPoolEvent::getEventType()  const { return eventType; }
const int& AAAConnectionPoolEvent::getConnectionId()  const { return connectionId; }
const AAAConnectionPoolStatus& AAAConnectionPoolEvent::getPoolStatus()  const { return poolStatus; }
const unsigned long& AAAConnectionPoolEvent::getDuration()  const { return duration; }
const bool& AAAConnectionPoolEvent::isSuccessfull() const { return successfull; }

std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolEvent& obj) {
    
	os << "AAAConnectionPoolEvent["
		<< "description=" << obj.getDescriptor()
		<< ", eventType=" << eventTypeNames[obj.getEventType()]
		<< ", connectionId= " << obj.getConnectionId()
		<< ", poolStatus=" << obj.getPoolStatus()
		<< "]";
		return os;
}


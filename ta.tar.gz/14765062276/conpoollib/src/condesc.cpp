/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"
#include "msg.h"
#include "dba.h"
#include "dbiconnection.h"
#include <conexcept.h>
#include <random>

static std::string typeNameTab[] = {
        "NullServer",
        "SqlServer",
        "FinServer",
        "InternalProc",
		"DispatchServer"};

AAASTATIC_ASSERT(sizeof(typeNameTab) / sizeof(typeNameTab[0]) == LastServerType + 1);

extern DBA_RDBMS_ENUM EV_RdbmsVendor;

static std::string rdbmsNameTab[] = {
    "Sybase",
    "Oracle",
    "QtHttp",
    "NuoDB",
    "MSSql",
    "Sqlite",
    "PostgreSQL",
    "Unknown"};

AAASTATIC_ASSERT(sizeof(rdbmsNameTab) / sizeof(rdbmsNameTab[0]) == UnknownRdbms + 1);

static std::string roleNameTab[] = {
    "Init",
    "Admin",
    "User",
    "Security",
    "SSO",
    "ProxyUser"}; /* PMSTA-34344 - LJE - 201221 */

AAASTATIC_ASSERT(sizeof(roleNameTab) / sizeof(roleNameTab[0]) == LAST_ROLE);

static std::string schemeNameTab[] = {
    "HTTP",
    "HTTPS",
    "OpenServer"};

AAASTATIC_ASSERT(sizeof(schemeNameTab) / sizeof(schemeNameTab[0]) == Scheme_Last);

ServerClientConfig    EV_CurrentSrvConfig("");

static ClientConfig        SV_configClient;

extern bool                EV_IsProxyServer;               /* PMSTA-34344 - LJE - 210215 */

/************************************************************************
*   Function             :  AAAConnectionDescription::AAAConnectionDescription()
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  PMSTA-26108 - LJE - 171122
*
*   Last Modification    :
*
*************************************************************************/
AAAConnectionDescription::AAAConnectionDescription(const AAAConnectionRole& role)
    : AAAConnectionDescription(SqlServer, std::string(), role)
{

}

/************************************************************************
*   Function             :  AAAConnectionDescription::AAAConnectionDescription()
*
*   Description          :  Constructor
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
AAAConnectionDescription::AAAConnectionDescription(const  AAAConnectionType& type,
                                                   const std::string& serverName,
                                                   const AAAConnectionRole& role,
                                                   const DBA_RDBMS_ENUM& model,
                                                   const std::string& urlStr)
    : m_type(type)
    , m_model(model)
    , m_role(role)
    , m_serverName(serverName)
    , m_url(urlStr)
    , m_bSilentMode(false)
    , m_bReloadProcess(false)
{
    if (this->m_type != NullServer)
    {
        if (this->m_type == InternalProc)
        {
            this->m_type = SqlServer;
        }

        if (CON_POOL_IS_INIT() == TRUE)
        {
            if (this->m_role == ROLE_INIT)
            {
                this->m_role = ROLE_ADMIN;
            }

            if (this->m_role == ROLE_USER && SYS_IsSrvMode() == FALSE)
            {
                this->m_role = ROLE_ADMIN;
            }

			/* PMSTA-26108 - 171116 - DDV - For server when "Use Server User" is on, use ROLE_ADMIN */
            if (SYS_IsSrvMode() == TRUE)
            {
                if (this->m_type == DispatchServer)
                {
                    this->m_role = ROLE_ADMIN;
                }
                else if (SYS_GetThreadUseProxyUser() == true)
                {
                    this->m_role = ROLE_PROXY;
                }
                else if (SYS_GetThreadUseServerUser() == true)
                {
                    this->m_role = ROLE_ADMIN;
                }
            }
        }
        else if (this->m_role == ROLE_USER || this->m_role == ROLE_ADMIN)
        {
            this->m_role = ROLE_INIT;
        }

        if (this->m_serverName.empty())
        {
            switch (type)
            {
                case SqlServer:
                case InternalProc:
                    this->m_serverName = DBI_GetSqlServerName();
                    break;

                case DispatchServer:
                    if (SYS_IsGuiMode() == FALSE)
                    {
                        this->m_serverName = GEN_GetDispatcherName();
                        break;
                    }

                case FinServer:
                    GEN_GetApplInfo(ApplServerName, this->m_serverName);
                    break;

                default:
                    /* Leave blank */
                    break;
            }
        }

        if (this->m_model == UnknownRdbms)
        {
            if (this->m_type == SqlServer || this->m_type == InternalProc)
            {
                this->m_model = EV_RdbmsVendor;

				/* PMSTA-34344 - TEB - 190319 */
				if (this->m_model == QtHttp && this->m_url.empty())
				{
                    this->m_url = this->m_serverName;
				}
            }
            else if (this->m_serverName.empty() == false)
			{
                if (EV_CurrentSrvConfig.getServerName().compare(this->m_serverName) == 0)
                {
                    this->m_model = EV_CurrentSrvConfig.getServerModel();
                    this->m_url   = EV_CurrentSrvConfig.getUrl();
                }
                else
                {
                    loadConfig();   /* PMSTA-25644 - 141216 - PMO */
                }
            }
        }

        if (this->m_role == ROLE_SECURITY)
        {
            this->m_user = "aaa_login_manager";
        }
        else if (this->m_role == ROLE_DBSO)
        {
            const char *username = getenv("SSO_USER");

            if (username == nullptr || username[0] == END_OF_STRING)
            {
                username = getenv("SA_USER");
            }

            if (username == nullptr || username[0] == END_OF_STRING)
            {
                this->m_user = GEN_GetUserLogin();
            }
            else
            {
                this->m_user = username;
            }
        }
        else if (this->m_role == ROLE_USER && SYS_IsSrvMode())
        {
            this->m_user = SYS_GetThreadUser();
        }
        else if (this->m_role == ROLE_PROXY)
        {
            DBA_GetProxyUser(this->m_user);
        }
        else
        {
            this->m_user = GEN_GetUserLogin();
        }
    }
}

AAAConnectionDescription::AAAConnectionDescription(const AAAConnectionSpecification& specification):
        AAAConnectionDescription(specification.getType(),
                                 specification.getServerName(),
                                 specification.getRole(),
                                 specification.getModel(),
                                 specification.getServerUrl())
{
    this->m_user = specification.getCredentials().getUser();
}


/************************************************************************
*   Function             :  AAAConnectionDescription::AAAConnectionDescription()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-27303 - 220517 - PMO : AAAConnectionProvider::getConnection: Conditional jump or move depends on uninitialised value(s)
*
*************************************************************************/
AAAConnectionDescription::AAAConnectionDescription(const AAAConnectionDescription& toCopy)
{
    this->m_type               = toCopy.getType();
    this->m_model              = toCopy.getModel();
    this->m_role               = toCopy.getRole();
    this->m_serverName         = toCopy.getServerName();
    this->m_user               = toCopy.getUser();
    this->m_url                = toCopy.getUrl();
    this->m_bSilentMode        = toCopy.getSilentMode();               /* PMSTA-27303 - 220517 - PMO */
    this->m_bReloadProcess     = toCopy.m_bReloadProcess;              /* PMSTA-34344 - LJE - 201028 */
    this->m_database           = toCopy.m_database;                    /* PMSTA-46681 - LJE - 230124 */
}


/************************************************************************
*   Function             :  AAAConnectionDescription::operator=()
*
*   Description          :
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-27303 - 220517 - PMO : AAAConnectionProvider::getConnection: Conditional jump or move depends on uninitialised value(s)
*
*************************************************************************/
 AAAConnectionDescription & AAAConnectionDescription::operator=(const AAAConnectionDescription & toCopy)
{
    this->m_type               = toCopy.getType();
    this->m_model              = toCopy.getModel();
    this->m_role               = toCopy.getRole();
    this->m_serverName         = toCopy.getServerName();
    this->m_user               = toCopy.getUser();
    this->m_url                = toCopy.getUrl();
    this->m_bSilentMode        = toCopy.getSilentMode();               /* PMSTA-27303 - 220517 - PMO */
    this->m_bReloadProcess     = toCopy.m_bReloadProcess;              /* PMSTA-34344 - LJE - 201028 */
    this->m_database           = toCopy.m_database;                    /* PMSTA-46681 - LJE - 230124 */

    return *this;
}

bool AAAConnectionDescription::operator== (const AAAConnectionDescription& toCompare) const
{
    return
        (this->m_type       == toCompare.getType()) &&
        (this->m_model      == toCompare.getModel()) &&              /* PMSTA-nuodb - LJE - 190412 */
        (this->m_role       == toCompare.getRole()) &&
        (this->m_serverName == toCompare.getServerName()) &&
		(this->m_user		== toCompare.getUser() &&
		(this->m_url		== toCompare.getUrl()) &&
        (this->m_database   == toCompare.getDatabase()));
}

bool AAAConnectionDescription::operator< (const AAAConnectionDescription& toCompare) const
{
    if (this->m_type < toCompare.getType())
        return true;

    if (this->m_type != toCompare.getType())
        return false;

    if (this->m_model < toCompare.getModel())
        return true;

    if (this->m_model != toCompare.getModel())
        return false;

    if (this->m_role < toCompare.getRole())
        return true;

    if (this->m_role != toCompare.getRole())
        return false;

    if (this->m_serverName < toCompare.getServerName())
        return true;

    if (this->m_serverName != toCompare.getServerName())
        return false;

    if (this->m_user < toCompare.getUser())
        return true;

    if (this->m_user != toCompare.getUser())
        return false;

    return false;
}

bool AAAConnectionDescription::match(const AAAConnectionType* typeScopeFilter,
                                     const char* user,
                                     const char* serverNameScopeFilter) const
{
    return		 (((typeScopeFilter == nullptr) || (getType() == *typeScopeFilter))
                  && ((serverNameScopeFilter == nullptr) || (getServerName().compare(serverNameScopeFilter)))
                  && ((user == nullptr) || (getUser().compare(user))));

}

const AAAConnectionType& AAAConnectionDescription::getType() const
{
    return m_type;
}

const  std::string& AAAConnectionDescription::getTypeName() const
{
    return typeNameTab[this->m_type + 1];
}

const DBA_RDBMS_ENUM& AAAConnectionDescription::getModel() const
{
    return m_model;
}

const std::string& AAAConnectionDescription::getModelName() const
{
    return rdbmsNameTab[m_model];
}

void AAAConnectionDescription::setModel(const DBA_RDBMS_ENUM &newModel)
{
    this->m_model = newModel;
}

const AAAConnectionRole& AAAConnectionDescription::getRole() const
{
    return m_role;
}

const std::string& AAAConnectionDescription::getRoleName() const
{
    return roleNameTab[this->m_role];
}

const std::string& AAAConnectionDescription::getUser() const
{
    return m_user;
}

void AAAConnectionDescription::setUser(const std::string& user)
{
    this->m_user = user;
}

const std::string& AAAConnectionDescription::getServerName() const
{
    return m_serverName;
}

void AAAConnectionDescription::setServerName(const std::string &newServerName)
{
    this->m_serverName = newServerName;
}

void AAAConnectionDescription::setUrl(const std::string &newUrl)
{
    this->m_url = newUrl;
}

const std::string& AAAConnectionDescription::getUrl() const
{
    if (m_url.empty() == true)
    {
        return m_serverName;
    }
    else
    {
        return m_url;
    }
}

AAAConnectionDescription::~AAAConnectionDescription(void)
{
}

std::ostream& operator<<(std::ostream& os, const AAAConnectionDescription& desc)
{
    os << "ConnectionDescription[" << "model:" << desc.getModelName() << ",type:" << desc.getTypeName() << ",role:" << desc.getRoleName();
    os << ",serverName:" << desc.getServerName();
    os << "]";
    return os;
}

/************************************************************************
*   Function             :  AAAConnectionDescription::setSilentMode()
*
*   Description          :  Set the silent connection mode
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        : PMSTA-24563 - LJE - 160907
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionDescription::setSilentMode(bool bSilentMode)
{
    this->m_bSilentMode = bSilentMode;
}

/************************************************************************
*   Function             :  AAAConnectionDescription::getSilentMode()
*
*   Description          :  Get the silent connection mode
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        : PMSTA-24563 - LJE - 160907
*
*   Last Modification    :
*
*************************************************************************/
bool AAAConnectionDescription::getSilentMode() const
{
    return this->m_bSilentMode;
}

/************************************************************************
*   Function             :  AAAConnectionDescription::updateSrvPoolCfg()
*
*   Description          :  update server Pool configuration
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionDescription::updateSrvPoolCfg()
{
    SV_configClient.updateSrvPoolCfg(this->m_serverName);
}

/************************************************************************
*   Function             :  AAAConnectionDescription::isLastServer()
*
*   Description          :  check if the last server is picked from the pool
*
*   Arguments            :
*
*   Return               :  true if the last server else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool AAAConnectionDescription::isLastServer()
{
	return SV_configClient.isLastServer();
}

/************************************************************************
*   Function             :  AAAConnectionDescription::getReportServer
*
*   Description          :  Returns the Report server 
*
*   Arguments            :
*
*   Return               :  Returns the Report server
*
*   Creation Date        :  PMSTA-41931 - JOS - 20201011
*
*   Last Modification    :
*
*************************************************************************/
std::string AAAConnectionDescription::getReportServer()
{
    return SV_configClient.getReportServer(this->m_serverName);
}

/************************************************************************
*   Function             :  AAAConnectionDescription::setDatabase()
*
*   Description          :  
*
*   Arguments            :
*
*   Return               :  
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionDescription::setDatabase(const std::string& database)
{
    this->m_database = database;
}

/************************************************************************
*   Function             :  AAAConnectionDescription::setDatabase()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
const std::string& AAAConnectionDescription::getDatabase() const
{
    return this->m_database;
}


SERVERCONNECTNAT_ENUM AAAConnectionDescription::isFinServerPool()
{
	return SV_configClient.getServerType();
}
/************************************************************************
*   Function             :  AAAConnectionDescription::loadConfig()
*
*   Description          :  Load the configuration from ClientConfig
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :  HFI-PMSTA-49765-221005  : add 6 to MSG_SendExceptionMesg to get a complete message into the log
*
*************************************************************************/
void AAAConnectionDescription::loadConfig()
{
    try 
    {
        ServerClientConfig srvConfig = SV_configClient.getServerClientConfig(this->m_serverName);

        if (SV_configClient.getServerType() == ServConnectNat_Pool && srvConfig.getServerName().empty())
        {
            if (SV_configClient.availableServerInPool() == 0)
            {
                throw AAAPoolUsageException("Servers are not configured in the provided pool.");
            }
			else
            {
				throw AAAPoolUsageException("All the servers in the pool are down.");
            }
        }
        else
        {
            if (srvConfig.getServerModel() != UnknownRdbms)
            {
                this->m_model = srvConfig.getServerModel();
                this->m_url = srvConfig.getUrl();
            }
        }
    }
    catch (AAAPoolUsageException & e)
    {
        MSG_SendExceptionMesg(RET_GEN_ERR_PERSONAL, 6, e.getCallStack(), FILEINFO, "AAAConnectionDescription::loadConfig", e.what());     /* PMSTA-21907 - 281215 - PMO */
    }
}

/************************************************************************
*   Function             :  AAAConnectionDescription::setReloadProcess()
*
*   Description          :  Set reload bool to avoid recursive trying
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  PMSTA-34344 - LJE - 201030
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionDescription::setReloadProcess()
{
    this->m_bReloadProcess = true;
}

/************************************************************************
*   Function             :  AAAConnectionDescription::reload()
*
*   Description          :  Reload the configuration
*
*   Arguments            :  None
*
*   Return               :
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
void AAAConnectionDescription::reload()
{
    if (this->m_bReloadProcess == false && SYS_IsDdlGenMode() == FALSE)
    {
        SV_configClient.reload(this->m_serverName);
        this->loadConfig();
    }
}

/************************************************************************
*   Class        :   ClientConfig
*
*************************************************************************/


const ServerClientConfig ClientConfig::Null_ServerClientConfig("");

ClientConfig::ClientConfig()
{
    this->serverType = ServConnectNat_None;
}

size_t ClientConfig::availableServerInPool()
{
	return this->m_finSvrPool.availableFinSrv();
}

const ServerClientConfig& ClientConfig::getServerClientConfig(const std::string& serverName)
{
    if (serverName.empty())
    {
        return Null_ServerClientConfig;
    }

    auto it = this->m_allClientServerConfig.find(serverName);

    if (it != m_allClientServerConfig.end())
    {
        return it->second;
    }
    else
    {
        if (isFinServerPool(serverName))
        {
            if (availableServerInPool() == 0)
            {
                this->m_finSvrPool.initFinServerPool(serverName);
            }

			if (availableServerInPool() > 0)
			{
				this->m_finSvrPool.updateServerPoolCompo(serverName);
				return this->m_finSvrPool.next();
			}
			else
			{
				return Null_ServerClientConfig;
			}
        }
        else
        {
            ServerClientConfig srvConfig(serverName);

            if (srvConfig.getServerModel() != UnknownRdbms)
            {
                m_allClientServerConfig.insert(std::make_pair(serverName, srvConfig));
                return m_allClientServerConfig.find(serverName)->second;
            }
            else
            {
                return Null_ServerClientConfig;
            }
        }
    }	
}

/************************************************************************
*   Function             :  ClientConfig::isFinServerPool()
*
*   Description          :  Check whether the provided server name is a Pool or not
*
*   Arguments            :  serverName
*
*   Return               :  true if Server name is Pool type else false
*
*   Creation Date        :  
*
*   Last Modification    :
*
*************************************************************************/
bool ClientConfig::isFinServerPool(const std::string &serverName)
{
    DBA_DYNFLD_STP shSrvConnectStp = NULL, srvConnectStp = NULL;
    DbiConnectionHelper dbiConnHelper;
    bool isPool = false;
    MemoryPool mp;
    
    /*   Financial Server Pool */
    if ((srvConnectStp = mp.allocDynst(FILEINFO, A_ServConnect)) != NULL &&
        (shSrvConnectStp = mp.allocDynst(FILEINFO, S_ServConnect)) != NULL)
    {
        SET_NAME(shSrvConnectStp, S_ServConnect_ServerName, serverName.c_str());
        if (dbiConnHelper.dbaGet(ServConnect, UNUSED, shSrvConnectStp, &srvConnectStp) == RET_SUCCEED &&
            ServConnectNat_Pool == (SERVERCONNECTNAT_ENUM)GET_ENUM(srvConnectStp, A_ServConnect_NatEn))
        {
            isPool = true;
            this->serverType = ServConnectNat_Pool;
        }
    }
    return isPool;
}

/************************************************************************
*   Function             :  ClientConfig::reload()
*
*   Description          :  Reload the configuration of the given server
*
*   Arguments            :  serverName
*
*   Return               :
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
void ClientConfig::reload(const std::string & serverName)
{
    auto it = this->m_allClientServerConfig.find(serverName);

    if (it != m_allClientServerConfig.end())
    {
        this->m_allClientServerConfig.erase(it);
    }
    else if (isFinServerPool(serverName))
    {
        this->m_finSvrPool.addServerInQuarantine();
		this->m_finSvrPool.updateServerPoolCompo(serverName);
    }
    else
    {
        ServerClientConfig srvConfig(serverName);

        if (srvConfig.getServerModel() != UnknownRdbms)
        {
            m_allClientServerConfig.insert(std::make_pair(serverName, srvConfig));
        }
    }    
}

/************************************************************************
*   Function             :  ClientConfig::updateSrvPoolCfg()
*
*   Description          :  Reload the server pool configuration
*
*   Arguments            :  
*
*   Return               :
*
*   Creation Date        :  
*
*   Last Modification    :
*
*************************************************************************/
void ClientConfig::updateSrvPoolCfg(const std::string & serverName)
{
    this->m_finSvrPool.updateServerPoolCompo(serverName);
}

/************************************************************************
*   Function             :  ClientConfig::isLastServer()
*
*   Description          :  check if the last server is picked from the pool
*
*   Arguments            :
*
*   Return               :  true if the last server else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool ClientConfig::isLastServer()
{
	return this->m_finSvrPool.isLastServer();
}

/************************************************************************
*   Function             :  ClientConfig::getServerType()
*
*   Description          :  to get the server type
*
*   Arguments            :  
*
*   Return               :  type of the server
*
*   Creation Date        :  
*
*   Last Modification    :
*
*************************************************************************/
SERVERCONNECTNAT_ENUM ClientConfig::getServerType()
{
    return this->serverType;
}

/************************************************************************
*   Function             :  ClientConfig::getReportServer
*
*   Description          :  Returns the Report server
*
*   Arguments            :  serverName
*
*   Return               :  Returns the Report server
*
*   Creation Date        :  PMSTA-41931 - JOS - 20201011
*
*   Last Modification    :
*
*************************************************************************/
std::string ClientConfig::getReportServer(const std::string& serverName)
{
    
    std::string reportServer;

    auto it = this->m_allClientServerConfig.find(serverName);

    if (it != m_allClientServerConfig.end())
    {
        if(it->second.isReportServer())
        { 
            reportServer = it->second.getServerName();
        }
    }
    else
    {
        if (this->serverType == ServConnectNat_Pool)
        {
            ServerClientConfig srvConfig(serverName);
            /* Check if Pool is a Report Server */
            if (srvConfig.isReportServer())
            {
                if (availableServerInPool() == 0)
                {
                    this->m_finSvrPool.initFinServerPool(serverName);
                }

                if (availableServerInPool() > 0)
                {
                    /* Search for a Report Server in Pool */
                    reportServer = this->m_finSvrPool.getReportServerFromPool();
                }
            }    
        }
    }

    return reportServer;
}

/***************************************
*  Class :    AAAFinServerPool
*
****************************************/

AAAFinServerPool::AAAFinServerPool()
{
    //in minutes
    this->m_quarantinePeriod = 2;
	this->m_isLastServer = false;
}

/************************************************************************
*   Function             :  AAAFinServerPool::next
*
*   Description          :  Returns the next available server in the pool
*
*   Arguments            :
*
*   Return               :  Returns the next available server in the pool
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
const ServerClientConfig& AAAFinServerPool::next()
{
	size_t nbServer = this->m_finServers.size();
	size_t i = 0;
	std::random_device rand;
	int randPoolSelFlg = atoi(SYS_GetEnvStringOrDefValue("AAAPOOLSELECTIONDETERMINISTIC","1").c_str());

	for (i = 0; i < nbServer; i++)
	{
		auto index = i;
		if (!randPoolSelFlg)
			 index = rand() % nbServer;

		if (!isInQuarantine(this->m_finServers[index]))
		{
			this->m_currentServer = this->m_finServers[index];
			return this->m_currentServer;
		}
	}

	this->m_isLastServer = true;
	ServerClientConfig null_Server("");
	this->m_currentServer = null_Server;
	return this->m_currentServer;
}

/************************************************************************
*   Function             :  AAAFinServerPool::getReportServerFromPool
*
*   Description          :  Returns the next available Report server in the pool
*
*   Arguments            :
*
*   Return               :  Returns the next available Report server in the pool
*
*   Creation Date        :  PMSTA-41931 - JOS - 20201011
*
*   Last Modification    :
*
*************************************************************************/
std::string AAAFinServerPool::getReportServerFromPool()
{
    std::string reportServer;
    size_t nbServer = this->m_finServers.size();
    size_t i = 0;

    /* Check if Current Server is a Report Server*/
    if(this->m_currentServer.isReportServer())
    {
        std::string server = this->m_currentServer.getServerName();
        ServerClientConfig serverClient(server);
        
        if(serverClient.getHost().empty() == false)
        {
            reportServer = serverClient.getServerName();
            return reportServer;
        }  
    }

    /* If Current Server is not a Report Server, then search in Pool*/
    for (i = 0; i < nbServer; i++)
    {
        if (this->m_finServers[i].getServerName() != this->m_currentServer.getServerName() &&
            this->m_finServers[i].isReportServer())
        {
            std::string server = this->m_finServers[i].getServerName();
            ServerClientConfig serverClient(server);

            if(serverClient.getHost().empty() == false)
            {
                reportServer = serverClient.getServerName();
                break;
            }
        }
    }
   
    return reportServer;
}

/************************************************************************
*   Function             :  AAAFinServerPool::isInQuarantine
*
*   Description          :  check if the server in quarantine
*
*   Arguments            :  ServerClientConfig
*
*   Return               :  Returns true if in quarantine else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool AAAFinServerPool::isInQuarantine(const ServerClientConfig & finSrv)
{
    auto it = this->m_srvInQuarantine.find(finSrv.getServerName());

    if (it != this->m_srvInQuarantine.end())
    {
        time_t lastTimeFailed = it->second;

        if (lastTimeFailed != 0)
        {
            time_t currenDateTime;

            time(&currenDateTime);

            if ((currenDateTime - lastTimeFailed) > (this->m_quarantinePeriod * 60))
            {
                this->m_srvInQuarantine.erase(it->first);
            }
            else
            {
                return true;
            }
        }
    }
    return false;
}

/************************************************************************
*   Function             :  AAAFinServerPool::addServerInQuarantine
*
*   Description          :  Add the server in quarantine list
*
*   Arguments            :  ServerClientConfig
*
*   Return               :  Returns true if in quarantine else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void AAAFinServerPool::addServerInQuarantine()
{
    size_t nbServer = this->m_finServers.size();

    for (size_t i = 0; i < nbServer; i++)
    {
        if (this->m_finServers[i].getServerName().compare(this->m_currentServer.getServerName()) == 0 && 
            (this->m_srvInQuarantine.find(this->m_currentServer.getServerName()) == this->m_srvInQuarantine.end()))
        {
            time_t currentDateTime;

            time(&currentDateTime);

            this->m_srvInQuarantine.insert(std::make_pair(this->m_currentServer.getServerName(), currentDateTime));

            //erasing it from the current position 
            this->m_finServers.erase(this->m_finServers.begin() + i);

            //pushing it at the end of the list of servers
            this->m_finServers.push_back(this->m_currentServer);
        }
    }
}


/************************************************************************
*   Function             :  AAAFinServerPool::updateServerPoolCompo
*
*   Description          :  Update the pool compo with the new list of server
*
*   Arguments            :  newFinSrvPool : list of new server in the same pool
*
*   Return               :  Returns true if in quarantine else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void AAAFinServerPool::updateServerPoolCompo(const std::string& poolName)
{
    std::vector<ServerClientConfig> newFinSrvPool;

    getListOfServers(poolName, newFinSrvPool);

    bool isModified = false;

    for (auto newFinSrvIt : newFinSrvPool) {
        std::string serverName = newFinSrvIt.getServerName();

        auto oldFinSrvIt = std::find_if(this->m_finServers.begin(), this->m_finServers.end(), [serverName](const ServerClientConfig& it) {
            return it.getServerName() == serverName; });

        if (oldFinSrvIt != this->m_finServers.end())
        {
            if (oldFinSrvIt->getHost().compare(newFinSrvIt.getHost()) != 0 || oldFinSrvIt->getPort() != newFinSrvIt.getPort()
                || oldFinSrvIt->getScheme() != newFinSrvIt.getScheme())
            {
                //erasing the old config
                this->m_finServers.erase(oldFinSrvIt);

                //adding the new config
                this->m_finServers.push_back(newFinSrvIt);

				isModified = true;
            }
        }
        else
        {
            //adding the new config
            this->m_finServers.push_back(newFinSrvIt);
			isModified = true;
        }
    }

    //in case of Delete action (if the server is removed from the pool)
	for (size_t i = 0; i < this->m_finServers.size(); i++) {
        std::string serverName = this->m_finServers[i].getServerName();

        auto finSrvItExist = std::find_if(newFinSrvPool.begin(), newFinSrvPool.end(), [serverName](const ServerClientConfig& it) {
            return it.getServerName() == serverName; });

        //if fin server, from old list, is not present in the new Server list
        if (finSrvItExist == newFinSrvPool.end())
        {
            //erasing the config
            this->m_finServers.erase(this->m_finServers.begin() + i);

			isModified = true;
        }
    }

	if (isModified && m_srvInQuarantine.size() > 0)
	{
		this->m_srvInQuarantine.clear();
	}
}

/************************************************************************
*   Function             :  AAAFinServerPool::availableFinSrv
*
*   Description          :  no of available servers
*
*   Arguments            :
*
*   Return               :  Returns no of available servers
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
size_t AAAFinServerPool::availableFinSrv()
{
    return this->m_finServers.size();
}


/************************************************************************
*   Function             :  AAAFinServerPool::isLastServer
*
*   Description          :  if the last server is picked
*
*   Arguments            :
*
*   Return               :  true if last server else false
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
bool AAAFinServerPool::isLastServer()
{
	return this->m_isLastServer;
}

/************************************************************************
*   Function             :  AAAFinServerPool::getListOfServers
*
*   Description          :  fetch the list of servers available in he pool
*
*   Arguments            :  poolId
*
*   Return               :  Returns available servers
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void AAAFinServerPool::getListOfServers(const std::string& poolName, std::vector<ServerClientConfig>& listOfServers)
{
    DbiConnectionHelper dbiConnHelper;
    MemoryPool          mp;
	DBA_DYNFLD_STP      shSrvDtStp = NULL;
	DBA_DYNFLD_STP      *srvDtTab = nullptr;
	int                 nbServer = 0;

    if ((shSrvDtStp = mp.allocDynst(FILEINFO, S_ServPool)) != NULL)
    {
        SET_NAME(shSrvDtStp, S_ServPool_PoolServerName, poolName.c_str());

        if (dbiConnHelper.dbaSelect(ServPool, UNUSED, shSrvDtStp, S_ServPool, &srvDtTab, &nbServer) == RET_SUCCEED)
        {		
            if (nbServer <= 0)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAAFinServerPool::getListOfServers : No server configured for this pool.");
            }

            for (int idx = 0; idx < nbServer; idx++)
            {
                std::string server_name = GET_NAME(srvDtTab[idx], S_ServPool_ChildServerName);
                ServerClientConfig newServer(server_name);
                listOfServers.push_back(newServer);
            }
            DBA_FreeDynStTab(srvDtTab, nbServer, S_ServPool);
        } 
                
    }
}

/************************************************************************
*   Function             :  AAAFinServerPool::initFinServerPool
*
*   Description          :  initialize the server pool
*
*   Arguments            :  poolName
*
*   Return               :  
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
void AAAFinServerPool::initFinServerPool(const std::string &poolName)
{
    if (this->m_srvInQuarantine.size() > 0)
    {
        this->m_srvInQuarantine.clear();
    }    
    getListOfServers(poolName, this->m_finServers);
}

/************************************************************************
*   Function             :  AAAFinServerPool::getCurrentServer
*
*   Description          :  to get the current server object
*
*   Arguments            :
*
*   Return               :  Returns the current server object
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
const ServerClientConfig & AAAFinServerPool::getCurrentServer()
{
    return this->m_currentServer;
}

/************************************************************************
*   Class        :   ServerClientConfig
*
*************************************************************************/
ServerClientConfig::ServerClientConfig() : ServerClientConfig::ServerClientConfig("")
{
}

ServerClientConfig::ServerClientConfig(std::string forServerName)
    : m_port(0)
    , m_externalPort(0)
    , m_host()
    , m_host_name() /* PMSTA - 32186 CMILOS 05032019 */
    , m_externalHost() /* PMSTA-30135 CMILOS 140219 */
    , m_servername(forServerName)
    , m_useSsl(false)
    , m_useExternalSsl(false) /* PMSTA-30135 CMILOS 140219 */
    , m_bDispatcher(false)
    , m_isHttpServer(false)
    , m_serverModel(UnknownRdbms)
    , m_schemeEn(Scheme_OpenServer)
    , m_external_schemeEn(Scheme_OpenServer) /* PMSTA-30135 CMILOS 140219 */
    , m_businessEntityCd()                   /* PMSTA-41113 - KNI - 26092020 */
    , m_businessEntityId(0)                  /* PMSTA-41113 - KNI - 26092020 */
{
    if (forServerName.empty() == false)
    {
        DBA_DYNFLD_STP shSrvConnectStp = NULL, srvConnectStp = NULL;
        if ((srvConnectStp = ALLOC_DYNST(A_ServConnect)) != NULL &&
            (shSrvConnectStp = ALLOC_DYNST(S_ServConnect)) != NULL)
        {
            bool oldUseServerUser = SYS_GetThreadUseServerUser();
            SYS_SetThreadUseServerUser(true);

            DbiConnectionHelper dbiConnHelper;
            dbiConnHelper.getDescription().setReloadProcess();

            /*   Virtual Pool Management                                                                        */      /*  HFI-PMSTA-35648-200417  */
            SET_SYSNAME(shSrvConnectStp, S_ServConnect_ServerName, forServerName.c_str());
            if (dbiConnHelper.dbaGet(ServConnect, UNUSED, shSrvConnectStp, &srvConnectStp) == RET_SUCCEED)
            {
                if (ServConnectNat_VirtualPool == (SERVERCONNECTNAT_ENUM) GET_ENUM(srvConnectStp, A_ServConnect_NatEn))
                {
                    this->setScheme((SCHEME_ENUM) GET_ENUM(srvConnectStp, A_ServConnect_SchemeEn));
                    this->setExternalScheme((SCHEME_ENUM) GET_ENUM(srvConnectStp, A_ServConnect_SchemeEn));
                    if (IS_NULLFLD(srvConnectStp, A_ServConnect_VirtualHost) == TRUE)
                    {
                        throw AAAPoolUsageException("Virtual host must not be null in virtual connection pool.");
                    }
                    else
                    {
                        this->m_host         = GET_NOTE(srvConnectStp, A_ServConnect_VirtualHost);
                        this->m_port         = GET_INT(srvConnectStp, A_ServConnect_VirtualPort);
                        this->m_externalHost = GET_NOTE(srvConnectStp, A_ServConnect_VirtualHost);
                        this->m_externalPort = GET_INT(srvConnectStp, A_ServConnect_VirtualPort);
                    }
                }
                else
                {
                    DBA_DYNFLD_STP shSrvRunningStp = NULL, srvRunningStp = NULL;

                    if ((srvRunningStp = ALLOC_DYNST(A_ServRunning)) != NULL &&
                        (shSrvRunningStp = ALLOC_DYNST(S_ServRunning)) != NULL)
                    {
                        SET_SYSNAME(shSrvRunningStp, S_ServRunning_ServerName, forServerName.c_str());

                        if (dbiConnHelper.dbaGet(ServRunning, UNUSED, shSrvRunningStp, &srvRunningStp) == RET_SUCCEED)
                        {
                            this->setScheme((SCHEME_ENUM)GET_ENUM(srvRunningStp, A_ServRunning_InternalSchemeEn)); /* PMSTA-30135 CMILOS 140219 */
                            this->setExternalScheme((SCHEME_ENUM)GET_ENUM(srvRunningStp, A_ServRunning_SchemeEn)); /* PMSTA-30135 CMILOS 140219 */
                            this->m_host         = GET_NOTE(srvRunningStp, A_ServRunning_InternalHost); /* PMSTA-30135 CMILOS 140219 */
                            this->m_port         = GET_INT(srvRunningStp, A_ServRunning_InternalPort);  /* PMSTA-30135 CMILOS 140219 */
                            this->m_externalHost = GET_NOTE(srvRunningStp, A_ServRunning_Host); /* PMSTA-30135 CMILOS 140219 */
                            this->m_externalPort = GET_INT(srvRunningStp, A_ServRunning_Port);  /* PMSTA-30135 CMILOS 140219 */
                        }
                    }
                    FREE_DYNST(srvRunningStp, A_ServRunning);
                    FREE_DYNST(shSrvRunningStp, S_ServRunning);
                }
            }            
            FREE_DYNST(srvConnectStp, A_ServConnect);
            FREE_DYNST(shSrvConnectStp, S_ServConnect);

            SYS_SetThreadUseServerUser(oldUseServerUser);
        }
        updateUrl();

    }
}
ServerClientConfig::ServerClientConfig(const ServerClientConfig & other)
{
    set(other); /* PMSTA-25644 - 141216 - PMO */
}

/************************************************************************
*   Function             :  ServerClientConfig::operator=
*
*   Description          :  The copy operator
*
*   Arguments            :  src of data
*
*   Return               :  reference of this object
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
ServerClientConfig & ServerClientConfig::operator=(const ServerClientConfig & other)
{
    set(other);

    return *this;
}


/************************************************************************
*   Function             :  ServerClientConfig::set
*
*   Description          :  Define all fields
*
*   Arguments            :  src of data
*
*   Return               :  None
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
void ServerClientConfig::set(const ServerClientConfig & other)
{
    this->m_servername        = other.m_servername;
    this->m_isHttpServer      = other.m_isHttpServer;
    this->m_serverModel       = other.m_serverModel;
    this->m_host              = other.m_host;
    this->m_host_name         = other.m_host_name; /* PMSTA - 32186 CMILOS 05032019 */
    this->m_port              = other.m_port;
    this->m_useSsl            = other.m_useSsl;
    this->m_useExternalSsl    = other.m_useExternalSsl; /* PMSTA - 32186 CMILOS 05032019 */
    this->m_schemeEn          = other.m_schemeEn;
    this->m_external_schemeEn = other.m_external_schemeEn; /* PMSTA - 32186 CMILOS 05032019 */
    this->m_bDispatcher       = other.m_bDispatcher;
    this->m_externalHost      = other.m_externalHost;
    this->m_externalPort      = other.m_externalPort;
    this->m_businessEntityCd  = other.m_businessEntityCd;  /* PMSTA-41113 - KNI - 26092020 */
    this->m_businessEntityId  = other.m_businessEntityId;  /* PMSTA-41113 - KNI - 26092020 */

    updateUrl();
}

/************************************************************************
*   Function             :  ServerClientConfig::compare
*
*   Description          :  Compare two ServerClientConfig
*
*   Arguments            :  other   Other configuration used for comparison
*
*   Return               :  true    All fields are equal
*                           false   There is any difference
*
*   Creation Date        :  PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*   Last Modification    :
*
*************************************************************************/
bool ServerClientConfig::compare(const ServerClientConfig & other)
{
    return  this->m_servername        == other.m_servername        &&
            this->m_isHttpServer      == other.m_isHttpServer      &&
            this->m_serverModel       == other.m_serverModel       &&
            this->m_host              == other.m_host              &&
            this->m_host_name         == other.m_host_name         && /* PMSTA - 32186 CMILOS 05032019 */
            this->m_port              == other.m_port              &&
            this->m_useSsl            == other.m_useSsl            &&
            this->m_useExternalSsl    == other.m_useExternalSsl    && /* PMSTA-30135 CMILOS 140219 */
            this->m_schemeEn          == other.m_schemeEn          &&
            this->m_external_schemeEn == other.m_external_schemeEn && /* PMSTA-30135 CMILOS 140219 */
            this->m_bDispatcher       == other.m_bDispatcher       &&
            this->m_externalHost      == other.m_externalHost      &&
            this->m_externalPort      == other.m_externalPort      &&
            this->m_businessEntityCd  == other.m_businessEntityCd  &&   /* PMSTA-41113 - KNI - 26092020 */
            this->m_businessEntityId  == other.m_businessEntityId  ;
}


bool ServerClientConfig::isHttpServer() const
{
    return m_isHttpServer;
}

void ServerClientConfig::setServerModel(const DBA_RDBMS_ENUM model)
{
    this->m_serverModel = model;

    if (this->m_serverModel == QtHttp)
    {
        this->m_isHttpServer = true;
    }
    else
    {
        this->m_isHttpServer = false;
    }

    updateUrl();
}

DBA_RDBMS_ENUM ServerClientConfig::getServerModel() const
{
    return this->m_serverModel;
}

void ServerClientConfig::setScheme(const SCHEME_ENUM scheme)
{
    this->m_schemeEn = scheme;

    this->m_useSsl = false;

    switch (this->m_schemeEn)
    {
        case Scheme_Https:
            this->m_useSsl = true;
            this->setServerModel(QtHttp); /* PMSTA-30135 CMILOS 140219 */
            break;
        case Scheme_Http:
            this->setServerModel(QtHttp);
            break;

        case Scheme_OpenServer:
            this->setServerModel(Sybase);
            break;
    }

    if (this->m_servername.empty())
    {
        this->m_servername = EV_Server;
    }

    updateUrl();

}

void ServerClientConfig::setExternalScheme(const SCHEME_ENUM scheme) /* PMSTA-30135 CMILOS 140219 */
{
    this->m_external_schemeEn = scheme;

    this->m_useExternalSsl = false;

    switch (this->m_external_schemeEn)
    {
    case Scheme_Https:
        this->m_useExternalSsl = true;
        break;
    case Scheme_Http:
        this->m_useExternalSsl = false;
        break;
    }
}

SCHEME_ENUM ServerClientConfig::getScheme() const
{
    return this->m_schemeEn;
}

SCHEME_ENUM ServerClientConfig::getExternalScheme() const /* PMSTA-30135 CMILOS 140219 */
{
    return this->m_external_schemeEn;
}

const std::string &ServerClientConfig::getSchemeName() const
{
    return schemeNameTab[this->m_schemeEn];
}

void ServerClientConfig::setServerName(const std::string& servername)
{
    this->m_servername = servername;
    updateUrl();
}

std::string ServerClientConfig::getServerName() const
{
    return m_servername;
}

std::string ServerClientConfig::getUrl() const
{
    return m_url;
}

std::string ServerClientConfig::getExternalUrl() const
{
    return m_externalUrl;
}
void ServerClientConfig::setHost(const std::string& host)
{
    m_host = host;
    updateUrl();
}

void ServerClientConfig::setHostName(const std::string& host) /* PMSTA - 32186 CMILOS 05032019 */
{
    m_host_name = host;
}

const std::string& ServerClientConfig::getHost()
{
    return this->m_host;
}

const std::string& ServerClientConfig::getHostName() /* PMSTA - 32186 CMILOS 05032019 */
{
    return this->m_host_name;
}

void ServerClientConfig::setExternalHost(const std::string& externalHost)
{
    m_externalHost = externalHost;
    updateUrl();
}

const std::string& ServerClientConfig::getExternalHost()
{
    return this->m_externalHost;
}

void ServerClientConfig::setPort(int port)
{
    m_port = port;
    updateUrl();
}

int ServerClientConfig::getPort()
{
    return this->m_port;
}

void ServerClientConfig::setExternalPort(int externalPort)
{
    m_externalPort = externalPort;
    updateUrl();
}

int ServerClientConfig::getExternalPort()
{
    return this->m_externalPort;
}

bool ServerClientConfig::isDispatcher()
{
    return this->m_bDispatcher;
}

const std::string& ServerClientConfig::getBusEntityCd() /* PMSTA-41113 - KNI - 26092020 */
{
    return this->m_businessEntityCd;
}

const int ServerClientConfig::getBusEntityId()          /* PMSTA-41113 - KNI - 26092020 */
{
    return this->m_businessEntityId;
}


void ServerClientConfig::setDispatcher(bool bDispatcher)
{
    this->m_bDispatcher = bDispatcher;
}

void ServerClientConfig::setBusinessEntity(const std::string& i_businessEntityCd, int i_businessEntityId) /* PMSTA-41113 - KNI - 26092020 */
{
    this->m_businessEntityCd = i_businessEntityCd;
    this->m_businessEntityId = i_businessEntityId;
}

void ServerClientConfig::setUseSsl(bool useSsl)
{
    m_useSsl = useSsl;
    updateUrl();
}

/************************************************************************
*   Function             :  ClientConfig::isReportServer()
*
*   Description          :  Check whether the server is Report Server or not
*
*   Arguments            :  
*
*   Return               :  true if Server is Report Server else false
*
*   Creation Date        :  PMSTA-41931 - JOS - 20201011
*
*   Last Modification    :
*
*************************************************************************/
bool ServerClientConfig::isReportServer()
{
    DBA_DYNFLD_STP shSrvConnectStp = NULLDYNST, srvConnectStp = NULLDYNST;
    DbiConnectionHelper dbiConnHelper;
    bool isReport = false;
    MemoryPool mp;

    std::string serverName= this->getServerName();

    if ((srvConnectStp = mp.allocDynst(FILEINFO, A_ServConnect)) != NULLDYNST &&
        (shSrvConnectStp = mp.allocDynst(FILEINFO, S_ServConnect)) != NULLDYNST)
    {
        SET_NAME(shSrvConnectStp, S_ServConnect_ServerName, serverName.c_str());
        if (dbiConnHelper.dbaGet(ServConnect, UNUSED, shSrvConnectStp, &srvConnectStp) == RET_SUCCEED &&
             TRUE == GET_FLAG(srvConnectStp, A_ServConnect_ReportFlg))
        {
            isReport = true;
        }
    }
    return isReport;
}

std::string ServerClientConfig::toUrl(const std::string& host, int port, bool usingSsl, bool isHttp)
{
    std::stringstream sstm;
    if (isHttp)
    {
        if (usingSsl)
        {
            sstm << "https://";
        }
        else
        {
            sstm << "http://";
        }
    }
    sstm << (host) << ":" << port;
    return  sstm.str();
}

void ServerClientConfig::updateUrl()
{
    if (this->m_isHttpServer)
    {
        /* PMSTA-30135 CMILOS 140219 */
        if (EV_InternalAddress == TRUE)
        {
            /* PMSTA-30135 CMILOS 140219 */
            if (!m_host.compare("localhost"))
                m_host = "127.0.0.1";
            m_url = ServerClientConfig::toUrl(m_host, m_port, m_useSsl, m_isHttpServer);
        }
        else
        {
            /* PMSTA-30135 CMILOS 140219 */
            if (SYS_IsSrvMode())
            {
                m_url = ServerClientConfig::toUrl(m_host, m_port, m_useSsl, m_isHttpServer);
            }
            else
            {
                m_url = ServerClientConfig::toUrl(m_externalHost, m_externalPort, m_useExternalSsl, m_isHttpServer);
            }
        }

        m_externalUrl = ServerClientConfig::toUrl(m_externalHost.length()>0 ? m_externalHost : m_host,
            m_externalPort>0 ? m_externalPort : m_port,
            m_useSsl,
            m_isHttpServer);
    }
    else
    {
        m_url = this->m_servername;
    }
}



/************************************************************************
*   Function             :  DBAuthenticationMethod::get
*
*   Description          :  Return the type of Database configuration autenticatin mechanism used by the process (static)
*
*   Arguments            :  
*
*   Return               : 
*
*   Creation Date        :  PMSTA-53363 - FME - 2023-06-16 Support AWS IAM C++
*
*   Last Modification    :
*
*************************************************************************/
const DBAuthenticationMethod DBAuthenticationMethod::get()
{
    static const std::string   authMethodStr = SYS_GetEnvStringOrDefValue(DBAuthenticationMethod::ENV_VARIABLE_NAME, "password");

    if (SYS_StringCompareInsensitive(authMethodStr, "iam"))
    {
        static const DBAuthenticationMethod result(DBAuthenticationMethod::iam);
        return result;
    }
    else
    {
        static const DBAuthenticationMethod result(DBAuthenticationMethod::password);
        return result;
    }
}

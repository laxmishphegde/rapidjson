/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "conpolicies.h"
#include <iostream>

AAAConnectionPolicies::AAAConnectionPolicies(const  AAAConnectionPolicy& connectionPolicy, const  AAADisconnectionPolicy& disconnectionPolicy, const unsigned long& maxIdleTime, const  AAAAgingPolicy& agingPolicy, const unsigned long& maxAge) {
	this->connectionPolicy = connectionPolicy;
	this->disconnectionPolicy = disconnectionPolicy;
	this->agingPolicy = agingPolicy;
	this->maxAge = maxAge;
    this->maxIdleTime = maxIdleTime;
}
AAAConnectionPolicies::AAAConnectionPolicies(const  AAAConnectionPolicies& toCopy) {
	this->connectionPolicy = toCopy.getConnectionPolicy();
	this->disconnectionPolicy = toCopy.getDisconnectionPolicy();
	this->agingPolicy = toCopy.getAgingPolicy();
	this->maxAge = toCopy.getMaxAge();
    this->maxIdleTime = toCopy.getMaxIdleTime();
}
AAAConnectionPolicies::~AAAConnectionPolicies() {
}

void AAAConnectionPolicies::operator = (const  AAAConnectionPolicies& toCopy) {
	this->connectionPolicy = toCopy.getConnectionPolicy();
	this->disconnectionPolicy = toCopy.getDisconnectionPolicy();
	this->agingPolicy = toCopy.getAgingPolicy();
	this->maxAge = toCopy.getMaxAge();
    this->maxIdleTime = toCopy.getMaxIdleTime();
}

const AAAConnectionPolicy& AAAConnectionPolicies::getConnectionPolicy() const { return  connectionPolicy; }
const AAADisconnectionPolicy& AAAConnectionPolicies::getDisconnectionPolicy() const{ return disconnectionPolicy; }
const AAAAgingPolicy& AAAConnectionPolicies::getAgingPolicy() const{ return agingPolicy; }
const unsigned long& AAAConnectionPolicies::getMaxAge() const{ return maxAge; }
const unsigned long& AAAConnectionPolicies::getMaxIdleTime() const{ return maxIdleTime; }

std::ostream& operator<<(std::ostream& os, const AAAConnectionPolicies& obj) {
    os << "AAAConnectionPolicies["
        << "connectionPolicy:" << (obj.getConnectionPolicy() == ConnectAtCreate ? "ConnectAtCreate" : "ConnectAtUse")
        << ",disconnectionPolicy:" << AAA_GetAAADisconnectionPolicyStr(obj.getDisconnectionPolicy());
    if (obj.getDisconnectionPolicy() == DisconnectAtUnusedConnTimeout) {
            os << ",maxIdleTime:" << obj.getMaxIdleTime();
    }
	os	<< ",agingPolicy:" << (obj.getAgingPolicy() == Aging ? "Aging" : "NoAging");
	if (obj.getAgingPolicy() == Aging) {
		os << ",maxAge:" << obj.getMaxAge();
	}
	os << "]";
	return os;
}

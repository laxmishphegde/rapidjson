/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"
#include "conpoolconf.h"
#include "password.h"

AAAConnectionPoolConfiguration::AAAConnectionPoolConfiguration(const AAAConnectionDescription& description, 
	                                                           const int& maxsize, 
                                                               const int& minsize,
															   const PasswordEncrypted& password, 
															   const AAAConnectionPolicies& policies) : description(description), policies(policies){
	this->maxSize = maxsize ;
    this->minSize = minsize ;
	this->password = password ;
}

AAAConnectionPoolConfiguration::AAAConnectionPoolConfiguration(const AAAConnectionPoolConfiguration& toCopy) : description(toCopy.getDescription()), policies(toCopy.getPolicies()) {
	this->maxSize = toCopy.getMaxsize() ;
    this->minSize = toCopy.getMinsize();
	this->password = toCopy.getPassword() ;
}
AAAConnectionPoolConfiguration::~AAAConnectionPoolConfiguration(void)
{
}
const int& AAAConnectionPoolConfiguration::getMaxsize() const {
	return this->maxSize; 
}
const int& AAAConnectionPoolConfiguration::getMinsize() const {
    return this->minSize;
}
const AAAConnectionDescription& AAAConnectionPoolConfiguration::getDescription() const {
	return this->description; 
}
const PasswordEncrypted & AAAConnectionPoolConfiguration::getPassword()  const {
	return password;
}
const AAAConnectionPolicies& AAAConnectionPoolConfiguration::getPolicies() const {
	return policies;
}

std::ostream& operator<<(std::ostream& os, const AAAConnectionPoolConfiguration& obj) {
	os << "AAAConnectionPoolConfiguration[" << "description:" << obj.getDescription() << ",policies:" << obj.getPolicies() << ",maxSize:" << obj.getMaxsize() << ",password:" << "******" << "]";
	return os;
}

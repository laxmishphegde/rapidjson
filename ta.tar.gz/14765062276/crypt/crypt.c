/* ***********************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
** ***********************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "crypt.h"

extern int key_crypt(CRYPT_ACTION_ENUM, char *, int, char **);

static const char *moduleNameTab[] = { "Core module number                           : ",
                                 "Production module number                     : ",
                                 "Attribution module level                     : ",
                                 "Risk module number                           : ",
                                 "Accounting module number                     : ",
                                 "Fund module number                           : ",
                                 "Corporate actions module number              : ",
                                 "Advanced analytics module level              : ",
                                 "Composite manager module number              : ",
                                 "Excel module number                          : ",
                                 "Return analysis module level                 : ",
                                 "Advanced constraint management module number : ",
                                 "Order management module number               : ",
                                 "Compound Order module level                  : ", /* PMSTA-18601 - DDV - 141002 */
                                 "Risk Compliance module level                 : ", /* PMSTA-18426 - DDV - 141002 */
                                 "Suitability and Investment profiling level   : ", /* PMSTA-24032 - DDV - 160914 */
                                 "Financial Planning module level              : ", /* PMSTA-24032 - DDV - 160914 */
                                 "Data Framework module level                  : ", /* PMSTA-24032 - DDV - 160914 */
                                 "CRM module level                             : ", /* PMSTA-34693 - JPG - 040419 */
                                 "Future module #7 number                      : ",
                                 NULL };

/************************************************************************
**
**  Function    :   scanline
**
**  Description :   Allows inputs.
**
**  Argument    :   inputString.
**
**  Return      :   void.
**
**  Creation    :   GRD - 970325 - DVP404.
**
*************************************************************************/

void scanline(char	*inputString)
{
	char		c;
	int		i = 0;

	while ((c = getchar()))
	{
		if ((c == '\n'))
			return;

		inputString[i] = c;
		i++;
	}
}

/************************************************************************
**
**  Function    :   main core
**
**  Description :   Accepts and controls parameters to be
**                  crypted/checked.
**
**  Argument    :   None.
**
**  Creation    :   GRD - 970325 - DVP404.
**
*************************************************************************/

int main(int argc, char **argv)
{
	CRYPT_ACTION_ENUM	cryptAction = CRYPT;
	time_t			currentTime;
	char			**arrayFields;
	char			cryptedKey[MAX_LINE_LENGTH],
				cryptActn[MAX_LINE_LENGTH],
				dayStr[MAX_LINE_LENGTH],
				monthStr[MAX_LINE_LENGTH],
				yearStr[MAX_LINE_LENGTH],
				answer[MAX_LINE_LENGTH],
				moduleStr[MAX_LINE_LENGTH];
	char			actionChar;
	int			retcode = OP_SUCCEDED;
	int			keyRoot = 0;
	int			i = 0;
        int                     paramNumber; /* DLA - REF6118 - 010619 */
	const char			**moduleCursor = moduleNameTab;
	char                    *validModuleStr;
	struct tm 		*ltp;

	/*
	 * Optionally dump licensee modules (then exit)
	*/

	if (argc == 2 && strcmp(argv[1], "-M") == 0)
	{
		while (*moduleCursor)
			printf("%s\n", *moduleCursor++);
		return 0;
	}

	/*
	 * Allocate memory to store inputs.
	 */

	printf("\n\n");
	printf("CHECK OR CRYPT (1/2): ");
	scanline(cryptActn);
	printf("\n\n");
	actionChar=cryptActn[0];

	/*
	 * CHECK or CRYPT.
	 */

	memset(cryptedKey, 0x00, MAX_LINE_LENGTH);

	switch (actionChar)
	{
		case '1':	/* Action is check. */
			cryptAction = CHECK;
			break;

		case '2':	/* Action is crypt. */
			cryptAction = CRYPT;
			keyRoot = CRYPT_VERSION * 10000;
			currentTime = time(NULL);
			ltp = localtime(&currentTime);
			keyRoot += ((unsigned int) (rand() * ltp->tm_sec)) % 9999;
			sprintf(cryptedKey, "%d", keyRoot);
			break;

		default:
			printf ("Error: invalid command!\n");
			exit(0);
	}

	arrayFields = (char **) malloc (LINE_NUMBER * sizeof (char *));
        paramNumber = LINE_NUMBER; /* DLA - REF6118 - 010619 */

	for (i = 0; i < LINE_NUMBER; i++)
	{
		arrayFields[i] = (char *) malloc (MAX_LINE_LENGTH * sizeof(char));
		memset(arrayFields[i], 0x00, MAX_LINE_LENGTH);
	}

	switch (cryptAction)
	{
		case CRYPT:
			printf("LICENSEE NAME: ");
			scanline(arrayFields[0]);

			if (strlen(arrayFields[0]) == 0)
			{
				printf("LICENSEE NAME is mandatory!\n");
				exit(0);
			}

			/*********************
			 * GET MODULES DATA. *
			 *********************/

			printf("\nLICENSEE MODULES: \n");

			moduleCursor = moduleNameTab;
			validModuleStr = arrayFields[1];

			while(*moduleCursor != NULL)
			{
				printf("        %s", *moduleCursor);
				memset(moduleStr, 0x00, MAX_LINE_LENGTH);
				scanline(moduleStr);

				if (strlen(moduleStr) == 0)
				{
					printf("Error: module is MANDATORY!\n");
					exit(1);
				}

				for(i = 0; i < strlen(moduleStr); i++)
					if ((moduleStr[i] < '0') || (moduleStr[i] > '9'))
					{
						printf("Error: only digits are allowed!\n");
						exit(1);
					}

				strcat(validModuleStr, moduleStr);
				strcat(validModuleStr, ",");
				moduleCursor++;
			}

			validModuleStr[strlen(validModuleStr) -1] = 0x00;

			/********************************
			 * GET LICENSE EXPIRATION DATE. *
			 ********************************/

			memset(answer,   0x00, MAX_LINE_LENGTH);
			memset(dayStr,   0x00, MAX_LINE_LENGTH);
			memset(monthStr, 0x00, MAX_LINE_LENGTH);
			memset(yearStr,  0x00, MAX_LINE_LENGTH);

			printf("\nLICENSEE EXPIRATION: \n");
			printf("        UNLIMITED license? (Y/N) [DEFAULT N]: ");

			scanline(answer);

			if ((strlen(answer) == 0) ||
			    ((strcmp(answer, "NO") == 0) || (strcmp(answer, "no") == 0) ||
			     (strcmp(answer, "N") == 0) || (strcmp(answer, "n") == 0)))
			{
				/* Accept days and verify that days are between 1 and 31. */
				printf("        Enter day  : ");
				scanline(dayStr);

				if (strlen(dayStr) == 0)
				{
					printf("Error: days are MANDATORY!\n");
					exit(1);
				}

				for(i = 0; i < strlen(dayStr); i++)
					if ((dayStr[i] < '0') || (dayStr[i] > '9'))
					{
						printf("Error: only digits are allowed!\n");
						exit(1);
					}

				if ((atoi(dayStr) < 1) || (atoi(dayStr) > 31))
				{
					printf("Error: days should be from 1 to 31!\n");
					exit(1);
				}

				strcat(arrayFields[2], dayStr);
				strcat(arrayFields[2], "/");

				/* Accept month and verify that month are between 1 and 12. */
				printf("        Enter month: ");
				scanline(monthStr);

				if (strlen(monthStr) == 0)
				{
					printf("Error: month is MANDATORY!\n");
					exit(1);
				}

				for(i = 0; i < strlen(monthStr); i++)
					if ((monthStr[i] < '0') || (monthStr[i] > '9'))
					{
						printf("Error: only digits are allowed!\n");
						exit(1);
					}

				if ((atoi(monthStr) < 1) || (atoi(monthStr) > 12))
				{
					printf("Error: month should be from 1 to 12!\n");
					exit(1);
				}

				strcat(arrayFields[2], monthStr);
				strcat(arrayFields[2], "/");

				/* Accept year. */
				printf("        Enter year : ");
				scanline(yearStr);

				if (strlen(yearStr) == 0)
				{
					printf("Error: year is MANDATORY!\n");
					exit(1);
				}

				for(i = 0; i < strlen(yearStr); i++)
					if ((yearStr[i] < '0') || (yearStr[i] > '9'))
					{
						printf("Error: only digits are allowed!\n");
						exit(1);
					}

				if (strlen(yearStr) < 4)
				{
					printf("Error: year should be 4 digits long!\n");
					exit(1);
				}

				strcat(arrayFields[2], yearStr);
			}
			else
				strcat(arrayFields[2], LICENSEEXPIRATION);

			/*********************
			 * GET LICENSE PACK  *  DLA - REF6118 - 010619
			 *********************/
			printf("LICENSEE PACK: ");
			scanline(arrayFields[3]);


			/*******************************************
			 * Display parameters used for encryption. *
			 *******************************************/

			printf("\n\nPARAMETERS USED FOR ENCRYPTION ARE: \n\n");
			printf("LICENSEE NAME        : %s\n", arrayFields[0]);
			printf("LICENSEE MODULES     : %s\n", arrayFields[1]);
			printf("LICENSEE EXPIRATION  : %s\n", arrayFields[2]);
                        printf("LICENSEE PACK        : %s\n", arrayFields[3]); /* DLA - REF6118 - 010619 */

			break;

		case CHECK:
			printf("LICENSEE NAME: ");
			scanline(arrayFields[0]);
			printf("LICENSEE MODULES: ");
			scanline(arrayFields[1]);
			printf("LICENSEE EXPIRATION: ");
			scanline(arrayFields[2]);
                        printf("LICENSEE PACK: ");
			scanline(arrayFields[3]); /* DLA - REF6118 - 010619 */
			printf("KEY TO CHECK: ");
			scanline(cryptedKey);
			break;
	}

	if (strlen(arrayFields[3]) == 0) /* DLA - REF6118 - 010619 */
	{
 	    paramNumber--;
	}

	retcode = key_crypt(cryptAction, cryptedKey, paramNumber, arrayFields);

	switch(cryptAction)
	{
		case CRYPT:
			if (retcode == OP_SUCCEDED)
			{
				printf ("\n\nOperation succeded!\n");
				printf("The crypted key is [ %s ]\n\n", cryptedKey);
			}
			else
				printf ("\n\nOperation failed!\n\n");

			break;

		case CHECK:
			if (retcode == OP_SUCCEDED)
			{
				printf ("\n\nOperation succeded!\n");
				printf ("The license key matches the given one\n\n");
			}
			else
			{
				printf ("\n\nOperation failed!\n");
				printf ("Incorrect License key\n\n");
			}
			break;
	}

	/*
	   Free the allocated memory.
	*/

	for (i = 0; i < LINE_NUMBER; i++)
		free(arrayFields[i]);

	free(arrayFields);

	printf ("Goodbye\n");
	return 0;
}


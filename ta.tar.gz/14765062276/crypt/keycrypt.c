/* ***********************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
** ***********************************************************************/


#include "crypt.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"

int power(int dataNumber1, int dataNumber2)
{
	int	i = 0;
	int	result = dataNumber1;

	if ((dataNumber1 == 0) || (dataNumber2 == 0) ||
	    (dataNumber2 == 1))
		return (0);

	for (i = 1; i < dataNumber2; i++)
		result = result * dataNumber1;

	return (result);
}

/************************************************************************
**
**  Function    :   key_crypt
**
**  Description :   Allows crypting/checking of keys.
**
**  Argument    :   cryptAction: CRYPT/CHECK.
**                  key        : key to crypt/check.
**                  dataNbr    : Number of elements to crypt.
**                  data       : Elements to crypt.
**
**  Return      :   OP_SUCCEDED/OP_FAILED.
**
**  Creation    :   GRD - 970325 - DVP404.
**
**  Modification :  GRD - 980427 - REF1905.
*************************************************************************/

int key_crypt(CRYPT_ACTION_ENUM cryptAction,
	      char              *key,
	      int               dataNbr,
	      char              **data)
{
	char	charsetLower[]="abcdefghijklmnopqrstuvwxyz";
	char	charsetUpper[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char	charsetFinal[]="0123456789ABCDEFGHIJKLMN+PQRSTUVWXYZabcdefghijk-mnopqrstuvwxyz";
	char	*dataStream;
	char	*dataCursor;
	char	*charsetCursor;
	char	*finalKey;
	char	curChar[2];			/* BUG452 - 970903 - XMT */
	int	retCode = OP_SUCCEDED;
	int	fldLength = 0;
	int	i = 0, j = 0;
	/* int	randNbr = 0;  */ /*REF3305 - SSO - 000516 */
	int	leadingSpace = 0;
	int	charPos = 0; 
	int	factor[5];
	int	modulus[5];
	int	*dataVal;
	int	*dataValGrp;
	int	*dataValCursor;
	int	*dataValCursor2;
	int	strLength = 0;
	int	strModulus = 0;

	/*
		First of all, check data integrity.
	*/

	if (((cryptAction != CRYPT) && (cryptAction != CHECK)) ||
	    (key == 0x00) || (dataNbr == 0) || (data == 0x00))
	{
		return (OP_FAILED);
	}

	/*
	   Must not correspond to only the first 5 elements.
	*/

	if (cryptAction == CHECK)
	{
		if (strlen(key) < 6)
		{
			return (OP_FAILED);
		}
	}

	/*
		Concatenate the fields to be crypted, separated by a space.
	*/

	for (i = 0; i < dataNbr; i++)
	{
		fldLength += (int)strlen(data[i]);
	}

	/*
		1 for null termination, 7 allows rounding if filling with X.

		fldLength:    is total length of all given strings.
		dataNbr:      is number of spaces between strings.
		leadingSpace: is possible rounding size.
	*/

	leadingSpace = 1 + 7;
	dataStream = (char *) malloc((fldLength + dataNbr + leadingSpace) * sizeof (char *));
	*dataStream = '\0';

	for (i = 0; i < dataNbr; i++)
	{
		strcat(dataStream, data[i]);
		strcat(dataStream, " ");
	}

	dataStream[fldLength + dataNbr - 1] = '\0';

	/*
	   Change lower case to upper case charaters.
	   Change non-alphanumeric charaters to ' '.
	   Change characters > ASCII 127 to 'Y'.
	*/

	for (dataCursor = dataStream; *dataCursor != '\0'; dataCursor++)
	{
		if (((*dataCursor >= 'A') && (*dataCursor <= 'Z')) ||
		    ((*dataCursor >= '0') && (*dataCursor <= '9')) ||
		    (*dataCursor == ' '))
			continue;	/* Nothing to do. */

			/* Is it lower case ? */
		if ((*dataCursor >= 'a') && (*dataCursor <= 'z'))
		{
			for (charsetCursor = charsetLower, charPos = 0;
			     *charsetCursor != *dataCursor;
			     charsetCursor++, charPos++);

			*dataCursor = charsetUpper[charPos];
			continue;
		}

		*dataCursor = ' ';
	}

	/*
	   Squeeze consecutive repeated characters, except digits
	*/

	for (dataCursor = dataStream, charPos = 0; *dataCursor != '\0'; dataCursor++)
	{
		if ((*dataCursor >= '0' && *dataCursor <= '9') || *dataCursor != *(dataCursor + 1))
			dataStream[charPos++] = *dataCursor;
	}
	dataStream[charPos] = '\0';

	/*
	   Fill the data stream with X's corresponding
	   to the division by 7 remainder.
	*/

	strModulus = (strlen(dataStream) % 7);

	if (strModulus)
	{
		for (i = 0; i < (7 - strModulus); i++)
			strcat(dataStream, "X");
	}

	/* 
	   For each character in the string should
	   match a number.
		Space: 0, 0 -> 9: 1 -> 10,
		AEIOUY: 11, BP: 12, CKQ: 13
		DTF: 14, GHJ: 15, LMN: 16
		RSZ: 17, VWX: 18
	*/

	dataVal = (int *) malloc(strlen(dataStream) * sizeof (int *));

	for (dataCursor = dataStream, dataValCursor = dataVal;
	     *dataCursor != '\0'; dataCursor++, dataValCursor++)
	{
		if (*dataCursor == ' ')
		{
			*dataValCursor = 0;
			continue;
		}

		if ((*dataCursor >= '0') && (*dataCursor <= '9'))
		{
			/* BUG452 - 970903 - XMT: curChar must be an array */
			curChar[1] = '\0';
			curChar[0] = *dataCursor;
			*dataValCursor = (atoi(curChar) + 1);
			continue;
		}

		if ((*dataCursor == 'A') || (*dataCursor == 'E') ||
		    (*dataCursor == 'I') || (*dataCursor == 'O') ||
		    (*dataCursor == 'U') || (*dataCursor == 'Y'))
		{
			*dataValCursor = 11;
			continue;
		}

		if ((*dataCursor == 'B') || (*dataCursor == 'P'))
		{
			*dataValCursor = 12;
			continue;
		}

		if ((*dataCursor == 'C') || (*dataCursor == 'K') ||
		    (*dataCursor == 'Q'))
		{
			*dataValCursor = 13;
			continue;
		}

		if ((*dataCursor == 'D') || (*dataCursor == 'T') ||
		    (*dataCursor == 'F'))
		{
			*dataValCursor = 14;
			continue;
		}

		if ((*dataCursor == 'G') || (*dataCursor == 'H') ||
		    (*dataCursor == 'J'))
		{
			*dataValCursor = 15;
			continue;
		}

		if ((*dataCursor == 'L') || (*dataCursor == 'M') ||
		    (*dataCursor == 'N'))
		{
			*dataValCursor = 16;
			continue;
		}

		if ((*dataCursor == 'R') || (*dataCursor == 'S') ||
		    (*dataCursor == 'Z'))
		{
			*dataValCursor = 17;
			continue;
		}

		if ((*dataCursor == 'V') || (*dataCursor == 'W') ||
		    (*dataCursor == 'X'))
		{
			*dataValCursor = 18;
			continue;
		}
	}

	strLength = ((int)strlen(dataStream) / 7);
	dataValGrp = (int *) malloc((strLength + 1) * sizeof (int *));

	for (dataValCursor = dataValGrp + 1, dataValCursor2 = dataVal, i = 0;
	     i < strLength; dataValCursor++, i++, dataValCursor2 += 7)
	{
		*dataValCursor = (*dataValCursor2 +
				 (*(dataValCursor2 + 1) * 19) +
				 (*(dataValCursor2 + 2) * (int) power(19, 2)) +
				 (*(dataValCursor2 + 3) * (int) power(19, 3)) +
				 (*(dataValCursor2 + 4) * (int) power(19, 4)) +
				 (*(dataValCursor2 + 5) * (int) power(19, 5)) +
				 (*(dataValCursor2 + 6) * (int) power(19, 6)));
	}

	finalKey = (char *) malloc(((strLength + 2) * 5) * sizeof(char *));
	memset(finalKey, '\0', (((strLength + 2) * 5) * sizeof(char)));

	/*
	   Copy the first 5 characters from the given key.
	*/

	memcpy(finalKey, key, 5);
	finalKey[5] = ' ';
	*dataValGrp = atoi(finalKey);
	*dataValGrp *= 100000 - *dataValGrp;		/* REF1905 */

	for (dataValCursor = dataValGrp + 1, i = 0; i < strLength; dataValCursor++, i++)
	{
		*dataValCursor = (((*dataValCursor) ^ (*(dataValCursor - 1))) & ((int) power (2, 30) - 1));
	}

	for (dataValCursor = dataValGrp + 1, i = 0, dataCursor = finalKey + 6;
	     i < strLength; dataValCursor++, i++)
	{
		factor[0] = (*dataValCursor / 62);
		modulus[0] = (*dataValCursor % 62);

		for (j = 1; j < 5; j++)
		{
			factor[j] = (factor[j - 1] / 62);
			modulus[j] = (factor[j - 1] % 62);
		}

		/* Transform each of those 5 factors to characters. */
		for (j = 0; j < 5; j++)
		{
			*dataCursor = charsetFinal[modulus[4 - j]];
			dataCursor++;
		}

		*dataCursor = ' ';
		dataCursor++;
	}

	*(dataCursor - 1) = '\0';
	retCode = OP_SUCCEDED;


	if (cryptAction == CHECK)
	{
		if ((strcmp(finalKey, key)) != 0)
		{
			retCode = OP_FAILED;
		}
	}
	else
	{
		strcpy (key, finalKey);
	}

	/*
		Free allocated memory.
	*/

	free(dataStream);
	free(dataVal);
	free(dataValGrp);
	free(finalKey);

	return (retCode);
}

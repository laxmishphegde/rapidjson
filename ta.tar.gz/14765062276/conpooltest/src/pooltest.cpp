/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

// pooltest.cpp : Defines the entry point for the console application.
//
#include <conprovider.h>
#include <conpoolstatus.h>
#include <conpoolobserver.h>
#include <conexcept.h>
#include <connection.h>
#include <conpolicies.h>
#include <conlocprovider.h>
#include <condesc.h>
#include <functional>
#include <iostream>
#include <strstream>
#include <mutex>
#include <cassert>
#include <thread>
#include <vector>
using namespace std;
static AAAConnectionProvider &provider = AAAConnectionProvider::getConnectionProviderInstance();

#ifdef WIN32
__declspec(thread) void* localProvider = nullptr;
#endif

// connection type
#define DB 1
#define SRV 2
// connection model
#define ORACLE 10
#define SYBASE 11
#define HTTP 99999
// connection role
#define ROLE1 1
#define ROLE2 2

enum LogEventLevel {
	DEBUG,
	INFO,
	WARNING,
	ERROR,
	NOLOG
};
class Logger {
public:
	Logger(std::string signature) :signature(signature), out(cout), err(cerr), logLevel(INFO) {}
	Logger(std::string signature, std::ostream& out, std::ostream& err) :signature(signature), out(out), err(err),  logLevel(INFO) {}
	void error( const std::string& message) {
		if (logLevel > ERROR) return;
		ostrstream  strstream;
		sign(strstream, "ERROR") << message << ends;
		mutex.lock();	err << strstream.str() << endl;	mutex.unlock();
	}
	void error(const std::string& message, const  exception&e) {
		if (logLevel > ERROR) return;
		mutex.lock();
		ostrstream  strstream;
		sign(strstream, "ERROR") << message << "- what:" << e.what()<< ends;
		err << strstream.str() << endl;	mutex.unlock();
	}
	void warning(const std::string& message) {
		if (logLevel > WARNING) return;
		ostrstream  strstream;
		sign(strstream, "WARNING") << message << ends;
		mutex.lock();out << strstream.str() << endl;mutex.unlock();
	}
	void info(const std::string& message) {
		if (logLevel > INFO) return;
		ostrstream  strstream;
		sign(strstream, "INFO") << message << ends;
		mutex.lock();out << strstream.str() << endl;mutex.unlock();
	}
	void debug(const std::string& message) {
		if (logLevel > DEBUG) return;
		ostrstream  strstream;
		sign(strstream, "DEBUG") << message << ends;
		mutex.lock(); out << strstream.str() << endl; mutex.unlock();
	}
	void setLogLevel(const LogEventLevel& level) { logLevel = level; }
private:
	ostrstream&  sign(ostrstream& str, const char* level) { str << signature << "-" << level << " :"; return str; }
	LogEventLevel logLevel;
	std::mutex mutex;
	std::ostream& out;
	std::ostream& err;
	std::string signature;
};

AAALocalConnectionProvider * SYS_GetThreadLocalConnectionProvider(){
	return static_cast<AAALocalConnectionProvider *>(localProvider);
}

/*DLA To remove */
void SYS_SetThreadLocalConnectionProvider(AAALocalConnectionProvider * p_localProvider){
	localProvider = p_localProvider;
}


/** ---------------------------------------------------------------------------------------------------
 *  Connection Classes
 ** ---------------------------------------------------------------------------------------------------*/
class ORADBConnectionStub : protected AAAConnection {
public :
	static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id) {return new ORADBConnectionStub(spec, id);}
	bool connect() { return true; }
	bool disconnect() {return true; }
	bool isValid() { return true; }
	void clean() {}
	void installSessionProperties(){}
	void removeSessionProperties() {}
	void uninstallSessionProperties(){}
	void installSessionProperty(const std::string& context, const std::string& name, const std::string &value){}
	void uninstallSessionProperty(const std::string& context, const std::string& name){}
	void setValidConnection(bool)  {}
	bool changePassword(const PasswordEncrypted&) { return true; }
	bool changePassword(const  std::string& user, const PasswordEncrypted& password)  { return true; }
private:
	

	ORADBConnectionStub(const AAAConnectionSpecification& spec, const int& id) : AAAConnection(spec, id) {}
};

class SYBDBConnectionStub :protected AAAConnection {
public:
	static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id) {return new SYBDBConnectionStub(spec, id);}
	bool connect() {return true; }
	bool disconnect() {return true; }
	bool isValid() { return true; }
	void clean() {}
	void installSessionProperties(){}
	void removeSessionProperties() {}
	void uninstallSessionProperties(){}
	void installSessionProperty(const std::string& context, const std::string& name, const std::string &value){}
	void uninstallSessionProperty(const std::string& context, const std::string& name){}
	void setValidConnection(bool)  {}
	bool changePassword(const PasswordEncrypted&) { return true; }
	bool changePassword(const  std::string& user, const PasswordEncrypted& password)  { return true; }

private:
	SYBDBConnectionStub(const AAAConnectionSpecification& spec, const int& id) : AAAConnection(spec, id) {}
};
class SYBSRVConnectionStub :protected AAAConnection {
public:
	static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id) {	return new SYBSRVConnectionStub(spec, id);}
	bool connect() {return true; }
	bool disconnect() { return true; }
	bool isValid() { return true; }
	void clean() {}
	void installSessionProperties(){}
	void removeSessionProperties() {}
	void uninstallSessionProperties(){}
	void installSessionProperty(const std::string& context, const std::string& name, const std::string &value){}
	void uninstallSessionProperty(const std::string& context, const std::string& name){}
	void setValidConnection(bool)  {}
	bool changePassword(const PasswordEncrypted&) { return true; }
	bool changePassword(const  std::string& user, const PasswordEncrypted& password)  { return true; }

private:
	SYBSRVConnectionStub(const AAAConnectionSpecification& spec, const int& id) : AAAConnection(spec, id) {}
};
class HTTPSRVConnectionStub :protected AAAConnection {
public:
	static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id) {	return new HTTPSRVConnectionStub(spec, id);	}
	bool connect() { return true; }
	bool disconnect() { return true; }
	bool isValid() { return true; }
	void clean() {}
	void installSessionProperties(){}
	void removeSessionProperties() {}
	void uninstallSessionProperties(){}
	void installSessionProperty(const std::string& context, const std::string& name, const std::string &value){}
	void uninstallSessionProperty(const std::string& context, const std::string& name){}
	void setValidConnection(bool)  {}
	bool changePassword(const PasswordEncrypted&) { return true; }
	bool changePassword(const  std::string& user, const PasswordEncrypted& password)  { return true; }

private:
	HTTPSRVConnectionStub(const AAAConnectionSpecification& spec, const int& id) : AAAConnection(spec, id) {	}
};

/** ---------------------------------------------------------------------------------------------------
*  Observer
** ---------------------------------------------------------------------------------------------------*/
class EventCounter{
public:
	EventCounter() {
		 connectionCreatedEventCount = 0;
		 connectionDeletedEventCount = 0;
		 connectionTakenEventCount = 0;
		 connectionReleasedEventCount = 0;
		 connectionConnectedEventCount = 0;
		 connectionDisconnectedEventCount = 0 ;
	}
	EventCounter(const EventCounter& source) {
		connectionCreatedEventCount = source.connectionCreatedEventCount;
		connectionDeletedEventCount = source.connectionDeletedEventCount;
		connectionTakenEventCount = source.connectionTakenEventCount;
		connectionReleasedEventCount = source.connectionReleasedEventCount;
		connectionConnectedEventCount = source.connectionConnectedEventCount;
		connectionDisconnectedEventCount = source.connectionDisconnectedEventCount;
	}
	void operator = (const EventCounter& source) {
		connectionCreatedEventCount = source.connectionCreatedEventCount;
		connectionDeletedEventCount = source.connectionDeletedEventCount;
		connectionTakenEventCount = source.connectionTakenEventCount;
		connectionReleasedEventCount = source.connectionReleasedEventCount;
		connectionConnectedEventCount = source.connectionConnectedEventCount;
		connectionDisconnectedEventCount = source.connectionDisconnectedEventCount;
	}
	~EventCounter() {
	}
	void reset() {
		connectionCreatedEventCount = 0;
		connectionDeletedEventCount = 0;
		connectionTakenEventCount = 0;
		connectionReleasedEventCount = 0;
		connectionConnectedEventCount = 0;
		connectionDisconnectedEventCount = 0;
	}
	const int& getCreatedEventCount() const		{ return connectionCreatedEventCount;		}
	const int& getDeletedEventCount() const		{ return  connectionDeletedEventCount;		}
	const int& getTakenEventCount() const		{ return  connectionTakenEventCount;		}
	const int& getReleasedEventCount() const	{ return  connectionReleasedEventCount;		}
	const int& getConnectedEventCount() const	{ return  connectionConnectedEventCount;	}
	const int& getDisconnectedEventCount() const{ return  connectionDisconnectedEventCount; }

	void createdEventCountInc()			{ connectionCreatedEventCount++;		}
	void deletedEventCountInc()			{ connectionDeletedEventCount++;		}
	void takenEventCountInc()			{ connectionTakenEventCount++;			}
	void releasedEventCountInc()		{ connectionReleasedEventCount++;		}
	void connectedEventCountInc()		{ connectionConnectedEventCount++;		}
	void disconnectedEventCountInc()	{ connectionDisconnectedEventCount++;	}
private:
	int connectionCreatedEventCount;
	int connectionDeletedEventCount;
	int connectionTakenEventCount;
	int connectionReleasedEventCount;
	int connectionConnectedEventCount;
	int connectionDisconnectedEventCount;
};

class TestPoolObserver : public AAAConnectionPoolObserver {
public:
	TestPoolObserver(Logger& logger): logger(logger) {}
	void  operator=(const TestPoolObserver& ) = delete;
	TestPoolObserver(const TestPoolObserver&) = delete;
	void processEvent(const AAAConnectionPoolEvent& event) {

		switch (event.getEventType()){
		case	ConnectionCreated:		createdEventCountInc(event.getDescriptor());		break;
		case	ConnectionDeleted:		deletedEventCountInc(event.getDescriptor());		break;
		case	ConnectionTaken:		takenEventCountInc(event.getDescriptor());			break;
		case	ConnectionReleased:		releasedEventCountInc(event.getDescriptor());		break;
		case	ConnectionConnected:	connectedEventCountInc(event.getDescriptor());		break;
		case	ConnectionDisconnected:	disconnectedEventCountInc(event.getDescriptor());	break;
		}
		strstream strstr; strstr << "received_event:" << event << ends; 
		std::string receiveInfo = strstr.str();
		logger.debug(receiveInfo);
		
	}
	void reset() {
		counterMap.clear();
	}
	void reset(const AAAConnectionDescription &desc) {
		getCounter(desc).reset();
	}
	const int& getCreatedEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getCreatedEventCount(); }
	const int& getDeletedEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getDeletedEventCount(); }
	const int& getTakenEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getTakenEventCount(); }
	const int& getReleasedEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getReleasedEventCount(); }
	const int& getConnectedEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getConnectedEventCount(); }
	const int& getDisconnectedEventCount(const AAAConnectionDescription& desc)  { return getCounter(desc).getDisconnectedEventCount(); }
private:


	void createdEventCountInc(const AAAConnectionDescription& desc)		{ return getCounter(desc).createdEventCountInc(); }
	void deletedEventCountInc(const AAAConnectionDescription& desc)		{ return getCounter(desc).deletedEventCountInc(); }
	void takenEventCountInc(const AAAConnectionDescription& desc)			{ return getCounter(desc).takenEventCountInc(); }
	void releasedEventCountInc(const AAAConnectionDescription& desc)		{ return getCounter(desc).releasedEventCountInc(); }
	void connectedEventCountInc(const AAAConnectionDescription& desc)		{ return getCounter(desc).connectedEventCountInc(); }
	void disconnectedEventCountInc(const AAAConnectionDescription& desc)	{ return getCounter(desc).disconnectedEventCountInc(); }


	 EventCounter& getCounter(const AAAConnectionDescription& desc) {
		 EventCounter* res = nullptr;
		 try {
			res =counterMap.at(desc);
		 }
		 catch (std::out_of_range& ) {
			  res = new EventCounter();
			  counterMap.emplace(desc, res);
		 }
		 return *res;
	}

	
	Logger &logger;
	std::map<AAAConnectionDescription, EventCounter*> counterMap;
};








template <class Provider>
class ConnectionProviderTest  {

public:
	ConnectionProviderTest(Provider& provider, Logger	& logger, TestPoolObserver& observer, const AAAConnectionPoolConfiguration& config): 
		provider(provider),
		logger(logger),
		observer(observer),
		config(config) {
	}
	~ConnectionProviderTest() {}
	virtual void run() = 0;
protected:
	Provider& provider;
	Logger& logger;
	TestPoolObserver& observer;
	AAAConnectionPoolConfiguration config;

	AAAConnection* testGetConnection(const AAAConnectionDescription & desc, bool errorExpected, bool impactCentralProvider);
	AAAConnection* testGetConnectionById(const AAAConnectionDescription & desc, const int id, bool errorExpected);
	void testReleaseConnection(AAAConnection* connection, bool errorExpected, bool impactCentralProvider);
	void _run(bool usePreferredConnection);
private:
	void operator=(ConnectionProviderTest<Provider> &) = delete;

};

template <class Provider>
AAAConnection* ConnectionProviderTest<Provider>::testGetConnection(const AAAConnectionDescription & desc, bool errorExpected, bool impactCentralProvider) {
	bool exceptionCaugth = false;
	AAAConnection* res = nullptr;
	observer.reset(desc);
	AAAConnectionPoolStatus *initPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());

	try {		res = provider.getConnection(desc);	}
	catch (exception e) {
		logger.error("testGetConnection  - expected exception arrived", e);
		exceptionCaugth = true;
	}
	if (errorExpected) {
		assert(exceptionCaugth);
		assert(res == nullptr);
	}
	else {
		assert(!exceptionCaugth);
		assert(res != nullptr);
		assert(res->getDescription() == config.getDescription());
		assert(res->isInUse());
	}
	AAAConnectionPoolStatus *afterPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
	if (errorExpected || !impactCentralProvider) {
		assert(*afterPoolStatus == *initPoolStatus);
		assert(observer.getCreatedEventCount(config.getDescription()) == 0);
		assert(observer.getConnectedEventCount(config.getDescription()) == 0);
		assert(observer.getDeletedEventCount(config.getDescription()) == 0);
		assert(observer.getDisconnectedEventCount(config.getDescription()) == 0);
		assert(observer.getReleasedEventCount(config.getDescription()) == 0);
		assert(observer.getTakenEventCount(config.getDescription()) == 0);
	}
	else{
		assert(afterPoolStatus->getUsedConnectionsCount() == initPoolStatus->getUsedConnectionsCount() + 1);
		assert(initPoolStatus->getAvailableConnectionsCount() == 0 ? afterPoolStatus->getAvailableConnectionsCount() == 0 : afterPoolStatus->getAvailableConnectionsCount() == initPoolStatus->getAvailableConnectionsCount() - 1);
		
		if (initPoolStatus->getAvailableConnectionsCount() == 0) { assert(observer.getCreatedEventCount(config.getDescription()) == 1); }
		else                                                     { assert(observer.getCreatedEventCount(config.getDescription()) == 0); }
		if ((initPoolStatus->getAvailableConnectionsCount() == 0) || (config.getPolicies().getConnectionPolicy() == ConnectAtUse) ) {
			assert(observer.getConnectedEventCount(config.getDescription()) == 1);
		}
		else {
			assert(observer.getConnectedEventCount(config.getDescription()) == 0);

		}
		assert(observer.getDeletedEventCount(config.getDescription()) == 0);
		assert(observer.getDisconnectedEventCount(config.getDescription()) == 0);
		assert(observer.getReleasedEventCount(config.getDescription()) == 0);
		assert(observer.getTakenEventCount(config.getDescription()) == 1);
	}
	delete afterPoolStatus;
	delete initPoolStatus;
	return res;
}



template <class Provider>
AAAConnection* ConnectionProviderTest<Provider>::testGetConnectionById(const AAAConnectionDescription & desc, const int id, bool errorExpected) {
	bool exceptionCaugth = false;
	AAAConnection* res = nullptr;
	observer.reset(desc);
	AAAConnectionPoolStatus *initPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());

	try {
		res = provider.getConnection(id);
	}
	catch (exception e) {
		logger.error("testGetConnectionById  - expected exception arrived", e);
		exceptionCaugth = true;
	}
	if (errorExpected) {
		assert(exceptionCaugth);
		assert(res == nullptr);
	}
	else {
		assert(!exceptionCaugth);
		assert(res != nullptr);
		assert(res->getDescription() == config.getDescription());
		assert(res->isInUse());
	}
	AAAConnectionPoolStatus *afterPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
	assert(*afterPoolStatus == *initPoolStatus);
	assert(observer.getCreatedEventCount(config.getDescription()) == 0);
	assert(observer.getConnectedEventCount(config.getDescription()) == 0);
	assert(observer.getDeletedEventCount(config.getDescription()) == 0);
	assert(observer.getDisconnectedEventCount(config.getDescription()) == 0);
	assert(observer.getReleasedEventCount(config.getDescription()) == 0);
	assert(observer.getTakenEventCount(config.getDescription()) == 0);
	return res;
}

template <class Provider>
void ConnectionProviderTest<Provider>::testReleaseConnection(AAAConnection* connection, bool errorExpected, bool impactCentralProvider) {
	bool exceptionCaugth = false;
	
	observer.reset(connection->getDescription());
	AAAConnectionPoolStatus *initPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
	try {	provider.release(connection);	}
	catch (exception e) {
		logger.error("testReleaseConnection  - expected exception arrived", e);
		exceptionCaugth = true;
	}
	if (errorExpected) {
		assert(exceptionCaugth);
	}
	else {
		assert(!exceptionCaugth);
		assert(!impactCentralProvider || !connection->isInUse());
	}
	AAAConnectionPoolStatus *afterPoolStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
	if (errorExpected || !impactCentralProvider) {
		assert(*afterPoolStatus == *initPoolStatus);
		assert(observer.getCreatedEventCount(connection->getDescription()) == 0);
		assert(observer.getConnectedEventCount(connection->getDescription()) == 0);
		assert(observer.getDeletedEventCount(connection->getDescription()) == 0);
		assert(observer.getDisconnectedEventCount(connection->getDescription()) == 0);
		assert(observer.getReleasedEventCount(connection->getDescription()) == 0);
		assert(observer.getTakenEventCount(connection->getDescription()) == 0);
	}
	else {
		assert(!connection->isInUse());
		assert(observer.getCreatedEventCount(connection->getDescription()) == 0);
		assert(observer.getConnectedEventCount(connection->getDescription()) == 0);
		assert(observer.getTakenEventCount(connection->getDescription()) == 0);
		
		assert(observer.getReleasedEventCount(connection->getDescription()) == 1);
		if (config.getPolicies().getDisconnectionPolicy() == DisconnectAtRelease)	assert(observer.getDisconnectedEventCount(connection->getDescription()) == 1);
		else assert(observer.getDisconnectedEventCount(connection->getDescription()) == 0);
		assert(observer.getDeletedEventCount(connection->getDescription()) == 0);
	}
}



template <class Provider>
void ConnectionProviderTest<Provider>::_run(bool preferredConnectionModel) {
	observer.reset(config.getDescription());
	AAAConnection* connection = nullptr;
	AAAConnection* connectionById = nullptr;

	connection = testGetConnection(config.getDescription(), false, true);
	connectionById = testGetConnectionById(config.getDescription(), connection->getId(), false);
	testReleaseConnection(connection, false, !preferredConnectionModel);
	connectionById = testGetConnectionById(config.getDescription(), connection->getId(), true);
	testReleaseConnection(connection, true, !preferredConnectionModel);
	AAAConnection* secondConnection = testGetConnection(config.getDescription(), false, !preferredConnectionModel);
	testReleaseConnection(secondConnection, false, !preferredConnectionModel);


	connection = testGetConnection(config.getDescription(), false, !preferredConnectionModel);
	secondConnection = testGetConnection(config.getDescription(), false, true);
	testReleaseConnection(connection, false, !preferredConnectionModel);
	testReleaseConnection(secondConnection, false, true);
	secondConnection = testGetConnection(config.getDescription(), false, !preferredConnectionModel);
	assert(connection == secondConnection);
	testReleaseConnection(secondConnection, false, !preferredConnectionModel);


	int maxLoop = config.getMaxsize() ;
	std::vector<AAAConnection*> connToRelease;
	for (int i = 0; i <= maxLoop; i++) {
		if (i == 0)            {connToRelease.push_back(testGetConnection(config.getDescription(), false, !preferredConnectionModel));}
		else if (i == maxLoop) {                        testGetConnection(config.getDescription(), true, false);		              }
		else                   {connToRelease.push_back(testGetConnection(config.getDescription(), false, true));                      }
	}
	for (auto con : connToRelease) {
		provider.release(con);
	}

}


class CentralConnectionProviderTest : public ConnectionProviderTest<AAAConnectionProvider>{
public :
	CentralConnectionProviderTest(AAAConnectionProvider& provider,
		Logger	& logger, 
		TestPoolObserver& observer, 
		const AAAConnectionPoolConfiguration& config) : ConnectionProviderTest<AAAConnectionProvider>(provider, logger, observer, config){
	}
	~CentralConnectionProviderTest() {};
	CentralConnectionProviderTest() = delete; 
	void operator = (const CentralConnectionProviderTest &)= delete;
	void run() { _run(false); }
};



class LocalConnectionProviderTest : public ConnectionProviderTest<AAALocalConnectionProvider>{
public:
	LocalConnectionProviderTest(AAALocalConnectionProvider& provider, Logger	& logger, TestPoolObserver& observer, const AAAConnectionPoolConfiguration& config) 
		: ConnectionProviderTest<AAALocalConnectionProvider>(provider, logger, observer, config){
	}
	~LocalConnectionProviderTest() {}
	LocalConnectionProviderTest() = delete;
	void operator = (const LocalConnectionProviderTest &) = delete;

	void run() { _run(true); testReset(); }
private:
	void testReset() {
		observer.reset(config.getDescription());
		AAAConnectionPoolStatus * startStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
		provider.reset();
		AAAConnectionPoolStatus * afterStatus = AAAConnectionProvider::getConnectionProviderInstance().getPoolStatus(config.getDescription());
		
	}
};


void startLocalProviderTest(std::string name, TestPoolObserver* observer, const AAAConnectionPoolConfiguration& config) {
	Logger threadLogger(name);
	threadLogger.setLogLevel(DEBUG);
	LocalConnectionProviderTest test (
		AAALocalConnectionProvider::get(),
		threadLogger,
		*observer, 
		config);
	test.run();
}

void testGlobalProviderTest(Logger &logger , TestPoolObserver* observer, vector<AAAConnectionPoolConfiguration>& configs) {
	logger.setLogLevel(INFO);
	for (AAAConnectionPoolConfiguration& conf : configs) {
		std::ostrstream strinfo;
		strinfo << ">testing " << conf << ends;
		logger.info(strinfo.str());
		CentralConnectionProviderTest test (AAAConnectionProvider::getConnectionProviderInstance(),logger, *observer, conf);
		test.run();
	}
}


void testLocLProviderTest(Logger &logger, TestPoolObserver* observer, vector<AAAConnectionPoolConfiguration>& configs) {
	std::vector<std::thread*> threads;
	logger.setLogLevel(DEBUG);
	int i = 0;
	char name[20];
	for (AAAConnectionPoolConfiguration& conf : configs) {
		logger.info("starting new trhead");
		sprintf(name, "%d", i);
		std::thread* t = new std::thread(&startLocalProviderTest, name, observer, conf);
		threads.push_back(t);
		i++;
	}
	for (std::thread* t: threads) {
		t->join();
	}
}

int testpool() {
	Logger mainLogger("main");
	TestPoolObserver observer(mainLogger);
	vector<AAAConnectionPoolConfiguration> config;
	mainLogger.setLogLevel(INFO);
	PasswordEncrypted sybpassword1;
	sybpassword1.setClearPassword("sybpassword1");
	PasswordEncrypted sybpassword2;
	sybpassword2.setClearPassword("sybpassword2");
	PasswordEncrypted orapassword1;
	orapassword1.setClearPassword("orapassword1");

	config.push_back(AAAConnectionPoolConfiguration(AAAConnectionDescription(ROLE1, DB, SYBASE, "sybuser1"), 10, sybpassword1, "sybconnection1", AAAConnectionPolicies(AAAConnectionPolicy::ConnectAtCreate, AAADisconnectionPolicy::DisconnectAtDelete, AAAAgingPolicy::NoAging, 0)));
	config.push_back(AAAConnectionPoolConfiguration(AAAConnectionDescription(ROLE2, DB, SYBASE, "sybuser2"), 20, sybpassword2, "sybconnection2", AAAConnectionPolicies(AAAConnectionPolicy::ConnectAtCreate, AAADisconnectionPolicy::DisconnectAtDelete, AAAAgingPolicy::NoAging, 0)));
	config.push_back(AAAConnectionPoolConfiguration(AAAConnectionDescription(ROLE1, DB, ORACLE, "orauser1"), 20, orapassword1, "oraconnection1", AAAConnectionPolicies(AAAConnectionPolicy::ConnectAtCreate, AAADisconnectionPolicy::DisconnectAtDelete, AAAAgingPolicy::NoAging, 0)));
	config.push_back(AAAConnectionPoolConfiguration(AAAConnectionDescription(ROLE1, SRV, HTTP, "http1"), 5, orapassword1, "oraconnection1", AAAConnectionPolicies(AAAConnectionPolicy::ConnectAtUse, AAADisconnectionPolicy::DisconnectAtRelease, AAAAgingPolicy::NoAging, 0)));

	try {
		AAAConnectionProvider::getConnectionProviderInstance().setObserver(&observer);
		AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(DB, SYBASE, &SYBDBConnectionStub::createConnection);
		AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(DB, ORACLE, &ORADBConnectionStub::createConnection);
		AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SRV, SYBASE, &SYBSRVConnectionStub::createConnection);
		AAAConnectionProvider::getConnectionProviderInstance().registerAllocator(SRV, HTTP, &HTTPSRVConnectionStub::createConnection);
		provider.configure(config);
	}
	catch (std::bad_function_call& e) {
		mainLogger.error("initPovider error:", e);
	}
	testGlobalProviderTest(mainLogger, &observer, config);
	testLocLProviderTest(mainLogger, &observer, config);
	AAAConnectionProvider::getConnectionProviderInstance().setObserver(nullptr);
	return 0;
}

void main(){
	testpool();
}

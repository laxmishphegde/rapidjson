/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "conproptree.h"
#include <cassert>
#include <string>
void testNode() {
	AAASessionPropertyNode node(0);
	std::string props[9][3] = {
		{ "ctx1", "prop11", "v11" },
		{ "ctx1", "prop12", "v12" },
		{ "ctx1", "prop13", "v13" },
		{ "ctx2", "prop21", "v21" },
		{ "ctx2", "prop22", "v22" },
		{ "ctx2", "prop23", "v23" },
		{ "ctx3", "prop31", "v31" },
		{ "ctx3", "prop32", "v32" },
		{ "ctx3", "prop33", "v33" }
	};
	for (int i = 0; i < 9; i++) {
		assert(node.getValue().add(props[i][0], AAAConnectionProperty(props[i][1], props[i][2])) == true);
	}
	for (int i = 0; i < 9; i++) {
		const AAAConnectionProperty* v = node.getValue().get(props[i][0], props[i][1]);
		assert(v != nullptr);
		assert(strcmp(v->getValue().c_str(), props[i][2].c_str()) == 0);
	}
	for (int i = 0; i < 9; i++) {
		assert(node.getValue().add(props[i][0], AAAConnectionProperty(props[i][1], props[i][2])) == false);
	}
	for (int i = 0; i < 9; i++) {
		std::string oldValue;
		assert(node.getValue().set(props[i][0], props[i][1], props[i][2], oldValue) == true);
		assert(strcmp(oldValue.c_str(), props[i][2].c_str()) == 0);
	}
	std::string oldValue;
	assert(node.getValue().set("dummy", "dummy", "v", oldValue) == false);
	assert(node.getValue().set("ctx3", "dummy", "v", oldValue) == false);
	for (int i = 0; i < 9; i++) {
		assert(node.getValue().remove(props[i][0], props[i][1]) == true);
		assert(node.getValue().remove(props[i][0], props[i][1]) == false);
	}
	for (int i = 0; i < 9; i++) {
		const AAAConnectionProperty* v = node.getValue().get(props[i][0], props[i][1]);
		assert(v == nullptr);
	}
}


void testBaseNode() {
	std::string props[9][3] = {
		{ "ctx1", "prop11", "v11" },
		{ "ctx1", "prop12", "v12" },
		{ "ctx1", "prop13", "v13" },
		{ "ctx2", "prop21", "v21" },
		{ "ctx2", "prop22", "v22" },
		{ "ctx2", "prop23", "v23" },
		{ "ctx3", "prop31", "v31" },
		{ "ctx3", "prop32", "v32" },
		{ "ctx3", "prop33", "v33" } 
	};

	AAASessionPropertyNode top(0, nullptr);
	AAASessionPropertyNode node10(10, &top);
	AAASessionPropertyNode node11(11, &top);
	AAASessionPropertyNode node100(100, &node10);
	AAASessionPropertyNode node101(101, &node10);
	AAASessionPropertyNode node110(110, &node11);
	AAASessionPropertyNode node111(111, &node11);

	assert(top.getParent() == nullptr);
	assert(node111.getParent() == &node11);
	assert(node110.getParent() == &node11);
	assert(node101.getParent() == &node10);
	assert(node100.getParent() == &node10);
	assert(node11.getParent() == &top);
	assert(node10.getParent() == &top);

	std::vector<AAASessionPropertyNode*> nodes;
	nodes.push_back(&top);
	nodes.push_back(&node111);
	nodes.push_back(&node110);
	nodes.push_back(&node101);
	nodes.push_back(&node100);
	nodes.push_back(&node11);
	nodes.push_back(&node10);

	std::vector<int> searchPath;
	searchPath.push_back(10);
	searchPath.push_back(101);
	AAASessionPropertyNodeSearcher fullsearcher(searchPath);
	top.search(fullsearcher);
	assert(fullsearcher.isPerfectMatch());
	assert(fullsearcher.getMatchingNodes().size() == 2);
	assert(fullsearcher.getMatchingNodes().at(0) == &node10);
	assert(fullsearcher.getMatchingNodes().at(1) == &node101);



	searchPath.push_back(1000);
	AAASessionPropertyNodeSearcher incompletesearcher(searchPath);
	top.search(incompletesearcher);
	assert(!incompletesearcher.isPerfectMatch());
	assert(incompletesearcher.getMatchingNodes().size() == 2);
	assert(incompletesearcher.getMatchingNodes().at(0) == &node10);
	assert(incompletesearcher.getMatchingNodes().at(1) == &node101);

	for (AAASessionPropertyNode* node : nodes) {
		for (auto prop : props) {
			char newValue[255] = "";
			sprintf(newValue, "%s-node-%d", prop[2].c_str(), node->getKey());
			assert(node->getValue().add(prop[0], AAAConnectionProperty(prop[1], newValue)));
		}
	}

	AAASessionPropertyAggregator agg;
	node101.visit(agg);
	for (auto prop : props) {
		char expectedValue[255] = "";
		sprintf(expectedValue, "%s-node-%d", prop[2].c_str(), node101.getKey()); 
		assert(strcmp(agg.getPropertyMap().at(prop[0]).at(prop[1]).c_str(), expectedValue) == 0);
	}
	
	AAASessionPropertyNode node1010(0, &node101);
	node1010.visit(agg);
	for (auto prop : props) {
		char expectedValue[255] = "";
		sprintf(expectedValue, "%s-node-%d", prop[2].c_str(), node101.getKey());
		assert(strcmp(agg.getPropertyMap().at(prop[0]).at(prop[1]).c_str(), expectedValue) == 0);
	}
}



void testSessTree() {
	AAASessionProperyTree sessPropTree;


	assert(sessPropTree.putSessionProperty(0, "ctx1", "prop11", "r0-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, "ctx1", "prop12", "r0-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, "ctx1", "prop13", "r0-ctx1-prop13-v"));
	assert(sessPropTree.putSessionProperty(0, "ctx2", "prop21", "r0-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(0, 0, "ctx1", "prop11", "r0m1-ctx1-prop01-v"));
	assert(sessPropTree.putSessionProperty(0, 0, "ctx1", "prop12", "r0m1-ctx1-prop02-v"));
	assert(sessPropTree.putSessionProperty(0, 0, "ctx1", "prop14", "r0m1-ctx1-prop04-v"));
	assert(sessPropTree.putSessionProperty(0, 0, "ctx2", "prop21", "r0m1-ctx2-prop01-v"));


	assert(sessPropTree.putSessionProperty(0, 0, 0, "ctx1", "prop11", "r0m0t0-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 0, "ctx1", "prop12", "r0m0t0-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 0, "ctx1", "prop15", "r0m0t0-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 0, "ctx2", "prop21", "r0m0t0-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(0, 0, 1, "ctx1", "prop11", "r0m0t1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 1, "ctx1", "prop12", "r0m0t1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 1, "ctx1", "prop15", "r0m0t1-ctx1-prop14-v"));
	assert(sessPropTree.putSessionProperty(0, 0, 1, "ctx2", "prop21", "r0m0t1-ctx2-prop21-v"));

	assert(sessPropTree.putSessionProperty(0, 1, "ctx1", "prop11", "r0m1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, 1, "ctx1", "prop12", "r0m1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, 1, "ctx1", "prop14", "r0m1-ctx1-prop14-v"));
	assert(sessPropTree.putSessionProperty(0, 1, "ctx2", "prop21", "r0m1-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(0, 1, 0, "ctx1", "prop11", "r0m1t0-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 0, "ctx1", "prop12", "r0m1t0-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 0, "ctx1", "prop15", "r0m1t0-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 0, "ctx2", "prop21", "r0m1t0-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(0, 1, 1, "ctx1", "prop11", "r0m1t1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 1, "ctx1", "prop12", "r0m1t1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 1, "ctx1", "prop15", "r0m1t1-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(0, 1, 1, "ctx2", "prop21", "r0m1t1-ctx2-prop21-v"));



	assert(sessPropTree.putSessionProperty(1, "ctx1", "prop11", "r1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, "ctx1", "prop12", "r1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, "ctx1", "prop13", "r1-ctx1-prop13-v"));
	assert(sessPropTree.putSessionProperty(1, "ctx2", "prop21", "r1-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(1, 0, "ctx1", "prop11", "r1m1-ctx1-prop01-v"));
	assert(sessPropTree.putSessionProperty(1, 0, "ctx1", "prop12", "r1m1-ctx1-prop02-v"));
	assert(sessPropTree.putSessionProperty(1, 0, "ctx1", "prop14", "r1m1-ctx1-prop04-v"));
	assert(sessPropTree.putSessionProperty(1, 0, "ctx2", "prop21", "r1m1-ctx2-prop01-v"));


	assert(sessPropTree.putSessionProperty(1, 0, 0, "ctx1", "prop11", "r1m0t0-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 0, "ctx1", "prop12", "r1m0t0-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 0, "ctx1", "prop15", "r1m0t0-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 0, "ctx2", "prop21", "r1m0t0-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(1, 0, 1, "ctx1", "prop11", "r1m0t1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 1, "ctx1", "prop12", "r1m0t1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 1, "ctx1", "prop15", "r1m0t1-ctx1-prop14-v"));
	assert(sessPropTree.putSessionProperty(1, 0, 1, "ctx2", "prop21", "r1m0t1-ctx2-prop21-v"));

	assert(sessPropTree.putSessionProperty(1, 1, "ctx1", "prop11", "r1m1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, 1, "ctx1", "prop12", "r1m1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, 1, "ctx1", "prop14", "r1m1-ctx1-prop14-v"));
	assert(sessPropTree.putSessionProperty(1, 1, "ctx2", "prop21", "r1m1-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(1, 1, 0, "ctx1", "prop11", "r1m1t0-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 0, "ctx1", "prop12", "r1m1t0-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 0, "ctx1", "prop15", "r1m1t0-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 0, "ctx2", "prop21", "r1m1t0-ctx2-prop21-v"));


	assert(sessPropTree.putSessionProperty(1, 1, 1, "ctx1", "prop11", "r1m1t1-ctx1-prop11-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 1, "ctx1", "prop12", "r1m1t1-ctx1-prop12-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 1, "ctx1", "prop15", "r1m1t1-ctx1-prop15-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 1, "ctx2", "prop21", "r1m1t1-ctx2-prop21-v"));
	assert(sessPropTree.putSessionProperty(1, 1, 1, "ctx2", "prop21", "r1m1t1-ctx2-prop21-v")==false);

	std::vector<AAASessionProperty> sessionProperties;

	AAAConnectionPropertyRegistry* finalRegistry = new AAAConnectionPropertyRegistry();
	sessPropTree.getProperties(AAAConnectionDescription(1, 1, 1,""), sessionProperties);
	assert(sessionProperties.size() == 6);

	for (auto it = sessionProperties.begin(); it < sessionProperties.end(); it++) {
		assert(finalRegistry->add(it->getContext(), AAAConnectionProperty(it->getPropertyName(), it->getPropertyValue())));
	}
	assert(strcmp(finalRegistry->get("ctx1", "prop11")->getValue().c_str(), "r1m1t1-ctx1-prop11-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop12")->getValue().c_str(), "r1m1t1-ctx1-prop12-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop13")->getValue().c_str(), "r1-ctx1-prop13-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop14")->getValue().c_str(), "r1m1-ctx1-prop14-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop15")->getValue().c_str(), "r1m1t1-ctx1-prop15-v") == 0);
	assert(strcmp(finalRegistry->get("ctx2", "prop21")->getValue().c_str(), "r1m1t1-ctx2-prop21-v") == 0);
	delete (finalRegistry);
	sessionProperties.clear();


	finalRegistry = new AAAConnectionPropertyRegistry();
	sessPropTree.getProperties(AAAConnectionDescription(0, 1, 1, ""), sessionProperties);
	assert(sessionProperties.size() == 6);
	for (auto it = sessionProperties.begin(); it < sessionProperties.end(); it++) {
		assert(finalRegistry->add(it->getContext(), AAAConnectionProperty(it->getPropertyName(), it->getPropertyValue())));
	}
	assert(strcmp(finalRegistry->get("ctx1", "prop11")->getValue().c_str(), "r0m1t1-ctx1-prop11-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop12")->getValue().c_str(), "r0m1t1-ctx1-prop12-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop13")->getValue().c_str(), "r0-ctx1-prop13-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop14")->getValue().c_str(), "r0m1-ctx1-prop14-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop15")->getValue().c_str(), "r0m1t1-ctx1-prop15-v") == 0);
	assert(strcmp(finalRegistry->get("ctx2", "prop21")->getValue().c_str(), "r0m1t1-ctx2-prop21-v") == 0);
	delete (finalRegistry);
	sessionProperties.clear();

	sessPropTree.putSessionProperty(1, 1, 2, "ctx10", "prop12", "r1m1t2-ctx10-prop12-v");
	finalRegistry = new AAAConnectionPropertyRegistry();
	sessPropTree.getProperties(AAAConnectionDescription(1, 1, 2, ""), sessionProperties);
	for (auto it = sessionProperties.begin(); it < sessionProperties.end(); it++) {
		assert(finalRegistry->add(it->getContext(), AAAConnectionProperty(it->getPropertyName(), it->getPropertyValue())));
	}
	assert(sessionProperties.size() == 6);
	assert(strcmp(finalRegistry->get("ctx1", "prop11")->getValue().c_str(), "r1m1-ctx1-prop11-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop12")->getValue().c_str(), "r1m1-ctx1-prop12-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop13")->getValue().c_str(), "r1-ctx1-prop13-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop14")->getValue().c_str(), "r1m1-ctx1-prop14-v") == 0);
	assert(strcmp(finalRegistry->get("ctx2", "prop21")->getValue().c_str(), "r1m1-ctx2-prop21-v") == 0);
	assert(strcmp(finalRegistry->get("ctx10", "prop12")->getValue().c_str(), "r1m1t2-ctx10-prop12-v") == 0);
	delete (finalRegistry);
	sessionProperties.clear();

	assert(sessPropTree.removeSessionProperty(1, "ctx1", "prop13"));
	assert(sessPropTree.removeSessionProperty(1, 1, "ctx2", "prop21"));
	assert(sessPropTree.removeSessionProperty(1, 1, 2, "ctx10", "prop12"));
	assert(sessPropTree.removeSessionProperty(1, 1, 2, "ctx10", "prop12")==false);
	finalRegistry = new AAAConnectionPropertyRegistry();
	sessPropTree.getProperties(AAAConnectionDescription(1, 1, 2, ""), sessionProperties);
	for (auto it = sessionProperties.begin(); it < sessionProperties.end(); it++) {
		assert(finalRegistry->add(it->getContext(), AAAConnectionProperty(it->getPropertyName(), it->getPropertyValue())));
	}
	assert(sessionProperties.size() == 4);
	assert(strcmp(finalRegistry->get("ctx1", "prop11")->getValue().c_str(), "r1m1-ctx1-prop11-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop12")->getValue().c_str(), "r1m1-ctx1-prop12-v") == 0);
	assert(strcmp(finalRegistry->get("ctx1", "prop14")->getValue().c_str(), "r1m1-ctx1-prop14-v") == 0);
	assert(strcmp(finalRegistry->get("ctx2", "prop21")->getValue().c_str(), "r1-ctx2-prop21-v") == 0);

}


int  testPropTree() {
	testBaseNode();
	testNode();
	testSessTree();
	return 0;
}

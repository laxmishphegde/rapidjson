/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ActivityNatEn                GET_A_Activity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityNatEn>  (GET_ENUM(p, A_Activity_NatEn)));
}
inline ActivityNatEn                GET_S_Activity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityNatEn>  (GET_ENUM(p, S_Activity_NatEn)));
}
inline ActivityStatusEn             GET_A_Activity_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityStatusEn>  (GET_ENUM(p, A_Activity_StatusEn)));
}
inline ActivityPriorityEn           GET_A_Activity_PriorityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityPriorityEn>  (GET_ENUM(p, A_Activity_PriorityEn)));
}
inline ActivitySourceEn             GET_A_Activity_SourceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivitySourceEn>  (GET_ENUM(p, A_Activity_SourceEn)));
}
inline ActivityIntractnReasonEn     GET_A_Activity_IntractnReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnReasonEn>  (GET_ENUM(p, A_Activity_IntractnReasonEn)));
}
inline ActivityIntractnNatEn        GET_A_Activity_IntractnNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnNatEn>  (GET_ENUM(p, A_Activity_IntractnNatEn)));
}
inline ActivityIntractnDirectionEn  GET_A_Activity_IntractnDirectionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnDirectionEn>  (GET_ENUM(p, A_Activity_IntractnDirectionEn)));
}
inline ActivityIntractnCustNatEn    GET_A_Activity_IntractnCustNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnCustNatEn>  (GET_ENUM(p, A_Activity_IntractnCustNatEn)));
}

inline ActivityNatEn                _GET_A_Activity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityNatEn>  (_GET_ENUM(p, A_Activity_NatEn)));
}
inline ActivityNatEn                _GET_S_Activity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityNatEn>  (_GET_ENUM(p, S_Activity_NatEn)));
}
inline ActivityStatusEn             _GET_A_Activity_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityStatusEn>  (_GET_ENUM(p, A_Activity_StatusEn)));
}
inline ActivityPriorityEn           _GET_A_Activity_PriorityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityPriorityEn>  (_GET_ENUM(p, A_Activity_PriorityEn)));
}
inline ActivitySourceEn             _GET_A_Activity_SourceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivitySourceEn>  (_GET_ENUM(p, A_Activity_SourceEn)));
}
inline ActivityIntractnReasonEn     _GET_A_Activity_IntractnReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnReasonEn>  (_GET_ENUM(p, A_Activity_IntractnReasonEn)));
}
inline ActivityIntractnNatEn        _GET_A_Activity_IntractnNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnNatEn>  (_GET_ENUM(p, A_Activity_IntractnNatEn)));
}
inline ActivityIntractnDirectionEn  _GET_A_Activity_IntractnDirectionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnDirectionEn>  (_GET_ENUM(p, A_Activity_IntractnDirectionEn)));
}
inline ActivityIntractnCustNatEn    _GET_A_Activity_IntractnCustNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ActivityIntractnCustNatEn>  (_GET_ENUM(p, A_Activity_IntractnCustNatEn)));
}

inline void                         SET_A_Activity_NatEn(DBA_DYNFLD_STP p, ActivityNatEn enumValue)
{
    SET_ENUM(p, A_Activity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Activity_NatEn(DBA_DYNFLD_STP p, ActivityNatEn enumValue)
{
    SET_ENUM(p, S_Activity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_StatusEn(DBA_DYNFLD_STP p, ActivityStatusEn enumValue)
{
    SET_ENUM(p, A_Activity_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_PriorityEn(DBA_DYNFLD_STP p, ActivityPriorityEn enumValue)
{
    SET_ENUM(p, A_Activity_PriorityEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_SourceEn(DBA_DYNFLD_STP p, ActivitySourceEn enumValue)
{
    SET_ENUM(p, A_Activity_SourceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_IntractnReasonEn(DBA_DYNFLD_STP p, ActivityIntractnReasonEn enumValue)
{
    SET_ENUM(p, A_Activity_IntractnReasonEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_IntractnNatEn(DBA_DYNFLD_STP p, ActivityIntractnNatEn enumValue)
{
    SET_ENUM(p, A_Activity_IntractnNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_IntractnDirectionEn(DBA_DYNFLD_STP p, ActivityIntractnDirectionEn enumValue)
{
    SET_ENUM(p, A_Activity_IntractnDirectionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Activity_IntractnCustNatEn(DBA_DYNFLD_STP p, ActivityIntractnCustNatEn enumValue)
{
    SET_ENUM(p, A_Activity_IntractnCustNatEn, static_cast<unsigned char>(enumValue));
}


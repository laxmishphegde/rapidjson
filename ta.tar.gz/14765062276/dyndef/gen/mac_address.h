/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline AddrAddressFmtEn             GET_A_Addr_AddressFmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AddrAddressFmtEn>  (GET_ENUM(p, A_Addr_AddressFmtEn)));
}

inline AddrAddressFmtEn             _GET_A_Addr_AddressFmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AddrAddressFmtEn>  (_GET_ENUM(p, A_Addr_AddressFmtEn)));
}

inline void                         SET_A_Addr_AddressFmtEn(DBA_DYNFLD_STP p, AddrAddressFmtEn enumValue)
{
    SET_ENUM(p, A_Addr_AddressFmtEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline AlertDefActiveEn             GET_A_AlertDef_ActiveEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefActiveEn>  (GET_ENUM(p, A_AlertDef_ActiveEn)));
}
inline AlertDefNotifPatternEn       GET_A_AlertDef_NotifPatternEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefNotifPatternEn>  (GET_ENUM(p, A_AlertDef_NotifPatternEn)));
}
inline AlertDefSeverityEn           GET_A_AlertDef_SeverityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefSeverityEn>  (GET_ENUM(p, A_AlertDef_SeverityEn)));
}
inline AlertDefVisibilityEn         GET_A_AlertDef_VisibilityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefVisibilityEn>  (GET_ENUM(p, A_AlertDef_VisibilityEn)));
}

inline AlertDefActiveEn             _GET_A_AlertDef_ActiveEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefActiveEn>  (_GET_ENUM(p, A_AlertDef_ActiveEn)));
}
inline AlertDefNotifPatternEn       _GET_A_AlertDef_NotifPatternEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefNotifPatternEn>  (_GET_ENUM(p, A_AlertDef_NotifPatternEn)));
}
inline AlertDefSeverityEn           _GET_A_AlertDef_SeverityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefSeverityEn>  (_GET_ENUM(p, A_AlertDef_SeverityEn)));
}
inline AlertDefVisibilityEn         _GET_A_AlertDef_VisibilityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<AlertDefVisibilityEn>  (_GET_ENUM(p, A_AlertDef_VisibilityEn)));
}

inline void                         SET_A_AlertDef_ActiveEn(DBA_DYNFLD_STP p, AlertDefActiveEn enumValue)
{
    SET_ENUM(p, A_AlertDef_ActiveEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AlertDef_NotifPatternEn(DBA_DYNFLD_STP p, AlertDefNotifPatternEn enumValue)
{
    SET_ENUM(p, A_AlertDef_NotifPatternEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AlertDef_SeverityEn(DBA_DYNFLD_STP p, AlertDefSeverityEn enumValue)
{
    SET_ENUM(p, A_AlertDef_SeverityEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AlertDef_VisibilityEn(DBA_DYNFLD_STP p, AlertDefVisibilityEn enumValue)
{
    SET_ENUM(p, A_AlertDef_VisibilityEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfFusionRuleEn              GET_A_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (GET_ENUM(p, A_AccountingRuleCompo_FusionRuleEn)));
}
inline PtfFusionRuleEn              GET_S_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (GET_ENUM(p, S_AccountingRuleCompo_FusionRuleEn)));
}
inline PtfTaxLotMngtEn              GET_A_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (GET_ENUM(p, A_AccountingRuleCompo_TaxLotMngtEn)));
}
inline PtfTaxLotMngtEn              GET_S_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (GET_ENUM(p, S_AccountingRuleCompo_TaxLotMngtEn)));
}

inline PtfFusionRuleEn              _GET_A_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (_GET_ENUM(p, A_AccountingRuleCompo_FusionRuleEn)));
}
inline PtfFusionRuleEn              _GET_S_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (_GET_ENUM(p, S_AccountingRuleCompo_FusionRuleEn)));
}
inline PtfTaxLotMngtEn              _GET_A_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (_GET_ENUM(p, A_AccountingRuleCompo_TaxLotMngtEn)));
}
inline PtfTaxLotMngtEn              _GET_S_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (_GET_ENUM(p, S_AccountingRuleCompo_TaxLotMngtEn)));
}

inline void                         SET_A_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p, PtfFusionRuleEn enumValue)
{
    SET_ENUM(p, A_AccountingRuleCompo_FusionRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_AccountingRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p, PtfFusionRuleEn enumValue)
{
    SET_ENUM(p, S_AccountingRuleCompo_FusionRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p, PtfTaxLotMngtEn enumValue)
{
    SET_ENUM(p, A_AccountingRuleCompo_TaxLotMngtEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_AccountingRuleCompo_TaxLotMngtEn(DBA_DYNFLD_STP p, PtfTaxLotMngtEn enumValue)
{
    SET_ENUM(p, S_AccountingRuleCompo_TaxLotMngtEn, static_cast<unsigned char>(enumValue));
}


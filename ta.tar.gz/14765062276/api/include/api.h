/* ***********************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
** ***********************************************************************/

#ifndef API_H_
#define API_H_

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
* memory allocation function prototype.
*
* @param ctx the memory management context as maintained in the MEMmanager object.
* @param memsize the size of memory to allocate.
*
* @return the pointer to the new allocated memory zone (as a void*).
*/
typedef void* (*MEM_alloc_FPtr)(size_t memsize) ;

/**
* memory reallocation function prototype.
*
* @param ctx the memory management context as maintained in the MEMmanager object
* @param addr the address of the memory zone to reallocated
* @param memsize the size of memory to reallocate
*
* @return the pointer to the new allocated memory zone (as a void*)
*/
typedef void* (*MEM_realloc_FPtr)(void* addr,  size_t memsize) ;
/**
* memory free function prototype.
* 
* @param ctx the memory management context as maintained in the MEMmanager object
* @param addr the address of the memory zone to free 
*/
typedef void (*MEM_free_FPtr)(void* addr);
/**
* memory manager context relase function prototype. (automatically called when the memory manager is released)
* 
* @param ctx the memory manager context to release.
*/
typedef void (*MEM_release_FPtr)();
/**
*	MEMManager object definition. 
*   A memory manager contains the following information:
*	<ul>
*		<li><b>allocFPtr</b> pointer on memory allocation function (as defined by allocFunc) </li>
*		<li><b>reallocFPtr</b> pointer on memory reallocation function (as defined by reallocFunc) </li>
*		<li><b>freeFPtr</b> pointer on memory free function (as defined by freeFunc) </li>
*		<li><b>ctxFPtr</b> pointer on the memory management context </li>
*	</ul>
*/
typedef struct  {
/**
*pointer on memory allocation function.
* @see #MEM_alloc_FPtr
*/
  MEM_alloc_FPtr        allocFPtr       ;
/**
*pointer on memory reallocation function.
* @see #MEM_realloc_FPtr
*/
  MEM_realloc_FPtr      reallocFPtr     ;
/**
* pointer on memory free function.
* @see #MEM_free_FPtr
*/
  MEM_free_FPtr         freeFPtr        ;
} MEM_manager_ST ;
typedef MEM_manager_ST* MEM_manager_STP ;

/**
* create a memoray management object.
*
* The object is allocated by the use of the allocation function. 
* The object must be delete by the use of the dedicated deletion  function. @see #MEM_managerDelete.
* @param allocFptr pointer to the memory allocation function
* @param reallocFPtr pointer to the memory reallocation function
* @param freePtr pointer to the memomry free function
* @return the memory management object
*/

extern MEM_manager_STP MEM_managerCreate (MEM_alloc_FPtr allocFPtr ,MEM_realloc_FPtr reallocFPtr , MEM_free_FPtr freePtr)  ;
/*
* Delete a memory management object
*
* The object is deleted by the use of the memory function and the context released by the use of the context release function. (called whenever context is null)
* 
* @param memmgr the object to delete.
*/
extern void  MEM_managerDelete (MEM_manager_STP memmgr)  ;

/**
* Allocate some memory.
*
* @param memmgr the memory manager
* @param memsize the memory size to reallocate
*/
extern void* MEM_alloc(MEM_manager_STP memmgr, size_t memsize) ;
/**
*
*
*/
extern void* MEM_realloc(MEM_manager_STP memmgr, void *addr, size_t memsize) ;
/**
*
*
*/
extern void  MEM_free(MEM_manager_STP memmgr, void *addr) ;
/**
*
*
*/
extern char* MEM_strdup(MEM_manager_STP memmgr, char* str);
/**
*
*
*/
extern MEM_manager_STP MEM_getDefaultManager() ;

/*
* API memory magement declaration macro
* This must be used in the main include of the api include and declare the following functions.
**	MEMmanagerPtr APIgetMEMmanager()
*   MEMmanagerPtr APIinitManager() 
*   void* APIallocate(size_t memsize) 
*   void* APIreallocate(void* ptr,  size_t memsize)
*   void" APIfree(void* ptr)
*	char* APIstrdup(char*ptr)
* All the functions (except APIgetMEMmanager and APIinitManager that have to be coded manually)  are automatically implemented by the use of the IMPL_MEMAPI macro.
* @param API the api acronym
*/


#define DECLARE_MEMAPI(API) \
	extern MEM_manager_STP API##_getMEMmanager() ; \
	extern MEM_manager_STP API##_initMEMmanager() ; \
	extern void* API##_allocate(size_t memsize) ;\
	extern void* API##_reallocate(void* ptr,  size_t memsize) ;\
	extern void API##_free(void* ptr);\
	extern char* API##_strdup(char* str);
	
/* API memory allocation function definition function */
#define IMPL_MEMAPI_ALLOC(API)		void* API##_allocate(size_t memsize)				{ return MEM_alloc(API##_getMEMmanager(),memsize);		}
/* API memory reallocation function definition function */
#define IMPL_MEMAPI_REALLOC(API)	void* API##_reallocate(void* addr, size_t memsize)	{ return MEM_realloc(API##_getMEMmanager(),addr, memsize);}
/* API memory free function definition function */
#define IMPL_MEMAPI_FREE(API)		void API##_free(void* addr)							{MEM_free(API##_getMEMmanager(),addr);			}
/* API character duplication function */
#define IMPL_MEMAPI_STDRUP(API)		char* API##_strdup(char* str)						{ return MEM_strdup(API##_getMEMmanager(),str);			}



/*
* API memory magement declaration macro
* This must be used in the main include of the api include and implements the following functions.
*   void* APIallocate(size_t memsize) 
*   void* APIreallocate(void* ptr,  size_t memsize)
*   void" APIfree(void* ptr)
*	char* APIstrdup(char*ptr)
* All the functions (except APIgetMEMmanager and APIinitManager that have to be coded manually)  are automatically implemented by the use of the IMPL_MEMAPI macro.
* @param API the api acronym
*/
#define IMPL_MEMAPI(API) IMPL_MEMAPI_ALLOC(API) IMPL_MEMAPI_REALLOC(API) IMPL_MEMAPI_FREE(API)  IMPL_MEMAPI_STDRUP(API);
#ifdef __cplusplus
}
#endif
#endif

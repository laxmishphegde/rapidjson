/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include "api.h"
#include "string.h"
#include "stdlib.h"

extern void * SYS_AixDeadLockMallocWorkAround(size_t);

/*
 *   default memory manager
 */ 
static MEM_manager_STP defaultMEMmanager;

void* MEM_alloc(MEM_manager_STP memmgr, size_t memsize)
{
    void* res = nullptr ;
    if (memmgr == nullptr)
    {
        res = (*(MEM_getDefaultManager()->allocFPtr))(memsize) ;
    }
    else
    {
        res = (*(memmgr->allocFPtr))(memsize) ;
    }

    return res ;
}

 void* MEM_realloc(MEM_manager_STP memmgr, void *addr, size_t memsize)
{
    void* res = nullptr ;

    if (memmgr == nullptr)
    {
        res = (*(MEM_getDefaultManager()->reallocFPtr))(addr, memsize) ;
    }
    else
    {
        res = (*(memmgr->reallocFPtr))(addr,memsize) ;
    }

    return res ;
}


 void MEM_free(MEM_manager_STP memmgr, void *addr) 
{
    if (memmgr == nullptr)
    {
        (*(MEM_getDefaultManager()->freeFPtr))(addr) ;
    }
    else  
    {
        (*(memmgr->freeFPtr))(addr) ;
    }
}


 char* MEM_strdup(MEM_manager_STP memmgr, char* str)
{
    char* newStr =  (char*) MEM_alloc(memmgr, (strlen(str)+1)*sizeof (char)) ;
    if (nullptr != newStr)
    {
        strcpy(newStr,str) ;
    }

    return newStr ;
}


/************************************************************************
*   Function             : MEM_getDefaultManager()
*
*   Description          : Create a default memory manager
*                               default allocation function is malloc.
*                               default realloc function is realloc.
*                               default free funnction is free.
*
*                           The default memory manager is created only once.
*
*   Arguments            : None
*
*   Return               : None
*
*   Creation Date        : 
*
*   Last Modification    : PMSTA-32006 - 290618 - PMO : AIX Deadlock in fin server around _global_lock_common
*
*************************************************************************/
MEM_manager_STP MEM_getDefaultManager()
{
    if (defaultMEMmanager == NULL)
    {
#ifdef AIX
        defaultMEMmanager =  MEM_managerCreate(SYS_AixDeadLockMallocWorkAround, realloc, free);
#else
        defaultMEMmanager =  MEM_managerCreate(malloc, realloc, free);
#endif
    }

    return defaultMEMmanager ;
}


MEM_manager_STP MEM_managerCreate(MEM_alloc_FPtr allocFuncPtr ,MEM_realloc_FPtr reallocFuncPtr , MEM_free_FPtr freeFuncPtr)   
{
    MEM_manager_STP res  = (MEM_manager_STP)((*allocFuncPtr)(sizeof(MEM_manager_ST) ));
    res->allocFPtr =allocFuncPtr;
    res->reallocFPtr=reallocFuncPtr;
    res->freeFPtr=freeFuncPtr ;

    return res ;
}

void MEM_managerDelete (MEM_manager_STP memmgr)
{
    (*(memmgr->freeFPtr))(memmgr ) ;
}


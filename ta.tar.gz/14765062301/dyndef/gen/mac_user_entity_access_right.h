/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline UserEntityAccessRightAccessRightEn GET_A_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightAccessRightEn>  (GET_ENUM(p, A_UserEntityAccessRight_AccessRightEn)));
}
inline UserEntityAccessRightAccessRightEn GET_S_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightAccessRightEn>  (GET_ENUM(p, S_UserEntityAccessRight_AccessRightEn)));
}
inline UserEntityAccessRightOverrideEn GET_A_UserEntityAccessRight_OverrideEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightOverrideEn>  (GET_ENUM(p, A_UserEntityAccessRight_OverrideEn)));
}

inline UserEntityAccessRightAccessRightEn _GET_A_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightAccessRightEn>  (_GET_ENUM(p, A_UserEntityAccessRight_AccessRightEn)));
}
inline UserEntityAccessRightAccessRightEn _GET_S_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightAccessRightEn>  (_GET_ENUM(p, S_UserEntityAccessRight_AccessRightEn)));
}
inline UserEntityAccessRightOverrideEn _GET_A_UserEntityAccessRight_OverrideEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<UserEntityAccessRightOverrideEn>  (_GET_ENUM(p, A_UserEntityAccessRight_OverrideEn)));
}

inline void                         SET_A_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p, UserEntityAccessRightAccessRightEn enumValue)
{
    SET_ENUM(p, A_UserEntityAccessRight_AccessRightEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_UserEntityAccessRight_AccessRightEn(DBA_DYNFLD_STP p, UserEntityAccessRightAccessRightEn enumValue)
{
    SET_ENUM(p, S_UserEntityAccessRight_AccessRightEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_UserEntityAccessRight_OverrideEn(DBA_DYNFLD_STP p, UserEntityAccessRightOverrideEn enumValue)
{
    SET_ENUM(p, A_UserEntityAccessRight_OverrideEn, static_cast<unsigned char>(enumValue));
}


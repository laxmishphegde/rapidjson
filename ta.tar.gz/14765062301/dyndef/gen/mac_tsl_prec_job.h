/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TslPrecJobNatEn              GET_A_TslPrecJob_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobNatEn>  (GET_ENUM(p, A_TslPrecJob_NatEn)));
}
inline TslPrecJobNatEn              GET_S_TslPrecJob_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobNatEn>  (GET_ENUM(p, S_TslPrecJob_NatEn)));
}
inline TslPrecJobPackagingNatEn     GET_A_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobPackagingNatEn>  (GET_ENUM(p, A_TslPrecJob_PackagingNatEn)));
}
inline TslPrecJobPackagingNatEn     GET_S_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobPackagingNatEn>  (GET_ENUM(p, S_TslPrecJob_PackagingNatEn)));
}

inline TslPrecJobNatEn              _GET_A_TslPrecJob_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobNatEn>  (_GET_ENUM(p, A_TslPrecJob_NatEn)));
}
inline TslPrecJobNatEn              _GET_S_TslPrecJob_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobNatEn>  (_GET_ENUM(p, S_TslPrecJob_NatEn)));
}
inline TslPrecJobPackagingNatEn     _GET_A_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobPackagingNatEn>  (_GET_ENUM(p, A_TslPrecJob_PackagingNatEn)));
}
inline TslPrecJobPackagingNatEn     _GET_S_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TslPrecJobPackagingNatEn>  (_GET_ENUM(p, S_TslPrecJob_PackagingNatEn)));
}

inline void                         SET_A_TslPrecJob_NatEn(DBA_DYNFLD_STP p, TslPrecJobNatEn enumValue)
{
    SET_ENUM(p, A_TslPrecJob_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TslPrecJob_NatEn(DBA_DYNFLD_STP p, TslPrecJobNatEn enumValue)
{
    SET_ENUM(p, S_TslPrecJob_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p, TslPrecJobPackagingNatEn enumValue)
{
    SET_ENUM(p, A_TslPrecJob_PackagingNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TslPrecJob_PackagingNatEn(DBA_DYNFLD_STP p, TslPrecJobPackagingNatEn enumValue)
{
    SET_ENUM(p, S_TslPrecJob_PackagingNatEn, static_cast<unsigned char>(enumValue));
}


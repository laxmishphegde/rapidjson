/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdEntityFeatureFeatureEn     GET_A_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (GET_ENUM(p, A_XdEntityFeature_FeatureEn)));
}
inline XdEntityFeatureFeatureEn     GET_S_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (GET_ENUM(p, S_XdEntityFeature_FeatureEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntityFeature_AuthEn)));
}
inline XdEntityFeatureAuthEn        GET_S_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, S_XdEntityFeature_AuthEn)));
}
inline XdEntityFeatureGenRuleEn     GET_A_XdEntityFeature_GenRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureGenRuleEn>  (GET_ENUM(p, A_XdEntityFeature_GenRuleEn)));
}
inline XdEntityXdActionEn           GET_A_XdEntityFeature_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdEntityFeature_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdEntityFeature_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdEntityFeature_XdStatusEn)));
}

inline XdEntityFeatureFeatureEn     _GET_A_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (_GET_ENUM(p, A_XdEntityFeature_FeatureEn)));
}
inline XdEntityFeatureFeatureEn     _GET_S_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (_GET_ENUM(p, S_XdEntityFeature_FeatureEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntityFeature_AuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_S_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, S_XdEntityFeature_AuthEn)));
}
inline XdEntityFeatureGenRuleEn     _GET_A_XdEntityFeature_GenRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureGenRuleEn>  (_GET_ENUM(p, A_XdEntityFeature_GenRuleEn)));
}
inline XdEntityXdActionEn           _GET_A_XdEntityFeature_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdEntityFeature_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdEntityFeature_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdEntityFeature_XdStatusEn)));
}

inline void                         SET_A_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p, XdEntityFeatureFeatureEn enumValue)
{
    SET_ENUM(p, A_XdEntityFeature_FeatureEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdEntityFeature_FeatureEn(DBA_DYNFLD_STP p, XdEntityFeatureFeatureEn enumValue)
{
    SET_ENUM(p, S_XdEntityFeature_FeatureEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntityFeature_AuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdEntityFeature_AuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, S_XdEntityFeature_AuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntityFeature_GenRuleEn(DBA_DYNFLD_STP p, XdEntityFeatureGenRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntityFeature_GenRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntityFeature_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdEntityFeature_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntityFeature_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdEntityFeature_XdStatusEn, static_cast<unsigned char>(enumValue));
}


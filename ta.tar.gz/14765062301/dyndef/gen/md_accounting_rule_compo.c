/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



OBJECT_ENUM AccountingRuleCompo   ; /* 851  : accounting_rule_compo         */

DBA_DYNST_ENUM A_AccountingRuleCompo ;
DBA_DYNST_ENUM S_AccountingRuleCompo ;

FIELD_IDX_T		A_AccountingRuleCompo_Id                		=    0;	/* IdType              */
FIELD_IDX_T		A_AccountingRuleCompo_AccountingRuleHistoId		=    1;	/* IdType              */
FIELD_IDX_T		A_AccountingRuleCompo_InstrListId       		=    2;	/* IdType              */
FIELD_IDX_T		A_AccountingRuleCompo_FusionRuleEn      		=    3;	/* EnumType            */
FIELD_IDX_T		A_AccountingRuleCompo_TaxLotMngtEn      		=    4;	/* EnumType            */
FIELD_IDX_T		A_AccountingRuleCompo_TaxLotOpRuleId    		=    5;	/* IdType              */

static DBA_CFIELDDEF_ST SV_GenFieldDef_A_AccountingRuleCompo[] = {
	{"id"                          ,TRUE  ,&A_AccountingRuleCompo_Id                ,IdType              ,TRUE  },
	{"accounting_rule_histo_id"    ,TRUE  ,&A_AccountingRuleCompo_AccountingRuleHistoId,IdType              ,TRUE  },
	{"instr_list_id"               ,TRUE  ,&A_AccountingRuleCompo_InstrListId       ,IdType              ,TRUE  },
	{"fusion_rule_e"               ,TRUE  ,&A_AccountingRuleCompo_FusionRuleEn      ,EnumType            ,TRUE  },
	{"tax_lot_mngt_e"              ,TRUE  ,&A_AccountingRuleCompo_TaxLotMngtEn      ,EnumType            ,TRUE  },
	{"tax_lot_op_rule_id"          ,TRUE  ,&A_AccountingRuleCompo_TaxLotOpRuleId    ,IdType              ,TRUE  },
	{""                            ,FALSE ,NULL                                     ,NullDataType        ,FALSE }
	};

FIELD_IDX_T		S_AccountingRuleCompo_Id                		=    0;	/* IdType              */
FIELD_IDX_T		S_AccountingRuleCompo_AccountingRuleHistoId		=    1;	/* IdType              */
FIELD_IDX_T		S_AccountingRuleCompo_InstrListId       		=    2;	/* IdType              */
FIELD_IDX_T		S_AccountingRuleCompo_FusionRuleEn      		=    3;	/* EnumType            */
FIELD_IDX_T		S_AccountingRuleCompo_TaxLotMngtEn      		=    4;	/* EnumType            */
FIELD_IDX_T		S_AccountingRuleCompo_TaxLotOpRuleId    		=    5;	/* IdType              */
FIELD_IDX_T		S_AccountingRuleCompo_InstrListCd       		=    6;	/* CodeType            */

static DBA_CFIELDDEF_ST SV_GenFieldDef_S_AccountingRuleCompo[] = {
	{"id"                          ,TRUE  ,&S_AccountingRuleCompo_Id                ,IdType              ,TRUE  },
	{"accounting_rule_histo_id"    ,TRUE  ,&S_AccountingRuleCompo_AccountingRuleHistoId,IdType              ,TRUE  },
	{"instr_list_id"               ,TRUE  ,&S_AccountingRuleCompo_InstrListId       ,IdType              ,TRUE  },
	{"fusion_rule_e"               ,TRUE  ,&S_AccountingRuleCompo_FusionRuleEn      ,EnumType            ,TRUE  },
	{"tax_lot_mngt_e"              ,TRUE  ,&S_AccountingRuleCompo_TaxLotMngtEn      ,EnumType            ,TRUE  },
	{"tax_lot_op_rule_id"          ,TRUE  ,&S_AccountingRuleCompo_TaxLotOpRuleId    ,IdType              ,TRUE  },
	{"instr_list_code"             ,TRUE  ,&S_AccountingRuleCompo_InstrListCd       ,CodeType            ,TRUE  },
	{""                            ,FALSE ,NULL                                     ,NullDataType        ,FALSE }
	};


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ValRuleEltEvalRuleEn         GET_A_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltEvalRuleEn>  (GET_ENUM(p, A_ValRuleElt_EvalRuleEn)));
}
inline ValRuleEltEvalRuleEn         GET_S_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltEvalRuleEn>  (GET_ENUM(p, S_ValRuleElt_EvalRuleEn)));
}
inline ValRuleEltMaxConstraintEn    GET_A_ValRuleElt_MaxConstraintEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltMaxConstraintEn>  (GET_ENUM(p, A_ValRuleElt_MaxConstraintEn)));
}
inline ValRuleEltPriceMktRuleEn     GET_A_ValRuleElt_PriceMktRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceMktRuleEn>  (GET_ENUM(p, A_ValRuleElt_PriceMktRuleEn)));
}
inline ValRuleEltPriceProviderRuleEn GET_A_ValRuleElt_PriceProviderRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceProviderRuleEn>  (GET_ENUM(p, A_ValRuleElt_PriceProviderRuleEn)));
}
inline ValRuleEltPriceCurrRuleEn    GET_A_ValRuleElt_PriceCurrRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceCurrRuleEn>  (GET_ENUM(p, A_ValRuleElt_PriceCurrRuleEn)));
}
inline ValRuleEltRuleNatEn          GET_A_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltRuleNatEn>  (GET_ENUM(p, A_ValRuleElt_RuleNatEn)));
}
inline ValRuleEltRuleNatEn          GET_S_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltRuleNatEn>  (GET_ENUM(p, S_ValRuleElt_RuleNatEn)));
}
inline ValRuleEltBusEntityRuleEn    GET_A_ValRuleElt_BusEntityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltBusEntityRuleEn>  (GET_ENUM(p, A_ValRuleElt_BusEntityRuleEn)));
}

inline ValRuleEltEvalRuleEn         _GET_A_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltEvalRuleEn>  (_GET_ENUM(p, A_ValRuleElt_EvalRuleEn)));
}
inline ValRuleEltEvalRuleEn         _GET_S_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltEvalRuleEn>  (_GET_ENUM(p, S_ValRuleElt_EvalRuleEn)));
}
inline ValRuleEltMaxConstraintEn    _GET_A_ValRuleElt_MaxConstraintEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltMaxConstraintEn>  (_GET_ENUM(p, A_ValRuleElt_MaxConstraintEn)));
}
inline ValRuleEltPriceMktRuleEn     _GET_A_ValRuleElt_PriceMktRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceMktRuleEn>  (_GET_ENUM(p, A_ValRuleElt_PriceMktRuleEn)));
}
inline ValRuleEltPriceProviderRuleEn _GET_A_ValRuleElt_PriceProviderRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceProviderRuleEn>  (_GET_ENUM(p, A_ValRuleElt_PriceProviderRuleEn)));
}
inline ValRuleEltPriceCurrRuleEn    _GET_A_ValRuleElt_PriceCurrRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltPriceCurrRuleEn>  (_GET_ENUM(p, A_ValRuleElt_PriceCurrRuleEn)));
}
inline ValRuleEltRuleNatEn          _GET_A_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltRuleNatEn>  (_GET_ENUM(p, A_ValRuleElt_RuleNatEn)));
}
inline ValRuleEltRuleNatEn          _GET_S_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltRuleNatEn>  (_GET_ENUM(p, S_ValRuleElt_RuleNatEn)));
}
inline ValRuleEltBusEntityRuleEn    _GET_A_ValRuleElt_BusEntityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleEltBusEntityRuleEn>  (_GET_ENUM(p, A_ValRuleElt_BusEntityRuleEn)));
}

inline void                         SET_A_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p, ValRuleEltEvalRuleEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_EvalRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ValRuleElt_EvalRuleEn(DBA_DYNFLD_STP p, ValRuleEltEvalRuleEn enumValue)
{
    SET_ENUM(p, S_ValRuleElt_EvalRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_MaxConstraintEn(DBA_DYNFLD_STP p, ValRuleEltMaxConstraintEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_MaxConstraintEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_PriceMktRuleEn(DBA_DYNFLD_STP p, ValRuleEltPriceMktRuleEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_PriceMktRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_PriceProviderRuleEn(DBA_DYNFLD_STP p, ValRuleEltPriceProviderRuleEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_PriceProviderRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_PriceCurrRuleEn(DBA_DYNFLD_STP p, ValRuleEltPriceCurrRuleEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_PriceCurrRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p, ValRuleEltRuleNatEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_RuleNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ValRuleElt_RuleNatEn(DBA_DYNFLD_STP p, ValRuleEltRuleNatEn enumValue)
{
    SET_ENUM(p, S_ValRuleElt_RuleNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ValRuleElt_BusEntityRuleEn(DBA_DYNFLD_STP p, ValRuleEltBusEntityRuleEn enumValue)
{
    SET_ENUM(p, A_ValRuleElt_BusEntityRuleEn, static_cast<unsigned char>(enumValue));
}


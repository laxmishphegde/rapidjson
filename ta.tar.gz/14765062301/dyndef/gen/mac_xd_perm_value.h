/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictPermValPermValNatEn      GET_A_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (GET_ENUM(p, A_XdPermVal_PermValNatEn)));
}
inline DictPermValPermValNatEn      GET_S_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (GET_ENUM(p, S_XdPermVal_PermValNatEn)));
}
inline DictPermValPermValRuleEn     GET_A_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (GET_ENUM(p, A_XdPermVal_PermValRuleEn)));
}
inline DictPermValPermValRuleEn     GET_S_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (GET_ENUM(p, S_XdPermVal_PermValRuleEn)));
}
inline XdEntityXdActionEn           GET_A_XdPermVal_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdPermVal_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdPermVal_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdPermVal_XdStatusEn)));
}
inline DictPermValDbRuleEn          GET_A_XdPermVal_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValDbRuleEn>  (GET_ENUM(p, A_XdPermVal_DbRuleEn)));
}

inline DictPermValPermValNatEn      _GET_A_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (_GET_ENUM(p, A_XdPermVal_PermValNatEn)));
}
inline DictPermValPermValNatEn      _GET_S_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValNatEn>  (_GET_ENUM(p, S_XdPermVal_PermValNatEn)));
}
inline DictPermValPermValRuleEn     _GET_A_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (_GET_ENUM(p, A_XdPermVal_PermValRuleEn)));
}
inline DictPermValPermValRuleEn     _GET_S_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValPermValRuleEn>  (_GET_ENUM(p, S_XdPermVal_PermValRuleEn)));
}
inline XdEntityXdActionEn           _GET_A_XdPermVal_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdPermVal_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdPermVal_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdPermVal_XdStatusEn)));
}
inline DictPermValDbRuleEn          _GET_A_XdPermVal_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictPermValDbRuleEn>  (_GET_ENUM(p, A_XdPermVal_DbRuleEn)));
}

inline void                         SET_A_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p, DictPermValPermValNatEn enumValue)
{
    SET_ENUM(p, A_XdPermVal_PermValNatEn, enumValue);
}
inline void                         SET_S_XdPermVal_PermValNatEn(DBA_DYNFLD_STP p, DictPermValPermValNatEn enumValue)
{
    SET_ENUM(p, S_XdPermVal_PermValNatEn, enumValue);
}
inline void                         SET_A_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p, DictPermValPermValRuleEn enumValue)
{
    SET_ENUM(p, A_XdPermVal_PermValRuleEn, enumValue);
}
inline void                         SET_S_XdPermVal_PermValRuleEn(DBA_DYNFLD_STP p, DictPermValPermValRuleEn enumValue)
{
    SET_ENUM(p, S_XdPermVal_PermValRuleEn, enumValue);
}
inline void                         SET_A_XdPermVal_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdPermVal_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdPermVal_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdPermVal_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdPermVal_DbRuleEn(DBA_DYNFLD_STP p, DictPermValDbRuleEn enumValue)
{
    SET_ENUM(p, A_XdPermVal_DbRuleEn, enumValue);
}


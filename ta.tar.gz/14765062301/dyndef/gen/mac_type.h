/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrNatEn                   GET_A_Tp_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_Tp_InstrNatEn)));
}
inline InstrNatEn                   GET_S_Tp_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_Tp_InstrNatEn)));
}

inline InstrNatEn                   _GET_A_Tp_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_Tp_InstrNatEn)));
}
inline InstrNatEn                   _GET_S_Tp_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_Tp_InstrNatEn)));
}

inline void                         SET_A_Tp_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_Tp_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Tp_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_Tp_InstrNatEn, static_cast<unsigned char>(enumValue));
}


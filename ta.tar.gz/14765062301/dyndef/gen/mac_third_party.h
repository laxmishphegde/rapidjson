/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdHeartUploadEn           GET_A_Third_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdHeartUploadEn>  (GET_ENUM(p, A_Third_HeartUploadEn)));
}
inline ThirdStatusEn                GET_A_Third_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdStatusEn>  (GET_ENUM(p, A_Third_StatusEn)));
}
inline ThirdLegalEntityTypeEn       GET_A_Third_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, A_Third_LegalEntityTypeEn)));
}
inline ThirdLegalEntityStatusEn     GET_A_Third_LegalEntityStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityStatusEn>  (GET_ENUM(p, A_Third_LegalEntityStatusEn)));
}
inline InstrIslamicComplianceEn     GET_A_Third_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (GET_ENUM(p, A_Third_IslamicComplianceEn)));
}
inline ThirdRiskProfileEn           GET_A_Third_RiskProfileEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdRiskProfileEn>  (GET_ENUM(p, A_Third_RiskProfileEn)));
}
inline ThirdSettleDaysRuleEn        GET_A_Third_SettleDaysRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdSettleDaysRuleEn>  (GET_ENUM(p, A_Third_SettleDaysRuleEn)));
}

inline ThirdHeartUploadEn           _GET_A_Third_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdHeartUploadEn>  (_GET_ENUM(p, A_Third_HeartUploadEn)));
}
inline ThirdStatusEn                _GET_A_Third_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdStatusEn>  (_GET_ENUM(p, A_Third_StatusEn)));
}
inline ThirdLegalEntityTypeEn       _GET_A_Third_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, A_Third_LegalEntityTypeEn)));
}
inline ThirdLegalEntityStatusEn     _GET_A_Third_LegalEntityStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityStatusEn>  (_GET_ENUM(p, A_Third_LegalEntityStatusEn)));
}
inline InstrIslamicComplianceEn     _GET_A_Third_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (_GET_ENUM(p, A_Third_IslamicComplianceEn)));
}
inline ThirdRiskProfileEn           _GET_A_Third_RiskProfileEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdRiskProfileEn>  (_GET_ENUM(p, A_Third_RiskProfileEn)));
}
inline ThirdSettleDaysRuleEn        _GET_A_Third_SettleDaysRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdSettleDaysRuleEn>  (_GET_ENUM(p, A_Third_SettleDaysRuleEn)));
}

inline void                         SET_A_Third_HeartUploadEn(DBA_DYNFLD_STP p, ThirdHeartUploadEn enumValue)
{
    SET_ENUM(p, A_Third_HeartUploadEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_StatusEn(DBA_DYNFLD_STP p, ThirdStatusEn enumValue)
{
    SET_ENUM(p, A_Third_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_LegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, A_Third_LegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_LegalEntityStatusEn(DBA_DYNFLD_STP p, ThirdLegalEntityStatusEn enumValue)
{
    SET_ENUM(p, A_Third_LegalEntityStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_IslamicComplianceEn(DBA_DYNFLD_STP p, InstrIslamicComplianceEn enumValue)
{
    SET_ENUM(p, A_Third_IslamicComplianceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_RiskProfileEn(DBA_DYNFLD_STP p, ThirdRiskProfileEn enumValue)
{
    SET_ENUM(p, A_Third_RiskProfileEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Third_SettleDaysRuleEn(DBA_DYNFLD_STP p, ThirdSettleDaysRuleEn enumValue)
{
    SET_ENUM(p, A_Third_SettleDaysRuleEn, static_cast<unsigned char>(enumValue));
}


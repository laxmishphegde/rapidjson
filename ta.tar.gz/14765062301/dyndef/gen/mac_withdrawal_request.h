/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline WithdrawalRequestNatEn       GET_A_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestNatEn>  (GET_ENUM(p, A_WithdrawalRequest_NatEn)));
}
inline WithdrawalRequestNatEn       GET_S_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestNatEn>  (GET_ENUM(p, S_WithdrawalRequest_NatEn)));
}
inline WithdrawalRequestStatusEn    GET_A_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestStatusEn>  (GET_ENUM(p, A_WithdrawalRequest_StatusEn)));
}
inline WithdrawalRequestStatusEn    GET_S_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestStatusEn>  (GET_ENUM(p, S_WithdrawalRequest_StatusEn)));
}
inline WithdrawalRequestFailureReasonEn GET_A_WithdrawalRequest_FailureReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestFailureReasonEn>  (GET_ENUM(p, A_WithdrawalRequest_FailureReasonEn)));
}
inline WithdrawalRequestFullLiquidationBehaviorEn GET_A_WithdrawalRequest_FullLiquidationBehaviorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestFullLiquidationBehaviorEn>  (GET_ENUM(p, A_WithdrawalRequest_FullLiquidationBehaviorEn)));
}
inline WithdrawalRequestCashRealignMethodEn GET_A_WithdrawalRequest_CashRealignMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestCashRealignMethodEn>  (GET_ENUM(p, A_WithdrawalRequest_CashRealignMethodEn)));
}
inline WithdrawalRequestRealignEn   GET_A_WithdrawalRequest_RealignEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestRealignEn>  (GET_ENUM(p, A_WithdrawalRequest_RealignEn)));
}

inline WithdrawalRequestNatEn       _GET_A_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestNatEn>  (_GET_ENUM(p, A_WithdrawalRequest_NatEn)));
}
inline WithdrawalRequestNatEn       _GET_S_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestNatEn>  (_GET_ENUM(p, S_WithdrawalRequest_NatEn)));
}
inline WithdrawalRequestStatusEn    _GET_A_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestStatusEn>  (_GET_ENUM(p, A_WithdrawalRequest_StatusEn)));
}
inline WithdrawalRequestStatusEn    _GET_S_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestStatusEn>  (_GET_ENUM(p, S_WithdrawalRequest_StatusEn)));
}
inline WithdrawalRequestFailureReasonEn _GET_A_WithdrawalRequest_FailureReasonEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestFailureReasonEn>  (_GET_ENUM(p, A_WithdrawalRequest_FailureReasonEn)));
}
inline WithdrawalRequestFullLiquidationBehaviorEn _GET_A_WithdrawalRequest_FullLiquidationBehaviorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestFullLiquidationBehaviorEn>  (_GET_ENUM(p, A_WithdrawalRequest_FullLiquidationBehaviorEn)));
}
inline WithdrawalRequestCashRealignMethodEn _GET_A_WithdrawalRequest_CashRealignMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestCashRealignMethodEn>  (_GET_ENUM(p, A_WithdrawalRequest_CashRealignMethodEn)));
}
inline WithdrawalRequestRealignEn   _GET_A_WithdrawalRequest_RealignEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WithdrawalRequestRealignEn>  (_GET_ENUM(p, A_WithdrawalRequest_RealignEn)));
}

inline void                         SET_A_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p, WithdrawalRequestNatEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_WithdrawalRequest_NatEn(DBA_DYNFLD_STP p, WithdrawalRequestNatEn enumValue)
{
    SET_ENUM(p, S_WithdrawalRequest_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p, WithdrawalRequestStatusEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_WithdrawalRequest_StatusEn(DBA_DYNFLD_STP p, WithdrawalRequestStatusEn enumValue)
{
    SET_ENUM(p, S_WithdrawalRequest_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_WithdrawalRequest_FailureReasonEn(DBA_DYNFLD_STP p, WithdrawalRequestFailureReasonEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_FailureReasonEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_WithdrawalRequest_FullLiquidationBehaviorEn(DBA_DYNFLD_STP p, WithdrawalRequestFullLiquidationBehaviorEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_FullLiquidationBehaviorEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_WithdrawalRequest_CashRealignMethodEn(DBA_DYNFLD_STP p, WithdrawalRequestCashRealignMethodEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_CashRealignMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_WithdrawalRequest_RealignEn(DBA_DYNFLD_STP p, WithdrawalRequestRealignEn enumValue)
{
    SET_ENUM(p, A_WithdrawalRequest_RealignEn, static_cast<unsigned char>(enumValue));
}


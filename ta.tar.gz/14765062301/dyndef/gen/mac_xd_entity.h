/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictEntityNatEn              GET_A_XdEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, A_XdEntity_NatEn)));
}
inline DictEntityNatEn              GET_S_XdEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, S_XdEntity_NatEn)));
}
inline DictEntityInterfaceEn        GET_A_XdEntity_InterfaceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityInterfaceEn>  (GET_ENUM(p, A_XdEntity_InterfaceEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_AuditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_AuditEn)));
}
inline XdEntityLockSchemeEn         GET_A_XdEntity_LockSchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLockSchemeEn>  (GET_ENUM(p, A_XdEntity_LockSchemeEn)));
}
inline DictEntitySecurityLevelEn    GET_A_XdEntity_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntitySecurityLevelEn>  (GET_ENUM(p, A_XdEntity_SecurityLevelEn)));
}
inline XdEntityDeleteRuleEn         GET_A_XdEntity_DeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDeleteRuleEn>  (GET_ENUM(p, A_XdEntity_DeleteRuleEn)));
}
inline XdEntityLastModifEn          GET_A_XdEntity_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_XdEntity_ObjModifStatEn)));
}
inline XdEntityLastModifEn          GET_A_XdEntity_TableModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_XdEntity_TableModifStatEn)));
}
inline XdEntityLastModifEn          GET_A_XdEntity_LastModifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_XdEntity_LastModifEn)));
}
inline DictEntityPkRuleEn           GET_A_XdEntity_PkRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityPkRuleEn>  (GET_ENUM(p, A_XdEntity_PkRuleEn)));
}
inline XdEntityXdActionEn           GET_A_XdEntity_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdEntity_XdActionEn)));
}
inline XdEntityXdActionEn           GET_S_XdEntity_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, S_XdEntity_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdEntity_XdStatusEn)));
}
inline XdEntityXdStatusEn           GET_S_XdEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, S_XdEntity_XdStatusEn)));
}
inline DictEntityTypingNat          GET_A_XdEntity_TypingNat(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityTypingNat>  (GET_ENUM(p, A_XdEntity_TypingNat)));
}
inline XdEntityDbRuleEn             GET_A_XdEntity_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDbRuleEn>  (GET_ENUM(p, A_XdEntity_DbRuleEn)));
}
inline XdEntityDictBuildRuleEn      GET_A_XdEntity_DictBuildRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDictBuildRuleEn>  (GET_ENUM(p, A_XdEntity_DictBuildRuleEn)));
}
inline XdEntityLoadDictRuleEn       GET_A_XdEntity_LoadDictRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLoadDictRuleEn>  (GET_ENUM(p, A_XdEntity_LoadDictRuleEn)));
}
inline XdEntityCopyRightEn          GET_A_XdEntity_CopyRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityCopyRightEn>  (GET_ENUM(p, A_XdEntity_CopyRightEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_ExternalSeqAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_UpdFctAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_UpdFctAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_ActiveAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_ActiveAuthEn)));
}
inline XdEntityDmlModifTrackEn      GET_A_XdEntity_DmlModifTrackEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDmlModifTrackEn>  (GET_ENUM(p, A_XdEntity_DmlModifTrackEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_PartAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_PartAuthEn)));
}
inline XdEntityFeatureAuthEn        GET_A_XdEntity_DlmAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (GET_ENUM(p, A_XdEntity_DlmAuthEn)));
}
inline XdEntityMultiEntityCategoryEn GET_A_XdEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (GET_ENUM(p, A_XdEntity_MultiEntityCategoryEn)));
}

inline DictEntityNatEn              _GET_A_XdEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, A_XdEntity_NatEn)));
}
inline DictEntityNatEn              _GET_S_XdEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, S_XdEntity_NatEn)));
}
inline DictEntityInterfaceEn        _GET_A_XdEntity_InterfaceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityInterfaceEn>  (_GET_ENUM(p, A_XdEntity_InterfaceEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_AuditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_AuditEn)));
}
inline XdEntityLockSchemeEn         _GET_A_XdEntity_LockSchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLockSchemeEn>  (_GET_ENUM(p, A_XdEntity_LockSchemeEn)));
}
inline DictEntitySecurityLevelEn    _GET_A_XdEntity_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntitySecurityLevelEn>  (_GET_ENUM(p, A_XdEntity_SecurityLevelEn)));
}
inline XdEntityDeleteRuleEn         _GET_A_XdEntity_DeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDeleteRuleEn>  (_GET_ENUM(p, A_XdEntity_DeleteRuleEn)));
}
inline XdEntityLastModifEn          _GET_A_XdEntity_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_XdEntity_ObjModifStatEn)));
}
inline XdEntityLastModifEn          _GET_A_XdEntity_TableModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_XdEntity_TableModifStatEn)));
}
inline XdEntityLastModifEn          _GET_A_XdEntity_LastModifEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_XdEntity_LastModifEn)));
}
inline DictEntityPkRuleEn           _GET_A_XdEntity_PkRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityPkRuleEn>  (_GET_ENUM(p, A_XdEntity_PkRuleEn)));
}
inline XdEntityXdActionEn           _GET_A_XdEntity_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdEntity_XdActionEn)));
}
inline XdEntityXdActionEn           _GET_S_XdEntity_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, S_XdEntity_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdEntity_XdStatusEn)));
}
inline XdEntityXdStatusEn           _GET_S_XdEntity_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, S_XdEntity_XdStatusEn)));
}
inline DictEntityTypingNat          _GET_A_XdEntity_TypingNat(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityTypingNat>  (_GET_ENUM(p, A_XdEntity_TypingNat)));
}
inline XdEntityDbRuleEn             _GET_A_XdEntity_DbRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDbRuleEn>  (_GET_ENUM(p, A_XdEntity_DbRuleEn)));
}
inline XdEntityDictBuildRuleEn      _GET_A_XdEntity_DictBuildRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDictBuildRuleEn>  (_GET_ENUM(p, A_XdEntity_DictBuildRuleEn)));
}
inline XdEntityLoadDictRuleEn       _GET_A_XdEntity_LoadDictRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLoadDictRuleEn>  (_GET_ENUM(p, A_XdEntity_LoadDictRuleEn)));
}
inline XdEntityCopyRightEn          _GET_A_XdEntity_CopyRightEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityCopyRightEn>  (_GET_ENUM(p, A_XdEntity_CopyRightEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_ExternalSeqAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_UpdFctAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_UpdFctAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_ActiveAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_ActiveAuthEn)));
}
inline XdEntityDmlModifTrackEn      _GET_A_XdEntity_DmlModifTrackEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityDmlModifTrackEn>  (_GET_ENUM(p, A_XdEntity_DmlModifTrackEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_PartAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_PartAuthEn)));
}
inline XdEntityFeatureAuthEn        _GET_A_XdEntity_DlmAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureAuthEn>  (_GET_ENUM(p, A_XdEntity_DlmAuthEn)));
}
inline XdEntityMultiEntityCategoryEn _GET_A_XdEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityMultiEntityCategoryEn>  (_GET_ENUM(p, A_XdEntity_MultiEntityCategoryEn)));
}

inline void                         SET_A_XdEntity_NatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, A_XdEntity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdEntity_NatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, S_XdEntity_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_InterfaceEn(DBA_DYNFLD_STP p, DictEntityInterfaceEn enumValue)
{
    SET_ENUM(p, A_XdEntity_InterfaceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_AuditEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_AuditEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_LockSchemeEn(DBA_DYNFLD_STP p, XdEntityLockSchemeEn enumValue)
{
    SET_ENUM(p, A_XdEntity_LockSchemeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_SecurityLevelEn(DBA_DYNFLD_STP p, DictEntitySecurityLevelEn enumValue)
{
    SET_ENUM(p, A_XdEntity_SecurityLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_DeleteRuleEn(DBA_DYNFLD_STP p, XdEntityDeleteRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntity_DeleteRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_ObjModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_XdEntity_ObjModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_TableModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_XdEntity_TableModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_LastModifEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_XdEntity_LastModifEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_PkRuleEn(DBA_DYNFLD_STP p, DictEntityPkRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntity_PkRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdEntity_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdEntity_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, S_XdEntity_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdEntity_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdEntity_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, S_XdEntity_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_TypingNat(DBA_DYNFLD_STP p, DictEntityTypingNat enumValue)
{
    SET_ENUM(p, A_XdEntity_TypingNat, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_DbRuleEn(DBA_DYNFLD_STP p, XdEntityDbRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntity_DbRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_DictBuildRuleEn(DBA_DYNFLD_STP p, XdEntityDictBuildRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntity_DictBuildRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_LoadDictRuleEn(DBA_DYNFLD_STP p, XdEntityLoadDictRuleEn enumValue)
{
    SET_ENUM(p, A_XdEntity_LoadDictRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_CopyRightEn(DBA_DYNFLD_STP p, XdEntityCopyRightEn enumValue)
{
    SET_ENUM(p, A_XdEntity_CopyRightEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_ExternalSeqAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_ExternalSeqAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_UpdFctAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_UpdFctAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_ActiveAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_ActiveAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_DmlModifTrackEn(DBA_DYNFLD_STP p, XdEntityDmlModifTrackEn enumValue)
{
    SET_ENUM(p, A_XdEntity_DmlModifTrackEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_PartAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_PartAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_DlmAuthEn(DBA_DYNFLD_STP p, XdEntityFeatureAuthEn enumValue)
{
    SET_ENUM(p, A_XdEntity_DlmAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdEntity_MultiEntityCategoryEn(DBA_DYNFLD_STP p, XdEntityMultiEntityCategoryEn enumValue)
{
    SET_ENUM(p, A_XdEntity_MultiEntityCategoryEn, static_cast<unsigned char>(enumValue));
}


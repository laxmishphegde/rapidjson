/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TradConstrNatEn              GET_A_TradConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TradConstrNatEn>  (GET_ENUM(p, A_TradConstr_NatEn)));
}
inline TradConstrApplicationScopeEn GET_A_TradConstr_ApplicationScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TradConstrApplicationScopeEn>  (GET_ENUM(p, A_TradConstr_ApplicationScopeEn)));
}

inline TradConstrNatEn              _GET_A_TradConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TradConstrNatEn>  (_GET_ENUM(p, A_TradConstr_NatEn)));
}
inline TradConstrApplicationScopeEn _GET_A_TradConstr_ApplicationScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TradConstrApplicationScopeEn>  (_GET_ENUM(p, A_TradConstr_ApplicationScopeEn)));
}

inline void                         SET_A_TradConstr_NatEn(DBA_DYNFLD_STP p, TradConstrNatEn enumValue)
{
    SET_ENUM(p, A_TradConstr_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TradConstr_ApplicationScopeEn(DBA_DYNFLD_STP p, TradConstrApplicationScopeEn enumValue)
{
    SET_ENUM(p, A_TradConstr_ApplicationScopeEn, static_cast<unsigned char>(enumValue));
}


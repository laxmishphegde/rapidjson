/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdLabelNatEn                 GET_A_XdLabel_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdLabelNatEn>  (GET_ENUM(p, A_XdLabel_NatEn)));
}
inline XdLabelNatEn                 GET_S_XdLabel_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdLabelNatEn>  (GET_ENUM(p, S_XdLabel_NatEn)));
}
inline XdEntityXdActionEn           GET_A_XdLabel_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdLabel_XdActionEn)));
}
inline XdEntityXdActionEn           GET_S_XdLabel_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, S_XdLabel_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdLabel_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdLabel_XdStatusEn)));
}
inline XdEntityXdStatusEn           GET_S_XdLabel_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, S_XdLabel_XdStatusEn)));
}

inline XdLabelNatEn                 _GET_A_XdLabel_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdLabelNatEn>  (_GET_ENUM(p, A_XdLabel_NatEn)));
}
inline XdLabelNatEn                 _GET_S_XdLabel_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdLabelNatEn>  (_GET_ENUM(p, S_XdLabel_NatEn)));
}
inline XdEntityXdActionEn           _GET_A_XdLabel_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdLabel_XdActionEn)));
}
inline XdEntityXdActionEn           _GET_S_XdLabel_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, S_XdLabel_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdLabel_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdLabel_XdStatusEn)));
}
inline XdEntityXdStatusEn           _GET_S_XdLabel_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, S_XdLabel_XdStatusEn)));
}

inline void                         SET_A_XdLabel_NatEn(DBA_DYNFLD_STP p, XdLabelNatEn enumValue)
{
    SET_ENUM(p, A_XdLabel_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdLabel_NatEn(DBA_DYNFLD_STP p, XdLabelNatEn enumValue)
{
    SET_ENUM(p, S_XdLabel_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdLabel_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdLabel_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdLabel_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, S_XdLabel_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdLabel_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdLabel_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdLabel_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, S_XdLabel_XdStatusEn, static_cast<unsigned char>(enumValue));
}


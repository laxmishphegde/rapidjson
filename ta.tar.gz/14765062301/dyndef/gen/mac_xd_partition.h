/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdPartitionPartTypeEn        GET_A_XdPartition_PartTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdPartitionPartTypeEn>  (GET_ENUM(p, A_XdPartition_PartTypeEn)));
}
inline XdEntityXdActionEn           GET_A_XdPartition_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdPartition_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdPartition_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdPartition_XdStatusEn)));
}

inline XdPartitionPartTypeEn        _GET_A_XdPartition_PartTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdPartitionPartTypeEn>  (_GET_ENUM(p, A_XdPartition_PartTypeEn)));
}
inline XdEntityXdActionEn           _GET_A_XdPartition_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdPartition_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdPartition_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdPartition_XdStatusEn)));
}

inline void                         SET_A_XdPartition_PartTypeEn(DBA_DYNFLD_STP p, XdPartitionPartTypeEn enumValue)
{
    SET_ENUM(p, A_XdPartition_PartTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdPartition_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdPartition_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdPartition_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdPartition_XdStatusEn, static_cast<unsigned char>(enumValue));
}


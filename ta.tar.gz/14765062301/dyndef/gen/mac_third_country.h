/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdCountryCitizenshipEn    GET_A_ThirdCountry_CitizenshipEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryCitizenshipEn>  (GET_ENUM(p, A_ThirdCountry_CitizenshipEn)));
}
inline ThirdCountryNationalityEn    GET_A_ThirdCountry_NationalityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryNationalityEn>  (GET_ENUM(p, A_ThirdCountry_NationalityEn)));
}
inline ThirdCountryTaxDomicileEn    GET_A_ThirdCountry_TaxDomicileEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryTaxDomicileEn>  (GET_ENUM(p, A_ThirdCountry_TaxDomicileEn)));
}
inline ThirdCountryTaxResidenceEn   GET_A_ThirdCountry_TaxResidenceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryTaxResidenceEn>  (GET_ENUM(p, A_ThirdCountry_TaxResidenceEn)));
}
inline ThirdCountryListedStatusEn   GET_A_ThirdCountry_ListedStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryListedStatusEn>  (GET_ENUM(p, A_ThirdCountry_ListedStatusEn)));
}
inline ThirdCountryRegulatedStatusEn GET_A_ThirdCountry_RegulatedStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryRegulatedStatusEn>  (GET_ENUM(p, A_ThirdCountry_RegulatedStatusEn)));
}
inline ThirdCountryReasonNoTinEn    GET_A_ThirdCountry_ReasonNoTinEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryReasonNoTinEn>  (GET_ENUM(p, A_ThirdCountry_ReasonNoTinEn)));
}
inline ThirdCountryIdenNumTypeEn    GET_A_ThirdCountry_IdenNumTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryIdenNumTypeEn>  (GET_ENUM(p, A_ThirdCountry_IdenNumTypeEn)));
}

inline ThirdCountryCitizenshipEn    _GET_A_ThirdCountry_CitizenshipEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryCitizenshipEn>  (_GET_ENUM(p, A_ThirdCountry_CitizenshipEn)));
}
inline ThirdCountryNationalityEn    _GET_A_ThirdCountry_NationalityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryNationalityEn>  (_GET_ENUM(p, A_ThirdCountry_NationalityEn)));
}
inline ThirdCountryTaxDomicileEn    _GET_A_ThirdCountry_TaxDomicileEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryTaxDomicileEn>  (_GET_ENUM(p, A_ThirdCountry_TaxDomicileEn)));
}
inline ThirdCountryTaxResidenceEn   _GET_A_ThirdCountry_TaxResidenceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryTaxResidenceEn>  (_GET_ENUM(p, A_ThirdCountry_TaxResidenceEn)));
}
inline ThirdCountryListedStatusEn   _GET_A_ThirdCountry_ListedStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryListedStatusEn>  (_GET_ENUM(p, A_ThirdCountry_ListedStatusEn)));
}
inline ThirdCountryRegulatedStatusEn _GET_A_ThirdCountry_RegulatedStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryRegulatedStatusEn>  (_GET_ENUM(p, A_ThirdCountry_RegulatedStatusEn)));
}
inline ThirdCountryReasonNoTinEn    _GET_A_ThirdCountry_ReasonNoTinEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryReasonNoTinEn>  (_GET_ENUM(p, A_ThirdCountry_ReasonNoTinEn)));
}
inline ThirdCountryIdenNumTypeEn    _GET_A_ThirdCountry_IdenNumTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCountryIdenNumTypeEn>  (_GET_ENUM(p, A_ThirdCountry_IdenNumTypeEn)));
}

inline void                         SET_A_ThirdCountry_CitizenshipEn(DBA_DYNFLD_STP p, ThirdCountryCitizenshipEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_CitizenshipEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_NationalityEn(DBA_DYNFLD_STP p, ThirdCountryNationalityEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_NationalityEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_TaxDomicileEn(DBA_DYNFLD_STP p, ThirdCountryTaxDomicileEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_TaxDomicileEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_TaxResidenceEn(DBA_DYNFLD_STP p, ThirdCountryTaxResidenceEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_TaxResidenceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_ListedStatusEn(DBA_DYNFLD_STP p, ThirdCountryListedStatusEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_ListedStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_RegulatedStatusEn(DBA_DYNFLD_STP p, ThirdCountryRegulatedStatusEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_RegulatedStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_ReasonNoTinEn(DBA_DYNFLD_STP p, ThirdCountryReasonNoTinEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_ReasonNoTinEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCountry_IdenNumTypeEn(DBA_DYNFLD_STP p, ThirdCountryIdenNumTypeEn enumValue)
{
    SET_ENUM(p, A_ThirdCountry_IdenNumTypeEn, static_cast<unsigned char>(enumValue));
}


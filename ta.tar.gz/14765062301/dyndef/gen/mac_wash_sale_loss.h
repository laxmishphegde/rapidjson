/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline WashSaleLossStatusEn         GET_A_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WashSaleLossStatusEn>  (GET_ENUM(p, A_WashSaleLoss_StatusEn)));
}
inline WashSaleLossStatusEn         GET_S_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WashSaleLossStatusEn>  (GET_ENUM(p, S_WashSaleLoss_StatusEn)));
}

inline WashSaleLossStatusEn         _GET_A_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WashSaleLossStatusEn>  (_GET_ENUM(p, A_WashSaleLoss_StatusEn)));
}
inline WashSaleLossStatusEn         _GET_S_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<WashSaleLossStatusEn>  (_GET_ENUM(p, S_WashSaleLoss_StatusEn)));
}

inline void                         SET_A_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p, WashSaleLossStatusEn enumValue)
{
    SET_ENUM(p, A_WashSaleLoss_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_WashSaleLoss_StatusEn(DBA_DYNFLD_STP p, WashSaleLossStatusEn enumValue)
{
    SET_ENUM(p, S_WashSaleLoss_StatusEn, static_cast<unsigned char>(enumValue));
}


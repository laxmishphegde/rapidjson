/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdPartyCrsCrsAccHolderNatEn GET_A_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsAccHolderNatEn>  (GET_ENUM(p, A_ThirdPartyCrs_CrsAccHolderNatEn)));
}
inline ThirdPartyCrsCrsAccHolderNatEn GET_S_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsAccHolderNatEn>  (GET_ENUM(p, S_ThirdPartyCrs_CrsAccHolderNatEn)));
}
inline ThirdPartyCrsCrsEntityNatEn  GET_A_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntityNatEn>  (GET_ENUM(p, A_ThirdPartyCrs_CrsEntityNatEn)));
}
inline ThirdPartyCrsCrsEntityNatEn  GET_S_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntityNatEn>  (GET_ENUM(p, S_ThirdPartyCrs_CrsEntityNatEn)));
}
inline ThirdPartyCrsCrsEntitySubNatEn GET_A_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntitySubNatEn>  (GET_ENUM(p, A_ThirdPartyCrs_CrsEntitySubNatEn)));
}
inline ThirdPartyCrsCrsEntitySubNatEn GET_S_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntitySubNatEn>  (GET_ENUM(p, S_ThirdPartyCrs_CrsEntitySubNatEn)));
}
inline ThirdPartyCrsCrsCtrlPersonDefEn GET_A_ThirdPartyCrs_CrsCtrlPersonDefEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsCtrlPersonDefEn>  (GET_ENUM(p, A_ThirdPartyCrs_CrsCtrlPersonDefEn)));
}

inline ThirdPartyCrsCrsAccHolderNatEn _GET_A_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsAccHolderNatEn>  (_GET_ENUM(p, A_ThirdPartyCrs_CrsAccHolderNatEn)));
}
inline ThirdPartyCrsCrsAccHolderNatEn _GET_S_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsAccHolderNatEn>  (_GET_ENUM(p, S_ThirdPartyCrs_CrsAccHolderNatEn)));
}
inline ThirdPartyCrsCrsEntityNatEn  _GET_A_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntityNatEn>  (_GET_ENUM(p, A_ThirdPartyCrs_CrsEntityNatEn)));
}
inline ThirdPartyCrsCrsEntityNatEn  _GET_S_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntityNatEn>  (_GET_ENUM(p, S_ThirdPartyCrs_CrsEntityNatEn)));
}
inline ThirdPartyCrsCrsEntitySubNatEn _GET_A_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntitySubNatEn>  (_GET_ENUM(p, A_ThirdPartyCrs_CrsEntitySubNatEn)));
}
inline ThirdPartyCrsCrsEntitySubNatEn _GET_S_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsEntitySubNatEn>  (_GET_ENUM(p, S_ThirdPartyCrs_CrsEntitySubNatEn)));
}
inline ThirdPartyCrsCrsCtrlPersonDefEn _GET_A_ThirdPartyCrs_CrsCtrlPersonDefEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrsCrsCtrlPersonDefEn>  (_GET_ENUM(p, A_ThirdPartyCrs_CrsCtrlPersonDefEn)));
}

inline void                         SET_A_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsAccHolderNatEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrs_CrsAccHolderNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdPartyCrs_CrsAccHolderNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsAccHolderNatEn enumValue)
{
    SET_ENUM(p, S_ThirdPartyCrs_CrsAccHolderNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsEntityNatEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrs_CrsEntityNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdPartyCrs_CrsEntityNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsEntityNatEn enumValue)
{
    SET_ENUM(p, S_ThirdPartyCrs_CrsEntityNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsEntitySubNatEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrs_CrsEntitySubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdPartyCrs_CrsEntitySubNatEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsEntitySubNatEn enumValue)
{
    SET_ENUM(p, S_ThirdPartyCrs_CrsEntitySubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrs_CrsCtrlPersonDefEn(DBA_DYNFLD_STP p, ThirdPartyCrsCrsCtrlPersonDefEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrs_CrsCtrlPersonDefEn, static_cast<unsigned char>(enumValue));
}


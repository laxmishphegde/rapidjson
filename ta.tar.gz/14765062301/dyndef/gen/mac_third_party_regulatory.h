/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdPartyRegulatoryOverallRiskEn GET_A_ThirdPartyRegulatory_OverallRiskEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryOverallRiskEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_OverallRiskEn)));
}
inline ThirdPartyRegulatoryAmlRiskRatingEn GET_A_ThirdPartyRegulatory_AmlRiskRatingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryAmlRiskRatingEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_AmlRiskRatingEn)));
}
inline ThirdPartyRegulatoryRiskTaxEvasionEn GET_A_ThirdPartyRegulatory_RiskTaxEvasionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryRiskTaxEvasionEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_RiskTaxEvasionEn)));
}
inline ThirdPartyRegulatoryInternetFactivaFindEn GET_A_ThirdPartyRegulatory_InternetFactivaFindEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryInternetFactivaFindEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_InternetFactivaFindEn)));
}
inline ThirdPartyRegulatoryFundInMethodEn GET_A_ThirdPartyRegulatory_FundInMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryFundInMethodEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_FundInMethodEn)));
}
inline ThirdPartyRegulatoryFundOutMethodEn GET_A_ThirdPartyRegulatory_FundOutMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryFundOutMethodEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_FundOutMethodEn)));
}
inline ThirdPartyRegulatorySourceWealthEn GET_A_ThirdPartyRegulatory_SourceWealthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatorySourceWealthEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_SourceWealthEn)));
}
inline ThirdPartyRegulatoryEmpStatusEn GET_A_ThirdPartyRegulatory_EmpStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryEmpStatusEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_EmpStatusEn)));
}
inline ThirdPartyRegulatoryMgtDiscEn GET_A_ThirdPartyRegulatory_MgtDiscEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryMgtDiscEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_MgtDiscEn)));
}
inline ThirdPartyRegulatorySignRelGovEn GET_A_ThirdPartyRegulatory_SignRelGovEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatorySignRelGovEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_SignRelGovEn)));
}
inline ThirdPartyRegulatoryCmplxStructEn GET_A_ThirdPartyRegulatory_CmplxStructEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryCmplxStructEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_CmplxStructEn)));
}
inline ThirdPartyRegulatoryHighriskProEn GET_A_ThirdPartyRegulatory_HighriskProEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryHighriskProEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_HighriskProEn)));
}
inline ThirdPartyRegulatoryCorrAccEn GET_A_ThirdPartyRegulatory_CorrAccEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryCorrAccEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_CorrAccEn)));
}
inline ThirdPartyRegulatoryScreeningEn GET_A_ThirdPartyRegulatory_ScreeningEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryScreeningEn>  (GET_ENUM(p, A_ThirdPartyRegulatory_ScreeningEn)));
}

inline ThirdPartyRegulatoryOverallRiskEn _GET_A_ThirdPartyRegulatory_OverallRiskEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryOverallRiskEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_OverallRiskEn)));
}
inline ThirdPartyRegulatoryAmlRiskRatingEn _GET_A_ThirdPartyRegulatory_AmlRiskRatingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryAmlRiskRatingEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_AmlRiskRatingEn)));
}
inline ThirdPartyRegulatoryRiskTaxEvasionEn _GET_A_ThirdPartyRegulatory_RiskTaxEvasionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryRiskTaxEvasionEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_RiskTaxEvasionEn)));
}
inline ThirdPartyRegulatoryInternetFactivaFindEn _GET_A_ThirdPartyRegulatory_InternetFactivaFindEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryInternetFactivaFindEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_InternetFactivaFindEn)));
}
inline ThirdPartyRegulatoryFundInMethodEn _GET_A_ThirdPartyRegulatory_FundInMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryFundInMethodEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_FundInMethodEn)));
}
inline ThirdPartyRegulatoryFundOutMethodEn _GET_A_ThirdPartyRegulatory_FundOutMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryFundOutMethodEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_FundOutMethodEn)));
}
inline ThirdPartyRegulatorySourceWealthEn _GET_A_ThirdPartyRegulatory_SourceWealthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatorySourceWealthEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_SourceWealthEn)));
}
inline ThirdPartyRegulatoryEmpStatusEn _GET_A_ThirdPartyRegulatory_EmpStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryEmpStatusEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_EmpStatusEn)));
}
inline ThirdPartyRegulatoryMgtDiscEn _GET_A_ThirdPartyRegulatory_MgtDiscEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryMgtDiscEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_MgtDiscEn)));
}
inline ThirdPartyRegulatorySignRelGovEn _GET_A_ThirdPartyRegulatory_SignRelGovEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatorySignRelGovEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_SignRelGovEn)));
}
inline ThirdPartyRegulatoryCmplxStructEn _GET_A_ThirdPartyRegulatory_CmplxStructEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryCmplxStructEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_CmplxStructEn)));
}
inline ThirdPartyRegulatoryHighriskProEn _GET_A_ThirdPartyRegulatory_HighriskProEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryHighriskProEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_HighriskProEn)));
}
inline ThirdPartyRegulatoryCorrAccEn _GET_A_ThirdPartyRegulatory_CorrAccEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryCorrAccEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_CorrAccEn)));
}
inline ThirdPartyRegulatoryScreeningEn _GET_A_ThirdPartyRegulatory_ScreeningEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyRegulatoryScreeningEn>  (_GET_ENUM(p, A_ThirdPartyRegulatory_ScreeningEn)));
}

inline void                         SET_A_ThirdPartyRegulatory_OverallRiskEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryOverallRiskEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_OverallRiskEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_AmlRiskRatingEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryAmlRiskRatingEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_AmlRiskRatingEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_RiskTaxEvasionEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryRiskTaxEvasionEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_RiskTaxEvasionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_InternetFactivaFindEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryInternetFactivaFindEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_InternetFactivaFindEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_FundInMethodEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryFundInMethodEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_FundInMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_FundOutMethodEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryFundOutMethodEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_FundOutMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_SourceWealthEn(DBA_DYNFLD_STP p, ThirdPartyRegulatorySourceWealthEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_SourceWealthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_EmpStatusEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryEmpStatusEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_EmpStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_MgtDiscEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryMgtDiscEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_MgtDiscEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_SignRelGovEn(DBA_DYNFLD_STP p, ThirdPartyRegulatorySignRelGovEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_SignRelGovEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_CmplxStructEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryCmplxStructEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_CmplxStructEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_HighriskProEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryHighriskProEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_HighriskProEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_CorrAccEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryCorrAccEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_CorrAccEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyRegulatory_ScreeningEn(DBA_DYNFLD_STP p, ThirdPartyRegulatoryScreeningEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyRegulatory_ScreeningEn, static_cast<unsigned char>(enumValue));
}


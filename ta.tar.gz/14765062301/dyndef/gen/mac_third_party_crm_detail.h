/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdPartyCrmDetailPostingRestrictionEn GET_A_ThirdPartyCrmDetail_PostingRestrictionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailPostingRestrictionEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_PostingRestrictionEn)));
}
inline ThirdPartyCrmDetailGovtOwnCoEn GET_A_ThirdPartyCrmDetail_GovtOwnCoEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailGovtOwnCoEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_GovtOwnCoEn)));
}
inline ThirdPartyCrmDetailBearShareEn GET_A_ThirdPartyCrmDetail_BearShareEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailBearShareEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_BearShareEn)));
}
inline ThirdPartyCrmDetailUboHunIdenEn GET_A_ThirdPartyCrmDetail_UboHunIdenEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailUboHunIdenEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_UboHunIdenEn)));
}
inline ThirdPartyCrmDetailMainSrcWealthEn GET_A_ThirdPartyCrmDetail_MainSrcWealthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailMainSrcWealthEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_MainSrcWealthEn)));
}
inline ThirdPartyCrmDetailNonProfOrgEn GET_A_ThirdPartyCrmDetail_NonProfOrgEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailNonProfOrgEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_NonProfOrgEn)));
}
inline ThirdPartyCrmDetailIntrBusCoEn GET_A_ThirdPartyCrmDetail_IntrBusCoEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailIntrBusCoEn>  (GET_ENUM(p, A_ThirdPartyCrmDetail_IntrBusCoEn)));
}

inline ThirdPartyCrmDetailPostingRestrictionEn _GET_A_ThirdPartyCrmDetail_PostingRestrictionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailPostingRestrictionEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_PostingRestrictionEn)));
}
inline ThirdPartyCrmDetailGovtOwnCoEn _GET_A_ThirdPartyCrmDetail_GovtOwnCoEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailGovtOwnCoEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_GovtOwnCoEn)));
}
inline ThirdPartyCrmDetailBearShareEn _GET_A_ThirdPartyCrmDetail_BearShareEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailBearShareEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_BearShareEn)));
}
inline ThirdPartyCrmDetailUboHunIdenEn _GET_A_ThirdPartyCrmDetail_UboHunIdenEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailUboHunIdenEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_UboHunIdenEn)));
}
inline ThirdPartyCrmDetailMainSrcWealthEn _GET_A_ThirdPartyCrmDetail_MainSrcWealthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailMainSrcWealthEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_MainSrcWealthEn)));
}
inline ThirdPartyCrmDetailNonProfOrgEn _GET_A_ThirdPartyCrmDetail_NonProfOrgEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailNonProfOrgEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_NonProfOrgEn)));
}
inline ThirdPartyCrmDetailIntrBusCoEn _GET_A_ThirdPartyCrmDetail_IntrBusCoEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyCrmDetailIntrBusCoEn>  (_GET_ENUM(p, A_ThirdPartyCrmDetail_IntrBusCoEn)));
}

inline void                         SET_A_ThirdPartyCrmDetail_PostingRestrictionEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailPostingRestrictionEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_PostingRestrictionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_GovtOwnCoEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailGovtOwnCoEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_GovtOwnCoEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_BearShareEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailBearShareEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_BearShareEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_UboHunIdenEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailUboHunIdenEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_UboHunIdenEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_MainSrcWealthEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailMainSrcWealthEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_MainSrcWealthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_NonProfOrgEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailNonProfOrgEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_NonProfOrgEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyCrmDetail_IntrBusCoEn(DBA_DYNFLD_STP p, ThirdPartyCrmDetailIntrBusCoEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyCrmDetail_IntrBusCoEn, static_cast<unsigned char>(enumValue));
}


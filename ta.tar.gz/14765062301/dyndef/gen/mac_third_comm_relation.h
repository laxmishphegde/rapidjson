/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdCommRelationUsageTypeEn GET_A_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationUsageTypeEn>  (GET_ENUM(p, A_ThirdCommRelation_UsageTypeEn)));
}
inline ThirdCommRelationUsageTypeEn GET_S_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationUsageTypeEn>  (GET_ENUM(p, S_ThirdCommRelation_UsageTypeEn)));
}
inline ThirdCommRelationStatusEn    GET_A_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationStatusEn>  (GET_ENUM(p, A_ThirdCommRelation_StatusEn)));
}
inline ThirdCommRelationStatusEn    GET_S_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationStatusEn>  (GET_ENUM(p, S_ThirdCommRelation_StatusEn)));
}

inline ThirdCommRelationUsageTypeEn _GET_A_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationUsageTypeEn>  (_GET_ENUM(p, A_ThirdCommRelation_UsageTypeEn)));
}
inline ThirdCommRelationUsageTypeEn _GET_S_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationUsageTypeEn>  (_GET_ENUM(p, S_ThirdCommRelation_UsageTypeEn)));
}
inline ThirdCommRelationStatusEn    _GET_A_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationStatusEn>  (_GET_ENUM(p, A_ThirdCommRelation_StatusEn)));
}
inline ThirdCommRelationStatusEn    _GET_S_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCommRelationStatusEn>  (_GET_ENUM(p, S_ThirdCommRelation_StatusEn)));
}

inline void                         SET_A_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p, ThirdCommRelationUsageTypeEn enumValue)
{
    SET_ENUM(p, A_ThirdCommRelation_UsageTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdCommRelation_UsageTypeEn(DBA_DYNFLD_STP p, ThirdCommRelationUsageTypeEn enumValue)
{
    SET_ENUM(p, S_ThirdCommRelation_UsageTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p, ThirdCommRelationStatusEn enumValue)
{
    SET_ENUM(p, A_ThirdCommRelation_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdCommRelation_StatusEn(DBA_DYNFLD_STP p, ThirdCommRelationStatusEn enumValue)
{
    SET_ENUM(p, S_ThirdCommRelation_StatusEn, static_cast<unsigned char>(enumValue));
}


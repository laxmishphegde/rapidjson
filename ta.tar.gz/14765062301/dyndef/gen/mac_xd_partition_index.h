/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdEntityXdActionEn           GET_A_XdPartitionIndex_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdPartitionIndex_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdPartitionIndex_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdPartitionIndex_XdStatusEn)));
}

inline XdEntityXdActionEn           _GET_A_XdPartitionIndex_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdPartitionIndex_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdPartitionIndex_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdPartitionIndex_XdStatusEn)));
}

inline void                         SET_A_XdPartitionIndex_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdPartitionIndex_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdPartitionIndex_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdPartitionIndex_XdStatusEn, static_cast<unsigned char>(enumValue));
}


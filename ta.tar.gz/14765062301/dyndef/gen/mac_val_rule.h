/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ValRuleNatEn                 GET_A_ValRule_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleNatEn>  (GET_ENUM(p, A_ValRule_NatEn)));
}
inline ValRuleNatEn                 GET_S_ValRule_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleNatEn>  (GET_ENUM(p, S_ValRule_NatEn)));
}

inline ValRuleNatEn                 _GET_A_ValRule_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleNatEn>  (_GET_ENUM(p, A_ValRule_NatEn)));
}
inline ValRuleNatEn                 _GET_S_ValRule_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ValRuleNatEn>  (_GET_ENUM(p, S_ValRule_NatEn)));
}

inline void                         SET_A_ValRule_NatEn(DBA_DYNFLD_STP p, ValRuleNatEn enumValue)
{
    SET_ENUM(p, A_ValRule_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ValRule_NatEn(DBA_DYNFLD_STP p, ValRuleNatEn enumValue)
{
    SET_ENUM(p, S_ValRule_NatEn, static_cast<unsigned char>(enumValue));
}


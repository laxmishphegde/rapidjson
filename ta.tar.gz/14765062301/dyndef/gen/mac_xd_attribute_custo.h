/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdAttributeCustoNatEn        GET_A_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoNatEn>  (GET_ENUM(p, A_XdAttributeCusto_NatEn)));
}
inline XdAttributeCustoNatEn        GET_S_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoNatEn>  (GET_ENUM(p, S_XdAttributeCusto_NatEn)));
}
inline XdEntityXdActionEn           GET_A_XdAttributeCusto_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdAttributeCusto_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdAttributeCusto_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdAttributeCusto_XdStatusEn)));
}
inline DictAttrEditEn               GET_A_XdAttributeCusto_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (GET_ENUM(p, A_XdAttributeCusto_EditEn)));
}
inline XdAttribExportEn             GET_A_XdAttributeCusto_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (GET_ENUM(p, A_XdAttributeCusto_ExportEn)));
}
inline XdAttribMeSpecialisationEn   GET_A_XdAttributeCusto_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (GET_ENUM(p, A_XdAttributeCusto_MeSpecialisationEn)));
}
inline XdAttributeCustoTslSearchEn  GET_A_XdAttributeCusto_TslSearchEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoTslSearchEn>  (GET_ENUM(p, A_XdAttributeCusto_TslSearchEn)));
}
inline XdEntityLastModifEn          GET_A_XdAttributeCusto_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_XdAttributeCusto_ObjModifStatEn)));
}
inline DictAttrWidgetEn             GET_A_XdAttributeCusto_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (GET_ENUM(p, A_XdAttributeCusto_WidgetEn)));
}

inline XdAttributeCustoNatEn        _GET_A_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoNatEn>  (_GET_ENUM(p, A_XdAttributeCusto_NatEn)));
}
inline XdAttributeCustoNatEn        _GET_S_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoNatEn>  (_GET_ENUM(p, S_XdAttributeCusto_NatEn)));
}
inline XdEntityXdActionEn           _GET_A_XdAttributeCusto_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdAttributeCusto_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdAttributeCusto_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdAttributeCusto_XdStatusEn)));
}
inline DictAttrEditEn               _GET_A_XdAttributeCusto_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (_GET_ENUM(p, A_XdAttributeCusto_EditEn)));
}
inline XdAttribExportEn             _GET_A_XdAttributeCusto_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (_GET_ENUM(p, A_XdAttributeCusto_ExportEn)));
}
inline XdAttribMeSpecialisationEn   _GET_A_XdAttributeCusto_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (_GET_ENUM(p, A_XdAttributeCusto_MeSpecialisationEn)));
}
inline XdAttributeCustoTslSearchEn  _GET_A_XdAttributeCusto_TslSearchEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoTslSearchEn>  (_GET_ENUM(p, A_XdAttributeCusto_TslSearchEn)));
}
inline XdEntityLastModifEn          _GET_A_XdAttributeCusto_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_XdAttributeCusto_ObjModifStatEn)));
}
inline DictAttrWidgetEn             _GET_A_XdAttributeCusto_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (_GET_ENUM(p, A_XdAttributeCusto_WidgetEn)));
}

inline void                         SET_A_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p, XdAttributeCustoNatEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttributeCusto_NatEn(DBA_DYNFLD_STP p, XdAttributeCustoNatEn enumValue)
{
    SET_ENUM(p, S_XdAttributeCusto_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_EditEn(DBA_DYNFLD_STP p, DictAttrEditEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_EditEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_ExportEn(DBA_DYNFLD_STP p, XdAttribExportEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_ExportEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_MeSpecialisationEn(DBA_DYNFLD_STP p, XdAttribMeSpecialisationEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_MeSpecialisationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_TslSearchEn(DBA_DYNFLD_STP p, XdAttributeCustoTslSearchEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_TslSearchEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_ObjModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_ObjModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttributeCusto_WidgetEn(DBA_DYNFLD_STP p, DictAttrWidgetEn enumValue)
{
    SET_ENUM(p, A_XdAttributeCusto_WidgetEn, enumValue);
}


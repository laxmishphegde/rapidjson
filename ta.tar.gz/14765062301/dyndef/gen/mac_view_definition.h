/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ViewDefinitionViewTypeEn     GET_A_ViewDefinition_ViewTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ViewDefinitionViewTypeEn>  (GET_ENUM(p, A_ViewDefinition_ViewTypeEn)));
}
inline ViewDefinitionNatEn          GET_A_ViewDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ViewDefinitionNatEn>  (GET_ENUM(p, A_ViewDefinition_NatEn)));
}

inline ViewDefinitionViewTypeEn     _GET_A_ViewDefinition_ViewTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ViewDefinitionViewTypeEn>  (_GET_ENUM(p, A_ViewDefinition_ViewTypeEn)));
}
inline ViewDefinitionNatEn          _GET_A_ViewDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ViewDefinitionNatEn>  (_GET_ENUM(p, A_ViewDefinition_NatEn)));
}

inline void                         SET_A_ViewDefinition_ViewTypeEn(DBA_DYNFLD_STP p, ViewDefinitionViewTypeEn enumValue)
{
    SET_ENUM(p, A_ViewDefinition_ViewTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ViewDefinition_NatEn(DBA_DYNFLD_STP p, ViewDefinitionNatEn enumValue)
{
    SET_ENUM(p, A_ViewDefinition_NatEn, static_cast<unsigned char>(enumValue));
}


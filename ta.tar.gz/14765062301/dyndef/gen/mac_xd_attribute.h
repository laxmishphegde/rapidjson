/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdAttribRefDeleteRuleEn      GET_A_XdAttrib_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (GET_ENUM(p, A_XdAttrib_RefDeleteRuleEn)));
}
inline XdAttribRefSecurityRuleEn    GET_A_XdAttrib_RefSecurityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefSecurityRuleEn>  (GET_ENUM(p, A_XdAttrib_RefSecurityRuleEn)));
}
inline XdAttribCustomFlg            GET_A_XdAttrib_CustomFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCustomFlg>  (GET_ENUM(p, A_XdAttrib_CustomFlg)));
}
inline XdAttribCustomFlg            GET_S_XdAttrib_CustomFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCustomFlg>  (GET_ENUM(p, S_XdAttrib_CustomFlg)));
}
inline DictAttrCalcEn               GET_A_XdAttrib_CalcEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrCalcEn>  (GET_ENUM(p, A_XdAttrib_CalcEn)));
}
inline DictAttrPermAuthFlg          GET_A_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (GET_ENUM(p, A_XdAttrib_PermAuthEn)));
}
inline DictAttrPermAuthFlg          GET_S_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (GET_ENUM(p, S_XdAttrib_PermAuthEn)));
}
inline DictAttrEditEn               GET_A_XdAttrib_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (GET_ENUM(p, A_XdAttrib_EditEn)));
}
inline DictAttrSecurityLevelEn      GET_A_XdAttrib_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrSecurityLevelEn>  (GET_ENUM(p, A_XdAttrib_SecurityLevelEn)));
}
inline DictAttrWidgetEn             GET_A_XdAttrib_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (GET_ENUM(p, A_XdAttrib_WidgetEn)));
}
inline DictAttrTascViewEn           GET_A_XdAttrib_TascViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrTascViewEn>  (GET_ENUM(p, A_XdAttrib_TascViewEn)));
}
inline DictAttrFkPresentationEn     GET_A_XdAttrib_FkPresentationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrFkPresentationEn>  (GET_ENUM(p, A_XdAttrib_FkPresentationEn)));
}
inline XdEntityLastModifEn          GET_A_XdAttrib_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (GET_ENUM(p, A_XdAttrib_ObjModifStatEn)));
}
inline XdEntityXdActionEn           GET_A_XdAttrib_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdAttrib_XdActionEn)));
}
inline XdEntityXdActionEn           GET_S_XdAttrib_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, S_XdAttrib_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdAttrib_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdAttrib_XdStatusEn)));
}
inline XdAttribRefCheckRuleEn       GET_A_XdAttrib_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (GET_ENUM(p, A_XdAttrib_RefCheckRuleEn)));
}
inline XdAttribExportEn             GET_A_XdAttrib_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (GET_ENUM(p, A_XdAttrib_ExportEn)));
}
inline XdEntityFeatureFeatureEn     GET_A_XdAttrib_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (GET_ENUM(p, A_XdAttrib_FeatureEn)));
}
inline XdEntityFeatureFeatureEn     GET_S_XdAttrib_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (GET_ENUM(p, S_XdAttrib_FeatureEn)));
}
inline XdAttribModelBankEn          GET_A_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (GET_ENUM(p, A_XdAttrib_ModelBankEn)));
}
inline XdAttribModelBankEn          GET_S_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (GET_ENUM(p, S_XdAttrib_ModelBankEn)));
}
inline XdAttribMeSpecialisationEn   GET_A_XdAttrib_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (GET_ENUM(p, A_XdAttrib_MeSpecialisationEn)));
}
inline XdAttribOutboxPublishEn      GET_A_XdAttrib_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (GET_ENUM(p, A_XdAttrib_OutboxPublishEn)));
}

inline XdAttribRefDeleteRuleEn      _GET_A_XdAttrib_RefDeleteRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefDeleteRuleEn>  (_GET_ENUM(p, A_XdAttrib_RefDeleteRuleEn)));
}
inline XdAttribRefSecurityRuleEn    _GET_A_XdAttrib_RefSecurityRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefSecurityRuleEn>  (_GET_ENUM(p, A_XdAttrib_RefSecurityRuleEn)));
}
inline XdAttribCustomFlg            _GET_A_XdAttrib_CustomFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCustomFlg>  (_GET_ENUM(p, A_XdAttrib_CustomFlg)));
}
inline XdAttribCustomFlg            _GET_S_XdAttrib_CustomFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCustomFlg>  (_GET_ENUM(p, S_XdAttrib_CustomFlg)));
}
inline DictAttrCalcEn               _GET_A_XdAttrib_CalcEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrCalcEn>  (_GET_ENUM(p, A_XdAttrib_CalcEn)));
}
inline DictAttrPermAuthFlg          _GET_A_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (_GET_ENUM(p, A_XdAttrib_PermAuthEn)));
}
inline DictAttrPermAuthFlg          _GET_S_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrPermAuthFlg>  (_GET_ENUM(p, S_XdAttrib_PermAuthEn)));
}
inline DictAttrEditEn               _GET_A_XdAttrib_EditEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrEditEn>  (_GET_ENUM(p, A_XdAttrib_EditEn)));
}
inline DictAttrSecurityLevelEn      _GET_A_XdAttrib_SecurityLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrSecurityLevelEn>  (_GET_ENUM(p, A_XdAttrib_SecurityLevelEn)));
}
inline DictAttrWidgetEn             _GET_A_XdAttrib_WidgetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrWidgetEn>  (_GET_ENUM(p, A_XdAttrib_WidgetEn)));
}
inline DictAttrTascViewEn           _GET_A_XdAttrib_TascViewEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrTascViewEn>  (_GET_ENUM(p, A_XdAttrib_TascViewEn)));
}
inline DictAttrFkPresentationEn     _GET_A_XdAttrib_FkPresentationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttrFkPresentationEn>  (_GET_ENUM(p, A_XdAttrib_FkPresentationEn)));
}
inline XdEntityLastModifEn          _GET_A_XdAttrib_ObjModifStatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityLastModifEn>  (_GET_ENUM(p, A_XdAttrib_ObjModifStatEn)));
}
inline XdEntityXdActionEn           _GET_A_XdAttrib_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdAttrib_XdActionEn)));
}
inline XdEntityXdActionEn           _GET_S_XdAttrib_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, S_XdAttrib_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdAttrib_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdAttrib_XdStatusEn)));
}
inline XdAttribRefCheckRuleEn       _GET_A_XdAttrib_RefCheckRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribRefCheckRuleEn>  (_GET_ENUM(p, A_XdAttrib_RefCheckRuleEn)));
}
inline XdAttribExportEn             _GET_A_XdAttrib_ExportEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribExportEn>  (_GET_ENUM(p, A_XdAttrib_ExportEn)));
}
inline XdEntityFeatureFeatureEn     _GET_A_XdAttrib_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (_GET_ENUM(p, A_XdAttrib_FeatureEn)));
}
inline XdEntityFeatureFeatureEn     _GET_S_XdAttrib_FeatureEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityFeatureFeatureEn>  (_GET_ENUM(p, S_XdAttrib_FeatureEn)));
}
inline XdAttribModelBankEn          _GET_A_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (_GET_ENUM(p, A_XdAttrib_ModelBankEn)));
}
inline XdAttribModelBankEn          _GET_S_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribModelBankEn>  (_GET_ENUM(p, S_XdAttrib_ModelBankEn)));
}
inline XdAttribMeSpecialisationEn   _GET_A_XdAttrib_MeSpecialisationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribMeSpecialisationEn>  (_GET_ENUM(p, A_XdAttrib_MeSpecialisationEn)));
}
inline XdAttribOutboxPublishEn      _GET_A_XdAttrib_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (_GET_ENUM(p, A_XdAttrib_OutboxPublishEn)));
}

inline void                         SET_A_XdAttrib_RefDeleteRuleEn(DBA_DYNFLD_STP p, XdAttribRefDeleteRuleEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_RefDeleteRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_RefSecurityRuleEn(DBA_DYNFLD_STP p, XdAttribRefSecurityRuleEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_RefSecurityRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_CustomFlg(DBA_DYNFLD_STP p, XdAttribCustomFlg enumValue)
{
    SET_ENUM(p, A_XdAttrib_CustomFlg, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttrib_CustomFlg(DBA_DYNFLD_STP p, XdAttribCustomFlg enumValue)
{
    SET_ENUM(p, S_XdAttrib_CustomFlg, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_CalcEn(DBA_DYNFLD_STP p, DictAttrCalcEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_CalcEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p, DictAttrPermAuthFlg enumValue)
{
    SET_ENUM(p, A_XdAttrib_PermAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttrib_PermAuthEn(DBA_DYNFLD_STP p, DictAttrPermAuthFlg enumValue)
{
    SET_ENUM(p, S_XdAttrib_PermAuthEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_EditEn(DBA_DYNFLD_STP p, DictAttrEditEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_EditEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_SecurityLevelEn(DBA_DYNFLD_STP p, DictAttrSecurityLevelEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_SecurityLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_WidgetEn(DBA_DYNFLD_STP p, DictAttrWidgetEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_WidgetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_TascViewEn(DBA_DYNFLD_STP p, DictAttrTascViewEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_TascViewEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_FkPresentationEn(DBA_DYNFLD_STP p, DictAttrFkPresentationEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_FkPresentationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_ObjModifStatEn(DBA_DYNFLD_STP p, XdEntityLastModifEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_ObjModifStatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttrib_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, S_XdAttrib_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_RefCheckRuleEn(DBA_DYNFLD_STP p, XdAttribRefCheckRuleEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_RefCheckRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_ExportEn(DBA_DYNFLD_STP p, XdAttribExportEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_ExportEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_FeatureEn(DBA_DYNFLD_STP p, XdEntityFeatureFeatureEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_FeatureEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttrib_FeatureEn(DBA_DYNFLD_STP p, XdEntityFeatureFeatureEn enumValue)
{
    SET_ENUM(p, S_XdAttrib_FeatureEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p, XdAttribModelBankEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_ModelBankEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttrib_ModelBankEn(DBA_DYNFLD_STP p, XdAttribModelBankEn enumValue)
{
    SET_ENUM(p, S_XdAttrib_ModelBankEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_MeSpecialisationEn(DBA_DYNFLD_STP p, XdAttribMeSpecialisationEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_MeSpecialisationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttrib_OutboxPublishEn(DBA_DYNFLD_STP p, XdAttribOutboxPublishEn enumValue)
{
    SET_ENUM(p, A_XdAttrib_OutboxPublishEn, static_cast<unsigned char>(enumValue));
}


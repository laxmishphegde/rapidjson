/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdIndexIdxFctEn              GET_A_XdIndex_IdxFctEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexIdxFctEn>  (GET_ENUM(p, A_XdIndex_IdxFctEn)));
}
inline XdIndexIdxFctEn              GET_S_XdIndex_IdxFctEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexIdxFctEn>  (GET_ENUM(p, S_XdIndex_IdxFctEn)));
}
inline XdEntityXdActionEn           GET_A_XdIndex_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdIndex_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_XdIndex_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdIndex_XdStatusEn)));
}
inline XdIndexScopeEn               GET_A_XdIndex_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexScopeEn>  (GET_ENUM(p, A_XdIndex_ScopeEn)));
}

inline XdIndexIdxFctEn              _GET_A_XdIndex_IdxFctEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexIdxFctEn>  (_GET_ENUM(p, A_XdIndex_IdxFctEn)));
}
inline XdIndexIdxFctEn              _GET_S_XdIndex_IdxFctEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexIdxFctEn>  (_GET_ENUM(p, S_XdIndex_IdxFctEn)));
}
inline XdEntityXdActionEn           _GET_A_XdIndex_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdIndex_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdIndex_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdIndex_XdStatusEn)));
}
inline XdIndexScopeEn               _GET_A_XdIndex_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdIndexScopeEn>  (_GET_ENUM(p, A_XdIndex_ScopeEn)));
}

inline void                         SET_A_XdIndex_IdxFctEn(DBA_DYNFLD_STP p, XdIndexIdxFctEn enumValue)
{
    SET_ENUM(p, A_XdIndex_IdxFctEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdIndex_IdxFctEn(DBA_DYNFLD_STP p, XdIndexIdxFctEn enumValue)
{
    SET_ENUM(p, S_XdIndex_IdxFctEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdIndex_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdIndex_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdIndex_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdIndex_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdIndex_ScopeEn(DBA_DYNFLD_STP p, XdIndexScopeEn enumValue)
{
    SET_ENUM(p, A_XdIndex_ScopeEn, static_cast<unsigned char>(enumValue));
}


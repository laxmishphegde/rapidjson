/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline XdAttribCommentNatEn         GET_A_XdAttribComment_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCommentNatEn>  (GET_ENUM(p, A_XdAttribComment_NatEn)));
}
inline XdAttribCommentNatEn         GET_S_XdAttribComment_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCommentNatEn>  (GET_ENUM(p, S_XdAttribComment_NatEn)));
}
inline XdEntityXdStatusEn           GET_A_XdAttribComment_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_XdAttribComment_XdStatusEn)));
}
inline XdEntityXdActionEn           GET_A_XdAttribComment_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_XdAttribComment_XdActionEn)));
}

inline XdAttribCommentNatEn         _GET_A_XdAttribComment_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCommentNatEn>  (_GET_ENUM(p, A_XdAttribComment_NatEn)));
}
inline XdAttribCommentNatEn         _GET_S_XdAttribComment_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribCommentNatEn>  (_GET_ENUM(p, S_XdAttribComment_NatEn)));
}
inline XdEntityXdStatusEn           _GET_A_XdAttribComment_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_XdAttribComment_XdStatusEn)));
}
inline XdEntityXdActionEn           _GET_A_XdAttribComment_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_XdAttribComment_XdActionEn)));
}

inline void                         SET_A_XdAttribComment_NatEn(DBA_DYNFLD_STP p, XdAttribCommentNatEn enumValue)
{
    SET_ENUM(p, A_XdAttribComment_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_XdAttribComment_NatEn(DBA_DYNFLD_STP p, XdAttribCommentNatEn enumValue)
{
    SET_ENUM(p, S_XdAttribComment_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttribComment_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_XdAttribComment_XdStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_XdAttribComment_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_XdAttribComment_XdActionEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdPartyFatcaFatcaCertificationEn GET_A_ThirdPartyFatca_FatcaCertificationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaCertificationEn>  (GET_ENUM(p, A_ThirdPartyFatca_FatcaCertificationEn)));
}
inline ThirdPartyFatcaFatcaIdNatEn  GET_A_ThirdPartyFatca_FatcaIdNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaIdNatEn>  (GET_ENUM(p, A_ThirdPartyFatca_FatcaIdNatEn)));
}
inline ThirdPartyFatcaFatcaAccHolderNatEn GET_A_ThirdPartyFatca_FatcaAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaAccHolderNatEn>  (GET_ENUM(p, A_ThirdPartyFatca_FatcaAccHolderNatEn)));
}

inline ThirdPartyFatcaFatcaCertificationEn _GET_A_ThirdPartyFatca_FatcaCertificationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaCertificationEn>  (_GET_ENUM(p, A_ThirdPartyFatca_FatcaCertificationEn)));
}
inline ThirdPartyFatcaFatcaIdNatEn  _GET_A_ThirdPartyFatca_FatcaIdNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaIdNatEn>  (_GET_ENUM(p, A_ThirdPartyFatca_FatcaIdNatEn)));
}
inline ThirdPartyFatcaFatcaAccHolderNatEn _GET_A_ThirdPartyFatca_FatcaAccHolderNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdPartyFatcaFatcaAccHolderNatEn>  (_GET_ENUM(p, A_ThirdPartyFatca_FatcaAccHolderNatEn)));
}

inline void                         SET_A_ThirdPartyFatca_FatcaCertificationEn(DBA_DYNFLD_STP p, ThirdPartyFatcaFatcaCertificationEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyFatca_FatcaCertificationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyFatca_FatcaIdNatEn(DBA_DYNFLD_STP p, ThirdPartyFatcaFatcaIdNatEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyFatca_FatcaIdNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ThirdPartyFatca_FatcaAccHolderNatEn(DBA_DYNFLD_STP p, ThirdPartyFatcaFatcaAccHolderNatEn enumValue)
{
    SET_ENUM(p, A_ThirdPartyFatca_FatcaAccHolderNatEn, static_cast<unsigned char>(enumValue));
}


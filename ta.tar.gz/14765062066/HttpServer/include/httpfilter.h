/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/**
  @author Francois Mercier
*/

#ifndef HTTPFILTER_H
#define HTTPFILTER_H

#include <QObject>
#include <QList>
#include <QByteArray>

/**
  HTTP Filter allows to act before the treatment of the request/response handler 

*/

class HttpRequest;
class HttpResponse;
class HttpFilter;
class HttpRequestHandler;
class HttpSession;
class PasswordEncrypted;

class HttpFilterChain : public QObject {
	Q_OBJECT
	Q_DISABLE_COPY(HttpFilterChain)
public:

	/** Constructor. */
	HttpFilterChain(HttpRequestHandler* requestHandler, QObject* parent = 0);

	/** Destructor */
	virtual ~HttpFilterChain();
	
	/** add a filter to the chain */
	void appendOwned(HttpFilter* filter);

	virtual bool doFilter(HttpRequest& request, HttpResponse& response);

private:

	/** list of filters to execute */
	QList<HttpFilter*> filters_;
	HttpRequestHandler* requestHandler_;

};

class HttpFilter
{
public:

	HttpFilter();
	virtual ~HttpFilter();

	HttpFilter(const HttpFilter &) = delete;
	HttpFilter & operator=(const HttpFilter &) = delete;

	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain) = 0;

};


class HttpLoggingFilter : public HttpFilter
{
public:

	HttpLoggingFilter();
	virtual ~HttpLoggingFilter();

	HttpLoggingFilter(const HttpLoggingFilter &) = delete;
	HttpLoggingFilter & operator=(const HttpLoggingFilter &) = delete;

	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

};

class HttpTracerFilter : public HttpFilter
{
public:

    HttpTracerFilter();
    virtual ~HttpTracerFilter();

    HttpTracerFilter(const HttpTracerFilter &) = delete;
    HttpTracerFilter & operator=(const HttpTracerFilter &) = delete;

    virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

};

class HttpSessionStore;

class HttpBasicAuthenticationFilter : public HttpFilter
{
public:

	HttpBasicAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore);
	virtual ~HttpBasicAuthenticationFilter();

	HttpBasicAuthenticationFilter(const HttpBasicAuthenticationFilter &) = delete;
	HttpBasicAuthenticationFilter & operator=(const HttpBasicAuthenticationFilter &) = delete;

	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

private:
	bool determineIfAuthorized(const HttpRequest& request, HttpResponse& response, HttpSession& session);

	const QByteArray realmName_;
	HttpSessionStore* sessionStore_;
};

class HttpOAuthAuthenticationFilter : public HttpFilter
{
public:
	HttpOAuthAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore);
	virtual ~HttpOAuthAuthenticationFilter();

	HttpOAuthAuthenticationFilter(const HttpOAuthAuthenticationFilter&) = delete;
	HttpOAuthAuthenticationFilter& operator=(const HttpOAuthAuthenticationFilter&) = delete;

	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

private:
	bool determineIfAuthorized(const HttpRequest& request, HttpResponse& response, HttpSession& session);

	const QByteArray realmName_;
	HttpSessionStore* sessionStore_;
};

/* PMSTA-34344 - TEB - 190405 */
class AAARealmServerAuthenticationFilter : public HttpFilter
{
public:

    AAARealmServerAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore);
    virtual ~AAARealmServerAuthenticationFilter();

    AAARealmServerAuthenticationFilter(const AAARealmServerAuthenticationFilter &) = delete;
    AAARealmServerAuthenticationFilter & operator=(const AAARealmServerAuthenticationFilter &) = delete;

    virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);
protected:

    bool checkPassword(const HttpRequest& request, HttpSession& session, const QByteArray&, PasswordEncrypted&);

private:
    bool determineIfAuthorized(const HttpRequest& request, HttpSession& session);

private:
    const QByteArray realmName_;
    HttpSessionStore* sessionStore_;
};

class HttpSessionFilter : public HttpFilter
{
public:

	HttpSessionFilter(HttpSessionStore* sessionStore);
	virtual ~HttpSessionFilter();

	HttpSessionFilter(const HttpSessionFilter &) = delete;
	HttpSessionFilter & operator=(const HttpSessionFilter &) = delete;

	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

private:
	HttpSessionStore* sessionStore_;
};

/* PMSTA-34344 - TEB - 190405 */
class HttpApplSessionFilter : public HttpFilter
{
public:

    HttpApplSessionFilter(HttpSessionStore* sessionStore);
    virtual ~HttpApplSessionFilter();

    HttpApplSessionFilter(const HttpApplSessionFilter &) = delete;
    HttpApplSessionFilter & operator=(const HttpApplSessionFilter &) = delete;

    virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

private:
    HttpSessionStore* sessionStore_;
};

class HttpIPAccessFilter : public HttpFilter
{
public:

	HttpIPAccessFilter();
	virtual ~HttpIPAccessFilter();

	HttpIPAccessFilter(const HttpIPAccessFilter &) = delete;
	HttpIPAccessFilter & operator=(const HttpIPAccessFilter &) = delete;


	virtual void doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain);

};

QByteArray getRequestHeader(const HttpRequest& request, const QByteArray& hKey);

#endif // HTTPFILTER_H

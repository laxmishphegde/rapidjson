/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef RPCCONTROLLER_H
#define RPCCONTROLLER_H

#include "httprequest.h"
#include "httpresponse.h"
#include "httprequesthandler.h"
#include "httpsessionstore.h"

/**
  This controller demonstrates how to use sessions.
*/

class RpcController : public HttpRequestHandler {
    Q_OBJECT
    Q_DISABLE_COPY(RpcController)
public:

    /** Constructor */
    RpcController(HttpSessionStore* sessionStore, QObject* parent = 0);

    /** Generates the response */
    void service(HttpRequest& request, HttpResponse& response);

private:
	HttpSessionStore* sessionStore_;
};

/* PMSTA-34344 - TEB - 190405 */
/* TODO put it in specific file ApplSessionController.cpp and ApplSessionController.h */
/**
  This controller is designed to handle autentication and appl session creation.
*/
class ApplSessionController : public HttpRequestHandler {
    Q_OBJECT
        Q_DISABLE_COPY(ApplSessionController)
public:

    /** Constructor */
    ApplSessionController(HttpSessionStore* sessionStore, QObject* parent = 0);

    /** Generates the response */
    void service(HttpRequest& request, HttpResponse& response);

private:
    HttpSessionStore* sessionStore_;
};

#endif // SESSIONCONTROLLER_H

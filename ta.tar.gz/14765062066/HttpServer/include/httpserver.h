/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef HTTPSERVER_H
#define HTTPSERVER_H

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include "unidef.h"
#include "dba.h"

#include "httplistener.h"
#include "requestmapper.h"
#include "rpccontext.h"
#include "json.h"
#include "httpsession.h"
#include "httplib.h"

#ifdef NTWIN
#pragma warning(disable:4127)
#pragma warning(disable:4251)
#endif
#include "QCoreApplication"
#include "QSettings"
#ifdef NTWIN
#pragma warning (pop)
#endif


class QCoreApplication;

/************************************************************************
**
**  Description :   This is the RPC HTTP context
**
**  Last modif. :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**
*************************************************************************/

class RpcContextHttp : public RpcContext
{
    public:
        RpcContextHttp(const HttpRequest& request, HttpResponse & response);
        ~RpcContextHttp();

		RpcContextHttp(const RpcContextHttp &) = delete;
		RpcContextHttp & operator=(const RpcContextHttp &) = delete;

        virtual RpcContextType  getRpcContextType();
        virtual void            setRpcOnError();
        virtual void            serverDoneError();
        virtual int             serverMsg(const char *text, int number, int status);
        virtual bool            servColBind(int colNumber, const char * colName, DATATYPE_ENUM type, DBI_PTR dataPtr, DBI_INT *dataLength, DBI_SMALLINT *nullData, FIELD_IDX_T dynStPos);
        virtual bool            servSendRowData();
        virtual bool            servSendDone(int, int);
        virtual bool            servEndianWorkAround();
        virtual void            servStop();
        virtual bool            servSleep(std::string sleepMsg);
        virtual bool            servWakeUp();
        virtual bool            servEvent(SRV_EVENT_ENUM);
        virtual std::string     getCharsetName();
        virtual std::string     getConnectionInputKey();

        virtual bool            bindRecord(DBA_DYNST_ENUM, const char **, std::set<INT_T>*);
        virtual bool            prepareDataField(DATATYPE_ENUM, int, DBA_DYNFLD_STP, int);

        // Used only the time of Authentication     PMSTA-24510 - 220816 - PMO
        void                setAuthenticationUserPwd(const QByteArray *, PasswordEncrypted *);
        const QByteArray *  getAuthenticationUser() const;
        PasswordEncrypted * getAuthenticationPwd();
        int                 getHTTPStatusFromTaRetCode();

		void                setSessionId(QByteArray );
		QByteArray          getSessionId();
        void                setHttpBody(const std::string & httpBody);
        const std::string & getHttpBody();
        bool                servSendFile(const std::string & filename, const std::string & mimeType);
        bool                servSendData(const std::string& jsonData); /* PMSTA-46681 - LJE - 220704 */

        const std::string& getDisplayHost() const;

        void                setImportLogLevel(const std::string&);
        ProcessingMessageNatEn  getImportLogLevel() const;

        void                setEntityProfile(const std::string&);
        const std::string & getEntityProfile() const;

        void                setJWT(QByteArray);
        QByteArray          getJWT() const;

    protected:
        virtual bool        servSendStatus(int status);
    
    private:
        void                setDesiredCompression(const HttpRequest& request);
        static int          getMinSizeToCompress();
        void                manageCompression (const std::string& fromData, QByteArray& compressedData);

    private :
        bool                        m_isInit;
        HttpResponse &              m_response;
        FormatFieldsRapidJson *     m_formatFields;
        const QByteArray *          m_authenticationUser;   // Used only the time of Authentication     PMSTA-24510 - 220816 - PMO
        PasswordEncrypted *         m_authenticationPwd;    // Used only the time of Authentication     PMSTA-24510 - 220816 - PMO
		QByteArray                  m_sessionId;			// Used for collect                         PMSTA-24797 - TEB - 160823
        std::string                 m_httpBody;             // Give access to the HTTP body             PMSTA-32235 - 160519 - PMO
        HttpUtility::Compression    m_requestCompression;   /* support  compression                             */ /* PMSTA-36658 -FME- 20200127 */
        std::string                 m_displayHost;          /* PMSTA-43741 - LJE - 210223 */
        std::string                 m_entityProfileCd;      /* PMSTA-46681 - LJE - 240207 */
        ProcessingMessageNatEn          m_importLogLevelEn;     /* PMSTA-46681 - LJE - 240207 */
        QByteArray                  m_base64JWT;

};


/************************************************************************
**
**  Description :   This class represent the configuration of the HTTP Listener.
**                  It will be filled by configuraion file and database attribute of server_connect
**                  and be used to configure the HTTPListener
**
**  Last modif. :
**
*************************************************************************/

class HttpServerListenerConfiguration
{
public:
    HttpServerListenerConfiguration();
    ~HttpServerListenerConfiguration();

    HttpServerListenerConfiguration(const HttpServerListenerConfiguration &) = delete;
    HttpServerListenerConfiguration & operator=(const HttpServerListenerConfiguration &) = delete;

    QSettings* getQSettings(QObject * parent = 0);

    void setCertificateFilePath(const QString& certificateFilePath);
    void setPrivateKeyFilePath(const QString& privateKeyFilePath);
	void setTrustStoreFilePath(const QString& clientCertFilePath);
    void setMinThreads(int minThreads);
    void setMaxThreads(int maxThreads);
    void setCleanupIntervalsec(int cleanupIntervalsec);
    void setReadTimeoutSec(int readTimeoutSec);
    void setMaxRequestSize(int maxRequestSize);
    void setMaxMultiPartSize(int maxMultiPartSize);
    void setStackSize(int stackSize);
    bool setListeningInterface(const QString& listeningInterface);
    void setListeningInterfaceName(const QString& listeningInterface);/* PMSTA - 32186 CMILOS 05032019 */
    void setListeningPort(int listeningPort);
    void setListeningExternalInterface(const QString& listeningInterface);
    void setSslProtocolVersion(const QString& sslProtocolVersion); /* PMSTA-47921 Sudeep 29092022 */
    void setListeningExternalPort(int listeningPort);
    void setUse_ssl(bool use_ssl);
	void setMutual_tls(bool mutual_tls);
    void setUse_external_ssl(bool use_ssl); /* PMSTA-30135 CMILOS 140219 */
    void setNeedToStart(bool needToStart);

public:

    const QString& getCertificateFilePath() const;
    const QString& getPrivateKeyFilePath() const;
	const QString& getTrustStoreFilePath() const;
    int getMinThreads() const;
    int getMaxThreads() const;
    int getCleanupIntervalsec() const;
    int getReadTimeoutSec() const;
    int getMaxRequestSize() const;
    int getMaxMultiPartSize() const;
    int getStackSize() const;
    const QString& getListeningInterface() const;
    const QString& getListeningInterfaceName() const; /* PMSTA - 32186 CMILOS 05032019 */
    int getListeningPort() const;
    const QString& getListeningExternalInterface() const;
    const QString& getSslProtocolVersion() const; /* PMSTA-47921 Sudeep 29092022 */
    int getListeningExternalPort() const;
    bool isUse_ssl() const;
	bool isMutual_tls() const;
    bool isUse_external_ssl() const; /* PMSTA-30135 CMILOS 140219 */
    bool isNeedToStart() const;

private:

    QString m_certificateFilePath;
    QString m_privateKeyFilePath;
	QString m_trustStoreFilePath;
    QString m_listeningInterface;
    QString m_listeningInterfaceName; /* PMSTA - 32186 CMILOS 05032019 */
    QString m_listeningExternalInterface;
    QString m_sslProtocolVersion;  /* PMSTA-47921 Sudeep 29092022 */
    int m_minThreads;
    int m_maxThreads;
    int m_cleanupIntervalsec;
    int m_readTimeoutSec;
    int m_maxRequestSize;
    int m_maxMultiPartSize;
    int m_stackSize;
    int m_listeningPort;
    int m_listeningExternalPort;
    bool m_use_ssl;
	bool m_mutual_tls;
    bool m_use_external_ssl; /* PMSTA-30135 CMILOS 140219 */
    bool m_needToStart;
};

/************************************************************************
**
**  Description :   This class represent the configuration of the HTTP Session and session Store.
**                  It will be filled by configuraion file and database attribute of appl_session
**                  and be used to configure the HTTPSession/HTTPSessionStore
**
**  Last modif. :
**
*************************************************************************/

class HttpServerSessionConfiguration
{
public:
    HttpServerSessionConfiguration();
    ~HttpServerSessionConfiguration();

    HttpServerSessionConfiguration(const HttpServerSessionConfiguration &) = delete;
    HttpServerSessionConfiguration & operator=(const HttpServerSessionConfiguration &) = delete;

    QSettings* getQSettings(QObject * parent = 0);

    int getExpirationTimeSec() const;
    const QString& getCookieName() const;
    const QString& getCookiePath() const;
    const QString& getCookieComment() const;
    const QString& getCookieDomain() const;
    bool isCookieSecure() const;
    const QString& getRealmName() const;

    void setExpirationTimeSec(int expirationTimeSec);
    void setCookieName(const QString& cookieName);
    void setCookiePath(const QString& cookiePath);
    void setCookieComment(const QString& cookieComment);
    void setCookieDomain(const QString& cookieDomain);
    void setCookieSecure(bool cookieSecure);
    void setRealmName(const QString& realmName);

private:

    QString m_cookieName;
    QString m_cookiePath;
    QString m_cookieComment;
    QString m_cookieDomain;
    QString m_RealmName;
    int m_expirationTimeSec;
    bool m_cookieSecure;

};




/************************************************************************
*
*   Description     :   HTTP server startServer callback
*
*   Arguments       :
*
*   Return          :
*
*   Last Modif.     :   DLA - PMSTA-25072 - 161019
*   Last Modif.     :   FME - PMSTA-24869 - 161130  Avoid creation of QSettings file
*
*************************************************************************/
class AAAQCoreApplication : public QCoreApplication
{
    Q_OBJECT
    Q_DISABLE_COPY(AAAQCoreApplication)
  public:

    typedef enum {
          listenerConfigurationQSetting,
          sessionConfigurationQSetting,
          configurationQSettinglastValue
    } InMemoryConfigurationQSetting;

    AAAQCoreApplication(int &argc, char **argv);

    static const QSettings::Format& getInMemoryQSettingsFormat(InMemoryConfigurationQSetting setting);
    static void                     DISP(QSettings* settings);
    static void                     DISP(const QSettings::SettingsMap &map);

  private:
    static bool readQSettingNone(QIODevice &device, QSettings::SettingsMap &map);
    static bool writeQSettingNone(QIODevice &device, const QSettings::SettingsMap &map);

  public slots:
    void HTTP_StartServerHandler();

  private:
      static QSettings::Format m_inMemoryQSettingsFormat[InMemoryConfigurationQSetting::configurationQSettinglastValue];

};


/************************************************************************
*
*   Description     :   Main object for creating the HTTP server
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
class HttpServer
{
    public:
        HttpServer(AAAQCoreApplication *, const QString& serverName);
        ~HttpServer();

        HttpServer(const HttpServer &)             = delete;
        HttpServer & operator=(const HttpServer &) = delete;

        bool                configure();

        // Start the event loop
        int                start();

        void               stopInProgress();


        AAAQCoreApplication *  getQtCoreApplication();

    private:
        void init(HttpServerSessionConfiguration&);
        void init(HttpServerListenerConfiguration&);

    private:
        QString                         m_ServerName;                       /* The name of the TAP Server */
        AAAQCoreApplication *           m_QtCoreApplication;                /* The QT application                           */
	    HttpListener *                  m_HttpListener;                     /* The HTTP listener of the application         */
        RequestMapper *                 m_RequestMapper;                    /* HTTP request mapper */

        HttpServerFileConfiguration     m_HttpServerFileConfiguration;      /* HTTP server might have a configuration file  */

        HttpServerListenerConfiguration m_ListenerConfiguration;
};


extern void HTTP_RpcExecutor(HttpRequest &, HttpResponse &, QByteArray &, HttpSession &);
bool Http_ReadRpcParameters(HttpRequest&, RpcContextHttp&, const RpcProperties&);
bool HTTP_Authentication(const HttpRequest& request, HttpSession &, const QByteArray&, PasswordEncrypted&);  /* PMSTA-34344 - TEB - 190405 */

#endif // HTTPSERVER_H


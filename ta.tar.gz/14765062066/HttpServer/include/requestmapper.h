/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef REQUESTMAPPER_H
#define REQUESTMAPPER_H

#include "httprequesthandler.h"

class StaticFileController;
class HttpSessionStore;
class HttpServerSessionConfiguration;

/**
  The request mapper dispatches incoming HTTP requests to controller classes
  depending on the requested path.
*/

class RequestMapper : public HttpRequestHandler {
    Q_OBJECT
    Q_DISABLE_COPY(RequestMapper)
public:

    /**
      Constructor.
      @param parent Parent object
    */
	RequestMapper(QObject* parent=0);

	
    void configureSessionStore(HttpServerSessionConfiguration& sessionStoreConfiguration);

	/**
      Destructor.
    */
    ~RequestMapper();
	
    /**
      Dispatch incoming HTTP requests to different controllers depending on the URL.
      @param request The received HTTP request
      @param response Must be used to return the response
    */
    void service(HttpRequest& request, HttpResponse& response);

private:

	/** Storage for session cookies */
	HttpSessionStore* m_sessionStore;

    QString m_RealmName;

};

#endif // REQUESTMAPPER_H
